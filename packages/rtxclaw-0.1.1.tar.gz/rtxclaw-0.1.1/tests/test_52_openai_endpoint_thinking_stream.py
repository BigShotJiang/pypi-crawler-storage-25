"""Step 52 — OpenAI endpoint surfaces intermediate ACP events as
``<think>...</think>`` content so Open WebUI renders them as
collapsible thinking blocks.

Pre-fix the openai_endpoint silently dropped every sessionUpdate
except ``agent_message_chunk`` (the final assistant text). Tool
runs, reasoning, and plan updates ran fine on the agent side but
the OpenAI caller saw a wall of silence until the final answer.

Fix: a small synchronous helper, ``format_session_updates_for_openai``,
folds an ACP sessionUpdate stream into a flat sequence of ``content``
deltas. Intermediate events go inside a ``<think>…</think>`` wrapper
(Open WebUI's canonical collapsible-reasoning pattern); the wrapper
closes on the first ``agent_message_chunk``. Streaming and non-
streaming paths share the same helper so the wire shape is identical.
"""
from __future__ import annotations


def _evs(*shapes: dict) -> list[dict]:
    return list(shapes)


def _content(text: str) -> dict:
    return {
        "sessionUpdate": "agent_message_chunk",
        "content": {"type": "text", "text": text},
    }


def _thought(text: str) -> dict:
    return {
        "sessionUpdate": "agent_thought_chunk",
        "content": {"type": "text", "text": text},
    }


def _tool_start(call_id: str, title: str, args: dict) -> dict:
    return {
        "sessionUpdate": "tool_call",
        "toolCallId": call_id,
        "title": title,
        "status": "in_progress",
        "rawInput": dict(args),
    }


def _tool_done(call_id: str, ok: bool = True) -> dict:
    return {
        "sessionUpdate": "tool_call_update",
        "toolCallId": call_id,
        "status": "completed" if ok else "failed",
        "content": [],
    }


def _consume(events: list[dict]) -> str:
    """Run the helper synchronously and return the concatenated content."""
    from rtxclaw_agent.openai_endpoint import format_session_updates_for_openai
    out: list[str] = []
    state = None
    for ev in events:
        chunks, state = format_session_updates_for_openai(ev, state)
        for c in chunks:
            out.append(c)
    # Drain — emit a final "flush" sentinel so the wrapper can close
    # any open <think> if the stream ends without ever producing
    # content.
    chunks, _state = format_session_updates_for_openai(None, state)
    for c in chunks:
        out.append(c)
    return "".join(out)


def test_only_final_content_passes_through_unwrapped() -> None:
    """No intermediate events → plain content delta, no <think> wrapper."""
    out = _consume(_evs(_content("hello"), _content(" world")))
    assert out == "hello world"


def test_intermediate_thought_wrapped_in_think_tags() -> None:
    """A standalone reasoning chunk before content gets wrapped."""
    out = _consume(_evs(
        _thought("let me think about this"),
        _content("the answer is 42"),
    ))
    assert out.startswith("<think>")
    assert "</think>" in out
    assert "let me think about this" in out.split("</think>")[0]
    assert out.endswith("the answer is 42")


def test_tool_call_rendered_as_human_readable_line() -> None:
    """A tool call becomes a one-line marker inside the think block."""
    out = _consume(_evs(
        _tool_start("c1", "web_fetch", {"url": "https://example.com"}),
        _tool_done("c1", ok=True),
        _content("done"),
    ))
    pre = out.split("</think>")[0]
    assert "<think>" in pre
    assert "web_fetch" in pre
    # Args summary (URL or part of it) surfaces.
    assert "example.com" in pre
    # Completion marker — some unicode/ascii result indicator.
    assert "OK" in pre or "✓" in pre
    assert out.endswith("done")


def test_failed_tool_marker_distinguished_from_ok() -> None:
    out = _consume(_evs(
        _tool_start("c1", "broken_tool", {}),
        _tool_done("c1", ok=False),
        _content("recovered"),
    ))
    pre = out.split("</think>")[0]
    assert "failed" in pre.lower() or "✗" in pre


def test_think_block_closes_only_once_when_content_arrives() -> None:
    """After the first content delta the wrapper must NOT re-open
    a new <think> block — even if the agent emits more reasoning
    interleaved later (we treat post-content reasoning as deliberate
    inline content, not metadata)."""
    out = _consume(_evs(
        _thought("planning"),
        _content("first part "),
        _thought("more reasoning"),
        _content("second part"),
    ))
    # Exactly one open + one close.
    assert out.count("<think>") == 1
    assert out.count("</think>") == 1
    # Inline post-content thought leaks into content (acceptable
    # fallback — better than dropping it silently).
    assert "first part " in out
    assert "second part" in out


def test_empty_stream_yields_nothing() -> None:
    out = _consume(_evs())
    assert out == ""


def test_only_intermediate_with_no_content_still_closes_think() -> None:
    """If the turn ends with only intermediate events (no
    agent_message_chunk), the flush MUST close the <think> block so
    Open WebUI doesn't render an unterminated tag."""
    out = _consume(_evs(
        _thought("I have nothing to say"),
    ))
    assert out.startswith("<think>")
    assert out.endswith("</think>") or out.rstrip().endswith("</think>")
