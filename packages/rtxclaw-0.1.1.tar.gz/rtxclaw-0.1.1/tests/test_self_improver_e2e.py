"""End-to-end smoke test: fire a synthetic ReasoningLoopDetected payload
through the installed wrapper and verify (a) a Claude spawn would have
happened, (b) the run counter increments, (c) the sidecar would be
written (verified by the stubbed claude script touching the sidecar)."""
import json
import os
import stat
import subprocess
import textwrap
import time
from pathlib import Path

import pytest


@pytest.fixture
def installed(tmp_path, monkeypatch):
    rtxhome = tmp_path / "rtxhome"
    src_repo = tmp_path / "src" / "rtxclaw"
    bin_dir = tmp_path / "bin"
    (src_repo / "assets" / "self-improver").mkdir(parents=True)
    (src_repo / "scripts").mkdir(parents=True)
    bin_dir.mkdir(parents=True)
    # Copy real assets from the repo under test into the staged src tree.
    repo_root = Path(__file__).resolve().parents[1]
    for name in ("self-improver.sh", "self-improver-scan.sh",
                 "self-improver-gc.sh", "hooks.json"):
        (src_repo / "assets" / "self-improver" / name).write_text(
            (repo_root / "assets" / "self-improver" / name).read_text()
        )
    (src_repo / "scripts" / "self-improver-prompt.md").write_text(
        (repo_root / "scripts" / "self-improver-prompt.md").read_text()
    )
    (src_repo / "scripts" / "run-self-improver-tests.sh").write_text(
        (repo_root / "scripts" / "run-self-improver-tests.sh").read_text()
    )

    # Stub claude — records its prompt arg + side-effects a sidecar.
    sidecar_dir = rtxhome / "agents" / "main" / "session_reviews"
    fake = bin_dir / "claude"
    fake.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env bash
        # The real claude would read its prompt argv and write the
        # sidecar via the protocol; the stub simulates the sidecar
        # write to verify the wiring is intact.
        mkdir -p {sidecar_dir}
        echo '{{"status":"clean","trigger":"reasoning-loop"}}' > \\
            {sidecar_dir}/sess-e2e.json
    """))
    fake.chmod(0o755)

    monkeypatch.setenv("PATH", f"{bin_dir}:{os.environ['PATH']}")
    monkeypatch.setenv("RTXCLAW_HOME", str(rtxhome))
    monkeypatch.setenv("RTXCLAW_SOURCE_DIR", str(src_repo))

    # Run the installer.
    from rtxclaw_agent.self_improver_install import install
    install(agents=("main",), print_cron=True)
    return {"rtxhome": rtxhome, "sidecar_dir": sidecar_dir}


def test_e2e_hook_to_sidecar(installed):
    rtxhome = installed["rtxhome"]
    wrapper = rtxhome / "scripts" / "self-improver.sh"
    payload = json.dumps({
        "hook_event_name": "ReasoningLoopDetected",
        "session_id": "sess-e2e",
        "transcript_path": "/dev/null",
        "cwd": "/tmp",
        "agent_name": "main",
    })
    proc = subprocess.run(
        [str(wrapper), "reasoning-loop"],
        input=payload, text=True, capture_output=True, timeout=15,
    )
    assert proc.returncode == 0, proc.stderr

    target = installed["sidecar_dir"] / "sess-e2e.json"
    for _ in range(30):
        if target.exists():
            break
        time.sleep(0.1)
    assert target.exists(), "stubbed claude did not produce sidecar — wiring broken"

    runs = list((rtxhome / "self-improver" / "runs").iterdir())
    assert runs, "run marker not written"
