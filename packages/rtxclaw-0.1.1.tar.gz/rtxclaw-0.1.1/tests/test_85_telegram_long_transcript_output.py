import asyncio
import pytest
from rtxclaw_telegram.bot import _TelegramAPI
from rtxclaw_telegram.bot import AcpTelegramBot
from rtxclaw_telegram.config import TelegramConfig


def _async_return(value):
    async def _f(*a, **k): return value
    return _f


def test_send_document_builds_multipart(monkeypatch):
    api = _TelegramAPI("TOKEN")
    captured = {}
    class _Resp:
        status_code = 200
        def json(self): return {"ok": True, "result": {"message_id": 7}}
    async def fake_post(url, *, data=None, files=None):
        captured["url"] = url; captured["data"] = data; captured["files"] = files
        return _Resp()
    monkeypatch.setattr(api._http, "post", fake_post)
    mid = asyncio.run(api.send_document(123, b"hello transcript",
        filename="transcript.txt", caption="🎙️ transcript", message_thread_id=9))
    assert mid == 7
    assert captured["url"].endswith("/sendDocument")
    assert captured["data"]["chat_id"] == "123"
    assert captured["data"]["message_thread_id"] == "9"
    assert captured["files"]["document"][0] == "transcript.txt"


class _FakeAPI2:
    def __init__(self): self.docs=[]; self.msgs=[]; self.edits=[]; self._next=100; self.local_mode=False
    async def send_message(self, cid, text, *, message_thread_id=None, parse_mode=None):
        self._next+=1; self.msgs.append((self._next, text)); return self._next
    async def edit_message(self, cid, mid, text): self.edits.append((mid, text)); return (True, 0.0)
    async def send_document(self, cid, b, *, filename="f.txt", caption=None, mime=None, message_thread_id=None):
        self.docs.append((filename, b, caption)); return 999
    async def call(self, m, **k): return {"ok": True, "result": {}}


@pytest.fixture
def home(tmp_path, monkeypatch): monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path)); return tmp_path


@pytest.mark.asyncio
async def test_long_transcript_sent_as_document_and_fed(home, monkeypatch):
    api = _FakeAPI2()
    long_text = "word " * 1000  # >1500 chars
    bot = AcpTelegramBot(TelegramConfig(default_agent="main"), acp_url="",
        trusted_chats=set(), api=api, tts=None,
        stt=_async_return(long_text),
        download_audio=_async_return((b"AUDIO", "v.m4a")))
    captured = {}
    async def fake_dispatch(cid, blocks, *, on_chunk=None, on_tool_status=None, thread_id=None):
        captured["blocks"] = blocks
        if on_chunk: await on_chunk("reply", force=True)
        return "reply"
    monkeypatch.setattr(bot, "_dispatch_blocks", fake_dispatch)
    await bot._stream_turn_for_chat(1, voice_file_id="F", voice_mime="audio/mp4")
    assert api.docs and api.docs[0][0].endswith(".txt")
    assert long_text in api.docs[0][1].decode()
    assert any(getattr(b, "text", "") == long_text for b in captured["blocks"])


@pytest.mark.asyncio
async def test_short_transcript_inline_echo_no_document(home, monkeypatch):
    api = _FakeAPI2()
    bot = AcpTelegramBot(TelegramConfig(default_agent="main"), acp_url="",
        trusted_chats=set(), api=api, tts=None,
        stt=_async_return("hello there"),
        download_audio=_async_return((b"AUDIO", "v.m4a")))
    async def fake_dispatch(cid, blocks, *, on_chunk=None, on_tool_status=None, thread_id=None):
        if on_chunk: await on_chunk("reply", force=True)
        return "reply"
    monkeypatch.setattr(bot, "_dispatch_blocks", fake_dispatch)
    await bot._stream_turn_for_chat(1, voice_file_id="F", voice_mime="audio/mp4")
    assert not api.docs
    assert any("🎙️ heard" in t for _, t in api.edits)
