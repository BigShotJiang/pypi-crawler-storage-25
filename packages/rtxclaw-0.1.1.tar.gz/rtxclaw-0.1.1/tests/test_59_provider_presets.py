"""Step 59 — provider presets + the bundled free-default key guard.

Pure-function unit tests (no network, no filesystem) for the 0.1.0
"ship a free Nemotron default" feature. The security-critical surface is
``bundled_key_for_row``: the shared, public OpenRouter demo key must fire
ONLY for the exact shipped default row and NEVER for a user-configured
model — otherwise the shared key could bill paid models or leak to a
look-alike host (both flagged in code review).
"""
from __future__ import annotations

from rtxclaw_core import provider_presets as pp


# ---- presets table -------------------------------------------------------

def test_presets_are_openai_compatible_and_unique():
    keys = [p.key for p in pp.PROVIDER_PRESETS]
    assert len(keys) == len(set(keys)), "preset keys must be unique"
    # The providers the user asked to ship are present.
    for want in ("openrouter", "openai", "deepseek", "xai", "qwen", "groq",
                 "mistral", "gemini"):
        assert want in keys, f"missing provider preset: {want}"
    # Anthropic is intentionally absent (native Messages API, not OpenAI-shaped).
    assert "anthropic" not in keys
    for p in pp.PROVIDER_PRESETS:
        assert p.base_url.startswith("http"), p
        # hosted providers declare a key env; local servers don't.
        if "127.0.0.1" not in p.base_url and "localhost" not in p.base_url:
            assert p.api_key_env, f"{p.key} should declare an api_key_env"


def test_preset_by_key():
    assert pp.preset_by_key("deepseek").base_url == "https://api.deepseek.com/v1"
    assert pp.preset_by_key("DeepSeek").key == "deepseek"   # case-insensitive
    assert pp.preset_by_key("nope") is None


# ---- is_openrouter: host equality, not substring -------------------------

def test_is_openrouter_requires_exact_host():
    assert pp.is_openrouter("https://openrouter.ai/api/v1")
    assert pp.is_openrouter("http://openrouter.ai/api/v1")
    # look-alikes and substrings must NOT match
    assert not pp.is_openrouter("https://openrouter.ai.evil.example/v1")
    assert not pp.is_openrouter("https://notopenrouter.ai/v1")
    assert not pp.is_openrouter("https://api.openai.com/v1")
    assert not pp.is_openrouter("")


# ---- bundled key guard (the important one) -------------------------------

def test_bundled_key_fires_only_for_shipped_default():
    row = pp.default_model_row()
    assert row["useBundledKey"] is True
    assert row["id"] == pp.DEFAULT_MODEL
    assert pp.bundled_key_for_row(row) == pp.BUNDLED_OPENROUTER_KEY


def test_bundled_key_withheld_from_paid_model_edit():
    # User keeps useBundledKey but swaps in a paid OpenRouter model.
    row = pp.default_model_row()
    row["id"] = "openai/gpt-5"
    assert pp.bundled_key_for_row(row) == ""


def test_bundled_key_withheld_from_lookalike_host():
    row = pp.default_model_row()
    row["baseUrl"] = "https://openrouter.ai.evil.example/api/v1"
    assert pp.bundled_key_for_row(row) == ""


def test_bundled_key_withheld_from_user_row_without_flag():
    # A user-added OpenRouter row (correct model, no useBundledKey flag).
    row = {
        "baseUrl": "https://openrouter.ai/api/v1",
        "id": pp.DEFAULT_MODEL,
        "apiKeyEnv": "OPENROUTER_API_KEY",
    }
    assert pp.bundled_key_for_row(row) == ""


def test_bundled_key_withheld_from_non_openrouter():
    row = pp.default_model_row()
    row["baseUrl"] = "https://api.openai.com/v1"
    assert pp.bundled_key_for_row(row) == ""


def test_bundled_key_handles_garbage_input():
    assert pp.bundled_key_for_row({}) == ""
    assert pp.bundled_key_for_row(None) == ""  # type: ignore[arg-type]


# ---- personal key always wins (resolution order in upstream_headers) -----

def test_personal_key_beats_bundled_in_upstream_headers(monkeypatch):
    """AgentConfig.upstream_headers must prefer a real OPENROUTER_API_KEY
    over the bundled demo key for the default row."""
    from rtxclaw_core.agent import AgentConfig

    cfg = AgentConfig(name="main")
    cfg.models = [pp.default_model_row()]
    cfg.upstream_endpoint = pp.DEFAULT_BASE_URL

    # No personal key set anywhere → bundled key is used.
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    cfg.api_keys = {}
    h = cfg.upstream_headers(pp.DEFAULT_BASE_URL)
    assert h.get("Authorization") == f"Bearer {pp.BUNDLED_OPENROUTER_KEY}"

    # Personal key in env → it wins.
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-personal-xyz")
    h = cfg.upstream_headers(pp.DEFAULT_BASE_URL)
    assert h.get("Authorization") == "Bearer sk-or-personal-xyz"
