"""Step 74 — session-log attribution for ACP-bridge-created sessions.

Regression (operator report 2026-05-20: "session logs agent name
backend are all empty"):

The local-LLM ACP path — ``CoreBackend.new_session``, the live
TUI / gateway session creator, ``workspace_origin="acp"`` — built the
``Session`` via ``Session.new()`` and persisted it with
``sess.save(force=True)``, but:

* it never called :func:`session_log.record_session_creation`, so
  ``agent_name`` / ``engine`` were never stamped onto the Session, and
* it never passed ``backend`` / ``context_window`` into ``Session.new``.

The ``session_started`` event — and therefore the ``sessions_meta``
row — was written with empty ``agent_name`` and ``backend``. Worse,
``Session.save``'s ``header_update`` path explicitly excludes
``agent_name`` (session.py), so the blank could never self-heal on a
later config toggle. Every ``session/list`` / TUI session-picker row
showed a blank agent + backend for every local-LLM session.

(The CLI agents — claude / codex / antigravity — go through
``Agent.create_session``, which stamps attribution correctly, so only
the ``orig='acp'`` local-LLM sessions were affected.)

This file pins the contract: a session created through the bridge
carries its ``agent_name``, ``engine``, and ``backend`` in
``sessions.db``.
"""
from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path

import pytest

from rtxclaw_agent.acp_bridge import CoreBackend
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.session_index import SessionIndex


def _meta_row(sessions_dir: Path, sid: str) -> dict:
    """Project the JSONL into ``sessions.db`` (the lazy-index read path
    the bridge / ``session/list`` use) and return the row for ``sid``.

    ``SessionWriter`` writes only the JSONL on the hot path; the
    ``sessions_meta`` row is materialised by tailing the JSONL — exactly
    what a reader (``session/list``, TUI picker, ``Agent.list_sessions``)
    triggers. The bug is in what the projected row CONTAINS, so we drive
    the same projection here.
    """
    SessionIndex(sessions_dir.parent).tail(sid)
    db = sessions_dir / "sessions.db"
    assert db.exists(), f"sessions.db never created at {db}"
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    try:
        r = con.execute(
            "SELECT agent_name, engine, backend, model, workspace_origin, "
            "context_window FROM sessions_meta WHERE session_hash=?",
            (sid,),
        ).fetchone()
    finally:
        con.close()
    assert r is not None, f"no sessions_meta row for {sid}"
    return dict(r)


def test_bridge_new_session_stamps_agent_name_engine_backend(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A bridge-created (``orig='acp'``) session must carry its
    agent_name, engine, and backend in ``sessions.db`` — not blanks."""
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(
        name="main",
        system="sys",
        backend="vllm",
        upstream_max_context=262144,
    )
    bridge = CoreBackend(cfg)

    resp = asyncio.run(bridge.new_session(str(tmp_path), []))
    sid = resp["sessionId"]

    row = _meta_row(cfg.sessions_dir, sid)
    assert row["workspace_origin"] == "acp"
    assert row["agent_name"] == "main", (
        f"agent_name blank in sessions.db (got {row['agent_name']!r}); "
        "bridge.new_session skipped record_session_creation"
    )
    assert row["engine"] == "local_llm", (
        f"engine not stamped (got {row['engine']!r})"
    )
    assert row["backend"] == "vllm", (
        f"backend blank in sessions.db (got {row['backend']!r}); "
        "bridge.new_session dropped cfg.backend"
    )
    assert row["context_window"] == 262144, (
        f"context_window not propagated (got {row['context_window']!r})"
    )


def test_heartbeat_session_stamps_agent_name_engine_backend(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The heartbeat dedicated-session creator (``orig='heartbeat'``)
    had the identical defect — assert it now stamps attribution too."""
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(
        name="main",
        system="sys",
        backend="sglang",
        engine="local_llm",
        upstream_model="qwen3.6-27b-fp8",
        upstream_max_context=96000,
    )
    cfg.home.mkdir(parents=True, exist_ok=True)

    from rtxclaw_agent.heartbeat import HeartbeatScheduler

    sched = HeartbeatScheduler(cfg, app=None)
    sid = asyncio.run(sched._create_dedicated_session())

    row = _meta_row(cfg.sessions_dir, sid)
    assert row["workspace_origin"] == "heartbeat"
    assert row["agent_name"] == "main", (
        f"heartbeat session agent_name blank (got {row['agent_name']!r})"
    )
    assert row["engine"] == "local_llm"
    assert row["backend"] == "sglang", (
        f"heartbeat session backend blank (got {row['backend']!r})"
    )


def test_second_session_started_cannot_blank_attribution(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Defense-in-depth (codex review): a re-emitted ``session_started``
    with empty identity fields must NOT clobber an already-populated
    ``sessions_meta`` row. The projector's upsert previously had no
    empty-skip guard (only ``_apply_header_patch`` did), so any future
    creator emitting a blank ``session_started`` could re-introduce the
    very bug this PR fixes."""
    import sqlite3 as _sqlite3

    from rtxclaw_core.session_index import EventProjector, ensure_schema
    from rtxclaw_core.session_index import connect_sessions_db

    db = tmp_path / "sessions.db"
    ensure_schema(db)
    con = connect_sessions_db(db)
    proj = EventProjector()
    sid = "deadbeefdeadbeefdeadbeefdeadbeef"

    # 1) populated session_started
    con.execute("BEGIN")
    con.execute(
        "INSERT INTO sessions_meta(session_hash) VALUES (?)", (sid,)
    )
    proj.apply(con, sid, {
        "type": "session_started", "agent_name": "main",
        "engine": "local_llm", "backend": "vllm", "created_at": "2026-05-20",
    }, 100)
    con.execute("COMMIT")

    # 2) a SECOND session_started that omits identity fields (the clobber)
    con.execute("BEGIN")
    proj.apply(con, sid, {
        "type": "session_started", "agent_name": "",
        "engine": "", "model": "qwen3.6-27b-fp8",
    }, 200)
    con.execute("COMMIT")

    con.row_factory = _sqlite3.Row
    r = con.execute(
        "SELECT agent_name, engine, backend, model FROM sessions_meta "
        "WHERE session_hash=?", (sid,),
    ).fetchone()
    con.close()
    assert r["agent_name"] == "main", "blank session_started clobbered agent_name"
    assert r["engine"] == "local_llm", "blank session_started clobbered engine"
    assert r["backend"] == "vllm", "backend lost"
    # non-identity fields still update normally
    assert r["model"] == "qwen3.6-27b-fp8", "model update was dropped"
