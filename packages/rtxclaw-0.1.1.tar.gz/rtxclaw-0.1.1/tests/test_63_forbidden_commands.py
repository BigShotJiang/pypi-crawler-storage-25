"""Step 63 — FORBIDDEN class: commands the agent must NEVER even ask
the operator to allow.

Operator instruction (2026-05-18): a destructive command that targets
the operator's home (``rm -rf ~/``), the root filesystem (``rm -rf /``),
a fork bomb, or a whole-disk wipe must be hard-denied in every mode —
the permission modal must not fire because a reflexive "allow" click
on these is catastrophic.

This suite pins:

- The :func:`classify_command` heuristic returns ``CommandSafety.FORBIDDEN``
  for the operator-named patterns AND keeps ``DESTRUCTIVE`` for
  legitimate scoped uses (``rm -rf /tmp/x``, ``rm ~/notes.md`` without
  ``-r``) so we don't false-positive a real workflow.
- The :class:`Criticality` enum has the matching ``FORBIDDEN`` member.
- :meth:`PermissionPolicy.evaluate` returns ``("deny", reason)`` for
  ``criticality="forbidden"`` in EVERY mode (plan/ask/auto), bypassing
  the auto-allowlist short-circuit.

Pure unit test — no daemon, no upstream.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.tools.safety import CommandSafety, classify_command  # noqa: E402
from rtxclaw_core.tools.permissions import Criticality  # noqa: E402
from rtxclaw_core.agents.permissions_integration import PermissionPolicy  # noqa: E402


# ---- classifier: what counts as FORBIDDEN ---------------------------


@pytest.mark.parametrize(
    "cmd",
    [
        "rm -rf ~/",
        "rm -rf ~",
        "rm -rf  ~/",
        "rm -rf ~/*",
        "rm -fr ~/",
        "rm -Rf ~",
        "rm -rf $HOME",
        "rm -rf ${HOME}",
        "rm -rf $HOME/",
        "rm -rf \"$HOME\"",
        "rm -rf '~/'",
        "sudo rm -rf ~/",
        "rm -rf /",
        "rm -rf /*",
        "sudo rm -rf /",
        ":(){ :|:& };:",
        ":() { : | : & } ; :",
        "dd if=/dev/zero of=/dev/sda",
        "dd if=/dev/urandom of=/dev/nvme0n1 bs=1M",
        "mkfs.ext4 /dev/sda",
        "sudo mkfs.xfs /dev/nvme0n1",
    ],
)
def test_forbidden_patterns_classify_as_forbidden(cmd: str):
    assert classify_command(cmd) is CommandSafety.FORBIDDEN, cmd


@pytest.mark.parametrize(
    "cmd",
    [
        "rm -rf /tmp/foo",
        "rm -rf ~/projects/scratch",      # scoped subdir under home — operator chose
        "rm -rf $HOME/scratch",            # scoped subdir under home
        "rm ~/notes.md",                   # not recursive, normal delete
        "rm -f ~/notes.md",                # force but not recursive
        "rm -rf /var/log/old",             # under root but explicit subdir
        "dd if=/dev/zero of=/tmp/zero.bin bs=1M count=10",  # not a device
        "dd if=foo.img of=/dev/sda1",      # partition, not whole disk
        "mkfs.ext4 /dev/sda1",             # partition, not whole disk
        "mkfs.ext4 ./loopfile.img",
    ],
)
def test_real_workflows_are_not_forbidden(cmd: str):
    """The forbidden classifier must not steal legitimate destructive
    workflows from the normal ASK path."""
    assert classify_command(cmd) is not CommandSafety.FORBIDDEN, cmd


# ---- Criticality enum has FORBIDDEN ---------------------------------


def test_criticality_has_forbidden_member():
    assert Criticality.FORBIDDEN.value == "forbidden"
    # Severity is highest — `most_cautious` should always prefer it.
    others = [
        Criticality.READ_ONLY, Criticality.MUTATING, Criticality.DESTRUCTIVE
    ]
    assert all(
        Criticality.FORBIDDEN.severity > c.severity for c in others
    )


# ---- policy evaluator: FORBIDDEN denies in every mode ---------------


@pytest.mark.parametrize("mode", ["plan", "ask", "auto"])
def test_forbidden_is_denied_in_every_mode(mode: str):
    policy = PermissionPolicy(mode=mode)
    decision, reason = policy.evaluate(
        "Bash",
        {"command": "rm -rf ~/"},
        criticality="forbidden",
    )
    assert decision == "deny", (mode, decision, reason)
    assert "forbidden" in reason.lower()


def test_forbidden_bypasses_session_allowlist():
    """Even if the operator (somehow) added this pattern to the
    allowlist, the hard-deny must still fire — that's the whole
    point of the FORBIDDEN class."""
    policy = PermissionPolicy(mode="auto")
    args = {"command": "rm -rf ~/"}
    # Force-add to the session allowlist via the public API.
    policy.remember("Bash", args)
    decision, _ = policy.evaluate("Bash", args, criticality="forbidden")
    assert decision == "deny"


def test_destructive_still_asks_in_auto():
    """Sanity: the new FORBIDDEN branch did not break the existing
    DESTRUCTIVE ASK flow."""
    policy = PermissionPolicy(mode="auto")
    decision, reason = policy.evaluate(
        "Bash",
        {"command": "rm -rf /tmp/x"},
        criticality="destructive",
    )
    assert decision == "ask"
    assert reason
