"""Step 00 — prereqs. Verifies the host can run the rest of the suite."""
from __future__ import annotations

import shutil
import subprocess
import sys
import urllib.request


def test_python_at_least_310() -> None:
    assert sys.version_info >= (3, 10), f"need Python ≥ 3.10, have {sys.version}"


def test_venv_module_available() -> None:
    cp = subprocess.run([sys.executable, "-m", "venv", "--help"],
                        capture_output=True, timeout=10)
    assert cp.returncode == 0, "python3 -m venv unusable (install python3-venv?)"


def test_tmux_on_path() -> None:
    assert shutil.which("tmux"), "tmux missing — step 05 (TUI smoke) will skip"


def test_pypi_reachable() -> None:
    try:
        with urllib.request.urlopen("https://pypi.org/simple/", timeout=5):
            pass
    except Exception as e:  # noqa: BLE001
        # Soft skip — offline runs are valid, but the bootstrap step
        # will explode in a less-clear way without this signal.
        import pytest
        pytest.skip(f"pypi.org unreachable ({e}); bootstrap will fail")
