"""Step 56 — per-session outbound permission routing (fix_20260514).

The decision-harness fix. Before this, ``session/request_permission``
was only ever wired on the stdio transport: every HTTP/WS (gateway)
session had ``backend.server_handle is None``, so a destructive tool
call in auto mode silently auto-denied — the user never saw a prompt.
And because the gateway shares one ``CoreBackend`` across every
connection to ``/acp/<agent>``, a single ``server_handle`` would race
between e.g. a TUI and a Telegram client.

This suite pins the fix:

- ``CoreBackend`` per-session channel registry — ``bind_session_server``
  / ``unbind_session_server`` / ``_outbound_for`` resolution, the
  ``server_handle`` fallback, and multi-connection isolation.
- ``_resolve_outbound_channel`` + ``_request_permission_outbound`` —
  no channel → deny (the deliberate "default to no" for self-contained
  tasks), timeout → deny, wire error → deny, outcome mapping, and
  per-session routing (a prompt for sid1 never hits sid2's wire).
- ``AcpServer._bind_session`` / ``_unbind_session`` wired into
  ``session/new`` / ``session/load`` / ``session/close`` and the
  ``serve_until_close`` teardown.
- ``classify_command`` keeps BOTH ``git branch -d`` and ``-D``
  DESTRUCTIVE (operator instruction: keep ``-d`` destructive).

Fixture-free / offline — pure unit assertions, no Docker harness
fixtures, no network.
"""
from __future__ import annotations

import asyncio

import pytest

from rtxclaw_acp.protocol import JsonRpcFramingError
from rtxclaw_acp.server.server import AcpServer
from rtxclaw_agent.acp_bridge import (
    CoreBackend,
    _resolve_outbound_channel,
)
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.tools.safety import CommandSafety, classify_command


# ---- fakes ----------------------------------------------------------


class _FakeServer:
    """Minimal stand-in for :class:`AcpServer` — records outbound calls
    and returns a scripted response (or raises / hangs)."""

    def __init__(self, response=None, *, raises=None, hang=False):
        self._response = response
        self._raises = raises
        self._hang = hang
        self.calls: list[tuple[str, dict]] = []

    async def request_outbound(self, method, params):
        self.calls.append((method, params))
        if self._hang:
            await asyncio.Event().wait()  # never resolves
        if self._raises is not None:
            raise self._raises
        return self._response


class _FakeBackend:
    """Backend stub for driving ``AcpServer`` session-lifecycle handlers
    without the full CoreBackend. Records per-session bindings."""

    def __init__(self):
        self.bound: dict[str, object] = {}
        self._counter = 0

    async def new_session(self, cwd, mcp_servers):
        self._counter += 1
        return {
            "sessionId": f"sid-{self._counter}",
            "modes": {},
            "configOptions": [],
        }

    async def load_session(self, session_id, cwd, mcp_servers):
        return {"modes": {}, "configOptions": []}

    async def close_session(self, session_id):
        return None

    def bind_session_server(self, session_id, server):
        self.bound[session_id] = server

    def unbind_session_server(self, session_id):
        self.bound.pop(session_id, None)


class _EofTransport:
    """Transport whose read loop is immediately at EOF — drives
    ``serve_until_close`` straight into its teardown ``finally``."""

    async def read_message(self):
        raise JsonRpcFramingError("EOF before any header bytes")

    async def write_message(self, payload):  # pragma: no cover - unused
        return None

    async def close(self):
        return None


class _Tool:
    name = "Bash"


_CALL = {
    "id": "call-1",
    "name": "Bash",
    "arguments": {"command": "git branch -d fix_20260514"},
}


def _backend() -> CoreBackend:
    return CoreBackend(AgentConfig(name="test_agent", permission_mode="auto"))


def _make_server() -> tuple[AcpServer, _FakeBackend]:
    be = _FakeBackend()
    srv = AcpServer(
        _EofTransport(), be, agent_capabilities={}, agent_info={},
    )
    return srv, be


# ---- CoreBackend per-session channel registry -----------------------


def test_outbound_for_prefers_session_binding_over_handle():
    be = _backend()
    fallback = _FakeServer()
    per_session = _FakeServer()
    be.server_handle = fallback
    be.bind_session_server("sidA", per_session)
    # Bound session resolves to its own server …
    assert be._outbound_for("sidA") is per_session
    # … an unbound session falls back to the single handle.
    assert be._outbound_for("sidB") is fallback


def test_outbound_for_unbind_restores_fallback():
    be = _backend()
    fallback = _FakeServer()
    per_session = _FakeServer()
    be.server_handle = fallback
    be.bind_session_server("sidA", per_session)
    be.unbind_session_server("sidA")
    assert be._outbound_for("sidA") is fallback
    # Unbinding an unknown session is a harmless no-op.
    be.unbind_session_server("never-bound")


def test_outbound_for_multi_connection_isolation():
    """Two connections → two AcpServers → one shared backend. Each
    session must resolve to its OWN server (the pre-fix single
    ``server_handle`` raced here — last connection won)."""
    be = _backend()
    srv1 = _FakeServer()
    srv2 = _FakeServer()
    be.bind_session_server("sid1", srv1)
    be.bind_session_server("sid2", srv2)
    assert be._outbound_for("sid1") is srv1
    assert be._outbound_for("sid2") is srv2
    # No global handle wired → an unknown session resolves to None.
    assert be._outbound_for("sid-unknown") is None


def test_resolve_outbound_channel_uses_session_binding():
    be = _backend()
    srv = _FakeServer()
    be.bind_session_server("sid", srv)
    assert _resolve_outbound_channel(be, "sid") is srv


def test_resolve_outbound_channel_rejects_handle_without_request_outbound():
    be = _backend()
    be.server_handle = object()  # no ``request_outbound`` attribute
    assert _resolve_outbound_channel(be, "sid") is None


def test_resolve_outbound_channel_none_when_nothing_wired():
    assert _resolve_outbound_channel(_backend(), "sid") is None


# ---- AcpServer bind/unbind across the session lifecycle -------------


def test_acpserver_binds_on_session_new():
    srv, be = _make_server()
    result = asyncio.run(
        srv._handle_session_new({"cwd": "/tmp", "mcpServers": []})
    )
    sid = result["sessionId"]
    assert be.bound.get(sid) is srv
    assert sid in srv._bound_sessions


def test_acpserver_binds_on_session_load():
    srv, be = _make_server()
    asyncio.run(
        srv._handle_session_load(
            {"sessionId": "sid-loaded", "cwd": "/tmp", "mcpServers": []}
        )
    )
    assert be.bound.get("sid-loaded") is srv
    assert "sid-loaded" in srv._bound_sessions


def test_acpserver_unbinds_on_session_close():
    srv, be = _make_server()
    result = asyncio.run(
        srv._handle_session_new({"cwd": "/tmp", "mcpServers": []})
    )
    sid = result["sessionId"]
    asyncio.run(srv._handle_session_close({"sessionId": sid}))
    assert sid not in be.bound
    assert sid not in srv._bound_sessions


def test_acpserver_teardown_unbinds_all():
    """``serve_until_close``'s finally block must drop every binding so
    a dead connection can't keep routing prompts to a stale server."""
    srv, be = _make_server()
    asyncio.run(srv._handle_session_new({"cwd": "/tmp", "mcpServers": []}))
    asyncio.run(srv._handle_session_new({"cwd": "/tmp", "mcpServers": []}))
    assert len(be.bound) == 2 and len(srv._bound_sessions) == 2
    # _EofTransport drives the read loop straight to its teardown.
    asyncio.run(srv.serve_until_close())
    assert be.bound == {}
    assert srv._bound_sessions == set()


# ---- classifier: git branch -d / -D stay destructive ---------------


@pytest.mark.parametrize(
    "cmd",
    [
        "git branch -d feature_x",
        "git branch -D feature_x",
        "cd ~/src/rtxclaw && git branch -d fix_20260514",
    ],
)
def test_git_branch_delete_is_destructive(cmd):
    assert classify_command(cmd) is CommandSafety.DESTRUCTIVE
