"""Step 65 — inline AskUserQuestion transcript widget.

The TUI's ``QuestionsModal`` (popped from ``AgentChatApp._on_ask_user``)
collects the operator's pick and dismisses, leaving zero record on the
transcript of what was asked or chosen. This step adds an inline
``AskUserQuestionMessage`` widget — same pattern as ``PlanMessage``
(ExitPlanMode) and ``UpdateMessage`` (Edit/Update) — mounted on the
transcript right before the modal pops, then stamped via
``mark_answered`` / ``mark_cancelled`` from the modal's return.

These tests pin the widget contract only — pure constructor + helper
methods, no Textual app mount required (mirrors
``test_57_update_tool_diff_widget.py``).
"""
from __future__ import annotations

import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


# ---- header ---------------------------------------------------------


def test_header_reflects_pending_then_answered_then_cancelled() -> None:
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage(
        [
            {"header": "Auth", "question": "How?", "options": [
                {"label": "OAuth", "description": "sso"},
                {"label": "Token", "description": "header"},
            ]},
        ]
    )
    assert card._build_header() == "❓ AskUserQuestion — 1 question · waiting…"
    card.mark_answered({"answers": [{"selected": ["OAuth"], "notes": ""}]})
    assert card._build_header() == "✅ AskUserQuestion — 1 question · answered"
    card.mark_cancelled()
    assert card._build_header().startswith("✗ AskUserQuestion")
    assert "cancelled" in card._build_header()


def test_header_pluralises_count() -> None:
    from rtxclaw_tui.app import AskUserQuestionMessage

    one = AskUserQuestionMessage([{"question": "a", "options": []}])
    two = AskUserQuestionMessage([
        {"question": "a", "options": []},
        {"question": "b", "options": []},
    ])
    assert "1 question " in one._build_header()
    assert "2 questions " in two._build_header()


# ---- mark_answered --------------------------------------------------


def test_mark_answered_flips_state_and_keeps_answer_strings() -> None:
    """``mark_answered`` must capture the selected labels and the
    operator's free-form notes, in the order the questions were
    asked. The card itself isn't mounted under a running App in this
    test, so the per-question ``Static`` placeholders for the answer
    line live on ``card._answer_statics`` but their ``renderable`` is
    only populated once :meth:`compose` runs under Textual — what we
    DO pin here is the state flag + the parsed answers structure,
    which downstream Telegram/log replays rely on."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage(
        [
            {"question": "Q1", "options": [{"label": "yes"}, {"label": "no"}]},
            {"question": "Q2", "options": [{"label": "a"}, {"label": "b"}]},
        ]
    )
    assert card._state is None
    card.mark_answered(
        {
            "answers": [
                {"selected": ["yes"], "notes": "with caveats"},
                {"selected": ["a", "b"], "notes": ""},
            ]
        }
    )
    assert card._state is True


def test_mark_answered_tolerates_missing_and_malformed_entries() -> None:
    """A buggy QuestionsModal (or a wire-shape mismatch) must NOT
    crash the transcript. Missing answers and non-dict entries fall
    through to a "(no selection)" body so the operator can see that
    something went wrong without losing the rest of the turn."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage(
        [
            {"question": "Q1", "options": []},
            {"question": "Q2", "options": []},
            {"question": "Q3", "options": []},
        ]
    )
    # Only one answer; second is non-dict; third is missing.
    card.mark_answered(
        {"answers": [{"selected": ["yep"], "notes": ""}, "garbage"]}
    )
    assert card._state is True


def test_mark_answered_handles_none_and_empty_result() -> None:
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage([{"question": "Q1", "options": []}])
    # Bridge sometimes returns None on a torn-down client.
    card.mark_answered(None)  # type: ignore[arg-type]
    assert card._state is True


# ---- mark_cancelled ------------------------------------------------


def test_mark_cancelled_sets_state_false() -> None:
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage([{"question": "Q1", "options": []}])
    card.mark_cancelled()
    assert card._state is False
    # Header reflects the cancel.
    assert "cancelled" in card._build_header()


# ---- construction defensive copying --------------------------------


def test_constructor_filters_non_dict_questions() -> None:
    """``acp_bridge`` validates the shape but a forward-compat run
    against an older agent could still hand us garbage. The
    constructor drops non-dict entries so the rest of the card
    renders rather than crashing on a single bad question."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage([
        {"question": "ok", "options": []},
        "not a dict",  # type: ignore[list-item]
        42,  # type: ignore[list-item]
    ])
    assert len(card._questions) == 1


def test_empty_questions_does_not_crash() -> None:
    from rtxclaw_tui.app import AskUserQuestionMessage

    card = AskUserQuestionMessage([])
    assert card._questions == []
    # Header still rendered cleanly (the wire path short-circuits
    # before we'd be invoked, but defense-in-depth: the widget itself
    # mustn't blow up on an empty list).
    assert "0 questions" in card._build_header()


# ---- mounted-lifecycle (run_test) ----------------------------------

# The pure-constructor tests above pin the model layer but never
# exercise Textual's compose / mount lifecycle. The widget's whole
# point is rendering — the failure modes that actually matter
# (compose-time ``display = False`` not surviving mount, the answer
# Statics not actually unhiding when ``mark_answered`` flips
# ``display = True``, the ``askq-msg-cancelled`` class not propagating
# to descendant CSS rules) only surface under a real mount. These two
# tests mount the widget under ``App.run_test()`` and assert on
# rendered state — same pattern as Textual's own widget tests.


def _run_mounted(test_coro) -> None:
    """Boilerplate harness: spin up a minimal App with a
    VerticalScroll, await ``test_coro(pilot, transcript)``. Kept inline
    rather than as a fixture so the test file stays single-import."""
    import asyncio
    from textual.app import App, ComposeResult
    from textual.containers import VerticalScroll

    class _Probe(App):
        def compose(self) -> ComposeResult:
            yield VerticalScroll(id="t")

    async def _runner():
        async with _Probe().run_test() as pilot:
            t = pilot.app.query_one("#t", VerticalScroll)
            await test_coro(pilot, t)

    asyncio.run(_runner())


def test_widget_mounts_and_hides_answer_statics_in_pending_state() -> None:
    """Verifies the ``display = False`` set inside ``compose()``
    survives mount. If Textual ever stops honoring pre-mount display
    state, this test fails BEFORE the widget ships a regression to
    the operator (who would otherwise see empty answer lines stacked
    under every pending question)."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    async def _check(pilot, t):
        card = AskUserQuestionMessage([
            {"header": "Auth", "question": "How?", "options": [
                {"label": "OAuth", "description": "sso"},
                {"label": "Token"},
            ]},
        ])
        await t.mount(card)
        await pilot.pause()
        # Compose ran, the per-question answer Static exists.
        assert len(card._answer_statics) == 1
        # And it's hidden in pending state — the load-bearing
        # assertion this whole test exists for.
        assert card._answer_statics[0].display is False

    _run_mounted(_check)


def test_mark_answered_reveals_answer_line_with_selection_and_notes() -> None:
    """End-to-end check: post-mount, ``mark_answered`` must (a) flip
    each answer Static's ``display`` to True, and (b) render the
    "→ selected: …" + notes line. The pure-constructor tests miss
    both — they only verify the parsed result lands on the widget,
    not that the operator actually SEES it."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    async def _check(pilot, t):
        card = AskUserQuestionMessage([
            {"header": "Auth", "question": "How?", "options": [{"label": "OAuth"}]},
            {"header": "Tests", "question": "Which?", "multiSelect": True, "options": [
                {"label": "unit"}, {"label": "e2e"},
            ]},
        ])
        await t.mount(card)
        await pilot.pause()
        card.mark_answered({"answers": [
            {"selected": ["OAuth"], "notes": "with PKCE"},
            {"selected": ["unit", "e2e"], "notes": ""},
        ]})
        await pilot.pause()
        # Both answer Statics now visible.
        assert all(a.display for a in card._answer_statics)
        # And the rendered text carries the operator's choices.
        body0 = str(card._answer_statics[0].render())
        assert "OAuth" in body0
        assert "with PKCE" in body0
        body1 = str(card._answer_statics[1].render())
        assert "unit" in body1
        assert "e2e" in body1
        # The notes line is OMITTED when the operator left it blank
        # (the pure-constructor tests can't see this — only the
        # rendered text does).
        assert "notes:" not in body1

    _run_mounted(_check)


def test_mark_cancelled_applies_class_under_mount() -> None:
    """Verifies ``set_class(True, 'askq-msg-cancelled')`` actually
    propagates to the descendant CSS rules
    (``.askq-msg-cancelled .askq-msg-header``). The constructor-only
    tests can't see this — only a live mount can."""
    from rtxclaw_tui.app import AskUserQuestionMessage

    async def _check(pilot, t):
        card = AskUserQuestionMessage([{"question": "Q1", "options": []}])
        await t.mount(card)
        await pilot.pause()
        assert not card.has_class("askq-msg-cancelled")
        card.mark_cancelled()
        await pilot.pause()
        assert card.has_class("askq-msg-cancelled")
        # Header text follows the state flip.
        assert "cancelled" in card._build_header()

    _run_mounted(_check)
