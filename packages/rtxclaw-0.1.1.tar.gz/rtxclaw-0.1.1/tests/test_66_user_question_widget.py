"""Step 66 — inline UserQuestion transcript widget.

``UserQuestion`` (``rtxclaw_core.tools.registry``) is the local
agent's clarifying-question tool: single question + 2–4 options,
async-by-text (the model issues the question, ends its turn, and the
operator's next chat message is interpreted as the answer). Without
a dedicated widget the call lands as a ``🔧 UserQuestion
{"question": ..., "options": [...]}`` pill plus a collapsed echo
peek — operators reported "I can't tell what the model is asking".

This widget mounts on the transcript when the tool fires, rendering
the question + numbered options + an explicit "agent is waiting"
hint. The matching tool_result (a markdown echo from the runner) is
suppressed on success in the tool dispatch so the operator sees one
clean card, not card + redundant Collapsible.

Pure-constructor + mounted-lifecycle tests below — mirrors
``test_57_update_tool_diff_widget.py`` /
``test_65_ask_user_question_widget.py``. No live LLM needed.
"""
from __future__ import annotations

import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


# ---- construction --------------------------------------------------


def test_constructor_extracts_question_and_options() -> None:
    from rtxclaw_tui.app import UserQuestionMessage

    card = UserQuestionMessage({
        "question": "What's your favorite color?",
        "options": [
            {"label": "Red", "description": "Bold and energetic"},
            {"label": "Blue", "description": "Calm and cool"},
            {"label": "Green", "description": "Fresh and natural"},
        ],
    })
    assert card._question == "What's your favorite color?"
    assert len(card._options) == 3
    assert card._options[0]["label"] == "Red"


def test_constructor_filters_non_dict_options() -> None:
    """A buggy model could emit garbage in the options list. The
    constructor drops non-dict entries so the rest of the card renders
    rather than crashing on a single malformed option."""
    from rtxclaw_tui.app import UserQuestionMessage

    card = UserQuestionMessage({
        "question": "Q?",
        "options": [
            {"label": "ok"},
            "not a dict",  # type: ignore[list-item]
            42,  # type: ignore[list-item]
            {"label": "also ok", "description": "yes"},
        ],
    })
    assert len(card._options) == 2


def test_constructor_handles_none_and_missing_keys() -> None:
    """Defense-in-depth: the dispatcher passes ``args_for_widget``
    which could be None on a malformed tool_call frame. The widget
    must construct cleanly rather than blowing up the transcript."""
    from rtxclaw_tui.app import UserQuestionMessage

    a = UserQuestionMessage(None)  # type: ignore[arg-type]
    assert a._question == ""
    assert a._options == []

    b = UserQuestionMessage({})
    assert b._question == ""
    assert b._options == []

    c = UserQuestionMessage({"question": "  spaces  "})
    assert c._question == "spaces"  # stripped
    assert c._options == []


def test_constructor_handles_non_list_options() -> None:
    from rtxclaw_tui.app import UserQuestionMessage

    card = UserQuestionMessage({
        "question": "Q?",
        "options": "not a list",  # type: ignore[dict-item]
    })
    assert card._options == []


# ---- mounted rendering ---------------------------------------------

# These pin the operator-visible behavior under Textual's real
# compose/mount lifecycle — the constructor tests above can't see the
# rendered text, only the parsed model fields. The widget's whole
# point is rendering, so the integration test is load-bearing.


def _run_mounted(test_coro) -> None:
    import asyncio
    from textual.app import App, ComposeResult
    from textual.containers import VerticalScroll

    class _Probe(App):
        def compose(self) -> ComposeResult:
            yield VerticalScroll(id="t")

    async def _runner():
        async with _Probe().run_test() as pilot:
            t = pilot.app.query_one("#t", VerticalScroll)
            await test_coro(pilot, t)

    asyncio.run(_runner())


def test_mounted_render_includes_question_options_and_hint() -> None:
    """The card must render: the header (warning-colored, names the
    state), the question text verbatim, every option numbered with
    its description, and a hint line telling the operator to type
    their reply. All four are load-bearing for the UX — missing any
    of them means the operator can't actually use the question."""
    from rtxclaw_tui.app import UserQuestionMessage

    async def _check(pilot, t):
        card = UserQuestionMessage({
            "question": "Pick a framework",
            "options": [
                {"label": "pytest", "description": "modern"},
                {"label": "unittest"},
            ],
        })
        await t.mount(card)
        await pilot.pause()
        # Pull all rendered Static text out of the card's children.
        from textual.widgets import Static
        statics = [s for s in card.query(Static)]
        rendered = "\n".join(str(s.render()) for s in statics)
        # Header present.
        assert "User question" in rendered
        assert "waiting" in rendered
        # Question text verbatim.
        assert "Pick a framework" in rendered
        # Numbered options + description for the one that has it.
        assert "1. pytest — modern" in rendered
        # Option without description renders WITHOUT the em-dash.
        assert "2. unittest" in rendered
        assert "2. unittest —" not in rendered
        # Hint line tells the operator what to do.
        assert "reply with your choice" in rendered

    _run_mounted(_check)


def test_mounted_render_with_no_options_does_not_crash() -> None:
    """Edge case — model emits ``UserQuestion`` with empty options.
    The tool runner will reject this with a validation error, but the
    widget mounts BEFORE the runner result lands, so the card must
    not crash on a degenerate options list."""
    from rtxclaw_tui.app import UserQuestionMessage

    async def _check(pilot, t):
        card = UserQuestionMessage({"question": "Q?", "options": []})
        await t.mount(card)
        await pilot.pause()
        from textual.widgets import Static
        rendered = "\n".join(
            str(s.render()) for s in card.query(Static)
        )
        # Placeholder text in lieu of a real options list — operator
        # can still read the question and reply freely.
        assert "(no options)" in rendered
        assert "Q?" in rendered

    _run_mounted(_check)


def test_mounted_render_with_missing_question_shows_placeholder() -> None:
    from rtxclaw_tui.app import UserQuestionMessage

    async def _check(pilot, t):
        card = UserQuestionMessage({"options": [{"label": "yes"}]})
        await t.mount(card)
        await pilot.pause()
        from textual.widgets import Static
        rendered = "\n".join(
            str(s.render()) for s in card.query(Static)
        )
        assert "(no question text)" in rendered

    _run_mounted(_check)


def test_mounted_card_has_warning_class_for_styling() -> None:
    """CSS hook check — the outer Vertical must carry the ``userq-msg``
    class so the surrounding ``.userq-msg`` / ``.userq-msg-header``
    rules apply (warning border, bold header)."""
    from rtxclaw_tui.app import UserQuestionMessage

    async def _check(pilot, t):
        card = UserQuestionMessage({"question": "?", "options": []})
        await t.mount(card)
        await pilot.pause()
        assert card.has_class("userq-msg")

    _run_mounted(_check)
