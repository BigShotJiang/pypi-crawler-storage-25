"""Tests for the bash hook wrapper. Runs the script with a stubbed
``claude`` binary on PATH so no real Claude call is made."""
import json
import os
import stat
import subprocess
import textwrap
from pathlib import Path

import pytest

SCRIPT_SRC = Path(__file__).resolve().parents[1] / "assets" / "self-improver" / "self-improver.sh"


@pytest.fixture
def stage(tmp_path, monkeypatch):
    """Install the wrapper + a fake claude binary + a fake RTXCLAW_HOME."""
    rtxhome = tmp_path / "rtxhome"
    src_repo = tmp_path / "src" / "rtxclaw"
    bin_dir = tmp_path / "bin"
    (rtxhome / "self-improver" / "logs").mkdir(parents=True)
    (rtxhome / "self-improver" / "runs").mkdir(parents=True)
    (rtxhome / "self-improver" / "queue").mkdir(parents=True)
    (rtxhome / "scripts").mkdir(parents=True)
    (src_repo / "scripts").mkdir(parents=True)
    bin_dir.mkdir(parents=True)

    # Install the script under test.
    dst = rtxhome / "scripts" / "self-improver.sh"
    dst.write_text(SCRIPT_SRC.read_text())
    dst.chmod(0o755)

    # Ship a minimal repo prompt so the resolver finds it.
    (src_repo / "scripts" / "self-improver-prompt.md").write_text(
        "Prompt placeholders: {session_id} {event} {transcript_path} {agent_name}"
    )

    # Stub claude: records argv + stdin to a marker file.
    marker = tmp_path / "claude.call"
    fake = bin_dir / "claude"
    fake.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env bash
        echo "ARGS: $*" >> {marker}
        cat >> {marker}
        echo "STDIN-END" >> {marker}
    """))
    fake.chmod(0o755)

    monkeypatch.setenv("PATH", f"{bin_dir}:{os.environ['PATH']}")
    monkeypatch.setenv("RTXCLAW_HOME", str(rtxhome))
    monkeypatch.setenv("RTXCLAW_SOURCE_DIR", str(src_repo))
    return {
        "rtxhome": rtxhome, "src_repo": src_repo, "wrapper": dst, "marker": marker,
        "bin_dir": bin_dir,
    }


def _hook_payload(session_id="sess1", agent_name="main", extra=None):
    p = {
        "hook_event_name": "ReasoningLoopDetected",
        "session_id": session_id,
        "transcript_path": "/dev/null",
        "cwd": "/tmp",
        "permission_mode": "auto",
        "agent_name": agent_name,
    }
    if extra:
        p.update(extra)
    return json.dumps(p)


def test_wrapper_is_executable(stage):
    assert stage["wrapper"].stat().st_mode & stat.S_IXUSR


def test_wrapper_spawns_claude_with_prompt_for_first_event(stage):
    proc = subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=_hook_payload(),
        text=True, capture_output=True, timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    marker = stage["marker"]
    for _ in range(20):
        if marker.exists():
            break
        import time; time.sleep(0.1)
    assert marker.exists(), "wrapper did not spawn claude"
    contents = marker.read_text()
    assert "-p" in contents, "claude must be invoked with -p"
    assert "Prompt placeholders: sess1 reasoning-loop /dev/null main" in contents, (
        f"prompt templating broken; got: {contents!r}"
    )


def test_wrapper_records_run_marker_for_rate_cap(stage):
    subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=_hook_payload(), text=True, capture_output=True, timeout=10,
    )
    runs_dir = stage["rtxhome"] / "self-improver" / "runs"
    assert any(runs_dir.iterdir()), "wrapper must record a run marker"


def test_wrapper_drops_when_rate_cap_exceeded(stage):
    # Pre-populate 10 fresh run markers.
    runs_dir = stage["rtxhome"] / "self-improver" / "runs"
    import time
    for i in range(10):
        (runs_dir / f"run-{i}").write_text("x")
    assert not stage["marker"].exists()
    proc = subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=_hook_payload(), text=True, capture_output=True, timeout=10,
    )
    assert proc.returncode == 0
    time.sleep(0.5)
    assert not stage["marker"].exists(), "wrapper must skip spawn when cap is hit"
    # Drop is recorded in wrapper.log (forensic record), but the queue
    # dir stays empty — there's no drain, so writing files there would
    # be a leak. The cold-path scanner picks the session up later.
    log_path = stage["rtxhome"] / "self-improver" / "logs" / "wrapper.log"
    assert log_path.exists() and "rate-cap" in log_path.read_text(), (
        "rate-cap drop must be logged"
    )
    queue_dir = stage["rtxhome"] / "self-improver" / "queue"
    assert not any(queue_dir.iterdir() if queue_dir.exists() else []), (
        "wrapper must NOT write dead-letter queue files (cold scanner "
        "recovers missed sessions)"
    )


def test_wrapper_drops_when_lock_held(stage):
    """Second wrapper invocation while the first holds the lock must
    drop and exit 0 — no concurrent claude spawn, no dead-letter
    queue file."""
    lock = stage["rtxhome"] / "self-improver" / "lock"
    lock.touch()
    import fcntl, os
    fd = os.open(str(lock), os.O_RDWR | os.O_CREAT)
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        proc = subprocess.run(
            [str(stage["wrapper"]), "reasoning-loop"],
            input=_hook_payload(), text=True, capture_output=True, timeout=10,
        )
        assert proc.returncode == 0
        import time; time.sleep(0.3)
        assert not stage["marker"].exists()
        log_path = stage["rtxhome"] / "self-improver" / "logs" / "wrapper.log"
        assert log_path.exists() and "lock held" in log_path.read_text(), (
            "lock-held drop must be logged"
        )
        queue_dir = stage["rtxhome"] / "self-improver" / "queue"
        assert not any(queue_dir.iterdir() if queue_dir.exists() else []), (
            "wrapper must NOT write dead-letter queue files"
        )
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def test_wrapper_lock_held_for_spawned_claude_lifetime(stage):
    """Bug #1 regression: after the wrapper exits, the spawned claude
    must keep the lock until *it* exits — not release it when the
    wrapper exits. Without this, RATE_CAP concurrent self-improvers
    could mutate the same worktree.

    Verified by:
      1. Replacing the stub claude with one that sleeps 2 seconds.
      2. Firing the wrapper.
      3. Immediately (within 0.5s of wrapper exit) attempting to take
         the lock from python via fcntl.flock(LOCK_EX | LOCK_NB).
         If the wrapper handed the lock to claude, this fails.
      4. Waiting until claude exits (~2s); then the lock acquires."""
    import fcntl, os, subprocess, time, textwrap

    # Slow stub claude — sleeps 2s before exiting.
    fake = stage["bin_dir"] / "claude"
    fake.write_text(textwrap.dedent("""\
        #!/usr/bin/env bash
        sleep 2
        exit 0
    """))
    fake.chmod(0o755)

    payload = '{"hook_event_name":"ReasoningLoopDetected","session_id":"lockid","transcript_path":"/dev/null","cwd":"/tmp","agent_name":"main"}'
    proc = subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=payload, text=True, capture_output=True, timeout=10,
    )
    assert proc.returncode == 0

    lock_path = stage["rtxhome"] / "self-improver" / "lock"
    # Wrapper has exited; claude (the sleep-2 stub) is still running.
    # The lock MUST still be held.
    fd = os.open(str(lock_path), os.O_RDWR)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            raise AssertionError(
                "lock was released when wrapper exited — child claude does "
                "not inherit fd 9 → second wrapper invocation would spawn "
                "a concurrent claude"
            )
        except BlockingIOError:
            pass  # expected — lock held by stub claude

        # Wait for the stub claude to exit (~2s). Lock should release.
        for _ in range(40):
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break  # acquired
            except BlockingIOError:
                time.sleep(0.1)
        else:
            raise AssertionError("lock never released even after claude exited")
        fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def test_wrapper_substitutes_src_dir_and_rtxclaw_home_in_prompt(stage):
    """Bug #5 regression: prompt template must NOT contain hardcoded
    /home/jcooloj/ paths. The wrapper substitutes {src_dir} and
    {rtxclaw_home} placeholders at templating time so the same
    prompt file works on any user's host."""
    import time
    # Replace the staged prompt with one that uses the new placeholders.
    (stage["src_repo"] / "scripts" / "self-improver-prompt.md").write_text(
        "src={src_dir} home={rtxclaw_home} sess={session_id} ev={event}"
    )
    payload = '{"hook_event_name":"ReasoningLoopDetected","session_id":"sess-paths","transcript_path":"/dev/null","cwd":"/tmp","agent_name":"main"}'
    proc = subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=payload, text=True, capture_output=True, timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    for _ in range(20):
        if stage["marker"].exists():
            break
        time.sleep(0.1)
    contents = stage["marker"].read_text()
    assert f"src={stage['src_repo']} home={stage['rtxhome']}" in contents, (
        f"path placeholders not substituted; got: {contents!r}"
    )


def test_wrapper_prompt_has_no_hardcoded_home_jcooloj_paths():
    """Bug #5 regression: the committed prompt file must not embed any
    user-specific absolute paths."""
    from pathlib import Path
    repo_root = Path(__file__).resolve().parents[1]
    body = (repo_root / "scripts" / "self-improver-prompt.md").read_text()
    assert "/home/jcooloj" not in body, (
        "prompt embeds hardcoded /home/jcooloj path — use {src_dir} / "
        "{rtxclaw_home} placeholders instead"
    )


def test_wrapper_invokes_claude_without_unsupported_cwd_flag(stage):
    """Regression: the wrapper must NOT pass ``--cwd`` to ``claude``.

    The real ``claude`` CLI has no ``--cwd`` option — it errors out with
    ``error: unknown option '--cwd'`` and exits before doing any work.
    On 2026-05-21 every self-improver spawn died this way (87 zero-byte
    runs, never once functioned). The working directory must instead be
    set by ``cd``-ing into ``$SRC_DIR`` before exec'ing claude.

    The default stub claude swallows any argv, so it can't catch this.
    Here we record both argv AND the process cwd, then assert:
      * ``--cwd`` is absent from argv, and
      * claude actually ran with cwd == $SRC_DIR.
    """
    import time
    # Strict stub: records argv + its own working directory.
    fake = stage["bin_dir"] / "claude"
    marker = stage["marker"]
    fake.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env bash
        echo "ARGS: $*" >> {marker}
        echo "PWD: $PWD" >> {marker}
    """))
    fake.chmod(0o755)

    payload = ('{"hook_event_name":"ReasoningLoopDetected",'
               '"session_id":"sess-cwd","transcript_path":"/dev/null",'
               '"cwd":"/tmp","agent_name":"main"}')
    proc = subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=payload, text=True, capture_output=True, timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    for _ in range(20):
        if marker.exists():
            break
        time.sleep(0.1)
    assert marker.exists(), "wrapper did not spawn claude"
    contents = marker.read_text()
    assert "--cwd" not in contents, (
        f"wrapper passed unsupported --cwd flag to claude; got: {contents!r}"
    )
    assert f"PWD: {stage['src_repo']}" in contents, (
        f"claude did not run with cwd == $SRC_DIR; got: {contents!r}"
    )


def test_wrapper_records_dirty_prompt_version_when_uncommitted_edits_exist(stage):
    """Bug #9 regression: PROMPT_VER must tag dirty when the repo
    prompt file has uncommitted modifications, so sidecar forensics
    can tell apart 'fingerprint X under prompt Y' from 'fingerprint
    X under prompt Y-modified-but-not-committed'."""
    import time

    # Init src_repo as a git repo and commit the prompt, then modify it.
    src = stage["src_repo"]
    subprocess.run(["git", "init", "-q", "-b", "main", str(src)], check=True)
    subprocess.run(["git", "-C", str(src), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(src), "config", "user.name", "t"], check=True)
    subprocess.run(["git", "-C", str(src), "add", "."], check=True)
    subprocess.run(["git", "-C", str(src), "commit", "-q", "-m", "init"], check=True)
    # Modify the prompt without committing.
    (src / "scripts" / "self-improver-prompt.md").write_text(
        "DIRTIED placeholders: {session_id}"
    )

    # The wrapper logs prompt_version into wrapper.log when it spawns.
    payload = '{"hook_event_name":"ReasoningLoopDetected","session_id":"sess-dirty","transcript_path":"/dev/null","cwd":"/tmp","agent_name":"main"}'
    subprocess.run(
        [str(stage["wrapper"]), "reasoning-loop"],
        input=payload, text=True, capture_output=True, timeout=10,
    )
    # Wait for the spawn log line.
    log_path = stage["rtxhome"] / "self-improver" / "logs" / "wrapper.log"
    for _ in range(20):
        if log_path.exists() and "spawned" in log_path.read_text():
            break
        time.sleep(0.1)
    log_body = log_path.read_text()
    assert "+dirty" in log_body, (
        f"PROMPT_VER did not include '+dirty' tag despite uncommitted "
        f"edits to scripts/self-improver-prompt.md. wrapper.log:\n{log_body}"
    )
