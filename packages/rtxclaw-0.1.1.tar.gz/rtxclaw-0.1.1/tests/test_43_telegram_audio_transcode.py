"""Step 43 — Telegram OGG/Opus → MP3 transcode pipeline.

Telegram voice notes always arrive as ``audio/ogg`` (Opus codec in an
OGG container). OpenRouter's ``gpt-4o-transcribe`` rejects Opus on the
wire, so the bot has to re-encode the audio to MP3 before the STT
upload. The previous codepath called ``shutil.which("ffmpeg")`` and
silently degraded to "STT skipped" when the operator hadn't installed
ffmpeg system-wide — which is what was happening in production: the
ENV bootstrap (test_42) wired ``OPENROUTER_API_KEY`` correctly but the
transcode step never ran.

The fix declares ``imageio-ffmpeg`` (a wheel that ships a static
ffmpeg binary) in ``src/requirements.txt`` and adds
``_resolve_ffmpeg`` so the transcoder prefers PATH ffmpeg and falls
back to the bundled one. This file pins:

* ``_resolve_ffmpeg`` returns a usable absolute path (PATH or bundled).
* ``_transcode_to_mp3`` accepts real OGG/Opus bytes and produces a MP3
  payload whose header looks valid (ID3 or MPEG sync).
* End-to-end with a synthesized sine-wave OGG so we don't need a
  vendored binary blob in the test tree.

The test skips cleanly if no ffmpeg can be located at all (i.e.
imageio-ffmpeg isn't installed AND the system has no ffmpeg) — that
state is itself a runtime warning the operator should see.
"""
from __future__ import annotations

import subprocess

import pytest

from rtxclaw_telegram.bot import _resolve_ffmpeg, _transcode_to_mp3


@pytest.fixture(scope="module")
def ffmpeg_path() -> str:
    """Where do we get ffmpeg from? Skip if neither source exists —
    that means the install / venv hasn't picked up the
    imageio-ffmpeg dependency yet, which is its own bug to surface
    via skip-not-pass."""
    p = _resolve_ffmpeg()
    if not p:
        pytest.skip(
            "no ffmpeg available — install imageio-ffmpeg "
            "(in src/requirements.txt) or apt install ffmpeg"
        )
    return p


@pytest.fixture(scope="module")
def synthesized_ogg(ffmpeg_path: str) -> bytes:
    """Generate a tiny OGG/Opus payload via ffmpeg's own ``lavfi``
    filter so we don't need a binary fixture file. Mirrors the
    on-the-wire shape of a Telegram voice note."""
    proc = subprocess.run(
        [
            ffmpeg_path, "-loglevel", "error",
            "-f", "lavfi", "-i", "sine=frequency=440:duration=0.5",
            "-c:a", "libopus", "-f", "ogg", "pipe:1",
        ],
        capture_output=True,
    )
    if proc.returncode != 0 or not proc.stdout:
        pytest.skip(
            f"local ffmpeg can't synthesize OGG/Opus "
            f"(rc={proc.returncode} stderr={proc.stderr[:200]!r})"
        )
    # OGG container magic is "OggS"; sanity-check.
    assert proc.stdout[:4] == b"OggS", (
        f"synthesized payload isn't OGG: {proc.stdout[:8]!r}"
    )
    return proc.stdout


def test_resolve_ffmpeg_returns_usable_path(ffmpeg_path: str) -> None:
    """Whatever ``_resolve_ffmpeg`` returns has to be a working
    binary, not just a path. Run ``-version`` to confirm."""
    out = subprocess.run(
        [ffmpeg_path, "-version"], capture_output=True, timeout=10,
    )
    assert out.returncode == 0, (
        f"resolved ffmpeg at {ffmpeg_path!r} but "
        f"-version failed (rc={out.returncode}, "
        f"stderr={out.stderr[:200]!r})"
    )
    assert b"ffmpeg version" in out.stdout, (
        f"output doesn't look like ffmpeg: {out.stdout[:100]!r}"
    )


def test_transcode_ogg_opus_to_mp3(synthesized_ogg: bytes) -> None:
    """End-to-end: real OGG/Opus bytes go in, valid MP3 comes out.

    The bug-on-prod was ``_transcode_to_mp3`` returning ``None``
    because ``shutil.which("ffmpeg")`` was empty. With the fix in
    place we get a real MP3 back."""
    mp3 = _transcode_to_mp3(synthesized_ogg)
    assert mp3 is not None, (
        "transcode returned None — ffmpeg likely missing "
        "(install imageio-ffmpeg via src/requirements.txt)"
    )
    assert len(mp3) > 100, (
        f"transcoded payload is too small to be a real MP3: "
        f"{len(mp3)} bytes"
    )
    # Either ID3v2 tag ("ID3") or a raw MPEG sync word (0xFF 0xFB-ish).
    # libmp3lame produces ID3 by default; accept the MPEG sync as
    # well in case the encoder config changes.
    head = mp3[:3]
    assert head == b"ID3" or (
        len(mp3) >= 2 and mp3[0] == 0xFF and (mp3[1] & 0xE0) == 0xE0
    ), f"mp3 header doesn't look right: {head!r} / {mp3[:4]!r}"


def test_transcode_returns_none_on_garbage_input() -> None:
    """A non-audio payload should fail cleanly with ``None`` instead
    of crashing the bot's voice handler. The handler treats ``None``
    as "STT skipped" and surfaces a friendly user-facing reply."""
    result = _transcode_to_mp3(b"this is not audio at all")
    assert result is None, (
        f"transcode of garbage should be None, got {len(result)} bytes"
    )
