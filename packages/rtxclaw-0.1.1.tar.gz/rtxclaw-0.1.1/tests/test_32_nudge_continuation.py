"""Step 32 — Continuation-nudge policy.

Background: small models (qwen3.6-class) sometimes drop EOS after a
tool chain without writing any user-visible summary. Operators see a
silent end and have to type ``status`` to discover what happened. The
bridge re-prompts the model up to ``MAX_NUDGES_PER_TURN`` times asking
it to either finish the task or summarize, with hard caps so a
non-compliant model can't loop the agent.

These tests pin the pure decision function so a future refactor can't
silently flip the policy. Integration coverage (the actual injection
into the message list + persistence onto the session record) lives
under the live-LLM smoke tests; this file is the policy contract.
"""
from __future__ import annotations

import pytest

from rtxclaw_core.agents.local_llm import (
    MAX_NUDGES_PER_TURN,
    NUDGE_MIN_TEXT_CHARS,
    NUDGE_PROMPT_BODY,
    _detect_colon_cliffhanger,
    _detect_content_cutoff,
    _should_nudge,
)


# ---- baseline -----------------------------------------------------


def _base_kwargs(**overrides):
    """Return a kwargs dict that fires the nudge by default. Tests
    override one knob at a time so the failure surface is one bit."""
    out = dict(
        final_text_chars=0,
        tool_rounds_so_far=3,
        nudge_count=0,
        cancelled=False,
        terminate_reason="end_turn",
        silent_chain=False,
    )
    out.update(overrides)
    return out


def test_baseline_fires() -> None:
    assert _should_nudge(**_base_kwargs()) is True


# ---- positive cases -----------------------------------------------


def test_fires_with_terminate_reason_none() -> None:
    """Worker died without explicit terminate event — still treat as
    a natural stop and nudge."""
    assert _should_nudge(**_base_kwargs(terminate_reason=None)) is True


def test_fires_under_text_threshold() -> None:
    """Single-period summary is just whitespace dressing; nudge."""
    assert _should_nudge(**_base_kwargs(final_text_chars=NUDGE_MIN_TEXT_CHARS - 1)) is True


def test_fires_at_first_attempt() -> None:
    assert _should_nudge(**_base_kwargs(nudge_count=0)) is True


def test_fires_at_attempt_below_cap() -> None:
    """First retry already burned, one more allowed."""
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN - 1)) is True


# ---- negative cases -----------------------------------------------


def test_blocks_when_no_tool_rounds() -> None:
    """First-round empty stop is a different bug — no tools fired,
    so this isn't the 'silent after tool chain' shape."""
    assert _should_nudge(**_base_kwargs(tool_rounds_so_far=0)) is False


def test_blocks_when_text_at_threshold() -> None:
    """``NUDGE_MIN_TEXT_CHARS`` is inclusive on the upper side — the
    value itself is enough text to count as a summary."""
    assert _should_nudge(**_base_kwargs(final_text_chars=NUDGE_MIN_TEXT_CHARS)) is False


def test_blocks_when_text_well_above_threshold() -> None:
    assert _should_nudge(**_base_kwargs(final_text_chars=500)) is False


def test_blocks_at_cap() -> None:
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN)) is False


def test_blocks_above_cap() -> None:
    """Defensive: if state ever gets out of sync, never go past cap."""
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN + 1)) is False


def test_blocks_when_cancelled() -> None:
    """User pressed ESC — never override their cancel with a nudge."""
    assert _should_nudge(**_base_kwargs(cancelled=True)) is False


def test_blocks_on_max_tokens_terminate() -> None:
    """Model hit the token budget; it didn't choose to stop. Nudging
    would just consume more tokens it doesn't have."""
    assert _should_nudge(**_base_kwargs(terminate_reason="max_tokens")) is False


def test_blocks_on_refusal_terminate() -> None:
    """Model declined for safety reasons — don't badger it."""
    assert _should_nudge(**_base_kwargs(terminate_reason="refusal")) is False


def test_blocks_on_cancelled_terminate() -> None:
    """Cancellation already terminated the worker — don't restart."""
    assert _should_nudge(**_base_kwargs(terminate_reason="cancelled")) is False


def test_blocks_after_silent_chain() -> None:
    """Two silent rounds in a row → abort. A model that won't talk
    after a nudge isn't going to start talking on the second nudge."""
    assert _should_nudge(**_base_kwargs(silent_chain=True)) is False


# ---- constants ----------------------------------------------------


def test_max_nudges_is_bounded_low() -> None:
    """Hard cap must stay tight — 5+ would be a runaway loop. 1-3 is
    the survivable range."""
    assert 1 <= MAX_NUDGES_PER_TURN <= 3


def test_min_text_chars_is_reasonable() -> None:
    """Threshold must allow a one-word answer like 'done.' through
    but reject pure whitespace. 5-25 chars is the sane range."""
    assert 5 <= NUDGE_MIN_TEXT_CHARS <= 25


def test_prompt_body_is_self_describing() -> None:
    """The injected message should be greppable in transcripts AND
    legible to the model — start with the rtxclaw tag."""
    assert NUDGE_PROMPT_BODY.startswith("[rtxclaw")
    assert "summari" in NUDGE_PROMPT_BODY.lower() or "finish" in NUDGE_PROMPT_BODY.lower()


def test_prompt_body_addresses_reasoning_only_stop() -> None:
    """qwen3-class models (live: 489 reasoning_tokens / 0 content
    tokens on a tool-using turn) dump the whole answer into the
    reasoning channel. The nudge has to explicitly tell the model
    (a) content vs reasoning is distinct and (b) not to start a new
    chain of thought — otherwise the model just emits MORE reasoning
    in response to the nudge and silently exits again."""
    body = NUDGE_PROMPT_BODY.lower()
    assert "content" in body, (
        "nudge must mention 'content' so the model knows reasoning "
        "tokens aren't user-visible"
    )
    assert "chain of thought" in body or "reasoning" in body, (
        "nudge must explicitly redirect away from another reasoning "
        "loop, otherwise qwen3 just dumps another <think> block"
    )


# ---- _detect_content_cutoff ---------------------------------------
#
# Regression tests for the windowing bug observed 2026-05-18: the
# detector counted backtick / triple-fence parity over a 500-char tail
# window. Long answers with Markdown tables or many inline-code spans
# routinely got the window sliced through a code-span pair, producing
# an odd count and a false-positive ``cutoff`` nudge. All 15
# ``NUDGE_FIRED`` events in the gateway log over 48h were
# ``kind=cutoff``, ~100% false positives. Fix: count fences and
# backticks over the FULL content; only the bracket check stays
# windowed (brackets are noisy in prose, full-count would over-fire).


def test_cutoff_clean_prose() -> None:
    """No code at all — must not fire."""
    assert _detect_content_cutoff(
        "All done. The report is at ~/reports/foo.md and the index "
        "is at ~/reports/README.md. Nothing else to do."
    ) is None


def test_cutoff_empty_input() -> None:
    """Empty / whitespace-only input is not 'mid-syntax', it's an
    empty round — the silent variant handles that case."""
    assert _detect_content_cutoff("") is None
    assert _detect_content_cutoff("   \n  \n") is None


def test_cutoff_balanced_inline_backticks() -> None:
    """Five balanced inline-code spans in one sentence — even count,
    must not fire."""
    assert _detect_content_cutoff(
        "Try `a`, `b`, `c`, `d` or `e` — any of them works."
    ) is None


def test_cutoff_balanced_triple_fence() -> None:
    """A closed code block — must not fire."""
    assert _detect_content_cutoff(
        "Here's the snippet:\n```bash\necho hello\n```\nThat's it."
    ) is None


def test_cutoff_unclosed_inline_backtick() -> None:
    """Real cutoff — single unclosed inline-code span at end. MUST fire."""
    tail = _detect_content_cutoff(
        "I wrote the code that handles the `expo-build flow"
    )
    assert tail is not None
    assert tail.endswith("flow")


def test_cutoff_unclosed_triple_fence() -> None:
    """Real cutoff — open fence with no close. MUST fire."""
    tail = _detect_content_cutoff(
        "Here's the script:\n```bash\necho hello\necho world"
    )
    assert tail is not None


def test_cutoff_long_balanced_inline_backticks_no_false_positive() -> None:
    """Regression: 2026-05-18 misfire on session 6a09c6cdd485.

    Reproduction of the windowing bug — the assistant wrote a
    multi-paragraph technical answer with many inline-code spans
    (a Markdown table + prose discussion). Total backtick count is
    even (balanced), but the ``s[-500:]`` window in the old detector
    sliced through a code-span pair, producing an odd count → false
    positive ``cutoff`` nudge fired on a fully-completed answer.

    The content below mirrors the shape of the real misfire: a
    final paragraph with ~10 inline-code spans where the 500-char
    window starts AFTER an opening backtick but BEFORE its closing
    partner. Must not fire under the fixed detector.
    """
    # Construct so the full content has EVEN inline-backtick count but
    # the -500: tail window has ODD count — i.e. an opening backtick
    # sits before the window boundary and its closer sits inside it.
    #
    # Prologue opens one inline-code span whose closer lives in the
    # epilogue, with enough no-backtick padding between them to push
    # the opener outside the 500-char tail window.
    prologue = (
        "Setup notes — the relevant configuration knob is `max-nudges-per-"
    )  # opens span, intentionally not closed in prologue
    pad = (
        "turn"
        + " plus a paragraph of pure prose without any code markers at all. "
        * 12
    )
    epilogue = (
        "` is set to 3 by default. Additional balanced spans like `foo`, "
        "`bar`, and `baz` appear in the final paragraph. JSON parses clean, "
        "module imports clean. Restart the gateway and the system should work."
    )
    content = prologue + pad + epilogue
    # Sanity: this fixture must actually exhibit the windowing pathology
    # (full count even, window count odd) — otherwise the test isn't
    # exercising the bug.
    full_bt = content.count("`")
    tail_bt = content[-500:].count("`")
    assert full_bt % 2 == 0, "fixture must have balanced full backticks"
    assert tail_bt % 2 == 1, (
        f"fixture must trigger the window pathology (tail count={tail_bt}); "
        "adjust prologue/pad sizing"
    )
    assert _detect_content_cutoff(content) is None, (
        "balanced full-content backticks must not fire as cutoff even when "
        "the 500-char tail window happens to slice a code-span pair"
    )


def test_cutoff_long_balanced_triple_fence_no_false_positive() -> None:
    """Regression: closed code block whose opening fence is >500 chars
    from the end. Old detector saw only the closing fence in its
    window → triple_fences == 1 (odd) → false-positive cutoff.
    """
    opener = "Here's the full script:\n```bash\n"
    body = "echo iteration $i\n" * 60  # >1000 chars of fence body
    closer = "```\nThat's all."
    content = opener + body + closer
    assert content.count("```") == 2, "fixture must have a closed fence"
    tail_fences = content[-500:].count("```")
    assert tail_fences == 1, (
        f"fixture must trigger window pathology (tail fences={tail_fences})"
    )
    assert _detect_content_cutoff(content) is None, (
        "balanced full-content triple-fence must not fire as cutoff even "
        "when the opening fence falls outside the 500-char tail window"
    )


def test_cutoff_bracket_imbalance_still_uses_tail_window() -> None:
    """The bracket check (``()``/``[]``/``{}``) intentionally stays
    windowed — brackets are noisy in prose and a full-content count
    would over-fire on things like nested list markdown across long
    documents. Confirm the windowed bracket check still catches
    real near-end imbalance.
    """
    # Three opens, one close in the tail — abs diff == 2 > 1.
    content = "Opening braces near the end {a} {b {c {d"
    assert _detect_content_cutoff(content) is not None


def test_cutoff_bracket_balanced_prose_no_false_positive() -> None:
    """Natural prose with paired brackets — must not fire."""
    assert _detect_content_cutoff(
        "We (the team) need (more) time for (everything)."
    ) is None


# ---- _detect_colon_cliffhanger ------------------------------------


def test_colon_fires_on_trailing_colon() -> None:
    """The whole point: content ending with ':' and no tool call is a
    cliffhanger."""
    tail = _detect_colon_cliffhanger("Now I'll search for the answer:")
    assert tail is not None
    assert tail.endswith(":")


def test_colon_does_not_fire_on_clean_prose() -> None:
    """Normal sentence ending — must not fire."""
    assert _detect_colon_cliffhanger("All done.") is None


def test_colon_does_not_fire_on_empty() -> None:
    assert _detect_colon_cliffhanger("") is None
    assert _detect_colon_cliffhanger("   \n  ") is None


def test_colon_does_not_fire_on_mid_string_colon() -> None:
    """Colons mid-sentence don't count — only trailing ones."""
    assert _detect_colon_cliffhanger(
        "The config: ~/.config/foo.json holds the value."
    ) is None
