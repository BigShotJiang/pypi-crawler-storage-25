"""Step 42 — TUI render order when a streaming tool's stream is
interrupted by an inner tool_call.

Regression for the bug where ``delegate_claude`` (or any other
streaming-capable outer tool) accumulated ALL its tool_delta chunks
into ONE ``ToolResultMessage`` widget — the one mounted at the time
of the FIRST chunk. When Claude's inner session fired its own
``tool_use`` events, the bridge announced those as new ACP tool_call
events and the TUI mounted ToolCallMessage / ToolResultMessage
widgets at the END of the transcript. But subsequent tool_delta
chunks for the OUTER call (text Claude emitted AFTER running the
inner tool) STILL landed in the original streaming widget — placing
the inner tool widgets visually BELOW the outer's complete text.

The operator's complaint: "tool calls eventually shown after the
final response." Reproduced in session 6a0434800c2f.

Fix: when a ``tool_call`` event arrives while any streaming
ToolResultMessage exists, call ``mark_split()`` on each so the
next ``tool_delta`` for the same call_id mounts a NEW widget at
the END of the transcript — below the inner tool widgets just
placed.

This test drives ``_stream_via_agent`` with a synthetic event
sequence and asserts the recorded mount order. It pins both
the split widget's marker (``🔧→``) and the absence of content
duplication when the outer tool finally completes."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any, AsyncIterator, Iterable
from unittest.mock import MagicMock

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_tui.app import (  # noqa: E402
    AgentChatApp,
    AssistantMessage,
    ToolCallMessage,
    ToolResultMessage,
)


class _FakeTranscript:
    """Records every mount() call so the test can assert layout.

    ``query(ToolResultMessage)`` returns the live in-order list of
    ToolResultMessage widgets the SSE handler has mounted so far —
    this is the surface ``_stream_via_agent``'s split logic + delta
    lookup actually reach for."""

    def __init__(self) -> None:
        self.mounted: list[Any] = []

    async def mount(self, widget: Any) -> None:
        self.mounted.append(widget)

    @property
    def children(self) -> list[Any]:
        # ``_ensure_assistant`` in ``rtxclaw_tui.app`` does
        # ``list(transcript.children)`` to walk previously-mounted
        # widgets when catching up late-arriving chunks (commit
        # 14bf624). Without this property the call AttributeError's
        # before any layout assertion can run.
        return list(self.mounted)

    def scroll_end(self, *, animate: bool = False) -> None:
        return None

    def query(self, kind: Any = None) -> Iterable[Any]:
        if kind is ToolResultMessage:
            return [w for w in self.mounted
                    if isinstance(w, ToolResultMessage)]
        return []

    async def wait_for_refresh(self) -> None:
        # The tool_call handler awaits this; a no-op is fine for
        # the headless test (no real Textual painter to wait on).
        return None


def _events_delegate_claude_with_inner_tool() -> list[tuple[str, dict, str]]:
    """Wire shape for a streaming tool that gets interrupted mid-stream
    by an inner tool_call (the split-boundary invariant this file pins).

    Original reproducer used ``delegate_claude`` as the outer tool, but
    commit 14bf624 routes delegate-* tools through ``SubagentBoxMessage``
    which DELIBERATELY suppresses inner widgets and skips ``mark_split``
    (subagent grouping is its own UI affordance, owned by
    test_41_tui_parallel_tool_render_order.py's subagent fixture). The
    split-boundary code at app.py:10995-10997 is tool-agnostic — it
    fires on any streaming ``ToolResultMessage`` interrupted by an
    inner ``tool_call``. Use ``Bash`` (a regular, non-subagent
    streaming tool) so the path runs end-to-end and the assertion
    pins the same invariant the test name claims.

    Event sequence:
      - outer tool_call (Bash with streaming output)
      - outer tool_delta ("I'll look at the file.")
      - inner tool_call (Grep)
      - inner tool_result (Grep)
      - outer tool_delta ("Found it. Answer is 42.")
      - outer tool_result (Bash complete; content is the FULL body —
        duplicates everything streamed)
      - next-round chunk ("the assistant's final response text")
      - done
    """
    tid = "tid-split"
    outer = "call_bash_long"
    inner = f"{outer}.inner.grep01"
    full_body = (
        "I'll look at the file. Found it. Answer is 42."
    )
    return [
        ("started", {"turn_id": tid}, tid),
        ("tool_call", {
            "tool": "Bash",
            "call_id": outer,
            "arguments": {"command": "long-running task"},
        }, tid),
        ("tool_delta", {
            "call_id": outer,
            "text": "I'll look at the file. ",
        }, tid),
        ("tool_call", {
            "tool": "Grep",
            "call_id": inner,
            "arguments": {"pattern": "answer"},
        }, tid),
        ("tool_result", {
            "call_id": inner,
            "ok": True,
            "content": "42\n",
        }, tid),
        ("tool_delta", {
            "call_id": outer,
            "text": "Found it. Answer is 42.",
        }, tid),
        ("tool_result", {
            "call_id": outer,
            "ok": True,
            "content": full_body,
        }, tid),
        ("chunk", {"choices": [{"delta": {"content": "all done."}}]}, tid),
        ("done", {"state": "complete"}, tid),
    ]


def _make_session_turn_gen(events: list[tuple[str, dict, str]]):
    async def _gen(*_args: Any, **_kwargs: Any) -> AsyncIterator[tuple[str, dict, str]]:
        for ev in events:
            yield ev
    return _gen


async def _drive(app: AgentChatApp, transcript: _FakeTranscript, text: str) -> None:
    app.query_one = MagicMock(return_value=transcript)
    app._set_worker_state = MagicMock()
    app._refresh_status_bar = MagicMock()
    app._set_status = MagicMock()
    app._refresh_title = MagicMock()
    app._maybe_start_next = MagicMock()

    async def _fake_get_session(_sid: str) -> dict:
        return {
            "hash": "h", "title": "t",
            "created_at": "2026-01-01T00:00:00Z",
            "system_prompt": "", "model": "test",
            "endpoint": "http://x", "turns": [],
            "context_window": 0,
        }
    app._client.get_session = _fake_get_session  # type: ignore[attr-defined]
    await app._stream_via_agent(text)


@pytest.fixture
def app() -> AgentChatApp:
    a = AgentChatApp.__new__(AgentChatApp)
    a._sid = "sid-test"
    a._current_turn_id = None
    a._current_assistant = None
    a._pending_tool_calls = set()
    a.enable_thinking = False
    a.reasoning_visibility = "off"
    a._permission_mode = "auto"
    a._last_prompt_tokens = 0
    a._last_context_window = 0
    a._plans = []
    # Subagent-box + plan/section/question/update/harness-task
    # bookkeeping added by 14bf624 + subsequent commits — see the
    # comment block in test_41's app fixture for context.
    a._subagent_box_stack = []
    a._subagent_boxes_by_call = {}
    a._suppressed_subagent_calls = set()
    a._plan_call_ids = set()
    a._section_call_ids = set()
    a._user_question_call_ids = set()
    a._update_call_ids = set()
    a._harness_task_call_ids = set()
    a._pending_task_create_calls = {}
    a._subagent_done = 0
    a._subagent_failed = 0
    a._subagent_total = 0
    return a


def test_inner_tool_call_splits_outer_stream(app: AgentChatApp) -> None:
    """The streaming widget MUST be split when an inner tool_call
    arrives. Inner tool widgets render BELOW the outer's first
    segment, and the second segment of outer text renders AFTER
    the inner widgets — NOT in the original streaming widget."""
    events = _events_delegate_claude_with_inner_tool()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "ask claude"))

    types = [type(w).__name__ for w in transcript.mounted]

    # Expected chronological mount order:
    # 0  AssistantMessage    (eager pre-loop)
    # 1  ToolCallMessage     (outer Bash)
    # 2  ToolResultMessage   (outer segment 1 — gets split when inner
    #                         tool_call arrives)
    # 3  ToolCallMessage     (inner Grep)
    # 4  ToolResultMessage   (inner Grep — completed)
    # 5  ToolResultMessage   (outer segment 2 — mounted on the
    #                         POST-inner-tool delta because the prior
    #                         widget was split, so the streaming-search
    #                         in tool_delta returns None)
    # 6  AssistantMessage    (next-round answer; mounted on the post-
    #                         tool_result _ensure_assistant)
    expected = [
        "AssistantMessage",
        "ToolCallMessage",
        "ToolResultMessage",
        "ToolCallMessage",
        "ToolResultMessage",
        "ToolResultMessage",
        "AssistantMessage",
    ]
    assert types == expected, (
        f"unexpected mount sequence:\n  got:      {types}\n"
        f"  expected: {expected}"
    )

    # The CRITICAL invariant — inner tool widgets must NOT come AFTER
    # the second outer segment (would mean text-then-tools, the bug).
    inner_tc_idx = types.index("ToolCallMessage", 2)  # second one
    inner_tr_idx = types.index("ToolResultMessage", inner_tc_idx)
    second_outer_tr_idx = [i for i, t in enumerate(types)
                            if t == "ToolResultMessage"][-1]
    assert inner_tr_idx < second_outer_tr_idx, (
        f"inner ToolResultMessage at {inner_tr_idx} must come BEFORE the "
        f"second outer ToolResultMessage at {second_outer_tr_idx} — "
        f"the bug was the OPPOSITE order."
    )


def test_split_widget_carries_continuation_marker(app: AgentChatApp) -> None:
    """The split widget MUST flip its prefix from 🔧 (streaming) to
    🔧→ (continuation) so the operator visually understands the
    widget is not the end of the stream."""
    events = _events_delegate_claude_with_inner_tool()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "ask claude"))

    results = [w for w in transcript.mounted
               if isinstance(w, ToolResultMessage)]
    # Three ToolResultMessage widgets total: outer-seg-1 (split),
    # inner Grep (✅), outer-seg-2 (✅).
    assert len(results) == 3, [w.call_id for w in results]
    seg1, inner, seg2 = results
    assert seg1._split is True
    assert seg1._streaming is False
    assert seg1._prefix == "🔧→", seg1._prefix
    # Inner is a regular non-streaming tool_result; ✅ marker.
    assert inner._prefix == "✅", inner._prefix
    assert inner._split is False
    # Outer's final segment carries the closing ✅.
    assert seg2._prefix == "✅", seg2._prefix
    assert seg2._streaming is False


def test_no_content_duplication_across_split_segments(
    app: AgentChatApp,
) -> None:
    """When the outer tool_result finalizes, it MUST NOT replace the
    last segment's streamed content with the full body (which would
    duplicate text already shown in the first segment)."""
    events = _events_delegate_claude_with_inner_tool()
    transcript = _FakeTranscript()
    client = MagicMock()
    client.session_turn = _make_session_turn_gen(events)
    app._client = client

    asyncio.run(_drive(app, transcript, "ask claude"))

    results = [w for w in transcript.mounted
               if isinstance(w, ToolResultMessage)]
    seg1, _inner, seg2 = results
    assert seg1.content == "I'll look at the file.", repr(seg1.content)
    assert seg2.content == "Found it. Answer is 42.", repr(seg2.content)
    # Concatenated, the visible widget content equals the streamed
    # body (no missing text, no duplicated text).
    combined = (seg1.content.rstrip() + " " + seg2.content.lstrip())
    assert combined == "I'll look at the file. Found it. Answer is 42.", (
        f"split segments do not reconstitute the streamed body: {combined!r}"
    )
