"""Step 34 — Bridge cancellation/abort event logging.

The bridge owns several silent code paths that abort or cancel the
in-flight turn:

- The streaming repetition detector (``_detect_reasoning_loop``) trips
  on degenerative output and SIGTERMs the worker.
- ``CoreBackend.cancel`` flips the per-session cancel flag in response
  to ESC / ACP ``session/cancel``.
- The worker emits ``kind="aborted"`` or ``kind="error"`` events.
- A tool runner is interrupted mid-call (``asyncio.CancelledError``)
  or returns ``run_aborted=True`` after a SIGTERM.
- The permission flow returns ``cancelled``.
- The round budget is exhausted (``max_turn_requests``).

Before this step, *none* of those paths logged anything — the only
artifacts were ``aborted=true`` in the session JSON and a
``stopReason="cancelled"`` shipped to the frontend, leaving the
operator unable to answer "why did this turn stop?". Concretely,
the 2026-05-07 incident where a vLLM model recommendation reply was
killed mid-stream by the loop detector wrote zero log lines.

This file pins the logging contract:

- ``CoreBackend._log_event`` writes one ``EVENT {json}`` line to
  ``cfg.logfile`` (gateway.log) per call, mirroring the existing
  ``TURN_METRICS`` shape so a single ``grep`` answers the question.
- ``cancel`` emits ``EXTERNAL_CANCEL``.
- A loop-detector trip emits ``LOOP_DETECTED`` with the offending
  n-gram preview, the buffer length, and the configured thresholds.

Adding more sites in future steps means adding more events here, not
adding parallel print/logger statements scattered across the bridge.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from rtxclaw_agent.acp_bridge import CoreBackend
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.turn_runtime import (
    LOOP_MIN_CONTEXT_CHARS,
    LOOP_NGRAM_LEN,
    LOOP_REPEAT_THRESHOLD,
    LOOP_WINDOW_CHARS,
)


def _make_bridge(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> CoreBackend:
    """Build a CoreBackend whose ``cfg.logfile`` lives under ``tmp_path``.

    The on-disk path resolves through ``RTXCLAW_AGENTS_HOME`` →
    ``cfg.home`` → ``cfg.logfile``; setting that env var keeps the
    test off the operator's real ``~/.rtxclaw/`` tree.
    """
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(name="t", system="sys")
    cfg.logfile.parent.mkdir(parents=True, exist_ok=True)
    return CoreBackend(cfg)


def _read_events(logfile: Path, tag: str) -> list[dict]:
    """Return the JSON payloads of every line in ``logfile`` that opens
    with ``tag ``. Skips other lines (TURN_METRICS, ROUND, …) so this
    helper composes with future events landing in the same file."""
    if not logfile.exists():
        return []
    out: list[dict] = []
    for raw in logfile.read_text(encoding="utf-8").splitlines():
        if not raw.startswith(tag + " "):
            continue
        body = raw[len(tag) + 1:]
        try:
            out.append(json.loads(body))
        except json.JSONDecodeError:
            continue
    return out


def test_log_event_writes_one_jsonl_line(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``_log_event`` must produce exactly one tag-prefixed JSON line
    per call so ``grep TAG gateway.log | jq`` is a one-liner.

    Multi-line writes would corrupt that pipeline; an ``EVENT_FOO\\n``
    with no body would tell us the call happened but strip every
    correlation field (sid, turn_id, …) the operator needs."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    bridge._log_event("UNIT_TEST", sid="abc", turn_id="t1", note="hello")

    events = _read_events(bridge.cfg.logfile, "UNIT_TEST")
    assert len(events) == 1, "expected exactly one UNIT_TEST line"
    payload = events[0]
    assert payload["sid"] == "abc"
    assert payload["turn_id"] == "t1"
    assert payload["note"] == "hello"
    assert "ts" in payload, "every event must carry a timestamp"


def test_log_event_survives_unserialisable_value(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A bad field (e.g. an Exception) must NOT crash the bridge mid-
    cancel. Observability is best-effort; a write failure here is the
    least bad outcome and must surface as a degraded line, not as a
    raised exception that prevents the cancel from completing."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    bridge._log_event("UNIT_TEST_BAD", payload=object())  # not JSON-able

    raw = bridge.cfg.logfile.read_text(encoding="utf-8")
    assert "UNIT_TEST_BAD" in raw, "event tag must still land in the log"


def test_external_cancel_emits_event(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``cancel`` is the operator-visible kill switch (ESC in TUI, ACP
    ``session/cancel``). Every fire MUST log so the next post-mortem
    can attribute an aborted turn to a real user action vs an internal
    safety net."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    asyncio.run(bridge.cancel("session-deadbeef"))

    events = _read_events(bridge.cfg.logfile, "EXTERNAL_CANCEL")
    assert len(events) == 1
    payload = events[0]
    # sid is truncated to 12 chars in the log so a long Telegram chat
    # id doesn't bloat every line — but it must still be enough to
    # correlate with the session file's hash prefix.
    assert payload["sid"] == "session-dead"
    # No active turn is registered for an unknown session, so the flag
    # must reflect that — operator can tell "cancel arrived but there
    # was nothing in flight" from the log alone.
    assert payload["had_active_turn"] is False


def test_loop_detected_event_shape(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The loop-detector trip is the path that motivated this work —
    it MUST emit ``LOOP_DETECTED`` with enough fields to diagnose a
    false positive (offending n-gram + buffer length + thresholds).

    We exercise ``_log_event`` directly with the same payload shape
    the bridge constructs, rather than booting a worker subprocess,
    so the test is fast + deterministic. The wiring at the call site
    is covered by the ``acp_bridge.py`` source (``LOOP_DETECTED`` is
    grep-greppable) — this test pins the *contract* of what the line
    must contain so a future drive-by edit doesn't drop a field
    operators rely on.
    """
    bridge = _make_bridge(tmp_path, monkeypatch)
    bridge._log_event(
        "LOOP_DETECTED",
        sid="69fca5cf0de7"[:12],
        turn_id="t-9",
        round_idx=2,
        stream="content",
        buffer_chars=2791,
        ngram_preview="  --tensor-parallel-size 2 \\\n  --max-model-len 131072",
        ngram_len=LOOP_NGRAM_LEN,
        repeat_threshold=LOOP_REPEAT_THRESHOLD,
        window_chars=LOOP_WINDOW_CHARS,
    )

    events = _read_events(bridge.cfg.logfile, "LOOP_DETECTED")
    assert len(events) == 1
    p = events[0]
    # Every operator-relevant field must round-trip — losing any one
    # of these turns "why did this turn stop?" back into a guess.
    for key in (
        "sid", "turn_id", "round_idx", "stream", "buffer_chars",
        "ngram_preview", "ngram_len", "repeat_threshold", "window_chars",
    ):
        assert key in p, f"LOOP_DETECTED missing required field: {key}"
    assert p["stream"] in {"content", "thinking"}, (
        "stream field must distinguish CoT loops from answer-text loops"
    )
    # The preview is bounded by 80 chars at the call site so a runaway
    # tokenizer can't produce a 50K-char log line. Assert the contract,
    # not the literal cap, so a future tweak is easy.
    assert len(p["ngram_preview"]) <= 200


def test_log_event_appends_not_truncates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``open(..., 'a')`` is the contract. A regression to ``'w'``
    would obliterate every ``TURN_METRICS`` line on each cancel —
    catastrophic for retro-debugging multi-turn runs."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    bridge.cfg.logfile.write_text("PREEXISTING_LINE {}\n", encoding="utf-8")
    bridge._log_event("UNIT_TEST_APPEND", sid="x")

    body = bridge.cfg.logfile.read_text(encoding="utf-8")
    assert "PREEXISTING_LINE" in body, (
        "log writes must append — prior content was truncated"
    )
    assert "UNIT_TEST_APPEND" in body
