"""Step 44 — ``todo(action="replace")`` state-merge contract.

Background: the model occasionally re-emits a full plan via
``replace`` (sometimes with all items pre-marked ``status="done"``)
when it should have used ``complete``. A naive overwrite either
wipes existing done flags (when items come back as ``"pending"``)
or duplicates the plan in the TUI.

Reproducer in the wild: session 69ff1bf6a5e3410fa7000001 turn 3.
The model fired a 5-step plan with 4 explicit ``complete`` calls,
then for the final tick it called ``replace`` with the same 5 items
all marked done. Persisted state was overwritten verbatim — fine
in that one trace, but the same pattern with ``status="pending"``
would have erased the prior done flags.

The runner-side fix: when ``replace`` items have the same content
list (in order) as the persisted items, merge instead of overwrite —
preserve ``created_at`` from existing entries and OR the done
status (so done flags accumulate, never get cleared).

The TUI-side fix lives in ``test_28_plan_steps.py`` —
``test_handle_todo_replace_same_steps_merges_into_existing``.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rtxclaw_core.tools.runners import (
    load_todos,
    run_todo,
    todos_path_for_session,
)


@pytest.fixture
def todos_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Configure the runner's env-driven session-todo resolution to
    point at a tmp file. ``run_todo`` reads ``RTXCLAW_SESSION_ID``
    + ``RTXCLAW_SESSIONS_DIR`` to derive the path."""
    monkeypatch.setenv("RTXCLAW_SESSION_ID", "test_sid_001")
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(tmp_path))
    return todos_path_for_session(tmp_path, "test_sid_001")


def _seed(path: Path, items: list[dict]) -> None:
    path.write_text(json.dumps(items, indent=2) + "\n")


def test_replace_with_matching_content_preserves_done_status(
    todos_path: Path,
) -> None:
    """The smoking gun: model resends the plan with all-pending items
    after some have already been completed. Without merge, the prior
    done flags get wiped. With merge, they survive."""
    _seed(todos_path, [
        {"content": "step1", "status": "done", "created_at": "2026-05-09T00:00:00+00:00"},
        {"content": "step2", "status": "done", "created_at": "2026-05-09T00:00:00+00:00"},
        {"content": "step3", "status": "pending", "created_at": "2026-05-09T00:00:00+00:00"},
    ])
    res = run_todo({
        "action": "replace",
        "items": [
            {"content": "step1", "status": "pending"},
            {"content": "step2", "status": "pending"},
            {"content": "step3", "status": "pending"},
        ],
    })
    assert res.ok, res.content
    after = load_todos(todos_path)
    assert [t["status"] for t in after] == ["done", "done", "pending"]
    # created_at on the existing entries is preserved.
    assert after[0]["created_at"] == "2026-05-09T00:00:00+00:00"


def test_replace_with_matching_content_ors_in_new_done_flags(
    todos_path: Path,
) -> None:
    """The exact session 69ff1bf6 case: model sends ``replace`` with
    all five items pre-marked done. Existing done flags survive AND
    the new done flags get applied to previously-pending items."""
    _seed(todos_path, [
        {"content": "a", "status": "done"},
        {"content": "b", "status": "done"},
        {"content": "c", "status": "pending"},
    ])
    res = run_todo({
        "action": "replace",
        "items": [
            {"content": "a", "status": "done"},
            {"content": "b", "status": "done"},
            {"content": "c", "status": "done"},
        ],
    })
    assert res.ok, res.content
    after = load_todos(todos_path)
    assert [t["status"] for t in after] == ["done", "done", "done"]


def test_replace_with_different_content_still_overwrites(
    todos_path: Path,
) -> None:
    """Sanity: when content doesn't match (model truly is starting a
    new plan), the runner overwrites as before. The merge path is
    content-equality only."""
    _seed(todos_path, [
        {"content": "old1", "status": "done"},
        {"content": "old2", "status": "pending"},
    ])
    res = run_todo({
        "action": "replace",
        "items": [
            {"content": "fresh1", "status": "pending"},
            {"content": "fresh2", "status": "pending"},
        ],
    })
    assert res.ok, res.content
    after = load_todos(todos_path)
    assert [t["content"] for t in after] == ["fresh1", "fresh2"]
    assert [t["status"] for t in after] == ["pending", "pending"]


def test_replace_on_empty_persisted_state_does_not_merge(
    todos_path: Path,
) -> None:
    """First-ever ``replace`` (no persisted state) must still create
    the plan from scratch — the merge guard (``if items``) prevents
    a degenerate empty == empty match."""
    res = run_todo({
        "action": "replace",
        "items": [
            {"content": "first", "status": "pending"},
            {"content": "second", "status": "pending"},
        ],
    })
    assert res.ok, res.content
    after = load_todos(todos_path)
    assert [t["content"] for t in after] == ["first", "second"]
    assert [t["status"] for t in after] == ["pending", "pending"]


def test_replace_with_matching_content_different_length_overwrites(
    todos_path: Path,
) -> None:
    """A subset / superset of the existing items is NOT a merge —
    the model genuinely changed the plan shape, so overwrite."""
    _seed(todos_path, [
        {"content": "a", "status": "done"},
        {"content": "b", "status": "done"},
        {"content": "c", "status": "pending"},
    ])
    res = run_todo({
        "action": "replace",
        "items": [
            {"content": "a", "status": "pending"},
            {"content": "b", "status": "pending"},
        ],
    })
    assert res.ok, res.content
    after = load_todos(todos_path)
    assert len(after) == 2
    assert [t["status"] for t in after] == ["pending", "pending"]
