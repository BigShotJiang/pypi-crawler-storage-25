"""Tests for `rtxclaw_agent.self_improver_install` — the module that
copies assets/self-improver/* into ~/.rtxclaw/scripts/, installs the
hooks.json per agent, and (optionally) registers the cron entry."""
import argparse
import json
import os
import stat
from pathlib import Path

import pytest

from rtxclaw_agent import self_improver_install as installer


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path / "rtxhome"))
    monkeypatch.setenv("RTXCLAW_SOURCE_DIR", str(tmp_path / "src" / "rtxclaw"))
    src = tmp_path / "src" / "rtxclaw"
    (src / "assets" / "self-improver").mkdir(parents=True)
    (src / "scripts").mkdir(parents=True)
    for name in ("self-improver.sh", "self-improver-scan.sh", "self-improver-gc.sh"):
        (src / "assets" / "self-improver" / name).write_text(f"#!/bin/sh\n# {name}\n")
    # Realistic template with the 4 self-improver events so merge
    # tests have something to merge in.
    (src / "assets" / "self-improver" / "hooks.json").write_text(json.dumps({
        "hooks": {
            "ReasoningLoopDetected": [{"matcher": "*", "hooks": [{
                "type": "command",
                "command": "~/.rtxclaw/scripts/self-improver.sh reasoning-loop",
                "async": True, "timeout": 5}]}],
            "PrematureTurnEnd": [{"matcher": "*", "hooks": [{
                "type": "command",
                "command": "~/.rtxclaw/scripts/self-improver.sh premature-end",
                "async": True, "timeout": 5}]}],
            "PostToolUseFailure": [{"matcher": "*", "hooks": [{
                "type": "command",
                "command": "~/.rtxclaw/scripts/self-improver.sh tool-failure",
                "async": True, "timeout": 5}]}],
            "SessionError": [{"matcher": "*", "hooks": [{
                "type": "command",
                "command": "~/.rtxclaw/scripts/self-improver.sh session-error",
                "async": True, "timeout": 5}]}],
        }
    }))
    (src / "scripts" / "self-improver-prompt.md").write_text("prompt")
    (src / "scripts" / "run-self-improver-tests.sh").write_text("#!/bin/sh\n")
    return tmp_path


def test_install_copies_three_scripts_to_rtxhome(fake_home):
    installer.install(agents=["main"], print_cron=True)
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    for name in ("self-improver.sh", "self-improver-scan.sh", "self-improver-gc.sh"):
        dst = rtxhome / "scripts" / name
        assert dst.is_file(), f"missing {dst}"
        assert dst.stat().st_mode & stat.S_IXUSR, f"{dst} must be executable"


def test_install_writes_hooks_json_per_agent(fake_home):
    installer.install(agents=["main", "claude"], print_cron=True)
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    for agent in ("main", "claude"):
        hf = rtxhome / "agents" / agent / "hooks.json"
        assert hf.is_file(), f"missing {hf}"


def test_install_does_not_overwrite_customized_hooks_json(fake_home):
    """If the existing hooks.json already mentions self-improver.sh
    (operator has customized the self-improver wiring), leave it
    alone."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        "hooks": {
            "ReasoningLoopDetected": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh reasoning-loop",
                           "async": True, "_custom_tag": "DO_NOT_OVERWRITE"}],
            }]
        }
    }))

    installer.install(agents=["main"], print_cron=True)
    # The "_custom_tag" must survive — proof we didn't touch the file.
    body = json.loads(custom.read_text())
    cmd_hook = body["hooks"]["ReasoningLoopDetected"][0]["hooks"][0]
    assert cmd_hook.get("_custom_tag") == "DO_NOT_OVERWRITE"


def test_install_merges_into_existing_hooks_json_without_self_improver_entries(fake_home):
    """Bug #7 regression: if the existing hooks.json has unrelated
    hooks (e.g. operator added PreToolUse) but NO self-improver
    entries, the installer must MERGE the 4 self-improver events in
    rather than silently leaving the file unmodified."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        "hooks": {
            "PreToolUse": [{
                "matcher": "Bash",
                "hooks": [{"type": "command", "command": "echo pre",
                           "_user_tag": "PRESERVED"}],
            }]
        }
    }))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())
    # User's PreToolUse entry must survive untouched.
    assert body["hooks"]["PreToolUse"][0]["hooks"][0]["_user_tag"] == "PRESERVED"
    # All 4 self-improver events must now be present.
    for event in ("ReasoningLoopDetected", "PrematureTurnEnd",
                  "PostToolUseFailure", "SessionError"):
        assert event in body["hooks"], f"missing event after merge: {event}"
        cmd = body["hooks"][event][0]["hooks"][0]["command"]
        assert "self-improver.sh" in cmd, (
            f"merged {event} command must invoke self-improver.sh, got: {cmd!r}"
        )


def test_install_into_empty_hooks_object_adds_all_four_events(fake_home):
    """Edge case: the operator has an empty hooks dict (e.g. a
    placeholder file). Merge in all 4 self-improver events."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({"hooks": {}}))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())
    for event in ("ReasoningLoopDetected", "PrematureTurnEnd",
                  "PostToolUseFailure", "SessionError"):
        assert event in body["hooks"], f"missing event after merge into empty: {event}"


def test_install_merges_into_bare_event_map_hooks_json(fake_home):
    """Codex regression: HookEngine accepts a bare-event-map shape
    (no top-level 'hooks' key). The installer must merge our events
    INTO the bare map, not wrap them in a new 'hooks' key (which
    would silently disable the operator's existing entries)."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        "PreToolUse": [{
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": "echo pre",
                       "_user_tag": "BAREMAP_PRESERVED"}],
        }]
    }))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())
    # The operator's bare-map PreToolUse must survive — at the TOP LEVEL,
    # not inside a new "hooks" key.
    assert "PreToolUse" in body, (
        "operator's bare-map PreToolUse was lost — installer must "
        "preserve the bare shape, not wrap in a new 'hooks' key"
    )
    assert body["PreToolUse"][0]["hooks"][0]["_user_tag"] == "BAREMAP_PRESERVED"
    # Self-improver events must be merged AT THE SAME LEVEL (bare-map),
    # not inside a new 'hooks' key.
    for event in ("ReasoningLoopDetected", "PrematureTurnEnd",
                  "PostToolUseFailure", "SessionError"):
        assert event in body, (
            f"missing event {event} at bare-map top level — installer "
            f"wrote a 'hooks' wrapper that would shadow the operator's "
            f"top-level entries"
        )
    # The dangerous "wrapped in hooks key" shape MUST NOT appear.
    assert "hooks" not in body, (
        "installer must preserve the bare-event-map shape; instead it "
        "wrapped the events in a 'hooks' key, which the loader would "
        "ignore in favour of one or the other side"
    )


def test_install_preserves_standard_shape_when_existing_uses_it(fake_home):
    """Mirror of the bare-map test: standard {'hooks': {...}} shape
    must stay standard after a merge."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        "hooks": {
            "PreToolUse": [{
                "matcher": "*",
                "hooks": [{"type": "command", "command": "echo std",
                           "_user_tag": "STANDARD_PRESERVED"}],
            }]
        }
    }))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())
    # Shape preserved.
    assert "hooks" in body and isinstance(body["hooks"], dict)
    assert "PreToolUse" not in body, (
        "events leaked to bare-map level — should stay inside 'hooks'"
    )
    assert body["hooks"]["PreToolUse"][0]["hooks"][0]["_user_tag"] == "STANDARD_PRESERVED"
    for event in ("ReasoningLoopDetected", "PrematureTurnEnd",
                  "PostToolUseFailure", "SessionError"):
        assert event in body["hooks"]


def test_install_repairs_mixed_shape_hooks_json_from_broken_f6(fake_home):
    """Codex round-3 caveat: if the operator's hooks.json was damaged
    by the pre-f3344c3 installer (mixed shape: bare-map operator
    entries at top level AND a 'hooks' wrapper containing the
    self-improver entries), HookEngine loads only the 'hooks' side
    and silently ignores the operator's top-level entries.

    Re-running the fixed installer must REPAIR this — move the
    orphan top-level entries into the 'hooks' dict so the file
    becomes pure standard shape, with both operator and
    self-improver entries active."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        # Operator's original bare-map entry — silently orphaned by broken F6.
        "PreToolUse": [{
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": "echo pre",
                       "_user_tag": "ORPHANED_BY_F6"}],
        }],
        # The 'hooks' wrapper broken-F6 added on top.
        "hooks": {
            "ReasoningLoopDetected": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh reasoning-loop",
                           "async": True}],
            }],
            "PrematureTurnEnd": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh premature-end",
                           "async": True}],
            }],
            "PostToolUseFailure": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh tool-failure",
                           "async": True}],
            }],
            "SessionError": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh session-error",
                           "async": True}],
            }],
        },
    }))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())

    # Operator's PreToolUse must now live inside 'hooks' (alongside
    # the self-improver entries) instead of orphaned at top level.
    assert "PreToolUse" not in body or body.get("PreToolUse") in (None, []), (
        f"PreToolUse still at top level after repair — operator entry "
        f"would remain silently orphaned. body={body!r}"
    )
    assert "hooks" in body
    assert "PreToolUse" in body["hooks"], (
        "PreToolUse was not migrated into the standard-shape 'hooks' "
        "container during repair"
    )
    assert body["hooks"]["PreToolUse"][0]["hooks"][0]["_user_tag"] == "ORPHANED_BY_F6", (
        "operator entry contents must survive the migration unchanged"
    )
    # All 4 self-improver events still present.
    for event in ("ReasoningLoopDetected", "PrematureTurnEnd",
                  "PostToolUseFailure", "SessionError"):
        assert event in body["hooks"], (
            f"self-improver event {event} lost during repair"
        )


def test_install_mixed_shape_collision_prefers_hooks_side(fake_home):
    """Edge case: if the same event key appears in BOTH the bare-map
    top-level AND the 'hooks' wrapper, the 'hooks' side wins (it's
    the more recent install). Operator's bare-map duplicate is
    dropped with a stderr warning."""
    import io
    from contextlib import redirect_stderr

    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        # Same key in both locations.
        "ReasoningLoopDetected": [{
            "matcher": "operator",
            "hooks": [{"type": "command", "command": "echo bare",
                       "_user_tag": "BARE_DROPPED"}],
        }],
        "hooks": {
            "ReasoningLoopDetected": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": "~/.rtxclaw/scripts/self-improver.sh reasoning-loop",
                           "_user_tag": "HOOKS_KEPT"}],
            }],
        },
    }))

    err = io.StringIO()
    with redirect_stderr(err):
        installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())

    assert "ReasoningLoopDetected" not in body or body.get("ReasoningLoopDetected") in (None, []), (
        "duplicate bare-map entry should not survive normalisation"
    )
    assert body["hooks"]["ReasoningLoopDetected"][0]["hooks"][0]["_user_tag"] == "HOOKS_KEPT", (
        "on collision, the 'hooks' side (more recent install) must win"
    )


def test_install_recognises_self_improver_in_bare_event_map(fake_home):
    """If an operator's bare-map already calls self-improver.sh, the
    installer must respect that (no merge / no rewrite) — same
    semantic as the standard-shape customisation guard."""
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    custom = rtxhome / "agents" / "main" / "hooks.json"
    custom.parent.mkdir(parents=True)
    custom.write_text(json.dumps({
        "ReasoningLoopDetected": [{
            "matcher": "*",
            "hooks": [{"type": "command",
                       "command": "~/.rtxclaw/scripts/self-improver.sh reasoning-loop",
                       "async": True, "_custom_tag": "BAREMAP_CUSTOM"}],
        }]
    }))

    installer.install(agents=["main"], print_cron=True)
    body = json.loads(custom.read_text())
    assert body["ReasoningLoopDetected"][0]["hooks"][0]["_custom_tag"] == "BAREMAP_CUSTOM"
    # No new wrapper, no clobber.
    assert "hooks" not in body


def test_install_creates_runtime_dirs(fake_home):
    installer.install(agents=["main"], print_cron=True)
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    for sub in ("self-improver/logs",
                "self-improver/runs", "self-improver/worktrees",
                "self-improver/test-runs", "self-improver/fixes"):
        assert (rtxhome / sub).is_dir(), f"missing dir: {sub}"


def test_install_print_cron_emits_correct_line(fake_home, capsys):
    installer.install(agents=["main"], print_cron=True)
    out = capsys.readouterr().out
    assert "*/15" in out
    assert "self-improver-scan.sh" in out


def test_install_is_idempotent(fake_home):
    installer.install(agents=["main"], print_cron=True)
    installer.install(agents=["main"], print_cron=True)
    rtxhome = Path(os.environ["RTXCLAW_HOME"])
    assert (rtxhome / "scripts" / "self-improver.sh").is_file()


def test_install_returns_nonzero_when_crontab_install_fails(fake_home, monkeypatch):
    """Bug #10 regression: a failed crontab install must propagate as a
    non-zero return from install(), not be swallowed."""
    from unittest.mock import patch, MagicMock

    def fake_run(cmd, *args, **kwargs):
        result = MagicMock()
        result.returncode = 0 if cmd[:2] == ["crontab", "-l"] else 1
        result.stdout = "" if cmd[:2] == ["crontab", "-l"] else ""
        result.stderr = "" if cmd[:2] == ["crontab", "-l"] else "crontab: permission denied"
        return result

    with patch.object(installer.subprocess, "run", side_effect=fake_run):
        rc = installer.install(agents=["main"], print_cron=False)
    assert rc != 0, (
        "install() must return non-zero when crontab install fails — "
        "silent success is the bug we're fixing"
    )


def test_install_returns_zero_when_crontab_install_succeeds(fake_home, monkeypatch):
    from unittest.mock import patch, MagicMock

    def fake_run(cmd, *args, **kwargs):
        result = MagicMock()
        result.returncode = 0
        result.stdout = "" if cmd[:2] == ["crontab", "-l"] else ""
        result.stderr = ""
        return result

    with patch.object(installer.subprocess, "run", side_effect=fake_run):
        rc = installer.install(agents=["main"], print_cron=False)
    assert rc == 0


def test_install_print_cron_returns_zero_without_invoking_crontab(fake_home):
    """The --print-cron path must NEVER touch the real crontab and
    must always return 0 — the test fixtures rely on this to avoid
    polluting the host crontab."""
    from unittest.mock import patch
    with patch.object(installer.subprocess, "run") as mock_run:
        rc = installer.install(agents=["main"], print_cron=True)
    assert rc == 0
    assert not mock_run.called, "print_cron must not invoke subprocess at all"


def test_cli_registers_self_improver_install_subcommand():
    """`rtxclaw_agent self-improver install --print-cron` must be
    reachable through the main CLI without raising."""
    # Need a staged env so the installer can find assets/.
    # Reuse the fake_home fixture by setting env vars manually.
    import os
    from pathlib import Path
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        src = td / "src" / "rtxclaw"
        (src / "assets" / "self-improver").mkdir(parents=True)
        for name in ("self-improver.sh", "self-improver-scan.sh", "self-improver-gc.sh"):
            (src / "assets" / "self-improver" / name).write_text(f"#!/bin/sh\n# {name}\n")
        (src / "assets" / "self-improver" / "hooks.json").write_text('{"hooks":{}}')
        os.environ["RTXCLAW_HOME"] = str(td / "rtxhome")
        os.environ["RTXCLAW_SOURCE_DIR"] = str(src)
        try:
            from rtxclaw_agent.cli import main
            rc = main(["self-improver", "install", "--print-cron"])
            assert rc == 0
        finally:
            os.environ.pop("RTXCLAW_HOME", None)
            os.environ.pop("RTXCLAW_SOURCE_DIR", None)
