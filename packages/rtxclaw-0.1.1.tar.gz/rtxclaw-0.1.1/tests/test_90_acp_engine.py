"""Step 90 — generic AcpEngine + the CursorAcpEngine subclass.

``AcpEngine`` drives ANY ACP server (rtxclaw as ACP client) over the
newline-delimited JSON-RPC stdio transport. ``CursorAcpEngine`` is a
thin subclass carrying Cursor's documented non-standard quirks (mode
ids agent/plan/ask, bracketed model ids). Fast, daemon-free: the
integration tests inject a spawn function that wires the real
:class:`AcpClient` to an in-process :class:`AcpServer` with a stub
backend, so no cursor-agent binary or auth is needed.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, AsyncIterator

import pytest

from rtxclaw_acp.client.client import AcpClient
from rtxclaw_acp.protocol.jsonrpc import JsonRpcFramingError
from rtxclaw_acp.protocol.transport import Transport
from rtxclaw_acp.server.server import AcpServer
from rtxclaw_core.agents.acp_engine import (
    AcpEngine,
    _build_prompt_blocks,
    _make_permission_handler,
    _pick_option,
    _text_of,
    _translate_update,
)
from rtxclaw_core.agents.cursor_acp_engine import CursorAcpEngine
from rtxclaw_core.agents.engine import (
    EngineKind,
    EngineSessionState,
    TextDelta,
    ToolCallResult,
    ToolCallStarted,
    TurnDone,
    TurnRequest,
    TurnStarted,
)


# ---- pure-unit: session/update translation -------------------------


def test_translate_agent_message_chunk_to_content_delta() -> None:
    evs = _translate_update(
        {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "hi"}}
    )
    assert len(evs) == 1 and isinstance(evs[0], TextDelta)
    assert evs[0].text == "hi" and evs[0].channel == "content"


def test_translate_thought_chunk_to_thinking_delta() -> None:
    evs = _translate_update(
        {"sessionUpdate": "agent_thought_chunk", "content": {"type": "text", "text": "hmm"}}
    )
    assert evs[0].channel == "thinking" and evs[0].text == "hmm"


def test_translate_tool_call_and_completion() -> None:
    started = _translate_update(
        {"sessionUpdate": "tool_call", "toolCallId": "c1", "title": "Bash",
         "kind": "execute", "status": "in_progress", "rawInput": {"command": "ls"}}
    )
    assert isinstance(started[0], ToolCallStarted)
    assert started[0].call_id == "c1" and started[0].name == "Bash"
    assert started[0].arguments == {"command": "ls"}

    done = _translate_update(
        {"sessionUpdate": "tool_call_update", "toolCallId": "c1", "status": "completed",
         "content": [{"type": "content", "content": {"type": "text", "text": "out"}}]}
    )
    assert isinstance(done[0], ToolCallResult)
    assert done[0].ok is True and done[0].content == "out"


def test_translate_failed_tool_is_not_ok() -> None:
    evs = _translate_update(
        {"sessionUpdate": "tool_call_update", "toolCallId": "c1", "status": "failed", "content": []}
    )
    assert isinstance(evs[0], ToolCallResult) and evs[0].ok is False


def test_translate_ignores_unmapped_updates() -> None:
    assert _translate_update({"sessionUpdate": "current_mode_update", "currentModeId": "agent"}) == []
    assert _translate_update({"sessionUpdate": "available_commands_update", "availableCommands": []}) == []


def test_text_of_flattens_nested_and_lists() -> None:
    assert _text_of({"type": "text", "text": "a"}) == "a"
    assert _text_of([{"type": "content", "content": {"type": "text", "text": "a"}},
                     {"type": "content", "content": {"type": "text", "text": "b"}}]) == "ab"
    assert _text_of(None) == ""


def test_build_prompt_blocks_injects_system_on_first_turn() -> None:
    req = TurnRequest(prompt="do it", system_prompt="BE GOOD", system_prompt_sha256="s")
    blocks = _build_prompt_blocks(req, "first_turn")
    assert "<system>\nBE GOOD\n</system>" in blocks[0]["text"]
    assert blocks[0]["text"].endswith("do it")


def test_build_prompt_blocks_omits_system_on_resume() -> None:
    req = TurnRequest(prompt="next", system_prompt="BE GOOD", system_prompt_sha256="s")
    assert _build_prompt_blocks(req, "never") == [{"type": "text", "text": "next"}]


def test_build_prompt_blocks_folds_preamble_on_priming() -> None:
    # Preamble (pinned facts / todos / memory / skills) must reach the ACP
    # server on priming turns, like CLI engines fold it into priming.
    req = TurnRequest(prompt="go", system_prompt="SYS", system_prompt_sha256="s",
                      preamble=[{"content": "PINNED-FACTS"}, {"content": "TODOS"}])
    text = _build_prompt_blocks(req, "first_turn")[0]["text"]
    assert "SYS" in text and "PINNED-FACTS" in text and "TODOS" in text
    assert text.endswith("go")


def test_build_prompt_blocks_folds_preamble_even_without_system() -> None:
    req = TurnRequest(prompt="go", preamble=[{"content": "MEMORY-RECALL"}])
    text = _build_prompt_blocks(req, "first_turn")[0]["text"]
    assert "MEMORY-RECALL" in text


def test_build_prompt_blocks_omits_preamble_on_resume() -> None:
    req = TurnRequest(prompt="go", preamble=[{"content": "X"}])
    assert _build_prompt_blocks(req, "never") == [{"type": "text", "text": "go"}]


def test_permission_handler_modes() -> None:
    opts = [{"optionId": "allow", "kind": "allow_once"}, {"optionId": "rej", "kind": "reject_once"}]
    assert asyncio.run(_make_permission_handler("auto")({"options": opts})) == \
        {"outcome": {"outcome": "selected", "optionId": "allow"}}
    assert asyncio.run(_make_permission_handler("plan")({"options": opts})) == \
        {"outcome": {"outcome": "selected", "optionId": "rej"}}
    assert asyncio.run(_make_permission_handler("auto")({"options": []})) == \
        {"outcome": {"outcome": "cancelled"}}


def test_pick_option_prefers_kind_order() -> None:
    opts = [{"optionId": "a", "kind": "allow_once"}, {"optionId": "b", "kind": "allow_always"}]
    assert _pick_option(opts, ("allow_always", "allow_once")) == "b"
    assert _pick_option([], ("allow_once",)) is None


# ---- generic AcpEngine ---------------------------------------------


def test_generic_engine_is_command_driven() -> None:
    eng = AcpEngine(command=["my-acp", "serve"], name="gemini", model="gemini-3")
    assert eng.kind is EngineKind.ACP
    assert eng.name == "gemini"
    assert eng.display_model() == "gemini-3"
    # Base passes the mode through unchanged (no vendor remap).
    assert eng._acp_mode("auto") == "auto"
    assert eng._clean_model_label("x[fast=true]") == "x[fast=true]"


def test_generic_engine_unconfigured_is_unavailable() -> None:
    ok, reason = AcpEngine(command=[]).is_available()
    assert ok is False and "acp_command" in reason


def test_generic_engine_missing_binary_is_unavailable() -> None:
    ok, reason = AcpEngine(command=["definitely-not-on-path-xyz", "acp"]).is_available()
    assert ok is False and "PATH" in reason


def test_display_model_prefers_cached_then_config_then_name() -> None:
    eng = AcpEngine(command=["x"], name="acp", model="cfg-model")
    assert eng.display_model() == "cfg-model"
    eng._cached_model = "live-model"
    assert eng.display_model() == "live-model"
    assert AcpEngine(command=["x"], name="acp").display_model() == "acp"


def test_capture_model_resolves_name_and_cleans_label() -> None:
    eng = CursorAcpEngine()  # subclass cleans bracket suffixes

    class _C:
        last_session_models = {
            "currentModelId": "composer-2.5[fast=true]",
            "availableModels": [
                {"modelId": "default[]", "name": "Auto"},
                {"modelId": "composer-2.5[fast=true]", "name": "composer-2.5"},
            ],
        }

    eng._capture_model(_C())
    assert eng._cached_model == "composer-2.5"


# ---- CursorAcpEngine quirks ----------------------------------------


def test_cursor_subclass_defaults_and_inheritance() -> None:
    c = CursorAcpEngine()
    assert isinstance(c, AcpEngine)
    assert c.kind is EngineKind.CURSOR_ACP
    assert c._command == ["cursor-agent", "acp"]
    assert c.name == "cursor"
    assert c._auth_method == "cursor_login"


def test_cursor_maps_auto_mode_to_agent() -> None:
    c = CursorAcpEngine()
    assert c._acp_mode("auto") == "agent"   # the key Cursor quirk
    assert c._acp_mode("plan") == "plan"
    assert c._acp_mode("ask") == "ask"


def test_cursor_strips_bracketed_model_suffix() -> None:
    c = CursorAcpEngine()
    assert c._clean_model_label("composer-2.5[fast=true]") == "composer-2.5"
    assert c._clean_model_label("default[]") == "default"
    assert c._clean_model_label("plain") == "plain"


def test_cursor_config_overrides_defaults(tmp_path: Path) -> None:
    # Per-agent config.json must be able to override the Cursor defaults
    # (e.g. extra flags / a pinned model), not be hard-clobbered.
    home = tmp_path / "cur"
    home.mkdir()
    (home / "config.json").write_text(json.dumps({
        "engine": "cursor_acp",
        "acp_command": ["cursor-agent", "acp", "--foo"],
        "acp_model": "composer-2.5",
    }))

    class _Cfg:
        name = "cur"

        @property
        def home(self):
            return home

    c = CursorAcpEngine(_Cfg())
    assert c._command == ["cursor-agent", "acp", "--foo"]  # config wins
    assert c.display_model() == "composer-2.5"
    # Defaults still fill gaps the config didn't set.
    assert c._auth_method == "cursor_login"


def test_session_load_retries_after_auth_required(tmp_path: Path) -> None:
    # A resumed turn whose session/load returns auth-required must
    # authenticate and retry the LOAD (preserving the saved session),
    # NOT fall through to a fresh session/new.
    from rtxclaw_acp.client.client import AcpRemoteError

    class _FakeClient:
        def __init__(self) -> None:
            self.authed = False
            self.loads = 0

        async def authenticate(self, method_id):
            self.authed = True

        async def session_load(self, sid, *, cwd):
            self.loads += 1
            if not self.authed:
                raise AcpRemoteError(code=-32000, message="auth required")
            return {}

        async def session_new(self, cwd):
            raise AssertionError("must not open a new session on auth-retry path")

    eng = CursorAcpEngine()  # auth_method defaults to cursor_login
    init = {"agentCapabilities": {"loadSession": True}}
    state = EngineSessionState(
        rtxclaw_session_id="s1", engine=EngineKind.CURSOR_ACP,
        engine_session_id="prev-sid", priming_status="completed",
        priming_system_prompt_sha256="x",
    )
    client = _FakeClient()
    sid = asyncio.run(eng._open_session(client, init, state, "never", "/tmp"))
    assert sid == "prev-sid"
    assert client.authed and client.loads == 2


# ---- scaffolding ----------------------------------------------------


def test_scaffold_writes_full_config_for_cursor(tmp_path: Path) -> None:
    from rtxclaw_core.agents import default_scaffolds as ds

    home = tmp_path / "cursor"
    ds.write_scaffold(home, "cursor_acp")
    cfg = json.loads((home / "config.json").read_text())
    assert cfg["engine"] == "cursor_acp"
    for fname in ("SOUL.md", "AGENTS.md", "TOOLS.md"):
        assert (home / fname).read_text().strip()


def test_all_external_engine_kinds_scaffold_cleanly(tmp_path: Path) -> None:
    from rtxclaw_core.agents import default_scaffolds as ds

    for kind in ("claude_cli", "codex_cli", "antigravity_cli", "cursor_acp"):
        home = tmp_path / kind
        ds.write_scaffold(home, kind)
        assert (home / "config.json").exists()
        assert ds.soul_for(kind).strip()
        assert ds.tools_md_for(kind).strip()
        assert ds.agents_md_for(kind).strip()


# ---- integration: run_turn against an in-process stub ACP server ----


class _MemTransport(Transport):
    def __init__(self, inbox: "asyncio.Queue", outbox: "asyncio.Queue") -> None:
        self._in = inbox
        self._out = outbox
        self._closed = False

    async def read_message(self) -> bytes:
        item = await self._in.get()
        if item is None:
            raise JsonRpcFramingError("EOF before any header bytes")
        return item

    async def write_message(self, payload: bytes) -> None:
        await self._out.put(bytes(payload))

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        await self._out.put(None)


class _DummyProc:
    def __init__(self, task: "asyncio.Task[Any]") -> None:
        self._task = task
        self.returncode: int | None = None

    def terminate(self) -> None:
        self._task.cancel()

    def kill(self) -> None:
        self._task.cancel()


class _StubBackend:
    def __init__(self, updates: list[dict], models: dict | None = None) -> None:
        self._updates = updates
        self._models = models
        self.prompts: list[list[dict]] = []
        self.modes: list[str] = []

    async def initialize(self, protocol_version, client_caps, client_info) -> None:
        return None

    async def new_session(self, cwd, mcp_servers) -> dict:
        out = {"sessionId": "sess-1",
               "modes": {"availableModes": [{"id": "agent", "name": "Agent"}],
                         "currentModeId": "agent"}}
        if self._models is not None:
            out["models"] = self._models
        return out

    async def load_session(self, session_id, cwd, mcp_servers) -> dict:
        out = {"modes": {"availableModes": [{"id": "agent", "name": "Agent"}],
                         "currentModeId": "agent"}}
        if self._models is not None:
            out["models"] = self._models
        return out

    async def set_mode(self, session_id, mode_id) -> None:
        self.modes.append(mode_id)

    async def prompt(self, session_id, message_id, blocks) -> AsyncIterator[dict]:
        self.prompts.append(blocks)
        for upd in self._updates:
            yield upd
        yield {"stopReason": "end_turn"}

    async def cancel(self, session_id, *, force: bool = False) -> None:
        return None


_AGENT_CAPS = {"loadSession": True,
               "promptCapabilities": {"image": False, "audio": False, "embeddedContext": False}}


def _spawn_factory(backend: _StubBackend):
    async def spawn(cmd, *, cwd=None, env=None):
        q_c2s: asyncio.Queue = asyncio.Queue()
        q_s2c: asyncio.Queue = asyncio.Queue()
        server = AcpServer(_MemTransport(q_c2s, q_s2c), backend,
                           agent_capabilities=_AGENT_CAPS,
                           agent_info={"name": "stub", "version": "0"}, auth_methods=[])
        task = asyncio.create_task(server.serve_until_close())
        client = AcpClient(_MemTransport(q_s2c, q_c2s))
        await client.start()
        return client, _DummyProc(task)

    return spawn


def test_run_turn_streams_updates_and_persists(tmp_path: Path) -> None:
    backend = _StubBackend(updates=[
        {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "Hi "}},
        {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "there"}},
        {"sessionUpdate": "tool_call", "toolCallId": "t1", "title": "Bash",
         "kind": "execute", "status": "in_progress", "rawInput": {"command": "ls"}},
        {"sessionUpdate": "tool_call_update", "toolCallId": "t1", "status": "completed",
         "content": [{"type": "content", "content": {"type": "text", "text": "out.txt"}}]},
    ])
    eng = AcpEngine(command=["stub-acp"], name="stub", spawn_fn=_spawn_factory(backend))
    state = EngineSessionState(rtxclaw_session_id="s1", engine=EngineKind.ACP)
    req = TurnRequest(prompt="list", mode="auto", cwd=str(tmp_path),
                      system_prompt="SOUL", system_prompt_sha256="sha1")

    async def run() -> list:
        return [ev async for ev in eng.run_turn(req, state, sessions_dir=tmp_path, turn_id="t1")]

    events = asyncio.run(run())
    assert isinstance(events[0], TurnStarted)
    deltas = [e for e in events if isinstance(e, TextDelta)]
    assert "".join(d.text for d in deltas if d.channel == "content") == "Hi there"
    assert any(isinstance(e, ToolCallStarted) and e.name == "Bash" for e in events)
    assert any(isinstance(e, ToolCallResult) and e.ok and e.content == "out.txt" for e in events)
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"
    assert events[-1].engine_session_id == "sess-1"
    # generic engine passes the mode through unchanged
    assert backend.modes == ["auto"]
    sidecar = json.loads(eng.state_path(tmp_path, "s1").read_text())
    assert sidecar["engine_session_id"] == "sess-1" and sidecar["priming_status"] == "completed"


def test_cursor_subclass_maps_mode_and_captures_model_end_to_end(tmp_path: Path) -> None:
    backend = _StubBackend(
        updates=[{"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "ok"}}],
        models={"currentModelId": "composer-2.5[fast=true]",
                "availableModels": [{"modelId": "composer-2.5[fast=true]", "name": "composer-2.5"}]},
    )
    eng = CursorAcpEngine(spawn_fn=_spawn_factory(backend))
    state = EngineSessionState(rtxclaw_session_id="s1", engine=EngineKind.CURSOR_ACP)
    req = TurnRequest(prompt="hi", mode="auto", cwd=str(tmp_path),
                      system_prompt="SOUL", system_prompt_sha256="sha1")

    async def run() -> list:
        return [ev async for ev in eng.run_turn(req, state, sessions_dir=tmp_path, turn_id="t1")]

    events = asyncio.run(run())
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"
    # Cursor quirk: rtxclaw "auto" reached the server as "agent".
    assert backend.modes == ["agent"]
    # Model captured from the protocol and cleaned of the [fast=true] suffix.
    assert eng.display_model() == "composer-2.5"
    assert events[-1].metrics.get("model") == "composer-2.5"


def test_ctx_estimate_emitted_and_accumulates(tmp_path: Path) -> None:
    # ACP servers don't report token usage, so the engine emits an
    # ESTIMATED context size (prompt_tokens) — without it the footer's
    # ctx meter shows "—". It must accumulate turn-over-turn.
    backend = _StubBackend(updates=[
        {"sessionUpdate": "agent_message_chunk",
         "content": {"type": "text", "text": "hello there, this is a reply"}},
    ])
    eng = AcpEngine(command=["stub-acp"], name="stub", spawn_fn=_spawn_factory(backend))
    state = EngineSessionState(rtxclaw_session_id="s1", engine=EngineKind.ACP)
    req = TurnRequest(prompt="a question", mode="auto", cwd=str(tmp_path),
                      system_prompt="SYSTEM-PROMPT-TEXT", system_prompt_sha256="sha1")

    async def one_turn(turn_id: str):
        done = None
        async for ev in eng.run_turn(req, state, sessions_dir=tmp_path, turn_id=turn_id):
            if isinstance(ev, TurnDone):
                done = ev
        return done

    d1 = asyncio.run(one_turn("t1"))
    d2 = asyncio.run(one_turn("t2"))

    assert d1.metrics["tokens_estimated"] is True
    assert d1.metrics["prompt_tokens"] > 0          # ctx is now counted
    assert d1.metrics["completion_tokens"] > 0
    # Cumulative context estimate grows as the conversation grows.
    assert d2.metrics["prompt_tokens"] > d1.metrics["prompt_tokens"]

    # And the usage_update path that feeds the footer fires for it.
    from rtxclaw_core.agents.acp_translation import _usage_update_from_metrics
    uu = _usage_update_from_metrics(d2.metrics, context_window=262144)
    assert uu is not None and uu["used"] == d2.metrics["prompt_tokens"]


def test_parse_model_context_window() -> None:
    from rtxclaw_core.agents.acp_engine import _parse_model_context
    assert _parse_model_context("gpt-5.5[context=272k,reasoning=medium]") == 272000
    assert _parse_model_context("claude-opus-4-7[thinking=true,context=300k]") == 300000
    assert _parse_model_context("grok-4.3[context=200k]") == 200000
    assert _parse_model_context("composer-2.5[fast=true]") == 0   # no context field
    assert _parse_model_context("") == 0


def test_cursor_context_window_default_and_config(tmp_path: Path) -> None:
    # Cursor doesn't advertise composer's window → default to 200k.
    assert CursorAcpEngine().context_window() == 200_000
    # Per-agent config overrides the default.
    home = tmp_path / "cur"
    home.mkdir()
    (home / "config.json").write_text(json.dumps(
        {"engine": "cursor_acp", "acp_context_window": 300000}))

    class _Cfg:
        name = "cur"

        @property
        def home(self):
            return home

    assert CursorAcpEngine(_Cfg()).context_window() == 300000


def test_generic_context_window_unknown_is_zero() -> None:
    # Generic ACP engine: 0 (unknown) → agent layer uses global default.
    assert AcpEngine(command=["x"]).context_window() == 0
    # A model-id-parsed window wins once captured.
    e = AcpEngine(command=["x"])
    e._cached_context_window = 272000
    assert e.context_window() == 272000


def test_real_usage_update_overrides_estimate(tmp_path: Path) -> None:
    # When the ACP server reports real usage (ACP session-usage RFD),
    # use it verbatim instead of the char estimate.
    backend = _StubBackend(updates=[
        {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "hi"}},
        {"sessionUpdate": "usage_update", "used": 54321, "size": 200000},
    ])
    eng = AcpEngine(command=["stub"], name="stub", spawn_fn=_spawn_factory(backend))
    state = EngineSessionState(rtxclaw_session_id="s1", engine=EngineKind.ACP)
    req = TurnRequest(prompt="hi", mode="auto", cwd=str(tmp_path),
                      system_prompt="S", system_prompt_sha256="x")

    async def run():
        done = None
        async for ev in eng.run_turn(req, state, sessions_dir=tmp_path, turn_id="t1"):
            if isinstance(ev, TurnDone):
                done = ev
        return done

    d = asyncio.run(run())
    assert d.metrics["prompt_tokens"] == 54321        # REAL, not estimate
    assert d.metrics["tokens_estimated"] is False
    assert d.metrics["context_window"] == 200000
