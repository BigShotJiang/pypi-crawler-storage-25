"""Unit tests for the Telegram ``/steer`` routing decision.

``tests/test_10_telegram_commands.py`` is integration-only (telethon +
a live Telegram connection), so it cannot run in the sandbox. These
tests exercise ``AcpTelegramBot._dispatch_steer`` in isolation by
constructing a bare instance (``__new__``) and stubbing its
collaborators — verifying which backend each engine/turn state selects:

* local-LLM turn in flight → ``session/inject_user_message`` (true steer);
* CLI-bridge turn in flight → graceful ``cancel_chat`` then re-dispatch;
* no turn in flight → plain dispatch as a normal message;
* empty ``/steer`` → usage reply, no dispatch.
"""
import pytest

from rtxclaw_telegram.bot import AcpTelegramBot


class _FakeLock:
    def __init__(self, locked: bool) -> None:
        self._locked = locked

    def locked(self) -> bool:
        return self._locked


class _FakeClient:
    def __init__(self) -> None:
        self.injected: list[tuple[str, str]] = []

    async def session_inject_user_message(self, sid: str, text: str):
        self.injected.append((sid, text))
        return {"ok": True, "queued": True}


class _AgentCfg:
    def __init__(self, engine: str) -> None:
        self.engine = engine


def _make_bot(*, engine: str, locked: bool, sid: str = "sid-1"):
    """Bare bot with just the collaborators ``_dispatch_steer`` touches."""
    bot = AcpTelegramBot.__new__(AcpTelegramBot)
    client = _FakeClient()
    calls: dict[str, list] = {
        "replies": [], "cancel": [], "dispatch": [], "client": client,
    }

    bot.get_session_id = lambda c, t: sid
    bot._agent_cfg = lambda c, t: _AgentCfg(engine)
    bot.chat_lock = lambda c, t: _FakeLock(locked)
    bot._clients = {"42": client}

    async def _cancel_chat(chat_id, thread_id, *, via="stop"):
        calls["cancel"].append(via)
        return True, False

    async def _handle_text_message(chat_id, text, *, thread_id=None):
        calls["dispatch"].append(text)
        return "reply-body"

    async def _reply(chat_id, text, thread_id):
        calls["replies"].append(text)

    bot.cancel_chat = _cancel_chat
    bot.handle_text_message = _handle_text_message
    bot._reply = _reply
    return bot, calls


async def _reply_capture(store):
    async def _reply(text: str):
        store.append(text)
    return _reply


@pytest.mark.asyncio
async def test_local_llm_live_turn_injects():
    bot, calls = _make_bot(engine="", locked=True)
    cmd_replies: list[str] = []

    async def reply(text):
        cmd_replies.append(text)

    await bot._dispatch_steer(42, None, "pivot now", reply)

    assert calls["client"].injected == [("sid-1", "pivot now")]
    assert calls["dispatch"] == []          # no normal dispatch
    assert any("steering" in r for r in cmd_replies)


@pytest.mark.asyncio
async def test_cli_bridge_live_turn_aborts_then_dispatches():
    bot, calls = _make_bot(engine="claude_cli", locked=True)
    cmd_replies: list[str] = []

    async def reply(text):
        cmd_replies.append(text)

    await bot._dispatch_steer(42, None, "new direction", reply)

    assert calls["cancel"] == ["steer"]                 # graceful abort fired
    assert calls["dispatch"] == ["new direction"]       # re-dispatched
    assert calls["client"].injected == []               # no inject for CLI


@pytest.mark.asyncio
async def test_no_live_turn_dispatches_normally():
    bot, calls = _make_bot(engine="", locked=False)
    cmd_replies: list[str] = []

    async def reply(text):
        cmd_replies.append(text)

    await bot._dispatch_steer(42, None, "just a prompt", reply)

    assert calls["dispatch"] == ["just a prompt"]
    assert calls["client"].injected == []
    assert calls["cancel"] == []


@pytest.mark.asyncio
async def test_empty_steer_shows_usage():
    bot, calls = _make_bot(engine="", locked=True)
    cmd_replies: list[str] = []

    async def reply(text):
        cmd_replies.append(text)

    await bot._dispatch_steer(42, None, "   ", reply)

    assert any("usage" in r.lower() for r in cmd_replies)
    assert calls["dispatch"] == []
    assert calls["client"].injected == []
