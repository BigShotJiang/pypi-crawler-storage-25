"""Regression: two concurrent CLI-engine turns must not cross-wire sidecars.

Pre-refactor ``ExternalCliEngine.run_turn`` mutated process-wide
``os.environ["RTXCLAW_SESSION_ID"]`` / ``RTXCLAW_SESSIONS_DIR`` to convey
session identity to the legacy ``run_delegate_<cli>_async`` runner. Two
TUIs against the same agent (one ``AgentACPBackend`` instance in the
gateway) shared that env: turn B's mutation overrode turn A's, and turn
A then wrote its CLI ``--resume`` id into turn B's sidecar.

Fix: identity flows through ``args["_rtxclaw_session_id"]`` /
``_rtxclaw_sessions_dir`` / ``_rtxclaw_permission_mode``.

This file has two tiers of coverage:

* The first two tests exercise the new contract directly against
  ``run_delegate_claude_async``, which is what the engine's
  ``delegate_runner`` calls. They prove the runner honours args.

* The third test exercises the full ``ExternalCliEngine.run_turn``
  pipeline end-to-end. This is the level that would catch a regression
  where someone reintroduces ``os.environ`` mutation in the engine
  layer — the runner-level tests above would still pass in that case
  because the args are still wired correctly. (codex review of PR #181)
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from pathlib import Path

from rtxclaw_core.tools.runners import run_delegate_claude_async


def _fake_claude(bin_dir: Path) -> None:
    """Install a deterministic ``claude`` stub on PATH.

    Echoes a fresh stream-json session per invocation tagged with the
    rtxclaw sid embedded in the prompt. The 80ms sleep is enough to
    overlap two concurrent runs reliably without slowing the suite.
    """
    bin_dir.mkdir(parents=True, exist_ok=True)
    stub = bin_dir / "claude"
    stub.write_text(
        """#!/usr/bin/env python3
import json
import sys
import time

stdin_data = sys.stdin.read()
# The prompt embeds the caller's rtxclaw sid so we can produce a
# distinct claude session id per run.
tag = "unknown"
for line in stdin_data.splitlines():
    if line.startswith("RTXSID="):
        tag = line.split("=", 1)[1]
        break

time.sleep(0.08)

print(json.dumps({
    "type": "assistant",
    "session_id": f"claude-session-{tag}",
    "message": {"content": [{"type": "text", "text": f"ok for {tag}"}]},
}), flush=True)
print(json.dumps({
    "type": "result",
    "session_id": f"claude-session-{tag}",
    "is_error": False,
}), flush=True)
""",
        encoding="utf-8",
    )
    stub.chmod(0o755)


def test_concurrent_runs_write_distinct_sidecars(tmp_path, monkeypatch) -> None:
    """Two run_delegate_claude_async calls in parallel — different
    ``_rtxclaw_session_id`` args — must each persist their own
    ``<sid>.delegate_claude.json`` without cross-wiring.
    """
    _fake_claude(tmp_path / "bin")
    monkeypatch.setenv("PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}")
    # NOTE: deliberately do NOT set RTXCLAW_SESSION_ID / RTXCLAW_SESSIONS_DIR
    # in env — the new contract carries them through args. If a regression
    # reintroduces env-mutation, this test will still fail because the
    # sidecar paths derive from args.
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    sid_a, sid_b = "rtx-aaaa", "rtx-bbbb"

    async def _run(sid: str):
        return await run_delegate_claude_async({
            "prompt": f"hello\nRTXSID={sid}\n",
            "_rtxclaw_session_id": sid,
            "_rtxclaw_sessions_dir": str(sessions_dir),
            "_rtxclaw_permission_mode": "auto",
        })

    async def _both():
        return await asyncio.gather(_run(sid_a), _run(sid_b))

    res_a, res_b = asyncio.run(_both())
    assert res_a.ok and res_b.ok, (res_a.content, res_b.content)
    # The body should carry the per-sid stub response. The header truncates
    # claude's session id to 12 chars so we don't anchor on that; the body
    # text ("ok for <sid>") is the authoritative cross-wire check.
    assert f"ok for {sid_a}" in res_a.content
    assert f"ok for {sid_b}" in res_b.content

    sidecar_a = sessions_dir / f"{sid_a}.delegate_claude.json"
    sidecar_b = sessions_dir / f"{sid_b}.delegate_claude.json"
    assert sidecar_a.exists(), "sid A sidecar missing — args not honoured"
    assert sidecar_b.exists(), "sid B sidecar missing — args not honoured"

    data_a = json.loads(sidecar_a.read_text(encoding="utf-8"))
    data_b = json.loads(sidecar_b.read_text(encoding="utf-8"))
    assert data_a == {"claude_session_id": f"claude-session-{sid_a}"}
    assert data_b == {"claude_session_id": f"claude-session-{sid_b}"}


def test_args_override_env_when_both_present(tmp_path, monkeypatch) -> None:
    """When the engine passes args AND env happens to be set
    (e.g. a stale leak from an unrelated path), args must win — the
    write must land in the args-identified sidecar, not the env one.
    """
    _fake_claude(tmp_path / "bin")
    monkeypatch.setenv("PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}")

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    wrong_sid = "rtx-WRONG-from-env"
    right_sid = "rtx-RIGHT-from-args"

    # Simulate a contaminated env from some other agent / sibling turn.
    monkeypatch.setenv("RTXCLAW_SESSION_ID", wrong_sid)
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(sessions_dir))
    monkeypatch.setenv("RTXCLAW_PERMISSION_MODE", "ask")

    async def _run():
        return await run_delegate_claude_async({
            "prompt": f"hi\nRTXSID={right_sid}\n",
            "_rtxclaw_session_id": right_sid,
            "_rtxclaw_sessions_dir": str(sessions_dir),
            "_rtxclaw_permission_mode": "auto",
        })

    res = asyncio.run(_run())
    assert res.ok, res.content

    right_sidecar = sessions_dir / f"{right_sid}.delegate_claude.json"
    wrong_sidecar = sessions_dir / f"{wrong_sid}.delegate_claude.json"
    assert right_sidecar.exists(), "args-identified sidecar must be written"
    assert not wrong_sidecar.exists(), (
        "env-identified sidecar must NOT be written when args are set"
    )


# ---- engine-level coverage -----------------------------------------------
#
# The two tests above exercise ``run_delegate_claude_async`` directly. They
# don't catch a regression where the engine layer reintroduces
# ``os.environ`` mutation: even if ``ExternalCliEngine.run_turn`` started
# writing env again, the runner-level args would still be correct and the
# above sidecar checks would still pass.
#
# This test drives the full ``ExternalCliEngine.run_turn`` pipeline for
# two concurrent sids on the same engine instance — the exact shape of
# the bug PR #181 fixed — and asserts both that ``os.environ`` is
# unchanged from before the run AND that each ``<sid>.claude_cli.json``
# (the normalized state file the engine writes via :meth:`write_state`)
# carries its own ``engine_session_id``.


def _fake_claude_with_barrier(bin_dir: Path, barrier_dir: Path) -> None:
    """Stub that emits a unique session id per call.

    The barrier handshake guarantees overlap: each invocation drops a
    ``<tag>.ready`` file under ``barrier_dir`` and then blocks until two
    such files exist before it emits its result. If
    ``ExternalCliEngine.run_turn`` serialised concurrent turns (or this
    test only ran one at a time), the second process would never see the
    second .ready and the test would hang — caught by pytest-timeout.
    """
    bin_dir.mkdir(parents=True, exist_ok=True)
    stub = bin_dir / "claude"
    stub.write_text(
        """#!/usr/bin/env python3
import json
import os
import sys
import time

stdin_data = sys.stdin.read()
tag = "unknown"
for line in stdin_data.splitlines():
    if line.startswith("RTXSID="):
        tag = line.split("=", 1)[1]
        break

barrier_dir = os.environ.get("STUB_BARRIER_DIR", "")
if barrier_dir:
    with open(os.path.join(barrier_dir, f"{tag}.ready"), "w") as fp:
        fp.write("ready")
    # Wait for the sibling turn to also reach this point. 10s cap so a
    # serialised-engine regression fails fast under pytest-timeout
    # rather than wedging the suite.
    deadline = time.time() + 10.0
    while time.time() < deadline:
        if len([f for f in os.listdir(barrier_dir) if f.endswith('.ready')]) >= 2:
            break
        time.sleep(0.02)

# Stub doesn't read os.environ for any RTXCLAW_* key — its session id is
# derived purely from the rtx sid embedded in the prompt. That keeps
# the test's signal cleanly attributable to engine-level wiring, not
# subprocess env inheritance.
print(json.dumps({
    "type": "assistant",
    "session_id": f"claude-session-{tag}",
    "message": {"content": [{"type": "text", "text": f"ok for {tag}"}]},
}), flush=True)
print(json.dumps({
    "type": "result",
    "session_id": f"claude-session-{tag}",
    "is_error": False,
}), flush=True)
""",
        encoding="utf-8",
    )
    stub.chmod(0o755)


def test_engine_run_turn_concurrent_sids_no_env_mutation(
    tmp_path, monkeypatch,
) -> None:
    """End-to-end engine pipeline: two concurrent ``run_turn`` calls on
    the same ``ClaudeCliEngine`` instance with different sids must:

    1. Not mutate the parent process's ``os.environ``.
    2. Persist each sid's CLI session id to its OWN
       ``<sid>.claude_cli.json`` normalized state file.
    3. Persist each sid's CLI session id to its OWN legacy
       ``<sid>.delegate_claude.json`` sidecar.
    """
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import (
        EngineKind, EngineSessionState, TurnDone, TurnRequest,
    )

    barrier_dir = tmp_path / "barrier"
    barrier_dir.mkdir()
    _fake_claude_with_barrier(tmp_path / "bin", barrier_dir)

    monkeypatch.setenv("PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.setenv("STUB_BARRIER_DIR", str(barrier_dir))
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()

    engine = ClaudeCliEngine()  # single instance, shared across both turns
    sid_a, sid_b = "rtx-eng-aaaa", "rtx-eng-bbbb"

    def _state(sid: str) -> EngineSessionState:
        # priming_status="completed" so system_prompt_policy returns
        # "never" — no first-turn priming. Keeps the test focused on the
        # concurrent-resume codepath where the env race actually bit.
        return EngineSessionState(
            rtxclaw_session_id=sid,
            engine=EngineKind.CLAUDE_CLI,
            priming_status="completed",
        )

    def _request(sid: str) -> TurnRequest:
        return TurnRequest(
            prompt=f"hello\nRTXSID={sid}\n",
            mode="auto",
        )

    async def _drain_turn(sid: str) -> str:
        terminal: str = "none"
        async for ev in engine.run_turn(
            _request(sid), _state(sid),
            sessions_dir=sessions_dir,
            turn_id=f"turn-{sid}",
        ):
            if isinstance(ev, TurnDone):
                terminal = ev.state
        return terminal

    # Snapshot env so we can prove the engine doesn't mutate it.
    env_before = dict(os.environ)

    async def _both():
        return await asyncio.gather(_drain_turn(sid_a), _drain_turn(sid_b))

    a_state, b_state = asyncio.run(_both())
    assert a_state == "ok", a_state
    assert b_state == "ok", b_state

    env_after = dict(os.environ)
    # If a regression reintroduces os.environ mutation in run_turn, this
    # comparison fires — even on a single-threaded run, the finally-block
    # restore can leak when the turn aborts.
    assert env_before == env_after, (
        "ExternalCliEngine.run_turn must not mutate os.environ; "
        f"added: {set(env_after) - set(env_before)} "
        f"removed: {set(env_before) - set(env_after)}"
    )

    # Normalized state files — the engine's write_state output.
    for sid in (sid_a, sid_b):
        norm = sessions_dir / f"{sid}.claude_cli.json"
        assert norm.exists(), f"normalized state for {sid} missing"
        data = json.loads(norm.read_text(encoding="utf-8"))
        assert data.get("rtxclaw_session_id") == sid
        assert data.get("engine_session_id") == f"claude-session-{sid}", (
            f"cross-wired engine_session_id on {sid}: {data}"
        )

    # Legacy sidecars — written by run_delegate_claude_async via
    # _write_claude_session_id. Same cross-wire check at the runner level.
    for sid in (sid_a, sid_b):
        legacy = sessions_dir / f"{sid}.delegate_claude.json"
        assert legacy.exists(), f"legacy sidecar for {sid} missing"
        data = json.loads(legacy.read_text(encoding="utf-8"))
        assert data == {"claude_session_id": f"claude-session-{sid}"}, (
            f"cross-wired legacy sidecar on {sid}: {data}"
        )
