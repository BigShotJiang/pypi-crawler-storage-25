"""Step 19 — MCP client config + namespace round-trip coverage.

The MCP client lives in ``src/rtxclaw_mcp/mcp_client.py``. It owns:

* ``MCPServerConfig.from_dict`` — config-row validation (stdio /
  http / sse).
* ``load_mcp_servers`` — accepts both ``mcpServers`` (canonical
  Claude Code key) and ``mcp_servers`` (legacy snake_case).
* ``mcp_tool_namespaced`` / ``parse_mcp_namespaced`` — the
  ``mcp__<server>__<tool>`` round-trip used by the model's tool
  registry to invoke server-specific tools without meta-tool
  detours.

This test file pins the config + namespacing surface so a regression
in any of those (a frequent flashpoint when adding new MCP transports
or renaming the namespacing convention) trips here, not at the live
discovery boot path.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_mcp.mcp_client import (
    MCPServerConfig,
    load_mcp_servers,
    mcp_tool_namespaced,
    parse_mcp_namespaced,
)


@pytest.fixture(autouse=True)
def _isolated_home(tmp_path, monkeypatch):
    # load_mcp_servers unconditionally reads
    # ``~/.claude/.mcp.json`` and ``~/.claude/mcp.json`` via
    # ``Path.home()`` (mcp_client.py:205-206, 271-272). Without this
    # isolation the "empty input → empty result" tests below leak
    # ambient state from the operator's real ``~/.claude`` and pass
    # or fail per-host. Point ``Path.home`` at a clean tmp dir so
    # every test runs against a known-empty filesystem.
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    yield


# ---- MCPServerConfig.from_dict --------------------------------------


def test_stdio_default_transport_when_command_present() -> None:
    cfg = MCPServerConfig.from_dict("yt", {
        "command": "python",
        "args": ["-m", "rtxclaw_mcp.youtube_mcp_server"],
    })
    assert cfg.transport == "stdio"
    assert cfg.command == "python"
    assert cfg.args == ("-m", "rtxclaw_mcp.youtube_mcp_server")


def test_http_default_transport_when_url_present() -> None:
    cfg = MCPServerConfig.from_dict("svc", {"url": "http://localhost:7000"})
    assert cfg.transport == "http"
    assert cfg.url == "http://localhost:7000"


def test_explicit_transport_wins() -> None:
    cfg = MCPServerConfig.from_dict("svc", {
        "transport": "sse",
        "url": "http://localhost:8000/sse",
    })
    assert cfg.transport == "sse"


def test_stdio_without_command_raises() -> None:
    with pytest.raises(ValueError, match="missing transport"):
        MCPServerConfig.from_dict("svc", {})


def test_http_without_url_raises() -> None:
    with pytest.raises(ValueError, match="requires `url`"):
        MCPServerConfig.from_dict("svc", {"transport": "http"})


def test_unknown_transport_raises() -> None:
    with pytest.raises(ValueError, match="unknown transport"):
        MCPServerConfig.from_dict("svc", {
            "transport": "carrier-pigeon", "url": "http://x",
        })


def test_env_strings_coerce() -> None:
    """env values that arrive as ints / non-strings (legacy configs)
    should be coerced to strings rather than raising — the subprocess
    spawn would otherwise crash later with an opaque type error."""
    cfg = MCPServerConfig.from_dict("svc", {
        "command": "echo", "env": {"PORT": 8080, "MODE": "fast"},
    })
    assert cfg.env == {"PORT": "8080", "MODE": "fast"}


# ---- load_mcp_servers -----------------------------------------------


def test_load_accepts_camel_case_key() -> None:
    out = load_mcp_servers({
        "mcpServers": {
            "yt": {"command": "python", "args": ["-m", "rtxclaw_mcp.yt"]},
        },
    })
    assert "yt" in out
    assert out["yt"].command == "python"


def test_load_accepts_snake_case_key() -> None:
    out = load_mcp_servers({
        "mcp_servers": {
            "yt": {"command": "python"},
        },
    })
    assert "yt" in out


def test_camel_case_wins_over_snake_case() -> None:
    """Standard key wins. We expose the new server, not the legacy one."""
    out = load_mcp_servers({
        "mcpServers": {"new": {"command": "newcmd"}},
        "mcp_servers": {"old": {"command": "oldcmd"}},
    })
    assert "new" in out
    assert "old" not in out


def test_malformed_row_dropped_silently() -> None:
    """One bad row mustn't take out other servers' configs."""
    out = load_mcp_servers({
        "mcpServers": {
            "good": {"command": "echo"},
            "bad": {"transport": "carrier-pigeon"},  # invalid — dropped
        },
    })
    assert "good" in out
    assert "bad" not in out


def test_load_empty_when_no_key() -> None:
    assert load_mcp_servers({}) == {}


def test_load_empty_when_value_not_dict() -> None:
    assert load_mcp_servers({"mcpServers": "not-a-dict"}) == {}


# ---- namespacing round-trip -----------------------------------------


def test_namespacing_round_trip() -> None:
    name = mcp_tool_namespaced("youtube", "transcribe_youtube")
    assert name == "mcp__youtube__transcribe_youtube"
    parsed = parse_mcp_namespaced(name)
    assert parsed == ("youtube", "transcribe_youtube")


def test_parse_returns_none_for_non_mcp_name() -> None:
    assert parse_mcp_namespaced("memory_search") is None
    assert parse_mcp_namespaced("mcp__yt") is None  # missing tool half
    assert parse_mcp_namespaced("") is None


def test_parse_handles_tool_with_underscores() -> None:
    """Tool names often contain underscores — the splitter must only
    consume the FIRST namespace separator and let the rest land in the
    tool slot."""
    parsed = parse_mcp_namespaced("mcp__markitdown__convert_to_markdown")
    assert parsed == ("markitdown", "convert_to_markdown")
