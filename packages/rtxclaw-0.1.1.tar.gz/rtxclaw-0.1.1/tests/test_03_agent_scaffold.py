"""Step 03 — agent scaffold (configure + agent init + agent list)."""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from conftest import RTXCLAW_BIN

# NOT marked slow. test_03..06 are the boot+smoke chain that
# tests/select-affected.sh::ALWAYS_RUN forces into every tier-1 run.
# Marking them slow would let `-m "not slow"` silently filter them out,
# defeating the belt-and-suspenders against daemon-shape regressions
# (e.g. the wt_ms TURN_METRICS drop). The full suite (tier-3) runs them
# regardless of markers.


def test_configure_writes_global_config(
    run_rtxclaw, sandbox_home: Path, configured_endpoint: str, configured_model: str,
) -> None:
    cfg = sandbox_home / "config.json"
    if cfg.exists():
        cfg.unlink()
    cp = run_rtxclaw("configure", "--endpoint", configured_endpoint, "--model", configured_model)
    assert cp.returncode == 0, cp.stderr
    assert cfg.exists()
    body = json.loads(cfg.read_text())
    assert body.get("upstream_endpoint") == configured_endpoint
    assert body.get("upstream_model") == configured_model


def test_agent_init_creates_main(
    run_rtxclaw, sandbox_env, sandbox_home: Path, configured_endpoint: str, configured_model: str,
) -> None:
    agent_dir = sandbox_home / "agents" / "main"
    if agent_dir.exists():
        shutil.rmtree(agent_dir)
    # Make sure global config exists so init has an endpoint/model to copy.
    if not (sandbox_home / "config.json").exists():
        run_rtxclaw("configure", "--endpoint", configured_endpoint, "--model", configured_model)
    cp = subprocess.run(
        [str(RTXCLAW_BIN), "agent", "init", "main"],
        env=sandbox_env, input="", capture_output=True, text=True, timeout=60,
    )
    assert cp.returncode == 0, f"agent init failed:\n{cp.stderr}"
    assert agent_dir.is_dir()
    assert (agent_dir / "config.json").is_file()


def test_agent_list_shows_main(scaffolded_agent: Path, run_rtxclaw) -> None:
    cp = run_rtxclaw("agent", "list")
    assert cp.returncode == 0, cp.stderr
    combined = cp.stdout + cp.stderr
    assert "main" in combined, combined
