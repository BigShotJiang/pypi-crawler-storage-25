"""Step 59 — ``LocalLLMEngine.set_config_option('model', alias)`` must
update the global cfg consistently.

Regression for the "tb07/deepseek HTTP 404" bug: after the user issued
``/model deepseek`` against a long-lived gateway, the next fresh
session (TUI ``/new``, heartbeat session creation) inherited
``cfg.upstream_model = "deepseek"`` (the ALIAS) paired with
``cfg.upstream_endpoint = "http://192.168.0.70:8001/v1"`` (the stale
tb07 endpoint), and tb07's vLLM rejected the request with::

    HTTP 404: {"error":{"message":"The model deepseek does not exist."}}

The bridge's per-session swap was correct (``sess.model = row.id``,
``sess.endpoint = row.baseUrl``), but the engine's earlier mutation of
the GLOBAL cfg used the alias string and never updated the endpoint.
This suite pins the corrected behaviour: alias → row.id /
row.baseUrl / alias triple, atomically.
"""
from __future__ import annotations

import asyncio
import types

import pytest

from rtxclaw_core.agents.local_llm import LocalLLMEngine


def _engine_with_models() -> LocalLLMEngine:
    cfg = types.SimpleNamespace(
        upstream_max_context=8000,
        permission_mode="auto",
        reasoning_visibility="off",
        upstream_model="qwen3.6-27b-fp8",
        upstream_endpoint="http://192.168.0.70:8001/v1",
        upstream_alias="tb07",
        distill_max_recoveries=3,
        _max_rounds=20,
        models=[
            {
                "alias": "tb07",
                "baseUrl": "http://192.168.0.70:8001/v1",
                "id": "qwen3.6-27b-fp8",
                "backend": "vllm",
                "contextWindow": 262144,
            },
            {
                "alias": "deepseek",
                "baseUrl": "https://api.deepseek.com/v1",
                "id": "deepseek-v4-flash",
                "backend": "unknown",
                "contextWindow": 1000000,
            },
        ],
    )
    return LocalLLMEngine(cfg)


def test_set_model_uses_row_id_not_alias() -> None:
    """``cfg.upstream_model`` must be the wire id (``deepseek-v4-flash``),
    not the alias (``deepseek``). Storing the alias would propagate to
    fresh sessions and produce ``HTTP 404 The model deepseek does not
    exist`` against any endpoint that doesn't advertise that literal
    name."""
    eng = _engine_with_models()
    asyncio.run(eng.set_config_option("sid", "model", "deepseek"))
    assert eng.cfg.upstream_model == "deepseek-v4-flash"


def test_set_model_updates_endpoint_and_alias_together() -> None:
    """The full triple flips atomically. Without this, a fresh session
    after ``/model deepseek`` would still target the stale tb07
    endpoint and the model id would not match anything served there."""
    eng = _engine_with_models()
    asyncio.run(eng.set_config_option("sid", "model", "deepseek"))
    assert eng.cfg.upstream_endpoint == "https://api.deepseek.com/v1"
    assert eng.cfg.upstream_alias == "deepseek"


def test_set_model_unknown_alias_raises() -> None:
    """Unknown alias surfaces a ``ValueError`` so the bridge can echo
    a clean rejection to the frontend instead of silently flipping to
    a synthetic primary row."""
    eng = _engine_with_models()
    with pytest.raises(ValueError, match="unknown alias"):
        asyncio.run(eng.set_config_option("sid", "model", "no-such-alias"))
    # State must be unchanged after the failed switch.
    assert eng.cfg.upstream_model == "qwen3.6-27b-fp8"
    assert eng.cfg.upstream_endpoint == "http://192.168.0.70:8001/v1"
    assert eng.cfg.upstream_alias == "tb07"


def test_set_model_row_without_id_raises() -> None:
    """A model row missing ``id`` cannot be activated — auto-discovery
    via ``/v1/models`` was removed deliberately (acp_bridge.py L1838).
    Surface a clear error pointing at the config file."""
    cfg = types.SimpleNamespace(
        upstream_max_context=8000,
        permission_mode="auto",
        reasoning_visibility="off",
        upstream_model="qwen3.6-27b-fp8",
        upstream_endpoint="http://192.168.0.70:8001/v1",
        upstream_alias="tb07",
        distill_max_recoveries=3,
        _max_rounds=20,
        models=[
            {"alias": "incomplete", "baseUrl": "http://x/v1"},
        ],
    )
    eng = LocalLLMEngine(cfg)
    with pytest.raises(ValueError, match="no `id` configured"):
        asyncio.run(eng.set_config_option("sid", "model", "incomplete"))
