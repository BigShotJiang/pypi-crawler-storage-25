"""Step 17 — "Small models" config + fallback chain coverage.

Per operator request: "create a test called small models."

Today rtxclaw has THREE model alias slots that exist alongside the
primary upstream model:

* ``memory_flush_model`` — silent end-of-turn agentic flush before
  compaction. Cheap model so the cost of the flush is negligible.
* ``remember_synthesizer_model`` — used by ``remember target=memory``
  integrations. Falls back to ``memory_flush_model``, then to the
  primary upstream.
* The plan classifier + plan generator (``_should_run_plan_pass`` /
  ``_run_plan_pass``) — currently use the session's primary model
  but can be retargeted by environment overrides at the call site.

This test pins:
- AgentConfig defaults are empty strings (not ``None``) so JSON round-
  trip stays stable.
- The fallback chain works: when synthesizer is empty, flush is used;
  when both are empty, primary upstream is used.
- Loading + persisting a config preserves both knobs.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rtxclaw_core.agent import AgentConfig


def _resolve_synth_model(cfg: AgentConfig, primary: str) -> str:
    """Mirror the runtime fallback chain: synth → flush → primary.

    Pulled into a helper so the test is the source of truth for the
    fallback rule and a regression in the runner can be diffed against
    this docstring.
    """
    return (
        cfg.remember_synthesizer_model
        or cfg.memory_flush_model
        or primary
    )


def test_default_aliases_are_empty_strings() -> None:
    cfg = AgentConfig(name="test_agent")
    assert cfg.memory_flush_model == ""
    assert cfg.remember_synthesizer_model == ""


def test_synth_falls_back_to_flush() -> None:
    cfg = AgentConfig(
        name="test_agent",
        memory_flush_model="qwen2-1.5b",
    )
    assert _resolve_synth_model(cfg, "primary-7b") == "qwen2-1.5b"


def test_synth_overrides_flush_when_set() -> None:
    cfg = AgentConfig(
        name="test_agent",
        memory_flush_model="qwen2-1.5b",
        remember_synthesizer_model="gpt-4o-mini",
    )
    assert _resolve_synth_model(cfg, "primary-7b") == "gpt-4o-mini"


def test_synth_falls_through_to_primary_when_both_empty() -> None:
    cfg = AgentConfig(name="test_agent")
    assert _resolve_synth_model(cfg, "primary-7b") == "primary-7b"


def test_aliases_round_trip_json(tmp_path: Path) -> None:
    """Writing an AgentConfig to disk and re-reading must preserve
    both alias knobs unchanged."""
    cfg = AgentConfig(
        name="test_agent",
        memory_flush_model="qwen2-1.5b",
        remember_synthesizer_model="gpt-4o-mini",
    )
    raw = json.dumps({
        "memory_flush_model": cfg.memory_flush_model,
        "remember_synthesizer_model": cfg.remember_synthesizer_model,
    })
    parsed = json.loads(raw)
    cfg2 = AgentConfig(
        name="test_agent",
        memory_flush_model=parsed["memory_flush_model"],
        remember_synthesizer_model=parsed["remember_synthesizer_model"],
    )
    assert cfg.memory_flush_model == cfg2.memory_flush_model
    assert cfg.remember_synthesizer_model == cfg2.remember_synthesizer_model


def test_distiller_sampling_invariants() -> None:
    """The reasoning-loop distiller must use deterministic-leaning
    sampling so the structured handoff JSON is reliably parseable.

    Source of truth: ``turn_runtime.py`` — `temperature=0.2` is hard-
    coded inline; ``presence_penalty`` is read from the
    ``_DISTILL_PRESENCE_PENALTY`` module constant (env-overridable
    via ``RTXCLAW_DISTILL_PRESENCE_PENALTY``, defaulting to 1.0).
    A future "tune the distiller" PR should re-pin these on purpose.
    """
    from rtxclaw_core import turn_runtime as _tr
    src = Path(_tr.__file__).read_text(encoding="utf-8")
    assert '"temperature": 0.2' in src, (
        "distiller temperature drifted from 0.2 — verify this is intentional"
    )
    assert _tr._DISTILL_PRESENCE_PENALTY == 1.0, (
        f"distiller presence_penalty drifted from 1.0: "
        f"{_tr._DISTILL_PRESENCE_PENALTY}"
    )


@pytest.mark.parametrize(
    "alias",
    [
        "qwen2-1.5b-instruct",
        "gpt-4o-mini",
        "llama-3-8b-instruct",
        "phi-3-mini-4k-instruct",
    ],
)
def test_known_small_model_aliases_accept_as_string(alias: str) -> None:
    """Sanity: any opaque alias the operator chooses for the small-
    model slot must accept as a free-form string (no enum gating).

    Useful as a regression net if someone adds a Literal[] validator
    later that breaks BYO-model usage.
    """
    cfg = AgentConfig(
        name="test_agent",
        memory_flush_model=alias,
    )
    assert cfg.memory_flush_model == alias
