"""Step 76 — voice turn: the "🎙️ heard:" echo must render ABOVE the reply.

A voice/audio message produces two bubbles: the transcript echo
(`🎙️ heard: "…"`) and the agent's streamed reply. Telegram orders
messages by **message_id**, not by edit time.

The bug: `_stream_turn_for_chat` sent the "💭 thinking…" placeholder
first (lowest message_id), streamed the reply INTO that placeholder,
and sent the transcript echo as a *separate, later* message — giving
the echo a HIGHER message_id, so it landed BELOW the reply. The user
saw the reply first and "🎙️ heard: …" underneath it.

The fix reuses the first placeholder as the echo (it keeps its earlier
message_id) and opens a fresh placeholder for the reply (a later
message_id). So echo-above-reply holds by construction.

This test drives `_stream_turn_for_chat` with a fully faked Telegram
API + STT + dispatch, reconstructs each message's final text, and
asserts the echo's message_id is lower than the reply's.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_telegram.bot import AcpTelegramBot
from rtxclaw_telegram.config import TelegramConfig


class _FakeAPI:
    """Records sends/edits and hands out monotonically increasing
    message_ids — exactly the property Telegram uses to order bubbles."""

    def __init__(self) -> None:
        self._next = 100
        self.sends: list[tuple[int, str]] = []
        self.edits: list[tuple[int, str]] = []

    async def send_message(self, chat_id, text, *, message_thread_id=None,
                           parse_mode=None):
        mid = self._next
        self._next += 1
        self.sends.append((mid, text))
        return mid

    async def edit_message(self, chat_id, message_id, text):
        self.edits.append((message_id, text))
        return (True, 0.0)

    async def send_voice(self, *a, **k):
        return 9999

    def final_text(self) -> dict[int, str]:
        """Final on-screen text per message_id: last edit wins, else
        the original send."""
        out: dict[int, str] = {mid: txt for mid, txt in self.sends}
        for mid, txt in self.edits:
            out[mid] = txt
        return out


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    return tmp_path


@pytest.mark.asyncio
async def test_voice_echo_renders_above_reply(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    api = _FakeAPI()

    async def fake_download(file_id):
        return (b"FAKEAUDIOBYTES", "voice.m4a")

    async def fake_stt(audio_bytes, *, mime="", filename="", on_progress=None):
        return "bom dia pessoal vamos la"

    bot = AcpTelegramBot(
        TelegramConfig(default_agent="main"),
        acp_url="",
        trusted_chats=set(),
        api=api,
        stt=fake_stt,
        tts=None,
        download_audio=fake_download,
    )

    # Stand in for the ACP streaming turn: emit one chunk + return the
    # assembled reply (what finalize writes into the reply bubble).
    reply_text = "Here is the summary of what you said."

    async def fake_dispatch(chat_id, blocks, *, on_chunk=None,
                            on_tool_status=None, thread_id=None):
        if on_chunk is not None:
            await on_chunk(reply_text, force=True)
        return reply_text

    bot._dispatch_blocks = fake_dispatch  # type: ignore[assignment]

    await bot._stream_turn_for_chat(
        123, voice_file_id="file-xyz", voice_mime="audio/mp4",
    )

    final = api.final_text()
    heard_ids = [mid for mid, txt in final.items() if "heard" in txt]
    reply_ids = [mid for mid, txt in final.items() if reply_text in txt]

    assert heard_ids, f"no transcript-echo bubble found; messages={final}"
    assert reply_ids, f"no reply bubble found; messages={final}"

    # The whole point: the echo bubble must have a LOWER message_id than
    # the reply bubble, so Telegram renders it ABOVE the reply.
    assert max(heard_ids) < min(reply_ids), (
        "transcript echo must render above the reply: "
        f"heard_ids={heard_ids} reply_ids={reply_ids} messages={final}"
    )

    # And the transcript itself made it into the echo bubble.
    assert any("bom dia pessoal" in final[mid] for mid in heard_ids)
