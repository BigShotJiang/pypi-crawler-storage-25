"""Step 22 — LocalLLMEngine multi-round tool dispatch + Claude Code hooks.

``LocalLLMEngine.run_turn`` is the only turn architecture. This
suite is the contract test for the multi-round loop that dispatches
tool calls, runs the Claude Code hook lifecycle, and feeds tool
results back to the model.

Coverage (stub worker + stub tool runner — no real LLM, no
subprocess; safe to run on the host):
- A round that emits ``tool_calls`` actually dispatches: the engine
  yields ``PermissionRequested`` (the Agent resolves policy/ASK),
  runs the tool runner, appends the tool-result message, and runs a
  continuation round → ``TurnDone(state="ok")``.
- PreToolUse hook ``deny`` skips the tool (no runner call) and the
  model gets a ``[denied]`` result.
- PostToolUse hook ``additionalContext`` is folded into the
  tool-result message body (so it reaches the model, not just the
  transcript) — overcoming the documented limit.
- A PreToolUse hook ``permissionDecision: allow`` bypasses the
  permission policy (no ``PermissionRequested`` yielded).
- A denied PermissionRequested (the Agent says "deny") skips the
  tool and surfaces a ``[permission denied]`` result.

The async generator is driven directly; the test plays the Agent's
role by resolving each ``PermissionRequested``.
"""
from __future__ import annotations

import asyncio
import types
from pathlib import Path

from rtxclaw_core.agents.engine import (
    EngineKind,
    EngineSessionState,
    PermissionRequested,
    TextDelta,
    ToolCallResult,
    ToolCallStarted,
    TurnDone,
    TurnRequest,
)
from rtxclaw_core.agents.local_llm import LocalLLMEngine
from rtxclaw_core.hooks import HookEngine


# --------------------------------------------------------------------------
# Stubs
# --------------------------------------------------------------------------

class _Sess:
    hash = "tooltest01"
    endpoint = "http://stub/v1"
    model = "stub-model"
    workspace_cwd = ""
    system_prompt = ""
    turns: list = []


class _Turn:
    def __init__(self) -> None:
        self.proc = None
        self.metrics: dict = {}

    def stop(self) -> None:  # noqa: D401
        pass


def _make_engine(spawn, runner, cfg_extra=None):
    cfg = types.SimpleNamespace(
        upstream_max_context=8000,
        permission_mode="auto",
        reasoning_visibility="off",
        upstream_model="stub-model",
        distill_max_recoveries=3,
        _max_rounds=20,
    )
    for k, v in (cfg_extra or {}).items():
        setattr(cfg, k, v)
    eng = LocalLLMEngine(cfg, worker_spawner=spawn, tool_runner=runner)
    # Don't touch a real session file — the message list shape doesn't
    # matter to these tests, only the event flow.
    eng._build_messages_simple = (  # type: ignore[method-assign]
        lambda s, uc, sp, pre: [{"role": "user", "content": str(uc)}]
    )
    return eng


def _tool_call_round_then_done(
    tool_name="Bash", criticality="read_only", content="all done with the task",
):
    """A 2-round stub worker: round 0 emits one tool_call, round 1 finishes.

    ``content`` controls the round-1 final text. Default is ≥
    NUDGE_MIN_TEXT_CHARS (10) so the silent-nudge detector at
    local_llm.py:1874 does NOT fire a 3rd continuation round (most
    callers want the 2-round happy path). Tests that specifically
    exercise the silent-nudge branch (e.g.
    ``test_notification_hook_fires_on_runtime_warnings``) pass a
    shorter string (``"all done"`` = 8 chars).
    """
    state = {"n": 0}

    async def _spawn(engine, session, messages, turn_id, env):
        n = state["n"]
        state["n"] += 1

        async def _stream():
            if n == 0:
                yield {
                    "kind": "tool_calls",
                    "calls": [{
                        "id": "call-1",
                        "function": {
                            "name": tool_name,
                            "arguments": (
                                '{"command":"echo hi","criticality":"'
                                + criticality + '"}'
                            ),
                        },
                    }],
                }
                yield {"kind": "metrics", "finish_reason": "tool_calls"}
                yield {"kind": "done"}
            else:
                yield {"kind": "content", "text": content}
                yield {"kind": "metrics", "finish_reason": "stop"}
                yield {"kind": "done"}

        return _Turn(), _stream()

    return _spawn, state


def _run(eng, *, hook_engine=None, resolve="allow"):
    """Drive run_turn; play the Agent — resolve every PermissionRequested."""
    sess = _Sess()
    req = TurnRequest(
        prompt="do the thing", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": hook_engine,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )
    state = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )

    async def _go():
        events = []
        async for ev in eng.run_turn(
            req, state, sessions_dir=Path("/tmp"), turn_id="turn-1",
        ):
            events.append(ev)
            if isinstance(ev, PermissionRequested):
                ev.response.set_result(resolve)
        return events

    return asyncio.run(_go())


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------

def test_tool_call_round_dispatches_and_continues() -> None:
    """A tool_calls round runs the tool and a continuation round."""
    spawn, wstate = _tool_call_round_then_done()
    ran: list = []

    async def _runner(session_id, call, turn, **kw):
        ran.append(call)
        return (True, "hi\n", False, False)

    eng = _make_engine(spawn, _runner)
    events = _run(eng)
    kinds = [type(e).__name__ for e in events]
    assert "PermissionRequested" in kinds
    assert "ToolCallStarted" in kinds and "ToolCallResult" in kinds
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"
    assert len(ran) == 1, "tool runner should have been invoked exactly once"
    assert wstate["n"] == 2, "expected a tool round + a continuation round"


def test_pre_tool_use_hook_deny_skips_the_tool() -> None:
    """A PreToolUse hook that exits 2 denies the call — runner never runs."""
    spawn, _ = _tool_call_round_then_done()
    ran: list = []

    async def _runner(session_id, call, turn, **kw):
        ran.append(call)
        return (True, "should not happen", False, False)

    hooks = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [
            {"type": "command", "command": "echo 'no bash here' >&2; exit 2"},
        ]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    assert ran == [], "PreToolUse deny must skip the tool runner"
    tcr = [e for e in events if isinstance(e, ToolCallResult)]
    assert tcr and not tcr[0].ok
    assert "denied" in tcr[0].content.lower()
    # No PermissionRequested — the hook decided before policy.
    assert not any(isinstance(e, PermissionRequested) for e in events)


def test_post_tool_use_hook_injects_additional_context() -> None:
    """PostToolUse additionalContext lands in the tool-result message."""
    spawn, _ = _tool_call_round_then_done()

    async def _runner(session_id, call, turn, **kw):
        return (True, "raw tool output", False, False)

    hooks = HookEngine.from_dict({"hooks": {"PostToolUse": [
        {"matcher": "Bash", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":{"additionalContext":"INJECTED"}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    tcr = [e for e in events if isinstance(e, ToolCallResult)][0]
    assert "raw tool output" in tcr.content
    assert "INJECTED" in tcr.content, (
        "PostToolUse additionalContext must be folded into the result body"
    )


def test_pre_tool_use_hook_allow_bypasses_permission_policy() -> None:
    """permissionDecision:allow means no PermissionRequested is yielded."""
    spawn, _ = _tool_call_round_then_done()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":{"permissionDecision":"allow"}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    assert not any(isinstance(e, PermissionRequested) for e in events), (
        "a PreToolUse `allow` hook must bypass the permission policy"
    )
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"


def test_permission_denied_skips_the_tool() -> None:
    """When the Agent resolves PermissionRequested as deny, the tool is skipped."""
    spawn, _ = _tool_call_round_then_done(criticality="destructive")
    ran: list = []

    async def _runner(session_id, call, turn, **kw):
        ran.append(call)
        return (True, "should not happen", False, False)

    eng = _make_engine(spawn, _runner)
    events = _run(eng, resolve="deny")
    assert ran == [], "a denied PermissionRequested must skip the tool runner"
    tcr = [e for e in events if isinstance(e, ToolCallResult)]
    assert tcr and not tcr[0].ok
    assert "denied" in tcr[0].content.lower()


def test_pre_tool_use_hook_updated_input_rewrites_runner_args() -> None:
    """A PreToolUse hook that returns ``updatedInput`` mutates the tool
    args before the runner sees them — the canonical use case is a
    linter rewriting ``rm -rf`` into ``rm -rfI`` before dispatch."""
    spawn, _ = _tool_call_round_then_done()
    runner_args: list = []

    async def _runner(session_id, call, turn, **kw):
        runner_args.append(dict(call.get("arguments") or {}))
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":'
                '{"updatedInput":{"command":"echo rewritten",'
                '"criticality":"read_only"}}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    assert runner_args, "runner must have been invoked"
    assert runner_args[0].get("command") == "echo rewritten", (
        "PreToolUse updatedInput must reach the runner"
    )
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"


def test_subagent_stop_hook_fires_for_delegate_tools() -> None:
    """``delegate_*`` tools fire the ``SubagentStop`` hook (parent-side)
    with the child's name + tool_response in the payload, matching
    Claude Code's subagent lifecycle."""
    # Use a delegate_* tool name in the stub round.
    spawn, _ = _tool_call_round_then_done(tool_name="delegate_claude")
    captured_payload: list = []

    async def _runner(session_id, call, turn, **kw):
        return (True, "child agent reply text", False, False)

    # Self-inspecting hook: writes its stdin payload to a temp file,
    # which the test reads back to assert the SubagentStop fired.
    import os
    import tempfile
    fd, sink = tempfile.mkstemp(prefix="subagent_stop_", suffix=".json")
    os.close(fd)
    try:
        hooks = HookEngine.from_dict({"hooks": {"SubagentStop": [
            {"matcher": "*", "hooks": [{
                "type": "command",
                "command": f"cat > {sink}",
            }]},
        ]}})
        eng = _make_engine(spawn, _runner)
        _ = _run(eng, hook_engine=hooks)
        import json as _json
        with open(sink, "r", encoding="utf-8") as f:
            recorded = _json.load(f)
        captured_payload.append(recorded)
    finally:
        try:
            os.unlink(sink)
        except OSError:
            pass
    assert captured_payload, "SubagentStop must fire when delegate_* runs"
    p = captured_payload[0]
    assert p.get("hook_event_name") == "SubagentStop"
    assert p.get("subagent_name") == "claude"
    assert p.get("tool_name") == "delegate_claude"
    assert "child agent reply text" in str(p.get("tool_response") or "")
    assert p.get("state") == "ok"


def _loop_then_done():
    """Stub worker: round 0 emits tool_args_loop (immediate loop_detected),
    round 1 emits "all done" + clean stop.

    Used to exercise the ReasoningLoopDetected → distill/force-terminate
    cascade without needing to hit the 4k-char streaming-detector threshold.
    """
    state = {"n": 0}

    async def _spawn(engine, session, messages, turn_id, env):
        n = state["n"]
        state["n"] += 1

        async def _stream():
            if n == 0:
                yield {"kind": "thinking", "text": "thinking thinking"}
                yield {
                    "kind": "tool_args_loop",
                    "evidence": "AAAAAAAA",
                }
                yield {"kind": "metrics", "finish_reason": "tool_calls"}
                yield {"kind": "done"}
            else:
                yield {"kind": "content", "text": "recovered output"}
                yield {"kind": "metrics", "finish_reason": "stop"}
                yield {"kind": "done"}

        return _Turn(), _stream()

    return _spawn, state


def test_reasoning_loop_detected_hook_can_suppress_with_block() -> None:
    """A ReasoningLoopDetected hook that exits 2 with a reason
    suppresses the cascade — treat as a false positive, inject the
    reason as a steering user message, and keep going. The
    distill/force-terminate path must NOT fire."""
    spawn, wstate = _loop_then_done()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"ReasoningLoopDetected": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": "echo 'false positive; this is dense reasoning' >&2; exit 2",
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    # The hook intercepted → the next round runs (recovered output).
    assert isinstance(events[-1], TurnDone) and events[-1].state == "ok"
    # Worker must have run twice — once for the looped round, once for
    # the override continuation. Distill recovery did NOT fire (which
    # would inject a third spawn).
    assert wstate["n"] == 2, (
        "false-positive override should rerun the round, not the "
        "distill recovery cascade"
    )


def test_reasoning_loop_detected_hook_continue_false_ends_turn() -> None:
    """A ReasoningLoopDetected hook returning ``continue: false`` ends
    the turn immediately — no distill, no force-terminate."""
    spawn, wstate = _loop_then_done()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"ReasoningLoopDetected": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"continue":false,"stopReason":"operator wants hard stop"}\''
            ),
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)
    events = _run(eng, hook_engine=hooks)
    # No recovery cascade — only the one looped round ran.
    assert wstate["n"] == 1, (
        "continue:false must end the turn after the looped round, not "
        "fire distill/force-terminate"
    )
    assert isinstance(events[-1], TurnDone)


def test_force_terminate_hook_substitutes_body() -> None:
    """A ForceTerminate hook with ``decision: block`` and a reason
    substitutes the canned FORCE_TERMINATE body in the injected
    user message. This is the override path for the hardcoded
    last-ditch terminator."""
    spawn, _ = _loop_then_done()
    captured_messages: list = []

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    # Force-terminate must fire when distill recoveries are capped to 0.
    hooks = HookEngine.from_dict({"hooks": {"ForceTerminate": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"decision":"block","reason":"CUSTOM TERMINATE BODY"}\''
            ),
        }]},
    ]}})
    eng = _make_engine(
        spawn, _runner, cfg_extra={"distill_max_recoveries": 0},
    )

    # Wrap _force_terminate to capture the message it injects.
    orig_force_terminate = eng._force_terminate

    async def _spy(messages, **kw):
        result_messages, fired = await orig_force_terminate(messages, **kw)
        captured_messages.append(list(result_messages))
        return result_messages, fired

    eng._force_terminate = _spy  # type: ignore[method-assign]

    events = _run(eng, hook_engine=hooks)
    assert captured_messages, "force_terminate must have fired"
    last_user = next(
        (m for m in reversed(captured_messages[0])
         if isinstance(m, dict) and m.get("role") == "user"),
        None,
    )
    assert last_user is not None
    assert "CUSTOM TERMINATE BODY" in str(last_user.get("content") or ""), (
        "ForceTerminate hook's `reason` must replace the canned body"
    )


def test_permission_request_hook_can_upgrade_criticality() -> None:
    """A PermissionRequest hook can return updatedCriticality to upgrade
    a tool's severity from read_only to destructive — the value the
    Agent's permission gate sees."""
    spawn, _ = _tool_call_round_then_done(criticality="read_only")
    seen_crit: list = []

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"PermissionRequest": [
        {"matcher": "Bash", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":'
                '{"updatedCriticality":"destructive"}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(spawn, _runner)

    def _capture_perm(ev):
        if isinstance(ev, PermissionRequested):
            seen_crit.append(ev.criticality)

    # Wrap _run to intercept the criticality the Agent gate sees.
    sess = _Sess()
    state = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )
    req = TurnRequest(
        prompt="do it", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": hooks,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )

    async def _go():
        async for ev in eng.run_turn(
            req, state, sessions_dir=Path("/tmp"), turn_id="turn-1",
        ):
            _capture_perm(ev)
            if isinstance(ev, PermissionRequested):
                ev.response.set_result("allow")

    asyncio.run(_go())
    assert seen_crit, "PermissionRequested must have fired"
    assert seen_crit[0] == "destructive", (
        f"PermissionRequest hook should have upgraded criticality; "
        f"saw {seen_crit[0]}"
    )


def test_pre_compact_hook_substitutes_messages() -> None:
    """A PreCompact hook returning ``hookSpecificOutput.replacementMessages``
    replaces the message list wholesale, skipping the default
    ``_maybe_compact`` strategy at round_idx > 0."""
    # The spawn must yield TWO rounds (so PreCompact fires on round 1).
    spawn, _ = _tool_call_round_then_done()
    spawn_messages: list[list[dict]] = []

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    # Spy on the spawn to record the messages each round was called with.
    async def _spy_spawn(engine, session, messages, turn_id, env):
        spawn_messages.append(list(messages))
        return await spawn(engine, session, messages, turn_id, env)

    hooks = HookEngine.from_dict({"hooks": {"PreCompact": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":'
                '{"replacementMessages":'
                '[{"role":"system","content":"squeezed by hook"}]}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(
        _spy_spawn, _runner,
        # compact_at_frac=0 forces PreCompact to fire on every
        # round_idx>0 even with a tiny message list.
        cfg_extra={"upstream_max_context": 100, "compact_at_frac": 0.0},
    )

    sess = _Sess()
    estate = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )
    req = TurnRequest(
        prompt="do it", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": hooks,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )

    async def _go():
        async for ev in eng.run_turn(
            req, estate, sessions_dir=Path("/tmp"), turn_id="turn-pc",
        ):
            if isinstance(ev, PermissionRequested):
                ev.response.set_result("allow")

    asyncio.run(_go())
    assert len(spawn_messages) >= 2, "two rounds should have spawned"
    # Round 1's messages should contain the hook's replacement marker
    # — proves the replacement made it into the next worker spawn.
    round1_msgs = spawn_messages[1]
    bodies = [str(m.get("content") or "") for m in round1_msgs]
    assert any("squeezed by hook" in b for b in bodies), (
        f"PreCompact replacementMessages must reach the next round's "
        f"worker spawn; saw bodies={bodies!r}"
    )


def test_upstream_error_hook_steers_reactive_compact_routing() -> None:
    """An UpstreamError hook that rewrites the classification to the
    overflow marker should cause the engine to fire reactive-compact
    even on a raw error string that the default classifier wouldn't
    have recognised — proves the hook actually STEERS routing, not
    just relabels the surfaced error."""

    state = {"errored_once": False, "compacted": False}

    async def _spawn(engine, session, messages, turn_id, env):
        async def _stream():
            if not state["errored_once"]:
                state["errored_once"] = True
                yield {
                    "kind": "error",
                    "message": "model-specific overflow string with no markers",
                }
            else:
                yield {"kind": "content", "text": "recovered output"}
                yield {"kind": "metrics", "finish_reason": "stop"}
                yield {"kind": "done"}

        return _Turn(), _stream()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"UpstreamError": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":'
                '{"classification":"upstream context-length overflow"}}\''
            ),
        }]},
    ]}})

    eng = _make_engine(_spawn, _runner)

    # Wrap _reactive_compact_on_overflow so we can prove it was called.
    orig = eng._reactive_compact_on_overflow

    async def _spy(session, msgs, err, *, classification=""):
        state["compacted"] = True
        # Pretend we squeezed successfully so the engine retries.
        return msgs, True

    eng._reactive_compact_on_overflow = _spy  # type: ignore[method-assign]

    sess = _Sess()
    estate = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )
    req = TurnRequest(
        prompt="hi", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": hooks,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )

    async def _go():
        async for ev in eng.run_turn(
            req, estate, sessions_dir=Path("/tmp"), turn_id="turn-route",
        ):
            pass

    asyncio.run(_go())
    assert state["compacted"], (
        "UpstreamError hook rewriting classification to overflow marker "
        "should have triggered reactive-compact"
    )


def test_upstream_error_hook_can_override_classification() -> None:
    """A worker error → upstream-error classifier path; an UpstreamError
    hook returning ``hookSpecificOutput.classification`` overrides the
    default tag the engine would have used to steer reactive-compact
    vs hard-error retry."""
    # Stub spawner that emits a worker error.
    async def _err_spawn(engine, session, messages, turn_id, env):
        async def _stream():
            yield {"kind": "error", "message": "context length exceeded"}

        return _Turn(), _stream()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    hooks = HookEngine.from_dict({"hooks": {"UpstreamError": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":'
                '{"classification":"hook_overridden"}}\''
            ),
        }]},
    ]}})
    eng = _make_engine(_err_spawn, _runner)

    sess = _Sess()
    state = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )
    req = TurnRequest(
        prompt="hi", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": hooks,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )

    seen_errors: list = []

    async def _go():
        async for ev in eng.run_turn(
            req, state, sessions_dir=Path("/tmp"), turn_id="turn-2",
        ):
            from rtxclaw_core.agents.engine import TurnError
            if isinstance(ev, TurnError):
                seen_errors.append(ev.classification)

    asyncio.run(_go())
    assert seen_errors, "TurnError must have surfaced"
    assert seen_errors[0] == "hook_overridden", (
        f"UpstreamError hook should have rewritten classification; "
        f"saw {seen_errors[0]}"
    )


def test_notification_hook_fires_on_runtime_warnings() -> None:
    """When the engine surfaces a runtime warning (loop / nudge /
    distill / force-terminate), the ``Notification`` hook fires
    fire-and-forget so an ECC plugin can route the event externally.
    This test triggers the silent-nudge warning (8-char final content
    after a tool round) and asserts Notification fired with
    ``kind: nudge``."""
    # 8 chars — explicitly below NUDGE_MIN_TEXT_CHARS (10) to trip
    # the silent-nudge branch. The shared helper's default is the
    # long string; we override here so the 3rd round (the nudge
    # continuation) actually fires and emits the Notification event.
    spawn, _ = _tool_call_round_then_done(content="all done")

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    import os
    import tempfile
    fd, sink = tempfile.mkstemp(prefix="notification_", suffix=".jsonl")
    os.close(fd)
    try:
        hooks = HookEngine.from_dict({"hooks": {"Notification": [
            {"matcher": "*", "hooks": [{
                "type": "command",
                # Append (not overwrite) so multiple Notifications
                # are recorded if they fire.
                "command": f"cat >> {sink}; echo >> {sink}",
            }]},
        ]}})
        eng = _make_engine(spawn, _runner)
        _ = _run(eng, hook_engine=hooks)
        import json as _json
        with open(sink, "r", encoding="utf-8") as f:
            lines = [ln for ln in f.read().splitlines() if ln.strip()]
        events_fired = [_json.loads(ln) for ln in lines]
    finally:
        try:
            os.unlink(sink)
        except OSError:
            pass
    # At least one Notification must have fired (the nudge warning).
    kinds = {p.get("kind") for p in events_fired}
    assert "nudge" in kinds or "loop-detected" in kinds, (
        f"expected at least one runtime-warning Notification; got {kinds}"
    )


# --------------------------------------------------------------------------
# Thinking-visibility gate (regression — see 2026-05-15 e6ad9ee)
# --------------------------------------------------------------------------
#
# The gate that decides whether ``thinking`` worker events surface as
# ``TextDelta(channel="thinking")`` reads off the BOUND SESSION
# (``session.reasoning_visibility``), not the AgentConfig. Originally
# it read ``cfg.reasoning_visibility`` — but AgentConfig has no such
# field, so the gate defaulted to "off" and the TUI silently received
# no thinking events even though the model + worker still produced
# them. These tests pin the per-session contract.

def _thinking_then_done_spawn():
    """One-round worker that emits a thinking chunk + a content chunk."""
    async def _spawn(engine, session, messages, turn_id, env):
        async def _stream():
            yield {"kind": "thinking", "text": "let me think…"}
            yield {"kind": "content", "text": "answer"}
            yield {"kind": "metrics", "finish_reason": "stop"}
            yield {"kind": "done"}
        return _Turn(), _stream()
    return _spawn


def _run_with_session(eng, sess):
    """Drive run_turn with a caller-supplied session stub."""
    req = TurnRequest(
        prompt="ping", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model",
        extra={
            "session": sess,
            "hook_engine": None,
            "hook_ctx": {"session_id": sess.hash, "cwd": "/tmp"},
        },
    )
    state = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )

    async def _go():
        events = []
        async for ev in eng.run_turn(
            req, state, sessions_dir=Path("/tmp"), turn_id="turn-1",
        ):
            events.append(ev)
        return events

    return asyncio.run(_go())


def test_thinking_delta_yielded_when_session_visibility_on() -> None:
    """``session.reasoning_visibility = "on"`` → thinking deltas reach
    the frontend.

    Regression: before the 2026-05-18 fix the gate read off
    ``cfg.reasoning_visibility``, a field that AgentConfig never
    defines. Every fresh session silently swallowed thinking events
    and the TUI / Telegram showed no chain-of-thought even though the
    worker still emitted ``thinking`` chunks.
    """
    eng = _make_engine(
        _thinking_then_done_spawn(),
        lambda *a, **kw: (True, "", False, False),
    )
    sess = _Sess()
    sess.reasoning_visibility = "on"
    events = _run_with_session(eng, sess)
    thinking = [
        e for e in events
        if isinstance(e, TextDelta) and e.channel == "thinking"
    ]
    assert thinking, (
        "expected a TextDelta(channel='thinking') for the worker's "
        "thinking event; got "
        f"{[type(e).__name__ for e in events]}"
    )
    assert "let me think" in "".join(d.text for d in thinking)


def test_thinking_delta_suppressed_when_session_visibility_off() -> None:
    """``session.reasoning_visibility = "off"`` → no thinking deltas
    reach the frontend, but the answer still does (privacy gate).

    Pins the inverse of the regression so a future refactor that
    accidentally turns the gate inside-out gets caught.
    """
    eng = _make_engine(
        _thinking_then_done_spawn(),
        lambda *a, **kw: (True, "", False, False),
    )
    sess = _Sess()
    sess.reasoning_visibility = "off"
    events = _run_with_session(eng, sess)
    thinking = [
        e for e in events
        if isinstance(e, TextDelta) and e.channel == "thinking"
    ]
    content = [
        e for e in events
        if isinstance(e, TextDelta) and e.channel == "content"
    ]
    assert not thinking, "off must suppress thinking deltas"
    assert content and "answer" in "".join(d.text for d in content), (
        "content channel must still reach the frontend even when "
        "reasoning_visibility is off"
    )


# --------------------------------------------------------------------
# Per-turn wall-clock timestamps in the model context — fix_20260519
# round-4. Pre-change, prior turns were sent as ``[Turn N]`` with no
# date; only the LIVE turn carried a wall-clock. The model couldn't
# tell when a "yesterday" turn happened. Post-change, every prior
# turn's marker includes the turn's frozen ``started_at`` timestamp.
# --------------------------------------------------------------------


def test_build_messages_prior_turn_markers_include_started_at():
    """``_build_messages_simple`` embeds each prior turn's
    ``started_at`` ISO timestamp inside the ``[Turn N · …]`` marker
    so the model has wall-clock context for every prior interaction.

    The timestamp is taken from the turn record verbatim and never
    recomputed from ``datetime.now()`` for prior turns — that's the
    KV-cache-safety invariant: each prior-turn marker stays
    byte-stable across subsequent turns, so vLLM / SGLang prefix
    caching keeps reusing the prefill.
    """
    eng = LocalLLMEngine(
        types.SimpleNamespace(
            upstream_max_context=8000,
            permission_mode="auto",
            reasoning_visibility="off",
            upstream_model="stub-model",
            distill_max_recoveries=3,
            _max_rounds=20,
        ),
        worker_spawner=None,
        tool_runner=None,
    )
    sess = _Sess()
    # Two prior turns with explicit ISO timestamps.
    sess.turns = [
        {
            "user": "hello morning",
            "content": "morning answer",
            "started_at": "2026-05-19T08:00:00-03:00",
            "ended_at":   "2026-05-19T08:00:05-03:00",
            "in_progress": False,
            "aborted": False,
        },
        {
            "user": "noon question",
            "content": "noon answer",
            "started_at": "2026-05-19T12:30:00-03:00",
            "ended_at":   "2026-05-19T12:30:08-03:00",
            "in_progress": False,
            "aborted": False,
        },
    ]
    msgs = eng._build_messages_simple(
        sess, "afternoon question", system_prompt=None, preamble=[],
    )
    user_msgs = [m for m in msgs if m.get("role") == "user"]
    assert len(user_msgs) == 3, (
        f"expected 3 user messages (2 prior + 1 live); got {len(user_msgs)}"
    )
    morning_marker = user_msgs[0]["content"].split("\n", 1)[0]
    noon_marker    = user_msgs[1]["content"].split("\n", 1)[0]
    live_marker    = user_msgs[2]["content"].split("\n", 1)[0]
    # Prior-turn markers MUST carry the turn's own timestamp.
    assert "[Turn 0 · 2026-05-19 08:00:00 -0300" in morning_marker, (
        f"prior turn 0 marker missing its timestamp: {morning_marker!r}"
    )
    assert "[Turn 1 · 2026-05-19 12:30:00 -0300" in noon_marker, (
        f"prior turn 1 marker missing its timestamp: {noon_marker!r}"
    )
    # Live marker still carries `datetime.now()` (separate path).
    assert live_marker.startswith("[Turn 2 · "), (
        f"live marker shape changed unexpectedly: {live_marker!r}"
    )
    # Day-of-week label is in the format too — pin "Tuesday" for the
    # 2026-05-19 timestamps so a locale change can't silently break it.
    assert "(Tuesday)" in morning_marker
    assert "(Tuesday)" in noon_marker


def test_build_messages_prior_turn_marker_falls_back_without_timestamp():
    """If a prior turn's ``started_at`` is missing or malformed, the
    marker falls back to the bare ``[Turn N]`` form rather than
    crashing or inserting a partial timestamp."""
    eng = LocalLLMEngine(
        types.SimpleNamespace(
            upstream_max_context=8000,
            permission_mode="auto",
            reasoning_visibility="off",
            upstream_model="stub-model",
            distill_max_recoveries=3,
            _max_rounds=20,
        ),
        worker_spawner=None,
        tool_runner=None,
    )
    sess = _Sess()
    sess.turns = [
        {
            "user": "u0",
            "content": "c0",
            "started_at": "",  # blank
            "in_progress": False, "aborted": False,
        },
        {
            "user": "u1",
            "content": "c1",
            "started_at": "not-an-iso-string",  # malformed
            "in_progress": False, "aborted": False,
        },
    ]
    msgs = eng._build_messages_simple(
        sess, "live", system_prompt=None, preamble=[],
    )
    user_msgs = [m for m in msgs if m.get("role") == "user"]
    assert user_msgs[0]["content"].startswith("[Turn 0]\n"), (
        f"empty started_at should fall back to bare marker: "
        f"{user_msgs[0]['content'][:40]!r}"
    )
    assert user_msgs[1]["content"].startswith("[Turn 1]\n"), (
        f"malformed started_at should fall back to bare marker: "
        f"{user_msgs[1]['content'][:40]!r}"
    )


def test_build_messages_prior_marker_is_byte_stable_across_builds():
    """KV-cache safety invariant: building messages multiple times
    against the same prior-turn list produces IDENTICAL bytes for
    the prior-turn markers. Without this property, the prefix-cache
    in vLLM / SGLang would miss between consecutive turns and the
    operator pays TTFT for the full prefill every round.

    A regression that derives the prior-turn timestamp from
    ``datetime.now()`` instead of the turn's frozen ``started_at``
    would silently fail this test — the second build's marker
    would carry a different time than the first.
    """
    import time as _time

    eng = LocalLLMEngine(
        types.SimpleNamespace(
            upstream_max_context=8000,
            permission_mode="auto",
            reasoning_visibility="off",
            upstream_model="stub-model",
            distill_max_recoveries=3,
            _max_rounds=20,
        ),
        worker_spawner=None,
        tool_runner=None,
    )
    sess = _Sess()
    sess.turns = [
        {
            "user": "u0", "content": "c0",
            "started_at": "2026-05-19T08:00:00-03:00",
            "in_progress": False, "aborted": False,
        },
    ]
    msgs1 = eng._build_messages_simple(
        sess, "first build", system_prompt=None, preamble=[],
    )
    # Sleep just long enough that ``datetime.now()`` would
    # observably differ between builds — proves the prior-turn
    # marker doesn't pick up the live clock.
    _time.sleep(1.2)
    msgs2 = eng._build_messages_simple(
        sess, "second build", system_prompt=None, preamble=[],
    )
    # Prior-turn user message is the FIRST user message of each
    # build (after the system prompt). Slice the marker line.
    def _prior_marker(msgs):
        users = [m for m in msgs if m.get("role") == "user"]
        return users[0]["content"].split("\n", 1)[0]

    marker1 = _prior_marker(msgs1)
    marker2 = _prior_marker(msgs2)
    assert marker1 == marker2, (
        f"prior-turn marker drifted across builds — KV cache busted:\n"
        f"  build 1: {marker1!r}\n  build 2: {marker2!r}"
    )
    # Sanity: the marker really does include the frozen timestamp,
    # so this isn't passing just because both builds produced
    # "[Turn 0]" (the bare-fallback shape).
    assert "2026-05-19 08:00:00" in marker1


# --------------------------------------------------------------------
# Hook-outcomes audit trail — codex round-4 critical: every _fire_hook
# call must land in the per-turn collector so the saved JSON can
# answer "did a hook deny this tool call" without scanning gateway.log.
# --------------------------------------------------------------------


def test_fire_hook_appends_outcome_to_contextvar_log():
    """The contextvar-driven collector records every hook event
    (event, matcher, decision, blocked, additional_context size,
    ran count, fired_at). Outside a run_turn frame the contextvar
    is None and _fire_hook is a no-op — no log pollution from
    heartbeat / test-time calls.
    """
    import asyncio
    from rtxclaw_core.agents.local_llm import (
        LocalLLMEngine, _HOOK_OUTCOMES_LOG,
    )
    from rtxclaw_core.hooks import HookEngine

    eng = LocalLLMEngine(
        types.SimpleNamespace(
            upstream_max_context=8000,
            permission_mode="auto",
            reasoning_visibility="off",
            upstream_model="stub-model",
            distill_max_recoveries=3,
            _max_rounds=20,
        ),
        worker_spawner=None,
        tool_runner=None,
    )
    hooks = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [{
            "type": "command",
            "command": (
                "printf '%s' "
                '\'{"hookSpecificOutput":{"permissionDecision":"deny",'
                '"permissionDecisionReason":"never run Bash here"}}\''
            ),
        }]},
    ]}})

    async def _go():
        # 1) Outside the contextvar frame — no logging.
        outcome = await eng._fire_hook(
            hooks, {"session_id": "s", "cwd": "/tmp"},
            "PreToolUse", {"tool_name": "Bash"},
        )
        assert outcome.permission_decision == "deny"

        # 2) Inside the frame — outcome lands in the log.
        log: list = []
        token = _HOOK_OUTCOMES_LOG.set(log)
        try:
            outcome = await eng._fire_hook(
                hooks, {"session_id": "s", "cwd": "/tmp"},
                "PreToolUse", {"tool_name": "Bash"},
            )
            assert outcome.permission_decision == "deny"
        finally:
            _HOOK_OUTCOMES_LOG.reset(token)
        return log

    log = asyncio.run(_go())
    assert len(log) == 1, (
        f"contextvar log should carry exactly one entry; got {log!r}"
    )
    row = log[0]
    assert row["event"] == "PreToolUse"
    assert row["matcher"] == "Bash"
    assert row["decision"] == "deny"
    assert row["ran"] >= 1
    assert "fired_at" in row


def test_reactive_maxtok_fallback_is_bounded_per_turn() -> None:
    """Runaway-storm guard (2026-05-21).

    When the reactive max-tokens fallback fires but the retried request
    STILL overflows every round, the engine must surface the error after
    a bounded number of fallback retries — NOT keep shrinking
    ``max_tokens`` and re-spawning the worker for the whole round budget.
    Production hit 81 ``COMPACTION_REACTIVE_MAX_TOKENS_FALLBACK`` events in
    ~60s on one session, ``new_max_tokens`` marching 16384→…→<256.
    """
    from rtxclaw_core.agents.engine import TurnError
    from rtxclaw_core.agents.local_llm import (
        _MAX_REACTIVE_MAXTOK_FALLBACKS,
    )

    # Worker always 400s with a context-overflow error.
    async def _spawn(engine, session, messages, turn_id, env):
        async def _stream():
            yield {
                "kind": "error",
                "message": (
                    "HTTP 400: This model's maximum context length is 8000 "
                    "tokens. However, you requested more — context-length "
                    "overflow"
                ),
            }

        return _Turn(), _stream()

    async def _runner(session_id, call, turn, **kw):
        return (True, "ok", False, False)

    eng = _make_engine(_spawn, _runner)

    calls = {"n": 0}

    async def _spy(session, msgs, err, *, classification=""):
        # Mimic the real max-tokens fallback: shrink the per-session
        # override each call and signal a retry (the storm shape).
        calls["n"] += 1
        prev = getattr(session, "max_tokens_override", 4096) or 4096
        setattr(session, "max_tokens_override", int(prev) - 256)
        return msgs, True

    eng._reactive_compact_on_overflow = _spy  # type: ignore[method-assign]
    # Cap rounds so a regression fails fast rather than looping to 999.
    eng._max_rounds_override = 25

    sess = _Sess()
    estate = EngineSessionState(
        rtxclaw_session_id=sess.hash, engine=EngineKind.LOCAL_LLM,
    )
    req = TurnRequest(
        prompt="hi", prompt_parts=[], system_prompt="sys",
        system_prompt_sha256="x", preamble=[], mode="auto", cwd="",
        model="stub-model", extra={"session": sess},
    )

    saw_error = {"v": False}

    async def _go():
        async for ev in eng.run_turn(
            req, estate, sessions_dir=Path("/tmp"), turn_id="turn-storm",
        ):
            if isinstance(ev, TurnError):
                saw_error["v"] = True

    asyncio.run(_go())

    assert calls["n"] <= _MAX_REACTIVE_MAXTOK_FALLBACKS + 1, (
        f"reactive max-tokens fallback not bounded: fired {calls['n']}x "
        f"(cap is {_MAX_REACTIVE_MAXTOK_FALLBACKS} + 1 initial)"
    )
    assert saw_error["v"], "the overflow must surface as a TurnError"
