"""Tests for the worktree garbage collector. GC prunes worktrees whose
branch is merged into main OR whose branch is older than N days."""
import subprocess
from pathlib import Path

import pytest

GC_SRC = Path(__file__).resolve().parents[1] / "assets" / "self-improver" / "self-improver-gc.sh"


@pytest.fixture
def stage(tmp_path, monkeypatch):
    src_repo = tmp_path / "src" / "rtxclaw"
    rtxhome = tmp_path / "rtxhome"
    (rtxhome / "scripts").mkdir(parents=True)
    src_repo.mkdir(parents=True)

    subprocess.run(["git", "init", "-q", "-b", "main", str(src_repo)], check=True)
    subprocess.run(["git", "-C", str(src_repo), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(src_repo), "config", "user.name", "t"], check=True)
    (src_repo / "README").write_text("hello")
    subprocess.run(["git", "-C", str(src_repo), "add", "."], check=True)
    subprocess.run(["git", "-C", str(src_repo), "commit", "-q", "-m", "init"], check=True)

    dst = rtxhome / "scripts" / "self-improver-gc.sh"
    dst.write_text(GC_SRC.read_text())
    dst.chmod(0o755)

    monkeypatch.setenv("RTXCLAW_HOME", str(rtxhome))
    monkeypatch.setenv("RTXCLAW_SOURCE_DIR", str(src_repo))
    return {"src_repo": src_repo, "rtxhome": rtxhome, "gc": dst}


def _add_worktree(src_repo, rtxhome, fp):
    wt = rtxhome / "self-improver" / "worktrees" / f"fix_{fp}"
    wt.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["git", "-C", str(src_repo), "worktree", "add",
         str(wt), "-b", f"fix_selfimprover_{fp}"],
        check=True, capture_output=True,
    )
    return wt


def test_gc_prunes_merged_worktrees(stage):
    wt = _add_worktree(stage["src_repo"], stage["rtxhome"], "merged01")
    # Add real work on the branch so the merge produces a merge commit
    # (otherwise --no-ff is a no-op fast-forward and main never moves).
    (wt / "fix.txt").write_text("the fix")
    subprocess.run(["git", "-C", str(wt), "add", "fix.txt"], check=True)
    subprocess.run(["git", "-C", str(wt), "commit", "-q", "-m", "fix"], check=True)
    subprocess.run(["git", "-C", str(stage["src_repo"]), "merge", "--no-ff",
                    "-q", "-m", "merge", "fix_selfimprover_merged01"], check=True)
    subprocess.run([str(stage["gc"])], check=True, capture_output=True)
    assert not wt.exists(), "merged worktree must be pruned"


def test_gc_keeps_unmerged_recent_worktree(stage):
    wt = _add_worktree(stage["src_repo"], stage["rtxhome"], "fresh02")
    subprocess.run([str(stage["gc"])], check=True, capture_output=True)
    assert wt.exists(), "unmerged recent worktree must survive GC"
