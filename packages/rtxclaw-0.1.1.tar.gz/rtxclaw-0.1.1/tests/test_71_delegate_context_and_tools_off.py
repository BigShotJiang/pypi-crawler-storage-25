"""Regression tests for two delegate-path fixes (2026-05-20).

Bug 1 — codex/antigravity tool calls leaked into Telegram chat even with
``/tools off``. Root cause: the CLI runners inline their ``🔧 bash …``
markers into the reply body via ``on_delta`` whenever ``on_event`` is
NOT wired (runners.py ``_push_marker``), and that body always renders
for direct-dispatch delegate output. Claude avoided it by surfacing
structured ``on_event`` blocks the frontend ``/tools`` gate suppresses.
Fix: codex/antigravity engines now ``supports_on_event() -> True`` and every
delegate shim forwards ``on_event``.

Bug 2 — ``/claude`` (and ``/codex`` / ``/antigravity``) via Telegram reached
the delegate with the bare user prompt and a fresh CLI session every
call:
  (a) no ``<rtxclaw-context>`` preamble (the TUI built it client-side;
      other frontends did not);
  (b) the in-process direct-dispatch shim read the parent rtxclaw
      session id from ``os.environ['RTXCLAW_SESSION_ID']`` which is only
      set on the tool_runner SUBPROCESS env — so it was empty in the
      gateway, breaking child-session keying / resume / the link sidecar.
Fix: build the preamble server-side in ``_run_direct_tool_call`` and
thread the parent session id explicitly into the shim.
"""

from __future__ import annotations

import asyncio
import os
import inspect


# Fake ``codex exec --json`` emitting the codex-cli 0.125.0 event schema:
# thread.started + a command_execution item (started/completed) + a final
# agent_message. Proves the runner parses tool calls regardless of the
# live CLI.
_FAKE_CODEX = """#!/usr/bin/env python3
import json, sys
try:
    sys.stdin.read()  # runner pipes the prompt on stdin
except Exception:
    pass
for ev in [
    {"type": "thread.started", "thread_id": "codex-thread-xyz"},
    {"type": "item.started",
     "item": {"type": "command_execution", "id": "c1", "command": "echo hi"}},
    {"type": "item.completed",
     "item": {"type": "command_execution", "id": "c1", "command": "echo hi",
              "aggregated_output": "hi", "exit_code": 0}},
    {"type": "item.completed",
     "item": {"type": "agent_message", "id": "m1", "text": "all done"}},
]:
    print(json.dumps(ev), flush=True)
"""


def _install_fake_codex(tmp_path, monkeypatch):
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fc = fake_bin / "codex"
    fc.write_text(_FAKE_CODEX, encoding="utf-8")
    fc.chmod(0o755)
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setenv("PATH", f"{fake_bin}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.setenv("RTXCLAW_SESSION_ID", "rtx-codex-tools")
    monkeypatch.setenv("RTXCLAW_SESSIONS_DIR", str(sessions_dir))
    monkeypatch.setenv("RTXCLAW_AGENT_HOME", str(tmp_path / "agent"))
    monkeypatch.setenv("RTXCLAW_PERMISSION_MODE", "auto")


# ---- Bug 1 -----------------------------------------------------------

def test_codex_antigravity_engines_support_on_event() -> None:
    from rtxclaw_core.agents.codex_engine import CodexCliEngine
    from rtxclaw_core.agents.antigravity_engine import AntigravityCliEngine
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine

    assert CodexCliEngine().supports_on_event() is True
    assert AntigravityCliEngine().supports_on_event() is True
    # Claude was already True — guard against an accidental regression.
    assert ClaudeCliEngine().supports_on_event() is True


def test_every_delegate_shim_accepts_on_event() -> None:
    from rtxclaw_core.agents import delegate_shims as ds

    for fn in (
        ds.shim_run_delegate_claude_async,
        ds.shim_run_delegate_codex_async,
        ds.shim_run_delegate_antigravity_async,
        ds.shim_run_delegate_agent_async,
    ):
        assert "on_event" in inspect.signature(fn).parameters, fn.__name__


def test_runner_dispatch_shims_forward_on_event() -> None:
    from rtxclaw_core.tools import runners

    for nm in ("_shim_claude", "_shim_codex", "_shim_antigravity"):
        fn = getattr(runners, nm)
        assert "on_event" in inspect.signature(fn).parameters, nm


def test_codex_runner_parses_tool_calls_into_structured_events(
    tmp_path, monkeypatch,
) -> None:
    """With ``on_event`` wired, codex ``command_execution`` items must be
    PARSED into structured ``tool_use`` / ``tool_result`` events — and
    the ``🔧 bash …`` markers must NOT be inlined into ``on_delta`` text
    (that inlining is what leaked tool calls past ``/tools off``)."""
    from rtxclaw_core.tools.runners import run_delegate_codex_async
    _install_fake_codex(tmp_path, monkeypatch)

    events: list[dict] = []
    deltas: list[str] = []
    res = asyncio.run(run_delegate_codex_async(
        {"prompt": "do a thing"},
        on_delta=lambda t: deltas.append(t),
        on_event=lambda e: events.append(e),
    ))

    assert res.ok is True, res.content
    kinds = [e.get("kind") for e in events]
    assert "tool_use" in kinds, f"command_execution not parsed: {events}"
    assert "tool_result" in kinds, f"no tool_result parsed: {events}"
    tu = next(e for e in events if e.get("kind") == "tool_use")
    assert tu["name"] == "bash"
    assert tu["input"]["command"] == "echo hi"
    tr = next(e for e in events if e.get("kind") == "tool_result")
    assert tr["ok"] is True
    # Markers must NOT bleed into the streamed body when on_event is wired.
    assert not any("🔧" in d for d in deltas), f"marker leaked to on_delta: {deltas}"
    # The agent's actual reply text still streams.
    assert any("all done" in d for d in deltas), deltas


def test_codex_runner_inlines_markers_only_without_on_event(
    tmp_path, monkeypatch,
) -> None:
    """Back-compat: a legacy consumer that passes only ``on_delta`` (no
    ``on_event``) still gets the inline ``🔧`` markers — so plain-text
    frontends keep their trace."""
    from rtxclaw_core.tools.runners import run_delegate_codex_async
    _install_fake_codex(tmp_path, monkeypatch)

    deltas: list[str] = []
    res = asyncio.run(run_delegate_codex_async(
        {"prompt": "do a thing"},
        on_delta=lambda t: deltas.append(t),
    ))
    assert res.ok is True, res.content
    joined = "".join(deltas)
    assert "🔧" in joined and "echo hi" in joined, joined


# ---- Bug 2 -----------------------------------------------------------

class _StubSession:
    def __init__(self, turns):
        self.turns = turns
        self.hash = "parentSID123"


def test_preamble_first_call_forwards_all_prior_turns() -> None:
    from rtxclaw_core.agents.local_llm import _build_direct_delegate_preamble

    sess = _StubSession([
        {"user": "Whats the prime numbers from 10 to 20",
         "content": "11, 13, 17, 19"},
    ])
    pre = _build_direct_delegate_preamble(sess, "delegate_claude")
    assert "<rtxclaw-context>" in pre
    assert "prime numbers" in pre
    assert "talking to a local model" in pre  # first-call header
    assert pre.rstrip().endswith("The user's request follows.")


def test_preamble_resume_forwards_only_turns_since_last_same_delegate() -> None:
    from rtxclaw_core.agents.local_llm import _build_direct_delegate_preamble

    sess = _StubSession([
        {"user": "Whats the prime numbers from 10 to 20",
         "content": "11, 13, 17, 19"},
        {"user": '__RTXCLAW_DELEGATE__:delegate_claude:{"prompt": "is this correct"}',
         "content": "Yes."},
        {"user": "now do 20 to 30", "content": "23, 29"},
    ])
    pre = _build_direct_delegate_preamble(sess, "delegate_claude")
    assert "since your last invocation" in pre   # resume header
    assert "now do 20 to 30" in pre              # new local turn forwarded
    assert "prime numbers" not in pre            # pre-delegate turn NOT re-sent
    assert "is this correct" not in pre          # raw sentinel dropped


def test_preamble_forwards_cross_kind_delegate_reply() -> None:
    from rtxclaw_core.agents.local_llm import _build_direct_delegate_preamble

    sess = _StubSession([
        {"user": '__RTXCLAW_DELEGATE__:delegate_codex:{"prompt": "review"}',
         "content": "codex says LGTM"},
        {"user": "and the tests?", "content": "all green"},
    ])
    pre = _build_direct_delegate_preamble(sess, "delegate_claude")
    # Claude has no shared resume state with codex → its reply IS context.
    assert "codex says LGTM" in pre
    assert "and the tests?" in pre


def test_preamble_empty_when_no_turns() -> None:
    from rtxclaw_core.agents.local_llm import _build_direct_delegate_preamble

    assert _build_direct_delegate_preamble(_StubSession([]), "delegate_claude") == ""


def test_direct_dispatch_threads_parent_sid_and_guards_double_context() -> None:
    # The slash-command handler must thread the parent session id and
    # skip re-prepending a preamble when one is already present.
    from rtxclaw_core.agents import local_llm

    src = inspect.getsource(local_llm.LocalLLMEngine._run_direct_tool_call)
    assert "_rtxclaw_parent_session_id" in src
    assert "<rtxclaw-context>" in src  # double-context guard
    assert "_build_direct_delegate_preamble" in src


def test_drive_child_agent_turn_prefers_explicit_parent_sid() -> None:
    from rtxclaw_core.agents import delegate_shims as ds

    src = inspect.getsource(ds._drive_child_agent_turn)
    # Explicit arg preferred over the (gateway-empty) env var.
    assert "_rtxclaw_parent_session_id" in src
    assert "RTXCLAW_SESSION_ID" in src
    # Persists the parent → CLI session-id link + surfaces it back to the
    # direct-dispatch caller for the parent session's own record.
    assert "engine_session_id" in src
    assert "_rtxclaw_engine_session_id_out" in src


# ---- rtxclaw ↔ engine session-id link: JSONL log + sessions.db -------

def _iter_jsonl(sr, path):
    for raw in path.read_bytes().split(b"\n"):
        if not raw:
            continue
        ev = sr.decode_line(raw)
        if ev:
            yield ev


def test_engine_session_id_link_in_jsonl_log_and_sessions_db(tmp_path) -> None:
    """The rtxclaw↔engine (claude/codex/antigravity) session-id link must be
    present in BOTH the append-only JSONL session log and sessions.db.

    The Agent emits a ``header_update`` carrying ``engine_session_id`` at
    TurnDone for CLI engines; the projector folds it into
    ``sessions_meta.engine_session_id``."""
    from rtxclaw_core import session_reader as sr
    from rtxclaw_core.session_writer import SessionWriter
    from rtxclaw_core.session_index import SessionIndex, connect_sessions_db

    home = tmp_path / "agent"
    sdir = home / "sessions"
    sdir.mkdir(parents=True)
    sid = "rtx-child-codex"
    eng_sid = "019e4323-d2e9-75a0-8290-da44f725b3e4"

    w = SessionWriter(sdir, sid, engine="codex_cli", flush_ms=0)
    w.session_started({"agent_name": "codex", "engine": "codex_cli"})
    w.turn_started(turn_idx=0, user="do x", permission_mode="auto", cwd="/w")
    w.round_started(turn_idx=0, round_idx=0, model="codex")
    w.text_delta(turn_idx=0, round_idx=0, chunk="done")
    w.round_ended(turn_idx=0, round_idx=0, metrics={}, finish_reason="stop")
    w.turn_ended(turn_idx=0, user="do x", final_content="done", metrics={})
    # What Agent.run_turn emits at TurnDone for a CLI engine:
    w.header_update(patch={"engine_session_id": eng_sid})
    w.close()

    # 1) session log (JSONL) carries the link as a header_update record.
    patches = [
        (ev.get("patch") or {}).get("engine_session_id")
        for ev in _iter_jsonl(sr, sdir / f"{sid}.jsonl")
        if ev.get("type") == "header_update"
    ]
    assert eng_sid in patches, f"engine_session_id not in JSONL log: {patches}"

    # 2) sessions.db sessions_meta row carries it after indexing.
    SessionIndex(home).tail(sid)
    con = connect_sessions_db(sdir / "sessions.db")
    row = con.execute(
        "SELECT engine_session_id FROM sessions_meta WHERE session_hash=?",
        (sid,),
    ).fetchone()
    assert row is not None
    val = row["engine_session_id"] if not isinstance(row, tuple) else row[0]
    assert val == eng_sid, f"sessions.db engine_session_id={val!r}"


def test_sessions_meta_has_engine_session_id_column() -> None:
    from rtxclaw_core.session_index import _SESSIONS_META_COLUMNS

    names = {name for name, _ in _SESSIONS_META_COLUMNS}
    assert "engine_session_id" in names
