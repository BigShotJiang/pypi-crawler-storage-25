"""Regression: prompt-sha drift mid-session must NOT discard the
bound CLI conversation.

Before fix_20260513, ``ExternalCliEngine.run_turn`` cleared
``effective_resume_id`` whenever ``system_prompt_policy`` returned
``sha_changed`` (external_cli.py:593-595). That meant any tool call
the agent itself made that flowed into ``_compose_system_prompt`` —
e.g., editing ``~/.rtxclaw/config.json``'s ``mcp_servers``
list, editing the agent's own ``MEMORY.md`` / ``SOUL.md``, creating a
skill — would shift the priming sha and, on the very next turn, spawn
a fresh Claude CLI session. The user saw the agent suddenly forget
everything from the prior turn.

Codex's review settled on Option C: always resume when an
``engine_session_id`` is recorded, and log the drift instead. The CLI
session has its priming prompt baked in at first call; re-priming
trades all conversation history for an updated prompt — a bad trade.

This test pins that contract.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path


def _fake_claude_argv_capture(bin_dir: Path, capture_path: Path) -> None:
    """Install a ``claude`` stub that records its argv to a file, then
    emits a minimal valid stream-json reply so the engine drives to
    ``TurnDone(state="ok")``.

    The argv capture is what we assert against — we want to confirm
    the spawn carried ``--resume <id>`` and did NOT carry
    ``--append-system-prompt`` when sha drifted mid-session.
    """
    bin_dir.mkdir(parents=True, exist_ok=True)
    stub = bin_dir / "claude"
    stub.write_text(
        f"""#!/usr/bin/env python3
import json, sys
sys.stdin.read()  # drain so the parent's stdin_task completes.
with open({json.dumps(str(capture_path))}, "a", encoding="utf-8") as fh:
    fh.write(json.dumps(sys.argv) + chr(10))
print(json.dumps({{
    "type": "assistant",
    "session_id": "resumed-session-id",
    "message": {{"content": [{{"type": "text", "text": "resumed ok"}}]}},
}}), flush=True)
print(json.dumps({{
    "type": "result",
    "session_id": "resumed-session-id",
    "is_error": False,
}}), flush=True)
""",
        encoding="utf-8",
    )
    stub.chmod(0o755)


def _drain(engine, request, state, sessions_dir, turn_id):
    """Helper: drive engine.run_turn to completion and return the
    final TurnDone state string (``"ok"`` / ``"error"`` / ``"aborted"``).
    """
    from rtxclaw_core.agents.engine import TurnDone

    async def _go():
        terminal = "none"
        async for ev in engine.run_turn(
            request, state, sessions_dir=sessions_dir, turn_id=turn_id,
        ):
            if isinstance(ev, TurnDone):
                terminal = ev.state
        return terminal

    return asyncio.run(_go())


def test_sha_drift_with_recorded_session_resumes(tmp_path, monkeypatch) -> None:
    """Policy ``sha_changed`` + a recorded ``engine_session_id`` must
    spawn ``claude --resume <prior-id>`` and must NOT pass
    ``--append-system-prompt``. The bound CLI session keeps its
    baseline; the drift is logged, not acted on.
    """
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import (
        EngineKind, EngineSessionState, TurnRequest,
    )

    capture = tmp_path / "argv.jsonl"
    _fake_claude_argv_capture(tmp_path / "bin", capture)

    monkeypatch.setenv("PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    rtx_sid = "rtx-drift-test"
    prior_engine_sid = "claude-session-from-turn-0"
    old_sha = "0" * 64
    new_sha = "f" * 64

    state = EngineSessionState(
        rtxclaw_session_id=rtx_sid,
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id=prior_engine_sid,
        priming_status="completed",
        priming_system_prompt_sha256=old_sha,
    )

    # Agent populates system_prompt + sha on sha_changed (agent.py:689-694).
    # external_cli must IGNORE the system_prompt and resume anyway.
    request = TurnRequest(
        prompt="follow-up turn — should retain prior context",
        system_prompt="# SOUL\n\n(updated since priming)\n",
        system_prompt_sha256=new_sha,
        preamble=[],
        mode="auto",
    )

    engine = ClaudeCliEngine()
    terminal = _drain(engine, request, state, sessions_dir, turn_id="t-1")
    assert terminal == "ok", f"engine drove to {terminal!r}, expected 'ok'"

    # Exactly one claude spawn.
    lines = capture.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1, f"expected 1 spawn, got {len(lines)}: {lines}"
    argv = json.loads(lines[0])

    # Must resume the prior CLI session.
    assert "--resume" in argv, f"missing --resume in argv: {argv}"
    assert argv[argv.index("--resume") + 1] == prior_engine_sid, (
        f"resumed wrong session id: {argv}"
    )

    # Must NOT pass --append-system-prompt — the bound CLI session
    # already has its baseline; passing a new prompt alongside
    # --resume either fights the session's own state or no-ops, and
    # before the fix it correlated with the bug (the engine spawned
    # WITHOUT --resume and WITH --append-system-prompt, creating a
    # fresh session).
    assert "--append-system-prompt" not in argv, (
        f"--append-system-prompt leaked into resume call: {argv}"
    )


def test_first_turn_no_recorded_session_primes(tmp_path, monkeypatch) -> None:
    """Baseline: with no recorded ``engine_session_id``, the engine
    primes fresh — passes ``--append-system-prompt`` and does NOT
    pass ``--resume``. Same shape as before the fix; we pin it so the
    drift fix doesn't accidentally break first-turn priming.
    """
    from rtxclaw_core.agents.claude_engine import ClaudeCliEngine
    from rtxclaw_core.agents.engine import (
        EngineKind, EngineSessionState, TurnRequest,
    )

    capture = tmp_path / "argv.jsonl"
    _fake_claude_argv_capture(tmp_path / "bin", capture)
    monkeypatch.setenv("PATH", f"{tmp_path/'bin'}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.delenv("RTXCLAW_SESSION_ID", raising=False)
    monkeypatch.delenv("RTXCLAW_SESSIONS_DIR", raising=False)
    monkeypatch.delenv("RTXCLAW_PERMISSION_MODE", raising=False)

    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()

    state = EngineSessionState(
        rtxclaw_session_id="rtx-fresh",
        engine=EngineKind.CLAUDE_CLI,
        engine_session_id="",
        priming_status="never",
        priming_system_prompt_sha256="",
    )
    request = TurnRequest(
        prompt="hello",
        system_prompt="# SOUL\n\nfirst-turn priming prompt\n",
        system_prompt_sha256="a" * 64,
        preamble=[],
        mode="auto",
    )

    engine = ClaudeCliEngine()
    terminal = _drain(engine, request, state, sessions_dir, turn_id="t-fresh")
    assert terminal == "ok", f"engine drove to {terminal!r}, expected 'ok'"

    lines = capture.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1, f"expected 1 spawn, got {len(lines)}: {lines}"
    argv = json.loads(lines[0])
    assert "--resume" not in argv, f"--resume leaked into first-turn: {argv}"
    assert "--append-system-prompt" in argv, (
        f"first turn must pass --append-system-prompt: {argv}"
    )
