"""Step 64 — PLAN mode must allow read-only pipelines / quoted operators.

Regression suite for the operator-reported "plan mode is not working"
symptom (session 20260520T132628335933-ba2088014684): read-only
commands were denied in PLAN mode because
``tools.safety.classify_command`` bailed to ``UNKNOWN`` (→ ``MUTATING``
→ denied) for ANY command containing a shell operator — even when the
operator was inside quotes (``grep -E "a|b"``) or every pipeline /
chain segment was itself read-only (``cat f | grep x``).

The classifier must now:

- ignore operators inside single / double quotes,
- classify each pipeline / chain segment and take the most-cautious,
- floor a file-write redirection (``>`` / ``>>``) at ``MUTATING``,
- stay cautious (``UNKNOWN``) on command substitution (`` ` `` / ``$(``),
- still flag destructive / forbidden constructs anywhere in the string.

Pure unit test — no daemon, no upstream.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from rtxclaw_core.tools.safety import CommandSafety, classify_command  # noqa: E402
from rtxclaw_core.tools.permissions import (  # noqa: E402
    Decision,
    PermissionEvaluator,
    PermissionMode,
)
from rtxclaw_core.tools.registry import Tool, ToolKind  # noqa: E402


# ---- read-only despite operators -----------------------------------


@pytest.mark.parametrize(
    "cmd",
    [
        'grep -E "a|b" file.txt',            # quoted pipe — not a real pipe
        r"grep -e 'x\|y' file.txt",          # quoted regex alternation
        'grep -rn "self.?impro\\|self_improv" .',  # the exact denied command
        "cat foo | grep bar",                # read-only pipeline
        "cat foo | grep bar | wc -l",        # 3-stage read-only pipeline
        "ls -la && cat foo",                 # read-only && chain
        "ls; pwd",                           # read-only ; chain
        "cat < input.txt",                   # input redirect is read-only
        "ls -la 2>&1 | grep err",            # fd-dup is not a file write
        "cat foo >&2",                       # >&N fd-dup → no file write
        "crontab -l",                        # list-only crontab
        "git status && git log --oneline",   # read-only git chain
    ],
)
def test_readonly_pipelines_classify_read_only(cmd: str):
    assert classify_command(cmd) is CommandSafety.READ_ONLY, cmd


# ---- single read-only command unchanged ----------------------------


@pytest.mark.parametrize("cmd", ["ls -la", "git status", "grep foo bar.txt"])
def test_single_readonly_unchanged(cmd: str):
    assert classify_command(cmd) is CommandSafety.READ_ONLY, cmd


# ---- file-write redirect floors at MUTATING ------------------------


@pytest.mark.parametrize(
    "cmd",
    [
        "grep foo bar.txt > out.txt",        # write redirect
        "cat foo >> log.txt",                # append redirect
        "cat foo | tee out.txt",             # tee is mutating
        "echo hi > file",                    # write redirect
        "cat src >&dest",                    # >&FILE truncates a FILE (not fd-dup)
    ],
)
def test_file_write_is_mutating(cmd: str):
    assert classify_command(cmd) is CommandSafety.MUTATING, cmd


# ---- command substitution stays cautious ---------------------------


@pytest.mark.parametrize(
    "cmd",
    [
        "cat $(echo foo)",
        "echo `ls`",
        'cat "$(touch x)"',     # $() expands INSIDE double quotes
        'cat "`touch x`"',      # backticks expand INSIDE double quotes
        "cat <(touch x)",       # process substitution RUNS the inner cmd
        "diff <(ls) <(ls /tmp)",
    ],
)
def test_command_substitution_unknown(cmd: str):
    # Can't promise read-only across a substitution → cautious. Double
    # quotes do NOT make `$(...)` / backticks literal (the shell still
    # runs them), and process substitution `<(...)` executes the inner
    # command — so a read-only-looking command must not be allowed.
    assert classify_command(cmd) is CommandSafety.UNKNOWN, cmd


def test_single_quotes_are_literal():
    # Single quotes ARE fully literal in the shell — nothing expands, so
    # this just cats a weirdly-named file (read-only).
    assert classify_command("cat '$(touch x)'") is CommandSafety.READ_ONLY


# ---- `find -exec` runs arbitrary commands, not read-only ------------


@pytest.mark.parametrize(
    "cmd",
    [
        "find . -exec rm {} ';'",       # quoted terminator (no longer a separator)
        "find . -exec rm {} \\;",
        "find . -type f -exec touch {} +",
        "find . -execdir sh -c 'x' ';'",
        "find . -ok rm {} ';'",
        "find . -okdir rm {} ';'",
    ],
)
def test_find_exec_is_not_read_only(cmd: str):
    # `-exec`/`-execdir`/`-ok`/`-okdir` run a command per match. (A
    # destructive inner command — e.g. `rm -rf` — is caught as DESTRUCTIVE
    # over the whole string; the point here is it must never be READ_ONLY.)
    assert classify_command(cmd) is not CommandSafety.READ_ONLY, cmd


@pytest.mark.parametrize(
    "cmd",
    [
        "find . -name '*.py'",
        "find /tmp -type f -newer ref",
        "find . -maxdepth 2 -type d",
    ],
)
def test_plain_find_stays_read_only(cmd: str):
    assert classify_command(cmd) is CommandSafety.READ_ONLY, cmd


# ---- destructive / forbidden anywhere in a chain still wins ---------


@pytest.mark.parametrize(
    "cmd",
    [
        "ls -la && rm -rf /tmp/scratch",     # destructive segment
        "cat foo | xargs rm",                # xargs rm
        "git status; git push --force origin main",
    ],
)
def test_destructive_anywhere_wins(cmd: str):
    assert classify_command(cmd) is CommandSafety.DESTRUCTIVE, cmd


def test_forbidden_anywhere_wins():
    assert classify_command("cat foo; rm -rf ~/") is CommandSafety.FORBIDDEN


# ---- end-to-end: PLAN mode permission decision ---------------------


def _bash() -> Tool:
    return Tool(name="Bash", kind=ToolKind.EXEC, description="run shell")


def test_plan_mode_allows_readonly_pipeline():
    ev = PermissionEvaluator(mode=PermissionMode.PLAN)
    d = ev.evaluate(
        _bash(),
        {"command": "cat foo | grep bar", "criticality": "read_only"},
    )
    assert d is Decision.ALLOW


def test_plan_mode_allows_quoted_pipe_grep():
    ev = PermissionEvaluator(mode=PermissionMode.PLAN)
    d = ev.evaluate(
        _bash(),
        {"command": 'grep -E "a|b" file.txt', "criticality": "read_only"},
    )
    assert d is Decision.ALLOW


def test_plan_mode_denies_file_write_even_if_model_claims_readonly():
    ev = PermissionEvaluator(mode=PermissionMode.PLAN)
    d = ev.evaluate(
        _bash(),
        {"command": "echo hi > file.txt", "criticality": "read_only"},
    )
    assert d is Decision.DENY


# ---- skill auto-invoke cache must be a settable slotted field ------


def test_agent_skill_index_is_settable_slot():
    """``Agent`` is ``@dataclass(slots=True)``; the auto-invoke cache
    (``self._skill_index = idx``) MUST be a declared field or it raises
    ``AttributeError`` — which the helper's broad ``except`` swallows,
    leaving skill auto-invoke dead. This guards that regression."""
    import dataclasses

    from rtxclaw_core.agents.agent import Agent

    assert "_skill_index" in {f.name for f in dataclasses.fields(Agent)}
    inst = Agent.__new__(Agent)      # bypass __init__ (needs cfg/engine)
    inst._skill_index = object()     # must NOT raise AttributeError
    assert inst._skill_index is not None


# ====================================================================
# Session 20260520T145255989695 — the SECOND plan-mode report.
# ====================================================================
#
# After the quote/segment-aware split landed, this session's read-only
# research commands were STILL denied because the safe builtins they use
# (`cd`, `echo`, `test`, `sort`) weren't on the read-only allowlist and
# a `2>/dev/null` stderr-discard was mis-counted as a file write. These
# pin the follow-up fix so the regression can't reappear.


@pytest.mark.parametrize(
    "cmd",
    [
        # the exact commands denied in session …145255989695
        "cd /home/jcooloj/src/rtxclaw && git log --oneline -30",
        'cd /x && test -f scripts/y.md && echo "EXISTS" || echo "MISSING"',
        'find /x -name "*.py" -path "*/test*" -name "*self*" | sort',
        'ls -la /x/assets/self-improver/ 2>/dev/null || echo "DIR MISSING"',
        'echo "mode check"',
    ],
)
def test_session_145255_readonly_research_allowed(cmd: str):
    assert classify_command(cmd) is CommandSafety.READ_ONLY, cmd


@pytest.mark.parametrize(
    "cmd",
    [
        "cd /tmp", "echo hi", 'printf "%s\\n" x', "test -f x", "[ -d y ]",
        "true", "false", "sort file", "uniq", "cut -d, -f1 x", "tr a b",
        "basename /a/b", "dirname /a/b", "realpath .", "readlink x",
        "seq 1 10", "expr 1 + 1", "sleep 1",
    ],
)
def test_safe_builtins_classify_read_only(cmd: str):
    assert classify_command(cmd) is CommandSafety.READ_ONLY, cmd


@pytest.mark.parametrize(
    "cmd",
    [
        "ls -la 2>/dev/null",                 # discard stderr — not a file
        "cat f >/dev/null",                   # discard stdout
        "git status >/dev/null 2>&1",         # discard both
        "grep x f 2>/dev/null || echo none",  # discard + read-only chain
        'cmd &>/dev/null',                    # &> to /dev/null is benign...
    ],
)
def test_devnull_redirects_stay_read_only(cmd: str):
    # ``cmd`` (last case) is unknown argv[0] → UNKNOWN, but the point is
    # the /dev/null redirect must NOT push it to MUTATING.
    assert classify_command(cmd) is not CommandSafety.MUTATING, cmd


def test_devnull_readonly_command_is_read_only():
    assert classify_command("ls -la 2>/dev/null") is CommandSafety.READ_ONLY
    assert classify_command("cat f >/dev/null") is CommandSafety.READ_ONLY


@pytest.mark.parametrize(
    "cmd",
    ["sort -o out.txt in.txt", "sort --output=x in", "sort -o x"],
)
def test_sort_output_flag_is_mutating(cmd: str):
    # `sort` is a read-only stream filter EXCEPT when it writes via -o.
    assert classify_command(cmd) is CommandSafety.MUTATING, cmd


def test_plan_mode_allows_session_145255_commands():
    ev = PermissionEvaluator(mode=PermissionMode.PLAN)
    for cmd in (
        "cd /home/jcooloj/src/rtxclaw && git log --oneline -30",
        'find . -name "*.py" | sort',
        'ls -la x/ 2>/dev/null || echo "DIR MISSING"',
        'echo "mode check"',
    ):
        d = ev.evaluate(_bash(), {"command": cmd, "criticality": "read_only"})
        assert d is Decision.ALLOW, (cmd, d)
