"""Step 09 — cleanup.

Stops any lingering daemon, kills stray pollers, wipes the sandbox,
asserts no rtxclaw processes remain. Marked with the highest sort key
so it runs last under default pytest collection order.
"""
from __future__ import annotations

import os
import shutil
import signal as _signal
import subprocess
import time
from pathlib import Path


def _pgrep(pattern: str) -> list[int]:
    cp = subprocess.run(["pgrep", "-f", pattern], capture_output=True, text=True)
    if cp.returncode != 0:
        return []
    return [int(x) for x in cp.stdout.split() if x.strip().isdigit()]


def _proc_owns_sandbox(pid: int, sandbox_home: Path) -> bool:
    """True iff /proc/<pid>/environ has RTXCLAW_HOME=<sandbox_home>.

    Used to filter pgrep matches so tests on a developer machine that
    runs a real production bot (rooted at ~/.rtxclaw/telegram) don't
    flag the production process as a sandbox leftover.
    """
    try:
        env_blob = Path(f"/proc/{pid}/environ").read_bytes()
    except OSError:
        return False
    wanted = str(sandbox_home.resolve()) if sandbox_home.exists() else str(sandbox_home)
    for entry in env_blob.split(b"\0"):
        if entry.startswith(b"RTXCLAW_HOME="):
            return entry[len(b"RTXCLAW_HOME="):].decode("utf-8", "replace") == wanted
    return False


def test_cleanup_wipes_sandbox(run_rtxclaw, sandbox_home: Path, sandbox_venv: Path) -> None:
    run_rtxclaw("gateway", "stop")
    # Prefer the standalone CLI's SIGTERM path so the bot's signal
    # handler runs (drains the long poll, cleans up the pidfile).
    run_rtxclaw("telegram", "stop")
    # Fallback: SIGTERM only sandbox-owned bots (filter by RTXCLAW_HOME
    # in /proc/<pid>/environ) so a developer's production bot at
    # ~/.rtxclaw/telegram is left alone.
    for pid in _pgrep(r"rtxclaw_telegram\.bot"):
        if _proc_owns_sandbox(pid, sandbox_home):
            try:
                os.kill(pid, _signal.SIGTERM)
            except ProcessLookupError:
                pass
    time.sleep(0.5)

    if sandbox_home.exists():
        shutil.rmtree(sandbox_home)
    if sandbox_venv.exists():
        shutil.rmtree(sandbox_venv)

    assert not sandbox_home.exists(), f"sandbox workspace not removed: {sandbox_home}"
    assert not sandbox_venv.exists(), f"sandbox venv not removed: {sandbox_venv}"


def test_no_leftover_rtxclaw_processes(sandbox_home: Path) -> None:
    leftovers: list[tuple[str, list[int]]] = []
    for pat in (
        r"rtxclaw_telegram\.bot",
        r"rtxclaw_agent\.acp_stdio_main",
        r"hypercorn.*rtxclaw",
    ):
        pids = [p for p in _pgrep(pat) if _proc_owns_sandbox(p, sandbox_home)]
        if pids:
            leftovers.append((pat, pids))
    assert not leftovers, f"leftover rtxclaw processes (sandbox-scoped): {leftovers}"
