"""Tests for the new SessionError hook event."""
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from rtxclaw_core import errors as errmod
from rtxclaw_core.hooks import HOOK_EVENTS


def test_session_error_is_registered_hook_event():
    """SessionError must be in HOOK_EVENTS so the loader accepts it
    in a hooks.json without a 'unknown event' warning."""
    assert "SessionError" in HOOK_EVENTS


@pytest.fixture
def isolated_errors_dir(tmp_path, monkeypatch):
    """Point errors_dir() at a temp directory so the test never
    touches the user's real ~/.rtxclaw/errors/."""
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    monkeypatch.delenv("RTXCLAW_AGENTS_HOME", raising=False)
    return tmp_path / "errors"


def test_log_error_accepts_session_id_kwarg(isolated_errors_dir):
    """log_error() should accept an optional session_id kwarg and embed
    it in the file's Context section so the self-improver can locate
    the originating session JSON."""
    try:
        raise ValueError("boom")
    except ValueError as e:
        path = errmod.log_error(
            "test_component", e,
            context={"k": "v"},
            session_id="abc12345session",
        )
    body = Path(path).read_text(encoding="utf-8")
    assert "abc12345session" in body, "session_id must appear in the log file"


def test_log_error_fires_session_error_hook(isolated_errors_dir):
    """log_error() should ask the hook engine to fire SessionError
    after writing the file, with payload {component, exception,
    fingerprint, file_path, session_id}."""
    fake_engine = MagicMock()
    fake_engine.run = MagicMock(return_value=None)

    with patch.object(errmod, "_get_hook_engine", return_value=fake_engine, create=True):
        try:
            raise RuntimeError("hookable")
        except RuntimeError as e:
            path = errmod.log_error(
                "session_review", e,
                session_id="sess-xyz",
            )

    assert fake_engine.run.called, "hook engine must be invoked"
    call_args, call_kwargs = fake_engine.run.call_args
    event = call_kwargs.get("event") or (call_args[0] if call_args else None)
    payload = call_kwargs.get("payload") or (call_args[1] if len(call_args) > 1 else {})
    assert event == "SessionError"
    assert payload.get("component") == "session_review"
    assert payload.get("exception") == "RuntimeError"
    assert payload.get("session_id") == "sess-xyz"
    assert "fingerprint" in payload
    assert payload.get("file_path") == str(path)


def test_log_error_hook_failure_does_not_raise(isolated_errors_dir):
    """A failure inside the hook engine must not propagate — logging
    errors is best-effort and must never break the caller."""
    fake_engine = MagicMock()
    fake_engine.run = MagicMock(side_effect=Exception("hook broke"))

    with patch.object(errmod, "_get_hook_engine", return_value=fake_engine, create=True):
        try:
            raise OSError("disk")
        except OSError as e:
            errmod.log_error("io", e, session_id="s1")  # must not raise


def test_log_error_actually_awaits_async_hook_run(isolated_errors_dir):
    """Regression for the bug where _maybe_fire_session_error_hook
    called the async HookEngine.run() synchronously, producing an
    unawaited coroutine that never actually fired the hook.

    The fake engine here is async; the test verifies the coroutine
    was awaited (called=True implies the await happened — an
    unawaited coroutine returned by AsyncMock would never set
    .called)."""
    from unittest.mock import AsyncMock
    fake_engine = MagicMock()
    fake_engine.run = AsyncMock(return_value=None)

    with patch.object(errmod, "_get_hook_engine", return_value=fake_engine, create=True):
        try:
            raise RuntimeError("async-hookable")
        except RuntimeError as e:
            errmod.log_error("session_review", e, session_id="sess-async")

    # Allow the fire-and-forget thread up to 2s to complete.
    import time
    for _ in range(20):
        if fake_engine.run.await_count > 0:
            break
        time.sleep(0.1)
    assert fake_engine.run.await_count == 1, (
        f"async hook was not awaited (await_count={fake_engine.run.await_count}); "
        "the sync call to engine.run() leaked an un-awaited coroutine"
    )


def test_tui_worker_log_error_passes_session_id():
    """Regression: the TUI worker-state-change handler at app.py:9384
    must include session_id when calling log_error, so SessionError
    downstream receives a useful payload."""
    import ast
    import pathlib
    src = pathlib.Path("src/rtxclaw_tui/app.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    log_error_calls = [
        n for n in ast.walk(tree)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute)
        and n.func.attr == "log_error"
    ]
    assert log_error_calls, "no log_error call found in app.py"
    has_session_id = any(
        any(kw.arg == "session_id" for kw in call.keywords)
        for call in log_error_calls
    )
    assert has_session_id, "no log_error call in app.py passes session_id="


def test_turn_runtime_log_error_passes_session_id():
    """Regression: every log_error() in turn_runtime.py must pass
    session_id= so the SessionError hook gets a meaningful payload.

    Note: at T3 authoring time turn_runtime.py contains zero real
    log_error call sites (only a docstring reference at line 1539
    inside ``_classify_upstream_error``). The test therefore enforces
    a conditional invariant: *if* a real call ever lands here, it
    must pass session_id=. An empty call list is acceptable — there
    is nothing to thread the id through."""
    import ast
    import pathlib
    src = pathlib.Path("src/rtxclaw_core/turn_runtime.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    log_error_calls = [
        n for n in ast.walk(tree)
        if isinstance(n, ast.Call)
        and (
            (isinstance(n.func, ast.Attribute) and n.func.attr == "log_error")
            or (isinstance(n.func, ast.Name) and n.func.id == "log_error")
        )
    ]
    if not log_error_calls:
        # No real call sites exist yet — invariant vacuously holds.
        return
    has_session_id = all(
        any(kw.arg == "session_id" for kw in call.keywords)
        for call in log_error_calls
    )
    assert has_session_id, "every log_error call in turn_runtime.py must pass session_id="


def test_session_error_actually_spawns_command_hook(tmp_path, isolated_errors_dir):
    """Real integration test: SessionError fires a `command` async hook that
    touches a marker file. Verifies the spawn actually happens — would
    fail before the engine.drain_async_hooks() fix because the spawn
    task would be cancelled before it ran."""
    import json
    from rtxclaw_core import hooks as hooks_mod
    marker = tmp_path / "marker.touched"
    hooks_file = tmp_path / "hooks.json"
    hooks_file.write_text(json.dumps({
        "hooks": {
            "SessionError": [{
                "matcher": "*",
                "hooks": [{"type": "command",
                           "command": f"touch {marker}",
                           "async": True, "timeout": 5}],
            }]
        }
    }))
    engine = hooks_mod.HookEngine.load(hooks_file)
    hooks_mod.set_active_engine(engine, agent_name="main")
    try:
        try:
            raise RuntimeError("integration-fire")
        except RuntimeError as e:
            errmod.log_error("session_review", e,
                             session_id="sess-int",
                             agent_name="main")
        # Daemon thread + spawn — give it up to 3s.
        import time
        for _ in range(30):
            if marker.exists():
                break
            time.sleep(0.1)
        assert marker.exists(), (
            "SessionError hook did not actually spawn — engine.run "
            "returned before the async spawn task ran"
        )
    finally:
        hooks_mod.set_active_engine(None, agent_name="main")


def test_active_engine_registry_is_per_agent_name(tmp_path):
    """Bug B regression: multiple agents must NOT clobber each other's engine."""
    from rtxclaw_core import hooks as hooks_mod
    eng_a = object()  # type: ignore[assignment]
    eng_b = object()  # type: ignore[assignment]
    hooks_mod.set_active_engine(eng_a, agent_name="agent_a")
    hooks_mod.set_active_engine(eng_b, agent_name="agent_b")
    assert hooks_mod.get_active_engine("agent_a") is eng_a
    assert hooks_mod.get_active_engine("agent_b") is eng_b
    # Cleanup.
    hooks_mod.set_active_engine(None, agent_name="agent_a")
    hooks_mod.set_active_engine(None, agent_name="agent_b")
