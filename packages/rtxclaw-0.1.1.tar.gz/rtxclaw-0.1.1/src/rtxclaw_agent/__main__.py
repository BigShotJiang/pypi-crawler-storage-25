"""``python -m rtxclaw_agent`` entrypoint.

Delegates to :func:`rtxclaw_agent.cli.main` so the module-as-script
form is identical to the eventual ``rtxclaw-agent`` console script.
"""
from __future__ import annotations

import sys

from .cli import main


if __name__ == "__main__":
    sys.exit(main())
