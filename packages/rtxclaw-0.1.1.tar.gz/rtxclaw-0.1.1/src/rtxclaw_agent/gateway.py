"""Single-process agent gateway.

Hosts every configured agent in one parent process. Binds a single ACP
Streamable HTTP listener (default :20100) and mounts one
:class:`AgentACPBackend` per discovered agent under ``/acp/<agent>``.

ACP-compliance:

* The gateway IS an ACP server externally — same Starlette app a
  per-agent daemon would expose, mounted once per agent name.
* Each backend is in-process; no child subprocess. For local-LLM
  agents :class:`AgentACPBackend` holds an in-process
  :class:`CoreBackend` wrapper that delegates the multi-round turn
  loop to ``Agent.run_turn`` → :class:`LocalLLMEngine.run_turn`. For
  CLI agents (claude / codex / antigravity) it routes through
  :class:`Agent` → :class:`ExternalCliEngine` → the per-turn CLI
  subprocess; the CLI process itself runs only for the duration of
  one turn.
* No protocol additions. ``new_session`` against ``/acp/main``
  allocates a session via the ``main`` agent's backend; subsequent
  calls for that session id route to the same backend.

Cancel cascade:

* Gateway-level abort (SIGTERM, ``rtxclaw gateway stop``) stops every
  per-agent heartbeat scheduler, then drains the HTTP listener.
* ACP ``cancel(session_id)`` routes through
  :meth:`AgentACPBackend.cancel` → :meth:`Engine.abort(turn_id)`
  which SIGTERMs the active subprocess (worker OR tool runner) via
  :class:`TurnState.stop`. Two ESC presses inside
  ``_HARD_KILL_WINDOW_S`` escalate to SIGKILL + ``killpg``.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
from logging.handlers import RotatingFileHandler
import os
import signal
import time
from pathlib import Path
from typing import Any, Callable, Optional

from rtxclaw_core.agent import (
    AgentConfig,
    agents_root,
    load_global_config,
    rtxclaw_root,
)


_LOG = logging.getLogger("rtxclaw.gateway")


# ---- defaults --------------------------------------------------------

_DEFAULT_HOST = "127.0.0.1"
_DEFAULT_PORT = 20100


def _attach_gateway_logfile_handler() -> None:
    """Wire a FileHandler on the ``rtxclaw`` logger tree.

    The gateway process has historically relied on bare ``_LOG.info``
    calls reaching stdout via stdlib logging's defaults. There are no
    defaults: a logger with no handler falls through to the
    ``lastResort`` handler, which only emits WARNING+ to stderr. So
    every INFO event from gateway.py / openai_endpoint.py /
    local_llm.py / acp_bridge.py was silently dropped — operators
    tailing ``~/.rtxclaw/gateway.log`` saw nothing between boot and
    shutdown.

    Attach a single rotating FileHandler at INFO level pointed at
    ``$RTXCLAW_HOME/gateway.log`` (the same path the daemonizer in
    ``gateway_cli.start_gateway_background`` already wires fd1/fd2 to,
    so both the stdio inheritance path and the python-logging path
    converge on the same file). Idempotent: if a handler whose
    ``baseFilename`` already matches is attached, skip — so test
    harnesses and any future re-call don't double-write.
    """
    log_path = Path(
        os.environ.get("RTXCLAW_HOME") or Path.home() / ".rtxclaw"
    ) / "gateway.log"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        return
    root = logging.getLogger("rtxclaw")
    target = str(log_path.resolve())
    for h in root.handlers:
        if getattr(h, "baseFilename", None) == target:
            return
    handler = RotatingFileHandler(
        log_path, maxBytes=64 * 1024 * 1024, backupCount=4,
        encoding="utf-8", delay=True,
    )
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"
    ))
    root.addHandler(handler)
    root.setLevel(logging.INFO)


# ---- AgentRegistry --------------------------------------------------
#
# Single-process replacement for the legacy ``ChildManager`` /
# ``ChildSession`` / ``RoutingBackend`` triplet that used to spawn one
# stdio ACP subprocess per agent. The user's "no legacy non-compliant
# routing" requirement: every agent is loaded in-memory via
# :func:`factory.load_agent` and exposed through a single
# :class:`AgentACPBackend` instance.
#
# ``AgentRegistry.get(name)`` returns that backend (lazy-allocated on
# first access so the boot sequence doesn't have to pay the
# load-every-agent cost for agents that are never used). All callers
# (the ACP HTTP mount, the openai_endpoint helper) talk to backends
# directly without any subprocess hop.


class AgentRegistry:
    """In-process agent registry. Replaces ChildManager.

    Holds one :class:`AgentACPBackend` instance per discovered agent
    for the gateway process's lifetime. No subprocess spawn, no idle
    GC, no LRU eviction — backends are lightweight Python objects.
    """

    def __init__(self, agent_names: list[str]) -> None:
        self.agent_names = list(agent_names)
        self._backends: dict[str, Any] = {}

    def get(self, name: str) -> Any:
        """Return the in-process :class:`AgentACPBackend` for ``name``."""
        if name in self._backends:
            return self._backends[name]
        from rtxclaw_core.agents.factory import load_agent
        from rtxclaw_core.agents.gateway_shim import AgentACPBackend
        agent = load_agent(name)
        backend = AgentACPBackend(agent)
        self._backends[name] = backend
        return backend

    def keys(self) -> list[str]:
        return list(self.agent_names)

    async def shutdown(self) -> None:
        """No-op — backends hold only in-memory state."""
        return None


# ---- gateway server --------------------------------------------------


def load_shared_secrets_into_environ(home: Path) -> int:
    """Merge ``<home>/secrets.env`` into ``os.environ`` (setdefault).

    Returns the number of keys added (not counting ones already in
    env). Called once at gateway boot AND on every SIGHUP so an
    operator edit takes effect without restarting the systemd unit.

    Why setdefault: systemd ``EnvironmentFile`` / ``/etc/environment``
    are intentional, deliberate overrides. The shared ``secrets.env``
    is the GATEWAY's idea of the default; whatever the operator put
    in process env wins. Don't pollute the process env with per-agent
    overrides — those stay in ``cfg.api_keys`` so each agent gets its
    own keys and one agent's value doesn't leak into another agent's
    MCP subprocess.
    """
    sec = home / "secrets.env"
    if not sec.is_file():
        return 0
    try:
        from rtxclaw_core.agent import _parse_dotenv, _warn_if_world_readable
        _warn_if_world_readable(sec)
        kvs = _parse_dotenv(sec.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        _LOG.warning("failed to load shared secrets.env (%s)", exc)
        return 0
    added = 0
    for k, v in kvs.items():
        if k not in os.environ:
            os.environ[k] = v
            added += 1
    if added:
        _LOG.info(
            "[secrets] loaded %d key(s) from %s into process env "
            "(systemd EnvironmentFile / shell wins on collision)",
            added, sec,
        )
    return added


def _install_sighup_secrets_reload() -> None:
    """SIGHUP → re-read ``~/.rtxclaw/secrets.env`` into ``os.environ``.

    Lets the operator rotate provider keys without restarting the
    systemd-managed gateway:

      1. Edit ``~/.rtxclaw/secrets.env`` with the new key value
      2. ``kill -HUP $(systemctl show -p MainPID --value rtxclaw-gateway.service)``
      3. Next request uses the new key

    Per-agent ``secrets.env`` files are re-read on the next
    ``AgentConfig.load()`` call (every new ACP session), so a SIGHUP
    isn't strictly required for per-agent rotation — but it IS
    required for shared keys and for any external CLI subprocess
    (claude/codex/antigravity) that already inherited the old env.

    Only the boot path installs the handler — the test suite doesn't
    need a real signal handler, and a missing-signal-support platform
    (Windows) silently no-ops.
    """
    import signal
    try:
        def _handler(_signum: int, _frame: Any) -> None:
            try:
                added = load_shared_secrets_into_environ(rtxclaw_root())
                _LOG.info(
                    "[secrets] SIGHUP reload: refreshed %d key(s) from "
                    "shared secrets.env into process env",
                    added,
                )
            except Exception as exc:  # noqa: BLE001
                _LOG.warning("SIGHUP secrets reload failed: %s", exc)
        signal.signal(signal.SIGHUP, _handler)
        _LOG.info(
            "[secrets] SIGHUP handler installed — "
            "send `kill -HUP <pid>` to reload shared secrets.env"
        )
    except (AttributeError, OSError, ValueError):
        # SIGHUP unsupported on this platform OR signal already in
        # use; silently skip.
        pass


def _gateway_config(global_cfg: Optional[dict] = None) -> dict[str, Any]:
    """Resolve gateway config from ``~/.rtxclaw/config.json``.

    Defaults: host=127.0.0.1, port=20100. ``host`` / ``port`` /
    ``auth_token`` overridable via the ``gateway`` block in the
    global config.
    """
    if global_cfg is None:
        global_cfg = load_global_config() or {}
    raw = global_cfg.get("gateway") or {}
    return {
        "host": str(raw.get("host") or _DEFAULT_HOST),
        "port": int(raw.get("port") or _DEFAULT_PORT),
        "auth_token": raw.get("auth_token") or None,
    }


def _discover_agents() -> list[str]:
    """Walk ``agents_root()`` and return every configured agent name.

    Each subdirectory with a ``config.json`` is considered an agent.
    Returns sorted names so the mount order is deterministic.
    """
    root = agents_root()
    if not root.is_dir():
        return []
    out: list[str] = []
    for entry in sorted(root.iterdir()):
        if not entry.is_dir():
            continue
        if (entry / "config.json").is_file():
            out.append(entry.name)
    return out


def _gateway_pidfile() -> Path:
    return Path(os.environ.get("RTXCLAW_HOME") or Path.home() / ".rtxclaw") / "gateway.pid"


def _resolve_port_holder(host: str, port: int) -> Optional[int]:
    """Pid (or ``-1``) holding ``host:port`` in LISTEN state, else None.

    Reuses ``gateway_cli._port_holder`` via a deferred import — that
    module imports :func:`_gateway_pidfile` from here, so a top-level
    import would be circular. Any failure degrades to ``None`` ("looks
    free") so the pre-flight never blocks a legitimate start.
    """
    try:
        from rtxclaw_agent.gateway_cli import _port_holder
    except Exception:  # noqa: BLE001
        return None
    try:
        return _port_holder(host, int(port))
    except Exception:  # noqa: BLE001
        return None


async def _await_port_free(
    host: str,
    port: int,
    timeout: float = 10.0,
    *,
    holder_fn: Optional[Callable[[str, int], Optional[int]]] = None,
    sleep: Optional[Callable[[float], Any]] = None,
) -> Optional[int]:
    """Wait up to ``timeout`` s for a live listener on ``host:port`` to go.

    Returns ``None`` once no listener holds the port (free, or it freed
    within the window), or the pid (``-1`` when owned by another user)
    still holding it at timeout. On a gateway restart the previous
    process may still be draining its socket; polling lets the successor
    bind cleanly once it exits instead of crashing with ``OSError(98)``.
    Only LISTEN-state sockets count — ``SO_REUSEADDR`` (hypercorn's
    default) already covers a TIME_WAIT predecessor.
    """
    holder = holder_fn or _resolve_port_holder
    napper = sleep or asyncio.sleep
    deadline = time.monotonic() + max(0.0, timeout)
    pid = holder(host, int(port))
    while pid is not None and time.monotonic() < deadline:
        await napper(0.25)
        pid = holder(host, int(port))
    return pid


async def _await_serve_or_stop(
    hc_task: "asyncio.Task[Any]",
    stop_event: asyncio.Event,
) -> Optional[BaseException]:
    """Block until the HTTP serve task ends OR a stop is requested.

    The port pre-flight (:func:`_await_port_free`) only NARROWS the
    zombie-gateway window — hypercorn still binds asynchronously inside
    ``hc_task``, so a bind ``OSError(98)`` can still fire there if the
    port is taken after the pre-flight check or two starts race and both
    saw it free. Awaiting ``stop_event`` alone would then hang forever as
    a non-serving zombie (the original pathology) and never retrieve the
    serve task's exception.

    Wait on BOTH; if ``hc_task`` finished first, return its exception (or
    ``None`` if it somehow returned cleanly) so the caller can surface the
    failure and exit non-zero. A normal stop returns ``None``.
    """
    stop_wait = asyncio.create_task(stop_event.wait())
    try:
        await asyncio.wait(
            {hc_task, stop_wait},
            return_when=asyncio.FIRST_COMPLETED,
        )
    finally:
        stop_wait.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await stop_wait
    if hc_task.done():
        # .exception() is safe here: the task is done and (since we only
        # cancel it later, in serve_gateway's cleanup) was not cancelled.
        return hc_task.exception()
    return None


async def serve_gateway() -> None:
    """Run the gateway parent process until SIGTERM/INT.

    Binds one Streamable HTTP listener; mounts ``/acp/<agent>`` for
    every discovered agent; lazy-spawns each child on first
    ``session/new``; cascades shutdown to every live child on stop.
    """
    from hypercorn.asyncio import serve as _h_serve
    from hypercorn.config import Config as _HCConfig
    from starlette.applications import Starlette
    from starlette.routing import Mount, Route
    from starlette.responses import JSONResponse, PlainTextResponse

    from rtxclaw_acp.server.http_server import make_acp_app
    from rtxclaw_agent.acp_stdio_main import (
        _build_agent_info,
        _build_capabilities,
    )

    # Wire the on-disk sink for ``rtxclaw.*`` loggers before any
    # ``_LOG.*`` call below — otherwise the boot banner / heartbeat-
    # start lines silently drop (see ``_attach_gateway_logfile_handler``
    # for the full rationale).
    _attach_gateway_logfile_handler()

    # Load shared secrets.env into os.environ so MCP subprocesses
    # (spawned later by mcp_client with env={**os.environ, ...}) and
    # external-CLI engines (claude/codex/antigravity) that read os.environ
    # directly both inherit the operator's keys. Per-agent secrets
    # stay in cfg.api_keys only — pushing those into the process env
    # would mean whichever agent loaded last wins for any other
    # subprocess, which defeats per-agent attribution. The shared
    # file is the right granularity to lift into os.environ.
    load_shared_secrets_into_environ(rtxclaw_root())

    # Install a SIGHUP handler so the operator can hot-reload edits to
    # ~/.rtxclaw/secrets.env without restarting the systemd service.
    # `kill -HUP $(pidof rtxclaw)` re-reads the shared file, refreshes
    # os.environ for new MCP subprocesses, and re-prints the boot audit
    # for each agent. Per-agent secrets are re-read on the next
    # AgentConfig.load() (next /acp/<name> request).
    _install_sighup_secrets_reload()

    gw = _gateway_config()
    bearer = gw["auth_token"]

    # Auto-scaffold built-in CLI-engine agents (claude/codex/antigravity)
    # when their CLI is on PATH. Idempotent on every boot — never
    # overwrites operator customization. See
    # ``rtxclaw_core.agents.factory.ensure_default_external_agents``.
    try:
        from rtxclaw_core.agents.factory import ensure_default_external_agents
        scaffolded = ensure_default_external_agents()
        if scaffolded:
            _LOG.info(
                "auto-scaffolded built-in CLI-engine agents: %s",
                ", ".join(scaffolded),
            )
    except Exception as exc:  # noqa: BLE001
        # Scaffold failure must not block gateway boot; log + continue.
        _LOG.warning("auto-scaffold failed (continuing): %s", exc)

    agent_names = _discover_agents()
    if not agent_names:
        _LOG.warning(
            "no agents discovered under %s; gateway will run but every "
            "/acp/<name> route will 404 until an agent is configured",
            agents_root(),
        )

    # In-process agent registry replaces the legacy ChildManager.
    # See AgentRegistry above — each agent's :class:`AgentACPBackend`
    # is lazy-built on first use; no subprocess spawn.
    manager = AgentRegistry(agent_names)

    # Mount one ACP app per discovered agent under /acp/<name>. EVERY
    # agent is exposed through :class:`AgentACPBackend` regardless of
    # engine kind. AgentACPBackend internally:
    #
    #   * For local_llm agents — holds an in-process CoreBackend
    #     wrapper around the same Agent + LocalLLMEngine (single source
    #     of truth for session-lifecycle / cancel-routing / outbound
    #     channel binding). The multi-round dispatch / compaction /
    #     loop detection / distill recovery / premature-turn-end
    #     nudges all live in :class:`LocalLLMEngine.run_turn`.
    #   * For claude_cli / codex_cli / antigravity_cli agents — routes
    #     through Agent.run_turn → Engine.run_turn →
    #     :func:`run_delegate_*_async` (the CLI subprocess driver
    #     shared between :meth:`ExternalCliEngine.delegate_runner`
    #     and the delegate-tool entry points in
    #     :mod:`rtxclaw_core.agents.delegate_shims`). The new engine
    #     layer adds agent-context priming (--append-system-prompt) and
    #     sha-change session-resume override.
    routes: list[Any] = []
    for name in agent_names:
        try:
            cfg = AgentConfig.load(name)
        except FileNotFoundError:
            continue
        # Boot audit: one INFO line per agent listing every apiKeyEnv
        # the operator's models[] referenced + where the key was
        # resolved from. Catches the kimi-style bug (OPENROUTER_API_KEY
        # set only inside a per-MCP env block so the gateway process
        # itself never saw it) at restart instead of on the first
        # vision-transcription 401. Missing keys render as ``✗(missing)``
        # in red-ish prefix; present keys as ``✓(agent-local)`` /
        # ``✓(env)`` so the operator can see whether per-agent
        # attribution is actually wired up.
        try:
            audit = cfg.audit_api_keys()
        except Exception:  # noqa: BLE001
            audit = {}
        if audit:
            bits: list[str] = []
            missing = False
            for env_name, src in audit.items():
                if src == "missing":
                    bits.append(f"{env_name}=✗(missing)")
                    missing = True
                else:
                    bits.append(f"{env_name}=✓({src})")
            line = f"[boot] agent={name} api_keys: " + " ".join(bits)
            (_LOG.warning if missing else _LOG.info)(line)
        # AgentACPBackend construction; lazy via the registry so the
        # boot sequence doesn't pay the full agent-load cost for
        # agents never used by a frontend.
        backend = manager.get(name)
        sub_app = make_acp_app(
            backend=backend,
            agent_capabilities=_build_capabilities(cfg),
            agent_info=_build_agent_info(cfg),
            auth_methods=[],
            bearer_token=bearer,
        )
        routes.append(Mount(f"/acp/{name}", app=sub_app))

        # Start the per-agent heartbeat scheduler when the config
        # asks for it. The pre-refactor stdio-per-agent path fired
        # this; the single-process gateway needs to start it explicitly
        # so background memory-synth / idle cleanup keeps running.
        try:
            agent_obj = getattr(backend, "agent", None)
            if agent_obj is not None and getattr(
                cfg, "heartbeat_enabled", False
            ):
                hb_task = agent_obj.start_heartbeat()
                if hb_task is not None:
                    _LOG.info(
                        "heartbeat scheduler started for agent %r", name,
                    )
        except Exception as exc:  # noqa: BLE001
            _LOG.warning(
                "heartbeat scheduler failed to start for %r: %s",
                name, exc,
            )

    async def _index(_request: Any) -> Any:
        return JSONResponse({
            "service": "rtxclaw-gateway",
            "agents": agent_names,
            "live_backends": sorted(manager._backends.keys()),
        })

    async def _health(_request: Any) -> Any:
        return PlainTextResponse("ok")

    routes.append(Route("/", _index, methods=["GET"]))
    routes.append(Route("/health", _health, methods=["GET"]))

    # OpenAI-compatible HTTP API at /openai/v1 — point Open WebUI (or any
    # OpenAI-spec client) here. Same gateway, same auth, same lifecycle;
    # routes the chat/completions field 'model' → AgentRegistry.get(name)
    # so each agent shows up as one OpenAI 'model'.
    from rtxclaw_agent.openai_endpoint import make_openai_app
    routes.append(Mount(
        "/openai/v1",
        app=make_openai_app(
            agent_names=agent_names,
            manager=manager,
            bearer_token=bearer,
        ),
    ))

    app = Starlette(routes=routes)

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()

    def _on_signal() -> None:
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            pass

    _hc_cfg = _HCConfig()
    _hc_cfg.bind = [f"{gw['host']}:{gw['port']}"]
    _hc_cfg.alpn_protocols = ["h2", "http/1.1"]
    _hc_cfg.accesslog = None
    _hc_cfg.errorlog = "-"

    # Pre-flight bind guard. hypercorn binds INSIDE the serve task
    # below; if the configured port is still held (a restart racing the
    # predecessor's socket drain, or an accidental double-start) the bind
    # raises OSError(98) in that task, the exception is never retrieved,
    # and THIS process lives on awaiting ``stop_event`` as a non-serving
    # zombie that has already clobbered the pidfile to point at itself —
    # the "zombie gateway" pathology (14 such crashes on 2026-05-21).
    # Wait briefly for a draining predecessor to release the socket; if
    # it stays held, refuse to start and leave the existing pidfile
    # (owned by the live holder) intact.
    _holder_pid = await _await_port_free(gw["host"], int(gw["port"]), 10.0)
    if _holder_pid is not None:
        _LOG.error(
            "gateway: %s:%d still held by pid=%s after 10s; refusing to "
            "start (leaving existing pidfile intact)",
            gw["host"], gw["port"], _holder_pid,
        )
        print(
            f"[rtxclaw-gateway] {gw['host']}:{gw['port']} already in use "
            f"(pid={_holder_pid}); not starting",
            flush=True,
        )
        return

    # AgentRegistry has no GC loop — backends live for the process
    # lifetime (no per-agent subprocess to reap, no idle-eviction
    # window to enforce).
    pidfile = _gateway_pidfile()
    pidfile.parent.mkdir(parents=True, exist_ok=True)
    pidfile.write_text(str(os.getpid()))

    hc_task = asyncio.create_task(
        _h_serve(
            app,  # type: ignore[arg-type]
            _hc_cfg,
            shutdown_trigger=stop_event.wait,
        ),
        name="rtxclaw-gateway-http",
    )
    _LOG.info(
        "gateway listening on http://%s:%d/  (agents: %s)",
        gw["host"], gw["port"], ", ".join(agent_names) or "(none)",
    )
    print(
        f"[rtxclaw-gateway] listening on http://{gw['host']}:{gw['port']}/  "
        f"agents: {', '.join(agent_names) or '(none)'}",
        flush=True,
    )

    serve_exc: Optional[BaseException] = None
    try:
        # Wait on the serve task too, not just stop_event — otherwise a
        # serve-task bind failure (the zombie pathology) would hang here
        # forever. _await_serve_or_stop returns the serve task's
        # exception when it died on its own.
        serve_exc = await _await_serve_or_stop(hc_task, stop_event)
        if serve_exc is not None:
            _LOG.error(
                "gateway HTTP serve task exited early: %r", serve_exc,
            )
            print(
                f"[rtxclaw-gateway] serve task failed: {serve_exc!r}",
                flush=True,
            )
    finally:
        # Stop every running heartbeat scheduler before the listener
        # drains so background work doesn't outlive the gateway.
        for backend in list(manager._backends.values()):
            agent_obj = getattr(backend, "agent", None)
            if agent_obj is None:
                continue
            with contextlib.suppress(Exception):
                await asyncio.wait_for(
                    agent_obj.stop_heartbeat(), timeout=5.0,
                )
        # Cancel-cascade: shutdown manager first so all children get
        # SIGTERM before the HTTP listener fully drains. This honors
        # the "abort reaches all child subagents" contract.
        with contextlib.suppress(Exception):
            await asyncio.wait_for(manager.shutdown(), timeout=10.0)
        if not hc_task.done():
            try:
                await asyncio.wait_for(hc_task, timeout=5.0)
            except asyncio.TimeoutError:
                hc_task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await hc_task
        # Only remove the pidfile if it still points at THIS process. In a
        # double-start race the winner may have overwritten it to its own
        # pid; deleting it then would orphan the live holder's pidfile.
        with contextlib.suppress(FileNotFoundError, OSError, ValueError):
            if pidfile.read_text().strip() == str(os.getpid()):
                pidfile.unlink()
        print("[rtxclaw-gateway] stopped", flush=True)
    # Propagate a serve-task failure so the process exits non-zero (the
    # supervisor can restart) instead of returning 0 like a clean stop.
    if serve_exc is not None:
        raise serve_exc


def serve_gateway_main() -> int:
    """Sync wrapper for the ``rtxclaw gateway serve`` subcommand."""
    try:
        asyncio.run(serve_gateway())
    except KeyboardInterrupt:
        return 0
    except Exception as e:  # noqa: BLE001
        # serve_gateway propagated a serve-task failure (e.g. bind
        # OSError(98) that slipped past the port pre-flight). Exit
        # non-zero so the supervisor restarts instead of treating a dead
        # gateway as a clean shutdown.
        print(f"[rtxclaw-gateway] exiting after serve failure: {e!r}", flush=True)
        return 1
    return 0


__all__ = [
    "AgentRegistry",
    "serve_gateway",
    "serve_gateway_main",
]
