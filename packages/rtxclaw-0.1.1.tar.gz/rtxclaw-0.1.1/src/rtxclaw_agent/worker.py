"""Streaming subprocess worker.

Reads one JSON request from stdin, opens a streaming chat-completions request
against an OpenAI-compatible endpoint (vLLM), and emits JSONL events on stdout
that the parent app consumes:

    {"kind": "thinking", "text": "..."}
    {"kind": "content",  "text": "..."}
    {"kind": "done"}
    {"kind": "aborted"}
    {"kind": "error",    "message": "..."}

The parent kills this process via SIGTERM (Popen.terminate()) on /abort or ESC.
"""
from __future__ import annotations

import json
import os
import signal
import sys
import time
from typing import Any

import httpx

from rtxclaw_core.splitter import ThinkSplitter
from rtxclaw_core.turn_runtime import (
    LOOP_CHECK_STRIDE,
    LOOP_DETECT_ENABLED,
    _detect_loops_layered,
)


def emit(kind: str, **fields: Any) -> None:
    sys.stdout.write(json.dumps({"kind": kind, **fields}, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _install_term_handler() -> None:
    def handler(signum, frame):  # noqa: ARG001
        emit("aborted")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)


def main() -> int:
    _install_term_handler()

    try:
        request = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError as e:
        emit("error", message=f"bad request json: {e}")
        return 2

    endpoint = (request.get("endpoint") or "").rstrip("/")
    model = request.get("model")
    messages = request.get("messages") or []
    if not endpoint or not model or not messages:
        emit("error", message="missing endpoint/model/messages")
        return 2

    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        # Ask vLLM to include token-count usage in the final SSE chunk so we
        # can compute tokens-per-second exactly instead of approximating from
        # character count.
        "stream_options": {"include_usage": True},
    }
    # Forward sampling knobs from the request. These come from the agent's
    # `Model` (per-mode sampling profile) plus any per-turn override.
    # Fields the caller didn't set don't appear here, so the upstream gets
    # to default; fields the caller DID set we forward verbatim.
    for k in (
        "temperature", "top_p", "top_k", "min_p",
        "repetition_penalty", "presence_penalty", "frequency_penalty",
        "max_tokens", "seed",
    ):
        if k in request and request[k] is not None:
            payload[k] = request[k]
    # Floor: if the caller didn't pick a temperature, default to 0.7 — the
    # OpenAI default upstreams use anyway, but stating it makes the wire
    # behavior deterministic.
    payload.setdefault("temperature", 0.7)
    # Optional tool-calling: the agent runtime sends `tools` (OpenAI
    # function-tool schemas) and `tool_choice`. We forward as-is.
    tools = request.get("tools")
    if tools:
        payload["tools"] = tools
        choice = request.get("tool_choice")
        if choice:
            payload["tool_choice"] = choice
    extra = request.get("extra") or {}
    payload.update(extra)

    # Per-model thinking-tag + prefill behaviour. `models.for_name` resolves
    # the upstream model id (e.g. `gemma-4-27b-it`) to a `Model` carrying
    # the right open/close tags for inline reasoning detection. Gemma 4
    # uses `<thought>...</thought>` rather than Qwen3's `<think>...</think>`.
    from rtxclaw_core.models import for_name as _model_for_name
    mdl = _model_for_name(model)
    open_tag, close_tag = mdl.thinking_tags

    # Prefill: for Gemma 4 (and any future family with the same pattern),
    # when thinking is enabled, end the prompt with the open tag so the
    # model continues inside a thought block. Probe `enable_thinking` from
    # the chat-template kwargs the request builder set; if absent, default
    # to True (matches the rest of the codebase where thinking is opt-out).
    cte_kwargs = (extra.get("chat_template_kwargs") or {}) if isinstance(extra, dict) else {}
    enable_thinking = cte_kwargs.get("enable_thinking")
    if enable_thinking is None:
        enable_thinking = bool(request.get("enable_thinking", True))
    prefilled_thinking = False
    if mdl.prefill_thinking_open_tag and enable_thinking:
        # Append an assistant message opened with the thinking tag and tell
        # vLLM to continue from it instead of starting a fresh assistant
        # turn. The splitter is primed with `in_think=True` so the first
        # streamed token is routed to the thinking channel until we see
        # the close tag.
        payload_msgs = list(payload.get("messages") or [])
        payload_msgs.append({"role": "assistant", "content": f"{open_tag}\n"})
        payload["messages"] = payload_msgs
        payload["continue_final_message"] = True
        payload["add_generation_prompt"] = False
        prefilled_thinking = True

    splitter = ThinkSplitter(open_tag, close_tag, in_think=prefilled_thinking)
    # Buffered reasoning text so we can surface it as content if the
    # upstream's reasoning parser ate the model's final answer (see the
    # end-of-stream fallback below). Cheaper than re-streaming and only
    # held in RAM for the lifetime of one turn.
    reasoning_buf: list[str] = []
    # Per-chunk read timeout. With ``read=None`` the worker would block
    # forever on a wedged upstream (gemma-4-31b-nvfp4-mtp on gpu-d
    # observed: GPU goes idle, SSE stops sending bytes mid-prefill, no
    # 5xx). A 120s ceiling means a stalled stream surfaces as an
    # ``http error: ReadTimeout`` rather than hanging the whole turn,
    # and the ratio guard / loop detector can still fire on legitimate
    # slow-but-streaming rounds (decode at 50 tok/s + 4096-token cap is
    # ~80s in the worst case, so 120s leaves margin).
    try:
        read_timeout_s = float(
            os.environ.get("RTXCLAW_WORKER_READ_TIMEOUT_S", "120")
            or 120.0
        )
    except (TypeError, ValueError):
        read_timeout_s = 120.0
    timeout = httpx.Timeout(
        connect=10.0,
        read=read_timeout_s,
        write=10.0,
        pool=10.0,
    )
    headers = {"Accept": "text/event-stream"}
    extra_headers = request.get("headers") or {}
    if isinstance(extra_headers, dict):
        headers.update({str(k): str(v) for k, v in extra_headers.items() if v is not None})

    dump_path = os.environ.get("RTXCLAW_DEBUG_DUMP")
    dump_fh = None
    if dump_path:
        try:
            dump_fh = open(dump_path, "w", encoding="utf-8")
            dump_fh.write(f"# request payload\n{json.dumps(payload, indent=2)}\n\n# raw sse stream\n")
            dump_fh.flush()
        except OSError:
            dump_fh = None

    # Per-backend differences (vLLM vs SGLang vs unknown) live in
    # `providers.py`. The worker request can carry an optional `backend`
    # field so we use the provider's preferred alias order; otherwise we
    # fall back to a UNKNOWN provider that probes every alias.
    from rtxclaw_core.providers import by_name
    provider = by_name(request.get("backend", ""))
    REASONING_KEYS = provider.reasoning_keys

    t_start = time.monotonic()
    t_headers: float | None = None
    t_first_token: float | None = None
    completion_tokens: int | None = None
    prompt_tokens: int | None = None
    # Cached-token count from vLLM's `usage.prompt_tokens_details.cached_tokens`
    # (`--enable-prefix-caching` exposes this). Lets the agent surface
    # cache-hit ratio per round so an operator can tell "TTFT is climbing
    # because cache misses" vs "because the prompt grew." Also fits a
    # `cache_hit_pct` line on the status bar.
    prompt_tokens_cached: int | None = None
    # Authoritative reasoning-token count from
    # `usage.completion_tokens_details.reasoning_tokens` (OpenAI / DeepSeek
    # surface it). When present we report it directly; when absent we
    # estimate by char ratio between the streamed reasoning vs content.
    reasoning_tokens_usage: int | None = None
    reasoning_chars = 0
    content_chars = 0
    # Accumulator for streamed `delta.tool_calls` fragments. Keyed on the
    # tool-call's `index` (vLLM/SGLang both use position-indexed chunks):
    #   { 0: {"id": "...", "name": "...", "arguments": "<JSON fragments>"} }
    # On finish_reason="tool_calls" we parse `arguments` and emit a single
    # `tool_calls` event. `finish_reason` is recorded so the agent runtime
    # can tell "stop with content" from "tool_calls awaiting results".
    tool_calls_acc: dict[int, dict[str, Any]] = {}
    finish_reason: str | None = None

    try:
        with httpx.Client(timeout=timeout, headers=headers) as client:
            with client.stream("POST", f"{endpoint}/chat/completions", json=payload) as resp:
                # Entering the `with` returns once response headers are in.
                # For a streaming SSE chat-completions call this happens at
                # request ACCEPTANCE — the upstream's ASGI/uvicorn layer
                # flushes status+headers as soon as the request is queued,
                # NOT after prefill. So this stamp is "request accepted",
                # and the real prefill+first-decode cost lives in
                # `t_first_token - t_headers`. (Earlier comments here
                # claimed headers came back after prefill; that was wrong
                # and made `pft_ms` misleading on long-prompt diagnostics.)
                t_headers = time.monotonic()
                if resp.status_code != 200:
                    body = resp.read().decode("utf-8", "replace")
                    emit("error", message=f"HTTP {resp.status_code}: {body[:500]}")
                    return 1
                # Validate Content-Type. A 200 response that ISN'T SSE
                # (HTML interstitial, plain JSON, captive-portal page)
                # would be parsed as garbage SSE below — every chunk
                # silently fails JSON decode and the user sees an empty
                # reply. Surface it as a structured error instead.
                ctype = resp.headers.get("content-type", "")
                if "text/event-stream" not in ctype.lower():
                    body = resp.read().decode("utf-8", "replace")
                    emit(
                        "error",
                        message=(
                            "upstream returned non-SSE content-type "
                            f"{ctype!r} on a stream=true request "
                            f"(status=200). body[:300]={body[:300]!r}"
                        ),
                    )
                    return 1
                json_decode_failures = 0
                for raw in resp.iter_lines():
                    if not raw:
                        continue
                    line = raw if isinstance(raw, str) else raw.decode("utf-8", "replace")
                    if dump_fh is not None:
                        dump_fh.write(line + "\n")
                        dump_fh.flush()
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError as je:
                        # Track silent decode failures so the parent can
                        # see when tokens are being lost. We don't bail
                        # the stream — a single malformed chunk shouldn't
                        # kill the turn — but the count surfaces in the
                        # metrics payload below so the operator notices
                        # and the SSE consumer logs it as a `decode_drop`.
                        json_decode_failures += 1
                        if json_decode_failures <= 3:
                            # First few only — emit so the caller sees
                            # the actual content; afterwards just count.
                            emit(
                                "decode_drop",
                                message=str(je),
                                line_head=data[:200],
                            )
                        continue
                    # Defensive: vLLM (and some OpenAI-compat servers)
                    # surface a request-level 400 on a stream=true
                    # request as an SSE ``data:`` chunk shaped
                    # ``{"error": {"message": ..., "type": ..., "code": 400}}``
                    # rather than an HTTP 4xx. Without this branch we
                    # silently drop the chunk (no ``choices``, no
                    # ``usage``) and exit with ``completion_tokens=1
                    # tokens_estimated=true`` — looks like the model
                    # produced a single empty token, when in fact the
                    # upstream never started decoding. Surface as a
                    # structured ``error`` event so the parent agent
                    # sees the real reason (e.g. "min_p ... not yet
                    # supported with speculative decoding").
                    err = chunk.get("error")
                    if isinstance(err, dict):
                        msg = err.get("message") or json.dumps(err)
                        code = err.get("code")
                        suffix = f" (code={code})" if code is not None else ""
                        emit(
                            "error",
                            message=f"upstream SSE error{suffix}: {msg}",
                        )
                        return 1
                    # vLLM with stream_options.include_usage=true sends a
                    # final chunk with empty choices and a populated usage
                    # field. Capture and continue.
                    usage = chunk.get("usage")
                    if usage:
                        if usage.get("completion_tokens") is not None:
                            completion_tokens = int(usage["completion_tokens"])
                        if usage.get("prompt_tokens") is not None:
                            prompt_tokens = int(usage["prompt_tokens"])
                        # vLLM with prefix caching enabled reports the
                        # cached-token count under `prompt_tokens_details`.
                        # `cached_tokens` == `prompt_tokens` ⇒ full hit;
                        # `cached_tokens` == 0 ⇒ full miss (this is the
                        # signature of the TTFT-climbing-with-prompt bug).
                        details = usage.get("prompt_tokens_details") or {}
                        if isinstance(details, dict):
                            cached = details.get("cached_tokens")
                            if cached is not None:
                                prompt_tokens_cached = int(cached)
                        # Some upstreams (OpenAI, DeepSeek) split the
                        # completion-side count into reasoning vs visible
                        # output under `completion_tokens_details`. When
                        # present we trust it over the char-ratio
                        # estimate built below.
                        comp_details = usage.get("completion_tokens_details") or {}
                        if isinstance(comp_details, dict):
                            rt = comp_details.get("reasoning_tokens")
                            if rt is not None:
                                reasoning_tokens_usage = int(rt)
                    choices = chunk.get("choices") or []
                    if not choices:
                        continue
                    delta = choices[0].get("delta") or {}
                    rc = None
                    for k in REASONING_KEYS:
                        v = delta.get(k)
                        if v:
                            rc = v
                            break
                    if rc:
                        if t_first_token is None:
                            t_first_token = time.monotonic()
                        reasoning_chars += len(rc)
                        reasoning_buf.append(rc)
                        emit("thinking", text=rc)
                    text = delta.get("content")
                    if text:
                        if t_first_token is None:
                            t_first_token = time.monotonic()
                        thinking, content = splitter.feed(text)
                        if thinking:
                            reasoning_chars += len(thinking)
                            reasoning_buf.append(thinking)
                            emit("thinking", text=thinking)
                        if content:
                            content_chars += len(content)
                            emit("content", text=content)
                    # Tool calls stream as positional deltas; accumulate.
                    tcalls = delta.get("tool_calls")
                    if tcalls:
                        for tc in tcalls:
                            idx = int(tc.get("index", 0))
                            slot = tool_calls_acc.setdefault(
                                idx, {"id": "", "name": "", "arguments": ""}
                            )
                            if tc.get("id"):
                                slot["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                slot["name"] = fn["name"]
                            arg_frag = fn.get("arguments")
                            if arg_frag:
                                slot["arguments"] += arg_frag
                                # Loop detection on the streamed
                                # `arguments` JSON. The `delta.content`
                                # / `delta.reasoning_content` detectors
                                # in `acp_bridge.py` don't see this
                                # channel — the worker buffers args
                                # internally and only emits a single
                                # `tool_calls` event at finish. On
                                # gemma-4-31b-nvfp4-mtp we've observed
                                # the model entering a token-collapse
                                # loop *inside* the tool args (3022+
                                # tokens emitted, finish_reason=
                                # tool_calls, JSON unrecoverable).
                                # Sample at LOOP_CHECK_STRIDE-char
                                # intervals so the cost is bounded
                                # over a long argument string.
                                buf = slot["arguments"]
                                last_check = slot.get("_loop_checked_at", 0)
                                if (
                                    LOOP_DETECT_ENABLED
                                    and len(buf) - last_check >= LOOP_CHECK_STRIDE
                                ):
                                    slot["_loop_checked_at"] = len(buf)
                                    hit = _detect_loops_layered(
                                        buf, channel="tool_args",
                                    )
                                    if hit is not None:
                                        tier, evidence = hit
                                        emit(
                                            "tool_args_loop",
                                            index=idx,
                                            name=slot.get("name") or "",
                                            tier=tier,
                                            evidence=evidence[:80],
                                            args_chars=len(buf),
                                            checked_at=len(buf),
                                        )
                                        # ``reason`` distinguishes a
                                        # worker self-protective abort
                                        # (loop detector tripped) from
                                        # an operator cancel (SIGTERM
                                        # / ESC, which emits bare
                                        # ``aborted`` from
                                        # ``_install_term_handler``).
                                        # The engine routes reasoned
                                        # aborts through the loop-
                                        # recovery cascade instead of
                                        # hard-cancelling the turn.
                                        emit(
                                            "aborted",
                                            reason="tool_args_loop",
                                        )
                                        return 0
                    fr = choices[0].get("finish_reason")
                    if fr:
                        finish_reason = fr
        thinking, content = splitter.flush()
        if thinking:
            reasoning_chars += len(thinking)
            reasoning_buf.append(thinking)
            emit("thinking", text=thinking)
        if content:
            content_chars += len(content)
            emit("content", text=content)

        # Reasoning-to-content fallback. Symptom: the upstream parser
        # (or a protocol mismatch — e.g. Gemma 4's asymmetric channel
        # markers `<|channel>thought\n…<channel|>` against a stale
        # `<thought>` config) classifies the model's final answer as
        # `reasoning_content`, so we stream it as `thinking` and
        # `content_chars` ends at zero. With `reasoning_visibility=off`
        # (the TUI default) the user sees an empty bubble. This is
        # observable with `gemma-4-31b-nvfp4-mtp` on gpu-d: turn JSONs
        # show `thinking="\n<channel|>Hello!…"`, `content=""`. The fix
        # above (asymmetric tags + `enable_thinking` kwarg + no prefill)
        # addresses the root cause; this branch is the safety net for
        # any future protocol drift on a thinking-only model. Only
        # promote on a clean stop with no tool calls so we don't paper
        # over real "model is still thinking" truncations.
        reasoning_promoted_to_content = False
        if (
            reasoning_chars > 0
            and content_chars == 0
            and not tool_calls_acc
            and finish_reason in ("stop", None)
            and reasoning_buf
        ):
            promoted = "".join(reasoning_buf).lstrip("\n")
            if promoted:
                emit("content", text=promoted)
                content_chars += len(promoted)
                reasoning_promoted_to_content = True
        t_end = time.monotonic()

        # If the model wants to call tools, parse each call's accumulated
        # `arguments` JSON and emit one `tool_calls` event so the agent
        # runtime can drive the dispatch loop. We don't validate the args
        # here — that's the runner's job.
        #
        # If `finish_reason == "tool_calls"` but the accumulator is empty
        # (some upstreams emit this when they truncate mid-tool-args),
        # downgrade to "stop" rather than emitting an empty `tool_calls`
        # event — the dispatch loop expects at least one call when the
        # finish_reason claims tool_calls, and an empty list there causes
        # a no-op or a confused dispatch.
        if not tool_calls_acc and finish_reason == "tool_calls":
            finish_reason = "stop"
        if tool_calls_acc and finish_reason == "tool_calls":
            from rtxclaw_core.json_repair import repair_truncated_json
            calls_out: list[dict[str, Any]] = []
            for idx in sorted(tool_calls_acc):
                slot = tool_calls_acc[idx]
                raw = slot["arguments"] or "{}"
                # Streaming truncation: vLLM's gemma4 tool-call parser
                # has been observed cutting long `arguments` (e.g. a
                # multi-item TodoWrite) mid-string, producing JSON that
                # `json.loads` can't parse. Try a structural repair
                # (close strings + scopes, drop dangling key tails)
                # before giving up — recovers the model's intent in
                # the common case so the call still dispatches instead
                # of bouncing the model with a misleading arg-shape
                # error.
                try:
                    parsed: Any = repair_truncated_json(raw)
                    if not isinstance(parsed, dict):
                        parsed = {"_arguments": parsed}
                except json.JSONDecodeError:
                    parsed = {"_arguments_unparsed": raw}
                calls_out.append({
                    "id": slot["id"] or f"call_{idx}",
                    "name": slot["name"],
                    "arguments": parsed,
                    "raw_arguments": raw,
                })
            emit("tool_calls", calls=calls_out)

        # Build metrics payload.
        # Naming:
        #   accept_ms  = request acceptance — time from POST to upstream
        #                returning HTTP response headers (ASGI flushes as
        #                soon as the request is queued; prefill not done
        #                yet). Mostly reflects network + upstream queue.
        #   ttft_ms    = time-to-first-token — when the first reasoning
        #                or content delta hits us. Includes accept +
        #                prefill + first-decode-and-emit.
        #   prefill_ms = ttft_ms − accept_ms — the dominant component on
        #                long prompts (uncached-tail prefill plus the
        #                O(N) attention cost on the first decoded token).
        wt_ms = (t_end - t_start) * 1000.0
        accept_ms = (t_headers - t_start) * 1000.0 if t_headers is not None else None
        ttft_ms = (t_first_token - t_start) * 1000.0 if t_first_token is not None else None
        prefill_ms = (
            (t_first_token - t_headers) * 1000.0
            if (t_first_token is not None and t_headers is not None)
            else None
        )
        # Some upstreams (notably cold-start vLLM) hold the HTTP
        # response open until prefill is done — they return the
        # response headers AND the first token together at the end
        # of prefill. Our naïve decomposition then reads as
        # ``accept_ms ≈ 12_800ms`` and ``prefill_ms ≈ 0ms``, which
        # makes the operator-visible stats line lie about where the
        # latency went and (worse) divides ``prompt_tokens`` by ~0
        # to produce a 100M-tok/s prefill rate. Re-attribute when
        # the split looks pathological: if prefill_ms is near zero
        # but ttft_ms is non-trivial, treat ttft minus a small
        # network floor as the real prefill cost. Bump the floor
        # via $RTXCLAW_PREFILL_FLOOR_MS for high-latency networks.
        try:
            floor_ms = float(
                os.environ.get("RTXCLAW_PREFILL_FLOOR_MS", "50") or 50
            )
        except (TypeError, ValueError):
            floor_ms = 50.0
        if (
            prefill_ms is not None
            and ttft_ms is not None
            and prefill_ms < floor_ms
            and ttft_ms > floor_ms * 4
        ):
            prefill_ms = max(0.0, ttft_ms - floor_ms)
            if accept_ms is not None and accept_ms > floor_ms:
                accept_ms = floor_ms
        gen_seconds = (t_end - t_first_token) if t_first_token is not None else None
        tokens_estimated = completion_tokens is None
        if completion_tokens is None:
            # 1 token ≈ 4 chars of English text — rough but useful when the
            # server didn't return usage.
            completion_tokens = max(1, (reasoning_chars + content_chars) // 4)
        # Decode throughput. `gen_seconds` (t_end − t_first_token) is the
        # streaming decode window and the right denominator for a truly
        # streaming upstream. But buffered / non-streaming upstreams
        # (notably OpenRouter's free tier and reasoning models that hold the
        # body until done) deliver the whole completion in a final burst:
        # t_first_token ≈ t_end, so gen_seconds collapses toward 0 and a
        # naïve completion/gen_seconds reports a nonsensical multi-thousand
        # tok/s. When the decode window is implausibly short for the token
        # count, fall back to the post-accept window (prefill+decode) for a
        # bounded, meaningful effective rate.
        decode_seconds = gen_seconds
        if (
            gen_seconds is not None
            and gen_seconds < 0.5
            and completion_tokens
            and completion_tokens > 20
            and accept_ms is not None
            and (wt_ms - accept_ms) > 0
        ):
            decode_seconds = (wt_ms - accept_ms) / 1000.0
        tps = (
            (completion_tokens / decode_seconds)
            if (decode_seconds and decode_seconds > 0)
            else None
        )
        # Prefill TPS is the prompt-side rate: how fast the upstream
        # ingested + KV-attended the (uncached tail of the) prompt. Only
        # meaningful when we have both a prompt-token count and a
        # prefill duration. Cached blocks aren't actually prefilled, so
        # exclude them from the numerator when the upstream returned a
        # ``prompt_tokens_cached`` count.
        prefill_seconds = (prefill_ms / 1000.0) if prefill_ms is not None else None
        prefill_tokens = (
            (prompt_tokens - (prompt_tokens_cached or 0))
            if prompt_tokens is not None
            else None
        )
        prefill_tps = (
            (prefill_tokens / prefill_seconds)
            if (prefill_seconds and prefill_seconds > 0 and prefill_tokens)
            else None
        )
        total_tokens = (
            ((prompt_tokens or 0) + (completion_tokens or 0))
            if (prompt_tokens is not None or completion_tokens is not None)
            else None
        )

        cache_hit_pct = (
            round(100.0 * prompt_tokens_cached / prompt_tokens, 1)
            if prompt_tokens and prompt_tokens_cached is not None
            else None
        )
        # Per-call output-token split. Prefer the upstream's authoritative
        # `reasoning_tokens` when present; otherwise estimate by char
        # ratio so the TUI's stats line still has a "thinking vs result"
        # breakdown for upstreams that don't report the split.
        reasoning_tokens: int | None
        content_tokens: int | None
        if reasoning_tokens_usage is not None and completion_tokens is not None:
            reasoning_tokens = max(0, min(reasoning_tokens_usage, completion_tokens))
            content_tokens = max(0, completion_tokens - reasoning_tokens)
        elif completion_tokens is not None:
            total_chars = reasoning_chars + content_chars
            if total_chars > 0:
                r = int(round(completion_tokens * (reasoning_chars / total_chars)))
                reasoning_tokens = max(0, min(r, completion_tokens))
                content_tokens = max(0, completion_tokens - reasoning_tokens)
            else:
                reasoning_tokens = 0
                content_tokens = completion_tokens
        else:
            reasoning_tokens = None
            content_tokens = None
        prompt_tokens_fresh = (
            max(0, prompt_tokens - (prompt_tokens_cached or 0))
            if prompt_tokens is not None
            else None
        )
        # Token-loop ratio guard. When the model collapses into a token
        # loop (gemma-4-31b-nvfp4-mtp does this on long planning turns)
        # the upstream burns through completion tokens but the streamed
        # text barely grows: we've measured 3022 tokens for 1123 chars
        # (0.37 chars/token) — well below the ~3-4 chars/token English
        # baseline. The streaming detectors inside the round handle the
        # in-stream case; this is the post-stream backstop for round
        # types where streaming detection isn't wired (silent tool-args
        # rounds where `delta.content` was empty the whole time).
        # Per-model override (``Model.loop_chars_per_token_min``) wins
        # over the env default — quantization-fragile families like
        # gemma-4 NVFP4 tighten this to catch collapses one round
        # earlier than the BF16 baseline would.
        # Ratio floor: a hard lower bound for chars-per-completion-token
        # below which we suspect token-collapse. Empirical evidence on
        # 2026-05-13: real collapses (gemma-4 NVFP4 mtp) land at 0.03-0.43
        # chars/token; legitimate thinking-mode turns on Qwen3.6 / Deepseek
        # land at 1.0-1.2 chars/token (lots of compact reasoning tokens
        # followed by a clean tool call). The prior default of 1.5 sat
        # ABOVE the legitimate-reasoning floor and killed valid turns —
        # see LOOP_DETECTED ratio entries from sid=6a049b18e4a4. 0.5 sits
        # well above any observed collapse but well below any observed
        # legitimate reasoning turn. Per-model override still wins.
        ratio_floor = (
            float(mdl.loop_chars_per_token_min)
            if getattr(mdl, "loop_chars_per_token_min", None) is not None
            else None
        )
        if ratio_floor is None:
            try:
                ratio_floor = float(
                    os.environ.get("RTXCLAW_LOOP_CHARS_PER_TOKEN_MIN", "0.5") or 0.5
                )
            except (TypeError, ValueError):
                ratio_floor = 0.5
        try:
            ratio_min_tokens = int(
                os.environ.get("RTXCLAW_LOOP_RATIO_MIN_TOKENS", "500") or 500
            )
        except (TypeError, ValueError):
            ratio_min_tokens = 500
        emitted_chars = reasoning_chars + content_chars
        # Skip the ratio guard when the upstream gave a clean termination
        # signal ("stop" = end-of-turn, "tool_calls" = the model wants to
        # invoke a tool now). A clean finish means the model chose to end
        # this round on purpose; the chars/token ratio reflects how dense
        # the reasoning was, not a runaway loop. The guard still fires on
        # ``length`` (hit max_tokens — could be a loop that was capped),
        # ``None`` (upstream didn't say), or any other irregular state.
        _clean_finish = finish_reason in ("stop", "tool_calls")
        token_loop_suspected = (
            not _clean_finish
            and completion_tokens is not None
            and completion_tokens >= ratio_min_tokens
            and not tokens_estimated
            and emitted_chars / max(1, completion_tokens) < ratio_floor
        )
        emit(
            "metrics",
            wt_ms=round(wt_ms, 1),
            accept_ms=round(accept_ms, 1) if accept_ms is not None else None,
            ttft_ms=round(ttft_ms, 1) if ttft_ms is not None else None,
            prefill_ms=round(prefill_ms, 1) if prefill_ms is not None else None,
            prefill_tps=round(prefill_tps, 2) if prefill_tps is not None else None,
            tps=round(tps, 2) if tps is not None else None,
            completion_tokens=completion_tokens,
            reasoning_tokens=reasoning_tokens,
            content_tokens=content_tokens,
            prompt_tokens=prompt_tokens,
            prompt_tokens_cached=prompt_tokens_cached,
            prompt_tokens_fresh=prompt_tokens_fresh,
            total_tokens=total_tokens,
            cache_hit_pct=cache_hit_pct,
            reasoning_chars=reasoning_chars,
            content_chars=content_chars,
            tokens_estimated=tokens_estimated,
            model=model,                              # which upstream model served this turn
            endpoint=endpoint,
            finish_reason=finish_reason,
            json_decode_failures=json_decode_failures,
            reasoning_promoted_to_content=reasoning_promoted_to_content,
            token_loop_suspected=token_loop_suspected,
            chars_per_token=(
                round(emitted_chars / completion_tokens, 3)
                if completion_tokens and not tokens_estimated
                else None
            ),
        )
        emit("done")
        return 0
    except httpx.HTTPError as e:
        emit("error", message=f"http error: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        emit("error", message=f"{type(e).__name__}: {e}")
        return 1
    finally:
        if dump_fh is not None:
            try:
                dump_fh.close()
            except OSError:
                pass


if __name__ == "__main__":
    sys.exit(main())
