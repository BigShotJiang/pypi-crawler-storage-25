"""CLI subcommands for managing agent configuration.

Wired into the top-level ``rtxclaw`` parser as the ``agent`` subcommand:

    rtxclaw agent init [name]                  # scaffold ~/.rtxclaw/agents/<name>/
    rtxclaw agent list                         # list configured agents + state
    rtxclaw agent status [name]                # gateway-pid + ACP initialize probe
    rtxclaw agent health [name]                # turn-health stats
    rtxclaw agent heartbeat <op> [name]        # heartbeat scheduler config
    rtxclaw agent rollback-backup <op> [name]  # snapshot maintenance

Per-agent daemon lifecycle (``start``/``stop``/``restart``/``serve``/
``logs``) is intentionally absent: every agent runs as a stdio child
of the single rtxclaw gateway, which is started by systemd
(``rtxclaw-gateway.service``). The agent surface here is config-only;
the gateway owns process lifecycle.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import httpx

from rtxclaw_core.agent import (
    AgentConfig,
    agents_root,
    derive_upstream_alias,
    ensure_main_agent,
    global_config_path,
    list_agents,
    load_global_config,
    save_global_config,
)


# ---- internals ----

def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (PermissionError, ProcessLookupError):
        return False


def _say(msg: str) -> None:
    """Write a status line to stderr so it never pollutes -p stdout."""
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()


_ECC_VENV_DEPS = ("pyyaml", "python-pptx", "websockets")
_ECC_VENV_SENTINEL_NAME = ".rtxclaw-deps-installed"


def _install_ecc_bundle(global_cfg: dict) -> None:
    """Clone `everything-claude-code` into ``~/.rtxclaw/ecc/`` and wire
    it into ``skills_dirs`` + ``commands_dirs``. Optional first-run
    wizard step gated by an explicit y/N (default N).

    Performs the smallest install that gets the bundle usable:

    1. ``git clone`` the upstream repo into ``~/.rtxclaw/ecc/``
       (keeps ``.git`` so ``git pull`` updates work). Skipped when
       the directory already exists — a partial / manual clone is
       treated as authoritative.
    2. Create a venv at ``~/.rtxclaw/ecc/skills/.venv`` using the
       running interpreter (``python -m venv``); installs the three
       deps the ECC skill helpers need (``pyyaml``, ``python-pptx``,
       ``websockets``) and marks success with a sentinel file. A
       previous failed install (venv dir exists but sentinel
       missing) is re-attempted; a fresh dependency added later by
       a rtxclaw release can be installed by deleting the sentinel.
    3. ALWAYS reconciles ``skills_dirs`` + ``commands_dirs`` against
       what's actually on disk so a re-run wires existing dirs even
       when the clone was skipped — a manual or partial install no
       longer looks installed-but-not-wired.

    Hard failures raise; the caller downgrades to a warning so the
    wizard doesn't abort.
    """
    import subprocess
    ecc_root = Path.home() / ".rtxclaw" / "ecc"
    ecc_root.parent.mkdir(parents=True, exist_ok=True)
    if not ecc_root.exists():
        _say(f"  cloning ECC → {ecc_root} …")
        subprocess.run(
            [
                "git", "clone", "--depth", "1",
                "https://github.com/affaan-m/everything-claude-code.git",
                str(ecc_root),
            ],
            check=True,
        )
    else:
        _say(f"  ECC dir exists at {ecc_root} — reconciling config without re-cloning")

    venv_root = ecc_root / "skills" / ".venv"
    sentinel = venv_root / _ECC_VENV_SENTINEL_NAME
    if not sentinel.exists():
        try:
            import venv as _venv
            if not venv_root.exists():
                _say(f"  creating skill venv → {venv_root} …")
                _venv.create(str(venv_root), with_pip=True, clear=False)
            else:
                _say(f"  reusing existing venv at {venv_root} (sentinel missing — repairing deps)")
            pip = venv_root / "bin" / "pip"
            if pip.exists():
                rc = subprocess.run(
                    [str(pip), "install", "--quiet", *_ECC_VENV_DEPS],
                    check=False,
                ).returncode
                if rc == 0:
                    sentinel.write_text(
                        f"deps={','.join(_ECC_VENV_DEPS)}\n",
                        encoding="utf-8",
                    )
                else:
                    _say(f"  ⚠ pip install returned {rc} — sentinel NOT written; re-run will retry")
            else:
                _say(f"  ⚠ no pip at {pip} — skills with stdlib-only scripts still work")
        except Exception as exc:  # noqa: BLE001
            _say(f"  ⚠ ECC skill venv setup failed: {exc} (re-run to retry)")

    skills_dir = ecc_root / "skills"
    cmds_dir = ecc_root / "commands"
    legacy_cmds_dir = ecc_root / "legacy-command-shims" / "commands"
    sd = list(global_cfg.get("skills_dirs") or [])
    if str(skills_dir) not in sd and skills_dir.is_dir():
        sd.append(str(skills_dir))
        global_cfg["skills_dirs"] = sd
    cd = list(global_cfg.get("commands_dirs") or [])
    for entry in (cmds_dir, legacy_cmds_dir):
        if entry.is_dir() and str(entry) not in cd:
            cd.append(str(entry))
    if cd:
        global_cfg["commands_dirs"] = cd
    _say(f"  ✓ ECC ready → {ecc_root}")


def _parse_user_md_name(home: Path) -> str:
    """Extract the operator's name from `<home>/USER.md` if pre-filled.

    The wizard writes `- **Name:** Alice` lines via `personalize_user_md`;
    this is the symmetric reader so reconfigure runs can default to the
    name already on disk instead of `getpass.getuser()`. Returns "" when
    the file is missing or the line wasn't filled in.
    """
    p = home / "USER.md"
    if not p.exists():
        return ""
    try:
        body = p.read_text(encoding="utf-8")
    except OSError:
        return ""
    import re as _re
    m = _re.search(r"^- \*\*Name:\*\*\s*(.*)$", body, flags=_re.MULTILINE)
    return (m.group(1).strip() if m else "")


def _ask_bool(ask_fn, prompt: str, default: bool) -> bool:
    """Yes/no prompt with explicit `[Y/n]` or `[y/N]` framing."""
    suffix = "[Y/n]" if default else "[y/N]"
    raw = ask_fn(f"  {prompt} {suffix}: ").strip().lower()
    if not raw:
        return default
    if raw in ("y", "yes", "1", "true", "on"):
        return True
    if raw in ("n", "no", "0", "false", "off"):
        return False
    return default


def _offer_gateway_service(ask) -> None:
    """Final wizard step — get the gateway running so setup ends "up".

    The whole point of the wizard is ``pip install rtxclaw`` → answer
    prompts → you're running. Without this the operator lands on a
    bare ``rtxclaw gateway is not running`` pointer and has to go
    hunting for ``systemctl`` incantations.

    Config is already saved by the time this runs, so this only
    affects whether the gateway is LIVE when the wizard returns. It
    NEVER raises and NEVER blocks the return: on any failure or Ctrl+C
    it degrades to a one-line "start it yourself" pointer.

    First-run is deliberately **sudo-free**: it never installs a system
    service. The gateway is started in the background in user space.
    Survive-reboot via systemd is an explicit opt-in the operator can
    run later (`rtxclaw gateway install-service`), not part of setup.

    Resolution:
      1. Gateway already up (systemd unit or CLI-started) → say so.
      2. Otherwise → start the gateway in the BACKGROUND (user space,
         no sudo, no systemd) so this session is up and running.

    ``ask`` is accepted for call-site symmetry with the rest of the
    wizard but is unused now that there's no service prompt.
    """
    from rtxclaw_agent import gateway_cli as gwcli

    _say("")
    _say("  ── Service ──")

    # (1) Already running? _running() tracks the CLI pidfile; a
    # systemd-managed gateway won't show there, so also probe /health.
    try:
        running, pid = gwcli._running()
    except Exception:  # noqa: BLE001
        running, pid = False, None
    if running:
        _say(f"  ✓ rtxclaw gateway already running (pid={pid})")
        return
    gw = gwcli._gateway_config()
    url = f"http://{gw['host']}:{gw['port']}"
    try:
        if httpx.get(f"{url}/health", timeout=1.0).status_code == 200:
            _say(f"  ✓ rtxclaw gateway already running at {url}")
            return
    except httpx.HTTPError:
        pass

    try:
        # First-run NEVER prompts for sudo. We always bring the gateway
        # up in user space (no root, no systemd) so `pip install rtxclaw`
        # → wizard → running needs zero privileges. The survive-reboot
        # path stays available as an explicit, opt-in command
        # (`rtxclaw gateway install-service`, systemd) for operators who
        # actually want a boot service.
        res = gwcli.start_gateway_background()
        if res["ok"]:
            if res["already_running"]:
                _say(f"  ✓ gateway already running (pid={res['pid']})")
            else:
                _say(f"  ✓ gateway started (pid={res['pid']}) → {res['url']}")
                if gwcli.systemd_available():
                    _say(
                        "    (background run — won't survive a reboot. For a "
                        "boot service, run `rtxclaw gateway install-service`.)"
                    )
        else:
            _say(f"  couldn't start the gateway automatically: {res['error']}")
            _say(
                "    start it yourself with `rtxclaw gateway start` "
                "(or `rtxclaw gateway install-service` for a boot service)."
            )
    except (EOFError, KeyboardInterrupt):
        _say("")
        _say(
            "  skipped service setup — start the gateway later with "
            "`rtxclaw gateway install-service` or `rtxclaw gateway start`."
        )
    except Exception as e:  # noqa: BLE001
        _say(
            f"  service setup hit an error ({e}); start the gateway with "
            "`rtxclaw gateway start`."
        )


def setup_main_wizard(*, reconfigure: bool = False) -> AgentConfig | None:
    """Interactive setup for the `main` agent — same flow first-run and re-run.

    `reconfigure=False` (first-run): empty defaults; called automatically
    when `~/.rtxclaw/agents/main/config.json` is missing.

    `reconfigure=True` (re-run): pre-fills every prompt from the existing
    config so a `rtxclaw configure` invocation is a quick walk-through
    where Enter keeps each value. If the agent isn't yet configured we
    fall through to first-run behaviour.

    Walks the user through every AgentConfig variable:

    1. Model deployments (alias/baseUrl/id/backend/contextWindow).
    2. Operator name (pre-fills USER.md).
    3. Brave Search API key (optional, powers `web_search` tool).
    4. Telegram bot token + allowed chat_ids (optional).
    5. Local agent port (default 7700, free-port fallback).
    6. Advanced: temperature, enable_thinking, permission_mode,
       compact_at_frac, host, heartbeat_enabled, heartbeat_interval_s.
       Gated behind a single Y/N so first-run users don't have to slog
       through them.

    Returns the saved config, or None if the user aborted.
    """
    if not sys.stdin.isatty():
        _say(
            "agent 'main' is not configured and stdin is not a tty.\n"
            "run `rtxclaw agent init` interactively first."
        )
        return None

    from rtxclaw_core import providers as prov
    from rtxclaw_core.agent import personalize_user_md
    import getpass
    import httpx as _httpx

    defaults = AgentConfig(name="main")

    # When `reconfigure=True` and a config exists on disk, every prompt
    # below pre-fills from it. When the user calls `rtxclaw configure`
    # before the first-run install, fall through to empty defaults.
    existing_cfg: AgentConfig | None = None
    if reconfigure:
        try:
            existing_cfg = AgentConfig.load("main")
        except FileNotFoundError:
            existing_cfg = None
    is_rerun = existing_cfg is not None

    default_username = ""
    if is_rerun:
        default_username = _parse_user_md_name(existing_cfg.home)
    if not default_username:
        try:
            default_username = getpass.getuser()
        except Exception:  # noqa: BLE001
            default_username = os.environ.get("USER") or ""

    _say("")
    _say(f"  rtxclaw — {'reconfigure' if is_rerun else 'first-run setup'}")
    _say(f"  global config (LLM endpoint / model / backend) → {global_config_path()}")
    _say(f"  per-agent config (port + identity)             → {agents_root() / 'main' / 'config.json'}")
    _say("  Ctrl+C / EOF aborts at any point; no file is written until the end.")
    _say("")

    try:
        # input()'s prompt goes to stdout, so write the prompt to stderr first
        # and read with a blank input() prompt — keeps stdout clean even when
        # the wizard is run inside a stdout-piped context.
        def ask(prompt: str) -> str:
            sys.stderr.write(prompt)
            sys.stderr.flush()
            return input("")

        # ----- 1. Collect models (one or more) -----
        _say("  Backend hints:")
        _say(f"    - vLLM    {prov.VLLM.typical_endpoint_hint}")
        _say(f"    - SGLang  {prov.SGLANG.typical_endpoint_hint}")
        _say("")

        endpoints: list[dict] = []

        def collect_one_endpoint():
            """Collect a single model entry (alias + baseUrl + id +
            backend + contextWindow). Returns a dict ready for
            `models[]`. The wizard loops on this so the operator can
            add as many model deployments as they want."""
            from rtxclaw_core import provider_presets as pp
            # Provider picker — pick a known OpenAI-compatible provider
            # (pre-fills baseUrl + apiKeyEnv) or 'c' to type a custom URL.
            _say("  Pick a provider:")
            for i, p in enumerate(pp.PROVIDER_PRESETS, 1):
                tail = f"key: ${p.api_key_env}" if p.api_key_env else "local, no key"
                extra = f" — {p.note}" if p.note else ""
                _say(f"    {i:>2}. {p.label:<18} {p.base_url}  ({tail}){extra}")
            _say("     c. Custom OpenAI-compatible endpoint (type the URL)")
            preset = None
            sel = ask("  provider [c]: ").strip().lower()
            if sel.isdigit() and 1 <= int(sel) <= len(pp.PROVIDER_PRESETS):
                preset = pp.PROVIDER_PRESETS[int(sel) - 1]
            elif sel and sel not in ("c", "custom"):
                preset = pp.preset_by_key(sel)  # also accept the key name
                if preset is None:
                    _say(f"    unknown provider {sel!r} — falling back to custom; "
                         "type the OpenAI-compatible baseUrl below.")

            endpoint = ""
            if preset is not None:
                endpoint = preset.base_url.rstrip("/")
                _say(f"    → {preset.label}: {endpoint}")
            while not endpoint:
                raw = ask("  baseUrl: ").strip()
                if not raw:
                    _say("    (required — try again, or Ctrl+C to abort)")
                    continue
                endpoint = raw.rstrip("/")
                if not endpoint.endswith("/v1") and not endpoint.endswith("/openai"):
                    guess = endpoint + "/v1"
                    _say(f"    (no /v1 suffix; will try {guess})")
                    endpoint = guess

            api_key_env_default = (
                preset.api_key_env if preset is not None
                else ("OPENROUTER_API_KEY" if "openrouter.ai" in endpoint else "")
            )
            api_key_env = ask(
                f"  apiKeyEnv [{api_key_env_default or 'blank = none'}]: "
            ).strip() or api_key_env_default
            headers: dict[str, str] = {}
            if "openrouter.ai" in endpoint:
                headers["HTTP-Referer"] = ask(
                    "  HTTP-Referer [blank = omit]: "
                ).strip()
                headers["X-Title"] = ask(
                    "  X-Title [rtxclaw]: "
                ).strip() or "rtxclaw"
                headers = {k: v for k, v in headers.items() if v}
            probe_headers = dict(headers)
            if api_key_env and os.environ.get(api_key_env):
                probe_headers.setdefault("Authorization", f"Bearer {os.environ[api_key_env]}")

            # Probe + detect backend
            provider = prov.UNKNOWN
            models_data: list[dict] = []
            try:
                provider, models_data = prov.detect_from_endpoint_sync(endpoint, timeout=5.0, headers=probe_headers)
                if provider is prov.UNKNOWN:
                    _say(
                        f"    probed {endpoint}/models — reachable but `owned_by` "
                        f"didn't match vllm/sglang; treating as generic OpenAI-compat."
                    )
                else:
                    _say(f"    detected backend: {provider.label} ✓")
            except _httpx.HTTPError as e:
                _say(f"    couldn't reach {endpoint}/models: {e}")
                _say("    (continuing with manual backend)")

            choice = ask(
                f"  backend [{provider.name or 'unknown'}] "
                "(enter vllm / sglang / unknown to override): "
            ).strip().lower() or provider.name
            backend = prov.by_name(choice)

            # Alias — short user-facing handle for `/model <alias>`.
            alias_default = derive_upstream_alias(endpoint)
            alias_prompt = (
                f"  alias (short name for /model) [{alias_default}]: "
                if alias_default
                else "  alias (short name for /model): "
            )
            alias = ask(alias_prompt).strip() or alias_default

            # Model id (the value sent in chat-completions `model` field).
            # Model id is REQUIRED — auto-discovery via `/v1/models`
            # has been removed because it silently bound sessions to
            # whichever model the upstream happened to expose first,
            # which drifted as operators reloaded vLLM/SGLang. Prompt
            # until the operator types something non-empty.
            if models_data:
                default_model = prov.first_model_id(models_data) or ""
                _say(f"    available model ids:")
                for m in models_data[:5]:
                    _say(f"      - {m.get('id')}")
                if len(models_data) > 5:
                    _say(f"      … and {len(models_data) - 5} more")
                prompt = (
                    f"  id [{default_model} — required]: "
                    if default_model else "  id (required): "
                )
            else:
                default_model = ""
                prompt = "  id (required): "
            while True:
                ep_model = ask(prompt).strip()
                if not ep_model and default_model:
                    ep_model = default_model
                if ep_model:
                    break
                _say("    model id is required — type one of the listed ids "
                     "(no auto-discover).")

            # contextWindow — try vLLM's `max_model_len` then SGLang's
            # `/get_model_info`. Prompt with the detected value (or
            # 96000 fallback) so the operator can override but doesn't
            # have to remember the number on a clean install.
            detected_ctx = prov.probe_max_context(endpoint, models_data, headers=probe_headers)
            if detected_ctx:
                _say(f"    detected contextWindow: {detected_ctx:,} tokens ✓")
                ctx_default = detected_ctx
            else:
                _say("    couldn't auto-detect contextWindow (no max_model_len exposed)")
                ctx_default = 96000
            raw_ctx = ask(
                f"  contextWindow [{ctx_default}]: "
            ).strip()
            try:
                ep_max_ctx = int(raw_ctx) if raw_ctx else ctx_default
                if ep_max_ctx <= 0:
                    raise ValueError
            except ValueError:
                _say(f"    invalid number {raw_ctx!r}; using {ctx_default}")
                ep_max_ctx = ctx_default

            # OpenClaw-aligned shape: each model deployment gets
            # `alias` (rtxclaw-specific user handle), `baseUrl` (the
            # OpenAI-compat endpoint), `id` (model id), `backend`
            # (vllm/sglang/unknown — rtxclaw concept), `contextWindow`
            # and `maxTokens` (informational output cap).
            row = {
                "alias": alias,
                "baseUrl": endpoint,
                "id": ep_model,
                "backend": backend.name,
                "contextWindow": ep_max_ctx,
                "maxTokens": 0,  # operator can fill in later if desired
            }
            if api_key_env:
                row["apiKeyEnv"] = api_key_env
            if headers:
                row["headers"] = headers
            return row

        # On a re-run with existing models, offer to keep them as-is.
        # The model collection sub-wizard probes /v1/models per row, which
        # is slow and unnecessary if you're just here to update telegram.
        if is_rerun and existing_cfg.models:
            _say("  Currently configured models:")
            for i, m in enumerate(existing_cfg.models, 1):
                _say(
                    f"    {i}. alias={m.get('alias','')!r:<10} "
                    f"baseUrl={m.get('baseUrl','')} "
                    f"id={m.get('id','') or '<auto>'} "
                    f"backend={m.get('backend','') or '<unknown>'} "
                    f"ctx={m.get('contextWindow', 0):,}"
                )
            keep = _ask_bool(ask, "keep these models as-is?", default=True)
            if keep:
                endpoints = [dict(m) for m in existing_cfg.models]

        # Collect at least one model deployment, then keep asking until
        # the operator says they're done. No artificial cap — `models[]`
        # is just a JSON list, and the wizard doesn't display indices so
        # the prompt feels the same on the first or the tenth row.
        # `while True` (not `while not endpoints`) so "add another? yes"
        # actually loops — the previous condition exited as soon as the
        # first row landed.
        while True:
            if endpoints and not _ask_bool(ask, "add another model?", default=False):
                break
            ep = collect_one_endpoint()
            endpoints.append(ep)
            _say(f"    → alias={ep['alias']}, baseUrl={ep['baseUrl']}")

        # If the user kept existing rows, still let them add more.
        if is_rerun and existing_cfg and existing_cfg.models and endpoints == [
            dict(m) for m in existing_cfg.models
        ]:
            while _ask_bool(ask, "add another model deployment?", default=False):
                ep = collect_one_endpoint()
                endpoints.append(ep)
                _say(f"    → alias={ep['alias']}, baseUrl={ep['baseUrl']}")

        # The first row is the primary (used when no --model flag).
        primary = endpoints[0]
        endpoint = primary["baseUrl"]
        alias = primary["alias"]
        model = primary.get("id", "")
        provider = prov.by_name(primary.get("backend", "unknown"))
        primary_max_context = primary.get("contextWindow") or 96000

        # ----- 4. Your name (pre-fills USER.md) -----
        name_prompt = (
            f"  your name (for USER.md) [{default_username}]: "
            if default_username
            else "  your name (for USER.md, blank = leave empty): "
        )
        user_name = ask(name_prompt).strip() or default_username

        # ----- 5. Web search (Brave) — optional -----
        # Brave Search powers the `web_search` tool. Skipping is fine —
        # the tool will surface a friendly "key not configured" error if
        # the model invokes it, and other tools are unaffected. Default
        # is the env var if set, else whatever's in the global config.
        existing = load_global_config()
        brave_default = (
            os.environ.get("BRAVE_API_KEY")
            or str(existing.get("brave_api_key") or "")
        )
        if brave_default:
            # Mask the key in the prompt — show only the first few chars
            # so the user knows it's there without dumping the secret in
            # their terminal scrollback.
            mask = brave_default[:6] + "…" if len(brave_default) > 6 else "(set)"
            brave_prompt = (
                f"  Brave Search API key (web_search tool) [{mask}, "
                "Enter to keep]: "
            )
        else:
            brave_prompt = (
                "  Brave Search API key (web_search tool, blank to skip; "
                "get one at https://brave.com/search/api): "
            )
        brave_key = ask(brave_prompt).strip() or brave_default

        # ----- 6. Telegram — optional -----
        # Telegram fields live in ``~/.rtxclaw/telegram/config.json``
        # — the bot is its own service, not part of any one agent. On
        # both first-run and re-run we pre-fill from there. Old
        # per-agent ``telegram_bot_token`` keys are still honored as a
        # one-time migration so users coming from the coupled layout
        # don't have to retype their token.
        from rtxclaw_telegram.config import TelegramConfig as _TgCfg
        _tg_cfg = _TgCfg.load()
        telegram_bot_token = _tg_cfg.bot_token or (
            str(getattr(existing_cfg, "telegram_bot_token", "") or "")
            if is_rerun else ""
        )
        telegram_allowed_chat_ids = list(_tg_cfg.allowed_chat_ids) or (
            list(getattr(existing_cfg, "telegram_allowed_chat_ids", []) or [])
            if is_rerun else []
        )

        if telegram_bot_token:
            # Mask the token in the prompt — show only the first/last
            # few chars so the user knows it's there.
            mask = telegram_bot_token[:8] + "…" + telegram_bot_token[-4:]
            tg_want = ask(
                f"  Telegram bot token [{mask}, Enter to keep]: "
            ).strip()
            if tg_want:
                telegram_bot_token = tg_want
            # Ask about chat_ids if we have a token.
            if telegram_allowed_chat_ids:
                _say(f"    current allowed chat_ids: {telegram_allowed_chat_ids}")
                chat_ids_input = ask(
                    "  add more chat_ids (comma-separated, blank to keep current): "
                ).strip()
                if chat_ids_input:
                    try:
                        new_ids = [int(x.strip()) for x in chat_ids_input.split(",") if x.strip()]
                        telegram_allowed_chat_ids = list(set(telegram_allowed_chat_ids + new_ids))
                    except ValueError:
                        _say("    invalid input; keeping current chat_ids")
            else:
                _say("")
                _say(
                    "    You'll need to whitelist your Telegram chat_id. "
                    "The easiest way:"
                )
                _say("      1. Start the agent:  rtxclaw agent start")
                _say("      2. Send any message to your bot")
                _say("      3. Check the log:     tail ~/.rtxclaw/agents/main/logs/telegram.log")
                _say("         (it will print your chat_id)")
                _say("      4. Re-run this wizard or edit config.json to add it")
                _say("")
        else:
            tg_want = ask(
                "  set up Telegram bot? [y/N] (get a token from @BotFather): "
            ).strip().lower()
            if tg_want in ("y", "yes"):
                _say("")
                _say("    1. Message @BotFather on Telegram and /newbot")
                _say("    2. Follow prompts (name + username)")
                _say("    3. Copy the HTTP API token it gives you")
                _say("")
                while not telegram_bot_token:
                    telegram_bot_token = ask(
                        "  Telegram bot token (from @BotFather): "
                    ).strip()
                    if not telegram_bot_token:
                        _say("    (required — try again, or Ctrl+C to abort)")
                        continue
                    # Quick format sanity check: BotFather tokens are
                    # <numeric>:<alphanumeric> — reject obviously wrong input.
                    if ":" not in telegram_bot_token:
                        _say("    (doesn't look like a valid token — expected <number>:<string>)")
                        telegram_bot_token = ""

                _say("")
                _say(
                    "    After setup, you'll need to whitelist your Telegram "
                    "chat_id. The easiest way:"
                )
                _say("      1. Start the agent:  rtxclaw agent start")
                _say("      2. Send any message to your bot")
                _say("      3. Check the log:     tail ~/.rtxclaw/agents/main/logs/telegram.log")
                _say("         (it will print your chat_id)")
                _say("      4. Re-run this wizard or edit config.json to add it")
                _say("")
            else:
                _say("    (skip — you can always add it later with `rtxclaw configure` or editing config.json)")
                _say("")

        # ----- 7. Port -----
        # No prompt. Under the single-process gateway every agent is
        # mounted at /acp/<name> on the ONE gateway port, so a per-agent
        # `port` is vestigial — asking for it just confused operators
        # into thinking they'd moved the gateway (they hadn't; the
        # gateway reads the `gateway` block of the global config, not
        # `cfg.port`). Keep the field at its default so retired
        # daemon-path readers still get a sane value; to actually move
        # the listener, edit `gateway` in ~/.rtxclaw/config.json.
        port = existing_cfg.port if is_rerun else defaults.port

        # ----- 8. Advanced settings -----
        # Gated behind a single Y/N so first-run users don't slog
        # through six more prompts. On re-run the prompt offers to
        # review them; on first-run the defaults are sane.
        adv_default = is_rerun  # re-runs start showing
        adv_label = "review" if is_rerun else "configure"
        show_advanced = _ask_bool(
            ask,
            f"{adv_label} advanced settings (temperature, thinking, "
            "permission mode, compaction, heartbeat, host)?",
            default=False if not is_rerun else False,
        )

        # Defaults: existing config when re-running, dataclass defaults otherwise.
        adv_src = existing_cfg if is_rerun else defaults
        temperature = float(getattr(adv_src, "temperature", defaults.temperature))
        enable_thinking = bool(getattr(adv_src, "enable_thinking", defaults.enable_thinking))
        permission_mode = str(getattr(adv_src, "permission_mode", defaults.permission_mode))
        compact_at_frac = float(getattr(adv_src, "compact_at_frac", defaults.compact_at_frac))
        host = str(getattr(adv_src, "host", defaults.host))
        heartbeat_enabled = bool(getattr(adv_src, "heartbeat_enabled", defaults.heartbeat_enabled))
        heartbeat_interval_s = int(
            getattr(adv_src, "heartbeat_interval_s", defaults.heartbeat_interval_s)
        )
        # Optional `# SYSTEM` block appended after the .md context. Most
        # users leave it empty.
        system_extra = str(getattr(adv_src, "system", defaults.system))
        description = str(getattr(adv_src, "description", "The default rtxclaw agent."))

        if show_advanced:
            _say("")
            _say("  ── Advanced ──")

            # Temperature
            raw = ask(f"  temperature [{temperature}]: ").strip()
            if raw:
                try:
                    temperature = float(raw)
                except ValueError:
                    _say(f"    invalid float; keeping {temperature}")

            # enable_thinking (Qwen3 chat-template flag)
            enable_thinking = _ask_bool(
                ask,
                "enable_thinking (chat_template_kwargs.enable_thinking for Qwen3-family)?",
                default=enable_thinking,
            )

            # Permission mode
            raw = ask(
                f"  permission_mode [{permission_mode}] (plan / ask / auto): "
            ).strip().lower()
            if raw in ("plan", "ask", "auto"):
                permission_mode = raw
            elif raw:
                _say(f"    unrecognised; keeping {permission_mode}")

            # Proactive compaction trigger
            raw = ask(
                f"  compact_at_frac [{compact_at_frac}] "
                "(0.85 = squeeze early; 1.0 = wait for overflow): "
            ).strip()
            if raw:
                try:
                    val = float(raw)
                    if 0.0 < val <= 1.0:
                        compact_at_frac = val
                    else:
                        _say(f"    out of range (0..1]; keeping {compact_at_frac}")
                except ValueError:
                    _say(f"    invalid float; keeping {compact_at_frac}")

            # Host (loopback by default — change only if you intend to
            # expose the gateway to the network).
            raw = ask(f"  host [{host}]: ").strip()
            if raw:
                host = raw

            # Heartbeat
            heartbeat_enabled = _ask_bool(
                ask,
                "heartbeat_enabled (background tick into a dedicated session)?",
                default=heartbeat_enabled,
            )
            if heartbeat_enabled:
                raw = ask(
                    f"  heartbeat_interval_s [{heartbeat_interval_s}] (seconds): "
                ).strip()
                if raw:
                    try:
                        val = int(raw)
                        if val > 0:
                            heartbeat_interval_s = val
                        else:
                            _say(f"    must be > 0; keeping {heartbeat_interval_s}")
                    except ValueError:
                        _say(f"    invalid int; keeping {heartbeat_interval_s}")

            # System extra (`# SYSTEM` appended block). Show the current
            # value compressed to one line so the user can decide if they
            # want to clear/replace it. Leave editing the multi-line body
            # to a real editor — the prompt accepts a one-line value or
            # blank-to-keep / "-" to clear.
            sys_show = system_extra.replace("\n", " ⏎ ")[:60]
            sys_label = sys_show or "<empty>"
            raw = ask(
                f"  system extra (# SYSTEM block) [{sys_label}, "
                "Enter to keep, '-' to clear, or new text]: "
            )
            if raw == "-":
                system_extra = ""
            elif raw:
                system_extra = raw

            # Description (one-liner shown in `agent list`).
            raw = ask(f"  description [{description}]: ").strip()
            if raw:
                description = raw
            _say("")
    except (EOFError, KeyboardInterrupt):
        _say("\n  setup canceled — nothing written.")
        return None

    # Global config: shared across every agent. Preserve any existing
    # global fields the wizard didn't touch (e.g. permission_mode set by
    # editing the JSON manually or by a future wizard pass).
    glob = load_global_config()
    glob.update({
        "upstream_endpoint": endpoint,
        "upstream_model": model,
        "upstream_alias": alias,
        "backend": provider.name,
        # OpenClaw-aligned model deployments. Each row carries its own
        # `contextWindow`, used by the runtime's compaction guard
        # per-session (falls back to `upstream_max_context` for legacy
        # / single-primary configs).
        "models": endpoints,
        # Kept as a top-level fallback for callers that haven't been
        # ported to per-session contextWindow yet (chat_completions
        # passthrough, control_status snapshot).
        "upstream_max_context": primary_max_context,
        # Advanced fields — written even when the user skipped the
        # advanced block, so the saved config matches what was effective
        # at wizard time. Existing values (or dataclass defaults) round-
        # trip cleanly when the user just hits Enter through the prompts.
        "temperature": temperature,
        "enable_thinking": enable_thinking,
        "permission_mode": permission_mode,
        "compact_at_frac": compact_at_frac,
        "host": host,
    })
    # Explicitly drop the legacy alias if a previous wizard run wrote it.
    glob.pop("upstream_endpoints", None)
    if brave_key:
        glob["brave_api_key"] = brave_key

    # Default MCP servers (youtube + markitdown) + the skills map —
    # shipped enabled out of the box. Shared with the zero-config
    # quickstart via `_seed_mcp_and_skills` so both first-run paths
    # produce the same baseline. Never clobbers operator config: MCP
    # only-if-absent, skills via setdefault (an explicit `enabled: false`
    # the operator set by hand survives — they keep a kill switch).
    _seed_mcp_and_skills(glob)

    # Optional ECC (everything-claude-code) bundle install — 228+
    # Claude Code skills covering instincts, memory ops, security
    # scanning, continuous learning, research workflows. Opt-in by
    # design: a fresh user shouldn't be forced to clone a multi-MB
    # third-party repo + create a Python venv before they can chat.
    # Operators who want it can also run ``rtxclaw configure`` later
    # OR install manually (clone to ``~/.rtxclaw/ecc/``, append
    # ``~/.rtxclaw/ecc/skills`` to ``skills_dirs`` in the global
    # config). Default is NO so the wizard stays fast.
    ecc_skills_dir = Path.home() / ".rtxclaw" / "ecc" / "skills"
    if ecc_skills_dir.is_dir():
        # Already-present install (manual clone, prior wizard run, or
        # rtxclaw configure). Reconcile config so a partial install
        # still gets wired into skills_dirs / commands_dirs.
        try:
            _install_ecc_bundle(glob)
        except Exception as exc:  # noqa: BLE001
            _say(f"  ⚠ ECC reconcile failed: {exc}")
    else:
        _say("")
        _say("  Optional: everything-claude-code (ECC) skill bundle")
        _say(
            "  ~228 Claude Code skills (instincts, memory, security "
            "scanning, …). Adds ~50 MB on disk + a Python venv for "
            "skill scripts. Skip for a leaner install — you can run "
            "the install later via `rtxclaw configure` or git-clone "
            "manually."
        )
        choice = ask("  install ECC now? [y/N]: ").strip().lower()
        if choice in ("y", "yes"):
            try:
                _install_ecc_bundle(glob)
            except Exception as exc:  # noqa: BLE001
                _say(f"  ⚠ ECC install failed: {exc}")
                _say("    skipping — you can retry via `rtxclaw configure`")

    save_global_config(glob)
    if brave_key:
        _say(f"  ✓ saved global config + Brave key → {global_config_path()}")
    else:
        _say(f"  ✓ saved global config → {global_config_path()}")

    # Per-agent config: only what differs between agents (name,
    # description, port, system extra, heartbeat). Telegram fields go
    # to the standalone bot config below.
    cfg = AgentConfig(
        name="main",
        description=description,
        port=port,
        system=system_extra,
        heartbeat_enabled=heartbeat_enabled,
        heartbeat_interval_s=heartbeat_interval_s,
    )
    cfg.save()
    # Persist the bot-wide Telegram config to its own home. The agent
    # gateway no longer reads these fields; the standalone Telegram
    # service does.
    if telegram_bot_token or telegram_allowed_chat_ids:
        from rtxclaw_telegram.config import TelegramConfig as _TgCfg
        tg_cfg = _TgCfg.load()
        if telegram_bot_token:
            tg_cfg.bot_token = telegram_bot_token
        if telegram_allowed_chat_ids:
            tg_cfg.allowed_chat_ids = list(telegram_allowed_chat_ids)
        if not tg_cfg.default_agent:
            tg_cfg.default_agent = "main"
        tg_cfg.save()
        _say(f"  ✓ saved telegram config → {tg_cfg.config_path}")
    ensure_main_agent()  # scaffolds SOUL/USER/TOOLS/AGENTS from upstream defaults
    if user_name:
        if personalize_user_md(cfg, user_name):
            _say(f"  ✓ pre-filled USER.md with name={user_name!r}")
    _say(f"  ✓ saved main agent  → {cfg.config_path}")

    # Offer to wire up external coding agents (Claude Code / Codex / Cursor /
    # Antigravity) as rtxclaw delegates — detect what's installed, quick-install
    # the rest, and scaffold each. Best-effort: never blocks the wizard.
    _say("")
    _say("  ── Coding agents ──")
    try:
        setup_external_agents(emit=_say)
    except Exception:  # noqa: BLE001
        _say("  (skipped external-agent setup; run `rtxclaw agents` later)")

    # Final step: get the gateway live so the wizard ends "up and
    # running" instead of dumping a `systemctl` to-do on the operator.
    # `ask` is still in scope here (try/except doesn't open a new
    # scope) and the wizard only reaches this point on a clean run.
    _offer_gateway_service(ask)

    # Re-load so the returned cfg reflects the merged (global + per-agent) view.
    return AgentConfig.load("main")


def _seed_mcp_and_skills(glob: dict) -> None:
    """Seed default MCP servers + the skills map into ``glob`` in place.

    Shared by the first-run wizard and the zero-config quickstart so both
    produce the same baseline. Never clobbers operator config: MCP
    defaults only when absent; skills via ``setdefault`` (an explicit
    ``enabled: false`` survives). ``sys.executable`` is the rtxclaw venv,
    so the bundled MCP servers import with no PYTHONPATH wrangling.
    """
    import importlib.util as _ilu
    _venv_python = sys.executable
    if not (glob.get("mcpServers") or glob.get("mcp_servers")):
        # Only seed a bundled MCP server when its (optional, `full`-extra)
        # deps are importable — a lean `pip install rtxclaw` shouldn't wire
        # up servers that can't spawn. `pip install rtxclaw[full]` brings
        # these in; re-running `rtxclaw configure` then seeds them.
        servers: dict = {}
        if _ilu.find_spec("yt_dlp") and _ilu.find_spec("youtube_transcript_api"):
            servers["youtube"] = {
                "command": _venv_python,
                "args": ["-m", "rtxclaw_mcp.youtube_mcp_server"],
                "env": {},
            }
        if _ilu.find_spec("markitdown_mcp"):
            servers["markitdown"] = {
                "command": _venv_python,
                "args": ["-m", "markitdown_mcp"],
                "env": {},
            }
        if servers:
            glob["mcpServers"] = servers
            glob.pop("mcp_servers", None)
    from rtxclaw_core.skills import discover_skills as _discover_skills
    _skills_map = glob.get("skills")
    if not isinstance(_skills_map, dict):
        _skills_map = {}
    for _s in _discover_skills(include_disabled=True):
        _skills_map.setdefault(_s.name, {"enabled": True})
    if _skills_map:
        glob["skills"] = _skills_map


def _write_quickstart_config() -> AgentConfig | None:
    """Zero-config first-run: ship the free NVIDIA Nemotron default
    (OpenRouter + shared demo-key fallback) so ``pip install rtxclaw`` →
    ``rtxclaw`` chats immediately, no signup. The user upgrades later by
    exporting their own ``OPENROUTER_API_KEY`` or running
    ``rtxclaw configure`` (which always wins over the shared key).
    """
    from rtxclaw_core import provider_presets as pp

    glob = load_global_config()
    # Don't clobber an already-configured global: `main` can be missing
    # while a prior global config (models/endpoint) exists. Only write the
    # Nemotron default when there's nothing to lose.
    fresh = not glob.get("models")
    if fresh:
        glob.update({
            "upstream_endpoint": pp.DEFAULT_BASE_URL,
            "upstream_model": pp.DEFAULT_MODEL,
            "upstream_alias": pp.DEFAULT_MODEL_ALIAS,
            "backend": "unknown",
            "models": [pp.default_model_row()],
            "upstream_max_context": pp.DEFAULT_CONTEXT_WINDOW,
        })
        glob.pop("upstream_endpoints", None)
    _seed_mcp_and_skills(glob)
    save_global_config(glob)
    _say("")
    if fresh:
        _say(f"  ✓ free Nemotron default saved → {global_config_path()}")
        _say("    (shared demo key — set your own with `export OPENROUTER_API_KEY=…`")
        _say("     or `rtxclaw configure` for any provider)")
    else:
        _say(f"  ✓ kept existing LLM config; created main agent → {global_config_path()}")
    cfg = AgentConfig(name="main", description="rtxclaw main agent")
    cfg.save()
    ensure_main_agent()  # scaffolds SOUL/USER/TOOLS/AGENTS
    _say(f"  ✓ saved main agent → {cfg.config_path}")
    _offer_gateway_service(lambda *_a, **_k: "")
    return AgentConfig.load("main")


def _write_local_gpu_config(setup) -> AgentConfig | None:
    """The moat path: wire ``main`` at a local model on the detected GPU(s).

    ``setup`` is a :class:`rtxclaw_core.local_gpu.LocalSetup`. Mirrors
    :func:`_write_quickstart_config` but saves the local-server row (no API
    key, points at 127.0.0.1) instead of the cloud Nemotron default. Only
    runs when there's nothing to clobber (``fresh``)."""
    row = setup.row
    glob = load_global_config()
    fresh = not glob.get("models")
    if fresh:
        glob.update({
            "upstream_endpoint": row["baseUrl"],
            "upstream_model": row["id"],
            "upstream_alias": row["alias"],
            "backend": row["backend"],
            "models": [row],
            "upstream_max_context": row["contextWindow"],
        })
        glob.pop("upstream_endpoints", None)
    _seed_mcp_and_skills(glob)
    save_global_config(glob)
    verb = "provisioned" if setup.provisioned else "found running"
    _say("")
    _say(f"  ✓ detected {setup.profile.short_name()} — using your local GPU")
    if fresh:
        _say(f"  ✓ {verb} local model '{row['id']}' "
             f"({setup.server.backend}) → {row['baseUrl']}")
        _say(f"    saved → {global_config_path()}  "
             f"(change anytime with `rtxclaw configure`)")
    else:
        _say(f"  ✓ kept existing LLM config; created main agent → {global_config_path()}")
    cfg = AgentConfig(name="main", description="rtxclaw main agent")
    cfg.save()
    ensure_main_agent()
    _say(f"  ✓ saved main agent → {cfg.config_path}")
    _offer_gateway_service(lambda *_a, **_k: "")
    return AgentConfig.load("main")


def _start_background_provision(profile, choice) -> AgentConfig | None:
    """Wire ``main`` at a local endpoint and kick off model provisioning in a
    DETACHED worker, returning immediately so the TUI launches and can show a
    live download bar (it polls ``local_gpu.provision_status``). The gateway
    starts pointed at the soon-to-serve local endpoint; the TUI gates chat
    until the model is up."""
    from rtxclaw_core import local_gpu as lg

    model_id = lg._provision_model_id(choice, profile)
    if not model_id:
        return _write_quickstart_config()  # no downloadable model → cloud default
    base_url = f"http://127.0.0.1:{lg._provision_port()}/v1"
    served = model_id.split("/")[-1].lower()
    cw = min(choice.context_window, 32_768)

    glob = load_global_config()
    if not glob.get("models"):
        glob.update({
            "upstream_endpoint": base_url,
            "upstream_model": served,
            "upstream_alias": served,
            "backend": "vllm",
            "models": [{
                "alias": served, "baseUrl": base_url, "id": served,
                "backend": "vllm", "contextWindow": cw, "maxTokens": 0,
                "apiKeyEnv": "", "headers": {"X-Title": "rtxclaw"},
            }],
            "upstream_max_context": cw,
        })
        glob.pop("upstream_endpoints", None)
    _seed_mcp_and_skills(glob)
    save_global_config(glob)
    lg.write_provision_marker(model_id, base_url, served)

    import subprocess
    log = os.path.expanduser("~/.rtxclaw/provision-worker.log")
    try:
        os.makedirs(os.path.dirname(log), exist_ok=True)
        with open(log, "ab") as fh:
            subprocess.Popen(
                [sys.executable, "-m", "rtxclaw_core.provision_worker"],
                stdout=fh, stderr=subprocess.STDOUT, start_new_session=True,
            )
    except (OSError, subprocess.SubprocessError):
        lg.mark_provision_error("could not start the provision worker")

    _say("")
    _say(f"  ✓ detected {profile.short_name()} — provisioning '{model_id}'")
    _say("    downloading + launching in the background; the TUI shows progress.")
    _say(f"    saved → {global_config_path()}")
    cfg = AgentConfig(name="main", description="rtxclaw main agent")
    cfg.save()
    ensure_main_agent()
    _offer_gateway_service(lambda *_a, **_k: "")
    return AgentConfig.load("main")


def _try_local_gpu_quickstart() -> AgentConfig | None:
    """Moat UX: if this box has an NVIDIA GPU, wire ``main`` straight at a
    local model — zero questions. Detect-first (a server already up) is
    instant; otherwise rtxclaw provisions one (install + download + launch
    vLLM). Returns None when there's no GPU / no way to serve (caller falls
    back to cloud / provider).

    Provisioning is ON by default — it's the moat. An interactive (TUI) launch
    backgrounds the long download so the TUI can show a progress bar; a
    non-interactive launch (piped/Docker) provisions synchronously. Set
    ``RTXCLAW_NO_PROVISION=1`` to keep only the instant detect-first path. Any
    failure degrades silently to the fork."""
    no_prov = os.environ.get("RTXCLAW_NO_PROVISION", "").strip() in ("1", "true", "yes")
    interactive = bool(getattr(sys, "stdin", None)) and sys.stdin.isatty()
    try:
        from rtxclaw_core import local_gpu as lg
        profile = lg.gpu_profile()
        if profile is None:
            return None
        setup = lg.attach_setup(profile)  # instant: a server is already up
        if setup is not None:
            return _write_local_gpu_config(setup)
        if no_prov:
            return None
        choice = lg.select_model_for_profile(profile)
        if choice is None:
            return None
        if interactive:
            return _start_background_provision(profile, choice)
        setup = lg.auto_local_setup(allow_provision=True)  # piped: synchronous
        return _write_local_gpu_config(setup) if setup is not None else None
    except Exception:  # detection must never break first-run
        return None


def _first_run_fork() -> AgentConfig | None:
    """First-run fork. The moat first: detect a local GPU and wire to a
    local model with no questions. Otherwise: chat now on the free cloud
    default, or set up a provider. Non-interactive (piped/Docker) → local if
    present, else the zero-config cloud default, so automated installs still
    come up running."""
    # _try_local_gpu_quickstart already writes config + agent and returns the
    # ready AgentConfig (or None); don't re-wrap it.
    cfg = _try_local_gpu_quickstart()
    if cfg is not None:
        return cfg

    interactive = bool(getattr(sys, "stdin", None)) and sys.stdin.isatty()
    if not interactive:
        return _write_quickstart_config()
    _say("")
    _say("  rtxclaw isn't configured yet — how do you want to start?")
    _say("    [1] Start chatting now — free NVIDIA Nemotron (no setup)")
    _say("    [2] Pick a provider / set up my own endpoint")
    try:
        sys.stderr.write("  choice [1]: ")
        sys.stderr.flush()
        choice = input("").strip() or "1"
    except (EOFError, KeyboardInterrupt):
        choice = "1"
    if choice == "2":
        return setup_main_wizard()
    return _write_quickstart_config()


def ensure_main_configured() -> AgentConfig | None:
    """Make sure the ``main`` agent is configured on disk.

    If not configured, run the first-run fork: zero-config free-Nemotron
    quickstart or the provider wizard. Never spawns the gateway here —
    callers (TUI self-bootstrap / ``_offer_gateway_service``) own that.
    """
    try:
        return AgentConfig.load("main")
    except FileNotFoundError:
        pass  # expected on first run — fall through so any first-run error
              # surfaces on its own, not chained off this FileNotFoundError
    return _first_run_fork()


def gateway_alive() -> bool:
    """True iff the rtxclaw gateway is reachable.

    Primary signal: ``$RTXCLAW_HOME/gateway.pid`` → live pid.
    Fallback: ``GET /health`` against the configured bind URL —
    covers a missing pidfile while the listener is otherwise
    healthy.
    """
    from .gateway import _gateway_config, _gateway_pidfile

    pidfile = _gateway_pidfile()
    if pidfile.is_file():
        try:
            pid = int(pidfile.read_text().strip())
            if _is_alive(pid):
                return True
        except (OSError, ValueError):
            pass
    gw = _gateway_config()
    try:
        r = httpx.get(f"http://{gw['host']}:{gw['port']}/health", timeout=1.0)
        return r.status_code == 200
    except httpx.HTTPError:
        return False


# ---- commands ----

def cmd_init(args: argparse.Namespace) -> int:
    name = args.name or "main"
    if name == "main":
        cfg = ensure_main_agent()
        print(f"agent {cfg.name} ready at {cfg.home}")
        return 0
    home = agents_root() / name
    if (home / "config.json").exists():
        print(f"agent {name} already configured at {home}")
        return 0
    cfg = AgentConfig(name=name, description=f"rtxclaw agent: {name}")
    cfg.save()
    print(f"agent {name} scaffolded at {cfg.home}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    """List configured agents + their gateway-mount status.

    Every agent is a stdio child of the rtxclaw gateway, mounted at
    ``/acp/<name>``. ``running`` means the gateway is alive AND
    answers ``initialize`` for that mount; ``stopped`` means the
    gateway is down (no agent is reachable until the gateway boots).
    """
    names = list_agents()
    if not names:
        print(
            "no agents configured. run `rtxclaw agent init` to scaffold "
            "the default `main` agent."
        )
        return 0

    from .gateway import _gateway_config, _gateway_pidfile

    gw = _gateway_config()
    gw_pidfile = _gateway_pidfile()
    gw_pid: int | None = None
    if gw_pidfile.is_file():
        try:
            candidate = int(gw_pidfile.read_text().strip())
            if _is_alive(candidate):
                gw_pid = candidate
        except (OSError, ValueError):
            gw_pid = None
    gw_alive = gateway_alive()
    gw_pid_label = str(gw_pid) if gw_pid is not None else "-"
    gateway_base = f"http://{gw['host']}:{gw['port']}"
    headers: dict[str, str] = {}
    if gw.get("auth_token"):
        headers["Authorization"] = f"Bearer {gw['auth_token']}"

    print(f"{'NAME':<14} {'STATE':<10} {'GW_PID':<8} {'MOUNT'}")
    for name in names:
        if not gw_alive:
            print(f"{name:<14} {'stopped':<10} {'-':<8} {gateway_base}/acp/{name}")
            continue
        state = "unhealthy"
        try:
            r = httpx.post(
                f"{gateway_base}/acp/{name}/acp",
                content=json.dumps({
                    "jsonrpc": "2.0", "id": 1, "method": "initialize",
                    "params": {"protocolVersion": 1, "clientCapabilities": {}},
                }).encode("utf-8"),
                headers={**headers, "Content-Type": "application/json"},
                timeout=2.0,
            )
            if r.status_code == 200:
                state = "running"
        except httpx.HTTPError:
            pass
        print(f"{name:<14} {state:<10} {gw_pid_label:<8} {gateway_base}/acp/{name}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    """Print agent status by hitting the gateway.

    Under the single-process gateway every agent is mounted at
    ``/acp/<name>`` on the gateway. We probe ``initialize`` against
    that URL to surface the agent's ``agentInfo`` and
    ``agentCapabilities``. Pid/uptime fields refer to the gateway
    itself, not a per-agent process — there isn't one.
    """
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2

    from .gateway import _gateway_config, _gateway_pidfile

    gw = _gateway_config()
    gw_pidfile = _gateway_pidfile()
    gw_pid: int | None = None
    if gw_pidfile.is_file():
        try:
            candidate = int(gw_pidfile.read_text().strip())
            if _is_alive(candidate):
                gw_pid = candidate
        except (OSError, ValueError):
            gw_pid = None
    # If pidfile is missing / stale, fall back to the HTTP /health
    # probe (covers a systemd-managed gateway whose pidfile got
    # raced — the listener is still healthy).
    if gw_pid is None and not gateway_alive():
        print(f"agent {name}: gateway not running")
        print(f"  home: {cfg.home}")
        return 1

    try:
        uptime_s = max(0.0, time.time() - gw_pidfile.stat().st_mtime)
    except OSError:
        uptime_s = 0.0
    gateway_base = f"http://{gw['host']}:{gw['port']}"
    agent_url = f"{gateway_base}/acp/{name}"
    out: dict = {
        "agent": name,
        "gateway_pid": gw_pid,
        "gateway_url": gateway_base,
        "uptime_s": round(uptime_s, 1),
        "url": agent_url,
        "acp_url": f"{agent_url}/acp",
        "home": str(cfg.home),
        "upstream_endpoint": getattr(cfg, "upstream_endpoint", ""),
        "upstream_model": getattr(cfg, "upstream_model", ""),
    }
    headers = {"Content-Type": "application/json"}
    if gw.get("auth_token"):
        headers["Authorization"] = f"Bearer {gw['auth_token']}"
    try:
        r = httpx.post(
            f"{agent_url}/acp",
            content=json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": 1,
                    "clientCapabilities": {},
                },
            }).encode("utf-8"),
            headers=headers,
            timeout=3.0,
        )
        if r.status_code == 200:
            body = r.json()
            result = body.get("result") if isinstance(body, dict) else None
            if isinstance(result, dict):
                out["agent_info"] = result.get("agentInfo")
                out["agent_capabilities"] = result.get("agentCapabilities")
                out["protocol_version"] = result.get("protocolVersion")
            out["acp_ok"] = True
        else:
            out["acp_ok"] = False
            out["acp_status_code"] = r.status_code
    except httpx.HTTPError as e:
        out["acp_ok"] = False
        out["acp_error"] = str(e)
    print(json.dumps(out, indent=2))
    return 0 if out.get("acp_ok") else 1


def _rollback_backup_dirs(home) -> list:
    """Return rollback-backup directories sorted oldest-first by name.
    Names are timestamps (`YYYYMMDDTHHMMSSZ`) so lexical sort = chrono."""
    root = home / ".rollback-backup"
    if not root.exists():
        return []
    return sorted(
        [p for p in root.iterdir() if p.is_dir()],
        key=lambda p: p.name,
    )


def _du(path) -> int:
    """Recursive byte size of `path`. Best-effort — silently skips
    files we can't stat. Used by `rollback-backup list` so an operator
    can decide whether a `clean` is worth running."""
    total = 0
    for sub in path.rglob("*"):
        try:
            if sub.is_file():
                total += sub.stat().st_size
        except OSError:
            continue
    return total


def cmd_rollback_backup_list(args: argparse.Namespace) -> int:
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2
    dirs = _rollback_backup_dirs(cfg.home)
    if not dirs:
        print(f"agent {name}: no rollback-backup snapshots in {cfg.home}/.rollback-backup")
        return 0
    print(f"agent {name}: {len(dirs)} snapshot(s)")
    for p in dirs:
        n_files = sum(1 for _ in p.iterdir() if _.is_file())
        print(f"  {p.name}  {n_files} files  {_du(p)}b  ({p})")
    return 0


def cmd_rollback_backup_clean(args: argparse.Namespace) -> int:
    """Keep the `--keep` most-recent snapshots, delete the rest."""
    import shutil
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2
    keep = max(0, int(args.keep))
    dirs = _rollback_backup_dirs(cfg.home)
    if len(dirs) <= keep:
        print(
            f"agent {name}: {len(dirs)} snapshot(s) — "
            f"≤ keep={keep}, nothing to delete"
        )
        return 0
    to_delete = dirs[: len(dirs) - keep]
    for p in to_delete:
        try:
            shutil.rmtree(p)
            print(f"  removed {p.name}")
        except OSError as e:
            sys.stderr.write(f"  failed to remove {p}: {e}\n")
    print(
        f"agent {name}: kept {keep} most-recent, removed "
        f"{len(to_delete)} older snapshot(s)"
    )
    return 0


def _toggle_heartbeat(args: argparse.Namespace, enabled: bool) -> int:
    """Mutate `heartbeat_enabled` in the per-agent config. Effect is
    deferred to the next agent restart — the scheduler is wired up at
    `serve()` boot, not on a config-watch loop, so there's no
    middle-of-the-tick toggle that could leave a partial heartbeat
    in flight.
    """
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2
    cfg.heartbeat_enabled = enabled
    interval = getattr(args, "interval_s", None)
    if interval is not None and interval > 0:
        cfg.heartbeat_interval_s = int(interval)
    cfg.save()
    state = "enabled" if enabled else "disabled"
    print(
        f"agent {name}: heartbeat {state}  "
        f"(interval={cfg.heartbeat_interval_s}s).  "
        f"Restart agent for change to take effect:\n"
        f"  rtxclaw agent restart {name}"
    )
    return 0


def cmd_heartbeat_enable(args: argparse.Namespace) -> int:
    return _toggle_heartbeat(args, enabled=True)


def cmd_heartbeat_disable(args: argparse.Namespace) -> int:
    return _toggle_heartbeat(args, enabled=False)


def cmd_heartbeat_status(args: argparse.Namespace) -> int:
    """Print scheduler config + persisted state. No HTTP call — works
    even when the gateway is stopped."""
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2
    from rtxclaw_agent.heartbeat import load_state, state_path, read_heartbeat_md, is_heartbeat_content_effectively_empty
    print(f"agent: {name}")
    print(f"heartbeat_enabled: {cfg.heartbeat_enabled}")
    print(f"heartbeat_interval_s: {cfg.heartbeat_interval_s}")
    state = load_state(cfg.home)
    sp = state_path(cfg.home)
    print(f"state file: {sp} ({'present' if sp.exists() else 'absent'})")
    if state:
        for k in ("session_id", "created_at", "last_run_at"):
            if state.get(k):
                print(f"  {k}: {state[k]}")
        progress = state.get("session_progress") or {}
        if progress:
            print(f"  session_progress entries: {len(progress)}")
    body = read_heartbeat_md(cfg.home)
    if body is None:
        print("HEARTBEAT.md: missing")
    else:
        empty = is_heartbeat_content_effectively_empty(body)
        marker = "EFFECTIVELY EMPTY (ticks SKIP)" if empty else "non-empty (ticks RUN)"
        print(f"HEARTBEAT.md: {len(body)} chars — {marker}")
    return 0


def cmd_heartbeat_fire(args: argparse.Namespace) -> int:
    """Deprecated — the in-process heartbeat scheduler is retired.

    Periodic / scheduled-job work belongs to an external scheduler
    that drives ACP ``session/prompt`` against the running agent.
    """
    name = args.name or "main"
    sys.stderr.write(
        f"agent {name}: `heartbeat fire` is deprecated — the in-process "
        f"heartbeat scheduler is retired. Drive periodic work through "
        f"ACP from an external scheduler. No tick fired.\n"
    )
    return 1


def cmd_health(args: argparse.Namespace) -> int:
    """Report turn-health stats from the agent's saved sessions.

    Aggregates the `failure_modes` field that `_record_failure_mode`
    populates on every turn — `loop_detected`, `empty_stop`,
    `thinking_only_stop`, `length_continue`, `tool_loop_cap`,
    `compaction_summarised`, `forced_plan_pivot`, etc. Without this,
    the only way to tell whether a runtime change is moving the needle
    is to grep session JSONs by hand.

    Defaults to the last 50 turns across the most-recently-modified
    sessions in the agent's `sessions/` directory. Outputs a small
    table (mode, count, % of turns) plus a per-mode list of recent
    session IDs so an operator can drill into one.
    """
    name = args.name or "main"
    try:
        cfg = AgentConfig.load(name)
    except FileNotFoundError:
        sys.stderr.write(f"agent {name!r} not configured.\n")
        return 2
    sessions_dir = cfg.sessions_dir
    if not sessions_dir.exists():
        print(f"(no sessions dir at {sessions_dir})")
        return 0
    # turn-level failure signals live in sessions.db ``turn_events``
    # (loop / error / nudge / distill / finish), projected from the
    # JSONL event logs. Refresh the index, then aggregate.
    from rtxclaw_core.session_index import SessionIndex, connect_sessions_db
    idx = SessionIndex(sessions_dir.parent)
    idx.refresh()
    limit = max(1, int(args.limit or 50))
    _FAIL_KINDS = ("loop", "error", "nudge", "distill", "tool_result_fail")
    counts: dict[str, int] = {}
    sample_sids: dict[str, list[str]] = {}
    turns_seen = 0
    con = connect_sessions_db(idx.db_path)
    try:
        row = con.execute(
            "SELECT COALESCE(SUM(CASE WHEN last_turn_idx>=0 "
            "THEN last_turn_idx+1 ELSE 0 END),0) n FROM sessions_meta"
        ).fetchone()
        turns_seen = int(row["n"]) if row else 0
        ph = ",".join("?" for _ in _FAIL_KINDS)
        cur = con.execute(
            f"SELECT kind, session_hash FROM turn_events "
            f"WHERE kind IN ({ph}) ORDER BY ts DESC LIMIT ?",
            (*_FAIL_KINDS, limit * 20),
        )
        for r in cur.fetchall():
            k = r["kind"]
            counts[k] = counts.get(k, 0) + 1
            lst = sample_sids.setdefault(k, [])
            sid = r["session_hash"]
            if sid not in lst and len(lst) < 5:
                lst.append(sid)
    finally:
        con.close()
    if turns_seen == 0:
        print("(no turns found)")
        return 0
    total_fail = sum(counts.values())
    print(f"agent {name}: turn health ({turns_seen} turn(s) indexed)")
    print(f"  failure/recovery events: {total_fail}")
    print()
    if not counts:
        print("  (clean — no recovery paths fired)")
        return 0
    width = max(len(k) for k in counts) + 2
    print(f"  {'mode':<{width}} count  % of turns  recent sessions")
    for mode, cnt in sorted(counts.items(), key=lambda kv: -kv[1]):
        pct = 100 * cnt / turns_seen
        sids = ",".join(s[:12] for s in sample_sids.get(mode, []))
        print(f"  {mode:<{width}} {cnt:>5}  {pct:>9.1f}%  {sids}")
    return 0


# ---- external coding agents: detect + quick-install + configure ----

def _ask_yn(prompt: str, default_yes: bool = True) -> bool:
    suffix = "[Y/n]" if default_yes else "[y/N]"
    try:
        sys.stderr.write(f"  {prompt} {suffix} ")
        sys.stderr.flush()
        ans = input("").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return default_yes
    if not ans:
        return default_yes
    return ans in ("y", "yes")


def setup_external_agents(*, auto: bool = False, do_setup: bool = True,
                          emit=None) -> bool:
    """Detect external coding-agent CLIs (Claude Code / Codex / Cursor /
    Antigravity), print status, and — unless ``do_setup`` is False — quick-install
    the missing ones and configure each as an rtxclaw delegate. ``auto`` runs
    non-interactively (install + configure all). ``emit`` is the output sink
    (defaults to stderr ``_say`` for the wizard; the CLI passes ``print``).
    Returns True if any agent was newly configured.

    Shared by ``rtxclaw agents`` and the first-run wizard."""
    import shutil
    import subprocess
    from rtxclaw_core.agents import default_scaffolds as ds
    from rtxclaw_core.agent import agents_root

    em = emit or _say
    rows = ds.detect_external_agents()
    em("External coding agents (drive them via `/<name> <task>` or as delegates):")
    for r in rows:
        inst = "✓ installed" if r["installed"] else "✗ not installed"
        conf = "✓ configured" if r["configured"] else "— not configured"
        em(f"  {r['display_name']:<18} {r['cli_command']:<14} {inst:<16} {conf}")

    if not do_setup:
        return False

    interactive = auto or (bool(getattr(sys, "stdin", None)) and sys.stdin.isatty())
    if not interactive:
        em("  (run `rtxclaw agents` in a terminal, or with --yes, to install/configure)")
        return False

    changed = False
    for r in rows:
        if r["configured"]:
            continue
        name, disp = r["short_name"], r["display_name"]
        if not r["installed"]:
            cmd = r["install_cmd"]
            if not cmd:
                em(f"  {disp}: install manually → {r['install_hint']}")
                continue
            if not (auto or _ask_yn(f"{disp} not installed. Install it now?  ({cmd})",
                                    default_yes=False)):
                continue
            em(f"  installing {disp} … ({cmd})")
            try:
                rc = subprocess.run(cmd, shell=True).returncode
            except (OSError, subprocess.SubprocessError) as exc:
                rc = 1
                em(f"  ✗ could not run installer: {exc}")
            if rc != 0 or shutil.which(r["cli_command"]) is None:
                em(f"  ✗ {disp} install failed — install manually: {r['install_hint']}")
                continue
            r["installed"] = True
            em(f"  ✓ {disp} installed")
        # Installed (now or already) but not configured → scaffold the agent.
        if r["installed"] and (auto or _ask_yn(f"Configure rtxclaw agent '{name}'?")):
            ds.write_scaffold(agents_root() / name, r["kind"])
            changed = True
            em(f"  ✓ configured '{name}' — use it with `/{name} <task>`")

    if changed:
        em("  Restart the gateway to mount the new agent(s):  rtxclaw gateway restart")
    return changed


def cmd_agents(args: argparse.Namespace) -> int:
    """`rtxclaw agents` — detect / quick-install / configure external coding
    agents. ``--list`` just prints status; ``--yes`` is non-interactive."""
    setup_external_agents(
        auto=bool(getattr(args, "yes", False)),
        do_setup=not bool(getattr(args, "list", False)),
        emit=print,
    )
    return 0


# ---- argparse wiring ----

def add_agents_subparser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "agents",
        help="Detect, quick-install, and configure external coding agents "
             "(Claude Code / Codex / Cursor / Antigravity)",
    )
    p.add_argument("--list", "-l", action="store_true",
                   help="Just print detection status; don't install/configure")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Non-interactive: install + configure everything known")
    p.set_defaults(_dispatch=cmd_agents)


def add_subparser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "agent",
        help=(
            "Agent config: init / list / status / health / heartbeat / "
            "rollback-backup. Process lifecycle lives on `rtxclaw "
            "gateway` — the gateway hosts every agent as a stdio child."
        ),
    )
    p.set_defaults(_dispatch=lambda args: p.print_help() or 0)
    inner = p.add_subparsers(dest="op")
    inner.required = True

    def _name(parser: argparse.ArgumentParser) -> None:
        parser.add_argument("name", nargs="?", default="main", help="agent name (default: main)")

    p_init = inner.add_parser("init", help="Scaffold a new agent dir")
    _name(p_init); p_init.set_defaults(_dispatch=cmd_init)

    p_list = inner.add_parser("list", help="List configured agents + gateway-mount status")
    p_list.set_defaults(_dispatch=cmd_list)

    p_stat = inner.add_parser("status", help="Probe gateway and the agent's ACP mount")
    _name(p_stat); p_stat.set_defaults(_dispatch=cmd_status)

    p_health = inner.add_parser(
        "health", help="Report failure-mode rates across recent turns",
    )
    _name(p_health)
    p_health.add_argument(
        "--limit", "-n", type=int, default=50,
        help="how many recent turns to scan (default: 50)",
    )
    p_health.set_defaults(_dispatch=cmd_health)

    # Rollback-backup management. `scaffold_context_files(overwrite=True)`
    # snapshots the agent home into `<home>/.rollback-backup/<ts>/`
    # before rewriting templates. This subtree accumulates over time;
    # `rtxclaw agent rollback-backup {list,clean}` keeps it bounded.
    p_rb = inner.add_parser(
        "rollback-backup",
        help="List or clean .rollback-backup snapshots in the agent home",
    )
    rb_inner = p_rb.add_subparsers(dest="rb_op")
    p_rb.set_defaults(_dispatch=lambda args: p_rb.print_help() or 0)
    p_rb_list = rb_inner.add_parser("list", help="List existing snapshots")
    _name(p_rb_list); p_rb_list.set_defaults(_dispatch=cmd_rollback_backup_list)
    p_rb_clean = rb_inner.add_parser("clean", help="Delete snapshots (keeps the most-recent --keep, default 3)")
    _name(p_rb_clean)
    p_rb_clean.add_argument("--keep", type=int, default=3, help="Number of most-recent snapshots to retain (default 3)")
    p_rb_clean.set_defaults(_dispatch=cmd_rollback_backup_clean)

    # Heartbeat lifecycle: enable/disable/status/fire. The scheduler
    # reads `cfg.heartbeat_enabled` at boot, so enable/disable mutate
    # the per-agent config and require an `agent restart` to take
    # effect. `status` is read-only; `fire` POSTs a single tick into
    # the running gateway via HTTP.
    p_hb = inner.add_parser(
        "heartbeat",
        help="Manage heartbeat scheduler (enable/disable/status/fire)",
    )
    hb_inner = p_hb.add_subparsers(dest="hb_op")
    p_hb.set_defaults(_dispatch=lambda args: p_hb.print_help() or 0)
    for hb_op, hb_fn in (
        ("enable", cmd_heartbeat_enable),
        ("disable", cmd_heartbeat_disable),
        ("status", cmd_heartbeat_status),
        ("fire", cmd_heartbeat_fire),
    ):
        sp = hb_inner.add_parser(hb_op, help=f"{hb_op} the heartbeat scheduler")
        _name(sp)
        sp.set_defaults(_dispatch=hb_fn)
    # `enable` accepts an optional `--interval-s` so the user can tune
    # cadence in one shot without hand-editing config.json.
    for sp in (hb_inner.choices.get("enable"), hb_inner.choices.get("disable")):
        if sp is not None:
            sp.add_argument(
                "--interval-s", type=int, default=None,
                help="Set heartbeat_interval_s (default 1800).",
            )


def dispatch(args: argparse.Namespace) -> int:
    fn = getattr(args, "_dispatch", None)
    if fn is None:
        return 1
    return fn(args)
