"""rtxclaw-agent configuration types — daemon-side, paths only.

The full behaviour-config object lives in
``rtxclaw_core.agent.AgentConfig``; this module is the on-disk-paths
view the daemon CLI reads (pidfile, logfile, root). No I/O happens
here.

Surface:

- ``AgentConfig`` — frozen dataclass.
- ``default_root`` — pure path helper.
- ``AgentConfig.for_name`` — classmethod factory.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


def default_root(name: str) -> Path:
    """Return the default on-disk root for an agent named ``name``.

    Default layout: ``~/.rtxclaw/agents/<name>``. Honors
    ``$RTXCLAW_HOME`` / ``$RTXCLAW_AGENTS_HOME`` via
    :func:`rtxclaw_core.agent.agents_root` so tests can redirect the
    whole tree (e.g. ``RTXCLAW_HOME=~/.rtxclaw-test``).
    """
    from rtxclaw_core.agent import agents_root
    return agents_root() / name


@dataclass(frozen=True)
class AgentConfig:
    """Frozen, on-disk-path-only view of one rtxclaw agent."""

    name: str
    port: int
    root: Path
    pidfile: Path
    logfile: Path

    @classmethod
    def for_name(cls, name: str, port: int) -> "AgentConfig":
        """Build an :class:`AgentConfig` for ``name`` at ``port``.

        Pure data — no directories are created, no files are read.
        Callers that need the directory on disk should ``mkdir(parents
        =True, exist_ok=True)`` themselves; this factory exists so
        tests and CLI code can compute paths without I/O side effects.
        """
        root = default_root(name)
        return cls(
            name=name,
            port=port,
            root=root,
            pidfile=root / "gateway.pid",
            logfile=root / "logs" / "gateway.log",
        )
