"""`rtxclaw doctor` — let the agent diagnose & fix its own logged errors.

The agent writes structured failure records to `~/.rtxclaw/errors/`
(see `errors.py`). This module reads those records, asks an LLM
(local model or Claude Code) to fix them, and — when a fix lands —
flips the file from `<ts>_<fp>_<slug>.md` to
`[fixed]_<ts>_<fp>_<slug>.md` with a resolution note appended.

## CLI shape (handled in `app.py`)

```
rtxclaw doctor                          # auto-fix on a new branch errfix/<slug>
rtxclaw doctor --plan                   # show plan, ask y/n, then fix on branch
rtxclaw doctor --claude                 # use Claude Code as the fix engine
rtxclaw doctor --no-branch              # skip branch creation (in-place fix)
rtxclaw doctor --all                    # process every open error (default: 1)
rtxclaw doctor <fingerprint-or-name>    # target one specific error
```

## Fix-engine fan-out

- **Local model** (default): one-shot via the agent's `_run_oneshot_via_agent`
  — the agent's tool dispatch handles read_file/edit_file/write_file/exec
  with the configured permission mode (plan/auto). The doctor command
  hard-overrides mode to `auto` for fix-execution, `plan` for plan-mode.
- **Claude Code** (`--claude`): one-shot via `_run_claude_oneshot`. The
  permission-mode mapping is the same one the rest of rtxclaw uses
  (plan/default/bypassPermissions).

## Branch policy

Without `--no-branch`, every fix lands on its own short-lived branch:
`errfix/<slug>` cut from the current branch. The doctor does NOT
auto-merge — the user reviews and merges by hand. Branch creation
happens AFTER plan approval (in `--plan` mode) so a rejected plan
leaves the working tree alone.
"""
from __future__ import annotations

import argparse
import asyncio
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from rtxclaw_core.errors import errors_dir, mark_fixed


@dataclass
class ErrorEntry:
    """One file under `~/.rtxclaw/errors/` parsed for the doctor's use.

    `slug` is the short filename tag (e.g. `upstream-context-length-overflow`)
    — used for the branch name and the user-visible label.
    """

    path: Path
    fingerprint: str
    slug: str
    component: str
    exception: str
    summary: str          # the leading `> …` line under the H1, if any
    body: str             # full Markdown body (frontmatter included)


_FILENAME_RE = re.compile(
    r"^(?:\[fixed\]_)?(?P<ts>[0-9TZ:\-]+)_(?P<fp>[0-9a-f]{8})_(?P<slug>[a-z0-9\-]+)\.md$"
)


def parse_error_md(path: Path) -> Optional[ErrorEntry]:
    """Parse one error file. Returns None if the filename doesn't match."""
    m = _FILENAME_RE.match(path.name)
    if not m:
        return None
    body = path.read_text(encoding="utf-8")
    component = exception = summary = ""
    for line in body.splitlines():
        if line.startswith("component: "):
            component = line.split(": ", 1)[1].strip()
        elif line.startswith("exception: "):
            exception = line.split(": ", 1)[1].strip()
        elif line.startswith("> ") and not summary:
            summary = line[2:].strip()
    return ErrorEntry(
        path=path,
        fingerprint=m.group("fp"),
        slug=m.group("slug"),
        component=component,
        exception=exception,
        summary=summary,
        body=body,
    )


def list_open_errors() -> list[ErrorEntry]:
    """Return every unfixed error file, newest first."""
    d = errors_dir()
    if not d.is_dir():
        return []
    out: list[ErrorEntry] = []
    for p in sorted(d.glob("*.md"), reverse=True):
        if p.name.startswith("[fixed]_"):
            continue
        e = parse_error_md(p)
        if e is not None:
            out.append(e)
    return out


def find_error(target: str) -> Optional[ErrorEntry]:
    """Look up one open error by fingerprint, exact filename, or substring match."""
    for e in list_open_errors():
        if target in (e.fingerprint, e.path.name) or target in e.slug:
            return e
    return None


# ----- prompts -----

# Stable header so prefix-cache reuse can pay off across multiple
# doctor invocations on related errors. The volatile per-error body
# is appended last (cache-friendly: see CLAUDE.md).
_FIX_PROMPT_HEADER = """\
You are rtxclaw's self-repair agent ("doctor"). One of rtxclaw's components has logged an error and you have been asked to fix it.

Operating principles:

- Read the error record carefully — fingerprint, exception, traceback, and context.
- Reproduce or trace the failure in the source tree (`src/rtxclaw/`).
- Find the root cause; do not paper over symptoms.
- Apply a minimal, surgical fix. No refactors, no scope creep.
- If the fix needs a regression test, add one in `tests/`.
- Run `pytest -q tests/test_unit.py` after editing to confirm green.
- Keep changes inside `src/rtxclaw/`, `tests/`, and `src/README.md`. Do not touch root `README.md` or `papers`.

Format your final answer as:

1. **Root cause** — one paragraph.
2. **Fix applied** — files + line ranges.
3. **Verification** — what you ran and the result.

If you cannot find a real bug (e.g. the error is environmental), say so plainly — do NOT invent a fix to clear the queue.
"""

_PLAN_PROMPT_HEADER = """\
You are rtxclaw's self-repair agent ("doctor") in PLAN MODE. One of rtxclaw's components has logged an error. Your job is to investigate and propose a fix plan — DO NOT EDIT ANY FILES YET.

Investigate by reading the relevant source files. Then write a numbered plan covering:

1. **Root cause** — where in the source the bug lives, and why it triggers.
2. **Proposed fix** — concretely, which lines change and how.
3. **Test strategy** — what regression test(s) to add or modify.
4. **Risk** — anything that could go wrong with this fix.

After your plan, the user will decide whether to apply it.
"""


def _error_block(entry: ErrorEntry) -> str:
    return (
        f"## Error to fix\n\n"
        f"- File: `{entry.path}`\n"
        f"- Fingerprint: `{entry.fingerprint}`\n"
        f"- Component: `{entry.component}`\n"
        f"- Exception: `{entry.exception}`\n"
        f"- Summary: {entry.summary or '(none)'}\n\n"
        f"### Full record\n\n"
        f"```markdown\n{entry.body}\n```\n"
    )


def build_fix_prompt(entry: ErrorEntry) -> str:
    return f"{_FIX_PROMPT_HEADER}\n\n{_error_block(entry)}"


def build_plan_prompt(entry: ErrorEntry) -> str:
    return f"{_PLAN_PROMPT_HEADER}\n\n{_error_block(entry)}"


# ----- branch management -----


def _git(*argv: str, check: bool = True) -> subprocess.CompletedProcess:
    """Run `git` from the repo root (cwd at invocation time)."""
    return subprocess.run(
        ["git", *argv], capture_output=True, text=True, check=check
    )


def _is_repo_clean() -> bool:
    r = _git("status", "--porcelain", check=False)
    return r.returncode == 0 and not r.stdout.strip()


def _current_branch() -> str:
    r = _git("rev-parse", "--abbrev-ref", "HEAD", check=False)
    return (r.stdout or "").strip()


def _branch_exists(name: str) -> bool:
    r = _git("rev-parse", "--verify", name, check=False)
    return r.returncode == 0


def _make_branch_name(slug: str) -> str:
    """`errfix/<slug>` — collision-resolved with a numeric suffix."""
    base = f"errfix/{slug or 'unknown'}"
    if not _branch_exists(base):
        return base
    n = 2
    while _branch_exists(f"{base}-{n}"):
        n += 1
    return f"{base}-{n}"


def create_branch(slug: str) -> str:
    """Create + check out a fresh `errfix/<slug>` branch.

    Refuses if the working tree is dirty so an in-flight edit doesn't
    get bundled into the doctor's commit.
    """
    if not _is_repo_clean():
        raise RuntimeError(
            "working tree is dirty; commit or stash before running `rtxclaw doctor`"
        )
    name = _make_branch_name(slug)
    _git("checkout", "-b", name)
    return name


# ----- engines -----


async def _run_local_engine(prompt: str, *, mode: str, agent: str) -> int:
    """Drive the local model via the agent's one-shot path."""
    # Route via importlib so the import-linter contract stays
    # satisfied (rtxclaw_agent must not import rtxclaw_tui at module
    # load).
    import importlib

    _app = importlib.import_module("rtxclaw_tui.app")

    ns = argparse.Namespace(
        agent=agent,
        endpoint=None,
        model=None,
        system=None,
        temperature=None,
        enable_thinking=None,
        prompt=prompt,
        mode=mode,
        claude=False,
    )
    return await _app._run_oneshot_via_agent(ns, prompt)


async def _run_claude_engine(prompt: str, *, mode: str) -> int:
    """Drive Claude Code via the existing bash-bridge runner."""
    # TODO(phase-1-S2): see _run_local_engine — same boundary, same
    # importlib workaround until doctor.py moves to rtxclaw_agent.
    import importlib

    _app = importlib.import_module("rtxclaw_tui.app")

    ns = argparse.Namespace(
        agent="main",
        prompt=prompt,
        mode=mode,
        claude=True,
    )
    return await _app._run_claude_oneshot(ns, prompt)


# ----- main -----


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Wire `rtxclaw doctor` into the top-level CLI."""
    p = sub.add_parser(
        "doctor",
        help="Diagnose & auto-fix entries in ~/.rtxclaw/errors/.",
        description=(
            "Walk unfixed error records and ask the agent (or Claude) to "
            "fix them. Default: auto-fix on a new errfix/<slug> branch. "
            "Use --plan to require human approval before any edits."
        ),
    )
    p.add_argument(
        "target", nargs="?",
        help="Fingerprint, filename, or slug substring (default: most recent open error).",
    )
    p.add_argument("--plan", action="store_true", help="Plan-only first; ask y/n before applying.")
    p.add_argument("--claude", action="store_true", help="Use Claude Code as the fix engine instead of the local model.")
    p.add_argument("--all", action="store_true", help="Process every open error in turn.")
    p.add_argument("--no-branch", action="store_true", help="Apply the fix on the current branch (no errfix/<slug> branch).")
    p.add_argument("--agent", default="main", help="Local agent to use (default: main).")


def dispatch(args: argparse.Namespace) -> int:
    """Entry point for `rtxclaw doctor`."""
    return asyncio.run(_run(args))


async def _run(args: argparse.Namespace) -> int:
    if args.target:
        entries = [e for e in [find_error(args.target)] if e is not None]
        if not entries:
            print(f"no open error matching {args.target!r} in {errors_dir()}")
            return 2
    else:
        entries = list_open_errors()

    if not entries:
        print(f"(no open errors in {errors_dir()})")
        return 0

    if not args.all and len(entries) > 1:
        entries = entries[:1]
        print(f"(found {len(list_open_errors())} open errors; processing the most recent — pass --all for the rest)")

    if args.claude and shutil.which("claude") is None:
        print("error: --claude requested but `claude` CLI is not on PATH", file=sys.stderr)
        return 2

    rc = 0
    for entry in entries:
        rc |= await _process_one(entry, args)
    return rc


async def _process_one(entry: ErrorEntry, args: argparse.Namespace) -> int:
    print(f"\n── doctor: {entry.slug} ({entry.fingerprint}) ──")
    print(f"   {entry.path}")
    if entry.summary:
        print(f"   {entry.summary}")

    # 1. PLAN PHASE (only if --plan)
    if args.plan:
        plan_prompt = build_plan_prompt(entry)
        print("\n== plan ==\n")
        if args.claude:
            rc = await _run_claude_engine(plan_prompt, mode="plan")
        else:
            rc = await _run_local_engine(plan_prompt, mode="plan", agent=args.agent)
        if rc != 0:
            print("(plan engine returned non-zero; aborting fix)")
            return rc
        if not _ask_yn("\napply this plan? [y/N] "):
            print("(declined; leaving error open)")
            return 0

    # 2. BRANCH (unless --no-branch)
    starting_branch = _current_branch()
    branch_name: Optional[str] = None
    if not args.no_branch:
        try:
            branch_name = create_branch(entry.slug)
            print(f"   created branch: {branch_name}")
        except RuntimeError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2

    # 3. FIX PHASE
    fix_prompt = build_fix_prompt(entry)
    print("\n== fix ==\n")
    try:
        if args.claude:
            rc = await _run_claude_engine(fix_prompt, mode="auto")
        else:
            rc = await _run_local_engine(fix_prompt, mode="auto", agent=args.agent)
    except Exception as e:  # noqa: BLE001
        print(f"engine error: {e}", file=sys.stderr)
        rc = 1

    if rc != 0:
        print("(fix engine returned non-zero; not marking error fixed)")
        if branch_name and starting_branch and starting_branch != branch_name:
            print(f"   leaving you on {branch_name} for inspection (was {starting_branch})")
        return rc

    # 4. MARK FIXED
    fixed_path = mark_fixed(
        entry.path,
        resolution=(
            f"Auto-fixed by `rtxclaw doctor`"
            f"{' (claude)' if args.claude else ''}"
            f"{' on branch ' + branch_name if branch_name else ''}."
        ),
    )
    print(f"\n   marked fixed: {fixed_path.name}")
    if branch_name:
        print(f"   review and merge: git diff {starting_branch}..{branch_name}")
    return 0


def _ask_yn(prompt: str) -> bool:
    try:
        ans = input(prompt).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return ans in ("y", "yes")
