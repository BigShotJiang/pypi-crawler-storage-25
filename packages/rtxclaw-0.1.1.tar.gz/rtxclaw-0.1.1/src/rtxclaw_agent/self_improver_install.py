"""`rtxclaw self-improver install` — wire the self-improver into a host.

Copies the canonical scripts from the source repo's
``assets/self-improver/`` into ``~/.rtxclaw/scripts/`` (chmod +x),
writes a default ``hooks.json`` per agent (only if the agent doesn't
already have one — never overwrite operator customisation), creates
the runtime directory tree, and optionally registers the cron entry
for the cold-path scanner.

Intentionally does **not** install the prompt or the test runner —
both live in the source repo at ``scripts/`` and are read by the
wrapper / Claude session at run time. Keeping them out of
``~/.rtxclaw/`` means a ``git pull`` updates them with no install
step.
"""
from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path
from typing import Iterable, Sequence


def _rtxhome() -> Path:
    return Path(os.environ.get("RTXCLAW_HOME") or (Path.home() / ".rtxclaw"))


def _src_dir() -> Path:
    return Path(os.environ.get("RTXCLAW_SOURCE_DIR") or (Path.home() / "src" / "rtxclaw"))


_SCRIPTS = ("self-improver.sh", "self-improver-scan.sh", "self-improver-gc.sh")
_RUNTIME_DIRS = (
    "self-improver/logs",
    "self-improver/runs",
    "self-improver/worktrees",
    "self-improver/test-runs",
    "self-improver/fixes",
)


def _ensure_dirs(rtxhome: Path) -> None:
    for sub in _RUNTIME_DIRS:
        (rtxhome / sub).mkdir(parents=True, exist_ok=True)
    (rtxhome / "scripts").mkdir(parents=True, exist_ok=True)


def _copy_scripts(rtxhome: Path, src: Path) -> list[Path]:
    src_assets = src / "assets" / "self-improver"
    out: list[Path] = []
    for name in _SCRIPTS:
        src_path = src_assets / name
        dst_path = rtxhome / "scripts" / name
        if not src_path.is_file():
            raise FileNotFoundError(f"asset missing: {src_path}")
        shutil.copy2(src_path, dst_path)
        dst_path.chmod(dst_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        out.append(dst_path)
    return out


_SELF_IMPROVER_COMMAND_MARKER = "self-improver.sh"


_HOOK_EVENT_NAMES = {
    # Subset sufficient to recognise the bare-event-map shape; the
    # full HOOK_EVENTS set lives in rtxclaw_core.hooks but we don't
    # want to import that at install time (keeps the installer free
    # of rtxclaw_core imports for the same reason the hot path is).
    "PreToolUse", "PostToolUse", "PostToolUseFailure", "PostToolBatch",
    "UserPromptSubmit", "UserPromptExpansion", "Notification",
    "Stop", "StopFailure", "SubagentStart", "SubagentStop",
    "PreCompact", "SessionStart", "SessionEnd", "Setup",
    "PermissionRequest", "PermissionDenied", "Elicitation",
    "ElicitationResult", "InstructionsLoaded",
    "ReasoningLoopDetected", "PrematureTurnEnd", "PrematureTurnEndGate",
    "DistillRecovery", "ForceTerminate", "PreambleInject",
    "UpstreamError", "SessionError",
}


def _hooks_container(existing: dict) -> dict:
    """Return the dict that holds event -> [groups] mappings,
    matching the on-disk shape:

    - Standard shape: ``{"hooks": {"PreToolUse": [...]}}`` →
      returns the inner ``existing["hooks"]`` dict.
    - Bare-event-map shape: ``{"PreToolUse": [...]}`` →
      returns ``existing`` itself.
    - Ambiguous / empty: defaults to standard shape; sets
      ``existing["hooks"] = {}`` and returns it.

    The shape is preserved on write — callers that mutate the
    returned dict in place don't change the operator's file format.
    """
    if not isinstance(existing, dict):
        # Pathological — caller should have caught this earlier.
        return {}
    if isinstance(existing.get("hooks"), dict):
        return existing["hooks"]
    # Bare-map detection: any top-level key matches a known event name.
    if any(k in _HOOK_EVENT_NAMES for k in existing):
        return existing
    # Empty / unrecognised — default to standard shape.
    existing.setdefault("hooks", {})
    return existing["hooks"]


def _has_self_improver_entry(data: dict) -> bool:
    """True if any hook entry in ``data`` invokes self-improver.sh.
    Recognises both ``{"hooks": {...}}`` and the bare-event-map shape."""
    if not isinstance(data, dict):
        return False
    container = data.get("hooks") if isinstance(data.get("hooks"), dict) else data
    for groups in container.values() if isinstance(container, dict) else []:
        if not isinstance(groups, list):
            continue
        for group in groups:
            if not isinstance(group, dict):
                continue
            for hook in group.get("hooks", []) or []:
                if isinstance(hook, dict) and _SELF_IMPROVER_COMMAND_MARKER in str(hook.get("command", "")):
                    return True
    return False


def _repair_mixed_shape(existing: dict) -> list[str]:
    """Normalise a mixed-shape hooks.json into pure standard shape.

    Mixed shape happens when an earlier broken installer (the
    pre-f3344c3 ``_install_hooks_json`` regression on a bare-event-map
    config) added a ``hooks`` key on top of operator bare-map entries.
    HookEngine prefers ``raw["hooks"]`` over the top-level keys, so
    the operator's bare-map entries are silently ignored.

    This function moves every top-level event entry INTO the
    ``hooks`` sub-dict. On collision (same event key in both
    locations), the ``hooks`` side wins (it's the more recent
    install — the operator can revert via git if needed) and the
    bare-map duplicate is dropped with a stderr warning.

    Returns the list of event names that were touched (moved OR
    dropped as collisions). Empty list means no migration was
    needed (file was already pure standard or pure bare-map). The
    truthiness of the return value is what callers should test to
    decide whether to write the repaired file back to disk.
    """
    if not isinstance(existing, dict):
        return []
    inner = existing.get("hooks")
    if not isinstance(inner, dict):
        return []  # not mixed shape
    moved: list[str] = []
    dropped_collisions: list[str] = []
    # Iterate a snapshot of keys — we mutate existing during the loop.
    for key in list(existing.keys()):
        if key == "hooks":
            continue
        if key not in _HOOK_EVENT_NAMES:
            continue  # leave non-event top-level keys alone ($schema, _comment, etc.)
        if key in inner:
            dropped_collisions.append(key)
            del existing[key]
        else:
            inner[key] = existing.pop(key)
            moved.append(key)
    if moved or dropped_collisions:
        msg_parts: list[str] = []
        if moved:
            msg_parts.append(f"migrated {', '.join(moved)} into 'hooks'")
        if dropped_collisions:
            msg_parts.append(
                f"dropped duplicate bare-map entries (hooks-side wins): "
                f"{', '.join(dropped_collisions)}"
            )
        sys.stderr.write(
            f"[self-improver install] repaired mixed-shape hooks.json: "
            f"{'; '.join(msg_parts)}\n"
        )
    # Caller uses truthiness to decide whether the file needs a write
    # back; include collisions so the "drop-only" case still writes.
    return moved + dropped_collisions


def _install_hooks_json(rtxhome: Path, src: Path, agent: str) -> Path:
    """Install / merge the self-improver hooks.json for ``agent``.

    Three cases:

    1. No file yet → copy the template verbatim.
    2. File exists, mentions self-improver.sh already → operator has
       customised the self-improver wiring. Leave it alone (after
       repairing any mixed-shape damage first — see
       :func:`_repair_mixed_shape`).
    3. File exists, does NOT mention self-improver.sh → MERGE the
       template's 4 events into the existing ``hooks`` dict,
       preserving every operator-added entry. The merge ADDS events
       that are missing; it never overwrites an existing event key
       (so an operator who manually wired their own
       ReasoningLoopDetected hook keeps it).
    """
    import json

    dst = rtxhome / "agents" / agent / "hooks.json"
    dst.parent.mkdir(parents=True, exist_ok=True)
    template_path = src / "assets" / "self-improver" / "hooks.json"

    if not dst.exists():
        shutil.copy2(template_path, dst)
        return dst

    try:
        existing = json.loads(dst.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        # File present but unparseable — don't clobber it. Surface
        # the situation to the operator via stderr.
        sys.stderr.write(
            f"[self-improver install] WARN: {dst} is not valid JSON; "
            "leaving it alone. Add the four self-improver events by hand or "
            "delete the file and re-run.\n"
        )
        return dst

    # Repair the mixed-shape damage left by the pre-f3344c3 installer
    # bug BEFORE checking whether self-improver is "already installed"
    # — without repair, the early-return would lock in the broken
    # state because self-improver entries DO exist (inside 'hooks'),
    # but the operator's top-level entries are silently disabled by
    # HookEngine's loader.
    migrated = _repair_mixed_shape(existing)

    if _has_self_improver_entry(existing) and not migrated:
        # Already installed AND no migration was needed — leave alone.
        return dst

    if _has_self_improver_entry(existing) and migrated:
        # Migration brought self-improver entries into the right
        # shape; nothing more to merge, but we must write the
        # repaired file back to disk.
        dst.write_text(
            json.dumps(existing, indent=2) + "\n",
            encoding="utf-8",
        )
        return dst

    # Merge: pull events from template that aren't already in the
    # existing file. Never overwrite an existing event entry.
    # Preserve the operator's on-disk shape — standard
    # ({"hooks": {...}}) stays standard; bare-event-map stays bare.
    template = json.loads(template_path.read_text(encoding="utf-8"))
    container = _hooks_container(existing)
    template_hooks = template.get("hooks", {})
    added: list[str] = []
    for event, groups in template_hooks.items():
        if event in container:
            continue
        container[event] = groups
        added.append(event)
    if added or migrated:
        dst.write_text(
            json.dumps(existing, indent=2) + "\n",
            encoding="utf-8",
        )
        if added:
            sys.stderr.write(
                f"[self-improver install] merged into {dst}: "
                f"{', '.join(added)}\n"
            )
    return dst


def _cron_line(rtxhome: Path) -> str:
    scan = rtxhome / "scripts" / "self-improver-scan.sh"
    log = rtxhome / "self-improver" / "logs" / "scan.log"
    return f"*/15 * * * * {scan} >> {log} 2>&1\n"


def _install_cron(rtxhome: Path) -> bool:
    """Append the cold-scan cron line idempotently. Returns True on
    success (line already present OR newly added), False on failure."""
    line = _cron_line(rtxhome).strip()
    existing_proc = subprocess.run(
        ["crontab", "-l"], capture_output=True, text=True
    )
    # "no crontab for user" is rc=1 with empty stdout — that's not a
    # failure mode; treat as empty existing crontab.
    existing = existing_proc.stdout if existing_proc.returncode == 0 else ""
    if line in existing.splitlines():
        return True
    new = existing + ("\n" if existing and not existing.endswith("\n") else "") + line + "\n"
    p = subprocess.run(["crontab", "-"], input=new, text=True, capture_output=True)
    if p.returncode != 0:
        sys.stderr.write(f"crontab install failed: {p.stderr}\n")
        return False
    return True


def install(
    *,
    agents: Sequence[str] = ("main",),
    print_cron: bool = False,
) -> int:
    """Wire the self-improver onto this host.

    Args:
        agents: per-agent hooks.json target list.
        print_cron: print the cron line instead of installing it. Test
            path; lets unit tests run without touching the user's
            crontab.

    Returns the process exit code.
    """
    rtxhome = _rtxhome()
    src = _src_dir()
    _ensure_dirs(rtxhome)
    _copy_scripts(rtxhome, src)
    for agent in agents:
        _install_hooks_json(rtxhome, src, agent)

    if print_cron:
        print(_cron_line(rtxhome), end="")
        return 0
    if not _install_cron(rtxhome):
        return 1
    return 0


def main(argv: Iterable[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="rtxclaw self-improver install")
    ap.add_argument("--agent", action="append", default=None,
                    help="agent name (repeatable; default: main)")
    ap.add_argument("--print-cron", action="store_true",
                    help="print the cron line instead of installing")
    ns = ap.parse_args(argv)
    return install(
        agents=tuple(ns.agent) if ns.agent else ("main",),
        print_cron=ns.print_cron,
    )
