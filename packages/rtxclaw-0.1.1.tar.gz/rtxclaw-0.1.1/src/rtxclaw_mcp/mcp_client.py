"""Model Context Protocol client.

rtxclaw connects out to MCP servers (stdio + HTTP/SSE transports) so the
model can call tools provided by, e.g., the Brave-search MCP server, a
filesystem server, or a custom company tool. Servers are configured once
in `~/.rtxclaw/config.json` under `mcp_servers`; the model picks one by
its short name when it issues a tool call.

Connection model — one-shot per call
----------------------------------

The MCP SDK's `ClientSession` is an async context manager that owns the
lifetime of a transport (a stdio subprocess or an HTTP/SSE stream). The
straightforward way to support every tool runner cleanly is to spin up a
fresh session per call:

    async with mcp_session(server_name) as sess:
        result = await sess.call_tool(tool_name, arguments=...)

Per-call sessions trade a small startup cost (cheap for stdio, ~50 ms;
HTTP is just a TCP open) for two big simplifications:

1. **Process model fits.** Each rtxclaw tool call already runs in its
   own subprocess (`tool_runner.py`). A persistent MCP connection would
   need a long-lived broker the runner can't easily reach.
2. **Reconnect is implicit.** A failed call returns an error; the next
   call opens a fresh connection. No background reconnect loop, no
   stale-socket detection.

If a server proves to need persistent state across calls (e.g. a
session-ful query language) we'll graduate it to a long-lived broker
inside the agent process; today, no configured server needs that.

Configuration shape
-------------------

stdio:
    {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-brave-search"],
      "env": {"BRAVE_API_KEY": "..."},
      "transport": "stdio"
    }

http (Streamable HTTP):
    {
      "url": "http://localhost:3100",
      "transport": "http",
      "headers": {"Authorization": "Bearer ..."}
    }

sse (legacy SSE):
    {
      "url": "http://localhost:3101/sse",
      "transport": "sse",
      "headers": {"Authorization": "Bearer ..."}
    }

Public API
----------
- ``MCPServerConfig.from_dict(name, raw)`` — parse one config row.
- ``load_mcp_servers(global_cfg)`` — read all configured servers.
- ``mcp_session(name)`` async context manager.
- ``call_tool(name, tool_name, arguments)`` — one-shot helper.
- ``list_tools(name)`` — one-shot helper.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional


_log = logging.getLogger("rtxclaw.mcp")


# ---- config -----------------------------------------------------------


@dataclass(frozen=True)
class MCPServerConfig:
    """One configured MCP server, with the transport-specific fields it
    needs to spawn or connect to.

    Validation lives here (not at config-load time) so a malformed row
    doesn't take down the agent at boot — the error only surfaces when
    the model actually tries to use that server.
    """

    name: str
    transport: str  # "stdio" | "http" | "sse"
    # stdio
    command: str = ""
    args: tuple[str, ...] = ()
    env: dict[str, str] = field(default_factory=dict)
    cwd: Optional[str] = None
    # http / sse
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    # Optional human-readable description, surfaced to the model.
    description: str = ""

    @classmethod
    def from_dict(cls, name: str, raw: dict[str, Any]) -> "MCPServerConfig":
        if not isinstance(raw, dict):
            raise ValueError(f"mcp_servers[{name!r}]: not a dict")
        # Default to stdio when `command` is set, http when `url` is set,
        # so existing configs without a `transport` field keep working.
        transport = str(raw.get("transport") or "").strip().lower()
        if not transport:
            if raw.get("command"):
                transport = "stdio"
            elif raw.get("url"):
                transport = "http"
            else:
                raise ValueError(
                    f"mcp_servers[{name!r}]: missing transport (and "
                    "neither command nor url is set)"
                )
        if transport == "stdio":
            cmd = str(raw.get("command") or "").strip()
            if not cmd:
                raise ValueError(
                    f"mcp_servers[{name!r}]: stdio transport requires `command`"
                )
            args = tuple(str(a) for a in (raw.get("args") or []))
            env_raw = raw.get("env") or {}
            env = (
                {str(k): str(v) for k, v in env_raw.items()}
                if isinstance(env_raw, dict) else {}
            )
            return cls(
                name=name,
                transport="stdio",
                command=cmd,
                args=args,
                env=env,
                cwd=str(raw.get("cwd")) if raw.get("cwd") else None,
                description=str(raw.get("description") or ""),
            )
        if transport in ("http", "sse"):
            url = str(raw.get("url") or "").strip()
            if not url:
                raise ValueError(
                    f"mcp_servers[{name!r}]: {transport} transport requires `url`"
                )
            headers_raw = raw.get("headers") or {}
            headers = (
                {str(k): str(v) for k, v in headers_raw.items()}
                if isinstance(headers_raw, dict) else {}
            )
            return cls(
                name=name,
                transport=transport,
                url=url,
                headers=headers,
                description=str(raw.get("description") or ""),
            )
        raise ValueError(
            f"mcp_servers[{name!r}]: unknown transport {transport!r} "
            "(expected stdio | http | sse)"
        )


def load_mcp_servers(global_cfg: Optional[dict[str, Any]] = None) -> dict[str, MCPServerConfig]:
    """Parse the MCP server map out of the global config dict.

    Accepts both the standard ``mcpServers`` (camelCase, what Claude
    Desktop / Claude Code / the MCP Python SDK use) and the legacy
    ``mcp_servers`` (snake_case, what early rtxclaw configs used).
    The standard key wins when both are present.

    Bad rows are dropped with a logged warning rather than raising —
    one mistyped server config shouldn't keep the model from using the
    other configured ones. Pass `global_cfg=None` to load from disk.
    """
    if global_cfg is None:
        try:
            from rtxclaw_core.agent import load_global_config
            global_cfg = load_global_config()
        except Exception:  # noqa: BLE001
            global_cfg = {}
    cfg = global_cfg or {}
    # Standard key (mcpServers) wins; legacy key (mcp_servers) is the
    # fallback. Both empty → no servers from the user config.
    raw = cfg.get("mcpServers") or cfg.get("mcp_servers") or {}
    if not isinstance(raw, dict):
        raw = {}
    # Claude Code's canonical user-level MCP file at
    # ``~/.claude/.mcp.json`` (and the unprefixed ``mcp.json``) — read
    # it as another source so an operator who configured an MCP via
    # Claude Code sees the same server in rtxclaw. User's
    # rtxclaw config still wins on collisions.
    cc_raw: dict[str, Any] = {}
    try:
        import json as _json
        from pathlib import Path as _Path
        for _cand in (
            _Path.home() / ".claude" / ".mcp.json",
            _Path.home() / ".claude" / "mcp.json",
        ):
            if _cand.is_file():
                _doc = _json.loads(_cand.read_text(encoding="utf-8"))
                if isinstance(_doc, dict):
                    cc_raw = _doc.get("mcpServers") or _doc.get("mcp_servers") or {}
                    if not isinstance(cc_raw, dict):
                        cc_raw = {}
                break
    except (OSError, ValueError) as e:
        _log.debug("~/.claude mcp.json read skipped: %s", e)
    # Merge installed plugins' .mcp.json blocks + Claude Code mcp.json
    # on top — user config wins on name collisions; plugins / Claude
    # Code fill in anything not set.
    try:
        from rtxclaw_core.plugins import plugin_mcp_servers as _plug_mcp
        plug_raw = _plug_mcp() or {}
    except Exception as e:  # noqa: BLE001
        _log.debug("plugin mcpServers merge skipped: %s", e)
        plug_raw = {}
    if (isinstance(plug_raw, dict) and plug_raw) or cc_raw:
        merged: dict[str, Any] = {}
        if isinstance(plug_raw, dict):
            merged.update(plug_raw)
        if cc_raw:
            merged.update(cc_raw)
        merged.update(raw)
        raw = merged
    out: dict[str, MCPServerConfig] = {}
    for name, row in raw.items():
        try:
            out[name] = MCPServerConfig.from_dict(name, row)
        except (ValueError, TypeError) as e:
            _log.warning("MCP server %r ignored: %s", name, e)
    return out


def list_mcp_servers_with_source(
    global_cfg: Optional[dict[str, Any]] = None,
) -> list[tuple[MCPServerConfig, str]]:
    """Like :func:`load_mcp_servers` but also tags each server with the
    discovery source — ``"config"`` (~/.rtxclaw/config.json), ``"plugin"``
    (a bundle's .mcp.json), or ``"claude"`` (~/.claude/.mcp.json).

    Used by the ``/mcp`` slash command to render where each server came
    from, mirroring Claude Code's ``/mcp`` introspection. Source
    precedence matches :func:`load_mcp_servers`: a server present in
    multiple stores reports the highest-priority one (config > claude
    > plugin) — the same merge order the loader uses.
    """
    if global_cfg is None:
        try:
            from rtxclaw_core.agent import load_global_config
            global_cfg = load_global_config()
        except Exception:  # noqa: BLE001
            global_cfg = {}
    cfg = global_cfg or {}
    config_names = set(
        (cfg.get("mcpServers") or cfg.get("mcp_servers") or {}).keys()
    )
    claude_names: set[str] = set()
    try:
        import json as _json
        from pathlib import Path as _Path
        for _cand in (
            _Path.home() / ".claude" / ".mcp.json",
            _Path.home() / ".claude" / "mcp.json",
        ):
            if _cand.is_file():
                _doc = _json.loads(_cand.read_text(encoding="utf-8"))
                if isinstance(_doc, dict):
                    cc_raw = _doc.get("mcpServers") or _doc.get("mcp_servers") or {}
                    if isinstance(cc_raw, dict):
                        claude_names = set(cc_raw.keys())
                break
    except (OSError, ValueError):
        pass
    merged = load_mcp_servers(cfg)
    out: list[tuple[MCPServerConfig, str]] = []
    for name, server in sorted(merged.items()):
        if name in config_names:
            src = "config"
        elif name in claude_names:
            src = "claude"
        else:
            src = "plugin"
        out.append((server, src))
    return out


# ---- standard-pattern tool injection ------------------------------------
#
# Per the MCP spec lifecycle (https://modelcontextprotocol.io/specification/
# 2025-11-25/basic/lifecycle): client spawns server → initialize →
# notifications/initialized → tools/list. The discovered tools are
# injected DIRECTLY into the model's tool registry as
# ``mcp__<server>__<tool>`` (Claude Code's namespacing convention) so
# the model picks them via standard tool-use, not via meta-tools.
#
# We cache the discovery at the process level — re-running tools/list
# every turn would block the event loop on subprocess spawn. Cache
# is invalidated when:
#   - the agent restarts (process boot)
#   - load_global_config() returns a config whose hash differs
#   - call_mcp_namespaced raises an error (server died, retry on next list)


_MCP_NAMESPACE_SEP = "__"  # Claude Code: mcp__<server>__<tool>


def mcp_tool_namespaced(server: str, tool: str) -> str:
    """``mcp__<server>__<tool>`` — the convention Claude Code uses."""
    return f"mcp{_MCP_NAMESPACE_SEP}{server}{_MCP_NAMESPACE_SEP}{tool}"


def parse_mcp_namespaced(name: str) -> Optional[tuple[str, str]]:
    """Inverse of ``mcp_tool_namespaced``. Returns ``(server, tool)`` or
    ``None`` for a non-MCP name."""
    prefix = f"mcp{_MCP_NAMESPACE_SEP}"
    if not name.startswith(prefix):
        return None
    rest = name[len(prefix):]
    sep = _MCP_NAMESPACE_SEP
    if sep not in rest:
        return None
    server, tool = rest.split(sep, 1)
    return server, tool


# Process-wide cache. Each entry: (server_cfg, raw_tool_name, description, input_schema).
_DISCOVERED_TOOLS: list[tuple[MCPServerConfig, str, str, dict[str, Any]]] = []
_DISCOVERED_TOOLS_LOADED: bool = False
_DISCOVERED_TOOLS_LOCK: Optional[asyncio.Lock] = None


async def discover_all_tools(
    *, force_refresh: bool = False,
) -> list[tuple[MCPServerConfig, str, str, dict[str, Any]]]:
    """Spawn every configured MCP server, run tools/list against each,
    and return ``(server, tool_name, description, input_schema)`` tuples
    for every discovered tool.

    Subsequent calls reuse the cached result unless ``force_refresh``
    is set or the cache is empty. A failed server is logged and skipped
    (other servers' tools still surface).

    Discovery progress is mirrored to stdout (the daemon's gateway.log
    sink) via ``print(...)`` because the agent's logging is configured
    by ``rtxclaw_telegram.bot``'s FileHandler — the rest of the runtime
    surfaces info via ``print()`` to stdout, and we follow that pattern
    so MCP discovery lands alongside ``acp listening on ...`` etc.
    """
    global _DISCOVERED_TOOLS, _DISCOVERED_TOOLS_LOADED, _DISCOVERED_TOOLS_LOCK
    if _DISCOVERED_TOOLS_LOCK is None:
        _DISCOVERED_TOOLS_LOCK = asyncio.Lock()
    async with _DISCOVERED_TOOLS_LOCK:
        if _DISCOVERED_TOOLS_LOADED and not force_refresh:
            return list(_DISCOVERED_TOOLS)
        # Sentinel — written progressively so a discovery that hangs
        # or crashes still leaves a forensic trail.
        sentinel: Optional[Any] = None
        sentinel_lines: list[str] = [f"started at: {time.time()}"]
        try:
            from rtxclaw_core.agent import rtxclaw_root
            sentinel = rtxclaw_root() / "mcp_discovery.last"
            sentinel.parent.mkdir(parents=True, exist_ok=True)
            sentinel.write_text("\n".join(sentinel_lines) + "\n")
        except Exception:  # noqa: BLE001
            sentinel = None
        servers = load_mcp_servers()
        sentinel_lines.append(f"servers: {sorted(servers)}")
        if sentinel is not None:
            try:
                sentinel.write_text("\n".join(sentinel_lines) + "\n")
            except Exception:  # noqa: BLE001
                pass
        if not servers:
            print("[mcp] no mcpServers configured — skipping discovery", file=sys.stderr, flush=True)
            _DISCOVERED_TOOLS = []
            _DISCOVERED_TOOLS_LOADED = True
            return []
        print(f"[mcp] discovering tools across {len(servers)} server(s): "
              f"{sorted(servers.keys())}", file=sys.stderr, flush=True)
        out: list[tuple[MCPServerConfig, str, str, dict[str, Any]]] = []
        for name, srv in servers.items():
            try:
                ok, tools, err = await list_tools(srv)
            except Exception as e:  # noqa: BLE001
                msg = f"{name}: spawn/init failed: {type(e).__name__}: {e}"
                sentinel_lines.append(msg)
                print(f"[mcp] discover {msg}", file=sys.stderr, flush=True)
                _log.warning("mcp discover %r: spawn/init failed: %s", name, e)
                if sentinel is not None:
                    try: sentinel.write_text("\n".join(sentinel_lines) + "\n")
                    except Exception: pass  # noqa: BLE001
                continue
            if not ok:
                msg = f"{name}: tools/list failed: {err}"
                sentinel_lines.append(msg)
                print(f"[mcp] discover {msg}", file=sys.stderr, flush=True)
                _log.warning("mcp discover %r: tools/list failed: %s", name, err)
                if sentinel is not None:
                    try: sentinel.write_text("\n".join(sentinel_lines) + "\n")
                    except Exception: pass  # noqa: BLE001
                continue
            for t in tools or []:
                tname = str(t.get("name") or "").strip()
                if not tname:
                    continue
                schema = t.get("inputSchema") or {"type": "object", "properties": {}}
                desc = str(t.get("description") or "").strip()
                out.append((srv, tname, desc, schema))
            tnames = ", ".join(str(t.get("name") or "?") for t in (tools or []))
            sentinel_lines.append(f"{name}: ok ({len(tools or [])} tool(s): {tnames})")
            print(f"[mcp] discover {name!r}: {len(tools or [])} tool(s): {tnames}",
                  file=sys.stderr, flush=True)
            _log.info("mcp discover %r: %d tool(s)", name, len(tools or []))
            if sentinel is not None:
                try: sentinel.write_text("\n".join(sentinel_lines) + "\n")
                except Exception: pass  # noqa: BLE001
        _DISCOVERED_TOOLS = out
        _DISCOVERED_TOOLS_LOADED = True
        sentinel_lines.append(f"DONE: {len(out)} total tool(s)")
        if sentinel is not None:
            try: sentinel.write_text("\n".join(sentinel_lines) + "\n")
            except Exception: pass  # noqa: BLE001
        return list(out)


def invalidate_discovery_cache() -> None:
    """Force the next ``discover_all_tools`` call to re-spawn servers."""
    global _DISCOVERED_TOOLS, _DISCOVERED_TOOLS_LOADED
    _DISCOVERED_TOOLS = []
    _DISCOVERED_TOOLS_LOADED = False


# ---- session helpers --------------------------------------------------


@contextlib.asynccontextmanager
async def mcp_session(
    server: MCPServerConfig,
    *,
    timeout_s: float = 30.0,
) -> AsyncIterator[Any]:
    """Open an `mcp.ClientSession` against `server` and yield it
    initialized + ready to use.

    Imports inside the function body so callers without the optional
    `mcp` package don't pay the import cost at module load.
    Raises `RuntimeError` if the SDK isn't installed.
    """
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
    except ImportError as e:
        raise RuntimeError(
            "mcp package not installed. Install with: pip install mcp"
        ) from e

    if server.transport == "stdio":
        params = StdioServerParameters(
            command=server.command,
            args=list(server.args),
            # The SDK merges this with the parent env; pass exactly the
            # operator-specified overrides.
            env={**os.environ, **server.env},
            cwd=server.cwd,
        )
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as sess:
                await asyncio.wait_for(sess.initialize(), timeout=timeout_s)
                yield sess
        return

    if server.transport == "http":
        from mcp.client.streamable_http import streamablehttp_client
        async with streamablehttp_client(
            server.url, headers=server.headers or None,
        ) as (read, write, _close):
            async with ClientSession(read, write) as sess:
                await asyncio.wait_for(sess.initialize(), timeout=timeout_s)
                yield sess
        return

    if server.transport == "sse":
        from mcp.client.sse import sse_client
        async with sse_client(server.url, headers=server.headers or None) as (read, write):
            async with ClientSession(read, write) as sess:
                await asyncio.wait_for(sess.initialize(), timeout=timeout_s)
                yield sess
        return

    raise RuntimeError(f"unsupported MCP transport: {server.transport!r}")


# ---- one-shot helpers (the runner's hot path) -------------------------


def _flatten_content(items: Any) -> str:
    """Render an MCP `CallToolResult.content` list (a list of
    `TextContent`/`ImageContent`/...) into a plain string.

    The rtxclaw tool layer hands a string back to the model — images
    and other binary blobs are cited by their content-type and length,
    not embedded.
    """
    if items is None:
        return ""
    if isinstance(items, str):
        return items
    if not isinstance(items, list):
        try:
            return json.dumps(items, default=str, ensure_ascii=False)
        except Exception:  # noqa: BLE001
            return str(items)
    parts: list[str] = []
    for it in items:
        if it is None:
            continue
        # MCP SDK emits pydantic models; fall back to dict access.
        if hasattr(it, "type"):
            t = getattr(it, "type", None)
        elif isinstance(it, dict):
            t = it.get("type")
        else:
            t = None
        if t == "text":
            parts.append(getattr(it, "text", None) or (it.get("text") if isinstance(it, dict) else "") or "")
        elif t == "image":
            mime = getattr(it, "mimeType", None) or (it.get("mimeType") if isinstance(it, dict) else "") or "image/*"
            data = getattr(it, "data", None) or (it.get("data") if isinstance(it, dict) else "") or ""
            parts.append(f"[image: {mime}, {len(data)} bytes (base64)]")
        elif t == "resource":
            uri = (
                getattr(it, "uri", None)
                or (it.get("uri") if isinstance(it, dict) else "")
                or "?"
            )
            parts.append(f"[resource: {uri}]")
        else:
            try:
                parts.append(json.dumps(it, default=str, ensure_ascii=False))
            except Exception:  # noqa: BLE001
                parts.append(str(it))
    return "\n".join(p for p in parts if p)


async def call_tool(
    server: MCPServerConfig,
    tool_name: str,
    arguments: Optional[dict[str, Any]] = None,
    *,
    timeout_s: float = 60.0,
) -> tuple[bool, str]:
    """One-shot: open a session, call the tool, close. Returns
    `(ok, body_string)`. `ok=False` carries either an MCP-reported
    `isError` flag or a transport / SDK exception message.
    """
    try:
        async with mcp_session(server) as sess:
            result = await asyncio.wait_for(
                sess.call_tool(tool_name, arguments=arguments or {}),
                timeout=timeout_s,
            )
    except asyncio.TimeoutError:
        return False, f"mcp_call timeout after {timeout_s}s"
    except RuntimeError as e:
        return False, f"mcp_call failed: {e}"
    except Exception as e:  # noqa: BLE001
        return False, f"mcp_call {type(e).__name__}: {e}"
    is_error = bool(getattr(result, "isError", False))
    body = _flatten_content(getattr(result, "content", None))
    return (not is_error, body)


async def list_tools(
    server: MCPServerConfig,
    *,
    timeout_s: float = 15.0,
) -> tuple[bool, list[dict[str, Any]], str]:
    """One-shot: open a session, list tools, close. Returns
    `(ok, tool_dicts, error_string)`. Each tool dict has `name`,
    `description`, `inputSchema`. On failure: ``(False, [], reason)``.

    The error string lets the caller surface what went wrong to the
    model — the previous shape ``(False, [])`` only logged the reason
    locally, so the model just saw "failed against {server!r}" with no
    way to fix it (was it auth? DNS? a missing dependency? a
    SDK-version mismatch?). Now the reason rides back with the result.
    """
    try:
        async with mcp_session(server) as sess:
            result = await asyncio.wait_for(sess.list_tools(), timeout=timeout_s)
    except asyncio.TimeoutError:
        msg = f"timeout after {timeout_s}s"
        _log.warning("mcp list_tools timeout against %s", server.name)
        return False, [], msg
    except RuntimeError as e:
        # Raised from `mcp_session` for unsupported transport / missing
        # SDK. Surface verbatim — these are fixable misconfigurations.
        return False, [], str(e)
    except Exception as e:  # noqa: BLE001 — SDK / transport / protocol errors
        msg = f"{type(e).__name__}: {e}"
        _log.warning("mcp list_tools failed against %s: %s", server.name, msg)
        return False, [], msg
    out: list[dict[str, Any]] = []
    for t in getattr(result, "tools", []) or []:
        out.append({
            "name": getattr(t, "name", ""),
            "description": getattr(t, "description", "") or "",
            "inputSchema": getattr(t, "inputSchema", None) or {},
        })
    return True, out, ""


__all__ = [
    "MCPServerConfig",
    "call_tool",
    "list_tools",
    "load_mcp_servers",
    "list_mcp_servers_with_source",
    "mcp_session",
]
