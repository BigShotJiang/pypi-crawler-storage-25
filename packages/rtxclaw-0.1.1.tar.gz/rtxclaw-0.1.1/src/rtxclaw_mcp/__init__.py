"""rtxclaw-mcp — MCP (Model Context Protocol) client + bundled servers.

Holds the in-process MCP client used by the agent's tool runners
(``mcp_client``) and any first-party MCP servers shipped with rtxclaw
(currently ``youtube_mcp_server``). Lives outside ``rtxclaw_core`` and
``rtxclaw_agent`` so MCP plumbing can evolve without churning either.
"""
from __future__ import annotations

__all__: list[str] = []
