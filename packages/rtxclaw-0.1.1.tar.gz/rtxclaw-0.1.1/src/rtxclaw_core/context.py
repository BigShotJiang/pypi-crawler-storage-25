"""OpenClaw-style context injection.

At session start, prepend the contents of
`<root>/{WORKSPACE,SOUL,USER,TOOLS,TOOLCALL,AGENTS}.md` to the user's
configured `system` prompt — in that order. Each file becomes a labeled
section so the model can tell them apart.

Callers always pass an explicit `root` (the agent's home dir at
`~/.rtxclaw/agents/<name>/`). The module-level `CONTEXT_DIR` default is a
fallback at `~/.rtxclaw/` so we never accidentally read or write a
`.rtxclaw/` directory into the project tree.

Missing files are skipped silently. With no files at all, the function
returns the user's system prompt unchanged.

MEMORY.md was previously loaded at the tail of the system prompt as a
"volatile" section, but that broke prefix-cache hits across turns: any
mid-session edit to MEMORY.md shifted the byte boundary inside the
system message, invalidating the KV cache for every token after it —
including the entire conversation history that follows. We now omit
MEMORY.md from the prompt entirely. The disk-write helpers
(`append_memory_entry`, `append_daily_memory`) remain for code paths
that still want to keep notes on disk; they no longer affect the
prompt sent upstream.

The system prompt is also intentionally sticky for the lifetime of a
session: `agent_runtime` builds it once at session creation, persists
it on the session record, and reuses the saved string on every turn.
It's only re-read from disk when a compaction event explicitly resets
the message list (so .md edits land in the next post-compact prompt).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

# Defaults are absolute (~/.rtxclaw/...) so we never leak a `.rtxclaw/`
# into the project tree if a caller forgets to pass an explicit root.
CONTEXT_DIR = Path.home() / ".rtxclaw"
CONTEXT_FILES: tuple[str, ...] = (
    # Stable prefix — byte-identical across turns of a session, so the
    # inference backend's prefix cache (vLLM APC / SGLang RadixAttention)
    # holds it across turns.
    "WORKSPACE.md",  # rtxclaw — agent home + filesystem layout
    "SOUL.md",       # OpenClaw — identity / vibe
    "USER.md",       # OpenClaw — who the user is
    "TOOLS.md",      # OpenClaw — local infra notes
    "TOOLCALL.md",   # rtxclaw — criticality contract for tool calls
    "AGENTS.md",     # OpenClaw — workspace + memory protocol
)

# Mode files: only ONE is loaded per turn, picked by the active permission
# mode (`tools.permissions.PermissionMode`). They sit at the tail of the
# stable prefix — cacheable within a session, but switch atoms when
# Shift+Tab cycles modes (which deliberately busts the cache from this
# point onward).
MODE_FILES: dict[str, str] = {
    "plan": "MODE-PLAN.md",
    "ask":  "MODE-ASK.md",
    "auto": "MODE-AUTO.md",
}
# Kept for legacy disk-write helpers below (`append_memory_entry`,
# `append_daily_memory`). MEMORY.md is no longer loaded into the prompt.
MEMORY_FILE = "MEMORY.md"
MEMORY_DAILY_DIR = "memory"

# Per-file cap on context `.md` reads. A runaway SOUL.md / TOOLS.md
# (e.g. a hostile or accidental dump into one of these files) would
# OOM the agent at session start; cap each at 1 MiB and the total at
# 10 MiB. Files exceeding the cap are read up to the cap and a
# truncation marker is appended so the operator notices.
CONTEXT_FILE_MAX_BYTES = 1 * 1024 * 1024
CONTEXT_TOTAL_MAX_BYTES = 10 * 1024 * 1024


def load_system_prompt(
    user_system: str = "",
    *,
    root: Path | None = None,
    mode: str | None = None,
) -> str:
    """Concatenate the workspace `.md` files into one system prompt.

    All behavior steering lives in editable `.md` files in the agent's
    home — the runtime adds NO prose of its own. Section order:

        WORKSPACE → SOUL → USER → TOOLS → TOOLCALL → AGENTS
        → MODE-<active>  → (optional `# SYSTEM`)

    The whole concatenation is byte-stable across turns of a session
    so the inference backend's prefix cache holds. The active mode
    file (`MODE-PLAN.md` / `MODE-ASK.md` / `MODE-AUTO.md`) is selected
    via `mode` — pass `None` to skip mode injection entirely.

    `user_system` is the legacy `cfg.system` extra block. It's empty
    in practice (most agents leave it ""); when set, it goes at the
    very end as `# SYSTEM`.

    If no files are present and no user_system is set, returns
    `user_system` (typically empty) so we don't add noise to a
    just-bootstrapped agent.
    """
    if root is None:
        root = CONTEXT_DIR

    total_consumed = 0  # nonlocal accumulator for the total cap

    def _read(fname: str) -> str | None:
        nonlocal total_consumed
        path = root / fname
        if not path.exists():
            return None
        try:
            with open(path, "rb") as f:
                # Read up to CONTEXT_FILE_MAX_BYTES + 1 so we can
                # detect the overflow and append a truncation marker
                # without materialising the whole oversized file.
                blob = f.read(CONTEXT_FILE_MAX_BYTES + 1)
        except OSError:
            return None
        truncated = len(blob) > CONTEXT_FILE_MAX_BYTES
        if truncated:
            blob = blob[:CONTEXT_FILE_MAX_BYTES]
        if total_consumed + len(blob) > CONTEXT_TOTAL_MAX_BYTES:
            # Total budget exhausted — drop this section entirely.
            # Better than partial corruption of headings / sections.
            return None
        total_consumed += len(blob)
        # `errors="replace"` — a legacy file with mixed encoding
        # shouldn't crash session start.
        body = blob.decode("utf-8", errors="replace").strip()
        if truncated:
            body += (
                f"\n\n[... truncated by rtxclaw context loader: file "
                f"exceeded CONTEXT_FILE_MAX_BYTES={CONTEXT_FILE_MAX_BYTES}]"
            )
        return body or None

    sections: list[str] = []
    for fname in CONTEXT_FILES:
        body = _read(fname)
        if body is not None:
            sections.append(body)

    # Mode file (rtxclaw-specific): only one loaded per request, by
    # active mode. Goes at the tail of the stable prefix.
    if mode and mode in MODE_FILES:
        body = _read(MODE_FILES[mode])
        if body is not None:
            sections.append(body)

    # Empty workspace + only `user_system` → return it bare (no `# SYSTEM`
    # label) so a simple test agent with no .md files gets a clean prompt.
    if not sections:
        return user_system

    if user_system.strip():
        sections.append(f"# SYSTEM\n{user_system.strip()}")

    return "\n\n".join(sections)


def memory_path(*, root: Path | None = None) -> Path:
    if root is None:
        root = CONTEXT_DIR
    return root / MEMORY_FILE


def daily_memory_path(*, root: Path | None = None, day: str | None = None) -> Path:
    """Return the per-day memory log path under `<root>/memory/YYYY-MM-DD.md`."""
    if root is None:
        root = CONTEXT_DIR
    if day is None:
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return root / MEMORY_DAILY_DIR / f"{day}.md"


def append_memory_entry(line: str, *, root: Path | None = None) -> None:
    """Append a single timestamped line to the agent's MEMORY.md.

    Creates the file with a small header on first write.
    """
    p = memory_path(root=root)
    p.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    if not p.exists():
        p.write_text(
            "# MEMORY\n\nCurated long-term memory. Appended by rtxclaw on session "
            "checkpoints and on session close.\n\n",
            encoding="utf-8",
        )
    with p.open("a", encoding="utf-8") as f:
        f.write(f"- [{ts}] {line.strip()}\n")


def append_daily_memory(line: str, *, root: Path | None = None) -> Path:
    if root is None:
        root = CONTEXT_DIR
    """Append a timestamped line to today's daily memory file.

    Returns the path written to. Creates `<root>/memory/YYYY-MM-DD.md`
    with a header on first write of the day.
    """
    p = daily_memory_path(root=root)
    p.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    if not p.exists():
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        p.write_text(f"# Memory log — {date}\n\n", encoding="utf-8")
    with p.open("a", encoding="utf-8") as f:
        f.write(f"- {ts} · {line.strip()}\n")
    return p
