"""Read side of the session log (append-only JSONL).

The on-disk session log is ``<agent_home>/sessions/<sid>.jsonl`` — one
event per LF-terminated line, each line prefixed with a CRC32 of the
JSON payload:

    <crc8> <json>\\n

where ``<crc8>`` is the 8-char lowercase hex of ``zlib.crc32`` over the
UTF-8 JSON bytes (everything right of the first space, excluding the
trailing newline) and ``<json>`` is
``json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))``.

The CRC lives OUTSIDE the JSON object (as a line prefix) on purpose:
an in-object ``_crc`` field is not byte-deterministic across json
serialisers, so a reader recomputing it would spuriously fail. The
prefix form lets the reader CRC exactly the on-disk bytes with no
re-serialisation. See ``session_writer.encode_line``.

Three readers consume this file:

* :func:`tail_jsonl` — incremental event stream from a byte offset,
  tolerant of a writer mid-append (partial trailing line) and of a
  corrupt line (CRC mismatch). Never raises on a malformed tail.
* :func:`fold_jsonl_into_turns` — reconstruct the legacy per-turn dict
  shape (the shape ``_render_one_saved_turn`` / telegram ``/history`` /
  memory ``on_session_end`` / the fine-tune harvester consume).
* The indexer's ``tail`` / ``rebuild`` (see ``session_index.py``) reuse
  :func:`tail_jsonl` to project events into ``sessions.db``.

Readers NEVER take the per-session lock. The writer's flock plus the
``\\n``-terminator-before-parse rule is the entire synchronisation
story; a reader that wants to stay consistent with ``sessions.db``
reads ``sessions_meta.live_last_event_offset`` first and bounds its
fold there (see the spec, §6).
"""
from __future__ import annotations

import json
import logging
import zlib
from pathlib import Path
from typing import Any, Iterator, Optional


_log = logging.getLogger(__name__)

SCHEMA_VERSION = "1"

# Process-wide count of dropped (CRC-mismatch / malformed) JSONL lines.
# A silently-dropped line is a hole in the fine-tune corpus, so every
# drop is logged AND counted. Readable for a Prometheus/metrics export.
SESSION_JSONL_CORRUPTION_TOTAL = 0


# ---- line codec -----------------------------------------------------


def _crc8(json_bytes: bytes) -> str:
    """8-char lowercase hex CRC32 of the JSON payload bytes."""
    return f"{zlib.crc32(json_bytes) & 0xFFFFFFFF:08x}"


def encode_line(event: dict[str, Any]) -> bytes:
    """Serialise one event to its on-disk line bytes (incl. trailing LF).

    The canonical wire form. ``session_writer`` calls this; tests assert
    against it. Pinned ``json.dumps`` flags make the bytes deterministic
    so the CRC round-trips.
    """
    payload = json.dumps(
        event, sort_keys=True, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return _crc8(payload).encode("ascii") + b" " + payload + b"\n"


def decode_line(raw: bytes) -> Optional[dict[str, Any]]:
    """Parse one on-disk line (without trailing LF) back to an event.

    Returns ``None`` when the line is malformed OR the CRC does not
    match — the caller treats both as "skip this line." Never raises.
    """
    if not raw:
        return None
    sp = raw.find(b" ")
    if sp != 8:
        # Prefix must be exactly 8 hex chars + a space. Anything else
        # is a torn/partial/foreign line.
        return None
    prefix = raw[:8]
    payload = raw[9:]
    if not payload:
        return None
    if _crc8(payload).encode("ascii") != prefix:
        return None
    try:
        obj = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(obj, dict):
        return None
    return obj


# ---- tail reader ----------------------------------------------------


def tail_jsonl(
    path: Path, start_offset: int = 0
) -> Iterator[tuple[dict[str, Any], int]]:
    """Yield ``(event, end_offset)`` for every complete, CRC-valid line
    at or after ``start_offset``.

    ``end_offset`` is the byte position immediately after the line's
    terminating ``\\n`` — feed it back as the next ``start_offset`` to
    resume without re-reading. A partial trailing line (writer mid-
    append, no ``\\n`` yet) is left unconsumed; the next call retries
    from the last complete line's end. A CRC-mismatched / malformed
    line is skipped (the caller may bump a corruption counter) and the
    scan advances past it so it is never re-read in a loop.

    Tolerant of a missing file (yields nothing) — a freshly created
    session may not have flushed its first line yet.
    """
    try:
        f = open(path, "rb")
    except FileNotFoundError:
        return
    try:
        f.seek(start_offset)
        buf = b""
        pos = start_offset  # byte offset of the start of ``buf``
        while True:
            chunk = f.read(1 << 16)
            if not chunk:
                break
            buf += chunk
            while True:
                nl = buf.find(b"\n")
                if nl < 0:
                    break
                line = buf[:nl]
                end_offset = pos + nl + 1
                event = decode_line(line)
                # Advance regardless of validity so a bad line is never
                # re-scanned on the next pass.
                buf = buf[nl + 1 :]
                if event is not None:
                    pos = end_offset
                    yield event, end_offset
                elif line:
                    # A non-empty line that failed CRC/parse is a
                    # corrupt event — count + log it (a silent drop is a
                    # hole in the fine-tune corpus). Empty lines (a bare
                    # \n) are ignored without noise.
                    global SESSION_JSONL_CORRUPTION_TOTAL
                    SESSION_JSONL_CORRUPTION_TOTAL += 1
                    _log.warning(
                        "session jsonl: dropped corrupt line at offset %d in %s",
                        pos, path,
                    )
                    pos = end_offset
                else:
                    pos = end_offset
    finally:
        f.close()


# ---- turn materialisation -------------------------------------------


def _empty_turn(turn_idx: int) -> dict[str, Any]:
    """The legacy per-turn dict skeleton every consumer expects.

    Mirrors the shape ``Session.add_turn`` produced plus the fine-
    tune fields. Consumers (``_render_one_saved_turn``, telegram
    ``/history``, memory ``on_session_end``) read a subset; the fold
    fills every field it can so no consumer regresses.
    """
    return {
        "user": "",
        "thinking": "",
        "content": "",
        "started_at": "",
        "ended_at": "",
        "aborted": False,
        "error": None,
        "metrics": {},
        "in_progress": False,
        "engine": "",
        "model": "",
        "permission_mode": "",
        "cwd": "",
        "tool_calls": [],
        "tool_results": [],
        "round_metrics": [],
        # replay-fidelity (from round_started / turn_ended events)
        "model_input_messages": [],
        "effective_system_prompt": "",
        "effective_system_prompt_sha256": "",
        "effective_preamble": [],
        "upstream_endpoint": "",
        "finish_reason": "",
        # lifecycle audit lists (from lifecycle events)
        "hook_outcomes": [],
        "approval_decisions": [],
        "compaction_events": [],
        "distill_events": [],
        "nudge_events": [],
        "pause_resume_log": [],
        "_turn_idx": turn_idx,
    }


_ENVELOPE_KEYS = frozenset({"v", "ts", "type", "engine", "turn_idx", "round_idx"})


def _payload_only(ev: dict[str, Any]) -> dict[str, Any]:
    """Strip the event envelope, returning just the payload fields."""
    return {k: v for k, v in ev.items() if k not in _ENVELOPE_KEYS}


def fold_events_into_turns(
    events: Iterator[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Fold an event stream into the legacy per-turn dict list.

    One dict per ``turn_idx``, in turn order. ``text_delta`` /
    ``thinking_delta`` chunks concatenate into ``content`` / ``thinking``;
    ``tool_call`` / ``tool_result_meta`` / ``tool_result`` accumulate
    into ``tool_calls`` / ``tool_results``; ``round_ended`` metrics
    append to ``round_metrics``; ``turn_ended`` stamps the terminal
    fields (``final_content`` wins over accumulated deltas, since the
    engine may have rewritten the final text). ``turn_started`` stamps
    ``user`` / ``permission_mode`` / ``cwd``.

    The fold is lossless for the legacy shape: a consumer that read
    ``data["turns"]`` from the old ``<sid>.json`` sees the same keys.
    """
    turns: dict[int, dict[str, Any]] = {}
    order: list[int] = []

    def _turn(idx: int) -> dict[str, Any]:
        t = turns.get(idx)
        if t is None:
            t = _empty_turn(idx)
            turns[idx] = t
            order.append(idx)
        return t

    for ev in events:
        etype = ev.get("type")
        ti = ev.get("turn_idx")
        if etype == "session_started":
            continue
        if ti is None:
            # header_update / session_closed — not turn-scoped.
            continue
        t = _turn(int(ti))
        engine = ev.get("engine") or ""
        if engine and not t["engine"]:
            t["engine"] = engine
        if etype == "turn_started":
            t["user"] = ev.get("user", "")
            t["permission_mode"] = ev.get("permission_mode", "") or ""
            t["cwd"] = ev.get("cwd", "") or ""
            t["started_at"] = ev.get("ts", "") or t["started_at"]
            if ev.get("attachments"):
                t["attachments"] = ev["attachments"]
        elif etype == "round_started":
            if ev.get("model") and not t["model"]:
                t["model"] = ev["model"]
            if ev.get("model_input"):
                t["model_input_messages"] = ev["model_input"]
            if ev.get("effective_system_prompt"):
                t["effective_system_prompt"] = ev["effective_system_prompt"]
            if ev.get("effective_system_prompt_sha256"):
                t["effective_system_prompt_sha256"] = ev["effective_system_prompt_sha256"]
            if ev.get("effective_preamble"):
                t["effective_preamble"] = ev["effective_preamble"]
            if ev.get("upstream_endpoint"):
                t["upstream_endpoint"] = ev["upstream_endpoint"]
        elif etype == "text_delta":
            t["content"] += ev.get("delta", "") or ""
        elif etype == "thinking_delta":
            t["thinking"] += ev.get("delta", "") or ""
        elif etype == "tool_call":
            t["tool_calls"].append({
                "call_id": ev.get("call_id", ""),
                "name": ev.get("name", ""),
                "arguments": ev.get("arguments", {}),
                "raw_arguments": ev.get("raw_arguments", ""),
                "started_at": ev.get("started_at", ""),
            })
        elif etype == "tool_result_meta":
            t["tool_results"].append({
                "call_id": ev.get("call_id", ""),
                "ok": bool(ev.get("ok")),
                "ended_at": ev.get("ended_at", ""),
                "content_chars": ev.get("content_chars", 0),
            })
        elif etype == "tool_result":
            # Body event (gated). Attach to the matching meta row if
            # present, else stash a body-only row so harvesters see it.
            cid = ev.get("call_id", "")
            for r in reversed(t["tool_results"]):
                if r.get("call_id") == cid and "content" not in r:
                    r["content"] = ev.get("content", "")
                    break
            else:
                t["tool_results"].append({
                    "call_id": cid, "content": ev.get("content", ""),
                })
        elif etype == "round_ended":
            m = ev.get("metrics") or {}
            if ev.get("tokenizer_id"):
                m = {**m, "tokenizer_id": ev["tokenizer_id"]}
            t["round_metrics"].append(m)
            if ev.get("finish_reason"):
                t["finish_reason"] = ev["finish_reason"]
        elif etype == "hook_outcome":
            t["hook_outcomes"].append(_payload_only(ev))
        elif etype == "approval_decision":
            t["approval_decisions"].append(_payload_only(ev))
        elif etype == "compaction":
            t["compaction_events"].append(_payload_only(ev))
        elif etype == "distill":
            t["distill_events"].append(_payload_only(ev))
        elif etype == "nudge":
            t["nudge_events"].append(_payload_only(ev))
        elif etype == "pause_resume":
            t["pause_resume_log"].append(_payload_only(ev))
        elif etype == "loop_detected":
            t.setdefault("loop_events", []).append(_payload_only(ev))
        elif etype == "turn_ended":
            fc = ev.get("final_content")
            if fc is not None:
                t["content"] = fc
            ft = ev.get("final_thinking")
            if ft is not None:
                t["thinking"] = ft
            t["_terminal"] = True
            t["aborted"] = bool(ev.get("aborted"))
            t["error"] = ev.get("error")
            if ev.get("error_classification"):
                t["error_classification"] = ev["error_classification"]
            t["metrics"] = ev.get("metrics") or t["metrics"]
            t["ended_at"] = ev.get("ts", "") or t["ended_at"]
            t["in_progress"] = False
            # The terminal record now also stamps the permission mode;
            # honor it if turn_started was missing / lost (don't clobber
            # an already-folded non-empty value with an empty one).
            if ev.get("permission_mode") and not t.get("permission_mode"):
                t["permission_mode"] = ev["permission_mode"]

    # For an IN-FLIGHT turn (no turn_ended seen), content/thinking were
    # assembled from per-chunk deltas that were each scrubbed
    # independently — a secret split across a debounce boundary could
    # reassemble in the clear here. Re-scrub the folded text for any turn
    # that didn't reach turn_ended (terminal turns already carry the
    # scrubbed final_content). (review: Codex S1)
    out = []
    for i in order:
        t = turns[i]
        if not t.pop("_terminal", False):
            from rtxclaw_core.secrets_scrubber import scrub_text
            if t.get("content"):
                t["content"] = scrub_text(t["content"])
            if t.get("thinking"):
                t["thinking"] = scrub_text(t["thinking"])
            t["in_progress"] = True
        out.append(t)
    return out


def fold_jsonl_into_turns(
    path: Path, start_offset: int = 0
) -> list[dict[str, Any]]:
    """Convenience: tail a JSONL file from disk and fold to turns."""
    return fold_events_into_turns(
        ev for ev, _off in tail_jsonl(path, start_offset)
    )


def load_session_dict(sessions_dir: Path, sid: str) -> Optional[dict[str, Any]]:
    """Return a legacy ``<sid>.json``-shaped dict for one session: the
    materialised header (sessions.db, refreshed via tail) plus the turns
    folded from ``<sid>.jsonl``. ``None`` when the session is unknown.

    The single read helper for consumers that used to
    ``json.loads(<sid>.json)`` (telegram /status·/history·/context, etc.).
    """
    sessions_dir = Path(sessions_dir)
    jsonl = sessions_dir / f"{sid}.jsonl"
    db = sessions_dir / "sessions.db"
    if not jsonl.exists() and not db.exists():
        return None
    from rtxclaw_core.session_index import (  # local import avoids a cycle
        SessionIndex, connect_sessions_db,
    )
    d: dict[str, Any] = {}
    try:
        SessionIndex(sessions_dir.parent).tail(sid)
        con = connect_sessions_db(db)
        try:
            row = con.execute(
                "SELECT * FROM sessions_meta WHERE session_hash=?", (sid,)
            ).fetchone()
        finally:
            con.close()
        if row is not None:
            d = dict(row)
            d["hash"] = d.get("session_hash")
            pf = d.get("pinned_facts")
            if isinstance(pf, str):
                try:
                    d["pinned_facts"] = json.loads(pf)
                except (ValueError, TypeError):
                    d["pinned_facts"] = []
    except Exception:  # noqa: BLE001
        d = {"hash": sid}
    try:
        d["turns"] = fold_jsonl_into_turns(jsonl)
    except Exception:  # noqa: BLE001
        d["turns"] = []
    if not d.get("hash"):
        d["hash"] = sid
    return d
