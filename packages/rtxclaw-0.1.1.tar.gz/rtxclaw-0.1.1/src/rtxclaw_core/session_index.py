"""SQLite-backed FTS5 search over saved session turns.

Sessions are JSON files at `<agent_home>/sessions/<hash>.json`; nothing
indexes their *contents* today, so "did we discuss X last week?" has no
fast answer. This module fixes that with a separate `sessions.db`
keyed by session hash + turn index, indexed via FTS5 on user/assistant
text combined per turn.

Two-table layout (sessions_meta + turns) instead of letting the FTS
table double as storage. Reasons:

- A future migration that wants role splitting / per-side scoring
  doesn't need a re-import — the `turns` table holds the durable
  rows; FTS is a derived index that can be rebuilt.
- `pin_fact` / future "summarize this session" tools can hit the
  `turns` table directly without going through MATCH.

Memory and session indexes are deliberately split into different
DBs so the memory index's chunking + embedding pipeline (see
`memory_index.py`) doesn't get polluted with conversational noise.

Lifecycle:

- `Session.save()` (in-process) publishes `session_saved` on the
  shared event bus.
- `subscribe_for_sessions(home)` wires that event to a non-blocking
  `index_session()` call and runs a one-shot `reindex_all()` to
  backfill any history on first wire.
- The `session_search` tool (subprocess-side) opens a fresh
  `SessionIndex` per call — same lazy pattern `memory_tools.py`
  uses for `MemoryIndex`. The tool runner subprocess inherits
  `RTXCLAW_AGENT_HOME` and `RTXCLAW_WORKSPACE_ORIGIN` so the privacy
  gate enforces the same trusted-origin set memory tools do.

FTS-only by design — vector search over conversational text added
little signal in early prototypes (turns are short, terms repeat,
BM25 + recency does the heavy lifting). Re-introduce it later by
mirroring the `chunks_vec` virtual table from `memory_index.py` if
the recall numbers ever justify it.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

from rtxclaw_memory.memory_primitives import (
    DEFAULT_SNIPPET_CHARS,
    RecallResult,
    bm25_rank_to_score,
    build_fts_query,
    format_recall_hits,
)


_log = logging.getLogger(__name__)


DEFAULT_MAX_RESULTS: int = 6
DEFAULT_MIN_SCORE: float = 0.35


# ---- privacy gate (mirrors memory_tools.py / memory_write.py) -------

_PRIVATE_ORIGINS: frozenset[str] = frozenset({
    "", "tui", "oneshot", "heartbeat", "telegram",
})


def _is_private_origin(workspace_origin: str) -> bool:
    """True iff the calling session is a private (trusted) frontend."""
    return (workspace_origin or "").strip().lower() in _PRIVATE_ORIGINS


# ---- text extraction ------------------------------------------------

def _extract_user_text(user: Any) -> str:
    """Pull plain text out of a turn's `user` field.

    Vision-capable models accept multi-part `user` content (a list of
    `{type: image_url|text, ...}` dicts). For search purposes we only
    care about the text parts; image URLs are skipped.
    """
    if isinstance(user, str):
        return user
    if isinstance(user, list):
        parts: list[str] = []
        for part in user:
            if isinstance(part, dict):
                kind = str(part.get("type") or "").lower()
                if kind == "text":
                    txt = part.get("text") or ""
                    if txt:
                        parts.append(str(txt))
            elif isinstance(part, str):
                parts.append(part)
        return "\n".join(parts)
    if user is None:
        return ""
    return str(user)


def _combine_turn(user: Any, assistant: str) -> str:
    """Combine user + assistant text into a single FTS document.

    A leading separator + role tag would help downstream consumers
    that want to slice the snippet, but FTS5's `snippet()` works
    over the raw string — keep the markup minimal.
    """
    user_text = _extract_user_text(user).strip()
    assistant_text = (assistant or "").strip()
    if user_text and assistant_text:
        return f"{user_text}\n---\n{assistant_text}"
    return user_text or assistant_text


def _derive_title(user: Any, limit: int = 60) -> str:
    """First non-empty line of the user prompt, truncated. Mirrors
    ``Session._derive_title`` so a title derived by the projector
    matches what the in-memory dataclass would have produced."""
    text = _extract_user_text(user)
    if not text:
        return "session"
    first = next(
        (line for line in text.strip().splitlines() if line.strip()), ""
    )
    if not first:
        return "session"
    return first[:limit] + ("…" if len(first) > limit else "")


# ---- structured event extraction ------------------------------------


# Recognised event kinds. Stored as TEXT in turn_events.kind so
# downstream queries can JOIN / GROUP BY without a separate enum.
EVENT_KINDS = (
    "loop",              # loop detector fired (metrics.loop_detected==True
                         # OR finish_reason=='tool_args_loop')
    "nudge",             # silent-nudge after premature end / loop
    "distill",           # partial-reasoning recovery
    "compaction",        # mid-turn compaction
    "pause_resume",      # operator-driven pause/resume cycle
    "error",             # turn-level error with classification
    "finish",            # finish_reason (always emitted once per turn)
    "tool_call",         # one row per tool dispatched
    "tool_result_fail",  # one row per tool_result with ok=False
)


def _extract_turn_events(
    session_hash: str,
    turn_idx: int,
    turn: dict,
    default_ts_ms: int,
) -> list[tuple[str, str]]:
    """Fan one turn dict into `(kind, payload_json)` tuples.

    Empty result is fine — many turns have nothing to index here.
    Each emitted payload is a small JSON document with the
    actionable fields for that kind; the FULL turn record stays in
    the on-disk JSON for callers who need the surrounding context.

    Self-improvement use case (fine-tune / eval / regression):
    queryers JOIN ``turn_events`` to ``sessions_meta`` + ``turns``
    to get session metadata + conversational text alongside the
    structured event payload.
    """
    out: list[tuple[str, str]] = []
    if not isinstance(turn, dict):
        return out
    metrics = turn.get("metrics") or {}
    if not isinstance(metrics, dict):
        metrics = {}

    # loop — metrics.loop_detected (PR #242 flattening) OR a literal
    # tool_args_loop finish_reason OR token_loop_suspected heuristic.
    finish_reason = (
        str(metrics.get("finish_reason") or turn.get("finish_reason") or "")
    )
    if (
        metrics.get("loop_detected")
        or metrics.get("loop_event")
        or metrics.get("token_loop_suspected")
        or finish_reason == "tool_args_loop"
    ):
        payload = {
            "tier": metrics.get("loop_tier") or "",
            "evidence": metrics.get("loop_evidence") or "",
            "channel": metrics.get("loop_channel") or "",
            "tool_name": metrics.get("loop_tool_name") or "",
            "args_chars": metrics.get("loop_args_chars"),
            "checked_at": metrics.get("loop_checked_at"),
            "finish_reason": finish_reason,
            "token_loop_suspected": bool(
                metrics.get("token_loop_suspected") or False,
            ),
            # Preserve the raw nested dict too when present — it's
            # the legacy shape from pre-PR-#242 records.
            "raw": metrics.get("loop_event"),
        }
        out.append(("loop", json.dumps(payload, ensure_ascii=False)))

    # finish — emitted whenever the turn terminated (real
    # finish_reason OR explicit aborted flag), so forensics
    # queries like "how many turns aborted before finishing" can
    # count without scanning every JSON. ``in_progress`` is NOT
    # part of this predicate: ``index_session`` skips in_progress
    # turns up-front (so live-flush checkpoints don't churn the
    # index against the same row N times per turn), so we'd never
    # reach this branch with ``in_progress=True`` from production.
    aborted = bool(turn.get("aborted"))
    if finish_reason or aborted:
        out.append((
            "finish",
            json.dumps(
                {
                    "finish_reason": finish_reason,
                    "aborted": aborted,
                },
                ensure_ascii=False,
            ),
        ))

    # error — turn-level error + classification (engine_exception,
    # rate_limit, needs_memory_flush, etc.).
    err = turn.get("error")
    err_class = turn.get("error_classification") or ""
    if err or err_class:
        out.append((
            "error",
            json.dumps(
                {
                    "message": str(err or "")[:1000],
                    "classification": err_class,
                    "finish_reason": finish_reason,
                },
                ensure_ascii=False,
            ),
        ))

    # tool_call — one row per dispatched tool. Cap the serialised
    # arguments payload at ``_TOOL_ARGS_CAP`` chars so a single
    # multi-megabyte pasted blob (long SQL / base64 / file body)
    # can't balloon sessions.db at "thousands of sessions" scale.
    # When the truncation fires, store a marker + the original
    # length so the row still tells the trainer "this turn passed
    # a giant payload" without keeping it verbatim. Match the
    # 1000-char policy on error.message / tool_result_fail.content
    # so the truncation budget is consistent.
    #
    # NOTE: this column is an INDEX, not a content store. For full
    # fidelity (fine-tune SFT pipelines, etc.) read the on-disk
    # session JSON — ``turn_events`` only carries enough to drive
    # SELECTs that pinpoint which turn to load.
    _TOOL_ARGS_CAP = 1000
    for call in turn.get("tool_calls") or []:
        if not isinstance(call, dict):
            continue
        raw_args = call.get("arguments") or {}
        try:
            args_dumped = json.dumps(raw_args, ensure_ascii=False)
            args_unserializable = False
        except (TypeError, ValueError):
            # ``arguments`` carried a non-JSON-serialisable value
            # (an engine bug — the wire shape should always be a
            # dict-of-primitives, but defensive code keeps the
            # whole turn from disappearing from the index). Anchor
            # the outer dump on the stringified repr instead.
            args_dumped = str(raw_args)
            args_unserializable = True
        if args_unserializable or len(args_dumped) > _TOOL_ARGS_CAP:
            args_field: Any = {
                "_truncated": True,
                "_full_chars": len(args_dumped),
                "preview": args_dumped[:_TOOL_ARGS_CAP],
            }
            if args_unserializable:
                args_field["_unserializable"] = True
        else:
            args_field = raw_args
        out.append((
            "tool_call",
            json.dumps(
                {
                    "call_id": str(call.get("call_id") or ""),
                    "name": str(call.get("name") or ""),
                    "arguments": args_field,
                    "started_at": str(call.get("started_at") or ""),
                },
                ensure_ascii=False,
            ),
        ))

    # tool_result_fail — only failures (ok=False). Successes are
    # already implied by the matching tool_call row. Note that
    # tool_results carry only metadata after session_log.record_turn
    # strips the content body (fix_20260519 round-4) — the
    # ``content_chars`` size hint is enough for an indexer; the
    # actual body lives in gateway.log if a debugger needs it.
    for result in turn.get("tool_results") or []:
        if not isinstance(result, dict):
            continue
        if result.get("ok"):
            continue
        # Tolerate both the legacy shape (with ``content``) AND the
        # post-stripping shape (with ``content_chars``).
        legacy_content = result.get("content")
        out.append((
            "tool_result_fail",
            json.dumps(
                {
                    "call_id": str(result.get("call_id") or ""),
                    "content_chars": int(
                        result.get("content_chars")
                        if result.get("content_chars") is not None
                        else (len(legacy_content) if isinstance(legacy_content, str) else 0)
                    ),
                    "ended_at": str(result.get("ended_at") or ""),
                },
                ensure_ascii=False,
            ),
        ))

    # Forward-compat: the four lifecycle audit lists on TurnRecord
    # (nudge_events / distill_events / compaction_events /
    # pause_resume_log). Today's engine doesn't write them; once it
    # does, the index picks them up automatically with no schema
    # bump. Empty lists produce zero rows.
    _LIFECYCLE_KINDS = (
        ("nudge_events", "nudge"),
        ("distill_events", "distill"),
        ("compaction_events", "compaction"),
        ("pause_resume_log", "pause_resume"),
    )
    for field_name, kind in _LIFECYCLE_KINDS:
        for entry in turn.get(field_name) or []:
            if not isinstance(entry, dict):
                # Tolerate engines that wrote a bare string — wrap
                # it so the payload column is always valid JSON.
                entry = {"value": str(entry)}
            out.append((kind, json.dumps(entry, ensure_ascii=False)))

    return out


# ---- main class -----------------------------------------------------

class SessionIndex:
    """One `sessions.db` per agent home.

    Three-table layout:
      - `sessions_meta` — one row per session (title, created_at,
        frontend, updated_at).
      - `turns` — one row per non-empty turn (combined_text, ts).
        rowid is autoincrement; FK references `sessions_meta`.
      - `turns_fts` — FTS5 virtual table over `combined_text`. Kept
        in sync manually (FTS5 triggers are fragile across
        INSERT-OR-REPLACE rowid churn — same reason `MemoryIndex`
        avoids them).

    Thread safety: NOT shared across threads. Open a fresh instance
    per call.
    """

    def __init__(self, agent_home: Path) -> None:
        self.agent_home = Path(agent_home)
        self.sessions_dir = self.agent_home / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.sessions_dir / "sessions.db"
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return connect_sessions_db(self.db_path)

    def _init_db(self) -> None:
        ensure_schema(self.db_path)

    # -- write path (tail JSONL into the index) --------------------

    def tail(self, sid: str, *, projector: Optional["EventProjector"] = None) -> int:
        """Project new ``<sid>.jsonl`` events into the db, from the
        session's ``indexed_bytes`` cursor forward.

        Idempotent and crash-safe: each event advances ``indexed_bytes``
        in the same transaction, and the per-event ``turn_events`` writes
        use INSERT-OR-IGNORE on a dedup UNIQUE index. Resets the cursor
        to 0 when it has run past EOF (operator truncated the JSONL).

        This is the fallback / reconcile path. In the steady state the
        ``SessionWriter`` projects each event in-line as it appends, so
        ``tail`` usually finds nothing new. Returns the count applied.
        """
        from rtxclaw_core.session_reader import tail_jsonl
        sid = str(sid)
        path = self.sessions_dir / f"{sid}.jsonl"
        if not path.exists():
            return 0
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        con = self._connect()
        try:
            proj = projector or EventProjector()
            applied = 0
            # Read the cursor INSIDE the write transaction so two
            # concurrent tail()s can't both fold from the same stale
            # offset and double-apply the live-column read-modify-append
            # (review: Gemini final — TOCTOU on indexed_bytes). The
            # second tailer blocks on BEGIN IMMEDIATE, then sees the
            # advanced cursor and folds nothing.
            con.execute("BEGIN IMMEDIATE")
            try:
                row = con.execute(
                    "SELECT indexed_bytes FROM sessions_meta WHERE session_hash=?",
                    (sid,),
                ).fetchone()
                start = int(row["indexed_bytes"]) if row is not None else 0
                if start > size:
                    # JSONL truncated under us — re-fold from the top.
                    start = 0
                for event, end_off in tail_jsonl(path, start):
                    proj.apply(con, sid, event, end_off)
                    applied += 1
                con.commit()
            except BaseException:
                con.rollback()
                raise
            return applied
        finally:
            con.close()

    def refresh(self) -> int:
        """Tail every session whose JSONL has grown past its indexed
        cursor — the read-side lazy-index trigger.

        The writer appends to the JSONL only (no realtime SQL); this
        brings ``sessions.db`` current before a list/search read. Cheap:
        one ``stat`` + one indexed_bytes lookup per session, and a real
        tail only for the ones that actually grew. Returns the number of
        sessions refreshed.
        """
        if not self.sessions_dir.is_dir():
            return 0
        con = self._connect()
        try:
            cur = {
                row["session_hash"]: int(row["indexed_bytes"])
                for row in con.execute(
                    "SELECT session_hash, indexed_bytes FROM sessions_meta"
                )
            }
        except Exception:  # noqa: BLE001
            cur = {}
        finally:
            con.close()
        refreshed = 0
        for entry in self.sessions_dir.iterdir():
            if not entry.is_file() or entry.suffix != ".jsonl":
                continue
            sid = entry.stem
            try:
                size = entry.stat().st_size
            except OSError:
                continue
            if size > cur.get(sid, 0):
                try:
                    self.tail(sid)
                    refreshed += 1
                except Exception:  # noqa: BLE001
                    pass
        return refreshed

    def rebuild(self) -> dict:
        """Recreate the index for every ``<sid>.jsonl`` from offset 0.

        Power-loss recovery: ``sessions.db`` is a derived cache; the
        JSONL files are the source of truth. Wipes the materialised
        rows for each session, resets its cursor, and re-tails.
        """
        stats = {"files": 0, "events": 0, "errors": 0}
        if not self.sessions_dir.is_dir():
            return stats
        for entry in sorted(self.sessions_dir.iterdir()):
            if not entry.is_file() or entry.suffix != ".jsonl":
                continue
            sid = entry.stem
            stats["files"] += 1
            con = self._connect()
            try:
                for tbl in ("turn_events", "turns", "turns_fts", "sessions_meta"):
                    con.execute(f"DELETE FROM {tbl} WHERE session_hash=?", (sid,))
                con.execute(
                    "INSERT OR IGNORE INTO sessions_meta(session_hash, indexed_bytes) "
                    "VALUES (?, 0)",
                    (sid,),
                )
                con.commit()
            finally:
                con.close()
            try:
                stats["events"] += self.tail(sid)
            except Exception:  # noqa: BLE001
                stats["errors"] += 1
        return stats

    def index_session_file(self, path: Path) -> int:
        """Back-compat shim: tail the JSONL for ``path``'s session.

        The legacy whole-file JSON re-index is gone (is append-only
        JSONL). Accepts a ``<sid>.jsonl`` path and tails it.
        """
        sid = Path(path).stem
        try:
            return self.tail(sid)
        except Exception:  # noqa: BLE001
            return 0

    def reindex_all(self) -> dict:
        """Back-compat alias for :meth:`rebuild`."""
        r = self.rebuild()
        return {"files": r["files"], "indexed_turns": r["events"],
                "errors": r["errors"]}

    def remove_session(self, session_hash: str) -> None:
        """Drop one session's rows. Used when a session is deleted."""
        if not session_hash:
            return
        con = self._connect()
        try:
            con.execute("DELETE FROM turns_fts WHERE session_hash = ?", (session_hash,))
            con.execute("DELETE FROM turns WHERE session_hash = ?", (session_hash,))
            con.execute("DELETE FROM turn_events WHERE session_hash = ?", (session_hash,))
            con.execute("DELETE FROM sessions_meta WHERE session_hash = ?", (session_hash,))
            con.commit()
        finally:
            con.close()

    # -- read path -----------------------------------------------------

    def search(
        self,
        query: str,
        *,
        top_k: int = DEFAULT_MAX_RESULTS,
        min_score: float = DEFAULT_MIN_SCORE,
    ) -> list[RecallResult]:
        """FTS5 search across saved session turns.

        Returns `RecallResult`s with `source="session"` so callers
        can rank session hits alongside other recall sources.
        """
        query = (query or "").strip()
        if not query:
            return []
        match = build_fts_query(query)
        if match is None:
            return []
        con = self._connect()
        try:
            rows = con.execute(
                "SELECT f.session_hash AS session_hash, "
                "       f.turn_idx     AS turn_idx, "
                "       snippet(turns_fts, 0, '', '', '…', 64) AS snippet, "
                "       bm25(turns_fts) AS rank, "
                "       m.title        AS title, "
                "       m.created_at   AS created_at, "
                "       m.workspace_origin AS frontend "
                "FROM turns_fts AS f "
                "LEFT JOIN sessions_meta AS m "
                "  ON m.session_hash = f.session_hash "
                "WHERE turns_fts MATCH ? "
                "ORDER BY rank LIMIT ?",
                (match, max(1, int(top_k)) * 4),
            ).fetchall()
        finally:
            con.close()

        out: list[RecallResult] = []
        for r in rows:
            score = bm25_rank_to_score(float(r["rank"]))
            if score < min_score:
                continue
            session_hash = r["session_hash"]
            title = r["title"] or f"untitled-{(session_hash or '')[-8:]}"
            created_at = str(r["created_at"] or "")
            date_part = created_at.split("T", 1)[0] if created_at else ""
            out.append(RecallResult(
                source="session",
                path_or_id=session_hash,
                title=title,
                snippet=(r["snippet"] or "")[:DEFAULT_SNIPPET_CHARS],
                score=score,
                metadata={
                    "turn_idx": int(r["turn_idx"]),
                    "date": date_part,
                    "frontend": r["frontend"] or "",
                },
            ))
        # Dedup on (session_hash, turn_idx) — defensive; with the new
        # combined-text schema each turn is one row and won't appear
        # twice, but keep the guard for forward-compatibility with any
        # future role-split index.
        by_key: dict[tuple[str, int], RecallResult] = {}
        for h in out:
            key = (h.path_or_id, int(h.metadata.get("turn_idx", 0)))
            existing = by_key.get(key)
            if existing is None or h.score > existing.score:
                by_key[key] = h
        deduped = sorted(by_key.values(), key=lambda x: x.score, reverse=True)
        return deduped[: max(1, int(top_k))]

    def stats(self) -> dict:
        con = self._connect()
        try:
            sess_n = con.execute(
                "SELECT count(*) AS n FROM sessions_meta"
            ).fetchone()["n"]
            turn_n = con.execute(
                "SELECT count(*) AS n FROM turns"
            ).fetchone()["n"]
            fts_n = con.execute(
                "SELECT count(*) AS n FROM turns_fts"
            ).fetchone()["n"]
        finally:
            con.close()
        try:
            db_size = self.db_path.stat().st_size
        except OSError:
            db_size = 0
        return {
            "db_path": str(self.db_path),
            "db_size_bytes": db_size,
            "sessions": sess_n,
            "turns": turn_n,
            "turn_rows": fts_n,  # back-compat alias
        }

    def clear(self) -> None:
        """Drop all data — for `rtxclaw session index --force` (future)."""
        con = self._connect()
        try:
            con.executescript(
                "DELETE FROM turns_fts;\n"
                "DELETE FROM turns;\n"
                "DELETE FROM turn_events;\n"
                "DELETE FROM sessions_meta;"
            )
            con.commit()
        finally:
            con.close()


def _iso_to_ms(ts: Any) -> int:
    """Best-effort ISO-8601 → epoch milliseconds."""
    if not ts:
        return 0
    if isinstance(ts, (int, float)):
        return int(ts)
    if not isinstance(ts, str):
        return 0
    try:
        from datetime import datetime
        # Strip any trailing 'Z' for fromisoformat (3.10 doesn't
        # accept it); 3.11+ does.
        cleaned = ts.replace("Z", "+00:00")
        return int(datetime.fromisoformat(cleaned).timestamp() * 1000)
    except (ValueError, TypeError):
        return 0


# ---- public tool entry --------------------------------------------

def session_search(
    query: str,
    *,
    top_k: int = DEFAULT_MAX_RESULTS,
    min_score: float = DEFAULT_MIN_SCORE,
    workspace_origin: str = "",
    agent_home: Optional[Path] = None,
) -> str:
    """FTS-based search over saved sessions. Returns a markdown blob.

    Privacy gate: refused on shared / group frontends, same as
    `memory_search`.
    """
    if not _is_private_origin(workspace_origin):
        return (
            "session_search refused: this session's workspace_origin is not "
            "private (past conversations may contain operator notes — "
            "shared / group frontends can't read them)."
        )
    home = agent_home or _resolve_agent_home()
    if home is None:
        return "session_search failed: agent home not resolvable from env."
    if not isinstance(query, str) or not query.strip():
        return "session_search failed: query required."
    try:
        top_k = max(1, min(20, int(top_k)))
    except (TypeError, ValueError):
        top_k = DEFAULT_MAX_RESULTS
    try:
        min_score = max(0.0, min(1.0, float(min_score)))
    except (TypeError, ValueError):
        min_score = DEFAULT_MIN_SCORE
    idx = SessionIndex(home)
    hits = idx.search(query, top_k=top_k, min_score=min_score)
    if not hits:
        return f"session_search: no matches for {query!r} (min_score={min_score})."
    return format_recall_hits(
        hits,
        header=f"# session_search: {query!r}\n_{len(hits)} hit(s)_",
    )


def _resolve_agent_home() -> Optional[Path]:
    """Same resolution as `memory_tools._resolve_agent_home`."""
    explicit = os.environ.get("RTXCLAW_AGENT_HOME")
    if explicit:
        return Path(explicit).expanduser()
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if sdir:
        p = Path(sdir).expanduser()
        if p.name == "sessions":
            return p.parent
    return None


# ---- event-bus subscriber ------------------------------------------

# Per-agent registration state (keyed by agent home path) so
# `subscribe_for_sessions()` is idempotent across multiple calls.
_REGISTERED: set[str] = set()


def subscribe_for_sessions(home: Path, *, quiet_seconds: float = 0.5) -> bool:
    """Wire `session_saved` → `SessionIndex.index_session_file()` on
    the process-wide event bus.

    Debounce is short (0.5s default) — saves are cheap to index and
    we want recent turns searchable as quickly as possible. The bus's
    late-publish-merging serializes per-subscriber so two saves of
    the same session can't run the indexer concurrently.

    First-subscribe also runs `reindex_all()` once so an agent that
    has been running for months without an index gets backfilled
    on the next heartbeat tick.

    Returns True iff newly subscribed.
    """
    key = str(Path(home).resolve())
    if key in _REGISTERED:
        return False

    async def handler(payload: dict[str, Any]) -> None:
        ev_home = (payload or {}).get("agent_home", "")
        try:
            if ev_home and Path(ev_home).resolve() != Path(home).resolve():
                return
        except Exception:  # noqa: BLE001
            return
        # payload carries ``session_hash`` directly; tolerate the
        # legacy ``path`` (a ``<sid>.jsonl`` path) too.
        sid = (payload or {}).get("session_hash", "")
        if not sid:
            path_str = (payload or {}).get("path", "")
            if path_str:
                sid = Path(path_str).stem
        if not sid:
            return
        try:
            idx = SessionIndex(Path(home))
            n = idx.tail(str(sid))
            _log.debug("session_index: tailed %d event(s) for %s", n, sid)
        except Exception:  # noqa: BLE001
            _log.exception("session_index handler crashed for %s", sid)

    from rtxclaw_core.event_bus import get_bus
    bus = get_bus()
    bus.subscribe(
        "session_saved", handler,
        quiet_seconds=quiet_seconds,
        name=f"session_index[{Path(home).name}]",
    )
    _REGISTERED.add(key)
    # First-subscribe backfill.
    try:
        SessionIndex(Path(home)).reindex_all()
    except Exception:  # noqa: BLE001
        _log.exception("session_index: backfill error for %s", home)
    return True


# Back-compat alias — earlier code (heartbeat.py) imports the old
# name. Keeping both spellings avoids touching unrelated wiring.
subscribe_for_agent = subscribe_for_sessions


# ---- DDL ------------------------------------------------------------

SCHEMA_USER_VERSION = 2

# Full sessions_meta column set. Used both to CREATE a fresh table
# and to drive the additive ALTER-TABLE migration on existing DBs
# (``_apply_migrations``). Order: (name, sql_type_with_default).
_SESSIONS_META_COLUMNS: list[tuple[str, str]] = [
    # identity (immutable after session_started)
    ("session_hash", "TEXT PRIMARY KEY"),
    ("created_at", "TEXT NOT NULL DEFAULT ''"),
    ("agent_name", "TEXT NOT NULL DEFAULT ''"),
    ("engine", "TEXT NOT NULL DEFAULT ''"),
    # Parent rtxclaw session id when this session is a subagent (an
    # agent spawned by another session via Agent / BatchAgent /
    # delegate_*). Empty for top-level sessions. Folded from the
    # ``session_started`` header; lets queries walk the parent↔child
    # subagent tree without parsing the loose ``delegate_*`` sidecars.
    ("parent_session_id", "TEXT NOT NULL DEFAULT ''"),
    # The engine's OWN CLI session/resume token (claude/codex/antigravity
    # session id) for CLI-engine sessions — the rtxclaw↔engine session
    # link. Folded from a `header_update` at TurnDone; empty for
    # local-LLM sessions. Mutable (set once the first CLI turn lands).
    ("engine_session_id", "TEXT NOT NULL DEFAULT ''"),
    ("workspace_cwd", "TEXT NOT NULL DEFAULT ''"),
    ("workspace_origin", "TEXT NOT NULL DEFAULT ''"),   # was `frontend`
    ("schema_version", "TEXT NOT NULL DEFAULT '1'"),
    # mutable session-config
    ("title", "TEXT NOT NULL DEFAULT ''"),
    ("model", "TEXT NOT NULL DEFAULT ''"),
    ("endpoint", "TEXT NOT NULL DEFAULT ''"),
    ("backend", "TEXT NOT NULL DEFAULT ''"),
    ("context_window", "INTEGER NOT NULL DEFAULT 0"),
    ("system_mode", "TEXT NOT NULL DEFAULT ''"),
    ("reasoning_visibility", "TEXT NOT NULL DEFAULT 'off'"),
    ("tool_output_visible", "INTEGER NOT NULL DEFAULT 0"),
    ("persist_reasoning_traces", "INTEGER NOT NULL DEFAULT 1"),
    ("persist_tool_result_bodies", "INTEGER NOT NULL DEFAULT 1"),
    # system prompt
    ("system_prompt", "TEXT NOT NULL DEFAULT ''"),
    ("system_prompt_sha256", "TEXT NOT NULL DEFAULT ''"),
    # mutable session-state
    ("pinned_facts", "TEXT NOT NULL DEFAULT '[]'"),
    ("compaction_count", "INTEGER NOT NULL DEFAULT 0"),
    ("compaction_summary", "TEXT NOT NULL DEFAULT ''"),
    ("memory_flush_compaction_count", "INTEGER NOT NULL DEFAULT -1"),
    ("last_memory_flush_at", "TEXT NOT NULL DEFAULT ''"),
    ("last_turn_idx", "INTEGER NOT NULL DEFAULT -1"),
    ("last_turn_ts", "INTEGER NOT NULL DEFAULT 0"),
    # live streaming snapshot (NULL/empty between turns)
    ("live_turn_idx", "INTEGER"),
    ("live_round_idx", "INTEGER"),
    ("live_started_at", "TEXT"),
    ("live_content_so_far", "TEXT NOT NULL DEFAULT ''"),
    ("live_thinking_so_far", "TEXT NOT NULL DEFAULT ''"),
    ("live_tool_calls_so_far", "TEXT NOT NULL DEFAULT '[]'"),
    ("live_last_event_offset", "INTEGER NOT NULL DEFAULT 0"),
    # indexer cursor + bookkeeping
    ("indexed_bytes", "INTEGER NOT NULL DEFAULT 0"),
    ("updated_at", "INTEGER NOT NULL DEFAULT 0"),
]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions_meta (
{cols}
);
CREATE INDEX IF NOT EXISTS idx_sessions_meta_agent
  ON sessions_meta(agent_name);
CREATE INDEX IF NOT EXISTS idx_sessions_meta_last_turn_ts
  ON sessions_meta(last_turn_ts DESC);

CREATE TABLE IF NOT EXISTS turns (
  rowid         INTEGER PRIMARY KEY AUTOINCREMENT,
  session_hash  TEXT NOT NULL,
  turn_idx      INTEGER NOT NULL,
  combined_text TEXT NOT NULL,
  ts            INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_hash);
CREATE INDEX IF NOT EXISTS idx_turns_ts      ON turns(ts);
CREATE UNIQUE INDEX IF NOT EXISTS idx_turns_session_turn
  ON turns(session_hash, turn_idx);

CREATE VIRTUAL TABLE IF NOT EXISTS turns_fts USING fts5(
  combined_text,
  session_hash UNINDEXED,
  turn_idx     UNINDEXED,
  tokenize='unicode61'
);

-- Structured per-turn events for self-improvement queries
-- (fine-tune dataset extraction, regression tests, incident triage).
-- projected from JSONL events by ``EventProjector.apply`` inside
-- the writer's transaction. ``UNIQUE(session_hash, turn_idx, kind,
-- payload_hash)`` + INSERT-OR-IGNORE makes re-tail idempotent.
CREATE TABLE IF NOT EXISTS turn_events (
  rowid         INTEGER PRIMARY KEY AUTOINCREMENT,
  session_hash  TEXT NOT NULL,
  turn_idx      INTEGER NOT NULL,
  kind          TEXT NOT NULL,
  ts            INTEGER NOT NULL,
  payload_json  TEXT NOT NULL DEFAULT '{{}}',
  payload_hash  TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_turn_events_kind_ts
  ON turn_events(kind, ts DESC);
CREATE INDEX IF NOT EXISTS idx_turn_events_session
  ON turn_events(session_hash, turn_idx);
CREATE UNIQUE INDEX IF NOT EXISTS idx_turn_events_dedup
  ON turn_events(session_hash, turn_idx, kind, payload_hash);
""".format(
    cols=",\n".join(f"  {name:<30} {decl}" for name, decl in _SESSIONS_META_COLUMNS)
)


# ---- connection + schema (module-level so SessionWriter shares them) -


def connect_sessions_db(db_path: Any) -> sqlite3.Connection:
    """Open a WAL-mode connection to a session ``sessions.db``.

    Shared by :class:`SessionIndex` and ``session_writer.SessionWriter``
    so both speak to the db with identical pragmas. ``wal_autocheckpoint``
    is bounded so the per-delta UPDATE cadence doesn't grow the ``-wal``
    file without limit (the spec, §7.5).
    """
    # ``check_same_thread=False``: a ``SessionWriter`` may be driven from
    # a different thread than the one that opened its connection. All
    # access to a given connection is serialised by the writer's RLock
    # (in-process) and the per-session flock (cross-process), so no two
    # threads ever touch the same connection concurrently.
    con = sqlite3.connect(str(db_path), check_same_thread=False)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA temp_store=MEMORY")
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA wal_autocheckpoint=400")
        # Explicit busy timeout so a long lock-hold on one session (a
        # multi-MB model_input append) doesn't SQLITE_BUSY-abort another
        # session's BEGIN IMMEDIATE on the shared db. (review: Codex S2)
        con.execute("PRAGMA busy_timeout=15000")
    except sqlite3.DatabaseError:
        pass
    return con


def ensure_schema(db_path: Any) -> None:
    """Create the schema if absent and run additive migrations.

    Idempotent. Safe to call on every writer/index construction.
    """
    con = connect_sessions_db(db_path)
    try:
        # Migrate FIRST so a legacy table gains the columns before
        # ``_SCHEMA`` creates indexes that reference them. On a fresh DB
        # the migration is a no-op (no table yet) and ``_SCHEMA`` creates
        # the full shape.
        _apply_migrations(con)
        con.executescript(_SCHEMA)
        con.execute(f"PRAGMA user_version={SCHEMA_USER_VERSION}")
        con.commit()
    finally:
        con.close()


def _apply_migrations(con: sqlite3.Connection) -> None:
    """Bring an existing ``sessions_meta`` up to the column set.

    SQLite can't ``ALTER TABLE ... ADD COLUMN`` with a non-constant
    default, but all defaults are constants, so an additive sweep
    works. The legacy ``frontend`` column (pre-) is preserved in
    place (SQLite can't cleanly drop columns pre-3.35) and its value
    copied into the new ``workspace_origin`` once.
    """
    cols = {row[1] for row in con.execute("PRAGMA table_info(sessions_meta)")}
    if not cols:
        return  # table didn't exist; _SCHEMA already created it fresh
    had_workspace_origin = "workspace_origin" in cols
    for name, decl in _SESSIONS_META_COLUMNS:
        if name == "session_hash" or name in cols:
            continue
        # Strip PRIMARY KEY (only valid at CREATE); keep type+default.
        add_decl = decl.replace(" PRIMARY KEY", "")
        con.execute(f"ALTER TABLE sessions_meta ADD COLUMN {name} {add_decl}")
    # One-time copy frontend -> workspace_origin for pre-rows.
    if "frontend" in cols and not had_workspace_origin:
        con.execute(
            "UPDATE sessions_meta SET workspace_origin = frontend "
            "WHERE workspace_origin = '' AND frontend <> ''"
        )
    # turn_events.payload_hash (added here for the dedup UNIQUE index).
    te_cols = {row[1] for row in con.execute("PRAGMA table_info(turn_events)")}
    if te_cols and "payload_hash" not in te_cols:
        con.execute(
            "ALTER TABLE turn_events ADD COLUMN payload_hash TEXT NOT NULL DEFAULT ''"
        )
        # Backfill the hash from existing payloads, THEN drop duplicate
        # rows, so the UNIQUE(session_hash,turn_idx,kind,payload_hash)
        # index in _SCHEMA can build. A pre-turn that dispatched ≥2
        # tools has multiple (sid,turn,'tool_call') rows that would all
        # carry payload_hash='' and collide. (review: Codex C1 — this
        # crashed ensure_schema on any populated existing sessions.db.)
        rows = con.execute(
            "SELECT rowid, payload_json FROM turn_events"
        ).fetchall()
        for r in rows:
            con.execute(
                "UPDATE turn_events SET payload_hash=? WHERE rowid=?",
                (_payload_hash(str(r[1] or "{}")), r[0]),
            )
        con.execute(
            "DELETE FROM turn_events WHERE rowid NOT IN ("
            "  SELECT MIN(rowid) FROM turn_events "
            "  GROUP BY session_hash, turn_idx, kind, payload_hash)"
        )


# ---- event projection (JSONL event -> sessions.db rows) -------------


# Indexable lifecycle event kinds -> turn_events.kind.
_LIFECYCLE_INDEX_KINDS = {
    "loop_detected": "loop",
    "nudge": "nudge",
    "distill": "distill",
    "compaction": "compaction",
    "pause_resume": "pause_resume",
    "approval_decision": "approval_decision",
    "hook_outcome": "hook_outcome",
}


def _payload_hash(payload_json: str) -> str:
    import hashlib
    return hashlib.sha1(payload_json.encode("utf-8")).hexdigest()[:16]


class EventProjector:
    """Projects JSONL events into ``sessions.db`` rows, in order.

    Stateful: tracks each in-flight turn's user + accumulated content so
    ``turn_ended`` can build the FTS ``combined_text`` without a cross-
    event SQL read. One instance per writer (live path) and a fresh
    instance per ``tail``/``rebuild`` replay. ``apply`` runs inside the
    caller's open transaction; it never commits.
    """

    def __init__(self) -> None:
        # turn_idx -> {"user": str, "content": str}
        self._scratch: dict[int, dict[str, str]] = {}

    def apply(
        self, con: sqlite3.Connection, sid: str, event: dict, end_offset: int
    ) -> None:
        etype = str(event.get("type") or "")
        now_ms = int(time.time() * 1000)
        # The cursor advances for EVERY event so a re-tail resumes past
        # already-applied lines.
        con.execute(
            "UPDATE sessions_meta SET indexed_bytes=?, updated_at=? "
            "WHERE session_hash=?",
            (int(end_offset), now_ms, sid),
        )
        if etype == "session_started":
            self._upsert_header_from_started(con, sid, event, now_ms, end_offset)
            return
        ti = event.get("turn_idx")

        if etype == "turn_started":
            self._scratch[int(ti)] = {
                "user": _extract_user_text(event.get("user")),
                "content": "",
            }
            con.execute(
                "UPDATE sessions_meta SET live_turn_idx=?, live_round_idx=NULL, "
                "live_started_at=?, live_content_so_far='', "
                "live_thinking_so_far='', live_tool_calls_so_far='[]', "
                "live_last_event_offset=? WHERE session_hash=?",
                (int(ti), str(event.get("ts") or ""), int(end_offset), sid),
            )
            # Derive title from the first turn if still untitled.
            row = con.execute(
                "SELECT title FROM sessions_meta WHERE session_hash=?", (sid,)
            ).fetchone()
            if row is not None:
                cur_title = row["title"] if not isinstance(row, tuple) else row[0]
                if not cur_title or str(cur_title).startswith("untitled-"):
                    con.execute(
                        "UPDATE sessions_meta SET title=? WHERE session_hash=?",
                        (_derive_title(event.get("user")), sid),
                    )
            return

        if etype == "round_started":
            con.execute(
                "UPDATE sessions_meta SET live_round_idx=?, live_last_event_offset=? "
                "WHERE session_hash=?",
                (int(event.get("round_idx") or 0), int(end_offset), sid),
            )
            return

        if etype == "text_delta":
            self._scratch.setdefault(int(ti), {"user": "", "content": ""})
            self._scratch[int(ti)]["content"] += str(event.get("delta") or "")
            # Cap the live column to a trailing window so a long turn
            # doesn't rewrite an ever-growing TEXT value per delta
            # (O(n^2) WAL churn). The full content lives in the JSONL;
            # the live column only feeds the "what's it typing now"
            # poll. (review: Gemini perf)
            con.execute(
                "UPDATE sessions_meta SET "
                "live_content_so_far = substr(live_content_so_far || ?, ?), "
                "live_last_event_offset=? WHERE session_hash=?",
                (str(event.get("delta") or ""), -_LIVE_SNAPSHOT_CAP,
                 int(end_offset), sid),
            )
            return

        if etype == "thinking_delta":
            con.execute(
                "UPDATE sessions_meta SET "
                "live_thinking_so_far = substr(live_thinking_so_far || ?, ?), "
                "live_last_event_offset=? WHERE session_hash=?",
                (str(event.get("delta") or ""), -_LIVE_SNAPSHOT_CAP,
                 int(end_offset), sid),
            )
            return

        if etype == "tool_call":
            self._append_live_tool_call(con, sid, event, end_offset)
            self._index_event(con, sid, ti, "tool_call", {
                "call_id": str(event.get("call_id") or ""),
                "name": str(event.get("name") or ""),
                "arguments": _cap_args(event.get("arguments") or {}),
                "started_at": str(event.get("started_at") or ""),
            }, now_ms)
            return

        if etype == "tool_result_meta":
            if not event.get("ok"):
                self._index_event(con, sid, ti, "tool_result_fail", {
                    "call_id": str(event.get("call_id") or ""),
                    "content_chars": int(event.get("content_chars") or 0),
                    "ended_at": str(event.get("ended_at") or ""),
                }, now_ms)
            con.execute(
                "UPDATE sessions_meta SET live_last_event_offset=? WHERE session_hash=?",
                (int(end_offset), sid),
            )
            return

        if etype == "round_ended":
            finish = str(event.get("finish_reason") or "")
            metrics = event.get("metrics") or {}
            if finish or metrics.get("loop_detected"):
                self._index_event(con, sid, ti, "finish", {
                    "finish_reason": finish,
                    "loop_detected": bool(metrics.get("loop_detected")),
                    "round_idx": event.get("round_idx"),
                }, now_ms)
            return

        if etype == "turn_ended":
            self._on_turn_ended(con, sid, event, now_ms)
            return

        if etype == "header_update":
            self._apply_header_patch(con, sid, event.get("patch") or {})
            return

        if etype in _LIFECYCLE_INDEX_KINDS:
            payload = {k: v for k, v in event.items()
                       if k not in ("v", "ts", "type", "engine")}
            self._index_event(
                con, sid, ti, _LIFECYCLE_INDEX_KINDS[etype], payload, now_ms,
            )
            return
        # session_closed and anything else: cursor already advanced.

    # -- helpers --

    def _upsert_header_from_started(self, con, sid, event, now_ms, end_offset):
        cols = [name for name, _ in _SESSIONS_META_COLUMNS]
        vals: dict[str, Any] = {}
        for name in cols:
            if name in event:
                v = event[name]
                # Defense-in-depth: never let a (re-)emitted
                # ``session_started`` clobber an already-populated identity
                # field with an empty value. The ON CONFLICT UPDATE below
                # would otherwise blank a good agent_name / engine /
                # created_at if some session-creator emits a second
                # ``session_started`` with those unset. Mirrors the same
                # guard already in ``_apply_header_patch`` — this is the
                # layer that makes the "blank attribution can never
                # self-heal" bug class impossible regardless of which
                # creator runs. (review: codex 2026-05-20)
                if name in ("engine", "created_at", "agent_name") and not v:
                    continue
                if name == "pinned_facts" and not isinstance(v, str):
                    v = json.dumps(v, ensure_ascii=False)
                if isinstance(v, bool):
                    v = 1 if v else 0
                vals[name] = v
        vals["session_hash"] = sid
        vals.setdefault("schema_version", str(event.get("v") or "1"))
        # Cursor advances to the end of THIS line so a re-tail resumes
        # past it (review: Codex C3 / Gemini — the old code read a
        # nonexistent ``_end_offset`` key and clobbered this to 0).
        vals["indexed_bytes"] = int(end_offset)
        vals["updated_at"] = now_ms
        colnames = list(vals.keys())
        placeholders = ",".join("?" for _ in colnames)
        updates = ",".join(f"{c}=excluded.{c}" for c in colnames if c != "session_hash")
        con.execute(
            f"INSERT INTO sessions_meta({','.join(colnames)}) "
            f"VALUES ({placeholders}) "
            f"ON CONFLICT(session_hash) DO UPDATE SET {updates}",
            tuple(vals[c] for c in colnames),
        )

    def _apply_header_patch(self, con, sid, patch: dict):
        valid = {name for name, _ in _SESSIONS_META_COLUMNS} - {"session_hash"}
        sets = []
        args = []
        for k, v in patch.items():
            if k not in valid:
                continue
            # Never let a header_update clobber a real (turn-derived)
            # title with the in-memory ``untitled-…`` placeholder — the
            # in-memory Session.title may still be the placeholder when a
            # config mutation triggers save(), but the projector already
            # derived the title from the first turn.
            if k == "title" and str(v or "").startswith("untitled-"):
                continue
            # Likewise don't overwrite a known engine/created_at with an
            # empty value (ACP new_session doesn't stamp engine).
            if k in ("engine", "created_at", "agent_name") and not v:
                continue
            if k == "pinned_facts" and not isinstance(v, str):
                v = json.dumps(v, ensure_ascii=False)
            if isinstance(v, bool):
                v = 1 if v else 0
            sets.append(f"{k}=?")
            args.append(v)
        if not sets:
            return
        args.append(sid)
        con.execute(
            f"UPDATE sessions_meta SET {','.join(sets)} WHERE session_hash=?",
            tuple(args),
        )

    def _append_live_tool_call(self, con, sid, event, end_offset):
        row = con.execute(
            "SELECT live_tool_calls_so_far FROM sessions_meta WHERE session_hash=?",
            (sid,),
        ).fetchone()
        cur = "[]"
        if row is not None:
            cur = (row["live_tool_calls_so_far"] if not isinstance(row, tuple) else row[0]) or "[]"
        try:
            arr = json.loads(cur)
            if not isinstance(arr, list):
                arr = []
        except (ValueError, TypeError):
            arr = []
        arr.append({
            "call_id": str(event.get("call_id") or ""),
            "name": str(event.get("name") or ""),
            "arguments": event.get("arguments") or {},
            "started_at": str(event.get("started_at") or ""),
        })
        con.execute(
            "UPDATE sessions_meta SET live_tool_calls_so_far=?, "
            "live_last_event_offset=? WHERE session_hash=?",
            (json.dumps(arr, ensure_ascii=False), int(end_offset), sid),
        )

    def _on_turn_ended(self, con, sid, event, now_ms):
        ti = int(event.get("turn_idx") or 0)
        scratch = self._scratch.pop(ti, {"user": "", "content": ""})
        user_text = scratch.get("user") or _extract_user_text(event.get("user"))
        final = event.get("final_content")
        content = final if final is not None else scratch.get("content", "")
        combined = _combine_turn(user_text, content or "")
        ts = _iso_to_ms(event.get("ts")) or now_ms
        if combined.strip():
            con.execute(
                "INSERT INTO turns(session_hash, turn_idx, combined_text, ts) "
                "VALUES (?,?,?,?) "
                "ON CONFLICT(session_hash, turn_idx) DO UPDATE SET "
                "combined_text=excluded.combined_text, ts=excluded.ts",
                (sid, ti, combined, ts),
            )
            con.execute(
                "DELETE FROM turns_fts WHERE session_hash=? AND turn_idx=?",
                (sid, ti),
            )
            con.execute(
                "INSERT INTO turns_fts(combined_text, session_hash, turn_idx) "
                "VALUES (?,?,?)",
                (combined, sid, ti),
            )
        # turn_metrics index row.
        self._index_event(con, sid, ti, "turn_metrics", {
            "aborted": bool(event.get("aborted")),
            "error": event.get("error"),
            "error_classification": event.get("error_classification") or "",
            "metrics": event.get("metrics") or {},
        }, now_ms)
        # A discrete ``error`` event row when the turn errored or was
        # aborted, so health/forensics queries (cmd_health) can count
        # them by kind. (review: Codex S2 — projector never emitted
        # 'error' so health under-reported.)
        if event.get("error") or event.get("aborted"):
            self._index_event(con, sid, ti, "error", {
                "message": str(event.get("error") or "")[:1000],
                "classification": event.get("error_classification") or "",
                "aborted": bool(event.get("aborted")),
            }, now_ms)
        # Clear live + advance last_turn_*.
        con.execute(
            "UPDATE sessions_meta SET live_turn_idx=NULL, live_round_idx=NULL, "
            "live_started_at=NULL, live_content_so_far='', live_thinking_so_far='', "
            "live_tool_calls_so_far='[]', last_turn_idx=?, last_turn_ts=? "
            "WHERE session_hash=?",
            (ti, ts, sid),
        )
        # Backfill the header engine from the turn when the session row
        # was created without one (ACP new_session doesn't stamp engine;
        # per-turn events carry it).
        ev_engine = str(event.get("engine") or "")
        if ev_engine:
            con.execute(
                "UPDATE sessions_meta SET engine=? "
                "WHERE session_hash=? AND (engine='' OR engine IS NULL)",
                (ev_engine, sid),
            )

    def _index_event(self, con, sid, turn_idx, kind, payload, now_ms):
        pj = json.dumps(payload, ensure_ascii=False)
        con.execute(
            "INSERT OR IGNORE INTO turn_events"
            "(session_hash, turn_idx, kind, ts, payload_json, payload_hash) "
            "VALUES (?,?,?,?,?,?)",
            (sid, int(turn_idx or 0), kind, now_ms, pj, _payload_hash(pj)),
        )


# Live snapshot columns keep only a trailing window — the full content
# is in the JSONL; the live column only serves the realtime poll.
_LIVE_SNAPSHOT_CAP = 16000

_TOOL_ARGS_INDEX_CAP = 1000


def _cap_args(args: Any) -> Any:
    """Cap tool-call arguments for the INDEX column only. The full args
    live verbatim in the JSONL ``tool_call`` event."""
    try:
        dumped = json.dumps(args, ensure_ascii=False)
    except (TypeError, ValueError):
        dumped = str(args)
    if len(dumped) <= _TOOL_ARGS_INDEX_CAP:
        return args
    return {"_truncated": True, "_full_chars": len(dumped),
            "preview": dumped[:_TOOL_ARGS_INDEX_CAP]}


__all__ = [
    "DEFAULT_MAX_RESULTS",
    "DEFAULT_MIN_SCORE",
    "DEFAULT_SNIPPET_CHARS",
    "EventProjector",
    "RecallResult",
    "SessionIndex",
    "connect_sessions_db",
    "ensure_schema",
    "session_search",
    "subscribe_for_agent",
    "subscribe_for_sessions",
]
