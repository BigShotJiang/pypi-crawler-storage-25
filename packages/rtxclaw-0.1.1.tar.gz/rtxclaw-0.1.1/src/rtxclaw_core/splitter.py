from __future__ import annotations

DEFAULT_OPEN = "<think>"
DEFAULT_CLOSE = "</think>"


class ThinkSplitter:
    """Split a stream of `delta.content` text into thinking vs final-content text.

    Models without a dedicated `reasoning_content` field (vLLM Qwen3 family with
    a buggy reasoning parser, raw chat templates, etc.) often emit
    `<think>...</think>` inline in `delta.content`. This class buffers across
    chunks so partial tags spanning chunk boundaries split correctly.

    Tags are configurable so we can also parse Gemma's `<thought>...</thought>`
    pattern (vLLM `--reasoning-parser gemma4`) when it leaks back into
    `delta.content`. Defaults stay `<think>` / `</think>` for backward compat.
    """

    def __init__(
        self,
        open_tag: str = DEFAULT_OPEN,
        close_tag: str = DEFAULT_CLOSE,
        *,
        in_think: bool = False,
    ) -> None:
        self._open = open_tag
        self._close = close_tag
        self._hold = max(len(open_tag), len(close_tag)) - 1
        self._buf = ""
        # `in_think=True` lets callers prime the splitter when the prompt
        # was prefilled with the open tag (Gemma 4 thinking pattern) so
        # the model's first output token is already inside a thought block.
        self._in_think = in_think

    def feed(self, text: str) -> tuple[str, str]:
        """Consume a chunk; return (thinking_text, content_text) safe to emit now."""
        self._buf += text
        thinking: list[str] = []
        content: list[str] = []
        while True:
            if self._in_think:
                end = self._buf.find(self._close)
                if end == -1:
                    safe = max(0, len(self._buf) - self._hold)
                    if safe:
                        thinking.append(self._buf[:safe])
                        self._buf = self._buf[safe:]
                    break
                thinking.append(self._buf[:end])
                self._buf = self._buf[end + len(self._close):]
                self._in_think = False
            else:
                start = self._buf.find(self._open)
                if start == -1:
                    safe = max(0, len(self._buf) - self._hold)
                    if safe:
                        content.append(self._buf[:safe])
                        self._buf = self._buf[safe:]
                    break
                content.append(self._buf[:start])
                self._buf = self._buf[start + len(self._open):]
                self._in_think = True
        return "".join(thinking), "".join(content)

    def flush(self) -> tuple[str, str]:
        """Drain the buffer when the stream ends."""
        if not self._buf:
            return "", ""
        if self._in_think:
            out = self._buf
            self._buf = ""
            return out, ""
        out = self._buf
        self._buf = ""
        return "", out
