"""Write side of the session log — the single sink for every engine.

``SessionWriter`` owns, for one session:

* the append-only ``<sid>.jsonl`` event log,
* the per-session ``.<sid>.lock`` flock,
* a connection to the shared ``sessions.db`` (materialised header +
  live snapshot + FTS index).

Every engine and every header mutator goes through this class. Direct
``Session.add_turn`` / ``Session.save`` / raw ``path.write_text`` on a
session file is forbidden post-cutover (the spec, §7).

Per-event critical section (the flock serialises writers; the kernel
serialises nothing on its own for >PIPE_BUF appends, so the flock IS
the atomicity primitive):

    acquire .<sid>.lock LOCK_EX   (fstat-verify inode; reopen if swept)
      os.write(jsonl_fd, "<crc8> <json>\\n")   # single write(2)
      if fsync_mode == always or boundary-event: os.fsync(jsonl_fd)
      BEGIN IMMEDIATE on sessions.db
        EventProjector.apply(con, sid, event, end_offset)   # §8 projection
      COMMIT
      fsync(sessions_dir_fd)        # parent-dir fsync for create/rename durability
    release lock

JSONL write+fsync happens BEFORE the SQL commit, so a crash leaves the
JSONL ahead of ``sessions_meta`` but never behind; ``reconcile_on_open``
repairs the db from the JSONL on the next writer start.

Threading: synchronous, guarded by a re-entrant in-process lock plus the
flock. Delta events (``text_delta`` / ``thinking_delta``) are debounced
in-memory and flushed when (a) ``flush_ms`` has elapsed since the first
buffered chunk, (b) the turn/round changes, or (c) any non-delta event
arrives. (The spec's separate writer-thread + bounded queue for
backpressure is a documented deferral — today's runtime already does
synchronous fsync in the loop, so this matches the existing threading
model; the debounce already bounds write frequency.)
"""
from __future__ import annotations

import fcntl
import os
import threading
import time
from collections import OrderedDict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from rtxclaw_core.secrets_scrubber import scrub_value
from rtxclaw_core.session_index import EventProjector, SessionIndex
from rtxclaw_core.session_reader import SCHEMA_VERSION, encode_line


# Events that always fsync the JSONL even in ``boundaries`` mode —
# anything whose loss would break recovery or lose a structured signal.
_FSYNC_BOUNDARY_EVENTS = frozenset({
    "session_started", "turn_started", "round_started", "round_ended",
    "turn_ended", "tool_call", "tool_result", "header_update",
    "session_closed", "loop_detected", "nudge", "distill", "compaction",
    "pause_resume", "approval_decision", "hook_outcome",
})


def _now_iso_ms() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _now_ms() -> int:
    return int(time.time() * 1000)


class SessionWriter:
    def __init__(
        self,
        sessions_dir: Path,
        sid: str,
        *,
        engine: str = "",
        fsync_mode: Optional[str] = None,
        flush_ms: Optional[int] = None,
    ) -> None:
        self.sessions_dir = Path(sessions_dir)
        self.sid = str(sid)
        self.engine = engine
        self.jsonl_path = self.sessions_dir / f"{self.sid}.jsonl"
        self.lock_path = self.sessions_dir / f".{self.sid}.lock"
        self.fsync_mode = (
            fsync_mode
            or os.environ.get("RTXCLAW_LOG_FSYNC", "boundaries")
        ).strip().lower()
        try:
            self.flush_ms = int(
                flush_ms if flush_ms is not None
                else os.environ.get("RTXCLAW_LOG_FLUSH_MS", "100")
            )
        except (TypeError, ValueError):
            self.flush_ms = 100

        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        # Ensure the schema exists / is migrated before any write.
        self._index = SessionIndex(self.sessions_dir.parent)
        self._projector = EventProjector()

        self._rlock = threading.RLock()
        self._jsonl_fd = -1
        self._lock_fd = -1
        self._dir_fd = -1
        self._dir_synced = False    # parent-dir fsync only needed on create
        self._poison = False
        # Current turn's user prompt, cached from turn_started so
        # turn_ended ALWAYS carries it — the FTS combined_text then
        # pairs user+content even when a fresh projector (post-restart
        # tail) has no scratch for this turn. (review: Gemini #3)
        self._cur_user: Any = ""
        # Current turn's permission mode, cached from turn_started so the
        # terminal turn_ended record self-describes the mode too — the
        # fine-tune pipeline wants permission_mode on EVERY TurnRecord
        # (see agents/session_log.TurnRecord), not only inferred from the
        # turn_started event during reconstruction.
        self._cur_permission_mode: str = ""
        # Incremental-stream state for the facade. The facade hands us
        # the FULL accumulated content/thinking/tool lists on each flush;
        # we diff against what's already on disk and append only the new
        # suffix as a JSONL delta — realtime streaming straight to the
        # file, no SQL on the hot path.
        self._open_turn: Optional[int] = None
        self._emitted_content_len = 0
        self._emitted_thinking_len = 0
        self._emitted_tool_calls = 0
        self._emitted_tool_results = 0

        # Privacy gates — refreshed from sessions_meta on first use or
        # set by session_started's header.
        self._persist_thinking = True
        self._persist_tool_bodies = True
        self._gates_loaded = False

        # Delta debounce buffers.
        self._buf_content: list[str] = []
        self._buf_thinking: list[str] = []
        self._buf_turn: Optional[int] = None
        self._buf_round: Optional[int] = None
        self._buf_started_ms: Optional[int] = None

    # ---- public API: lifecycle --------------------------------------

    def session_started(self, header: dict[str, Any]) -> None:
        """Stamp the initial header. Writes the ``session_started`` event
        (full header, self-describing) and INSERTs the sessions_meta row.
        """
        hdr = dict(header or {})
        self.engine = self.engine or str(hdr.get("engine") or "")
        self._persist_thinking = bool(hdr.get("persist_reasoning_traces", True))
        self._persist_tool_bodies = bool(hdr.get("persist_tool_result_bodies", True))
        self._gates_loaded = True
        ev = {"type": "session_started"}
        ev.update(hdr)
        self._emit(ev)

    def turn_started(
        self, *, turn_idx: int, user: Any, permission_mode: str = "",
        cwd: str = "", attachments: Optional[list] = None,
    ) -> None:
        self._flush_deltas()
        self._cur_user = user
        self._cur_permission_mode = permission_mode or ""
        ev: dict[str, Any] = {
            "type": "turn_started", "turn_idx": int(turn_idx),
            "user": user, "permission_mode": permission_mode or "",
            "cwd": cwd or "",
        }
        if attachments:
            ev["attachments"] = attachments
        self._emit(ev)

    def round_started(
        self, *, turn_idx: int, round_idx: int, model_input: Optional[list] = None,
        effective_system_prompt: str = "", effective_system_prompt_sha256: str = "",
        effective_preamble: Optional[list] = None, upstream_endpoint: str = "",
        model: str = "", engine_session_id: str = "",
    ) -> None:
        self._flush_deltas()
        self._emit({
            "type": "round_started", "turn_idx": int(turn_idx),
            "round_idx": int(round_idx),
            "model_input": _strip_tool_msg_bodies(model_input or []),
            "effective_system_prompt": effective_system_prompt or "",
            "effective_system_prompt_sha256": effective_system_prompt_sha256 or "",
            "effective_preamble": list(effective_preamble or []),
            "upstream_endpoint": upstream_endpoint or "",
            "model": model or "", "engine_session_id": engine_session_id or "",
        })

    def text_delta(self, *, turn_idx: int, round_idx: int, chunk: str) -> None:
        self._buffer_delta("content", turn_idx, round_idx, chunk)

    def thinking_delta(self, *, turn_idx: int, round_idx: int, chunk: str) -> None:
        if not self._persist_thinking:
            return
        self._buffer_delta("thinking", turn_idx, round_idx, chunk)

    def tool_call(
        self, *, turn_idx: int, round_idx: int, call_id: str, name: str,
        arguments: Optional[dict] = None, raw_arguments: str = "",
        started_at: str = "",
    ) -> None:
        self._flush_deltas()
        self._emit({
            "type": "tool_call", "turn_idx": int(turn_idx),
            "round_idx": int(round_idx), "call_id": str(call_id),
            "name": str(name), "arguments": dict(arguments or {}),
            "raw_arguments": str(raw_arguments or ""),
            "started_at": started_at or "",
        })

    def tool_result(
        self, *, turn_idx: int, round_idx: int, call_id: str, ok: bool,
        content: str = "", content_chars: Optional[int] = None,
        ended_at: str = "",
    ) -> None:
        self._flush_deltas()
        n_chars = (
            content_chars if content_chars is not None
            else (len(content) if isinstance(content, str) else 0)
        )
        self._emit({
            "type": "tool_result_meta", "turn_idx": int(turn_idx),
            "round_idx": int(round_idx), "call_id": str(call_id),
            "ok": bool(ok), "ended_at": ended_at or "",
            "content_chars": int(n_chars),
        })
        if self._persist_tool_bodies and content:
            self._emit({
                "type": "tool_result", "turn_idx": int(turn_idx),
                "round_idx": int(round_idx), "call_id": str(call_id),
                "content": content,
            })

    def lifecycle(self, *, kind: str, payload: Optional[dict] = None,
                  turn_idx: Optional[int] = None,
                  round_idx: Optional[int] = None) -> None:
        """Emit a lifecycle event: loop_detected / nudge / distill /
        compaction / pause_resume / approval_decision / hook_outcome."""
        self._flush_deltas()
        ev: dict[str, Any] = {"type": str(kind)}
        if turn_idx is not None:
            ev["turn_idx"] = int(turn_idx)
        if round_idx is not None:
            ev["round_idx"] = int(round_idx)
        ev.update(dict(payload or {}))
        self._emit(ev)

    def round_ended(
        self, *, turn_idx: int, round_idx: int,
        metrics: Optional[dict] = None, finish_reason: str = "",
        tokenizer_id: str = "",
    ) -> None:
        self._flush_deltas()
        self._emit({
            "type": "round_ended", "turn_idx": int(turn_idx),
            "round_idx": int(round_idx), "metrics": dict(metrics or {}),
            "finish_reason": finish_reason or "", "tokenizer_id": tokenizer_id or "",
        })

    def turn_ended(
        self, *, turn_idx: int, user: Any = "", final_content: str = "",
        final_thinking: str = "", aborted: bool = False,
        error: Optional[str] = None, error_classification: str = "",
        metrics: Optional[dict] = None, permission_mode: str = "",
    ) -> dict[str, Any]:
        """Terminal turn event. Returns the materialised turn dict so the
        caller (observe_turn_memory) need not read ``session.turns``."""
        self._flush_deltas()
        # Always carry the user prompt (cached from turn_started) so the
        # FTS combined_text pairs user+content even when re-tailed by a
        # fresh projector after a restart. (review: Gemini #3)
        eff_user = user if user not in ("", None) else self._cur_user
        # Stamp the permission mode on the terminal record too (cached
        # from turn_started if the caller didn't repeat it) so the
        # durable TurnRecord self-describes the mode it ran under.
        eff_mode = permission_mode or self._cur_permission_mode or ""
        ev: dict[str, Any] = {
            "type": "turn_ended", "turn_idx": int(turn_idx),
            "user": eff_user,
            "permission_mode": eff_mode,
            "final_content": final_content or "",
            "aborted": bool(aborted), "error": error,
            "error_classification": error_classification or "",
            "metrics": dict(metrics or {}),
        }
        if self._persist_thinking:
            ev["final_thinking"] = final_thinking or ""
        self._emit(ev)
        self._cur_user = ""
        self._cur_permission_mode = ""
        # Scrub the returned dict too — it feeds observe_turn_memory,
        # a second on-disk corpus path that must not bypass the
        # scrubber. (review: Codex C4)
        from rtxclaw_core.secrets_scrubber import scrub_text, scrub_value
        return {
            "user": scrub_value(eff_user),
            "content": scrub_text(final_content or ""),
            "thinking": scrub_text(final_thinking or "") if self._persist_thinking else "",
            "aborted": bool(aborted), "error": scrub_text(error) if error else error,
            "metrics": scrub_value(dict(metrics or {})), "engine": self.engine,
        }

    def header_update(self, *, patch: dict[str, Any]) -> None:
        """Apply a header mutation: write the ``header_update`` event and
        UPDATE the matching sessions_meta columns (in the projector)."""
        self._flush_deltas()
        # Refresh local privacy gates if they changed.
        if "persist_reasoning_traces" in patch:
            self._persist_thinking = bool(patch["persist_reasoning_traces"])
        if "persist_tool_result_bodies" in patch:
            self._persist_tool_bodies = bool(patch["persist_tool_result_bodies"])
        self._emit({"type": "header_update", "patch": dict(patch or {})})

    def session_closed(self, *, reason: str = "") -> None:
        self._flush_deltas()
        self._emit({"type": "session_closed", "reason": reason or ""})

    def flush_deltas(self) -> None:
        self._flush_deltas()

    def reconcile_on_open(self) -> None:
        """Sync ``sessions_meta`` to the JSONL on (re)open.

        If the process died between a JSONL append and its SQL commit,
        ``sessions_meta`` is behind the file. Replaying the unindexed
        tail through THIS writer's projector both advances the cursor
        and re-seeds the projector's per-turn scratch (so an in-flight
        turn's user prompt survives into the FTS combined_text). Cheap
        no-op when the cursor is already at EOF. (review: Gemini #3,
        spec §11 reconcile_on_open.)
        """
        try:
            self._index.tail(self.sid, projector=self._projector)
        except Exception:  # noqa: BLE001
            pass

    def close(self) -> None:
        with self._rlock:
            try:
                self._flush_deltas_locked()
            except Exception:
                pass
            # Close ALL fds incl. the lock fd (review: Codex C2 — the
            # lock fd was leaked, exhausting the gateway's fd table).
            self._drop_lock_fd()
            for fd_attr in ("_jsonl_fd", "_dir_fd"):
                fd = getattr(self, fd_attr)
                if fd >= 0:
                    try:
                        os.close(fd)
                    except OSError:
                        pass
                    setattr(self, fd_attr, -1)

    # ---- internals --------------------------------------------------

    def _buffer_delta(self, channel: str, turn_idx: int, round_idx: int,
                      chunk: str) -> None:
        if not chunk:
            return
        with self._rlock:
            if self._buf_turn != turn_idx or self._buf_round != round_idx:
                self._flush_deltas_locked()
                self._buf_turn = turn_idx
                self._buf_round = round_idx
            if self._buf_started_ms is None:
                self._buf_started_ms = _now_ms()
            if channel == "content":
                self._buf_content.append(chunk)
            else:
                self._buf_thinking.append(chunk)
            if _now_ms() - self._buf_started_ms >= self.flush_ms:
                self._flush_deltas_locked()

    def _flush_deltas(self) -> None:
        with self._rlock:
            self._flush_deltas_locked()

    def _flush_deltas_locked(self) -> None:
        ti, ri = self._buf_turn, self._buf_round
        if self._buf_content:
            delta = "".join(self._buf_content)
            self._buf_content = []
            self._emit({
                "type": "text_delta", "turn_idx": ti, "round_idx": ri,
                "delta": delta,
            }, fsync=(self.fsync_mode == "always"))
        if self._buf_thinking:
            delta = "".join(self._buf_thinking)
            self._buf_thinking = []
            self._emit({
                "type": "thinking_delta", "turn_idx": ti, "round_idx": ri,
                "delta": delta,
            }, fsync=(self.fsync_mode == "always"))
        self._buf_started_ms = None

    def _emit(self, event: dict[str, Any], *, fsync: Optional[bool] = None) -> int:
        if self._poison:
            raise RuntimeError(f"SessionWriter[{self.sid}] is poisoned")
        event.setdefault("v", SCHEMA_VERSION)
        event.setdefault("ts", _now_iso_ms())
        if event.get("type") != "session_started":
            event.setdefault("engine", self.engine)
        safe = scrub_value(event)
        line = encode_line(safe)
        do_fsync = (
            fsync if fsync is not None
            else (self.fsync_mode == "always"
                  or event.get("type") in _FSYNC_BOUNDARY_EVENTS)
        )
        with self._rlock:
            self._acquire_flock()
            try:
                jfd = self._open_jsonl()
                _write_all(jfd, line)
                if do_fsync:
                    try:
                        os.fsync(jfd)
                    except OSError as e:
                        self._poison = True
                        raise RuntimeError(
                            f"SessionWriter[{self.sid}] fsync failed: {e}"
                        ) from e
                end_offset = os.lseek(jfd, 0, os.SEEK_CUR)
                self._fsync_dir()
            finally:
                self._release_flock()
        # The sessions.db index is NOT written on the realtime hot path
        # (per-token SQL was the perf problem). The JSONL is the durable
        # write target + source of truth; sessions.db is a derived index
        # rebuilt by lazily tailing the JSONL — driven by this bus
        # publish (debounced subscriber → SessionIndex.tail) and by
        # read-triggered tail(sid). Published AFTER the flock release so
        # a subscriber that tails immediately sees the committed bytes.
        self._publish_appended()
        return end_offset

    def _publish_appended(self) -> None:
        try:
            from rtxclaw_core.event_bus import get_bus
            agent_home = (
                self.sessions_dir.parent
                if self.sessions_dir.name == "sessions"
                else self.sessions_dir
            )
            get_bus().publish("session_saved", {
                "agent_home": str(agent_home),
                "session_hash": self.sid,
                "path": str(self.jsonl_path),
            })
        except Exception:  # noqa: BLE001
            pass

    def _open_jsonl(self) -> int:
        if self._jsonl_fd < 0:
            existed = self.jsonl_path.exists()
            self._jsonl_fd = os.open(
                self.jsonl_path,
                os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_CLOEXEC,
                0o600,
            )
            # A parent-dir fsync is only needed to make the file's
            # CREATE durable; pure appends don't change the dirent.
            # (review: Gemini perf — was fsync'ing the dir per event.)
            if not existed:
                self._dir_synced = False
        return self._jsonl_fd

    def _acquire_flock(self) -> None:
        # Open (lazily) and lock. After acquiring, verify the inode
        # hasn't been swept out from under us; if it has, reopen+relock.
        for _ in range(3):
            if self._lock_fd < 0:
                self._lock_fd = os.open(
                    self.lock_path, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC, 0o600
                )
            fcntl.flock(self._lock_fd, fcntl.LOCK_EX)
            try:
                disk = os.stat(self.lock_path)
                held = os.fstat(self._lock_fd)
            except FileNotFoundError:
                # Swept while held — drop and retry.
                self._drop_lock_fd()
                continue
            if (disk.st_ino, disk.st_dev) == (held.st_ino, held.st_dev):
                return
            # Inode changed underneath: release, reopen, retry.
            self._drop_lock_fd()
        # Best effort: proceed with whatever we have.
        if self._lock_fd < 0:
            self._lock_fd = os.open(
                self.lock_path, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC, 0o600
            )
            fcntl.flock(self._lock_fd, fcntl.LOCK_EX)

    def _drop_lock_fd(self) -> None:
        if self._lock_fd >= 0:
            try:
                fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
            except OSError:
                pass
            try:
                os.close(self._lock_fd)
            except OSError:
                pass
            self._lock_fd = -1

    def _release_flock(self) -> None:
        if self._lock_fd >= 0:
            try:
                fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
            except OSError:
                pass

    def _fsync_dir(self) -> None:
        # Only needed once, to make the JSONL file's directory entry
        # durable after create. Appends don't touch the dirent.
        if self._dir_synced:
            return
        try:
            if self._dir_fd < 0:
                self._dir_fd = os.open(self.sessions_dir, os.O_RDONLY | os.O_CLOEXEC)
            os.fsync(self._dir_fd)
            self._dir_synced = True
        except OSError:
            pass


    # ---- facade: incremental streaming (used by record_turn) --------

    def record_stream(
        self, *, turn_idx: int, user: Any, content: str = "",
        thinking: str = "", tool_calls: Optional[list] = None,
        tool_results: Optional[list] = None, terminal: bool = False,
        permission_mode: str = "", cwd: str = "", model: str = "",
        finish_reason: str = "", metrics: Optional[dict] = None,
        aborted: bool = False, error: Optional[str] = None,
        error_classification: str = "",
        engine_session_id: str = "",
        model_input_messages: Optional[list] = None,
        round_metrics: Optional[list] = None,
        effective_system_prompt: str = "",
        effective_system_prompt_sha256: str = "",
        effective_preamble: Optional[list] = None,
        upstream_endpoint: str = "",
        hook_outcomes: Optional[list] = None,
        approval_decisions: Optional[list] = None,
        compaction_events: Optional[list] = None,
        distill_events: Optional[list] = None,
        nudge_events: Optional[list] = None,
        pause_resume_log: Optional[list] = None,
    ) -> Optional[dict[str, Any]]:
        """Append the NEW suffix of an in-flight (or finished) turn.

        The facade hands the full accumulated ``content`` / ``thinking`` /
        tool lists on each flush; this diffs against what's already on
        disk and appends only the new part as JSONL deltas — realtime
        streaming straight to the file, no SQL. On the first flush of a
        turn it opens it (turn_started + round_started). When
        ``terminal`` it emits round_ended + turn_ended (carrying the
        replay-fidelity fields) and returns the materialised turn dict;
        otherwise returns ``None``.
        """
        with self._rlock:
            if self._open_turn != turn_idx:
                # New turn — flush any stale buffers, open it.
                self._open_turn = turn_idx
                self._emitted_content_len = 0
                self._emitted_thinking_len = 0
                self._emitted_tool_calls = 0
                self._emitted_tool_results = 0
                self.turn_started(
                    turn_idx=turn_idx, user=user,
                    permission_mode=permission_mode, cwd=cwd,
                )
                self.round_started(
                    turn_idx=turn_idx, round_idx=0,
                    model_input=model_input_messages or [],
                    effective_system_prompt=effective_system_prompt,
                    effective_system_prompt_sha256=effective_system_prompt_sha256,
                    effective_preamble=effective_preamble or [],
                    upstream_endpoint=upstream_endpoint, model=model,
                    engine_session_id=engine_session_id,
                )

            content = content or ""
            if len(content) > self._emitted_content_len:
                self.text_delta(
                    turn_idx=turn_idx, round_idx=0,
                    chunk=content[self._emitted_content_len:],
                )
                self._emitted_content_len = len(content)
            thinking = thinking or ""
            if self._persist_thinking and len(thinking) > self._emitted_thinking_len:
                self.thinking_delta(
                    turn_idx=turn_idx, round_idx=0,
                    chunk=thinking[self._emitted_thinking_len:],
                )
                self._emitted_thinking_len = len(thinking)

            tcs = list(tool_calls or [])
            for tc in tcs[self._emitted_tool_calls:]:
                if not isinstance(tc, dict):
                    continue
                self.tool_call(
                    turn_idx=turn_idx, round_idx=0,
                    call_id=str(tc.get("call_id") or ""),
                    name=str(tc.get("name") or ""),
                    arguments=tc.get("arguments") or {},
                    raw_arguments=str(tc.get("raw_arguments") or ""),
                    started_at=str(tc.get("started_at") or ""),
                )
            self._emitted_tool_calls = len(tcs)

            trs = list(tool_results or [])
            for tr in trs[self._emitted_tool_results:]:
                if not isinstance(tr, dict):
                    continue
                self.tool_result(
                    turn_idx=turn_idx, round_idx=0,
                    call_id=str(tr.get("call_id") or ""),
                    ok=bool(tr.get("ok")),
                    content=str(tr.get("content") or ""),
                    content_chars=tr.get("content_chars"),
                    ended_at=str(tr.get("ended_at") or ""),
                )
            self._emitted_tool_results = len(trs)

            if not terminal:
                return None

            for rm in (round_metrics or []):
                if not isinstance(rm, dict):
                    continue
                self.round_ended(
                    turn_idx=turn_idx, round_idx=int(rm.get("round_idx", 0) or 0),
                    metrics=rm, finish_reason=str(rm.get("finish_reason") or ""),
                    tokenizer_id=str(rm.get("tokenizer_id") or ""),
                )
            if not round_metrics:
                self.round_ended(
                    turn_idx=turn_idx, round_idx=0,
                    metrics=metrics or {}, finish_reason=finish_reason,
                )
            for ho in (hook_outcomes or []):
                self.lifecycle(kind="hook_outcome", payload=ho, turn_idx=turn_idx)
            for ad in (approval_decisions or []):
                self.lifecycle(kind="approval_decision", payload=ad, turn_idx=turn_idx)
            for cv in (compaction_events or []):
                self.lifecycle(kind="compaction", payload=cv, turn_idx=turn_idx)
            for dv in (distill_events or []):
                self.lifecycle(kind="distill", payload=dv, turn_idx=turn_idx)
            for nv in (nudge_events or []):
                self.lifecycle(kind="nudge", payload=nv, turn_idx=turn_idx)
            for pv in (pause_resume_log or []):
                self.lifecycle(kind="pause_resume", payload=pv, turn_idx=turn_idx)
            rec = self.turn_ended(
                turn_idx=turn_idx, user=user, final_content=content,
                final_thinking=thinking, aborted=aborted, error=error,
                error_classification=error_classification, metrics=metrics or {},
                permission_mode=permission_mode,
            )
            self._open_turn = None
            return rec

    def write_full_turn(self, **kw: Any) -> dict[str, Any]:
        """One-shot complete turn (tests / non-streaming callers).

        Thin wrapper over :meth:`record_stream` with ``terminal=True``.
        ``thinking`` is accepted as a kwarg alias for the stream's
        thinking channel; ``started_at`` / ``ended_at`` are ignored
        (event ``ts`` is authoritative).
        """
        kw.pop("started_at", None)
        kw.pop("ended_at", None)
        kw["terminal"] = True
        return self.record_stream(**kw)


# ---- process-wide writer registry -----------------------------------
#
# A SessionWriter holds an append fd + per-turn incremental-stream
# state, so it MUST persist across the many ``record_turn`` calls of
# one session (not be rebuilt per
# call — that would lose the projector scratch and reopen fds every
# event). Keyed by the resolved jsonl path.

_WRITERS: "OrderedDict[str, SessionWriter]" = OrderedDict()
_WRITERS_LOCK = threading.Lock()
# Cap the registry so a long-lived gateway serving many sessions doesn't
# leak fds (each writer holds jsonl + dir + lock fds). LRU-evict + close
# the least-recently-used beyond the cap. (review: Codex/Gemini C2.)
_WRITERS_MAX = int(os.environ.get("RTXCLAW_SESSION_WRITERS_MAX", "128"))


def get_session_writer(
    sessions_dir: Any, sid: str, *, engine: str = "",
) -> "SessionWriter":
    """Return a cached :class:`SessionWriter` for ``sid``, creating one
    on first use. Thread-safe. LRU-bounded."""
    key = str(Path(sessions_dir) / f"{sid}.jsonl")
    evicted: list["SessionWriter"] = []
    with _WRITERS_LOCK:
        w = _WRITERS.get(key)
        if w is None:
            w = SessionWriter(sessions_dir, sid, engine=engine)
            # Resuming an existing session: replay any unindexed tail so
            # sessions_meta + the projector scratch are current.
            if w.jsonl_path.exists():
                w.reconcile_on_open()
            _WRITERS[key] = w
            while len(_WRITERS) > _WRITERS_MAX:
                _, old = _WRITERS.popitem(last=False)
                evicted.append(old)
        else:
            _WRITERS.move_to_end(key)
            if engine and not w.engine:
                w.engine = engine
    # Close evicted writers OUTSIDE the registry lock (close takes the
    # writer's own rlock + flock; never nest under _WRITERS_LOCK).
    for old in evicted:
        try:
            old.close()
        except Exception:  # noqa: BLE001
            pass
    return w


def close_session_writer(sessions_dir: Any, sid: str) -> None:
    """Close + drop a cached writer (e.g. on session close)."""
    key = str(Path(sessions_dir) / f"{sid}.jsonl")
    with _WRITERS_LOCK:
        w = _WRITERS.pop(key, None)
    if w is not None:
        w.close()


def _write_all(fd: int, data: bytes) -> None:
    """Write every byte; loop on short writes (large lines > pipe buf)."""
    mv = memoryview(data)
    while mv:
        n = os.write(fd, mv)
        mv = mv[n:]


def _strip_tool_msg_bodies(msgs: list) -> list:
    """Stub ``role=tool`` message bodies inside a model_input list.

    Tool-result content is persisted (when enabled) via the dedicated
    ``tool_result`` event, not duplicated inside every round's
    model_input — the round event would otherwise carry the full tool
    output N times (once per subsequent round). Preserves the
    structural slot so SFT pipelines see "a tool result of N chars was
    here."
    """
    out: list = []
    for m in (msgs or []):
        if isinstance(m, dict) and str(m.get("role") or "") == "tool":
            content = m.get("content")
            stub = {
                "role": "tool",
                "content": "<<TOOL_RESULT_OMITTED>>",
                "content_chars": len(content) if isinstance(content, str) else 0,
            }
            if m.get("tool_call_id") is not None:
                stub["tool_call_id"] = m["tool_call_id"]
            if m.get("name") is not None:
                stub["name"] = m["name"]
            out.append(stub)
        else:
            out.append(m)
    return out
