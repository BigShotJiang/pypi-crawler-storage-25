"""Structured logging for tool runners.

Tool runners run inside a short-lived subprocess (`_spawn_tool_runner`)
that inherits `RTXCLAW_AGENT_HOME` from its parent. The subprocess has
no `FileHandler` attached to the stdlib logging tree, so a plain
`logger.info(...)` would silently drop. The pattern this module
follows mirrors `acp_bridge.py:2127` — open the agent's logfile in
append mode and write a single deterministic line per event.

Output format (one line per event)::

    <iso8601-utc-z> EVENT scope=<scope> field1=val1 field2=val2 …

Values are JSON-encoded so embedded spaces / special chars survive
parsing, matching what `gateway.log` already does for `TURN_METRICS`.
The lines are append-only and sized to be greppable by a human:

    grep '^2026-05-07.*MONITOR_' ~/.rtxclaw/agents/main/logs/gateway.log
    grep 'DELEGATE_AGENT' ~/.rtxclaw/agents/main/logs/gateway.log

Why not a stdlib logger:

* The runner subprocess can't reliably attach a `FileHandler` (it
  exits before flush, gets reaped before stream-close, etc).
* Direct file writes are the same approach the existing telemetry
  uses; staying consistent means existing log-tail tooling keeps
  working without changes.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def _agent_logfile() -> Optional[Path]:
    """Resolve `<RTXCLAW_AGENT_HOME>/logs/gateway.log`.

    Returns `None` when the env isn't set (e.g. running outside an
    agent context — unit tests, ad-hoc invocations). Callers must
    silently no-op so a missing logfile cannot break a tool call.
    """
    home = os.environ.get("RTXCLAW_AGENT_HOME")
    if not home:
        return None
    return Path(home) / "logs" / "gateway.log"


def log_event(event: str, **fields: Any) -> None:
    """Append a structured line to the agent's `gateway.log`.

    Best-effort: any I/O error (logfile rolled away, disk full,
    permission lost) is swallowed so a logging failure cannot break
    the tool call. The contract is "log if you can", not "log or
    fail" — the agent's own session JSON has the authoritative trace.
    """
    path = _agent_logfile()
    if path is None:
        return
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    parts = [ts, event]
    for k, v in fields.items():
        try:
            rendered = json.dumps(v, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            rendered = json.dumps(repr(v))
        parts.append(f"{k}={rendered}")
    line = " ".join(parts) + "\n"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        # Logfile unwritable — silently drop. The agent's session
        # JSON still records the tool call's args + result; this
        # logfile is auxiliary telemetry, not the source of truth.
        pass


__all__ = ["log_event"]
