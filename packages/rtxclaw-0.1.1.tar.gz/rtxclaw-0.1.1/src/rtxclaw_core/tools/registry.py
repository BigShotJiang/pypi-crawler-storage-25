"""Tool registry: kind tags + a default set of tool definitions.

Rtxclaw doesn't yet wire OpenAI tool-calling into the worker. When it
does, each registered `Tool` will become a function the model can call,
and the runtime will gate every invocation through `PermissionEvaluator`
(see `tools.permissions`).

Tools carry a `kind` tag (`read` / `write` / `exec` / `network`). The
permission decision matrix is keyed on `kind`, not on tool name — adding
a new tool is just a registry entry, no permission code change.

`exec`-kind tools accept a `command` (or compatible) field. The evaluator
re-classifies each call's actual command via `tools.safety.classify_command`
before deciding, so two `exec` calls can land on different decisions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ToolKind(Enum):
    """Coarse permission category. Drives `PermissionEvaluator.evaluate`."""

    READ = "read"        # inspects state only — Read, Glob, Grep, list_dir
    WRITE = "write"      # writes / edits files — Write, Edit, ApplyPatch
    EXEC = "exec"        # runs arbitrary shell — Bash, Exec, Process
    NETWORK = "network"  # outbound HTTP — WebFetch, WebSearch (read-only)


@dataclass(frozen=True)
class Tool:
    """One callable tool — name, kind, and an OpenAI-compatible schema.

    `parameters` is the JSON Schema sent to the model in the
    `tools[].function.parameters` field of a `chat/completions` request.
    The convention added by `tools.prompt`: every tool's parameters
    include a `criticality` enum with values `read_only` / `mutating` /
    `destructive`, and the system prompt teaches the model when to set
    which.

    ``core`` controls deferral: the bridge only includes core tools in
    the worker's ``tools[]`` payload by default (~2K tokens vs ~10K).
    Non-core tools surface in a one-line catalog the model sees in the
    system prompt; the model calls ``tool_search`` to load full schemas
    for the tools it actually needs that round, and the bridge then
    expands ``tools[]`` for subsequent rounds.
    """

    name: str
    kind: ToolKind
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    core: bool = False

    def openai_schema(self) -> dict[str, Any]:
        """Return the function-tool entry for `tools[]` in chat/completions."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters or {"type": "object", "properties": {}},
            },
        }


def _params(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    """Build a JSON-schema parameters object including the criticality enum."""
    full_props = dict(properties)
    full_props["criticality"] = {
        "type": "string",
        "enum": ["read_only", "mutating", "destructive"],
        "description": (
            "Self-classification of this call's effect. "
            "`read_only` if the call only inspects state. "
            "`mutating` if it changes state but is reversible. "
            "`destructive` if it is irreversible or affects critical state "
            "(rm -rf, drop table, force-push to main, etc.). "
            "Be honest — the runtime gates execution on this value."
        ),
    }
    return {
        "type": "object",
        "properties": full_props,
        "required": required + ["criticality"],
        "additionalProperties": False,
    }


# Default tool set. Implementations come later; this is just the schema
# the model sees and the kind tag the permission evaluator reads.
BUILTIN_TOOLS: tuple[Tool, ...] = (
    Tool(
        name="ToolSearch",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Discover and load schemas for deferred tools. The agent ships "
            "with a small core toolset (file ops, Grep, Bash, TodoWrite); "
            "every other tool is referenced by name + one-line description "
            "in the system prompt and its full schema is loaded on demand. "
            "Call this tool to fetch the schemas you need.\n\n"
            "Query forms:\n"
            "- ``select:<name1>,<name2>,...`` — fetch these exact tools.\n"
            "- ``<keyword>`` — fuzzy-match against tool name + description.\n\n"
            "Result: the matching tools' schemas appear in your tools list "
            "for subsequent turns and become callable. "
            "criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "query": {
                    "type": "string",
                    "description": (
                        "Tool selector. ``select:Read,Grep`` for "
                        "explicit names, or a free-form keyword."
                    ),
                },
                "max_results": {
                    "type": "integer",
                    "description": "Max tools to return (default 5).",
                },
            },
            required=["query"],
        ),
    ),
    Tool(
        name="Read",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Read a file from the local filesystem. Pass `offset` "
            "(1-based start line) and `limit` (number of lines) to "
            "slice — strongly preferred for source files >100 lines so "
            "you don't flood your context with unrelated code. Always "
            "read_only — set criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "file_path": {
                    "type": "string",
                    "description": "Absolute path to the file.",
                },
                "offset": {
                    "type": "integer",
                    "description": (
                        "Optional 1-based line number to start reading from."
                    ),
                },
                "limit": {
                    "type": "integer",
                    "description": "Optional number of lines to read.",
                },
            },
            required=["file_path"],
        ),
    ),
    Tool(
        name="list_dir",
        kind=ToolKind.READ,
        core=True,
        description=(
            "List the entries of a directory. Always read_only — "
            "set criticality=\"read_only\". Prefer `Glob` for "
            "pattern-based file finding."
        ),
        parameters=_params(
            {"path": {"type": "string"}},
            required=["path"],
        ),
    ),
    Tool(
        name="Glob",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Find files matching a glob pattern. Returns absolute paths "
            "sorted by modification time (most recent first). Patterns "
            "use standard shell glob syntax with ``**`` recursion. "
            "Always read_only — set criticality=\"read_only\".\n\n"
            "Examples:\n"
            "- ``**/*.py`` — every Python file under cwd.\n"
            "- ``/path/to/rtxclaw/**/*.md`` — markdown under a "
            "specific tree.\n"
            "- ``tests/test_*_telegram*.py`` — telegram-related tests."
        ),
        parameters=_params(
            {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern (supports ``**``).",
                },
                "path": {
                    "type": "string",
                    "description": (
                        "Optional root directory to search (default: "
                        "cwd). Pattern is interpreted relative to this."
                    ),
                },
            },
            required=["pattern"],
        ),
    ),
    Tool(
        name="Grep",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Search file contents with a regex. Returns "
            "``path:lineno:line`` matches (or per-mode output). Always "
            "read_only — set criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "pattern": {"type": "string", "description": "Regex pattern."},
                "path": {
                    "type": "string",
                    "description": "Root path to search (default: cwd).",
                },
                "glob": {
                    "type": "string",
                    "description": (
                        "Filter files by glob (e.g. ``*.py``). Equivalent "
                        "to the legacy ``include`` arg."
                    ),
                },
                "output_mode": {
                    "type": "string",
                    "enum": ["content", "files_with_matches", "count"],
                    "description": (
                        "``content`` (default): matched lines. "
                        "``files_with_matches``: just filenames. "
                        "``count``: per-file match counts."
                    ),
                },
                "-n": {
                    "type": "boolean",
                    "description": "Show line numbers (default true).",
                },
                "-i": {
                    "type": "boolean",
                    "description": "Case-insensitive match.",
                },
                "head_limit": {
                    "type": "integer",
                    "description": "Cap returned hits (default 500).",
                },
            },
            required=["pattern"],
        ),
    ),
    Tool(
        name="Write",
        kind=ToolKind.WRITE,
        core=True,
        description=(
            "Create or overwrite a file. Set criticality=\"mutating\" "
            "for normal writes, \"destructive\" if you are overwriting "
            "something irreplaceable."
        ),
        parameters=_params(
            {
                "file_path": {
                    "type": "string",
                    "description": "Absolute path to the file.",
                },
                "content": {"type": "string"},
            },
            required=["file_path", "content"],
        ),
    ),
    Tool(
        name="Edit",
        kind=ToolKind.WRITE,
        core=True,
        description=(
            "Replace ``old_string`` with ``new_string`` in a file. By "
            "default expects a unique match — pass ``replace_all=true`` "
            "to substitute every occurrence. Set "
            "criticality=\"mutating\" unless you are deleting "
            "load-bearing content."
        ),
        parameters=_params(
            {
                "file_path": {
                    "type": "string",
                    "description": "Absolute path to the file.",
                },
                "old_string": {
                    "type": "string",
                    "description": "Exact text to match (must be unique unless replace_all).",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text.",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": (
                        "If true, replace EVERY occurrence; otherwise the "
                        "match must be unique."
                    ),
                },
            },
            required=["file_path", "old_string", "new_string"],
        ),
    ),
    Tool(
        name="Update",
        kind=ToolKind.WRITE,
        core=True,
        description=(
            "Modify a file by replacing ``old_string`` with "
            "``new_string`` — the canonical file-edit tool, named to "
            "match the \"Update\" label Claude Code shows for edits. "
            "Same contract as ``Edit``: the match must be unique "
            "unless ``replace_all=true``. Prefer ``Update`` over "
            "``Edit`` — the rtxclaw TUI renders an ``Update`` call as "
            "a colored code-diff card (red removals / green "
            "additions) so the operator sees exactly what changed. "
            "Set criticality=\"mutating\" unless you are deleting "
            "load-bearing content."
        ),
        parameters=_params(
            {
                "file_path": {
                    "type": "string",
                    "description": "Absolute path to the file.",
                },
                "old_string": {
                    "type": "string",
                    "description": "Exact text to match (must be unique unless replace_all).",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text.",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": (
                        "If true, replace EVERY occurrence; otherwise the "
                        "match must be unique."
                    ),
                },
            },
            required=["file_path", "old_string", "new_string"],
        ),
    ),
    Tool(
        name="Bash",
        core=True,
        kind=ToolKind.EXEC,
        description=(
            "Run a shell command. Output streams line-by-line to the TUI "
            "as the command produces it. `timeout` is the wall-clock "
            "deadline in milliseconds (default 120000 = 2 min, max "
            "600000). Set ``run_in_background=true`` to fire-and-forget "
            "— the call returns immediately with a ``bash_id`` you can "
            "feed to ``BashOutput`` to drain output and ``KillShell`` to "
            "stop it. Set criticality based on what the command does: "
            "`read_only` for ls/cat/grep, `mutating` for mkdir/touch/mv, "
            "`destructive` for rm -rf, drop table, git push --force to "
            "main, rebooting the host, etc. The runtime also runs a "
            "heuristic classifier and takes the more cautious of the two."
        ),
        parameters=_params(
            {
                "command": {"type": "string", "description": "Shell command to run."},
                "description": {
                    "type": "string",
                    "description": (
                        "Short, active-voice description of what this "
                        "command does (5-10 words for simple commands)."
                    ),
                },
                "timeout": {
                    "type": "number",
                    "description": (
                        "Wall-clock timeout in milliseconds (default "
                        "120000, max 600000)."
                    ),
                },
                "run_in_background": {
                    "type": "boolean",
                    "description": (
                        "Run the command in the background and return "
                        "immediately with a bash_id for BashOutput/KillShell."
                    ),
                },
            },
            required=["command"],
        ),
    ),
    Tool(
        name="Monitor",
        kind=ToolKind.EXEC,
        core=True,
        description=(
            "Start a background monitor that streams events from a "
            "long-running script. Each stdout line is emitted as a "
            "notification. Stops when the command exits or the timeout "
            "fires. Set ``persistent=true`` for session-length watches "
            "(no timeout). Returns the ``task_id`` so you can stop "
            "early via ``KillShell``. Set criticality based on what "
            "the command does — same rules as ``Bash``."
        ),
        parameters=_params(
            {
                "command": {
                    "type": "string",
                    "description": "Shell command or script to background-spawn.",
                },
                "description": {
                    "type": "string",
                    "description": "Short human-readable description shown with each event.",
                },
                "timeout_ms": {
                    "type": "integer",
                    "description": (
                        "Kill the monitor after this deadline (default "
                        "300000 ms, max 3600000)."
                    ),
                },
                "persistent": {
                    "type": "boolean",
                    "description": "Run for the lifetime of the session (no timeout).",
                },
            },
            required=["command", "description"],
        ),
    ),
    Tool(
        name="BashOutput",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Pull new output lines from a background ``Bash`` (started "
            "with ``run_in_background=true``) or a ``Monitor``. If "
            "nothing new is buffered, waits briefly for the next line "
            "OR process exit. Cursor advances per call — each line is "
            "delivered exactly once. Always `read_only`."
        ),
        parameters=_params(
            {
                "bash_id": {
                    "type": "string",
                    "description": (
                        "Background id from ``Bash(run_in_background=true)`` "
                        "or ``Monitor``."
                    ),
                },
                "filter": {
                    "type": "string",
                    "description": (
                        "Optional regex; only lines matching are returned."
                    ),
                },
            },
            required=["bash_id"],
        ),
    ),
    Tool(
        name="KillShell",
        kind=ToolKind.EXEC,
        core=True,
        description=(
            "Terminate a background ``Bash`` or ``Monitor`` (SIGTERM "
            "then SIGKILL after a grace period). Returns the exit code "
            "and unread-line count. Always safe to call against an "
            "already-exited shell. Set criticality based on what the "
            "command was doing."
        ),
        parameters=_params(
            {
                "shell_id": {
                    "type": "string",
                    "description": "Background id to terminate.",
                },
            },
            required=["shell_id"],
        ),
    ),
    Tool(
        name="monitor_list",
        kind=ToolKind.READ,
        core=True,
        description=(
            "List every live background ``Bash`` / ``Monitor`` in this "
            "process: id, running flag, exit code (if finished), "
            "unread-line count, and command. No arguments. Always "
            "`read_only`."
        ),
        parameters=_params({}, required=[]),
    ),
    Tool(
        name="ExitPlanMode",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Use this tool when you are in plan mode and have finished "
            "presenting your plan and are ready to start coding. The user "
            "will be prompted to switch out of plan mode (and into auto / "
            "ask). Always read_only — set criticality=\"read_only\". Do "
            "NOT use this for routine research / read-only summaries — "
            "only when you have a concrete plan ready to execute."
        ),
        parameters=_params(
            {
                "plan": {
                    "type": "string",
                    "description": (
                        "The plan you're proposing, in markdown. The "
                        "user sees this verbatim before approving."
                    ),
                },
            },
            required=["plan"],
        ),
    ),
    Tool(
        name="WebFetch",
        kind=ToolKind.NETWORK,
        description=(
            "Fetch a URL and return its content. Optional ``prompt`` is "
            "an extraction hint — what to look for / pull out of the "
            "page. HTML pages are extracted to markdown (main article "
            "body only, headings/lists/tables/links preserved; nav, "
            "ads, scripts dropped). Non-HTML responses (JSON, plain "
            "text, CSV) pass through unchanged. Read-only network call "
            "— set criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "url": {"type": "string"},
                "prompt": {
                    "type": "string",
                    "description": (
                        "Optional extraction hint: 'what is the X "
                        "version', 'pull the price table', etc."
                    ),
                },
            },
            required=["url"],
        ),
    ),
    Tool(
        name="WebSearch",
        kind=ToolKind.NETWORK,
        description=(
            "Search the web via the Brave Search API. Returns a ranked "
            "list of {title, url, description}. Always read_only — set "
            "criticality=\"read_only\". Requires a Brave API key configured "
            "via the wizard or `BRAVE_API_KEY` env var."
        ),
        parameters=_params(
            {
                "query": {"type": "string", "description": "Search query."},
                "allowed_domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Restrict results to these domains.",
                },
                "blocked_domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Drop results from these domains.",
                },
                "count": {
                    "type": "integer",
                    "description": "Number of results to return (1-10, default 5).",
                },
                "freshness": {
                    "type": "string",
                    "description": "Time filter: 'day' | 'week' | 'month' | 'year'.",
                },
                "country": {
                    "type": "string",
                    "description": "2-letter ISO country code (e.g. 'US', 'BR').",
                },
            },
            required=["query"],
        ),
    ),
    Tool(
        name="SkillSearch",
        kind=ToolKind.READ,
        # Core, single-entrypoint by design — mirrors `ToolSearch`.
        # Discover, enumerate, AND load skill bodies through one tool;
        # there is intentionally no separate `Skill` tool because
        # small models split a "find then read" task into two calls
        # only when both surfaces exist. The system prompt carries a
        # one-line pointer + skill count instead of a 30 KB ``# SKILLS``
        # header dump, which is how rtxclaw scales to 200+ installed
        # skills against a local 27-31B first-thinking model.
        core=True,
        description=(
            "Discover and load skills. The ONLY correct way to "
            "enumerate, search, or read installed skills — do NOT use "
            "`Bash ls` / `Glob` / `Grep` / `Read` / `list_dir` on the "
            "skills directory; those miss `skills_dirs` overrides + "
            "plugin bundles, and they bloat the prompt.\n\n"
            "Query forms (mirrors ToolSearch):\n"
            "- ``select:<name1>,<name2>,...`` — load the FULL bodies "
            "of these exact skills.\n"
            "- ``<keyword>`` — lexical match against name + "
            "description; returns ranked `name — description` lines.\n"
            "- empty / ``*`` / ``all`` — list every installed skill, "
            "alphabetised, paginated via `offset` + `max_results`. "
            "Use this when the user says \"list skills\" / "
            "\"what skills are there\".\n\n"
            "Result format for `select:`: a `selected: skill1, skill2` "
            "line, then bodies inside a ``<skills>…</skills>`` block. "
            "criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "query": {
                    "type": "string",
                    "description": (
                        "Skill selector. ``select:python-refactor,"
                        "deploy-vllm`` to load bodies, ``\"deploy vllm\"`` "
                        "for a ranked search, or omit / pass ``\"\"`` / "
                        "``\"*\"`` / ``\"all\"`` to list every skill."
                    ),
                },
                "max_results": {
                    "type": "integer",
                    "description": (
                        "Max skills to return. Default 10 (ranked) / "
                        "50 (list). Max 50 ranked, 200 list. (Alias: "
                        "`top_k` for back-compat.)"
                    ),
                },
                "offset": {
                    "type": "integer",
                    "description": (
                        "Pagination offset for list mode (ignored "
                        "elsewhere). Default 0."
                    ),
                },
            },
            required=[],
        ),
    ),
    Tool(
        name="remember",
        kind=ToolKind.WRITE,
        description=(
            "Save an observation to today's daily log "
            "(`memory/YYYY-MM-DD.md`). The ONLY tool that can write "
            "memory files — direct write_file / edit_file / exec on "
            "those paths is REFUSED.\n\n"
            "Use when the user says \"remember\", \"save this\", "
            "\"from now on\", or when you've reached a durable "
            "observation on your own.\n\n"
            "MEMORY.md is NOT written by this tool. It's curated by a "
            "background synthesizer that periodically reads the daily "
            "logs and lifts general principles up to MEMORY.md, "
            "dropping specifics (file paths, branch names, dates, perf "
            "numbers tied to a single dataset). Just write the raw "
            "observation here — the synthesizer decides what goes "
            "into long-term memory.\n\n"
            "Three actions:\n"
            "  - add:     append a new dated bullet to today's log.\n"
            "  - replace: substring-match in today's log, swap for new "
            "content. `old_text` need only be unique enough to "
            "identify ONE entry.\n"
            "  - remove:  substring-match and delete (same uniqueness "
            "rule as replace).\n\n"
            "Set criticality=\"mutating\" for add/replace, "
            "\"destructive\" for remove."
        ),
        parameters=_params(
            {
                "action":   {"type": "string", "enum": ["add", "replace", "remove"]},
                "content":  {"type": "string"},
                "old_text": {"type": "string"},
                "category": {
                    "type": "string",
                    "enum": [
                        "fact", "preference", "decision", "lesson",
                        "todo", "context", "profile", "project",
                    ],
                },
            },
            required=["action"],
        ),
    ),
    Tool(
        name="memory_search",
        kind=ToolKind.READ,
        description=(
            "Search MEMORY.md and memory/YYYY-MM-DD.md using hybrid "
            "vector + keyword (BM25) retrieval. Use BEFORE acting when a "
            "task could relate to past decisions, identifiers, or "
            "conversations the user has already discussed — don't guess "
            "history, look it up. Returns ranked snippets with file path "
            "+ line range + relevance score; follow up with `memory_get` "
            "or `read_file` to read the full hit. Always read_only — set "
            "criticality=\"read_only\". Refused on shared / group "
            "frontends to keep operator notes private. Two filters "
            "stack on top of `top_k`: `min_score` is the absolute floor "
            "(default 0.35); `relevance_floor` is a fraction of the top "
            "hit's score (default 0 = off; set to 0.5 to drop anything "
            "below 50% of the best match — useful when only one result "
            "is actually relevant)."
        ),
        parameters=_params(
            {
                "query": {
                    "type": "string",
                    "description": "Natural-language search query.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results to return (1-20, default 6).",
                },
                "min_score": {
                    "type": "number",
                    "description": (
                        "Absolute floor on the fused score (0-1, "
                        "default 0.35). Lower to widen recall on a "
                        "small corpus."
                    ),
                },
                "relevance_floor": {
                    "type": "number",
                    "description": (
                        "Relative-to-best filter (0-1, default 0). "
                        "Drops hits whose score is below "
                        "`relevance_floor × top_score`. Useful when "
                        "you want quality > quantity."
                    ),
                },
            },
            required=["query"],
        ),
    ),
    Tool(
        name="memory_get",
        kind=ToolKind.READ,
        description=(
            "Read a memory file (or line range) by path. Use after "
            "`memory_search` narrows down the location, or to read "
            "MEMORY.md / a specific daily log directly. Path is relative "
            "to the agent's home directory; absolute paths and '..' "
            "traversal are refused. Always read_only — set "
            "criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "file_path": {
                    "type": "string",
                    "description": (
                        "Memory file path, e.g. 'MEMORY.md' or "
                        "'memory/2026-04-27.md'."
                    ),
                },
                "start_line": {
                    "type": "integer",
                    "description": "Optional 1-based start line.",
                },
                "end_line": {
                    "type": "integer",
                    "description": "Optional 1-based end line (inclusive).",
                },
            },
            required=["file_path"],
        ),
    ),
    Tool(
        name="session_search",
        kind=ToolKind.READ,
        description=(
            "Search past saved sessions for matching turns using FTS5. "
            "Use when the user references a previous conversation ('did "
            "we discuss…', 'remind me what I said about…') or when you "
            "need to recover context the operator may have established "
            "in a prior session. Returns ranked hits with session title, "
            "date, turn index, and a snippet — follow up with `read_file` "
            "on the session JSON if the snippet isn't enough.\n\n"
            "Always read_only — set criticality=\"read_only\". Refused "
            "on shared / group frontends to keep operator chats private. "
            "Empty result is normal for fresh agents (the index backfills "
            "from disk on the first heartbeat tick after deploy)."
        ),
        parameters=_params(
            {
                "query": {
                    "type": "string",
                    "description": "Natural-language search query.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results to return (1-20, default 6).",
                },
                "min_score": {
                    "type": "number",
                    "description": (
                        "Absolute floor on the BM25 score (0-1, "
                        "default 0.35). Lower to widen recall on a "
                        "small corpus."
                    ),
                },
            },
            required=["query"],
        ),
    ),
    Tool(
        name="fact_store",
        kind=ToolKind.WRITE,
        description=(
            "Local-first fact store complementing `remember`. Use this "
            "for DISCRETE structured facts that benefit from category + "
            "tags + trust scoring (e.g. operator preferences, machine "
            "configs, learned recipes); use `remember` for free-form "
            "diary entries.\n\n"
            "Five sub-actions:\n"
            "  - add:    insert a fact. id is SHA-256(content); exact "
            "duplicates are returned as-is, not re-inserted. Refuses "
            "content with invisible Unicode or credential-shaped "
            "patterns (API keys, PEM headers).\n"
            "  - search: FTS over content, blended with trust score.\n"
            "  - list:   list facts, optionally filtered by category.\n"
            "  - remove: delete by `old_content_prefix` substring (must "
            "match exactly one fact).\n"
            "  - update: replace by `old_content_prefix` → `new_content` "
            "(preserves category/trust/tags).\n\n"
            "Set criticality=\"mutating\" for add/update, \"destructive\" "
            "for remove, \"read_only\" for search/list."
        ),
        parameters=_params(
            {
                "action": {
                    "type": "string",
                    "enum": ["add", "search", "list", "remove", "update"],
                },
                "category": {
                    "type": "string",
                    "description": (
                        "Free-form tag (e.g. 'preference', 'config', "
                        "'recipe'). Defaults to 'fact' on add."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": "Fact body (for add).",
                },
                "old_content_prefix": {
                    "type": "string",
                    "description": (
                        "Substring identifying ONE fact (for "
                        "remove/update)."
                    ),
                },
                "new_content": {
                    "type": "string",
                    "description": "Replacement text (for update).",
                },
                "query": {
                    "type": "string",
                    "description": "Search query (for search).",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Optional list of free-form tags to attach on "
                        "add."
                    ),
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results (search/list, default 6).",
                },
            },
            required=["action"],
        ),
    ),
    Tool(
        name="fact_feedback",
        kind=ToolKind.WRITE,
        description=(
            "Adjust a fact's trust score after using it. Helpful=True "
            "bumps trust by +0.05 (capped 1.0); Helpful=False drops it "
            "by -0.10 (floored 0.0). Search ranking is BM25 × (0.5 + "
            "0.5 × trust), so distrusted facts decay out of results "
            "without disappearing — the operator can still see (and "
            "correct) them.\n\n"
            "Call this when you've consumed a fact_store hit and the "
            "outcome tells you whether it was right. Set "
            "criticality=\"mutating\"."
        ),
        parameters=_params(
            {
                "fact_id_or_prefix": {
                    "type": "string",
                    "description": (
                        "Fact id (SHA-256 hex prefix accepted) OR "
                        "content substring identifying ONE fact."
                    ),
                },
                "helpful": {
                    "type": "boolean",
                    "description": "True bumps trust; False drops it.",
                },
            },
            required=["fact_id_or_prefix", "helpful"],
        ),
    ),
    Tool(
        name="OutputSection",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Emit ONE section of a long structured response, then yield. "
            "Use this whenever your final answer needs more than ~5 "
            "distinct sections (a comprehensive report, a step-by-step "
            "guide, a multi-file refactor plan). Writing everything in "
            "one round is the textbook way to slip into long-context "
            "coherence collapse on local 27B-class models — entropy "
            "drops, prose collapses into character spam, the loop "
            "detector fires, and the partial output gets thrown away.\n\n"
            "Pattern: on the FIRST call, pass ``outline=[…]`` listing "
            "every section title (the model's own plan for the answer). "
            "On every call also pass ``section_name`` (which section "
            "you just finished) and ``content`` (the prose for that "
            "section). The bridge persists the section to "
            "``sess.draft_sections`` and tells you the next section to "
            "write. When you've written the LAST section, set "
            "``is_final=True``; the bridge confirms and you end your "
            "turn naturally.\n\n"
            "Each section is its own round, so the loop detectors + "
            "ratio guard + distill recovery run with a fresh context "
            "per section — no single round accumulates enough context "
            "to enter the collapse zone.\n\n"
            "Marked kind=READ — operates only on session-scoped state. "
            "Set criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "section_name": {
                    "type": "string",
                    "description": (
                        "The section just written (matches an entry in "
                        "the outline). Used as a key for the persisted "
                        "draft."
                    ),
                },
                "content": {
                    "type": "string",
                    "description": (
                        "The prose for this section. Markdown OK. The "
                        "bridge appends this to the session's draft "
                        "buffer and the user sees it in the live "
                        "transcript."
                    ),
                },
                "outline": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Full ordered list of section titles. "
                        "Required on the first call; ignored on "
                        "subsequent calls (the outline is locked once "
                        "set so the model can't keep re-planning)."
                    ),
                },
                "is_final": {
                    "type": "boolean",
                    "description": (
                        "True when this is the last section. The "
                        "bridge confirms completion and you can end "
                        "your turn after the tool result."
                    ),
                },
            },
            required=["section_name", "content"],
        ),
    ),
    Tool(
        name="UserQuestion",
        kind=ToolKind.NETWORK,  # treated as 'asks the world' — not a local read
        core=True,
        description=(
            "Ask the user a clarifying question when the prompt is "
            "ambiguous or under-specified, BEFORE doing significant "
            "work. Use sparingly — for routine work just proceed with "
            "reasonable assumptions. Use this tool when:\n"
            "  - The prompt has a load-bearing ambiguity (e.g. \"clean "
            "    up the auth code\" — which auth: `auth.py` or "
            "    `auth_legacy.py`?).\n"
            "  - The user's stated goal is mutually exclusive with "
            "    something they already shipped (e.g. they ask for a "
            "    feature that conflicts with a constraint in CLAUDE.md).\n"
            "  - You'd otherwise need to do >5 minutes of exploratory "
            "    work just to interpret the request.\n\n"
            "Each question must offer 2–4 specific options the user "
            "can pick. Avoid generic open questions (\"what do you "
            "want?\") — they're a poor user experience.\n\n"
            "RESERVED for the user-facing main agent. Worker sub-agents "
            "(``coder``, ``scraper``) don't have a user to ask and are "
            "explicitly denied this tool via their ``tools_allowlist``. "
            "If you're a worker and need clarification, return a "
            "concrete question in your final text and let the parent "
            "agent ask the user.\n\n"
            "Marked kind=NETWORK because the answer comes from outside "
            "this process. Set criticality=\"read_only\" — asking a "
            "question is non-mutating."
        ),
        parameters=_params(
            {
                "question": {
                    "type": "string",
                    "description": (
                        "The complete question to ask the user. End "
                        "with a question mark."
                    ),
                },
                "options": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "label": {
                                "type": "string",
                                "description": (
                                    "Short, mutually-exclusive choice "
                                    "the user picks (1–5 words)."
                                ),
                            },
                            "description": {
                                "type": "string",
                                "description": (
                                    "What this choice means / its "
                                    "implication."
                                ),
                            },
                        },
                        "required": ["label"],
                    },
                    "description": (
                        "2–4 options. The user can also reply 'Other' "
                        "with free-form text."
                    ),
                },
            },
            required=["question", "options"],
        ),
    ),
    Tool(
        name="AskUserQuestion",
        kind=ToolKind.NETWORK,  # answer comes from outside this process
        core=True,
        description=(
            "Ask the user 1–4 multiple-choice questions and synchronously "
            "await their selections. Use to gather requirements, resolve "
            "ambiguity, or pick between approaches BEFORE doing the work "
            "— never as a wrap-up confirmation.\n\n"
            "Differences from ``UserQuestion``:\n"
            "  - Multiple questions in one call (batch related choices).\n"
            "  - Optional multi-select per question.\n"
            "  - Synchronous round-trip via ACP ``session/ask_user``: "
            "    the model receives the user's selections as the tool "
            "    result, rather than ending its turn and waiting for "
            "    the user's next message.\n\n"
            "Each question must offer 2–4 mutually-exclusive options "
            "(unless ``multiSelect=true``). 'Other' free-form is always "
            "appended client-side — you don't need to provide it. "
            "Use sparingly; for routine work just proceed with "
            "reasonable assumptions.\n\n"
            "RESERVED for the user-facing main agent. Worker sub-agents "
            "have no user to ask and should return clarifying questions "
            "in their final text instead.\n\n"
            "kind=NETWORK because the answer comes from outside this "
            "process. Set criticality=\"read_only\" — asking is "
            "non-mutating."
        ),
        parameters=_params(
            {
                "questions": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 4,
                    "description": (
                        "1–4 questions. Each is asked together in one "
                        "round-trip; the user picks options for each "
                        "before answers return."
                    ),
                    "items": {
                        "type": "object",
                        "required": ["question", "header", "options"],
                        "additionalProperties": False,
                        "properties": {
                            "question": {
                                "type": "string",
                                "description": (
                                    "The complete question. End with a "
                                    "question mark."
                                ),
                            },
                            "header": {
                                "type": "string",
                                "description": (
                                    "Very short label shown as a chip/"
                                    "tag (≤12 chars). E.g. 'Library', "
                                    "'Auth method'."
                                ),
                            },
                            "multiSelect": {
                                "type": "boolean",
                                "default": False,
                                "description": (
                                    "Allow multiple options to be "
                                    "selected. Use only when choices "
                                    "are non-exclusive."
                                ),
                            },
                            "options": {
                                "type": "array",
                                "minItems": 2,
                                "maxItems": 4,
                                "items": {
                                    "type": "object",
                                    "required": ["label"],
                                    "additionalProperties": False,
                                    "properties": {
                                        "label": {
                                            "type": "string",
                                            "description": (
                                                "Short choice (1–5 "
                                                "words)."
                                            ),
                                        },
                                        "description": {
                                            "type": "string",
                                            "description": (
                                                "What this choice "
                                                "means / its "
                                                "implication."
                                            ),
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
            required=["questions"],
        ),
    ),
    Tool(
        name="TodoWrite",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Session-scoped checklist for organizing multi-step work. "
            "The list lives at `<sessions_dir>/<sid>.todos.json` — one "
            "list per rtxclaw session, persisted across turns until the "
            "session ends.\n\n"
            "Use it whenever a user request decomposes into more than "
            "two or three discrete steps, or whenever you find yourself "
            "about to do work that has natural milestones (\"first read "
            "X, then patch Y, then run tests\"). The list keeps you "
            "from losing track between turns and lets the user see what "
            "you're planning without you having to restate it every "
            "round.\n\n"
            "Single primitive: send the WHOLE updated list with each "
            "call — adding, completing, or removing items is just "
            "writing the new state. Match Claude Code's TodoWrite "
            "shape exactly so a delegated /claude turn and a native "
            "rtxclaw turn produce the same on-disk list.\n\n"
            "Item shape: ``{content, activeForm, status}`` with "
            "``status ∈ {pending, in_progress, completed}``. "
            "``content`` is the TODO line as a noun phrase; "
            "``activeForm`` is the same step in present-continuous "
            "form (shown in the spinner while running). Exactly ONE "
            "item should be ``in_progress`` at any time.\n\n"
            "Marked kind=READ so it never prompts and is allowed in "
            "plan mode — todos are model-side bookkeeping, not user "
            "data. Set criticality=\"mutating\"."
        ),
        parameters=_params(
            {
                "todos": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {
                                "type": "string",
                                "description": (
                                    "Imperative title of the todo "
                                    "(e.g. 'Fix auth bug')."
                                ),
                            },
                            "activeForm": {
                                "type": "string",
                                "description": (
                                    "Present-continuous form shown in "
                                    "spinner (e.g. 'Fixing auth bug')."
                                ),
                            },
                            "status": {
                                "type": "string",
                                "enum": ["pending", "in_progress", "completed"],
                            },
                        },
                        "required": ["content", "activeForm", "status"],
                    },
                    "description": (
                        "The full updated todo list. Each call replaces "
                        "the persisted list with this array."
                    ),
                },
            },
            required=["todos"],
        ),
    ),
    Tool(
        name="TaskCreate",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Persistent task tracker — distinct from TodoWrite (which "
            "holds the working plan). Use when you need stable "
            "numeric ids for cross-turn task references, or when "
            "delegating ownership / dependencies across multiple "
            "agents in one session.\n\n"
            "Each call creates ONE task; the assigned id is returned "
            "in the result body (``Task #N created successfully: …``). "
            "The TUI mirrors the live list in the ``#harness-tasks`` "
            "footer (same UX as TodoWrite's ``#plan-checklist`` footer).\n\n"
            "Persisted to ``<sessions_dir>/<sid>.tasks.json``. Set "
            "criticality=\"mutating\"."
        ),
        parameters=_params(
            {
                "subject": {
                    "type": "string",
                    "description": (
                        "Imperative-form title of the task "
                        "(e.g. 'Review auth_routes.py')."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": (
                        "Longer-form description / acceptance "
                        "criteria. Optional."
                    ),
                },
                "activeForm": {
                    "type": "string",
                    "description": (
                        "Present-continuous verb-phrase shown in the "
                        "spinner while in_progress. Optional."
                    ),
                },
                "metadata": {
                    "type": "object",
                    "description": (
                        "Arbitrary metadata blob attached to the "
                        "task. Optional."
                    ),
                    "additionalProperties": True,
                },
            },
            required=["subject"],
        ),
    ),
    Tool(
        name="TaskUpdate",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Mutate an existing task. Pass ``taskId`` plus any subset "
            "of fields to change. ``status='deleted'`` removes the "
            "task. ``addBlocks`` / ``addBlockedBy`` add task-id "
            "relationships; ``metadata`` merges into the existing "
            "blob (set a key to null to delete it).\n\n"
            "Persists to ``<sessions_dir>/<sid>.tasks.json``. Set "
            "criticality=\"mutating\"."
        ),
        parameters=_params(
            {
                "taskId": {
                    "type": ["string", "integer"],
                    "description": "The id of the task to update.",
                },
                "status": {
                    "type": "string",
                    "enum": [
                        "pending", "in_progress", "completed", "deleted",
                    ],
                },
                "subject": {"type": "string"},
                "description": {"type": "string"},
                "activeForm": {"type": "string"},
                "owner": {"type": "string"},
                "addBlocks": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Task ids that this task blocks.",
                },
                "addBlockedBy": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Task ids that block this task.",
                },
                "metadata": {
                    "type": "object",
                    "additionalProperties": True,
                },
            },
            required=["taskId"],
        ),
    ),
    Tool(
        name="TaskList",
        kind=ToolKind.READ,
        core=True,
        description=(
            "List every task in the session-scoped task store, in id "
            "order. Each row shows id, status, subject, owner, and "
            "blockedBy edges. Set criticality=\"read_only\"."
        ),
        parameters=_params({}, required=[]),
    ),
    Tool(
        name="TaskGet",
        kind=ToolKind.READ,
        core=True,
        description=(
            "Fetch the full record for a single task — subject, "
            "description, activeForm, status, owner, blocks, "
            "blockedBy, metadata. Use when you need the long-form "
            "description back. Set criticality=\"read_only\"."
        ),
        parameters=_params(
            {
                "taskId": {
                    "type": ["string", "integer"],
                    "description": "The id of the task to fetch.",
                },
            },
            required=["taskId"],
        ),
    ),
    Tool(
        name="compact_context",
        kind=ToolKind.READ,
        description=(
            "Squeeze your own conversation context. Trims oldest large "
            "tool results, drops them entirely if still over budget, then "
            "drops oldest user/assistant turns until the message list "
            "fits the target. Always read_only on the filesystem; the "
            "agent runtime intercepts this call and operates on the "
            "in-flight messages list directly (no subprocess). "
            "Set criticality=\"read_only\". Call this when you notice "
            "earlier tool results are no longer load-bearing for the "
            "remaining work — better than letting the runtime auto-compact "
            "near the context cap."
        ),
        parameters=_params(
            {
                "target_tokens": {
                    "type": "integer",
                    "description": (
                        "Optional target prompt size after compaction. "
                        "Defaults to 50% of `compact_at_frac × "
                        "upstream_max_context` so the next few rounds "
                        "have plenty of headroom."
                    ),
                },
            },
            required=[],
        ),
    ),
    Tool(
        name="delegate_claude",
        kind=ToolKind.NETWORK,
        description=(
            "Delegate a question to Claude Code (a stronger external "
            "agent). Use when a task exceeds your own ability — deep "
            "research with web access, multi-file refactors, design "
            "review where you want a second opinion. Claude has its own "
            "tools (Read/Write/Edit/Bash/WebFetch/WebSearch) and by "
            "default runs in the working directory rtxclaw was launched "
            "from. Pass `cwd` to point Claude at a different directory "
            "(e.g. a worktree for isolated parallel work).\n\n"
            "**Session continuity is automatic.** Claude's `session_id` "
            "is persisted at `<sessions_dir>/<sid>.delegate_claude.json` "
            "and `--resume`'d on every subsequent call within one rtxclaw "
            "session, so Claude keeps the FULL prior delegate_claude "
            "conversation in its own context.\n\n"
            "**Critical: do NOT restate prior delegate_claude exchanges.** "
            "On a follow-up call, only forward the NEW context Claude "
            "is missing — the user turns, tool results, and your own "
            "reasoning that have happened SINCE your last delegate_claude "
            "call. Re-summarising the whole rtxclaw conversation is "
            "wasteful: Claude already has every prior exchange in "
            "`--resume` state. Treat `prompt` as a delta, not a full "
            "transcript.\n\n"
            "On the FIRST delegate_claude call in this session, do "
            "include the salient context (user's question, tool results, "
            "your findings) — that's the summarization step that "
            "replaces the truncation-based preamble the slash bridge "
            "used to build. After that, just send the increment.\n\n"
            "The full Claude reply comes back as the tool result and is "
            "yours to cite. Always set criticality=\"mutating\" "
            "(Claude may run shell commands and edit files in auto "
            "mode); use \"destructive\" only when the prompt asks "
            "Claude to do something irreversible. Read-only research "
            "questions can be \"read_only\" if you set mode=\"plan\"."
        ),
        parameters=_params(
            {
                "prompt": {
                    "type": "string",
                    "description": (
                        "The message to send Claude. On the FIRST call "
                        "in this rtxclaw session, include the salient "
                        "context (Claude doesn't see rtxclaw history "
                        "automatically). On follow-up calls, send only "
                        "what's NEW since your last delegate_claude "
                        "call — Claude already has the prior exchange "
                        "via --resume. Don't restate."
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["plan", "ask", "auto"],
                    "description": (
                        "Permission mode for Claude. `plan`=research-only "
                        "(no edits), `ask`=prompts before edits (won't "
                        "work non-interactively, prefer `plan` or `auto`), "
                        "`auto`=bypassPermissions (full bypass — Edit, "
                        "Write, Bash, etc. without prompting; required "
                        "in headless `-p` mode where no one can answer). "
                        "Default: inherits the rtxclaw session's current "
                        "permission mode."
                    ),
                },
                "cwd": {
                    "type": "string",
                    "description": (
                        "Optional working directory for the spawned "
                        "`claude` CLI. Absolute paths are used as-is; "
                        "relative paths resolve against rtxclaw's launch "
                        "cwd. The path must exist and be a directory or "
                        "the call fails before spawning. Omit to inherit "
                        "rtxclaw's launch directory (the historical "
                        "default — most calls don't need this). Useful "
                        "for pointing Claude at a specific worktree for "
                        "isolated parallel work."
                    ),
                },
            },
            required=["prompt"],
        ),
    ),
    Tool(
        name="delegate_codex",
        kind=ToolKind.NETWORK,
        description=(
            "Delegate a question to Codex (OpenAI's CLI agent — a stronger "
            "external agent). Use when a task exceeds your own ability — "
            "deep research with web access, multi-file refactors, design "
            "review where you want a second opinion. Codex has its own "
            "tools (Read/Write/Edit/Bash/WebFetch/WebSearch) and by "
            "default runs in the working directory rtxclaw was launched "
            "from. Pass `cwd` to point Codex at a different directory "
            "(e.g. a worktree for isolated parallel work).\n\n"
            "**Session continuity is automatic.** Codex's `thread_id` is "
            "persisted at `<sessions_dir>/<sid>.delegate_codex.json` and "
            "`exec resume`'d on every subsequent call within one rtxclaw "
            "session, so Codex keeps the FULL prior delegate_codex "
            "conversation in its own context.\n\n"
            "**Critical: do NOT restate prior delegate_codex exchanges.** "
            "On a follow-up call, only forward the NEW context Codex is "
            "missing — the user turns, tool results, and your own "
            "reasoning that have happened SINCE your last delegate_codex "
            "call. Re-summarising the whole rtxclaw conversation is "
            "wasteful: Codex already has every prior exchange in "
            "`exec resume` state. Treat `prompt` as a delta, not a full "
            "transcript.\n\n"
            "On the FIRST delegate_codex call in this session, do "
            "include the salient context (user's question, tool results, "
            "your findings) — that's the summarization step that "
            "replaces the truncation-based preamble the slash bridge "
            "used to build. After that, just send the increment.\n\n"
            "The full Codex reply comes back as the tool result and is "
            "yours to cite. Always set criticality=\"mutating\" "
            "(Codex may run shell commands and edit files in auto "
            "mode); use \"destructive\" only when the prompt asks "
            "Codex to do something irreversible. Read-only research "
            "questions can be \"read_only\" if you set mode=\"plan\"."
        ),
        parameters=_params(
            {
                "prompt": {
                    "type": "string",
                    "description": (
                        "The message to send Codex. On the FIRST call "
                        "in this rtxclaw session, include the salient "
                        "context (Codex doesn't see rtxclaw history "
                        "automatically). On follow-up calls, send only "
                        "what's NEW since your last delegate_codex "
                        "call — Codex already has the prior exchange "
                        "via `exec resume`. Don't restate."
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["plan", "ask", "auto"],
                    "description": (
                        "Permission mode for Codex. `plan`=research-only "
                        "(read-only sandbox, never asks), `ask`=prompts "
                        "before edits (won't work non-interactively, prefer "
                        "`plan` or `auto`), `auto`=bypass approvals and "
                        "sandbox (full bypass — Edit, Write, Bash, etc. "
                        "without prompting; required in headless mode "
                        "where no one can answer). Default: inherits the "
                        "rtxclaw session's current permission mode."
                    ),
                },
                "cwd": {
                    "type": "string",
                    "description": (
                        "Optional working directory for the spawned "
                        "`codex` CLI. Absolute paths are used as-is; "
                        "relative paths resolve against rtxclaw's launch "
                        "cwd. The path must exist and be a directory or "
                        "the call fails before spawning. Omit to inherit "
                        "rtxclaw's launch directory (the historical "
                        "default — most calls don't need this). Useful "
                        "for pointing Codex at a specific worktree for "
                        "isolated parallel work."
                    ),
                },
            },
            required=["prompt"],
        ),
    ),
    Tool(
        name="delegate_antigravity",
        kind=ToolKind.NETWORK,
        description=(
            "Delegate a question to Google Antigravity (via the official "
            "``@google/antigravity-cli`` — a stronger external agent). Use "
            "when a task benefits from Antigravity's strengths: long-context "
            "summarisation (>1M tokens), multimodal reasoning, or a "
            "second opinion alongside ``delegate_claude`` / "
            "``delegate_codex``. Antigravity has its own tools "
            "(Read/Write/Edit/Bash/WebFetch/WebSearch) and by default "
            "runs in the working directory rtxclaw was launched from. "
            "Pass ``cwd`` to point Antigravity at a different directory.\n\n"
            "**Session continuity is automatic.** Antigravity's session "
            "UUID is persisted at "
            "``<sessions_dir>/<sid>.delegate_antigravity.json`` and "
            "``--resume``'d on every subsequent call within one "
            "rtxclaw session, so Antigravity keeps the FULL prior "
            "delegate_antigravity conversation in its own context.\n\n"
            "**Critical: do NOT restate prior delegate_antigravity "
            "exchanges.** On a follow-up call, only forward the NEW "
            "context Antigravity is missing — the user turns, tool results, "
            "and your own reasoning that have happened SINCE your "
            "last delegate_antigravity call. Re-summarising the whole "
            "rtxclaw conversation is wasteful: Antigravity already has "
            "every prior exchange in ``--resume`` state. Treat "
            "``prompt`` as a delta, not a full transcript.\n\n"
            "On the FIRST delegate_antigravity call in this session, do "
            "include the salient context (user's question, tool "
            "results, your findings). After that, just send the "
            "increment.\n\n"
            "The full Antigravity reply comes back as the tool result and "
            "is yours to cite. Always set criticality=\"mutating\" "
            "(Antigravity may run shell commands and edit files in yolo "
            "mode); use \"destructive\" only when the prompt asks "
            "Antigravity to do something irreversible. Read-only research "
            "questions can be \"read_only\" if you set mode=\"plan\".\n\n"
            "**Auth required**: ``ANTIGRAVITY_API_KEY`` (or "
            "``GOOGLE_GENAI_USE_VERTEXAI`` / ``GOOGLE_GENAI_USE_GCA``) "
            "must be set in the agent's ``.env`` — operators put it "
            "alongside ``OPENROUTER_API_KEY``."
        ),
        parameters=_params(
            {
                "prompt": {
                    "type": "string",
                    "description": (
                        "The message to send Antigravity. On the FIRST "
                        "call in this rtxclaw session, include the "
                        "salient context (Antigravity doesn't see rtxclaw "
                        "history automatically). On follow-up calls, "
                        "send only what's NEW since your last "
                        "delegate_antigravity call — Antigravity already has "
                        "the prior exchange via ``--resume``. Don't "
                        "restate."
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["plan", "ask", "auto"],
                    "description": (
                        "Permission mode for Antigravity, mapped to its "
                        "``--approval-mode`` flag. ``plan``=read-only, "
                        "``ask``=prompt before tools (won't work "
                        "non-interactively — prefer ``plan`` or "
                        "``auto``), ``auto``=yolo (auto-approve all "
                        "tools). Default: inherits the rtxclaw "
                        "session's current permission mode."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": (
                        "Optional Antigravity model id (e.g. ``gemini-2.5-pro`` "
                        "or ``gemini-2.0-flash-exp``). Omit to use the "
                        "Antigravity CLI default configured in "
                        "``~/.antigravity/settings.json``."
                    ),
                },
                "cwd": {
                    "type": "string",
                    "description": (
                        "Optional working directory for the spawned "
                        "``antigravity`` CLI. Absolute paths are used "
                        "as-is; relative paths resolve against "
                        "rtxclaw's launch cwd. Must exist and be a "
                        "directory or the call fails before spawning. "
                        "Omit to inherit rtxclaw's launch directory."
                    ),
                },
            },
            required=["prompt"],
        ),
    ),
    Tool(
        name="delegate_agent",
        kind=ToolKind.NETWORK,
        description=(
            "Delegate one task to a SIBLING rtxclaw agent. Each agent "
            "(``main``, ``scraper``, …) runs in its own home directory "
            "with its own SOUL/AGENTS/TOOLS context, its own session "
            "store, and may be wired to a different upstream model. "
            "Use this when the target agent is materially better "
            "suited for the task (e.g. ``scraper`` has browser tools "
            "and a domain-tuned prompt). The full reply comes back as "
            "the tool result.\n\n"
            "**Session continuity is automatic.** The target agent's "
            "session id is persisted at "
            "``<sessions_dir>/<sid>.delegate_agent.<name>.json`` and "
            "resumed on every subsequent call within one rtxclaw "
            "session, so the target keeps the FULL prior delegate_agent "
            "conversation in its own context.\n\n"
            "**Critical: do NOT restate prior delegate_agent exchanges.** "
            "On a follow-up call, only forward the NEW context the "
            "target is missing. On the FIRST call, include the salient "
            "context (the task being asked, relevant findings) — that "
            "summarisation is what the target uses to ground its work."
        ),
        parameters=_params(
            {
                "name": {
                    "type": "string",
                    "description": (
                        "Target agent name (canonical). The runtime "
                        "also accepts ``agent`` / ``agent_id`` / "
                        "``agent_name`` / ``target`` / ``to`` as "
                        "synonyms so a first-attempt mis-key still "
                        "lands. Must match a configured agent under "
                        "``~/.rtxclaw/agents/<name>``."
                    ),
                },
                "task": {
                    "type": "string",
                    "description": (
                        "The prompt to send the target (canonical). "
                        "The runtime also accepts ``prompt`` / "
                        "``message`` / ``input`` as synonyms. On the "
                        "FIRST call include salient context; on "
                        "follow-ups send only what's NEW since the "
                        "last call — the target keeps the prior "
                        "exchange via the resumed session."
                    ),
                },
            },
            required=["name", "task"],
        ),
    ),
    # NOTE: `mcp_list_tools` and `mcp_call` were previously in this
    # builtin tool list. They've been removed as model-facing tools
    # because the standard MCP pattern (Claude Desktop, Claude Code,
    # MCP Python SDK) is for the CLIENT to auto-discover tools at
    # startup via the `tools/list` JSON-RPC method and inject them
    # DIRECTLY into the model's tool registry as
    # ``mcp__<server>__<tool>``. The model picks them via standard
    # tool-use, not via meta-tools.
    #
    # The runner functions for `mcp_list_tools` / `mcp_call` are kept
    # in `tools/runners.py` for diagnostic / back-compat use only —
    # they're no longer surfaced to the model.
    Tool(
        name="acp_call",
        kind=ToolKind.NETWORK,
        description=(
            "Delegate a prompt to a remote ACP (Agent Communication "
            "Protocol) agent. The remote agent is configured in the "
            "operator's `~/.rtxclaw/config.json` under `acp_agents` and "
            "addressed by its short name.\n\n"
            "Use when a task fits another agent better than this one — "
            "deep research, multi-file refactors, design review across a "
            "stack the local agent doesn't know. The remote agent runs "
            "in its own process / machine, calls its own tools, and "
            "streams the assembled reply back as the tool result.\n\n"
            "`mode` mirrors rtxclaw's permission modes:\n"
            "  - plan: research-only, the remote agent won't mutate.\n"
            "  - ask:  remote prompts before mutations (rare in headless).\n"
            "  - auto: remote runs autonomously, mutating included.\n"
            "Default: inherits this session's mode.\n\n"
            "Always criticality=\"mutating\" unless the prompt is "
            "explicitly read-only AND mode=plan; the remote may run "
            "shells / write files. Use \"destructive\" when the prompt "
            "asks the remote to do something irreversible."
        ),
        parameters=_params(
            {
                "agent_name": {
                    "type": "string",
                    "description": (
                        "Configured ACP agent name (key in the "
                        "`acp_agents` map of the global config)."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Message to send the remote agent. Be "
                        "self-contained — the remote doesn't see this "
                        "session's history unless you include it."
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["plan", "ask", "auto"],
                    "description": (
                        "Permission mode for the remote. Defaults to "
                        "this session's current mode."
                    ),
                },
                "cwd": {
                    "type": "string",
                    "description": (
                        "Optional working directory hint for the remote "
                        "agent (whatever it's free to interpret as the "
                        "context for filesystem-aware tools)."
                    ),
                },
            },
            required=["agent_name", "prompt"],
        ),
    ),
    Tool(
        name="pin_fact",
        kind=ToolKind.WRITE,
        description=(
            "Pin a fact to the session's persistent memory. Pinned "
            "facts are re-injected into the prompt right after the "
            "system message on every round, and survive every "
            "compaction (deterministic and LLM-based). Use sparingly "
            "— each pinned fact costs prompt tokens on every "
            "subsequent round.\n\n"
            "When to call:\n"
            "  - The user states a stable preference, identifier, "
            "    file path, or constraint that you'll need on later "
            "    turns (e.g. 'the dataset is at /data/x.parquet', "
            "    'always use UTC', 'the API key is in env $FOO').\n"
            "  - You established a non-obvious factual conclusion "
            "    via tools that future turns will need to honour.\n\n"
            "When NOT to call:\n"
            "  - Facts that are already in the user's input on the "
            "    current turn — they're visible without pinning.\n"
            "  - Anything ephemeral (today's weather, a one-shot "
            "    answer) — pin pollution is real.\n\n"
            "One fact per call; one concise sentence per fact. "
            "Always criticality=\"mutating\" — it changes session "
            "state but is reversible (an operator can drop pinned "
            "facts manually)."
        ),
        parameters=_params(
            {
                "fact": {
                    "type": "string",
                    "description": (
                        "Single concise sentence stating the fact. "
                        "Self-contained — no 'as we discussed' or "
                        "'see above'."
                    ),
                },
            },
            required=["fact"],
        ),
    ),
    # ── Browser tools removed (2026-05-12) ─────────────────────────────
    # The whole browser_* family used to live here as async wrappers
    # around rtxclaw_core/tools/browser_tools.py. Both surfaces wrapped
    # the same nodriver-browser skill CLI, and two front doors for one
    # backend confused small local models (qwen-27b would flip between
    # calling browser_goto and Bash running browser.py mid-task).
    # The bundled nodriver-browser skill at
    # rtxclaw_core/builtin_skills/nodriver-browser/ is now the only
    # browser surface — model invokes it as Bash →
    # ~/.rtxclaw/skills/nodriver-browser/browser <action> [flags].
    # ─────────────────────────────────────────────────────────────────────
    Tool(
        name="Agent",
        kind=ToolKind.NETWORK,
        core=True,
        description=(
            "Dispatch a subagent to handle a sub-task in its own "
            "isolated context (Claude Code's canonical primitive).\n\n"
            "``subagent_type`` selects the backend:\n"
            "  - ``general-purpose`` — a fresh rtxclaw sibling agent "
            "(see ~/.rtxclaw/agents/). Best for research, code "
            "review, multi-file refactors handled in a separate "
            "context window. Pass the sibling agent name via the "
            "``name`` field (defaults to ``main``).\n"
            "  - ``claude`` — delegate to Claude Code (via the local "
            "``claude`` CLI bridge). Use for: web research, deep "
            "long-context reasoning, or as a second opinion.\n"
            "  - ``codex`` — delegate to OpenAI Codex (via the local "
            "``codex`` CLI bridge).\n"
            "  - ``antigravity`` — delegate to Google Antigravity (via the "
            "local ``antigravity`` CLI bridge). Best for >1M-token "
            "summarisation and multimodal.\n\n"
            "The subagent runs in its own session; rtxclaw persists "
            "the full prompt + result + per-tool trace at "
            "``<sessions_dir>/<sid>.subagent.<call_id>.json`` so the "
            "operator can re-read or navigate to the run later via "
            "``/subagents`` or ``alt+up`` / ``alt+down`` / "
            "``alt+enter``. Always set criticality=\"mutating\" — "
            "subagents may execute shells / edit files. Use "
            "\"destructive\" if the prompt asks for an irreversible "
            "operation. read_only is allowed only when the subagent "
            "is being run in plan/research mode.\n\n"
            "**PARALLEL FANOUT — PREFER ``BatchAgent`` WHEN N≥2.** "
            "When the user's task names MULTIPLE independent subagents "
            "(e.g. \"spawn claude, codex AND antigravity\", \"get 3 second "
            "opinions\", \"review with all engines\"), call "
            "``BatchAgent`` with ``runs: [{subagent_type, description, "
            "prompt}, …]`` ONCE — it dispatches every entry "
            "concurrently via ``asyncio.gather``. As a fallback (only "
            "if BatchAgent is unavailable), emit ALL ``Agent`` calls "
            "in a SINGLE assistant message (multi-tool-call); "
            "splitting them across turns serializes them and is a "
            "latency bug. Read-the-room: if the user says \"the whole "
            "point is speed\" or \"in parallel\" or \"in ONE "
            "message\", you MUST batch via BatchAgent."
        ),
        parameters=_params(
            {
                "subagent_type": {
                    "type": "string",
                    "description": (
                        "Subagent backend: ``general-purpose`` "
                        "(sibling rtxclaw agent) / ``claude`` / "
                        "``codex`` / ``antigravity``."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": (
                        "Short label of what this subagent run is "
                        "for (shown in the TUI's subagent box "
                        "header and in /subagents listings)."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "The full prompt for the subagent. Include "
                        "salient context (file paths, prior "
                        "findings) — the subagent does not see the "
                        "parent's conversation by default."
                    ),
                },
                "name": {
                    "type": "string",
                    "description": (
                        "When ``subagent_type=general-purpose``: "
                        "name of the sibling rtxclaw agent under "
                        "``~/.rtxclaw/agents/<name>`` (default "
                        "``main``). Ignored for claude / codex / "
                        "antigravity."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": (
                        "Optional model override forwarded to the "
                        "underlying CLI (claude / codex / antigravity "
                        "only)."
                    ),
                },
                "cwd": {
                    "type": "string",
                    "description": (
                        "Optional working directory for the spawned "
                        "subagent. Defaults to rtxclaw's launch cwd."
                    ),
                },
            },
            required=["subagent_type", "description", "prompt"],
        ),
    ),
    Tool(
        name="BatchAgent",
        kind=ToolKind.NETWORK,
        core=True,
        description=(
            "Dispatch MULTIPLE subagents concurrently in a SINGLE "
            "tool call. Equivalent to emitting N ``Agent`` calls in "
            "one assistant message, but takes only ONE tool_call to "
            "express — which small models reliably get right, whereas "
            "multi-tool-call emission routinely degrades to one-call-"
            "per-turn serialisation on <32B-param models.\n\n"
            "**USE WHENEVER N≥2 INDEPENDENT SUBAGENTS ARE NEEDED.** "
            "Examples: \"spawn claude, codex AND antigravity for a "
            "review\", \"get 3 second opinions\", \"fan out 5 "
            "explorers\", \"review with all engines in parallel\".\n\n"
            "``runs`` is a list of subagent specs; each entry takes "
            "the SAME fields as ``Agent`` (``subagent_type``, "
            "``description``, ``prompt``, optional ``name`` / "
            "``model`` / ``cwd``). The runner fans out via "
            "``asyncio.gather`` over the same backend as ``Agent`` — "
            "per-subagent session persistence at "
            "``<sessions_dir>/<sid>.subagent.<call_id>.json``, "
            "per-subagent ``tool_use`` event streaming, per-subagent "
            "TUI box are all preserved. Returns ONE tool_result body "
            "concatenating each run's output with a "
            "``=== run <i> [<subagent_type>:<name>] ===`` header.\n\n"
            "criticality is the max-cautious of all entries — if any "
            "run is ``destructive`` the whole call is destructive. "
            "Default ``mutating``. Use ``read_only`` only when EVERY "
            "run is read-only AND in plan/research mode."
        ),
        parameters=_params(
            {
                "runs": {
                    "type": "array",
                    "description": (
                        "List of subagent dispatch specs; each entry "
                        "has the same shape as the ``Agent`` tool's "
                        "arguments. All entries fan out in parallel."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "subagent_type": {
                                "type": "string",
                                "description": (
                                    "Backend: ``general-purpose`` / "
                                    "``claude`` / ``codex`` / "
                                    "``antigravity``."
                                ),
                            },
                            "description": {
                                "type": "string",
                                "description": (
                                    "Short label shown in the TUI "
                                    "subagent box header."
                                ),
                            },
                            "prompt": {
                                "type": "string",
                                "description": (
                                    "Full prompt for this subagent. "
                                    "Self-contained — subagent does "
                                    "not see parent's conversation."
                                ),
                            },
                            "name": {
                                "type": "string",
                                "description": (
                                    "For ``general-purpose``: sibling "
                                    "agent name (default ``main``)."
                                ),
                            },
                            "model": {
                                "type": "string",
                                "description": (
                                    "Optional model override for the "
                                    "underlying CLI."
                                ),
                            },
                            "cwd": {
                                "type": "string",
                                "description": (
                                    "Optional cwd override."
                                ),
                            },
                        },
                        "required": ["subagent_type", "description", "prompt"],
                    },
                },
            },
            required=["runs"],
        ),
    ),
)


# The ``delegate_*`` tools (delegate_claude / delegate_codex /
# delegate_antigravity / delegate_agent) are intentionally NOT exported in
# ``BUILTIN_TOOLS`` — they're rtxclaw-isms with no Claude Code parity.
# The model only sees the canonical ``Agent`` tool above; the
# ``Agent`` runner dispatches to the corresponding internal shim
# based on ``subagent_type``. The shims (``shim_run_delegate_*``)
# remain importable for the slash-command path (``/claude``,
# ``/codex``, ``/antigravity``) which bypasses the model and dispatches
# directly.
_HIDDEN_LEGACY_TOOL_NAMES = frozenset({
    "delegate_claude",
    "delegate_codex",
    "delegate_antigravity",
    "delegate_agent",
})
BUILTIN_TOOLS = tuple(
    t for t in BUILTIN_TOOLS
    if t.name not in _HIDDEN_LEGACY_TOOL_NAMES
)


@dataclass
class ToolRegistry:
    """Lookup table over a set of `Tool` objects, by name."""

    tools: tuple[Tool, ...] = BUILTIN_TOOLS

    def __post_init__(self) -> None:
        self._by_name: dict[str, Tool] = {t.name: t for t in self.tools}

    def get(self, name: str) -> Tool | None:
        return self._by_name.get(name)

    def names(self) -> list[str]:
        return list(self._by_name.keys())

    def openai_schemas(self) -> list[dict[str, Any]]:
        """Return `tools[]` payload for `chat/completions`."""
        return [t.openai_schema() for t in self.tools]

    # ---- deferral helpers ---------------------------------------------

    def core_tools(self) -> tuple[Tool, ...]:
        """Subset of tools always-loaded into the worker's tools[]
        payload. Currently: file ops + grep + exec + todo +
        ``tool_search`` itself."""
        return tuple(t for t in self.tools if t.core)

    def deferred_tools(self) -> tuple[Tool, ...]:
        """Subset whose schemas are NOT pre-loaded — the model fetches
        them via ``tool_search`` when needed. Mostly: web/memory/skill/
        delegate/MCP tools. About 10× cheaper to keep them in a name+
        description catalog than in the full schema list."""
        return tuple(t for t in self.tools if not t.core)

    def filtered_schemas(self, allowed_names: set[str]) -> list[dict[str, Any]]:
        """Return `tools[]` payload restricted to ``allowed_names``.

        Order matches the canonical ``BUILTIN_TOOLS`` order so the
        prefix the upstream sees is byte-stable across rounds (the
        prefix-cache friendly path).
        """
        return [t.openai_schema() for t in self.tools if t.name in allowed_names]

    def deferred_catalog_block(self) -> str:
        """Render a compact ``# DEFERRED TOOLS`` block for the system
        prompt: one line per deferred tool listing name + the first
        sentence of its description. The model picks the name it
        needs and calls ``tool_search`` to load full schemas. Empty
        when every tool is core (no deferral active).
        """
        deferred = self.deferred_tools()
        if not deferred:
            return ""
        lines = [
            "# DEFERRED TOOLS",
            "",
            "These tools exist but their schemas aren't loaded yet. Call "
            "``ToolSearch`` with the names you need (e.g. "
            "``select:WebSearch,memory_search``) to load schemas.",
            "",
        ]
        for t in deferred:
            short = (t.description or "").split(".")[0].strip()
            if len(short) > 110:
                short = short[:107] + "…"
            lines.append(f"- **{t.name}** — {short}")
        lines.append("")
        return "\n".join(lines)


# ---- MCP tool injection (standard pattern) ------------------------------


def discovered_mcp_tools_sync() -> tuple[Tool, ...]:
    """Synchronous cache reader. Returns whatever ``discovered_mcp_tools``
    last loaded — empty tuple if no async caller has warmed the cache yet
    in this process. Use this from sync call sites (e.g. ``_build_worker_request``)
    that run inside the same event loop AFTER an async caller has run
    discovery."""
    from rtxclaw_mcp.mcp_client import _DISCOVERED_TOOLS, mcp_tool_namespaced
    if not _DISCOVERED_TOOLS:
        return ()
    out: list[Tool] = []
    for server, tname, desc, schema in _DISCOVERED_TOOLS:
        props = (schema.get("properties") if isinstance(schema, dict) else {}) or {}
        required = (schema.get("required") if isinstance(schema, dict) else []) or []
        if not isinstance(props, dict):
            props = {}
        if not isinstance(required, list):
            required = []
        wrapped = _params(props, list(required))
        out.append(Tool(
            name=mcp_tool_namespaced(server.name, tname),
            kind=ToolKind.NETWORK,
            description=desc or f"MCP tool from server {server.name!r}.",
            parameters=wrapped,
        ))
    return tuple(out)


async def discovered_mcp_tools() -> tuple[Tool, ...]:
    """Return ``Tool`` objects for every tool advertised by every
    configured MCP server, named ``mcp__<server>__<tool>`` (Claude
    Code's namespacing convention). Returns an empty tuple if no
    servers are configured or all of them failed to start.

    Discovery is cached at the rtxclaw_mcp module level — the first
    call spawns each server, subsequent calls reuse the cache. Call
    ``rtxclaw_mcp.mcp_client.invalidate_discovery_cache()`` to force
    a re-discover (e.g. after editing the config).

    Each MCP tool is registered as ``ToolKind.NETWORK`` since calling
    out to an external server matches the existing permission gate
    for ``web_fetch`` etc. The tool's `inputSchema` is wrapped to
    include the standard `criticality` field rtxclaw expects on every
    parameter object.
    """
    from rtxclaw_mcp.mcp_client import (
        discover_all_tools,
        mcp_tool_namespaced,
    )
    discovered = await discover_all_tools()
    out: list[Tool] = []
    for server, tname, desc, schema in discovered:
        # Wrap the server's inputSchema with the criticality field.
        props = (schema.get("properties") if isinstance(schema, dict) else {}) or {}
        required = (schema.get("required") if isinstance(schema, dict) else []) or []
        if not isinstance(props, dict):
            props = {}
        if not isinstance(required, list):
            required = []
        wrapped = _params(props, list(required))
        out.append(Tool(
            name=mcp_tool_namespaced(server.name, tname),
            kind=ToolKind.NETWORK,
            description=desc or f"MCP tool from server {server.name!r}.",
            parameters=wrapped,
        ))
    return tuple(out)
