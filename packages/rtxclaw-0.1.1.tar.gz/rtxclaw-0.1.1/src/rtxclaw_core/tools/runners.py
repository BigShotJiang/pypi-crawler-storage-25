"""Tool implementations — the actual functions behind `BUILTIN_TOOLS`.

Each runner takes the tool's `arguments` dict (already parsed from JSON
by the caller) and returns a `ToolResult` whose `content` field is the
string the upstream LLM sees in the next turn's `role:"tool"` message.

Errors are caught and surfaced as `ok=False` results — the model gets
the error text and can decide how to proceed instead of the agent
crashing the whole turn. Long outputs are truncated; the truncation is
visible to the model so it knows there's more.
"""
from __future__ import annotations

import asyncio
import fnmatch
import json
import os
import re
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

from rtxclaw_core.tools._log import log_event


# ---- subprocess group helpers (killability) -------------------------
#
# Every long-running subprocess we spawn — exec, delegate_claude,
# delegate_codex — runs in its own process group via
# `start_new_session=True`. On cancel/timeout we send the signal to the
# whole group with `os.killpg`, so a tool that itself shells out (the
# `claude` CLI launches `Bash`/`Read`/etc.; an `exec` `bash -c '…'`
# spawns commands behind the pipeline) doesn't leave orphaned
# descendants running after ESC. Calling `proc.kill()` alone only
# delivers the signal to the immediate child, which is the foundational
# killability bug this addresses.

async def _feed_stdin(proc: asyncio.subprocess.Process, data: bytes) -> None:
    """Write `data` to `proc.stdin` and close it.

    Used by the delegate runners to pass the prompt via stdin instead
    of argv — argv would hit Linux's ARG_MAX (~128 KiB) on large
    prompts. Errors are swallowed: a closed pipe means the child
    already exited (we'll surface its rc), and the caller's cancel
    path also closes the proc, both of which would otherwise raise
    here and shadow the real failure.
    """
    if proc.stdin is None:
        return
    try:
        proc.stdin.write(data)
        await proc.stdin.drain()
    except (BrokenPipeError, ConnectionResetError, OSError):
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:  # noqa: BLE001
            pass


def _kill_group(proc: asyncio.subprocess.Process, sig: int = signal.SIGTERM) -> None:
    """Best-effort send `sig` to the entire process group of `proc`.

    Falls back to per-process kill if the group lookup fails (the
    process already exited, or the platform doesn't have process
    groups). All exceptions are swallowed — this is called from cancel
    paths where re-raising would mask the original cancellation.
    """
    if proc.pid is None:
        return
    try:
        pgid = os.getpgid(proc.pid)
    except (ProcessLookupError, PermissionError, OSError):
        # Process gone or we lost permission. Try the immediate kill.
        try:
            proc.send_signal(sig)
        except ProcessLookupError:
            pass
        return
    try:
        os.killpg(pgid, sig)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.send_signal(sig)
        except ProcessLookupError:
            pass


async def _terminate_group(
    proc: asyncio.subprocess.Process,
    *,
    grace_s: float = 1.0,
) -> None:
    """SIGTERM the group, wait up to `grace_s` seconds, then SIGKILL.

    Used in cancel/timeout paths so well-behaved children get a chance
    to clean up but uncooperative ones don't pin the runner forever.
    """
    _kill_group(proc, signal.SIGTERM)
    try:
        await asyncio.wait_for(proc.wait(), timeout=grace_s)
        return
    except asyncio.TimeoutError:
        pass
    _kill_group(proc, signal.SIGKILL)
    try:
        await asyncio.wait_for(proc.wait(), timeout=grace_s)
    except asyncio.TimeoutError:
        pass


# --- Delegate-CLI read timeouts -------------------------------------
# A spawned delegate CLI (`claude -p` / `codex exec` / antigravity) can
# stall before emitting ANY output — a hung SessionStart hook, an auth or
# network wedge, a spawn that never reaches the model. claude had only a
# 900s idle timer (so a startup stall was invisible for ~15 min); codex and
# antigravity had no read timeout at all and would block on `readline()`
# forever. These bound the wait so a stall fails fast with a clear error
# instead of a silent freeze that needs an ESC / gateway restart to clear.
def _delegate_first_token_timeout_s() -> float:
    """Seconds to wait for a delegate CLI's FIRST stream event before
    treating its startup as stalled. Env override:
    ``RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S`` (default 60)."""
    try:
        return float(
            os.environ.get("RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S", "60") or "60"
        )
    except ValueError:
        return 60.0


def _delegate_idle_timeout_s() -> float:
    """Seconds of silence AFTER output has started before treating a
    delegate CLI as hung (one long tool call is legitimate). Env override:
    ``RTXCLAW_DELEGATE_IDLE_TIMEOUT_S`` (default 900)."""
    try:
        return float(
            os.environ.get("RTXCLAW_DELEGATE_IDLE_TIMEOUT_S", "900") or "900"
        )
    except ValueError:
        return 900.0


async def _delegate_readline(
    stream: asyncio.StreamReader,
    *,
    got_first_event: bool,
    first_token_timeout_s: float,
    idle_timeout_s: float,
) -> bytes:
    """One delegate-CLI stdout line, bounded by a startup or idle timeout.

    Before the first event arrives the wait is bounded by
    ``first_token_timeout_s`` (catches a CLI that never starts emitting);
    afterwards by ``idle_timeout_s``. Raises :class:`asyncio.TimeoutError`
    when the stream stalls past the applicable bound so the caller can fail
    the turn fast instead of blocking on ``readline()`` until ESC (claude)
    or forever (codex / antigravity, which had no read timeout).
    """
    timeout = first_token_timeout_s if not got_first_event else idle_timeout_s
    return await asyncio.wait_for(stream.readline(), timeout=timeout)


MAX_OUTPUT_BYTES = 64 * 1024  # 64 KiB cap per tool result

# Hard upper bound on the bytes a single `read_file` call will pull off
# disk before refusing. The runner truncates the *returned* content to
# `MAX_OUTPUT_BYTES`, but without a pre-read cap a multi-GB log file
# would still be slurped into memory and OOM-kill the runner. Source
# code rarely needs more than this; for genuinely-large files use
# `grep` or split the read into ranges.
READ_FILE_MAX_BYTES = 50 * 1024 * 1024  # 50 MiB

# Hard upper bound on the bytes `web_fetch` will pull from the
# upstream HTTP response. trafilatura is happy with much less than
# this; the cap exists to prevent a single misdirected fetch from
# materialising a 500 MB response into memory before the runner gets a
# chance to truncate.
WEB_FETCH_MAX_BYTES = 8 * 1024 * 1024  # 8 MiB

# Directories `run_grep` skips by default. The previous implementation
# walked everything (including `.git/`, `node_modules/`, `__pycache__/`,
# `.venv/`, `dist/`, `build/`, …) and decoded every file in full, which
# turned a single grep on a real repo into a 2-minute disk-bound spin.
# Pruning these is the single biggest win.
_GREP_IGNORE_DIRS: frozenset[str] = frozenset({
    ".git", ".hg", ".svn", ".bzr",
    "node_modules", "bower_components",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".venv", "venv", ".env", "env",
    "dist", "build", "target", "out", ".output",
    ".tox", ".cache", ".idea", ".vscode",
    ".next", ".nuxt", ".gradle",
    ".rtxclaw", ".claude",
})
# Per-file cap: above this, skip rather than decode. Source code is
# rarely this big; this dodges multi-GB log files / model dumps that
# dominate runtime when grep accidentally points at one.
_GREP_MAX_FILE_BYTES = 10 * 1024 * 1024  # 10 MiB
# Hard ceiling on files examined per grep call. Without this, pointing
# grep at `~` or `/` walks the entire tree (millions of inodes under
# `.cache`, `.local/share`, etc.) before any other limit applies.
_GREP_MAX_FILES = 10000
# Max recursion depth from the root path. Caps pathological deeply
# nested trees (e.g. node_modules-style fan-out we somehow didn't prune).
_GREP_MAX_DEPTH = 15
# Wall-clock budget for one grep invocation. After this, we stop and
# return what we have plus a warning, rather than block the agent loop.
_GREP_TIMEOUT_S = 30.0
# `EXEC_TIMEOUT_DEFAULT_S` is an IDLE timeout: kill if no stdout/stderr
# arrives for this many seconds. A healthy long-running command that
# keeps producing output (a build, a test suite, `pytest -v`, a long
# Python script that prints progress) is NOT killed when it crosses
# 60s wall time, only if it goes silent for 60s.
EXEC_TIMEOUT_DEFAULT_S = 60.0
# Hard upper bound regardless of output activity. A perfectly chatty
# infinite loop (`while True: print('.')`) would never trip the idle
# timer, so this is the safety net. 30 min is comfortable for big test
# suites and ML training scripts; the model can override per-call.
EXEC_WALL_TIMEOUT_DEFAULT_S = 1800.0


@dataclass(frozen=True)
class ToolResult:
    """One tool invocation's result.

    `content` goes back to the model as the `tool` message body. `ok` is
    metadata for the agent runtime / TUI to render success vs failure
    indicators; the model only sees `content`.
    """

    content: str
    ok: bool = True
    truncated: bool = False


def _truncate(text: str) -> tuple[str, bool]:
    enc = text.encode("utf-8")
    if len(enc) <= MAX_OUTPUT_BYTES:
        return text, False
    head = enc[:MAX_OUTPUT_BYTES].decode("utf-8", "ignore")
    return (
        head + f"\n\n[... truncated, {len(enc) - MAX_OUTPUT_BYTES} more bytes ...]",
        True,
    )


def _err(msg: str) -> ToolResult:
    return ToolResult(content=f"error: {msg}", ok=False)


def _build_delegate_spawn_env(args: dict[str, Any]) -> Optional[dict[str, str]]:
    """Return the env dict to hand to ``create_subprocess_exec`` for a
    CLI delegate spawn (claude / codex / antigravity).

    When the engine passed ``_spawn_env_overrides`` (per-agent API
    keys lifted from ``~/.rtxclaw/agents/<name>/secrets.env``), we
    overlay them on top of ``os.environ`` so the CLI subprocess
    inherits everything the operator put in process env PLUS the
    per-agent overrides. Per-agent values WIN (same precedence as
    ``AgentConfig.upstream_headers``).

    Returns ``None`` when no overrides exist — the runner passes
    ``env=None`` and the subprocess inherits the parent's env
    verbatim (the legacy behaviour).
    """
    overrides = args.get("_spawn_env_overrides")
    if not isinstance(overrides, dict) or not overrides:
        return None
    return {**os.environ, **{str(k): str(v) for k, v in overrides.items()}}


# ---- read tools ----

def _coerce_line_arg(value: Any, name: str) -> tuple[Optional[int], Optional[str]]:
    if value is None:
        return None, None
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None, f"{name} must be an integer"
    if n < 1:
        return None, f"{name} must be >= 1"
    return n, None


def run_read_file(args: dict[str, Any]) -> ToolResult:
    # Claude Code's ``Read`` schema: ``file_path`` + ``offset`` (1-based
    # start) + ``limit`` (lines to read). We accept either Claude args
    # or the legacy rtxclaw args (``path`` / ``start_line`` / ``end_line``)
    # so /claude-delegated calls and existing rtxclaw call sites both
    # land here.
    path = args.get("file_path") or args.get("path")
    if not isinstance(path, str) or not path:
        return _err("file_path required")
    raw_start = args.get("offset")
    if raw_start is None:
        raw_start = args.get("start_line")
    raw_limit = args.get("limit")
    raw_end = args.get("end_line")
    start_line, err = _coerce_line_arg(raw_start, "offset")
    if err:
        return _err(err)
    if raw_limit is not None:
        limit_int, err = _coerce_line_arg(raw_limit, "limit")
        if err:
            return _err(err)
        if start_line is None:
            start_line = 1
        end_line = (start_line - 1) + (limit_int or 0)
    else:
        end_line, err = _coerce_line_arg(raw_end, "end_line")
        if err:
            return _err(err)
    if start_line is not None and end_line is not None and end_line < start_line:
        return _err("end_line/limit must be >= offset")
    p = Path(path).expanduser()
    # Stat first so we can refuse oversize files BEFORE materialising
    # them. A 5 GB log would otherwise OOM-kill the runner.
    try:
        st = p.stat()
    except (OSError, FileNotFoundError) as e:
        return _err(f"{e}")
    if st.st_size > READ_FILE_MAX_BYTES:
        return _err(
            f"file too large: {st.st_size} bytes exceeds "
            f"READ_FILE_MAX_BYTES={READ_FILE_MAX_BYTES}. "
            "Use `grep` to extract a portion, or read line ranges via "
            "`memory_get` (for memory files) / a slice tool."
        )
    try:
        # Read up to READ_FILE_MAX_BYTES + 1 so a file that grew between
        # stat() and read() is still capped — the +1 lets us detect the
        # race and surface it as a normal truncation.
        with open(p, "rb") as fh:
            blob = fh.read(READ_FILE_MAX_BYTES + 1)
    except (OSError, IsADirectoryError) as e:
        return _err(f"{e}")
    if len(blob) > READ_FILE_MAX_BYTES:
        return _err(
            f"file grew past READ_FILE_MAX_BYTES={READ_FILE_MAX_BYTES} "
            "during read; refusing to materialise."
        )
    body = blob.decode("utf-8", errors="replace")
    if start_line is not None or end_line is not None:
        lines = body.splitlines(keepends=True)
        lo = (start_line - 1) if start_line is not None else 0
        hi = end_line if end_line is not None else len(lines)
        body = "".join(lines[lo:hi])
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


def run_list_dir(args: dict[str, Any]) -> ToolResult:
    path = args.get("path") or "."
    if not isinstance(path, str):
        return _err("path must be a string")
    try:
        entries = sorted(os.listdir(Path(path).expanduser()))
    except OSError as e:
        return _err(f"{e}")
    body = "\n".join(entries) if entries else "(empty)"
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


def run_glob(args: dict[str, Any]) -> ToolResult:
    """Find files matching a glob pattern. Returns absolute paths
    sorted by mtime (most recent first), one per line. Mirrors
    Claude Code's ``Glob`` tool."""
    import glob as _glob
    pattern = args.get("pattern")
    if not isinstance(pattern, str) or not pattern:
        return _err("pattern required")
    root = args.get("path")
    if isinstance(root, str) and root:
        # Anchor the pattern to the given root if it's relative.
        if not pattern.startswith("/"):
            pattern = str(Path(root).expanduser() / pattern)
    else:
        pattern = str(Path(pattern).expanduser())
    try:
        matches = _glob.glob(pattern, recursive=True)
    except OSError as e:
        return _err(f"glob failed: {e}")
    # mtime-desc sort so the most relevant edits surface first.
    rows: list[tuple[float, str]] = []
    for p in matches:
        try:
            mtime = os.stat(p).st_mtime
        except OSError:
            continue
        rows.append((mtime, p))
    rows.sort(key=lambda r: -r[0])
    if not rows:
        return ToolResult(content="No files found", ok=True, truncated=False)
    body = "\n".join(p for _, p in rows[:500])
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


def run_exit_plan_mode(args: dict[str, Any]) -> ToolResult:
    """Plan-mode exit signal. Returns the plan as the tool result so
    the surrounding runner / TUI can show it to the user. The actual
    mode flip is handled out-of-band by the runner that consumes
    this result (the tool itself doesn't mutate the session mode —
    that's the operator's call after seeing the plan).
    """
    plan = args.get("plan") or ""
    if not isinstance(plan, str) or not plan.strip():
        return _err("plan required")
    body = (
        "Plan ready — confirm to leave plan mode and execute:\n\n"
        + plan.strip()
    )
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


def run_grep(args: dict[str, Any]) -> ToolResult:
    # Claude Code's ``Grep`` accepts ``pattern, path, glob, output_mode,
    # -n, -i, head_limit`` (plus -A/-B/-C/type/multiline). Translate
    # those to rtxclaw's existing path/include scan + post-process for
    # output_mode and head_limit. Legacy ``include`` arg is still
    # accepted as an alias for ``glob``.
    pattern = args.get("pattern")
    path = args.get("path") or "."
    glob_pat = args.get("glob") or args.get("include")
    output_mode = (args.get("output_mode") or "content").strip().lower()
    show_lineno = bool(args.get("-n", True))
    case_insensitive = bool(args.get("-i", False))
    head_limit_raw = args.get("head_limit")
    try:
        head_limit = int(head_limit_raw) if head_limit_raw is not None else 500
    except (TypeError, ValueError):
        head_limit = 500
    if not isinstance(pattern, str) or not pattern:
        return _err("pattern required")
    try:
        flags = re.IGNORECASE if case_insensitive else 0
        regex = re.compile(pattern, flags)
    except re.error as e:
        return _err(f"bad regex: {e}")
    root = Path(path).expanduser()
    if not root.exists():
        return _err(f"path not found: {path}")
    include_glob = glob_pat if isinstance(glob_pat, str) and glob_pat else None

    deadline = time.monotonic() + _GREP_TIMEOUT_S
    hits: list[str] = []
    files_examined = 0
    stop_reason: Optional[str] = None

    def _scan_one(p: Path) -> None:
        try:
            st = p.stat()
        except OSError:
            return
        if st.st_size > _GREP_MAX_FILE_BYTES:
            return
        try:
            with open(p, "rb") as fh:
                blob = fh.read()
        except OSError:
            return
        # Sniff for binary content: any NUL in the first 8 KiB is a strong
        # signal (matches what `grep -I` does). Skips git pack files,
        # compiled artifacts, images, etc.
        if b"\x00" in blob[:8192]:
            return
        text = blob.decode("utf-8", errors="replace")
        file_match_count = 0
        for i, line in enumerate(text.splitlines(), 1):
            if regex.search(line):
                file_match_count += 1
                if output_mode == "files_with_matches":
                    # Defer emission — we only need ONE hit per file.
                    continue
                if output_mode == "count":
                    continue
                if show_lineno:
                    hits.append(f"{p}:{i}:{line}")
                else:
                    hits.append(f"{p}:{line}")
                if len(hits) >= head_limit:
                    return
        if output_mode == "files_with_matches" and file_match_count:
            hits.append(str(p))
            if len(hits) >= head_limit:
                return
        if output_mode == "count" and file_match_count:
            hits.append(f"{p}:{file_match_count}")
            if len(hits) >= head_limit:
                return

    if root.is_file():
        files_examined = 1
        _scan_one(root)
    else:
        root_str = str(root)
        # Walk and search in the same loop so file-count / depth /
        # timeout limits can short-circuit before we waste a full walk
        # building a candidate list.
        for dirpath, dirnames, filenames in os.walk(root):
            rel = os.path.relpath(dirpath, root_str)
            depth = 0 if rel == "." else rel.count(os.sep) + 1
            if depth >= _GREP_MAX_DEPTH:
                # Don't descend any deeper; still scan files at this level.
                dirnames[:] = []
            else:
                dirnames[:] = [d for d in dirnames if d not in _GREP_IGNORE_DIRS]
            for fn in filenames:
                if include_glob and not fnmatch.fnmatch(fn, include_glob):
                    continue
                if time.monotonic() >= deadline:
                    stop_reason = (
                        f"(search stopped after {_GREP_TIMEOUT_S}s, "
                        "consider narrowing path)"
                    )
                    break
                if files_examined >= _GREP_MAX_FILES:
                    stop_reason = (
                        f"(search stopped: examined {_GREP_MAX_FILES} files, "
                        "consider narrowing path or using include filter)"
                    )
                    break
                files_examined += 1
                _scan_one(Path(dirpath) / fn)
                if len(hits) >= head_limit:
                    break
            if stop_reason or len(hits) >= head_limit:
                break
    body = "\n".join(hits) if hits else "(no matches)"
    if stop_reason:
        body = f"{body}\n{stop_reason}"
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


# ---- write tools ----

def run_write_file(args: dict[str, Any]) -> ToolResult:
    # Accept Claude Code's ``file_path`` AND legacy ``path``.
    path = args.get("file_path") or args.get("path")
    content = args.get("content")
    if not isinstance(path, str) or not path:
        return _err("file_path required")
    if not isinstance(content, str):
        return _err("content must be a string")
    try:
        p = Path(path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    except OSError as e:
        return _err(f"{e}")
    return ToolResult(content=f"wrote {len(content)} chars to {path}", ok=True)


def run_edit_file(args: dict[str, Any]) -> ToolResult:
    # Accept Claude Code's ``file_path / old_string / new_string /
    # replace_all`` AND legacy ``path / old / new``.
    path = args.get("file_path") or args.get("path")
    old = args.get("old_string") if args.get("old_string") is not None else args.get("old")
    new = args.get("new_string") if args.get("new_string") is not None else args.get("new")
    replace_all = bool(args.get("replace_all", False))
    if not isinstance(path, str) or not path:
        return _err("file_path required")
    if not isinstance(old, str) or old == "":
        return _err("old_string (non-empty) required")
    if not isinstance(new, str):
        return _err("new_string must be a string")
    try:
        p = Path(path).expanduser()
        body = p.read_text(encoding="utf-8")
    except OSError as e:
        return _err(f"{e}")
    occurrences = body.count(old)
    if occurrences == 0:
        return _err(f"old_string not found in {path}")
    if occurrences > 1 and not replace_all:
        return _err(
            f"old_string is not unique in {path} ({occurrences} occurrences). "
            f"Pass replace_all=true to substitute every match."
        )
    if replace_all:
        new_body = body.replace(old, new)
    else:
        new_body = body.replace(old, new, 1)
    try:
        p.write_text(new_body, encoding="utf-8")
    except OSError as e:
        return _err(f"{e}")
    suffix = f" (×{occurrences})" if replace_all and occurrences > 1 else ""
    return ToolResult(
        content=f"edited {path} ({len(old)}→{len(new)} chars){suffix}",
        ok=True,
    )


def run_update_file(args: dict[str, Any]) -> ToolResult:
    """``Update`` — Claude Code's canonical file-edit tool.

    Identical contract to ``Edit`` (``old_string`` → ``new_string``);
    the name matches the "Update" label Claude Code shows for file
    edits. The rtxclaw TUI renders an ``Update`` call as a colored
    code-diff card — but that diff is computed *client-side* from the
    call's arguments (see ``UpdateMessage`` in ``rtxclaw_tui.app``),
    so the ``ToolResult.content`` here stays a one-line summary. That
    keeps the model's context lean AND means the Telegram frontend —
    which only ever echoes this summary, never the arguments — shows
    no code diff (TUI-only widget, by construction).
    """
    res = run_edit_file(args)
    if res.ok and res.content.startswith("edited "):
        return ToolResult(
            content="updated " + res.content[len("edited "):],
            ok=res.ok,
            truncated=res.truncated,
        )
    return res


# ---- exec ----

async def run_exec_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
) -> ToolResult:
    """Run a shell command, streaming its stdout/stderr line-by-line.

    Two timeouts:

    - `timeout` (idle, default 60s): kill if NO output arrives for this
      many seconds. A long-running command that keeps printing progress
      is NOT killed when it crosses 60s wall time. Each line resets the
      idle timer. This is what users actually want — the previous code
      killed a healthy, streaming exec at exactly 60s wall time.
    - `wall_timeout` (absolute, default 30 min): hard ceiling regardless
      of output activity. Catches a chatty infinite loop that would
      otherwise dodge the idle timer forever.

    Lines are pushed to `on_delta` (one call per line) so the parent
    tool_runner emits `delta` events the agent forwards as `tool_delta`
    SSE — the TUI shows live exec output the same way it shows
    `delegate_claude` text. stderr lines are tagged inline so the user
    can tell the streams apart.

    Killability stays unchanged: if the awaiting task is cancelled (ESC
    → SIGTERM on the tool_runner), the `finally` block kills the child
    subprocess so it doesn't keep running orphaned.
    """
    command = args.get("command")
    cwd = args.get("cwd")
    # Claude Code's ``Bash`` carries ``timeout`` in milliseconds (max
    # 600000) and a ``run_in_background`` flag. Translate the ms case
    # so the model can pass either shape.
    raw_timeout = args.get("timeout")
    if raw_timeout is None:
        idle_timeout = EXEC_TIMEOUT_DEFAULT_S
    else:
        try:
            t = float(raw_timeout)
        except (TypeError, ValueError):
            t = EXEC_TIMEOUT_DEFAULT_S
        # Heuristic: anything > 3600 is almost certainly ms (Claude
        # default = 120000 ms = 2 min; rtxclaw legacy default = 60 s).
        idle_timeout = (t / 1000.0) if t > 3600 else t
    wall_timeout = float(args.get("wall_timeout") or EXEC_WALL_TIMEOUT_DEFAULT_S)
    if not isinstance(command, str) or not command:
        return _err("command required")
    if args.get("run_in_background"):
        # Fire-and-forget shape: hand off to the Monitor runner so the
        # caller gets a ``bash_id`` they can drain via BashOutput /
        # terminate via KillShell.
        return await run_monitor_start_async({
            "command": command,
            "cwd": cwd,
            "description": args.get("description") or command[:60],
            "timeout_ms": int(args.get("timeout_ms") or wall_timeout * 1000),
            "persistent": False,
        })
    cwd_path: Optional[str] = None
    if isinstance(cwd, str) and cwd:
        cwd_path = str(Path(cwd).expanduser())
    try:
        # Bump the StreamReader buffer above asyncio's 64 KiB default so
        # a single huge line (e.g. an unwrapped JSON dump from a Python
        # script) doesn't blow up `readline()` with LimitOverrunError.
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd_path,
            limit=4 * 1024 * 1024,
            # New session = own process group. ESC / timeout sends
            # SIGTERM to the group via `_kill_group` so any commands
            # the shell spawned (a build, a `find`, a piped chain) get
            # the signal too, instead of being orphaned.
            start_new_session=True,
        )
    except OSError as e:
        return _err(f"spawn failed: {e}")

    out_chunks: list[str] = []
    err_chunks: list[str] = []
    loop = asyncio.get_running_loop()
    started_at = loop.time()
    last_output_at = started_at
    kill_reason: Optional[str] = None

    async def _drain(
        stream: Optional[asyncio.StreamReader],
        sink: list[str],
        is_stderr: bool,
    ) -> None:
        """Read one line at a time, append to `sink`, push as a delta.

        Returns naturally when the stream hits EOF (process exited and
        all buffered output has been drained).
        """
        nonlocal last_output_at
        if stream is None:
            return
        while True:
            try:
                line = await stream.readline()
            except ValueError:
                # Single line exceeded the StreamReader buffer. Skip
                # (don't drop the rest of the stream) — `readline`
                # raises but the buffer is left in a recoverable state.
                continue
            if not line:
                return
            text = line.decode("utf-8", "replace")
            sink.append(text)
            last_output_at = loop.time()
            if on_delta is not None:
                try:
                    on_delta(f"[stderr] {text}" if is_stderr else text)
                except Exception:  # noqa: BLE001
                    pass

    out_task = asyncio.create_task(_drain(proc.stdout, out_chunks, False))
    err_task = asyncio.create_task(_drain(proc.stderr, err_chunks, True))
    wait_task = asyncio.create_task(proc.wait())

    try:
        # Poll loop: sleep until the process exits OR until the next
        # idle/wall deadline. `asyncio.shield(wait_task)` prevents the
        # `wait_for` timeout from cancelling the underlying `proc.wait()`,
        # so we can keep re-awaiting it across iterations.
        while not wait_task.done():
            now = loop.time()
            idle_left = idle_timeout - (now - last_output_at)
            wall_left = wall_timeout - (now - started_at)
            if idle_left <= 0:
                kill_reason = (
                    f"killed: no output for {idle_timeout:.0f}s "
                    "(idle timeout)"
                )
                break
            if wall_left <= 0:
                kill_reason = (
                    f"killed: wall-clock {wall_timeout:.0f}s exceeded"
                )
                break
            sleep_for = min(idle_left, wall_left, 5.0)
            try:
                await asyncio.wait_for(
                    asyncio.shield(wait_task), timeout=sleep_for,
                )
            except asyncio.TimeoutError:
                # Loop again to re-check the deadlines.
                continue
        if kill_reason:
            await _terminate_group(proc, grace_s=2.0)
    except asyncio.CancelledError:
        # Send SIGTERM to the WHOLE group synchronously so descendants
        # don't outlive the cancellation. Don't `await proc.wait()`
        # from inside the cancelled coroutine — let the OS reap the
        # child as the runner shuts down.
        _kill_group(proc, signal.SIGTERM)
        # Brief escalation in case the group is uncooperative. We
        # can't await here, so fire SIGKILL immediately afterwards as
        # a belt-and-suspenders for descendants that ignore SIGTERM.
        _kill_group(proc, signal.SIGKILL)
        raise

    # Wait for the drain tasks AND the wait_task to finish so we don't
    # leak pending tasks into the loop's shutdown phase. Drain tasks
    # return on EOF (kernel delivers it as soon as the child exits)
    # so this should be near-instant; small timeout is a safety net.
    try:
        await asyncio.wait_for(
            asyncio.gather(
                out_task, err_task, wait_task, return_exceptions=True,
            ),
            timeout=2.0,
        )
    except asyncio.TimeoutError:
        for t in (out_task, err_task, wait_task):
            if not t.done():
                t.cancel()

    rc = proc.returncode if proc.returncode is not None else -9
    out = "".join(out_chunks)
    err = "".join(err_chunks)
    parts = [f"$ {command}"]
    if kill_reason:
        parts.append(f"[{kill_reason}]")
    else:
        parts.append(f"[exit {rc}]")
    if out.strip():
        parts.append("--- stdout ---")
        parts.append(out.rstrip())
    if err.strip():
        parts.append("--- stderr ---")
        parts.append(err.rstrip())
    body = "\n".join(parts)
    body, truncated = _truncate(body)
    return ToolResult(
        content=body,
        ok=(kill_reason is None and rc == 0),
        truncated=truncated,
    )


# ---- network ----

async def run_web_fetch_async(args: dict[str, Any]) -> ToolResult:
    """Fetch URL; for HTML, return the main article body as markdown.

    Raw HTML is never returned to the model — it's too noisy (nav,
    scripts, ads, inline base64 images blow the token budget for
    almost no signal). HTML/XML responses go through trafilatura,
    which isolates the article and emits markdown with
    headings/lists/tables/links preserved. If extraction fails or
    returns nothing, the call surfaces an error instead of falling
    back to raw HTML. Non-HTML responses (JSON, plain text, CSV)
    pass through unchanged.
    """
    import httpx
    url = args.get("url")
    if not isinstance(url, str) or not url:
        return _err("url required")
    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as c:
            # Stream the response so a misdirected fetch at a
            # 500 MB target is aborted at the cap rather than
            # materialised into memory before the truncation kicks in.
            async with c.stream("GET", url) as r:
                r.raise_for_status()
                ctype = r.headers.get("content-type", "").lower()
                buf = bytearray()
                async for chunk in r.aiter_bytes():
                    if not chunk:
                        continue
                    if len(buf) + len(chunk) > WEB_FETCH_MAX_BYTES:
                        room = WEB_FETCH_MAX_BYTES - len(buf)
                        if room > 0:
                            buf.extend(chunk[:room])
                        # Stop reading; the body we've already pulled is
                        # what the caller gets. Surface the cap so the
                        # model knows the page was clipped before
                        # extraction ran.
                        return _err(
                            f"response exceeded WEB_FETCH_MAX_BYTES="
                            f"{WEB_FETCH_MAX_BYTES} bytes (read "
                            f"{len(buf)} of an unknown total). "
                            "Refusing to materialise a body this large; "
                            "narrow the URL or use a paginated source."
                        )
                    buf.extend(chunk)
            try:
                raw = bytes(buf).decode("utf-8", errors="replace")
            except Exception as e:  # noqa: BLE001
                return _err(f"decode failed: {e}")
    except httpx.HTTPError as e:
        return _err(f"{e}")
    if "html" in ctype or "xml" in ctype:
        try:
            import trafilatura
        except ImportError:
            return _err(
                "trafilatura not installed — required for HTML extraction. "
                "It ships in the optional tooling: pip install 'rtxclaw[full]'"
            )
        try:
            md = trafilatura.extract(
                raw,
                url=url,
                output_format="markdown",
                include_links=True,
                include_tables=True,
                favor_precision=True,
            )
        except Exception as e:  # noqa: BLE001
            return _err(f"trafilatura extraction failed: {e}")
        if not md:
            return _err(
                f"no main content extracted from {url} "
                f"(content-type: {ctype or 'unknown'}, {len(raw)} bytes)"
            )
        text = md
    else:
        text = raw
    text, truncated = _truncate(text)
    return ToolResult(content=text, ok=True, truncated=truncated)


# ---- web search (Brave) ----

BRAVE_SEARCH_URL = "https://api.search.brave.com/res/v1/web/search"


def _resolve_brave_api_key() -> str:
    """Pick the Brave API key. Priority: `BRAVE_API_KEY` env > global config.

    The runner is a subprocess; reading the global config from disk
    keeps the secret out of the agent → runner request payload (which
    is otherwise the model-visible args dict).
    """
    env = os.environ.get("BRAVE_API_KEY")
    if env:
        return env
    try:
        from rtxclaw_core.agent import load_global_config
        return str(load_global_config().get("brave_api_key") or "")
    except Exception:  # noqa: BLE001
        return ""


async def run_web_search_async(args: dict[str, Any]) -> ToolResult:
    import httpx
    query = args.get("query")
    if not isinstance(query, str) or not query.strip():
        return _err("query required")
    api_key = _resolve_brave_api_key()
    if not api_key:
        return _err(
            "Brave API key not configured. "
            "Run `rtxclaw agent init` (or edit ~/.rtxclaw/config.json's "
            "`brave_api_key`) or set the BRAVE_API_KEY env var."
        )
    count = args.get("count")
    try:
        count_int = int(count) if count is not None else 5
    except (TypeError, ValueError):
        count_int = 5
    count_int = max(1, min(10, count_int))
    params: dict[str, Any] = {"q": query.strip(), "count": count_int}
    for k in ("freshness", "country", "language", "search_lang"):
        v = args.get(k)
        if isinstance(v, str) and v:
            params[k] = v
    headers = {
        "X-Subscription-Token": api_key,
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
    }
    try:
        async with httpx.AsyncClient(timeout=30.0) as c:
            r = await c.get(BRAVE_SEARCH_URL, headers=headers, params=params)
            if r.status_code == 401:
                return _err("Brave API: 401 unauthorized — bad or missing API key")
            if r.status_code == 429:
                return _err("Brave API: 429 rate-limited (free tier is ~1 qps / 1k qpm)")
            r.raise_for_status()
            data = r.json()
    except httpx.HTTPError as e:
        return _err(f"Brave API: {e}")
    results = ((data.get("web") or {}).get("results")) or []
    if not results:
        return ToolResult(
            content=f"# Web search: {query}\n\n(no results)",
            ok=True,
        )
    lines = [f"# Web search: {query}", ""]
    for i, item in enumerate(results, 1):
        title = (item.get("title") or "").strip()
        url = (item.get("url") or "").strip()
        desc = (item.get("description") or "").strip()
        lines.append(f"## {i}. {title}")
        if url:
            lines.append(url)
        if desc:
            lines.append("")
            lines.append(desc)
        lines.append("")
    body = "\n".join(lines)
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


# ---- delegation: external-agent bridges ----

# Map rtxclaw permission modes → claude --permission-mode values.
# Same table as `app._claude_permission_mode`; duplicated here so the
# tool runner doesn't have to import the TUI module.
#
# `auto` → `bypassPermissions` (not `acceptEdits`): in headless `-p`
# mode there's no human to answer a permission prompt, so anything that
# isn't a plain edit (Bash, Write to a new path, etc.) deadlocks under
# `acceptEdits`. `bypassPermissions` is the canonical full-bypass mode
# and is what the user opts into by cycling rtxclaw to `auto`.
_CLAUDE_MODE_MAP: dict[str, str] = {
    "plan": "plan",
    "ask": "default",
    "auto": "bypassPermissions",
}

# rtxclaw permission mode → ``antigravity --approval-mode`` flag value.
# Antigravity CLI's modes are: ``default`` (prompt for approval),
# ``auto_edit`` (auto-approve edit tools), ``yolo`` (auto-approve
# everything, equivalent to Claude's ``bypassPermissions``), ``plan``
# (read-only, mirrors Claude's plan mode).
_ANTIGRAVITY_MODE_MAP: dict[str, str] = {
    "plan": "plan",
    "ask": "default",
    "auto": "yolo",
}


def _resolve_delegate_cwd(
    args: dict[str, Any],
) -> tuple[Optional[str], Optional[str]]:
    """Validate and resolve the optional `cwd` arg for delegate_* runners.

    Returns `(cwd, None)` on success — `cwd` is an absolute path string
    suitable for `Popen(..., cwd=...)`, or `None` when the caller didn't
    pass one (in which case the spawned subprocess inherits rtxclaw's
    launch directory, the historical default we don't change).
    On failure returns `(None, error_msg)`; the runner should surface
    that as a tool-result error and skip spawning — a bad cwd is almost
    always a typo, so we fail loud rather than silently fall back.

    Relative paths are resolved against `os.getcwd()` (rtxclaw's launch
    cwd at the moment the runner subprocess invokes this), per the
    contract: "interpret as the model gives it, don't try to be clever".
    """
    raw = args.get("cwd")
    if raw is None:
        return None, None
    if not isinstance(raw, str) or not raw.strip():
        return None, "cwd must be a non-empty string when provided"
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = Path(os.getcwd()) / p
    try:
        resolved = p.resolve(strict=False)
    except OSError as e:
        return None, f"cwd resolve failed: {e}"
    if not resolved.exists():
        return None, f"cwd does not exist: {resolved}"
    if not resolved.is_dir():
        return None, f"cwd is not a directory: {resolved}"
    return str(resolved), None


def _log_delegate_error(
    delegate: str,
    reason: str,
    *,
    prompt: Optional[str] = None,
    cwd: Optional[str] = None,
    mode: Optional[str] = None,
    resume_id: Optional[str] = None,
    remote_session_id: Optional[str] = None,
    returncode: Optional[int] = None,
    stderr: Optional[str] = None,
    message: Optional[str] = None,
    event: Optional[dict[str, Any]] = None,
    **extra: Any,
) -> None:
    """Best-effort structured logging for delegate_* failures.

    Tool results intentionally stay compact because they are fed back
    into the model. The gateway log is where operators need the richer
    failure context: whether this was a stale resume, a subprocess
    launch problem, an API/context error surfaced by the delegate CLI,
    or a local validation failure.
    """
    fields: dict[str, Any] = {
        "rtxclaw_session_id": os.environ.get("RTXCLAW_SESSION_ID"),
        "agent_name": os.environ.get("RTXCLAW_AGENT_NAME"),
        "reason": reason,
        "mode": mode,
        "cwd": cwd or os.getcwd(),
        "resume_id": resume_id,
        "resumed": bool(resume_id),
        "remote_session_id": remote_session_id,
        "returncode": returncode,
        "prompt_chars": len(prompt) if isinstance(prompt, str) else None,
    }
    if stderr:
        fields["stderr_preview"] = stderr[:1000]
    if message:
        fields["message_preview"] = message[:1000]
    if event:
        fields.update({
            "subtype": event.get("subtype"),
            "api_error_status": event.get("api_error_status"),
            "terminal_reason": event.get("terminal_reason"),
            "result_preview": str(event.get("result") or "")[:1000],
            "usage": event.get("usage"),
            "model_usage": event.get("modelUsage"),
        })
    fields.update(extra)
    log_event(f"DELEGATE_{delegate.upper()}_ERROR", **fields)


def _claude_state_path(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[Path]:
    """Resolve the per-rtxclaw-session state file for `delegate_claude`.

    Callers (the engine pipeline) pass ``rtx_sid`` / ``rtx_sdir``
    explicitly so two concurrent CLI turns against the same agent
    can't race on process-wide ``os.environ``. Legacy direct callers
    (no agent context) get an env fallback for back-compat — same
    behavior as before. Returns ``None`` when neither args nor env
    yield a sid/sdir, in which case ``--resume`` is skipped and the
    call starts a fresh Claude session.
    """
    sid = rtx_sid or os.environ.get("RTXCLAW_SESSION_ID")
    sdir = rtx_sdir or os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return Path(sdir) / f"{sid}.delegate_claude.json"


def _read_claude_session_id(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[str]:
    p = _claude_state_path(rtx_sid, rtx_sdir)
    if p is None or not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    sid = data.get("claude_session_id") if isinstance(data, dict) else None
    return sid if isinstance(sid, str) and sid else None


def _write_claude_session_id(
    claude_sid: str,
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> None:
    p = _claude_state_path(rtx_sid, rtx_sdir)
    if p is None:
        return
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"claude_session_id": claude_sid}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


def _format_claude_tool_use(name: str, inp: Any) -> str:
    """Render an in-band marker for a `tool_use` block Claude emitted.

    Surfaces "Claude is calling Read foo.py" to the rtxclaw user without
    a separate event channel — the marker is appended to the same text
    stream Claude's prose flows through, so the existing TUI / Telegram
    consumers render it for free. Stable, compact format (no timestamps,
    no ids) so the marker also lands cleanly in the saved tool result
    that gets sent back to the local model on the next round.
    """
    try:
        args_json = json.dumps(inp, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        args_json = str(inp)
    if len(args_json) > 160:
        args_json = args_json[:160] + "…"
    return f"\n\n🔧 {name} {args_json}\n"


def _format_claude_tool_result(block: dict) -> str:
    """Render an in-band marker for a `tool_result` Claude received.

    Anthropic's tool_result `content` is either a plain string or a list
    of `{type: text, text: ...}` blocks; both shapes are flattened to a
    single line + char count so the user can see what came back without
    inflating context.
    """
    is_err = bool(block.get("is_error"))
    raw = block.get("content")
    if isinstance(raw, list):
        parts: list[str] = []
        for b in raw:
            if isinstance(b, dict) and b.get("type") == "text":
                parts.append(b.get("text") or "")
        text = "".join(parts)
    elif isinstance(raw, str):
        text = raw
    else:
        text = "" if raw is None else str(raw)
    n = len(text)
    head = next((line for line in text.splitlines() if line.strip()), "")
    summary = head.strip()[:140]
    arrow = "✗" if is_err else "↳"
    if summary:
        return f"{arrow} {summary} ({n} chars)\n"
    return f"{arrow} ({n} chars)\n"


# ---- delegate_antigravity helpers ----

def _antigravity_state_path(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[Path]:
    """Resolve the per-rtxclaw-session state file for ``delegate_antigravity``.

    Mirrors :func:`_claude_state_path` — engine-pipeline callers pass
    ``rtx_sid`` / ``rtx_sdir`` explicitly so concurrent CLI turns can't
    race on ``os.environ``; legacy direct callers fall back to env.
    """
    sid = rtx_sid or os.environ.get("RTXCLAW_SESSION_ID")
    sdir = rtx_sdir or os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return Path(sdir) / f"{sid}.delegate_antigravity.json"


def _read_antigravity_session_id(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[str]:
    p = _antigravity_state_path(rtx_sid, rtx_sdir)
    if p is None or not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    sid = data.get("antigravity_session_id") if isinstance(data, dict) else None
    return sid if isinstance(sid, str) and sid else None


def _write_antigravity_session_id(
    antigravity_sid: str,
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> None:
    p = _antigravity_state_path(rtx_sid, rtx_sdir)
    if p is None:
        return
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"antigravity_session_id": antigravity_sid}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


def _format_antigravity_tool_use(name: str, params: Any) -> str:
    """Render an in-band marker for a Antigravity ``tool_use`` event.

    Mirrors :func:`_format_claude_tool_use` so the surrounding TUI /
    Telegram renderers don't have to special-case Antigravity's payload —
    same ``🔧 <name> <json>`` shape, same compact JSON args, same
    160-char clamp. Stable, no timestamps, no ids — cache-friendly
    when the result is replayed via ``_build_messages``.
    """
    try:
        args_json = json.dumps(params, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        args_json = str(params)
    if len(args_json) > 160:
        args_json = args_json[:160] + "…"
    return f"\n\n🔧 {name} {args_json}\n"


def _format_antigravity_tool_result(event: dict) -> str:
    """Render an in-band marker for a Antigravity ``tool_result`` event.

    Pairs with :func:`_format_antigravity_tool_use`. Antigravity's stream-json
    ``tool_result`` carries ``status`` (``success`` / ``error``) and
    ``output`` (the textual result). We surface a 1-line summary plus
    char count, identical to the Claude variant.
    """
    is_err = str(event.get("status") or "").lower() not in ("success", "ok")
    raw = event.get("output")
    if isinstance(raw, list):
        parts: list[str] = []
        for b in raw:
            if isinstance(b, dict) and b.get("type") == "text":
                parts.append(b.get("text") or "")
            elif isinstance(b, str):
                parts.append(b)
        text = "".join(parts)
    elif isinstance(raw, str):
        text = raw
    else:
        text = "" if raw is None else str(raw)
    n = len(text)
    head = next((line for line in text.splitlines() if line.strip()), "")
    summary = head.strip()[:140]
    arrow = "✗" if is_err else "↳"
    if summary:
        return f"{arrow} {summary} ({n} chars)\n"
    return f"{arrow} ({n} chars)\n"


async def run_delegate_antigravity_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
    on_spawn: Optional[Callable[[Any], None]] = None,
) -> ToolResult:
    """Spawn ``antigravity -p '' ...`` and return its reply as the tool result.

    .. deprecated:: refactor-phase-4
       Legacy delegate-as-tool entry point. The new
       :class:`rtxclaw_core.agents.antigravity_engine.AntigravityCliEngine`
       reuses this via :meth:`delegate_runner`; the function stays
       until Phase 7's legacy sweep.


    Mirrors :func:`run_delegate_claude_async` against the Google
    Antigravity CLI (https://github.com/google-antigravity/gemini-cli). Streams
    ``--output-format stream-json`` (newline-delimited JSON events:
    ``init`` / ``message`` / ``tool_use`` / ``tool_result`` /
    ``result`` / ``error``) and forwards each text delta plus a
    compact in-band marker for every tool use the way the Claude
    runner does — the slash-command bridge (``/antigravity``) and the
    autonomous-tool path (``tool_delta`` SSE) consume the same
    ``on_delta`` callback, so live progress shows up everywhere
    without per-frontend code.

    Per-rtxclaw-session state: reads ``antigravity_session_id`` from
    ``<sessions_dir>/<sid>.delegate_antigravity.json`` and passes
    ``--resume <id>`` so a follow-up call continues the same
    Antigravity conversation. The new id is written back on success.

    Killability: a SIGTERM landing on this coroutine (via the
    parent ``tool_runner``'s signal handler) propagates through
    CancelledError; the ``finally`` block kills the antigravity
    subprocess so it doesn't keep running orphaned.

    Auth: requires ``ANTIGRAVITY_API_KEY`` (or the documented
    ``GOOGLE_GENAI_USE_VERTEXAI`` / ``GOOGLE_GENAI_USE_GCA``
    alternatives) in the runner's environment — operators put it
    in ``<agent>/.env`` the same way they put ``OPENROUTER_API_KEY``.
    """
    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return _err("prompt required")

    # Engine-pipeline session identity + mode — see :func:`run_delegate_claude_async`
    # for rationale. Concurrent CLI turns on the same agent must not
    # race on process-wide ``os.environ``.
    rtx_sid_arg = args.get("_rtxclaw_session_id")
    rtx_sid: Optional[str] = rtx_sid_arg if isinstance(rtx_sid_arg, str) and rtx_sid_arg else None
    rtx_sdir_arg = args.get("_rtxclaw_sessions_dir")
    rtx_sdir: Optional[str] = rtx_sdir_arg if isinstance(rtx_sdir_arg, str) and rtx_sdir_arg else None
    rtx_perm_arg = args.get("_rtxclaw_permission_mode")
    rtx_perm: str = rtx_perm_arg if isinstance(rtx_perm_arg, str) and rtx_perm_arg else ""

    mode_raw = args.get("mode")
    if isinstance(mode_raw, str) and mode_raw in _ANTIGRAVITY_MODE_MAP:
        antigravity_mode = _ANTIGRAVITY_MODE_MAP[mode_raw]
    else:
        rtx_mode = rtx_perm or os.environ.get("RTXCLAW_PERMISSION_MODE", "")
        antigravity_mode = _ANTIGRAVITY_MODE_MAP.get(rtx_mode, "default")

    spawn_cwd, cwd_err = _resolve_delegate_cwd(args)
    if cwd_err is not None:
        _log_delegate_error(
            "antigravity", "bad_cwd",
            prompt=prompt, cwd=os.getcwd(), mode=antigravity_mode,
            message=cwd_err,
        )
        return _err(cwd_err)

    force_fresh = bool(args.get("_rtxclaw_antigravity_no_resume"))
    # Resume-id override (new Agent/Engine pipeline). When the caller
    # is :class:`ExternalCliEngine`, the engine manages its own
    # sidecar and passes the resume id explicitly via
    # ``_force_resume_id``.
    forced_resume = args.get("_force_resume_id")
    if isinstance(forced_resume, str) and forced_resume:
        resume_id = None if force_fresh else forced_resume
    else:
        resume_id = None if force_fresh else _read_antigravity_session_id(rtx_sid, rtx_sdir)

    # System-prompt priming for the new Agent/Engine pipeline. Antigravity
    # CLI exposes a ``--system-prompt`` flag when available; on older
    # builds we fall back to a leading-user-message injection. Same
    # rationale as the codex/claude branches (antigravity final audit #1).
    appended_sys = args.get("_append_system_prompt")
    appended_sys_text = (
        appended_sys.strip()
        if isinstance(appended_sys, str) and appended_sys.strip()
        else ""
    )

    # Optional model override. Antigravity CLI defaults to
    # ``gemini-2.0-flash-exp`` (or whatever the user picked in
    # ``~/.antigravity/settings.json``); accept a tool arg so the local
    # model can dispatch to a stronger Antigravity model when it explicitly
    # wants to (``delegate_antigravity(prompt=..., model="gemini-2.5-pro")``).
    model_override = args.get("model")
    if not isinstance(model_override, str) or not model_override.strip():
        model_override = None

    # Prompt is piped on stdin (antigravity ``-p`` "Appended to input on
    # stdin (if any)" per --help). Empty ``-p ""`` is the
    # non-interactive trigger. Same trick we use for claude — argv
    # would hit Linux ARG_MAX on long context dumps.
    cmd = [
        "antigravity", "-p", "",
        "--output-format", "stream-json",
        "--approval-mode", antigravity_mode,
        "--skip-trust",  # tool runner already gated by permission system
    ]
    if model_override:
        cmd += ["--model", model_override]
    if resume_id:
        cmd += ["--resume", resume_id]
    if appended_sys_text:
        # Inject as a leading-user-message in the stdin stream so it
        # lands in the bound Antigravity session's state on the first call
        # and rides on every ``--resume`` after. (The antigravity CLI's
        # native --system-prompt flag isn't universally present
        # across versions; the leading-user-message form works
        # against every antigravity build.)
        prompt = (
            f"<system>\n{appended_sys_text}\n</system>\n\n"
            f"---\n\n{prompt}"
        )

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=16 * 1024 * 1024,
            start_new_session=True,
            cwd=spawn_cwd,
            env=_build_delegate_spawn_env(args),
        )
        if on_spawn is not None:
            try:
                on_spawn(proc)
            except Exception:  # noqa: BLE001
                pass
    except FileNotFoundError:
        _log_delegate_error(
            "antigravity", "spawn_failed",
            prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
            resume_id=resume_id,
            message="`antigravity` CLI not on PATH",
        )
        return _err(
            "`antigravity` CLI not on PATH. Install: "
            "`npm install -g @google/antigravity-cli`"
        )

    stdin_task = asyncio.create_task(_feed_stdin(proc, prompt.encode("utf-8")))

    text_buf: list[str] = []
    final_session_id: Optional[str] = resume_id
    is_error = False
    error_event: dict[str, Any] = {}
    seen_tool_uses: set[str] = set()
    seen_tool_results: set[str] = set()

    def _push(chunk: str) -> None:
        if not chunk:
            return
        text_buf.append(chunk)
        if on_delta is not None:
            try:
                on_delta(chunk)
            except Exception:  # noqa: BLE001
                pass

    def _push_marker(chunk: str) -> None:
        """Tool marker push. Keeps the inline ``🔧 …`` / ``↳ …``
        text in the persisted body but skips ``on_delta`` when
        ``on_event`` is wired — the structured event already drives
        a native widget on the frontend, so we don't want the inline
        text to render alongside it.
        """
        if not chunk:
            return
        text_buf.append(chunk)
        if on_event is None and on_delta is not None:
            try:
                on_delta(chunk)
            except Exception:  # noqa: BLE001
                pass

    try:
        if proc.stdout is None:
            raise RuntimeError("subprocess stdout pipe is None — spawn config bug")
        first_token_timeout_s = _delegate_first_token_timeout_s()
        idle_timeout_s = _delegate_idle_timeout_s()
        got_first_event = False
        while True:
            try:
                line = await _delegate_readline(
                    proc.stdout,
                    got_first_event=got_first_event,
                    first_token_timeout_s=first_token_timeout_s,
                    idle_timeout_s=idle_timeout_s,
                )
            except asyncio.TimeoutError:
                stage = "startup" if not got_first_event else "idle"
                secs = int(
                    first_token_timeout_s if not got_first_event else idle_timeout_s
                )
                # antigravity's finally does an UNBOUNDED proc.wait(); kill
                # the group first so it returns instead of hanging on a
                # stalled child.
                _kill_group(proc, signal.SIGTERM)
                _kill_group(proc, signal.SIGKILL)
                _log_delegate_error(
                    "antigravity", f"{stage}_timeout",
                    prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
                    resume_id=resume_id, remote_session_id=final_session_id,
                    returncode=proc.returncode,
                )
                return _err(
                    f"antigravity produced no output for {secs}s ({stage} "
                    "timeout) — the CLI appears stalled. Aborted instead of "
                    "hanging; tune via RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S "
                    "/ RTXCLAW_DELEGATE_IDLE_TIMEOUT_S."
                )
            except ValueError:
                got_first_event = True
                continue
            if not line:
                break
            got_first_event = True
            try:
                event = json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                continue
            etype = event.get("type")
            # ``init`` carries the session_id we'll persist for --resume
            # on the next call.
            if etype == "init":
                sid = event.get("session_id")
                if isinstance(sid, str) and sid:
                    final_session_id = sid
                continue
            if etype == "message":
                # Assistant message chunks. ``delta=true`` is a streaming
                # piece; the consolidated final message arrives with no
                # delta (or delta=false). We push deltas as-is for live
                # render, and skip the consolidated final to avoid
                # duplicating the body.
                role = event.get("role") or ""
                if role and role != "assistant":
                    continue
                content = event.get("content") or ""
                if not isinstance(content, str) or not content:
                    continue
                if event.get("delta"):
                    _push(content)
                else:
                    # Non-delta message: only push the suffix not yet
                    # streamed (mirror the Claude consolidated path so
                    # silent-stream Antigravity configs still show output).
                    already = "".join(text_buf)
                    if len(content) > len(already):
                        _push(content[len(already):])
                continue
            if etype == "tool_use":
                tu_id = event.get("tool_id") or ""
                if tu_id and tu_id in seen_tool_uses:
                    continue
                if tu_id:
                    seen_tool_uses.add(tu_id)
                name = event.get("tool_name") or "?"
                params = event.get("parameters") or {}
                _push_marker(_format_antigravity_tool_use(name, params))
                if on_event is not None:
                    try:
                        on_event({
                            "kind": "tool_use",
                            "id": tu_id,
                            "name": name,
                            "input": params if isinstance(params, dict) else {"_raw": params},
                        })
                    except Exception:  # noqa: BLE001
                        pass
                continue
            if etype == "tool_result":
                tu_id = event.get("tool_id") or ""
                if tu_id and tu_id in seen_tool_results:
                    continue
                if tu_id:
                    seen_tool_results.add(tu_id)
                _push_marker(_format_antigravity_tool_result(event))
                if on_event is not None:
                    out_field = (
                        event.get("output")
                        or event.get("content")
                        or event.get("text")
                        or ""
                    )
                    if isinstance(out_field, list):
                        parts: list[str] = []
                        for b in out_field:
                            if isinstance(b, dict) and b.get("type") == "text":
                                parts.append(str(b.get("text") or ""))
                            elif isinstance(b, str):
                                parts.append(b)
                        out_text = "".join(parts)
                    elif isinstance(out_field, str):
                        out_text = out_field
                    else:
                        out_text = str(out_field or "")
                    is_err = bool(event.get("is_error") or event.get("error"))
                    try:
                        on_event({
                            "kind": "tool_result",
                            "tool_use_id": tu_id,
                            "ok": not is_err,
                            "text": out_text,
                        })
                    except Exception:  # noqa: BLE001
                        pass
                continue
            if etype == "error":
                # Per the schema, ``error`` events are non-fatal warnings
                # — log but keep streaming. The terminal failure signal
                # is ``result`` with status != success.
                _log_delegate_error(
                    "antigravity", "stream_error",
                    prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
                    resume_id=resume_id, remote_session_id=final_session_id,
                    event=event,
                )
                continue
            if etype == "result":
                status_val = str(event.get("status") or "").lower()
                if status_val and status_val not in ("success", "ok"):
                    is_error = True
                    error_event = event
                continue
    except asyncio.CancelledError:
        _log_delegate_error(
            "antigravity", "cancelled",
            prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
        )
        _kill_group(proc, signal.SIGTERM)
        _kill_group(proc, signal.SIGKILL)
        raise
    finally:
        if not stdin_task.done():
            stdin_task.cancel()
        try:
            await stdin_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass

    if proc.returncode != 0 and not is_error:
        stderr_bytes = b""
        if proc.stderr is not None:
            try:
                stderr_bytes = await proc.stderr.read()
            except Exception:  # noqa: BLE001
                pass
        err_msg = stderr_bytes.decode("utf-8", "replace")[:400] or f"rc={proc.returncode}"
        _log_delegate_error(
            "antigravity", "nonzero_exit",
            prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
            stderr=stderr_bytes.decode("utf-8", "replace"),
        )
        return _err(f"antigravity exited {proc.returncode}: {err_msg}")

    if is_error:
        _log_delegate_error(
            "antigravity", "reported_error",
            prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
            event=error_event,
        )
        return _err(
            f"antigravity reported error: "
            f"{error_event.get('status') or 'unknown'}"
        )

    body_text = "".join(text_buf).strip()
    if not body_text:
        _log_delegate_error(
            "antigravity", "empty_response",
            prompt=prompt, cwd=spawn_cwd, mode=antigravity_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
        )
        return _err("antigravity returned empty response")

    if final_session_id:
        _write_antigravity_session_id(final_session_id, rtx_sid, rtx_sdir)

    header_bits = []
    if final_session_id:
        header_bits.append(f"session={final_session_id[:12]}")
    header_bits.append(f"mode={antigravity_mode}")
    if resume_id:
        header_bits.append("resumed")
    header = f"[antigravity {' · '.join(header_bits)}]"

    footer = (
        "\n\n[antigravity --resume note: Antigravity now has this exchange. On your "
        "next delegate_antigravity call in this rtxclaw session, only forward "
        "context that is NEW since this point — do not restate this "
        "reply or anything earlier.]"
    )

    body, truncated = _truncate(f"{header}\n\n{body_text}{footer}")
    return ToolResult(content=body, ok=True, truncated=truncated)


async def run_delegate_claude_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
    on_spawn: Optional[Callable[[Any], None]] = None,
) -> ToolResult:
    """Spawn `claude -p ...` and return its full reply as the tool result.

    Driver shared between two callers:

    * :class:`rtxclaw_core.agents.claude_engine.ClaudeCliEngine` via
      :meth:`delegate_runner` — drives a turn against the Claude CLI
      when an Agent's engine is ``claude_cli``.
    * The ``delegate_claude`` tool registry entry (via the
      :func:`rtxclaw_core.agents.delegate_shims.shim_run_delegate_claude_async`
      wrapper) — lets any agent dispatch a child turn to Claude as
      a regular tool call.

    Streams `--output-format stream-json --include-partial-messages` and
    forwards each text delta (Claude's prose) plus a compact in-band
    marker for every `tool_use` / `tool_result` block Claude emits, all
    through the same `on_delta` callback. The slash-command bridge
    (`/claude`) and the autonomous-tool path (`tool_delta` SSE) both
    consume that callback, so live progress — including which tools
    Claude itself is running under the hood — shows up in the TUI,
    Telegram, and any other SSE consumer with no per-frontend changes.

    When ``on_event`` is wired, Claude's inner ``tool_use`` /
    ``tool_result`` blocks are ALSO surfaced as structured events
    (``{"kind": "tool_use", "id", "name", "input"}`` /
    ``{"kind": "tool_result", "tool_use_id", "ok", "text"}``) so the
    frontend can mount native tool-call widgets — e.g., a
    ``TodoWrite`` inside ``/claude`` ticks the rtxclaw plan checklist
    the same way a local-model ``TodoWrite`` would. The inline text
    marker still lands in ``text_buf`` (so the persisted reply the
    local model replays on its next round retains a record of what
    Claude did), but it is NOT also sent through ``on_delta`` to the
    frontend — that would double-render. When ``on_event`` is
    ``None``, behaviour is unchanged: markers stream through
    ``on_delta`` just like before.

    Per-rtxclaw-session state: reads `claude_session_id` from
    `<sessions_dir>/<sid>.delegate_claude.json` and passes
    `--resume <id>` so a follow-up `delegate_claude` call continues the
    same Claude conversation. The new id is written back on success.

    Killability: a SIGTERM landing on this coroutine (via the parent
    `tool_runner`'s signal handler) propagates through CancelledError;
    the `finally` block kills the claude subprocess so it doesn't keep
    running orphaned.
    """
    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return _err("prompt required")

    # Engine-pipeline callers pass session identity + permission mode
    # through args so concurrent CLI turns on the same agent can't race
    # on process-wide ``os.environ``. Legacy direct callers leave these
    # absent and fall back to env reads — same behaviour as before.
    rtx_sid_arg = args.get("_rtxclaw_session_id")
    rtx_sid: Optional[str] = rtx_sid_arg if isinstance(rtx_sid_arg, str) and rtx_sid_arg else None
    rtx_sdir_arg = args.get("_rtxclaw_sessions_dir")
    rtx_sdir: Optional[str] = rtx_sdir_arg if isinstance(rtx_sdir_arg, str) and rtx_sdir_arg else None
    rtx_perm_arg = args.get("_rtxclaw_permission_mode")
    rtx_perm: str = rtx_perm_arg if isinstance(rtx_perm_arg, str) and rtx_perm_arg else ""

    mode_raw = args.get("mode")
    if isinstance(mode_raw, str) and mode_raw in _CLAUDE_MODE_MAP:
        claude_mode = _CLAUDE_MODE_MAP[mode_raw]
    else:
        # Inherit from the rtxclaw permission mode the agent is running
        # in. Engine callers pass it via ``_rtxclaw_permission_mode``;
        # legacy direct callers leave it absent and we fall back to the
        # env var. Falls back to ``default`` if neither yields a known
        # mode — same fallback as the slash command.
        rtx_mode = rtx_perm or os.environ.get("RTXCLAW_PERMISSION_MODE", "")
        claude_mode = _CLAUDE_MODE_MAP.get(rtx_mode, "default")

    # Optional `cwd`: if the caller passed one, validate it BEFORE
    # spawning so a typo fails loud with a clear tool-result error
    # instead of crashing the subprocess with a cryptic FileNotFoundError.
    spawn_cwd, cwd_err = _resolve_delegate_cwd(args)
    if cwd_err is not None:
        _log_delegate_error(
            "claude", "bad_cwd",
            prompt=prompt, cwd=os.getcwd(), mode=claude_mode,
            message=cwd_err,
        )
        return _err(cwd_err)

    force_fresh = bool(args.get("_rtxclaw_claude_no_resume"))
    retry_of = args.get("_rtxclaw_claude_retry_of")
    retry_of = retry_of if isinstance(retry_of, str) and retry_of else None
    # Resume-id override (new Agent/Engine pipeline). When the caller
    # is :class:`rtxclaw_core.agents.external_cli.ExternalCliEngine`,
    # the engine manages its own sidecar (``<sid>.claude_cli.json``)
    # and passes the resume id explicitly via ``_force_resume_id``
    # rather than letting us re-read the legacy
    # ``<sid>.delegate_claude.json``. ``force_fresh`` still wins.
    forced_resume = args.get("_force_resume_id")
    if isinstance(forced_resume, str) and forced_resume:
        resume_id = None if force_fresh else forced_resume
    else:
        resume_id = None if force_fresh else _read_claude_session_id(rtx_sid, rtx_sdir)

    # Prompt is piped on stdin, NOT passed as argv. argv would hit
    # Linux's ARG_MAX (~128 KiB) and fail with OSError E2BIG
    # ("Argument list too long") on large prompts (full session
    # context, long files, etc.). `claude -p` reads stdin when no
    # positional prompt arg is given.
    cmd = [
        "claude", "-p",
        "--output-format", "stream-json",
        "--include-partial-messages",
        "--verbose",
        "--permission-mode", claude_mode,
        # `claude -p` is headless: AskUserQuestion auto-denies with
        # "Answer questions?" instead of round-tripping to the user.
        # Disallow it so Claude falls back to asking in its text reply.
        "--disallowed-tools", "AskUserQuestion",
    ]
    if resume_id:
        cmd += ["--resume", resume_id]
    # System-prompt priming on the FIRST call of an agent session
    # (new Agent/Engine pipeline). ``ExternalCliEngine.run_turn``
    # composes the agent's SOUL.md + AGENTS.md + TOOLS.md (+ live
    # preamble blocks) into ``_append_system_prompt``; we pass it
    # to ``claude -p`` via the documented ``--append-system-prompt``
    # flag so it lands in the bound Claude session's state and
    # rides on every ``--resume`` after. Without this flag (antigravity
    # final audit #1) the engine's whole agent context is dropped
    # on the floor — Claude runs vanilla without the agent's
    # persona.
    appended_sys = args.get("_append_system_prompt")
    if isinstance(appended_sys, str) and appended_sys.strip():
        cmd += ["--append-system-prompt", appended_sys]
    # If the caller wants AskUserQuestion blocked (same `claude -p`
    # has no user available, so the model would dead-end on it),
    # respect a ``_disallowed_tools`` arg as a list of tool names.
    disallowed = args.get("_disallowed_tools")
    if isinstance(disallowed, (list, tuple)) and disallowed:
        cmd += ["--disallowedTools", ",".join(str(t) for t in disallowed)]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=16 * 1024 * 1024,
            # Own process group so SIGTERM reaches Claude's spawned
            # `Bash`/`Read`/etc. subtools when the user hits ESC.
            start_new_session=True,
            cwd=spawn_cwd,
            env=_build_delegate_spawn_env(args),
        )
        if on_spawn is not None:
            try:
                on_spawn(proc)
            except Exception:  # noqa: BLE001
                pass
    except FileNotFoundError:
        _log_delegate_error(
            "claude", "spawn_failed",
            prompt=prompt, cwd=spawn_cwd, mode=claude_mode,
            resume_id=resume_id,
            message="`claude` CLI not on PATH",
        )
        return _err(
            "`claude` CLI not on PATH. Install: https://claude.com/code"
        )

    stdin_task = asyncio.create_task(_feed_stdin(proc, prompt.encode("utf-8")))

    text_buf: list[str] = []
    final_session_id: Optional[str] = resume_id
    is_error = False
    error_subtype: Optional[str] = None
    error_event: dict[str, Any] = {}
    # Per-index buffer for tool_use blocks streaming via stream_event:
    # content_block_start gives us the name + id, content_block_delta
    # streams the input as input_json_delta partial_json chunks, and
    # content_block_stop is when we finally have the full args ready
    # to emit a marker. Without this we'd either fire `🔧 Read {}` at
    # block_start (no args yet) or wait for the consolidated `assistant`
    # event (less live).
    tool_use_pending: dict[int, dict] = {}
    # Dedup against the consolidated `assistant` / `user` events that
    # restate the same blocks the stream channel already delivered.
    seen_tool_uses: set[str] = set()
    seen_tool_results: set[str] = set()

    def _push(chunk: str) -> None:
        """Append to text_buf and forward through on_delta."""
        if not chunk:
            return
        text_buf.append(chunk)
        if on_delta is not None:
            try:
                on_delta(chunk)
            except Exception:  # noqa: BLE001
                pass

    def _push_tool_use(tu_id: str, name: str, inp: Any) -> None:
        """Surface a tool_use block to the frontend.

        The compact ``🔧 <name> <args>`` text marker ALWAYS lands in
        ``text_buf`` so the persisted body the local model replays on
        its next round retains a record of what Claude did. Streaming
        delivery splits on whether the frontend asked for structured
        events: with ``on_event`` wired, only the structured payload
        goes out so the TUI can mount a native ToolCallMessage / route
        TodoWrite to the plan checklist; without, the text marker
        flows through ``on_delta`` so older consumers still see the
        inline pill.
        """
        marker = _format_claude_tool_use(name, inp)
        text_buf.append(marker)
        if on_event is not None:
            try:
                on_event({
                    "kind": "tool_use",
                    "id": tu_id or "",
                    "name": name or "?",
                    "input": inp,
                })
            except Exception:  # noqa: BLE001
                pass
        elif on_delta is not None:
            try:
                on_delta(marker)
            except Exception:  # noqa: BLE001
                pass

    def _push_tool_result(block: dict) -> None:
        """Surface a tool_result block. Mirror of ``_push_tool_use``."""
        marker = _format_claude_tool_result(block)
        text_buf.append(marker)
        if on_event is not None:
            raw = block.get("content")
            if isinstance(raw, list):
                parts: list[str] = []
                for b in raw:
                    if isinstance(b, dict) and b.get("type") == "text":
                        parts.append(b.get("text") or "")
                text = "".join(parts)
            elif isinstance(raw, str):
                text = raw
            else:
                text = "" if raw is None else str(raw)
            try:
                on_event({
                    "kind": "tool_result",
                    "tool_use_id": block.get("tool_use_id") or "",
                    "ok": not bool(block.get("is_error")),
                    "text": text,
                })
            except Exception:  # noqa: BLE001
                pass
        elif on_delta is not None:
            try:
                on_delta(marker)
            except Exception:  # noqa: BLE001
                pass

    # Hard backstop in case stdout never reaches EOF (a tool grandchild
    # inherited claude's stdout fd and kept it open after claude itself
    # exited — observed in rtxclaw session 6a0af106cd41 where claude
    # finished at 11:03:15 but readline blocked for 15+ min until ESC).
    # Configurable via env; 900s ≈ longest realistic single-tool wait.
    idle_timeout_s = float(
        os.environ.get("RTXCLAW_CLAUDE_IDLE_TIMEOUT_S", "900") or "900"
    )
    # A `claude -p` that never emits its first stream event (hung
    # SessionStart hook, auth/network wedge, a spawn that never reaches the
    # model) was previously invisible until this 900s idle timer — the
    # operator saw a frozen turn and restarted the gateway. Bound the wait
    # for the FIRST event separately so a startup stall fails fast.
    first_token_timeout_s = _delegate_first_token_timeout_s()
    got_first_event = False
    session_id_emitted = False
    try:
        if proc.stdout is None:
            raise RuntimeError("subprocess stdout pipe is None — spawn config bug")
        while True:
            try:
                line = await _delegate_readline(
                    proc.stdout,
                    got_first_event=got_first_event,
                    first_token_timeout_s=first_token_timeout_s,
                    idle_timeout_s=idle_timeout_s,
                )
            except asyncio.TimeoutError:
                if not got_first_event:
                    # Stalled startup — fail fast with a clear error rather
                    # than waiting out the full idle window. The bounded
                    # finally below reaps the process group.
                    _log_delegate_error(
                        "claude", "first_token_timeout",
                        prompt=prompt, cwd=spawn_cwd, mode=claude_mode,
                        resume_id=resume_id, remote_session_id=final_session_id,
                        returncode=proc.returncode,
                    )
                    return _err(
                        f"claude produced no output within "
                        f"{int(first_token_timeout_s)}s (startup timeout) — the "
                        "CLI appears stalled (e.g. a hung SessionStart hook, "
                        "auth, or network). Aborted instead of hanging; tune "
                        "via RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S."
                    )
                # Output started then went silent past the idle window.
                # Surface as an error instead of spinning forever. The
                # finally below SIGTERMs the process group so any
                # pipe-holding grandchild dies too.
                is_error = True
                error_subtype = "claude_runner_idle_timeout"
                break
            except ValueError:
                # Single event over the 16 MiB readline limit — skip it
                # but keep reading rather than failing the whole call.
                got_first_event = True
                continue
            if not line:
                break
            got_first_event = True
            try:
                event = json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                continue
            sid = event.get("session_id")
            if isinstance(sid, str) and sid:
                final_session_id = sid
                # Surface the session id to the engine as soon as we
                # see it (instead of only on the success terminal
                # path) so an ESC/idle-timeout still leaves the
                # engine sidecar primed for `--resume` on the next
                # turn. Without this, an aborted turn 0 erases the
                # claude session id and the user loses context.
                if not session_id_emitted and on_event is not None:
                    try:
                        on_event({"kind": "session_id", "id": sid})
                    except Exception:  # noqa: BLE001
                        pass
                    session_id_emitted = True
            etype = event.get("type")
            if etype == "stream_event":
                inner = event.get("event") or {}
                inner_type = inner.get("type")
                if inner_type == "content_block_delta":
                    delta = inner.get("delta") or {}
                    dtype = delta.get("type")
                    if dtype == "text_delta":
                        txt = delta.get("text") or ""
                        if txt:
                            # Push immediately so the SSE consumer
                            # (TUI ClaudeMessage / bash bridge stdout)
                            # sees Claude's text as it's generated,
                            # not just at end-of-call.
                            _push(txt)
                    elif dtype == "input_json_delta":
                        idx = inner.get("index")
                        partial = delta.get("partial_json") or ""
                        if isinstance(idx, int) and idx in tool_use_pending and partial:
                            tool_use_pending[idx]["json"] += partial
                elif inner_type == "content_block_start":
                    cb = inner.get("content_block") or {}
                    if cb.get("type") == "tool_use":
                        idx = inner.get("index")
                        if isinstance(idx, int):
                            tool_use_pending[idx] = {
                                "id": cb.get("id") or "",
                                "name": cb.get("name") or "?",
                                "json": "",
                            }
                elif inner_type == "content_block_stop":
                    idx = inner.get("index")
                    pending = tool_use_pending.pop(idx, None) if isinstance(idx, int) else None
                    if pending and pending["id"] not in seen_tool_uses:
                        seen_tool_uses.add(pending["id"])
                        try:
                            inp = json.loads(pending["json"]) if pending["json"] else {}
                        except json.JSONDecodeError:
                            inp = pending["json"]
                        _push_tool_use(pending["id"], pending["name"], inp)
            elif etype == "assistant":
                # Consolidated assistant message — fill in text not yet
                # streamed AND surface any tool_use blocks we haven't
                # already seen via `content_block_start`.
                content = (event.get("message") or {}).get("content") or []
                if isinstance(content, list):
                    for block in content:
                        if not isinstance(block, dict):
                            continue
                        btype = block.get("type")
                        if btype == "text":
                            full = block.get("text") or ""
                            already = "".join(text_buf)
                            if len(full) > len(already):
                                _push(full[len(already):])
                        elif btype == "tool_use":
                            tu_id = block.get("id") or ""
                            if tu_id and tu_id in seen_tool_uses:
                                continue
                            if tu_id:
                                seen_tool_uses.add(tu_id)
                            _push_tool_use(
                                tu_id,
                                block.get("name") or "?",
                                block.get("input") or {},
                            )
            elif etype == "user":
                # Tool results coming back to Claude. Surface a brief
                # marker so the rtxclaw user (and the local model on
                # replay) sees what Claude's sub-tool returned.
                content = (event.get("message") or {}).get("content") or []
                if isinstance(content, list):
                    for block in content:
                        if not isinstance(block, dict):
                            continue
                        if block.get("type") != "tool_result":
                            continue
                        tu_id = block.get("tool_use_id") or ""
                        if tu_id and tu_id in seen_tool_results:
                            continue
                        if tu_id:
                            seen_tool_results.add(tu_id)
                        _push_tool_result(block)
            elif etype == "result":
                if event.get("is_error"):
                    is_error = True
                    error_event = event
                    error_subtype = event.get("subtype") or "claude reported an error"
                # `result` is claude's logical end-of-turn marker. Trust
                # it instead of waiting for stdout EOF — a tool
                # grandchild can keep the stdout pipe open long after
                # claude itself exits, which would otherwise leave the
                # runner blocked on readline forever (and the TUI's
                # worker indicator spinning until the user hits ESC).
                break
    except asyncio.CancelledError:
        _log_delegate_error(
            "claude", "cancelled",
            prompt=prompt, cwd=spawn_cwd, mode=claude_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
        )
        # Send SIGTERM/SIGKILL to the WHOLE group so claude's spawned
        # tools (Bash, Read, …) die too instead of being orphaned.
        _kill_group(proc, signal.SIGTERM)
        _kill_group(proc, signal.SIGKILL)
        raise
    finally:
        if not stdin_task.done():
            stdin_task.cancel()
        try:
            await stdin_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        # Bounded reap: wait for natural exit first (cleanly-exiting
        # claude races against any signal we send and would otherwise
        # come back with a negative returncode → spurious _err). If
        # the proc is still alive after the grace window — usually a
        # tool grandchild holding claude's stdout pipe open — escalate
        # to SIGTERM/SIGKILL on the whole group so the finally itself
        # can't pin the engine indefinitely.
        try:
            await asyncio.wait_for(proc.wait(), timeout=2.0)
        except asyncio.TimeoutError:
            try:
                await _terminate_group(proc, grace_s=2.0)
            except Exception:  # noqa: BLE001
                pass
        except Exception:  # noqa: BLE001
            pass

    if proc.returncode != 0 and not is_error:
        stderr_bytes = b""
        if proc.stderr is not None:
            try:
                stderr_bytes = await proc.stderr.read()
            except Exception:  # noqa: BLE001
                pass
        err_msg = stderr_bytes.decode("utf-8", "replace")[:400] or f"rc={proc.returncode}"
        _log_delegate_error(
            "claude", "nonzero_exit",
            prompt=prompt, cwd=spawn_cwd, mode=claude_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
            stderr=stderr_bytes.decode("utf-8", "replace"),
        )
        return _err(f"claude exited {proc.returncode}: {err_msg}")

    if is_error:
        _log_delegate_error(
            "claude", "reported_error",
            prompt=prompt,
            cwd=spawn_cwd,
            mode=claude_mode,
            resume_id=resume_id,
            remote_session_id=final_session_id,
            returncode=proc.returncode,
            event=error_event,
            claude_session_id=final_session_id,
            retry_no_resume=force_fresh,
            retry_of=retry_of,
        )
        if (
            error_subtype == "error_during_execution"
            and resume_id
            and not force_fresh
        ):
            log_event(
                "DELEGATE_CLAUDE_RETRY_FRESH",
                rtxclaw_session_id=os.environ.get("RTXCLAW_SESSION_ID"),
                stale_claude_session_id=resume_id,
                cwd=spawn_cwd or os.getcwd(),
                mode=claude_mode,
            )
            retry_args = dict(args)
            retry_args["_rtxclaw_claude_no_resume"] = True
            retry_args["_rtxclaw_claude_retry_of"] = resume_id
            retry = await run_delegate_claude_async(
                retry_args, on_delta=on_delta, on_event=on_event,
            )
            log_event(
                "DELEGATE_CLAUDE_RETRY_FRESH_DONE",
                rtxclaw_session_id=os.environ.get("RTXCLAW_SESSION_ID"),
                stale_claude_session_id=resume_id,
                ok=retry.ok,
                truncated=retry.truncated,
            )
            if retry.ok:
                return retry
            return _err(
                "claude reported error: "
                f"{error_subtype}; fresh retry also failed: {retry.content}"
            )
        return _err(f"claude reported error: {error_subtype}")

    body_text = "".join(text_buf).strip()
    if not body_text:
        _log_delegate_error(
            "claude", "empty_response",
            prompt=prompt, cwd=spawn_cwd, mode=claude_mode,
            resume_id=resume_id, remote_session_id=final_session_id,
            returncode=proc.returncode,
        )
        return _err("claude returned empty response")

    if final_session_id:
        _write_claude_session_id(final_session_id, rtx_sid, rtx_sdir)

    header_bits = []
    if final_session_id:
        header_bits.append(f"session={final_session_id[:12]}")
    header_bits.append(f"mode={claude_mode}")
    if resume_id:
        header_bits.append("resumed")
    header = f"[claude {' · '.join(header_bits)}]"

    # Footer steers the model on its NEXT delegate_claude call: don't
    # restate this exchange, Claude already has it in --resume state.
    # Lives inside the tool result so it stays in context every round
    # the result is replayed via `_build_messages` — the model can't
    # forget the rule. Stable wording (no timestamps, no session id in
    # the footer) so it's cache-friendly.
    footer = (
        "\n\n[claude --resume note: Claude now has this exchange. On your "
        "next delegate_claude call in this rtxclaw session, only forward "
        "context that is NEW since this point — do not restate this "
        "reply or anything earlier.]"
    )

    body, truncated = _truncate(f"{header}\n\n{body_text}{footer}")
    return ToolResult(content=body, ok=True, truncated=truncated)


# Map rtxclaw permission modes → codex flags. The codex CLI's resume
# subcommand doesn't accept `-s/--sandbox` or `-a/--ask-for-approval`
# directly, so we use `-c sandbox_mode=...` / `-c approval_policy=...`
# overrides which work for both first-call (`codex exec`) and resume
# (`codex exec resume`). `auto` uses the canonical
# `--dangerously-bypass-approvals-and-sandbox` flag because in headless
# mode there's no human to answer an approval prompt.
_CODEX_MODE_FLAGS: dict[str, list[str]] = {
    "plan": ["-c", "sandbox_mode=read-only", "-c", "approval_policy=never"],
    "ask": ["-c", "sandbox_mode=workspace-write", "-c", "approval_policy=on-request"],
    "auto": ["--dangerously-bypass-approvals-and-sandbox"],
}


def _codex_state_path(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[Path]:
    """Resolve the per-rtxclaw-session state file for `delegate_codex`.

    Mirrors :func:`_claude_state_path`: engine-pipeline callers pass
    ``rtx_sid`` / ``rtx_sdir`` explicitly so concurrent CLI turns can't
    race on ``os.environ``; legacy direct callers fall back to env.
    """
    sid = rtx_sid or os.environ.get("RTXCLAW_SESSION_ID")
    sdir = rtx_sdir or os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return Path(sdir) / f"{sid}.delegate_codex.json"


def _read_codex_thread_id(
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> Optional[str]:
    p = _codex_state_path(rtx_sid, rtx_sdir)
    if p is None or not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    tid = data.get("codex_thread_id") if isinstance(data, dict) else None
    return tid if isinstance(tid, str) and tid else None


def _write_codex_thread_id(
    thread_id: str,
    rtx_sid: Optional[str] = None,
    rtx_sdir: Optional[str] = None,
) -> None:
    p = _codex_state_path(rtx_sid, rtx_sdir)
    if p is None:
        return
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"codex_thread_id": thread_id}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


def _format_codex_command_started(cmd: str) -> str:
    """In-band marker for a `command_execution` item codex started running."""
    cmd_disp = cmd.strip()
    if len(cmd_disp) > 160:
        cmd_disp = cmd_disp[:160] + "…"
    return f"\n\n🔧 bash {cmd_disp}\n"


def _format_codex_command_completed(item: dict) -> str:
    """In-band marker for a completed `command_execution` item.

    Uses the same `↳ <head> (N chars)` shape as `_format_claude_tool_result`
    so the two delegates look uniform in saved transcripts.
    """
    out = item.get("aggregated_output") or ""
    if not isinstance(out, str):
        out = str(out)
    exit_code = item.get("exit_code")
    n = len(out)
    head = next((line for line in out.splitlines() if line.strip()), "")
    summary = head.strip()[:140]
    arrow = "✗" if isinstance(exit_code, int) and exit_code != 0 else "↳"
    if summary:
        return f"{arrow} {summary} ({n} chars)\n"
    return f"{arrow} ({n} chars)\n"


async def run_delegate_codex_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
    on_spawn: Optional[Callable[[Any], None]] = None,
) -> ToolResult:
    """Spawn `codex exec ...` and return its full reply as the tool result.

    .. deprecated:: refactor-phase-4
       Legacy delegate-as-tool entry point. The new
       :class:`rtxclaw_core.agents.codex_engine.CodexCliEngine`
       reuses this via :meth:`delegate_runner`; the function stays
       until Phase 7's legacy sweep.


    Streams `codex exec --json` and forwards each `agent_message` text
    plus a compact in-band marker for every `command_execution` item
    Codex emits, all through the same `on_delta` callback. The
    slash-command bridge (`/codex`) and the autonomous-tool path
    (`tool_delta` SSE) both consume that callback, so live progress —
    including which shell commands Codex itself is running under the
    hood — shows up in the TUI, Telegram, and any other SSE consumer
    with no per-frontend changes.

    Per-rtxclaw-session state: reads `codex_thread_id` from
    `<sessions_dir>/<sid>.delegate_codex.json` and uses
    `codex exec resume <id>` so a follow-up `delegate_codex` call
    continues the same Codex conversation. The new id is written back
    on success.

    Note: codex doesn't stream agent text token-by-token like
    `claude -p` does — `agent_message` arrives as one consolidated
    `item.completed` event. We surface it as a single chunk on
    `on_delta`, which is fine for the SSE consumer (the user just sees
    a delayed burst rather than a typewriter effect).

    Killability: a SIGTERM landing on this coroutine (via the parent
    `tool_runner`'s signal handler) propagates through CancelledError;
    the `finally` block kills the codex subprocess so it doesn't keep
    running orphaned.
    """
    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return _err("prompt required")

    # Engine-pipeline session identity + mode — see :func:`run_delegate_claude_async`
    # for rationale. Concurrent CLI turns on the same agent must not
    # race on process-wide ``os.environ``.
    rtx_sid_arg = args.get("_rtxclaw_session_id")
    rtx_sid: Optional[str] = rtx_sid_arg if isinstance(rtx_sid_arg, str) and rtx_sid_arg else None
    rtx_sdir_arg = args.get("_rtxclaw_sessions_dir")
    rtx_sdir: Optional[str] = rtx_sdir_arg if isinstance(rtx_sdir_arg, str) and rtx_sdir_arg else None
    rtx_perm_arg = args.get("_rtxclaw_permission_mode")
    rtx_perm: str = rtx_perm_arg if isinstance(rtx_perm_arg, str) and rtx_perm_arg else ""

    mode_raw = args.get("mode")
    if isinstance(mode_raw, str) and mode_raw in _CODEX_MODE_FLAGS:
        mode = mode_raw
    else:
        # Inherit from the rtxclaw permission mode the agent is running
        # in. Engine callers pass it via ``_rtxclaw_permission_mode``;
        # legacy direct callers fall back to env. ``ask`` is the safe
        # fallback when neither yields a known mode.
        rtx_mode = rtx_perm or os.environ.get("RTXCLAW_PERMISSION_MODE", "")
        mode = rtx_mode if rtx_mode in _CODEX_MODE_FLAGS else "ask"

    mode_flags = _CODEX_MODE_FLAGS[mode]

    # Optional `cwd`: validate before spawn (same rationale as
    # delegate_claude — fail loud on typos rather than crash subprocess).
    spawn_cwd, cwd_err = _resolve_delegate_cwd(args)
    if cwd_err is not None:
        _log_delegate_error(
            "codex", "bad_cwd",
            prompt=prompt, cwd=os.getcwd(), mode=mode,
            message=cwd_err,
        )
        return _err(cwd_err)

    # Resume-id override (new Agent/Engine pipeline). When the caller
    # is :class:`ExternalCliEngine`, the engine manages its own
    # sidecar and passes the resume id explicitly via
    # ``_force_resume_id``. ``_rtxclaw_codex_no_resume`` (if added)
    # is also respected for parity with the claude branch.
    forced_resume = args.get("_force_resume_id")
    force_fresh = bool(args.get("_rtxclaw_codex_no_resume"))
    if isinstance(forced_resume, str) and forced_resume:
        resume_id = None if force_fresh else forced_resume
    else:
        resume_id = None if force_fresh else _read_codex_thread_id(rtx_sid, rtx_sdir)

    # System-prompt priming for the new Agent/Engine pipeline. Codex
    # has no ``--system-prompt`` flag, so we inject the composed
    # SOUL.md / AGENTS.md / TOOLS.md as a leading user-message
    # fragment in the stdin payload (antigravity final audit #1).
    appended_sys = args.get("_append_system_prompt")
    if isinstance(appended_sys, str) and appended_sys.strip():
        # Prepend with a clear separator so codex treats the agent
        # context as instruction prelude rather than user request.
        prompt = (
            f"<system>\n{appended_sys.strip()}\n</system>\n\n"
            f"---\n\n{prompt}"
        )

    # `--skip-git-repo-check` so codex doesn't refuse to run when the
    # cwd isn't a git repo (rtxclaw agents may launch from anywhere).
    # Prompt is piped on stdin (see delegate_claude rationale): argv
    # would hit ARG_MAX (~128 KiB) and crash with E2BIG. `codex exec`
    # reads stdin when no positional PROMPT is given.
    base = ["codex", "exec", "--json", "--skip-git-repo-check"]
    if resume_id:
        # `codex exec resume <id>`. Mode flags come AFTER `resume <id>`
        # because of how the codex argparse subcommand is structured:
        # positional `[SESSION_ID]` then options on the `resume`
        # subcommand.
        cmd = base + ["resume", resume_id] + list(mode_flags)
    else:
        cmd = base + list(mode_flags)

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=16 * 1024 * 1024,
            # Own process group; see delegate_claude.
            start_new_session=True,
            cwd=spawn_cwd,
            env=_build_delegate_spawn_env(args),
        )
        if on_spawn is not None:
            try:
                on_spawn(proc)
            except Exception:  # noqa: BLE001
                pass
    except FileNotFoundError:
        _log_delegate_error(
            "codex", "spawn_failed",
            prompt=prompt, cwd=spawn_cwd, mode=mode,
            resume_id=resume_id,
            message="`codex` CLI not on PATH",
        )
        return _err(
            "`codex` CLI not on PATH. Install: https://github.com/openai/codex"
        )

    stdin_task = asyncio.create_task(_feed_stdin(proc, prompt.encode("utf-8")))

    text_buf: list[str] = []
    final_thread_id: Optional[str] = resume_id
    is_error = False
    error_msg: Optional[str] = None
    error_event: dict[str, Any] = {}
    # Per-id buffers for command_execution items so we don't print the
    # `🔧 bash …` marker twice when both `item.started` and
    # `item.completed` carry the command.
    cmd_announced: set[str] = set()

    def _push(chunk: str) -> None:
        """Append to text_buf and forward through on_delta."""
        if not chunk:
            return
        text_buf.append(chunk)
        if on_delta is not None:
            try:
                on_delta(chunk)
            except Exception:  # noqa: BLE001
                pass

    def _push_marker(chunk: str) -> None:
        """Append a tool marker to text_buf so the persisted body
        keeps its inline trace, but skip ``on_delta`` when
        ``on_event`` is wired — the structured event already drives
        a native widget on the frontend, so duplicating it as inline
        text would render twice.
        """
        if not chunk:
            return
        text_buf.append(chunk)
        if on_event is None and on_delta is not None:
            try:
                on_delta(chunk)
            except Exception:  # noqa: BLE001
                pass

    try:
        if proc.stdout is None:
            raise RuntimeError("subprocess stdout pipe is None — spawn config bug")
        first_token_timeout_s = _delegate_first_token_timeout_s()
        idle_timeout_s = _delegate_idle_timeout_s()
        got_first_event = False
        while True:
            try:
                line = await _delegate_readline(
                    proc.stdout,
                    got_first_event=got_first_event,
                    first_token_timeout_s=first_token_timeout_s,
                    idle_timeout_s=idle_timeout_s,
                )
            except asyncio.TimeoutError:
                stage = "startup" if not got_first_event else "idle"
                secs = int(
                    first_token_timeout_s if not got_first_event else idle_timeout_s
                )
                # codex's finally does an UNBOUNDED proc.wait(); kill the
                # group first so it returns instead of hanging on a stalled
                # child.
                _kill_group(proc, signal.SIGTERM)
                _kill_group(proc, signal.SIGKILL)
                _log_delegate_error(
                    "codex", f"{stage}_timeout",
                    prompt=prompt, cwd=spawn_cwd, mode=mode,
                    resume_id=resume_id, remote_session_id=final_thread_id,
                    returncode=proc.returncode,
                )
                return _err(
                    f"codex produced no output for {secs}s ({stage} timeout) "
                    "— the CLI appears stalled. Aborted instead of hanging; "
                    "tune via RTXCLAW_DELEGATE_FIRST_TOKEN_TIMEOUT_S / "
                    "RTXCLAW_DELEGATE_IDLE_TIMEOUT_S."
                )
            except ValueError:
                # Single event over the 16 MiB readline limit — skip it
                # but keep reading rather than failing the whole call.
                got_first_event = True
                continue
            if not line:
                break
            got_first_event = True
            try:
                event = json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                continue
            etype = event.get("type")
            if etype == "thread.started":
                tid = event.get("thread_id")
                if isinstance(tid, str) and tid:
                    final_thread_id = tid
                continue
            if etype in ("item.started", "item.completed"):
                item = event.get("item") or {}
                itype = item.get("type")
                iid = item.get("id") or ""
                if itype == "agent_message":
                    # Agent text arrives only on `item.completed` (codex
                    # doesn't stream tokens). Push the full body once.
                    if etype == "item.completed":
                        txt = item.get("text") or ""
                        if txt:
                            _push(txt)
                elif itype == "command_execution":
                    cmd = item.get("command") or "?"
                    if etype == "item.started":
                        if iid not in cmd_announced:
                            cmd_announced.add(iid)
                            _push_marker(_format_codex_command_started(cmd))
                            if on_event is not None:
                                try:
                                    on_event({
                                        "kind": "tool_use",
                                        "id": iid,
                                        "name": "bash",
                                        "input": {"command": cmd},
                                    })
                                except Exception:  # noqa: BLE001
                                    pass
                    else:  # item.completed
                        # Announce here too if we missed the start event
                        # (race / dropped frame), then push the result.
                        if iid not in cmd_announced:
                            cmd_announced.add(iid)
                            _push_marker(_format_codex_command_started(cmd))
                            if on_event is not None:
                                try:
                                    on_event({
                                        "kind": "tool_use",
                                        "id": iid,
                                        "name": "bash",
                                        "input": {"command": cmd},
                                    })
                                except Exception:  # noqa: BLE001
                                    pass
                        _push_marker(_format_codex_command_completed(item))
                        if on_event is not None:
                            out = item.get("aggregated_output") or ""
                            if not isinstance(out, str):
                                out = str(out)
                            exit_code = item.get("exit_code")
                            ok = not (isinstance(exit_code, int) and exit_code != 0)
                            try:
                                on_event({
                                    "kind": "tool_result",
                                    "tool_use_id": iid,
                                    "ok": ok,
                                    "text": out,
                                })
                            except Exception:  # noqa: BLE001
                                pass
                # Other item types (web_search, file_search, mcp tool
                # calls, agent_reasoning) are intentionally ignored:
                # reasoning bloats context and the others don't have a
                # stable enough shape to render usefully yet.
                continue
            if etype == "turn.failed":
                is_error = True
                err = event.get("error") or {}
                if isinstance(err, dict):
                    error_msg = err.get("message") or err.get("type") or "codex turn failed"
                    error_event = event
                else:
                    error_msg = str(err) or "codex turn failed"
                    error_event = event
                continue
    except asyncio.CancelledError:
        _log_delegate_error(
            "codex", "cancelled",
            prompt=prompt, cwd=spawn_cwd, mode=mode,
            resume_id=resume_id, remote_session_id=final_thread_id,
            returncode=proc.returncode,
            codex_thread_id=final_thread_id,
        )
        # Same group-kill rationale as delegate_claude.
        _kill_group(proc, signal.SIGTERM)
        _kill_group(proc, signal.SIGKILL)
        raise
    finally:
        if not stdin_task.done():
            stdin_task.cancel()
        try:
            await stdin_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass

    if proc.returncode != 0 and not is_error:
        stderr_bytes = b""
        if proc.stderr is not None:
            try:
                stderr_bytes = await proc.stderr.read()
            except Exception:  # noqa: BLE001
                pass
        err_msg = stderr_bytes.decode("utf-8", "replace")[:400] or f"rc={proc.returncode}"
        _log_delegate_error(
            "codex", "nonzero_exit",
            prompt=prompt, cwd=spawn_cwd, mode=mode,
            resume_id=resume_id, remote_session_id=final_thread_id,
            returncode=proc.returncode,
            stderr=stderr_bytes.decode("utf-8", "replace"),
            codex_thread_id=final_thread_id,
        )
        return _err(f"codex exited {proc.returncode}: {err_msg}")

    if is_error:
        _log_delegate_error(
            "codex", "reported_error",
            prompt=prompt, cwd=spawn_cwd, mode=mode,
            resume_id=resume_id, remote_session_id=final_thread_id,
            returncode=proc.returncode,
            message=error_msg,
            event=error_event,
            codex_thread_id=final_thread_id,
        )
        return _err(f"codex reported error: {error_msg or 'unknown'}")

    body_text = "".join(text_buf).strip()
    if not body_text:
        _log_delegate_error(
            "codex", "empty_response",
            prompt=prompt, cwd=spawn_cwd, mode=mode,
            resume_id=resume_id, remote_session_id=final_thread_id,
            returncode=proc.returncode,
            codex_thread_id=final_thread_id,
        )
        return _err("codex returned empty response")

    if final_thread_id:
        _write_codex_thread_id(final_thread_id, rtx_sid, rtx_sdir)

    header_bits = []
    if final_thread_id:
        header_bits.append(f"thread={final_thread_id[:12]}")
    header_bits.append(f"mode={mode}")
    if resume_id:
        header_bits.append("resumed")
    header = f"[codex {' · '.join(header_bits)}]"

    # Footer steers the model on its NEXT delegate_codex call: don't
    # restate this exchange, Codex already has it via `exec resume`.
    # Same wording as delegate_claude's footer (sub `--resume` for
    # `exec resume`) so the steering is consistent across delegates.
    footer = (
        "\n\n[codex resume note: Codex now has this exchange. On your "
        "next delegate_codex call in this rtxclaw session, only forward "
        "context that is NEW since this point — do not restate this "
        "reply or anything earlier.]"
    )

    body, truncated = _truncate(f"{header}\n\n{body_text}{footer}")
    return ToolResult(content=body, ok=True, truncated=truncated)


# ---- monitor (long-running background process registry) ----

# Mirrors Claude Code's ``Monitor`` tool. The model spawns a process
# via ``monitor_start``, reads new output via ``monitor_read``, and
# kills it via ``monitor_stop``. v1 is pull-based (the model polls);
# the push variant (each line wakes the agent via session-update
# notifications) is a follow-up that needs gateway integration.
#
# The registry is per-worker: every tool subprocess holds its own
# MonitorRegistry, so monitor ids are stable for the duration of a
# tool round but do NOT survive across rounds. Long-running watches
# need either the push variant or a session-scoped registry — both
# are tracked in the README's ``Architecture`` section.


async def run_monitor_start_async(args: dict[str, Any]) -> ToolResult:
    """Spawn a long-running command and return its monitor id.

    Mirrors Claude Code's ``Monitor`` schema (``command``, ``description``,
    ``timeout_ms``, ``persistent``). Legacy ``cwd`` arg still accepted.
    The monitor id is surfaced as ``bash_id`` so the rest of the
    Claude-style tool family (``BashOutput`` / ``KillShell``) can
    address it without operators having to remember the rtxclaw
    legacy name.
    """
    from .monitor import _registry
    command = args.get("command")
    cwd = args.get("cwd")
    description = args.get("description") or ""
    if not isinstance(command, str) or not command:
        return _err("command required")
    try:
        mon = await _registry().start(
            command,
            cwd=str(cwd) if isinstance(cwd, str) and cwd else None,
        )
    except Exception as e:  # noqa: BLE001
        return _err(f"spawn failed: {e}")
    desc_line = f"description: {description}\n" if description else ""
    return ToolResult(
        content=(
            f"bash_id: {mon.monitor_id}\n"
            f"{desc_line}"
            f"command: {mon.command}\n"
            f"pid: {mon.process.pid}\n"
            f"\nUse BashOutput(bash_id={mon.monitor_id!r}) to drain new "
            "output, KillShell(...) to terminate."
        ),
    )


async def run_monitor_read_async(args: dict[str, Any]) -> ToolResult:
    """Pop unread lines from a monitor's buffer.

    Reads from the per-monitor logfile (the spawned process writes
    directly there, so SIGPIPE never fires when launcher subprocesses
    cycle). The byte cursor is persisted in the sidecar entry, so
    each ``monitor_read`` call across separate tool rounds resumes
    cleanly without re-reading lines.
    """
    from .monitor import (
        _registry,
        load_sidecar,
        read_log_lines,
        write_sidecar_entry,
    )
    # Accept Claude Code's ``bash_id`` AND legacy ``monitor_id``.
    mid = args.get("bash_id") or args.get("monitor_id")
    if not isinstance(mid, str) or not mid:
        return _err("bash_id required")
    max_lines = int(args.get("max_lines") or 100)
    timeout_s = float(args.get("timeout_s") or 2.0)
    # Optional Claude ``filter`` regex — drops lines that don't match.
    filter_pat = args.get("filter")
    filter_regex: Optional[re.Pattern[str]] = None
    if isinstance(filter_pat, str) and filter_pat:
        try:
            filter_regex = re.compile(filter_pat)
        except re.error as exc:
            return _err(f"bad filter regex: {exc}")
    # In-proc fast path: if THIS subprocess started the monitor, the
    # registry has the buffered lines + asyncio.Event for tail-style
    # waits. Use it.
    try:
        result = await _registry().read(
            mid, max_lines=max_lines, timeout_s=timeout_s,
        )
    except LookupError:
        result = None
    if result is not None:
        lines = result["lines"]
        if filter_regex is not None:
            lines = [ln for ln in lines if filter_regex.search(ln["text"])]
        parts = [
            f"bash_id: {result['monitor_id']}",
            f"running: {result['running']}",
        ]
        if result["exit_code"] is not None:
            parts.append(f"exit_code: {result['exit_code']}")
        parts.append(f"new lines: {len(lines)}")
        if result["more_buffered"]:
            parts.append("(more buffered — call BashOutput again)")
        if lines:
            parts.append("--- output ---")
            for ln in lines:
                tag = "[stderr] " if ln["stream"] == "stderr" else ""
                parts.append(f"{tag}{ln['text'].rstrip()}")
        body, truncated = _truncate("\n".join(parts))
        return ToolResult(content=body, truncated=truncated)

    # Cross-subprocess: read from the on-disk logfile starting at the
    # cursor in the sidecar. Wait up to ``timeout_s`` for new bytes
    # to appear (or for the process to exit).
    sidecar = load_sidecar()
    match = next(
        (e for e in sidecar if e.get("monitor_id") == mid), None,
    )
    if match is None:
        return _err(f"unknown monitor_id {mid!r}")
    log_path = match.get("log_path")
    if not log_path:
        # Older sidecar entry without log_path — surface status only.
        running = bool(match.get("alive"))
        return ToolResult(content=(
            f"monitor_id: {mid}\nrunning: {running}\n"
            f"pid: {match.get('pid')}\n"
            "(no log_path recorded — likely an older monitor; "
            "use monitor_list / monitor_stop instead.)"
        ))
    log_path = Path(log_path)
    cursor = int(match.get("read_cursor") or 0)
    pid = int(match.get("pid") or 0)

    deadline = time.monotonic() + min(max(0.0, timeout_s), 30.0)
    lines: list[tuple[str, bool]] = []
    new_cursor = cursor
    while True:
        lines, new_cursor = read_log_lines(
            log_path, start_byte=cursor, max_lines=max_lines,
        )
        if lines:
            break
        if pid > 0 and not _pid_alive(pid):
            break
        if time.monotonic() >= deadline:
            break
        await asyncio.sleep(0.1)

    if new_cursor != cursor:
        # Persist the advance so the next call (this subprocess or
        # the next one) resumes from the right place.
        merged = {**match, "read_cursor": new_cursor}
        # Keep the value pristine — write_sidecar_entry already
        # strips ``alive``.
        write_sidecar_entry(merged)

    if filter_regex is not None:
        lines = [(t, e) for (t, e) in lines if filter_regex.search(t)]
    running = pid > 0 and _pid_alive(pid)
    parts = [
        f"bash_id: {mid}",
        f"running: {running}",
        f"pid: {pid}",
        f"new lines: {len(lines)}",
    ]
    if lines:
        parts.append("--- output ---")
        for text, is_err in lines:
            tag = "[stderr] " if is_err else ""
            parts.append(f"{tag}{text.rstrip()}")
    body, truncated = _truncate("\n".join(parts))
    return ToolResult(content=body, truncated=truncated)


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


async def run_monitor_stop_async(args: dict[str, Any]) -> ToolResult:
    """SIGTERM the monitor's process group, escalate to SIGKILL."""
    from .monitor import _registry
    # Accept Claude Code's ``shell_id`` AND legacy ``monitor_id``.
    mid = args.get("shell_id") or args.get("monitor_id")
    if not isinstance(mid, str) or not mid:
        return _err("shell_id required")
    try:
        result = await _registry().stop(mid)
    except LookupError as e:
        return _err(str(e))
    return ToolResult(
        content=(
            f"shell_id: {result['monitor_id']}\n"
            f"running: {result['running']}\n"
            f"exit_code: {result['exit_code']}\n"
            f"unread_lines: {result['unread_lines']}"
        ),
    )


def run_monitor_list(args: dict[str, Any]) -> ToolResult:  # noqa: ARG001
    """List every live monitor + its buffer state.

    Reads the session sidecar (`<sid>.monitors.json`) so monitors
    started in earlier tool subprocesses still show up. Each entry's
    `alive` flag is recomputed via `os.kill(pid, 0)` on every read,
    so a process that died after its subprocess exited shows as
    `exited` regardless of what the sidecar last recorded.
    """
    from .monitor import _registry, load_sidecar
    in_proc = {r["monitor_id"]: r for r in _registry().list()}
    sidecar = load_sidecar()
    # Merge: in-process entries win for buffered/unread counts; sidecar
    # provides the cross-subprocess survivors.
    by_id: dict[str, dict[str, Any]] = {}
    for entry in sidecar:
        by_id[entry["monitor_id"]] = {
            "monitor_id": entry["monitor_id"],
            "command": entry.get("command", ""),
            "pid": entry.get("pid"),
            "alive": entry.get("alive", False),
            "started_at_unix": entry.get("started_at_unix"),
            "buffered_lines": 0,
            "unread_lines": 0,
            "scope": "sidecar",
        }
    for mid, row in in_proc.items():
        merged = by_id.get(mid, {})
        merged.update({
            "monitor_id": mid,
            "command": row["command"],
            "alive": row["running"],
            "exit_code": row["exit_code"],
            "buffered_lines": row["buffered_lines"],
            "unread_lines": row["unread_lines"],
            "scope": "in_proc",
        })
        by_id[mid] = merged
    rows = list(by_id.values())
    if not rows:
        return ToolResult(content="(no live monitors)")
    parts = [f"{len(rows)} monitor(s):"]
    for r in rows:
        if r.get("alive"):
            state = "running"
        elif r.get("exit_code") is not None:
            state = f"exited({r['exit_code']})"
        else:
            state = "exited"
        pid = r.get("pid")
        parts.append(
            f"  {r['monitor_id']}  {state}  pid={pid}  "
            f"unread={r['unread_lines']}  cmd={r['command']!r}"
        )
    return ToolResult(content="\n".join(parts))


# ---- todo (session-scoped checklist) ----

# Persisted at `<sessions_dir>/<sid>.todos.json`. The runner resolves
# that path from `RTXCLAW_SESSION_ID` + `RTXCLAW_SESSIONS_DIR` (set by
# `_spawn_tool_runner` on every tool subprocess). The agent runtime
# also reads + formats this file directly for the `/todo` slash command,
# via `todos_path_for_session` and `format_todo_md` below.

_TODO_VALID_STATUSES: frozenset[str] = frozenset(
    {"pending", "in_progress", "done", "completed"}
)


def _canonical_todo_status(status: Any) -> str:
    """Normalize a status value across rtxclaw legacy and Claude TodoWrite.

    Both ``done`` and ``completed`` collapse to the rtxclaw-internal
    ``done`` so downstream renderers / persistence stay stable;
    ``in_progress`` passes through. Anything else falls back to
    ``pending``.
    """
    if not isinstance(status, str):
        return "pending"
    s = status.strip().lower()
    if s == "completed":
        return "done"
    if s in ("pending", "in_progress", "done"):
        return s
    return "pending"


def todos_path_for_session(sessions_dir: Path, sid: str) -> Path:
    """The session's todo file. Mirrors `<sid>.delegate_*.json` paths."""
    return sessions_dir / f"{sid}.todos.json"


def _todos_path_from_env() -> Optional[Path]:
    sid = os.environ.get("RTXCLAW_SESSION_ID")
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return todos_path_for_session(Path(sdir), sid)


def load_todos(path: Path) -> list[dict[str, Any]]:
    """Read the todo list. Missing/corrupt → empty list."""
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, list):
        return []
    out: list[dict[str, Any]] = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        content = entry.get("content")
        if not isinstance(content, str) or not content:
            continue
        status = entry.get("status")
        if status not in _TODO_VALID_STATUSES:
            status = "pending"
        item: dict[str, Any] = {"content": content, "status": status}
        created_at = entry.get("created_at")
        if isinstance(created_at, str) and created_at:
            item["created_at"] = created_at
        out.append(item)
    return out


def _save_todos(path: Path, items: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(items, indent=2, ensure_ascii=False) + "\n"
    # Atomic write: tmp + fsync + os.replace, same pattern Session.save
    # uses. Without this, a SIGTERM mid-write leaves an empty / partial
    # JSON the next `load_todos` discards as corrupt → silent reset of
    # the model's todo list.
    tmp = path.with_name(f".{path.name}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def format_todo_md(items: list[dict[str, Any]]) -> str:
    """Render the list as the markdown checklist the model + UI see.

    Mirrors Claude Code's TodoWrite render: completed steps get ``[x]``,
    in_progress gets ``[~]`` (rtxclaw extension; keeps the marker
    distinct from done), pending gets ``[ ]``. The trailing message
    matches Claude's "Todos have been modified successfully" so a
    delegated /claude turn and a native rtxclaw turn produce
    indistinguishable confirmations.
    """
    if not items:
        return "Todos have been modified successfully. (list is empty)"
    lines = ["## Todo List", ""]
    for i, t in enumerate(items):
        status = t.get("status") or "pending"
        if status == "done":
            mark = "x"
        elif status == "in_progress":
            mark = "~"
        else:
            mark = " "
        content = (t.get("content") or "").strip()
        lines.append(f"- [{mark}] {i}: {content}")
    lines.append("")
    lines.append(
        "Todos have been modified successfully. Ensure that you "
        "continue to use the todo list to track your progress."
    )
    return "\n".join(lines)


def _normalize_todo_items(raw: Any) -> tuple[Optional[list[dict[str, Any]]], Optional[str]]:
    """Coerce the model's todo items into ``{content, status, activeForm,
    created_at}`` dicts.

    Accepts:
    - plain strings (pending),
    - legacy ``{content, status?}`` dicts,
    - Claude TodoWrite ``{content, activeForm, status}`` dicts (where
      ``status`` ∈ {pending, in_progress, completed}).

    Returns ``(items, error)`` — exactly one is non-None.
    """
    if not isinstance(raw, list):
        return (
            None,
            "todos/items must be a list of strings or "
            "{content, activeForm, status} objects",
        )
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    out: list[dict[str, Any]] = []
    for it in raw:
        if isinstance(it, str):
            content = it.strip()
            if not content:
                return None, "items must not contain empty strings"
            out.append({
                "content": content,
                "status": "pending",
                "activeForm": "",
                "created_at": now,
            })
            continue
        if isinstance(it, dict):
            content = it.get("content")
            if not isinstance(content, str) or not content.strip():
                return None, "each item dict must have non-empty content"
            status = _canonical_todo_status(it.get("status"))
            active_form = it.get("activeForm") or it.get("active_form") or ""
            if not isinstance(active_form, str):
                active_form = ""
            out.append({
                "content": content.strip(),
                "status": status,
                "activeForm": active_form.strip(),
                "created_at": now,
            })
            continue
        return None, "items must be strings or {content, activeForm, status} objects"
    return out, None



def run_todo(args: dict[str, Any]) -> ToolResult:
    """Session-scoped checklist tool — Claude Code ``TodoWrite`` shape.

    Primary primitive: pass ``todos: [{content, activeForm, status}]``
    and the runner overwrites the persisted list with this state.
    Status ∈ {``pending``, ``in_progress``, ``completed``}.
    rtxclaw stores ``done`` internally for completed items so the
    legacy ``format_todo_md`` keeps rendering, but accepts both
    ``done`` and ``completed`` from the model.

    Legacy shape ``action="add|replace|complete|delete|list", items,
    indexes`` is still honored for callers that haven't migrated.

    Persists to ``<sessions_dir>/<sid>.todos.json``.
    """
    todos_arg = args.get("todos")
    action = args.get("action")
    if isinstance(todos_arg, list) and not action:
        # Claude TodoWrite shape — wholesale replace.
        action = "replace"
        items_raw = todos_arg
    else:
        items_raw = args.get("items")
    if action not in ("add", "replace", "complete", "delete", "list"):
        return _err(
            "either pass `todos: [...]` (Claude TodoWrite shape) or "
            "`action ∈ {add, replace, complete, delete, list}`"
        )
    path = _todos_path_from_env()
    if path is None:
        return _err(
            "session todo file unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    items = load_todos(path)
    if action in ("add", "replace"):
        normalized, err = _normalize_todo_items(items_raw)
        if err is not None:
            return _err(err)
        assert normalized is not None
        if action == "add":
            items = items + normalized
        else:
            # replace: if the incoming content list matches the
            # persisted one in order, treat it as a state-merge instead
            # of an overwrite. The model occasionally re-emits the whole
            # plan via `replace` (sometimes with all items pre-marked
            # done) when it should have used `complete`. A naive
            # overwrite either wipes existing done flags (when items
            # come back as "pending") or duplicates the plan in the TUI.
            # Merging keeps `created_at`, ORs the `done` status, and
            # leaves the persisted file representing actual progress.
            existing_contents = [it.get("content") for it in items]
            new_contents = [it.get("content") for it in normalized]
            if items and existing_contents == new_contents:
                merged: list[dict[str, Any]] = []
                for old, new in zip(items, normalized):
                    status = (
                        "done" if old.get("status") == "done"
                        or new.get("status") == "done"
                        else "pending"
                    )
                    out_item = {**old, "status": status}
                    if "created_at" not in out_item and "created_at" in new:
                        out_item["created_at"] = new["created_at"]
                    merged.append(out_item)
                items = merged
            else:
                items = normalized
    elif action in ("complete", "delete"):
        idxs_raw = args.get("indexes")
        if not isinstance(idxs_raw, list) or not idxs_raw:
            return _err("indexes must be a non-empty list of integers")
        idxs: list[int] = []
        for i in idxs_raw:
            if not isinstance(i, int) or isinstance(i, bool):
                return _err("indexes must contain integers")
            if i < 0 or i >= len(items):
                return _err(
                    f"index out of range: {i} "
                    f"(have {len(items)} item(s))"
                )
            idxs.append(i)
        if action == "complete":
            for i in idxs:
                items[i] = {**items[i], "status": "done"}
        else:
            drop = set(idxs)
            items = [t for n, t in enumerate(items) if n not in drop]
    if action != "list":
        try:
            _save_todos(path, items)
        except OSError as e:
            return _err(f"failed to write {path}: {e}")
    return ToolResult(content=format_todo_md(items), ok=True)


# ---- Task family (harness task tracker) ----

# Mirrors Claude Code's TaskCreate / TaskUpdate / TaskList / TaskGet
# tool family but persisted to the same per-session sidecar pattern
# used by TodoWrite. Distinct from TodoWrite:
#   - TodoWrite holds the model's working plan (single list, the
#     model rewrites it each turn).
#   - Task* holds a persistent task tracker with stable numeric ids,
#     subject + description + status, owner, and block/blockedBy
#     relations. Survives across turns and shows in the
#     ``#harness-tasks`` TUI footer.
#
# State file: ``<sessions_dir>/<sid>.tasks.json``. Shape:
#   {"next_id": int, "tasks": {id_str: {subject, description,
#     activeForm, status, owner, blocks: [id...], blockedBy: [id...],
#     metadata: {...}}}}


_TASK_VALID_STATUSES: frozenset[str] = frozenset(
    {"pending", "in_progress", "completed", "deleted"}
)


def _tasks_path_from_env() -> Optional[Path]:
    sid = os.environ.get("RTXCLAW_SESSION_ID")
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return Path(sdir) / f"{sid}.tasks.json"


def _load_tasks(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"next_id": 1, "tasks": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"next_id": 1, "tasks": {}}
    if not isinstance(data, dict):
        return {"next_id": 1, "tasks": {}}
    if not isinstance(data.get("tasks"), dict):
        data["tasks"] = {}
    if not isinstance(data.get("next_id"), int) or data["next_id"] < 1:
        data["next_id"] = max(
            (int(k) for k in data["tasks"].keys() if str(k).isdigit()),
            default=0,
        ) + 1
    return data


def _save_tasks(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(state, indent=2, ensure_ascii=False) + "\n"
    tmp = path.with_name(f".{path.name}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(payload)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _task_summary(t: dict[str, Any]) -> str:
    blockers = t.get("blockedBy") or []
    blocker_str = ""
    if blockers:
        blocker_str = f" blockedBy={','.join(str(b) for b in blockers)}"
    owner = t.get("owner") or ""
    owner_str = f" owner={owner}" if owner else ""
    return (
        f"#{t.get('id')} [{t.get('status') or 'pending'}] "
        f"{(t.get('subject') or '').strip()}{owner_str}{blocker_str}"
    )


def run_task_create(args: dict[str, Any]) -> ToolResult:
    """Create a new task in the session-scoped task store.

    Required: ``subject`` (synonyms ``title`` / ``name`` /
    ``content`` accepted). Optional: ``description``,
    ``activeForm``, ``metadata`` (dict). Status starts at
    ``pending``. Assigned id is returned in the result body
    (``"Task #N created successfully: …"``) so the TUI can parse it
    for the harness-task footer.
    """
    # Accept the common alternates that smaller-context LLMs reach
    # for first (deepseek-v4-pro / qwen / kimi tend to emit
    # ``title`` or ``name`` when the schema says ``subject``). The
    # canonical key remains ``subject``.
    subject = (
        args.get("subject")
        or args.get("title")
        or args.get("name")
        or args.get("content")
    )
    if not isinstance(subject, str) or not subject.strip():
        return _err(
            "`subject` (non-empty string) required — synonyms "
            "title / name / content also accepted"
        )
    description = args.get("description")
    if description is not None and not isinstance(description, str):
        return _err("`description` must be a string")
    active_form = args.get("activeForm")
    if active_form is not None and not isinstance(active_form, str):
        return _err("`activeForm` must be a string")
    metadata = args.get("metadata")
    if metadata is not None and not isinstance(metadata, dict):
        return _err("`metadata` must be an object")
    path = _tasks_path_from_env()
    if path is None:
        return _err(
            "session task file unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    state = _load_tasks(path)
    tid = int(state.get("next_id") or 1)
    state["next_id"] = tid + 1
    task = {
        "id": tid,
        "subject": subject.strip(),
        "description": (description or "").strip(),
        "activeForm": (active_form or "").strip(),
        "status": "pending",
        "owner": "",
        "blocks": [],
        "blockedBy": [],
        "metadata": metadata or {},
    }
    state["tasks"][str(tid)] = task
    try:
        _save_tasks(path, state)
    except OSError as e:
        return _err(f"failed to write {path}: {e}")
    return ToolResult(
        content=f"Task #{tid} created successfully: {subject.strip()}",
        ok=True,
    )


def run_task_update(args: dict[str, Any]) -> ToolResult:
    """Update an existing task. Required: ``taskId``. Optional:
    ``status``, ``subject``, ``description``, ``activeForm``, ``owner``,
    ``addBlocks`` (list[int]), ``addBlockedBy`` (list[int]),
    ``metadata`` (merged into existing). ``status="deleted"`` removes
    the task.
    """
    tid_raw = (
        args.get("taskId")
        if args.get("taskId") is not None
        else args.get("task_id")
        if args.get("task_id") is not None
        else args.get("id")
    )
    if not isinstance(tid_raw, (str, int)):
        return _err(
            "`taskId` required (synonyms task_id / id also accepted)"
        )
    tid = str(tid_raw)
    path = _tasks_path_from_env()
    if path is None:
        return _err(
            "session task file unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    state = _load_tasks(path)
    task = state["tasks"].get(tid)
    if task is None:
        return _err(f"unknown taskId: {tid}")
    if (status := args.get("status")) is not None:
        if status == "deleted":
            del state["tasks"][tid]
            try:
                _save_tasks(path, state)
            except OSError as e:
                return _err(f"failed to write {path}: {e}")
            return ToolResult(
                content=f"Task #{tid} deleted",
                ok=True,
            )
        if status not in _TASK_VALID_STATUSES:
            return _err(
                f"`status` must be one of {sorted(_TASK_VALID_STATUSES)}"
            )
        task["status"] = status
    for fld in ("subject", "description", "activeForm", "owner"):
        if (v := args.get(fld)) is not None:
            if not isinstance(v, str):
                return _err(f"`{fld}` must be a string")
            task[fld] = v.strip() if fld != "description" else v
    if (ab := args.get("addBlocks")) is not None:
        if not isinstance(ab, list):
            return _err("`addBlocks` must be a list of task ids")
        cur = set(task.get("blocks") or [])
        for v in ab:
            cur.add(int(v))
        task["blocks"] = sorted(cur)
    if (abb := args.get("addBlockedBy")) is not None:
        if not isinstance(abb, list):
            return _err("`addBlockedBy` must be a list of task ids")
        cur = set(task.get("blockedBy") or [])
        for v in abb:
            cur.add(int(v))
        task["blockedBy"] = sorted(cur)
    if (md := args.get("metadata")) is not None:
        if not isinstance(md, dict):
            return _err("`metadata` must be an object")
        merged = dict(task.get("metadata") or {})
        for k, v in md.items():
            if v is None:
                merged.pop(k, None)
            else:
                merged[k] = v
        task["metadata"] = merged
    try:
        _save_tasks(path, state)
    except OSError as e:
        return _err(f"failed to write {path}: {e}")
    return ToolResult(
        content=f"Updated task #{tid} status",
        ok=True,
    )


def run_task_list(args: dict[str, Any]) -> ToolResult:
    """List all tasks in id order. Each row shows
    ``#id [status] subject [owner=X] [blockedBy=A,B]``.
    """
    path = _tasks_path_from_env()
    if path is None:
        return _err(
            "session task file unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    state = _load_tasks(path)
    tasks = state.get("tasks") or {}
    if not tasks:
        return ToolResult(content="(no tasks)", ok=True)
    ordered = sorted(
        tasks.values(),
        key=lambda t: int(t.get("id") or 0),
    )
    body = "\n".join(_task_summary(t) for t in ordered)
    return ToolResult(content=body, ok=True)


def run_task_get(args: dict[str, Any]) -> ToolResult:
    """Fetch a single task's full details for the model."""
    tid_raw = (
        args.get("taskId")
        if args.get("taskId") is not None
        else args.get("task_id")
        if args.get("task_id") is not None
        else args.get("id")
    )
    if not isinstance(tid_raw, (str, int)):
        return _err(
            "`taskId` required (synonyms task_id / id also accepted)"
        )
    tid = str(tid_raw)
    path = _tasks_path_from_env()
    if path is None:
        return _err(
            "session task file unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    state = _load_tasks(path)
    task = state["tasks"].get(tid)
    if task is None:
        return _err(f"unknown taskId: {tid}")
    return ToolResult(
        content=json.dumps(task, indent=2, ensure_ascii=False),
        ok=True,
    )


def _output_sections_path() -> Optional[Path]:
    sid = os.environ.get("RTXCLAW_SESSION_ID")
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sdir:
        return None
    return Path(sdir) / f"{sid}.output_sections.json"


def run_output_section(args: dict[str, Any]) -> ToolResult:
    """Per-section emission for long structured responses.

    Persists the current section to ``<sid>.output_sections.json`` and
    returns a short directive telling the model what to do next:
    "write the next section: <name>" or "draft complete — end your
    turn." Designed to keep each round's content small enough that
    long-context coherence collapse doesn't fire on the report-writing
    rounds (witnessed 2026-05-10 on qwen3.6-fp8-mtp at >70k context).

    See the OutputSection tool description in ``registry.py`` for the
    full pattern.
    """
    section_name = args.get("section_name")
    content = args.get("content")
    outline = args.get("outline")
    is_final = bool(args.get("is_final", False))
    if not isinstance(section_name, str) or not section_name.strip():
        return _err("`section_name` (string) required")
    if not isinstance(content, str):
        return _err("`content` (string) required")
    path = _output_sections_path()
    if path is None:
        return _err(
            "session output-sections file unresolved — RTXCLAW_SESSION_ID "
            "/ RTXCLAW_SESSIONS_DIR not set in env"
        )
    state: dict[str, Any] = {"outline": [], "sections": {}, "order": []}
    if path.exists():
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
    # First call: lock the outline. Subsequent calls: ignore any
    # outline arg the model resends so it can't re-plan mid-draft.
    if not state.get("outline"):
        if isinstance(outline, list) and all(isinstance(x, str) for x in outline):
            cleaned = [s.strip() for s in outline if s.strip()]
            state["outline"] = cleaned
        else:
            return _err(
                "first call must include `outline=[<section_name>, …]` "
                "listing every section the model intends to write"
            )
    name_clean = section_name.strip()
    state["sections"][name_clean] = content
    if name_clean not in state["order"]:
        state["order"].append(name_clean)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f".{path.name}.tmp")
        tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2))
        os.replace(tmp, path)
    except OSError as e:
        return _err(f"failed to write {path}: {e}")
    written = set(state["order"])
    remaining = [s for s in state["outline"] if s not in written]
    written_count = len(written)
    total = len(state["outline"])
    if is_final or not remaining:
        return ToolResult(
            content=(
                f"Section {written_count}/{total} ({name_clean!r}) saved. "
                f"Draft complete — end your turn now without writing more "
                f"text. The user has the full output via the section "
                f"stream."
            ),
            ok=True,
        )
    next_section = remaining[0]
    return ToolResult(
        content=(
            f"Section {written_count}/{total} ({name_clean!r}) saved. "
            f"Next: {next_section!r}. Write only that ONE section in your "
            f"next round, end with another OutputSection call. Do NOT "
            f"resend the outline."
        ),
        ok=True,
    )


def run_user_question(args: dict[str, Any]) -> ToolResult:
    """Ask the user a clarifying question. Reserved for the main agent.

    Implementation note: this runner just dispatches the question +
    options as a structured payload back to the model as the tool
    result. The bridge surfaces the question to the frontend (TUI /
    Telegram) via the regular tool-result rendering, the model is
    instructed to end its turn after calling the tool, and the user's
    next message in the session is interpreted as the answer (the
    model sees normal user text in context).

    A future iteration can promote this to a synchronous round-trip
    via ACP ``session/request_permission``-style plumbing — for now
    the async-by-text path is a 0-cost MVP and works on every
    frontend without changes.
    """
    question = args.get("question")
    options = args.get("options")
    if not isinstance(question, str) or not question.strip():
        return _err("`question` (non-empty string) required")
    if not isinstance(options, list) or len(options) < 2 or len(options) > 4:
        return _err(
            "`options` must be a list of 2–4 {label, description} dicts"
        )
    lines = [
        f"❓ **User question dispatched**",
        "",
        question.strip(),
        "",
    ]
    for i, opt in enumerate(options, 1):
        if not isinstance(opt, dict):
            return _err(f"options[{i-1}] must be a dict with `label`")
        label = str(opt.get("label") or "").strip()
        if not label:
            return _err(f"options[{i-1}] missing required `label`")
        desc = str(opt.get("description") or "").strip()
        if desc:
            lines.append(f"  {i}. **{label}** — {desc}")
        else:
            lines.append(f"  {i}. **{label}**")
    lines.extend(
        [
            "",
            "(end your turn now — the user's next message is the answer)",
        ]
    )
    return ToolResult(content="\n".join(lines), ok=True)


# ---- dispatcher ----

# Sync tools dispatch to a thread; async tools run on the event loop.
def run_memory_search(args: dict[str, Any]) -> ToolResult:
    """Hybrid search over MEMORY.md + memory/YYYY-MM-DD.md.

    The runner subprocess inherits `RTXCLAW_AGENT_HOME` and
    `RTXCLAW_WORKSPACE_ORIGIN` from the parent — the privacy gate
    inside `memory_search` reads `workspace_origin` to refuse calls
    from shared frontends.
    """
    from rtxclaw_memory import memory_tools as _mt
    query = args.get("query")
    if not isinstance(query, str) or not query.strip():
        return _err("query required")
    top_k = args.get("top_k")
    min_score = args.get("min_score")
    relevance_floor = args.get("relevance_floor")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    body = _mt.memory_search(
        query,
        top_k=int(top_k) if isinstance(top_k, (int, float)) else 6,
        min_score=float(min_score) if isinstance(min_score, (int, float)) else 0.35,
        relevance_floor=float(relevance_floor) if isinstance(relevance_floor, (int, float)) else 0.0,
        workspace_origin=workspace_origin,
    )
    body, truncated = _truncate(body)
    ok = not body.startswith("memory_search failed") and not body.startswith("memory_search refused")
    return ToolResult(content=body, ok=ok, truncated=truncated)


def run_memory_get(args: dict[str, Any]) -> ToolResult:
    from rtxclaw_memory import memory_tools as _mt
    file_path = args.get("file_path")
    if not isinstance(file_path, str) or not file_path:
        return _err("file_path required")
    start_line = args.get("start_line")
    end_line = args.get("end_line")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    body = _mt.memory_get(
        file_path,
        start_line=int(start_line) if isinstance(start_line, (int, float)) else None,
        end_line=int(end_line) if isinstance(end_line, (int, float)) else None,
        workspace_origin=workspace_origin,
    )
    body, truncated = _truncate(body)
    ok = not body.startswith("memory_get failed") and not body.startswith("memory_get refused")
    return ToolResult(content=body, ok=ok, truncated=truncated)


async def run_remember_async(args: dict[str, Any]) -> ToolResult:
    """`remember` runner — calls the full pipeline in `memory_write`.

    Reads agent home, workspace_origin, and upstream config from env
    vars set by `agent_runtime._spawn_tool_runner`:

    - RTXCLAW_AGENT_NAME
    - RTXCLAW_AGENT_HOME
    - RTXCLAW_WORKSPACE_ORIGIN
    - RTXCLAW_UPSTREAM_ENDPOINT
    - RTXCLAW_UPSTREAM_MODEL
    - RTXCLAW_UPSTREAM_BACKEND
    - RTXCLAW_REMEMBER_SYNTH_MODEL (optional)

    The runner subprocess instantiates a thin `_RuntimeCfgShim`
    (looks like AgentConfig from `memory_write.remember`'s POV)
    rather than re-loading the full config from disk.
    """
    from rtxclaw_memory import memory_write as _mw

    action = args.get("action")
    content = args.get("content")
    old_text = args.get("old_text")
    category = args.get("category")

    if not isinstance(action, str) or action not in ("add", "replace", "remove"):
        return _err("action ∈ {add, replace, remove} required")

    home_str = os.environ.get("RTXCLAW_AGENT_HOME") or ""
    if not home_str:
        return _err("RTXCLAW_AGENT_HOME not set in env")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    cfg = _RememberCfgShim(
        name=os.environ.get("RTXCLAW_AGENT_NAME") or "main",
        home=Path(home_str),
        remember_synthesizer_model=os.environ.get("RTXCLAW_REMEMBER_SYNTH_MODEL", ""),
        memory_flush_model=os.environ.get("RTXCLAW_MEMORY_FLUSH_MODEL", ""),
    )
    result = await _mw.remember(
        action=action,
        content=content if isinstance(content, str) else "",
        old_text=old_text if isinstance(old_text, str) else "",
        category=category if isinstance(category, str) else "",
        cfg=cfg,
        workspace_origin=workspace_origin,
    )
    body = result.summary
    if result.error:
        body += f"\nerror: {result.error}"
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=result.ok, truncated=truncated)


# Lightweight stand-in for AgentConfig — only the fields `remember`
# reads. Using a real AgentConfig here would force a full disk read
# of the global + per-agent config inside every tool runner.
@dataclass(frozen=True)
class _RememberCfgShim:
    name: str
    home: Path
    remember_synthesizer_model: str = ""
    memory_flush_model: str = ""


def run_session_search(args: dict[str, Any]) -> ToolResult:
    """FTS5 search over saved session turns.

    Same env-driven pattern as `run_memory_search`: the runner
    subprocess inherits `RTXCLAW_AGENT_HOME` + `RTXCLAW_WORKSPACE_ORIGIN`,
    and the privacy gate inside `session_search` refuses calls from
    shared frontends.
    """
    from rtxclaw_core import session_index as _si
    query = args.get("query")
    if not isinstance(query, str) or not query.strip():
        return _err("query required")
    top_k = args.get("top_k")
    min_score = args.get("min_score")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    body = _si.session_search(
        query,
        top_k=int(top_k) if isinstance(top_k, (int, float)) else 6,
        min_score=float(min_score) if isinstance(min_score, (int, float)) else 0.35,
        workspace_origin=workspace_origin,
    )
    body, truncated = _truncate(body)
    ok = (
        not body.startswith("session_search failed")
        and not body.startswith("session_search refused")
    )
    return ToolResult(content=body, ok=ok, truncated=truncated)


def run_fact_store(args: dict[str, Any]) -> ToolResult:
    """Dispatch one of the `fact_store` sub-actions."""
    from rtxclaw_core import sqlite_facts as _sf
    action = args.get("action")
    if not isinstance(action, str) or action not in (
        "add", "search", "list", "remove", "update",
    ):
        return _err("action ∈ {add,search,list,remove,update} required")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    top_k = args.get("top_k")
    body = _sf.fact_store(
        action=action,
        category=str(args.get("category") or ""),
        content=str(args.get("content") or ""),
        old_content_prefix=str(args.get("old_content_prefix") or ""),
        new_content=str(args.get("new_content") or ""),
        query=str(args.get("query") or ""),
        tags=args.get("tags"),
        top_k=int(top_k) if isinstance(top_k, (int, float)) else 6,
        workspace_origin=workspace_origin,
    )
    body, truncated = _truncate(body)
    ok = (
        not body.startswith("fact_store failed")
        and not body.startswith("fact_store refused")
        and not body.startswith("fact_store add refused")
        and not body.startswith("fact_store remove refused")
        and not body.startswith("fact_store update refused")
    )
    return ToolResult(content=body, ok=ok, truncated=truncated)


def run_fact_feedback(args: dict[str, Any]) -> ToolResult:
    """Adjust trust on a fact_store row."""
    from rtxclaw_core import sqlite_facts as _sf
    fact_ref = args.get("fact_id_or_prefix")
    helpful = args.get("helpful")
    if not isinstance(fact_ref, str) or not fact_ref.strip():
        return _err("fact_id_or_prefix required")
    if not isinstance(helpful, bool):
        return _err("helpful: boolean required")
    workspace_origin = os.environ.get("RTXCLAW_WORKSPACE_ORIGIN", "")
    body = _sf.fact_feedback(
        fact_id_or_prefix=fact_ref,
        helpful=helpful,
        workspace_origin=workspace_origin,
    )
    body, truncated = _truncate(body)
    ok = (
        not body.startswith("fact_feedback failed")
        and not body.startswith("fact_feedback refused")
    )
    return ToolResult(content=body, ok=ok, truncated=truncated)


def run_pin_fact(args: dict[str, Any]) -> ToolResult:
    """Pin a fact to the session's persistent ``pinned_facts`` list.

    The list is re-injected into every prompt during turn assembly so
    pinned facts survive turn-to-turn (cf. ``Session.pinned_facts``).
    Idempotent: pinning the same fact twice is a no-op.
    """
    fact = args.get("fact")
    if not isinstance(fact, str) or not fact.strip():
        return _err("fact must be a non-empty string")
    sid = os.environ.get("RTXCLAW_SESSION_ID")
    sessions_dir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if not sid or not sessions_dir:
        return _err(
            "session unresolved — RTXCLAW_SESSION_ID / "
            "RTXCLAW_SESSIONS_DIR not set in env"
        )
    # pinned_facts live in sessions.db (materialised header). Read
    # the current list, append, and persist via SessionWriter.header_update
    # (appends a header_update JSONL event under the per-session flock —
    # the same lock the engine's writer uses, so no raw-write race that
    # the legacy path had). The lazy index picks it up on the next tail.
    sdir = Path(sessions_dir)
    jsonl = sdir / f"{sid}.jsonl"
    if not jsonl.exists():
        return _err(f"session not found: {jsonl}")
    fact_norm = fact.strip()
    try:
        from rtxclaw_core.session_index import SessionIndex, connect_sessions_db
        from rtxclaw_core.session_writer import get_session_writer
        idx = SessionIndex(sdir.parent)
        idx.tail(sid)
        pinned: list = []
        con = connect_sessions_db(idx.db_path)
        try:
            r = con.execute(
                "SELECT pinned_facts FROM sessions_meta WHERE session_hash=?",
                (sid,),
            ).fetchone()
            if r is not None and r["pinned_facts"]:
                try:
                    pinned = json.loads(r["pinned_facts"]) or []
                except (ValueError, TypeError):
                    pinned = []
        finally:
            con.close()
    except Exception as e:  # noqa: BLE001
        return _err(f"session read failed: {e}")
    if fact_norm in pinned:
        return ToolResult(
            content=f"already pinned ({len(pinned)} fact(s) total)", ok=True,
        )
    pinned.append(fact_norm)
    try:
        writer = get_session_writer(sdir, sid)
        writer.header_update(patch={"pinned_facts": pinned})
    except Exception as e:  # noqa: BLE001
        return _err(f"session save failed: {e}")
    return ToolResult(
        content=f"✓ pinned ({len(pinned)} fact(s) total)", ok=True,
    )


def run_skill_get(args: dict[str, Any]) -> ToolResult:
    # Claude Code's ``Skill`` uses ``skill`` (and optional ``args``) —
    # accept both that and the legacy ``name`` / no-args shape.
    name = args.get("skill") or args.get("name")
    extra_args = args.get("args")
    if not isinstance(name, str) or not name:
        return _err("skill name required")
    from rtxclaw_core import skills as _skills_mod
    skill = _skills_mod.find_skill(name)
    if skill is None:
        return _err(
            f"skill not found: {name!r}. Run `rtxclaw skills list` to "
            f"see what's installed."
        )
    body = skill.body or "(SKILL.md has frontmatter only — no body)"
    header = (
        f"# {skill.name}\n"
        f"_{skill.short_description}_\n\n"
        f"_(source: {skill.source})_\n\n---\n\n"
    )
    if isinstance(extra_args, str) and extra_args.strip():
        header += f"_(invoked with args: {extra_args.strip()})_\n\n"
    full = header + body
    full, truncated = _truncate(full)
    return ToolResult(content=full, ok=True, truncated=truncated)


def run_skill_search(args: dict[str, Any]) -> ToolResult:
    """The sole skill entrypoint — mirrors ``ToolSearch`` exactly.

    Three modes, dispatched on the ``query`` string:

    1. ``select:skill1,skill2`` — fetch FULL bodies of those skills.
       This replaces the old ``Skill(skill=…)`` tool: instead of
       SkillSearch + Skill round-trip, one call both finds and loads.
       The output starts with a ``selected: skill1, skill2`` machine-
       readable line (same shape as ToolSearch's selected line), then
       the bodies inside a ``<skills>…</skills>`` block.
    2. ``<keyword>`` — lexical ranking over name + short_description.
       Returns top ``max_results`` matches as ``name — description``
       so the model can pick one and call back with ``select:…``.
    3. Empty / ``"*"`` / ``"all"`` / ``"list"`` — alphabetised
       paginated full list. The "list everything" path that makes
       small models stop reaching for ``Bash ls`` on the skills dir.

    Lexical-only (substring + word match) so the tool is fast and
    dependency-free in the subprocess runner. The embedding-backed
    auto-invoke path (``cfg.skill_auto_invoke``) supplements this in
    the gateway — both keep the prompt small for local models.
    """
    raw_query = str(args.get("query") or "").strip()
    list_mode = raw_query in ("", "*", "all", "list", "ls")
    select_mode = raw_query.lower().startswith("select:")

    try:
        max_results_raw = int(
            args.get("max_results")
            or args.get("top_k")  # back-compat with the old name
            or (50 if list_mode else 10)
        )
    except (TypeError, ValueError):
        max_results_raw = 50 if list_mode else 10
    max_results = max(1, min(max_results_raw, 200 if list_mode else 50))
    try:
        offset = int(args.get("offset") or 0)
    except (TypeError, ValueError):
        offset = 0
    offset = max(0, offset)

    from rtxclaw_core import skills as _skills_mod
    skills = _skills_mod.discover_skills()
    if not skills:
        return ToolResult(
            content=(
                "(no skills installed — see `skills_dirs` in "
                "~/.rtxclaw/config.json)"
            ),
            ok=True,
        )

    # -- select: mode -- load full bodies, ToolSearch-shaped output --
    if select_mode:
        wanted = [
            s.strip()
            for s in raw_query[len("select:"):].split(",")
            if s.strip()
        ]
        by_name = {s.name: s for s in skills}
        loaded: list[Any] = []
        missing: list[str] = []
        for name in wanted:
            sk = by_name.get(name)
            if sk is None:
                missing.append(name)
            else:
                loaded.append(sk)
        if not loaded:
            return ToolResult(
                content=(
                    f"# SkillSearch — no match for {wanted!r}\n\n"
                    f"Searched {len(skills)} installed skill(s). "
                    "Names are kebab-case; call `SkillSearch()` with "
                    "no query to list every installed skill."
                ),
                ok=True,
            )
        bits: list[str] = [
            "selected: " + ", ".join(s.name for s in loaded),
            "",
            "<skills>",
        ]
        for sk in loaded:
            body = sk.body or "(SKILL.md has frontmatter only — no body)"
            bits.append(f"## {sk.name}")
            if sk.short_description:
                bits.append(f"_{sk.short_description}_")
            bits.append(f"_(source: {sk.source})_")
            bits.append("")
            bits.append(body)
            bits.append("")
        bits.append("</skills>")
        if missing:
            bits.append("")
            bits.append(
                f"_not found: {', '.join(missing)} — try "
                "`SkillSearch(query=\"<keywords>\")` to find by topic._"
            )
        full, truncated = _truncate("\n".join(bits))
        return ToolResult(content=full, ok=True, truncated=truncated)

    # -- list mode -- alphabetised paginated dump --
    if list_mode:
        ordered = sorted(skills, key=lambda s: s.name.lower())
        total = len(ordered)
        page = ordered[offset : offset + max_results]
        end = offset + len(page)
        lines = [
            f"# SkillSearch — listing {len(page)} of {total} installed skill(s)",
            (
                f"_(page {offset}–{end}; pass `offset` + `max_results` "
                "to paginate, or `query=\"<keywords>\"` to rank, or "
                "`query=\"select:<name>,…\"` to load bodies)_"
            ),
            "",
        ]
        for s in page:
            lines.append(f"- **{s.name}** — {s.short_description}")
        lines.append("")
        lines.append(
            "Call `SkillSearch(query=\"select:<name>\")` to read the "
            "full body of one (or more, comma-separated)."
        )
        full, truncated = _truncate("\n".join(lines))
        return ToolResult(content=full, ok=True, truncated=truncated)

    # -- keyword mode -- ranked lexical match --
    query = raw_query
    q_lower = query.lower()
    q_words = [w for w in q_lower.split() if len(w) >= 3]
    scored: list[tuple[float, Any]] = []
    for s in skills:
        name_l = s.name.lower()
        desc_l = (s.description or "").lower()
        score = 0.0
        if q_lower == name_l:
            score += 10.0
        elif q_lower in name_l:
            score += 4.0
        if q_lower in desc_l:
            score += 2.0
        for w in q_words:
            if w in name_l:
                score += 1.5
            if w in desc_l:
                score += 0.5
        if score > 0:
            scored.append((score, s))
    scored.sort(key=lambda t: t[0], reverse=True)
    hits = scored[:max_results]
    if not hits:
        return ToolResult(
            content=(
                f"# SkillSearch — no match for {query!r}\n\n"
                f"Searched {len(skills)} installed skill(s). Try "
                "different keywords (skill names are kebab-case), or "
                "call `SkillSearch()` with no query to list them all."
            ),
            ok=True,
        )
    lines = [
        f"# SkillSearch — {len(hits)} match(es) for {query!r}",
        f"_(searched {len(skills)} installed skill(s); top {max_results})_",
        "",
    ]
    for score, s in hits:
        lines.append(f"- **{s.name}** (score {score:.1f}) — {s.short_description}")
    lines.append("")
    lines.append(
        "Call `SkillSearch(query=\"select:<name>\")` to read the full "
        "body of one (or more, comma-separated)."
    )
    full, truncated = _truncate("\n".join(lines))
    return ToolResult(content=full, ok=True, truncated=truncated)


# ---- MCP / ACP tool runners ----------------------------------------
#
# The MCP runners go through `rtxclaw.mcp_client`, which opens a
# one-shot session per call (see that module's docstring for the
# rationale). The ACP runner goes through `rtxclaw_acp.client` — it
# picks the right transport from the configured `acp_agents` row
# (stdio / ws / http), runs the standard ACP handshake, drives one
# prompt turn, and closes the session.
#
# All three are NETWORK-kind tools, so the existing permission gate
# treats them like web_fetch/delegate_claude — `auto` runs them
# silently, `ask` prompts.


async def run_mcp_list_tools_async(args: dict[str, Any]) -> ToolResult:
    server_name = args.get("server_name")
    if not isinstance(server_name, str) or not server_name:
        return _err("server_name required")
    from rtxclaw_mcp import mcp_client as _mcp
    servers = _mcp.load_mcp_servers()
    server = servers.get(server_name)
    if server is None:
        configured = ", ".join(sorted(servers)) or "(none configured)"
        return _err(
            f"unknown MCP server: {server_name!r}. "
            f"Configured: {configured}. Edit `mcp_servers` in "
            "~/.rtxclaw/config.json to add one."
        )
    ok, tools, err = await _mcp.list_tools(server)
    if not ok:
        return _err(
            f"mcp_list_tools failed against {server_name!r}: "
            f"{err or 'unknown error'}"
        )
    if not tools:
        return ToolResult(
            content=f"# MCP server {server_name!r}\n\n(server reports no tools)",
            ok=True,
        )
    lines = [f"# MCP server {server_name!r}", ""]
    for t in tools:
        lines.append(f"## {t.get('name', '?')}")
        desc = (t.get("description") or "").strip()
        if desc:
            lines.append("")
            lines.append(desc)
        schema = t.get("inputSchema") or {}
        if schema:
            lines.append("")
            lines.append("Input schema:")
            lines.append("```json")
            try:
                lines.append(json.dumps(schema, ensure_ascii=False, indent=2))
            except (TypeError, ValueError):
                lines.append(str(schema))
            lines.append("```")
        lines.append("")
    body = "\n".join(lines).rstrip() + "\n"
    body, truncated = _truncate(body)
    return ToolResult(content=body, ok=True, truncated=truncated)


async def run_mcp_call_async(args: dict[str, Any]) -> ToolResult:
    server_name = args.get("server_name")
    tool_name = args.get("tool_name")
    arguments = args.get("arguments") or {}
    if not isinstance(server_name, str) or not server_name:
        return _err("server_name required")
    if not isinstance(tool_name, str) or not tool_name:
        return _err("tool_name required")
    if not isinstance(arguments, dict):
        return _err("arguments must be an object")
    from rtxclaw_mcp import mcp_client as _mcp
    servers = _mcp.load_mcp_servers()
    server = servers.get(server_name)
    if server is None:
        configured = ", ".join(sorted(servers)) or "(none configured)"
        return _err(
            f"unknown MCP server: {server_name!r}. "
            f"Configured: {configured}. Edit `mcp_servers` in "
            "~/.rtxclaw/config.json to add one."
        )
    ok, body = await _mcp.call_tool(server, tool_name, arguments)
    body, truncated = _truncate(body or "(empty result)")
    header = f"[mcp {server_name}/{tool_name}]"
    full = f"{header}\n\n{body}"
    return ToolResult(content=full, ok=ok, truncated=truncated)


def _load_acp_agents_cfg() -> dict[str, dict[str, Any]]:
    """Read the ``acp_agents`` map out of the global config.

    Returns ``{name: row_dict}`` for every entry; bad rows (non-dict)
    are dropped silently. We deliberately do NOT validate row shape
    here — the per-row dispatcher in ``_drive_acp_session_async``
    inspects ``url`` / ``command`` to pick the transport, and an
    unrecognised shape is reported as a runtime error there. Kept as
    a module-level helper so tests can monkeypatch it.
    """
    try:
        from rtxclaw_core.agent import load_global_config
        global_cfg = load_global_config() or {}
    except Exception:  # noqa: BLE001
        global_cfg = {}
    raw = global_cfg.get("acp_agents") or {}
    if not isinstance(raw, dict):
        return {}
    return {
        name: row for name, row in raw.items() if isinstance(row, dict)
    }


async def _drive_acp_session_async(
    cfg: dict[str, Any],
    prompt: str,
    *,
    mode: str,
    cwd: Optional[str],
    on_delta: Optional[Callable[[str], None]],
) -> tuple[bool, str, dict[str, Any]]:
    """One-shot drive of a remote ACP agent over the appropriate transport.

    Picks the transport from ``cfg``:

    - ``cfg["command"]`` (list[str]) → stdio (``spawn_stdio_agent``).
    - ``cfg["url"]`` starts with ``ws://`` / ``wss://`` → ``connect_ws``.
    - ``cfg["url"]`` starts with ``http://`` / ``https://`` →
      ``connect_http``.

    Runs the standard handshake (``initialize`` → ``session/new`` →
    ``session/prompt``), assembles agent-message-chunk text into the
    return body, forwards each chunk through ``on_delta``, and closes
    the session + transport on the way out. Returns
    ``(ok, body, meta)`` so the caller renders the same ``[acp …]``
    header shape as before.
    """
    from rtxclaw_acp.client import (
        spawn_stdio_agent,
        connect_ws,
        connect_http,
    )
    import acp.schema as _acp_schema

    text_buf: list[str] = []
    meta: dict[str, Any] = {"state": "unknown", "error": None}

    # Pick the transport based on the row's shape.
    command = cfg.get("command")
    url = cfg.get("url")
    bearer = cfg.get("token") or None

    client = None
    aux: Any = None  # process | aiohttp.ClientSession | None
    transport_kind: str
    try:
        if isinstance(command, list) and command:
            transport_kind = "stdio"
            client, aux = await spawn_stdio_agent(
                [str(x) for x in command], cwd=cwd,
            )
        elif isinstance(url, str) and url.startswith(("ws://", "wss://")):
            transport_kind = "ws"
            headers = {"Authorization": f"Bearer {bearer}"} if bearer else None
            client, aux = await connect_ws(url, headers=headers)
        elif isinstance(url, str) and url.startswith(("http://", "https://")):
            transport_kind = "http"
            client = await connect_http(url, bearer_token=bearer)
        else:
            return False, "", {
                "state": "error",
                "error": (
                    "ACP agent row needs `command` (list[str]) for "
                    "stdio, or `url` (ws://, wss://, http://, https://) "
                    "for network transports"
                ),
            }
    except Exception as e:  # noqa: BLE001
        return False, "", {
            "state": "error",
            "error": f"ACP transport setup failed: {type(e).__name__}: {e}",
        }

    try:
        try:
            await client.initialize()
        except Exception as e:  # noqa: BLE001
            return False, "", {
                "state": "error",
                "error": f"initialize failed: {type(e).__name__}: {e}",
            }

        try:
            session_id = await client.session_new(cwd or os.getcwd())
        except Exception as e:  # noqa: BLE001
            return False, "", {
                "state": "error",
                "error": f"session/new failed: {type(e).__name__}: {e}",
            }

        # `mode` is rtxclaw's permission concept (plan/ask/auto). The
        # agent may or may not advertise a matching session mode; we
        # try to set it but tolerate failure (capability gate or
        # unknown id) — the prompt still goes through.
        try:
            await client.session_set_mode(session_id, mode)
        except Exception:  # noqa: BLE001
            pass

        text_block = _acp_schema.TextContentBlock(text=prompt, type="text")
        prompt_blocks = [text_block.model_dump(by_alias=True)]
        stop_reason: Optional[str] = None
        try:
            async for item in client.session_prompt(session_id, prompt_blocks):
                if isinstance(item, _acp_schema.SessionNotification):
                    update = item.update
                    chunk = ""
                    # AgentMessageChunk / AgentThoughtChunk both carry
                    # a `content` ContentBlock; surface text only —
                    # images/audio/resources are ignored for the
                    # assembled text body but still streamed by
                    # transport.
                    content = getattr(update, "content", None)
                    if content is not None and getattr(content, "type", None) == "text":
                        chunk = getattr(content, "text", "") or ""
                    if chunk:
                        text_buf.append(chunk)
                        if on_delta is not None:
                            try:
                                on_delta(chunk)
                            except Exception:  # noqa: BLE001
                                pass
                elif isinstance(item, _acp_schema.PromptResponse):
                    stop_reason = item.stop_reason
        except Exception as e:  # noqa: BLE001
            meta["state"] = "error"
            meta["error"] = f"session/prompt failed: {type(e).__name__}: {e}"
            return False, "".join(text_buf), meta

        # Map StopReason → legacy meta.state for the [acp …] header.
        # `end_turn` is the success path; everything else surfaces as
        # the state string and is treated as not-ok at the caller.
        if stop_reason == "end_turn":
            meta["state"] = "done"
            meta["error"] = None
            ok = True
        else:
            meta["state"] = stop_reason or "incomplete"
            meta["error"] = (
                None if stop_reason is None else f"stop_reason={stop_reason}"
            )
            ok = False

        try:
            await client.session_close(session_id)
        except Exception:  # noqa: BLE001 — best-effort
            pass
        return ok, "".join(text_buf), meta
    finally:
        # Orderly client teardown. The transport's close path is the
        # one wired into the killability story (subprocess stdin EOF /
        # WS close frame / HTTP DELETE).
        try:
            await client.close()
        except Exception:  # noqa: BLE001
            pass
        # Each transport family has its own auxiliary handle:
        # - stdio: asyncio.subprocess.Process — wait briefly for clean
        #   exit, then SIGKILL if it's still running. Mirrors the
        #   killability rule without leaving zombies.
        # - ws: aiohttp.ClientSession — must close for connector cleanup.
        # - http: no auxiliary; client.close() does it all.
        if transport_kind == "stdio" and aux is not None:
            proc = aux
            try:
                await asyncio.wait_for(proc.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                except Exception:  # noqa: BLE001
                    pass
            except Exception:  # noqa: BLE001
                pass
        elif transport_kind == "ws" and aux is not None:
            try:
                await aux.close()
            except Exception:  # noqa: BLE001
                pass


async def run_acp_call_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
) -> ToolResult:
    agent_name = args.get("agent_name")
    prompt = args.get("prompt")
    mode = args.get("mode") or os.environ.get("RTXCLAW_PERMISSION_MODE", "auto")
    cwd = args.get("cwd")
    if not isinstance(agent_name, str) or not agent_name:
        return _err("agent_name required")
    if not isinstance(prompt, str) or not prompt.strip():
        return _err("prompt required")
    if mode not in ("plan", "ask", "auto"):
        mode = "auto"
    agents = _load_acp_agents_cfg()
    cfg = agents.get(agent_name)
    if cfg is None:
        configured = ", ".join(sorted(agents)) or "(none configured)"
        return _err(
            f"unknown ACP agent: {agent_name!r}. "
            f"Configured: {configured}. Edit `acp_agents` in "
            "~/.rtxclaw/config.json to add one."
        )
    ok, body, meta = await _drive_acp_session_async(
        cfg, prompt, mode=mode,
        cwd=str(cwd) if isinstance(cwd, str) and cwd else None,
        on_delta=on_delta,
    )
    if not body:
        body = "(remote returned empty body)"
    header_bits = [f"agent={agent_name}", f"mode={mode}"]
    if meta.get("state"):
        header_bits.append(f"state={meta['state']}")
    if meta.get("error"):
        header_bits.append("error")
    header = "[acp " + " · ".join(header_bits) + "]"
    full = f"{header}\n\n{body}"
    if meta.get("error") and not ok:
        full += f"\n\nerror: {meta['error']}"
    full, truncated = _truncate(full)
    return ToolResult(content=full, ok=ok, truncated=truncated)


def run_tool_search(args: dict[str, Any]) -> ToolResult:
    """Resolve a deferred tool name (or keyword) to its full schema.

    The bridge interprets the structured ``selected:`` line in our
    output to expand the worker's ``tools[]`` payload on the next
    round. The model sees the same schemas as if they had been
    pre-loaded.

    Query forms (mirrors Claude Code's ToolSearch):
      - ``select:read_file,grep`` — fetch these exact tools by name.
      - ``<keyword>`` — keyword search over name + description.

    Output is a markdown blob with three sections:
    1. ``selected: tool1, tool2, ...`` — machine-readable list the
       bridge parses to expand ``tools[]``.
    2. One JSON-schema block per tool inside a fenced ``functions``
       block — same shape as ``BUILTIN_TOOLS`` schemas, so the
       model sees them in the format it expects.
    3. A short reminder that the tools become callable on the next
       round.
    """
    from rtxclaw_core.tools.registry import BUILTIN_TOOLS
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    try:
        max_results = int(args.get("max_results") or 5)
    except (TypeError, ValueError):
        max_results = 5
    max_results = max(1, min(max_results, 20))

    # ``select:`` direct lookup wins over keyword search.
    selected: list = []
    if query.lower().startswith("select:"):
        wanted = {
            s.strip()
            for s in query[len("select:"):].split(",")
            if s.strip()
        }
        selected = [t for t in BUILTIN_TOOLS if t.name in wanted]
    else:
        ql = query.lower()
        scored: list[tuple[int, "Tool"]] = []
        for t in BUILTIN_TOOLS:
            score = 0
            if ql in t.name.lower():
                score += 10
            for word in ql.split():
                if not word:
                    continue
                if word in t.name.lower():
                    score += 5
                if word in (t.description or "").lower():
                    score += 1
            if score > 0:
                scored.append((score, t))
        scored.sort(key=lambda r: -r[0])
        selected = [t for _, t in scored[:max_results]]

    if not selected:
        return ToolResult(
            content=(
                f"tool_search: no tools matched {query!r}. "
                "List of available tools is in the system prompt's "
                "DEFERRED TOOLS section."
            ),
            ok=True,
        )

    bits: list[str] = [
        "selected: " + ", ".join(t.name for t in selected),
        "",
        "<functions>",
    ]
    for t in selected:
        schema = t.openai_schema()
        bits.append(json.dumps(schema, ensure_ascii=False))
    bits.append("</functions>")
    bits.append("")
    bits.append(
        f"{len(selected)} tool(s) loaded. They become callable on "
        "your next turn — the runtime expands tools[] for you."
    )
    return ToolResult(content="\n".join(bits), ok=True)


_SYNC_RUNNERS: dict[str, Callable[[dict[str, Any]], ToolResult]] = {
    "ToolSearch": run_tool_search,
    "Read": run_read_file,
    "list_dir": run_list_dir,
    "Glob": run_glob,
    "Grep": run_grep,
    "Write": run_write_file,
    "Edit": run_edit_file,
    "Update": run_update_file,
    "Skill": run_skill_get,
    "SkillSearch": run_skill_search,
    "memory_search": run_memory_search,
    "memory_get": run_memory_get,
    "session_search": run_session_search,
    "fact_store": run_fact_store,
    "fact_feedback": run_fact_feedback,
    "TodoWrite": run_todo,
    "TaskCreate": run_task_create,
    "TaskUpdate": run_task_update,
    "TaskList": run_task_list,
    "TaskGet": run_task_get,
    "OutputSection": run_output_section,
    "UserQuestion": run_user_question,
    "ExitPlanMode": run_exit_plan_mode,
    "pin_fact": run_pin_fact,
    "monitor_list": run_monitor_list,
}

# Lazy import — the shim package imports from this module, so we
# cannot import at module load time without a cycle.
def _shim_claude(args, *, on_delta=None, on_event=None):
    from rtxclaw_core.agents.delegate_shims import shim_run_delegate_claude_async
    return shim_run_delegate_claude_async(args, on_delta=on_delta, on_event=on_event)


def _shim_codex(args, *, on_delta=None, on_event=None):
    from rtxclaw_core.agents.delegate_shims import shim_run_delegate_codex_async
    return shim_run_delegate_codex_async(
        args, on_delta=on_delta, on_event=on_event,
    )


def _shim_antigravity(args, *, on_delta=None, on_event=None):
    from rtxclaw_core.agents.delegate_shims import shim_run_delegate_antigravity_async
    return shim_run_delegate_antigravity_async(
        args, on_delta=on_delta, on_event=on_event,
    )


def _shim_agent(args, *, on_delta=None, on_event=None):
    from rtxclaw_core.agents.delegate_shims import shim_run_delegate_agent_async
    return shim_run_delegate_agent_async(args, on_delta=on_delta, on_event=on_event)


def _shim_agent_canonical(args, *, on_delta=None, on_event=None):
    """Dispatcher for the canonical Claude-Code-style ``Agent`` tool.

    The model sees ONE tool (``Agent``) with a ``subagent_type``
    field; the runner routes to the appropriate internal shim:

      - ``general-purpose`` → ``shim_run_delegate_agent_async`` on
        the sibling rtxclaw agent named by ``name`` (defaults to
        ``main``).
      - ``claude``           → ``shim_run_delegate_claude_async``.
      - ``codex``            → ``shim_run_delegate_codex_async``.
      - ``antigravity``           → ``shim_run_delegate_antigravity_async``.

    Param normalisation:
      - the canonical ``prompt`` is forwarded as-is to claude / codex
        / antigravity shims; the agent shim wants ``task`` so we mirror
        ``prompt`` → ``task`` if absent.
      - ``description`` lives in the args dict (consumed by the TUI
        subagent-box for the header label) but is not part of the
        underlying shim's contract; safely ignored.
    """
    if not isinstance(args, dict):
        args = {}
    args = dict(args)
    subagent_type = str(args.get("subagent_type") or "").strip().lower()
    if not subagent_type:
        from rtxclaw_core.tools.runners import ToolResult
        async def _err_async():
            return ToolResult(
                content=(
                    "[Agent: missing `subagent_type` — must be one of "
                    "general-purpose / claude / codex / antigravity]"
                ),
                ok=False,
            )
        return _err_async()
    # Mirror canonical ``prompt`` → ``task`` for the agent-sibling
    # shim (the canonical Claude-Code Agent uses ``prompt``; rtxclaw's
    # delegate_agent shim historically uses ``task``).
    if "prompt" in args and "task" not in args:
        args["task"] = args["prompt"]
    if subagent_type in ("claude", "delegate_claude"):
        from rtxclaw_core.agents.delegate_shims import shim_run_delegate_claude_async
        return shim_run_delegate_claude_async(args, on_delta=on_delta, on_event=on_event)
    if subagent_type in ("codex", "delegate_codex"):
        from rtxclaw_core.agents.delegate_shims import shim_run_delegate_codex_async
        return shim_run_delegate_codex_async(args, on_delta=on_delta)
    if subagent_type in ("antigravity", "delegate_antigravity"):
        from rtxclaw_core.agents.delegate_shims import shim_run_delegate_antigravity_async
        return shim_run_delegate_antigravity_async(args, on_delta=on_delta)
    # "general-purpose" + any sibling-agent name routes through the
    # delegate_agent shim. ``name`` field selects the target; default
    # ``main`` matches Claude Code's "general-purpose subagent".
    if "name" not in args:
        # Treat the subagent_type itself as the target agent name when
        # it doesn't match one of the CLI-bridge keywords above — lets
        # the model spell out e.g. ``subagent_type="scraper"`` and have
        # it route to the scraper sibling.
        if subagent_type not in ("general-purpose", "general", "gp"):
            args["name"] = subagent_type
        else:
            args["name"] = "main"
    from rtxclaw_core.agents.delegate_shims import shim_run_delegate_agent_async
    return shim_run_delegate_agent_async(args, on_delta=on_delta, on_event=on_event)


# --- per-subagent subprocess fan-out -------------------------------------
#
# ``_spawn_subagent_runner`` runs ONE child ``python -m
# rtxclaw_core.tool_runner`` process per subagent entry and multiplexes
# its JSONL stdout (deltas + tool_events + final record) back to the
# caller via the supplied ``on_delta`` / ``on_event`` callbacks. This
# is the primitive ``_shim_batch_agent`` uses to get true OS-level
# parallelism across subagent entries — versus the prior in-process
# ``asyncio.gather`` over ``_shim_agent_canonical``, which:
#   - crash-coupled every entry (one subagent OOM took the batch)
#   - gave no CPU parallelism for prompt-render / large-JSON-parse
#   - couldn't be SIGTERM'd from the TUI (no PID to signal)
# Wire shape is byte-identical to ``_default_run_tool`` (acp_bridge.py
# L968), so a child subagent run looks the same as any other tool
# dispatch on the wire — feed ``{"tool": "Agent", "args": entry}`` on
# stdin, read JSONL events on stdout, terminate on a ``"type": "final"``
# record. Cancel path: parent CancelledError → SIGTERM → 3 s grace →
# SIGKILL, so the ``ps`` table reflects the kill within seconds and the
# TUI's ``/restart`` actually stops subagent work in flight.
#
# ``RTXCLAW_SUBAGENT_INPROCESS=1`` short-circuits this helper in
# ``_shim_batch_agent`` back to the in-process gather so a regression
# escape exists.


async def _spawn_subagent_runner(
    entry: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], Any]] = None,
    on_event: Optional[Callable[[dict], Any]] = None,
) -> "ToolResult":
    """Run ONE ``Agent``-equivalent tool call in a dedicated OS process.

    See the module-level commentary above for design rationale and
    wire shape. Returns a :class:`ToolResult` whose ``content`` is the
    subagent turn's final body (or a diagnostic when the runner
    crashed before emitting a final record). Crash-isolated.
    """
    request = {"tool": "Agent", "args": dict(entry)}
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    # Hint to the child's ``_drive_child_agent_turn`` that this boot
    # should skip MCP discovery / skill-index rebuild / memory provider
    # init — the parent has already paid those costs once for the
    # gateway process and the subagent only needs to dispatch a single
    # Agent.run_turn.
    env["RTXCLAW_SUBAGENT_MINIMAL"] = "1"
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "rtxclaw_core.tool_runner",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
        limit=16 * 1024 * 1024,
    )
    if proc.stdin is None:
        return ToolResult(
            content="[subagent runner: stdin pipe is None]", ok=False,
        )
    proc.stdin.write(json.dumps(request).encode("utf-8"))
    await proc.stdin.drain()
    proc.stdin.close()

    final: Optional[dict] = None
    try:
        if proc.stdout is None:
            return ToolResult(
                content="[subagent runner: stdout pipe is None]", ok=False,
            )
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            try:
                obj = json.loads(line.decode("utf-8", "replace"))
            except json.JSONDecodeError:
                continue
            t = obj.get("type")
            if t == "delta":
                if on_delta is not None:
                    txt = obj.get("text") or ""
                    if txt:
                        try:
                            r = on_delta(txt)
                            if hasattr(r, "__await__"):
                                await r
                        except Exception:  # noqa: BLE001
                            pass
                continue
            if t == "tool_event":
                if on_event is not None:
                    try:
                        r = on_event(
                            {k: v for k, v in obj.items() if k != "type"},
                        )
                        if hasattr(r, "__await__"):
                            await r
                    except Exception:  # noqa: BLE001
                        pass
                continue
            if final is None:
                final = obj
    except asyncio.CancelledError:
        # SIGTERM → 3 s grace → SIGKILL. Propagates the parent's
        # cancel into the OS process so ESC / /restart / /new actually
        # stop subagent work in flight (the in-process gather path
        # couldn't honour this — coroutines kept running until the
        # bound model turn finished).
        try:
            proc.terminate()
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=3.0)
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            try:
                await proc.wait()
            except Exception:  # noqa: BLE001
                pass
        raise

    try:
        await proc.wait()
    except Exception:  # noqa: BLE001
        pass

    if final is None:
        head = ""
        if proc.stderr is not None:
            try:
                err = await proc.stderr.read()
                lines = err.decode("utf-8", "replace").strip().splitlines()
                head = (lines or [""])[-1][:200]
            except Exception:  # noqa: BLE001
                pass
        return ToolResult(
            content=(
                f"[subagent runner crashed "
                f"(rc={proc.returncode}): {head or '<no stderr>'}]"
            ),
            ok=False,
        )
    return ToolResult(
        content=str(final.get("content") or ""),
        ok=bool(final.get("ok", False)),
        truncated=bool(final.get("truncated", False)),
    )


async def _shim_batch_agent(args, *, on_delta=None, on_event=None):
    """BatchAgent runner — fan out N ``Agent``-equivalent calls concurrently.

    The model emits ONE BatchAgent tool_call with ``runs=[{…}, {…}, …]``
    and the runner dispatches every entry through ``_shim_agent_canonical``
    in parallel via ``asyncio.gather``. This sidesteps the small-model
    failure mode where qwen3.6-27b-fp8 (and similar) can't reliably
    emit N tool_calls in one assistant message even when the registry
    description begs them to.

    Per-entry behaviour is byte-identical to a standalone ``Agent``
    call — same session persistence, same ``tool_use`` event streaming,
    same TUI subagent box. We just multiplex through one parent
    ToolResult whose body concatenates each run's output with a
    ``=== run <i> [<subagent_type>:<name>] ===`` header so the model
    can parse them apart.

    Streaming: ``on_delta`` deltas from each entry are prefixed with
    ``[run <i>] `` so the parent transcript stays interleaved-but-
    attributable. ``on_event`` events get ``batch_idx`` injected so
    the TUI subagent panel can distinguish them.
    """
    from rtxclaw_core.tools.runners import ToolResult

    if not isinstance(args, dict):
        args = {}
    runs = args.get("runs")
    if not isinstance(runs, list) or not runs:
        return ToolResult(
            content=(
                "[BatchAgent: missing or empty `runs` list — pass "
                "`runs: [{subagent_type, description, prompt}, …]` "
                "with at least one entry]"
            ),
            ok=False,
        )
    # Validate every entry up-front so we don't half-spawn before
    # surfacing a schema error. Mirror _shim_agent_canonical's required
    # field — ``subagent_type`` — and reject anything else as a clean
    # error rather than dispatching garbage.
    for i, entry in enumerate(runs):
        if not isinstance(entry, dict):
            return ToolResult(
                content=(
                    f"[BatchAgent: runs[{i}] must be an object, got "
                    f"{type(entry).__name__}]"
                ),
                ok=False,
            )
        if not str(entry.get("subagent_type") or "").strip():
            return ToolResult(
                content=(
                    f"[BatchAgent: runs[{i}] missing `subagent_type` "
                    "— must be one of general-purpose / claude / "
                    "codex / antigravity]"
                ),
                ok=False,
            )

    # Per-entry callbacks that prefix the delta / tag the event so the
    # interleaved output stays attributable to its source run.
    def _make_on_delta(idx):
        if on_delta is None:
            return None
        async def _wrapped(text):
            try:
                res = on_delta(f"[run {idx}] {text}")
                if hasattr(res, "__await__"):
                    await res
            except Exception:  # noqa: BLE001
                pass
        return _wrapped

    def _make_on_event(idx):
        if on_event is None:
            return None
        async def _wrapped(ev):
            try:
                tagged = dict(ev or {})
                tagged["batch_idx"] = idx
                res = on_event(tagged)
                if hasattr(res, "__await__"):
                    await res
            except Exception:  # noqa: BLE001
                pass
        return _wrapped

    # Schedule all entries concurrently — ONE OS PROCESS PER ENTRY,
    # not an in-process coroutine. ``_spawn_subagent_runner`` re-enters
    # ``python -m rtxclaw_core.tool_runner`` per entry and multiplexes
    # its JSONL stdout back to the caller via the per-entry
    # ``_make_on_delta`` / ``_make_on_event`` callbacks. Wire shape is
    # byte-identical to the gateway-side ``_default_run_tool`` spawn,
    # so the child subagent run looks the same as any other tool
    # dispatch on the wire (the child runner itself ends up calling
    # ``_shim_agent_canonical`` once inside its own process).
    #
    # Trade-offs vs the prior in-process gather:
    #   + true CPU parallelism for any subagent CPU-bound work
    #     (prompt-template render, large JSON parse on tool results)
    #   + crash-isolation: one subagent OOM / segfault / wedge returns
    #     a failed ToolResult for its slot instead of killing the batch
    #   + SIGTERM-able: ESC / /restart / /new propagates into every
    #     subagent OS process via ``_spawn_subagent_runner``'s cancel
    #     path (SIGTERM → 3 s grace → SIGKILL)
    #   − adds ~150 ms boot overhead per entry (one fork+exec each)
    #     plus the ``RTXCLAW_SUBAGENT_MINIMAL=1`` lean-boot fast path
    #     inside ``_drive_child_agent_turn`` — cheap vs a subagent turn
    # ``RTXCLAW_SUBAGENT_INPROCESS=1`` short-circuits back to the
    # in-process gather so a regression escape exists (e.g. when the
    # subprocess pattern misbehaves under heavy fan-out, an operator
    # can fall back to today's behaviour without redeploying).
    inprocess = os.environ.get("RTXCLAW_SUBAGENT_INPROCESS") == "1"
    # A session per subagent: the batch is ONE tool call with ONE call
    # id, but each entry is an independent subagent that must get its
    # OWN child session. Derive a unique per-entry call id from the
    # batch's so ``_drive_child_agent_turn`` keys a fresh session per
    # entry (without this, every entry of the same engine collided on —
    # and concurrently raced — one shared session). The parent sid is
    # propagated so each child back-links to the dispatching session.
    batch_cid = str(args.get("_rtxclaw_call_id") or "batch")
    batch_parent = str(args.get("_rtxclaw_parent_session_id") or "")

    def _entry_args(i: int, entry: dict) -> dict:
        e = dict(entry)
        e["_rtxclaw_call_id"] = f"{batch_cid}.{i}"
        if batch_parent and "_rtxclaw_parent_session_id" not in e:
            e["_rtxclaw_parent_session_id"] = batch_parent
        return e

    coros = []
    for i, entry in enumerate(runs):
        if inprocess:
            coros.append(
                _shim_agent_canonical(
                    _entry_args(i, entry),
                    on_delta=_make_on_delta(i),
                    on_event=_make_on_event(i),
                )
            )
        else:
            coros.append(
                _spawn_subagent_runner(
                    _entry_args(i, entry),
                    on_delta=_make_on_delta(i),
                    on_event=_make_on_event(i),
                )
            )
    results = await asyncio.gather(*coros, return_exceptions=True)

    # Assemble one combined ToolResult body in CALL ORDER (asyncio.gather
    # preserves order regardless of completion timing).
    chunks: list[str] = []
    overall_ok = True
    for i, (entry, res) in enumerate(zip(runs, results)):
        st = str(entry.get("subagent_type") or "?")
        nm = str(entry.get("name") or "")
        header = f"=== run {i} [{st}{':' + nm if nm else ''}] ==="
        if isinstance(res, BaseException):
            overall_ok = False
            chunks.append(f"{header}\n[BatchAgent: run {i} crashed: {res!r}]")
            continue
        body = getattr(res, "content", "") or ""
        if not getattr(res, "ok", True):
            overall_ok = False
        chunks.append(f"{header}\n{body}")
    return ToolResult(
        content="\n\n".join(chunks),
        ok=overall_ok,
    )


_ASYNC_RUNNERS: dict[str, Callable[[dict[str, Any]], "asyncio.Future[ToolResult]"]] = {
    "Bash": run_exec_async,
    "Monitor": run_monitor_start_async,
    "BashOutput": run_monitor_read_async,
    "KillShell": run_monitor_stop_async,
    "WebFetch": run_web_fetch_async,
    "WebSearch": run_web_search_async,
    # Delegate-class tools route through the Agent + Engine shims so
    # the autonomous-tool path (model emits ``delegate_claude`` as a
    # tool call) and the slash-command direct-dispatch path
    # (gateway_shim._dispatch_direct_delegate) converge on the same
    # backend. Without this both paths existed in parallel and a
    # divergence between them was a latent bug.
    "delegate_claude": _shim_claude,
    "delegate_codex": _shim_codex,
    "delegate_antigravity": _shim_antigravity,
    "delegate_agent": _shim_agent,
    # Canonical Claude-Code-style subagent dispatch. The model sees
    # ONLY ``Agent`` in BUILTIN_TOOLS (delegate_* names are filtered
    # out of the model-facing tool list); this entry routes
    # ``Agent(subagent_type=…)`` calls to the appropriate shim above.
    # The four ``delegate_*`` keys above are kept so the SLASH-COMMAND
    # path (``/claude`` / ``/codex`` / ``/antigravity``), which bypasses
    # the model and the registry filter, can still dispatch via name.
    "Agent": _shim_agent_canonical,
    "BatchAgent": _shim_batch_agent,
    "remember": run_remember_async,
    "mcp_list_tools": run_mcp_list_tools_async,
    "mcp_call": run_mcp_call_async,
    "acp_call": run_acp_call_async,
}


async def dispatch(
    tool_name: str,
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> ToolResult:
    """Run `tool_name(args)`, returning a `ToolResult`.

    Sync runners go through `asyncio.to_thread` so file I/O doesn't
    block the event loop. Unknown tool names return an error result
    that the model will see in its `tool` message.

    `on_delta` is the streaming hook: tools that produce output
    incrementally (today: `delegate_claude` as Claude's text streams
    in) call it to push partial text back to the parent runner. The
    runner forwards it as a `{"type": "delta", "text": "..."}` JSON
    line on stdout, which `_read_tool_result` reads and the SSE layer
    turns into a `delta` event for the TUI / bash bridge. Tools that
    don't stream simply ignore the callback.

    `on_event` is the structured side-channel for tools that emit
    discrete events alongside their text stream — today,
    `delegate_claude` uses it to surface Claude's own inner
    `tool_use` / `tool_result` blocks as `{"kind": "tool_use", ...}`
    / `{"kind": "tool_result", ...}` records so the frontend can
    mount native tool-call widgets (the TUI's ToolCallMessage /
    ToolResultMessage, the plan checklist for TodoWrite). Tools that
    don't emit events ignore it.
    """
    args = dict(args or {})
    # Drop the model's self-classification before dispatch — the runner
    # doesn't need it (the permission gate already consumed it).
    args.pop("criticality", None)

    # Standard MCP namespacing: ``mcp__<server>__<tool>``. The client
    # injected discovered MCP tools into the model's tool list with
    # this prefix at startup; route invocations back to the
    # corresponding MCP server here.
    from rtxclaw_mcp import mcp_client as _mcp
    parsed = _mcp.parse_mcp_namespaced(tool_name)
    if parsed is not None:
        server_name, original_tool = parsed
        # Surface the MCP call to (a) stderr — works for the HTTP ACP
        # daemon whose stderr goes to gateway.log — AND (b) a file
        # under <home>/mcp_calls.log so the stdio ACP path (whose
        # subprocess stderr is captured by the parent and not
        # forwarded) is also observable.
        import sys as _sys
        import time as _time
        line = (
            f"[mcp_call] {_time.strftime('%Y-%m-%d %H:%M:%S')} "
            f"{tool_name} server={server_name} tool={original_tool}"
        )
        print(line, file=_sys.stderr, flush=True)
        try:
            from rtxclaw_core.agent import rtxclaw_root
            (rtxclaw_root() / "mcp_calls.log").open("a").write(line + "\n")
        except Exception:  # noqa: BLE001
            pass
        servers = _mcp.load_mcp_servers()
        server = servers.get(server_name)
        if server is None:
            return _err(
                f"MCP server {server_name!r} no longer configured "
                f"(tool was {tool_name!r}). Reload the agent after "
                "editing mcpServers in the global config."
            )
        ok, body = await _mcp.call_tool(server, original_tool, args)
        result_line = (
            f"[mcp_call] {_time.strftime('%Y-%m-%d %H:%M:%S')} "
            f"{tool_name} → ok={ok} bytes={len(body or '')}"
        )
        print(result_line, file=_sys.stderr, flush=True)
        try:
            (rtxclaw_root() / "mcp_calls.log").open("a").write(result_line + "\n")
        except Exception:  # noqa: BLE001
            pass
        body, truncated = _truncate(body or "(empty result)")
        return ToolResult(content=body, ok=ok, truncated=truncated)

    if tool_name in _ASYNC_RUNNERS:
        runner = _ASYNC_RUNNERS[tool_name]
        # Streaming-capable runners declare an `on_delta` keyword; some
        # also accept `on_event` for structured tool events. We pass
        # each kwarg only when the signature accepts it so existing
        # runners stay unchanged.
        import inspect
        sig = inspect.signature(runner)
        kwargs: dict[str, Any] = {}
        if "on_delta" in sig.parameters:
            kwargs["on_delta"] = on_delta
        if "on_event" in sig.parameters:
            kwargs["on_event"] = on_event
        return await runner(args, **kwargs)
    if tool_name in _SYNC_RUNNERS:
        return await asyncio.to_thread(_SYNC_RUNNERS[tool_name], args)
    return _err(f"unknown tool: {tool_name}")
