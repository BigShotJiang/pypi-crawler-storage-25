"""Heuristic shell-command classifier — defense-in-depth sanity check.

The PRIMARY criticality source is the model itself: we ask the model to
mark every tool call's `criticality` field via a system-prompt fragment
(see `tools.prompt`). This module is the SECONDARY source — a regex /
keyword classifier that catches obviously destructive commands the model
might have under-classified (e.g. it called `rm -rf /tmp/foo` and
labeled it `mutating` instead of `destructive`).

The evaluator takes the more cautious of {model_claim, heuristic}, so:

- If both agree, decision is unambiguous.
- If they disagree, the more cautious side wins (we never under-protect).
- If the model omits the claim entirely, the heuristic is the only signal.

This file ships with a hand-curated, conservative ruleset. It is **not**
a sandbox — it doesn't prevent malicious commands from running, it just
makes the permission gate aware of what's about to run. A user in `auto`
mode running `rm -rf /` will still get a confirmation prompt because
the heuristic flags `rm -rf` even if the model wrongly claimed otherwise.
"""
from __future__ import annotations

import re
import shlex
from enum import Enum


class CommandSafety(Enum):
    """Heuristic classification of a shell command.

    Values are ordered from least to most cautious so callers can take
    `max(a, b, key=CommandSafety.severity)` to merge two classifications.

    ``FORBIDDEN`` is a hard "never even ask" class for commands whose
    blast radius makes any approval flow a bug — ``rm -rf ~/``,
    ``rm -rf /``, fork bombs, raw-disk overwrites of a system device.
    The permission evaluator short-circuits these to ``deny`` in EVERY
    mode (including ``auto`` + session allowlist) so a model never has
    a path to convince a half-attentive operator into running them.
    """

    READ_ONLY = "read_only"      # ls, cat, git status, grep — won't change anything
    UNKNOWN = "unknown"          # not on either allow- or deny-list
    MUTATING = "mutating"        # mkdir, touch, mv, sed -i — reversible-ish writes
    DESTRUCTIVE = "destructive"  # rm -rf <subdir>, dd, drop table, force-push to main
    FORBIDDEN = "forbidden"      # rm -rf ~/, rm -rf /, fork bomb — never even ask

    @property
    def severity(self) -> int:
        return _SEVERITY[self]


_SEVERITY: dict[CommandSafety, int] = {
    CommandSafety.READ_ONLY: 0,
    CommandSafety.UNKNOWN: 1,
    CommandSafety.MUTATING: 2,
    CommandSafety.DESTRUCTIVE: 3,
    CommandSafety.FORBIDDEN: 4,
}


# Commands whose mere invocation can't change state (no flags that mutate).
# Conservative: a single argv[0] match, no flag inspection beyond what's
# checked below for `git`. Add to this list with care — a "read-only" tag
# is a permission for plan-mode users to run the command unprompted.
_READ_ONLY_COMMANDS: frozenset[str] = frozenset({
    # Inspection
    "ls", "cat", "head", "tail", "less", "more", "wc", "file", "stat",
    "tree", "tac", "nl", "fold", "fmt", "column", "diff", "cmp",
    # Search
    "grep", "egrep", "fgrep", "rg", "ack", "ag", "find", "locate", "which",
    # Process / system inspect
    "ps", "top", "htop", "free", "df", "du", "uptime", "who", "w", "id",
    "whoami", "hostname", "uname", "groups", "tty", "lsof", "lsblk", "lscpu",
    "lspci", "lsusb", "dmesg",
    # Network inspect (no mutations)
    "ping", "traceroute", "dig", "nslookup", "host", "ip",
    "ifconfig", "netstat", "ss", "arp", "route",
    # Date / env
    "date", "cal", "env", "printenv", "locale",
    # Help / docs
    "man", "info", "help", "type", "command", "alias", "history",
    # Compression inspect-only — `tar` / `unzip` are NOT here because
    # the classifier doesn't inspect their flags: `tar -xf foo.tar`
    # extracts and `unzip foo.zip` unpacks, both of which are mutating.
    # The classifier returns UNKNOWN (→ MUTATING) for them so the
    # permission evaluator prompts the user.
    "zcat", "bzcat", "xzcat", "zless", "bzless",
    # Python read-only invocations
    "pwd",
    # Shell builtins / no-ops that never touch the filesystem. ``cd``
    # changes only the shell's own working dir; ``echo`` / ``printf``
    # write to stdout (a real file target is caught by the redirect
    # floor, not here); ``test`` / ``[`` evaluate; ``true`` / ``false``
    # / ``:`` are no-ops. These show up constantly in read-only research
    # chains (``cd repo && git log``, ``test -f x && echo found``) and
    # their absence was denying plan-mode research.
    "cd", "echo", "printf", "test", "[", "true", "false", ":",
    "sleep",
    # Text-stream filters — read stdin / files and print to stdout.
    # (``sort -o FILE`` / ``split`` can write; ``sort -o`` is guarded
    # explicitly in ``_classify_segment``; ``split`` / ``csplit`` /
    # ``tee`` are intentionally NOT here.)
    "sort", "uniq", "cut", "tr", "rev", "comm", "paste", "join",
    # Path-string helpers — pure string math, no filesystem writes.
    "basename", "dirname", "realpath", "readlink", "seq", "expr",
})

# Commands that DON'T change state when called without arguments / with
# specific subcommands. Limited to the ones we can be sure about.
#
# Excluded on purpose: `branch`, `tag`, `remote`, `stash`, `config`. Each
# has destructive variants that cannot be told apart from a read-only
# invocation by argv[1] alone:
#   - `git branch -d/-D <name>` deletes branches.
#   - `git tag -d <name>` deletes tags; `git tag <new>` creates them.
#   - `git remote add/remove/set-url …` mutates remotes.
#   - `git stash drop / pop / clear` discards stash entries.
#   - `git config --global user.email …` rewrites global git identity.
# The classifier returns UNKNOWN (→ MUTATING) for these so the permission
# evaluator prompts the user before executing — better than silently
# allowing them in PLAN mode.
_GIT_READ_ONLY_SUBCOMMANDS: frozenset[str] = frozenset({
    "status", "diff", "log", "show", "blame",
    "rev-parse", "ls-files", "ls-tree", "ls-remote",
    "describe", "shortlog", "reflog", "fsck", "count-objects",
    "cherry", "name-rev", "for-each-ref", "cat-file", "check-ignore",
})

# Hard-deny patterns — commands whose blast radius makes any approval
# flow a bug. The evaluator maps these to ``deny`` in every mode; the
# permission modal NEVER fires for these. Keep narrow on purpose: a
# false positive here breaks a real workflow, a false negative is a
# safety incident. Match only constructs whose wipe target is clearly
# the operator's home / root / a system disk / a fork-bomb shape.
#
# Patterns intentionally accept the most common shell quotings of
# ``~``, ``$HOME`` and ``${HOME}`` (and their trailing-slash variants)
# while requiring the recursive-force flag combo (``-rf`` / ``-fr`` /
# ``-rfd`` etc.) so an interactive ``rm ~/file`` still gets the normal
# destructive prompt.
_FORBIDDEN_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        # rm -rf on home dir: `~`, `~/`, `~/*`, `"$HOME"`, `${HOME}/`,
        # quoted or not. The constraint at the end (``end-of-string``
        # or shell separator) keeps `rm -rf ~/projects/x` out — those
        # are explicit subdirs and go through the normal destructive
        # path.
        r"\b(?:sudo\s+)?rm\s+-[a-zA-Z]*[rR][a-zA-Z]*[fF][a-zA-Z]*\s+"
        r"(?:--\s+)?['\"]?(?:~|\$\{?HOME\}?)/?['\"]?\s*\*?\s*['\"]?\s*(?:$|[;&|])",
        r"\b(?:sudo\s+)?rm\s+-[a-zA-Z]*[fF][a-zA-Z]*[rR][a-zA-Z]*\s+"
        r"(?:--\s+)?['\"]?(?:~|\$\{?HOME\}?)/?['\"]?\s*\*?\s*['\"]?\s*(?:$|[;&|])",
        # rm -rf / (root) or /* — match `/` standing alone as the
        # target, NOT `/tmp/x` (which is a subdir of /).
        r"\b(?:sudo\s+)?rm\s+-[a-zA-Z]*[rR][a-zA-Z]*[fF][a-zA-Z]*\s+"
        r"(?:--\s+)?['\"]?/['\"]?\s*\*?\s*['\"]?\s*(?:$|[;&|])",
        r"\b(?:sudo\s+)?rm\s+-[a-zA-Z]*[fF][a-zA-Z]*[rR][a-zA-Z]*\s+"
        r"(?:--\s+)?['\"]?/['\"]?\s*\*?\s*['\"]?\s*(?:$|[;&|])",
        # Classic fork bomb — both the canonical form and the
        # whitespace-tolerant variant the model might emit.
        r":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:",
        # Whole-disk raw write to a system device. `/dev/sda`,
        # `/dev/nvme0n1`, `/dev/vda` — no partition suffix means the
        # whole disk including the partition table.
        r"\bdd\b[^|;&]*\bof=/dev/(?:sd[a-z]|nvme\d+n\d+|vd[a-z]|hd[a-z])\b(?!\d)",
        # mkfs on a whole-disk system device — wipes everything on it.
        r"\bmkfs(?:\.\w+)?\s+(?:-\S+\s+)*/dev/(?:sd[a-z]|nvme\d+n\d+|vd[a-z]|hd[a-z])\b(?!\d)",
    )
)


# Things that are nearly always destructive / irreversible.
_DESTRUCTIVE_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"\brm\s+(-[a-zA-Z]*[rRfF][a-zA-Z]*\s+)",       # rm -r / -rf / -fr / -Rf etc.
        r"\bsudo\s+rm\b",                                 # any sudo rm
        r"\bdd\s+.*\bof=/dev/",                           # dd of=/dev/sdX
        r"\bmkfs\.",                                      # mkfs.ext4 etc.
        r"\bmkfs\b",
        r"\bshred\b",
        r"\bwipefs\b",
        r"\bfind\b.*\s-delete\b",                         # find ... -delete
        r"\bxargs\s+rm\b",
        r":\(\)\s*\{\s*:\|:\s*&\s*\}\s*;",               # fork-bomb signature
        r">\s*/dev/sd[a-z]",                              # raw-device write
        # Any force-push is destructive — many teams promote to
        # `develop` / `production` / `release/*` and the previous
        # main|master-only filter let those slip through.
        r"\bgit\s+push\b[^|;&]*\s-{1,2}f\b",
        r"\bgit\s+push\b[^|;&]*\s-{1,2}force\b",
        r"\bgit\s+push\b[^|;&]*\s-{1,2}force-with-lease\b",
        r"\bgit\s+reset\s+--hard\b",
        r"\bgit\s+clean\s+-[a-zA-Z]*[fF][a-zA-Z]*[dD]?\b",
        # Branch deletion — BOTH `-d` (safe/merged-only) and `-D`
        # (force) are treated as destructive on purpose: deleting a
        # branch is rarely something an agent should do unprompted.
        # The class is matched explicitly via `-[dD]` rather than
        # leaning on the tuple-wide re.IGNORECASE flag so the intent
        # is in the pattern, not an accident of compilation.
        r"\bgit\s+branch\s+-[dD]\b",
        r"\bDROP\s+(TABLE|DATABASE|SCHEMA)\b",
        r"\bTRUNCATE\s+(TABLE|DATABASE)\b",
        r"\bDELETE\s+FROM\b\s+\w+\s*;?\s*$",              # DELETE FROM x; with no WHERE
    )
)

# Things that change state but are generally reversible.
_MUTATING_COMMANDS: frozenset[str] = frozenset({
    "mkdir", "rmdir", "touch", "ln", "chmod", "chown", "chgrp",
    "mv", "cp", "rsync", "install",
    "tee", "sed", "awk",
    "apt", "apt-get", "dnf", "yum", "brew", "pacman", "pip", "pip3",
    "npm", "yarn", "pnpm", "cargo", "go",
    "systemctl", "service", "launchctl", "kill", "killall", "pkill",
    "make", "cmake",
})


class SafetyClassifier:
    """Stateless wrapper around `classify_command` for monkeypatching in tests."""

    def classify(self, command: str) -> CommandSafety:
        return classify_command(command)


def _max_safety(a: CommandSafety, b: CommandSafety) -> CommandSafety:
    """Return the more cautious of two classifications (higher severity)."""
    return a if a.severity >= b.severity else b


def _split_command(text: str) -> tuple[list[str], bool, bool]:
    """Split ``text`` on shell control operators OUTSIDE quotes.

    The historic classifier bailed to ``UNKNOWN`` the instant it saw a
    ``| ; && || > < `` `` $(`` anywhere in the string — including inside
    a quoted regex (``grep -E "a|b"``) — which denied legitimate
    read-only commands in plan mode. This walks the string quote-aware
    so only REAL operators split, and so a read-only-only pipeline /
    chain can be recognized as read-only.

    Returns ``(segments, has_file_write, has_cmd_sub)``:

    - ``segments`` — the individual simple-command strings. Redirect
      operators are dropped; their target words remain so argv[0]
      classification still sees the real command.
    - ``has_file_write`` — a ``>`` / ``>>`` / ``&>`` file redirection is
      present. An fd-duplication (``2>&1`` / ``>&2``) does NOT count —
      it writes no file.
    - ``has_cmd_sub`` — a ``$(...)`` or backtick substitution is present;
      its inner command can't be promised read-only, so callers stay
      cautious.
    """
    segments: list[str] = []
    buf: list[str] = []
    has_file_write = False
    has_cmd_sub = False
    quote: "str | None" = None
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if quote:
            # Inside DOUBLE quotes the shell still expands ``$(...)`` and
            # backtick command substitution, so a "read-only-looking"
            # command can execute a mutating one (`cat "$(touch x)"`).
            # Flag it so the caller floors to UNKNOWN. SINGLE quotes are
            # fully literal — nothing expands there.
            if quote == '"':
                if c == "`":
                    has_cmd_sub = True
                elif c == "$" and i + 1 < n and text[i + 1] == "(":
                    has_cmd_sub = True
            buf.append(c)
            if c == quote:
                quote = None
            i += 1
            continue
        if c in ("'", '"'):
            quote = c
            buf.append(c)
            i += 1
            continue
        # command-substitution markers — literal chars, but flag them
        if c == "`":
            has_cmd_sub = True
            buf.append(c)
            i += 1
            continue
        if c == "$" and i + 1 < n and text[i + 1] == "(":
            has_cmd_sub = True
            buf.append(c)
            i += 1
            continue
        # Process substitution `<(cmd)` / `>(cmd)` — the shell RUNS the
        # inner command, so it can't be promised read-only. Flag it
        # BEFORE the redirect branches below treat the `<` / `>` as a
        # plain input/output redirect.
        if c in ("<", ">") and i + 1 < n and text[i + 1] == "(":
            has_cmd_sub = True
            buf.append(c)
            i += 1
            continue
        two = text[i:i + 2]
        # control operators → break the current segment
        if two in ("||", "&&"):
            segments.append("".join(buf)); buf = []; i += 2; continue
        if c == "|":
            segments.append("".join(buf)); buf = []; i += 1; continue
        if c in (";", "\n"):
            segments.append("".join(buf)); buf = []; i += 1; continue
        if c == "&":
            if two == "&>":               # &>file — redirect all streams to a file
                if not _redirect_target_is_benign(text, i + 2):
                    has_file_write = True
                i += 2
                continue
            segments.append("".join(buf)); buf = []; i += 1; continue  # background &
        if c == ">":
            if two == ">&":
                # ``>&N`` / ``>&-`` is fd-duplication (no file). But
                # ``>&FILE`` (non-numeric target) redirects BOTH stdout
                # and stderr to a FILE — a real truncating write — so it
                # must NOT be waved through as read-only.
                j = i + 2
                while j < n and text[j] == " ":
                    j += 1
                if j < n and (text[j].isdigit() or text[j] == "-"):
                    i += 2            # fd-dup, not a file write
                    continue
                if not _redirect_target_is_benign(text, i + 2):
                    has_file_write = True
                i += 2
                continue
            step = 2 if two == ">>" else 1  # >> append / > truncate
            if not _redirect_target_is_benign(text, i + step):
                has_file_write = True
            i += step
            continue
        if c == "<":
            i += 2 if two == "<<" else 1  # heredoc / input redirect — read side
            continue
        if c.isdigit() and i + 1 < n and text[i + 1] == ">":
            # fd-prefixed redirect (`2>file`, `2>&1`): break the token so
            # the digit doesn't glue onto the previous word, then let the
            # next iteration's `>` handling decide file-write vs fd-dup.
            buf.append(" ")
            i += 1
            continue
        buf.append(c)
        i += 1
    if buf:
        segments.append("".join(buf))
    return [s.strip() for s in segments if s.strip()], has_file_write, has_cmd_sub


# Redirect targets that don't create/overwrite a real file — writing
# here is a no-op for safety purposes, so a ``> /dev/null`` (or
# ``2>/dev/null``) must NOT bump a read-only command up to MUTATING.
# This matters in plan mode: research commands routinely silence stderr
# (``ls x 2>/dev/null || echo missing``) and that must stay read-only.
_BENIGN_WRITE_TARGETS = frozenset({"/dev/null", "/dev/stdout", "/dev/stderr"})


def _redirect_target_is_benign(text: str, j: int) -> bool:
    """True when the redirect target starting at/after ``j`` is a discard
    / passthrough device (``/dev/null`` & friends) rather than a real
    file. Quote-stripping keeps ``> "/dev/null"`` benign too."""
    n = len(text)
    while j < n and text[j] in " \t":
        j += 1
    k = j
    while k < n and text[k] not in " \t|&;<>\n":
        k += 1
    return text[j:k].strip("'\"") in _BENIGN_WRITE_TARGETS


def _classify_segment(segment: str) -> CommandSafety:
    """Classify ONE simple command (no control operators).

    Mirrors the historic argv[0] logic: read-only allowlist, git /
    crontab inspect-only forms, mutating list, else ``UNKNOWN``.
    Destructive / forbidden detection is the caller's job (it runs over
    the whole string before splitting), so this never returns those.
    """
    try:
        argv = shlex.split(segment)
    except ValueError:
        return CommandSafety.UNKNOWN
    if not argv:
        return CommandSafety.UNKNOWN
    # Strip a leading path: `/usr/bin/rm` → `rm`.
    base = argv[0].rsplit("/", 1)[-1]

    # `git <subcommand>` with a read-only subcommand.
    if base == "git" and len(argv) >= 2 and argv[1] in _GIT_READ_ONLY_SUBCOMMANDS:
        return CommandSafety.READ_ONLY
    # `crontab -l` lists the table (read-only); `crontab <file>` installs
    # and `crontab -r` removes — those stay UNKNOWN (caller prompts).
    if base == "crontab" and len(argv) >= 2 and argv[1] == "-l":
        return CommandSafety.READ_ONLY
    # `find` is read-only for LISTING, but `-exec` / `-execdir` / `-ok` /
    # `-okdir` run an ARBITRARY command per match (`find . -exec rm {} ';'`)
    # — those are not read-only. This guard keeps the action forms out of
    # the read-only allowlist below. (With a quoted `';'` terminator the
    # whole command parses as one `find` segment that would otherwise be
    # allowlisted; the `\;` backslash form already lands non-read-only
    # another way — it splits on the bare `;` and the trailing-backslash
    # fragment fails `shlex.split` → UNKNOWN — but this guard makes the
    # intent explicit and uniform across both terminator forms.)
    if base == "find" and any(
        a in ("-exec", "-execdir", "-ok", "-okdir") for a in argv[1:]
    ):
        return CommandSafety.UNKNOWN
    # `sort -o FILE` / `sort --output=FILE` writes a file even though
    # `sort` is otherwise a read-only stream filter.
    if base == "sort" and any(
        a == "-o" or a.startswith("--output") for a in argv[1:]
    ):
        return CommandSafety.MUTATING
    if base in _READ_ONLY_COMMANDS:
        return CommandSafety.READ_ONLY
    if base in _MUTATING_COMMANDS:
        return CommandSafety.MUTATING
    return CommandSafety.UNKNOWN


def classify_command(command: str) -> CommandSafety:
    """Heuristic-classify a shell command string.

    A pipeline / chain is classified as the most-cautious of its
    segments, so a read-only-only pipeline (``cat f | grep x``) stays
    read-only and runs in plan mode, while a destructive segment
    anywhere (``ls && rm -rf x``) trips the whole command.

    Examples:
        >>> classify_command("ls -la").name
        'READ_ONLY'
        >>> classify_command('grep -E "a|b" file').name
        'READ_ONLY'
        >>> classify_command("cat foo | grep bar").name
        'READ_ONLY'
        >>> classify_command("grep foo bar > out.txt").name
        'MUTATING'
        >>> classify_command("rm -rf /tmp/foo").name
        'DESTRUCTIVE'
        >>> classify_command("ls && rm -rf /tmp/foo").name
        'DESTRUCTIVE'
        >>> classify_command("rm -rf ~/").name
        'FORBIDDEN'
        >>> classify_command("git status").name
        'READ_ONLY'
        >>> classify_command("git push --force origin main").name
        'DESTRUCTIVE'
        >>> classify_command("mkdir -p build").name
        'MUTATING'
    """
    text = (command or "").strip()
    if not text:
        return CommandSafety.UNKNOWN

    # 0. Forbidden patterns FIRST — the "never even ask" set
    #    (``rm -rf ~/``, fork bomb, whole-disk wipe). Matched over the
    #    WHOLE string so a hard-deny inside a chain still wins; checked
    #    before destructive so a pattern that is both (rm -rf) gets the
    #    strictest tag.
    for pat in _FORBIDDEN_PATTERNS:
        if pat.search(text):
            return CommandSafety.FORBIDDEN

    # 1. Destructive patterns — matched over the whole string so a
    #    destructive segment anywhere in a pipeline / chain trips
    #    (`ls && rm -rf x`, `cat f | xargs rm`, `bash -c 'rm -rf x'`).
    for pat in _DESTRUCTIVE_PATTERNS:
        if pat.search(text):
            return CommandSafety.DESTRUCTIVE

    # 2. Quote-aware split into simple-command segments. Operators inside
    #    quotes (a regex like `grep -E "a|b"`) are literal and do NOT
    #    split — that was the plan-mode over-block bug.
    segments, has_file_write, has_cmd_sub = _split_command(text)
    if not segments:
        return CommandSafety.UNKNOWN

    # 3. Most-cautious merge of every segment + the redirect / cmd-sub
    #    floors. A read-only-only pipeline / chain stays READ_ONLY (and
    #    is allowed in plan mode); a file write floors at MUTATING; a
    #    command substitution can't be promised read-only.
    worst = CommandSafety.READ_ONLY
    for seg in segments:
        worst = _max_safety(worst, _classify_segment(seg))
    if has_file_write:
        worst = _max_safety(worst, CommandSafety.MUTATING)
    if has_cmd_sub:
        worst = _max_safety(worst, CommandSafety.UNKNOWN)
    return worst
