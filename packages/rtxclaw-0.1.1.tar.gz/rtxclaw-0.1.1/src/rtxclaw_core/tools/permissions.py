"""Permission evaluator: combines mode + tool-kind + criticality → decision.

The user picks one of three permission modes per session:

- **plan** — read-only operations only. Anything not classified
  `read_only` is denied before the tool runs.
- **ask** — prompt before mutating / destructive operations. Three responses
  per prompt: `yes` / `yes-and-don't-ask-again-for-this` / `no`. The
  session allowlist remembers `yes-and-don't-ask-again` choices for the
  rest of the session — except for destructive operations, which always
  re-prompt as a safety net.
- **auto** — run without prompting, except destructive operations always
  pause for confirmation. That's the auto-mode safety net.

Criticality has two sources:

1. The model's self-classification, passed in the tool call's
   `args["criticality"]` field. The system prompt (see `tools.prompt`)
   teaches the model how to set this.
2. A heuristic shell-command classifier (see `tools.safety`). Defense
   in depth — if the model under-classifies a destructive command, the
   regex still catches it.

`PermissionEvaluator.evaluate` takes the more cautious of the two so we
never under-protect.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from .registry import Tool, ToolKind
from .safety import CommandSafety, classify_command


# ---- Memory-tree path gate ------------------------------------------
#
# Used by the dispatch loop in `agent_runtime.session_turn` to refuse
# write_file / edit_file / exec on memory paths. Memory mutations must
# go through the `remember` tool so the synthesis
# step + both index reindexes stay in lock-step.

def is_memory_path(rel_path: str) -> bool:
    """True iff `rel_path` is `MEMORY.md` or under `memory/`.

    Inputs are relative-style strings (forward slashes acceptable).
    The caller is responsible for resolving absolute paths against
    the agent home — see `path_under_memory`.
    """
    if not rel_path:
        return False
    rel = rel_path.lstrip("/").replace(os.sep, "/")
    return rel == "MEMORY.md" or rel.startswith("memory/")


def path_under_memory(home: Path, raw_path: str) -> bool:
    """Resolve `raw_path` (handles `~` + relative) and return True iff
    the resolved path lives inside `<home>`'s memory tree.

    Defensive: returns False on any exception (caller can still treat
    the operation as untrusted; this helper is purely for the gate's
    yes-or-no decision)."""
    if not raw_path:
        return False
    try:
        candidate = Path(str(raw_path)).expanduser()
        # Resolve symlinks; falls back to lexical join when the file
        # doesn't yet exist (write_file's case).
        try:
            candidate = candidate.resolve()
        except (OSError, RuntimeError):
            candidate = (Path.cwd() / candidate).resolve(strict=False)
        home_resolved = Path(home).resolve()
        rel = candidate.relative_to(home_resolved)
    except (ValueError, OSError):
        return False
    return is_memory_path(str(rel))


def exec_targets_memory(home: Path, command: str) -> bool:
    """Heuristic: True if a shell command string references a path
    under `<home>`'s memory tree.

    Two passes:

    1. **Token pass** — strip shell quotes and split into argv-like
       tokens (`shlex.split`). For each token, normalise common
       obfuscations (concatenated quoted segments are already merged by
       shlex; trailing slashes; leading `./` and `~/`) and check
       whether the resolved path lives under the agent home's memory
       tree. This catches `cat ./mem"ory"/foo.md` and `cat $HOME/.../memory/foo.md`
       (where `$HOME` was already expanded by the operator before
       handing it to the model).
    2. **Substring fallback** — for command strings that don't parse
       cleanly as shell (`cmd | grep`, command-substitution with
       backticks, etc.) we still want to refuse the obvious literal
       references to `MEMORY.md` / `memory/`.

    Not bulletproof — an obfuscated `> $(echo memory.md)` still slips
    through because `$(...)` is evaluated only at runtime — but the
    token pass closes the everyday cases the previous substring-only
    check missed. The model can still bypass deliberately, which is why
    this is a *deterrent + safety belt* on top of the permission gate;
    the gate's hard enforcement still runs in the dispatch loop.
    """
    if not command:
        return False
    cmd = str(command)
    home_path = Path(home).expanduser().resolve()
    memory_root = home_path / "memory"
    memory_md = home_path / "MEMORY.md"

    # Pass 1: token-level resolved-path check.
    import shlex
    try:
        tokens = shlex.split(cmd, posix=True)
    except ValueError:
        # Unbalanced quotes — fall through to the substring pass.
        tokens = []
    for tok in tokens:
        if not tok:
            continue
        # Strip leading redirection operators ("> /path", "2>>/path").
        stripped = tok.lstrip("<>&|")
        if not stripped:
            continue
        # Skip obvious flags so `--memory=foo` (a flag value of "foo")
        # isn't treated as a path probe.
        if stripped.startswith("-"):
            continue
        try:
            cand = Path(stripped).expanduser()
            if not cand.is_absolute():
                cand = home_path / cand
            cand = cand.resolve(strict=False)
        except (OSError, ValueError, RuntimeError):
            continue
        try:
            cand.relative_to(home_path)
        except ValueError:
            continue
        try:
            cand.relative_to(memory_root)
            return True
        except ValueError:
            pass
        if cand == memory_md:
            return True

    # Pass 2: literal substring fallback for commands shlex can't parse.
    candidates = [
        str(memory_md),
        str(memory_root) + "/",
        " MEMORY.md",
        "/MEMORY.md",
        " memory/",
        "/memory/",
    ]
    return any(c in cmd for c in candidates)


class PermissionMode(Enum):
    """User-selected gating policy."""

    PLAN = "plan"   # read-only only
    ASK = "ask"     # prompt before mutations
    AUTO = "auto"   # autonomous; only destructive ops pause for confirmation


class Criticality(Enum):
    """Per-tool-call effect category. Set by the model and/or heuristic.

    ``FORBIDDEN`` is the hard "never even ask" class — the permission
    policy denies it in every mode, the modal never fires. See
    :class:`rtxclaw_core.tools.safety.CommandSafety.FORBIDDEN`.
    """

    READ_ONLY = "read_only"
    MUTATING = "mutating"
    DESTRUCTIVE = "destructive"
    FORBIDDEN = "forbidden"

    @property
    def severity(self) -> int:
        return _CRIT_SEVERITY[self]


_CRIT_SEVERITY: dict[Criticality, int] = {
    Criticality.READ_ONLY: 0,
    Criticality.MUTATING: 1,
    Criticality.DESTRUCTIVE: 2,
    Criticality.FORBIDDEN: 3,
}


# Map from CommandSafety (heuristic) to Criticality.
# - READ_ONLY  → READ_ONLY
# - MUTATING   → MUTATING
# - DESTRUCTIVE → DESTRUCTIVE
# - FORBIDDEN   → FORBIDDEN (hard-deny in every mode)
# - UNKNOWN     → MUTATING (cautious; can't promise read-only)
_SAFETY_TO_CRITICALITY: dict[CommandSafety, Criticality] = {
    CommandSafety.READ_ONLY: Criticality.READ_ONLY,
    CommandSafety.UNKNOWN: Criticality.MUTATING,
    CommandSafety.MUTATING: Criticality.MUTATING,
    CommandSafety.DESTRUCTIVE: Criticality.DESTRUCTIVE,
    CommandSafety.FORBIDDEN: Criticality.FORBIDDEN,
}


def most_cautious(*claims: Optional[Criticality]) -> Criticality:
    """Return the most cautious of the given non-None claims.

    Default if no claims given: MUTATING (better safe than read-only).
    """
    real = [c for c in claims if c is not None]
    if not real:
        return Criticality.MUTATING
    return max(real, key=lambda c: c.severity)


class Decision(Enum):
    """Outcome of `PermissionEvaluator.evaluate`."""

    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"


class Response(Enum):
    """User response to an `ASK` prompt."""

    YES = "yes"
    YES_DONT_ASK = "yes_dont_ask"  # remember this pattern for the session
    NO = "no"


@dataclass
class PermissionEvaluator:
    """Per-session permission gate.

    Construct one when a session starts; call `evaluate(tool, args)` for
    every tool call before executing it. On `Decision.ASK`, the frontend
    surfaces a prompt; pass the user's answer back to `record(...)` if
    you want `YES_DONT_ASK` to be remembered.
    """

    mode: PermissionMode
    session_allowlist: set[str] = field(default_factory=set)

    def evaluate(
        self,
        tool: Tool,
        args: dict[str, Any],
    ) -> Decision:
        """Return ALLOW / ASK / DENY for one tool call."""
        crit = self._effective_criticality(tool, args)

        # Plan: only read-only allowed.
        if self.mode == PermissionMode.PLAN:
            return Decision.ALLOW if crit == Criticality.READ_ONLY else Decision.DENY

        # Auto: allow everything except destructive ops (always re-prompt).
        if self.mode == PermissionMode.AUTO:
            return Decision.ASK if crit == Criticality.DESTRUCTIVE else Decision.ALLOW

        # Ask mode: read-only auto-allowed, others prompt; session
        # allowlist suppresses re-prompts EXCEPT for destructive.
        if crit == Criticality.READ_ONLY:
            return Decision.ALLOW
        if crit != Criticality.DESTRUCTIVE:
            if self._pattern_for(tool, args) in self.session_allowlist:
                return Decision.ALLOW
        return Decision.ASK

    def record(
        self,
        tool: Tool,
        args: dict[str, Any],
        response: Response,
    ) -> None:
        """Log the user's response. `YES_DONT_ASK` adds to the allowlist.

        Called by the frontend after a prompt. `YES` and `NO` are no-ops
        here — they only affect the current call. `YES_DONT_ASK` remembers
        the pattern for the rest of the session.
        """
        if response == Response.YES_DONT_ASK:
            # Belt-and-braces: even if the caller flubbed it, we never
            # remember a destructive op.
            crit = self._effective_criticality(tool, args)
            if crit != Criticality.DESTRUCTIVE:
                self.session_allowlist.add(self._pattern_for(tool, args))

    # ---- internals ----

    def _effective_criticality(
        self,
        tool: Tool,
        args: dict[str, Any],
    ) -> Criticality:
        """Combine model claim + heuristic; pick the more cautious."""
        # 1. Model's self-classification (from tool call args).
        claimed: Optional[Criticality] = None
        raw = args.get("criticality")
        if isinstance(raw, str):
            try:
                claimed = Criticality(raw)
            except ValueError:
                claimed = None

        # 2. Heuristic (only meaningful for exec).
        heuristic: Optional[Criticality] = None
        if tool.kind == ToolKind.EXEC:
            cmd = args.get("command")
            if isinstance(cmd, str) and cmd:
                heuristic = _SAFETY_TO_CRITICALITY[classify_command(cmd)]

        # 3. Tool-kind floor: a WRITE-kind tool can't be classified read-only
        #    even if the model claims so — opening that door is a footgun.
        if tool.kind == ToolKind.WRITE and (claimed == Criticality.READ_ONLY
                                            or heuristic == Criticality.READ_ONLY):
            kind_floor = Criticality.MUTATING
        elif tool.kind == ToolKind.READ and claimed is None and heuristic is None:
            return Criticality.READ_ONLY  # pure-read tool with no claim → safe
        else:
            kind_floor = None

        return most_cautious(claimed, heuristic, kind_floor)

    def _pattern_for(self, tool: Tool, args: dict[str, Any]) -> str:
        """Build the session-allowlist key for this tool call.

        - For `Bash`: tool name + argv[0] of the command. So saying
          `yes-don't-ask-again` for `git status` covers `git log`,
          `git diff`, etc., but not `rm` or `npm`.
        - For other tools: just the tool name (every call to `Read`
          shares one allowlist entry).
        """
        if tool.kind == ToolKind.EXEC:
            cmd = args.get("command", "")
            if isinstance(cmd, str) and cmd.strip():
                # Bare argv[0]; strip leading path. Match `tools.safety`'s logic.
                head = cmd.strip().split(None, 1)[0]
                head = head.rsplit("/", 1)[-1]
                return f"{tool.name}:{head}"
        return tool.name
