---
name: nodriver-browser
description: "Drive a real headed Chromium browser via the Bash CLI at ~/.rtxclaw/skills/nodriver-browser/browser. Use for: (1) pages web_fetch can't see (Cloudflare, DataDome, JS-heavy SPAs), (2) interactive login flows where a human types credentials in a visible window, (3) sessions that need to persist cookies across calls, (4) clicking/filling/screenshotting/extracting on real DOMs. NOT for: plain HTTP JSON / static HTML (use web_fetch), simple web search (use web_search)."
---

# Nodriver Browser — How to drive Chromium from Bash

This skill is the **only** way to drive a real browser. There are no
`browser_*` tools. You invoke a single CLI launcher from `Bash` and
read its stdout.

## ⚠️ Read this first

1. **One launcher, absolute path:**
   `~/.rtxclaw/skills/nodriver-browser/browser <action> [flags]`
2. **Never** chain it with `cd` (`cd … && python browser.py …`) —
   that pattern silently drops env vars and breaks `DISPLAY`. The
   launcher already cd's into the right place and uses the right venv.
3. **Headed is the default.** Chromium appears on the operator's
   xrdp / Xorg screen. Pass `--headless` only when the operator
   explicitly asks for an unattended run.
4. **`DISPLAY` is auto-set** by the rtxclaw agent at startup —
   the launcher inherits it. On headless hosts (TB08) where the
   agent process has no X session active, pass ``--display :N``
   explicitly (e.g., ``--display :10`` for xrdp).
5. **Global flags go BEFORE the action name:** ``--headless``,
   ``--display``, ``--timeout`` are top-level flags — they must
   come before ``goto``/``extract``/etc.:
   ``browser --headless goto --url ...`` ✅
   ``browser goto --headless --url ...`` ❌
6. **Check status first:** ``browser status [--session live]``
   prints JSON ``{running: true/false, pid, port, ...}``. Use
   it before opening or attaching to avoid hitting stale PIDs.

## Quick reference — every action

Every action takes flags after the action name. Long-form `--flags`
only (no short flags). All commands return text or JSON on stdout
and exit `0` on success, non-zero on failure.

| Action | What it does |
|---|---|
| `goto`       | Navigate to a URL and print the page text (first ~5 KB). Accepts `--session` for live attach. |
| `extract`    | Pull elements matching a CSS selector. With `--json`, prints a JSON array. |
| `click`      | Click an element by `--text` / `--css` / `--xpath`. `--repeat N` for pagination. |
| `fill`       | Fill form fields (`--field selector:value` repeated). `--submit` to submit. |
| `screenshot` | Save page to `--output <file>`. |
| `inspect`    | DOM outline rooted at `--css`, depth-limited JSON tree. Use BEFORE writing a flaky extract. |
| `eval`       | Run a JS expression in the live tab; result is JSON-serialised. |
| `scroll`     | Trigger lazy-load (`--to bottom --steps 4` is the default). |
| `open`       | Launch a long-running headed Chrome with a persistent profile. Other calls attach via `--session`. |
| `close`      | Terminate a session opened with `open`. The profile persists on disk. |
| `status`     | Check if a live session is running. Prints JSON: `{running, pid, port, ...}`. |
| `login`      | Open headed, wait for the operator to log in, save a cookie snapshot. Mostly legacy — prefer `open` + manual login + reuse. |
| `takeover`   | Resume a cookie-snapshot session for an anonymous-looking visit. |
| `persist`    | Verify a saved cookie snapshot exists; prints the path. |

## The 90% pattern: persistent live browser

For almost every browse task: open once, attach many times.

```bash
# 1. Open the headed window. The operator sees it. Returns immediately.
~/.rtxclaw/skills/nodriver-browser/browser open --session live --url https://example.com

# 2. Every follow-up call attaches via --session live. No new Chrome spawn.
~/.rtxclaw/skills/nodriver-browser/browser goto --session live --url https://example.com/page2
~/.rtxclaw/skills/nodriver-browser/browser extract --session live --url https://example.com/page2 --css "table tr" --json
~/.rtxclaw/skills/nodriver-browser/browser eval --session live --js "document.title"

# 3. Do NOT close it when you're done. Leave the window open for the
#    operator. The on-disk profile at
#    ~/.rtxclaw/skills/nodriver-browser/profiles/live/  persists across
#    restarts — Google login from yesterday still works tomorrow.
```

`live` is the default session name. Use a different name only when
the operator wants a separate profile (e.g. `google`, `investing`,
`mercadolivre`, `amazon`).

## Per-action examples

### Navigate + extract page text (anonymous, one-shot)

```bash
~/.rtxclaw/skills/nodriver-browser/browser goto --url https://example.com
```

### Wait for an SPA to hydrate

```bash
~/.rtxclaw/skills/nodriver-browser/browser goto --url https://example.com/spa --wait-for-css "#main-content" --wait 2
```

### Extract a table as JSON

```bash
~/.rtxclaw/skills/nodriver-browser/browser extract --session live --url https://investing.com/economic-calendar/ --css "table.datatable-v2 tr" --attr "text,data-event-id" --json
```

### Click "Load more" 20 times

```bash
~/.rtxclaw/skills/nodriver-browser/browser click --session live --url https://example.com/feed --text "Load more" --repeat 20
```

### Fill a search form and submit

```bash
~/.rtxclaw/skills/nodriver-browser/browser fill --session live --url https://mercadolivre.com.br --field "input.nav-search-input:rtx 3090 usada" --submit
```

### Run arbitrary JS, get JSON back

```bash
~/.rtxclaw/skills/nodriver-browser/browser eval --session live --js 'Array.from(document.querySelectorAll("a")).slice(0,5).map(a => a.href)'
```

### Outline the DOM before writing a fragile selector

```bash
~/.rtxclaw/skills/nodriver-browser/browser inspect --session live --css 'body' --depth 2
```

### Trigger lazy-loaded items

```bash
~/.rtxclaw/skills/nodriver-browser/browser scroll --session live --to bottom --steps 4
```

### Screenshot for debugging

```bash
~/.rtxclaw/skills/nodriver-browser/browser screenshot --session live --url https://example.com --output /tmp/page.png
```

### Check if a session is alive

```bash
~/.rtxclaw/skills/nodriver-browser/browser status --session live
# → {"session": "live", "running": true, "pid": 12345, "port": 12345, ...}
```

### Open on a specific display (headless hosts)

```bash
# When the agent doesn't auto-detect DISPLAY (TB08 without xrdp active):
~/.rtxclaw/skills/nodriver-browser/browser --display :10 open --session live --url https://example.com
```

## Sessions, profiles, cookies — where state lives

```
~/.rtxclaw/skills/nodriver-browser/
├── browser              # The launcher you invoke.
├── scripts/
│   ├── browser.py       # CLI source. Don't invoke directly.
│   └── venv/            # Python venv carrying `nodriver`.
├── profiles/<name>/     # Chrome on-disk profile for `open --session <name>`.
└── sessions/
    ├── <name>.json      # Cookie + localStorage snapshot from `login`.
    └── <name>.live.json # Live-Chrome handle (pid + CDP port) from `open`.
```

- `open --session <name>` writes/updates `<name>.live.json` and the
  matching `profiles/<name>/` dir.
- `login --session <name>` writes `<name>.json` (cookie snapshot)
  after the operator finishes typing credentials.
- Subsequent `goto/extract/click/fill/screenshot/eval/inspect/scroll`
  with `--session <name>` will:
  - **Attach** to the live Chrome if `<name>.live.json` exists and the
    pid is alive.
  - **Otherwise fall back** to a fresh Chromium that hydrates cookies
    from `<name>.json` if that snapshot exists.

## Recovery and pacing

- If a command exits non-zero with **"BLOCKED"** in stderr, the site
  detected automation (Cloudflare, captcha, 403, 429). **Stop.** Don't
  retry. Tell the operator what happened.
- Real Chromium against real sites can earn IP bans. Don't override
  the built-in random delays (0.5 – 2 s between repeated clicks).
- For lazy-loaded grids: `scroll --to bottom --steps 4` first, then
  `extract` or `eval`. If `scrollHeight` stopped growing, there's no
  more content.
- If three consecutive `(action, flags)` calls return zero rows or
  unchanged text, **screenshot the page** before changing your
  selector again. The DOM is probably different from what you think.

## Common mistakes to avoid

| Wrong | Right |
|---|---|
| `cd ~/.rtxclaw/skills/nodriver-browser/scripts && venv/bin/python browser.py goto --url …` | `~/.rtxclaw/skills/nodriver-browser/browser goto --url …` |
| `DISPLAY=:10 ~/.rtxclaw/skills/nodriver-browser/browser …` | `browser --display :10 …` (global flag, not env prefix) |
| Passing `--headless` because Chrome won't show | First check `echo $DISPLAY`. If unset and you're on TB08, pass `--display :10`. |
| `goto … && extract …` in one shell call | Run two separate `Bash` tool calls so each result is visible in the transcript. |
| Closing a session you opened | Leave `open` sessions running unless the operator asks. |
| `browser goto --headless --url ...` | `browser --headless goto --url ...` (global flags before action) |
| `browser eval --code "..."` | `browser eval --js "..."` (the flag is `--js`, not `--code`) |
| `browser goto --session live --url ...` before checking if session is alive | `browser status --session live` first; if stale, `open` a new one |

## Why headed and why a persistent profile

- The operator **sees** what the agent is doing and can intervene
  (log in, solve a captcha, scroll, click). Anything they do in the
  window persists for the next tool call.
- Profile dir keeps cookies + localStorage + history across restarts
  → no nightly re-login dance.
- Headless Chrome leaks fingerprints (`navigator.webdriver`,
  AudioContext anomalies) that anti-bot systems use. Headed bypasses
  most of that.
- Spawn cost amortizes: one Chrome cold-start per task (~2 s)
  instead of one per tool call.

## When to fall back to `web_fetch` / `web_search`

This skill spawns Chrome. That's heavy. Use it only when you need
JS rendering, session state, or anti-bot bypass. For everything
else:

| Target | Tool |
|---|---|
| Public JSON API | `web_fetch` |
| Plain HTML / RSS | `web_fetch` |
| "Find me articles about X" | `web_search` |
| Behind login | this skill |
| Cloudflare-protected | this skill |
| SPA where `view-source` is empty | this skill |
| Need to click / fill / paginate | this skill |

## Bootstrap (only needed on a fresh machine)

The launcher and venv are normally pre-installed. If
`~/.rtxclaw/skills/nodriver-browser/browser` is missing, set up the
venv once:

```bash
mkdir -p ~/.rtxclaw/skills/nodriver-browser/scripts
cd ~/.rtxclaw/skills/nodriver-browser/scripts
python3 -m venv venv
venv/bin/pip install nodriver
```

Then place the launcher shim and `browser.py` from the rtxclaw
source tree at `~/src/rtxclaw/src/rtxclaw_core/builtin_skills/nodriver-browser/`.
