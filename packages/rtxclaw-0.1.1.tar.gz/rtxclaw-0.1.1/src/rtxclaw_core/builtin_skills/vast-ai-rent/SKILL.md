---
name: vast-ai-rent
description: "Rent GPUs on vast.ai from the CLI and connect rtxclaw to the rented endpoint. Covers: (1) install + auth (`vastai`), (2) search offers filtered by GPU type, VRAM, $/hr, region, and uptime, (3) launching with a vLLM/SGLang Docker image and the right port-forward, (4) SSH-tunneling the inference port back to the local box so rtxclaw can reach it as 127.0.0.1, (5) registering the rented endpoint in `models[]`. Use when the user says 'rent a gpu', 'vast.ai', 'I need an H100/H200 for an hour', 'spin up a remote vllm', or wants compute they don't own."
metadata:
  rtxclaw:
    always: false
---

# vast.ai — rent a GPU, point rtxclaw at it

Use this when the local box can't run the model the user wants (the
27/31B FP8 paths need ~32 GB just for weights; the dense 70B / DeepSeek
variants need 80–141 GB). Vast.ai is the cheapest spot-style market;
expect $0.30–$2/hr per H100-80 depending on region + interruptible
status.

## 1. Install the CLI + auth

```bash
# vastai is a single Python script.
uv pip install --system vastai   # or: pip install --user vastai

# Get an API key from https://vast.ai/account/  (avoid pasting in
# shell history; vastai stores it locally for reuse):
vastai set api-key <key-from-the-web-ui>
vastai show user                  # sanity check
```

## 2. Find an offer

The query language is `field op value` joined by spaces. Useful
filters:

```bash
# H100 80GB, On-demand (not interruptible), < $2/hr, > 99% uptime,
# > 8 TB/s GPU bandwidth, in Datacenter (no residential), 1 GPU.
vastai search offers \
  'gpu_name=H100_SXM num_gpus=1 verified=True rentable=True \
   gpu_ram>=80 dph<2.0 inet_down>=500 reliability>0.99 \
   datacenter=True' --order 'dph asc' --limit 8
```

Tweak for your need:

| Want | Filter |
|---|---|
| Hopper / 80 GB / cheapest | `gpu_name=H100_SXM gpu_ram>=80 dph<1.5` |
| Hopper / 141 GB | `gpu_name=H200 gpu_ram>=141` |
| Ampere / 80 GB | `gpu_name=A100_SXM4 gpu_ram>=80` |
| Ada / 48 GB | `gpu_name=L40S gpu_ram>=48` |
| Spot (cheaper, can be evicted) | `rentable=True` plus `dph<...` and bid via `--bid_price` later |
| EU only | `country_code in [DE,FR,NL,SE,FI,IS]` |

Each result row has an `ID`, host machine info, and a `dph_total`
(dollar-per-hour). Pick the cheapest + most reliable.

## 3. Launch the rental

Use a prebuilt vLLM image. Vast.ai will expose the port number it
maps `8000` to in `Direct mapped ports`.

```bash
OFFER=12345678  # the chosen ID from the search
vastai create instance $OFFER \
  --image vllm/vllm-openai:latest \
  --disk 80 \
  --env '-p 8000:8000 -e HF_TOKEN=hf_xxx' \
  --onstart-cmd 'vllm serve Qwen/Qwen3.6-27B-Instruct-FP8 \
    --served-model-name qwen3.6-27b-fp8 \
    --port 8000 \
    --enable-prefix-caching \
    --max-model-len 262144 \
    --gpu-memory-utilization 0.97 \
    --max-num-seqs 4'
```

For SGLang use `lmsysorg/sglang:latest` and replace `--onstart-cmd`
with the SGLang launch (see the `sglang-install` skill).

Watch the boot log live:

```bash
INSTANCE=$(vastai show instances --raw | jq -r '.[0].id')
vastai logs $INSTANCE --tail 80
```

## 4. Get the connection info

```bash
vastai show instance $INSTANCE
```

Look for `ssh_host`, `ssh_port`, and the public port mapping for
`8000` (under `public_ipaddr` / `ports`). Use the public mapping if
the vast.ai host exposes it directly; otherwise SSH-tunnel.

**SSH tunnel (treat the remote endpoint as `127.0.0.1` locally):**

```bash
SSH_HOST=$(vastai show instance $INSTANCE --raw | jq -r '.ssh_host')
SSH_PORT=$(vastai show instance $INSTANCE --raw | jq -r '.ssh_port')

# Background tunnel: local :8001 -> remote :8000
ssh -fN -L 8001:127.0.0.1:8000 \
    -o ServerAliveInterval=30 -o ExitOnForwardFailure=yes \
    -p $SSH_PORT root@$SSH_HOST
```

(Vast.ai injects your `~/.ssh/id_rsa.pub` if you uploaded it before
launching; otherwise `vastai change-ssh-key` first.)

## 5. Register in rtxclaw

`~/.rtxclaw/config.json` → `models[]`:

```json
{
  "alias": "vast",
  "baseUrl": "http://127.0.0.1:8001/v1",
  "id": "qwen3.6-27b-fp8",
  "backend": "vllm",
  "contextWindow": 262144,
  "maxTokens": 0,
  "capabilities": []
}
```

Switch the live session with `/model vast`. The first request to a
fresh boot can take 30–90s while weights download to the instance's
local disk; subsequent requests are normal latency.

## 6. Cost discipline

```bash
# Show current $/hr + accumulated cost.
vastai show instance $INSTANCE --raw | jq '{dph,cur_billed,uptime_mins}'

# Stop billing when you're done (KEEPS the instance, no compute).
vastai stop instance $INSTANCE

# Or destroy it (and the disk).
vastai destroy instance $INSTANCE
```

Set a session-end checklist: rtxclaw's `/restart`-style cleanup
shouldn't leave a rented H200 spinning at $2/hr overnight.

## 7. When to use this vs your own box

Run locally when:
- The workload fits in your VRAM (`vllm-install` step 1).
- The session is long-running (the SSH tunnel + boot delay isn't
  worth it for 10 minutes of work).

Rent vast.ai when:
- You need a quant/dtype your card can't host (FP8 on a 3090).
- The model size needs >24 GB (Qwen3.6-27B FP8 needs ≥32 GB; the
  dense 70B+ needs ≥80 GB).
- You're benchmarking or doing one-off heavy inference and don't want
  to keep the GPU on.
