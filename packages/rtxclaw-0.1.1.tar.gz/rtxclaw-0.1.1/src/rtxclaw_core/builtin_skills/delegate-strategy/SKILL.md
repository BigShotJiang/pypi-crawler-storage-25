---
name: delegate-strategy
description: "When a local 27-31B model should delegate to a larger remote model (Claude/Codex/Gemini) instead of grinding through. The 'first thinking on local, escalate on hard' pattern that justifies running a small model at all. Use whenever the user asks 'should I delegate this', 'is this too hard for the local model', 'when do I use /claude', 'how to route between models', or when the local model has been stuck for >2 rounds on the same step."
metadata:
  rtxclaw:
    always: false
---

# Delegate to a bigger model — when, and how cleanly

You are running on a 27-31B local model. You are **fast** and
**free** but you are not GPT-5 or Opus 4.x. This skill teaches the
operator (and you, the model reading it via `Skill`) the routing
rules that justify running a small model at all.

## The routing rule

| Phase of a task | Who does it |
|---|---|
| Read the user's prompt, pick the right skill, fetch context, plan steps | **local** (you) |
| Read + understand existing code, find the right files, run tests, summarise outputs | **local** |
| Write 20–80 lines of code from a clear spec, rename, refactor mechanical changes | **local** |
| Write 200+ lines of unfamiliar code from scratch, design a new module, reason about subtle concurrency, decode a stack trace from a framework you've never touched | **delegate** |
| Verify a critical security claim, audit code for vulns, write a proof | **delegate** |
| Run a 5-minute exec / shell pipeline, parse JSON, format output | **local** |
| Explain a concept to the user, summarise a doc, translate between formats | **local** |

The general heuristic: **first thinking happens locally; only the
final synthesis on hard problems delegates.** Doing it the other way
round burns tokens on what a 27B model already does fine.

## The three escalation triggers

Delegate when ANY of these fire:

1. **You're stuck in a recovery loop.** Three rounds in a row of
   "tried X, didn't work; let me try Y" without making real progress.
   Distill what you've learned and hand it to a bigger model with the
   full thread.

2. **The task requires synthesising 5+ files of unfamiliar code.**
   You can read them, but the gestalt understanding ("what is this
   architecture actually doing?") is where small models drift.

3. **The user explicitly asked for high-stakes output.** A
   user-facing migration plan, a security-sensitive patch, a public
   API design. Don't be the bottleneck on prose the user will paste
   into a critical doc.

DO NOT delegate when:

- You're partway through and just want a sanity check (use the
  local model — small models are great at sanity checks).
- The work is mechanical (rename, format, run-and-summarise).
- The user is iterating fast and waiting on you (delegation adds
  10–30s of latency).

## How to delegate cleanly

rtxclaw exposes three external bridges as tools:

| Tool | Best for | Notes |
|---|---|---|
| `delegate_claude` | Code synthesis, refactors, security review, prose | Anthropic Claude Code via the local `claude` CLI. Resumes sibling sessions across calls (sticky context). |
| `delegate_codex` | Reasoning-heavy debug, long traces, mathematical work | OpenAI Codex via `codex` CLI. |
| `delegate_gemini` | Multimodal (images), long-context summarisation | Google Gemini via `gemini` CLI. |

There's also `delegate_agent(name, task)` — delegates to a SIBLING
rtxclaw agent (a `coder` / `scraper` worker — not an external CLI).
Use that for fan-out, not escalation.

### The prompt you send a delegate matters more than which one

A typical bad delegate:
> `delegate_claude(prompt="fix the bug")`

The delegate has no context. It either asks for more or guesses.
Round-tripping costs more than doing it locally.

A good delegate:
```text
delegate_claude(prompt="""
Context: I'm 3 rounds into refactoring ~/src/foo/bar.py. The
failing test is tests/test_bar.py::test_round_trip. The traceback
ends in ``KeyError: 'inserted_at'``.

What I've tried (didn't work):
- adding the field at insert
- pre-populating defaults

The schema (tests/conftest.py L40-55) sets ``inserted_at`` as a
server default but the test fixture instantiates the model
client-side, so the default never fires.

Goal: fix tests/test_bar.py so the field is populated client-side
when no server is involved. Show the diff only, no prose. 
""")
```

Note what's there: the failing test path, the traceback, the
diagnosis chain, and a tight ask. The delegate writes the patch in
one round.

## After a delegate returns

You (local) ALWAYS:

1. **Read** the delegate's output. Don't just paste it.
2. **Run** any tests it claims should pass.
3. **Verify** against the original ask — small models are perfectly
   capable of catching "delegate generated code that compiles but
   doesn't actually do what was asked".
4. **Summarise** back to the user as if you had done the work
   (because the user is paying for your tokens, not the
   delegate's — they want a coherent thread, not transcripts of
   internal hand-offs).

## Cost discipline

Each delegate is capped at ONE per turn per bridge by the runtime
(see `acp_bridge._DELEGATE_BUDGET_TOOLS`). If you'd want to delegate
twice in one turn, that's a sign you should have done it earlier
with better context, not three times now. Ask the user before
escalating to a second bridge in the same turn.
