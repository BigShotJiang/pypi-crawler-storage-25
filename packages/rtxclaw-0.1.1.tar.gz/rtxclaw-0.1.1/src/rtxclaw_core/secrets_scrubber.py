"""Redact secrets from text destined for the session log.

The session JSON files at ``<agent_home>/sessions/<sid>.json`` are
the corpus operators feed back into fine-tune SFT pipelines, AWQ
calibration runs, and crash-debug forensics. They MUST NOT carry
credentials in the clear — once a session JSON has been generated,
it gets copied around: into training datasets, into shared
diagnostic archives, into wiki ingestion. A leaked OpenAI key,
GitHub PAT, AWS access key, or operator OAuth bearer there is a
real-world incident.

This module is the single chokepoint. Every text field that lands
on disk runs through :func:`scrub_text`; structured fields (dicts,
lists, JSON-serialisable values) run through :func:`scrub_value`,
which walks the tree and applies ``scrub_text`` to every string
leaf.

Design constraints:

* **Cheap.** The scrubber runs once per turn-save, of which there
  are now ~10× more per turn after PR #235. Pure regex over the
  text; no SAT solvers, no allocation-heavy string ops.
* **High recall over precision.** A false positive (over-redaction)
  is annoying but recoverable — operators can paste the redacted
  segment back from gateway.log if they need to debug an exact
  call. A false negative (a real credential makes it to disk) is
  an incident. So patterns are tuned to err on the side of redact.
* **No external dependencies.** stdlib ``re`` only. Easy to audit;
  easy to extend; no surprise transitive vuln surface.
* **Idempotent.** Running ``scrub_text(scrub_text(x))`` == ``scrub_text(x)``.
  Critical because the same string may transit multiple writes
  (in-progress flushes via PR #235 + final TurnDone).

Patterns are intentionally LIBERAL — when in doubt, redact. The
redaction sentinel ``<<REDACTED:KIND>>`` is unique enough that a
trainer / linter can spot whether a corpus has been scrubbed and
optionally exclude scrubbed rows from sensitive eval sets.
"""
from __future__ import annotations

import re
from typing import Any, Iterable

# ---------------------------------------------------------------------
# Pattern registry. Each entry is ``(name, compiled_regex, replacement)``.
#
# Replacement uses the literal sentinel ``<<REDACTED:NAME>>`` so a
# downstream consumer can detect what was stripped without learning
# the value. ``NAME`` is the pattern key — keeping it stable makes
# diff-based audit of the corpus straightforward.
#
# Order matters within a pass: more specific patterns must match
# BEFORE the catch-all "looks-like-a-token" pattern, otherwise the
# catch-all redacts the value with a generic tag and loses the
# kind-of-secret signal.
# ---------------------------------------------------------------------


def _redact(name: str) -> str:
    return f"<<REDACTED:{name}>>"


_PATTERNS: list[tuple[str, "re.Pattern[str]", str]] = []


def _register(name: str, pattern: str, *, flags: int = 0) -> None:
    _PATTERNS.append((name, re.compile(pattern, flags), _redact(name)))


# ---- specific provider keys (highest priority — exact prefixes) -----
#
# OpenAI / Anthropic / xAI / Mistral / Cohere / OpenRouter / DeepSeek
# all converged on a ``<prefix>-<long_b64ish>`` shape. Catch them by
# their distinguishing prefix rather than a generic "long token".

# OpenAI: sk-… (classic) and sk-proj-… (project-scoped). Length
# varies (~32-72 chars after the prefix). Match the prefix and grab
# at least 20 token chars after it. Refuse ``sk-ant-`` so it doesn't
# steal matches that belong to the ANTHROPIC_KEY pattern below.
_register("OPENAI_KEY", r"\bsk-(?!ant-)(?:proj-)?[A-Za-z0-9_-]{20,}")

# Anthropic: sk-ant-api… or sk-ant-… (legacy). Same shape.
_register("ANTHROPIC_KEY", r"\bsk-ant-[A-Za-z0-9_-]{20,}")

# Google AI Studio / Gemini API: AIza followed by exactly 35
# token chars. No trailing ``\b`` — the value may end in ``-``,
# which is non-word, so a non-word→non-word transition into
# whitespace would not satisfy ``\b``. The exact ``{35}`` quantifier
# bounds the match.
_register("GOOGLE_API_KEY", r"\bAIza[A-Za-z0-9_-]{35}")

# GitHub PATs (classic + fine-grained + server-to-server + user-to-
# server + OAuth + refresh). All share the ghX_ prefix.
_register("GITHUB_TOKEN", r"\bgh[opusr]_[A-Za-z0-9]{36,}\b")

# AWS access key IDs (AKIA/ASIA/AGPA prefix + 16 base32). Secret
# access keys are 40 chars of base64 — caught by the password=
# context-prefix patterns below since they don't have a distinctive
# prefix to anchor on.
_register("AWS_ACCESS_KEY_ID", r"\b(?:AKIA|ASIA|AGPA|ANPA|ANVA|ASCA)[0-9A-Z]{16}\b")

# Slack tokens (bot / user / app / refresh).
_register("SLACK_TOKEN", r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")

# Stripe (live + test).
_register("STRIPE_KEY", r"\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{24,}\b")

# Telegram bot tokens: ``<bot_id>:<35-char>``. Used by rtxclaw's
# own telegram service — catch operator copy/pastes.
_register("TELEGRAM_BOT_TOKEN", r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b")

# Discord bot tokens (Nlong.Bshort.Csigned).
_register("DISCORD_TOKEN", r"\b[A-Za-z0-9_-]{24,28}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,}\b")

# JWT — three base64url segments joined by dots, header begins with
# the alg=HS256/RS256/ES256/etc. eyJ prefix.
_register("JWT", r"\beyJ[A-Za-z0-9_-]+?\.[A-Za-z0-9_-]+?\.[A-Za-z0-9_-]+\b")

# HashiCorp Vault tokens — modern: hvs.<base62> / legacy:
# s.<base62>. The ``s.`` prefix is short enough that we anchor by
# requiring at least 24 chars of value to avoid false positives on
# everyday "s. plus identifier" prose.
_register("VAULT_TOKEN", r"\bhvs\.[A-Za-z0-9_-]{20,}\b")
_register("VAULT_LEGACY_TOKEN", r"\bs\.[A-Za-z0-9]{24,}\b")

# npm registry auth tokens (``//registry.npmjs.org/:_authToken=…``
# and ``_password=…``). The leading underscore breaks the
# ``\btoken`` boundary, so the generic CREDENTIAL pattern misses
# this idiom in .npmrc / npm config files.
_register(
    "NPM_AUTH_TOKEN",
    r"(?i)//[A-Za-z0-9._/-]+:_authtoken\s*=\s*([A-Za-z0-9_-]{8,})",
)

# Docker config (``~/.docker/config.json``) embeds basic-auth as
# ``"auth": "<base64>"``. The keyword ``auth`` alone isn't in the
# generic CREDENTIAL list (too noisy — "auth" appears in benign
# prose), so match it only in the JSON-string idiom.
_register(
    "DOCKER_AUTH",
    r'"auth"\s*:\s*"([A-Za-z0-9+/=]{12,})"',
)

# Private keys (PEM blocks). DOTALL so ``-----BEGIN … END-----``
# spanning multiple lines is captured in one match.
_register(
    "PRIVATE_KEY_BLOCK",
    r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED |PGP |)PRIVATE KEY"
    r"(?: BLOCK)?-----.*?-----END (?:RSA |EC |OPENSSH |DSA |ENCRYPTED |PGP |)"
    r"PRIVATE KEY(?: BLOCK)?-----",
    flags=re.DOTALL,
)

# SSH key fingerprints / passphrases are NOT redacted (they're not
# secrets); the PEM block above catches the keys themselves.

# ---- context-prefix patterns (kw=value, kw: value) ------------------
#
# Operator scripts and Bash tool calls often paste secrets as
# ``PASSWORD=hunter2`` / ``TOKEN: abc123`` / ``--api-key foo`` /
# ``Authorization: Bearer eyJ…``. Match the keyword, the separator,
# and grab a generous run of value chars until whitespace or
# shell metacharacter (`'"&|;`>`).
#
# These run AFTER the provider-key patterns above so an exact key
# format gets the right ``NAME`` instead of the generic
# ``CREDENTIAL`` tag.

_CREDENTIAL_KEYWORDS = (
    "password", "passwd", "secret", "token", "apikey", "api_key",
    "api-key", "auth_token", "auth-token", "access_token", "access-token",
    "refresh_token", "refresh-token", "bearer", "private_key", "private-key",
    "session_token", "session-token", "credentials", "client_secret",
    "client-secret",
)
_KW = "|".join(re.escape(k) for k in _CREDENTIAL_KEYWORDS)
# Form: `kw = value` or `kw: value` or `kw "value"` etc.
_register(
    "CREDENTIAL",
    rf"(?i)\b(?:{_KW})\s*[:=]\s*['\"]?([^'\"\s$`&|;>]{{6,}})['\"]?",
)
# Form: `--api-key foo` / `--token=foo` / `-p somepassword` (very
# common in Bash tool calls).
_register(
    "CLI_FLAG_CREDENTIAL",
    rf"(?i)\B--(?:{_KW})(?:[= ])\s*['\"]?([^'\"\s$`&|;>]{{6,}})['\"]?",
)
# Form: `Authorization: Bearer <token>` (HTTP header style).
_register(
    "BEARER_AUTH",
    r"(?i)\bauthorization\s*:\s*bearer\s+[A-Za-z0-9._\-+/=]{16,}",
)

# Form: an env-style line `EXPORT KEY=value` or `KEY=value` where
# KEY ends in known credential suffixes. More specific than the
# generic CREDENTIAL above because it requires SHOUTY_SNAKE_CASE
# (the env-var idiom).
_register(
    "ENV_CREDENTIAL",
    r"\b(?:[A-Z][A-Z0-9_]*_(?:KEY|TOKEN|SECRET|PASSWORD|PWD))\s*=\s*['\"]?"
    r"([^'\"\s$`&|;>]{6,})['\"]?",
)


# ---- the public API ------------------------------------------------


def scrub_text(text: str) -> str:
    """Apply every registered pattern to ``text`` and return the
    redacted string. Idempotent: a string with sentinels already
    in it stays unchanged on a second pass (no pattern matches the
    sentinel form ``<<REDACTED:…>>``).

    Returns ``text`` unchanged when it is not a string. The empty
    string and ``None``-shaped inputs short-circuit immediately so
    the hot session-save path doesn't waste cycles.
    """
    if not isinstance(text, str) or not text:
        return text
    out = text
    for name, pattern, replacement in _PATTERNS:
        # For patterns that capture a single group, replace only the
        # group span — that keeps the surrounding context (`PASSWORD=`,
        # `--token`, etc.) visible to the reader so they know the
        # SHAPE of what was redacted. For patterns without groups
        # (raw token shapes like sk-…) replace the whole match.
        if pattern.groups == 1:
            def _sub(m: "re.Match[str]", _r: str = replacement) -> str:
                whole = m.group(0)
                grp = m.group(1)
                # Idempotence: if the captured value is already a
                # redaction sentinel from a prior scrub pass, leave
                # the match unchanged. Without this guard, a pattern
                # like ``password=<<REDACTED:CREDENTIAL>>`` would
                # re-match on the next pass (capturing
                # ``<<REDACTED:CREDENTIAL`` as the "value") and
                # append an extra ``>>``.
                if grp.startswith("<<REDACTED:"):
                    return whole
                start_in_match = whole.index(grp)
                end_in_match = start_in_match + len(grp)
                return (
                    whole[:start_in_match] + _r + whole[end_in_match:]
                )
            out = pattern.sub(_sub, out)
        else:
            out = pattern.sub(replacement, out)
    return out


def scrub_value(value: Any) -> Any:
    """Recursively scrub a JSON-serialisable value.

    * ``str``  → :func:`scrub_text` applied.
    * ``dict`` → keys passed through unchanged; values scrubbed.
    * ``list`` / ``tuple`` → elementwise scrub (returns a ``list``
      because the persisted shape is always JSON-array).
    * Anything else (int, float, bool, None, custom objects) →
      returned unchanged.

    Returns a NEW container; the input is never mutated. That
    matters because the in-memory ``tool_calls`` list also feeds
    the live model context — mutating it under the model would
    poison subsequent rounds.
    """
    if isinstance(value, str):
        return scrub_text(value)
    if isinstance(value, dict):
        return {k: scrub_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [scrub_value(v) for v in value]
    # ``bytes`` may carry a credential too (e.g. a copy-pasted PEM
    # block that hit a bytes-handling code path). Decode best-effort
    # and re-encode the scrubbed text. ``set`` / ``frozenset`` get
    # converted to a sorted list so the JSON serializer downstream
    # can persist them; the original container type was already
    # destined to fail ``json.dumps``, so this is a strict upgrade.
    # Anything else (numpy / custom object / etc.) is replaced with
    # a sentinel — silent pass-through would let an engine that
    # passes such a value at some future point leak its repr to disk
    # un-scrubbed.
    if isinstance(value, (bytes, bytearray)):
        try:
            decoded = bytes(value).decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            return f"<<REDACTED:OPAQUE_BYTES_{len(value)}>>"
        return scrub_text(decoded)
    if isinstance(value, (set, frozenset)):
        return [scrub_value(v) for v in sorted(value, key=repr)]
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    # Unknown type — produce a typed sentinel rather than a
    # silently-stringified repr that might leak unscrubbed content.
    return f"<<REDACTED:UNKNOWN_TYPE:{type(value).__name__}>>"


def list_pattern_names() -> Iterable[str]:
    """Return the registered pattern names (for tests + audit)."""
    return tuple(name for name, _, _ in _PATTERNS)


__all__ = (
    "scrub_text",
    "scrub_value",
    "list_pattern_names",
)
