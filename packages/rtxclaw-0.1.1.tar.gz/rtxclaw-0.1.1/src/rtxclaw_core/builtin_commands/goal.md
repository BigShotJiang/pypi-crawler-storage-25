---
description: Set a completion condition; work iteratively until met.
argument-hint: "<completion-condition>"
---

# /goal — work until the condition is met

The operator has set the following goal/completion condition:

> $ARGUMENTS

## How to execute

1. **Treat the line above as a goal**, not a one-shot task. The
   condition tells you when to stop — until it is demonstrably met
   (commands pass, file exists, test green, metric ≥ N, etc.), keep
   iterating.

2. **Plan the first step now.** Use `TodoWrite` (or the equivalent
   plan tool) to write the smallest concrete action that moves you
   toward the goal. Then execute it.

3. **Self-pace with the loop mechanism.** When you finish a step but
   the completion condition is NOT yet met, schedule the next
   iteration via `ScheduleWakeup` (the dynamic `/loop` mode — pass
   the literal sentinel `<<autonomous-loop-dynamic>>` so the runtime
   re-enters this goal on the next turn). Pick a delay that matches
   what you're waiting on (cache window vs. external job; see the
   tool's own guidance). Omit the `ScheduleWakeup` call to terminate.

4. **Check the condition every turn.** Before scheduling another
   iteration, verify the goal: run the test, read the file, inspect
   the metric, etc. Don't rely on intermediate signals — only the
   condition the operator wrote above.

5. **Stop the moment the goal is met.** Don't schedule another wake.
   Don't add scope ("while I'm here, let me also..."). Report what
   you did and what evidence shows the goal is satisfied.

6. **Stop on genuine block.** If you can't make progress (missing
   credential, external dependency down, ambiguity that needs
   operator input), state the blocker clearly and stop. Do NOT
   schedule another wake into a known-stuck state.

## Reporting

Each turn, lead with one sentence: what you just did, and whether
the goal is met. Keep iterations tight — the operator can read the
artifact, they don't need a recap of every command.
