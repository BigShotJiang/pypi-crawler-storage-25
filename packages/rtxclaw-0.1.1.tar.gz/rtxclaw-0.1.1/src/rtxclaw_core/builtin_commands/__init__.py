"""File-based slash commands bundled with the rtxclaw package.

Discovered by ``rtxclaw_core.file_commands.command_search_paths`` at
the LOWEST precedence — a user-installed command at
``~/.rtxclaw/commands/<name>.md`` (or ``~/.claude/commands/<name>.md``)
overrides the bundled copy. The bundled copy is the source of truth
that ships with the codebase; it does not depend on anything in the
user's home directory existing before first use.

This mirrors the ``builtin_skills/`` arrangement so the wheel ships
both bundled skills and bundled commands, and both layers honour the
same operator-override semantics.
"""
