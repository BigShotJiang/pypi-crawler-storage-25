"""Built-in LLM provider presets + the bundled zero-config default.

Two things live here:

1. :data:`PROVIDER_PRESETS` — a curated list of well-known,
   **OpenAI-compatible** providers the first-run wizard offers as
   one-pick presets (so a newcomer picks "DeepSeek" instead of
   memorising ``https://api.deepseek.com/v1`` + the right env var).

2. The **bundled free default** (NVIDIA Nemotron via OpenRouter) so a
   fresh ``pip install rtxclaw`` → ``rtxclaw`` can chat *immediately*
   with no signup. A shared, public demo key ships as a fallback; a
   personal ``OPENROUTER_API_KEY`` always wins (see
   :meth:`rtxclaw_core.agent.AgentConfig.upstream_headers`).

Anthropic is intentionally NOT a preset: rtxclaw speaks the OpenAI
``/v1/chat/completions`` shape, and Anthropic's native Messages API is
different. Use Claude models through the OpenRouter preset instead.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderPreset:
    """One OpenAI-compatible provider the wizard can pre-fill."""

    key: str          # short id, e.g. "deepseek"
    label: str        # display name, e.g. "DeepSeek"
    base_url: str     # OpenAI-compatible base URL (ends in /v1 or /openai)
    api_key_env: str  # conventional env var for the key ("" = local/no key)
    note: str = ""    # one-line hint shown in the picker


# Order matters — this is the wizard's menu order. OpenRouter first
# (it fronts every other provider incl. free models), then the big
# direct providers, then local servers.
PROVIDER_PRESETS: list[ProviderPreset] = [
    ProviderPreset(
        "openrouter", "OpenRouter", "https://openrouter.ai/api/v1",
        "OPENROUTER_API_KEY", "1000s of models incl. free ones (Claude, GPT, Llama…)",
    ),
    ProviderPreset(
        "openai", "OpenAI", "https://api.openai.com/v1", "OPENAI_API_KEY",
    ),
    ProviderPreset(
        "deepseek", "DeepSeek", "https://api.deepseek.com/v1", "DEEPSEEK_API_KEY",
    ),
    ProviderPreset(
        "xai", "xAI (Grok)", "https://api.x.ai/v1", "XAI_API_KEY",
    ),
    ProviderPreset(
        "qwen", "Qwen (DashScope)",
        "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
        "DASHSCOPE_API_KEY",
    ),
    ProviderPreset(
        "groq", "Groq", "https://api.groq.com/openai/v1", "GROQ_API_KEY",
    ),
    ProviderPreset(
        "mistral", "Mistral", "https://api.mistral.ai/v1", "MISTRAL_API_KEY",
    ),
    ProviderPreset(
        "gemini", "Google Gemini",
        "https://generativelanguage.googleapis.com/v1beta/openai/",
        "GEMINI_API_KEY", "OpenAI-compat endpoint",
    ),
    ProviderPreset(
        "cerebras", "Cerebras", "https://api.cerebras.ai/v1", "CEREBRAS_API_KEY",
    ),
    ProviderPreset(
        "together", "Together", "https://api.together.xyz/v1", "TOGETHER_API_KEY",
    ),
    ProviderPreset(
        "vllm", "Local vLLM", "http://127.0.0.1:8000/v1", "", "self-hosted",
    ),
    ProviderPreset(
        "sglang", "Local SGLang", "http://127.0.0.1:30000/v1", "", "self-hosted",
    ),
    ProviderPreset(
        "ollama", "Local Ollama", "http://127.0.0.1:11434/v1", "", "self-hosted",
    ),
    ProviderPreset(
        "lmstudio", "Local LM Studio", "http://127.0.0.1:1234/v1", "", "self-hosted",
    ),
]


def preset_by_key(key: str) -> ProviderPreset | None:
    key = (key or "").strip().lower()
    for p in PROVIDER_PRESETS:
        if p.key == key:
            return p
    return None


# --------------------------------------------------------------------------
# Bundled free default — the zero-config quickstart
# --------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://openrouter.ai/api/v1"
DEFAULT_MODEL = "nvidia/nemotron-3-super-120b-a12b:free"
DEFAULT_MODEL_ALIAS = "nemotron-free"
DEFAULT_API_KEY_ENV = "OPENROUTER_API_KEY"
DEFAULT_CONTEXT_WINDOW = 1_000_000  # OpenRouter model metadata (2026-05)

# SHARED, PUBLIC demo key shipped so a fresh install chats out-of-box
# with no signup. It is rate-limited and visible to everyone who installs
# rtxclaw — do NOT treat it as private. A personal OPENROUTER_API_KEY
# (env var or `rtxclaw configure`) ALWAYS takes precedence over this; the
# fallback only fires for the shipped Nemotron default row (the row sets
# ``useBundledKey: true``) and only against OpenRouter — never for a
# user-added OpenRouter model, so it can't be used to bill paid models.
BUNDLED_OPENROUTER_KEY = (
    "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"
)


def is_openrouter(base_url: str) -> bool:
    """True iff ``base_url``'s host is exactly OpenRouter's API host.

    Host-equality (not substring) so a look-alike like
    ``https://openrouter.ai.evil.example/v1`` can NEVER be mistaken for
    OpenRouter and receive the shared bundled key.
    """
    from urllib.parse import urlparse
    try:
        host = (urlparse(base_url or "").hostname or "").lower()
    except ValueError:
        return False
    return host == "openrouter.ai"


def bundled_key_for_row(row: dict) -> str:
    """Return the bundled fallback key for a model row, or '' if none.

    Bound to the EXACT shipped default — ``useBundledKey: true`` AND the
    canonical free Nemotron model id AND OpenRouter's real host. A user
    who edits the row's ``id`` to a paid OpenRouter model, or repoints
    ``baseUrl`` at a look-alike host, gets '' — so the shared demo key can
    never bill a paid model or leak to another host.
    """
    if not isinstance(row, dict):
        return ""
    if not row.get("useBundledKey"):
        return ""
    if str(row.get("id") or "") != DEFAULT_MODEL:
        return ""
    if not is_openrouter(str(row.get("baseUrl") or "")):
        return ""
    return BUNDLED_OPENROUTER_KEY


def default_model_row() -> dict:
    """The ``models[]`` row for the bundled free Nemotron default."""
    return {
        "alias": DEFAULT_MODEL_ALIAS,
        "baseUrl": DEFAULT_BASE_URL,
        "id": DEFAULT_MODEL,
        "backend": "unknown",
        "contextWindow": DEFAULT_CONTEXT_WINDOW,
        "maxTokens": 0,
        "apiKeyEnv": DEFAULT_API_KEY_ENV,
        "headers": {"X-Title": "rtxclaw"},
        # Marks this as the shipped default that may use the shared demo
        # key as a fallback. The wizard never sets this on user rows.
        "useBundledKey": True,
    }
