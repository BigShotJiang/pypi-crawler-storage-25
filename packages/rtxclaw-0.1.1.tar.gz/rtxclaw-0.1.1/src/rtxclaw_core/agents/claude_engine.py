"""``ClaudeCliEngine`` — wraps the ``claude -p`` CLI.

Class-shape facade. :meth:`delegate_runner` returns
``runners.run_delegate_claude_async``; the
:class:`ExternalCliEngine.run_turn` driver translates that runner's
``on_delta`` / ``on_event`` callbacks into :data:`AgentTurnEvent`
instances. The whole CLI subprocess pipeline (stdin priming,
``--resume``, group-kill on cancel, stale-resume retry, structured
logging, truncation, ``--include-partial-messages``, inner-tool
``on_event`` surface) lives in the legacy runner.
"""

from __future__ import annotations

from typing import Any

from .engine import EngineKind
from .external_cli import ExternalCliEngine


class ClaudeCliEngine(ExternalCliEngine):
    """Run a turn through ``claude -p --output-format stream-json``."""

    kind = EngineKind.CLAUDE_CLI
    cli_command = "claude"
    install_url = "https://claude.com/code"

    @property
    def name(self) -> str:
        return "claude"

    def delegate_runner(self) -> Any:
        """Return ``runners.run_delegate_claude_async``.

        :meth:`ExternalCliEngine.run_turn` awaits the returned helper
        with ``on_delta`` (and ``on_event`` — Claude is the only
        engine that surfaces structured ``tool_use`` / ``tool_result``
        blocks today) wired to the AgentTurnEvent translator.
        """
        from rtxclaw_core.tools.runners import run_delegate_claude_async
        return run_delegate_claude_async

    def supports_on_event(self) -> bool:
        # Claude is the only legacy runner that surfaces structured
        # tool_use / tool_result blocks via on_event today.
        return True

    def resume_footer(self) -> str:
        """``[claude --resume note: …]`` footer block.

        Stable wording (no timestamps, no session id) so the marker is
        cache-friendly when replayed in the local model's next round.
        """
        return (
            "\n\n[claude --resume note: Claude now has this exchange. On your "
            "next delegate_claude call in this rtxclaw session, only forward "
            "context that is NEW since this point — do not restate this "
            "reply or anything earlier.]"
        )
