"""``CursorAcpEngine`` — Cursor's quirks on top of the generic ACP engine.

Cursor's ``cursor-agent acp`` is *almost* a vanilla ACP server, but has
a few documented non-standard behaviours. This thin subclass of
:class:`~rtxclaw_core.agents.acp_engine.AcpEngine` is the ONLY place
those quirks live — everything else (spawn, handshake, session/prompt,
session/update translation, sidecar, abort) is the generic engine.

Cursor peculiarities handled here:

* **Session modes** are ``agent`` / ``plan`` / ``ask`` (NOT the
  ``auto`` / ``plan`` / ``ask`` rtxclaw uses), so ``session/set_mode``
  needs ``auto`` → ``agent``. See
  https://agentclientprotocol.com/protocol/session-modes and
  https://cursor.com/docs/agent/plan-mode.
* **Model ids carry vendor suffixes** like ``composer-2.5[fast=true]``
  / ``default[]`` (and a ``thinking=true`` variant even when disabled),
  so the display label is normalized. See
  https://forum.cursor.com/t/please-add-model-advertising-to-the-acp/154153.
* **Defaults** the spawn command (``cursor-agent acp``), label
  (``cursor``) and auth method (``cursor_login``) so a Cursor agent's
  ``config.json`` only needs ``"engine": "cursor_acp"``.

A generic ACP agent (Gemini, Zed, …) uses ``"engine": "acp"`` with an
explicit ``acp_command`` and needs none of this.
"""
from __future__ import annotations

import re
from typing import Any

from .acp_engine import AcpEngine, _read_acp_config
from .engine import EngineKind


class CursorAcpEngine(AcpEngine):
    """Generic :class:`AcpEngine` specialized for ``cursor-agent acp``."""

    kind = EngineKind.CURSOR_ACP

    # rtxclaw permission mode → Cursor ACP session mode id.
    _MODE_MAP = {"auto": "agent", "plan": "plan", "ask": "ask"}

    # Strips a trailing vendor-encoded variant suffix, e.g.
    # ``composer-2.5[fast=true]`` → ``composer-2.5``, ``default[]`` → ``default``.
    _SUFFIX_RE = re.compile(r"\[[^\]]*\]\s*$")

    # Composer's context window. Cursor's ACP does NOT advertise it for
    # composer models (only gpt/claude/grok ids carry ``context=``), and
    # Composer 2 is documented at 200k, so default composer to 200k.
    # Overridable per-agent via ``acp_context_window`` in config.json.
    _DEFAULT_WINDOW = 200_000

    def __init__(self, cfg: Any = None, **kwargs: Any) -> None:
        # Per-agent config wins; the Cursor defaults only fill the gaps,
        # so a cursor agent's config.json may still override the command
        # (e.g. extra flags), label, or auth method. An explicit kwarg
        # (tests) wins over both via setdefault.
        acp = _read_acp_config(cfg)
        kwargs.setdefault("command", acp["command"] or ["cursor-agent", "acp"])
        kwargs.setdefault("name", acp["name"] or "cursor")
        kwargs.setdefault("auth_method", acp["auth_method"] or "cursor_login")
        super().__init__(cfg, **kwargs)

    def _acp_mode(self, mode: str) -> str:
        return self._MODE_MAP.get(mode, mode)

    def context_window(self) -> int:
        # Model-id-parsed (gpt/claude) or configured window wins; else the
        # composer default (Cursor doesn't report composer's window).
        return super().context_window() or self._DEFAULT_WINDOW

    def _clean_model_label(self, label: str) -> str:
        cleaned = self._SUFFIX_RE.sub("", label).strip()
        return cleaned or label


__all__ = ["CursorAcpEngine"]
