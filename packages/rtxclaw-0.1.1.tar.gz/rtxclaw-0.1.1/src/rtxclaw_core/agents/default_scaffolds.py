"""Default on-disk templates for auto-scaffolded external-engine agents.

Templates are minimal but operational. Operators who want a customized
agent (e.g. ``dashboard_dev``) create the dir by hand or override the
files post-scaffold — :func:`write_scaffold` never overwrites an
existing file.

When :func:`factory.ensure_default_external_agents` runs and the CLI
is on PATH, it drops these files under
``~/.rtxclaw/agents/<short_name>/`` (``claude`` / ``codex`` / ``gemini``):

* ``config.json``  — :func:`config_for`
* ``SOUL.md``      — :func:`soul_for`
* ``AGENTS.md``    — :func:`agents_md_for`
* ``TOOLS.md``     — :func:`tools_md_for`
* ``USER.md``      — empty (the operator's per-agent introduction)
* ``MEMORY.md``    — empty (the agent populates this over time)
* ``HEARTBEAT.md`` — empty (heartbeat disabled by default for CLI
                    engines; flip ``heartbeat_enabled=true`` in
                    ``config.json`` to enable)

The Agent's :meth:`compose_system_prompt` reads these files at turn
time; for CLI engines, the composed result rides on
``--append-system-prompt`` (Claude) or first-message injection
(Codex / Gemini) on the first call of each session.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from .engine import EngineKind


_LOG = logging.getLogger("rtxclaw.agents.scaffolds")


# Engine kind → short directory name + display name + install hint.
_KIND_DETAILS: dict[str, dict[str, str]] = {
    EngineKind.CLAUDE_CLI.value: {
        "short_name": "claude",
        "display_name": "Claude Code",
        "cli_command": "claude",
        "install_hint": "https://claude.com/code",
        "install_cmd": "npm install -g @anthropic-ai/claude-code",
    },
    EngineKind.CODEX_CLI.value: {
        "short_name": "codex",
        "display_name": "OpenAI Codex",
        "cli_command": "codex",
        "install_hint": "https://github.com/openai/codex",
        "install_cmd": "npm install -g @openai/codex",
    },
    EngineKind.ANTIGRAVITY_CLI.value: {
        "short_name": "antigravity",
        "display_name": "Google Antigravity",
        "cli_command": "antigravity",
        "install_hint": "npm install -g @google/antigravity-cli",
        "install_cmd": "npm install -g @google/antigravity-cli",
    },
    # Cursor is a built-in ACP agent (engine "cursor_acp" →
    # CursorAcpEngine, a thin subclass of the generic AcpEngine). It IS
    # keyed here so it auto-scaffolds. *Generic* ACP agents (engine
    # "acp") are NOT keyed — they're configured per-agent via
    # ``acp_command`` in config.json and need no scaffold template.
    EngineKind.CURSOR_ACP.value: {
        "short_name": "cursor",
        "display_name": "Cursor",
        # Availability probe binary; the engine runs `cursor-agent acp`.
        "cli_command": "cursor-agent",
        "install_hint": "curl https://cursor.com/install -fsS | bash  (then: cursor-agent login)",
        "install_cmd": "curl https://cursor.com/install -fsS | bash",
    },
}

# Order the detect/setup flow walks the external agents in.
EXTERNAL_AGENT_KINDS: tuple[str, ...] = (
    EngineKind.CLAUDE_CLI.value,
    EngineKind.CODEX_CLI.value,
    EngineKind.CURSOR_ACP.value,
    EngineKind.ANTIGRAVITY_CLI.value,
)


def detect_external_agents() -> list[dict]:
    """Status of each known external coding-agent integration: whether its CLI
    is installed (on PATH) and whether the rtxclaw agent is configured on disk.

    Powers ``rtxclaw agents`` (detect + quick-install + configure). The
    ``cli_command`` is the availability probe; ``install_cmd`` is a runnable
    one-liner; ``install_hint`` is the human pointer."""
    import shutil
    from rtxclaw_core.agent import agents_root

    root = agents_root()
    rows: list[dict] = []
    for kind in EXTERNAL_AGENT_KINDS:
        d = _KIND_DETAILS[kind]
        short = d["short_name"]
        rows.append({
            "kind": kind,
            "short_name": short,
            "display_name": d["display_name"],
            "cli_command": d["cli_command"],
            "installed": shutil.which(d["cli_command"]) is not None,
            "configured": (root / short / "config.json").exists(),
            "install_cmd": d.get("install_cmd", ""),
            "install_hint": d.get("install_hint", ""),
        })
    return rows


def short_name_for(engine_kind: str) -> str:
    """``"claude_cli"`` → ``"claude"``. Raises for unknown kinds."""
    details = _KIND_DETAILS.get(engine_kind)
    if details is None:
        raise ValueError(f"unknown engine kind: {engine_kind!r}")
    return details["short_name"]


# =====================================================================
# config.json
# =====================================================================


def config_for(engine_kind: str) -> dict[str, Any]:
    """Default ``config.json`` payload for a built-in external-engine agent.

    CLI engines leave the upstream/sampling/compaction fields empty —
    they are inert on CLI engines and the engine subclass ignores them.
    The ``heartbeat`` is disabled by default; the operator opts in by
    setting ``heartbeat_enabled: true``.
    """
    details = _KIND_DETAILS.get(engine_kind)
    if details is None:
        raise ValueError(f"unknown engine kind: {engine_kind!r}")
    return {
        "name": details["short_name"],
        "engine": engine_kind,
        "description": (
            f"{details['display_name']} CLI as the turn-dispatch engine. "
            "Edit SOUL.md / AGENTS.md / TOOLS.md to customize the agent's "
            "context; those files are passed to the CLI via "
            "--append-system-prompt (Claude) or first-message injection "
            "(Codex / Gemini) on the first call of each session."
        ),
        "permission_mode": "auto",
        "heartbeat_enabled": False,
        # No port; CLI-engine agents are still served through the
        # gateway under /acp/<name>, but they don't open their own
        # HTTP listener. Setting a port here would be misleading.
        "port": 0,
        "host": "127.0.0.1",
    }


# =====================================================================
# SOUL.md — agent's role / personality
# =====================================================================


_SOUL_TEMPLATE_CLAUDE = """\
# SOUL — Claude as a rtxclaw agent

You are Claude (via the `claude-code` CLI), the turn-dispatch engine
for this rtxclaw agent. The user is interacting with you through
rtxclaw's frontends (TUI / Telegram / OpenAI-compat endpoint), which
route every prompt for this agent to a long-lived `claude --resume`
session.

The rtxclaw side composes the conversation context (this file plus
`AGENTS.md` / `TOOLS.md` / `USER.md` / `MEMORY.md`) and primes you
with it via `--append-system-prompt` on the first call of each
session. On follow-up turns the same `claude --resume <session_id>`
process is reused, so you already have the full prior exchange — do
NOT restate prior turns.

Behave per your own training. Lean into:
- code-heavy multi-file refactors
- design review and second-opinion analysis
- planning long-running tasks with `TodoWrite`

Operators are expected to overwrite this file with their own persona
before relying on the agent in production. The template here is a
baseline.
"""

_SOUL_TEMPLATE_CODEX = """\
# SOUL — Codex as a rtxclaw agent

You are OpenAI Codex (via the `codex exec` CLI), the turn-dispatch
engine for this rtxclaw agent. Every prompt for this agent routes
through `codex exec resume <thread_id>` so the conversation thread
persists across rtxclaw turns.

Behave per your own training. Lean into:
- shell-driven workflows (`bash` is your default tool)
- tight feedback loops on real systems
- pragmatic patches via `apply_patch`

Operators are expected to overwrite this file with their own persona
before relying on the agent in production.
"""

_SOUL_TEMPLATE_ANTIGRAVITY = """\
# SOUL — Antigravity as a rtxclaw agent

You are Google Antigravity (via the `antigravity` CLI), the turn-dispatch
engine for this rtxclaw agent. Every prompt for this agent routes
through `antigravity --resume <session_id>` so the session persists across
rtxclaw turns.

Behave per your own training. Lean into:
- long-context summarisation (>1M token windows)
- multimodal reasoning (images, audio, video)
- second-opinion analysis alongside Claude / Codex

Operators are expected to overwrite this file with their own persona
before relying on the agent in production.
"""

_SOUL_TEMPLATE_CURSOR = """\
# SOUL — Cursor as a rtxclaw agent

You are Cursor (via `cursor-agent acp`, Cursor's first-party Agent
Client Protocol server), the turn-dispatch engine for this rtxclaw
agent. rtxclaw drives you as an ACP client over newline-delimited
JSON-RPC stdio; each rtxclaw turn becomes a `session/prompt`, and the
ACP session persists across turns (rtxclaw stores your `sessionId` and
re-attaches via `session/load`).

Behave per your own training. Lean into:
- deep codebase understanding and semantic search
- multi-file refactoring and edits
- access to Cursor's model roster (Composer, GPT-5.x, Codex, Claude)

Operators are expected to overwrite this file with their own persona
before relying on the agent in production.
"""


def soul_for(engine_kind: str) -> str:
    """Default ``SOUL.md`` content for a built-in CLI-engine agent."""
    return {
        EngineKind.CLAUDE_CLI.value: _SOUL_TEMPLATE_CLAUDE,
        EngineKind.CODEX_CLI.value: _SOUL_TEMPLATE_CODEX,
        EngineKind.ANTIGRAVITY_CLI.value: _SOUL_TEMPLATE_ANTIGRAVITY,
        EngineKind.CURSOR_ACP.value: _SOUL_TEMPLATE_CURSOR,
    }[engine_kind]


# =====================================================================
# AGENTS.md — who else is around
# =====================================================================


_AGENTS_TEMPLATE = """\
# AGENTS — sibling rtxclaw agents

You can delegate one task to a sibling rtxclaw agent via the
`delegate_agent` tool. Sibling agents live under
`~/.rtxclaw/agents/<name>/` and each has its own SOUL/AGENTS/TOOLS
configuration. Run `/agents` in the TUI or Telegram to list them.

Some sibling agents are themselves CLI-engine-backed (like you);
others are local-LLM-backed. The protocol is the same in either
case — your `delegate_agent` call's reply is the target's full
turn output.

Use `delegate_agent` sparingly: it adds a network round-trip and
the target gets a fresh context per call (the sidecar resume is
per-rtxclaw-session, not per-target-session). For most tasks,
answering directly is faster.
"""


def agents_md_for(engine_kind: str) -> str:
    """Default ``AGENTS.md`` content. Same for every external-engine kind."""
    if engine_kind not in _KIND_DETAILS:
        raise ValueError(f"unknown engine kind: {engine_kind!r}")
    return _AGENTS_TEMPLATE


# =====================================================================
# TOOLS.md — what tools the engine can call
# =====================================================================


_TOOLS_TEMPLATE_CLAUDE = """\
# TOOLS — what Claude has access to

You have Claude Code's full built-in toolset: `Read`, `Write`, `Edit`,
`MultiEdit`, `NotebookEdit`, `Bash`, `BashOutput`, `KillBash`,
`Glob`, `Grep`, `WebFetch`, `WebSearch`, `TodoWrite`, `Task`,
plus any MCP servers configured in your `~/.claude/settings.json`.

rtxclaw's permission mode maps to `--permission-mode`:

| rtxclaw mode | claude flag         | meaning                          |
|---|---|---|
| `plan`       | `plan`              | read-only research, no edits     |
| `ask`        | `default`           | prompt before edits              |
| `auto`       | `bypassPermissions` | full bypass (headless contract)  |

The current mode is visible in your environment; treat `auto` as
operator-approved autonomous execution.
"""

_TOOLS_TEMPLATE_CODEX = """\
# TOOLS — what Codex has access to

You have Codex's built-in toolset: `local_shell`, `apply_patch`,
`web_search`, `file_search`, plus any MCP servers configured.

rtxclaw's permission mode maps to Codex flags:

| rtxclaw mode | codex flags                                          |
|---|---|
| `plan`       | `sandbox_mode=read-only`, `approval_policy=never`    |
| `ask`        | `sandbox_mode=workspace-write`, `approval_policy=on-request` |
| `auto`       | `--dangerously-bypass-approvals-and-sandbox`         |
"""

_TOOLS_TEMPLATE_ANTIGRAVITY = """\
# TOOLS — what Antigravity has access to

You have Antigravity CLI's built-in toolset: shell, file operations, web
search, plus any MCP servers configured.

rtxclaw's permission mode maps to `--approval-mode`:

| rtxclaw mode | antigravity flag    |
|---|---|
| `plan`       | `plan`         |
| `ask`        | `default`      |
| `auto`       | `yolo`         |
"""

_TOOLS_TEMPLATE_CURSOR = """\
# TOOLS — what Cursor has access to

You run as `cursor-agent acp` (Cursor's ACP server). rtxclaw drives you
as an ACP client and you use Cursor's own built-in agent toolset: file
read / write / edit, shell, codebase semantic search, plus any MCP
servers configured in Cursor.

rtxclaw's permission mode maps onto the ACP session:

| rtxclaw mode | ACP session mode | tool-permission requests |
|---|---|---|
| `plan`       | `plan` (read-only) | rejected                 |
| `ask`        | `ask`              | allowed once *(interactive operator bridge is a follow-up)* |
| `auto`       | (default)          | allowed                  |

Tool-permission requests arrive over `session/request_permission` and
are answered by the engine per the mode above; Cursor's own sandbox
still applies.
"""


def tools_md_for(engine_kind: str) -> str:
    """Default ``TOOLS.md`` content."""
    return {
        EngineKind.CLAUDE_CLI.value: _TOOLS_TEMPLATE_CLAUDE,
        EngineKind.CODEX_CLI.value: _TOOLS_TEMPLATE_CODEX,
        EngineKind.ANTIGRAVITY_CLI.value: _TOOLS_TEMPLATE_ANTIGRAVITY,
        EngineKind.CURSOR_ACP.value: _TOOLS_TEMPLATE_CURSOR,
    }[engine_kind]


# =====================================================================
# Scaffold writer
# =====================================================================


def write_scaffold(home: Path, engine_kind: str) -> list[str]:
    """Write all default files into ``home``.

    Idempotent: if a file already exists, it is NOT overwritten. The
    function logs structured ``AGENT_SCAFFOLD_WRITTEN`` events for each
    file actually created and returns the list of file names that
    landed (relative to ``home``).
    """
    if engine_kind not in _KIND_DETAILS:
        raise ValueError(f"unknown engine kind: {engine_kind!r}")
    home = Path(home)
    home.mkdir(parents=True, exist_ok=True)
    (home / "sessions").mkdir(parents=True, exist_ok=True)
    (home / "logs").mkdir(parents=True, exist_ok=True)

    files: list[tuple[str, str]] = [
        ("config.json", json.dumps(config_for(engine_kind), indent=2) + "\n"),
        ("SOUL.md", soul_for(engine_kind)),
        ("AGENTS.md", agents_md_for(engine_kind)),
        ("TOOLS.md", tools_md_for(engine_kind)),
        ("USER.md", ""),
        ("MEMORY.md", ""),
        ("HEARTBEAT.md", ""),
    ]
    written: list[str] = []
    for name, body in files:
        path = home / name
        if path.exists():
            continue
        path.write_text(body, encoding="utf-8")
        written.append(name)
        _LOG.info(
            "AGENT_SCAFFOLD_WRITTEN engine=%s home=%s file=%s",
            engine_kind, home, name,
        )
    return written
