"""``CodexCliEngine`` — wraps the ``codex exec`` CLI.

Class-shape facade. :meth:`delegate_runner` returns
``runners.run_delegate_codex_async``; the
:class:`ExternalCliEngine.run_turn` driver translates that runner's
``on_delta`` callbacks into :data:`AgentTurnEvent` instances. The
CLI subprocess pipeline (``codex exec resume``, ``-c`` permission
flags, ``thread.started`` parsing, ``-c sandbox_mode=…`` overrides)
lives in the legacy runner.
"""

from __future__ import annotations

from typing import Any

from .engine import EngineKind
from .external_cli import ExternalCliEngine


class CodexCliEngine(ExternalCliEngine):
    """Run a turn through ``codex exec --json``."""

    kind = EngineKind.CODEX_CLI
    cli_command = "codex"
    install_url = "https://github.com/openai/codex"

    @property
    def name(self) -> str:
        return "codex"

    def delegate_runner(self) -> Any:
        """Return ``runners.run_delegate_codex_async``.

        :meth:`ExternalCliEngine.run_turn` awaits the returned helper
        with ``on_delta`` wired to the AgentTurnEvent translator.
        Codex doesn't surface structured ``on_event`` blocks today;
        :meth:`supports_on_event` returns False.
        """
        from rtxclaw_core.tools.runners import run_delegate_codex_async
        return run_delegate_codex_async

    def supports_on_event(self) -> bool:
        # Surface Codex's inner ``command_execution`` items as
        # structured ``tool_use`` / ``tool_result`` events (matching
        # :class:`ClaudeCliEngine`) so the frontend's ``/tools`` gate can
        # suppress them. Without this, the legacy runner inlines the
        # ``🔧 bash …`` markers into the reply body via ``on_delta``
        # (runners.py ``_push_marker``) — and that body ALWAYS renders
        # for the direct-dispatch delegate output, so codex tool calls
        # leaked into the chat even with ``/tools off``.
        return True

    def resume_footer(self) -> str:
        """``[codex resume note: …]`` footer block."""
        return (
            "\n\n[codex resume note: Codex now has this exchange. On your "
            "next delegate_codex call in this rtxclaw session, only forward "
            "context that is NEW since this point — do not restate this "
            "reply or anything earlier.]"
        )
