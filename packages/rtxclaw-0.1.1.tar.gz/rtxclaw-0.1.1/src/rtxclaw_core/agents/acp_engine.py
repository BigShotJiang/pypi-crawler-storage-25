"""``AcpEngine`` — drive ANY ACP server as an ACP client.

ACP (the Agent Client Protocol) is a *generic* protocol, so this engine
is too: it spawns an arbitrary ACP server (configured per-agent) and
drives it over newline-delimited JSON-RPC stdio via
:mod:`rtxclaw_acp.client`. Cursor's first-party ``cursor-agent acp`` is
just one configuration; Gemini, Zed agents, or any other ACP server work
the same way.

Per-agent config (``~/.rtxclaw/agents/<name>/config.json``)::

    {
      "engine": "acp",
      "acp_command": ["cursor-agent", "acp"],   # the ACP server argv
      "acp_name": "cursor",                       # short label (logs/footer)
      "acp_auth_method": "cursor_login",          # authenticate methodId (optional)
      "acp_model": "composer-2.5"                 # idle footer label (optional)
    }

Unlike the ``*_CLI`` engines (claude/codex/antigravity) which shell out
to each tool's native print mode, this one talks ACP. The turn flow:
spawn → initialize → (authenticate) → session/new|load → session/prompt,
translating ``session/update`` notifications into :data:`AgentTurnEvent`.
The model is read from the ACP ``session/new`` response
(``models.currentModelId``) so the TUI footer reflects the real upstream
model for any agent — falling back to the configured ``acp_model``.
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncIterator, Awaitable, Callable, Optional

from .engine import (
    AgentTurnEvent,
    Engine,
    EngineKind,
    EngineSessionState,
    TextDelta,
    ToolCallResult,
    ToolCallStarted,
    TurnDone,
    TurnError,
    TurnRequest,
    TurnStarted,
)

logger = logging.getLogger(__name__)

# JSON-RPC error code an ACP server returns when the client must
# authenticate first. Mirrors jsonrpc.JsonRpcErrorCode.AUTH_REQUIRED.
_AUTH_REQUIRED = -32000

SpawnFn = Callable[..., Awaitable[tuple[Any, Any]]]


async def _default_spawn(cmd: list[str], *, cwd: Optional[str], env: Optional[dict[str, str]]):
    from rtxclaw_acp.client import spawn_stdio_agent

    return await spawn_stdio_agent(
        cmd, cwd=cwd, env=env,
        client_info={"name": "rtxclaw", "version": "1.0.0"},
        return_process=True,
    )


@dataclass(slots=True)
class _LiveTurn:
    client: Any
    proc: Any
    session_id: str = ""


def _read_acp_config(cfg: Any) -> dict[str, Any]:
    """Read the ``acp_*`` settings from the agent's ``config.json``.

    Kept out of :class:`AgentConfig` (which is a fixed dataclass that
    drops unknown keys) so adding a new ACP agent needs no schema change
    — the engine reads its own config from the agent home directory.
    """
    out: dict[str, Any] = {
        "command": [], "name": "", "auth_method": "", "model": "", "context_window": 0,
    }
    home = getattr(cfg, "home", None)
    if home is None and cfg is not None:
        try:
            from rtxclaw_core.agent import agents_root
            home = agents_root() / getattr(cfg, "name", "")
        except Exception:  # noqa: BLE001
            home = None
    if home is None:
        return out
    try:
        data = json.loads((Path(home) / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    if not isinstance(data, dict):
        return out
    cmd = data.get("acp_command")
    if isinstance(cmd, list):
        out["command"] = [str(x) for x in cmd]
    elif isinstance(cmd, str) and cmd.strip():
        out["command"] = cmd.split()
    out["name"] = str(data.get("acp_name") or "")
    out["auth_method"] = str(data.get("acp_auth_method") or "")
    out["model"] = str(data.get("acp_model") or "")
    try:
        out["context_window"] = int(data.get("acp_context_window") or 0)
    except (TypeError, ValueError):
        out["context_window"] = 0
    return out


def _parse_model_context(model_id: str) -> int:
    """Extract a context window from an ACP model id that encodes it.

    Cursor encodes it for some models, e.g. ``gpt-5.5[context=272k]`` →
    272000, ``claude-opus-4-7[...context=300k...]`` → 300000. Returns 0
    when absent (e.g. ``composer-2.5[fast=true]`` has no context field)."""
    import re

    m = re.search(r"context=(\d+)(k?)", model_id or "")
    if not m:
        return 0
    n = int(m.group(1))
    return n * 1000 if m.group(2) else n


class AcpEngine(Engine):
    """Run a turn by driving a configured ACP server as an ACP client."""

    kind = EngineKind.ACP
    install_url = "https://agentclientprotocol.com"

    def __init__(
        self,
        cfg: Any = None,
        *,
        command: Optional[list[str]] = None,
        name: Optional[str] = None,
        auth_method: Optional[str] = None,
        model: Optional[str] = None,
        spawn_fn: Optional[SpawnFn] = None,
    ) -> None:
        acp = _read_acp_config(cfg)
        self._command: list[str] = list(command or acp["command"])
        self._name: str = name or acp["name"] or "acp"
        self._auth_method: str = auth_method or acp["auth_method"] or ""
        self._model: str = model or acp["model"] or ""
        self._config_window: int = int(acp["context_window"] or 0)
        self._spawn: SpawnFn = spawn_fn or _default_spawn
        self._session_locks: dict[str, asyncio.Lock] = {}
        self._active: dict[str, _LiveTurn] = {}
        # Most recent model the ACP server reported (session/new). Cached
        # so the footer reflects the real model after the first turn.
        self._cached_model: str = ""
        # Context window parsed from the model id Cursor reports
        # (``...[context=272k]``); 0 when the model doesn't encode it.
        self._cached_context_window: int = 0
        # Per-session running char count for a context-size ESTIMATE.
        # ACP servers (Cursor included) don't report token usage on the
        # wire, and the conversation history lives server-side where the
        # client can't see it — so we accumulate the chars we send + the
        # chars we receive each turn and convert to an approximate token
        # count for the TUI's ``ctx`` meter (flagged estimated).
        self._ctx_chars: dict[str, int] = {}

    @property
    def name(self) -> str:
        return self._name

    # ---- agent-specific hooks (overridden by subclasses) ------------

    def _acp_mode(self, mode: str) -> str:
        """Map rtxclaw's permission mode (auto/plan/ask) onto the ACP
        server's ``session/set_mode`` id. The base passes it through;
        subclasses remap for agents whose mode ids differ (e.g. Cursor
        uses ``agent``/``plan``/``ask``, so ``auto`` → ``agent``)."""
        return mode

    def _clean_model_label(self, label: str) -> str:
        """Normalize the model label for display. Base is a no-op;
        subclasses strip vendor-specific encodings (e.g. Cursor's
        ``composer-2.5[fast=true]`` suffix)."""
        return label

    def display_model(self) -> str:
        # Prefer the model the ACP server actually reported; fall back to
        # the configured label, then the engine name. Generic — any ACP
        # agent that reports ``models.currentModelId`` gets a live label.
        return self._cached_model or self._model or self._name

    def context_window(self) -> int:
        """Best-known context window (denominator of the ctx meter).

        Prefers the window parsed from the model id Cursor reports
        (``...[context=272k]``), then the configured ``acp_context_window``.
        0 means "unknown" — the agent layer falls back to the global
        default. Subclasses set a sensible per-agent default (Cursor's
        composer doesn't advertise a window, so it returns 200000)."""
        return self._cached_context_window or self._config_window or 0

    # ---- session sidecar I/O ----------------------------------------

    def state_path(self, sessions_dir: Path, rtxclaw_sid: str) -> Path:
        return Path(sessions_dir) / f"{rtxclaw_sid}.{self.kind.value}.json"

    def read_state(self, sessions_dir: Path, rtxclaw_sid: str) -> EngineSessionState:
        state = EngineSessionState(rtxclaw_session_id=rtxclaw_sid, engine=self.kind)
        path = self.state_path(Path(sessions_dir), rtxclaw_sid)
        if not path.exists():
            # Migrate the pre-generic ``cursor_acp`` sidecar name.
            legacy = Path(sessions_dir) / f"{rtxclaw_sid}.cursor_acp.json"
            path = legacy if legacy.exists() else path
        if not path.exists():
            return state
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return state
        if not isinstance(data, dict):
            return state
        eid = data.get("engine_session_id") or data.get("cursor_session_id") or ""
        state.engine_session_id = str(eid or "")
        state.priming_status = str(data.get("priming_status") or ("completed" if eid else "never"))
        state.priming_system_prompt_sha256 = str(data.get("priming_system_prompt_sha256") or "")
        state.last_used_at = str(data.get("last_used_at") or "")
        state.last_error = str(data.get("last_error") or "")
        state.spawn_cwd = str(data.get("spawn_cwd") or "")
        return state

    def write_state(self, sessions_dir: Path, state: EngineSessionState) -> None:
        path = self.state_path(Path(sessions_dir), state.rtxclaw_session_id)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                json.dumps(
                    {
                        "rtxclaw_session_id": state.rtxclaw_session_id,
                        "engine": state.engine.value,
                        "engine_session_id": state.engine_session_id,
                        "priming_status": state.priming_status,
                        "priming_system_prompt_sha256": state.priming_system_prompt_sha256,
                        "last_used_at": state.last_used_at,
                        "last_error": state.last_error,
                        "spawn_cwd": state.spawn_cwd,
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except OSError:
            logger.debug("acp write_state failed for %s", path, exc_info=True)

    # ---- introspection ----------------------------------------------

    def _resolved_cli(self) -> Optional[str]:
        """Resolve the ACP server binary (``acp_command[0]``).

        Prefer PATH; fall back to ``~/.local/bin`` so the engine works
        when the gateway was started without ``~/.local/bin`` on PATH."""
        import os

        if not self._command:
            return None
        exe = self._command[0]
        found = shutil.which(exe)
        if found:
            return found
        cand = os.path.expanduser(f"~/.local/bin/{exe}")
        return cand if os.path.exists(cand) else None

    def is_available(self) -> tuple[bool, str]:
        if not self._command:
            return (False, "no acp_command configured for this ACP agent")
        if self._resolved_cli() is None:
            return (
                False,
                f"`{self._command[0]}` (acp_command) not found on PATH or "
                f"~/.local/bin. See {self.install_url}.",
            )
        return (True, "")

    # ---- system-prompt policy ---------------------------------------

    def system_prompt_policy(
        self, state: EngineSessionState, *, current_system_prompt_sha256: str
    ) -> str:
        if state.priming_status in {"never", "in_progress", "failed"}:
            return "first_turn"
        if (
            current_system_prompt_sha256
            and state.priming_system_prompt_sha256 != current_system_prompt_sha256
        ):
            return "sha_changed"
        return "never"

    # ---- abort ------------------------------------------------------

    async def abort(self, turn_id: str, *, force: bool = False) -> None:
        live = self._active.get(turn_id)
        if live is None:
            return
        if live.session_id:
            try:
                await live.client.session_cancel(live.session_id, force=force)
            except Exception:  # noqa: BLE001
                logger.debug("acp session_cancel failed", exc_info=True)
        _kill_proc(live.proc, force=force)

    # ---- turn dispatch ----------------------------------------------

    async def run_turn(
        self,
        request: TurnRequest,
        state: EngineSessionState,
        *,
        sessions_dir: Path,
        turn_id: str,
        env: Optional[dict[str, str]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        yield TurnStarted(
            turn_id=turn_id,
            rtxclaw_session_id=state.rtxclaw_session_id,
            engine_session_id=state.engine_session_id,
            resumed=bool(state.engine_session_id),
        )

        if not self._command:
            yield TurnError(message="no acp_command configured", classification="config")
            yield TurnDone(state="error", engine_session_id=state.engine_session_id)
            return

        cwd = request.cwd or state.spawn_cwd or None
        cmd = [self._resolved_cli() or self._command[0], *self._command[1:]]
        try:
            client, proc = await self._spawn(cmd, cwd=cwd, env=env)
        except FileNotFoundError:
            yield TurnError(
                message=f"`{self._command[0]}` not on PATH ({self.install_url})",
                classification="spawn_failed",
            )
            yield TurnDone(state="error", engine_session_id=state.engine_session_id)
            return

        live = _LiveTurn(client=client, proc=proc, session_id=state.engine_session_id)
        self._active[turn_id] = live
        client.register_request_permission(_make_permission_handler(request.mode))

        try:
            init = await client.initialize()
            policy = self.system_prompt_policy(
                state, current_system_prompt_sha256=request.system_prompt_sha256
            )
            session_id = await self._open_session(client, init, state, policy, cwd)
            live.session_id = session_id
            self._capture_model(client)

            state.engine_session_id = session_id
            state.priming_status = "in_progress"
            state.spawn_cwd = cwd or ""
            self.write_state(sessions_dir, state)

            if request.mode:
                try:
                    await client.session_set_mode(session_id, self._acp_mode(request.mode))
                except Exception:  # noqa: BLE001
                    logger.debug("acp set_mode failed", exc_info=True)

            blocks = _build_prompt_blocks(request, policy)
            sent_chars = sum(
                len(b.get("text", "")) for b in blocks if isinstance(b, dict)
            )
            recv_chars = 0
            real_used: Optional[int] = None
            real_size: Optional[int] = None
            stop_reason = "end_turn"
            async for item in client.session_prompt(session_id, blocks):
                update = getattr(item, "update", None)
                if update is not None:
                    d = _as_dict(update)
                    if d.get("sessionUpdate") == "usage_update":
                        # REAL context usage the agent reported (ACP
                        # session-usage RFD: used/size). Cursor doesn't
                        # send this yet, but we honour it the moment it does.
                        u, s = d.get("used"), d.get("size")
                        if isinstance(u, (int, float)):
                            real_used = int(u)
                        if isinstance(s, (int, float)):
                            real_size = int(s)
                        continue
                    for ev in _translate_update(update):
                        if isinstance(ev, TextDelta) and ev.channel in ("content", "thinking"):
                            recv_chars += len(ev.text)
                        yield ev
                else:
                    stop_reason = getattr(item, "stop_reason", None) or "end_turn"
                    # PromptResponse.usage (RFD): real per-turn tokens.
                    usage = getattr(item, "usage", None)
                    if usage is not None and real_used is None:
                        ud = _as_dict(usage)
                        tot = ud.get("input_tokens") or ud.get("total_tokens")
                        if isinstance(tot, (int, float)):
                            real_used = int(tot)

            state.priming_status = "completed"
            state.priming_system_prompt_sha256 = request.system_prompt_sha256
            state.last_used_at = _now_iso()
            state.last_error = ""
            self.write_state(sessions_dir, state)
            yield TurnDone(
                state="ok",
                engine_session_id=session_id,
                metrics=self._turn_metrics(
                    state.rtxclaw_session_id, sent_chars, recv_chars, stop_reason,
                    real_used=real_used, real_size=real_size,
                ),
            )
        except asyncio.CancelledError:
            if live.session_id:
                try:
                    await client.session_cancel(live.session_id, force=True)
                except Exception:  # noqa: BLE001
                    pass
            yield TurnDone(state="aborted", engine_session_id=state.engine_session_id)
            return
        except Exception as exc:  # noqa: BLE001 - turn boundary
            if state.engine_session_id:
                state.priming_status = "failed"
                state.last_error = f"{exc.__class__.__name__}: {exc}"
                self.write_state(sessions_dir, state)
            yield TurnError(message=str(exc), classification=exc.__class__.__name__)
            yield TurnDone(state="error", engine_session_id=state.engine_session_id)
        finally:
            self._active.pop(turn_id, None)
            try:
                await client.close()
            except Exception:  # noqa: BLE001
                pass
            await _reap_proc(proc)

    # ---- helpers ----------------------------------------------------

    def _turn_metrics(
        self,
        sid: str,
        sent_chars: int,
        recv_chars: int,
        stop_reason: str,
        *,
        real_used: Optional[int] = None,
        real_size: Optional[int] = None,
    ) -> dict[str, Any]:
        """TurnDone metrics with the best-available context size.

        Prefers REAL usage the ACP server reported this turn via a
        ``usage_update`` notification or ``PromptResponse.usage`` (per the
        ACP session-usage RFD). When the agent reports nothing (Cursor
        today), fall back to an ESTIMATE: the running total of chars
        sent + received this session converted to tokens
        (``tokens_estimated=True`` → the TUI shows ``ctx`` with ``≈``).
        The estimate is a lower bound — it can't see the agent's
        server-side system prompt / codebase index / command list."""
        from rtxclaw_core.context_report import estimate_tokens_from_chars

        if real_used is not None:
            used = int(real_used)
            estimated = False
        else:
            total = self._ctx_chars.get(sid, 0) + max(sent_chars, 0) + max(recv_chars, 0)
            self._ctx_chars[sid] = total
            used = estimate_tokens_from_chars(total)
            estimated = True
        window = int(real_size or self.context_window() or 0)
        metrics: dict[str, Any] = {
            "stop_reason": stop_reason,
            "model": self._cached_model or self._model,
            "prompt_tokens": used,
            "completion_tokens": estimate_tokens_from_chars(recv_chars),
            "tokens_estimated": estimated,
        }
        if window:
            metrics["context_window"] = window
        return metrics

    def _capture_model(self, client: Any) -> None:
        """Cache the model the ACP server reported in session/new/load.

        Reads ``models.currentModelId`` and resolves its display name via
        ``availableModels`` so the footer shows e.g. ``composer-2.5``."""
        models = getattr(client, "last_session_models", None)
        if not isinstance(models, dict):
            return
        current = models.get("currentModelId")
        if not isinstance(current, str) or not current:
            return
        # Cursor encodes the window in some model ids (gpt/claude/grok);
        # composer omits it (stays 0 → subclass default applies).
        win = _parse_model_context(current)
        if win:
            self._cached_context_window = win
        label = current
        for m in models.get("availableModels") or []:
            if isinstance(m, dict) and m.get("modelId") == current:
                nm = m.get("name")
                if isinstance(nm, str) and nm:
                    label = nm
                break
        self._cached_model = self._clean_model_label(label)

    async def _open_session(
        self, client: Any, init: Any, state: EngineSessionState, policy: str, cwd: Optional[str]
    ) -> str:
        load_cwd = cwd or "."
        can_load = bool(state.engine_session_id) and policy == "never" and _supports_load(init)
        if can_load:
            try:
                await client.session_load(state.engine_session_id, cwd=load_cwd)
                return state.engine_session_id
            except Exception as exc:  # noqa: BLE001
                # Authenticate and retry the LOAD before abandoning the
                # saved session — otherwise an auth-required resume falls
                # through to session/new and silently drops conversation
                # continuity on every turn after the first.
                if _is_auth_required(exc) and self._auth_method:
                    try:
                        await client.authenticate(self._auth_method)
                        await client.session_load(state.engine_session_id, cwd=load_cwd)
                        return state.engine_session_id
                    except Exception:  # noqa: BLE001
                        logger.debug(
                            "acp session_load retry after auth failed; opening new",
                            exc_info=True,
                        )
                else:
                    logger.debug("acp session_load failed; opening new", exc_info=True)
        return await self._new_session_with_auth(client, load_cwd)

    async def _new_session_with_auth(self, client: Any, cwd: str) -> str:
        try:
            return await client.session_new(cwd)
        except Exception as exc:  # noqa: BLE001
            if _is_auth_required(exc) and self._auth_method:
                await client.authenticate(self._auth_method)
                return await client.session_new(cwd)
            raise


# =====================================================================
# Module-level helpers (pure → unit-testable without a live client).
# =====================================================================


def _build_prompt_blocks(request: TurnRequest, policy: str) -> list[dict[str, Any]]:
    """Compose the ACP prompt content blocks for this turn.

    ACP has no separate system-prompt channel, so on priming turns
    (``first_turn`` / ``sha_changed``) we fold the composed system prompt
    AND the below-cache-boundary ``preamble`` blocks (pinned facts,
    compaction summary, todos, memory recall, skills) into a leading
    ``<system>`` block — the same content CLI engines bake into their
    first-message priming (see ``external_cli`` preamble folding)."""
    text = request.prompt or ""
    if policy in {"first_turn", "sha_changed"}:
        sys_parts: list[str] = []
        if request.system_prompt:
            sys_parts.append(request.system_prompt)
        for block in request.preamble or []:
            content = str(block.get("content") or "") if isinstance(block, dict) else ""
            if content:
                sys_parts.append(content)
        if sys_parts:
            sys_text = "\n\n".join(sys_parts)
            text = f"<system>\n{sys_text}\n</system>\n\n---\n\n{text}"
    return [{"type": "text", "text": text}]


def _translate_update(update: Any) -> list[AgentTurnEvent]:
    d = _as_dict(update)
    kind = d.get("sessionUpdate")
    out: list[AgentTurnEvent] = []
    if kind == "agent_message_chunk":
        text = _text_of(d.get("content"))
        if text:
            out.append(TextDelta(text=text, channel="content"))
    elif kind == "agent_thought_chunk":
        text = _text_of(d.get("content"))
        if text:
            out.append(TextDelta(text=text, channel="thinking"))
    elif kind == "tool_call":
        raw_input = d.get("rawInput")
        out.append(
            ToolCallStarted(
                call_id=str(d.get("toolCallId") or ""),
                name=str(d.get("title") or d.get("kind") or "tool"),
                arguments=raw_input if isinstance(raw_input, dict) else {},
            )
        )
    elif kind == "tool_call_update":
        call_id = str(d.get("toolCallId") or "")
        status = d.get("status")
        if status in ("completed", "failed"):
            out.append(
                ToolCallResult(call_id=call_id, ok=(status == "completed"),
                               content=_text_of(d.get("content")))
            )
        else:
            text = _text_of(d.get("content"))
            if text:
                out.append(TextDelta(text=text, channel="tool_delta", call_id=call_id))
    return out


def _make_permission_handler(mode: str) -> Callable[[dict], Awaitable[dict]]:
    """Map rtxclaw's permission mode onto ACP ``session/request_permission``.

    ``auto`` allows, ``plan`` rejects (plan mode is also set on the
    session). ``ask`` allows-once for now (no interactive operator bridge
    from a client-side ACP permission callback yet; the upstream agent's
    own sandbox still applies)."""

    async def handler(params: dict) -> dict:
        options = params.get("options") or []
        if mode == "plan":
            option_id = _pick_option(options, ("reject_once", "reject_always"))
        elif mode == "auto":
            option_id = _pick_option(options, ("allow_always", "allow_once"))
        else:
            option_id = _pick_option(options, ("allow_once", "allow_always"))
        if option_id is None:
            return {"outcome": {"outcome": "cancelled"}}
        return {"outcome": {"outcome": "selected", "optionId": option_id}}

    return handler


def _pick_option(options: list, kinds: tuple[str, ...]) -> Optional[str]:
    for kind in kinds:
        for opt in options:
            if isinstance(opt, dict) and opt.get("kind") == kind:
                return opt.get("optionId")
    for opt in options:
        if isinstance(opt, dict) and opt.get("optionId"):
            return opt.get("optionId")
    return None


def _text_of(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        if content.get("type") == "text":
            return str(content.get("text") or "")
        inner = content.get("content")
        if inner is not None:
            return _text_of(inner)
        return ""
    if isinstance(content, (list, tuple)):
        return "".join(_text_of(c) for c in content)
    return ""


def _as_dict(update: Any) -> dict[str, Any]:
    if isinstance(update, dict):
        return update
    dump = getattr(update, "model_dump", None)
    if callable(dump):
        try:
            return dump(by_alias=True, exclude_none=True)
        except Exception:  # noqa: BLE001
            pass
    return {}


def _supports_load(init: Any) -> bool:
    caps = getattr(init, "agent_capabilities", None)
    if caps is None and isinstance(init, dict):
        caps = init.get("agentCapabilities") or init.get("agent_capabilities")
    val = getattr(caps, "load_session", None)
    if val is None and isinstance(caps, dict):
        val = caps.get("loadSession") or caps.get("load_session")
    return bool(val)


def _is_auth_required(exc: Exception) -> bool:
    code = getattr(exc, "code", None)
    if code == _AUTH_REQUIRED:
        return True
    s = str(exc).lower()
    return "auth" in s and "requir" in s


def _kill_proc(proc: Any, *, force: bool) -> None:
    if proc is None:
        return
    try:
        if force and hasattr(proc, "kill"):
            proc.kill()
        elif hasattr(proc, "terminate"):
            proc.terminate()
    except (ProcessLookupError, OSError):
        pass


async def _reap_proc(proc: Any) -> None:
    if proc is None:
        return
    _kill_proc(proc, force=False)
    waiter = getattr(proc, "wait", None)
    if not callable(waiter):
        return
    try:
        await asyncio.wait_for(waiter(), timeout=2.0)
    except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
        _kill_proc(proc, force=True)


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


__all__ = ["AcpEngine"]
