"""``AntigravityCliEngine`` — wraps the ``antigravity`` CLI.

Class-shape facade. :meth:`delegate_runner` returns
``runners.run_delegate_antigravity_async``; the
:class:`ExternalCliEngine.run_turn` driver translates that runner's
``on_delta`` callbacks into :data:`AgentTurnEvent` instances. The
CLI subprocess pipeline (``antigravity -p`` first turn / ``--resume``
follow-up, ``--model``, ``--approval-mode``, ``--skip-trust``,
``init`` / ``message`` / ``tool_use`` / ``tool_result`` event
parsing) lives in the legacy runner.
"""

from __future__ import annotations

from typing import Any

from .engine import EngineKind
from .external_cli import ExternalCliEngine


class AntigravityCliEngine(ExternalCliEngine):
    """Run a turn through ``antigravity -p --output-format stream-json``."""

    kind = EngineKind.ANTIGRAVITY_CLI
    cli_command = "antigravity"
    install_url = "https://github.com/google-gemini/antigravity-cli"

    @property
    def name(self) -> str:
        return "antigravity"

    def delegate_runner(self) -> Any:
        """Return ``runners.run_delegate_antigravity_async``.

        :meth:`ExternalCliEngine.run_turn` awaits the returned helper
        with ``on_delta`` wired to the AgentTurnEvent translator.
        """
        from rtxclaw_core.tools.runners import run_delegate_antigravity_async
        return run_delegate_antigravity_async

    def supports_on_event(self) -> bool:
        # Same rationale as :class:`CodexCliEngine`: emit Gemini's inner
        # tool blocks as structured ``tool_use`` / ``tool_result``
        # events so the ``/tools`` gate can suppress them, instead of
        # inlining the markers into the always-rendered delegate body.
        return True

    def resume_footer(self) -> str:
        """``[antigravity --resume note: …]`` footer block."""
        return (
            "\n\n[antigravity --resume note: Antigravity now has this exchange. On your "
            "next delegate_antigravity call in this rtxclaw session, only forward "
            "context that is NEW since this point — do not restate this "
            "reply or anything earlier.]"
        )

ANTIGRAVITY_MODELS = [
    {"alias": "flash", "id": "gemini-3.5-flash", "display": "Gemini 3.5 Flash (default)"},
    {"alias": "pro",   "id": "gemini-3.5-pro",   "display": "Gemini 3.5 Pro"},
    {"alias": "omni",  "id": "gemini-omni",      "display": "Gemini Omni"},
    {"alias": "nano",  "id": "gemini-nano-4",    "display": "Gemini Nano 4 (local)"},
]
