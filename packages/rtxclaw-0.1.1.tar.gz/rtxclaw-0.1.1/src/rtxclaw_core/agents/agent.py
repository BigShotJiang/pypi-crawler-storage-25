"""``Agent`` — the composition root.

One concrete class. Owns the agent's identity (name, home dir, context
files, sessions dir, permission mode, hooks) and a single
:class:`Engine` instance. Replaces the implicit "agent = ``AgentConfig``
+ the runtime around it" pattern.

The :class:`Agent` is what:

* The gateway mounts at ``/acp/<name>`` (one Agent per discovered
  ``~/.rtxclaw/agents/<name>/`` dir).
* ``/agent <name>`` in TUI / Telegram swaps to (today this is a
  rtxclaw-agent-only switch; in the new model it accepts CLI-engine
  agents like ``dashboard_dev`` too).
* The ``delegate_agent`` tool targets when the model wants a sibling
  agent to handle one task — same Agent class, no special "delegate"
  type.

The Agent's responsibilities (orthogonal to engine choice):

1. **System-prompt composition** from on-disk files (SOUL/AGENTS/TOOLS/
   USER/MEMORY/MODE-*.md) — exactly the way
   ``turn_runtime._compose_system_prompt`` does today.
2. **Session lifecycle** under ``<home>/sessions/``.
3. **First-call vs follow-up routing** to the engine: send the
   composed system prompt on the first turn, ``None`` after.
4. **Hook engine** dispatch — pre/post tool, post turn. Sourced from
   ``cfg.hooks_path``; same shape as today's ``HookEngine``.
5. **Memory provider** lifecycle — fact extraction post-turn, recall
   prefetch pre-turn (recall_mode=context/hybrid).
6. **Heartbeat scheduler** — periodic background turns through
   ``engine.run_turn`` against a dedicated heartbeat session.
7. **Pre-compaction memory flush** — when the local-LLM engine is
   about to compact, the Agent runs a silent turn that lets the model
   save context to MEMORY.md first. (CLI engines have their own
   resume so this is a no-op for them.)
8. **Skills auto-invoke** preamble selection (the actual injection
   happens engine-side).
9. **Uniform session-log writing** via :mod:`session_log` so every
   engine produces identically-shaped session JSON for fine-tuning.
10. **Translate Engine events to ACP** (the gateway's wire format).
    A thin shim lives at the Agent level so subclasses don't need to
    know about ACP.

The Agent does NOT know how a turn is executed. That's the engine's
job.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator, Optional

from .engine import AgentTurnEvent, Engine, EngineKind, TurnRequest


def _loads_list(v: Any) -> list:
    """Parse a JSON-array TEXT column (e.g. sessions_meta.pinned_facts)
    into a list; tolerate already-list / null / malformed values."""
    if isinstance(v, list):
        return v
    if not v:
        return []
    try:
        import json as _json
        out = _json.loads(v)
        return out if isinstance(out, list) else []
    except (ValueError, TypeError):
        return []


def agent_session_to_dict(sess: Any) -> dict[str, Any]:
    """Render a :class:`Session` (header + folded turns) to the legacy
    ``<sid>.json``-shaped dict that pre-readers expect."""
    return {
        "hash": getattr(sess, "hash", ""),
        "title": getattr(sess, "title", ""),
        "created_at": getattr(sess, "created_at", ""),
        "system_prompt": getattr(sess, "system_prompt", ""),
        "system_mode": getattr(sess, "system_mode", ""),
        "model": getattr(sess, "model", ""),
        "endpoint": getattr(sess, "endpoint", ""),
        "backend": getattr(sess, "backend", ""),
        "context_window": int(getattr(sess, "context_window", 0) or 0),
        "workspace_cwd": getattr(sess, "workspace_cwd", ""),
        "workspace_origin": getattr(sess, "workspace_origin", ""),
        "agent_name": getattr(sess, "agent_name", ""),
        "engine": getattr(sess, "engine", ""),
        "pinned_facts": list(getattr(sess, "pinned_facts", []) or []),
        "compaction_count": int(getattr(sess, "compaction_count", 0) or 0),
        "compaction_summary": getattr(sess, "compaction_summary", ""),
        "turns": list(getattr(sess, "turns", []) or []),
    }


@dataclass(slots=True)
class Agent:
    """Identity + engine for one rtxclaw agent.

    Built by :func:`factory.load_agent`. The ``cfg`` is the existing
    ``AgentConfig`` (``rtxclaw_core.agent.AgentConfig``) extended with
    one new field, ``engine: str``; ``factory.load_agent`` reads that
    field to pick which :class:`Engine` subclass to instantiate.
    """

    cfg: Any         # rtxclaw_core.agent.AgentConfig
    engine: Engine
    # Optional pre-resolved sibling registry (other agents we know
    # about). Today the bridge derives this lazily from agents_root();
    # making it explicit on the Agent dataclass lets tests inject it.
    siblings: list[str] = field(default_factory=list)
    # Cached, lazily-loaded ``HookEngine`` instance. Populated on
    # first hook fire; reused across the agent's lifetime so a
    # hot path doesn't pay file-IO every turn. ``None`` means
    # uninitialized; an empty :class:`HookEngine` means we've
    # loaded and there are no hooks.
    _hook_engine: Any = None
    # ``CLAUDE_PLUGIN_ROOT`` exported to hook commands — derived from
    # the hooks file location by :meth:`_load_hook_engine`.
    _hook_plugin_root: str = ""
    # Cached embedding-backed skill auto-invoke index — lazily built on
    # the first turn with auto-invoke enabled and reused so we don't
    # re-embed the skill corpus every round. ``None`` = uninitialized.
    # MUST be a declared field: ``Agent`` is ``slots=True``, so an
    # undeclared ``self._skill_index = …`` would raise ``AttributeError``
    # (which the auto-invoke's broad ``except`` would silently swallow,
    # leaving the feature dead).
    _skill_index: Any = None
    # Active heartbeat scheduler (when :meth:`start_heartbeat` is
    # running). Single instance per Agent — re-entrant start is a
    # no-op.
    _heartbeat_scheduler: Any = None
    # Optional ``sid → outbound channel`` resolver installed by the
    # backend layer (CoreBackend / AgentACPBackend). When set,
    # :meth:`resolve_permission` calls it to find the AcpServer that
    # owns the session so ``mode=ask`` permission prompts reach the
    # connection that actually opened the session instead of silently
    # auto-denying. ``None`` for stand-alone Agent callers (tests,
    # delegate-shim child turns) — those paths can't surface a
    # permission prompt anyway.
    _outbound_resolver: Any = None

    # ---- identity passthrough --------------------------------------

    @property
    def name(self) -> str:
        """Agent name. Same as today's ``cfg.name``."""
        return self.cfg.name

    @property
    def home(self) -> Path:
        """``~/.rtxclaw/agents/<name>/`` — same as today's ``cfg.home``."""
        return self.cfg.home

    @property
    def sessions_dir(self) -> Path:
        """``<home>/sessions/`` — same as today's ``cfg.sessions_dir``."""
        return self.cfg.sessions_dir

    @property
    def engine_kind(self) -> EngineKind:
        """The engine's ``kind``. For status displays and routing."""
        return self.engine.kind

    @property
    def permission_mode(self) -> str:
        """Static cfg permission mode — fallback when no session is in
        scope. Per-session ``/mode`` overrides land on
        ``Session.system_mode`` and are picked up by
        :meth:`_effective_mode` below.
        """
        return getattr(self.cfg, "permission_mode", "auto") or "auto"

    def _effective_mode(self, session: Any) -> str:
        """Resolve the permission mode for THIS session.

        Regression guard for the 2026-05-07 bug ("``/mode plan`` was
        purely cosmetic"): :meth:`resolve_permission` previously read
        ``self.permission_mode`` only, ignoring
        ``Session.system_mode`` that the frontend's ``set_mode`` call
        wrote. The bridge stayed in AUTO regardless of what the TUI
        footer said.

        Resolution order:
          1. ``session.system_mode`` if it parses as ``{plan,ask,auto}``
          2. ``cfg.permission_mode`` if set
          3. ``"auto"`` (a corrupted on-disk system_mode never elevates
             the bridge to a weaker mode by accident — falls back to
             auto, never to ``cfg.permission_mode`` here, because a
             bogus value should be loud-ish but not catastrophic).
        """
        # Single source of truth for the valid mode set — the
        # PermissionPolicy constructor raises on anything else.
        # ``VALID_PERMISSION_MODES`` is a public re-export pinned to
        # ``PermissionPolicy._VALID_MODES`` at module scope, so we
        # don't reach into a sibling class's private attribute.
        from .permissions_integration import VALID_PERMISSION_MODES
        sm = str(getattr(session, "system_mode", "") or "").strip().lower()
        if sm in VALID_PERMISSION_MODES:
            return sm
        if sm:
            # Non-empty but bogus → drop straight to auto. See test_35
            # test_effective_mode_falls_back_to_auto_when_session_mode_unrecognised.
            return "auto"
        return self.permission_mode

    # ---- system-prompt composition ---------------------------------

    def compose_system_prompt(
        self,
        *,
        mode: Optional[str] = None,
        workspace_cwd: str = "",
        workspace_origin: str = "",
    ) -> str:
        """Build the system prompt from the agent's home directory.

        Forwards to ``turn_runtime._compose_system_prompt`` (the
        single source of truth — reading SOUL.md / AGENTS.md /
        TOOLS.md / USER.md / MEMORY.md / MODE-*.md, plus the
        skills + MCP + deferred-tools catalogs, with the cache
        boundary inserted before the dynamic ``# WORKSPACE-CONTEXT``
        tail).
        """
        from rtxclaw_core.turn_runtime import _compose_system_prompt

        return _compose_system_prompt(
            self.cfg,
            mode or self.permission_mode,
            workspace_cwd=workspace_cwd,
            workspace_origin=workspace_origin,
        )

    def compose_round_preamble(
        self,
        session: Any,
        user_text: str,
        *,
        suppressed_blocks: Optional[set[str]] = None,
        block_overrides: Optional[dict[str, str]] = None,
    ) -> list[dict[str, Any]]:
        """Build the below-cache-boundary preamble blocks for one round.

        **Single owner of dynamic-context composition** per codex audit
        finding #5. Neither :class:`LocalLLMEngine` nor any
        :class:`ExternalCliEngine` reaches into the agent's .md files
        or the memory provider on its own — they consume what this
        method returns via :attr:`TurnRequest.preamble`.

        Returns the list of (role, content) pairs that go AFTER the
        system prompt but BEFORE the live transcript:

        * Pinned facts block (today's ``_inject_pinned_facts``).
        * Rolling compaction summary (today's
          ``_inject_compaction_summary``).
        * Current-todos block (today's ``_inject_current_todos``).
        * Skill auto-invoke preamble (when
          ``cfg.skill_auto_invoke.enabled`` — ``SkillIndex.search``
          + ``render_preamble``).
        * Memory recall block (when
          ``cfg.memory_recall_mode in {"context", "hybrid"}`` —
          ``memory_manager.prefetch_for_query``).

        Per-engine semantics:

        * Local LLM: this method is invoked once per turn; the engine
          re-splices the same preamble blocks every round within the
          turn (idempotent via stable marker comments).
        * CLI engines: invoked ONCE on the first call of a session;
          the Agent folds the result into the composed system prompt
          sent via ``--append-system-prompt`` (or first-message
          injection). NOT re-invoked on resume — the CLI session has
          a snapshot. If the operator edits a SOUL/AGENTS/TOOLS file
          mid-session, the change won't reach CLI engines until the
          next first-turn (sha mismatch detection via
          :meth:`Engine.system_prompt_policy`).
        """
        # Reuses the legacy injection helpers — calling each in
        # sequence against an empty message list collects the
        # pinned-facts / rolling-summary / current-todos blocks
        # without duplicating the rendering logic. Skills / memory
        # recall integrations are Phase 4 follow-ups; for now we wire
        # only the three high-traffic injections that fire every
        # round today.
        from rtxclaw_core.turn_runtime import (
            _inject_compaction_summary,
            _inject_current_todos,
            _inject_pinned_facts,
        )

        out: list[dict[str, Any]] = []
        # ``suppressed_blocks`` lets a ``PreambleInject`` hook (fired
        # by ``compose_round_preamble_async`` before calling this
        # sync method) opt out of specific built-in injectors;
        # ``block_overrides`` lets a hook substitute the body text
        # (handed in as ``{"kind": "<custom body>"}``).
        suppressed_blocks = suppressed_blocks or set()
        block_overrides = block_overrides or {}

        # Preamble blocks are ALL ``role="user"`` (below the cache
        # boundary, after the single system prompt). A ``role="system"``
        # block here lands after the user-role pinned/summary/todos
        # blocks, and strict chat templates (qwen3.x vLLM on tb08/tb10)
        # reject any system message that isn't first with HTTP 400
        # "System message must be at the beginning" — killing the turn
        # (observed 2026-05-21). The canonical injectors already emit
        # user-role; the hook-override + recall + skill paths below match
        # that so no preamble block is ever system-role.
        pinned = list(getattr(session, "pinned_facts", None) or [])
        if pinned and "pinned_facts" not in suppressed_blocks:
            if "pinned_facts" in block_overrides:
                # Hook supplied a substitute body — render as a single
                # user message (matches the canonical multi-line block).
                out.append({
                    "role": "user",
                    "content": block_overrides["pinned_facts"],
                })
            else:
                out = _inject_pinned_facts(out, [str(x) for x in pinned])

        summary = str(getattr(session, "compaction_summary", "") or "")
        if summary.strip() and "compaction_summary" not in suppressed_blocks:
            if "compaction_summary" in block_overrides:
                out.append({
                    "role": "user",
                    "content": block_overrides["compaction_summary"],
                })
            else:
                out = _inject_compaction_summary(out, summary)

        # Todos — needs the session id + the agent's sessions_dir to
        # locate <sessions_dir>/<sid>.todos.json. Fail-soft on
        # missing/corrupt todos: caller still gets a valid preamble.
        if "current_todos" not in suppressed_blocks:
            try:
                from rtxclaw_core.plan_steps import (
                    load_todos,
                    todos_path_for_session,
                )
                sid = getattr(session, "hash", None)
                if isinstance(sid, str) and sid:
                    todos = load_todos(todos_path_for_session(self.sessions_dir, sid))
                    if "current_todos" in block_overrides:
                        out.append({
                            "role": "user",
                            "content": block_overrides["current_todos"],
                        })
                    else:
                        out = _inject_current_todos(out, todos)
            except (OSError, ValueError, ImportError):
                pass

        # Skill auto-invoke preamble is appended by
        # ``compose_round_preamble_async`` (see ``_skill_auto_invoke_block``)
        # — it MUST be ``await``ed because ``SkillIndex.search`` is a
        # coroutine, so it cannot run from this sync method. The previous
        # inline version here called ``SkillIndex(self.cfg)`` (wrong ctor —
        # it takes ``(embedder, agent_home)``) and used the un-awaited
        # coroutine, which ``render_preamble`` then threw on and a bare
        # ``except`` swallowed: the feature never produced a preamble even
        # when enabled. Run-turn always goes through the async path
        # (``compose_round_preamble_async``), so no engine loses it.

        # Memory recall preamble — when
        # ``cfg.memory_recall_mode in {context, hybrid}``, prefetch the
        # memory-manager's recall block for the current user prompt.
        # Same migration story as skill auto-invoke: used to live in
        # the legacy turn_runtime; now runs here uniformly.
        try:
            recall = self.memory_recall_context(session, user_text)
        except Exception:  # noqa: BLE001
            recall = ""
        if recall:
            # user-role (see preamble-role note above): a system message
            # after the user-role blocks breaks strict chat templates.
            out.append({"role": "user", "content": recall})

        return out

    async def compose_round_preamble_async(
        self,
        session: Any,
        user_text: str,
    ) -> list[dict[str, Any]]:
        """Async variant — fires ``PreambleInject`` hooks per built-in
        injector before composing the preamble, so an ECC plugin can
        suppress / substitute pinned-facts, compaction-summary,
        current-todos blocks instead of only wrapping them.

        Hook semantics per block:
        * ``decision: block`` (exit 2) → suppress the block entirely.
        * ``decision: block`` + ``reason: <body>`` → substitute the
          hook's body for the canonical injector output.
        * ``hookSpecificOutput.replacementBody`` → same as the reason
          form via the JSON control protocol.
        * No-op → original built-in injector runs.

        Returns the same shape as :meth:`compose_round_preamble`.
        """
        engine = self._load_hook_engine()
        if engine is None or not engine.has_event("PreambleInject"):
            out = self.compose_round_preamble(session, user_text)
            await self._append_skill_auto_invoke(out, user_text)
            return out

        # Probe each injector: skip the hook entirely when there's
        # nothing to render (no pinned facts, no summary, no todos).
        candidates: list[tuple[str, str]] = []
        if list(getattr(session, "pinned_facts", None) or []):
            candidates.append(("pinned_facts", "pinned facts"))
        if str(getattr(session, "compaction_summary", "") or "").strip():
            candidates.append(("compaction_summary", "compaction summary"))
        # current_todos always considered — load_todos is the truth.
        candidates.append(("current_todos", "current todos"))

        suppressed: set[str] = set()
        overrides: dict[str, str] = {}
        for kind, description in candidates:
            outcome = await self._run_hook_event(
                "PreambleInject",
                session,
                {
                    "kind": kind,
                    "description": description,
                    "user_text_chars": len(user_text or ""),
                },
            )
            if outcome.blocked:
                if outcome.block_reason:
                    overrides[kind] = outcome.block_reason
                else:
                    suppressed.add(kind)
            # Honour replacementBody from JSON control protocol.
            for r in getattr(outcome, "results", []) or []:
                j = getattr(r, "json_output", None)
                if not isinstance(j, dict):
                    continue
                hso = j.get("hookSpecificOutput")
                if not isinstance(hso, dict):
                    continue
                rb = hso.get("replacementBody")
                if isinstance(rb, str) and rb.strip():
                    overrides[kind] = rb
                    suppressed.discard(kind)
                    break

        out = self.compose_round_preamble(
            session, user_text,
            suppressed_blocks=suppressed,
            block_overrides=overrides,
        )
        await self._append_skill_auto_invoke(out, user_text)
        return out

    async def _append_skill_auto_invoke(
        self,
        out: list[dict[str, Any]],
        user_text: str,
    ) -> None:
        """Append the embedding-backed skill auto-invoke preamble.

        No-op unless ``cfg.skill_auto_invoke.enabled`` is set AND an
        embedder is configured. Embeds the live user prompt against the
        per-agent :class:`SkillIndex` (cached on ``self._skill_index`` so
        we don't re-embed the skill corpus every turn) and appends any
        skills whose description scores above threshold. Fail-soft: any
        error (embedder down, no skills) yields no preamble — never
        raises into the turn loop.

        This is the awaited home of the auto-invoke that ``SkillIndex``
        was always meant to back; the old inline version in
        :meth:`compose_round_preamble` was dead code (un-awaited
        coroutine, wrong constructor).
        """
        sai_cfg = getattr(self.cfg, "skill_auto_invoke", None) or {}
        if isinstance(sai_cfg, dict):
            enabled = bool(sai_cfg.get("enabled"))
            top_k = int(sai_cfg.get("top_k") or 3)
            threshold = float(sai_cfg.get("threshold", 0.6))
        else:
            enabled = bool(getattr(sai_cfg, "enabled", False))
            top_k = int(getattr(sai_cfg, "top_k", 0) or 3)
            threshold = float(getattr(sai_cfg, "threshold", 0.6))
        if not enabled or not (user_text or "").strip():
            return
        try:
            from rtxclaw_core.skill_index import SkillIndex, render_preamble

            idx = getattr(self, "_skill_index", None)
            if idx is None:
                from rtxclaw_memory.memory_embed import resolve_embedder
                idx = SkillIndex(
                    resolve_embedder(), getattr(self.cfg, "home", None),
                )
                self._skill_index = idx
            if not idx.is_available:
                return
            matches = await idx.search(
                user_text, top_k=top_k, threshold=threshold,
            )
            block = render_preamble(matches)
            if block:
                # user-role (see preamble-role note in
                # compose_round_preamble): the skill block is appended
                # after the user-role pinned/summary/todos blocks, so a
                # system role here would not be leading and strict chat
                # templates reject it ("System message must be at the
                # beginning").
                out.append({"role": "user", "content": block})
        except Exception:  # noqa: BLE001
            pass

    # ---- session CRUD ----------------------------------------------

    def create_session(
        self,
        *,
        workspace_cwd: str = "",
        workspace_origin: str = "",
        mode: Optional[str] = None,
        parent_session_id: str = "",
    ) -> Any:
        """Create a fresh session under ``sessions_dir``.

        Returns the :class:`rtxclaw_core.session.Session` object.
        Composes the system prompt at create-time (so the same prompt
        rides every round of this session) and stamps the new
        attribution fields via
        :func:`session_log.record_session_creation`. The first
        ``session.save()`` picks up those fields.

        Also calls ``self.engine.attach_session(sid, session)`` so the
        local-LLM engine can allocate its per-session live state
        (cancellation flags, promoted-tools set, mode overrides).
        No-op for CLI engines.
        """
        from rtxclaw_core.session import Session
        from . import session_log

        mode = mode or self.permission_mode
        system_prompt = self.compose_system_prompt(mode=mode)

        # Default model/endpoint sourced from cfg (the local-LLM hot
        # path expects them present on the saved session). CLI-engine
        # agents stamp the engine name as ``model`` and leave the HTTP
        # fields empty so the TUI footer / per-turn stats row identify
        # the CLI ("claude" / "codex" / "antigravity") instead of leaking the
        # global config's ``upstream_model`` (e.g. ``gpu-a/qwen3.6-27b``)
        # — which the CLI doesn't use and which made every CLI session
        # falsely advertise as if it ran on the local vLLM upstream.
        engine_kind = self.engine.kind
        _cli_kinds = {
            EngineKind.CLAUDE_CLI,
            EngineKind.CODEX_CLI,
            EngineKind.ANTIGRAVITY_CLI,
            EngineKind.ACP,
            EngineKind.CURSOR_ACP,
        }
        if engine_kind in _cli_kinds:
            primary_model = self.engine.display_model()
            primary_endpoint = ""
            backend = ""
            # ACP engines know the model's real window (e.g. composer
            # 200k); other CLI engines return 0 → global default applies.
            context_window = int(self.engine.context_window() or 0)
        else:
            primary_model = getattr(self.cfg, "upstream_model", "") or ""
            primary_endpoint = getattr(self.cfg, "upstream_endpoint", "") or ""
            backend = getattr(self.cfg, "backend", "") or ""
            context_window = int(
                getattr(self.cfg, "upstream_max_context", 0) or 0
            )

        session = Session.new(
            system_prompt=system_prompt,
            model=primary_model,
            endpoint=primary_endpoint,
            sessions_dir=self.sessions_dir,
            system_mode=mode,
            workspace_cwd=workspace_cwd,
            workspace_origin=workspace_origin,
            backend=backend,
            context_window=context_window,
            parent_session_id=parent_session_id,
        )
        session_log.record_session_creation(
            session,
            agent_name=self.name,
            engine=self.engine.kind.value,
            system_prompt=system_prompt,
            sessions_dir=self.sessions_dir,
            parent_session_id=parent_session_id,
        )
        # Engine-side per-session in-memory state (no-op on CLI engines
        # per the Engine ABC's default).
        try:
            self.engine.attach_session(session.hash, session)
        except Exception:  # noqa: BLE001
            # attach_session is best-effort scaffolding; a buggy
            # override must not block session creation.
            pass
        # session_started was already emitted by record_session_creation
        # above (it inserts the sessions_meta row + writes the
        # self-describing header line). No legacy whole-JSON save.
        return session

    def list_sessions(self) -> list[dict[str, Any]]:
        """Return one row per session from ``sessions.db``.

        Schema matches what ``CoreBackend.list_sessions`` returns —
        hash, title, created_at, turn_count, agent_name, engine,
        workspace_*. Most-recent first. A single SQL query replaces the
        legacy per-file JSON glob+parse.
        """
        from rtxclaw_core.session_index import SessionIndex, connect_sessions_db
        rows: list[dict[str, Any]] = []
        db = self.sessions_dir / "sessions.db"
        if not db.exists() and not self.sessions_dir.is_dir():
            return rows
        try:
            # Lazy index: bring sessions.db current with any JSONL writes
            # before listing (the writer appends JSONL only).
            SessionIndex(self.sessions_dir.parent).refresh()
            con = connect_sessions_db(db)
            try:
                cur = con.execute(
                    "SELECT session_hash, title, created_at, agent_name, "
                    "engine, workspace_cwd, workspace_origin, last_turn_idx "
                    "FROM sessions_meta ORDER BY last_turn_ts DESC, created_at DESC"
                )
                for r in cur.fetchall():
                    rows.append({
                        "hash": r["session_hash"],
                        "title": r["title"] or "",
                        "created_at": r["created_at"] or "",
                        "turn_count": max(0, int(r["last_turn_idx"]) + 1),
                        "agent_name": r["agent_name"] or "",
                        "engine": r["engine"] or "",
                        "workspace_cwd": r["workspace_cwd"] or "",
                        "workspace_origin": r["workspace_origin"] or "",
                    })
            finally:
                con.close()
        except Exception:  # noqa: BLE001
            return rows
        return rows

    def get_session(self, sid: str) -> Any:
        """Load a session by id from ``sessions.db`` + the JSONL event log.

        Header fields come from the ``sessions_meta`` row; ``turns`` are
        folded from ``<sid>.jsonl``. Returns ``None`` when the session
        is unknown. Defense-in-depth: if there's no db row but the engine
        has the session attached (the bridge calls ``attach_session``
        right after ACP ``session/new``), recover from the engine cache.
        """
        from rtxclaw_core.session import Session
        from rtxclaw_core.session_index import SessionIndex, connect_sessions_db
        from rtxclaw_core.session_reader import fold_jsonl_into_turns

        db = self.sessions_dir / "sessions.db"
        jsonl = self.sessions_dir / f"{sid}.jsonl"
        row = None
        if jsonl.exists() or db.exists():
            try:
                # Lazy index: tail this session's JSONL into sessions.db
                # so the header row reflects the latest writes.
                SessionIndex(self.sessions_dir.parent).tail(sid)
                con = connect_sessions_db(db)
                try:
                    row = con.execute(
                        "SELECT * FROM sessions_meta WHERE session_hash=?", (sid,)
                    ).fetchone()
                finally:
                    con.close()
            except Exception:  # noqa: BLE001
                row = None
        if row is None:
            return getattr(self.engine, "_sessions", {}).get(sid)

        d = dict(row)
        sess = Session(
            hash=d.get("session_hash") or sid,
            title=d.get("title") or f"untitled-{sid[-8:]}",
            created_at=d.get("created_at") or "",
            system_prompt=d.get("system_prompt") or "",
            model=d.get("model") or "",
            endpoint=d.get("endpoint") or "",
            turns=[],
            system_mode=d.get("system_mode") or "",
            workspace_cwd=d.get("workspace_cwd") or "",
            workspace_origin=d.get("workspace_origin") or "",
            backend=d.get("backend") or "",
            context_window=int(d.get("context_window") or 0),
            compaction_count=int(d.get("compaction_count") or 0),
            memory_flush_compaction_count=int(
                d.get("memory_flush_compaction_count") or -1
            ),
            last_memory_flush_at=d.get("last_memory_flush_at") or "",
            pinned_facts=_loads_list(d.get("pinned_facts")),
            compaction_summary=d.get("compaction_summary") or "",
            reasoning_visibility=d.get("reasoning_visibility") or "off",
            tool_output_visible=bool(d.get("tool_output_visible") or 0),
        )
        sess.agent_name = d.get("agent_name") or ""
        sess.engine = d.get("engine") or ""
        sess.system_prompt_sha256 = d.get("system_prompt_sha256") or ""
        sess.persist_reasoning_traces = bool(d.get("persist_reasoning_traces", 1))
        sess.persist_tool_result_bodies = bool(d.get("persist_tool_result_bodies", 1))
        # Turns folded from the append-only event log.
        try:
            sess.turns = fold_jsonl_into_turns(self.sessions_dir / f"{sid}.jsonl")
        except Exception:  # noqa: BLE001
            sess.turns = []
        try:
            self.engine.attach_session(sess.hash, sess)
        except Exception:  # noqa: BLE001
            pass
        return sess

    def close_session(self, sid: str) -> None:
        """Drop per-session live state on the engine.

        Reference: ``CoreBackend.close_session`` (acp_bridge.py L1644).
        Forwards to ``engine.detach_session(sid)`` (no-op default on
        the Engine ABC). The on-disk session file is NOT deleted.

        Fires Claude Code's ``SessionEnd`` hook on the way out so an
        ECC plugin can flush state, persist conversation summary, or
        emit a notification. The hook is fired fire-and-forget when an
        event loop is available — ``close_session`` itself stays sync
        for callers that don't want to await. When no loop is running
        (process-shutdown / direct sync caller) the hook is skipped
        rather than blocking on a new loop; SessionEnd is informational
        and should never gate cleanup.
        """
        session = None
        try:
            session = self.get_session(sid)
        except Exception:  # noqa: BLE001
            session = None
        try:
            self.engine.detach_session(sid)
        except Exception:  # noqa: BLE001
            # detach is best-effort cleanup; a buggy override must not
            # block close.
            pass
        # Emit session_closed + evict the cached SessionWriter so its
        # jsonl/dir/lock fds are released (review: Codex/Gemini C2 — the
        # process-global writer registry never evicted → fd leak).
        try:
            from rtxclaw_core.session_writer import (
                close_session_writer, get_session_writer,
            )
            try:
                get_session_writer(self.sessions_dir, sid).session_closed(
                    reason="close_session",
                )
            except Exception:  # noqa: BLE001
                pass
            close_session_writer(self.sessions_dir, sid)
        except Exception:  # noqa: BLE001
            pass
        # SessionEnd — Claude Code's lifecycle hook. Fire-and-forget.
        try:
            import asyncio as _asyncio
            loop = _asyncio.get_event_loop()
            if loop.is_running():
                _asyncio.ensure_future(
                    self._run_hook_event(
                        "SessionEnd",
                        session,
                        {
                            "reason": "close_session",
                            "session_id": sid,
                        },
                    ),
                )
        except RuntimeError:
            # No running loop — best-effort skip (process is shutting
            # down or caller is in a thread without an asyncio loop).
            pass
        except Exception:  # noqa: BLE001
            pass

    def inject_user_message(self, sid: str, text: str) -> bool:
        """Forward a mid-turn user message to the engine.

        The frontend pushes the operator's fresh prompt here when a
        turn is already streaming so the new instruction lands at the
        next round boundary and can steer the in-flight plan without
        waiting for it to terminate.

        Returns ``True`` when queued. Engines that don't implement the
        injection protocol (CLI bridges, gemini-cli) return ``False``
        — caller should fall back to local queue + post-turn dispatch.
        """
        inj = getattr(self.engine, "inject_user_message", None)
        if inj is None:
            return False
        try:
            return bool(inj(sid, text))
        except Exception:  # noqa: BLE001
            return False

    # ---- turn dispatch ---------------------------------------------

    async def run_turn(
        self,
        sid: str,
        prompt: str = "",
        *,
        prompt_parts: Optional[list[dict[str, Any]]] = None,
        mode: Optional[str] = None,
        cwd: Optional[str] = None,
        model: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Dispatch one turn against ``sid``.

        Sequence (revised per codex audit findings #3, #4, #5, #6, #7):

        1. **Per-session lock** — ``async with await
           self.engine.session_lock(sid):`` so two concurrent prompts
           on the same sid don't race on engine-session creation.
        2. Load the :class:`Session` and the engine's
           :class:`EngineSessionState` for ``sid``.
        3. Compose the system prompt + preamble:

           * ``system_prompt = self.compose_system_prompt(mode=mode)``
             and ``sha = sha256(system_prompt)``.
           * ``preamble = self.compose_round_preamble(session,
             user_text=prompt_or_parts_text)``.

        4. Consult :meth:`Engine.system_prompt_policy(state)`:

           * ``"every_turn"`` (local LLM): include both system_prompt
             and preamble in :class:`TurnRequest`. Local LLM splices
             every round.
           * ``"first_turn"`` (CLI, ``priming_status in
             {never, in_progress, failed}``): include both. Engine
             primes via ``--append-system-prompt`` then sets
             ``priming_status="completed"`` + stamps the sha.
           * ``"sha_changed"`` (CLI, prompt edits detected): include
             both. Engine starts a fresh CLI session (don't reuse the
             stale one — old SOUL.md is baked into Claude's session
             state).
           * ``"never"`` (CLI resume, sha matches): pass
             ``system_prompt=None``, ``preamble=[]``. CLI resumes;
             no re-injection.

        5. Run :meth:`apply_pre_turn_hooks` — operator-defined hooks.
        6. Build :class:`TurnRequest` (carrying ``prompt`` /
           ``prompt_parts`` for multimodal — codex audit finding #7 —
           plus the system_prompt / preamble / mode / cwd / model
           chosen above).
        7. ``async for event in self.engine.run_turn(request, state,
           ...)``:

           * :class:`PermissionRequested` (codex audit finding #6) —
             INTERCEPT before yielding upward. Call
             :meth:`resolve_permission` which consults
             :class:`PermissionPolicy.evaluate` and (for ``"ask"``)
             surfaces an outbound ACP ``request_permission``. Set
             ``ev.response.set_result(decision)``. DO NOT yield this
             event to the gateway translator.
           * :class:`TurnStarted` — capture ``engine_session_id``;
             record into session metadata.
           * :class:`ToolCallStarted` / :class:`ToolCallResult` —
             accumulate into structured lists for
             :func:`session_log.record_turn`. Yield through unchanged.
           * :class:`TextDelta` / :class:`TurnError` — yield through.
           * :class:`TurnDone` — terminal. Move to step 8.

        8. On :class:`TurnDone`:

           * :meth:`apply_post_turn_hooks` — operator hooks + memory
             provider's ``observe_turn`` + fact extraction.
           * :func:`session_log.record_turn` with FULL attribution:
             engine, model, engine_session_id, tool_calls[],
             tool_results[], permission_mode, approval_decisions[],
             round_index, finish_reason, error_classification, cwd,
             cli_argv (CLI engines only), thinking_chars (if
             persistence enabled), compaction_events,
             distill_events, nudge_events, pause_resume_log.
           * ``session.save()``.
           * The engine has ALREADY written its state mid-stream
             (priming_status transitions) — no separate write here.

        9. **Pre-compaction memory flush** intercept (local-LLM only):
           if the engine yields
           :class:`TurnError(classification="needs_memory_flush")`,
           the Agent pauses, runs a silent flush turn (via
           :meth:`maybe_memory_flush`), then re-enters step 7 from
           the same engine state. CLI engines never produce this.

        Engine-kind matrix:

        * Local-LLM agents (``engine == "local_llm"``) reach this
          method through :class:`AgentACPBackend` →
          :class:`CoreBackend.prompt` → ``_prompt_via_new_backend`` —
          a 4-line proxy. The multi-round loop, compaction, loop
          detection, distill recovery, hooks, premature-turn-end
          nudges, and memory recall all live inside
          :class:`LocalLLMEngine.run_turn`; CoreBackend now only
          owns session lifecycle + cancel routing + outbound
          channel binding.
        * CLI agents (``claude_cli`` / ``codex_cli`` /
          ``gemini_cli``) flow through Agent.run_turn → Engine.run_turn
          → ``run_delegate_<cli>_async``. The CLI subprocess owns its
          own hooks / compaction / heartbeat / loop semantics; rtxclaw
          contributes the composed system prompt via
          ``--append-system-prompt`` (claude) or ``<system>...</system>``
          (codex / gemini) and intercepts permission via
          :class:`PermissionRequested`.

        Permission interception consults
        :class:`permissions_integration.PermissionPolicy.evaluate`
        (auto-mode auto-allows safe tools, prompts on destructive
        ones; ASK mode round-trips through the bound outbound
        channel). Engines that yield :class:`PermissionRequested`
        set their response future and the turn resumes; the event is
        not yielded upward.
        """
        from .engine import (
            EngineKind,
            EngineSessionState,
            PermissionRequested,
            TextDelta,
            ToolCallResult,
            ToolCallStarted,
            TurnDone,
            TurnError,
            TurnRequest,
            TurnStarted,
        )
        from . import session_log

        # Resolve / pre-load the session BEFORE acquiring the lock so
        # a 404 fails fast.
        session = self.get_session(sid)
        if session is None:
            yield TurnError(
                message=f"session not found: {sid!r}",
                classification="bad_request",
            )
            yield TurnDone(state="error")
            return

        # Top-level terminal-emission safety net (gemini audit
        # phase-3a finding #3). Without this an exception in
        # ``session_lock`` / ``compose_system_prompt`` /
        # ``compose_round_preamble`` would bubble up before any
        # ``TurnDone`` ever yields — frontend hangs in "thinking"
        # state forever. We delegate the actual work to an inner
        # async generator and wrap it here so we can emit a
        # ``TurnError`` + ``TurnDone(error)`` fallback when no
        # ``TurnDone`` was produced before an exception fired.
        #
        # ``GeneratorExit`` (consumer ``aclose``'d us) is the one
        # case we do NOT emit on — yielding from within
        # ``GeneratorExit`` raises RuntimeError. Let it propagate.
        turn_done_emitted = False
        try:
            async for ev in self._run_turn_inner(
                session, sid, prompt, prompt_parts, mode, cwd, model, env,
            ):
                if isinstance(ev, TurnDone):
                    turn_done_emitted = True
                yield ev
        except GeneratorExit:
            raise
        except Exception as exc:  # noqa: BLE001
            if not turn_done_emitted:
                yield TurnError(
                    message=f"agent.run_turn aborted: {exc}",
                    classification="agent_exception",
                )
                yield TurnDone(state="error")
            else:
                # Already terminated normally; suppress the exception
                # rather than re-yielding (TurnDone is terminal).
                pass

    async def _run_turn_inner(
        self,
        session: Any,
        sid: str,
        prompt: str,
        prompt_parts: Optional[list[dict[str, Any]]],
        mode: Optional[str],
        cwd: Optional[str],
        model: Optional[str],
        env: Optional[dict[str, str]],
    ) -> AsyncIterator[AgentTurnEvent]:
        """Inner body of :meth:`run_turn`.

        Extracted so the outer ``run_turn`` can wrap this in a
        single ``try/except`` for the terminal-emission safety net
        (gemini audit phase-3a finding #3) without re-indenting the
        existing body. Same imports + same control flow as before
        the refactor.
        """
        from .engine import (
            EngineKind,
            EngineSessionState,
            PermissionRequested,
            RoundComplete,
            TextDelta,
            ToolCallResult,
            ToolCallStarted,
            TurnDone,
            TurnError,
            TurnRequest,
            TurnStarted,
            UserMessageInjected,
        )
        from . import session_log

        # Per-session lock — codex audit #3.
        lock = await self.engine.session_lock(sid)
        async with lock:
            # Stamp the agent attribution on legacy-created sessions
            # that hit the new path. ``CoreBackend.new_session``
            # doesn't set ``agent_name`` (codex sixth-pass A.1), so
            # without this the ``turn_completed`` publish inside
            # ``session_log.record_turn`` silently skips — memory
            # provider auto-extraction would stop on every turn that
            # touched a pre-attribution session.
            if not getattr(session, "agent_name", "") or not session.agent_name:
                session.agent_name = self.name
            if not getattr(session, "engine", "") or not session.engine:
                session.engine = self.engine.kind.value

            # Compose system prompt + preamble. Sha is computed
            # against the freshly composed system prompt so the
            # engine's policy can detect SOUL.md edits between
            # turns (CLI engines only — local LLM ignores).
            #
            # Use `_effective_mode(session)` so a session-scoped
            # `/mode plan` flows into the MODE-*.md system-prompt
            # block AND the hook context AND the TurnRequest.mode
            # stamped on the engine — not just the permission gate.
            # Without this, `/mode plan` was "half cosmetic": the gate
            # denied tools but the model saw "you're in auto" in its
            # system prompt and kept trying to make the calls.
            effective_mode = mode or self._effective_mode(session)

            # Claude Code's hook lifecycle (UserPromptSubmit /
            # PreToolUse / PostToolUse / Stop / PreCompact) fires
            # INSIDE the engine's turn loop — the engine owns the
            # message list, the round loop, and tool dispatch, which
            # is exactly where Claude Code runs hooks. The Agent just
            # hands the engine its HookEngine plus the common Claude
            # Code hook context (session_id / transcript_path / cwd /
            # permission_mode / plugin_root). See
            # LocalLLMEngine.run_turn / _dispatch_tool_calls.
            hook_engine = self._load_hook_engine()
            hook_ctx = self._hook_kwargs(session, cwd or "")

            system_prompt = self.compose_system_prompt(
                mode=effective_mode,
                workspace_cwd=cwd or "",
                workspace_origin=session.workspace_origin or "",
            )
            preamble = await self.compose_round_preamble_async(session, prompt)
            sha = session_log.compute_system_prompt_hash(system_prompt)

            engine_state = self.engine.read_state(self.sessions_dir, sid)
            policy = self.engine.system_prompt_policy(
                engine_state,
                current_system_prompt_sha256=sha,
            )
            if policy == "never":
                request_system_prompt: Optional[str] = None
                request_preamble: list[dict[str, Any]] = []
            else:
                request_system_prompt = system_prompt
                request_preamble = preamble

            request = TurnRequest(
                prompt=prompt or "",
                prompt_parts=list(prompt_parts or []),
                system_prompt=request_system_prompt,
                system_prompt_sha256=sha,
                preamble=request_preamble,
                mode=effective_mode,
                cwd=cwd,
                model=model,
                extra={
                    "session": session,
                    "hook_engine": hook_engine,
                    "hook_ctx": hook_ctx,
                    # Per-agent provider API keys, lifted from
                    # ``~/.rtxclaw/agents/<name>/secrets.env`` at
                    # ``AgentConfig.load()`` time. External-CLI engines
                    # (claude/codex/gemini) inject these into the
                    # subprocess env so each agent's CLI hits its OWN
                    # provider sub-account — the same per-agent
                    # attribution that LocalLLMEngine gets via
                    # ``cfg.upstream_headers()``. Empty dict means
                    # the CLI inherits ``os.environ`` only.
                    "api_keys": dict(getattr(self.cfg, "api_keys", {}) or {}),
                },
            )

            turn_id = uuid.uuid4().hex

            # Collect tool_calls / tool_results for the session log.
            # Agent is the SINGLE owner of session_log.record_turn —
            # codex audit round-3 #6 (no split attribution).
            import datetime as _dt
            def _now_iso() -> str:
                return _dt.datetime.now().astimezone().isoformat()

            collected_tool_calls: list[dict[str, Any]] = []
            collected_tool_results: list[dict[str, Any]] = []
            # call_id -> {name, arguments} so PostToolUse hooks can name
            # the tool (ToolCallResult carries only call_id/ok/content).
            tool_calls_by_id: dict[str, dict[str, Any]] = {}
            last_error_msg = ""
            last_error_classification = ""

            # Streaming accumulators for in-progress snapshots. Today
            # ``thinking`` / ``content`` only land on disk at TurnDone
            # (via ``request.extra["_engine_audit"]``). For realtime
            # log streaming + crash recovery we mirror the engine's
            # buffers here as ``TextDelta`` events fly by, and feed
            # them into mid-turn ``record_turn(in_progress=True)``
            # snapshots so the JSON file always reflects the latest
            # state (atomic-replace in ``Session.save`` keeps the file
            # parseable at every flush boundary).
            streamed_content: list[str] = []
            streamed_thinking: list[str] = []
            turn_started_at_iso = _now_iso()

            # Per-channel debounce. A streaming worker can emit
            # hundreds of TextDelta chunks/sec; full JSON serialize +
            # fsync on each one would dominate the turn's CPU. Tool
            # events bypass this and always flush. Operators can tune
            # via ``RTXCLAW_SESSION_FLUSH_DEBOUNCE_MS`` (0 disables).
            import os
            try:
                _flush_debounce_ms = int(
                    os.environ.get("RTXCLAW_SESSION_FLUSH_DEBOUNCE_MS", "250")
                )
            except (TypeError, ValueError):
                _flush_debounce_ms = 250
            _flush_debounce_s = max(0.0, _flush_debounce_ms / 1000.0)
            _last_delta_flush_ts = 0.0

            def _flush_in_progress_snapshot(
                *, round_idx: int = 0, finish_reason: str = "in_progress",
            ) -> None:
                """Persist the current accumulator state as an
                ``in_progress=True`` turn record. Best-effort:
                ``Session.save`` is atomic (tmp + fsync + rename) so the
                on-disk JSON stays valid at every flush boundary; any
                exception here is swallowed so a transient write failure
                never interrupts the live stream.
                """
                try:
                    session_log.record_turn(
                        session,
                        sessions_dir=self.sessions_dir,
                        user=(
                            list(request.prompt_parts)
                            if request.prompt_parts
                            else (request.prompt or "")
                        ),
                        thinking="".join(streamed_thinking),
                        content="".join(streamed_content),
                        started_at=turn_started_at_iso,
                        ended_at=_now_iso(),
                        engine=self.engine.kind.value,
                        model=(
                            model
                            or session.model
                            or getattr(self.cfg, "upstream_model", "")
                            or self.engine.kind.value
                        ),
                        permission_mode=effective_mode,
                        cwd=cwd or "",
                        round_index=round_idx,
                        finish_reason=finish_reason,
                        metrics={"in_progress": True},
                        aborted=False,
                        error=None,
                        error_classification="",
                        tool_calls=collected_tool_calls,
                        tool_results=collected_tool_results,
                        engine_session_id="",
                        in_progress=True,
                    )
                except Exception:  # noqa: BLE001
                    # Partial-save is best-effort — never interrupt
                    # the stream on a flush failure.
                    pass

            try:
                async for ev in self.engine.run_turn(
                    request, engine_state,
                    sessions_dir=self.sessions_dir,
                    turn_id=turn_id,
                    env=env,
                ):
                    # Permission interception — never reaches the wire.
                    # The engine has already run the PreToolUse hook
                    # (and handled allow/deny itself); this resolves
                    # the permission POLICY + ASK protocol and honors
                    # a hook's `ask` request via ev.hook_decision.
                    if isinstance(ev, PermissionRequested):
                        try:
                            outbound = None
                            resolver = self._outbound_resolver
                            if callable(resolver):
                                try:
                                    outbound = resolver(session.hash)
                                except Exception:  # noqa: BLE001
                                    outbound = None
                            await self.resolve_permission(
                                ev, session, outbound=outbound,
                            )
                        except Exception:  # noqa: BLE001
                            try:
                                if (
                                    ev.response is not None
                                    and not ev.response.done()
                                ):
                                    ev.reason = "permission resolver error"
                                    ev.response.set_result("deny")
                            except Exception:  # noqa: BLE001
                                pass
                        continue
                    if isinstance(ev, ToolCallStarted):
                        if not ev.is_outer:
                            collected_tool_calls.append(
                                session_log.make_tool_call_record(
                                    ev.call_id,
                                    ev.name,
                                    ev.arguments,
                                    started_at=_now_iso(),
                                )
                            )
                            tool_calls_by_id[ev.call_id] = {
                                "name": ev.name,
                                "arguments": ev.arguments,
                            }
                            # Tool dispatch is a discrete, low-frequency
                            # event — flush immediately so the on-disk
                            # log reflects the call before the (often
                            # long-running) tool body executes. Bypasses
                            # the TextDelta debounce.
                            _flush_in_progress_snapshot()
                            _last_delta_flush_ts = time.monotonic()
                    elif isinstance(ev, ToolCallResult):
                        # PostToolUse hooks already fired inside the
                        # engine's dispatch loop (it owns the message
                        # list — that is where `additionalContext` has
                        # to land to reach the model). The Agent just
                        # records the result for the session log.
                        collected_tool_results.append(
                            session_log.make_tool_result_record(
                                ev.call_id, ev.ok, ev.content,
                                ended_at=_now_iso(),
                            )
                        )
                        # Tool completion is the other discrete event
                        # we always flush on — pairs with the
                        # ToolCallStarted snapshot so a mid-turn crash
                        # never leaves an orphan "call without result".
                        _flush_in_progress_snapshot()
                        _last_delta_flush_ts = time.monotonic()
                    elif isinstance(ev, TextDelta):
                        # Mirror the engine's per-channel buffers so
                        # in-progress snapshots carry the latest
                        # content / thinking. ``tool_delta`` chunks
                        # stream INSIDE an in-flight tool call and are
                        # captured by the eventual ``ToolCallResult``;
                        # we don't accumulate them here.
                        if ev.channel == "content":
                            streamed_content.append(ev.text)
                        elif ev.channel == "thinking":
                            streamed_thinking.append(ev.text)
                        # Debounced flush — coalesces high-frequency
                        # token bursts so we don't fsync per delta.
                        # The accumulators carry the latest state, so
                        # any flush — debounced or tool-triggered —
                        # picks up everything since the last write.
                        now_mono = time.monotonic()
                        if (
                            _flush_debounce_s <= 0.0
                            or (now_mono - _last_delta_flush_ts)
                            >= _flush_debounce_s
                        ):
                            _flush_in_progress_snapshot()
                            _last_delta_flush_ts = now_mono
                        # Fall through to ``yield ev`` so the gateway /
                        # frontend still sees the live delta stream.
                    elif isinstance(ev, RoundComplete):
                        # Realtime persistence checkpoint. Mid-turn
                        # kills (TUI dies, gateway restart, network
                        # blip) used to lose ALL evidence of the in-
                        # progress turn — record_turn only fired at
                        # TurnDone. Now after every worker round we
                        # flush an ``in_progress=True`` snapshot so a
                        # crash leaves a recoverable record on disk
                        # and ``/sessions`` shows the partial turn.
                        _flush_in_progress_snapshot(
                            round_idx=ev.round_idx,
                            finish_reason="in_progress",
                        )
                        _last_delta_flush_ts = time.monotonic()
                        # Forward RoundComplete upward so the ACP
                        # translator can emit a per-round usage_update
                        # — that's what makes the frontend's `ctx X/Y`
                        # indicator climb after each tool round instead
                        # of sitting frozen on the baseline until
                        # TurnDone. The translator only acts on the
                        # round's `metrics`; non-ACP consumers
                        # (delegate/heartbeat/memory-flush) ignore the
                        # event via their isinstance dispatch.
                        # Fall through to ``yield ev`` below.
                    elif isinstance(ev, UserMessageInjected):
                        # Surface mid-turn injects upward so frontends
                        # can render "↳ steering message picked up"
                        # inline. The engine has already appended the
                        # message to its own message list.
                        pass  # fall through to ``yield ev`` below
                    elif isinstance(ev, TurnError):
                        last_error_msg = ev.message
                        last_error_classification = ev.classification
                    elif isinstance(ev, TurnDone):
                        # Persist the canonical turn record BEFORE
                        # yielding TurnDone upward (so the on-disk
                        # state is consistent by the time the gateway
                        # translator sees the stopReason).
                        audit = request.extra.get("_engine_audit") or {}
                        user_payload: Any = (
                            list(request.prompt_parts)
                            if request.prompt_parts else (request.prompt or "")
                        )
                        try:
                            # Resolve model with a graceful chain so
                            # fine-tune records never get an empty
                            # ``model`` field even when cfg.upstream_model
                            # was empty at session-creation time
                            # (codex audit round-4 model-empty note).
                            resolved_model = (
                                (audit.get("metrics") or {}).get("model")
                                or model
                                or session.model
                                or getattr(self.cfg, "upstream_model", "")
                                or self.engine.kind.value
                            )
                            # Fall back to the agent-side streamed
                            # buffers when the engine produced no audit
                            # (raised before stashing) — without this,
                            # an engine crash would overwrite the
                            # last in_progress snapshot with empty
                            # content / thinking and lose everything
                            # that was already flushed to disk during
                            # the stream.
                            final_thinking = (
                                audit.get("thinking")
                                or "".join(streamed_thinking)
                            )
                            final_content = (
                                audit.get("content")
                                or "".join(streamed_content)
                            )
                            session_log.record_turn(
                                session,
                                sessions_dir=self.sessions_dir,
                                user=user_payload,
                                thinking=final_thinking,
                                content=final_content,
                                started_at=audit.get("started_at") or turn_started_at_iso,
                                ended_at=audit.get("ended_at") or _now_iso(),
                                engine=self.engine.kind.value,
                                model=resolved_model,
                                permission_mode=effective_mode,
                                cwd=cwd or "",
                                round_index=0,
                                finish_reason=str(
                                    (audit.get("metrics") or {}).get("finish_reason") or "stop"
                                ),
                                metrics=audit.get("metrics") or {},
                                aborted=(ev.state == "aborted"),
                                error=last_error_msg or None,
                                error_classification=last_error_classification or "",
                                tool_calls=collected_tool_calls,
                                tool_results=collected_tool_results,
                                engine_session_id=ev.engine_session_id or "",
                                # Replay-fidelity fields (fix_20260519
                                # round-4): pulled from the engine's
                                # audit stash. Empty defaults are fine
                                # — CLI engines don't populate these.
                                model_input_messages=audit.get("model_input_messages") or [],
                                round_metrics=audit.get("round_metrics") or [],
                                effective_system_prompt=audit.get("effective_system_prompt") or "",
                                effective_system_prompt_sha256=audit.get("effective_system_prompt_sha256") or "",
                                effective_preamble=audit.get("effective_preamble") or [],
                                upstream_endpoint=audit.get("upstream_endpoint") or "",
                                hook_outcomes=audit.get("hook_outcomes") or [],
                            )
                        except Exception as exc:  # noqa: BLE001
                            # record_turn is best-effort; never block
                            # terminal emission on a save failure.
                            try:
                                import logging
                                logging.getLogger("rtxclaw.agents.agent").warning(
                                    "record_turn failed: %s", exc,
                                )
                            except Exception:  # noqa: BLE001
                                pass

                        # Surface the engine's OWN CLI session id
                        # (claude/codex/antigravity resume token) at the
                        # SESSION level — both the JSONL log and
                        # sessions.db (`sessions_meta.engine_session_id`)
                        # — so the rtxclaw↔engine session link is
                        # queryable from either store. Only CLI engines
                        # populate ``ev.engine_session_id``; local-LLM
                        # leaves it empty. ``header_update`` writes the
                        # JSONL record and the projector folds it into
                        # sessions.db. Dedup so a multi-turn CLI session
                        # logs the (stable) id once, not per turn.
                        eng_sid = ev.engine_session_id or ""
                        if eng_sid and eng_sid != getattr(
                            session, "_logged_engine_session_id", "",
                        ):
                            try:
                                from rtxclaw_core.session_writer import (
                                    get_session_writer,
                                )
                                get_session_writer(
                                    self.sessions_dir, sid,
                                ).header_update(
                                    patch={"engine_session_id": eng_sid},
                                )
                                session._logged_engine_session_id = eng_sid
                            except Exception:  # noqa: BLE001
                                pass

                        # Memory provider observe hook — surfaces the
                        # just-finished turn to the memory layer so
                        # the next round can recall it. We harvest
                        # the freshly-persisted turn record from
                        # ``session.turns[-1]`` (record_turn appends
                        # there before returning); ``observe_turn``
                        # needs both the session and the row to
                        # extract facts and feed the provider.
                        try:
                            last_turn = (
                                list(session.turns or [])[-1]
                                if getattr(session, "turns", None) else {}
                            )
                            self.observe_turn_memory(
                                session, dict(last_turn),
                            )
                        except Exception as obs_exc:  # noqa: BLE001
                            # Log so a future regression doesn't sit
                            # silent behind the catch-all (the previous
                            # 1-arg invocation TypeError'd on every
                            # turn for ~24h without anyone noticing).
                            try:
                                import logging
                                logging.getLogger("rtxclaw.agents.agent").warning(
                                    "observe_turn_memory failed: %s",
                                    obs_exc,
                                )
                            except Exception:  # noqa: BLE001
                                pass

                        # Pre-compaction memory flush. When the
                        # session has crossed the configured flush
                        # threshold (``cfg.memory_flush_*``), squeeze
                        # the message list into MEMORY.md and reset
                        # the budget so the next turn doesn't push
                        # against the compaction guard.
                        #
                        # Scheduled as a background task (not
                        # awaited) because ``maybe_memory_flush``
                        # recurses into ``self.run_turn`` and we are
                        # still holding the per-session lock here —
                        # awaiting would self-deadlock (gemini
                        # round-6 finding B2). The task waits on the
                        # same lock and runs once the current turn
                        # releases it.
                        try:
                            import asyncio as _flush_asyncio
                            _flush_asyncio.create_task(
                                self.maybe_memory_flush(session),
                                name=f"memory_flush_{session.hash[:12]}",
                            )
                        except Exception:  # noqa: BLE001
                            pass

                        # Stop hooks (Claude Code) fire INSIDE the
                        # engine's turn loop — including the blocking
                        # continuation path, which needs the message
                        # list and round loop the engine owns. The
                        # Agent doesn't re-fire them here.
                    yield ev
            except Exception as exc:  # noqa: BLE001
                yield TurnError(
                    message=f"engine raised: {exc}",
                    classification="engine_exception",
                )
                yield TurnDone(state="error")
                return

    async def resolve_permission(
        self,
        ev: "PermissionRequested",
        session: Any,
        *,
        outbound: Optional[Any] = None,    # ACP outbound channel
    ) -> None:
        """Decide a permission request and set ``ev.response``.

        Codex audit finding #6 — the engine yields
        :class:`PermissionRequested` events and the Agent resolves
        them. Steps:

        1. Run :meth:`apply_pre_tool_hooks` — operator can veto.
        2. Run :class:`PermissionPolicy.evaluate(tool_name, args,
           criticality)` → ``"allow"`` / ``"deny"`` / ``"ask"``.
        3. For ``"ask"``: run :func:`permissions_integration.ask_user`
           (auto-mode auto-answers; non-auto surfaces ACP
           ``request_permission``).
        4. Populate ``ev.reason`` when denying.
        5. ``ev.response.set_result(decision)`` to unblock the engine.

        Never yields. Never raises (failures map to ``"deny"`` with a
        reason).
        """
        from .permissions_integration import (
            AskQuestion,
            PermissionPolicy,
            ask_user,
        )

        decision = "deny"
        reason = ""

        try:
            if ev.response is None or ev.response.done():
                return

            # Step 1: PreToolUse hooks already ran inside the engine's
            # dispatch loop — it handled `deny` (skipped the call) and
            # `allow` (never yielded this event) itself. Only "" (no
            # opinion) or "ask" (force the confirmation path) reach
            # here, carried on ev.hook_decision.
            hook_perm = str(getattr(ev, "hook_decision", "") or "")

            # Step 2: policy evaluation. Use the per-session resolved
            # mode (so `/mode plan` actually flips the gate); falls
            # back to cfg.permission_mode when the session hasn't
            # been steered. The 2026-05-07 regression was caused by
            # reading self.permission_mode here directly.
            mode = self._effective_mode(session)
            try:
                policy = PermissionPolicy(mode=mode)
                decision, policy_reason = policy.evaluate(
                    ev.tool_name,
                    ev.arguments or {},
                    ev.criticality or "mutating",
                )
                reason = policy_reason or reason
            except Exception:  # noqa: BLE001
                decision, reason = "deny", "policy_unavailable"
                return

            # A PreToolUse hook asking for confirmation upgrades an
            # otherwise-allowed call to the ASK path (Claude Code's
            # `permissionDecision: ask`).
            if hook_perm == "ask" and decision == "allow":
                decision = "ask"
                reason = reason or "PreToolUse hook requested confirmation"

            # Step 3: surface ASK if needed.
            if decision == "ask":
                try:
                    answers = await ask_user(
                        [AskQuestion(
                            id=f"perm:{ev.call_id}",
                            title=f"Allow {ev.tool_name}?",
                            detail=str(ev.arguments)[:400],
                        )],
                        session_id=getattr(session, "hash", "") or "",
                        mode=mode,
                        outbound=outbound,
                    )
                except Exception:  # noqa: BLE001
                    answers = []
                if answers and isinstance(answers[0], dict):
                    chosen = answers[0].get("optionId") or answers[0].get("decision")
                    decision = "allow" if str(chosen).lower() in (
                        "allow", "yes", "y", "0"
                    ) else "deny"
                    if decision == "deny" and not reason:
                        reason = "user denied"
                else:
                    decision = "deny"
                    reason = reason or "no user answer"

            if decision != "allow":
                ev.reason = reason
        finally:
            try:
                if ev.response is not None and not ev.response.done():
                    ev.response.set_result(
                        decision if decision in ("allow", "deny") else "deny",
                    )
            except Exception:  # noqa: BLE001
                pass

    async def abort(self, turn_id: str) -> None:
        """Forward to ``engine.abort(turn_id)``. The Agent doesn't own
        the in-flight subprocess; the Engine does. ACP's
        ``session/cancel`` reaches this via
        :meth:`AgentACPBackend.cancel`."""
        await self.engine.abort(turn_id)

    # ---- hooks — Claude Code lifecycle events ----------------------
    #
    # rtxclaw's hooks ARE Claude Code's hooks: the same ``hooks.json``
    # config, the same event names, the same stdin-payload / exit-code
    # / JSON-stdout protocol (see :mod:`rtxclaw_core.hooks`). The
    # methods below are the runtime's call sites — each builds the
    # per-event payload, runs the engine, and hands a
    # :class:`~rtxclaw_core.hooks.HookOutcome` back to the caller to
    # act on (deny a tool, inject context, halt the agent, warn the
    # operator).
    #
    # rtxclaw's tool registry already uses Claude Code's tool names
    # verbatim (``Bash`` / ``Read`` / ``Edit`` / ``Write`` / ``Grep``
    # / ``Glob`` / ``TodoWrite`` …), so a ``tool_name`` from a tool
    # call is fed to the hook payload as-is — a matcher written for
    # Claude Code (``"matcher": "Bash"``) fires here unchanged with no
    # translation layer.

    def _hook_kwargs(self, session: Any, cwd: str = "") -> dict[str, Any]:
        """Common Claude Code hook fields for this agent + session."""
        import os as _os
        sid = str(getattr(session, "hash", "") or "")
        transcript = ""
        try:
            if sid:
                transcript = str(self.sessions_dir / f"{sid}.jsonl")
        except Exception:  # noqa: BLE001
            transcript = ""
        return {
            "session_id": sid,
            "transcript_path": transcript,
            "cwd": cwd or str(
                getattr(session, "workspace_cwd", "") or _os.getcwd()
            ),
            "permission_mode": self._effective_mode(session),
            "plugin_root": getattr(self, "_hook_plugin_root", "") or "",
        }

    async def _run_hook_event(
        self,
        event: str,
        session: Any,
        payload: dict[str, Any],
        *,
        cwd: str = "",
    ) -> Any:
        """Dispatch one Claude Code hook event; never raises.

        Returns an empty-effect
        :class:`~rtxclaw_core.hooks.HookOutcome` when no engine is
        loaded, the event has no matching hooks, or the engine errors
        — so callers treat "hooks disabled" and "hooks ran, no
        effect" identically.
        """
        from rtxclaw_core.hooks import HookOutcome
        engine = self._load_hook_engine()
        if engine is None or not engine.has_event(event):
            return HookOutcome(event=event)
        try:
            return await engine.run(
                event, payload, **self._hook_kwargs(session, cwd),
            )
        except Exception as exc:  # noqa: BLE001
            import logging
            logging.getLogger("rtxclaw.agents.hooks").info(
                "hook event %s failed: %s", event, exc,
            )
            return HookOutcome(event=event)

    # Per-event hook wrappers — UserPromptSubmit / PreToolUse /
    # PostToolUse / Stop / SubagentStop / SessionStart / SessionEnd /
    # PreCompact / Notification — used to live here as thin
    # ``_run_hook_event(...)`` wrappers. None had callers — every
    # live hook firing goes through :meth:`LocalLLMEngine._fire_hook`
    # (which calls ``hook_engine.run(event, payload, **hook_ctx)``
    # directly). Removed.

    def observe_turn_memory(
        self,
        session: Any,
        turn_record: dict[str, Any],
    ) -> None:
        """Memory-provider + SQLite-facts observation of a finished turn.

        Split out of the old ``apply_post_turn_hooks``: operator
        ``Stop`` hooks now run via :meth:`run_stop_hooks` (real Claude
        Code hooks), while this keeps the memory side-effects — the
        provider's ``observe_turn`` and ``sqlite_facts`` extraction —
        that must fire on every turn regardless of hook config.
        Best-effort; failures never block the turn save.
        """

        # 2. Memory provider observation (best-effort; failures here
        #    must never block the turn save).
        try:
            from rtxclaw_memory.memory_manager import get_active_provider
            provider = get_active_provider(self.cfg.home)
            if provider is not None and hasattr(provider, "observe_turn"):
                res = provider.observe_turn(self.cfg, session, turn_record)
                if hasattr(res, "__await__"):
                    # Provider exposes async observe; schedule but don't await.
                    try:
                        import asyncio
                        asyncio.ensure_future(res)
                    except Exception:  # noqa: BLE001
                        pass
        except Exception:  # noqa: BLE001
            pass

        # 3. SQLite facts auto-extraction.
        try:
            from rtxclaw_core import sqlite_facts as _sf
            if hasattr(_sf, "extract_facts_from_session"):
                turns = list(getattr(session, "turns", []) or [])
                if turn_record:
                    turns = turns + [turn_record]
                _sf.extract_facts_from_session({"turns": turns})
        except Exception:  # noqa: BLE001
            pass

    # ---- memory ----------------------------------------------------

    def memory_recall_context(
        self,
        session: Any,
        user_text: str,
    ) -> str:
        """Build the ``[RECALLED CONTEXT]`` block for a turn.

        Reference: existing ``memory_manager.prefetch_for_query``
        contract (``rtxclaw_core.memory_manager``). Returns the
        formatted block (or empty string when recall is disabled or
        the provider has nothing relevant). Local-LLM engine calls
        this every round; CLI engines call it once and fold into the
        composed system prompt.
        """
        mode = str(getattr(self.cfg, "memory_recall_mode", "") or "off").lower()
        if mode not in ("context", "hybrid"):
            return ""
        if not (user_text or "").strip():
            return ""
        try:
            import asyncio
            from rtxclaw_memory.memory_manager import prefetch_for_query

            # ``prefetch_for_query`` is an async helper; call it
            # synchronously by running a fresh loop when we're not
            # already inside one. Returns the formatted recall block.
            # NB: the helper is keyword-only — ``*, home, query,
            # workspace_origin`` — passing positionally raises
            # ``TypeError: takes 0 positional arguments`` and the
            # bare-except eats it (audit 2026-05-15 finding B1).
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop is not None and loop.is_running():
                # Cannot block on an existing running loop from a
                # sync method. Fall back to empty recall.
                return ""
            workspace_origin = str(
                getattr(session, "workspace_origin", "") or ""
            )
            return asyncio.run(
                prefetch_for_query(
                    home=self.cfg.home,
                    query=user_text,
                    workspace_origin=workspace_origin,
                ),
            ) or ""
        except Exception as exc:  # noqa: BLE001
            try:
                import logging
                logging.getLogger("rtxclaw.agents.agent").warning(
                    "memory_recall_context failed: %s", exc,
                )
            except Exception:  # noqa: BLE001
                pass
            return ""

    async def maybe_memory_flush(
        self, session: Any
    ) -> tuple[bool, str]:
        """Run the pre-compaction silent flush turn if conditions met.

        Reference: existing pre-compaction-flush flow in acp_bridge
        + ``cfg.memory_flush_*`` config. Fires when ALL of:

        * ``cfg.memory_flush_enabled`` is True.
        * Estimated tokens cross ``ctx − reserve_floor − soft_threshold``.
        * ``session.compaction_count > session.memory_flush_compaction_count``
          (haven't already flushed in this cycle).

        Spawns a silent turn through ``self.engine.run_turn`` with a
        directive prompt instructing the model to save context to
        MEMORY.md / memory/YYYY-MM-DD.md. After the turn, runs
        ``self.memory_index_all()`` so the saved notes are
        searchable next turn. Then bumps
        ``session.memory_flush_compaction_count`` so we don't refire
        inside the same cycle.

        Returns ``(fired, audit_message)``.
        """
        if not getattr(self.cfg, "memory_flush_enabled", False):
            return False, "memory_flush_disabled"

        # First-turn gate. A fresh session has ``compaction_count==0``
        # and ``memory_flush_compaction_count==-1`` (default). Without
        # this guard the first ``record_turn`` would trigger a flush
        # turn before the agent has done anything worth saving and
        # recursively re-enter ``run_turn`` against the test mock,
        # hanging it. The flush is meaningful only AFTER at least one
        # compaction has fired.
        cur_compaction = int(getattr(session, "compaction_count", 0) or 0)
        if cur_compaction <= 0:
            return False, "no_compaction_yet"

        # Cycle gate — refuse to flush twice within the same
        # compaction generation.
        last_flush = int(
            getattr(session, "memory_flush_compaction_count", -1) or -1
        )
        if last_flush >= cur_compaction:
            return False, "already_flushed_this_cycle"

        # Threshold math — approximate. The local-LLM engine has
        # cheaper access to the live message-list token estimate;
        # at the Agent level we just check that the context window
        # is configured so this is enabled at all.
        ctx = int(getattr(self.cfg, "upstream_max_context", 0) or 0)
        reserve = int(
            getattr(self.cfg, "memory_flush_reserve_tokens_floor", 0) or 0
        )
        soft = int(
            getattr(self.cfg, "memory_flush_soft_threshold_tokens", 0) or 0
        )
        if ctx <= 0:
            return False, "no_context_window"
        budget = max(0, ctx - reserve - soft)
        if budget <= 0:
            return False, "no_flush_budget"

        # Fire a silent agentic turn instructing the model to save
        # context to MEMORY.md. The local-LLM engine implements the
        # actual saved-prompt drive; from the Agent we open one turn
        # against ``session.hash`` with a flush directive prompt.
        flush_prompt = (
            "[MEMORY FLUSH] Persist the most important state from "
            "this session to MEMORY.md or memory/<YYYY-MM-DD>.md "
            "before the next compaction. Use Write/Edit only. "
            "Reply with [MEMORY_FLUSH_DONE] when finished."
        )
        try:
            from .engine import TurnDone
            done_ok = False
            async for ev in self.run_turn(
                session.hash,
                flush_prompt,
                mode=self._effective_mode(session),
            ):
                if isinstance(ev, TurnDone):
                    done_ok = ev.state == "ok"
                    break
            # Persist that we've flushed for this compaction cycle.
            session.memory_flush_compaction_count = cur_compaction
            import datetime as _dt
            session.last_memory_flush_at = _dt.datetime.now().astimezone().isoformat()
            try:
                session.save(root=self.sessions_dir, force=True)
            except Exception:  # noqa: BLE001
                pass
            # Re-index notes so the flushed content is searchable.
            self.memory_index_all()
            return done_ok, "flush_completed" if done_ok else "flush_failed"
        except Exception as exc:  # noqa: BLE001
            return False, f"flush_error:{exc}"

    def memory_index_all(self) -> None:
        """Re-build the agent's local memory index.

        Reference: ``rtxclaw_core.memory_manager`` post-flush rebuild
        (today driven by ``force_post_compaction_index``).
        """
        try:
            from rtxclaw_memory.memory_index import MemoryIndex
            try:
                from rtxclaw_memory.memory_embed import resolve_embedder
                embedder = resolve_embedder()
            except Exception:  # noqa: BLE001
                embedder = None
            idx = MemoryIndex(self.cfg.home, embedder=embedder)
            idx.index_all()
        except Exception:  # noqa: BLE001
            # Indexing is best-effort; never block the caller.
            return

    # ---- heartbeat -------------------------------------------------

    def start_heartbeat(self) -> Optional["asyncio.Task[None]"]:
        """Start the periodic background heartbeat task.

        Reference: ``rtxclaw_agent.heartbeat.HeartbeatScheduler``
        (heartbeat.py L152). When ``cfg.heartbeat_enabled`` is True,
        spawns a task that:

        * Maintains a DEDICATED heartbeat session (one per agent, not
          per chat) so the prefix cache stays warm.
        * Every ``cfg.heartbeat_interval_s`` (default 1800 = 30 min),
          fires one turn into that session via ``engine.run_turn``.
        * The prompt is the standard ``HEARTBEAT_PROMPT`` plus the
          contents of ``HEARTBEAT.md``; the model decides whether to
          do background work (memory synth, idle cleanup) or reply
          ``HEARTBEAT_OK`` and stay quiet.
        * State (current heartbeat sid, per-session last-analyzed
          turn idx) lives in ``<home>/heartbeat-state.json``.

        Returns the task handle, or ``None`` if heartbeat is disabled.
        """
        if not getattr(self.cfg, "heartbeat_enabled", False):
            return None
        if getattr(self, "_heartbeat_scheduler", None) is not None:
            # Already running.
            return getattr(self._heartbeat_scheduler, "_task", None)
        try:
            from rtxclaw_agent.heartbeat import HeartbeatScheduler

            # HeartbeatScheduler expects an AgentApp-shaped object
            # exposing ``_read_session_file``, ``_resolve_model``,
            # ``turns``, and a way to fire turns. Build a thin shim
            # over this Agent so the scheduler keeps working
            # uniformly for both local-LLM and CLI agents.
            scheduler = HeartbeatScheduler(self.cfg, self._build_heartbeat_app_shim())
            self._heartbeat_scheduler = scheduler
            import asyncio
            task = asyncio.create_task(scheduler.start())
            return task
        except Exception:  # noqa: BLE001
            self._heartbeat_scheduler = None
            return None

    async def stop_heartbeat(self) -> None:
        """Cancel + drain the heartbeat task."""
        scheduler = getattr(self, "_heartbeat_scheduler", None)
        if scheduler is None:
            return
        try:
            await scheduler.stop()
        except Exception:  # noqa: BLE001
            pass
        finally:
            self._heartbeat_scheduler = None

    # ---- delegate-as-tool compatibility ----------------------------

    def delegate_sidecar_path(
        self, parent_sid: str, kind: EngineKind
    ) -> Path:
        """Legacy sidecar path for ``delegate_<kind>`` tool result resume.

        Returns ``<parent_agent.sessions_dir>/<parent_sid>.delegate_<kind>.json``.
        Reads/writes this file when the Agent is operating as a child
        of a ``delegate_claude`` / ``delegate_codex`` / ``delegate_antigravity``
        tool call, so an in-flight chain from before the refactor
        keeps resuming after upgrade (T11 in the regression list).

        Under the new architecture, the rtxclaw model that calls
        ``delegate_claude(prompt=…)`` actually triggers:

            child_agent = factory.load_agent("claude")  # the built-in
            child_session = child_agent.create_session()  # or resume by sidecar
            return child_agent.run_turn(child_session, prompt=…)

        — i.e. "delegate as a tool" and "agent IS Claude" collapse to
        one code path.
        """
        # Map EngineKind → the legacy filename suffix today's
        # delegate runners write (``.delegate_<cli>.json``).
        suffix_map = {
            EngineKind.CLAUDE_CLI: "delegate_claude",
            EngineKind.CODEX_CLI: "delegate_codex",
            EngineKind.ANTIGRAVITY_CLI: "delegate_antigravity",
        }
        suffix = suffix_map.get(kind)
        if suffix is None:
            # Local LLM / unknown → fall back to engine-kind tag
            # so callers always get a deterministic path.
            suffix = f"delegate_{getattr(kind, 'value', str(kind))}"
        return self.sessions_dir / f"{parent_sid}.{suffix}.json"

    # ---- ACP / openai-compat translation ---------------------------
    #
    # The gateway speaks ACP today and a thin OpenAI-compatible REST
    # endpoint (``rtxclaw_agent.openai_endpoint``). Both consume the
    # ``AgentTurnEvent`` stream the Agent emits. The Agent provides
    # two small adapters so the gateway code stays simple.

    # ---- internal helpers ------------------------------------------

    def _load_hook_engine(self) -> Any:
        """Lazy-load + cache the agent's Claude Code :class:`HookEngine`.

        Sourced from ``cfg.hooks_path`` (the resolved
        ``<agent_home>/hooks.json`` by default; ``cfg.hooks_file`` for
        older configs). Also derives ``_hook_plugin_root`` — the
        ``CLAUDE_PLUGIN_ROOT`` exported to every hook command — from
        the hooks file's location: a file inside a ``hooks/`` dir (the
        Claude Code plugin layout, e.g. ``…/ecc/hooks/hooks.json``)
        roots at its grandparent, otherwise at its parent. Returns
        ``None`` on any failure so callers always treat hooks as
        best-effort. The cached instance is reused for the agent's
        lifetime — operators reloading hooks should bounce the agent.
        """
        if self._hook_engine is not None:
            return self._hook_engine
        try:
            from rtxclaw_core.hooks import HookEngine

            hooks_path = (
                getattr(self.cfg, "hooks_path", None)
                or getattr(self.cfg, "hooks_file", None)
            )
            if hooks_path:
                hp = Path(hooks_path)
                engine = HookEngine.load(hp)
                root = hp.parent.parent if hp.parent.name == "hooks" else hp.parent
                self._hook_plugin_root = str(root)
            else:
                engine = HookEngine.load(None)
                self._hook_plugin_root = ""
            # Merge enabled-plugin hooks.json files so a Claude-Code
            # plugin bundle that ships ``hooks/hooks.json`` (or a
            # top-level ``hooks.json``) fires here too — agent-local
            # rules first, then plugins in discovery order.
            try:
                from rtxclaw_core.plugins import list_plugins
                plug_engines: list[Any] = []
                for p in list_plugins():
                    if not p.enabled or p.hooks_file is None:
                        continue
                    pe = HookEngine.load(p.hooks_file)
                    if not pe.is_empty():
                        plug_engines.append(pe)
                if plug_engines:
                    engine = HookEngine.merge([engine] + plug_engines)
            except Exception:  # noqa: BLE001
                pass
        except Exception:  # noqa: BLE001
            return None
        self._hook_engine = engine
        # Wire the process-wide active engine so logging-side callers
        # (e.g. ``rtxclaw_core.errors.log_error`` firing ``SessionError``)
        # can fire hooks without needing an Agent reference. A gateway
        # may host multiple Agents — register under our own ``name`` so
        # an error from agent A does NOT trigger agent B's hooks.
        try:
            from rtxclaw_core.hooks import set_active_engine
            set_active_engine(engine, agent_name=self.name)
        except Exception:  # noqa: BLE001
            pass
        return engine

    def _build_heartbeat_app_shim(self) -> Any:
        """Build a HeartbeatScheduler-compatible app shim around this Agent.

        The legacy scheduler expects an ``AgentApp``-shaped object
        with ``_read_session_file``, ``_resolve_model``, ``turns``
        (an empty dict-of-TurnState is fine for new-architecture
        agents that don't share the legacy in-flight map), and a
        ``session_turn`` method. The shim forwards each to the
        Agent / engine.
        """
        agent = self

        class _HeartbeatAppShim:
            def __init__(self) -> None:
                # Empty in-flight turns map — the legacy scheduler
                # only reads this to skip ticks when an existing
                # turn on the heartbeat session is still running.
                # New-architecture in-flight tracking lives on the
                # engine; we surface zero turns so the scheduler
                # always fires (engine-level locking serializes).
                self.turns: dict[str, Any] = {}

            def _read_session_file(self, sid: str) -> Optional[dict[str, Any]]:
                # header from sessions.db + turns folded from JSONL.
                sess = agent.get_session(sid)
                if sess is None:
                    return None
                d = agent_session_to_dict(sess)
                return d

            async def _resolve_model(self) -> str:
                return (
                    getattr(agent.cfg, "upstream_model", "")
                    or agent.engine.kind.value
                )

            async def session_turn(self, sid: str, prompt: str) -> None:
                from .engine import TurnDone
                async for ev in agent.run_turn(sid, prompt):
                    if isinstance(ev, TurnDone):
                        break

        return _HeartbeatAppShim()
