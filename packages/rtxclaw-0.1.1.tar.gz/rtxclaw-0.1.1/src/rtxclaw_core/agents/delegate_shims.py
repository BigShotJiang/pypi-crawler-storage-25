"""Cross-agent delegate-tool shims.

Holds the four ``delegate_*`` tool-runner shims that let an agent
dispatch a turn against another agent (``/claude``, ``/codex``,
``/antigravity``, ``/delegate <name>``). Each shim loads the named child
agent through :func:`factory.load_agent`, opens / resumes a session
keyed off the parent sid, drives one turn via :meth:`Agent.run_turn`,
and assembles a :class:`ToolResult` whose ``content`` is the same
shape the legacy delegate runner emitted (so model transcript replay
is byte-stable across the cutover).

Renamed from ``legacy_compat`` at 2026-05-15 once the sidecar /
session-record migration helpers and the tool-call inline-marker
backfill that justified the old name were deleted — the remaining
content is the live cross-agent dispatch path, not legacy support.
"""

from __future__ import annotations

from typing import Any, Callable, Optional


async def _drive_child_agent_turn(
    short_name: str,
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Common driver for the four ``shim_run_delegate_*`` shims.

    Loads the named child agent, opens (or resumes) a session keyed
    off the parent sid, dispatches one turn, and assembles a
    :class:`ToolResult` whose ``content`` is the same shape the
    delegate runner emits.
    """
    import os
    # Subagent-minimal boot: when the parent dispatcher spawned us as
    # a dedicated per-subagent ``rtxclaw_core.tool_runner`` subprocess
    # (env ``RTXCLAW_SUBAGENT_MINIMAL=1`` set by
    # ``_spawn_subagent_runner``), skip the heavy gateway-side side
    # effects: MCP server discovery, skill-index rebuild, memory
    # provider init. ``Agent.run_turn`` lazy-loads each of these only
    # when the child config asks for them, so default subagents boot
    # in well under a second instead of paying the full gateway cost.
    # Surfaced as an env hint rather than an arg so the in-process
    # gather fallback ``RTXCLAW_SUBAGENT_INPROCESS=1`` doesn't need
    # to thread the flag through.
    if os.environ.get("RTXCLAW_SUBAGENT_MINIMAL") == "1":
        os.environ.setdefault("RTXCLAW_SKIP_MCP_DISCOVERY", "1")
        os.environ.setdefault("RTXCLAW_SKIP_SKILL_INDEX_REBUILD", "1")
        os.environ.setdefault("RTXCLAW_SKIP_MEMORY_PROVIDER", "1")
    from rtxclaw_core.tools.runners import ToolResult
    from . import factory
    from .engine import TurnDone, TurnError, TextDelta, ToolCallStarted, ToolCallResult

    try:
        child = factory.load_agent(short_name)
    except FileNotFoundError:
        return ToolResult(
            content=f"[delegate {short_name}: no agent scaffolded — install the CLI and retry]",
            ok=False,
        )
    except Exception as exc:  # noqa: BLE001
        return ToolResult(
            content=f"[delegate {short_name}: load_agent failed: {exc}]",
            ok=False,
        )

    available, reason = child.engine.is_available()
    if not available:
        return ToolResult(
            content=f"[delegate {short_name}: {reason}]", ok=False,
        )

    # Resolve / create the child session keyed off the parent sid.
    #
    # The slash-command direct-dispatch path (/claude /codex /antigravity via
    # ``LocalLLMEngine._run_direct_tool_call``) runs us IN-PROCESS inside
    # the long-lived gateway, where ``RTXCLAW_SESSION_ID`` is NOT in
    # ``os.environ`` — ``acp_bridge`` only stamps it on the tool_runner
    # SUBPROCESS env. Reading the env alone yielded ``""`` there, so the
    # child session was recreated fresh on every call (no ``--resume``,
    # no parent→child link sidecar). Prefer an explicit
    # ``_rtxclaw_parent_session_id`` arg the caller threads in; fall back
    # to the env var for the subprocess tool-call path.
    parent_sid = str(
        args.get("_rtxclaw_parent_session_id")
        or os.environ.get("RTXCLAW_SESSION_ID")
        or ""
    )
    # A session per subagent. The ``Agent`` / ``BatchAgent`` tool path
    # threads a unique ``_rtxclaw_call_id`` per dispatch; the
    # slash-command path (/claude /codex /antigravity) does not. When a
    # call id is present we key the child session per CALL (one fresh
    # session per subagent invocation) instead of per (parent, engine).
    # Without this, a 2nd ``Agent(subagent_type="codex")`` under the
    # same parent RESUMED the 1st codex child session — N subagents
    # collapsed into one shared session (and concurrent batch fan-out
    # raced on it). Same call id (a tool-retry) still resumes; distinct
    # call ids get distinct sessions. The slash-command continuing-
    # conversation UX is unchanged (no call id → per-engine resume).
    subagent_call_id = str(args.get("_rtxclaw_call_id") or "").strip()

    def _sidecar_path() -> Any:
        base = child.delegate_sidecar_path(parent_sid, child.engine.kind)
        if not subagent_call_id:
            return base
        # ``<parent>.delegate_<kind>.json`` → ``<parent>.subagent.<cid>.delegate_<kind>.json``
        safe_cid = subagent_call_id.replace("/", "_").replace(".", "_")
        tail = base.name.split(".", 1)[1] if "." in base.name else base.name
        return base.with_name(f"{parent_sid}.subagent.{safe_cid}.{tail}")

    child_sid = ""
    if parent_sid:
        sidecar = _sidecar_path()
        if sidecar.exists():
            try:
                import json as _json
                data = _json.loads(sidecar.read_text(encoding="utf-8"))
                child_sid = (
                    data.get("rtxclaw_child_session_id")
                    or data.get("rtxclaw_session_id")
                    or ""
                )
            except (OSError, _json.JSONDecodeError):
                child_sid = ""

    if not child_sid or child.get_session(child_sid) is None:
        # Stamp the FULL parent rtxclaw session id (not a 12-char prefix)
        # so the delegate session carries an exact back-link to the parent
        # that spawned it.
        sess = child.create_session(
            workspace_cwd=args.get("cwd") or "",
            workspace_origin=(
                f"delegate:{parent_sid}" if parent_sid else "delegate:"
            ),
            # First-class back-link: this child session IS a subagent of
            # ``parent_sid``. Mirrors the ``delegate:{parent_sid}``
            # workspace_origin but in a dedicated, queryable field.
            parent_session_id=parent_sid,
        )
        child_sid = sess.hash
        # Record the mapping so a retry of the SAME call resumes the same
        # child session (per-call sidecar when a call id is present;
        # per-engine sidecar for the slash-command path).
        if parent_sid:
            try:
                import json as _json
                sidecar = _sidecar_path()
                sidecar.parent.mkdir(parents=True, exist_ok=True)
                sidecar.write_text(
                    _json.dumps({
                        "rtxclaw_session_id": parent_sid,
                        "rtxclaw_child_session_id": child_sid,
                        "engine": child.engine.kind.value,
                        "subagent_call_id": subagent_call_id,
                    }, ensure_ascii=False),
                    encoding="utf-8",
                )
            except Exception:  # noqa: BLE001
                pass

    prompt = str(args.get("prompt") or args.get("task") or "")
    mode = str(args.get("mode") or os.environ.get("RTXCLAW_PERMISSION_MODE") or "auto")
    cwd = args.get("cwd") or None
    model = args.get("model") or None

    buf: list[str] = []
    ok = True
    last_error = ""

    async for ev in child.run_turn(
        child_sid, prompt, mode=mode, cwd=cwd, model=model,
    ):
        if isinstance(ev, TextDelta):
            if ev.channel != "tool_delta" and ev.text:
                buf.append(ev.text)
                if on_delta is not None:
                    try:
                        res = on_delta(ev.text)
                        if hasattr(res, "__await__"):
                            await res
                    except Exception:  # noqa: BLE001
                        pass
        elif isinstance(ev, ToolCallStarted):
            if on_event is not None:
                try:
                    res = on_event({
                        "kind": "tool_use",
                        "id": ev.call_id,
                        "name": ev.name,
                        "input": dict(ev.arguments or {}),
                    })
                    if hasattr(res, "__await__"):
                        await res
                except Exception:  # noqa: BLE001
                    pass
        elif isinstance(ev, ToolCallResult):
            if on_event is not None:
                try:
                    res = on_event({
                        "kind": "tool_result",
                        "tool_use_id": ev.call_id,
                        "ok": ev.ok,
                        "text": ev.content,
                    })
                    if hasattr(res, "__await__"):
                        await res
                except Exception:  # noqa: BLE001
                    pass
        elif isinstance(ev, TurnError):
            last_error = ev.message
        elif isinstance(ev, TurnDone):
            ok = ev.state == "ok"
            break

    body = "".join(buf)
    if not ok and last_error and last_error not in body:
        body = (body + "\n\n" + last_error).strip()

    # Read the child engine's OWN CLI session id (claude/codex/antigravity
    # resume token) that the child engine wrote into its
    # ``<child_sid>.<engine>.json`` state during run_turn.
    engine_sid = ""
    if child_sid:
        try:
            state = child.engine.read_state(child.sessions_dir, child_sid)
            engine_sid = str(getattr(state, "engine_session_id", "") or "")
        except Exception:  # noqa: BLE001
            engine_sid = ""
    # Surface the link back to the direct-dispatch caller
    # (LocalLLMEngine._run_direct_tool_call) so the PARENT session also
    # records the rtxclaw↔engine session id in its log + sessions.db.
    if isinstance(args, dict):
        args["_rtxclaw_engine_session_id_out"] = engine_sid
        args["_rtxclaw_child_session_id_out"] = child_sid

    # Persist the full mapping parent_sid → child_sid → engine_session_id
    # in one sidecar the operator can correlate. Best-effort — never fail
    # the turn over a bookkeeping write.
    if parent_sid and child_sid:
        try:
            import json as _json
            sidecar = _sidecar_path()
            sidecar.parent.mkdir(parents=True, exist_ok=True)
            sidecar.write_text(
                _json.dumps({
                    "rtxclaw_session_id": parent_sid,
                    "rtxclaw_child_session_id": child_sid,
                    "engine": child.engine.kind.value,
                    "engine_session_id": engine_sid,
                    "subagent_call_id": subagent_call_id,
                }, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:  # noqa: BLE001
            pass

    return ToolResult(content=body, ok=ok)


async def shim_run_delegate_claude_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Drive one Claude CLI turn keyed off the parent's session id."""
    return await _drive_child_agent_turn(
        "claude", args, on_delta=on_delta, on_event=on_event,
    )


async def shim_run_delegate_codex_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Drive one Codex CLI turn keyed off the parent's session id.

    ``on_event`` is forwarded so Codex's inner tool calls surface as
    structured events the frontend can gate on ``/tools`` — see
    :meth:`CodexCliEngine.supports_on_event`. Without it the engine
    inlines the ``🔧 bash …`` markers into the reply body, which always
    renders, leaking tool calls under ``/tools off``.
    """
    return await _drive_child_agent_turn(
        "codex", args, on_delta=on_delta, on_event=on_event,
    )


async def shim_run_delegate_antigravity_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Drive one Gemini CLI turn keyed off the parent's session id.

    ``on_event`` forwarded for the same reason as the codex shim.
    """
    return await _drive_child_agent_turn(
        "antigravity", args, on_delta=on_delta, on_event=on_event,
    )


async def shim_run_delegate_agent_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Dispatch one turn against a sibling rtxclaw agent.

    Works uniformly across engine kinds because the work is performed
    by ``Agent.run_turn`` on the target child agent.
    """
    # Accept every alias smaller-context LLMs typically reach for —
    # the canonical schema parameter is ``name`` but deepseek-v4-pro /
    # qwen / kimi often emit ``agent_id`` / ``agent_name`` / ``agent``
    # / ``target`` on the first attempt. Round-tripping a 4-round
    # tool-error recovery just to relearn the field name is wasteful
    # when the intent is unambiguous; normalise here so the FIRST
    # call lands.
    target = str(
        args.get("name")
        or args.get("agent")
        or args.get("agent_id")
        or args.get("agent_name")
        or args.get("target")
        or args.get("to")
        or ""
    )
    if not target:
        from rtxclaw_core.tools.runners import ToolResult
        return ToolResult(
            content=(
                "[delegate_agent: missing target agent — pass `name` "
                "(canonical) or any of agent / agent_id / agent_name "
                "/ target / to. Available agents: see ~/.rtxclaw/agents/]"
            ),
            ok=False,
        )
    # Normalise back to the canonical key + accept ``prompt`` /
    # ``message`` as task synonyms (registry says ``task``, but
    # delegate_claude / delegate_codex use ``prompt`` and the LLM
    # carries that habit over).
    args = dict(args)
    args["name"] = target
    if "task" not in args:
        for k in ("prompt", "message", "input"):
            v = args.get(k)
            if isinstance(v, str) and v.strip():
                args["task"] = v
                break
    return await _drive_child_agent_turn(
        target, args, on_delta=on_delta, on_event=on_event,
    )
