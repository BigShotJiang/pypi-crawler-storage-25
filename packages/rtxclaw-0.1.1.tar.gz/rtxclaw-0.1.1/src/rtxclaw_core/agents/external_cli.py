"""``ExternalCliEngine`` — shared base for CLI-backed engines.

Hosts the shared ``run_turn`` driver that adapts every CLI engine's
:meth:`delegate_runner` (a wrapper around the legacy
``run_delegate_*_async`` helper) into the uniform
:data:`AgentTurnEvent` stream. Subclasses
(``ClaudeCliEngine`` / ``CodexCliEngine`` / ``AntigravityCliEngine``)
configure the per-CLI argv assembly, permission-mode mapping, and
event-parsing details. The CLI subprocess plumbing duplicated across
the three legacy runners lives there:

* ``run_delegate_claude_async`` (runners.py)
* ``run_delegate_codex_async``  (runners.py)
* ``run_delegate_antigravity_async`` (runners.py)

Subclasses (``ClaudeCliEngine`` / ``CodexCliEngine`` / ``AntigravityCliEngine``)
override the parts that actually differ: CLI argv assembly, permission-
mode mapping, stream-JSON event parser, and the engine-specific tool-name
dictionary.

Every helper here corresponds to a named function in today's
``runners.py``; the docstring cites the source so the implementer can
re-read the authoritative version while filling in the body.
"""

from __future__ import annotations

import asyncio
import os
import signal
from abc import abstractmethod
from pathlib import Path
from typing import Any, AsyncIterator, Optional

# Grace window for a friendly CLI-bridge abort: on ``/abort`` (first
# press) we send SIGINT and let the delegated ``claude -p`` / ``codex`` /
# ``antigravity`` subprocess wind down — flushing its reply and its own
# ``--resume`` session file — for up to this many seconds before
# escalating to SIGTERM→SIGKILL. Tunable via env for slow models.
CLI_GRACEFUL_ABORT_S: float = float(
    os.environ.get("RTXCLAW_CLI_GRACEFUL_ABORT_S", "15") or "15"
)

from .engine import (
    AgentTurnEvent,
    Engine,
    EngineKind,
    EngineSessionState,
    TextDelta,
    ToolCallResult,
    ToolCallStarted,
    TurnDone,
    TurnError,
    TurnRequest,
    TurnStarted,
)


class ExternalCliEngine(Engine):
    """Shared scaffolding for CLI-backed engines.

    Each subclass is responsible for telling this base class:

    * **what CLI to spawn** — via :meth:`build_argv`
    * **how to pipe in the prompt** — default is stdin (mirrors all three
      delegates today; see runners.py L1565–1576 on the ARG_MAX
      rationale). Subclasses can override if a CLI behaves differently.
    * **what permission mode flags to pass** — via :meth:`permission_flags`
    * **how to parse stream-JSON lines** — via :meth:`parse_stream_event`
    * **how to extract the engine's own session id** from those events —
      via :meth:`extract_session_id`
    * **how to format the in-band tool markers** that get appended to
      ``text_buf`` so the persisted body is identical to today — via
      :meth:`format_tool_use_marker` / :meth:`format_tool_result_marker`

    The base class owns:

    * Process spawn + ``start_new_session=True`` (runners.py L1589, L2100,
      L1294).
    * Stdin feed via ``_feed_stdin`` (runners.py L42–63).
    * Stdout read-loop with the 16 MiB readline-bypass and JSONDecode
      tolerance (runners.py L1696–1714).
    * Cancellation → SIGTERM-group → SIGKILL-group fallthrough
      (runners.py L1803–1813).
    * Exit-code + error-event triage → tool-result error formatting
      (runners.py L1827–1899, L2225–2289, L1430–1489).
    * Sidecar I/O with legacy-key tolerance (see ``EngineSessionState``).
    * Result body assembly (header / body / footer) and truncation
      (runners.py L1904–1926, L2269–2289, L1473–1489).
    * Structured logging via ``_log_delegate_error`` (runners.py L970).
    """

    # Subclasses MUST set both.
    kind: EngineKind
    cli_command: str  # the executable name ("claude" / "codex" / "antigravity")
    install_url: str = ""  # surfaced when the CLI is not on PATH

    def __init__(self) -> None:
        # Per-engine in-memory state. Each ``run_turn`` registers
        # its driver-task in ``_active_procs[turn_id]`` so ESC can
        # route through :meth:`abort`. The legacy ``run_delegate_*``
        # runners handle their own subprocess group-kill on
        # ``CancelledError``, so cancelling the driver task is
        # sufficient — the legacy runner's ``finally`` block does
        # the SIGTERM/SIGKILL on the spawned CLI.
        self._active_procs: dict[str, Any] = {}
        # Per-turn handle to the live CLI subprocess (populated by the
        # runner via its ``on_spawn`` callback) so :meth:`abort` can send
        # a friendly SIGINT to the process group and wait for a clean
        # wind-down before escalating to a hard kill.
        self._active_cli_procs: dict[str, Any] = {}
        self._session_locks: dict[str, asyncio.Lock] = {}

    def _session_model(self, rtxclaw_sid: str) -> str:
        """Return the per-session model override an engine subclass has
        stored via :meth:`set_config_option`, or ``""`` when none.

        :meth:`run_turn` consults this before falling back to the
        engine's built-in default (no ``--model`` flag). Subclasses
        that implement model selection expose a ``session_model(sid)``
        accessor (see :class:`AntigravityCliEngine`); subclasses that don't
        return ``""``.
        """
        getter = getattr(self, "session_model", None)
        if callable(getter):
            try:
                return str(getter(rtxclaw_sid) or "")
            except Exception:  # noqa: BLE001
                return ""
        return ""

    def _materialize_image_parts(
        self, prompt_parts: list[dict[str, Any]],
    ) -> tuple[list[str], list[Path]]:
        """Resolve every ``image_url`` part to a local filesystem path.

        Returns ``(paths, temp_files)``:

        * ``paths`` — every resolved local path, in prompt order, for
          :meth:`run_turn` to inline into the prompt text. The CLI
          subprocess can't see an inline base64 blob; the supported
          CLIs (claude / codex / antigravity) all read images off disk via
          their own file-reading tool, so we hand them a path instead.
        * ``temp_files`` — the subset of ``paths`` this call created
          (``data:`` decode / ``http(s)`` fetch). The caller MUST
          unlink these after the CLI subprocess exits. ``file://`` and
          bare local paths are inlined but never returned here — we
          didn't create them, so there's nothing to clean up.

        Mirrors the URL handling in
        :meth:`ClaudeCliEngine.prime_first_turn_prompt` — kept here as
        the live ``run_turn`` path's own copy because that method is
        only consumed by the not-yet-wired native-priming path.
        """
        import base64
        import tempfile
        import uuid

        paths: list[str] = []
        temp_files: list[Path] = []
        for part in (prompt_parts or []):
            if not isinstance(part, dict) or part.get("type") != "image_url":
                continue
            image_url = part.get("image_url")
            url: Optional[str] = None
            if isinstance(image_url, dict):
                u = image_url.get("url")
                if isinstance(u, str):
                    url = u
            elif isinstance(image_url, str):
                url = image_url
            if not url:
                continue

            if url.startswith("data:"):
                # data:image/<ext>;base64,<payload>
                try:
                    header, _, payload = url.partition(",")
                    meta = header[len("data:"):]
                    mime = meta.split(";")[0] if meta else "image/png"
                    ext = mime.split("/")[-1] if "/" in mime else "png"
                    raw_bytes = base64.b64decode(payload)
                    tmp = tempfile.NamedTemporaryFile(
                        prefix=f"rtxclaw-attach-{uuid.uuid4().hex[:8]}-",
                        suffix=f".{ext}",
                        delete=False,
                    )
                    try:
                        tmp.write(raw_bytes)
                    finally:
                        tmp.close()
                    paths.append(tmp.name)
                    temp_files.append(Path(tmp.name))
                except (ValueError, base64.binascii.Error, OSError):
                    continue
            elif url.startswith("http://") or url.startswith("https://"):
                try:
                    import httpx  # local import — only on http(s) urls
                    resp = httpx.get(url, timeout=5.0, follow_redirects=True)
                    resp.raise_for_status()
                    ctype = resp.headers.get("content-type", "image/png")
                    ext = ctype.split(";")[0].split("/")[-1] or "png"
                    tmp = tempfile.NamedTemporaryFile(
                        prefix=f"rtxclaw-attach-{uuid.uuid4().hex[:8]}-",
                        suffix=f".{ext}",
                        delete=False,
                    )
                    try:
                        tmp.write(resp.content)
                    finally:
                        tmp.close()
                    paths.append(tmp.name)
                    temp_files.append(Path(tmp.name))
                except Exception:  # noqa: BLE001
                    continue
            elif url.startswith("file://"):
                paths.append(url[len("file://"):])
            else:
                # Bare local path — inline as-is, nothing to clean up.
                paths.append(url)
        return paths, temp_files

    # ---- subclass surface -------------------------------------------

    @abstractmethod
    def resume_footer(self) -> str:
        """Engine-specific footer steering the model on its NEXT turn.

        Today: ``[claude --resume note: …]`` / ``[codex resume note: …]``
        / ``[antigravity --resume note: …]`` blocks at the tail of the
        tool-result body. Stable wording (no timestamps) so the
        in-context replay is cache-friendly.
        """

    # ---- Engine ABC methods (concrete here, parametrized by subclass) -

    @property
    def name(self) -> str:
        # Subclasses override; tag is the CLI short name.
        return self.cli_command or "external_cli"

    def state_path(self, sessions_dir: Path, rtxclaw_sid: str) -> Path:
        """``<sessions_dir>/<sid>.<engine>.json``."""
        return Path(sessions_dir) / f"{rtxclaw_sid}.{self.kind.value}.json"

    def read_state(
        self, sessions_dir: Path, rtxclaw_sid: str
    ) -> EngineSessionState:
        """Read sidecar JSON. Tolerates the legacy single-key shapes
        (``claude_session_id``, ``codex_thread_id``,
        ``antigravity_session_id``) so an in-flight chain from before the
        refactor keeps resuming.
        """
        import json
        state = EngineSessionState(
            rtxclaw_session_id=rtxclaw_sid,
            engine=self.kind,
        )
        path = self.state_path(Path(sessions_dir), rtxclaw_sid)
        if not path.exists():
            # Fall back to the legacy delegate sidecar — same parent
            # sid hit by the historical `delegate_<kind>` tool runs.
            legacy_path = (
                Path(sessions_dir)
                / f"{rtxclaw_sid}.delegate_{self.cli_command}.json"
            )
            path = legacy_path if legacy_path.exists() else path
        if not path.exists():
            return state
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return state
        if not isinstance(data, dict):
            return state
        # New normalized shape.
        eid = data.get("engine_session_id") or ""
        # Legacy fallbacks (pre-refactor sidecars).
        if not eid:
            eid = (
                data.get("claude_session_id")
                or data.get("codex_thread_id")
                or data.get("antigravity_session_id")
                or ""
            )
        state.engine_session_id = str(eid or "")
        state.priming_status = str(
            data.get("priming_status")
            or ("completed" if eid else "never")
        )
        state.priming_system_prompt_sha256 = str(
            data.get("priming_system_prompt_sha256") or ""
        )
        state.last_used_at = str(data.get("last_used_at") or "")
        state.last_error = str(data.get("last_error") or "")
        state.spawn_cwd = str(data.get("spawn_cwd") or "")
        return state

    def write_state(
        self, sessions_dir: Path, state: EngineSessionState
    ) -> None:
        """Persist sidecar atomically (best-effort)."""
        import json
        path = self.state_path(Path(sessions_dir), state.rtxclaw_session_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "rtxclaw_session_id": state.rtxclaw_session_id,
            "engine": state.engine.value,
            "engine_session_id": state.engine_session_id,
            "priming_status": state.priming_status,
            "priming_system_prompt_sha256": state.priming_system_prompt_sha256,
            "last_used_at": state.last_used_at,
            "last_error": state.last_error,
            "spawn_cwd": state.spawn_cwd,
        }
        try:
            path.write_text(
                json.dumps(payload, ensure_ascii=False), encoding="utf-8",
            )
        except OSError:
            pass

    # ---- subclass hook: which legacy runner to delegate to --------
    #
    # Phase 4 strategy: rather than reimplement the full subprocess /
    # sidecar / SIGTERM / stream-parse / error-retry pipeline from
    # scratch, each CLI engine delegates to its corresponding legacy
    # ``rtxclaw_core.tools.runners.run_delegate_*_async`` helper.
    # That helper already implements every behavior the user said
    # "can't lose" — stdin priming, ARG_MAX avoidance, session
    # resume sidecar, group-kill on CancelledError, stale-resume
    # retry (Claude), structured logging, truncation. The Engine
    # wraps it with ``on_delta`` / ``on_event`` callbacks that yield
    # :class:`AgentTurnEvent` instances to the Agent layer.

    @abstractmethod
    def delegate_runner(self) -> Any:
        """Return the legacy ``run_delegate_<kind>_async`` callable.

        Each subclass returns its matching legacy runner. The runner
        signature is approximately
        ``async def run_delegate_<x>_async(args: dict, *, on_delta=None,
        on_event=None) -> ToolResult``.
        """

    def supports_on_event(self) -> bool:
        """Whether the subclass's delegate runner accepts the
        ``on_event`` callback. Only Claude does today (it surfaces
        structured ``tool_use`` / ``tool_result`` blocks)."""
        return False

    async def run_turn(  # type: ignore[override]
        self,
        request: TurnRequest,
        state: EngineSessionState,
        *,
        sessions_dir: Path,
        turn_id: str,
        env: Optional[dict[str, str]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Drive one CLI turn end-to-end.

        Phase 4 implementation strategy: delegate to the legacy
        ``run_delegate_*_async`` helper via :meth:`delegate_runner`,
        translating its callbacks to :data:`AgentTurnEvent` yields.
        This guarantees byte-identical CLI-side behavior to the
        legacy delegate-as-tool path; the Engine wrapper adds:

        * The first-call vs resume policy (system prompt rides on
          ``--append-system-prompt`` / first-message injection on the
          first call; later calls use ``--resume <id>``).
        * sha-change detection so an operator who edits SOUL.md
          between turns gets a fresh CLI session.
        * Uniform :data:`AgentTurnEvent` stream for the gateway / ACP
          translator.
        * Per-session state sidecar (replaces ``<sid>.delegate_<kind>.json``).
        """
        import asyncio as _asyncio

        rtxclaw_sid = state.rtxclaw_session_id
        # Snapshot for the failed-downgrade check in the finally below:
        # we only want to mark priming_status="failed" when a *prior*
        # session id (loaded from disk) failed to resume — never when
        # we just committed a fresh id mid-stream this turn (which is
        # how an aborted first turn now reaches the finally block).
        initial_engine_session_id = state.engine_session_id

        yield TurnStarted(
            turn_id=turn_id,
            rtxclaw_session_id=rtxclaw_sid,
            engine_session_id=state.engine_session_id,
            resumed=bool(state.engine_session_id),
        )

        # Decide whether this is a first-turn priming call. The Agent
        # has already consulted ``system_prompt_policy`` and either
        # populated ``request.system_prompt`` (first_turn / sha_changed)
        # or left it ``None`` (never — pure resume).
        policy = self.system_prompt_policy(
            state, current_system_prompt_sha256=request.system_prompt_sha256,
        )

        # Resume id: ALWAYS honor a recorded engine_session_id when one
        # exists, even when ``policy == "sha_changed"``. Re-priming a
        # CLI session mid-conversation trades every prior user turn,
        # tool result, and decision for an updated system prompt — a
        # bad trade for an opaque CLI conversation we can't replay.
        #
        # In particular, the agent's own tool calls (editing
        # ``config.json``'s ``mcp_servers`` / ``acp_agents``, editing
        # MEMORY.md or any .md file, creating skills) flow into
        # ``_compose_system_prompt`` and shift the sha. Until this fix
        # those self-edits caused the very next turn to spawn a fresh
        # Claude CLI session, dropping the conversation cold. Drift is
        # now logged below but not acted on; operators who want the
        # new prompt to take effect start a new session.
        effective_resume_id = state.engine_session_id or ""

        # Build the prompt payload. We only send
        # ``--append-system-prompt`` on the TRUE first call of a CLI
        # session (no engine_session_id to resume into). On resume the
        # bound CLI session already has its priming snapshot baked in;
        # passing a different prompt alongside ``--resume`` either
        # gets ignored or fights the session's own state.
        user_prompt_text = request.prompt or ""
        # Multimodal: the user attached image(s) (Telegram photo, TUI
        # paste, …). The CLI subprocess can't see an inline base64
        # blob, so materialize each image to a temp file and inline the
        # paths into the prompt text — every supported CLI reads images
        # off disk via its own file-reading tool. Temp files are
        # unlinked in the ``finally`` below once the subprocess exits.
        # Native per-CLI flags (antigravity ``--image`` etc.) are a later
        # optimization; inlining the path works for all three today.
        image_temp_files: list[Path] = []
        if request.has_multimodal_content():
            image_paths, image_temp_files = self._materialize_image_parts(
                request.prompt_parts
            )
            if image_paths:
                n = len(image_paths)
                listing = "\n".join(f"  - {p}" for p in image_paths)
                plural = "s" if n != 1 else ""
                them = "them" if n != 1 else "it"
                user_prompt_text = (
                    f"{user_prompt_text}\n\n"
                    f"[The user attached {n} image{plural}. Read {them} "
                    f"from the local filesystem with your file-reading "
                    f"tool:\n{listing}\n]"
                ).strip()
        if request.system_prompt and not effective_resume_id:
            # First-turn priming — fold preamble blocks into the
            # composed system prompt so the CLI session has them in
            # its ``--append-system-prompt`` baseline.
            composed_sys = request.system_prompt
            if request.preamble:
                tail = "\n\n".join(
                    str(b.get("content") or "")
                    for b in request.preamble
                    if b.get("content")
                )
                if tail:
                    composed_sys = f"{composed_sys}\n\n{tail}"
        else:
            composed_sys = None

        # Surface prompt drift without acting on it. Lets ops see
        # divergence between the bound CLI session's baked-in priming
        # prompt and the current composed prompt (e.g., the agent
        # mutated config.json mid-session) without silently abandoning
        # the conversation.
        if policy == "sha_changed" and effective_resume_id:
            from rtxclaw_core.tools._log import log_event as _log_event
            _log_event(
                "CLI_ENGINE_PROMPT_DRIFT_RESUMED",
                engine=self.kind.value,
                rtxclaw_session_id=rtxclaw_sid,
                engine_session_id=effective_resume_id,
                prior_sha=state.priming_system_prompt_sha256,
                current_sha=request.system_prompt_sha256,
                turn_id=turn_id,
            )

        # Marshall args for the legacy runner. Pre-refactor this path
        # mutated process-wide ``os.environ`` to convey session identity,
        # which raced between concurrent CLI turns on the same agent
        # (two TUIs against ``claude`` hit the same engine instance and
        # cross-wired the ``<sid>.delegate_claude.json`` sidecar). The
        # runner now reads ``_rtxclaw_session_id`` /
        # ``_rtxclaw_sessions_dir`` / ``_rtxclaw_permission_mode``
        # directly from ``args`` and falls back to env only when
        # absent (back-compat for direct callers outside the engine).
        legacy_args: dict[str, Any] = {
            "prompt": user_prompt_text,
            "mode": request.mode or "auto",
            "_rtxclaw_session_id": rtxclaw_sid,
            "_rtxclaw_sessions_dir": str(sessions_dir),
            "_rtxclaw_permission_mode": request.mode or "auto",
        }
        # Per-agent API keys → spawn env override for the CLI
        # subprocess. Lets each rtxclaw agent's claude/codex/antigravity
        # CLI hit its OWN provider sub-account so per-agent cost +
        # rate-limit attribution works (the same headline feature
        # LocalLLMEngine gets via cfg.upstream_headers). Empty dict
        # = CLI inherits os.environ only. Runners (runners.py
        # run_delegate_*_async) read ``_spawn_env_overrides`` and
        # pass it as ``env={**os.environ, **overrides}`` to
        # create_subprocess_exec.
        api_keys = request.extra.get("api_keys") if isinstance(request.extra, dict) else None
        if isinstance(api_keys, dict) and api_keys:
            legacy_args["_spawn_env_overrides"] = dict(api_keys)
        # Spawn cwd resolution. The CLIs (Claude Code / Codex / Antigravity)
        # all key ``--resume <id>`` lookups by an encoded form of the
        # spawn cwd; if a resume runs from a different cwd than the
        # one that minted the engine_session_id, the lookup misses
        # silently and we'd fall back to a fresh CLI session — losing
        # the entire prior conversation. So when we have a recorded
        # ``state.spawn_cwd`` AND we're resuming (engine_session_id
        # set), we use the recorded cwd unconditionally; only when we
        # have no recorded spawn cwd yet do we honor request.cwd.
        # ``turn_spawn_cwd`` is closed over by the ``session_id``
        # event handler below so we know what cwd to lock when the
        # CLI first emits its session id.
        if state.spawn_cwd and effective_resume_id:
            turn_spawn_cwd = state.spawn_cwd
        else:
            turn_spawn_cwd = request.cwd or ""
        if turn_spawn_cwd:
            legacy_args["cwd"] = turn_spawn_cwd
        # Model resolution: caller-supplied wins; otherwise fall back to
        # the engine's per-session selection (set via
        # ``set_config_option(sid, "model", <id>)`` — currently only
        # AntigravityCliEngine implements it). Empty / "auto" → no
        # ``--model`` flag, letting the CLI pick its own default.
        effective_model = request.model or self._session_model(rtxclaw_sid)
        if effective_model:
            legacy_args["model"] = effective_model
        if composed_sys:
            legacy_args["_append_system_prompt"] = composed_sys
        if effective_resume_id:
            legacy_args["_force_resume_id"] = effective_resume_id
        elif policy == "sha_changed":
            # We land here only when ``sha_changed`` AND no
            # engine_session_id is recorded — i.e., turn 0's session
            # id wasn't successfully captured. Treat as a fresh prime:
            # the legacy runners gate session resume on a per-engine
            # ``_rtxclaw_<cli>_no_resume`` flag (see runners.py); set
            # it so the runner doesn't silently pick up a stale
            # legacy sidecar id.
            _no_resume_flag = {
                EngineKind.CLAUDE_CLI: "_rtxclaw_claude_no_resume",
                EngineKind.CODEX_CLI:  "_rtxclaw_codex_no_resume",
                EngineKind.ANTIGRAVITY_CLI: "_rtxclaw_antigravity_no_resume",
            }.get(self.kind)
            if _no_resume_flag:
                legacy_args[_no_resume_flag] = True

        # Event channel from runner callbacks → our generator.
        ev_queue: "_asyncio.Queue[Optional[AgentTurnEvent]]" = _asyncio.Queue()

        def _on_delta(text: str) -> None:
            try:
                ev_queue.put_nowait(TextDelta(text=text, channel="content"))
            except Exception:  # noqa: BLE001
                pass

        def _on_event(payload: dict) -> None:
            try:
                kind_ = (payload or {}).get("kind") or ""
                if kind_ == "tool_use":
                    ev_queue.put_nowait(ToolCallStarted(
                        call_id=str(payload.get("id") or ""),
                        name=str(payload.get("name") or "?"),
                        arguments=dict(payload.get("input") or {}),
                    ))
                elif kind_ == "tool_result":
                    ev_queue.put_nowait(ToolCallResult(
                        call_id=str(payload.get("tool_use_id") or ""),
                        ok=bool(payload.get("ok", True)),
                        content=str(payload.get("text") or ""),
                    ))
                elif kind_ == "session_id":
                    # Runner saw the CLI's session id on a streamed
                    # event. Persist immediately so an ESC / idle
                    # timeout before TurnDone still leaves the
                    # sidecar primed for `--resume` on the next
                    # turn. Without this, an aborted first turn
                    # erases the id and the user loses context.
                    new_eid = str(payload.get("id") or "")
                    if new_eid and new_eid != state.engine_session_id:
                        state.engine_session_id = new_eid
                        state.priming_status = "completed"
                        state.last_error = ""
                        # Lock the spawn cwd alongside the session id.
                        # This is the cwd the CLI just used to encode
                        # its on-disk session record; every future
                        # resume MUST use the same cwd or the lookup
                        # will silently miss. Recorded only on the
                        # first sighting (``not state.spawn_cwd``) so
                        # an unrelated mid-stream session-id rebind
                        # doesn't relocate the lock.
                        if not state.spawn_cwd and turn_spawn_cwd:
                            state.spawn_cwd = turn_spawn_cwd
                        try:
                            self.write_state(sessions_dir, state)
                        except Exception:  # noqa: BLE001
                            pass
            except Exception:  # noqa: BLE001
                pass

        runner = self.delegate_runner()
        if runner is None:
            yield TurnError(
                message=f"{self.name} engine has no delegate_runner wired",
                classification="not_yet_implemented",
            )
            yield TurnDone(state="error")
            return

        # Mark priming status as in_progress + write state so a crash
        # before TurnDone preserves a recoverable engine_session_id.
        state.priming_status = "in_progress"
        if request.system_prompt_sha256:
            state.priming_system_prompt_sha256 = request.system_prompt_sha256
        self.write_state(sessions_dir, state)

        def _register_proc(proc: Any) -> None:
            # Called by the runner the instant the CLI subprocess is
            # spawned; lets :meth:`abort` reach the live process group.
            self._active_cli_procs[turn_id] = proc

        async def _drive() -> Any:
            kwargs: dict[str, Any] = {
                "on_delta": _on_delta,
                "on_spawn": _register_proc,
            }
            if self.supports_on_event():
                kwargs["on_event"] = _on_event
            try:
                return await runner(legacy_args, **kwargs)
            finally:
                self._active_cli_procs.pop(turn_id, None)
                # Sentinel signals end-of-stream to the consumer below.
                await ev_queue.put(None)

        driver_task = _asyncio.create_task(_drive())
        # Track in active map for ESC routing.
        self._active_procs[turn_id] = driver_task

        last_error_emitted = False
        terminal_state = "error"
        terminal_metrics: dict[str, Any] = {}
        result_text = ""

        # Every exit path (success, runner-error, ESC-cancel) MUST yield
        # exactly one terminal TurnDone — otherwise the upstream ACP
        # server logs "backend.prompt iterator finished without yielding
        # a PromptResponse" and returns JSON-RPC -32603 to the TUI, the
        # rtxclaw session record never gets an aborted=true row (since
        # Agent.run_turn only persists the turn on TurnDone), and the
        # operator's next prompt on the same sid hits the same error
        # against a stale priming_status=failed sidecar until they give
        # up and create a fresh session — losing all context. So the
        # `try`/`except`/`else` ladder below only sets ``terminal_state``;
        # the unconditional `yield TurnDone(...)` after the `finally`
        # block fires for every path.
        try:
            try:
                while True:
                    ev = await ev_queue.get()
                    if ev is None:
                        break
                    yield ev
            except _asyncio.CancelledError:
                # Generator cancelled by the consumer (Agent.run_turn
                # task cancel). Cancel the driver so the legacy runner's
                # own CancelledError handler SIGTERMs the CLI process
                # group, then fall through to the terminal yield.
                driver_task.cancel()
                terminal_state = "aborted"
            else:
                # Driver signalled end-of-stream (sentinel None). Harvest
                # the ToolResult to classify success / error.
                try:
                    tool_result = await driver_task
                except _asyncio.CancelledError:
                    # External ESC → engine.abort(turn_id) cancelled the
                    # driver mid-stream; the runner's finally drained
                    # the sentinel before propagating CancelledError.
                    terminal_state = "aborted"
                except Exception as exc:  # noqa: BLE001
                    yield TurnError(
                        message=f"{self.name} runner raised: {exc}",
                        classification="engine_exception",
                    )
                    last_error_emitted = True
                    terminal_state = "error"
                else:
                    ok = bool(getattr(tool_result, "ok", False))
                    result_text = str(getattr(tool_result, "content", "") or "")
                    if not ok:
                        yield TurnError(
                            message=result_text or f"{self.name} reported error",
                            classification="cli_error",
                        )
                        last_error_emitted = True
                        terminal_state = "error"
                    else:
                        # Success: the CLI session is now primed. Extract
                        # the engine_session_id from the result body
                        # header (``[claude session=<sid:8>... ...]``)
                        # and persist.
                        new_sid = self._extract_session_id_from_result(
                            result_text,
                            rtxclaw_sid=rtxclaw_sid,
                            sessions_dir=sessions_dir,
                        )
                        if new_sid:
                            state.engine_session_id = new_sid
                        state.priming_status = "completed"
                        state.last_error = ""
                        # Lock spawn_cwd on the success terminal too —
                        # covers CLIs whose ``session_id`` event the
                        # runner doesn't surface mid-stream (only the
                        # claude runner does today). Without this, a
                        # codex/antigravity session would only get its cwd
                        # locked once a subsequent turn happens to
                        # spawn from a different cwd, which is exactly
                        # the failure mode we're trying to prevent.
                        if not state.spawn_cwd and turn_spawn_cwd:
                            state.spawn_cwd = turn_spawn_cwd
                        self.write_state(sessions_dir, state)
                        terminal_state = "ok"
        finally:
            self._active_procs.pop(turn_id, None)
            self._active_cli_procs.pop(turn_id, None)
            # Drop the temp image files materialized for this turn.
            # The CLI subprocess has exited (success / error) or is
            # being group-killed (abort) by the time we get here, and
            # it read the images off disk at turn start — so unlinking
            # now is safe. Every terminal path (including the cancel
            # branches above) routes through this ``finally``.
            for _tmp in image_temp_files:
                try:
                    _tmp.unlink()
                except OSError:
                    pass
            # If we exited with anything other than "ok" (and we
            # have an engine_session_id), mark priming_status=failed
            # so the next call can decide to retry-with-resume vs
            # start fresh. EXCEPT: a session id we just acquired
            # mid-stream this turn (via the on_event "session_id"
            # path — first turn aborted between session-id sighting
            # and end-of-stream) is almost certainly still resumable
            # on the CLI side; downgrading it would force a fresh
            # prime and discard the conversation.
            if (
                terminal_state != "ok"
                and state.engine_session_id
                and state.engine_session_id == initial_engine_session_id
            ):
                state.priming_status = "failed"
                self.write_state(sessions_dir, state)

        # Stash the engine-side audit on request.extra for Agent to
        # write into the session record. Reaches the Agent on every
        # terminal_state — including ``aborted`` — so the session JSON
        # gains a row with ``aborted=true`` for cancelled turns instead
        # of silently dropping them.
        request.extra["_engine_audit"] = {
            "thinking": "",
            "content": result_text,
            "tool_calls": [],
            "tool_results": [],
            "metrics": {"engine": self.kind.value, "model": self.name},
            "started_at": "",
            "ended_at": "",
            "state": terminal_state,
        }
        yield TurnDone(
            state=terminal_state,
            engine_session_id=state.engine_session_id,
            metrics={"engine": self.kind.value, "model": self.name},
        )

    def _extract_session_id_from_result(
        self,
        body: str,
        *,
        rtxclaw_sid: str = "",
        sessions_dir: Optional[Path] = None,
    ) -> str:
        """Pull ``session=<id>`` (Claude/Antigravity) or ``thread=<id>``
        (Codex) out of the legacy result-body header.

        Legacy runners produce a header like
        ``[claude session=abc12345…1234 · mode=…]`` at the top of
        the tool-result body. Parsing that out is the cheapest way
        to recover the CLI's own session id without re-reading the
        legacy sidecar file (which the runner already wrote).
        ``rtxclaw_sid`` / ``sessions_dir`` are passed through to the
        sidecar fallback so concurrent CLI turns don't cross-wire
        through ``os.environ``.
        """
        import re
        m = re.search(r"(?:session|thread)=([A-Za-z0-9_\-]+)", body or "")
        if not m:
            return ""
        head = m.group(1)
        # Header truncates to 12 chars w/ ellipsis; the FULL id is
        # in the sidecar. Fall back to the sidecar read.
        if "…" in head or len(head) <= 12:
            return self._read_legacy_sidecar_session_id(
                rtxclaw_sid=rtxclaw_sid, sessions_dir=sessions_dir,
            )
        return head

    def _read_legacy_sidecar_session_id(
        self,
        *,
        rtxclaw_sid: str = "",
        sessions_dir: Optional[Path] = None,
    ) -> str:
        """Read the legacy ``<sid>.delegate_<cli>.json`` sidecar to
        recover the full engine session id when the result header
        carries only a truncated form. Explicit ``rtxclaw_sid`` /
        ``sessions_dir`` args are required for the engine pipeline so
        concurrent CLI turns on the same agent don't cross-wire
        through process-wide ``os.environ``; absent args fall back to
        env for legacy direct callers (none today, but defensive)."""
        import json, os
        sid = rtxclaw_sid or os.environ.get("RTXCLAW_SESSION_ID") or ""
        sdir = str(sessions_dir) if sessions_dir else (
            os.environ.get("RTXCLAW_SESSIONS_DIR") or ""
        )
        if not sid or not sdir:
            return ""
        path = Path(sdir) / f"{sid}.delegate_{self.cli_command}.json"
        if not path.exists():
            return ""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return ""
        key_map = {
            "claude": "claude_session_id",
            "codex": "codex_thread_id",
            "antigravity": "antigravity_session_id",
        }
        return str(data.get(key_map.get(self.cli_command, "")) or "")

    async def abort(self, turn_id: str, *, force: bool = False) -> None:
        """Stop the in-flight CLI turn, gracefully when possible.

        First press (``force=False``): send a friendly ``SIGINT`` to the
        delegated CLI's process group — the documented "wind down
        cleanly" signal for ``claude -p`` (it flushes its reply and its
        own ``--resume`` session file, then exits) — and wait up to
        :data:`CLI_GRACEFUL_ABORT_S` for the driver to reach its terminal
        stream event. If it finishes in time, NO hard kill is sent and
        the turn (plus the CLI's resume state) is preserved. On timeout
        we escalate ``SIGTERM`` → grace → ``SIGKILL`` via the runner's
        :func:`_terminate_group` and cancel the driver.

        We wait on the driver task (which completes when the event
        stream ends), NOT on process exit — ``claude -p`` in stream-json
        mode is known to linger after emitting its final ``result``
        event, so keying off the stream avoids a needless full-grace
        wait when the turn is already captured.

        Second press (``force=True``): skip the grace window and cancel
        the driver immediately; the runner's own ``CancelledError``
        handler SIGTERM/SIGKILLs the subprocess group right away.

        Idempotent — abort on an unknown / already-finished turn_id is a
        silent no-op.
        """
        # Imported lazily to avoid a core↔tools import cycle at module load.
        from ..tools.runners import _kill_group, _terminate_group

        task = self._active_procs.get(turn_id)
        if task is None or task.done():
            return

        if force:
            # Impatient second press → hard kill now.
            try:
                task.cancel()
            except Exception:  # noqa: BLE001
                pass
            return

        proc = self._active_cli_procs.get(turn_id)
        if proc is None:
            # No live subprocess to be gentle with (between rounds, or it
            # already exited) — fall back to a plain driver cancel.
            try:
                task.cancel()
            except Exception:  # noqa: BLE001
                pass
            return

        try:
            # Close stdin (EOF) + friendly SIGINT to the whole group.
            stdin = getattr(proc, "stdin", None)
            if stdin is not None:
                try:
                    stdin.close()
                except Exception:  # noqa: BLE001
                    pass
            _kill_group(proc, signal.SIGINT)
            try:
                # ``shield`` so the wait_for timeout doesn't cancel the
                # driver out from under us — we own the escalation below.
                await asyncio.wait_for(
                    asyncio.shield(task), CLI_GRACEFUL_ABORT_S,
                )
            except asyncio.TimeoutError:
                # Didn't wind down in time → hard escalation.
                await _terminate_group(proc, grace_s=2.0)
                if not task.done():
                    task.cancel()
            except asyncio.CancelledError:
                # Driver was cancelled elsewhere mid-grace — nothing more
                # to do; the runner's own handler kills the subprocess.
                pass
        except Exception:  # noqa: BLE001
            if not task.done():
                task.cancel()

    async def session_lock(self, rtxclaw_sid: str) -> Any:
        """Lazy-allocate a per-session asyncio.Lock."""
        lock = self._session_locks.get(rtxclaw_sid)
        if lock is None:
            lock = asyncio.Lock()
            self._session_locks[rtxclaw_sid] = lock
        return lock

    def is_available(self) -> tuple[bool, str]:
        """Check ``shutil.which`` for the CLI. Returns
        ``(False, install-url-hint)`` when missing."""
        import shutil
        if shutil.which(self.cli_command):
            return True, ""
        return False, (
            f"`{self.cli_command}` CLI not on PATH"
            + (f". Install: {self.install_url}" if self.install_url else "")
        )

    # ---- system-prompt policy ---------------------------------------

    def system_prompt_policy(
        self,
        state: "EngineSessionState",
        *,
        current_system_prompt_sha256: str,
    ) -> str:
        """CLI engines prime once, then resume.

        Returns ``"first_turn"`` when ``state.priming_status in
        {"never", "in_progress", "failed"}``; ``"sha_changed"`` when
        ``current_system_prompt_sha256 !=
        state.priming_system_prompt_sha256``; ``"never"`` once the
        session is fully primed AND the prompt hash matches.

        Compare against :meth:`LocalLLMEngine.system_prompt_policy`
        which always returns ``"every_turn"``.

        Concrete here on the base class — every CLI engine shares
        this state-machine logic (no subclass override). Per codex
        audit round-3 finding #1: leaving this as
        ``NotImplementedError`` would crash every CLI agent at the
        policy step.
        """
        if state.priming_status in ("never", "in_progress", "failed"):
            return "first_turn"
        if (
            state.priming_system_prompt_sha256
            and state.priming_system_prompt_sha256
            != current_system_prompt_sha256
        ):
            return "sha_changed"
        return "never"
