"""Agent + Engine layer for rtxclaw.

The architecture composes two orthogonal axes:

* :class:`Agent` (identity)  — name, home dir, ``SOUL.md`` /
  ``AGENTS.md`` / ``TOOLS.md`` / ``USER.md`` / ``MEMORY.md``, sessions
  dir, permission mode, hooks. See :mod:`.agent`.

* :class:`Engine` (turn dispatch) — abstract; implementations live
  alongside this file:

  - :class:`LocalLLMEngine` — drives the local LLM via worker + tool
    dispatch + compaction + loop detection + distill / nudge /
    force-terminate recovery. See :mod:`.local_llm`.
  - :class:`ClaudeCliEngine` / :class:`CodexCliEngine` /
    :class:`AntigravityCliEngine` — subclasses of
    :class:`ExternalCliEngine`; spawn the matching CLI, ``--resume``
    after the first call, translate the CLI's stream-JSON into the
    normalized :data:`AgentTurnEvent` stream.

================================================================
File map
================================================================

========================= ============================================
File                      Role
========================= ============================================
__init__.py               this docstring + ``__all__`` re-exports
engine.py                 Engine ABC + AgentTurnEvent dataclasses + types
local_llm.py              LocalLLMEngine — drives the local-LLM turn loop
external_cli.py           ExternalCliEngine — shared CLI scaffolding
claude_engine.py          ClaudeCliEngine subclass
codex_engine.py           CodexCliEngine subclass
antigravity_engine.py          AntigravityCliEngine subclass
agent.py                  Agent runtime — composes Engine + identity
factory.py                load_agent + auto-scaffold helpers
session_log.py            uniform record_turn writer (fine-tune ready)
gateway_shim.py           AgentACPBackend — ACP backend over Agent
delegate_shims.py         cross-agent delegate-tool shims
default_scaffolds.py      SOUL/AGENTS/TOOLS templates for auto-scaffolded
                           external-engine agents
acp_translation.py        AgentTurnEvent ↔ ACP sessionUpdate mapping
permissions_integration.  PermissionPolicy + AskQuestion + ASK protocol
   py
========================= ============================================
"""

from __future__ import annotations

from .agent import Agent
from .claude_engine import ClaudeCliEngine
from .codex_engine import CodexCliEngine
from .engine import (
    AgentTurnEvent,
    Engine,
    EngineKind,
    EngineSessionState,
    TextDelta,
    ToolCallResult,
    ToolCallStarted,
    TurnDone,
    TurnError,
    TurnRequest,
    TurnStarted,
)
from .external_cli import ExternalCliEngine
from .factory import load_agent
from .gateway_shim import AgentACPBackend
from .antigravity_engine import AntigravityCliEngine
from .acp_engine import AcpEngine
from .cursor_acp_engine import CursorAcpEngine
from .local_llm import LocalLLMEngine
from .session_log import record_turn


__all__ = [
    "Agent",
    "AgentACPBackend",
    "AgentTurnEvent",
    "Engine",
    "EngineKind",
    "EngineSessionState",
    "ExternalCliEngine",
    "LocalLLMEngine",
    "ClaudeCliEngine",
    "CodexCliEngine",
    "AntigravityCliEngine",
    "AcpEngine",
    "CursorAcpEngine",
    "TextDelta",
    "ToolCallStarted",
    "ToolCallResult",
    "TurnDone",
    "TurnError",
    "TurnRequest",
    "TurnStarted",
    "load_agent",
    "record_turn",
]
