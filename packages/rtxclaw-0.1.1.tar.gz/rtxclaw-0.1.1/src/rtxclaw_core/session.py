from __future__ import annotations

import fcntl
import json
import os
import secrets
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

# Global default — used only by callers that don't pass an explicit
# `sessions_dir`/`root` (legacy direct-spawn paths). Agents always pass
# their own per-agent sessions dir, so this default never fires for the
# agent flow. Kept cwd-independent so we never leak a `.rtxclaw/` into
# the project tree.
SESSIONS_DIR = Path.home() / ".rtxclaw" / "sessions"


@contextmanager
def _exclusive_session_write(path: Path) -> Iterator[Path]:
    """Write-side guard for ``Session.save``.

    Yields a *per-writer-unique* tmp path that the caller writes,
    fsyncs, then ``os.replace``s into ``path``. The body of the
    ``with`` block runs under an exclusive ``fcntl.flock(LOCK_EX)``
    on a sibling ``.<filename>.lock`` so concurrent writers — within
    the process, across threads, or across separate processes (e.g.
    gateway + a legacy TUI ChatApp save in ``rtxclaw_tui/app.py``,
    gateway + a stdio-fallback one-shot, or ``set_mode`` in the ACP
    bridge racing a streaming flush from ``Agent.run_turn``) — line
    up cleanly instead of issuing parallel writes against the same
    visible file.

    Two pieces, with distinct jobs — don't conflate them:

    1. **Per-writer unique tmp filename** (``PID.TID.NONCE``) opened
       with ``O_EXCL`` (``Session.save`` body, below). This is what
       prevents two writers from truncating each other's in-flight
       tmp file: each writer gets its own private inode. Combined
       with the atomicity of ``rename(2)`` (``os.replace``), the
       visible ``<sid>.json`` ends up as exactly ONE writer's
       complete payload — no torn / interleaved JSON is possible
       even if the flock were skipped.
    2. **fcntl.flock(LOCK_EX)** (this helper). Adds *ordering*:
       writers run one at a time in the critical section, so the
       final on-disk state is deterministic last-writer-wins
       instead of "whichever ``os.replace`` happened to land
       second." It also gives downstream readers a predictable
       sequence point (e.g. the ``session_saved`` bus publish
       fires AFTER the lock is released, so subscribers can't
       reach into a half-written FD). On Linux ``flock(2)`` is
       advisory and per-open-file-description, so two distinct
       processes (each calling ``os.open`` on the lockfile) get
       their own OFDs and contend on the same lock.

    Readers are intentionally NOT gated by this lock. They open
    ``<sid>.json`` directly and rely on the atomic ``os.replace``
    rename to always see a fully-formed JSON document — that
    contract is preserved unchanged.

    The lockfile is created on first write and left behind on
    cleanup; deleting it would re-open the race window (proc A
    unlinks the lockfile while proc B has it open → next writers
    create a fresh lockfile and the old holder no longer serialises
    with them). No code path in this repo deletes session JSONs
    today (see ``Agent.close_session`` — it explicitly preserves
    the file), so the ``.<sid>.json.lock`` files accumulate
    one-per-session alongside their JSON, at the same growth rate.
    An operator-side ``sessions/`` sweep is the only cleanup.

    NFS note: ``flock(2)`` on local ext4/xfs/btrfs (the production
    deployment per the operator's ops notes) gives true cross-
    process serialisation. On NFS mounts the lock is advisory and
    client-local — two clients on different machines would NOT
    serialise. If you ever point ``~/.rtxclaw`` at an NFS volume,
    revisit this primitive.
    """
    lock_path = path.with_name(f".{path.name}.lock")
    tmp_path = path.with_name(
        f".{path.name}."
        f"{os.getpid()}.{threading.get_ident()}.{secrets.token_hex(4)}.tmp"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        try:
            yield tmp_path
        finally:
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            except OSError:
                # Best-effort unlock; ``os.close`` below will also
                # release the lock on the OFD.
                pass
    finally:
        os.close(lock_fd)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_session_id() -> str:
    """Return a fresh session id that sorts into creation order under
    **any** sort — lexical *and* numeric.

    Format (UTC)::

        YYYYMMDD 'T' HHMMSS ffffff '-' <12 hex random>
        e.g.  20260520T134055123456-a3f8b2c1d4e5

    The leading ``YYYYMMDDTHHMMSSffffff`` is a fixed-width, zero-padded
    UTC timestamp (8 + 6 + 6 digits). Because every field is fixed
    width and the only non-digit before the random tail is the ``T``
    date/time divider, the id orders chronologically under:

    * **lexical / byte sort** — ``ls``, Python ``sorted()``, SQLite
      ``ORDER BY hash`` (BINARY collation); and
    * **numeric / natural sort** — what VS Code's Explorer and many
      file managers use *by default*: maximal digit runs are compared
      by value, so ``YYYYMMDD`` and ``HHMMSSffffff`` (both fixed width)
      still compare correctly and the newest session lands **last**.

    Sorting right under *both* is the whole point of the format. The
    previous UUIDv7-hex id only sorted right under a *lexical* sort;
    under a numeric sorter the hex timestamp gets chopped into
    variable-length decimal runs (``…d91…`` → 91, ``…d152…`` → 152)
    and the order scrambles — so in VS Code a freshly created session
    did **not** appear last. UTC (not local time) guarantees
    monotonicity across DST transitions; the 12-hex random tail keeps
    ids unique within a single microsecond.

    Single-use contract: every caller MUST treat the returned id as
    opaque and set it exactly once at ``Session.new`` time.
    Reassignment elsewhere is a bug — the id is the file name (its
    ``Path.stem``), the dict key, and the index key. It contains no
    ``.``, so ``"<id>.jsonl"`` round-trips through ``Path.stem`` cleanly.
    """
    import secrets
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    return f"{now:%Y%m%dT%H%M%S%f}-{secrets.token_hex(6)}"


@dataclass
class Session:
    hash: str
    title: str
    created_at: str
    system_prompt: str
    model: str
    endpoint: str
    turns: list[dict[str, Any]] = field(default_factory=list)
    # Permission mode the saved `system_prompt` was composed with. Used
    # by `agent_runtime` to decide whether the cached prompt is still
    # valid for the next turn — a mode switch (Shift+Tab in the TUI)
    # forces a fresh `load_system_prompt(...)` so the right MODE-*.md
    # file is in effect.
    system_mode: str = ""
    # The frontend-reported workspace context, captured at session
    # creation. `workspace_cwd` is the absolute filesystem directory the
    # frontend was launched from (TUI / `-p` / Telegram poller); the
    # agent injects it as a `# WORKSPACE-CONTEXT` section at the tail of
    # the system prompt so the model knows which folder the user is
    # operating in. `workspace_origin` is a short tag identifying the
    # frontend ("tui", "oneshot", "telegram", "api"). Both default to
    # empty strings; nothing is injected when both are empty (preserves
    # byte-stable prompts for callers that don't care).
    workspace_cwd: str = ""
    workspace_origin: str = ""
    # Tokenizer/protocol family of the upstream this session is bound
    # to. Empty = use cfg.backend at turn time. Stored alongside
    # `endpoint` so a session created against an alternate endpoint
    # (e.g. `rtxclaw --model gpu-c`) keeps the right backend tag for
    # every subsequent turn — without this, switching endpoints
    # mid-config would silently mismatch the tokenizer.
    backend: str = ""
    # Max context window in tokens for the bound model. 0 = use
    # cfg.upstream_max_context fallback. OpenClaw-aligned name; per
    # session because two configured `models[]` rows can advertise
    # different contextWindows (e.g. gpu-a 256k vs gpu-c 32k) and the
    # compaction guard must trigger at the right threshold for each.
    context_window: int = 0
    # Number of successful compactions this session has run. Bumps on
    # each `_compact_via_llm` success. The pre-compaction memory-flush
    # gate uses this to avoid re-flushing within the same cycle —
    # mirrors OpenClaw's `entry.compactionCount`.
    compaction_count: int = 0
    # Compaction count at which the most recent pre-compaction memory
    # flush ran. Equals `compaction_count` after a flush; differs after
    # a fresh compaction has happened, which re-arms the flush gate.
    memory_flush_compaction_count: int = -1
    # ISO timestamp of the last pre-compaction memory flush — purely
    # informational, surfaced via `rtxclaw memory status`.
    last_memory_flush_at: str = ""
    # --- pinned facts + rolling compaction summary ------------------
    # Facts the model has explicitly pinned via the `pin_fact` tool, or
    # that an operator pinned out-of-band. These survive every
    # compaction stage (deterministic and LLM-based), are re-injected
    # into the message list right after the system prompt, and persist
    # across turns. Use sparingly — every pinned fact costs prompt
    # tokens on every round.
    pinned_facts: list[str] = field(default_factory=list)
    # Rolling cross-compaction summary. The LLM summary produced by
    # `_compact_via_llm` is normally session-local (one summary per
    # compaction event, replacing the prior one). When a session
    # compacts repeatedly, facts established in compaction N can be
    # lost by compaction N+1's summary if the model focused on more
    # recent material. This field accumulates a SECOND-ORDER summary
    # across compactions so old context isn't silently dropped. Bounded
    # by `_COMPACTION_SUMMARY_MAX_CHARS` in agent_runtime.
    compaction_summary: str = ""
    # Per-session frontend visibility flags. Both default to OFF so a
    # fresh session keeps the chat clean (no reasoning stream, no tool
    # output flood); the operator opts in via `/reasoning on|stream`
    # and `/tool on`. Telegram (and any other stream-aware client)
    # reads these from the saved session record so each session
    # carries its own preference instead of falling back to a per-chat
    # default that's unrelated to which session is currently bound.
    # The model's THINKING behaviour is independent and continues to
    # be controlled by `cfg.enable_thinking` / the `/thinking` command.
    reasoning_visibility: str = "off"
    tool_output_visible: bool = False
    # ---- agents/ refactor attribution fields (Phase 2) -------------
    #
    # Set by ``rtxclaw_core.agents.session_log.record_session_creation``
    # at agent.create_session() time. Additive — sessions saved before
    # the refactor lack these fields and the loader / index tolerates
    # their absence via dataclass defaults.
    agent_name: str = ""
    engine: str = ""                # "local_llm" | "claude_cli" | …
    system_prompt_sha256: str = ""  # stable hash for fine-tune grouping
    # Privacy gate for reasoning traces. When False, ``record_turn``
    # drops the ``thinking`` channel from the on-disk record; live
    # render in the TUI still receives it (gated separately by
    # ``reasoning_visibility``).
    persist_reasoning_traces: bool = True
    # Parent rtxclaw session id, set when this session IS a subagent —
    # i.e. an agent spawned by another session via the ``Agent`` /
    # ``BatchAgent`` tool (or the ``delegate_*`` slash-commands). Empty
    # for top-level (operator-initiated) sessions. This is the
    # first-class encoding of "a subagent is nothing more than an agent
    # with a parent session": the same Session/Agent machinery, plus a
    # back-link to whoever dispatched it. Additive — pre-refactor
    # sessions lack the field and default to "" (top-level). Persisted
    # to the JSONL header + sessions.db so the parent↔child tree is
    # queryable without parsing the loose ``delegate_*`` sidecars.
    parent_session_id: str = ""

    @classmethod
    def new(
        cls,
        *,
        system_prompt: str,
        model: str,
        endpoint: str,
        sessions_dir: Path | None = None,  # kept for API stability; unused for id
        system_mode: str = "",
        workspace_cwd: str = "",
        workspace_origin: str = "",
        backend: str = "",
        context_window: int = 0,
        parent_session_id: str = "",
    ) -> "Session":
        # Resolve at call time so test/runtime monkey-patches of the module
        # constant take effect.
        if sessions_dir is None:
            sessions_dir = SESSIONS_DIR
        h = new_session_id()
        return cls(
            hash=h,
            # Last 8 chars of the id's random hex tail — disambiguates an
            # "untitled" placeholder within an operator's session history
            # without surfacing the id's leading timestamp in the title.
            title=f"untitled-{h[-8:]}",
            created_at=_now(),
            system_prompt=system_prompt,
            model=model,
            endpoint=endpoint,
            system_mode=system_mode,
            workspace_cwd=workspace_cwd,
            workspace_origin=workspace_origin,
            backend=backend,
            context_window=context_window,
            parent_session_id=parent_session_id,
        )

    def add_turn(
        self,
        *,
        user: Any,
        thinking: str,
        content: str,
        started_at: str,
        ended_at: str,
        aborted: bool = False,
        error: str | None = None,
        metrics: dict[str, Any] | None = None,
        in_progress: bool = False,
    ) -> None:
        if not self.turns and self.title.startswith("untitled-"):
            self.title = self._derive_title(user)
        new_entry = {
            "user": user,
            "thinking": thinking,
            "content": content,
            "started_at": started_at,
            "ended_at": ended_at,
            "aborted": aborted,
            "error": error,
            "metrics": metrics,
            "in_progress": in_progress,
        }
        # In-progress checkpoint updates the last turn IN PLACE when
        # it's still an in-progress entry for the SAME user prompt —
        # the engine flushes one of these per round boundary, and
        # appending each as a fresh entry would explode ``turns[]`` into
        # N near-duplicate rows. The terminal record_turn (with
        # ``in_progress=False``) likewise overwrites the trailing
        # in-progress marker so the saved turn is the final state,
        # not stacked partials. New user prompts always append.
        if (
            self.turns
            and self.turns[-1].get("in_progress")
            and self.turns[-1].get("user") == user
        ):
            self.turns[-1] = new_entry
            return
        self.turns.append(new_entry)

    @staticmethod
    def _derive_title(text: Any, limit: int = 60) -> str:
        # `text` is either a plain string OR an OpenAI-style multi-part
        # content list (vision turns ship `[image_url, text]`). Pull the
        # first non-empty text part out before deriving the title; fall
        # back to "[image]" when the user sent a bare photo with no caption.
        if isinstance(text, list):
            text_part = ""
            for part in text:
                if isinstance(part, dict) and str(part.get("type") or "").lower() == "text":
                    text_part = part.get("text") or ""
                    if text_part:
                        break
            text = text_part or "[image]"
        if not isinstance(text, str):
            text = str(text or "")
        first = next((line for line in text.strip().splitlines() if line.strip()), "")
        if not first:
            return "session"
        return first[:limit] + ("…" if len(first) > limit else "")

    def _header_dict(self) -> dict[str, Any]:
        """Materialised-header fields for the sessions.db row."""
        return {
            "session_hash": self.hash,
            "created_at": self.created_at,
            "agent_name": self.agent_name,
            "engine": self.engine,
            "parent_session_id": getattr(self, "parent_session_id", "") or "",
            "workspace_cwd": self.workspace_cwd,
            "workspace_origin": self.workspace_origin,
            "title": self.title,
            "model": self.model,
            "endpoint": self.endpoint,
            "backend": self.backend,
            "context_window": int(self.context_window or 0),
            "system_mode": self.system_mode,
            "reasoning_visibility": self.reasoning_visibility,
            "tool_output_visible": bool(self.tool_output_visible),
            "persist_reasoning_traces": bool(self.persist_reasoning_traces),
            "persist_tool_result_bodies": bool(
                getattr(self, "persist_tool_result_bodies", True)
            ),
            "system_prompt": self.system_prompt,
            "system_prompt_sha256": self.system_prompt_sha256,
            "pinned_facts": list(self.pinned_facts),
            "compaction_count": int(self.compaction_count or 0),
            "compaction_summary": self.compaction_summary,
            "memory_flush_compaction_count": int(
                self.memory_flush_compaction_count
            ),
            "last_memory_flush_at": self.last_memory_flush_at,
        }

    def save(self, root: Path | None = None, *, force: bool = False) -> Path:
        """Persist the session HEADER to ``sessions.db``.

        Turns are persisted as append-only JSONL events by
        ``session_log.record_turn`` — ``save()`` now only flushes the
        materialised header (title / model / pinned_facts / compaction /
        config) that header-mutating callers (set_mode, set_config_option,
        memory_flush, acp new_session) change. On the first call for a
        session it emits ``session_started`` (which inserts the
        sessions_meta row); thereafter it emits ``header_update``.

        Returns the ``<sid>.jsonl`` path (the durable artifact). The
        legacy whole-document JSON write is gone.
        """
        if root is None:
            root = SESSIONS_DIR
        root = Path(root)
        jsonl_path = root / f"{self.hash}.jsonl"
        try:
            from rtxclaw_core.session_writer import get_session_writer
            writer = get_session_writer(root, self.hash, engine=self.engine or "")
            header = self._header_dict()
            if jsonl_path.exists():
                # Patch only the mutable config/state — never re-append the
                # large immutable system_prompt (+ identity fields) on every
                # /mode or /model toggle (review: Codex S4 write-amp). The
                # initial system_prompt rode the session_started event.
                patch = {
                    k: v for k, v in header.items()
                    if k not in (
                        "system_prompt", "system_prompt_sha256",
                        "created_at", "agent_name",
                    )
                }
                writer.header_update(patch=patch)
            else:
                writer.session_started(header)
        except Exception:  # noqa: BLE001
            # Header persistence is best-effort at the call boundary;
            # the next mutation re-flushes. Never raise into a caller
            # that just toggled a config option.
            pass
        return jsonl_path
