"""In-process async event bus with debounced subscribers.

The memory synthesizer wants to fire on "something happened, but
coalesce a burst into one run". This shared bus provides that debounce
pattern for in-process runtime events.

Design constraints:

- **In-process, single-loop.** The whole rtxclaw runtime is one asyncio
  loop in one process. We don't need pub/sub across processes.
- **Per-key handlers, not broadcast.** Each event name routes to its
  registered handler(s). Multiple subscribers per event are allowed.
- **Debounce per subscriber.** Each subscriber declares its own quiet
  window. A burst of N publishes within the window collapses into one
  invocation, fired `quiet_seconds` after the LAST publish.
- **Late-publish merging.** If a publish lands while a handler is
  still running, the bus marks "another run is pending" and re-fires
  the handler once the current run finishes. We never run the same
  handler concurrently with itself.
- **Cancel-safe.** Calling `shutdown()` cancels pending timers cleanly;
  in-flight handlers run to completion (the bus waits for them with a
  short timeout before giving up).

Not implemented: priorities, persistent queues, retry policy. If we
need those, we'll switch to a real broker. For now this fits inside
~150 lines and covers the current memory case.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

_log = logging.getLogger(__name__)

EventHandler = Callable[[dict[str, Any]], Awaitable[None]]


@dataclass
class _Subscription:
    handler: EventHandler
    quiet_seconds: float
    name: str

    # internal state — managed by the bus
    _timer: Optional[asyncio.TimerHandle] = field(default=None, repr=False)
    _running: bool = field(default=False, repr=False)
    _pending: bool = field(default=False, repr=False)
    _last_publish_ts: float = field(default=0.0, repr=False)
    _latest_payload: dict[str, Any] = field(default_factory=dict, repr=False)


class EventBus:
    """Single-loop async event bus.

    Usage:

        bus = EventBus()
        async def on_daily(payload):
            ...
        bus.subscribe("daily_appended", on_daily, quiet_seconds=60.0)
        bus.publish("daily_appended", {"home": "..."})
    """

    def __init__(self) -> None:
        self._subs: dict[str, list[_Subscription]] = {}
        self._closed: bool = False

    def subscribe(
        self,
        event: str,
        handler: EventHandler,
        *,
        quiet_seconds: float = 0.0,
        name: str = "",
    ) -> None:
        """Register `handler` for `event`. `quiet_seconds=0` means
        fire immediately on every publish (no debounce). Anything > 0
        debounces: the handler runs `quiet_seconds` after the LAST
        publish in a burst, with the burst's most recent payload."""
        if self._closed:
            raise RuntimeError("EventBus is closed")
        sub = _Subscription(
            handler=handler,
            quiet_seconds=max(0.0, float(quiet_seconds)),
            name=name or getattr(handler, "__name__", "anon"),
        )
        self._subs.setdefault(event, []).append(sub)

    def publish(self, event: str, payload: Optional[dict[str, Any]] = None) -> None:
        """Synchronous publish. Schedules each subscriber per its
        debounce config. Cheap: no LLM work happens on this thread.
        """
        if self._closed:
            return
        payload = dict(payload or {})
        subs = self._subs.get(event)
        if not subs:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            _log.warning("EventBus.publish(%s) without a running loop — dropping", event)
            return
        now = time.monotonic()
        for sub in subs:
            sub._last_publish_ts = now
            sub._latest_payload = payload
            if sub.quiet_seconds <= 0.0:
                # Fire-immediately mode.
                self._schedule_run(sub, loop)
                continue
            # Debounced: cancel any pending timer + reschedule.
            if sub._timer is not None:
                try:
                    sub._timer.cancel()
                except Exception:  # noqa: BLE001
                    pass
            sub._timer = loop.call_later(
                sub.quiet_seconds,
                self._on_timer_fire,
                sub,
                loop,
            )

    def _on_timer_fire(self, sub: _Subscription, loop: asyncio.AbstractEventLoop) -> None:
        sub._timer = None
        self._schedule_run(sub, loop)

    def _schedule_run(self, sub: _Subscription, loop: asyncio.AbstractEventLoop) -> None:
        if sub._running:
            # A run is already in flight. Mark pending; the run-loop
            # will re-fire once it finishes.
            sub._pending = True
            return
        sub._running = True
        loop.create_task(self._run_subscription(sub))

    async def _run_subscription(self, sub: _Subscription) -> None:
        try:
            while True:
                payload = sub._latest_payload
                sub._latest_payload = {}
                sub._pending = False
                try:
                    await sub.handler(payload)
                except Exception:  # noqa: BLE001
                    _log.exception("EventBus subscriber %r raised", sub.name)
                # Did another publish land while we were running? If
                # so, run once more with the latest payload.
                if not sub._pending:
                    break
        finally:
            sub._running = False

    async def shutdown(self, *, drain_timeout: float = 5.0) -> None:
        """Cancel pending debounce timers, wait for in-flight handlers
        to finish (bounded by `drain_timeout`), then mark closed."""
        self._closed = True
        for subs in self._subs.values():
            for sub in subs:
                if sub._timer is not None:
                    try:
                        sub._timer.cancel()
                    except Exception:  # noqa: BLE001
                        pass
                    sub._timer = None
        # Wait for in-flight handlers (they self-clear `_running`).
        deadline = time.monotonic() + max(0.0, drain_timeout)
        while time.monotonic() < deadline:
            still_running = any(
                sub._running
                for subs in self._subs.values()
                for sub in subs
            )
            if not still_running:
                return
            await asyncio.sleep(0.05)


# ---- module-level default bus --------------------------------------

# The runtime uses ONE bus per process. Modules import this directly
# rather than threading a bus parameter through every call site.
_DEFAULT_BUS: Optional[EventBus] = None


def get_bus() -> EventBus:
    """Return (lazy-init) the process-wide event bus."""
    global _DEFAULT_BUS
    if _DEFAULT_BUS is None:
        _DEFAULT_BUS = EventBus()
    return _DEFAULT_BUS


def reset_bus_for_tests() -> None:
    """Drop the singleton AND clear the per-subscriber registration
    state in modules that subscribe at boot. Used by tests that want
    a fresh bus + a fresh ability to re-subscribe."""
    global _DEFAULT_BUS
    _DEFAULT_BUS = None
    # Clear module-level "already subscribed" guards so the next
    # subscribe call lands fresh. Imported lazily to avoid hard
    # dependencies in event_bus on its consumers.
    try:
        from rtxclaw_memory import memory_synth as _ms
        _ms._REGISTERED.clear()
    except Exception:  # noqa: BLE001
        pass


__all__ = [
    "EventBus",
    "EventHandler",
    "get_bus",
    "reset_bus_for_tests",
]
