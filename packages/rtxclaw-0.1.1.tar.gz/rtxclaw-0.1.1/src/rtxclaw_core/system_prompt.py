"""System-prompt cache-boundary helpers (mirrors OpenClaw verbatim).

The system prompt is split into a STABLE prefix (cached aggressively
across turns and across sessions) and a DYNAMIC suffix (allowed to
change tick-to-tick: heartbeat content, time-of-day, ephemeral workspace
context). The split is marked by a single HTML-comment line that the
model ignores but rtxclaw's own code uses to insert dynamic additions
in a cache-safe spot.

Same pattern as `dist/system-prompt-cache-boundary-CeY_ZCdW.js` and
`dist/prompt-cache-stability-D3r6Fd59.js` in the OpenClaw runtime —
function for function. The marker string is the only intentional
divergence: we use `RTXCLAW_CACHE_BOUNDARY` so a prompt that round-trips
through both runtimes can be told apart and so logs make it clear
which agent owned the boundary.

Why this matters for vLLM APC / SGLang RadixAttention:
- The KV cache is hashed on a *block-aligned token prefix*. A single
  byte change near the start of the prompt invalidates the entire
  cache from there on, including the conversation history that follows.
- Putting "frequently-changing-but-still-per-session-stable" content
  (workspace cwd, frontend tag, …) BELOW the boundary keeps the long
  shared prefix byte-stable across sessions in different cwds — so the
  long head of every system prompt across your whole session library
  shares the same KV blocks on the upstream.
- Putting truly dynamic content (HEARTBEAT.md edits, current time,
  per-tick prompt additions) AFTER the boundary means *only the
  trailing few hundred tokens* re-prefill on a tick, not the whole
  10k-token system prompt.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional


# Single canonical marker string. Length = 33 chars including the
# leading and trailing `\n`. The OpenClaw bundle uses a magic `34` in
# `splitSystemPromptCacheBoundary` for `boundaryIndex + 34`; that's
# the length of THEIR marker (`OPENCLAW_CACHE_BOUNDARY` is one char
# shorter than `RTXCLAW_CACHE_BOUNDARY`). We compute the length here
# instead of hard-coding it so the marker can be changed without
# silently corrupting the split.
SYSTEM_PROMPT_CACHE_BOUNDARY = "\n<!-- RTXCLAW_CACHE_BOUNDARY -->\n"
_BOUNDARY_LEN = len(SYSTEM_PROMPT_CACHE_BOUNDARY)


# Workflow guidance for the `todo` tool. Lives ABOVE the cache boundary
# because it never changes between turns — adding it here doesn't cost
# us prefix-cache stability across a session. Mirrors OpenCode's
# TodoWrite usage hint: short, action-oriented, no examples (the tool's
# own JSON schema is the authoritative spec).
# NOTE: TODO_TOOL_PROMPT_SECTION used to live here. Removed
# 2026-05-06 — operators wanted a single source of truth for the
# planning rule, so the imperative "if 2+ steps you MUST call todo"
# contract now lives in the per-agent ``AGENTS.md`` workspace file
# instead of being runtime-injected. ``_compose_system_prompt``
# composes the .md files; whatever the operator writes there is what
# the model sees.


def load_prompt_pair(path: "Path") -> dict[str, str]:
    """Load a (system, user) prompt pair from one .md file.

    Internal sub-model invocations (loop-recovery distiller, memory
    synthesizer, …) used to embed their prompt strings directly in
    Python. The operator preferred them in editable .md files in the
    agent home — this helper does the parse.

    File format::

        <!-- system -->
        <body of the system message>

        <!-- user -->
        <body of the user message; may contain {placeholder} slots>

    Whichever sections are present land under ``"system"`` /
    ``"user"`` keys; missing or unreadable file yields an empty
    dict so callers can fail-soft (skip the recovery / synth pass
    rather than crash).
    """
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return {}
    sections: dict[str, str] = {}
    current: Optional[str] = None
    buf: list[str] = []

    def _flush() -> None:
        if current is not None:
            sections[current] = "".join(buf).strip("\n")
        buf.clear()

    import re as _re
    marker_re = _re.compile(r"^\s*<!--\s*(\w+)\s*-->\s*$")
    for line in text.splitlines(keepends=True):
        m = marker_re.match(line)
        if m:
            _flush()
            current = m.group(1).lower()
            continue
        if current is not None:
            buf.append(line)
    _flush()
    return sections


# CRLF normalization + trailing-whitespace cleanup. Matches OpenClaw's
# `normalizeStructuredPromptSection` byte for byte: the inference
# backend's tokenizer treats `\r\n` and `\n` differently, and a stray
# trailing space on a line that the model otherwise produces clean
# would break the cache hash on every round.
_CRLF_RE = re.compile(r"\r\n?")
_TRAILING_WS_RE = re.compile(r"[ \t]+$", re.MULTILINE)


def normalize_structured_prompt_section(text: str) -> str:
    """Mirror of `normalizeStructuredPromptSection`. Idempotent.

    1. `\\r\\n` / lone `\\r` → `\\n`.
    2. Strip trailing tabs/spaces from every line.
    3. Strip leading + trailing whitespace from the whole string.
    """
    if not isinstance(text, str):
        return ""
    out = _CRLF_RE.sub("\n", text)
    out = _TRAILING_WS_RE.sub("", out)
    return out.strip()


def strip_system_prompt_cache_boundary(text: str) -> str:
    """Replace every cache-boundary marker with a single `\\n`. Used
    for downstream consumers (logging, debug dumps, SSE replies) that
    want the system-prompt body without the rtxclaw-internal split
    marker leaking into UIs."""
    return text.replace(SYSTEM_PROMPT_CACHE_BOUNDARY, "\n")


def split_system_prompt_cache_boundary(text: str) -> Optional[dict]:
    """Split the prompt at the FIRST cache-boundary marker.

    Returns `{"stable_prefix": str, "dynamic_suffix": str}` (both
    leading/trailing whitespace stripped) or `None` if no marker is
    present. Mirrors OpenClaw's `splitSystemPromptCacheBoundary`.
    """
    idx = text.find(SYSTEM_PROMPT_CACHE_BOUNDARY)
    if idx == -1:
        return None
    return {
        "stable_prefix": text[:idx].rstrip(),
        "dynamic_suffix": text[idx + _BOUNDARY_LEN:].lstrip(),
    }


def prepend_system_prompt_addition_after_cache_boundary(
    *,
    system_prompt: str,
    system_prompt_addition: Optional[str],
) -> str:
    """Insert `system_prompt_addition` immediately after the cache
    boundary, ahead of any existing dynamic suffix. Mirrors OpenClaw's
    `prependSystemPromptAdditionAfterCacheBoundary`.

    - If the addition is empty, returns `system_prompt` unchanged.
    - If the system prompt has no boundary, the addition is prepended
      to the WHOLE prompt with `\\n\\n` separator (matches OpenClaw —
      a missing boundary means "treat this as legacy / fully dynamic").
    - If the dynamic suffix is empty, the addition becomes the suffix.
    - Otherwise: `<stable>\\n<boundary>\\n<addition>\\n\\n<dynamic>`.
    """
    addition = (
        normalize_structured_prompt_section(system_prompt_addition)
        if isinstance(system_prompt_addition, str)
        else ""
    )
    if not addition:
        return system_prompt
    split = split_system_prompt_cache_boundary(system_prompt)
    if split is None:
        return f"{addition}\n\n{system_prompt}"
    if not split["dynamic_suffix"]:
        return (
            f"{split['stable_prefix']}"
            f"{SYSTEM_PROMPT_CACHE_BOUNDARY}"
            f"{addition}"
        )
    dynamic = normalize_structured_prompt_section(split["dynamic_suffix"])
    return (
        f"{split['stable_prefix']}"
        f"{SYSTEM_PROMPT_CACHE_BOUNDARY}"
        f"{addition}\n\n{dynamic}"
    )


# Tooling section — mirrors OpenClaw's `buildToolingPromptSection`.
# Tool-contract guidance (the rules a tool ships with — "call `todo`
# first if you have 2+ steps", etc.) lives WITH the tool, in code,
# not in operator-editable .md files. AGENTS.md still owns behavioural
# style on top; this block owns the tool semantics. Lives in the
# stable head so the prefix cache holds — content is byte-stable per
# registry build, since BUILTIN_TOOLS is module-frozen.
#
# OpenClaw's docs.openclaw.ai phrasing: "structured-tool source-of-
# truth reminder plus runtime tool-use guidance. When the experimental
# `update_plan` tool is enabled, Tooling also tells the model to use
# it only for non-trivial multi-step work, keep exactly one
# `in_progress` step, and avoid repeating the whole plan after each
# update." We carry the same contract for the `todo` tool.
def tooling_prompt_section() -> str:
    """Render the `## Tooling` section. Hardcoded above the cache
    boundary, early in the stable prefix.

    Empirical motivation (2026-05-07): a Qwen3.6-27B BF16 session on
    SGLang ignored AGENTS.md's planning rule despite the byte-identical
    prompt that an FP8 vLLM session followed. The rule sat at byte
    ~13 K of a 26 K stable head — lost-in-the-middle territory. This
    block surfaces the same rule (positively) up front; the
    `## Execution Bias` block reinforces it negatively further down.
    """
    return "\n".join([
        "## Tooling",
        "",
        "- **Plans start with a skill scan, not the first tool call.** "
        "Multi-step work (anything that needs `TodoWrite`) MUST call "
        "``SkillSearch(query=\"<topic keywords from the request>\")`` "
        "FIRST so any installed runbook covering the task is loaded "
        "before you commit to an approach. Most plans go better with "
        "the skill — the runbook usually names tools, env vars, and "
        "gotchas the model would miss from cold reasoning. If the "
        "ranked search returns nothing relevant, that's a fine "
        "outcome — note it and proceed; the cost of the search is one "
        "small tool call.",
        "- `TodoWrite` is the structured planning tool. **If the work "
        "has 2+ steps AND no `[CURRENT TODO LIST]` marker is present, "
        "call `SkillSearch` first (see above), then "
        "`TodoWrite(todos=[{content,activeForm,status}, ...])` BEFORE "
        "any other tool.** Thinking-only enumerations are not "
        "enough — the user only sees your tool calls, not your "
        "reasoning trace.",
        "- **If a `[CURRENT TODO LIST]` marker is present**, the plan "
        "is already persisted from earlier in this session. Update it "
        "by re-emitting the FULL list via `TodoWrite(todos=[...])` "
        "with statuses set to `pending` / `in_progress` / `completed`. "
        "Exactly ONE item should be `in_progress` at any time.",
        "- As you finish a step, re-emit the list with that step's "
        "status flipped to `completed` — don't batch completions, the "
        "user reads the list live.",
        "- The tool echoes the formatted checklist on every call so "
        "you don't need a separate `list` call to see state.",
        "- When NOT to plan: trivial single-step requests "
        "(\"what's X?\", \"summarise this\"), pure-answer questions, "
        "single-tool-call lookups. A 1-step plan is not a plan.",
        "- Tool descriptions are the source of truth for arguments "
        "and return shape. Re-read the schema if a call fails — the "
        "fix is almost always in the tool's own description.",
        "- For SKILLS, ``SkillSearch`` is the sole entrypoint — it "
        "mirrors ``ToolSearch``. ``SkillSearch()`` lists all "
        "(paginated); ``SkillSearch(query=\"keywords\")`` ranks; "
        "``SkillSearch(query=\"select:name1,name2\")`` loads bodies. "
        "**Do NOT use ``Bash`` / ``Glob`` / ``Grep`` / ``Read`` / "
        "``list_dir`` on the skills directory** — they miss plugin "
        "bundles + `skills_dirs` overrides and bloat the prompt.",
        "- ``SkillSearch`` / ``ToolSearch`` / ``TodoWrite`` / "
        "``remember`` and the rest of YOUR tools are LOCAL to you. A "
        "delegated subagent (``Agent(subagent_type=\"claude\"|"
        "\"codex\"|...)``, ``delegate_claude``, ``delegate_codex``) runs "
        "a DIFFERENT agent with its OWN toolset — it cannot call your "
        "tools and has no access to your skill corpus. When delegating, "
        "describe the task in plain terms and hand over the concrete "
        "context/files it needs; do NOT instruct it to "
        "\"use SkillSearch\" / \"call TodoWrite\" — it will report those "
        "as unavailable. Claude/Codex have their own skill + planning "
        "tooling; let them use it.",
        "",
    ])


# Execution-bias section — verbatim port of OpenClaw's
# `buildExecutionBiasSection`. Negative reinforcement that pairs with
# the Tooling section's positive rule. The phrasing
# "do not finish with a plan/promise when tools can move it forward"
# specifically blocks the failure mode where the model lists steps in
# thinking and narrates instead of calling `todo`.
def execution_bias_prompt_section() -> str:
    """Render the `## Execution Bias` section. Hardcoded, above the
    cache boundary, after the Tooling section."""
    return "\n".join([
        "## Execution Bias",
        "- Actionable request: act in this turn.",
        "- Non-final turn: use tools to advance, or ask for the one "
        "missing decision that blocks safe progress.",
        "- Continue until done or genuinely blocked; do not finish "
        "with a plan/promise when tools can move it forward.",
        "- Weak/empty tool result: vary query, path, command, or "
        "source before concluding.",
        "- Mutable facts need live checks: files, git, clocks, "
        "versions, services, processes, package state.",
        "- Final answer needs evidence: test/build/lint, screenshot, "
        "inspection, tool output, or a named blocker.",
        "- Longer work: brief progress update, then keep going; use "
        "background work or sub-agents when they fit.",
        "",
    ])


# MCP / ACP capability hint. Lives in the stable section so it's
# cache-friendly. Surfaces the configured server / agent names along
# with a one-line description so the model picks the right name on the
# first try, instead of guessing and getting "unknown MCP server".
def mcp_acp_capabilities_block(global_cfg: Optional[dict] = None) -> str:
    """Render an `# EXTERNAL TOOLS — MCP / ACP` section.

    Returns "" when nothing is configured. Reads the live config so a
    config edit is picked up next time the prompt composes.
    """
    if global_cfg is None:
        try:
            from rtxclaw_core.agent import load_global_config
            global_cfg = load_global_config()
        except Exception:  # noqa: BLE001
            global_cfg = {}
    # Canonical key is `mcpServers` (camelCase, what the wizard writes);
    # `mcp_servers` (snake_case) is the legacy fallback. Mirrors
    # `mcp_client.load_mcp_servers()` so the system-prompt MCP block and
    # the runtime see the same servers.
    _gcfg = global_cfg or {}
    mcp_raw = _gcfg.get("mcpServers") or _gcfg.get("mcp_servers") or {}
    acp_raw = _gcfg.get("acp_agents") or {}
    if not isinstance(mcp_raw, dict) or not isinstance(acp_raw, dict):
        return ""
    if not mcp_raw and not acp_raw:
        return ""
    lines: list[str] = ["# EXTERNAL TOOLS — MCP / ACP"]
    if mcp_raw:
        lines.append("")
        lines.append(
            "MCP servers are reachable via `mcp_call` (and "
            "`mcp_list_tools` to discover what's on each one). Pick a "
            "server by its short name:"
        )
        lines.append("")
        for name, row in sorted(mcp_raw.items()):
            if not isinstance(row, dict):
                continue
            transport = (
                row.get("transport")
                or ("stdio" if row.get("command") else "http")
            )
            desc = str(row.get("description") or "").strip()
            tail = f" — {desc}" if desc else ""
            lines.append(f"- `{name}` ({transport}){tail}")
    if acp_raw:
        lines.append("")
        lines.append(
            "ACP agents are reachable via `acp_call` — delegate a "
            "self-contained prompt to a remote agent that has its own "
            "tools and may run autonomously:"
        )
        lines.append("")
        for name, row in sorted(acp_raw.items()):
            if not isinstance(row, dict):
                continue
            desc = str(row.get("description") or "").strip()
            caps_raw = row.get("capabilities") or []
            caps = (
                ", ".join(str(c) for c in caps_raw)
                if isinstance(caps_raw, list) else ""
            )
            tail_bits = []
            if desc:
                tail_bits.append(desc)
            if caps:
                tail_bits.append(f"capabilities: {caps}")
            tail = " — " + " · ".join(tail_bits) if tail_bits else ""
            lines.append(f"- `{name}`{tail}")
    return "\n".join(lines)


def compose_with_cache_boundary(
    stable_sections: list[str],
    dynamic_sections: list[str] | None = None,
) -> str:
    """Convenience builder: glue `stable_sections` with `\\n\\n`,
    append the boundary, then glue `dynamic_sections` with `\\n\\n`.

    Empty/whitespace-only sections drop out so the output never has
    a hanging boundary with nothing dynamic on the other side.
    """
    stable = "\n\n".join(s for s in stable_sections if (s and s.strip()))
    dynamic_sections = dynamic_sections or []
    dynamic = "\n\n".join(s for s in dynamic_sections if (s and s.strip()))
    if not dynamic:
        return stable
    if not stable:
        # No stable head; emit just the dynamic body. A boundary with
        # nothing on the stable side would be a footgun for downstream
        # `split_*` callers expecting a non-empty `stable_prefix`.
        return dynamic
    return f"{stable}{SYSTEM_PROMPT_CACHE_BOUNDARY}{dynamic}"
