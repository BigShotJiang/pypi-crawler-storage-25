"""Model class — opinionated per-model sampling + chat-template knobs.

This is the rtxclaw-vs-OpenClaw differentiator: rtxclaw is prescriptive
about which sampling knobs work well for which model on which provider.
OpenClaw is provider-agnostic; we're not.

Composition with `providers.py`:

- `Provider` describes WIRE format (vLLM vs SGLang — `delta.reasoning`
  vs `delta.reasoning_content`, etc.).
- `Model` describes per-model sampling sweet spots and family-specific
  chat-template kwargs (Qwen3's `thinking_budget`, future Llama-style
  knobs, etc.).

Two orthogonal axes; both feed into the worker's HTTP request.

Each `Model` carries three `ModeSampling` records, one per permission
mode (`plan` / `ask` / `auto`). The runtime picks the right one based
on the session's active mode and forwards the non-None fields to the
upstream `chat/completions` request.

Add a new model: append a `Model(...)` to `KNOWN_MODELS` and tune its
mode-specific sampling. `for_name()` resolves an upstream model id
(exact name → family-prefix → fallback to `GENERIC` defaults).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from typing import Any, Optional, Union

from rtxclaw_core.tools.permissions import PermissionMode


@dataclass(frozen=True)
class ModeSampling:
    """Per-mode sampling knobs. `None` for any field = let upstream default.

    `enable_thinking` and `thinking_budget` ride inside
    `chat_template_kwargs`; the rest go on the top-level chat/completions
    body. `sampling_to_request_fields()` does the split.
    """
    temperature: float = 0.6
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    min_p: Optional[float] = None
    repetition_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None
    max_completion_tokens: Optional[int] = None
    seed: Optional[int] = None
    # Qwen3-family chat-template kwargs (None = unset, let server default).
    enable_thinking: Optional[bool] = None
    thinking_budget: Optional[Union[str, int]] = None


# Mode defaults baked in once and re-used across every Model that doesn't
# override. These match the Qwen team's OFFICIAL Qwen3.6 thinking-mode
# guidance from the Qwen3.6-27B model card:
#
#   https://huggingface.co/Qwen/Qwen3.6-27B
#   Thinking mode (general):  temperature=1.0, top_p=0.95, top_k=20,
#                              min_p=0.0, presence_penalty=0.0,
#                              repetition_penalty=1.0
#   Thinking mode (precise):   temperature=0.6, top_p=0.95, top_k=20,
#                              min_p=0.0, presence_penalty=0.0,
#                              repetition_penalty=1.0
#   Instruct (non-thinking):   temperature=0.7, top_p=0.80, top_k=20,
#                              min_p=0.0, presence_penalty=1.5,
#                              repetition_penalty=1.0
#
# The FP8 variant's generation_config.json (2026-04-24) does not
# specify presence_penalty, defaulting to 0.0 in Transformers:
#   https://huggingface.co/Qwen/Qwen3.6-27B-FP8/raw/main/generation_config.json
#
# rtxclaw uses thinking mode, so we follow the thinking-mode
# recommendation: presence_penalty=0.0. The Qwen3-family docs
# (Qwen3-32B / Qwen3-30B-A3B-Thinking-2507) previously recommended
# presence_penalty in [0, 2] for repetition reduction — Qwen3.6
# specifically dialled it to 0.0 for thinking, reserving 1.5 for
# non-thinking instruct mode. Loop protection is handled by the
# runtime streaming detector + DRY sampler + server-side
# repetition_detection, not by presence_penalty.
# `repetition_penalty=1.0` (off) per Qwen's earlier guidance that
# `repetition_penalty > 1.0` in thinking mode hurts CoT quality.
#
# Per-mode budgets:
# - `plan`: high thinking budget + big completion ceiling so architectural
#   answers don't truncate themselves. The "fix laziness" lever.
# - `ask` / `auto`: same sampling, smaller budgets for snappy turns.

# Per-mode completion ceilings. The runtime no longer compacts at a
# soft fraction of context — it only fires when the request would
# actually overflow `upstream_max_context` (or the upstream returns a
# context-length 400). So a generous max_tokens here doesn't push
# compaction earlier; it just gives the model room to write.
#
# - `plan`: 16k — exhaustive synthesis answers
# - `ask` / `auto`: 8k — tool-driven workflows; the length-continue
#   path picks up where it left off if a particular answer goes long.
_PLAN_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    min_p=0.0,
    presence_penalty=0.0,
    repetition_penalty=1.0,
    max_completion_tokens=16384,
    enable_thinking=True,
    # PLAN is the "deep thinking / fix laziness" lever — the
    # higher max_completion_tokens above pairs with a thinking
    # budget that matches the output ceiling so an architectural
    # synthesis answer can spend up to 16k on CoT before the
    # answer phase. ASK / AUTO stay at 4k for snappy interactive
    # use.
    thinking_budget=16384,
)

_ASK_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    min_p=0.0,
    presence_penalty=0.0,
    repetition_penalty=1.0,
    # 16k output ceiling so thinking-first models (Qwen3.6-27B et al.)
    # always have headroom to land a content reply after a long
    # reasoning phase. With 8k, the model exhausted the budget on
    # thinking and emitted `content: null`, which the bot rendered as
    # an empty reply.
    max_completion_tokens=16384,
    enable_thinking=True,
    thinking_budget=8192,
)

_AUTO_DEFAULT = ModeSampling(
    temperature=0.6,
    top_p=0.95,
    top_k=20,
    # min_p=0.0 (off) by default: several vLLM deployments run with
    # speculative decoding enabled, which rejects ``min_p`` (and
    # ``logit_bias``) with HTTP 400 served as an in-band SSE error
    # chunk on a stream=true request. The worker silently dropped
    # that chunk pre-fix and the turn died after 0 tokens. Opt back
    # in via ``RTXCLAW_AUTO_MIN_P=0.05`` only when the upstream is
    # known to support it (no speculative decoding).
    min_p=0.0,
    presence_penalty=0.0,
    repetition_penalty=1.0,
    # Same headroom story as ASK — see comment above. 16k output / 8k
    # thinking matches PLAN's safety margin for thinking models without
    # breaking compaction (compact_at_frac is a fraction of total
    # context, not output length).
    max_completion_tokens=16384,
    enable_thinking=True,
    thinking_budget=8192,
)


def _env_float(name: str) -> Optional[float]:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return None
    try:
        return float(raw)
    except ValueError:
        return None


# A/B knob for emergency tuning: set RTXCLAW_AUTO_PRESENCE_PENALTY
# (e.g. 1.5) to override on top of the auto profile without a code
# change. The Qwen3.6-27B model card recommends 0.0 for thinking
# mode (default here) and 1.5 for non-thinking instruct mode.
# If the DRY sampler + server-side repetition_detection aren't
# catching paragraph-level repeats, dial this up toward 1.5.
# Conversely, if you see language mixing or CoT quality degradation,
# keep it at 0.0.
_AUTO_PP_OVERRIDE = _env_float("RTXCLAW_AUTO_PRESENCE_PENALTY")
if _AUTO_PP_OVERRIDE is not None:
    _AUTO_DEFAULT = replace(_AUTO_DEFAULT, presence_penalty=_AUTO_PP_OVERRIDE)

# A/B knob for min_p: set RTXCLAW_AUTO_MIN_P (e.g. 0.05) to enable
# the Min-P sampler without a code change. Min-P (arXiv 2407.01082)
# truncates tokens whose probability is below min_p × max_prob,
# acting as a dynamic top-p that adapts to the model's confidence
# distribution. Default 0.05 is the 2026 community-validated sweet
# spot for Qwen3-family reasoning models — low enough to avoid
# breaking tool-call accuracy, high enough to suppress low-
# probability slop tokens that seed repetition loops. Off (0.0) by
# default because vLLM rejects ``min_p`` under speculative decoding
# with a 400 served as an in-band SSE error chunk; opt in per-
# deployment when the upstream is known to support it.
_AUTO_MIN_P_OVERRIDE = _env_float("RTXCLAW_AUTO_MIN_P")
if _AUTO_MIN_P_OVERRIDE is not None:
    _AUTO_DEFAULT = replace(_AUTO_DEFAULT, min_p=_AUTO_MIN_P_OVERRIDE)


@dataclass(frozen=True)
class Model:
    """One model's per-mode sampling profile + family identity.

    `name` is matched (case-insensitive) against upstream model ids — exact
    match wins, falling back to substring match against the model name.
    `family` describes the chat-template family ("qwen3", "gemma4", …) for
    callers that want to dispatch on family rather than model.

    `thinking_tags` are the open/close markers the model emits around its
    chain-of-thought when no reasoning parser is active server-side.
    Qwen3 uses `<think>...</think>`; Gemma 4 uses `<thought>...</thought>`.
    Used by the worker's `ThinkSplitter` to route inline reasoning into
    the thinking channel.

    `prefill_thinking_open_tag=True` means the request builder should
    end the prompt with the open tag (e.g. `<thought>\n`) using vLLM's
    `continue_final_message=true` so generation begins inside a thought
    block. This is the documented Gemma 4 thinking pattern.
    """
    name: str
    family: str = ""
    plan: ModeSampling = field(default_factory=lambda: _PLAN_DEFAULT)
    ask: ModeSampling = field(default_factory=lambda: _ASK_DEFAULT)
    auto: ModeSampling = field(default_factory=lambda: _AUTO_DEFAULT)
    thinking_tags: tuple[str, str] = ("<think>", "</think>")
    prefill_thinking_open_tag: bool = False
    extra_sampling: dict[str, Any] = field(default_factory=dict)
    # Worker post-stream `chars_per_token < floor` ratio guard. Default
    # ``None`` falls back to ``$RTXCLAW_LOOP_CHARS_PER_TOKEN_MIN`` (1.5).
    # Quantization-fragile families (gemma-4 NVFP4) tighten this so a
    # round that emits text at less than the family's typical chars/
    # token rate trips the loop guard one round earlier.
    loop_chars_per_token_min: Optional[float] = None
    # Per-model absolute compaction trigger (in prompt tokens). When
    # set, the bridge's `_maybe_compact` squeezes old tool results
    # before the next round if `prompt_tokens >=
    # compact_at_max_prompt_tokens`, regardless of the agent-level
    # `compact_at_frac × upstream_max_context` threshold. Use this to
    # keep quantization-fragile models inside their reliable operating
    # range (FP8 / NVFP4 attention layers degrade past their
    # documented stable region — Qwen3.6-FP8 collapse-mode is
    # documented past long context per QwenLM/Qwen3.5#115). Default
    # ``None`` defers entirely to the agent-level config.
    compact_at_max_prompt_tokens: Optional[int] = None

    def sampling_for(self, mode: PermissionMode) -> ModeSampling:
        """Return the `ModeSampling` for the given permission mode."""
        return getattr(self, mode.value)


# Known models. Append here when a new local model joins your fleet.
#
# Qwen3 family. `presence_penalty=0.0` per the Qwen3.6-27B model card's
# thinking-mode recommendation (the model card reserves
# presence_penalty=1.5 for non-thinking instruct mode — rtxclaw uses
# thinking). Repetition protection is handled by DRY sampler +
# server-side `repetition_detection` + the runtime streaming loop
# detector, not by presence_penalty.
# Settings deliberately lenient compared to gemma's (3/20/4): qwen's
# observed failure mode is paragraph-level repeats during reasoning,
# not the token-collapse pattern that hits gemma-4-NVFP4. Larger
# `min_pattern_size` avoids false positives on legitimate tight
# structures (numbered-list scaffolding, repeated tool-result markers,
# code snippets with regular cadence). `min_count=8` requires the
# loop to be unambiguous before firing.
QWEN3_6 = Model(
    name="qwen3.6",
    family="qwen3",
    extra_sampling={
        # DRY sampler: exponential penalty for sequence repetition
        # (dry_multiplier × dry_base^(seq_len - dry_allowed_length)).
        # Critical for Qwen3.6-27B-FP8's tendency to slop in large
        # contexts; dry_allowed_length=4 hedges higher than Gemma's 2
        # because Qwen is more prone to legitimate repetition.
        "dry_multiplier": 0.8,
        "dry_base": 1.75,
        "dry_allowed_length": 4,
        "dry_sequence_breakers": ["\n", ".", "!", "?", ":", "—", "```"],
        "repetition_detection": {
            "max_pattern_size": 80,
            "min_pattern_size": 4,
            "min_count": 5,
        },
    },
    # Match the gemma-4 ratio guard floor explicitly so the post-
    # stream `chars_per_token < 1.5` check is documented per-model
    # rather than relying on the env-default fallback. Qwen3-FP8's
    # documented coherence collapse on long context produces the
    # same low chars/token signature as gemma-NVFP4's token collapse,
    # so the same floor applies.
    loop_chars_per_token_min=1.5,
    # Compact context at 128k prompt tokens. Qwen3.6-27B-FP8 advertises
    # 256k native context but the long-context decode cliff (single-
    # digit tok/s past 16k per the vLLM recipe) and the linear-attn
    # FP8 quantization fragility (QwenLM/Qwen3.5#115) make 128k a
    # comfortable ceiling — gives the model 4× the documented sweet
    # spot, well below the size where the SSM-block coherence
    # collapse has been reproduced. The bridge squeezes old tool
    # results before the next round once we cross this; the model
    # keeps the compaction summary in `sess.compaction_summary`.
    compact_at_max_prompt_tokens=128_000,
)

# Gemma 3/4 family. vLLM with `--reasoning-parser gemma4` splits the
# thought channel off into `delta.reasoning_content`; the worker's
# splitter handles any leaked markers as a safety net.
#
# Protocol (per ai.google.dev/gemma/docs/core/prompt-formatting-gemma4
# and vLLM's gemma4 recipe): Gemma 4 wraps thinking in an *asymmetric*
# channel marker — open `<|channel>thought\n`, close `<channel|>` (note
# the `|` swaps sides). Thinking is enabled via the chat-template kwarg
# `enable_thinking=true`, NOT by prefilling an open tag with
# `continue_final_message=true` (we used to do that for `<thought>`,
# which is a different format that does not match Gemma 4's tokenizer
# — vLLM's parser then misclassified the entire response as reasoning
# and the TUI showed an empty bubble because `reasoning_visibility=off`
# is the default).
#
# Sampling: Gemma 4 31B has a model-level repetition bug
# (google-deepmind/gemma#622, vllm-project/vllm#40080) that
# `repetition_penalty` does not fix. Community-validated mitigation for
# agentic / tool-calling use is lower temperature, mild
# frequency/presence penalty, and `min_p=0` (any positive `min_p`
# breaks Gemma 4 tool calling).
#
# `max_completion_tokens=2048` is a deliberate tightening from the
# 4096 we initially shipped: NVFP4 quantization leaves attention
# weights in BF16 but truncates MLP mantissa, which in practice means
# the model is more likely to slip into a token-collapse loop on long
# planning rounds (we observed 4096-token loops at ~40k prompt
# context on gpu-d/gemma-4-31b-nvfp4-mtp). A 2048 ceiling lets the
# model land a normal answer in one round but caps the per-round blast
# radius when the streaming loop detectors haven't caught the
# collapse yet — pairs with the worker's `chars_per_token < 1.5`
# ratio guard that fires post-stream.
_GEMMA_SAMPLING = ModeSampling(
    temperature=0.4,
    top_p=0.9,
    top_k=20,
    min_p=0.0,
    frequency_penalty=0.4,
    presence_penalty=0.3,
    repetition_penalty=1.05,
    max_completion_tokens=2048,
    enable_thinking=True,
)

GEMMA4 = Model(
    name="gemma",
    family="gemma4",
    plan=_GEMMA_SAMPLING,
    ask=_GEMMA_SAMPLING,
    auto=_GEMMA_SAMPLING,
    thinking_tags=("<|channel>thought\n", "<channel|>"),
    prefill_thinking_open_tag=False,
    # NVFP4 + MTP slip into token-collapse looping more readily than
    # BF16/FP8 baselines do. Healthy per-round ratios on gpu-d measure
    # 1.7–3.5 chars/token; 2.0 is comfortably above the noise floor
    # while still being tight enough to catch a collapse round (live
    # measured collapse: 0.37 chars/token).
    loop_chars_per_token_min=2.0,
    extra_sampling={
        "dry_multiplier": 0.8,
        "dry_base": 1.75,
        "dry_allowed_length": 2,
        "dry_sequence_breakers": ["\n", ".", "!", "?", "<", ">"],
        # vLLM's server-side RepetitionDetectionParams (per the
        # community recipe for gemma-4-31b-nvfp4-mtp dual-GPU loop
        # mitigation): detect any 3–20 token N-gram repeating ≥4
        # times and end generation early. This is the in-decoder
        # backstop — fires before our streaming `_detect_loops_layered`
        # ever sees the chars, saving the upstream tokens we'd
        # otherwise burn while the streaming detector samples every
        # `LOOP_CHECK_STRIDE` chars.
        "repetition_detection": {
            "max_pattern_size": 20,
            "min_pattern_size": 3,
            "min_count": 4,
        },
    },
)

# Truly-generic model profile for upstream APIs (OpenAI, xAI/Grok, Anthropic,
# OpenRouter, etc.) that do NOT support vLLM-specific sampling knobs like
# `presence_penalty`, `min_p`, `top_k`, `repetition_penalty`, or
# `frequency_penalty`. Every field is `None` so `sampling_to_request_fields`
# drops them — the upstream gets its own defaults. `max_completion_tokens`
# is set to a sensible ceiling so open-ended chat doesn't truncate the
# model. The per-turn override (`backend.cfg.temperature` in acp_bridge.py)
# sets `temperature` after the profile is applied, so we don't need one
# here either.
_GENERIC_PLAN = ModeSampling(
    max_completion_tokens=16384,
)
_GENERIC_ASK = ModeSampling(
    max_completion_tokens=16384,
)
_GENERIC_AUTO = ModeSampling(
    max_completion_tokens=16384,
)

GENERIC = Model(
    name="generic",
    family="",
    plan=_GENERIC_PLAN,
    ask=_GENERIC_ASK,
    auto=_GENERIC_AUTO,
)

KNOWN_MODELS: tuple[Model, ...] = (QWEN3_6, GEMMA4)


def for_name(name: str) -> Model:
    """Resolve a Model by upstream model id. Falls back to `GENERIC`.

    Case-insensitive. Exact name match first; then substring (so
    `qwen3.6-27b-fp8` matches `qwen3.6`). Path-style ids (SGLang's
    `/home/.../Qwen3.6-27B`) are normalized to the basename for matching.
    """
    if not name:
        return GENERIC
    n = name.lower()
    base = n.rsplit("/", 1)[-1]
    for m in KNOWN_MODELS:
        if m.name.lower() == base or m.name.lower() == n:
            return m
    for m in KNOWN_MODELS:
        m_n = m.name.lower()
        if m_n and (m_n in n or m_n in base):
            return m
    return GENERIC


# Top-level chat/completions request fields we know about. Anything else
# in `ModeSampling` rides as a chat_template_kwarg.
_REQUEST_FIELD_NAMES: tuple[str, ...] = (
    "temperature",
    "top_p",
    "top_k",
    "min_p",
    "repetition_penalty",
    "presence_penalty",
    "frequency_penalty",
    "seed",
)


def sampling_to_request_fields(s: ModeSampling) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split a `ModeSampling` into (top-level request fields, chat_template_kwargs).

    The top-level dict goes onto the chat/completions body; the
    chat_template_kwargs dict goes inside `chat_template_kwargs` so vLLM /
    SGLang forward it to the model's chat template (e.g. Qwen3's
    `enable_thinking` / `thinking_budget`). None values are dropped so we
    only send explicit knobs.
    """
    request_fields: dict[str, Any] = {}
    for k in _REQUEST_FIELD_NAMES:
        v = getattr(s, k, None)
        if v is not None:
            request_fields[k] = v
    if s.max_completion_tokens is not None:
        # OpenAI-compat name for the cap.
        request_fields["max_tokens"] = s.max_completion_tokens

    template_kwargs: dict[str, Any] = {}
    if s.enable_thinking is not None:
        template_kwargs["enable_thinking"] = s.enable_thinking
    if s.thinking_budget is not None:
        template_kwargs["thinking_budget"] = s.thinking_budget

    return request_fields, template_kwargs


def merge_overrides(base: ModeSampling, override: dict[str, Any] | None) -> ModeSampling:
    """Apply an override dict (from a per-turn `sampling` request body) on top of `base`.

    Returns a new `ModeSampling` with override fields replacing base fields
    where the override is non-None. Fields not present in override or set
    to None are inherited from base. Unknown keys in override are ignored
    so callers can't smuggle arbitrary fields through.
    """
    if not override:
        return base
    valid = {f.name for f in base.__dataclass_fields__.values()}
    kwargs = {f: getattr(base, f) for f in valid}
    for k, v in override.items():
        if k in valid and v is not None:
            kwargs[k] = v
    return ModeSampling(**kwargs)
