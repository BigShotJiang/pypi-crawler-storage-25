"""Shared primitives for memory + session indexing.

Re-exports the chunker / FTS / BM25 helpers from `memory_index.py` so
new callers (session search, fact provider, future indexers) don't
have to reach into the OpenClaw-byte-compat module — and don't have
to duplicate the logic when their schema is simpler than memory.db's.

Also defines:

- `chunk_text(...)` — paragraph-based chunker that returns
  `(start_line, end_line, text)` tuples. Cheaper than
  `chunk_markdown` when the caller doesn't need OpenClaw-shaped chunk
  objects (no SHA-256 ids, no source tag).
- `RecallResult` — uniform recall hit shape for cross-source ranking.
  Memory hits, session hits, and provider-supplied facts all
  serialize through the same dataclass so the formatter can render
  them consistently.
- `format_recall_hits(...)` — markdown renderer the model can cite
  directly (mirrors the layout `memory_tools._format_hit` uses).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from rtxclaw_memory.memory_index import (
    CHARS_PER_TOKEN,
    DEFAULT_CHUNK_OVERLAP,
    DEFAULT_CHUNK_TOKENS,
    DEFAULT_SNIPPET_CHARS,
    bm25_rank_to_score,
    build_fts_query,
    chunk_markdown,
)


# ---- paragraph-based chunker --------------------------------------

def chunk_text(
    text: str,
    *,
    target_tokens: int = DEFAULT_CHUNK_TOKENS,
    overlap_tokens: int = DEFAULT_CHUNK_OVERLAP,
) -> list[tuple[int, int, str]]:
    """Split `text` into chunks of ~`target_tokens` tokens each.

    Returns `(start_line, end_line, text)` tuples (1-based, inclusive).
    Works on any text (not just markdown). Splits on blank-line
    paragraph boundaries when possible; falls back to line-by-line
    when paragraphs exceed `target_chars`.

    Differences vs. `chunk_markdown`:
      - No `Chunk` dataclass with id / source / hash. The caller picks
        whatever metadata is meaningful for its store.
      - Boundary preference: paragraph break > line break. Better for
        prose; worse for code.
    """
    target_chars = max(1, target_tokens) * CHARS_PER_TOKEN
    overlap_chars = max(0, overlap_tokens) * CHARS_PER_TOKEN
    text = text or ""
    if not text.strip():
        return []

    # Build line index so we can report (start_line, end_line) without
    # losing track when we re-emit overlap content as a seed.
    lines = text.split("\n")
    if not lines:
        return []

    out: list[tuple[int, int, str]] = []
    cur_lines: list[str] = []
    cur_start_line = 1
    cur_chars = 0
    last_para_break: int | None = None  # index into cur_lines

    def _emit(end_line: int) -> None:
        if not cur_lines:
            return
        body = "\n".join(cur_lines).rstrip()
        if not body:
            return
        out.append((cur_start_line, end_line, body))

    for i, line in enumerate(lines, 1):
        cur_lines.append(line)
        cur_chars += len(line) + 1
        if not line.strip():
            last_para_break = len(cur_lines)  # boundary AFTER this line
        if cur_chars < target_chars:
            continue

        # Time to emit. Prefer cutting at the most recent paragraph
        # break so semantic units stay together.
        if last_para_break is not None and last_para_break > 0:
            head = cur_lines[:last_para_break]
            tail = cur_lines[last_para_break:]
            head_end_line = cur_start_line + last_para_break - 1
            cur_lines = head
            _emit(head_end_line)
            seed_lines = tail
            seed_start_line = head_end_line + 1
            cur_lines = []
            cur_chars = 0
            last_para_break = None
        else:
            _emit(i)
            seed_lines = []
            seed_start_line = i + 1
            cur_lines = []
            cur_chars = 0
            last_para_break = None

        # Carry an overlap of the just-emitted text plus any tail we
        # already had, so the next chunk shares context with the
        # previous one.
        if overlap_chars > 0 and out:
            prev_body = out[-1][2]
            # Carry approximately `overlap_chars` from the END of
            # prev_body into the new chunk.
            tail_carry = prev_body[-overlap_chars:] if len(prev_body) > overlap_chars else prev_body
            tail_lines = tail_carry.split("\n")
            # Compute the line range the overlap maps to.
            prev_start = out[-1][0]
            prev_end = out[-1][1]
            overlap_start_line = max(prev_start, prev_end - len(tail_lines) + 1)
            seed_lines = tail_lines + seed_lines
            seed_start_line = min(seed_start_line, overlap_start_line)

        cur_start_line = seed_start_line
        cur_lines = list(seed_lines)
        cur_chars = sum(len(ln) + 1 for ln in cur_lines)

    if cur_lines:
        _emit(cur_start_line + len(cur_lines) - 1)

    return out


# ---- uniform recall hit shape -------------------------------------

@dataclass(frozen=True)
class RecallResult:
    """One recall hit, source-agnostic.

    Used by:
      - `session_index.SessionIndex.search` (source="session")
      - `sqlite_facts.SqliteFactsStore` recall paths (source="facts")
      - `MemoryProvider.prefetch` adapters that want to pre-format

    `metadata` is intentionally untyped — different sources carry
    different context (date for sessions, category+trust for facts).
    Renderers should treat unknown keys as opaque.
    """

    source: str
    path_or_id: str
    title: str
    snippet: str
    score: float
    metadata: dict[str, Any] = field(default_factory=dict)


# ---- markdown renderer for hit lists -------------------------------

def format_recall_hits(hits: Iterable[RecallResult], *, header: str = "") -> str:
    """Render hits as markdown. Empty input renders the empty string.

    Layout matches `memory_tools._format_hit` so the model sees a
    consistent shape across `memory_search` / `session_search` /
    `fact_store search`.
    """
    hits_list = list(hits)
    if not hits_list:
        return ""
    bits: list[str] = []
    if header:
        bits.append(header)
        bits.append("")
    for i, h in enumerate(hits_list, 1):
        bits.append(
            f"### {i}. {h.title}  ({h.source}, score {h.score:.3f})"
        )
        if h.metadata:
            meta_str = " · ".join(
                f"{k}={v}" for k, v in h.metadata.items()
                if v not in (None, "", [])
            )
            if meta_str:
                bits.append(f"_{meta_str}_")
        snippet = (h.snippet or "(empty)")[:DEFAULT_SNIPPET_CHARS]
        bits.append(snippet)
        bits.append("")
    return "\n".join(bits).rstrip() + "\n"


__all__ = [
    "CHARS_PER_TOKEN",
    "DEFAULT_CHUNK_OVERLAP",
    "DEFAULT_CHUNK_TOKENS",
    "DEFAULT_SNIPPET_CHARS",
    "RecallResult",
    "bm25_rank_to_score",
    "build_fts_query",
    "chunk_markdown",
    "chunk_text",
    "format_recall_hits",
]
