"""rtxclaw-memory — fact / vector / synth memory subsystem.

Split out of ``rtxclaw_core`` so the memory pipeline (index, embed,
manager, provider, primitives, synth, tools, write) is its own
distribution-shaped package. ``rtxclaw_core`` no longer needs to grow
every time a new memory module lands.

Public surface is the modules themselves; import them directly:

    from rtxclaw_memory.memory_index import MemoryIndex
    from rtxclaw_memory.memory_embed import resolve_embedder
    from rtxclaw_memory.memory_write import remember
"""
from __future__ import annotations

__all__: list[str] = []
