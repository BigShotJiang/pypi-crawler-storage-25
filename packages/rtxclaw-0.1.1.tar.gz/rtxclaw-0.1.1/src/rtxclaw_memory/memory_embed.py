"""Embedding providers for the memory index.

`resolve_embedder()` is the single entry point: reads the active
agent's config + global config + env vars, and returns the configured
`Embedder` (or `None` to fall back to BM25-only). Everything else is
internal.

Provider auto-select chain mirrors OpenClaw's `doctor-memory-search`
priority list (high to low): `openai`, `gemini`, `voyage`, `mistral`,
then local providers (`ollama`, `lmstudio`). Currently `openai` and
`ollama` are wired; adding others is a matter of one new adapter
class each.

Each adapter implements:

    provider     : str    — stable id ("openai" / "ollama" / ...)
    model        : str    — embedding model name
    dims         : int    — vector dimension
    provider_key : str    — SHA-256 over (provider | base_url | org),
                            used to scope `embedding_cache` rows
    embed_query(text)        -> list[float]
    embed_batch(texts)       -> list[list[float]]

`embed_batch` returns vectors aligned with the input order. Failures
raise — `MemoryIndex` catches and falls back to a None vector for
the failed item, so partial-failure batches don't poison the index.

All vectors are L2-normalized before storage so cosine similarity is
equivalent to the inner product (consistent with what `chunks_vec`
and our fallback in-Python cosine assume).
"""
from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
from typing import Any, Optional


# OpenAI defaults — match `doctor-memory-search-DA8TSpcF.js` / OpenClaw.
DEFAULT_OPENAI_MODEL: str = "text-embedding-3-small"
DEFAULT_OPENAI_DIMS: int = 1536

# Ollama default — `nomic-embed-text` is the most common local choice.
DEFAULT_OLLAMA_MODEL: str = "nomic-embed-text"
DEFAULT_OLLAMA_DIMS: int = 768
DEFAULT_OLLAMA_BASE_URL: str = "http://localhost:11434"


def _normalize(vec: list[float]) -> list[float]:
    """L2-normalize a vector. NaN/Inf inputs collapse to a zero vector
    so we never write garbage into the index.
    """
    cleaned = [x if math.isfinite(x) else 0.0 for x in vec]
    norm = math.sqrt(sum(x * x for x in cleaned))
    if norm < 1e-10:
        return cleaned
    return [x / norm for x in cleaned]


def _provider_key(provider: str, base_url: str = "", organization: str = "") -> str:
    """SHA-256(provider | base_url | organization). Same scope key
    OpenClaw stores in `embedding_cache.provider_key`.
    """
    payload = f"{provider}|{base_url}|{organization}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ---- OpenAI ----

class OpenAIEmbedder:
    """OpenAI text-embedding-* adapter via the official SDK.

    The model and dim are bound at construction time so a bound
    `Embedder` instance is internally consistent. Switching models
    requires a new instance (and a re-index, gated on `scope_hash`).
    """

    provider = "openai"

    def __init__(
        self,
        *,
        api_key: str,
        model: str = DEFAULT_OPENAI_MODEL,
        dims: int = DEFAULT_OPENAI_DIMS,
        base_url: str = "",
        organization: str = "",
        timeout: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("OPENAI_API_KEY required for OpenAI embedder")
        try:
            from openai import AsyncOpenAI  # type: ignore[import-not-found]
        except ImportError as e:
            raise RuntimeError(
                "openai SDK not installed; run `pip install openai`"
            ) from e
        kwargs: dict[str, Any] = {"api_key": api_key, "timeout": timeout}
        if base_url:
            kwargs["base_url"] = base_url
        if organization:
            kwargs["organization"] = organization
        self._client = AsyncOpenAI(**kwargs)
        self.model = model
        self.dims = dims
        self.provider_key = _provider_key(self.provider, base_url, organization)

    async def embed_query(self, text: str) -> list[float]:
        vecs = await self.embed_batch([text])
        return vecs[0] if vecs else []

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        # OpenAI's batch endpoint accepts up to 2048 items; we cap at
        # 512 because the embedding endpoint has a 300k token-per-batch
        # ceiling and 512 chunks of 400 tokens fits comfortably.
        out: list[list[float]] = []
        for i in range(0, len(texts), 512):
            batch = texts[i : i + 512]
            resp = await self._client.embeddings.create(
                model=self.model,
                input=batch,
            )
            for d in resp.data:
                out.append(_normalize(list(d.embedding)))
        return out


# ---- Ollama ----

class OllamaEmbedder:
    """Local Ollama embedder via the OpenAI-compatible /api/embeddings."""

    provider = "ollama"

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_OLLAMA_BASE_URL,
        model: str = DEFAULT_OLLAMA_MODEL,
        dims: int = DEFAULT_OLLAMA_DIMS,
        timeout: float = 60.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.dims = dims
        self.timeout = timeout
        self.provider_key = _provider_key(self.provider, self.base_url)

    async def embed_query(self, text: str) -> list[float]:
        vecs = await self.embed_batch([text])
        return vecs[0] if vecs else []

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        import httpx
        out: list[list[float]] = []
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            # Ollama's /api/embeddings accepts one text at a time — issue
            # a small concurrency batch instead of a bulk call.
            import asyncio
            sem = asyncio.Semaphore(4)

            async def _one(t: str) -> list[float]:
                async with sem:
                    r = await c.post(
                        f"{self.base_url}/api/embeddings",
                        json={"model": self.model, "prompt": t},
                    )
                    r.raise_for_status()
                    data = r.json()
                    vec = data.get("embedding") or []
                    return _normalize([float(x) for x in vec])

            results = await asyncio.gather(*[_one(t) for t in texts])
            out.extend(results)
        return out


# ---- factory ----

def _read_codex_api_key() -> str:
    """Pull `OPENAI_API_KEY` from `~/.codex/auth.json`.

    OpenClaw and the OpenAI Codex CLI store the operator's API key in
    `~/.codex/auth.json` when `auth_mode == "apikey"`. Reading it here
    means rtxclaw's memory embedder Just Works on machines where the
    user has already authenticated `codex` / OpenClaw without forcing
    them to also export `OPENAI_API_KEY` into their shell. Returns "" if
    the file is missing, malformed, or in OAuth (`chatgpt`) mode.
    """
    import json as _json
    try:
        path = Path.home() / ".codex" / "auth.json"
        if not path.is_file():
            return ""
        data = _json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    if not isinstance(data, dict):
        return ""
    if data.get("auth_mode") != "apikey":
        # OAuth tokens live under `tokens.access_token` and rotate
        # frequently; they don't authenticate `api.openai.com/v1/embeddings`,
        # only Codex's bridge. Skip silently.
        return ""
    key = data.get("OPENAI_API_KEY")
    return key if isinstance(key, str) else ""


# Module-level singleton cache. Building an `OpenAIEmbedder` constructs
# an `AsyncOpenAI` httpx client; tearing it down per-search means every
# memory_search pays a cold-TLS handshake (~500-1000ms)
# AND a new asyncio loop creation (the runner uses
# `_run_blocking_coroutine` from inside the gateway's event loop, which
# spawns a fresh thread + loop per call). Reusing the embedder lets the
# httpx client keep its connection pool warm.
#
# Keyed by the (provider, base_url, organization, dims, model) tuple so
# config changes invalidate the cache. The `None` sentinel is also
# cached so repeated "no embedder configured" calls don't re-walk env +
# config files on each search.
_EMBEDDER_CACHE: dict[tuple, Optional[Any]] = {}


def _config_mtime() -> float:
    """`mtime_ns` of the global config file, or 0 if it doesn't exist.

    Folded into the embedder cache key so an operator who edits
    `~/.rtxclaw/config.json` (e.g. to switch embedding model) gets a
    fresh embedder on the next lookup — without `clear_embedder_cache`.
    Cheap (one stat call per lookup); the cache key tuple stays small.
    """
    try:
        from rtxclaw_core.agent import global_config_path
        p = global_config_path()
        st = p.stat()
    except (OSError, FileNotFoundError):
        return 0.0
    return float(st.st_mtime_ns)


def _embedder_cache_key(
    *, provider: str, model: str, dims: int, base_url: str, organization: str,
) -> tuple:
    # Include the config-file mtime so post-edit lookups bypass the
    # cache automatically.
    return (provider, model, dims, base_url, organization, _config_mtime())


def resolve_embedder() -> Optional[Any]:
    """Build the configured embedder, or None if disabled / unavailable.

    Cached at module scope — repeated calls return the same instance so
    the underlying httpx connection pool stays warm. Use
    `clear_embedder_cache()` to invalidate (e.g. after a config edit).

    Resolution order:

    1. `RTXCLAW_MEMORY_EMBEDDING_PROVIDER` env var (one of `openai`,
       `ollama`, `none`, or unset/auto). Lets the operator force a
       provider for tests.
    2. Global config (`~/.rtxclaw/config.json`):
       - `memory_embedding.provider`
       - `memory_embedding.model`
       - `memory_embedding.dims`
       - `memory_embedding.base_url`
       - `memory_embedding.organization`
       - `memory_embedding.api_key` (or env `OPENAI_API_KEY`)
    3. `~/.codex/auth.json` — the same file OpenClaw / `codex` write
       when the user runs `codex login` with an API key. Lets
       embedding Just Work without an explicit env var if the user
       already authenticated those tools.
    4. Auto-detect Ollama via `OLLAMA_BASE_URL` or pingable
       `localhost:11434`.

    Returns None silently when nothing is configured. Memory tools fall
    back to BM25-only — search still works, just less semantically.
    """
    provider = os.environ.get("RTXCLAW_MEMORY_EMBEDDING_PROVIDER", "").strip().lower()
    cfg: dict[str, Any] = {}
    try:
        from rtxclaw_core.agent import load_global_config
        cfg = (load_global_config() or {}).get("memory_embedding") or {}
    except Exception:  # noqa: BLE001
        cfg = {}

    if not provider:
        provider = str(cfg.get("provider") or "auto").strip().lower()
    if provider == "none":
        return None

    if provider in ("auto", "openai", ""):
        api_key = (
            os.environ.get("OPENAI_API_KEY")
            or str(cfg.get("api_key") or "")
            or _read_codex_api_key()
        )
        if api_key or provider == "openai":
            model = str(cfg.get("model") or DEFAULT_OPENAI_MODEL)
            dims = int(cfg.get("dims") or DEFAULT_OPENAI_DIMS)
            base_url = str(cfg.get("base_url") or "")
            organization = str(cfg.get("organization") or "")
            key = _embedder_cache_key(
                provider="openai", model=model, dims=dims,
                base_url=base_url, organization=organization,
            )
            if key in _EMBEDDER_CACHE:
                return _EMBEDDER_CACHE[key]
            try:
                inst = OpenAIEmbedder(
                    api_key=api_key,
                    model=model,
                    dims=dims,
                    base_url=base_url,
                    organization=organization,
                )
                _EMBEDDER_CACHE[key] = inst
                return inst
            except (RuntimeError, ValueError):
                if provider == "openai":
                    return None
                # auto: fall through to Ollama
    if provider in ("auto", "ollama"):
        base_url = (
            os.environ.get("OLLAMA_BASE_URL")
            or str(cfg.get("base_url") or DEFAULT_OLLAMA_BASE_URL)
        )
        model = str(cfg.get("model") or DEFAULT_OLLAMA_MODEL)
        dims = int(cfg.get("dims") or DEFAULT_OLLAMA_DIMS)
        key = _embedder_cache_key(
            provider="ollama", model=model, dims=dims,
            base_url=base_url, organization="",
        )
        if key in _EMBEDDER_CACHE:
            return _EMBEDDER_CACHE[key]
        # auto-detect: ping /api/tags; if it answers, Ollama is up.
        if provider == "auto":
            try:
                import httpx
                with httpx.Client(timeout=2.0) as c:
                    r = c.get(f"{base_url.rstrip('/')}/api/tags")
                    if r.status_code != 200:
                        return None
            except Exception:  # noqa: BLE001
                return None
        try:
            inst = OllamaEmbedder(
                base_url=base_url,
                model=model,
                dims=dims,
            )
            _EMBEDDER_CACHE[key] = inst
            return inst
        except Exception:  # noqa: BLE001
            return None
    return None


def clear_embedder_cache() -> None:
    """Drop the cached embedder instances. Call after a config edit
    or when an httpx client has gotten itself into a stuck state."""
    _EMBEDDER_CACHE.clear()


__all__ = [
    "DEFAULT_OLLAMA_BASE_URL",
    "DEFAULT_OLLAMA_DIMS",
    "DEFAULT_OLLAMA_MODEL",
    "DEFAULT_OPENAI_DIMS",
    "DEFAULT_OPENAI_MODEL",
    "OllamaEmbedder",
    "OpenAIEmbedder",
    "resolve_embedder",
]
