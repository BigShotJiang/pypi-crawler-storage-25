"""TUI-side slash-command sugar.

Slash commands are TUI sugar that desugar to the same tool-call
payload the local model would emit on its own. The pure parsing /
desugaring / normalization helpers live in `rtxclaw_core.commands`
so every frontend (TUI, Telegram) shares one source of truth for
command syntax.

This module is the TUI-side seam: it re-exports the small surface
the TUI calls (the parser entry point and the plain-text help card
formatter). TUI-only command sugar — Textual ``Binding`` lists,
footer help text, status-bar rendering helpers that touch widgets —
lands here.
"""
from __future__ import annotations

from rtxclaw_core.commands import format_help, parse_command

__all__ = ["format_help", "parse_command"]
