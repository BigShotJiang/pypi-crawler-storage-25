"""``rtxclaw telegram`` CLI subcommand.

Mirrors the shape of ``rtxclaw agent`` (init / start / stop / restart
/ status / logs / setup). Bridges to the same lifecycle primitives —
pidfile-based daemonization, systemd-friendly start_new_session.

Wired into the top-level ``rtxclaw`` parser by the same module that
wires ``rtxclaw agent`` (``rtxclaw_agent.agent_cli``).
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from rtxclaw_telegram.config import TelegramConfig


def _running(tg_cfg: TelegramConfig) -> tuple[bool, Optional[int]]:
    """Return (running, pid) by reading the pidfile + ``kill -0``."""
    pidfile = tg_cfg.pidfile
    if not pidfile.exists():
        return False, None
    try:
        pid_text = pidfile.read_text(encoding="utf-8").strip()
        pid = int(pid_text)
    except (OSError, ValueError):
        return False, None
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False, pid
    except PermissionError:
        return True, pid
    return True, pid


@contextlib.contextmanager
def _spawn_lock(tg_cfg: TelegramConfig):
    """``flock``-based mutex around a daemon spawn, mirroring the agent
    side. Locks ``<home>/telegram.spawn.lock`` (a sibling, not the
    pidfile itself, to avoid racing with the daemon's own
    pidfile open).
    """
    lock_path = tg_cfg.spawn_lock
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        except OSError:
            pass
        os.close(fd)


def _wait_for_pidfile(tg_cfg: TelegramConfig, timeout: float = 10.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if tg_cfg.pidfile.exists():
            return True
        time.sleep(0.1)
    return False


def cmd_setup(args: argparse.Namespace) -> int:
    """Interactive setup for the standalone Telegram bot.

    Writes ``~/.rtxclaw/telegram/config.json``. Reuses any existing
    values as defaults, including the legacy per-agent fields if a
    fresh ``TelegramConfig`` is empty (one-time migration).
    """
    print("rtxclaw-telegram setup")
    print(f"  config → {TelegramConfig.load().config_path}")
    print()

    tg_cfg = TelegramConfig.load()

    # One-time pickup of legacy per-agent telegram_bot_token /
    # telegram_allowed_chat_ids if the bot's own config is empty.
    if not tg_cfg.bot_token:
        try:
            from rtxclaw_core.agent import AgentConfig as _Acfg
            legacy = _Acfg.load("main")
        except (FileNotFoundError, Exception):  # noqa: BLE001
            legacy = None
        if legacy is not None:
            legacy_token = str(getattr(legacy, "telegram_bot_token", "") or "")
            legacy_ids = list(
                getattr(legacy, "telegram_allowed_chat_ids", []) or []
            )
            if legacy_token and not tg_cfg.bot_token:
                print(
                    f"  (carrying over legacy bot token from "
                    f"{legacy.config_path})"
                )
                tg_cfg.bot_token = legacy_token
            if legacy_ids and not tg_cfg.allowed_chat_ids:
                tg_cfg.allowed_chat_ids = legacy_ids

    def ask(prompt: str, default: str = "") -> str:
        suffix = f" [{default}]" if default else ""
        try:
            ans = input(f"  {prompt}{suffix}: ").strip()
        except EOFError:
            ans = ""
        return ans or default

    masked = (
        tg_cfg.bot_token[:8] + "…" + tg_cfg.bot_token[-4:]
        if tg_cfg.bot_token else ""
    )
    new_token = ask("bot token (from @BotFather)", masked)
    if new_token and new_token != masked:
        tg_cfg.bot_token = new_token
    if not tg_cfg.bot_token:
        print("ERROR: bot_token is required. Re-run when you have one.")
        return 2

    cur_ids = ",".join(str(x) for x in tg_cfg.allowed_chat_ids)
    raw_ids = ask("allowed chat_ids (comma-separated)", cur_ids)
    if raw_ids:
        try:
            tg_cfg.allowed_chat_ids = [
                int(x.strip()) for x in raw_ids.split(",") if x.strip()
            ]
        except ValueError:
            print("ERROR: chat_ids must be integers.")
            return 2

    tg_cfg.default_agent = ask(
        "default agent for new chats", tg_cfg.default_agent or "main",
    )

    tg_cfg.save()
    print(f"  ✓ saved → {tg_cfg.config_path}")
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    """Daemonize ``python -m rtxclaw_telegram.bot``.

    Same pattern as ``rtxclaw agent start``: open the logfile, fork
    via ``Popen(start_new_session=True)``, wait for the pidfile to
    appear (the bot writes it from its main loop), then return.
    """
    tg_cfg = TelegramConfig.load()
    if not tg_cfg.bot_token:
        sys.stderr.write(
            f"no bot_token in {tg_cfg.config_path}. Run "
            "`rtxclaw telegram setup` first.\n",
        )
        return 2

    with _spawn_lock(tg_cfg):
        running, pid = _running(tg_cfg)
        if running:
            print(f"telegram bot already running (pid {pid})")
            return 0

        tg_cfg.logfile.parent.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["PYTHONUNBUFFERED"] = "1"
        with open(tg_cfg.logfile, "a", buffering=1) as log_fh:
            log_fh.write(
                f"\n=== rtxclaw-telegram starting at "
                f"{time.strftime('%Y-%m-%d %H:%M:%S')} ===\n",
            )
            proc = subprocess.Popen(  # noqa: S603
                [sys.executable, "-m", "rtxclaw_telegram.bot"],
                stdin=subprocess.DEVNULL,
                stdout=log_fh,
                stderr=log_fh,
                start_new_session=True,
                env=env,
            )

        # Bot writes its own pidfile from ``run()`` at first
        # iteration; wait for it (or up to 5s) so the next
        # ``status`` / ``stop`` call sees the file.
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if tg_cfg.pidfile.is_file():
                break
            time.sleep(0.1)
        if not tg_cfg.pidfile.is_file():
            sys.stderr.write(
                "telegram bot did not write its pidfile within 5s. "
                f"Check {tg_cfg.logfile} for errors.\n",
            )
            return 1
        print(
            f"telegram bot started (pid {proc.pid}). "
            f"Logs: {tg_cfg.logfile}",
        )
        return 0


def cmd_stop(args: argparse.Namespace) -> int:
    tg_cfg = TelegramConfig.load()
    running, pid = _running(tg_cfg)
    if not running:
        if tg_cfg.pidfile.exists():
            try:
                tg_cfg.pidfile.unlink()
            except OSError:
                pass
        print("telegram bot not running")
        return 0
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    # Bounded wait for clean shutdown; SIGKILL after the grace period.
    deadline = time.time() + 8.0
    while time.time() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            break
        time.sleep(0.2)
    else:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        tg_cfg.pidfile.unlink()
    except FileNotFoundError:
        pass
    print(f"telegram bot stopped (pid {pid})")
    return 0


def cmd_restart(args: argparse.Namespace) -> int:
    rc = cmd_stop(args)
    if rc != 0:
        return rc
    return cmd_start(args)


def cmd_status(args: argparse.Namespace) -> int:
    tg_cfg = TelegramConfig.load()
    running, pid = _running(tg_cfg)
    print(f"telegram bot: {'running' if running else 'stopped'}")
    print(f"  home:        {tg_cfg.home}")
    print(f"  config:      {tg_cfg.config_path}")
    print(f"  default agent: {tg_cfg.default_agent}")
    print(f"  routes:      {len(tg_cfg.agent_routes)} configured")
    print(f"  allowlist:   {len(tg_cfg.allowed_chat_ids)} chat(s)")
    if running:
        print(f"  pid:         {pid}")
        try:
            uptime_s = max(0.0, time.time() - tg_cfg.pidfile.stat().st_mtime)
            print(f"  uptime:      {uptime_s:.0f}s")
        except OSError:
            pass
    return 0 if running else 1


def cmd_logs(args: argparse.Namespace) -> int:
    tg_cfg = TelegramConfig.load()
    if not tg_cfg.logfile.exists():
        print(f"(no log yet at {tg_cfg.logfile})")
        return 0
    return subprocess.call(["tail", "-n", "200", "-f", str(tg_cfg.logfile)])


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Wire ``rtxclaw telegram <cmd>`` into the top-level parser.

    Called from ``rtxclaw_agent.agent_cli`` next to the existing
    ``agent`` and ``memory`` subcommands.
    """
    p = sub.add_parser(
        "telegram",
        help=(
            "Telegram bot lifecycle: setup/start/stop/restart/status/logs"
        ),
    )
    p.set_defaults(_dispatch=lambda a: p.print_help() or 0)
    inner = p.add_subparsers(dest="telegram_cmd")

    p_setup = inner.add_parser("setup", help="Interactive setup wizard")
    p_setup.set_defaults(_dispatch=cmd_setup)

    p_start = inner.add_parser("start", help="Start the bot daemon")
    p_start.set_defaults(_dispatch=cmd_start)

    p_stop = inner.add_parser("stop", help="Stop the bot daemon (SIGTERM)")
    p_stop.set_defaults(_dispatch=cmd_stop)

    p_rest = inner.add_parser("restart", help="Stop + start the bot")
    p_rest.set_defaults(_dispatch=cmd_restart)

    p_stat = inner.add_parser("status", help="pid + uptime + routes")
    p_stat.set_defaults(_dispatch=cmd_status)

    p_logs = inner.add_parser("logs", help="tail -f logs/telegram.log")
    p_logs.set_defaults(_dispatch=cmd_logs)


__all__ = [
    "add_subparser",
    "cmd_setup",
    "cmd_start",
    "cmd_stop",
    "cmd_restart",
    "cmd_status",
    "cmd_logs",
]
