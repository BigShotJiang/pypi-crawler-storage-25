"""
Lightweight STT server using faster-whisper.
OpenAI-compatible /v1/audio/transcriptions endpoint.
Uses ~1-2 GB GPU memory (whisper-small).
"""
import io, os
from fastapi import FastAPI, UploadFile, File, Form
from faster_whisper import WhisperModel

MODEL = os.environ.get("STT_MODEL", "small")
DEVICE = os.environ.get("STT_DEVICE", "cuda")
COMPUTE = os.environ.get("STT_COMPUTE", "float16")
PORT = int(os.environ.get("PORT", "8002"))

print(f"[stt] loading faster-whisper {MODEL} on {DEVICE}", flush=True)
# download_root: honor STT_DOWNLOAD_ROOT, else faster-whisper's default
# HF cache (~/.cache/huggingface). Never hardcode an absolute home path.
model = WhisperModel(MODEL, device=DEVICE, compute_type=COMPUTE,
                     download_root=os.environ.get("STT_DOWNLOAD_ROOT") or None)
print("[stt] model loaded", flush=True)

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "ok", "model": f"faster-whisper/{MODEL}"}

@app.get("/v1/models")
def models():
    return {"object": "list", "data": [{"id": f"faster-whisper/{MODEL}", "object": "model"}]}

@app.post("/v1/audio/transcriptions")
async def transcribe(file: UploadFile = File(...), language: str = Form("auto")):
    audio_bytes = await file.read()
    lang = None if language == "auto" else language
    segments, info = model.transcribe(io.BytesIO(audio_bytes), language=lang, beam_size=5)
    text = " ".join(seg.text for seg in segments)
    detected_lang = info.language if info else language
    return {"text": text, "language": detected_lang}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info", workers=1)
