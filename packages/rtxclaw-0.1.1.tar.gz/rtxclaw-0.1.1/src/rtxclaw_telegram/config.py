"""Telegram-gateway on-disk config.

Independent of any single agent. The bot is now its own service with
its own home directory, mirroring how each agent has one. Layout:

    ~/.rtxclaw/telegram/
        config.json       — bot_token, allowed_chat_ids, default_agent
        sessions.json     — chat→{agent,session_id} bindings (Phase B)
        offset.json       — getUpdates ack cursor
        logs/
            telegram.log
        telegram.pid      — written while the service is running
        telegram.spawn.lock

Resolution honors ``$RTXCLAW_HOME`` (workspace root) so the test
sandbox at ``~/.rtxclaw-test/telegram/`` works without per-test
patching. ``$RTXCLAW_TELEGRAM_HOME`` overrides that for one-off runs.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


def telegram_home() -> Path:
    """Top of the Telegram-gateway tree.

    Resolution order:
      1. ``$RTXCLAW_TELEGRAM_HOME`` — exact directory.
      2. ``$RTXCLAW_HOME`` (workspace root) → ``<root>/telegram``.
      3. ``~/.rtxclaw/telegram``.
    """
    direct = os.environ.get("RTXCLAW_TELEGRAM_HOME")
    if direct:
        return Path(direct).expanduser()
    root = os.environ.get("RTXCLAW_HOME")
    if root:
        return Path(root).expanduser() / "telegram"
    return Path.home() / ".rtxclaw" / "telegram"


def _config_path() -> Path:
    return telegram_home() / "config.json"


@dataclass
class TelegramConfig:
    """Bot-wide configuration. Lives in
    ``<telegram_home>/config.json``; per-(chat,agent) state lives in
    sibling files (``sessions.json`` / ``offset.json``) so a config
    edit doesn't risk corrupting in-flight runtime state.
    """

    bot_token: str = ""
    # Bot-wide allowlist. An empty list denies every chat (refuses to
    # boot loud rather than open to the internet).
    allowed_chat_ids: list[int] = field(default_factory=list)
    # Trusted-chats get fs.readTextFile; everyone else stays text-only.
    # Mirrors the agent-side env var, hoisted into config so a single
    # bot deployment doesn't need a per-process env var.
    trusted_chat_ids: list[int] = field(default_factory=list)
    # User-id allowlist. When non-empty, the bot only replies to
    # messages whose ``message.from.id`` is in this set, even if the
    # surrounding chat is in ``allowed_chat_ids``. Useful for shared
    # groups where the bot should ignore everyone except the operator.
    # Empty (default) ⇒ disabled — every member of an allowed chat
    # can address the bot, matching the legacy behavior.
    allowed_user_ids: list[int] = field(default_factory=list)
    # Group-mention gate. When True, in non-private chats (groups,
    # supergroups, channels) the bot only replies to messages that
    # explicitly ``@<botname>`` it (slash commands' implicit
    # ``/cmd@<botname>`` suffix counts) or that are direct replies
    # to one of the bot's own messages. DMs (chat.type == "private")
    # are unaffected — there's no other recipient there to confuse,
    # so requiring a mention would just be noise. Default False to
    # preserve drop-in upgrade behavior.
    mention_required_in_groups: bool = False
    # Which agent gets a brand-new chat's first message. ``main`` is
    # the canonical default.
    default_agent: str = "main"
    # Static (chat_id|chat_id:thread_id) → agent_name map. Overrides
    # ``default_agent`` for chats / forum topics that should be pinned
    # to a specific agent (e.g. one Telegram group per agent, or one
    # forum topic per agent). Empty in fresh installs; the wizard
    # writes entries when the operator sets up a multi-agent layout.
    # The dynamic ``/agent <name>`` command (Phase B) writes here too,
    # so a chat's last selection survives bot restarts.
    agent_routes: dict[str, str] = field(default_factory=dict)

    @classmethod
    def load(cls) -> "TelegramConfig":
        """Read the on-disk config. Missing file → defaults (empty
        token, no allowlist, agent=main). Callers are expected to
        check ``bot_token`` before booting the long-poll loop.
        """
        p = _config_path()
        if not p.is_file():
            return cls()
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return cls()
        if not isinstance(data, dict):
            return cls()
        token = str(data.get("bot_token") or "")
        allowed: list[int] = []
        for x in data.get("allowed_chat_ids") or []:
            try:
                allowed.append(int(x))
            except (TypeError, ValueError):
                continue
        trusted: list[int] = []
        for x in data.get("trusted_chat_ids") or []:
            try:
                trusted.append(int(x))
            except (TypeError, ValueError):
                continue
        allowed_users: list[int] = []
        for x in data.get("allowed_user_ids") or []:
            try:
                allowed_users.append(int(x))
            except (TypeError, ValueError):
                continue
        mention_required = bool(data.get("mention_required_in_groups") or False)
        default_agent = str(data.get("default_agent") or "main") or "main"
        routes_raw = data.get("agent_routes") or {}
        routes: dict[str, str] = {}
        if isinstance(routes_raw, dict):
            for k, v in routes_raw.items():
                if not isinstance(k, str) or not isinstance(v, str):
                    continue
                if not k.strip() or not v.strip():
                    continue
                routes[k.strip()] = v.strip()
        return cls(
            bot_token=token,
            allowed_chat_ids=allowed,
            trusted_chat_ids=trusted,
            allowed_user_ids=allowed_users,
            mention_required_in_groups=mention_required,
            default_agent=default_agent,
            agent_routes=routes,
        )

    # ---- routing -------------------------------------------------------

    @staticmethod
    def chat_key(chat_id: int, thread_id: Optional[int] = None) -> str:
        """Compose the persistence key for a (chat, topic) pair.

        Forum topics are keyed ``"<chat_id>:<thread_id>"``; non-forum
        chats and the General topic (no ``message_thread_id``) keep
        the bare chat-id key, matching the Telegram bot's existing
        on-disk session-map convention.
        """
        if thread_id is None:
            return str(chat_id)
        return f"{chat_id}:{thread_id}"

    def agent_for(
        self, chat_id: int, thread_id: Optional[int] = None,
    ) -> str:
        """Resolve which agent name handles ``(chat_id, thread_id)``.

        Order: exact ``chat_id:thread_id`` match → bare ``chat_id``
        match → ``default_agent``. Returns a name only — the caller
        loads the matching :class:`AgentConfig`.
        """
        if thread_id is not None:
            specific = f"{chat_id}:{thread_id}"
            if specific in self.agent_routes:
                return self.agent_routes[specific]
        bare = str(chat_id)
        if bare in self.agent_routes:
            return self.agent_routes[bare]
        return self.default_agent or "main"

    def save(self) -> None:
        """Write the config atomically. Caller is responsible for
        choosing when to save (the wizard does, the runtime doesn't —
        a bot restart re-reads it fresh).
        """
        p = _config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(f".{p.name}.tmp")
        tmp.write_text(
            json.dumps(asdict(self), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        os.replace(tmp, p)

    # ---- on-disk paths -------------------------------------------------

    @property
    def home(self) -> Path:
        return telegram_home()

    @property
    def config_path(self) -> Path:
        return _config_path()

    @property
    def logs_dir(self) -> Path:
        return telegram_home() / "logs"

    @property
    def logfile(self) -> Path:
        return telegram_home() / "logs" / "telegram.log"

    @property
    def pidfile(self) -> Path:
        return telegram_home() / "telegram.pid"

    @property
    def spawn_lock(self) -> Path:
        return telegram_home() / "telegram.spawn.lock"

    @property
    def sessions_path(self) -> Path:
        """Per-chat session bindings. Phase A stores
        ``{chat_key: session_id}`` (one agent per bot); Phase B will
        change the value shape to ``{agent_name: session_id}`` so a
        chat can talk to multiple agents.
        """
        return telegram_home() / "sessions.json"

    @property
    def offset_path(self) -> Path:
        return telegram_home() / "offset.json"

    @property
    def visibility_path(self) -> Path:
        """Per-(chat, thread) display-visibility map (`/tools` and
        `/reasoning` levels). Persisted so a bot restart doesn't reset
        every chat to the off/off default — the operator's prior
        ``/tools on`` should outlive a redeploy."""
        return telegram_home() / "visibility.json"


__all__ = [
    "TelegramConfig",
    "telegram_home",
]
