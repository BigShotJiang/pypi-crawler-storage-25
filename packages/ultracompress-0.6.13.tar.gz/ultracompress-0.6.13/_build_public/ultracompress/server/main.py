"""UltraCompress inference server — FastAPI app.

OpenAI-compatible `/v1/completions` (non-streaming + SSE), `/v1/models`,
`/healthz`, and a Prometheus `/metrics` endpoint. Loads a compressed model at
startup from the env var `UC_MODEL_PATH`; refuses to start if it is unset or
invalid (no silent fallback). See `docs/INFERENCE_SERVER_ARCH.md` §6 for the
full design; this skeleton implements the OpenAI shim subset only.

Streaming caveat: the underlying generation pipeline is `model.generate(...)`
which returns the full string before we can chunk it. SSE here splits the
finished output into word-sized data frames; it is *not* true token-by-token
streaming. A warning is logged at startup. The dispatcher (§1) is the path to
real per-token streaming; this is an OpenAI-compatible surface so customers
can drop-in replace the OpenAI client today.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import PlainTextResponse, StreamingResponse
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)
from pydantic import BaseModel, Field

logger = logging.getLogger("ultracompress.server")

# ---------------------------------------------------------------------------
# Prometheus metrics. Module-level so they survive reload-restart and can be
# imported by tests directly.
# ---------------------------------------------------------------------------
DECODE_LATENCY_MS = Histogram(
    "uc_decode_latency_ms",
    "End-to-end decode latency per request in milliseconds.",
    buckets=(10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000),
)
TOKENS_PER_SECOND = Gauge(
    "uc_tokens_per_second",
    "Most recent decode throughput in output tokens per second.",
)
ACTIVE_REQUESTS = Gauge(
    "uc_active_requests",
    "Number of in-flight completion requests.",
)
BANK_FETCH_LATENCY_MS = Histogram(
    "uc_bank_fetch_latency_ms",
    "Streaming-bank fetch latency in milliseconds (streaming models only).",
    buckets=(0.1, 0.5, 1, 5, 10, 50, 100, 500, 1000),
)
COMPRESSION_BPW = Gauge(
    "uc_compression_bpw",
    "Effective bits-per-weight of the loaded compressed model.",
)
TOTAL_REQUESTS = Counter(
    "uc_total_requests",
    "Total completion requests received, by status.",
    ["status"],
)


# ---------------------------------------------------------------------------
# OpenAI-compatible request/response schemas (Pydantic V2).
# ---------------------------------------------------------------------------
class CompletionRequest(BaseModel):
    model: str
    prompt: str | list[str]
    max_tokens: int = Field(default=64, ge=1, le=4096)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    stream: bool = False
    n: int = Field(default=1, ge=1, le=1)  # n>1 not supported
    stop: str | list[str] | None = None


# ---------------------------------------------------------------------------
# Model loading. Validates UC_MODEL_PATH; refuses to start if unset/invalid.
# ---------------------------------------------------------------------------
def _validate_model_path(raw: str | None) -> Path:
    """Resolve and validate UC_MODEL_PATH. Raises RuntimeError on any failure."""
    if not raw:
        raise RuntimeError(
            "UC_MODEL_PATH is unset. Set it to the absolute path of a "
            "compressed .uc artifact before starting the server."
        )
    p = Path(raw).expanduser().resolve(strict=False)
    if not p.exists():
        raise RuntimeError(f"UC_MODEL_PATH does not exist: {p}")
    if not p.is_file():
        raise RuntimeError(f"UC_MODEL_PATH is not a regular file: {p}")
    if p.suffix != ".uc":
        raise RuntimeError(
            f"UC_MODEL_PATH must end in .uc; got suffix {p.suffix!r} "
            f"(.ucz support retired in v0.6.9)"
        )
    if not os.access(p, os.R_OK):
        raise RuntimeError(f"UC_MODEL_PATH not readable: {p}")
    return p


def _load_uc_artifact(path: Path) -> dict[str, Any]:
    """Load a compressed model artifact. Returns dict with model+tokenizer+meta.

    Handles the `.uc` format (torch.save dict from `api.save()`). The legacy
    `.ucz` archive format was retired in v0.6.9 along with its deprecated
    loader; `.ucz` paths now error cleanly rather than dispatching into
    removed code.
    """
    import torch  # local import: avoid torch cost on `--help`
    sidecar = path.with_suffix(path.suffix + ".json")
    bpw = float("nan")
    model_id = f"uc-{path.stem}"
    if sidecar.exists():
        try:
            meta = json.loads(sidecar.read_text())
            bpw = float(meta.get("report", {}).get("bits_per_weight", bpw))
        except Exception as e:  # pragma: no cover
            logger.warning("sidecar parse failed: %s", e)

    if path.suffix == ".ucz":
        raise RuntimeError(
            f"legacy .ucz archive format is no longer supported (retired in v0.6.9). "
            f"Repack as a .uc artifact via the v3 trainer + api.save()."
        )

    # New `.uc` format: state_dict + metadata. Skeleton path: hold the raw
    # payload; real generation requires re-instantiating the HF backbone, which
    # the dispatcher will own. For now we expose the metadata over the API.
    # SECURITY (v0.6.9): weights_only=True forbids arbitrary code execution
    # at deserialization time. The .uc payload is fully covered by the safe
    # loader allowlist — a tampered file raises UnpicklingError here.
    payload = torch.load(path, map_location="cpu", weights_only=True)
    meta = payload.get("metadata", {}) if isinstance(payload, dict) else {}
    report = meta.get("report", {})
    if "bits_per_weight" in report:
        bpw = float(report["bits_per_weight"])
    return {
        "model": None,  # dispatcher not wired; see arch doc §1
        "tokenizer": None,
        "bpw": bpw,
        "model_id": model_id,
        "format": "uc",
        "metadata": meta,
    }


# ---------------------------------------------------------------------------
# App factory + lifespan.
# ---------------------------------------------------------------------------
@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    path = _validate_model_path(os.environ.get("UC_MODEL_PATH"))
    logger.info("loading compressed model from %s", path)
    bundle = _load_uc_artifact(path)
    if bundle["bpw"] == bundle["bpw"]:
        COMPRESSION_BPW.set(bundle["bpw"])
    app.state.uc = bundle
    logger.warning("SSE streaming chunks completed strings post-hoc; not "
                   "true per-token streaming. Dispatcher (arch §1) delivers real SSE.")
    if bundle["model"] is None:
        logger.warning("model is None for .uc artifacts in skeleton mode; "
                       "/v1/completions will return 503 until dispatcher lands.")
    try:
        yield
    finally:
        app.state.uc = None


def build_app() -> FastAPI:
    app = FastAPI(title="UltraCompress Inference", version="0.1.0",
                  lifespan=_lifespan)

    @app.get("/healthz")
    async def healthz() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/metrics")
    async def metrics() -> PlainTextResponse:
        return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    @app.get("/v1/models")
    async def list_models(request: Request) -> dict[str, Any]:
        b = getattr(request.app.state, "uc", None)
        if b is None:
            raise HTTPException(503, "model not loaded")
        return {
            "object": "list",
            "data": [{
                "id": b["model_id"],
                "object": "model",
                "created": int(time.time()),
                "owned_by": "sipsa-labs",
                "compression": {
                    "bits_per_weight": b["bpw"],
                    "format": b["format"],
                },
            }],
        }

    @app.post("/v1/completions")
    async def completions(req: CompletionRequest, request: Request):
        b = getattr(request.app.state, "uc", None)
        if b is None:
            TOTAL_REQUESTS.labels(status="error").inc()
            raise HTTPException(503, "model not loaded")
        if req.model != b["model_id"]:
            TOTAL_REQUESTS.labels(status="error").inc()
            raise HTTPException(404, f"unknown model {req.model!r}")
        if b["model"] is None:
            TOTAL_REQUESTS.labels(status="error").inc()
            raise HTTPException(
                503,
                "dispatcher not wired for .uc artifacts in skeleton mode; "
                "load a .ucz archive artifact or wait for dispatcher rollout",
            )

        prompt = req.prompt if isinstance(req.prompt, str) else req.prompt[0]
        ACTIVE_REQUESTS.inc()
        t0 = time.perf_counter()
        try:
            text = b["model"].generate(
                prompt, max_tokens=req.max_tokens, temperature=req.temperature,
            )
        except Exception as e:
            TOTAL_REQUESTS.labels(status="error").inc()
            ACTIVE_REQUESTS.dec()
            raise HTTPException(500, f"generation failed: {e}") from e
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        DECODE_LATENCY_MS.observe(elapsed_ms)
        completion = text[len(prompt):] if text.startswith(prompt) else text
        n_tok = max(1, len(completion.split()))
        TOKENS_PER_SECOND.set(n_tok / max(elapsed_ms / 1000.0, 1e-6))
        ACTIVE_REQUESTS.dec()
        TOTAL_REQUESTS.labels(status="ok").inc()

        cid = f"cmpl-{uuid.uuid4().hex[:12]}"
        created = int(time.time())

        if not req.stream:
            n_prompt = len(prompt.split())
            return {
                "id": cid, "object": "text_completion", "created": created,
                "model": req.model,
                "choices": [{"text": completion, "index": 0,
                             "finish_reason": "stop", "logprobs": None}],
                "usage": {"prompt_tokens": n_prompt,
                          "completion_tokens": n_tok,
                          "total_tokens": n_prompt + n_tok},
            }

        async def sse() -> AsyncIterator[bytes]:
            for word in completion.split(" "):
                chunk = {
                    "id": cid, "object": "text_completion", "created": created,
                    "model": req.model,
                    "choices": [{"text": word + " ", "index": 0,
                                 "finish_reason": None, "logprobs": None}],
                }
                yield f"data: {json.dumps(chunk)}\n\n".encode("utf-8")
            done = {
                "id": cid, "object": "text_completion", "created": created,
                "model": req.model,
                "choices": [{"text": "", "index": 0, "finish_reason": "stop",
                             "logprobs": None}],
            }
            yield f"data: {json.dumps(done)}\n\n".encode("utf-8")
            yield b"data: [DONE]\n\n"

        return StreamingResponse(sse(), media_type="text/event-stream")

    return app


# uvicorn entrypoint: `uvicorn ultracompress.server.main:app`
app = build_app()
