"""Entrypoint shim so `python -m ultracompress …` works as a fallback when the
`uc` console script is not on PATH (Jupyter notebooks, minimal Docker images,
locked-down CI environments).

The fully-supported entry points are still `uc <subcommand>` and
`ultracompress <subcommand>`. This module exists so that `python -m ultracompress`
delegates to the same CLI dispatcher.
"""
from __future__ import annotations

# Must run BEFORE any import that transitively pulls torch, because
# torch.cuda.__init__ imports the deprecated pynvml shim at import time
# and emits a FutureWarning before our code gets a chance to filter it.
# ultracompress/__init__.py → api_v3 → import torch happens as soon as
# the package is loaded, so the filter must be installed here first.
import warnings as _warnings
_warnings.filterwarnings(
    "ignore",
    message=r".*pynvml package is deprecated.*",
    category=FutureWarning,
)

from ultracompress.cli import main


if __name__ == "__main__":
    main()
