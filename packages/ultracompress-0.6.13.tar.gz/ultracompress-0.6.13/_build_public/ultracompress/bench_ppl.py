"""ultracompress.bench_ppl - independent PPL verification for v3 packed models.

Customer-facing subcommand `uc bench-ppl` that lets a third party (auditor,
prospect, regulator) reproduce the published PPL ratio claim end-to-end on
their own hardware, with no trust placed in Sipsa-published JSONs.

Pipeline:
  1. Reconstruct the bf16 baseline by loading the original HF model id
     specified via `--against-bf16` (or resolved from the pack's manifest).
  2. Reconstruct the compressed model by calling the existing
     `ultracompress.bench._load_packed_model` reconstruction path - the
     same black-box codec used in `uc bench`. We do NOT touch codec
     internals here.
  3. Pull a deterministic held-out tail slice from FineWeb-edu via
     `datasets.load_dataset(..., streaming=True)`. The tail offset is
     fixed (default 10M rows) so the same `--seed` always yields the
     same prompts.
  4. Tokenize + truncate each prompt to `--seq-len` tokens.
  5. For each model, compute mean cross-entropy of shifted-target next-token
     prediction across all prompts, then PPL = exp(mean cross-entropy).
  6. Compute ratio = compressed_ppl / bf16_ppl. Optionally compare to
     `--published-ratio` and report drift in % terms.

Memory discipline:
  Models are loaded one at a time. The bf16 baseline gets loaded, scored,
  and torn down (del + cuda.empty_cache) before the compressed pack is loaded.
  This is critical for 8B+ models on a single 32 GB GPU.

Public API:
    from ultracompress.bench_ppl import bench_ppl
    result = bench_ppl(pack_dir="./pack", against_bf16="Qwen/Qwen3-8B", n_prompts=50)

CLI entry point:
    uc bench-ppl <pack-dir> --against-bf16 [HF_ID] [--n-prompts N] [--seq-len N]
                            [--seed N] [--dataset-name STR] [--dataset-config STR]
                            [--tail-offset N] [--published-ratio FLOAT]
                            [--tolerance-pct FLOAT] [--device cuda:0] [--output PATH]
"""
from __future__ import annotations

import argparse
import datetime
import gc
import json
import math
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

# Default tolerance for the PASS/FAIL verdict, in percent.
DEFAULT_TOLERANCE_PCT: float = 0.5

# Default offset (rows) into the FineWeb-edu stream, used to land in the
# held-out tail past anything a small calibration set could plausibly touch.
# Deterministic - same seed + same offset = same prompts.
DEFAULT_TAIL_OFFSET: int = 10_000_000

# Default streaming dataset for held-out PPL.
DEFAULT_DATASET_NAME: str = "HuggingFaceFW/fineweb-edu"
DEFAULT_DATASET_CONFIG: str = "sample-10BT"


@dataclass
class BenchPplResult:
    """Structured PPL-verification report. Serialized to JSON for distribution."""

    tool_version: str
    pack_dir: str
    pack_name: str
    bf16_baseline: str
    dataset: dict[str, Any]
    hardware: dict[str, Any]
    results: dict[str, Any]
    verdict: str
    tolerance_pct: float
    ts: str
    warnings: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _free_memory() -> None:
    """Aggressive cleanup between baseline and compressed runs."""
    import torch

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _human_elapsed(seconds: float) -> str:
    """Pretty-print an elapsed-time duration (e.g. '6m38s')."""
    s = int(round(seconds))
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m{s:02d}s"


def _detect_hardware(device: str) -> dict[str, Any]:
    """Best-effort GPU + torch info for the report."""
    import torch

    info: dict[str, Any] = {
        "device": device,
        "torch_version": torch.__version__,
    }
    if device.startswith("cuda") and torch.cuda.is_available():
        idx = torch.device(device).index or 0
        info["gpu"] = torch.cuda.get_device_name(idx)
        info["vram_gb"] = round(
            torch.cuda.get_device_properties(idx).total_memory / 1024**3, 1
        )
    else:
        info["gpu"] = "cpu"
        info["vram_gb"] = 0.0
    return info


def _resolve_baseline_id(pack_dir: Path, override: str | None) -> str:
    """Resolve the bf16 baseline HF id - explicit override wins, else pack metadata."""
    if override:
        return override
    # Reuse the existing resolver from bench.py - same priority chain.
    from ultracompress.bench import _resolve_base_model_id
    return _resolve_base_model_id(pack_dir)


def _load_held_out_prompts(
    dataset_name: str,
    dataset_config: str | None,
    tail_offset: int,
    n_prompts: int,
    seed: int,
    text_field: str = "text",
) -> list[str]:
    """Pull `n_prompts` rows from a streaming dataset's held-out tail.

    Determinism: with a fixed `tail_offset` and `seed`, the same dataset
    yields the same prompts on every machine. The seed shuffles the
    post-offset window with `datasets.IterableDataset.shuffle(buffer_size=...)`
    so we don't latch onto a pathological run of similar documents.
    """
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise ImportError(
            "uc bench-ppl requires the `datasets` package. "
            "Install via: pip install ultracompress[eval] (or `pip install datasets`)"
        ) from exc

    if dataset_config:
        ds = load_dataset(dataset_name, dataset_config, split="train", streaming=True)
    else:
        ds = load_dataset(dataset_name, split="train", streaming=True)

    # Skip into the tail, then shuffle a small window for variety.
    ds = ds.skip(tail_offset)
    # Buffer sized so we can pull `n_prompts` cleanly; cap at 1024 so we
    # don't burn excess memory streaming on small machines.
    shuffle_buf = max(64, min(1024, n_prompts * 8))
    ds = ds.shuffle(seed=seed, buffer_size=shuffle_buf)

    out: list[str] = []
    iterator = iter(ds)
    seen = 0
    while len(out) < n_prompts:
        try:
            row = next(iterator)
        except StopIteration:
            break
        text = row.get(text_field) if isinstance(row, dict) else None
        if not isinstance(text, str) or not text.strip():
            seen += 1
            if seen > n_prompts * 50:
                # Defensive: bail rather than spin if the dataset is empty.
                break
            continue
        out.append(text)
    if len(out) < n_prompts:
        raise RuntimeError(
            f"Held-out dataset yielded only {len(out)}/{n_prompts} non-empty rows "
            f"after offset={tail_offset}. Lower --tail-offset or pick another dataset."
        )
    return out


def _compute_ppl(
    model: Any,
    tokenizer: Any,
    prompts: list[str],
    seq_len: int,
    device: str,
) -> tuple[float, int]:
    """Compute PPL on `prompts` against `model`.

    Method: for each prompt, tokenize+truncate to `seq_len`, compute logits
    over the full sequence, take cross-entropy of the shifted next-token
    targets (positions [1:] vs logits[:-1]). Sum NLL and token count across
    all prompts; PPL = exp(total_nll / total_tokens).

    This is the standard sliding-window-free PPL definition and matches
    HuggingFace `evaluate.load("perplexity")` for the seq_len <= context
    case. We deliberately do NOT use Hugging Face's PPL helper because we
    want zero hidden assumptions about stride / window in the published
    number.

    Returns: (ppl, total_token_count).
    """
    import torch
    import torch.nn.functional as F

    total_nll = 0.0
    total_tokens = 0
    torch_device = torch.device(device)

    # Prefer tokenizer's reported model_max_length if it's tight; clamp seq_len.
    eff_seq_len = max(8, int(seq_len))
    model_max = getattr(tokenizer, "model_max_length", None)
    if isinstance(model_max, int) and 0 < model_max < eff_seq_len:
        eff_seq_len = model_max

    # `_load_bf16_baseline` and `_load_packed_model` both call `.train(False)`
    # at construction, so the model is already in inference mode. We rely on
    # `torch.no_grad()` to skip grad tracking.
    with torch.no_grad():
        for prompt in prompts:
            enc = tokenizer(
                prompt,
                return_tensors="pt",
                truncation=True,
                max_length=eff_seq_len,
                add_special_tokens=True,
            )
            input_ids = enc["input_ids"].to(torch_device)
            if input_ids.shape[1] < 2:
                # Need >=2 tokens to compute even one CE term.
                continue

            # Forward pass - we're memory-bound on big models, so cast logits
            # to fp32 only for the loss reduction (not the full forward).
            logits = model(input_ids=input_ids).logits  # [1, T, V]
            shift_logits = logits[:, :-1, :].float()    # [1, T-1, V]
            shift_labels = input_ids[:, 1:]             # [1, T-1]

            # Per-token NLL, summed across all positions.
            nll = F.cross_entropy(
                shift_logits.reshape(-1, shift_logits.size(-1)),
                shift_labels.reshape(-1),
                reduction="sum",
            ).item()
            n_tokens = int(shift_labels.numel())

            total_nll += nll
            total_tokens += n_tokens

            # Drop intermediate tensors before next iteration.
            del logits, shift_logits, shift_labels, input_ids

    if total_tokens == 0:
        raise RuntimeError("All prompts produced 0 valid CE terms - check seq_len and tokenizer.")

    mean_nll = total_nll / total_tokens
    return math.exp(mean_nll), total_tokens


def _load_bf16_baseline(hf_id: str, device: str):
    """Load the bf16 baseline from HF via the standard transformers path."""
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(hf_id, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        hf_id,
        torch_dtype=torch.bfloat16,
        device_map=torch.device(device),
        trust_remote_code=True,
    ).train(False)
    return model, tokenizer


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

def bench_ppl(
    pack_dir: str | Path,
    *,
    against_bf16: str | None = None,
    n_prompts: int = 50,
    seq_len: int = 1024,
    seed: int = 42,
    dataset_name: str = DEFAULT_DATASET_NAME,
    dataset_config: str | None = DEFAULT_DATASET_CONFIG,
    tail_offset: int = DEFAULT_TAIL_OFFSET,
    published_ratio: float | None = None,
    tolerance_pct: float = DEFAULT_TOLERANCE_PCT,
    device: str = "cuda:0",
    output: str | Path | None = None,
) -> BenchPplResult:
    """Independently verify the PPL ratio of an UltraCompress pack vs its bf16 baseline.

    Args:
        pack_dir: Path to a UC v3 packed directory (`layer_*.uc` + `manifest.json`).
        against_bf16: Override for the bf16 HF id. If None, resolved from the
            pack's manifest.json or README frontmatter.
        n_prompts: Number of held-out prompts to score (default 50).
        seq_len: Tokens per prompt after truncation (default 1024).
        seed: Determinism seed for held-out shuffle (default 42).
        dataset_name: HF dataset id for the held-out corpus (default FineWeb-edu).
        dataset_config: HF dataset config (default `sample-10BT`).
        tail_offset: Rows to skip into the dataset stream before sampling.
            Default 10M lands deep in the held-out tail.
        published_ratio: Optional published PPL ratio to compare against.
            If set, drift is reported in %.
        tolerance_pct: PASS/FAIL threshold for drift in % (default 0.5).
        device: Torch device string (default `cuda:0`).
        output: Output JSON path. Default: `bench_ppl_<timestamp>.json` in CWD.

    Returns:
        BenchPplResult with measured PPLs, ratio, drift, and verdict.

    Notes:
        Models are loaded one at a time to fit on a single 32 GB GPU.
        The compressed pack is reconstructed via the existing
        `ultracompress.bench._load_packed_model` codec - this module never
        touches codec internals.
    """
    pack_dir = Path(pack_dir).expanduser().resolve()
    if not pack_dir.is_dir():
        raise FileNotFoundError(f"Pack dir does not exist: {pack_dir}")

    baseline_id = _resolve_baseline_id(pack_dir, against_bf16)
    timestamp = datetime.datetime.now().isoformat(timespec="seconds")

    if output is None:
        ts_compact = timestamp.replace(":", "").replace("-", "")
        output = Path(f"./bench_ppl_{ts_compact}.json")
    output = Path(output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    # Read tool version from package metadata (fallback if not installed).
    try:
        import ultracompress
        tool_version = getattr(ultracompress, "__version__", "unknown")
    except ImportError:
        tool_version = "unknown"

    hardware = _detect_hardware(device)
    warnings_list: list[str] = []

    # Banner
    print("UltraCompress bench-ppl")
    print("=" * 64)
    print(f"Pack:           {pack_dir}  ({pack_dir.name})")
    print(f"Bf16 baseline:  {baseline_id}")
    print(f"Dataset:        {dataset_name}"
          + (f" / {dataset_config}" if dataset_config else "")
          + f" (held-out tail offset={tail_offset:,}, n={n_prompts}, seq_len={seq_len}, seed={seed})")
    print(f"Hardware:       {hardware['gpu']}"
          + (f" ({hardware['vram_gb']} GB)" if hardware['vram_gb'] else ""))
    print()

    # ----- Pull held-out prompts ----- #
    print(f"Pulling {n_prompts} held-out prompts from {dataset_name}...", flush=True)
    prompts = _load_held_out_prompts(
        dataset_name=dataset_name,
        dataset_config=dataset_config,
        tail_offset=tail_offset,
        n_prompts=n_prompts,
        seed=seed,
    )
    print(f"  got {len(prompts)} prompts.")
    print()

    # ----- Baseline (bf16) ----- #
    print("Computing baseline PPL on bf16...", flush=True)
    t0 = time.perf_counter()
    bf16_model, bf16_tokenizer = _load_bf16_baseline(baseline_id, device)
    bf16_ppl, bf16_tokens = _compute_ppl(
        bf16_model, bf16_tokenizer, prompts, seq_len, device
    )
    bf16_elapsed = time.perf_counter() - t0
    print(f"  bf16 PPL:        {bf16_ppl:.4f}  [tokens={bf16_tokens:,}, "
          f"elapsed: {_human_elapsed(bf16_elapsed)}]")
    del bf16_model, bf16_tokenizer
    _free_memory()
    print()

    # ----- Compressed pack ----- #
    print("Computing compressed PPL on uc pack...", flush=True)
    t0 = time.perf_counter()
    # Black-box: reuse the existing pack-loading path. We do NOT touch the
    # codec - we just call the same reconstruction API used by `uc bench`.
    from ultracompress.bench import _load_packed_model
    uc_model, uc_tokenizer = _load_packed_model(pack_dir, baseline_id, device)
    uc_ppl, uc_tokens = _compute_ppl(
        uc_model, uc_tokenizer, prompts, seq_len, device
    )
    uc_elapsed = time.perf_counter() - t0
    print(f"  compressed PPL:  {uc_ppl:.4f}  [tokens={uc_tokens:,}, "
          f"elapsed: {_human_elapsed(uc_elapsed)}]")
    del uc_model, uc_tokenizer
    _free_memory()
    print()

    if uc_tokens != bf16_tokens:
        # Token-count drift between models is a yellow flag (different
        # tokenizer behaviour or truncation), but the ratio is still
        # meaningful as long as both used the same prompts. We log it.
        warnings_list.append(
            f"token-count drift: bf16={bf16_tokens} vs uc={uc_tokens} "
            f"(can happen if tokenizers differ across HF revisions)"
        )

    # ----- Ratio + drift ----- #
    ratio = uc_ppl / bf16_ppl
    drift_pct: float | None = None
    if published_ratio is not None and published_ratio > 0:
        drift_pct = 100.0 * (ratio - published_ratio) / published_ratio

    print("Result:")
    print(f"  PPL ratio:           {ratio:.5f}")
    if published_ratio is not None:
        print(f"  Published ratio:     {published_ratio:.5f}")
        print(f"  Drift:               {drift_pct:+.2f}%  "
              f"({'within tolerance' if abs(drift_pct) <= tolerance_pct else 'OUT OF TOLERANCE'})")

    if published_ratio is None:
        verdict = "MEASURED"  # No claim to verify against, just measured.
        verdict_line = (f"VERIFY: MEASURED - PPL ratio = {ratio:.5f} "
                        f"(no --published-ratio supplied; nothing to verify against)")
    else:
        passed = drift_pct is not None and abs(drift_pct) <= tolerance_pct
        verdict = "PASS" if passed else "FAIL"
        if passed:
            verdict_line = (f"VERIFY: PASS - measured PPL ratio matches published claim "
                            f"within {tolerance_pct}% tolerance.")
        else:
            verdict_line = (f"VERIFY: FAIL - measured PPL ratio drifts {drift_pct:+.2f}% "
                            f"from published claim (tolerance {tolerance_pct}%).")
    print()
    print(verdict_line)

    # ----- Build report + write JSON ----- #
    result = BenchPplResult(
        tool_version=tool_version,
        pack_dir=str(pack_dir),
        pack_name=pack_dir.name,
        bf16_baseline=baseline_id,
        dataset={
            "name": dataset_name,
            "config": dataset_config,
            "n_prompts": n_prompts,
            "seq_len": seq_len,
            "seed": seed,
            "tail_offset_rows": tail_offset,
        },
        hardware=hardware,
        results={
            "bf16_ppl": round(bf16_ppl, 4),
            "compressed_ppl": round(uc_ppl, 4),
            "ratio": round(ratio, 5),
            "published_ratio": (round(published_ratio, 5)
                                 if published_ratio is not None else None),
            "drift_pct": (round(drift_pct, 4) if drift_pct is not None else None),
            "bf16_tokens_evaluated": bf16_tokens,
            "compressed_tokens_evaluated": uc_tokens,
            "bf16_elapsed_s": round(bf16_elapsed, 2),
            "compressed_elapsed_s": round(uc_elapsed, 2),
        },
        verdict=verdict,
        tolerance_pct=tolerance_pct,
        ts=timestamp,
        warnings=warnings_list,
    )
    output.write_text(json.dumps(asdict(result), indent=2), encoding="utf-8")
    print(f"  json written:        {output}")
    return result


# --------------------------------------------------------------------------- #
# CLI entry point
# --------------------------------------------------------------------------- #

def cmd_bench_ppl(args: argparse.Namespace) -> int:
    """`uc bench-ppl <pack_dir> --against-bf16 [HF_ID]` entry point."""
    try:
        result = bench_ppl(
            pack_dir=args.pack_dir,
            against_bf16=getattr(args, "against_bf16", None),
            n_prompts=int(args.n_prompts),
            seq_len=int(args.seq_len),
            seed=int(args.seed),
            dataset_name=str(args.dataset_name),
            dataset_config=(str(args.dataset_config)
                             if getattr(args, "dataset_config", None) else None),
            tail_offset=int(args.tail_offset),
            published_ratio=(float(args.published_ratio)
                              if args.published_ratio is not None else None),
            tolerance_pct=float(args.tolerance_pct),
            device=str(args.device),
            output=getattr(args, "output", None),
        )
    except (FileNotFoundError, ValueError, ImportError, RuntimeError) as exc:
        print(f"[FAILED] {type(exc).__name__}: {exc}")
        return 2

    # Exit code: 0 for PASS / MEASURED, 1 for FAIL.
    return 0 if result.verdict in ("PASS", "MEASURED") else 1
