"""
UltraCompress -- production model compression.

Default `uc.compress(...)` is the v3 stack: scalar symmetric per-row
quantization + learned low-rank correction, trained via KL distillation.

Production hyperparameters and codec internals are patent-protected
(provisional applications filed; numbers under NDA). See https://github.com/sipsalabs/ultracompress
for verified PPL ratios per architecture in BENCHMARKS.json.

Legacy codebook-based pipelines are not part of this distribution; they were
deprecated in favor of the v3 default and are no longer shipped.

Usage:
  import ultracompress as uc
  compressed = uc.compress(model, mode='scalar',
                           target_bpw=5.0,
                           tokens=calibration_token_ids)
  uc.save(compressed, 'my_model.uc')
  reloaded = uc.load('my_model.uc', fresh_skeleton)
"""

__version__ = "0.6.9"

# Suppress the pynvml deprecation FutureWarning that torch.cuda emits at
# import time.  Must run before any code path that triggers `import torch`.
import warnings as _warnings
_warnings.filterwarnings(
    "ignore",
    message=r".*pynvml package is deprecated.*",
    category=FutureWarning,
)
del _warnings


def _show_welcome_once():
    """One-time post-install banner. Silent on every failure path."""
    try:
        import os
        import sys
        from pathlib import Path

        marker_dir = Path.home() / ".ultracompress"
        marker = marker_dir / "welcomed"
        if marker.exists():
            return

        # Only print when stderr is a real terminal -- never in CI/pipelines.
        if not (hasattr(sys.stderr, "isatty") and sys.stderr.isatty()):
            # Still drop the marker so we don't reprobe forever in non-tty contexts.
            marker_dir.mkdir(parents=True, exist_ok=True)
            marker.touch()
            return

        banner = (
            "============================================================\n"
            " Thanks for installing ultracompress 0.6.9.\n"
            " \n"
            " Building with model compression?\n"
            " Get prioritized support + early v0.7 access:\n"
            " https://sipsalabs.com/u\n"
            "============================================================\n"
        )
        sys.stderr.write(banner)
        sys.stderr.flush()

        marker_dir.mkdir(parents=True, exist_ok=True)
        marker.touch()
    except Exception:
        pass


_show_welcome_once()


# v3 is the default
from ultracompress.api_v3 import (
    compress,
    save,
    load,
    CompressedModel,
    CompressionReport,
    SCHEMA_VERSION,
)

# Public bench API - imported lazily to avoid pulling transformers/torch eagerly
# when the user only needs `compress` / `save` / `load`.
def bench_packed(*args, **kwargs):
    """Inference throughput benchmark on a UC v3 packed model.

    See `ultracompress.bench.bench_packed` for the full signature and docs.
    """
    from ultracompress.bench import bench_packed as _impl
    return _impl(*args, **kwargs)


__all__ = [
    "compress", "save", "load",
    "CompressedModel", "CompressionReport",
    "SCHEMA_VERSION",
    "bench_packed",
]
