"""Benchmark Surya OCR batch sizes."""

import time
from pathlib import Path

import fitz
from PIL import Image
from surya.detection import DetectionPredictor
from surya.recognition import FoundationPredictor, RecognitionPredictor

PDF_PATH = Path("examples/Subrina_proposal (1).pdf")

# Load models once
print("Loading models...")
foundation = FoundationPredictor()
det = DetectionPredictor()
rec = RecognitionPredictor(foundation)

# Render pages once
print("Rendering pages...")
doc = fitz.open(PDF_PATH)
images = []
for pno in range(doc.page_count):
    page = doc[pno]
    mat = fitz.Matrix(2, 2)
    pix = page.get_pixmap(matrix=mat)
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    images.append(img)
doc.close()
print(f"  {len(images)} pages rendered\n")

# Benchmark configurations
configs = [
    ("default (det=8, rec=64)", {}),
    ("rec=32", {"recognition_batch_size": 32}),
    ("rec=128", {"recognition_batch_size": 128}),
    ("rec=256", {"recognition_batch_size": 256}),
    ("det=4, rec=128", {"detection_batch_size": 4, "recognition_batch_size": 128}),
]

RUNS = 2

for name, kwargs in configs:
    times = []
    for run in range(RUNS):
        t0 = time.perf_counter()
        predictions = rec(images, det_predictor=det, **kwargs)
        elapsed = time.perf_counter() - t0
        times.append(elapsed)
        print(f"  {name} run {run+1}: {elapsed:.1f}s")
    avg = sum(times) / len(times)
    print(f"  => {name} avg: {avg:.1f}s\n")
