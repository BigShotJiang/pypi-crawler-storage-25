"""Textual TUI application for Eastern Night."""

from __future__ import annotations

from typing import Optional

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Static

from .clock import ClockWidget
from .player import PlayerController


def _ar(text: str) -> str:
    """Return Arabic text as-is (raw Unicode — works in PoPOS terminal)."""
    return text


# ── Arabic title constant ──────────────────────────────────────────────────
_AR_TITLE = "الليل الشرقي"  # Eastern Night in Arabic


# ──────────────────────────────────────────────────────────────────────────
# Header bar  (replaces Textual's default Header)
# ──────────────────────────────────────────────────────────────────────────

class HeaderBar(Static):
    """Single-line custom header."""

    DEFAULT_CSS = """
    HeaderBar {
        height: 1;
        color: #6b4f1a;
        padding: 0 1;
    }
    """

    def render(self) -> Text:
        t = Text(no_wrap=True, overflow="crop")
        t.append("  ✦  ", style="#c8952a")
        t.append("Eastern Night", style="#e8b84b bold")
        t.append("  ·  ", style="#2a1f0a")
        t.append(_AR_TITLE, style="#c8952a")
        t.append("  ✦", style="#c8952a")
        return t


# ──────────────────────────────────────────────────────────────────────────
# Footer bar
# ──────────────────────────────────────────────────────────────────────────

class FooterBar(Static):
    """Single-line key-hint footer."""

    DEFAULT_CSS = """
    FooterBar {
        height: 1;
        color: #2a1f0a;
        padding: 0 1;
    }
    """

    def render(self) -> Text:
        t = Text(no_wrap=True, overflow="crop")
        pairs = [("p", "pause"), ("n", "next"), ("s", "shuffle"), ("q", "quit")]
        for i, (key, label) in enumerate(pairs):
            if i:
                t.append("  ·  ", style="#1a1428")
            t.append(f" {key} ", style="#c8952a")
            t.append(label, style="#6b4f1a")
        return t


# ──────────────────────────────────────────────────────────────────────────
# Separator
# ──────────────────────────────────────────────────────────────────────────

class Divider(Static):
    DEFAULT_CSS = """
    Divider {
        height: 1;
        color: #2a1f0a;
    }
    """

    def render(self) -> str:
        return "─" * self.size.width

# ──────────────────────────────────────────────────────────────────────────
# Saxophone Panel
# ──────────────────────────────────────────────────────────────────────────

class SaxophonePanel(Static):
    """Left panel — static ASCII saxophone, centred vertically."""

    # 20-row, ~18-char-wide saxophone drawing
    _SAX: list[str] = [
        "       _        ",
        "      ( )       ",
        "       |        ",
        "      /|        ",
        "     / |        ",
        "    /  | o      ",
        "   /   | o      ",
        "  /    | o      ",
        " /     | o      ",
        "|      | o      ",
        "|      |        ",
        "|       \\       ",
        "|        \\      ",
        "|         \\     ",
        "|__________\\    ",
        " /           \\  ",
        "(             ) ",
        " \\___________ / ",
    ]

    DEFAULT_CSS = """
    SaxophonePanel {
        width: 45%;
        height: 100%;
        border-right: solid #2a1f0a;
        padding: 0 2;
    }
    """

    def render(self) -> Text:
        h = max(self.size.height, 1)
        art = self._SAX
        top_pad = max(0, (h - len(art)) // 2)

        t = Text(no_wrap=True, overflow="crop")
        for _ in range(top_pad):
            t.append("\n")

        for i, line in enumerate(art):
            # Neck / mouthpiece: bright gold
            if i < 4:
                body_color = "#e8b84b"
            # Upper body
            elif i < 11:
                body_color = "#c8952a"
            # Lower body / bell
            else:
                body_color = "#6b4f1a"

            for ch in line:
                if ch == "o":           # key pads — bright accent
                    t.append(ch, style="#f0d070 bold")
                else:
                    t.append(ch, style=body_color)
            t.append("\n")

        return t




# ──────────────────────────────────────────────────────────────────────────
# Now-playing widget
# ──────────────────────────────────────────────────────────────────────────

class NowPlaying(Static):
    """Track title + progress bar."""

    DEFAULT_CSS = """
    NowPlaying {
        color: #c8952a;
        padding: 1 0;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._title = ""
        self._title_ar = ""
        self._position = 0.0
        self._duration = 0.0
        self._status = "idle"

    def set_track(self, track: Optional[dict]) -> None:
        if track:
            self._title = track.get("title", "")
            self._title_ar = track.get("title_ar", "")
        else:
            self._title = ""
            self._title_ar = ""
        self.refresh()

    def set_progress(self, position: float, duration: float, status: str) -> None:
        self._position = position
        self._duration = duration
        self._status = status
        self.refresh()

    def render(self) -> Text:
        t = Text(no_wrap=True, overflow="crop")

        # Track name line
        if self._title:
            t.append("  🎵  ", style="#6b4f1a")
            t.append(self._title, style="#e8b84b bold")
            if self._title_ar:
                ar = _ar(self._title_ar)
                t.append("  ", style="")
                t.append(ar, style="#c8952a")
        else:
            t.append("  🎵  ", style="#6b4f1a")
            t.append("Loading...", style="#6b4f1a")
        t.append("\n")

        # Progress bar line
        bar_w = 22
        if self._duration > 0:
            filled = max(0, min(bar_w, int(self._position / self._duration * bar_w)))
            bar = "━" * filled + "░" * (bar_w - filled)
            pos = f"{int(self._position // 60):02d}:{int(self._position % 60):02d}"
            dur = f"{int(self._duration // 60):02d}:{int(self._duration % 60):02d}"
            t.append(f"  {bar}", style="#c8952a")
            t.append(f"  {pos} / {dur}", style="#6b4f1a")
        else:
            if self._status == "loading":
                t.append("  ⟳  resolving stream...", style="#6b4f1a")
            elif self._status == "error":
                t.append("  ✗  stream error", style="#6b4f1a")
            else:
                t.append("  " + "─" * bar_w, style="#2a1f0a")
        t.append("\n")

        return t


# ──────────────────────────────────────────────────────────────────────────
# Info Panel
# ──────────────────────────────────────────────────────────────────────────

class InfoPanel(Vertical):
    """Right panel: now-playing + clock."""

    DEFAULT_CSS = """
    InfoPanel {
        width: 55%;
        height: 100%;
        padding: 0 1;
    }
    #np {
        height: auto;
    }
    #sep {
        height: 1;
        color: #2a1f0a;
        padding: 0 2;
    }
    #clock {
        padding: 0 2;
        color: #c8952a;
    }
    """

    def compose(self) -> ComposeResult:
        yield NowPlaying(id="np")
        yield Static("─" * 30, id="sep")
        yield ClockWidget(id="clock")

    def update_track(self, track: Optional[dict]) -> None:
        self.query_one("#np", NowPlaying).set_track(track)
        if track:
            clock = self.query_one("#clock", ClockWidget)
            clock.set_city(track.get("city", "Cairo"), track.get("city_ar", "القاهرة"))

    def update_progress(self, pos: float, dur: float, status: str) -> None:
        self.query_one("#np", NowPlaying).set_progress(pos, dur, status)


# ──────────────────────────────────────────────────────────────────────────
# Main App
# ──────────────────────────────────────────────────────────────────────────

class EasternNightApp(App):

    CSS = """
    Screen {
        layers: base;
    }

    #main-layout {
        height: 1fr;
    }

    /* Focus mode */
    .focus-mode #np {
        display: none;
    }
    .focus-mode #sep {
        display: none;
    }
    """

    BINDINGS = [
        Binding("p",      "toggle_pause",   "pause",   show=False),
        Binding("space",  "toggle_pause",   "pause",   show=False),
        Binding("n",      "next_track",     "next",    show=False),
        Binding("s",      "toggle_shuffle", "shuffle", show=False),
        Binding("q",      "quit",           "quit",    show=False),
        Binding("ctrl+c", "quit",           "quit",    show=False),
    ]

    def __init__(self, playlist: list[dict], focus_mode: bool = False):
        super().__init__()
        self._playlist = playlist
        self._focus_mode = focus_mode
        self._controller: Optional[PlayerController] = None
        self._shuffled = False

    def compose(self) -> ComposeResult:
        yield HeaderBar()
        with Horizontal(id="main-layout"):
            yield SaxophonePanel(id="sax")
            yield InfoPanel(id="info")
        yield FooterBar()

    def on_mount(self) -> None:
        if self._focus_mode:
            self.add_class("focus-mode")

        self._controller = PlayerController(self._playlist)
        self._controller.on_status_change(self._on_status_change)
        self._controller.start()

        self.set_interval(1.0, self._poll)

    def _on_status_change(self) -> None:
        self.call_from_thread(self._sync)

    def _sync(self) -> None:
        if not self._controller:
            return
        self.query_one("#info", InfoPanel).update_track(self._controller.current_track)

    def _poll(self) -> None:
        if not self._controller:
            return
        self.query_one("#info", InfoPanel).update_progress(
            self._controller.position,
            self._controller.duration,
            self._controller.status,
        )

    def action_toggle_pause(self) -> None:
        if self._controller:
            self._controller.toggle_pause()

    def action_next_track(self) -> None:
        if self._controller:
            self._controller.next_track()

    def action_toggle_shuffle(self) -> None:
        if not self._controller:
            return
        import random
        self._shuffled = not self._shuffled
        if self._shuffled:
            random.shuffle(self._controller.playlist)
        self.notify("Shuffle " + ("on" if self._shuffled else "off"))

    def action_quit(self) -> None:
        if self._controller:
            self._controller.quit()
        self.exit()
