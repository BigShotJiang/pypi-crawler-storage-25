"""Sharqify track catalog and audio URL resolver."""

from __future__ import annotations

TRACKS = [
    {
        "id": "sharqify_oud_jazz",
        "title": "Oud & Jazz",
        "title_ar": "عود و جاز",
        "youtube_url": "https://www.youtube.com/watch?v=ubwVt7EKkVM",
        "duration_hint": "60:00",
        "mood": "chill",
        "city": "Cairo",
        "city_ar": "القاهرة",
    },
    {
        "id": "sharqify_arabian_nights",
        "title": "Arabian Oud Nights",
        "title_ar": "ليالي العود العربية",
        "youtube_url": "https://www.youtube.com/watch?v=bi6t8waHWZo",
        "duration_hint": "60:00",
        "mood": "melancholic",
        "city": "Beirut",
        "city_ar": "بيروت",
    },
    {
        "id": "sharqify_lofi_dreamy",
        "title": "Lofi Dreamy Arabian Oud",
        "title_ar": "لوفاي عود حالم",
        "youtube_url": "https://www.youtube.com/watch?v=Cv_CUx1DelI",
        "duration_hint": "60:00",
        "mood": "chill",
        "city": "Baghdad",
        "city_ar": "بغداد",
    },
    {
        "id": "sharqify_flamenco_arabic",
        "title": "Arabic Oud × Flamenco",
        "title_ar": "عود عربي × فلامنكو",
        "youtube_url": "https://www.youtube.com/watch?v=0urW2ZBGiOg",
        "duration_hint": "60:00",
        "mood": "energetic",
        "city": "Casablanca",
        "city_ar": "الدار البيضاء",
    },
    {
        "id": "sharqify_silk_road",
        "title": "Silk Road",
        "title_ar": "طريق الحرير",
        "youtube_url": "https://www.youtube.com/watch?v=6diMzLQfTxA",
        "duration_hint": "60:00",
        "mood": "chill",
        "city": "Damascus",
        "city_ar": "دمشق",
    },
    {
        "id": "sharqify_desert_bayati",
        "title": "Arabian Desert — Oud Bayati",
        "title_ar": "صحراء عربية — عود بياتي",
        "youtube_url": "https://www.youtube.com/watch?v=aEFVhPKvwm4",
        "duration_hint": "60:00",
        "mood": "melancholic",
        "city": "Riyadh",
        "city_ar": "الرياض",
    },
    {
        "id": "sharqify_afro_cuban",
        "title": "Afro-Cuban Jazz Oud",
        "title_ar": "جاز أفرو كوبي وعود",
        "youtube_url": "https://www.youtube.com/watch?v=8Qg0XW1D6qc",
        "duration_hint": "60:00",
        "mood": "energetic",
        "city": "Amman",
        "city_ar": "عمان",
    },
    {
        "id": "sharqify_oud_violin",
        "title": "Oud, Violin & Jazz",
        "title_ar": "عود كمان و جاز",
        "youtube_url": "https://www.youtube.com/watch?v=BGCT8QVctes",
        "duration_hint": "60:00",
        "mood": "melancholic",
        "city": "Cairo",
        "city_ar": "القاهرة",
    },
    {
        "id": "sharqify_east_west",
        "title": "East–West Music Bridge",
        "title_ar": "جسر الشرق والغرب",
        "youtube_url": "https://www.youtube.com/watch?v=vGOXSSV5AKk",
        "duration_hint": "60:00",
        "mood": "chill",
        "city": "Tunis",
        "city_ar": "تونس",
    },
    {
        "id": "sharqify_expressive_oud",
        "title": "Expressive Oud Jazz",
        "title_ar": "عود جاز تعبيري",
        "youtube_url": "https://www.youtube.com/watch?v=-dpeG9HjezM",
        "duration_hint": "60:00",
        "mood": "melancholic",
        "city": "Amman",
        "city_ar": "عمان",
    },
    {
        "id": "sharqify_lofi_3h",
        "title": "Lofi Oud & Jazz — Deep Focus",
        "title_ar": "عود جاز لوفاي — تركيز عميق",
        "youtube_url": "https://www.youtube.com/watch?v=5Q-jLprWaXU",
        "duration_hint": "180:00",
        "mood": "chill",
        "city": "Beirut",
        "city_ar": "بيروت",
    },
    {
        "id": "sharqify_smoky_midnight",
        "title": "Smoky Midnight Jazz",
        "title_ar": "جاز منتصف الليل دخاني",
        "youtube_url": "https://www.youtube.com/watch?v=2uH3xSI3nZE",
        "duration_hint": "60:00",
        "mood": "melancholic",
        "city": "Baghdad",
        "city_ar": "بغداد",
    },
]


def resolve_audio_url(youtube_url: str) -> str:
    """Resolve a YouTube URL to a direct audio stream URL using yt-dlp."""
    import yt_dlp

    ydl_opts = {
        "format": "bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        # Use android client to avoid needing a JS runtime (node/deno)
        "extractor_args": {"youtube": {"player_client": ["android"]}},
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(youtube_url, download=False)
        return info["url"]
