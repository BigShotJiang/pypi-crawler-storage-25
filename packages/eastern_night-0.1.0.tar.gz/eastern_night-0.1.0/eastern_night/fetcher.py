"""Dynamic catalog fetcher for Eastern Night.

Scrapes a YouTube channel/playlist via yt-dlp (flat metadata only — no
download), merges with the static catalog so curated Arabic titles and city
data are preserved, and caches the result to disk for 24 hours so startup is
instant on repeat runs.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

# ── Sharqify channel / playlist to scrape ─────────────────────────────────
CHANNEL_URLS: list[str] = [
    "https://www.youtube.com/@Sharqify/videos",
]

# Cache lives in ~/.cache/eastern_night/
_CACHE_DIR = Path.home() / ".cache" / "eastern_night"
_CACHE_FILE = _CACHE_DIR / "catalog.json"
_CACHE_TTL_SECONDS = 60 * 60 * 24  # 24 hours

# City round-robin fallback for tracks whose city is unknown
_FALLBACK_CITIES = [
    ("Cairo",      "القاهرة"),
    ("Beirut",     "بيروت"),
    ("Baghdad",    "بغداد"),
    ("Damascus",   "دمشق"),
    ("Amman",      "عمان"),
    ("Tunis",      "تونس"),
    ("Casablanca", "الدار البيضاء"),
    ("Riyadh",     "الرياض"),
]


# ── Cache helpers ──────────────────────────────────────────────────────────

def _load_cache() -> Optional[list[dict]]:
    """Return cached tracks if the cache file exists and is fresh."""
    if not _CACHE_FILE.exists():
        return None
    age = time.time() - _CACHE_FILE.stat().st_mtime
    if age > _CACHE_TTL_SECONDS:
        return None
    try:
        with _CACHE_FILE.open(encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list) and data:
            return data
    except Exception:
        pass
    return None


def _save_cache(tracks: list[dict]) -> None:
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with _CACHE_FILE.open("w", encoding="utf-8") as f:
            json.dump(tracks, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ── yt-dlp scrape ─────────────────────────────────────────────────────────

def _scrape_channel(url: str) -> list[dict]:
    """Flat-scrape a channel/playlist URL and return raw entry dicts."""
    import yt_dlp

    opts = {
        "extract_flat": "in_playlist",
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": True,
        # Limit to the 200 most recent uploads; raise if you want more
        "playlistend": 200,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)

    entries = []
    if info and "entries" in info:
        for e in info["entries"]:
            if not e or not e.get("id"):
                continue
            entries.append(e)
    return entries


# ── Merge helpers ──────────────────────────────────────────────────────────

def _build_static_index(static_tracks: list[dict]) -> dict[str, dict]:
    """Build a video-ID → track dict from the static catalog."""
    idx: dict[str, dict] = {}
    for t in static_tracks:
        url = t.get("youtube_url", "")
        vid_id = _extract_id(url)
        if vid_id:
            idx[vid_id] = t
    return idx


def _extract_id(youtube_url: str) -> str:
    """Pull the video ID out of a youtube.com watch URL."""
    for sep in ("v=", "youtu.be/"):
        if sep in youtube_url:
            part = youtube_url.split(sep, 1)[1]
            return part.split("&")[0].split("?")[0]
    return ""


def _entry_to_track(entry: dict, fallback_city_idx: int) -> dict:
    """Convert a yt-dlp flat entry into an Eastern Night track dict."""
    vid_id = entry.get("id", "")
    city, city_ar = _FALLBACK_CITIES[fallback_city_idx % len(_FALLBACK_CITIES)]
    duration_secs = entry.get("duration") or 0
    if duration_secs:
        mins = int(duration_secs) // 60
        secs = int(duration_secs) % 60
        duration_hint = f"{mins}:{secs:02d}"
    else:
        duration_hint = "60:00"

    return {
        "id": f"yt_{vid_id}",
        "title": entry.get("title") or "Unknown",
        "title_ar": "",          # not in YT metadata; curated entries override
        "youtube_url": f"https://www.youtube.com/watch?v={vid_id}",
        "duration_hint": duration_hint,
        "mood": "chill",
        "city": city,
        "city_ar": city_ar,
    }


# ── Public API ─────────────────────────────────────────────────────────────

def build_playlist(static_tracks: list[dict], *, force_refresh: bool = False) -> list[dict]:
    """Return a merged, de-duplicated track list.

    Priority order:
      1. Cached result (if fresh and force_refresh is False)
      2. Fresh yt-dlp scrape merged with static catalog
      3. Static catalog alone (if network is unavailable)

    Curated static entries (with Arabic titles / city data) always take
    precedence over auto-fetched entries for the same video ID.
    """
    if not force_refresh:
        cached = _load_cache()
        if cached:
            return cached

    static_index = _build_static_index(static_tracks)

    fetched_entries: list[dict] = []
    for url in CHANNEL_URLS:
        try:
            fetched_entries.extend(_scrape_channel(url))
        except Exception:
            pass  # network failure — fall through to static fallback

    if not fetched_entries:
        # No network / yt-dlp error — just use the static catalog
        return list(static_tracks)

    # Merge: static entries take precedence; new YT entries are appended
    seen_ids: set[str] = set()
    merged: list[dict] = []

    # 1. Add all static entries first (preserve curation)
    for t in static_tracks:
        vid_id = _extract_id(t.get("youtube_url", ""))
        if vid_id:
            seen_ids.add(vid_id)
        merged.append(t)

    # 2. Append fetched entries that aren't already in the static list
    city_counter = 0
    for entry in fetched_entries:
        vid_id = entry.get("id", "")
        if not vid_id or vid_id in seen_ids:
            continue
        seen_ids.add(vid_id)
        track = _entry_to_track(entry, city_counter)
        # If the static index has metadata for this ID under a different key,
        # prefer the curated version
        if vid_id in static_index:
            merged.append(static_index[vid_id])
        else:
            merged.append(track)
        city_counter += 1

    _save_cache(merged)
    return merged
