"""Opening splash screen for Eastern Night."""

from __future__ import annotations

import time

from rich.align import Align
from rich.console import Console
from rich.text import Text

console = Console()


def _ar(text: str) -> str:
    """Return Arabic text as raw Unicode (works in PoPOS terminal)."""
    return text


def run_intro() -> None:
    """Display the opening splash then clear for the TUI."""
    console.clear()

    w = console.width or 80

    console.print()

    # ── Arabic title (raw Unicode) ─────────────────────────────────────────
    ar = _ar("الليل الشرقي")
    console.print(Align.center(Text(ar, style="#e8b84b bold")))

    # ── Divider ────────────────────────────────────────────────────────────
    console.print(Align.center(Text("─" * 22, style="#2a1f0a")))

    # ── English title ──────────────────────────────────────────────────────
    console.print(Align.center(Text("Eastern Night", style="#f5ead0 bold")))

    console.print()

    # ── Subtitle ───────────────────────────────────────────────────────────
    console.print(
        Align.center(Text("A terminal experience  ·  Powered by Sharqify", style="#6b4f1a"))
    )

    console.print()
    time.sleep(2.0)

    # ── Sweep ──────────────────────────────────────────────────────────────
    console.print("━" * w, style="#e8b84b", end="\r")
    time.sleep(0.15)
    console.clear()
