"""mpv IPC controller for Eastern Night."""

from __future__ import annotations

import threading
from typing import Callable, Optional


class Player:
    """Controls mpv audio playback silently in the background."""

    def __init__(self):
        import mpv
        self._mpv = mpv.MPV(
            video=False,
            terminal=False,
            really_quiet=True,
        )
        self._current_track: Optional[dict] = None
        self._on_end_callbacks: list[Callable] = []

        @self._mpv.event_callback("end-file")
        def _on_end(event):
            # event.data is MpvEventEndFile; reason == 0 means normal EOF
            try:
                if event.data is not None and event.data.reason == 0:
                    for cb in self._on_end_callbacks:
                        try:
                            cb()
                        except Exception:
                            pass
            except Exception:
                pass

    def play(self, url: str, track: Optional[dict] = None) -> None:
        self._current_track = track
        self._mpv.play(url)

    def pause(self) -> None:
        self._mpv.pause = not self._mpv.pause

    def stop(self) -> None:
        try:
            self._mpv.stop()
        except Exception:
            pass

    def quit(self) -> None:
        try:
            self._mpv.terminate()
        except Exception:
            pass

    def on_track_end(self, callback: Callable) -> None:
        self._on_end_callbacks.append(callback)

    @property
    def position(self) -> float:
        try:
            return self._mpv.time_pos or 0.0
        except Exception:
            return 0.0

    @property
    def duration(self) -> float:
        try:
            return self._mpv.duration or 0.0
        except Exception:
            return 0.0

    @property
    def is_playing(self) -> bool:
        try:
            return not self._mpv.pause
        except Exception:
            return False

    @property
    def current_track(self) -> Optional[dict]:
        return self._current_track


class PlayerController:
    """
    High-level controller that manages a playlist and resolves audio URLs
    in background threads so the UI stays responsive.
    """

    def __init__(self, playlist: list[dict], shuffle: bool = False):
        self._player = Player()
        self._playlist = list(playlist)
        self._index = 0
        self._loading = False
        self._status = "idle"      # idle | loading | playing | paused | error
        self._error: Optional[str] = None
        self._on_status_change: list[Callable] = []

        self._player.on_track_end(self._advance)

    def start(self) -> None:
        self._load_and_play(self._index)

    def _load_and_play(self, index: int) -> None:
        if not self._playlist:
            return
        self._index = index % len(self._playlist)
        track = self._playlist[self._index]
        self._status = "loading"
        self._notify()
        threading.Thread(target=self._resolve_and_play, args=(track,), daemon=True).start()

    def _resolve_and_play(self, track: dict) -> None:
        from .catalog import resolve_audio_url
        try:
            url = resolve_audio_url(track["youtube_url"])
            self._player.play(url, track=track)
            self._status = "playing"
        except Exception as exc:
            self._status = "error"
            self._error = str(exc)
        self._notify()

    def _advance(self) -> None:
        next_index = (self._index + 1) % len(self._playlist)
        self._load_and_play(next_index)

    def next_track(self) -> None:
        self._player.stop()
        self._advance()

    def toggle_pause(self) -> None:
        self._player.pause()
        if self._status == "playing":
            self._status = "paused"
        elif self._status == "paused":
            self._status = "playing"
        self._notify()

    def stop(self) -> None:
        self._player.stop()
        self._status = "idle"
        self._notify()

    def quit(self) -> None:
        self._player.quit()

    def on_status_change(self, callback: Callable) -> None:
        self._on_status_change.append(callback)

    def _notify(self) -> None:
        for cb in self._on_status_change:
            try:
                cb()
            except Exception:
                pass

    @property
    def status(self) -> str:
        return self._status

    @property
    def error(self) -> Optional[str]:
        return self._error

    @property
    def current_track(self) -> Optional[dict]:
        return self._player.current_track

    @property
    def position(self) -> float:
        return self._player.position

    @property
    def duration(self) -> float:
        return self._player.duration

    @property
    def is_playing(self) -> bool:
        return self._player.is_playing

    @property
    def playlist(self) -> list[dict]:
        return self._playlist

    @property
    def current_index(self) -> int:
        return self._index
