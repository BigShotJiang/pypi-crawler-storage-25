"""Geometric art panel — tiled girih lattice pattern."""

from __future__ import annotations

import math
import time

PULSE_PERIOD = 4.0
FRAME_RATE = 1  # 1 FPS — only the center pulses

# Tile dimensions: with 2:1 cell aspect ratio,
# TILE_W=4 chars × TILE_H=2 rows  ≈  4×4 visual units (square tile)
TILE_W = 4
TILE_H = 2


class GeometryRenderer:
    """
    Fills the panel with a repeating girih-lattice pattern.

    Pattern (one tile):
        ◈───◇───◈───◇───◈
        │   │   │   │   │
        ◇───◈───◇───◈───◇
        │   │   │   │   │

    Colors fade from bright gold at center to dim amber at the edges.
    Only the center glyph pulses between ✺ and ❋.
    """

    def __init__(self, width: int, height: int):
        self.width = max(width, 1)
        self.height = max(height, 1)
        self.start_time = time.time()

    def resize(self, width: int, height: int) -> None:
        self.width = max(width, 1)
        self.height = max(height, 1)

    def elapsed(self) -> float:
        return time.time() - self.start_time

    def render_frame(self) -> list[list[tuple[str, str]]]:
        t = self.elapsed()
        w = self.width
        h = self.height

        # Snap center to nearest node so the center always lands on a symbol
        snap_cx = (w // 2 // TILE_W) * TILE_W
        snap_cy = (h // 2 // TILE_H) * TILE_H

        grid: list[list[tuple[str, str]]] = [
            [(" ", "#0a0e1a")] * w for _ in range(h)
        ]

        for row in range(h):
            tile_row = row % TILE_H
            node_y = row // TILE_H

            for col in range(w):
                tile_col = col % TILE_W
                node_x = col // TILE_W

                # Normalised distance from the snapped center (0 = center, 1 = edge)
                dx = (col - snap_cx) / max(w * 0.5, 1)
                dy = (row - snap_cy) / max(h * 0.5, 1)
                dist = min(1.0, math.sqrt(dx * dx + dy * dy))

                if tile_row == 0 and tile_col == 0:
                    # ── Node symbol ────────────────────────────────────────
                    char = "◈" if (node_x + node_y) % 2 == 0 else "◇"
                    if dist < 0.20:
                        color = "#e8b84b"
                    elif dist < 0.45:
                        color = "#c8952a"
                    elif dist < 0.72:
                        color = "#6b4f1a"
                    else:
                        color = "#2a1f0a"
                    grid[row][col] = (char, color)

                elif tile_row == 0:
                    # ── Horizontal connector ────────────────────────────────
                    if dist < 0.30:
                        color = "#c8952a"
                    elif dist < 0.60:
                        color = "#6b4f1a"
                    else:
                        color = "#1a1428"
                    grid[row][col] = ("─", color)

                elif tile_row == 1 and tile_col == 0:
                    # ── Vertical connector ──────────────────────────────────
                    if dist < 0.30:
                        color = "#6b4f1a"
                    elif dist < 0.60:
                        color = "#2a1f0a"
                    else:
                        color = "#12102a"
                    grid[row][col] = ("│", color)

                # else: background — stays "#0a0e1a"

        # ── Center pulse (only animated element) ───────────────────────────
        pulse = 0.7 + 0.3 * math.sin(t * math.pi * 2 / PULSE_PERIOD)
        sym = "✺" if pulse > 0.85 else "❋"
        if 0 <= snap_cx < w and 0 <= snap_cy < h:
            grid[snap_cy][snap_cx] = (sym, "#ffffff")

        return grid
