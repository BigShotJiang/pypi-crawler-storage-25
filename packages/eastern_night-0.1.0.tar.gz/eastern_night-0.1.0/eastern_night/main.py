"""CLI entry point for Eastern Night."""

from __future__ import annotations

import random
import shutil
import sys

import click


def _check_mpv() -> None:
    """Exit with a helpful message if mpv or libmpv is not installed."""
    if shutil.which("mpv") is None:
        click.echo(
            "✗ mpv not found. Please install it first:\n"
            "  macOS:  brew install mpv\n"
            "  Ubuntu: sudo apt install mpv\n"
            "  Arch:   sudo pacman -S mpv",
            err=True,
        )
        sys.exit(1)

    # Check that the libmpv shared library is available (needed by python-mpv)
    try:
        import mpv  # noqa: F401
    except OSError:
        click.echo(
            "✗ libmpv shared library not found.\n"
            "  The mpv binary is installed but the client library is missing.\n"
            "  Ubuntu: sudo apt install libmpv2\n"
            "  Arch:   sudo pacman -S mpv  (includes libmpv)\n"
            "  macOS:  brew install mpv",
            err=True,
        )
        sys.exit(1)


@click.command()
@click.option("--no-intro", is_flag=True, help="Skip the opening cinematic")
@click.option(
    "--shuffle/--no-shuffle",
    default=True,
    help="Shuffle tracks (default: on)",
)
@click.option("--focus", is_flag=True, help="Focus mode: minimal UI, just art + music")
@click.option("--track", default=None, help="Play a specific track by ID")
def cli(no_intro: bool, shuffle: bool, focus: bool, track: str | None) -> None:
    """
    \b
    🌙 Eastern Night — A terminal ambient experience

    Streams Sharqify's Arabic jazz music while displaying
    Islamic geometric art in your terminal.

    \b
    Project: https://github.com/yourusername/eastern-night
    Music:   https://sharqify.net
    """
    _check_mpv()

    from .catalog import TRACKS
    from .fetcher import build_playlist
    from .intro import run_intro
    from .app import EasternNightApp

    if not no_intro:
        run_intro()

    # Build the playlist — scrapes the channel on first run (or after 24 h),
    # then uses the disk cache. Falls back to the static catalog if offline.
    click.echo("  ✦  Fetching catalog…", nl=False)
    try:
        playlist = build_playlist(TRACKS)
        click.echo(f"\r  ✦  {len(playlist)} tracks loaded.      ")
    except Exception:
        playlist = list(TRACKS)
        click.echo("\r  ✦  Offline — using built-in catalog.")

    import time as _time
    _time.sleep(0.6)   # let the user see the count before TUI takes over

    if shuffle:
        random.shuffle(playlist)
    if track:
        specific = [t for t in playlist if t["id"] == track]
        playlist = specific if specific else playlist

    app = EasternNightApp(
        playlist=playlist,
        focus_mode=focus,
    )
    app.run()
