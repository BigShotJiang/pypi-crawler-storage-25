"""Arab city clock widget for Eastern Night."""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

from textual.widgets import Static

CITY_TIMEZONES: dict[str, str] = {
    "Cairo":       "Africa/Cairo",
    "Beirut":      "Asia/Beirut",
    "Baghdad":     "Asia/Baghdad",
    "Tunis":       "Africa/Tunis",
    "Casablanca":  "Africa/Casablanca",
    "Amman":       "Asia/Amman",
    "Damascus":    "Asia/Damascus",
    "Riyadh":      "Asia/Riyadh",
}


def _ar(text: str) -> str:
    """Return Arabic text as raw Unicode (works in PoPOS terminal)."""
    return text


class ClockWidget(Static):
    """Displays city name, local time, and weather for the playing track's city."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._city = "Cairo"
        self._city_ar = "القاهرة"
        self._weather = ""

    def on_mount(self) -> None:
        self.set_interval(1.0, self.refresh)
        self._fetch_weather()

    def set_city(self, city: str, city_ar: str) -> None:
        self._city = city
        self._city_ar = city_ar
        self._weather = ""
        self._fetch_weather()
        self.refresh()

    def _fetch_weather(self) -> None:
        import threading
        threading.Thread(target=self._get_weather, daemon=True).start()

    def _get_weather(self) -> None:
        try:
            import httpx
            resp = httpx.get(f"https://wttr.in/{self._city}?format=j1", timeout=5.0)
            data = resp.json()
            cond = data["current_condition"][0]
            temp = cond["temp_C"]
            desc = cond["weatherDesc"][0]["value"]
            self._weather = f"{temp}°C  {desc}"
            self.refresh()
        except Exception:
            self._weather = ""

    def render(self) -> str:
        tz_name = CITY_TIMEZONES.get(self._city, "UTC")
        try:
            now = datetime.now(ZoneInfo(tz_name))
            time_str = now.strftime("%I:%M %p")
        except Exception:
            time_str = "--:-- --"

        ar = _ar(self._city_ar)

        lines = [
            "",
            f"  {ar}",
            f"  {self._city}",
            "  " + "━" * 18,
            f"  {time_str}",
        ]
        if self._weather:
            lines.append(f"  🌡  {self._weather}")
        lines.append("")
        return "\n".join(lines)
