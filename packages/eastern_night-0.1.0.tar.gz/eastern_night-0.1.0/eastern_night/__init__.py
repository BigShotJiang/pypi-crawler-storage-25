"""Eastern Night — A terminal ambient experience for Sharqify's Arabic jazz music."""

__version__ = "0.1.0"
