```
 ███████╗ █████╗ ███████╗████████╗███████╗██████╗ ███╗   ██╗
 ██╔════╝██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗████╗  ██║
 █████╗  ███████║███████╗   ██║   █████╗  ██████╔╝██╔██╗ ██║
 ██╔══╝  ██╔══██║╚════██║   ██║   ██╔══╝  ██╔══██╗██║╚██╗██║
 ███████╗██║  ██║███████║   ██║   ███████╗██║  ██║██║ ╚████║
 ╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝

   ███╗   ██╗██╗ ██████╗ ██╗  ██╗████████╗
   ████╗  ██║██║██╔════╝ ██║  ██║╚══██╔══╝
   ██╔██╗ ██║██║██║  ███╗███████║   ██║
   ██║╚██╗██║██║██║   ██║██╔══██║   ██║
   ██║ ╚████║██║╚██████╔╝██║  ██║   ██║
   ╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝

                  🌙  الليل الشرقي  ✦
```

# Eastern Night — الليل الشرقي

> A terminal ambient experience · Powered by [Sharqify](https://sharqify.net)

**Eastern Night** transforms your terminal into an immersive Arabic jazz café. It streams music directly from Sharqify's YouTube channel — Arabic jazz and oud fusion — while displaying a Saxon art panel and a city atmosphere widget, all rendered entirely in your terminal with no browser or GUI required.

---

## Quickstart

> **Requires:** `mpv` installed on your system and `pipx`.

```bash
# Ubuntu / PoPOS / Debian
sudo apt install mpv && pipx run eastern-night

# macOS
brew install mpv && pipx run eastern-night

# Arch Linux
sudo pacman -S mpv && pipx run eastern-night
```

That's it. No cloning, no virtual environment — `pipx run` handles everything else automatically.

---

## Permanent install

If you want `eastern-night` available as a persistent command:

```bash
pipx install eastern-night
eastern-night
```

---

## Features

- **Dynamic catalog** — scrapes Sharqify's full YouTube channel at startup via `yt-dlp`; catalogue is cached locally for 24 hours and refreshed automatically
- **ASCII saxophone panel** — static art panel on the left, coloured in a warm gold palette
- **Music streaming** — plays audio direct from YouTube, resolved at runtime (no downloads)
- **Arab city clock** — shows the local time of the current track's city (Cairo, Beirut, Baghdad, and more)
- **Live weather** — fetches current temperature and conditions from `wttr.in`
- **Cinematic intro** — brief splash screen with Arabic + English title on launch
- **Focus mode** — minimal UI, just art and music
- **Keyboard controls** — pause, next, shuffle, quit
- **Offline fallback** — if the network scrape fails, falls back to the built-in curated catalog instantly

---

## Usage

```bash
eastern-night                # Launch with intro splash
eastern-night --no-intro     # Skip intro, go straight to TUI
eastern-night --focus        # Focus/work mode — minimal UI
eastern-night --no-shuffle   # Play tracks in catalog order
eastern-night --track <id>   # Play a specific track by ID
```

---

## Key Bindings

| Key           | Action              |
|---------------|---------------------|
| `p` / `space` | Pause / Resume      |
| `n`           | Next track          |
| `s`           | Toggle shuffle      |
| `q` / Ctrl+C  | Quit                |

---

## From source

```bash
git clone https://github.com/yourusername/eastern-night
cd eastern-night
pip install -e .
eastern-night
```

---

## System Requirements

| Requirement  | Notes                                     |
|--------------|-------------------------------------------|
| Python 3.10+ | Uses `zoneinfo` (stdlib from 3.9+)        |
| mpv          | Audio playback engine — must be installed |
| pipx / pip   | For installing the package                |
| Internet     | Required for streaming and catalog fetch  |

---

## About Sharqify

[Sharqify](https://sharqify.net) is an Arabic jazz and oud fusion artist whose music blends traditional Middle Eastern sounds with modern lofi and jazz sensibilities. Eastern Night is a fan-made project — all music belongs to Sharqify. Please support the artist directly at **[sharqify.net](https://sharqify.net)**.

---

## License

MIT — see [LICENSE](LICENSE) for details.

*Eastern Night is a fan project and is not affiliated with Sharqify.*
