# 文元启序 (WenYuanQiXu)

> Agent 世界的通用去中心化通信协议 v1.0

**文元启序** 是一个通用的 Agent-to-Agent 通信协议，让任何 AI Agent 能够直接互相通信，无需中心服务器。

## 特性

- 🔑 **去中心化身份** — did:key，永久唯一，无需注册
- 🔐 **端到端加密** — X25519 + AES-256-GCM
- ✍️ **消息签名** — Ed25519，密码学确权
- 📡 **自动发现** — UDP 局域网广播 + Kademlia DHT
- 👥 **群组通信** — 支持多人协作
- 💾 **离线消息** — SQLite 本地加密存储
- 📎 **文件传输** — 分块 + SHA256 校验
- 💓 **心跳保活** — 维持长连接稳定
- 🔄 **密钥轮换** — 前向保密

## 快速开始

### 安装

```bash
pip install wenyuanqixu
# 或
git clone https://github.com/wenyuanqixu/agent-p2p.git
cd agent-p2p
pip install -r requirements.txt
```

### 使用

```python
from 文元启序 import Agent

agent = Agent(port=9000)
await agent.start()

# 发消息
await agent.send_message("did:key:z...对方号码", "你好")

# 收消息（自动加密、签名、解密、验签）
```

### 命令行

```bash
python3 client.py          # 启动客户端
python3 server.py          # 启动服务器
```

## 协议规范

完整规范见 [docs/protocol-v1.md](docs/protocol-v1.md)

19 章节覆盖：身份、消息、握手、加密、心跳、群组、错误、传输、排序、同步、限流、发现、扩展、测试、兼容。

## 架构

```
┌──────────────────────────────────────────┐
│           文元启序 协议层                 │
├──────────────────────────────────────────┤
│  身份: did:key (去中心化永久号码)        │
│  加密: X25519 + AES-256-GCM             │
│  签名: Ed25519                           │
│  传输: TCP / DHT / mDNS                 │
│  消息: JSON 标准格式                      │
├──────────────────────────────────────────┤
│  OpenClaw │ LangChain │ AutoGPT │ CrewAI │
│  BabyAGI  │ MetaGPT   │ 任何Agent       │
└──────────────────────────────────────────┘
```

## 项目结构

```
agent-p2p/
├── docs/               # 协议规范
│   └── protocol-v1.md  # 文元启序 1.0 完整规范
├── src/
│   ├── identity/       # did:key 身份
│   ├── crypto/         # 加密 + 会话 + 密钥轮换
│   ├── protocol/       # 消息 + 群组 + 联系人 + 事件
│   ├── network/        # TCP + 发现 + DHT + STUN
│   └── storage/        # 离线消息 + 历史
├── client.py           # 客户端
├── server.py           # 服务器
├── setup.py            # pip 包
└── .github/workflows/  # CI/CD
```

## 参与贡献

欢迎提交 Issue 和 PR！

## 许可证

MIT License
