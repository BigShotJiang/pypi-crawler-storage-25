from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="wenyuanqixu",
    version="1.0.0",
    author="文元启序",
    author_email="agent@wenyuanqixu.org",
    description="文元启序 - Agent 通用去中心化通信协议",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/wenyuanqixu/agent-p2p",
    packages=["wenyuanqixu", "wenyuanqixu.crypto", "wenyuanqixu.identity", "wenyuanqixu.network", "wenyuanqixu.protocol", "wenyuanqixu.storage"],
    package_dir={"wenyuanqixu": "src"},
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "cryptography>=42.0.0",
        "zeroconf>=0.130.0",
        "kademlia>=2.2.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "dev": ["pytest", "pytest-asyncio"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Communications",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    entry_points={
        "console_scripts": [
            "wenyuanqixu=main:main",
            "agent-p2p=main:main",
        ],
    },
)
