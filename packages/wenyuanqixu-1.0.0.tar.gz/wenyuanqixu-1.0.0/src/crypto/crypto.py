"""
加密模块 - Ed25519 签名 + AES-256-GCM 内容加密
"""
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


class MessageCrypto:
    """消息加解密工具"""

    @staticmethod
    def generate_nonce() -> bytes:
        """生成 96-bit nonce（AES-GCM 标准）"""
        return os.urandom(12)

    @staticmethod
    def derive_shared_key(private_key: Ed25519PrivateKey, peer_public_key: Ed25519PublicKey) -> bytes:
        """
        从双方密钥派生共享密钥
        注意：Ed25519 不直接支持 ECDH，这里用 X25519 转换
        """
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, PrivateFormat, NoEncryption

        # Ed25519 -> X25519 转换
        priv_bytes = private_key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        pub_bytes = peer_public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)

        x25519_priv = X25519PrivateKey.from_private_bytes(priv_bytes)

        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
        x25519_pub = X25519PublicKey.from_public_bytes(pub_bytes)

        shared = x25519_priv.exchange(x25519_pub)

        # HKDF 派生 256-bit 密钥
        derived = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"agent-p2p-session-key",
        ).derive(shared)

        return derived

    @staticmethod
    def encrypt(plaintext: bytes, key: bytes) -> tuple[bytes, bytes]:
        """
        AES-256-GCM 加密
        返回: (nonce, ciphertext)
        """
        nonce = MessageCrypto.generate_nonce()
        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)
        return nonce, ciphertext

    @staticmethod
    def decrypt(nonce: bytes, ciphertext: bytes, key: bytes) -> bytes:
        """
        AES-256-GCM 解密
        返回: plaintext
        """
        aesgcm = AESGCM(key)
        return aesgcm.decrypt(nonce, ciphertext, None)

    @staticmethod
    def encrypt_with_password(plaintext: bytes, password: str) -> bytes:
        """用密码加密（用于本地存储私钥等）"""
        key = hashlib.sha256(password.encode()).digest()
        nonce, ciphertext = MessageCrypto.encrypt(plaintext, key)
        return nonce + ciphertext

    @staticmethod
    def decrypt_with_password(data: bytes, password: str) -> bytes:
        """用密码解密"""
        import hashlib
        key = hashlib.sha256(password.encode()).digest()
        nonce, ciphertext = data[:12], data[12:]
        return MessageCrypto.decrypt(nonce, ciphertext, key)
