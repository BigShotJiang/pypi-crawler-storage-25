"""
会话加密模块 - 端到端加密信道
握手后用 X25519 协商会话密钥，后续消息全部 AES-256-GCM 加密
"""
import os
import hashlib
import logging
import time as time_module
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization

logger = logging.getLogger(__name__)


@dataclass
class SessionKey:
    """会话密钥"""
    send_key: bytes
    recv_key: bytes
    nonce_counter: int = 0
    msg_count: int = 0       # #1 用于密钥轮换计数
    created_at: float = 0.0

    def __post_init__(self):
        if not self.created_at:
            self.created_at = time_module.time()

    @property
    def key_size(self):
        return len(self.send_key) * 8

    def needs_rotation(self, max_msgs=100, max_age=3600) -> bool:
        """#1 是否需要轮换密钥"""
        if self.msg_count >= max_msgs:
            return True
        if time_module.time() - self.created_at >= max_age:
            return True
        return False


class SessionCrypto:
    """会话加密管理器"""

    def __init__(self, ed25519_private_key: Ed25519PrivateKey):
        self._ed25519_priv = ed25519_private_key
        # Ed25519 → X25519 转换
        priv_bytes = ed25519_private_key.private_bytes(
            serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
            serialization.NoEncryption()
        )
        self._x25519_priv = X25519PrivateKey.from_private_bytes(priv_bytes)
        self._x25519_pub = self._x25519_priv.public_key()
        self._sessions: dict[str, SessionKey] = {}  # peer_did -> session

    def get_public_bytes(self) -> bytes:
        """获取 X25519 公钥字节（用于交换）"""
        return self._x25519_pub.public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )

    def establish_session(self, peer_did: str, peer_x25519_pub_bytes: bytes, is_initiator: bool = True) -> SessionKey:
        """用对方 X25519 公钥建立会话密钥
        is_initiator: 是否是发起方（connect 那边）
        """
        peer_pub = X25519PublicKey.from_public_bytes(peer_x25519_pub_bytes)
        shared = self._x25519_priv.exchange(peer_pub)

        # HKDF 派生会话密钥
        session_key = HKDF(
            algorithm=hashes.SHA256(), length=32,
            salt=None, info=b"agent-p2p-session-v1"
        ).derive(shared)

        # 双方使用同一密钥（X25519 ECDH 保证双方得到相同 shared secret）
        session = SessionKey(send_key=session_key, recv_key=session_key)
        self._sessions[peer_did] = session
        logger.info(f"会话已建立: {peer_did[:25]}... (AES-256-GCM)")
        return session

    def encrypt(self, peer_did: str, plaintext: bytes) -> bytes:
        """加密消息"""
        session = self._sessions.get(peer_did)
        if not session:
            raise ValueError(f"未建立会话: {peer_did}")

        nonce = os.urandom(12)
        aesgcm = AESGCM(session.send_key)
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)
        return nonce + ciphertext  # 12字节 nonce + 密文

    def decrypt(self, peer_did: str, data: bytes) -> bytes:
        """解密消息"""
        session = self._sessions.get(peer_did)
        if not session:
            raise ValueError(f"未建立会话: {peer_did}")

        nonce, ciphertext = data[:12], data[12:]
        aesgcm = AESGCM(session.recv_key)
        return aesgcm.decrypt(nonce, ciphertext, None)

    def has_session(self, peer_did: str) -> bool:
        return peer_did in self._sessions

    def remove_session(self, peer_did: str):
        self._sessions.pop(peer_did, None)

    def rotate_session(self, peer_did: str, peer_x25519_pub_bytes: bytes) -> SessionKey:
        """#1 轮换会话密钥"""
        logger.info(f"密钥轮换: {peer_did[:25]}...")
        self.remove_session(peer_did)
        return self.establish_session(peer_did, peer_x25519_pub_bytes)

    def get_content_hash(self, plaintext: bytes) -> str:
        """#2 计算消息内容哈希"""
        return hashlib.sha256(plaintext).hexdigest()

    _revoked: set = None

    @property
    def revoked_dids(self):
        if self._revoked is None:
            self._revoked = set()
        return self._revoked

    def revoke(self, peer_did: str):
        """#3 吊销与某 Agent 的会话"""
        self.remove_session(peer_did)
        self.revoked_dids.add(peer_did)
        logger.warning(f"会话已吊销: {peer_did[:25]}...")

    def is_revoked(self, peer_did: str) -> bool:
        return peer_did in self.revoked_dids
