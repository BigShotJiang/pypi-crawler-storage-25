"""
离线消息存储模块 - SQLite 本地加密存储
"""
import json
import sqlite3
import time
import os
from pathlib import Path
from typing import Optional


class OfflineStorage:
    """离线消息本地加密存储"""

    def __init__(self, db_path: str = "~/.agent-p2p/offline.db"):
        self.db_path = os.path.expanduser(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.row_factory = sqlite3.Row
        self._init_db()

    def _init_db(self):
        # 离线消息
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS offline_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                msg_id TEXT UNIQUE NOT NULL,
                to_did TEXT NOT NULL,
                from_did TEXT NOT NULL,
                encrypted_content TEXT NOT NULL,
                msg_type TEXT DEFAULT 'message',
                created_at REAL NOT NULL,
                status TEXT DEFAULT 'pending',
                retry_count INTEGER DEFAULT 0
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_to_did_status
            ON offline_messages(to_did, status)
        """)
        # #5 消息历史
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS message_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                msg_id TEXT UNIQUE NOT NULL,
                from_did TEXT NOT NULL,
                to_did TEXT NOT NULL,
                msg_type TEXT,
                content TEXT,
                is_encrypted INTEGER DEFAULT 0,
                created_at REAL NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_history_from
            ON message_history(from_did)
        """)
        # #6 群组序号
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS group_sequences (
                group_id TEXT NOT NULL,
                seq INTEGER DEFAULT 0,
                PRIMARY KEY (group_id)
            )
        """)
        self._conn.commit()

    def store(self, msg_id: str, to_did: str, from_did: str,
              encrypted_content: str, msg_type: str = "message") -> bool:
        """存储离线消息"""
        try:
            self._conn.execute("""
                INSERT OR IGNORE INTO offline_messages
                (msg_id, to_did, from_did, encrypted_content, msg_type, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (msg_id, to_did, from_did, encrypted_content, msg_type, time.time()))
            self._conn.commit()
            return True
        except Exception as e:
            print(f"存储离线消息失败: {e}")
            return False

    def get_pending(self, to_did: str) -> list[dict]:
        """获取待推送的离线消息"""
        rows = self._conn.execute("""
            SELECT * FROM offline_messages
            WHERE to_did = ? AND status = 'pending'
            ORDER BY created_at ASC
        """, (to_did,)).fetchall()
        return [dict(r) for r in rows]

    def mark_sent(self, msg_id: str):
        """标记消息已发送"""
        self._conn.execute("""
            UPDATE offline_messages SET status = 'sent' WHERE msg_id = ?
        """, (msg_id,))
        self._conn.commit()

    def mark_acknowledged(self, msg_id: str):
        """标记消息已确认（可删除）"""
        self._conn.execute("""
            DELETE FROM offline_messages WHERE msg_id = ?
        """, (msg_id,))
        self._conn.commit()

    def increment_retry(self, msg_id: str):
        """增加重试次数"""
        self._conn.execute("""
            UPDATE offline_messages SET retry_count = retry_count + 1 WHERE msg_id = ?
        """, (msg_id,))
        self._conn.commit()

    def get_stats(self, to_did: str = None) -> dict:
        """获取存储统计"""
        if to_did:
            row = self._conn.execute("""
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) as pending,
                       SUM(CASE WHEN status='sent' THEN 1 ELSE 0 END) as sent
                FROM offline_messages WHERE to_did = ?
            """, (to_did,)).fetchone()
        else:
            row = self._conn.execute("""
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) as pending,
                       SUM(CASE WHEN status='sent' THEN 1 ELSE 0 END) as sent
                FROM offline_messages
            """).fetchone()
        return dict(row) if row else {"total": 0, "pending": 0, "sent": 0}

    def cleanup_old(self, max_age_hours: int = 168):
        """清理过期消息（默认7天）"""
        cutoff = time.time() - (max_age_hours * 3600)
        self._conn.execute("""
            DELETE FROM offline_messages WHERE created_at < ?
        """, (cutoff,))
        self._conn.commit()

    # #5 消息历史
    def save_message(self, msg_id: str, from_did: str, to_did: str,
                     msg_type: str, content: str, is_encrypted: bool = False):
        """保存收到的消息到历史"""
        try:
            self._conn.execute("""
                INSERT OR IGNORE INTO message_history
                (msg_id, from_did, to_did, msg_type, content, is_encrypted, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (msg_id, from_did, to_did, msg_type, content, int(is_encrypted), time.time()))
            self._conn.commit()
        except Exception:
            pass

    def get_history(self, peer_did: str = None, limit: int = 50) -> list[dict]:
        """获取消息历史"""
        if peer_did:
            rows = self._conn.execute("""
                SELECT * FROM message_history
                WHERE from_did = ? OR to_did = ?
                ORDER BY created_at DESC LIMIT ?
            """, (peer_did, peer_did, limit)).fetchall()
        else:
            rows = self._conn.execute("""
                SELECT * FROM message_history
                ORDER BY created_at DESC LIMIT ?
            """, (limit,)).fetchall()
        return [dict(r) for r in rows]

    # #6 群组序号
    def next_group_seq(self, group_id: str) -> int:
        """获取群组下一条消息序号"""
        row = self._conn.execute(
            "SELECT seq FROM group_sequences WHERE group_id = ?", (group_id,)
        ).fetchone()
        if row:
            new_seq = row[0] + 1
            self._conn.execute(
                "UPDATE group_sequences SET seq = ? WHERE group_id = ?",
                (new_seq, group_id)
            )
        else:
            new_seq = 1
            self._conn.execute(
                "INSERT INTO group_sequences (group_id, seq) VALUES (?, ?)",
                (group_id, new_seq)
            )
        self._conn.commit()
        return new_seq

    def close(self):
        self._conn.close()
