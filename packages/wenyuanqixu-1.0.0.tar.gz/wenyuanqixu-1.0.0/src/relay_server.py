#!/usr/bin/env python3
"""
中继服务器 - 穿透失败时的匿名转发
无状态，不解密，纯比特流转发
"""
import asyncio
import json
import logging
import struct
import sys

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

HEADER_SIZE = 4
MAX_SIZE = 1024 * 1024


class RelayServer:
    """轻量中继服务器"""

    def __init__(self, host: str = "0.0.0.0", port: int = 59300):
        self.host = host
        self.port = port
        self._connections: dict[str, tuple[asyncio.StreamReader, asyncio.StreamWriter]] = {}
        self._agent_map: dict[str, str] = {}  # did -> conn_id

    async def start(self):
        server = await asyncio.start_server(self._handle, self.host, self.port)
        logger.info(f"中继服务器启动: {self.host}:{self.port}")
        async with server:
            await server.serve_forever()

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        peer = writer.get_extra_info('peername')
        conn_id = f"{peer[0]}:{peer[1]}"
        self._connections[conn_id] = (reader, writer)
        logger.info(f"新连接: {conn_id}")

        agent_did = None
        try:
            # 第一条消息必须是注册
            data = await self._recv(reader)
            if not data:
                return

            msg = json.loads(data.decode())
            if msg.get("type") == "relay-register":
                agent_did = msg.get("did")
                self._agent_map[agent_did] = conn_id
                logger.info(f"注册: {agent_did[:30]}...")

                # 回复确认
                await self._send(writer, json.dumps({"type": "relay-ok"}).encode())

            # 中继循环
            while True:
                data = await self._recv(reader)
                if not data:
                    break

                # 解析目标
                try:
                    envelope = json.loads(data.decode())
                    target_did = envelope.get("to")
                    payload = envelope.get("data")

                    if target_did in self._agent_map:
                        target_conn = self._agent_map[target_did]
                        if target_conn in self._connections:
                            _, target_writer = self._connections[target_conn]
                            await self._send(target_writer, payload.encode() if isinstance(payload, str) else payload)
                            logger.debug(f"中继: {agent_did[:10]}... -> {target_did[:10]}...")
                        else:
                            logger.warning(f"目标连接不存在: {target_did[:20]}...")
                    else:
                        logger.warning(f"目标未注册: {target_did[:20]}...")
                except Exception as e:
                    logger.error(f"中继处理失败: {e}")

        except Exception as e:
            logger.debug(f"连接异常: {e}")
        finally:
            if agent_did:
                self._agent_map.pop(agent_did, None)
            self._connections.pop(conn_id, None)
            writer.close()
            try:
                await writer.wait_closed()
            except:
                pass
            logger.info(f"断开: {conn_id}")

    async def _recv(self, reader) -> bytes:
        header = await reader.readexactly(HEADER_SIZE)
        length = struct.unpack('>I', header)[0]
        if length > MAX_SIZE:
            return None
        return await reader.readexactly(length)

    async def _send(self, writer, data: bytes):
        header = struct.pack('>I', len(data))
        writer.write(header + data)
        await writer.drain()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=59300)
    args = parser.parse_args()

    relay = RelayServer(port=args.port)
    asyncio.run(relay.start())
