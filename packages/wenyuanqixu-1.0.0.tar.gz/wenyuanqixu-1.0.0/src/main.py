#!/usr/bin/env python3
"""
Agent P2P 通信系统 - 安全增强版
#1 会话加密 + #2 防重放 + #3 连接认证
"""
import asyncio
import base64
import json
import logging
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from identity.identity import Identity
from protocol.message import Message, MessageType
from protocol.group import GroupManager
from network.transport import P2PServer, P2PClient, P2PConnection
from network.discovery import LocalDiscovery
from network.dht import DHTDiscovery
from network.stun import get_public_address
from storage.offline import OfflineStorage
from crypto.session import SessionCrypto
from protocol.contacts import ContactManager
from protocol.filetransfer import FileHandler
import gzip

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


class Agent:
    """Agent（安全增强版）"""

    def __init__(self, host="0.0.0.0", port=0, identity=None, auto_connect=True, dht_port=0):
        self.identity = identity or Identity()
        self.host, self.port, self.dht_port = host, port, dht_port
        self.auto_connect = auto_connect
        self.server = P2PServer(host, port)
        self.server.on_message(self._handle_incoming)
        self.storage = OfflineStorage()
        self.groups = GroupManager()
        self.contacts = ContactManager()  # #4 联系人
        self.session_crypto = SessionCrypto(self.identity.private_key)
        self.local_discovery = None
        self.dht_discovery = None
        self.public_address = None
        self._pending_ack = {}
        self._received_messages = []
        self._connections = {}
        self._seen_msg_ids = set()  # #2 防重放：已见消息 ID 集合
        self._running = True

    @property
    def did(self):
        return self.identity.did

    async def start(self, enable_local=True, enable_dht=False, local_dht_bootstrap=None):
        self.port = await self.server.start()
        if enable_local:
            self.local_discovery = LocalDiscovery(self.did, self.port)
            self.local_discovery.on_peer_discovered(self._on_peer_found)
            await self.local_discovery.start()
        if enable_dht:
            dp = self.dht_port or (self.port + 1000)
            self.dht_discovery = DHTDiscovery(self.did, self.port, dp)
            await self.dht_discovery.start(local_bootstrap=local_dht_bootstrap or [])
        self.public_address = await get_public_address()
        logger.info(f"Agent 启动: {self.did[:40]}... 端口:{self.port}")

    async def stop(self):
        self._running = False
        if self.local_discovery: await self.local_discovery.stop()
        if self.dht_discovery: await self.dht_discovery.stop()
        for c in list(self._connections.values()): await c.close()
        self.storage.close()
        await self.server.stop()

    async def _on_peer_found(self, peer_did, host, port):
        if self.auto_connect: await self.connect_to(host, port)

    async def _handle_incoming(self, conn):
        await self._recv_loop(conn)

    async def _recv_loop(self, conn):
        while conn.is_connected and self._running:
            data = await conn.receive()
            if data is None: break
            await self._on_message(conn, data)

    async def connect_to(self, host, port):
        for c in self._connections.values():
            if c.is_connected and c.peer_address == f"{host}:{port}": return True
        conn = await P2PClient.connect(host, port)
        if not conn: return False

        # #1 会话加密 + #3 连接认证：握手时交换 X25519 公钥 + challenge
        challenge = os.urandom(16).hex()
        x25519_pub = self.session_crypto.get_public_bytes().hex()
        hs = Message(
            from_did=self.did, to_did="unknown",
            type=MessageType.HANDSHAKE,
            content=json.dumps({
                "did": self.did, "port": self.port,
                "x25519_pub": x25519_pub,
                "challenge": challenge,
            })
        )
        hs.signature = self.identity.sign(hs.to_signed_bytes()).hex()
        await conn.send(hs.to_json().encode())
        conn._handler_task = asyncio.create_task(self._recv_loop(conn))
        return True

    async def _on_message(self, conn, raw_data):
        try: msg = Message.from_json(raw_data.decode())
        except: return
        if not msg.is_valid(): return

        # #2 防重放
        if msg.msg_id in self._seen_msg_ids:
            if msg.type not in (MessageType.ACK, MessageType.HANDSHAKE):
                logger.debug(f"重放消息已忽略: {msg.msg_id[:8]}")
                return
        self._seen_msg_ids.add(msg.msg_id)

        # #2 拒绝过期消息（5分钟）
        if time.time() - msg.timestamp > 300:
            if msg.type not in (MessageType.ACK, MessageType.HANDSHAKE):
                logger.debug(f"过期消息已忽略: {msg.msg_id[:8]}")
                return

        if msg.type == MessageType.HANDSHAKE:
            await self._handle_handshake(conn, msg); return

        # #1 解密加密消息
        actual_type = msg.type
        actual_content = msg.content
        if msg.type == MessageType.ENCRYPTED:
            try:
                decrypted = self.session_crypto.decrypt(msg.from_did, bytes.fromhex(msg.content))
                # #7 尝试 gzip 解压
                try:
                    decrypted = gzip.decompress(decrypted)
                except:
                    pass
                inner = Message.from_json(decrypted.decode())
                actual_type = inner.type
                actual_content = inner.content
                # 验证内部消息签名
                if inner.signature:
                    pk = self._extract_pubkey(inner.from_did)
                    if pk:
                        if not self.identity.verify(inner.to_signed_bytes(), bytes.fromhex(inner.signature), pk):
                            logger.warning(f"内部签名无效"); return
            except Exception as e:
                logger.warning(f"解密失败: {e}"); return

        # 签名验证（非加密消息）
        if msg.signature and msg.type != MessageType.ENCRYPTED:
            pk = self._extract_pubkey(msg.from_did)
            if pk:
                try:
                    if not self.identity.verify(msg.to_signed_bytes(), bytes.fromhex(msg.signature), pk): return
                except: return

        if msg.type == MessageType.ACK:
            if msg.reply_to in self._pending_ack: self._pending_ack[msg.reply_to].set()
            self.storage.mark_acknowledged(msg.reply_to)
            return

        # 记录消息
        if actual_type == "group_message":
            logger.info(f"📢 群组 [{msg.metadata.get('group_name','')}] {msg.from_did[:15]}...: {actual_content}")
        else:
            tag = "🔐" if msg.type == MessageType.ENCRYPTED else "📨"
            logger.info(f"{tag} [{actual_type}] {msg.from_did[:20]}...: {actual_content}")

        self._received_messages.append(msg)

        # 自动回复（服务器模式）
        if actual_type == "message":
            reply = f"✅ 收到: {actual_content[:50]}"
            asyncio.create_task(self.send_message(msg.from_did, reply, wait_ack=False))

        # #5 持久化消息
        is_enc = msg.type == MessageType.ENCRYPTED
        self.storage.save_message(msg.msg_id, msg.from_did, self.did,
                                  actual_type, actual_content, is_enc)

        # ACK
        ack = Message(from_did=self.did, to_did=msg.from_did, type=MessageType.ACK,
                      reply_to=msg.msg_id, content="ok")
        ack.signature = self.identity.sign(ack.to_signed_bytes()).hex()
        await conn.send(ack.to_json().encode())

    async def _handle_handshake(self, conn, msg):
        try:
            info = json.loads(msg.content)
            peer = info["did"]

            # #1 建立会话密钥
            peer_x25519 = info.get("x25519_pub")
            if peer_x25519:
                self.session_crypto.establish_session(peer, bytes.fromhex(peer_x25519), is_initiator=conn.is_client)

            if peer in self._connections and self._connections[peer].is_connected:
                return
            self._connections[peer] = conn
            logger.info(f"🤝 握手: {peer[:25]}... (加密信道已建立)")

            if not conn.is_client:
                # #3 返回 challenge response + 自己的公钥
                challenge_resp = info.get("challenge", "")
                reply = Message(
                    from_did=self.did, to_did=peer, type=MessageType.HANDSHAKE,
                    content=json.dumps({
                        "did": self.did, "port": self.port,
                        "x25519_pub": self.session_crypto.get_public_bytes().hex(),
                        "challenge": os.urandom(16).hex(),
                        "challenge_resp": challenge_resp,  # #3 回显对方的 challenge
                    })
                )
                reply.signature = self.identity.sign(reply.to_signed_bytes()).hex()
                await conn.send(reply.to_json().encode())

            await self.flush_offline(peer)
        except Exception as e:
            logger.error(f"握手失败: {e}")

    def _extract_pubkey(self, did):
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            raw = self._b58decode(did.replace("did:key:z", ""))
            return Ed25519PublicKey.from_public_bytes(raw[2:])
        except: return None

    @staticmethod
    def _b58decode(s):
        a = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        n = 0
        for c in s: n = n * 58 + a.index(c)
        r = n.to_bytes((n.bit_length()+7)//8, 'big') if n > 0 else b''
        return b'\x00' * (len(s) - len(s.lstrip('1'))) + r

    def _make_send_msg(self, to_did, content, msg_type=MessageType.MESSAGE, metadata=None):
        """构造消息，自动加密"""
        inner = Message(from_did=self.did, to_did=to_did, type=msg_type, content=content, metadata=metadata or {})
        inner.signature = self.identity.sign(inner.to_signed_bytes()).hex()

        # #1 如果有会话密钥，加密整个内部消息
        if self.session_crypto.has_session(to_did):
            raw = inner.to_json().encode()
            if len(raw) > 512:
                raw = gzip.compress(raw)
            encrypted = self.session_crypto.encrypt(to_did, raw)
            outer = Message(from_did=self.did, to_did=to_did, type=MessageType.ENCRYPTED,
                           content=encrypted.hex(), metadata=metadata or {})
            outer.signature = self.identity.sign(outer.to_signed_bytes()).hex()
            return outer
        return inner

    async def send_message(self, to_did, content, msg_type=MessageType.MESSAGE, wait_ack=True, metadata=None):
        msg = self._make_send_msg(to_did, content, msg_type, metadata)
        conn = self._connections.get(to_did)
        if conn and conn.is_connected:
            if not await conn.send(msg.to_json().encode()): return False
            tag = "🔐" if msg.type == MessageType.ENCRYPTED else "📨"
            logger.info(f"{tag} 已发送 -> {to_did[:20]}...: {content}")
        else:
            self.storage.store(msg.msg_id, to_did, self.did, content, msg_type)
            return True
        if wait_ack:
            ev = asyncio.Event()
            self._pending_ack[msg.msg_id] = ev
            try:
                await asyncio.wait_for(ev.wait(), timeout=10); return True
            except asyncio.TimeoutError:
                self.storage.store(msg.msg_id, to_did, self.did, content, msg_type); return False
            finally:
                self._pending_ack.pop(msg.msg_id, None)
        return True

    async def send_group_message(self, group_id, content):
        group = self.groups.get(group_id)
        if not group: return
        # #6 群组序号
        seq = self.storage.next_group_seq(group_id)
        members = self.groups.get_member_dids(group_id, exclude=self.did)
        logger.info(f"📢 群组 → {group.name} #{seq} ({len(members)} 人)")
        for m in members:
            await self.send_message(m, content, msg_type="group_message", wait_ack=False,
                                   metadata={"group_id": group_id, "group_name": group.name, "seq": seq})

    async def send_file(self, to_did, filepath):
        """#8 发送文件"""
        chunks = FileHandler.prepare_send(filepath)
        logger.info(f"📎 发送文件: {os.path.basename(filepath)} ({len(chunks)} 块)")
        for chunk in chunks:
            msg = self._make_send_msg(to_did, json.dumps(chunk), MessageType.FILE_CHUNK)
            conn = self._connections.get(to_did)
            if conn and conn.is_connected:
                await conn.send(msg.to_json().encode())
            await asyncio.sleep(0.01)
        logger.info(f"📎 文件发送完成: {os.path.basename(filepath)}")

    async def flush_offline(self, to_did):
        pending = self.storage.get_pending(to_did)
        conn = self._connections.get(to_did)
        if not conn or not conn.is_connected or not pending: return
        for item in pending:
            m = self._make_send_msg(to_did, item["encrypted_content"], item["msg_type"])
            if await conn.send(m.to_json().encode()): self.storage.mark_sent(item["msg_id"])


async def full_demo():
    print("\n" + "=" * 60)
    print("  Agent P2P - 安全增强版测试")
    print("=" * 60 + "\n")

    a = Agent(port=9800)
    b = Agent(port=9801)
    c = Agent(port=9802)

    await a.start()
    await b.start()
    await c.start()
    await asyncio.sleep(3)

    print(f"A: {a.did[:45]}...")
    print(f"B: {b.did[:45]}...")
    print(f"C: {c.did[:45]}...\n")

    # 1. 加密消息测试
    print("=== 1. 端到端加密消息 ===")
    for name, agent in [("A", a), ("B", b), ("C", c)]:
        for peer in list(agent._connections.keys())[:1]:
            await agent.send_message(peer, f"来自 {name} 的加密消息 🔐")
            await asyncio.sleep(0.3)

    # 2. 群组
    print("\n=== 2. 加密群组消息 ===")
    group = a.groups.create("安全群组", a.did)
    from protocol.group import Group as G
    for agent in [b, c]:
        a.groups.add_member(group.group_id, agent.did, a.did)
        agent.groups._groups[group.group_id] = G.from_dict(group.to_dict())
    await a.send_group_message(group.group_id, "群组加密消息测试 🔐📢")
    await asyncio.sleep(0.5)

    # 3. 防重放
    print("\n=== 3. 防重放 ===")
    print(f"已记录 {len(a._seen_msg_ids)} 个消息 ID 防重放")

    # 4. 联系人
    print("\n=== 4. 联系人 ===")
    a.contacts.add(b.did, "Agent B", trusted=True)
    a.contacts.add(c.did, "Agent C", trusted=False)
    print(f"A 的联系人: {a.contacts.count} 个 (可信: {len(a.contacts.list_all(trusted_only=True))})")

    # 5. 消息历史
    print("\n=== 5. 消息历史 ===")
    history = b.storage.get_history(limit=10)
    print(f"B 的历史消息: {len(history)} 条")

    # 6. 群组序号
    print("\n=== 6. 群组序号 ===")
    await a.send_group_message(group.group_id, "第二条群消息")
    await a.send_group_message(group.group_id, "第三条群消息")
    await asyncio.sleep(0.5)

    # 7. 压缩（自动，大消息 >512 字节自动 gzip）
    print("\n=== 7. 消息压缩 ===")
    big_msg = "大消息" * 200  # 1000+ 字节
    await a.send_message(list(a._connections.keys())[0], big_msg)
    await asyncio.sleep(0.3)
    print(f"大消息已压缩发送 ({len(big_msg)} 字节)")

    # 8. 文件传输
    print("\n=== 8. 文件传输 ===")
    test_file = "/tmp/test_agent_file.txt"
    with open(test_file, 'w') as f:
        f.write("Hello Agent P2P! 这是文件传输测试内容。" * 50)
    await a.send_file(list(a._connections.keys())[0], test_file)
    await asyncio.sleep(0.5)

    # 9. 离线
    print("\n=== 9. 离线存储 ===")
    d = Agent(port=9803)
    await d.start()
    await a.send_message(d.did, "离线加密消息", wait_ack=False)
    stats = a.storage.get_stats()
    print(f"离线待发: {stats['total']} 条")

    print(f"\n{'=' * 60}")
    for name, agent in [('A', a), ('B', b), ('C', c)]:
        hist = agent.storage.get_history(limit=100)
        print(f"✅ {name}: {len(agent._received_messages)} 收 | {len(agent._connections)} 连接 | 会话:{len(agent.session_crypto._sessions)} | 历史:{len(hist)}")
    print(f"{'=' * 60}\n")

    for agent in [a, b, c, d]:
        await agent.stop()


if __name__ == "__main__":
    asyncio.run(full_demo())
