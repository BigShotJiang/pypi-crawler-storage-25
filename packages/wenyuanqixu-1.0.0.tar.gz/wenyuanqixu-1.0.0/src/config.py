"""
配置管理模块
"""
import os
import yaml
import logging
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "agent": {
        "port": 9000,
        "nickname": "",
        "auto_connect": True,
        "enable_local_discovery": True,
        "enable_dht": False,
        "dht_port": 0,
    },
    "network": {
        "dht_bootstrap_nodes": [
            ["router.bittorrent.com", 6881],
            ["router.utorrent.com", 6881],
        ],
        "stun_servers": [
            ["stun.cloudflare.com", 3478],
            ["stun.nextcloud.com", 3478],
        ],
        "discovery_port": 59100,
        "heartbeat_interval": 30,
    },
    "security": {
        "encrypt_private_key": True,
        "key_rotation_msgs": 100,
        "key_rotation_hours": 1,
        "dedup_window_seconds": 300,
        "message_expire_seconds": 300,
    },
    "storage": {
        "db_path": "~/.agent-p2p/data.db",
        "max_history": 10000,
        "cleanup_days": 30,
    },
    "logging": {
        "level": "INFO",
        "file": "~/.agent-p2p/agent.log",
        "max_size_mb": 10,
        "backup_count": 3,
    },
}


class Config:
    """配置管理"""

    def __init__(self, path: str = "~/.agent-p2p/config.yaml"):
        self.path = os.path.expanduser(path)
        self._config = DEFAULT_CONFIG.copy()
        self._load()

    def _load(self):
        try:
            if os.path.exists(self.path):
                with open(self.path) as f:
                    user_config = yaml.safe_load(f) or {}
                self._deep_merge(self._config, user_config)
                logger.info(f"配置已加载: {self.path}")
        except Exception as e:
            logger.warning(f"配置加载失败，使用默认: {e}")

    def _deep_merge(self, base: dict, override: dict):
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value

    def save(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, 'w') as f:
            yaml.dump(self._config, f, default_flow_style=False, allow_unicode=True)

    def get(self, dotpath: str, default=None):
        """用点号路径获取配置，如 get('agent.port')"""
        keys = dotpath.split('.')
        value = self._config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
        return value if value is not None else default

    def set(self, dotpath: str, value):
        """用点号路径设置配置"""
        keys = dotpath.split('.')
        config = self._config
        for k in keys[:-1]:
            config = config.setdefault(k, {})
        config[keys[-1]] = value

    @property
    def agent_port(self):
        return self.get('agent.port', 9000)

    @property
    def agent_nickname(self):
        return self.get('agent.nickname', '')

    @property
    def log_level(self):
        return self.get('logging.level', 'INFO')

    @property
    def log_file(self):
        return os.path.expanduser(self.get('logging.file', '~/.agent-p2p/agent.log'))
