"""
群组通信模块 - 支持多 Agent 群组消息
"""
import json
import time
import uuid
import logging
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Group:
    """群组"""
    group_id: str
    name: str
    creator: str  # 创建者 did
    members: list = field(default_factory=list)
    admins: list = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "group_id": self.group_id,
            "name": self.name,
            "creator": self.creator,
            "members": self.members,
            "admins": self.admins,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> 'Group':
        return cls(**d)


class GroupManager:
    """群组管理器"""

    def __init__(self):
        self._groups: dict[str, Group] = {}

    def create(self, name: str, creator: str) -> Group:
        """创建群组"""
        group_id = f"group-{uuid.uuid4().hex[:8]}"
        group = Group(
            group_id=group_id,
            name=name,
            creator=creator,
            members=[creator],
            admins=[creator],
        )
        self._groups[group_id] = group
        logger.info(f"创建群组: {name} ({group_id})")
        return group

    def get(self, group_id: str) -> Optional[Group]:
        return self._groups.get(group_id)

    def add_member(self, group_id: str, did: str, operator: str) -> bool:
        """添加成员"""
        group = self._groups.get(group_id)
        if not group or operator not in group.admins:
            return False
        if did not in group.members:
            group.members.append(did)
            logger.info(f"群组 {group.name}: {did[:20]}... 已加入")
        return True

    def remove_member(self, group_id: str, did: str, operator: str) -> bool:
        """移除成员"""
        group = self._groups.get(group_id)
        if not group or operator not in group.admins:
            return False
        if did in group.members:
            group.members.remove(did)
            return True
        return False

    @classmethod
    def create_from_dict(cls, d: dict) -> 'GroupManager':
        """从字典创建（用于同步群组信息）"""
        gm = cls()
        group = Group.from_dict(d)
        gm._groups[group.group_id] = group
        return gm

    def list_groups(self, did: str = None) -> list[Group]:
        """列出群组"""
        if did:
            return [g for g in self._groups.values() if did in g.members]
        return list(self._groups.values())

    def get_member_dids(self, group_id: str, exclude: str = None) -> list[str]:
        """获取群组成员（可排除自己）"""
        group = self._groups.get(group_id)
        if not group:
            return []
        members = group.members[:]
        if exclude:
            members = [m for m in members if m != exclude]
        return members
