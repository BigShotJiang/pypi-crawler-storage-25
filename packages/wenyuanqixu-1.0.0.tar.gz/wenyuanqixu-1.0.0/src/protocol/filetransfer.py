"""
文件传输模块 - 支持发送文件/图片
"""
import base64
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class FileTransfer:
    """文件传输"""
    file_id: str
    filename: str
    size: int
    mime_type: str
    sha256: str
    chunks_total: int
    chunks_received: int = 0
    data: bytes = b""
    created_at: float = field(default_factory=time.time)

    @property
    def complete(self):
        return self.chunks_received >= self.chunks_total


class FileHandler:
    """文件处理器"""

    CHUNK_SIZE = 64 * 1024  # 64KB per chunk

    @staticmethod
    def prepare_send(filepath: str) -> list[dict]:
        """准备文件发送：分块 + 计算哈希"""
        if not os.path.exists(filepath):
            raise FileNotFoundError(filepath)

        filename = os.path.basename(filepath)
        size = os.path.getsize(filepath)

        # 猜测 MIME
        ext = os.path.splitext(filename)[1].lower()
        mime_map = {
            ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".png": "image/png", ".gif": "image/gif",
            ".pdf": "application/pdf", ".txt": "text/plain",
            ".mp3": "audio/mpeg", ".mp4": "video/mp4",
            ".zip": "application/zip",
        }
        mime = mime_map.get(ext, "application/octet-stream")

        with open(filepath, "rb") as f:
            raw = f.read()

        sha256 = hashlib.sha256(raw).hexdigest()
        file_id = f"file-{sha256[:12]}"

        # 分块
        chunks = []
        total = (size + FileHandler.CHUNK_SIZE - 1) // FileHandler.CHUNK_SIZE
        for i in range(total):
            start = i * FileHandler.CHUNK_SIZE
            end = min(start + FileHandler.CHUNK_SIZE, size)
            chunk_data = base64.b64encode(raw[start:end]).decode()
            chunks.append({
                "type": "file_chunk",
                "file_id": file_id,
                "filename": filename,
                "mime": mime,
                "size": size,
                "sha256": sha256,
                "chunk_index": i,
                "chunks_total": total,
                "data": chunk_data,
            })
        return chunks

    @staticmethod
    def receive_chunk(transfers: dict, chunk: dict) -> Optional[bytes]:
        """接收文件块，返回完整文件数据（接收完毕时）"""
        file_id = chunk["file_id"]

        if file_id not in transfers:
            transfers[file_id] = FileTransfer(
                file_id=file_id,
                filename=chunk["filename"],
                size=chunk["size"],
                mime_type=chunk["mime"],
                sha256=chunk["sha256"],
                chunks_total=chunk["chunks_total"],
            )

        ft = transfers[file_id]
        data = base64.b64decode(chunk["data"])
        ft.data += data
        ft.chunks_received += 1

        if ft.complete:
            # 验证哈希
            actual_hash = hashlib.sha256(ft.data).hexdigest()
            if actual_hash != ft.sha256:
                raise ValueError(f"文件校验失败: {ft.filename}")
            return ft.data
        return None
