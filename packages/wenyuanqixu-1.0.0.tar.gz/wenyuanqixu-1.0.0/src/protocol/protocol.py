"""
协议辅助模块 - 版本、能力、心跳、错误
"""
import json
import time
from protocol.message import Message, MessageType, PROTOCOL_VERSION


# 标准能力定义
STANDARD_CAPABILITIES = {
    "message": "基础消息",
    "file_transfer": "文件传输",
    "group": "群组通信",
    "heartbeat": "心跳保活",
    "encryption": "端到端加密",
    "compression": "消息压缩",
}


def build_capability_msg(from_did: str, to_did: str,
                         supported: list[str] = None,
                         extra: dict = None) -> dict:
    """构建能力声明消息"""
    supported = supported or list(STANDARD_CAPABILITIES.keys())
    caps = {k: (k in supported) for k in STANDARD_CAPABILITIES}
    if extra:
        caps.update(extra)
    caps["protocol_version"] = PROTOCOL_VERSION

    return {
        "type": MessageType.CAPABILITY,
        "from": from_did,
        "to": to_did,
        "content": json.dumps(caps),
        "timestamp": time.time(),
    }


def build_heartbeat_msg(from_did: str, to_did: str,
                        uptime: float = 0, connections: int = 0,
                        load: float = 0) -> Message:
    """构建心跳消息"""
    return Message(
        from_did=from_did,
        to_did=to_did,
        type=MessageType.HEARTBEAT,
        content="",
        metadata={
            "uptime": round(uptime, 1),
            "connections": connections,
            "load": round(load, 2),
            "protocol_version": PROTOCOL_VERSION,
        }
    )


def build_error_msg(from_did: str, to_did: str,
                    error_code: str, error_detail: str,
                    reply_to: str = "") -> Message:
    """构建错误消息"""
    return Message(
        from_did=from_did,
        to_did=to_did,
        type=MessageType.ERROR_MSG,
        content=error_detail,
        reply_to=reply_to,
        metadata={"error_code": error_code}
    )


# 标准错误码
class ErrorCodes:
    INVALID_FORMAT = "INVALID_FORMAT"
    INVALID_SIGNATURE = "INVALID_SIGNATURE"
    DECRYPT_FAILED = "DECRYPT_FAILED"
    UNSUPPORTED_TYPE = "UNSUPPORTED_TYPE"
    RATE_LIMITED = "RATE_LIMITED"
    SESSION_EXPIRED = "SESSION_EXPIRED"
    NOT_FOUND = "NOT_FOUND"


def check_version_compatibility(local: str, remote: str) -> tuple[bool, str]:
    """检查版本兼容性"""
    local_major = int(local.split(".")[0])
    remote_major = int(remote.split(".")[0])

    if local_major != remote_major:
        return False, f"版本不兼容: local={local}, remote={remote}"

    local_minor = int(local.split(".")[1])
    remote_minor = int(remote.split(".")[1])
    negotiated = f"{local_major}.{min(local_minor, remote_minor)}"

    return True, negotiated
