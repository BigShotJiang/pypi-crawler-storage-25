"""
消息协议模块 - 标准化 JSON 消息格式
"""
import json
import time
import uuid
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import Optional


class MessageType(str, Enum):
    """消息类型"""
    MESSAGE = "message"
    REQUEST = "request"
    RESPONSE = "response"
    EVENT = "event"
    CALL = "call"
    CALL_ACCEPT = "call_accept"
    CALL_REJECT = "call_reject"
    ACK = "ack"
    HEARTBEAT = "heartbeat"
    HANDSHAKE = "handshake"       # 握手（含 X25519 公钥交换）
    ENCRYPTED = "encrypted"       # 加密消息
    FILE_CHUNK = "file_chunk"     # #8 文件块
    CAPABILITY = "capability"     # 能力声明
    ERROR_MSG = "error"           # 错误消息


PROTOCOL_VERSION = "文元启序 1.0"


@dataclass
class Message:
    """文元启序 1.0 标准消息格式"""
    msg_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    from_did: str = ""
    to_did: str = ""
    timestamp: float = field(default_factory=time.time)
    content: str = ""
    signature: str = ""       # hex 编码的签名
    type: str = MessageType.MESSAGE
    reply_to: str = ""        # 回复的消息 ID
    metadata: dict = field(default_factory=dict)
    version: str = PROTOCOL_VERSION
    signature_alg: str = "ed25519"  # #3 签名算法锁定
    seq: int = 0             # #2 序列号
    expires: float = 0.0     # #4 过期时间（0=不过期）
    fragment_index: int = 0  # #1 分片索引
    fragment_total: int = 1  # #1 总分片数（1=未分片）

    def to_bytes(self) -> bytes:
        """序列化为 JSON bytes（不含签名）"""
        data = asdict(self)
        # 签名时不包含 signature 字段
        data["signature"] = ""
        return json.dumps(data, ensure_ascii=False).encode()

    def to_json(self) -> str:
        """转为 JSON 字符串"""
        return json.dumps(asdict(self), ensure_ascii=False)

    def to_signed_bytes(self) -> bytes:
        """用于签名的字节（msg_id + from + to + timestamp + content + type）"""
        sign_data = f"{self.msg_id}|{self.from_did}|{self.to_did}|{self.timestamp}|{self.content}|{self.type}"
        return sign_data.encode()

    @classmethod
    def from_json(cls, data: str) -> 'Message':
        """从 JSON 字符串解析"""
        d = json.loads(data)
        return cls(
            msg_id=d.get("msg_id", str(uuid.uuid4())),
            from_did=d.get("from_did", ""),
            to_did=d.get("to_did", ""),
            timestamp=d.get("timestamp", time.time()),
            content=d.get("content", ""),
            signature=d.get("signature", ""),
            type=d.get("type", MessageType.MESSAGE),
            reply_to=d.get("reply_to", ""),
            metadata=d.get("metadata", {}),
        )

    def is_valid(self) -> bool:
        """基础格式校验"""
        return bool(self.msg_id and self.from_did and self.to_did and self.type)
