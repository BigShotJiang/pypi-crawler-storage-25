"""
联系人/好友管理模块
"""
import json
import os
import time
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class Contact:
    did: str
    name: str = ""
    trusted: bool = False
    added_at: float = field(default_factory=time.time)


class ContactManager:
    """联系人管理器"""

    def __init__(self, path: str = "~/.agent-p2p/contacts.json"):
        self.path = os.path.expanduser(path)
        self._contacts: dict[str, Contact] = {}
        self._load()

    def _load(self):
        try:
            if os.path.exists(self.path):
                with open(self.path) as f:
                    data = json.load(f)
                for did, info in data.items():
                    self._contacts[did] = Contact(did=did, **info)
        except:
            pass

    def _save(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        data = {}
        for did, c in self._contacts.items():
            data[did] = {"name": c.name, "trusted": c.trusted, "added_at": c.added_at}
        with open(self.path, 'w') as f:
            json.dump(data, f, indent=2)

    def add(self, did: str, name: str = "", trusted: bool = False):
        self._contacts[did] = Contact(did=did, name=name, trusted=trusted)
        self._save()

    def remove(self, did: str):
        self._contacts.pop(did, None)
        self._save()

    def get(self, did: str) -> Optional[Contact]:
        return self._contacts.get(did)

    def is_trusted(self, did: str) -> bool:
        c = self._contacts.get(did)
        return c.trusted if c else False

    def list_all(self, trusted_only: bool = False) -> list[Contact]:
        if trusted_only:
            return [c for c in self._contacts.values() if c.trusted]
        return list(self._contacts.values())

    @property
    def count(self):
        return len(self._contacts)
