"""
事件系统 - Agent 消息回调装饰器
用法:
    @agent.on("message")
    async def handle_message(msg):
        print(msg.content)

    @agent.on("connected")
    async def on_connect(peer_did):
        print(f"已连接: {peer_did}")
"""
import asyncio
import logging
from typing import Callable, Any
from functools import wraps

logger = logging.getLogger(__name__)


class EventEmitter:
    """事件发射器"""

    def __init__(self):
        self._handlers: dict[str, list[Callable]] = {}

    def on(self, event: str, handler: Callable = None):
        """注册事件处理器（可用作装饰器）"""
        def decorator(fn):
            if event not in self._handlers:
                self._handlers[event] = []
            self._handlers[event].append(fn)
            return fn

        if handler is not None:
            return decorator(handler)
        return decorator

    def off(self, event: str, handler: Callable):
        """移除事件处理器"""
        if event in self._handlers:
            self._handlers[event] = [h for h in self._handlers[event] if h != handler]

    async def emit(self, event: str, *args, **kwargs):
        """触发事件"""
        handlers = self._handlers.get(event, [])
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(*args, **kwargs)
                else:
                    handler(*args, **kwargs)
            except Exception as e:
                logger.error(f"事件处理异常 [{event}]: {e}")

    def once(self, event: str, handler: Callable = None):
        """只触发一次的事件"""
        def decorator(fn):
            async def wrapper(*args, **kwargs):
                self.off(event, wrapper)
                if asyncio.iscoroutinefunction(fn):
                    await fn(*args, **kwargs)
                else:
                    fn(*args, **kwargs)
            wrapper._original = fn
            return self.on(event, wrapper)

        if handler is not None:
            return decorator(handler)
        return decorator

    @property
    def events(self):
        return list(self._handlers.keys())

    def listener_count(self, event: str):
        return len(self._handlers.get(event, []))
