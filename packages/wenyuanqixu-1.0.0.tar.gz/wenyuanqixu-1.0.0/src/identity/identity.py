"""
身份模块 - did:key 去中心化身份
基于 Ed25519 密钥对生成 W3C did:key 标识符
"""
import base64
import hashlib
import json
import os
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization


class Identity:
    """Agent 去中心化身份"""

    def __init__(self, private_key: Ed25519PrivateKey = None):
        if private_key is None:
            private_key = Ed25519PrivateKey.generate()
        self._private_key = private_key
        self._public_key = private_key.public_key()
        self._did = self._generate_did()

    @property
    def did(self) -> str:
        """获取 did:key 身份号码"""
        return self._did

    @property
    def private_key(self) -> Ed25519PrivateKey:
        return self._private_key

    @property
    def public_key(self):
        return self._public_key

    def _generate_did(self) -> str:
        """从公钥生成 did:key 标识符"""
        pub_bytes = self._public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        # Ed25519 公钥 multicodec 前缀: 0xed 0x01
        multicodec_pub = b'\xed\x01' + pub_bytes
        # Base58btc 编码 (用 base58 手动实现)
        encoded = self._base58btc(multicodec_pub)
        return f"did:key:z{encoded}"

    @staticmethod
    def _base58btc(data: bytes) -> str:
        """Base58btc 编码"""
        alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        num = int.from_bytes(data, 'big')
        encoded = ''
        while num > 0:
            num, remainder = divmod(num, 58)
            encoded = alphabet[remainder] + encoded
        # 处理前导零字节
        for byte in data:
            if byte == 0:
                encoded = '1' + encoded
            else:
                break
        return encoded

    def sign(self, message: bytes) -> bytes:
        """使用私钥对消息签名"""
        return self._private_key.sign(message)

    def verify(self, message: bytes, signature: bytes, public_key=None) -> bool:
        """验证签名"""
        pk = public_key or self._public_key
        try:
            pk.verify(signature, message)
            return True
        except Exception:
            return False

    @staticmethod
    def did_to_sha1(did: str) -> bytes:
        """将 did:key 转换为 SHA-1 哈希（DHT 160bit key）"""
        return hashlib.sha1(did.encode()).digest()

    def save(self, filepath: str):
        """保存身份到本地文件（加密存储）"""
        private_bytes = self._private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        data = {
            "did": self._did,
            "private_key": private_bytes.decode()
        }
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(filepath, 0o600)

    @classmethod
    def load(cls, filepath: str) -> 'Identity':
        """从本地文件加载身份"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        private_key = serialization.load_pem_private_key(
            data["private_key"].encode(), password=None
        )
        return cls(private_key)
