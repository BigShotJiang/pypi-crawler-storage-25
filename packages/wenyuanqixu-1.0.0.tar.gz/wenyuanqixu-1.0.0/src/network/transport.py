"""
网络传输模块 - TCP 直连 + 消息帧协议（修复版）
"""
import asyncio
import json
import struct
import logging
from typing import Callable, Optional

logger = logging.getLogger(__name__)

HEADER_SIZE = 4
MAX_MESSAGE_SIZE = 1024 * 1024  # 1MB


class P2PConnection:
    """P2P 连接封装"""

    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, peer_address: str = ""):
        self.reader = reader
        self.writer = writer
        self.peer_address = peer_address
        self.is_connected = True
        self.is_client = False  # 是否客户端发起的连接
        self._handler_task = None

    async def send(self, data: bytes) -> bool:
        if not self.is_connected:
            return False
        try:
            header = struct.pack('>I', len(data))
            self.writer.write(header + data)
            await self.writer.drain()
            return True
        except Exception as e:
            logger.error(f"发送失败: {e}")
            self.is_connected = False
            return False

    async def receive(self) -> Optional[bytes]:
        if not self.is_connected:
            return None
        try:
            header = await self.reader.readexactly(HEADER_SIZE)
            length = struct.unpack('>I', header)[0]
            if length > MAX_MESSAGE_SIZE:
                logger.error(f"消息过大: {length} bytes")
                return None
            data = await self.reader.readexactly(length)
            return data
        except asyncio.IncompleteReadError:
            self.is_connected = False
            return None
        except Exception as e:
            logger.error(f"接收失败: {e}")
            self.is_connected = False
            return None

    async def close(self):
        self.is_connected = False
        if self._handler_task and not self._handler_task.done():
            self._handler_task.cancel()
        try:
            if not self.writer.is_closing():
                self.writer.close()
                await self.writer.wait_closed()
        except Exception:
            pass


class P2PServer:
    """P2P TCP 服务器"""

    def __init__(self, host: str = "0.0.0.0", port: int = 0):
        self.host = host
        self.port = port
        self._server = None
        self._handler: Optional[Callable] = None

    def on_message(self, handler: Callable):
        self._handler = handler

    async def start(self) -> int:
        self._server = await asyncio.start_server(
            self._handle_connection, self.host, self.port
        )
        actual_port = self._server.sockets[0].getsockname()[1]
        logger.info(f"TCP 服务器启动: {self.host}:{actual_port}")
        return actual_port

    async def _handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """仅服务端接受的连接走这里"""
        peer = writer.get_extra_info('peername')
        peer_addr = f"{peer[0]}:{peer[1]}" if peer else "unknown"
        conn = P2PConnection(reader, writer, peer_addr)
        logger.info(f"服务端接受连接: {peer_addr}")
        if self._handler:
            await self._handler(conn)

    async def stop(self):
        if self._server:
            self._server.close()
            await self._server.wait_closed()


class P2PClient:
    """P2P TCP 客户端"""

    @staticmethod
    async def connect(host: str, port: int, timeout: float = 10) -> Optional[P2PConnection]:
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=timeout
            )
            addr = f"{host}:{port}"
            logger.info(f"客户端已连接: {addr}")
            conn = P2PConnection(reader, writer, addr)
            conn.is_client = True
            return conn
        except Exception as e:
            logger.error(f"连接失败 {host}:{port}: {e}")
            return None
