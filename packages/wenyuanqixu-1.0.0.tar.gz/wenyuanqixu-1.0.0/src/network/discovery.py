"""
局域网发现模块 - UDP 广播发现（修复版）
"""
import asyncio
import json
import logging
import socket
from typing import Callable, Optional

logger = logging.getLogger(__name__)

DISCOVERY_PORT = 59100
BROADCAST_INTERVAL = 1  # 每秒广播，更快发现


class LocalDiscovery:
    """局域网 UDP 发现"""

    def __init__(self, agent_did: str, port: int):
        self.agent_did = agent_did
        self.port = port
        self._discovered: dict[str, dict] = {}
        self._on_discovered: Optional[Callable] = None
        self._running = True

    def on_peer_discovered(self, callback: Callable):
        self._on_discovered = callback

    @property
    def peers(self) -> dict[str, dict]:
        return self._discovered.copy()

    def _get_local_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    async def start(self):
        local_ip = self._get_local_ip()

        # 监听 socket
        listen_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listen_sock.setblocking(False)
        listen_sock.bind(("0.0.0.0", DISCOVERY_PORT))

        # 发送 socket
        send_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        send_sock.setblocking(False)

        announce = json.dumps({
            "did": self.agent_did,
            "host": local_ip,
            "port": self.port,
        }).encode()

        # 广播目标列表（loopback + 本机IP + 广播地址）
        targets = [
            ("127.0.0.1", DISCOVERY_PORT),
            (local_ip, DISCOVERY_PORT),
        ]

        self._running = True
        loop = asyncio.get_event_loop()

        async def broadcast_loop():
            import random
            # 首次广播随机延迟
            await asyncio.sleep(random.uniform(0.1, 0.3))
            # 前5秒每秒广播一次（快速发现阶段），之后每2秒广播
            fast_rounds = 5
            for _ in range(fast_rounds):
                if not self._running:
                    return
                for target in targets:
                    try:
                        send_sock.sendto(announce, target)
                    except Exception:
                        pass
                await asyncio.sleep(1)
            # 稳态广播
            while self._running:
                for target in targets:
                    try:
                        send_sock.sendto(announce, target)
                    except Exception:
                        pass
                await asyncio.sleep(BROADCAST_INTERVAL)

        async def listen_loop():
            while self._running:
                try:
                    data = await asyncio.wait_for(
                        loop.sock_recv(listen_sock, 1024), timeout=1.0
                    )
                    msg = json.loads(data.decode())
                    peer_did = msg.get("did")
                    if not peer_did or peer_did == self.agent_did:
                        continue
                    host = msg.get("host", "127.0.0.1")
                    port = msg.get("port", 0)
                    if peer_did not in self._discovered:
                        self._discovered[peer_did] = {"did": peer_did, "host": host, "port": port}
                        logger.info(f"发现 Agent: {peer_did[:25]}... {host}:{port}")
                        if self._on_discovered:
                            await self._on_discovered(peer_did, host, port)
                except asyncio.TimeoutError:
                    continue
                except Exception:
                    pass

        # 先启动监听，等 0.5 秒后再开始广播，确保能收到其他 Agent 的广播
        self._listen_task = asyncio.create_task(listen_loop())
        await asyncio.sleep(0.5)
        self._broadcast_task = asyncio.create_task(broadcast_loop())
        self._send_sock = send_sock
        self._listen_sock = listen_sock

        logger.info(f"UDP 发现启动: {local_ip}:{DISCOVERY_PORT}")

    async def stop(self):
        self._running = False
        for task in [self._broadcast_task, self._listen_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        try:
            self._send_sock.close()
            self._listen_sock.close()
        except Exception:
            pass
