"""
STUN 模块 - 获取公网 IP 和端口
用于 NAT 穿透前的地址发现
"""
import asyncio
import logging
import socket
import struct
import os
from typing import Optional

logger = logging.getLogger(__name__)

# STUN 协议常量
STUN_MAGIC_COOKIE = 0x2112A442
STUN_BINDING_REQUEST = 0x0001
STUN_BINDING_RESPONSE = 0x0101

# 公共 STUN 服务器（分布式，非中心化）
STUN_SERVERS = [
    ("stun.cloudflare.com", 3478),
    ("stun.nextcloud.com", 3478),
    ("stun.sipgate.net", 3478),
    ("stun.ekiga.net", 3478),
]


class STUNResult:
    """STUN 查询结果"""

    def __init__(self, public_ip: str, public_port: int, nat_type: str = "unknown"):
        self.public_ip = public_ip
        self.public_port = public_port
        self.nat_type = nat_type

    def __repr__(self):
        return f"STUNResult({self.public_ip}:{self.public_port}, nat={self.nat_type})"


async def get_public_address(servers: list = None, timeout: float = 5) -> Optional[STUNResult]:
    """
    通过 STUN 服务器获取公网地址
    返回: STUNResult 或 None
    """
    servers = servers or STUN_SERVERS
    loop = asyncio.get_event_loop()

    for host, port in servers:
        try:
            result = await asyncio.wait_for(
                _stun_request(host, port, loop),
                timeout=timeout
            )
            if result:
                logger.info(f"STUN 成功: {result.public_ip}:{result.public_port} ({host})")
                return result
        except Exception as e:
            logger.debug(f"STUN 失败 {host}:{port}: {e}")

    logger.warning("所有 STUN 服务器不可用")
    return None


async def _stun_request(host: str, port: int, loop) -> Optional[STUNResult]:
    """发送 STUN Binding Request"""
    # 解析 STUN 服务器地址
    try:
        addr_infos = await loop.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM)
        server_ip = addr_infos[0][4][0]
    except Exception:
        return None

    # 构造 STUN Binding Request
    transaction_id = os.urandom(12)
    message = struct.pack(
        '!HHI',
        STUN_BINDING_REQUEST,  # 消息类型
        0,                      # 消息长度
        STUN_MAGIC_COOKIE       # Magic Cookie
    ) + transaction_id

    # 发送 UDP 请求
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(5)
    try:
        sock.sendto(message, (server_ip, port))
        data, addr = sock.recvfrom(1024)
    finally:
        sock.close()

    # 解析响应
    if len(data) < 20:
        return None

    msg_type, msg_len, magic = struct.unpack('!HHI', data[:8])
    if msg_type != STUN_BINDING_RESPONSE:
        return None

    # 查找 XOR-MAPPED-ADDRESS 属性 (0x0020)
    offset = 20
    while offset < len(data) - 4:
        attr_type, attr_len = struct.unpack('!HH', data[offset:offset + 4])
        if attr_type == 0x0020 and attr_len >= 8:
            # 解析 XOR-MAPPED-ADDRESS
            family = data[offset + 5]
            if family == 0x01:  # IPv4
                xport = struct.unpack('!H', data[offset + 6:offset + 8])[0]
                port = xport ^ (STUN_MAGIC_COOKIE >> 16)
                xaddr = struct.unpack('!I', data[offset + 8:offset + 12])[0]
                ip_int = xaddr ^ STUN_MAGIC_COOKIE
                ip = socket.inet_ntoa(struct.pack('!I', ip_int))
                return STUNResult(ip, port)
        offset += 4 + attr_len
        if attr_len % 4:
            offset += 4 - (attr_len % 4)

    # 尝试 MAPPED-ADDRESS (0x0001)
    offset = 20
    while offset < len(data) - 4:
        attr_type, attr_len = struct.unpack('!HH', data[offset:offset + 4])
        if attr_type == 0x0001 and attr_len >= 8:
            family = data[offset + 5]
            if family == 0x01:
                port = struct.unpack('!H', data[offset + 6:offset + 8])[0]
                ip = socket.inet_ntoa(data[offset + 8:offset + 12])
                return STUNResult(ip, port)
        offset += 4 + attr_len
        if attr_len % 4:
            offset += 4 - (attr_len % 4)

    return None


async def detect_nat_type() -> str:
    """
    简单的 NAT 类型检测
    通过两次 STUN 请求使用不同端口来判断
    """
    result1 = await get_public_address()
    if not result1:
        return "blocked"

    return "cone"  # 简化：只要 STUN 成功就认为是锥形 NAT
