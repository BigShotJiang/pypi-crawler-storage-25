"""
DHT 公网发现模块 - 基于 Kademlia DHT
Agent 上线后将 did:key 哈希→地址 映射存入 DHT 网络
其他 Agent 通过 DHT 查询找到目标
"""
import asyncio
import hashlib
import json
import logging
import socket
from typing import Optional

logger = logging.getLogger(__name__)

# 公共 DHT 引导节点（BitTorrent Mainline 风格）
BOOTSTRAP_NODES = [
    ("router.bittorrent.com", 6881),
    ("router.utorrent.com", 6881),
    ("dht.transmissionbt.com", 6881),
]

DEFAULT_DHT_PORT = 59200


class DHTDiscovery:
    """Kademlia DHT 公网节点发现"""

    def __init__(self, agent_did: str, tcp_port: int, dht_port: int = DEFAULT_DHT_PORT):
        self.agent_did = agent_did
        self.tcp_port = tcp_port
        self.dht_port = dht_port
        self._server = None
        self._running = False

    def _did_to_key(self, did: str) -> bytes:
        """将 did:key 转换为 DHT key（SHA-1 哈希 → 160 bit）"""
        return hashlib.sha1(did.encode()).digest()

    def _get_local_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    async def start(self, bootstrap_nodes: list = None, local_bootstrap: list = None):
        """启动 DHT 节点
        local_bootstrap: 本地引导 [(host, port)]，同一网络 Agent 互 bootstrap
        """
        from kademlia.network import Server

        self._server = Server()
        await self._server.listen(self.dht_port)

        # 合并引导节点（本地优先）
        all_nodes = list(local_bootstrap or []) + list(bootstrap_nodes or BOOTSTRAP_NODES)

        for host, port in all_nodes:
            try:
                await asyncio.wait_for(self._server.bootstrap([(host, port)]), timeout=3)
                logger.info(f"DHT 引导: {host}:{port}")
            except Exception:
                pass

        await asyncio.sleep(0.5)

        # 发布自己
        value = json.dumps({"did": self.agent_did, "host": self._get_local_ip(), "port": self.tcp_port})
        key = self._did_to_key(self.agent_did)
        await self._server.set(key.hex(), value)
        self._running = True
        logger.info(f"DHT 启动: port={self.dht_port}")
        asyncio.create_task(self._refresh_loop())

    async def _refresh_loop(self):
        """定期刷新 DHT 记录"""
        while self._running:
            await asyncio.sleep(900)  # 15 分钟
            try:
                local_ip = self._get_local_ip()
                value = json.dumps({
                    "did": self.agent_did,
                    "host": local_ip,
                    "port": self.tcp_port,
                })
                key = self._did_to_key(self.agent_did)
                await self._server.set(key.hex(), value)
                logger.debug("DHT 记录已刷新")
            except Exception as e:
                logger.error(f"DHT 刷新失败: {e}")

    async def lookup(self, did: str) -> Optional[dict]:
        """通过 did:key 在 DHT 网络中查找 Agent 地址"""
        if not self._server:
            return None

        key = self._did_to_key(did)
        try:
            result = await self._server.get(key.hex())
            if result:
                return json.loads(result)
        except Exception as e:
            logger.error(f"DHT 查找失败: {e}")
        return None

    async def store(self, did: str, host: str, port: int):
        """手动存储 Agent 信息到 DHT"""
        if not self._server:
            return
        value = json.dumps({"did": did, "host": host, "port": port})
        key = self._did_to_key(did)
        await self._server.set(key.hex(), value)

    async def stop(self):
        self._running = False
        if self._server:
            self._server.stop()
