# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from typing import Any, Callable, cast

from recognizers_date_time import recognize_datetime
from recognizers_text import Culture

from microsoft_agents.hosting.core import TurnContext
from microsoft_agents.activity import ActivityTypes

from .datetime_resolution import DateTimeResolution
from .prompt import Prompt
from .prompt_options import PromptOptions
from .prompt_recognizer_result import PromptRecognizerResult
from .prompt_validator_context import PromptValidatorContext


class DateTimePrompt(Prompt):
    def __init__(
        self,
        dialog_id: str,
        validator: Callable[[PromptValidatorContext], Any] | None = None,
        default_locale: str | None = None,
    ):
        super(DateTimePrompt, self).__init__(dialog_id, validator)
        self.default_locale = default_locale

    async def on_prompt(
        self,
        turn_context: TurnContext,
        state: dict[str, object],
        options: PromptOptions,
        is_retry: bool,
    ):
        if not turn_context:
            raise TypeError("DateTimePrompt.on_prompt(): turn_context cannot be None.")
        if not options:
            raise TypeError("DateTimePrompt.on_prompt(): options cannot be None.")

        if is_retry and options.retry_prompt is not None:
            await turn_context.send_activity(options.retry_prompt)
        else:
            if options.prompt is not None:
                await turn_context.send_activity(options.prompt)

    async def on_recognize(
        self,
        turn_context: TurnContext,
        state: dict[str, object],
        options: PromptOptions,
    ) -> PromptRecognizerResult:
        if not turn_context:
            raise TypeError(
                "DateTimePrompt.on_recognize(): turn_context cannot be None."
            )

        result = PromptRecognizerResult()
        if turn_context.activity.type == ActivityTypes.message:
            # Recognize utterance
            utterance = turn_context.activity.text
            if not utterance:
                return result
            culture = (
                turn_context.activity.locale or self.default_locale or Culture.English
            )

            results = recognize_datetime(utterance, culture)
            if results:
                result.succeeded = True
                result.value = []
                values = cast(list, results[0].resolution["values"])
                for value in values:
                    cast(list, result.value).append(self.read_resolution(value))

        return result

    def read_resolution(self, resolution: dict[str, str]) -> DateTimeResolution:
        result = DateTimeResolution()

        if "timex" in resolution:
            result.timex = resolution["timex"]
        if "value" in resolution:
            result.value = resolution["value"]
        if "start" in resolution:
            result.start = resolution["start"]
        if "end" in resolution:
            result.end = resolution["end"]

        return result
