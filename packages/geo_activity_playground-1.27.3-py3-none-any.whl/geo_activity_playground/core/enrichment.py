import datetime
import logging
import uuid
import zoneinfo
from collections.abc import Callable

import numpy as np
import pandas as pd

from .config import Config
from .coordinates import get_distance
from .datamodel import DB, Activity
from .missing_values import some
from .tag_extraction import apply_tag_extraction_from_database
from .tiles import compute_tile_float
from .time_conversion import get_timezone

logger = logging.getLogger(__name__)


def enrichment_set_timezone(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    assert len(time_series) > 0, (
        f"You cannot import an activity without points. {activity=}"
    )
    latitude, longitude = time_series[["latitude", "longitude"]].iloc[0].to_list()
    if activity.iana_timezone is None or activity.start_country is None:
        activity.iana_timezone = get_timezone(latitude, longitude)
        return True
    else:
        return False


def enrichment_normalize_time(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    # Routes (as opposed to tracks) don't have time information. We cannot do anything with time here.
    if (
        "time" in time_series.columns
        and pd.isna(time_series["time"]).all()
        and not pd.api.types.is_datetime64_any_dtype(time_series["time"].dtype)
    ):
        time_series["time"] = pd.NaT
        return True

    changed = False
    tz_utc = zoneinfo.ZoneInfo("UTC")
    # If the time is naive, assume that it is UTC.
    if time_series["time"].dt.tz is None:
        time_series["time"] = time_series["time"].dt.tz_localize(tz_utc)
        changed = True

    if time_series["time"].dt.tz.utcoffset(None) != tz_utc.utcoffset(None):
        time_series["time"] = time_series["time"].dt.tz_convert(tz_utc)
        changed = True

    if not pd.api.types.is_dtype_equal(
        time_series["time"].dtype, "datetime64[ns, UTC]"
    ):
        time_series["time"] = (
            time_series["time"].dt.tz_convert(tz_utc).astype("datetime64[ns, UTC]")
        )
        changed = True

    assert pd.api.types.is_dtype_equal(
        time_series["time"].dtype, "datetime64[ns, UTC]"
    ), (
        time_series["time"].dtype,
        time_series["time"].iloc[0],
    )

    new_start = some(time_series["time"].iloc[0])
    if new_start != activity.start:
        activity.start = new_start
        changed = True

    new_elapsed_time = some(time_series["time"].iloc[-1] - time_series["time"].iloc[0])
    if new_elapsed_time != activity.elapsed_time:
        activity.elapsed_time = new_elapsed_time
        changed = True

    return changed


def enrichment_rename_altitude(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    if "altitude" in time_series.columns:
        time_series.rename(columns={"altitude": "elevation"}, inplace=True)
        return True
    else:
        return False


def enrichment_compute_tile_xy(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    x_missing = "x" not in time_series.columns
    y_missing = "y" not in time_series.columns
    xy_invalid = (
        not x_missing
        and not y_missing
        and not (
            np.isfinite(time_series["x"]).all() and np.isfinite(time_series["y"]).all()
        )
    )
    if force or x_missing or y_missing or xy_invalid:
        x, y = compute_tile_float(time_series["latitude"], time_series["longitude"], 0)
        time_series["x"] = x
        time_series["y"] = y
        return True
    else:
        return False


def enrichment_copernicus_elevation(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    from .copernicus_dem import get_elevation

    if "copernicus_elevation" not in time_series.columns:
        time_series["copernicus_elevation"] = [
            get_elevation(lat, lon)
            for lat, lon in zip(time_series["latitude"], time_series["longitude"])
        ]
        return True
    else:
        return False


def enrichment_elevation_gain(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    if (
        "elevation" in time_series.columns
        or "copernicus_elevation" in time_series.columns
    ) and ("elevation_gain_cum" not in time_series.columns or force):
        elevation = (
            time_series["elevation"]
            if "elevation" in time_series.columns
            else time_series["copernicus_elevation"]
        )
        elevation_diff = elevation.diff()
        elevation_diff = elevation_diff.ewm(span=5, min_periods=5).mean()
        elevation_diff.loc[elevation_diff.abs() > 30] = 0
        elevation_diff.loc[elevation_diff < 0] = 0
        time_series["elevation_gain_cum"] = elevation_diff.cumsum().fillna(0)

        activity.elevation_gain = (
            time_series["elevation_gain_cum"].iloc[activity.index_end or -1]
            - time_series["elevation_gain_cum"].iloc[activity.index_begin or 0]
        )
        return True
    else:
        return False


def enrichment_add_calories(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    if "calories" in time_series.columns and (activity.calories is None or force):
        activity.calories = (
            time_series["calories"].iloc[activity.index_end or -1]
            - time_series["calories"].iloc[activity.index_begin or 0]
        )
        return True
    else:
        return False


def enrichment_distance(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    changed = False

    distances = get_distance(
        time_series["latitude"].shift(1),
        time_series["longitude"].shift(1),
        time_series["latitude"],
        time_series["longitude"],
    ).fillna(0.0)

    if config.time_diff_threshold_seconds:
        time_diff = (
            time_series["time"] - time_series["time"].shift(1)
        ).dt.total_seconds()
        jump_indices = time_diff >= config.time_diff_threshold_seconds
        distances.loc[jump_indices] = 0.0

    if "distance_km" not in time_series.columns:
        time_series["distance_km"] = pd.Series(np.cumsum(distances)) / 1000
        changed = True

    if "speed" not in time_series.columns:
        time_series["speed"] = (
            time_series["distance_km"].diff()
            / time_series["time"].diff().dt.total_seconds()
            * 3600
        )
        # Division by zero causes infinity. We replace these with NaN and interpolate the values instead.
        time_series["speed"] = time_series["speed"].replace(
            [0, np.inf, -np.inf], np.nan
        )
        time_series.interpolate(inplace=True)

        changed = True

    # A GPS spike is a point where speed rose sharply AND drops sharply at the next sample.
    # Using diff() (current − previous) and diff(-1) (current − next) both > threshold
    # detects isolated peaks while leaving legitimate sustained high speeds (car/train/plane) intact.
    spike_diff_threshold = 100.0  # km/h per GPS sample
    is_spike = (time_series["speed"].diff() > spike_diff_threshold) & (
        time_series["speed"].diff(-1) > spike_diff_threshold
    )
    if is_spike.any():
        time_series.loc[is_spike, "speed"] = np.nan
        time_series["speed"].interpolate(inplace=True)
        changed = True

    if "segment_id" not in time_series.columns:
        if config.time_diff_threshold_seconds:
            time_series["segment_id"] = np.cumsum(jump_indices)
        else:
            time_series["segment_id"] = 0
        changed = True

    new_distance_km = (
        time_series["distance_km"].iloc[activity.index_end or -1]
        - time_series["distance_km"].iloc[activity.index_begin or 0]
    )
    if new_distance_km != activity.distance_km:
        activity.distance_km = new_distance_km
        changed = True

    return changed


def enrichment_moving_time(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    def moving_time(group) -> datetime.timedelta:
        selection = group["speed"] > 1.0
        time_diff = group["time"].diff().loc[selection]
        return time_diff.sum()

    new_moving_time = (
        time_series.iloc[activity.index_begin or 0 : activity.index_end or -1]
        .groupby("segment_id")
        .apply(moving_time, include_groups=False)
        .sum()
    )
    if new_moving_time != activity.moving_time:
        activity.moving_time = new_moving_time
        return True
    else:
        return False


def enrichment_copy_latlon(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    if activity.start_latitude is None or force:
        activity.start_latitude = time_series["latitude"].iloc[
            activity.index_begin or 0
        ]
        activity.end_latitude = time_series["latitude"].iloc[activity.index_end or -1]
        activity.start_longitude = time_series["longitude"].iloc[
            activity.index_begin or 0
        ]
        activity.end_longitude = time_series["longitude"].iloc[activity.index_end or -1]
        return True
    else:
        return False


enrichments: list[Callable[[Activity, pd.DataFrame, Config, bool], bool]] = [
    enrichment_set_timezone,
    enrichment_normalize_time,
    enrichment_rename_altitude,
    enrichment_compute_tile_xy,
    # enrichment_copernicus_elevation,
    enrichment_elevation_gain,
    enrichment_add_calories,
    enrichment_distance,
    enrichment_moving_time,
    enrichment_copy_latlon,
]


def apply_enrichments(
    activity: Activity, time_series: pd.DataFrame, config: Config, force: bool
) -> bool:
    was_changed = False
    for enrichment in enrichments:
        was_changed |= enrichment(activity, time_series, config, force)
    return was_changed


def update_and_commit(
    activity: Activity,
    time_series: pd.DataFrame,
    config: Config,
    force: bool = False,
) -> None:
    if len(time_series) < 2:
        logger.warning(
            "Skipping activity %r because it has fewer than two track points.",
            activity.path or activity.upstream_id or activity.name or "<unknown>",
        )
        return

    if activity.id is None:
        apply_tag_extraction_from_database(activity)
    changed = apply_enrichments(activity, time_series, config, force)
    if not activity.time_series_uuid:
        activity.time_series_uuid = str(uuid.uuid4())
    if changed:
        activity.replace_time_series(time_series)
    DB.session.add(activity)
    DB.session.commit()
