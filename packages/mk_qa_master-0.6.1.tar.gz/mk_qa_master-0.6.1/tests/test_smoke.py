"""Smoke tests for mk-qa-master.

Catches the "easy" regressions that an MCP catalog or first-time user will
hit before they get to a real test run:
- package imports cleanly
- the MCP Server() is instantiable
- list_tools() returns the full advertised surface (currently 16 tools)
- dispatch table covers every declared tool (no name typos / unwired tools)

Per issue #35: the QA / testing MCP should have a CI smoke test of its
own, otherwise "doesn't test itself" is a real credibility hit.
"""

import asyncio


EXPECTED_TOOLS = {
    "get_runner_info",
    "list_tests",
    "run_tests",
    "run_failed",
    "get_test_report",
    "get_failure_details",
    "generate_test",
    "codegen",
    "generate_html_report",
    "get_test_history",
    "get_optimization_plan",
    "analyze_url",
    "analyze_screen",
    "init_qa_knowledge",
    "get_qa_context",
    "auto_generate_tests",
}


def test_package_importable():
    import mk_qa_master  # noqa: F401
    import mk_qa_master.server  # noqa: F401


def test_server_instantiable():
    from mk_qa_master.server import app

    assert app is not None
    assert app.name == "mk-qa-master"


def test_list_tools_returns_advertised_surface():
    from mk_qa_master.server import list_tools

    declared = {t.name for t in asyncio.run(list_tools())}
    missing = EXPECTED_TOOLS - declared
    assert not missing, f"Expected tools missing from list_tools(): {missing}"


def test_list_tools_count_matches_advertised_16():
    """If the count drifts, README and the family-site claim of '16 tools
    across 5 categories' is stale. Catch that here before users do."""
    from mk_qa_master.server import list_tools

    declared = {t.name for t in asyncio.run(list_tools())}
    assert len(declared) == 16, f"Expected 16 tools, got {len(declared)}: {sorted(declared)}"


def test_schemathesis_runner_registered():
    """v0.6.0: the schemathesis runner must be discoverable via the
    REGISTRY. Failing this means QA_RUNNER=schemathesis won't resolve,
    which would silently regress the whole API-testing capability.

    The runner class itself imports `schemathesis` lazily inside its
    methods, so this assertion is safe even when the optional
    `[api]` extra isn't installed."""
    from mk_qa_master.runners import REGISTRY

    assert "schemathesis" in REGISTRY, (
        f"schemathesis runner not registered. Available: {sorted(REGISTRY)}"
    )
    assert "api" in REGISTRY, (
        "expected 'api' as an alias for the schemathesis runner"
    )
    assert REGISTRY["schemathesis"] is REGISTRY["api"], (
        "'api' should alias the same SchemathesisRunner class"
    )
    assert REGISTRY["schemathesis"].__name__ == "SchemathesisRunner"


def test_newman_runner_registered():
    """v0.6.1: the newman runner must be discoverable via the REGISTRY
    under both `newman` and `postman` keys (mirrors how schemathesis
    aliases as both `schemathesis` and `api`).

    The runner only shells out to the `newman` CLI when methods are
    called, so this assertion is safe even when newman isn't installed
    on the test runner's PATH (Newman is npm-side and CI installs it
    in a dedicated job)."""
    from mk_qa_master.runners import REGISTRY

    assert "newman" in REGISTRY, (
        f"newman runner not registered. Available: {sorted(REGISTRY)}"
    )
    assert "postman" in REGISTRY, (
        "expected 'postman' as an alias for the newman runner"
    )
    assert REGISTRY["newman"] is REGISTRY["postman"], (
        "'postman' should alias the same NewmanRunner class"
    )
    assert REGISTRY["newman"].__name__ == "NewmanRunner"
