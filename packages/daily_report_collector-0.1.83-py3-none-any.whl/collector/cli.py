"""Collector CLI — cross-platform install/setup/start/stop/status."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from .config import CollectorConfig, SYSTEM, _default_data_dir

PLIST_NAME = "com.dailyreport.collector"
SYSTEMD_UNIT = "daily-report-collector"


# ---------------------------------------------------------------------------
# Setup wizard (interactive, cross-platform)
# ---------------------------------------------------------------------------

def setup() -> None:
    """Interactive setup: configure server URL, register device, install service."""
    config = CollectorConfig()
    config.ensure_dirs()
    config_path = _default_data_dir() / "config.json"

    print("=== AI Daily Report Collector Setup ===\n")
    print(f"Platform: {SYSTEM}")
    print(f"Device:   {config.device_name}")
    print(f"ID:       {config.device_id}\n")

    # Server URL
    default_url = config.server.url
    url = input(f"Server URL [{default_url}]: ").strip() or default_url

    # Collector token
    default_token = config.server.token or "collector-dev-token"
    token = input(f"Collector token [{default_token}]: ").strip() or default_token

    # Obsidian vault
    vault = _discover_obsidian_vault()
    if vault:
        print(f"\nFound Obsidian vault: {vault}")
        use = input("Use this vault? [Y/n]: ").strip().lower()
        if use and use != "y":
            vault = input("Obsidian vault path (or empty to skip): ").strip() or None
    else:
        vault = input("Obsidian vault path (or empty to skip): ").strip() or None

    # Save config
    cfg = {
        "server_url": url,
        "server_token": token,
        "device_id": config.device_id,
        "device_name": config.device_name,
        "obsidian_vault_path": str(vault) if vault else None,
    }
    config_path.write_text(json.dumps(cfg, indent=2))
    print(f"\nConfig saved to {config_path}")

    # Register device with server
    print(f"\nRegistering device with {url}...")
    try:
        import httpx
        resp = httpx.post(
            f"{url}/api/ingest/heartbeat",
            headers={
                "X-Collector-Token": token,
                "X-Device-Id": config.device_id,
                "X-Device-Name": config.device_name,
                "X-Device-Platform": config.platform,
            },
            timeout=10,
        )
        if resp.status_code == 200:
            print("Device registered successfully!")
        else:
            print(f"Warning: server returned {resp.status_code} (collector may still work)")
    except Exception as e:
        print(f"Warning: could not reach server ({e}). You can start the collector later.")

    # Offer to install as service
    print()
    do_install = input("Install as system service (auto-start on boot)? [Y/n]: ").strip().lower()
    if not do_install or do_install == "y":
        install()

    print("\nSetup complete! Run 'daily-report-collector start' to begin collecting.")


def _discover_obsidian_vault() -> str | None:
    """Find Obsidian vault — first from obsidian.json config, then scan common paths."""
    # Method 1: Read Obsidian's own config (most reliable)
    from .config import _discover_obsidian_vault_from_config
    vault = _discover_obsidian_vault_from_config()
    if vault:
        return str(vault)

    # Method 2: Scan common directories
    home = Path.home()
    if SYSTEM == "Darwin":
        candidates = [home / "Documents" / "Obsidian"]
    elif SYSTEM == "Windows":
        candidates = [
            home / "Documents" / "Obsidian",
            home / "OneDrive" / "Documents" / "Obsidian",
            Path(os.environ.get("USERPROFILE", str(home))) / "Documents" / "Obsidian",
        ]
    else:
        candidates = [
            home / "Documents" / "Obsidian",
            home / "obsidian",
            home / "Obsidian",
            home / ".local" / "share" / "obsidian-vaults",
            home / "Dropbox" / "Obsidian",
            home / "snap" / "obsidian" / "common",
        ]

    for c in candidates:
        if c.exists() and c.is_dir():
            for item in c.iterdir():
                if item.is_dir() and (item / ".obsidian").exists():
                    return str(item)
            return str(c)
    return None


# ---------------------------------------------------------------------------
# Service installation (platform-specific)
# ---------------------------------------------------------------------------

def install() -> None:
    """Install as a system service (auto-start on boot)."""
    if SYSTEM == "Darwin":
        _install_launchd()
    elif SYSTEM == "Linux":
        _install_systemd()
    elif SYSTEM == "Windows":
        _install_windows_task()
    else:
        print(f"Unsupported platform: {SYSTEM}. Run manually with 'daily-report-collector run'")


def uninstall() -> None:
    """Remove the system service."""
    if SYSTEM == "Darwin":
        _uninstall_launchd()
    elif SYSTEM == "Linux":
        _uninstall_systemd()
    elif SYSTEM == "Windows":
        _uninstall_windows_task()


# --- macOS (launchd) ---

def _install_launchd() -> None:
    agents_dir = Path.home() / "Library" / "LaunchAgents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    plist_path = agents_dir / f"{PLIST_NAME}.plist"

    exe = shutil.which("daily-report-collector") or sys.executable
    config = CollectorConfig()

    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{PLIST_NAME}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{exe}</string>
        <string>run</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{config.log_dir / "launchd_stdout.log"}</string>
    <key>StandardErrorPath</key>
    <string>{config.log_dir / "launchd_stderr.log"}</string>
    <key>ThrottleInterval</key>
    <integer>10</integer>
</dict>
</plist>"""
    plist_path.write_text(plist_content)
    print(f"Installed: {plist_path}")


def _uninstall_launchd() -> None:
    stop()
    plist_path = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"
    if plist_path.exists():
        plist_path.unlink()
        print("Uninstalled.")


# --- Linux (systemd user service) ---

def _install_systemd() -> None:
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_path = unit_dir / f"{SYSTEMD_UNIT}.service"

    exe = shutil.which("daily-report-collector") or sys.executable

    unit_content = f"""[Unit]
Description=AI Daily Report Collector
After=network.target

[Service]
Type=simple
ExecStart={exe} run
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
Environment=PATH={os.environ.get('PATH', '/usr/local/bin:/usr/bin')}

[Install]
WantedBy=default.target
"""
    unit_path.write_text(unit_content)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    subprocess.run(["systemctl", "--user", "enable", SYSTEMD_UNIT], check=False)
    print(f"Installed: {unit_path}")
    print("Run 'daily-report-collector start' to start.")


def _uninstall_systemd() -> None:
    stop()
    unit_path = Path.home() / ".config" / "systemd" / "user" / f"{SYSTEMD_UNIT}.service"
    subprocess.run(["systemctl", "--user", "disable", SYSTEMD_UNIT], check=False)
    if unit_path.exists():
        unit_path.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    print("Uninstalled.")


# --- Windows (Task Scheduler) ---

def _install_windows_task() -> None:
    # Prefer gui-scripts entry (no console window) over console entry
    exe = shutil.which("daily-report-collectord") or shutil.which("daily-report-collector") or sys.executable
    task_name = "DailyReportCollector"

    # Create a scheduled task that runs at logon (no console window with *d variant)
    tr_cmd = f'\\"{exe}\\" run' if " " in str(exe) else f"{exe} run"
    cmd = [
        "schtasks", "/Create", "/F",
        "/TN", task_name,
        "/TR", tr_cmd,
        "/SC", "ONLOGON",
        "/RL", "LIMITED",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Installed Windows scheduled task: {task_name}")
        print(f"  Using: {exe}")
    else:
        print(f"Failed to install: {result.stderr}")
        print("You can run manually: daily-report-collectord run")


def _uninstall_windows_task() -> None:
    stop()
    result = subprocess.run(
        ["schtasks", "/Delete", "/TN", "DailyReportCollector", "/F"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        print("Uninstalled.")
    else:
        print(f"Not installed or failed: {result.stderr.strip()}")


# ---------------------------------------------------------------------------
# Start / Stop / Status (cross-platform)
# ---------------------------------------------------------------------------

def start() -> None:
    """Start the collector service."""
    if SYSTEM == "Darwin":
        plist = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"
        if not plist.exists():
            print("Not installed. Run 'daily-report-collector setup' first.")
            return
        r = subprocess.run(["launchctl", "load", str(plist)], capture_output=True, text=True)
        print("Started." if r.returncode == 0 else f"Failed: {r.stderr.strip()}")

    elif SYSTEM == "Linux":
        r = subprocess.run(["systemctl", "--user", "start", SYSTEMD_UNIT], capture_output=True, text=True)
        print("Started." if r.returncode == 0 else f"Failed: {r.stderr.strip()}")

    elif SYSTEM == "Windows":
        r = subprocess.run(
            ["schtasks", "/Run", "/TN", "DailyReportCollector"],
            capture_output=True, text=True,
        )
        print("Started." if r.returncode == 0 else f"Failed: {r.stderr.strip()}")


def stop() -> None:
    """Stop the collector service."""
    if SYSTEM == "Darwin":
        plist = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"
        subprocess.run(["launchctl", "unload", str(plist)], capture_output=True)
        print("Stopped.")

    elif SYSTEM == "Linux":
        subprocess.run(["systemctl", "--user", "stop", SYSTEMD_UNIT], capture_output=True)
        print("Stopped.")

    elif SYSTEM == "Windows":
        subprocess.run(
            ["schtasks", "/End", "/TN", "DailyReportCollector"],
            capture_output=True,
        )
        print("Stopped.")


def status() -> None:
    """Check collector status."""
    config = CollectorConfig()
    print(f"Platform:  {SYSTEM}")
    print(f"Device:    {config.device_name}")
    print(f"Device ID: {config.device_id}")
    print(f"Server:    {config.server.url}")
    print()

    if SYSTEM == "Darwin":
        r = subprocess.run(["launchctl", "list"], capture_output=True, text=True)
        if PLIST_NAME in r.stdout:
            for line in r.stdout.splitlines():
                if PLIST_NAME in line:
                    parts = line.split()
                    pid = parts[0] if parts[0] != "-" else "not running"
                    print(f"Service: loaded (PID={pid})")
                    break
        else:
            print("Service: not loaded")

    elif SYSTEM == "Linux":
        r = subprocess.run(
            ["systemctl", "--user", "is-active", SYSTEMD_UNIT],
            capture_output=True, text=True,
        )
        print(f"Service: {r.stdout.strip()}")

    elif SYSTEM == "Windows":
        r = subprocess.run(
            ["schtasks", "/Query", "/TN", "DailyReportCollector", "/FO", "LIST"],
            capture_output=True, text=True,
        )
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                if "Status" in line:
                    print(f"Service: {line.split(':')[-1].strip()}")
                    break
        else:
            print("Service: not installed")

    # Check connectivity
    print()
    try:
        import httpx
        resp = httpx.get(f"{config.server.url}/api/ingest/status", timeout=5)
        print(f"Server:  connected ({resp.status_code})")
    except Exception:
        print("Server:  unreachable")

    # Recent log
    log_file = config.log_dir / "collector.log"
    if log_file.exists():
        lines = log_file.read_text().splitlines()
        if lines:
            print(f"\nLast log: {lines[-1]}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def cli_main() -> None:
    """CLI entry point."""
    if len(sys.argv) < 2:
        # No args = run in foreground
        from .main import main
        main()
        return

    cmd = sys.argv[1]
    commands = {
        "setup": setup,
        "install": install,
        "uninstall": uninstall,
        "start": start,
        "stop": stop,
        "status": status,
        "run": lambda: __import__("collector.main", fromlist=["main"]).main(),
    }

    if cmd in commands:
        commands[cmd]()
    elif cmd in ("-h", "--help", "help"):
        print("AI Daily Report Collector\n")
        print("Usage: daily-report-collector [command]\n")
        print("Commands:")
        print("  setup      Interactive setup wizard (first time)")
        print("  install    Install as system service")
        print("  uninstall  Remove system service")
        print("  start      Start the service")
        print("  stop       Stop the service")
        print("  status     Show collector status")
        print("  run        Run in foreground (default)")
        print("  help       Show this help")
    else:
        print(f"Unknown command: {cmd}")
        print("Run 'daily-report-collector help' for usage.")
        sys.exit(1)
