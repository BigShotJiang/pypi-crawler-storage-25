# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-05-16

### Added
- Initial public release
- `build_runstamp` — async function that renders a `str.format`-style template by resolving each `{placeholder}` through a registered `Source`
- `RunstampConfig` — frozen dataclass pairing a template string with a mapping of sources
- `Source` — `Protocol` describing the `async def resolve(**context) -> Any` interface every source implements
- Built-in sources:
  - `ConstantSource` — fixed value
  - `EnvVarSource` — environment variable with optional default
  - `KwargsSource` — value from `context[key]` with optional dotted attribute access
  - `ImportSource` — import a module, optionally read a dotted attribute, optionally call it (async-aware)
  - `CallableSource` — call any provided `Callable[[], Any | Awaitable[Any]]` (async-aware)
- `default_sources()` — ready-made mapping covering `company`, `group`, `project`, `build`, `environment`, `shard_id`, `host`, `user`, `started_at`
- `DEFAULT_TEMPLATE` — matching template for `default_sources()`
- Explicit per-source `default=` opt-in for fallback values (no silent error swallowing)
- Support for Python 3.11 through 3.14
