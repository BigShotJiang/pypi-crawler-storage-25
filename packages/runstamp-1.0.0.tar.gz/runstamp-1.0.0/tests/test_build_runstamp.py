from dataclasses import make_dataclass
from typing import Any

import pytest
from pytest import param

from runstamp import (
    CallableSource,
    ConstantSource,
    EnvVarSource,
    ImportSource,
    KwargsSource,
    RunstampConfig,
    build_runstamp,
)


@pytest.mark.parametrize(
    ["config", "kwargs", "expected"],
    [
        param(
            RunstampConfig("just-text", {}),
            {},
            "just-text",
            id="template-without-placeholders",
        ),
        param(
            RunstampConfig(
                "{a}:{b}",
                {
                    "a": KwargsSource("ctx", attr="foo"),
                    "b": KwargsSource("ctx", attr="bar"),
                },
            ),
            {"ctx": make_dataclass("Ctx", ["foo", "bar", "other"])(foo="FOO", bar=123, other=-1.2)},
            "FOO:123",
            id="kwargs-with-attr",
        ),
        param(
            RunstampConfig(
                "stage={stage}, region={region}",
                {
                    "stage": ConstantSource("prod"),
                    "region": ConstantSource("eu-west-1"),
                },
            ),
            {},
            "stage=prod, region=eu-west-1",
            id="constant-only",
        ),
        param(
            RunstampConfig(
                "{a}-{b}",
                {
                    "a": CallableSource(lambda: "x"),
                    "b": CallableSource(lambda: "y"),
                },
            ),
            {},
            "x-y",
            id="callable-only",
        ),
        param(
            RunstampConfig(
                "{a}|{b}|{a}",
                {"a": ConstantSource("X"), "b": ConstantSource("Y")},
            ),
            {},
            "X|Y|X",
            id="repeated-placeholder",
        ),
    ],
)
async def test_build_runstamp(config: RunstampConfig, kwargs: dict[str, Any], expected: str) -> None:
    assert await build_runstamp(config, **kwargs) == expected


async def test_combines_all_source_types(monkeypatch: pytest.MonkeyPatch, importable_module) -> None:
    monkeypatch.setenv("RUNSTAMP_SHARD", "42")
    name = importable_module("rs_combined_build", "build_id = '1.2.3'\n")

    config = RunstampConfig(
        "{name}:{build}/{shard}@{stage}",
        {
            "name": KwargsSource("context", attr="service_name"),
            "build": ImportSource(name, attr="build_id"),
            "shard": EnvVarSource("RUNSTAMP_SHARD"),
            "stage": ConstantSource("prod"),
        },
    )
    ctx = make_dataclass("Ctx", ["service_name"])(service_name="billing")

    assert await build_runstamp(config, context=ctx) == "billing:1.2.3/42@prod"


async def test_missing_source_raises() -> None:
    config = RunstampConfig("{a}-{b}", {"a": KwargsSource("ctx")})
    with pytest.raises(KeyError, match="b"):
        await build_runstamp(config, ctx="x")


async def test_missing_sources_listed_alphabetically() -> None:
    config = RunstampConfig("{z}-{a}-{m}", {})
    with pytest.raises(KeyError) as info:
        await build_runstamp(config)
    assert "['a', 'm', 'z']" in str(info.value)


async def test_extra_unused_sources_are_ignored() -> None:
    config = RunstampConfig(
        "{a}",
        {"a": ConstantSource("X"), "unused": ConstantSource("BOOM")},
    )
    assert await build_runstamp(config) == "X"


async def test_missing_check_runs_before_any_source() -> None:
    calls: list[str] = []

    def tracker():
        calls.append("called")
        return "X"

    config = RunstampConfig("{a}-{b}", {"a": CallableSource(tracker)})
    with pytest.raises(KeyError):
        await build_runstamp(config)
    assert calls == []


async def test_async_resolve_is_awaited() -> None:
    config = RunstampConfig(
        "{value}",
        {"value": CallableSource(lambda: _async_return("awaited"))},
    )
    assert await build_runstamp(config) == "awaited"


async def _async_return(value: str) -> str:
    return value
