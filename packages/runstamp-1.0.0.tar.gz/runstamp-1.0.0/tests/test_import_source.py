import pytest

from runstamp import ImportSource


async def test_imports_module_object(importable_module) -> None:
    name = importable_module("rs_imp_mod", "value = 42\n")
    module = await ImportSource(name).resolve()
    assert module.value == 42


async def test_reads_attribute(importable_module) -> None:
    name = importable_module("rs_imp_attr", "build_id = '1.2.3'\n")
    assert await ImportSource(name, attr="build_id").resolve() == "1.2.3"


async def test_dotted_attribute(importable_module) -> None:
    name = importable_module(
        "rs_imp_dotted",
        "class Outer:\n    class Inner:\n        value = 'deep'\n",
    )
    assert await ImportSource(name, attr="Outer.Inner.value").resolve() == "deep"


async def test_calls_attribute(importable_module) -> None:
    name = importable_module("rs_imp_call", "def get(): return 7\n")
    assert await ImportSource(name, attr="get", call=True).resolve() == 7


async def test_calls_async_attribute(importable_module) -> None:
    name = importable_module("rs_imp_async", "async def get(): return 'async'\n")
    assert await ImportSource(name, attr="get", call=True).resolve() == "async"


async def test_missing_module_without_default_raises() -> None:
    with pytest.raises(ImportError):
        await ImportSource("nonexistent_runstamp_module").resolve()


async def test_missing_module_with_default() -> None:
    assert await ImportSource("nonexistent_runstamp_module", default=None).resolve() is None


async def test_missing_attribute_without_default_raises(importable_module) -> None:
    name = importable_module("rs_imp_missing_attr", "x = 1\n")
    with pytest.raises(AttributeError):
        await ImportSource(name, attr="missing").resolve()


async def test_missing_attribute_with_default(importable_module) -> None:
    name = importable_module("rs_imp_missing_attr_default", "x = 1\n")
    assert await ImportSource(name, attr="missing", default="fallback").resolve() == "fallback"
