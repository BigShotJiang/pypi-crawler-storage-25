from runstamp import ConstantSource


async def test_returns_given_value() -> None:
    assert await ConstantSource("prod").resolve() == "prod"


async def test_returns_none() -> None:
    assert await ConstantSource(None).resolve() is None


async def test_ignores_context() -> None:
    assert await ConstantSource(42).resolve(anything="else", more=1) == 42


async def test_returns_object_identity() -> None:
    sentinel = object()
    assert await ConstantSource(sentinel).resolve() is sentinel
