import pytest

from runstamp import CallableSource


async def test_calls_sync_function() -> None:
    assert await CallableSource(lambda: "hello").resolve() == "hello"


async def test_awaits_async_function() -> None:
    async def make() -> str:
        return "async-value"

    assert await CallableSource(make).resolve() == "async-value"


async def test_raises_without_default() -> None:
    def boom():
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        await CallableSource(boom).resolve()


async def test_default_returned_on_failure() -> None:
    def boom():
        raise RuntimeError("boom")

    assert await CallableSource(boom, default="fallback").resolve() == "fallback"


async def test_default_used_when_async_callable_raises() -> None:
    async def boom():
        raise RuntimeError("async-boom")

    assert await CallableSource(boom, default=None).resolve() is None


async def test_returning_falsy_value_is_not_replaced_by_default() -> None:
    assert await CallableSource(lambda: 0, default=99).resolve() == 0
