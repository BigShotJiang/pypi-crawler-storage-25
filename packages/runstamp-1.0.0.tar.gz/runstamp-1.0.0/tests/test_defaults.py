from dataclasses import make_dataclass

import pytest

from runstamp import (
    DEFAULT_TEMPLATE,
    CallableSource,
    EnvVarSource,
    ImportSource,
    KwargsSource,
    RunstampConfig,
    build_runstamp,
    default_sources,
)

Context = make_dataclass("Context", ["company", "project_group", "project_name"])


def test_default_template_format() -> None:
    assert "{company}" in DEFAULT_TEMPLATE
    assert "{group}" in DEFAULT_TEMPLATE
    assert "{project}" in DEFAULT_TEMPLATE
    assert "{build}" in DEFAULT_TEMPLATE
    assert "{host}" in DEFAULT_TEMPLATE
    assert "{user}" in DEFAULT_TEMPLATE
    assert "{started_at}" in DEFAULT_TEMPLATE


def test_default_sources_returns_expected_keys() -> None:
    sources = default_sources()
    assert set(sources) == {
        "company",
        "group",
        "project",
        "build",
        "environment",
        "shard_id",
        "started_at",
        "host",
        "user",
    }


def test_default_sources_have_expected_types() -> None:
    sources = default_sources()
    assert isinstance(sources["company"], KwargsSource)
    assert isinstance(sources["group"], KwargsSource)
    assert isinstance(sources["project"], KwargsSource)
    assert isinstance(sources["build"], ImportSource)
    assert isinstance(sources["environment"], EnvVarSource)
    assert isinstance(sources["shard_id"], EnvVarSource)
    assert isinstance(sources["started_at"], CallableSource)
    assert isinstance(sources["host"], CallableSource)
    assert isinstance(sources["user"], CallableSource)


def test_default_sources_returns_fresh_mapping_each_call() -> None:
    a = default_sources()
    b = default_sources()
    assert a is not b


async def test_build_with_defaults_renders_string(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    monkeypatch.delenv("SHARD_ID", raising=False)
    config = RunstampConfig(DEFAULT_TEMPLATE, default_sources())
    ctx = Context(company="acme", project_group="billing", project_name="api")

    result = await build_runstamp(config, context=ctx)

    assert result.startswith("service:acme/billing/api, built:")
    assert "host:" in result
    assert "user:" in result
    assert "run:" in result


async def test_defaults_override_only_what_you_need() -> None:
    sources = {**default_sources(), "project": KwargsSource("app", attr="name")}
    template = "project:{project}"
    App = make_dataclass("App", ["name"])

    result = await build_runstamp(RunstampConfig(template, sources), app=App(name="custom"))
    assert result == "project:custom"


async def test_default_environment_is_none_when_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    config = RunstampConfig("env:{environment}", default_sources())
    ctx = Context(company="a", project_group="b", project_name="c")
    assert await build_runstamp(config, context=ctx) == "env:None"


async def test_default_environment_picks_up_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ENVIRONMENT", "staging")
    config = RunstampConfig("env:{environment}", default_sources())
    ctx = Context(company="a", project_group="b", project_name="c")
    assert await build_runstamp(config, context=ctx) == "env:staging"
