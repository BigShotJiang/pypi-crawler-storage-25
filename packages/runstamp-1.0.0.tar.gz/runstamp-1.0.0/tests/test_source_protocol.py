from dataclasses import dataclass
from typing import Any

from runstamp import (
    CallableSource,
    ConstantSource,
    EnvVarSource,
    ImportSource,
    KwargsSource,
    RunstampConfig,
    Source,
    build_runstamp,
)


def test_builtin_sources_satisfy_protocol() -> None:
    assert isinstance(ConstantSource("x"), Source)
    assert isinstance(EnvVarSource("X"), Source)
    assert isinstance(KwargsSource("x"), Source)
    assert isinstance(ImportSource("x"), Source)
    assert isinstance(CallableSource(lambda: 1), Source)


async def test_custom_source_works_in_build_runstamp() -> None:
    @dataclass(frozen=True, slots=True)
    class UpperKwarg:
        key: str

        async def resolve(self, **context: Any) -> Any:
            return str(context[self.key]).upper()

    assert isinstance(UpperKwarg("name"), Source)

    config = RunstampConfig("hello {name}", {"name": UpperKwarg("name")})
    assert await build_runstamp(config, name="world") == "hello WORLD"
