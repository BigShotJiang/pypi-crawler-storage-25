import pytest

from runstamp import EnvVarSource


async def test_reads_existing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("RUNSTAMP_TEST_VAR", "value")
    assert await EnvVarSource("RUNSTAMP_TEST_VAR").resolve() == "value"


async def test_missing_without_default_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RUNSTAMP_TEST_VAR", raising=False)
    with pytest.raises(KeyError, match="RUNSTAMP_TEST_VAR"):
        await EnvVarSource("RUNSTAMP_TEST_VAR").resolve()


async def test_missing_with_default_returns_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RUNSTAMP_TEST_VAR", raising=False)
    assert await EnvVarSource("RUNSTAMP_TEST_VAR", default="fallback").resolve() == "fallback"


async def test_default_can_be_none(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RUNSTAMP_TEST_VAR", raising=False)
    assert await EnvVarSource("RUNSTAMP_TEST_VAR", default=None).resolve() is None


async def test_empty_string_value_is_returned_as_is(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("RUNSTAMP_TEST_VAR", "")
    assert await EnvVarSource("RUNSTAMP_TEST_VAR").resolve() == ""


async def test_existing_value_takes_priority_over_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("RUNSTAMP_TEST_VAR", "real")
    assert await EnvVarSource("RUNSTAMP_TEST_VAR", default="fallback").resolve() == "real"
