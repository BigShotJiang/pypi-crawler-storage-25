import sys
from pathlib import Path

import pytest


@pytest.fixture
def importable_module(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Create a Python module in a temp dir and put it on ``sys.path``.

    Returns a callable ``(name, source) -> module_name`` so each test owns its
    own module name (avoiding cross-test import-cache pollution).
    """
    monkeypatch.syspath_prepend(str(tmp_path))

    created: list[str] = []

    def _make(name: str, source: str) -> str:
        (tmp_path / f"{name}.py").write_text(source)
        created.append(name)
        return name

    yield _make

    for name in created:
        sys.modules.pop(name, None)
