from dataclasses import make_dataclass

import pytest

from runstamp import KwargsSource


async def test_plain_key() -> None:
    assert await KwargsSource("project").resolve(project="billing") == "billing"


async def test_attr_access() -> None:
    Ctx = make_dataclass("Ctx", ["project"])
    assert await KwargsSource("ctx", attr="project").resolve(ctx=Ctx(project="billing")) == "billing"


async def test_dotted_attr_access() -> None:
    Inner = make_dataclass("Inner", ["name"])
    Outer = make_dataclass("Outer", ["project"])
    ctx = Outer(project=Inner(name="api"))
    assert await KwargsSource("ctx", attr="project.name").resolve(ctx=ctx) == "api"


async def test_missing_key_without_default_raises() -> None:
    with pytest.raises(KeyError):
        await KwargsSource("missing").resolve(other="x")


async def test_missing_key_with_default() -> None:
    assert await KwargsSource("missing", default="fallback").resolve() == "fallback"


async def test_missing_attr_without_default_raises() -> None:
    Ctx = make_dataclass("Ctx", ["project"])
    with pytest.raises(AttributeError):
        await KwargsSource("ctx", attr="absent").resolve(ctx=Ctx(project="x"))


async def test_missing_attr_with_default() -> None:
    Ctx = make_dataclass("Ctx", ["project"])
    assert await KwargsSource("ctx", attr="absent", default=None).resolve(ctx=Ctx(project="x")) is None


async def test_default_does_not_swallow_unrelated_errors() -> None:
    class Boom:
        @property
        def value(self):
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        await KwargsSource("ctx", attr="value", default="fallback").resolve(ctx=Boom())


async def test_falsy_value_is_returned_not_replaced() -> None:
    Ctx = make_dataclass("Ctx", ["count"])
    assert await KwargsSource("ctx", attr="count", default=99).resolve(ctx=Ctx(count=0)) == 0
