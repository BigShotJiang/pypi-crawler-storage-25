from collections.abc import Mapping
from dataclasses import dataclass

from ._sources import Source


@dataclass(frozen=True, slots=True)
class RunstampConfig:
    """Template + source bindings for :func:`build_runstamp`.

    :param template: ``str.format``-style template, e.g. ``"svc:{project}@{host}"``.
    :param sources: one :class:`Source` per placeholder name.
    """

    template: str
    sources: Mapping[str, Source]
