from __future__ import annotations

import importlib
import inspect
import os
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class Source(Protocol):
    """Resolves a single template field to a value.

    Implementations receive the full ``context`` kwargs passed to
    :func:`build_runstamp` and return the value to interpolate into the
    template. ``resolve`` is async so that I/O-bound sources (HTTP, DB) can
    be added without changing the interface.
    """

    async def resolve(self, **context: Any) -> Any: ...


_UNSET: Any = object()


@dataclass(frozen=True, slots=True)
class ConstantSource:
    """Always returns the given value."""

    value: Any

    async def resolve(self, **context: Any) -> Any:
        return self.value


@dataclass(frozen=True, slots=True)
class EnvVarSource:
    """Reads an environment variable.

    If the variable is unset and ``default`` was not provided, raises
    ``KeyError``.
    """

    name: str
    default: Any = _UNSET

    async def resolve(self, **context: Any) -> Any:
        value = os.environ.get(self.name)
        if value is not None:
            return value
        if self.default is _UNSET:
            raise KeyError(f"Environment variable {self.name!r} is not set")
        return self.default


@dataclass(frozen=True, slots=True)
class KwargsSource:
    """Pulls ``context[key]`` and optionally drills into dotted attributes.

    Example: ``KwargsSource("ctx", attr="project.name")`` resolves to
    ``context["ctx"].project.name``.
    """

    key: str
    attr: str | None = None
    default: Any = _UNSET

    async def resolve(self, **context: Any) -> Any:
        try:
            value = context[self.key]
            if self.attr:
                for part in self.attr.split("."):
                    value = getattr(value, part)
            return value
        except (KeyError, AttributeError):
            if self.default is _UNSET:
                raise
            return self.default


@dataclass(frozen=True, slots=True)
class ImportSource:
    """Imports a module and optionally reads or calls an attribute on it.

    - ``ImportSource("mod")`` → the module object
    - ``ImportSource("mod", attr="CONST")`` → ``mod.CONST``
    - ``ImportSource("mod", attr="fn", call=True)`` → ``mod.fn()``
      (coroutines are awaited)

    ``attr`` supports dotted paths.
    """

    module: str
    attr: str | None = None
    call: bool = False
    default: Any = _UNSET

    async def resolve(self, **context: Any) -> Any:
        try:
            value: Any = importlib.import_module(self.module)
            if self.attr:
                for part in self.attr.split("."):
                    value = getattr(value, part)
            if self.call:
                value = value()
                if inspect.isawaitable(value):
                    value = await value
            return value
        except (ImportError, AttributeError):
            if self.default is _UNSET:
                raise
            return self.default


@dataclass(frozen=True, slots=True)
class CallableSource:
    """Calls an arbitrary zero-argument Python callable to produce the value.

    Coroutines are awaited. Pass ``default=...`` to swallow a specific failure
    and substitute that value instead.

    Example: ``CallableSource(socket.gethostname)``.
    """

    fn: Callable[[], Any | Awaitable[Any]]
    default: Any = _UNSET

    async def resolve(self, **context: Any) -> Any:
        try:
            value = self.fn()
            if inspect.isawaitable(value):
                value = await value
            return value
        except Exception:
            if self.default is _UNSET:
                raise
            return self.default
