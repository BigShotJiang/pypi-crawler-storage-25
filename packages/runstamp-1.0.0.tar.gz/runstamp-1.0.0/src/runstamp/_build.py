import string
from typing import Any

from ._config import RunstampConfig


async def build_runstamp(config: RunstampConfig, /, **context: Any) -> str:
    """Render ``config.template`` by resolving each placeholder via its source.

    Every name in ``{...}`` inside the template must have a matching entry in
    ``config.sources``; otherwise ``KeyError`` is raised before any source runs.

    Extra unused sources are allowed (and ignored) — convenient when a single
    source mapping is shared across several templates.
    """
    required = {field_name for _, field_name, _, _ in string.Formatter().parse(config.template) if field_name}
    missing = required - config.sources.keys()
    if missing:
        raise KeyError(f"No sources for template fields: {sorted(missing)}")
    resolved = {key: await config.sources[key].resolve(**context) for key in required}
    return config.template.format_map(resolved)
