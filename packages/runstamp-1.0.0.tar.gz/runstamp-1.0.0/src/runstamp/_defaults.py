import getpass
import socket
from collections.abc import Mapping
from datetime import UTC, datetime

from ._sources import (
    CallableSource,
    EnvVarSource,
    ImportSource,
    KwargsSource,
    Source,
)

DEFAULT_TEMPLATE = "service:{company}/{group}/{project}, built:{build}, host:{host}, user:{user}, run:{started_at}"


def default_sources() -> Mapping[str, Source]:
    """A reasonable starter source mapping for :data:`DEFAULT_TEMPLATE`.

    Expects a ``"context"`` kwarg with ``company``/``project_group``/``project_name``
    attributes for the application-specific fields, and an importable
    ``build_info.build_id`` for the build identifier (otherwise ``None``).
    """
    return {
        "company": KwargsSource("context", attr="company"),
        "group": KwargsSource("context", attr="project_group"),
        "project": KwargsSource("context", attr="project_name"),
        "build": ImportSource("build_info", attr="build_id", default=None),
        "environment": EnvVarSource("ENVIRONMENT", default=None),
        "shard_id": EnvVarSource("SHARD_ID", default=None),
        "started_at": CallableSource(lambda: datetime.now(UTC).astimezone().isoformat()),
        "host": CallableSource(socket.gethostname),
        "user": CallableSource(getpass.getuser),
    }
