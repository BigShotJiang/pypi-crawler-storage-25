"""Claude Usage Monitor — Moniteur temps réel des limites d'utilisation Claude."""

__version__ = "2.1.2"
