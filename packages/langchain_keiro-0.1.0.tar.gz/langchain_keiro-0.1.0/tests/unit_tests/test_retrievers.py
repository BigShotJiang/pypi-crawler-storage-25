"""Unit tests for KeiroRetriever."""

import pytest
from unittest.mock import MagicMock, patch

import httpx
from langchain_core.documents import Document

from langchain_keiro.retrievers.keiro import KeiroRetriever


pytestmark = pytest.mark.unit


@pytest.fixture
def retriever(api_key):
    """Create a KeiroRetriever instance for testing."""
    return KeiroRetriever(keiro_api_key=api_key, max_results=3)


@pytest.fixture
def retriever_small_dims(api_key):
    """Create a KeiroRetriever with custom embedding dimensions."""
    return KeiroRetriever(keiro_api_key=api_key, max_results=3, embedding_dimensions=384)


class TestKeiroRetrieverInit:
    """Tests for KeiroRetriever initialization."""

    def test_default_values(self, api_key):
        retriever = KeiroRetriever(keiro_api_key=api_key)
        assert retriever.base_url == "https://kierolabs.space/api"
        assert retriever.max_results == 3
        assert retriever.embedding_dimensions == 768

    def test_custom_values(self, api_key):
        retriever = KeiroRetriever(
            keiro_api_key=api_key,
            max_results=5,
            embedding_dimensions=512,
        )
        assert retriever.max_results == 5
        assert retriever.embedding_dimensions == 512

    def test_invalid_max_results(self, api_key):
        with pytest.raises(Exception):
            KeiroRetriever(keiro_api_key=api_key, max_results=10)

    def test_invalid_dimensions(self, api_key):
        with pytest.raises(Exception):
            KeiroRetriever(keiro_api_key=api_key, embedding_dimensions=999)

    def test_lc_secrets(self, api_key):
        retriever = KeiroRetriever(keiro_api_key=api_key)
        assert retriever.lc_secrets == {"keiro_api_key": "KEIRO_API_KEY"}

    def test_is_lc_serializable(self):
        assert KeiroRetriever.is_lc_serializable() is True


class TestKeiroRetrieverBuildBody:
    """Tests for request body construction."""

    def test_body_always_deep_with_embeddings(self, retriever):
        body = retriever._build_request_body("test query")
        assert body == {
            "query": "test query",
            "maxResults": 3,
            "mode": "deep",
            "embeddings": {
                "enabled": True,
                "dimensions": 768,
            },
        }

    def test_body_custom_dimensions(self, retriever_small_dims):
        body = retriever_small_dims._build_request_body("test query")
        assert body["embeddings"]["dimensions"] == 384


class TestKeiroRetrieverConvert:
    """Tests for response conversion."""

    def test_convert_response(self, retriever, mock_search_response):
        docs = retriever._convert_response(mock_search_response)
        assert len(docs) == 2
        assert isinstance(docs[0], Document)
        assert docs[0].page_content == "Full content of result 1"
        assert docs[0].metadata["source"] == "https://example.com/1"
        assert docs[0].metadata["title"] == "Test Result 1"
        assert docs[0].metadata["snippet"] == "A short snippet"

    def test_convert_with_snippet_fallback(self, retriever):
        data = {
            "queryEmbedding": [0.1],
            "results": [
                {
                    "title": "No Content",
                    "url": "https://example.com/no-content",
                    "snippet": "Fallback snippet",
                },
            ],
        }
        docs = retriever._convert_response(data)
        assert docs[0].page_content == "Fallback snippet"

    def test_convert_with_embeddings(self, retriever):
        data = {
            "queryEmbedding": [0.1, 0.2, 0.3],
            "results": [
                {
                    "title": "Test",
                    "url": "https://example.com",
                    "snippet": "snippet",
                    "content": "content",
                    "chunks": [
                        {"text": "chunk 1", "offset": 0, "embedding": [0.4, 0.5, 0.6]},
                    ],
                },
            ],
        }
        docs = retriever._convert_response(data)
        assert docs[0].metadata["query_embedding"] == [0.1, 0.2, 0.3]
        assert docs[0].metadata["chunk_embeddings"][0]["embedding"] == [0.4, 0.5, 0.6]

    def test_convert_enrichment_fields(self, retriever, mock_search_response):
        docs = retriever._convert_response(mock_search_response)
        assert docs[0].metadata["tldr"] == "Brief summary of result 1"
        assert docs[0].metadata["tags"] == ["test", "example"]

    def test_convert_missing_results(self, retriever):
        with pytest.raises(ValueError, match="missing 'results'"):
            retriever._convert_response({"error": "bad request"})


class TestKeiroRetrieverSync:
    """Tests for synchronous retrieval."""

    @patch("langchain_keiro.retrievers.keiro.httpx.Client")
    def test_get_relevant_documents(self, mock_client_cls, retriever, mock_search_response):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_search_response

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        docs = retriever._get_relevant_documents("test query", run_manager=MagicMock())
        assert len(docs) == 2
        assert docs[0].page_content == "Full content of result 1"

    @patch("langchain_keiro.retrievers.keiro.httpx.Client")
    def test_get_relevant_documents_auth_header(self, mock_client_cls, retriever, mock_search_response):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_search_response

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        retriever._get_relevant_documents("test", run_manager=MagicMock())
        call_kwargs = mock_client.post.call_args
        assert call_kwargs.kwargs["headers"]["Authorization"] == "Bearer test-api-key"

    @patch("langchain_keiro.retrievers.keiro.httpx.Client")
    def test_get_relevant_documents_sends_deep_mode(self, mock_client_cls, retriever, mock_search_response):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_search_response

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        retriever._get_relevant_documents("test", run_manager=MagicMock())
        payload = mock_client.post.call_args.kwargs["json"]
        assert payload["mode"] == "deep"
        assert payload["embeddings"]["enabled"] is True

    @patch("langchain_keiro.retrievers.keiro.httpx.Client")
    def test_api_error(self, mock_client_cls, retriever):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Unauthorized"}
        mock_response.text = "Unauthorized"

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        with pytest.raises(ValueError, match="status 401"):
            retriever._get_relevant_documents("test", run_manager=MagicMock())

    @patch("langchain_keiro.retrievers.keiro.httpx.Client")
    def test_network_error(self, mock_client_cls, retriever):
        mock_client = MagicMock()
        mock_client.post.side_effect = httpx.RequestError("Connection failed")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        with pytest.raises(ConnectionError, match="Network error"):
            retriever._get_relevant_documents("test", run_manager=MagicMock())


class TestKeiroRetrieverAsync:
    """Tests for async retrieval."""

    @pytest.mark.asyncio
    @patch("langchain_keiro.retrievers.keiro.httpx.AsyncClient")
    async def test_aget_relevant_documents(self, mock_client_cls, retriever, mock_search_response):
        from unittest.mock import AsyncMock

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_search_response

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        docs = await retriever._aget_relevant_documents("test query", run_manager=MagicMock())
        assert len(docs) == 2