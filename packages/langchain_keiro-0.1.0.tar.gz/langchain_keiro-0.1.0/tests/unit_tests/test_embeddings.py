"""Unit tests for KeiroEmbeddings."""

import pytest
from unittest.mock import MagicMock, patch

import httpx

from langchain_keiro.embeddings.keiro import KeiroEmbeddings


pytestmark = pytest.mark.unit


@pytest.fixture
def embeddings(api_key):
    """Create a KeiroEmbeddings instance for testing."""
    return KeiroEmbeddings(keiro_api_key=api_key)


MOCK_EMBEDDING_RESPONSE = {
    "query": "test query",
    "queryEmbedding": [0.1, 0.2, 0.3, 0.4],
    "embeddingModel": "pplx-embed-v1-0.6b",
    "embeddingDimensions": 768,
    "results": [],
}


class TestKeiroEmbeddingsInit:
    """Tests for KeiroEmbeddings initialization."""

    def test_default_values(self, api_key):
        emb = KeiroEmbeddings(keiro_api_key=api_key)
        assert emb.base_url == "https://kierolabs.space/api"
        assert emb.dimensions == 768

    def test_custom_dimensions(self, api_key):
        emb = KeiroEmbeddings(keiro_api_key=api_key, dimensions=384)
        assert emb.dimensions == 384

    def test_invalid_dimensions(self):
        with pytest.raises(Exception):
            KeiroEmbeddings(keiro_api_key="key", dimensions=999)

    def test_non_https_base_url(self):
        with pytest.raises(Exception):
            KeiroEmbeddings(keiro_api_key="key", base_url="http://example.com")

    def test_lc_secrets(self, embeddings):
        assert embeddings.lc_secrets == {"keiro_api_key": "KEIRO_API_KEY"}

    def test_is_lc_serializable(self):
        assert KeiroEmbeddings.is_lc_serializable() is True


class TestKeiroEmbeddingsPayload:
    """Tests for payload construction."""

    def test_build_payload_deep_mode(self, embeddings):
        payload = embeddings._build_payload("test query")
        assert payload == {
            "query": "test query",
            "maxResults": 1,
            "mode": "deep",
            "embeddings": {
                "enabled": True,
                "dimensions": 768,
            },
        }


class TestKeiroEmbeddingsSync:
    """Tests for synchronous embedding methods."""

    @patch("langchain_keiro.embeddings.keiro.httpx.Client")
    def test_embed_query(self, mock_client_cls, embeddings):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_EMBEDDING_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = embeddings.embed_query("test query")
        assert result == [0.1, 0.2, 0.3, 0.4]

    @patch("langchain_keiro.embeddings.keiro.httpx.Client")
    def test_embed_documents(self, mock_client_cls, embeddings):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_EMBEDDING_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = embeddings.embed_documents(["query 1", "query 2"])
        assert len(result) == 2
        assert result[0] == [0.1, 0.2, 0.3, 0.4]
        assert result[1] == [0.1, 0.2, 0.3, 0.4]

    @patch("langchain_keiro.embeddings.keiro.httpx.Client")
    def test_embed_query_http_error(self, mock_client_cls, embeddings):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Unauthorized", request=MagicMock(), response=mock_response
        )

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        with pytest.raises(ValueError, match="HTTP"):
            embeddings.embed_query("test")

    @patch("langchain_keiro.embeddings.keiro.httpx.Client")
    def test_embed_query_network_error(self, mock_client_cls, embeddings):
        mock_client = MagicMock()
        mock_client.post.side_effect = httpx.RequestError("Connection failed")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        with pytest.raises(ValueError, match="Network error"):
            embeddings.embed_query("test")

    def test_extract_embedding_missing(self, embeddings):
        with pytest.raises(ValueError, match="queryEmbedding"):
            embeddings._extract_embedding({"results": []})


class TestKeiroEmbeddingsAsync:
    """Tests for async embedding methods."""

    @pytest.mark.asyncio
    @patch("langchain_keiro.embeddings.keiro.httpx.AsyncClient")
    async def test_aembed_query(self, mock_client_cls, embeddings):
        from unittest.mock import AsyncMock

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_EMBEDDING_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = await embeddings.aembed_query("test query")
        assert result == [0.1, 0.2, 0.3, 0.4]