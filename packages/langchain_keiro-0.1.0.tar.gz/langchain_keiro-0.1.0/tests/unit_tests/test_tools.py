"""Unit tests for KeiroSearchTool."""

import pytest
from unittest.mock import MagicMock, patch

import httpx

from langchain_keiro.tools.keiro_search import KeiroSearchTool


pytestmark = pytest.mark.unit


@pytest.fixture
def tool(api_key):
    """Create a KeiroSearchTool instance for testing."""
    return KeiroSearchTool(keiro_api_key=api_key)


MOCK_TOOL_RESPONSE = {
    "query": "test query",
    "results": [
        {
            "title": "Test Result 1",
            "url": "https://example.com/1",
            "snippet": "A short snippet",
            "content": "Full content of result 1",
        },
        {
            "title": "Test Result 2",
            "url": "https://example.com/2",
            "snippet": "Another snippet",
            "content": "Full content of result 2",
        },
    ],
}


class TestKeiroSearchToolInit:
    """Tests for KeiroSearchTool initialization."""

    def test_default_values(self, api_key):
        tool = KeiroSearchTool(keiro_api_key=api_key)
        assert tool.name == "keiro_search"
        assert tool.base_url == "https://kierolabs.space/api"
        assert tool.args_schema is not None

    def test_lc_secrets(self, tool):
        assert tool.lc_secrets == {"keiro_api_key": "KEIRO_API_KEY"}

    def test_is_lc_serializable(self):
        assert KeiroSearchTool.is_lc_serializable() is True


class TestKeiroSearchToolSync:
    """Tests for synchronous tool execution."""

    @patch("langchain_keiro.tools.keiro_search.httpx.Client")
    def test_run(self, mock_client_cls, tool):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_TOOL_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = tool._run(query="test query", max_results=3)
        assert "Test Result 1" in result
        assert "https://example.com/1" in result
        assert "---" in result

    @patch("langchain_keiro.tools.keiro_search.httpx.Client")
    def test_run_empty_results(self, mock_client_cls, tool):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = tool._run(query="no results query")
        assert "No results found" in result

    @patch("langchain_keiro.tools.keiro_search.httpx.Client")
    def test_run_http_error(self, mock_client_cls, tool):
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Unauthorized", request=MagicMock(), response=mock_response
        )

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = tool._run(query="test")
        assert "401" in result

    @patch("langchain_keiro.tools.keiro_search.httpx.Client")
    def test_run_network_error(self, mock_client_cls, tool):
        mock_client = MagicMock()
        mock_client.post.side_effect = httpx.RequestError("Connection failed")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = tool._run(query="test")
        assert "internal error" in result.lower()

    @patch("langchain_keiro.tools.keiro_search.httpx.Client")
    def test_run_sends_deep_mode_with_embeddings(self, mock_client_cls, tool):
        """Verify the tool always sends mode=deep and embeddings enabled."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_TOOL_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.post.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client_cls.return_value = mock_client

        tool._run(query="test", max_results=5)
        payload = mock_client.post.call_args.kwargs["json"]
        assert payload["mode"] == "deep"
        assert payload["embeddings"]["enabled"] is True
        assert payload["maxResults"] == 5


class TestKeiroSearchToolAsync:
    """Tests for async tool execution."""

    @pytest.mark.asyncio
    @patch("langchain_keiro.tools.keiro_search.httpx.AsyncClient")
    async def test_arun(self, mock_client_cls, tool):
        from unittest.mock import AsyncMock

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = MOCK_TOOL_RESPONSE
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client_cls.return_value = mock_client

        result = await tool._arun(query="test query", max_results=3)
        assert "Test Result 1" in result