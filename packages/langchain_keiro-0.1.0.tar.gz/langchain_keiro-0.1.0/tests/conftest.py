"""Shared test fixtures and configuration."""

import os

import pytest


@pytest.fixture
def api_key():
    """Return the Keiro API key from environment, or a dummy for unit tests."""
    return os.environ.get("KEIRO_API_KEY", "test-api-key")


@pytest.fixture
def mock_search_response():
    """Standard mock response from the Keiro search API."""
    return {
        "query": "test query",
        "queryEmbedding": [0.1, 0.2, 0.3],
        "embeddingModel": "pplx-embed-v1-0.6b",
        "embeddingDimensions": 768,
        "results": [
            {
                "title": "Test Result 1",
                "url": "https://example.com/1",
                "snippet": "A short snippet",
                "content": "Full content of result 1",
                "tldr": "Brief summary of result 1",
                "tags": ["test", "example"],
                "entities": ["Test Entity"],
                "readingTime": 5,
                "wordCount": 1200,
                "chunks": [
                    {"text": "chunk 1", "offset": 0, "embedding": [0.4, 0.5, 0.6]},
                ],
            },
            {
                "title": "Test Result 2",
                "url": "https://example.com/2",
                "snippet": "Another snippet",
                "content": "Full content of result 2",
                "chunks": [
                    {"text": "chunk 2", "offset": 0, "embedding": [0.7, 0.8, 0.9]},
                ],
            },
        ],
    }