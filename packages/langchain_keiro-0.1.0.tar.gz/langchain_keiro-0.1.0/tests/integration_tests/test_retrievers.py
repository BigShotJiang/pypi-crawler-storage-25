"""Integration tests for KeiroRetriever.

These tests require a valid KEIRO_API_KEY environment variable
and network access to the Keiro API.

Run with: pytest tests/integration_tests/ -m integration
"""

import os

import pytest

pytestmark = pytest.mark.integration

from langchain_keiro.retrievers.keiro import KeiroRetriever

KEIRO_API_KEY = os.environ.get("KEIRO_API_KEY", "")

pytestmark = pytest.mark.skipif(
    not KEIRO_API_KEY,
    reason="KEIRO_API_KEY not set — skipping integration tests",
)


@pytest.fixture
def retriever():
    """Create a KeiroRetriever with the real API key."""
    return KeiroRetriever(
        keiro_api_key=KEIRO_API_KEY,
        max_results=3,
    )


class TestKeiroRetrieverIntegration:
    """Integration tests using the live Keiro API."""

    def test_get_relevant_documents(self, retriever):
        """Test document retrieval with deep mode + embeddings."""
        docs = retriever.invoke("What is artificial intelligence?")
        assert len(docs) > 0
        assert all(doc.page_content for doc in docs)
        assert all("source" in doc.metadata for doc in docs)
        assert all("title" in doc.metadata for doc in docs)

    def test_embeddings_in_metadata(self, retriever):
        """Test that query_embedding and chunk_embeddings are present."""
        docs = retriever.invoke("What is machine learning?")
        assert len(docs) > 0
        assert "query_embedding" in docs[0].metadata
        assert isinstance(docs[0].metadata["query_embedding"], list)
        assert "chunk_embeddings" in docs[0].metadata

    def test_custom_dimensions(self):
        """Test retrieval with custom embedding dimensions."""
        r = KeiroRetriever(
            keiro_api_key=KEIRO_API_KEY,
            max_results=1,
            embedding_dimensions=384,
        )
        docs = r.invoke("Python programming")
        assert len(docs) > 0

    @pytest.mark.asyncio
    async def test_async_retrieval(self, retriever):
        """Test async document retrieval."""
        docs = await retriever.ainvoke("What is LangChain?")
        assert len(docs) > 0