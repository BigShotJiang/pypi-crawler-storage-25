"""Integration tests for KeiroSearchTool.

These tests require a valid KEIRO_API_KEY environment variable
and network access to the Keiro API.

Run with: pytest tests/integration_tests/ -m integration
"""

import os

import pytest

pytestmark = pytest.mark.integration

from langchain_keiro.tools.keiro_search import KeiroSearchTool

KEIRO_API_KEY = os.environ.get("KEIRO_API_KEY", "")

pytestmark = pytest.mark.skipif(
    not KEIRO_API_KEY,
    reason="KEIRO_API_KEY not set — skipping integration tests",
)


@pytest.fixture
def tool():
    """Create a KeiroSearchTool instance with the real API key."""
    return KeiroSearchTool(keiro_api_key=KEIRO_API_KEY)


class TestKeiroSearchToolIntegration:
    """Integration tests using the live Keiro API."""

    def test_run(self, tool):
        """Test basic tool execution."""
        result = tool.invoke({"query": "What is artificial intelligence?"})
        assert isinstance(result, str)
        assert len(result) > 0
        assert "Result 1" in result or "No results" in result

    @pytest.mark.asyncio
    async def test_arun(self, tool):
        """Test async tool execution."""
        result = await tool.ainvoke({"query": "What is LangChain?"})
        assert isinstance(result, str)
        assert len(result) > 0