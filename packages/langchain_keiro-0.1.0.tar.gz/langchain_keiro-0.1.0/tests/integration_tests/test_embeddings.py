"""Integration tests for KeiroEmbeddings.

These tests require a valid KEIRO_API_KEY environment variable
and network access to the Keiro API.

Run with: pytest tests/integration_tests/ -m integration
"""

import os

import pytest

pytestmark = pytest.mark.integration

from langchain_keiro.embeddings.keiro import KeiroEmbeddings

KEIRO_API_KEY = os.environ.get("KEIRO_API_KEY", "")

pytestmark = pytest.mark.skipif(
    not KEIRO_API_KEY,
    reason="KEIRO_API_KEY not set — skipping integration tests",
)


@pytest.fixture
def embeddings():
    """Create a KeiroEmbeddings instance with the real API key."""
    return KeiroEmbeddings(keiro_api_key=KEIRO_API_KEY)


class TestKeiroEmbeddingsIntegration:
    """Integration tests using the live Keiro API."""

    def test_embed_query(self, embeddings):
        """Test single query embedding."""
        vec = embeddings.embed_query("What is artificial intelligence?")
        assert isinstance(vec, list)
        assert len(vec) == 768  # default dimensions
        assert all(isinstance(v, float) for v in vec)

    def test_embed_documents(self, embeddings):
        """Test batch document embedding."""
        vecs = embeddings.embed_documents(
            ["AI overview", "Machine learning basics"]
        )
        assert len(vecs) == 2
        assert all(len(v) == 768 for v in vecs)

    @pytest.mark.asyncio
    async def test_async_embed_query(self, embeddings):
        """Test async query embedding."""
        vec = await embeddings.aembed_query("What is LangChain?")
        assert isinstance(vec, list)
        assert len(vec) == 768

    @pytest.mark.asyncio
    async def test_async_embed_documents(self, embeddings):
        """Test async batch embedding."""
        vecs = await embeddings.aembed_documents(["test query"])
        assert len(vecs) == 1