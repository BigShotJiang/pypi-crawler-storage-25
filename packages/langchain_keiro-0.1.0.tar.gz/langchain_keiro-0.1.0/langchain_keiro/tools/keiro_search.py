"""Keiro Search Tool for LangChain.

Provides KeiroSearchTool, a BaseTool implementation that wraps the
Keiro content deep search endpoint for use in LangChain agents.

Typical usage::

    from langchain_keiro.tools import KeiroSearchTool

    tool = KeiroSearchTool(keiro_api_key="keiro_...")
    result = tool.invoke({"query": "What is LangChain?"})
"""

import logging
from typing import Type

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field, SecretStr

logger = logging.getLogger(__name__)


class KeiroSearchInput(BaseModel):
    """Input schema for Keiro search tool."""

    query: str = Field(..., description="The search query")
    max_results: int = Field(
        default=3,
        ge=1,
        le=5,
        description="Max results to return",
    )


class KeiroSearchTool(BaseTool):
    """Tool to search the web using the Keiro deep search API.

    Always uses deep mode with embeddings enabled.

    Attributes:
        keiro_api_key: Your Keiro API bearer token.
        base_url: Base URL of the Keiro API
            (default ``"https://kierolabs.space/api"``).
    """

    model_config = ConfigDict(extra="ignore", protected_namespaces=())

    name: str = "keiro_search"
    description: str = (
        "Search the web using Keiro deep search API. "
        "Returns relevant web pages with titles, URLs, and full content."
    )
    args_schema: Type[BaseModel] = KeiroSearchInput
    keiro_api_key: SecretStr = Field(..., description="Keiro API key")
    base_url: str = Field(
        default="https://kierolabs.space/api",
        description="Base URL of the Keiro API",
    )

    @property
    def lc_secrets(self) -> dict[str, str]:
        """Map secret fields to environment variable names."""
        return {"keiro_api_key": "KEIRO_API_KEY"}

    @classmethod
    def is_lc_serializable(cls) -> bool:
        """Return whether this class is serializable by LangChain."""
        return True

    def _run(
        self,
        query: str,
        max_results: int = 3,
        run_manager=None,
    ) -> str:
        """Synchronously call the Keiro deep search API and format results."""
        try:
            headers = {
                "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
                "Content-Type": "application/json",
            }
            payload = {
                "query": query,
                "mode": "deep",
                "maxResults": max_results,
                "embeddings": {"enabled": True},
            }
            with httpx.Client(timeout=30) as client:
                response = client.post(
                    f"{self.base_url.rstrip('/')}/v2/search/content",
                    headers=headers,
                    json=payload,
                )
                response.raise_for_status()
                data = response.json()

            results = data.get("results", [])
            if not results:
                return "No results found."

            formatted = []
            for idx, result in enumerate(results, 1):
                title = result.get("title", "No title")
                url = result.get("url", "No URL")
                content = result.get("content") or result.get("snippet", "No content")
                formatted.append(
                    f"Result {idx}:\nTitle: {title}\nURL: {url}\nContent: {content[:500]}"
                )
            return "\n---\n".join(formatted)

        except httpx.HTTPStatusError as exc:
            logger.warning("Keiro search failed with status %s", exc.response.status_code)
            return f"Search failed with HTTP status {exc.response.status_code}."
        except httpx.RequestError as exc:
            logger.warning("Keiro search network error: %s", exc)
            return "An internal error occurred while searching."

    async def _arun(
        self,
        query: str,
        max_results: int = 3,
        run_manager=None,
    ) -> str:
        """Asynchronously call the Keiro deep search API and format results."""
        try:
            headers = {
                "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
                "Content-Type": "application/json",
            }
            payload = {
                "query": query,
                "mode": "deep",
                "maxResults": max_results,
                "embeddings": {"enabled": True},
            }
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    f"{self.base_url.rstrip('/')}/v2/search/content",
                    headers=headers,
                    json=payload,
                )
                response.raise_for_status()
                data = response.json()

            results = data.get("results", [])
            if not results:
                return "No results found."

            formatted = []
            for idx, result in enumerate(results, 1):
                title = result.get("title", "No title")
                url = result.get("url", "No URL")
                content = result.get("content") or result.get("snippet", "No content")
                formatted.append(
                    f"Result {idx}:\nTitle: {title}\nURL: {url}\nContent: {content[:500]}"
                )
            return "\n---\n".join(formatted)

        except httpx.HTTPStatusError as exc:
            logger.warning("Keiro search failed with status %s", exc.response.status_code)
            return f"Search failed with HTTP status {exc.response.status_code}."
        except httpx.RequestError as exc:
            logger.warning("Keiro search network error: %s", exc)
            return "An internal error occurred while searching."