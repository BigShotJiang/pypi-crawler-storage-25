"""LangChain retriever for the Keiro search API.

Provides KeiroRetriever, a BaseRetriever implementation that queries
the Keiro content deep search endpoint with embeddings enabled and
returns langchain Document objects.

Typical usage::

    from langchain_keiro.retrievers import KeiroRetriever

    retriever = KeiroRetriever(
        keiro_api_key="keiro_...",
        max_results=3,
    )
    docs = retriever.invoke("What is LangChain?")
    # doc.metadata["query_embedding"]  — 768-dim vector for the query
    # doc.metadata["chunk_embeddings"]  — per-chunk embeddings
"""

from typing import Any

import httpx
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import ConfigDict, Field, SecretStr, field_validator


class KeiroRetriever(BaseRetriever):
    """Retriever that uses the Keiro deep search API with embeddings.

    Always uses ``mode="deep"`` with ``embeddings.enabled=true``.
    The API returns a ``queryEmbedding`` vector and per-result ``chunks``
    containing chunk-level embeddings — both are stored in Document metadata.

    Attributes:
        keiro_api_key: Your Keiro API bearer token.
        base_url: Base URL of the Keiro API (default ``https://kierolabs.space/api``).
        max_results: Number of results to return, from 1 to 5 (default 3).
        embedding_dimensions: Dimensionality of the requested embeddings.
            Must be one of ``[384, 512, 768, 1024]`` (default 768).
    """

    model_config = ConfigDict(extra="ignore", protected_namespaces=())

    keiro_api_key: SecretStr = Field(..., description="Keiro API bearer token")
    base_url: str = Field(
        default="https://kierolabs.space/api",
        description="Base URL of the Keiro API",
    )
    max_results: int = Field(
        default=3, ge=1, le=5, description="Number of results (1-5)"
    )
    embedding_dimensions: int = Field(
        default=768,
        description="Embedding dimensions (384, 512, 768, 1024)",
    )

    @classmethod
    def is_lc_serializable(cls) -> bool:
        """Return whether this class is serializable by LangChain."""
        return True

    @field_validator("embedding_dimensions")
    @classmethod
    def validate_dimensions(cls, v: int) -> int:
        """Validate that embedding dimensions is one of the allowed values."""
        if v not in {384, 512, 768, 1024}:
            raise ValueError(
                "embedding_dimensions must be one of [384, 512, 768, 1024]"
            )
        return v

    @property
    def lc_secrets(self) -> dict[str, str]:
        """Map secret fields to environment variable names."""
        return {"keiro_api_key": "KEIRO_API_KEY"}

    def _build_request_body(self, query: str) -> dict[str, Any]:
        """Construct the JSON body for the POST request.

        Always uses mode="deep" with embeddings enabled.

        Args:
            query: The search query string.

        Returns:
            Dictionary ready for JSON serialisation.
        """
        return {
            "query": query,
            "maxResults": self.max_results,
            "mode": "deep",
            "embeddings": {
                "enabled": True,
                "dimensions": self.embedding_dimensions,
            },
        }

    def _convert_response(self, data: dict[str, Any]) -> list[Document]:
        """Convert the Keiro API response into a list of Documents.

        Args:
            data: Parsed JSON response from the Keiro API.

        Returns:
            List of ``Document`` objects with page_content and metadata.

        Raises:
            ValueError: If the response does not contain a ``results`` field.
        """
        results = data.get("results")
        if results is None:
            raise ValueError("API response missing 'results' field")

        query_embedding = data.get("queryEmbedding")

        docs: list[Document] = []
        for item in results:
            title = item.get("title", "")
            url = item.get("url", "")
            snippet = item.get("snippet", "")
            content = item.get("content", snippet)

            metadata: dict[str, Any] = {
                "source": url,
                "title": title,
                "snippet": snippet,
            }

            # Enrichment fields
            for key in ("tldr", "readingTime", "wordCount", "tags", "entities",
                        "publishDate", "credibility", "quality"):
                if key in item:
                    metadata[key] = item[key]

            # Embeddings (always present — deep mode always sends embeddings)
            if query_embedding is not None:
                metadata["query_embedding"] = query_embedding
            chunks = item.get("chunks")
            if chunks:
                metadata["chunk_embeddings"] = [
                    {"text": c.get("text", ""), "offset": c.get("offset", 0),
                     "embedding": c.get("embedding", [])}
                    for c in chunks
                ]

            docs.append(Document(page_content=content, metadata=metadata))

        return docs

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> list[Document]:
        """Synchronously retrieve documents for the given query.

        Args:
            query: The search query.
            run_manager: Callback manager (required by BaseRetriever).

        Returns:
            List of relevant ``Document`` objects.

        Raises:
            ConnectionError: If a network error occurs.
            ValueError: If the API returns a non-success status code.
        """
        url = f"{self.base_url.rstrip('/')}/v2/search/content"
        headers = {
            "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
            "Content-Type": "application/json",
        }
        body = self._build_request_body(query)

        try:
            with httpx.Client(timeout=30) as client:
                response = client.post(url, headers=headers, json=body)
        except httpx.RequestError as exc:
            raise ConnectionError(
                f"Network error while calling Keiro API: {exc}"
            ) from exc

        if response.status_code != 200:
            detail = ""
            try:
                detail = response.json().get("error", response.text)
            except Exception:
                detail = response.text
            raise ValueError(
                f"Keiro API returned status {response.status_code}: {detail}"
            )

        data = response.json()
        return self._convert_response(data)

    async def _aget_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> list[Document]:
        """Asynchronously retrieve documents for the given query.

        Args:
            query: The search query.
            run_manager: Callback manager (required by BaseRetriever).

        Returns:
            List of relevant ``Document`` objects.

        Raises:
            ConnectionError: If a network error occurs.
            ValueError: If the API returns a non-success status code.
        """
        url = f"{self.base_url.rstrip('/')}/v2/search/content"
        headers = {
            "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
            "Content-Type": "application/json",
        }
        body = self._build_request_body(query)

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(url, headers=headers, json=body)
        except httpx.RequestError as exc:
            raise ConnectionError(
                f"Network error while calling Keiro API: {exc}"
            ) from exc

        if response.status_code != 200:
            detail = ""
            try:
                detail = response.json().get("error", response.text)
            except Exception:
                detail = response.text
            raise ValueError(
                f"Keiro API returned status {response.status_code}: {detail}"
            )

        data = response.json()
        return self._convert_response(data)