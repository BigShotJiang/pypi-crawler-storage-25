"""LangChain Keiro integration package.

Provides retriever, embeddings, and tool integrations for the Keiro API.
All components use deep mode with embeddings enabled by default.
"""

from importlib import metadata

from langchain_keiro.embeddings.keiro import KeiroEmbeddings
from langchain_keiro.retrievers.keiro import KeiroRetriever
from langchain_keiro.tools.keiro_search import KeiroSearchTool

try:
    __version__ = metadata.version(__package__)
except metadata.PackageNotFoundError:
    __version__ = ""
del metadata

__all__ = [
    "KeiroEmbeddings",
    "KeiroRetriever",
    "KeiroSearchTool",
    "__version__",
]