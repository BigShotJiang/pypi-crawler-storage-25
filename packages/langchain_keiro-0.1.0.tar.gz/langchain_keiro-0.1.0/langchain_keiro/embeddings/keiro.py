"""LangChain embeddings integration for the Keiro search API.

Uses the /v2/search/content endpoint with deep mode and embeddings enabled
to generate embedding vectors via the queryEmbedding response field.

Typical usage::

    from langchain_keiro.embeddings import KeiroEmbeddings

    embeddings = KeiroEmbeddings(keiro_api_key="keiro_...")
    vec = embeddings.embed_query("What is artificial intelligence?")
    # vec is a list of 768 floats

    docs_vecs = embeddings.embed_documents(["AI overview", "Machine learning basics"])
    # docs_vecs is a list of lists
"""

import httpx
from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator
from langchain_core.embeddings import Embeddings


class KeiroEmbeddings(BaseModel, Embeddings):
    """LangChain embeddings wrapper for the Keiro search API.

    Uses the ``/v2/search/content`` endpoint with deep mode and embeddings
    enabled to generate embedding vectors. The API returns a
    ``queryEmbedding`` field for each request.

    Attributes:
        keiro_api_key: API key for authentication.
        base_url: Base URL of the Keiro API
            (default ``"https://kierolabs.space/api"``).
        dimensions: Embedding vector dimension. Must be one of
            ``[384, 512, 768, 1024]`` (Matryoshka dimensions).
    """

    model_config = ConfigDict(extra="ignore", protected_namespaces=())

    keiro_api_key: SecretStr = Field(..., description="Keiro API key")
    base_url: str = Field(
        default="https://kierolabs.space/api",
        description="Base URL of the Keiro API",
    )
    dimensions: int = Field(
        default=768,
        description="Embedding dimension (must be one of 384, 512, 768, 1024)",
    )

    @model_validator(mode="after")
    def validate_config(self) -> "KeiroEmbeddings":
        """Validate dimensions and enforce HTTPS for base_url."""
        allowed_dims = {384, 512, 768, 1024}
        if self.dimensions not in allowed_dims:
            raise ValueError(
                f"dimensions must be one of {allowed_dims}, got {self.dimensions}"
            )
        if not self.base_url.startswith("https://"):
            raise ValueError("base_url must use HTTPS for security.")
        return self

    @property
    def lc_secrets(self) -> dict[str, str]:
        """Map secret fields to environment variable names."""
        return {"keiro_api_key": "KEIRO_API_KEY"}

    @classmethod
    def is_lc_serializable(cls) -> bool:
        """Return whether this class is serializable by LangChain."""
        return True

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of documents synchronously.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors, one per input text.
        """
        embeddings: list[list[float]] = []
        with httpx.Client(timeout=30.0) as client:
            for text in texts:
                emb = self._embed_single(client, text)
                embeddings.append(emb)
        return embeddings

    def embed_query(self, text: str) -> list[float]:
        """Embed a single query string synchronously.

        Args:
            text: The query text to embed.

        Returns:
            A single embedding vector.
        """
        with httpx.Client(timeout=30.0) as client:
            return self._embed_single(client, text)

    async def aembed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of documents asynchronously.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors, one per input text.
        """
        embeddings: list[list[float]] = []
        async with httpx.AsyncClient(timeout=30.0) as client:
            for text in texts:
                emb = await self._aembed_single(client, text)
                embeddings.append(emb)
        return embeddings

    async def aembed_query(self, text: str) -> list[float]:
        """Embed a single query string asynchronously.

        Args:
            text: The query text to embed.

        Returns:
            A single embedding vector.
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            return await self._aembed_single(client, text)

    def _build_payload(self, text: str) -> dict:
        """Build the JSON payload for the embedding request."""
        return {
            "query": text,
            "maxResults": 1,
            "mode": "deep",
            "embeddings": {
                "enabled": True,
                "dimensions": self.dimensions,
            },
        }

    def _extract_embedding(self, data: dict) -> list[float]:
        """Extract the queryEmbedding from the API response."""
        query_embedding = data.get("queryEmbedding")
        if query_embedding is None:
            raise ValueError(
                "Keiro API response did not contain 'queryEmbedding' field"
            )
        return query_embedding

    def _embed_single(self, client: httpx.Client, text: str) -> list[float]:
        """Synchronous embedding call for one text."""
        url = f"{self.base_url.rstrip('/')}/v2/search/content"
        headers = {
            "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
            "Content-Type": "application/json",
        }
        payload = self._build_payload(text)

        try:
            response = client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPStatusError as exc:
            raise ValueError(
                f"Keiro API returned HTTP {exc.response.status_code}"
            ) from exc
        except httpx.RequestError as exc:
            raise ValueError(
                f"Network error while calling Keiro API: {exc}"
            ) from exc

        return self._extract_embedding(data)

    async def _aembed_single(
        self, client: httpx.AsyncClient, text: str
    ) -> list[float]:
        """Asynchronous embedding call for one text."""
        url = f"{self.base_url.rstrip('/')}/v2/search/content"
        headers = {
            "Authorization": f"Bearer {self.keiro_api_key.get_secret_value()}",
            "Content-Type": "application/json",
        }
        payload = self._build_payload(text)

        try:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPStatusError as exc:
            raise ValueError(
                f"Keiro API returned HTTP {exc.response.status_code}"
            ) from exc
        except httpx.RequestError as exc:
            raise ValueError(
                f"Network error while calling Keiro API: {exc}"
            ) from exc

        return self._extract_embedding(data)