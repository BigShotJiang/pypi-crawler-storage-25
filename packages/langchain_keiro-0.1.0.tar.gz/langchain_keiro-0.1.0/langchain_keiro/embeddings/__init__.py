"""Keiro embeddings package."""

from langchain_keiro.embeddings.keiro import KeiroEmbeddings

__all__ = ["KeiroEmbeddings"]