---
description: |
  [TOPIC] Remote SSH Deployment
  [DETAILS] SSH remote deployment of agents to other machines..
tags: [scitex-agent-container-remote-deploy]
---

# Remote SSH Deployment

## YAML Config

```yaml
spec:
  remote:
    host: mba              # SSH hostname
    user: ywatanabe
    timeout: 180            # SSH command timeout (seconds)
    login_shell: true       # Use bash -l -c (default)
  venv: ~/.venv             # Activated on remote before commands
```

## How It Works

1. Copies `spec.yaml` + the whole `dot_claude/` directory (rsync, with a tar-pipe fallback) to `~/.scitex/agent-container/runtime/<name>/` on the remote
2. SSHs to remote and runs `sac agent start <name>` against the just-copied spec
3. Remote side handles auto-accept and startup commands
4. `remote:` section stripped from copied YAML (prevents recursion)

## Commands

```bash
scitex-agent-container start remote-agent.yaml       # Deploy and start
scitex-agent-container stop remote-agent.yaml        # Stop remote agent
scitex-agent-container inspect remote-agent          # Check live state
scitex-agent-container check remote-agent.yaml       # Preflight checks
scitex-agent-container start --no-preflight ...      # Skip SSH checks
```

## Requirements on Remote Host

- `scitex-agent-container` installed (same version recommended)
- `tmux` (or `screen`) installed
- `claude` CLI installed
- SSH key-based auth configured
