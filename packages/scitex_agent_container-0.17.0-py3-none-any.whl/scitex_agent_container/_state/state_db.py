"""SQLite-backed state for scitex-agent-container (F-CS11 + diary tables).

Replaces the per-agent JSON files under
``~/.scitex/agent-container/runtime/registry/`` with a single ``state.db``
holding tables in three groups:

  * F-CS11 registry — ``definitions``, ``instances``, ``events``.
  * F-CS11 phase 2 — ``instance_heartbeats`` (the legacy
    ``heartbeats`` time series, tied to an ``instances.id``).
  * Diary (2026-05-17) — ``turns``, ``errors``, ``heartbeats``. Each
    agent writes here continuously, like a journal; the lead reads
    + filters when it wants cross-host visibility. ``heartbeats``
    promotes the per-agent ``heartbeat.json`` file into a queryable
    table keyed by ``(name, host, pid, state, ts)``.

The single-file layout makes backup/sync trivial (one ``cp``) and
keeps the existing ``actions.db`` table (``attempts``) co-located so
queries can join across action history and instance lifecycle.

NOTE: The original F-CS11 ``heartbeats`` table (instance-tied time
series) is renamed to ``instance_heartbeats`` on first open so the
diary-style ``heartbeats`` (per-agent state ping, no instance_id
required) can own the canonical name. The rename happens in
``init_schema`` when an old layout is detected and is idempotent.

Large helper groups live in sibling modules:

  * :mod:`state_db_export` — export_state / import_state /
    import_legacy_registry.
  * :mod:`state_db_gc` — gc_dead_instances / _proc_btime.
  * :mod:`state_db_diary` — record_turn / record_error /
    record_heartbeat / latest_heartbeats_per_name.

All three are re-exported from THIS module so existing
``from scitex_agent_container._state.state_db import X`` imports
keep working.
"""

from __future__ import annotations

import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .._env import getenv as _sac_env

DEFAULT_DB_PATH = Path(
    os.environ.get(
        "SCITEX_AGENT_CONTAINER_STATE_DB",
        os.path.expanduser("~/.scitex/agent-container/runtime/state.db"),
    )
)


# Registry tables (F-CS11) — definitions, instances, events.
# The legacy ``heartbeats`` table (instance_id, ts, ...) is now
# created under the name ``instance_heartbeats``. See _SCHEMA_DIARY
# below for the new diary-style ``heartbeats``.
_SCHEMA_REGISTRY = """
CREATE TABLE IF NOT EXISTS definitions (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    yaml_path       TEXT NOT NULL,
    yaml_sha256     TEXT NOT NULL,
    scope           TEXT NOT NULL,
    runtime         TEXT,
    first_seen_at   TEXT NOT NULL,
    UNIQUE(yaml_path, yaml_sha256)
);

CREATE TABLE IF NOT EXISTS instances (
    id                  TEXT PRIMARY KEY,
    definition_id       TEXT REFERENCES definitions(id),
    name                TEXT NOT NULL,
    host                TEXT NOT NULL,
    scope               TEXT NOT NULL,
    pid                 INTEGER,
    ppid                INTEGER,
    screen              TEXT,
    workdir             TEXT,
    a2a_port            INTEGER,
    started_at          TEXT NOT NULL,
    last_heartbeat_at   TEXT,
    ended_at            TEXT,
    exit_reason         TEXT,
    iter_count          INTEGER DEFAULT 0,
    input_tokens        INTEGER DEFAULT 0,
    output_tokens       INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_instances_active
    ON instances(name, host, scope) WHERE ended_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_instances_host
    ON instances(host);

CREATE TABLE IF NOT EXISTS instance_heartbeats (
    instance_id     TEXT NOT NULL REFERENCES instances(id),
    ts              TEXT NOT NULL,
    iter            INTEGER,
    input_tokens    INTEGER,
    output_tokens   INTEGER,
    pane_state      TEXT,
    PRIMARY KEY (instance_id, ts)
);

CREATE TABLE IF NOT EXISTS events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              TEXT NOT NULL,
    instance_id     TEXT,
    definition_id   TEXT,
    kind            TEXT NOT NULL,
    actor           TEXT,
    payload_json    TEXT
);

CREATE INDEX IF NOT EXISTS idx_events_instance
    ON events(instance_id, ts);
"""

# Attempts predates state.db (lived in actions.db). Bundled here so
# state.db is self-contained on a fresh host.
_SCHEMA_ATTEMPTS = """
CREATE TABLE IF NOT EXISTS attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           TEXT    NOT NULL,
    agent        TEXT    NOT NULL,
    action       TEXT    NOT NULL,
    outcome      TEXT    NOT NULL,
    elapsed_s    REAL    NOT NULL,
    pane_before  TEXT,
    pane_after   TEXT,
    extras       TEXT
);
CREATE INDEX IF NOT EXISTS idx_attempts_ts ON attempts(ts);
CREATE INDEX IF NOT EXISTS idx_attempts_agent_action ON attempts(agent, action);
"""

# Diary tables (2026-05-17): turns / errors / heartbeats. Each
# agent appends rows like a journal; the lead reads + filters.
_SCHEMA_DIARY = """
CREATE TABLE IF NOT EXISTS turns (
    turn_id        TEXT NOT NULL,
    name           TEXT NOT NULL,
    host           TEXT NOT NULL,
    status         TEXT NOT NULL,
    prompt_text    TEXT,
    response_text  TEXT,
    ts             REAL NOT NULL,
    session_id     TEXT,
    input_tokens   INTEGER,
    output_tokens  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_turns_turn_id ON turns(turn_id);
CREATE INDEX IF NOT EXISTS idx_turns_name_ts ON turns(name, ts);

CREATE TABLE IF NOT EXISTS errors (
    error_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    host       TEXT NOT NULL,
    cause      TEXT NOT NULL,
    detail     TEXT,
    ts         REAL NOT NULL,
    turn_id    TEXT
);
CREATE INDEX IF NOT EXISTS idx_errors_name_ts ON errors(name, ts);
CREATE INDEX IF NOT EXISTS idx_errors_cause ON errors(cause);

CREATE TABLE IF NOT EXISTS heartbeats (
    heartbeat_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    host          TEXT NOT NULL,
    pid           INTEGER,
    state         TEXT NOT NULL,
    ts            REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_heartbeats_name_ts ON heartbeats(name, ts);
"""

# Tables exposed by `sac db query --table=<t>`. Whitelisted so users
# can't pass arbitrary identifiers through str-format SQL.
KNOWN_TABLES = (
    "definitions",
    "instances",
    "instance_heartbeats",
    "events",
    "attempts",
    "turns",
    "errors",
    "heartbeats",
)


def now_iso() -> str:
    """ISO-8601 UTC with trailing 'Z' (matches the legacy registry format)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_uuid7() -> str:
    """Return a uuid7 string (time-ordered, sortable by start time).

    Falls back to uuid4 if uuid.uuid7 is unavailable on the runtime
    Python (added in 3.14).
    """
    if hasattr(uuid, "uuid7"):
        return str(uuid.uuid7())  # type: ignore[attr-defined]
    return str(uuid.uuid4())


def _default_connector(db_path: Path) -> sqlite3.Connection:
    """Default sqlite3 connection factory (test seam)."""
    return sqlite3.connect(db_path, timeout=30.0)


def _connect(
    db_path: Path,
    connector=_default_connector,
) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = connector(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    current_mode = conn.execute("PRAGMA journal_mode").fetchone()
    if current_mode and str(current_mode[0]).lower() != "wal":
        import time

        for attempt in range(50):
            try:
                conn.execute("PRAGMA journal_mode = WAL")
                break
            except sqlite3.OperationalError as exc:
                if "locked" not in str(exc).lower() or attempt == 49:
                    raise
                time.sleep(0.02 * (attempt + 1))
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _migrate_legacy_heartbeats(conn: sqlite3.Connection) -> None:
    """Rename the legacy F-CS11 ``heartbeats`` table → ``instance_heartbeats``.

    Detection: legacy schema has an ``instance_id`` column (NOT NULL,
    REFERENCES instances). The diary schema has no such column. We
    only rename when:

      * a table called ``heartbeats`` exists, AND
      * that table has an ``instance_id`` column, AND
      * ``instance_heartbeats`` does NOT already exist.

    Idempotent: re-running on an already-migrated DB is a no-op.
    """
    existing = {
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    if "heartbeats" not in existing:
        return
    if "instance_heartbeats" in existing:
        return
    cols = {r[1] for r in conn.execute("PRAGMA table_info(heartbeats)").fetchall()}
    if "instance_id" not in cols:
        # Already the diary schema (no rename needed).
        return
    conn.execute("ALTER TABLE heartbeats RENAME TO instance_heartbeats")


def init_schema(db_path: Path | None = None) -> Path:
    """Create state.db with all tables if missing. Idempotent.

    Returns the resolved database path.
    """
    path = Path(db_path) if db_path else DEFAULT_DB_PATH
    with _connect(path) as conn:
        _migrate_legacy_heartbeats(conn)
        conn.executescript(_SCHEMA_REGISTRY)
        conn.executescript(_SCHEMA_ATTEMPTS)
        conn.executescript(_SCHEMA_DIARY)
        conn.commit()
    return path


@contextmanager
def open_db(db_path: Path | None = None) -> Iterator[sqlite3.Connection]:
    """Context-managed connection. Initialises schema on first use."""
    path = init_schema(db_path)
    conn = _connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def table_counts(db_path: Path | None = None) -> dict[str, int]:
    """Return ``{table_name: row_count}`` for every known table."""
    counts: dict[str, int] = {}
    with open_db(db_path) as conn:
        for table in KNOWN_TABLES:
            row = conn.execute(f"SELECT count(*) AS n FROM {table}").fetchone()
            counts[table] = int(row["n"])
    return counts


def _resolve_host(host: str | None) -> str:
    """Canonical hostname for state.db writes.

    Resolution chain (F-CS12):
        1. ``host`` arg (explicit override)
        2. ``$SAC_HOST`` env var
        3. ``host.canonical`` from config.yaml
        4. ``host.aliases[$(hostname -s)]`` from config.yaml
        5. ``$(hostname -s)`` (or fqdn when fallback=hostname-fqdn)
    """
    if host:
        return host
    from . import host_config

    # stx-allow: fallback (reason: a malformed config.yaml must not block
    # state.db writes — degrade to hostname-only resolution.)
    try:
        return host_config.load().canonical_host()
    except Exception:  # stx-allow: fallback (reason: see inline comment)
        import socket

        return _sac_env("HOST") or socket.gethostname().split(".")[0]


def record_instance_start(
    name: str,
    *,
    pid: int | None = None,
    ppid: int | None = None,
    screen: str | None = None,
    workdir: str | None = None,
    a2a_port: int | None = None,
    scope: str = "global",
    host: str | None = None,
    definition_id: str | None = None,
    db_path: Path | None = None,
) -> str:
    """Insert an ``instances`` row for a freshly-started agent.

    Returns the new ``instance_id`` (uuid7). Also appends a
    ``kind='start'`` row to ``events``.
    """
    instance_id = new_uuid7()
    started_at = now_iso()
    canonical_host = _resolve_host(host)
    with open_db(db_path) as conn:
        conn.execute(
            """
            INSERT INTO instances (
                id, definition_id, name, host, scope,
                pid, ppid, screen, workdir, a2a_port, started_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                instance_id,
                definition_id,
                name,
                canonical_host,
                scope,
                pid,
                ppid,
                screen,
                workdir,
                a2a_port,
                started_at,
            ),
        )
        conn.execute(
            "INSERT INTO events (ts, instance_id, kind, actor) VALUES (?, ?, 'start', 'sac')",
            (started_at, instance_id),
        )
    return instance_id


def record_instance_stop(
    instance_id: str,
    *,
    exit_reason: str = "stopped",
    db_path: Path | None = None,
) -> bool:
    """Mark an instance as ended. Returns True iff a row was updated.

    Idempotent: stopping an already-stopped row is a no-op.
    """
    ended_at = now_iso()
    with open_db(db_path) as conn:
        cur = conn.execute(
            "UPDATE instances SET ended_at=?, exit_reason=? "
            "WHERE id=? AND ended_at IS NULL",
            (ended_at, exit_reason, instance_id),
        )
        if cur.rowcount == 0:
            return False
        conn.execute(
            "INSERT INTO events (ts, instance_id, kind, actor, payload_json) "
            "VALUES (?, ?, 'stop', 'sac', ?)",
            (ended_at, instance_id, json.dumps({"exit_reason": exit_reason})),
        )
    return True


def update_heartbeat(
    instance_id: str,
    *,
    iter: int | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    pane_state: str | None = None,
    db_path: Path | None = None,
) -> None:
    """Append an instance-heartbeat row + bump the rolling cache.

    The duplicated state on ``instances`` lets ``sac agent status``
    answer 'is this agent still doing work?' without a JOIN.
    """
    ts = now_iso()
    with open_db(db_path) as conn:
        conn.execute(
            """
            INSERT INTO instance_heartbeats (
                instance_id, ts, iter, input_tokens, output_tokens, pane_state
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(instance_id, ts) DO UPDATE SET
                iter          = COALESCE(excluded.iter, instance_heartbeats.iter),
                input_tokens  = COALESCE(excluded.input_tokens, instance_heartbeats.input_tokens),
                output_tokens = COALESCE(excluded.output_tokens, instance_heartbeats.output_tokens),
                pane_state    = COALESCE(excluded.pane_state, instance_heartbeats.pane_state)
            """,
            (instance_id, ts, iter, input_tokens, output_tokens, pane_state),
        )
        conn.execute(
            """
            UPDATE instances
               SET last_heartbeat_at = ?,
                   iter_count    = COALESCE(?, iter_count),
                   input_tokens  = COALESCE(?, input_tokens),
                   output_tokens = COALESCE(?, output_tokens)
             WHERE id = ?
            """,
            (ts, iter, input_tokens, output_tokens, instance_id),
        )


def list_active_instances(
    host: str | None = None,
    db_path: Path | None = None,
) -> list[dict]:
    """Return every ``ended_at IS NULL`` row, optionally host-filtered."""
    with open_db(db_path) as conn:
        if host is None:
            cur = conn.execute(
                "SELECT * FROM instances WHERE ended_at IS NULL "
                "ORDER BY started_at DESC"
            )
        else:
            cur = conn.execute(
                "SELECT * FROM instances WHERE ended_at IS NULL AND host=? "
                "ORDER BY started_at DESC",
                (host,),
            )
        return [dict(r) for r in cur.fetchall()]


# Re-export the helpers that used to live in this file but moved
# into sibling modules under the per-file line cap. Existing callers
# keep importing them from :mod:`state_db`.
from .state_db_diary import (  # noqa: E402,F401
    latest_heartbeats_per_name,
    record_error,
    record_heartbeat,
    record_turn,
)
from .state_db_export import (  # noqa: E402,F401
    EXPORT_SCHEMA_VERSION,
    export_state,
    import_legacy_registry,
    import_state,
)
from .state_db_export import (
    _table_filter_clauses as _table_filter_clauses_impl,
)
from .state_db_gc import (  # noqa: E402,F401
    _proc_btime,
    gc_dead_instances,
)


def _table_filter_clauses(since: str | None) -> dict[str, tuple[str, tuple]]:
    """Per-table SQL fragments + params for ``--since`` filtering.

    Thin wrapper over ``state_db_export._table_filter_clauses`` so the
    original module-level signature stays compatible with callers that
    only pass ``since``.
    """
    return _table_filter_clauses_impl(since, KNOWN_TABLES)
