"""VM Fleet Dashboard — real-time monitoring for the VM fleet."""
