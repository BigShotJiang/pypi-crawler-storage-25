"""MCP server package for controlling VirtualBox VMs."""

from __future__ import annotations

from mcp_vm_blackbox.version import __version__

__all__ = ["__version__"]
