"""Tests for the mcp_vm_blackbox package."""
