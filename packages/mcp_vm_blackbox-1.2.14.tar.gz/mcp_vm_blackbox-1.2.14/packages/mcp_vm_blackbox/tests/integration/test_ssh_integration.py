from __future__ import annotations

import pytest

from mcp_vm_blackbox._helpers import _ssh_run


@pytest.mark.asyncio
async def test_ssh_run_basic_command(docker_sshd_target):
    """Test that _ssh_run can execute a simple command against a real SSH container."""
    result = await _ssh_run(docker_sshd_target, ["echo", "hello from ubuntu"])
    assert result.returncode == 0
    assert "hello from ubuntu" in result.stdout
    assert result.stderr == ""


@pytest.mark.asyncio
async def test_ssh_run_failing_command(docker_sshd_target):
    """Test that _ssh_run correctly captures non-zero exit codes and stderr."""
    result = await _ssh_run(docker_sshd_target, ["ls", "/does/not/exist"])
    assert result.returncode != 0
    assert "No such file or directory" in result.stderr
    assert result.stdout == ""


@pytest.mark.asyncio
async def test_ssh_run_sudo_command(docker_sshd_target):
    """Test that the testuser can execute sudo commands without a password."""
    result = await _ssh_run(docker_sshd_target, ["sudo", "whoami"])
    assert result.returncode == 0
    assert "root" in result.stdout
