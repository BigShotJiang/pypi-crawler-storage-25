"""Acceptance tests for the ``packer_prerequisites`` MCP prompt.

Three tests lock the contract before implementation exists in T02:

1. ``test_packer_prerequisites_prompt_is_registered`` — the prompt appears in
   the FastMCP server's internal prompt list.
2. ``test_prompts_list_includes_packer_prerequisites`` — ``prompts/list``
   JSON-RPC via in-process ``fastmcp.Client`` returns ``packer_prerequisites``.
3. ``test_prompts_get_returns_checklist_content`` — ``prompts/get`` JSON-RPC
   returns message text containing ``"packer server"``, a string present in the
   ``skills/packer-prerequisites/SKILL.md`` checklist body.

All three tests must **fail** (not error) before T02 is implemented, confirming
that they exercise real behaviour rather than stubs.

Deferred imports
----------------
``fastmcp`` is intentionally **not** imported at module level. Importing it at
collection time (before conftest patches are in place) causes
``ModuleNotFoundError`` for ``rich.logging`` in pytest-xdist workers. All
fastmcp symbols are accessed either through ``sys.modules`` (after the
``server_module`` session fixture has loaded the server) or via a local import
inside the test body — matching the pattern established in
``test_server_init.py`` and ``test_server_lifespan.py``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    import types


class TestPackerPrerequisitesPrompt:
    """Acceptance tests for the ``packer_prerequisites`` MCP prompt."""

    @pytest.mark.asyncio
    async def test_packer_prerequisites_prompt_is_registered(self, server_module: types.ModuleType) -> None:
        """The prompt must appear in the server's internal prompt registry.

        Uses ``mcp._list_prompts()`` (async) to enumerate all registered
        prompts and asserts that ``packer_prerequisites`` is present.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        prompts = await server_module.mcp._list_prompts()
        names = [p.name for p in prompts]
        assert "packer_prerequisites" in names, f"Expected 'packer_prerequisites' in prompt registry, got: {names}"

    @pytest.mark.asyncio
    async def test_prompts_list_includes_packer_prerequisites(self, server_module: types.ModuleType) -> None:
        """``prompts/list`` JSON-RPC must return ``packer_prerequisites``.

        Uses an in-process ``fastmcp.Client`` to exercise the real
        ``prompts/list`` JSON-RPC path without any network or subprocess.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        from fastmcp import Client

        async with Client(server_module.mcp) as client:
            result = await client.list_prompts()

        names = [p.name for p in result]
        assert "packer_prerequisites" in names, f"Expected 'packer_prerequisites' in prompts/list result, got: {names}"

    @pytest.mark.asyncio
    async def test_prompts_get_returns_checklist_content(self, server_module: types.ModuleType) -> None:
        """``prompts/get packer_prerequisites`` must return checklist text.

        Calls ``client.get_prompt('packer_prerequisites')`` via an in-process
        ``fastmcp.Client`` and asserts the first message's text contains
        ``"packer server"`` — a string present in the SKILL.md checklist body.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        from fastmcp import Client

        async with Client(server_module.mcp) as client:
            result = await client.get_prompt("packer_prerequisites")

        assert result.messages, "Expected at least one message in get_prompt result"
        text = result.messages[0].content.text
        assert "packer server" in text, f"Expected 'packer server' in prompt content, got: {text!r}"
