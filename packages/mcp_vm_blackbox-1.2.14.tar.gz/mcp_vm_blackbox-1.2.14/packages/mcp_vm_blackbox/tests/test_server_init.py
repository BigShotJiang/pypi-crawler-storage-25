"""Tests for MCP server application initialization.

Verifies that the FastMCP app is created with the correct name and is an
instance of the expected class, confirming that server.py bootstraps
cleanly even without the external runtime dependencies present.

Note: FastMCP is intentionally NOT imported at module level here. Importing
fastmcp at collection time (before conftest fixtures run) causes
``ModuleNotFoundError: No module named 'rich.logging'; 'rich' is not a
package`` in pytest-xdist workers due to coverage instrumentation ordering.
FastMCP is accessed through the server module that is already loaded by the
``server_module`` session fixture, which runs after conftest patches are in
place.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import types


class TestMcpAppInit:
    """Tests for the ``mcp`` FastMCP application object."""

    def test_mcp_app_name(self, server_module: types.ModuleType) -> None:
        """The MCP app must be named 'vm-blackbox'.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        assert server_module.mcp.name == "vm-blackbox"

    def test_mcp_is_fastmcp_instance(self, server_module: types.ModuleType) -> None:
        """The MCP app must be an instance of FastMCP from the loaded fastmcp package.

        Accesses FastMCP via sys.modules after the server module has been
        imported by the session fixture, avoiding collection-time import
        failures in xdist workers.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        FastMCP = sys.modules["fastmcp"].FastMCP
        assert isinstance(server_module.mcp, FastMCP)

    def test_main_is_callable(self, server_module: types.ModuleType) -> None:
        """The server module must expose a callable ``main`` entry point.

        Args:
            server_module: Session-scoped fixture providing the server module.
        """
        assert callable(server_module.main)
