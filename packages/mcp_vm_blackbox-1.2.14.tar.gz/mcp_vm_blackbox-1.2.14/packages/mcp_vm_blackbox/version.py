"""Package version — derived from installed package metadata at runtime."""

from __future__ import annotations

from importlib.metadata import version

__version__ = version("mcp-vm-blackbox")
