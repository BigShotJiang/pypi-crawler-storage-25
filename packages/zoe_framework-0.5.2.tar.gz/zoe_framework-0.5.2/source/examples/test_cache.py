import time

from zoe_cache.decorators.cache import cache
from zoe_cache.decorators.invalidates import invalidates

call_count = 0


@cache(ttl=2)
def get_products():
    global call_count
    call_count += 1
    print(f"  [DB] buscando produtos... (chamada #{call_count})")
    return ["Cone Laranja", "Faixa Refletiva", "Capacete"]


@invalidates(get_products)
def create_product(name: str):
    print(f"  [DB] criando produto: {name}")
    return name


print("=== TESTE 1: cache simples ===")
r1 = get_products()
print(f"resultado: {r1}")
r2 = get_products()
print(f"resultado: {r2}")
print(f"total de chamadas ao banco: {call_count} (esperado: 1)\n")

print("=== TESTE 2: invalidate ===")
create_product("Colete Refletivo")
r3 = get_products()
print(f"resultado: {r3}")
print(f"total de chamadas ao banco: {call_count} (esperado: 2)\n")

print("=== TESTE 3: TTL expirando ===")
print("aguardando 3 segundos para TTL expirar...")
time.sleep(3)
r4 = get_products()
print(f"resultado: {r4}")
print(f"total de chamadas ao banco: {call_count} (esperado: 3)\n")

print("=== TESTE 4: cache válido após renovação ===")
r5 = get_products()
print(f"resultado: {r5}")
print(f"total de chamadas ao banco: {call_count} (esperado: 3)")
