import requests
import json

API_URL = "https://flashapi.floxylabs.eu/v1/chat/completions"
CREDITS_URL = "https://flashapi.floxylabs.eu/v1/credits"

def getCredits(
    apikey: str
):
    headers = {
        "Authorization": f"Bearer {apikey}",
        "Content-Type": "application/json"
    }

    response = requests.post(CREDITS_URL, headers=headers)
    if response.status_code == 200:
        print(json.dumps(response.json(), indent=2))
    else:
        print(f"\033[91mError {response.status_code}: {response.text}\033[0m")

def generate(apiKey: str, model: str, prompt: str, streaming: bool):
    headers = {
        "Authorization": f"Bearer {apiKey}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": streaming
    }
    
    if streaming:
        response = requests.post(API_URL, headers=headers, json=payload, stream=True)
        if response.status_code == 200:
            for line in response.iter_lines():
                if line:
                    print(line.decode("utf-8"))
        else:
            print(f"\033[91mError {response.status_code}: {response.text}\033[0m")
    else:
        response = requests.post(API_URL, headers=headers, json=payload)
        if response.status_code == 200:
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"\033[91mError {response.status_code}: {response.text}\033[0m")