from .main import generate, getCredits

__version__ = "1.1.0"