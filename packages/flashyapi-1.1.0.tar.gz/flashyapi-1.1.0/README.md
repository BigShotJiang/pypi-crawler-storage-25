# FlashyAPI

A simple Python package to interact with AI models from FloxyLabs.eu.

## Installation

```bash
pip install flashyapi
```

## Usage

### Generate (Non-streaming)

```python
import FlashyAPI

# Non-streaming response
FlashyAPI.generate(
    apiKey="your-api-key",
    model="model-name",
    prompt="Your question here",
    streaming=False
)
```

### Generate (Streaming)

```python
import FlashyAPI

# Streaming response
FlashyAPI.generate(
    apiKey="your-api-key",
    model="model-name",
    prompt="Your question here",
    streaming=True
)
```

### Check Credits

```python
import FlashyAPI

# Get your remaining credits
FlashyAPI.getCredits(apikey="your-api-key")
```

## FAQ

### How to get an API key?
Join our Discord and open a ticket to request an API key: https://discord.gg/Y6aVDdyfm7  
You will receive **5,000 Credits** for free.

### What happens to my prompts?
Your prompts are sent to models hosted by FloxyLabs.eu. All data is secured and encrypted.

### What data is published?
Your used model, token usage, and credit usage are logged to https://flashapi.floxylabs.eu/v1/activity for tracking purposes.

### What are Credits?
Credits are the currency system from FloxyLabs. The formula is:  
`TOTAL_TOKENS × MODEL_MULTIPLIER = TOTAL_CREDITS`

## API Reference

- **Chat Completions**: `https://flashapi.floxylabs.eu/v1/chat/completions`
- **Credits**: `https://flashapi.floxylabs.eu/v1/credits`
- **Activity**: `https://flashapi.floxylabs.eu/v1/activity`

## Support

For support, join our [Discord](https://discord.gg/Y6aVDdyfm7) or visit [FloxyLabs](https://floxylabs.eu/).
