"""Run every public API and print outputs in copy-paste-ready blocks.

The output of this script is the source-of-truth for docs/USAGE.md.
Rerun after any API change to regenerate the examples.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import torch

import patchcraft
from patchcraft import (
    Cache,
    Patchify,
    extract,
    num_patches,
    pair,
    paired_tilings,
    patch_metrics,
    per_patch_psnr,
    reconstruct,
    resize,
    scale_factor,
    stitch,
    tilings,
)


def block(title: str) -> None:
    print()
    print(f"## {title}")
    print()


def repl(code: str, value: object) -> None:
    print(f">>> {code}")
    print(value)


block("0. setup")
repl("patchcraft.__version__", patchcraft.__version__)
repl("sorted(patchcraft.__all__)", sorted(patchcraft.__all__))


block("1. num_patches - pre-flight, no allocation")
repl("num_patches((28, 28), patch_size=7, stride=7)",
     num_patches((28, 28), patch_size=7, stride=7))
repl("num_patches((28, 28), patch_size=4, stride=2)",
     num_patches((28, 28), patch_size=4, stride=2))
repl("num_patches((3, 32, 32), patch_size=8, stride=8)  # accepts (C, H, W) too",
     num_patches((3, 32, 32), patch_size=8, stride=8))
repl("num_patches((4, 4), patch_size=8, stride=1)  # patch too big -> (0, 0)",
     num_patches((4, 4), patch_size=8, stride=1))


block("2. tilings - every full-coverage geometry for an image")
print(">>> tilings((28, 28))  # exact tilings only")
for t in tilings((28, 28)):
    print(f"    {t}")
print()
print(">>> len(tilings((28, 28), allow_overlap=True))")
print(len(tilings((28, 28), allow_overlap=True)))


block("3. extract - patches from one (C, H, W) image")
img = torch.arange(28 * 28, dtype=torch.float32).reshape(1, 28, 28)
patches = extract(img, patch_size=7, stride=7)
repl("img.shape", tuple(img.shape))
repl("patches = extract(img, patch_size=7, stride=7)", None)
repl("patches.shape  # (L, C, ph, pw); L = 4*4 = 16", tuple(patches.shape))
repl("patches.dtype", patches.dtype)


block("4. Patchify - callable companion for torchvision.transforms.Compose")
patchify = Patchify(patch_size=4, stride=2)
repl("patchify = Patchify(patch_size=4, stride=2)", None)
repl("repr(patchify)", repr(patchify))
repl("patchify(img).shape  # 13*13 = 169 patches with half-overlap",
     tuple(patchify(img).shape))


block("5. reconstruct - bit-exact when stride == patch_size")
recon = reconstruct(patches, image_shape=img.shape, stride=7)
repl("recon = reconstruct(patches, image_shape=img.shape, stride=7)", None)
repl("recon.shape", tuple(recon.shape))
repl("torch.equal(recon, img)  # bit-exact round-trip", torch.equal(recon, img))


block("6. reconstruct with overlap - weighted, still exact for in-range float")
ps_overlap = extract(img, patch_size=4, stride=2)
recon_overlap = reconstruct(ps_overlap, image_shape=img.shape, stride=2)
repl("ps_overlap = extract(img, patch_size=4, stride=2)  # 169 overlapping patches",
     None)
repl("recon_overlap = reconstruct(ps_overlap, image_shape=img.shape, stride=2)",
     None)
repl("torch.allclose(recon_overlap, img)", torch.allclose(recon_overlap, img))


block("6b. stitch - blend modified patches back with a window kernel")
print(">>> # stitch is the seam-aware counterpart to reconstruct: use when")
print(">>> # patches have been modified (model output, denoised). With uniform,")
print(">>> # it equals reconstruct; with hann/gaussian, it weights patch centers")
print(">>> # more than edges to attenuate boundary seams.")
print()
img_small = torch.full((1, 8, 8), 0.5, dtype=torch.float32)
patches_small = extract(img_small, patch_size=4, stride=4)
out_uniform = stitch(patches_small, image_shape=img_small.shape, stride=4,
                     weight="uniform")
out_hann = stitch(patches_small, image_shape=img_small.shape, stride=4,
                  weight="hann")
out_gauss = stitch(patches_small, image_shape=img_small.shape, stride=4,
                   weight="gaussian")
repl("img_small = torch.full((1, 8, 8), 0.5)  # uniform gray", None)
repl("patches_small = extract(img_small, patch_size=4, stride=4)  # 4 patches", None)
repl("stitch(..., weight='uniform') == reconstruct(...)  # equivalent math path",
     torch.equal(out_uniform,
                 reconstruct(patches_small, image_shape=img_small.shape, stride=4)))
repl("stitch(..., weight='hann')[0, 0, 0]   # corner zeroed (documented Hann artifact)",
     out_hann[0, 0, 0].item())
repl("stitch(..., weight='hann')[0, 1, 1]   # patch interior preserved",
     out_hann[0, 1, 1].item())
repl("stitch(..., weight='gaussian')[0, 0, 0]  # gaussian: no corner artifact",
     out_gauss[0, 0, 0].item())


block("7. pair - LR / HR correspondences with scale_factor=2")
lr = torch.arange(8 * 8, dtype=torch.float32).reshape(1, 8, 8)
hr = torch.arange(16 * 16, dtype=torch.float32).reshape(1, 16, 16)
result = pair(lr, hr, lr_patch_size=4, scale_factor=2, stride=4, image_id="demo-0")
repl("lr.shape, hr.shape", (tuple(lr.shape), tuple(hr.shape)))
repl("result = pair(lr, hr, lr_patch_size=4, scale_factor=2, stride=4, image_id='demo-0')",
     None)
repl("result.lr_patches.shape", tuple(result.lr_patches.shape))
repl("result.hr_patches.shape", tuple(result.hr_patches.shape))
repl("len(result)", len(result))
repl("result.metas[0]", result.metas[0])
repl("result.metas[-1]", result.metas[-1])


block("8. resize - output type matches input")
from PIL import Image
import numpy as np

arr = (np.arange(16 * 16 * 3) % 256).astype(np.uint8).reshape(16, 16, 3)
pil_img = Image.fromarray(arr, mode="RGB")
pil_out = resize(pil_img, target_size=(8, 8), backend="pil")
repl("pil_out = resize(pil_img, target_size=(8, 8), backend='pil')", None)
repl("type(pil_out).__name__, pil_out.size, pil_out.mode",
     (type(pil_out).__name__, pil_out.size, pil_out.mode))

tensor_img = torch.rand(3, 16, 16)
tensor_out = resize(tensor_img, target_size=(8, 8), backend="torch")
repl("tensor_out = resize(tensor_img, target_size=(8, 8), backend='torch')", None)
repl("type(tensor_out).__name__, tuple(tensor_out.shape), tensor_out.dtype",
     (type(tensor_out).__name__, tuple(tensor_out.shape), tensor_out.dtype))


block("9. Cache - bytes in, bytes out, atomic, version-aware")
with tempfile.TemporaryDirectory() as tmp:
    c = Cache(tmp, namespace="demo", version=1)
    repl("c = Cache(tmp, namespace='demo', version=1)", None)
    repl("repr(c)", repr(c))
    config = {"target_size": (8, 8), "resample": "lanczos"}
    k = c.key_for("image-fingerprint", config)
    repl("k = c.key_for('image-fingerprint', {'target_size': (8,8), 'resample': 'lanczos'})",
         None)
    repl("k[:16]  # short prefix used as filename", k[:16])
    c.put(k, b"some pickled payload")
    repl("c.put(k, b'some pickled payload')", None)
    repl("c.get(k)", c.get(k))
    repl("c.get(c.key_for('missing'))", c.get(c.key_for("missing")))

    # Version bump invalidates by construction (different key)
    c2 = Cache(tmp, namespace="demo", version=2)
    k2 = c2.key_for("image-fingerprint", config)
    repl("c2 = Cache(tmp, namespace='demo', version=2)", None)
    repl("k == c2.key_for(... same parts ...)  # different by construction",
         k == k2)
    repl("c2.get(k2)  # transparent miss after version bump", c2.get(k2))


block("10. scale_factor - discover the integer scale between two shapes")
repl("scale_factor((14, 14), (28, 28))", scale_factor((14, 14), (28, 28)))
repl("scale_factor((28, 28), (28, 28))  # identity", scale_factor((28, 28), (28, 28)))
repl("scale_factor((14, 14), (27, 27))  # non-integer", scale_factor((14, 14), (27, 27)))
repl("scale_factor((10, 10), (20, 30))  # anisotropic",
     scale_factor((10, 10), (20, 30)))


block("11. paired_tilings - aligned LR/HR geometries between two resolutions")
print(">>> paired_tilings((14, 14), (28, 28))")
for p in paired_tilings((14, 14), (28, 28)):
    print(f"    lr={p.lr.patch_size} stride={p.lr.stride} | "
          f"hr={p.hr.patch_size} stride={p.hr.stride} | "
          f"total={p.lr.total_patches} | sf={p.scale_factor}")


block("12. patch_metrics + per_patch_psnr - canonical comparisons")
# Build two patch stacks: one identical to source, one with small noise.
img_a = torch.arange(28 * 28, dtype=torch.float32).reshape(1, 28, 28) / 784.0
patches_a = extract(img_a, patch_size=7, stride=7)
patches_b = patches_a + 0.01  # uniform noise of magnitude 0.01

repl("patch_metrics(patches_a, patches_a)  # identical",
     patch_metrics(patches_a, patches_a))
repl("patch_metrics(patches_a, patches_b)  # +0.01 across the board",
     patch_metrics(patches_a, patches_b))
repl("per_patch_psnr(patches_a, patches_b)  # one value per patch",
     per_patch_psnr(patches_a, patches_b))


block("13. end-to-end QPatchSR-style pre-flight")
print(">>> # Goal: train SVM mapping 14x14 patches -> 28x28 patches on MNIST.")
print(">>> # Step 1: enumerate viable LR/HR geometries with same patch count.")
print(">>> for p in paired_tilings((14, 14), (28, 28)):")
print("...     print(p.lr.patch_size, '<-->', p.hr.patch_size,")
print("...           f'({p.lr.total_patches} patches each)')")
for p in paired_tilings((14, 14), (28, 28)):
    print(f"({p.lr.patch_size[0]}, {p.lr.patch_size[0]}) <--> "
          f"({p.hr.patch_size[0]}, {p.hr.patch_size[0]}) "
          f"({p.lr.total_patches} patches each)")
print(">>> # Step 2: pick a spec, call pair() with the LR/HR pixel data.")
print(">>> # Step 3: train.")
print(">>> # Step 4: measure with per_patch_psnr(model(lr), hr) to find")
print(">>> # which patches the model handles worst.")


block("14. composing extract + reconstruct in a torch pipeline")
print(">>> from patchcraft import Patchify")
print(">>> from torchvision import transforms")
print(">>> transform = transforms.Compose([")
print("...     transforms.ToTensor(),")
print("...     transforms.GaussianBlur(kernel_size=3),")
print("...     Patchify(patch_size=4, stride=2),")
print("... ])")
print(">>> # transform(pil_image) -> Tensor[L, C, 4, 4]")
print(">>> # DataLoader workers parallelize across images for free.")
