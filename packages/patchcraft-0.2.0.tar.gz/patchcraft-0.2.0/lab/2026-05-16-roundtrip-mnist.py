"""End-to-end round-trip on MNIST: image -> extract -> reconstruct -> assert close.

Validates M2 + M3 on real images. Sweeps a few patch geometries (no-overlap,
half-overlap, max-overlap), reports max abs diff per geometry, saves a
side-by-side PNG to Z:\\outputs\\patchkit\\<slug>\\ for visual inspection.

Run: python lab/2026-05-16-roundtrip-mnist.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import torch

# Allow tests._datasets import when running from project root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from patchkit import extract, reconstruct  # noqa: E402
from tests._datasets import mnist_subset  # noqa: E402

SLUG = "2026-05-16-roundtrip-mnist"
OUT_DIR = Path(r"Z:\outputs\patchkit") / SLUG


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Output dir: {OUT_DIR}\n")

    samples = mnist_subset(n_per_label=2, seed=0)
    img0, label0 = samples[0]
    print(f"Loaded {len(samples)} samples; first is digit {label0}, "
          f"shape={tuple(img0.shape)}, dtype={img0.dtype}\n")

    # (patch_size, stride, name)
    geometries: list[tuple[int, int, str]] = [
        (7, 7, "no-overlap (4x4 grid)"),
        (4, 2, "half-overlap (13x13 grid)"),
        (3, 1, "max-overlap (26x26 grid)"),
        (28, 28, "single patch == image"),
    ]

    all_ok = True
    for ps, st, name in geometries:
        max_diff = 0.0
        for img, _label in samples:
            patches = extract(img, patch_size=ps, stride=st)
            recon = reconstruct(patches, image_shape=tuple(img.shape), stride=st)
            max_diff = max(max_diff, (recon - img).abs().max().item())
        tolerance = 1e-6 if ps == st else 5e-7  # exact vs overlap (float32)
        ok = max_diff < tolerance
        marker = "OK " if ok else "FAIL"
        print(f"  [{marker}] {name:30s} patch={ps:2d} stride={st:2d}  "
              f"max|recon-img| = {max_diff:.3e}")
        all_ok = all_ok and ok

    print()

    # Save a side-by-side PNG for the first sample at half-overlap (4, 2).
    try:
        from torchvision.utils import save_image
        img, label = samples[0]
        patches = extract(img, patch_size=4, stride=2)
        recon = reconstruct(patches, image_shape=tuple(img.shape), stride=2)
        diff = (recon - img).abs()
        diff_scaled = (diff / diff.max().clamp(min=1e-12)).clamp(0, 1)
        triptych = torch.cat([img, recon, diff_scaled], dim=2)
        png_path = OUT_DIR / f"sample0-digit{label}-half-overlap.png"
        save_image(triptych, png_path)
        print(f"Saved triptych (orig | recon | |diff| normalized) -> {png_path}")
    except Exception as exc:  # noqa: BLE001
        print(f"(PNG save skipped: {exc})")

    print()
    print("ALL GEOMETRIES PASSED" if all_ok else "SOME GEOMETRIES FAILED")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
