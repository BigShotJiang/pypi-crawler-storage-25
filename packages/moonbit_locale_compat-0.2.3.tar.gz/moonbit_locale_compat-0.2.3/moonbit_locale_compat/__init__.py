"""Locale compatibility helpers for CJK environments."""
from .compat import (
    detect_encoding,
    ensure_utf8_env,
    normalize_locale,
    resolve_cjk_codec,
)
from ._compat_registry import warm_cache as _warm_cache

__version__ = "0.2.3"
__all__ = [
    "detect_encoding",
    "ensure_utf8_env",
    "normalize_locale",
    "resolve_cjk_codec",
]

# Pre-warm the codec compatibility cache so that the first call to
# resolve_cjk_codec does not block on a filesystem or registry probe.
_warm_cache()
