"""Tests for range_filter module."""

import pandas as pd
import pytest
from datetime import datetime, timezone

from chartpipe.core.range_filter import (
    DateRange,
    parse_range,
    filter_by_range,
    range_to_str,
    _subtract_months,
)


class TestParseRange:
    """Test range string parsing."""

    def test_relative_days(self):
        dr = parse_range("7d")
        assert dr.has_start()
        assert not dr.has_end()

    def test_relative_months(self):
        dr = parse_range("3mo")
        assert dr.has_start()
        assert not dr.has_end()

    def test_relative_year(self):
        dr = parse_range("1y")
        assert dr.has_start()
        assert not dr.has_end()

    def test_ytd(self):
        dr = parse_range("ytd")
        assert dr.has_start()
        assert not dr.has_end()
        now = datetime.now(timezone.utc)
        assert dr.start.year == now.year
        assert dr.start.month == 1
        assert dr.start.day == 1

    def test_full_year(self):
        dr = parse_range("2024")
        assert dr.has_start()
        assert dr.has_end()
        assert dr.start.year == 2024
        assert dr.start.month == 1
        assert dr.start.day == 1
        assert dr.end.month == 12
        assert dr.end.day == 31

    def test_year_range(self):
        dr = parse_range("2022-2024")
        assert dr.start.year == 2022
        assert dr.end.year == 2024
        assert dr.end.month == 12
        assert dr.end.day == 31

    def test_quarter(self):
        dr = parse_range("2024Q1")
        assert dr.start.year == 2024
        assert dr.start.month == 1
        assert dr.end.month == 3
        assert dr.end.day == 31

        dr2 = parse_range("2024Q4")
        assert dr2.start.month == 10
        assert dr2.end.month == 12
        assert dr2.end.day == 31

    def test_month(self):
        dr = parse_range("2024-03")
        assert dr.start.year == 2024
        assert dr.start.month == 3
        assert dr.start.day == 1
        assert dr.end.month == 3
        assert dr.end.day == 31

        # February leap year
        dr2 = parse_range("2024-02")
        assert dr2.end.day == 29

        # Non-leap February
        dr3 = parse_range("2023-02")
        assert dr3.end.day == 28

    def test_day(self):
        dr = parse_range("2024-03-15")
        assert dr.start.year == 2024
        assert dr.start.month == 3
        assert dr.start.day == 15
        assert dr.end.day == 15

    def test_invalid_range(self):
        with pytest.raises(ValueError):
            parse_range("foobar")
        with pytest.raises(ValueError):
            parse_range("")
        with pytest.raises(ValueError):
            parse_range("2024-13-01")  # invalid month

    def test_case_insensitive(self):
        dr = parse_range("YTD")
        assert dr.has_start()
        dr2 = parse_range("7D")
        assert dr2.has_start()


class TestSubtractMonths:
    def test_subtract_months(self):
        dt = datetime(2024, 6, 15, tzinfo=timezone.utc)
        result = _subtract_months(dt, 3)
        assert result.year == 2024
        assert result.month == 3
        assert result.day == 15

    def test_subtract_months_year_boundary(self):
        dt = datetime(2024, 1, 15, tzinfo=timezone.utc)
        result = _subtract_months(dt, 2)
        assert result.year == 2023
        assert result.month == 11
        assert result.day == 15

    def test_subtract_months_day_cap(self):
        # Jan 31 - 1 month should be Dec 31 (capped), not Nov 31
        dt = datetime(2024, 1, 31, tzinfo=timezone.utc)
        result = _subtract_months(dt, 1)
        assert result.month == 12
        assert result.day == 31


class TestFilterByRange:
    def _make_df(self, start_year=2024, rows=100):
        dates = pd.date_range(f"{start_year}-01-01", periods=rows, freq="D", tz="UTC")
        return pd.DataFrame({"close": range(rows)}, index=dates)

    def test_no_filter(self):
        df = self._make_df()
        dr = DateRange(start=None, end=None)
        result = filter_by_range(df, dr)
        assert len(result) == len(df)

    def test_start_only(self):
        df = self._make_df()
        dr = DateRange(start=datetime(2024, 3, 1, tzinfo=timezone.utc), end=None)
        result = filter_by_range(df, dr)
        assert result.index[0] >= pd.Timestamp(2024, 3, 1, tzinfo=timezone.utc)

    def test_end_only(self):
        df = self._make_df()
        dr = DateRange(start=None, end=datetime(2024, 3, 1, tzinfo=timezone.utc))
        result = filter_by_range(df, dr)
        assert result.index[-1] <= pd.Timestamp(2024, 3, 1, tzinfo=timezone.utc)

    def test_start_and_end(self):
        df = self._make_df()
        dr = DateRange(
            start=datetime(2024, 2, 1, tzinfo=timezone.utc),
            end=datetime(2024, 3, 31, tzinfo=timezone.utc),
        )
        result = filter_by_range(df, dr)
        assert len(result) > 0
        assert result.index[0] >= pd.Timestamp(2024, 2, 1, tzinfo=timezone.utc)
        assert result.index[-1] <= pd.Timestamp(2024, 3, 31, 23, 59, 59, tzinfo=timezone.utc)

    def test_empty_result(self):
        df = self._make_df()
        dr = DateRange(
            start=datetime(2025, 1, 1, tzinfo=timezone.utc),
            end=datetime(2025, 12, 31, tzinfo=timezone.utc),
        )
        result = filter_by_range(df, dr)
        assert len(result) == 0

    def test_empty_df(self):
        df = pd.DataFrame()
        dr = DateRange(start=datetime(2024, 1, 1, tzinfo=timezone.utc), end=None)
        result = filter_by_range(df, dr)
        assert result.empty

    def test_no_matching_index(self):
        df = self._make_df()
        dr = DateRange(start=datetime(2023, 1, 1, tzinfo=timezone.utc), end=datetime(2023, 12, 31, tzinfo=timezone.utc))
        result = filter_by_range(df, dr)
        assert len(result) == 0


class TestRangeToStr:
    def test_both_bounds(self):
        dr = DateRange(
            start=datetime(2024, 1, 1, tzinfo=timezone.utc),
            end=datetime(2024, 12, 31, tzinfo=timezone.utc),
        )
        assert range_to_str(dr) == "2024-01-01 → 2024-12-31"

    def test_start_only(self):
        dr = DateRange(start=datetime(2024, 6, 1, tzinfo=timezone.utc), end=None)
        s = range_to_str(dr)
        assert "2024-06-01" in s

    def test_no_bounds(self):
        dr = DateRange(start=None, end=None)
        assert range_to_str(dr) == "all time"
