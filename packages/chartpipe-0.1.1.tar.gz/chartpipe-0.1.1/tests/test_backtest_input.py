"""Tests for backtest input parsing (quantpipe envelope, run-dir CSV)."""

import json
from pathlib import Path

import pandas as pd
import pytest

from chartpipe.core.backtest_input import load_from_run_dir, parse_backtest_payload


def test_parse_quantpipe_envelope_loads_equity_csv(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    eq = tmp_path / "equity.csv"
    eq.write_text(
        "timestamp,equity\n"
        "2024-01-01T00:00:00Z,10000\n"
        "2024-01-02T00:00:00Z,10100\n",
        encoding="utf-8",
    )
    envelope = {
        "schemaVersion": 1,
        "tool": "quantpipe",
        "command": "backtest",
        "ok": True,
        "data": {
            "source": {"bars": 2},
            "strategy": {"name": "test"},
            "performance": {"total_return": 0.01},
        },
        "artifacts": {"equity": "equity.csv"},
    }
    df, trades, meta = parse_backtest_payload(json.dumps(envelope), cwd=str(tmp_path))
    assert "equity" in df.columns
    assert len(df) == 2
    assert trades == []
    assert meta.get("loaded_from") == "artifacts"


def test_parse_performance_only_raises():
    payload = {
        "schemaVersion": 1,
        "tool": "quantpipe",
        "ok": True,
        "data": {
            "source": {"bars": 1},
            "strategy": {"name": "x"},
            "performance": {"total_return": 0.1},
        },
        "artifacts": {},
    }
    with pytest.raises(ValueError, match="--run-dir"):
        parse_backtest_payload(payload)


def test_load_from_run_dir(tmp_path: Path):
    rd = tmp_path / "run1"
    rd.mkdir()
    (rd / "equity.csv").write_text(
        "timestamp,equity\n2024-01-01,100\n2024-01-02,101\n", encoding="utf-8"
    )
    df, trades, meta = load_from_run_dir(str(rd))
    assert isinstance(df.index, pd.DatetimeIndex)
    assert len(df) == 2
    assert meta["run_dir"] == str(rd.resolve())


def test_load_from_run_dir_empty_trades_csv(tmp_path: Path):
    rd = tmp_path / "run1"
    rd.mkdir()
    (rd / "equity.csv").write_text(
        "timestamp,equity\n2024-01-01,100\n2024-01-02,101\n", encoding="utf-8"
    )
    (rd / "trades.csv").write_text("", encoding="utf-8")
    df, trades, meta = load_from_run_dir(str(rd))
    assert len(df) == 2
    assert trades == []
    assert meta["run_dir"] == str(rd.resolve())


def test_legacy_equity_curve():
    body = {
        "equity_curve": [
            {"timestamp": "2024-01-01", "equity": 10000},
            {"timestamp": "2024-01-02", "equity": 10100},
        ],
        "trades": [],
    }
    df, trades, meta = parse_backtest_payload(body)
    assert len(df) == 2
    assert meta.get("loaded_from") == "inline"
