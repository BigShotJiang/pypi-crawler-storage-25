import pandas as pd

from chartpipe.core.input_data import json_payload_to_dataframe, normalize_ohlcv_columns


def test_json_payload_to_dataframe_unwraps_success_result_candles():
    payload = {
        "success": True,
        "result": {
            "message": "Fetched candles",
            "candles": [
                [
                    1704067200000,
                    "1.0",
                    "2.0",
                    "0.5",
                    "1.5",
                    "10.0",
                    1704067200000,
                    "0",
                    0,
                    "0",
                    "0",
                    "0",
                ]
            ],
        },
    }
    df = normalize_ohlcv_columns(json_payload_to_dataframe(payload))
    assert isinstance(df, pd.DataFrame)
    assert set(["timestamp", "open", "high", "low", "close", "volume"]).issubset(df.columns)

