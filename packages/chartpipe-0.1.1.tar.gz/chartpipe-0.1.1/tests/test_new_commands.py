"""Tests for new chartpipe commands: volatility, compare, volume, drawdown, calendar, regime."""

import json
import os
import tempfile

import pandas as pd
import pytest
from click.testing import CliRunner

from chartpipe.cli import cli


def create_ohlcv_data(days=100, symbol="BTCUSDT"):
    """Generate sample OHLCV data for testing."""
    import numpy as np
    
    np.random.seed(42)
    dates = pd.date_range(start="2024-01-01", periods=days, freq="D")
    
    # Generate realistic price movement
    returns = np.random.normal(0.001, 0.02, days)
    close = 100 * np.exp(np.cumsum(returns))
    
    # Generate OHLC from close
    high = close * (1 + np.abs(np.random.normal(0, 0.01, days)))
    low = close * (1 - np.abs(np.random.normal(0, 0.01, days)))
    open_price = low + (high - low) * np.random.random(days)
    volume = np.random.randint(1000, 10000, days)
    
    df = pd.DataFrame({
        "timestamp": [d.isoformat() for d in dates],
        "open": open_price,
        "high": high,
        "low": low,
        "close": close,
        "volume": volume,
    })
    
    return df


def create_multi_asset_data(days=100):
    """Generate sample multi-asset data for testing."""
    assets = {}
    for symbol in ["BTCUSDT", "ETHUSDT", "ADAUSDT"]:
        df = create_ohlcv_data(days, symbol)
        assets[symbol] = df.to_dict("records")
    return assets


@pytest.fixture
def ohlcv_file():
    """Create a temporary OHLCV data file."""
    df = create_ohlcv_data(100)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(df.to_dict("records"), f)
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture
def multi_asset_file():
    """Create a temporary multi-asset data file."""
    data = create_multi_asset_data(100)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        path = f.name
    yield path
    os.unlink(path)


class TestVolatilityCommand:
    """Tests for the volatility command."""
    
    def test_volatility_history(self, ohlcv_file):
        """Test volatility history chart generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volatility",
                "--data", ohlcv_file,
                "--type", "history",
                "--window", "20",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volatility_rolling(self, ohlcv_file):
        """Test volatility rolling chart generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volatility",
                "--data", ohlcv_file,
                "--type", "rolling",
                "--window", "20",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volatility_cone(self, ohlcv_file):
        """Test volatility cone chart generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volatility",
                "--data", ohlcv_file,
                "--type", "cone",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volatility_all(self, ohlcv_file):
        """Test generating all volatility charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volatility",
                "--data", ohlcv_file,
                "--type", "all",
            ])
            assert result.exit_code == 0
            assert "History volatility chart saved:" in result.output
            assert "Rolling volatility chart saved:" in result.output
            assert "Cone volatility chart saved:" in result.output
    
    def test_volatility_json_output(self, ohlcv_file):
        """Test volatility JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "volatility",
            "--data", ohlcv_file,
            "--type", "history",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "volatility"
        assert output["ok"] is True
        assert "chart" in output["artifacts"]
    
    def test_volatility_stdin(self, ohlcv_file):
        """Test volatility with stdin input."""
        runner = CliRunner()
        with open(ohlcv_file) as f:
            data = f.read()
        
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volatility",
                "--stdin",
                "--type", "history",
            ], input=data)
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volatility_dry_run(self, ohlcv_file):
        """Test volatility dry-run mode."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "volatility",
            "--data", ohlcv_file,
            "--dry-run",
        ])
        assert result.exit_code == 0
        assert "Dry run OK" in result.output


class TestCompareCommand:
    """Tests for the compare command."""
    
    def test_compare_price(self, multi_asset_file):
        """Test price comparison chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "compare",
                "--data", multi_asset_file,
                "--type", "price",
                "--normalize",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_compare_correlation(self, multi_asset_file):
        """Test correlation heatmap."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "compare",
                "--data", multi_asset_file,
                "--type", "correlation",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_compare_rs(self, multi_asset_file):
        """Test relative strength comparison."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "compare",
                "--data", multi_asset_file,
                "--type", "rs",
                "--benchmark", "BTCUSDT",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_compare_all(self, multi_asset_file):
        """Test generating all comparison charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "compare",
                "--data", multi_asset_file,
                "--type", "all",
                "--normalize",
            ])
            assert result.exit_code == 0
            assert "Price comparison chart saved:" in result.output
            assert "Correlation comparison chart saved:" in result.output
    
    def test_compare_json_output(self, multi_asset_file):
        """Test compare JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "compare",
            "--data", multi_asset_file,
            "--type", "price",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "compare"


class TestVolumeCommand:
    """Tests for the volume command."""
    
    def test_volume_vwap(self, ohlcv_file):
        """Test VWAP chart generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volume",
                "--data", ohlcv_file,
                "--type", "vwap",
                "--bands", "3",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volume_profile(self, ohlcv_file):
        """Test volume profile chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volume",
                "--data", ohlcv_file,
                "--type", "profile",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volume_obv(self, ohlcv_file):
        """Test OBV chart generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volume",
                "--data", ohlcv_file,
                "--type", "obv",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_volume_all(self, ohlcv_file):
        """Test generating all volume charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "volume",
                "--data", ohlcv_file,
                "--type", "all",
            ])
            assert result.exit_code == 0
            assert "VWAP chart saved:" in result.output
            assert "PROFILE chart saved:" in result.output
            assert "OBV chart saved:" in result.output
    
    def test_volume_json_output(self, ohlcv_file):
        """Test volume JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "volume",
            "--data", ohlcv_file,
            "--type", "vwap",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "volume"


class TestDrawdownCommand:
    """Tests for the drawdown command."""
    
    def test_drawdown_underwater(self, ohlcv_file):
        """Test underwater curve generation."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "drawdown",
                "--data", ohlcv_file,
                "--type", "underwater",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_drawdown_recovery(self, ohlcv_file):
        """Test recovery distribution chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "drawdown",
                "--data", ohlcv_file,
                "--type", "recovery",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_drawdown_top(self, ohlcv_file):
        """Test top drawdowns chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "drawdown",
                "--data", ohlcv_file,
                "--type", "top",
                "--top", "5",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_drawdown_all(self, ohlcv_file):
        """Test generating all drawdown charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "drawdown",
                "--data", ohlcv_file,
                "--type", "all",
            ])
            assert result.exit_code == 0
            assert "Underwater drawdown chart saved:" in result.output
            assert "Recovery drawdown chart saved:" in result.output
            assert "Top drawdown chart saved:" in result.output
    
    def test_drawdown_json_output(self, ohlcv_file):
        """Test drawdown JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "drawdown",
            "--data", ohlcv_file,
            "--type", "underwater",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "drawdown"


class TestCalendarCommand:
    """Tests for the calendar command."""
    
    def test_calendar_weekday(self, ohlcv_file):
        """Test weekday returns analysis."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "calendar",
                "--data", ohlcv_file,
                "--type", "weekday",
                "--agg", "mean",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_calendar_month(self, ohlcv_file):
        """Test month returns analysis."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "calendar",
                "--data", ohlcv_file,
                "--type", "month",
                "--agg", "mean",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_calendar_all(self, ohlcv_file):
        """Test generating all calendar charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "calendar",
                "--data", ohlcv_file,
                "--type", "all",
            ])
            assert result.exit_code == 0
            assert "Weekday calendar chart saved:" in result.output
            assert "Month calendar chart saved:" in result.output
    
    def test_calendar_json_output(self, ohlcv_file):
        """Test calendar JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "calendar",
            "--data", ohlcv_file,
            "--type", "weekday",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "calendar"


class TestRegimeCommand:
    """Tests for the regime command."""
    
    def test_regime_trend(self, ohlcv_file):
        """Test ADX trend regime chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "regime",
                "--data", ohlcv_file,
                "--type", "trend",
                "--period", "14",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_regime_volatility(self, ohlcv_file):
        """Test volatility regime chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "regime",
                "--data", ohlcv_file,
                "--type", "volatility",
                "--period", "20",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_regime_ma_cross(self, ohlcv_file):
        """Test MA cross regime chart."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "regime",
                "--data", ohlcv_file,
                "--type", "ma-cross",
                "--fast", "20",
                "--slow", "50",
            ])
            assert result.exit_code == 0
            assert "Chart saved:" in result.output
    
    def test_regime_all(self, ohlcv_file):
        """Test generating all regime charts."""
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "regime",
                "--data", ohlcv_file,
                "--type", "all",
            ])
            assert result.exit_code == 0
            assert "Trend regime chart saved:" in result.output
            assert "Volatility regime chart saved:" in result.output
            assert "Ma-Cross regime chart saved:" in result.output
    
    def test_regime_json_output(self, ohlcv_file):
        """Test regime JSON output."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "regime",
            "--data", ohlcv_file,
            "--type", "trend",
            "--json",
        ])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["tool"] == "chartpipe"
        assert output["command"] == "regime"


class TestIndicatorsModule:
    """Tests for the indicators module."""
    
    def test_calculate_volatility(self):
        """Test volatility calculation."""
        from chartpipe.core.indicators import calculate_volatility
        
        prices = pd.Series([100, 101, 102, 101, 100, 99, 100, 101, 102, 103] * 10)
        vol = calculate_volatility(prices, window=10, annualize=252)
        
        # Volatility has len(prices)-1 because returns drops first value
        assert len(vol) == len(prices) - 1
        assert pd.isna(vol.iloc[8])  # First window-1 values should be NaN
        assert vol.iloc[-1] > 0  # Last value should be positive
    
    def test_calculate_vwap(self):
        """Test VWAP calculation."""
        from chartpipe.core.indicators import calculate_vwap
        
        df = pd.DataFrame({
            "high": [102, 103, 104],
            "low": [98, 99, 100],
            "close": [100, 101, 102],
            "volume": [1000, 2000, 1500],
        })
        
        vwap = calculate_vwap(df)
        assert len(vwap) == len(df)
        assert vwap.iloc[0] == 100  # First VWAP equals first typical price
    
    def test_calculate_obv(self):
        """Test OBV calculation."""
        from chartpipe.core.indicators import calculate_obv
        
        df = pd.DataFrame({
            "close": [100, 101, 100, 99, 100],
            "volume": [1000, 2000, 1500, 1000, 2000],
        })
        
        obv = calculate_obv(df)
        assert len(obv) == len(df)
        assert obv.iloc[0] == 1000
        assert obv.iloc[1] == 3000  # Up day: add volume
        assert obv.iloc[2] == 1500  # Down day: subtract volume
    
    def test_calculate_adx(self):
        """Test ADX calculation."""
        from chartpipe.core.indicators import calculate_adx
        
        df = pd.DataFrame({
            "high": [102, 103, 104, 103, 102, 103, 104, 105, 104, 103],
            "low": [98, 99, 100, 99, 98, 99, 100, 101, 100, 99],
            "close": [100, 101, 102, 101, 100, 101, 102, 103, 102, 101],
        })
        
        adx_data = calculate_adx(df, period=5)
        assert "adx" in adx_data.columns
        assert "plus_di" in adx_data.columns
        assert "minus_di" in adx_data.columns
        assert len(adx_data) == len(df)
    
    def test_calculate_drawdowns(self):
        """Test drawdown calculation."""
        from chartpipe.core.indicators import calculate_drawdowns
        
        equity = pd.Series([100, 105, 110, 108, 105, 100, 95, 100, 105, 110])
        
        drawdowns = calculate_drawdowns(equity)
        assert isinstance(drawdowns, pd.DataFrame)
        assert "depth" in drawdowns.columns
        assert "duration" in drawdowns.columns
    
    def test_calculate_calendar_returns(self):
        """Test calendar returns calculation."""
        from chartpipe.core.indicators import calculate_calendar_returns
        
        dates = pd.date_range("2024-01-01", periods=100, freq="D")
        df = pd.DataFrame({
            "close": [100 + i * 0.1 for i in range(100)],
        }, index=dates)
        
        weekday_returns = calculate_calendar_returns(df, freq="weekday")
        assert isinstance(weekday_returns, pd.DataFrame)
        assert "period" in weekday_returns.columns
        assert "mean" in weekday_returns.columns
