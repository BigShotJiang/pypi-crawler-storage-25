import json

from click.testing import CliRunner

from chartpipe.cli import cli


def test_subcommand_output_dir_option_after_command_parses():
    runner = CliRunner()
    payload = {"candles": [[1704067200000, "1.0", "2.0", "0.5", "1.5", "10.0"]]}
    res = runner.invoke(
        cli,
        ["ohlcv", "--stdin", "--dry-run", "-o", "charts_test/subcmd"],
        input=json.dumps(payload),
    )
    assert res.exit_code == 0, res.output

