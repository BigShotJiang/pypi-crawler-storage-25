"""Unit tests for technical indicators module."""

import numpy as np
import pandas as pd
import pytest

from chartpipe.core.indicators import (
    calculate_adx,
    calculate_calendar_returns,
    calculate_correlation_matrix,
    calculate_drawdowns,
    calculate_obv,
    calculate_relative_strength,
    calculate_returns,
    calculate_volatility,
    calculate_volatility_cone,
    calculate_volume_profile,
    calculate_vwap,
    calculate_vwap_bands,
)


class TestReturnsCalculations:
    """Tests for returns-based calculations."""

    def test_calculate_returns_basic(self):
        """Test basic returns calculation."""
        prices = pd.Series([100, 101, 102, 101, 100])
        returns = calculate_returns(prices)
        
        assert len(returns) == 4
        assert returns.iloc[0] == pytest.approx(0.01, abs=1e-10)  # 1% return
        assert returns.iloc[1] == pytest.approx(0.009901, rel=1e-4)  # ~1% return
        assert returns.iloc[2] == pytest.approx(-0.009804, rel=1e-4)  # ~-1% return
        assert returns.iloc[3] == pytest.approx(-0.009901, rel=1e-4)  # ~-1% return

    def test_calculate_returns_empty(self):
        """Test returns calculation with single value."""
        prices = pd.Series([100])
        returns = calculate_returns(prices)
        assert len(returns) == 0


class TestVolatilityCalculations:
    """Tests for volatility calculations."""

    def test_calculate_volatility_basic(self):
        """Test basic volatility calculation."""
        np.random.seed(42)
        returns = np.random.normal(0, 0.02, 100)  # 2% daily volatility
        prices = 100 * np.exp(np.cumsum(returns))
        price_series = pd.Series(prices)
        
        vol = calculate_volatility(price_series, window=20, annualize=252)
        
        # Check shape and basic properties
        # Volatility has len(prices)-1 because returns drops first value
        assert len(vol) == len(prices) - 1
        assert np.isnan(vol.iloc[18])  # First window-1 values should be NaN
        assert vol.iloc[-1] > 0  # Volatility should be positive
        
        # Annualized volatility should be roughly 2% * sqrt(252) ≈ 31.7%
        # But with random data, we just check it's in a reasonable range
        assert 0.1 < vol.iloc[-1] < 1.0

    def test_calculate_volatility_cone(self):
        """Test volatility cone calculation."""
        np.random.seed(42)
        returns = np.random.normal(0, 0.02, 200)
        prices = 100 * np.exp(np.cumsum(returns))
        price_series = pd.Series(prices)
        
        cone = calculate_volatility_cone(price_series)
        
        assert isinstance(cone, pd.DataFrame)
        assert "q10" in cone.columns
        assert "q50" in cone.columns
        assert "q90" in cone.columns
        assert "current" in cone.columns
        
        # Quantiles should be ordered
        for idx in cone.index:
            assert cone.loc[idx, "q10"] <= cone.loc[idx, "q50"]
            assert cone.loc[idx, "q50"] <= cone.loc[idx, "q90"]


class TestVWAPCalculations:
    """Tests for VWAP calculations."""

    def test_calculate_vwap_basic(self):
        """Test basic VWAP calculation."""
        df = pd.DataFrame({
            "high": [102, 103, 104],
            "low": [98, 99, 100],
            "close": [100, 101, 102],
            "volume": [1000, 2000, 1500],
        })
        
        vwap = calculate_vwap(df)
        
        assert len(vwap) == len(df)
        # First VWAP should equal first typical price
        expected_first = (102 + 98 + 100) / 3
        assert vwap.iloc[0] == pytest.approx(expected_first, rel=1e-10)
        
        # VWAP should be volume-weighted
        assert vwap.iloc[-1] != 102  # Should not equal last close

    def test_calculate_vwap_bands(self):
        """Test VWAP with standard deviation bands."""
        df = pd.DataFrame({
            "high": [102, 103, 104, 103, 102],
            "low": [98, 99, 100, 99, 98],
            "close": [100, 101, 102, 101, 100],
            "volume": [1000, 2000, 1500, 1000, 2000],
        })
        
        bands = calculate_vwap_bands(df, num_bands=2, std_multiplier=1.0)
        
        assert "vwap" in bands
        assert "upper_1" in bands
        assert "upper_2" in bands
        assert "lower_1" in bands
        assert "lower_2" in bands
        
        # Upper bands should be above VWAP
        assert (bands["upper_1"] >= bands["vwap"]).all()
        assert (bands["upper_2"] >= bands["upper_1"]).all()
        
        # Lower bands should be below VWAP
        assert (bands["lower_1"] <= bands["vwap"]).all()
        assert (bands["lower_2"] <= bands["lower_1"]).all()


class TestOBVCalculations:
    """Tests for OBV calculations."""

    def test_calculate_obv_basic(self):
        """Test basic OBV calculation."""
        df = pd.DataFrame({
            "close": [100, 101, 100, 99, 100, 101],
            "volume": [1000, 2000, 1500, 1000, 2000, 1500],
        })
        
        obv = calculate_obv(df)
        
        assert len(obv) == len(df)
        assert obv.iloc[0] == 1000  # First day: just volume
        assert obv.iloc[1] == 3000  # Up day: add volume
        assert obv.iloc[2] == 1500  # Down day: subtract volume
        assert obv.iloc[3] == 500   # Down day: subtract volume
        assert obv.iloc[4] == 2500  # Up day: add volume
        assert obv.iloc[5] == 4000  # Up day: add volume

    def test_calculate_obv_flat(self):
        """Test OBV when price doesn't change."""
        df = pd.DataFrame({
            "close": [100, 100, 100],
            "volume": [1000, 2000, 1500],
        })
        
        obv = calculate_obv(df)
        
        # When price doesn't change, OBV stays the same
        assert obv.iloc[0] == 1000
        assert obv.iloc[1] == 1000
        assert obv.iloc[2] == 1000


class TestVolumeProfileCalculations:
    """Tests for Volume Profile calculations."""

    def test_calculate_volume_profile(self):
        """Test volume profile calculation."""
        df = pd.DataFrame({
            "high": [102, 103, 104, 103, 102],
            "low": [98, 99, 100, 99, 98],
            "close": [100, 101, 102, 101, 100],
            "volume": [1000, 2000, 3000, 2000, 1000],
        })
        
        vol_profile, bin_edges = calculate_volume_profile(df, num_bins=10)
        
        assert len(vol_profile) == 10
        assert len(bin_edges) == 11  # num_bins + 1
        
        # Total volume should be preserved
        assert vol_profile.sum() == pytest.approx(df["volume"].sum(), rel=1e-10)
        
        # Volume should be non-negative
        assert (vol_profile >= 0).all()


class TestADXCalculations:
    """Tests for ADX calculations."""

    def test_calculate_adx_basic(self):
        """Test basic ADX calculation."""
        df = pd.DataFrame({
            "high": [102, 103, 104, 103, 102, 103, 104, 105, 104, 103],
            "low": [98, 99, 100, 99, 98, 99, 100, 101, 100, 99],
            "close": [100, 101, 102, 101, 100, 101, 102, 103, 102, 101],
        })
        
        adx_data = calculate_adx(df, period=5)
        
        assert isinstance(adx_data, pd.DataFrame)
        assert "adx" in adx_data.columns
        assert "plus_di" in adx_data.columns
        assert "minus_di" in adx_data.columns
        assert "dx" in adx_data.columns
        assert len(adx_data) == len(df)
        
        # ADX should be between 0 and 100 (ignoring NaN)
        valid_adx = adx_data["adx"].dropna()
        assert (valid_adx >= 0).all()
        assert (valid_adx <= 100).all()
        
        # +DI and -DI should be between 0 and 100 (ignoring NaN)
        valid_plus_di = adx_data["plus_di"].dropna()
        valid_minus_di = adx_data["minus_di"].dropna()
        assert (valid_plus_di >= 0).all()
        assert (valid_plus_di <= 100).all()
        assert (valid_minus_di >= 0).all()
        assert (valid_minus_di <= 100).all()


class TestDrawdownCalculations:
    """Tests for drawdown calculations."""

    def test_calculate_drawdowns_basic(self):
        """Test basic drawdown calculation."""
        equity = pd.Series([100, 105, 110, 108, 105, 100, 95, 100, 105, 110])
        
        drawdowns = calculate_drawdowns(equity)
        
        assert isinstance(drawdowns, pd.DataFrame)
        assert "depth" in drawdowns.columns
        assert "duration" in drawdowns.columns
        assert "start" in drawdowns.columns
        assert "end" in drawdowns.columns
        
        # Should have at least one drawdown
        assert len(drawdowns) >= 1
        
        # Drawdown depths should be negative
        assert (drawdowns["depth"] <= 0).all()
        
        # Durations should be positive
        assert (drawdowns["duration"] > 0).all()

    def test_calculate_drawdowns_no_drawdown(self):
        """Test drawdown calculation with always increasing equity."""
        equity = pd.Series([100, 105, 110, 115, 120, 125, 130])
        
        drawdowns = calculate_drawdowns(equity)
        
        # Should have no drawdowns
        assert len(drawdowns) == 0


class TestCalendarCalculations:
    """Tests for calendar effect calculations."""

    def test_calculate_calendar_returns_weekday(self):
        """Test weekday returns calculation."""
        dates = pd.date_range("2024-01-01", periods=100, freq="D")  # Starts on Monday
        np.random.seed(42)
        prices = 100 * np.exp(np.cumsum(np.random.normal(0.001, 0.02, 100)))
        
        df = pd.DataFrame({"close": prices}, index=dates)
        
        result = calculate_calendar_returns(df, freq="weekday")
        
        assert isinstance(result, pd.DataFrame)
        assert "period" in result.columns
        assert "mean" in result.columns
        assert "median" in result.columns
        assert "std" in result.columns
        assert "count" in result.columns
        assert "win_rate" in result.columns
        
        # Should have 7 days (Mon-Sun)
        assert len(result) <= 7

    def test_calculate_calendar_returns_month(self):
        """Test month returns calculation."""
        dates = pd.date_range("2024-01-01", periods=365, freq="D")
        np.random.seed(42)
        prices = 100 * np.exp(np.cumsum(np.random.normal(0.001, 0.02, 365)))
        
        df = pd.DataFrame({"close": prices}, index=dates)
        
        result = calculate_calendar_returns(df, freq="month")
        
        assert isinstance(result, pd.DataFrame)
        
        # Should have 12 months
        assert len(result) <= 12


class TestRelativeStrengthCalculations:
    """Tests for relative strength calculations."""

    def test_calculate_relative_strength(self):
        """Test relative strength calculation."""
        dates = pd.date_range("2024-01-01", periods=10, freq="D")
        price = pd.Series([100, 101, 102, 101, 100, 101, 102, 103, 104, 105], index=dates)
        benchmark = pd.Series([100, 100, 100, 99, 98, 99, 100, 101, 102, 103], index=dates)
        
        rs = calculate_relative_strength(price, benchmark)
        
        # RS should start at 100
        assert rs.iloc[0] == pytest.approx(100, rel=1e-10)
        
        # When price outperforms benchmark, RS should increase
        assert rs.iloc[-1] > 100  # Price went from 100 to 105, benchmark from 100 to 103

    def test_calculate_relative_strength_underperform(self):
        """Test RS when price underperforms."""
        dates = pd.date_range("2024-01-01", periods=5, freq="D")
        price = pd.Series([100, 99, 98, 97, 96], index=dates)
        benchmark = pd.Series([100, 101, 102, 103, 104], index=dates)
        
        rs = calculate_relative_strength(price, benchmark)
        
        # RS should be less than 100 when underperforming
        assert rs.iloc[-1] < 100


class TestCorrelationCalculations:
    """Tests for correlation calculations."""

    def test_calculate_correlation_matrix(self):
        """Test correlation matrix calculation."""
        np.random.seed(42)
        dates = pd.date_range("2024-01-01", periods=100, freq="D")
        
        # Create correlated series
        base_returns = np.random.normal(0, 0.02, 100)
        data = {
            "A": 100 * np.exp(np.cumsum(base_returns)),
            "B": 100 * np.exp(np.cumsum(base_returns * 0.8 + np.random.normal(0, 0.01, 100))),
            "C": 100 * np.exp(np.cumsum(np.random.normal(0, 0.02, 100))),  # Uncorrelated
        }
        
        corr = calculate_correlation_matrix(data)
        
        assert isinstance(corr, pd.DataFrame)
        assert corr.shape == (3, 3)
        
        # Diagonal should be 1
        assert corr.loc["A", "A"] == pytest.approx(1.0, rel=1e-10)
        assert corr.loc["B", "B"] == pytest.approx(1.0, rel=1e-10)
        assert corr.loc["C", "C"] == pytest.approx(1.0, rel=1e-10)
        
        # A and B should be correlated
        assert corr.loc["A", "B"] > 0.5
        
        # Correlation matrix should be symmetric
        assert corr.loc["A", "B"] == pytest.approx(corr.loc["B", "A"], rel=1e-10)
