"""Pipeline JSON envelope tests."""

import json

from chartpipe.core.pipeline_json import emit_json_line, failure_envelope, success_envelope


def test_success_envelope_shape():
    env = success_envelope(
        "ohlcv",
        artifacts={"chart": "charts/x.png"},
        meta={"startedAt": "t0", "finishedAt": "t1"},
    )
    assert env["schemaVersion"] == 1
    assert env["tool"] == "chartpipe"
    assert env["command"] == "ohlcv"
    assert env["ok"] is True
    assert env["artifacts"]["chart"] == "charts/x.png"


def test_emit_json_line_single_line(capsys):
    emit_json_line(success_envelope("stats", artifacts={"chart": "a.png"}), pretty=False)
    captured = capsys.readouterr()
    lines = captured.out.strip().splitlines()
    assert len(lines) == 1
    obj = json.loads(lines[0])
    assert obj["ok"] is True


def test_failure_envelope():
    env = failure_envelope("backtest", "INVALID_INPUT", "bad")
    assert env["ok"] is False
    assert env["error"]["code"] == "INVALID_INPUT"
