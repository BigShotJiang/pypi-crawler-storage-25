"""Error-handling and edge-case tests for chartpipe commands.

Covers:
- Missing required columns
- Empty/invalid input data
- Missing stdin data
- Insufficient assets for correlation/rs
- --from-equity flag for drawdown
- --stdin for compare
- Dry-run for compare/drawdown/regime
"""

import json
import os
import tempfile

import pandas as pd
import pytest
from click.testing import CliRunner

from chartpipe.cli import cli


def create_ohlcv_data(days=100):
    """Generate sample OHLCV data for testing."""
    import numpy as np

    np.random.seed(42)
    dates = pd.date_range(start="2024-01-01", periods=days, freq="D")
    returns = np.random.normal(0.001, 0.02, days)
    close = 100 * np.exp(np.cumsum(returns))
    high = close * (1 + np.abs(np.random.normal(0, 0.01, days)))
    low = close * (1 - np.abs(np.random.normal(0, 0.01, days)))
    open_price = low + (high - low) * np.random.random(days)
    volume = np.random.randint(1000, 10000, days)
    df = pd.DataFrame({
        "timestamp": [d.isoformat() for d in dates],
        "open": open_price,
        "high": high,
        "low": low,
        "close": close,
        "volume": volume,
    })
    return df


def create_multi_asset_data(days=100):
    """Generate sample multi-asset data for testing."""
    assets = {}
    for symbol in ["BTCUSDT", "ETHUSDT", "ADAUSDT"]:
        df = create_ohlcv_data(days)
        assets[symbol] = df.to_dict("records")
    return assets


def _write_json_file(data):
    """Write data to a temp JSON file, return path. Caller must unlink."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        return f.name


# =============================================================================
# Compare — error cases and edge cases
# =============================================================================

class TestCompareErrors:
    """Error cases for compare command."""

    def test_compare_correlation_requires_two_assets(self):
        """Correlation type needs at least 2 assets."""
        data = {"BTCUSDT": create_ohlcv_data(50).to_dict("records")}
        path = _write_json_file(data)
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "compare", "--data", path, "--type", "correlation"
            ])
            assert result.exit_code == 2
            assert "At least 2 assets required" in result.output
        finally:
            os.unlink(path)

    def test_compare_empty_dict_returns_error(self):
        """Empty dict input should produce a clear error."""
        path = _write_json_file({})
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "compare", "--data", path, "--type", "price"
            ])
            assert result.exit_code != 0
            assert "INVALID_INPUT" in result.output or "Error" in result.output or "No valid" in result.output
        finally:
            os.unlink(path)

    def test_compare_stdin(self):
        """Compare command accepts data via stdin."""
        data = create_multi_asset_data(50)
        runner = CliRunner()
        with tempfile.TemporaryDirectory() as output_dir:
            result = runner.invoke(cli, [
                "-o", output_dir,
                "compare", "--stdin", "--type", "price", "--normalize"
            ], input=json.dumps(data))
            assert result.exit_code == 0
            assert "Chart saved:" in result.output

    def test_compare_stdin_empty(self):
        """Compare with empty stdin should fail with INVALID_INPUT."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "compare", "--stdin"
        ], input="")
        assert result.exit_code == 1
        assert "No input data" in result.output

    def test_compare_dry_run(self):
        """Compare --dry-run validates without generating charts."""
        data = create_multi_asset_data(50)
        runner = CliRunner()
        result = runner.invoke(cli, [
            "compare", "--stdin", "--type", "price", "--dry-run"
        ], input=json.dumps(data))
        assert result.exit_code == 0
        assert "Dry run OK" in result.output


# =============================================================================
# Volume — error cases and edge cases
# =============================================================================

class TestVolumeErrors:
    """Error cases for volume command."""

    def test_volume_vwap_requires_high_low(self):
        """VWAP type needs high/low columns."""
        df = create_ohlcv_data(50)[["timestamp", "close", "volume"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "volume", "--data", path, "--type", "vwap"
            ])
            assert result.exit_code == 2
            assert "Missing required columns" in result.output
        finally:
            os.unlink(path)

    def test_volume_profile_requires_high_low(self):
        """Volume profile type needs high/low columns."""
        df = create_ohlcv_data(50)[["timestamp", "close", "volume"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "volume", "--data", path, "--type", "profile"
            ])
            assert result.exit_code == 2
            assert "Missing required columns" in result.output
        finally:
            os.unlink(path)

    def test_volume_obv_only_needs_close_volume(self):
        """OBV type only needs close + volume (not high/low)."""
        df = create_ohlcv_data(50)[["timestamp", "close", "volume"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            with tempfile.TemporaryDirectory() as output_dir:
                result = runner.invoke(cli, [
                    "-o", output_dir,
                    "volume", "--data", path, "--type", "obv"
                ])
                assert result.exit_code == 0
                assert "Chart saved:" in result.output
        finally:
            os.unlink(path)

    def test_volume_empty_data(self):
        """Empty input data should fail cleanly."""
        path = _write_json_file([])
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "volume", "--data", path, "--type", "vwap"
            ])
            assert result.exit_code == 2
            assert "No valid data" in result.output
        finally:
            os.unlink(path)

    def test_volume_stdin_empty(self):
        """Volume with empty stdin should fail with INVALID_INPUT."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "volume", "--stdin"
        ], input="")
        assert result.exit_code == 1
        assert "No input data" in result.output


# =============================================================================
# Drawdown — error cases and edge cases
# =============================================================================

class TestDrawdownErrors:
    """Error cases for drawdown command."""

    def test_drawdown_from_equity(self):
        """Drawdown with --from-equity reads equity column directly."""
        equity_df = pd.DataFrame({
            "timestamp": [f"2024-01-{(i % 28) + 1:02d}" for i in range(50)],
            "equity": [100.0 + i * 0.5 for i in range(50)],
        })
        path = _write_json_file(equity_df.to_dict("records"))
        try:
            runner = CliRunner()
            with tempfile.TemporaryDirectory() as output_dir:
                result = runner.invoke(cli, [
                    "-o", output_dir,
                    "drawdown", "--data", path, "--from-equity", "--type", "underwater"
                ])
                assert result.exit_code == 0
                assert "Chart saved:" in result.output
        finally:
            os.unlink(path)

    def test_drawdown_from_equity_uses_close_as_fallback(self):
        """Drawdown --from-equity falls back to close if no equity column."""
        df = create_ohlcv_data(50)[["timestamp", "close"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            with tempfile.TemporaryDirectory() as output_dir:
                result = runner.invoke(cli, [
                    "-o", output_dir,
                    "drawdown", "--data", path, "--from-equity", "--type", "underwater"
                ])
                assert result.exit_code == 0
                assert "Chart saved:" in result.output
        finally:
            os.unlink(path)

    def test_drawdown_no_close_or_equity(self):
        """Drawdown --from-equity fails cleanly if no close or equity column."""
        df = pd.DataFrame({
            "timestamp": [f"2024-01-{(i % 28) + 1:02d}" for i in range(50)],
            "open": [100.0 + i * 0.5 for i in range(50)],
        })
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "drawdown", "--data", path, "--from-equity", "--type", "underwater"
            ])
            assert result.exit_code == 2
            assert "equity" in result.output.lower() or "Error" in result.output
        finally:
            os.unlink(path)

    def test_drawdown_dry_run(self):
        """Drawdown --dry-run validates without generating charts."""
        df = create_ohlcv_data(50)
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "drawdown", "--data", path, "--dry-run", "--type", "underwater"
            ])
            assert result.exit_code == 0
            assert "Dry run OK" in result.output
        finally:
            os.unlink(path)

    def test_drawdown_stdin_empty(self):
        """Drawdown with empty stdin should fail with INVALID_INPUT."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "drawdown", "--stdin"
        ], input="")
        assert result.exit_code == 1
        assert "No input data" in result.output


# =============================================================================
# Calendar — error cases and edge cases
# =============================================================================

class TestCalendarErrors:
    """Error cases for calendar command."""

    def test_calendar_unparseable_dates_fail_cleanly(self):
        """Calendar fails cleanly when date strings can't be parsed."""
        df = pd.DataFrame({
            "timestamp": ["not-a-date"] * 50,
            "close": [100 + i for i in range(50)],
        })
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "calendar", "--data", path, "--type", "weekday"
            ])
            # Should exit non-zero and emit a failure envelope or error message
            assert result.exit_code == 1
            assert "Error" in result.output or "INVALID_INPUT" in result.output or "No valid datetime" in result.output
        finally:
            os.unlink(path)

    def test_calendar_stdin_empty(self):
        """Calendar with empty stdin should fail with INVALID_INPUT."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "calendar", "--stdin"
        ], input="")
        assert result.exit_code == 1
        assert "No input data" in result.output


# =============================================================================
# Regime — error cases and edge cases
# =============================================================================

class TestRegimeErrors:
    """Error cases for regime command."""

    def test_regime_trend_requires_high_low(self):
        """Trend regime needs high/low columns."""
        df = create_ohlcv_data(50)[["timestamp", "close"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "regime", "--data", path, "--type", "trend"
            ])
            assert result.exit_code == 2
            assert "Missing required columns" in result.output
        finally:
            os.unlink(path)

    def test_regime_ma_cross_requires_high_low(self):
        """MA cross regime needs high/low columns."""
        df = create_ohlcv_data(50)[["timestamp", "close"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "regime", "--data", path, "--type", "ma-cross"
            ])
            assert result.exit_code == 2
            assert "Missing required columns" in result.output
        finally:
            os.unlink(path)

    def test_regime_volatility_only_needs_close(self):
        """Volatility regime only needs close column."""
        df = create_ohlcv_data(50)[["timestamp", "close"]]
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            with tempfile.TemporaryDirectory() as output_dir:
                result = runner.invoke(cli, [
                    "-o", output_dir,
                    "regime", "--data", path, "--type", "volatility"
                ])
                assert result.exit_code == 0
                assert "Chart saved:" in result.output
        finally:
            os.unlink(path)

    def test_regime_stdin_empty(self):
        """Regime with empty stdin should fail with INVALID_INPUT."""
        runner = CliRunner()
        result = runner.invoke(cli, [
            "regime", "--stdin"
        ], input="")
        assert result.exit_code == 1
        assert "No input data" in result.output

    def test_regime_dry_run(self):
        """Regime --dry-run validates without generating charts."""
        df = create_ohlcv_data(50)
        path = _write_json_file(df.to_dict("records"))
        try:
            runner = CliRunner()
            result = runner.invoke(cli, [
                "regime", "--data", path, "--type", "trend", "--dry-run"
            ])
            assert result.exit_code == 0
            assert "Dry run OK" in result.output
        finally:
            os.unlink(path)


# =============================================================================
# Pipeline JSON — error envelope parsing
# =============================================================================

class TestPipelineJsonErrors:
    """Error cases for pipeline JSON envelope."""

    def test_failure_envelope_contains_code(self):
        """failure_envelope includes the error code."""
        from chartpipe.core.pipeline_json import failure_envelope
        result = failure_envelope("ohlcv", "SCHEMA_MISMATCH", "missing close column")
        assert result["ok"] is False
        assert result["error"]["code"] == "SCHEMA_MISMATCH"
        assert "missing close column" in result["error"]["message"]

    def test_upstream_failure_detected(self):
        """parse_backtest_payload detects upstream ok=false."""
        from chartpipe.core.backtest_input import parse_backtest_payload
        upstream = {
            "tool": "quantpipe",
            "ok": False,
            "error": {"code": "INVALID_DATA", "message": "exchange returned empty"}
        }
        with pytest.raises(ValueError, match="ok=false"):
            parse_backtest_payload(upstream)
