from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='chartpipe',
    version='0.1.1',
    author='Your Name',
    author_email='your.email@example.com',
    description='Chart visualization toolkit for quantitative trading analysis',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/yourusername/chartpipe',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
    install_requires=[
        'pandas>=2.0.0',
        'numpy>=1.24.0',
        'click>=8.0.0',
        'matplotlib>=3.7.0',
        'mplfinance>=0.12.10b0',
        'seaborn>=0.12.0',
    ],
    entry_points={
        'console_scripts': [
            'chartpipe=chartpipe.cli:cli',
        ],
    },
    python_requires='>=3.9',
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Financial and Insurance Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
