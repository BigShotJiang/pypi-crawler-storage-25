"""Process exit codes aligned with repo rule.md (§3.3)."""

# 0 success; 1 generic (args, IO); 2 input/schema mismatch; 3 upstream unavailable
EXIT_OK = 0
EXIT_GENERAL = 1
EXIT_SCHEMA = 2
EXIT_UPSTREAM = 3

EXIT_CODE_HELP = """
Exit codes:
  0  Success
  1  General failure (invalid arguments, I/O error)
  2  Input format / schema mismatch
  3  Upstream dependency unavailable (e.g. missing optional package)
"""
