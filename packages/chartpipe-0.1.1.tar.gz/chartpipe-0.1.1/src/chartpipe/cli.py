#!/usr/bin/env python3
"""CLI entry point for ChartPipe."""

import logging
import sys

import click

from .cli_exit import EXIT_CODE_HELP
from .commands.ohlcv import ohlcv_command
from .commands.backtest import backtest_chart_command
from .commands.indicators import indicators_command
from .commands.stats import stats_command
from .commands.volatility import volatility_command
from .commands.compare import compare_command
from .commands.volume import volume_command
from .commands.drawdown import drawdown_command
from .commands.calendar import calendar_command
from .commands.regime import regime_command
from .commands.sharpe import sharpe_command
from .commands.trades import trades_command
from .commands.heatmap import heatmap_command
from .commands.orderbook import orderbook_command
from .commands.report import report_command


def _configure_verbose(verbose: bool) -> None:
    if verbose:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(levelname)s %(name)s: %(message)s",
            stream=sys.stderr,
        )
    else:
        logging.basicConfig(level=logging.WARNING, handlers=[logging.NullHandler()])


@click.group(epilog=EXIT_CODE_HELP)
@click.version_option(version="0.1.0", prog_name="chartpipe")
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    default=False,
    help="Output results as JSON for pipeline integration",
)
@click.option(
    "--output-dir",
    "-o",
    default="./charts",
    help="Directory to save generated charts",
)
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Validate input only; do not write chart files (subcommands may still parse data)",
)
@click.pass_context
def cli(ctx, json_output, output_dir, verbose, dry_run):
    """ChartPipe - Chart visualization toolkit for quantitative trading.

    Designed to work seamlessly with seamflux CLI and quantpipe via Unix pipes.

    Auto-detects data formats: Binance, Polymarket, Uniswap, generic OHLCV.

    See repository rule.md for pipeline JSON contract (schemaVersion, artifacts, exit codes).

    Examples:

        seamflux invoke binance fetchOhlcv --pipe -p symbol=BTC/USDT -p interval=1h -p limit=200 | chartpipe ohlcv --stdin

        quantpipe backtest ... --run-dir runs/id --json
        chartpipe backtest --run-dir runs/id --json

        chartpipe ohlcv --stdin --json
    """
    _configure_verbose(verbose)
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output
    ctx.obj["output_dir"] = output_dir
    ctx.obj["verbose"] = verbose
    ctx.obj["dry_run"] = dry_run


# Register commands
cli.add_command(ohlcv_command)
cli.add_command(backtest_chart_command)
cli.add_command(indicators_command)
cli.add_command(stats_command)
cli.add_command(volatility_command)
cli.add_command(compare_command)
cli.add_command(volume_command)
cli.add_command(drawdown_command)
cli.add_command(calendar_command)
cli.add_command(regime_command)
cli.add_command(sharpe_command)
cli.add_command(trades_command)
cli.add_command(heatmap_command)
cli.add_command(orderbook_command)
cli.add_command(report_command)


if __name__ == "__main__":
    cli()
