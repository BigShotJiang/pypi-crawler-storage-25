"""ChartPipe - Chart visualization toolkit for quantitative trading analysis.

Designed to work seamlessly with seamflux CLI and quantpipe.
"""

__version__ = '0.1.0'
