#!/usr/bin/env python3
"""Sharpe ratio and aggregate stats chart command."""

import logging
import os
import sys

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.backtest_input import (
    load_from_run_dir,
    parse_backtest_payload,
    title_from_summary,
)
from ..core.charts import ChartEngine
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)


@click.command(name="sharpe")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to backtest result file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option(
    "--run-dir",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Load equity.csv from a runs/<id>/ directory",
)
@click.option("--window", "-w", default=20, help="Rolling window for Sharpe calculation (default: 20)")
@click.option("--rf", "rf_rate", default=0.0, help="Annualized risk-free rate (default: 0)")
@click.option("--title", "-t", default=None, help="Chart title (auto-generated if not provided)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def sharpe_command(
    ctx,
    data,
    input_file,
    use_stdin,
    run_dir,
    window,
    rf_rate,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate Sharpe ratio and aggregate performance statistics charts.

    Produces rolling Sharpe ratio over time plus a panel with aggregate stats
    (Sharpe, Sortino, Calmar, Max Drawdown, Win Rate).

    Examples:
        chartpipe sharpe --run-dir runs/my-run
        chartpipe sharpe --data backtest.json --stdin
        chartpipe sharpe --run-dir runs/my-run --window 30 --rf 0.02
        chartpipe sharpe --run-dir runs/my-run --json
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "sharpe"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()
    df = None
    summary_block = None

    try:
        if run_dir:
            df, _trades, meta = load_from_run_dir(run_dir)
            summary_block = meta.get("summary")
            log.debug("Loaded backtest data from run-dir %s", run_dir)
        elif use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data, --run-dir, or pipe JSON via stdin.",
                    EXIT_GENERAL,
                )
            df, _trades, _meta = parse_backtest_payload(input_text, cwd=cwd)
        else:
            with open(path, encoding="utf-8") as f:
                df, _trades, _meta = parse_backtest_payload(f.read(), cwd=cwd)
    except FileNotFoundError as e:
        fail_json("MISSING_FILE", str(e), EXIT_GENERAL)
    except ValueError as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)
    except Exception as e:
        log.exception("sharpe input failed")
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    if "equity" not in df.columns:
        fail_json(
            "INVALID_INPUT",
            "Error: No 'equity' column found. Provide backtest results with equity curve.",
            EXIT_SCHEMA,
        )

    if len(df) < window:
        fail_json(
            "INVALID_INPUT",
            f"Need at least {window} data points for rolling Sharpe. Got {len(df)}.",
            EXIT_SCHEMA,
        )

    equity = df["equity"].astype(float)

    chart_title = title or title_from_summary(summary_block, "Sharpe Ratio Analysis")

    if dry_run:
        click.echo(
            f"Dry run OK: would plot Sharpe chart (window={window}, rf={rf_rate}, {len(df)} equity points)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"rows": len(df), "window": window, "rf_rate": rf_rate},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)
    try:
        chart_path = engine.plot_sharpe(
            equity,
            window=window,
            rf_rate=rf_rate,
            title=chart_title,
        )
    except Exception as e:
        log.exception("plot_sharpe failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)

    finished = utc_now_iso()
    rel = os.path.relpath(chart_path, cwd)
    if json_output:
        emit_json_line(
            success_envelope(
                command,
                artifacts={"chart": rel},
                meta={"startedAt": started, "finishedAt": finished},
            )
        )
    else:
        click.echo(f"Chart saved: {chart_path}")
