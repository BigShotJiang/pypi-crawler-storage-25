#!/usr/bin/env python3
"""Order book / market depth visualization command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.charts import ChartEngine
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)


def parse_orderbook(raw) -> dict:
    """Parse order book JSON from various formats.

    Binance-style:
      {"lastUpdateId": 123, "bids": [["price", "qty"], ...], "asks": [...]}

    Generic:
      {"timestamp": "...", "bids": [[price, qty], ...], "asks": [[price, qty], ...]}
      {"bid": [[price, qty], ...], "ask": [[price, qty], ...]}

    Returns dict with bids (list of [price, qty]) and asks.
    """
    import json as _json

    if isinstance(raw, str):
        try:
            raw = _json.loads(raw)
        except _json.JSONDecodeError:
            raise ValueError(f"Invalid JSON: {raw[:100]}")

    if not isinstance(raw, dict):
        raise ValueError(f"Expected dict for orderbook, got {type(raw).__name__}")

    # Unwrap result wrapper
    if "result" in raw:
        raw = raw["result"]

    # Locate bids and asks
    bids = raw.get("bids") or raw.get("bid") or []
    asks = raw.get("asks") or raw.get("ask") or []

    def parse_levels(levels):
        result = []
        for item in levels:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                try:
                    price = float(item[0])
                    qty = float(item[1])
                    result.append((price, qty))
                except (ValueError, TypeError):
                    continue
        return result

    return {
        "bids": parse_levels(bids),
        "asks": parse_levels(asks),
    }


@click.command(name="orderbook")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to order book JSON file")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read order book from stdin")
@click.option(
    "--type",
    "ob_type",
    type=click.Choice(["depth", "imbalance", "both"]),
    default="depth",
    help="Chart type: depth curve, imbalance ratio, or both",
)
@click.option(
    "--levels",
    "-n",
    default=20,
    help="Number of price levels to show (default 20)",
)
@click.option("--title", "-t", default=None, help="Chart title")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def orderbook_command(
    ctx,
    data,
    input_file,
    use_stdin,
    ob_type,
    levels,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Visualize market depth (bid/ask order book) as a depth curve.

    Renders:
      depth:  Bid and ask depth curves (cumulative volume by price level)
      imbalance: Bid/ask volume imbalance ratio by level
      both:    Both panels

    Examples:
        chartpipe orderbook --data ob.json
        chartpipe orderbook --data ob.json --type imbalance --levels 50
        chartpipe orderbook --data ob.json --type both --json
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "orderbook"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            raw_text = sys.stdin.read()
            if not raw_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No order book data provided. Use --data or pipe JSON via stdin.",
                    EXIT_GENERAL,
                )
            ob = parse_orderbook(raw_text)
        else:
            with open(path, encoding="utf-8") as f:
                ob = parse_orderbook(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if not ob["bids"] and not ob["asks"]:
        fail_json("INVALID_INPUT", "Error: No bid/ask levels found in order book data.", EXIT_SCHEMA)

    if dry_run:
        n_bids = len(ob["bids"])
        n_asks = len(ob["asks"])
        click.echo(
            f"Dry run OK: would plot orderbook type={ob_type} ({n_bids} bids, {n_asks} asks, levels={levels})",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"bids": n_bids, "asks": n_asks, "levels": levels, "type": ob_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel(p):
        try:
            return os.path.relpath(p, cwd)
        except ValueError:
            return p

    try:
        if ob_type == "both":
            results = {}
            results["depth"] = engine.plot_orderbook_depth(ob, n_levels=levels, title=title)
            results["imbalance"] = engine.plot_orderbook_imbalance(ob, n_levels=levels, title=title)
            finished = utc_now_iso()
            artifacts = {k: _rel(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for k, p in results.items():
                    click.echo(f"{k.title()} chart saved: {p}")
        elif ob_type == "imbalance":
            chart_path = engine.plot_orderbook_imbalance(ob, n_levels=levels, title=title)
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
        else:
            chart_path = engine.plot_orderbook_depth(ob, n_levels=levels, title=title)
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except Exception as e:
        log.exception("plot_orderbook failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
