#!/usr/bin/env python3
"""Multi-page PDF report generation command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.backtest_input import load_from_run_dir, parse_backtest_payload, title_from_summary
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)

VALID_PAGES = {"equity", "drawdown", "indicators", "sharpe", "summary"}


def _generate_report(charts_engine, df, trades, summary_block, pages, output_path, theme):
    """Render charts into a PDF using matplotlib PdfPages.

    Returns:
        Absolute path to the saved PDF file.
    """
    from matplotlib.backends.backend_pdf import PdfPages

    pages_to_render = pages if pages else list(VALID_PAGES)

    with PdfPages(output_path) as pdf:
        for page in pages_to_render:
            if page == "summary":
                fig = charts_engine._make_summary_page(df, summary_block)
                pdf.savefig(fig, bbox_inches="tight")
                charts_engine._close_fig(fig)

            elif page == "equity":
                if "equity" in df.columns:
                    fig = charts_engine._plot_equity_chart(df)
                    pdf.savefig(fig, bbox_inches="tight")
                    charts_engine._close_fig(fig)

            elif page == "drawdown":
                if "equity" in df.columns:
                    fig = charts_engine._plot_drawdown_chart(df)
                    pdf.savefig(fig, bbox_inches="tight")
                    charts_engine._close_fig(fig)

            elif page == "sharpe":
                if "equity" in df.columns:
                    fig = charts_engine._plot_sharpe_simple(df)
                    pdf.savefig(fig, bbox_inches="tight")
                    charts_engine._close_fig(fig)

            elif page == "indicators":
                # RSI page (most common)
                fig = charts_engine._plot_indicator_simple(df, "rsi")
                pdf.savefig(fig, bbox_inches="tight")
                charts_engine._close_fig(fig)

    return output_path


@click.command(name="report")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to backtest result JSON file")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read backtest data from stdin")
@click.option(
    "--run-dir",
    type=click.Path(exists=True, file_okay=False, dir_okay=True, path_type=str),
    default=None,
    help="Load equity.csv / trades.csv from runs/<id>/ directory",
)
@click.option(
    "--pages",
    "-p",
    multiple=True,
    type=click.Choice(list(VALID_PAGES)),
    default=[],
    help=f"Pages to include: {' / '.join(sorted(VALID_PAGES))}. All pages if omitted.",
)
@click.option(
    "--output",
    "-O",
    type=click.Path(file_okay=True, dir_okay=False, path_type=str),
    default=None,
    help="Output PDF path (default: <output-dir>/report_<timestamp>.pdf)",
)
@click.option("--title", "-t", default=None, help="Report title")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save PDF)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no PDF file)",
)
@click.pass_context
def report_command(
    ctx,
    data,
    input_file,
    use_stdin,
    run_dir,
    pages,
    output,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate a multi-page PDF report for a backtest run.

    Pages available:
      equity     - Equity curve over time
      drawdown   - Drawdown / underwater curve
      sharpe     - Rolling Sharpe ratio + aggregate stats
      indicators - RSI chart (most recent indicator)
      summary    - Text summary with key metrics

    All pages are included by default. Use --pages to select specific pages.

    Examples:
        chartpipe report --run-dir runs/my-run
        chartpipe report --run-dir runs/my-run --pages equity drawdown sharpe
        chartpipe report --run-dir runs/my-run --output my-report.pdf --json
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "report"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    # Load data
    df = None
    trades = []
    summary_block = None

    try:
        if run_dir:
            df, trades, meta = load_from_run_dir(run_dir)
            summary_block = meta.get("summary")
        elif use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No data provided. Use --data, --run-dir, or pipe JSON via stdin.",
                    EXIT_GENERAL,
                )
            df, trades, _meta = parse_backtest_payload(input_text, cwd=cwd)
        else:
            with open(path, encoding="utf-8") as f:
                df, trades, _meta = parse_backtest_payload(f.read(), cwd=cwd)
    except FileNotFoundError as e:
        fail_json("MISSING_FILE", str(e), EXIT_GENERAL)
    except ValueError as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)
    except Exception as e:
        log.exception("report input failed")
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df is None or df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    # Validate requested pages
    invalid = set(pages) - VALID_PAGES
    if invalid:
        fail_json(
            "INVALID_INPUT",
            f"Unknown page(s): {', '.join(sorted(invalid))}. Valid: {', '.join(sorted(VALID_PAGES))}",
            EXIT_SCHEMA,
        )

    # Determine output path
    if not output:
        os.makedirs(output_dir, exist_ok=True)
        ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        output = os.path.join(output_dir, f"report_{ts}.pdf")

    report_title = title or title_from_summary(summary_block, "Backtest Report")

    if dry_run:
        click.echo(
            f"Dry run OK: would generate PDF report ({len(pages) or 'all'} pages, output={output})",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"pages": list(pages) if pages else list(VALID_PAGES)},
                )
            )
        return

    try:
        with pd.Timestamp.now().strftime("%Y%m%d_%H%M%S"):
            pass  # just ensure we can use this

        os.makedirs(os.path.dirname(output) or ".", exist_ok=True)

        engine = ChartEngine(output_dir=os.path.dirname(output) or ".", theme=theme)

        # Generate charts into the PDF
        output = _generate_report(
            charts_engine=engine,
            df=df,
            trades=trades,
            summary_block=summary_block,
            pages=list(pages) if pages else None,
            output_path=output,
            theme=theme,
        )

    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_GENERAL)
    except Exception as e:
        log.exception("report generation failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)

    finished = utc_now_iso()
    rel = os.path.relpath(output, cwd)
    if json_output:
        emit_json_line(
            success_envelope(
                command,
                artifacts={"report": rel},
                meta={"startedAt": started, "finishedAt": finished},
            )
        )
    else:
        click.echo(f"Report saved: {output}")
