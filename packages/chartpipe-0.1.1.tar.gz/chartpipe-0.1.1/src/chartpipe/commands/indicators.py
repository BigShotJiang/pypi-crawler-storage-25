#!/usr/bin/env python3
"""Technical indicators chart command."""

import logging
import os
import sys

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.range_filter import parse_range, filter_by_range, range_to_str

log = logging.getLogger(__name__)


def parse_input_data(input_data):
    """Parse input data from various formats."""
    data = parse_input_text(input_data)
    df = json_payload_to_dataframe(data)
    df = normalize_ohlcv_columns(df)
    return normalize_timestamp_column_to_index(df)


def calculate_rsi(prices, period=14):
    """Calculate RSI indicator."""
    delta = prices.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def calculate_macd(prices, fast=12, slow=26, signal=9):
    """Calculate MACD indicator."""
    ema_fast = prices.ewm(span=fast).mean()
    ema_slow = prices.ewm(span=slow).mean()
    macd = ema_fast - ema_slow
    macd_signal = macd.ewm(span=signal).mean()
    histogram = macd - macd_signal
    return macd, macd_signal, histogram


def calculate_bollinger(prices, period=20, std_dev=2):
    """Calculate Bollinger Bands."""
    middle = prices.rolling(window=period).mean()
    std = prices.rolling(window=period).std()
    upper = middle + (std * std_dev)
    lower = middle - (std * std_dev)
    return upper, middle, lower


@click.command(name="indicators")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to OHLCV data file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from standard input")
@click.option(
    "--indicator",
    "-i",
    "indicator_type",
    type=click.Choice(["rsi", "macd", "bb", "all"]),
    default="rsi",
    help="Indicator type to plot",
)
@click.option("--title", "-t", help="Chart title (auto-generated if not provided)")
@click.option("--period", "-p", default=14, help="Indicator period (for RSI)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--range",
    "range_str",
    default=None,
    help="Date range to filter data: 7d, 1mo, 3mo, 6mo, 1y, ytd, 2024, 2023-2024, 2024Q1, 2024-03, 2024-03-15",
)
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def indicators_command(
    ctx,
    data,
    input_file,
    use_stdin,
    indicator_type,
    title,
    period,
    theme,
    range_str,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate technical indicator charts."""
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "indicators"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe data via stdin.",
                    EXIT_GENERAL,
                )
            df = parse_input_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                df = parse_input_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    # Apply date range filter if specified
    if range_str:
        try:
            date_range = parse_range(range_str)
            df = filter_by_range(df, date_range)
            if df.empty:
                fail_json(
                    "INVALID_INPUT",
                    f"No data found in range '{range_str}' ({range_to_str(date_range)}).",
                    EXIT_SCHEMA,
                )
        except ValueError as e:
            fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if "close" in df.columns:
        if indicator_type == "rsi" or indicator_type == "all":
            if "rsi" not in df.columns:
                df["rsi"] = calculate_rsi(df["close"], period)

        if indicator_type == "macd" or indicator_type == "all":
            if "macd" not in df.columns:
                df["macd"], df["signal"], df["histogram"] = calculate_macd(df["close"])

        if indicator_type == "bb" or indicator_type == "all":
            if "bb_upper" not in df.columns:
                df["bb_upper"], df["bb_middle"], df["bb_lower"] = calculate_bollinger(df["close"])

    if dry_run:
        click.echo(
            f"Dry run OK: would plot indicator chart(s) type={indicator_type} ({len(df)} rows)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"rows": len(df), "indicator": indicator_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    try:
        if indicator_type == "all":
            results = {}
            for ind in ["rsi", "macd", "bb"]:
                chart_title = title or f"{ind.upper()} Indicator"
                results[ind] = engine.plot_indicator(df, indicator=ind, title=chart_title)
            finished = utc_now_iso()
            artifacts = {k: os.path.relpath(v, cwd) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for ind, pth in results.items():
                    click.echo(f"{ind.upper()} chart saved: {pth}")
        else:
            chart_title = title or f"{indicator_type.upper()} Indicator"
            chart_path = engine.plot_indicator(df, indicator=indicator_type, title=chart_title)
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": os.path.relpath(chart_path, cwd)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_indicator failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
