#!/usr/bin/env python3
"""Trade annotation overlay on OHLCV price chart command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)


def parse_trades_from_signal(raw) -> tuple:
    """Parse trade/signal list from quantpipe signal JSON or raw trade list.

    Returns (trades_list, raw_data) where raw_data can be used as OHLCV
    if it contains price columns.
    """
    data = raw if isinstance(raw, dict) else parse_input_text(raw)

    # quantpipe signal output: {"ok": true, "signal": "buy", "trades": [...]}
    if isinstance(data, dict) and "signal" in data:
        trades = data.get("trades", [])
        return trades if isinstance(trades, list) else [], data

    # unwrap result wrapper
    if isinstance(data, dict) and "result" in data:
        inner = data["result"]
        if isinstance(inner, dict) and "signal" in inner:
            return inner.get("trades", []), inner

    # plain list of trades
    if isinstance(data, list):
        return data, data

    raise ValueError(f"Cannot parse trades from input type: {type(data).__name__}")


@click.command(name="trades")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to trade/signal JSON file")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read trades from stdin")
@click.option(
    "--ohlcv-data",
    "-c",
    type=click.Path(exists=True),
    help="OHLCV price data file (for candlestick chart). Required when --stdin is used without piped OHLCV.",
)
@click.option(
    "--ma",
    "ma_periods",
    multiple=True,
    type=int,
    default=[],
    help="Moving average periods to overlay (repeatable)",
)
@click.option("--title", "-t", default=None, help="Chart title")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def trades_command(
    ctx,
    data,
    input_file,
    use_stdin,
    ohlcv_data,
    ma_periods,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Overlay trade / signal markers on a price chart.

    Draws BUY (green up-arrow) and SELL (red down-arrow) markers on an OHLCV
    candlestick or line chart, optionally with moving averages.

    Input formats supported:
      - quantpipe signal JSON: {ok, signal: "buy"|"sell"|"hold", trades: [...]}
      - Generic trade list: [{timestamp, action, price, size}, ...]
      - Pipe OHLCV to --ohlcv-data while piping signals to --stdin

    Examples:
        quantpipe signal --stdin --strategy ma_cross --json | chartpipe trades --stdin --ohlcv-data ohlcv.json
        chartpipe trades --data trades.json --ohlcv-data btc.json
        chartpipe trades --data trades.json --ohlcv-data btc.json --ma 20 --ma 50
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "trades"
    trade_path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    # --- Read trade/signal input once ---
    raw_input = None
    try:
        if use_stdin or not trade_path:
            raw_input = sys.stdin.read()
            if not raw_input.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe JSON via stdin.",
                    EXIT_GENERAL,
                )
        elif trade_path:
            with open(trade_path, encoding="utf-8") as f:
                raw_input = f.read()
    except OSError as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    # Parse trades and check if same input can serve as OHLCV
    try:
        trades, signal_payload = parse_trades_from_signal(raw_input)
    except (ValueError, TypeError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if not trades:
        fail_json("INVALID_INPUT", "Error: No valid trade entries found.", EXIT_SCHEMA)

    # --- Read OHLCV data ---
    if ohlcv_data:
        try:
            with open(ohlcv_data, encoding="utf-8") as f:
                ohlcv_raw = f.read()
        except OSError as e:
            fail_json("INVALID_INPUT", f"Cannot read OHLCV file: {e}", EXIT_SCHEMA)
    elif isinstance(signal_payload, dict) and signal_payload.get("signal") is not None:
        # quantpipe signal output that embeds OHLCV or uses trades as price proxy
        # Use the signal_payload dict itself for OHLCV if it has close column
        ohlcv_raw = signal_payload
    else:
        fail_json(
            "INVALID_INPUT",
            "Error: OHLCV data required. Use --ohlcv-data to specify the price chart data, "
            "or pipe quantpipe signal output that includes OHLCV.",
            EXIT_GENERAL,
        )

    try:
        ohlcv_df = json_payload_to_dataframe(ohlcv_raw)
        ohlcv_df = normalize_ohlcv_columns(ohlcv_df)
        ohlcv_df = normalize_timestamp_column_to_index(ohlcv_df)
    except Exception as e:
        fail_json("INVALID_INPUT", f"Error parsing OHLCV data: {e}", EXIT_SCHEMA)

    if ohlcv_df.empty:
        fail_json("INVALID_INPUT", "Error: No valid OHLCV data found.", EXIT_SCHEMA)
    if "close" not in ohlcv_df.columns:
        fail_json("INVALID_INPUT", "Error: OHLCV data must have a 'close' column.", EXIT_SCHEMA)

    # Parse trade timestamps
    for trade in trades:
        ts = trade.get("timestamp") or trade.get("time") or trade.get("t")
        if ts:
            trade["_ts"] = pd.to_datetime(ts, errors="coerce")

    if dry_run:
        click.echo(
            f"Dry run OK: would plot trade chart ({len(trades)} trades, {len(ohlcv_df)} price rows)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"trades": len(trades), "price_rows": len(ohlcv_df)},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)
    try:
        chart_path = engine.plot_trades(
            ohlcv_df,
            trades=trades,
            title=title or f"Trade Markers ({len(trades)} trades)",
            ma_periods=list(ma_periods) if ma_periods else None,
        )
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_trades failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)

    finished = utc_now_iso()
    rel = os.path.relpath(chart_path, cwd)
    if json_output:
        emit_json_line(
            success_envelope(
                command,
                artifacts={"chart": rel},
                meta={"startedAt": started, "finishedAt": finished},
            )
        )
    else:
        click.echo(f"Chart saved: {chart_path}")
