#!/usr/bin/env python3
"""Volume analysis chart command."""

import logging
import os
import sys

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.range_filter import parse_range, filter_by_range, range_to_str

log = logging.getLogger(__name__)


def parse_input_data(input_data):
    """Parse input data from various formats."""
    data = parse_input_text(input_data)
    df = json_payload_to_dataframe(data)
    df = normalize_ohlcv_columns(df)
    return normalize_timestamp_column_to_index(df)


@click.command(name="volume")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to OHLCV data file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from standard input")
@click.option(
    "--type",
    "vol_type",
    type=click.Choice(["vwap", "profile", "obv", "all"]),
    default="vwap",
    help="Type of volume analysis chart",
)
@click.option("--bands", "-b", default=3, help="Number of VWAP standard deviation bands")
@click.option(
    "--session",
    "-s",
    default="none",
    type=click.Choice(["daily", "weekly", "none"]),
    help="Session reset period for VWAP",
)
@click.option("--title", "-t", help="Chart title (auto-generated if not provided)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--range",
    "range_str",
    default=None,
    help="Date range to filter data: 7d, 1mo, 3mo, 6mo, 1y, ytd, 2024, 2023-2024, 2024Q1, 2024-03, 2024-03-15",
)
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def volume_command(
    ctx,
    data,
    input_file,
    use_stdin,
    vol_type,
    bands,
    session,
    title,
    theme,
    range_str,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate volume analysis charts.
    
    Examples:
        chartpipe volume --data btc.json --type vwap --bands 3
        chartpipe volume --data btc.json --type profile
        seamflux invoke binance fetchOhlcv --pipe | chartpipe volume --type obv
        chartpipe volume --type all --data btc.json --session daily
    
    Chart types:
        vwap: Volume Weighted Average Price with standard deviation bands
        profile: Volume Profile (volume distribution by price level)
        obv: On-Balance Volume (cumulative volume flow)
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "volume"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe data via stdin.",
                    EXIT_GENERAL,
                )
            df = parse_input_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                df = parse_input_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    # Apply date range filter if specified
    if range_str:
        try:
            date_range = parse_range(range_str)
            df = filter_by_range(df, date_range)
            if df.empty:
                fail_json(
                    "INVALID_INPUT",
                    f"No data found in range '{range_str}' ({range_to_str(date_range)}).",
                    EXIT_SCHEMA,
                )
        except ValueError as e:
            fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    required_cols = ["close", "volume"]
    if vol_type in ["vwap", "profile"]:
        required_cols.extend(["high", "low"])
    
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        fail_json("INVALID_INPUT", f"Error: Missing required columns: {missing}", EXIT_SCHEMA)

    if dry_run:
        click.echo(
            f"Dry run OK: would plot volume chart(s) type={vol_type} ({len(df)} rows)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"rows": len(df), "volumeType": vol_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel_path(path):
        try:
            return os.path.relpath(path, cwd)
        except ValueError:
            return path

    try:
        if vol_type == "all":
            results = {}
            for vtype in ["vwap", "profile", "obv"]:
                chart_title = title or f"{vtype.upper()} Analysis"
                results[vtype] = engine.plot_volume_analysis(
                    df, vol_type=vtype, bands=bands, session=session, title=chart_title
                )
            finished = utc_now_iso()
            artifacts = {k: _rel_path(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for vtype, pth in results.items():
                    click.echo(f"{vtype.upper()} chart saved: {pth}")
        else:
            chart_title = title or f"{vol_type.upper()} Analysis"
            chart_path = engine.plot_volume_analysis(
                df, vol_type=vol_type, bands=bands, session=session, title=chart_title
            )
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel_path(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_volume_analysis failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
