#!/usr/bin/env python3
"""Drawdown analysis chart command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.range_filter import parse_range, filter_by_range, range_to_str

log = logging.getLogger(__name__)


def parse_input_data(input_data):
    """Parse input data from various formats."""
    data = parse_input_text(input_data)
    df = json_payload_to_dataframe(data)
    df = normalize_ohlcv_columns(df)
    return normalize_timestamp_column_to_index(df)


@click.command(name="drawdown")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to OHLCV or equity data file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from standard input")
@click.option(
    "--type",
    "dd_type",
    type=click.Choice(["underwater", "recovery", "top", "all"]),
    default="underwater",
    help="Type of drawdown chart",
)
@click.option("--top", "-t", default=5, help="Number of top drawdowns to display")
@click.option("--from-equity", is_flag=True, help="Input is already an equity curve (default: OHLCV)")
@click.option("--title", help="Chart title (auto-generated if not provided)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--range",
    "range_str",
    default=None,
    help="Date range to filter data: 7d, 1mo, 3mo, 6mo, 1y, ytd, 2024, 2023-2024, 2024Q1, 2024-03, 2024-03-15",
)
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def drawdown_command(
    ctx,
    data,
    input_file,
    use_stdin,
    dd_type,
    top,
    from_equity,
    title,
    theme,
    range_str,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate drawdown analysis charts.
    
    Examples:
        chartpipe drawdown --data btc.json --type underwater
        chartpipe drawdown --data equity.json --from-equity --type recovery
        chartpipe drawdown --data btc.json --type top --top 5
        chartpipe drawdown --type all --stdin
    
    Chart types:
        underwater: Drawdown percentage over time (underwater curve)
        recovery: Distribution of drawdown recovery times
        top: Highlight top N drawdowns on price chart
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "drawdown"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe data via stdin.",
                    EXIT_GENERAL,
                )
            df = parse_input_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                df = parse_input_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    # Apply date range filter if specified
    if range_str:
        try:
            date_range = parse_range(range_str)
            df = filter_by_range(df, date_range)
            if df.empty:
                fail_json(
                    "INVALID_INPUT",
                    f"No data found in range '{range_str}' ({range_to_str(date_range)}).",
                    EXIT_SCHEMA,
                )
        except ValueError as e:
            fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    # Determine equity series
    if from_equity:
        if "equity" in df.columns:
            equity = df["equity"]
        elif "close" in df.columns:
            equity = df["close"]
        else:
            fail_json("INVALID_INPUT", "Error: No 'equity' or 'close' column found.", EXIT_SCHEMA)
    else:
        if "close" not in df.columns:
            fail_json("INVALID_INPUT", "Error: 'close' column required for drawdown analysis.", EXIT_SCHEMA)
        # Calculate equity from returns
        returns = df["close"].pct_change().dropna()
        equity = (1 + returns).cumprod() * 100  # Start at 100
        equity = pd.concat([pd.Series([100], index=[df.index[0]]), equity])

    if dry_run:
        click.echo(
            f"Dry run OK: would plot drawdown chart(s) type={dd_type} ({len(equity)} points)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"points": len(equity), "drawdownType": dd_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel_path(path):
        try:
            return os.path.relpath(path, cwd)
        except ValueError:
            return path

    try:
        if dd_type == "all":
            results = {}
            dtypes = ["underwater", "recovery", "top"]
            for dtype in dtypes:
                chart_title = title or f"{dtype.title()} Drawdown Analysis"
                results[dtype] = engine.plot_drawdown(
                    df, equity, dd_type=dtype, top_n=top, from_equity=from_equity, title=chart_title
                )
            finished = utc_now_iso()
            artifacts = {k: _rel_path(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for dtype, pth in results.items():
                    click.echo(f"{dtype.title()} drawdown chart saved: {pth}")
        else:
            chart_title = title or f"{dd_type.title()} Drawdown Analysis"
            chart_path = engine.plot_drawdown(
                df, equity, dd_type=dd_type, top_n=top, from_equity=from_equity, title=chart_title
            )
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel_path(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_drawdown failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
