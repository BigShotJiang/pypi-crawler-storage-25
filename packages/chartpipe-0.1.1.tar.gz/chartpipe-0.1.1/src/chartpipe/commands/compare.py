#!/usr/bin/env python3
"""Multi-asset comparison chart command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import json_payload_to_dataframe, normalize_ohlcv_columns, parse_input_text
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)


def parse_multi_asset_data(input_data):
    """Parse multi-asset data from various formats.
    
    Supports:
    - { "symbol1": [...], "symbol2": [...] } - Multiple OHLCV series
    - { "data": { "symbol1": [...], "symbol2": [...] } }
    - Standard single asset format (treated as one asset)
    """
    data = parse_input_text(input_data)
    
    if isinstance(data, dict):
        # Check for nested data
        if "data" in data and isinstance(data["data"], dict):
            data = data["data"]
        
        # Check if it's a multi-asset format
        # Heuristic: values are lists (OHLCV data)
        is_multi_asset = all(isinstance(v, list) for v in data.values())
        
        if is_multi_asset:
            assets = {}
            for symbol, ohlcv_list in data.items():
                df = json_payload_to_dataframe(ohlcv_list)
                df = normalize_ohlcv_columns(df)
                if "close" in df.columns:
                    # Use timestamp as index if available
                    if "timestamp" in df.columns:
                        df = df.set_index("timestamp")
                        df.index = pd.to_datetime(df.index, errors="coerce")
                    assets[symbol] = df["close"]
            return assets
        else:
            # Single asset in dict format
            df = json_payload_to_dataframe(data)
            df = normalize_ohlcv_columns(df)
            symbol = data.get("symbol", "unknown")
            if "close" in df.columns:
                if "timestamp" in df.columns:
                    df = df.set_index("timestamp")
                    df.index = pd.to_datetime(df.index, errors="coerce")
                return {symbol: df["close"]}
    
    elif isinstance(data, list):
        # Single asset list format
        df = json_payload_to_dataframe(data)
        df = normalize_ohlcv_columns(df)
        if "close" in df.columns:
            if "timestamp" in df.columns:
                df = df.set_index("timestamp")
                df.index = pd.to_datetime(df.index, errors="coerce")
            return {"unknown": df["close"]}
    
    raise ValueError(f"Unsupported data format for multi-asset comparison: {type(data)}")


@click.command(name="compare")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to multi-asset data file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from standard input")
@click.option(
    "--type",
    "compare_type",
    type=click.Choice(["price", "correlation", "rs", "all"]),
    default="price",
    help="Type of comparison chart",
)
@click.option("--benchmark", "-b", help="Benchmark symbol for relative strength calculation")
@click.option("--normalize", "-n", is_flag=True, help="Normalize prices to start at 100")
@click.option("--title", "-t", help="Chart title (auto-generated if not provided)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def compare_command(
    ctx,
    data,
    input_file,
    use_stdin,
    compare_type,
    benchmark,
    normalize,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate multi-asset comparison charts.
    
    Examples:
        chartpipe compare --data portfolio.json --type price --normalize
        chartpipe compare --data assets.json --type correlation
        chartpipe compare --data btc.json --benchmark ETH --type rs
        chartpipe compare --type all --data portfolio.json --normalize
    
    Data format for multi-asset:
        {
          "BTCUSDT": [{"timestamp": "...", "close": 42000, ...}, ...],
          "ETHUSDT": [{"timestamp": "...", "close": 2800, ...}, ...]
        }
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "compare"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe data via stdin.",
                    EXIT_GENERAL,
                )
            assets = parse_multi_asset_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                assets = parse_multi_asset_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if not assets:
        fail_json("INVALID_INPUT", "Error: No valid asset data found.", EXIT_SCHEMA)

    if len(assets) < 2 and compare_type in ["correlation", "all"]:
        fail_json("INVALID_INPUT", "Error: At least 2 assets required for correlation analysis.", EXIT_SCHEMA)

    if compare_type == "rs" and not benchmark:
        # Use first asset as benchmark if not specified
        benchmark = list(assets.keys())[0] if assets else None

    if dry_run:
        click.echo(
            f"Dry run OK: would plot comparison chart(s) type={compare_type} ({len(assets)} assets)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"assets": list(assets.keys()), "compareType": compare_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel_path(path):
        try:
            return os.path.relpath(path, cwd)
        except ValueError:
            return path

    try:
        if compare_type == "all":
            results = {}
            ctypes = ["price"]
            if len(assets) >= 2:
                ctypes.append("correlation")
            if benchmark and benchmark in assets:
                ctypes.append("rs")
            
            for ctype in ctypes:
                chart_title = title or f"{ctype.title()} Comparison"
                results[ctype] = engine.plot_comparison(
                    assets, compare_type=ctype, normalize=normalize, benchmark=benchmark, title=chart_title
                )
            finished = utc_now_iso()
            artifacts = {k: _rel_path(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for ctype, pth in results.items():
                    click.echo(f"{ctype.title()} comparison chart saved: {pth}")
        else:
            chart_title = title or f"{compare_type.title()} Comparison"
            chart_path = engine.plot_comparison(
                assets, compare_type=compare_type, normalize=normalize, benchmark=benchmark, title=chart_title
            )
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel_path(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_comparison failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
