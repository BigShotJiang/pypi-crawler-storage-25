#!/usr/bin/env python3
"""Volatility analysis chart command."""

import logging
import os
import sys

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.charts import ChartEngine
from ..core.input_data import (
    json_payload_to_dataframe,
    normalize_ohlcv_columns,
    normalize_timestamp_column_to_index,
    parse_input_text,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.range_filter import parse_range, filter_by_range, range_to_str

log = logging.getLogger(__name__)


def parse_input_data(input_data):
    """Parse input data from various formats."""
    data = parse_input_text(input_data)
    df = json_payload_to_dataframe(data)
    df = normalize_ohlcv_columns(df)
    return normalize_timestamp_column_to_index(df)


@click.command(name="volatility")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to OHLCV data file (JSON)")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from standard input")
@click.option(
    "--type",
    "vol_type",
    type=click.Choice(["history", "rolling", "cone", "all"]),
    default="history",
    help="Type of volatility chart",
)
@click.option("--window", "-w", default=20, help="Rolling window for volatility calculation")
@click.option("--annualize", "-a", default=252, help="Annualization factor (252 for daily)")
@click.option("--title", "-t", help="Chart title (auto-generated if not provided)")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--range",
    "range_str",
    default=None,
    help="Date range to filter data: 7d, 1mo, 3mo, 6mo, 1y, ytd, 2024, 2023-2024, 2024Q1, 2024-03, 2024-03-15",
)
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def volatility_command(
    ctx,
    data,
    input_file,
    use_stdin,
    vol_type,
    window,
    annualize,
    title,
    theme,
    range_str,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate volatility analysis charts.
    
    Examples:
        chartpipe volatility --data btc.json --type history --window 20
        seamflux invoke binance fetchOhlcv --pipe | chartpipe volatility --type rolling --window 30
        chartpipe volatility --type cone --data btc.json --window 20 --annualize 252
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "volatility"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe data via stdin.",
                    EXIT_GENERAL,
                )
            df = parse_input_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                df = parse_input_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if df.empty:
        fail_json("INVALID_INPUT", "Error: No valid data found.", EXIT_SCHEMA)

    if "close" not in df.columns:
        fail_json("INVALID_INPUT", "Error: 'close' column required for volatility analysis.", EXIT_SCHEMA)

    # Apply date range filter if specified
    if range_str:
        try:
            date_range = parse_range(range_str)
            df = filter_by_range(df, date_range)
            if df.empty:
                fail_json(
                    "INVALID_INPUT",
                    f"No data found in range '{range_str}' ({range_to_str(date_range)}).",
                    EXIT_SCHEMA,
                )
        except ValueError as e:
            fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if dry_run:
        click.echo(
            f"Dry run OK: would plot volatility chart(s) type={vol_type} ({len(df)} rows)",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"rows": len(df), "volatilityType": vol_type},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel_path(path):
        try:
            return os.path.relpath(path, cwd)
        except ValueError:
            return path

    try:
        if vol_type == "all":
            results = {}
            for vtype in ["history", "rolling", "cone"]:
                chart_title = title or f"{vtype.title()} Volatility"
                results[vtype] = engine.plot_volatility(
                    df, vol_type=vtype, window=window, annualize=annualize, title=chart_title
                )
            finished = utc_now_iso()
            artifacts = {k: _rel_path(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for vtype, pth in results.items():
                    click.echo(f"{vtype.title()} volatility chart saved: {pth}")
        else:
            chart_title = title or f"{vol_type.title()} Volatility"
            chart_path = engine.plot_volatility(
                df, vol_type=vol_type, window=window, annualize=annualize, title=chart_title
            )
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel_path(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except ImportError as e:
        fail_json("MISSING_DEPENDENCY", str(e), EXIT_UPSTREAM)
    except Exception as e:
        log.exception("plot_volatility failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
