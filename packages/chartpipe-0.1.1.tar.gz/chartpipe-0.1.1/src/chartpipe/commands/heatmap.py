#!/usr/bin/env python3
"""Multi-asset correlation and returns heatmap command."""

import logging
import os
import sys

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.charts import ChartEngine
from ..core.input_data import json_payload_to_dataframe, normalize_ohlcv_columns, parse_input_text
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso

log = logging.getLogger(__name__)


def parse_multi_asset_data(input_data) -> dict:
    """Parse multi-asset data from JSON.

    Supports:
      - { "BTCUSDT": [...], "ETHUSDT": [...] }
      - { "data": { "BTCUSDT": [...], ... } }
      - { "result": { ... same ... } }
    """
    data = parse_input_text(input_data)

    if isinstance(data, dict):
        if "result" in data:
            data = data["result"]
        if "data" in data and isinstance(data["data"], dict):
            data = data["data"]

    if not isinstance(data, dict):
        raise ValueError(f"Expected dict with asset keys mapping to OHLCV arrays, got {type(data).__name__}")

    assets = {}
    for symbol, ohlcv_list in data.items():
        if not isinstance(ohlcv_list, list):
            continue
        df = json_payload_to_dataframe(ohlcv_list)
        df = normalize_ohlcv_columns(df)
        if "close" not in df.columns:
            continue
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df = df.set_index("timestamp")
        elif not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index, errors="coerce")
        assets[symbol] = df["close"]

    return assets


@click.command(name="heatmap")
@click.option("--data", "-d", type=click.Path(exists=True), help="Path to multi-asset JSON file")
@click.option("--input", "input_file", type=click.Path(exists=True), help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option(
    "--type",
    "chart_type",
    type=click.Choice(["correlation", "returns", "both"]),
    default="correlation",
    help="Type of heatmap: correlation (rolling), returns (by period), or both",
)
@click.option(
    "--window",
    "-w",
    "window",
    default=30,
    help="Rolling window for correlation heatmap (default 30)",
)
@click.option("--title", "-t", default=None, help="Chart title")
@click.option("--theme", default="dark", type=click.Choice(["dark", "light"]), help="Chart theme")
@click.option(
    "--output-dir",
    "-o",
    "output_dir_flag",
    default=None,
    help="Same as global chartpipe --output-dir (directory to save charts)",
)
@click.option(
    "--json",
    "json_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --json (machine-readable stdout)",
)
@click.option(
    "--dry-run",
    "dry_run_flag",
    is_flag=True,
    default=False,
    help="Same as global chartpipe --dry-run (validate only, no chart file)",
)
@click.pass_context
def heatmap_command(
    ctx,
    data,
    input_file,
    use_stdin,
    chart_type,
    window,
    title,
    theme,
    output_dir_flag,
    json_flag,
    dry_run_flag,
):
    """Generate multi-asset correlation and returns heatmaps.

    correlation: Heatmap of rolling pairwise correlations over time (requires >= 2 assets).
    returns:    Heatmap of returns by asset (rows) and time period (columns).
    both:       Generates both charts.

    Examples:
        chartpipe heatmap --data assets.json --type correlation --window 30
        chartpipe heatmap --data assets.json --type returns
        chartpipe heatmap --data assets.json --type both --json
    """
    json_output = bool(ctx.obj.get("json_output", False) or json_flag)
    output_dir = output_dir_flag or ctx.obj.get("output_dir", "./charts")
    dry_run = bool(ctx.obj.get("dry_run", False) or dry_run_flag)
    command = "heatmap"
    path = input_file or data
    cwd = os.getcwd()

    def fail_json(code: str, msg: str, exit_code: int) -> None:
        click.echo(msg, err=True)
        if json_output:
            emit_json_line(failure_envelope(command, code, msg))
        ctx.exit(exit_code)

    started = utc_now_iso()

    try:
        if use_stdin or not path:
            input_text = sys.stdin.read()
            if not input_text.strip():
                fail_json(
                    "INVALID_INPUT",
                    "Error: No input data provided. Use --data or pipe JSON via stdin.",
                    EXIT_GENERAL,
                )
            assets = parse_multi_asset_data(input_text)
        else:
            with open(path, encoding="utf-8") as f:
                assets = parse_multi_asset_data(f.read())
    except (ValueError, OSError) as e:
        fail_json("INVALID_INPUT", str(e), EXIT_SCHEMA)

    if len(assets) < 2:
        fail_json(
            "INVALID_INPUT",
            f"Need at least 2 assets for heatmap. Got {len(assets)}.",
            EXIT_SCHEMA,
        )

    if dry_run:
        click.echo(
            f"Dry run OK: would plot heatmap type={chart_type} ({len(assets)} assets, window={window})",
            err=True,
        )
        finished = utc_now_iso()
        if json_output:
            emit_json_line(
                success_envelope(
                    command,
                    artifacts={},
                    meta={"startedAt": started, "finishedAt": finished, "dryRun": True},
                    data={"assets": list(assets.keys()), "heatmapType": chart_type, "window": window},
                )
            )
        return

    engine = ChartEngine(output_dir=output_dir, theme=theme)

    def _rel(p):
        try:
            return os.path.relpath(p, cwd)
        except ValueError:
            return p

    try:
        if chart_type == "both":
            results = {}
            ctitle = title or "Rolling Correlation"
            results["correlation"] = engine.plot_correlation_rolling(assets, window=window, title=ctitle)
            rtitle = title or "Returns Heatmap"
            results["returns"] = engine.plot_returns_heatmap(assets, title=rtitle)
            finished = utc_now_iso()
            artifacts = {k: _rel(v) for k, v in results.items()}
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts=artifacts,
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                for k, p in results.items():
                    click.echo(f"{k.title()} heatmap saved: {p}")
        elif chart_type == "correlation":
            ctitle = title or "Rolling Correlation Heatmap"
            chart_path = engine.plot_correlation_rolling(assets, window=window, title=ctitle)
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
        else:  # returns
            rtitle = title or "Returns Heatmap"
            chart_path = engine.plot_returns_heatmap(assets, title=rtitle)
            finished = utc_now_iso()
            if json_output:
                emit_json_line(
                    success_envelope(
                        command,
                        artifacts={"chart": _rel(chart_path)},
                        meta={"startedAt": started, "finishedAt": finished},
                    )
                )
            else:
                click.echo(f"Chart saved: {chart_path}")
    except Exception as e:
        log.exception("plot_heatmap failed")
        fail_json("PLOT_ERROR", str(e), EXIT_GENERAL)
