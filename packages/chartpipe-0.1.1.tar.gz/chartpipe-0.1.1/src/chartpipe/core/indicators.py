"""Technical indicator calculations for chartpipe."""

from typing import Optional, Tuple

import numpy as np
import pandas as pd


def calculate_returns(prices: pd.Series) -> pd.Series:
    """Calculate percentage returns."""
    return prices.pct_change().dropna()


def calculate_volatility(
    prices: pd.Series, window: int = 20, annualize: int = 252
) -> pd.Series:
    """Calculate rolling volatility (annualized standard deviation of returns).
    
    Args:
        prices: Price series
        window: Rolling window size
        annualize: Annualization factor (252 for daily, 52 for weekly, 12 for monthly)
    
    Returns:
        Rolling volatility series
    """
    returns = calculate_returns(prices)
    return returns.rolling(window=window).std() * np.sqrt(annualize)


def calculate_volatility_cone(
    prices: pd.Series, windows: list = None, quantiles: list = None
) -> pd.DataFrame:
    """Calculate volatility cone across multiple lookback windows.
    
    Args:
        prices: Price series
        windows: List of lookback windows (default: [10, 20, 30, 60, 90, 120])
        quantiles: Quantile levels (default: [0.1, 0.25, 0.5, 0.75, 0.9])
    
    Returns:
        DataFrame with volatility cone statistics
    """
    if windows is None:
        windows = [10, 20, 30, 60, 90, 120]
    if quantiles is None:
        quantiles = [0.1, 0.25, 0.5, 0.75, 0.9]
    
    returns = calculate_returns(prices)
    cone_data = []
    
    for window in windows:
        if len(returns) < window:
            continue
        vol = returns.rolling(window=window).std() * np.sqrt(252)
        vol_stats = {"window": window}
        for q in quantiles:
            vol_stats[f"q{int(q*100)}"] = vol.quantile(q)
        vol_stats["current"] = vol.iloc[-1] if not vol.empty else np.nan
        cone_data.append(vol_stats)
    
    return pd.DataFrame(cone_data).set_index("window")


def calculate_vwap(df: pd.DataFrame, reset_period: str = None) -> pd.Series:
    """Calculate Volume Weighted Average Price (VWAP).
    
    Args:
        df: DataFrame with high, low, close, volume columns
        reset_period: Reset period ('daily', 'weekly', or None for cumulative)
    
    Returns:
        VWAP series
    """
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    
    if reset_period is None:
        # Cumulative VWAP
        return (typical_price * df["volume"]).cumsum() / df["volume"].cumsum()
    else:
        # Reset VWAP by period
        if reset_period == "daily":
            grouper = df.index.date if hasattr(df.index, "date") else df.index
        elif reset_period == "weekly":
            grouper = df.index.isocalendar().week if hasattr(df.index, "isocalendar") else df.index
        else:
            grouper = df.index
        
        tp_vol = typical_price * df["volume"]
        cum_tp_vol = tp_vol.groupby(grouper).cumsum()
        cum_vol = df["volume"].groupby(grouper).cumsum()
        return cum_tp_vol / cum_vol


def calculate_vwap_bands(
    df: pd.DataFrame, num_bands: int = 3, std_multiplier: float = 1.0
) -> dict:
    """Calculate VWAP with standard deviation bands.
    
    Args:
        df: DataFrame with OHLCV data
        num_bands: Number of standard deviation bands
        std_multiplier: Multiplier for standard deviation
    
    Returns:
        Dictionary with vwap, upper bands, and lower bands
    """
    vwap = calculate_vwap(df)
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    
    # Calculate deviation
    deviation = (typical_price - vwap) ** 2
    variance = deviation.expanding().mean()
    std = np.sqrt(variance)
    
    result = {"vwap": vwap}
    
    for i in range(1, num_bands + 1):
        multiplier = i * std_multiplier
        result[f"upper_{i}"] = vwap + (std * multiplier)
        result[f"lower_{i}"] = vwap - (std * multiplier)
    
    return result


def calculate_obv(df: pd.DataFrame) -> pd.Series:
    """Calculate On-Balance Volume (OBV).
    
    Args:
        df: DataFrame with close and volume columns
    
    Returns:
        OBV series
    """
    obv = pd.Series(index=df.index, dtype=float)
    obv.iloc[0] = df["volume"].iloc[0]
    
    for i in range(1, len(df)):
        if df["close"].iloc[i] > df["close"].iloc[i - 1]:
            obv.iloc[i] = obv.iloc[i - 1] + df["volume"].iloc[i]
        elif df["close"].iloc[i] < df["close"].iloc[i - 1]:
            obv.iloc[i] = obv.iloc[i - 1] - df["volume"].iloc[i]
        else:
            obv.iloc[i] = obv.iloc[i - 1]
    
    return obv


def calculate_volume_profile(
    df: pd.DataFrame, num_bins: int = 50
) -> Tuple[pd.Series, np.ndarray]:
    """Calculate Volume Profile (volume distribution by price level).
    
    Args:
        df: DataFrame with typical price and volume
        num_bins: Number of price bins
    
    Returns:
        Tuple of (volume_by_bin, bin_edges)
    """
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    
    # Create price bins
    bin_edges = np.linspace(typical_price.min(), typical_price.max(), num_bins + 1)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    
    # Assign each row to a bin
    bin_indices = np.digitize(typical_price, bin_edges) - 1
    bin_indices = np.clip(bin_indices, 0, num_bins - 1)
    
    # Sum volume by bin
    volume_by_bin = pd.Series(0.0, index=range(num_bins))
    for i, vol in enumerate(df["volume"]):
        volume_by_bin.iloc[bin_indices[i]] += vol
    
    volume_by_bin.index = bin_centers
    return volume_by_bin, bin_edges


def calculate_adx(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
    """Calculate Average Directional Index (ADX).
    
    Args:
        df: DataFrame with high, low, close columns
        period: ADX calculation period
    
    Returns:
        DataFrame with +DI, -DI, DX, and ADX columns
    """
    high = df["high"]
    low = df["low"]
    close = df["close"]
    
    # True Range
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # +DM and -DM
    plus_dm = high.diff()
    minus_dm = -low.diff()
    
    plus_dm[plus_dm < 0] = 0
    minus_dm[minus_dm < 0] = 0
    
    plus_dm[plus_dm <= minus_dm] = 0
    minus_dm[minus_dm <= plus_dm] = 0
    
    # Smoothed averages
    atr = tr.ewm(alpha=1/period, min_periods=period).mean()
    plus_di = 100 * (plus_dm.ewm(alpha=1/period, min_periods=period).mean() / atr)
    minus_di = 100 * (minus_dm.ewm(alpha=1/period, min_periods=period).mean() / atr)
    
    # DX and ADX
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    dx = dx.replace([np.inf, -np.inf], 0).fillna(0)
    adx = dx.ewm(alpha=1/period, min_periods=period).mean()
    
    return pd.DataFrame({
        "plus_di": plus_di,
        "minus_di": minus_di,
        "dx": dx,
        "adx": adx
    })


def calculate_drawdowns(equity: pd.Series) -> pd.DataFrame:
    """Calculate drawdown statistics.
    
    Args:
        equity: Equity curve series
    
    Returns:
        DataFrame with drawdown information
    """
    rolling_max = equity.expanding().max()
    drawdown = (equity - rolling_max) / rolling_max
    
    # Find drawdown periods
    is_drawdown = drawdown < 0
    
    drawdowns = []
    in_drawdown = False
    start_idx = None
    
    for i, (idx, is_dd) in enumerate(is_drawdown.items()):
        if is_dd and not in_drawdown:
            in_drawdown = True
            start_idx = idx
            start_i = i
        elif not is_dd and in_drawdown:
            in_drawdown = False
            end_idx = idx
            # Calculate stats for this drawdown period
            dd_period = drawdown.loc[start_idx:end_idx]
            peak = equity.loc[start_idx]
            trough = equity.loc[dd_period.idxmin()]
            drawdowns.append({
                "start": start_idx,
                "end": end_idx,
                "duration": i - start_i,
                "depth": dd_period.min(),
                "recovery": end_idx if not pd.isna(end_idx) else None,
                "peak": peak,
                "trough": trough
            })
    
    # Handle ongoing drawdown
    if in_drawdown:
        dd_period = drawdown.loc[start_idx:]
        peak = equity.loc[start_idx]
        trough = equity.loc[dd_period.idxmin()]
        drawdowns.append({
            "start": start_idx,
            "end": None,
            "duration": len(equity) - start_i,
            "depth": dd_period.min(),
            "recovery": None,
            "peak": peak,
            "trough": trough
        })
    
    return pd.DataFrame(drawdowns)


def calculate_calendar_returns(df: pd.DataFrame, freq: str = "weekday") -> pd.DataFrame:
    """Calculate returns by calendar period.
    
    Args:
        df: DataFrame with datetime index and close price
        freq: Calendar frequency ('weekday', 'month', 'hour')
    
    Returns:
        DataFrame with returns statistics by period
    """
    if "close" not in df.columns:
        raise ValueError("DataFrame must have 'close' column")
    
    # Calculate returns and align with index (dropna removes first value which is NaN)
    returns = df["close"].pct_change()

    # Drop rows with NaT in index (failed date parsing) before accessing date properties
    valid_mask = ~pd.isna(df.index)
    df = df[valid_mask]
    returns = returns[valid_mask]

    if df.empty:
        raise ValueError("No valid datetime entries found in data")

    # Create period series aligned with returns
    if freq == "weekday":
        period = pd.Series(df.index.dayofweek, index=df.index)
        labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    elif freq == "month":
        period = pd.Series(df.index.month, index=df.index)
        labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    elif freq == "hour":
        period = pd.Series(df.index.hour, index=df.index)
        labels = [f"{h:02d}:00" for h in range(24)]
    else:
        raise ValueError(f"Unknown frequency: {freq}")

    # Filter out NaN returns and align period — rebuild period index after filtering
    returns = returns.dropna()
    period = period.loc[returns.index]

    result = []
    for p in sorted(period.unique()):
        mask = period == p
        period_returns = returns[mask]
        if len(period_returns) > 0:
            result.append({
                "period": labels[p] if p < len(labels) else str(p),
                "mean": period_returns.mean(),
                "median": period_returns.median(),
                "std": period_returns.std(),
                "count": len(period_returns),
                "win_rate": (period_returns > 0).mean()
            })

    return pd.DataFrame(result)


def calculate_relative_strength(
    price: pd.Series, benchmark: pd.Series
) -> pd.Series:
    """Calculate Relative Strength (RS) ratio.
    
    Args:
        price: Asset price series
        benchmark: Benchmark price series
    
    Returns:
        RS ratio series (price / benchmark, normalized to 100)
    """
    # Align series
    aligned_price, aligned_benchmark = price.align(benchmark, join="inner")
    
    # Calculate ratio and normalize to 100
    rs = (aligned_price / aligned_benchmark) * 100
    return rs


def calculate_correlation_matrix(
    data: dict, window: Optional[int] = None
) -> pd.DataFrame:
    """Calculate correlation matrix for multiple assets.

    Args:
        data: Dictionary of {symbol: price_series}
        window: Optional rolling window for correlation

    Returns:
        Correlation matrix DataFrame
    """
    # Align all series
    df = pd.DataFrame(data)

    if window:
        return df.pct_change().rolling(window).corr()
    else:
        return df.pct_change().corr()


def calculate_rolling_sharpe(
    equity: pd.Series,
    window: int = 20,
    rf_rate: float = 0.0,
    annualize: int = 252,
) -> pd.Series:
    """Calculate rolling Sharpe ratio from an equity series.

    Args:
        equity: Equity curve (values, not returns). Index must be datetime.
        window: Rolling window for mean/std calculation.
        rf_rate: Risk-free rate (annualized). Default 0.
        annualize: Annualization factor. Default 252 (daily).

    Returns:
        Rolling Sharpe ratio series (aligned with equity index, starts after window).
    """
    if len(equity) < window:
        return pd.Series(dtype=float)

    # Convert equity to returns
    returns = equity.pct_change().dropna()

    # Excess returns
    annual_rf = rf_rate / annualize
    excess = returns - annual_rf

    # Rolling mean and std
    rolling_mean = excess.rolling(window=window).mean()
    rolling_std = excess.rolling(window=window).std()

    # Avoid division by zero
    rolling_std = rolling_std.replace(0, float("nan"))

    # Annualized Sharpe
    sharpe = rolling_mean / rolling_std * np.sqrt(annualize)
    return sharpe


def calculate_sortino_ratio(
    returns: pd.Series,
    rf_rate: float = 0.0,
    annualize: int = 252,
    target_return: float = 0.0,
) -> float:
    """Calculate Sortino ratio (return-to-downside-risk).

    Args:
        returns: Return series.
        rf_rate: Risk-free rate (annualized).
        annualize: Annualization factor.
        target_return: Minimum acceptable return (MAR / target). Default 0.

    Returns:
        Sortino ratio (scalar).
    """
    if len(returns) == 0:
        return float("nan")

    annual_rf = rf_rate / annualize
    excess = returns.mean() - annual_rf

    # Downside deviation (only negative returns)
    downside = returns - target_return
    downside_returns = downside[downside < 0]
    if len(downside_returns) == 0 or downside_returns.std() == 0:
        return float("nan")

    downside_std = downside_returns.std() * np.sqrt(annualize)
    return excess / downside_std


def aggregate_stats(
    equity: pd.Series,
    returns: Optional[pd.Series] = None,
    rf_rate: float = 0.0,
    annualize: int = 252,
) -> dict:
    """Compute aggregate performance statistics from an equity curve.

    Args:
        equity: Equity curve series.
        returns: Pre-computed return series (optional, computed from equity if None).
        rf_rate: Annualized risk-free rate.
        annualize: Annualization factor (252 for daily).

    Returns:
        Dictionary with keys: sharpe, sortino, calmar, max_drawdown,
        max_drawdown_duration, win_rate, total_trades, avg_trade, volatile.
    """
    if returns is None:
        returns = equity.pct_change().dropna()

    if len(returns) == 0:
        return {}

    annual_rf = rf_rate / annualize

    # Sharpe
    mean_ret = returns.mean()
    std_ret = returns.std()
    if std_ret == 0 or np.isnan(std_ret):
        sharpe = float("nan")
    else:
        sharpe = (mean_ret - annual_rf / annualize) / std_ret * np.sqrt(annualize)

    # Sortino
    sortino = calculate_sortino_ratio(returns, rf_rate=rf_rate, annualize=annualize)

    # Max drawdown and duration
    rolling_max = equity.expanding().max()
    drawdown = (equity - rolling_max) / rolling_max
    max_dd = drawdown.min()

    # Max drawdown duration (consecutive days in drawdown)
    in_dd = drawdown < 0
    durations = []
    current_dur = 0
    for is_dd in in_dd:
        if is_dd:
            current_dur += 1
        else:
            if current_dur > 0:
                durations.append(current_dur)
            current_dur = 0
    if current_dur > 0:
        durations.append(current_dur)
    max_dd_duration = max(durations) if durations else 0

    # Win rate (positive return periods)
    win_rate = (returns > 0).mean()

    # Total return
    total_return = (equity.iloc[-1] / equity.iloc[0] - 1) if len(equity) > 1 else 0.0

    # Annualized return
    n_periods = len(equity)
    years = n_periods / annualize if annualize > 0 else 1
    ann_return = (1 + total_return) ** (1 / years) - 1 if years > 0 and total_return > -1 else 0.0

    # Calmar ratio
    if max_dd == 0 or np.isnan(max_dd) or abs(max_dd) < 1e-10:
        calmar = float("nan")
    else:
        calmar = ann_return / abs(max_dd)

    return {
        "sharpe": round(float(sharpe), 4),
        "sortino": round(float(sortino), 4),
        "calmar": round(float(calmar), 4),
        "max_drawdown": round(float(max_dd) * 100, 4),
        "max_drawdown_duration": int(max_dd_duration),
        "win_rate": round(float(win_rate) * 100, 4),
        "total_return": round(float(total_return) * 100, 4),
        "annualized_return": round(float(ann_return) * 100, 4),
        "volatility": round(float(std_ret) * np.sqrt(annualize) * 100, 4),
        "n_periods": len(returns),
    }
