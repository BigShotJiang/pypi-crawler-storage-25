"""Chart generation engine."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")  # Use non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns

try:
    import mplfinance as mpf

    MPF_AVAILABLE = True
except ImportError:
    MPF_AVAILABLE = False

from .styles import ChartStyle
from .input_data import normalize_ohlcv_index_for_plot


def _trade_side_is_long(side: Any) -> bool:
    s = str(side or "long").strip().lower()
    if s in ("short", "sell"):
        return False
    return True


class ChartEngine:
    """Main chart generation engine."""

    def __init__(self, output_dir: str = "./charts", theme: str = "dark"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.colors = ChartStyle.apply_theme(theme)
        self.dpi = ChartStyle.DPI

    def _generate_filename(self, prefix: str, ext: str = "png") -> str:
        """Generate a unique filename for the chart."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{prefix}_{timestamp}.{ext}"

    def _save_or_return(self, fig, filename: str) -> str:
        """Save figure and return absolute path to the image file."""
        filepath = self.output_dir / filename
        fig.savefig(
            filepath,
            dpi=self.dpi,
            bbox_inches="tight",
            facecolor=fig.get_facecolor(),
        )
        plt.close(fig)
        return str(filepath.resolve())

    def plot_ohlcv(
        self,
        data: pd.DataFrame,
        title: str = "Price Chart",
        volume: bool = True,
        ma_periods: Optional[List[int]] = None,
    ) -> str:
        """Generate OHLCV candlestick chart."""
        if not MPF_AVAILABLE:
            raise ImportError(
                "mplfinance is required for OHLCV candlestick charts. "
                "Install with: pip install mplfinance"
            )
        df = normalize_ohlcv_index_for_plot(data)

        column_map = {
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
            "volume": "Volume",
        }
        df.rename(
            columns={k: v for k, v in column_map.items() if k in df.columns},
            inplace=True,
        )

        mc = mpf.make_marketcolors(
            up=self.colors["up_color"],
            down=self.colors["down_color"],
            edge="inherit",
            wick="inherit",
            volume="inherit",
        )

        s = mpf.make_mpf_style(
            marketcolors=mc,
            figcolor=self.colors["background"],
            facecolor=self.colors["foreground"],
            edgecolor=self.colors["grid"],
            gridcolor=self.colors["grid"],
            gridstyle="-",
            rc={"font.size": 10},
        )

        addplots = []
        if ma_periods:
            for period in ma_periods:
                if len(df) >= period:
                    ma = df["Close"].rolling(window=period).mean()
                    addplots.append(
                        mpf.make_addplot(ma, color=self.colors["line"], width=1)
                    )

        figsize = ChartStyle.get_figure_size("large")
        plot_kwargs = {
            "type": "candle",
            "style": s,
            "title": title,
            "ylabel": "Price",
            "volume": volume,
            "figsize": figsize,
            "returnfig": True,
            "panel_ratios": (3, 1) if volume else (1,),
        }
        if volume:
            plot_kwargs["ylabel_lower"] = "Volume"
        if addplots:
            plot_kwargs["addplot"] = addplots

        fig, axes = mpf.plot(df, **plot_kwargs)

        filename = self._generate_filename("ohlcv")
        return self._save_or_return(fig, filename)

    def plot_backtest(
        self,
        data: pd.DataFrame,
        trades: Optional[List[Dict]] = None,
        title: str = "Backtest Results",
    ) -> str:
        """Generate backtest visualization with equity curve and drawdown."""
        plot_data = data.copy()
        if "drawdown" not in plot_data.columns and "equity" in plot_data.columns:
            eq = plot_data["equity"].astype(float)
            rolling_max = eq.expanding().max()
            plot_data["drawdown"] = np.where(
                rolling_max > 0, (eq - rolling_max) / rolling_max * 100.0, 0.0
            )

        figsize = ChartStyle.get_figure_size("large")
        fig, axes = plt.subplots(
            3,
            1,
            figsize=figsize,
            gridspec_kw={"height_ratios": [2, 1, 1]},
        )

        ax1 = axes[0]
        if "equity" in plot_data.columns:
            ax1.plot(
                plot_data.index,
                plot_data["equity"],
                color=self.colors["up_color"],
                linewidth=2,
            )
            ax1.fill_between(
                plot_data.index,
                plot_data["equity"],
                alpha=0.3,
                color=self.colors["up_color"],
            )
        ax1.set_title(title, fontsize=14, fontweight="bold")
        ax1.set_ylabel("Equity")
        ax1.grid(True, alpha=0.3)

        ax2 = axes[1]
        if "drawdown" in plot_data.columns:
            ax2.fill_between(
                plot_data.index,
                plot_data["drawdown"],
                0,
                color=self.colors["down_color"],
                alpha=0.5,
            )
            ax2.set_ylabel("Drawdown %")
            ax2.grid(True, alpha=0.3)

        ax3 = axes[2]
        if "close" in plot_data.columns:
            ax3.plot(
                plot_data.index,
                plot_data["close"],
                color=self.colors["line"],
                linewidth=1,
                label="Price",
            )

        trades = trades or []
        for trade in trades:
            entry_time = pd.to_datetime(trade.get("entry_time"), errors="coerce")
            exit_time = pd.to_datetime(trade.get("exit_time"), errors="coerce")
            entry_price = trade.get("entry_price")
            exit_price = trade.get("exit_price")
            is_long = _trade_side_is_long(trade.get("side", "long"))
            side_label = "long" if is_long else "short"

            color = self.colors["up_color"] if is_long else self.colors["down_color"]
            marker = "^" if is_long else "v"

            if pd.notna(entry_time) and entry_price is not None:
                ax3.scatter(
                    entry_time,
                    entry_price,
                    marker=marker,
                    color=color,
                    s=100,
                    zorder=5,
                    label=f"{side_label} entry",
                )
            if pd.notna(exit_time) and exit_price is not None:
                ax3.scatter(
                    exit_time,
                    exit_price,
                    marker="o",
                    color=color,
                    s=80,
                    zorder=5,
                    alpha=0.7,
                    label=f"{side_label} exit",
                )

        ax3.set_ylabel("Price")
        ax3.set_xlabel("Time")
        ax3.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("backtest")
        return self._save_or_return(fig, filename)

    def plot_indicator(
        self, data: pd.DataFrame, indicator: str, title: str = None
    ) -> str:
        """Generate indicator chart."""
        figsize = ChartStyle.get_figure_size("medium")

        if indicator.lower() == "rsi":
            return self._plot_rsi(data, title)
        if indicator.lower() == "macd":
            return self._plot_macd(data, title)
        if indicator.lower() == "bb":
            return self._plot_bollinger(data, title)

        fig, ax = plt.subplots(figsize=figsize)
        if indicator in data.columns:
            ax.plot(data.index, data[indicator], color=self.colors["line"], linewidth=2)
        ax.set_title(
            title or f"{indicator.upper()} Indicator",
            fontsize=14,
            fontweight="bold",
        )
        ax.grid(True, alpha=0.3)

        filename = self._generate_filename(f"indicator_{indicator}")
        return self._save_or_return(fig, filename)

    def _plot_rsi(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot RSI indicator."""
        fig, (ax1, ax2) = plt.subplots(
            2,
            1,
            figsize=(12, 8),
            gridspec_kw={"height_ratios": [2, 1]},
        )

        if "close" in data.columns:
            ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title(title or "RSI Indicator", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.grid(True, alpha=0.3)

        rsi_col = "rsi" if "rsi" in data.columns else "RSI"
        if rsi_col in data.columns:
            ax2.plot(data.index, data[rsi_col], color=self.colors["line"], linewidth=1.5)
            ax2.axhline(y=70, color=self.colors["down_color"], linestyle="--", alpha=0.7)
            ax2.axhline(y=30, color=self.colors["up_color"], linestyle="--", alpha=0.7)
            ax2.fill_between(
                data.index,
                data[rsi_col],
                70,
                where=(data[rsi_col] > 70),
                color=self.colors["down_color"],
                alpha=0.3,
            )
            ax2.fill_between(
                data.index,
                data[rsi_col],
                30,
                where=(data[rsi_col] < 30),
                color=self.colors["up_color"],
                alpha=0.3,
            )
        ax2.set_ylabel("RSI")
        ax2.set_xlabel("Time")
        ax2.set_ylim(0, 100)
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("indicator_rsi")
        return self._save_or_return(fig, filename)

    def _plot_macd(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot MACD indicator."""
        fig, (ax1, ax2) = plt.subplots(
            2,
            1,
            figsize=(12, 8),
            gridspec_kw={"height_ratios": [2, 1]},
        )

        if "close" in data.columns:
            ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title(title or "MACD Indicator", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.grid(True, alpha=0.3)

        macd_col = "macd" if "macd" in data.columns else "MACD"
        signal_col = "signal" if "signal" in data.columns else "MACD_SIGNAL"
        hist_col = "histogram" if "histogram" in data.columns else "MACD_HIST"

        if macd_col in data.columns:
            ax2.plot(
                data.index,
                data[macd_col],
                color=self.colors["line"],
                linewidth=1.5,
                label="MACD",
            )
        if signal_col in data.columns:
            ax2.plot(
                data.index,
                data[signal_col],
                color=self.colors["text"],
                linewidth=1.5,
                label="Signal",
            )
        if hist_col in data.columns:
            colors = [
                self.colors["up_color"] if v >= 0 else self.colors["down_color"]
                for v in data[hist_col]
            ]
            ax2.bar(data.index, data[hist_col], color=colors, alpha=0.7, label="Histogram")

        ax2.set_ylabel("MACD")
        ax2.set_xlabel("Time")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("indicator_macd")
        return self._save_or_return(fig, filename)

    def _plot_bollinger(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot Bollinger Bands."""
        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("medium"))

        if "close" in data.columns:
            ax.plot(
                data.index,
                data["close"],
                color=self.colors["line"],
                linewidth=1.5,
                label="Price",
            )
        if "bb_upper" in data.columns:
            ax.plot(
                data.index,
                data["bb_upper"],
                color=self.colors["down_color"],
                linewidth=1,
                linestyle="--",
                label="Upper Band",
            )
        if "bb_middle" in data.columns:
            ax.plot(
                data.index,
                data["bb_middle"],
                color=self.colors["text"],
                linewidth=1,
                label="Middle Band",
            )
        if "bb_lower" in data.columns:
            ax.plot(
                data.index,
                data["bb_lower"],
                color=self.colors["up_color"],
                linewidth=1,
                linestyle="--",
                label="Lower Band",
            )

        if "bb_upper" in data.columns and "bb_lower" in data.columns:
            ax.fill_between(
                data.index,
                data["bb_upper"],
                data["bb_lower"],
                alpha=0.1,
                color=self.colors["line"],
            )

        ax.set_title(title or "Bollinger Bands", fontsize=14, fontweight="bold")
        ax.set_ylabel("Price")
        ax.set_xlabel("Time")
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("indicator_bb")
        return self._save_or_return(fig, filename)

    def plot_stats(self, data: pd.DataFrame, chart_type: str = "returns", title: str = None) -> str:
        """Generate statistical analysis charts."""
        if chart_type == "returns":
            return self._plot_returns_dist(data, title)
        if chart_type == "distribution":
            return self._plot_distribution(data, title)
        if chart_type == "monthly":
            return self._plot_monthly_returns(data, title)

        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("medium"))
        ax.text(
            0.5,
            0.5,
            f"Unknown chart type: {chart_type}",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
        filename = self._generate_filename("stats")
        return self._save_or_return(fig, filename)

    def _plot_returns_dist(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot returns distribution."""
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))

        if "returns" not in data.columns and "close" in data.columns:
            returns = data["close"].pct_change().dropna()
        elif "returns" in data.columns:
            returns = data["returns"].dropna()
        else:
            fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("medium"))
            ax.text(
                0.5,
                0.5,
                'Need a "close" or "returns" column for returns analysis',
                ha="center",
                va="center",
                transform=ax.transAxes,
            )
            filename = self._generate_filename("stats_returns")
            return self._save_or_return(fig, filename)

        ax1.plot(returns.index, returns * 100, color=self.colors["line"], linewidth=1)
        ax1.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
        ax1.set_title(title or "Returns Analysis", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Returns %")
        ax1.grid(True, alpha=0.3)

        ax2.hist(
            returns * 100,
            bins=50,
            color=self.colors["line"],
            alpha=0.7,
            edgecolor=self.colors["grid"],
        )
        ax2.axvline(
            x=returns.mean() * 100,
            color=self.colors["up_color"],
            linestyle="--",
            linewidth=2,
            label=f"Mean: {returns.mean() * 100:.2f}%",
        )
        ax2.set_xlabel("Returns %")
        ax2.set_ylabel("Frequency")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("stats_returns")
        return self._save_or_return(fig, filename)

    def _plot_distribution(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot price/volume distribution."""
        fig, axes = plt.subplots(2, 2, figsize=ChartStyle.get_figure_size("large"))

        if "close" in data.columns:
            axes[0, 0].hist(data["close"], bins=50, color=self.colors["line"], alpha=0.7)
            axes[0, 0].set_title("Price Distribution")
            axes[0, 0].set_xlabel("Price")
            axes[0, 0].grid(True, alpha=0.3)

            axes[0, 1].boxplot(data["close"], vert=True)
            axes[0, 1].set_title("Price Box Plot")
            axes[0, 1].grid(True, alpha=0.3)

        if "volume" in data.columns:
            axes[1, 0].hist(data["volume"], bins=50, color=self.colors["up_color"], alpha=0.7)
            axes[1, 0].set_title("Volume Distribution")
            axes[1, 0].set_xlabel("Volume")
            axes[1, 0].grid(True, alpha=0.3)

            axes[1, 1].boxplot(data["volume"], vert=True)
            axes[1, 1].set_title("Volume Box Plot")
            axes[1, 1].grid(True, alpha=0.3)

        plt.suptitle(title or "Data Distribution", fontsize=14, fontweight="bold")
        plt.tight_layout()
        filename = self._generate_filename("stats_distribution")
        return self._save_or_return(fig, filename)

    def _plot_monthly_returns(self, data: pd.DataFrame, title: str = None) -> str:
        """Plot monthly returns heatmap."""
        if "close" not in data.columns:
            fig, ax = plt.subplots()
            ax.text(0.5, 0.5, "No price data available", ha="center", va="center")
            filename = self._generate_filename("stats_monthly")
            return self._save_or_return(fig, filename)

        df = data.copy()
        df.index = pd.to_datetime(df.index)
        monthly = df["close"].resample("ME").last().pct_change().dropna()
        if monthly.empty:
            fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("medium"))
            ax.text(
                0.5,
                0.5,
                "Not enough data for monthly returns (need close prices across multiple months)",
                ha="center",
                va="center",
                transform=ax.transAxes,
            )
            ax.set_title(title or "Monthly Returns Heatmap", fontsize=14, fontweight="bold")
            filename = self._generate_filename("stats_monthly")
            return self._save_or_return(fig, filename)

        monthly_returns = monthly.to_frame()
        monthly_returns["Year"] = monthly_returns.index.year
        monthly_returns["Month"] = monthly_returns.index.month
        pivot = monthly_returns.pivot(index="Year", columns="Month", values="close")

        month_names = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
        ]
        pivot.columns = [month_names[i - 1] for i in pivot.columns]

        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("large"))
        plot_vals = pivot * 100
        if plot_vals.size == 0 or not np.isfinite(plot_vals.to_numpy(dtype=float)).any():
            ax.text(
                0.5,
                0.5,
                "No valid monthly returns to display",
                ha="center",
                va="center",
                transform=ax.transAxes,
            )
        else:
            sns.heatmap(
                plot_vals,
                annot=True,
                fmt=".1f",
                cmap="RdYlGn",
                center=0,
                ax=ax,
                cbar_kws={"label": "Returns %"},
            )
        ax.set_title(title or "Monthly Returns Heatmap", fontsize=14, fontweight="bold")

        plt.tight_layout()
        filename = self._generate_filename("stats_monthly")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Volatility Analysis Charts
    # =========================================================================

    def plot_volatility(
        self,
        data: pd.DataFrame,
        vol_type: str = "history",
        window: int = 20,
        annualize: int = 252,
        title: str = None,
    ) -> str:
        """Generate volatility analysis charts."""
        if vol_type == "history":
            return self._plot_volatility_history(data, window, annualize, title)
        elif vol_type == "rolling":
            return self._plot_volatility_rolling(data, window, annualize, title)
        elif vol_type == "cone":
            return self._plot_volatility_cone(data, annualize, title)
        else:
            raise ValueError(f"Unknown volatility type: {vol_type}")

    def _plot_volatility_history(
        self, data: pd.DataFrame, window: int, annualize: int, title: str
    ) -> str:
        """Plot historical volatility over time."""
        from .indicators import calculate_volatility

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1]}
        )

        # Price chart
        if "close" in data.columns:
            ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title(title or "Historical Volatility", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.grid(True, alpha=0.3)

        # Volatility chart
        volatility = calculate_volatility(data["close"], window=window, annualize=annualize)
        # Use volatility.index which aligns with returns (one less than data)
        ax2.fill_between(
            volatility.index,
            volatility * 100,
            0,
            color=self.colors["line"],
            alpha=0.5,
        )
        ax2.axhline(
            y=volatility.mean() * 100,
            color=self.colors["text"],
            linestyle="--",
            label=f"Mean: {volatility.mean()*100:.1f}%",
        )
        ax2.set_ylabel(f"Volatility (% ann., {window}d)")
        ax2.set_xlabel("Time")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("volatility_history")
        return self._save_or_return(fig, filename)

    def _plot_volatility_rolling(
        self, data: pd.DataFrame, window: int, annualize: int, title: str
    ) -> str:
        """Plot rolling volatility with multiple windows."""
        from .indicators import calculate_volatility

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        windows = [window, window * 2, window * 4]
        colors = [self.colors["line"], self.colors["up_color"], self.colors["down_color"]]

        for w, color in zip(windows, colors):
            if len(data) >= w:
                vol = calculate_volatility(data["close"], window=w, annualize=annualize)
                ax.plot(vol.index, vol * 100, color=color, linewidth=1.5, label=f"{w}d")

        ax.set_title(title or "Rolling Volatility", fontsize=14, fontweight="bold")
        ax.set_ylabel("Volatility (% annualized)")
        ax.set_xlabel("Time")
        ax.legend(title="Window")
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("volatility_rolling")
        return self._save_or_return(fig, filename)

    def _plot_volatility_cone(
        self, data: pd.DataFrame, annualize: int, title: str
    ) -> str:
        """Plot volatility cone (percentiles across lookback windows)."""
        from .indicators import calculate_volatility_cone

        figsize = ChartStyle.get_figure_size("medium")
        fig, ax = plt.subplots(figsize=figsize)

        cone = calculate_volatility_cone(data["close"])

        if not cone.empty:
            windows = cone.index
            # Plot percentiles
            ax.fill_between(
                windows,
                cone["q10"] * 100,
                cone["q90"] * 100,
                alpha=0.2,
                color=self.colors["line"],
                label="10th-90th percentile",
            )
            ax.fill_between(
                windows,
                cone["q25"] * 100,
                cone["q75"] * 100,
                alpha=0.3,
                color=self.colors["line"],
                label="25th-75th percentile",
            )
            ax.plot(
                windows,
                cone["q50"] * 100,
                color=self.colors["text"],
                linewidth=2,
                label="Median",
            )
            ax.scatter(
                windows,
                cone["current"] * 100,
                color=self.colors["up_color"],
                s=100,
                zorder=5,
                label="Current",
            )

        ax.set_title(title or "Volatility Cone", fontsize=14, fontweight="bold")
        ax.set_xlabel("Lookback Window (days)")
        ax.set_ylabel("Volatility (% annualized)")
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("volatility_cone")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Multi-Asset Comparison Charts
    # =========================================================================

    def plot_comparison(
        self,
        assets: dict,
        compare_type: str = "price",
        normalize: bool = True,
        benchmark: str = None,
        title: str = None,
    ) -> str:
        """Generate multi-asset comparison charts."""
        if compare_type == "price":
            return self._plot_price_comparison(assets, normalize, title)
        elif compare_type == "correlation":
            return self._plot_correlation_heatmap(assets, title)
        elif compare_type == "rs":
            return self._plot_relative_strength(assets, benchmark, title)
        else:
            raise ValueError(f"Unknown comparison type: {compare_type}")

    def _plot_price_comparison(
        self, assets: dict, normalize: bool, title: str
    ) -> str:
        """Plot normalized price comparison."""
        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        colors = plt.cm.tab10(np.linspace(0, 1, len(assets)))

        for (symbol, price), color in zip(assets.items(), colors):
            if normalize:
                normalized = (price / price.iloc[0]) * 100
                ax.plot(price.index, normalized, linewidth=2, label=symbol, color=color)
            else:
                ax.plot(price.index, price, linewidth=2, label=symbol, color=color)

        ax.set_title(title or "Price Comparison", fontsize=14, fontweight="bold")
        ax.set_ylabel("Normalized Price (base=100)" if normalize else "Price")
        ax.set_xlabel("Time")
        ax.legend(loc="best")
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("compare_price")
        return self._save_or_return(fig, filename)

    def _plot_correlation_heatmap(self, assets: dict, title: str) -> str:
        """Plot correlation matrix heatmap."""
        import seaborn as sns

        figsize = ChartStyle.get_figure_size("medium")
        fig, ax = plt.subplots(figsize=figsize)

        # Create returns DataFrame
        returns_df = pd.DataFrame({k: v.pct_change().dropna() for k, v in assets.items()})
        corr = returns_df.corr()

        # Determine theme-based colors
        if self.colors["background"] == "#1a1a2e":  # Dark theme
            cmap = "RdBu_r"
        else:
            cmap = "coolwarm"

        sns.heatmap(
            corr,
            annot=True,
            fmt=".2f",
            cmap=cmap,
            center=0,
            vmin=-1,
            vmax=1,
            ax=ax,
            square=True,
            cbar_kws={"label": "Correlation"},
        )
        ax.set_title(title or "Returns Correlation Matrix", fontsize=14, fontweight="bold")

        plt.tight_layout()
        filename = self._generate_filename("compare_correlation")
        return self._save_or_return(fig, filename)

    def _plot_relative_strength(
        self, assets: dict, benchmark: str, title: str
    ) -> str:
        """Plot relative strength ratio against benchmark."""
        from .indicators import calculate_relative_strength

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        if benchmark not in assets:
            raise ValueError(f"Benchmark '{benchmark}' not found in assets")

        benchmark_price = assets[benchmark]
        colors = plt.cm.tab10(np.linspace(0, 1, len(assets)))

        for (symbol, price), color in zip(assets.items(), colors):
            if symbol != benchmark:
                rs = calculate_relative_strength(price, benchmark_price)
                ax.plot(rs.index, rs, linewidth=2, label=f"{symbol}/{benchmark}", color=color)

        ax.axhline(y=100, color=self.colors["grid"], linestyle="--", alpha=0.7)
        ax.set_title(title or f"Relative Strength (vs {benchmark})", fontsize=14, fontweight="bold")
        ax.set_ylabel("RS Ratio (base=100)")
        ax.set_xlabel("Time")
        ax.legend(loc="best")
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("compare_rs")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Volume Analysis Charts
    # =========================================================================

    def plot_volume_analysis(
        self,
        data: pd.DataFrame,
        vol_type: str = "vwap",
        bands: int = 3,
        session: str = "none",
        title: str = None,
    ) -> str:
        """Generate volume analysis charts."""
        if vol_type == "vwap":
            return self._plot_vwap(data, bands, session, title)
        elif vol_type == "profile":
            return self._plot_volume_profile(data, title)
        elif vol_type == "obv":
            return self._plot_obv(data, title)
        else:
            raise ValueError(f"Unknown volume analysis type: {vol_type}")

    def _plot_vwap(
        self, data: pd.DataFrame, bands: int, session: str, title: str
    ) -> str:
        """Plot VWAP with standard deviation bands."""
        from .indicators import calculate_vwap_bands

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [3, 1]}
        )

        # Price and VWAP
        vwap_bands = calculate_vwap_bands(data, num_bands=bands)

        ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5, label="Price")
        ax1.plot(data.index, vwap_bands["vwap"], color=self.colors["text"], linewidth=2, label="VWAP")

        # Plot bands
        for i in range(1, bands + 1):
            alpha = 0.1 + (i * 0.05)
            ax1.fill_between(
                data.index,
                vwap_bands[f"upper_{i}"],
                vwap_bands[f"lower_{i}"],
                alpha=alpha,
                color=self.colors["grid"],
            )

        ax1.set_title(title or "VWAP Analysis", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # Volume
        ax2.bar(
            data.index,
            data["volume"],
            color=self.colors["line"],
            alpha=0.6,
        )
        ax2.set_ylabel("Volume")
        ax2.set_xlabel("Time")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("volume_vwap")
        return self._save_or_return(fig, filename)

    def _plot_volume_profile(self, data: pd.DataFrame, title: str) -> str:
        """Plot volume profile (volume distribution by price)."""
        from .indicators import calculate_volume_profile

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            1, 2, figsize=figsize, gridspec_kw={"width_ratios": [3, 1]}
        )

        # Price chart on left
        ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title(title or "Volume Profile", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.set_xlabel("Time")
        ax1.grid(True, alpha=0.3)

        # Volume profile on right
        vol_profile, bin_edges = calculate_volume_profile(data)

        ax2.barh(
            vol_profile.index,
            vol_profile.values,
            height=(bin_edges[1] - bin_edges[0]) * 0.8,
            color=self.colors["line"],
            alpha=0.6,
        )
        ax2.set_xlabel("Volume")
        ax2.grid(True, alpha=0.3)

        # Link y-axes
        ax2.set_ylim(ax1.get_ylim())

        plt.tight_layout()
        filename = self._generate_filename("volume_profile")
        return self._save_or_return(fig, filename)

    def _plot_obv(self, data: pd.DataFrame, title: str) -> str:
        """Plot On-Balance Volume."""
        from .indicators import calculate_obv

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1]}
        )

        obv = calculate_obv(data)

        # Price
        ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title(title or "On-Balance Volume", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.grid(True, alpha=0.3)

        # OBV
        ax2.plot(data.index, obv, color=self.colors["up_color"], linewidth=1.5)
        ax2.fill_between(
            data.index,
            obv,
            obv.iloc[0],
            where=(obv >= obv.iloc[0]),
            color=self.colors["up_color"],
            alpha=0.3,
        )
        ax2.fill_between(
            data.index,
            obv,
            obv.iloc[0],
            where=(obv < obv.iloc[0]),
            color=self.colors["down_color"],
            alpha=0.3,
        )
        ax2.set_ylabel("OBV")
        ax2.set_xlabel("Time")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("volume_obv")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Drawdown Analysis Charts
    # =========================================================================

    def plot_drawdown(
        self,
        data: pd.DataFrame,
        equity: pd.Series,
        dd_type: str = "underwater",
        top_n: int = 5,
        from_equity: bool = False,
        title: str = None,
    ) -> str:
        """Generate drawdown analysis charts."""
        if dd_type == "underwater":
            return self._plot_underwater_curve(equity, title)
        elif dd_type == "recovery":
            return self._plot_recovery_distribution(equity, title)
        elif dd_type == "top":
            return self._plot_top_drawdowns(data, equity, top_n, title)
        else:
            raise ValueError(f"Unknown drawdown type: {dd_type}")

    def _plot_underwater_curve(self, equity: pd.Series, title: str) -> str:
        """Plot underwater curve (drawdown over time)."""
        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        rolling_max = equity.expanding().max()
        drawdown = (equity - rolling_max) / rolling_max * 100

        ax.fill_between(
            equity.index,
            drawdown,
            0,
            color=self.colors["down_color"],
            alpha=0.5,
        )

        # Mark max drawdown
        max_dd_idx = drawdown.idxmin()
        max_dd = drawdown.min()
        ax.scatter(
            [max_dd_idx],
            [max_dd],
            color=self.colors["down_color"],
            s=100,
            zorder=5,
            label=f"Max DD: {max_dd:.1f}%",
        )

        ax.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
        ax.set_title(title or "Underwater Curve", fontsize=14, fontweight="bold")
        ax.set_ylabel("Drawdown (%)")
        ax.set_xlabel("Time")
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("drawdown_underwater")
        return self._save_or_return(fig, filename)

    def _plot_recovery_distribution(self, equity: pd.Series, title: str) -> str:
        """Plot drawdown recovery time distribution."""
        from .indicators import calculate_drawdowns

        figsize = ChartStyle.get_figure_size("medium")
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

        drawdowns = calculate_drawdowns(equity)

        if not drawdowns.empty:
            # Recovery time histogram
            recovery_times = drawdowns[drawdowns["recovery"].notna()]["duration"]
            if len(recovery_times) > 0:
                ax1.hist(
                    recovery_times,
                    bins=min(20, len(recovery_times)),
                    color=self.colors["line"],
                    alpha=0.7,
                    edgecolor=self.colors["grid"],
                )
                ax1.axvline(
                    x=recovery_times.mean(),
                    color=self.colors["text"],
                    linestyle="--",
                    label=f"Mean: {recovery_times.mean():.1f}d",
                )
            ax1.set_title("Recovery Time Distribution")
            ax1.set_xlabel("Duration (days)")
            ax1.set_ylabel("Frequency")
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            # Drawdown depth histogram
            depths = drawdowns["depth"] * 100
            ax2.hist(
                depths,
                bins=min(20, len(depths)),
                color=self.colors["down_color"],
                alpha=0.7,
                edgecolor=self.colors["grid"],
            )
            ax2.axvline(
                x=depths.mean(),
                color=self.colors["text"],
                linestyle="--",
                label=f"Mean: {depths.mean():.1f}%",
            )
            ax2.set_title("Drawdown Depth Distribution")
            ax2.set_xlabel("Drawdown (%)")
            ax2.set_ylabel("Frequency")
            ax2.legend()
            ax2.grid(True, alpha=0.3)

        fig.suptitle(title or "Drawdown Analysis", fontsize=14, fontweight="bold")
        plt.tight_layout()
        filename = self._generate_filename("drawdown_recovery")
        return self._save_or_return(fig, filename)

    def _plot_top_drawdowns(
        self, data: pd.DataFrame, equity: pd.Series, top_n: int, title: str
    ) -> str:
        """Plot price chart with top N drawdowns highlighted."""
        from .indicators import calculate_drawdowns

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        # Price
        ax.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5, label="Price")

        # Top drawdowns
        drawdowns = calculate_drawdowns(equity)
        if not drawdowns.empty:
            top_drawdowns = drawdowns.nsmallest(top_n, "depth")

            for _, dd in top_drawdowns.iterrows():
                if pd.notna(dd["start"]) and pd.notna(dd["end"]):
                    ax.axvspan(
                        dd["start"],
                        dd["end"],
                        alpha=0.2,
                        color=self.colors["down_color"],
                    )
                    ax.scatter(
                        [dd["start"]],
                        [dd["peak"]],
                        color=self.colors["up_color"],
                        s=80,
                        marker="v",
                        zorder=5,
                    )
                    ax.scatter(
                        [dd["end"]],
                        [dd["trough"]],
                        color=self.colors["down_color"],
                        s=80,
                        marker="^",
                        zorder=5,
                    )

        ax.set_title(title or f"Top {top_n} Drawdowns", fontsize=14, fontweight="bold")
        ax.set_ylabel("Price")
        ax.set_xlabel("Time")
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("drawdown_top")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Calendar Effects Charts
    # =========================================================================

    def plot_calendar(
        self,
        data: pd.DataFrame,
        cal_type: str = "weekday",
        agg_method: str = "mean",
        title: str = None,
    ) -> str:
        """Generate calendar effects analysis charts."""
        if cal_type == "weekday":
            return self._plot_weekday_returns(data, agg_method, title)
        elif cal_type == "month":
            return self._plot_month_returns(data, agg_method, title)
        elif cal_type == "intraday":
            return self._plot_intraday_returns(data, agg_method, title)
        else:
            raise ValueError(f"Unknown calendar type: {cal_type}")

    def _plot_weekday_returns(self, data: pd.DataFrame, agg_method: str, title: str) -> str:
        """Plot returns by day of week."""
        from .indicators import calculate_calendar_returns

        figsize = ChartStyle.get_figure_size("medium")
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

        cal_returns = calculate_calendar_returns(data, freq="weekday")

        if not cal_returns.empty:
            periods = cal_returns["period"]
            returns = cal_returns[agg_method] * 100

            # Bar chart
            colors = [self.colors["up_color"] if r > 0 else self.colors["down_color"] for r in returns]
            ax1.bar(periods, returns, color=colors, alpha=0.7, edgecolor=self.colors["grid"])
            ax1.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
            ax1.set_title(f"Returns by Day of Week ({agg_method})")
            ax1.set_ylabel("Return (%)")
            ax1.set_xlabel("Day")
            ax1.grid(True, alpha=0.3, axis="y")

            # Box plot
            returns_by_day = []
            labels = []
            for period in periods:
                mask = data.index.dayofweek == ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].index(period)
                day_returns = data["close"][mask].pct_change().dropna() * 100
                if len(day_returns) > 0:
                    returns_by_day.append(day_returns)
                    labels.append(period)

            if returns_by_day:
                bp = ax2.boxplot(returns_by_day, tick_labels=labels, patch_artist=True)
                for patch in bp["boxes"]:
                    patch.set_facecolor(self.colors["line"])
                    patch.set_alpha(0.5)
                ax2.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
                ax2.set_title("Return Distribution")
                ax2.set_ylabel("Return (%)")
                ax2.set_xlabel("Day")
                ax2.grid(True, alpha=0.3, axis="y")

        fig.suptitle(title or "Weekday Returns Analysis", fontsize=14, fontweight="bold")
        plt.tight_layout()
        filename = self._generate_filename("calendar_weekday")
        return self._save_or_return(fig, filename)

    def _plot_month_returns(self, data: pd.DataFrame, agg_method: str, title: str) -> str:
        """Plot returns by month."""
        from .indicators import calculate_calendar_returns

        figsize = ChartStyle.get_figure_size("medium")
        fig, ax = plt.subplots(figsize=figsize)

        cal_returns = calculate_calendar_returns(data, freq="month")

        if not cal_returns.empty:
            periods = cal_returns["period"]
            returns = cal_returns[agg_method] * 100

            colors = [self.colors["up_color"] if r > 0 else self.colors["down_color"] for r in returns]
            bars = ax.bar(periods, returns, color=colors, alpha=0.7, edgecolor=self.colors["grid"])

            # Add value labels
            for bar, ret in zip(bars, returns):
                height = bar.get_height()
                ax.annotate(
                    f"{ret:.1f}%",
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3 if height > 0 else -12),
                    textcoords="offset points",
                    ha="center",
                    va="bottom" if height > 0 else "top",
                    fontsize=8,
                )

            ax.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
            ax.set_title(title or f"Returns by Month ({agg_method})", fontsize=14, fontweight="bold")
            ax.set_ylabel("Return (%)")
            ax.set_xlabel("Month")
            ax.grid(True, alpha=0.3, axis="y")

        plt.tight_layout()
        filename = self._generate_filename("calendar_month")
        return self._save_or_return(fig, filename)

    def _plot_intraday_returns(self, data: pd.DataFrame, agg_method: str, title: str) -> str:
        """Plot returns by hour of day."""
        from .indicators import calculate_calendar_returns

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        cal_returns = calculate_calendar_returns(data, freq="hour")

        if not cal_returns.empty:
            periods = cal_returns["period"]
            returns = cal_returns[agg_method] * 100

            colors = [self.colors["up_color"] if r > 0 else self.colors["down_color"] for r in returns]
            ax.bar(periods, returns, color=colors, alpha=0.7, edgecolor=self.colors["grid"])
            ax.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
            ax.set_title(title or f"Returns by Hour ({agg_method})", fontsize=14, fontweight="bold")
            ax.set_ylabel("Return (%)")
            ax.set_xlabel("Hour")
            ax.grid(True, alpha=0.3, axis="y")

        plt.tight_layout()
        filename = self._generate_filename("calendar_intraday")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Market Regime Detection Charts
    # =========================================================================

    def plot_regime(
        self,
        data: pd.DataFrame,
        regime_type: str = "trend",
        period: int = 14,
        fast: int = 20,
        slow: int = 50,
        title: str = None,
    ) -> str:
        """Generate market regime detection charts."""
        if regime_type == "trend":
            return self._plot_trend_regime(data, period, title)
        elif regime_type == "volatility":
            return self._plot_volatility_regime(data, period, title)
        elif regime_type == "ma-cross":
            return self._plot_ma_cross_regime(data, fast, slow, title)
        else:
            raise ValueError(f"Unknown regime type: {regime_type}")

    def _plot_trend_regime(self, data: pd.DataFrame, period: int, title: str) -> str:
        """Plot ADX-based trend regime."""
        from .indicators import calculate_adx

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1]}
        )

        adx_data = calculate_adx(data, period=period)

        # Price with trend shading
        ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)

        # Shade trend strength
        strong_trend = adx_data["adx"] > 25
        ax1.fill_between(
            data.index,
            data["close"].min(),
            data["close"].max(),
            where=strong_trend,
            alpha=0.1,
            color=self.colors["up_color"],
            label="Strong Trend (ADX>25)",
        )

        ax1.set_title(title or "Trend Regime (ADX)", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # ADX
        ax2.plot(data.index, adx_data["adx"], color=self.colors["line"], linewidth=1.5, label="ADX")
        ax2.axhline(y=25, color=self.colors["up_color"], linestyle="--", alpha=0.7, label="Strong Trend")
        ax2.axhline(y=20, color=self.colors["grid"], linestyle="--", alpha=0.5, label="Weak Trend")
        ax2.fill_between(
            adx_data.index,
            adx_data["adx"],
            25,
            where=(adx_data["adx"] > 25),
            color=self.colors["up_color"],
            alpha=0.3,
        )
        ax2.set_ylabel("ADX")
        ax2.set_xlabel("Time")
        ax2.set_ylim(0, 100)
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("regime_trend")
        return self._save_or_return(fig, filename)

    def _plot_volatility_regime(self, data: pd.DataFrame, period: int, title: str) -> str:
        """Plot volatility regime classification."""
        from .indicators import calculate_volatility

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1]}
        )

        volatility = calculate_volatility(data["close"], window=period)
        vol_mean = volatility.mean()
        vol_std = volatility.std()

        high_vol_threshold = vol_mean + vol_std
        low_vol_threshold = max(0, vol_mean - vol_std)

        # Price with volatility regime shading
        ax1.plot(data.index, data["close"], color=self.colors["line"], linewidth=1.5)

        high_vol = volatility > high_vol_threshold
        low_vol = volatility < low_vol_threshold

        # Use volatility.index for fill_between to match mask size
        ax1.fill_between(
            volatility.index,
            data.loc[volatility.index, "close"].min(),
            data.loc[volatility.index, "close"].max(),
            where=high_vol,
            alpha=0.1,
            color=self.colors["down_color"],
            label="High Vol",
        )
        ax1.fill_between(
            volatility.index,
            data.loc[volatility.index, "close"].min(),
            data.loc[volatility.index, "close"].max(),
            where=low_vol,
            alpha=0.1,
            color=self.colors["up_color"],
            label="Low Vol",
        )

        ax1.set_title(title or "Volatility Regime", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # Volatility
        ax2.fill_between(volatility.index, volatility * 100, 0, color=self.colors["line"], alpha=0.5)
        ax2.axhline(
            y=high_vol_threshold * 100,
            color=self.colors["down_color"],
            linestyle="--",
            alpha=0.7,
            label=f"High (>{high_vol_threshold*100:.1f}%)",
        )
        ax2.axhline(
            y=low_vol_threshold * 100,
            color=self.colors["up_color"],
            linestyle="--",
            alpha=0.7,
            label=f"Low (<{low_vol_threshold*100:.1f}%)",
        )
        ax2.set_ylabel(f"Volatility ({period}d, % ann.)")
        ax2.set_xlabel("Time")
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("regime_volatility")
        return self._save_or_return(fig, filename)

    def _plot_ma_cross_regime(self, data: pd.DataFrame, fast: int, slow: int, title: str) -> str:
        """Plot MA crossover regime (bullish/bearish)."""
        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        ma_fast = data["close"].rolling(window=fast).mean()
        ma_slow = data["close"].rolling(window=slow).mean()

        bullish = ma_fast > ma_slow
        bearish = ma_fast < ma_slow

        # Price and MAs
        ax.plot(data.index, data["close"], color=self.colors["line"], linewidth=1, alpha=0.7, label="Price")
        ax.plot(data.index, ma_fast, color=self.colors["up_color"], linewidth=1.5, label=f"MA{fast}")
        ax.plot(data.index, ma_slow, color=self.colors["down_color"], linewidth=1.5, label=f"MA{slow}")

        # Regime shading
        ax.fill_between(
            data.index,
            data["close"].min(),
            data["close"].max(),
            where=bullish,
            alpha=0.1,
            color=self.colors["up_color"],
            label="Bullish",
        )
        ax.fill_between(
            data.index,
            data["close"].min(),
            data["close"].max(),
            where=bearish,
            alpha=0.1,
            color=self.colors["down_color"],
            label="Bearish",
        )

        ax.set_title(title or f"MA Cross Regime (MA{fast}/MA{slow})", fontsize=14, fontweight="bold")
        ax.set_ylabel("Price")
        ax.set_xlabel("Time")
        ax.legend(loc="best")
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("regime_ma_cross")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Trade Annotation Charts
    # =========================================================================

    def plot_trades(
        self,
        data: pd.DataFrame,
        trades: list,
        title: str = None,
        ma_periods: Optional[list] = None,
    ) -> str:
        """Plot OHLCV price chart with trade entry/exit markers overlaid.

        Args:
            data: DataFrame with OHLCV columns (close required, high/low optional).
            trades: List of trade dicts with keys: timestamp/_ts, action, price.
            title: Chart title.
            ma_periods: List of MA periods to overlay.

        Returns:
            Absolute path to saved chart file.
        """
        if not MPF_AVAILABLE:
            raise ImportError("mplfinance required for candlestick charts. Install with: pip install mplfinance")

        df = normalize_ohlcv_index_for_plot(data.copy())

        # Build mpf column rename
        column_map = {
            "open": "Open", "high": "High", "low": "Low",
            "close": "Close", "volume": "Volume",
        }
        df.rename(columns={k: v for k, v in column_map.items() if k in df.columns}, inplace=True)

        mc = mpf.make_marketcolors(
            up=self.colors["up_color"],
            down=self.colors["down_color"],
            edge="inherit",
            wick="inherit",
            volume="inherit",
        )
        s = mpf.make_mpf_style(
            marketcolors=mc,
            figcolor=self.colors["background"],
            facecolor=self.colors["foreground"],
            edgecolor=self.colors["grid"],
            gridcolor=self.colors["grid"],
            gridstyle="-",
            rc={"font.size": 10},
        )

        addplots = []

        # MAs
        if ma_periods:
            for period in ma_periods:
                if len(df) >= period:
                    ma = df["Close"].rolling(window=period).mean()
                    addplots.append(
                        mpf.make_addplot(ma, color=self.colors["line"], width=1)
                    )

        # Trade markers
        long_entries = []
        long_exits = []
        short_entries = []
        short_exits = []

        for trade in trades:
            ts = trade.get("_ts") or trade.get("timestamp")
            if ts is None:
                continue
            action = str(trade.get("action") or "").lower()
            price = trade.get("price")
            if price is None or pd.isna(ts):
                continue

            if action in ("buy", "long", "enter"):
                long_entries.append((ts, float(price)))
            elif action in ("sell", "short", "exit"):
                short_exits.append((ts, float(price)))
            elif action == "close_long":
                long_exits.append((ts, float(price)))
            elif action == "close_short":
                short_entries.append((ts, float(price)))

        # Convert to series for addplot
        if long_entries:
            le_ts, le_px = zip(*long_entries)
            le_series = pd.Series(le_px, index=pd.DatetimeIndex(le_ts).tz_localize(None))
            addplots.append(mpf.make_addplot(le_series, type="scatter", marker="^", color=self.colors["up_color"], markersize=120))

        if short_entries:
            se_ts, se_px = zip(*short_entries)
            se_series = pd.Series(se_px, index=pd.DatetimeIndex(se_ts).tz_localize(None))
            addplots.append(mpf.make_addplot(se_series, type="scatter", marker="v", color=self.colors["down_color"], markersize=120))

        if long_exits:
            lx_ts, lx_px = zip(*long_exits)
            lx_series = pd.Series(lx_px, index=pd.DatetimeIndex(lx_ts).tz_localize(None))
            addplots.append(mpf.make_addplot(lx_series, type="scatter", marker="o", color=self.colors["up_color"], markersize=80))

        if short_exits:
            sx_ts, sx_px = zip(*short_exits)
            sx_series = pd.Series(sx_px, index=pd.DatetimeIndex(sx_ts).tz_localize(None))
            addplots.append(mpf.make_addplot(sx_series, type="scatter", marker="o", color=self.colors["down_color"], markersize=80))

        plot_kwargs = {
            "type": "candle",
            "style": s,
            "title": title or "Trade Markers",
            "ylabel": "Price",
            "volume": False,
            "figsize": ChartStyle.get_figure_size("large"),
            "returnfig": True,
        }
        if addplots:
            plot_kwargs["addplot"] = addplots

        fig, _ = mpf.plot(df, **plot_kwargs)

        filename = self._generate_filename("trades")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Sharpe Ratio & Aggregate Stats Charts
    # =========================================================================

    def plot_sharpe(
        self,
        equity: pd.Series,
        returns: Optional[pd.Series] = None,
        window: int = 20,
        rf_rate: float = 0.0,
        annualize: int = 252,
        title: str = None,
    ) -> str:
        """Generate Sharpe ratio chart with equity curve overlay.

        Produces a 3-panel chart:
          1. Equity curve with rolling Sharpe ratio overlay
          2. Rolling Sharpe ratio time-series
          3. Aggregate stats table (Sharpe, Sortino, Calmar, MaxDD, WinRate)
        """
        from .indicators import calculate_rolling_sharpe, aggregate_stats

        figsize = ChartStyle.get_figure_size("large")
        fig, axes = plt.subplots(
            3, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1, 1]}
        )

        ax1, ax2, ax3 = axes

        # Compute rolling Sharpe
        rolling_sharpe = calculate_rolling_sharpe(equity, window=window, rf_rate=rf_rate, annualize=annualize)

        # Compute aggregate stats
        if returns is None:
            rets = equity.pct_change().dropna()
        else:
            rets = returns
        stats = aggregate_stats(equity, rets, rf_rate=rf_rate, annualize=annualize)

        # Panel 1: Equity curve
        ax1.plot(equity.index, equity, color=self.colors["up_color"], linewidth=2, label="Equity")
        ax1.fill_between(
            equity.index,
            equity,
            alpha=0.2,
            color=self.colors["up_color"],
        )

        # Overlay rolling Sharpe on a secondary y-axis
        if not rolling_sharpe.empty:
            ax1_twin = ax1.twinx()
            ax1_twin.plot(
                rolling_sharpe.index,
                rolling_sharpe,
                color=self.colors["text"],
                linewidth=1,
                alpha=0.7,
                label=f"Rolling Sharpe ({window}d)",
            )
            ax1_twin.axhline(y=0, color=self.colors["grid"], linestyle="--", alpha=0.5)
            ax1_twin.set_ylabel("Rolling Sharpe", fontsize=9)
            ax1_twin.legend(loc="upper right", fontsize=8)

        ax1.set_title(title or "Sharpe Ratio Analysis", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Equity")
        ax1.legend(loc="upper left")
        ax1.grid(True, alpha=0.3)

        # Panel 2: Rolling Sharpe alone
        if not rolling_sharpe.empty:
            ax2.fill_between(
                rolling_sharpe.index,
                rolling_sharpe,
                0,
                where=(rolling_sharpe >= 0),
                color=self.colors["up_color"],
                alpha=0.5,
                label="Positive",
            )
            ax2.fill_between(
                rolling_sharpe.index,
                rolling_sharpe,
                0,
                where=(rolling_sharpe < 0),
                color=self.colors["down_color"],
                alpha=0.5,
                label="Negative",
            )
            ax2.axhline(y=rolling_sharpe.mean(), color=self.colors["text"], linestyle="--", linewidth=1.5, label=f"Mean: {rolling_sharpe.mean():.2f}")
            ax2.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
        ax2.set_ylabel("Sharpe Ratio")
        ax2.set_xlabel("Time")
        ax2.legend(loc="upper right", fontsize=8)
        ax2.grid(True, alpha=0.3)

        # Panel 3: Stats table
        ax3.axis("off")
        if stats:
            stat_text = (
                f"Sharpe: {stats['sharpe']:.2f}   "
                f"Sortino: {stats['sortino']:.2f}   "
                f"Calmar: {stats['calmar']:.2f}   "
                f"MaxDD: {stats['max_drawdown']:.2f}%   "
                f"WinRate: {stats['win_rate']:.1f}%   "
                f"Ann.Return: {stats['annualized_return']:.2f}%   "
                f"Vol: {stats['volatility']:.2f}%"
            )
            ax3.text(0.5, 0.5, stat_text, ha="center", va="center", fontsize=11, transform=ax3.transAxes)
        ax3.set_title("Aggregate Statistics", fontsize=12, fontweight="bold")

        plt.tight_layout()
        filename = self._generate_filename("sharpe")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Multi-Asset Heatmap Charts
    # =========================================================================

    def plot_correlation_rolling(
        self,
        assets: dict,
        window: int = 30,
        title: str = None,
    ) -> str:
        """Plot rolling pairwise correlation heatmap over time.

        X-axis: time periods
        Y-axis: asset pairs
        Color: correlation value (-1 to +1)
        """
        if len(assets) < 2:
            raise ValueError("Need at least 2 assets for correlation heatmap")

        import seaborn as sns

        # Build returns DataFrame
        returns_df = pd.DataFrame({k: v.pct_change().dropna() for k, v in assets.items()})
        if returns_df.empty:
            raise ValueError("No return data available for correlation")

        # Compute rolling pairwise correlations
        rolling_corrs = {}
        symbols = list(returns_df.columns)
        for i, sym_a in enumerate(symbols):
            for sym_b in symbols[i + 1:]:
                pair_key = f"{sym_a}/{sym_b}"
                pair_returns = returns_df[[sym_a, sym_b]].dropna()
                if len(pair_returns) >= window:
                    rc = pair_returns[sym_a].rolling(window=window).corr(pair_returns[sym_b])
                    rolling_corrs[pair_key] = rc

        if not rolling_corrs:
            raise ValueError(f"Not enough data ({len(returns_df)} rows) for window={window}")

        corr_df = pd.DataFrame(rolling_corrs)

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        if self.colors["background"] == "#1a1a2e":
            cmap = "RdBu_r"
        else:
            cmap = "coolwarm"

        sns.heatmap(
            corr_df.T,
            annot=False,
            fmt=".2f",
            cmap=cmap,
            center=0,
            vmin=-1,
            vmax=1,
            ax=ax,
            cbar_kws={"label": "Correlation"},
        )
        ax.set_title(title or f"Rolling Correlation ({window}-period)", fontsize=14, fontweight="bold")
        ax.set_xlabel("Time")
        ax.set_ylabel("Asset Pair")

        plt.tight_layout()
        filename = self._generate_filename("heatmap_correlation_rolling")
        return self._save_or_return(fig, filename)

    def plot_returns_heatmap(
        self,
        assets: dict,
        title: str = None,
    ) -> str:
        """Plot multi-asset returns heatmap by time period.

        Rows: assets
        Columns: time periods (months)
        Color: return percentage
        """
        import seaborn as sns

        # Build resampled returns
        returns_data = {}
        for sym, series in assets.items():
            if isinstance(series.index, pd.DatetimeIndex):
                rets = series.pct_change().dropna()
                returns_data[sym] = rets
            else:
                returns_data[sym] = series.pct_change().dropna()

        # Align all series
        aligned = pd.DataFrame(returns_data)

        # Resample to monthly
        monthly = aligned.resample("ME").last().dropna(how="all")

        if monthly.empty or len(monthly) < 2:
            raise ValueError("Not enough data for monthly returns heatmap")

        # Convert to percentage returns
        monthly_pct = monthly * 100

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        sns.heatmap(
            monthly_pct.T,
            annot=True,
            fmt=".1f",
            cmap="RdYlGn",
            center=0,
            ax=ax,
            cbar_kws={"label": "Return (%)"},
            linewidths=0.5,
        )
        ax.set_title(title or "Monthly Returns Heatmap", fontsize=14, fontweight="bold")
        ax.set_xlabel("Month")
        ax.set_ylabel("Asset")

        plt.tight_layout()
        filename = self._generate_filename("heatmap_returns")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # Order Book / Market Depth Charts
    # =========================================================================

    def plot_orderbook_depth(
        self,
        ob: dict,
        n_levels: int = 20,
        title: str = None,
    ) -> str:
        """Plot market depth (bid/ask depth curves).

        Args:
            ob: Dict with 'bids' and 'asks' as lists of (price, qty) tuples.
            n_levels: Number of top levels to display.
            title: Chart title.

        Returns:
            Absolute path to saved chart file.
        """
        bids = sorted(ob.get("bids", []), reverse=True)[:n_levels]
        asks = sorted(ob.get("asks", []))[:n_levels]

        if not bids and not asks:
            raise ValueError("No bid/ask levels available")

        # Build cumulative depth
        bid_prices, bid_qtys = zip(*bids) if bids else ([], [])
        ask_prices, ask_qtys = zip(*asks) if asks else ([], [])

        bid_cum = list(pd.Series(bid_qtys).cumsum().values)
        ask_cum = list(pd.Series(ask_qtys).cumsum().values)

        figsize = ChartStyle.get_figure_size("large")
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=figsize, gridspec_kw={"height_ratios": [2, 1]}
        )

        # Depth curves
        ax1.plot(
            list(bid_prices), bid_cum,
            color=self.colors["up_color"], linewidth=2, label="Bid Depth"
        )
        ax1.fill_between(
            list(bid_prices), bid_cum, alpha=0.3, color=self.colors["up_color"]
        )
        ax1.plot(
            list(ask_prices), ask_cum,
            color=self.colors["down_color"], linewidth=2, label="Ask Depth"
        )
        ax1.fill_between(
            list(ask_prices), ask_cum, alpha=0.3, color=self.colors["down_color"]
        )

        # Mark spread
        if bids and asks:
            mid = (bids[0][0] + asks[0][0]) / 2
            spread = asks[0][0] - bids[0][0]
            spread_pct = (spread / mid) * 100 if mid > 0 else 0
            ax1.axvline(
                x=mid, color=self.colors["text"],
                linestyle="--", alpha=0.7,
                label=f"Mid: {mid:.2f}  Spread: {spread:.2f} ({spread_pct:.3f}%)"
            )

        ax1.set_title(title or "Market Depth", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Cumulative Volume")
        ax1.legend(loc="best")
        ax1.grid(True, alpha=0.3)

        # Level bar chart (top levels)
        ax2.bar(
            [p for p, _ in bids], [q for _, q in bids],
            color=self.colors["up_color"], alpha=0.7, label="Bid", width=0.001 * (bids[0][0] if bids else 1)
        )
        ax2.bar(
            [p for p, _ in asks], [q for _, q in asks],
            color=self.colors["down_color"], alpha=0.7, label="Ask", width=0.001 * (asks[0][0] if asks else 1)
        )
        ax2.set_ylabel("Volume")
        ax2.set_xlabel("Price")
        ax2.legend(loc="best")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        filename = self._generate_filename("orderbook_depth")
        return self._save_or_return(fig, filename)

    def plot_orderbook_imbalance(
        self,
        ob: dict,
        n_levels: int = 20,
        title: str = None,
    ) -> str:
        """Plot bid/ask volume imbalance by level.

        Args:
            ob: Dict with 'bids' and 'asks' as lists of (price, qty) tuples.
            n_levels: Number of levels to analyze.
            title: Chart title.

        Returns:
            Absolute path to saved chart file.
        """
        bids = sorted(ob.get("bids", []), reverse=True)[:n_levels]
        asks = sorted(ob.get("asks", []))[:n_levels]

        if not bids or not asks:
            raise ValueError("Need both bids and asks to compute imbalance")

        bid_prices = [p for p, _ in bids]
        ask_prices = [p for p, _ in asks]
        bid_qtys = [q for _, q in bids]
        ask_qtys = [q for _, q in asks]

        # Cumulative volumes
        bid_cum = list(pd.Series(bid_qtys).cumsum().values)
        ask_cum = list(pd.Series(ask_qtys).cumsum().values)

        # Imbalance = (bid_cum - ask_cum) / (bid_cum + ask_cum)
        n_compare = min(len(bid_cum), len(ask_cum))
        if n_compare == 0:
            raise ValueError("No levels to compare for imbalance")

        imbalance = [
            (bid_cum[i] - ask_cum[i]) / (bid_cum[i] + ask_cum[i])
            if (bid_cum[i] + ask_cum[i]) > 0 else 0
            for i in range(n_compare)
        ]

        all_prices = sorted(set(bid_prices[:n_compare] + ask_prices[:n_compare]))

        figsize = ChartStyle.get_figure_size("large")
        fig, ax = plt.subplots(figsize=figsize)

        colors = [
            self.colors["up_color"] if imp > 0 else self.colors["down_color"]
            for imp in imbalance
        ]
        ax.bar(
            all_prices[:len(imbalance)], imbalance,
            color=colors, alpha=0.7, width=0.001 * (bids[0][0] if bids else 1)
        )
        ax.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
        ax.axhline(
            y=0.1, color=self.colors["up_color"], linestyle="--", alpha=0.5,
            label="+0.1 (bullish bias)"
        )
        ax.axhline(
            y=-0.1, color=self.colors["down_color"], linestyle="--", alpha=0.5,
            label="-0.1 (bearish bias)"
        )

        ax.set_title(title or "Order Book Imbalance", fontsize=14, fontweight="bold")
        ax.set_ylabel("Imbalance (bid - ask) / (bid + ask)")
        ax.set_xlabel("Price Level")
        ax.legend(loc="best")
        ax.grid(True, alpha=0.3, axis="y")

        plt.tight_layout()
        filename = self._generate_filename("orderbook_imbalance")
        return self._save_or_return(fig, filename)

    # =========================================================================
    # PDF Report Helper Methods
    # =========================================================================

    def _close_fig(self, fig):
        """Close a matplotlib figure without saving (for report use)."""
        plt.close(fig)

    def _plot_equity_chart(self, df):
        """Return a figure for the equity chart page."""
        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("large"))
        ax.plot(df.index, df["equity"], color=self.colors["up_color"], linewidth=2)
        ax.fill_between(df.index, df["equity"], alpha=0.2, color=self.colors["up_color"])
        ax.set_title("Equity Curve", fontsize=14, fontweight="bold")
        ax.set_ylabel("Equity")
        ax.set_xlabel("Time")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    def _plot_drawdown_chart(self, df):
        """Return a figure for the drawdown chart page."""
        eq = df["equity"].astype(float)
        rolling_max = eq.expanding().max()
        dd = (eq - rolling_max) / rolling_max * 100
        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("large"))
        ax.fill_between(df.index, dd, 0, color=self.colors["down_color"], alpha=0.5)
        ax.set_title("Drawdown", fontsize=14, fontweight="bold")
        ax.set_ylabel("Drawdown (%)")
        ax.set_xlabel("Time")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        return fig

    def _plot_sharpe_simple(self, df):
        """Return a figure for the Sharpe ratio page."""
        from .indicators import calculate_rolling_sharpe, aggregate_stats

        equity = df["equity"].astype(float)
        rets = equity.pct_change().dropna()
        rolling_sharpe = calculate_rolling_sharpe(equity, window=20)

        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=ChartStyle.get_figure_size("large"), gridspec_kw={"height_ratios": [2, 1]}
        )
        ax1.plot(equity.index, equity, color=self.colors["up_color"], linewidth=2)
        ax1.fill_between(equity.index, equity, alpha=0.2, color=self.colors["up_color"])
        ax1.set_title("Equity Curve", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Equity")
        ax1.grid(True, alpha=0.3)

        if not rolling_sharpe.empty:
            ax2.fill_between(
                rolling_sharpe.index, rolling_sharpe, 0,
                where=(rolling_sharpe >= 0), color=self.colors["up_color"], alpha=0.5
            )
            ax2.fill_between(
                rolling_sharpe.index, rolling_sharpe, 0,
                where=(rolling_sharpe < 0), color=self.colors["down_color"], alpha=0.5
            )
            ax2.axhline(y=0, color=self.colors["grid"], linestyle="-", alpha=0.5)
        ax2.set_title("Rolling Sharpe Ratio (20-period)", fontsize=14, fontweight="bold")
        ax2.set_ylabel("Sharpe")
        ax2.set_xlabel("Time")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    def _plot_indicator_simple(self, df, indicator="rsi"):
        """Return a figure for a simple indicator page."""
        from .indicators import calculate_rsi

        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=ChartStyle.get_figure_size("large"), gridspec_kw={"height_ratios": [2, 1]}
        )
        ax1.plot(df.index, df["close"], color=self.colors["line"], linewidth=1.5)
        ax1.set_title("Price", fontsize=14, fontweight="bold")
        ax1.set_ylabel("Price")
        ax1.grid(True, alpha=0.3)

        if indicator == "rsi":
            rsi = calculate_rsi(df["close"])
            ax2.plot(df.index, rsi, color=self.colors["line"], linewidth=1.5)
            ax2.axhline(y=70, color=self.colors["down_color"], linestyle="--", alpha=0.7)
            ax2.axhline(y=30, color=self.colors["up_color"], linestyle="--", alpha=0.7)
            ax2.set_ylabel("RSI")
            ax2.set_ylim(0, 100)
        else:
            ax2.text(0.5, 0.5, f"Indicator: {indicator}", ha="center", va="center", transform=ax2.transAxes)

        ax2.set_title(f"{indicator.upper()} Indicator", fontsize=14, fontweight="bold")
        ax2.set_xlabel("Time")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    def _make_summary_page(self, df, summary_block=None):
        """Return a text summary figure."""
        from .indicators import aggregate_stats

        equity = df["equity"].astype(float) if "equity" in df.columns else None
        fig, ax = plt.subplots(figsize=ChartStyle.get_figure_size("large"))
        ax.axis("off")

        if equity is not None:
            rets = equity.pct_change().dropna()
            stats = aggregate_stats(equity, rets)
            lines = [
                f"Sharpe Ratio:    {stats.get('sharpe', 'N/A'):.4f}",
                f"Sortino Ratio:  {stats.get('sortino', 'N/A'):.4f}",
                f"Calmar Ratio:   {stats.get('calmar', 'N/A'):.4f}",
                f"Max Drawdown:   {stats.get('max_drawdown', 'N/A'):.2f}%",
                f"Win Rate:       {stats.get('win_rate', 'N/A'):.2f}%",
                f"Total Return:   {stats.get('total_return', 'N/A'):.2f}%",
                f"Ann. Return:    {stats.get('annualized_return', 'N/A'):.2f}%",
                f"Volatility:     {stats.get('volatility', 'N/A'):.2f}%",
                f"Data Points:   {stats.get('n_periods', 'N/A')}",
            ]
        else:
            lines = ["No equity data available for summary."]

        strat_name = None
        if isinstance(summary_block, dict):
            strat_name = summary_block.get("strategy", {}).get("name")

        title_text = strat_name or "Backtest Summary"
        ax.text(0.1, 0.95, title_text, fontsize=16, fontweight="bold", transform=ax.transAxes)
        for i, line in enumerate(lines):
            ax.text(0.1, 0.85 - i * 0.06, line, fontsize=12, transform=ax.transAxes, family="monospace")

        plt.tight_layout()
        return fig
