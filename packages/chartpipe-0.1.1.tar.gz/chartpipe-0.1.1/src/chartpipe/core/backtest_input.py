"""Load backtest chart input from JSON (quantpipe envelope), artifact paths, or run directory."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
from pandas.errors import EmptyDataError

from .pipeline_json import unwrap_upstream_json


def _resolve_path(p: str, base: Optional[str] = None) -> str:
    path = Path(p)
    if path.is_absolute():
        return str(path)
    root = Path(base) if base else Path.cwd()
    return str((root / path).resolve())


def _load_equity_trades_from_csv(
    equity_path: str,
    trades_path: Optional[str],
) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    eq_df = pd.read_csv(equity_path)
    if eq_df.empty:
        return eq_df, []
    # Normalize timestamp column name
    if "timestamp" not in eq_df.columns:
        raise ValueError(f"equity CSV missing 'timestamp' column: {equity_path}")
    if "equity" not in eq_df.columns:
        raise ValueError(f"equity CSV missing 'equity' column: {equity_path}")
    eq_df = eq_df.copy()
    eq_df["timestamp"] = pd.to_datetime(eq_df["timestamp"], errors="coerce")
    eq_df = eq_df.set_index("timestamp")
    trades: List[Dict[str, Any]] = []
    if trades_path and os.path.isfile(trades_path):
        try:
            tdf = pd.read_csv(trades_path)
        except EmptyDataError:
            tdf = pd.DataFrame()
        for _, row in tdf.iterrows():
            trades.append(
                {
                    "entry_time": row.get("entry_time"),
                    "exit_time": row.get("exit_time") or row.get("timestamp"),
                    "entry_price": row.get("entry_price"),
                    "exit_price": row.get("exit_price") or row.get("price"),
                    "side": row.get("side", "long"),
                }
            )
    return eq_df, trades


def _dataframe_from_equity_body(
    equity_data: Any, trades: List[Dict[str, Any]]
) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    if isinstance(equity_data, list):
        df = pd.DataFrame(equity_data)
    elif isinstance(equity_data, dict):
        df = pd.DataFrame([equity_data])
    else:
        df = pd.DataFrame(equity_data)
    if not df.empty and "timestamp" in df.columns:
        df = df.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df = df.set_index("timestamp")
    return df, trades


def parse_backtest_payload(
    raw: Union[str, Dict[str, Any]],
    *,
    cwd: Optional[str] = None,
) -> Tuple[pd.DataFrame, List[Dict[str, Any]], Dict[str, Any]]:
    """
    Parse backtest input from JSON string or dict.

    Supports:
    - quantpipe-style envelope (ok, data, artifacts)
    - legacy dicts with equity_curve / history
    - seamflux { result: ... } (via unwrap)

    Returns (equity_df indexed by time, trades list, meta dict with keys like envelope_ok, error hints).
    """
    meta: Dict[str, Any] = {}
    if isinstance(raw, str):
        try:
            data = json.loads(raw.strip())
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}") from e
    else:
        data = raw

    data = unwrap_upstream_json(data)

    # quantpipe / chartpipe failure envelope
    if isinstance(data, dict) and data.get("ok") is False:
        err = data.get("error") or {}
        msg = err.get("message", "upstream reported failure")
        raise ValueError(f"Upstream JSON ok=false: {msg}")

    artifacts: Dict[str, Any] = {}
    body: Dict[str, Any]
    if isinstance(data, dict) and data.get("tool") == "quantpipe" and "data" in data:
        body = data.get("data") or {}
        artifacts = dict(data.get("artifacts") or {})
        meta["quantpipe_envelope"] = True
    elif isinstance(data, dict) and "performance" in data and (
        "source" in data or "strategy" in data
    ):
        # Bare quantpipe data body (no envelope)
        body = data
    elif isinstance(data, dict):
        body = data
        artifacts = dict(data.get("artifacts") or {})
    else:
        body = {}
        df = pd.DataFrame(data) if data is not None else pd.DataFrame()
        return df, [], meta

    # Prefer artifact CSV paths (quantpipe --run-dir)
    equity_key = artifacts.get("equity")
    trades_key = artifacts.get("trades")
    if equity_key:
        eq_path = _resolve_path(str(equity_key), cwd)
        tr_path = _resolve_path(str(trades_key), cwd) if trades_key else None
        if not os.path.isfile(eq_path):
            raise FileNotFoundError(f"equity artifact not found: {eq_path}")
        if tr_path and not os.path.isfile(tr_path):
            tr_path = None
        df, trades = _load_equity_trades_from_csv(eq_path, tr_path)
        meta["loaded_from"] = "artifacts"
        return df, trades, meta

    # Inline equity series in body
    if "equity_curve" in body:
        equity_data = body["equity_curve"]
    elif "history" in body:
        equity_data = body["history"]
    elif isinstance(body.get("performance"), dict) and "equity_curve" not in body and "history" not in body:
        raise ValueError(
            "quantpipe JSON has performance metrics but no equity series. "
            "Re-run quantpipe with --run-dir or --run-id so equity.csv is written, "
            "or pass a run directory via chartpipe backtest --run-dir."
        )
    else:
        equity_data = body

    trades = list(body.get("trades") or [])
    df, trades = _dataframe_from_equity_body(equity_data, trades)
    meta["loaded_from"] = "inline"
    return df, trades, meta


def load_from_run_dir(run_dir: str) -> Tuple[pd.DataFrame, List[Dict[str, Any]], Dict[str, Any]]:
    """Load equity.csv and optional trades.csv from a runs/<id>/ style directory."""
    rd = Path(run_dir).resolve()
    equity_p = rd / "equity.csv"
    trades_p = rd / "trades.csv"
    if not equity_p.is_file():
        raise FileNotFoundError(f"Missing equity.csv under {rd}")
    df, trades = _load_equity_trades_from_csv(str(equity_p), str(trades_p) if trades_p.is_file() else None)
    summary_meta: Dict[str, Any] = {"run_dir": str(rd)}
    summary_path = rd / "summary.json"
    if summary_path.is_file():
        try:
            with open(summary_path, encoding="utf-8") as f:
                summary_meta["summary"] = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return df, trades, summary_meta


def title_from_summary(summary: Any, default: str) -> str:
    if not isinstance(summary, dict):
        return default
    strat = summary.get("strategy") or {}
    name = strat.get("name")
    if name:
        return f"Backtest: {name}"
    return default
