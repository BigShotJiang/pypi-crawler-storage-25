"""Chart styles and theme configuration."""

import matplotlib.pyplot as plt


class ChartStyle:
    """Chart styling configuration."""
    
    # Color palettes
    DARK_THEME = {
        'background': '#1a1a2e',
        'foreground': '#16213e',
        'text': '#e94560',
        'up_color': '#00d084',
        'down_color': '#ff4757',
        'volume_up': 'rgba(0, 208, 132, 0.3)',
        'volume_down': 'rgba(255, 71, 87, 0.3)',
        'grid': '#2d3561',
        'line': '#0f3460',
    }
    
    LIGHT_THEME = {
        'background': '#ffffff',
        'foreground': '#f5f5f5',
        'text': '#333333',
        'up_color': '#26a69a',
        'down_color': '#ef5350',
        'volume_up': 'rgba(38, 166, 154, 0.3)',
        'volume_down': 'rgba(239, 83, 80, 0.3)',
        'grid': '#e0e0e0',
        'line': '#2196f3',
    }
    
    # Figure sizes (in inches)
    FIGURE_SIZES = {
        'small': (8, 6),
        'medium': (12, 8),
        'large': (16, 10),
        'wide': (16, 6),
    }
    
    DPI = 150
    
    @classmethod
    def apply_theme(cls, theme='dark'):
        """Apply a theme to matplotlib."""
        colors = cls.DARK_THEME if theme == 'dark' else cls.LIGHT_THEME
        
        plt.rcParams['figure.facecolor'] = colors['background']
        plt.rcParams['axes.facecolor'] = colors['foreground']
        plt.rcParams['axes.edgecolor'] = colors['grid']
        plt.rcParams['axes.labelcolor'] = colors['text']
        plt.rcParams['text.color'] = colors['text']
        plt.rcParams['xtick.color'] = colors['text']
        plt.rcParams['ytick.color'] = colors['text']
        plt.rcParams['grid.color'] = colors['grid']
        plt.rcParams['grid.alpha'] = 0.3
        
        return colors
    
    @classmethod
    def get_figure_size(cls, size='medium'):
        """Get figure size tuple."""
        return cls.FIGURE_SIZES.get(size, cls.FIGURE_SIZES['medium'])
