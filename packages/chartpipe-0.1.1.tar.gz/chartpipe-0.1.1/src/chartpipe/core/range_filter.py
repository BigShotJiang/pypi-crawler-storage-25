"""Date range parsing and OHLCV data slicing for chartpipe."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Tuple, Union

import pandas as pd


@dataclass
class DateRange:
    """Parsed date range with start and end bounds."""
    start: Optional[datetime]
    end: Optional[datetime]

    def has_start(self) -> bool:
        return self.start is not None

    def has_end(self) -> bool:
        return self.end is not None


def parse_range(range_str: str) -> DateRange:
    """Parse a human-readable range string into a DateRange.

    Supported formats:
        7d      → last 7 days from end of data
        1mo     → last 1 month
        3mo     → last 3 months
        6mo     → last 6 months
        1y      → last 1 year
        ytd     → year to date (Jan 1 of current year → now)
        2024    → full year 2024 (Jan 1 → Dec 31)
        2023-2024 → Jan 1 2023 → Dec 31 2024
        2024Q1  → Q1 2024 (Jan 1 → Mar 31)
        2024Q2  → Q2 2024 (Apr 1 → Jun 30)
        2024-03      → March 2024 (Mar 1 → Mar 31)
        2024-03-15   → March 15 2024 (single day)

    Returns:
        DateRange with start and/or end bounds. Caller applies them
        relative to the data's datetime index.

    Raises:
        ValueError: if the range string is unrecognized or malformed.
    """
    if not range_str or not range_str.strip():
        raise ValueError(f"Empty range string")

    s = range_str.strip().lower()

    # Relative periods: Nd, Nw, Nmo (months), N y/yr/years
    m_rel = re.match(r'^(\d+)(d|w|mo|y|yr|yrs)$', s)
    if m_rel:
        value = int(m_rel.group(1))
        unit = m_rel.group(2)
        now = datetime.now(timezone.utc)
        if unit == 'd':
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            start = start - pd.Timedelta(days=value)
            return DateRange(start=start, end=None)
        elif unit == 'w':
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            start = start - pd.Timedelta(weeks=value)
            return DateRange(start=start, end=None)
        elif unit in ('m', 'mo', 'month', 'months'):
            start = _subtract_months(now, value)
            return DateRange(start=start, end=None)
        elif unit in ('y', 'yr', 'yrs'):
            start = _subtract_months(now, value * 12)
            return DateRange(start=start, end=None)

    # ytd — year to date
    if s == 'ytd':
        now = datetime.now(timezone.utc)
        start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        return DateRange(start=start, end=None)

    # Full year: 2024, 2023
    m_year = re.match(r'^(\d{4})$', s)
    if m_year:
        year = int(m_year.group(1))
        start = datetime(year, 1, 1, tzinfo=timezone.utc)
        end = datetime(year, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        return DateRange(start=start, end=end)

    # Year range: 2023-2024
    m_year_range = re.match(r'^(\d{4})-(\d{4})$', s)
    if m_year_range:
        y1, y2 = int(m_year_range.group(1)), int(m_year_range.group(2))
        start = datetime(y1, 1, 1, tzinfo=timezone.utc)
        end = datetime(y2, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        return DateRange(start=start, end=end)

    # Quarter: 2024Q1
    m_quarter = re.match(r'^(\d{4})q([1-4])$', s)
    if m_quarter:
        year = int(m_quarter.group(1))
        quarter = int(m_quarter.group(2))
        month_start = (quarter - 1) * 3 + 1
        start = datetime(year, month_start, 1, tzinfo=timezone.utc)
        # End of last month in quarter
        end_month = quarter * 3
        end_year = year
        if end_month == 12:
            end = datetime(end_year, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        else:
            end = datetime(end_year, end_month + 1, 1, tzinfo=timezone.utc) - pd.Timedelta(seconds=1)
        return DateRange(start=start, end=end)

    # Month: 2024-03 or 2024-3
    m_month = re.match(r'^(\d{4})-(\d{1,2})$', s)
    if m_month:
        year = int(m_month.group(1))
        month = int(m_month.group(2))
        if month < 1 or month > 12:
            raise ValueError(f"Month must be 01-12, got {month}")
        start = datetime(year, month, 1, tzinfo=timezone.utc)
        if month == 12:
            end = datetime(year, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        else:
            end = datetime(year, month + 1, 1, tzinfo=timezone.utc) - pd.Timedelta(seconds=1)
        return DateRange(start=start, end=end)

    # Day: 2024-03-15
    m_day = re.match(r'^(\d{4})-(\d{1,2})-(\d{1,2})$', s)
    if m_day:
        year, month, day = int(m_day.group(1)), int(m_day.group(2)), int(m_day.group(3))
        try:
            start = datetime(year, month, day, 0, 0, 0, tzinfo=timezone.utc)
            end = datetime(year, month, day, 23, 59, 59, tzinfo=timezone.utc)
        except ValueError as e:
            raise ValueError(f"Invalid date {year}-{month:02d}-{day:02d}: {e}")
        return DateRange(start=start, end=end)

    raise ValueError(
        f"Unrecognized range format: '{range_str}'. "
        "Supported: 7d, 1mo, 3mo, 6mo, 1y, ytd, 2024, 2023-2024, 2024Q1, 2024-03, 2024-03-15"
    )


def _subtract_months(dt: datetime, months: int) -> datetime:
    """Subtract `months` from a datetime, approximating calendar months."""
    total_month = dt.month - months
    year = dt.year + total_month // 12
    month = total_month % 12
    if month <= 0:
        month += 12
        year -= 1
    # Cap day to valid range for the target month
    import calendar
    day = min(dt.day, calendar.monthrange(year, month)[1])
    return dt.replace(year=year, month=month, day=day,
                       hour=0, minute=0, second=0, microsecond=0)


def filter_by_range(
    df: pd.DataFrame,
    date_range: DateRange,
    *,
    timestamp_col: str = "timestamp",
) -> pd.DataFrame:
    """Slice a DataFrame to the given DateRange using its datetime index.

    The DataFrame's index must be a DatetimeIndex or contain a parseable
    timestamp column. The date_range bounds are inclusive.

    Args:
        df: DataFrame with datetime index or timestamp column.
        date_range: Parsed DateRange from parse_range().
        timestamp_col: Column name to use if index is not DatetimeIndex.

    Returns:
        Filtered DataFrame. Returns empty DataFrame if no data in range.
    """
    if df.empty:
        return df

    # Ensure we have a DatetimeIndex
    work = df.copy()
    if not isinstance(work.index, pd.DatetimeIndex):
        if timestamp_col in work.columns:
            work[timestamp_col] = pd.to_datetime(work[timestamp_col], errors="coerce")
            work = work.set_index(timestamp_col)
        else:
            return work  # Can't filter without a time index

    # Remove rows with NaT in index before filtering
    work = work[work.index.notna()]

    if work.empty:
        return work

    # Normalize index to UTC-aware DatetimeIndex for comparison
    if work.index.tz is None:
        work.index = work.index.tz_localize("UTC")
    else:
        work.index = work.index.tz_convert("UTC")

    if date_range.has_start():
        start = pd.Timestamp(date_range.start).tz_convert("UTC")
        work = work[work.index >= start]

    if date_range.has_end():
        end = pd.Timestamp(date_range.end).tz_convert("UTC")
        work = work[work.index <= end]

    return work


def range_to_str(date_range: DateRange) -> str:
    """Human-readable representation of a DateRange for use in chart titles."""
    parts = []
    if date_range.has_start():
        parts.append(date_range.start.strftime("%Y-%m-%d"))
    if date_range.has_end():
        parts.append(date_range.end.strftime("%Y-%m-%d"))
    return " → ".join(parts) if parts else "all time"
