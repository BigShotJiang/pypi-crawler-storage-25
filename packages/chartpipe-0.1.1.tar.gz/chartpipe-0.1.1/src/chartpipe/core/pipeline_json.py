"""Pipeline JSON envelope (rule.md §4) and stdout emission."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any, Dict, Optional

SCHEMA_VERSION = 1
TOOL_NAME = "chartpipe"


def unwrap_upstream_json(data: Any) -> Any:
    """
    If stdin/file looks like a seamflux-style wrapper, unwrap once.

    Recognizes top-level ``{"result": {<dict>}}`` and returns the inner dict.
    """
    if isinstance(data, dict):
        inner = data.get("result")
        if isinstance(inner, dict):
            return inner
    return data


def success_envelope(
    command: str,
    *,
    artifacts: Optional[Dict[str, Any]] = None,
    meta: Optional[Dict[str, Any]] = None,
    run_id: Optional[str] = None,
    data: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a successful pipeline summary object (rule.md §4.1)."""
    out: Dict[str, Any] = {
        "schemaVersion": SCHEMA_VERSION,
        "tool": TOOL_NAME,
        "command": command,
        "ok": True,
    }
    if data is not None:
        out["data"] = data
    if run_id is not None:
        out["runId"] = run_id
    if artifacts:
        out["artifacts"] = artifacts
    if meta:
        out["meta"] = meta
    return out


def failure_envelope(command: str, code: str, message: str) -> Dict[str, Any]:
    """Build a failure pipeline summary object (rule.md §4.2)."""
    return {
        "schemaVersion": SCHEMA_VERSION,
        "tool": TOOL_NAME,
        "command": command,
        "ok": False,
        "error": {"code": code, "message": message},
    }


def emit_json_line(payload: Dict[str, Any], *, pretty: bool = False) -> None:
    """
    Write JSON to stdout only.

    With ``pretty=False`` (default for ``--json``), emit a single line for ``jq``/parsers.
    """
    if pretty:
        text = json.dumps(payload, indent=2, default=str) + "\n"
    else:
        text = json.dumps(payload, separators=(",", ":"), default=str) + "\n"
    sys.stdout.write(text)


def utc_now_iso() -> str:
    """ISO-8601 timestamp with Z suffix."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
