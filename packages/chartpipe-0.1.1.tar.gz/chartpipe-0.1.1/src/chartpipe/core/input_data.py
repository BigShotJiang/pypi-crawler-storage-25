"""Normalize JSON / pipeline payloads into DataFrames and timestamps."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Union

import json
import pandas as pd


def _kline_rows_to_dataframe(rows: list) -> pd.DataFrame:
    """Binance-style kline: list of arrays; use first 6 fields as OHLCV."""
    if not rows:
        return pd.DataFrame()
    first = rows[0]
    if not isinstance(first, (list, tuple)):
        return pd.DataFrame(rows)
    df = pd.DataFrame(rows)
    n = min(6, df.shape[1])
    if n < 5:
        return df
    names = ["timestamp", "open", "high", "low", "close", "volume"]
    df = df.iloc[:, :n].copy()
    df.columns = names[:n]
    return df


def json_payload_to_dataframe(data: Any) -> pd.DataFrame:
    """Build DataFrame from parsed JSON (list, dict wrappers, or kline `candles`)."""
    if isinstance(data, list):
        return pd.DataFrame(data)
    if isinstance(data, dict):
        if "data" in data:
            return pd.DataFrame(data["data"])
        if "result" in data:
            return json_payload_to_dataframe(data["result"])
        if "ohlcv" in data:
            return pd.DataFrame(data["ohlcv"])
        if "candles" in data:
            return _kline_rows_to_dataframe(data["candles"])
        # Polymarket: {"history": [{t, p}, ...]} → use the history list
        if "history" in data and isinstance(data["history"], list):
            return pd.DataFrame(data["history"])
        return pd.DataFrame([data])
    raise ValueError(f"Unsupported data format: {type(data)}")


def parse_input_text(input_data: Union[str, Any]) -> Any:
    """Parse str as JSON or file path; pass through non-str."""
    if isinstance(input_data, str):
        try:
            return json.loads(input_data)
        except json.JSONDecodeError:
            path = Path(input_data)
            if path.exists():
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            raise ValueError(f"Invalid input data: {input_data[:100]}...")
    return input_data


COLUMN_MAPPING = {
    "t": "timestamp",
    "T": "timestamp",
    "time": "timestamp",
    "Time": "timestamp",
    "o": "open",
    "O": "open",
    "Open": "open",
    "h": "high",
    "H": "high",
    "High": "high",
    "l": "low",
    "L": "low",
    "Low": "low",
    "c": "close",
    "C": "close",
    "Close": "close",
    "v": "volume",
    "V": "volume",
    "Volume": "volume",
    "vol": "volume",
    "p": "price",        # Polymarket price column
    "P": "price",
}


def normalize_ohlcv_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename short keys and coerce numeric OHLCV columns.

    If the DataFrame has a 'price' column but no OHLCV columns,
    synthesizes open/high/low/close from price so chart commands
    can render Polymarket-style price-history data.
    """
    df = df.rename(columns=COLUMN_MAPPING)
    has_price = "price" in df.columns
    has_ohlcv = {"open", "high", "low", "close"}.issubset(df.columns)
    if has_price and not has_ohlcv:
        # Synthesize OHLCV from a single price column
        df["open"] = df["price"].copy()
        df["high"] = df["price"].copy()
        df["low"] = df["price"].copy()
        df["close"] = df["price"].copy()
        if "volume" not in df.columns:
            df["volume"] = 0.0
    numeric_columns = ["open", "high", "low", "close", "volume"]
    for col in numeric_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def series_looks_like_epoch_ms(series: pd.Series) -> bool:
    """Heuristic: numeric values large enough to be ms since epoch."""
    s = series.dropna()
    if s.empty:
        return False
    if not pd.api.types.is_numeric_dtype(series):
        return False
    try:
        v = float(s.iloc[0])
    except (TypeError, ValueError):
        return False
    return abs(v) > 1e11


def to_datetime_series(series: pd.Series) -> pd.Series:
    """Parse timestamps: epoch ms (int/float), seconds, or calendar strings."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    # String / object dtype (e.g. "2024-01-01"): parse as calendar strings first.
    if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
        parsed = pd.to_datetime(series, errors="coerce")
        if not parsed.isna().all():
            return parsed
    if series_looks_like_epoch_ms(series):
        return pd.to_datetime(series, unit="ms", errors="coerce")
    if pd.api.types.is_numeric_dtype(series):
        s = series.dropna()
        if not s.empty:
            v = abs(float(s.iloc[0]))
            if v > 1e9:
                return pd.to_datetime(series, unit="s", errors="coerce")
    return pd.to_datetime(series, errors="coerce")


def normalize_timestamp_column_to_index(df: pd.DataFrame) -> pd.DataFrame:
    """If `timestamp` column exists, parse it and set as index (indicators/stats)."""
    if "timestamp" not in df.columns:
        return df
    out = df.copy()
    out["timestamp"] = to_datetime_series(out["timestamp"])
    return out.set_index("timestamp")


def normalize_ohlcv_index_for_plot(df: pd.DataFrame) -> pd.DataFrame:
    """Set datetime index for mplfinance without mis-parsing ms epoch as ns (OHLCV charts)."""
    out = df.copy()
    if "timestamp" in out.columns:
        out = out.set_index("timestamp")
    idx = pd.Series(out.index)
    if isinstance(out.index, pd.DatetimeIndex):
        return out
    if series_looks_like_epoch_ms(idx):
        out.index = pd.DatetimeIndex(pd.to_datetime(idx, unit="ms", errors="coerce"))
        return out
    if pd.api.types.is_object_dtype(idx.dtype) or pd.api.types.is_string_dtype(idx.dtype):
        out.index = pd.DatetimeIndex(pd.to_datetime(idx, errors="coerce"))
        return out
    if pd.api.types.is_numeric_dtype(idx.dtype) and not idx.empty:
        v = abs(float(idx.dropna().iloc[0]))
        if v > 1e9:
            out.index = pd.DatetimeIndex(pd.to_datetime(idx, unit="s", errors="coerce"))
        # else: keep numeric index (row labels)
    return out
