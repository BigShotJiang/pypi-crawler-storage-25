#!/usr/bin/env python3
"""Entry point for python -m chartpipe."""

from .cli import cli

if __name__ == '__main__':
    cli()
