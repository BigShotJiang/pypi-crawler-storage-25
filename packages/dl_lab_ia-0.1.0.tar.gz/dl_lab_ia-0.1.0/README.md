# dl-lab-ia

Simple loader for DL lab program scripts.

## Install

```bash
pip install dl-lab-ia
```

## Use

```python
import dl_ia as dl

dl.load(1)
dl.load("8fast")
dl.load(8, "slow")
```