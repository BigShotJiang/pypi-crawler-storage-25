from __future__ import annotations

from importlib import resources
from typing import Iterable, Optional, Union


_INT_MAP = {
    1: "1.py",
    2: "2.py",
    3: "3.py",
    4: "4.py",
    5: "5.py",
    6: "6.py",
    7: "7.py",
}

_STR_MAP = {
    "8fast": "8fast.py",
    "8slow": "8slow.py",
}


def _resolve_filename(program: Union[int, str], variant: Optional[str]) -> str:
    if isinstance(program, int):
        if program == 8:
            v = (variant or "fast").strip().lower()
            if v not in ("fast", "slow"):
                raise ValueError("variant must be 'fast' or 'slow' for program 8")
            return f"8{v}.py"
        if program in _INT_MAP:
            return _INT_MAP[program]
        raise ValueError("program must be 1-8")

    key = program.strip().lower()
    if key in _STR_MAP:
        return _STR_MAP[key]
    if key.isdigit():
        return _resolve_filename(int(key), variant)
    raise ValueError("program must be 1-8 or '8fast'/'8slow'")


def load(program: Union[int, str], variant: Optional[str] = None, print_output: bool = True) -> str:
    filename = _resolve_filename(program, variant)
    content = (
        resources.files("dl_ia")
        .joinpath("scripts", filename)
        .read_text(encoding="utf-8")
    )
    if print_output:
        end = "" if content.endswith("\n") else "\n"
        print(content, end=end)
    return content


def list_programs() -> Iterable[str]:
    return [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8fast",
        "8slow",
    ]
