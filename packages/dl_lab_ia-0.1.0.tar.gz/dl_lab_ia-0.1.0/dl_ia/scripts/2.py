import tensorflow as tf, matplotlib.pyplot as plt, numpy as np

# Data
(x_tr,y_tr),(x_te,y_te)=tf.keras.datasets.mnist.load_data()
x_tr,x_te=x_tr.reshape(-1,784)/255.0,x_te.reshape(-1,784)/255.0

# Model
model=tf.keras.Sequential([
 tf.keras.layers.Dense(128,activation='relu',input_shape=(784,)),
 tf.keras.layers.Dropout(0.2),
 tf.keras.layers.Dense(10,activation='softmax')
])

# Train
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
model.fit(x_tr,y_tr,epochs=5,batch_size=32,validation_split=0.1,verbose=1)

acc = model.evaluate(x_te, y_te, verbose=0)[1]
print(f"Accuracy: {acc:.4f}")

pred=model.predict(x_te[:9])
for i in range(9):
 plt.subplot(3,3,i+1)
 plt.imshow(x_te[i].reshape(28,28),cmap='gray')
 plt.title(f"T:{y_te[i]} P:{np.argmax(pred[i])}")
 plt.axis('off')
plt.show()
