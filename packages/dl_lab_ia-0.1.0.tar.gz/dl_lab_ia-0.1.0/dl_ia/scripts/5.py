import tensorflow as tf, matplotlib.pyplot as plt
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split

# Data
(x_tr,y_tr),(x_te,y_te)=tf.keras.datasets.fashion_mnist.load_data()
x_tr,x_te=x_tr[:15000]/255.0,x_te[:3000]/255.0
y_tr,y_te=y_tr[:15000],y_te[:3000]

x_tr,x_val,y_tr,y_val=train_test_split(x_tr,y_tr,test_size=0.2)

x_tr=x_tr.reshape(-1,784)
x_val=x_val.reshape(-1,784)
x_te=x_te.reshape(-1,784)

# Model
def model(l2=0,d=0):
    reg=tf.keras.regularizers.l2(l2) if l2 else None
    
    return tf.keras.Sequential([
      tf.keras.Input(shape=(784,)),
      layers.Dense(128, activation='relu', kernel_regularizer=reg),
      layers.Dropout(d),
      layers.Dense(10, activation='softmax')
    ])

# Train
def run(name,l2,d):
    m=model(l2,d)

    m.compile(optimizer='adam', loss='sparse_categorical_crossentropy',
            metrics=['accuracy'])

    h=m.fit(x_tr,y_tr, epochs=5, batch_size=64,
            validation_data=(x_val,y_val), verbose=0)

    plt.plot(h.history['val_loss'],label=name)

    print(name,
          "Val:",m.evaluate(x_val,y_val,verbose=0)[1],
          "Test:",m.evaluate(x_te,y_te,verbose=0)[1])

run("No Regularization",0,0)
run("L2",0.01,0)
run("Dropout",0,0.5)
run("Both",0.01,0.5)

plt.legend()
plt.show()
