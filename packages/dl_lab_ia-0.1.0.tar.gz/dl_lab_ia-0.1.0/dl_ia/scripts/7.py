#7program
import tensorflow as tf, matplotlib.pyplot as plt

(x_tr,y_tr),(x_te,y_te)=tf.keras.datasets.imdb.load_data(num_words=10000)
x_tr=tf.keras.preprocessing.sequence.pad_sequences(x_tr,200)
x_te=tf.keras.preprocessing.sequence.pad_sequences(x_te,200)

m=tf.keras.Sequential([
    tf.keras.layers.Embedding(10000,32),
    tf.keras.layers.SimpleRNN(32),
    tf.keras.layers.Dense(1,activation='sigmoid')
])

m.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

h=m.fit(x_tr,y_tr,epochs=5,batch_size=128,validation_split=0.2)

print(f"Test Accuracy: {m.evaluate(x_te,y_te,verbose=0)[1]:.4f}")

plt.plot(h.history['accuracy']); plt.plot(h.history['val_accuracy'])
plt.legend(['Train','Val']); plt.show()

wi=tf.keras.datasets.imdb.get_word_index()
rwi={v:k for k,v in wi.items()}
decode=lambda s:' '.join([rwi.get(i,'?') for i in s if i>3])

p=(m.predict(x_te[:5])>0.5).astype(int).flatten()
for i in range(5):
    print("\nReview",i+1)
    print("True:", "Positive" if y_te[i] else "Negative")
    print("Pred:", "Positive" if p[i] else "Negative")
    print("Text:", decode(x_te[i][:50]),"...")
