import torch, time
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as T

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

transform = T.Compose([T.ToTensor(), T.Normalize((0.5,)*3, (0.5,)*3)])
trainloader = torch.utils.data.DataLoader(
    torchvision.datasets.CIFAR10('./data', train=True, download=True, transform=transform),
    batch_size=64, shuffle=True)

testloader = torch.utils.data.DataLoader(
    torchvision.datasets.CIFAR10('./data', train=False, download=True, transform=transform),
    batch_size=64)

# Model
class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3,32,3,1,1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32,64,3,1,1), nn.ReLU(), nn.MaxPool2d(2))
        self.fc = nn.Sequential(nn.Linear(64*8*8,256), nn.ReLU(), nn.Linear(256,10))

    def forward(self,x):
        return self.fc(self.conv(x).view(x.size(0), -1))

# Optimizer
def get_optimizer(name, params):
    if name == "SGD":
        return optim.SGD(params, lr=0.01)
    elif name == "Adam":
        return optim.Adam(params, lr=0.001)
    elif name == "RMSprop":
        return optim.RMSprop(params, lr=0.001)

# Train + Test
def train_model(opt_name):
    model = SimpleCNN().to(device)
    opt = get_optimizer(opt_name, model.parameters())
    loss_fn = nn.CrossEntropyLoss()
    start = time.time()

    for e in range(5):
        total = 0
        for x,y in trainloader:
            x,y = x.to(device), y.to(device)
            opt.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            total += loss.item()
        print(f"{opt_name} | Epoch {e+1} | Loss: {total/len(trainloader):.4f}")

    print(f"{opt_name} Final Accuracy: {test(model):.2f}%")
    print(f"{opt_name} Training Time: {time.time()-start:.2f} seconds\n")

# Test
def test(model):
    correct = total = 0
    model.eval()
    with torch.no_grad():
        for x,y in testloader:
            x,y = x.to(device), y.to(device)
            pred = model(x).argmax(1)
            total += y.size(0)
            correct += (pred==y).sum().item()
    return 100 * correct / total

for opt in ["SGD","Adam","RMSprop"]:
    train_model(opt)
