#6th program
import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt

(x_tr,y_tr),(x_te,y_te)=tf.keras.datasets.mnist.load_data()
x_tr,x_te=x_tr[...,None]/255.0,x_te[...,None]/255.0

model=models.Sequential([
    layers.Conv2D(32,(3,3),activation='relu',input_shape=(28,28,1)),
    layers.MaxPooling2D(2),
    layers.Conv2D(64,(3,3),activation='relu'),
    layers.MaxPooling2D(2),
    layers.Flatten(),
    layers.Dense(64,activation='relu'),
    layers.Dense(10,activation='softmax')
])

model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
model.fit(x_tr,y_tr,epochs=3,validation_data=(x_te,y_te))

print(f"Test Accuracy: {model.evaluate(x_te,y_te,verbose=0)[1]:.4f}")

f,_=model.layers[0].get_weights()
fig,ax=plt.subplots(2,3,figsize=(8,5))

for i,a in enumerate(ax.flat):
    a.imshow(f[:,:,0,i],cmap='gray')
    a.axis('off')
    a.set_title(f'F{i+1}')

plt.show()
