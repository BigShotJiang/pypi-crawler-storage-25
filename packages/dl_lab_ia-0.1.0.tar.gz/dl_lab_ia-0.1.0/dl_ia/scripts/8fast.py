import tensorflow as tf, numpy as np, matplotlib.pyplot as plt
from tensorflow.keras import layers, models
from tensorflow.keras.applications import VGG16

# Small dataset
(x_tr,y_tr),(x_te,y_te)=tf.keras.datasets.cifar10.load_data()

x_tr,y_tr=x_tr[:2000],y_tr[:2000]
x_te,y_te=x_te[:500],y_te[:500]

# Preprocess
def prep(x,y):
    return tf.image.resize(x,(32,32))/255.0, y

tr=tf.data.Dataset.from_tensor_slices((x_tr,y_tr)).map(prep).batch(32)
va=tf.data.Dataset.from_tensor_slices((x_te,y_te)).map(prep).batch(32)

# Pretrained model
base=VGG16(weights='imagenet',
           include_top=False,
           input_shape=(32,32,3))

# Freeze model
base.trainable=False

# Model
m=models.Sequential([
    base,
    layers.GlobalAveragePooling2D(),
    layers.Dense(64,activation='relu'),
    layers.Dense(10,activation='softmax')
])

# Train
m.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

m.fit(tr,epochs=1,validation_data=va)

# Accuracy
print(f"Accuracy: {m.evaluate(va,verbose=0)[1]:.4f}")

# Predictions
img,lab=next(iter(va))
pred=np.argmax(m.predict(img),1)

for i in range(4):
    plt.subplot(2,2,i+1)
    plt.imshow(img[i])
    plt.title(f"T:{lab[i][0]} P:{pred[i]}")
    plt.axis('off')

plt.show()
