import numpy as np
import matplotlib.pyplot as plt

class Perceptron:
    def __init__(self):
        self.w = np.random.randn(2)
        self.b = np.random.randn()

    def predict(self, x):
        return np.where(np.dot(x, self.w) + self.b > 0, 1, 0)

    def train(self, X, y, lr=0.1, epochs=10):
        for _ in range(epochs):
            for xi, yi in zip(X, y):
                err = yi - self.predict(xi)
                self.w += lr * err * xi
                self.b += lr * err

# Data (AND gate)
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 0, 0, 1])

# Train model
p = Perceptron()
p.train(X, y)

# Decision boundary
x_line = np.linspace(-0.5, 1.5, 100)
y_line = -(p.w[0] * x_line + p.b) / p.w[1]

# Plot
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='bwr')
plt.plot(x_line, y_line)
plt.show()
