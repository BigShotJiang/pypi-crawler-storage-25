import numpy as np

# Input and Output
x=np.array([[2,9],[1,5],[3,6]],dtype=float)
y=np.array([[0.92],[0.86],[0.89]],dtype=float)

def sigmoid(z):
    return 1/(1+np.exp(-z))

def d_sigmoid(z):
    return z*(1-z)

def tanh(z):
    return np.tanh(z)

def d_tanh(z):
    return 1-z**2

def relu(z):
    return np.maximum(0,z)

def d_relu(z):
    return np.where(z>0,1,0)

# Training Function
def train(act,d_act,name):

    np.random.seed(1)

    # Weights
    w1=np.random.uniform(size=(2,3))
    w2=np.random.uniform(size=(3,1))

    # Bias
    b1=np.random.uniform(size=(1,3))
    b2=np.random.uniform(size=(1,1))

    lr=0.1

    for _ in range(1000):

        # Forward
        h_in=np.dot(x,w1)+b1
        h_out=act(h_in)

        o_in=np.dot(h_out,w2)+b2
        y_pred=sigmoid(o_in)

        # Backprop
        error=y-y_pred
        d_out=error*d_sigmoid(y_pred)
        d_hidden=d_out.dot(w2.T)*d_act(h_out)

        # Update
        w2+=h_out.T.dot(d_out)*lr
        w1+=x.T.dot(d_hidden)*lr

    print(f"\n{name} Activation")
    print(y_pred)

# Run
train(sigmoid,d_sigmoid,"Sigmoid")
train(tanh,d_tanh,"Tanh")
train(relu,d_relu,"ReLU")
