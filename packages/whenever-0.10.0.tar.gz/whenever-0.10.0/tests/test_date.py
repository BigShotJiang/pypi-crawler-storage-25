import pickle
import re
from copy import copy, deepcopy
from datetime import date as py_date, datetime as py_datetime
from itertools import chain, product
from typing import Literal

import pytest

from tests.test_date_delta import make_ddelta
from whenever import (
    Date,
    DateDelta,
    IsoWeekDate,
    ItemizedDateDelta,
    MonthDay,
    PlainDateTime,
    Time,
    Weekday,
    WheneverDeprecationWarning,
    YearMonth,
)

from .common import (
    AlwaysEqual,
    AlwaysLarger,
    AlwaysSmaller,
    NeverEqual,
)

MAX_I64 = 1 << 63
MAX_I32 = 1 << 31
pytestmark = pytest.mark.filterwarnings(
    "ignore::whenever.WheneverDeprecationWarning"
)


class TestInit:

    def test_args(self):
        d = Date(2021, 1, 2)
        assert d.year == 2021
        assert d.month == 1
        assert d.day == 2

    def test_kwargs(self):
        d = Date(year=2021, month=1, day=2)
        assert d.year == 2021
        assert d.month == 1
        assert d.day == 2

    @pytest.mark.parametrize(
        "args, kwargs",
        [
            ((2021, 1, 2), {}),
            ((), {"year": 2021, "month": 1, "day": 2}),
            ((2021,), {"month": 1, "day": 2}),
            ((2021, 3), {"day": 2}),
            ((2021, 3, 1), {}),
        ],
    )
    def test_valid_arg_kwargs(self, args, kwargs):
        assert Date(*args, **kwargs) is not None

    @pytest.mark.parametrize(
        "args, kwargs",
        [
            ((), {}),
            ((2021,), {"month": 1}),
            ((2021,), {"day": 2}),
            ((2021, 3, 4), {"day": 2}),
            ((2021, 3), {"day": 2, "month": 5}),
            ((2021, 3, 4), {"foo": 3}),
            ((2021, 3), {"day": 4, "foo": 3}),
            ((2021, 3), {9: 4, "foo": 3}),
            (("2021", 3, 1), {}),
        ],
    )
    def test_invalid_arg_kwargs(self, args, kwargs):
        with pytest.raises(TypeError):
            Date(*args, **kwargs)

    def test_not_enough_args(self):
        with pytest.raises(TypeError, match=r"day"):
            Date(2021, 1)  # type: ignore[call-overload]

        with pytest.raises(TypeError):
            Date(2021)  # type: ignore[call-overload]

        with pytest.raises(TypeError):
            Date()  # type: ignore[call-overload]

    @pytest.mark.parametrize(
        "year, month, day",
        [
            (0, 1, 2),
            (-1, 2, 28),
            (-MAX_I64 + 8, 2, 28),  # underflow
            (10_000, 2, 28),
            (MAX_I64 + 4, 2, 28),
            (-MAX_I64, 2, 28),
        ],
    )
    def test_invalid_year(self, year, month, day):
        with pytest.raises(
            (ValueError, OverflowError), match="int|range|date|year"
        ):
            Date(year, month, day)

    @pytest.mark.parametrize(
        "year, month, day",
        [
            (2021, 0, 1),
            (2021, 13, 1),
            (2021, -1, 1),
            (2021, MAX_I64, 1),
            (2021, -MAX_I64, 1),
        ],
    )
    def test_invalid_month(self, year, month, day):
        with pytest.raises(
            (ValueError, OverflowError), match="int|range|date|month"
        ):
            Date(year, month, day)

    @pytest.mark.parametrize(
        "year, month, day",
        [
            (2021, 1, 0),
            (2021, 12, 32),
            (2021, 12, -1),
            (2021, 1, MAX_I64),
            (2021, 1, -MAX_I64),
            # specific months
            (2021, 4, 31),
            (2021, 2, 29),
        ],
    )
    def test_invalid_day(self, year, month, day):
        with pytest.raises(
            (ValueError, OverflowError), match="int|range|date|day"
        ):
            Date(year, month, day)

    def test_iso_string(self):
        assert Date("2023-01-02") == Date(2023, 1, 2)


def test_year_month():
    d = Date(2021, 1, 2)
    assert d.year_month() == YearMonth(2021, 1)


def test_month_day():
    d = Date(2021, 1, 2)
    assert d.month_day() == MonthDay(1, 2)


def test_to_stdlib():
    d = Date(2021, 1, 2)
    assert d.to_stdlib() == py_date(2021, 1, 2)


def test_today_in_system_tz():
    d = Date.today_in_system_tz()
    # NOTE: this may fail if the test is run *exactly* at midnight.
    # Mocking this out would make things more complicated than it's worth.
    assert d == Date(py_date.today())


def test_init_from_py_date():
    assert Date(py_date(2021, 1, 2)) == Date(2021, 1, 2)
    assert Date(py_datetime(2021, 1, 2, 3, 4, 5)) == Date(2021, 1, 2)

    class CustomDate(py_date):
        pass

    assert Date(CustomDate(2021, 1, 2)) == Date(2021, 1, 2)

    with pytest.raises(TypeError):
        Date(20210102)  # type: ignore[call-overload]


def test_format_iso():
    d = Date(2021, 1, 2)
    assert d.format_iso() == "2021-01-02"
    assert d.format_iso(basic=True) == "20210102"

    with pytest.raises(TypeError):
        d.format_iso(3)  # type: ignore[arg-type, misc]

    with pytest.raises(TypeError):
        d.format_iso(sep="T")  # type: ignore[call-arg]


def test_str():
    d = Date(2021, 1, 2)
    assert str(d) == "2021-01-02"


class TestParseIso:

    @pytest.mark.parametrize(
        "s, expected",
        [
            # Extended ISO format
            ("0001-01-01", Date(1, 1, 1)),
            ("2000-01-01", Date(2000, 1, 1)),
            ("2015-11-22", Date(2015, 11, 22)),
            ("9999-12-31", Date(9999, 12, 31)),
            # "Basic" ISO format
            ("00010101", Date(1, 1, 1)),
            ("20000101", Date(2000, 1, 1)),
            ("20150902", Date(2015, 9, 2)),
            ("99991231", Date(9999, 12, 31)),
        ],
    )
    def test_valid(self, s, expected):
        assert Date.parse_iso(s) == expected

    @pytest.mark.parametrize(
        "s",
        [
            # non-digits
            "202A-01-02",
            "2022-a1-02",
            "2022-a1-02",
            "2023-01-3o",
            "2023Ww1-3",
            "2021-01-02T03:04:05",  # with a time
            # bad separators
            "2021-01/02",
            "2021/01-02",
            # wrong padding
            "2021-1-2",
            "021-1-002",
            # inconsistent dash use
            "2020W12-3",
            "2020-W123",
            "2020W01-3",
            "202011-12",
            "2020-1112",
            "2020-1112",
            "2020-w12-3",  # lowercase w
            # other
            "20-12-03",  # two-digit year
            "-012-12-03",  # negative year
            "312🧨-12-03",  # non-ASCII
            "202𝟙-11-02",  # non-ascii
            "999991112",  # too many digits
            "2023-W03-",  # empty day
            "YYYY-MM-DD",
            "2023/11/01",
            "2023.11.01",
            "",
            "1234",
            "1",
            "1_992101",
            # invalid dates
            "2021-02-29",
            "2021-366",
            "2000-00-03",
            "2000-13-03",
            "2000-01-32",
            "2000-01-00",
            "1989-W53",
            "1989-W22-8",
            "1989-W22-0",
            # Week and ordinal not implemented
            "2021-W01-01",
            "2021-344",
            "2021W134",
            "2021214",
            # incomplete
            "2021-01",
            "202101",
        ],
    )
    def test_invalid(self, s):
        with pytest.raises(
            ValueError,
            match=r"Invalid format.*" + re.escape(repr(s)),
        ):
            Date.parse_iso(s)

    def test_no_string(self):
        with pytest.raises((TypeError, AttributeError), match="(int|str)"):
            Date.parse_iso(20210102)  # type: ignore[arg-type]


def test_replace():
    d = Date(2021, 1, 2)
    assert d.replace(year=2022) == Date(2022, 1, 2)
    assert d.replace(month=2) == Date(2021, 2, 2)
    assert d.replace(day=3) == Date(2021, 1, 3)
    assert d == Date(2021, 1, 2)  # original is unchanged

    with pytest.raises(TypeError):
        d.replace(3)  # type: ignore[misc]

    with pytest.raises(TypeError, match="foo"):
        d.replace(foo=3)  # type: ignore[call-arg]

    with pytest.raises(TypeError, match="foo"):
        d.replace(foo="blabla")  # type: ignore[call-arg]

    with pytest.raises(ValueError, match="(date|year)"):
        d.replace(year=10_000)


def test_kwarg_interning_bug_issue_149():
    d = Date(2021, 1, 2)
    assert d.replace(**{"day": 4, "y" + (lambda: "ear")(): 2022}) == Date(
        2022, 1, 4
    )


def test_at():
    d = Date(2021, 1, 2)
    assert d.at(Time(3, 4, 5)) == PlainDateTime(2021, 1, 2, 3, 4, 5)


def test_repr():
    d = Date(221, 1, 2)
    assert repr(d) == 'Date("0221-01-02")'


def test_hash():
    d = Date(2021, 1, 2)
    assert hash(d) == hash(Date(2021, 1, 2))
    assert hash(d) != hash(Date(2021, 1, 3))


def test_eq():
    d = Date(2021, 1, 2)
    same = Date(2021, 1, 2)
    different = Date(2021, 1, 3)

    assert d == same
    assert not d == different
    assert not d == NeverEqual()
    assert d == AlwaysEqual()

    assert not d != same
    assert d != different
    assert d != NeverEqual()
    assert not d != AlwaysEqual()
    assert d != None  # noqa: E711
    assert None != d  # noqa: E711
    assert not d == None  # noqa: E711
    assert not None == d  # noqa: E711

    assert hash(d) == hash(same)


def test_comparison():
    d = Date(2021, 5, 10)
    same = Date(2021, 5, 10)
    bigger = Date(2022, 2, 28)
    smaller = Date(2020, 12, 31)

    assert d <= same
    assert d <= bigger
    assert not d <= smaller
    assert d <= AlwaysLarger()
    assert not d <= AlwaysSmaller()

    assert not d < same
    assert d < bigger
    assert not d < smaller
    assert d < AlwaysLarger()
    assert not d < AlwaysSmaller()

    assert d >= same
    assert not d >= bigger
    assert d >= smaller
    assert not d >= AlwaysLarger()
    assert d >= AlwaysSmaller()

    assert not d > same
    assert not d > bigger
    assert d > smaller
    assert not d > AlwaysLarger()
    assert d > AlwaysSmaller()


class TestAdd:

    @pytest.mark.parametrize(
        "d, kwargs, expected",
        [
            (Date(2021, 1, 31), dict(), Date(2021, 1, 31)),
            (Date(2021, 1, 31), dict(days=1), Date(2021, 2, 1)),
            (Date(2021, 2, 1), dict(days=-1), Date(2021, 1, 31)),
            (Date(2021, 2, 28), dict(months=-2), Date(2020, 12, 28)),
            (Date(2021, 1, 31), dict(years=1), Date(2022, 1, 31)),
            (Date(2021, 1, 31), dict(months=37), Date(2024, 2, 29)),
            (Date(2020, 2, 29), dict(years=1), Date(2021, 2, 28)),
            (Date(2020, 2, 29), dict(years=1, days=1), Date(2021, 3, 1)),
            (Date(2020, 2, 29), dict(years=1, weeks=2), Date(2021, 3, 14)),
            (
                Date(2020, 1, 30),
                dict(years=1, months=1, days=1),
                Date(2021, 3, 1),
            ),
            (
                Date(2020, 1, 30),
                dict(years=1, months=1, weeks=1),
                Date(2021, 3, 7),
            ),
            # this checks that truncation isn't done after years, but after
            # months *and* years
            (
                Date(2020, 2, 29),
                dict(years=1, months=1),
                Date(2021, 3, 29),
            ),
        ],
    )
    def test_valid(self, d, kwargs, expected):
        assert d.add(**kwargs) == expected

        assert d.add(DateDelta(**kwargs)) == expected
        assert d + DateDelta(**kwargs) == expected

        if kwargs:  # skip the empty delta case
            assert d.add(ItemizedDateDelta(**kwargs)) == expected

    def test_operator_deprecation_warning(self):

        d = Date(2021, 1, 31)
        delta = DateDelta(months=2)
        with pytest.warns(
            WheneverDeprecationWarning, match=r"\+ operator.*add"
        ):
            assert (d + delta) is not None

    @pytest.mark.parametrize(
        "d, kwargs",
        [
            (Date(2021, 1, 31), dict(years=8000)),
            (Date(2021, 1, 31), dict(days=8000 * 365)),
            (Date(2021, 1, 31), dict(years=-3000)),
            (Date(2021, 1, 31), dict(days=MAX_I64 + 3)),
            (Date(2021, 1, 31), dict(weeks=-MAX_I64 - 2)),
            (Date(2021, 1, 31), dict(months=MAX_I64 + 2)),
            (Date(2021, 1, 31), dict(months=MAX_I32 - 2, years=1)),
        ],
    )
    def test_out_of_range(self, d, kwargs):
        with pytest.raises((OverflowError, ValueError)):
            d.add(**kwargs)

        with pytest.raises((OverflowError, ValueError)):
            d + DateDelta(**kwargs)

        with pytest.raises((OverflowError, ValueError)):
            d.add(DateDelta(**kwargs))

        with pytest.raises((OverflowError, ValueError)):
            d.add(ItemizedDateDelta(**kwargs))

    def test_invalid(self):
        with pytest.raises(TypeError):
            Date(2021, 1, 1) + None  # type: ignore[operator]

        with pytest.raises(TypeError):
            None + Date(2021, 1, 1)  # type: ignore[operator]

        with pytest.raises(TypeError):
            py_date(2020, 1, 1) + Date(2021, 1, 1)  # type: ignore[operator]

    def test_no_mix_arg_kwargs(self):
        d = Date(2020, 1, 1)
        with pytest.raises(TypeError):
            d.add(DateDelta(years=1), months=1)  # type: ignore[call-overload]

        with pytest.raises(TypeError):
            d.add(ItemizedDateDelta(years=1), months=1)  # type: ignore[call-overload]


class TestDaysUntilAndSince:

    @pytest.mark.parametrize(
        "d1, d2, expected",
        [
            (Date(2021, 1, 1), Date(2021, 1, 31), 30),
            (Date(2020, 2, 28), Date(2020, 2, 28), 0),
            (Date(2020, 2, 28), Date(2020, 3, 1), 2),
            (Date(2020, 2, 28), Date(2020, 2, 1), -27),
            (Date(1990, 5, 2), Date(2021, 12, 1), 11536),
            (Date.MIN, Date.MAX, 3652058),
        ],
    )
    def test_days_until_and_since(self, d1, d2, expected):
        assert d1.days_until(d2) == expected
        assert d2.days_since(d1) == expected
        assert d1.days_since(d2) == -expected
        assert d2.days_until(d1) == -expected

    def test_invalid(self):
        with pytest.raises((TypeError, AttributeError)):
            Date(2021, 1, 1).days_until(PlainDateTime(2021, 1, 1, 1, 2, 3))  # type: ignore[arg-type]

    def test_deprecated(self):
        with pytest.warns(
            WheneverDeprecationWarning, match=r"days_until.*until()"
        ):
            assert Date(2021, 1, 1).days_until(Date(2021, 1, 31)) == 30

        with pytest.warns(
            WheneverDeprecationWarning, match=r"days_since.*since()"
        ):
            assert Date(2021, 1, 1).days_since(Date(2021, 1, 31)) == -30


_EXAMPLE_DATES = [
    *chain.from_iterable(
        [
            Date(y, 1, 1),
            Date(y, 1, 2),
            Date(y, 1, 4),
            Date(y, 1, 10),
            Date(y, 1, 28),
            Date(y, 1, 29),
            Date(y, 1, 30),
            Date(y, 1, 31),
            Date(y, 2, 1),
            Date(y, 2, 26),
            Date(y, 2, 27),
            Date(y, 2, 28),
            Date(y, 3, 1),
            Date(y, 3, 2),
            Date(y, 3, 31),
            Date(y, 4, 1),
            Date(y, 4, 2),
            Date(y, 4, 15),
            Date(y, 4, 30),
            Date(y, 5, 1),
            Date(y, 5, 31),
            Date(y, 8, 25),
            Date(y, 11, 30),
            Date(y, 12, 1),
            Date(y, 12, 2),
            Date(y, 12, 27),
            Date(y, 12, 28),
            Date(y, 12, 29),
            Date(y, 12, 30),
            Date(y, 12, 31),
        ]
        for y in (2020, 2021, 2022, 2023, 2024)
    ),
    Date(2024, 2, 29),
    Date(2020, 2, 29),
]


class TestSinceAndUntil:

    @pytest.mark.parametrize(
        "d1, d2, unit, expected",
        [
            # ---
            # years
            # ---
            # exact integer: same calendar position
            (Date(2021, 7, 30), Date(2020, 7, 30), "years", 1.0),
            (Date(2021, 7, 30), Date(2012, 7, 30), "years", 9.0),
            (Date(2024, 2, 29), Date(2020, 2, 29), "years", 4.0),
            # fractional: partway through the year
            (
                Date(2021, 7, 2),
                Date(2021, 1, 1),
                "years",
                pytest.approx(182 / 365),
            ),
            # negative
            (Date(2020, 7, 30), Date(2021, 7, 30), "years", -1.0),
            # zero
            (Date(2021, 5, 4), Date(2021, 5, 4), "years", 0.0),
            # ---
            # months
            # ---
            # exact integer: same calendar day
            (Date(2021, 3, 15), Date(2021, 2, 15), "months", 1.0),
            (Date(2021, 7, 30), Date(2020, 7, 30), "months", 12.0),
            # fractional: 15 days into a 31-day month
            (
                Date(2021, 3, 16),
                Date(2021, 3, 1),
                "months",
                pytest.approx(15 / 31),
            ),
            # negative
            (Date(2021, 2, 15), Date(2021, 3, 15), "months", -1.0),
            # ---
            # weeks (days / 7)
            # ---
            (Date(2021, 5, 11), Date(2021, 4, 27), "weeks", 2.0),
            (
                Date(2021, 3, 31),
                Date(2025, 2, 28),
                "weeks",
                pytest.approx(-1430 / 7),
            ),
            (
                Date(2021, 5, 12),
                Date(2021, 4, 27),
                "weeks",
                pytest.approx(15 / 7),
            ),
            # ---
            # days
            # ---
            (Date(2021, 5, 4), Date(2021, 4, 30), "days", 4.0),
            (Date(2020, 3, 1), Date(2020, 2, 29), "days", 1.0),
            (Date(2021, 4, 30), Date(2021, 5, 4), "days", -4.0),
        ],
    )
    def test_single_unit(
        self,
        d1: Date,
        d2: Date,
        unit: Literal["years", "months", "weeks", "days"],
        expected: float,
    ):
        result = d1.since(d2, total=unit)
        assert isinstance(result, float)
        assert result == expected
        # until() is the inverse of since()
        assert d2.until(d1, total=unit) == expected

    @pytest.mark.parametrize(
        "d1, d2, units, expected, kwargs",
        [
            (
                Date(2021, 5, 15),
                Date(2019, 5, 15),
                ["years", "months", "days"],
                ItemizedDateDelta(years=2, months=0, days=0),
                {},
            ),
            (
                Date(2021, 5, 15),
                Date(2022, 5, 15),
                ["years", "weeks"],
                ItemizedDateDelta(years=-1, weeks=0),
                {"round_increment": 13},
            ),
            (
                Date(2025, 3, 31),
                Date(2021, 12, 3),
                ["years", "months", "weeks"],
                ItemizedDateDelta(years=3, months=3, weeks=4),
                {"round_increment": 2},
            ),
            (
                Date(2025, 3, 31),
                Date(2021, 12, 8),
                ["years", "months", "days"],
                ItemizedDateDelta(years=3, months=3, days=27),
                {"round_increment": 9, "round_mode": "half_even"},
            ),
            (
                Date(2025, 3, 31),
                Date(2021, 12, 5),
                ("months", "weeks"),
                ItemizedDateDelta(months=39, weeks=4),
                {"round_increment": 2, "round_mode": "half_ceil"},
            ),
            (
                Date(2025, 4, 30),
                Date(2021, 4, 3),
                ("years", "weeks"),
                ItemizedDateDelta(years=4, weeks=4),
                {"round_increment": 2, "round_mode": "half_floor"},
            ),
            (
                Date(2025, 4, 30),
                Date(2021, 4, 3),
                ("years", "days"),
                ItemizedDateDelta(years=4, days=28),
                {"round_increment": 14, "round_mode": "half_floor"},
            ),
            (
                Date(2025, 4, 30),
                Date(2021, 4, 2),
                ("years", "days"),
                ItemizedDateDelta(years=4, days=28),
                {"round_increment": 14, "round_mode": "ceil"},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months"),
                ItemizedDateDelta(years=0, months=-11),
                {"round_increment": 1},
            ),
            # NOTE: temporal gives a different result here (days=-4)
            # but re-adding the delta gives the correct date, so I'm not
            # sure if this is a bug in temporal or just a different rounding approach.
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=-3),
                {},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=0),
                {"round_increment": 6},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=0),
                {"round_increment": 6, "round_mode": "half_even"},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=-6),
                {"round_increment": 6, "round_mode": "half_expand"},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=-6),
                {"round_increment": 6, "round_mode": "half_floor"},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=0),
                {"round_increment": 6, "round_mode": "half_trunc"},
            ),
            (
                Date(2025, 4, 30),
                Date(2026, 4, 3),
                ("years", "months", "days"),
                ItemizedDateDelta(years=0, months=-11, days=0),
                {"round_increment": 6, "round_mode": "half_ceil"},
            ),
            (
                Date(2022, 6, 1),
                Date(2023, 1, 31),
                ("months", "days"),
                ItemizedDateDelta(months=-7, days=-29),
                {},
            ),
            # Leap year edge case where it matters that years and months
            # are considered together
            (
                Date(2025, 8, 29),
                Date(2024, 2, 29),
                ("years", "months", "days"),
                ItemizedDateDelta(years=1, months=6, days=0),
                {},
            ),
        ],
    )
    def test_multiple_units(self, d1, d2, units, expected, kwargs):
        result = d1.since(d2, in_units=units, **kwargs)
        assert result == expected

        # verify by adding back the delta
        if "days" in units and kwargs.get("round_increment", 1) == 1:
            assert (
                d2.add(
                    years=result.get("years", 0),
                    months=result.get("months", 0),
                    weeks=result.get("weeks", 0),
                    days=result.get("days", 0),
                )
                == d1
            )

    @pytest.mark.parametrize(
        "units",
        [
            ["months", "years"],
            ["days", "years"],
            ["days", "months"],
            ["days", "months", "years"],
        ],
    )
    def test_invalid_unit_order(self, units):
        with pytest.raises(ValueError, match="order"):
            Date(2021, 1, 1).since(Date(2020, 1, 1), in_units=units)

    def test_invalid_units(self):
        d = Date(2021, 1, 1)
        # invalid unit in list
        with pytest.raises(ValueError, match="unit.*|foos"):
            d.since(Date(2020, 1, 1), in_units=["days", "foos"])  # type: ignore[list-item]

        # invalid single unit
        with pytest.raises(ValueError, match="unit.*|foos"):
            d.since(Date(2020, 1, 1), total="foos")  # type: ignore[call-overload]

        # empty units list
        with pytest.raises(
            ValueError, match="units cannot be empty|[Aa]t least one"
        ):
            d.since(Date(2020, 1, 1), in_units=())

        # neither total nor in_units specified
        with pytest.raises(
            TypeError, match="Must specify|total.*or.*in_units"
        ):
            d.since(Date(2020, 1, 1))  # type: ignore[call-overload]

        # both in_unit and in_units specified
        with pytest.raises(TypeError, match="both"):
            d.since(Date(2020, 1, 1), total="years", in_units=("days", "months"))  # type: ignore[call-overload]

        # duplicate units
        with pytest.raises(ValueError, match="duplicate"):
            d.since(Date(2020, 1, 1), in_units=["years", "days", "days"])

    def test_invalid_round_mode(self):
        d = Date(2021, 1, 1)
        # round_mode and round_increment are not supported with total=
        with pytest.raises(TypeError, match="round_mode.*total|total.*round"):
            d.since(Date(2020, 1, 1), total="years", round_mode="floor")  # type: ignore[call-overload]

        with pytest.raises(TypeError, match="round_mode.*total|total.*round"):
            d.since(Date(2020, 1, 1), total="years", round_increment=2)  # type: ignore[call-overload]

        # even round_increment=1 is rejected (no default magic)
        with pytest.raises(TypeError, match="round_mode.*total|total.*round"):
            d.since(Date(2020, 1, 1), total="years", round_increment=1)  # type: ignore[call-overload]

        # round_mode is still valid with in_units
        with pytest.raises(ValueError, match="round.*mode.*foobar"):
            d.since(Date(2020, 1, 1), in_units=["years"], round_mode="foobar")  # type: ignore[call-overload]

    # `until` behaves very similarly to `since`,
    # so we can just do a few spot checks here.
    # The main tricky differences are regarding rounding direction.
    @pytest.mark.parametrize(
        "d1, d2, units, delta, kwargs",
        [
            (
                Date(2019, 1, 30),
                Date(2020, 2, 1),
                ("years", "months"),
                ItemizedDateDelta(years=1, months=0),
                {"round_mode": "trunc"},
            ),
            (
                Date(2019, 1, 30),
                Date(2020, 2, 1),
                ("years", "months"),
                ItemizedDateDelta(years=1, months=0),
                {"round_mode": "floor"},
            ),
            (
                Date(2019, 1, 30),
                Date(2020, 2, 1),
                ("years", "months"),
                ItemizedDateDelta(years=1, months=1),
                {"round_mode": "ceil"},
            ),
            (
                Date(2019, 1, 30),
                Date(2020, 2, 1),
                ("years", "months"),
                ItemizedDateDelta(years=1, months=1),
                {"round_mode": "expand"},
            ),
            # negative deltas
            (
                Date(2020, 2, 1),
                Date(2019, 1, 30),
                ("years", "months"),
                ItemizedDateDelta(years=-1, months=0),
                {"round_mode": "trunc"},
            ),
            (
                Date(2020, 2, 1),
                Date(2019, 1, 30),
                ("years", "months"),
                ItemizedDateDelta(years=-1, months=-1),
                {"round_mode": "expand"},
            ),
            (
                Date(2020, 2, 1),
                Date(2019, 1, 30),
                ("years", "months"),
                ItemizedDateDelta(years=-1, months=0),
                {"round_mode": "ceil"},
            ),
            (
                Date(2020, 2, 1),
                Date(2019, 1, 30),
                ("years", "months"),
                ItemizedDateDelta(years=-1, months=-1),
                {"round_mode": "floor"},
            ),
        ],
    )
    def test_until(self, d1, d2, units, delta, kwargs):
        result = d1.until(d2, in_units=units, **kwargs)
        assert result == delta
        # verify by adding back the delta
        if "days" in units and kwargs.get("round_increment", 1) == 1:
            assert (
                d1.add(
                    years=result.years,
                    months=result.months,
                    weeks=result.weeks,
                    days=result.days,
                )
                == d2
            )


class TestSubtract:

    @pytest.mark.parametrize(
        "d, kwargs, expected",
        [
            (Date(2021, 1, 31), dict(), Date(2021, 1, 31)),
            (Date(2021, 1, 31), dict(months=0), Date(2021, 1, 31)),
            (Date(2021, 1, 31), dict(days=1), Date(2021, 1, 30)),
            (Date(2021, 2, 1), dict(days=-1), Date(2021, 2, 2)),
            (Date(2021, 2, 28), dict(months=2), Date(2020, 12, 28)),
            (Date(2021, 1, 31), dict(years=1), Date(2020, 1, 31)),
            (Date(2021, 1, 31), dict(months=37), Date(2017, 12, 31)),
            (Date(2020, 2, 29), dict(years=1), Date(2019, 2, 28)),
            (Date(2020, 2, 29), dict(years=1, days=1), Date(2019, 2, 27)),
            (
                Date(2020, 1, 30),
                dict(years=1, months=1, days=1),
                Date(2018, 12, 29),
            ),
            (
                Date(2020, 1, 30),
                dict(years=1, months=1, weeks=1),
                Date(2018, 12, 23),
            ),
        ],
    )
    def test_valid_delta(self, d, kwargs, expected):
        assert d.subtract(**kwargs) == expected
        assert d - DateDelta(**kwargs) == expected
        assert d.subtract(DateDelta(**kwargs)) == expected

        if kwargs:  # skip the zero-delta case
            assert d.subtract(ItemizedDateDelta(**kwargs)) == expected

    def test_operator_is_deprecated(self):
        d = Date(2021, 1, 1)
        delta = DateDelta(days=1)
        with pytest.warns(
            WheneverDeprecationWarning, match="-.*operator.*subtract"
        ):
            d - delta

        with pytest.warns(
            WheneverDeprecationWarning, match="-.*operator.*since"
        ):
            d - d

    @pytest.mark.parametrize(
        "kwargs",
        [
            {"years": 3000},
            {"days": 3000 * 365},
            {"years": -8000},
            {"days": MAX_I64 + 3},
            {"weeks": -MAX_I64 - 2},
            {"months": MAX_I64 + 2},
        ],
    )
    def test_delta_out_of_bounds(self, kwargs):
        with pytest.raises((OverflowError, ValueError)):
            Date(2021, 1, 1) - DateDelta(**kwargs)
        with pytest.raises((OverflowError, ValueError)):
            Date(2021, 1, 1).subtract(**kwargs)
        with pytest.raises((OverflowError, ValueError)):
            Date(2021, 1, 1).subtract(DateDelta(**kwargs))

        with pytest.raises((OverflowError, ValueError)):
            Date(2021, 1, 1).subtract(ItemizedDateDelta(**kwargs))

    @pytest.mark.parametrize(
        "d1, d2, expected",
        [
            (Date(2021, 1, 31), Date(2021, 1, 1), make_ddelta(days=30)),
            (Date(2021, 1, 1), Date(2021, 1, 31), -make_ddelta(days=30)),
            (Date(2021, 1, 20), Date(2021, 1, 11), make_ddelta(days=9)),
            (Date(2021, 2, 28), Date(2021, 2, 28), make_ddelta(days=0)),
            (Date(2021, 2, 28), Date(2021, 2, 27), make_ddelta(days=1)),
            (Date(2021, 2, 28), Date(2021, 2, 1), make_ddelta(days=27)),
        ],
    )
    def test_days(self, d1, d2, expected):
        assert d1 - d2 == expected

    @pytest.mark.parametrize(
        "d1, d2, delta",
        [
            (
                Date(2021, 2, 1),
                Date(2020, 1, 29),
                make_ddelta(years=1, days=3),
            ),
            (Date(2021, 1, 31), Date(2020, 12, 31), make_ddelta(months=1)),
            (Date(2020, 12, 31), Date(2021, 1, 31), make_ddelta(months=-1)),
            (
                Date(2021, 1, 20),
                Date(2020, 12, 19),
                make_ddelta(months=1, days=1),
            ),
            (Date(2024, 2, 28), Date(2024, 2, 29), -make_ddelta(days=1)),
            (Date(2024, 2, 29), Date(2024, 2, 28), make_ddelta(days=1)),
            (
                Date(2024, 2, 29),
                Date(2023, 3, 1),
                make_ddelta(months=11, days=28),
            ),
            (
                Date(2024, 2, 29),
                Date(2023, 3, 2),
                make_ddelta(months=11, days=27),
            ),
            (
                Date(2023, 3, 2),
                Date(2024, 2, 29),
                -make_ddelta(months=11, days=27),
            ),
            (Date(2024, 1, 31), Date(2023, 1, 31), make_ddelta(years=1)),
            (
                Date(2023, 1, 31),
                Date(2024, 2, 29),
                -make_ddelta(years=1, days=28),
            ),
            (
                Date(2023, 1, 30),
                Date(2024, 2, 29),
                -make_ddelta(years=1, days=29),
            ),
            (
                Date(2022, 12, 30),
                Date(2024, 2, 29),
                -make_ddelta(years=1, months=1, days=30),
            ),
            (
                Date(2024, 2, 29),
                Date(2023, 1, 31),
                make_ddelta(years=1, months=1),
            ),
            (
                Date(2024, 2, 29),
                Date(2023, 2, 28),
                make_ddelta(years=1, days=1),
            ),
            (Date(2023, 2, 28), Date(2024, 2, 29), -make_ddelta(years=1)),
            (Date(2023, 2, 28), Date(2024, 2, 28), -make_ddelta(years=1)),
            (Date(2025, 2, 28), Date(2024, 2, 29), make_ddelta(years=1)),
            (
                Date(2024, 2, 29),
                Date(2025, 2, 28),
                -make_ddelta(months=11, days=28),
            ),
            (
                Date(2023, 2, 28),
                Date(2024, 2, 29),
                make_ddelta(years=-1),
            ),
        ],
    )
    def test_months_and_years(self, d1, d2, delta):
        assert d1 - d2 == delta
        assert d2 + delta == d1

    def test_invalid_type(self):
        with pytest.raises(TypeError, match="unsupported operand"):
            Date(2021, 1, 1) - 1  # type: ignore[operator]
        with pytest.raises(TypeError, match="unsupported operand"):
            Date(2021, 1, 1) - "2021-01-01"  # type: ignore[operator]

        with pytest.raises(TypeError):
            None - Date(2021, 1, 1)  # type: ignore[operator]

        with pytest.raises(TypeError):
            3 - Date(2021, 1, 1)  # type: ignore[operator]

        with pytest.raises(TypeError):
            DateDelta() - Date(2021, 1, 1)  # type: ignore[operator]

        with pytest.raises(TypeError):
            Date(2021, 1, 1) - PlainDateTime(2020, 3, 2)  # type: ignore[operator]

        with pytest.raises(TypeError):
            PlainDateTime(2021, 1, 1) - Date(2020, 3, 2)  # type: ignore[operator]

    def test_fuzzing(self):
        for d1, d2 in product(_EXAMPLE_DATES, _EXAMPLE_DATES):
            delta = d1 - d2
            assert d2 + delta == d1


def test_day_of_week():
    d = Date(2021, 1, 2)
    assert d.day_of_week() is Weekday.SATURDAY
    assert Date(2021, 1, 3).day_of_week() is Weekday.SUNDAY
    assert Date(2021, 1, 4).day_of_week() is Weekday.MONDAY
    assert Date(2021, 1, 5).day_of_week() is Weekday.TUESDAY
    assert Date(2021, 1, 6).day_of_week() is Weekday.WEDNESDAY
    assert Date(2021, 1, 7).day_of_week() is Weekday.THURSDAY
    assert Date(2021, 1, 8).day_of_week() is Weekday.FRIDAY

    # test that days can be imported directly from the module too
    from whenever import (
        FRIDAY,
        MONDAY,
        SATURDAY,
        SUNDAY,
        THURSDAY,
        TUESDAY,
        WEDNESDAY,
    )

    assert Date(1915, 7, 19).day_of_week() is MONDAY
    assert Date(1915, 7, 20).day_of_week() is TUESDAY
    assert Date(1915, 7, 21).day_of_week() is WEDNESDAY
    assert Date(1915, 7, 22).day_of_week() is THURSDAY
    assert Date(1915, 7, 23).day_of_week() is FRIDAY
    assert Date(1915, 7, 24).day_of_week() is SATURDAY
    assert Date(1915, 7, 25).day_of_week() is SUNDAY

    assert pickle.loads(pickle.dumps(SATURDAY)) is SATURDAY


def test_pickling():
    d = Date(2021, 1, 2)
    dumped = pickle.dumps(d)
    assert len(dumped) < len(pickle.dumps(d.to_stdlib())) + 10
    assert pickle.loads(dumped) == d


def test_unpickle_compatibility():
    dumped = (
        b"\x80\x04\x95'\x00\x00\x00\x00\x00\x00\x00\x8c\x08whenever\x94\x8c\x0b_unp"
        b"kl_date\x94\x93\x94C\x04\xe5\x07\x01\x02\x94\x85\x94R\x94."
    )
    assert pickle.loads(dumped) == Date(2021, 1, 2)


def test_copy():
    d = Date(2021, 1, 2)
    assert copy(d) is d
    assert deepcopy(d) is d


def test_singletons():
    assert Date.MIN == Date(1, 1, 1)
    assert Date.MAX == Date(9999, 12, 31)


class TestDeprecations:
    def test_py_date(self):
        d = Date(2021, 1, 2)
        with pytest.warns(WheneverDeprecationWarning):
            result = d.py_date()
        assert result == py_date(2021, 1, 2)

    def test_from_py_date(self):
        with pytest.warns(WheneverDeprecationWarning):
            result = Date.from_py_date(py_date(2021, 1, 2))
        assert result == Date(2021, 1, 2)

    def test_from_py_date_wrong_type(self):
        with pytest.warns(WheneverDeprecationWarning):
            with pytest.raises(TypeError):
                Date.from_py_date(42)  # type: ignore[arg-type]


def test_cannot_subclass():
    with pytest.raises(TypeError):

        class SubclassDate(Date):  # type: ignore[misc]
            pass


MONDAY = Weekday.MONDAY
TUESDAY = Weekday.TUESDAY
WEDNESDAY = Weekday.WEDNESDAY
THURSDAY = Weekday.THURSDAY
FRIDAY = Weekday.FRIDAY
SATURDAY = Weekday.SATURDAY
SUNDAY = Weekday.SUNDAY


class TestDayOfYear:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2023, 1, 1), 1),
            (Date(2023, 1, 2), 2),
            (Date(2023, 2, 28), 59),
            (Date(2024, 2, 28), 59),
            (Date(2024, 2, 29), 60),
            (Date(2023, 3, 1), 60),
            (Date(2024, 3, 1), 61),
            (Date(2023, 12, 31), 365),
            (Date(2024, 12, 31), 366),
        ],
    )
    def test_values(self, d, expected):
        assert d.day_of_year() == expected

    def test_first_and_last_day(self):
        assert Date(2000, 1, 1).day_of_year() == 1
        assert Date(2000, 12, 31).day_of_year() == 366  # leap year

    def test_century_year(self):
        # 1900 is not a leap year (div by 100 but not 400)
        assert Date(1900, 12, 31).day_of_year() == 365
        assert Date(1900, 3, 1).day_of_year() == 60

    def test_not_callable_with_args(self):
        with pytest.raises(TypeError):
            Date(2024, 1, 1).day_of_year(1)  # type: ignore[call-arg]


class TestDaysInMonth:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2023, 1, 15), 31),
            (Date(2023, 2, 15), 28),
            (Date(2024, 2, 15), 29),
            (Date(2023, 3, 15), 31),
            (Date(2023, 4, 15), 30),
            (Date(2023, 5, 15), 31),
            (Date(2023, 6, 15), 30),
            (Date(2023, 7, 15), 31),
            (Date(2023, 8, 15), 31),
            (Date(2023, 9, 15), 30),
            (Date(2023, 10, 15), 31),
            (Date(2023, 11, 15), 30),
            (Date(2023, 12, 15), 31),
        ],
    )
    def test_values(self, d, expected):
        assert d.days_in_month() == expected

    def test_not_callable_with_args(self):
        with pytest.raises(TypeError):
            Date(2024, 1, 1).days_in_month(1)  # type: ignore[call-arg]


class TestDaysInYear:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2024, 1, 1), 366),
            (Date(2023, 1, 1), 365),
            (Date(2000, 6, 15), 366),
            (Date(1900, 6, 15), 365),
        ],
    )
    def test_values(self, d, expected):
        assert d.days_in_year() == expected


class TestInLeapYear:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2024, 1, 1), True),
            (Date(2023, 1, 1), False),
            (Date(2000, 6, 15), True),
            (Date(1900, 6, 15), False),
            (Date(2100, 6, 15), False),
        ],
    )
    def test_values(self, d, expected):
        assert d.in_leap_year() is expected


class TestNextDay:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2024, 1, 1), Date(2024, 1, 2)),
            (Date(2024, 1, 31), Date(2024, 2, 1)),
            (Date(2024, 2, 28), Date(2024, 2, 29)),
            (Date(2024, 2, 29), Date(2024, 3, 1)),
            (Date(2023, 2, 28), Date(2023, 3, 1)),
            (Date(2024, 12, 31), Date(2025, 1, 1)),
        ],
    )
    def test_values(self, d, expected):
        assert d.next_day() == expected

    def test_at_max(self):
        with pytest.raises((ValueError, OverflowError)):
            Date.MAX.next_day()


class TestPrevDay:

    @pytest.mark.parametrize(
        "d, expected",
        [
            (Date(2024, 1, 2), Date(2024, 1, 1)),
            (Date(2024, 2, 1), Date(2024, 1, 31)),
            (Date(2024, 3, 1), Date(2024, 2, 29)),
            (Date(2023, 3, 1), Date(2023, 2, 28)),
            (Date(2025, 1, 1), Date(2024, 12, 31)),
            (Date(2024, 1, 1), Date(2023, 12, 31)),
        ],
    )
    def test_values(self, d, expected):
        assert d.prev_day() == expected

    def test_at_min(self):
        with pytest.raises((ValueError, OverflowError)):
            Date.MIN.prev_day()


class TestNthWeekdayOfMonth:

    @pytest.mark.parametrize(
        "d, n, weekday, expected",
        [
            # December 2024 starts on Sunday
            (Date(2024, 12, 1), 1, MONDAY, Date(2024, 12, 2)),
            (Date(2024, 12, 1), 2, MONDAY, Date(2024, 12, 9)),
            (Date(2024, 12, 1), 3, MONDAY, Date(2024, 12, 16)),
            (Date(2024, 12, 1), 4, MONDAY, Date(2024, 12, 23)),
            (Date(2024, 12, 1), 5, MONDAY, Date(2024, 12, 30)),
            (Date(2024, 12, 1), 1, SUNDAY, Date(2024, 12, 1)),
            (Date(2024, 12, 1), 1, FRIDAY, Date(2024, 12, 6)),
            (Date(2024, 12, 1), 1, SATURDAY, Date(2024, 12, 7)),
            # Negative n
            (Date(2024, 12, 1), -1, MONDAY, Date(2024, 12, 30)),
            (Date(2024, 12, 1), -2, MONDAY, Date(2024, 12, 23)),
            (Date(2024, 12, 1), -1, SUNDAY, Date(2024, 12, 29)),
            (Date(2024, 12, 1), -1, TUESDAY, Date(2024, 12, 31)),
            # Various months
            (Date(2024, 1, 15), 1, MONDAY, Date(2024, 1, 1)),
            (Date(2024, 2, 15), 1, THURSDAY, Date(2024, 2, 1)),
            (Date(2024, 2, 15), -1, THURSDAY, Date(2024, 2, 29)),
            # February non-leap
            (Date(2023, 2, 1), 4, TUESDAY, Date(2023, 2, 28)),
            (Date(2023, 2, 1), -1, TUESDAY, Date(2023, 2, 28)),
        ],
    )
    def test_values(self, d, n, weekday, expected):
        assert d.nth_weekday_of_month(n, weekday) == expected

    def test_invalid_weekday_type(self):
        with pytest.raises(TypeError):
            Date(2024, 12, 1).nth_weekday_of_month(1, 5)  # type: ignore[arg-type]

    def test_n_zero(self):
        with pytest.raises(ValueError, match="n must not be 0"):
            Date(2024, 8, 15).nth_weekday_of_month(0, MONDAY)

    def test_fifth_positive_when_not_exists(self):
        # February 2023 (non-leap) starts on Wednesday
        # Only 4 Wednesdays: 1, 8, 15, 22
        with pytest.raises(ValueError):
            Date(2023, 2, 1).nth_weekday_of_month(5, WEDNESDAY)

    def test_fifth_negative_when_not_exists(self):
        # February 2023 (non-leap) starts on Wednesday
        # Only 4 Fridays: 3, 10, 17, 24
        with pytest.raises(ValueError):
            Date(2023, 2, 1).nth_weekday_of_month(-5, FRIDAY)

    def test_n_out_of_range(self):
        with pytest.raises(ValueError, match="n must be between -5 and 5"):
            Date(2024, 12, 1).nth_weekday_of_month(6, MONDAY)

        with pytest.raises(ValueError, match="n must be between -5 and 5"):
            Date(2024, 12, 1).nth_weekday_of_month(-6, MONDAY)


class TestNthWeekday:

    @pytest.mark.parametrize(
        "d, n, weekday, expected",
        [
            (Date(2024, 12, 25), 1, FRIDAY, Date(2024, 12, 27)),
            (Date(2024, 12, 25), 2, FRIDAY, Date(2025, 1, 3)),
            (Date(2024, 12, 25), 1, WEDNESDAY, Date(2025, 1, 1)),
            (Date(2024, 12, 25), -1, MONDAY, Date(2024, 12, 23)),
            (Date(2024, 12, 25), -1, WEDNESDAY, Date(2024, 12, 18)),
            (Date(2024, 12, 25), -2, MONDAY, Date(2024, 12, 16)),
            (Date(2024, 12, 25), 1, MONDAY, Date(2024, 12, 30)),
            (Date(2024, 12, 25), 1, TUESDAY, Date(2024, 12, 31)),
            (Date(2024, 12, 25), 1, THURSDAY, Date(2024, 12, 26)),
            (Date(2024, 12, 25), 1, SATURDAY, Date(2024, 12, 28)),
            (Date(2024, 12, 25), 1, SUNDAY, Date(2024, 12, 29)),
            (Date(2024, 12, 25), -1, TUESDAY, Date(2024, 12, 24)),
            (Date(2024, 12, 25), -1, THURSDAY, Date(2024, 12, 19)),
            (Date(2024, 12, 25), -1, FRIDAY, Date(2024, 12, 20)),
            (Date(2024, 12, 25), -1, SATURDAY, Date(2024, 12, 21)),
            (Date(2024, 12, 25), -1, SUNDAY, Date(2024, 12, 22)),
            (Date(2024, 12, 25), 3, FRIDAY, Date(2025, 1, 10)),
            (Date(2024, 12, 25), -3, FRIDAY, Date(2024, 12, 6)),
            (Date(2024, 12, 25), 5, FRIDAY, Date(2025, 1, 24)),
            (Date(2024, 12, 25), -5, FRIDAY, Date(2024, 11, 22)),
            (Date(2024, 12, 25), 234, FRIDAY, Date(2029, 6, 15)),
            (Date(2024, 12, 25), -234, FRIDAY, Date(2020, 7, 3)),
        ],
    )
    def test_values(self, d, n, weekday, expected):
        assert d.nth_weekday(n, weekday) == expected

    def test_invalid_weekday_type(self):
        with pytest.raises(TypeError):
            Date(2024, 12, 25).nth_weekday(1, 5)  # type: ignore[arg-type]

    def test_n_zero(self):
        with pytest.raises(ValueError, match="n must not be 0"):
            Date(2024, 8, 15).nth_weekday(0, MONDAY)

    def test_n_too_large(self):
        with pytest.raises(ValueError):
            Date(2024, 12, 25).nth_weekday(521_723, FRIDAY)

        with pytest.raises(ValueError):
            Date(2024, 12, 25).nth_weekday(-521_723, FRIDAY)

    def test_same_weekday_as_date(self):
        # 2024-12-25 is a Wednesday. n=1 should return NEXT Wednesday, not self
        assert Date(2024, 12, 25).nth_weekday(1, WEDNESDAY) == Date(2025, 1, 1)

    def test_same_weekday_as_date_negative(self):
        # 2024-12-25 is a Wednesday. n=-1 should return PREVIOUS Wednesday
        assert Date(2024, 12, 25).nth_weekday(-1, WEDNESDAY) == Date(
            2024, 12, 18
        )


class TestIsoWeekDateConversion:

    def test_basic(self):
        assert Date(2024, 1, 1).iso_week_date() == IsoWeekDate(2024, 1, MONDAY)

    def test_year_boundary_forward(self):
        # Dec 30, 2024 belongs to ISO 2025-W01
        iwd = Date(2024, 12, 30).iso_week_date()
        assert iwd.year == 2025
        assert iwd.week == 1

    def test_year_boundary_backward(self):
        # Jan 1, 2016 belongs to ISO 2015-W53
        iwd = Date(2016, 1, 1).iso_week_date()
        assert iwd.year == 2015
        assert iwd.week == 53

    def test_mid_year(self):
        iwd = Date(2024, 7, 4).iso_week_date()
        assert iwd.year == 2024
        assert iwd.week == 27
        assert iwd.weekday == THURSDAY

    def test_roundtrip_many_dates(self):
        # Verify round-trip for several important dates
        for d in [
            Date(2024, 1, 1),
            Date(2024, 6, 15),
            Date(2024, 12, 31),
            Date(2023, 1, 1),
            Date(2023, 12, 31),
            Date(2020, 2, 29),
        ]:
            assert d.iso_week_date().date() == d


class TestStartOf:

    def test_year(self):
        assert Date(2024, 8, 15).start_of("year") == Date(2024, 1, 1)

    def test_year_already_jan1(self):
        assert Date(2024, 1, 1).start_of("year") == Date(2024, 1, 1)

    def test_month(self):
        assert Date(2024, 8, 15).start_of("month") == Date(2024, 8, 1)

    def test_month_already_first(self):
        assert Date(2024, 8, 1).start_of("month") == Date(2024, 8, 1)

    def test_month_december(self):
        assert Date(2024, 12, 25).start_of("month") == Date(2024, 12, 1)

    def test_invalid_unit(self):
        with pytest.raises(ValueError, match="Invalid"):
            Date(2024, 8, 15).start_of("day")  # type: ignore[arg-type]

    def test_invalid_unit_arbitrary(self):
        with pytest.raises(ValueError, match="Invalid"):
            Date(2024, 8, 15).start_of("week")  # type: ignore[arg-type]


class TestEndOf:

    def test_year(self):
        assert Date(2024, 8, 15).end_of("year") == Date(2024, 12, 31)

    def test_year_already_dec31(self):
        assert Date(2024, 12, 31).end_of("year") == Date(2024, 12, 31)

    def test_month_31_days(self):
        assert Date(2024, 8, 15).end_of("month") == Date(2024, 8, 31)

    def test_month_30_days(self):
        assert Date(2024, 6, 10).end_of("month") == Date(2024, 6, 30)

    def test_month_feb_leap_year(self):
        assert Date(2024, 2, 10).end_of("month") == Date(2024, 2, 29)

    def test_month_feb_non_leap_year(self):
        assert Date(2023, 2, 10).end_of("month") == Date(2023, 2, 28)

    def test_month_already_last_day(self):
        assert Date(2024, 8, 31).end_of("month") == Date(2024, 8, 31)

    def test_invalid_unit(self):
        with pytest.raises(ValueError, match="Invalid"):
            Date(2024, 8, 15).end_of("day")  # type: ignore[arg-type]

    def test_invalid_unit_arbitrary(self):
        with pytest.raises(ValueError, match="Invalid"):
            Date(2024, 8, 15).end_of("hour")  # type: ignore[arg-type]
