# Core4 SDK

A lightweight Python SDK for error tracking and performance monitoring.

## Installation

```bash
pip install core4-sdk
```

## Usage

```python
from core4 import Tracelify

sdk = Tracelify(
    dsn="http://your_key@your_host/project/id/events"
)

sdk.set_user({"id": "user_101"})
sdk.set_tag("env", "Production")

try:
    x = 10 / 0
except Exception as e:
    sdk.capture_exception(e)
```
