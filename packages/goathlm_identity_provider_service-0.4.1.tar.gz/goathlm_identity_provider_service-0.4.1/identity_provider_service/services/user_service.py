from uuid import UUID

from shared_models.schemas import User
from sqlalchemy.ext.asyncio import AsyncSession

from identity_provider_service.repositories import user_repository


async def get_all_users(session: AsyncSession) -> list[User]:
    """
    Retrieves a complete list of all users from the system.

    This service function delegates the retrieval process to the user
    repository, returning the full collection of user entities stored
    in the database.

    :param session: The active asynchronous database session.
    :return: A list of all User instances.
    """
    return await user_repository.get_all(session=session)


async def get_user_by_id(user_id: UUID, session: AsyncSession) -> User:
    """
    Fetches a specific user based on their unique UUID.

    The function provides a direct way to find a single user profile
    by communicating with the repository layer. It is used when
    the internal system identifier is already known.

    :param user_id: The unique UUID of the user.
    :param session: The active asynchronous database session.
    :return: The User instance matching the provided ID.
    """
    return await user_repository.get_by_id(user_id=user_id, session=session)


async def get_user_by_email_address(email_address: str, session: AsyncSession) -> User:
    """
    Locates a user profile using their registered email address.

    This service facilitates user lookups based on contact information,
    wrapping the repository logic to find a matching account in
    the identity system.

    :param email_address: The unique email string associated with the user account.
    :param session: The active asynchronous database session.
    :return: The User instance associated with the given email address.
    """
    return await user_repository.get_by_email_address(
        email_address=email_address,
        session=session,
    )
