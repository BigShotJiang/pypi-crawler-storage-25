from uuid import UUID

from shared_models.schemas import User
from sqlalchemy.orm import joinedload
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession


async def get_all(session: AsyncSession) -> list[User]:
    """
    Retrieves all registered users from the database.

    This function performs a bulk fetch of user records and uses
    eager loading to include associated geographic location data
    in a single database round-trip.

    :param session: The active asynchronous database session.
    :return: A list of User instances with their location attributes populated.
    """
    statement = select(User).options(joinedload(User.location))
    result = await session.exec(statement)
    return result.unique().all()


async def get_by_id(user_id: UUID, session: AsyncSession) -> User:
    """
    Finds a specific user based on their unique identifier.

    This function filters the user table by primary key and ensures
    that the related location information is joined and available
    on the returned object.

    :param user_id: The UUID of the user to retrieve.
    :param session: The active asynchronous database session.
    :return: A single User instance matching the provided ID.
    """
    statement = (
        select(User).where(User.id == user_id).options(joinedload(User.location))
    )
    result = await session.exec(statement)
    return result.unique().one()


async def get_by_email_address(email_address: str, session: AsyncSession) -> User:
    """
    Retrieves a user profile using a specific email address.

    This function is commonly used for authentication and profile
    lookups, ensuring that the linked location data is loaded
    alongside the user's personal details.

    :param email_address: The unique email string associated with the account.
    :param session: The active asynchronous database session.
    :return: The User instance associated with the given email address.
    """
    statement = (
        select(User)
        .where(User.email_address == email_address)
        .options(joinedload(User.location))
    )
    result = await session.exec(statement)
    return result.unique().one()
