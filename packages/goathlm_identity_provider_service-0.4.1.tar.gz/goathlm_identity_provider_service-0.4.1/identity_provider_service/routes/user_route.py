from typing import Annotated
from uuid import UUID

from database_service.database import get_db_session
from fastapi import APIRouter, Depends, HTTPException, status
from shared_models.dtos.user_auth_dto import UserAuthDTO
from shared_models.dtos.user_dto import UserDTO
from sqlalchemy.exc import NoResultFound
from sqlmodel.ext.asyncio.session import AsyncSession

from identity_provider_service.routes.authentication_route import get_current_user
from identity_provider_service.services.user_service import (
    get_all_users,
    get_user_by_email_address,
    get_user_by_id,
)

route = APIRouter(
    prefix="/user",
    tags=["user"],
    responses={404: {"description": "Not found"}},
)

db_session_dependency = Depends(get_db_session)
user_connected_dependency = Depends(get_current_user)


@route.get("/all", status_code=status.HTTP_200_OK, response_model=list[UserDTO])
async def get_all_users_route(
    session: Annotated[AsyncSession, db_session_dependency],
    _: Annotated[UserAuthDTO, user_connected_dependency],
) -> list[UserDTO]:
    """
    Retrieves a complete list of all registered users.

    This endpoint calls the user service to fetch every profile
    available in the identity system, typically used for
    administrative overviews or directory listings.

    :param session: The active asynchronous database session.
    :return: A list of UserDTO instances representing all users.
    """
    return await get_all_users(session=session)


@route.get("/{user_id}", status_code=status.HTTP_200_OK, response_model=UserDTO)
async def get_by_id(
    user_id: UUID,
    session: Annotated[AsyncSession, db_session_dependency],
    _: Annotated[UserAuthDTO, user_connected_dependency],
) -> UserDTO:
    """
    Fetches a specific user profile using their unique UUID.

    The function attempts to locate a single user. If the identifier
    does not match any existing record, it returns a 404 Not Found
    status to the client.

    :param user_id: The unique UUID of the user.
    :param session: The active asynchronous database session.
    :return: The UserDTO associated with the provided ID.
    """
    try:
        return await get_user_by_id(user_id=user_id, session=session)
    except NoResultFound as exception:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User '{user_id}' not found",
        ) from exception


@route.get(
    "/email/{user_email_address}",
    status_code=status.HTTP_200_OK,
    response_model=UserDTO,
)
async def get_by_email_address(
    user_email_address: str,
    session: Annotated[AsyncSession, db_session_dependency],
    _: Annotated[UserAuthDTO, user_connected_dependency],
) -> UserDTO:
    """
    Locates a user profile based on their registered email address.

    This lookup is essential for verifying accounts and retrieving
    user information when the internal UUID is unknown. It raises a
    404 error if no account is linked to the provided email string.

    :param user_email_address: The unique email string to search for.
    :param session: The active asynchronous database session.
    :return: The UserDTO associated with the provided email address.
    """
    try:
        return await get_user_by_email_address(
            email_address=user_email_address,
            session=session,
        )
    except NoResultFound as exception:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User '{user_email_address}' not found",
        ) from exception
