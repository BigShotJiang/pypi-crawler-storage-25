"""MCP server for repoindex."""
