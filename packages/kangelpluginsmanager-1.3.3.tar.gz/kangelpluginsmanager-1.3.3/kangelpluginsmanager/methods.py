import hashlib
import json
import os
import re
import time
import urllib.request

from android_utils import log as _android_log

MKSTATS_API_URL = os.getenv("MKSTATS_API_URL", "https://mkstats.mk69.su/api")
MKSTATS_PING_INTERVAL = int(os.getenv("MKSTATS_PING_INTERVAL", "1500"))
MKSTATS_POW_SOLVE_SECONDS = int(os.getenv("MKSTATS_POW_SOLVE_SECONDS", "6"))


def generate_user_hash(device_id: str, plugin_id: str) -> str:
    payload = f"{device_id}:{plugin_id}:mkstats:v1"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def generate_device_fingerprint(device_id: str) -> str:
    payload = f"{device_id}:mkstats:device:v1"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _normalize_api_base(api_url: str) -> str:
    base = api_url.rstrip("/")
    if base.endswith("/api"):
        return f"{base}/v1"
    return base


def _post_json(url: str, payload: dict) -> dict:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        body = response.read().decode("utf-8")
    return json.loads(body)


def _pow_valid(challenge: str, nonce: str, difficulty: int) -> bool:
    if not challenge or not nonce or difficulty <= 0:
        return False
    prefix = "0" * max(1, int(difficulty))
    digest = hashlib.sha256(f"{challenge}:{nonce}".encode("utf-8")).hexdigest()
    return digest.startswith(prefix)


def _solve_pow(challenge: str, difficulty: int, max_seconds: int = MKSTATS_POW_SOLVE_SECONDS) -> str | None:
    difficulty = max(1, int(difficulty or 0))
    deadline = time.time() + max(1, int(max_seconds or 0))
    nonce = 0
    prefix = "0" * difficulty
    while time.time() < deadline:
        candidate = format(nonce, "x")
        digest = hashlib.sha256(f"{challenge}:{candidate}".encode("utf-8")).hexdigest()
        if digest.startswith(prefix):
            return candidate
        nonce += 1
    return None


class MkStatsCoreClient:
    def __init__(
        self,
        api_url: str,
        plugin_id: str,
        plugin_version: str,
        user_hash: str,
        device_fingerprint: str,
        client_version: str | None = None,
        client_name: str | None = None,
    ) -> None:
        self.api_base = _normalize_api_base(api_url)
        self.plugin_id = plugin_id
        self.plugin_version = plugin_version
        self.client_version = client_version
        self.client_name = client_name
        self.user_hash = user_hash
        self.device_fingerprint = device_fingerprint

    def handshake(self) -> dict:
        payload = {
            "plugin_id": self.plugin_id,
            "version": self.plugin_version,
            "client_name": self.client_name,
            "client_version": self.client_version,
            "user_hash": self.user_hash,
            "device_fingerprint": self.device_fingerprint,
        }
        response = _post_json(f"{self.api_base}/handshake", payload)
        token = (response or {}).get("install_token", "")
        if token:
            return response
        pow_required = bool((response or {}).get("pow_required"))
        pow_challenge = (response or {}).get("pow_challenge")
        if pow_required and pow_challenge:
            difficulty = int((response or {}).get("pow_difficulty") or 0)
            nonce = _solve_pow(pow_challenge, difficulty)
            if nonce and _pow_valid(pow_challenge, nonce, difficulty):
                payload["pow_challenge"] = pow_challenge
                payload["pow_nonce"] = nonce
                response = _post_json(f"{self.api_base}/handshake", payload)
        return response

    def send_ping(self, install_token: str, timestamp=None) -> dict:
        payload = {
            "plugin_id": self.plugin_id,
            "version": self.plugin_version,
            "client_name": self.client_name,
            "client_version": self.client_version,
            "user_hash": self.user_hash,
            "device_fingerprint": self.device_fingerprint,
            "install_token": install_token,
            "timestamp": timestamp or int(time.time()),
        }
        return _post_json(f"{self.api_base}/data", payload)

    def send_event(self, install_token: str, event: str, count: int = 1, timestamp=None) -> dict:
        payload = {
            "plugin_id": self.plugin_id,
            "version": self.plugin_version,
            "client_name": self.client_name,
            "client_version": self.client_version,
            "user_hash": self.user_hash,
            "device_fingerprint": self.device_fingerprint,
            "install_token": install_token,
            "event": event,
            "count": count,
            "timestamp": timestamp or int(time.time()),
        }
        return _post_json(f"{self.api_base}/event", payload)

def _get_loading_html():
    try:
        from org.telegram.ui.ActionBar import Theme

        color_int = Theme.getColor(Theme.key_windowBackgroundWhiteBlueText)
        accent_color = "%06X" % (int(color_int) & 0xFFFFFF)
    except Exception:
        accent_color = "4F378B"

    return f"""
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            height: 100vh;
            background: transparent;
            overflow: hidden;
        }}
        .svg-canvas {{
            width: 90px;
            height: 90px;
            overflow: visible;
        }}
        .expressive-snap {{
            transform-origin: 60px 60px;
            animation: snap-rotate 6s infinite;
        }}
        @keyframes snap-rotate {{
            0%   {{ transform: rotate(0deg); animation-timing-function: ease-out; }}
            12%  {{ transform: rotate(15deg); animation-timing-function: ease-in-out; }}
            15%  {{ transform: rotate(5deg); animation-timing-function: cubic-bezier(0.8, 0.0, 0.2, 1); }}
            25%  {{ transform: rotate(135deg); animation-timing-function: linear; }}
            25%  {{ transform: rotate(135deg); animation-timing-function: ease-out; }}
            37%  {{ transform: rotate(150deg); animation-timing-function: ease-in-out; }}
            40%  {{ transform: rotate(140deg); animation-timing-function: cubic-bezier(0.8, 0.0, 0.2, 1); }}
            50%  {{ transform: rotate(270deg); animation-timing-function: linear; }}
            50%  {{ transform: rotate(270deg); animation-timing-function: ease-out; }}
            62%  {{ transform: rotate(285deg); animation-timing-function: ease-in-out; }}
            65%  {{ transform: rotate(275deg); animation-timing-function: cubic-bezier(0.8, 0.0, 0.2, 1); }}
            75%  {{ transform: rotate(405deg); animation-timing-function: linear; }}
            75%  {{ transform: rotate(405deg); animation-timing-function: ease-out; }}
            87%  {{ transform: rotate(420deg); animation-timing-function: ease-in-out; }}
            90%  {{ transform: rotate(410deg); animation-timing-function: cubic-bezier(0.8, 0.0, 0.2, 1); }}
            100% {{ transform: rotate(540deg); animation-timing-function: linear; }}
        }}
    </style>
</head>
<body>
    <svg class="svg-canvas" viewBox="0 0 120 120">
        <g class="expressive-snap">
            <path class="morph-path" fill="#{accent_color}">
                <animate class="morph-anim" attributeName="d" dur="6s" repeatCount="indefinite" calcMode="spline" />
            </path>
        </g>
    </svg>
    <script>
        document.addEventListener('DOMContentLoaded', () => {{
            function generateGeometricPath(type, centerX = 60, centerY = 60) {{
                const numPoints = 120;
                const angleStep = (Math.PI * 2) / numPoints;
                let d = "";
                for (let i = 0; i < numPoints; i++) {{
                    const angle = i * angleStep;
                    let a = ((angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
                    let r = 0;
                    if (type === 'flower') {{
                        r = 44 + 4 * Math.cos(10 * a);
                    }}
                    else if (type === 'blob') {{
                        const S = 40;
                        const R = 16;
                        let oct = a % (Math.PI / 2);
                        if (oct > Math.PI / 4) oct = Math.PI / 2 - oct;
                        const a_bound = Math.atan2(S - R, S);
                        if (oct <= a_bound) {{
                            r = S / Math.cos(oct);
                        }} else {{
                            const cx = S - R, cy = S - R;
                            const b = cx * Math.cos(oct) + cy * Math.sin(oct);
                            const c = cx * cx + cy * cy - R * R;
                            r = b + Math.sqrt(b * b - c);
                        }}
                    }}
                    else if (type === 'peanut') {{
                        const W = 48;
                        const H = 34;
                        const cx = W - H;
                        let quad = a % Math.PI;
                        if (quad > Math.PI / 2) quad = Math.PI - quad;
                        const a_bound = Math.atan2(H, cx);
                        if (quad >= a_bound) {{
                            r = H / Math.sin(quad);
                        }} else {{
                            const b = cx * Math.cos(quad);
                            const c = cx * cx - H * H;
                            r = b + Math.sqrt(b * b - c);
                        }}
                    }}
                    const x = centerX + r * Math.cos(angle);
                    const y = centerY + r * Math.sin(angle);
                    if (i === 0) d += `M ${{x.toFixed(2)}},${{y.toFixed(2)}} `;
                    else d += `L ${{x.toFixed(2)}},${{y.toFixed(2)}} `;
                }}
                return d + "Z";
            }}
            const pFlower = generateGeometricPath('flower');
            const pBlob = generateGeometricPath('blob');
            const pPeanut = generateGeometricPath('peanut');
            const animValues = `${{pFlower}}; ${{pFlower}}; ${{pBlob}}; ${{pBlob}}; ${{pFlower}}; ${{pFlower}}; ${{pPeanut}}; ${{pPeanut}}; ${{pFlower}}`;
            const keyTimes = "0; 0.15; 0.25; 0.40; 0.50; 0.65; 0.75; 0.90; 1";
            const holdSpline = "0 0 1 1";
            const morphSpline = "0.2 0.0 0.0 1.0";
            const keySplines = [
                holdSpline, morphSpline,
                holdSpline, morphSpline,
                holdSpline, morphSpline,
                holdSpline, morphSpline
            ].join('; ');
            document.querySelectorAll('.morph-anim').forEach(anim => {{
                anim.setAttribute('values', animValues);
                anim.setAttribute('keyTimes', keyTimes);
                anim.setAttribute('keySplines', keySplines);
            }});
            document.querySelectorAll('.morph-path').forEach(p => {{
                p.setAttribute('d', pFlower);
            }});
        }});
    </script>
</body>
</html>
"""

_kpm_instance_ref = [None] 


def _set_kpm_instance(instance) -> None:
    """Store a weak-reference-like pointer to the plugin instance for log gating."""
    _kpm_instance_ref[0] = instance


def _kpm_logs_enabled():
    inst = _kpm_instance_ref[0]
    if inst is None:
        return True
    try:
        return bool(inst.get_setting("logs_enabled", True))
    except Exception:
        return True


def log(*args, **kwargs):
    try:
        if _kpm_logs_enabled():
            _android_log(*args, **kwargs)
    except Exception:
        pass


def _get_lang():
    from java.util import Locale

    lang = Locale.getDefault().getLanguage().lower()
    return "ru" if lang.startswith("ru") else "en"

_KPM_LOCALE = {}
_KPM_LOCALE_LOADED = False


def _load_kpm_locale():
    global _KPM_LOCALE, _KPM_LOCALE_LOADED
    if _KPM_LOCALE_LOADED:
        return
    try:
        _locale_path = os.path.join(os.path.dirname(__file__), "assests", "locale.json")
        if os.path.isfile(_locale_path):
            with open(_locale_path, "r", encoding="utf-8") as _f:
                _KPM_LOCALE = json.load(_f)
        _KPM_LOCALE_LOADED = True
    except Exception:
        _KPM_LOCALE = {}
        _KPM_LOCALE_LOADED = True


def _tr(key):
    _load_kpm_locale()
    lang = _get_lang()
    lang_dict = _KPM_LOCALE.get(lang) or _KPM_LOCALE.get("en", {})
    return lang_dict.get(key, key)


def _status_label(status: str):
    try:
        s = (status or "plugin").lower()
    except Exception:
        s = "plugin"
    if s == "library":
        return _tr("status_library")
    if s == "customization":
        return _tr("status_customization")
    if s == "utilities":
        return _tr("status_utilities")
    if s == "informational":
        return _tr("status_informational")
    if s == "fun":
        return _tr("status_fun")
    if s == "messages":
        return _tr("status_messages")
    return _tr("status_plugin")


def _status_sort_key(status: str):
    order = {
        "library": 0,
        "customization": 1,
        "utilities": 2,
        "informational": 3,
        "fun": 4,
        "messages": 5,
        "plugin": 6,
    }
    try:
        return order.get((status or "plugin").lower(), 99)
    except Exception:
        return 99

def _parse_markdown(text: str, text_color: int = None):
    from android.text import SpannableString, Spanned
    from android.text.style import ForegroundColorSpan, StyleSpan, URLSpan, StrikethroughSpan
    from android.text.style import TypefaceSpan
    from android.graphics import Typeface
    from android.text import TextUtils

    if not text:
        return None

    try:
        if text_color is None:
            from org.telegram.ui.ActionBar import Theme

            text_color = Theme.getColor(Theme.key_windowBackgroundWhiteBlackText)
    except Exception:
        text_color = 0xFF000000

    spannable = SpannableString(text)

    for m in __import__("re").finditer(r"\*\*(.+?)\*\*", text):
        spannable.setSpan(StyleSpan(Typeface.BOLD), m.start(1), m.end(1), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    for m in __import__("re").finditer(r"\*(.+?)\*", text):
        spannable.setSpan(StyleSpan(Typeface.ITALIC), m.start(1), m.end(1), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    for m in __import__("re").finditer(r"~~(.+?)~~", text):
        spannable.setSpan(StrikethroughSpan(), m.start(1), m.end(1), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

    # [text](url)
    for m in __import__("re").finditer(r"\[(.+?)\]\((.+?)\)", text):
        spannable.setSpan(
            URLSpan(m.group(2)),
            m.start(1),
            m.end(1),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )

    # @mentions / #tags → monospace
    for m in __import__("re").finditer(r"[@#]\w+", text):
        spannable.setSpan(
            TypefaceSpan("monospace"),
            m.start(),
            m.end(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )

    # URLs
    for m in __import__("re").finditer(r"https?://\S+", text):
        spannable.setSpan(
            URLSpan(m.group(0)),
            m.start(),
            m.end(),
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )

    return spannable

def open_link(url):
    from client_utils import get_last_fragment

    fragment = get_last_fragment()
    if not fragment:
        return
    context = fragment.getParentActivity()
    if not context:
        return
    intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    run_on_ui_thread(lambda: context.startActivity(intent))


def _get_current_account(fragment):
    try:
        from org.telegram.messenger import UserConfig

        current_user = UserConfig.getInstance(fragment.getClientUser())
        return current_user
    except Exception:
        return None


def open_username(username):
    def go():
        try:
            fragment = get_last_fragment()
            if not fragment:
                return
            account = _get_current_account(fragment)
            ok = False
            try:
                ok = get_messages_controller().openByUserName(username, fragment, account)
            except Exception as e:
                log(f"[KPM] openByUserName error: {e}")
            if not ok:
                try:
                    context = fragment.getParentActivity()
                    if context:
                        intent = Intent(Intent.ACTION_VIEW, Uri.parse(f"tg://resolve?domain={username}"))
                        context.startActivity(intent)
                        return
                except Exception as e2:
                    log(f"[KPM] tg://resolve fallback error: {e2}")
                open_link(f"https://t.me/{username}")
        except Exception as e:
            log(f"[KPM] open_username error: {e}")
            open_link(f"https://t.me/{username}")
    run_on_ui_thread(go)

class KPMSettingsHeaderHook:
    def __init__(self, plugin):
        self.plugin = plugin

    def after_hooked_method(self, param):
        try:
            activity = param.thisObject
            items = param.args[0]
            if not items or items.size() == 0:
                return

            from hook_utils import get_private_field

            plugin_obj = get_private_field(activity, "plugin")
            if not plugin_obj:
                return

            plugin_id = str(plugin_obj.getId())
            if plugin_id != "kangel_plugins_manager":
                return

            if get_private_field(activity, "createSubFragmentCallback") is not None:
                return

            from org.telegram.ui.Components import UItem
            from com.exteragram.messenger.plugins.models import HeaderSetting

            header = self.plugin._create_settings_header(activity.getContext())
            if header:
                item = UItem.asCustom(header)
                try:
                    item.settingItem = HeaderSetting("kpm_header")
                except Exception:
                    pass
                try:
                    item.setTransparent(True)
                except Exception:
                    pass
                items.add(0, item)
                items.add(1, UItem.asShadow())
        except Exception as e:
            log(f"[KPM] Error in settings header hook: {e}")
