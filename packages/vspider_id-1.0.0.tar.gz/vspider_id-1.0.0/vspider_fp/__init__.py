import ctypes

__version__ = '1.0.0'

_lib = ctypes.CDLL('/data/data/com.termux/files/usr/lib/vspider-fp.so')
_lib.get.argtypes = []
_lib.get.restype = ctypes.c_char_p

def get_device_hash():
    result = _lib.get()
    return result.decode() if result else None

__all__ = ['get_device_hash']
