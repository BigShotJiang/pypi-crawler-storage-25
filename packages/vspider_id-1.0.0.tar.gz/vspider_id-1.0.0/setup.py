from setuptools import setup, find_packages

setup(
    name='vspider-id',
    version='1.0.0',
    author='VSpider',
    description='Device fingerprinting library for Android',
    long_description='# vspider-id\n\nGet unique device hash\n\n## Usage\n```python\nfrom vspider_fp import get_device_hash\nprint(get_device_hash())\n```',
    long_description_content_type='text/markdown',
    packages=find_packages(),
    package_data={'vspider_fp': ['native/*.so']},
    include_package_data=True,
    python_requires='>=3.6',
)
