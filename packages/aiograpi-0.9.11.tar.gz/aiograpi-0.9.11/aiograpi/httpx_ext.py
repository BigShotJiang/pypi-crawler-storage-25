import asyncio
import ssl

import httpx
import orjson
import zstandard as zstd
from httpx import (
    CloseError,
    ConnectError,
    ConnectTimeout,
    CookieConflict,
    DecodingError,
    HTTPError,
    HTTPStatusError,
    InvalidURL,
    LocalProtocolError,
    NetworkError,
    PoolTimeout,
    ProtocolError,
    ProxyError,
    ReadError,
    ReadTimeout,
    RemoteProtocolError,
    RequestError,
    TimeoutException,
    TooManyRedirects,
    TransportError,
    UnsupportedProtocol,
    WriteError,
    WriteTimeout,
)
from httpx._client import ClientState
from httpx._decoders import SUPPORTED_DECODERS, ContentDecoder

httpx.Response.json = lambda self: orjson.loads(self.content)


class ZstdDecoder(ContentDecoder):
    def __init__(self) -> None:
        self.decompressor = zstd.ZstdDecompressor().decompressobj()

    def decode(self, data: bytes) -> bytes:
        # TODO: optimization
        if not data:
            return b""
        data_parts = [self.decompressor.decompress(data)]
        while self.decompressor.eof and self.decompressor.unused_data:
            unused_data = self.decompressor.unused_data
            self.decompressor = zstd.ZstdDecompressor().decompressobj()
            data_parts.append(self.decompressor.decompress(unused_data))
        return b"".join(data_parts)

    def flush(self) -> bytes:
        ret = self.decompressor.flush()
        if not self.decompressor.eof:
            raise DecodingError("Zstandard data is incomplete")
        return ret


SUPPORTED_DECODERS["zstd"] = ZstdDecoder

DEFAULT_TIMEOUT = 45


def _httpx_verify_value(verify):
    if isinstance(verify, str):
        return ssl.create_default_context(cafile=verify)
    return verify


async def request(method, url, proxy=None, verify=True, follow_redirects=True, **kwargs):
    if "timeout" not in kwargs:
        kwargs["timeout"] = DEFAULT_TIMEOUT
    async with httpx.AsyncClient(
        proxy=proxy,
        verify=_httpx_verify_value(verify),
        follow_redirects=follow_redirects,
    ) as client:
        return await client.request(method, url, **kwargs)


class Session:
    def __init__(self, verify=True):
        # TLS verification ON by default — turn off only if you're sure
        # the proxy is a known MITM (e.g. a corporate inspection
        # gateway). With verify=False, an attacker on the network path
        # can intercept sessionid / passwords / TOTP secrets.
        self.headers = {}
        self.verify = verify
        self._client = None
        self._proxy = None

    @property
    def cookies(self):
        return self._client.cookies.jar

    def cookies_dict(self):
        return {c.name: c.value for c in self._client.cookies.jar}

    def set_cookies(self, d):
        for k, v in d.items():
            self._client.cookies.set(k, v)

    @property
    def proxy(self):
        return self._proxy

    @proxy.setter
    def proxy(self, p):
        self._proxy = p
        self._set_client()

    def _set_client(self):
        self._client = httpx.AsyncClient(
            proxy=self._proxy,
            verify=_httpx_verify_value(self.verify),
            follow_redirects=True,
        )

    def set_verify(self, verify):
        self.verify = verify
        if self._client is not None:
            self._set_client()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args, **kwargs):
        await self._close()

    async def _close(self):
        if self._client and self._client._state is ClientState.OPENED:
            await self._client.__aexit__()

    async def request(self, *args, headers=None, proxy=None, **kwargs):
        if "timeout" not in kwargs:
            kwargs["timeout"] = DEFAULT_TIMEOUT
        if self._client._state is ClientState.UNOPENED:
            await self._client.__aenter__()
        headers = self.headers | (headers or {})
        headers = {k: v for k, v in headers.items() if v is not None}
        kwargs = {k: v for k, v in kwargs.items() if v}
        return await self._client.request(*args, headers=headers, **kwargs)

    async def get(self, *args, **kwargs):
        return await self.request("get", *args, **kwargs)

    async def post(self, *args, **kwargs):
        return await self.request("post", *args, **kwargs)


class CurlResponse:
    def __init__(self, response):
        self._response = response

    def __getattr__(self, name):
        return getattr(self._response, name)

    @property
    def status_code(self):
        return self._response.status_code

    @property
    def url(self):
        return self._response.url

    @property
    def text(self):
        return self._response.text

    @property
    def content(self):
        return self._response.content

    @property
    def headers(self):
        return self._response.headers

    def json(self):
        return self._response.json()

    def raise_for_status(self):
        if self.status_code < 400:
            return None
        request = httpx.Request("GET", str(self.url))
        response = httpx.Response(self.status_code, request=request, content=self.content)
        raise HTTPStatusError(f"{self.status_code} response for {self.url}", request=request, response=response)


class CurlSession:
    def __init__(self, verify=True, impersonate="chrome136"):
        try:
            import requests
            from curl_adapter import CurlCffiAdapter  # type: ignore[import-not-found, import-untyped]
        except ImportError as exc:
            raise RuntimeError(
                "curl public transport requires the optional curl extra: pip install aiograpi[curl]"
            ) from exc

        self.headers = {}
        self.verify = verify
        self.impersonate = impersonate
        self._proxy = None
        self._requests = requests
        self._client = requests.Session()
        self._client.verify = verify
        adapter = CurlCffiAdapter(impersonate_browser_type=impersonate)
        self._client.mount("https://", adapter)
        self._client.mount("http://", adapter)

    @property
    def cookies(self):
        return self._client.cookies

    def cookies_dict(self):
        return self._requests.utils.dict_from_cookiejar(self._client.cookies)

    def set_cookies(self, d):
        self._client.cookies.update(self._requests.utils.cookiejar_from_dict(d))

    @property
    def proxy(self):
        return self._proxy

    @proxy.setter
    def proxy(self, p):
        self._proxy = p
        self._client.proxies = {"http": p, "https": p} if p else {}

    def set_verify(self, verify):
        self.verify = verify
        self._client.verify = verify

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args, **kwargs):
        await self._close()

    async def _close(self):
        self._client.close()

    async def request(self, method, url, headers=None, proxy=None, **kwargs):
        if "timeout" not in kwargs:
            kwargs["timeout"] = DEFAULT_TIMEOUT
        headers = self.headers | (headers or {})
        headers = {k: v for k, v in headers.items() if v is not None}
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        try:
            response = await asyncio.to_thread(
                self._client.request,
                method,
                url,
                headers=headers,
                proxies={"http": proxy, "https": proxy} if proxy else None,
                **kwargs,
            )
        except (self._requests.exceptions.ConnectTimeout, self._requests.exceptions.ReadTimeout) as exc:
            raise ReadError(str(exc)) from exc
        except self._requests.exceptions.RequestException as exc:
            raise ConnectError(str(exc)) from exc
        return CurlResponse(response)

    async def get(self, *args, **kwargs):
        return await self.request("get", *args, **kwargs)

    async def post(self, *args, **kwargs):
        return await self.request("post", *args, **kwargs)

    async def head(self, *args, **kwargs):
        return await self.request("head", *args, **kwargs)


__all__ = [
    "HTTPError",
    "RequestError",
    "TransportError",
    "TimeoutException",
    "ConnectTimeout",
    "ReadTimeout",
    "WriteTimeout",
    "PoolTimeout",
    "NetworkError",
    "ConnectError",
    "ReadError",
    "WriteError",
    "CloseError",
    "ProtocolError",
    "LocalProtocolError",
    "RemoteProtocolError",
    "ProxyError",
    "UnsupportedProtocol",
    "DecodingError",
    "TooManyRedirects",
    "HTTPStatusError",
    "InvalidURL",
    "CookieConflict",
    "ZstdDecoder",
    "request",
    "Session",
    "CurlSession",
]
