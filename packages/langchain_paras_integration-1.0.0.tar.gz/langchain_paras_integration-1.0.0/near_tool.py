"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - Paras Integration
"""
import requests
import json
import base64
import time
import hashlib
import hmac
import urllib.parse
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


PARAS_API_BASE = "https://api-v2-mainnet.paras.id"

class ParasNFTSearchInput(BaseModel):
    collection_id: Optional[str] = Field(None, description="Collection ID to filter by")
    token_series_id: Optional[str] = Field(None, description="Token series ID")
    owner_id: Optional[str] = Field(None, description="NEAR account ID of owner")
    min_price: Optional[str] = Field(None, description="Minimum price in yoctoNEAR")
    max_price: Optional[str] = Field(None, description="Maximum price in yoctoNEAR")
    sort: Optional[str] = Field("updatedAt", description="Sort field: updatedAt, lowestPrice, highestPrice")
    limit: int = Field(10, description="Number of results to return (max 30)")

class ParasNFTSearchTool(BaseTool):
    name: str = "paras_nft_search"
    description: str = (
        "Search NFTs listed for sale on Paras marketplace. "
        "Filter by collection, owner, price range. Returns token info and listing prices."
    )
    args_schema: Type[BaseModel] = ParasNFTSearchInput

    def _run(self, collection_id: Optional[str] = None, token_series_id: Optional[str] = None,
             owner_id: Optional[str] = None, min_price: Optional[str] = None,
             max_price: Optional[str] = None, sort: str = "updatedAt", limit: int = 10) -> str:
        params: Dict[str, Any] = {"__limit": min(limit, 30), "__sort": sort, "__is_verified": "true"}
        if collection_id:
            params["collection_id"] = collection_id
        if token_series_id:
            params["token_series_id"] = token_series_id
        if owner_id:
            params["owner_id"] = owner_id
        if min_price:
            params["min_price"] = min_price
        if max_price:
            params["max_price"] = max_price
        try:
            resp = requests.get(f"{PARAS_API_BASE}/token", params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            tokens = data.get("data", {}).get("results", [])
            if not tokens:
                return "No NFTs found matching your criteria."
            results = []
            for t in tokens[:limit]:
                price = t.get("price")
                near_price = f"{int(price) / 1e24:.4f} NEAR" if price else "Not listed"
                results.append(
                    f"Token: {t.get('token_series_id')}#{t.get('edition_id', '?')} | "
                    f"Collection: {t.get('collection_id')} | "
                    f"Price: {near_price} | Owner: {t.get('owner_id')}"
                )
            return f"Found {len(tokens)} NFT(s):\n" + "\n".join(results)
        except Exception as e:
            return f"Error searching Paras NFTs: {e}"

    async def _arun(self, **kwargs: Any) -> str:
        return self._run(**kwargs)


class ParasCollectionStatsInput(BaseModel):
    collection_id: str = Field(..., description="Paras collection ID (e.g. 'near-punks.near')")

class ParasCollectionStatsTool(BaseTool):
    name: str = "paras_collection_stats"
    description: str = (
        "Get statistics and metadata for a Paras NFT collection: "
        "floor price, total volume, owner count, and collection details."
    )
    args_schema: Type[BaseModel] = ParasCollectionStatsInput

    def _run(self, collection_id: str) -> str:
        try:
            meta_resp = requests.get(f"{PARAS_API_BASE}/collections", params={"collection_id": collection_id}, timeout=15)
            meta_resp.raise_for_status()
            meta_data = meta_resp.json().get("data", {}).get("results", [])
            stats_resp = requests.get(f"{PARAS_API_BASE}/collection-stats", params={"collection_id": collection_id}, timeout=15)
            stats_resp.raise_for_status()
            stats = stats_resp.json().get("data", {})
            lines = [f"Collection: {collection_id}"]
            if meta_data:
                col = meta_data[0]
                lines.append(f"Name: {col.get('collection', collection_id)}")
                lines.append(f"Creator: {col.get('creator_id', 'unknown')}")
                lines.append(f"Description: {col.get('description', 'N/A')[:120]}")
                lines.append(f"Total Cards: {col.get('total_cards', 'N/A')}")
            if stats:
                floor = stats.get("floor_price")
                floor_str = f"{int(floor) / 1e24:.4f} NEAR" if floor else "N/A"
                volume = stats.get("volume")
                vol_str = f"{int(volume) / 1e24:.2f} NEAR" if volume else "N/A"
                lines.append(f"Floor Price: {floor_str}")
                lines.append(f"Total Volume: {vol_str}")
                lines.append(f"Owners: {stats.get('total_owners', 'N/A')}")
                lines.append(f"Transactions: {stats.get('total_transactions', 'N/A')}")
            return "\n".join(lines) if len(lines) > 1 else f"No data found for collection '{collection_id}'."
        except Exception as e:
            return f"Error fetching Paras collection stats: {e}"

    async def _arun(self, collection_id: str) -> str:
        return self._run(collection_id)