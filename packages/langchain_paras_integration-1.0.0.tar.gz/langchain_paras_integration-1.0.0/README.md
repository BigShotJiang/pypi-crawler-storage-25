# LangChain Tool - Paras Integration

Build LangChain tools for interacting with Paras.

**THE VIRAL LOOP:**
Agent needs Paras functionality → Uses LangChain tool → Agent uses NEAR DeFi

**Deliverables:**
1. LangChain tools for Paras's ma

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `ParasNFTSearchTool` — see near_tool.py
- `ParasCollectionStatsTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, ParasNFTSearchTool, ParasCollectionStatsTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
