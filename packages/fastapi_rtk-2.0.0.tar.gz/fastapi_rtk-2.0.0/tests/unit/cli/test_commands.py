"""Tier 14 - smoke tests for the cli command sub-apps.

These tests just verify that each sub-app's --help loads without errors -
proving the typer scaffolding wires up correctly. End-to-end command runs
(create-admin, db init, translate extract, export api-docs) need a live
FastAPI app + db, deferred to tier 15.
"""

from fastapi_rtk.cli.cli import app
from typer.testing import CliRunner

runner = CliRunner()


class TestSubAppHelp:
    def test_security_help(self):
        result = runner.invoke(app, ["security", "--help"])
        assert result.exit_code == 0

    def test_db_help(self):
        result = runner.invoke(app, ["db", "--help"])
        assert result.exit_code == 0

    def test_translate_help(self):
        result = runner.invoke(app, ["translate", "--help"])
        assert result.exit_code == 0

    def test_export_help(self):
        result = runner.invoke(app, ["export", "--help"])
        assert result.exit_code == 0


class TestSecuritySubcommands:
    """Subcommands that pass through `_check_existing_app` *after* --help works
    show 0; subcommands that exit when no app file is discoverable show 1.
    Either way they prove the typer wiring loaded.
    """

    def test_create_admin_help(self):
        result = runner.invoke(app, ["security", "create-admin", "--help"])
        assert result.exit_code in (0, 1)

    def test_create_user_help(self):
        result = runner.invoke(app, ["security", "create-user", "--help"])
        assert result.exit_code in (0, 1)

    def test_reset_password_help(self):
        result = runner.invoke(app, ["security", "reset-password", "--help"])
        assert result.exit_code in (0, 1)

    def test_export_users_help(self):
        result = runner.invoke(app, ["security", "export-users", "--help"])
        assert result.exit_code in (0, 1)

    def test_export_roles_help(self):
        result = runner.invoke(app, ["security", "export-roles", "--help"])
        assert result.exit_code in (0, 1)

    def test_cleanup_help(self):
        result = runner.invoke(app, ["security", "cleanup", "--help"])
        assert result.exit_code in (0, 1)


class TestTranslateSubcommands:
    def test_extract_help(self):
        result = runner.invoke(app, ["translate", "extract", "--help"])
        assert result.exit_code == 0

    def test_init_help(self):
        result = runner.invoke(app, ["translate", "init", "--help"])
        assert result.exit_code == 0

    def test_update_help(self):
        result = runner.invoke(app, ["translate", "update", "--help"])
        assert result.exit_code == 0

    def test_compile_help(self):
        result = runner.invoke(app, ["translate", "compile", "--help"])
        assert result.exit_code == 0

    def test_build_help(self):
        result = runner.invoke(app, ["translate", "build", "--help"])
        assert result.exit_code == 0


class TestTranslateInitBabelCli:
    """Direct calls to `init_babel_cli` exercise the helper logic without
    touching real Babel runs."""

    def test_creates_root_path_when_missing(self, tmp_path, config_setter):
        from fastapi_rtk.cli.commands.translate import init_babel_cli

        target = tmp_path / "lang_dir"
        # Confirm the helper materializes the directory
        config_setter("LANG_FOLDER", str(target))
        config_setter("BABEL_OPTIONS", {})
        cli = init_babel_cli()
        assert target.exists()
        assert cli is not None

    def test_raises_when_create_disabled(self, tmp_path, config_setter):
        from fastapi_rtk.cli.commands.translate import init_babel_cli

        config_setter("LANG_FOLDER", str(tmp_path / "missing"))
        config_setter("BABEL_OPTIONS", {})
        import pytest

        with pytest.raises(FileNotFoundError):
            init_babel_cli(create_root_path_if_not_exists=False, log=False)

    def test_uses_explicit_root_path(self, tmp_path, config_setter):
        from fastapi_rtk.cli.commands.translate import init_babel_cli

        config_setter("BABEL_OPTIONS", {})
        cli = init_babel_cli(root_path=str(tmp_path))
        assert cli is not None

    def test_uses_explicit_babel_cfg(self, tmp_path, config_setter):
        from fastapi_rtk.cli.commands.translate import init_babel_cli

        config_setter("BABEL_OPTIONS", {})
        cfg = tmp_path / "babel.cfg"
        cfg.write_text("[python: **.py]\n")
        cli = init_babel_cli(root_path=str(tmp_path), babel_cfg=str(cfg))
        assert cli is not None


class TestTranslateCommands:
    """Exercises the underlying command functions with mocked Babel CLI."""

    def test_extract_runs_babel_extract(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        config_setter("LANG_FOLDER", str(tmp_path / "lang"))

        fake_cli = MagicMock()
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.extract(extract_dir=str(tmp_path), keywords="lazy_text gettext")
        fake_cli.extract.assert_called_once()

    def test_init_runs_for_each_locale(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        config_setter("LANG_FOLDER", str(tmp_path / "lang"))
        config_setter("LANGUAGES", "en,de")

        fake_cli = MagicMock()
        # Domain file already exists -> skip extract path
        domain = tmp_path / "messages.pot"
        domain.write_text("")
        fake_cli.babel.config.BABEL_MESSAGE_POT_FILE = str(domain)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(tmp_path / "trans")

        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.init()
        # Two locales -> init called twice
        assert fake_cli.init.call_count == 2

    def test_init_skips_existing_locale(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        fake_cli = MagicMock()
        domain = tmp_path / "messages.pot"
        domain.write_text("")
        trans = tmp_path / "trans"
        (trans / "en").mkdir(parents=True)
        fake_cli.babel.config.BABEL_MESSAGE_POT_FILE = str(domain)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(trans)

        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.init(locales="en")
        # Existing dir -> init not called for `en`
        fake_cli.init.assert_not_called()

    def test_compile_runs(self, tmp_path, config_setter, monkeypatch):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        fake_cli = MagicMock()
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.compile()
        fake_cli.compile.assert_called_once()

    def test_update_skips_internal_merge_when_disabled(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        fake_cli = MagicMock()
        trans = tmp_path / "trans"
        (trans / "en").mkdir(parents=True)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(trans)
        fake_cli.babel.config.BABEL_DOMAIN = "messages.pot"

        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.update(locales="en", merge_with_internal=False)
        fake_cli.update.assert_called_once()

    def test_init_runs_extract_when_domain_missing(
        self, tmp_path, config_setter, monkeypatch
    ):
        # Domain file missing -> extract command runs first (lines 111-119)
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        config_setter("LANGUAGES", "en")

        fake_cli = MagicMock()
        # ROOT_DIR with at least one .py file present
        root = tmp_path / "rootpy"
        root.mkdir()
        (root / "x.py").write_text("# stub")
        domain = tmp_path / "missing.pot"
        fake_cli.babel.config.BABEL_MESSAGE_POT_FILE = str(domain)
        fake_cli.babel.config.ROOT_DIR = str(root)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(tmp_path / "trans")

        extract_calls = []

        def fake_extract(**kw):
            extract_calls.append(kw)

        monkeypatch.setattr(tr_mod, "extract", fake_extract)
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.init()
        # extract was invoked before init iteration
        assert len(extract_calls) == 1

    def test_update_runs_init_when_locale_dir_missing(
        self, tmp_path, config_setter, monkeypatch
    ):
        # Locale dir missing -> init() runs for that locale (lines 170-173)
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})

        fake_cli = MagicMock()
        trans = tmp_path / "trans"
        trans.mkdir()
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(trans)
        fake_cli.babel.config.BABEL_DOMAIN = "messages.pot"

        init_calls = []

        def fake_init(**kw):
            init_calls.append(kw)

        monkeypatch.setattr(tr_mod, "init", fake_init)
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.update(locales="de", merge_with_internal=False)
        # init invoked for missing locale `de`
        assert any(call.get("locales") == "de" for call in init_calls)

    def test_build_chains_extract_update_compile(
        self, tmp_path, config_setter, monkeypatch
    ):
        # build invokes extract + update + compile (lines 230-242)
        from fastapi_rtk.cli.commands import translate as tr_mod

        called = []

        def fake_extract(**kw):
            called.append("extract")

        def fake_update(**kw):
            called.append("update")

        def fake_compile(**kw):
            called.append("compile")

        monkeypatch.setattr(tr_mod, "extract", fake_extract)
        monkeypatch.setattr(tr_mod, "update", fake_update)
        monkeypatch.setattr(tr_mod, "compile", fake_compile)
        tr_mod.build()
        assert called == ["extract", "update", "compile"]

    def test_update_with_merge_internal_calls_merge_pot_files(
        self, tmp_path, config_setter, monkeypatch
    ):
        # merge_with_internal=True path calls merge_pot_files (lines 189-205)
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})

        fake_cli = MagicMock()
        trans = tmp_path / "trans"
        (trans / "en").mkdir(parents=True)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(trans)
        fake_cli.babel.config.BABEL_DOMAIN = "messages.pot"

        merge_calls = []

        def fake_merge(pot_files, output_path):
            merge_calls.append((list(pot_files), output_path))

        monkeypatch.setattr(tr_mod, "merge_pot_files", fake_merge)
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.update(locales="en", merge_with_internal=True)
        assert len(merge_calls) == 1


class TestSecurityCommandFunctions:
    """Direct calls to the typer command functions (bypassing prompts)."""

    def _wire_sm(self, monkeypatch, global_setter):
        from unittest.mock import AsyncMock, MagicMock

        sm = MagicMock()
        sm.create_user = AsyncMock(return_value=MagicMock(username="admin"))
        sm.reset_password = AsyncMock(return_value=MagicMock(username="admin"))
        sm.get_user = AsyncMock(return_value=MagicMock(username="admin"))
        sm.export_data = AsyncMock(return_value="{}")
        sm.cleanup = AsyncMock()
        sm.create_role = AsyncMock()
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)
        global_setter("admin_role", "Admin")
        global_setter("public_role", "Public")
        return sm

    def test_create_admin_with_args(self, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        sm = self._wire_sm(monkeypatch, global_setter)

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)
        sec_mod.create_admin(
            username="admin",
            email="admin@example.com",
            password="pass1234",
            first_name="Ad",
            last_name="Min",
        )
        sm.create_user.assert_called_once()

    def test_create_user_with_role(self, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        sm = self._wire_sm(monkeypatch, global_setter)

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)
        sec_mod.create_user(
            username="u",
            email="u@example.com",
            password="pass1234",
            first_name="Foo",
            last_name="Bar",
            role="Editor",
            create_role=True,
        )
        sm.create_user.assert_called_once()

    def test_create_user_with_create_role_no_role(self, monkeypatch, global_setter):
        # create_role=True with empty role -> defaults to g.public_role
        from fastapi_rtk.cli.commands import security as sec_mod

        sm = self._wire_sm(monkeypatch, global_setter)

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)
        sec_mod.create_user(
            username="u",
            email="u@example.com",
            password="pass1234",
            first_name="Foo",
            last_name="Bar",
            role="",
            create_role=True,
        )
        sm.create_user.assert_called_once()

    def test_reset_password_with_args(self, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        sm = self._wire_sm(monkeypatch, global_setter)
        sec_mod.reset_password(
            email_or_username="admin",
            password="pass1234",
        )
        sm.reset_password.assert_called_once()

    def test_export_users_command(self, tmp_path, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        self._wire_sm(monkeypatch, global_setter)
        target = tmp_path / "users.json"
        sec_mod.export_users(file_path=str(target))
        assert target.exists()

    def test_export_roles_command(self, tmp_path, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        self._wire_sm(monkeypatch, global_setter)
        target = tmp_path / "roles.csv"
        sec_mod.export_roles(file_path=str(target), type="csv")
        assert target.exists()

    def test_cleanup_command(self, monkeypatch, global_setter):
        from fastapi_rtk.cli.commands import security as sec_mod

        sm = self._wire_sm(monkeypatch, global_setter)
        sec_mod.cleanup()
        sm.cleanup.assert_called_once()


class TestSecurityCommandPrompts:
    """Drive prompt branches by monkeypatching typer.prompt / typer.echo."""

    def _wire_sm(self, monkeypatch, global_setter):
        from unittest.mock import AsyncMock, MagicMock

        sm = MagicMock()
        sm.create_user = AsyncMock(return_value=MagicMock(username="prompted"))
        sm.reset_password = AsyncMock(return_value=MagicMock(username="prompted"))
        sm.get_user = AsyncMock(return_value=MagicMock(username="prompted"))
        sm.export_data = AsyncMock(return_value="{}")
        sm.create_role = AsyncMock()
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)
        global_setter("admin_role", "Admin")
        global_setter("public_role", "Public")
        return sm

    def _scripted_prompt(self, answers):
        """Return a typer.prompt replacement that consumes a list of answers."""
        queue = list(answers)

        def _prompt(text, default=None, hide_input=False, **_kw):
            if queue:
                return queue.pop(0)
            return default if default is not None else ""

        return _prompt

    def test_create_admin_prompt_loops_with_mismatch_and_retry(
        self, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import security as sec_mod
        import typer

        sm = self._wire_sm(monkeypatch, global_setter)

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)

        # Order: empty username -> retry -> "admin"; empty email -> retry -> "a@x";
        # password mismatch -> retry; first/last empty defaults applied.
        answers = [
            "",  # first username prompt: empty -> echo + loop
            "admin",  # second prompt: accept
            "",  # email empty
            "a@x.com",  # email accept
            "pw1",  # password
            "pw2",  # confirm mismatch -> echo continue
            "secret123",  # password retry
            "secret123",  # confirm match
            "",  # first_name (uses default "")
            "",  # last_name (uses default "")
        ]
        echos = []
        monkeypatch.setattr(typer, "prompt", self._scripted_prompt(answers))
        monkeypatch.setattr(typer, "echo", lambda *a, **kw: echos.append(a))
        sec_mod.create_admin()
        sm.create_user.assert_called_once()

    def test_create_user_prompt_loops_with_mismatch(
        self, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import security as sec_mod
        import typer

        sm = self._wire_sm(monkeypatch, global_setter)

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)
        answers = [
            "",
            "u",
            "",
            "u@x.com",
            "x",
            "y",  # mismatch
            "validpw1",
            "validpw1",
            "",
            "",
        ]
        monkeypatch.setattr(typer, "prompt", self._scripted_prompt(answers))
        monkeypatch.setattr(typer, "echo", lambda *a, **kw: None)
        sec_mod.create_user()
        sm.create_user.assert_called_once()

    def test_reset_password_prompt_loops_with_mismatch(
        self, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import security as sec_mod
        import typer

        sm = self._wire_sm(monkeypatch, global_setter)
        answers = [
            "",
            "u@x.com",
            "x",
            "y",
            "newpw1234",
            "newpw1234",
        ]
        monkeypatch.setattr(typer, "prompt", self._scripted_prompt(answers))
        monkeypatch.setattr(typer, "echo", lambda *a, **kw: None)
        sec_mod.reset_password()
        sm.reset_password.assert_called_once()

    def test_export_users_prompts_for_file_path(
        self, tmp_path, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import security as sec_mod
        import typer

        self._wire_sm(monkeypatch, global_setter)
        target = tmp_path / "u.json"
        answers = ["", str(target)]
        monkeypatch.setattr(typer, "prompt", self._scripted_prompt(answers))
        monkeypatch.setattr(typer, "echo", lambda *a, **kw: None)
        sec_mod.export_users()
        assert target.exists()

    def test_export_roles_prompts_for_file_path(
        self, tmp_path, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import security as sec_mod
        import typer

        self._wire_sm(monkeypatch, global_setter)
        target = tmp_path / "r.json"
        answers = ["", str(target)]
        monkeypatch.setattr(typer, "prompt", self._scripted_prompt(answers))
        monkeypatch.setattr(typer, "echo", lambda *a, **kw: None)
        sec_mod.export_roles()
        assert target.exists()


class TestSecurityCliHelpers:
    """Async helpers under `cli.commands.security` exercised with mocked sm."""

    def test_export_data_writes_file(
        self, tmp_path, global_setter
    ):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands.security import export_data
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        sm = MagicMock()
        sm.export_data = AsyncMock(return_value="csv,content\nrow,here")
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)

        target = tmp_path / "out.csv"
        run_in_current_event_loop(export_data(str(target), "users", "csv"))
        assert target.read_text() == "csv,content\nrow,here"

    def test_cleanup_invokes_sm_cleanup(self, global_setter):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands.security import _cleanup
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        sm = MagicMock()
        sm.cleanup = AsyncMock()
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)
        run_in_current_event_loop(_cleanup())
        sm.cleanup.assert_called_once()

    def test_check_roles_raises_when_missing_no_create(
        self, monkeypatch, global_setter
    ):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands import security as sec_mod
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        # Stub db.session() context manager to yield a fake session
        class FakeSession:
            async def execute(self, stmt):
                result = MagicMock()
                result.scalar_one_or_none = MagicMock(return_value=None)
                return result

        class FakeSessionCtx:
            async def __aenter__(self):
                return FakeSession()

            async def __aexit__(self, *a):
                pass

        fake_db = MagicMock()
        fake_db.session = MagicMock(return_value=FakeSessionCtx())
        monkeypatch.setattr(sec_mod, "db", fake_db)

        import pytest

        with pytest.raises(Exception, match="does not exist"):
            run_in_current_event_loop(sec_mod._check_roles("Ghost", create=False))

    def test_check_roles_creates_when_missing_with_create_flag(
        self, monkeypatch, global_setter
    ):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands import security as sec_mod
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        class FakeSession:
            async def execute(self, stmt):
                result = MagicMock()
                result.scalar_one_or_none = MagicMock(return_value=None)
                return result

        class FakeSessionCtx:
            async def __aenter__(self):
                return FakeSession()

            async def __aexit__(self, *a):
                pass

        fake_db = MagicMock()
        fake_db.session = MagicMock(return_value=FakeSessionCtx())
        monkeypatch.setattr(sec_mod, "db", fake_db)

        sm = MagicMock()
        sm.create_role = AsyncMock()
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)

        run_in_current_event_loop(sec_mod._check_roles("NewRole", create=True))
        sm.create_role.assert_called_once()

    def test_create_user_with_role(self, monkeypatch, global_setter):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands import security as sec_mod
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        async def fake_check(name, create=False):
            return None

        monkeypatch.setattr(sec_mod, "_check_roles", fake_check)

        sm = MagicMock()
        sm.create_user = AsyncMock(return_value=MagicMock(username="x"))
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)

        result = run_in_current_event_loop(
            sec_mod._create_user("u", "u@example.com", "pw1234", role="Admin")
        )
        assert result.username == "x"
        sm.create_user.assert_called_once()

    def test_reset_password_helper(self, global_setter):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.cli.commands.security import _reset_password
        from fastapi_rtk.cli.utils import run_in_current_event_loop

        user = MagicMock()
        sm = MagicMock()
        sm.get_user = AsyncMock(return_value=user)
        sm.reset_password = AsyncMock(return_value=user)
        app = MagicMock()
        app.sm = sm
        global_setter("current_app", app)

        result = run_in_current_event_loop(_reset_password("u@example.com", "newpw"))
        assert result is user
        sm.reset_password.assert_called_once()


class TestDbConfig:
    """`Config.get_template_directory` covers the package-default branch."""

    def test_default_template_directory_resolves(self):
        from fastapi_rtk.cli.commands.db import Config

        c = Config()
        # No override -> resolves to the package's templates folder
        path = c.get_template_directory()
        assert path.endswith("templates")

    def test_override_template_directory(self, tmp_path):
        from fastapi_rtk.cli.commands.db import Config

        c = Config(template_directory=str(tmp_path))
        assert c.get_template_directory() == str(tmp_path)


class TestDbCommandWrappers:
    """Direct calls to db.<cmd> functions with mocked alembic.command."""

    def _patch_alembic(self, monkeypatch, name):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import db as db_mod

        called = {}

        def fake(*args, **kwargs):
            called["args"] = args
            called["kwargs"] = kwargs

        monkeypatch.setattr(db_mod.alembic.command, name, fake)
        return called

    def test_init(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.db import init

        called = self._patch_alembic(monkeypatch, "init")
        init(directory=str(tmp_path), template="fastapi")
        assert called["kwargs"]["template"] == "fastapi"

    def test_init_multidb_swaps_template(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.db import init

        called = self._patch_alembic(monkeypatch, "init")
        init(directory=str(tmp_path), template="fastapi", multidb=True)
        assert called["kwargs"]["template"] == "fastapi-multidb"

    def test_init_with_path_in_template(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.db import init

        called = self._patch_alembic(monkeypatch, "init")
        # Template with path -> split happens
        init(directory=str(tmp_path), template="/abs/dir/mytemplate")
        assert called["kwargs"]["template"] == "mytemplate"

    def test_revision(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import revision

        called = self._patch_alembic(monkeypatch, "revision")
        revision(message="initial", autogenerate=True)
        # Message passed positionally
        assert "initial" in called["args"]
        assert called["kwargs"]["autogenerate"] is True

    def test_migrate_calls_revision_with_autogenerate(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import migrate

        called = self._patch_alembic(monkeypatch, "revision")
        migrate(message="auto")
        assert called["kwargs"]["autogenerate"] is True

    def test_edit(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import edit

        called = self._patch_alembic(monkeypatch, "edit")
        edit(revision="abc")
        assert "abc" in called["args"]

    def test_merge(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import merge

        called = self._patch_alembic(monkeypatch, "merge")
        merge(revisions="r1,r2", message="m")
        assert called["kwargs"]["message"] == "m"

    def test_upgrade(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import upgrade

        called = self._patch_alembic(monkeypatch, "upgrade")
        upgrade(revision="head")
        assert "head" in called["args"]

    def test_downgrade(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import downgrade

        called = self._patch_alembic(monkeypatch, "downgrade")
        downgrade(revision="-1")
        assert "-1" in called["args"]

    def test_show(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import show

        called = self._patch_alembic(monkeypatch, "show")
        show(revision="head")
        assert "head" in called["args"]

    def test_history(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import history

        called = self._patch_alembic(monkeypatch, "history")
        history(verbose=True, indicate_current=True)
        assert called["kwargs"]["verbose"] is True

    def test_heads(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import heads

        called = self._patch_alembic(monkeypatch, "heads")
        heads(verbose=True, resolve_dependencies=True)
        assert called["kwargs"]["resolve_dependencies"] is True

    def test_branches(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import branches

        called = self._patch_alembic(monkeypatch, "branches")
        branches(verbose=True)
        assert called["kwargs"]["verbose"] is True

    def test_current(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import current

        called = self._patch_alembic(monkeypatch, "current")
        current()

    def test_stamp(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import stamp

        called = self._patch_alembic(monkeypatch, "stamp")
        stamp(revision="head", purge=True)
        assert called["kwargs"]["purge"] is True

    def test_check(self, monkeypatch):
        from fastapi_rtk.cli.commands.db import check

        called = self._patch_alembic(monkeypatch, "check")
        check()

    def test_list_templates(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.db import Config, list_templates

        # Build a fake templates dir
        templates_dir = tmp_path / "templates"
        for name in ("fastapi", "alpha"):
            d = templates_dir / name
            d.mkdir(parents=True)
            (d / "README").write_text(f"Synopsis for {name}\n")

        # Patch Config.get_template_directory to return our fake dir
        monkeypatch.setattr(
            Config, "get_template_directory", lambda self: str(templates_dir)
        )
        # Just smoke - no assertion on output here, command writes to stdout
        list_templates()


class TestExportHelpers:
    def test_generate_fastapi_rtk_tables_docs_populates(self):
        from fastapi_rtk.cli.commands.export import (
            _generate_fastapi_rtk_tables_docs,
            table_documentation,
        )
        from fastapi_rtk.const import (
            API_TABLE,
            ASSOC_PERMISSION_API_ROLE_TABLE,
            ASSOC_USER_ROLE_TABLE,
            OAUTH_TABLE,
            PERMISSION_API_TABLE,
            PERMISSION_TABLE,
            ROLE_TABLE,
            USER_TABLE,
        )

        # Snapshot + clear so we observe the mutation
        snapshot = {
            k: dict(table_documentation[k])
            for k in (
                USER_TABLE,
                ROLE_TABLE,
                PERMISSION_TABLE,
                API_TABLE,
                PERMISSION_API_TABLE,
                ASSOC_PERMISSION_API_ROLE_TABLE,
                ASSOC_USER_ROLE_TABLE,
                OAUTH_TABLE,
            )
        }
        for key in snapshot:
            table_documentation[key]["description"] = ""
            table_documentation[key]["columns"] = {}
        try:
            _generate_fastapi_rtk_tables_docs()
            assert table_documentation[USER_TABLE]["description"]
            assert "id" in table_documentation[USER_TABLE]["columns"]
            assert table_documentation[OAUTH_TABLE]["columns"]["oauth_name"]
        finally:
            for key, snap in snapshot.items():
                table_documentation[key].update(snap)


class TestApiSchemaCommand:
    def _wire_api_classes(self, monkeypatch, global_setter, with_base=False):
        from unittest.mock import MagicMock

        from fastapi_rtk.api.model_rest_api import ModelRestApi

        # Real-ish API: subclass of ModelRestApi with name attr
        class WidgetApi(ModelRestApi):
            pass

        widget = MagicMock(spec=WidgetApi)
        widget.__class__ = WidgetApi
        apis = [widget]

        if with_base:
            from fastapi_rtk.api import BaseApi

            class BareApi(BaseApi):
                pass

            bare = MagicMock(spec=BareApi)
            bare.__class__ = BareApi
            apis.append(bare)

        app = MagicMock()
        app.apis = apis
        global_setter("current_app", app)
        return apis

    def test_api_schema_with_named_filter(
        self, tmp_path, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import export as ex_mod

        self._wire_api_classes(monkeypatch, global_setter)

        def _stub(coro, *_args, **_kwargs):
            coro.close()
            return {"WidgetApi": {}}

        # Mock the inner async helper invocation; api_schema passes 2 args
        # to run_in_current_event_loop, so stub the signature too. The first
        # positional arg is a live coroutine — close it so pytest does not
        # raise `coroutine ... was never awaited`.
        monkeypatch.setattr(ex_mod, "run_in_current_event_loop", _stub)
        target = tmp_path / "schema.json"
        ex_mod.api_schema(apis="WidgetApi", filename=str(target))
        assert target.exists()
        body = target.read_text()
        assert "WidgetApi" in body

    def test_api_schema_rejects_non_model_rest_api(
        self, tmp_path, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import export as ex_mod

        self._wire_api_classes(monkeypatch, global_setter, with_base=True)

        def _stub(coro, *_args, **_kwargs):
            coro.close()
            return {}

        monkeypatch.setattr(ex_mod, "run_in_current_event_loop", _stub)
        import pytest

        with pytest.raises(ValueError, match="not ModelRestApi"):
            ex_mod.api_schema(apis="WidgetApi|BareApi", filename=str(tmp_path / "x.json"))

    def test_api_schema_no_apis_filter(
        self, tmp_path, monkeypatch, global_setter
    ):
        from fastapi_rtk.cli.commands import export as ex_mod

        self._wire_api_classes(monkeypatch, global_setter, with_base=True)

        def _stub(coro, *_args, **_kwargs):
            coro.close()
            return {}

        monkeypatch.setattr(ex_mod, "run_in_current_event_loop", _stub)
        target = tmp_path / "schema_all.json"
        ex_mod.api_schema(filename=str(target))
        assert target.exists()


class TestApiDocsCommand:
    def test_api_docs_writes_markdown_no_apis(
        self, tmp_path, monkeypatch, global_setter
    ):
        from unittest.mock import MagicMock

        from fastapi import FastAPI

        from fastapi_rtk.cli.commands import export as ex_mod

        # Build a minimal app with one route + components (request body schema)
        from pydantic import BaseModel

        fastapi_app = FastAPI()

        class WidgetIn(BaseModel):
            name: str

        @fastapi_app.post("/widgets/", tags=["WidgetApi"])
        def create_widget(body: WidgetIn):
            return {"name": body.name}

        # Wire `g.current_app.app + apis` so api_docs walks the openapi spec
        app_obj = MagicMock()
        app_obj.app = fastapi_app
        app_obj.apis = []
        global_setter("current_app", app_obj)

        target = tmp_path / "api.md"
        ex_mod.api_docs(filename=str(target))
        assert target.exists()
        body = target.read_text()
        # Schemas section always populated from openapi components
        assert "Schemas" in body
        assert "WidgetIn" in body


class TestApiDocsCommandFilteredWalk:
    """Hit the body of api_docs (lines 154-241): integrate_router + paths walk."""

    def test_api_docs_with_named_filter_walks_paths(
        self, tmp_path, monkeypatch, global_setter
    ):
        from unittest.mock import MagicMock

        from fastapi import FastAPI
        from pydantic import BaseModel

        from fastapi_rtk.api.model_rest_api import ModelRestApi
        from fastapi_rtk.cli.commands import export as ex_mod

        # Build a FastAPI app with a path tagged "WidgetApi" + request body $ref
        # + response $ref so api_docs walks the entire body.
        class WidgetIn(BaseModel):
            name: str

        class WidgetOut(BaseModel):
            id: int

        fastapi_app = FastAPI()

        @fastapi_app.post(
            "/widgets/",
            tags=["WidgetApi"],
            responses={
                200: {"model": WidgetOut, "description": "ok"},
                "default": {"description": "fallback"},
            },
            summary="Create a widget",
        )
        def create_widget(body: WidgetIn):
            return {"id": 1}

        # Stub a ModelRestApi-like instance with class name "WidgetApi"
        class WidgetApi(ModelRestApi):
            pass

        widget = MagicMock(spec=WidgetApi)
        widget.__class__ = WidgetApi
        widget.description = "Widget API"
        widget.integrate_router = MagicMock()

        app_obj = MagicMock()
        app_obj.app = fastapi_app
        app_obj.apis = [widget]
        global_setter("current_app", app_obj)

        target = tmp_path / "filtered.md"
        ex_mod.api_docs(apis="WidgetApi", filename=str(target))
        assert target.exists()
        body = target.read_text()
        # Body schema $ref + response schema $ref both rendered
        assert "WidgetIn" in body or "WidgetOut" in body
        assert "Create a widget" in body or "/widgets/" in body
        widget.integrate_router.assert_called_once()


class TestLicensesOutputDirDefault:
    def test_licenses_output_dir_from_setting(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands import export as ex_mod
        from fastapi_rtk.setting import Setting

        # Force LICENSE_FOLDER to a tmp dir so the default branch gets used.
        monkeypatch.setattr(
            type(Setting), "LICENSE_FOLDER", str(tmp_path / "lic_default")
        )
        monkeypatch.setattr(
            ex_mod.piplicenses,
            "create_output_string",
            lambda args: "[]",
        )
        ex_mod.licenses(webapp_dir=str(tmp_path / "ghost"))
        assert (tmp_path / "lic_default" / "app-licenses.json").exists()


class TestDbDocsCommand:
    def test_db_docs_writes_markdown(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.export import db_docs

        target = tmp_path / "schema.md"
        db_docs(filename=str(target))
        assert target.exists()
        body = target.read_text()
        # Markdown formatted; contains the Database section
        assert "Database" in body or "database" in body.lower()

    def test_db_docs_filtered_tables(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands.export import db_docs

        target = tmp_path / "schema_filtered.md"
        # Filter to a known fastapi_rtk table; just smoke that path runs
        db_docs(filename=str(target), tables="ab_user", separator="|")
        assert target.exists()


class TestLicensesCommand:
    def test_licenses_no_webapp_skips(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands import export as ex_mod

        # Mock piplicenses output so the "app" half doesn't shell out
        monkeypatch.setattr(
            ex_mod.piplicenses,
            "create_output_string",
            lambda args: '[{"Name":"x","Version":"1","License":"MIT"}]',
        )

        out_dir = tmp_path / "lic"
        ex_mod.licenses(output_dir=str(out_dir), webapp_dir=str(tmp_path / "ghost"))
        # App licenses written
        assert (out_dir / "app-licenses.json").exists()
        # Webapp half was skipped because dir/package.json missing
        assert not (out_dir / "webapp-licenses.json").exists()

    def test_licenses_webapp_subprocess_failure_logged(self, tmp_path, monkeypatch):
        import subprocess as subprocess_mod

        from fastapi_rtk.cli.commands import export as ex_mod

        monkeypatch.setattr(
            ex_mod.piplicenses,
            "create_output_string",
            lambda args: "{}",
        )

        # Create a webapp dir with package.json
        webapp_dir = tmp_path / "wa"
        webapp_dir.mkdir()
        (webapp_dir / "package.json").write_text('{"name":"x"}')

        class FakeResult:
            returncode = 1
            stderr = "boom"
            stdout = ""

        monkeypatch.setattr(
            ex_mod.subprocess,
            "run",
            lambda *args, **kwargs: FakeResult(),
        )

        out_dir = tmp_path / "lic"
        ex_mod.licenses(
            output_dir=str(out_dir),
            webapp_dir=str(webapp_dir),
            with_system=False,
        )
        # App licenses still written; webapp not
        assert (out_dir / "app-licenses.json").exists()
        assert not (out_dir / "webapp-licenses.json").exists()

    def test_licenses_webapp_subprocess_success(self, tmp_path, monkeypatch):
        from fastapi_rtk.cli.commands import export as ex_mod

        monkeypatch.setattr(
            ex_mod.piplicenses,
            "create_output_string",
            lambda args: "{}",
        )

        webapp_dir = tmp_path / "wa"
        webapp_dir.mkdir()
        (webapp_dir / "package.json").write_text('{"name":"x"}')

        class FakeResult:
            returncode = 0
            stderr = ""
            stdout = '{"react@18.0.0":{"licenses":"MIT"}}'

        monkeypatch.setattr(
            ex_mod.subprocess,
            "run",
            lambda *args, **kwargs: FakeResult(),
        )

        out_dir = tmp_path / "lic"
        ex_mod.licenses(
            output_dir=str(out_dir),
            webapp_dir=str(webapp_dir),
        )
        assert (out_dir / "webapp-licenses.json").exists()


class TestExportSubcommands:
    def test_api_schema_help(self):
        result = runner.invoke(app, ["export", "api-schema", "--help"])
        assert result.exit_code in (0, 1)

    def test_api_docs_help(self):
        result = runner.invoke(app, ["export", "api-docs", "--help"])
        assert result.exit_code in (0, 1)

    def test_db_docs_help(self):
        result = runner.invoke(app, ["export", "db-docs", "--help"])
        assert result.exit_code in (0, 1)

    def test_licenses_help(self):
        result = runner.invoke(app, ["export", "licenses", "--help"])
        assert result.exit_code in (0, 1)


class TestTranslateExtraGaps:
    """Line 117: extract_dir falls back to parent when no .py files present.
    Lines 161-162: update() default-LANGUAGES branch when locales=None."""

    def test_init_extract_dir_falls_back_to_parent(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        config_setter("LANGUAGES", "en")

        fake_cli = MagicMock()
        # ROOT_DIR contains no .py files — line 117 should fire
        empty_root = tmp_path / "no_py"
        empty_root.mkdir()
        (empty_root / "README.txt").write_text("")
        domain = tmp_path / "missing.pot"
        fake_cli.babel.config.BABEL_MESSAGE_POT_FILE = str(domain)
        fake_cli.babel.config.ROOT_DIR = str(empty_root)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(tmp_path / "trans")

        captured = []

        def fake_extract(**kw):
            captured.append(kw)

        monkeypatch.setattr(tr_mod, "extract", fake_extract)
        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        tr_mod.init()
        assert captured
        extract_dir = captured[0]["extract_dir"]
        assert extract_dir.rstrip("/").endswith("..")

    def test_update_uses_default_languages_when_none(
        self, tmp_path, config_setter, monkeypatch
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.cli.commands import translate as tr_mod

        config_setter("BABEL_OPTIONS", {})
        config_setter("LANGUAGES", "en")

        fake_cli = MagicMock()
        trans = tmp_path / "trans"
        (trans / "en").mkdir(parents=True)
        fake_cli.babel.config.BABEL_TRANSLATION_DIRECTORY = str(trans)
        fake_cli.babel.config.BABEL_DOMAIN = "messages.pot"

        monkeypatch.setattr(tr_mod, "init_babel_cli", lambda **kw: fake_cli)
        monkeypatch.setattr(tr_mod, "merge_pot_files", lambda *a, **kw: None)
        # locales=None → lines 161-162 fire (default branch)
        tr_mod.update(merge_with_internal=True)
        fake_cli.update.assert_called_once()
