"""Pluggable text embedding (Phase 2)."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class Embedder(Protocol):
    """Embed segment bodies; each vector length must match `KgConfig.embedding_dimension`."""

    async def embed_texts(self, texts: list[str]) -> list[list[float]]:
        ...