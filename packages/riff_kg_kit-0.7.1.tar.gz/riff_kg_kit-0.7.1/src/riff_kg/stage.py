"""Extract -> staged proposals (no canonical graph writes). Phase 3."""

from __future__ import annotations

from riff_kg.extract import (
    ProposalDraft,
    SegmentExtractor,
    run_extraction_for_signal,
    validate_proposal_span,
)

__all__ = [
    "ProposalDraft",
    "SegmentExtractor",
    "run_extraction_for_signal",
    "validate_proposal_span",
]