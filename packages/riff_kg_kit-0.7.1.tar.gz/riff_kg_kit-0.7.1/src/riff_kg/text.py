"""Character-level normalization and segmentation."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from riff_kg.config import KgConfig


@dataclass(frozen=True)
class TextSegmentPiece:
    """Half-open range [char_offset_start, char_offset_end) over normalized text."""

    char_offset_start: int
    char_offset_end: int
    body: str

    def __post_init__(self) -> None:
        if self.char_offset_end < self.char_offset_start:
            raise ValueError("char_offset_end must be >= char_offset_start")
        expected_len = self.char_offset_end - self.char_offset_start
        if len(self.body) != expected_len:
            raise ValueError("body length must match half-open span")


def normalize_text(raw: str) -> str:
    """Strip, Unicode NFC, collapse runs of whitespace/newlines (conservative)."""
    t = unicodedata.normalize("NFC", (raw or "").strip())
    t = re.sub(r"\r\n", "\n", t)
    t = re.sub(r"\n{4,}", "\n\n\n", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    return t


def segment_text(normalized: str, cfg: KgConfig) -> list[TextSegmentPiece]:
    """Split normalized text into >=1 segment using kit chunk policy."""
    if not normalized:
        return [TextSegmentPiece(0, 0, "")]

    n = len(normalized)
    if n <= cfg.chunk_if_longer_than_chars:
        return [TextSegmentPiece(0, n, normalized)]

    max_len = cfg.chunk_max_chars
    overlap = min(cfg.chunk_overlap_chars, max_len - 1) if max_len > 1 else 0
    pieces: list[TextSegmentPiece] = []
    start = 0
    while start < n:
        end = min(start + max_len, n)
        body = normalized[start:end]
        pieces.append(TextSegmentPiece(start, end, body))
        if end == n:
            break
        nxt = max(0, end - overlap)
        if nxt <= start:
            nxt = end
        start = nxt
    return pieces
