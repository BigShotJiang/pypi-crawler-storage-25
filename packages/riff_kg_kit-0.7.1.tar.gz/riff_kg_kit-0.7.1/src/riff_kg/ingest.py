"""Phase A persistence: signal rows + segments + optional embeddings."""

from __future__ import annotations

import json
import uuid
from typing import Any

import asyncpg

from riff_kg.config import KgConfig
from riff_kg.embedder import Embedder
from riff_kg.text import normalize_text, segment_text


def vector_literal(vec: list[float]) -> str:
    """pgvector text representation for asyncpg + ::vector cast."""
    return "[" + ",".join(str(float(x)) for x in vec) + "]"


async def replace_segments_for_signal(
    conn: asyncpg.Connection,
    signal_id: uuid.UUID,
    normalized_text: str,
    cfg: KgConfig,
    embedder: Embedder | None = None,
    *,
    embedding_meta: dict[str, Any] | None = None,
) -> list[uuid.UUID]:
    """Delete existing segments, insert new pieces, optionally fill embeddings."""
    pieces = segment_text(normalized_text, cfg)
    await conn.execute(
        "DELETE FROM riff_kg.signal_segments WHERE signal_id = $1",
        signal_id,
    )
    ids: list[uuid.UUID] = []
    for i, piece in enumerate(pieces):
        row_id = await conn.fetchval(
            """
            INSERT INTO riff_kg.signal_segments (
                signal_id, segment_index, char_offset_start, char_offset_end, body
            )
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
            """,
            signal_id,
            i,
            piece.char_offset_start,
            piece.char_offset_end,
            piece.body,
        )
        ids.append(row_id)

    if embedder is not None and pieces and any(p.body for p in pieces):
        texts = [p.body for p in pieces]
        vectors = await embedder.embed_texts(texts)
        if len(vectors) != len(ids):
            raise ValueError(
                f"embedder returned {len(vectors)} vectors for {len(ids)} segments",
            )
        meta_base = embedding_meta or {}
        for seg_id, vec in zip(ids, vectors, strict=True):
            if len(vec) != cfg.embedding_dimension:
                raise ValueError(
                    f"expected embedding dim {cfg.embedding_dimension}, got {len(vec)}",
                )
            await conn.execute(
                """
                UPDATE riff_kg.signal_segments
                SET embedding = $1::vector,
                    embedding_meta = $2::jsonb
                WHERE id = $3
                """,
                vector_literal(vec),
                json.dumps(meta_base),
                seg_id,
            )

    return ids


async def insert_signal_row(
    conn: asyncpg.Connection,
    *,
    scope_id: str | None,
    source_system: str,
    source_ref: dict[str, Any],
    metadata: dict[str, Any] | None,
    raw_text_for_inline: str | None,
    byte_length: int,
    status: str = "processing",
) -> uuid.UUID:
    """Insert `riff_kg.signals` row; does not create segments."""
    sid = await conn.fetchval(
        """
        INSERT INTO riff_kg.signals (
            scope_id, source_system, source_ref, raw_text_inline, byte_length, status, metadata
        )
        VALUES ($1, $2, $3::jsonb, $4, $5, $6, $7::jsonb)
        RETURNING id
        """,
        scope_id,
        source_system,
        json.dumps(source_ref),
        raw_text_for_inline,
        byte_length,
        status,
        json.dumps(metadata or {}),
    )
    return sid


async def finalize_signal_ready(conn: asyncpg.Connection, signal_id: uuid.UUID) -> None:
    await conn.execute(
        """
        UPDATE riff_kg.signals
        SET status = 'ready', updated_at = now()
        WHERE id = $1
        """,
        signal_id,
    )


async def ingest_new_signal(
    conn: asyncpg.Connection,
    *,
    scope_id: str | None,
    source_system: str,
    source_ref: dict[str, Any],
    raw_text: str,
    cfg: KgConfig,
    embedder: Embedder | None = None,
    metadata: dict[str, Any] | None = None,
    embedding_meta: dict[str, Any] | None = None,
    inline_text_max_bytes: int = 500_000,
) -> uuid.UUID:
    """Normalize text, insert signal, write segments (+ embeddings), mark ready."""
    norm = normalize_text(raw_text)
    norm_bytes = len(norm.encode("utf-8"))
    inline = norm if norm_bytes <= inline_text_max_bytes else None
    async with conn.transaction():
        sid = await insert_signal_row(
            conn,
            scope_id=scope_id,
            source_system=source_system,
            source_ref=source_ref,
            metadata=metadata,
            raw_text_for_inline=inline,
            byte_length=norm_bytes,
            status="processing",
        )
        await replace_segments_for_signal(
            conn,
            sid,
            norm,
            cfg,
            embedder=embedder,
            embedding_meta=embedding_meta,
        )
        await finalize_signal_ready(conn, sid)
    return sid