"""Apply numbered Postgres migrations (requires asyncpg)."""

from __future__ import annotations

from importlib import resources

import asyncpg

from riff_kg.migrations import MIGRATION_STEMS


def _load_sql(stem: str) -> str:
    name = f"{stem}.sql"
    return resources.files("riff_kg.migrations").joinpath(name).read_text(encoding="utf-8")


def _split_sql(sql: str) -> list[str]:
    chunks: list[str] = []
    for part in sql.split(";"):
        stmt = part.strip()
        if not stmt:
            continue
        if all(not ln.strip() or ln.strip().startswith("--") for ln in stmt.splitlines()):
            continue
        chunks.append(stmt + ";")
    return chunks


async def _migration_applied(conn: asyncpg.Connection, version: str) -> bool:
    try:
        v = await conn.fetchval(
            "SELECT 1 FROM riff_kg.schema_migrations WHERE version = $1",
            version,
        )
        return v is not None
    except asyncpg.exceptions.UndefinedTableError:
        return False


async def apply_migrations(conn: asyncpg.Connection) -> list[str]:
    """Run pending migrations in order. Returns stems applied in this call."""
    applied: list[str] = []
    for stem in MIGRATION_STEMS:
        if await _migration_applied(conn, stem):
            continue
        sql = _load_sql(stem)
        stmts = _split_sql(sql)
        async with conn.transaction():
            for statement in stmts:
                await conn.execute(statement)
            await conn.execute(
                "INSERT INTO riff_kg.schema_migrations (version) VALUES ($1)",
                stem,
            )
        applied.append(stem)
    return applied