-- LLM extraction runs and staged proposals (no canonical graph until commit)
CREATE TABLE IF NOT EXISTS riff_kg.extraction_runs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    signal_id uuid REFERENCES riff_kg.signals (id) ON DELETE SET NULL,
    batch_id uuid,
    model_id text,
    prompt_hash text,
    config_snapshot jsonb,
    status text NOT NULL DEFAULT 'running',
    error_message text,
    created_at timestamptz NOT NULL DEFAULT now (),
    completed_at timestamptz
);

CREATE TABLE IF NOT EXISTS riff_kg.staged_proposals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    extraction_run_id uuid NOT NULL REFERENCES riff_kg.extraction_runs (id) ON DELETE CASCADE,
    segment_id uuid NOT NULL REFERENCES riff_kg.signal_segments (id) ON DELETE CASCADE,
    char_start integer,
    char_end integer,
    proposal_kind text NOT NULL,
    payload jsonb NOT NULL,
    status text NOT NULL DEFAULT 'pending_review',
    resolution_note text,
    created_at timestamptz NOT NULL DEFAULT now (),
    CONSTRAINT chk_staged_span CHECK (
        char_start IS NULL
        OR char_end IS NULL
        OR char_end >= char_start
    )
);

CREATE INDEX IF NOT EXISTS idx_riff_kg_extraction_signal ON riff_kg.extraction_runs (signal_id);

CREATE INDEX IF NOT EXISTS idx_riff_kg_extraction_batch ON riff_kg.extraction_runs (batch_id);

CREATE INDEX IF NOT EXISTS idx_riff_kg_staged_status ON riff_kg.staged_proposals (status);

CREATE INDEX IF NOT EXISTS idx_riff_kg_staged_run ON riff_kg.staged_proposals (extraction_run_id);