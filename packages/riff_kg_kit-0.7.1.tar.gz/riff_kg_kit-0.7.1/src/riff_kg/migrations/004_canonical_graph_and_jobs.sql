-- Canonical committed graph + async job queue
CREATE TABLE IF NOT EXISTS riff_kg.entities (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    scope_id text NOT NULL,
    entity_type text NOT NULL,
    label text NOT NULL,
    canonical_key text,
    attrs jsonb NOT NULL DEFAULT '{}'::jsonb,
    valid_from timestamptz,
    valid_to timestamptz,
    created_at timestamptz NOT NULL DEFAULT now ()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_riff_kg_entities_scope_type_key ON riff_kg.entities (scope_id, entity_type, canonical_key)
WHERE
    canonical_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_riff_kg_entities_scope_type ON riff_kg.entities (scope_id, entity_type);

CREATE TABLE IF NOT EXISTS riff_kg.relations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    scope_id text NOT NULL,
    src_entity_id uuid NOT NULL REFERENCES riff_kg.entities (id) ON DELETE CASCADE,
    dst_entity_id uuid NOT NULL REFERENCES riff_kg.entities (id) ON DELETE CASCADE,
    relation_type text NOT NULL,
    attrs jsonb NOT NULL DEFAULT '{}'::jsonb,
    evidence_segment_id uuid NOT NULL REFERENCES riff_kg.signal_segments (id) ON DELETE RESTRICT,
    evidence_char_start integer,
    evidence_char_end integer,
    staged_proposal_id uuid REFERENCES riff_kg.staged_proposals (id) ON DELETE SET NULL,
    extraction_run_id uuid REFERENCES riff_kg.extraction_runs (id) ON DELETE SET NULL,
    committed_by text,
    committed_at timestamptz NOT NULL DEFAULT now (),
    valid_from timestamptz,
    valid_to timestamptz
);

CREATE INDEX IF NOT EXISTS idx_riff_kg_rel_src ON riff_kg.relations (src_entity_id);

CREATE INDEX IF NOT EXISTS idx_riff_kg_rel_dst ON riff_kg.relations (dst_entity_id);

CREATE INDEX IF NOT EXISTS idx_riff_kg_rel_scope_type ON riff_kg.relations (scope_id, relation_type);

CREATE TABLE IF NOT EXISTS riff_kg.kg_jobs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    scope_id text,
    job_type text NOT NULL,
    payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL DEFAULT 'queued',
    attempts integer NOT NULL DEFAULT 0,
    last_error text,
    created_at timestamptz NOT NULL DEFAULT now (),
    updated_at timestamptz NOT NULL DEFAULT now ()
);

CREATE INDEX IF NOT EXISTS idx_riff_kg_jobs_status ON riff_kg.kg_jobs (status, created_at);

CREATE INDEX IF NOT EXISTS idx_riff_kg_segments_embedding ON riff_kg.signal_segments USING hnsw (embedding vector_cosine_ops)
WITH
    (m = 16, ef_construction = 64);