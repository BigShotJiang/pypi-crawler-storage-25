-- riff-kg-kit Phase 1: extensions and migration ledger
CREATE SCHEMA IF NOT EXISTS riff_kg;

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS riff_kg.schema_migrations (
    version text PRIMARY KEY,
    applied_at timestamptz NOT NULL DEFAULT now()
);
