-- Ingest storage: signals and text segments (with optional embedding column)
CREATE TABLE IF NOT EXISTS riff_kg.signals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    scope_id text,
    source_system text NOT NULL,
    source_ref jsonb NOT NULL DEFAULT '{}'::jsonb,
    raw_storage_key text,
    normalized_text_storage_key text,
    raw_text_inline text,
    content_hash text,
    byte_length integer,
    status text NOT NULL DEFAULT 'pending',
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS riff_kg.signal_segments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid (),
    signal_id uuid NOT NULL REFERENCES riff_kg.signals (id) ON DELETE CASCADE,
    segment_index integer NOT NULL CHECK (segment_index >= 0),
    char_offset_start integer NOT NULL DEFAULT 0,
    char_offset_end integer NOT NULL,
    body text NOT NULL,
    embedding vector(768),
    embedding_meta jsonb,
    body_tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', body)) STORED,
    created_at timestamptz NOT NULL DEFAULT now (),
    UNIQUE (signal_id, segment_index)
);

CREATE INDEX IF NOT EXISTS idx_riff_kg_signals_scope_status ON riff_kg.signals (scope_id, status);

CREATE INDEX IF NOT EXISTS idx_riff_kg_signals_created ON riff_kg.signals (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_riff_kg_segments_signal ON riff_kg.signal_segments (signal_id);

CREATE INDEX IF NOT EXISTS idx_riff_kg_segments_tsv ON riff_kg.signal_segments USING gin (body_tsv);