"""SQL migrations shipped with riff_kg (Postgres + pgvector)."""

MIGRATION_STEMS: tuple[str, ...] = (
    "001_extensions",
    "002_signals_and_segments",
    "003_extraction_and_staging",
    "004_canonical_graph_and_jobs",
)