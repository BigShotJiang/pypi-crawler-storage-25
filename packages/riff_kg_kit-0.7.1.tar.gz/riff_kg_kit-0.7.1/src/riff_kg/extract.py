"""Phase 3: LLM-based extraction into staged_proposals only. No canonical graph writes."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

import asyncpg

from riff_kg.config import KgConfig


@dataclass(frozen=True)
class ProposalDraft:
    """One row to insert into `riff_kg.staged_proposals` (pending_review)."""

    proposal_kind: str
    payload: dict[str, Any]
    char_start: int | None = None
    char_end: int | None = None

    def __post_init__(self) -> None:
        if not self.proposal_kind.strip():
            raise ValueError("proposal_kind must be non-empty")


@runtime_checkable
class SegmentExtractor(Protocol):
    """Produce draft proposals for a single segment body."""

    async def extract_for_segment(
        self,
        *,
        segment_id: uuid.UUID,
        segment_index: int,
        body: str,
        signal_id: uuid.UUID,
        scope_id: str | None,
        source_system: str,
        source_ref: dict[str, Any],
        cfg: KgConfig,
    ) -> list[ProposalDraft]:
        ...


def validate_proposal_span(body: str, start: int | None, end: int | None) -> None:
    if start is None and end is None:
        return
    if start is None or end is None:
        raise ValueError("char_start and char_end must both be set or both omitted")
    if start < 0 or end > len(body) or end < start:
        raise ValueError("invalid char span for segment body")


async def run_extraction_for_signal(
    conn: asyncpg.Connection,
    signal_id: uuid.UUID,
    cfg: KgConfig,
    extractor: SegmentExtractor,
    *,
    batch_id: uuid.UUID | None = None,
    model_id: str | None = None,
    prompt_hash: str | None = None,
    extra_config: dict[str, Any] | None = None,
) -> uuid.UUID:
    """Create an `extraction_run` and append `staged_proposals` for each segment.

    Inserts are **not** wrapped in a single outer transaction: each statement
    commits when the connection is in autocommit mode, so proposals from
    already-processed segments remain visible and durable if a later segment
    fails or the process is killed (timeouts, deploys). If the caller has
    already opened a transaction on ``conn``, behavior stays all-or-nothing
    with that outer transaction.

    On failure after the run row is created, ``status`` is set to ``failed`` and
    ``error_message`` is populated; staged rows from successful segments are
    kept (again, unless rolled back by a caller-owned transaction).
    """
    row = await conn.fetchrow(
        """
        SELECT scope_id, source_system, source_ref
        FROM riff_kg.signals
        WHERE id = $1
        """,
        signal_id,
    )
    if row is None:
        raise ValueError(f"signal not found: {signal_id}")

    scope_id = row["scope_id"]
    source_system = row["source_system"]
    source_ref = row["source_ref"]
    if not isinstance(source_ref, dict):
        source_ref = {}

    snap = {**(extra_config or {}), "kg_config": cfg.model_dump(mode="json")}

    run_id = await conn.fetchval(
        """
        INSERT INTO riff_kg.extraction_runs (
            signal_id, batch_id, model_id, prompt_hash, config_snapshot, status
        )
        VALUES ($1, $2, $3, $4, $5::jsonb, 'running')
        RETURNING id
        """,
        signal_id,
        batch_id,
        model_id,
        prompt_hash,
        json.dumps(snap),
    )

    try:
        segs = await conn.fetch(
            """
            SELECT id, segment_index, body
            FROM riff_kg.signal_segments
            WHERE signal_id = $1
            ORDER BY segment_index ASC
            """,
            signal_id,
        )

        for seg in segs:
            seg_id = seg["id"]
            idx = seg["segment_index"]
            body = seg["body"] or ""
            if not body.strip():
                continue
            drafts = await extractor.extract_for_segment(
                segment_id=seg_id,
                segment_index=idx,
                body=body,
                signal_id=signal_id,
                scope_id=scope_id,
                source_system=source_system,
                source_ref=source_ref,
                cfg=cfg,
            )
            for d in drafts:
                validate_proposal_span(body, d.char_start, d.char_end)
                await conn.execute(
                    """
                    INSERT INTO riff_kg.staged_proposals (
                        extraction_run_id, segment_id, char_start, char_end,
                        proposal_kind, payload, status
                    )
                    VALUES ($1, $2, $3, $4, $5, $6::jsonb, 'pending_review')
                    """,
                    run_id,
                    seg_id,
                    d.char_start,
                    d.char_end,
                    d.proposal_kind,
                    json.dumps(d.payload),
                )

        await conn.execute(
            """
            UPDATE riff_kg.extraction_runs
            SET status = 'completed', completed_at = now()
            WHERE id = $1
            """,
            run_id,
        )
    except BaseException as e:
        msg = str(e)[:10_000]
        await conn.execute(
            """
            UPDATE riff_kg.extraction_runs
            SET status = 'failed', error_message = $2, completed_at = now()
            WHERE id = $1
            """,
            run_id,
            msg,
        )
        raise

    return run_id
