"""Pipeline orchestration (normalize -> segment -> embed -> extract): Phase 2+.

Phase 2 provides `run_phase_a` (segment + optional embed) on an existing signal row.
"""

from __future__ import annotations

import uuid

import asyncpg

from riff_kg.config import KgConfig
from riff_kg.embedder import Embedder


def describe_pipeline() -> list[str]:
    """Ordered stage names for introspection / kg_capabilities."""
    return [
        "normalize",
        "segment",
        "embed",
        "extract",
        "stage_proposals",
        "agent_review",
        "commit",
    ]


async def run_phase_a(
    conn: asyncpg.Connection,
    *,
    signal_id: uuid.UUID,
    normalized_text: str,
    cfg: KgConfig,
    embedder: Embedder | None = None,
) -> list[uuid.UUID]:
    """Replace segments for a signal from already-normalized text (Phase 2)."""
    from riff_kg.ingest import replace_segments_for_signal

    return await replace_segments_for_signal(
        conn,
        signal_id,
        normalized_text,
        cfg,
        embedder=embedder,
    )