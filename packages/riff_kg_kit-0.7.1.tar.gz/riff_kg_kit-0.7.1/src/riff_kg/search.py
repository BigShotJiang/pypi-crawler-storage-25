"""Retrieval: vector/FTS search, hybrid rerank, graph hops, context packing."""

from __future__ import annotations

import uuid
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

import asyncpg

from riff_kg.config import KgConfig
from riff_kg.ingest import vector_literal


@dataclass(frozen=True)
class SegmentHit:
    """One retrieved segment row with a relevance score."""

    segment_id: uuid.UUID
    signal_id: uuid.UUID
    scope_id: str | None
    segment_index: int
    body: str
    score: float
    method: Literal["vector", "fts", "hybrid"]


@dataclass(frozen=True)
class GraphEntityNode:
    """Entity node discovered in graph-hop traversal."""

    entity_id: uuid.UUID
    scope_id: str
    entity_type: str
    label: str
    depth: int


@dataclass(frozen=True)
class GraphRelationEdge:
    """Relation edge in graph-hop traversal."""

    relation_id: uuid.UUID
    scope_id: str
    relation_type: str
    src_entity_id: uuid.UUID
    dst_entity_id: uuid.UUID


def capabilities(cfg: KgConfig) -> dict[str, Any]:
    """Machine-readable surface for agents."""
    from riff_kg import __version__
    from riff_kg.pipeline import describe_pipeline

    return {
        "version": __version__,
        "pipeline": describe_pipeline(),
        "embedding_dimension": cfg.embedding_dimension,
        "chunking": cfg.effective_chunking(),
        "entity_types": list(cfg.entity_types),
        "relation_types": list(cfg.relation_types),
        "profile_uri": cfg.profile_uri,
        "search_modes": ["vector", "fts", "hybrid"],
        "hybrid_strategies": ["rrf", "weighted"],
        "graph_hop": True,
    }


def _validate_embedding(vec: list[float], cfg: KgConfig) -> None:
    if len(vec) != cfg.embedding_dimension:
        d = cfg.embedding_dimension
        raise ValueError(
            f"query embedding dim {len(vec)} != KgConfig.embedding_dimension {d}",
        )


async def search_segments_vector(
    conn: asyncpg.Connection,
    cfg: KgConfig,
    query_embedding: list[float],
    *,
    scope_id: str | None = None,
    limit: int = 10,
) -> list[SegmentHit]:
    """Order by cosine distance ascending; score = 1 - distance (higher is better)."""
    _validate_embedding(query_embedding, cfg)
    lim = max(1, min(limit, 500))
    vec = vector_literal(query_embedding)
    rows = await conn.fetch(
        """
        SELECT
            seg.id AS segment_id,
            seg.signal_id,
            s.scope_id,
            seg.segment_index,
            seg.body,
            1 - (seg.embedding <=> $1::vector) AS score
        FROM riff_kg.signal_segments seg
        INNER JOIN riff_kg.signals s ON s.id = seg.signal_id
        WHERE seg.embedding IS NOT NULL
          AND ($2::text IS NULL OR s.scope_id IS NOT DISTINCT FROM $2)
        ORDER BY seg.embedding <=> $1::vector
        LIMIT $3
        """,
        vec,
        scope_id,
        lim,
    )
    out: list[SegmentHit] = []
    for r in rows:
        out.append(
            SegmentHit(
                segment_id=r["segment_id"],
                signal_id=r["signal_id"],
                scope_id=r["scope_id"],
                segment_index=r["segment_index"],
                body=r["body"] or "",
                score=float(r["score"]),
                method="vector",
            ),
        )
    return out


async def search_segments_fts(
    conn: asyncpg.Connection,
    *,
    query_text: str,
    scope_id: str | None = None,
    limit: int = 10,
) -> list[SegmentHit]:
    """Full-text search on `body_tsv` using English config."""
    if not (query_text or "").strip():
        return []
    lim = max(1, min(limit, 500))
    q = query_text.strip()
    rows = await conn.fetch(
        """
        SELECT
            seg.id AS segment_id,
            seg.signal_id,
            s.scope_id,
            seg.segment_index,
            seg.body,
            ts_rank_cd(seg.body_tsv, plainto_tsquery('english', $1)) AS score
        FROM riff_kg.signal_segments seg
        INNER JOIN riff_kg.signals s ON s.id = seg.signal_id
        WHERE seg.body_tsv @@ plainto_tsquery('english', $1)
          AND ($2::text IS NULL OR s.scope_id IS NOT DISTINCT FROM $2)
        ORDER BY score DESC
        LIMIT $3
        """,
        q,
        scope_id,
        lim,
    )
    out: list[SegmentHit] = []
    for r in rows:
        out.append(
            SegmentHit(
                segment_id=r["segment_id"],
                signal_id=r["signal_id"],
                scope_id=r["scope_id"],
                segment_index=r["segment_index"],
                body=r["body"] or "",
                score=float(r["score"]),
                method="fts",
            ),
        )
    return out


async def search_segments_hybrid(
    conn: asyncpg.Connection,
    cfg: KgConfig,
    *,
    query_embedding: list[float] | None = None,
    fts_query: str | None = None,
    scope_id: str | None = None,
    limit: int = 10,
    strategy: Literal["rrf", "weighted"] = "rrf",
    vector_weight: float = 0.6,
    fts_weight: float = 0.4,
) -> list[SegmentHit]:
    """Run vector and/or FTS; rerank with rank-aware hybrid scoring."""
    if query_embedding is None and not (fts_query or "").strip():
        raise ValueError("provide query_embedding and/or fts_query")
    vector_hits: list[SegmentHit] = []
    fts_hits: list[SegmentHit] = []
    if query_embedding is not None:
        vector_hits = await search_segments_vector(
            conn,
            cfg,
            query_embedding,
            scope_id=scope_id,
            limit=limit,
        )
    if (fts_query or "").strip():
        fts_hits = await search_segments_fts(
            conn,
            query_text=fts_query or "",
            scope_id=scope_id,
            limit=limit,
        )
    return merge_segment_hits_hybrid(
        vector_hits,
        fts_hits,
        limit=limit,
        strategy=strategy,
        vector_weight=vector_weight,
        fts_weight=fts_weight,
    )


def merge_segment_hits_hybrid(
    vector_hits: Sequence[SegmentHit],
    fts_hits: Sequence[SegmentHit],
    *,
    limit: int = 10,
    strategy: Literal["rrf", "weighted"] = "rrf",
    vector_weight: float = 0.6,
    fts_weight: float = 0.4,
) -> list[SegmentHit]:
    """Merge two rank lists into one list with normalized hybrid scores."""
    lim = max(1, min(limit, 500))
    by_id: dict[uuid.UUID, SegmentHit] = {}
    vec_rank: dict[uuid.UUID, int] = {}
    fts_rank: dict[uuid.UUID, int] = {}
    for i, hit in enumerate(vector_hits):
        vec_rank[hit.segment_id] = i + 1
        by_id[hit.segment_id] = hit
    for i, hit in enumerate(fts_hits):
        fts_rank[hit.segment_id] = i + 1
        existing = by_id.get(hit.segment_id)
        if existing is None or hit.score > existing.score:
            by_id[hit.segment_id] = hit

    if strategy == "weighted":
        max_vec = max((h.score for h in vector_hits), default=1.0) or 1.0
        max_fts = max((h.score for h in fts_hits), default=1.0) or 1.0
        scored: list[tuple[float, SegmentHit]] = []
        for seg_id, base in by_id.items():
            vscore = 0.0
            fscore = 0.0
            if seg_id in vec_rank:
                vhit = next(h for h in vector_hits if h.segment_id == seg_id)
                vscore = max(vhit.score, 0.0) / max_vec
            if seg_id in fts_rank:
                fhit = next(h for h in fts_hits if h.segment_id == seg_id)
                fscore = max(fhit.score, 0.0) / max_fts
            hscore = (vector_weight * vscore) + (fts_weight * fscore)
            scored.append(
                (
                    hscore,
                    SegmentHit(
                        segment_id=base.segment_id,
                        signal_id=base.signal_id,
                        scope_id=base.scope_id,
                        segment_index=base.segment_index,
                        body=base.body,
                        score=hscore,
                        method="hybrid",
                    ),
                ),
            )
    else:
        # Reciprocal Rank Fusion avoids raw-score scale mismatch.
        k = 60.0
        scored = []
        for seg_id, base in by_id.items():
            rrf = 0.0
            if seg_id in vec_rank:
                rrf += vector_weight * (1.0 / (k + float(vec_rank[seg_id])))
            if seg_id in fts_rank:
                rrf += fts_weight * (1.0 / (k + float(fts_rank[seg_id])))
            scored.append(
                (
                    rrf,
                    SegmentHit(
                        segment_id=base.segment_id,
                        signal_id=base.signal_id,
                        scope_id=base.scope_id,
                        segment_index=base.segment_index,
                        body=base.body,
                        score=rrf,
                        method="hybrid",
                    ),
                ),
            )

    scored.sort(key=lambda item: item[0], reverse=True)
    return [hit for _, hit in scored[:lim]]


async def graph_hop_subgraph(
    conn: asyncpg.Connection,
    *,
    root_entity_id: uuid.UUID,
    max_hops: int = 1,
    scope_id: str | None = None,
    relation_types: Sequence[str] | None = None,
    limit_entities: int = 500,
) -> tuple[list[GraphEntityNode], list[GraphRelationEdge]]:
    """Return entities reachable from root up to `max_hops` and relations among them."""
    hops = max(0, min(max_hops, 6))
    rel_types = list(relation_types or [])
    rows = await conn.fetch(
        """
        WITH RECURSIVE walk(entity_id, depth) AS (
            SELECT e.id, 0
            FROM riff_kg.entities e
            WHERE e.id = $1
              AND ($2::text IS NULL OR e.scope_id IS NOT DISTINCT FROM $2)
            UNION
            SELECT
                CASE
                    WHEN r.src_entity_id = w.entity_id THEN r.dst_entity_id
                    ELSE r.src_entity_id
                END,
                w.depth + 1
            FROM walk w
            INNER JOIN riff_kg.relations r
                ON (r.src_entity_id = w.entity_id OR r.dst_entity_id = w.entity_id)
            WHERE w.depth < $3
              AND ($2::text IS NULL OR r.scope_id IS NOT DISTINCT FROM $2)
              AND (
                cardinality($4::text[]) = 0
                OR r.relation_type = ANY($4::text[])
              )
        )
        SELECT
            e.id AS entity_id,
            e.scope_id,
            e.entity_type,
            e.label,
            MIN(w.depth) AS depth
        FROM walk w
        INNER JOIN riff_kg.entities e ON e.id = w.entity_id
        GROUP BY e.id, e.scope_id, e.entity_type, e.label
        ORDER BY depth ASC, e.created_at DESC
        LIMIT $5
        """,
        root_entity_id,
        scope_id,
        hops,
        rel_types,
        max(1, min(limit_entities, 1000)),
    )
    entities = [
        GraphEntityNode(
            entity_id=r["entity_id"],
            scope_id=r["scope_id"],
            entity_type=r["entity_type"],
            label=r["label"],
            depth=int(r["depth"]),
        )
        for r in rows
    ]
    if not entities:
        return [], []
    entity_ids = [e.entity_id for e in entities]
    rel_rows = await conn.fetch(
        """
        SELECT
            r.id AS relation_id,
            r.scope_id,
            r.relation_type,
            r.src_entity_id,
            r.dst_entity_id
        FROM riff_kg.relations r
        WHERE r.src_entity_id = ANY($1::uuid[])
          AND r.dst_entity_id = ANY($1::uuid[])
          AND ($2::text IS NULL OR r.scope_id IS NOT DISTINCT FROM $2)
          AND (
            cardinality($3::text[]) = 0
            OR r.relation_type = ANY($3::text[])
          )
        ORDER BY r.committed_at DESC
        """,
        entity_ids,
        scope_id,
        rel_types,
    )
    relations = [
        GraphRelationEdge(
            relation_id=r["relation_id"],
            scope_id=r["scope_id"],
            relation_type=r["relation_type"],
            src_entity_id=r["src_entity_id"],
            dst_entity_id=r["dst_entity_id"],
        )
        for r in rel_rows
    ]
    return entities, relations


def pack_context(
    hits: Sequence[SegmentHit],
    *,
    max_chars: int = 8000,
    header: str = "## Retrieved segments\n",
) -> str:
    """Format hits as markdown-ish text for LLM consumption (truncated to `max_chars`)."""
    parts: list[str] = [header]
    used = len(header)
    for i, h in enumerate(hits, start=1):
        block = (
            f"### [{i}] segment={h.segment_id} signal={h.signal_id} "
            f"method={h.method} score={h.score:.4f}\n"
            f"{h.body}\n\n"
        )
        if used + len(block) > max_chars:
            parts.append(f"... truncated after {used} chars ...")
            break
        parts.append(block)
        used += len(block)
    return "".join(parts)
