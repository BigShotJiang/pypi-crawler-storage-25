﻿"""Shared Pydantic types for signals, segments, proposals (Phase 1+)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class SignalRef(BaseModel):
    """Pointer to a signal row; full schema arrives with migrations."""

    signal_id: str
    scope_id: str | None = None


class SegmentRef(BaseModel):
    segment_id: str
    signal_id: str
    index: int = Field(ge=0)
