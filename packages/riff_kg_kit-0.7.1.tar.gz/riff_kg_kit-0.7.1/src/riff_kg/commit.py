"""Phase 4: validate staged proposals and write canonical entities / relations."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any, Literal

import asyncpg

from riff_kg.config import KgConfig


def _payload_dict(raw: Any) -> dict[str, Any]:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        return json.loads(raw)
    raise TypeError("payload must be dict or json string")


def _require_str(d: dict[str, Any], key: str) -> str:
    v = d.get(key)
    if not isinstance(v, str) or not v.strip():
        raise ValueError(f"payload missing or invalid string field: {key!r}")
    return v.strip()


def _optional_str(d: dict[str, Any], key: str) -> str | None:
    v = d.get(key)
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip()
        return s or None
    raise ValueError(f"payload field {key!r} must be string or null")


def _optional_dict(d: dict[str, Any], key: str) -> dict[str, Any]:
    v = d.get(key)
    if v is None:
        return {}
    if isinstance(v, dict):
        return v
    raise ValueError(f"payload field {key!r} must be object")


def _parse_uuid(s: str) -> uuid.UUID:
    try:
        return uuid.UUID(str(s).strip())
    except ValueError as e:
        raise ValueError(f"invalid uuid: {s!r}") from e


@dataclass(frozen=True)
class CommitResult:
    """One committed staged proposal."""

    proposal_id: uuid.UUID
    record_kind: Literal["entity", "relation"]
    record_id: uuid.UUID


@dataclass(frozen=True)
class CommitSummary:
    """Batch outcome for `commit_proposals`."""

    committed: tuple[CommitResult, ...]
    skipped_already_approved: tuple[uuid.UUID, ...]


async def commit_proposals(
    conn: asyncpg.Connection,
    cfg: KgConfig,
    proposal_ids: list[uuid.UUID],
    *,
    committed_by: str | None = None,
) -> CommitSummary:
    """Commit pending proposals: entities first, then relations. Idempotent: skips `approved`."""
    if not proposal_ids:
        return CommitSummary(committed=(), skipped_already_approved=())

    uniq = list(dict.fromkeys(proposal_ids))
    rows = await conn.fetch(
        """
        SELECT sp.id, sp.proposal_kind, sp.payload, sp.segment_id, sp.char_start, sp.char_end,
               sp.status AS proposal_status, s.scope_id, sp.extraction_run_id
        FROM riff_kg.staged_proposals sp
        JOIN riff_kg.signal_segments seg ON seg.id = sp.segment_id
        JOIN riff_kg.signals s ON s.id = seg.signal_id
        WHERE sp.id = ANY($1::uuid[])
        """,
        uniq,
    )
    by_id = {r["id"]: r for r in rows}
    missing = [pid for pid in uniq if pid not in by_id]
    if missing:
        raise ValueError(f"unknown or inaccessible proposal ids: {missing}")

    sorted_rows = sorted(
        rows,
        key=lambda r: (0 if str(r["proposal_kind"]).strip() == "entity" else 1, str(r["id"])),
    )

    committed: list[CommitResult] = []
    skipped: list[uuid.UUID] = []

    async with conn.transaction():
        for row in sorted_rows:
            pid: uuid.UUID = row["id"]
            st = row["proposal_status"]
            if st == "approved":
                skipped.append(pid)
                continue
            if st != "pending_review":
                raise ValueError(f"proposal {pid} is not pending_review ({st})")

            scope_raw = row["scope_id"]
            scope_id = scope_raw if isinstance(scope_raw, str) else str(scope_raw or "")
            pk = row["proposal_kind"]
            kind = str(pk).strip() if pk is not None else ""
            if not kind:
                raise ValueError(f"proposal {pid} has empty proposal_kind")
            payload = _payload_dict(row["payload"])

            if kind == "entity":
                entity_type = _require_str(payload, "entity_type")
                if entity_type not in cfg.entity_types:
                    raise ValueError(f"entity_type {entity_type!r} not allowed by KgConfig")
                label = _require_str(payload, "label")
                can_key = _optional_str(payload, "canonical_key")
                attrs = json.dumps(_optional_dict(payload, "attrs"))

                if can_key:
                    existing = await conn.fetchrow(
                        """
                        SELECT id FROM riff_kg.entities
                        WHERE scope_id = $1 AND entity_type = $2 AND canonical_key = $3
                        """,
                        scope_id,
                        entity_type,
                        can_key,
                    )
                    if existing:
                        eid = existing["id"]
                        await conn.execute(
                            """
                            UPDATE riff_kg.entities
                            SET label = $1, attrs = attrs || $2::jsonb
                            WHERE id = $3
                            """,
                            label,
                            attrs,
                            eid,
                        )
                    else:
                        eid = await conn.fetchval(
                            """
                            INSERT INTO riff_kg.entities (
                                scope_id, entity_type, label, canonical_key, attrs
                            )
                            VALUES ($1, $2, $3, $4, $5::jsonb)
                            RETURNING id
                            """,
                            scope_id,
                            entity_type,
                            label,
                            can_key,
                            attrs,
                        )
                else:
                    eid = await conn.fetchval(
                        """
                        INSERT INTO riff_kg.entities (
                            scope_id, entity_type, label, canonical_key, attrs
                        )
                        VALUES ($1, $2, $3, NULL, $4::jsonb)
                        RETURNING id
                        """,
                        scope_id,
                        entity_type,
                        label,
                        attrs,
                    )

                await conn.execute(
                    """
                    UPDATE riff_kg.staged_proposals
                    SET status = 'approved', resolution_note = NULL
                    WHERE id = $1
                    """,
                    pid,
                )
                committed.append(CommitResult(pid, "entity", eid))

            elif kind == "relation":
                rel_type = _require_str(payload, "relation_type")
                if rel_type not in cfg.relation_types:
                    raise ValueError(f"relation_type {rel_type!r} not allowed by KgConfig")
                src = _parse_uuid(_require_str(payload, "src_entity_id"))
                dst = _parse_uuid(_require_str(payload, "dst_entity_id"))
                rattrs = json.dumps(_optional_dict(payload, "attrs"))

                rid = await conn.fetchval(
                    """
                    INSERT INTO riff_kg.relations (
                        scope_id, src_entity_id, dst_entity_id, relation_type, attrs,
                        evidence_segment_id, evidence_char_start, evidence_char_end,
                        staged_proposal_id, extraction_run_id, committed_by
                    )
                    VALUES (
                        $1, $2, $3, $4, $5::jsonb,
                        $6, $7, $8, $9, $10, $11
                    )
                    RETURNING id
                    """,
                    scope_id,
                    src,
                    dst,
                    rel_type,
                    rattrs,
                    row["segment_id"],
                    row["char_start"],
                    row["char_end"],
                    pid,
                    row["extraction_run_id"],
                    committed_by,
                )

                await conn.execute(
                    """
                    UPDATE riff_kg.staged_proposals SET status = 'approved', resolution_note = NULL
                    WHERE id = $1
                    """,
                    pid,
                )
                committed.append(CommitResult(pid, "relation", rid))
            else:
                raise ValueError(f"unsupported proposal_kind for commit: {kind!r}")

    return CommitSummary(
        committed=tuple(committed),
        skipped_already_approved=tuple(skipped),
    )


async def reject_proposals(
    conn: asyncpg.Connection,
    proposal_ids: list[uuid.UUID],
    *,
    reason: str,
) -> int:
    """Mark pending proposals rejected; returns number of rows updated."""
    if not proposal_ids:
        return 0
    status = await conn.execute(
        """
        UPDATE riff_kg.staged_proposals
        SET status = 'rejected', resolution_note = $2
        WHERE id = ANY($1::uuid[]) AND status = 'pending_review'
        """,
        list(dict.fromkeys(proposal_ids)),
        reason[:10_000],
    )
    # asyncpg returns "UPDATE N"
    prefix = "UPDATE "
    if status.startswith(prefix):
        return int(status.split()[-1])
    return 0
