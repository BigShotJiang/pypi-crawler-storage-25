from riff_kg import KgConfig, __version__
from riff_kg.search import capabilities


def test_kg_config_json_roundtrip() -> None:
    raw = '{"embedding_dimension": 768, "entity_types": ["Company", "Person"]}'
    cfg = KgConfig.model_validate_json(raw)
    assert cfg.embedding_dimension == 768
    assert cfg.entity_types == ("Company", "Person")


def test_capabilities_includes_pipeline() -> None:
    cfg = KgConfig()
    caps = capabilities(cfg)
    assert caps["embedding_dimension"] == 768
    assert "normalize" in caps["pipeline"]
    assert caps["relation_types"] == ["related_to"]
    assert caps["version"] == __version__