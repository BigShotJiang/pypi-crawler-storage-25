"""Phase 4 commit and reject (optional DB)."""

from __future__ import annotations

import os
import uuid

import pytest

from riff_kg import KgConfig
from riff_kg.commit import commit_proposals, reject_proposals
from riff_kg.embedder import Embedder
from riff_kg.extract import ProposalDraft, run_extraction_for_signal


class _Emb(Embedder):
    async def embed_texts(self, texts: list[str]) -> list[list[float]]:  # noqa: ARG002
        return [[0.0] * 768 for _ in texts]


class _ExEnt:
    async def extract_for_segment(self, **kwargs):  # noqa: ANN003
        body = kwargs["body"]
        return [
            ProposalDraft(
                "entity",
                {
                    "entity_type": "Entity",
                    "label": "alpha",
                    "canonical_key": "a",
                },
                char_start=0,
                char_end=min(5, len(body)),
            ),
            ProposalDraft(
                "entity",
                {
                    "entity_type": "Entity",
                    "label": "beta",
                    "canonical_key": "b",
                },
                char_start=0,
                char_end=min(5, len(body)),
            ),
        ]


class _ExRel:
    def __init__(self, src: uuid.UUID, dst: uuid.UUID) -> None:
        self._src = src
        self._dst = dst
        self._done = False

    async def extract_for_segment(self, **kwargs):  # noqa: ANN003
        if self._done:
            return []
        self._done = True
        return [
            ProposalDraft(
                "relation",
                {
                    "relation_type": "related_to",
                    "src_entity_id": str(self._src),
                    "dst_entity_id": str(self._dst),
                },
            ),
        ]


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_commit_entities_then_relation_end_to_end() -> None:
    import asyncpg

    from riff_kg.ingest import ingest_new_signal
    from riff_kg.migrate import apply_migrations

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    cfg = KgConfig()
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        sid = await ingest_new_signal(
            conn,
            scope_id="commit_e2e",
            source_system="t",
            source_ref={},
            raw_text="hello commit integration test body",
            cfg=cfg,
            embedder=_Emb(),
        )
        run_id = await run_extraction_for_signal(conn, sid, cfg, _ExEnt())
        pids = [
            r["id"]
            for r in await conn.fetch(
                "select id from riff_kg.staged_proposals where extraction_run_id = $1 order by id",
                run_id,
            )
        ]
        assert len(pids) == 2
        summary = await commit_proposals(conn, cfg, pids, committed_by="test")
        assert len(summary.committed) == 2
        n_ent = await conn.fetchval(
            "select count(*)::int from riff_kg.entities where scope_id = $1",
            "commit_e2e",
        )
        assert n_ent == 2

        rows = await conn.fetch(
            """
            select id from riff_kg.entities
            where scope_id = $1 and canonical_key in ('a','b') order by canonical_key
            """,
            "commit_e2e",
        )
        assert len(rows) == 2
        src_id, dst_id = rows[0]["id"], rows[1]["id"]

        await run_extraction_for_signal(conn, sid, cfg, _ExRel(src_id, dst_id))
        rel_pid = await conn.fetchval(
            """
            select id from riff_kg.staged_proposals
            where proposal_kind = 'relation' and status = 'pending_review'
            order by created_at desc limit 1
            """,
        )
        assert rel_pid is not None
        s2 = await commit_proposals(conn, cfg, [rel_pid], committed_by="test")
        assert len(s2.committed) == 1 and s2.committed[0].record_kind == "relation"

        n_rel = await conn.fetchval(
            "select count(*)::int from riff_kg.relations where scope_id = $1",
            "commit_e2e",
        )
        assert n_rel == 1
    finally:
        await conn.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_reject_proposals() -> None:
    import asyncpg

    from riff_kg.ingest import ingest_new_signal
    from riff_kg.migrate import apply_migrations

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    cfg = KgConfig()
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        sid = await ingest_new_signal(
            conn,
            scope_id="reject_t",
            source_system="t",
            source_ref={},
            raw_text="x",
            cfg=cfg,
            embedder=_Emb(),
        )
        run_id = await run_extraction_for_signal(conn, sid, cfg, _ExEnt())
        pid = await conn.fetchval(
            "select id from riff_kg.staged_proposals where extraction_run_id = $1 limit 1",
            run_id,
        )
        n = await reject_proposals(conn, [pid], reason="no thanks")
        assert n == 1
        st = await conn.fetchval(
            "select status::text from riff_kg.staged_proposals where id = $1",
            pid,
        )
        assert st == "rejected"
    finally:
        await conn.close()
