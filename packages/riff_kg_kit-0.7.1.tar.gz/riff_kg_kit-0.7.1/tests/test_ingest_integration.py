"""Optional integration test against a real Postgres (Neon). Set RIFF_KG_DATABASE_URL."""

from __future__ import annotations

import os
import uuid

import asyncpg
import pytest

from riff_kg import KgConfig
from riff_kg.embedder import Embedder
from riff_kg.ingest import ingest_new_signal
from riff_kg.migrate import apply_migrations

pytestmark = pytest.mark.asyncio


class FakeEmbedder:
    def __init__(self, dim: int = 768) -> None:
        self.dim = dim

    async def embed_texts(self, texts: list[str]) -> list[list[float]]:  # noqa: ARG002
        return [[0.01 * (i + 1)] * self.dim for i in range(len(texts))]


def _dsn() -> str | None:
    return os.environ.get("RIFF_KG_DATABASE_URL")


@pytest.mark.skipif(not _dsn(), reason="RIFF_KG_DATABASE_URL not set")
async def test_ingest_new_signal_writes_segments_and_embeddings() -> None:
    dsn = _dsn()
    assert dsn is not None
    cfg = KgConfig(embedding_dimension=768)
    emb: Embedder = FakeEmbedder(dim=768)
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        sid = await ingest_new_signal(
            conn,
            scope_id="scope_it",
            source_system="test",
            source_ref={"k": "v"},
            raw_text="short text for integration " * 5,
            cfg=cfg,
            embedder=emb,
            embedding_meta={"model": "fake"},
        )
        assert isinstance(sid, uuid.UUID)
        n = await conn.fetchval(
            "select count(*)::int from riff_kg.signal_segments where signal_id = $1",
            sid,
        )
        assert n and n >= 1
        emb_n = await conn.fetchval(
            (
                "select count(*)::int from riff_kg.signal_segments "
                "where signal_id = $1 and embedding is not null"
            ),
            sid,
        )
        assert emb_n == n
    finally:
        await conn.close()