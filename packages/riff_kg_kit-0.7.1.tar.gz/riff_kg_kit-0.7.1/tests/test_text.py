"""Tests for normalize + segment helpers."""

from riff_kg.config import KgConfig
from riff_kg.text import TextSegmentPiece, normalize_text, segment_text


def test_normalize_collapses_whitespace() -> None:
    s = normalize_text("  hello   world  \r\n\r\n\n\nfoo  ")
    assert "hello world" in s
    assert "foo" in s


def test_segment_single_under_threshold() -> None:
    cfg = KgConfig(chunk_if_longer_than_chars=5000, chunk_max_chars=8000, chunk_overlap_chars=400)
    segs = segment_text("a" * 30, cfg)
    assert len(segs) == 1
    assert segs[0] == TextSegmentPiece(0, 30, "a" * 30)


def test_segment_multi_long_text() -> None:
    cfg = KgConfig(
        chunk_if_longer_than_chars=1000,
        chunk_max_chars=500,
        chunk_overlap_chars=50,
    )
    text = "x" * 2500
    segs = segment_text(text, cfg)
    assert len(segs) >= 2
    assert segs[0].char_offset_start == 0
    assert segs[-1].char_offset_end == 2500


def test_empty_yields_one_zero_length_piece() -> None:
    cfg = KgConfig()
    segs = segment_text("", cfg)
    assert len(segs) == 1
    assert segs[0].body == ""