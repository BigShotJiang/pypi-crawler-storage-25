from importlib import resources

from riff_kg.migrate import _load_sql, _split_sql
from riff_kg.migrations import MIGRATION_STEMS


def test_migration_stems_order() -> None:
    assert MIGRATION_STEMS[0].startswith("001")
    assert MIGRATION_STEMS[-1].startswith("004")


def test_each_migration_file_is_readable() -> None:
    root = resources.files("riff_kg.migrations")
    for stem in MIGRATION_STEMS:
        p = root.joinpath(f"{stem}.sql")
        assert p.is_file(), stem
        text = p.read_text(encoding="utf-8")
        assert "CREATE" in text.upper()


def test_split_sql_non_empty() -> None:
    sql = _load_sql("001_extensions")
    stmts = _split_sql(sql)
    assert len(stmts) >= 1
    assert all(s.endswith(";") for s in stmts)