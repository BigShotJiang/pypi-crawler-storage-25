"""Phase 3 extraction helpers and optional DB coverage."""

import pytest

from riff_kg import KgConfig
from riff_kg.extract import ProposalDraft, run_extraction_for_signal, validate_proposal_span


def test_validate_proposal_span_accepts_none() -> None:
    validate_proposal_span("abc", None, None)


def test_validate_proposal_span_rejects_partial() -> None:
    with pytest.raises(ValueError, match="both"):
        validate_proposal_span("abc", 0, None)


def test_validate_proposal_span_bounds() -> None:
    validate_proposal_span("hello", 0, 5)
    with pytest.raises(ValueError):
        validate_proposal_span("hi", 0, 3)


def test_proposal_draft_rejects_blank_kind() -> None:
    with pytest.raises(ValueError):
        ProposalDraft("   ", {})


class _StubEx:
    async def extract_for_segment(self, **kwargs):  # noqa: ANN003, ARG002
        body = kwargs["body"]
        return [
            ProposalDraft(
            "entity",
            {
                "entity_type": "Entity",
                "label": "stub",
                "canonical_key": "stub-ck",
            },
            char_start=0,
            char_end=len(body),
        ),
        ]


@pytest.mark.asyncio
@pytest.mark.skipif(
    not __import__("os").environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_run_extraction_after_ingest_inserts_staged_rows() -> None:
    import os

    import asyncpg

    from riff_kg.embedder import Embedder
    from riff_kg.ingest import ingest_new_signal
    from riff_kg.migrate import apply_migrations

    class NoEmb(Embedder):
        async def embed_texts(self, texts: list[str]) -> list[list[float]]:  # noqa: ARG002
            return [[0.0] * 768 for _ in texts]

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    cfg = KgConfig()
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        sid = await ingest_new_signal(
            conn,
            scope_id="ex_test",
            source_system="t",
            source_ref={},
            raw_text="hello extraction world",
            cfg=cfg,
            embedder=NoEmb(),
        )
        run_id = await run_extraction_for_signal(conn, sid, cfg, _StubEx())
        n = await conn.fetchval(
            "select count(*)::int from riff_kg.staged_proposals where extraction_run_id = $1",
            run_id,
        )
        assert n == 1
        st = await conn.fetchval(
            "select status::text from riff_kg.extraction_runs where id = $1",
            run_id,
        )
        assert st == "completed"
    finally:
        await conn.close()


class _FailOnSecondSegment:
    async def extract_for_segment(self, **kwargs):  # noqa: ANN003, ARG002
        idx = int(kwargs["segment_index"])
        body = kwargs["body"]
        if idx >= 1:
            raise RuntimeError("simulated_llm_timeout")
        return [
            ProposalDraft(
                "entity",
                {
                    "entity_type": "Entity",
                    "label": f"seg-{idx}",
                    "canonical_key": f"seg-{idx}",
                },
                char_start=0,
                char_end=len(body),
            ),
        ]


@pytest.mark.asyncio
@pytest.mark.skipif(
    not __import__("os").environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_run_extraction_keeps_proposals_after_mid_run_failure() -> None:
    """Later-segment failures must not roll back proposals from earlier segments."""
    import os

    import asyncpg

    from riff_kg.embedder import Embedder
    from riff_kg.ingest import ingest_new_signal
    from riff_kg.migrate import apply_migrations

    class NoEmb(Embedder):
        async def embed_texts(self, texts: list[str]) -> list[list[float]]:  # noqa: ARG002
            return [[0.0] * 768 for _ in texts]

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    cfg = KgConfig()
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        long_text = ("word " * 2500) + "\n\n" + ("other " * 2500)
        sid = await ingest_new_signal(
            conn,
            scope_id="ex_partial",
            source_system="t",
            source_ref={},
            raw_text=long_text,
            cfg=cfg,
            embedder=NoEmb(),
        )
        n_segs = await conn.fetchval(
            "select count(*)::int from riff_kg.signal_segments where signal_id = $1",
            sid,
        )
        assert n_segs >= 2

        with pytest.raises(RuntimeError, match="simulated_llm_timeout"):
            await run_extraction_for_signal(conn, sid, cfg, _FailOnSecondSegment())

        run_id = await conn.fetchval(
            "select id from riff_kg.extraction_runs "
            "where signal_id = $1 order by created_at desc limit 1",
            sid,
        )
        n_prop = await conn.fetchval(
            "select count(*)::int from riff_kg.staged_proposals where extraction_run_id = $1",
            run_id,
        )
        assert n_prop >= 1
        st = await conn.fetchval(
            "select status::text from riff_kg.extraction_runs where id = $1",
            run_id,
        )
        assert st == "failed"
        err = await conn.fetchval(
            "select error_message from riff_kg.extraction_runs where id = $1",
            run_id,
        )
        assert err and "simulated_llm_timeout" in err
    finally:
        await conn.close()