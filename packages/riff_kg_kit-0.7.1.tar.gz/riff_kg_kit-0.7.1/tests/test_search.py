"""Phase 5 search and pack_context (unit + optional DB)."""

from __future__ import annotations

import os
import uuid

import pytest

from riff_kg import KgConfig
from riff_kg.embedder import Embedder
from riff_kg.ingest import ingest_new_signal
from riff_kg.migrate import apply_migrations
from riff_kg.search import (
    GraphEntityNode,
    GraphRelationEdge,
    SegmentHit,
    graph_hop_subgraph,
    merge_segment_hits_hybrid,
    pack_context,
    search_segments_fts,
    search_segments_hybrid,
    search_segments_vector,
)


def test_pack_context_formats_and_truncates() -> None:
    sid = uuid.uuid4()
    sig = uuid.uuid4()
    hits = [
        SegmentHit(sid, sig, "s", 0, "alpha body", 0.9, "vector"),
        SegmentHit(uuid.uuid4(), sig, "s", 1, "beta", 0.5, "fts"),
    ]
    out = pack_context(hits, max_chars=500)
    assert "## Retrieved segments" in out
    assert "alpha body" in out
    assert "segment=" in out


@pytest.mark.asyncio
async def test_vector_search_rejects_wrong_embedding_length() -> None:
    cfg = KgConfig(embedding_dimension=768)
    with pytest.raises(ValueError, match="embedding_dimension"):
        await search_segments_vector(None, cfg, [0.0] * 10)  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_hybrid_requires_at_least_one_query() -> None:
    cfg = KgConfig()
    with pytest.raises(ValueError, match="query_embedding"):
        await search_segments_hybrid(None, cfg)  # type: ignore[arg-type]


def test_merge_segment_hits_hybrid_rrf_prefers_overlap() -> None:
    sig = uuid.uuid4()
    shared = uuid.uuid4()
    only_vec = uuid.uuid4()
    only_fts = uuid.uuid4()
    vec_hits = [
        SegmentHit(shared, sig, "s", 0, "shared", 0.9, "vector"),
        SegmentHit(only_vec, sig, "s", 1, "vec", 0.8, "vector"),
    ]
    fts_hits = [
        SegmentHit(shared, sig, "s", 0, "shared", 0.2, "fts"),
        SegmentHit(only_fts, sig, "s", 2, "fts", 0.1, "fts"),
    ]
    merged = merge_segment_hits_hybrid(vec_hits, fts_hits, strategy="rrf", limit=3)
    assert merged[0].segment_id == shared
    assert merged[0].method == "hybrid"


class _ConstEmb(Embedder):
    def __init__(self, vec: list[float]) -> None:
        self._vec = vec

    async def embed_texts(self, texts: list[str]) -> list[list[float]]:  # noqa: ARG002
        return [list(self._vec) for _ in texts]


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_vector_and_fts_search_against_db() -> None:
    import asyncpg

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    cfg = KgConfig(embedding_dimension=768)
    qvec = [0.02] * 768
    emb = _ConstEmb(qvec)
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        scope = "search_e2e"
        sid = await ingest_new_signal(
            conn,
            scope_id=scope,
            source_system="t",
            source_ref={},
            raw_text="The quantum particle accelerator runs overnight for calibration.",
            cfg=cfg,
            embedder=emb,
        )
        vhits = await search_segments_vector(conn, cfg, qvec, scope_id=scope, limit=5)
        assert len(vhits) >= 1
        assert vhits[0].signal_id == sid
        assert "quantum" in vhits[0].body.lower()

        fts = await search_segments_fts(
            conn,
            query_text="quantum",
            scope_id=scope,
            limit=5,
        )
        assert len(fts) >= 1
        assert fts[0].signal_id == sid

        hy = await search_segments_hybrid(
            conn,
            cfg,
            query_embedding=qvec,
            fts_query="calibration",
            scope_id=scope,
            limit=10,
        )
        assert any(h.signal_id == sid for h in hy)
    finally:
        await conn.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.environ.get("RIFF_KG_DATABASE_URL"),
    reason="RIFF_KG_DATABASE_URL not set",
)
async def test_graph_hop_subgraph_shape() -> None:
    import asyncpg

    dsn = os.environ["RIFF_KG_DATABASE_URL"]
    conn = await asyncpg.connect(dsn)
    try:
        await apply_migrations(conn)
        scope = "graph_hop_smoke"
        a = await conn.fetchval(
            """
            INSERT INTO riff_kg.entities (scope_id, entity_type, label, canonical_key)
            VALUES ($1, 'Entity', 'A', 'A') RETURNING id
            """,
            scope,
        )
        b = await conn.fetchval(
            """
            INSERT INTO riff_kg.entities (scope_id, entity_type, label, canonical_key)
            VALUES ($1, 'Entity', 'B', 'B') RETURNING id
            """,
            scope,
        )
        seg = await conn.fetchval(
            """
            INSERT INTO riff_kg.signals (scope_id, source_system, source_ref)
            VALUES ($1, 't', '{}'::jsonb) RETURNING id
            """,
            scope,
        )
        seg_id = await conn.fetchval(
            """
            INSERT INTO riff_kg.signal_segments (signal_id, segment_index, char_offset_end, body)
            VALUES ($1, 0, 4, 'evid') RETURNING id
            """,
            seg,
        )
        await conn.execute(
            """
            INSERT INTO riff_kg.relations (
                scope_id, src_entity_id, dst_entity_id, relation_type, evidence_segment_id
            ) VALUES ($1, $2, $3, 'related_to', $4)
            """,
            scope,
            a,
            b,
            seg_id,
        )
        nodes, edges = await graph_hop_subgraph(
            conn,
            root_entity_id=a,
            max_hops=1,
            scope_id=scope,
        )
        assert any(isinstance(n, GraphEntityNode) for n in nodes)
        assert any(n.entity_id == a for n in nodes)
        assert any(n.entity_id == b for n in nodes)
        assert any(isinstance(e, GraphRelationEdge) for e in edges)
    finally:
        await conn.close()
