# Changelog

## 0.7.1

- `run_extraction_for_signal` no longer wraps the whole run in one transaction: staged proposals commit incrementally (when the connection is in autocommit), so timeouts or crashes after some segments still leave earlier proposals in the database. On failure, the extraction run is marked `failed` with `error_message`.

## 0.7.0

- Hybrid retrieval improvements: `search_segments_hybrid` now supports `rrf` and `weighted` strategies via `merge_segment_hits_hybrid`.
- Graph-hop retrieval: added `graph_hop_subgraph` with `GraphEntityNode` and `GraphRelationEdge`.
- Docs: added publishing checklist and retrieval examples.

## 0.6.0 and earlier

- Phases 0–4: package skeleton, migrations, ingest, extract, commit/reject, and docs.
