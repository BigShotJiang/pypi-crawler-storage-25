from __future__ import annotations

from dataclasses import dataclass, field

from py_engine.engine_bridge import EngineBridge


@dataclass
class MediaManager:
    engine: EngineBridge
    images: dict[str, int] = field(default_factory=dict)
    audio: dict[str, int] = field(default_factory=dict)
    videos: dict[str, int] = field(default_factory=dict)
    fonts: dict[tuple[str, int], int] = field(default_factory=dict)

    def load_image(self, path: str) -> int:
        if path not in self.images:
            self.images[path] = self.engine.load_image(path)
        return self.images[path]

    def load_audio(self, path: str) -> int:
        if path not in self.audio:
            self.audio[path] = self.engine.load_audio(path)
        return self.audio[path]

    def load_video(self, path: str) -> int:
        if path not in self.videos:
            self.videos[path] = self.engine.load_video(path)
        return self.videos[path]

    def load_font(self, path: str, size: int) -> int:
        key = (path, size)
        if key not in self.fonts:
            self.fonts[key] = self.engine.load_font(path, size)
        return self.fonts[key]
