from __future__ import annotations

from py_engine.application import Application


def run_htmlpy_app(
    html_path: str = "main.htmlpy", css_path: str = "main.csspy", logic_path: str | None = "main_logic.py"
) -> None:
    app = Application()
    app.load_html(html_path)
    app.load_css(css_path)
    if logic_path:
        app.load_logic(logic_path)
    app.run()
