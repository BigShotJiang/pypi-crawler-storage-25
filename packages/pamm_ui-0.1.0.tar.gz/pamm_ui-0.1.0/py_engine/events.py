from __future__ import annotations

from dataclasses import dataclass


@dataclass
class InputEvent:
    mouse_x: int
    mouse_y: int
    mouse_clicked: bool
    mouse_down: bool


class EventManager:
    def dispatch(self, app: "Application", event: InputEvent) -> None:
        hovered = None
        clickable = [element for element in app.iter_elements() if element.is_clickable]
        for element in clickable:
            if element.hit_test(event.mouse_x, event.mouse_y):
                hovered = element

        app.hovered_element = hovered

        if event.mouse_clicked and hovered and hovered.on_click:
            app.call_handler(hovered.on_click, hovered)
