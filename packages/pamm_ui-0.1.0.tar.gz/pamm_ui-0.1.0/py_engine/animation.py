from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Animation:
    target: object
    property_name: str
    start_value: float
    end_value: float
    duration: float
    elapsed: float = 0.0


@dataclass
class AnimationManager:
    animations: list[Animation] = field(default_factory=list)

    def add(self, target: object, property_name: str, start_value: float, end_value: float, duration: float) -> None:
        self.animations.append(Animation(target, property_name, start_value, end_value, max(duration, 0.0001)))

    def update(self, delta_time: float) -> None:
        remaining: list[Animation] = []
        for animation in self.animations:
            animation.elapsed += delta_time
            t = min(animation.elapsed / animation.duration, 1.0)
            value = animation.start_value + (animation.end_value - animation.start_value) * t
            setattr(animation.target, animation.property_name, value)
            if t < 1.0:
                remaining.append(animation)
        self.animations = remaining
