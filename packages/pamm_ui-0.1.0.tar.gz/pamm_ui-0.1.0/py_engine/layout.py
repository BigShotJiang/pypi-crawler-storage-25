from __future__ import annotations

from py_engine.style import parse_size


class LayoutManager:
    def layout_children(self, parent: "UIElement") -> None:
        display = parent.style.get("display", "").lower()
        if display not in {"flex", "stack"}:
            return

        gap = parse_size(parent.style.get("gap"), 16)
        cursor_x = parent.abs_x + parse_size(parent.style.get("padding-left", parent.style.get("padding")), 0)
        cursor_y = parent.abs_y + parse_size(parent.style.get("padding-top", parent.style.get("padding")), 0)
        direction = parent.style.get("flex-direction", "column").lower()

        for child in parent.children:
            if "x" not in child.attrs:
                child.x = cursor_x - parent.abs_x
            if "y" not in child.attrs:
                child.y = cursor_y - parent.abs_y

            if direction == "row":
                cursor_x += child.width + gap
            else:
                cursor_y += child.height + gap
