#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(__has_include)
#if __has_include(<SDL2/SDL.h>)
#include <SDL2/SDL.h>
#define ENGINE_HAS_SDL 1
#elif __has_include(<SDL.h>)
#include <SDL.h>
#define ENGINE_HAS_SDL 1
#else
#define ENGINE_HAS_SDL 0
#endif
#else
#define ENGINE_HAS_SDL 0
#endif

#if ENGINE_HAS_SDL && defined(__has_include)
#if __has_include(<SDL2/SDL_image.h>)
#include <SDL2/SDL_image.h>
#define ENGINE_HAS_SDL_IMAGE 1
#elif __has_include(<SDL_image.h>)
#include <SDL_image.h>
#define ENGINE_HAS_SDL_IMAGE 1
#else
#define ENGINE_HAS_SDL_IMAGE 0
#endif

#if __has_include(<SDL2/SDL_ttf.h>)
#include <SDL2/SDL_ttf.h>
#define ENGINE_HAS_SDL_TTF 1
#elif __has_include(<SDL_ttf.h>)
#include <SDL_ttf.h>
#define ENGINE_HAS_SDL_TTF 1
#else
#define ENGINE_HAS_SDL_TTF 0
#endif

#if __has_include(<SDL2/SDL_mixer.h>)
#include <SDL2/SDL_mixer.h>
#define ENGINE_HAS_SDL_MIXER 1
#elif __has_include(<SDL_mixer.h>)
#include <SDL_mixer.h>
#define ENGINE_HAS_SDL_MIXER 1
#else
#define ENGINE_HAS_SDL_MIXER 0
#endif

#if __has_include(<libavformat/avformat.h>) && __has_include(<libavcodec/avcodec.h>) && __has_include(<libswscale/swscale.h>) && __has_include(<libavutil/imgutils.h>)
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
#define ENGINE_HAS_FFMPEG 1
#else
#define ENGINE_HAS_FFMPEG 0
#endif
#else
#define ENGINE_HAS_SDL_IMAGE 0
#define ENGINE_HAS_SDL_TTF 0
#define ENGINE_HAS_SDL_MIXER 0
#define ENGINE_HAS_FFMPEG 0
#endif

#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#define ENGINE_MAX_WINDOWS 16
#define ENGINE_MAX_LAYERS 32
#define ENGINE_MAX_COMMANDS 4096
#define ENGINE_MAX_ANIMATIONS 256
#define ENGINE_MAX_AUDIO 128
#define ENGINE_MAX_VIDEO 128
#define ENGINE_MAX_IMAGES 256
#define ENGINE_MAX_FONTS 64
#define ENGINE_MAX_TEXT 256
#define ENGINE_MAX_TITLE 128
#define ENGINE_MAX_SCREENS 16
#define ENGINE_KEY_COUNT 512
#define ENGINE_MOUSE_BUTTONS 8

typedef struct EngineColor {
    unsigned char r;
    unsigned char g;
    unsigned char b;
    unsigned char a;
} EngineColor;

typedef enum DrawCommandType {
    DRAW_COMMAND_NONE = 0,
    DRAW_COMMAND_PIXEL,
    DRAW_COMMAND_RECT,
    DRAW_COMMAND_ROUNDED_RECT,
    DRAW_COMMAND_CIRCLE,
    DRAW_COMMAND_GRADIENT_RECT,
    DRAW_COMMAND_LINE,
    DRAW_COMMAND_TEXT,
    DRAW_COMMAND_IMAGE,
    DRAW_COMMAND_VIDEO
} DrawCommandType;

typedef enum AnimationProperty {
    ANIM_PROPERTY_X = 0,
    ANIM_PROPERTY_Y,
    ANIM_PROPERTY_WIDTH,
    ANIM_PROPERTY_HEIGHT,
    ANIM_PROPERTY_OPACITY
} AnimationProperty;

typedef enum AnimationTargetType {
    ANIM_TARGET_WINDOW = 0,
    ANIM_TARGET_LAYER
} AnimationTargetType;

typedef struct DrawCommand {
    DrawCommandType type;
    int layer_id;
    int z_index;
    EngineColor color;
    double alpha;
    union {
        struct {
            int x;
            int y;
        } pixel;
        struct {
            int x;
            int y;
            int w;
            int h;
            int filled;
        } rect;
        struct {
            int x;
            int y;
            int w;
            int h;
            int radius;
            int filled;
        } rounded_rect;
        struct {
            int x;
            int y;
            int radius;
            int filled;
        } circle;
        struct {
            int x;
            int y;
            int w;
            int h;
            EngineColor end_color;
            int vertical;
        } gradient_rect;
        struct {
            int x1;
            int y1;
            int x2;
            int y2;
        } line;
        struct {
            int x;
            int y;
            int font_id;
            char text[ENGINE_MAX_TEXT];
        } text;
        struct {
            int x;
            int y;
            int w;
            int h;
            int image_id;
        } image;
        struct {
            int x;
            int y;
            int w;
            int h;
            int video_id;
        } video;
    } data;
} DrawCommand;

typedef struct EngineLayer {
    int in_use;
    int id;
    int z_index;
    double opacity;
} EngineLayer;

typedef struct EngineFont {
    int in_use;
    int id;
    int size;
    char path[260];
#if ENGINE_HAS_SDL_TTF
    TTF_Font *native_font;
#endif
} EngineFont;

typedef struct EngineImage {
    int in_use;
    int id;
    int width;
    int height;
    char path[260];
#if ENGINE_HAS_SDL_IMAGE
    SDL_Texture *texture;
    SDL_Renderer *renderer_owner;
#endif
} EngineImage;

typedef struct EngineAudioClip {
    int in_use;
    int id;
    int playing;
    int loop;
    double volume;
    char path[260];
#if ENGINE_HAS_SDL_MIXER
    Mix_Chunk *chunk;
    int channel;
#endif
} EngineAudioClip;

typedef struct EngineVideoClip {
    int in_use;
    int id;
    int playing;
    int loop;
    double time_seconds;
    char path[260];
#if ENGINE_HAS_FFMPEG
    AVFormatContext *format_context;
    AVCodecContext *codec_context;
    struct SwsContext *sws_context;
    AVFrame *frame;
    AVFrame *rgba_frame;
    AVPacket *packet;
    unsigned char *rgba_buffer;
    int video_stream_index;
    int width;
    int height;
    double frame_rate;
    double frame_accumulator;
#endif
} EngineVideoClip;

typedef struct EngineScreenInfo {
    int id;
    int width;
    int height;
    float dpi;
    int refresh_rate;
} EngineScreenInfo;

typedef struct EngineWindow {
    int in_use;
    int id;
    int screen_id;
    int x;
    int y;
    int width;
    int height;
    int borderless;
    int focused;
    int minimized;
    int maximized;
    int visible;
    int z_order;
    char title[ENGINE_MAX_TITLE];
    EngineColor clear_color;
    EngineLayer layers[ENGINE_MAX_LAYERS];
    int layer_count;
    DrawCommand commands[ENGINE_MAX_COMMANDS];
    int command_count;
#if ENGINE_HAS_SDL
    SDL_Window *native_window;
    SDL_Renderer *native_renderer;
    Uint32 sdl_window_id;
#endif
} EngineWindow;

typedef struct EngineInputState {
    int mouse_x;
    int mouse_y;
    int mouse_wheel_x;
    int mouse_wheel_y;
    int drag_active;
    int drag_start_x;
    int drag_start_y;
    int mouse_buttons[ENGINE_MOUSE_BUTTONS];
    int mouse_clicked[ENGINE_MOUSE_BUTTONS];
    int key_pressed[ENGINE_KEY_COUNT];
    int key_down[ENGINE_KEY_COUNT];
    int key_released[ENGINE_KEY_COUNT];
    int modifier_shift;
    int modifier_ctrl;
    int modifier_alt;
    int quit_requested;
    int focused_window_id;
    char text_input[64];
} EngineInputState;

typedef struct EngineAnimation {
    int in_use;
    int id;
    AnimationTargetType target_type;
    int target_id;
    AnimationProperty property;
    double start_value;
    double end_value;
    double duration;
    double elapsed;
} EngineAnimation;

typedef struct EngineState {
    int initialized;
    int running;
    int next_window_id;
    int next_layer_id;
    int next_animation_id;
    int next_audio_id;
    int next_video_id;
    int next_font_id;
    int primary_window_id;
    double delta_time;
    double last_tick_seconds;
    EngineWindow windows[ENGINE_MAX_WINDOWS];
    EngineAnimation animations[ENGINE_MAX_ANIMATIONS];
    EngineImage images[ENGINE_MAX_IMAGES];
    EngineAudioClip audio[ENGINE_MAX_AUDIO];
    EngineVideoClip videos[ENGINE_MAX_VIDEO];
    EngineFont fonts[ENGINE_MAX_FONTS];
    EngineScreenInfo screens[ENGINE_MAX_SCREENS];
    int screen_count;
    EngineInputState input;
} EngineState;

static EngineState g_engine;

EXPORT int engine_poll_events(void);

static double engine_now_seconds(void) {
#if ENGINE_HAS_SDL
    return (double)SDL_GetTicks64() / 1000.0;
#else
    return (double)clock() / (double)CLOCKS_PER_SEC;
#endif
}

static EngineColor engine_make_color(int r, int g, int b, int a) {
    EngineColor color;
    color.r = (unsigned char)r;
    color.g = (unsigned char)g;
    color.b = (unsigned char)b;
    color.a = (unsigned char)a;
    return color;
}

static void engine_reset_input_frame(EngineInputState *input) {
    int i;

    for (i = 0; i < ENGINE_MOUSE_BUTTONS; ++i) {
        input->mouse_clicked[i] = 0;
    }

    for (i = 0; i < ENGINE_KEY_COUNT; ++i) {
        input->key_pressed[i] = 0;
        input->key_released[i] = 0;
    }

    input->text_input[0] = '\0';
    input->mouse_wheel_x = 0;
    input->mouse_wheel_y = 0;
}

static EngineWindow *engine_get_window(int window_id) {
    int i;

    for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
        if (g_engine.windows[i].in_use && g_engine.windows[i].id == window_id) {
            return &g_engine.windows[i];
        }
    }

    return NULL;
}

static EngineWindow *engine_get_primary_window(void) {
    return engine_get_window(g_engine.primary_window_id);
}

static EngineImage *engine_get_image(int image_id) {
    int i;

    for (i = 0; i < ENGINE_MAX_IMAGES; ++i) {
        if (g_engine.images[i].in_use && g_engine.images[i].id == image_id) {
            return &g_engine.images[i];
        }
    }

    return NULL;
}

static EngineFont *engine_get_font(int font_id) {
    int i;

    for (i = 0; i < ENGINE_MAX_FONTS; ++i) {
        if (g_engine.fonts[i].in_use && g_engine.fonts[i].id == font_id) {
            return &g_engine.fonts[i];
        }
    }

    return NULL;
}

static EngineAudioClip *engine_get_audio(int sound_id) {
    int i;

    for (i = 0; i < ENGINE_MAX_AUDIO; ++i) {
        if (g_engine.audio[i].in_use && g_engine.audio[i].id == sound_id) {
            return &g_engine.audio[i];
        }
    }

    return NULL;
}

static EngineVideoClip *engine_get_video(int video_id) {
    int i;

    for (i = 0; i < ENGINE_MAX_VIDEO; ++i) {
        if (g_engine.videos[i].in_use && g_engine.videos[i].id == video_id) {
            return &g_engine.videos[i];
        }
    }

    return NULL;
}

static int engine_get_layer_z(const EngineWindow *window, int layer_id) {
    int i;

    if (!window) {
        return 0;
    }

    for (i = 0; i < window->layer_count; ++i) {
        if (window->layers[i].in_use && window->layers[i].id == layer_id) {
            return window->layers[i].z_index;
        }
    }

    return 0;
}

static int engine_allocate_layer(EngineWindow *window, int z_index) {
    EngineLayer *layer;

    if (!window || window->layer_count >= ENGINE_MAX_LAYERS) {
        return -1;
    }

    layer = &window->layers[window->layer_count++];
    memset(layer, 0, sizeof(*layer));
    layer->in_use = 1;
    layer->id = g_engine.next_layer_id++;
    layer->z_index = z_index;
    layer->opacity = 1.0;
    return layer->id;
}

static int engine_push_command(EngineWindow *window, const DrawCommand *command) {
    if (!window || !command || window->command_count >= ENGINE_MAX_COMMANDS) {
        return -1;
    }

    window->commands[window->command_count++] = *command;
    return 0;
}

static int engine_compare_commands(const void *left, const void *right) {
    const DrawCommand *a = (const DrawCommand *)left;
    const DrawCommand *b = (const DrawCommand *)right;

    if (a->z_index < b->z_index) {
        return -1;
    }
    if (a->z_index > b->z_index) {
        return 1;
    }
    return 0;
}

#if ENGINE_HAS_SDL_IMAGE
static SDL_Texture *engine_image_get_texture(EngineImage *image, SDL_Renderer *renderer) {
    SDL_Surface *surface;

    if (!image || !renderer) {
        return NULL;
    }

    if (image->texture && image->renderer_owner == renderer) {
        return image->texture;
    }

    if (image->texture) {
        SDL_DestroyTexture(image->texture);
        image->texture = NULL;
        image->renderer_owner = NULL;
    }

    surface = IMG_Load(image->path);
    if (!surface) {
        return NULL;
    }

    image->width = surface->w;
    image->height = surface->h;
    image->texture = SDL_CreateTextureFromSurface(renderer, surface);
    image->renderer_owner = renderer;
    SDL_FreeSurface(surface);
    return image->texture;
}
#endif

#if ENGINE_HAS_FFMPEG
static void engine_video_reset_decode(EngineVideoClip *video) {
    if (!video || !video->format_context || !video->codec_context) {
        return;
    }

    av_seek_frame(video->format_context, video->video_stream_index, 0, AVSEEK_FLAG_BACKWARD);
    avcodec_flush_buffers(video->codec_context);
    video->frame_accumulator = 0.0;
    video->time_seconds = 0.0;
}

static int engine_video_decode_next_frame(EngineVideoClip *video) {
    int response;

    if (!video || !video->format_context || !video->codec_context || !video->packet || !video->frame || !video->rgba_frame) {
        return 0;
    }

    while ((response = av_read_frame(video->format_context, video->packet)) >= 0) {
        if (video->packet->stream_index == video->video_stream_index) {
            if (avcodec_send_packet(video->codec_context, video->packet) == 0) {
                while (avcodec_receive_frame(video->codec_context, video->frame) == 0) {
                    sws_scale(video->sws_context,
                              (const uint8_t *const *)video->frame->data,
                              video->frame->linesize,
                              0,
                              video->codec_context->height,
                              video->rgba_frame->data,
                              video->rgba_frame->linesize);
                    av_packet_unref(video->packet);
                    return 1;
                }
            }
        }
        av_packet_unref(video->packet);
    }

    if (video->loop) {
        engine_video_reset_decode(video);
        return engine_video_decode_next_frame(video);
    }

    video->playing = 0;
    return 0;
}
#endif

static void engine_query_screens(void) {
    g_engine.screen_count = 0;

#if ENGINE_HAS_SDL
    {
        int i;
        int count = SDL_GetNumVideoDisplays();
        if (count < 1) {
            count = 1;
        }

        if (count > ENGINE_MAX_SCREENS) {
            count = ENGINE_MAX_SCREENS;
        }

        for (i = 0; i < count; ++i) {
            SDL_DisplayMode mode;
            float ddpi = 96.0f;
            float hdpi = 96.0f;
            float vdpi = 96.0f;

            memset(&g_engine.screens[i], 0, sizeof(g_engine.screens[i]));
            g_engine.screens[i].id = i;

            if (SDL_GetCurrentDisplayMode(i, &mode) == 0) {
                g_engine.screens[i].width = mode.w;
                g_engine.screens[i].height = mode.h;
                g_engine.screens[i].refresh_rate = mode.refresh_rate;
            } else {
                g_engine.screens[i].width = 1920;
                g_engine.screens[i].height = 1080;
                g_engine.screens[i].refresh_rate = 60;
            }

            if (SDL_GetDisplayDPI(i, &ddpi, &hdpi, &vdpi) == 0) {
                g_engine.screens[i].dpi = ddpi;
            } else {
                g_engine.screens[i].dpi = 96.0f;
            }
        }

        g_engine.screen_count = count;
    }
#else
    memset(&g_engine.screens[0], 0, sizeof(g_engine.screens[0]));
    g_engine.screens[0].id = 0;
    g_engine.screens[0].width = 1920;
    g_engine.screens[0].height = 1080;
    g_engine.screens[0].dpi = 96.0f;
    g_engine.screens[0].refresh_rate = 60;
    g_engine.screen_count = 1;
#endif
}

static void engine_apply_animation(EngineAnimation *animation, double value) {
    EngineWindow *window;

    if (!animation) {
        return;
    }

    if (animation->target_type != ANIM_TARGET_WINDOW) {
        return;
    }

    window = engine_get_window(animation->target_id);
    if (!window) {
        return;
    }

    switch (animation->property) {
        case ANIM_PROPERTY_X:
            window->x = (int)value;
#if ENGINE_HAS_SDL
            if (window->native_window) {
                SDL_SetWindowPosition(window->native_window, window->x, window->y);
            }
#endif
            break;
        case ANIM_PROPERTY_Y:
            window->y = (int)value;
#if ENGINE_HAS_SDL
            if (window->native_window) {
                SDL_SetWindowPosition(window->native_window, window->x, window->y);
            }
#endif
            break;
        case ANIM_PROPERTY_WIDTH:
            window->width = (int)value;
#if ENGINE_HAS_SDL
            if (window->native_window) {
                SDL_SetWindowSize(window->native_window, window->width, window->height);
            }
#endif
            break;
        case ANIM_PROPERTY_HEIGHT:
            window->height = (int)value;
#if ENGINE_HAS_SDL
            if (window->native_window) {
                SDL_SetWindowSize(window->native_window, window->width, window->height);
            }
#endif
            break;
        case ANIM_PROPERTY_OPACITY:
#if ENGINE_HAS_SDL
            if (window->native_window) {
                SDL_SetWindowOpacity(window->native_window, (float)value);
            }
#else
            (void)value;
#endif
            break;
    }
}

static void engine_flush_window(EngineWindow *window) {
    if (!window) {
        return;
    }

#if ENGINE_HAS_SDL
    int i;
    if (!window->native_renderer) {
        window->command_count = 0;
        return;
    }

    if (window->command_count > 1) {
        qsort(window->commands,
              (size_t)window->command_count,
              sizeof(window->commands[0]),
              engine_compare_commands);
    }

    SDL_SetRenderDrawBlendMode(window->native_renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(window->native_renderer,
                           window->clear_color.r,
                           window->clear_color.g,
                           window->clear_color.b,
                           window->clear_color.a);
    SDL_RenderClear(window->native_renderer);

    for (i = 0; i < window->command_count; ++i) {
        DrawCommand *command = &window->commands[i];

        SDL_SetRenderDrawColor(window->native_renderer,
                               command->color.r,
                               command->color.g,
                               command->color.b,
                               command->color.a);

            switch (command->type) {
            case DRAW_COMMAND_PIXEL:
                SDL_RenderDrawPoint(window->native_renderer,
                                    command->data.pixel.x,
                                    command->data.pixel.y);
                break;
            case DRAW_COMMAND_RECT: {
                SDL_Rect rect;
                rect.x = command->data.rect.x;
                rect.y = command->data.rect.y;
                rect.w = command->data.rect.w;
                rect.h = command->data.rect.h;
                if (command->data.rect.filled) {
                    SDL_RenderFillRect(window->native_renderer, &rect);
                } else {
                    SDL_RenderDrawRect(window->native_renderer, &rect);
                }
                break;
            }
            case DRAW_COMMAND_ROUNDED_RECT: {
                int rx = command->data.rounded_rect.x;
                int ry = command->data.rounded_rect.y;
                int rw = command->data.rounded_rect.w;
                int rh = command->data.rounded_rect.h;
                int radius = command->data.rounded_rect.radius;
                int step;

                if (radius < 1) {
                    SDL_Rect rect = {rx, ry, rw, rh};
                    if (command->data.rounded_rect.filled) {
                        SDL_RenderFillRect(window->native_renderer, &rect);
                    } else {
                        SDL_RenderDrawRect(window->native_renderer, &rect);
                    }
                    break;
                }

                if (command->data.rounded_rect.filled) {
                    SDL_Rect center = {rx + radius, ry, rw - (radius * 2), rh};
                    SDL_Rect left = {rx, ry + radius, radius, rh - (radius * 2)};
                    SDL_Rect right = {rx + rw - radius, ry + radius, radius, rh - (radius * 2)};
                    SDL_RenderFillRect(window->native_renderer, &center);
                    SDL_RenderFillRect(window->native_renderer, &left);
                    SDL_RenderFillRect(window->native_renderer, &right);
                }

                for (step = 0; step <= radius; ++step) {
                    int offset = (int)(radius - SDL_sqrtf((float)(radius * radius - step * step)));
                    if (command->data.rounded_rect.filled) {
                        SDL_RenderDrawLine(window->native_renderer, rx + offset, ry + radius - step, rx + rw - offset - 1, ry + radius - step);
                        SDL_RenderDrawLine(window->native_renderer, rx + offset, ry + rh - radius + step - 1, rx + rw - offset - 1, ry + rh - radius + step - 1);
                    } else {
                        SDL_RenderDrawPoint(window->native_renderer, rx + offset, ry + radius - step);
                        SDL_RenderDrawPoint(window->native_renderer, rx + rw - offset - 1, ry + radius - step);
                        SDL_RenderDrawPoint(window->native_renderer, rx + offset, ry + rh - radius + step - 1);
                        SDL_RenderDrawPoint(window->native_renderer, rx + rw - offset - 1, ry + rh - radius + step - 1);
                    }
                }

                if (!command->data.rounded_rect.filled) {
                    SDL_RenderDrawLine(window->native_renderer, rx + radius, ry, rx + rw - radius, ry);
                    SDL_RenderDrawLine(window->native_renderer, rx + radius, ry + rh - 1, rx + rw - radius, ry + rh - 1);
                    SDL_RenderDrawLine(window->native_renderer, rx, ry + radius, rx, ry + rh - radius);
                    SDL_RenderDrawLine(window->native_renderer, rx + rw - 1, ry + radius, rx + rw - 1, ry + rh - radius);
                }
                break;
            }
            case DRAW_COMMAND_CIRCLE: {
                int x0 = command->data.circle.x;
                int y0 = command->data.circle.y;
                int radius = command->data.circle.radius;
                int x = radius;
                int y = 0;
                int err = 0;

                while (x >= y) {
                    if (command->data.circle.filled) {
                        SDL_RenderDrawLine(window->native_renderer, x0 - x, y0 + y, x0 + x, y0 + y);
                        SDL_RenderDrawLine(window->native_renderer, x0 - y, y0 + x, x0 + y, y0 + x);
                        SDL_RenderDrawLine(window->native_renderer, x0 - x, y0 - y, x0 + x, y0 - y);
                        SDL_RenderDrawLine(window->native_renderer, x0 - y, y0 - x, x0 + y, y0 - x);
                    } else {
                        SDL_RenderDrawPoint(window->native_renderer, x0 + x, y0 + y);
                        SDL_RenderDrawPoint(window->native_renderer, x0 + y, y0 + x);
                        SDL_RenderDrawPoint(window->native_renderer, x0 - y, y0 + x);
                        SDL_RenderDrawPoint(window->native_renderer, x0 - x, y0 + y);
                        SDL_RenderDrawPoint(window->native_renderer, x0 - x, y0 - y);
                        SDL_RenderDrawPoint(window->native_renderer, x0 - y, y0 - x);
                        SDL_RenderDrawPoint(window->native_renderer, x0 + y, y0 - x);
                        SDL_RenderDrawPoint(window->native_renderer, x0 + x, y0 - y);
                    }

                    ++y;
                    if (err <= 0) {
                        err += 2 * y + 1;
                    } else {
                        --x;
                        err += 2 * (y - x) + 1;
                    }
                }
                break;
            }
            case DRAW_COMMAND_GRADIENT_RECT: {
                int step;
                int total = command->data.gradient_rect.vertical ? command->data.gradient_rect.h : command->data.gradient_rect.w;
                if (total < 1) {
                    total = 1;
                }
                for (step = 0; step < total; ++step) {
                    float t = (float)step / (float)total;
                    Uint8 rr = (Uint8)((1.0f - t) * command->color.r + t * command->data.gradient_rect.end_color.r);
                    Uint8 gg = (Uint8)((1.0f - t) * command->color.g + t * command->data.gradient_rect.end_color.g);
                    Uint8 bb = (Uint8)((1.0f - t) * command->color.b + t * command->data.gradient_rect.end_color.b);
                    Uint8 aa = (Uint8)((1.0f - t) * command->color.a + t * command->data.gradient_rect.end_color.a);
                    SDL_SetRenderDrawColor(window->native_renderer, rr, gg, bb, aa);
                    if (command->data.gradient_rect.vertical) {
                        SDL_RenderDrawLine(window->native_renderer,
                                           command->data.gradient_rect.x,
                                           command->data.gradient_rect.y + step,
                                           command->data.gradient_rect.x + command->data.gradient_rect.w,
                                           command->data.gradient_rect.y + step);
                    } else {
                        SDL_RenderDrawLine(window->native_renderer,
                                           command->data.gradient_rect.x + step,
                                           command->data.gradient_rect.y,
                                           command->data.gradient_rect.x + step,
                                           command->data.gradient_rect.y + command->data.gradient_rect.h);
                    }
                }
                SDL_SetRenderDrawColor(window->native_renderer,
                                       command->color.r,
                                       command->color.g,
                                       command->color.b,
                                       command->color.a);
                break;
            }
            case DRAW_COMMAND_LINE:
                SDL_RenderDrawLine(window->native_renderer,
                                   command->data.line.x1,
                                   command->data.line.y1,
                                   command->data.line.x2,
                                   command->data.line.y2);
                break;
            case DRAW_COMMAND_TEXT: {
#if ENGINE_HAS_SDL_TTF
                EngineFont *font = engine_get_font(command->data.text.font_id);
                if (font && font->native_font) {
                    SDL_Color text_color;
                    SDL_Surface *surface;
                    SDL_Texture *texture;
                    SDL_Rect target;
                    text_color.r = command->color.r;
                    text_color.g = command->color.g;
                    text_color.b = command->color.b;
                    text_color.a = command->color.a;

                    surface = TTF_RenderUTF8_Blended(font->native_font, command->data.text.text, text_color);
                    if (surface) {
                        texture = SDL_CreateTextureFromSurface(window->native_renderer, surface);
                        if (texture) {
                            target.x = command->data.text.x;
                            target.y = command->data.text.y;
                            target.w = surface->w;
                            target.h = surface->h;
                            SDL_RenderCopy(window->native_renderer, texture, NULL, &target);
                            SDL_DestroyTexture(texture);
                        }
                        SDL_FreeSurface(surface);
                    }
                }
#else
                SDL_Rect placeholder;
                size_t len = strlen(command->data.text.text);
                placeholder.x = command->data.text.x;
                placeholder.y = command->data.text.y;
                placeholder.w = (int)(len * 8);
                placeholder.h = 16;
                SDL_RenderDrawRect(window->native_renderer, &placeholder);
#endif
                break;
            }
            case DRAW_COMMAND_IMAGE: {
#if ENGINE_HAS_SDL_IMAGE
                EngineImage *image = engine_get_image(command->data.image.image_id);
                SDL_Texture *texture = engine_image_get_texture(image, window->native_renderer);
                if (texture) {
                    SDL_Rect target;
                    target.x = command->data.image.x;
                    target.y = command->data.image.y;
                    target.w = command->data.image.w > 0 ? command->data.image.w : image->width;
                    target.h = command->data.image.h > 0 ? command->data.image.h : image->height;
                    SDL_RenderCopy(window->native_renderer, texture, NULL, &target);
                }
#else
                SDL_Rect placeholder;
                placeholder.x = command->data.image.x;
                placeholder.y = command->data.image.y;
                placeholder.w = command->data.image.w;
                placeholder.h = command->data.image.h;
                SDL_RenderDrawRect(window->native_renderer, &placeholder);
#endif
                break;
            }
            case DRAW_COMMAND_VIDEO: {
#if ENGINE_HAS_FFMPEG
                EngineVideoClip *video = engine_get_video(command->data.video.video_id);
                if (video && video->rgba_frame && video->width > 0 && video->height > 0) {
                    SDL_Texture *texture;
                    SDL_Rect target;

                    if (video->playing) {
                        double frame_step = video->frame_rate > 0.0 ? (1.0 / video->frame_rate) : 0.033333;
                        video->frame_accumulator += g_engine.delta_time;
                        while (video->frame_accumulator >= frame_step) {
                            if (!engine_video_decode_next_frame(video)) {
                                break;
                            }
                            video->frame_accumulator -= frame_step;
                            video->time_seconds += frame_step;
                        }
                    }

                    texture = SDL_CreateTexture(window->native_renderer,
                                                SDL_PIXELFORMAT_RGBA32,
                                                SDL_TEXTUREACCESS_STREAMING,
                                                video->width,
                                                video->height);

                    if (texture) {
                        SDL_UpdateTexture(texture,
                                          NULL,
                                          video->rgba_frame->data[0],
                                          video->rgba_frame->linesize[0]);
                        target.x = command->data.video.x;
                        target.y = command->data.video.y;
                        target.w = command->data.video.w > 0 ? command->data.video.w : video->width;
                        target.h = command->data.video.h > 0 ? command->data.video.h : video->height;
                        SDL_RenderCopy(window->native_renderer, texture, NULL, &target);
                        SDL_DestroyTexture(texture);
                    }
                }
#else
                SDL_Rect placeholder;
                placeholder.x = command->data.video.x;
                placeholder.y = command->data.video.y;
                placeholder.w = command->data.video.w;
                placeholder.h = command->data.video.h;
                SDL_RenderDrawRect(window->native_renderer, &placeholder);
                SDL_RenderDrawLine(window->native_renderer,
                                   placeholder.x,
                                   placeholder.y,
                                   placeholder.x + placeholder.w,
                                   placeholder.y + placeholder.h);
                SDL_RenderDrawLine(window->native_renderer,
                                   placeholder.x + placeholder.w,
                                   placeholder.y,
                                   placeholder.x,
                                   placeholder.y + placeholder.h);
#endif
                break;
            }
            case DRAW_COMMAND_NONE:
            default:
                break;
        }
    }

    SDL_RenderPresent(window->native_renderer);
#endif

    window->command_count = 0;
}

#if ENGINE_HAS_SDL
static int engine_find_window_by_sdl_id(unsigned int sdl_window_id) {
    int i;
    for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
        if (g_engine.windows[i].in_use && g_engine.windows[i].sdl_window_id == sdl_window_id) {
            return g_engine.windows[i].id;
        }
    }
    return -1;
}
#endif

EXPORT int engine_init(void) {
    if (g_engine.initialized) {
        return 0;
    }

    memset(&g_engine, 0, sizeof(g_engine));
    g_engine.next_window_id = 1;
    g_engine.next_layer_id = 1;
    g_engine.next_animation_id = 1;
    g_engine.next_audio_id = 1;
    g_engine.next_video_id = 1;
    g_engine.next_font_id = 1;
    g_engine.primary_window_id = -1;

#if ENGINE_HAS_SDL
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        printf("SDL Init Error: %s\n", SDL_GetError());
        return -1;
    }
#endif

#if ENGINE_HAS_SDL_IMAGE
    if ((IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG | IMG_INIT_TIF | IMG_INIT_WEBP) == 0)) {
        printf("SDL_image Init Error: %s\n", IMG_GetError());
    }
#endif

#if ENGINE_HAS_SDL_TTF
    if (TTF_Init() != 0) {
        printf("SDL_ttf Init Error: %s\n", TTF_GetError());
    }
#endif

#if ENGINE_HAS_SDL_MIXER
    if (Mix_OpenAudio(48000, AUDIO_F32SYS, 2, 2048) != 0) {
        printf("SDL_mixer Init Error: %s\n", Mix_GetError());
    }
    Mix_AllocateChannels(64);
#endif

#if ENGINE_HAS_FFMPEG
    av_log_set_level(AV_LOG_ERROR);
    avformat_network_init();
#endif

    engine_query_screens();
    g_engine.last_tick_seconds = engine_now_seconds();
    g_engine.initialized = 1;
    return 0;
}

EXPORT void engine_shutdown(void) {
    int i;

    if (!g_engine.initialized) {
        return;
    }

#if ENGINE_HAS_SDL
    for (i = 0; i < ENGINE_MAX_IMAGES; ++i) {
#if ENGINE_HAS_SDL_IMAGE
        if (g_engine.images[i].texture) {
            SDL_DestroyTexture(g_engine.images[i].texture);
        }
#endif
    }

    for (i = 0; i < ENGINE_MAX_FONTS; ++i) {
#if ENGINE_HAS_SDL_TTF
        if (g_engine.fonts[i].native_font) {
            TTF_CloseFont(g_engine.fonts[i].native_font);
        }
#endif
    }

    for (i = 0; i < ENGINE_MAX_AUDIO; ++i) {
#if ENGINE_HAS_SDL_MIXER
        if (g_engine.audio[i].chunk) {
            Mix_FreeChunk(g_engine.audio[i].chunk);
        }
#endif
    }

    for (i = 0; i < ENGINE_MAX_VIDEO; ++i) {
#if ENGINE_HAS_FFMPEG
        if (g_engine.videos[i].packet) {
            av_packet_free(&g_engine.videos[i].packet);
        }
        if (g_engine.videos[i].frame) {
            av_frame_free(&g_engine.videos[i].frame);
        }
        if (g_engine.videos[i].rgba_frame) {
            av_frame_free(&g_engine.videos[i].rgba_frame);
        }
        if (g_engine.videos[i].rgba_buffer) {
            av_free(g_engine.videos[i].rgba_buffer);
        }
        if (g_engine.videos[i].sws_context) {
            sws_freeContext(g_engine.videos[i].sws_context);
        }
        if (g_engine.videos[i].codec_context) {
            avcodec_free_context(&g_engine.videos[i].codec_context);
        }
        if (g_engine.videos[i].format_context) {
            avformat_close_input(&g_engine.videos[i].format_context);
        }
#endif
    }

    for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
        if (g_engine.windows[i].in_use) {
            if (g_engine.windows[i].native_renderer) {
                SDL_DestroyRenderer(g_engine.windows[i].native_renderer);
            }
            if (g_engine.windows[i].native_window) {
                SDL_DestroyWindow(g_engine.windows[i].native_window);
            }
        }
    }

#if ENGINE_HAS_SDL_MIXER
    Mix_CloseAudio();
#endif
#if ENGINE_HAS_SDL_TTF
    TTF_Quit();
#endif
#if ENGINE_HAS_SDL_IMAGE
    IMG_Quit();
#endif
#if ENGINE_HAS_FFMPEG
    avformat_network_deinit();
#endif
    SDL_Quit();
#else
    (void)i;
#endif

    memset(&g_engine, 0, sizeof(g_engine));
}

EXPORT double engine_get_delta_time(void) {
    return g_engine.delta_time;
}

EXPORT int screen_get_count(void) {
    if (!g_engine.initialized && engine_init() != 0) {
        return 0;
    }

    return g_engine.screen_count;
}

EXPORT int screen_get_resolution(int screen_id, int *width, int *height) {
    if (!g_engine.initialized && engine_init() != 0) {
        return -1;
    }

    if (screen_id < 0 || screen_id >= g_engine.screen_count) {
        return -1;
    }

    if (width) {
        *width = g_engine.screens[screen_id].width;
    }

    if (height) {
        *height = g_engine.screens[screen_id].height;
    }

    return 0;
}

EXPORT int screen_get_dpi(int screen_id) {
    if (!g_engine.initialized && engine_init() != 0) {
        return 96;
    }

    if (screen_id < 0 || screen_id >= g_engine.screen_count) {
        return 96;
    }

    return (int)g_engine.screens[screen_id].dpi;
}

EXPORT int window_create_ex(int width, int height, const char *title, int screen_id, int borderless) {
    int i;
    EngineWindow *window = NULL;

    if (!g_engine.initialized && engine_init() != 0) {
        return -1;
    }

    for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
        if (!g_engine.windows[i].in_use) {
            window = &g_engine.windows[i];
            break;
        }
    }

    if (!window) {
        return -1;
    }

    memset(window, 0, sizeof(*window));
    window->in_use = 1;
    window->id = g_engine.next_window_id++;
    window->screen_id = screen_id >= 0 ? screen_id : 0;
    window->x = 100;
    window->y = 100;
    window->width = width;
    window->height = height;
    window->borderless = borderless;
    window->visible = 1;
    window->z_order = window->id;
    window->clear_color = engine_make_color(20, 20, 20, 255);
    strncpy(window->title, title ? title : "Pamm Engine", ENGINE_MAX_TITLE - 1);
    window->title[ENGINE_MAX_TITLE - 1] = '\0';
    engine_allocate_layer(window, 0);

#if ENGINE_HAS_SDL
    {
        Uint32 flags = SDL_WINDOW_SHOWN;
        if (borderless) {
            flags |= SDL_WINDOW_BORDERLESS;
        }

        window->native_window = SDL_CreateWindow(window->title,
                                                 SDL_WINDOWPOS_CENTERED_DISPLAY(window->screen_id),
                                                 SDL_WINDOWPOS_CENTERED_DISPLAY(window->screen_id),
                                                 width,
                                                 height,
                                                 flags);

        if (!window->native_window) {
            printf("Window Error: %s\n", SDL_GetError());
            memset(window, 0, sizeof(*window));
            return -1;
        }

        window->native_renderer = SDL_CreateRenderer(window->native_window,
                                                     -1,
                                                     SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

        if (!window->native_renderer) {
            printf("Renderer Error: %s\n", SDL_GetError());
            SDL_DestroyWindow(window->native_window);
            memset(window, 0, sizeof(*window));
            return -1;
        }

        window->sdl_window_id = SDL_GetWindowID(window->native_window);
    }
#endif

    if (g_engine.primary_window_id < 0) {
        g_engine.primary_window_id = window->id;
    }

    return window->id;
}

EXPORT int create_window(int width, int height) {
    return window_create_ex(width, height, "Pamm Engine", 0, 1) >= 0 ? 0 : -1;
}

EXPORT int window_move(int window_id, int x, int y) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }

    window->x = x;
    window->y = y;

#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_SetWindowPosition(window->native_window, x, y);
    }
#endif

    return 0;
}

EXPORT int window_resize(int window_id, int width, int height) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }

    window->width = width;
    window->height = height;

#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_SetWindowSize(window->native_window, width, height);
    }
#endif

    return 0;
}

EXPORT int window_focus(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }

    g_engine.input.focused_window_id = window_id;
    window->focused = 1;

#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_RaiseWindow(window->native_window);
    }
#endif

    return 0;
}

EXPORT int window_close(int window_id) {
    int i;
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }

#if ENGINE_HAS_SDL
    if (window->native_renderer) {
        SDL_DestroyRenderer(window->native_renderer);
    }
    if (window->native_window) {
        SDL_DestroyWindow(window->native_window);
    }
#endif

    memset(window, 0, sizeof(*window));

    if (g_engine.primary_window_id == window_id) {
        g_engine.primary_window_id = -1;
        for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
            if (g_engine.windows[i].in_use) {
                g_engine.primary_window_id = g_engine.windows[i].id;
                break;
            }
        }
    }

    return 0;
}

EXPORT int window_set_screen(int window_id, int screen_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window || screen_id < 0 || screen_id >= g_engine.screen_count) {
        return -1;
    }

    window->screen_id = screen_id;

#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_SetWindowPosition(window->native_window,
                              SDL_WINDOWPOS_CENTERED_DISPLAY(screen_id),
                              SDL_WINDOWPOS_CENTERED_DISPLAY(screen_id));
    }
#endif

    return 0;
}

EXPORT int window_minimize(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_MinimizeWindow(window->native_window);
    }
#endif
    window->minimized = 1;
    return 0;
}

EXPORT int window_maximize(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_MaximizeWindow(window->native_window);
    }
#endif
    window->maximized = 1;
    return 0;
}

EXPORT int window_restore(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_RestoreWindow(window->native_window);
    }
#endif
    window->minimized = 0;
    window->maximized = 0;
    return 0;
}

EXPORT int window_show(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_ShowWindow(window->native_window);
    }
#endif
    window->visible = 1;
    return 0;
}

EXPORT int window_hide(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_HideWindow(window->native_window);
    }
#endif
    window->visible = 0;
    return 0;
}

EXPORT int window_set_title(int window_id, const char *title) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window || !title) {
        return -1;
    }
    strncpy(window->title, title, ENGINE_MAX_TITLE - 1);
    window->title[ENGINE_MAX_TITLE - 1] = '\0';
#if ENGINE_HAS_SDL
    if (window->native_window) {
        SDL_SetWindowTitle(window->native_window, window->title);
    }
#endif
    return 0;
}

EXPORT int layer_add(int window_id, int z_index) {
    EngineWindow *window = engine_get_window(window_id);
    return engine_allocate_layer(window, z_index);
}

EXPORT int layer_remove(int window_id, int layer_id) {
    int i;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    for (i = 0; i < window->layer_count; ++i) {
        if (window->layers[i].in_use && window->layers[i].id == layer_id) {
            int j;
            for (j = i; j < window->layer_count - 1; ++j) {
                window->layers[j] = window->layers[j + 1];
            }
            --window->layer_count;
            return 0;
        }
    }

    return -1;
}

EXPORT int layer_set_z_order(int window_id, int layer_id, int z_index) {
    int i;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    for (i = 0; i < window->layer_count; ++i) {
        if (window->layers[i].in_use && window->layers[i].id == layer_id) {
            window->layers[i].z_index = z_index;
            return 0;
        }
    }

    return -1;
}

EXPORT int input_get_mouse_position(int *x, int *y) {
    if (x) {
        *x = g_engine.input.mouse_x;
    }
    if (y) {
        *y = g_engine.input.mouse_y;
    }
    return 0;
}

EXPORT int window_set_icon(int window_id, const char *path) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window || !path || !path[0]) {
        return -1;
    }
#if ENGINE_HAS_SDL_IMAGE
    if (window->native_window) {
        SDL_Surface *surface = IMG_Load(path);
        if (!surface) {
            return -1;
        }
        SDL_SetWindowIcon(window->native_window, surface);
        SDL_FreeSurface(surface);
        return 0;
    }
#endif
    return -1;
}

EXPORT int input_is_key_pressed(int key) {
    if (key < 0 || key >= ENGINE_KEY_COUNT) {
        return 0;
    }
    return g_engine.input.key_down[key];
}

EXPORT int input_is_mouse_clicked(int button) {
    if (button < 0 || button >= ENGINE_MOUSE_BUTTONS) {
        return 0;
    }
    return g_engine.input.mouse_clicked[button];
}

EXPORT int input_is_mouse_down(int button) {
    if (button < 0 || button >= ENGINE_MOUSE_BUTTONS) {
        return 0;
    }
    return g_engine.input.mouse_buttons[button];
}

EXPORT int input_get_mouse_wheel(int *x, int *y) {
    if (x) {
        *x = g_engine.input.mouse_wheel_x;
    }
    if (y) {
        *y = g_engine.input.mouse_wheel_y;
    }
    return 0;
}

EXPORT int input_is_dragging(void) {
    return g_engine.input.drag_active;
}

EXPORT int input_get_drag_start(int *x, int *y) {
    if (x) {
        *x = g_engine.input.drag_start_x;
    }
    if (y) {
        *y = g_engine.input.drag_start_y;
    }
    return 0;
}

EXPORT int input_get_modifiers(int *shift, int *ctrl, int *alt) {
    if (shift) {
        *shift = g_engine.input.modifier_shift;
    }
    if (ctrl) {
        *ctrl = g_engine.input.modifier_ctrl;
    }
    if (alt) {
        *alt = g_engine.input.modifier_alt;
    }
    return 0;
}

EXPORT int input_get_focused_window(void) {
    return g_engine.input.focused_window_id;
}

EXPORT int input_poll_events(void) {
    return engine_poll_events();
}

EXPORT int engine_poll_events(void) {
    engine_reset_input_frame(&g_engine.input);

#if ENGINE_HAS_SDL
    {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    g_engine.running = 0;
                    g_engine.input.quit_requested = 1;
                    return 1;
                case SDL_MOUSEMOTION:
                    g_engine.input.mouse_x = event.motion.x;
                    g_engine.input.mouse_y = event.motion.y;
                    if (g_engine.input.mouse_buttons[SDL_BUTTON_LEFT]) {
                        g_engine.input.drag_active = 1;
                    }
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    if (event.button.button < ENGINE_MOUSE_BUTTONS) {
                        g_engine.input.mouse_buttons[event.button.button] = 1;
                        g_engine.input.mouse_clicked[event.button.button] = 1;
                        if (event.button.button == SDL_BUTTON_LEFT) {
                            g_engine.input.drag_start_x = event.button.x;
                            g_engine.input.drag_start_y = event.button.y;
                        }
                    }
                    break;
                case SDL_MOUSEBUTTONUP:
                    if (event.button.button < ENGINE_MOUSE_BUTTONS) {
                        g_engine.input.mouse_buttons[event.button.button] = 0;
                        if (event.button.button == SDL_BUTTON_LEFT) {
                            g_engine.input.drag_active = 0;
                        }
                    }
                    break;
                case SDL_MOUSEWHEEL:
                    g_engine.input.mouse_wheel_x = event.wheel.x;
                    g_engine.input.mouse_wheel_y = event.wheel.y;
                    break;
                case SDL_KEYDOWN:
                    if (event.key.keysym.scancode < ENGINE_KEY_COUNT) {
                        g_engine.input.key_down[event.key.keysym.scancode] = 1;
                        g_engine.input.key_pressed[event.key.keysym.scancode] = 1;
                    }
                    g_engine.input.modifier_shift = (event.key.keysym.mod & KMOD_SHIFT) != 0;
                    g_engine.input.modifier_ctrl = (event.key.keysym.mod & KMOD_CTRL) != 0;
                    g_engine.input.modifier_alt = (event.key.keysym.mod & KMOD_ALT) != 0;
                    break;
                case SDL_KEYUP:
                    if (event.key.keysym.scancode < ENGINE_KEY_COUNT) {
                        g_engine.input.key_down[event.key.keysym.scancode] = 0;
                        g_engine.input.key_released[event.key.keysym.scancode] = 1;
                    }
                    g_engine.input.modifier_shift = (event.key.keysym.mod & KMOD_SHIFT) != 0;
                    g_engine.input.modifier_ctrl = (event.key.keysym.mod & KMOD_CTRL) != 0;
                    g_engine.input.modifier_alt = (event.key.keysym.mod & KMOD_ALT) != 0;
                    break;
                case SDL_TEXTINPUT:
                    strncpy(g_engine.input.text_input, event.text.text, sizeof(g_engine.input.text_input) - 1);
                    g_engine.input.text_input[sizeof(g_engine.input.text_input) - 1] = '\0';
                    break;
                case SDL_WINDOWEVENT: {
                    int window_id = engine_find_window_by_sdl_id(event.window.windowID);
                    EngineWindow *window = engine_get_window(window_id);
                    if (window) {
                        switch (event.window.event) {
                            case SDL_WINDOWEVENT_FOCUS_GAINED:
                                g_engine.input.focused_window_id = window_id;
                                window->focused = 1;
                                break;
                            case SDL_WINDOWEVENT_FOCUS_LOST:
                                window->focused = 0;
                                break;
                            case SDL_WINDOWEVENT_SIZE_CHANGED:
                                window->width = event.window.data1;
                                window->height = event.window.data2;
                                break;
                            case SDL_WINDOWEVENT_MINIMIZED:
                                window->minimized = 1;
                                break;
                            case SDL_WINDOWEVENT_MAXIMIZED:
                                window->maximized = 1;
                                break;
                            case SDL_WINDOWEVENT_RESTORED:
                                window->minimized = 0;
                                window->maximized = 0;
                                break;
                            case SDL_WINDOWEVENT_CLOSE:
                                window_close(window_id);
                                break;
                            default:
                                break;
                        }
                    }
                    break;
                }
                default:
                    break;
            }
        }
    }
#endif

    return g_engine.input.quit_requested;
}

EXPORT int poll_event(void) {
    return engine_poll_events();
}

EXPORT int animate_property(int target_id,
                            int property,
                            double start_value,
                            double end_value,
                            double duration) {
    int i;

    for (i = 0; i < ENGINE_MAX_ANIMATIONS; ++i) {
        EngineAnimation *animation = &g_engine.animations[i];
        if (!animation->in_use) {
            memset(animation, 0, sizeof(*animation));
            animation->in_use = 1;
            animation->id = g_engine.next_animation_id++;
            animation->target_type = ANIM_TARGET_WINDOW;
            animation->target_id = target_id;
            animation->property = (AnimationProperty)property;
            animation->start_value = start_value;
            animation->end_value = end_value;
            animation->duration = duration > 0.0001 ? duration : 0.0001;
            animation->elapsed = 0.0;
            engine_apply_animation(animation, start_value);
            return animation->id;
        }
    }

    return -1;
}

EXPORT void update_animations(double delta_time) {
    int i;

    for (i = 0; i < ENGINE_MAX_ANIMATIONS; ++i) {
        EngineAnimation *animation = &g_engine.animations[i];
        if (animation->in_use) {
            double t;
            double value;

            animation->elapsed += delta_time;
            t = animation->elapsed / animation->duration;
            if (t > 1.0) {
                t = 1.0;
            }

            value = animation->start_value + (animation->end_value - animation->start_value) * t;
            engine_apply_animation(animation, value);

            if (animation->elapsed >= animation->duration) {
                animation->in_use = 0;
            }
        }
    }
}

EXPORT int audio_load(const char *path) {
    int i;
    for (i = 0; i < ENGINE_MAX_AUDIO; ++i) {
        if (!g_engine.audio[i].in_use) {
            memset(&g_engine.audio[i], 0, sizeof(g_engine.audio[i]));
            g_engine.audio[i].in_use = 1;
            g_engine.audio[i].id = g_engine.next_audio_id++;
            g_engine.audio[i].volume = 1.0;
            strncpy(g_engine.audio[i].path, path ? path : "", sizeof(g_engine.audio[i].path) - 1);
#if ENGINE_HAS_SDL_MIXER
            g_engine.audio[i].chunk = Mix_LoadWAV(g_engine.audio[i].path);
            if (!g_engine.audio[i].chunk) {
                memset(&g_engine.audio[i], 0, sizeof(g_engine.audio[i]));
                return -1;
            }
            g_engine.audio[i].channel = -1;
#endif
            return g_engine.audio[i].id;
        }
    }
    return -1;
}

EXPORT int audio_play(int sound_id) {
    int i;
    for (i = 0; i < ENGINE_MAX_AUDIO; ++i) {
        if (g_engine.audio[i].in_use && g_engine.audio[i].id == sound_id) {
            g_engine.audio[i].playing = 1;
#if ENGINE_HAS_SDL_MIXER
            g_engine.audio[i].channel = Mix_PlayChannel(-1,
                                                        g_engine.audio[i].chunk,
                                                        g_engine.audio[i].loop ? -1 : 0);
            if (g_engine.audio[i].channel >= 0) {
                Mix_Volume(g_engine.audio[i].channel, (int)(g_engine.audio[i].volume * MIX_MAX_VOLUME));
            }
#endif
            return 0;
        }
    }
    return -1;
}

EXPORT int audio_pause(int sound_id) {
    int i;
    for (i = 0; i < ENGINE_MAX_AUDIO; ++i) {
        if (g_engine.audio[i].in_use && g_engine.audio[i].id == sound_id) {
            g_engine.audio[i].playing = 0;
#if ENGINE_HAS_SDL_MIXER
            if (g_engine.audio[i].channel >= 0) {
                Mix_Pause(g_engine.audio[i].channel);
            }
#endif
            return 0;
        }
    }
    return -1;
}

EXPORT int audio_stop(int sound_id) {
    EngineAudioClip *audio = engine_get_audio(sound_id);
    if (!audio) {
        return -1;
    }
    audio->playing = 0;
#if ENGINE_HAS_SDL_MIXER
    if (audio->channel >= 0) {
        Mix_HaltChannel(audio->channel);
        audio->channel = -1;
    }
#endif
    return 0;
}

EXPORT int audio_set_volume(int sound_id, double volume) {
    EngineAudioClip *audio = engine_get_audio(sound_id);
    if (!audio) {
        return -1;
    }
    if (volume < 0.0) {
        volume = 0.0;
    }
    if (volume > 1.0) {
        volume = 1.0;
    }
    audio->volume = volume;
#if ENGINE_HAS_SDL_MIXER
    if (audio->channel >= 0) {
        Mix_Volume(audio->channel, (int)(volume * MIX_MAX_VOLUME));
    }
#endif
    return 0;
}

EXPORT int audio_set_loop(int sound_id, int loop) {
    EngineAudioClip *audio = engine_get_audio(sound_id);
    if (!audio) {
        return -1;
    }
    audio->loop = loop ? 1 : 0;
    return 0;
}

EXPORT int video_load(const char *path) {
    int i;
    for (i = 0; i < ENGINE_MAX_VIDEO; ++i) {
        if (!g_engine.videos[i].in_use) {
            memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
            g_engine.videos[i].in_use = 1;
            g_engine.videos[i].id = g_engine.next_video_id++;
            strncpy(g_engine.videos[i].path, path ? path : "", sizeof(g_engine.videos[i].path) - 1);
#if ENGINE_HAS_FFMPEG
            {
                AVCodecParameters *codec_params;
                const AVCodec *codec;
                int stream_index = -1;
                int j;

                if (avformat_open_input(&g_engine.videos[i].format_context, g_engine.videos[i].path, NULL, NULL) < 0) {
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                if (avformat_find_stream_info(g_engine.videos[i].format_context, NULL) < 0) {
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                for (j = 0; j < (int)g_engine.videos[i].format_context->nb_streams; ++j) {
                    if (g_engine.videos[i].format_context->streams[j]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
                        stream_index = j;
                        break;
                    }
                }

                if (stream_index < 0) {
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                g_engine.videos[i].video_stream_index = stream_index;
                codec_params = g_engine.videos[i].format_context->streams[stream_index]->codecpar;
                codec = avcodec_find_decoder(codec_params->codec_id);
                if (!codec) {
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                g_engine.videos[i].codec_context = avcodec_alloc_context3(codec);
                if (!g_engine.videos[i].codec_context ||
                    avcodec_parameters_to_context(g_engine.videos[i].codec_context, codec_params) < 0 ||
                    avcodec_open2(g_engine.videos[i].codec_context, codec, NULL) < 0) {
                    if (g_engine.videos[i].codec_context) {
                        avcodec_free_context(&g_engine.videos[i].codec_context);
                    }
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                g_engine.videos[i].width = g_engine.videos[i].codec_context->width;
                g_engine.videos[i].height = g_engine.videos[i].codec_context->height;
                g_engine.videos[i].frame_rate = av_q2d(g_engine.videos[i].format_context->streams[stream_index]->avg_frame_rate);
                if (g_engine.videos[i].frame_rate <= 0.0) {
                    g_engine.videos[i].frame_rate = 30.0;
                }

                g_engine.videos[i].frame = av_frame_alloc();
                g_engine.videos[i].rgba_frame = av_frame_alloc();
                g_engine.videos[i].packet = av_packet_alloc();
                if (!g_engine.videos[i].frame || !g_engine.videos[i].rgba_frame || !g_engine.videos[i].packet) {
                    if (g_engine.videos[i].packet) {
                        av_packet_free(&g_engine.videos[i].packet);
                    }
                    if (g_engine.videos[i].frame) {
                        av_frame_free(&g_engine.videos[i].frame);
                    }
                    if (g_engine.videos[i].rgba_frame) {
                        av_frame_free(&g_engine.videos[i].rgba_frame);
                    }
                    avcodec_free_context(&g_engine.videos[i].codec_context);
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                g_engine.videos[i].rgba_buffer = (unsigned char *)av_malloc((size_t)av_image_get_buffer_size(AV_PIX_FMT_RGBA,
                                                                                                               g_engine.videos[i].width,
                                                                                                               g_engine.videos[i].height,
                                                                                                               1));
                if (!g_engine.videos[i].rgba_buffer) {
                    av_packet_free(&g_engine.videos[i].packet);
                    av_frame_free(&g_engine.videos[i].frame);
                    av_frame_free(&g_engine.videos[i].rgba_frame);
                    avcodec_free_context(&g_engine.videos[i].codec_context);
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                av_image_fill_arrays(g_engine.videos[i].rgba_frame->data,
                                     g_engine.videos[i].rgba_frame->linesize,
                                     g_engine.videos[i].rgba_buffer,
                                     AV_PIX_FMT_RGBA,
                                     g_engine.videos[i].width,
                                     g_engine.videos[i].height,
                                     1);

                g_engine.videos[i].sws_context = sws_getContext(g_engine.videos[i].width,
                                                                g_engine.videos[i].height,
                                                                g_engine.videos[i].codec_context->pix_fmt,
                                                                g_engine.videos[i].width,
                                                                g_engine.videos[i].height,
                                                                AV_PIX_FMT_RGBA,
                                                                SWS_BILINEAR,
                                                                NULL,
                                                                NULL,
                                                                NULL);
                if (!g_engine.videos[i].sws_context) {
                    av_free(g_engine.videos[i].rgba_buffer);
                    av_packet_free(&g_engine.videos[i].packet);
                    av_frame_free(&g_engine.videos[i].frame);
                    av_frame_free(&g_engine.videos[i].rgba_frame);
                    avcodec_free_context(&g_engine.videos[i].codec_context);
                    avformat_close_input(&g_engine.videos[i].format_context);
                    memset(&g_engine.videos[i], 0, sizeof(g_engine.videos[i]));
                    return -1;
                }

                engine_video_reset_decode(&g_engine.videos[i]);
                engine_video_decode_next_frame(&g_engine.videos[i]);
            }
#endif
            return g_engine.videos[i].id;
        }
    }
    return -1;
}

EXPORT int video_play(int video_id) {
    int i;
    for (i = 0; i < ENGINE_MAX_VIDEO; ++i) {
        if (g_engine.videos[i].in_use && g_engine.videos[i].id == video_id) {
            g_engine.videos[i].playing = 1;
#if ENGINE_HAS_FFMPEG
            engine_video_reset_decode(&g_engine.videos[i]);
            engine_video_decode_next_frame(&g_engine.videos[i]);
#else
            g_engine.videos[i].time_seconds = 0.0;
#endif
            return 0;
        }
    }
    return -1;
}

EXPORT int video_pause(int video_id) {
    int i;
    for (i = 0; i < ENGINE_MAX_VIDEO; ++i) {
        if (g_engine.videos[i].in_use && g_engine.videos[i].id == video_id) {
            g_engine.videos[i].playing = 0;
            return 0;
        }
    }
    return -1;
}

EXPORT int video_stop(int video_id) {
    EngineVideoClip *video = engine_get_video(video_id);
    if (!video) {
        return -1;
    }
    video->playing = 0;
#if ENGINE_HAS_FFMPEG
    engine_video_reset_decode(video);
    engine_video_decode_next_frame(video);
#endif
    return 0;
}

EXPORT int load_font(const char *path, int size) {
    int i;
    for (i = 0; i < ENGINE_MAX_FONTS; ++i) {
        if (!g_engine.fonts[i].in_use) {
            memset(&g_engine.fonts[i], 0, sizeof(g_engine.fonts[i]));
            g_engine.fonts[i].in_use = 1;
            g_engine.fonts[i].id = g_engine.next_font_id++;
            g_engine.fonts[i].size = size;
            strncpy(g_engine.fonts[i].path, path ? path : "", sizeof(g_engine.fonts[i].path) - 1);
#if ENGINE_HAS_SDL_TTF
            g_engine.fonts[i].native_font = TTF_OpenFont(g_engine.fonts[i].path, size);
            if (!g_engine.fonts[i].native_font) {
                memset(&g_engine.fonts[i], 0, sizeof(g_engine.fonts[i]));
                return -1;
            }
#endif
            return g_engine.fonts[i].id;
        }
    }
    return -1;
}

EXPORT int image_load(const char *path) {
    int i;

    for (i = 0; i < ENGINE_MAX_IMAGES; ++i) {
        if (!g_engine.images[i].in_use) {
            memset(&g_engine.images[i], 0, sizeof(g_engine.images[i]));
            g_engine.images[i].in_use = 1;
            g_engine.images[i].id = i + 1;
            strncpy(g_engine.images[i].path, path ? path : "", sizeof(g_engine.images[i].path) - 1);
#if ENGINE_HAS_SDL_IMAGE
            {
                SDL_Surface *surface = IMG_Load(g_engine.images[i].path);
                if (!surface) {
                    memset(&g_engine.images[i], 0, sizeof(g_engine.images[i]));
                    return -1;
                }
                g_engine.images[i].width = surface->w;
                g_engine.images[i].height = surface->h;
                SDL_FreeSurface(surface);
            }
#endif
            return g_engine.images[i].id;
        }
    }

    return -1;
}

EXPORT void clear_window(int window_id, int r, int g, int b, int a) {
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return;
    }
    window->clear_color = engine_make_color(r, g, b, a);
}

EXPORT void clear(int r, int g, int b) {
    EngineWindow *window = engine_get_primary_window();
    if (!window) {
        return;
    }
    clear_window(window->id, r, g, b, 255);
}

EXPORT int render_draw_rect(int window_id,
                            int x,
                            int y,
                            int w,
                            int h,
                            int r,
                            int g,
                            int b,
                            int a,
                            int filled,
                            int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_RECT;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.alpha = (double)a / 255.0;
    command.data.rect.x = x;
    command.data.rect.y = y;
    command.data.rect.w = w;
    command.data.rect.h = h;
    command.data.rect.filled = filled;

    return engine_push_command(window, &command);
}

EXPORT int render_draw_pixel(int window_id,
                             int x,
                             int y,
                             int r,
                             int g,
                             int b,
                             int a,
                             int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_PIXEL;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.data.pixel.x = x;
    command.data.pixel.y = y;
    return engine_push_command(window, &command);
}

EXPORT int render_draw_circle(int window_id,
                              int x,
                              int y,
                              int radius,
                              int r,
                              int g,
                              int b,
                              int a,
                              int filled,
                              int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_CIRCLE;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.data.circle.x = x;
    command.data.circle.y = y;
    command.data.circle.radius = radius;
    command.data.circle.filled = filled;
    return engine_push_command(window, &command);
}

EXPORT int render_draw_rounded_rect(int window_id,
                                    int x,
                                    int y,
                                    int w,
                                    int h,
                                    int radius,
                                    int r,
                                    int g,
                                    int b,
                                    int a,
                                    int filled,
                                    int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_ROUNDED_RECT;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.data.rounded_rect.x = x;
    command.data.rounded_rect.y = y;
    command.data.rounded_rect.w = w;
    command.data.rounded_rect.h = h;
    command.data.rounded_rect.radius = radius;
    command.data.rounded_rect.filled = filled;
    return engine_push_command(window, &command);
}

EXPORT int render_draw_gradient_rect(int window_id,
                                     int x,
                                     int y,
                                     int w,
                                     int h,
                                     int start_r,
                                     int start_g,
                                     int start_b,
                                     int start_a,
                                     int end_r,
                                     int end_g,
                                     int end_b,
                                     int end_a,
                                     int vertical,
                                     int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);
    if (!window) {
        return -1;
    }
    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_GRADIENT_RECT;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(start_r, start_g, start_b, start_a);
    command.data.gradient_rect.x = x;
    command.data.gradient_rect.y = y;
    command.data.gradient_rect.w = w;
    command.data.gradient_rect.h = h;
    command.data.gradient_rect.end_color = engine_make_color(end_r, end_g, end_b, end_a);
    command.data.gradient_rect.vertical = vertical;
    return engine_push_command(window, &command);
}

EXPORT void draw_rect(int x, int y, int w, int h, int r, int g, int b) {
    EngineWindow *window = engine_get_primary_window();
    if (!window) {
        return;
    }
    render_draw_rect(window->id, x, y, w, h, r, g, b, 255, 1, 0);
}

EXPORT int render_draw_line(int window_id,
                            int x1,
                            int y1,
                            int x2,
                            int y2,
                            int r,
                            int g,
                            int b,
                            int a,
                            int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_LINE;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.data.line.x1 = x1;
    command.data.line.y1 = y1;
    command.data.line.x2 = x2;
    command.data.line.y2 = y2;

    return engine_push_command(window, &command);
}

EXPORT int render_draw_text(int window_id,
                            const char *text,
                            int x,
                            int y,
                            int font_id,
                            int r,
                            int g,
                            int b,
                            int a,
                            int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);

    if (!window || !text) {
        return -1;
    }

    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_TEXT;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(r, g, b, a);
    command.data.text.x = x;
    command.data.text.y = y;
    command.data.text.font_id = font_id;
    strncpy(command.data.text.text, text, sizeof(command.data.text.text) - 1);

    return engine_push_command(window, &command);
}

EXPORT int render_draw_image(int window_id,
                             int image_id,
                             int x,
                             int y,
                             int w,
                             int h,
                             int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_IMAGE;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(255, 255, 255, 255);
    command.data.image.image_id = image_id;
    command.data.image.x = x;
    command.data.image.y = y;
    command.data.image.w = w;
    command.data.image.h = h;

    return engine_push_command(window, &command);
}

EXPORT int video_draw(int window_id,
                      int video_id,
                      int x,
                      int y,
                      int w,
                      int h,
                      int layer_id) {
    DrawCommand command;
    EngineWindow *window = engine_get_window(window_id);

    if (!window) {
        return -1;
    }

    memset(&command, 0, sizeof(command));
    command.type = DRAW_COMMAND_VIDEO;
    command.layer_id = layer_id;
    command.z_index = engine_get_layer_z(window, layer_id);
    command.color = engine_make_color(200, 200, 255, 255);
    command.data.video.video_id = video_id;
    command.data.video.x = x;
    command.data.video.y = y;
    command.data.video.w = w;
    command.data.video.h = h;

    return engine_push_command(window, &command);
}

EXPORT void render_present_window(int window_id) {
    EngineWindow *window = engine_get_window(window_id);
    engine_flush_window(window);
}

EXPORT void render_present(void) {
    int i;
    for (i = 0; i < ENGINE_MAX_WINDOWS; ++i) {
        if (g_engine.windows[i].in_use) {
            engine_flush_window(&g_engine.windows[i]);
        }
    }
}

EXPORT void present(void) {
    render_present();
}

EXPORT void engine_run_loop_step(void) {
    double now;

    if (!g_engine.initialized && engine_init() != 0) {
        return;
    }

    now = engine_now_seconds();
    g_engine.delta_time = now - g_engine.last_tick_seconds;
    if (g_engine.delta_time < 0.0) {
        g_engine.delta_time = 0.0;
    }
    g_engine.last_tick_seconds = now;

    engine_poll_events();
    update_animations(g_engine.delta_time);
    render_present();
}

EXPORT void engine_run_loop(void) {
    if (!g_engine.initialized && engine_init() != 0) {
        return;
    }

    g_engine.running = 1;
    while (g_engine.running) {
        engine_run_loop_step();
        if (g_engine.input.quit_requested) {
            break;
        }
#if ENGINE_HAS_SDL
        SDL_Delay(1);
#endif
    }
}

EXPORT void shutdown(void) {
    engine_shutdown();
}
