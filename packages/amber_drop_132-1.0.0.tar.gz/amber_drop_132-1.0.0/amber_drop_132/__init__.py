"""Open Beta Grid"""
__version__ = "1.0.0"
