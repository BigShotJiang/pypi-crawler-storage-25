"""Transient Table Mixin for routing ephemeral pipeline data to dedicated transient resources."""

import os
from typing import Optional
from aws_lambda_powertools import Logger

from geek_cafe_saas_sdk.core.services.storage_validator import (
    classify_resource,
    ResourceClassification,
)

logger = Logger(__name__)

DEFAULT_TTL_SECONDS = 1_209_600  # 14 days


class TransientTableMixin:
    """Mixin for services that route data to dedicated transient resources.

    Provides static utility methods for resolving the transient DynamoDB table
    name, the transient S3 bucket, and reading the configurable TTL duration
    from environment variables.
    """

    @staticmethod
    def resolve_transient_table_name(
        fallback_table_name: Optional[str] = None,
    ) -> str:
        """Resolve the transient table name from environment.

        Resolution order:
        1. ``DYNAMODB_TRANSIENT_TABLE_NAME`` environment variable
        2. ``fallback_table_name`` parameter (typically the main table name)
        3. ``DYNAMODB_TABLE_NAME`` or ``TABLE_NAME`` environment variable

        Args:
            fallback_table_name: Optional table name to use when the transient
                env var is not set (usually the main table name).

        Returns:
            The resolved table name.

        Raises:
            ValueError: If no table name can be resolved from any source.
        """
        resolved: Optional[str] = None

        transient = os.getenv("DYNAMODB_TRANSIENT_TABLE_NAME")
        if transient:
            resolved = transient
        elif fallback_table_name:
            logger.warning(
                "DYNAMODB_TRANSIENT_TABLE_NAME not set, falling back to main table"
            )
            resolved = fallback_table_name
        else:
            main = os.getenv("DYNAMODB_TABLE_NAME") or os.getenv("TABLE_NAME")
            if main:
                logger.warning(
                    "DYNAMODB_TRANSIENT_TABLE_NAME not set, falling back to DYNAMODB_TABLE_NAME"
                )
                resolved = main

        if resolved is None:
            raise ValueError(
                "No table name available. Set DYNAMODB_TRANSIENT_TABLE_NAME or DYNAMODB_TABLE_NAME."
            )

        classification = classify_resource(resolved)
        if classification != ResourceClassification.TRANSIENT:
            logger.warning(
                "Resolved transient table '%s' is not classified as transient",
                resolved,
            )

        return resolved

    @staticmethod
    def get_ttl_duration() -> int:
        """Get TTL duration in seconds from environment or use the default.

        Reads ``TRANSIENT_DATA_TTL_SECONDS`` environment variable. Falls back
        to :data:`DEFAULT_TTL_SECONDS` (14 days) when not set.

        Returns:
            TTL duration in seconds.
        """
        raw = os.getenv("TRANSIENT_DATA_TTL_SECONDS")
        if raw:
            return int(raw)
        return DEFAULT_TTL_SECONDS

    @staticmethod
    def resolve_transient_bucket(fallback_bucket: Optional[str] = None) -> str:
        """Resolve the transient S3 bucket name from environment.

        Used by handlers that read/write intermediate pipeline files
        (output batch partials, per-profile calculation JSONs, batch warnings).

        Resolution order:
        1. ``S3_TRANSIENT_BUCKET`` environment variable
        2. ``fallback_bucket`` parameter (typically the workload bucket)
        3. ``S3_BUCKET`` or ``FILE_SYSTEM_BUCKET`` environment variable

        Args:
            fallback_bucket: Optional bucket name to use when the transient
                env var is not set (usually the workload bucket name).

        Returns:
            The resolved bucket name.
        """
        transient = os.getenv("S3_TRANSIENT_BUCKET")
        if transient:
            resolved = transient
        elif fallback_bucket:
            resolved = fallback_bucket
        else:
            workload = os.getenv("S3_BUCKET") or os.getenv("FILE_SYSTEM_BUCKET")
            if workload:
                resolved = workload
            else:
                return ""

        classification = classify_resource(resolved)
        if classification != ResourceClassification.TRANSIENT:
            logger.warning(
                "Resolved transient bucket '%s' is not classified as transient",
                resolved,
            )

        return resolved
