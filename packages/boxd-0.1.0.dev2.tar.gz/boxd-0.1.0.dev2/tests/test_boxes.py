"""Test VM listing operations (sync)."""


def test_list_vms(compute):
    vms = compute.box.list()
    assert isinstance(vms, list)
