"""Test exec operations (sync)."""


def test_exec_simple(box):
    result = box.exec("echo", "hello")
    assert result.exit_code == 0
    assert result.success
    assert "hello" in result.stdout


def test_exec_exit_code(box):
    result = box.exec("false")
    assert result.exit_code != 0
    assert not result.success


def test_exec_multiline_output(box):
    result = box.exec("seq", "3")
    assert result.exit_code == 0
    lines = result.stdout.strip().split("\n")
    assert lines == ["1", "2", "3"]
