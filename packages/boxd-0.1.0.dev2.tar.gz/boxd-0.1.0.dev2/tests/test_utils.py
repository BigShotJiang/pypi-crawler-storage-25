"""Unit tests for boxd._utils — pure functions, no network."""

from __future__ import annotations

from boxd._utils import resolve_endpoint


def test_http_scheme_strips_and_disables_tls():
    e = resolve_endpoint("http://boxd.sh:9443")
    assert e.host == "boxd.sh:9443"
    assert e.use_tls is False


def test_https_scheme_strips_and_enables_tls():
    e = resolve_endpoint("https://grpc.boxd.sh:443")
    assert e.host == "grpc.boxd.sh:443"
    assert e.use_tls is True


def test_bare_localhost_is_plaintext():
    e = resolve_endpoint("localhost:9443")
    assert e.host == "localhost:9443"
    assert e.use_tls is False


def test_bare_loopback_is_plaintext():
    e = resolve_endpoint("127.0.0.1:9443")
    assert e.host == "127.0.0.1:9443"
    assert e.use_tls is False


def test_bare_non_local_defaults_to_tls():
    e = resolve_endpoint("grpc.boxd.sh:443")
    assert e.host == "grpc.boxd.sh:443"
    assert e.use_tls is True


def test_explicit_http_localhost_overrides_local_default():
    e = resolve_endpoint("http://localhost:9443")
    assert e.host == "localhost:9443"
    assert e.use_tls is False


def test_explicit_https_localhost_forces_tls():
    e = resolve_endpoint("https://localhost:443")
    assert e.host == "localhost:443"
    assert e.use_tls is True
