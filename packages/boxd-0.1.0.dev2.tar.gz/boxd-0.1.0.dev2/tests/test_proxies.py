"""Test proxy operations (sync)."""


def test_list_proxies(box):
    proxies = box.proxies()
    assert isinstance(proxies, list)
    assert len(proxies) >= 1
    default = [p for p in proxies if p.is_default]
    assert len(default) == 1


def test_create_and_delete_proxy(box):
    proxy = box.create_proxy("sdk-test-sync", port=3000)
    assert proxy.name == "sdk-test-sync"
    assert proxy.port == 3000
    assert proxy.vm_name == box.name

    proxies = box.proxies()
    names = [p.name for p in proxies]
    assert "sdk-test-sync" in names

    box.delete_proxy("sdk-test-sync")
    proxies = box.proxies()
    names = [p.name for p in proxies]
    assert "sdk-test-sync" not in names


def test_set_proxy_port(box):
    box.set_proxy_port(9999)
    proxies = box.proxies()
    default = [p for p in proxies if p.is_default][0]
    assert default.port == 9999
    box.set_proxy_port(8000)
