"""v2 tests — domains, networks, tokens. Fast list-only tests (no VM needed)."""

import pytest

from boxd import Token, TokenInfo


def test_list_domains_empty(compute):
    domains = compute.domain.list()
    assert isinstance(domains, list)


def test_list_networks_has_default(compute):
    """User always has a default network created at signup."""
    networks = compute.network.list()
    assert isinstance(networks, list)
    assert len(networks) >= 1
    default_id = compute.whoami().default_network_id
    assert any(n.id == default_id for n in networks)


def test_create_token(compute):
    token = compute.token.create(expires_in=3600)
    assert isinstance(token, Token)
    assert token.token.startswith("eyJ")  # JWT header
    assert token.expires_at > 0


def test_list_tokens_returns_list(compute):
    """Server currently stubs ListTokens to return []. Verify shape only."""
    tokens = compute.token.list()
    assert isinstance(tokens, list)
    assert all(isinstance(t, TokenInfo) for t in tokens)


@pytest.mark.skip(reason="server stub: ListTokens always returns empty, can't verify revoke")
def test_create_and_revoke_token(compute):
    created = compute.token.create(expires_in=3600)
    tokens = compute.token.list()
    matching = [t for t in tokens if t.expires_at == created.expires_at]
    assert matching
    jti = matching[0].jti
    compute.token.revoke(jti)
    tokens_after = compute.token.list()
    assert all(t.jti != jti for t in tokens_after)


def test_token_roundtrip(compute):
    """Create a token, use it to authenticate a new Compute, verify same user."""
    from boxd import Compute

    original_user = compute.whoami().user_id

    token = compute.token.create(expires_in=3600)
    with Compute(
        token=token.token,
        api_url="localhost:9443",
        exchange_url="http://localhost:8080/api/v1/auth/token",
    ) as c2:
        assert c2.whoami().user_id == original_user
