"""Test VM lifecycle operations (sync)."""

import pytest
from boxd.errors import NotFoundError


def test_get_by_id(compute, box):
    fetched = compute.box.get(box.id)
    assert fetched.id == box.id
    assert fetched.name == box.name


def test_get_by_name(compute, box):
    fetched = compute.box.get(box.name)
    assert fetched.id == box.id
    assert fetched.name == box.name


def test_get_nonexistent(compute):
    with pytest.raises(NotFoundError):
        compute.box.get("nonexistent-vm-name-xyz")
