"""v2 e2e tests — domains (require VM), stream_logs, PTY exec."""

import time

import pytest

pytestmark = pytest.mark.e2e


def _wait_ready(box, timeout=90):
    for i in range(timeout):
        try:
            box.exec("true")
            return i
        except Exception:
            time.sleep(1)
    pytest.fail(f"VM {box.name} not ready after {timeout}s")


# ── Domains ─────────────────────────────────────────────────────

def test_domain_bind_list_unbind(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)

        test_domain = f"sdk-test-{box.name}.example.com"

        compute.domain.bind(test_domain, box)

        domains = compute.domain.list()
        assert any(
            d.domain == test_domain and d.vm_id == box.id for d in domains
        )

        compute.domain.unbind(test_domain)

        domains_after = compute.domain.list()
        assert not any(d.domain == test_domain for d in domains_after)
    finally:
        box.destroy()


def test_domain_bind_by_vm_name(compute):
    """Verify bind() can accept a VM name string, not just Box object."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        test_domain = f"sdk-name-{box.name}.example.com"

        compute.domain.bind(test_domain, box.name)
        domains = compute.domain.list()
        assert any(d.domain == test_domain for d in domains)

        compute.domain.unbind(test_domain)
    finally:
        box.destroy()


# ── Stream logs ─────────────────────────────────────────────────

@pytest.mark.skip(reason="server: StreamLogs returns UNIMPLEMENTED")
def test_stream_logs_no_follow(compute):
    """Stream all current log output without following."""
    box = compute.box.create()
    try:
        _wait_ready(box)
        chunks = list(box.stream_logs(follow=False))
        combined = b"".join(chunks)
        assert len(combined) > 0
    finally:
        box.destroy()


# ── PTY exec ────────────────────────────────────────────────────

def test_exec_without_pty(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)
        # Without PTY, `tty` outputs "not a tty"
        result = box.exec("tty")
        assert result.exit_code != 0 or "not a tty" in result.stdout
    finally:
        box.destroy()


def test_exec_with_pty(compute):
    box = compute.box.create()
    try:
        _wait_ready(box)
        # With PTY, `tty` outputs a /dev/pts/N path
        result = box.exec("tty", pty=True)
        assert result.exit_code == 0
        assert "/dev/" in result.stdout
    finally:
        box.destroy()
