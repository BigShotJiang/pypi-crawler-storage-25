"""Test API key authentication and token exchange (sync)."""

import pytest
from boxd import Compute
from boxd.errors import AuthenticationError


def test_whoami(compute):
    me = compute.whoami()
    assert me.user_id
    assert isinstance(me.fingerprints, list)


def test_config(compute):
    cfg = compute.config()
    assert cfg.zone


def test_invalid_api_key():
    with Compute(
        api_key="bxd_invalid_key_12345",
        api_url="localhost:9443",
        exchange_url="http://localhost:8080/api/v1/auth/token",
    ) as c:
        with pytest.raises(AuthenticationError):
            c.whoami()


def test_no_credentials(monkeypatch):
    monkeypatch.delenv("BOXD_API_KEY", raising=False)
    monkeypatch.delenv("BOXD_TOKEN", raising=False)
    with pytest.raises(AuthenticationError):
        Compute()
