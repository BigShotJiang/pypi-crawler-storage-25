"""Test file I/O operations (sync)."""

import pytest
from boxd.errors import BoxdError


def test_write_and_read_bytes(box):
    box.write_file(b"hello world sync", "/tmp/sdk-sync-bytes.txt")
    data = box.read_file("/tmp/sdk-sync-bytes.txt")
    assert data == b"hello world sync"


def test_write_and_read_string(box):
    box.write_file("string content\nwith newlines\n", "/tmp/sdk-sync-str.txt")
    data = box.read_file("/tmp/sdk-sync-str.txt")
    assert data == b"string content\nwith newlines\n"


def test_read_nonexistent_file(box):
    with pytest.raises(BoxdError):
        box.read_file("/tmp/this-file-does-not-exist-sync-xyz")
