"""Box — a running VM with lifecycle, exec, file, and proxy methods."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import grpc.aio

from ._generated import api_pb2
from ._utils import GrpcCaller
from .errors import from_grpc_error
from .exec import ExecProcess, ExecResult, StreamReader, StreamWriter
from .types import Proxy, ResumeResult, SuspendResult

if TYPE_CHECKING:
    from .client import Compute


@dataclass
class Box(GrpcCaller):
    """A boxd VM."""

    id: str
    name: str
    image: str
    public_ip: str
    status: str
    _client: Compute = field(repr=False)
    url: str = ""
    boot_time_ms: int | None = None
    #: Source VM id, set when this VM was created via ``compute.box.fork(...)``.
    forked_from: str | None = None
    #: Restart policy, populated by ``compute.box.get(...)`` (server doesn't return it on create/fork).
    restart_policy: str | None = None
    #: Disk size in bytes, populated by ``compute.box.get(...)``.
    disk_bytes: int | None = None
    #: Auto-suspend timeout in seconds (0 = disabled), populated by ``compute.box.get(...)``.
    auto_suspend_timeout_secs: int | None = None

    # ── Lifecycle ──────────────────────────────────────────────────

    async def destroy(self) -> None:
        """Destroy this VM."""
        await self._call("DestroyVm", api_pb2.DestroyVmRequest(vm_id=self.id))
        self.status = "destroyed"

    async def reboot(self) -> None:
        """Reboot this VM."""
        await self._call("RebootVm", api_pb2.RebootVmRequest(vm_id=self.id))
        self.status = "running"

    async def start(self) -> None:
        """Start this VM."""
        await self._call("StartVm", api_pb2.StartVmRequest(vm_id=self.id))
        self.status = "running"

    async def stop(self) -> None:
        """Stop this VM."""
        await self._call("StopVm", api_pb2.StopVmRequest(vm_id=self.id))
        self.status = "stopped"

    async def suspend(self) -> SuspendResult:
        """Suspend this VM."""
        resp = await self._call("SuspendVm", api_pb2.SuspendVmRequest(vm_id=self.id))
        self.status = "suspended"
        return SuspendResult(suspend_us=resp.suspend_us)

    async def resume(self) -> ResumeResult:
        """Resume this VM from suspension."""
        resp = await self._call("ResumeVm", api_pb2.ResumeVmRequest(vm_id=self.id))
        self.status = "running"
        return ResumeResult(resume_us=resp.resume_us)

    # ── Exec ──────────────────────────────────────────────────────

    async def exec(
        self,
        *args: str,
        stream: bool = False,
        interactive: bool = False,
        pty: bool = False,
        text: bool = True,
        timeout: float | None = None,
        env: dict[str, str] | None = None,
    ) -> ExecResult | ExecProcess:
        """Execute a command in this VM.

        Args:
            *args: Command and arguments (e.g. ``"ls", "-la"``).
            stream: If True, return an :class:`ExecProcess` for streaming I/O.
            interactive: Enable interactive mode (implies pty).
            pty: Allocate a pseudo-terminal.
            text: (unused, reserved for future use).
            timeout: Timeout in seconds for non-streaming mode.
            env: Extra environment variables for the command.
        """
        use_tty = pty or interactive
        init_chunk = self._build_exec_chunk(list(args), use_tty, env)

        if stream:
            return await self._exec_stream(init_chunk)
        return await self._exec_simple(init_chunk, timeout)

    def _build_exec_chunk(
        self,
        command: list[str],
        tty: bool,
        env: dict[str, str] | None,
    ) -> api_pb2.ExecChunk:
        """Build the initial ExecChunk for a command."""
        import shlex

        cmd_str = " ".join(shlex.quote(arg) for arg in command)
        if env:
            env_prefix = " ".join(
                f"{k}={shlex.quote(v)}" for k, v in env.items()
            )
            cmd_str = f"{env_prefix} {cmd_str}"
        return api_pb2.ExecChunk(vm_id=self.id, command=cmd_str, tty=tty)

    async def _exec_simple(
        self,
        init_chunk: api_pb2.ExecChunk,
        timeout: float | None,
    ) -> ExecResult:
        """Run a command and collect all output."""
        stub = await self._client._ensure_channel()

        async def request_iter():
            yield init_chunk

        try:
            metadata = await self._client._auth.metadata()
            call = stub.Exec(request_iter(), timeout=timeout, metadata=metadata)
            stdout_parts: list[bytes] = []
            exit_code = -1

            async for chunk in call:
                if chunk.data:
                    stdout_parts.append(chunk.data)
                exit_code = chunk.exit_code

            raw = b"".join(stdout_parts)
            return ExecResult(
                stdout=raw.decode("utf-8", errors="replace"),
                stderr="",
                exit_code=exit_code,
            )
        except grpc.aio.AioRpcError as e:
            raise from_grpc_error(e) from e

    async def _exec_stream(
        self,
        init_chunk: api_pb2.ExecChunk,
    ) -> ExecProcess:
        """Run a command with streaming I/O."""
        stub = await self._client._ensure_channel()

        stdout_reader = StreamReader()
        stderr_reader = StreamReader()
        stdin_writer = StreamWriter()

        process = ExecProcess(
            stdout=stdout_reader,
            stderr=stderr_reader,
            stdin=stdin_writer,
        )

        async def request_iter():
            yield init_chunk
            while True:
                data = await stdin_writer._get()
                stdin_writer._task_done()
                if data is None:
                    break
                yield api_pb2.ExecChunk(data=data, stdin=True)

        async def relay(call):
            exit_code = -1
            try:
                async for chunk in call:
                    if chunk.data:
                        stdout_reader._feed(chunk.data)
                    exit_code = chunk.exit_code
            except grpc.aio.AioRpcError as e:
                process._set_error(from_grpc_error(e))
            else:
                process._set_exit_code(exit_code)
            finally:
                stdout_reader._feed_eof()
                stderr_reader._feed_eof()

        try:
            metadata = await self._client._auth.metadata()
            call = stub.Exec(request_iter(), metadata=metadata)
        except grpc.aio.AioRpcError as e:
            raise from_grpc_error(e) from e

        process._relay_task = asyncio.create_task(relay(call))
        return process

    # ── Files ─────────────────────────────────────────────────────

    async def write_file(self, source: str | bytes | Path, dest: str) -> None:
        """Write a file to the VM.

        Args:
            source: File content as bytes or str, or a ``Path`` to read from disk.
            dest: Destination path inside the VM.

        To upload a local file, pass a ``Path`` object::

            await box.write_file(Path("local/file.py"), "/app/file.py")
        """
        if isinstance(source, bytes):
            data = source
        elif isinstance(source, Path):
            data = source.read_bytes()
        else:
            data = source.encode()
        await self._call(
            "UploadFile",
            api_pb2.UploadFileRequest(vm_id=self.id, path=dest, data=data),
        )

    async def read_file(self, path: str) -> bytes:
        """Download a file from the VM.

        Args:
            path: Path inside the VM.

        Returns:
            File contents as bytes.
        """
        resp = await self._call(
            "DownloadFile",
            api_pb2.DownloadFileRequest(vm_id=self.id, path=path),
        )
        return resp.data

    # ── Proxies ───────────────────────────────────────────────────

    async def proxies(self) -> list[Proxy]:
        """List proxies for this VM."""
        resp = await self._call(
            "ListProxies",
            api_pb2.ListProxiesRequest(vm_name=self.name),
        )
        return [
            Proxy(
                name=p.name,
                vm_name=p.vm_name,
                domain=p.domain,
                port=p.port,
                is_default=p.is_default,
            )
            for p in resp.proxies
        ]

    async def create_proxy(self, name: str, port: int = 0) -> Proxy:
        """Create a new proxy subdomain for this VM."""
        resp = await self._call(
            "CreateProxy",
            api_pb2.CreateProxyRequest(name=name, vm_name=self.name, port=port),
        )
        return Proxy(
            name=resp.name,
            vm_name=resp.vm_name,
            domain=resp.domain,
            port=resp.port,
            is_default=False,
        )

    async def delete_proxy(self, name: str) -> None:
        """Delete a proxy subdomain."""
        await self._call(
            "DeleteProxy",
            api_pb2.DeleteProxyRequest(name=name, vm_name=self.name),
        )

    async def set_proxy_port(self, port: int, name: str = "") -> None:
        """Change the port for a proxy.

        Args:
            port: New target port.
            name: Proxy name (empty string for the default proxy).
        """
        await self._call(
            "SetProxyPort",
            api_pb2.SetProxyPortRequest(name=name, vm_name=self.name, port=str(port)),
        )

    # ── Logs ─────────────────────────────────────────────────────

    async def stream_logs(self, follow: bool = False):
        """Stream console log chunks from the VM.

        Args:
            follow: If True, keep the stream open and yield new chunks as
                they arrive. If False, yield only the log content currently
                available, then end.

        Yields:
            ``bytes`` chunks of raw log data.
        """
        stub = await self._client._ensure_channel()
        try:
            metadata = await self._client._auth.metadata()
            call = stub.StreamLogs(
                api_pb2.StreamLogsRequest(vm_id=self.id, follow=follow),
                metadata=metadata,
            )
            async for chunk in call:
                if chunk.data:
                    yield chunk.data
        except grpc.aio.AioRpcError as e:
            raise from_grpc_error(e) from e
