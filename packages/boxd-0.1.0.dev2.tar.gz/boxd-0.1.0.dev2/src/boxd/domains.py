"""DomainService — bind, unbind, and list external domains."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._generated import api_pb2
from ._utils import GrpcCaller
from .types import Domain

if TYPE_CHECKING:
    from .box import Box
    from .client import Compute


class DomainService(GrpcCaller):
    """Manage external domains bound to VMs."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def bind(self, domain: str, vm: Box | str) -> None:
        """Bind an external domain to a VM.

        Args:
            domain: The external domain name (e.g. ``"app.example.com"``).
            vm: A Box object, VM name, or VM ID.

        The domain's DNS must already point to the boxd proxy. This call only
        configures the proxy to route traffic for ``domain`` to the given VM.
        """
        # Resolve Box/name/id to VM ID
        if hasattr(vm, "id"):
            vm_id = vm.id
        else:
            resolved = await self._client.box.get(vm)
            vm_id = resolved.id

        await self._call(
            "BindDomain",
            api_pb2.BindDomainRequest(domain=domain, vm_id=vm_id),
        )

    async def unbind(self, domain: str) -> None:
        """Remove the binding for an external domain."""
        await self._call(
            "UnbindDomain",
            api_pb2.UnbindDomainRequest(domain=domain),
        )

    async def list(self) -> list[Domain]:
        """List all external domains bound to this user's VMs."""
        resp = await self._call("ListDomains", api_pb2.ListDomainsRequest())
        return [Domain(domain=d.domain, vm_id=d.vm_id) for d in resp.domains]
