"""BoxService — create, list, get, and fork VMs."""

from __future__ import annotations

from typing import TYPE_CHECKING

import grpc.aio

from ._generated import api_pb2
from ._utils import GrpcCaller, parse_size
from .errors import NotFoundError, from_grpc_error
from .types import BoxConfig

if TYPE_CHECKING:
    from .box import Box
    from .client import Compute


def _box_config_to_proto(config: BoxConfig | None) -> api_pb2.VmConfig | None:
    """Convert a BoxConfig dataclass to a VmConfig protobuf message."""
    if config is None:
        return None

    vm_config = api_pb2.VmConfig()

    if config.vcpu:
        vm_config.vcpu = config.vcpu
    if config.memory:
        vm_config.memory_bytes = parse_size(config.memory)
    if config.disk:
        vm_config.disk_bytes = parse_size(config.disk)

    if config.lifecycle:
        vm_config.srf.auto_suspend_timeout_secs = config.lifecycle.auto_suspend_timeout
        vm_config.srf.auto_destroy_timeout_secs = config.lifecycle.auto_destroy_timeout

    if config.network:
        vm_config.network.ssh = config.network.ssh
        if config.network.proxies:
            for p in config.network.proxies:
                entry = api_pb2.ProxyEntry(name=p.name, port=p.port)
                vm_config.network.proxies.append(entry)

    if config.volumes:
        for v in config.volumes:
            mount = api_pb2.VolumeMount(
                disk_id=v.disk_id,
                mount_path=v.mount_path,
                read_only=v.read_only,
            )
            vm_config.volumes.append(mount)

    return vm_config


def _vm_response_to_box(resp, client: Compute, *, has_url: bool = False) -> Box:
    """Convert a VM response proto to a Box dataclass.

    Works with both GetVmResponse (image_ref field) and
    CreateVmResponse/ForkVmResponse (image field, plus url/boot_time_ms).
    """
    from .box import Box

    image = getattr(resp, "image", "") or getattr(resp, "image_ref", "")
    kwargs: dict = dict(
        id=resp.vm_id,
        name=resp.name,
        image=image,
        public_ip=resp.public_ip,
        status=resp.status,
        _client=client,
    )
    if has_url:
        kwargs["url"] = resp.url
        kwargs["boot_time_ms"] = resp.boot_time_ms or None
    # ForkVmResponse carries source vm id; CreateVm/GetVm don't.
    forked_from = getattr(resp, "forked_from", "")
    if forked_from:
        kwargs["forked_from"] = forked_from
    # GetVmResponse-only fields (it's the only one with image_ref instead of image).
    if hasattr(resp, "image_ref"):
        kwargs["restart_policy"] = resp.restart_policy or None
        kwargs["disk_bytes"] = resp.disk_bytes or None
        kwargs["auto_suspend_timeout_secs"] = resp.auto_suspend_timeout_secs
    return Box(**kwargs)


class BoxService(GrpcCaller):
    """Create, list, get, and fork VMs."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def create(
        self,
        name: str = "",
        image: str = "",
        config: BoxConfig | None = None,
    ) -> Box:
        """Create a new VM."""
        req = api_pb2.CreateVmRequest(name=name)
        if image:
            req.image_ref = image
        if config:
            if config.env:
                for k, v in config.env.items():
                    req.env.append(api_pb2.EnvVar(key=k, value=v))
            if config.cmd:
                req.cmd.extend(config.cmd)
            if config.restart_policy:
                req.restart_policy = config.restart_policy

            proto_config = _box_config_to_proto(config)
            if proto_config is not None:
                req.config.CopyFrom(proto_config)

        resp = await self._call("CreateVm", req)
        return _vm_response_to_box(resp, self._client, has_url=True)

    async def list(self) -> list[Box]:
        """List all VMs."""
        resp = await self._call("ListVms", api_pb2.ListVmsRequest())
        return [_vm_response_to_box(vm, self._client) for vm in resp.vms]

    async def get(self, vm_id: str) -> Box:
        """Get a VM by ID or name.

        Tries by ID first; on NotFoundError falls back to name lookup.
        """
        stub = await self._client._ensure_channel()

        try:
            resp = await stub.GetVm(api_pb2.GetVmRequest(vm_id=vm_id))
            return _vm_response_to_box(resp, self._client)
        except grpc.aio.AioRpcError as e:
            err = from_grpc_error(e)
            if not isinstance(err, NotFoundError):
                raise err from e

        # Fall back to name lookup via list
        all_vms = await self.list()
        for vm in all_vms:
            if vm.name == vm_id:
                return vm
        raise NotFoundError(f"VM not found: {vm_id}")

    async def fork(
        self,
        source: str,
        name: str | None = None,
        config: BoxConfig | None = None,
    ) -> Box:
        """Fork (clone) a VM."""
        source_vm = await self.get(source)
        req = api_pb2.ForkVmRequest(source_vm_id=source_vm.id)
        if name:
            req.name = name

        proto_config = _box_config_to_proto(config)
        if proto_config is not None:
            req.config.CopyFrom(proto_config)

        resp = await self._call("ForkVm", req)
        return _vm_response_to_box(resp, self._client, has_url=True)
