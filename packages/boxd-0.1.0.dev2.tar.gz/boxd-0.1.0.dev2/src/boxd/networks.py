"""NetworkService — create and list user networks."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._generated import api_pb2
from ._utils import GrpcCaller
from .types import Network

if TYPE_CHECKING:
    from .client import Compute


class NetworkService(GrpcCaller):
    """Manage user networks."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def create(self, name: str = "") -> Network:
        """Create a new network.

        Args:
            name: Optional network name.

        Returns:
            A Network with only ``id`` populated. Call :meth:`list` to get
            subnet and status.
        """
        resp = await self._call(
            "CreateNetwork",
            api_pb2.CreateNetworkRequest(name=name),
        )
        return Network(id=resp.network_id, subnet="", status="")

    async def list(self) -> list[Network]:
        """List all of this user's networks."""
        resp = await self._call("ListNetworks", api_pb2.ListNetworksRequest())
        return [
            Network(id=n.network_id, subnet=n.subnet, status=n.status)
            for n in resp.networks
        ]
