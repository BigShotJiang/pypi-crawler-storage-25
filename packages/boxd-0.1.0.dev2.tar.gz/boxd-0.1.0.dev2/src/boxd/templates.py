"""TemplateService — create, list, delete, and instantiate VM templates."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._generated import api_pb2
from ._utils import GrpcCaller, parse_size
from .types import BoxConfig, Template

if TYPE_CHECKING:
    from .box import Box
    from .client import Compute


def _template_info_to_template(info) -> Template:
    """Convert a TemplateInfo proto to a Template dataclass."""
    return Template(
        id=info.template_id,
        name=info.name,
        image=info.image_ref,
        status=info.status,
        vcpu=info.vcpu,
        memory_bytes=info.memory_bytes,
    )


class TemplateService(GrpcCaller):
    """Manage VM templates."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def create(
        self,
        name: str,
        image: str = "",
        config: BoxConfig | None = None,
    ) -> Template:
        """Create a new VM template.

        Args:
            name: Template name.
            image: Base image reference.
            config: Optional VM configuration.

        Returns:
            The created Template.
        """
        from .boxes import _box_config_to_proto

        req = api_pb2.CreateTemplateRequest(name=name)
        if image:
            req.image_ref = image
        if config is not None:
            proto_config = _box_config_to_proto(config)
            if proto_config is not None:
                req.config.CopyFrom(proto_config)

        resp = await self._call("CreateTemplate", req)
        return Template(
            id=resp.template_id,
            name=resp.name,
            image=image,
            status=resp.status,
            vcpu=config.vcpu if config else 0,
            memory_bytes=parse_size(config.memory) if config and config.memory else 0,
        )

    async def list(self) -> list[Template]:
        """List all templates."""
        resp = await self._call("ListTemplates", api_pb2.ListTemplatesRequest())
        return [_template_info_to_template(t) for t in resp.templates]

    async def delete(self, template_id: str) -> None:
        """Delete a template by ID."""
        await self._call(
            "DeleteTemplate",
            api_pb2.DeleteTemplateRequest(template_id=template_id),
        )

    async def create_vm(
        self,
        template: Template | str,
        name: str = "",
        config: BoxConfig | None = None,
    ) -> Box:
        """Create a VM from a template.

        Args:
            template: A Template object or template ID string.
            name: Optional name for the new VM.
            config: Optional VM configuration overrides.

        Returns:
            The newly created Box.
        """
        from .boxes import _box_config_to_proto

        template_id = template.id if isinstance(template, Template) else template

        req = api_pb2.CreateVmFromTemplateRequest(template_id=template_id)
        if name:
            req.name = name
        if config is not None:
            proto_config = _box_config_to_proto(config)
            if proto_config is not None:
                req.config.CopyFrom(proto_config)

        resp = await self._call("CreateVmFromTemplate", req)
        from .boxes import _vm_response_to_box

        return _vm_response_to_box(resp, self._client, has_url=True)
