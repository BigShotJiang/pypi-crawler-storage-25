"""Data types for the boxd SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class BoxConfig:
    vcpu: int = 0
    memory: str = ""
    disk: str = ""
    env: dict[str, str] | None = None
    cmd: list[str] | None = None
    restart_policy: str = "always"
    lifecycle: LifecycleConfig | None = None
    network: NetworkConfig | None = None
    volumes: list[VolumeMount] | None = None


@dataclass
class LifecycleConfig:
    auto_suspend_timeout: int = 0
    auto_destroy_timeout: int = 0


@dataclass
class NetworkConfig:
    ssh: bool = True
    proxies: list[ProxyEntry] | None = None


@dataclass
class ProxyEntry:
    name: str
    port: int = 0


@dataclass
class VolumeMount:
    disk_id: str
    mount_path: str
    read_only: bool = False


@dataclass
class Proxy:
    name: str
    vm_name: str
    domain: str
    port: int
    is_default: bool


@dataclass
class Template:
    id: str
    name: str
    image: str
    status: str
    vcpu: int
    memory_bytes: int


@dataclass
class Disk:
    id: str
    name: str
    size_bytes: int
    status: str
    attachments: list[DiskAttachment] = field(default_factory=list)


@dataclass
class DiskAttachment:
    vm_id: str
    vm_name: str
    mount_path: str
    mount_mode: str


@dataclass
class SuspendResult:
    suspend_us: int


@dataclass
class ResumeResult:
    resume_us: int


@dataclass
class PtyInfo:
    rows: int = 24
    cols: int = 80


@dataclass
class WhoamiResult:
    user_id: str
    fingerprints: list[str]
    default_network_id: str


@dataclass
class ConfigResult:
    default_image: str
    zone: str


@dataclass
class Domain:
    """An external domain bound to a VM."""

    domain: str
    vm_id: str


@dataclass
class Network:
    """A user network."""

    id: str
    subnet: str
    status: str


@dataclass
class Token:
    """A freshly-issued JWT. The raw token is only available at creation time."""

    token: str
    expires_at: int


@dataclass
class TokenInfo:
    """A previously-issued token (from list)."""

    jti: str
    created_at: int
    expires_at: int
