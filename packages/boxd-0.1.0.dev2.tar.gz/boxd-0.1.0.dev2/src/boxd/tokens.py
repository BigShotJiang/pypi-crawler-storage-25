"""TokenService — create, list, and revoke scoped JWT tokens."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._generated import api_pb2
from ._utils import GrpcCaller
from .types import Token, TokenInfo

if TYPE_CHECKING:
    from .client import Compute


class TokenService(GrpcCaller):
    """Manage scoped JWT tokens for delegated access."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def create(self, expires_in: int = 0) -> Token:
        """Create a new scoped JWT token for the current user.

        Args:
            expires_in: TTL in seconds. 0 means server default (24h).

        Returns:
            A :class:`Token` with the raw JWT string. Save it — the raw token
            cannot be retrieved later via :meth:`list`.
        """
        resp = await self._call(
            "CreateToken",
            api_pb2.CreateTokenRequest(expires_in_secs=expires_in),
        )
        return Token(token=resp.token, expires_at=resp.expires_at)

    async def list(self) -> list[TokenInfo]:
        """List metadata about previously-issued tokens (no raw token strings)."""
        resp = await self._call("ListTokens", api_pb2.ListTokensRequest())
        return [
            TokenInfo(
                jti=t.jti,
                created_at=t.created_at,
                expires_at=t.expires_at,
            )
            for t in resp.tokens
        ]

    async def revoke(self, jti: str) -> None:
        """Revoke a token by its JTI (JWT ID)."""
        await self._call("RevokeToken", api_pb2.RevokeTokenRequest(jti=jti))
