"""DiskService — create and list persistent disks; DiskHandle — attach, detach, destroy."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ._generated import api_pb2
from ._utils import GrpcCaller, parse_size

if TYPE_CHECKING:
    from .box import Box
    from .client import Compute


def _resolve_vm_id(box: Box | str) -> str:
    """Extract a VM ID from a Box object or string."""
    return box if isinstance(box, str) else box.id


@dataclass
class DiskHandle(GrpcCaller):
    """A handle to a persistent disk with attach/detach/destroy operations."""

    id: str
    name: str
    size_bytes: int
    status: str
    _client: Compute = field(repr=False)

    async def attach(
        self,
        box: Box | str,
        mount_path: str,
        read_only: bool = False,
    ) -> None:
        """Attach this disk to a VM.

        Args:
            box: A Box object or VM ID string.
            mount_path: Path at which to mount the disk inside the VM.
            read_only: Whether to mount the disk read-only.
        """
        await self._call(
            "AttachDisk",
            api_pb2.AttachDiskRequest(
                disk_id=self.id,
                vm_id=_resolve_vm_id(box),
                mount_path=mount_path,
                read_only=read_only,
            ),
        )

    async def detach(self, box: Box | str) -> None:
        """Detach this disk from a VM.

        Args:
            box: A Box object or VM ID string.
        """
        await self._call(
            "DetachDisk",
            api_pb2.DetachDiskRequest(disk_id=self.id, vm_id=_resolve_vm_id(box)),
        )

    async def destroy(self) -> None:
        """Permanently destroy this disk."""
        await self._call("DestroyDisk", api_pb2.DestroyDiskRequest(disk_id=self.id))
        self.status = "destroyed"


class DiskService(GrpcCaller):
    """Manage persistent disks."""

    def __init__(self, client: Compute) -> None:
        self._client = client

    async def create(self, name: str, size: str) -> DiskHandle:
        """Create a new persistent disk.

        Args:
            name: Disk name.
            size: Human-readable size string, e.g. ``"10G"`` or ``"512M"``.

        Returns:
            A DiskHandle for the created disk.
        """
        resp = await self._call(
            "CreateDisk",
            api_pb2.CreateDiskRequest(name=name, size_bytes=parse_size(size)),
        )
        return DiskHandle(
            id=resp.disk_id,
            name=resp.name,
            size_bytes=resp.size_bytes,
            status=resp.status,
            _client=self._client,
        )

    async def list(self) -> list[DiskHandle]:
        """List all disks."""
        resp = await self._call("ListDisks", api_pb2.ListDisksRequest())
        return [
            DiskHandle(
                id=d.disk_id,
                name=d.name,
                size_bytes=d.size_bytes,
                status=d.status,
                _client=self._client,
            )
            for d in resp.disks
        ]
