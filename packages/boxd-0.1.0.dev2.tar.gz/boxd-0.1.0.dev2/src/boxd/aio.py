"""Async API for the boxd SDK.

Usage::

    from boxd.aio import Compute

    async with Compute(api_key="bxk_...") as c:
        box = await c.box.create("my-vm")
        result = await box.exec("echo", "hello")
        print(result.stdout)
"""

# Re-export async classes under their original names
from .client import Compute
from .box import Box
from .exec import ExecResult, ExecProcess, StreamReader, StreamWriter
from .boxes import BoxService
from .templates import TemplateService
from .disks import DiskService, DiskHandle
from .domains import DomainService
from .networks import NetworkService
from .tokens import TokenService

# Types and errors are shared — re-export for convenience
from .types import (
    BoxConfig,
    ConfigResult,
    Disk,
    DiskAttachment,
    Domain,
    LifecycleConfig,
    Network,
    NetworkConfig,
    Proxy,
    ProxyEntry,
    PtyInfo,
    ResumeResult,
    SuspendResult,
    Template,
    Token,
    TokenInfo,
    VolumeMount,
    WhoamiResult,
)
from .errors import (
    BoxdError,
    AuthenticationError,
    NotFoundError,
    QuotaExceededError,
    InvalidArgumentError,
    InternalError,
    TimeoutError,
    ConnectionError,
)

__all__ = [
    "Compute",
    "Box",
    "BoxService",
    "ExecResult",
    "ExecProcess",
    "StreamReader",
    "StreamWriter",
    "TemplateService",
    "DiskService",
    "DiskHandle",
    "DomainService",
    "NetworkService",
    "TokenService",
    "BoxConfig",
    "LifecycleConfig",
    "NetworkConfig",
    "ProxyEntry",
    "VolumeMount",
    "Proxy",
    "Template",
    "Disk",
    "DiskAttachment",
    "Domain",
    "Network",
    "Token",
    "TokenInfo",
    "SuspendResult",
    "ResumeResult",
    "PtyInfo",
    "WhoamiResult",
    "ConfigResult",
    "BoxdError",
    "AuthenticationError",
    "NotFoundError",
    "QuotaExceededError",
    "InvalidArgumentError",
    "InternalError",
    "TimeoutError",
    "ConnectionError",
]
