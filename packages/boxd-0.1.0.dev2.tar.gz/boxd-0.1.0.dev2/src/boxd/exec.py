"""Exec primitives: result, stream readers/writers, and process handle."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field


@dataclass
class ExecResult:
    """Result of a non-streaming exec call."""

    stdout: str
    stderr: str
    exit_code: int

    @property
    def success(self) -> bool:
        return self.exit_code == 0


class StreamReader:
    """Async reader that buffers chunks from an exec stream."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[bytes | None] = asyncio.Queue()
        self._eof = False

    async def read(self) -> bytes:
        """Read the next chunk, or return empty bytes on EOF."""
        if self._eof:
            return b""
        chunk = await self._queue.get()
        if chunk is None:
            self._eof = True
            return b""
        return chunk

    def _feed(self, data: bytes) -> None:
        self._queue.put_nowait(data)

    def _feed_eof(self) -> None:
        self._queue.put_nowait(None)

    def __aiter__(self):
        return self

    async def __anext__(self) -> bytes:
        chunk = await self.read()
        if not chunk and self._eof:
            raise StopAsyncIteration
        return chunk


class StreamWriter:
    """Async writer that queues stdin chunks for an exec stream."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[bytes | None] = asyncio.Queue()
        self._closed = False

    def write(self, data: bytes | str) -> None:
        """Queue data to be sent to stdin."""
        if self._closed:
            raise RuntimeError("writer is closed")
        if isinstance(data, str):
            data = data.encode("utf-8")
        self._queue.put_nowait(data)

    def write_eof(self) -> None:
        """Signal end of stdin."""
        if not self._closed:
            self._closed = True
            self._queue.put_nowait(None)

    async def drain(self) -> None:
        """Wait until the queue is empty."""
        await self._queue.join()

    async def _get(self) -> bytes | None:
        return await self._queue.get()

    def _task_done(self) -> None:
        self._queue.task_done()


@dataclass
class ExecProcess:
    """Handle to a streaming exec process."""

    stdout: StreamReader
    stderr: StreamReader
    stdin: StreamWriter
    _exit_code: int | None = field(default=None, repr=False)
    _error: BaseException | None = field(default=None, repr=False)
    _done: asyncio.Event = field(default_factory=asyncio.Event, repr=False)
    _relay_task: asyncio.Task | None = field(default=None, repr=False)

    async def wait(self) -> int:
        """Wait for the process to exit and return the exit code.

        Raises the original exception if the exec stream failed.
        """
        await self._done.wait()
        if self._error is not None:
            raise self._error
        return self._exit_code if self._exit_code is not None else -1

    def close(self) -> None:
        """Cancel the relay task and close stdin."""
        self.stdin.write_eof()
        if self._relay_task and not self._relay_task.done():
            self._relay_task.cancel()

    def _set_exit_code(self, code: int) -> None:
        self._exit_code = code
        self._done.set()

    def _set_error(self, error: BaseException) -> None:
        self._error = error
        self._exit_code = -1
        self._done.set()
