"""API key authentication — exchange and JWT refresh."""

from __future__ import annotations

import time

import grpc
import httpx

from .errors import AuthenticationError


class TokenAuth:
    """Manages API key → JWT exchange and transparent refresh."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        token: str | None = None,
        exchange_url: str = "https://boxd.sh/api/v1/auth/token",
    ):
        self._api_key = api_key
        self._token = token
        self._expires_at: float = 0
        self._exchange_url = exchange_url

        if not api_key and not token:
            raise AuthenticationError("provide api_key or token")

    async def get_token(self) -> str:
        """Return a valid JWT, exchanging/refreshing if needed."""
        if self._token and not self._api_key:
            # Direct token mode — no refresh
            return self._token

        # API key mode — exchange or refresh
        if not self._token or time.time() > self._expires_at - 300:
            await self._exchange()

        assert self._token is not None  # set by _exchange()
        return self._token

    async def _exchange(self) -> None:
        """Exchange API key for a short-lived JWT."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                self._exchange_url,
                json={"api_key": self._api_key},
                timeout=10,
            )
        if resp.status_code == 401:
            raise AuthenticationError("invalid or expired API key")
        if resp.status_code == 429:
            raise AuthenticationError("rate limit exceeded — try again later")
        if resp.status_code != 200:
            raise AuthenticationError(f"exchange failed: {resp.status_code} {resp.text}")

        data = resp.json()
        self._token = data["token"]
        self._expires_at = data["expires_at"]

    async def metadata(self) -> list[tuple[str, str]]:
        """Return auth metadata for manual injection (streaming calls)."""
        token = await self.get_token()
        return [("authorization", f"Bearer {token}")]

    def interceptor(self) -> "AuthInterceptor":
        """Return a gRPC interceptor that injects the Bearer token."""
        return AuthInterceptor(self)


class AuthInterceptor(
    grpc.aio.UnaryUnaryClientInterceptor,
    grpc.aio.UnaryStreamClientInterceptor,
    grpc.aio.StreamUnaryClientInterceptor,
    grpc.aio.StreamStreamClientInterceptor,
):
    """gRPC interceptor that injects Bearer token into metadata."""

    def __init__(self, auth: TokenAuth):
        self._auth = auth

    async def _add_auth(self, client_call_details):
        token = await self._auth.get_token()
        metadata = list(client_call_details.metadata or [])
        metadata.append(("authorization", f"Bearer {token}"))
        return client_call_details._replace(metadata=metadata)

    async def _intercept(self, continuation, client_call_details, request_or_iterator):
        try:
            new_details = await self._add_auth(client_call_details)
        except AuthenticationError:
            raise _abort_unauthenticated()
        return await continuation(new_details, request_or_iterator)

    async def intercept_unary_unary(self, continuation, client_call_details, request):
        return await self._intercept(continuation, client_call_details, request)

    async def intercept_unary_stream(self, continuation, client_call_details, request):
        return await self._intercept(continuation, client_call_details, request)

    async def intercept_stream_unary(self, continuation, client_call_details, request_iterator):
        return await self._intercept(continuation, client_call_details, request_iterator)

    async def intercept_stream_stream(self, continuation, client_call_details, request_iterator):
        return await self._intercept(continuation, client_call_details, request_iterator)


def _abort_unauthenticated() -> grpc.aio.AioRpcError:
    """Create a proper gRPC UNAUTHENTICATED error for clean interceptor shutdown."""
    return grpc.aio.AioRpcError(
        code=grpc.StatusCode.UNAUTHENTICATED,
        initial_metadata=grpc.aio.Metadata(),
        trailing_metadata=grpc.aio.Metadata(),
        details="authentication failed",
        debug_error_string=None,
    )
