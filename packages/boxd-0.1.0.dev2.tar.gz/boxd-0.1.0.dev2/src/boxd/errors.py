"""Exception hierarchy for the boxd SDK."""

from __future__ import annotations

import grpc


class BoxdError(Exception):
    """Base exception for all boxd SDK errors."""

    def __init__(self, message: str, grpc_code: int | None = None):
        super().__init__(message)
        self.message = message
        self.grpc_code = grpc_code


class AuthenticationError(BoxdError):
    """API key invalid, expired, or revoked."""


class NotFoundError(BoxdError):
    """Resource not found."""


class QuotaExceededError(BoxdError):
    """Resource limit reached."""


class InvalidArgumentError(BoxdError):
    """Invalid request parameters."""


class InternalError(BoxdError):
    """Server-side error."""


class TimeoutError(BoxdError):
    """Operation timed out."""


class ConnectionError(BoxdError):
    """Failed to connect to boxd API."""


_STATUS_MAP = {
    grpc.StatusCode.UNAUTHENTICATED: AuthenticationError,
    grpc.StatusCode.PERMISSION_DENIED: AuthenticationError,
    grpc.StatusCode.NOT_FOUND: NotFoundError,
    grpc.StatusCode.ALREADY_EXISTS: InvalidArgumentError,
    grpc.StatusCode.RESOURCE_EXHAUSTED: QuotaExceededError,
    grpc.StatusCode.INVALID_ARGUMENT: InvalidArgumentError,
    grpc.StatusCode.INTERNAL: InternalError,
    grpc.StatusCode.UNKNOWN: InternalError,
    grpc.StatusCode.DEADLINE_EXCEEDED: TimeoutError,
    grpc.StatusCode.UNAVAILABLE: ConnectionError,
}


def from_grpc_error(err: grpc.aio.AioRpcError) -> BoxdError:
    """Convert a gRPC error to the appropriate BoxdError subclass."""
    cls = _STATUS_MAP.get(err.code(), BoxdError)
    return cls(err.details() or str(err), grpc_code=err.code().value[0])
