"""Internal helpers."""

from __future__ import annotations

import re
from typing import NamedTuple, TYPE_CHECKING

import grpc.aio

from .errors import from_grpc_error

if TYPE_CHECKING:
    from .client import Compute


class Endpoint(NamedTuple):
    """Resolved gRPC endpoint: bare ``host:port`` and whether to use TLS."""

    host: str
    use_tls: bool


def resolve_endpoint(url: str) -> Endpoint:
    """Resolve an api_url into a ``(host, use_tls)`` pair.

    - ``http://...``  → plaintext, scheme stripped
    - ``https://...`` → TLS, scheme stripped
    - bare ``host:port`` → TLS, except ``localhost``/``127.*`` which stay plaintext

    Production gRPC currently lives at ``boxd.sh:9443`` over plain HTTP/2, so the
    package default uses an explicit ``http://`` scheme. Self-hosted/dev clusters
    can pass ``api_url="http://my-cluster:9443"`` to opt into plaintext.
    """
    if url.startswith("http://"):
        return Endpoint(host=url[len("http://"):], use_tls=False)
    if url.startswith("https://"):
        return Endpoint(host=url[len("https://"):], use_tls=True)
    is_local = url.startswith("localhost") or url.startswith("127.")
    return Endpoint(host=url, use_tls=not is_local)


def parse_size(s: str) -> int:
    """Parse a human-readable size string to bytes.

    Examples: "8G" -> 8589934592, "512M" -> 536870912, "100G" -> 107374182400
    """
    if not s:
        return 0
    m = re.match(r"^(\d+)\s*([KMGT]?)i?[Bb]?$", s.strip(), re.IGNORECASE)
    if not m:
        raise ValueError(f"invalid size: {s!r}")
    num = int(m.group(1))
    unit = m.group(2).upper()
    multipliers = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}
    return num * multipliers[unit]


class GrpcCaller:
    """Mixin for classes that call gRPC methods through a Compute client.

    Subclasses must have a ``_client`` attribute of type :class:`Compute`.
    """

    _client: Compute

    async def _call(self, method_name: str, request):
        """Call a gRPC method on the stub, converting errors."""
        stub = await self._client._ensure_channel()
        method = getattr(stub, method_name)
        try:
            return await method(request)
        except grpc.aio.AioRpcError as e:
            raise from_grpc_error(e) from e
