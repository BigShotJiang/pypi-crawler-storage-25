#!/usr/bin/env python
# coding=utf-8
"""
python distribute file
"""

from __future__ import (absolute_import, division, print_function,
                        unicode_literals, with_statement)
from setuptools import setup, find_packages

setup(
    name="aiom3u8downloader",
    version='1.3.0',
    description=(
        "Asynchronous high-speed HLS (m3u8) downloader and MP4 assembler "
        "using aiohttp for parallel downloads and ffmpeg for final muxing"
    ),
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    keywords=[
        'hls',
        'm3u8',
        'download',
        'aiohttp',
        'asyncio',
        'ffmpeg',
        'video',
        'streaming',
        'downloader',
    ],
    python_requires=">=3.6",
    install_requires=[
        'requests>=2.25.1',
        'aiohttp>=3.8.1'
    ],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'aiodownloadm3u8 = aiom3u8downloader.aiodownloadm3u8:main',
            'aiom3u8downloader = aiom3u8downloader.aiodownloadm3u8:main',
        ]
    },
    package_dir={'':"."},
    packages=find_packages(),
    package_data={'aiom3u8downloader': ['logger.conf']},
    author="cghn",
    license="GPLv3",
    url="https://github.com/kirikumo/aiom3u8downloader/",
    project_urls={
        'Source': 'https://github.com/kirikumo/aiom3u8downloader',
        'Issues': 'https://github.com/kirikumo/aiom3u8downloader/issues',
    },
    classifiers=[
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
    ])
