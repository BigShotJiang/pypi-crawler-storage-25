# aidev_wxbot tests
