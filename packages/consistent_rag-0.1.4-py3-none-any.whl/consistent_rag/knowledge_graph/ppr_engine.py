"""Custom Weighted Personalized PageRank engine.

Implements power-iteration PPR from scratch (no NetworkX dependency for
the core solver).  Supports:

* Query-aware seed weighting via cosine similarity.
* Edge-weighted transition matrices (confidence scores).
* Dynamic edge pruning (for ReAct refinement loops).

Mathematical formulation
------------------------
R = (1 - α) * M * R + α * P

where ``M`` is the column-stochastic transition matrix and ``P`` is the
personalization (teleport) vector.  When ``query_embedding`` is supplied
the teleport vector is weighted by ReLU(cosine_sim(node, query)).
"""

from __future__ import annotations

from loguru import logger
import numpy as np


def _build_transition_matrix(
    adjacency: np.ndarray,
    edge_weights: np.ndarray | None = None,
) -> np.ndarray:
    """Build column-stochastic transition matrix.

    Args:
        adjacency: Binary or weighted adjacency matrix (n × n).
        edge_weights: Optional per-edge weights with same shape as adjacency.
            These should reflect *query relevance*, not LLM confidence.
            When None, all edges are treated uniformly.

    Returns:
        Column-stochastic matrix where each column sums to 1.0.
    """
    if edge_weights is not None:
        W = edge_weights.copy()
    else:
        W = adjacency.astype(float)
    n = W.shape[0]
    col_sums = W.sum(axis=0)
    # Dangling nodes: uniform distribution
    dangling = col_sums == 0
    col_sums[dangling] = 1.0
    M = W / col_sums
    # Set dangling columns to uniform
    for j in np.where(dangling)[0]:
        M[:, j] = 1.0 / n
    return M


def _build_personalization_vector(
    n: int,
    seed_indices: list[int],
    seed_weights: dict[int, float] | None = None,
    query_embedding: np.ndarray | None = None,
    node_embeddings: dict[int, np.ndarray] | None = None,
) -> np.ndarray:
    """Build teleport vector ``P``.

    If ``query_embedding`` and ``node_embeddings`` are provided, seed nodes
    are weighted by their cosine similarity to the query (ReLU applied so
    negative similarities are clamped to 0).

    Args:
        n: Number of nodes.
        seed_indices: Indices of seed nodes.
        seed_weights: Optional base weights for each seed index.
        query_embedding: Query vector for semantic weighting.
        node_embeddings: Mapping from node index -> embedding vector.

    Returns:
        Normalized personalization vector of shape (n,).
    """
    P = np.zeros(n, dtype=float)

    for idx in seed_indices:
        weight = seed_weights.get(idx, 1.0) if seed_weights else 1.0

        if query_embedding is not None and node_embeddings is not None:
            emb = node_embeddings.get(idx)
            if emb is not None:
                emb_norm = np.linalg.norm(emb)
                query_norm = np.linalg.norm(query_embedding)
                if emb_norm > 0 and query_norm > 0:
                    sim = float(np.dot(emb, query_embedding) / (emb_norm * query_norm))
                    weight *= max(0.0, sim)  # ReLU

        P[idx] = weight

    total = P.sum()
    if total > 0:
        P /= total
    else:
        P = np.ones(n) / n  # uniform fallback

    return P


def compute_weighted_ppr(
    adjacency_matrix: np.ndarray,
    seed_indices: list[int],
    *,
    seed_weights: dict[int, float] | None = None,
    query_embedding: np.ndarray | None = None,
    node_embeddings: dict[int, np.ndarray] | None = None,
    edge_weights: np.ndarray | None = None,
    alpha: float = 0.85,
    max_iter: int = 100,
    tol: float = 1e-6,
) -> np.ndarray:
    """Compute Weighted Personalized PageRank via Power Iteration.

    Args:
        adjacency_matrix: Square adjacency matrix (n × n).  Non-zero entries
            indicate edges.  Row i -> column j means i → j.
        seed_indices: Node indices to teleport back to.
        seed_weights: Optional dict mapping seed index -> base weight.
        query_embedding: Optional query vector for semantic seed weighting.
        node_embeddings: Optional dict mapping node index -> embedding vector.
        edge_weights: Optional matrix of same shape as adjacency with per-edge
            transition weights. These weights should reflect *query relevance*
            (e.g. cosine similarity between edge/triple embeddings and the
            query embedding), NOT LLM-extracted confidence scores. When
            provided, ``adjacency_matrix`` is treated as a binary mask.
        alpha: Damping factor (teleport probability).  0.85 is standard PageRank.
        max_iter: Maximum power iterations.
        tol: L1 convergence threshold.

    Returns:
        Rank vector of shape (n,) where higher values indicate more important
        nodes relative to the seeds and query.
    """
    n = adjacency_matrix.shape[0]
    if n == 0 or not seed_indices:
        return np.array([])

    M = _build_transition_matrix(adjacency_matrix, edge_weights)
    P = _build_personalization_vector(
        n,
        seed_indices,
        seed_weights=seed_weights,
        query_embedding=query_embedding,
        node_embeddings=node_embeddings,
    )

    R = P.copy()  # warm-start with teleport vector

    for iteration in range(max_iter):
        R_next = (1 - alpha) * M.dot(R) + alpha * P
        delta = float(np.linalg.norm(R_next - R, ord=1))

        if delta < tol:
            logger.debug(f"[PPR] Converged after {iteration + 1} iterations (δ={delta:.2e})")
            return R_next

        R = R_next

    logger.debug(f"[PPR] Did not converge within {max_iter} iterations (final δ={delta:.2e})")
    return R


def prune_edges(
    adjacency_matrix: np.ndarray,
    bad_paths: list[tuple[int, int]],
    edge_weights: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Prune edges from the adjacency matrix.

    Temporarily removes edges that led to dead ends or irrelevant conclusions.
    This is the **Pruner** component of the ReAct refinement loop.

    Args:
        adjacency_matrix: Original adjacency matrix.
        bad_paths: List of (source, target) index pairs to remove.
        edge_weights: Optional edge weight matrix to prune in parallel.

    Returns:
        Tuple of (pruned_adjacency, pruned_edge_weights).
    """
    A = adjacency_matrix.copy()
    W = edge_weights.copy() if edge_weights is not None else None

    for src, tgt in bad_paths:
        A[src, tgt] = 0
        if W is not None:
            W[src, tgt] = 0.0

    n_removed = sum(1 for s, t in bad_paths if adjacency_matrix[s, t] != 0)
    logger.info(f"[Pruner] Removed {n_removed} bad-path edges")

    return A, W


def ppr_scores_to_dict(
    scores: np.ndarray,
    node_names: list[str],
    top_k: int | None = None,
) -> dict[str, float]:
    """Convert a raw PPR score vector to a sorted name -> score mapping.

    Args:
        scores: Rank vector from :func:`compute_weighted_ppr`.
        node_names: List of node names aligned with score indices.
        top_k: If given, only return the top-k entries.

    Returns:
        Ordered dict of {name: normalized_score}.
    """
    if len(scores) == 0:
        return {}

    max_score = float(scores.max())
    if max_score == 0:
        return {name: 0.0 for name in node_names}

    named_scores = {name: float(scores[i]) / max_score for i, name in enumerate(node_names)}
    sorted_scores = dict(sorted(named_scores.items(), key=lambda x: x[1], reverse=True))

    if top_k is not None:
        return dict(list(sorted_scores.items())[:top_k])

    return sorted_scores
