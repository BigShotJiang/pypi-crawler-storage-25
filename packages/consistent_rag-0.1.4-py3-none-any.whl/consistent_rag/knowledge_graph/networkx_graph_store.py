"""NetworkX-based knowledge graph storage.

In-memory NetworkX MultiDiGraph supporting multiple edges between
the same entity pair (e.g., different predicates or time periods).
Entity embeddings are stored as node attributes with a FAISS index
for semantic similarity search and entity resolution.
"""

from __future__ import annotations

import json
from pathlib import Path
import pickle
from typing import Any

import faiss
from loguru import logger
import networkx as nx
import numpy as np
from pydantic import BaseModel

from ..embeddings import EmbeddingConfig, EmbeddingService
from .extractor import Triple


def _canonicalize_predicate(predicate: str) -> str:
    """Normalize a relation predicate to canonical form.

    1. Strip, lowercase, replace spaces with underscores
    2. Remove passive voice prefix 'was_..._by' -> '..._by'
    3. Uppercase for storage
    """
    p = predicate.strip().lower().replace(" ", "_")
    # Remove passive: "was_founded_by" -> "founded_by"
    if p.startswith("was_") and p.endswith("_by"):
        p = p[4:]  # remove "was_"
    return p.upper()


class GraphConfig(BaseModel):
    """Configuration for the NetworkX graph store."""

    embedding_model: str = "text-embedding-ada-002"
    embedding_dimensions: int = 1536
    enable_embeddings: bool = True

    # Entity-resolution thresholds (cosine similarity over node embeddings).
    # - `merge_threshold`: at or above this, two entities are treated as the
    #   same and merged (edges relinked, one node dropped).
    # - `synonymy_threshold`: below `merge_threshold` but at or above this,
    #   two entities get bidirectional `SIMILAR_TO` edges instead of being
    #   merged — preserves near-duplicates as distinct but connected nodes.
    # Below `synonymy_threshold`, no edge is added and no merge occurs.
    merge_threshold: float = 0.85
    synonymy_threshold: float = 0.80


class NetworkXGraphStore:
    """In-memory knowledge graph using NetworkX MultiDiGraph.

    Nodes represent entities with optional embedding vectors.
    Edges represent typed relationships with confidence scores.
    MultiDiGraph allows multiple edges between the same entity pair
    A FAISS index enables semantic entity search and resolution.
    """

    ENTITY_SIMILARITY_THRESHOLD = 0.85
    SYNONYMY_SIMILARITY_THRESHOLD = 0.80

    def __init__(
        self,
        config: GraphConfig | None = None,
        embedding_service: Any | None = None,
        entity_resolution: bool = True,
    ):
        self.config = config or GraphConfig()
        self._embedding_service = embedding_service
        self.entity_resolution = entity_resolution
        self.graph = nx.MultiDiGraph()
        self._entity_names: list[str] = []
        self._faiss_index: faiss.IndexFlatIP | None = None
        self._lsh_index: Any | None = None
        self._name_to_canonical: dict[str, str] = {}  # lowercase -> canonical name
        self._last_resolution_count: int = 0
        self._blocked_edges: set[tuple[str, str, str]] = set()  # (subject, predicate, object)

    @property
    def embedding_service(self) -> Any:
        if self._embedding_service is None and self.config.enable_embeddings:
            self._embedding_service = EmbeddingService(
                EmbeddingConfig(model_name=self.config.embedding_model)
            )
        return self._embedding_service

    def _canonical_name(self, name: str) -> str:
        """Get or create canonical entity name (case-insensitive exact match only).

        Semantic resolution via FAISS is done separately in `_resolve_entities_batch`
        to avoid per-entity API calls during add_triples.
        """
        key = name.strip().lower()
        if key in self._name_to_canonical:
            return self._name_to_canonical[key]
        canonical = name.strip()
        self._name_to_canonical[key] = canonical
        return canonical

    def _should_resolve(self, entity_names) -> bool:
        """Return True when the store is in a state where FAISS resolution can run.

        All preconditions must hold: resolution must be enabled, the FAISS
        index must exist and be non-empty, an embedding service must be
        available, and we must have entities to resolve.
        """
        return (
            self.entity_resolution
            and self._faiss_index is not None
            and self._faiss_index.ntotal > 0
            and self.embedding_service is not None
            and bool(entity_names)
        )

    def _normalize_embeddings(self, embeddings: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1
        return embeddings / norms

    def _resolve_from_faiss_batch(
        self, entity_names: list[str], embeddings: np.ndarray
    ) -> dict[str, str]:
        normalized = self._normalize_embeddings(embeddings)
        scores, indices = self._faiss_index.search(normalized, k=1)
        resolved = {}
        merge_threshold = self.config.merge_threshold
        for name, score, idx in zip(entity_names, scores[:, 0], indices[:, 0]):
            if idx >= 0 and score >= merge_threshold:
                existing = self._entity_names[idx]
                if existing != name:
                    resolved[name] = existing
                    self._name_to_canonical[name.lower()] = existing
        return resolved

    def _resolve_entities_batch(self, entity_names: list[str]) -> dict[str, str]:
        if not self._should_resolve(entity_names):
            return {}
        embeddings = self.embedding_service.embed(entity_names)
        if embeddings is None:
            return {}
        return self._resolve_from_faiss_batch(entity_names, np.array(embeddings, dtype=np.float32))

    def add_triples(self, triples: list[Triple]) -> int:
        """Add triples to the graph with entity deduplication.

        Dedup strategy:
        1. Case-insensitive exact match
        2. Relation canonicalization (normalized predicate forms)
        3. Edge weight accumulation (duplicate edges increase confidence)
        4. After adding nodes, batch semantic resolution via FAISS
        5. Merge resolved entities by relinking edges

        Returns the number of triples added.
        """
        added = 0
        new_entities: set[str] = set()

        # Pass 1: Add triples with case-insensitive dedup + relation canon
        for triple in triples:
            subj = self._canonical_name(triple.subject)
            obj = self._canonical_name(triple.object)
            pred = _canonicalize_predicate(triple.predicate)

            if not self.graph.has_node(subj):
                self.graph.add_node(subj, name=subj)
                new_entities.add(subj)

            if not self.graph.has_node(obj):
                self.graph.add_node(obj, name=obj)
                new_entities.add(obj)

            # Edge weight accumulation: find existing edge with same predicate
            existing_key = None
            for key, data in self.graph[subj].get(obj, {}).items():
                if data.get("type") == pred:
                    existing_key = key
                    break

            if existing_key is not None:
                # bump confidence, increment source count
                edge = self.graph[subj][obj][existing_key]
                edge["confidence"] = min(1.0, edge["confidence"] + triple.confidence)
                edge["source_count"] = edge.get("source_count", 1) + 1
            else:
                # Compute edge embedding for query-aware weighting
                edge_text = f"{subj} {pred} {obj}"
                edge_embedding = None
                if self.config.enable_embeddings and self.embedding_service:
                    try:
                        edge_embedding = self.embedding_service.embed([edge_text])[0]
                    except Exception:
                        pass

                self.graph.add_edge(
                    subj,
                    obj,
                    type=pred,
                    confidence=triple.confidence,
                    source=triple.source_text or "",
                    source_count=1,
                    metadata=triple.metadata,
                    embedding=edge_embedding,
                )
            added += 1

        # Pass 2: Compute embeddings for new entities (1 batch API call).
        # Critically: we do NOT rebuild the FAISS index yet. Resolution in
        # Pass 3 must search the PRE-batch index (old entities only), so
        # new entities don't self-match at k=1.
        if new_entities and self.config.enable_embeddings and self.embedding_service:
            self._store_entity_embeddings(list(new_entities))

            # Pass 3: Batch semantic resolution — merge new entities that
            # match an existing one above merge_threshold.
            resolved = self._resolve_entities_batch(list(new_entities))
            self._last_resolution_count = len(resolved)
            if resolved:
                self._merge_resolved_entities(resolved)

            # Pass 4: Rebuild the FAISS index now that merges are applied,
            # then add synonymy edges for remaining near-duplicates in the
            # [synonymy_threshold, merge_threshold) band.
            self._rebuild_faiss_index()

            remaining = [
                e
                for e in new_entities
                if self.graph.has_node(e) and "embedding" in self.graph.nodes[e]
            ]
            if remaining:
                embs = np.array(
                    [self.graph.nodes[e]["embedding"] for e in remaining],
                    dtype=np.float32,
                )
                self._add_synonymy_edges(remaining, embs)

        logger.debug(f"Added {added} triples, {len(new_entities)} new entities")
        return added

    def _merge_resolved_entities(self, resolved: dict[str, str]) -> None:
        """Merge entities that were resolved to existing ones.

        Moves all edges from the resolved entity to the target entity,
        then removes the resolved entity node.
        """
        for old_name, new_name in resolved.items():
            if not self.graph.has_node(old_name) or old_name == new_name:
                continue

            # Move outgoing edges
            for _, target, _key, data in list(
                self.graph.out_edges(old_name, data=True, keys=True)
            ):
                self.graph.add_edge(new_name, target, **data)

            # Move incoming edges
            for source, _, key, data in list(self.graph.in_edges(old_name, data=True, keys=True)):
                self.graph.add_edge(source, new_name, **data)

            self.graph.remove_node(old_name)
            logger.debug(f"Merged entity '{old_name}' into '{new_name}'")

    def _add_synonymy_edges(self, entity_names: list[str], embeddings: np.ndarray) -> int:
        """Add SIMILAR_TO edges between entities in the synonymy band.

        Entities with cosine similarity in [SYNONYMY_THRESHOLD, MERGE_THRESHOLD)
        get bidirectional SIMILAR_TO edges instead of being merged.

        Returns the number of synonymy edges added.
        """
        if self._faiss_index is None or self._faiss_index.ntotal == 0:
            return 0

        normalized = self._normalize_embeddings(embeddings)
        k = min(3, self._faiss_index.ntotal)
        scores, indices = self._faiss_index.search(normalized, k=k)

        synonymy_threshold = self.config.synonymy_threshold
        merge_threshold = self.config.merge_threshold
        added = 0
        for name, row_scores, row_indices in zip(entity_names, scores, indices):
            for score, idx in zip(row_scores, row_indices):
                if idx < 0:
                    continue
                existing = self._entity_names[idx]
                if existing == name:
                    continue
                if synonymy_threshold <= score < merge_threshold:
                    if not self._has_edge_of_type(name, existing, "SIMILAR_TO"):
                        self.graph.add_edge(
                            name,
                            existing,
                            type="SIMILAR_TO",
                            confidence=float(score),
                            source="entity_resolution",
                            source_count=1,
                            metadata={},
                        )
                        self.graph.add_edge(
                            existing,
                            name,
                            type="SIMILAR_TO",
                            confidence=float(score),
                            source="entity_resolution",
                            source_count=1,
                            metadata={},
                        )
                        added += 2

        # Per-call accounting so we can measure how much of the graph's edge
        # budget synonymy is consuming on a given benchmark sample. Driven by
        # §6 of research/synonymy_handling_comparison.md: before changing any
        # hop / threshold knobs, we need the base rate.
        if added:
            total_edges = self.graph.number_of_edges()
            total_nodes = self.graph.number_of_nodes()
            synonymy_share = (added / total_edges) if total_edges else 0.0
            logger.debug(
                f"[synonymy] pairs={added // 2} edges_added={added} "
                f"total_edges={total_edges} total_nodes={total_nodes} "
                f"share={synonymy_share:.2%}"
            )
        return added

    def _has_edge_of_type(self, source: str, target: str, edge_type: str) -> bool:
        """Check if an edge of a specific type exists between two nodes."""
        if not self.graph.has_edge(source, target):
            return False
        for _key, data in self.graph[source][target].items():
            if data.get("type") == edge_type:
                return True
        return False

    def _store_entity_embeddings(self, entity_names: list[str]) -> None:
        """Compute embeddings for new entities and store them on graph nodes.

        Does NOT rebuild the FAISS index. Callers that need the index to
        reflect these new embeddings must call `_rebuild_faiss_index()`
        explicitly. This separation lets the add_triples flow resolve new
        entities against the PRE-batch index (so matches aren't shadowed
        by self-matches at k=1), then rebuild once merges are applied.
        """
        if not entity_names or not self.embedding_service:
            return

        embeddings = self.embedding_service.embed(entity_names)
        for name, emb in zip(entity_names, embeddings):
            self.graph.nodes[name]["embedding"] = emb

    def _rebuild_faiss_index(self) -> None:
        """Rebuild the FAISS index from all node embeddings."""
        entities_with_emb = [
            (name, data["embedding"])
            for name, data in self.graph.nodes(data=True)
            if "embedding" in data
        ]

        if not entities_with_emb:
            self._faiss_index = None
            self._entity_names = []
            return

        self._entity_names = [name for name, _ in entities_with_emb]
        vectors = np.array([emb for _, emb in entities_with_emb], dtype=np.float32)

        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vectors = vectors / norms

        dim = vectors.shape[1]
        self._faiss_index = faiss.IndexFlatIP(dim)
        self._faiss_index.add(vectors)

    def find_similar_entities(self, query: str, top_k: int = 5) -> list[tuple[str, float]]:
        """Find entities most similar to query text by embedding cosine similarity."""
        if self._faiss_index is None or not self.embedding_service:
            return []

        query_emb = self.embedding_service.embed([query])[0]
        query_vec = np.array([query_emb], dtype=np.float32)
        norm = np.linalg.norm(query_vec)
        if norm > 0:
            query_vec = query_vec / norm

        k = min(top_k, self._faiss_index.ntotal)
        if k == 0:
            return []

        scores, indices = self._faiss_index.search(query_vec, k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            results.append((self._entity_names[idx], float(score)))
        return results

    def get_entity_by_name(self, name: str) -> dict[str, Any] | None:
        """Get entity node data by name (case-insensitive)."""
        canonical = self._name_to_canonical.get(name.strip().lower())
        if canonical and self.graph.has_node(canonical):
            return dict(self.graph.nodes[canonical])
        return None

    def get_relationships(self, entity: str) -> list[dict[str, Any]]:
        """Get all relationships (incoming and outgoing) for an entity."""
        canonical = self._name_to_canonical.get(entity.strip().lower())
        if not canonical or not self.graph.has_node(canonical):
            return []

        rels = []
        for _, target, _key, data in self.graph.out_edges(canonical, data=True, keys=True):
            rels.append(
                {"subject": canonical, "predicate": data.get("type", ""), "object": target, **data}
            )
        for source, _, _key, data in self.graph.in_edges(canonical, data=True, keys=True):
            rels.append(
                {"subject": source, "predicate": data.get("type", ""), "object": canonical, **data}
            )
        return rels

    def get_stats(self) -> dict[str, int]:
        """Get graph statistics."""
        return {
            "node_count": self.graph.number_of_nodes(),
            "edge_count": self.graph.number_of_edges(),
            "connected_components": nx.number_weakly_connected_components(self.graph),
        }

    def get_neighbors(
        self, entity: str, direction: str = "both", max_hops: int = 1
    ) -> list[dict[str, Any]]:
        """Get neighboring entities with relationship details.

        Args:
            entity: Entity name (case-insensitive lookup)
            direction: "out", "in", or "both"
            max_hops: Not used for dict output (kept for compat); always returns 1-hop

        Returns:
            List of dicts with keys: neighbor, relation, confidence, direction, and
            any extra edge metadata.
        """
        canonical = self._name_to_canonical.get(entity.strip().lower())
        if not canonical or not self.graph.has_node(canonical):
            return []

        results: list[dict[str, Any]] = []
        seen: set[tuple[str, str, str]] = set()

        if direction in ("out", "both"):
            for _, target, data in self.graph.out_edges(canonical, data=True):
                rel = data.get("type", "")
                # Skip blocked edges
                if self._is_edge_blocked(canonical, rel, target):
                    continue
                key = (target, rel, "out")
                if key not in seen:
                    seen.add(key)
                    results.append(
                        {
                            "neighbor": target,
                            "relation": rel,
                            "confidence": data.get("confidence", 1.0),
                            "direction": "out",
                            **{k: v for k, v in data.items() if k not in ("type", "confidence")},
                        }
                    )

        if direction in ("in", "both"):
            for source, _, data in self.graph.in_edges(canonical, data=True):
                rel = data.get("type", "")
                # Skip blocked edges
                if self._is_edge_blocked(source, rel, canonical):
                    continue
                key = (source, rel, "in")
                if key not in seen:
                    seen.add(key)
                    results.append(
                        {
                            "neighbor": source,
                            "relation": rel,
                            "confidence": data.get("confidence", 1.0),
                            "direction": "in",
                            **{k: v for k, v in data.items() if k not in ("type", "confidence")},
                        }
                    )

        return results

    def search_entities(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Search entities by substring match on names, with FAISS fallback.

        Args:
            query: Search term
            limit: Maximum results

        Returns:
            List of dicts with at least a 'name' key.
        """
        query_lower = query.strip().lower()
        results: list[dict[str, Any]] = []
        seen: set[str] = set()

        # Substring match on entity names
        for name in self.graph.nodes():
            if query_lower in name.lower():
                results.append({"name": name, "match_type": "substring"})
                seen.add(name)
                if len(results) >= limit:
                    return results

        # FAISS semantic fallback if not enough results
        if len(results) < limit:
            similar = self.find_similar_entities(query, top_k=limit - len(results))
            for name, score in similar:
                if name not in seen:
                    results.append({"name": name, "score": score, "match_type": "semantic"})
                    seen.add(name)

        return results[:limit]

    def get_paths(self, start: str, end: str, max_hops: int = 2) -> list[list[dict[str, str]]]:
        """Find paths between two entities up to max_hops.

        Args:
            start: Source entity name
            end: Target entity name
            max_hops: Maximum path length (edges)

        Returns:
            List of paths, each path is a list of alternating entity/relation dicts.
        """
        start_canonical = self._name_to_canonical.get(start.strip().lower())
        end_canonical = self._name_to_canonical.get(end.strip().lower())

        if (
            not start_canonical
            or not end_canonical
            or not self.graph.has_node(start_canonical)
            or not self.graph.has_node(end_canonical)
        ):
            return []

        paths: list[list[dict[str, str]]] = []
        try:
            # Use NetworkX to find simple paths (undirected view for reachability)
            undirected = self.graph.to_undirected(as_view=True)
            for nx_path in nx.all_simple_paths(
                undirected, start_canonical, end_canonical, cutoff=max_hops
            ):
                formatted = self._format_path(nx_path)
                if formatted:
                    paths.append(formatted)
                if len(paths) >= 5:  # cap to avoid explosion
                    break
        except (nx.NetworkXError, nx.NodeNotFound):
            pass

        return paths

    def _format_path(self, nx_path: list[str]) -> list[dict[str, str]]:
        """Convert a NetworkX node path into alternating entity/relation dicts."""
        formatted: list[dict[str, str]] = []
        for i, node in enumerate(nx_path):
            formatted.append({"type": "entity", "name": node})
            if i < len(nx_path) - 1:
                next_node = nx_path[i + 1]
                # Try to find the edge relation
                rel = ""
                if self.graph.has_edge(node, next_node):
                    edge_data = self.graph.get_edge_data(node, next_node)
                    if edge_data:
                        first_edge = next(iter(edge_data.values()))
                        rel = first_edge.get("type", "RELATED_TO")
                elif self.graph.has_edge(next_node, node):
                    edge_data = self.graph.get_edge_data(next_node, node)
                    if edge_data:
                        first_edge = next(iter(edge_data.values()))
                        rel = f"←{first_edge.get('type', 'RELATED_TO')}"
                formatted.append({"type": "relation", "name": rel or "RELATED_TO"})
        return formatted

    def clear(self) -> None:
        """Remove all nodes, edges, and reset the FAISS index."""
        self.graph.clear()
        self._entity_names = []
        self._faiss_index = None
        self._name_to_canonical = {}
        logger.debug("Graph cleared")

    def save(self, path: Path) -> None:
        """Serialize the graph, embeddings, and FAISS index to disk."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        with open(path / "graph.pkl", "wb") as f:
            pickle.dump(self.graph, f)

        with open(path / "name_map.json", "w", encoding="utf-8") as f:
            json.dump(self._name_to_canonical, f)

        if self._faiss_index is not None:
            faiss.write_index(self._faiss_index, str(path / "faiss.index"))
            with open(path / "entity_names.json", "w", encoding="utf-8") as f:
                json.dump(self._entity_names, f)

        logger.info(f"Graph saved to {path}")

    def load(self, path: Path) -> None:
        """Load a serialized graph from disk."""
        path = Path(path)

        with open(path / "graph.pkl", "rb") as f:
            self.graph = pickle.load(f)  # noqa: S301

        with open(path / "name_map.json", encoding="utf-8") as f:
            self._name_to_canonical = json.load(f)

        faiss_path = path / "faiss.index"
        if faiss_path.exists():
            self._faiss_index = faiss.read_index(str(faiss_path))
            with open(path / "entity_names.json", encoding="utf-8") as f:
                self._entity_names = json.load(f)
        else:
            self._faiss_index = None
            self._entity_names = []

        logger.info(f"Graph loaded from {path}: {self.get_stats()}")

    def ensure_indexes(self) -> None:
        """Ensure search indexes exist. No-op for NetworkX (in-memory)."""

    def block_edges(self, edges: set[tuple[str, str, str]]) -> None:
        """Block edges from being used in traversal.

        Blocked edges are excluded from neighbor queries and path extraction.
        They remain in the graph but are invisible to ranking algorithms.

        Args:
            edges: Set of (subject, predicate, object) tuples to block
        """
        self._blocked_edges.update(edges)
        if edges:
            logger.debug(f"Blocked {len(edges)} edges (total: {len(self._blocked_edges)})")

    @property
    def blocked_edges(self) -> set[tuple[str, str, str]]:
        """Return the set of blocked edges."""
        return self._blocked_edges.copy()

    def _is_edge_blocked(self, subject: str, predicate: str, object: str) -> bool:
        """Check if an edge is blocked."""
        return (subject, predicate, object) in self._blocked_edges

    def close(self) -> None:
        """Clean up resources. No-op for NetworkX (in-memory)."""
