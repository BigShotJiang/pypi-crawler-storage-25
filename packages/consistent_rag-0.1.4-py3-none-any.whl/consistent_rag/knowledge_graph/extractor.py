"""Triple extraction from text using structured LLM outputs.

Uses pydantic-ai Agent with output_type for guaranteed structured
extraction — no manual JSON parsing needed. Follows the same pattern
as every other agent in the ConsistentRAG codebase.
"""

from __future__ import annotations

from typing import Any

from loguru import logger
from pydantic import BaseModel, Field
from pydantic_ai import Agent


class Triple(BaseModel):
    """A knowledge graph triple (subject, predicate, object)."""

    subject: str = Field(description="The subject entity of the relationship.")
    predicate: str = Field(
        description="The canonical relationship (e.g., founded_by, located_in, has_population)."
    )
    object: str = Field(description="The object entity or value of the relationship.")
    confidence: float = 1.0
    source_text: str | None = None
    metadata: dict[str, Any] = {}

    def __str__(self) -> str:
        return f"({self.subject}) -[{self.predicate}]-> ({self.object})"

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "predicate": self.predicate,
            "object": self.object,
        }


class TripleList(BaseModel):
    """Structured output model for triple extraction."""

    triples: list[Triple] = Field(description="List of extracted knowledge graph triples.")


EXTRACTION_SYSTEM_PROMPT = """You are a knowledge graph extraction assistant.
Extract factual relationships from text as structured triples.

Rules:
1. Extract factual relationships only
2. Keep entities concise but complete (≤6 words, real named entities — never sentences)
3. Use clear, canonical predicate names. Every triple must read left-to-right
   as a sentence: subject → predicate → object.
   - For ROLE predicates (kinship, possession, position), ALWAYS suffix with
     "_of" / "_from" / "_in" / "_by" / "_at" / "has_" so direction is
     unambiguous. Good: father_of, mother_of, capital_of, born_in,
     located_in, founded_by, has_population, came_from.
     BAD (ambiguous — never emit these bare role nouns): parent, mother,
     father, child, spouse, sibling, brother, sister, grandmother,
     grandfather, capital, author, founder, owner, director, creator.
     Example: write (Louis XIII, father_of, Philippe) — NOT
     (Louis XIII, parent, Philippe).
   - For ACTION predicates, use the plain verb in subject→object direction:
     directs, plays, wrote, discovered, acquired. These are fine as-is.
4. Include important attributes as separate triples (dates, quantities, properties)
5. Resolve pronouns to their referent entities"""

GLEANING_SYSTEM_PROMPT = """You are a knowledge graph extraction assistant.
The following triples were already extracted:
{existing_triples}

Extract ADDITIONAL triples that were NOT already captured above.
Focus on implicit relationships, attributes, and secondary entities."""


RETRY_SYSTEM_PROMPT = """You are a knowledge graph extraction assistant.

The previous extraction attempt failed — it returned meta-statements
("the search", "relevant information", "retrieved documents") instead of
concrete factual triples. Ignore that attempt.

Re-read the text and extract ONLY concrete (subject, predicate, object)
facts directly asserted in the text. Subjects and objects must be named
entities or terse noun phrases (≤6 words), not sentences. Do NOT emit
triples that describe the retrieval process, the search, or the text
itself as a document.

Predicates must read left-to-right as a sentence. For role/kinship
relations ALWAYS use the "_of" / "has_" form (father_of, mother_of,
capital_of, has_population) — never bare nouns like "parent", "mother",
"capital". For actions use the plain verb (directs, plays, wrote)."""


# Predicates and tokens the LLM emits when it has *failed* to extract but
# is forced to satisfy the TripleList schema. See
# research/triplet_extraction_collapse.md.
_META_PREDICATES = frozenset(
    {
        "similar_to",
        "contains_information_about",
        "contains_information_related_to",
        "do_not_contain_information_related_to",
        "does_not_contain_information_about",
        "related_to_search",
        "search_result",
        # Retrieval-narration predicates — the LLM describing the search
        # instead of extracting facts. Observed in musique_2ef1c0.
        "did_not_return",
        "does_not_return",
        "not_returned",
        "returned_no_results",
        "no_results_for",
        "failed_to_retrieve",
    }
)

# Bare role nouns — ambiguous without an `_of` / `has_` qualifier.
# (A) -[parent]-> (B) could mean "A is parent of B" or "A's parent is B".
# Flagging these forces the retry path to return canonical `X_of` form.
_AMBIGUOUS_ROLE_PREDICATES = frozenset(
    {
        "parent",
        "mother",
        "father",
        "child",
        "son",
        "daughter",
        "spouse",
        "wife",
        "husband",
        "sibling",
        "brother",
        "sister",
        "grandmother",
        "grandfather",
        "grandparent",
        "grandchild",
        "uncle",
        "aunt",
        "cousin",
        "nephew",
        "niece",
        "capital",
        "author",
        "founder",
        "owner",
        "director",
        "creator",
        "inventor",
        "discoverer",
        "ceo",
        "president",
        "leader",
    }
)

_META_TOKENS = (
    "relevant information",
    "the search",
    "retrieved document",
    "no information",
    "not contain",
    "not provided",
    "relevant_document",
    "additional_search",
    "search_strateg",
    "genealogical_information",
)

# A real entity is terse; a narrated-sentence entity packs many words into
# one token. These thresholds flag subjects/objects that look like
# verbalized reasoning rather than named entities.
_ENTITY_MAX_UNDERSCORE_TOKENS = 6
_ENTITY_MAX_CHARS = 60


def _entity_looks_like_phrase(value: str) -> bool:
    """True if the entity is too long to be a real named entity."""
    if not value:
        return False
    if len(value) > _ENTITY_MAX_CHARS:
        return True
    if value.count("_") >= _ENTITY_MAX_UNDERSCORE_TOKENS:
        return True
    return False


def _triples_look_degenerate(triples: list["Triple"], text: str) -> tuple[bool, str]:
    """Heuristic: did the LLM return meta-failure triples instead of facts?

    Pure function — cheap string checks only. Returns (is_degenerate, reason).
    """
    if not triples:
        return (True, "zero triples from non-trivial text") if len(text) > 200 else (False, "")

    if len(triples) == 1 and len(text) > 300:
        return True, "single triple from long text"

    def _is_meta(t: "Triple") -> bool:
        pred = (t.predicate or "").lower().replace("-", "_").replace(" ", "_")
        if pred in _META_PREDICATES:
            return True
        if pred in _AMBIGUOUS_ROLE_PREDICATES:
            return True
        if _entity_looks_like_phrase(t.subject) or _entity_looks_like_phrase(t.object):
            return True
        blob = f"{t.subject} {t.object}".lower()
        return any(tok in blob for tok in _META_TOKENS)

    meta_count = sum(1 for t in triples if _is_meta(t))
    if meta_count and meta_count / len(triples) >= 0.5:
        return True, f"{meta_count}/{len(triples)} meta-triples"

    return False, ""


_OPENIE_WORKER = r"""
import json, os, sys
os.environ.setdefault("PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION", "python")
# StanfordOpenIE prints "Starting server..." to stdout regardless of the
# quiet flag. Capture the real stdout, redirect the library's chatter to
# stderr, then emit only our JSON payload on the real stdout with a
# unique sentinel line so the parent can split cleanly.
_real_stdout = sys.stdout
sys.stdout = sys.stderr
try:
    from openie import StanfordOpenIE
    text = sys.stdin.read()
    with StanfordOpenIE(quiet=True) as client:
        raw = client.annotate(text) or []
    _real_stdout.write("__OPENIE_RESULT__\n")
    _real_stdout.write(json.dumps(raw))
    _real_stdout.flush()
except Exception as e:
    sys.stderr.write(f"OPENIE_ERR: {e}")
    sys.exit(2)
"""


async def _openie_fallback_async(text: str, max_triples: int) -> list["Triple"]:
    """Stanford OpenIE fallback — isolated in a subprocess.

    `stanfordnlp`'s generated pb2 files predate protobuf 4/5's descriptor
    API, so in-process import crashes with "Descriptors cannot be created
    directly". Setting ``PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python``
    only works before protobuf is first imported; the main process has
    already loaded protobuf via qdrant / logfire / opentelemetry by the
    time we get here, so the env var in-process is a no-op.

    Running openie in a fresh Python subprocess sidesteps the conflict —
    the child starts clean, applies the env var before importing
    protobuf, and returns annotations via stdout. Overhead is a few
    seconds of Java startup, acceptable for a fallback that only fires
    when the LLM retry produces degenerate triples.

    Returns [] if the dep, Java, or CoreNLP download is unavailable —
    callers must tolerate that.
    """
    import asyncio
    import json as _json
    import os
    import sys

    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-c",
            _OPENIE_WORKER,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env={**os.environ, "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION": "python"},
        )
    except FileNotFoundError as e:
        logger.debug(f"[openie] subprocess launch failed: {e}")
        return []

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=text.encode("utf-8")), timeout=180
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        logger.warning("[openie] subprocess timed out")
        return []

    if proc.returncode != 0:
        msg = stderr.decode(errors="replace").strip()
        logger.debug(f"[openie] unavailable, skipping fallback: {msg[:200]}")
        return []

    # Split on the sentinel line so we discard any startup chatter that
    # leaked through stanford-openie's "quiet" mode.
    decoded = stdout.decode(errors="replace")
    marker = "__OPENIE_RESULT__\n"
    payload = decoded.split(marker, 1)[1] if marker in decoded else decoded
    try:
        raw = _json.loads(payload.strip() or "[]")
    except Exception as e:
        logger.warning(f"[openie] could not parse subprocess output: {e}")
        return []

    out: list[Triple] = []
    for r in raw[:max_triples]:
        subj = (r.get("subject") or "").strip()
        pred = (r.get("relation") or "").strip().lower().replace(" ", "_")
        obj = (r.get("object") or "").strip()
        if subj and pred and obj:
            out.append(
                Triple(
                    subject=subj,
                    predicate=pred,
                    object=obj,
                    confidence=0.7,
                    source_text=text[:500],
                    metadata={"source": "openie"},
                )
            )
    return out


class TripleExtractor:
    """Extracts knowledge graph triples using pydantic-ai structured outputs.

    Uses Agent(output_type=TripleList) for guaranteed structured extraction,
    consistent with every other agent in the ConsistentRAG codebase.
    """

    def __init__(
        self,
        model: Any | None = None,
        *,
        llm_client: Any | None = None,
        llm_config: Any | None = None,
    ):
        """Initialize the triple extractor.

        Args:
            model: A pydantic-ai model instance (e.g., from config.create_model()).
                   This is the preferred way to initialize.
            llm_client: Legacy LLMClient (for backward compat with existing code).
            llm_config: Legacy LLMConfig (for backward compat).
        """
        self._model = model
        self._llm_client = llm_client
        self._llm_config = llm_config

        # Create extraction agent if we have a model
        if self._model is not None:
            self._agent: Agent[None, TripleList] = Agent(
                self._model,
                output_type=TripleList,
                system_prompt=EXTRACTION_SYSTEM_PROMPT,
                retries=2,
            )
        else:
            self._agent = None

    def _get_agent(self, system_prompt: str | None = None) -> Agent[None, TripleList]:
        """Get or create the extraction agent.

        Falls back to creating from llm_client/llm_config if no model was provided.
        """
        if self._agent is not None and system_prompt is None:
            return self._agent

        if system_prompt is not None and self._model is not None:
            return Agent(
                self._model,
                output_type=TripleList,
                system_prompt=system_prompt,
                retries=2,
            )

        # Legacy fallback: create model from LLMClient credentials
        if self._model is None:
            self._model = self._create_model_from_legacy()
            self._agent = Agent(
                self._model,
                output_type=TripleList,
                system_prompt=system_prompt or EXTRACTION_SYSTEM_PROMPT,
                retries=2,
            )
            return self._agent

        return self._agent

    def _create_model_from_legacy(self) -> Any:
        """Create a pydantic-ai model from legacy LLMClient/LLMConfig."""
        from openai import AsyncOpenAI
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        from ..llm import resolve_llm_credentials

        if self._llm_client is not None:
            client = self._llm_client
            key = client.client.api_key
            base_url = str(client.client.base_url)
            model_name = client.config.model
        elif self._llm_config is not None:
            key, base_url = resolve_llm_credentials(
                api_key=self._llm_config.api_key, base_url=self._llm_config.base_url
            )
            model_name = self._llm_config.model
        else:
            key, base_url = resolve_llm_credentials()
            model_name = "gpt-4o-mini"

        async_client = AsyncOpenAI(api_key=key, base_url=base_url)
        provider = OpenAIProvider(openai_client=async_client)
        return OpenAIChatModel(model_name, provider=provider)

    def extract(
        self, text: str | list[str], max_triples: int = 20, gleaning_passes: int = 0
    ) -> list[Triple]:
        """Synchronous triple extraction.

        WARNING: Do not call from inside an async context — use extract_async instead.
        This method calls agent.run_sync() which fails when an event loop is already running.
        """
        if isinstance(text, list):
            text = "\n".join(text)
        if not text or not text.strip():
            return []

        try:
            agent = self._get_agent()
            result = agent.run_sync(f"Extract knowledge graph triples from this text:\n\n{text}")
            triples = result.output.triples
            for t in triples:
                t.source_text = text[:500]

            seen = {(t.subject.lower(), t.predicate.lower(), t.object.lower()) for t in triples}

            for _pass in range(gleaning_passes):
                existing_str = "\n".join(str(t) for t in triples)
                gleaning_prompt = GLEANING_SYSTEM_PROMPT.format(existing_triples=existing_str)
                gleaning_agent = self._get_agent(system_prompt=gleaning_prompt)
                gleaning_result = gleaning_agent.run_sync(
                    f"Extract ADDITIONAL triples missed from this text:\n\n{text}"
                )
                for t in gleaning_result.output.triples:
                    key = (t.subject.lower(), t.predicate.lower(), t.object.lower())
                    if key not in seen:
                        seen.add(key)
                        t.source_text = text[:500]
                        triples.append(t)

            return triples[:max_triples]

        except Exception as e:
            logger.error(f"Error extracting triples (sync): {e}")
            return []

    async def extract_async(
        self, text: str | list[str], max_triples: int = 20, gleaning_passes: int = 0
    ) -> list[Triple]:
        """Async triple extraction — use this from inside async pipelines.

        Args:
            text: The text to extract triples from (str or list of str)
            max_triples: Maximum number of triples to extract
            gleaning_passes: Number of additional extraction passes (0 = single pass)

        Returns:
            List of extracted Triple objects
        """
        if isinstance(text, list):
            text = "\n".join(text)
        if not text or not text.strip():
            return []

        try:
            agent = self._get_agent()
            result = await agent.run(f"Extract knowledge graph triples from this text:\n\n{text}")
            triples = result.output.triples
            for t in triples:
                t.source_text = text[:500]

            # --- Degenerate-output recovery (see research/triplet_extraction_collapse.md) ---
            is_degenerate, reason = _triples_look_degenerate(triples, text)
            if is_degenerate:
                logger.warning(f"[extract] degenerate output ({reason}) — retrying once")
                retry_agent = self._get_agent(system_prompt=RETRY_SYSTEM_PROMPT)
                retry_result = await retry_agent.run(
                    "Extract concrete factual triples from this text. "
                    "Subjects/objects must be terse named entities, never "
                    f"meta-statements about the text itself:\n\n{text}"
                )
                retry_triples = retry_result.output.triples
                for t in retry_triples:
                    t.source_text = text[:500]

                retry_bad, _ = _triples_look_degenerate(retry_triples, text)
                if not retry_bad and retry_triples:
                    triples = retry_triples
                else:
                    logger.warning(
                        "[extract] retry still degenerate — trying Stanford OpenIE fallback"
                    )
                    openie_triples = await _openie_fallback_async(text, max_triples)
                    if openie_triples:
                        triples = openie_triples
                    # else: surface whatever the first attempt returned so
                    # downstream stages can log a degraded-run marker instead
                    # of silently seeing zero triples.

            seen = {(t.subject.lower(), t.predicate.lower(), t.object.lower()) for t in triples}

            for _pass in range(gleaning_passes):
                existing_str = "\n".join(str(t) for t in triples)
                gleaning_prompt = GLEANING_SYSTEM_PROMPT.format(existing_triples=existing_str)
                gleaning_agent = self._get_agent(system_prompt=gleaning_prompt)
                gleaning_result = await gleaning_agent.run(
                    f"Extract ADDITIONAL triples missed from this text:\n\n{text}"
                )
                for t in gleaning_result.output.triples:
                    key = (t.subject.lower(), t.predicate.lower(), t.object.lower())
                    if key not in seen:
                        seen.add(key)
                        t.source_text = text[:500]
                        triples.append(t)

            return triples[:max_triples]

        except Exception as e:
            logger.error(f"Error extracting triples (async): {e}")
            return []

    def segment_and_extract(
        self,
        text: str,
        segment_size: int = 500,
        overlap: int = 50,
    ) -> list[Triple]:
        """Segment text and extract triples from each segment.

        Args:
            text: The text to process
            segment_size: Size of each segment in characters
            overlap: Overlap between segments

        Returns:
            Combined list of triples from all segments
        """
        if len(text) <= segment_size:
            return self.extract(text)

        segments = []
        start = 0
        while start < len(text):
            end = min(start + segment_size, len(text))
            segments.append(text[start:end])
            start += segment_size - overlap

        all_triples = []
        seen: set[tuple[str, str, str]] = set()

        for segment in segments:
            triples = self.extract(segment)
            for triple in triples:
                key = (triple.subject.lower(), triple.predicate.lower(), triple.object.lower())
                if key not in seen:
                    seen.add(key)
                    all_triples.append(triple)

        return all_triples
