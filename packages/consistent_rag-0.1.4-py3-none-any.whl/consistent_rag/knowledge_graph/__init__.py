"""Knowledge Graph module for ConsistentRAG."""

from .extractor import Triple, TripleExtractor
from .networkx_graph_store import GraphConfig, NetworkXGraphStore

# Backward compatibility alias
GraphStore = NetworkXGraphStore

__all__ = [
    "Triple",
    "TripleExtractor",
    "NetworkXGraphStore",
    "GraphStore",
    "GraphConfig",
]
