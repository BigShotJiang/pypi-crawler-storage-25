"""Locality-Sensitive Hashing (LSH) index for triple embeddings.

Uses Random Projection LSH (SimHash) for approximate cosine-similarity
search over dense vector embeddings.  This is the **Expander** component
of the ReAct refinement loop: when the critic identifies missing
concepts, we embed the missing requirement and query the LSH index to
instantly find semantically related triples without re-scanning the
whole graph.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from loguru import logger
import numpy as np


class CosineLSH:
    """Random-Projection LSH for cosine-similarity search."""

    def __init__(
        self,
        embedding_dim: int,
        num_bits: int = 128,
        *,
        seed: int = 42,
    ) -> None:
        """
        Args:
            embedding_dim: Dimension of vectors to be hashed.
            num_bits: Hash length.  Trade-off: more bits -> fewer collisions ->
                higher precision but lower recall.
            seed: Random seed for reproducible hyperplanes.
        """
        self.embedding_dim = embedding_dim
        self.num_bits = num_bits
        rng = np.random.default_rng(seed)
        self.planes = rng.standard_normal((num_bits, embedding_dim), dtype=np.float64)

        self.hash_table: dict[str, list[str]] = defaultdict(list)
        self.triples_store: dict[str, np.ndarray] = {}

    # ------------------------------------------------------------------
    # Core hashing
    # ------------------------------------------------------------------

    def _compute_hash(self, vector: np.ndarray) -> str:
        """Project vector against random planes to create a binary string."""
        projections = self.planes.dot(vector)
        return "".join("1" if p > 0 else "0" for p in projections)

    def _hamming_neighbors(self, hash_str: str, max_distance: int = 2) -> list[str]:
        """Generate hash strings within ``max_distance`` Hamming distance.

        Multi-probe LSH: if the exact bucket has few candidates, we also
        check nearby buckets (vectors that differ by a small number of bits).
        """
        neighbors = [hash_str]
        bits = list(hash_str)

        # Single-bit flips
        if max_distance >= 1:
            for i in range(self.num_bits):
                flipped = bits.copy()
                flipped[i] = "0" if flipped[i] == "1" else "1"
                neighbors.append("".join(flipped))

        # Two-bit flips (combinatorial, only for small num_bits)
        if max_distance >= 2 and self.num_bits <= 256:
            from itertools import combinations

            for i, j in combinations(range(self.num_bits), 2):
                flipped = bits.copy()
                flipped[i] = "0" if flipped[i] == "1" else "1"
                flipped[j] = "0" if flipped[j] == "1" else "1"
                neighbors.append("".join(flipped))

        return neighbors

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def insert(self, triple_id: str, triple_vector: np.ndarray) -> None:
        """Insert a triple embedding into the LSH index.

        Args:
            triple_id: Unique identifier for the triple (e.g. "S|P|O").
            triple_vector: Dense embedding vector.
        """
        if triple_id in self.triples_store:
            # Remove from old bucket before re-inserting
            old_hash = self._compute_hash(self.triples_store[triple_id])
            if triple_id in self.hash_table[old_hash]:
                self.hash_table[old_hash].remove(triple_id)

        hash_str = self._compute_hash(triple_vector)
        self.hash_table[hash_str].append(triple_id)
        self.triples_store[triple_id] = triple_vector

    def bulk_insert(
        self,
        triple_ids: list[str],
        triple_vectors: list[np.ndarray],
    ) -> None:
        """Batch insert triples."""
        for tid, vec in zip(triple_ids, triple_vectors):
            self.insert(tid, vec)

    def query(
        self,
        query_vector: np.ndarray,
        *,
        max_results: int = 20,
        probe_distance: int = 1,
    ) -> list[tuple[str, float]]:
        """Find approximate nearest neighbors.

        Uses multi-probe LSH: checks the exact hash bucket plus nearby
        buckets within ``probe_distance`` Hamming distance.  Candidates
        are then re-ranked by exact cosine similarity.

        Args:
            query_vector: Vector to search for.
            max_results: Maximum number of results to return.
            probe_distance: Hamming distance for multi-probe (0 = exact
                bucket only, 1 = single-bit flips, 2 = two-bit flips).

        Returns:
            List of (triple_id, cosine_similarity) sorted by similarity
            descending.
        """
        query_hash = self._compute_hash(query_vector)
        candidate_ids: set[str] = set()

        # Collect candidates from exact bucket + neighbors
        for neighbor_hash in self._hamming_neighbors(query_hash, probe_distance):
            candidate_ids.update(self.hash_table.get(neighbor_hash, []))

        if not candidate_ids:
            logger.debug(
                f"[LSH] No candidates found for hash {query_hash[:16]}... "
                f"(probe_distance={probe_distance})"
            )
            return []

        # Exact re-ranking with cosine similarity
        q_norm = np.linalg.norm(query_vector)
        if q_norm == 0:
            return []

        results: list[tuple[str, float]] = []
        for cid in candidate_ids:
            t_vec = self.triples_store[cid]
            t_norm = np.linalg.norm(t_vec)
            if t_norm > 0:
                sim = float(np.dot(t_vec, query_vector) / (t_norm * q_norm))
                results.append((cid, sim))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:max_results]

    def get_stats(self) -> dict[str, Any]:
        """Return index statistics."""
        n_buckets = len(self.hash_table)
        n_empty = 2**self.num_bits - n_buckets
        sizes = [len(v) for v in self.hash_table.values()]
        return {
            "num_triples": len(self.triples_store),
            "num_buckets_used": n_buckets,
            "num_buckets_empty": n_empty,
            "avg_bucket_size": float(np.mean(sizes)) if sizes else 0.0,
            "max_bucket_size": max(sizes) if sizes else 0,
            "num_bits": self.num_bits,
        }
