"""Backward compatibility shim — use networkx_graph_store instead."""

from .networkx_graph_store import GraphConfig, NetworkXGraphStore

# Alias for backward compatibility
GraphStore = NetworkXGraphStore

__all__ = ["GraphConfig", "GraphStore"]
