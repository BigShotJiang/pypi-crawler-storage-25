"""Project configuration and path constants."""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Paths
PROJ_ROOT = Path(__file__).resolve().parents[1]
DATASETS_DIR = PROJ_ROOT / "datasets"
DATA_DIR = PROJ_ROOT / "data"
MODELS_DIR = PROJ_ROOT / "models"
REPORTS_DIR = PROJ_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
