"""Base retriever types and abstract interface.

Defines the shared data models (``Document``, ``RetrievalResult``,
``RetrieverConfig``) and the ``BaseRetriever`` abstract base class that
all concrete retrievers (Qdrant, FAISS, ...) implement. The ``backend``
field on ``RetrieverConfig`` lets a factory dispatch to the right
implementation without leaking backend choice into user code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any
import uuid

from pydantic import BaseModel

from ..embeddings import EmbeddingConfig


class RetrieverConfig(BaseModel):
    """Configuration for a retriever, regardless of backend."""

    backend: str = "qdrant"
    qdrant_url: str = "http://localhost:6333"
    collection_name: str = "documents"
    top_k: int = 5
    embedding_config: EmbeddingConfig | None = None


class Document(BaseModel):
    """A document with text and metadata."""

    id: str | None = None
    text: str
    metadata: dict[str, Any] = {}

    def __post_init__(self):
        if self.id is None:
            self.id = str(uuid.uuid4())


class RetrievalResult(BaseModel):
    """Result from a retrieval query."""

    document: Document
    score: float


class BaseRetriever(ABC):
    """Abstract interface every retriever backend must implement.

    Concrete subclasses implement ``create_collection``, ``add_documents``,
    and ``retrieve``. ``format_context`` is shared across all backends.
    """

    def __init__(self, config: RetrieverConfig | None = None) -> None:
        self.config = config or RetrieverConfig()

    @abstractmethod
    def create_collection(self, recreate: bool = False) -> None:
        """Create (or reset) the underlying vector store."""

    @abstractmethod
    def add_documents(self, documents: list[Document]) -> None:
        """Embed and add documents to the underlying store."""

    @abstractmethod
    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievalResult]:
        """Retrieve the top-k most relevant documents for a query."""

    def format_context(self, results: list[RetrievalResult]) -> str:
        """Format retrieval results as a numbered context string."""
        return "\n\n".join(f"[{i}] {result.document.text}" for i, result in enumerate(results, 1))
