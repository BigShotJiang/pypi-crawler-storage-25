"""FAISS-based vector retriever — drop-in replacement for QdrantRetriever.

Same interface as QdrantRetriever but backed by a local FAISS index.
No external services required.
"""

from __future__ import annotations

import json
from pathlib import Path

import faiss
from loguru import logger
import numpy as np

from ..embeddings import EmbeddingService
from .base_retriever import (
    BaseRetriever,
    Document,
    RetrievalResult,
    RetrieverConfig,
)

__all__ = ["FAISSRetriever"]


class FAISSRetriever(BaseRetriever):
    """FAISS-based vector retriever with the same interface as QdrantRetriever.

    Drop-in replacement for the Qdrant-based retriever. Uses a local
    FAISS IndexFlatIP (cosine similarity via normalized inner product).
    No external services required.
    """

    def __init__(self, config: RetrieverConfig | None = None):
        super().__init__(config)
        self.embedder = EmbeddingService(self.config.embedding_config)
        self._index: faiss.IndexFlatIP | None = None
        self._documents: list[Document] = []

        logger.info(f"Initialized FAISS retriever (collection: {self.config.collection_name})")

    def create_collection(self, recreate: bool = False) -> None:
        """Create/reset the FAISS index."""
        if recreate or self._index is None:
            self._index = None
            self._documents = []
            logger.info(f"FAISS collection '{self.config.collection_name}' reset")

    def add_documents(self, documents: list[Document]) -> None:
        """Embed and add documents to the FAISS index."""
        if not documents:
            return

        texts = [doc.text for doc in documents]
        embeddings = self.embedder.embed(texts)
        vectors = np.array(embeddings, dtype=np.float32)

        # L2-normalize for cosine similarity
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1
        vectors = vectors / norms

        if self._index is None:
            dim = vectors.shape[1]
            self._index = faiss.IndexFlatIP(dim)

        self._index.add(vectors)
        self._documents.extend(documents)
        logger.info(
            f"Added {len(documents)} documents to FAISS index (total: {self._index.ntotal})"
        )

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievalResult]:
        """Retrieve relevant documents via FAISS similarity search."""
        top_k = top_k or self.config.top_k
        if self._index is None or self._index.ntotal == 0:
            return []

        query_emb = self.embedder.embed(query)
        query_vec = np.array([query_emb], dtype=np.float32)
        norm = np.linalg.norm(query_vec)
        if norm > 0:
            query_vec = query_vec / norm

        k = min(top_k, self._index.ntotal)
        scores, indices = self._index.search(query_vec, k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self._documents):
                continue
            doc = self._documents[idx]
            results.append(RetrievalResult(document=doc, score=float(score)))
        return results

    def save(self, path: str | Path) -> None:
        """Save FAISS index and documents to disk."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        if self._index is not None:
            faiss.write_index(self._index, str(path / "faiss.index"))

        docs_data = [{"id": d.id, "text": d.text, "metadata": d.metadata} for d in self._documents]
        with open(path / "documents.json", "w", encoding="utf-8") as f:
            json.dump(docs_data, f)

        logger.info(f"FAISS retriever saved to {path} ({len(self._documents)} docs)")

    def load(self, path: str | Path) -> None:
        """Load FAISS index and documents from disk."""
        path = Path(path)

        index_path = path / "faiss.index"
        if not index_path.exists():
            raise FileNotFoundError(f"FAISS index not found at {index_path}")

        self._index = faiss.read_index(str(index_path))

        with open(path / "documents.json", encoding="utf-8") as f:
            docs_data = json.load(f)

        self._documents = [Document(**d) for d in docs_data]
        logger.info(
            f"FAISS retriever loaded from {path}: "
            f"{self._index.ntotal} vectors, {len(self._documents)} docs"
        )

    @property
    def size(self) -> int:
        """Number of indexed documents."""
        return self._index.ntotal if self._index else 0
