"""Retrievers package — strategy + factory for vector store backends.

Public API:

    from consistent_rag.retrievers import (
        BaseRetriever,
        QdrantRetriever,
        FAISSRetriever,
        RetrieverConfig,
        RetrieverFactory,
        Document,
        RetrievalResult,
    )

    retriever = RetrieverFactory.create(RetrieverConfig(backend="faiss"))
"""

from .base_retriever import (
    BaseRetriever,
    Document,
    RetrievalResult,
    RetrieverConfig,
)
from .factory import RETRIEVER_REGISTRY, RetrieverFactory
from .faiss_retriever import FAISSRetriever
from .qdrant_retriever import QdrantRetriever

__all__ = [
    "BaseRetriever",
    "Document",
    "FAISSRetriever",
    "QdrantRetriever",
    "RetrievalResult",
    "RetrieverConfig",
    "RetrieverFactory",
    "RETRIEVER_REGISTRY",
]
