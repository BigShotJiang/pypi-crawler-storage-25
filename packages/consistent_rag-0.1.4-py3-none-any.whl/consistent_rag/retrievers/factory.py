"""Factory for constructing retrievers by backend name.

User code builds a ``RetrieverConfig`` (with the desired ``backend``) and
calls ``RetrieverFactory.create(config)``. The factory looks up the
backend in ``RETRIEVER_REGISTRY`` and returns a fully configured
``BaseRetriever`` instance, with no backend-specific conditionals at the
call site.
"""

from __future__ import annotations

from .base_retriever import BaseRetriever, RetrieverConfig
from .faiss_retriever import FAISSRetriever
from .qdrant_retriever import QdrantRetriever

RETRIEVER_REGISTRY: dict[str, type[BaseRetriever]] = {
    "qdrant": QdrantRetriever,
    "faiss": FAISSRetriever,
}


class RetrieverFactory:
    """Factory that dispatches to the right retriever backend."""

    @staticmethod
    def create(config: RetrieverConfig) -> BaseRetriever:
        """Construct a retriever for ``config.backend``.

        Raises:
            ValueError: if ``config.backend`` is not in the registry.
        """
        try:
            cls = RETRIEVER_REGISTRY[config.backend]
        except KeyError as exc:
            known = ", ".join(sorted(RETRIEVER_REGISTRY.keys()))
            raise ValueError(
                f"Unknown retriever backend: {config.backend!r} (known: {known})"
            ) from exc
        return cls(config)
