"""Vector store retriever using Qdrant."""

import uuid

from loguru import logger
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels

from ..embeddings import EmbeddingService
from .base_retriever import (
    BaseRetriever,
    Document,
    RetrievalResult,
    RetrieverConfig,
)

__all__ = ["QdrantRetriever"]


class QdrantRetriever(BaseRetriever):
    """Vector store retriever using Qdrant."""

    def __init__(self, config: RetrieverConfig | None = None):
        super().__init__(config)
        self.client = QdrantClient(url=self.config.qdrant_url)
        self.embedder = EmbeddingService(self.config.embedding_config)

        logger.info(f"Initialized retriever with collection: {self.config.collection_name}")

    def create_collection(self, recreate: bool = False) -> None:
        """Create the vector collection if it doesn't exist.

        Args:
            recreate: If True, delete and recreate the collection
        """
        collections = [c.name for c in self.client.get_collections().collections]

        if self.config.collection_name in collections:
            if recreate:
                logger.warning(f"Deleting existing collection: {self.config.collection_name}")
                self.client.delete_collection(self.config.collection_name)
            else:
                logger.info(f"Collection {self.config.collection_name} already exists")
                return

        self.client.create_collection(
            collection_name=self.config.collection_name,
            vectors_config=qmodels.VectorParams(
                size=self.embedder.dimension,
                distance=qmodels.Distance.COSINE,
            ),
        )
        logger.info(f"Created collection: {self.config.collection_name}")

    def add_documents(self, documents: list[Document]) -> None:
        """Add documents to the vector store.

        Args:
            documents: List of documents to add
        """
        if not documents:
            return

        texts = [doc.text for doc in documents]
        embeddings = self.embedder.embed(texts)

        points = []
        for i, doc in enumerate(documents):
            doc_id = doc.id or str(uuid.uuid4())
            # Qdrant requires point IDs to be UUID strings or positive integers.
            # Always use UUID for the point ID; store original doc_id in payload.
            point_id = str(uuid.uuid4())
            points.append(
                qmodels.PointStruct(
                    id=point_id,
                    vector=embeddings[i].tolist(),
                    payload={"text": doc.text, "doc_id": doc_id, **doc.metadata},
                )
            )

        self.client.upsert(
            collection_name=self.config.collection_name,
            points=points,
        )
        logger.info(f"Added {len(documents)} documents to collection")

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievalResult]:
        """Retrieve relevant documents for a query.

        Args:
            query: The search query
            top_k: Number of results to return (overrides config)

        Returns:
            List of retrieval results with documents and scores
        """
        top_k = top_k or self.config.top_k
        query_embedding = self.embedder.embed(query)

        # Use query_points for qdrant-client >= 1.10
        results = self.client.query_points(
            collection_name=self.config.collection_name,
            query=query_embedding.tolist(),
            limit=top_k,
        ).points

        retrieval_results = []
        for result in results:
            payload = result.payload or {}
            doc = Document(
                id=payload.get("doc_id", str(result.id)),
                text=payload.get("text", ""),
                metadata={k: v for k, v in payload.items() if k not in ["text", "doc_id"]},
            )
            retrieval_results.append(RetrievalResult(document=doc, score=result.score))

        return retrieval_results
