"""Base configuration with LLM settings.

THESIS-RELEVANT:
    - Change model: BaseConfig.model
    - Change API credentials: BaseConfig.api_key, BaseConfig.base_url
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BaseConfig:
    """Base configuration shared across all pipeline types.

    Contains LLM settings and API credentials.

    Attributes:
        model: LLM model name (default: "gpt-4o-mini")
        api_key: OpenAI-compatible API key (default: from env)
        base_url: API base URL (default: from env)
    """

    model: str = "gpt-4o-mini"
    api_key: str | None = None
    base_url: str | None = None
