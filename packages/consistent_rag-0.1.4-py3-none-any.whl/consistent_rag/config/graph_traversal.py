"""Graph traversal strategy configuration.

Controls which algorithm is used to traverse the knowledge graph
and find relevant subgraphs.

THESIS-RELEVANT PARAMETERS (edit these for experiments):
    - strategy: Which algorithm (PPR, NHOPS, RANDOM_WALK, HYBRID)
    - ppr_alpha: Damping factor for PPR (0.0-1.0, default 0.5)
    - nhops_depth: BFS depth for N-hops (default 2)
    - hybrid_alpha: Balance between structure and semantics (0.0-1.0)

Examples:
    >>> from consistent_rag.config import GraphTraversalConfig
    >>>
    >>> # PPR with high damping (more exploration)
    >>> config = GraphTraversalConfig(strategy="ppr", ppr_alpha=0.8)
    >>>
    >>> # Deep N-hops traversal
    >>> config = GraphTraversalConfig(strategy="nhops", nhops_depth=5)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class SubgraphStrategy(str, Enum):
    """Strategy for subgraph ranking."""

    PPR = "ppr"
    NHOPS = "nhops"
    RANDOM_WALK = "random_walk"
    HYBRID = "hybrid"


@dataclass
class GraphTraversalConfig:
    """Configuration for graph traversal algorithms.

    Each strategy uses a subset of these parameters:
    - PPR: ppr_alpha, ppr_iterations
    - NHOPS: nhops_depth
    - RANDOM_WALK: (no specific params)
    - HYBRID: hybrid_alpha, hybrid_max_hops, hybrid_top_k_per_hop

    Attributes:
        strategy: Which traversal algorithm to use
        ppr_alpha: Damping factor for PPR (default: 0.5, higher = more exploration)
        ppr_iterations: Number of power iterations for PPR (default: 20)
        nhops_depth: BFS depth for N-hops traversal (default: 2)
        hybrid_alpha: Structure vs semantics balance (default: 0.5, 1.0 = structure only)
        hybrid_max_hops: Maximum hops for hybrid traversal (default: 3)
        hybrid_top_k_per_hop: Frontier cap per hop level (default: 10)
    """

    strategy: SubgraphStrategy = field(default_factory=lambda: SubgraphStrategy.PPR)

    # PPR-specific parameters
    ppr_alpha: float = 0.5
    ppr_iterations: int = 20

    # N-hops specific parameters
    nhops_depth: int = 2

    # Hybrid traversal parameters
    hybrid_alpha: float = 0.5
    hybrid_max_hops: int = 3
    hybrid_top_k_per_hop: int = 10

    # Progressive expansion (all strategies)
    expansion_nhops_step: int = 1
    expansion_hybrid_hops_step: int = 1
    expansion_hybrid_topk_step: int = 5

    def __post_init__(self):
        """Convert string strategy to enum if needed."""
        if isinstance(self.strategy, str):
            self.strategy = SubgraphStrategy(self.strategy.lower())
