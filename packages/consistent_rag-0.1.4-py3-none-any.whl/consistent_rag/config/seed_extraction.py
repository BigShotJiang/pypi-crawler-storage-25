"""Seed extraction configuration.

Controls how seed entities are extracted from queries for graph traversal.

THESIS-RELEVANT PARAMETERS:
    - min_score: Minimum relevance score for seeds (default: 0.3)
    - faiss_threshold: Cosine similarity for FAISS matching (default: 0.85)
    - max_total: Hard cap on total seeds (default: 15)

Examples:
    >>> from consistent_rag.config import SeedExtractionConfig
    >>>
    >>> # Strict seed filtering
    >>> config = SeedExtractionConfig(min_score=0.5, max_total=10)
    >>>
    >>> # Allow more seeds with lower threshold
    >>> config = SeedExtractionConfig(min_score=0.2, max_total=20)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SeedExtractionConfig:
    """Configuration for seed entity extraction.

    Seeds are the starting points for graph traversal.
    Good seeds = better traversal results.

    Attributes:
        use_hybrid: Use graph-aware seed extraction (default: True)
        search_limit: Max entities per search term (default: 5)
        match_strategy: How to match seeds to graph (default: "faiss")
            Options: "exact", "substring", "faiss", "hybrid"
        faiss_threshold: Min cosine similarity for FAISS match (default: 0.85)
        max_total: Hard cap on total seeds (default: 15)
        graph_match_boost: Score boost for graph-matched entities (default: 0.10)
        llm_fallback_penalty: Penalty for LLM-only candidates (default: 0.20)
        enable_llm_fallback: Include LLM candidates not in graph (default: False)
        min_score: Minimum relevance score for inclusion (default: 0.3)
    """

    use_hybrid: bool = True
    search_limit: int = 5
    match_strategy: str = "faiss"
    faiss_threshold: float = 0.85
    max_total: int = 15
    graph_match_boost: float = 0.10
    llm_fallback_penalty: float = 0.20
    enable_llm_fallback: bool = False
    min_score: float = 0.3
