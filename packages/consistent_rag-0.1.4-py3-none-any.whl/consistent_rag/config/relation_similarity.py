"""Configuration for relation similarity detection.

Relation similarity is used to detect contradictory triples in knowledge graphs.
For example, "FOUNDED_BY" and "CREATED_BY" are similar relations that could
lead to contradictions if they have different objects for the same subject.

THESIS-RELEVANT PARAMETERS:
    - embedding_model: Which model to use for semantic similarity
    - embedding_similarity_threshold: Minimum cosine similarity to consider relations similar
    - string_similarity_threshold: Fallback Jaro-Winkler threshold

For broad domains (science, medicine, law), use embedding-based similarity.
For narrow domains with known relation vocabularies, explicit synonym groups work too.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RelationSimilarityConfig:
    """Configuration for relation similarity detection.

    Detects when two relation predicates are semantically similar,
    which is needed for contradiction detection.

    Three approaches (can be combined):
    1. Embedding-based (recommended for broad domains): Uses sentence embeddings
       to compute semantic similarity. Works for ANY domain.
    2. Explicit synonym groups: Predefined groups of equivalent relations.
       Best for narrow, well-defined domains.
    3. String similarity fallback: Jaro-Winkler string similarity.
       Always active as final fallback.

    Examples:
        >>> # Broad domain (science, medicine, etc.)
        >>> config = RelationSimilarityConfig(
        ...     use_embedding_similarity=True,
        ...     embedding_similarity_threshold=0.85,
        ... )

        >>> # Narrow domain (business entities)
        >>> config = RelationSimilarityConfig(
        ...     use_embedding_similarity=False,
        ...     synonym_groups=[
        ...         ["FOUNDED_BY", "CREATED_BY", "ESTABLISHED_BY"],
        ...         ["CEO", "CHIEF_EXECUTIVE", "HEAD_OF"],
        ...     ],
        ... )
    """

    # Option 1: Embedding-based similarity (recommended for broad domains)
    use_embedding_similarity: bool = True
    embedding_similarity_threshold: float = 0.85
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Option 2: Explicit synonym groups (for narrow, known domains)
    synonym_groups: list[list[str]] = field(default_factory=list)

    # Option 3: String similarity fallback (always active)
    string_similarity_threshold: float = 0.85

    def __post_init__(self):
        """Validate configuration."""
        if not 0 <= self.embedding_similarity_threshold <= 1:
            raise ValueError("embedding_similarity_threshold must be in [0, 1]")
        if not 0 <= self.string_similarity_threshold <= 1:
            raise ValueError("string_similarity_threshold must be in [0, 1]")
