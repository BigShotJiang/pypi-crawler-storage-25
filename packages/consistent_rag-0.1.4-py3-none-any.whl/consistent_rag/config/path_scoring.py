"""Path scoring configuration.

Controls how reasoning paths are scored and ranked.

THESIS-RELEVANT PARAMETERS (most important for experiments):
    - endpoint_weight: How much to weight destination entity's PPR score
    - confidence_weight: How much to weight weakest edge's confidence
    - length_weight: How much to penalize longer paths
    - relevance_threshold: Minimum score for entity to count toward budget
    - max_paths: Maximum reasoning paths to include (default: 20)

FORMULA:
    score = endpoint_score^endpoint_weight *
            min_confidence^confidence_weight *
            (1/length)^length_weight

Examples:
    >>> from consistent_rag.config import PathScoringConfig
    >>>
    >>> # Prefer shorter paths (Occam's razor)
    >>> config = PathScoringConfig(length_weight=2.0)
    >>>
    >>> # Prefer high-confidence edges
    >>> config = PathScoringConfig(confidence_weight=2.0)
    >>>
    >>> # More paths in context
    >>> config = PathScoringConfig(max_paths=50)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PathScoringConfig:
    """Configuration for reasoning path scoring.

    The scoring formula combines three factors:
    1. endpoint_score: How relevant the destination entity is
    2. min_confidence: Weakest link in the path (edge confidence)
    3. path_length: Number of hops (shorter = better)

    Attributes:
        relevance_threshold: Entities scored above this count toward budget (default: 0.3)
        max_paths: Maximum reasoning paths to include in context (default: 20)
        min_path_score: Minimum score for path inclusion (default: 0.5)
        endpoint_weight: Weight for destination entity score (default: 1.0)
        confidence_weight: Weight for minimum edge confidence (default: 1.0)
        length_weight: Weight for path length penalty (default: 1.0)
        default_edge_confidence: Default confidence when edge has none (default: 0.5)
    """

    relevance_threshold: float = 0.3
    max_paths: int = 20
    min_path_score: float = 0.5

    # Weight parameters for thesis experimentation
    endpoint_weight: float = 1.0
    confidence_weight: float = 1.0
    length_weight: float = 1.0
    default_edge_confidence: float = 0.5

    # Progressive expansion
    expansion_relevance_delta: float = 0.05
    expansion_max_paths_step: int = 5
