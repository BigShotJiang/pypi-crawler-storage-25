"""ConsistentRAG configuration package.

Provides focused configuration classes for different aspects of the system.

THESIS-RELEVANT CONFIGURATION:
    - Graph traversal: config.graph_traversal.GraphTraversalConfig
    - Path scoring: config.path_scoring.PathScoringConfig
    - Seed extraction: config.seed_extraction.SeedExtractionConfig

Examples:
    >>> from consistent_rag.config import (
    ...     GraphTraversalConfig,
    ...     PathScoringConfig,
    ...     SeedExtractionConfig,
    ... )
    >>>
    >>> # Configure for PPR with custom alpha
    >>> traversal = GraphTraversalConfig(strategy="ppr", ppr_alpha=0.7)
    >>>
    >>> # Configure path scoring
    >>> scoring = PathScoringConfig(max_paths=30, length_weight=1.5)
"""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv

from .base import BaseConfig
from .graph_traversal import GraphTraversalConfig, SubgraphStrategy
from .path_scoring import PathScoringConfig
from .relation_similarity import RelationSimilarityConfig
from .seed_extraction import SeedExtractionConfig

load_dotenv()

# Path constants (backward compatibility)
PROJ_ROOT = Path(__file__).resolve().parents[2]
DATASETS_DIR = PROJ_ROOT / "datasets"
DATA_DIR = PROJ_ROOT / "data"
MODELS_DIR = PROJ_ROOT / "models"
REPORTS_DIR = PROJ_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"

__all__ = [
    "BaseConfig",
    "GraphTraversalConfig",
    "PathScoringConfig",
    "RelationSimilarityConfig",
    "SeedExtractionConfig",
    "SubgraphStrategy",
    "PROJ_ROOT",
    "DATASETS_DIR",
    "DATA_DIR",
    "MODELS_DIR",
    "REPORTS_DIR",
    "FIGURES_DIR",
]
