"""Logging configuration for ConsistentRAG.

Provides centralized loguru configuration to prevent duplicate log output
and allow runtime control of log levels.
"""

from __future__ import annotations

import sys
from typing import Literal

from loguru import logger

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

# Track if we've already configured logging to prevent duplicates
_CONFIGURED = False


def _remove_all_handlers() -> None:
    """Remove all loguru handlers including the default one."""
    # Get all handler IDs and remove them
    handler_ids = list(logger._core.handlers.keys())
    for handler_id in handler_ids:
        logger.remove(handler_id)


def configure_logging(
    level: LogLevel = "INFO",
    *,
    sink: object = sys.stderr,
    force: bool = False,
) -> None:
    """Configure loguru with a single handler to prevent duplicate output.

    This function is safe to call multiple times - it will remove all
    existing handlers and configure a single handler each time.

    Args:
        level: Minimum log level to display (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        sink: Where to send logs (default: sys.stderr)
        force: If True, remove all existing handlers and reconfigure
            (always applies, kept for API compatibility)

    Example:
        >>> from consistent_rag.logging_config import configure_logging
        >>> configure_logging("DEBUG")  # Show all logs
        >>> configure_logging("ERROR")  # Only show errors
    """
    global _CONFIGURED

    # Always remove all handlers to ensure clean state
    # This prevents duplicate output from the default handler
    _remove_all_handlers()

    # Add a single handler with the specified level
    # Note: enqueue=False to avoid issues with Jupyter notebook output capture
    logger.add(
        sink,
        level=level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>",
        colorize=True,
        enqueue=False,  # Disabled to prevent Jupyter notebook duplication issues
        backtrace=True,
        diagnose=True,
    )
    _CONFIGURED = True


def set_log_level(level: LogLevel) -> None:
    """Change the log level at runtime.

    Args:
        level: New minimum log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

    Example:
        >>> from consistent_rag.logging_config import set_log_level
        >>> set_log_level("DEBUG")  # Increase verbosity
        >>> set_log_level("WARNING")  # Decrease verbosity
    """
    # Remove all handlers and re-add with new level
    _remove_all_handlers()
    global _CONFIGURED
    _CONFIGURED = False
    configure_logging(level)


def get_current_level() -> str:
    """Get the current minimum log level.

    Returns:
        Current log level as string (e.g., "INFO", "DEBUG")
    """
    # Check the first handler's level
    for handler_id, handler in logger._core.handlers.items():
        return handler.level.name
    return "INFO"
