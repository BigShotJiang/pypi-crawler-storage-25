"""Unified evaluation runner for all ConsistentRAG pipeline configurations.

Usage:
    python -m consistent_rag.evaluate_all --approaches all --benchmark all --limit 10
    python -m consistent_rag.evaluate_all --approaches agentic_kg_ppr --benchmark faitheval
    python -m consistent_rag.evaluate_all --approaches all --benchmark financebench --resume --csv results.csv

This module is a thin shim that delegates to the evaluation runner package.
"""

from consistent_rag.evaluation.runner import (  # noqa: F401
    APPROACHES,
    BENCHMARKS,
    BenchmarkCSVWriter,
    load_completed_samples,
    run_all,
    run_approach,
)
from consistent_rag.evaluation.runner.cli import build_parser, main

__all__ = [
    "APPROACHES",
    "BENCHMARKS",
    "BenchmarkCSVWriter",
    "build_parser",
    "load_completed_samples",
    "main",
    "run_all",
    "run_approach",
]

if __name__ == "__main__":
    main()
