"""Embedding service for vector representations.

Supports OpenAI API models (default: text-embedding-ada-002) and
local sentence-transformers models (e.g., all-MiniLM-L6-v2).
Automatically detects Azure endpoints and uses the right client.
"""

from __future__ import annotations

from typing import Literal

from loguru import logger
import numpy as np
from pydantic import BaseModel

from .llm import create_openai_client, resolve_llm_credentials

# Known OpenAI embedding models and their dimensions
OPENAI_EMBEDDING_MODELS = {
    "text-embedding-ada-002": 1536,
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
}


class EmbeddingConfig(BaseModel):
    """Configuration for the embedding service."""

    model_name: str = "text-embedding-ada-002"
    device: Literal["cpu", "cuda", "mps"] | None = None
    batch_size: int = 32
    normalize: bool = True


class EmbeddingService:
    """Service for generating text embeddings.

    Default: OpenAI text-embedding-ada-002 via API (uses same credentials as LLM).
    Alternative: any sentence-transformers model for local/free inference.
    """

    def __init__(self, config: EmbeddingConfig | None = None):
        if config is None:
            config = EmbeddingConfig()

        self.config = config
        self._client = None
        self._dimension: int | None = None
        self._is_api = config.model_name in OPENAI_EMBEDDING_MODELS

    @property
    def client(self):
        """Lazy-load the embedding client (API or local model)."""
        if self._client is None:
            if self._is_api:
                self._client = self._create_api_client()
            else:
                self._client = self._create_local_model()
        return self._client

    # Keep backward compat — some code accesses .model
    @property
    def model(self):
        return self.client

    def _create_api_client(self):
        """Create an OpenAI/Azure embedding client using LLM credentials."""

        api_key, base_url = resolve_llm_credentials()
        client = create_openai_client(api_key, base_url)
        logger.info(f"Embedding via API: model={self.config.model_name}, endpoint={base_url}")
        return client

    def _create_local_model(self):
        """Load a local sentence-transformers model."""
        from sentence_transformers import SentenceTransformer

        logger.info(f"Loading local embedding model: {self.config.model_name}")
        model = SentenceTransformer(
            self.config.model_name,
            device=self.config.device,
        )
        logger.info("Local embedding model loaded")
        return model

    @property
    def dimension(self) -> int:
        """Get the embedding dimension."""
        if self._dimension is None:
            if self._is_api:
                self._dimension = OPENAI_EMBEDDING_MODELS[self.config.model_name]
            else:
                dim = self.client.get_sentence_embedding_dimension()
                if dim is None:
                    raise ValueError("Could not determine embedding dimension")
                self._dimension = dim
        return self._dimension

    def embed(self, texts: str | list[str]) -> np.ndarray:
        """Generate embeddings for text(s).

        Args:
            texts: Single text or list of texts to embed

        Returns:
            Numpy array of embeddings. Shape (n, dim) for list input,
            (dim,) for single string input.
        """
        if isinstance(texts, str):
            texts = [texts]
            single = True
        else:
            single = False

        if self._is_api:
            embeddings = self._embed_api(texts)
        else:
            embeddings = self.client.encode(
                texts,
                batch_size=self.config.batch_size,
                normalize_embeddings=self.config.normalize,
                show_progress_bar=len(texts) > 100,
            )

        if single:
            return embeddings[0]
        return embeddings

    def _embed_api(self, texts: list[str]) -> np.ndarray:
        """Generate embeddings via OpenAI/Azure API."""
        all_embeddings = []
        for i in range(0, len(texts), self.config.batch_size):
            batch = texts[i : i + self.config.batch_size]
            response = self.client.embeddings.create(
                model=self.config.model_name,
                input=batch,
            )
            batch_embs = [item.embedding for item in response.data]
            all_embeddings.extend(batch_embs)

        result = np.array(all_embeddings, dtype=np.float32)

        if self.config.normalize:
            norms = np.linalg.norm(result, axis=1, keepdims=True)
            norms[norms == 0] = 1
            result = result / norms

        return result

    def similarity(self, query: str, documents: list[str]) -> np.ndarray:
        """Compute cosine similarity between query and documents."""
        query_emb = self.embed(query)
        doc_embs = self.embed(documents)
        return np.dot(doc_embs, query_emb)
