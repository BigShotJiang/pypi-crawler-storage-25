"""Evaluation metrics for RAG systems."""

from __future__ import annotations

from collections import Counter
import re
import string
from typing import TYPE_CHECKING

import inflect
from pydantic import BaseModel

from ..llm import LLMClient

if TYPE_CHECKING:
    from ..benchmarks.faitheval import FaithEvalSample
    from .models import FaithEvalResponse


class EvaluationResult(BaseModel):
    """Container for evaluation results."""

    sample_id: str
    prediction: str
    ground_truth: str | None  # Primary answer
    ground_truths: list[str] = []  # All acceptable answers
    exact_match: bool
    f1: float
    accuracy: float = 0.0  # TruthfulRAG-style: normalized ground truth in prediction
    faithfulness: float | None = None
    # FaithEval-specific fields
    conflict_detection_correct: bool | None = None
    unanswerable_detected: bool | None = None
    choice_correct: bool | None = None
    justification_similarity: float | None = None
    answer_label: str | None = None
    selected_choice: str | None = None
    metadata: dict = {}


ENGINE = inflect.engine()


def normalize_answer(s: str, p=ENGINE) -> str:
    """Lower text and remove punctuation, articles and extra whitespace."""

    def remove_articles(text):
        return re.sub(r"\b(a|an|the)\b", " ", text)

    def white_space_fix(text):
        return " ".join(text.split())

    def handle_punc(text):
        exclude = set(string.punctuation + "".join(["‘", "’", "´", "`"]))
        return "".join(ch if ch not in exclude else " " for ch in text)

    def lower(text):
        return text.lower()

    def replace_underscore(text):
        return text.replace("_", " ")

    def convert_numbers_to_words(text):
        words = text.split()
        result = []
        for word in words:
            if word.isdigit() and int(word) < 100:
                word_in_words = p.number_to_words(int(word))
                result.append(word_in_words)
            else:
                result.append(word)
        return " ".join(result)

    if not s:
        return ""
    return white_space_fix(
        remove_articles(handle_punc(convert_numbers_to_words(lower(replace_underscore(s)))))
    ).strip()


def exact_match_score(prediction: str, ground_truth: str) -> float:
    """Check if prediction exactly matches ground truth after normalization."""
    return float(normalize_answer(prediction) == normalize_answer(ground_truth))


def acc_score(prediction: str, ground_truth: str) -> float:
    """Check if ground truth is contained in prediction after normalization."""
    return float(normalize_answer(ground_truth) in normalize_answer(prediction))


def metric_max_over_ground_truths(metric_fn, prediction, ground_truths):
    """Compute max metric score across all acceptable answers."""
    scores_for_ground_truths = []
    if not ground_truths:
        return 0.0

    # Handle case where ground_truths might not be a list (though type hint says it is)
    if not isinstance(ground_truths, list):
        ground_truths = [ground_truths]

    for ground_truth in ground_truths:
        score = metric_fn(prediction, ground_truth)
        scores_for_ground_truths.append(score)
    return max(scores_for_ground_truths)


def exact_match_any(prediction: str, ground_truths: list[str]) -> bool:
    """Check if prediction matches any of the acceptable answers.

    Uses both exact match and containment: returns True if the normalized
    ground truth is contained within the normalized prediction, or vice versa.
    """
    if not ground_truths:
        return False
    norm_pred = normalize_answer(prediction)
    for gt in ground_truths:
        norm_gt = normalize_answer(gt)
        if norm_pred == norm_gt or norm_gt in norm_pred or norm_pred in norm_gt:
            return True
    return False


def f1_score(prediction: str, ground_truth: str) -> float:
    """Compute token-level F1 score between prediction and ground truth."""
    pred_tokens = normalize_answer(prediction).split()
    gt_tokens = normalize_answer(ground_truth).split()

    common = Counter(pred_tokens) & Counter(gt_tokens)
    num_same = sum(common.values())

    if num_same == 0:
        return 0.0

    precision = 1.0 * num_same / len(pred_tokens)
    recall = 1.0 * num_same / len(gt_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1


def f1_score_max(prediction: str, ground_truths: list[str]) -> float:
    """Compute max F1 score across all acceptable answers."""
    return metric_max_over_ground_truths(f1_score, prediction, ground_truths)


def acc_score_max(prediction: str, ground_truths: list[str]) -> float:
    """Compute max TruthfulRAG-style accuracy across all acceptable answers.

    Mirrors `acc_score` from TruthfulRAG (`truthfulrag/evaluate.py:11-12`):
    after normalisation, the sample is considered correct if any reference
    answer appears as a substring of the prediction. Useful on tasks with
    short canonical answers where the model may wrap the answer in
    explanatory prose.
    """
    return metric_max_over_ground_truths(acc_score, prediction, ground_truths)


def accuracy(results: list[EvaluationResult]) -> float:
    """Compute accuracy over a list of results."""
    if not results:
        return 0.0
    return sum(1 for r in results if r.exact_match) / len(results)


def faithfulness_score(
    prediction: str,
    context: str,
    ground_truth: str | None = None,
) -> float:
    """Compute a simple faithfulness score (token overlap heuristic).

    This is a basic heuristic that checks if the prediction's key tokens
    appear in the context. For research use, prefer nli_faithfulness or
    llm_judge_faithfulness.

    Args:
        prediction: The model's prediction
        context: The provided context
        ground_truth: Optional ground truth for additional signal

    Returns:
        Faithfulness score between 0 and 1
    """
    pred_tokens = set(normalize_answer(prediction).split())
    context_tokens = set(normalize_answer(context).split())

    if not pred_tokens:
        return 0.0

    # Remove common stop words for better signal
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "again",
        "further",
        "then",
        "once",
        "here",
        "there",
        "when",
        "where",
        "why",
        "how",
        "all",
        "each",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "no",
        "nor",
        "not",
        "only",
        "own",
        "same",
        "so",
        "than",
        "too",
        "very",
        "just",
        "but",
        "and",
        "or",
        "if",
        "because",
        "until",
        "while",
        "this",
        "that",
        "these",
        "those",
        "it",
        "its",
    }

    pred_content_tokens = pred_tokens - stop_words
    context_content_tokens = context_tokens - stop_words

    if not pred_content_tokens:
        return 1.0  # Prediction only has stop words, consider faithful

    # Compute overlap
    overlap = pred_content_tokens & context_content_tokens
    faithfulness = len(overlap) / len(pred_content_tokens)

    return faithfulness


# =============================================================================
# Research-Grade Faithfulness Metrics (for publication)
# =============================================================================


def llm_judge_faithfulness(
    prediction: str,
    context: str,
    llm_client=None,
) -> tuple[float, str]:
    """Compute faithfulness using LLM-as-judge approach.

    Uses an LLM to evaluate how well-grounded the prediction is in context.

    Args:
        prediction: The model's prediction
        context: The provided context
        llm_client: Optional LLMClient instance (creates one if None)

    Returns:
        Tuple of (score, reasoning) where score is between 0 and 1
    """
    if llm_client is None:
        llm_client = LLMClient()

    prompt = f"""Evaluate faithfulness of this answer to the given context.

Context:
{context[:2000]}

Answer:
{prediction}

Rate the answer's faithfulness on a scale of 0.0 to 1.0 where:
- 1.0 = Every claim is directly supported by the context
- 0.5 = Some claims are supported, some are not in context
- 0.0 = Answer contains information contradicting or not in context

Respond in this exact format:
SCORE: [number between 0.0 and 1.0]
REASONING: [brief explanation]"""

    response = llm_client.generate(
        prompt,
        system_prompt="You are a precise evaluator. Rate faithfulness strictly.",
        temperature=0.0,
    )

    # Parse response
    score = 0.5  # Default
    reasoning = response

    try:
        score_match = re.search(r"SCORE:\s*([0-9.]+)", response)
        if score_match:
            score = float(score_match.group(1))
            score = max(0.0, min(1.0, score))  # Clamp to [0, 1]

        reason_match = re.search(r"REASONING:\s*(.+)", response, re.DOTALL)
        if reason_match:
            reasoning = reason_match.group(1).strip()
    except Exception:
        pass

    return score, reasoning


def claim_faithfulness(
    prediction: str,
    context: str,
    llm_client=None,
) -> float:
    """Compute faithfulness using claim decomposition (RAGAS-style).

    Decomposes the prediction into atomic claims and verifies each against
    the context. Returns the fraction of claims supported by context.

    Args:
        prediction: The model's prediction
        context: The provided context
        llm_client: Optional LLMClient instance

    Returns:
        Faithfulness score (supported_claims / total_claims)
    """
    if llm_client is None:
        llm_client = LLMClient()  # XXX: using default for the moment(same deepseek as judge)

    # Step 1: Decompose prediction into atomic claims
    decompose_prompt = f"""Break this answer into atomic factual claims. Each claim should be a single verifiable statement.

Answer: {prediction}

List each claim on a new line, prefixed with "- ":"""

    claims_response = llm_client.generate(
        decompose_prompt,
        system_prompt="Extract factual claims. Be thorough but concise.",
        temperature=0.0,
    )

    # Parse claims
    claims = []
    for line in claims_response.split("\n"):
        line = line.strip()
        if line.startswith("- "):
            claims.append(line[2:])
        elif line.startswith("•"):
            claims.append(line[1:].strip())

    if not claims:
        return 1.0  # No claims to verify

    # Step 2: Verify each claim against context
    supported = 0
    for claim in claims:
        verify_prompt = f"""Is this claim supported by the context?

Context: {context[:1500]}

Claim: {claim}

Answer only YES or NO."""

        result = llm_client.generate(
            verify_prompt,
            system_prompt="Answer only YES or NO based strictly on context.",
            temperature=0.0,
        )

        if "YES" in result.upper():
            supported += 1

    return supported / len(claims) if claims else 1.0


def deepeval_faithfulness(
    prediction: str,
    context: str,
    model_name: str = "gpt-4o",
) -> float:
    """Compute faithfulness using DeepEval.

    Args:
        prediction: The model's prediction
        context: The provided context
        model_name: Model to use for evaluation

    Returns:
        Faithfulness score between 0 and 1
    """
    try:
        from deepeval.metrics import FaithfulnessMetric
        from deepeval.test_case import LLMTestCase
    except ImportError:
        # loguru is imported at module level in this project context usually, but metrics.py
        # imports it? No, looking at file it imports `re`, `string`, `pydantic`.
        # I'll just print specific error or return None/0.
        print("deepeval not installed. Run: pip install deepeval")
        return 0.0

    experiment_test_case = LLMTestCase(
        input="Query not provided for faithfulness check",  # Faithfulness only needs actual_output and retrieval_context
        actual_output=prediction,
        retrieval_context=[context],
    )

    metric = FaithfulnessMetric(threshold=0.0, model=model_name, include_reason=False)

    try:
        metric.measure(experiment_test_case)
        return metric.score
    except Exception as e:
        print(f"DeepEval faithfulness failed: {e}")
        return 0.0


class Evaluator:
    """Evaluator for RAG system outputs."""

    def __init__(self, compute_faithfulness: bool = True):
        self.compute_faithfulness = compute_faithfulness
        self.results: list[EvaluationResult] = []

    def evaluate_sample(
        self,
        sample_id: str,
        prediction: str,
        ground_truth: str | None = None,
        ground_truths: list[str] | None = None,
        context: str | None = None,
    ) -> EvaluationResult:
        """Evaluate a single sample.

        Args:
            sample_id: Unique identifier for the sample
            prediction: Model's prediction
            ground_truth: Primary expected answer (if available)
            ground_truths: List of all acceptable answers
            context: Context used for generation (for faithfulness)

        Returns:
            EvaluationResult with computed metrics
        """
        # Build list of acceptable answers
        all_answers = ground_truths or []
        if ground_truth and ground_truth not in all_answers:
            all_answers = [ground_truth] + all_answers

        if all_answers:
            em = exact_match_any(prediction, all_answers)
            f1 = f1_score_max(prediction, all_answers)
            acc = acc_score_max(prediction, all_answers)
        else:
            em = False
            f1 = 0.0
            acc = 0.0

        faith = None
        if self.compute_faithfulness and context:
            faith = faithfulness_score(prediction, context, ground_truth)

        result = EvaluationResult(
            sample_id=sample_id,
            prediction=prediction,
            ground_truth=ground_truth,
            ground_truths=all_answers,
            exact_match=em,
            f1=f1,
            accuracy=acc,
            faithfulness=faith,
        )

        self.results.append(result)
        return result

    def evaluate_faitheval_sample(
        self,
        sample: FaithEvalSample,
        response: FaithEvalResponse,
        context: str | None = None,
    ) -> EvaluationResult:
        """Evaluate a FaithEval sample with dataset-aware metrics.

        Dispatches evaluation logic based on sample.conflict_type:
        - Inconsistent: check answer against answers array + label match
        - Unanswerable: check if answer_label == UNANSWERABLE
        - Counterfactual: check selected_choice against answerKey + label match

        Args:
            sample: The FaithEval benchmark sample
            response: The LLM's structured FaithEvalResponse
            context: Context used for generation (for faithfulness)

        Returns:
            EvaluationResult with FaithEval-specific metrics
        """
        from ..benchmarks.faitheval import ConflictType
        from .models import AnswerLabel

        prediction = response.answer
        all_answers = sample.answers or []
        if sample.answer and sample.answer not in all_answers:
            all_answers = [sample.answer] + all_answers

        # Standard metrics
        if all_answers:
            em = exact_match_any(prediction, all_answers)
            f1 = f1_score_max(prediction, all_answers)
            acc = acc_score_max(prediction, all_answers)
        else:
            em = False
            f1 = 0.0
            acc = 0.0

        faith = None
        if self.compute_faithfulness and context:
            faith = faithfulness_score(prediction, context, sample.answer)

        # Conflict detection accuracy
        label_to_conflict = {
            AnswerLabel.CONSISTENT: None,  # No specific conflict
            AnswerLabel.INCONSISTENT: ConflictType.INCONSISTENT,
            AnswerLabel.UNANSWERABLE: ConflictType.UNANSWERABLE,
            AnswerLabel.COUNTERFACTUAL: ConflictType.COUNTERFACTUAL,
        }
        detected_conflict = label_to_conflict.get(response.answer_label)
        conflict_correct = detected_conflict == sample.conflict_type

        # Dataset-specific metrics
        unanswerable_detected = None
        choice_correct = None

        if sample.conflict_type == ConflictType.UNANSWERABLE:
            unanswerable_detected = response.answer_label == AnswerLabel.UNANSWERABLE

        # Check choice accuracy whenever the sample has multiple-choice options,
        # regardless of declared conflict_type (the local FaithEval JSON does
        # not label conflict_type, so we rely on choices presence instead).
        if sample.choices:
            expected_key = sample.metadata.get("answerKey")
            if expected_key and response.selected_choice:
                choice_correct = (
                    response.selected_choice.strip().upper() == expected_key.strip().upper()
                )
            else:
                choice_correct = False

        # Justification similarity
        just_sim = None
        justification = sample.metadata.get("justification")
        if justification and response.reasoning:
            just_sim = f1_score(response.reasoning, justification)

        result = EvaluationResult(
            sample_id=sample.id,
            prediction=prediction,
            ground_truth=sample.answer,
            ground_truths=all_answers,
            exact_match=em,
            f1=f1,
            accuracy=acc,
            faithfulness=faith,
            conflict_detection_correct=conflict_correct,
            unanswerable_detected=unanswerable_detected,
            choice_correct=choice_correct,
            justification_similarity=just_sim,
            answer_label=response.answer_label.value,
            selected_choice=response.selected_choice,
        )

        self.results.append(result)
        return result

    def get_aggregate_metrics(self) -> dict:
        """Compute aggregate metrics over all evaluated samples.

        Returns ACC, faithfulness, and FaithEval-specific metrics.
        """
        if not self.results:
            return {}

        em_scores = [r.exact_match for r in self.results]
        faith_scores = [r.faithfulness for r in self.results if r.faithfulness is not None]

        metrics: dict = {
            "num_samples": len(self.results),
            "accuracy": sum(em_scores) / len(em_scores),
        }

        if faith_scores:
            metrics["avg_faithfulness"] = sum(faith_scores) / len(faith_scores)

        # FaithEval-specific aggregate metrics
        conflict_scores = [
            r.conflict_detection_correct
            for r in self.results
            if r.conflict_detection_correct is not None
        ]
        if conflict_scores:
            metrics["conflict_detection_accuracy"] = sum(conflict_scores) / len(conflict_scores)

        unanswerable_scores = [
            r.unanswerable_detected for r in self.results if r.unanswerable_detected is not None
        ]
        if unanswerable_scores:
            metrics["unanswerable_detection_rate"] = sum(unanswerable_scores) / len(
                unanswerable_scores
            )

        choice_scores = [r.choice_correct for r in self.results if r.choice_correct is not None]
        if choice_scores:
            metrics["choice_accuracy"] = sum(choice_scores) / len(choice_scores)

        just_scores = [
            r.justification_similarity
            for r in self.results
            if r.justification_similarity is not None
        ]
        if just_scores:
            metrics["avg_justification_similarity"] = sum(just_scores) / len(just_scores)

        return metrics

    def reset(self) -> None:
        """Reset stored results."""
        self.results = []
