"""Structured output models for FaithEval evaluation."""

from enum import Enum

from pydantic import BaseModel, Field


class AnswerLabel(str, Enum):
    """Classification of the conflict type detected by the LLM."""

    CONSISTENT = "consistent"
    INCONSISTENT = "inconsistent"
    UNANSWERABLE = "unanswerable"
    COUNTERFACTUAL = "counterfactual"


class FaithEvalResponse(BaseModel):
    """Structured response from the LLM for FaithEval evaluation.

    Used across all pipelines (baseline, agentic, KG+PPR) to ensure
    consistent structured output for FaithEval benchmarking.
    """

    answer: str = Field(description="The answer text, or 'unanswerable' if info is missing")
    answer_label: AnswerLabel = Field(description="Classification of detected conflict type")
    reasoning: str = Field(description="Chain-of-thought reasoning explaining the classification")
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence score between 0 and 1")
    selected_choice: str | None = Field(
        default=None,
        description="The choice label (A/B/C/D) for counterfactual samples, None otherwise",
    )
    prompt_used: str = Field(default="", description="The prompt text used for this evaluation")
