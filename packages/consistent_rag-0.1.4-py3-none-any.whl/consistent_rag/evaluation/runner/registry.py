"""Pipeline and benchmark registries for evaluation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...approaches.baseline import BaselineNoRAGPipeline, RAGPipeline
from ...benchmarks.faitheval import FaithEvalLoader
from ...benchmarks.financebench import FinanceBenchLoader
from ...benchmarks.musique import MuSiQuELoader
from ...benchmarks.squad import SQuADLoader
from ...benchmarks.timeqa import TimeQALoader
from ...pipeline.pipeline import ConsistentRAGPipeline
from .utils import make_kg_pipeline

if TYPE_CHECKING:
    from ...pipeline.config import PipelineConfig


def _create_approaches(config: "PipelineConfig | None" = None) -> dict:
    """Build the APPROACHES registry, optionally with a pre-built PipelineConfig.

    Args:
        config: Pre-built PipelineConfig from YAML profile. If provided, KG
                pipelines use this config instead of creating a new one.
    """
    approaches = {
        # Single-pass baselines (non-agentic)
        "baseline_no_tool": {
            "factory": BaselineNoRAGPipeline,
            "needs_kg": False,
            "use_vector": False,
            "async": True,
            "faitheval_native": True,
        },
        "baseline_vector": {
            "factory": RAGPipeline,
            "needs_kg": False,
            "use_vector": True,
            "async": False,
        },
        # Agentic baselines (text-only refinement)
        "agentic_vector_only": {
            "factory": ConsistentRAGPipeline,
            "needs_kg": False,
            "use_vector": True,
            "async": True,
        },
        # ConsistentRAG configurations (graph-augmented agentic refinement).
        "agentic_kg_nhops": {
            "factory": lambda cfg=config: make_kg_pipeline("nhops", use_vector=False, config=cfg),
            "needs_kg": True,
            "use_vector": False,
            "async": True,
            "faitheval_native": True,
        },
        "agentic_kg_ppr": {
            "factory": lambda cfg=config: make_kg_pipeline("ppr", use_vector=False, config=cfg),
            "needs_kg": True,
            "use_vector": False,
            "async": True,
            "faitheval_native": True,
        },
        "agentic_kg_random_walk": {
            "factory": lambda cfg=config: make_kg_pipeline(
                "random_walk", use_vector=False, config=cfg
            ),
            "needs_kg": True,
            "use_vector": False,
            "async": True,
            "faitheval_native": True,
        },
        "agentic_kg_hybrid": {
            "factory": lambda cfg=config: make_kg_pipeline("hybrid", use_vector=False, config=cfg),
            "needs_kg": True,
            "use_vector": False,
            "async": True,
            "faitheval_native": True,
        },
    }
    return approaches


# Default registry (no pre-built config)
APPROACHES = _create_approaches()

# Benchmark registry — all dataset variants
BENCHMARKS = {
    "faitheval": FaithEvalLoader,
    "musique_golden": lambda: MuSiQuELoader(variant="golden"),
    "musique_negative": lambda: MuSiQuELoader(variant="negative"),
    "squad_golden": lambda: SQuADLoader(variant="golden"),
    "squad_negative": lambda: SQuADLoader(variant="negative"),
    "timeqa": TimeQALoader,
    "financebench": FinanceBenchLoader,
}
