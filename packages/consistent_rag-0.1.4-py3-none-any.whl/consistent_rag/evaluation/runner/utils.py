"""Generic helper functions for the evaluation runner."""

from __future__ import annotations


def normalize_sample_choices(sample) -> list[str]:
    """Normalize `sample.choices` to a list[str]. Returns [] when absent.

    Handles the dict shape some loaders emit (answerKey -> text) and
    coerces elements to str so the answer agent's prompt template doesn't
    choke on int keys or Enum values.
    """
    raw = getattr(sample, "choices", None) or []
    if isinstance(raw, dict):
        return [str(v) for v in raw.values()]
    return [str(c) for c in raw]


def get_retriever(pipeline):
    """Get the retriever from a pipeline, regardless of type."""
    # New pipeline stores retriever in _components
    if hasattr(pipeline, "_components"):
        return pipeline._components.get("retriever")
    # Fallback for old-style pipelines
    if hasattr(pipeline, "orchestrator"):
        return getattr(pipeline.orchestrator, "retriever", None)
    return getattr(pipeline, "retriever", None)


def collection_has_documents(retriever, collection_name: str) -> bool:
    """Check if a retriever already has indexed documents.

    Works with both Qdrant Retriever (checks collection) and
    FAISSRetriever (checks in-memory index size).
    """
    # FAISSRetriever — check .size property
    if hasattr(retriever, "size"):
        return retriever.size > 0

    # Qdrant Retriever — check collection via client
    try:
        collections = [c.name for c in retriever.client.get_collections().collections]
        if collection_name not in collections:
            return False
        info = retriever.client.get_collection(collection_name)
        return info.points_count > 0
    except Exception:
        return False


def make_kg_pipeline(
    strategy: str,
    use_vector: bool = True,
    collection_name: str = "documents",
    retriever_backend: str = "faiss",
    config=None,
    **graph_kwargs,
):
    """Create a ConsistentRAGPipeline with a specific graph strategy.

    Args:
        strategy: One of "ppr", "nhops", "random_walk", "hybrid"
        use_vector: Whether to enable vector retrieval
        collection_name: Collection/index name for vector retrieval
        retriever_backend: "qdrant" or "faiss"
        config: Pre-built PipelineConfig (overrides all other args if provided)
        **graph_kwargs: Extra PipelineConfig fields (ppr_alpha, nhops_depth,
                        ppr_iterations, max_paths, min_seed_score, etc.)
    """
    from ...config import SubgraphStrategy
    from ...pipeline.config import PipelineConfig
    from ...pipeline.pipeline import ConsistentRAGPipeline
    from ...retrievers import RetrieverConfig

    if config is not None:
        # Use provided config, but override strategy and vector settings
        # Create a copy to avoid mutating the original
        import copy

        config = copy.deepcopy(config)
        strategy_enum = {
            "ppr": SubgraphStrategy.PPR,
            "nhops": SubgraphStrategy.NHOPS,
            "random_walk": SubgraphStrategy.RANDOM_WALK,
            "hybrid": SubgraphStrategy.HYBRID,
        }
        chosen_strategy = strategy_enum.get(strategy.lower()) or SubgraphStrategy.PPR
        config.subgraph_strategy = chosen_strategy.value
        config.use_vector = use_vector
        config.retriever_backend = retriever_backend
        if config.retriever_config is None:
            config.retriever_config = RetrieverConfig(collection_name=collection_name)
        else:
            config.retriever_config.collection_name = collection_name
        # Apply any additional CLI overrides
        for key, value in graph_kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        return ConsistentRAGPipeline(config=config)

    # Legacy path: build config from scratch
    strategy_enum = {
        "ppr": SubgraphStrategy.PPR,
        "nhops": SubgraphStrategy.NHOPS,
        "random_walk": SubgraphStrategy.RANDOM_WALK,
        "hybrid": SubgraphStrategy.HYBRID,
    }

    chosen_strategy = strategy_enum.get(strategy.lower()) or SubgraphStrategy.PPR
    retriever_config = RetrieverConfig(collection_name=collection_name)

    config = PipelineConfig(
        subgraph_strategy=chosen_strategy.value,
        use_vector=use_vector,
        retriever_backend=retriever_backend,
        retriever_config=retriever_config,
        **graph_kwargs,
    )
    return ConsistentRAGPipeline(config=config)
