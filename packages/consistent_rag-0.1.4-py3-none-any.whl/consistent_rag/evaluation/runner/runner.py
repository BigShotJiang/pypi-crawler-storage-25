"""Core evaluation logic: run_approach and run_all."""

from __future__ import annotations

import concurrent.futures
from datetime import datetime
import json
from pathlib import Path
import threading
import time
from typing import Optional

from loguru import logger

from ...benchmarks.faitheval import ConflictType, FaithEvalSample
from ...config import REPORTS_DIR
from ...evaluation.metrics import Evaluator, claim_faithfulness, llm_judge_faithfulness
from ...evaluation.models import AnswerLabel, FaithEvalResponse
from ...experiment_store import ExperimentStore
from ...retrievers import Document
from .csv_writer import BenchmarkCSVWriter, load_completed_samples
from .registry import APPROACHES, BENCHMARKS
from .utils import collection_has_documents, get_retriever, normalize_sample_choices


def _get_approaches_registry(custom_registry=None):
    """Return the approaches registry, optionally using a custom one."""
    return custom_registry if custom_registry is not None else APPROACHES


def run_approach(
    approach_name: str,
    samples: list,
    metrics_type: str = "all",
    verbose: bool = False,
    csv_writer: BenchmarkCSVWriter | None = None,
    benchmark_name: str = "faitheval",
    store: Optional[ExperimentStore] | None = None,
    run_id: str | None = None,
    csv_run_id: str | None = None,
    max_workers: int = 5,
    worker_stagger_ms: int = 100,
    approaches_registry: dict | None = None,
) -> dict:
    """Run evaluation for a single approach.

    Args:
        approach_name: Name of the approach
        samples: Benchmark samples
        metrics_type: "basic", "llm", or "all"
        verbose: Print detailed progress
        benchmark_name: Name of the benchmark being evaluated
        max_workers: Max concurrent samples per approach. Lower this if the
            LLM endpoint returns 429 (rate limit). Default 5.
        worker_stagger_ms: Delay in milliseconds between submitting each
            sample to the thread pool. Spreads out the initial burst of
            LLM calls that all N workers would otherwise fire simultaneously.
            Default 100ms. Set to 0 to disable.
        approaches_registry: Optional custom approaches registry (defaults to global APPROACHES)

    Returns:
        Evaluation results dict
    """
    registry = _get_approaches_registry(approaches_registry)
    approach = registry[approach_name]
    pipeline_factory = approach["factory"]
    needs_kg = approach.get("needs_kg", False)
    samples_are_faitheval = samples and isinstance(samples[0], FaithEvalSample)
    is_faitheval_native = approach.get("faitheval_native", False) and samples_are_faitheval
    approach_uses_vector = approach.get("use_vector", False)

    logger.info(f"Initializing {approach_name} pipeline...")

    # Setup step: only instantiate a pipeline here when we actually need to
    # check or populate a Qdrant collection. FaithEval-native paths bypass
    # vector retrieval entirely and non-vector approaches never touch Qdrant,
    # so creating a pipeline at this point just to close it is dead work.
    indexed_for_vector = False
    if approach_uses_vector and not is_faitheval_native:
        setup_pipeline = pipeline_factory()
        try:
            retriever = get_retriever(setup_pipeline)
            if retriever is not None:
                retriever.config.collection_name = benchmark_name
                if collection_has_documents(retriever, benchmark_name):
                    indexed_for_vector = True
                    logger.info(
                        f"Using existing Qdrant collection '{benchmark_name}' for vector retrieval"
                    )
                elif hasattr(setup_pipeline, "index_documents"):
                    docs = [
                        Document(id=s.id, text=s.context)
                        for s in samples
                        if getattr(s, "context", "")
                    ]
                    if docs:
                        setup_pipeline.index_documents(docs, recreate=False)
                        indexed_for_vector = True
                        logger.info(
                            f"Indexed {len(docs)} sample contexts into "
                            f"collection '{benchmark_name}'"
                        )
        finally:
            if hasattr(setup_pipeline, "close"):
                setup_pipeline.close()
    elif is_faitheval_native:
        logger.info(
            f"FaithEval-native path: skipping vector retrieval for '{approach_name}' "
            f"(KG built on-the-fly from sample.context)"
        )

    results = []
    _results_lock = threading.Lock()

    def process_sample(sample_item: tuple) -> list[dict]:
        i, sample = sample_item
        local_results = []
        if verbose:
            logger.info(f"[{approach_name}] Processing sample {i + 1}/{len(samples)}: {sample.id}")

        # PER-TASK ISOLATION: Initialize an independent pipeline per sample.
        # The pipeline owns its own graph store via `orchestrator.graph_store`,
        # so a fresh pipeline gives us a pristine KG — no standalone
        # `GraphStore()` object is needed here.
        pipeline = pipeline_factory()

        retriever = get_retriever(pipeline)
        if approach_uses_vector and retriever is not None:
            retriever.config.collection_name = benchmark_name

        try:
            # Per-sample KG isolation: rebuild KG from this sample's context.
            kg_only = approach.get("kg_only_context", False)
            if needs_kg and hasattr(pipeline, "build_kg_from_texts"):
                pipeline.build_kg_from_texts([sample.context])

            # Normalize once so the same list flows into every branch and
            # gets recorded on the CSV row for verification.
            sample_choices = normalize_sample_choices(sample)

            # Route to appropriate pipeline method
            faitheval_response = None
            if is_faitheval_native and hasattr(pipeline, "query_from_sample_sync"):
                # BaselineNoRAGPipeline: returns FaithEvalResponse directly
                faitheval_response = pipeline.query_from_sample_sync(sample)
                prediction = faitheval_response.answer
                reasoning = faitheval_response.reasoning
                context = sample.context
                response = faitheval_response
            elif is_faitheval_native and hasattr(pipeline, "query_without_retrieval_sync"):
                # KGPPRAgenticPipeline: pass sample for FaithEval-aware prompts
                response = pipeline.query_without_retrieval_sync(
                    sample.question, sample.context, sample=sample
                )
                prediction = response.answer
                reasoning = getattr(response, "reasoning", "")
                context = sample.context
                # Construct FaithEvalResponse from KGPPRResponse fields
                if getattr(response, "answer_label", None) is not None:
                    faitheval_response = FaithEvalResponse(
                        answer=response.answer,
                        answer_label=AnswerLabel(response.answer_label),
                        reasoning=getattr(response, "reasoning", ""),
                        confidence=getattr(response, "confidence", 0.0),
                        selected_choice=getattr(response, "selected_choice", None),
                        prompt_used=getattr(response, "prompt_used", ""),
                    )
            elif indexed_for_vector and hasattr(pipeline, "query_sync"):
                # Full pipeline with vector retrieval from pre-indexed contexts.
                # Forward sample.choices so MC samples get a choice-aware prompt.
                try:
                    response = pipeline.query_sync(sample.question, choices=sample_choices or None)
                except TypeError:
                    # Back-compat: pipelines that don't yet accept `choices`
                    response = pipeline.query_sync(sample.question)
                prediction = response.answer
                reasoning = getattr(response, "reasoning", "")
                context = sample.context
            elif hasattr(pipeline, "query_without_retrieval_sync"):
                # Agentic pipelines (async) - use sync wrapper with provided context.
                # Forward sample.choices when present so the answer agent emits a
                # choice-aware prompt.
                try:
                    response = pipeline.query_without_retrieval_sync(
                        sample.question, sample.context, choices=sample_choices
                    )
                except TypeError:
                    # Back-compat: pipelines that don't yet accept `choices`
                    response = pipeline.query_without_retrieval_sync(
                        sample.question, sample.context
                    )
                prediction = response.answer
                reasoning = getattr(response, "reasoning", "")
                context = sample.context
            elif hasattr(pipeline, "query_without_retrieval"):
                # Baseline pipelines - use direct method
                use_kg_flag = needs_kg
                response = pipeline.query_without_retrieval(
                    query=sample.question,
                    context="" if kg_only else sample.context,
                    **(
                        {"use_kg": use_kg_flag}
                        if hasattr(pipeline, "query_without_retrieval") and needs_kg
                        else {}
                    ),
                )
                if hasattr(response, "answer"):
                    prediction = response.answer
                else:
                    prediction = response
                reasoning = getattr(response, "reasoning", "")
                context = sample.context
            else:
                # Fallback to retrieval-based query
                if approach["async"]:
                    response = pipeline.query_sync(sample.question)
                else:
                    response = pipeline.query(sample.question)
                prediction = response.answer
                reasoning = getattr(response, "reasoning", "")
                context = response.context if hasattr(response, "context") else sample.context

            # Thread-local evaluator to avoid shared-state races
            local_evaluator = Evaluator(compute_faithfulness=True)
            if faitheval_response and isinstance(faitheval_response, FaithEvalResponse):
                eval_result = local_evaluator.evaluate_faitheval_sample(
                    sample=sample,
                    response=faitheval_response,
                    context=context,
                )
            else:
                eval_result = local_evaluator.evaluate_sample(
                    sample_id=sample.id,
                    prediction=prediction,
                    ground_truth=sample.answer,
                    ground_truths=sample.answers,
                    context=context,
                )

            ppr_paths = getattr(response, "ppr_paths", [])
            seeds_used = getattr(response, "seeds_used", [])
            ppr_entities = getattr(response, "ppr_entities", [])
            triples_extracted = getattr(response, "triples_extracted", 0)
            kg_context = getattr(response, "kg_context", "")

            # Combine reasoning + answer for faithfulness evaluation
            faithfulness_text = (
                f"{reasoning}\n\nFinal Answer: {prediction}" if reasoning else prediction
            )

            # `response.context` reflects whatever formatted context the
            # answer agent actually saw (retrieved docs for the vector path,
            # KG-expanded context for the KG paths). Distinct from the raw
            # sample.context we ingested.
            final_context_full = getattr(response, "context", "") or ""
            final_context_trimmed = (
                final_context_full[:1000] + "..."
                if len(final_context_full) > 1000
                else final_context_full
            )

            result = {
                "sample_id": sample.id,
                "question": sample.question,
                "context": sample.context[:500] + "..."
                if len(sample.context) > 500
                else sample.context,
                "final_context": final_context_trimmed,
                "choices_forwarded": json.dumps(sample_choices) if sample_choices else "",
                "ground_truth": sample.answer,
                "ground_truths": sample.answers,
                "prediction": prediction,
                "reasoning": reasoning,
                "prompt_used": getattr(response, "prompt_used", ""),
                "conflict_type": getattr(sample, "conflict_type", None)
                and sample.conflict_type.value
                or None,
                "answer_label": eval_result.answer_label,
                "selected_choice": eval_result.selected_choice,
                "conflict_detection_correct": eval_result.conflict_detection_correct,
                "justification_similarity": eval_result.justification_similarity,
                "ppr_paths": ppr_paths,
                "ppr_entities": ppr_entities,
                "reasoning_paths": json.dumps(ppr_paths) if ppr_paths else "",
                "seeds_used": json.dumps(seeds_used) if seeds_used else "",
                "triples_extracted": triples_extracted,
                "kg_context": kg_context[:500] + "..." if len(kg_context) > 500 else kg_context,
            }

            pipeline_state = getattr(response, "pipeline_state", None)
            if pipeline_state:
                result["total_duration_ms"] = pipeline_state.total_duration_ms
                result["agent_timings"] = json.dumps(
                    [
                        {"agent": s.agent_name, "ms": round(s.duration_ms, 1)}
                        for s in pipeline_state.steps
                    ]
                )
                result["iteration_traces"] = json.dumps(
                    [
                        {
                            "iter": t.iteration,
                            "seeds": len(t.seeds_used),
                            "seeds_list": t.seeds_used,
                            "triples": t.triples_extracted,
                            "entities": t.entities_in_graph,
                            "edges": t.edges_in_graph,
                            "paths": t.reasoning_paths_found,
                            "path_details": [
                                {
                                    "score": p.get("score", 0),
                                    "steps": [
                                        {
                                            "name": s.get("name", ""),
                                            "type": s.get("type", ""),
                                        }
                                        for s in p.get("steps", [])
                                    ],
                                }
                                for p in t.reasoning_paths[:5]
                            ],
                            "faiss_resolved": t.entities_resolved_by_faiss,
                            "confidence": round(t.answer_confidence, 3),
                            "critic": round(t.critic_score, 3),
                            "satisfactory": t.is_satisfactory,
                            "pruned": t.triples_pruned,
                            "expanded": t.paths_expanded,
                            "refined": t.refinement_applied,
                            "contradictions": t.contradictions_detected,
                            "subgraph_entities": t.subgraph_entity_count,
                            "subgraph_edges": t.subgraph_edge_count,
                            "subgraph_nodes": t.subgraph_nodes[:20],
                            "faiss_size": t.faiss_index_size,
                            "lsh_size": t.lsh_index_size,
                            "edges_reweighted": t.edges_reweighted,
                            "weight_delta": round(t.weight_delta, 4),
                            "error_types": t.error_types,
                            "answer": t.answer_text[:200] if t.answer_text else "",
                            "context": t.context_snapshot[:500] if t.context_snapshot else "",
                        }
                        for t in pipeline_state.iteration_traces
                    ]
                )
            else:
                result["total_duration_ms"] = ""
                result["agent_timings"] = ""
                result["iteration_traces"] = ""

            if hasattr(pipeline, "config") and hasattr(pipeline.config, "subgraph_strategy"):
                result["graph_config"] = json.dumps(
                    {
                        "strategy": pipeline.config.subgraph_strategy.value,
                        "ppr_alpha": pipeline.config.ppr_alpha,
                        "nhops_depth": pipeline.config.nhops_depth,
                        "ppr_iterations": pipeline.config.ppr_iterations,
                        "max_paths": pipeline.config.max_paths,
                        "min_seed_score": pipeline.config.min_seed_score,
                        "use_vector": pipeline.config.use_vector,
                    }
                )
            else:
                result["graph_config"] = ""

            result["exact_match"] = eval_result.exact_match
            result["f1"] = eval_result.f1
            result["accuracy"] = eval_result.accuracy
            result["faithfulness_basic"] = eval_result.faithfulness

            if metrics_type in ("llm", "all", "deepeval"):
                try:
                    llm_score, llm_reason = llm_judge_faithfulness(faithfulness_text, context)
                    result["faithfulness_llm"] = llm_score
                    result["llm_reasoning"] = llm_reason
                except Exception as e:
                    logger.warning(f"LLM faithfulness failed: {e}")
                    result["faithfulness_llm"] = None

            if metrics_type in ("deepeval", "all"):
                try:
                    from ...evaluation.metrics import deepeval_faithfulness

                    result["faithfulness_deepeval"] = deepeval_faithfulness(
                        faithfulness_text, context
                    )
                except Exception as e:
                    logger.warning(f"DeepEval faithfulness failed: {e}")
                    result["faithfulness_deepeval"] = None

            if metrics_type == "all":
                try:
                    result["faithfulness_claim"] = claim_faithfulness(faithfulness_text, context)
                except Exception as e:
                    logger.warning(f"Claim faithfulness failed: {e}")
                    result["faithfulness_claim"] = None

            local_results.append(result)

            if csv_writer:
                csv_writer.write_row(
                    {
                        "run_id": csv_run_id or "",
                        "strategy": approach_name,
                        "benchmark_name": benchmark_name,
                        "timestamp": datetime.now().isoformat(),
                        **result,
                    }
                )

            if store and run_id:
                store.save_result(
                    run_id,
                    {
                        "strategy": approach_name,
                        "benchmark_name": benchmark_name,
                        **result,
                    },
                )

        except Exception as e:
            logger.error(f"Error processing sample {sample.id}: {e}")
            error_result = {
                "sample_id": sample.id,
                "conflict_type": getattr(sample, "conflict_type", None)
                and sample.conflict_type.value
                or None,
                "error": str(e),
            }
            local_results.append(error_result)

            if csv_writer:
                csv_writer.write_row(
                    {
                        "run_id": csv_run_id or "",
                        "strategy": approach_name,
                        "benchmark_name": benchmark_name,
                        "timestamp": datetime.now().isoformat(),
                        **error_result,
                    }
                )

            if store and run_id:
                store.save_result(
                    run_id,
                    {
                        "strategy": approach_name,
                        "benchmark_name": benchmark_name,
                        **error_result,
                    },
                )
        finally:
            if hasattr(pipeline, "close"):
                pipeline.close()

        return local_results

    # Batch-run all samples with bounded concurrency. A stagger delay
    # between submissions spreads the initial burst of LLM calls, which
    # helps avoid 429 rate limits when every worker fires its first
    # extractor/seed/answer call at the same tick.
    stagger_seconds = max(worker_stagger_ms, 0) / 1000.0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(max_workers, 1)) as executor:
        futures = []
        for i, sample in enumerate(samples):
            futures.append(executor.submit(process_sample, (i, sample)))
            if stagger_seconds and i < len(samples) - 1:
                time.sleep(stagger_seconds)
        for future in concurrent.futures.as_completed(futures):
            with _results_lock:
                results.extend(future.result())

    # Rebuild aggregates from collected results (thread-local evaluators
    # were discarded, so we replay the results into a fresh evaluator).
    agg_evaluator = Evaluator(compute_faithfulness=True)
    for r in results:
        if "error" not in r and r.get("prediction") is not None:
            agg_evaluator.evaluate_sample(
                sample_id=r["sample_id"],
                prediction=r["prediction"],
                ground_truth=r.get("ground_truth"),
                ground_truths=r.get("ground_truths"),
                context=r.get("context"),
            )
    aggregate = agg_evaluator.get_aggregate_metrics()

    # Per-conflict-type metrics
    per_type = {}
    for conflict_type in ConflictType:
        type_results = [r for r in results if r.get("conflict_type") == conflict_type.value]
        if type_results:
            type_metrics = {
                "num_samples": len(type_results),
                "accuracy": sum(1 for r in type_results if r.get("exact_match"))
                / len(type_results),
                "avg_f1": sum(r.get("f1", 0) for r in type_results) / len(type_results),
                "avg_faithfulness": sum(r.get("faithfulness_basic", 0) or 0 for r in type_results)
                / len(type_results),
            }

            # FaithEval-specific per-type metrics
            conflict_correct = [
                r["conflict_detection_correct"]
                for r in type_results
                if r.get("conflict_detection_correct") is not None
            ]
            if conflict_correct:
                type_metrics["conflict_detection_accuracy"] = sum(conflict_correct) / len(
                    conflict_correct
                )

            if conflict_type == ConflictType.UNANSWERABLE:
                unanswerable_results = [
                    r for r in type_results if r.get("answer_label") is not None
                ]
                if unanswerable_results:
                    type_metrics["unanswerable_detection_rate"] = sum(
                        1 for r in unanswerable_results if r.get("answer_label") == "unanswerable"
                    ) / len(unanswerable_results)

            just_sims = [
                r["justification_similarity"]
                for r in type_results
                if r.get("justification_similarity") is not None
            ]
            if just_sims:
                type_metrics["avg_justification_similarity"] = sum(just_sims) / len(just_sims)

            per_type[conflict_type.value] = type_metrics

    return {
        "approach": approach_name,
        "config": {
            "samples": len(samples),
            "metrics_type": metrics_type,
        },
        "aggregate_metrics": aggregate,
        "per_type_metrics": per_type,
        "results": results,
    }


def run_all(
    approaches: list[str],
    limit: int | None = None,
    conflict_types: list[ConflictType] | None = None,
    metrics_type: str = "basic",
    output_dir: Path | None = None,
    verbose: bool = False,
    csv_path: Path | None = None,
    resume: bool = False,
    benchmarks: list[str] | None = None,
    postgres_url: str | None = None,
    max_workers: int = 5,
    worker_stagger_ms: int = 100,
    approaches_registry: dict | None = None,
) -> dict:
    """Run evaluation on multiple approaches across one or more benchmarks.

    Args:
        approaches: List of approach names
        limit: Max samples per conflict type
        conflict_types: Conflict types to include (FaithEval only)
        metrics_type: "basic", "llm", or "all"
        output_dir: Directory for reports
        verbose: Print detailed progress
        csv_path: Path for CSV output (auto-generated if None)
        resume: If True, skip samples already in the CSV
        benchmarks: List of benchmark names (default: ["faitheval"])

    Returns:
        Combined results dict
    """
    if benchmarks is None:
        benchmarks = ["faitheval"]

    if output_dir is None:
        output_dir = REPORTS_DIR / "evaluations"
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load completed samples for resume
    completed = set()
    if resume and csv_path:
        completed = load_completed_samples(Path(csv_path))
        logger.info(f"Resume mode: found {len(completed)} completed entries in {csv_path}")

    # Determine CSV path and run ID
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_run_id = f"run_{timestamp}"  # Always set for CSV traceability
    if csv_path is None:
        benchmark_label = "_".join(benchmarks) if len(benchmarks) <= 3 else "multi"
        csv_path = output_dir / f"benchmark_{benchmark_label}_{timestamp}.csv"

    store = None
    run_id = None
    if postgres_url and ExperimentStore is not None:
        try:
            store = ExperimentStore(postgres_url)
            run_id = store.create_run(
                name=f"eval_{timestamp}",
                strategy=",".join(approaches),
                config={
                    "limit": limit,
                    "metrics_type": metrics_type,
                    "benchmarks": benchmarks,
                    "approaches": approaches,
                },
            )
            logger.info(f"Experiment run ID: {run_id}")
        except Exception as exc:
            logger.warning(
                f"Failed to initialise ExperimentStore, continuing without persistence: {exc}"
            )
            store = None
            run_id = None
    elif postgres_url and ExperimentStore is None:
        logger.warning(
            "postgres_url provided but psycopg is not installed; skipping DB persistence"
        )

    all_results = {}
    try:
        with BenchmarkCSVWriter(Path(csv_path)) as csv_writer:
            for benchmark_name in benchmarks:
                if benchmark_name not in BENCHMARKS:
                    logger.warning(f"Unknown benchmark: {benchmark_name}")
                    continue

                # Load benchmark samples
                logger.info(f"Loading {benchmark_name} benchmark...")
                loader = BENCHMARKS[benchmark_name]()
                if benchmark_name == "faitheval" and conflict_types:
                    samples = loader.load(conflict_types=conflict_types, limit=limit)
                else:
                    samples = loader.load(limit=limit)
                logger.info(f"Loaded {len(samples)} samples from {benchmark_name}")

                samples_are_faitheval = samples and isinstance(samples[0], FaithEvalSample)

                # Run each approach against this benchmark
                registry = _get_approaches_registry(approaches_registry)
                for approach_name in approaches:
                    if approach_name not in registry:
                        logger.warning(f"Unknown approach: {approach_name}")
                        continue

                    # Filter samples for resume
                    if resume and completed:
                        approach_samples = [
                            s for s in samples if (approach_name, s.id) not in completed
                        ]
                        total = len(samples)
                        already_done = total - len(approach_samples)
                        remaining = len(approach_samples)
                        logger.info(f"\n{'=' * 60}")
                        logger.info(f"Benchmark: {benchmark_name} | Strategy: {approach_name}")
                        logger.info(f"Total samples requested: {total}")
                        logger.info(f"Already completed: {already_done}")
                        logger.info(f"Remaining to evaluate: {remaining}")
                        if samples_are_faitheval:
                            for ct in ConflictType:
                                ct_total = sum(1 for s in samples if s.conflict_type == ct)
                                ct_done = sum(
                                    1
                                    for s in samples
                                    if s.conflict_type == ct and (approach_name, s.id) in completed
                                )
                                logger.info(f"  {ct.value}: {ct_done}/{ct_total} done")
                        logger.info("=" * 60)

                        if not approach_samples:
                            logger.info(
                                f"All samples already complete for {approach_name} on {benchmark_name}, skipping."
                            )
                            continue
                    else:
                        approach_samples = samples

                    logger.info(
                        f"\n{'=' * 60}\nRunning {approach_name} on {benchmark_name}\n{'=' * 60}"
                    )
                    result = run_approach(
                        approach_name,
                        approach_samples,
                        metrics_type,
                        verbose,
                        csv_writer=csv_writer,
                        benchmark_name=benchmark_name,
                        store=store,
                        run_id=run_id,
                        csv_run_id=csv_run_id,
                        max_workers=max_workers,
                        worker_stagger_ms=worker_stagger_ms,
                    )
                    result_key = f"{approach_name}/{benchmark_name}"
                    all_results[result_key] = result

                    # Save individual JSON report
                    report_path = output_dir / f"{approach_name}_{benchmark_name}_{timestamp}.json"
                    with open(report_path, "w", encoding="utf-8") as f:
                        json.dump(result, f, indent=2)
                    logger.info(f"Saved report: {report_path}")

        logger.info(f"CSV results saved to: {csv_path}")

        # Save comparison report
        if len(all_results) > 1:
            comparison = {
                "timestamp": datetime.now().isoformat(),
                "config": {
                    "approaches": approaches,
                    "benchmarks": benchmarks,
                    "metrics_type": metrics_type,
                },
                "comparison": {
                    name: result["aggregate_metrics"] for name, result in all_results.items()
                },
            }
            comparison_path = output_dir / f"comparison_{timestamp}.json"
            with open(comparison_path, "w", encoding="utf-8") as f:
                json.dump(comparison, f, indent=2)
            logger.info(f"Saved comparison: {comparison_path}")

        if store and run_id:
            store.update_run_status(run_id, "completed")
    finally:
        if store:
            store.close()

    return all_results
