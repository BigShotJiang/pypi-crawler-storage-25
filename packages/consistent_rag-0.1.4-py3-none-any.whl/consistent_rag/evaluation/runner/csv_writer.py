"""Incremental CSV writer and resume helpers."""

from __future__ import annotations

import csv
import os
from pathlib import Path
import threading

CSV_COLUMNS = [
    "run_id",
    "strategy",
    "benchmark_name",
    "conflict_type",
    "sample_id",
    "question",
    "ground_truth",
    "prediction",
    "reasoning",
    "answer_label",
    "selected_choice",
    "choices_forwarded",
    "final_context",
    "conflict_detection_correct",
    "justification_similarity",
    "exact_match",
    "f1",
    "accuracy",
    "faithfulness_basic",
    "faithfulness_llm",
    "faithfulness_deepeval",
    "faithfulness_claim",
    "reasoning_paths",
    "triples_extracted",
    "seeds_used",
    "total_duration_ms",
    "agent_timings",
    "iteration_traces",
    "graph_config",
    "timestamp",
    "error",
]


class BenchmarkCSVWriter:
    """Incremental CSV writer that appends one row at a time and flushes immediately."""

    def __init__(self, path: Path, fieldnames: list[str] | None = None):
        if fieldnames is None:
            fieldnames = CSV_COLUMNS
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        needs_header = not self.path.exists() or os.path.getsize(self.path) == 0
        self._file = open(self.path, "a", newline="", encoding="utf-8")
        self._writer = csv.DictWriter(self._file, fieldnames=fieldnames, extrasaction="ignore")
        self._lock = threading.Lock()
        if needs_header:
            self._writer.writeheader()
            self._file.flush()

    def write_row(self, row: dict) -> None:
        with self._lock:
            self._writer.writerow(row)
            self._file.flush()

    def close(self) -> None:
        self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


def load_completed_samples(csv_path: Path) -> set[tuple[str, str]]:
    """Load completed (strategy, sample_id) pairs from an existing CSV."""
    completed = set()
    if not csv_path.exists():
        return completed
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("prediction") or row.get("error"):
                completed.add((row["strategy"], row["sample_id"]))
    return completed
