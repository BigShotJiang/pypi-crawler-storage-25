"""Command-line interface for the evaluation runner."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from ...config_loader import ConfigLoader
from ...pipeline.config import PipelineConfig
from ...pipeline.pipeline import ConsistentRAGPipeline
from .registry import BENCHMARKS, _create_approaches
from .runner import run_all
from .utils import make_kg_pipeline


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser for evaluate_all."""
    parser = argparse.ArgumentParser(
        description="Run ConsistentRAG evaluation across pipeline configurations and benchmarks"
    )
    parser.add_argument(
        "--profile",
        type=str,
        default="benchmark",
        choices=["benchmark", "dev", "production"],
        help="Config profile: benchmark (default), dev, or production",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="LLM model name (overrides config profile)",
    )
    parser.add_argument(
        "--approaches",
        type=str,
        default="all",
        help=(
            f"Comma-separated config names or 'all'. Available: {', '.join(sorted(_create_approaches().keys()))}"
        ),
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=5,
        help="Max samples per conflict type / benchmark",
    )
    parser.add_argument(
        "--metrics",
        type=str,
        choices=["basic", "llm", "deepeval", "all"],
        default="basic",
        help="Metrics to compute (basic, llm, deepeval, or all)",
    )
    parser.add_argument(
        "--benchmark",
        type=str,
        default="faitheval",
        help=(
            f"Comma-separated benchmark names or 'all'. Available: {', '.join(BENCHMARKS.keys())}"
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print detailed progress",
    )
    parser.add_argument(
        "--csv",
        type=str,
        default=None,
        help="Path for CSV output file (auto-generated if omitted)",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from existing CSV, skipping already-completed samples (requires --csv)",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable triplet cache — re-extract all seeds/triples via LLM",
    )
    parser.add_argument(
        "--ppr-alpha",
        type=float,
        default=None,
        help="PPR damping factor (default: 0.5)",
    )
    parser.add_argument(
        "--nhops-depth",
        type=int,
        default=None,
        help="BFS depth for n-hops strategy (default: 2)",
    )
    parser.add_argument(
        "--ppr-iterations",
        type=int,
        default=None,
        help="Number of PPR power iterations (default: 20)",
    )
    parser.add_argument(
        "--max-paths",
        type=int,
        default=None,
        help="Maximum reasoning paths to include (default: 5)",
    )
    parser.add_argument(
        "--min-seed-score",
        type=float,
        default=None,
        help="Minimum score for seed selection (default: 0.3)",
    )
    parser.add_argument(
        "--no-vector",
        action="store_true",
        help="Run KG-only mode — skip vector retrieval (sets use_vector=False)",
    )
    parser.add_argument(
        "--retriever-backend",
        type=str,
        choices=["qdrant", "faiss"],
        default="faiss",
        help="Vector retriever backend: 'qdrant' (requires server) or 'faiss' (local, no server)",
    )
    parser.add_argument(
        "--postgres",
        type=str,
        default=None,
        help="PostgreSQL URL for experiment persistence (e.g. postgresql://user:pass@localhost:5432/db)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        help=(
            "Max concurrent samples per approach (default: 5). Lower this if "
            "the LLM endpoint returns 429 rate-limit errors; raise it if "
            "your endpoint has headroom."
        ),
    )
    parser.add_argument(
        "--worker-stagger-ms",
        type=int,
        default=100,
        help=(
            "Delay in milliseconds between submitting each sample to the "
            "thread pool (default: 100). Spreads out the burst of LLM calls "
            "that N workers would otherwise fire at the same tick. "
            "Set to 0 to disable."
        ),
    )
    return parser


def _apply_graph_overrides(
    approaches_registry: dict,
    approaches: list[str],
    graph_kwargs: dict,
    use_vector: bool = True,
    retriever_backend: str = "faiss",
) -> None:
    """Override KG pipeline factories in the registry with custom hyperparameters."""
    for name in approaches:
        if name not in approaches_registry:
            continue
        entry = approaches_registry[name]

        # agentic_vector_only — apply retriever_backend
        if name == "agentic_vector_only" and retriever_backend != "qdrant":
            entry["factory"] = lambda rb=retriever_backend: ConsistentRAGPipeline(
                PipelineConfig(use_vector=True, retriever_backend=rb)
            )
            continue

        # KG agentic pipelines — apply graph kwargs + retriever backend
        if not entry.get("needs_kg", False) or not name.startswith("agentic_kg_"):
            continue
        strategy = name.replace("agentic_kg_", "")
        entry["factory"] = (
            lambda s=strategy, uv=use_vector, rb=retriever_backend, gk=graph_kwargs: (
                make_kg_pipeline(s, use_vector=uv, retriever_backend=rb, **gk)
            )
        )
        entry["use_vector"] = use_vector


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.resume and not args.csv:
        parser.error("--resume requires --csv <path> to specify the results file to resume from")

    postgres_url = args.postgres or os.environ.get("POSTGRES_URL")

    # Load pipeline config from YAML profile
    loader = ConfigLoader(profile=args.profile)
    pipeline_config = loader.load_pipeline()

    # CLI overrides take precedence over YAML
    if args.model is not None:
        pipeline_config.model = args.model
    if args.ppr_alpha is not None:
        pipeline_config.ppr_alpha = args.ppr_alpha
    if args.nhops_depth is not None:
        pipeline_config.nhops_depth = args.nhops_depth
    if args.ppr_iterations is not None:
        pipeline_config.ppr_iterations = args.ppr_iterations
    if args.max_paths is not None:
        pipeline_config.max_paths = args.max_paths
    if args.min_seed_score is not None:
        pipeline_config.min_seed_score = args.min_seed_score
    if args.no_vector:
        pipeline_config.use_vector = False
    if args.retriever_backend:
        pipeline_config.retriever_backend = args.retriever_backend

    if args.verbose:
        print(f"Using config profile: {args.profile}")
        print(f"Model: {pipeline_config.model}")
        print(f"Strategy: {pipeline_config.subgraph_strategy}")

    # Create approaches registry with loaded config
    approaches_registry = _create_approaches(pipeline_config)

    if args.approaches == "all":
        approaches = list(approaches_registry.keys())
    else:
        approaches = [a.strip() for a in args.approaches.split(",")]

    if args.benchmark == "all":
        benchmarks = list(BENCHMARKS.keys())
    else:
        benchmarks = [b.strip() for b in args.benchmark.split(",")]

    # Collect graph hyperparameter overrides
    graph_kwargs = {}
    if args.ppr_alpha is not None:
        graph_kwargs["ppr_alpha"] = args.ppr_alpha
    if args.nhops_depth is not None:
        graph_kwargs["nhops_depth"] = args.nhops_depth
    if args.ppr_iterations is not None:
        graph_kwargs["ppr_iterations"] = args.ppr_iterations
    if args.max_paths is not None:
        graph_kwargs["max_paths"] = args.max_paths
    if args.min_seed_score is not None:
        graph_kwargs["min_seed_score"] = args.min_seed_score

    # Apply overrides to KG pipeline factories
    use_vector = not args.no_vector
    retriever_backend = args.retriever_backend
    if graph_kwargs or not use_vector or retriever_backend != "qdrant":
        _apply_graph_overrides(
            approaches_registry, approaches, graph_kwargs, use_vector, retriever_backend
        )

    results = run_all(
        approaches=approaches,
        limit=args.limit,
        metrics_type=args.metrics,
        verbose=args.verbose,
        csv_path=Path(args.csv) if args.csv else None,
        resume=args.resume,
        benchmarks=benchmarks,
        postgres_url=postgres_url,
        max_workers=args.workers,
        worker_stagger_ms=args.worker_stagger_ms,
        approaches_registry=approaches_registry,
    )

    # Print summary
    print("\n" + "=" * 72)
    print("SUMMARY")
    print("=" * 72)
    for name, result in results.items():
        metrics = result.get("aggregate_metrics", {})
        acc = metrics.get("accuracy", 0)
        faith = metrics.get("avg_faithfulness", 0)
        conflict_det = metrics.get("conflict_detection_accuracy")
        unans_rate = metrics.get("unanswerable_detection_rate")
        choice_acc = metrics.get("choice_accuracy")
        just_sim = metrics.get("avg_justification_similarity")

        parts = [f"ACC={acc:.1%}", f"Faith={faith:.3f}"]
        if conflict_det is not None:
            parts.append(f"ConflictDet={conflict_det:.1%}")
        if unans_rate is not None:
            parts.append(f"UnansRate={unans_rate:.1%}")
        if choice_acc is not None:
            parts.append(f"ChoiceAcc={choice_acc:.1%}")
        if just_sim is not None:
            parts.append(f"JustSim={just_sim:.3f}")
        print(f"  {name}: {' | '.join(parts)}")


if __name__ == "__main__":
    import warnings

    # Suppress httpx async cleanup noise when event loop closes
    warnings.filterwarnings("ignore", message=".*Event loop is closed.*")
    import logging

    logging.getLogger("asyncio").setLevel(logging.CRITICAL)
    main()
