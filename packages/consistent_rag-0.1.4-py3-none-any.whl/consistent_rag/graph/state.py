"""Graph state definitions."""

from dataclasses import dataclass, field
from typing import Any

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.pipeline.context_models import StructuredContext
from consistent_rag.pipeline.models import PipelineIterationState


@dataclass
class PipelineGraphState:
    """Mutable state threaded through all graph nodes."""

    iteration_state: PipelineIterationState
    metrics: MetricsCollector
    pruned_entities: set[str] = field(default_factory=set)
    improvement_history: list[Any] = field(default_factory=list)
    context: StructuredContext = field(default_factory=StructuredContext)
    subgraph_snapshots: list[dict] = field(default_factory=list)
    reasoning_paths_history: list[list[dict]] = field(default_factory=list)
    previous_state: "PipelineGraphState | None" = None
