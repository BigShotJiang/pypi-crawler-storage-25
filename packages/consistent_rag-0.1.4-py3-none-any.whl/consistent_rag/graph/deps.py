"""Graph dependencies definitions."""

from dataclasses import dataclass
from typing import Any

from consistent_rag.knowledge_graph.lsh_index import CosineLSH
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.steps.answer import AnswerGenerationStep
from consistent_rag.steps.critic import CriticStep
from consistent_rag.steps.ranking import SubgraphRankingStep
from consistent_rag.steps.refinement import CriticGuidedRefinementStep
from consistent_rag.steps.retrieval import RetrievalStep
from consistent_rag.steps.seed import SeedExtractionStep
from consistent_rag.steps.triple import TripleExtractionStep


@dataclass
class PipelineDeps:
    """Injected dependencies for the pipeline graph."""

    config: PipelineConfig
    retrieval_step: RetrievalStep
    triple_step: TripleExtractionStep
    seed_step: SeedExtractionStep
    ranking_step: SubgraphRankingStep
    answer_step: AnswerGenerationStep
    critic_step: CriticStep
    refinement_step: CriticGuidedRefinementStep
    graph_store: Any
    lsh_index: CosineLSH | None = None
