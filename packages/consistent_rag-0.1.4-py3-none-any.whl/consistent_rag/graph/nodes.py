"""pydantic-graph FSM nodes for the C-GAPUD pipeline.

Each node maps to a step in the ConsistentRAG improvement loop.
Transitions are encoded via return type annotations, making the
pipeline a typed finite state machine.

This implements C-GAPUD (Critic-Guided Adaptive Path Utility Diffusion):
- Structured critic feedback with error types
- Path-aware edge re-weighting
- Budgeted diverse seed evolution
- Session-level relation fusion
- Convergence checking
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterator

from loguru import logger
from pydantic_graph import BaseNode, End, Graph, GraphRunContext

from consistent_rag.agents.critic.agent import StructuredCriticFeedback
from consistent_rag.agents.state import IterationTrace
from consistent_rag.graph.deps import PipelineDeps
from consistent_rag.graph.state import PipelineGraphState
from consistent_rag.pipeline.context_models import StructuredContext
from consistent_rag.pipeline.models import PipelineResponse

# Optional numpy import — used for LSH index population only.
try:
    import numpy as np
except ImportError:
    np = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _extract_triples_from_paths(paths: list[dict]) -> Iterator[tuple[str, str, str, float]]:
    """Yield (source, relation, target, score) from reasoning path dicts.

    Paths alternate: entity → relation → entity → relation → entity.
    We extract entity-relation-entity triples from every 3-step window.
    """
    for path in paths:
        steps = path.get("steps", [])
        score = path.get("score", 0.0)
        for i in range(len(steps) - 2):
            if (
                steps[i].get("type") == "entity"
                and steps[i + 1].get("type") == "relation"
                and steps[i + 2].get("type") == "entity"
            ):
                yield (steps[i]["name"], steps[i + 1]["name"], steps[i + 2]["name"], score)


def _populate_lsh_index(graph_store: Any) -> int:
    """Populate the LSH index on *graph_store* with edge embeddings.

    Returns the number of triples successfully inserted.
    """
    if np is None:
        return 0

    lsh_index = getattr(graph_store, "_lsh_index", None)
    if lsh_index is None:
        return 0

    count = 0
    for u, v, data in graph_store.graph.edges(data=True):
        emb = data.get("embedding")
        if emb is None:
            continue
        triple_id = f"{u}|{data.get('type', 'RELATED')}|{v}"
        try:
            lsh_index.insert(triple_id, np.array(emb, dtype=np.float32))
            count += 1
        except Exception:
            pass
    return count


def _has_actionable_signal(feedback: Any) -> bool:
    """Return True if *feedback* carries actionable refinement signals.

    Handles both ``CriticFeedback`` and ``StructuredCriticFeedback``
    transparently so callers do not need ``getattr`` chains.
    """
    if feedback is None:
        return False

    # Common checks that exist on both feedback types
    if bool(getattr(feedback, "improvement_suggestions", None)):
        return True
    if bool(getattr(feedback, "conflicting_claims", None)):
        return True

    # CriticFeedback specific fields
    if getattr(feedback, "has_contradictions", False):
        return True
    if getattr(feedback, "missing_information", False):
        return True

    # StructuredCriticFeedback specific fields
    if isinstance(feedback, StructuredCriticFeedback) and bool(feedback.error_types):
        return True

    return False


def _increment_contradictions_if_any(feedback: Any, metrics: Any) -> None:
    """Increment contradiction counter when feedback signals contradictions."""
    if getattr(feedback, "has_contradictions", False):
        metrics.increment_contradictions()


def _get_index_sizes(graph_store: Any) -> tuple[int, int]:
    """Return (faiss_index_size, lsh_index_size) for the given graph store."""
    faiss_size = 0
    if hasattr(graph_store, "_faiss_index") and graph_store._faiss_index is not None:
        faiss_size = getattr(graph_store._faiss_index, "ntotal", 0)

    lsh_size = 0
    if hasattr(graph_store, "_lsh_index") and graph_store._lsh_index is not None:
        stats = graph_store._lsh_index.get_stats()
        lsh_size = stats.get("num_triples", 0)

    return faiss_size, lsh_size


# ---------------------------------------------------------------------------
# Graph nodes
# ---------------------------------------------------------------------------


@dataclass
class ExtractTriples(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Extract triples from retrieved documents and build KG."""

    async def run(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> ExtractSeeds:
        state = ctx.state.iteration_state
        if ctx.deps.config.build_kg_incrementally and state.formatted_context:
            texts = [state.formatted_context]
            if state.retrieved_docs:
                texts = [doc.text for doc in state.retrieved_docs]
            await ctx.deps.triple_step.execute(state, ctx.state.metrics, texts)

            count = _populate_lsh_index(ctx.deps.graph_store)
            if count:
                logger.info(f"Populated LSH index with {count} triples from extraction")

        return ExtractSeeds()


@dataclass
class ExtractSeeds(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Extract seed entities from the query."""

    async def run(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> RankSubgraph:
        await ctx.deps.seed_step.execute(ctx.state.iteration_state, ctx.state.metrics)
        return RankSubgraph()


@dataclass
class RankSubgraph(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Rank subgraph entities using the configured strategy."""

    async def run(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> GenerateAnswer:
        await ctx.deps.ranking_step.execute(ctx.state.iteration_state, ctx.state.metrics)
        self._log_ranking_state(ctx)

        ctx.state.context = StructuredContext.from_state(
            ctx.state.iteration_state, max_paths=ctx.deps.config.max_paths
        )
        ctx.state.iteration_state.combined_context = ctx.state.context.render()
        self._log_context_state(ctx)

        self._capture_subgraph_snapshot(ctx)
        self._capture_reasoning_paths(ctx)

        return GenerateAnswer()

    # ------------------------------------------------------------------
    # Logging helpers
    # ------------------------------------------------------------------
    def _log_ranking_state(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> None:
        ppr = ctx.state.iteration_state.ppr_result
        if ppr:
            logger.info(
                f"[RankSubgraph] {len(ppr.ranked_entities)} entities, "
                f"{len(ppr.relevant_paths)} paths"
            )
        else:
            logger.warning("[RankSubgraph] ppr_result is None after ranking!")

    def _log_context_state(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> None:
        ctx_state = ctx.state.iteration_state.combined_context
        has_paths = "Reasoning paths:" in ctx_state
        logger.info(f"[RankSubgraph] context has paths: {has_paths}, length: {len(ctx_state)}")

    # ------------------------------------------------------------------
    # Snapshot helpers
    # ------------------------------------------------------------------
    def _capture_subgraph_snapshot(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> None:
        graph_store = ctx.deps.graph_store
        snapshot = {
            "iteration": ctx.state.iteration_state.iteration,
            "nodes": list(graph_store.graph.nodes()),
            "edges": [
                {"source": u, "target": v, "weight": data.get("confidence", 0.5)}
                for u, v, data in graph_store.graph.edges(data=True)
            ],
            "seeds": (
                ctx.state.iteration_state.seeds.seeds if ctx.state.iteration_state.seeds else []
            ),
        }
        ctx.state.subgraph_snapshots.append(snapshot)

    def _capture_reasoning_paths(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> None:
        ppr = ctx.state.iteration_state.ppr_result
        if ppr:
            ctx.state.reasoning_paths_history.append(ppr.relevant_paths)


@dataclass
class GenerateAnswer(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Generate an answer using the current context."""

    async def run(self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]) -> Critique:
        self._log_context_before_render(ctx)

        ctx.state.iteration_state.combined_context = ctx.state.context.render()

        self._log_context_after_render(ctx)

        _, prompt_used = await ctx.deps.answer_step.execute(
            ctx.state.iteration_state, ctx.state.metrics
        )
        ctx.state.iteration_state._last_prompt_used = prompt_used  # type: ignore[attr-defined]
        return Critique()

    def _log_context_before_render(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> None:
        logger.info(
            "[GenerateAnswer] context reasoning_paths before render: "
            f"{len(ctx.state.context.reasoning_paths)}"
        )

    def _log_context_after_render(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> None:
        has_paths = "Reasoning paths:" in ctx.state.iteration_state.combined_context
        logger.info(f"[GenerateAnswer] combined_context has reasoning paths: {has_paths}")


@dataclass
class Critique(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Critique the answer and decide: refine or finish."""

    async def run(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> RefineContext | End[PipelineResponse]:
        state = ctx.state.iteration_state
        feedback = await ctx.deps.critic_step.execute(
            state, ctx.state.metrics, answer_result=state.answer
        )
        ctx.state.improvement_history.append(feedback)

        _increment_contradictions_if_any(feedback, ctx.state.metrics)

        trace = _build_iteration_trace(ctx)
        ctx.state.metrics.record_iteration(trace)

        logger.info(
            f"Critic score: {feedback.score:.2f}, satisfactory: {feedback.is_satisfactory}"
        )

        max_iters = ctx.deps.config.max_improvement_iterations
        if feedback.is_satisfactory or state.iteration >= max_iters - 1:
            ctx.state.metrics.set_iterations(state.iteration + 1)
            response = _build_response(ctx)
            return End(response)

        if not _has_actionable_signal(feedback):
            logger.info(
                f"Critic unsatisfied (score={feedback.score:.2f}) with no "
                "actionable signal — ending refinement loop."
            )
            ctx.state.metrics.set_iterations(state.iteration + 1)
            response = _build_response(ctx)
            return End(response)

        return RefineContext()


@dataclass
class RefineContext(BaseNode[PipelineGraphState, PipelineDeps, PipelineResponse]):
    """Refine context using C-GAPUD."""

    async def run(
        self, ctx: GraphRunContext[PipelineGraphState, PipelineDeps]
    ) -> RankSubgraph | GenerateAnswer:
        state = ctx.state.iteration_state
        feedback = state.critic_feedback

        if feedback is None:
            state.iteration += 1
            return GenerateAnswer()

        # Ensure graph reference is available for refinement
        state.graph = ctx.deps.graph_store.graph

        # Save previous state for convergence checking
        ctx.state.previous_state = PipelineGraphState(
            iteration_state=state.model_copy(),
            metrics=ctx.state.metrics,
        )

        # Track edge weights before refinement
        edges_before = {
            (u, v): data.get("confidence", 0.5)
            for u, v, data in ctx.deps.graph_store.graph.edges(data=True)
        }

        # Execute C-GAPUD refinement
        ctx.state.pruned_entities = await ctx.deps.refinement_step.execute(
            state, ctx.state.metrics, ctx.state.pruned_entities
        )

        # Calculate how many edges were reweighted
        edges_reweighted = 0
        total_weight_delta = 0.0
        for u, v, data in ctx.deps.graph_store.graph.edges(data=True):
            before = edges_before.get((u, v), 0.5)
            after = data.get("confidence", 0.5)
            if abs(after - before) > 0.001:
                edges_reweighted += 1
                total_weight_delta += abs(after - before)

        # Update the last iteration trace with refinement stats
        if ctx.state.metrics.state.iteration_traces:
            last_trace = ctx.state.metrics.state.iteration_traces[-1]
            last_trace.edges_reweighted = edges_reweighted
            last_trace.weight_delta = (
                total_weight_delta / edges_reweighted if edges_reweighted > 0 else 0.0
            )
            last_trace.refinement_applied = True

        # Check convergence
        if state.converged:
            logger.info(f"Converged after {state.iteration + 1} iterations")
            ctx.state.metrics.set_iterations(state.iteration + 1)
            response = _build_response(ctx)
            return End(response)

        state.iteration += 1
        return RankSubgraph()


def build_pipeline_graph() -> Graph[PipelineGraphState, PipelineDeps, PipelineResponse]:
    """Construct the C-GAPUD pipeline graph."""
    return Graph(
        nodes=(
            ExtractTriples,
            ExtractSeeds,
            RankSubgraph,
            GenerateAnswer,
            Critique,
            RefineContext,
        ),
    )


# ---------------------------------------------------------------------------
# Trace / response builders
# ---------------------------------------------------------------------------


def _build_iteration_trace(
    ctx: GraphRunContext[PipelineGraphState, PipelineDeps],
) -> IterationTrace:
    """Build an IterationTrace from current graph state."""
    state = ctx.state.iteration_state
    graph_store = ctx.deps.graph_store

    paths = state.ppr_result.relevant_paths if state.ppr_result else []
    unused_triples = _collect_unused_triples(graph_store.graph, paths)

    # Extract subgraph nodes/edges from reasoning paths using shared helper
    subgraph_nodes: set[str] = set()
    seen_edges: set[tuple[str, str, str]] = set()
    subgraph_edges: list[dict[str, Any]] = []
    for src, rel, dst, score in _extract_triples_from_paths(paths):
        subgraph_nodes.add(src)
        subgraph_nodes.add(dst)
        edge_key = (src, rel, dst)
        if edge_key not in seen_edges:
            seen_edges.add(edge_key)
            subgraph_edges.append({"source": src, "target": dst, "relation": rel, "score": score})

    # Also add any dangling final entity from each path
    for path in paths:
        steps = path.get("steps", [])
        if steps and steps[-1].get("type") == "entity":
            subgraph_nodes.add(steps[-1]["name"])

    logger.info(
        f"ITERATION {state.iteration} TRACE: "
        f"subgraph={len(subgraph_nodes)} nodes, "
        f"{len(subgraph_edges)} edges, paths={len(paths)}"
    )

    faiss_size, lsh_size = _get_index_sizes(graph_store)

    return IterationTrace(
        iteration=state.iteration,
        query=state.query,
        seeds_used=state.seeds.seeds if state.seeds else [],
        triples_extracted=len(state.extracted_triples),
        entities_in_graph=graph_store.graph.number_of_nodes(),
        edges_in_graph=graph_store.graph.number_of_edges(),
        reasoning_paths_found=len(paths),
        reasoning_paths=paths,
        unused_triples=unused_triples,
        subgraph_nodes=list(subgraph_nodes),
        subgraph_edges=subgraph_edges,
        answer_confidence=state.answer.confidence if state.answer else 0.0,
        answer_text=state.answer.answer if state.answer else "",
        critic_score=state.critic_feedback.score if state.critic_feedback else 0.0,
        is_satisfactory=(
            state.critic_feedback.is_satisfactory if state.critic_feedback else False
        ),
        contradictions_detected=(
            len(state.critic_feedback.conflicting_claims)
            if state.critic_feedback and hasattr(state.critic_feedback, "conflicting_claims")
            else 0
        ),
        entities_resolved_by_faiss=getattr(graph_store, "_last_resolution_count", 0),
        context_snapshot=state.combined_context,
        error_types=[e.value for e in state.critic_feedback.error_types]
        if state.critic_feedback and hasattr(state.critic_feedback, "error_types")
        else [],
        faiss_index_size=faiss_size,
        lsh_index_size=lsh_size,
        subgraph_entity_count=len(subgraph_nodes),
        subgraph_edge_count=len(subgraph_edges),
    )


def _collect_unused_triples(graph, used_paths: list[dict]) -> list[dict]:
    """Collect triples that were not used in any reasoning path."""
    used_edges: set[tuple[str, str, str]] = set()
    for src, rel, dst, _ in _extract_triples_from_paths(used_paths):
        used_edges.add((src, rel, dst))
        used_edges.add((dst, rel, src))  # Bidirectional matching

    unused = []
    for u, v, data in graph.edges(data=True):
        rel = data.get("type", data.get("relation", "RELATED"))
        if (u, rel, v) not in used_edges and (v, rel, u) not in used_edges:
            unused.append(
                {
                    "subject": u,
                    "predicate": rel,
                    "object": v,
                    "confidence": data.get("confidence", 0.0),
                }
            )

    unused.sort(key=lambda x: x["confidence"], reverse=True)
    return unused[:50]


def _build_response(
    ctx: GraphRunContext[PipelineGraphState, PipelineDeps],
) -> PipelineResponse:
    """Build final PipelineResponse from graph state."""
    state = ctx.state.iteration_state
    prompt_used = getattr(state, "_last_prompt_used", "")

    unresolved_issues: list[str] = []
    if state.critic_feedback and not state.critic_feedback.is_satisfactory:
        unresolved_issues.append(
            f"Final answer unsatisfactory (score: {state.critic_feedback.score:.2f}): "
            f"{state.critic_feedback.guidance}"
        )

    all_unused = []
    for trace in ctx.state.metrics.state.iteration_traces:
        all_unused.extend(trace.unused_triples)

    seen: set[tuple[str, str, str]] = set()
    unique_unused = []
    for t in all_unused:
        key = (t["subject"], t["predicate"], t["object"])
        if key not in seen:
            seen.add(key)
            unique_unused.append(t)

    return PipelineResponse(
        query=state.query,
        answer=state.answer.answer if state.answer else "",
        reasoning=state.answer.reasoning if state.answer else "",
        prompt_used=prompt_used,
        context=state.formatted_context,
        kg_context=state.kg_context,
        citations=state.answer.citations if state.answer else [],
        kg_citations=state.answer.kg_citations if state.answer else [],
        confidence=state.answer.confidence if state.answer else 0.0,
        iterations_used=state.iteration + 1,
        final_score=state.critic_feedback.score if state.critic_feedback else 0.0,
        seeds_used=state.seeds.seeds if state.seeds else [],
        triples_extracted=len(state.extracted_triples),
        ppr_entities=(state.ppr_result.ranked_entities[:10] if state.ppr_result else []),
        ppr_paths=state.ppr_result.relevant_paths if state.ppr_result else [],
        improvement_history=ctx.state.improvement_history,
        unresolved_issues=unresolved_issues,
        iteration_traces=ctx.state.metrics.state.iteration_traces,
        all_unused_triples=unique_unused[:100],
        converged=getattr(state, "converged", False),
        pipeline_state=ctx.state.metrics.finalise(),
    )
