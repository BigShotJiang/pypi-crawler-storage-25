"""Weighted Random Walk strategy."""

from __future__ import annotations

import random

import numpy as np

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PPRResult
from consistent_rag.strategies.path_utils import _get_edge_attr, extract_paths, format_context


class RandomWalkStrategy:
    """Directed random walk with query-aware transition probabilities."""

    async def rank(
        self,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
        seeds: list[str],
        query: str | None = None,
        answer_choices: list[str] | None = None,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> PPRResult:
        """Run weighted random walks from seeds."""
        if not seeds:
            return PPRResult()

        G = graph_store.graph
        valid_seeds = [s for s in seeds if s in G]
        if not valid_seeds:
            return PPRResult()

        # Query embedding for relevance scoring
        query_embedding = None
        query_relevance = {}
        if query and graph_store.embedding_service:
            query_embedding = np.array(
                graph_store.embedding_service.embed(query), dtype=float
            ).flatten()
            for node in G.nodes():
                node_emb = G.nodes.get(node, {}).get("embedding")
                if node_emb is not None and query_embedding is not None:
                    node_emb_arr = np.array(node_emb, dtype=float).flatten()
                    q_norm = np.linalg.norm(query_embedding)
                    n_norm = np.linalg.norm(node_emb_arr)
                    if q_norm > 0 and n_norm > 0:
                        query_relevance[node] = float(
                            np.dot(query_embedding, node_emb_arr) / (q_norm * n_norm)
                        )

        visit_counts = {}
        rng = random.Random(42)
        num_walks = 100
        walk_length = 10

        for _ in range(num_walks):
            # Weighted seed selection by query relevance
            if len(valid_seeds) == 1:
                current = valid_seeds[0]
            else:
                weights = [query_relevance.get(s, 0.0) + 0.1 for s in valid_seeds]
                total_w = sum(weights)
                probs = [w / total_w for w in weights]
                current = rng.choices(valid_seeds, weights=probs, k=1)[0]

            visit_counts[current] = visit_counts.get(current, 0) + 1

            for _ in range(walk_length):
                successors = list(G.successors(current))
                if not successors:
                    current = rng.choice(valid_seeds)
                    visit_counts[current] = visit_counts.get(current, 0) + 1
                    continue

                # Weighted transitions: edge confidence + query relevance
                weights = []
                for succ in successors:
                    edge_conf = _get_edge_attr(G, current, succ, "confidence", 1.0)

                    rel_score = query_relevance.get(succ, 0.0)
                    combined = 0.7 * edge_conf + 0.3 * max(0, rel_score) + 0.01
                    weights.append(combined)

                total_w = sum(weights)
                if total_w == 0:
                    current = rng.choice(successors)
                else:
                    probs = [w / total_w for w in weights]
                    current = rng.choices(successors, weights=probs, k=1)[0]

                visit_counts[current] = visit_counts.get(current, 0) + 1

        scores = {k: float(v) for k, v in visit_counts.items()}
        if scores:
            max_score = max(scores.values())
            if max_score > 0:
                scores = {k: v / max_score for k, v in scores.items()}

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        rank_cap = max(20, config.max_paths * 2)
        ranked_entities = [(e, float(s)) for e, s in ranked[:rank_cap]]

        top_entities = [e for e, _ in ranked_entities]
        paths = extract_paths(
            graph_store,
            seeds,
            top_entities,
            max_paths=config.max_paths,
            max_hops=config.path_max_hops,
            entity_scores=scores,
            relevance_threshold=config.path_relevance_threshold,
            answer_choices=answer_choices,
            excluded_relations=config.excluded_relations,
        )

        context = format_context(
            ranked_entities, paths, graph_store, "WeightedRW", config.max_paths
        )

        return PPRResult(
            ranked_entities=ranked_entities,
            relevant_paths=paths,
            subgraph_context=context,
        )
