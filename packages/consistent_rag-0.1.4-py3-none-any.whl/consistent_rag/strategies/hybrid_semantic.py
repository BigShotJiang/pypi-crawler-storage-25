"""Hybrid Semantic strategy fusing graph structure with semantic similarity."""

from __future__ import annotations

import numpy as np

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PPRResult
from consistent_rag.strategies.path_utils import _get_edge_attr, extract_paths, format_context


class HybridSemanticStrategy:
    """Hybrid traversal fusing graph structure with semantic similarity."""

    async def rank(
        self,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
        seeds: list[str],
        query: str | None = None,
        answer_choices: list[str] | None = None,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> PPRResult:
        """Run hybrid semantic traversal from seeds."""
        if not seeds:
            return PPRResult()

        G = graph_store.graph
        valid_seeds = [s for s in seeds if s in G]
        if not valid_seeds:
            return PPRResult()

        # Query embedding
        query_embedding = None
        if query and graph_store.embedding_service:
            query_embedding = np.array(
                graph_store.embedding_service.embed(query), dtype=float
            ).flatten()
            query_norm = np.linalg.norm(query_embedding)
            if query_norm > 0:
                query_embedding = query_embedding / query_norm

        scores = {s: 1.0 for s in valid_seeds}
        frontier = set(valid_seeds)
        visited = set(valid_seeds)

        for _hop in range(config.hybrid_max_hops):
            next_frontier = {}

            for node in frontier:
                neighbors = set(G.successors(node)) | set(G.predecessors(node))
                for neighbor in neighbors:
                    if neighbor in visited:
                        continue

                    # Structural score (edge confidence)
                    structural = 0.0
                    if G.has_edge(node, neighbor):
                        structural = _get_edge_attr(G, node, neighbor, "confidence", 0.5)
                    elif G.has_edge(neighbor, node):
                        structural = _get_edge_attr(G, neighbor, node, "confidence", 0.5)

                    # Semantic score (cosine similarity to query)
                    semantic = 0.0
                    if query_embedding is not None:
                        node_emb = G.nodes.get(neighbor, {}).get("embedding")
                        if node_emb is not None:
                            emb = np.array(node_emb, dtype=float).flatten()
                            emb_norm = np.linalg.norm(emb)
                            if emb_norm > 0:
                                semantic = float(np.dot(query_embedding, emb / emb_norm))

                    # Hybrid fusion
                    hybrid_score = config.hybrid_alpha * structural + (
                        1 - config.hybrid_alpha
                    ) * max(semantic, 0)
                    if neighbor not in next_frontier or hybrid_score > next_frontier[neighbor]:
                        next_frontier[neighbor] = hybrid_score

            # Keep top-K per hop
            ranked = sorted(next_frontier.items(), key=lambda x: x[1], reverse=True)
            top_nodes = ranked[: config.hybrid_top_k_per_hop]

            for name, score in top_nodes:
                scores[name] = score
                visited.add(name)

            frontier = {name for name, _ in top_nodes}
            if not frontier:
                break

        # Normalize
        if scores:
            max_score = max(scores.values())
            if max_score > 0:
                scores = {k: v / max_score for k, v in scores.items()}

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        rank_cap = max(20, config.max_paths * 2)
        ranked_entities = [(e, float(s)) for e, s in ranked[:rank_cap]]

        top_entities = [e for e, _ in ranked_entities]
        paths = extract_paths(
            graph_store,
            seeds,
            top_entities,
            max_paths=config.max_paths,
            max_hops=config.path_max_hops,
            entity_scores=scores,
            relevance_threshold=config.path_relevance_threshold,
            answer_choices=answer_choices,
            excluded_relations=config.excluded_relations,
        )

        context = format_context(
            ranked_entities, paths, graph_store, "HybridSemantic", config.max_paths
        )

        return PPRResult(
            ranked_entities=ranked_entities,
            relevant_paths=paths,
            subgraph_context=context,
        )
