"""Weighted N-Hops BFS strategy."""

from __future__ import annotations

import networkx as nx
import numpy as np

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PPRResult
from consistent_rag.strategies.path_utils import _get_edge_attr, extract_paths, format_context


class NHopsStrategy:
    """N-hop BFS strategy with weighted edge confidence and query relevance."""

    async def rank(
        self,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
        seeds: list[str],
        query: str | None = None,
        answer_choices: list[str] | None = None,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> PPRResult:
        """Run weighted N-hop BFS from seeds."""
        if not seeds:
            return PPRResult()

        G = graph_store.graph
        valid_seeds = [s for s in seeds if s in G]
        if not valid_seeds:
            return PPRResult()

        # Query embedding for relevance scoring
        query_embedding = None
        if query and graph_store.embedding_service:
            query_embedding = np.array(
                graph_store.embedding_service.embed(query), dtype=float
            ).flatten()

        # BFS with weighted scoring
        all_nodes = {}
        for seed in valid_seeds:
            all_nodes[seed] = 0
            undirected = G.to_undirected(as_view=True)
            lengths = nx.single_source_shortest_path_length(
                undirected, seed, cutoff=config.nhops_depth
            )
            for node, dist in lengths.items():
                if node not in all_nodes or dist < all_nodes[node]:
                    all_nodes[node] = dist

        # Score nodes: (1 / (1 + dist)) * edge_confidence * query_relevance
        scores = {}
        for node, dist in all_nodes.items():
            base_score = 1.0 / (1.0 + dist)

            # Edge confidence boost
            edge_conf = 0.5
            for seed in valid_seeds:
                if G.has_edge(seed, node):
                    edge_conf = max(edge_conf, _get_edge_attr(G, seed, node, "confidence", 0.5))
                if G.has_edge(node, seed):
                    edge_conf = max(edge_conf, _get_edge_attr(G, node, seed, "confidence", 0.5))

            # Query relevance
            query_rel = 0.5
            if query_embedding is not None:
                node_emb = G.nodes.get(node, {}).get("embedding")
                if node_emb is not None:
                    node_emb_arr = np.array(node_emb, dtype=float).flatten()
                    q_norm = np.linalg.norm(query_embedding)
                    n_norm = np.linalg.norm(node_emb_arr)
                    if q_norm > 0 and n_norm > 0:
                        query_rel = float(
                            np.dot(query_embedding, node_emb_arr) / (q_norm * n_norm)
                        )

            scores[node] = base_score * edge_conf * (0.5 + 0.5 * query_rel)

        # Normalize
        if scores:
            max_score = max(scores.values())
            if max_score > 0:
                scores = {k: v / max_score for k, v in scores.items()}

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        rank_cap = max(20, config.max_paths * 2)
        ranked_entities = [(e, float(s)) for e, s in ranked[:rank_cap]]

        top_entities = [e for e, _ in ranked_entities]
        paths = extract_paths(
            graph_store,
            seeds,
            top_entities,
            max_paths=config.max_paths,
            max_hops=config.path_max_hops,
            entity_scores=scores,
            relevance_threshold=config.path_relevance_threshold,
            answer_choices=answer_choices,
            excluded_relations=config.excluded_relations,
        )

        context = format_context(
            ranked_entities, paths, graph_store, "WeightedNHops", config.max_paths
        )

        return PPRResult(
            ranked_entities=ranked_entities,
            relevant_paths=paths,
            subgraph_context=context,
        )
