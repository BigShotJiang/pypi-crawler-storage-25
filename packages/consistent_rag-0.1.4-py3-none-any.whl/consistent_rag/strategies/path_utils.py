"""Shared path extraction and formatting utilities."""

from __future__ import annotations

import networkx as nx

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore


def _get_edge_attr(G, u, v, attr="confidence", default=0.5):
    """Safely get an edge attribute from a MultiDiGraph.

    In a MultiDiGraph, G.get_edge_data(u, v) returns {key: {attr: val}}.
    This helper returns the maximum value of the attribute across all edges.
    """
    edge_data = G.get_edge_data(u, v)
    if not edge_data:
        return default
    # MultiDiGraph: dict of dicts
    if (
        isinstance(edge_data, dict)
        and edge_data
        and isinstance(next(iter(edge_data.values())), dict)
    ):
        values = [
            edata.get(attr, default) for edata in edge_data.values() if isinstance(edata, dict)
        ]
        return max(values) if values else default
    # Regular DiGraph: single dict
    if isinstance(edge_data, dict):
        return edge_data.get(attr, default)
    return default


def _get_edge_relation(G, u, v, default="RELATED"):
    """Safely get the relation name from a MultiDiGraph edge.

    Checks both 'relation' and 'type' keys since edges may use either.
    """
    edge_data = G.get_edge_data(u, v)
    if not edge_data:
        return default
    # MultiDiGraph: dict of dicts
    if (
        isinstance(edge_data, dict)
        and edge_data
        and isinstance(next(iter(edge_data.values())), dict)
    ):
        for edata in edge_data.values():
            if isinstance(edata, dict):
                if "relation" in edata:
                    return edata["relation"]
                if "type" in edata:
                    return edata["type"]
        return default
    # Regular DiGraph: single dict
    if isinstance(edge_data, dict):
        if "relation" in edge_data:
            return edge_data["relation"]
        if "type" in edge_data:
            return edge_data["type"]
    return default


def extract_paths(
    graph_store: NetworkXGraphStore,
    seeds: list[str],
    top_entities: list[str],
    max_paths: int = 20,
    max_hops: int = 3,
    entity_scores: dict[str, float] | None = None,
    relevance_threshold: float = 0.3,
    answer_choices: list[str] | None = None,
    excluded_relations: list[str] | None = None,
) -> list[dict]:
    """Extract reasoning paths between seeds and top entities.

    Args:
        graph_store: The knowledge graph store.
        seeds: Seed entities.
        top_entities: Top-ranked entities.
        max_paths: Maximum number of paths to extract.
        max_hops: Maximum path length.
        entity_scores: Optional entity relevance scores.
        relevance_threshold: Minimum relevance for path inclusion.
        answer_choices: Optional answer choices for context.
        excluded_relations: Relation types to exclude from paths (e.g., SIMILAR_TO).

    Returns:
        List of path dictionaries with steps.
    """
    G = graph_store.graph
    excluded = set(excluded_relations or [])
    paths = []
    path_id = 0

    # Build a filtered undirected graph excluding excluded relation types
    if excluded:
        filtered_G = nx.Graph()
        filtered_G.add_nodes_from(G.nodes())
        for u, v, data in G.edges(data=True):
            rel = data.get("type", data.get("relation", "RELATED"))
            if rel not in excluded:
                filtered_G.add_edge(u, v)
    else:
        filtered_G = G.to_undirected()

    for seed in seeds:
        if seed not in G:
            continue

        try:
            # Find all shortest paths from seed with cutoff (more efficient)
            all_paths = nx.single_source_shortest_path(filtered_G, seed, cutoff=max_hops)
        except Exception:
            continue

        for target in top_entities[:10]:  # Only connect to top 10
            if target not in G or target == seed:
                continue

            if target not in all_paths:
                continue

            path_nodes = all_paths[target]
            if len(path_nodes) < 2:
                continue

            # Build steps
            steps = []
            valid_path = True
            for i, node in enumerate(path_nodes):
                steps.append({"name": node, "type": "entity"})
                if i < len(path_nodes) - 1:
                    # Find relation (use original graph for relation names)
                    relation = _get_edge_relation(G, node, path_nodes[i + 1])
                    if relation in excluded:
                        valid_path = False
                        break
                    steps.append({"name": relation, "type": "relation"})

            if not valid_path:
                continue

            # Compute path score
            path_score = 0.0
            if entity_scores:
                path_score = sum(entity_scores.get(n, 0) for n in path_nodes) / len(path_nodes)

            if path_score >= relevance_threshold:
                paths.append(
                    {
                        "id": f"path_{path_id}",
                        "steps": steps,
                        "score": path_score,
                        "start": seed,
                        "end": target,
                    }
                )
                path_id += 1

                if len(paths) >= max_paths:
                    return paths

    # Deduplicate: remove paths that are strict subpaths of other paths
    paths = _deduplicate_subpaths(paths)

    return paths


def _deduplicate_subpaths(paths: list[dict]) -> list[dict]:
    """Remove paths that are strict subpaths of other paths.

    Keeps longer, more informative paths. If same length, keeps higher score.
    """
    if len(paths) <= 1:
        return paths

    # Sort by length (descending) then score (descending)
    sorted_paths = sorted(
        paths,
        key=lambda p: (
            -len([s for s in p["steps"] if s.get("type") == "entity"]),
            -p.get("score", 0),
        ),
    )

    kept = []
    for p in sorted_paths:
        entities = tuple(s["name"] for s in p["steps"] if s.get("type") == "entity")

        # Check if this is a strict subpath of any kept path
        is_subpath = False
        for kp in kept:
            kept_entities = tuple(s["name"] for s in kp["steps"] if s.get("type") == "entity")
            if len(entities) < len(kept_entities) and all(e in kept_entities for e in entities):
                is_subpath = True
                break

        if not is_subpath:
            kept.append(p)

    # Re-sort by original score
    return sorted(kept, key=lambda p: -p.get("score", 0))


def format_context(
    ranked_entities: list[tuple[str, float]],
    paths: list[dict],
    graph_store: NetworkXGraphStore,
    strategy_name: str,
    max_paths: int = 20,
) -> str:
    """Format ranked entities and paths into context string.

    Args:
        ranked_entities: List of (entity, score) tuples.
        paths: List of path dictionaries.
        graph_store: The knowledge graph store.
        strategy_name: Name of the ranking strategy.
        max_paths: Maximum paths to include.

    Returns:
        Formatted context string.
    """
    parts = [f"=== Knowledge Graph Context ({strategy_name}) ==="]

    if ranked_entities:
        parts.append("\nTop relevant entities:")
        for entity, score in ranked_entities[:10]:
            parts.append(f"  - {entity} (score: {score:.3f})")

    if paths:
        parts.append(f"\nReasoning paths (showing top {min(len(paths), max_paths)}):")
        for i, path in enumerate(paths[:max_paths], 1):
            steps = path.get("steps", [])
            path_str = " → ".join(s["name"] for s in steps if s.get("type") == "entity")
            parts.append(f"  {i}. {path_str} (score: {path.get('score', 0):.3f})")

    return "\n".join(parts)
