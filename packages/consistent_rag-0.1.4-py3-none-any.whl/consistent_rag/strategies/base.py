"""Base strategy protocol."""

from typing import Protocol

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PPRResult


class SubgraphRankingStrategy(Protocol):
    """Protocol for subgraph ranking strategies."""

    async def rank(
        self,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
        seeds: list[str],
        query: str | None = None,
        answer_choices: list[str] | None = None,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> PPRResult: ...
