"""Weighted PPR strategy using custom power-iteration engine."""

from __future__ import annotations

from loguru import logger
import numpy as np

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.knowledge_graph.ppr_engine import compute_weighted_ppr, ppr_scores_to_dict
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PPRResult
from consistent_rag.strategies.path_utils import extract_paths, format_context


class PPRStrategy:
    """Personalized PageRank strategy using custom power-iteration engine with FAISS-based edge weighting."""

    async def rank(
        self,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
        seeds: list[str],
        query: str | None = None,
        answer_choices: list[str] | None = None,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> PPRResult:
        """Run weighted PPR from seed entities.

        Uses FAISS/embedding-based edge weights for query-aware scoring.
        """
        if not seeds:
            logger.debug("[WeightedPPR] No seeds provided")
            return PPRResult()

        G = graph_store.graph
        if G.number_of_nodes() == 0:
            return PPRResult()

        # Build ordered node list
        node_list = sorted(G.nodes())
        node_to_idx = {name: i for i, name in enumerate(node_list)}

        # Resolve seeds using exact match first, then semantic fallback
        seed_indices = []
        resolved_seeds = []  # Seeds that actually exist in the graph
        unresolved_seeds = []
        for s in seeds:
            if s in node_to_idx:
                seed_indices.append(node_to_idx[s])
                resolved_seeds.append(s)
            else:
                unresolved_seeds.append(s)

        # Try semantic resolution for unresolved seeds
        if unresolved_seeds and graph_store.embedding_service:
            for s in unresolved_seeds:
                similar = graph_store.find_similar_entities(s, top_k=1)
                if similar and len(similar[0]) >= 2:
                    entity_name, score = similar[0]
                    if score >= 0.7:  # Minimum similarity threshold
                        if entity_name in node_to_idx:
                            seed_indices.append(node_to_idx[entity_name])
                            resolved_seeds.append(entity_name)
                            logger.debug(
                                f"[WeightedPPR] Resolved seed '{s}' -> '{entity_name}' (score={score:.3f})"
                            )

        # Remove duplicates while preserving order
        seen = set()
        unique_indices = []
        unique_seeds = []
        for idx, seed_name in zip(seed_indices, resolved_seeds):
            if idx not in seen:
                seen.add(idx)
                unique_indices.append(idx)
                unique_seeds.append(seed_name)
        seed_indices = unique_indices
        resolved_seeds = unique_seeds

        if not seed_indices:
            logger.warning("[WeightedPPR] No seeds found in graph")
            return PPRResult()

        # Build query embedding for edge weighting
        query_embedding = None
        if query and graph_store.embedding_service:
            raw_emb = graph_store.embedding_service.embed(query)
            query_embedding = np.array(raw_emb, dtype=float).flatten()

        # Build adjacency and edge-weight matrices
        adjacency, edge_weights = self._graph_to_matrix(
            graph_store, node_list, node_to_idx, query_embedding
        )

        # Apply pruning
        if pruned_edges:
            for src_name, tgt_name in pruned_edges:
                if src_name in node_to_idx and tgt_name in node_to_idx:
                    i, j = node_to_idx[src_name], node_to_idx[tgt_name]
                    adjacency[i, j] = 0
                    edge_weights[i, j] = 0.0

        # Collect node embeddings
        node_embeddings = self._get_node_embeddings(graph_store, node_list)

        # Run custom weighted PPR
        raw_scores = compute_weighted_ppr(
            adjacency_matrix=adjacency,
            seed_indices=seed_indices,
            query_embedding=query_embedding,
            node_embeddings=node_embeddings,
            edge_weights=edge_weights,
            alpha=config.ppr_alpha,
            max_iter=config.ppr_iterations,
        )

        if len(raw_scores) == 0:
            return PPRResult()

        scores_dict = ppr_scores_to_dict(raw_scores, node_list)
        ranked = sorted(scores_dict.items(), key=lambda x: x[1], reverse=True)
        rank_cap = max(20, config.max_paths * 2)
        ranked_entities = [(e, float(s)) for e, s in ranked[:rank_cap]]

        top_entities = [e for e, _ in ranked_entities]
        paths = extract_paths(
            graph_store,
            resolved_seeds,
            top_entities,
            max_paths=config.max_paths,
            max_hops=config.path_max_hops,
            entity_scores=scores_dict,
            relevance_threshold=config.path_relevance_threshold,
            answer_choices=answer_choices,
            excluded_relations=config.excluded_relations,
        )

        context = format_context(
            ranked_entities, paths, graph_store, "WeightedPPR", config.max_paths
        )

        return PPRResult(
            ranked_entities=ranked_entities,
            relevant_paths=paths,
            subgraph_context=context,
        )

    def _graph_to_matrix(
        self,
        graph_store: NetworkXGraphStore,
        node_list: list[str],
        node_to_idx: dict[str, int],
        query_embedding: np.ndarray | None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Convert graph to adjacency + edge-weight matrices with FAISS-based weights."""
        n = len(node_list)
        adjacency = np.zeros((n, n), dtype=int)
        edge_weights = np.zeros((n, n), dtype=float)

        G = graph_store.graph
        for u, v, data in G.edges(data=True):
            if u not in node_to_idx or v not in node_to_idx:
                continue
            i, j = node_to_idx[u], node_to_idx[v]
            adjacency[i, j] = 1

            # Weight = cosine similarity(edge_embedding, query_embedding)
            weight = 1.0
            if query_embedding is not None:
                triple_emb = data.get("embedding")
                if triple_emb is not None:
                    t_emb = np.array(triple_emb, dtype=float).flatten()
                    q_emb = query_embedding.flatten()
                    t_norm = np.linalg.norm(t_emb)
                    q_norm = np.linalg.norm(q_emb)
                    if t_norm > 0 and q_norm > 0:
                        sim = float(np.dot(t_emb, q_emb) / (t_norm * q_norm))
                        weight = max(0.0, sim)

            edge_weights[i, j] = weight

        return adjacency, edge_weights

    def _get_node_embeddings(
        self,
        graph_store: NetworkXGraphStore,
        node_list: list[str],
    ) -> dict[int, np.ndarray]:
        """Collect node embeddings."""
        embeddings = {}
        for idx, name in enumerate(node_list):
            data = graph_store.graph.nodes.get(name, {})
            emb = data.get("embedding")
            if emb is not None:
                embeddings[idx] = np.array(emb, dtype=float)
        return embeddings
