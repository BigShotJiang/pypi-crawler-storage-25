"""Base types for benchmark loaders."""

from typing import Protocol, runtime_checkable

from pydantic import BaseModel


class BenchmarkSample(BaseModel):
    """A single sample from a benchmark dataset."""

    id: str
    question: str
    context: str
    answer: str | None = None
    answers: list[str] = []
    choices: list[str] | None = None
    metadata: dict = {}


@runtime_checkable
class BenchmarkLoader(Protocol):
    """Protocol for benchmark dataset loaders."""

    def load(self, limit: int | None = None) -> list[BenchmarkSample]: ...
