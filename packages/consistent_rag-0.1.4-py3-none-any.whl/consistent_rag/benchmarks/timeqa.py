"""TimeQA benchmark loader.

TimeQA is a temporal question answering benchmark with questions
requiring temporal reasoning over contexts.
"""

import json

from loguru import logger

from ..config import DATASETS_DIR
from .base import BenchmarkSample


class TimeQALoader:
    """Loader for the TimeQA 2022 NOTA benchmark from local JSON files."""

    def load(self, limit: int | None = None) -> list[BenchmarkSample]:
        """Load TimeQA samples from disk.

        Args:
            limit: Maximum number of samples to load.

        Returns:
            List of BenchmarkSample objects.
        """
        path = DATASETS_DIR / "timeqa_2022_nota.json"
        logger.info(f"Loading TimeQA from {path}")

        try:
            with open(path, encoding="utf-8") as f:
                raw: list[dict] = json.load(f)
        except FileNotFoundError:
            logger.error(f"TimeQA data file not found: {path}")
            return []
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse TimeQA JSON: {e}")
            return []

        if limit is not None:
            raw = raw[:limit]

        samples = [
            BenchmarkSample(
                id=str(item["id"]),
                question=item["question"],
                context=item["context"],
                answer=item.get("answer"),
                answers=[item["answer"]] if item.get("answer") is not None else [],
                choices=item.get("choices"),
                metadata={"source": "timeqa_2022_nota"},
            )
            for item in raw
        ]

        logger.info(f"Loaded {len(samples)} TimeQA samples")
        return samples
