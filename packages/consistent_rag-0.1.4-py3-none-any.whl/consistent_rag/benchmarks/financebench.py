"""FinanceBench benchmark loader.

Loads QA samples from local JSONL files with pre-extracted evidence
from SEC filings (10-K, 10-Q). Falls back to HuggingFace if local
files are not available.
"""

from __future__ import annotations

import json

from loguru import logger

from ..config import DATASETS_DIR
from .base import BenchmarkSample

FINANCEBENCH_DIR = DATASETS_DIR / "financebench"
OPEN_SOURCE_JSONL = FINANCEBENCH_DIR / "financebench_open_source.jsonl"
DOC_INFO_JSONL = FINANCEBENCH_DIR / "financebench_document_information.jsonl"
PDFS_DIR = FINANCEBENCH_DIR / "pdfs"


class FinanceBenchLoader:
    """Loader for the FinanceBench benchmark.

    Primary: loads from local JSONL files with PDF-backed evidence.
    Fallback: loads from HuggingFace datasets.
    """

    def __init__(self, subset: str | None = None, enrich: bool = True) -> None:
        """Initialize the loader.

        Args:
            subset: Optional filter by question_type (e.g., "metrics-generated").
            enrich: Whether to enrich samples with document info (sector, period).
        """
        self.subset = subset
        self.enrich = enrich

    def load(self, limit: int | None = None) -> list[BenchmarkSample]:
        """Load FinanceBench samples.

        Attempts local JSONL first, falls back to HuggingFace.
        """
        if OPEN_SOURCE_JSONL.exists():
            return self._load_from_jsonl(limit)

        logger.warning(f"Local JSONL not found at {OPEN_SOURCE_JSONL}, trying HuggingFace")
        try:
            return self._load_from_huggingface(limit)
        except Exception as e:
            logger.error(f"Failed to load FinanceBench: {e}")
            return []

    def _load_doc_info(self) -> dict[str, dict]:
        """Load document information for enrichment."""
        if not DOC_INFO_JSONL.exists():
            return {}

        doc_info = {}
        with open(DOC_INFO_JSONL, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                item = json.loads(line)
                doc_info[item["doc_name"]] = {
                    "gics_sector": item.get("gics_sector", ""),
                    "doc_period": item.get("doc_period"),
                    "doc_type": item.get("doc_type", ""),
                    "doc_link": item.get("doc_link", ""),
                }
        return doc_info

    def _load_from_jsonl(self, limit: int | None = None) -> list[BenchmarkSample]:
        """Load from local financebench_open_source.jsonl."""
        logger.info(f"Loading FinanceBench from {OPEN_SOURCE_JSONL}")

        doc_info = self._load_doc_info() if self.enrich else {}
        samples = []

        with open(OPEN_SOURCE_JSONL, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                item = json.loads(line)

                if self.subset:
                    question_type = item.get("question_type", "")
                    if question_type.lower() != self.subset.lower():
                        continue

                # Concatenate evidence texts as context
                evidence_list = item.get("evidence", [])
                context_parts = [
                    ev.get("evidence_text", "") for ev in evidence_list if ev.get("evidence_text")
                ]
                context = "\n\n".join(context_parts)

                doc_name = item.get("doc_name", "")
                pdf_path = str(PDFS_DIR / f"{doc_name}.pdf") if doc_name else ""

                metadata = {
                    "source": "financebench",
                    "company": item.get("company", ""),
                    "doc_name": doc_name,
                    "question_type": item.get("question_type", ""),
                    "question_reasoning": item.get("question_reasoning", ""),
                    "justification": item.get("justification", ""),
                    "pdf_path": pdf_path,
                }

                # Enrich with document info
                if doc_name in doc_info:
                    info = doc_info[doc_name]
                    metadata["gics_sector"] = info.get("gics_sector", "")
                    metadata["doc_period"] = info.get("doc_period")

                answer = item.get("answer", "")
                samples.append(
                    BenchmarkSample(
                        id=item.get("financebench_id", f"financebench_{len(samples)}"),
                        question=item.get("question", ""),
                        context=context,
                        answer=answer,
                        answers=[answer] if answer else [],
                        metadata=metadata,
                    )
                )

                if limit is not None and len(samples) >= limit:
                    break

        logger.info(f"Loaded {len(samples)} FinanceBench samples from JSONL")
        return samples

    def _load_from_huggingface(self, limit: int | None = None) -> list[BenchmarkSample]:
        """Fallback: load from HuggingFace datasets."""
        from datasets import load_dataset

        ds = load_dataset("PatronusAI/financebench", split="train")
        samples = []

        for i, item in enumerate(ds):
            if limit is not None and len(samples) >= limit:
                break

            if self.subset:
                question_type = item.get("question_type", "")
                if question_type.lower() != self.subset.lower():
                    continue

            question = item.get("question", "")
            context = item.get("evidence", item.get("context", ""))
            answer = item.get("answer", "")

            samples.append(
                BenchmarkSample(
                    id=item.get("id", f"financebench_{i}"),
                    question=question,
                    context=context,
                    answer=answer,
                    answers=[answer] if answer else [],
                    metadata={
                        "source": "financebench",
                        "company": item.get("company", ""),
                        "question_type": item.get("question_type", ""),
                    },
                )
            )

        logger.info(f"Loaded {len(samples)} FinanceBench samples from HuggingFace")
        return samples
