"""FaithEval benchmark loader.

FaithEval is a benchmark for evaluating faithfulness in RAG systems.
It contains samples with:
- Unanswerable contexts (information needed is not in context)
- Inconsistent contexts (context contains conflicting information)
- Counterfactual contexts (context contradicts common knowledge)

See: https://huggingface.co/collections/Salesforce/faitheval-benchmark
"""

from enum import Enum
import json

from loguru import logger

from ..config import DATASETS_DIR
from .base import BenchmarkSample


class ConflictType(str, Enum):
    """Type of conflict in the FaithEval sample."""

    UNANSWERABLE = "unanswerable"
    INCONSISTENT = "inconsistent"
    COUNTERFACTUAL = "counterfactual"


class FaithEvalSample(BenchmarkSample):
    """A single sample from the FaithEval benchmark."""

    choices: dict | None = None  # type: ignore[assignment]
    conflict_type: ConflictType | None = None


class FaithEvalLoader:
    """Loader for the FaithEval benchmark from local JSON."""

    DATA_FILE = DATASETS_DIR / "faitheval_data.json"

    def load(
        self,
        conflict_types: list[ConflictType] | None = None,
        limit: int | None = None,
    ) -> list[FaithEvalSample]:
        """Load FaithEval samples from local JSON file.

        Args:
            conflict_types: Accepted for interface compatibility. The local
                JSON file does not contain per-sample conflict_type labels,
                so filtering is not applied.
            limit: Maximum number of samples to load

        Returns:
            List of FaithEvalSample objects
        """
        if conflict_types is not None:
            logger.warning(
                "conflict_types filter requested but local faitheval_data.json "
                "does not have conflict_type labels — returning all samples"
            )
        try:
            with open(self.DATA_FILE, encoding="utf-8") as f:
                raw_items = json.load(f)
        except FileNotFoundError:
            logger.error(f"FaithEval data file not found: {self.DATA_FILE}")
            return []
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse FaithEval JSON: {e}")
            return []

        if limit is not None:
            raw_items = raw_items[:limit]

        samples = []
        for item in raw_items:
            answer = item.get("answer")
            answers = [answer] if answer else []

            raw_choices = item.get("choices")
            if isinstance(raw_choices, list):
                letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                choices_dict = {letters[i]: c for i, c in enumerate(raw_choices)}
            elif isinstance(raw_choices, dict):
                choices_dict = raw_choices
            else:
                choices_dict = None

            sample = FaithEvalSample(
                id=str(item.get("id", "")),
                question=item.get("question", ""),
                context=item.get("context", ""),
                answer=answer,
                answers=answers,
                choices=choices_dict,
                conflict_type=None,
                metadata={
                    "source": "faitheval_data.json",
                    "answerKey": item.get("answerKey"),
                    "justification": item.get("justification"),
                    "num_of_options": item.get("num of options"),
                },
            )
            samples.append(sample)

        logger.info(f"Total FaithEval samples loaded: {len(samples)}")
        return samples
