"""SQuAD benchmark loader.

SQuAD (Stanford Question Answering Dataset) loader for golden and negative
context variants.
"""

import json

from loguru import logger

from ..config import DATASETS_DIR
from .base import BenchmarkSample


class SQuADLoader:
    """Loader for the SQuAD benchmark from local JSON files."""

    def __init__(self, variant: str = "golden") -> None:
        """Initialize the loader.

        Args:
            variant: Dataset variant, either "golden" or "negative".
        """
        if variant not in ("golden", "negative"):
            raise ValueError(f"Unknown variant: {variant!r}. Use 'golden' or 'negative'.")
        self.variant = variant

    def load(self, limit: int | None = None) -> list[BenchmarkSample]:
        """Load SQuAD samples from disk.

        Args:
            limit: Maximum number of samples to load.

        Returns:
            List of BenchmarkSample objects.
        """
        path = DATASETS_DIR / f"squad_{self.variant}.json"
        logger.info(f"Loading SQuAD ({self.variant}) from {path}")

        try:
            with open(path, encoding="utf-8") as f:
                raw: list[dict] = json.load(f)
        except FileNotFoundError:
            logger.error(f"SQuAD data file not found: {path}")
            return []
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse SQuAD JSON: {e}")
            return []

        if limit is not None:
            raw = raw[:limit]

        samples = [
            BenchmarkSample(
                id=item["id"],
                question=item["question"],
                context=item["context"],
                answer=item.get("answer"),
                answers=[item["answer"]] if item.get("answer") is not None else [],
                choices=[c.strip() for c in item["choices"]] if item.get("choices") else None,
                metadata={"source": f"squad_{self.variant}"},
            )
            for item in raw
        ]

        logger.info(f"Loaded {len(samples)} SQuAD ({self.variant}) samples")
        return samples
