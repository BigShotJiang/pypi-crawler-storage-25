"""ConsistentRAG public API.

Provides a unified interface for the ConsistentRAG pipeline with C-GAPUD refinement.
"""

from __future__ import annotations

import asyncio
from typing import Any

from loguru import logger
from pydantic import BaseModel, Field

from consistent_rag.agents.state import PipelineState
from consistent_rag.core import Backend, PipelineType
from consistent_rag.core.pipeline_factory import PipelineFactory
from consistent_rag.logging_config import LogLevel, configure_logging, set_log_level
from consistent_rag.pipeline.models import PipelineResponse
from consistent_rag.retrievers import Document

__all__ = ["ConsistentRAG", "QueryResult", "configure_logging", "set_log_level", "LogLevel"]


class QueryResult(BaseModel):
    """Unified result from ConsistentRAG pipeline."""

    answer: str = Field(description="The generated answer")
    reasoning: str = Field(default="", description="Chain-of-thought reasoning")
    confidence: float = Field(default=0.0, description="Model confidence [0, 1]")
    context_used: str = Field(default="", description="Context the answer was grounded in")
    kg_context: str = Field(default="", description="Knowledge graph reasoning paths as text")
    citations: list[int] = Field(default_factory=list, description="Document indices cited")
    kg_citations: list[str] = Field(default_factory=list, description="KG entities cited")
    seeds_used: list[str] = Field(
        default_factory=list, description="Seed entities for graph traversal"
    )
    triples_extracted: int = Field(default=0, description="Number of KG triples extracted")
    reasoning_paths: list[dict] = Field(
        default_factory=list, description="Structured reasoning paths"
    )
    iteration_traces: list[dict] = Field(
        default_factory=list, description="Per-iteration execution traces"
    )
    all_unused_triples: list[dict] = Field(
        default_factory=list, description="Unused triples for context refinement"
    )
    iterations_used: int = Field(default=1, description="Number of refinement iterations")
    final_score: float = Field(default=0.0, description="Final critic quality score")
    converged: bool = Field(default=False, description="Whether refinement converged")
    pipeline_state: PipelineState | None = Field(
        default=None, description="Detailed execution trace"
    )

    @property
    def debug_summary(self) -> str:
        """Human-readable debug summary."""
        lines = [
            f"Answer: {self.answer[:100]}{'...' if len(self.answer) > 100 else ''}",
            f"Confidence: {self.confidence:.2f} | Critic: {self.final_score:.2f}",
            f"Iterations: {self.iterations_used} | Converged: {self.converged}",
            f"Triples: {self.triples_extracted} | Seeds: {len(self.seeds_used)}",
        ]
        if self.pipeline_state:
            lines.append(f"Duration: {self.pipeline_state.total_duration_ms:.0f}ms")
            if self.pipeline_state.iteration_traces:
                for t in self.pipeline_state.iteration_traces:
                    lines.append(
                        f"  Iter {t.iteration}: critic={t.critic_score:.2f}, "
                        f"seeds={len(t.seeds_used)}, triples={t.triples_extracted}, "
                        f"paths={t.reasoning_paths_found}, ok={t.is_satisfactory}"
                    )
        return "\n".join(lines)


class ConsistentRAG:
    """Main entry point for the ConsistentRAG library.

    Args:
        pipeline: Pipeline type: "vector_only", "kg_only", or "hybrid"
        backend: Vector store backend - "faiss" (default) or "qdrant"
        strategy: Graph traversal strategy - "ppr", "nhops", "random_walk", "hybrid"
        model: LLM model name (default: "gpt-4o-mini")
        api_key: OpenAI-compatible API key
        base_url: API base URL
        embedding_model: Embedding model name
        collection_name: Vector store collection name
        max_iterations: Max refinement iterations (default: 3)
        improvement_threshold: Critic score threshold (default: 0.8)
        ppr_alpha: PPR damping factor (default: 0.5)
        nhops_depth: BFS depth for n-hops (default: 2)
        max_paths: Max reasoning paths (default: 20)
        min_seed_score: Minimum seed relevance (default: 0.3)
        log_level: Logging verbosity
    """

    def __init__(
        self,
        pipeline: str = "hybrid",
        backend: str | None = None,
        strategy: str | None = None,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
        embedding_model: str = "text-embedding-ada-002",
        collection_name: str = "consistent_rag",
        max_iterations: int = 3,
        improvement_threshold: float = 0.8,
        ppr_alpha: float = 0.5,
        nhops_depth: int = 2,
        max_paths: int = 20,
        min_seed_score: float = 0.3,
        log_level: LogLevel | None = None,
    ):
        if log_level is not None:
            configure_logging(log_level)

        self._pipeline_type = PipelineType.from_string(pipeline)
        self._backend = Backend.from_string(backend) if backend else None
        self._strategy = strategy
        self._loop: asyncio.AbstractEventLoop | None = None

        # Default to faiss if not specified and pipeline uses vector
        if self._pipeline_type.uses_vector and self._backend is None:
            self._backend = Backend.FAISS
            logger.info("No backend specified, defaulting to FAISS")

        # Create pipeline using factory
        self._pipeline = PipelineFactory.create(
            pipeline_type=self._pipeline_type,
            backend=self._backend,
            strategy=strategy,
            model=model,
            api_key=api_key,
            base_url=base_url,
            embedding_model=embedding_model,
            collection_name=collection_name,
            max_iterations=max_iterations,
            improvement_threshold=improvement_threshold,
            ppr_alpha=ppr_alpha,
            nhops_depth=nhops_depth,
            max_paths=max_paths,
            min_seed_score=min_seed_score,
        )

        logger.info(
            f"ConsistentRAG initialized: pipeline={pipeline}, "
            f"backend={self._backend.value if self._backend else 'none'}, strategy={strategy or 'none'}"
        )

    def index_documents(
        self,
        texts: list[str],
        metadata: list[dict[str, Any]] | None = None,
        recreate: bool = False,
        build_kg: bool = True,
    ) -> None:
        """Index documents for retrieval and/or KG construction."""
        docs = []
        for i, text in enumerate(texts):
            meta = metadata[i] if metadata and i < len(metadata) else {}
            docs.append(Document(id=str(i), text=text, metadata=meta))

        self._pipeline.index_documents(docs, recreate=recreate, build_kg=build_kg)
        logger.info(f"Indexed {len(docs)} documents")

    async def aquery(
        self,
        query: str,
        context: str | None = None,
        choices: list[str] | None = None,
        top_k: int = 5,
    ) -> QueryResult:
        """Query the pipeline asynchronously.

        Args:
            query: The question to answer
            context: Optional pre-provided context (skips retrieval)
            choices: Optional multiple-choice options
            top_k: Number of documents to retrieve
        """
        if context is not None:
            response = await self._pipeline.query_without_retrieval(
                query, context, choices=choices
            )
        else:
            response = await self._pipeline.query(query, top_k=top_k, choices=choices)

        return self._to_result(response)

    def query(
        self,
        query: str,
        context: str | None = None,
        choices: list[str] | None = None,
        top_k: int = 5,
    ) -> QueryResult:
        """Query the pipeline synchronously.

        Args:
            query: The question to answer
            context: Optional pre-provided context (skips retrieval)
            choices: Optional multiple-choice options
            top_k: Number of documents to retrieve
        """
        loop = self._get_or_create_loop()
        return loop.run_until_complete(
            self.aquery(query, context=context, choices=choices, top_k=top_k)
        )

    def get_kg_stats(self) -> dict:
        """Get knowledge graph statistics."""
        return self._pipeline.get_kg_stats()

    def close(self) -> None:
        """Clean up resources."""
        self._pipeline.close()
        if self._loop and not self._loop.is_closed():
            try:
                self._loop.close()
            except RuntimeError:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _get_or_create_loop(self):
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def _to_result(self, response: PipelineResponse) -> QueryResult:
        """Convert internal response to public QueryResult."""
        return QueryResult(
            answer=response.answer,
            reasoning=response.reasoning,
            confidence=response.confidence,
            context_used=response.context,
            kg_context=response.kg_context,
            citations=response.citations,
            kg_citations=response.kg_citations,
            seeds_used=response.seeds_used,
            triples_extracted=response.triples_extracted,
            reasoning_paths=response.ppr_paths,
            iteration_traces=[trace.model_dump() for trace in response.iteration_traces]
            if response.iteration_traces
            else [],
            all_unused_triples=response.all_unused_triples,
            iterations_used=response.iterations_used,
            final_score=response.final_score,
            converged=response.converged,
            pipeline_state=response.pipeline_state,
        )
