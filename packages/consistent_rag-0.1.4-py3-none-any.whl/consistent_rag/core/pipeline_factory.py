"""Pipeline factory for creating ConsistentRAG pipelines.

Factory pattern implementation that creates the appropriate pipeline
based on PipelineType, Backend, and SubgraphStrategy selections.

Usage:
    from consistent_rag.core import PipelineType, Backend
    from consistent_rag.config import SubgraphStrategy
    from consistent_rag.core.pipeline_factory import PipelineFactory

    # Create hybrid pipeline with FAISS + PPR (default)
    pipeline = PipelineFactory.create(
        pipeline_type=PipelineType.HYBRID,
        backend=Backend.FAISS,
        strategy=SubgraphStrategy.PPR,
        model="gpt-4o-mini",
    )
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

from . import Backend, PipelineType

if TYPE_CHECKING:
    from consistent_rag.config import SubgraphStrategy
    from consistent_rag.pipeline.pipeline import ConsistentRAGPipeline


class PipelineFactory:
    """Factory for creating ConsistentRAG pipeline instances.

    This factory centralizes pipeline creation logic and provides
    clear validation of parameter combinations.
    """

    @classmethod
    def create(
        cls,
        pipeline_type: PipelineType | str,
        backend: Backend | str | None = None,
        strategy: SubgraphStrategy | str | None = None,
        **kwargs,
    ) -> ConsistentRAGPipeline:
        """Create appropriate pipeline for the given configuration.

        Args:
            pipeline_type: Type of pipeline (vector_only, kg_only, hybrid)
            backend: Vector store backend (qdrant, faiss) - required for vector modes
            strategy: Graph traversal strategy - required for KG modes
            **kwargs: Additional configuration parameters passed to config

        Returns:
            Configured pipeline instance

        Raises:
            ValueError: If required parameters are missing for the pipeline type

        Examples:
            # Vector-only with FAISS (default)
            >>> pipeline = PipelineFactory.create(
            ...     PipelineType.VECTOR_ONLY,
            ...     backend=Backend.FAISS,
            ... )

            # KG-only with PPR traversal
            >>> pipeline = PipelineFactory.create(
            ...     PipelineType.KG_ONLY,
            ...     strategy=SubgraphStrategy.PPR,
            ... )

            # Hybrid: FAISS + KG with PPR
            >>> pipeline = PipelineFactory.create(
            ...     PipelineType.HYBRID,
            ...     backend=Backend.FAISS,
            ...     strategy=SubgraphStrategy.PPR,
            ... )
        """
        # Convert string inputs to enums
        pipeline_type = cls._resolve_pipeline_type(pipeline_type)

        # Validate parameter combinations
        cls._validate_params(pipeline_type, backend, strategy)

        # Convert backend to enum if provided
        if backend is not None and isinstance(backend, str):
            backend = Backend.from_string(backend)

        # Resolve strategy to enum for logging
        strategy_enum = cls._resolve_strategy(strategy)
        logger.info(
            f"Creating pipeline: type={pipeline_type.value}, "
            f"backend={backend.value if backend else 'none'}, "
            f"strategy={strategy_enum.value if strategy_enum else 'none'}"
        )

        return cls._create_pipeline(pipeline_type, backend, strategy, **kwargs)

    @staticmethod
    def _resolve_pipeline_type(pipeline_type: PipelineType | str) -> PipelineType:
        """Resolve pipeline type from string or enum."""
        if isinstance(pipeline_type, PipelineType):
            return pipeline_type
        return PipelineType.from_string(pipeline_type)

    @staticmethod
    def _resolve_strategy(strategy):
        """Resolve strategy from string or enum."""
        from consistent_rag.config import SubgraphStrategy

        if strategy is None or isinstance(strategy, SubgraphStrategy):
            return strategy
        return SubgraphStrategy(strategy.lower())

    @classmethod
    def _validate_params(
        cls,
        pipeline_type: PipelineType,
        backend: Backend | str | None,
        strategy: SubgraphStrategy | str | None,
    ) -> None:
        """Validate that required parameters are provided."""
        if pipeline_type.uses_vector and backend is None:
            raise ValueError(
                f"Pipeline type '{pipeline_type.value}' requires a backend. "
                f"Choose from: qdrant, faiss"
            )

        if pipeline_type.uses_kg and strategy is None:
            raise ValueError(
                f"Pipeline type '{pipeline_type.value}' requires a strategy. "
                f"Choose from: ppr, nhops, random_walk, hybrid"
            )

        if not pipeline_type.uses_vector and backend is not None:
            logger.warning(
                f"Backend '{backend}' ignored for pipeline type '{pipeline_type.value}' "
                f"(does not use vector retrieval)"
            )

    @classmethod
    def _create_pipeline(
        cls,
        pipeline_type: PipelineType,
        backend: Backend | None,
        strategy: SubgraphStrategy | str | None,
        **kwargs,
    ) -> ConsistentRAGPipeline:
        """Create a ConsistentRAG pipeline using the new graph-based architecture."""
        from consistent_rag.embeddings import EmbeddingConfig
        from consistent_rag.knowledge_graph.networkx_graph_store import GraphConfig
        from consistent_rag.pipeline.config import PipelineConfig
        from consistent_rag.pipeline.pipeline import ConsistentRAGPipeline
        from consistent_rag.retrievers import RetrieverConfig

        strategy_enum = cls._resolve_strategy(strategy)

        # Build config
        config_kwargs = {
            "model": kwargs.get("model", "gpt-4o-mini"),
            "api_key": kwargs.get("api_key"),
            "base_url": kwargs.get("base_url"),
            "use_vector": pipeline_type.uses_vector,
            "subgraph_strategy": strategy_enum.value if strategy_enum else "ppr",
            "max_improvement_iterations": kwargs.get("max_iterations", 3),
            "improvement_threshold": kwargs.get("improvement_threshold", 0.8),
        }

        # Add traversal-specific params
        if "ppr_alpha" in kwargs:
            config_kwargs["ppr_alpha"] = kwargs["ppr_alpha"]
        if "nhops_depth" in kwargs:
            config_kwargs["nhops_depth"] = kwargs["nhops_depth"]
        if "max_paths" in kwargs:
            config_kwargs["max_paths"] = kwargs["max_paths"]
        if "min_seed_score" in kwargs:
            config_kwargs["min_seed_score"] = kwargs["min_seed_score"]

        # Get embedding model (used for both retriever and graph)
        embedding_model = kwargs.get("embedding_model", "text-embedding-ada-002")

        # Add retriever config if using vector
        if pipeline_type.uses_vector:
            embedding_config = EmbeddingConfig(model_name=embedding_model)

            retriever_backend = backend.value if backend else "faiss"
            collection_name = kwargs.get("collection_name", "consistent_rag")

            config_kwargs["retriever_backend"] = retriever_backend
            config_kwargs["retriever_config"] = RetrieverConfig(
                collection_name=collection_name,
                embedding_config=embedding_config,
            )

        # Always create graph_config for KG pipelines
        config_kwargs["graph_config"] = GraphConfig(embedding_model=embedding_model)

        config = PipelineConfig(**config_kwargs)
        return ConsistentRAGPipeline(config=config)
