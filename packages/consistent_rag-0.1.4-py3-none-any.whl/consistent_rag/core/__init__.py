"""Core pipeline types and backend definitions.

This module defines the fundamental building blocks for ConsistentRAG.

Public API:
    from consistent_rag.core import PipelineType, Backend

Examples:
    >>> from consistent_rag.core import PipelineType, Backend
    >>>
    >>> # Hybrid: Qdrant + KG with PPR
    >>> PipelineType.HYBRID, Backend.QDRANT
    >>>
    >>> # KG only: no retrieval, build from context
    >>> PipelineType.KG_ONLY
    >>>
    >>> # Vector only: just retrieval, no graph
    >>> PipelineType.VECTOR_ONLY, Backend.FAISS

THESIS-RELEVANT PARAMETERS:
    - PipelineType: Choose which components are active
    - Backend: Choose which vector store to use
"""

from __future__ import annotations

from enum import Enum

__all__ = ["PipelineType", "Backend"]


class PipelineType(Enum):
    """Pipeline execution modes.

    Defines which components are active in the pipeline:
    - VECTOR_ONLY: Retrieve documents, answer (no knowledge graph)
    - KG_ONLY: Build KG from provided context, traverse, answer (no retrieval)
    - HYBRID: Retrieve docs → build KG from docs → traverse + answer

    All modes support on-the-fly KG construction (default).
    To cache KG between queries, call index_documents() first.
    """

    VECTOR_ONLY = "vector_only"
    KG_ONLY = "kg_only"
    HYBRID = "hybrid"

    @property
    def uses_vector(self) -> bool:
        """Whether this pipeline uses vector retrieval."""
        return self in (PipelineType.VECTOR_ONLY, PipelineType.HYBRID)

    @property
    def uses_kg(self) -> bool:
        """Whether this pipeline uses knowledge graph."""
        return self in (PipelineType.KG_ONLY, PipelineType.HYBRID)

    @classmethod
    def from_string(cls, value: str) -> PipelineType:
        """Parse pipeline type from string with validation.

        Args:
            value: String value to parse

        Returns:
            PipelineType enum value

        Raises:
            ValueError: If value is not a valid pipeline type
        """
        try:
            return cls(value.lower())
        except ValueError:
            valid = [m.value for m in cls]
            raise ValueError(f"Invalid pipeline type '{value}'. Valid types: {', '.join(valid)}")


class Backend(Enum):
    """Vector store backend.

    Only relevant when pipeline_type.uses_vector is True.
    """

    QDRANT = "qdrant"
    FAISS = "faiss"

    @classmethod
    def from_string(cls, value: str) -> Backend:
        """Parse backend from string with validation."""
        try:
            return cls(value.lower())
        except ValueError:
            valid = [m.value for m in cls]
            raise ValueError(f"Invalid backend '{value}'. Valid backends: {', '.join(valid)}")
