"""Centralized YAML configuration with profile-based overrides.

Loads defaults from config/defaults/*.yaml, then deep-merges
overrides from config/profiles/<profile>.yaml. Credentials
(api_key, base_url) stay in environment variables — never in YAML.
"""

from __future__ import annotations

from pathlib import Path
from typing import TypeVar

from loguru import logger
from pydantic import BaseModel
import yaml

from .config import PROJ_ROOT

T = TypeVar("T", bound=BaseModel)

_DEFAULT_CONFIG_DIR = PROJ_ROOT / "config"


class ConfigLoader:
    """Loads YAML configs with profile-based overrides."""

    def __init__(
        self,
        config_dir: Path = _DEFAULT_CONFIG_DIR,
        profile: str = "dev",
    ) -> None:
        self._defaults = self._load_dir(config_dir / "defaults")
        profile_path = config_dir / "profiles" / f"{profile}.yaml"
        if not profile_path.exists():
            raise FileNotFoundError(
                f"Config profile '{profile}' not found at {profile_path}. "
                f"Available profiles: {[p.stem for p in (config_dir / 'profiles').glob('*.yaml')]}"
            )
        self._overrides = self._load_file(profile_path)
        logger.debug(f"Loaded config profile '{profile}' from {profile_path}")

    def load(self, section: str, model_cls: type[T]) -> T:
        """Load a config section into its Pydantic model."""
        merged = self._deep_merge(
            self._defaults.get(section, {}),
            self._overrides.get(section, {}),
        )
        return model_cls(**merged)

    def load_pipeline(self):
        """Load the unified pipeline config with nested models.

        Merges defaults/pipeline.yaml with profile overrides, then
        instantiates PipelineConfig with proper GraphConfig and
        RetrieverConfig nested models.
        """
        from consistent_rag.knowledge_graph.networkx_graph_store import GraphConfig
        from consistent_rag.pipeline.config import PipelineConfig
        from consistent_rag.retrievers import RetrieverConfig

        merged = self._deep_merge(
            self._defaults.get("pipeline", {}),
            self._overrides.get("pipeline", {}),
        )

        # Handle nested models: extract and instantiate separately
        graph_kwargs = merged.pop("graph_config", None)
        retriever_kwargs = merged.pop("retriever_config", None)

        if graph_kwargs is not None:
            merged["graph_config"] = GraphConfig(**graph_kwargs)
        if retriever_kwargs is not None:
            merged["retriever_config"] = RetrieverConfig(**retriever_kwargs)

        return PipelineConfig(**merged)

    @staticmethod
    def _load_dir(path: Path) -> dict[str, dict]:
        """Load all YAML files in a directory, keyed by stem."""
        result: dict[str, dict] = {}
        if not path.exists():
            return result
        for f in sorted(path.glob("*.yaml")):
            with open(f, encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
                if isinstance(data, dict):
                    result[f.stem] = data
        return result

    @staticmethod
    def _load_file(path: Path) -> dict[str, dict]:
        """Load a single YAML file with section keys."""
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        if data is None:
            return {}
        if not isinstance(data, dict):
            raise ValueError(f"Expected dict in {path}, got {type(data)}")
        return data

    @staticmethod
    def _deep_merge(base: dict, override: dict) -> dict:
        """Recursively merge override into base dict."""
        result = dict(base)
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = ConfigLoader._deep_merge(result[key], value)
            else:
                result[key] = value
        return result
