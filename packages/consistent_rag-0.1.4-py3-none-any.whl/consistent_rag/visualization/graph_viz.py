"""Interactive graph visualization using gravis.

Provides functions to render the knowledge graph and subgraphs
as interactive HTML visualizations suitable for Streamlit and Jupyter.
Uses networkx graphs directly with gravis for reliable rendering.
"""

from __future__ import annotations

from typing import Any

import networkx as nx

from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore


def _style_graph(
    G: nx.DiGraph | nx.MultiDiGraph, seeds: set[str], show_similarity_edges: bool = True
) -> nx.DiGraph:
    """Create a styled DiGraph from a graph for visualization.

    Returns a new DiGraph with node/edge attributes set for gravis styling.
    """
    styled = nx.DiGraph()

    # Add nodes with styling
    for node in G.nodes():
        is_seed = node in seeds
        styled.add_node(
            node,
            label=node,
            color="#ff6b6b" if is_seed else "#4ecdc4",
            size=25 if is_seed else 18,
            border_width=3 if is_seed else 1,
            border_color="#c0392b" if is_seed else "#2c3e50",
            type="seed" if is_seed else "entity",
        )

    # Add edges with styling
    seen_edges = set()

    if isinstance(G, nx.MultiDiGraph):
        edge_iter = G.edges(data=True, keys=True)
    else:
        edge_iter = G.edges(data=True)

    for edge_tuple in edge_iter:
        if isinstance(G, nx.MultiDiGraph):
            u, v, key, data = edge_tuple
        else:
            u, v, data = edge_tuple

        rel = data.get("type", data.get("relation", "RELATED"))
        confidence = data.get("confidence", 0.5)

        # Skip SIMILAR_TO edges if not showing them
        if rel == "SIMILAR_TO" and not show_similarity_edges:
            continue

        # For MultiDiGraph, only add one edge per pair with combined info
        edge_key = (u, v)
        if edge_key in seen_edges:
            continue
        seen_edges.add(edge_key)

        is_similarity = rel == "SIMILAR_TO"

        if is_similarity:
            edge_color = "#95a5a6"
            width = 1
            style = "dashed"
        else:
            edge_color = "#3498db"
            width = max(1, confidence * 3)
            style = "solid"

        styled.add_edge(
            u,
            v,
            label=rel,
            color=edge_color,
            width=width,
            style=style,
            confidence=round(confidence, 3),
            relation_type=rel,
        )

    return styled


def visualize_whole_graph(
    graph_store: NetworkXGraphStore,
    seeds: list[str] | None = None,
    show_similarity_edges: bool = True,
    height: int = 600,
) -> str:
    """Create an interactive HTML visualization of the whole knowledge graph.

    Args:
        graph_store: The knowledge graph store.
        seeds: Seed entities to highlight in red.
        show_similarity_edges: Whether to show SIMILAR_TO edges.
        height: Visualization height in pixels.

    Returns:
        HTML string for embedding in Streamlit/Jupyter.
    """
    try:
        import gravis as gv
    except ImportError:
        return "<p>gravis not installed. Run: uv pip install gravis</p>"

    G = graph_store.graph
    if G.number_of_nodes() == 0:
        return "<p>Graph is empty</p>"

    seeds_set = set(seeds) if seeds else set()
    styled = _style_graph(G, seeds_set, show_similarity_edges)

    fig = gv.d3(
        styled,
        graph_height=height,
        show_edge_label=True,
        edge_label_data_source="label",
        node_label_data_source="label",
        use_node_size_normalization=False,
        use_edge_size_normalization=False,
        node_hover_tooltip=True,
        edge_hover_tooltip=True,
    )

    return fig.to_html()


def visualize_subgraph(
    graph_store: NetworkXGraphStore,
    nodes: list[str],
    edges: list[dict[str, Any]],
    seeds: list[str] | None = None,
    height: int = 500,
) -> str:
    """Create an interactive HTML visualization of a subgraph.

    Args:
        graph_store: The knowledge graph store.
        nodes: List of node names in the subgraph.
        edges: List of edge dicts with 'source', 'target', 'relation', 'score'.
        seeds: Seed entities to highlight.
        height: Visualization height in pixels.

    Returns:
        HTML string for embedding.
    """
    try:
        import gravis as gv
    except ImportError:
        return "<p>gravis not installed. Run: uv pip install gravis</p>"

    if not nodes:
        return "<p>Subgraph is empty</p>"

    seeds_set = set(seeds) if seeds else set()

    # Build networkx graph for gravis
    G = nx.DiGraph()

    # Add nodes with styling
    for node in nodes:
        is_seed = node in seeds_set
        G.add_node(
            node,
            label=node,
            color="#ff6b6b" if is_seed else "#4ecdc4",
            size=25 if is_seed else 18,
            border_width=3 if is_seed else 1,
            border_color="#c0392b" if is_seed else "#2c3e50",
            type="seed" if is_seed else "entity",
        )

    # Add edges with styling
    seen_edges = set()
    for edge in edges:
        src = edge.get("source", "")
        tgt = edge.get("target", "")
        rel = edge.get("relation", "RELATED")
        score = edge.get("score", 0.5)

        edge_key = (src, tgt)
        if edge_key in seen_edges:
            continue
        seen_edges.add(edge_key)

        G.add_edge(
            src,
            tgt,
            label=rel,
            color="#e74c3c" if score > 0.7 else "#3498db",
            width=max(1, score * 4),
            confidence=round(score, 3),
            relation_type=rel,
        )

    fig = gv.d3(
        G,
        graph_height=height,
        show_edge_label=True,
        edge_label_data_source="label",
        node_label_data_source="label",
        use_node_size_normalization=False,
        use_edge_size_normalization=False,
        node_hover_tooltip=True,
        edge_hover_tooltip=True,
    )

    return fig.to_html()


def visualize_path_evolution(
    iteration_traces: list[Any],
    height: int = 400,
) -> str:
    """Create a timeline visualization showing path evolution across iterations.

    Args:
        iteration_traces: List of IterationTrace objects.
        height: Visualization height.

    Returns:
        HTML string.
    """
    try:
        import gravis as gv
    except ImportError:
        return "<p>gravis not installed</p>"

    if not iteration_traces:
        return "<p>No iteration data</p>"

    # Build a networkx graph with iteration layers
    G = nx.DiGraph()

    for iter_idx, trace in enumerate(iteration_traces):
        # Add iteration layer node
        layer_node = f"iter_{iter_idx}"
        G.add_node(
            layer_node,
            label=f"Iteration {iter_idx}",
            color="#9b59b6",
            size=30,
            type="layer",
        )

        # Add subgraph entities for this iteration
        for entity in trace.subgraph_nodes or []:
            entity_id = f"{entity}_iter_{iter_idx}"
            is_seed = entity in (trace.seeds_used or [])
            G.add_node(
                entity_id,
                label=entity,
                color="#ff6b6b" if is_seed else "#4ecdc4",
                size=20 if is_seed else 15,
                type="seed" if is_seed else "entity",
            )

            # Connect to layer node
            G.add_edge(
                layer_node,
                entity_id,
                color="#bdc3c7",
                width=1,
                style="dashed",
                alpha=0.3,
            )

        # Add edges within iteration
        seen_edges = set()
        for edge in trace.subgraph_edges or []:
            src = edge.get("source", "")
            tgt = edge.get("target", "")
            rel = edge.get("relation", "RELATED")
            score = edge.get("score", 0.5)

            src_id = f"{src}_iter_{iter_idx}"
            tgt_id = f"{tgt}_iter_{iter_idx}"

            edge_key = (src_id, tgt_id)
            if edge_key in seen_edges:
                continue
            seen_edges.add(edge_key)

            G.add_edge(
                src_id,
                tgt_id,
                label=rel,
                color="#3498db",
                width=max(1, score * 3),
                confidence=round(score, 3),
            )

    fig = gv.d3(
        G,
        graph_height=height,
        show_edge_label=True,
        edge_label_data_source="label",
        node_label_data_source="label",
        use_node_size_normalization=False,
        use_edge_size_normalization=False,
        node_hover_tooltip=True,
        edge_hover_tooltip=True,
    )

    return fig.to_html()
