"""Answer generation step."""

from __future__ import annotations

from consistent_rag.agents.answer.agent import create_answer_agent, run_answer
from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.common.models import AnswerWithCitations, IterationState
from consistent_rag.pipeline.models import PipelineIterationState


class AnswerGenerationStep:
    """Generates an answer using the answer agent."""

    def __init__(
        self,
        agent=None,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._agent = agent or create_answer_agent(model, api_key, base_url)

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
    ) -> tuple[AnswerWithCitations, str]:
        """Generate an answer.

        Args:
            state: Current pipeline iteration state.
            metrics: Metrics collector for timing.

        Returns:
            Tuple of (answer, prompt_used).
        """
        metrics.start_step("answer_generation")

        # Convert pipeline state to iteration state for the agent
        iter_state = IterationState(
            iteration=state.iteration,
            query=state.query,
            choices=state.choices,
            formatted_context=state.combined_context,
            critic_feedback=state.critic_feedback,
        )

        answer, prompt_used = await run_answer(self._agent, iter_state)
        state.answer = answer

        metrics.end_step(
            input_summary=f"query={state.query[:80]}",
            output_summary=f"answer={answer.answer[:80]}",
        )

        return answer, prompt_used
