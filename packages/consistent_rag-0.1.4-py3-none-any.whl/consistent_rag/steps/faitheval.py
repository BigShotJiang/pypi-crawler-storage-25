"""FaithEval classification step."""

from __future__ import annotations

from loguru import logger
from pydantic_ai import Agent

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.common.prompts import SYSTEM_PROMPTS, get_faitheval_prompt
from consistent_rag.benchmarks.faitheval import FaithEvalSample
from consistent_rag.evaluation.models import FaithEvalResponse
from consistent_rag.pipeline.models import PipelineIterationState


class FaithEvalStep:
    """Optional FaithEval classification (decoupled from main loop)."""

    def __init__(
        self, model: str = "gpt-4o-mini", api_key: str | None = None, base_url: str | None = None
    ) -> None:
        from openai import AsyncOpenAI
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        from consistent_rag.llm import resolve_llm_credentials

        key, url = resolve_llm_credentials(api_key=api_key, base_url=base_url)
        client = AsyncOpenAI(api_key=key, base_url=url)
        provider = OpenAIProvider(openai_client=client)
        chat_model = OpenAIChatModel(model, provider=provider)

        self._agent = Agent(
            chat_model,
            output_type=FaithEvalResponse,
            system_prompt=SYSTEM_PROMPTS["faitheval"],
            retries=2,
        )

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        sample: FaithEvalSample,
    ) -> FaithEvalResponse | None:
        """Run FaithEval classification."""
        enriched_sample = sample.model_copy(update={"context": state.combined_context})
        faitheval_prompt = get_faitheval_prompt(enriched_sample)
        try:
            metrics.start_step("faitheval_classification")
            result = await self._agent.run(faitheval_prompt)
            response = result.output
            response.prompt_used = faitheval_prompt
            metrics.end_step(
                input_summary="faitheval sample",
                output_summary=f"label={response.answer_label}",
            )
            logger.info(f"FaithEval answer_label: {response.answer_label}")
            return response
        except Exception as e:
            logger.warning(f"FaithEval classification step failed: {e}")
            return None
