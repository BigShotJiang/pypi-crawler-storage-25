"""Retrieval step for document fetching."""

from __future__ import annotations

from loguru import logger

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.common.models import RouteDecision
from consistent_rag.agents.retrieval.agent import create_retrieval_agent, run_retrieval
from consistent_rag.pipeline.models import PipelineIterationState
from consistent_rag.retrievers import BaseRetriever


class RetrievalStep:
    """Retrieves documents from vector store."""

    def __init__(
        self,
        agent=None,
        retriever: BaseRetriever | None = None,
        use_vector: bool = True,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._agent = agent
        self._retriever = retriever
        self._use_vector = use_vector
        if agent is None and retriever is not None:
            self._agent = create_retrieval_agent(model, api_key, base_url)

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        top_k: int = 5,
    ) -> None:
        """Retrieve documents and set state.retrieved_docs / formatted_context."""
        strategy = "vector" if self._use_vector else "none"
        state.route_decision = RouteDecision(
            strategy=strategy,
            reasoning=f"Config-driven: use_vector={self._use_vector}",
        )

        if not self._use_vector or self._retriever is None:
            state.retrieved_docs = []
            state.formatted_context = ""
            return

        metrics.start_step("retrieval")
        state.retrieved_docs, state.formatted_context = await run_retrieval(
            self._agent, state.query, self._retriever, top_k
        )
        metrics.end_step(
            input_summary=f"query={state.query[:80]}",
            output_summary=f"{len(state.retrieved_docs)} docs",
        )
        logger.info(f"Retrieved {len(state.retrieved_docs)} documents")
