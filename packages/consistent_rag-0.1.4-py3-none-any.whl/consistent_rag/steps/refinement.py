"""C-GAPUD refinement step.

Critic-Guided Adaptive Path Utility Diffusion (C-GAPUD):
- Structured critic feedback with error types
- Path-aware edge re-weighting with fixed interpolation (zero training)
- Budgeted diverse seed evolution
- Session-level relation fusion
- Convergence checking
"""

from __future__ import annotations

from typing import Any

from loguru import logger
import numpy as np

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.critic.agent import CriticErrorType, StructuredCriticFeedback
from consistent_rag.embeddings import EmbeddingService
from consistent_rag.knowledge_graph.lsh_index import CosineLSH
from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.models import PipelineIterationState, SeedExtractionResult


class CriticGuidedRefinementStep:
    """C-GAPUD refinement using structured critic feedback."""

    def __init__(
        self,
        graph_store: NetworkXGraphStore,
        embedding_service: EmbeddingService,
        lsh_index: CosineLSH | None = None,
        max_new_seeds: int = 5,
        seed_budget: int = 10,
        # Fixed hyperparameters (zero training)
        alpha: float = 0.3,  # old confidence retention
        beta: float = 0.5,  # query relevance weight
        gamma: float = 0.2,  # path utility weight
        pruned_suppression: float = 0.05,
        new_seed_similarity_threshold: float = 0.7,
        stagnation_threshold: float = 0.85,
        weight_delta_threshold: float = 0.01,
    ) -> None:
        self._graph_store = graph_store
        self._embed = embedding_service
        self._lsh = lsh_index
        self._max_new_seeds = max_new_seeds
        self._seed_budget = seed_budget
        self._alpha = alpha
        self._beta = beta
        self._gamma = gamma
        self._pruned_suppression = pruned_suppression
        self._new_seed_similarity_threshold = new_seed_similarity_threshold
        self._stagnation_threshold = stagnation_threshold
        self._weight_delta_threshold = weight_delta_threshold

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        pruned_entities: set[str],
    ) -> set[str]:
        """Execute one C-GAPUD refinement iteration.

        Args:
            state: Current pipeline iteration state.
            metrics: Metrics collector for timing.
            pruned_entities: Set of entities to prune.

        Returns:
            Updated pruned_entities set.
        """
        feedback = state.critic_feedback
        if not feedback or feedback.is_satisfactory:
            return pruned_entities

        metrics.start_step("c_gapud_refinement")

        # Ensure graph is available
        graph = state.graph
        if graph is None:
            logger.warning("No graph available for refinement")
            return pruned_entities

        # Step 1: Build refined query from original query + critic guidance
        guidance = feedback.guidance or " ".join(feedback.improvement_suggestions)
        refined_query = f"{state.query} {guidance}".strip()
        query_embedding = np.array(self._embed.embed(refined_query), dtype=float).flatten()

        # Store edge weights before update for delta tracking
        edges_before = {e: graph.edges[e].get("confidence", 0.5) for e in graph.edges}

        # Step 2: Re-weight edges based on refined query
        self._update_edge_weights(graph, query_embedding, state, pruned_entities)

        # Step 3: Re-weight nodes (affects PPR personalization)
        self._update_node_weights(graph, query_embedding)

        # Step 4: Compute weight delta for convergence tracking
        avg_weight_delta = self._compute_weight_delta(graph, edges_before)
        metrics.last_weight_delta = avg_weight_delta  # type: ignore[attr-defined]

        # Step 5: Fuse relations for long paths
        path_utilities = self._compute_path_utilities(state, query_embedding, feedback)
        shortcuts = self._fuse_relations(graph, state, feedback, path_utilities)

        # Step 6: Discover new seeds via LSH + FAISS + critic explicit
        new_candidates = self._discover_new_seeds(refined_query, query_embedding, feedback)

        # Step 7: Evolve seed set with budget and diversity
        if new_candidates:
            state.seeds = self._evolve_seeds(
                state.seeds, new_candidates, query_embedding, state, graph
            )

        # Step 8: Check convergence
        converged = self._check_convergence(state, avg_weight_delta)
        if converged:
            logger.info(f"C-GAPUD converged after {state.iteration + 1} iterations")
            state.converged = True

        new_seeds_count = len([e for e in new_candidates if e[2] == "new"])
        metrics.end_step(
            input_summary=f"errors={[e.value for e in feedback.error_types]}",
            output_summary=f"shortcuts={len(shortcuts)}, new_seeds={new_seeds_count}, converged={converged}",
        )

        metrics.update_last_trace(
            refinement_applied=True,
            weight_delta=avg_weight_delta,
            converged=converged,
        )
        metrics.increment_refinements()

        return pruned_entities

    def _update_edge_weights(
        self,
        graph: Any,
        query_embedding: np.ndarray,
        state: PipelineIterationState,
        pruned_entities: set[str],
    ) -> int:
        """Re-weight edges based on refined query using fixed interpolation.

        Returns number of edges processed.
        """
        edges_processed = 0

        for u, v, edge_data in graph.edges(data=True):
            old_confidence = edge_data.get("confidence", 0.5)

            # 2a. Compute query relevance for this edge
            edge_embedding = edge_data.get("embedding")
            if edge_embedding is not None:
                query_relevance = self._cosine_similarity(
                    np.array(edge_embedding, dtype=float).flatten(),
                    query_embedding,
                )
            else:
                query_relevance = 0.5  # Neutral default

            # 2b. Compute path-aware prior
            path_utility = self._compute_path_aware_prior(state, u, v)

            # 2c. Combine: fixed interpolation (alpha + beta + gamma = 1.0)
            new_confidence = (
                self._alpha * old_confidence
                + self._beta * query_relevance
                + self._gamma * path_utility
            )
            new_confidence = max(0.01, min(1.0, new_confidence))

            # 2d. Apply pruned-entity suppression
            if u in pruned_entities or v in pruned_entities:
                new_confidence *= self._pruned_suppression

            edge_data["confidence"] = float(new_confidence)
            edges_processed += 1

        return edges_processed

    def _update_node_weights(self, graph: Any, query_embedding: np.ndarray) -> None:
        """Re-weight nodes for PPR personalization."""
        for node_name, node_data in graph.nodes(data=True):
            node_embedding = node_data.get("embedding")
            if node_embedding is not None:
                node_data["query_relevance"] = self._cosine_similarity(
                    np.array(node_embedding, dtype=float).flatten(),
                    query_embedding,
                )
            else:
                node_data["query_relevance"] = 0.5

    def _compute_path_aware_prior(self, state: PipelineIterationState, u: str, v: str) -> float:
        """Check if edge (u,v) appeared in past reasoning paths."""
        if not state.reasoning_paths_history:
            return 0.5  # Neutral

        utilities = []
        for iteration_paths in state.reasoning_paths_history:
            for path_dict in iteration_paths:
                steps = path_dict.get("steps", [])
                # Check if edge (u,v) or (v,u) is in this path
                # Path steps alternate: entity -> relation -> entity
                path_edges = []
                for i in range(len(steps) - 2):
                    if (
                        steps[i].get("type") == "entity"
                        and steps[i + 1].get("type") == "relation"
                        and steps[i + 2].get("type") == "entity"
                    ):
                        path_edges.append((steps[i]["name"], steps[i + 2]["name"]))

                if (u, v) in path_edges or (v, u) in path_edges:
                    utilities.append(path_dict.get("score", 0.5))

        if not utilities:
            return 0.5

        return float(np.mean(utilities))

    def _compute_weight_delta(self, graph: Any, edges_before: dict) -> float:
        """Compute average weight change."""
        weight_deltas = []
        for e in graph.edges:
            if e in edges_before:
                old_weight = edges_before[e]
                new_weight = graph.edges[e].get("confidence", old_weight)
                weight_deltas.append(abs(new_weight - old_weight))

        return float(np.mean(weight_deltas)) if weight_deltas else 1.0

    def _compute_path_utilities(
        self,
        state: PipelineIterationState,
        query_embedding: np.ndarray,
        feedback: StructuredCriticFeedback,
    ) -> dict[str, float]:
        """Compute utility for each reasoning path."""
        utilities = {}
        paths = state.ppr_result.relevant_paths if state.ppr_result else []

        for i, path in enumerate(paths):
            path_id = path.get("id", f"path_{i}")

            # Base relevance: path embedding vs query
            path_emb = self._embed_path(path)
            relevance = self._cosine_similarity(path_emb, query_embedding)

            # Error adjustments
            adjustment = 1.0
            if path_id in feedback.irrelevant_path_ids:
                adjustment *= 0.1
            if path_id in feedback.long_path_ids:
                adjustment *= 0.5
            if path_id in feedback.contradiction_path_ids:
                adjustment *= 0.05

            # Missing entity boost
            for entity in feedback.missing_entities:
                if entity in str(path):
                    adjustment += 0.3

            utilities[path_id] = relevance * adjustment

        return utilities

    def _embed_path(self, path: dict) -> np.ndarray:
        """Embed a path using its edge embeddings."""
        steps = path.get("steps", [])
        edge_embs = []
        for step in steps:
            emb = step.get("embedding")
            if emb is not None:
                edge_embs.append(np.array(emb, dtype=float))
        if not edge_embs:
            return np.zeros(1536)  # Default embedding dim
        return np.mean(edge_embs, axis=0)

    def _fuse_relations(
        self,
        graph: Any,
        state: PipelineIterationState,
        feedback: StructuredCriticFeedback,
        path_utilities: dict[str, float],
    ) -> list[tuple]:
        """Add shortcut edges for high-utility long paths."""
        shortcuts = []
        if CriticErrorType.LONG_PATH not in feedback.error_types:
            return shortcuts

        paths = state.ppr_result.relevant_paths if state.ppr_result else []
        for i, path in enumerate(paths):
            path_id = path.get("id", f"path_{i}")
            if path_id not in feedback.long_path_ids:
                continue
            if path_utilities.get(path_id, 0) < 0.8:
                continue

            steps = path.get("steps", [])
            if len(steps) < 3:
                continue

            head = steps[0].get("name")
            tail = steps[-1].get("name")
            if head and tail:
                graph.add_edge(
                    head,
                    tail,
                    confidence=path_utilities[path_id] * 0.9,
                    relation="shortcut",
                    is_shortcut=True,
                )
                shortcuts.append((head, tail))

        return shortcuts

    def _discover_new_seeds(
        self,
        refined_query: str,
        query_embedding: np.ndarray,
        feedback: StructuredCriticFeedback,
    ) -> list[tuple[str, float, str]]:
        """Discover new seeds via LSH + FAISS + critic explicit.

        Returns list of (entity, score, source) tuples.
        """
        candidates: list[tuple[str, float, str]] = []

        # 5a. LSH expansion: triples similar to refined query
        if self._lsh is not None:
            try:
                lsh_results = self._lsh.query(query_embedding, max_results=20)
                for triple_id, similarity in lsh_results[: self._max_new_seeds]:
                    parts = triple_id.split("|")
                    if len(parts) >= 2:
                        if similarity > self._new_seed_similarity_threshold:
                            candidates.append((parts[0], similarity, "lsh"))
                            candidates.append((parts[-1], similarity, "lsh"))
            except Exception as e:
                logger.warning(f"LSH expansion failed: {e}")

        # 5b. FAISS expansion: nearest neighbor entities in graph
        try:
            similar = self._graph_store.find_similar_entities(refined_query, top_k=10)
            for entity_name, score in similar:
                if score > self._new_seed_similarity_threshold:
                    candidates.append((entity_name, score, "faiss"))
        except Exception as e:
            logger.warning(f"FAISS expansion failed: {e}")

        # 5c. Critic explicit: encode missing entities, find closest graph entity
        for missing_entity in feedback.missing_entities:
            try:
                closest = self._graph_store.find_similar_entities(missing_entity, top_k=1)
                if closest:
                    entity_name, dist = closest[0]
                    # Convert distance to similarity (FAISS returns cosine similarity for normalized vectors)
                    similarity = dist if dist <= 1.0 else 1.0 / dist
                    candidates.append((entity_name, similarity, "critic_explicit"))
            except Exception as e:
                logger.warning(f"Critic explicit expansion failed for {missing_entity}: {e}")

        # Deduplicate: keep highest score per entity
        best_for_entity: dict[str, tuple[float, str]] = {}
        for entity, score, source in candidates:
            if entity not in best_for_entity or score > best_for_entity[entity][0]:
                best_for_entity[entity] = (score, source)

        return [(entity, score, source) for entity, (score, source) in best_for_entity.items()]

    def _evolve_seeds(
        self,
        current_seeds: SeedExtractionResult | None,
        new_candidates: list[tuple[str, float, str]],
        query_embedding: np.ndarray,
        state: PipelineIterationState,
        graph: Any,
    ) -> SeedExtractionResult:
        """Evolve seed set with budget and anchor preservation."""
        if current_seeds is None:
            current_seeds = SeedExtractionResult(seeds=[], scores=[], reasoning="")

        all_entries: list[tuple[str, float, str, str]] = []  # (entity, score, source, status)

        # Existing seeds with age penalty
        for i, seed in enumerate(current_seeds.seeds):
            seed_emb = graph.nodes.get(seed, {}).get("embedding")
            if seed_emb is not None:
                relevance = self._cosine_similarity(
                    np.array(seed_emb, dtype=float).flatten(),
                    query_embedding,
                )
            else:
                relevance = current_seeds.scores[i] if i < len(current_seeds.scores) else 0.5

            age_penalty = 1.0 - (0.05 * state.iteration)
            source = (
                current_seeds.source_type[i] if i < len(current_seeds.source_type) else "existing"
            )
            all_entries.append((seed, relevance * age_penalty, source, "existing"))

        # New candidates
        for entity, sim, source in new_candidates:
            if entity not in graph.nodes:
                continue
            all_entries.append((entity, sim, source, "new"))

        # Deduplicate (keep highest score per entity)
        best_for_entity: dict[str, tuple[float, str, str]] = {}
        for entity, score, source, status in all_entries:
            if entity not in best_for_entity or score > best_for_entity[entity][0]:
                best_for_entity[entity] = (score, source, status)

        # Rank by score
        ranked = sorted(
            [(e, s, src, st) for e, (s, src, st) in best_for_entity.items()],
            key=lambda x: x[1],
            reverse=True,
        )

        # Budget with anchor preservation
        budget = self._seed_budget
        selected: list[tuple[str, float, str]] = []

        # Always keep at least 1 original seed (symbolic anchoring)
        original_seeds = (
            [
                e
                for e in current_seeds.seeds
                if current_seeds.source_type[current_seeds.seeds.index(e)] == "initial"
            ]
            if current_seeds.source_type
            else []
        )
        if original_seeds:
            anchor = original_seeds[0]
            if anchor in best_for_entity:
                selected.append((anchor, best_for_entity[anchor][0], best_for_entity[anchor][1]))

        # Fill remaining slots from ranked list
        for entity, score, source, status in ranked:
            if len(selected) >= budget:
                break
            if entity not in [e for e, _, _ in selected]:
                selected.append((entity, score, source))

        return SeedExtractionResult(
            seeds=[s for s, _, _ in selected],
            scores=[sc for _, sc, _ in selected],
            reasoning="Evolved via C-GAPUD",
            source_type=[src for _, _, src in selected],
        )

    def _check_convergence(self, state: PipelineIterationState, weight_delta: float) -> bool:
        """Check if refinement has plateaued (stagnation)."""
        if state.iteration < 2:
            return False  # Need at least 2 iterations to compare

        if not state.reasoning_paths_history or len(state.reasoning_paths_history) < 2:
            return False

        # Path stagnation score (Jaccard of edge sets)
        prev_paths = state.reasoning_paths_history[-2]
        curr_paths = state.reasoning_paths_history[-1]

        prev_edges = set()
        curr_edges = set()

        for path_dict in prev_paths:
            steps = path_dict.get("steps", [])
            for i in range(len(steps) - 2):
                if (
                    steps[i].get("type") == "entity"
                    and steps[i + 1].get("type") == "relation"
                    and steps[i + 2].get("type") == "entity"
                ):
                    prev_edges.add(tuple(sorted([steps[i]["name"], steps[i + 2]["name"]])))

        for path_dict in curr_paths:
            steps = path_dict.get("steps", [])
            for i in range(len(steps) - 2):
                if (
                    steps[i].get("type") == "entity"
                    and steps[i + 1].get("type") == "relation"
                    and steps[i + 2].get("type") == "entity"
                ):
                    curr_edges.add(tuple(sorted([steps[i]["name"], steps[i + 2]["name"]])))

        if not prev_edges or not curr_edges:
            stagnation = 0.0
        else:
            intersection = len(prev_edges & curr_edges)
            union = len(prev_edges | curr_edges)
            stagnation = intersection / union if union > 0 else 1.0

        # Combined convergence: paths AND weights stable
        is_stagnated = stagnation > self._stagnation_threshold
        is_weight_stable = weight_delta < self._weight_delta_threshold

        return is_stagnated and is_weight_stable

    @staticmethod
    def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        a_norm = np.linalg.norm(a)
        b_norm = np.linalg.norm(b)
        if a_norm == 0 or b_norm == 0:
            return 0.0
        return float(np.dot(a, b) / (a_norm * b_norm))
