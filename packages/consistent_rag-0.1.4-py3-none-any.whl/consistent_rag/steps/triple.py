"""Triple extraction step."""

from __future__ import annotations

from loguru import logger

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.knowledge_graph.extractor import TripleExtractor
from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.models import PipelineIterationState


class TripleExtractionStep:
    """Extracts triples from text and stores them in the graph."""

    def __init__(
        self,
        extractor: TripleExtractor,
        graph_store: NetworkXGraphStore,
        max_triples_per_doc: int = 40,
    ) -> None:
        self._extractor = extractor
        self._graph_store = graph_store
        self._max_triples = max_triples_per_doc

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        texts: list[str],
    ) -> None:
        """Extract triples and store in graph."""
        if not texts:
            return

        metrics.start_step("triple_extraction")
        all_triples = []

        for text in texts:
            triples = await self._extractor.extract_async(text, max_triples=self._max_triples)
            all_triples.extend(triples)
            if triples:
                self._graph_store.add_triples(triples)

        state.extracted_triples = all_triples
        metrics.end_step(
            input_summary=f"{len(texts)} texts",
            output_summary=f"{len(all_triples)} triples",
        )
        metrics.set_triples_count(len(all_triples))
        logger.info(f"Extracted {len(all_triples)} triples")
