"""Critic evaluation step."""

from __future__ import annotations

from loguru import logger

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.common.models import AnswerWithCitations
from consistent_rag.agents.critic.agent import (
    StructuredCriticFeedback,
    create_critic_agent,
    run_critic,
)
from consistent_rag.pipeline.models import PipelineIterationState


class CriticStep:
    """Evaluates answer quality using the critic agent."""

    def __init__(
        self,
        agent=None,
        threshold: float = 0.8,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._agent = agent or create_critic_agent(model, api_key, base_url, threshold)
        self._threshold = threshold

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        answer_result: AnswerWithCitations | None = None,
    ) -> StructuredCriticFeedback:
        """Evaluate the answer.

        Args:
            state: Current pipeline iteration state.
            metrics: Metrics collector for timing.
            answer_result: Optional answer to evaluate (uses state.answer if None).

        Returns:
            StructuredCriticFeedback with error classification.
        """
        metrics.start_step("critic")

        answer = answer_result or state.answer
        if not answer:
            logger.warning("No answer to critique")
            return StructuredCriticFeedback(
                score=0.0,
                is_satisfactory=False,
                guidance="No answer was generated.",
            )

        feedback = await run_critic(
            self._agent,
            query=state.query,
            context=state.combined_context,
            answer_text=answer.answer,
            reasoning=answer.reasoning,
            threshold=self._threshold,
        )

        state.critic_feedback = feedback

        metrics.end_step(
            input_summary=f"answer={answer.answer[:80]}",
            output_summary=f"score={feedback.score:.2f}, satisfactory={feedback.is_satisfactory}",
        )

        return feedback
