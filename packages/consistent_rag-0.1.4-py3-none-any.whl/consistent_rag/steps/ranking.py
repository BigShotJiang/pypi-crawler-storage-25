"""Subgraph ranking step."""

from __future__ import annotations

from loguru import logger

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.knowledge_graph.networkx_graph_store import NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PipelineIterationState
from consistent_rag.strategies.base import SubgraphRankingStrategy
from consistent_rag.strategies.hybrid_semantic import HybridSemanticStrategy
from consistent_rag.strategies.weighted_nhops import NHopsStrategy
from consistent_rag.strategies.weighted_ppr import PPRStrategy
from consistent_rag.strategies.weighted_random_walk import RandomWalkStrategy


class SubgraphRankingStep:
    """Ranks subgraph entities using the configured strategy."""

    def __init__(
        self,
        strategy: SubgraphRankingStrategy,
        config: PipelineConfig,
        graph_store: NetworkXGraphStore,
    ) -> None:
        self._strategy = strategy
        self._config = config
        self._graph_store = graph_store

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
        pruned_edges: set[tuple[str, str]] | None = None,
    ) -> None:
        """Rank subgraph and update state.ppr_result."""
        metrics.start_step("subgraph_ranking")

        seeds = state.seeds.seeds if state.seeds else []
        if not seeds:
            logger.warning("No seeds for subgraph ranking")
            state.ppr_result = None
            metrics.end_step(output_summary="no seeds")
            return

        result = await self._strategy.rank(
            config=self._config,
            graph_store=self._graph_store,
            seeds=seeds,
            query=state.query,
            answer_choices=state.choices,
            pruned_edges=pruned_edges,
        )

        state.ppr_result = result
        state.kg_context = result.subgraph_context if result else ""

        metrics.end_step(
            output_summary=f"{len(result.ranked_entities if result else [])} entities, {len(result.relevant_paths if result else [])} paths",
        )
        logger.info(
            f"Ranked {len(result.ranked_entities if result else [])} entities, "
            f"{len(result.relevant_paths if result else [])} paths"
        )


def create_ranking_strategy(strategy_name: str) -> SubgraphRankingStrategy:
    """Factory: create the appropriate ranking strategy.

    Args:
        strategy_name: One of "ppr", "nhops", "random_walk", "hybrid".

    Returns:
        Configured strategy instance.
    """
    strategies = {
        "ppr": PPRStrategy(),
        "nhops": NHopsStrategy(),
        "random_walk": RandomWalkStrategy(),
        "hybrid": HybridSemanticStrategy(),
    }
    return strategies.get(strategy_name, PPRStrategy())
