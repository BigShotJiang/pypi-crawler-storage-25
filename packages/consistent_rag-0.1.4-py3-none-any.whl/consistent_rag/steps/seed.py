"""Seed extraction step."""

from __future__ import annotations

from loguru import logger

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.common.models import IterationState
from consistent_rag.agents.seed.agent import create_seed_agent, run_seed_extraction
from consistent_rag.pipeline.hybrid_seed_retriever import HybridSeedRetriever
from consistent_rag.pipeline.models import PipelineIterationState


class SeedExtractionStep:
    """Extracts seed entities from query."""

    def __init__(
        self,
        agent=None,
        hybrid_retriever: HybridSeedRetriever | None = None,
        use_hybrid: bool = True,
        min_seed_score: float = 0.3,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._agent = agent or create_seed_agent(model, api_key, base_url)
        self._hybrid_retriever = hybrid_retriever
        self._use_hybrid = use_hybrid
        self._min_score = min_seed_score

    async def execute(
        self,
        state: PipelineIterationState,
        metrics: MetricsCollector,
    ) -> None:
        """Extract seeds and update state."""
        metrics.start_step("seed_extraction")

        iter_state = IterationState(
            iteration=state.iteration,
            query=state.query,
            choices=state.choices,
        )

        result = await run_seed_extraction(self._agent, iter_state)

        # Hybrid seed retrieval if enabled
        if self._use_hybrid and self._hybrid_retriever is not None:
            result = await self._hybrid_retriever.enhance(result)

        state.seeds = result
        metrics.set_seeds_count(len(result.seeds))
        metrics.end_step(
            input_summary=f"query={state.query[:80]}",
            output_summary=f"{len(result.seeds)} seeds",
        )
        logger.info(f"Extracted {len(result.seeds)} seeds: {result.seeds[:5]}")
