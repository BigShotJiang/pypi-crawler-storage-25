"""MCP server exposing ConsistentRAG as a callable tool.

Start with: python -m consistent_rag.mcp_server
"""

from __future__ import annotations

from typing import Any

from loguru import logger

try:
    from fastmcp import FastMCP

    FASTMCP_AVAILABLE = True
except ImportError:
    FASTMCP_AVAILABLE = False
    logger.error("fastmcp not installed. MCP server unavailable.")
    raise ImportError("fastmcp is required for the MCP server. Install with: pip install fastmcp")

mcp = FastMCP("ConsistentRAG")


@mcp.tool()
async def query(
    question: str,
    context: str | None = None,
    mode: str = "kg",
    strategy: str = "ppr",
    top_k: int = 5,
) -> dict[str, Any]:
    """Query ConsistentRAG with a question.

    Args:
        question: The question to answer.
        context: Optional pre-provided context. If given, skips retrieval.
        mode: Operational mode - "kg", "vector", "hybrid", "faiss", or "faiss_kg".
        strategy: Graph strategy - "ppr", "random_walk", "hybrid", or "nhops".
        top_k: Number of documents to retrieve.

    Returns:
        Dict with answer, confidence, reasoning_paths, seeds_used, etc.
    """
    if not question:
        return {"error": "question is required"}

    try:
        from .api import ConsistentRAG

        rag = ConsistentRAG(mode=mode, strategy=strategy)
        result = rag.query(question, context=context, top_k=top_k)

        return {
            "answer": result.answer,
            "confidence": result.confidence,
            "reasoning": result.reasoning,
            "reasoning_paths": result.reasoning_paths,
            "seeds_used": result.seeds_used,
            "triples_extracted": result.triples_extracted,
            "iterations_used": result.iterations_used,
            "final_score": result.final_score,
        }
    except Exception as e:
        logger.error(f"MCP query failed: {e}")
        return {"error": str(e)}


@mcp.tool()
async def get_kg_stats() -> dict[str, Any]:
    """Get current knowledge graph statistics."""
    try:
        from .api import ConsistentRAG

        rag = ConsistentRAG(mode="kg", strategy="ppr")
        return rag.get_kg_stats()
    except Exception as e:
        logger.error(f"MCP get_kg_stats failed: {e}")
        return {"error": str(e)}


def main():
    """Entry point for the MCP server."""

    mcp.run()


if __name__ == "__main__":
    main()
