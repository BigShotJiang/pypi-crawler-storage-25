"""Configuration for the ConsistentRAG pipeline."""

from __future__ import annotations

import os

from openai import AsyncAzureOpenAI, AsyncOpenAI
from pydantic import BaseModel, Field
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

from consistent_rag.config.relation_similarity import RelationSimilarityConfig
from consistent_rag.knowledge_graph.networkx_graph_store import GraphConfig
from consistent_rag.llm import _is_azure_endpoint, resolve_llm_credentials
from consistent_rag.retrievers import RetrieverConfig


class PipelineConfig(BaseModel):
    """Configuration for the ConsistentRAG pipeline.

    Attributes:
        model: LLM model name.
        api_key: Optional API key.
        base_url: Optional API base URL.
        max_improvement_iterations: Max refinement iterations.
        improvement_threshold: Critic score threshold.
        subgraph_strategy: Graph traversal strategy.
        ppr_alpha: PPR damping factor.
        ppr_iterations: Number of power iterations.
        max_paths: Maximum reasoning paths.
        use_vector: Whether to use vector retrieval.
        retriever_backend: Vector store backend ("faiss" or "qdrant").
        max_triples_per_doc: Max triples per document.
        build_kg_incrementally: Build KG during retrieval.
    """

    model: str = "gpt-4o-mini"
    api_key: str | None = None
    base_url: str | None = None

    # Improvement loop
    max_improvement_iterations: int = 3
    improvement_threshold: float = 0.8
    use_dynamic_critic_threshold: bool = False

    # Subgraph strategy
    subgraph_strategy: str = "ppr"  # ppr, nhops, random_walk, hybrid
    nhops_depth: int = 2

    # PPR settings
    ppr_alpha: float = 0.5
    ppr_iterations: int = 20
    min_seed_score: float = 0.3
    min_path_score: float = 0.5
    max_paths: int = 20
    path_relevance_threshold: float = 0.3
    path_max_hops: int = 3

    # Hybrid traversal
    hybrid_alpha: float = 0.5
    hybrid_max_hops: int = 3
    hybrid_top_k_per_hop: int = 10

    # Edge filtering for reasoning paths
    excluded_relations: list[str] = Field(
        default_factory=lambda: ["SIMILAR_TO"],
        description="Relation types to exclude from reasoning paths",
    )

    # Progressive expansion
    expansion_nhops_step: int = 1
    expansion_hybrid_hops_step: int = 1
    expansion_hybrid_topk_step: int = 5
    expansion_relevance_delta: float = 0.05
    expansion_max_paths_step: int = 5

    # Retriever and graph
    retriever_config: RetrieverConfig | None = None
    graph_config: GraphConfig | None = None
    use_vector: bool = True
    retriever_backend: str = "faiss"  # "faiss" or "qdrant"

    # Triple extraction
    max_triples_per_doc: int = 40
    build_kg_incrementally: bool = True

    # Hybrid seeds
    use_hybrid_seeds: bool = True
    seed_search_limit: int = 5
    seed_match_strategy: str = "faiss"
    seed_faiss_threshold: float = 0.85
    seed_max_total: int = 15

    # Refinement hyperparameters (fixed, zero-training)
    refinement_old_weight: float = 0.3
    refinement_query_weight: float = 0.5
    refinement_path_weight: float = 0.2
    pruned_suppression_factor: float = 0.05

    # Seed management
    seed_budget: int = 10
    lsh_candidates: int = 20
    faiss_candidates: int = 10
    new_seed_similarity_threshold: float = 0.7

    # Convergence
    stagnation_threshold: float = 0.85
    weight_delta_threshold: float = 0.01

    # Contradiction-aware refinement (simplified in C-GAPUD)
    relation_similarity_config: RelationSimilarityConfig = Field(
        default_factory=RelationSimilarityConfig
    )
    block_contradictions_permanently: bool = True
    max_contradiction_blocked_edges: int = 50

    # Query-aware weighting
    use_query_aware_weighting: bool = True
    query_aware_beta: float = 0.3

    def get_api_key(self) -> str:
        """Get API key using priority resolution."""
        key, _ = resolve_llm_credentials(api_key=self.api_key, base_url=self.base_url)
        return key

    def get_base_url(self) -> str:
        """Get base URL using priority resolution."""
        _, url = resolve_llm_credentials(api_key=self.api_key, base_url=self.base_url)
        return url

    def create_model(self):
        """Create a pydantic-ai model."""
        key, url = resolve_llm_credentials(api_key=self.api_key, base_url=self.base_url)

        if _is_azure_endpoint(url):
            azure_endpoint = url.rstrip("/")
            if azure_endpoint.endswith("/v1"):
                azure_endpoint = azure_endpoint[:-3]
            api_version = os.getenv("AZURE_API_VERSION", "2024-10-21")
            client = AsyncAzureOpenAI(
                api_key=key,
                azure_endpoint=azure_endpoint,
                api_version=api_version,
            )
        else:
            client = AsyncOpenAI(api_key=key, base_url=url)

        provider = OpenAIProvider(openai_client=client)
        return OpenAIChatModel(self.model, provider=provider)
