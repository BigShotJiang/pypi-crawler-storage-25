"""Context models for structured context building."""

from __future__ import annotations

from pydantic import BaseModel, Field

from consistent_rag.pipeline.models import PipelineIterationState


class PathStep(BaseModel):
    """A single step (edge) in a reasoning path through the graph."""

    subject: str
    predicate: str
    object: str
    score: float = 0.0

    def normalized_key(self) -> tuple[str, str, str]:
        """Return normalized key for deduplication."""
        return (self.subject.lower(), self.predicate.lower(), self.object.lower())


class StructuredContext(BaseModel):
    """Structured context for the answer agent."""

    documents: list[str] = Field(default_factory=list)
    ranked_entities: list[tuple[str, float]] = Field(default_factory=list)
    reasoning_paths: list[PathStep] = Field(default_factory=list)
    guidance: str = ""
    contradiction_header: str = ""

    @classmethod
    def from_state(
        cls, state: PipelineIterationState, max_paths: int | None = None
    ) -> StructuredContext:
        """Construct from PipelineIterationState after ranking."""
        documents = []
        if state.formatted_context:
            documents.append(state.formatted_context)

        ranked_entities = []
        paths = []

        if state.ppr_result:
            ranked_entities = list(state.ppr_result.ranked_entities[:10])
            seen_keys = set()
            for path_dict in state.ppr_result.relevant_paths:
                steps = path_dict.get("steps", [])
                entities = [s["name"] for s in steps if s.get("type") == "entity"]
                relations = [s["name"] for s in steps if s.get("type") == "relation"]
                for j in range(len(entities) - 1):
                    rel = relations[j] if j < len(relations) else "RELATED"
                    rp = PathStep(
                        subject=entities[j],
                        predicate=rel,
                        object=entities[j + 1],
                        score=path_dict.get("score", 0.0),
                    )
                    n_key = rp.normalized_key()
                    if n_key not in seen_keys:
                        seen_keys.add(n_key)
                        paths.append(rp)

            if max_paths is not None:
                paths = paths[:max_paths]

        return cls(
            documents=documents,
            ranked_entities=ranked_entities,
            reasoning_paths=paths,
        )

    def render(self) -> str:
        """Serialize to the prompt format the Answer Agent expects."""
        parts = []

        if self.contradiction_header:
            parts.append(self.contradiction_header)
            parts.append("")

        if self.documents:
            parts.append("=== Retrieved Documents ===")
            parts.append("\n".join(self.documents))

        if self.ranked_entities or self.reasoning_paths:
            parts.append("")
            parts.append("=== Knowledge Graph Context ===")

            if self.ranked_entities:
                parts.append("")
                parts.append("Top relevant entities:")
                for entity, score in self.ranked_entities[:5]:
                    parts.append(f"  - {entity} (relevance: {score:.3f})")

            if self.reasoning_paths:
                parts.append("")
                parts.append("Reasoning paths:")
                for i, path in enumerate(self.reasoning_paths, 1):
                    parts.append(f"  {i}. {path.subject} -[{path.predicate}]-> {path.object}")

        if self.guidance:
            parts.append(f"\n\nCRITIC GUIDANCE: {self.guidance}")

        return "\n".join(parts) if parts else ""
