"""ConsistentRAG Pipeline - graph-only execution via pydantic-graph.

This pipeline implements C-GAPUD (Critic-Guided Adaptive Path Utility Diffusion)
for iterative knowledge graph refinement.
"""

from __future__ import annotations

import asyncio

from loguru import logger
import numpy as np

from consistent_rag.agents.base import MetricsCollector
from consistent_rag.benchmarks.faitheval import FaithEvalSample
from consistent_rag.graph import build_pipeline_graph
from consistent_rag.graph.deps import PipelineDeps
from consistent_rag.graph.nodes import ExtractTriples
from consistent_rag.graph.state import PipelineGraphState
from consistent_rag.knowledge_graph.extractor import TripleExtractor
from consistent_rag.knowledge_graph.lsh_index import CosineLSH
from consistent_rag.knowledge_graph.networkx_graph_store import GraphConfig, NetworkXGraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import PipelineIterationState, PipelineResponse
from consistent_rag.retrievers import Document, RetrieverConfig, RetrieverFactory
from consistent_rag.steps import (
    AnswerGenerationStep,
    CriticStep,
    FaithEvalStep,
    RetrievalStep,
    SeedExtractionStep,
    SubgraphRankingStep,
    TripleExtractionStep,
)
from consistent_rag.steps.ranking import create_ranking_strategy
from consistent_rag.steps.refinement import CriticGuidedRefinementStep


class ConsistentRAGPipeline:
    """ConsistentRAG Pipeline with C-GAPUD refinement.

    Uses pydantic-graph for execution, exposing full iteration traces
    and subgraph evolution for visualization.
    """

    def __init__(self, config: PipelineConfig | None = None):
        if config is None:
            config = PipelineConfig()

        self.config = config
        self._loop: asyncio.AbstractEventLoop | None = None

        # Build components
        self._components = self._build_components(config)

        logger.info(
            f"Initialized ConsistentRAGPipeline with strategy={config.subgraph_strategy}, "
            f"max_iterations={config.max_improvement_iterations}"
        )

    def _build_components(self, config: PipelineConfig) -> dict:
        """Build all pipeline components from config."""
        # Retriever
        retriever = None
        if config.use_vector:
            retriever_config = config.retriever_config or RetrieverConfig()
            retriever_config = retriever_config.model_copy(
                update={"backend": config.retriever_backend}
            )
            retriever = RetrieverFactory.create(retriever_config)

        # Graph store
        graph_config = config.graph_config or GraphConfig()
        graph_store = NetworkXGraphStore(graph_config)

        # Triple extractor
        triple_extractor = TripleExtractor(model=config.create_model())

        # Embedding service
        embedding_service = graph_store.embedding_service

        # Agents
        model = config.model
        api_key = config.api_key
        base_url = config.base_url

        # Steps
        retrieval_step = RetrievalStep(
            retriever=retriever,
            use_vector=config.use_vector,
            model=model,
            api_key=api_key,
            base_url=base_url,
        )
        triple_step = TripleExtractionStep(
            triple_extractor, graph_store, config.max_triples_per_doc
        )
        seed_step = SeedExtractionStep(
            model=model,
            api_key=api_key,
            base_url=base_url,
        )

        ranking_strategy = create_ranking_strategy(config.subgraph_strategy)
        ranking_step = SubgraphRankingStep(ranking_strategy, config, graph_store)

        answer_step = AnswerGenerationStep(
            model=model,
            api_key=api_key,
            base_url=base_url,
        )

        critic_step = CriticStep(
            threshold=config.improvement_threshold,
            model=model,
            api_key=api_key,
            base_url=base_url,
        )

        # Create LSH index for triple embeddings
        lsh_index = None
        if embedding_service:
            try:
                # Get embedding dimension from the service
                sample_emb = embedding_service.embed("test")
                emb_dim = len(sample_emb) if hasattr(sample_emb, "__len__") else 384
                lsh_index = CosineLSH(embedding_dim=emb_dim, num_bits=128)
                graph_store._lsh_index = lsh_index
                logger.info(f"Created LSH index with dim={emb_dim}")
            except Exception as e:
                logger.warning(f"Failed to create LSH index: {e}")

        refinement_step = CriticGuidedRefinementStep(
            graph_store=graph_store,
            embedding_service=embedding_service,
            lsh_index=lsh_index,
            max_new_seeds=5,
            seed_budget=config.seed_budget,
            alpha=config.refinement_old_weight,
            beta=config.refinement_query_weight,
            gamma=config.refinement_path_weight,
            pruned_suppression=config.pruned_suppression_factor,
            new_seed_similarity_threshold=config.new_seed_similarity_threshold,
            stagnation_threshold=config.stagnation_threshold,
            weight_delta_threshold=config.weight_delta_threshold,
        )

        faitheval_step = FaithEvalStep(
            model=model,
            api_key=api_key,
            base_url=base_url,
        )

        return {
            "retrieval_step": retrieval_step,
            "triple_step": triple_step,
            "seed_step": seed_step,
            "ranking_step": ranking_step,
            "answer_step": answer_step,
            "critic_step": critic_step,
            "refinement_step": refinement_step,
            "faitheval_step": faitheval_step,
            "graph_store": graph_store,
            "retriever": retriever,
            "triple_extractor": triple_extractor,
            "lsh_index": lsh_index,
        }

    def index_documents(
        self,
        documents: list[Document],
        recreate: bool = False,
        build_kg: bool = True,
    ) -> None:
        """Index documents into vector store and optionally build KG."""
        graph_store = self._components["graph_store"]
        retriever = self._components["retriever"]

        # Index in vector store
        if retriever is not None:
            retriever.create_collection(recreate=recreate)
            retriever.add_documents(documents)
            logger.info(f"Indexed {len(documents)} documents in vector store")

        # Build KG
        if build_kg:
            if recreate:
                graph_store.clear()

            total_triples = 0
            for doc in documents:
                triples = self._components["triple_extractor"].extract(
                    doc.text, max_triples=self.config.max_triples_per_doc
                )
                if triples:
                    graph_store.add_triples(triples)
                    total_triples += len(triples)

            logger.info(f"Built KG with {total_triples} triples")

            # Populate LSH index with edge embeddings
            lsh_index = self._components.get("lsh_index")
            if lsh_index is not None:
                self._populate_lsh_index(graph_store, lsh_index)

    def _populate_lsh_index(self, graph_store, lsh_index) -> None:
        """Populate LSH index with edge embeddings from the graph."""
        count = 0
        for u, v, data in graph_store.graph.edges(data=True):
            emb = data.get("embedding")
            if emb is not None:
                triple_id = f"{u}|{data.get('type', 'RELATED')}|{v}"
                lsh_index.insert(triple_id, np.array(emb, dtype=np.float32))
                count += 1
        if count > 0:
            stats = lsh_index.get_stats()
            logger.info(
                f"Populated LSH index with {count} triples, "
                f"{stats['num_buckets_used']} buckets used"
            )

    async def query(
        self,
        query: str,
        top_k: int = 5,
        choices: list[str] | None = None,
    ) -> PipelineResponse:
        """Run the ConsistentRAG pipeline (async).

        Args:
            query: The user's question.
            top_k: Number of documents to retrieve.
            choices: Optional multiple-choice options.

        Returns:
            PipelineResponse with answer and full evolution history.
        """
        return await self._run_graph_pipeline(query, top_k=top_k, choices=choices)

    def query_sync(
        self,
        query: str,
        top_k: int = 5,
        choices: list[str] | None = None,
    ) -> PipelineResponse:
        """Run the ConsistentRAG pipeline (sync)."""
        return self._get_or_create_loop().run_until_complete(
            self.query(query, top_k=top_k, choices=choices)
        )

    async def query_without_retrieval(
        self,
        query: str,
        context: str,
        sample: FaithEvalSample | None = None,
        choices: list[str] | None = None,
    ) -> PipelineResponse:
        """Run with provided context (no retrieval)."""
        return await self._run_graph_pipeline(
            query, context=context, choices=choices, sample=sample
        )

    def query_without_retrieval_sync(
        self,
        query: str,
        context: str,
        sample: FaithEvalSample | None = None,
        choices: list[str] | None = None,
    ) -> PipelineResponse:
        """Run with provided context (sync)."""
        return self._get_or_create_loop().run_until_complete(
            self.query_without_retrieval(query, context, sample=sample, choices=choices)
        )

    async def _run_graph_pipeline(
        self,
        query: str,
        context: str | None = None,
        top_k: int = 5,
        choices: list[str] | None = None,
        sample: FaithEvalSample | None = None,
    ) -> PipelineResponse:
        """Run the pipeline using pydantic-graph."""
        components = self._components

        deps = PipelineDeps(
            config=self.config,
            retrieval_step=components["retrieval_step"],
            triple_step=components["triple_step"],
            seed_step=components["seed_step"],
            ranking_step=components["ranking_step"],
            answer_step=components["answer_step"],
            critic_step=components["critic_step"],
            refinement_step=components["refinement_step"],
            graph_store=components["graph_store"],
        )

        metrics = MetricsCollector(
            "consistent_rag",
            use_vector=self.config.use_vector,
            use_kg=True,
            subgraph_strategy=self.config.subgraph_strategy,
        )

        state = PipelineIterationState(
            query=query,
            choices=[str(c).strip() for c in (choices or []) if str(c).strip()],
        )

        if context is not None:
            state.formatted_context = context
            state.retrieved_docs = []
        else:
            await components["retrieval_step"].execute(state, metrics, top_k)

        graph_state = PipelineGraphState(
            iteration_state=state,
            metrics=metrics,
        )

        pipeline_graph = build_pipeline_graph()
        result = await pipeline_graph.run(
            ExtractTriples(),
            state=graph_state,
            deps=deps,
        )

        # Store full graph state for inspection (includes iteration history, snapshots, etc.)
        self._last_graph_state = result.state
        return result.output

    def get_kg_stats(self) -> dict:
        """Get knowledge graph statistics."""
        return self._components["graph_store"].get_stats()

    def close(self) -> None:
        """Clean up resources."""
        self._components["graph_store"].close()
        if self._loop and not self._loop.is_closed():
            try:
                self._loop.close()
            except RuntimeError:
                pass

    def _get_or_create_loop(self):
        """Get or create a persistent event loop for sync wrappers."""
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop
