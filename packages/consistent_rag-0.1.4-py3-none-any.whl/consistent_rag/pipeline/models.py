"""Models for the ConsistentRAG pipeline."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from consistent_rag.agents.common.models import AnswerWithCitations, RouteDecision
from consistent_rag.agents.critic.agent import StructuredCriticFeedback
from consistent_rag.agents.state import PipelineState
from consistent_rag.knowledge_graph.extractor import Triple
from consistent_rag.retrievers import Document


class PPRResult(BaseModel):
    """Result from subgraph ranking execution."""

    ranked_entities: list[tuple[str, float]] = Field(
        default_factory=list, description="Entities ranked by score"
    )
    relevant_paths: list[dict] = Field(
        default_factory=list, description="Reasoning paths between top entities"
    )
    subgraph_context: str = Field(default="", description="Formatted context from subgraph")


class SeedExtractionResult(BaseModel):
    """Result from seed entity extraction."""

    seeds: list[str] = Field(description="Entity names to use as seeds")
    scores: list[float] = Field(description="Relevance scores for each seed")
    reasoning: str = Field(description="Explanation for seed selection")
    source_type: list[str] = Field(
        default_factory=list,
        description="Source of each seed: 'llm', 'graph_match', 'graph_neighbor'",
    )
    graph_matched: int = Field(default=0, description="Count of seeds matched in graph")


class PipelineIterationState(BaseModel):
    """State tracking for one pipeline iteration."""

    iteration: int = 0
    query: str
    choices: list[str] = Field(default_factory=list)

    # Seeds
    seeds: SeedExtractionResult | None = None

    # Routing and retrieval
    route_decision: RouteDecision | None = None
    retrieved_docs: list[Document] = Field(default_factory=list)
    formatted_context: str = ""

    # Triples
    extracted_triples: list[Triple] = Field(default_factory=list)

    # PPR results
    ppr_result: PPRResult | None = None
    kg_context: str = ""

    # Combined context
    combined_context: str = ""

    # Answer and feedback
    answer: AnswerWithCitations | None = None
    critic_feedback: StructuredCriticFeedback | None = None

    # Convergence
    converged: bool = False

    # Graph reference (for refinement)
    graph: Any | None = None

    # Path history for convergence checking
    reasoning_paths_history: list[list[dict]] = Field(default_factory=list)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class PipelineResponse(BaseModel):
    """Final response from the ConsistentRAG pipeline."""

    query: str
    answer: str
    reasoning: str = ""
    prompt_used: str = ""
    context: str
    kg_context: str
    citations: list[int]
    kg_citations: list[str]
    confidence: float
    iterations_used: int
    final_score: float
    seeds_used: list[str] = Field(default_factory=list)
    triples_extracted: int = 0
    ppr_entities: list[tuple[str, float]] = Field(default_factory=list)
    ppr_paths: list[dict] = Field(default_factory=list)
    improvement_history: list[Any] = Field(default_factory=list)
    unresolved_issues: list[str] = Field(default_factory=list)
    iteration_traces: list[Any] = Field(default_factory=list)
    all_unused_triples: list[dict] = Field(default_factory=list)
    converged: bool = False
    pipeline_state: PipelineState | None = None

    model_config = ConfigDict(arbitrary_types_allowed=True)
