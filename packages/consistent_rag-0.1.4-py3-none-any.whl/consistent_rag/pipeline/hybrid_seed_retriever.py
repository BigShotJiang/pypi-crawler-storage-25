"""Hybrid Seed Retriever - Graph-aware seed extraction with FAISS semantic matching.

Architecture:
- Strategy pattern for entity matching (exact, substring, FAISS, hybrid)
- Builder pattern for seed assembly
- Facade (HybridSeedRetriever) orchestrates the flow

Flow:
1. LLM extracts candidate entities from query (via seed_agent.run_seed_extraction)
2. Each candidate is matched to graph entities using the configured strategy
3. Matched entities are boosted; unmatched LLM candidates may be included as fallback
4. Final seed list is sorted, filtered, and capped
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from loguru import logger

from consistent_rag.agents.seed.agent import create_seed_agent, run_seed_extraction
from consistent_rag.knowledge_graph.graph_store import GraphStore
from consistent_rag.pipeline.config import PipelineConfig
from consistent_rag.pipeline.models import SeedExtractionResult

# =============================================================================
# Data structures
# =============================================================================


@dataclass(frozen=True)
class MatchedEntity:
    """A graph entity matched to an LLM candidate."""

    name: str
    score: float
    match_type: str  # "exact", "substring", "faiss"


# =============================================================================
# Strategy: Entity matching
# =============================================================================


class EntityMatcher(Protocol):
    """Strategy for matching an LLM candidate to graph entities."""

    def match(self, candidate: str, graph_store: GraphStore) -> list[MatchedEntity]:
        """Match a candidate to graph entities.

        Args:
            candidate: LLM-extracted entity candidate
            graph_store: Graph store with search capabilities

        Returns:
            List of matched graph entities, sorted by score descending
        """
        ...


class FAISSMatcher:
    """Match candidates to graph entities using FAISS semantic similarity."""

    def __init__(self, threshold: float = 0.85, top_k: int = 5) -> None:
        self.threshold = threshold
        self.top_k = top_k

    def match(self, candidate: str, graph_store: GraphStore) -> list[MatchedEntity]:
        """Find graph entities semantically similar to candidate.

        Only returns entities with cosine similarity >= threshold.
        """
        results: list[MatchedEntity] = []
        seen: set[str] = set()

        try:
            similar = graph_store.find_similar_entities(candidate, top_k=self.top_k)
        except Exception as e:
            logger.warning(f"FAISS search failed for '{candidate}': {e}")
            return results

        for name, score in similar:
            if score < self.threshold:
                continue
            if name in seen:
                continue
            seen.add(name)
            results.append(MatchedEntity(name=name, score=score, match_type="faiss"))

        # Respect top_k after filtering
        return results[: self.top_k]


class ExactMatcher:
    """Match candidates via case-insensitive exact match."""

    def match(self, candidate: str, graph_store: GraphStore) -> list[MatchedEntity]:
        """Find exact matches in graph."""
        results: list[MatchedEntity] = []

        try:
            entity = graph_store.get_entity_by_name(candidate)
        except Exception:
            entity = None

        if entity is not None:
            results.append(MatchedEntity(name=candidate, score=1.0, match_type="exact"))

        return results


class SubstringMatcher:
    """Match candidates via substring search."""

    def __init__(self, limit: int = 5) -> None:
        self.limit = limit

    def match(self, candidate: str, graph_store: GraphStore) -> list[MatchedEntity]:
        """Find entities containing candidate as substring."""
        results: list[MatchedEntity] = []

        try:
            found = graph_store.search_entities(candidate, limit=self.limit)
        except Exception:
            return results

        for entity in found:
            name = entity.get("name", "")
            score = entity.get("score", 0.8)
            if name:
                results.append(MatchedEntity(name=name, score=score, match_type="substring"))

        return results


class HybridMatcher:
    """Try exact → substring → FAISS, return best unique matches."""

    def __init__(self, faiss_threshold: float = 0.85, faiss_top_k: int = 5) -> None:
        self.exact = ExactMatcher()
        self.substring = SubstringMatcher()
        self.faiss = FAISSMatcher(threshold=faiss_threshold, top_k=faiss_top_k)

    def match(self, candidate: str, graph_store: GraphStore) -> list[MatchedEntity]:
        """Find matches using cascading strategies."""
        # Try exact first
        exact_results = self.exact.match(candidate, graph_store)
        if exact_results:
            return exact_results

        # Try substring
        substring_results = self.substring.match(candidate, graph_store)
        if substring_results:
            return substring_results

        # Fall back to FAISS
        return self.faiss.match(candidate, graph_store)


def create_matcher(config: PipelineConfig) -> EntityMatcher:
    """Factory: create the appropriate matcher from config."""
    strategy = config.seed_match_strategy.lower()

    if strategy == "exact":
        return ExactMatcher()
    elif strategy == "substring":
        return SubstringMatcher(limit=config.seed_search_limit)
    elif strategy == "faiss":
        return FAISSMatcher(
            threshold=config.seed_faiss_threshold,
            top_k=config.seed_search_limit,
        )
    elif strategy == "hybrid":
        return HybridMatcher(
            faiss_threshold=config.seed_faiss_threshold,
            faiss_top_k=config.seed_search_limit,
        )
    else:
        logger.warning(f"Unknown match strategy '{strategy}', defaulting to FAISS")
        return FAISSMatcher(
            threshold=config.seed_faiss_threshold,
            top_k=config.seed_search_limit,
        )


# =============================================================================
# Builder: Seed assembly
# =============================================================================


class SeedAssembler:
    """Builds the final seed list from matched and unmatched candidates.

    Enforces:
    - Unique entities only
    - Score boosting for graph matches
    - Score penalty for LLM-only fallback
    - Hard cap on total seeds
    - Descending sort by score
    - Min score filtering
    """

    def __init__(self, config: PipelineConfig) -> None:
        self._config = config
        self._entries: list[tuple[str, float, str]] = []  # (name, score, source)
        self._seen: set[str] = set()

    def add_graph_matches(self, matches: list[MatchedEntity]) -> "SeedAssembler":
        """Add graph-matched entities with boost."""
        for match in matches:
            if match.name in self._seen:
                continue
            self._seen.add(match.name)

            # Apply graph match boost, cap at 1.0
            boosted = min(1.0, match.score + getattr(self._config, "seed_graph_match_boost", 0.1))
            self._entries.append((match.name, boosted, "graph_match"))

        return self

    def add_llm_fallback(self, candidates: list[str], scores: list[float]) -> "SeedAssembler":
        """Add unmatched LLM candidates with penalty (if enabled)."""
        if not getattr(self._config, "seed_enable_llm_fallback", False):
            return self

        for candidate, score in zip(candidates, scores):
            if candidate in self._seen:
                continue
            self._seen.add(candidate)

            # Apply penalty
            penalized = max(0.0, score - getattr(self._config, "seed_llm_fallback_penalty", 0.2))
            self._entries.append((candidate, penalized, "llm"))

        return self

    def build(self, min_score: float) -> SeedExtractionResult:
        """Assemble final seed list."""
        # Sort by score descending
        sorted_entries = sorted(self._entries, key=lambda x: x[1], reverse=True)

        # Apply hard cap
        capped = sorted_entries[: self._config.seed_max_total]

        # Filter by min_score
        final = [(name, score, source) for name, score, source in capped if score >= min_score]

        if not final:
            return SeedExtractionResult(
                seeds=[], scores=[], reasoning="", source_type=[], graph_matched=0
            )

        seeds, scores, sources = zip(*final)
        graph_matched = sum(1 for s in sources if s == "graph_match")

        return SeedExtractionResult(
            seeds=list(seeds),
            scores=list(scores),
            reasoning="",  # Filled in by caller
            source_type=list(sources),
            graph_matched=graph_matched,
        )


# =============================================================================
# Facade: HybridSeedRetriever
# =============================================================================


class HybridSeedRetriever:
    """Graph-aware seed extraction using FAISS semantic matching.

    Orchestrates:
    1. LLM candidate extraction (via seed_agent)
    2. Graph entity matching (via configured strategy)
    3. Seed assembly (with boosting, penalties, caps)

    No neighbors are included — seeds must be directly related to the query,
    not derived from graph context (prevents information leakage).
    """

    def __init__(self, graph_store: GraphStore, config: PipelineConfig) -> None:
        """Initialize hybrid seed retriever.

        Args:
            graph_store: Graph store with FAISS/search capabilities
            config: Pipeline configuration
        """
        self.graph_store = graph_store
        self.config = config
        self._matcher = create_matcher(config)
        self._seed_agent = create_seed_agent(config.model, config.api_key, config.base_url)

    async def extract_seeds(
        self,
        query: str,
        min_score: float = 0.3,
    ) -> SeedExtractionResult:
        """Extract seeds using hybrid approach.

        Flow:
        0. Direct semantic search: embed query, search graph node embeddings
        1. LLM extracts candidate entities from query
        2. Match each candidate to graph entities (FAISS/substring/exact)
        3. Merge both sources, deduplicate, boost graph matches
        4. Assemble final seed list with caps and filtering

        Phase 0 guarantees graph entities when embeddings exist, even if the
        LLM fails or returns no candidates.

        Args:
            query: User query to extract entities from
            min_score: Minimum relevance score for inclusion

        Returns:
            SeedExtractionResult with graph-matched seeds
        """
        # =====================================================================
        # Phase 0: Direct semantic graph search (guaranteed graph entities)
        # =====================================================================
        logger.debug("[HybridSeed] Phase 0: Direct semantic graph search...")
        semantic_matches: list[MatchedEntity] = []

        if self.graph_store.embedding_service is not None:
            try:
                semantic_matches = self._semantic_search_with_retry(query)
                logger.debug(
                    f"[HybridSeed] Phase 0: found {len(semantic_matches)} "
                    f"semantic matches from graph"
                )
            except Exception as e:
                logger.warning(f"[HybridSeed] Phase 0 semantic search failed: {e}")
        else:
            logger.debug("[HybridSeed] Phase 0: no embedding service, skipping")

        # =====================================================================
        # Phase 1: LLM candidate extraction
        # =====================================================================
        logger.debug("[HybridSeed] Phase 1: LLM candidate extraction...")
        llm_seeds: list[str] = []
        llm_scores: list[float] = []
        llm_reasoning: str = ""

        try:
            from consistent_rag.agents.common.models import IterationState

            iter_state = IterationState(iteration=0, query=query, choices=[])
            llm_result = await run_seed_extraction(
                agent=self._seed_agent,
                state=iter_state,
            )
            llm_seeds = llm_result.seeds
            llm_scores = llm_result.scores
            llm_reasoning = llm_result.reasoning
            logger.debug(f"[HybridSeed] Phase 1: LLM returned {len(llm_seeds)} candidates")
        except Exception as e:
            logger.warning(
                f"[HybridSeed] Phase 1 LLM extraction failed: {e}. "
                f"Falling back to semantic-only seeds."
            )

        # =====================================================================
        # Phase 2: Match LLM candidates to graph
        # =====================================================================
        logger.debug("[HybridSeed] Phase 2: LLM candidate graph matching...")
        llm_matches: list[MatchedEntity] = []
        matched_candidates: set[str] = set()

        if llm_seeds:
            # Cap: N candidates + 1
            max_matches = len(llm_seeds) + 1
            matches_remaining = max_matches

            for candidate in llm_seeds:
                if matches_remaining <= 0:
                    break

                matches = self._matcher.match(candidate, self.graph_store)
                for match in matches:
                    if matches_remaining <= 0:
                        break
                    if match.name not in {m.name for m in llm_matches}:
                        llm_matches.append(match)
                        matches_remaining -= 1

                if matches:
                    matched_candidates.add(candidate)

            logger.debug(
                f"[HybridSeed] Phase 2: matched {len(llm_matches)} graph entities "
                f"from {len(llm_seeds)} candidates (cap={max_matches})"
            )

        # =====================================================================
        # Phase 3: Merge sources and assemble
        # =====================================================================
        logger.debug("[HybridSeed] Phase 3: Seed assembly...")

        # Semantic matches take priority (guaranteed graph entities)
        all_matches = list(semantic_matches)
        seen_names = {m.name for m in all_matches}

        # Add LLM-matched entities (deduplicated)
        for match in llm_matches:
            if match.name not in seen_names:
                all_matches.append(match)
                seen_names.add(match.name)

        assembler = SeedAssembler(self.config)
        assembler.add_graph_matches(all_matches)

        # Add unmatched LLM candidates as fallback (if enabled)
        if llm_seeds:
            unmatched = [
                (cand, score)
                for cand, score in zip(llm_seeds, llm_scores)
                if cand not in matched_candidates
            ]
            if unmatched:
                candidates, scores = zip(*unmatched)
                assembler.add_llm_fallback(list(candidates), list(scores))

        result = assembler.build(min_score)
        result.reasoning = llm_reasoning

        total_semantic = len(semantic_matches)
        total_llm_matched = len(llm_matches)
        logger.info(
            f"[HybridSeed] Final: {len(result.seeds)} seeds "
            f"({result.graph_matched} graph-matched: "
            f"{total_semantic} semantic + {total_llm_matched} LLM-matched)"
        )

        return result

    def _semantic_search_with_retry(
        self,
        query: str,
        min_threshold: float = 0.3,
        step: float = 0.1,
    ) -> list[MatchedEntity]:
        """Search graph embeddings with progressive threshold reduction.

        Starts at the configured threshold and lowers it until we find
        at least one match or hit the minimum.

        Args:
            query: Query text to embed and search
            min_threshold: Absolute minimum similarity threshold
            step: Amount to reduce threshold per retry

        Returns:
            List of MatchedEntity from the best attempt
        """
        threshold = self.config.seed_faiss_threshold
        best_matches: list[MatchedEntity] = []

        while threshold >= min_threshold:
            matches: list[MatchedEntity] = []
            try:
                similar = self.graph_store.find_similar_entities(
                    query, top_k=self.config.seed_search_limit
                )
                for name, score in similar:
                    if score >= threshold:
                        matches.append(
                            MatchedEntity(name=name, score=score, match_type="semantic")
                        )
            except Exception as e:
                logger.debug(f"[HybridSeed] Semantic search at {threshold:.2f} failed: {e}")

            if matches:
                logger.debug(
                    f"[HybridSeed] Semantic search succeeded at threshold={threshold:.2f} "
                    f"with {len(matches)} matches"
                )
                return matches

            best_matches = matches if len(matches) > len(best_matches) else best_matches
            logger.debug(
                f"[HybridSeed] No semantic matches at threshold={threshold:.2f}, "
                f"retrying at {max(min_threshold, threshold - step):.2f}"
            )
            threshold -= step

        # Return the best attempt even if empty
        return best_matches
