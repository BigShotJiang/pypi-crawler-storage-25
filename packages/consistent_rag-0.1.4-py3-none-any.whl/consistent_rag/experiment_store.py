"""PostgreSQL-backed experiment result storage with retry/resume.

Provides atomic, upsertable storage for experiment runs and individual
evaluation results. Supports both sync and async interfaces via psycopg3.
"""

import csv
import json
from pathlib import Path
from typing import Any
import uuid

from loguru import logger

# ---------------------------------------------------------------------------
# SQL constants
# ---------------------------------------------------------------------------

_CREATE_RUNS_TABLE = """
CREATE TABLE IF NOT EXISTS experiment_runs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL,
    strategy      TEXT NOT NULL,
    created_at    TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    config_json   JSONB DEFAULT '{}',
    status        TEXT DEFAULT 'pending'
                  CHECK (status IN ('pending','running','completed','failed')),
    updated_at    TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
"""

_CREATE_RESULTS_TABLE = """
CREATE TABLE IF NOT EXISTS experiment_results (
    id                         SERIAL PRIMARY KEY,
    run_id                     UUID NOT NULL REFERENCES experiment_runs(id) ON DELETE CASCADE,
    strategy                   TEXT NOT NULL,
    benchmark_name             TEXT,
    conflict_type              TEXT,
    sample_id                  TEXT NOT NULL,
    question                   TEXT,
    ground_truth               TEXT,
    prediction                 TEXT,
    reasoning                  TEXT,
    answer_label               TEXT,
    selected_choice            TEXT,
    exact_match                BOOLEAN,
    f1                         FLOAT8,
    faithfulness_basic         FLOAT8,
    faithfulness_llm           FLOAT8,
    faithfulness_deepeval      FLOAT8,
    faithfulness_claim         FLOAT8,
    conflict_detection_correct BOOLEAN,
    justification_similarity   FLOAT8,
    seeds_used                 JSONB,
    ppr_entities               JSONB,
    ppr_paths                  JSONB,
    latency_ms                 INT,
    llm_calls                  INT,
    error                      TEXT,
    created_at                 TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at                 TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(run_id, strategy, benchmark_name, sample_id)
);
"""

_CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_results_run_id ON experiment_results(run_id);",
    "CREATE INDEX IF NOT EXISTS idx_results_strategy_sample ON experiment_results(strategy, sample_id);",
    "CREATE INDEX IF NOT EXISTS idx_results_conflict ON experiment_results(run_id, conflict_type);",
    "CREATE INDEX IF NOT EXISTS idx_results_benchmark ON experiment_results(run_id, benchmark_name);",
]

# Ordered column list for INSERT (excluding id, created_at, updated_at)
_RESULT_COLUMNS = [
    "run_id",
    "strategy",
    "benchmark_name",
    "conflict_type",
    "sample_id",
    "question",
    "ground_truth",
    "prediction",
    "reasoning",
    "answer_label",
    "selected_choice",
    "exact_match",
    "f1",
    "faithfulness_basic",
    "faithfulness_llm",
    "faithfulness_deepeval",
    "faithfulness_claim",
    "conflict_detection_correct",
    "justification_similarity",
    "seeds_used",
    "ppr_entities",
    "ppr_paths",
    "latency_ms",
    "llm_calls",
    "error",
]

# Columns that are JSONB and need json.dumps
_JSONB_COLUMNS = {"seeds_used", "ppr_entities", "ppr_paths"}

# Columns to update on upsert (everything except the unique key triple)
_UPSERT_SET_COLUMNS = [
    c for c in _RESULT_COLUMNS if c not in ("run_id", "strategy", "benchmark_name", "sample_id")
]


def _build_upsert_sql() -> str:
    """Build the parameterised upsert SQL once at import time."""
    cols = ", ".join(_RESULT_COLUMNS)
    placeholders = ", ".join([f"%({c})s" for c in _RESULT_COLUMNS])
    updates = ", ".join([f"{c} = EXCLUDED.{c}" for c in _UPSERT_SET_COLUMNS])
    return f"""
        INSERT INTO experiment_results ({cols})
        VALUES ({placeholders})
        ON CONFLICT (run_id, strategy, benchmark_name, sample_id) DO UPDATE SET
            {updates},
            updated_at = CURRENT_TIMESTAMP
    """


_UPSERT_SQL = _build_upsert_sql()

_AGGREGATE_SQL = """
    SELECT
        COUNT(*)                                          AS total_results,
        COUNT(*) FILTER (WHERE error IS NOT NULL)         AS error_count,
        COUNT(*) FILTER (WHERE error IS NULL)             AS success_count,
        AVG(exact_match::INT)                             AS accuracy,
        AVG(f1)                                           AS avg_f1,
        AVG(faithfulness_basic)                           AS avg_faithfulness_basic,
        AVG(faithfulness_llm)                             AS avg_faithfulness_llm,
        AVG(faithfulness_deepeval)                        AS avg_faithfulness_deepeval,
        AVG(faithfulness_claim)                           AS avg_faithfulness_claim,
        AVG(conflict_detection_correct::INT)              AS conflict_detection_accuracy,
        AVG(justification_similarity)                     AS avg_justification_similarity,
        AVG(latency_ms)                                   AS avg_latency_ms,
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY latency_ms) AS median_latency_ms,
        MAX(latency_ms)                                   AS max_latency_ms,
        SUM(llm_calls)                                    AS total_llm_calls,
        MAX(created_at)                                   AS last_updated
    FROM experiment_results
    WHERE run_id = %(run_id)s
"""

_AGGREGATE_BY_CONFLICT_SQL = """
    SELECT
        conflict_type,
        COUNT(*)                                          AS num_samples,
        COUNT(*) FILTER (WHERE error IS NOT NULL)         AS error_count,
        AVG(exact_match::INT)                             AS accuracy,
        AVG(f1)                                           AS avg_f1,
        AVG(faithfulness_basic)                           AS avg_faithfulness_basic,
        AVG(faithfulness_llm)                             AS avg_faithfulness_llm,
        AVG(conflict_detection_correct::INT)              AS conflict_detection_accuracy,
        AVG(justification_similarity)                     AS avg_justification_similarity,
        AVG(latency_ms)                                   AS avg_latency_ms,
        SUM(llm_calls)                                    AS total_llm_calls
    FROM experiment_results
    WHERE run_id = %(run_id)s
    GROUP BY conflict_type
    ORDER BY conflict_type
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _prepare_params(run_id: str, result_dict: dict[str, Any]) -> dict[str, Any]:
    """Build the named-parameter dict for the upsert query."""
    params: dict[str, Any] = {"run_id": run_id}
    for col in _RESULT_COLUMNS:
        if col == "run_id":
            continue
        val = result_dict.get(col)
        if col in _JSONB_COLUMNS and val is not None:
            val = json.dumps(val)
        params[col] = val
    return params


def _rows_to_dicts(cursor) -> list[dict[str, Any]]:
    """Convert cursor rows + description into a list of dicts."""
    if cursor.description is None:
        return []
    cols = [d.name for d in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# ExperimentStore  (sync)
# ---------------------------------------------------------------------------


class ExperimentStore:
    """PostgreSQL-backed experiment result storage with retry/resume.

    Uses psycopg 3 ``ConnectionPool`` for thread-safe connection reuse.
    Tables are created lazily on first access (idempotent).

    Usage::

        with ExperimentStore("postgresql://...") as store:
            run_id = store.create_run("exp1", "baseline", {"limit": 100})
            store.save_result(run_id, {"sample_id": "s1", "strategy": "baseline", ...})
            completed = store.get_completed_samples(run_id)
            store.export_csv(run_id, Path("results.csv"))
    """

    def __init__(self, postgres_url: str, *, pool_size: int = 5) -> None:
        from psycopg_pool import ConnectionPool

        self._pool = ConnectionPool(
            conninfo=postgres_url,
            min_size=1,
            max_size=pool_size,
            open=True,
        )
        self._tables_ready = False

    # -- lifecycle -----------------------------------------------------------

    def _ensure_tables(self) -> None:
        if self._tables_ready:
            return
        with self._pool.connection() as conn:
            conn.execute(_CREATE_RUNS_TABLE)
            conn.execute(_CREATE_RESULTS_TABLE)
            for idx_sql in _CREATE_INDEXES:
                conn.execute(idx_sql)
            conn.commit()
        self._tables_ready = True
        logger.info("Experiment tables initialised")

    def close(self) -> None:
        """Close the connection pool."""
        self._pool.close()
        logger.info("ExperimentStore pool closed")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    # -- runs ----------------------------------------------------------------

    def create_run(
        self,
        name: str,
        strategy: str,
        config: dict | None = None,
    ) -> str:
        """Create a new experiment run, return its UUID."""
        self._ensure_tables()
        run_id = str(uuid.uuid4())
        with self._pool.connection() as conn:
            conn.execute(
                """INSERT INTO experiment_runs (id, name, strategy, config_json, status)
                   VALUES (%(id)s, %(name)s, %(strategy)s, %(config)s, 'running')""",
                {
                    "id": run_id,
                    "name": name,
                    "strategy": strategy,
                    "config": json.dumps(config or {}),
                },
            )
            conn.commit()
        logger.info(f"Created run {run_id} ({name}/{strategy})")
        return run_id

    def update_run_status(self, run_id: str, status: str) -> None:
        """Update the status of an experiment run."""
        with self._pool.connection() as conn:
            conn.execute(
                """UPDATE experiment_runs
                   SET status = %(status)s, updated_at = CURRENT_TIMESTAMP
                   WHERE id = %(id)s""",
                {"id": run_id, "status": status},
            )
            conn.commit()

    # -- results -------------------------------------------------------------

    def save_result(self, run_id: str, result_dict: dict[str, Any]) -> None:
        """Upsert one evaluation result (atomic).

        ``result_dict`` must contain ``sample_id`` and ``strategy``.
        On conflict the existing row is updated.
        """
        if "sample_id" not in result_dict or "strategy" not in result_dict:
            raise ValueError("result_dict must contain 'sample_id' and 'strategy'")

        self._ensure_tables()
        params = _prepare_params(run_id, result_dict)
        with self._pool.connection() as conn:
            conn.execute(_UPSERT_SQL, params)
            conn.commit()

    def get_completed_samples(self, run_id: str) -> set[tuple[str, str]]:
        """Return ``{(strategy, sample_id)}`` for rows that have a prediction or error."""
        self._ensure_tables()
        with self._pool.connection() as conn:
            cur = conn.execute(
                """SELECT strategy, sample_id FROM experiment_results
                   WHERE run_id = %(run_id)s
                     AND (prediction IS NOT NULL OR error IS NOT NULL)""",
                {"run_id": run_id},
            )
            return {(row[0], row[1]) for row in cur.fetchall()}

    def get_run_results(self, run_id: str) -> list[dict[str, Any]]:
        """Return all result rows for a run."""
        self._ensure_tables()
        with self._pool.connection() as conn:
            cur = conn.execute(
                "SELECT * FROM experiment_results WHERE run_id = %(run_id)s ORDER BY created_at",
                {"run_id": run_id},
            )
            return _rows_to_dicts(cur)

    def get_aggregate_metrics(self, run_id: str) -> dict[str, Any]:
        """Compute overall aggregate metrics for a run."""
        self._ensure_tables()
        with self._pool.connection() as conn:
            cur = conn.execute(_AGGREGATE_SQL, {"run_id": run_id})
            rows = _rows_to_dicts(cur)
            return rows[0] if rows else {}

    def get_metrics_by_conflict_type(self, run_id: str) -> list[dict[str, Any]]:
        """Compute per-conflict-type aggregate metrics."""
        self._ensure_tables()
        with self._pool.connection() as conn:
            cur = conn.execute(_AGGREGATE_BY_CONFLICT_SQL, {"run_id": run_id})
            return _rows_to_dicts(cur)

    # -- export --------------------------------------------------------------

    def export_csv(self, run_id: str, path: str | Path) -> None:
        """Export run results to CSV."""
        results = self.get_run_results(run_id)
        if not results:
            logger.warning(f"No results to export for run {run_id}")
            return

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        fieldnames = list(results[0].keys())
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            for row in results:
                writer.writerow(
                    {
                        k: json.dumps(v) if isinstance(v, (dict, list)) else v
                        for k, v in row.items()
                    }
                )
        logger.info(f"Exported {len(results)} rows → {path}")
