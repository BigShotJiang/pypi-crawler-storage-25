"""Universal LLM client supporting any OpenAI-compatible API.

Supports DeepSeek (default), OpenAI, Azure OpenAI, and local vLLM
endpoints. Credential priority: explicit config > OPENAI_API_KEY > DEEPSEEK_API_KEY.
"""

import os
from typing import Any

from loguru import logger
from openai import AzureOpenAI, OpenAI
from pydantic import BaseModel
from tenacity import retry, stop_after_attempt, wait_exponential


def _is_azure_endpoint(url: str) -> bool:
    """Detect if a URL is an Azure OpenAI endpoint."""
    return "openai.azure.com" in url


def resolve_llm_credentials(
    api_key: str | None = None,
    base_url: str | None = None,
) -> tuple[str, str]:
    """Resolve LLM API credentials with priority.

    Priority: explicit args > OPENAI_API_KEY > DEEPSEEK_API_KEY

    Returns:
        Tuple of (api_key, base_url).

    Raises:
        ValueError: If no API key can be resolved.
    """
    # If both explicitly provided, use them directly
    if api_key and base_url:
        return api_key, base_url

    # If only base_url is provided, resolve key from env
    # Try to match the key to the provider indicated by base_url
    if base_url and not api_key:
        # DeepSeek URL -> try DeepSeek key first
        if "deepseek" in base_url:
            deepseek_key = os.getenv("DEEPSEEK_API_KEY")
            if deepseek_key:
                return deepseek_key, base_url
            openai_key = os.getenv("OPENAI_API_KEY")
            if openai_key:
                return openai_key, base_url
        else:
            # Non-DeepSeek URL -> try OpenAI key first
            openai_key = os.getenv("OPENAI_API_KEY")
            if openai_key:
                return openai_key, base_url
            deepseek_key = os.getenv("DEEPSEEK_API_KEY")
            if deepseek_key:
                return deepseek_key, base_url
        raise ValueError(
            "No LLM API key found. Set OPENAI_API_KEY or DEEPSEEK_API_KEY "
            "in environment, or pass api_key explicitly."
        )

    # If only api_key is provided, resolve base_url from env or default
    if api_key and not base_url:
        # Check if OPENAI_API_BASE is set
        openai_base = os.getenv("OPENAI_API_BASE")
        if openai_base:
            return api_key, openai_base
        # Default to OpenAI unless DeepSeek is explicitly preferred
        # (no way to infer provider from key alone, so OpenAI is safer default)
        return api_key, "https://api.openai.com/v1"

    # Neither provided — resolve both from environment
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        openai_base = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")
        return openai_key, openai_base

    deepseek_key = os.getenv("DEEPSEEK_API_KEY")
    if deepseek_key:
        return deepseek_key, "https://api.deepseek.com"

    raise ValueError(
        "No LLM API key found. Set OPENAI_API_KEY or DEEPSEEK_API_KEY "
        "in environment, or pass api_key explicitly."
    )


def create_openai_client(api_key: str, base_url: str) -> OpenAI | AzureOpenAI:
    """Create the appropriate OpenAI client based on the endpoint.

    Azure endpoints get AzureOpenAI client; everything else gets OpenAI.
    """
    if _is_azure_endpoint(base_url):
        # Azure URL format: https://{resource}.openai.azure.com/v1
        # Strip /v1 suffix for Azure client (it adds its own path)
        azure_endpoint = base_url.rstrip("/")
        if azure_endpoint.endswith("/v1"):
            azure_endpoint = azure_endpoint[:-3]

        api_version = os.getenv("AZURE_API_VERSION", "2024-10-21")

        logger.debug(
            f"Using AzureOpenAI client: endpoint={azure_endpoint}, api_version={api_version}"
        )
        return AzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version,
        )

    return OpenAI(api_key=api_key, base_url=base_url)


class LLMConfig(BaseModel):
    """Configuration for the LLM client."""

    api_key: str | None = None
    base_url: str | None = None
    model: str = "gpt-4o-mini"
    temperature: float = 0.0
    max_tokens: int = 1024


class LLMClient:
    """Client for interacting with any OpenAI-compatible API."""

    def __init__(self, config: LLMConfig | None = None):
        if config is None:
            config = LLMConfig()

        resolved_key, resolved_url = resolve_llm_credentials(
            api_key=config.api_key,
            base_url=config.base_url,
        )

        self.config = config
        self.client = create_openai_client(resolved_key, resolved_url)
        logger.info(f"Initialized LLM client: model={config.model}, base_url={resolved_url}")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
    )
    def generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Generate a response from the LLM.

        Args:
            prompt: The user prompt
            system_prompt: Optional system prompt
            **kwargs: Additional arguments passed to the API

        Returns:
            The generated text response
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        response = self.client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            temperature=kwargs.get("temperature", self.config.temperature),
            max_tokens=kwargs.get("max_tokens", self.config.max_tokens),
        )

        return response.choices[0].message.content or ""

    def generate_with_context(
        self,
        query: str,
        context: str,
        system_prompt: str | None = None,
    ) -> str:
        """Generate a response using RAG context.

        Args:
            query: The user's question
            context: Retrieved context to ground the response
            system_prompt: Optional custom system prompt

        Returns:
            The generated response
        """
        if system_prompt is None:
            system_prompt = (
                "You are a helpful assistant that answers questions based on the "
                "provided context. Only use information from the context to answer. "
                "If the context doesn't contain enough information to answer the "
                "question, say so clearly."
            )

        prompt = f"""Context:
{context}

Question: {query}

Answer based only on the context provided above:"""

        return self.generate(prompt, system_prompt=system_prompt)
