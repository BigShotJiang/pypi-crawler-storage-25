"""ConsistentRAG: Improving factual consistency in RAG through KG grounding.

Quick start:
    >>> from consistent_rag import ConsistentRAG
    >>>
    >>> # Hybrid: FAISS + KG with PPR (default)
    >>> rag = ConsistentRAG(
    ...     pipeline="hybrid",
    ...     backend="faiss",
    ...     strategy="ppr"
    ... )
    >>> result = rag.query("What is X?")
    >>> print(result.answer)

    >>> # KG-only with provided context
    >>> rag = ConsistentRAG(pipeline="kg_only", strategy="ppr")
    >>> result = rag.query("What is X?", context="X is...")
"""

# Logging is configured when ConsistentRAG is instantiated
# to allow user control over verbosity
from consistent_rag.agents.state import AgentStep, IterationTrace, PipelineState
from consistent_rag.api import ConsistentRAG, QueryResult
from consistent_rag.config import DATASETS_DIR, PROJ_ROOT
from consistent_rag.core import Backend, PipelineType
from consistent_rag.embeddings import EmbeddingConfig
from consistent_rag.logging_config import LogLevel, configure_logging, set_log_level

__all__ = [
    "ConsistentRAG",
    "QueryResult",
    "PipelineState",
    "IterationTrace",
    "AgentStep",
    "EmbeddingConfig",
    "PipelineType",
    "Backend",
    "DATASETS_DIR",
    "PROJ_ROOT",
    # Logging utilities
    "configure_logging",
    "set_log_level",
    "LogLevel",
]
