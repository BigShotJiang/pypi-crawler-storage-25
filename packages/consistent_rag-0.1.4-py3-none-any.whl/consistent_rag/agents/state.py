"""Pipeline observability models for tracking agent execution."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class AgentStep(BaseModel):
    """Record of a single agent invocation."""

    agent_name: str = Field(description="Name of the agent that ran")
    duration_ms: float = Field(description="Wall-clock duration in milliseconds")
    input_summary: str = Field(default="", description="Brief summary of input")
    output_summary: str = Field(default="", description="Brief summary of output")


class IterationTrace(BaseModel):
    """Trace of a single improvement loop iteration."""

    iteration: int = 0
    query: str = ""
    seeds_used: list[str] = Field(default_factory=list)
    new_seeds_added: list[str] = Field(default_factory=list)
    seeds_dropped: list[str] = Field(default_factory=list)
    triples_extracted: int = 0
    entities_in_graph: int = 0
    edges_in_graph: int = 0
    edges_reweighted: int = 0
    avg_weight_delta: float = 0.0
    shortcuts_added: int = 0
    reasoning_paths_found: int = 0
    reasoning_paths: list[dict] = Field(default_factory=list)
    path_utilities: dict[str, float] = Field(default_factory=dict)
    subgraph_nodes: list[str] = Field(default_factory=list)
    subgraph_edges: list[dict] = Field(default_factory=list)
    unused_triples: list[dict] = Field(default_factory=list)
    pruned_edges: list[tuple] = Field(default_factory=list)
    added_edges: list[tuple] = Field(default_factory=list)
    answer_confidence: float = 0.0
    critic_score: float = 0.0
    is_satisfactory: bool = False
    refinement_applied: bool = False
    contradictions_detected: int = 0
    triples_pruned: int = 0
    paths_expanded: int = 0
    entities_resolved_by_faiss: int = 0
    context_snapshot: str = Field(
        default="", description="Combined context used for this iteration"
    )
    converged: bool = False
    weight_delta: float = 0.0
    path_jaccard: float = 0.0
    score_improvement: float = 0.0
    error_types: list[str] = Field(default_factory=list)
    answer_text: str = ""
    duration_ms: float = 0.0

    # Subgraph tracking (what was actually used, not the whole graph)
    subgraph_entity_count: int = 0
    subgraph_edge_count: int = 0
    subgraph_entity_names: list[str] = Field(default_factory=list)
    faiss_index_size: int = 0
    lsh_index_size: int = 0


class PipelineState(BaseModel):
    """Tracks what happened inside an agentic pipeline run."""

    pipeline_name: str = Field(default="", description="Name of the pipeline")
    started_at: datetime = Field(default_factory=datetime.now)
    total_duration_ms: float = 0.0
    iterations: int = 0
    steps: list[AgentStep] = Field(default_factory=list)
    iteration_traces: list[IterationTrace] = Field(default_factory=list)
    subgraph_strategy: str = ""
    use_vector: bool = False
    use_kg: bool = False
    seeds_count: int = 0
    triples_count: int = 0
    refinements_applied: int = 0
    contradictions_found: int = 0
