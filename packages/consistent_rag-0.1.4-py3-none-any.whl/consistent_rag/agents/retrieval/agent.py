"""Retrieval Agent - executes retrieval with tools based on routing decision."""

from __future__ import annotations

from dataclasses import dataclass

from loguru import logger
from pydantic_ai import Agent, RunContext
from pydantic_ai.exceptions import UsageLimitExceeded
from pydantic_ai.usage import UsageLimits

from consistent_rag.retrievers import BaseRetriever, Document


@dataclass
class RetrievalDeps:
    """Dependencies for the retrieval agent."""

    retriever: BaseRetriever
    query: str
    top_k: int = 5


RETRIEVAL_SYSTEM_PROMPT = """You are a retrieval expert. Execute the retrieval strategy decided by the router.

Rules:
1. Issue AT MOST 2 tool calls total. A single search is almost always sufficient.
2. After receiving results from the first (and at most second) search, return the retrieved documents immediately.
3. Do NOT refine, paraphrase, or issue additional searches — the outer pipeline handles iteration.
4. If the query was rewritten by the router, use the rewritten version.
5. Skip retrieval entirely only when the strategy is "none"."""


def create_retrieval_agent(
    model: str, api_key: str | None = None, base_url: str | None = None
) -> Agent[RetrievalDeps, list[Document]]:
    """Create the retrieval agent with tools.

    Args:
        model: The LLM model name.
        api_key: Optional API key.
        base_url: Optional API base URL.

    Returns:
        Configured Agent instance.
    """
    from openai import AsyncOpenAI
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    from consistent_rag.llm import resolve_llm_credentials

    key, url = resolve_llm_credentials(api_key=api_key, base_url=base_url)
    client = AsyncOpenAI(api_key=key, base_url=url)
    provider = OpenAIProvider(openai_client=client)
    chat_model = OpenAIChatModel(model, provider=provider)

    agent = Agent(
        chat_model,
        deps_type=RetrievalDeps,
        output_type=list[Document],
        system_prompt=RETRIEVAL_SYSTEM_PROMPT,
        retries=2,
    )

    @agent.tool
    async def vector_search(ctx: RunContext[RetrievalDeps], query: str) -> list[dict]:
        """Search for documents using semantic vector search.

        Args:
            query: The search query.

        Returns:
            List of documents with text and metadata.
        """
        logger.debug(f"Vector search for: {query}")
        results = ctx.deps.retriever.retrieve(query, top_k=ctx.deps.top_k)
        return [
            {"text": r.document.text, "score": r.score, "metadata": r.document.metadata}
            for r in results
        ]

    @agent.tool
    async def hybrid_search(ctx: RunContext[RetrievalDeps], query: str) -> list[dict]:
        """Search using hybrid (semantic + keyword) approach.

        Args:
            query: The search query.

        Returns:
            List of documents with text and metadata.
        """
        logger.debug(f"Hybrid search for: {query}")
        results = ctx.deps.retriever.retrieve(query, top_k=ctx.deps.top_k + 2)
        return [
            {"text": r.document.text, "score": r.score, "metadata": r.document.metadata}
            for r in results
        ]

    return agent


async def run_retrieval(
    agent: Agent[RetrievalDeps, list[Document]],
    query: str,
    retriever: BaseRetriever,
    top_k: int = 5,
    max_requests: int = 6,
) -> tuple[list[Document], str]:
    """Run the retrieval agent to get documents.

    Args:
        agent: The retrieval agent.
        query: The search query.
        retriever: The retriever to use.
        top_k: Number of documents to retrieve.
        max_requests: Maximum number of tool calls.

    Returns:
        Tuple of (documents, formatted_context).

    On UsageLimitExceeded, falls back to a direct retriever call so the
    pipeline still produces a context instead of crashing the sample.
    """
    deps = RetrievalDeps(retriever=retriever, query=query, top_k=top_k)
    prompt = f"Execute vector search for: {query}"
    usage_limits = UsageLimits(request_limit=max_requests)

    try:
        result = await agent.run(prompt, deps=deps, usage_limits=usage_limits)
        documents = result.output
    except UsageLimitExceeded as exc:
        logger.warning(
            f"Retrieval agent exceeded request budget ({max_requests} calls): {exc}. "
            "Falling back to direct retriever.retrieve"
        )
        results = retriever.retrieve(query, top_k=top_k)
        documents = [r.document for r in results]
        context = retriever.format_context(results)
        return documents, context

    # Format context
    context = retriever.format_context(
        [type("R", (), {"document": doc, "score": 1.0})() for doc in documents]
    )

    return documents, context
