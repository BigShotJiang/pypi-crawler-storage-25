"""Seed Agent - extracts seed entities from queries for graph traversal."""

from __future__ import annotations

from pydantic import BaseModel, Field
from pydantic_ai import Agent

from consistent_rag.agents.common.models import IterationState


class SeedExtractionResult(BaseModel):
    """Result from seed entity extraction."""

    seeds: list[str] = Field(description="Entity names to use as seeds")
    scores: list[float] = Field(description="Relevance scores for each seed")
    reasoning: str = Field(description="Explanation for seed selection")
    source_type: list[str] = Field(
        default_factory=list,
        description="Source of each seed: 'llm', 'graph_match', 'graph_neighbor'",
    )
    graph_matched: int = Field(default=0, description="Count of seeds matched in graph")


SEED_SYSTEM_PROMPT = """You are an expert in entity extraction for knowledge graph traversal.

Your task is to extract key entities from a query that will be used as seeds for graph traversal.

Rules:
1. Extract only the most relevant entities (max 5-7).
2. Prefer named entities (people, organizations, locations, products).
3. Include key concepts that are central to the query.
4. Do not include generic terms like "what", "when", "how".
5. Each seed should be a single word or short phrase.

Example:
Query: "What was the revenue of Apple in 2023?"
Seeds: ["Apple", "revenue", "2023"]"""


def create_seed_agent(
    model: str, api_key: str | None = None, base_url: str | None = None
) -> Agent[IterationState, SeedExtractionResult]:
    """Create the seed extraction agent.

    Args:
        model: The LLM model name.
        api_key: Optional API key.
        base_url: Optional API base URL.

    Returns:
        Configured Agent instance.
    """
    from openai import AsyncOpenAI
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    from consistent_rag.llm import resolve_llm_credentials

    key, url = resolve_llm_credentials(api_key=api_key, base_url=base_url)
    client = AsyncOpenAI(api_key=key, base_url=url)
    provider = OpenAIProvider(openai_client=client)
    chat_model = OpenAIChatModel(model, provider=provider)

    return Agent(
        chat_model,
        deps_type=IterationState,
        output_type=SeedExtractionResult,
        system_prompt=SEED_SYSTEM_PROMPT,
        retries=2,
    )


async def run_seed_extraction(
    agent: Agent[IterationState, SeedExtractionResult],
    state: IterationState,
) -> SeedExtractionResult:
    """Run the seed extraction agent.

    Args:
        agent: The seed extraction agent.
        state: Current iteration state with query.

    Returns:
        SeedExtractionResult with extracted seeds.
    """
    prompt = f"Extract seed entities from this query:\n\n{state.query}"
    result = await agent.run(prompt, deps=state)
    return result.output
