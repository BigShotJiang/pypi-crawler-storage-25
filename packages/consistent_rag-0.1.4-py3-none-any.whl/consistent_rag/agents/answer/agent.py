"""Answer Agent - generates grounded responses with citations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from loguru import logger
from pydantic import Field, create_model
from pydantic_ai import Agent

from consistent_rag.agents.common.models import AnswerWithCitations, IterationState
from consistent_rag.agents.common.prompts import PromptGenerator

ANSWER_SYSTEM_PROMPT = """You are an expert in retrieval QA and Chain of Thought reasoning.

Your task is to answer questions based on the provided context. Follow these rules:
1. Always provide the best possible answer based on what the context states.
2. If the context contains conflicting information, pick the answer most directly supported by the context.
3. Always provide your step-by-step reasoning in the "reasoning" field.
4. Provide a concise, direct answer in the "answer" field — just the key fact or phrase, not a full sentence.
5. Provide a confidence score between 0.0 and 1.0 in the "confidence" field indicating how strongly the context supports your answer.

Be concise and precise. Use information from the provided context."""


@dataclass
class AnswerDeps:
    """Dependencies for the answer agent."""

    state: IterationState


def _build_choice_constrained_output_model(choices: list[str]) -> type[AnswerWithCitations]:
    """Build a per-run output schema whose `answer` is Literal[*choices].

    Making the choice-adherence contract structural — not prompt-only —
    means pydantic-ai's validation rejects free-form replies like
    "No information available" and triggers the agent's retry loop.
    This is how we keep the "we always rely on structured outputs" rule
    intact for MC samples.
    """
    allowed = Literal[tuple(choices)]  # type: ignore[valid-type]
    return create_model(
        "ChoiceConstrainedAnswer",
        __base__=AnswerWithCitations,
        answer=(allowed, Field(description="One of the provided options, verbatim")),
    )


def create_answer_agent(
    model: str, api_key: str | None = None, base_url: str | None = None
) -> Agent[AnswerDeps, AnswerWithCitations]:
    """Create the answer generation agent.

    Args:
        model: The LLM model name (e.g., "gpt-4o-mini").
        api_key: Optional API key.
        base_url: Optional API base URL.

    Returns:
        Configured Agent instance.
    """
    from openai import AsyncOpenAI
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    from consistent_rag.llm import resolve_llm_credentials

    key, url = resolve_llm_credentials(api_key=api_key, base_url=base_url)
    client = AsyncOpenAI(api_key=key, base_url=url)
    provider = OpenAIProvider(openai_client=client)
    chat_model = OpenAIChatModel(model, provider=provider)

    return Agent(
        chat_model,
        deps_type=AnswerDeps,
        output_type=AnswerWithCitations,
        system_prompt=ANSWER_SYSTEM_PROMPT,
        retries=2,
    )


async def run_answer(
    agent: Agent[AnswerDeps, AnswerWithCitations],
    state: IterationState,
) -> tuple[AnswerWithCitations, str]:
    """Run the answer agent to generate a response.

    Args:
        agent: The answer generation agent.
        state: Current iteration state with context and query.

    Returns:
        Tuple of (answer result, prompt used).
    """
    deps = AnswerDeps(state=state)

    # Initialize prompt generator
    prompt_gen = PromptGenerator(llm_type="deepseek", task="qa-cot")

    # If the benchmark sample shipped choices, fold them into the prompt so the
    # model answers with one of the options rather than inventing free-form
    # prose. Every dataset under `datasets/` (FaithEval, MuSiQuE, SQuAD, TimeQA)
    # ships fully populated choices; dropping them here is the main reason the
    # pre-fix F1 numbers understated the pipeline's correctness.
    formatted_options = None
    if state.choices:
        formatted_options = "\n".join(c.strip() for c in state.choices if c)

    prompt = prompt_gen.generate_qa_prompt_normal_cot(
        context=state.formatted_context if state.formatted_context else "No context available.",
        question=state.query,
        options=formatted_options,
    )

    # Add improvement suggestions if this is a retry
    if state.iteration > 0 and state.critic_feedback:
        prompt += f"\n\nPrevious answer score: {state.critic_feedback.score:.2f}"
        prompt += "\nImprovement suggestions:"
        for suggestion in state.critic_feedback.improvement_suggestions:
            prompt += f"\n- {suggestion}"

    # For MC samples, override the per-run output_type so the answer is
    # structurally constrained to one of the provided choices. The default
    # AnswerWithCitations schema would let the model emit free-form text
    # (observed on TimeQA: "No information available" vs. the "I don't know"
    # choice) — structural typing is the guardrail the prompt alone can't
    # provide.
    output_type = _build_choice_constrained_output_model(state.choices) if state.choices else None
    run_kwargs: dict = {"deps": deps}
    if output_type is not None:
        run_kwargs["output_type"] = output_type
        logger.debug(f"[run_answer] Choice-constrained output: choices={state.choices!r}")

    try:
        result = await agent.run(prompt, **run_kwargs)
        return _coerce_to_answer_with_citations(result.output), prompt
    except Exception as e:
        if "content or tool_calls must be set" in str(e):
            logger.warning("DeepSeek rejected message format, retrying with fresh context...")
            result = await agent.run(prompt, **run_kwargs)
            return _coerce_to_answer_with_citations(result.output), prompt
        raise


def _coerce_to_answer_with_citations(output) -> AnswerWithCitations:
    """Normalize choice-constrained dynamic models back to AnswerWithCitations.

    Downstream code (critic, orchestrator, CSV writer) expects the base
    type — the Literal-typed subclass is an implementation detail of the
    choice-aware run.
    """
    if isinstance(output, AnswerWithCitations):
        return output
    return AnswerWithCitations(
        answer=getattr(output, "answer", ""),
        reasoning=getattr(output, "reasoning", ""),
        citations=getattr(output, "citations", []),
        confidence=getattr(output, "confidence", 0.0),
    )
