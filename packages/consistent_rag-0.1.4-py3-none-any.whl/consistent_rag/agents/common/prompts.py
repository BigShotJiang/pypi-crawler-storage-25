from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...benchmarks.faitheval import FaithEvalSample

SYSTEM_PROMPTS = {}
SYSTEM_PROMPTS["normal"] = (
    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible."
)
SYSTEM_PROMPTS["qa"] = (
    "You are an expert in retrieval QA. Please respond with the exact answer only. Dont be verbose or provide extra information."
)
SYSTEM_PROMPTS["extract"] = (
    "You are a precise and reliable information extractor. Your sole task is to extract relevant information from the given context strictly according to the instructions. You must not add, modify, or infer any information that is not explicitly stated in the context."
)
SYSTEM_PROMPTS["qa-cot"] = (
    "You are an expert in retrieval QA and Chain of Thought reasoning. Provide your reasoning steps followed by a precise and direct answer. Avoiding any unnecessary explanations or verbosity."
)
SYSTEM_PROMPTS["faitheval"] = (
    "You are an expert in reading comprehension and faithfulness evaluation. Analyze the context carefully and classify any conflicts or issues you detect."
)
SYSTEM_PROMPTS["financial-qa"] = (
    "You are an expert financial analyst and retrieval QA specialist. "
    "When answering questions: (1) cite specific filing references (10-K, 10-Q, 8-K) when available, "
    "(2) distinguish clearly between historical facts and forward-looking statements, "
    "(3) flag when numerical precision is uncertain or when figures are estimates, "
    "(4) never provide investment advice or recommendations. "
    "Base your answers strictly on the provided context and financial documents."
)
SYSTEM_PROMPTS["regulatory-extract"] = (
    "You are a precise regulatory information extractor. Extract structured information from "
    "regulatory and compliance documents. Focus on: obligations (MUST/SHALL), prohibitions, "
    "exceptions to rules, definitions of terms, effective dates, and regulatory references. "
    "Output only what is explicitly stated — do not infer or add information."
)
SYSTEM_PROMPTS["valuation-cot"] = (
    "You are an expert in financial valuation and Chain of Thought reasoning. "
    "When analyzing valuations: select the appropriate methodology (DCF, comparable company analysis, "
    "precedent transactions), show calculation steps, state assumptions explicitly, and provide "
    'your reasoning in JSON format: {"Reason": "(methodology and steps)", "Answer": "(valuation conclusion)"}.'
)
SYSTEM_PROMPTS["risk-assessment"] = (
    "You are a financial risk assessment specialist. Evaluate risk factors from documents, "
    "categorizing each risk by type (market, credit, operational, regulatory, liquidity) "
    "and severity (high, medium, low). Provide structured output with risk category, "
    "description, severity, and potential mitigation measures."
)

GRAPH_FIELD_SEP = "<SEP>"

PROMPTS = {}

PROMPTS["DEFAULT_TUPLE_DELIMITER"] = "<|>"
PROMPTS["DEFAULT_RECORD_DELIMITER"] = "##"
PROMPTS["DEFAULT_COMPLETION_DELIMITER"] = "<|COMPLETE|>"
PROMPTS["process_tickers"] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

PROMPTS["DEFAULT_ENTITY_TYPES"] = ["organization", "person", "location", "event"]


class PromptGenerator:
    def __init__(self, llm_type, task: str = "normal", tokenizer=None):
        self.llm_type = llm_type
        self.tokenizer = tokenizer
        if task == "qa":
            self.system_prompt = SYSTEM_PROMPTS["qa"]
        elif task == "extract":
            self.system_prompt = SYSTEM_PROMPTS["extract"]
        elif task == "facts":
            self.system_prompt = SYSTEM_PROMPTS.get("facts", SYSTEM_PROMPTS["normal"])
        elif task == "qa-cot":
            self.system_prompt = SYSTEM_PROMPTS["qa-cot"]
        elif task == "faitheval":
            self.system_prompt = SYSTEM_PROMPTS["faitheval"]
        elif task == "financial-qa":
            self.system_prompt = SYSTEM_PROMPTS["financial-qa"]
        elif task == "regulatory-extract":
            self.system_prompt = SYSTEM_PROMPTS["regulatory-extract"]
        elif task == "valuation-cot":
            self.system_prompt = SYSTEM_PROMPTS["valuation-cot"]
        elif task == "risk-assessment":
            self.system_prompt = SYSTEM_PROMPTS["risk-assessment"]
        else:
            self.system_prompt = SYSTEM_PROMPTS["normal"]

    def generate_qa_prompt_normal_cot(self, context, question, options=None, facts=None):
        normal_w_facts_prompt = """
-Task Description-
Given facts, a question and a context, your task is to select the most accurate and relevant answer from the provided options. You should only choose the option that directly answers the question based on the facts and context.

-Steps-
1. Analyze the **Question** carefully.
2. Use the **Facts** to provide a clear and accurate answer to the question.
3. Refer to the **Context** If the facts do not contain enough information to answer the question, or if additional information is needed.
4. Please return in JSON format: {{"Reason": "(reason)", "Answer": "(answer)"}}

######################
-Example-
######################
Question:  
Which element has the highest electronegativity?  

Facts:  
Electronegativity increases across periods and decreases down groups. Fluorine is the most electronegative element.  

Context:  
The Pauling scale measures electronegativity. Chlorine, in fluorine's group, has lower electronegativity due to larger atomic radius.  
#############
CoT-Answer:
{{"Reason": "According to the facts, electronegativity increases across periods and decreases down groups, and it is stated that fluorine is the most electronegative element. The context also supports this by mentioning that chlorine, which is in the same group as fluorine, has a lower electronegativity due to its larger atomic radius. Therefore, based on the given information, fluorine has the highest electronegativity.", "Answer": "Fluorine"}}

######################
-Real Data-
######################
Question:
{question}

Facts:
{facts}

Context:
{context}
#############
CoT-Answer:
"""
        choice_w_facts_prompt = """
-Task Description-
Given facts, a question and a context, your task is to select the most accurate and relevant answer from the provided options. You MUST output exactly one option verbatim — do not paraphrase, do not invent free-form text. If neither facts nor context contain enough information, one of the options is typically an explicit fallback such as "I don't know" or "None of the above" — choose that fallback option rather than replying with text that is not in the list.

-Steps-
1. Analyze the **Question** and the **Options**.
2. Use the **Facts** to select the most accurate answer from the **Options**.
3. Refer to the **Context** if the facts do not contain enough information.
4. If neither facts nor context support a non-fallback option, pick the fallback option (e.g. "I don't know") that is present in the list.
5. Please return in JSON format: {{"Reason": "(reason)", "Answer": "(answer)"}}

######################
-Example-
######################
Question:  
Which element has the highest electronegativity?  

Facts:  
Electronegativity increases across periods and decreases down groups. Fluorine is the most electronegative element.  

Context:  
The Pauling scale measures electronegativity. Chlorine, in fluorine's group, has lower electronegativity due to larger atomic radius.  

Options:  
Oxygen  
Chlorine  
Fluorine 
#############
CoT-Answer:
{{"Reason": "According to the facts, electronegativity increases across periods and decreases down groups, and it is stated that fluorine is the most electronegative element. The context also supports this by mentioning that chlorine, which is in the same group as fluorine, has a lower electronegativity due to its larger atomic radius. Therefore, based on the given information, fluorine has the highest electronegativity.", "Answer": "Fluorine"}}

######################
-Real Data-
######################
Question:
{question}

Facts:
{facts}

Context:
{context}

Options:
{options}
#############
CoT-Answer:
"""
        normal_wo_facts_prompt = """
-Task Description-
Given a question and a context, your task is to provide a clear, concise, and accurate answer based on the provided context.

IMPORTANT:
- Always provide the best possible answer based on what the context states, even if the context contains conflicting or unusual information.
- If the context contains conflicting information, pick the answer that is most directly supported.
- Your answer should be SHORT and DIRECT — just the key fact or phrase, not a full sentence.
- Be concise and direct in your answer.

-Steps-
1. Analyze the **Question** carefully.
2. Refer to the **Context** to find the answer.
3. Provide a short, direct answer based on the context.
4. Return in JSON format: {{"reasoning": "(your step-by-step reasoning)", "answer": "(your concise answer)"}}

######################
-Example-
######################
Question:
Which element has the highest electronegativity?

Context:
The Pauling scale measures electronegativity. Fluorine is the most electronegative element. Chlorine, in fluorine's group, has lower electronegativity due to larger atomic radius.
#############
CoT-Answer:
{{"reasoning": "The context explicitly states that fluorine is the most electronegative element.", "answer": "Fluorine"}}

######################
-Real Data-
######################
Question:
{question}

Context:
{context}
#############
CoT-Answer:
"""

        choice_wo_facts_prompt = """
-Task Description-
Given a question, a context, and options, your task is to select the most accurate and relevant answer from the provided options. You MUST output exactly one option verbatim — do not paraphrase, do not invent free-form text. If the context does not contain enough information, one of the options is typically an explicit fallback such as "I don't know" or "None of the above" — choose that fallback option rather than replying with text that is not in the list.

-Steps-
1. Analyze the **Question** and the **Options**.
2. Refer to the **Context** to select the most accurate answer from the **Options**.
3. If the context is empty or unhelpful, pick the fallback option (e.g. "I don't know") that is present in the list.
4. Please return in JSON format: {{"Reason": "(reason)", "Answer": "(answer)"}}

######################
-Example-
######################
Question:  
Which element has the highest electronegativity?  

Context:  
The Pauling scale measures electronegativity. Chlorine, in fluorine's group, has lower electronegativity due to larger atomic radius.  

Options:  
Oxygen  
Chlorine  
Fluorine 
#############
CoT-Answer:
{{"Reason": "According to the facts, electronegativity increases across periods and decreases down groups, and it is stated that fluorine is the most electronegative element. The context also supports this by mentioning that chlorine, which is in the same group as fluorine, has a lower electronegativity due to its larger atomic radius. Therefore, based on the given information, fluorine has the highest electronegativity.", "Answer": "Fluorine"}}

######################
-Real Data-
######################
Question:
{question}

Context:
{context}

Options:
{options}
#############
CoT-Answer:
"""
        if options is None:
            if facts is None:
                return normal_wo_facts_prompt.format(question=question, context=context)
            else:
                return normal_w_facts_prompt.format(
                    question=question, facts=facts, context=context
                )
        else:
            if facts is None:
                return choice_wo_facts_prompt.format(
                    question=question, context=context, options=options
                )
            else:
                return choice_w_facts_prompt.format(
                    question=question, facts=facts, context=context, options=options
                )

    def generate_faitheval_inconsistent_prompt(self, context: str, question: str) -> str:
        """Generate a prompt for FaithEval inconsistent samples.

        Instructs the LLM to detect conflicting information in the context,
        identify both possible answers, and classify as inconsistent.
        """
        return """You are evaluating a reading comprehension question where the context may contain CONFLICTING information.

-Task-
Given a question and a context, carefully analyze the context for any conflicting or contradictory information. The context may present two different answers to the same question. You MUST always provide an answer regardless of conflicts.

-Steps-
1. Read the **Context** carefully and identify any conflicting statements.
2. If conflicting information exists, classify this as "inconsistent".
3. Even if there is a conflict, you MUST provide a concise, direct answer — pick the answer most directly supported by the context.
4. Explain your reasoning, noting the conflicting information found.

-Output Format-
Respond with a JSON object with these exact fields:
- "answer": your concise, direct answer to the question (NEVER say "unanswerable" — always pick the best answer)
- "answer_label": "inconsistent" if conflicting info detected, "consistent" otherwise
- "reasoning": your step-by-step analysis of the conflict
- "confidence": a number between 0 and 1
- "selected_choice": null

######################
-Real Data-
######################
Question:
{question}

Context:
{context}
#############
Response:""".format(question=question, context=context)

    def generate_faitheval_unanswerable_prompt(self, context: str, question: str) -> str:
        """Generate a prompt for FaithEval unanswerable samples.

        Instructs the LLM to detect when the context does not contain
        sufficient information to answer the question.
        """
        return """You are evaluating a reading comprehension question where the context may NOT contain enough information to answer the question.

-Task-
Given a question and a context, determine whether the context provides sufficient information to answer the question. You MUST always provide your best answer based on what the context states.

-Steps-
1. Read the **Question** carefully.
2. Search the **Context** for information that directly answers the question.
3. Provide a concise, direct answer based on what the context states — even if the information seems incomplete or unusual.
4. If the context truly has no relevant information at all, classify as "unanswerable", but still provide your best attempt.
5. Explain your reasoning.

-Output Format-
Respond with a JSON object with these exact fields:
- "answer": your concise, direct answer based on the context (always provide the best answer you can)
- "answer_label": "unanswerable" if info is truly absent, "consistent" if answerable
- "reasoning": your step-by-step analysis
- "confidence": a number between 0 and 1
- "selected_choice": null

######################
-Real Data-
######################
Question:
{question}

Context:
{context}
#############
Response:""".format(question=question, context=context)

    def generate_faitheval_counterfactual_prompt(
        self, context: str, question: str, choices: dict
    ) -> str:
        """Generate a prompt for FaithEval counterfactual samples.

        Formats choices as A) text and instructs the LLM to select one,
        detecting if the context contradicts common knowledge.
        """
        # Format choices from dict with 'label' and 'text' arrays
        formatted_choices = ""
        if choices and "label" in choices and "text" in choices:
            for label, text in zip(choices["label"], choices["text"]):
                formatted_choices += f"{label}) {text}\n"
        elif choices:
            # Fallback for other dict formats
            for k, v in choices.items():
                formatted_choices += f"{k}) {v}\n"

        return """You are evaluating a multiple-choice question where the context may contain COUNTERFACTUAL information that contradicts common knowledge.

-Task-
Given a question, a context, and answer choices, select the best answer from the choices. The context may contain information that contradicts well-known facts.

-Steps-
1. Read the **Question** and the **Choices** carefully.
2. Analyze the **Context** for any information that contradicts common knowledge.
3. Select the best answer from the choices based on the context, even if the context is counterfactual.
4. Set "selected_choice" to the letter label of your chosen answer (e.g., "A", "B", "C", "D").
5. Classify as "counterfactual" if the context contradicts common knowledge, "consistent" otherwise.
6. Explain your reasoning.

-Output Format-
Respond with a JSON object with these exact fields:
- "answer": the text of your chosen answer
- "answer_label": "counterfactual" if context contradicts common knowledge, "consistent" otherwise
- "reasoning": your step-by-step analysis
- "confidence": a number between 0 and 1
- "selected_choice": the letter label of your choice (e.g., "A")

######################
-Real Data-
######################
Question:
{question}

Context:
{context}

Choices:
{choices}
#############
Response:""".format(question=question, context=context, choices=formatted_choices.strip())


def get_faitheval_prompt(
    sample: FaithEvalSample, prompt_gen: PromptGenerator | None = None
) -> str:
    """Select the correct FaithEval prompt template based on sample conflict type.

    Args:
        sample: A FaithEvalSample with conflict_type, question, context, and optional choices.
        prompt_gen: Optional PromptGenerator instance. Creates one if not provided.

    Returns:
        The formatted prompt string for the sample.
    """
    from ...benchmarks.faitheval import ConflictType

    if prompt_gen is None:
        prompt_gen = PromptGenerator(llm_type="deepseek", task="faitheval")

    # If the sample has multiple-choice options, ALWAYS use the counterfactual
    # prompt (which selects A/B/C/D) — regardless of the declared conflict_type.
    # Otherwise the model produces free-form descriptions and exact_match fails.
    if sample.choices:
        return prompt_gen.generate_faitheval_counterfactual_prompt(
            sample.context, sample.question, sample.choices
        )

    if sample.conflict_type == ConflictType.INCONSISTENT:
        return prompt_gen.generate_faitheval_inconsistent_prompt(sample.context, sample.question)
    elif sample.conflict_type == ConflictType.UNANSWERABLE:
        return prompt_gen.generate_faitheval_unanswerable_prompt(sample.context, sample.question)
    else:
        # Default to unanswerable prompt for samples without conflict_type and no choices
        return prompt_gen.generate_faitheval_unanswerable_prompt(sample.context, sample.question)
