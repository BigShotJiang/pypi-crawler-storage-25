"""Shared models used across all agents."""

from __future__ import annotations

from pydantic import BaseModel, Field

from consistent_rag.agents.critic.agent import StructuredCriticFeedback


class CriticFeedback(BaseModel):
    """Structured feedback from the critic agent."""

    score: float = Field(ge=0.0, le=1.0, description="Overall quality score")
    groundedness: float = Field(
        default=0.0, ge=0.0, le=1.0, description="How well the answer is grounded in context"
    )
    completeness: float = Field(
        default=0.0, ge=0.0, le=1.0, description="How completely the answer addresses the query"
    )
    relevance: float = Field(default=0.0, ge=0.0, le=1.0, description="How relevant the answer is")
    is_satisfactory: bool = Field(
        default=False, description="Whether the answer meets quality threshold"
    )
    has_contradictions: bool = Field(
        default=False, description="Whether contradictions were detected in the context"
    )
    missing_information: bool = Field(
        default=False, description="Whether the context is missing required information"
    )
    missing_claims: list[str] = Field(
        default_factory=list, description="Specific claims missing from the context"
    )
    conflicting_claims: list[str] = Field(
        default_factory=list, description="Specific claims that contradict each other"
    )
    improvement_suggestions: list[str] = Field(
        default_factory=list, description="Suggestions for improvement"
    )
    guidance: str = Field(
        default="", description="Natural language guidance for the next iteration"
    )
    should_reroute: bool = Field(
        default=False, description="Whether to try a different retrieval strategy"
    )


class AnswerWithCitations(BaseModel):
    """Generated answer with source citations."""

    answer: str = Field(description="The generated short, direct answer")
    reasoning: str = Field(default="", description="The reasoning leading to the answer")
    citations: list[int] = Field(
        default_factory=list, description="Document indices used as sources"
    )
    kg_citations: list[str] = Field(
        default_factory=list, description="KG entities used as sources"
    )
    confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Confidence in the answer")


class RouteDecision(BaseModel):
    """Routing decision for retrieval strategy."""

    strategy: str = Field(description="Selected strategy: vector, hybrid, or none")
    query_rewrite: str = Field(default="", description="Rewritten query if applicable")
    reasoning: str = Field(default="", description="Explanation for the routing decision")


class IterationState(BaseModel):
    """State for a single iteration of the basic agentic pipeline."""

    iteration: int = 0
    query: str = ""
    choices: list[str] = Field(default_factory=list)
    formatted_context: str = ""
    answer: AnswerWithCitations | None = None
    critic_feedback: CriticFeedback | StructuredCriticFeedback | None = None
    route_decision: RouteDecision | None = None
