"""Common utilities for agents."""

from consistent_rag.agents.common.prompts import PROMPTS, SYSTEM_PROMPTS, PromptGenerator

__all__ = ["PromptGenerator", "SYSTEM_PROMPTS", "PROMPTS"]
