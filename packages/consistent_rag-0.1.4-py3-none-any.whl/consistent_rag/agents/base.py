"""Base classes for agent execution tracking."""

from __future__ import annotations

from datetime import datetime
import time

from consistent_rag.agents.state import AgentStep, IterationTrace, PipelineState


class MetricsCollector:
    """Centralizes timing, step recording, and iteration traces."""

    def __init__(
        self,
        pipeline_name: str,
        *,
        use_vector: bool = False,
        use_kg: bool = False,
        subgraph_strategy: str = "",
    ) -> None:
        self._pipeline_start = time.monotonic()
        self._step_start: float | None = None
        self._step_name: str = ""
        self._ps = PipelineState(
            pipeline_name=pipeline_name,
            started_at=datetime.now(),
            use_vector=use_vector,
            use_kg=use_kg,
            subgraph_strategy=subgraph_strategy,
        )

    def start_step(self, name: str) -> None:
        """Begin timing a named step."""
        self._step_name = name
        self._step_start = time.monotonic()

    def end_step(self, *, input_summary: str = "", output_summary: str = "") -> float:
        """End the current step and record it. Returns duration_ms."""
        if self._step_start is None:
            return 0.0
        duration_ms = (time.monotonic() - self._step_start) * 1000
        self._ps.steps.append(
            AgentStep(
                agent_name=self._step_name,
                duration_ms=duration_ms,
                input_summary=input_summary,
                output_summary=output_summary,
            )
        )
        self._step_start = None
        return duration_ms

    def record_iteration(self, trace: IterationTrace) -> None:
        """Record an iteration trace."""
        self._ps.iteration_traces.append(trace)

    def update_last_trace(self, **kwargs) -> None:
        """Update fields on the most recent iteration trace."""
        if self._ps.iteration_traces:
            trace = self._ps.iteration_traces[-1]
            for key, value in kwargs.items():
                setattr(trace, key, value)

    @property
    def state(self) -> PipelineState:
        """Return the current pipeline state."""
        return self._ps

    def set_iterations(self, n: int) -> None:
        """Set the number of iterations."""
        self._ps.iterations = n

    def set_seeds_count(self, n: int) -> None:
        """Set the seeds count."""
        self._ps.seeds_count = n

    def set_triples_count(self, n: int) -> None:
        """Set the triples count."""
        self._ps.triples_count = n

    def increment_contradictions(self) -> None:
        """Increment contradiction count."""
        self._ps.contradictions_found += 1

    def increment_refinements(self) -> None:
        """Increment refinement count."""
        self._ps.refinements_applied += 1

    def finalise(self) -> PipelineState:
        """Stamp total duration and return the completed PipelineState."""
        self._ps.total_duration_ms = (time.monotonic() - self._pipeline_start) * 1000
        return self._ps
