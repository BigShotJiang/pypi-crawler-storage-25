"""Critic Agent - evaluates and scores response quality with structured error types.

This agent outputs StructuredCriticFeedback which includes error classification
for C-GAPUD (Critic-Guided Adaptive Path Utility Diffusion) refinement.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from loguru import logger
from pydantic import BaseModel, Field
from pydantic_ai import Agent


class CriticErrorType(str, Enum):
    """Typed error categories from critic feedback."""

    MISSING_ENTITY = "missing_entity"
    IRRELEVANT_PATH = "irrelevant_path"
    LONG_PATH = "long_path"
    CONTRADICTION = "contradiction"
    COMPLETENESS = "completeness"


class StructuredCriticFeedback(BaseModel):
    """Structured critic feedback with error classification.

    The critic agent outputs this directly via pydantic-ai structured output.
    Error types trigger different operations in the C-GAPUD refinement loop.
    """

    score: float = Field(ge=0.0, le=1.0, description="Overall quality score")
    groundedness: float = Field(
        default=0.0, ge=0.0, le=1.0, description="How well the answer is grounded in context"
    )
    completeness: float = Field(
        default=0.0, ge=0.0, le=1.0, description="How completely the answer addresses the query"
    )
    relevance: float = Field(default=0.0, ge=0.0, le=1.0, description="How relevant the answer is")
    is_satisfactory: bool = Field(
        default=False, description="Whether the answer meets quality threshold"
    )

    # Error classification (multiple can be true)
    error_types: list[CriticErrorType] = Field(
        default_factory=list, description="Classification of errors found in the answer"
    )

    # Specific details per error type
    missing_entities: list[str] = Field(
        default_factory=list, description="Entities or facts that are missing from the context"
    )
    irrelevant_path_ids: list[str] = Field(
        default_factory=list,
        description="IDs of reasoning paths that led to irrelevant conclusions",
    )
    long_path_ids: list[str] = Field(
        default_factory=list, description="IDs of reasoning paths that are unnecessarily long"
    )
    contradiction_path_ids: list[str] = Field(
        default_factory=list, description="IDs of reasoning paths that contain contradictions"
    )

    # Natural language guidance (for answer agent)
    guidance: str = Field(default="", description="Specific guidance for improving the answer")
    improvement_suggestions: list[str] = Field(
        default_factory=list, description="Actionable suggestions for improvement"
    )
    should_reroute: bool = Field(
        default=False, description="Whether to try a different retrieval strategy"
    )


CRITIC_SYSTEM_PROMPT = """You are a critical evaluator of RAG (Retrieval-Augmented Generation) responses.

Your job is to evaluate the quality of an answer based on:

1. **Groundedness (0.0-1.0)**: Is the answer fully supported by the context? Penalize hallucinations.
2. **Completeness (0.0-1.0)**: Does the answer fully address the question?
3. **Relevance (0.0-1.0)**: Is the answer relevant and on-topic?

Calculate the overall score as the average of these three metrics.

**Error Classification** (critical for C-GAPUD refinement):
Classify errors into these categories:
- **MISSING_ENTITY**: The answer is missing key entities or facts that should be in the context
- **IRRELEVANT_PATH**: The reasoning took a path that doesn't help answer the question
- **LONG_PATH**: The reasoning is too indirect or could be shorter
- **CONTRADICTION**: The context contains conflicting claims about the same entity or fact
- **COMPLETENESS**: The answer is incomplete (doesn't fully address the question)

For each error type, provide specific details:
- missing_entities: List specific entities or facts that are missing
- irrelevant_path_ids: IDs of reasoning paths that are irrelevant
- long_path_ids: IDs of reasoning paths that are too long
- contradiction_path_ids: IDs of reasoning paths with contradictions

Provide specific, actionable improvement suggestions if the score is below the threshold.

Set `is_satisfactory` to true if score >= threshold.
Set `should_reroute` to true if the retrieval strategy seems wrong (e.g., context is irrelevant or missing key information)."""


def create_critic_agent(
    model: str, api_key: str | None = None, base_url: str | None = None, threshold: float = 0.8
) -> Agent[Any, StructuredCriticFeedback]:
    """Create the critic agent for response evaluation.

    Args:
        model: The LLM model name.
        api_key: Optional API key.
        base_url: Optional API base URL.
        threshold: Quality threshold for satisfaction.

    Returns:
        Configured Agent instance.
    """
    from openai import AsyncOpenAI
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    from consistent_rag.llm import resolve_llm_credentials

    key, url = resolve_llm_credentials(api_key=api_key, base_url=base_url)
    client = AsyncOpenAI(api_key=key, base_url=url)
    provider = OpenAIProvider(openai_client=client)
    chat_model = OpenAIChatModel(model, provider=provider)

    return Agent(
        chat_model,
        output_type=StructuredCriticFeedback,
        system_prompt=CRITIC_SYSTEM_PROMPT,
        retries=2,
    )


async def run_critic(
    agent: Agent[Any, StructuredCriticFeedback],
    query: str,
    context: str,
    answer_text: str,
    reasoning: str,
    threshold: float,
    path_ids: list[str] | None = None,
) -> StructuredCriticFeedback:
    """Run the critic agent to evaluate the response.

    Args:
        agent: The critic agent.
        query: The original query.
        context: The context provided to the answer agent.
        answer_text: The generated answer.
        reasoning: The reasoning provided by the answer agent.
        threshold: Quality threshold.
        path_ids: Optional list of reasoning path IDs for reference.

    Returns:
        StructuredCriticFeedback with error classification.
    """
    prompt_parts = [
        f"Query: {query}",
        f"\nContext provided:\n{context}" if context else "\nNo context was provided.",
        f"\nReasoning:\n{reasoning}" if reasoning else "\nNo reasoning provided.",
        f"\nAnswer to evaluate:\n{answer_text}",
        f"\nQuality threshold: {threshold}",
    ]

    if path_ids:
        prompt_parts.append(f"\nReasoning path IDs: {path_ids}")

    try:
        result = await agent.run("\n".join(prompt_parts))
        return result.output
    except Exception as e:
        if "content or tool_calls must be set" in str(e):
            logger.warning("DeepSeek rejected message format, retrying with fresh context...")
            result = await agent.run("\n".join(prompt_parts))
            return result.output
        raise
