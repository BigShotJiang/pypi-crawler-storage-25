"""ConsistentRAG agents package.

Each agent is a specialized pydantic-ai Agent with structured output.
All agents are organized in individual folders for discoverability.
"""

from consistent_rag.agents.answer.agent import create_answer_agent, run_answer
from consistent_rag.agents.base import MetricsCollector
from consistent_rag.agents.critic.agent import create_critic_agent, run_critic
from consistent_rag.agents.retrieval.agent import create_retrieval_agent, run_retrieval
from consistent_rag.agents.seed.agent import create_seed_agent, run_seed_extraction
from consistent_rag.agents.state import AgentStep, IterationTrace, PipelineState

__all__ = [
    "MetricsCollector",
    "PipelineState",
    "IterationTrace",
    "AgentStep",
    "create_answer_agent",
    "run_answer",
    "create_critic_agent",
    "run_critic",
    "create_retrieval_agent",
    "run_retrieval",
    "create_seed_agent",
    "run_seed_extraction",
]
