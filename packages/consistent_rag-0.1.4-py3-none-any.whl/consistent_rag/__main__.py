"""Entry point for running ConsistentRAG MCP server."""

from consistent_rag.mcp_server import main

main()
