"""No-RAG baseline pipeline for FaithEval evaluation.

Single-agent pipeline that takes provided context, applies dataset-aware
prompts, and returns structured output. No retrieval, no KG, no improvement loop.
"""

import asyncio
import os

from loguru import logger
from openai import AsyncAzureOpenAI, AsyncOpenAI
from pydantic import BaseModel, Field
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

from ...agents.common.prompts import SYSTEM_PROMPTS, get_faitheval_prompt
from ...benchmarks.faitheval import FaithEvalSample
from ...evaluation.models import FaithEvalResponse
from ...llm import _is_azure_endpoint, resolve_llm_credentials


class BaselineResponse(BaseModel):
    """Generic response for non-FaithEval benchmarks."""

    answer: str = Field(description="The answer to the question")
    reasoning: str = Field(default="", description="Reasoning for the answer")


class BaselineNoRAGPipeline:
    """No-RAG baseline: context + prompt + structured output only.

    Uses pydantic-ai for structured output generation with FaithEvalResponse.
    Selects the appropriate prompt template based on sample conflict type.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model_name: str = "gpt-4o-mini",
    ):
        resolved_key, resolved_url = resolve_llm_credentials(api_key=api_key, base_url=base_url)

        if _is_azure_endpoint(resolved_url):
            azure_endpoint = resolved_url.rstrip("/")
            if azure_endpoint.endswith("/v1"):
                azure_endpoint = azure_endpoint[:-3]
            api_version = os.getenv("AZURE_API_VERSION", "2024-10-21")
            client = AsyncAzureOpenAI(
                api_key=resolved_key,
                azure_endpoint=azure_endpoint,
                api_version=api_version,
            )
        else:
            client = AsyncOpenAI(api_key=resolved_key, base_url=resolved_url)

        self._loop: asyncio.AbstractEventLoop | None = None

        provider = OpenAIProvider(openai_client=client)
        model = OpenAIChatModel(model_name, provider=provider)

        self.agent = Agent(
            model,
            output_type=FaithEvalResponse,
            system_prompt=SYSTEM_PROMPTS["faitheval"],
        )

        # Generic agent for non-FaithEval benchmarks
        self.generic_agent = Agent(
            model,
            output_type=BaselineResponse,
            system_prompt=(
                "You are a helpful assistant that answers questions based on the "
                "provided context. Only use information from the context to answer. "
                "Be concise and direct."
            ),
        )

        logger.info(f"Initialized BaselineNoRAGPipeline with model: {model_name}")

    async def query_from_sample(self, sample: FaithEvalSample) -> FaithEvalResponse:
        """Process a FaithEval sample and return structured response.

        Args:
            sample: FaithEval sample with question, context, and conflict_type

        Returns:
            FaithEvalResponse with answer, label, reasoning, confidence
        """
        prompt = get_faitheval_prompt(sample)
        try:
            result = await self.agent.run(prompt)
        except Exception as e:
            if "content or tool_calls must be set" in str(e):
                logger.warning("DeepSeek rejected message format, retrying...")
                result = await self.agent.run(prompt)
            else:
                raise
        response = result.output
        response.prompt_used = prompt
        return response

    def query_from_sample_sync(self, sample: FaithEvalSample) -> FaithEvalResponse:
        """Synchronous wrapper for query_from_sample."""
        loop = self._get_or_create_loop()
        return loop.run_until_complete(self.query_from_sample(sample))

    async def query_without_retrieval(self, query: str, context: str) -> BaselineResponse:
        """Answer a question using provided context (any benchmark).

        Args:
            query: The question to answer
            context: Pre-provided context

        Returns:
            BaselineResponse with answer and reasoning
        """
        prompt = f"Context:\n{context}\n\nQuestion: {query}"
        result = await self.generic_agent.run(prompt)
        return result.output

    def query_without_retrieval_sync(self, query: str, context: str) -> BaselineResponse:
        """Synchronous wrapper for query_without_retrieval."""
        loop = self._get_or_create_loop()
        return loop.run_until_complete(self.query_without_retrieval(query, context))

    def _get_or_create_loop(self):
        """Get or create a persistent event loop for sync wrappers."""
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def close(self):
        """Clean up resources."""
        if self._loop is not None and not self._loop.is_closed():
            self._loop.close()
