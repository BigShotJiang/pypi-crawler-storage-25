"""Main RAG pipeline that ties together retrieval and generation."""

from loguru import logger
from pydantic import BaseModel

from ...llm import LLMClient, LLMConfig
from ...retrievers import (
    BaseRetriever,
    Document,
    RetrievalResult,
    RetrieverConfig,
    RetrieverFactory,
)


class RAGConfig(BaseModel):
    """Configuration for the RAG pipeline."""

    llm_config: LLMConfig | None = None
    retriever_config: RetrieverConfig | None = None
    top_k: int = 5


class RAGResponse(BaseModel):
    """Response from the RAG pipeline."""

    query: str
    answer: str
    context: str
    retrieved_documents: list[RetrievalResult]


class RAGPipeline:
    """Main RAG pipeline combining retrieval and generation."""

    def __init__(self, config: RAGConfig | None = None):
        if config is None:
            config = RAGConfig()

        self.config = config

        # Initialize retriever config with top_k
        retriever_config = config.retriever_config or RetrieverConfig()
        retriever_config.top_k = config.top_k

        self.retriever: BaseRetriever = RetrieverFactory.create(retriever_config)
        self.llm = LLMClient(config.llm_config)

        logger.info("Initialized RAG pipeline")

    def index_documents(self, documents: list[Document], recreate: bool = False) -> None:
        """Index documents into the vector store.

        Args:
            documents: List of documents to index
            recreate: If True, recreate the collection
        """
        self.retriever.create_collection(recreate=recreate)
        self.retriever.add_documents(documents)
        logger.info(f"Indexed {len(documents)} documents")

    def query(
        self,
        query: str,
        top_k: int | None = None,
        system_prompt: str | None = None,
    ) -> RAGResponse:
        """Run the RAG pipeline for a query.

        Args:
            query: The user's question
            top_k: Number of documents to retrieve (overrides config)
            system_prompt: Optional custom system prompt

        Returns:
            RAGResponse with answer and retrieved context
        """
        # Retrieve relevant documents
        results = self.retriever.retrieve(query, top_k=top_k)

        # Format context from retrieved documents
        context = self.retriever.format_context(results)

        # Generate answer using LLM with context
        answer = self.llm.generate_with_context(
            query=query,
            context=context,
            system_prompt=system_prompt,
        )

        return RAGResponse(
            query=query,
            answer=answer,
            context=context,
            retrieved_documents=results,
        )

    def query_without_retrieval(
        self,
        query: str,
        context: str,
        system_prompt: str | None = None,
    ) -> str:
        """Generate answer with provided context (no retrieval).

        This is useful for benchmarks that provide their own context.

        Args:
            query: The user's question
            context: Pre-provided context
            system_prompt: Optional custom system prompt

        Returns:
            Generated answer string
        """
        return self.llm.generate_with_context(
            query=query,
            context=context,
            system_prompt=system_prompt,
        )
