"""Auto-fix runtime errors in markpact projects.

When fixop is installed (pip install markpact[ops]), error classification
and port detection are delegated to fixop for richer diagnostics.
Otherwise, a local fallback is used.
"""

import os
import re
import subprocess
from pathlib import Path
from typing import Optional

from .sandbox import Sandbox, find_free_port

# Try to use fixop for richer error classification and port handling
try:
    from fixop.classify import classify_error as _fixop_classify
    from fixop.ports import is_port_free, find_free_port_near
    _HAS_FIXOP = True
except ImportError:
    _HAS_FIXOP = False

    def is_port_free(port: int, host: str = "0.0.0.0") -> bool:
        """Fallback: check if port is free."""
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
                return True
            except OSError:
                return False

    def find_free_port_near(start: int, span: int = 50) -> int | None:
        """Fallback: find free port near start."""
        for p in range(start, start + span):
            if is_port_free(p):
                return p
        return None


def detect_error_type(error_output: str, exit_code: int = 1, cmd: str = "") -> Optional[str]:
    """Detect the type of error from output.

    Delegates to fixop.classify_error when available for richer diagnostics.
    """
    if _HAS_FIXOP:
        issue = _fixop_classify(exit_code, error_output, cmd)
        cat = issue.category.value if hasattr(issue.category, 'value') else str(issue.category)
        _MAP = {"port": "port_in_use", "dependency": "missing_module", "syntax": "syntax_error", "import": "import_error"}
        return _MAP.get(cat)

    if "address already in use" in error_output.lower():
        return "port_in_use"
    if "modulenotfounderror" in error_output.lower():
        return "missing_module"
    if "syntaxerror" in error_output.lower():
        return "syntax_error"
    if "importerror" in error_output.lower():
        return "import_error"
    return None


def fix_port_in_readme(readme_path: Path, new_port: int) -> bool:
    """Update the port in a README file."""
    content = readme_path.read_text()
    
    # Replace ${MARKPACT_PORT:-XXXX} with new port
    pattern = r'\$\{MARKPACT_PORT:-\d+\}'
    replacement = f'${{MARKPACT_PORT:-{new_port}}}'
    
    new_content = re.sub(pattern, replacement, content)
    
    if new_content != content:
        readme_path.write_text(new_content)
        return True
    
    # Also try replacing --port XXXX directly
    pattern2 = r'--port\s+\d+'
    replacement2 = f'--port {new_port}'
    new_content = re.sub(pattern2, replacement2, content)
    
    if new_content != content:
        readme_path.write_text(new_content)
        return True
    
    return False


def _setup_env_with_venv_simple(sandbox: Sandbox) -> dict:
    """Setup environment with virtualenv if available."""
    env = os.environ.copy()
    if sandbox.venv_bin.exists():
        env["VIRTUAL_ENV"] = str(sandbox.venv_bin.parent)
        env["PATH"] = f"{sandbox.venv_bin}:{env.get('PATH', '')}"
    return env


def _run_and_print(cmd: str, sandbox: Sandbox, env: dict, verbose: bool) -> subprocess.CompletedProcess:
    """Run subprocess and print output. Returns result."""
    if verbose:
        print(f"[markpact] RUN: {cmd}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=sandbox.path,
            env=env,
            capture_output=True,
            text=True,
        )
    except KeyboardInterrupt:
        if verbose:
            print("\n[markpact] Stopped by user (Ctrl+C)")
        raise
    
    if result.stdout:
        print(result.stdout, end='')
    if result.stderr:
        print(result.stderr, end='')
    
    return result


def _handle_port_error_simple(
    cmd: str,
    env: dict,
    readme_path: Optional[Path],
) -> tuple[str, dict]:
    """Handle port in use error. Returns (new_cmd, new_env)."""
    new_port = find_free_port()
    print(f"\n[markpact] Port in use. Trying port {new_port}...")
    
    if readme_path and readme_path.exists():
        if fix_port_in_readme(readme_path, new_port):
            print(f"[markpact] Updated README with new port: {new_port}")
    
    new_cmd = re.sub(r'\$\{MARKPACT_PORT:-\d+\}', str(new_port), cmd)
    new_cmd = re.sub(r'--port\s+\d+', f'--port {new_port}', new_cmd)
    env["MARKPACT_PORT"] = str(new_port)
    
    return new_cmd, env


def run_with_auto_fix(
    cmd: str,
    sandbox: Sandbox,
    readme_path: Optional[Path] = None,
    verbose: bool = True,
    max_retries: int = 3,
) -> int:
    """Run command with automatic error detection and fixing.
    
    Args:
        cmd: Command to run
        sandbox: Sandbox instance
        readme_path: Path to README.md to update on fix
        verbose: Print verbose output
        max_retries: Maximum number of retry attempts
        
    Returns:
        Exit code (0 for success)
    """
    env = _setup_env_with_venv_simple(sandbox)
    current_cmd = cmd
    
    for attempt in range(max_retries + 1):
        try:
            result = _run_and_print(current_cmd, sandbox, env, verbose)
        except KeyboardInterrupt:
            return 130
        
        if result.returncode == 0:
            return 0
        
        # Detect error type
        combined_output = result.stdout + result.stderr
        error_type = detect_error_type(combined_output)
        
        if error_type == "port_in_use" and attempt < max_retries:
            current_cmd, env = _handle_port_error_simple(cmd, env, readme_path)
            continue
        
        # No auto-fix available
        return result.returncode
    
    return 1


def add_missing_dependency(readme_path: Path, module_name: str) -> bool:
    """Add a missing dependency to the README deps block."""
    content = readme_path.read_text()
    
    # Find deps block
    pattern = r'(```(?:[^\s]+\s+)?markpact:deps python[^\n]*\n)(.*?)(```)' 
    match = re.search(pattern, content, re.DOTALL)
    
    if match:
        deps_content = match.group(2)
        if module_name not in deps_content:
            new_deps = deps_content.rstrip() + f"\n{module_name}\n"
            new_content = content[:match.start(2)] + new_deps + content[match.end(2):]
            readme_path.write_text(new_content)
            return True
    
    return False


def extract_module_name(error_output: str) -> Optional[str]:
    """Extract missing module name from ModuleNotFoundError."""
    # Pattern: ModuleNotFoundError: No module named 'xyz'
    match = re.search(r"No module named ['\"]([^'\"]+)['\"]", error_output)
    if match:
        return match.group(1).split('.')[0]  # Get top-level module
    return None


def fix_with_llm(
    readme_path: Path,
    error_output: str,
    error_type: str,
    verbose: bool = True,
) -> bool:
    """Use LLM to fix errors in the README.
    
    Args:
        readme_path: Path to README.md
        error_output: Error output from failed run
        error_type: Type of error detected
        verbose: Print verbose output
        
    Returns:
        True if fix was applied, False otherwise
    """
    try:
        from .generator import generate_contract
        from .config import GeneratorConfig
    except ImportError:
        if verbose:
            print("[markpact] LLM support not available for auto-fix")
        return False
    
    content = readme_path.read_text()
    
    # Build fix prompt
    fix_prompt = f"""Fix the following error in this markpact README.

ERROR TYPE: {error_type}
ERROR OUTPUT:
{error_output[:2000]}

CURRENT README:
{content[:4000]}

Instructions:
1. Analyze the error and identify the root cause
2. Fix ONLY the problematic code block(s)
3. Return the COMPLETE fixed README with all markpact blocks
4. Do NOT add explanations, just return the fixed README content
"""
    
    try:
        config = GeneratorConfig()
        fixed_content = generate_contract(fix_prompt, config)
        
        if fixed_content and "markpact:" in fixed_content:
            readme_path.write_text(fixed_content)
            if verbose:
                print(f"[markpact] LLM applied fix for {error_type}")
            return True
    except Exception as e:
        if verbose:
            print(f"[markpact] LLM fix failed: {e}")
    
    return False


def _setup_env_with_venv(sandbox: Sandbox) -> dict:
    """Setup environment variables with virtualenv if available."""
    env = os.environ.copy()
    if sandbox.venv_bin.exists():
        env["VIRTUAL_ENV"] = str(sandbox.venv_bin.parent)
        env["PATH"] = f"{sandbox.venv_bin}:{env.get('PATH', '')}"
    return env


def _run_subprocess(cmd: str, sandbox: Sandbox, env: dict) -> subprocess.CompletedProcess:
    """Run subprocess with proper error handling."""
    return subprocess.run(
        cmd,
        shell=True,
        cwd=sandbox.path,
        env=env,
        capture_output=True,
        text=True,
    )


def _handle_port_error(
    cmd: str,
    env: dict,
    readme_path: Optional[Path],
    verbose: bool
) -> tuple[str, dict, bool]:
    """Handle port in use error. Returns (new_cmd, new_env, fixed)."""
    new_port = find_free_port()
    print(f"\n[markpact] Port in use. Trying port {new_port}...")
    
    if readme_path and readme_path.exists():
        if fix_port_in_readme(readme_path, new_port):
            print(f"[markpact] Updated README with new port: {new_port}")
    
    new_cmd = re.sub(r'\$\{MARKPACT_PORT:-\d+\}', str(new_port), cmd)
    new_cmd = re.sub(r'--port\s+\d+', f'--port {new_port}', new_cmd)
    env["MARKPACT_PORT"] = str(new_port)
    
    return new_cmd, env, True


def _handle_missing_module_error(
    error_output: str,
    sandbox: Sandbox,
    readme_path: Optional[Path],
    verbose: bool
) -> bool:
    """Handle missing module error. Returns True if fixed."""
    module_name = extract_module_name(error_output)
    if module_name and readme_path and readme_path.exists():
        print(f"\n[markpact] Missing module: {module_name}")
        if add_missing_dependency(readme_path, module_name):
            print(f"[markpact] Added {module_name} to dependencies")
            # Re-install dependencies
            from .runner import install_deps
            install_deps([module_name], sandbox, verbose)
            return True
    return False


def _try_llm_fix(
    error_type: str,
    error_output: str,
    readme_path: Optional[Path],
    verbose: bool
) -> bool:
    """Attempt LLM-based fix. Returns True if fixed."""
    if not readme_path or not readme_path.exists():
        return False
    
    print(f"\n[markpact] Attempting LLM fix for {error_type}...")
    return fix_with_llm(readme_path, error_output, error_type, verbose)


def run_with_auto_fix_llm(
    cmd: str,
    sandbox: Sandbox,
    readme_path: Optional[Path] = None,
    verbose: bool = True,
    max_retries: int = 3,
    use_llm: bool = False,
) -> int:
    """Run command with automatic error detection and fixing (with optional LLM).
    
    Args:
        cmd: Command to run
        sandbox: Sandbox instance
        readme_path: Path to README.md to update on fix
        verbose: Print verbose output
        max_retries: Maximum number of retry attempts
        use_llm: Use LLM for complex error fixes
        
    Returns:
        Exit code (0 for success)
    """
    env = _setup_env_with_venv(sandbox)
    current_cmd = cmd
    
    for attempt in range(max_retries + 1):
        if verbose:
            print(f"[markpact] RUN: {current_cmd}" + (f" (attempt {attempt + 1})" if attempt > 0 else ""))
        
        try:
            result = _run_subprocess(current_cmd, sandbox, env)
        except KeyboardInterrupt:
            if verbose:
                print("\n[markpact] Stopped by user (Ctrl+C)")
            return 130
            
        if result.stdout:
            print(result.stdout, end='')
        if result.stderr:
            print(result.stderr, end='')
        
        if result.returncode == 0:
            return 0
        
        if attempt >= max_retries:
            break
            
        combined_output = result.stdout + result.stderr
        error_type = detect_error_type(combined_output)
        
        if not error_type:
            if verbose:
                print(f"[markpact] Unknown error, cannot auto-fix")
            break
        
        fixed = False
        
        # Port in use - simple fix
        if error_type == "port_in_use":
            current_cmd, env, fixed = _handle_port_error(cmd, env, readme_path, verbose)
        
        # Missing module - add dependency
        elif error_type == "missing_module":
            fixed = _handle_missing_module_error(combined_output, sandbox, readme_path, verbose)
        
        # LLM fix for other errors
        elif use_llm:
            fixed = _try_llm_fix(error_type, combined_output, readme_path, verbose)
        
        if not fixed:
            if verbose:
                print(f"[markpact] Could not auto-fix {error_type}")
            break
    
    return result.returncode if 'result' in dir() else 1
