"""
ZenTao PMS Direct Database CLI - 直接操作禅道数据库

不需要通过 HTTP API，直接连接数据库操作。
"""

import mysql.connector
from mysql.connector import Error
import click
from typing import Optional, List, Dict, Any
import json
from tabulate import tabulate


# 数据库配置
DB_CONFIG = {
    'host': 'sdpjw-data-vpc.rwlb.rds.aliyuncs.com',
    'port': 3306,
    'database': 'zentao_21',
    'user': 'zentao',
    'password': 'bS7Ybhq@OmYfiV@5I9!9Y4p!TphOL3!0',
    'charset': 'utf8mb4'
}


def get_connection():
    """获取数据库连接"""
    return mysql.connector.connect(**DB_CONFIG)


def execute_query(sql: str, params: tuple = None) -> List[Dict]:
    """执行查询并返回结果"""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(sql, params)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def execute_update(sql: str, params: tuple = None) -> int:
    """执行更新并返回影响的行数"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(sql, params)
        conn.commit()
        return cursor.rowcount
    finally:
        cursor.close()
        conn.close()


# Click CLI
@click.group()
def cli():
    """ZenTao PMS 数据库直连 CLI"""
    pass


@cli.command()
def test():
    """测试数据库连接"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT VERSION()")
        version = cursor.fetchone()
        cursor.close()
        conn.close()
        click.echo(f"✓ 数据库连接成功！MySQL 版本: {version[0]}")
    except Error as e:
        click.echo(f"✗ 数据库连接失败: {e}")


@cli.command('user-list')
@click.option('--limit', '-l', default=20, help='显示数量')
def user_list(limit: int):
    """列出用户"""
    sql = f"SELECT id, account, realname, role, email, phone, status FROM zt_user LIMIT {limit}"
    results = execute_query(sql)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('project-list')
@click.option('--status', '-s', default='', help='状态筛选 (doing, suspended, closed)')
@click.option('--limit', '-l', default=20, help='显示数量')
def project_list(status: str, limit: int):
    """列出项目"""
    if status:
        sql = "SELECT id, name, code, status, PM, begin, end FROM zt_project WHERE type='project' AND status=%s AND deleted='0' ORDER BY id DESC LIMIT %s"
        results = execute_query(sql, (status, limit))
    else:
        sql = f"SELECT id, name, code, status, PM, begin, end FROM zt_project WHERE type='project' AND deleted='0' ORDER BY id DESC LIMIT {limit}"
        results = execute_query(sql)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('project-show')
@click.argument('project_id', type=int)
def project_show(project_id: int):
    """显示项目详情"""
    sql = "SELECT * FROM zt_project WHERE id = %s"
    results = execute_query(sql, (project_id,))
    if results:
        for key, value in results[0].items():
            click.echo(f"{key}: {value}")
    else:
        click.echo(f"未找到项目 ID: {project_id}")


@cli.command('task-list')
@click.option('--project', '-p', 'project_id', type=int, default=0, help='项目ID')
@click.option('--execution', '-e', 'execution_id', type=int, default=0, help='执行ID')
@click.option('--status', '-s', default='', help='状态筛选')
@click.option('--assigned', '-a', default='', help='指派给')
@click.option('--limit', '-l', default=20, help='显示数量')
def task_list(project_id: int, execution_id: int, status: str, assigned: str, limit: int):
    """列出任务"""
    conditions = ["deleted='0'"]
    params = []

    if project_id:
        conditions.append("project=%s")
        params.append(project_id)
    if execution_id:
        conditions.append("execution=%s")
        params.append(execution_id)
    if status:
        conditions.append("status=%s")
        params.append(status)
    if assigned:
        conditions.append("assignedTo=%s")
        params.append(assigned)

    sql = f"SELECT id, name, type, pri, status, assignedTo, estimate, consumed, `left` FROM zt_task WHERE {' AND '.join(conditions)} ORDER BY id DESC LIMIT {limit}"
    results = execute_query(sql, tuple(params) if params else None)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('task-show')
@click.argument('task_id', type=int)
def task_show(task_id: int):
    """显示任务详情"""
    sql = "SELECT * FROM zt_task WHERE id = %s"
    results = execute_query(sql, (task_id,))
    if results:
        for key, value in results[0].items():
            click.echo(f"{key}: {value}")
    else:
        click.echo(f"未找到任务 ID: {task_id}")


@cli.command('bug-list')
@click.option('--project', '-p', 'project_id', type=int, default=0, help='项目ID')
@click.option('--product', '-pr', 'product_id', type=int, default=0, help='产品ID')
@click.option('--status', '-s', default='', help='状态筛选')
@click.option('--limit', '-l', default=20, help='显示数量')
def bug_list(project_id: int, product_id: int, status: str, limit: int):
    """列出 Bug"""
    conditions = ["deleted='0'"]
    params = []

    if project_id:
        conditions.append("project=%s")
        params.append(project_id)
    if product_id:
        conditions.append("product=%s")
        params.append(product_id)
    if status:
        conditions.append("status=%s")
        params.append(status)

    sql = f"SELECT id, title, severity, pri, status, assignedTo FROM zt_bug WHERE {' AND '.join(conditions)} ORDER BY id DESC LIMIT {limit}"
    results = execute_query(sql, tuple(params) if params else None)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('bug-show')
@click.argument('bug_id', type=int)
def bug_show(bug_id: int):
    """显示 Bug 详情"""
    sql = "SELECT * FROM zt_bug WHERE id = %s"
    results = execute_query(sql, (bug_id,))
    if results:
        for key, value in results[0].items():
            click.echo(f"{key}: {value}")
    else:
        click.echo(f"未找到 Bug ID: {bug_id}")


@cli.command('story-list')
@click.option('--product', '-p', 'product_id', type=int, default=0, help='产品ID')
@click.option('--status', '-s', default='', help='状态筛选')
@click.option('--limit', '-l', default=20, help='显示数量')
def story_list(product_id: int, status: str, limit: int):
    """列出需求"""
    conditions = ["deleted='0'", "type='story'"]
    params = []

    if product_id:
        conditions.append("product=%s")
        params.append(product_id)
    if status:
        conditions.append("status=%s")
        params.append(status)

    sql = f"SELECT id, title, pri, status, stage, assignedTo FROM zt_story WHERE {' AND '.join(conditions)} ORDER BY id DESC LIMIT {limit}"
    results = execute_query(sql, tuple(params) if params else None)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('story-show')
@click.argument('story_id', type=int)
def story_show(story_id: int):
    """显示需求详情"""
    sql = "SELECT * FROM zt_story WHERE id = %s"
    results = execute_query(sql, (story_id,))
    if results:
        for key, value in results[0].items():
            click.echo(f"{key}: {value}")
    else:
        click.echo(f"未找到需求 ID: {story_id}")


@cli.command('product-list')
@click.option('--limit', '-l', default=20, help='显示数量')
def product_list(limit: int):
    """列出产品"""
    sql = f"SELECT id, name, code, status, PO, QD, RD FROM zt_product WHERE deleted='0' ORDER BY id DESC LIMIT {limit}"
    results = execute_query(sql)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('execution-list')
@click.option('--project', '-p', 'project_id', type=int, default=0, help='项目ID')
@click.option('--limit', '-l', default=20, help='显示数量')
def execution_list(project_id: int, limit: int):
    """列出执行"""
    conditions = ["deleted='0'", "type IN ('sprint', 'stage', 'kanban')"]
    params = []

    if project_id:
        conditions.append("project=%s")
        params.append(project_id)

    sql = f"SELECT id, name, project, status, begin, end FROM zt_project WHERE {' AND '.join(conditions)} ORDER BY id DESC LIMIT {limit}"
    results = execute_query(sql, tuple(params) if params else None)
    click.echo(tabulate(results, headers='keys', tablefmt='simple'))


@cli.command('sql')
@click.argument('query')
@click.option('--json', '-j', 'json_output', is_flag=True, help='JSON 输出')
def run_sql(query: str, json_output: bool):
    """执行自定义 SQL 查询 (只读)"""
    # 安全检查：只允许 SELECT
    if not query.strip().upper().startswith('SELECT'):
        click.echo("错误：只允许执行 SELECT 查询")
        return

    try:
        results = execute_query(query)
        if json_output:
            click.echo(json.dumps(results, indent=2, default=str, ensure_ascii=False))
        else:
            click.echo(tabulate(results, headers='keys', tablefmt='simple'))
    except Error as e:
        click.echo(f"SQL 错误: {e}")


if __name__ == '__main__':
    cli()