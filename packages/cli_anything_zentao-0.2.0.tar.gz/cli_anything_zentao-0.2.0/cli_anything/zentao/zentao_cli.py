"""
ZenTao PMS CLI - Main entry point.

A modern CLI interface for ZenTao Project Management System
with support for one-shot commands, REPL mode, and JSON output.
"""

import json
import sys
import click
from click_repl import repl
from prompt_toolkit.history import FileHistory
from pathlib import Path
from typing import Optional, Dict, Any

from cli_anything.zentao import __version__
from cli_anything.zentao.core import (
    Session,
    AuthenticationError,
    ProjectManager,
    TaskManager,
    BugManager,
    StoryManager,
    ProductManager,
    ExecutionManager,
    UserManager,
)


# Global session instance
_session: Optional[Session] = None


def get_session() -> Session:
    """Get or create the global session instance."""
    global _session
    if _session is None:
        _session = Session()
    return _session


def output_json(data: Any) -> None:
    """Output data as JSON to stdout."""
    click.echo(json.dumps(data, indent=2, default=str))


def output_table(data: Any, headers: list = None) -> None:
    """Output data as formatted table."""
    if isinstance(data, list):
        if len(data) == 0:
            click.echo("No results found.")
            return

        # Auto-detect headers from first item
        if headers is None and isinstance(data[0], dict):
            # Use common fields for ZenTao objects
            first = data[0]
            if 'id' in first and 'name' in first:
                headers = ['id', 'name', 'status']
                if 'pri' in first:
                    headers.append('pri')
                if 'progress' in first:
                    headers.append('progress')
                if 'assignedTo' in first:
                    headers.append('assignedTo')
                if 'begin' in first:
                    headers.append('begin')
                if 'end' in first:
                    headers.append('end')
            else:
                headers = list(first.keys())[:6]  # Limit to 6 columns

        # Calculate column widths
        widths = {}
        for h in headers:
            widths[h] = len(h)
            for row in data:
                val = str(row.get(h, ""))
                widths[h] = max(widths[h], min(len(val), 30))  # Cap width at 30

        # Print header
        header_line = " | ".join(h.ljust(widths[h]) for h in headers)
        click.echo(header_line)
        click.echo("-" * len(header_line))

        # Print rows
        for row in data:
            click.echo(" | ".join(str(row.get(h, ""))[:widths[h]].ljust(widths[h]) for h in headers))

    elif isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)) and len(str(value)) > 100:
                click.echo(f"{key}: (use --json to see full details)")
            else:
                click.echo(f"{key}: {value}")
    else:
        click.echo(data)


def format_response(response, json_output: bool = False) -> None:
    """Format and output API response."""
    if json_output:
        data = response.data if hasattr(response, 'data') else response
        output_json(data)
    else:
        if response.success:
            data = response.data if hasattr(response, 'data') else response
            # Handle ZenTao JSON view format - various list field names
            if isinstance(data, dict):
                # Single task details (check first before users)
                if 'task' in data and isinstance(data['task'], dict):
                    task = data['task']
                    click.echo(f"Task #{task.get('id', '?')}: {task.get('name', 'N/A')}")
                    click.echo(f"  Status: {task.get('status', 'N/A')}")
                    click.echo(f"  Priority: {task.get('pri', 'N/A')}")
                    click.echo(f"  Assigned: {task.get('assignedToRealName', task.get('assignedTo', 'N/A'))}")
                    click.echo(f"  Estimate: {task.get('estimate', 0)}h, Consumed: {task.get('consumed', 0)}h, Left: {task.get('left', 0)}h")
                    click.echo(f"  Execution: {task.get('execution', 'N/A')}")
                    if task.get('desc'):
                        click.echo(f"  Description: {task.get('desc', '')[:100]}...")
                # Task list from my/work
                elif 'tasks' in data and isinstance(data['tasks'], list):
                    output_table(data['tasks'])
                # Project/executions list
                elif 'executionStats' in data:
                    output_table(data['executionStats'])
                elif 'projects' in data:
                    output_table(data['projects'])
                elif 'bugs' in data:
                    output_table(data['bugs'])
                elif 'stories' in data:
                    output_table(data['stories'])
                elif 'products' in data:
                    output_table(data['products'])
                elif 'executions' in data:
                    output_table(data['executions'])
                elif 'users' in data:
                    output_table(data['users'])
                elif 'project' in data:
                    # Single project details
                    output_table(data['project'])
                elif 'pager' in data:
                    # Has pagination but no recognizable list field
                    # Try to find the main data
                    click.echo("数据获取成功。使用 --json 查看完整输出。")
                else:
                    # Single item - show details
                    output_table(data)
            elif isinstance(data, list):
                output_table(data)
            else:
                click.echo(data)
        else:
            click.echo(f"Error: {response.message}")


# Click CLI Group
@click.group(invoke_without_command=True)
@click.option('--version', '-v', is_flag=True, help='Show version information')
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def cli(ctx: click.Context, version: bool, json_output: bool):
    """ZenTao PMS CLI - Project Management from the Command Line.

    Use this tool to manage projects, tasks, bugs, and stories in ZenTao PMS.

    Examples:
        cli-anything-zentao auth login --url http://zentao.example.com --account admin
        cli-anything-zentao project list --status doing
        cli-anything-zentao task show 123 --json
        cli-anything-zentao repl
    """
    ctx.ensure_object(dict)
    ctx.obj['json_output'] = json_output

    if version:
        click.echo(f"cli-anything-zentao version {__version__}")
        return

    if ctx.invoked_subcommand is None:
        # Start REPL if no command specified
        ctx.invoke(repl_cmd)


# Authentication Commands
@cli.group('auth', help='Authentication commands')
def auth():
    """Authentication management."""
    pass


@auth.command('login')
@click.option('--url', '-u', required=True, help='ZenTao server URL')
@click.option('--account', '-a', required=True, help='User account')
@click.option('--password', '-p', required=True, help='User password')
@click.pass_context
def auth_login(ctx: click.Context, url: str, account: str, password: str):
    """Login to ZenTao PMS server.

    Example:
        cli-anything-zentao auth login --url http://zentao.example.com --account admin --password pass123

    Note: If login requires captcha, use 'auth session' command instead.
    """
    session = get_session()
    try:
        result = session.login(url, account, password)
        click.echo(f"Successfully logged in to {url}")
        click.echo(f"Token: {result['token']}")
    except AuthenticationError as e:
        click.echo(f"Login failed: {e}", err=True)
        sys.exit(1)
    except ConnectionError as e:
        click.echo(f"Connection error: {e}", err=True)
        sys.exit(1)


@auth.command('session')
@click.option('--url', '-u', required=True, help='ZenTao server URL')
@click.option('--token', '-t', required=True, help='Session ID (zentaosid from browser)')
@click.pass_context
def auth_session(ctx: click.Context, url: str, token: str):
    """Set session manually with browser session ID.

    Use this when login requires captcha.

    Steps to get session ID:
    1. Login to ZenTao in your browser
    2. Open browser DevTools (F12)
    3. Go to Application -> Cookies
    4. Find 'zentaosid' and copy its value

    Example:
        cli-anything-zentao auth session --url https://pm.sdpjw.com --token abc123xyz
    """
    session = get_session()
    try:
        result = session.set_session(url, token)
        click.echo(f"Session set successfully for {url}")
        click.echo(f"Token: {result['token']}")
    except Exception as e:
        click.echo(f"Failed to set session: {e}", err=True)
        sys.exit(1)


@auth.command('logout')
def auth_logout():
    """Logout from ZenTao PMS."""
    session = get_session()
    session.logout()
    click.echo("Logged out successfully.")


@auth.command('status')
def auth_status():
    """Show authentication status."""
    session = get_session()
    if session.is_authenticated():
        state = session.get_state()
        click.echo(f"Authenticated to: {state.url}")
        user = session.get_user()
        if user:
            click.echo(f"User: {user.get('account', 'Unknown')}")
    else:
        click.echo("Not authenticated. Use 'auth login' to login.")


# Project Commands
@cli.group('project', help='Project commands')
def project():
    """Project management."""
    pass


@project.command('list')
@click.option('--status', '-s', default='all', help='Filter by status (all, doing, suspended, closed)')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.option('--page', '-p', default=1, type=int, help='Page number')
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def project_list(ctx: click.Context, status: str, limit: int, page: int, json_output: bool):
    """List all projects.

    Example:
        cli-anything-zentao project list --status doing
        cli-anything-zentao project list --json
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = ProjectManager(session)
    response = manager.list_projects(status=status, limit=limit, page=page)
    format_response(response, json_output or ctx.obj.get('json_output', False))


@project.command('show')
@click.argument('project_id', type=int)
@click.option('--fields', '-f', default='', help='Additional fields (team,products,stat,workhour)')
@click.pass_context
def project_show(ctx: click.Context, project_id: int, fields: str):
    """Show project details.

    Example:
        cli-anything-zentao project show 123 --fields team,products
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = ProjectManager(session)
    response = manager.get_project(project_id, fields=fields)
    format_response(response, ctx.obj.get('json_output', False))


@project.command('create')
@click.option('--name', '-n', required=True, help='Project name')
@click.option('--begin', '-b', required=True, help='Start date (YYYY-MM-DD)')
@click.option('--end', '-e', required=True, help='End date (YYYY-MM-DD)')
@click.option('--acl', default='private', help='Access control (private, open)')
@click.option('--pm', default='', help='Project manager account')
@click.option('--desc', '-d', default='', help='Project description')
@click.pass_context
def project_create(ctx: click.Context, name: str, begin: str, end: str, acl: str, pm: str, desc: str):
    """Create a new project.

    Example:
        cli-anything-zentao project create --name "New Project" --begin 2024-01-01 --end 2024-03-31
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = ProjectManager(session)
    response = manager.create_project(name=name, begin=begin, end=end, acl=acl, pm=pm, desc=desc)
    format_response(response, ctx.obj.get('json_output', False))


@project.command('update')
@click.argument('project_id', type=int)
@click.option('--name', '-n', help='New project name')
@click.option('--begin', '-b', help='New start date')
@click.option('--end', '-e', help='New end date')
@click.pass_context
def project_update(ctx: click.Context, project_id: int, name: str, begin: str, end: str):
    """Update a project.

    Example:
        cli-anything-zentao project update 123 --name "Updated Name"
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = ProjectManager(session)
    response = manager.update_project(project_id, name=name, begin=begin, end=end)
    format_response(response, ctx.obj.get('json_output', False))


@project.command('delete')
@click.argument('project_id', type=int)
@click.confirmation_option(prompt='Are you sure you want to delete this project?')
@click.pass_context
def project_delete(ctx: click.Context, project_id: int):
    """Delete a project.

    Example:
        cli-anything-zentao project delete 123
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = ProjectManager(session)
    response = manager.delete_project(project_id)
    if response.success:
        click.echo(f"Project {project_id} deleted successfully.")
    else:
        click.echo(f"Failed to delete project: {response.message}", err=True)


# Task Commands
@cli.group('task', help='Task commands')
def task():
    """Task management."""
    pass


@task.command('list')
@click.option('--execution', '-e', 'execution_id', type=int, default=0, help='Execution ID')
@click.option('--status', '-s', default='all', help='Task status (all, wait, doing, done, closed)')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def task_list(ctx: click.Context, execution_id: int, status: str, limit: int, json_output: bool):
    """List tasks.

    Example:
        cli-anything-zentao task list --execution 123 --status doing
        cli-anything-zentao task list --json
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.list_tasks(execution_id=execution_id, status=status, limit=limit)
    format_response(response, json_output or ctx.obj.get('json_output', False))


@task.command('show')
@click.argument('task_id', type=int)
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def task_show(ctx: click.Context, task_id: int, json_output: bool):
    """Show task details.

    Example:
        cli-anything-zentao task show 456
        cli-anything-zentao task show 456 --json
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.get_task(task_id)
    format_response(response, json_output or ctx.obj.get('json_output', False))


@task.command('create')
@click.option('--execution', '-e', 'execution_id', required=True, type=int, help='Execution ID')
@click.option('--name', '-n', required=True, help='Task name')
@click.option('--assigned', '-a', 'assigned_to', required=True, help='Assignee account')
@click.option('--type', '-t', default='devel', help='Task type (devel, test, design, etc.)')
@click.option('--pri', '-p', default=3, type=int, help='Priority (1-4)')
@click.option('--estimate', default=0, type=float, help='Estimated hours')
@click.option('--product', type=int, default=0, help='Product ID')
@click.pass_context
def task_create(ctx: click.Context, execution_id: int, name: str, assigned_to: str, type: str, pri: int, estimate: float, product: int):
    """Create a new task.

    Example:
        cli-anything-zentao task create --execution 123 --name "Implement feature" --assigned user1
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.create_task(
        execution_id=execution_id,
        name=name,
        assigned_to=assigned_to,
        type=type,
        pri=pri,
        estimate=estimate,
        product=product if product else None
    )
    format_response(response, ctx.obj.get('json_output', False))


@task.command('assign')
@click.argument('task_id', type=int)
@click.option('--assigned', '-a', 'assigned_to', required=True, help='Account to assign to')
@click.pass_context
def task_assign(ctx: click.Context, task_id: int, assigned_to: str):
    """Assign task to a user.

    Example:
        cli-anything-zentao task assign 456 --assigned user2
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.assign(task_id, assigned_to)
    format_response(response, ctx.obj.get('json_output', False))


@task.command('start')
@click.argument('task_id', type=int)
@click.option('--consumed', default=0, type=float, help='Consumed hours')
@click.option('--left', type=float, help='Remaining hours')
@click.pass_context
def task_start(ctx: click.Context, task_id: int, consumed: float, left: float):
    """Start a task.

    Example:
        cli-anything-zentao task start 456
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.start(task_id, consumed=consumed, left=left)
    format_response(response, ctx.obj.get('json_output', False))


@task.command('finish')
@click.argument('task_id', type=int)
@click.option('--consumed', default=0, type=float, help='Total consumed hours')
@click.option('--left', default=0, type=float, help='Remaining hours')
@click.pass_context
def task_finish(ctx: click.Context, task_id: int, consumed: float, left: float):
    """Finish a task.

    Example:
        cli-anything-zentao task finish 456
        cli-anything-zentao task finish 456 --consumed 8
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.finish(task_id, consumed=consumed, left=left)

    if response.success:
        click.echo(f"Task {task_id} finished successfully.")
    else:
        click.echo(f"Failed to finish task: {response.message}", err=True)
        if response.data and isinstance(response.data, dict):
            # Show any validation errors
            errors = response.data.get('errors', {})
            if errors:
                for field, msg in errors.items():
                    click.echo(f"  {field}: {msg}", err=True)


@task.command('log')
@click.argument('task_id', type=int)
@click.option('--consumed', '-c', required=True, type=float, help='Hours consumed in this session')
@click.option('--left', '-l', required=True, type=float, help='Remaining hours')
@click.option('--work', '-w', default='', help='Work description')
@click.option('--date', '-d', default='', help='Date for the record (YYYY-MM-DD, defaults to today)')
@click.pass_context
def task_log(ctx: click.Context, task_id: int, consumed: float, left: float, work: str, date: str):
    """Log work effort on a task.

    Example:
        cli-anything-zentao task log 456 --consumed 2 --left 18
        cli-anything-zentao task log 456 --consumed 4 --left 14 --work "Implemented feature X"
        cli-anything-zentao task log 456 --consumed 3 --left 15 --date 2026-03-28
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)
    response = manager.record_estimate(task_id, consumed=consumed, left=left, work=work, date=date)

    if response.success:
        from datetime import datetime
        record_date = date if date else datetime.now().strftime('%Y-%m-%d')
        click.echo(f"Logged {consumed}h on task {task_id} for {record_date}. Remaining: {left}h")
    else:
        click.echo(f"Failed to log effort: {response.message}", err=True)


@task.command('close')
@click.argument('task_id', type=int)
@click.option('--comment', '-c', default='', help='Comment for closing')
@click.option('--force', '-f', is_flag=True, help='Force close (finish first if needed)')
@click.pass_context
def task_close(ctx: click.Context, task_id: int, comment: str, force: bool):
    """Close a task.

    Note: Task must be in 'done' or 'cancel' status before closing.
    Use --force to automatically finish the task first if needed.

    Example:
        cli-anything-zentao task close 456
        cli-anything-zentao task close 456 --comment "Task completed"
        cli-anything-zentao task close 456 --force
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = TaskManager(session)

    # First, get the task to check its status
    task_response = manager.get_task(task_id)
    if not task_response.success:
        click.echo(f"Failed to get task {task_id}: {task_response.message}", err=True)
        sys.exit(1)

    task_data = task_response.data
    if isinstance(task_data, dict):
        task_status = task_data.get('task', {}).get('status', '')
        if isinstance(task_data.get('task'), dict):
            task_name = task_data.get('task', {}).get('name', f'Task {task_id}')
        else:
            task_name = f'Task {task_id}'
    else:
        task_status = ''
        task_name = f'Task {task_id}'

    # Check if task can be closed
    if task_status and task_status not in ('done', 'cancel', 'closed'):
        if force:
            click.echo(f"Task status is '{task_status}', finishing first...")
            finish_response = manager.finish(task_id)
            if not finish_response.success:
                click.echo(f"Failed to finish task: {finish_response.message}", err=True)
                sys.exit(1)
            click.echo(f"Task finished successfully.")
        else:
            click.echo(f"Cannot close task: status is '{task_status}'.", err=True)
            click.echo("Task must be 'done' or 'cancel' status before closing.")
            click.echo("Use --force to automatically finish first, or run:")
            click.echo(f"  cli-anything-zentao task finish {task_id}")
            sys.exit(1)

    if task_status == 'closed':
        click.echo(f"Task {task_id} is already closed.")
        return

    response = manager.close(task_id, comment=comment)

    # Check if the response indicates success
    if response.success:
        click.echo(f"Task {task_id} ({task_name}) closed successfully.")
    else:
        click.echo(f"Failed to close task: {response.message}", err=True)
        if ctx.obj.get('json_output'):
            output_json(response.data)


# Bug Commands
@cli.group('bug', help='Bug commands')
def bug():
    """Bug management."""
    pass


@bug.command('list')
@click.option('--product', type=int, default=0, help='Product ID')
@click.option('--status', '-s', default='all', help='Bug status (all, active, resolved, closed)')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.pass_context
def bug_list(ctx: click.Context, product: int, status: str, limit: int):
    """List bugs.

    Example:
        cli-anything-zentao bug list --product 123 --status active
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = BugManager(session)
    response = manager.list_bugs(product_id=product, status=status, limit=limit)
    format_response(response, ctx.obj.get('json_output', False))


@bug.command('show')
@click.argument('bug_id', type=int)
@click.pass_context
def bug_show(ctx: click.Context, bug_id: int):
    """Show bug details.

    Example:
        cli-anything-zentao bug show 789
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = BugManager(session)
    response = manager.get_bug(bug_id)
    format_response(response, ctx.obj.get('json_output', False))


@bug.command('create')
@click.option('--title', '-t', required=True, help='Bug title')
@click.option('--product', '-p', required=True, type=int, help='Product ID')
@click.option('--assigned', '-a', 'assigned_to', default='', help='Assignee account')
@click.option('--pri', default=3, type=int, help='Priority (1-4)')
@click.option('--severity', default=3, type=int, help='Severity (1-4)')
@click.pass_context
def bug_create(ctx: click.Context, title: str, product: int, assigned_to: str, pri: int, severity: int):
    """Create a new bug.

    Example:
        cli-anything-zentao bug create --title "Login fails" --product 123
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' or 'auth session' first.", err=True)
        sys.exit(1)

    manager = BugManager(session)
    response = manager.create_bug(
        title=title,
        product=product,
        assigned_to=assigned_to,
        pri=pri,
        severity=severity
    )
    format_response(response, ctx.obj.get('json_output', False))


@bug.command('resolve')
@click.argument('bug_id', type=int)
@click.option('--resolution', '-r', default='fixed', help='Resolution (fixed, wontfix, etc.)')
@click.pass_context
def bug_resolve(ctx: click.Context, bug_id: int, resolution: str):
    """Resolve a bug.

    Example:
        cli-anything-zentao bug resolve 789 --resolution fixed
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = BugManager(session)
    response = manager.resolve(bug_id, resolution=resolution)
    format_response(response, ctx.obj.get('json_output', False))


@bug.command('close')
@click.argument('bug_id', type=int)
@click.pass_context
def bug_close(ctx: click.Context, bug_id: int):
    """Close a bug.

    Example:
        cli-anything-zentao bug close 789
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = BugManager(session)
    response = manager.close(bug_id)
    format_response(response, ctx.obj.get('json_output', False))


# Story Commands
@cli.group('story', help='Story/requirement commands')
def story():
    """Story management."""
    pass


@story.command('list')
@click.option('--product', type=int, default=0, help='Product ID')
@click.option('--status', '-s', default='all', help='Story status (all, active, closed)')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.pass_context
def story_list(ctx: click.Context, product: int, status: str, limit: int):
    """List stories.

    Example:
        cli-anything-zentao story list --product 123
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = StoryManager(session)
    response = manager.list_stories(product_id=product, status=status, limit=limit)
    format_response(response, ctx.obj.get('json_output', False))


@story.command('show')
@click.argument('story_id', type=int)
@click.pass_context
def story_show(ctx: click.Context, story_id: int):
    """Show story details.

    Example:
        cli-anything-zentao story show 100
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = StoryManager(session)
    response = manager.get_story(story_id)
    format_response(response, ctx.obj.get('json_output', False))


@story.command('create')
@click.option('--title', '-t', required=True, help='Story title')
@click.option('--product', '-p', required=True, type=int, help='Product ID')
@click.option('--pri', default=3, type=int, help='Priority (1-4)')
@click.pass_context
def story_create(ctx: click.Context, title: str, product: int, pri: int):
    """Create a new story.

    Example:
        cli-anything-zentao story create --title "New feature" --product 123
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = StoryManager(session)
    response = manager.create_story(title=title, product=product, pri=pri)
    format_response(response, ctx.obj.get('json_output', False))


@story.command('close')
@click.argument('story_id', type=int)
@click.pass_context
def story_close(ctx: click.Context, story_id: int):
    """Close a story.

    Example:
        cli-anything-zentao story close 100
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = StoryManager(session)
    response = manager.close(story_id)
    format_response(response, ctx.obj.get('json_output', False))


# Product Commands
@cli.group('product', help='Product commands')
def product():
    """Product management."""
    pass


@product.command('list')
@click.option('--status', '-s', default='all', help='Product status (all, normal, closed)')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.pass_context
def product_list(ctx: click.Context, status: str, limit: int):
    """List products.

    Example:
        cli-anything-zentao product list
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = ProductManager(session)
    response = manager.list_products(status=status, limit=limit)
    format_response(response, ctx.obj.get('json_output', False))


@product.command('show')
@click.argument('product_id', type=int)
@click.pass_context
def product_show(ctx: click.Context, product_id: int):
    """Show product details.

    Example:
        cli-anything-zentao product show 123
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = ProductManager(session)
    response = manager.get_product(product_id)
    format_response(response, ctx.obj.get('json_output', False))


# User Commands
@cli.group('user', help='User commands')
def user():
    """User management."""
    pass


@user.command('list')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.pass_context
def user_list(ctx: click.Context, limit: int):
    """List users.

    Example:
        cli-anything-zentao user list
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = UserManager(session)
    response = manager.list_users(limit=limit)

    if ctx.obj.get('json_output'):
        output_json(response.data)
    else:
        if response.success and response.data:
            # Extract users from the response (simple account->name mapping)
            users = response.data.get('users', {})
            if users:
                click.echo("id | account        | name")
                click.echo("-" * 35)
                for account, name in users.items():
                    click.echo(f"{account[:15]:<15} | {name}")
            else:
                click.echo("No users found.")
        else:
            click.echo(f"Error: {response.message}")


@user.command('me')
@click.pass_context
def user_me(ctx: click.Context):
    """Show current user info.

    Example:
        cli-anything-zentao user me
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = UserManager(session)
    response = manager.me()
    format_response(response, ctx.obj.get('json_output', False))


# Execution Commands
@cli.group('execution', help='Execution (sprint) commands')
def execution():
    """Execution management."""
    pass


@execution.command('list')
@click.option('--project', type=int, default=0, help='Project ID')
@click.option('--status', '-s', default='all', help='Execution status')
@click.option('--limit', '-l', default=100, type=int, help='Number of results')
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def execution_list(ctx: click.Context, project: int, status: str, limit: int, json_output: bool):
    """List executions.

    Example:
        cli-anything-zentao execution list --project 123
        cli-anything-zentao execution list --json
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = ExecutionManager(session)
    response = manager.list_executions(project_id=project, status=status, limit=limit)
    format_response(response, json_output or ctx.obj.get('json_output', False))


@execution.command('show')
@click.argument('execution_id', type=int)
@click.option('--json', '-j', 'json_output', is_flag=True, help='Output in JSON format')
@click.pass_context
def execution_show(ctx: click.Context, execution_id: int, json_output: bool):
    """Show execution details.

    Example:
        cli-anything-zentao execution show 456
        cli-anything-zentao execution show 456 --json
    """
    session = get_session()
    if not session.is_authenticated():
        click.echo("Not authenticated. Use 'auth login' first.", err=True)
        sys.exit(1)

    manager = ExecutionManager(session)
    response = manager.get_execution(execution_id)
    format_response(response, json_output or ctx.obj.get('json_output', False))


# REPL Command
@cli.command('repl', help='Start interactive REPL mode')
@click.pass_context
def repl_cmd(ctx: click.Context):
    """Start interactive REPL mode.

    Example:
        cli-anything-zentao repl
    """
    click.echo("ZenTao PMS CLI - Interactive Mode")
    click.echo("Type 'help' for available commands, 'exit' to quit.")
    click.echo()

    # Get history file path
    history_file = Path.home() / ".config" / "cli-anything-zentao" / "repl_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    prompt_kwargs = {
        'history': FileHistory(str(history_file)),
        'message': 'zentao> ',
    }

    repl(ctx, prompt_kwargs=prompt_kwargs)


def main():
    """Main entry point."""
    cli(obj={})


if __name__ == '__main__':
    main()