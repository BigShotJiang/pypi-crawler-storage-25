"""
Story (requirement) management for ZenTao PMS CLI.

Provides CRUD operations and status changes for stories.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from cli_anything.zentao.core.api_client import APIClient, APIResponse, NotFoundError


class StoryManager(APIClient):
    """
    Manager for ZenTao stories (requirements).

    Provides methods for listing, creating, updating, and managing story status.
    """

    ENDPOINT = "stories"

    def list_stories(
        self,
        product_id: int = 0,
        project_id: int = 0,
        execution_id: int = 0,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc",
        type: str = "story"
    ) -> APIResponse:
        """
        List stories.

        Args:
            product_id: Product ID to filter
            project_id: Project ID to filter
            execution_id: Execution ID to filter
            status: Story status filter (all, draft, active, changed, reviewing, closed)
            limit: Number of results per page
            page: Page number
            order: Sort order
            type: Story type (story, requirement)

        Returns:
            APIResponse with list of stories
        """
        # Use JSON view format
        endpoint = "m=story&f=admin"
        params = {"t": "json"}

        if product_id:
            endpoint = f"m=story&f=admin&productID={product_id}"
        if status != "all":
            params["status"] = status

        return super().get(endpoint, params=params, use_api=False)

    def get_story(self, story_id: int, type: str = "story") -> APIResponse:
        """
        Get story details.

        Args:
            story_id: Story ID
            type: Story type (story, requirement)

        Returns:
            APIResponse with story details
        """
        # Use JSON view format
        endpoint = f"m=story&f=view&id={story_id}"
        params = {"type": type, "t": "json"}
        return super().get(endpoint, params=params, use_api=False)

    def create_story(
        self,
        title: str,
        product: int,
        type: str = "story",
        pri: int = 3,
        estimate: float = 0.0,
        module: int = 0,
        plan: str = "",
        source: str = "",
        category: str = "",
        desc: str = "",
        reviewer: str = "",
        **kwargs
    ) -> APIResponse:
        """
        Create a new story.

        Args:
            title: Story title
            product: Product ID (required)
            type: Story type (story, requirement)
            pri: Priority (1-4)
            estimate: Estimated hours
            module: Module ID
            plan: Product plan ID(s)
            source: Story source (customer, user, competitor, etc.)
            category: Story category
            desc: Story description
            reviewer: Reviewer account(s)
            **kwargs: Additional fields

        Returns:
            APIResponse with created story
        """
        data = {
            "title": title,
            "product": product,
            "type": type,
            "pri": pri,
            "estimate": estimate,
            **kwargs
        }
        if module:
            data["module"] = module
        if plan:
            data["plan"] = plan
        if source:
            data["source"] = source
        if category:
            data["category"] = category
        if desc:
            data["desc"] = desc
        if reviewer:
            data["reviewer"] = reviewer

        return super().post(self.ENDPOINT, data=data)

    def update_story(
        self,
        story_id: int,
        title: Optional[str] = None,
        pri: Optional[int] = None,
        estimate: Optional[float] = None,
        module: Optional[int] = None,
        plan: Optional[str] = None,
        desc: Optional[str] = None,
        stage: Optional[str] = None,
        **kwargs
    ) -> APIResponse:
        """
        Update an existing story.

        Args:
            story_id: Story ID
            title: New title
            pri: New priority
            estimate: New estimate
            module: New module
            plan: New plan
            desc: New description
            stage: New stage (planned, projected, developing, developed, testing, tested, released)
            **kwargs: Additional fields

        Returns:
            APIResponse with updated story
        """
        data = {}
        if title:
            data["title"] = title
        if pri:
            data["pri"] = pri
        if estimate:
            data["estimate"] = estimate
        if module:
            data["module"] = module
        if plan:
            data["plan"] = plan
        if desc:
            data["desc"] = desc
        if stage:
            data["stage"] = stage
        data.update(kwargs)

        endpoint = f"story/{story_id}"
        return super().put(endpoint, data=data)

    def delete_story(self, story_id: int) -> APIResponse:
        """
        Delete a story.

        Args:
            story_id: Story ID

        Returns:
            APIResponse indicating success
        """
        endpoint = f"story/{story_id}"
        return super().delete(endpoint)

    def assign(self, story_id: int, assigned_to: str) -> APIResponse:
        """
        Assign story to a user.

        Args:
            story_id: Story ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storyassignto/{story_id}"
        data = {"assignedTo": assigned_to}
        return super().post(endpoint, data=data)

    def change(self, story_id: int, title: str = "", desc: str = "", **kwargs) -> APIResponse:
        """
        Change a story (request modification).

        Args:
            story_id: Story ID
            title: New title
            desc: Change description
            **kwargs: Additional fields

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storychange/{story_id}"
        data = {}
        if title:
            data["title"] = title
        if desc:
            data["desc"] = desc
        data.update(kwargs)
        return super().post(endpoint, data=data)

    def review(
        self,
        story_id: int,
        result: str = "pass",
        reviewed_by: str = ""
    ) -> APIResponse:
        """
        Review a story.

        Args:
            story_id: Story ID
            result: Review result (pass, revert, clarify, reject)
            reviewed_by: Reviewer account

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storyreview/{story_id}"
        data = {"result": result}
        if reviewed_by:
            data["reviewedBy"] = reviewed_by
        return super().post(endpoint, data=data)

    def close(self, story_id: int, reason: str = "done", comment: str = "") -> APIResponse:
        """
        Close a story.

        Args:
            story_id: Story ID
            reason: Close reason (done, cancel, closedByParent)
            comment: Close comment

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storyclose/{story_id}"
        data = {"reason": reason}
        if comment:
            data["comment"] = comment
        return super().post(endpoint, data=data)

    def activate(self, story_id: int, assigned_to: str = "") -> APIResponse:
        """
        Activate a closed story.

        Args:
            story_id: Story ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storyactive/{story_id}"
        data = {}
        if assigned_to:
            data["assignedTo"] = assigned_to
        return super().post(endpoint, data=data)

    def recall(self, story_id: int) -> APIResponse:
        """
        Recall a submitted/reviewing story.

        Args:
            story_id: Story ID

        Returns:
            APIResponse with updated story
        """
        endpoint = f"storyrecall/{story_id}"
        return super().post(endpoint)