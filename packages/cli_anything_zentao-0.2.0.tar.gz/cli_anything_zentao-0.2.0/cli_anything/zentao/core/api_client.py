"""
Base API client for ZenTao PMS.

Provides common HTTP operations for interacting with ZenTao.

Note: ZenTao's REST API (/api.php/v1/) may require special configuration.
This client also supports the JSON view format (?t=json) for page requests.
"""

import json
import time
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
import requests

from cli_anything.zentao.core.session import Session, SessionExpiredError, AuthenticationError


@dataclass
class APIResponse:
    """Standardized API response wrapper."""
    success: bool
    status_code: int
    data: Any
    message: str = ""
    page: Optional[int] = None
    total: Optional[int] = None
    limit: Optional[int] = None

    @classmethod
    def from_response(cls, response: requests.Response, use_api: bool = True) -> "APIResponse":
        """Create APIResponse from requests.Response."""
        # Debug: Check if response is empty
        if not response.text:
            return cls(
                success=False,
                status_code=response.status_code,
                data=None,
                message="Empty response from server",
                page=None,
                total=None,
                limit=None
            )

        try:
            body = response.json()
        except json.JSONDecodeError:
            return cls(
                success=False,
                status_code=response.status_code,
                data=response.text[:500],  # Include partial text for debugging
                message=f"Invalid JSON response: {response.text[:100]}...",
                page=None,
                total=None,
                limit=None
            )

        # ZenTao JSON view format: {"status": "success", "data": "json_string", "md5": "..."}
        # The data field contains a nested JSON string that needs to be parsed
        # For POST actions: {"result": "success"} or {"result": "fail", "message": "..."}
        if not use_api and isinstance(body, dict):
            # Handle POST action response (result field)
            if 'result' in body:
                success = body.get('result') == 'success'
                message = body.get('message', '')
                return cls(
                    success=success,
                    status_code=response.status_code,
                    data=body,
                    message=message,
                    page=None,
                    total=None,
                    limit=None
                )

            if body.get('status') == 'success' and 'data' in body:
                # Parse the nested JSON data string
                try:
                    inner_data = json.loads(body['data'])
                except (json.JSONDecodeError, TypeError):
                    inner_data = body['data']

                success = True
                message = ""

                # Pagination info from ZenTao JSON view
                pager = inner_data.get('pager') or {}
                page = pager.get('pageID')
                total = pager.get('recTotal')
                limit = pager.get('recPerPage')

                return cls(
                    success=success,
                    status_code=response.status_code,
                    data=inner_data,
                    message=message,
                    page=page,
                    total=total,
                    limit=limit
                )

        # ZenTao REST API format (may not be available on all installations)
        data = body.get('data', body)
        message = body.get('message', "")

        # Pagination info
        page = body.get('page')
        total = body.get('total')
        limit = body.get('limit')

        # Determine success
        success = response.status_code < 400 and body.get('status', '') != 'fail'

        return cls(
            success=success,
            status_code=response.status_code,
            data=data,
            message=message,
            page=page,
            total=total,
            limit=limit
        )


class APIClient:
    """
    Base API client for ZenTao PMS.

    Supports both REST API (/api.php/v1/) and JSON view format (?t=json).
    """

    API_PREFIX = "/api.php/v1"

    def __init__(self, session: Session):
        """
        Initialize API client with session.

        Args:
            session: Session instance for authentication
        """
        self.session = session
        # Use requests.Session to maintain cookies and connection
        self._http_session = requests.Session()
        # Set cookies on the session
        for name, value in session.get_cookies().items():
            self._http_session.cookies.set(name, value)

    def _get_endpoint_url(self, endpoint: str, use_api: bool = True) -> str:
        """Build full endpoint URL."""
        base_url = self.session.get_url()
        if not base_url:
            raise AuthenticationError("Not authenticated. Please login first.")
        endpoint = endpoint.lstrip('/')
        if use_api:
            return f"{base_url}{self.API_PREFIX}/{endpoint}"
        else:
            return f"{base_url}/index.php?{endpoint}"

    def _handle_error(self, response: requests.Response) -> None:
        """Handle API error responses."""
        if response.status_code == 401:
            raise AuthenticationError("Authentication failed or session expired")
        if response.status_code == 404:
            raise NotFoundError(f"Resource not found: {response.url}")
        if response.status_code == 403:
            raise PermissionError("Permission denied for this operation")
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get('message', f"API error: {response.status_code}")
            except json.JSONDecodeError:
                message = f"API error: {response.status_code}"
            raise APIError(message)

    def request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 30,
        retries: int = 3,
        use_api: bool = True,
        debug: bool = False
    ) -> APIResponse:
        """
        Make API request with retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint path
            params: Query parameters
            data: Request body data
            timeout: Request timeout in seconds
            retries: Number of retry attempts
            use_api: If True, use /api.php/v1/ prefix; if False, use index.php

        Returns:
            APIResponse object
        """
        url = self._get_endpoint_url(endpoint, use_api)
        headers = self.session.get_headers()

        # Add JSON format for non-API requests
        if not use_api:
            if params is None:
                params = {}
            params['t'] = 'json'
            # For POST requests to JSON view, use form data instead of JSON body
            if method == "POST" and data:
                headers["Content-Type"] = "application/x-www-form-urlencoded"
                # Add Referer header to pass CSRF check
                headers["Referer"] = url.split('?')[0]

        for attempt in range(retries):
            try:
                # For non-API POST with data, use form-encoded data
                if not use_api and method == "POST" and data:
                    response = self._http_session.request(
                        method=method,
                        url=url,
                        params=params,
                        data=data,  # form-encoded data
                        headers=headers,
                        timeout=timeout
                    )
                else:
                    response = self._http_session.request(
                        method=method,
                        url=url,
                        params=params,
                        json=data if data else None,
                        headers=headers,
                        timeout=timeout
                    )

                if response.status_code in (401, 403):
                    self._handle_error(response)

                return APIResponse.from_response(response, use_api=use_api)

            except requests.exceptions.Timeout:
                if attempt == retries - 1:
                    raise ConnectionError(f"Request timeout after {retries} attempts")
                time.sleep(1)

            except requests.exceptions.ConnectionError as e:
                if attempt == retries - 1:
                    raise ConnectionError(f"Connection error: {e}")
                time.sleep(1)

        raise ConnectionError("Failed to complete request")

    def get(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        use_api: bool = True
    ) -> APIResponse:
        """GET request."""
        return self.request("GET", endpoint, params=params, use_api=use_api)

    def post(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        use_api: bool = True
    ) -> APIResponse:
        """POST request."""
        return self.request("POST", endpoint, data=data, use_api=use_api)

    def put(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        use_api: bool = True
    ) -> APIResponse:
        """PUT request."""
        return self.request("PUT", endpoint, data=data, use_api=use_api)

    def delete(self, endpoint: str, use_api: bool = True) -> APIResponse:
        """DELETE request."""
        return self.request("DELETE", endpoint, use_api=use_api)


class APIError(Exception):
    """General API error."""
    pass


class NotFoundError(APIError):
    """Resource not found (404)."""
    pass


class PermissionError(APIError):
    """Permission denied (403)."""
    pass