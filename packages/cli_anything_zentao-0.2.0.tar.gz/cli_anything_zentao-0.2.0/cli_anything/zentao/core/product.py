"""
Product management for ZenTao PMS CLI.

Provides CRUD operations for products.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from cli_anything.zentao.core.api_client import APIClient, APIResponse, NotFoundError


class ProductManager(APIClient):
    """
    Manager for ZenTao products.

    Products are the top-level containers for stories, bugs, and test cases.
    """

    ENDPOINT = "products"

    def list_products(
        self,
        program_id: int = 0,
        project_id: int = 0,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "order_asc",
        with_user: bool = False,
        merge_children: bool = False
    ) -> APIResponse:
        """
        List products.

        Args:
            program_id: Program (portfolio) ID to filter
            project_id: Project ID to filter linked products
            status: Product status filter (all, normal, closed)
            limit: Number of results per page
            page: Page number
            order: Sort order
            with_user: Include user information
            merge_children: Merge children products structure

        Returns:
            APIResponse with list of products
        """
        # Use JSON view format instead of REST API
        endpoint = "m=product&f=all"
        params = {"t": "json"}

        if status != "all":
            params["status"] = status

        return super().get(endpoint, params=params, use_api=False)

    def get_product(self, product_id: int) -> APIResponse:
        """
        Get product details.

        Args:
            product_id: Product ID

        Returns:
            APIResponse with product details
        """
        # Use JSON view format
        endpoint = f"m=product&f=view&id={product_id}"
        return super().get(endpoint, use_api=False)

    def create_product(
        self,
        name: str,
        program: int = 0,
        line: int = 0,
        po: str = "",
        qd: str = "",
        rd: str = "",
        type: str = "normal",
        acl: str = "private",
        desc: str = "",
        whitelist: str = "",
        **kwargs
    ) -> APIResponse:
        """
        Create a new product.

        Args:
            name: Product name (required)
            program: Parent program ID
            line: Product line ID
            po: Product owner account
            qd: Quality director account
            rd: Release director account
            type: Product type (normal, branch, platform)
            acl: Access control (private, open, custom)
            desc: Product description
            whitelist: Whitelist accounts for custom ACL
            **kwargs: Additional fields

        Returns:
            APIResponse with created product
        """
        data = {
            "name": name,
            "program": program,
            "line": line,
            "type": type,
            "acl": acl,
            **kwargs
        }
        if po:
            data["PO"] = po
        if qd:
            data["QD"] = qd
        if rd:
            data["RD"] = rd
        if desc:
            data["desc"] = desc
        if whitelist:
            data["whitelist"] = whitelist

        return super().post(self.ENDPOINT, data=data)

    def update_product(
        self,
        product_id: int,
        name: Optional[str] = None,
        po: Optional[str] = None,
        qd: Optional[str] = None,
        rd: Optional[str] = None,
        type: Optional[str] = None,
        acl: Optional[str] = None,
        desc: Optional[str] = None,
        status: Optional[str] = None,
        **kwargs
    ) -> APIResponse:
        """
        Update an existing product.

        Args:
            product_id: Product ID
            name: New name
            po: New product owner
            qd: New quality director
            rd: New release director
            type: New type
            acl: New access control
            desc: New description
            status: New status
            **kwargs: Additional fields

        Returns:
            APIResponse with updated product
        """
        data = {}
        if name:
            data["name"] = name
        if po:
            data["PO"] = po
        if qd:
            data["QD"] = qd
        if rd:
            data["RD"] = rd
        if type:
            data["type"] = type
        if acl:
            data["acl"] = acl
        if desc:
            data["desc"] = desc
        if status:
            data["status"] = status
        data.update(kwargs)

        endpoint = f"product/{product_id}"
        return super().put(endpoint, data=data)

    def close(self, product_id: int) -> APIResponse:
        """
        Close a product.

        Args:
            product_id: Product ID

        Returns:
            APIResponse with updated product
        """
        endpoint = f"product/{product_id}"
        return super().put(endpoint, data={"status": "closed"})

    def get_projects(self, product_id: int) -> APIResponse:
        """
        Get projects linked to a product.

        Args:
            product_id: Product ID

        Returns:
            APIResponse with project list
        """
        endpoint = f"productprojects/{product_id}"
        return super().get(endpoint)

    def get_plans(self, product_id: int, status: str = "all") -> APIResponse:
        """
        Get product plans for a product.

        Args:
            product_id: Product ID
            status: Plan status filter

        Returns:
            APIResponse with plan list
        """
        endpoint = f"productplans/{product_id}"
        params = {"status": status}
        return super().get(endpoint, params=params)

    def get_stories(
        self,
        product_id: int,
        status: str = "all",
        branch: int = 0,
        limit: int = 100,
        page: int = 1,
        type: str = "story"
    ) -> APIResponse:
        """
        Get stories for a product.

        Args:
            product_id: Product ID
            status: Story status filter
            branch: Branch ID (for branch-type products)
            limit: Number of results
            page: Page number
            type: Story type (story, requirement)

        Returns:
            APIResponse with story list
        """
        endpoint = f"stories/{product_id}"
        params = {
            "status": status,
            "branch": branch,
            "limit": limit,
            "page": page,
            "type": type
        }
        return super().get(endpoint, params=params)

    def get_bugs(
        self,
        product_id: int,
        status: str = "all",
        branch: int = 0,
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get bugs for a product.

        Args:
            product_id: Product ID
            status: Bug status filter
            branch: Branch ID
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with bug list
        """
        params = {
            "product": product_id,
            "status": status,
            "branch": branch,
            "limit": limit,
            "page": page
        }
        return super().get("bugs", params=params)

    def get_releases(self, product_id: int) -> APIResponse:
        """
        Get releases for a product.

        Args:
            product_id: Product ID

        Returns:
            APIResponse with release list
        """
        endpoint = f"releases/{product_id}"
        return super().get(endpoint)


class ExecutionManager(APIClient):
    """
    Manager for ZenTao executions (sprints/stages).

    Executions are time-boxed work periods within projects.
    """

    ENDPOINT = "executions"

    def list_executions(
        self,
        project_id: int = 0,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc"
    ) -> APIResponse:
        """
        List executions.

        Args:
            project_id: Project ID to filter
            status: Execution status filter (all, doing, suspended, closed)
            limit: Number of results per page
            page: Page number
            order: Sort order

        Returns:
            APIResponse with list of executions
        """
        # Use JSON view format - always get all executions and filter client-side
        endpoint = "m=execution&f=all"
        params = {"t": "json"}

        response = super().get(endpoint, params=params, use_api=False)

        # Filter by project_id if specified
        if project_id and response.success and response.data:
            execution_stats = response.data.get('executionStats', [])
            if execution_stats:
                filtered = [e for e in execution_stats if e.get('project') == project_id]
                response.data['executionStats'] = filtered

        return response

    def get_execution(self, execution_id: int) -> APIResponse:
        """
        Get execution details.

        Args:
            execution_id: Execution ID

        Returns:
            APIResponse with execution details
        """
        # Use JSON view format
        endpoint = f"m=execution&f=view&id={execution_id}"
        return super().get(endpoint, use_api=False)

    def get_tasks(
        self,
        execution_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc"
    ) -> APIResponse:
        """
        Get tasks for an execution.

        Args:
            execution_id: Execution ID
            status: Task status filter
            limit: Number of results
            page: Page number
            order: Sort order

        Returns:
            APIResponse with task list
        """
        endpoint = f"tasks/{execution_id}"
        params = {
            "status": status,
            "limit": limit,
            "page": page,
            "order": order
        }
        return super().get(endpoint, params=params)

    def get_bugs(
        self,
        execution_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get bugs for an execution.

        Args:
            execution_id: Execution ID
            status: Bug status filter
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with bug list
        """
        endpoint = f"executionbugs/{execution_id}"
        params = {"status": status, "limit": limit, "page": page}
        return super().get(endpoint, params=params)

    def get_stories(
        self,
        execution_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get stories linked to an execution.

        Args:
            execution_id: Execution ID
            status: Story status filter
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with story list
        """
        endpoint = f"executionstories/{execution_id}"
        params = {"status": status, "limit": limit, "page": page}
        return super().get(endpoint, params=params)

    def get_builds(
        self,
        execution_id: int,
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get builds for an execution.

        Args:
            execution_id: Execution ID
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with build list
        """
        endpoint = f"executionbuilds/{execution_id}"
        params = {"limit": limit, "page": page}
        return super().get(endpoint, params=params)


class UserManager(APIClient):
    """
    Manager for ZenTao users.
    """

    ENDPOINT = "users"

    def list_users(
        self,
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        List users.

        Args:
            limit: Number of results per page
            page: Page number

        Returns:
            APIResponse with list of users
        """
        # Use JSON view format - my/work includes users list
        endpoint = "m=my&f=work"
        params = {"t": "json"}
        return super().get(endpoint, params=params, use_api=False)

    def get_user(self, user_id: int = None, account: str = None) -> APIResponse:
        """
        Get user details.

        Args:
            user_id: User ID
            account: User account (alternative to user_id)

        Returns:
            APIResponse with user details
        """
        # Use JSON view format
        if user_id:
            endpoint = f"m=user&f=view&id={user_id}"
        elif account:
            endpoint = f"m=user&f=view&account={account}"
        else:
            endpoint = "m=user&f=view"

        return super().get(endpoint, use_api=False)

    def me(self, fields: str = "") -> APIResponse:
        """
        Get current user info.

        Args:
            fields: Additional fields (product, project, task, bug, etc.)

        Returns:
            APIResponse with current user details
        """
        # Use JSON view format - my profile page
        endpoint = "m=my&f=profile"
        params = {"t": "json"}
        return super().get(endpoint, params=params, use_api=False)