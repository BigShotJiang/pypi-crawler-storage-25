"""
Task management for ZenTao PMS CLI.

Provides CRUD operations and status changes for tasks.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from cli_anything.zentao.core.api_client import APIClient, APIResponse, NotFoundError


class TaskManager(APIClient):
    """
    Manager for ZenTao tasks.

    Provides methods for listing, creating, updating, and managing task status.
    """

    ENDPOINT = "tasks"

    def list_tasks(
        self,
        execution_id: int = 0,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc",
        search: bool = False,
        **filters
    ) -> APIResponse:
        """
        List tasks.

        Args:
            execution_id: Execution ID to filter (0 for all/my tasks)
            status: Task status filter (all, wait, doing, done, pause, cancel, closed)
            limit: Number of results per page
            page: Page number
            order: Sort order
            search: Enable search mode
            **filters: Additional search filters (pri, assignedTo, id, name)

        Returns:
            APIResponse with list of tasks
        """
        # Use JSON view format
        # Note: ZenTao's JSON view doesn't handle extra params well
        # Just use minimal params to get data
        if execution_id:
            endpoint = f"m=execution&f=task&executionID={execution_id}"
        else:
            # Get my tasks
            endpoint = "m=my&f=work"

        # Minimal params - just t=json is enough
        params = {}

        if search:
            for key in ["pri", "assignedTo", "id", "name"]:
                if key in filters:
                    params[key] = filters[key]

        return super().get(endpoint, params=params, use_api=False)

    def get_task(self, task_id: int) -> APIResponse:
        """
        Get task details.

        Args:
            task_id: Task ID

        Returns:
            APIResponse with task details
        """
        # Use JSON view format instead of REST API
        endpoint = f"m=task&f=view&id={task_id}"
        return super().get(endpoint, use_api=False)

    def create_task(
        self,
        execution_id: int,
        name: str,
        assigned_to: str,
        type: str = "devel",
        pri: int = 3,
        estimate: float = 0.0,
        est_started: str = "",
        deadline: str = "",
        desc: str = "",
        story: int = 0,
        module: int = 0,
        product: int = 0,
        **kwargs
    ) -> APIResponse:
        """
        Create a new task.

        Args:
            execution_id: Execution ID (required)
            name: Task name
            assigned_to: Account to assign task to
            type: Task type (devel, test, design, discuss, etc.)
            pri: Priority (1-4)
            estimate: Estimated hours
            est_started: Estimated start date (YYYY-MM-DD)
            deadline: Deadline date (YYYY-MM-DD)
            desc: Task description
            story: Related story ID
            module: Module ID
            product: Product ID
            **kwargs: Additional fields

        Returns:
            APIResponse with created task
        """
        data = {
            "name": name,
            "assignedTo": assigned_to,
            "type": type,
            "pri": pri,
            "estimate": estimate,
            "execution": execution_id,
            "desc": desc,
            **kwargs
        }
        if est_started:
            data["estStarted"] = est_started
        if deadline:
            data["deadline"] = deadline
        if story:
            data["story"] = story
        if module:
            data["module"] = module
        if product:
            data["product"] = product

        endpoint = f"m=task&f=create&executionID={execution_id}"
        return super().post(endpoint, data=data, use_api=False)

    def update_task(
        self,
        task_id: int,
        name: Optional[str] = None,
        assigned_to: Optional[str] = None,
        pri: Optional[int] = None,
        estimate: Optional[float] = None,
        left: Optional[float] = None,
        consumed: Optional[float] = None,
        status: Optional[str] = None,
        desc: Optional[str] = None,
        **kwargs
    ) -> APIResponse:
        """
        Update an existing task.

        Args:
            task_id: Task ID
            name: New task name
            assigned_to: New assignee
            pri: New priority
            estimate: New estimate
            left: Remaining hours
            consumed: Consumed hours
            status: New status
            desc: New description
            **kwargs: Additional fields

        Returns:
            APIResponse with updated task
        """
        data = {}
        if name:
            data["name"] = name
        if assigned_to:
            data["assignedTo"] = assigned_to
        if pri:
            data["pri"] = pri
        if estimate:
            data["estimate"] = estimate
        if left:
            data["left"] = left
        if consumed:
            data["consumed"] = consumed
        if status:
            data["status"] = status
        if desc:
            data["desc"] = desc
        data.update(kwargs)

        endpoint = f"task/{task_id}"
        return super().put(endpoint, data=data)

    def delete_task(self, task_id: int) -> APIResponse:
        """
        Delete a task.

        Args:
            task_id: Task ID

        Returns:
            APIResponse indicating success
        """
        endpoint = f"task/{task_id}"
        return super().delete(endpoint)

    def assign(self, task_id: int, assigned_to: str) -> APIResponse:
        """
        Assign task to a user.

        Args:
            task_id: Task ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated task
        """
        endpoint = f"taskassignto/{task_id}"
        data = {"assignedTo": assigned_to}
        return super().post(endpoint, data=data)

    def start(self, task_id: int, consumed: float = 0, left: float = None) -> APIResponse:
        """
        Start a task (change status to 'doing').

        Args:
            task_id: Task ID
            consumed: Consumed hours
            left: Remaining hours

        Returns:
            APIResponse with updated task
        """
        endpoint = f"taskstart/{task_id}"
        data = {"consumed": consumed}
        if left is not None:
            data["left"] = left
        return super().post(endpoint, data=data)

    def pause(self, task_id: int) -> APIResponse:
        """
        Pause a task.

        Args:
            task_id: Task ID

        Returns:
            APIResponse with updated task
        """
        endpoint = f"taskpause/{task_id}"
        return super().post(endpoint)

    def restart(self, task_id: int, consumed: float = 0, left: float = None) -> APIResponse:
        """
        Restart a paused task.

        Args:
            task_id: Task ID
            consumed: Consumed hours
            left: Remaining hours

        Returns:
            APIResponse with updated task
        """
        endpoint = f"taskrestart/{task_id}"
        data = {"consumed": consumed}
        if left is not None:
            data["left"] = left
        return super().post(endpoint, data=data)

    def finish(self, task_id: int, consumed: float = 0, left: float = 0) -> APIResponse:
        """
        Finish a task.

        Args:
            task_id: Task ID
            consumed: Hours consumed in this session (currentConsumed)
            left: Remaining hours (should be 0 for finished task)

        Returns:
            APIResponse with updated task
        """
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        endpoint = f"m=task&f=finish&id={task_id}"
        data = {
            "status": "done",
            "currentConsumed": str(consumed) if consumed else "1",
            "left": str(left) if left else "0",
            "finishedDate": now,
        }
        return super().post(endpoint, data=data, use_api=False)

    def close(self, task_id: int, comment: str = "") -> APIResponse:
        """
        Close a task.

        Note: Task must be in 'done' or 'cancel' status to be closed.
        Use finish() first if the task is not yet completed.

        Args:
            task_id: Task ID
            comment: Optional comment for closing

        Returns:
            APIResponse with updated task
        """
        endpoint = f"m=task&f=close&id={task_id}"
        data = {"status": "closed"}
        if comment:
            data["comment"] = comment
        return super().post(endpoint, data=data, use_api=False)

    def activate(self, task_id: int, assigned_to: str = None) -> APIResponse:
        """
        Activate a closed/canceled task.

        Args:
            task_id: Task ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated task
        """
        endpoint = f"taskactive/{task_id}"
        data = {}
        if assigned_to:
            data["assignedTo"] = assigned_to
        return super().post(endpoint, data=data)

    def record_estimate(self, task_id: int, consumed: float, left: float, work: str = "", date: str = "") -> APIResponse:
        """
        Record effort on a task.

        Args:
            task_id: Task ID
            consumed: Hours consumed in this session
            left: Remaining hours
            work: Work description
            date: Date for the record (YYYY-MM-DD, defaults to today)

        Returns:
            APIResponse with recorded effort
        """
        from datetime import datetime
        if not date:
            date = datetime.now().strftime('%Y-%m-%d')

        endpoint = f"m=task&f=recordWorkhour&taskID={task_id}"
        # ZenTao uses batch form data with array notation
        data = {
            "date[0]": date,
            "work[0]": work,
            "consumed[0]": str(consumed),
            "left[0]": str(left),
        }
        return super().post(endpoint, data=data, use_api=False)

    def batch_create(
        self,
        execution_id: int,
        tasks: List[Dict[str, Any]]
    ) -> APIResponse:
        """
        Batch create multiple tasks.

        Args:
            execution_id: Execution ID
            tasks: List of task dictionaries

        Returns:
            APIResponse with created tasks
        """
        endpoint = f"taskbatchcreate/{execution_id}"
        return super().post(endpoint, data={"tasks": tasks})