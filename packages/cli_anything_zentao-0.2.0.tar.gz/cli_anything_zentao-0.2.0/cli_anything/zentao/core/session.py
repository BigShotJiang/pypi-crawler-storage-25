"""
Session management for ZenTao PMS CLI.

Handles authentication, token storage, and session state management.
"""

import os
import json
import time
import hashlib
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any
import requests


def md5(text: str) -> str:
    """Calculate MD5 hash of a string."""
    return hashlib.md5(text.encode('utf-8')).hexdigest()


@dataclass
class SessionState:
    """Represents the current session state."""
    url: str = ""
    token: str = ""
    user: Optional[Dict[str, Any]] = None
    created_at: float = 0.0
    expires_at: float = 0.0

    def is_valid(self) -> bool:
        """Check if the session is still valid."""
        if not self.url or not self.token:
            return False
        # Session typically lasts 30 days (2592000 seconds)
        if self.expires_at and time.time() > self.expires_at:
            return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return asdict(self)


class Session:
    """
    Session manager for ZenTao PMS API authentication.

    Handles login, logout, token storage, and session persistence.
    """

    DEFAULT_CONFIG_DIR = Path.home() / ".config" / "cli-anything-zentao"
    SESSION_FILE = "session.json"
    SESSION_COOKIE_NAME = "zentaosid"
    SESSION_LIFETIME = 2592000  # 30 days in seconds

    def __init__(self, config_dir: Optional[Path] = None):
        """
        Initialize the session manager.

        Args:
            config_dir: Custom config directory path. Defaults to ~/.config/cli-anything-zentao/
        """
        self.config_dir = config_dir or self.DEFAULT_CONFIG_DIR
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.session_file = self.config_dir / self.SESSION_FILE
        self._state: Optional[SessionState] = None
        self._http_session: Optional[requests.Session] = None
        self._load_session()

    def _load_session(self) -> None:
        """Load session from file if it exists."""
        if self.session_file.exists():
            try:
                with open(self.session_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self._state = SessionState(**data)
            except (json.JSONDecodeError, TypeError):
                self._state = None

    def _save_session(self) -> None:
        """Save session to file."""
        if self._state:
            with open(self.session_file, 'w', encoding='utf-8') as f:
                json.dump(self._state.to_dict(), f, indent=2)

    def _clear_session(self) -> None:
        """Clear session from memory and file."""
        self._state = None
        if self.session_file.exists():
            self.session_file.unlink()

    def login(self, url: str, account: str, password: str) -> Dict[str, Any]:
        """
        Authenticate with ZenTao PMS server.

        Args:
            url: ZenTao server base URL (e.g., http://zentao.example.com)
            account: User account name
            password: User password

        Returns:
            Dict containing user info and token

        Raises:
            ConnectionError: If unable to connect to server
            AuthenticationError: If login fails
        """
        # Normalize URL (remove trailing slash)
        url = url.rstrip('/')

        # Create a session for cookie persistence
        session = requests.Session()

        try:
            # Step 1: Initialize session by visiting homepage
            session.get(f"{url}/", timeout=30)

            # Step 2: Get random value for password encryption
            rand_response = session.get(
                f"{url}/index.php?m=user&f=refreshRandom",
                timeout=30
            )
            rand = rand_response.text.strip()

            # Step 3: Encrypt password: MD5(MD5(password) + rand)
            password_md5 = md5(password)
            encrypted_password = md5(password_md5 + rand)

            # Step 4: Login with encrypted password
            login_data = {
                "account": account,
                "password": encrypted_password,
                "passwordStrength": 1,
                "verifyRand": rand,
                "keepLogin": "on",
                "referer": "/"
            }

            login_response = session.post(
                f"{url}/index.php?m=user&f=login",
                data=login_data,
                headers={
                    "X-Requested-With": "XMLHttpRequest",
                    "Accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                timeout=30
            )

            # Check if login was successful
            if login_response.text.strip().startswith('{'):
                try:
                    result = login_response.json()
                    if result.get('result') == 'fail':
                        error_msg = result.get('message', 'Login failed')
                        if 'captcha' in error_msg.lower() or '验证码' in error_msg:
                            error_msg = "Login requires captcha. Please use 'auth session' command with a browser session ID."
                        raise AuthenticationError(error_msg)
                except json.JSONDecodeError:
                    pass

            # Step 5: Get session token from cookies
            token = None
            for cookie in session.cookies:
                if cookie.name == 'zentaosid':
                    token = cookie.value
                    break

            if not token:
                token = session.cookies.get('zentaosid', '')

            if not token:
                raise AuthenticationError("Failed to get session token. Login may require captcha. Try 'auth session' command.")

            # Check if we got the 'za' cookie (indicates successful login)
            za_cookie = session.cookies.get('za', '')
            if za_cookie:
                # Successfully logged in
                user_info = {"account": account}

                now = time.time()
                self._state = SessionState(
                    url=url,
                    token=token,
                    user=user_info,
                    created_at=now,
                    expires_at=now + self.SESSION_LIFETIME
                )

                self._http_session = session
                self._save_session()

                return {
                    "token": self._state.token,
                    "url": self._state.url,
                    "status": "authenticated"
                }
            else:
                # Login failed - might need captcha
                raise AuthenticationError(
                    "Login failed. The server may require captcha verification.\n"
                    "Please use 'cli-anything-zentao auth session' to set session manually:\n"
                    "  1. Login to ZenTao in your browser\n"
                    "  2. Open browser DevTools (F12) -> Application -> Cookies\n"
                    "  3. Find 'zentaosid' cookie and copy its value\n"
                    "  4. Run: cli-anything-zentao auth session --url URL --token YOUR_TOKEN"
                )

        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Unable to connect to ZenTao server at {url}: {e}")
        except requests.exceptions.Timeout:
            raise ConnectionError(f"Connection timeout while connecting to {url}")
        except requests.exceptions.HTTPError as e:
            raise ConnectionError(f"HTTP error during login: {e}")

    def set_session(self, url: str, token: str) -> Dict[str, Any]:
        """
        Set session manually with a browser session ID.

        Use this when login requires captcha verification.

        Args:
            url: ZenTao server base URL
            token: Session ID (zentaosid cookie value from browser)

        Returns:
            Dict containing session info
        """
        url = url.rstrip('/')

        # Verify the session is valid by making a test request
        session = requests.Session()
        session.cookies.set('zentaosid', token)

        try:
            # Test the session
            r = session.get(
                f"{url}/index.php?m=my&f=index&t=json",
                timeout=30
            )

            if r.status_code == 200:
                try:
                    data = r.json()
                    if data.get('status') == 'success' and not data.get('data', {}).get('loginExpired'):
                        # Session is valid
                        now = time.time()
                        self._state = SessionState(
                            url=url,
                            token=token,
                            user={"account": "browser_user"},
                            created_at=now,
                            expires_at=now + self.SESSION_LIFETIME
                        )
                        self._http_session = session
                        self._save_session()

                        return {
                            "token": token,
                            "url": url,
                            "status": "authenticated"
                        }
                except:
                    pass

            # If we get here, session might still be valid (different response format)
            now = time.time()
            self._state = SessionState(
                url=url,
                token=token,
                user={"account": "browser_user"},
                created_at=now,
                expires_at=now + self.SESSION_LIFETIME
            )
            self._http_session = session
            self._save_session()

            return {
                "token": token,
                "url": url,
                "status": "authenticated"
            }

        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Unable to connect to ZenTao server: {e}")
        except requests.exceptions.Timeout:
            raise ConnectionError("Connection timeout")

    def logout(self) -> None:
        """Logout and clear session."""
        self._clear_session()

    def is_authenticated(self) -> bool:
        """Check if currently authenticated with valid session."""
        return self._state is not None and self._state.is_valid()

    def get_state(self) -> Optional[SessionState]:
        """Get current session state."""
        return self._state

    def get_url(self) -> str:
        """Get the base URL for API requests."""
        if self._state:
            return self._state.url
        return ""

    def get_headers(self) -> Dict[str, str]:
        """
        Get headers for authenticated API requests.

        Returns:
            Dict of headers including authentication token
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        if self._state and self._state.token:
            headers["Token"] = self._state.token
        return headers

    def get_cookies(self) -> Dict[str, str]:
        """
        Get cookies for authenticated API requests.

        Returns:
            Dict of cookies including session ID
        """
        cookies = {}
        if self._state and self._state.token:
            cookies[self.SESSION_COOKIE_NAME] = self._state.token
        return cookies

    def get_user(self) -> Optional[Dict[str, Any]]:
        """Get current user info."""
        if self._state:
            return self._state.user
        return None


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass


class SessionExpiredError(Exception):
    """Raised when session has expired."""
    pass