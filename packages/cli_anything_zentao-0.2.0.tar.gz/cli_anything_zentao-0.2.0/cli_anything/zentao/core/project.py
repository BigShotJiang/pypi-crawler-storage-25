"""
Project management for ZenTao PMS CLI.

Provides CRUD operations for projects.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from cli_anything.zentao.core.api_client import APIClient, APIResponse, NotFoundError


class ProjectManager(APIClient):
    """
    Manager for ZenTao projects.

    Provides methods for listing, creating, updating, and deleting projects.
    """

    ENDPOINT = "projects"

    def list_projects(
        self,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc"
    ) -> APIResponse:
        """
        List all projects.

        Args:
            status: Filter by status (all, doing, suspended, closed)
            limit: Number of results per page
            page: Page number (note: may not work on all ZenTao versions)
            order: Sort order (id_desc, id_asc, name_asc, etc.)

        Returns:
            APIResponse with list of projects
        """
        # Use JSON view format since REST API may not be available
        # Note: ZenTao's JSON view doesn't handle extra params well
        params = {}
        endpoint = "m=project&f=execution"
        return super().get(endpoint, params=params, use_api=False)

    def get_project(self, project_id: int, fields: Optional[str] = None) -> APIResponse:
        """
        Get project details.

        Args:
            project_id: Project ID
            fields: Additional fields to include (team, products, stat, workhour, actions, dynamics)

        Returns:
            APIResponse with project details
        """
        # Use JSON view format
        params = {}
        if fields:
            params["fields"] = fields
        endpoint = f"m=project&f=view&id={project_id}"
        return super().get(endpoint, params=params, use_api=False)

    def create_project(
        self,
        name: str,
        begin: str,
        end: str,
        acl: str = "private",
        parent: int = 0,
        pm: str = "",
        desc: str = "",
        model: str = "scrum",
        **kwargs
    ) -> APIResponse:
        """
        Create a new project.

        Args:
            name: Project name
            begin: Start date (YYYY-MM-DD)
            end: End date (YYYY-MM-DD)
            acl: Access control (private, open)
            parent: Parent program ID
            pm: Project manager account
            desc: Project description
            model: Project model (scrum, waterfall, kanban)
            **kwargs: Additional fields

        Returns:
            APIResponse with created project
        """
        data = {
            "name": name,
            "begin": begin,
            "end": end,
            "acl": acl,
            "parent": parent,
            "PM": pm,
            "desc": desc,
            "model": model,
            **kwargs
        }
        return super().post(self.ENDPOINT, data=data)

    def update_project(
        self,
        project_id: int,
        name: Optional[str] = None,
        begin: Optional[str] = None,
        end: Optional[str] = None,
        acl: Optional[str] = None,
        pm: Optional[str] = None,
        desc: Optional[str] = None,
        **kwargs
    ) -> APIResponse:
        """
        Update an existing project.

        Args:
            project_id: Project ID
            name: New project name
            begin: New start date
            end: New end date
            acl: New access control
            pm: New project manager
            desc: New description
            **kwargs: Additional fields to update

        Returns:
            APIResponse with updated project
        """
        data = {}
        if name:
            data["name"] = name
        if begin:
            data["begin"] = begin
        if end:
            data["end"] = end
        if acl:
            data["acl"] = acl
        if pm:
            data["PM"] = pm
        if desc:
            data["desc"] = desc
        data.update(kwargs)

        endpoint = f"{self.ENDPOINT}/{project_id}"
        return super().put(endpoint, data=data)

    def delete_project(self, project_id: int) -> APIResponse:
        """
        Delete a project.

        Args:
            project_id: Project ID

        Returns:
            APIResponse indicating success
        """
        endpoint = f"{self.ENDPOINT}/{project_id}"
        return super().delete(endpoint)

    def get_tasks(
        self,
        project_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get tasks for a project.

        Args:
            project_id: Project ID
            status: Task status filter
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with list of tasks
        """
        endpoint = f"projecttasks/{project_id}"
        params = {"status": status, "limit": limit, "page": page}
        return super().get(endpoint, params=params)

    def get_bugs(
        self,
        project_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get bugs for a project.

        Args:
            project_id: Project ID
            status: Bug status filter
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with list of bugs
        """
        endpoint = f"projectbugs/{project_id}"
        params = {"status": status, "limit": limit, "page": page}
        return super().get(endpoint, params=params)

    def get_stories(
        self,
        project_id: int,
        status: str = "all",
        limit: int = 100,
        page: int = 1
    ) -> APIResponse:
        """
        Get stories for a project.

        Args:
            project_id: Project ID
            status: Story status filter
            limit: Number of results
            page: Page number

        Returns:
            APIResponse with list of stories
        """
        endpoint = f"projectstories/{project_id}"
        params = {"status": status, "limit": limit, "page": page}
        return super().get(endpoint, params=params)

    def get_team(self, project_id: int) -> APIResponse:
        """
        Get project team members.

        Args:
            project_id: Project ID

        Returns:
            APIResponse with team member list
        """
        return super().get(f"{self.ENDPOINT}/{project_id}", params={"fields": "team"})