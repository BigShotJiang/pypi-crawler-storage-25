"""
Core module for ZenTao PMS CLI.

Exports all managers and the session handler.
"""

from cli_anything.zentao.core.session import Session, SessionState, AuthenticationError, SessionExpiredError
from cli_anything.zentao.core.api_client import APIClient, APIResponse, APIError, NotFoundError, PermissionError
from cli_anything.zentao.core.project import ProjectManager
from cli_anything.zentao.core.task import TaskManager
from cli_anything.zentao.core.bug import BugManager
from cli_anything.zentao.core.story import StoryManager
from cli_anything.zentao.core.product import ProductManager, ExecutionManager, UserManager


__all__ = [
    "Session",
    "SessionState",
    "AuthenticationError",
    "SessionExpiredError",
    "APIClient",
    "APIResponse",
    "APIError",
    "NotFoundError",
    "PermissionError",
    "ProjectManager",
    "TaskManager",
    "BugManager",
    "StoryManager",
    "ProductManager",
    "ExecutionManager",
    "UserManager",
]