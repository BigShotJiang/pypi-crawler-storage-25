"""
Bug management for ZenTao PMS CLI.

Provides CRUD operations and status changes for bugs.
"""

from typing import Dict, Any, Optional, List
from datetime import datetime

from cli_anything.zentao.core.api_client import APIClient, APIResponse, NotFoundError


class BugManager(APIClient):
    """
    Manager for ZenTao bugs.

    Provides methods for listing, creating, updating, and managing bug status.
    """

    ENDPOINT = "bugs"

    def list_bugs(
        self,
        product_id: int = 0,
        project_id: int = 0,
        execution_id: int = 0,
        status: str = "all",
        limit: int = 100,
        page: int = 1,
        order: str = "id_desc",
        search: bool = False,
        **filters
    ) -> APIResponse:
        """
        List bugs.

        Args:
            product_id: Product ID to filter
            project_id: Project ID to filter
            execution_id: Execution ID to filter
            status: Bug status filter (all, active, resolved, closed)
            limit: Number of results per page
            page: Page number
            order: Sort order
            search: Enable search mode
            **filters: Additional search filters

        Returns:
            APIResponse with list of bugs
        """
        # Use JSON view format
        endpoint = "m=bug&f=browse"
        params = {"t": "json"}

        if product_id:
            params["productID"] = product_id
        if status != "all":
            params["status"] = status

        return super().get(endpoint, params=params, use_api=False)

    def get_bug(self, bug_id: int) -> APIResponse:
        """
        Get bug details.

        Args:
            bug_id: Bug ID

        Returns:
            APIResponse with bug details
        """
        # Use JSON view format
        endpoint = f"m=bug&f=view&id={bug_id}"
        return super().get(endpoint, use_api=False)

    def create_bug(
        self,
        title: str,
        product: int,
        project: int = 0,
        execution: int = 0,
        opened_build: str = "",
        assigned_to: str = "",
        pri: int = 3,
        severity: int = 3,
        type: str = "codeerror",
        steps: str = "",
        module: int = 0,
        deadline: str = "",
        **kwargs
    ) -> APIResponse:
        """
        Create a new bug.

        Args:
            title: Bug title
            product: Product ID (required)
            project: Project ID
            execution: Execution ID
            opened_build: Build version(s)
            assigned_to: Account to assign to
            pri: Priority (1-4)
            severity: Severity level (1-4)
            type: Bug type (codeerror, config, install, security, performance, etc.)
            steps: Bug description/reproduction steps
            module: Module ID
            deadline: Deadline date (YYYY-MM-DD)
            **kwargs: Additional fields

        Returns:
            APIResponse with created bug
        """
        data = {
            "title": title,
            "product": product,
            "pri": pri,
            "severity": severity,
            "type": type,
            "steps": steps,
            **kwargs
        }
        if project:
            data["project"] = project
        if execution:
            data["execution"] = execution
        if opened_build:
            data["openedBuild"] = opened_build
        if assigned_to:
            data["assignedTo"] = assigned_to
        if module:
            data["module"] = module
        if deadline:
            data["deadline"] = deadline

        return super().post(self.ENDPOINT, data=data)

    def update_bug(
        self,
        bug_id: int,
        title: Optional[str] = None,
        assigned_to: Optional[str] = None,
        pri: Optional[int] = None,
        severity: Optional[int] = None,
        type: Optional[str] = None,
        steps: Optional[str] = None,
        status: Optional[str] = None,
        **kwargs
    ) -> APIResponse:
        """
        Update an existing bug.

        Args:
            bug_id: Bug ID
            title: New title
            assigned_to: New assignee
            pri: New priority
            severity: New severity
            type: New type
            steps: New description
            status: New status
            **kwargs: Additional fields

        Returns:
            APIResponse with updated bug
        """
        data = {}
        if title:
            data["title"] = title
        if assigned_to:
            data["assignedTo"] = assigned_to
        if pri:
            data["pri"] = pri
        if severity:
            data["severity"] = severity
        if type:
            data["type"] = type
        if steps:
            data["steps"] = steps
        if status:
            data["status"] = status
        data.update(kwargs)

        endpoint = f"bug/{bug_id}"
        return super().put(endpoint, data=data)

    def delete_bug(self, bug_id: int) -> APIResponse:
        """
        Delete a bug.

        Args:
            bug_id: Bug ID

        Returns:
            APIResponse indicating success
        """
        endpoint = f"bug/{bug_id}"
        return super().delete(endpoint)

    def assign(self, bug_id: int, assigned_to: str) -> APIResponse:
        """
        Assign bug to a user.

        Args:
            bug_id: Bug ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated bug
        """
        endpoint = f"bugassign/{bug_id}"
        data = {"assignedTo": assigned_to}
        return super().post(endpoint, data=data)

    def confirm(self, bug_id: int) -> APIResponse:
        """
        Confirm a bug.

        Args:
            bug_id: Bug ID

        Returns:
            APIResponse with updated bug
        """
        endpoint = f"bugconfirm/{bug_id}"
        return super().post(endpoint)

    def resolve(
        self,
        bug_id: int,
        resolution: str = "fixed",
        resolved_build: str = "",
        assigned_to: str = ""
    ) -> APIResponse:
        """
        Resolve a bug.

        Args:
            bug_id: Bug ID
            resolution: Resolution type (fixed, bydesign, wontfix, postponed, etc.)
            resolved_build: Build version where fixed
            assigned_to: Account to assign after resolution (for verification)

        Returns:
            APIResponse with updated bug
        """
        endpoint = f"bugresolve/{bug_id}"
        data = {"resolution": resolution}
        if resolved_build:
            data["resolvedBuild"] = resolved_build
        if assigned_to:
            data["assignedTo"] = assigned_to
        return super().post(endpoint, data=data)

    def close(self, bug_id: int) -> APIResponse:
        """
        Close a bug.

        Args:
            bug_id: Bug ID

        Returns:
            APIResponse with updated bug
        """
        endpoint = f"bugclose/{bug_id}"
        return super().post(endpoint)

    def activate(self, bug_id: int, assigned_to: str = "") -> APIResponse:
        """
        Activate a closed bug.

        Args:
            bug_id: Bug ID
            assigned_to: Account to assign to

        Returns:
            APIResponse with updated bug
        """
        endpoint = f"bugactive/{bug_id}"
        data = {}
        if assigned_to:
            data["assignedTo"] = assigned_to
        return super().post(endpoint, data=data)

    def record_estimate(self, bug_id: int, consumed: float, left: float = 0, work: str = "") -> APIResponse:
        """
        Record effort on a bug.

        Args:
            bug_id: Bug ID
            consumed: Hours consumed
            left: Remaining hours
            work: Work description

        Returns:
            APIResponse with recorded effort
        """
        endpoint = f"bugrecordestimate/{bug_id}"
        data = {"consumed": consumed, "left": left, "work": work}
        return super().post(endpoint, data=data)