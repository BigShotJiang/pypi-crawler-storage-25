# ZenTao PMS CLI

A modern CLI interface for ZenTao Project Management System with support for one-shot commands, REPL mode, and JSON output.

## Installation

```bash
pip install cli-anything-zentao
```

## Quick Start

### Login to ZenTao

```bash
cli-anything-zentao auth login --url http://zentao.example.com --account admin --password your_password
```

### List Projects

```bash
cli-anything-zentao project list
```

### Create a Task

```bash
cli-anything-zentao task create --execution 123 --name "Implement feature X" --assigned user1
```

### JSON Output (for automation)

```bash
cli-anything-zentao project list --json
```

### Interactive REPL Mode

```bash
cli-anything-zentao repl
```

## Commands

### Authentication

| Command | Description |
|---------|-------------|
| `auth login` | Login to ZenTao server |
| `auth logout` | Logout from ZenTao |
| `auth status` | Show authentication status |

### Projects

| Command | Description |
|---------|-------------|
| `project list` | List all projects |
| `project show <id>` | Show project details |
| `project create` | Create a new project |
| `project update <id>` | Update a project |
| `project delete <id>` | Delete a project |

### Tasks

| Command | Description |
|---------|-------------|
| `task list` | List tasks |
| `task show <id>` | Show task details |
| `task create` | Create a new task |
| `task assign <id>` | Assign task to user |
| `task start <id>` | Start a task |
| `task finish <id>` | Finish a task |
| `task close <id>` | Close a task |

### Bugs

| Command | Description |
|---------|-------------|
| `bug list` | List bugs |
| `bug show <id>` | Show bug details |
| `bug create` | Create a new bug |
| `bug resolve <id>` | Resolve a bug |
| `bug close <id>` | Close a bug |

### Stories

| Command | Description |
|---------|-------------|
| `story list` | List stories |
| `story show <id>` | Show story details |
| `story create` | Create a new story |
| `story close <id>` | Close a story |

### Products

| Command | Description |
|---------|-------------|
| `product list` | List products |
| `product show <id>` | Show product details |

### Executions

| Command | Description |
|---------|-------------|
| `execution list` | List executions/sprints |
| `execution show <id>` | Show execution details |

### Users

| Command | Description |
|---------|-------------|
| `user list` | List users |
| `user me` | Show current user info |

## Options

| Option | Description |
|--------|-------------|
| `--json` | Output in JSON format |
| `--version` | Show version |
| `--help` | Show help |

## Configuration

Session data is stored in `~/.config/cli-anything-zentao/session.json`.

## Examples

### One-shot Commands

```bash
# Login
cli-anything-zentao auth login --url http://zentao.example.com --account admin

# List active projects
cli-anything-zentao project list --status doing

# Create and start a task
cli-anything-zentao task create --execution 1 --name "Write docs" --assigned user1
cli-anything-zentao task start 100

# Get bug details in JSON
cli-anything-zentao bug show 50 --json
```

### REPL Mode

```bash
$ cli-anything-zentao repl
zentao> auth login http://zentao.example.com admin password
zentao> project list
zentao> task create --execution 123 --name "Fix bug" --assigned user1
zentao> exit
```

## API Reference

The CLI interacts with ZenTao's REST API v1. Key endpoints:

- `/tokens` - Authentication
- `/projects` - Projects CRUD
- `/executions` - Executions/sprints
- `/tasks` - Tasks CRUD and status changes
- `/bugs` - Bugs CRUD and lifecycle
- `/stories` - Stories/requirements
- `/products` - Products
- `/users` - Users

## License

This CLI harness is provided as-is for interfacing with ZenTao PMS.

## Version

Current version: 0.1.0