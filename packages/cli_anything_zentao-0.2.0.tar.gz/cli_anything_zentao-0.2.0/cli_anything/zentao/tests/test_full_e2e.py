"""
End-to-End tests for ZenTao PMS CLI.

Tests complete workflows with real API interactions.
Requires running ZenTao server and test credentials.
"""

import os
import json
import pytest
import subprocess
import shutil
from pathlib import Path
from typing import Optional


# Test configuration from environment
ZENTAO_URL = os.environ.get("ZENTAO_URL", "")
ZENTAO_ACCOUNT = os.environ.get("ZENTAO_ACCOUNT", "")
ZENTAO_PASSWORD = os.environ.get("ZENTAO_PASSWORD", "")
ZENTAO_PROJECT_ID = os.environ.get("ZENTAO_PROJECT_ID", "1")
ZENTAO_EXECUTION_ID = os.environ.get("ZENTAO_EXECUTION_ID", "1")
ZENTAO_PRODUCT_ID = os.environ.get("ZENTAO_PRODUCT_ID", "1")

# Skip all tests if no test server configured
pytestmark = pytest.mark.skipif(
    not all([ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD]),
    reason="Test server not configured. Set ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD environment variables."
)


def _resolve_cli(cli_name: str = "cli-anything-zentao") -> str:
    """
    Resolve CLI executable path.

    Tests the installed command via subprocess without hardcoded paths.
    """
    # Check if CLI is in PATH
    cli_path = shutil.which(cli_name)
    if cli_path:
        return cli_path

    # Fallback to python module execution
    return f"python -m cli_anything.zentao.zentao_cli"


class TestCLISubprocess:
    """
    Tests for CLI via subprocess execution.

    Verifies the installed CLI works correctly.
    """

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup for each test."""
        self.cli = _resolve_cli()
        self.env = os.environ.copy()
        self.env["CLI_ANYTHING_FORCE_INSTALLED"] = "1"

    def _run_cli(self, *args, json_output: bool = False) -> subprocess.CompletedProcess:
        """Run CLI command."""
        cmd = self.cli.split() + list(args)
        if json_output:
            cmd.append("--json")
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=self.env,
            timeout=30
        )

    def test_cli_version(self):
        """Test CLI version command."""
        result = self._run_cli("--version")
        assert result.returncode == 0
        assert "cli-anything-zentao" in result.stdout

    def test_cli_help(self):
        """Test CLI help command."""
        result = self._run_cli("--help")
        assert result.returncode == 0
        assert "ZenTao PMS CLI" in result.stdout

    def test_auth_status_not_authenticated(self):
        """Test auth status when not authenticated."""
        # Clear any existing session
        self._run_cli("auth", "logout")

        result = self._run_cli("auth", "status")
        assert result.returncode == 0
        assert "Not authenticated" in result.stdout or "authenticated" in result.stdout.lower()


class TestAuthenticationFlow:
    """Tests for authentication workflow."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session

        self.config_dir = tmp_path / ".config" / "cli-anything-zentao"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=self.config_dir)

    def test_login_success(self):
        """Test successful login."""
        result = self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)

        assert "token" in result
        assert result["status"] == "authenticated"
        assert self.session.is_authenticated()

    def test_login_invalid_credentials(self):
        """Test login with invalid credentials."""
        with pytest.raises(Exception):  # AuthenticationError or similar
            self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, "wrong_password")

    def test_logout(self):
        """Test logout."""
        # Login first
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        assert self.session.is_authenticated()

        # Logout
        self.session.logout()
        assert not self.session.is_authenticated()

    def test_session_persistence(self):
        """Test session persists across instances."""
        # Login with first instance
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)

        # Create new instance - should load existing session
        from cli_anything.zentao.core.session import Session
        new_session = Session(config_dir=self.config_dir)

        assert new_session.is_authenticated()


class TestProjectWorkflow:
    """Tests for project workflow."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session
        from cli_anything.zentao.core.project import ProjectManager

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        self.manager = ProjectManager(self.session)

    def test_list_projects(self):
        """Test listing projects."""
        response = self.manager.list(limit=10)

        assert response.success
        assert "projects" in response.data or isinstance(response.data, list)

    def test_get_project(self):
        """Test getting project details."""
        project_id = int(ZENTAO_PROJECT_ID)
        response = self.manager.get(project_id)

        assert response.success
        assert response.data["id"] == project_id


class TestTaskWorkflow:
    """Tests for task workflow."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session
        from cli_anything.zentao.core.task import TaskManager

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        self.manager = TaskManager(self.session)

    def test_list_tasks(self):
        """Test listing tasks."""
        execution_id = int(ZENTAO_EXECUTION_ID)
        response = self.manager.list(execution_id=execution_id, limit=10)

        assert response.success
        # Response should contain tasks or empty list


class TestBugWorkflow:
    """Tests for bug workflow."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session
        from cli_anything.zentao.core.bug import BugManager

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        self.manager = BugManager(self.session)

    def test_list_bugs(self):
        """Test listing bugs."""
        product_id = int(ZENTAO_PRODUCT_ID)
        response = self.manager.list(product_id=product_id, limit=10)

        assert response.success


class TestStoryWorkflow:
    """Tests for story workflow."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session
        from cli_anything.zentao.core.story import StoryManager

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        self.manager = StoryManager(self.session)

    def test_list_stories(self):
        """Test listing stories."""
        product_id = int(ZENTAO_PRODUCT_ID)
        response = self.manager.list(product_id=product_id, limit=10)

        assert response.success


class TestJSONOutput:
    """Tests for JSON output mode."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session
        from cli_anything.zentao.core.project import ProjectManager

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)
        self.manager = ProjectManager(self.session)

    def test_project_list_json_structure(self):
        """Test JSON output structure for project list."""
        response = self.manager.list(limit=5)

        # Should be valid data structure
        assert response.data is not None

        # Can be serialized to JSON
        json_str = json.dumps(response.data, default=str)
        parsed = json.loads(json_str)
        assert isinstance(parsed, (dict, list))

    def test_project_get_json_structure(self):
        """Test JSON output structure for project get."""
        project_id = int(ZENTAO_PROJECT_ID)
        response = self.manager.get(project_id)

        assert response.data is not None
        assert response.data["id"] == project_id

        # Can be serialized to JSON
        json_str = json.dumps(response.data, default=str)
        parsed = json.loads(json_str)
        assert isinstance(parsed, dict)


class TestErrorHandling:
    """Tests for error handling."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        """Setup for each test."""
        from cli_anything.zentao.core.session import Session

        config_dir = tmp_path / ".config" / "cli-anything-zentao"
        config_dir.mkdir(parents=True, exist_ok=True)
        self.session = Session(config_dir=config_dir)
        self.session.login(ZENTAO_URL, ZENTAO_ACCOUNT, ZENTAO_PASSWORD)

    def test_get_nonexistent_project(self):
        """Test getting non-existent project."""
        from cli_anything.zentao.core.project import ProjectManager

        manager = ProjectManager(self.session)
        response = manager.get(999999999)  # Very unlikely to exist

        # Should handle gracefully
        assert response is not None

    def test_get_nonexistent_task(self):
        """Test getting non-existent task."""
        from cli_anything.zentao.core.task import TaskManager

        manager = TaskManager(self.session)
        response = manager.get(999999999)

        assert response is not None


# ============================================
# Run Tests
# ============================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])