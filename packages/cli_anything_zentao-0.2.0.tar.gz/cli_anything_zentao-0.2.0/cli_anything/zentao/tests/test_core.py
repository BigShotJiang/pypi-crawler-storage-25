"""
Unit tests for ZenTao PMS CLI core modules.

Tests individual components using synthetic data and mocked responses.
No external dependencies required.
"""

import os
import json
import pytest
from unittest.mock import Mock, MagicMock, patch
from pathlib import Path
import tempfile

from cli_anything.zentao.core.session import Session, SessionState, AuthenticationError
from cli_anything.zentao.core.api_client import APIClient, APIResponse, APIError, NotFoundError
from cli_anything.zentao.core.project import ProjectManager
from cli_anything.zentao.core.task import TaskManager
from cli_anything.zentao.core.bug import BugManager
from cli_anything.zentao.core.story import StoryManager
from cli_anything.zentao.core.product import ProductManager, ExecutionManager, UserManager


# ============================================
# Session Tests
# ============================================

class TestSessionState:
    """Tests for SessionState class."""

    def test_session_state_creation(self):
        """Test creating a session state."""
        state = SessionState(
            url="http://zentao.example.com",
            token="test_token_123",
            user={"account": "admin"},
            created_at=1000.0,
            expires_at=2000.0
        )
        assert state.url == "http://zentao.example.com"
        assert state.token == "test_token_123"
        assert state.user["account"] == "admin"

    def test_session_state_validity(self):
        """Test session state validation."""
        # Valid state
        valid_state = SessionState(
            url="http://zentao.example.com",
            token="test_token",
            created_at=1000.0,
            expires_at=9999999999.0  # Far future
        )
        assert valid_state.is_valid() == True

        # Invalid - no token
        invalid_state = SessionState(
            url="http://zentao.example.com",
            token="",
            created_at=1000.0
        )
        assert invalid_state.is_valid() == False

        # Invalid - expired
        expired_state = SessionState(
            url="http://zentao.example.com",
            token="test_token",
            created_at=1000.0,
            expires_at=1001.0  # Already expired
        )
        assert expired_state.is_valid() == False

    def test_session_state_to_dict(self):
        """Test converting session state to dictionary."""
        state = SessionState(
            url="http://zentao.example.com",
            token="test_token",
            user={"account": "admin"},
            created_at=1000.0,
            expires_at=2000.0
        )
        data = state.to_dict()
        assert isinstance(data, dict)
        assert data["url"] == "http://zentao.example.com"
        assert data["token"] == "test_token"


class TestSession:
    """Tests for Session class."""

    @pytest.fixture
    def temp_config_dir(self):
        """Create temporary config directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_session_init(self, temp_config_dir):
        """Test session initialization."""
        session = Session(config_dir=temp_config_dir)
        assert session.config_dir == temp_config_dir
        assert session._state is None

    def test_session_save_and_load(self, temp_config_dir):
        """Test session persistence."""
        session1 = Session(config_dir=temp_config_dir)
        session1._state = SessionState(
            url="http://zentao.example.com",
            token="test_token",
            user={"account": "admin"},
            created_at=1000.0,
            expires_at=2000.0
        )
        session1._save_session()

        # Create new session to load saved state
        session2 = Session(config_dir=temp_config_dir)
        assert session2._state is not None
        assert session2._state.token == "test_token"

    def test_session_clear(self, temp_config_dir):
        """Test session clearing."""
        session = Session(config_dir=temp_config_dir)
        session._state = SessionState(
            url="http://zentao.example.com",
            token="test_token"
        )
        session._save_session()

        session._clear_session()
        assert session._state is None
        assert not (temp_config_dir / "session.json").exists()

    def test_session_is_authenticated(self, temp_config_dir):
        """Test authentication check."""
        session = Session(config_dir=temp_config_dir)

        # Not authenticated initially
        assert session.is_authenticated() == False

        # With valid state
        session._state = SessionState(
            url="http://zentao.example.com",
            token="test_token",
            expires_at=9999999999.0
        )
        assert session.is_authenticated() == True

    def test_session_get_headers(self, temp_config_dir):
        """Test getting request headers."""
        session = Session(config_dir=temp_config_dir)
        session._state = SessionState(
            url="http://zentao.example.com",
            token="test_token"
        )

        headers = session.get_headers()
        assert headers["Content-Type"] == "application/json"
        assert headers["Token"] == "test_token"

    def test_session_get_cookies(self, temp_config_dir):
        """Test getting request cookies."""
        session = Session(config_dir=temp_config_dir)
        session._state = SessionState(
            url="http://zentao.example.com",
            token="test_token"
        )

        cookies = session.get_cookies()
        assert "zentaosid" in cookies
        assert cookies["zentaosid"] == "test_token"

    def test_login_connection_error(self, temp_config_dir):
        """Test login with connection error."""
        import requests

        session = Session(config_dir=temp_config_dir)

        with patch('requests.post') as mock_post:
            mock_post.side_effect = requests.exceptions.ConnectionError("Connection failed")

            with pytest.raises(ConnectionError):
                session.login("http://invalid.url", "admin", "password")


# ============================================
# API Client Tests
# ============================================

class TestAPIResponse:
    """Tests for APIResponse class."""

    def test_api_response_success(self):
        """Test successful response parsing."""
        import requests

        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "success",
            "data": {"id": 1, "name": "Test"},
            "page": 1,
            "total": 10
        }

        response = APIResponse.from_response(mock_response)
        assert response.success == True
        assert response.status_code == 200
        assert response.data["id"] == 1
        assert response.page == 1

    def test_api_response_error(self):
        """Test error response parsing."""
        import requests

        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "status": "fail",
            "message": "Error occurred"
        }

        response = APIResponse.from_response(mock_response)
        assert response.success == False
        assert response.message == "Error occurred"

    def test_api_response_no_json(self):
        """Test response with no JSON body."""
        import requests

        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 500
        mock_response.json.side_effect = json.JSONDecodeError("test", "test", 0)

        response = APIResponse.from_response(mock_response)
        assert response.success == False
        assert response.status_code == 500


class TestAPIClient:
    """Tests for APIClient class."""

    @pytest.fixture
    def mock_session(self):
        """Create mock session."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        session.get_headers.return_value = {"Content-Type": "application/json"}
        session.get_cookies.return_value = {"zentaosid": "test_token"}
        session.is_authenticated.return_value = True
        return session

    def test_api_client_init(self, mock_session):
        """Test API client initialization."""
        client = APIClient(mock_session)
        assert client.session == mock_session

    def test_endpoint_url_building(self, mock_session):
        """Test endpoint URL construction."""
        client = APIClient(mock_session)
        url = client._get_endpoint_url("projects")
        assert url == "http://zentao.example.com/api.php/v1/projects"

        url = client._get_endpoint_url("/tasks/123")
        assert url == "http://zentao.example.com/api.php/v1/tasks/123"

    def test_api_client_get(self, mock_session):
        """Test GET request."""
        import requests

        client = APIClient(mock_session)

        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": [{"id": 1, "name": "Project 1"}]}

        with patch.object(requests, 'request', return_value=mock_response):
            response = client.get("projects")
            assert response.success == True

    def test_api_client_post(self, mock_session):
        """Test POST request."""
        import requests

        client = APIClient(mock_session)

        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": 1, "name": "Created"}

        with patch.object(requests, 'request', return_value=mock_response):
            response = client.post("projects", data={"name": "New Project"})
            assert response.success == True


# ============================================
# Manager Tests
# ============================================

class TestProjectManager:
    """Tests for ProjectManager class."""

    @pytest.fixture
    def mock_client(self):
        """Create mock API client."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        session.get_headers.return_value = {}
        session.get_cookies.return_value = {}
        return ProjectManager(session)

    def test_project_manager_list(self, mock_client):
        """Test project listing."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {
            "projects": [
                {"id": 1, "name": "Project 1", "status": "doing"},
                {"id": 2, "name": "Project 2", "status": "closed"}
            ]
        }

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.list(status="doing")
            assert response.success == True
            assert len(response.data["projects"]) == 2

    def test_project_manager_get(self, mock_client):
        """Test project retrieval."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {"id": 1, "name": "Project 1"}

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.get(1)
            assert response.success == True
            assert response.data["id"] == 1


class TestTaskManager:
    """Tests for TaskManager class."""

    @pytest.fixture
    def mock_client(self):
        """Create mock API client."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        return TaskManager(session)

    def test_task_manager_list(self, mock_client):
        """Test task listing."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {
            "tasks": [
                {"id": 1, "name": "Task 1", "status": "doing"},
                {"id": 2, "name": "Task 2", "status": "wait"}
            ]
        }

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.list(execution_id=123)
            assert response.success == True

    def test_task_manager_create(self, mock_client):
        """Test task creation."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {"id": 1, "name": "New Task"}

        with patch.object(mock_client, 'post', return_value=mock_response):
            response = mock_client.create(
                execution_id=123,
                name="New Task",
                assigned_to="user1"
            )
            assert response.success == True


class TestBugManager:
    """Tests for BugManager class."""

    @pytest.fixture
    def mock_client(self):
        """Create mock API client."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        return BugManager(session)

    def test_bug_manager_list(self, mock_client):
        """Test bug listing."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {
            "bugs": [
                {"id": 1, "title": "Bug 1", "status": "active"},
                {"id": 2, "title": "Bug 2", "status": "resolved"}
            ]
        }

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.list(product_id=123)
            assert response.success == True


class TestStoryManager:
    """Tests for StoryManager class."""

    @pytest.fixture
    def mock_client(self):
        """Create mock API client."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        return StoryManager(session)

    def test_story_manager_list(self, mock_client):
        """Test story listing."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {
            "stories": [
                {"id": 1, "title": "Story 1", "status": "active"},
                {"id": 2, "title": "Story 2", "status": "closed"}
            ]
        }

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.list(product_id=123)
            assert response.success == True


class TestProductManager:
    """Tests for ProductManager class."""

    @pytest.fixture
    def mock_client(self):
        """Create mock API client."""
        session = Mock(spec=Session)
        session.get_url.return_value = "http://zentao.example.com"
        return ProductManager(session)

    def test_product_manager_list(self, mock_client):
        """Test product listing."""
        mock_response = Mock(spec=APIResponse)
        mock_response.success = True
        mock_response.data = {
            "products": [
                {"id": 1, "name": "Product 1"},
                {"id": 2, "name": "Product 2"}
            ]
        }

        with patch.object(mock_client, 'get', return_value=mock_response):
            response = mock_client.list()
            assert response.success == True


# ============================================
# Output Formatter Tests
# ============================================

class TestOutputFormatter:
    """Tests for output formatting."""

    def test_truncate_text(self):
        """Test text truncation."""
        from cli_anything.zentao.utils.formatter import truncate_text

        short_text = "Short"
        assert truncate_text(short_text, 50) == short_text

        long_text = "This is a very long text that should be truncated"
        result = truncate_text(long_text, 20)
        assert len(result) == 20
        assert result.endswith("...")

    def test_validate_url(self):
        """Test URL validation."""
        from cli_anything.zentao.utils.formatter import validate_url

        assert validate_url("http://zentao.example.com") == True
        assert validate_url("https://zentao.example.com") == True
        assert validate_url("invalid_url") == False
        assert validate_url("") == False

    def test_validate_date(self):
        """Test date validation."""
        from cli_anything.zentao.utils.formatter import validate_date

        assert validate_date("2024-01-01") == True
        assert validate_date("2024-12-31") == True
        assert validate_date("invalid") == False
        assert validate_date("") == False

    def test_parse_filters(self):
        """Test filter parsing."""
        from cli_anything.zentao.utils.formatter import parse_filters

        filters = parse_filters("status:active,pri:1")
        assert filters["status"] == "active"
        assert filters["pri"] == "1"

        empty_filters = parse_filters("")
        assert empty_filters == {}


# ============================================
# Run Tests
# ============================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])