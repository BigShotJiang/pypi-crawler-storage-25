"""
Tests for ZenTao PMS CLI.
"""