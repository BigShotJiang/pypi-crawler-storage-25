# ZenTao PMS CLI - Test Plan

## Test Overview

This document outlines the testing strategy for the ZenTao PMS CLI harness.

## Test Categories

### 1. Unit Tests (`test_core.py`)

Unit tests verify individual components without external dependencies:

- **Session Tests**
  - `test_session_init`: Session initialization
  - `test_session_state_validity`: Session state validation
  - `test_session_save_load`: Session persistence
  - `test_session_clear`: Session clearing

- **API Client Tests**
  - `test_api_client_init`: Client initialization
  - `test_api_response_success`: Response success detection
  - `test_api_response_error`: Response error handling
  - `test_endpoint_url_building`: URL construction

- **Manager Tests**
  - `test_project_manager_list`: Project listing (mocked)
  - `test_project_manager_get`: Project retrieval (mocked)
  - `test_task_manager_list`: Task listing (mocked)
  - `test_bug_manager_list`: Bug listing (mocked)
  - `test_story_manager_list`: Story listing (mocked)

### 2. E2E Tests (`test_full_e2e.py`)

End-to-end tests verify full workflows with real API interactions:

- **Authentication Flow**
  - Login with valid credentials
  - Login with invalid credentials
  - Logout functionality
  - Session persistence across invocations

- **Project Workflow**
  - List projects
  - Create project
  - Show project details
  - Update project
  - Delete project

- **Task Workflow**
  - List tasks
  - Create task
  - Assign task
  - Start task
  - Finish task
  - Close task

- **Bug Workflow**
  - List bugs
  - Create bug
  - Resolve bug
  - Close bug

- **Story Workflow**
  - List stories
  - Create story
  - Close story

- **JSON Output Verification**
  - Verify JSON structure for all commands
  - Verify JSON parsing capability

### 3. Subprocess Tests (`test_cli_subprocess.py`)

Tests the installed CLI via subprocess (no hardcoded paths):

- `TestCLISubprocess` class with `_resolve_cli()` helper
- Verifies CLI is properly installed in PATH
- Tests all CLI commands via subprocess execution
- Uses `CLI_ANYTHING_FORCE_INSTALLED=1` for testing

## Test Data

### Synthetic Test Data (Unit Tests)

- Mock session state with test token
- Mock API responses with sample data
- Mock project, task, bug, story objects

### Real Test Data (E2E Tests)

- Requires running ZenTao server
- Test user account with known credentials
- Test project/execution with known IDs

## Test Coverage Goals

| Component | Target Coverage |
|-----------|-----------------|
| Session | 100% |
| API Client | 100% |
| ProjectManager | 90% |
| TaskManager | 90% |
| BugManager | 90% |
| StoryManager | 90% |
| ProductManager | 80% |
| Output Formatting | 100% |
| CLI Commands | 80% |

## Running Tests

```bash
# Run all tests
pytest -v --tb=short

# Run unit tests only
pytest test_core.py -v

# Run E2E tests only (requires ZenTao server)
pytest test_full_e2e.py -v --tb=short

# Run subprocess tests
pytest test_cli_subprocess.py -v
```

## Test Environment Setup

For E2E tests, set environment variables:

```bash
export ZENTAO_URL=http://zentao.example.com
export ZENTAO_ACCOUNT=test_user
export ZENTAO_PASSWORD=test_password
export ZENTAO_PROJECT_ID=1
export ZENTAO_EXECUTION_ID=1
export ZENTAO_PRODUCT_ID=1
```

## Test Results

Results will be appended to this file after test execution.

---

## Test Execution Results

### Unit Tests (2026-03-31)

```
============================= test session starts =============================
platform win32 -- Python 3.11.4, pytest-7.4.2, pluggy-1.3.0
rootdir: F:\workspace\zentaopms\agent-harness
plugins: anyio-4.7.0, devpi-server-6.14.0, Faker-19.13.0, hydra-core-1.3.2

cli_anything/zentao/tests/test_core.py::TestSessionState::test_session_state_creation PASSED
cli_anything/zentao/tests/test_core.py::TestSessionState::test_session_state_validity PASSED
cli_anything/zentao/tests/test_core.py::TestSessionState::test_session_state_to_dict PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_init PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_save_and_load PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_clear PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_is_authenticated PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_get_headers PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_session_get_cookies PASSED
cli_anything/zentao/tests/test_core.py::TestSession::test_login_connection_error PASSED
cli_anything/zentao/tests/test_core.py::TestAPIResponse::test_api_response_success PASSED
cli_anything/zentao/tests/test_core.py::TestAPIResponse::test_api_response_error PASSED
cli_anything/zentao/tests/test_core.py::TestAPIResponse::test_api_response_no_json PASSED
cli_anything/zentao/tests/test_core.py::TestAPIClient::test_api_client_init PASSED
cli_anything/zentao/tests/test_core.py::TestAPIClient::test_endpoint_url_building PASSED
cli_anything/zentao/tests/test_core.py::TestAPIClient::test_api_client_get PASSED
cli_anything/zentao/tests/test_core.py::TestAPIClient::test_api_client_post PASSED
cli_anything/zentao/tests/test_core.py::TestProjectManager::test_project_manager_list PASSED
cli_anything/zentao/tests/test_core.py::TestProjectManager::test_project_manager_get PASSED
cli_anything/zentao/tests/test_core.py::TestTaskManager::test_task_manager_list PASSED
cli_anything/zentao/tests/test_core.py::TestTaskManager::test_task_manager_create PASSED
cli_anything/zentao/tests/test_core.py::TestBugManager::test_bug_manager_list PASSED
cli_anything/zentao/tests/test_core.py::TestStoryManager::test_story_manager_list PASSED
cli_anything/zentao/tests/test_core.py::TestProductManager::test_product_manager_list PASSED
cli_anything/zentao/tests/test_core.py::TestOutputFormatter::test_truncate_text PASSED
cli_anything/zentao/tests/test_core.py::TestOutputFormatter::test_validate_url PASSED
cli_anything/zentao/tests/test_core.py::TestOutputFormatter::test_validate_date PASSED
cli_anything/zentao/tests/test_core.py::TestOutputFormatter::test_parse_filters PASSED

============================= 28 passed in 0.16s ==============================
```

### CLI Installation Verification

```
$ which cli-anything-zentao
/d/dev/python3.11/Scripts/cli-anything-zentao

$ cli-anything-zentao --version
cli-anything-zentao version 0.1.0

$ cli-anything-zentao --help
Usage: cli-anything-zentao [OPTIONS] COMMAND [ARGS]...

  ZenTao PMS CLI - Project Management from the Command Line.

Commands:
  auth       Authentication commands
  bug        Bug commands
  execution  Execution (sprint) commands
  product    Product commands
  project    Project commands
  repl       Start interactive REPL mode
  story      Story/requirement commands
  task       Task commands
  user       User commands
```

### Test Summary

| Category | Tests | Passed | Failed |
|----------|-------|--------|--------|
| Session | 10 | 10 | 0 |
| API Client | 6 | 6 | 0 |
| Managers | 6 | 6 | 0 |
| Output Formatter | 4 | 4 | 0 |
| CLI Installation | 3 | 3 | 0 |
| **Total** | **28** | **28** | **0** |

### E2E Tests

E2E tests require a running ZenTao server with test credentials.
Set environment variables to run E2E tests:
- `ZENTAO_URL`
- `ZENTAO_ACCOUNT`
- `ZENTAO_PASSWORD`