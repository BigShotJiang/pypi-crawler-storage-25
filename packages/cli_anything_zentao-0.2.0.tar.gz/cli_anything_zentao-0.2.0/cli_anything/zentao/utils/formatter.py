"""
Utilities for ZenTao PMS CLI.

Provides helper functions for formatting and output.
"""

import json
from typing import Any, Dict, List, Optional
from datetime import datetime
from tabulate import tabulate


def format_date(date_str: str) -> str:
    """Format date string for display."""
    if not date_str:
        return ""
    try:
        # ZenTao typically returns YYYY-MM-DD format
        return date_str
    except ValueError:
        return date_str


def format_time(time_str: str) -> str:
    """Format datetime string for display."""
    if not time_str:
        return ""
    try:
        # Parse ZenTao datetime format
        dt = datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d %H:%M")
    except ValueError:
        return time_str


def format_user(user: Dict[str, Any]) -> str:
    """Format user info for display."""
    if not user:
        return ""
    if isinstance(user, str):
        return user
    return user.get('realname', user.get('account', ''))


def truncate_text(text: str, max_length: int = 50) -> str:
    """Truncate text to specified length."""
    if not text:
        return ""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def sanitize_for_output(data: Any) -> Any:
    """Sanitize data for safe output."""
    if isinstance(data, dict):
        return {k: sanitize_for_output(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_for_output(item) for item in data]
    elif isinstance(data, str):
        # Remove potential control characters
        return ''.join(c for c in data if ord(c) >= 32 or c in '\n\t')
    return data


def format_table(data: List[Dict[str, Any]], headers: Optional[List[str]] = None) -> str:
    """Format data as a table."""
    if not data:
        return "No data to display."

    # Auto-detect headers
    if headers is None:
        headers = list(data[0].keys()) if data else []

    # Prepare rows
    rows = []
    for item in data:
        row = []
        for h in headers:
            value = item.get(h, '')
            if isinstance(value, dict):
                value = json.dumps(value, ensure_ascii=False)
            elif isinstance(value, list):
                value = ', '.join(str(v) for v in value)
            else:
                value = str(value)
            row.append(truncate_text(value, 40))
        rows.append(row)

    return tabulate(rows, headers=headers, tablefmt='simple')


def parse_filters(filter_str: str) -> Dict[str, str]:
    """Parse filter string into dictionary."""
    filters = {}
    if not filter_str:
        return filters

    for part in filter_str.split(','):
        if ':' in part:
            key, value = part.split(':', 1)
            filters[key.strip()] = value.strip()
    return filters


def validate_url(url: str) -> bool:
    """Validate ZenTao URL format."""
    if not url:
        return False
    return url.startswith('http://') or url.startswith('https://')


def validate_date(date_str: str) -> bool:
    """Validate date format (YYYY-MM-DD)."""
    if not date_str:
        return False
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


class OutputFormatter:
    """Formatter for CLI output."""

    def __init__(self, json_mode: bool = False):
        self.json_mode = json_mode

    def format(self, data: Any) -> str:
        """Format data for output."""
        if self.json_mode:
            return json.dumps(data, indent=2, default=str, ensure_ascii=False)
        return self._format_human(data)

    def _format_human(self, data: Any) -> str:
        """Format data for human-readable output."""
        if isinstance(data, list):
            return format_table(data)
        elif isinstance(data, dict):
            lines = []
            for key, value in data.items():
                if isinstance(value, (list, dict)):
                    value = json.dumps(value, ensure_ascii=False)
                lines.append(f"{key}: {value}")
            return '\n'.join(lines)
        return str(data)

    def format_error(self, message: str) -> str:
        """Format error message."""
        if self.json_mode:
            return json.dumps({"error": message})
        return f"Error: {message}"

    def format_success(self, message: str) -> str:
        """Format success message."""
        if self.json_mode:
            return json.dumps({"success": True, "message": message})
        return message