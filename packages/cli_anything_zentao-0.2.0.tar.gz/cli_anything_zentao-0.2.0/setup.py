"""
Setup script for cli-anything-zentao.

A modern CLI interface for ZenTao Project Management System.
"""

from setuptools import setup, find_namespace_packages

with open("cli_anything/zentao/README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cli-anything-zentao",
    version="0.1.0",
    author="CLI-Anything",
    author_email="noreply@example.com",
    description="A modern CLI interface for ZenTao Project Management System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/cli-anything/zentao",
    license="MIT",
    packages=find_namespace_packages(include=["cli_anything.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business",
        "Topic :: Software Development",
        "Topic :: Software Development :: Bug Tracking",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
        "Typing :: Typed",
    ],
    keywords="zentao pms project-management cli task bug story",
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0.0",
        "click-repl>=0.2.0",
        "prompt-toolkit>=3.0.0",
        "requests>=2.25.0",
        "tabulate>=0.8.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.0.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "cli-anything-zentao=cli_anything.zentao.zentao_cli:main",
        ],
    },
    package_data={
        "cli_anything.zentao": ["README.md"],
        "cli_anything.zentao.skills": ["SKILL.md"],
        "cli_anything.zentao.tests": ["TEST.md"],
    },
    include_package_data=True,
    zip_safe=False,
)