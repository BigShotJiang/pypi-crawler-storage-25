# cli-anything-zentao

A modern CLI interface for ZenTao Project Management System with support for one-shot commands, REPL mode, and JSON output.

## Features

- **Authentication**: Login via password or session token
- **Projects**: List, show, create, update, delete projects
- **Tasks**: Full lifecycle management (create, start, log, finish, close)
- **Bugs**: Create, resolve, close bugs
- **Stories**: Create and manage requirements/stories
- **Products & Executions**: Browse product and sprint information
- **JSON Output**: Machine-readable output for automation
- **REPL Mode**: Interactive command-line interface

## Installation

```bash
pip install cli-anything-zentao
```

## Quick Start

### Authentication

```bash
# Login with password
cli-anything-zentao auth login --url https://zentao.example.com --account admin --password your_password

# Or use session token (useful when login requires captcha)
cli-anything-zentao auth session --url https://zentao.example.com --token your_session_id
```

### Basic Commands

```bash
# List projects
cli-anything-zentao project list

# List tasks
cli-anything-zentao task list

# Create a task (requires execution ID and assignee)
cli-anything-zentao task create --execution 123 --name "New task" --assigned user1

# Show task details
cli-anything-zentao task show 456

# Log work hours
cli-anything-zentao task log 456 --consumed 2 --left 6 --work "Work description"

# Finish and close task
cli-anything-zentao task finish 456 --consumed 8
cli-anything-zentao task close 456
```

### JSON Output

All list and show commands support `--json` flag:

```bash
cli-anything-zentao task list --json
cli-anything-zentao project show 123 --json
```

### Interactive REPL

```bash
cli-anything-zentao repl
```

## Command Reference

| Command Group | Commands |
|--------------|----------|
| `auth` | login, session, logout, status |
| `project` | list, show, create, update, delete |
| `task` | list, show, create, assign, start, log, finish, close |
| `bug` | list, show, create, resolve, close |
| `story` | list, show, create, close |
| `product` | list, show |
| `execution` | list, show |
| `user` | list, me |

## Development

### Setup Development Environment

```bash
git clone https://github.com/cli-anything/zentao.git
cd zentao
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Build Package

```bash
python -m build
```

### Upload to PyPI

```bash
python -m twine upload dist/*
```

## Requirements

- Python 3.8+
- ZenTao PMS 18.0+ (for API v1)

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.