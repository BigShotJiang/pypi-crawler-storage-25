import pytest
import torch

from pyvisgen.simulation.observation import ValidBaselineSubset
from pyvisgen.simulation.scan import (
    RIMEScan,
    angular_distance,
    calc_beam,
    calc_feed_rotation,
    calc_fourier,
    integrate,
    jinc,
)

try:
    import cufinufft  # noqa: F401

    _FINUFFT_AVAIL = True
    _FINUFFT_ERROR = ""

except ImportError as e:
    _FINUFFT_AVAIL = False
    _FINUFFT_ERROR = str(e)


@pytest.fixture
def setup_test_data(device):
    # Set deterministic behavior
    torch.manual_seed(42)

    # Create a simple 2x2 image with a single source in the center
    img = torch.zeros(1, 2, 2, dtype=torch.complex128, device=device)
    img[0, 0, 0] = 1.0 + 0.5j  # type: ignore
    img[0, 0, 1] = 1.0 + 0.5j  # type: ignore

    # Create a simple 2D lm grid
    lm = torch.zeros(1, 1, 2, dtype=torch.float64, device=device)
    lm[..., 0] = torch.tensor([0.01], device=device)
    lm[..., 1] = torch.tensor([0.01], device=device)
    lm = lm.flatten(end_dim=1)

    bas = ValidBaselineSubset(
        u_start=torch.Tensor([]),
        u_stop=torch.Tensor([]),
        u_valid=torch.tensor([100.0, 200.0, 300.0], device=device),  # u
        v_start=torch.Tensor([]),
        v_stop=torch.Tensor([]),
        v_valid=torch.tensor([150.0, 250.0, 350.0], device=device),  # v
        w_start=torch.Tensor([]),
        w_stop=torch.Tensor([]),
        w_valid=torch.tensor([50.0, 100.0, 150.0], device=device),  # w
        baseline_nums=torch.Tensor([]),
        date=torch.Tensor([]),
        q1_start=torch.Tensor([]),
        q1_stop=torch.Tensor([]),
        q1_valid=torch.tensor([0.1], device=device),  # q1
        q2_start=torch.Tensor([]),
        q2_stop=torch.Tensor([]),
        q2_valid=torch.tensor([0.15], device=device),  # q2
        el1_start=torch.Tensor([]),
        el1_stop=torch.Tensor([]),
        el1_valid=torch.tensor([55.0], device=device),
        el2_start=torch.Tensor([]),
        el2_stop=torch.Tensor([]),
        el2_valid=torch.tensor([55.0], device=device),
        st_id_pairs=torch.zeros(1, device=device),
    )

    # Sky position
    ra = torch.tensor(0.0, device=device)
    dec = torch.tensor(0.0, device=device)

    # Antenna properties
    ant_diam = torch.tensor([25.0], device=device)

    # Spectral window frequencies
    spw_low = 1.0e9  # 1 GHz
    spw_high = 2.0e9  # 2 GHz

    # For angular distance
    rd = torch.zeros(1, 1, 2, dtype=torch.float64, device=device)
    rd[..., 0] = 0.001  # ra
    rd[..., 1] = 0.001  # dec
    rd = rd.flatten(end_dim=1)

    return {
        "img": img,
        "bas": bas,
        "lm": lm,
        "rd": rd,
        "ra": ra,
        "dec": dec,
        "ant_diam": ant_diam,
        "spw_low": spw_low,
        "spw_high": spw_high,
        "polarization": "circular",
        "device": device,
    }


class TestJonesMatrices:
    """Unit tests for pyvisgen.simulation.scan module."""

    def test_jinc(self, device):
        """Test the jinc function."""
        # Test with zero
        x_zero = torch.tensor([0.0], dtype=torch.float64, device=device)
        result_zero = jinc(x_zero)
        assert torch.isclose(
            result_zero, torch.tensor([1.0], dtype=torch.float64, device=device)
        )

        # Test with standard values
        x_values = torch.tensor([1.0, 2.0, 3.0], dtype=torch.float64, device=device)
        result = jinc(x_values)

        # Calculate expected values directly from torch's bessel_j1 function
        expected = torch.zeros_like(x_values, dtype=torch.float64)
        expected[x_values != 0] = (
            2
            * torch.special.bessel_j1(x_values[x_values != 0])
            / x_values[x_values != 0]
        )

        assert torch.allclose(result, expected, rtol=1e-6)

        # Additional test to verify actual values
        # Compare with actual values from the executed function
        assert torch.isclose(
            result[0],
            torch.tensor(0.8801, dtype=torch.float64, device=device),
            rtol=1e-4,
        )
        assert torch.isclose(
            result[1],
            torch.tensor(0.5767, dtype=torch.float64, device=device),
            rtol=1e-4,
        )
        assert torch.isclose(
            result[2],
            torch.tensor(0.2260, dtype=torch.float64, device=device),
            rtol=1e-3,
        )

    def test_angular_distance(self, setup_test_data):
        """Test the angular_distance function."""
        rd = setup_test_data["rd"]
        ra = setup_test_data["ra"]
        dec = setup_test_data["dec"]
        device = setup_test_data["device"]

        result = angular_distance(rd, ra, dec)

        # We expect theta to be arcsin(sqrt(rd[...,0]²+rd[...,1]²)) for each point
        expected_shape = (1,)
        assert result.shape == expected_shape

        # For our values (0.001, 0.001), the angular distance is approximately 0.0014
        expected_value = torch.arcsin(
            torch.sqrt(
                torch.tensor(0.001, device=device) ** 2
                + torch.tensor(0.001, device=device) ** 2
            )
        )
        assert torch.allclose(result, expected_value, rtol=1e-5)

    def test_calc_fourier(self, setup_test_data):
        """Test the calc_fourier function."""
        img = setup_test_data["img"]
        bas = setup_test_data["bas"]
        lm = setup_test_data["lm"].flatten(end_dim=-2)
        spw_low = setup_test_data["spw_low"]
        spw_high = setup_test_data["spw_high"]

        X1, X2 = calc_fourier(img, img, bas, lm, spw_low, spw_high)

        # Check shapes
        assert X1.shape[-2:] == img.shape[-2:]
        assert X2.shape[-2:] == img.shape[-2:]
        assert img.real[img.real > 0].shape == lm[-1].shape

        # Check types
        assert X1.dtype == torch.complex128
        assert X2.dtype == torch.complex128

        # Check values are different for different frequencies
        assert not torch.allclose(X1, X2)

    def test_calc_feed_rotation_circular(self, setup_test_data):
        """Test the feed rotation calculation for circular polarization."""
        device = setup_test_data["device"]
        # Simulate polarized visibilities with 2x2 Jones matrices
        X1 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        X2 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        bas = setup_test_data["bas"]
        polarization = "circular"

        X1_rot, X2_rot = calc_feed_rotation(X1, X2, bas, polarization)

        # Check shape preservation
        assert X1_rot.shape == X1.shape
        assert X2_rot.shape == X2.shape

        # Check types
        assert X1_rot.dtype == torch.complex128
        assert X2_rot.dtype == torch.complex128

        # For circular polarization, values should be modified by complex rotation
        assert not torch.allclose(X1_rot, X1)
        assert not torch.allclose(X2_rot, X2)

    def test_calc_feed_rotation_linear(self, setup_test_data):
        """Test the feed rotation calculation for linear polarization."""
        device = setup_test_data["device"]
        # Simulate polarized visibilities with 2x2 Jones matrices
        X1 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        X2 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        bas = setup_test_data["bas"]
        polarization = "linear"

        X1_rot, X2_rot = calc_feed_rotation(X1, X2, bas, polarization)

        # Check shape preservation
        assert X1_rot.shape == X1.shape
        assert X2_rot.shape == X2.shape

        # Check types
        assert X1_rot.dtype == torch.complex128
        assert X2_rot.dtype == torch.complex128

        # For linear polarization, values should be modified by trigonometric functions
        assert not torch.allclose(X1_rot, X1)
        assert not torch.allclose(X2_rot, X2)

    def test_calc_beam(self, setup_test_data):
        """Test the beam calculation function."""
        device = setup_test_data["device"]
        # Create test data for the beam calculation
        X1 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        X2 = torch.ones(2, 1, 2, 2, dtype=torch.complex128, device=device)
        rd = setup_test_data["rd"]
        ra = setup_test_data["ra"]
        dec = setup_test_data["dec"]
        ant_diam = setup_test_data["ant_diam"]
        spw_low = setup_test_data["spw_low"]
        spw_high = setup_test_data["spw_high"]

        EXE1, EXE2 = calc_beam(X1, X2, rd, ra, dec, ant_diam, spw_low, spw_high)

        # Check shape preservation
        assert EXE1.shape == X1.shape
        assert EXE2.shape == X2.shape

        # Check types
        assert EXE1.dtype == torch.complex128
        assert EXE2.dtype == torch.complex128

        # Check values are different for beam-corrected data
        assert not torch.allclose(EXE1, X1)
        assert not torch.allclose(EXE2, X2)

    def test_integrate(self, setup_test_data):
        """Test the integration function."""
        device = setup_test_data["device"]
        # Create test data for integration
        X1 = torch.ones(2, 2, 2, 2, dtype=torch.complex128, device=device)
        X2 = torch.ones(2, 2, 2, 2, dtype=torch.complex128, device=device)

        result = integrate(X1, X2)

        # Expected shape is (2, 2, 2) after summing over one dimension (lm)
        # and averaging over frequency
        expected_shape = (2, 2, 2)
        # Because X1 has all 1s and X2 has all 2s, average should be 1.5
        expected_value = 0.5 * 4  # 4 elements summed for each entry

        # Check shape
        assert result.shape == expected_shape

        # Check that values match expectation
        assert torch.allclose(
            result.real,
            torch.full(
                expected_shape, expected_value.real, dtype=torch.float64, device=device
            ),
        )


class TestRIME:
    @pytest.fixture
    def rime_test_data(self, setup_test_data):
        from dataclasses import dataclass

        data = setup_test_data
        img = data["img"]
        bas = data["bas"]
        spw_low = data["spw_low"]
        spw_high = data["spw_high"]
        ant_diam = data["ant_diam"]

        for key in ["img", "bas", "spw_low", "spw_high", "ant_diam"]:
            data.pop(key)

        @dataclass
        class MockArray:
            diam: torch.Tensor

        @dataclass
        class MockObs:
            lm: torch.Tensor
            rd: torch.Tensor
            ra: torch.Tensor
            dec: torch.Tensor
            array: MockArray
            polarization: str
            device: str
            corrupted: bool
            img_size: int
            fov: float

        return (
            img,
            bas,
            spw_low,
            spw_high,
            MockObs(
                **setup_test_data,
                corrupted=False,
                img_size=img.shape[-1],
                fov=0.24,
                array=MockArray(diam=ant_diam),
            ),
        )

    def test_rime_grid_reversed(self, rime_test_data):
        """Test the complete RIME function."""
        *rime_data, obs = rime_test_data
        obs.polarization = None

        # Test with mode = "grid" (default case)
        rime = RIMEScan("default", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid = rime(
            *rime_data,
        )

        # Test with mode = "grid" (reversed jones ordering)
        rime = RIMEScan("reversed", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid_reversed = rime(
            *rime_data,
        )

        assert torch.isclose(vis_grid_reversed, vis_grid, rtol=1e-8).all()
        assert vis_grid_reversed.dtype == vis_grid.dtype
        assert vis_grid_reversed.shape == vis_grid.shape

    @pytest.mark.skipif(not _FINUFFT_AVAIL, reason=_FINUFFT_ERROR)
    def test_rime_finufft(self, rime_test_data):
        *rime_data, obs = rime_test_data
        obs.polarization = None

        # Test with mode = "grid" (use radioft finufft)
        rime = RIMEScan("finufft", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid_finufft = rime(
            *rime_data,
        )

        rime = RIMEScan("reversed", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid_reversed = rime(
            *rime_data,
        )

        assert torch.isclose(vis_grid_reversed, vis_grid_finufft, rtol=1e-6).all()

    @pytest.mark.parametrize("polarization", ["linear", "circular"])
    def test_rime_grid_polarisation(self, polarization, rime_test_data):
        *rime_data, obs = rime_test_data
        obs.polarization = polarization

        # Test with mode = "grid" with polarization
        rime = RIMEScan("default", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid_pol = rime(*rime_data)

        # Check output shape, should be (baseline, 2, 2)
        expected_shape = (3, 2, 2)
        assert vis_grid_pol.shape == expected_shape

        # Check type
        assert vis_grid_pol.dtype == torch.complex128

    def test_rime_grid_corrupted(self, rime_test_data):
        *rime_data, obs = rime_test_data
        obs.polarization = None

        rime = RIMEScan("default", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        vis_grid = rime(
            *rime_data,
        )

        obs.corrupted = True
        rime = RIMEScan("default", mode="grid", obs=obs, lm=obs.lm, rd=obs.rd)
        # Test with corrupted=True
        vis_corrupted = rime(
            *rime_data,
        )

        expected_shape = (3, 2, 2)

        # Shape should be the same, but values should differ
        assert vis_corrupted.shape == expected_shape
        assert not torch.allclose(vis_corrupted, vis_grid)
