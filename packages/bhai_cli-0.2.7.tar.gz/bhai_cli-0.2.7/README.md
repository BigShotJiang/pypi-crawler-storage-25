# 🇮🇳 BHAI-CLI

**The Dual-Brain Agentic Coding CLI — 22 Indian Languages. One CLI.**

> भाई · ভাই · ભાઈ · ਭਾਈ · భాయ్ · ಭಾಯ್ · भाऊ · ଭାଇ

BHAI is a lean, zero-state resilient CLI tool that acts as your 10x Senior SDE from India. It uses a **Dual-Brain Manager-Worker Architecture** — a VibeLLM for persona, planning, and review, and a CoderAgent for autonomous tool-calling execution — all powered by [litellm](https://github.com/BerriAI/litellm) for universal LLM provider support and [Sarvam AI](https://sarvam.ai) for 22 Indian language understanding.

> *"You are BHAI, a 10x Senior SDE from India. Sab bhasha samajhte ho. You roast O(N²) loops and unoptimized Dockerfiles."*

---

## ✨ Features

- **🧠 Dual-Brain Agentic Architecture**: VibeLLM (Manager/Planner) delegates step-by-step tasks to the CoderAgent (Worker) which autonomously executes tools in a loop.
- **🤖 MCP-Powered File Operations**: Full agentic capability to `read_file`, `write_file`, `edit_file`, and `list_directory` autonomously to build features from scratch.
- **💾 Persistent Session Management**: Chat histories are saved locally with LLM-auto-generated titles. Resume past context anytime from the interactive menu.
- **🖥️ Interactive Menu-Driven CLI**: Simply run `bhai-code` for a rich, beautifully colored terminal UI to chat, manage sessions, and configure settings.
- **🔒 Secure Secrets Storage**: API keys are strictly separated into a `0600` permission `secrets.yaml` and masked during screen display.
- **🇮🇳 22 Indian Languages**: Speak in Hindi, Punjabi, Bengali, Tamil, Telugu, Gujarati, Marathi, Kannada, Malayalam, and more.
- **🌍 Universal LLM Support**: DeepSeek, xAI (Grok), Qwen, OpenAI, Anthropic, Groq, Google Gemini, Sarvam, Mistral, Cerebras, Ollama, Bedrock, and more.
- **🎙️ Indic Voice Interface**: Sarvam Saaras v3 (STT) translates any Indian language to English, Bulbul v3 (TTS) reads responses back.
- **⚡ Zero-State Resilience**: Boots in <300ms, persistent YAML config, hot-swappable model overrides.

---

## 🚀 Installation

```bash
pip install bhai-cli
```

**With voice support (optional):**
```bash
pip install "bhai-cli[audio]"
# Also needs: sudo apt install libportaudio2  (Linux)
```

---

## ⚙️ Setup

```bash
bhai-code setup
```

The interactive wizard will configure:
1. **VibeLLM** — Your planner/persona brain (e.g., `sarvam/sarvam-105b`, `groq/llama-3.3-70b-versatile`)
2. **CoderAgent** — Your autonomous worker brain (e.g., `openai/gpt-4o`, `anthropic/claude-3-5-sonnet-20241022`)
3. **Sarvam AI** — Voice interface API key (optional)
4. **Ollama Port** — Local inference configuration

### Model Format

Uses [litellm's model naming](https://docs.litellm.ai/docs/providers):

| Provider | Format | Example |
|----------|--------|---------|
| Anthropic | `anthropic/model` | `anthropic/claude-3-5-sonnet-20241022` |
| OpenAI | `openai/model` | `openai/gpt-4o` |
| Google | `gemini/model` | `gemini/gemini-2.5-pro` |
| DeepSeek | `deepseek/model` | `deepseek/deepseek-coder` |
| xAI | `xai/model` | `xai/grok-beta` |
| Groq | `groq/model` | `groq/llama-3.3-70b-versatile` |
| Sarvam | `sarvam/model` | `sarvam/sarvam-105b` |
| Ollama | `ollama/model` | `ollama/llama3` |

---

## 💬 Usage

### Interactive Menu (Recommended)
```bash
# Opens the rich terminal UI for chats, session management, and settings
bhai-code
```

### Text Mode
```bash
# Directly start a new chat session interactively
bhai-code text

# Single prompt execution
bhai-code text "explain the pyproject.toml file"

# Resume a specific session
bhai-code text --session-id <uuid>

# Override models on the fly
bhai-code text "optimize this Dockerfile" --vibe-model groq/llama-3.3-70b-versatile --coder-model openai/gpt-4o
```

### Voice Mode
```bash
# Live microphone
bhai-code listen

# From audio file
bhai-code listen --file recording.wav
```

### View Config
```bash
bhai-code config
```

---

## 🏗️ Architecture

```
User Input (Any of 22 Indian Languages / English)
         │
         ▼
┌─────────────────────┐
│   VibeLLM (Brain A)  │  ← Persona + Planning + Session Management
│   Sarvam-105B / any  │
└──────────┬──────────┘
           │ {"task": "step-by-step instructions"}
           ▼
┌─────────────────────┐
│  CoderAgent (Brain B)│  ← Autonomous Execution Loop
│  Any litellm model   │
│                      │
│  Tools:              │
│  • read/write/edit   │  ← File System Ops
│  • execute_bash      │  ← [Y/n] Guardrail
│  • web_search        │  ← DuckDuckGo
│  • codebase_context  │  ← AST signatures
└──────────┬──────────┘
           │ Results
           ▼
┌─────────────────────┐
│   VibeLLM (Brain A)  │  ← Review & Final Output
└─────────────────────┘
```

---

## 🔧 Tools (MCP-Powered)

| Tool | Description |
|------|-------------|
| `read_file` | Read the exact contents of a file before editing |
| `write_file` | Create a new file with provided content |
| `edit_file` | Target specific line ranges to replace code blocks |
| `list_directory` | Explore project structure to navigate codebase |
| `execute_bash` | Run shell commands (tests, docker, git) with `[Y/n]` confirmation |
| `web_search` | DuckDuckGo search for real-time debugging |
| `codebase_context` | Smart directory scanner with AST-based signature extraction |

---

## 📁 Project Structure

```
bhai-cli/
├── src/bhai_cli/
│   ├── __init__.py          # Package metadata
│   ├── cli.py               # Rich interactive Typer CLI
│   ├── config_manager.py    # Configuration & secure secrets
│   ├── session_manager.py   # Chat history persistence & auto-titling
│   ├── orchestrator.py      # Dual-Brain Agentic Loop
│   ├── audio_engine.py      # Sarvam STT/TTS
│   └── tools/
│       ├── __init__.py      # Tool registry + JSON schemas
│       ├── file_ops.py      # Read, Write, Edit, List tools
│       ├── bash.py          # execute_bash with guardrails
│       ├── search.py        # web_search via DuckDuckGo
│       └── codebase.py      # codebase_context with AST
├── tests/
├── website/                 # Next.js Landing Page Frontend
├── pyproject.toml
├── bhai_cli_documentation.html # Exhaustive local docs (gitignored)
└── README.md
```

---

## 🔑 Environment Variables & Secrets

API keys are securely isolated in `~/.config/bhai/secrets.yaml` (0600 permissions).
Supported keys include: `SARVAM_API_KEY`, `VIBE_API_KEY`, `CODER_API_KEY`, `GROQ_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `DEEPSEEK_API_KEY`, `XAI_API_KEY`.

---

## 📄 License

Apache-2.0 — see [LICENSE](LICENSE).

Built with ❤️ from India by [Madhav Kapila](https://github.com/madhavkapila).
