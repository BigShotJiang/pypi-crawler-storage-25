"""
web_search — Real-time web search via DuckDuckGo.

Uses the `duckduckgo-search` package for lightweight, zero-auth search.
Optimized for debugging queries and documentation lookups.
"""

from __future__ import annotations

from duckduckgo_search import DDGS


DEFAULT_MAX_RESULTS = 5


def web_search(query: str, max_results: int = DEFAULT_MAX_RESULTS) -> str:
    """
    Search the web using DuckDuckGo and return formatted results.

    Args:
        query: The search query.
        max_results: Maximum number of results to return.

    Returns:
        Formatted string of search results with titles, URLs, and snippets.
    """
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))

        if not results:
            return f"[NO RESULTS] No results found for query: '{query}'"

        formatted: list[str] = [f"Search results for: '{query}'\n{'=' * 60}"]

        for i, r in enumerate(results, 1):
            title = r.get("title", "No title")
            href = r.get("href", "No URL")
            body = r.get("body", "No snippet")
            formatted.append(
                f"\n[{i}] {title}\n"
                f"    URL: {href}\n"
                f"    {body}"
            )

        return "\n".join(formatted)

    except Exception as e:
        return f"[ERROR] Web search failed: {type(e).__name__}: {e}"
