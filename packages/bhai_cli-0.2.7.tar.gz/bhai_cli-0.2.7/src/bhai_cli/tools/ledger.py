"""
Stateful Planning Ledger — The `.bhai/plan.md` State Machine.

This module implements the Human-in-the-Loop (HITL) planning layer for
Bhai-CLI v2.  The CoderAgent writes a structured Markdown roadmap before
executing multi-step tasks, and the *user* can manually edit that file
in VS Code / vim / nano at any point to steer the agent.

The plan uses GitHub-flavored task-list syntax:
    - [ ] pending
    - [x] done
    - [-] failed / skipped

Design constraints (Accordion Scalability):
    • Every function returns a plain string — safe for *any* LLM context
      window, from Llama-3-8B on Groq to Claude 3.5 Opus.
    • JSON tool schemas are kept intentionally tiny (≤ 3 params each) so
      smaller models never choke on schema decoding.
    • Zero external dependencies — only stdlib pathlib + re.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

console = Console()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PLAN_DIR = ".bhai"
PLAN_FILE = "plan.md"

# Regex matching any task-list line:  - [ ] / - [x] / - [-]
_TASK_RE = re.compile(r"^(\s*- \[)([ x\-])(\] .+)$")


def _plan_path() -> Path:
    """Resolve the plan file path relative to CWD."""
    return Path.cwd() / PLAN_DIR / PLAN_FILE


# ---------------------------------------------------------------------------
# Tool: create_plan
# ---------------------------------------------------------------------------

def create_plan(tasks: list[str]) -> str:
    """
    Create a `.bhai/plan.md` roadmap with a numbered task checklist.

    If a plan already exists it is backed up as `plan.md.bak` so no
    previous context is lost.

    Args:
        tasks: A list of human-readable task descriptions.

    Returns:
        A confirmation string with the plan contents, or an error.
    """
    if not tasks:
        return "[ERROR] create_plan requires at least one task."

    plan_dir = Path.cwd() / PLAN_DIR
    plan_dir.mkdir(parents=True, exist_ok=True)
    plan_file = plan_dir / PLAN_FILE

    # Back up any existing plan
    if plan_file.exists():
        backup = plan_dir / f"{PLAN_FILE}.bak"
        backup.write_text(plan_file.read_text())

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# 🗺️  BHAI Execution Plan",
        f"",
        f"> Created: {timestamp}",
        f"> Status: **IN PROGRESS**",
        f"",
        f"---",
        f"",
    ]
    for i, task in enumerate(tasks, 1):
        lines.append(f"- [ ] **Step {i}:** {task}")

    lines += [
        "",
        "---",
        "",
        "> **Human-in-the-Loop:** Edit this file freely in your editor.",
        "> The agent will re-read it before each step.",
    ]

    content = "\n".join(lines) + "\n"
    plan_file.write_text(content)

    abs_path = plan_file.resolve()

    # Pretty-print in the terminal with ABSOLUTE path
    console.print()
    console.print(Panel(
        Markdown(content),
        title=f"[bold green]📋 Plan Created[/]",
        subtitle=f"[dim]{abs_path}[/]",
        border_style="green",
        padding=(1, 2),
    ))
    console.print(f"  [dim]📂 Location:[/] [bold cyan]{abs_path}[/]")

    return f"[SUCCESS] Plan created at {abs_path} with {len(tasks)} steps.\n\n{content}"


# ---------------------------------------------------------------------------
# Tool: read_plan
# ---------------------------------------------------------------------------

def read_plan() -> str:
    """
    Read the current `.bhai/plan.md` and return its contents.

    This MUST be called before resuming execution so that any manual
    edits the user made in their editor are respected.

    Returns:
        The full Markdown contents of the plan, or an error.
    """
    plan_file = _plan_path()
    if not plan_file.exists():
        return (
            "[ERROR] No plan found at .bhai/plan.md.  "
            "Use create_plan first to write a roadmap."
        )

    content = plan_file.read_text()

    # Parse progress stats for the agent
    total = 0
    done = 0
    failed = 0
    pending = 0
    for line in content.splitlines():
        m = _TASK_RE.match(line)
        if m:
            total += 1
            marker = m.group(2)
            if marker == "x":
                done += 1
            elif marker == "-":
                failed += 1
            else:
                pending += 1

    summary = (
        f"[PLAN STATUS] Total: {total} | "
        f"✅ Done: {done} | ⏳ Pending: {pending} | ❌ Failed: {failed}"
    )

    console.print()
    console.print(Panel(
        Markdown(content),
        title="[bold cyan]📖 Current Plan[/]",
        subtitle=f"[dim]{summary}[/]",
        border_style="cyan",
        padding=(1, 2),
    ))

    return f"{summary}\n\n{content}"


# ---------------------------------------------------------------------------
# Tool: update_plan_step
# ---------------------------------------------------------------------------

def update_plan_step(step_number: int, status: str) -> str:
    """
    Update a specific step's checkbox in `.bhai/plan.md`.

    Args:
        step_number: 1-indexed step number to update.
        status: One of "done", "failed", or "pending".

    Returns:
        Confirmation with the updated line, or an error.
    """
    plan_file = _plan_path()
    if not plan_file.exists():
        return "[ERROR] No plan found. Use create_plan first."

    status_lower = status.strip().lower()
    marker_map = {
        "done": "x",
        "failed": "-",
        "pending": " ",
        "x": "x",
        "-": "-",
        " ": " ",
        "skip": "-",
        "skipped": "-",
    }
    marker = marker_map.get(status_lower)
    if marker is None:
        return (
            f"[ERROR] Invalid status '{status}'. "
            f"Use one of: done, failed, pending."
        )

    lines = plan_file.read_text().splitlines(keepends=True)

    # Find the Nth task-list line
    task_index = 0
    target_line_idx = None
    for i, line in enumerate(lines):
        if _TASK_RE.match(line.rstrip("\n")):
            task_index += 1
            if task_index == step_number:
                target_line_idx = i
                break

    if target_line_idx is None:
        return f"[ERROR] Step {step_number} not found. Plan has {task_index} steps."

    # Mutate the checkbox
    old_line = lines[target_line_idx].rstrip("\n")
    m = _TASK_RE.match(old_line)
    if not m:
        return f"[ERROR] Could not parse task line: {old_line}"

    new_line = f"{m.group(1)}{marker}{m.group(3)}\n"
    lines[target_line_idx] = new_line

    # Check if all steps are now done/failed → update header status
    all_content = "".join(lines)
    remaining = sum(1 for l in lines if _TASK_RE.match(l.rstrip("\n")) and _TASK_RE.match(l.rstrip("\n")).group(2) == " ")
    if remaining == 0:
        all_content = all_content.replace(
            "Status: **IN PROGRESS**",
            "Status: **✅ COMPLETED**",
        )

    plan_file.write_text(all_content)

    # Terminal feedback
    status_emoji = {"x": "✅", "-": "❌", " ": "⏳"}.get(marker, "❓")
    console.print(
        f"  {status_emoji} [bold]Step {step_number}[/] → "
        f"[{'green' if marker == 'x' else 'red' if marker == '-' else 'yellow'}]"
        f"{status_lower.upper()}[/]"
    )

    return (
        f"[SUCCESS] Step {step_number} marked as {status_lower}.\n"
        f"Updated line: {new_line.strip()}"
    )
