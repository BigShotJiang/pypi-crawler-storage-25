"""
execute_bash — Run shell commands with a hard [Y/n] user guardrail.

Handles long-running processes via configurable timeouts and returns
cleaned stdout/stderr output.
"""

from __future__ import annotations

import subprocess
import shlex

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

console = Console()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_TIMEOUT = 30  # seconds


def execute_bash(command: str, timeout: int = DEFAULT_TIMEOUT) -> str:
    """
    Execute a bash command after explicit user confirmation.

    Args:
        command: The shell command to run.
        timeout: Max seconds to wait before killing the process.

    Returns:
        A string containing stdout, stderr, and return code.
    """
    # ── Display the command for review ──
    console.print()
    console.print(
        Panel(
            Syntax(command, "bash", theme="monokai", line_numbers=False),
            title="[bold yellow]🔧 BHAI wants to run this command[/]",
            border_style="yellow",
            padding=(1, 2),
        )
    )

    # ── Hard Guardrail: Manual [Y/n] prompt ──
    console.print(
        "[bold cyan]Execute this command?[/] [dim](Y/n — 'Haan' bolo ya 'Nahi')[/] ",
        end="",
    )
    answer = input().strip().lower()

    approved_responses = {"y", "yes", "haan", "ha", "h", ""}
    if answer not in approved_responses:
        return "[BLOCKED] User declined command execution."

    # ── Execute ──
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=None,  # inherit CWD
        )

        output_parts: list[str] = []

        if result.stdout.strip():
            output_parts.append(f"[STDOUT]\n{result.stdout.strip()}")
        if result.stderr.strip():
            output_parts.append(f"[STDERR]\n{result.stderr.strip()}")

        output_parts.append(f"[EXIT CODE] {result.returncode}")

        return "\n\n".join(output_parts)

    except subprocess.TimeoutExpired:
        return (
            f"[TIMEOUT] Command exceeded {timeout}s limit and was killed.\n"
            f"Command: {command}"
        )
    except Exception as e:
        return f"[ERROR] Failed to execute command: {type(e).__name__}: {e}"
