"""
codebase_context — Smart codebase scanner with anti-context-rot.

Prioritizes file tree structure and function/class signatures over full
content to keep LLM context windows lean. Full content mode is opt-in
for specific files only.
"""

from __future__ import annotations

import ast
import os
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_MAX_DEPTH = 4
IGNORED_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
    ".mypy_cache", ".pytest_cache", ".tox", "dist", "build",
    ".egg-info", ".eggs", "htmlcov", ".idea", ".vscode",
}
IGNORED_FILES = {".DS_Store", "Thumbs.db", "poetry.lock", "package-lock.json"}
CODE_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java", ".rb", ".sh"}


def _extract_python_signatures(filepath: Path) -> list[str]:
    """Extract function and class signatures from a Python file using AST."""
    signatures: list[str] = []
    try:
        source = filepath.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source, filename=str(filepath))

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                bases = ", ".join(
                    ast.unparse(base) for base in node.bases
                ) if node.bases else ""
                sig = f"  class {node.name}({bases}):" if bases else f"  class {node.name}:"
                signatures.append(f"  L{node.lineno}: {sig}")

                # Extract methods
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        prefix = "async " if isinstance(item, ast.AsyncFunctionDef) else ""
                        args = ast.unparse(item.args) if item.args.args else ""
                        signatures.append(
                            f"    L{item.lineno}: {prefix}def {item.name}({args})"
                        )

            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Top-level functions only (skip methods already handled)
                if not any(
                    isinstance(parent, ast.ClassDef)
                    for parent in ast.walk(tree)
                    if hasattr(parent, "body") and node in getattr(parent, "body", [])
                ):
                    prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
                    args = ast.unparse(node.args) if node.args.args else ""
                    signatures.append(
                        f"  L{node.lineno}: {prefix}def {node.name}({args})"
                    )

    except (SyntaxError, UnicodeDecodeError):
        signatures.append("  [Could not parse file]")

    return signatures


def _extract_signatures(filepath: Path) -> list[str]:
    """Extract signatures based on file extension."""
    if filepath.suffix == ".py":
        return _extract_python_signatures(filepath)
    # For non-Python code files, use a simple grep for common patterns
    if filepath.suffix in CODE_EXTENSIONS:
        sigs: list[str] = []
        try:
            lines = filepath.read_text(encoding="utf-8", errors="ignore").splitlines()
            for i, line in enumerate(lines, 1):
                stripped = line.strip()
                # Match common function/class declarations
                if any(stripped.startswith(kw) for kw in (
                    "def ", "async def ", "class ", "function ", "const ", "let ",
                    "export ", "pub fn ", "fn ", "func ", "public ", "private ",
                    "protected ", "static ",
                )):
                    sigs.append(f"  L{i}: {stripped[:120]}")
            if len(sigs) > 50:
                sigs = sigs[:50]
                sigs.append("  ... (truncated)")
        except (UnicodeDecodeError, OSError):
            sigs.append("  [Could not read file]")
        return sigs
    return []


def _scan_tree(
    root: Path,
    current_depth: int,
    max_depth: int,
    include_content: bool,
    prefix: str = "",
) -> list[str]:
    """Recursively build a directory tree with optional signatures."""
    lines: list[str] = []

    if current_depth > max_depth:
        return lines

    try:
        entries = sorted(root.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
    except PermissionError:
        lines.append(f"{prefix}[Permission Denied]")
        return lines

    for entry in entries:
        if entry.name in IGNORED_DIRS or entry.name in IGNORED_FILES:
            continue
        if entry.name.startswith(".") and entry.name not in {".env", ".gitignore"}:
            continue

        if entry.is_dir():
            lines.append(f"{prefix}📁 {entry.name}/")
            lines.extend(
                _scan_tree(entry, current_depth + 1, max_depth, include_content, prefix + "  ")
            )
        elif entry.is_file():
            size_kb = entry.stat().st_size / 1024
            lines.append(f"{prefix}📄 {entry.name} ({size_kb:.1f} KB)")

            if include_content and size_kb < 100:  # Don't include huge files
                try:
                    content = entry.read_text(encoding="utf-8", errors="ignore")
                    lines.append(f"{prefix}  ─── Content ───")
                    for cline in content.splitlines()[:200]:
                        lines.append(f"{prefix}  {cline}")
                    if len(content.splitlines()) > 200:
                        lines.append(f"{prefix}  ... (truncated at 200 lines)")
                    lines.append(f"{prefix}  ─── End ───")
                except (UnicodeDecodeError, OSError):
                    lines.append(f"{prefix}  [Binary or unreadable]")
            else:
                # Signatures only (anti-context-rot)
                sigs = _extract_signatures(entry)
                lines.extend(sigs)

    return lines


def codebase_context(
    path: str,
    include_content: bool = False,
    max_depth: int = DEFAULT_MAX_DEPTH,
) -> str:
    """
    Scan a local directory/file and return structured context.

    Args:
        path: Directory or file path to scan.
        include_content: If True, include full file content (use sparingly).
        max_depth: Maximum recursion depth for directories.

    Returns:
        Formatted string with file tree and signatures.
    """
    target = Path(path).resolve()

    if not target.exists():
        return f"[ERROR] Path does not exist: {target}"

    if target.is_file():
        lines = [f"📄 {target.name} ({target.stat().st_size / 1024:.1f} KB)"]
        if include_content:
            try:
                content = target.read_text(encoding="utf-8", errors="ignore")
                lines.append("─── Content ───")
                lines.extend(content.splitlines()[:500])
                if len(content.splitlines()) > 500:
                    lines.append("... (truncated at 500 lines)")
                lines.append("─── End ───")
            except (UnicodeDecodeError, OSError):
                lines.append("[Binary or unreadable]")
        else:
            sigs = _extract_signatures(target)
            lines.extend(sigs)
        return "\n".join(lines)

    # Directory scan
    header = f"Codebase scan: {target}\nMax depth: {max_depth}\n{'=' * 60}"
    tree_lines = _scan_tree(target, 0, max_depth, include_content)
    return header + "\n" + "\n".join(tree_lines)
