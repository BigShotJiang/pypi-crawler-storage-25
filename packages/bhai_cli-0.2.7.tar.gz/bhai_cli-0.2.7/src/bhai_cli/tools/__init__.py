"""
MCP-Style Tool Definitions for BHAI CoderAgent.

Each tool is defined as a JSON-RPC-style schema that litellm can natively
inject into any provider's tool-calling API (OpenAI, Anthropic, Groq, etc.).
"""

from __future__ import annotations

from bhai_cli.tools.bash import execute_bash
from bhai_cli.tools.search import web_search
from bhai_cli.tools.codebase import codebase_context
from bhai_cli.tools.file_ops import read_file, write_file, edit_file, list_directory
from bhai_cli.tools.ledger import create_plan, read_plan, update_plan_step

# ---------------------------------------------------------------------------
# Tool Registry: JSON schemas for litellm tool_choice
# ---------------------------------------------------------------------------

TOOL_SCHEMAS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "execute_bash",
            "description": (
                "Execute a bash command on the user's terminal. "
                "Returns stdout and stderr. ALWAYS requires user confirmation before execution. "
                "Use for: running scripts, installing packages, git operations, docker commands, "
                "file manipulation, and any system-level task."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The bash command to execute.",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Max seconds to wait for command completion. Default: 30.",
                    },
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": (
                "Search the web for real-time information using DuckDuckGo. "
                "Use for: debugging errors, finding documentation, looking up library APIs, "
                "checking latest versions, and any information retrieval task."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query string.",
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results to return. Default: 5.",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "codebase_context",
            "description": (
                "Recursively scan a local directory to understand the codebase structure. "
                "Returns a tree of files with function/class signatures to prevent context rot. "
                "Use 'include_content=true' only for specific files when full content is needed."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute or relative directory/file path to scan.",
                    },
                    "include_content": {
                        "type": "boolean",
                        "description": "If true, include full file content. Default: false. MUST BE A NATIVE JSON BOOLEAN (true/false), NOT A STRING.",
                    },
                    "max_depth": {
                        "type": "integer",
                        "description": "Max directory recursion depth. Default: 4.",
                    },
                },
                "required": ["path"],
            },
        },
    },
    # ── File Operations (agentic execution) ──
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": (
                "Read the contents of a file. Always read a file before editing it. "
                "Use start_line/end_line to read specific sections of large files."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read.",
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "1-indexed start line. 0 means beginning of file.",
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "1-indexed end line. 0 means end of file.",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": (
                "Create a new file or overwrite an existing file with content. "
                "Requires user confirmation. Parent directories are created automatically."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to create/overwrite.",
                    },
                    "content": {
                        "type": "string",
                        "description": "The full content to write to the file.",
                    },
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": (
                "Edit a file by replacing exact text. ALWAYS read the file first to get "
                "the exact text to replace. The old_text must match exactly."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to edit.",
                    },
                    "old_text": {
                        "type": "string",
                        "description": "The exact text to find and replace.",
                    },
                    "new_text": {
                        "type": "string",
                        "description": "The replacement text.",
                    },
                },
                "required": ["path", "old_text", "new_text"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": (
                "List files and subdirectories in a directory. "
                "Use recursive=true to explore nested structure."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the directory. Default: current directory.",
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "If true, list recursively. Default: false. MUST BE A NATIVE JSON BOOLEAN (true/false), NOT A STRING.",
                    },
                    "max_depth": {
                        "type": "integer",
                        "description": "Max recursion depth when recursive=true. Default: 3.",
                    },
                },
                "required": [],
            },
        },
    },
    # ── Stateful Planning Ledger (v2 HITL Decision Layer) ──
    {
        "type": "function",
        "function": {
            "name": "create_plan",
            "description": (
                "Create a .bhai/plan.md roadmap BEFORE starting any multi-step task. "
                "Write a checklist of steps you intend to execute. After creating it, "
                "STOP and ask the user to review/edit the plan in their editor before "
                "you continue. This is the Human-in-the-Loop checkpoint."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "tasks": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of task descriptions for the roadmap.",
                    },
                },
                "required": ["tasks"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_plan",
            "description": (
                "Read the current .bhai/plan.md to see the latest roadmap. "
                "ALWAYS call this after the user confirms the plan, and before "
                "each step, so you respect any manual edits they made."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_plan_step",
            "description": (
                "Mark a step in .bhai/plan.md as done, failed, or pending. "
                "Call this AFTER completing each step to track your progress."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "step_number": {
                        "type": "integer",
                        "description": "The 1-indexed step number to update.",
                    },
                    "status": {
                        "type": "string",
                        "description": "New status: done, failed, or pending.",
                    },
                },
                "required": ["step_number", "status"],
            },
        },
    },
]

# ---------------------------------------------------------------------------
# Tool Dispatcher
# ---------------------------------------------------------------------------

TOOL_DISPATCH = {
    "execute_bash": execute_bash,
    "web_search": web_search,
    "codebase_context": codebase_context,
    "read_file": read_file,
    "write_file": write_file,
    "edit_file": edit_file,
    "list_directory": list_directory,
    # v2 Stateful Planning Ledger
    "create_plan": create_plan,
    "read_plan": read_plan,
    "update_plan_step": update_plan_step,
}


async def dispatch_tool(name: str, arguments: dict) -> str:
    """Route a tool call to its implementation and return the string result."""
    handler = TOOL_DISPATCH.get(name)
    if handler is None:
        return f"[ERROR] Unknown tool: {name}"
    try:
        import asyncio
        if asyncio.iscoroutinefunction(handler):
            return await handler(**arguments)
        else:
            return handler(**arguments)
    except Exception as e:
        return f"[ERROR] Tool '{name}' failed: {type(e).__name__}: {e}"
