"""
File Operations Tools — read, write, edit files and list directories.

These tools enable agentic execution: the agent can autonomously
read code, write new files, edit existing files, and explore the
project structure — just like Claude Code.
"""

from __future__ import annotations

import os
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

console = Console()


def read_file(path: str, start_line: int = 0, end_line: int = 0) -> str:
    """
    Read the contents of a file.

    Args:
        path: Absolute or relative path to the file.
        start_line: Optional 1-indexed start line (0 = beginning).
        end_line: Optional 1-indexed end line (0 = end of file).

    Returns:
        File contents as a string, or error message.
    """
    try:
        p = Path(path).resolve()
        if not p.exists():
            return f"[ERROR] File not found: {path}"
        if not p.is_file():
            return f"[ERROR] Not a file: {path}"
        if p.stat().st_size > 1_000_000:  # 1MB safety limit
            return f"[ERROR] File too large ({p.stat().st_size} bytes). Use start_line/end_line."

        lines = p.read_text(errors="replace").splitlines(keepends=True)
        total = len(lines)

        s = max(0, (start_line - 1) if start_line > 0 else 0)
        e = end_line if end_line > 0 else total

        selected = lines[s:e]
        header = f"[{p.name}] Lines {s+1}-{min(e, total)} of {total}\n"
        return header + "".join(selected)

    except Exception as ex:
        return f"[ERROR] read_file failed: {type(ex).__name__}: {ex}"


def write_file(path: str, content: str) -> str:
    """
    Create or overwrite a file with the given content.

    Args:
        path: Absolute or relative path to the file.
        content: The full content to write.

    Returns:
        Success or error message.
    """
    # ── Guardrail: confirm with user ──
    console.print()
    console.print(
        Panel(
            f"[bold white]{path}[/]\n[dim]{len(content)} characters, "
            f"{content.count(chr(10))+1} lines[/]",
            title="[bold yellow]📝 BHAI wants to write this file[/]",
            border_style="yellow",
        )
    )
    console.print("[bold cyan]Write this file?[/] [dim](Y/n)[/] ", end="")
    answer = input().strip().lower()
    if answer not in {"y", "yes", "haan", "ha", "h", ""}:
        return "[BLOCKED] User declined file write."

    try:
        p = Path(path).resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return f"[SUCCESS] Wrote {len(content)} chars to {p}"
    except Exception as ex:
        return f"[ERROR] write_file failed: {type(ex).__name__}: {ex}"


def edit_file(path: str, old_text: str, new_text: str) -> str:
    """
    Edit a file by replacing old_text with new_text.

    Args:
        path: Path to the file.
        old_text: The exact text to find and replace.
        new_text: The replacement text.

    Returns:
        Success or error message.
    """
    try:
        p = Path(path).resolve()
        if not p.exists():
            return f"[ERROR] File not found: {path}"

        original = p.read_text(errors="replace")
        count = original.count(old_text)

        if count == 0:
            return f"[ERROR] Target text not found in {path}. Read the file first to get exact content."
        if count > 1:
            return f"[WARNING] Found {count} occurrences. Replacing ALL of them."

        # ── Guardrail ──
        preview = f"- {old_text[:200]}\n+ {new_text[:200]}"
        console.print()
        console.print(
            Panel(
                f"[bold white]{path}[/]\n[dim]{count} replacement(s)[/]\n\n{preview}",
                title="[bold yellow]✏️  BHAI wants to edit this file[/]",
                border_style="yellow",
            )
        )
        console.print("[bold cyan]Apply this edit?[/] [dim](Y/n)[/] ", end="")
        answer = input().strip().lower()
        if answer not in {"y", "yes", "haan", "ha", "h", ""}:
            return "[BLOCKED] User declined file edit."

        updated = original.replace(old_text, new_text)
        p.write_text(updated)
        return f"[SUCCESS] Replaced {count} occurrence(s) in {p}"

    except Exception as ex:
        return f"[ERROR] edit_file failed: {type(ex).__name__}: {ex}"


def list_directory(path: str = ".", recursive: bool = False, max_depth: int = 3) -> str:
    """
    List contents of a directory.

    Args:
        path: Path to directory.
        recursive: If True, list recursively up to max_depth.
        max_depth: Maximum recursion depth.

    Returns:
        Directory listing as a string.
    """
    try:
        p = Path(path).resolve()
        if not p.exists():
            return f"[ERROR] Directory not found: {path}"
        if not p.is_dir():
            return f"[ERROR] Not a directory: {path}"

        lines = [f"📁 {p}/\n"]
        _list_recursive(p, lines, depth=0, max_depth=max_depth if recursive else 0)
        return "".join(lines)

    except Exception as ex:
        return f"[ERROR] list_directory failed: {type(ex).__name__}: {ex}"


def _list_recursive(directory: Path, lines: list, depth: int, max_depth: int) -> None:
    """Helper to recursively list directory contents."""
    SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".tox", ".mypy_cache", "dist", "build"}

    try:
        entries = sorted(directory.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
    except PermissionError:
        lines.append("  " * (depth + 1) + "⚠ Permission denied\n")
        return

    indent = "  " * (depth + 1)
    for entry in entries:
        if entry.name.startswith(".") and entry.is_dir() and entry.name in SKIP_DIRS:
            continue
        if entry.name in SKIP_DIRS:
            continue

        if entry.is_dir():
            lines.append(f"{indent}📁 {entry.name}/\n")
            if depth < max_depth:
                _list_recursive(entry, lines, depth + 1, max_depth)
        else:
            size = entry.stat().st_size
            if size > 1_000_000:
                size_str = f"{size / 1_000_000:.1f}MB"
            elif size > 1000:
                size_str = f"{size / 1000:.1f}KB"
            else:
                size_str = f"{size}B"
            lines.append(f"{indent}📄 {entry.name} ({size_str})\n")
