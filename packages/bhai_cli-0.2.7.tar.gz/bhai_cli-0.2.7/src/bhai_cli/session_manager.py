"""
Session Manager for BHAI-CLI.

Handles persistent conversation history across multiple sessions.
Stores sessions as JSON files in ~/.config/bhai/sessions/.
"""

from __future__ import annotations

import json
import uuid
import datetime
from pathlib import Path

from bhai_cli.config_manager import CONFIG_DIR

SESSIONS_DIR = CONFIG_DIR / "sessions"

def _get_sessions_dir() -> Path:
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    return SESSIONS_DIR

def create_session_id() -> str:
    """Generate a new short hash-based session ID."""
    return uuid.uuid4().hex[:8]

def get_all_sessions() -> list[dict]:
    """
    Retrieve metadata for all saved sessions.
    Returns a list of dicts: {"id": str, "title": str, "updated_at": str}
    sorted by updated_at descending.
    """
    sessions_dir = _get_sessions_dir()
    sessions = []
    
    for file_path in sessions_dir.glob("*.json"):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                sessions.append({
                    "id": data.get("id", file_path.stem),
                    "title": data.get("title", "Untitled Session"),
                    "updated_at": data.get("updated_at", ""),
                })
        except Exception:
            pass
            
    sessions.sort(key=lambda x: x["updated_at"], reverse=True)
    return sessions

def load_session(session_id: str) -> tuple[str, list[dict]]:
    """
    Load a session from disk.
    Returns (title, history).
    If session_id doesn't exist, returns ("", []).
    """
    file_path = _get_sessions_dir() / f"{session_id}.json"
    if not file_path.exists():
        return "", []
        
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("title", ""), data.get("history", [])
    except Exception:
        return "", []

def save_session(session_id: str, title: str, history: list[dict]) -> None:
    """
    Save the session history and title to disk.
    """
    file_path = _get_sessions_dir() / f"{session_id}.json"
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
    
    data = {
        "id": session_id,
        "title": title or "Untitled Session",
        "updated_at": now_iso,
        "history": history,
    }
    
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def delete_session(session_id: str) -> bool:
    """Delete a session file. Returns True if deleted, False otherwise."""
    file_path = _get_sessions_dir() / f"{session_id}.json"
    if file_path.exists():
        try:
            file_path.unlink()
            return True
        except Exception:
            return False
    return False
