"""
Configuration Manager for BHAI-CLI.

Handles persistent YAML config at ~/.config/bhai/config.yaml,
secrets at ~/.config/bhai/secrets.yaml (0600 permissions),
environment variable overrides, and .env file loading.
Pydantic-validated with hot-swap support via CLI flags.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
CONFIG_DIR = Path.home() / ".config" / "bhai"
CONFIG_FILE = CONFIG_DIR / "config.yaml"
SECRETS_FILE = CONFIG_DIR / "secrets.yaml"
ENV_FILE = Path.cwd() / ".env"

# Keys that are secrets and must be stored separately
_SECRET_FIELDS = {"api_key"}

# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------

class SarvamConfig(BaseModel):
    """Sarvam AI credentials and preferences."""
    api_key: str = Field(default="", description="Sarvam API subscription key")
    stt_model: str = Field(default="saaras:v3", description="STT model identifier")
    stt_mode: str = Field(
        default="translate",
        description="STT mode: transcribe | translate | verbatim | translit | codemix",
    )
    tts_model: str = Field(default="bulbul:v3", description="TTS model identifier")
    tts_speaker: str = Field(default="shubh", description="TTS voice speaker name")
    tts_language: str = Field(default="en-IN", description="TTS target language code")


class VibeConfig(BaseModel):
    """VibeLLM (Brain A) configuration."""
    model: str = Field(
        default="sarvam/sarvam-105b",
        description="litellm model string for the VibeLLM (persona brain)",
    )
    api_key: str = Field(default="", description="API key for the VibeLLM provider")
    api_base: str = Field(default="", description="Custom API base URL (for Ollama, etc.)")
    ollama_port: int = Field(default=11434, description="Ollama server port (used when model starts with ollama/)")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=1024, ge=64)


class CoderConfig(BaseModel):
    """CoderAgent (Brain B) configuration."""
    model: str = Field(
        default="groq/llama-3.3-70b-versatile",
        description="litellm model string for the CoderAgent (tool-calling brain)",
    )
    api_key: str = Field(default="", description="API key for the CoderAgent provider")
    api_base: str = Field(default="", description="Custom API base URL (for Ollama, etc.)")
    ollama_port: int = Field(default=11434, description="Ollama server port (used when model starts with ollama/)")
    temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=64)


class BhaiConfig(BaseModel):
    """Root configuration model."""
    vibe: VibeConfig = Field(default_factory=VibeConfig)
    coder: CoderConfig = Field(default_factory=CoderConfig)
    sarvam: SarvamConfig = Field(default_factory=SarvamConfig)
    command_timeout: int = Field(default=30, description="Bash command timeout in seconds")
    audio_fallback_file: str = Field(
        default="",
        description="Path to a pre-recorded audio file for STT fallback (empty = live mic)",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mask_key(key: str) -> str:
    """Return a masked version of an API key for display."""
    if not key or len(key) < 8:
        return "(not set)"
    return "••••" + key[-4:]


def _resolve_ollama_base(model: str, api_base: str, port: int) -> str:
    """Auto-set api_base for Ollama models if not explicitly configured."""
    if model.startswith("ollama/") and not api_base:
        return f"http://localhost:{port}"
    return api_base


def _extract_secrets(data: dict) -> tuple[dict, dict]:
    """Split a config dict into non-secret config and secrets."""
    config_data = {}
    secrets_data = {}
    for section_key, section_val in data.items():
        if isinstance(section_val, dict):
            config_section = {}
            secrets_section = {}
            for k, v in section_val.items():
                if k in _SECRET_FIELDS:
                    secrets_section[k] = v
                else:
                    config_section[k] = v
            config_data[section_key] = config_section
            if secrets_section:
                secrets_data[section_key] = secrets_section
        else:
            config_data[section_key] = section_val
    return config_data, secrets_data


def _merge_secrets(config_data: dict, secrets_data: dict) -> dict:
    """Merge secrets back into config data for Pydantic loading."""
    merged = dict(config_data)
    for section_key, secret_vals in secrets_data.items():
        if section_key in merged and isinstance(merged[section_key], dict):
            merged[section_key].update(secret_vals)
        else:
            merged[section_key] = secret_vals
    return merged


# ---------------------------------------------------------------------------
# Loader / Saver
# ---------------------------------------------------------------------------

def _inject_env_keys(cfg: BhaiConfig) -> BhaiConfig:
    """Override empty API keys with environment variables if available."""
    env_map = {
        "SARVAM_API_KEY": lambda c: setattr(c.sarvam, "api_key", os.getenv("SARVAM_API_KEY", c.sarvam.api_key)),
        "VIBE_API_KEY": lambda c: setattr(c.vibe, "api_key", os.getenv("VIBE_API_KEY", c.vibe.api_key)),
        "CODER_API_KEY": lambda c: setattr(c.coder, "api_key", os.getenv("CODER_API_KEY", c.coder.api_key)),
        # litellm also respects provider-specific env vars like GROQ_API_KEY,
        # ANTHROPIC_API_KEY, OPENAI_API_KEY, etc. natively.
    }
    for env_var, setter in env_map.items():
        if os.getenv(env_var):
            setter(cfg)
    return cfg


def load_config(
    vibe_model_override: Optional[str] = None,
    coder_model_override: Optional[str] = None,
) -> BhaiConfig:
    """
    Load configuration with priority:
      1. CLI flag overrides (highest)
      2. Environment variables / .env
      3. config.yaml + secrets.yaml
      4. Pydantic defaults (lowest)
    """
    # Load .env if present
    if ENV_FILE.exists():
        load_dotenv(ENV_FILE)

    # Load YAML config + secrets
    config_data = {}
    secrets_data = {}

    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            config_data = yaml.safe_load(f) or {}

    if SECRETS_FILE.exists():
        with open(SECRETS_FILE, "r") as f:
            secrets_data = yaml.safe_load(f) or {}

    merged = _merge_secrets(config_data, secrets_data)
    cfg = BhaiConfig(**merged) if merged else BhaiConfig()

    # Inject env overrides
    cfg = _inject_env_keys(cfg)

    # CLI flag overrides (highest priority)
    if vibe_model_override:
        cfg.vibe.model = vibe_model_override
    if coder_model_override:
        cfg.coder.model = coder_model_override

    # Auto-resolve Ollama api_base from port
    cfg.vibe.api_base = _resolve_ollama_base(cfg.vibe.model, cfg.vibe.api_base, cfg.vibe.ollama_port)
    cfg.coder.api_base = _resolve_ollama_base(cfg.coder.model, cfg.coder.api_base, cfg.coder.ollama_port)

    return cfg


def save_config(cfg: BhaiConfig) -> Path:
    """Persist configuration to ~/.config/bhai/ (config.yaml + secrets.yaml)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    full_data = cfg.model_dump()
    config_data, secrets_data = _extract_secrets(full_data)

    # Write non-secret config (world-readable is fine)
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

    # Write secrets with restrictive permissions (0600)
    with open(SECRETS_FILE, "w") as f:
        yaml.dump(secrets_data, f, default_flow_style=False, sort_keys=False)
    os.chmod(SECRETS_FILE, stat.S_IRUSR | stat.S_IWUSR)  # 0600

    return CONFIG_FILE
