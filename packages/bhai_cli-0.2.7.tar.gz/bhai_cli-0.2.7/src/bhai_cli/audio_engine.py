"""
Audio Engine for BHAI-CLI.

Handles:
  - Live microphone recording via sounddevice (primary)
  - File-based audio fallback (configurable)
  - STT via Sarvam Saaras v3 (translate mode for code-mixed Punjabi/Hindi → English)
  - TTS via Sarvam Bulbul v3 (English → Indian-accented speech)

Edge Case: If Sarvam fails, gracefully returns error flags so the orchestrator
can downgrade to text-only mode without crashing.
"""

from __future__ import annotations

import asyncio
import base64
import io
import tempfile
import wave
from pathlib import Path
from typing import Optional

import httpx
from rich.console import Console

console = Console()

# ---------------------------------------------------------------------------
# Sarvam API Constants
# ---------------------------------------------------------------------------
SARVAM_BASE = "https://api.sarvam.ai"
STT_ENDPOINT = f"{SARVAM_BASE}/speech-to-text"
TTS_ENDPOINT = f"{SARVAM_BASE}/text-to-speech"

SAMPLE_RATE = 16000  # Optimal for Saaras v3
CHANNELS = 1
DTYPE = "int16"


# ---------------------------------------------------------------------------
# Audio Recording
# ---------------------------------------------------------------------------

class AudioRecorder:
    """Thread-safe live microphone recorder using sounddevice."""

    def __init__(self, sample_rate: int = SAMPLE_RATE, channels: int = CHANNELS):
        self.sample_rate = sample_rate
        self.channels = channels
        self._frames: list = []
        self._recording = False
        self._stream = None

    def _check_sounddevice(self):
        """Check if sounddevice is available (optional dependency)."""
        try:
            import sounddevice  # noqa: F401
            return True
        except ImportError:
            console.print(
                "[bold red]⚠ Audio support not installed.[/] "
                "Run: [cyan]pip install bhai-cli\\[audio][/]"
            )
            return False

    def start(self) -> bool:
        """Start recording from microphone. Returns False if unavailable."""
        if not self._check_sounddevice():
            return False

        import sounddevice as sd
        import numpy as np

        self._frames = []
        self._recording = True

        def callback(indata, frames, time_info, status):
            if self._recording:
                self._frames.append(indata.copy())

        try:
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                dtype=DTYPE,
                callback=callback,
            )
            self._stream.start()
            return True
        except Exception as e:
            console.print(f"[bold red]⚠ Microphone error:[/] {e}")
            self._recording = False
            return False

    def stop(self) -> Optional[bytes]:
        """Stop recording and return WAV bytes, or None on failure."""
        self._recording = False
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None

        if not self._frames:
            return None

        import numpy as np

        audio_data = np.concatenate(self._frames, axis=0)

        # Convert to WAV bytes
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(2)  # 16-bit = 2 bytes
            wf.setframerate(self.sample_rate)
            wf.writeframes(audio_data.tobytes())

        return buf.getvalue()


def load_audio_file(filepath: str) -> Optional[bytes]:
    """Load audio from a file path as bytes. Returns None on failure."""
    path = Path(filepath)
    if not path.exists():
        console.print(f"[bold red]⚠ Audio file not found:[/] {filepath}")
        return None
    try:
        return path.read_bytes()
    except Exception as e:
        console.print(f"[bold red]⚠ Failed to read audio file:[/] {e}")
        return None


# ---------------------------------------------------------------------------
# Sarvam STT (Saaras v3)
# ---------------------------------------------------------------------------

async def speech_to_text(
    audio_bytes: bytes,
    api_key: str,
    model: str = "saaras:v3",
    mode: str = "translate",
) -> tuple[bool, str]:
    """
    Transcribe/translate audio using Sarvam Saaras v3.

    Args:
        audio_bytes: WAV audio data.
        api_key: Sarvam API subscription key.
        model: STT model identifier.
        mode: transcribe | translate | verbatim | translit | codemix

    Returns:
        (success: bool, text_or_error: str)
    """
    if not api_key:
        return False, "[STT_ERROR] No Sarvam API key configured. Run: bhai-code setup"

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                STT_ENDPOINT,
                headers={"api-subscription-key": api_key},
                files={"file": ("audio.wav", audio_bytes, "audio/wav")},
                data={"model": model, "mode": mode},
            )

        if response.status_code == 200:
            data = response.json()
            transcript = data.get("transcript", "")
            if transcript:
                return True, transcript
            return False, "[STT_ERROR] Empty transcript returned."
        else:
            return False, f"[STT_ERROR] Sarvam API returned {response.status_code}: {response.text}"

    except httpx.TimeoutException:
        return False, "[STT_ERROR] Sarvam STT request timed out."
    except Exception as e:
        return False, f"[STT_ERROR] {type(e).__name__}: {e}"


# ---------------------------------------------------------------------------
# Sarvam TTS (Bulbul v3)
# ---------------------------------------------------------------------------

async def text_to_speech(
    text: str,
    api_key: str,
    model: str = "bulbul:v3",
    speaker: str = "shubh",
    language: str = "en-IN",
) -> tuple[bool, Optional[bytes]]:
    """
    Convert text to speech using Sarvam Bulbul v3.

    Args:
        text: Text to speak (max 2500 chars).
        api_key: Sarvam API subscription key.
        model: TTS model identifier.
        speaker: Voice speaker name.
        language: Target language code.

    Returns:
        (success: bool, audio_bytes_or_none)
    """
    if not api_key:
        return False, None

    # Truncate to API limit
    text = text[:2500]

    try:
        payload = {
            "text": text,
            "target_language_code": language,
            "speaker": speaker,
            "model": model,
            "speech_sample_rate": 24000,
            "pace": 1.0,
            "temperature": 0.6,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                TTS_ENDPOINT,
                headers={
                    "api-subscription-key": api_key,
                    "Content-Type": "application/json",
                },
                json=payload,
            )

        if response.status_code == 200:
            data = response.json()
            audios = data.get("audios", [])
            if audios:
                audio_bytes = base64.b64decode(audios[0])
                return True, audio_bytes
            return False, None
        else:
            console.print(
                f"[dim]TTS warning: Sarvam returned {response.status_code}[/]"
            )
            return False, None

    except Exception as e:
        console.print(f"[dim]TTS fallback: {type(e).__name__}: {e}[/]")
        return False, None


async def play_audio(audio_bytes: bytes) -> None:
    """Play audio bytes through the default output device."""
    try:
        import sounddevice as sd
        import soundfile as sf

        buf = io.BytesIO(audio_bytes)
        data, samplerate = sf.read(buf)
        sd.play(data, samplerate)
        sd.wait()
    except ImportError:
        # Save to temp file and play with system player as fallback
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(audio_bytes)
            console.print(f"[dim]Audio saved to: {f.name}[/]")
    except Exception as e:
        console.print(f"[dim]Audio playback failed: {e}[/]")
