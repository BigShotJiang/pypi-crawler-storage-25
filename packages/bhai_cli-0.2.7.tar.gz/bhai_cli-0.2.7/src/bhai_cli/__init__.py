"""
BHAI-CLI: The Dual-Brain AI Coding Agent with Punjabi Swagger.

Lean heritage. Zero-state resilience. Universal LLM support via litellm.
Indic-native voice interface via Sarvam AI (Saaras v3 STT / Bulbul v3 TTS).
"""

__version__ = "0.1.0"
__app_name__ = "bhai-cli"
