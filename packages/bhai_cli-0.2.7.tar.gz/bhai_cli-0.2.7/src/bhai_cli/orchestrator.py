"""
Orchestrator — The Dual-Brain Agentic Engine for BHAI-CLI.

Brain A (VibeLLM): Persona + intent parsing + planning + final review.
Brain B (CoderAgent): Tool-use execution via litellm.

Agentic Loop (Manager-Worker):
  1. VibeLLM parses intent → creates a plan
  2. CoderAgent executes the plan using tools autonomously
  3. VibeLLM reviews results → decides: done, or iterate with more instructions
  4. Loop until VibeLLM says DONE or max iterations reached
"""

from __future__ import annotations

import asyncio
import json
import re as _re
import time
from typing import Optional

import litellm
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from bhai_cli.config_manager import BhaiConfig
from bhai_cli.tools import TOOL_SCHEMAS, dispatch_tool
from bhai_cli.session_manager import load_session, save_session, create_session_id

console = Console()

# ---------------------------------------------------------------------------
# Rate-Limit Retry Config
# ---------------------------------------------------------------------------
MAX_RATE_LIMIT_RETRIES = 3
RATE_LIMIT_COOLDOWN_SECS = 60

# Global timestamp: ALL API calls (VibeLLM, CoderAgent, title gen) must
# respect this.  When ANY call is rate-limited, we set this so the NEXT
# call in the pipeline sleeps first instead of immediately burning tokens.
_global_rate_limit_until: float = 0.0


def _is_rate_limit_error(exc: Exception) -> bool:
    """Detect rate-limit errors across all LLM providers."""
    error_str = str(exc).lower()
    if "429" in error_str:
        return True
    rate_limit_phrases = [
        "rate limit",
        "rate_limit",
        "ratelimit",
        "too many requests",
        "quota exceeded",
        "tokens per minute",
        "requests per minute",
        "resource_exhausted",
    ]
    return any(phrase in error_str for phrase in rate_limit_phrases)


def _parse_retry_after(exc: Exception) -> int:
    """Try to extract Retry-After seconds from provider error message."""
    error_str = str(exc)
    # Groq format: "try again in 42.123s"
    m = _re.search(r'try again in (\d+\.?\d*)s', error_str, _re.IGNORECASE)
    if m:
        return int(float(m.group(1))) + 1  # +1s buffer
    # Generic Retry-After header value
    m = _re.search(r'retry[- ]?after[:\s]+(\d+)', error_str, _re.IGNORECASE)
    if m:
        return int(m.group(1))
    return RATE_LIMIT_COOLDOWN_SECS


async def _enforce_global_cooldown() -> None:
    """Sleep if a recent rate limit set the global cooldown timestamp."""
    global _global_rate_limit_until
    now = time.monotonic()
    if now < _global_rate_limit_until:
        wait = _global_rate_limit_until - now
        console.print(
            f"[dim]⏳ Global cooldown: waiting {wait:.0f}s before next API call...[/]"
        )
        await asyncio.sleep(wait)


def _set_global_cooldown(seconds: int) -> None:
    """Mark a global cooldown so ALL subsequent API calls wait."""
    global _global_rate_limit_until
    _global_rate_limit_until = time.monotonic() + seconds


def _tasks_are_similar(task_a: str, task_b: str, threshold: float = 0.45) -> bool:
    """Fuzzy check: are two task strings semantically the same?

    VibeLLM rewrites the same task each round to evade exact-match
    detection.  We compare the *significant* word sets and if >45%
    overlap, it's the same task being re-delegated.
    """
    _stop = {
        "a", "an", "the", "and", "or", "to", "in", "of", "for", "with",
        "is", "it", "on", "that", "this", "be", "do", "not", "just",
        "all", "from", "based", "using", "create", "implement", "write",
        "complete", "include", "ensure", "provide", "actual", "working",
        "new", "directly", "another", "them", "should",
    }

    def _tokenize(text: str) -> set[str]:
        # Split on whitespace, then also split on "/" for compound tokens
        raw = text.lower().split()
        tokens = set()
        for w in raw:
            w = w.strip(".,;:\"'()[]")
            for part in w.split("/"):
                part = part.strip(".,;:\"'()[]")
                if part and part not in _stop:
                    tokens.add(part)
        return tokens

    words_a = _tokenize(task_a)
    words_b = _tokenize(task_b)
    if not words_a or not words_b:
        return False
    overlap = len(words_a & words_b)
    smaller = min(len(words_a), len(words_b))
    return (overlap / smaller) >= threshold if smaller else False

# ---------------------------------------------------------------------------
# System Prompts
# ---------------------------------------------------------------------------

VIBE_SYSTEM_PROMPT = (
    "You are BHAI, a 10x Senior SDE from India. You understand all 22 official Indian "
    "languages. You have swagger and a religious devotion to performance. You roast O(N²) "
    "loops and unoptimized Dockerfiles. You speak with authority in Hindi/Hinglish, "
    "with occasional Punjabi and regional Indian flavor.\n\n"
    "Your job:\n"
    "1. Parse the user's intent (any Indian language, Hinglish, or English) into a clear "
    "English task description.\n"
    "2. IMPORTANT: You control a CoderAgent that has tools to read/edit files, list directories, run bash commands, and perform web searches! "
    "If the user asks to explain a file, run code, get real-time info from the internet, or do ANY system task, DO NOT ask them to do it themselves or upload it. "
    "Instead, output a JSON block to delegate it: {\"task\": \"Read HelloWorld.py and explain it\"} or {\"task\": \"Search the web for IPL 2026 points table\"}.\n"
    "3. CRITICAL — PRESERVE FULL SCOPE: When the user asks for multiple deliverables "
    "(e.g. 3 files, multiple features), you MUST include ALL of them in a SINGLE "
    "task delegation. Do NOT strip, split, or reduce scope. Example: if user asks for "
    "'monitor.py, run.sh, and README.md', your task MUST mention ALL three files.\n"
    "4. If strictly chatting with no system/code/search actions needed, respond conversationally with swagger.\n"
    "5. After CoderAgent results, review them and decide:\n"
    '   - If the task is COMPLETE, say "BHAI_DONE" somewhere in your response.\n'
    '   - If MORE WORK is needed, output another {"task": "next step description"} '
    'that covers ONLY the remaining unfinished items.\n\n'
    "Rules: NEVER execute anything yourself. Be concise. Use Hindi/Hinglish naturally, "
    "with occasional regional phrases. You are proudly Indian — sab bhasha samajhte ho."
)

CODER_SYSTEM_PROMPT = (
    "You are the CoderAgent, an autonomous agentic coding engine.\n"
    "You receive task descriptions and execute them using tools.\n\n"
    "## Execution Strategy:\n"
    "- For simple tasks (1-3 files, clear requirements): SKIP planning. "
    "Just use write_file/edit_file/execute_bash directly. Be efficient.\n"
    "- For complex multi-phase tasks (5+ steps, architecture changes): "
    "Use create_plan first to write a roadmap to .bhai/plan.md, then "
    "use update_plan_step to track progress.\n\n"
    "## IMPORTANT — Efficiency Rules:\n"
    "- Do NOT waste tool calls on planning when you can just write files directly.\n"
    "- Write ALL requested files in sequence without stopping between them.\n"
    "- If the user asks for 3 files, create all 3 in consecutive tool calls.\n\n"
    "## Core Principles:\n"
    "1. THINK before acting. Plan your approach.\n"
    "2. ALWAYS read files before editing them — never guess at content.\n"
    "3. Use tools autonomously — chain them as needed.\n"
    "4. Use list_directory and codebase_context to understand structure first.\n"
    "5. Use read_file to see exact file contents before edit_file.\n"
    "6. Use execute_bash for running tests, git, docker, and system commands.\n"
    "7. Verify your changes work by running relevant commands.\n"
    "8. Report results factually — what you did, what worked, what failed.\n"
    "9. IMPORTANT: When you are done with a task or providing an explanation, "
    "simply output plain text. DO NOT format your explanation as a JSON tool "
    "call if no tools are needed.\n\n"
    "## Tools Available:\n"
    "- create_plan / read_plan / update_plan_step: Planning ledger (use only for complex tasks)\n"
    "- list_directory: Explore project structure\n"
    "- codebase_context: Get function/class signatures (AST-based)\n"
    "- read_file: Read file contents (ALWAYS do this before editing)\n"
    "- write_file: Create new files\n"
    "- edit_file: Search-and-replace in existing files\n"
    "- execute_bash: Run shell commands (user confirms each one)\n"
    "- web_search: Search the internet for docs/solutions\n\n"
    "Rules:\n"
    "- NEVER fabricate file contents or command outputs.\n"
    "- Be precise with edit_file — the old_text must match EXACTLY.\n"
    "- For bash: use proper flags, be specific.\n"
    "- Chain tool calls to complete complex tasks end-to-end."
)


class BhaiOrchestrator:
    """Dual-brain agentic orchestrator for BHAI-CLI."""

    def __init__(self, config: BhaiConfig, session_id: Optional[str] = None):
        self.config = config
        self.session_id = session_id or create_session_id()
        self.session_title, self.conversation_history = load_session(self.session_id)
        self._setup_litellm()

    async def _generate_session_title(self, prompt: str) -> None:
        """Generate a short title using VibeLLM.

        Skips the API call entirely if we recently hit a rate limit —
        a title is not worth burning tokens on a 12K TPM budget.
        """
        if self.session_title:
            return

        # Don't waste tokens on title if we're rate-limited
        if time.monotonic() < _global_rate_limit_until:
            self.session_title = prompt[:30] + "..."
            return

        messages = [
            {"role": "system", "content": "Generate a very short title (max 5 words) for this chat based on the user's first prompt. Respond ONLY with the title string."},
            {"role": "user", "content": prompt}
        ]
        try:
            kwargs = {
                "model": self.config.vibe.model,
                "messages": messages,
                "temperature": 0.5,
                "max_tokens": 20,
            }
            if self.config.vibe.api_base:
                kwargs["api_base"] = self.config.vibe.api_base
            if self.config.vibe.api_key:
                kwargs["api_key"] = self.config.vibe.api_key
            response = await litellm.acompletion(**kwargs)
            title = response.choices[0].message.content.strip().strip('"\'')
            if title:
                self.session_title = title
        except Exception:
            self.session_title = prompt[:30] + "..."

    def _setup_litellm(self) -> None:
        import os
        if self.config.vibe.api_key:
            self._set_provider_key(self.config.vibe.model, self.config.vibe.api_key)
        if self.config.coder.api_key:
            self._set_provider_key(self.config.coder.model, self.config.coder.api_key)
        if self.config.sarvam.api_key:
            os.environ.setdefault("SARVAM_API_KEY", self.config.sarvam.api_key)
        litellm.suppress_debug_info = True

    @staticmethod
    def _set_provider_key(model: str, api_key: str) -> None:
        import os
        prefix = model.split("/")[0].upper() if "/" in model else ""
        env_map = {
            "GROQ": "GROQ_API_KEY",
            "ANTHROPIC": "ANTHROPIC_API_KEY",
            "OPENAI": "OPENAI_API_KEY",
            "SARVAM": "SARVAM_API_KEY",
            "GEMINI": "GEMINI_API_KEY",
            "MISTRAL": "MISTRAL_API_KEY",
            "CEREBRAS": "CEREBRAS_API_KEY",
            "DEEPSEEK": "DEEPSEEK_API_KEY",
            "XAI": "XAI_API_KEY",
            "QWEN": "DASHSCOPE_API_KEY",
            "AI_STUDIO": "AISTUDIO_API_KEY",
            "OLLAMA": "",
            "OLLAMA_CHAT": "",
        }
        env_var = env_map.get(prefix, "")
        if env_var:
            os.environ.setdefault(env_var, api_key)

    # ── VibeLLM (Brain A) ──

    async def vibe_parse(self, user_input: str) -> tuple[Optional[str], str]:
        """VibeLLM: extract intent or conversational response."""
        messages = [
            {"role": "system", "content": VIBE_SYSTEM_PROMPT},
            *self.conversation_history,
            {"role": "user", "content": user_input},
        ]
        kwargs = {
            "model": self.config.vibe.model,
            "messages": messages,
            "temperature": self.config.vibe.temperature,
            "max_tokens": self.config.vibe.max_tokens,
        }
        if self.config.vibe.api_base:
            kwargs["api_base"] = self.config.vibe.api_base
        if self.config.vibe.api_key:
            kwargs["api_key"] = self.config.vibe.api_key

        # ── Rate-limit resilient call ──
        consecutive_rate_limits = 0
        while True:
            await _enforce_global_cooldown()
            try:
                response = await litellm.acompletion(**kwargs)
                content = response.choices[0].message.content or ""
                self.conversation_history.append({"role": "user", "content": user_input})
                self.conversation_history.append({"role": "assistant", "content": content})
                
                # Auto-compress if history is getting too long (e.g. 30 messages)
                if len(self.conversation_history) > 30:
                    await self.compress_context()
                    
                if not self.session_title:
                    await self._generate_session_title(user_input)
                    
                save_session(self.session_id, self.session_title, self.conversation_history)
                
                task = self._extract_task(content)
                return task, content
            except Exception as e:
                if _is_rate_limit_error(e):
                    consecutive_rate_limits += 1
                    cooldown = _parse_retry_after(e)
                    _set_global_cooldown(cooldown)
                    if consecutive_rate_limits >= MAX_RATE_LIMIT_RETRIES:
                        console.print(Panel(
                            f"[bold red]Rate limit hit {MAX_RATE_LIMIT_RETRIES} times consecutively.[/]\n"
                            f"[dim]Maaf kardo yaar 🙏 — API quota khatam ho gaya. "
                            f"Thoda wait karo ya apna API key upgrade karo.[/]",
                            title="[bold red]⛔ Rate Limit Exhausted[/]",
                            border_style="red", padding=(1, 2),
                        ))
                        return None, "Rate limit reached after multiple retries. Please wait or upgrade your API key."
                    console.print(
                        f"[bold yellow]⏳ Rate limited (attempt {consecutive_rate_limits}/{MAX_RATE_LIMIT_RETRIES}). "
                        f"Waiting {cooldown}s before retry...[/]"
                    )
                    await asyncio.sleep(cooldown)
                    continue

                error_msg = f"VibeLLM error ({type(e).__name__}): {e}"
                console.print(f"[bold red]⚠ {error_msg}[/]")
                return None, error_msg

    @staticmethod
    def _extract_task(vibe_response: str) -> Optional[str]:
        """Extract {"task": "..."} from VibeLLM's response."""
        try:
            start = vibe_response.find('{"task"')
            if start == -1:
                start = vibe_response.find("```json")
                if start != -1:
                    start = vibe_response.find("{", start)
                    end = vibe_response.find("```", start)
                    if end != -1:
                        return json.loads(vibe_response[start:end].strip()).get("task")
                return None
            depth = 0
            for i in range(start, len(vibe_response)):
                if vibe_response[i] == "{":
                    depth += 1
                elif vibe_response[i] == "}":
                    depth -= 1
                    if depth == 0:
                        return json.loads(vibe_response[start:i+1]).get("task")
            return None
        except (json.JSONDecodeError, KeyError, IndexError):
            return None

    # ── CoderAgent (Brain B) ──

    async def coder_execute(self, task: str) -> str:
        """CoderAgent: execute task using autonomous tool-calling loop."""
        messages = [
            {"role": "system", "content": CODER_SYSTEM_PROMPT},
            {"role": "user", "content": task},
        ]
        max_iterations = 25
        all_results: list[str] = []
        coder_rate_limit_retries = 0

        for iteration in range(max_iterations):
            await _enforce_global_cooldown()

            kwargs = {
                "model": self.config.coder.model,
                "messages": messages,
                "tools": TOOL_SCHEMAS,
                "temperature": self.config.coder.temperature,
                "max_tokens": self.config.coder.max_tokens,
            }
            if self.config.coder.api_base:
                kwargs["api_base"] = self.config.coder.api_base
            if self.config.coder.api_key:
                kwargs["api_key"] = self.config.coder.api_key

            try:
                response = await litellm.acompletion(**kwargs)
                coder_rate_limit_retries = 0  # Reset on success
                message = response.choices[0].message

                if not message.tool_calls:
                    final = message.content or ""
                    return final if final else "\n\n".join(all_results)

                messages.append(message.model_dump())

                for tool_call in message.tool_calls:
                    func_name = tool_call.function.name
                    try:
                        func_args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        func_args = {}

                    # Show tool call with iteration counter
                    console.print(
                        f"[dim][{iteration+1}/{max_iterations}][/] "
                        f"[bold magenta]🔧 {func_name}[/]("
                        f"{', '.join(f'{k}={repr(v)[:60]}' for k, v in func_args.items())})"
                    )

                    if func_name == "execute_bash":
                        func_args.setdefault("timeout", self.config.command_timeout)

                    result = await dispatch_tool(func_name, func_args)
                    all_results.append(f"[{func_name}] {result[:500]}")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": result,
                    })

            except Exception as e:
                # ── Rate-limit retry for CoderAgent ──
                if _is_rate_limit_error(e):
                    coder_rate_limit_retries += 1
                    cooldown = _parse_retry_after(e)
                    _set_global_cooldown(cooldown)
                    if coder_rate_limit_retries >= MAX_RATE_LIMIT_RETRIES:
                        # Return PARTIAL work instead of a bare error.
                        # This prevents VibeLLM from re-delegating the same task.
                        partial = "\n".join(all_results) if all_results else "No tools were executed."
                        console.print(Panel(
                            f"[bold red]Rate limit hit {MAX_RATE_LIMIT_RETRIES} times consecutively.[/]\n"
                            f"[dim]Maaf kardo yaar 🙏 — API quota khatam ho gaya. "
                            f"Thoda wait karo ya apna API key upgrade karo.[/]",
                            title="[bold red]⛔ Rate Limit Exhausted[/]",
                            border_style="red", padding=(1, 2),
                        ))
                        return (
                            f"[RATE LIMITED] Could not finish — API quota exhausted after "
                            f"{MAX_RATE_LIMIT_RETRIES} retries.\n"
                            f"Partial work completed:\n{partial}"
                        )
                    console.print(
                        f"[bold yellow]⏳ Rate limited (attempt {coder_rate_limit_retries}/{MAX_RATE_LIMIT_RETRIES}). "
                        f"Waiting {cooldown}s before retry...[/]"
                    )
                    await asyncio.sleep(cooldown)
                    continue  # Retry the same iteration

                error_str = str(e)
                if "failed_generation" in error_str:
                    try:
                        json_start = error_str.find("{")
                        if json_start != -1:
                            error_json = json.loads(error_str[json_start:])
                            failed_gen = error_json.get("error", {}).get("failed_generation", "")
                            if failed_gen:
                                return failed_gen
                    except Exception:
                        pass

                error = f"CoderAgent error ({type(e).__name__}): {e}"
                console.print(f"[bold red]⚠ {error}[/]")
                return error

        return "Max iterations reached.\n" + "\n".join(all_results)

    async def compress_context(self, manual: bool = False) -> None:
        """Summarize older messages to free up context window."""
        if len(self.conversation_history) <= 4 and not manual:
            return

        # Keep the latest 10 messages, compress the rest. If manual, compress all but the last 2.
        keep_count = 2 if manual else 10
        if len(self.conversation_history) <= keep_count:
            if manual:
                console.print("[dim]Not enough history to compress.[/]")
            return

        messages_to_compress = self.conversation_history[:-keep_count]
        retained_messages = self.conversation_history[-keep_count:]

        history_text = ""
        for msg in messages_to_compress:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            history_text += f"{role.upper()}: {content}\n\n"

        prompt = (
            "Summarize the following conversation history densely. "
            "Retain all key technical facts, decisions, and context. "
            "Ignore conversational filler. Be concise.\n\n"
            f"{history_text}"
        )

        with console.status("[bold cyan]BHAI is compressing memory... 🗜️[/]"):
            try:
                kwargs = {
                    "model": self.config.vibe.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 500,
                }
                if self.config.vibe.api_base:
                    kwargs["api_base"] = self.config.vibe.api_base
                if self.config.vibe.api_key:
                    kwargs["api_key"] = self.config.vibe.api_key

                response = await litellm.acompletion(**kwargs)
                summary = (response.choices[0].message.content or "Conversation compressed.").strip()

                self.conversation_history = [
                    {"role": "system", "content": f"Previous Conversation Summary:\n{summary}"}
                ] + retained_messages

                save_session(self.session_id, self.session_title, self.conversation_history)

                if manual:
                    console.print(Panel(
                        f"[bold green]✅ Context compressed successfully.[/]\n\n[dim]Summary:\n{summary}[/]",
                        title="[bold cyan]Memory Compression[/]", border_style="cyan", padding=(1, 2)
                    ))
            except Exception as e:
                console.print(f"[bold red]⚠ Compression failed:[/] {e}")

    # ── Agentic Pipeline ──

    async def process(self, user_input: str) -> str:
        """
        Full agentic dual-brain pipeline.

        Manager-Worker loop:
          1. VibeLLM parses intent → creates task
          2. CoderAgent executes task
          3. VibeLLM reviews results → either DONE or creates next task
          4. Loop until BHAI_DONE or max agentic rounds
        """
        console.print(Panel(
            f"[bold white]{user_input}[/]",
            title="[bold green]📥 Input[/]", border_style="green", padding=(0, 2),
        ))

        # ── Step 1: VibeLLM initial parse ──
        with console.status("[bold cyan]BHAI is thinking... 🧠[/]"):
            task, vibe_response = await self.vibe_parse(user_input)

        # If VibeLLM says it's just a conversation (no task)
        if task is None:
            console.print()
            console.print(Panel(
                Markdown(vibe_response),
                title="[bold yellow]🎤 BHAI says[/]", border_style="yellow", padding=(1, 2),
            ))
            return vibe_response

        # ── Agentic loop: VibeLLM plans → CoderAgent executes → repeat ──
        max_agentic_rounds = 5
        final_response = vibe_response
        previous_task = None  # Death-spiral detection

        for round_num in range(max_agentic_rounds):
            # ── Death-spiral breaker ──
            # If VibeLLM re-delegates a similar task (fuzzy match), it means
            # the CoderAgent failed and VibeLLM is stuck in a loop.
            if previous_task and task and _tasks_are_similar(task, previous_task):
                console.print(Panel(
                    f"[bold yellow]Similar task re-delegated — breaking loop to save API quota.[/]\n"
                    f"[dim]Previous: {previous_task[:80]}[/]\n"
                    f"[dim]Current:  {task[:80]}[/]",
                    title="[bold yellow]🔄 Loop Detected[/]",
                    border_style="yellow", padding=(1, 2),
                ))
                break
            previous_task = task

            # ── Also break early if rate limited globally ──
            if "[RATE LIMITED]" in final_response:
                console.print(
                    "[dim]Skipping further rounds — rate limit was hit.[/]"
                )
                break

            console.print(f"\n[bold cyan]📋 Task [{round_num+1}]:[/] {task}\n")

            # CoderAgent executes
            coder_result = await self.coder_execute(task)

            # If CoderAgent was rate-limited, don't waste tokens on a
            # VibeLLM review that will just re-delegate the same task.
            if "[RATE LIMITED]" in coder_result:
                final_response = coder_result
                console.print(Panel(
                    Markdown(
                        "Rate limit laga diya API ne 🙏\n\n"
                        "Thoda wait karo, phir dubara try karo. "
                        "Ya phir apna API key upgrade karo for higher limits."
                    ),
                    title="[bold yellow]🎤 BHAI says[/]",
                    border_style="yellow", padding=(1, 2),
                ))
                break

            # VibeLLM reviews results
            review_prompt = (
                f"CoderAgent completed round {round_num+1}.\n"
                f"Task was: {task}\n\n"
                f"Results:\n{coder_result[:3000]}\n\n"
                "Review the results. Check what files/actions were actually completed vs. what was originally requested.\n"
                'If ALL the user\'s original deliverables are done, say "BHAI_DONE" in your response.\n'
                'If some deliverables are STILL MISSING, output {"task": "..."} with ONLY '
                'the specific remaining items (e.g. "Create run.sh and README.md"). '
                'Do NOT re-delegate work that was already completed.\n'
                "Summarize what was done so far with your BHAI swagger."
            )

            with console.status(f"[bold cyan]BHAI reviewing round {round_num+1}... 🎯[/]"):
                next_task, final_response = await self.vibe_parse(review_prompt)

            # Check if VibeLLM says we're done
            if "BHAI_DONE" in final_response or next_task is None:
                break

            # VibeLLM wants more work
            task = next_task
            console.print(Panel(
                Markdown(final_response),
                title=f"[bold yellow]🎤 BHAI — Round {round_num+1}[/]",
                border_style="yellow", padding=(1, 2),
            ))

        # ── Final summary ──
        console.print()
        # Clean BHAI_DONE from display
        display_response = final_response.replace("BHAI_DONE", "").strip()
        console.print(Panel(
            Markdown(display_response),
            title="[bold yellow]🎤 BHAI says[/]", border_style="yellow", padding=(1, 2),
        ))
        return display_response
