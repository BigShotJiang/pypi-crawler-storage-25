"""
fusiontest/core/goal_verifier.py

Lightweight LLM-based goal completion verifier.

Replaces the always-False stub in FusionTestRunner._is_goal_complete().

The verifier asks the same LLM backend used by ActionModel:
  "Given this screen state and the original goal, has the goal been
   completed? Reply with JSON: { complete: bool, confidence: float,
   reason: string }"

Confidence threshold (default 0.75) controls how certain the model
must be before declaring completion — below that, the runner keeps
stepping rather than risk a false-positive pass.

For the MPNet backend (no chat capability) the verifier falls back to
a keyword-presence heuristic: look for goal-relevant terms in the
current screen text.
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass

logger = logging.getLogger("fusiontest.goal_verifier")


@dataclass
class VerifierResult:
    complete: bool
    confidence: float     # 0–1
    reason: str = ""


class GoalVerifier:
    """
    Determines whether a test goal has been achieved on the current screen.

    Usage:
        verifier = GoalVerifier(backend="gpt4o", confidence_threshold=0.75)
        result = verifier.check(goal="Log in and reach the home screen",
                                screen_text=current_screen_text,
                                history=action_history)
        if result.complete and result.confidence >= 0.75:
            return True
    """

    _SYSTEM_PROMPT = (
        "You are a test verification agent. Decide whether a UI test goal "
        "has been completed based on the screen state.\n\n"
        "IMPORTANT: You MUST respond with ONLY a JSON object. "
        "No explanation, no markdown fences, no text before or after.\n\n"
        "Format: {\"complete\": true, \"confidence\": 0.95, \"reason\": \"one sentence\"}\n\n"
        "- complete: true if the goal is achieved, false otherwise\n"
        "- confidence: 0.0 to 1.0\n"
        "- reason: one sentence explanation"
    )

    def __init__(
        self,
        backend: str = "gpt4o",
        confidence_threshold: float = 0.75,
        temperature: float = 0.1,
    ):
        self.backend = backend
        self.confidence_threshold = confidence_threshold
        self.temperature = temperature
        self._client = None
        self._llm_model: str = ""

        if backend in ("gpt4o", "claude"):
            self._init_client(backend)

    # ── Public API ─────────────────────────────────────────────────────────────

    def check(
        self,
        goal: str,
        screen_text: str,
        history: list[str] | None = None,
    ) -> VerifierResult:
        """
        Returns a VerifierResult indicating whether the goal appears complete.
        Never raises — on any error returns complete=False with confidence=0.
        """
        try:
            if self.backend == "mpnet":
                return self._heuristic_check(goal, screen_text)
            return self._llm_check(goal, screen_text, history or [])
        except Exception as e:
            logger.warning(f"GoalVerifier error: {e}")
            return VerifierResult(complete=False, confidence=0.0, reason=f"error: {e}")

    def is_complete(
        self,
        goal: str,
        screen_text: str,
        history: list[str] | None = None,
    ) -> bool:
        """Convenience wrapper — returns True only when confident enough."""
        result = self.check(goal, screen_text, history)
        if result.complete and result.confidence >= self.confidence_threshold:
            logger.info(
                f"Goal complete (conf={result.confidence:.2f}): {result.reason}"
            )
            return True
        return False

    # ── LLM backend ────────────────────────────────────────────────────────────

    def _init_client(self, backend: str) -> None:
        """Validate import availability only — client is created lazily on first call."""
        if backend == "gpt4o":
            try:
                import openai as _openai  # noqa: F401
                self._llm_model = "gpt-4o"
            except ImportError as err:
                raise RuntimeError("GPT-4o verifier requires: pip install openai") from err
        elif backend == "claude":
            try:
                import anthropic as _anthropic  # noqa: F401
                self._llm_model = "claude-sonnet-4-6"
            except ImportError as err:
                raise RuntimeError("Claude verifier requires: pip install anthropic") from err

    def _get_client(self):
        if self._client is not None:
            return self._client
        if self.backend == "gpt4o":
            from openai import OpenAI
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "OPENAI_API_KEY is not set. Add it to your .env file or run: "
                    "export OPENAI_API_KEY=sk-..."
                )
            self._client = OpenAI(api_key=api_key)
        elif self.backend == "claude":
            import anthropic
            api_key = os.getenv("ANTHROPIC_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "ANTHROPIC_API_KEY is not set. Add it to your .env file or run: "
                    "export ANTHROPIC_API_KEY=sk-ant-..."
                )
            self._client = anthropic.Anthropic(api_key=api_key)
        return self._client

    def _llm_check(
        self, goal: str, screen_text: str, history: list[str]
    ) -> VerifierResult:
        prompt = self._build_prompt(goal, screen_text, history)
        raw = self._call_llm(prompt)
        return self._parse_response(raw)

    def _build_prompt(
        self, goal: str, screen_text: str, history: list[str]
    ) -> str:
        parts = [
            f"GOAL: {goal}",
            "",
            screen_text[:3000],   # enough context for content-heavy pages
        ]
        if history:
            parts += ["", "ACTIONS TAKEN:", *[f"  - {a}" for a in history[-5:]]]
        parts += [
            "",
            "Has the goal been achieved based on what is currently visible on screen?",
        ]
        return "\n".join(parts)

    def _call_llm(self, prompt: str) -> str:
        client = self._get_client()
        if self.backend == "gpt4o":
            resp = client.chat.completions.create(
                model=self._llm_model,
                messages=[
                    {"role": "system", "content": self._SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                temperature=self.temperature,
                max_tokens=128,
                response_format={"type": "json_object"},
            )
            return resp.choices[0].message.content or "{}"

        elif self.backend == "claude":
            resp = client.messages.create(
                model=self._llm_model,
                max_tokens=128,
                system=self._SYSTEM_PROMPT,
                messages=[
                    {"role": "user", "content": prompt + '\n\nIMPORTANT: Your entire response must be a single JSON object like {"complete": true, "confidence": 0.9, "reason": "..."}. No other text before or after the JSON.'},
                ],
            )
            return resp.content[0].text if resp.content else "{}"

        return "{}"

    def _parse_response(self, raw: str) -> VerifierResult:
        raw = raw.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = re.sub(r"```[a-z]*\n?", "", raw).strip()

        # Strategy 1: Extract JSON object from anywhere in the response
        json_match = re.search(r'\{[^{}]*"complete"\s*:\s*(true|false)[^{}]*\}', raw, re.IGNORECASE)
        if json_match:
            try:
                data = json.loads(json_match.group(0))
                return VerifierResult(
                    complete=bool(data.get("complete", False)),
                    confidence=float(data.get("confidence", 0.5)),
                    reason=str(data.get("reason", "")),
                )
            except (json.JSONDecodeError, ValueError):
                pass

        # Strategy 2: Try parsing the whole thing as JSON
        try:
            data = json.loads(raw)
            return VerifierResult(
                complete=bool(data.get("complete", False)),
                confidence=float(data.get("confidence", 0.5)),
                reason=str(data.get("reason", "")),
            )
        except (json.JSONDecodeError, ValueError):
            pass

        # Strategy 3: Fuzzy parse from natural language response
        # Claude sometimes returns prose despite being told to return JSON
        raw_lower = raw.lower()
        positive_signals = [
            "goal has been achieved", "goal is achieved", "goal is complete",
            "goal has been completed", "goal appears to be complete",
            "the goal is met", "yes, the goal", "has been satisfied",
            '"complete": true', "'complete': true", "complete: true",
            "the page has loaded", "page loads and displays",
            "can see the", "categories or cards",
        ]
        negative_signals = [
            "goal has not been", "not yet achieved", "not complete",
            "goal is not", "cannot determine", "no evidence",
            '"complete": false', "complete: false",
        ]

        pos_hits = sum(1 for s in positive_signals if s in raw_lower)
        neg_hits = sum(1 for s in negative_signals if s in raw_lower)

        if pos_hits > neg_hits and pos_hits >= 1:
            confidence = min(0.85, 0.6 + pos_hits * 0.1)
            logger.info(f"GoalVerifier: fuzzy-parsed as COMPLETE (pos={pos_hits}, neg={neg_hits})")
            return VerifierResult(
                complete=True,
                confidence=confidence,
                reason=f"fuzzy_parse: {raw[:80]}",
            )

        logger.warning(f"GoalVerifier: could not parse LLM response: {raw[:120]}")
        return VerifierResult(complete=False, confidence=0.0, reason="parse_error")

    # ── MPNet heuristic fallback ───────────────────────────────────────────────

    def _heuristic_check(self, goal: str, screen_text: str) -> VerifierResult:
        """
        Simple keyword match: extract noun phrases from the goal and check
        whether they appear in the current screen text.

        This is intentionally conservative — only marks complete if most
        key terms are visible.  Confidence tops out at 0.70 to ensure the
        caller doesn't over-rely on it.
        """
        keywords = self._extract_keywords(goal)
        if not keywords:
            return VerifierResult(complete=False, confidence=0.0, reason="no_keywords")

        screen_lower = screen_text.lower()
        hits = sum(1 for kw in keywords if kw in screen_lower)
        ratio = hits / len(keywords)

        complete = ratio >= 0.7
        confidence = min(0.70, ratio * 0.70)   # hard cap at 0.70 for heuristic
        reason = f"{hits}/{len(keywords)} keywords found in screen"

        return VerifierResult(complete=complete, confidence=confidence, reason=reason)

    @staticmethod
    def _extract_keywords(goal: str) -> list[str]:
        """Pull out meaningful lowercase tokens from a goal string."""
        stop = {
            "a", "an", "the", "and", "or", "to", "on", "in", "at", "of",
            "is", "are", "was", "were", "be", "been", "being",
            "that", "this", "with", "for", "from", "into", "by",
            "log", "click", "tap", "press", "open", "go", "navigate",
            "verify", "check", "confirm", "see", "view", "ensure",
        }
        tokens = re.findall(r"\b[a-z]{3,}\b", goal.lower())
        return [t for t in tokens if t not in stop]
