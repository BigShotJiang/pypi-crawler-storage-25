"""
fusiontest/core/runner.py

The FusionTest main runner — orchestrates the full test loop:
  1. Parse the screen
  2. Ask the model what to do
  3. Run it through guardrails
  4. Execute
  5. Record and report
  6. Repeat until goal is complete or max_steps reached
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from fusiontest.core.action_model import Action, ActionBackend, ActionModel
from fusiontest.core.goal_verifier import GoalVerifier
from fusiontest.core.screen_parser import UIElement
from fusiontest.guardrails.engine import GuardrailsConfig, GuardrailsEngine

logger = logging.getLogger("fusiontest.runner")


# ── Adapter protocol — mobile and desktop adapters must implement this ─────────

@runtime_checkable
class UIAdapter(Protocol):
    def get_screen(self) -> tuple[list[UIElement], str]: ...
    def get_screenshot(self) -> bytes: ...
    def execute(self, action: Action, elements: list[UIElement]) -> bool: ...


# ── Result types ───────────────────────────────────────────────────────────────

@dataclass
class StepResult:
    goal: str
    success: bool
    steps_taken: int
    actions: list[str] = field(default_factory=list)
    screenshots: list[bytes] = field(default_factory=list)
    error: str = ""
    duration_seconds: float = 0.0


@dataclass
class RunResult:
    name: str
    platform: str
    locale: str
    success: bool
    url: str = ""
    steps: list[StepResult] = field(default_factory=list)
    total_duration_seconds: float = 0.0
    bugs_detected: list[str] = field(default_factory=list)
    video_path: str = ""

    @property
    def stability_score(self) -> float:
        if not self.steps:
            return 0.0
        return sum(1 for s in self.steps if s.success) / len(self.steps)


# ── Runner config ──────────────────────────────────────────────────────────────

@dataclass
class RunnerConfig:
    backend: ActionBackend = "gpt4o"
    model_path: str | None = None
    max_steps_per_goal: int = 25
    screenshot_on_every_step: bool = False
    screenshot_on_failure: bool = True
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    verifier_confidence_threshold: float = 0.75
    # Path to write step-level JSONL logs (used by the training pipeline)
    step_log_path: str | None = None
    # Video recording
    record_video: bool = False
    video_output_dir: str = "fusiontest-reports/videos"


# ── Runner ─────────────────────────────────────────────────────────────────────

class FusionTestRunner:
    """
    Orchestrates a full FusionTest run across multiple goal steps.

    Usage:
        runner = FusionTestRunner(adapter, config)
        result = runner.run(
            name="Onboarding smoke test",
            goals=["Log in", "Navigate to settings", "Update profile name"],
            platform="android",
            locale="en-US",
        )
    """

    def __init__(self, adapter: UIAdapter, config: RunnerConfig | None = None):
        self.adapter = adapter
        self.config = config or RunnerConfig()
        self.model = ActionModel(
            backend=self.config.backend,
            model_path=self.config.model_path,
        )
        self.guardrails = GuardrailsEngine(self.config.guardrails)
        self.verifier = GoalVerifier(
            backend=self.config.backend,
            confidence_threshold=self.config.verifier_confidence_threshold,
        )
        self._step_log = None
        if self.config.step_log_path:
            import pathlib  # noqa: PLC0415
            pathlib.Path(self.config.step_log_path).parent.mkdir(parents=True, exist_ok=True)
            self._step_log = open(self.config.step_log_path, "a")  # noqa: SIM115

        self._recorder = None
        if self.config.record_video:
            from fusiontest.recording.recorder import Recorder, RecordingConfig
            self._recorder = Recorder(
                platform=getattr(adapter, "_platform", "unknown"),
                config=RecordingConfig(output_dir=self.config.video_output_dir),
            )

    def run(
        self,
        goals: list[str],
        name: str = "FusionTest Run",
        platform: str = "unknown",
        locale: str = "en-US",
        url: str = "",
        goal_urls: list[str | None] | None = None,
    ) -> RunResult:
        run_start = time.time()
        result = RunResult(name=name, platform=platform, locale=locale, success=True, url=url)

        if self._recorder:
            try:
                self._recorder.start(getattr(self.adapter, "_driver", self.adapter))
            except Exception as e:
                logger.warning(f"Could not start recorder: {e}")

        logger.info(f"Starting run: {name} ({len(goals)} goals)")

        for i, goal in enumerate(goals, 1):
            goal_url = (goal_urls[i - 1] if goal_urls and i - 1 < len(goal_urls) else None) or url
            logger.info(f"Goal {i}/{len(goals)}: {goal}" + (f" [{goal_url}]" if goal_url else ""))
            step_result = self._run_goal(goal, navigate_url=goal_url)
            result.steps.append(step_result)

            if not step_result.success:
                result.success = False
                logger.warning(f"Goal failed: {goal} — {step_result.error}")

            self.guardrails.reset_step()

        if self._recorder:
            try:
                video_path = self._recorder.stop()
                if video_path:
                    result.video_path = str(video_path)
            except Exception as e:
                logger.warning(f"Could not stop recorder: {e}")

        result.total_duration_seconds = time.time() - run_start
        logger.info(
            f"Run complete: {'PASS' if result.success else 'FAIL'} "
            f"(stability={result.stability_score:.1%}, "
            f"duration={result.total_duration_seconds:.1f}s)"
        )

        return result

    def _run_goal(self, goal: str, navigate_url: str = "") -> StepResult:
        start = time.time()
        step = StepResult(goal=goal, success=False, steps_taken=0)
        history: list[str] = []

        # Navigate to the goal's URL before starting (if provided)
        if navigate_url and hasattr(self.adapter, "navigate"):
            try:
                self.adapter.navigate(navigate_url)
                logger.info(f"  Navigated to: {navigate_url}")
            except Exception as e:
                logger.warning(f"  Navigation failed: {e}")

        for step_num in range(1, self.config.max_steps_per_goal + 1):
            step.steps_taken = step_num

            # Brief pause to let the page render after previous action
            if step_num > 1:
                time.sleep(0.8)

            # 1. Read the screen
            try:
                elements, screen_text = self.adapter.get_screen()
            except Exception as e:
                step.error = f"screen_read_error: {e}"
                break

            # NOTE: We record the screen hash AFTER checking verifier and model,
            # not before. This prevents observation/verification goals from
            # triggering screen loop detection when the page doesn't change.

            # Log interactive element count for diagnostics
            interactive = [e for e in elements if e.is_interactive()]
            if step_num == 1:
                logger.info(f"  Screen: {len(elements)} total, {len(interactive)} interactive elements")
                for el in interactive[:10]:
                    logger.info(f"    {el.to_token()}")

            # Capture screenshot if configured
            if self.config.screenshot_on_every_step:
                try:
                    step.screenshots.append(self.adapter.get_screenshot())
                except Exception:
                    pass

            # 2. Check if goal is already complete
            if self.verifier.is_complete(goal, screen_text, history):
                step.success = True
                logger.info(f"  Goal complete in {step_num} steps")
                self._write_step_log(goal, screen_text, "verify: goal complete", "success")
                break

            # 3. Ask the model for the best action
            actions = self.model.predict(
                screen_text=screen_text,
                goal=goal,
                history=history,
                invalid_actions=self.guardrails.get_invalid_actions(),
            )

            executed = False
            goal_done_by_model = False
            for action in actions:
                # 4a. Handle "done" action — model says goal is already achieved
                if action.action_type == "done":
                    logger.info(f"  Model signals goal complete: {action.reasoning}")
                    action_str = f"done: {action.reasoning}"
                    step.actions.append(action_str)
                    step.success = True
                    goal_done_by_model = True
                    self._write_step_log(goal, screen_text, action_str, "success")
                    break

                # 4b. Run through guardrails
                gr = self.guardrails.check(action, elements, screen_text)

                if gr.should_backtrack:
                    logger.info(f"  Backtracking (step {step_num})")
                    self._backtrack(history)
                    break

                if gr.should_skip:
                    logger.debug(f"  Skipping action: {action} ({gr.reason})")
                    continue

                # 5. Execute the action
                success = self.adapter.execute(gr.action, elements)
                if success:
                    action_str = str(gr.action)
                    history.append(action_str)
                    step.actions.append(action_str)
                    self.guardrails.record_action(gr.action)
                    # Only record screen hash for actions that change the page.
                    # Scroll doesn't change DOM extraction (all elements captured
                    # regardless of viewport), so recording it causes false loops.
                    if gr.action.action_type not in ("scroll", "wait"):
                        self.guardrails.record_screen(screen_text)
                    logger.info(f"  Step {step_num}: {gr.action}")
                    executed = True
                    self._write_step_log(goal, screen_text, action_str, "success")
                    break
                else:
                    self._write_step_log(goal, screen_text, str(action), "failure")

            if goal_done_by_model:
                break

            if not executed:
                logger.warning(f"  No valid action found at step {step_num}")

        else:
            step.error = f"max_steps_exceeded ({self.config.max_steps_per_goal})"

        if not step.success and self.config.screenshot_on_failure:
            try:
                step.screenshots.append(self.adapter.get_screenshot())
            except Exception:
                pass

        step.duration_seconds = time.time() - start
        return step

    def _write_step_log(
        self, goal: str, screen_text: str, action: str, outcome: str
    ) -> None:
        if not self._step_log:
            return
        import json
        self._step_log.write(json.dumps({
            "goal": goal,
            "screen_text": screen_text,
            "action": action,
            "outcome": outcome,
        }) + "\n")
        self._step_log.flush()

    def _backtrack(self, history: list[str]) -> None:
        """Undo the last action (platform-specific — adapter should implement back)."""
        if history:
            history.pop()
        try:
            from fusiontest.core.action_model import Action
            back_action = Action(action_type="back", element_index=None, element_label="")
            self.adapter.execute(back_action, [])
        except Exception as e:
            logger.warning(f"Backtrack failed: {e}")
