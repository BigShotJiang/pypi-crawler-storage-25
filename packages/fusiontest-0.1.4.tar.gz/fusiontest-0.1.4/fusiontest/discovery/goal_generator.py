"""
fusiontest/discovery/goal_generator.py

LLM-powered test goal generator.

Given a URL (and optionally scraped page HTML), generates prioritised
natural-language test goals across three categories:

  * critical_path — signup, login, checkout, core user actions
  * happy_path    — navigation, forms, standard CRUD flows
  * edge_cases    — empty inputs, invalid data, error states

LLM priority order:
  1. Anthropic Claude  (ANTHROPIC_API_KEY)
  2. OpenAI GPT-4o     (OPENAI_API_KEY)
  3. Heuristic fallback (no key needed — generic templates)
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger(__name__)

GoalCategory = Literal["critical_path", "happy_path", "edge_cases"]


@dataclass
class DiscoveredGoal:
    id: str
    name: str                  # short 5-8 word title for the YAML output
    text: str
    category: GoalCategory
    confidence: float          # 0.0 – 1.0
    selected: bool = True      # user can deselect before running
    edited: bool = False       # has the user overridden the text?


@dataclass
class GoalGeneratorConfig:
    openai_model: str = "gpt-4o"
    claude_model: str = ""   # empty = auto-detect from API
    max_goals: int = 20
    temperature: float = 0.3


# ── Page scraper ──────────────────────────────────────────────────────────────

def _scrape_page_text(url: str, timeout: float = 12.0) -> tuple[str, str, str]:
    """
    Fetch page HTML and return (title, nav_links, element_summary).
    Extracts richer signal: meta description, nav items, headings, CTA buttons.
    Never raises.
    """
    try:
        import httpx

        resp = httpx.get(
            url,
            timeout=timeout,
            follow_redirects=True,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (compatible; FusionTest-Discovery/0.1; "
                    "+https://fusiontest.fusionleap.io)"
                ),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            },
        )
        html = resp.text

        # Title
        m = re.search(r"<title[^>]*>([^<]+)</title>", html, re.I)
        title = m.group(1).strip() if m else ""

        # Meta description
        m2 = re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']{1,200})', html, re.I)
        meta_desc = m2.group(1).strip() if m2 else ""

        # H1 headings
        headings = re.findall(r"<h[12][^>]*>([^<]{2,80})</h[12]>", html, re.I)
        headings_clean = [re.sub(r"\s+", " ", h).strip() for h in headings[:6]]

        # Nav links
        nav_block = re.search(r"<nav[^>]*>(.*?)</nav>", html, re.I | re.S)
        nav_links: list[str] = []
        if nav_block:
            nav_links = re.findall(r"<a[^>]*>([^<]{2,40})</a>", nav_block.group(1), re.I)
            nav_links = [re.sub(r"\s+", " ", t).strip() for t in nav_links if t.strip()][:12]

        # Forms
        forms = len(re.findall(r"<form", html, re.I))

        # Input types and placeholders
        inputs = re.findall(
            r'<input[^>]*type=["\']([^"\']+)["\'][^>]*(?:placeholder=["\']([^"\']*)["\'])?',
            html, re.I,
        )
        input_types = list({t for t, _ in inputs if t.lower() not in ("hidden", "submit", "button")})
        placeholders = [p for _, p in inputs if p.strip()][:6]

        # CTA / action buttons
        buttons = re.findall(r"<button[^>]*>([^<]{2,50})</button>", html, re.I)
        buttons_clean = [re.sub(r"\s+", " ", b).strip() for b in buttons[:8]]

        # Build structured summary
        parts: list[str] = []
        if meta_desc:
            parts.append(f"Description: {meta_desc}")
        if headings_clean:
            parts.append(f"Headings: {', '.join(headings_clean)}")
        if nav_links:
            parts.append(f"Navigation: {', '.join(nav_links)}")
        if forms:
            parts.append(f"{forms} form(s)")
        if input_types:
            parts.append(f"Input types: {', '.join(input_types)}")
        if placeholders:
            parts.append(f"Input placeholders: {', '.join(placeholders)}")
        if buttons_clean:
            parts.append(f"Buttons: {', '.join(buttons_clean)}")

        element_summary = " | ".join(parts) if parts else "minimal page content detected"
        return title, " · ".join(nav_links[:5]), element_summary

    except Exception as exc:  # noqa: BLE001
        logger.warning("Page scrape failed for %s: %s", url, exc)
        return "", "", ""


# ── Shared prompt ─────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = """\
You are a senior QA engineer specialising in automated UI testing.
Generate concise, executable natural-language test goals for a specific web application
based on its actual URL, title, navigation structure, and interactive elements.

IMPORTANT: Goals must be SPECIFIC to this application — reference real features,
pages, and flows that exist on the site. Do NOT generate generic goals like
"sign up for an account" unless the site actually has signup functionality.

Rules:
- Write each goal as a complete action sentence a tester would follow,
  e.g. "Navigate to the Pricing page and verify all three plan tiers are displayed".
- Each goal must be self-contained and testable in isolation.
- Do NOT reference CSS selectors, element IDs, or code.
- Vary the goals — cover different parts of the site, not just auth flows.
- Return ONLY valid JSON: a flat array of objects with these exact keys:
    name       (string — short 5-8 word title, e.g. "Homepage hero section loads")
    text       (string — full executable goal sentence)
    category   ("critical_path" | "happy_path" | "edge_cases")
    confidence (number 0.0–1.0 — how certain you are this flow exists on this specific site)
- Do not add any explanation, markdown fences, or extra keys.
"""


def _build_user_message(url: str, title: str, nav: str, elements: str, max_goals: int) -> str:
    return (
        f"URL: {url}\n"
        f"Page title: {title or '(unknown)'}\n"
        f"Navigation: {nav or '(not detected)'}\n"
        f"Page elements: {elements or '(could not fetch page)'}\n\n"
        f"Generate up to {max_goals} test goals specific to this site, "
        f"distributed across critical_path, happy_path, and edge_cases categories."
    )


def _derive_name(text: str) -> str:
    """Fallback: condense a goal sentence into a short 5-8 word title."""
    # Strip leading verb phrases like "Verify that", "Navigate to", "Check that"
    cleaned = re.sub(
        r"^(verify\s+(that\s+)?|navigate\s+to\s+(the\s+)?|check\s+(that\s+)?|"
        r"attempt\s+to\s+|click\s+|submit\s+|open\s+(the\s+)?|ensure\s+(that\s+)?)",
        "",
        text,
        flags=re.I,
    ).strip()
    words = cleaned.split()
    name = " ".join(words[:7])
    if len(words) > 7:
        name += "…"
    return name.capitalize()


def _parse_goals(raw: str, max_goals: int) -> list[DiscoveredGoal]:
    """Parse the LLM JSON response into DiscoveredGoal objects."""
    # Strip markdown fences if the model included them
    raw = re.sub(r"^```[a-z]*\n?", "", raw.strip(), flags=re.M)
    raw = re.sub(r"\n?```$", "", raw.strip(), flags=re.M)

    data = json.loads(raw)
    items = data if isinstance(data, list) else data.get("goals", data.get("items", []))

    goals: list[DiscoveredGoal] = []
    for i, item in enumerate(items[:max_goals]):
        cat = item.get("category", "happy_path")
        if cat not in ("critical_path", "happy_path", "edge_cases"):
            cat = "happy_path"
        conf = float(item.get("confidence", 0.8))
        conf = max(0.0, min(1.0, conf))
        text = item.get("text", "").strip()
        if not text:
            continue
        name = item.get("name", "").strip() or _derive_name(text)
        goals.append(
            DiscoveredGoal(
                id=f"goal-{i:03d}",
                name=name,
                text=text,
                category=cat,  # type: ignore[arg-type]
                confidence=conf,
                selected=conf >= 0.75,
            )
        )
    return goals


# ── Claude (Anthropic) ────────────────────────────────────────────────────────

# Module-level cache so we only call models.list() once per process
_claude_model_cache: str | None = None


def _resolve_claude_model(client: object, preferred: str) -> str | None:
    """
    Return the best available Claude model for this API key.
    Prefers 'sonnet' > 'haiku' > 'opus' in the latest available generation.
    Result is cached for the lifetime of the process.
    """
    global _claude_model_cache  # noqa: PLW0603
    if _claude_model_cache is not None:
        return _claude_model_cache

    # If caller explicitly set a model ID, trust it (skip auto-detect)
    if preferred:
        _claude_model_cache = preferred
        return _claude_model_cache

    try:
        models_page = client.models.list()
        ids = [m.id for m in models_page.data]

        # Rank by preference: sonnet > haiku > opus, newer date wins within tier
        def _rank(model_id: str) -> tuple[int, str]:
            mid = model_id.lower()
            tier = 1 if "sonnet" in mid else (2 if "haiku" in mid else 3)
            return (tier, model_id)  # lexicographic date sort is fine for YYYYMMDD suffixes

        ids.sort(key=_rank)
        _claude_model_cache = ids[0] if ids else None
        logger.info("Auto-selected Claude model: %s (from %d available)", _claude_model_cache, len(ids))
        return _claude_model_cache

    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not list Claude models: %s", exc)
        return None


def _claude_goals(
    url: str, title: str, nav: str, elements: str, cfg: GoalGeneratorConfig,
) -> list[DiscoveredGoal]:
    """Call Claude to generate goals using the best available model. Returns [] on any error."""
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        return []

    try:
        import anthropic  # lazy import

        client = anthropic.Anthropic(api_key=api_key)
        model = _resolve_claude_model(client, cfg.claude_model)
        if not model:
            logger.warning("No Claude models available for this API key")
            return []

        user_msg = _build_user_message(url, title, nav, elements, cfg.max_goals)
        resp = client.messages.create(
            model=model,
            max_tokens=2048,
            temperature=cfg.temperature,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_msg}],
        )
        raw = resp.content[0].text if resp.content else "[]"
        return _parse_goals(raw, cfg.max_goals)

    except Exception as exc:  # noqa: BLE001
        logger.warning("Claude goal generation failed: %s", exc)
        return []


# ── OpenAI ────────────────────────────────────────────────────────────────────

def _openai_goals(
    url: str, title: str, nav: str, elements: str, cfg: GoalGeneratorConfig,
) -> list[DiscoveredGoal]:
    """Call OpenAI to generate goals. Returns [] on any error."""
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        return []

    try:
        from openai import OpenAI  # lazy import

        client = OpenAI(api_key=api_key)
        user_msg = _build_user_message(url, title, nav, elements, cfg.max_goals)

        resp = client.chat.completions.create(
            model=cfg.openai_model,
            temperature=cfg.temperature,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user",   "content": user_msg},
            ],
            response_format={"type": "json_object"},
        )

        raw = resp.choices[0].message.content or "[]"
        return _parse_goals(raw, cfg.max_goals)

    except Exception as exc:  # noqa: BLE001
        logger.warning("OpenAI goal generation failed: %s", exc)
        return []


# ── Heuristic fallback ────────────────────────────────────────────────────────

_HEURISTIC_TEMPLATES: dict[GoalCategory, list[tuple[str, str, float]]] = {
    "critical_path": [
        ("Account signup flow works", "Sign up for a new account using a valid email and password", 0.95),
        ("Login with valid credentials", "Log in with valid credentials and verify the main page loads", 0.95),
        ("Logout clears session", "Log out and confirm the session is cleared", 0.90),
        ("Password reset flow works", "Reset password via the forgot-password flow", 0.85),
        ("Primary conversion flow completes", "Complete the primary conversion flow (e.g. purchase, subscribe, or submit)", 0.80),
    ],
    "happy_path": [
        ("Main navigation links work", "Navigate to each top-level section via the main navigation menu", 0.90),
        ("Contact form submits successfully", "Fill in and submit the main contact or inquiry form successfully", 0.80),
        ("Search returns relevant results", "Search for a term and verify relevant results appear", 0.75),
        ("Profile details can be saved", "Edit account profile details and save changes", 0.75),
        ("Paginated content loads correctly", "Browse paginated content and navigate to the next page", 0.70),
        ("File upload works as expected", "Upload or attach a file where the UI allows it", 0.65),
        ("Filters and sorting update list", "Apply a filter or sort option and verify the list updates", 0.70),
    ],
    "edge_cases": [
        ("Invalid login shows error message", "Attempt to log in with an incorrect password and verify the error message", 0.90),
        ("Duplicate email rejected on signup", "Submit the registration form with an already-used email address", 0.85),
        ("Empty form shows validation errors", "Submit a required form with all fields empty and verify validation errors", 0.85),
        ("Long input handled gracefully", "Enter an extremely long string into a text input and verify it is handled gracefully", 0.70),
        ("404 page shown for bad URL", "Navigate to a non-existent URL and verify a 404 or error page is shown", 0.80),
        ("Protected page redirects unauthenticated", "Attempt to access a protected page while logged out", 0.80),
        ("Invalid email format shows error", "Enter invalid characters in an email field and verify the error state", 0.75),
        ("Back button keeps app state consistent", "Click the back button mid-flow and verify the app state is consistent", 0.65),
    ],
}


def _heuristic_goals(max_goals: int) -> list[DiscoveredGoal]:
    goals: list[DiscoveredGoal] = []
    idx = 0
    for category, templates in _HEURISTIC_TEMPLATES.items():
        for name, text, confidence in templates:
            if len(goals) >= max_goals:
                break
            goals.append(
                DiscoveredGoal(
                    id=f"goal-{idx:03d}",
                    name=name,
                    text=text,
                    category=category,  # type: ignore[arg-type]
                    confidence=confidence,
                    selected=confidence >= 0.80,
                )
            )
            idx += 1
    return goals[:max_goals]


# ── Public interface ──────────────────────────────────────────────────────────

class GoalGenerator:
    """Generates prioritised, site-specific test goals for a given URL."""

    def __init__(self, config: GoalGeneratorConfig | None = None) -> None:
        self.config = config or GoalGeneratorConfig()

    def generate(self, url: str) -> list[DiscoveredGoal]:
        """
        1. Scrape the URL for real page structure
        2. Try Claude (ANTHROPIC_API_KEY) → OpenAI (OPENAI_API_KEY)
        3. Fall back to heuristic templates if no key is available
        """
        title, nav, elements = _scrape_page_text(url)

        if title or elements:
            logger.info("Scraped %s — title=%r nav=%r", url, title[:40] if title else "", nav[:60] if nav else "")
        else:
            logger.warning("Could not scrape %s — will use URL only for LLM context", url)

        # Try LLMs in priority order
        goals = _claude_goals(url, title, nav, elements, self.config)
        if not goals:
            goals = _openai_goals(url, title, nav, elements, self.config)
        if not goals:
            logger.info("No LLM key available — using heuristic fallback for %s", url)
            goals = _heuristic_goals(self.config.max_goals)

        return goals
