"""
fusiontest/desktop/playwright_adapter.py

Desktop adapter for web-based apps (Electron, browser SaaS dashboards).
Uses Playwright under the hood — the easiest and most reliable path
for the majority of modern desktop/web UIs.

Supports:
  - Standard web browsers (Chrome, Firefox, Safari)
  - Electron apps (via Chromium DevTools Protocol)
  - Progressive Web Apps (PWAs)
"""

from __future__ import annotations

import asyncio
import base64
import logging

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import ScreenParser, UIElement

logger = logging.getLogger("fusiontest.desktop.playwright")


class PlaywrightAdapter:
    """
    Adapter that drives a browser or Electron app with Playwright
    and exposes the FusionTest action interface.

    Usage (sync wrapper):
        adapter = PlaywrightAdapter(browser_type="chromium")
        adapter.start(url="https://app.example.com")
        elements, screen_text = adapter.get_screen()
        adapter.execute(action)
        adapter.stop()

    Or async:
        async with PlaywrightAdapter.async_context("chromium") as adapter:
            await adapter.async_start(url="...")
            ...
    """

    def __init__(
        self,
        browser_type: str = "chromium",
        headless: bool = False,
        slow_mo: int = 100,
        viewport: dict | None = None,
        electron_app_path: str | None = None,
    ):
        self.browser_type = browser_type
        self.headless = headless
        self.slow_mo = slow_mo
        self.viewport = viewport or {"width": 1280, "height": 800}
        self.electron_app_path = electron_app_path

        self._playwright = None
        self._browser = None
        self._page = None
        self._parser = ScreenParser()
        self._loop: asyncio.AbstractEventLoop | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
        return self._loop

    def start(self, url: str | None = None) -> None:
        self._get_loop().run_until_complete(self.async_start(url))

    def stop(self) -> None:
        loop = self._get_loop()
        loop.run_until_complete(self.async_stop())
        loop.close()
        self._loop = None

    async def async_start(self, url: str | None = None) -> None:
        try:
            from playwright.async_api import async_playwright
        except ImportError as err:
            raise RuntimeError("Playwright adapter requires: pip install playwright && playwright install") from err

        self._playwright = await async_playwright().start()

        if self.electron_app_path:
            await self._start_electron()
        else:
            browser_launcher = getattr(self._playwright, self.browser_type)
            self._browser = await browser_launcher.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
            )
            context = await self._browser.new_context(viewport=self.viewport)
            self._page = await context.new_page()
            if url:
                await self._page.goto(url, wait_until="domcontentloaded", timeout=60_000)
                # Best-effort wait for network to quiet down; ignore if it times out
                try:
                    await self._page.wait_for_load_state("networkidle", timeout=10_000)
                except Exception:
                    pass

        logger.info(f"PlaywrightAdapter started (browser={self.browser_type}, electron={bool(self.electron_app_path)})")

    async def _start_electron(self) -> None:
        """Launch an Electron app via Playwright's Electron API."""
        self._electron_app = await self._playwright.electron.launch(
            executable_path=self.electron_app_path,
        )
        self._page = await self._electron_app.first_window()
        await self._page.wait_for_load_state("domcontentloaded")

    async def async_stop(self) -> None:
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info("PlaywrightAdapter stopped")

    # ── Screen reading ─────────────────────────────────────────────────────────

    def navigate(self, url: str) -> None:
        """Navigate to a URL and wait for the page to load."""
        self._get_loop().run_until_complete(self._async_navigate(url))

    async def _async_navigate(self, url: str) -> None:
        # If the current page is closed/crashed, open a fresh one in the same context
        try:
            await self._page.title()  # cheap liveness check
        except Exception:
            logger.warning("Page was closed — opening a new page in the existing context")
            try:
                context = self._page.context
                self._page = await context.new_page()
            except Exception:
                # Context is also gone — open a completely new browser context
                logger.warning("Browser context was closed — creating a new context")
                context = await self._browser.new_context(viewport=self.viewport)
                self._page = await context.new_page()

        await self._page.goto(url, wait_until="domcontentloaded", timeout=60_000)
        try:
            await self._page.wait_for_load_state("networkidle", timeout=10_000)
        except Exception:
            pass

    def get_screen(self) -> tuple[list[UIElement], str]:
        return self._get_loop().run_until_complete(self.async_get_screen())

    async def async_get_screen(self) -> tuple[list[UIElement], str]:
        """Extract accessibility tree from the current page and parse it.
        Falls back to direct DOM extraction when aria_snapshot yields too few
        interactive elements (common on JS-heavy SPA marketing pages)."""

        # Collect page context
        page_url = self._page.url or ""
        page_title = await self._page.title() or ""

        elements: list[UIElement] = []
        screen_text = ""

        # --- Primary path: Playwright aria_snapshot ---
        try:
            aria_text = await self._page.locator("body").aria_snapshot()
        except Exception:
            aria_text = ""

        if aria_text:
            nodes = self._parse_aria_snapshot(aria_text)
            tree = {"role": "RootWebArea", "name": "", "children": nodes}
            elements, screen_text = self._parser.parse(tree, platform="playwright")

        # --- Fallback: direct DOM query when too few interactive elements ---
        interactive_count = sum(1 for e in elements if e.is_interactive())
        if interactive_count < 3:
            logger.info(f"Aria snapshot yielded only {interactive_count} interactive elements — using DOM fallback")
            dom_elements, dom_text = await self._dom_fallback_screen()
            if dom_elements:
                elements = dom_elements
                screen_text = dom_text

        # Prepend page context so the LLM knows where it is
        header = f"=== PAGE: {page_title} ===\nURL: {page_url}\n"
        screen_text = header + screen_text

        return elements, screen_text

    async def _dom_fallback_screen(self) -> tuple[list[UIElement], str]:
        """Extract interactive elements directly from the DOM via JavaScript.
        This catches elements that aria_snapshot misses on JS-heavy pages."""
        js = """
        (() => {
            const results = [];
            const seen = new Set();
            const selectors = [
                {sel: 'a[href]', type: 'link'},
                {sel: 'button', type: 'button'},
                {sel: 'input:not([type=hidden])', type: 'text_field'},
                {sel: 'textarea', type: 'text_area'},
                {sel: 'select', type: 'picker'},
                {sel: '[role=button]', type: 'button'},
                {sel: '[role=link]', type: 'link'},
                {sel: '[role=tab]', type: 'tab'},
                {sel: '[role=menuitem]', type: 'menu_item'},
                {sel: '[role=checkbox]', type: 'checkbox'},
                {sel: '[role=searchbox]', type: 'search_field'},
            ];
            for (const {sel, type} of selectors) {
                for (const el of document.querySelectorAll(sel)) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width === 0 || rect.height === 0) continue;
                    const label = (el.getAttribute('aria-label')
                        || el.textContent || el.getAttribute('placeholder')
                        || el.getAttribute('title') || '').trim().slice(0, 80);
                    if (!label) continue;
                    const key = type + ':' + label;
                    if (seen.has(key)) continue;
                    seen.add(key);
                    results.push({type, label, href: el.getAttribute('href') || '',
                                  enabled: !el.disabled, visible: true,
                                  inViewport: rect.top < window.innerHeight && rect.bottom > 0});
                    if (results.length >= 80) break;
                }
                if (results.length >= 80) break;
            }
            // Also grab headings for context
            for (const h of document.querySelectorAll('h1,h2,h3')) {
                const t = (h.textContent || '').trim().slice(0, 100);
                if (t) results.push({type: 'heading', label: t, href: '', enabled: true, visible: true, inViewport: true});
            }
            return results;
        })()
        """
        try:
            raw_elements = await self._page.evaluate(js)
        except Exception as e:
            logger.warning(f"DOM fallback failed: {e}")
            return [], ""

        elements: list[UIElement] = []
        for i, el in enumerate(raw_elements):
            elements.append(UIElement(
                index=i,
                element_type=el["type"],
                label=el["label"],
                value=el.get("href", ""),
                enabled=el.get("enabled", True),
                visible=el.get("visible", True),
                raw=el,
            ))

        interactive = [e for e in elements if e.is_interactive()]
        context = [e for e in elements if e.element_type in ("heading", "static_text", "image")]

        lines = ["=== SCREEN STATE (DOM fallback) ==="]
        if context:
            lines.append("-- Context --")
            for el in context[:20]:
                if el.label:
                    lines.append(f'  {el.element_type}: "{el.label}"')
        lines.append("-- Interactive elements --")
        for el in interactive:
            lines.append(f"  {el.to_token()}")

        return elements, "\n".join(lines)

    @staticmethod
    def _parse_aria_snapshot(text: str) -> list[dict]:
        """Parse Playwright's aria_snapshot() YAML-like output into dicts."""
        import re
        nodes: list[dict] = []
        stack: list[tuple[int, dict]] = []  # (indent_level, node)

        for line in text.splitlines():
            stripped = line.lstrip()
            if not stripped or stripped.startswith("/"):
                continue
            indent = len(line) - len(stripped)
            stripped = stripped.lstrip("- ").strip()

            # Parse lines like: role "name":  or  role:  or  text: "..."
            match = re.match(r'^(\w+)\s*"([^"]*)"', stripped)
            if match:
                role, name = match.group(1), match.group(2)
            elif re.match(r'^(\w+)\s*:', stripped):
                role = re.match(r'^(\w+)', stripped).group(1)
                name = ""
            elif re.match(r'^text:\s*(.+)', stripped):
                # text node
                role = "paragraph"
                name = re.match(r'^text:\s*(.+)', stripped).group(1).strip()
            else:
                continue

            node = {"role": role, "name": name, "children": []}

            # Find parent based on indent
            while stack and stack[-1][0] >= indent:
                stack.pop()

            if stack:
                stack[-1][1]["children"].append(node)
            else:
                nodes.append(node)

            stack.append((indent, node))

        return nodes

    def get_screenshot(self) -> bytes:
        return self._get_loop().run_until_complete(self.async_get_screenshot())

    async def async_get_screenshot(self) -> bytes:
        return await self._page.screenshot(type="png")

    # ── Action execution ───────────────────────────────────────────────────────

    def execute(self, action: Action, elements: list[UIElement]) -> bool:
        return self._get_loop().run_until_complete(
            self.async_execute(action, elements)
        )

    async def async_execute(self, action: Action, elements: list[UIElement]) -> bool:
        """
        Execute an action on the page. Returns True on success.
        All actions wait for the page to settle (networkidle or DOMContentLoaded).
        """
        try:
            if action.action_type == "tap":
                await self._tap(action, elements)
            elif action.action_type == "type":
                await self._type(action, elements)
            elif action.action_type == "scroll":
                await self._scroll(action)
            elif action.action_type == "swipe":
                await self._swipe(action)
            elif action.action_type == "back":
                await self._page.go_back()
            elif action.action_type == "wait":
                secs = float(action.value) if action.value else 1.5
                await asyncio.sleep(secs)
            elif action.action_type == "select":
                await self._select(action, elements)

            # Wait for page to settle — use domcontentloaded as primary,
            # networkidle as best-effort (SPAs often never reach networkidle)
            try:
                await self._page.wait_for_load_state("domcontentloaded", timeout=5000)
            except Exception:
                pass
            try:
                await self._page.wait_for_load_state("networkidle", timeout=3000)
            except Exception:
                pass  # SPA pages often don't reach networkidle — that's OK
            return True

        except Exception as e:
            logger.warning(f"Action failed: {action} — {e}")
            return False

    async def _tap(self, action: Action, elements: list[UIElement]) -> None:
        locator = self._resolve_locator(action, elements)

        # Detect whether this element is likely to open a new tab
        # (links with target=_blank, or rel=noopener). Default: don't wait for one.
        opens_new_tab = False
        matching = [e for e in elements if e.index == action.element_index]
        if matching and matching[0].element_type == "link":
            raw = matching[0].raw or {}
            href = raw.get("href", "") or ""
            target = raw.get("target", "") or ""
            opens_new_tab = target == "_blank" or (href.startswith("http") and "rel" in raw)

        if opens_new_tab:
            # Only block waiting for a new tab when we're confident one will open
            try:
                async with self._page.context.expect_page(timeout=5000) as new_page_info:
                    await locator.click()
                new_page = await new_page_info.value
                await new_page.wait_for_load_state("domcontentloaded", timeout=10_000)
                self._page = new_page
                logger.info(f"Switched to new tab: {new_page.url}")
            except Exception:
                pass
        else:
            # Standard click — same page or same-tab navigation
            await locator.click()
            # If a new tab was opened anyway (e.g. JS window.open), pick it up
            pages = self._page.context.pages
            if len(pages) > 1 and pages[-1] != self._page:
                new_page = pages[-1]
                try:
                    await new_page.wait_for_load_state("domcontentloaded", timeout=5000)
                    self._page = new_page
                    logger.info(f"Switched to new tab: {new_page.url}")
                except Exception:
                    pass

    async def _type(self, action: Action, elements: list[UIElement]) -> None:
        locator = self._resolve_locator(action, elements)
        await locator.fill(action.value)

    async def _scroll(self, action: Action) -> None:
        direction = action.value.lower() if action.value else "down"
        delta = 400 if direction == "down" else -400
        await self._page.mouse.wheel(0, delta)

    async def _swipe(self, action: Action) -> None:
        # Simulate swipe via mouse drag
        vp = self._page.viewport_size or {"width": 1280, "height": 800}
        cx, cy = vp["width"] // 2, vp["height"] // 2
        direction = action.value.lower() if action.value else "left"
        offsets = {"left": (-200, 0), "right": (200, 0), "up": (0, -200), "down": (0, 200)}
        dx, dy = offsets.get(direction, (-200, 0))
        await self._page.mouse.move(cx, cy)
        await self._page.mouse.down()
        await self._page.mouse.move(cx + dx, cy + dy)
        await self._page.mouse.up()

    async def _select(self, action: Action, elements: list[UIElement]) -> None:
        locator = self._resolve_locator(action, elements)
        await locator.select_option(value=action.value)

    def _resolve_locator(self, action: Action, elements: list[UIElement]):
        """Resolve an action to a Playwright locator. Tries multiple strategies:
        1. Match by element index → use role-based locator
        2. Fall back to get_by_role with action label
        3. Fall back to get_by_text with action label
        Uses .first to avoid strict mode violations when multiple elements match."""
        matching = [e for e in elements if e.index == action.element_index]
        elem = matching[0] if matching else None
        label = (elem.label if elem else action.element_label) or ""
        elem_type = (elem.element_type if elem else "")

        if label:
            # Strategy 1: role-based locator (most reliable)
            if elem_type in ("button",):
                locator = self._page.get_by_role("button", name=label).first
                return locator
            elif elem_type in ("link",):
                locator = self._page.get_by_role("link", name=label).first
                return locator
            elif elem_type in ("text_field", "text_area", "search_field"):
                # Union of all the ways a text input can be labelled:
                # 1. <label> element  2. placeholder  3. aria-label / title
                label_esc = label.replace('"', '\\"')
                return self._page.locator(
                    f'[aria-label*="{label_esc}" i], '
                    f'[placeholder*="{label_esc}" i], '
                    f'[title*="{label_esc}" i]'
                ).or_(
                    self._page.get_by_label(label, exact=False)
                ).or_(
                    self._page.get_by_placeholder(label, exact=False)
                ).first
            elif elem_type in ("tab",):
                locator = self._page.get_by_role("tab", name=label).first
                return locator
            elif elem_type in ("checkbox",):
                locator = self._page.get_by_role("checkbox", name=label).first
                return locator

            # Strategy 2: try get_by_role with common roles
            for role in ("button", "link", "tab", "menuitem", "textbox"):
                try:
                    locator = self._page.get_by_role(role, name=label).first
                    return locator
                except Exception:
                    continue

            # Strategy 3: placeholder / aria-label attribute match
            label_esc = label.replace('"', '\\"')
            return self._page.locator(
                f'[placeholder*="{label_esc}" i], [aria-label*="{label_esc}" i]'
            ).or_(
                self._page.get_by_text(label, exact=False)
            ).first

        raise ValueError(f"Cannot resolve locator for action: {action}")

    # ── Vision fallback ────────────────────────────────────────────────────────

    async def get_vision_description(self) -> str:
        """
        Fallback for pages with poor accessibility trees.
        Takes a screenshot and returns a GPT-4V/Claude description of the UI.
        """
        import os

        screenshot = await self.async_get_screenshot()
        b64 = base64.b64encode(screenshot).decode()

        # Use whichever vision LLM is configured
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return "=== SCREEN STATE ===\n-- Vision fallback not configured --"

        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            resp = client.chat.completions.create(
                model="gpt-4o",
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": (
                                "Describe all interactive UI elements visible on this screen. "
                                "For each element, note: type (button, input, link, etc.), "
                                "visible label or text, and approximate position (top/center/bottom, left/center/right). "
                                "Format as a list."
                            ),
                        },
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                    ],
                }],
                max_tokens=512,
            )
            return f"=== SCREEN STATE (vision) ===\n{resp.choices[0].message.content}"
        except Exception as e:
            logger.warning(f"Vision fallback failed: {e}")
            return "=== SCREEN STATE ===\n-- Vision fallback error --"
