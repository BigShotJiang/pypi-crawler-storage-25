"""useCursor hook — control terminal cursor position.

Port of Ink's ``src/hooks/use-cursor.ts``.
"""
from __future__ import annotations

from collections.abc import Callable

from pyink.cursor_helpers import CursorPosition
from pyink.hooks.context import get_current_app


def use_cursor() -> dict[str, Callable]:
    """Control terminal cursor position. Matches Ink's useCursor hook.

    Returns dict with set_cursor_position(pos) where pos is CursorPosition or None.
    Pass None to hide cursor.

    Returns
    -------
    dict[str, Callable]
        A dict containing a ``set_cursor_position`` callable that accepts
        a ``CursorPosition`` or ``None``.
    """
    app = get_current_app()

    def set_cursor_position(position: CursorPosition | None) -> None:
        app.set_cursor_position(position)

    return {"set_cursor_position": set_cursor_position}
