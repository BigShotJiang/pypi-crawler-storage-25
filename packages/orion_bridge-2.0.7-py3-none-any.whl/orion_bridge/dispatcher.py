"""
dispatcher.py — Routes commands to the right device handler.

Extracted from bridge.py (Phase 3, Step 4).
Updated Phase 4: added MuJoCoXArmHandler support.
"""

import json
import logging
from datetime import datetime, timezone

from .handlers import (
    XArmHandler,
    GazeboXArmHandler,
    ABBHandler,
    PLCHandler,
    ShellHandler,
)

log = logging.getLogger("orion_bridge.dispatcher")

# Optional dependency checks
try:
    import roslibpy
except ImportError:
    roslibpy = None

try:
    import mujoco as _mj
except ImportError:
    _mj = None


class BridgeDispatcher:
    """Routes incoming command messages to the appropriate device handler."""

    def __init__(self, sb_logger=None):
        self.handlers = {}  # device_type → {device_id → handler}
        self._sb_logger = sb_logger

    def register(self, device_id: str, handler):
        dtype = handler.device_type
        self.handlers.setdefault(dtype, {})[device_id] = handler
        log.info(f"Registered {dtype}/{device_id}")

    def get_handler(self, device_type: str, device_id: str = ""):
        bucket = self.handlers.get(device_type, {})
        if device_id and device_id in bucket:
            return bucket[device_id]
        if bucket:
            return next(iter(bucket.values()))
        raise ValueError(f"No handler for {device_type}/{device_id}")

    def dispatch(self, msg: dict) -> dict:
        rid = msg.get("id", "")
        dtype = msg.get("device_type", "")
        did = msg.get("device_id", "")
        action = msg.get("action", msg.get("command", ""))
        params = msg.get("params", {})
        ts = datetime.now(timezone.utc).isoformat()

        try:
            handler = self.get_handler(dtype, did)
            if not handler.is_connected:
                return {
                    "id": rid, "status": "error", "device_id": did,
                    "error": f"{dtype}/{did} not connected",
                    "timestamp": ts,
                }

            data = handler.handle(action, params)

            # log movement-type actions to supabase
            if self._sb_logger and action in (
                "move_joint", "move_linear", "home",
                "go_to_pose", "set_gripper",
            ):
                self._sb_logger.log_movement(did, action, data)
            if self._sb_logger:
                self._sb_logger.log_diagnostic(
                    did, action, {"status": "ok", "data": data}
                )

            return {
                "id": rid, "status": "ok", "device_id": did,
                "data": data, "timestamp": ts,
            }

        except Exception as e:
            log.error(f"dispatch {dtype}.{action}: {e}")
            if self._sb_logger:
                self._sb_logger.log_diagnostic(
                    did, action, {"status": "error", "error": str(e)}
                )
            return {
                "id": rid, "status": "error", "device_id": did,
                "error": str(e), "timestamp": ts,
            }

    def connect_all(self):
        for dtype, handlers in self.handlers.items():
            for did, h in handlers.items():
                try:
                    h.connect()
                except Exception as e:
                    log.error(f"Connect failed {dtype}/{did}: {e}")

    def disconnect_all(self):
        for handlers in self.handlers.values():
            for h in handlers.values():
                try:
                    h.disconnect()
                except Exception:
                    pass

    def get_status(self) -> dict:
        """Return {device_id: {type, connected}} for UI display."""
        status = {}
        for dtype, handlers in self.handlers.items():
            for did, h in handlers.items():
                status[did] = {"type": dtype, "connected": h.is_connected}
        return status


def build_dispatcher(devices: list, sb_logger=None) -> BridgeDispatcher:
    """Build a dispatcher from a config device list."""
    d = BridgeDispatcher(sb_logger=sb_logger)

    for dev in devices:
        dtype, did = dev["type"], dev["id"]

        if dtype == "xarm":
            handler_kind = dev.get("handler", "physical")

            if handler_kind == "gazebo":
                if roslibpy is None:
                    log.error("roslibpy missing — can't do Gazebo mode")
                    continue
                h = GazeboXArmHandler(
                    dev.get("rosbridge_host", "localhost"),
                    dev.get("rosbridge_port", 9090),
                )

            elif handler_kind == "mujoco":
                if _mj is None:
                    log.error(
                        "MuJoCo Python bindings missing — "
                        "pip install mujoco"
                    )
                    continue
                from .handlers.xarm_mujoco import MuJoCoXArmHandler
                h = MuJoCoXArmHandler(
                    mjcf_path=dev.get("mjcf_path", ""),
                    viewer=dev.get("viewer", True),
                )

            else:
                # physical xArm (default)
                h = XArmHandler(dev["ip"])

            d.register(did, h)

        elif dtype == "abb":
            d.register(did, ABBHandler(dev["ip"], dev.get("port", 1025)))

        elif dtype == "plc":
            d.register(did, PLCHandler(dev.get("ips", [])))

        elif dtype == "shell":
            d.register(did, ShellHandler())

        else:
            log.warning(f"Unknown device type '{dtype}', skipping")

    return d