"""
handlers/plc.py — Siemens S7-1200 PLC via snap7 / S7comm.

Extracted from bridge.py (Phase 3).
"""

import logging

from .base import DeviceHandler

log = logging.getLogger("orion_bridge.handlers.plc")


class PLCHandler(DeviceHandler):
    device_type = "plc"

    def __init__(self, plc_ips=None):
        self.plc_ips = plc_ips or []
        self._connections = {}  # ip → snap7 Client
        self._status = {}      # ip → bool
        self._Areas = None

    def connect(self) -> bool:
        try:
            import snap7
            from snap7.type import Areas

            self._Areas = Areas
        except ImportError:
            log.error("snap7 not installed: pip install python-snap7")
            return False

        for ip in self.plc_ips:
            try:
                plc = snap7.client.Client()
                plc.connect(ip, 0, 1)
                self._connections[ip] = plc
                self._status[ip] = True
                log.info(f"PLC connected: {ip}")
            except Exception as e:
                log.warning(f"PLC {ip} failed: {e}")
                self._status[ip] = False
        return any(self._status.values())

    def disconnect(self):
        for plc in self._connections.values():
            try:
                plc.disconnect()
            except Exception:
                pass
        self._connections.clear()
        self._status.clear()

    @property
    def is_connected(self) -> bool:
        return any(self._status.values())

    def handle(self, action: str, params: dict) -> dict:
        if action == "list_connections":
            return {
                "plcs": {
                    ip: {"connected": st} for ip, st in self._status.items()
                },
                "connected_count": sum(
                    1 for s in self._status.values() if s
                ),
                "total_count": len(self._status),
            }

        if action == "read_area":
            from snap7.util import get_bool

            ip = params["plc_ip"]
            area = params.get("area", "input")
            byte_addr = params.get("byte_address", 0)
            plc = self._get_plc(ip)
            result = plc.read_area(self._area_enum(area), 0, byte_addr, 1)
            bits = {f"bit_{i}": get_bool(result, 0, i) for i in range(8)}
            return {"ip": ip, "area": area, "byte": byte_addr, "bits": bits}

        if action == "write_bit":
            from snap7.util import get_bool, set_bool

            ip = params["plc_ip"]
            area = params.get("area", "output")
            byte_addr = params.get("byte_address", 0)
            bit_num = params.get("bit", 0)
            value = params.get("value", False)
            if not (0 <= bit_num <= 7):
                raise ValueError(f"Bit must be 0-7, got {bit_num}")
            plc = self._get_plc(ip)
            ae = self._area_enum(area)
            data = plc.read_area(ae, 0, byte_addr, 1)
            set_bool(data, 0, bit_num, bool(value))
            plc.write_area(ae, 0, byte_addr, data)
            return {
                "ip": ip, "area": area, "byte": byte_addr,
                "bit": bit_num, "success": True,
                "value_written": bool(value),
            }

        raise ValueError(f"PLC: unknown action '{action}'")

    # ── helpers ───────────────────────────────────────────────

    def _get_plc(self, ip):
        plc = self._connections.get(ip)
        if not plc or not self._status.get(ip):
            raise ConnectionError(f"PLC {ip} not connected")
        return plc

    def _area_enum(self, area):
        return {
            "input": self._Areas.PE,
            "output": self._Areas.PA,
            "memory": self._Areas.MK,
        }[area]