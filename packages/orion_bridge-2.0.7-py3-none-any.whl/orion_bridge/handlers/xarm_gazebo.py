"""
handlers/xarm_gazebo.py — Gazebo digital twin via rosbridge.

Extracted from bridge.py (Phase 3).
Extends BaseXArmHandler — only implements the rosbridge transport.

NOTE: This handler will be REPLACED by xarm_mujoco.py once the
MuJoCo migration is complete. Kept for backward compat during transition.
"""

import math
import time
import threading
import logging

from .base import (
    BaseXArmHandler,
    JOINT_LIMITS,
    JOINT_NAMES,
    MODE_MAP,
    NAMED_POSES,
    HOME_TCP,
    approx_fk,
)

log = logging.getLogger("orion_bridge.handlers.xarm_gazebo")

try:
    import roslibpy
except ImportError:
    roslibpy = None


class GazeboXArmHandler(BaseXArmHandler):
    """xArm 6 digital twin in Gazebo, controlled via rosbridge WebSocket."""

    def __init__(self, rosbridge_host="localhost", rosbridge_port=9090):
        super().__init__()
        self._host = rosbridge_host
        self._port = rosbridge_port
        self._client = None
        self._connected = False

        self._lock = threading.Lock()
        self._joints_rad = [0.0] * 6
        self._joints_deg = [0.0] * 6
        self._velocities = [0.0] * 6
        self._efforts = [0.0] * 6
        self._state = "ready"
        self._mode = 0
        self._error_code = 0

        self._joint_sub = None
        self._traj_pub = None
        self._last_js_time = 0.0

    # ── connection ────────────────────────────────────────────

    def connect(self) -> bool:
        if roslibpy is None:
            log.error("Need roslibpy for Gazebo mode: pip install roslibpy")
            return False
        try:
            log.info(f"Gazebo xArm: connecting rosbridge {self._host}:{self._port}...")
            self._client = roslibpy.Ros(host=self._host, port=self._port)
            self._client.run()

            self._joint_sub = roslibpy.Topic(
                self._client, "/joint_states", "sensor_msgs/JointState"
            )
            self._joint_sub.subscribe(self._on_joint_state)

            self._traj_pub = roslibpy.Topic(
                self._client,
                "/xarm6_traj_controller/joint_trajectory",
                "trajectory_msgs/JointTrajectory",
            )
            self._traj_pub.advertise()

            self._connected = True
            log.info("Gazebo xArm: connected via rosbridge")
            return True
        except Exception as e:
            log.error(f"Gazebo xArm failed: {e}")
            self._connected = False
            return False

    def disconnect(self):
        for thing in [self._joint_sub, self._traj_pub]:
            if thing:
                try:
                    (
                        thing.unsubscribe()
                        if hasattr(thing, "unsubscribe")
                        else thing.unadvertise()
                    )
                except Exception:
                    pass
        self._joint_sub = self._traj_pub = None
        if self._client:
            try:
                self._client.terminate()
            except Exception:
                pass
            self._client = None
        self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected and self._client is not None

    # ── ROS callbacks ─────────────────────────────────────────

    def _on_joint_state(self, msg):
        now = time.time()
        if (now - self._last_js_time) < 0.02:
            return  # throttle to ~50Hz
        self._last_js_time = now

        names = msg.get("name", [])
        pos = msg.get("position", [])
        vel = msg.get("velocity", [])
        eff = msg.get("effort", [])
        if len(pos) < 6:
            return

        joint_order = {}
        for i, name in enumerate(names):
            if name.startswith("joint"):
                try:
                    jnum = int(name.replace("joint", ""))
                    joint_order[jnum] = i
                except ValueError:
                    pass

        if len(joint_order) < 6:
            return

        with self._lock:
            for j in range(1, 7):
                idx = joint_order[j]
                self._joints_rad[j - 1] = pos[idx]
                self._joints_deg[j - 1] = math.degrees(pos[idx])
                self._velocities[j - 1] = vel[idx] if idx < len(vel) else 0.0
                self._efforts[j - 1] = eff[idx] if idx < len(eff) else 0.0

    # ── transport layer (BaseXArmHandler contract) ────────────

    def _read_joints(self) -> list:
        with self._lock:
            return list(self._joints_deg)

    def _read_tcp(self) -> dict:
        joints = self._read_joints()
        tcp = approx_fk(joints)
        return {
            "x": tcp[0], "y": tcp[1], "z": tcp[2],
            "roll": tcp[3], "pitch": tcp[4], "yaw": tcp[5],
        }

    def _move_to(self, angles_deg: list, speed: float = 30) -> None:
        rad = [math.radians(a) for a in angles_deg]
        dur = self._calc_duration(rad, speed)
        self._pub_traj(rad, dur)
        self._wait_converge(angles_deg, timeout=max(dur + 2.0, 10.0))

    def _get_state(self) -> str:
        return self._state

    def _get_mode(self) -> str:
        return MODE_MAP.get(self._mode, "unknown")

    def _estop(self, p):
        with self._lock:
            cur = list(self._joints_rad)
        self._pub_traj(cur, 0.1)
        self._state = "emergency_stop"
        return {"stopped": True, "state": "emergency_stop"}

    # ── telemetry ─────────────────────────────────────────────

    def get_telemetry(self) -> dict:
        with self._lock:
            return {
                "joints_deg": [round(a, 3) for a in self._joints_deg],
                "velocities": [round(v, 4) for v in self._velocities],
                "efforts": [round(e, 4) for e in self._efforts],
                "gripper": self._gripper_pos,
                "state": self._state,
            }

    # ── internal helpers ──────────────────────────────────────

    def _pub_traj(self, angles_rad, duration=2.0):
        if not self._client or not self._client.is_connected:
            raise RuntimeError("rosbridge disconnected")
        msg = roslibpy.Message(
            {
                "joint_names": [f"joint{i+1}" for i in range(6)],
                "points": [
                    {
                        "positions": angles_rad,
                        "time_from_start": {
                            "secs": int(duration),
                            "nsecs": int((duration % 1) * 1e9),
                        },
                    }
                ],
            }
        )
        self._traj_pub.publish(msg)

    def _calc_duration(self, target_rad, speed_dps=30):
        with self._lock:
            cur = list(self._joints_rad)
        max_delta = max(abs(a - b) for a, b in zip(target_rad, cur))
        return max(1.0, max_delta / (max(speed_dps, 1) * math.pi / 180))

    def _wait_converge(
        self, angles_deg, timeout=10.0, tolerance_deg=1.5
    ):
        """Wait until joints converge to target."""
        deadline = time.time() + timeout
        settled_count = 0
        SETTLED_REQUIRED = 3

        while time.time() < deadline:
            time.sleep(0.2)
            current = self._read_joints()
            all_close = all(
                abs(current[i] - angles_deg[i]) < tolerance_deg
                for i in range(6)
            )
            if all_close:
                settled_count += 1
                if settled_count >= SETTLED_REQUIRED:
                    return
            else:
                settled_count = 0

        final = self._read_joints()
        max_error = max(abs(final[i] - angles_deg[i]) for i in range(6))
        log.warning(
            f"_wait_converge timeout: target={[round(a,1) for a in angles_deg]}, "
            f"actual={[round(a,1) for a in final]}, max_error={max_error:.1f}°"
        )