"""
handlers/base.py — Base classes and shared constants for device handlers.

Extracted from bridge.py (Phase 3, Step 1).
Updated Phase 4: supports both xArm 6 and xArm 7 via num_joints property.
"""

import math
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional



JOINT_NAMES_6 = {
    1: "Base",
    2: "Shoulder",
    3: "Elbow",
    4: "Wrist Roll",
    5: "Wrist Pitch",
    6: "Wrist Yaw",
}

JOINT_NAMES_7 = {
    1: "Base",
    2: "Shoulder",
    3: "Elbow Roll",
    4: "Elbow Pitch",
    5: "Wrist Roll",
    6: "Wrist Pitch",
    7: "Wrist Yaw",
}

JOINT_LIMITS_6 = {
    1: (-360, 360),
    2: (-118, 120),
    3: (-225, 11),
    4: (-360, 360),
    5: (-97, 180),
    6: (-360, 360),
}

JOINT_LIMITS_7 = {
    1: (-360, 360),
    2: (-118, 120),
    3: (-360, 360),
    4: (-11, 225),
    5: (-360, 360),
    6: (-97, 180),
    7: (-360, 360),
}

# Legacy aliases (default to 6-DOF for backward compat)
JOINT_NAMES = JOINT_NAMES_6
JOINT_LIMITS = JOINT_LIMITS_6

STATE_MAP = {1: "moving", 2: "sleeping", 3: "suspended", 4: "stopping"}

MODE_MAP = {
    0: "position control",
    1: "servo joint",
    2: "manual/teach",
    3: "servo cartesian",
    4: "joint velocity",
    5: "cartesian velocity",
    6: "joint online",
    7: "cartesian online",
}

NAMED_POSES_6 = {
    "home":    [0, 0, 0, 0, 0, 0],
    "pick":    [0, -30, 60, 0, 90, 0],
    "place":   [90, -30, 60, 0, 90, 0],
    "ready":   [0, -45, 30, 0, 45, 0],
    "inspect": [0, -60, 90, 0, 30, 0],
}

NAMED_POSES_7 = {
    "home":    [0, 0, 0, 0, 0, 0, 0],
    "pick":    [0, -30, 0, 60, 0, 90, 0],
    "place":   [90, -30, 0, 60, 0, 90, 0],
    "ready":   [0, -45, 0, 30, 0, 45, 0],
    "inspect": [0, -60, 0, 90, 0, 30, 0],
}

NAMED_POSES = NAMED_POSES_6  # legacy alias

_LINK_L = [267.0, 289.6, 77.5, 342.5, 97.0, 76.0]

HOME_TCP = [206.0, 0.0, 120.5, 180.0, 0.0, 0.0]



def approx_fk(joints_deg: list) -> list:
    """
    Rough FK for the xArm 6.
    Good enough for UI display and telemetry, not for path planning.
    Returns [x, y, z, roll, pitch, yaw] in mm / degrees.
    For xArm 7, pass a 7-element list — joint 3 (elbow roll) is ignored.
    """
    # If 7 joints, collapse to 6 by dropping joint3 (redundant elbow roll)
    if len(joints_deg) == 7:
        j6 = [joints_deg[0], joints_deg[1], joints_deg[3],
              joints_deg[4], joints_deg[5], joints_deg[6]]
    else:
        j6 = joints_deg

    j = [math.radians(a) for a in j6]
    L1, L2, L3, L4, L5, L6 = _LINK_L

    r = (
        L2 * math.cos(j[1])
        + L3 * math.cos(j[1] + j[2])
        + (L4 + L5) * math.cos(j[1] + j[2] + j[4])
    )
    z = (
        L1
        + L2 * math.sin(j[1])
        + L3 * math.sin(j[1] + j[2])
        + (L4 + L5) * math.sin(j[1] + j[2] + j[4])
        + L6
    )
    x = r * math.cos(j[0])
    y = r * math.sin(j[0])

    roll = 180.0
    pitch = j6[1] + j6[2] + j6[4]
    yaw = j6[3] + j6[5]
    return [round(v, 2) for v in [x, y, z, roll, pitch, yaw]]



def euler_to_quat(ex, ey, ez):
    """Euler angles (degrees) → quaternion (q1, q2, q3, q4)."""
    hx = math.radians(ex / 2)
    hy = math.radians(ey / 2)
    hz = math.radians(ez / 2)
    cx, sx = math.cos(hx), math.sin(hx)
    cy, sy = math.cos(hy), math.sin(hy)
    cz, sz = math.cos(hz), math.sin(hz)
    return (
        cz * cy * cx + sz * sy * sx,
        cz * cy * sx - sz * sy * cx,
        cz * sy * cx + sz * cy * sx,
        sz * cy * cx - cz * sy * sx,
    )


def quat_to_euler(q1, q2, q3, q4):
    """Quaternion → Euler angles (ex, ey, ez) in degrees."""
    sinp = max(-1.0, min(1.0, 2.0 * (q1 * q3 - q4 * q2)))
    ey = math.degrees(math.asin(sinp))
    if abs(sinp) > 0.9999:
        ex = math.degrees(
            math.atan2(2 * (q2 * q3 + q1 * q4), 1 - 2 * (q3**2 + q4**2))
        )
        ez = 0.0
    else:
        ex = math.degrees(
            math.atan2(2 * (q1 * q2 + q3 * q4), 1 - 2 * (q2**2 + q3**2))
        )
        ez = math.degrees(
            math.atan2(2 * (q1 * q4 + q2 * q3), 1 - 2 * (q3**2 + q4**2))
        )
    return round(ex, 2), round(ey, 2), round(ez, 2)



class DeviceHandler(ABC):
    """
    Base class for all device handlers.
    Each handler connects to one physical or simulated device,
    and exposes a uniform handle(action, params) → dict API.
    """

    device_type: str = "unknown"

    @abstractmethod
    def connect(self) -> bool:
        ...

    @abstractmethod
    def disconnect(self) -> None:
        ...

    @abstractmethod
    def handle(self, action: str, params: dict) -> dict:
        ...

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        ...



class BaseXArmHandler(DeviceHandler):
    """
    Shared logic between XArmHandler (physical), GazeboXArmHandler, and
    MuJoCoXArmHandler.

    Supports both xArm 6 (6 joints) and xArm 7 (7 joints) via the
    num_joints property. Subclasses set self._num_joints in __init__
    or connect().

    Subclasses must implement:
        connect, disconnect, is_connected,
        _read_joints() → list[float]   (N angles in degrees)
        _read_tcp() → dict             ({x,y,z,roll,pitch,yaw})
        _move_to(angles_deg, speed) → None   (blocking move)
        _get_state() → str
        _get_mode() → str
    """

    device_type = "xarm"

    def __init__(self, num_joints: int = 6):
        self._gripper_pos: float = 850.0
        self._num_joints: int = num_joints

    @property
    def num_joints(self) -> int:
        return self._num_joints

    @property
    def joint_names(self) -> dict:
        return JOINT_NAMES_7 if self._num_joints == 7 else JOINT_NAMES_6

    @property
    def joint_limits(self) -> dict:
        return JOINT_LIMITS_7 if self._num_joints == 7 else JOINT_LIMITS_6

    @property
    def named_poses(self) -> dict:
        return NAMED_POSES_7 if self._num_joints == 7 else NAMED_POSES_6


    def handle(self, action: str, params: dict) -> dict:
        dispatch = {
            "get_position":    self._get_position,
            "get_full_status": self._get_full_status,
            "move_joint":      self._move_joint,
            "move_linear":     self._move_linear,
            "home":            self._home,
            "go_to_pose":      self._go_to_pose,
            "set_gripper":     self._gripper,
            "emergency_stop":  self._estop,
            "highlight_joint": self._highlight_joint,
            "show_workspace":  self._show_workspace,
            "demo_movement":   self._demo_movement,
            "say_hi":          self._say_hi,
            "show_all_joints": self._show_all_joints,
        }
        fn = dispatch.get(action)
        if not fn:
            raise ValueError(f"xArm: unknown action '{action}'")
        return fn(params)


    @abstractmethod
    def _read_joints(self) -> list:
        """Return N joint angles in degrees."""
        ...

    @abstractmethod
    def _read_tcp(self) -> dict:
        """Return {x, y, z, roll, pitch, yaw} in mm/degrees."""
        ...

    @abstractmethod
    def _move_to(self, angles_deg: list, speed: float = 30) -> None:
        """Move to target joint angles. Block until done."""
        ...

    @abstractmethod
    def _get_state(self) -> str:
        ...

    @abstractmethod
    def _get_mode(self) -> str:
        ...

    @abstractmethod
    def _estop(self, p: dict) -> dict:
        ...


    def _get_position(self, p):
        return {
            "tcp": self._read_tcp(),
            "joints": self._read_joints(),
            "state": self._get_state(),
            "mode": self._get_mode(),
            "num_joints": self._num_joints,
        }

    def _get_full_status(self, p):
        """Override in subclass for real telemetry (temps, currents, etc)."""
        n = self._num_joints
        return {
            **self._get_position(p),
            "joint_velocities": [0.0] * n,
            "joint_efforts": [0.0] * n,
            "temperatures": [25.0] * n,
            "currents": [0.0] * n,
            "error_code": 0,
            "warning_code": 0,
            "gripper_position": self._gripper_pos,
        }

    def _move_joint(self, p):
        n = self._num_joints
        jid = p.get("joint_id", p.get("joint", 1))
        angle = float(p.get("angle", 0))
        speed = p.get("speed", 30)

        if jid < 1 or jid > n:
            raise ValueError(f"Joint {jid} doesn't exist (1-{n})")
        lo, hi = self.joint_limits[jid]
        if not (lo <= angle <= hi):
            raise ValueError(
                f"J{jid} ({self.joint_names[jid]}): {angle}° is outside [{lo}°, {hi}°]"
            )

        current = self._read_joints()
        prev = current[jid - 1]
        current[jid - 1] = angle
        self._move_to(current, speed)

        return {
            "code": 0,
            "target_joint": jid,
            "joint_name": self.joint_names[jid],
            "target_angle": angle,
            "previous_angle": prev,
            "final_angles": self._read_joints(),
            "state": self._get_state(),
        }

    def _move_linear(self, p):
        raise ValueError(
            "Cartesian moves need IK. Use move_joint or go_to_pose."
        )

    def _home(self, p):
        n = self._num_joints
        self._move_to([0] * n, p.get("speed", 30))
        tcp = self._read_tcp()
        return {
            "code": 0,
            "final_tcp": {"x": tcp["x"], "y": tcp["y"], "z": tcp["z"]},
            "state": self._get_state(),
        }

    def _go_to_pose(self, p):
        pose = p.get("pose", "home")
        joints = self.named_poses.get(pose, self.named_poses["home"])
        self._move_to(joints, p.get("speed", 30))
        return {
            "code": 0,
            "pose": pose,
            "final_angles": joints,
            "state": self._get_state(),
        }

    def _gripper(self, p):
        action = p.get("action", "toggle")
        if action == "open":
            pos = 850
        elif action == "close":
            pos = 0
        else:
            pos = 0 if self._gripper_pos > 400 else 850
        self._gripper_pos = pos
        return {
            "code": 0,
            "target_position": pos,
            "current_position": pos,
            "is_open": pos > 400,
        }

    def _highlight_joint(self, p):
        jid = p.get("joint_id", 1)
        current = self._read_joints()
        orig = current[jid - 1]
        for offset in [10, -10, 0]:
            current[jid - 1] = orig + offset
            self._move_to(current, 10)
            if offset != 0:
                import time
                time.sleep(0.3)
        return {
            "feedback": f"J{jid} ({self.joint_names[jid]}) highlighted",
            "safety_note": "Speed limited to 10% during demo",
        }

    def _show_workspace(self, p):
        jid = p.get("joint_id", 1)
        lo, hi = self.joint_limits.get(jid, (-180, 180))
        return {
            "feedback": f"J{jid} ({self.joint_names[jid]}): [{lo}°, {hi}°]",
            "safety_note": "Slow movement for range demo",
        }

    def _demo_movement(self, p):
        pattern = p.get("pattern", "pick_and_place")
        return {
            "feedback": f"Demo '{pattern}': home → pick → place → home",
            "safety_note": "Speed at 15%",
        }

    def _say_hi(self, p):
        n = self._num_joints
        speed = p.get("speed", 25)
        if n == 7:
            safe = [0, -45, 0, -25, 0, 70, 0]
            waves = [
                [20, -45, 0, -25, 0, 70, 30],
                [-20, -45, 0, -25, 0, 70, -30],
                [20, -45, 0, -25, 0, 70, 30],
                [-20, -45, 0, -25, 0, 70, -30],
            ]
        else:
            safe = [0, -45, -25, 0, 70, 0]
            waves = [
                [20, -45, -25, 0, 70, 30],
                [-20, -45, -25, 0, 70, -30],
                [20, -45, -25, 0, 70, 30],
                [-20, -45, -25, 0, 70, -30],
            ]
        self._move_to(safe, 30)
        for ang in waves:
            self._move_to(ang, speed)
        self._move_to(safe, speed)
        return {
            "code": 0,
            "feedback": "Robot saludó moviendo la base y la muñeca",
            "safety_note": "Animación completada desde posición segura",
        }

    def _show_all_joints(self, p: dict) -> dict:
        n = self._num_joints
        speed = p.get("speed", 20)
        demo_ranges = [20, 10, 15, 20, 10, 20, 20]

        # Start from zeros
        self._move_to([0.0] * n, speed=30)

        sequence = []
        for i in range(n):
            demo_range = demo_ranges[i] if i < len(demo_ranges) else 15
            target = [0.0] * n

            target[i] = demo_range
            self._move_to(target, speed)

            target[i] = -demo_range
            self._move_to(target, speed)

            target[i] = 0.0
            self._move_to(target, speed)

            sequence.append({
                "joint": i + 1,
                "name": self.joint_names.get(i + 1, f"J{i+1}"),
                "range_deg": demo_range,
            })

        return {
            "code": 0,
            "joints_demonstrated": n,
            "sequence": sequence,
            "feedback": f"Demostré mis {n} joints",
        }