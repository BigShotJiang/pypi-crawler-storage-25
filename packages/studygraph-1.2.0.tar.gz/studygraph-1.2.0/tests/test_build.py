import json

from studygraph.build import run_build


def test_build_help():
    from click.testing import CliRunner
    from studygraph.cli import main
    runner = CliRunner()
    result = runner.invoke(main, ["build", "--help"])
    assert result.exit_code == 0
    assert "dry-run" in result.output


def test_run_build_with_mock_input(tmp_path):
    input_dir = tmp_path / "input" / "Analisi_1"
    input_dir.mkdir(parents=True)
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir(parents=True)
    extracted_dir = tmp_path / "extracted"
    extracted_dir.mkdir(parents=True)
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True)

    from studygraph.config import load_config
    config = load_config()
    config["storage"]["raw_path"] = str(raw_dir)
    config["storage"]["extracted_path"] = str(extracted_dir)
    config["storage"]["output_path"] = str(output_dir)
    config["llm"]["enabled"] = False

    result = run_build(
        input_dir=str(input_dir), course="Analisi_1",
        dry_run=True, output_dir=str(output_dir),
        skip_export=True, config=config,
    )

    assert "error" not in result
