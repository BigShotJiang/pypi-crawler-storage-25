import json
from pathlib import Path

from studygraph.search_index import build_index
from studygraph.vector_index import build_vector_index
from studygraph.vector_search import semantic_search, cosine_similarity


def _config():
    return {
        "embedding": {
            "provider": "mock",
            "dimensions": 384,
            "model": "",
            "base_url": "",
            "api_key_env": "STUDYGRAPH_EMBEDDING_API_KEY",
        },
        "api_key": None,
    }


def _create_kb(tmp_path) -> Path:
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)

    docs = [
        {
            "source_id": "src_001",
            "filename": "Fourier.md",
            "course": "Analisi 1",
            "topic": "Serie di Fourier",
            "final_score": 0.85,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        },
        {
            "source_id": "src_002",
            "filename": "Limiti.md",
            "course": "Analisi 1",
            "topic": "Limiti di funzioni",
            "final_score": 0.78,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
        },
    ]

    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False)

    for d in docs:
        md_path = kb / d["markdown_path"]
        md_path.parent.mkdir(parents=True, exist_ok=True)
        topic_words = d["topic"].lower().replace(" ", "_")
        content = (
            f"---\nsource_id: {d['source_id']}\n---\n\n"
            f"# {d['topic']}\n\n"
            f"Questo documento riguarda {d['topic']}. "
            + " ".join([f"{topic_words}_{i}" for i in range(100)])
        )
        md_path.write_text(content, encoding="utf-8")

    return kb


def test_cosine_similarity_basic():
    a = [1.0, 0.0, 0.0]
    b = [1.0, 0.0, 0.0]
    assert cosine_similarity(a, b) == 1.0


def test_cosine_similarity_orthogonal():
    a = [1.0, 0.0]
    b = [0.0, 1.0]
    assert cosine_similarity(a, b) == 0.0


def test_cosine_similarity_zero():
    assert cosine_similarity([], []) == 0.0


def test_semantic_finds_chunk(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = semantic_search("Fourier", str(kb / "vector_index"), _config())
    assert len(results) > 0


def test_semantic_scores_descending(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = semantic_search("Fourier", str(kb / "vector_index"), _config(), top_k=10)
    for i in range(len(results) - 1):
        assert results[i]["score"] >= results[i + 1]["score"]


def test_course_filter_works(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = semantic_search("Fourier", str(kb / "vector_index"), _config(), course="Fisica")
    assert len(results) == 0


def test_empty_query_returns_empty(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    assert semantic_search("", str(kb / "vector_index"), _config()) == []


def test_missing_index_returns_empty(tmp_path):
    assert semantic_search("test", str(tmp_path / "nonexistent"), _config()) == []


def test_json_serializable(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = semantic_search("Fourier", str(kb / "vector_index"), _config())
    json.dumps(results, ensure_ascii=False)


def test_metadata_present(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = semantic_search("Fourier", str(kb / "vector_index"), _config())
    assert len(results) > 0
    r = results[0]
    assert "chunk_id" in r
    assert "source_id" in r
    assert "filename" in r
    assert "course" in r
    assert "markdown_path" in r
    assert "score_type" in r
    assert r["score_type"] == "semantic"
