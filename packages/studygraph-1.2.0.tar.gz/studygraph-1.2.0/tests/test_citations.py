from studygraph.citations import format_sources, validate_citations


def _source(citation_id=1):
    return {
        "citation_id": citation_id,
        "chunk_id": f"src_001::000{citation_id}",
        "source_id": "src_001",
        "filename": "Fourier.md",
        "course": "Analisi 1",
        "topic": "Serie di Fourier",
        "score": 0.87,
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
    }


def test_format_sources_outputs_numbered_sources():
    sources = [_source(1), _source(2)]
    output = format_sources(sources)
    assert "[1]" in output
    assert "[2]" in output
    assert "Fourier.md" in output
    assert "Analisi 1" in output


def test_format_sources_empty():
    assert format_sources([]) == ""


def test_validate_citations_valid_answer():
    sources = [_source(1), _source(2)]
    answer = "La serie di Fourier è una somma di seni e coseni. [1]"
    result = validate_citations(answer, sources)
    assert result["valid"] is True
    assert result["missing_citations"] is False


def test_validate_citations_missing_citations():
    sources = [_source(1)]
    answer = "Risposta senza citazioni."
    result = validate_citations(answer, sources)
    assert result["valid"] is False
    assert result["missing_citations"] is True


def test_validate_citations_invalid_citation_id():
    sources = [_source(1)]
    answer = "Testo [99]"
    result = validate_citations(answer, sources)
    assert result["valid"] is False
    assert 99 in result["invalid_citations"]


def test_validate_citations_no_answer_does_not_require_citation():
    sources = []
    answer = "Non ho trovato evidenza sufficiente nella knowledge base."
    result = validate_citations(answer, sources)
    assert result["valid"] is True


def test_validate_citations_multiple_sources():
    sources = [_source(1), _source(2), _source(3)]
    answer = "Primo [1] e secondo [2] e terzo [3]."
    result = validate_citations(answer, sources)
    assert result["valid"] is True
    assert result["used_citation_ids"] == [1, 2, 3]
