import json
from pathlib import Path

from studygraph.knowledge_base import build_knowledge_base, _filter_documents, _sanitize


def _doc(source_id: str, decision: str, course: str = "Analisi 1", topic: str = "") -> dict:
    return {
        "source_id": source_id,
        "filename": f"{source_id}.pdf",
        "course": course,
        "topic": topic or f"topic_{source_id}",
        "final_decision": decision,
        "suggested_decision": decision,
        "final_score": 0.7,
        "language": "it",
        "page_count": 5,
        "char_count": 1500,
        "text_quality_score": 0.8,
    }


def test_build_kb_creates_structure(tmp_path):
    docs = [_doc("src_001", "candidate"), _doc("src_002", "needs_review")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    for sid in ("src_001", "src_002"):
        (extracted / f"{sid}.txt").write_text("Contenuto del documento.", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    kb_dir = Path(stats["kb_dir"])

    assert (kb_dir / "catalog.json").exists()
    assert (kb_dir / "catalog.csv").exists()
    assert (kb_dir / "global_index.md").exists()
    assert (kb_dir / "courses" / "Analisi_1").exists()
    assert (kb_dir / "courses" / "Analisi_1" / "index.md").exists()
    assert (kb_dir / "courses" / "Analisi_1" / "topics.json").exists()


def test_build_kb_creates_markdown_files(tmp_path):
    docs = [_doc("src_001", "candidate")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "src_001.txt").write_text("# Test content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    kb_dir = Path(stats["kb_dir"])
    md_path = kb_dir / "courses" / "Analisi_1" / "documents" / "src_001.md"
    assert md_path.exists()
    content = md_path.read_text(encoding="utf-8")
    assert "source_id: src_001" in content
    assert "topic: topic_src_001" in content


def test_build_kb_handles_missing_txt(tmp_path):
    docs = [_doc("src_001", "candidate"), _doc("src_002", "candidate")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "src_001.txt").write_text("Content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    assert stats["exported"] == 1


def test_build_kb_handles_spaces_in_course(tmp_path):
    docs = [_doc("src_001", "candidate", course="Analisi 1")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "src_001.txt").write_text("Content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    kb_dir = Path(stats["kb_dir"])
    assert (kb_dir / "courses" / "Analisi_1" / "documents" / "src_001.md").exists()


def test_build_kb_only_candidates_flag(tmp_path):
    docs = [_doc("src_001", "candidate"), _doc("src_002", "needs_review")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    for sid in ("src_001", "src_002"):
        (extracted / f"{sid}.txt").write_text("Content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path), only_candidates=True)
    assert stats["exported"] == 1


def test_build_kb_creates_topics_json(tmp_path):
    docs = [
        _doc("src_001", "candidate", topic="Fourier"),
        _doc("src_002", "candidate", topic="Fourier"),
        _doc("src_003", "candidate", topic="Derivate"),
    ]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    for sid in ("src_001", "src_002", "src_003"):
        (extracted / f"{sid}.txt").write_text("Content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    topics_path = Path(stats["kb_dir"]) / "courses" / "Analisi_1" / "topics.json"
    topics = json.loads(topics_path.read_text(encoding="utf-8"))
    assert "Fourier" in topics
    assert "Derivate" in topics
    assert len(topics["Fourier"]) == 2
    assert len(topics["Derivate"]) == 1


def test_build_kb_course_index_has_table(tmp_path):
    docs = [_doc("src_001", "candidate", topic="Fourier")]
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "src_001.txt").write_text("Content", encoding="utf-8")

    stats = build_knowledge_base(docs, str(extracted), str(tmp_path))
    idx_path = Path(stats["kb_dir"]) / "courses" / "Analisi_1" / "index.md"
    content = idx_path.read_text(encoding="utf-8")
    assert "Fourier" in content
    assert "Score" in content
    assert "documenti" in content.lower()


def test_filter_documents():
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
        _doc("src_003", "reject"),
        _doc("src_004", "duplicate"),
        _doc("src_005", "private_only"),
    ]
    filtered = _filter_documents(docs)
    assert len(filtered) == 2


def test_sanitize():
    assert _sanitize("Analisi 1") == "Analisi_1"
    assert _sanitize("C:/Bad") == "C__Bad"
    assert _sanitize("") == "unnamed"
