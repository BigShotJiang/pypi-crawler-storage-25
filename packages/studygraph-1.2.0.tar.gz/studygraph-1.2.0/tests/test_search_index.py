import json
from pathlib import Path

from studygraph.search_index import build_index, tokenize


def _create_kb(tmp_path, docs: list[dict]) -> Path:
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)
    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False)
    for d in docs:
        md_path = kb / d.get("markdown_path", "")
        md_path.parent.mkdir(parents=True, exist_ok=True)
        content = (
            f"---\nsource_id: {d['source_id']}\n---\n\n"
            f"# {d['topic']}\n\n"
            + " ".join([f"parola_{i}" for i in range(200)])
        )
        md_path.write_text(content, encoding="utf-8")
    return kb


def test_creates_all_output_files(tmp_path):
    docs = [
        {"source_id": "src_001", "filename": "Fourier.md", "course": "Analisi 1",
         "topic": "Fourier", "markdown_path": "courses/Analisi_1/documents/Fourier.md",
         "final_score": 0.85, "language": "it"},
    ]
    kb = _create_kb(tmp_path, docs)
    stats = build_index(str(kb))
    idx = Path(stats["index_dir"])
    assert (idx / "chunks.jsonl").exists()
    assert (idx / "documents.jsonl").exists()
    assert (idx / "terms.json").exists()
    assert (idx / "index_meta.json").exists()


def test_chunks_jsonl_valid(tmp_path):
    docs = [
        {"source_id": "src_001", "filename": "Fourier.md", "course": "Analisi 1",
         "topic": "Fourier", "markdown_path": "courses/Analisi_1/documents/Fourier.md",
         "final_score": 0.85, "language": "it"},
    ]
    kb = _create_kb(tmp_path, docs)
    stats = build_index(str(kb))
    chunks_path = Path(stats["index_dir"]) / "chunks.jsonl"
    with open(chunks_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            c = json.loads(line)
            assert "chunk_id" in c
            assert "text" in c
            assert "tokens" in c


def test_terms_index_maps_terms_to_chunks(tmp_path):
    docs = [
        {"source_id": "src_001", "filename": "Fourier.md", "course": "Analisi 1",
         "topic": "Fourier", "markdown_path": "courses/Analisi_1/documents/Fourier.md",
         "final_score": 0.85, "language": "it"},
    ]
    kb = _create_kb(tmp_path, docs)
    stats = build_index(str(kb))
    terms = json.loads(Path(stats["index_dir"]).joinpath("terms.json").read_text(encoding="utf-8"))
    assert isinstance(terms, dict)
    assert len(terms) > 0


def test_handles_empty_kb(tmp_path):
    kb = tmp_path / "empty_kb"
    kb.mkdir()
    stats = build_index(str(kb))
    assert stats["documents"] == 0
    assert stats["chunks"] == 0


def test_force_rebuild(tmp_path):
    docs = [
        {"source_id": "src_001", "filename": "Fourier.md", "course": "Analisi 1",
         "topic": "Fourier", "markdown_path": "courses/Analisi_1/documents/Fourier.md",
         "final_score": 0.85, "language": "it"},
    ]
    kb = _create_kb(tmp_path, docs)
    stats1 = build_index(str(kb))
    stats2 = build_index(str(kb), force=False)
    assert stats2["documents"] == stats1["documents"]
    stats3 = build_index(str(kb), force=True)
    assert stats3["documents"] == stats1["documents"]


def test_index_meta_stats_correct(tmp_path):
    docs = [
        {"source_id": "src_001", "filename": "Fourier.md", "course": "Analisi 1",
         "topic": "Fourier", "markdown_path": "courses/Analisi_1/documents/Fourier.md",
         "final_score": 0.85, "language": "it"},
        {"source_id": "src_002", "filename": "Limiti.md", "course": "Analisi 1",
         "topic": "Limiti", "markdown_path": "courses/Analisi_1/documents/Limiti.md",
         "final_score": 0.78, "language": "it"},
    ]
    kb = _create_kb(tmp_path, docs)
    stats = build_index(str(kb))
    assert stats["documents"] == 2


def test_tokenize_simple():
    tokens = tokenize("Serie di Fourier")
    assert "serie" in tokens
    assert "fourier" in tokens
    assert "di" not in tokens


def test_tokenize_stopwords():
    tokens = tokenize("il lo la che non una con")
    assert all(t not in tokens for t in ["il", "lo", "la", "che", "non", "una", "con"])


def test_tokenize_short_terms():
    tokens = tokenize("a b c parole")
    assert "parole" in tokens
    assert not any(t in tokens for t in ["a", "b", "c"])
