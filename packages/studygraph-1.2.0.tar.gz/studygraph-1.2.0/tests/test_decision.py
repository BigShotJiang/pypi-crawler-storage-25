from studygraph.decision import decide


DEFAULT_CONFIG = {
    "scoring": {
        "high_risk_threshold": 0.85,
        "candidate_threshold": 0.75,
        "needs_review_threshold": 0.55,
    }
}


def _scores(**overrides):
    base = {
        "privacy_risk": 0.0,
        "copyright_risk": 0.0,
        "academic_reliability_risk": 0.0,
        "duplication_score": 0.0,
        "course_relevance": 0.5,
        "study_value": 0.5,
        "clarity": 0.5,
        "completeness": 0.5,
        "originality": 0.5,
        "actionability": 0.5,
    }
    base.update(overrides)
    return base


def test_privacy_risk_reject():
    result = decide(_scores(privacy_risk=0.85), DEFAULT_CONFIG)
    assert result["decision"] == "reject"
    assert "privacy" in result["reason"].lower()


def test_copyright_risk_reject():
    result = decide(_scores(copyright_risk=0.90), DEFAULT_CONFIG)
    assert result["decision"] == "reject"
    assert "copyright" in result["reason"].lower()


def test_academic_reliability_needs_review():
    result = decide(_scores(academic_reliability_risk=0.85), DEFAULT_CONFIG)
    assert result["decision"] == "needs_review"
    assert "affidabil" in result["reason"].lower()


def test_duplicate_hard_block():
    result = decide(_scores(duplication_score=0.95, privacy_risk=0.0), DEFAULT_CONFIG)
    assert result["decision"] == "duplicate"
    assert "duplicato" in result["reason"].lower()


def test_privacy_wins_over_duplicate():
    result = decide(_scores(duplication_score=0.95, privacy_risk=0.90), DEFAULT_CONFIG)
    assert result["decision"] == "reject"
    assert "privacy" in result["reason"].lower()


def test_excellent_score_candidate():
    result = decide(_scores(
        course_relevance=1.0, study_value=1.0, clarity=1.0,
        completeness=1.0, originality=1.0, actionability=1.0,
        privacy_risk=0.0, copyright_risk=0.0, academic_reliability_risk=0.0,
    ), DEFAULT_CONFIG)
    assert result["decision"] == "candidate"
    assert result["final_score"] > 0.75


def test_mid_score_needs_review():
    result = decide(_scores(
        course_relevance=0.65, study_value=0.65, clarity=0.65,
        completeness=0.65, originality=0.65, actionability=0.65,
        privacy_risk=0.25, copyright_risk=0.25, academic_reliability_risk=0.25,
    ), DEFAULT_CONFIG)
    assert result["decision"] == "needs_review"


def test_low_score_reject():
    result = decide(_scores(
        course_relevance=0.3, study_value=0.3, clarity=0.3,
        completeness=0.3, originality=0.3, actionability=0.3,
        privacy_risk=0.7, copyright_risk=0.7, academic_reliability_risk=0.7,
    ), DEFAULT_CONFIG)
    assert result["decision"] == "reject"


def test_high_score_blocked_by_risk():
    result = decide(_scores(
        course_relevance=1.0, study_value=1.0, clarity=1.0,
        completeness=1.0, originality=1.0, actionability=1.0,
        privacy_risk=0.45, copyright_risk=0.0, academic_reliability_risk=0.0,
    ), DEFAULT_CONFIG)
    assert result["decision"] == "needs_review"
