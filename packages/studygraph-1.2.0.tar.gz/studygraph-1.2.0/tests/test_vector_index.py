import json
from pathlib import Path

from studygraph.search_index import build_index
from studygraph.vector_index import build_vector_index


def _create_kb(tmp_path) -> Path:
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)

    docs = [
        {
            "source_id": "src_001",
            "filename": "Fourier.md",
            "course": "Analisi 1",
            "topic": "Serie di Fourier",
            "final_score": 0.85,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        },
        {
            "source_id": "src_002",
            "filename": "Limiti.md",
            "course": "Analisi 1",
            "topic": "Limiti di funzioni",
            "final_score": 0.78,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
        },
    ]

    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False)

    for d in docs:
        md_path = kb / d["markdown_path"]
        md_path.parent.mkdir(parents=True, exist_ok=True)
        topic_words = d["topic"].lower().replace(" ", "_")
        content = (
            f"---\nsource_id: {d['source_id']}\n---\n\n"
            f"# {d['topic']}\n\n"
            f"Questo documento riguarda {d['topic']}. "
            + " ".join([f"{topic_words}_{i}" for i in range(100)])
        )
        md_path.write_text(content, encoding="utf-8")

    return kb


def _config():
    return {
        "embedding": {
            "provider": "mock",
            "dimensions": 384,
            "model": "",
            "base_url": "",
            "api_key_env": "STUDYGRAPH_EMBEDDING_API_KEY",
        },
        "api_key": None,
    }


def test_creates_vector_index_dir(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    stats = build_vector_index(str(kb), _config())
    assert Path(stats["index_dir"]).exists()


def test_embeddings_jsonl_valid(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    emb_path = kb / "vector_index" / "embeddings.jsonl"
    assert emb_path.exists()
    with open(emb_path, encoding="utf-8") as f:
        lines = [json.loads(line) for line in f if line.strip()]
    assert len(lines) > 0
    for rec in lines:
        assert "chunk_id" in rec
        assert "text" in rec
        assert "embedding" in rec
        assert len(rec["embedding"]) > 0


def test_vector_meta_valid(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    meta = json.loads((kb / "vector_index" / "vector_meta.json").read_text(encoding="utf-8"))
    assert "provider" in meta
    assert "dimensions" in meta
    assert "chunks" in meta
    assert "created" in meta


def test_provider_json_valid(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    prov = json.loads((kb / "vector_index" / "provider.json").read_text(encoding="utf-8"))
    assert prov["provider"] == "mock"


def test_embedding_count_matches_chunks(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    meta = json.loads((kb / "vector_index" / "vector_meta.json").read_text(encoding="utf-8"))
    chunks_path = kb / "search_index" / "chunks.jsonl"
    chunk_count = sum(1 for _ in open(chunks_path, encoding="utf-8") if _.strip())
    assert meta["chunks"] == chunk_count


def test_force_overwrites(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    meta1 = json.loads((kb / "vector_index" / "vector_meta.json").read_text(encoding="utf-8"))
    build_vector_index(str(kb), _config(), force=True)
    meta2 = json.loads((kb / "vector_index" / "vector_meta.json").read_text(encoding="utf-8"))
    assert meta2["chunks"] == meta1["chunks"]


def test_missing_search_index_raises(tmp_path):
    kb = _create_kb(tmp_path)
    import pytest
    with pytest.raises(FileNotFoundError, match="index-kb"):
        build_vector_index(str(kb), _config())


def test_empty_kb_handled(tmp_path):
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)
    json.dump([], open(kb / "catalog.json", "w", encoding="utf-8"))
    build_index(str(kb))
    stats = build_vector_index(str(kb), _config())
    assert stats["chunks"] == 0
