from studygraph.embeddings import embed_texts


def _config(provider="mock", dimensions=384):
    return {
        "embedding": {
            "provider": provider,
            "dimensions": dimensions,
            "model": "",
            "base_url": "",
            "api_key_env": "STUDYGRAPH_EMBEDDING_API_KEY",
        },
        "api_key": None,
    }


def test_mock_is_deterministic():
    cfg = _config()
    v1 = embed_texts(["serie di Fourier"], cfg)
    v2 = embed_texts(["serie di Fourier"], cfg)
    assert v1 == v2


def test_different_texts_different_vectors():
    cfg = _config()
    v1 = embed_texts(["serie di Fourier"], cfg)
    v2 = embed_texts(["ricetta carbonara"], cfg)
    assert v1 != v2


def test_mock_embedding_dimensions():
    for dims in [64, 128, 384, 768]:
        cfg = _config(dimensions=dims)
        vecs = embed_texts(["test"], cfg)
        assert len(vecs[0]) == dims


def test_empty_list_returns_empty():
    cfg = _config()
    assert embed_texts([], cfg) == []


def test_dry_run_uses_mock():
    cfg = _config()
    v1 = embed_texts(["hello world"], cfg, dry_run=True)
    v2 = embed_texts(["hello world"], cfg, dry_run=True)
    assert v1 == v2


def test_single_text_returns_single_vector():
    cfg = _config()
    vecs = embed_texts(["unico testo"], cfg)
    assert len(vecs) == 1


def test_multiple_texts_all_have_embeddings():
    cfg = _config()
    texts = ["a", "b", "c"]
    vecs = embed_texts(texts, cfg)
    assert len(vecs) == 3
    assert all(len(v) == 384 for v in vecs)



