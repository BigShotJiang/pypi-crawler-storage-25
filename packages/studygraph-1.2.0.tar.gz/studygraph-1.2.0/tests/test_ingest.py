from pathlib import Path

from studygraph.ingest import ingest


def _write_dummy_pdf(path: Path):
    path.write_bytes(b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n")


def test_empty_dir(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    result = ingest(str(input_dir), str(raw_dir), sources_path)
    assert result == []


def test_single_pdf(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    pdf = input_dir / "doc.pdf"
    _write_dummy_pdf(pdf)

    result = ingest(str(input_dir), str(raw_dir), sources_path)
    assert len(result) == 1
    assert result[0]["filename"] == "doc.pdf"
    assert result[0]["source_id"] == "src_001"
    assert len(result[0]["hash"]) == 64
    assert Path(result[0]["raw_path"]).exists()


def test_two_pdfs(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    _write_dummy_pdf(input_dir / "doc_a.pdf")
    _write_dummy_pdf(input_dir / "doc_b.pdf")

    result = ingest(str(input_dir), str(raw_dir), sources_path)
    assert len(result) == 2
    ids = [r["source_id"] for r in result]
    assert "src_001" in ids
    assert "src_002" in ids


def test_second_run_no_duplicates(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    pdf = input_dir / "doc.pdf"
    _write_dummy_pdf(pdf)

    first = ingest(str(input_dir), str(raw_dir), sources_path)
    assert len(first) == 1

    second = ingest(str(input_dir), str(raw_dir), sources_path)
    assert len(second) == 0


def test_non_pdf_excluded(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    _write_dummy_pdf(input_dir / "doc.pdf")
    (input_dir / "image.jpg").write_text("not a pdf")
    (input_dir / "readme.txt").write_text("hello")

    result = ingest(str(input_dir), str(raw_dir), sources_path)
    assert len(result) == 1
    assert result[0]["filename"] == "doc.pdf"


def test_course_name_saved(tmp_path):
    input_dir = tmp_path / "input"
    raw_dir = tmp_path / "raw"
    sources_path = str(tmp_path / "sources.jsonl")
    input_dir.mkdir()

    _write_dummy_pdf(input_dir / "doc.pdf")

    result = ingest(str(input_dir), str(raw_dir), sources_path, course="Analisi 1")
    assert len(result) == 1
    assert result[0]["course"] == "Analisi 1"
