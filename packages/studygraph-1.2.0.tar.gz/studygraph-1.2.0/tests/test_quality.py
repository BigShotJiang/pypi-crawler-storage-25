from studygraph.quality import score_text_quality


def test_empty_text():
    result = score_text_quality("")
    assert result["text_quality_score"] == 0.0
    assert result["char_count"] == 0
    assert result["noise_ratio"] == 1.0


def test_whitespace_only():
    result = score_text_quality("   \n\t  ")
    assert result["text_quality_score"] == 0.0


def test_normal_italian_text():
    text = (
        "Il teorema di Lagrange afferma che se una funzione f è continua "
        "nell'intervallo chiuso [a,b] e derivabile nell'intervallo aperto (a,b), "
        "allora esiste almeno un punto c in (a,b) tale che la derivata prima "
        "in c è uguale al rapporto incrementale. Questo risultato è fondamentale "
        "per lo studio delle funzioni e delle loro proprietà. "
        "La dimostrazione si basa sul teorema di Rolle e sul concetto di "
        "funzione ausiliaria. La formula di Taylor è un'estensione naturale "
        "del teorema di Lagrange e permette di approssimare funzioni "
        "con polinomi di grado arbitrario. "
    ) * 3
    result = score_text_quality(text)
    assert result["text_quality_score"] > 0.7
    assert result["char_count"] > 100


def test_high_noise():
    text = "@#$%^&*()_+{}|:\"<>?~`!@#$%^&*()"
    result = score_text_quality(text)
    assert result["text_quality_score"] < 0.3
    assert result["noise_ratio"] > 0.3


def test_alphanumeric_only():
    text = "abc123 def456 ghi789 jkl012 mno345"
    result = score_text_quality(text)
    assert result["text_quality_score"] > 0.8
    assert result["noise_ratio"] == 0.0


def test_mixed_content():
    text = "Ciao mondo! Questa è una frase con 123 numeri e simboli @#$."
    result = score_text_quality(text)
    assert 0.3 < result["text_quality_score"] < 1.0


def test_extraction_warning_from_low_quality():
    text = "@#$%^&*()_+{}|:\"<>?~"
    result = score_text_quality(text)
    assert result["extraction_warning"] is True


def test_extraction_warning_from_scanned_meta():
    text = "Some valid text " * 20
    meta = {"is_probably_scanned": True, "empty_pages_ratio": 0.0}
    result = score_text_quality(text, extraction_meta=meta)
    assert result["extraction_warning"] is True


def test_extraction_warning_from_empty_pages():
    text = "Valid " * 100
    meta = {"is_probably_scanned": False, "empty_pages_ratio": 0.60}
    result = score_text_quality(text, extraction_meta=meta)
    assert result["extraction_warning"] is True


def test_no_extraction_warning_on_good_text():
    text = "This is good quality text with alphanumeric content 123." * 10
    meta = {"is_probably_scanned": False, "empty_pages_ratio": 0.0}
    result = score_text_quality(text, extraction_meta=meta)
    assert result["text_quality_score"] > 0.35
    assert result["extraction_warning"] is False


def test_extraction_warning_with_no_meta():
    text = "Good text " * 100
    result = score_text_quality(text)
    assert result["extraction_warning"] is False
