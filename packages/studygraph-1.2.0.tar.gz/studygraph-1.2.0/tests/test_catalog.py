import json
from pathlib import Path

from studygraph.catalog import generate_catalog, _filter_documents, _build_record


def _doc(source_id: str, decision: str, topic: str = "") -> dict:
    return {
        "source_id": source_id,
        "filename": f"{source_id}.pdf",
        "course": "Analisi 1",
        "topic": topic,
        "final_decision": decision,
        "suggested_decision": decision,
        "final_score": 0.7,
        "language": "it",
        "page_count": 5,
        "char_count": 1500,
        "text_quality_score": 0.8,
    }


def test_catalog_json_created(tmp_path):
    docs = [_doc("src_001", "candidate"), _doc("src_002", "needs_review")]
    generate_catalog(docs, str(tmp_path))
    json_path = tmp_path / "catalog.json"
    assert json_path.exists()
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert len(data) == 2
    assert data[0]["source_id"] == "src_001"
    assert data[1]["source_id"] == "src_002"


def test_catalog_csv_created(tmp_path):
    docs = [_doc("src_001", "candidate")]
    generate_catalog(docs, str(tmp_path))
    csv_path = tmp_path / "catalog.csv"
    assert csv_path.exists()
    content = csv_path.read_text(encoding="utf-8")
    assert "source_id" in content
    assert "src_001" in content


def test_catalog_excludes_rejected(tmp_path):
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "reject"),
    ]
    generate_catalog(docs, str(tmp_path))
    data = json.loads((tmp_path / "catalog.json").read_text(encoding="utf-8"))
    assert len(data) == 1
    assert data[0]["source_id"] == "src_001"


def test_catalog_excludes_private_only(tmp_path):
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "private_only"),
    ]
    generate_catalog(docs, str(tmp_path))
    data = json.loads((tmp_path / "catalog.json").read_text(encoding="utf-8"))
    assert len(data) == 1


def test_catalog_excludes_duplicate(tmp_path):
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "duplicate"),
    ]
    generate_catalog(docs, str(tmp_path))
    data = json.loads((tmp_path / "catalog.json").read_text(encoding="utf-8"))
    assert len(data) == 1


def test_catalog_paths_are_relative(tmp_path):
    docs = [_doc("src_001", "candidate", topic="Fourier")]
    generate_catalog(docs, str(tmp_path))
    data = json.loads((tmp_path / "catalog.json").read_text(encoding="utf-8"))
    rec = data[0]
    assert rec["markdown_path"].startswith("courses/")
    assert rec["source_pdf_path"].startswith("data/output/")


def test_catalog_source_pdf_path_matches_export_folders(tmp_path):
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
    ]
    generate_catalog(docs, str(tmp_path))
    data = json.loads((tmp_path / "catalog.json").read_text(encoding="utf-8"))
    assert data[0]["source_pdf_path"].startswith("data/output/candidates/")
    assert data[1]["source_pdf_path"].startswith("data/output/needs_review/")


def test_filter_documents_only_candidates():
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
        _doc("src_003", "reject"),
    ]
    filtered = _filter_documents(docs, only_candidates=True)
    assert len(filtered) == 1
    assert filtered[0]["source_id"] == "src_001"


def test_global_index_created(tmp_path):
    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
        _doc("src_003", "reject"),
    ]
    generate_catalog(docs, str(tmp_path))
    idx_path = tmp_path / "global_index.md"
    assert idx_path.exists()
    content = idx_path.read_text(encoding="utf-8")
    assert "Analisi 1" in content
    assert "Esclusi (reject)" in content
