from studygraph.canonicalize import canonicalize


def _doc(overrides: dict | None = None) -> dict:
    base = {
        "source_id": "src_001",
        "filename": "doc.pdf",
        "course": "Analisi 1",
        "topic": "Serie di Fourier",
        "final_decision": "candidate",
        "final_score": 0.7,
        "language": "it",
        "page_count": 5,
        "char_count": 1500,
        "text_quality_score": 0.8,
    }
    if overrides:
        base.update(overrides)
    return base


def test_empty_markdown():
    result = canonicalize("", _doc())
    assert "source_id: src_001" in result["text"]
    assert "too_short" in result["warnings"]


def test_normalize_headings():
    text = "#Heading\n##Subheading\nNo heading here"
    result = canonicalize(text, _doc())
    assert "# Heading" in result["text"]
    assert "## Subheading" in result["text"]
    assert "No heading here" in result["text"]


def test_collapse_whitespace():
    text = "Line 1\n\n\n\n\nLine 2\n\n\nLine 3"
    result = canonicalize(text, _doc())
    assert "\n\n\n" not in result["text"]
    assert "Line 1\n\nLine 2" in result["text"] or "Line 1\n\nLine 2" in result["text"]


def test_preserves_frontmatter():
    text = "---\nold_field: value\n---\n\nBody content"
    result = canonicalize(text, _doc())
    assert "source_id: src_001" in result["text"]
    assert "Body content" in result["text"]


def test_adds_heading_when_missing():
    text = "Just some body text without headings"
    result = canonicalize(text, _doc({"topic": "Fourier"}))
    assert "# Fourier" in result["text"]
    assert "Just some body text" in result["text"]


def test_flag_too_short():
    result = canonicalize("Short", _doc())
    assert "too_short" in result["warnings"]


def test_normal_length_no_warning():
    text = "A" * 500
    result = canonicalize(text, _doc())
    assert "too_short" not in result["warnings"]
