from click.testing import CliRunner

from studygraph.cli import main


def test_help():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "ask-kb" in result.output


def test_ask_kb_help():
    runner = CliRunner()
    result = runner.invoke(main, ["ask-kb", "--help"])
    assert result.exit_code == 0
    assert "QUESTION" in result.output
    assert "mode" in result.output


def test_ask_alias_help():
    runner = CliRunner()
    result = runner.invoke(main, ["ask", "--help"])
    assert result.exit_code == 0
    assert "QUESTION" in result.output
    assert "mode" in result.output


def test_ask_kb_dry_run_integration_lexical(tmp_path):
    import json
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "La serie di Fourier rappresenta una funzione periodica come somma di seni e coseni. " * 10,
        encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    result = runner.invoke(main, [
        "ask-kb", "Che cos'è una serie di Fourier?",
        "--kb-dir", str(kb_dir),
        "--mode", "lexical",
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Domanda" in result.output


def test_ask_kb_dry_run_integration_hybrid(tmp_path):
    import json
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "La serie di Fourier rappresenta una funzione periodica come somma di seni e coseni. " * 10,
        encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    from studygraph.vector_index import build_vector_index
    build_vector_index(str(kb_dir), {
        "embedding": {"provider": "mock", "dimensions": 384, "model": "",
                       "base_url": "", "api_key_env": ""},
        "api_key": None,
    }, dry_run=True)

    result = runner.invoke(main, [
        "ask-kb", "serie di Fourier",
        "--kb-dir", str(kb_dir),
        "--mode", "hybrid",
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Domanda" in result.output or "serie" in result.output


def test_ask_kb_json_output(tmp_path):
    import json
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    result = runner.invoke(main, [
        "ask-kb", "serie",
        "--kb-dir", str(kb_dir),
        "--mode", "lexical",
        "--dry-run",
        "--json",
    ])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "answer" in data
    assert "answer_type" in data


def test_ask_kb_missing_index_gives_error(tmp_path):
    runner = CliRunner()
    result = runner.invoke(main, [
        "ask-kb", "domanda",
        "--kb-dir", str(tmp_path),
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Errore" in result.output or "no_answer" in result.output.lower() or "non" in result.output.lower()



def test_search_kb_missing_index(tmp_path):
    runner = CliRunner()
    result = runner.invoke(main, [
        "search-kb", "test",
        "--kb-dir", str(tmp_path),
    ])
    assert result.exit_code == 0 or "Nessun risultato" in result.output


def test_embed_kb_help():
    runner = CliRunner()
    result = runner.invoke(main, ["embed-kb", "--help"])
    assert result.exit_code == 0
    assert "KB_DIR" in result.output


def test_embed_kb_integration_mock(tmp_path):
    import json

    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    result = runner.invoke(main, ["embed-kb", str(kb_dir), "--dry-run"])
    assert result.exit_code == 0
    assert "Knowledge base embedded" in result.output
    assert (kb_dir / "vector_index").exists()
    assert (kb_dir / "vector_index" / "embeddings.jsonl").exists()
    assert (kb_dir / "vector_index" / "vector_meta.json").exists()


def test_search_kb_mode_semantic_integration(tmp_path):
    import json

    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    from studygraph.vector_index import build_vector_index
    build_vector_index(str(kb_dir), {
        "embedding": {"provider": "mock", "dimensions": 384, "model": "",
                       "base_url": "", "api_key_env": ""},
        "api_key": None,
    }, dry_run=True)

    result = runner.invoke(main, [
        "search-kb", "serie",
        "--kb-dir", str(kb_dir),
        "--mode", "semantic",
        "--dry-run",
    ])
    assert result.exit_code == 0 or "Nessun risultato" in result.output


def test_search_kb_mode_hybrid_integration(tmp_path):
    import json

    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    from studygraph.vector_index import build_vector_index
    build_vector_index(str(kb_dir), {
        "embedding": {"provider": "mock", "dimensions": 384, "model": "",
                       "base_url": "", "api_key_env": ""},
        "api_key": None,
    }, dry_run=True)

    result = runner.invoke(main, [
        "search-kb", "serie",
        "--kb-dir", str(kb_dir),
        "--mode", "hybrid",
        "--dry-run",
    ])
    assert result.exit_code == 0 or "Nessun risultato" in result.output


def test_search_kb_semantic_missing_vector_index(tmp_path):
    import json

    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    result = runner.invoke(main, [
        "search-kb", "serie",
        "--kb-dir", str(kb_dir),
        "--mode", "semantic",
    ])
    assert result.exit_code == 0 or "Nessun risultato" in result.output


def test_search_kb_mode_lexical_default_still_works(tmp_path):
    import json

    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)

    catalog = [{
        "source_id": "src_001", "filename": "Fourier.md",
        "course": "Analisi 1", "topic": "Serie di Fourier",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    md_path = kb_dir / "courses" / "Analisi_1" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Fourier.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Serie di Fourier\n\n"
        + "serie fourier parola " * 50, encoding="utf-8")

    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    result = runner.invoke(main, [
        "search-kb", "Fourier",
        "--kb-dir", str(kb_dir),
    ])
    assert result.exit_code == 0
    assert "Fourier" in result.output or "serie" in result.output.lower()


def test_evaluate_retrieval_help():
    runner = CliRunner()
    result = runner.invoke(main, ["evaluate-retrieval", "--help"])
    assert result.exit_code == 0
    assert "KB_DIR" in result.output
    assert "DATASET" in result.output


def test_evaluate_qa_help():
    runner = CliRunner()
    result = runner.invoke(main, ["evaluate-qa", "--help"])
    assert result.exit_code == 0
    assert "KB_DIR" in result.output
    assert "DATASET" in result.output


def test_evaluate_retrieval_integration(tmp_path):
    import json
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)
    catalog = [{
        "source_id": "src_001", "filename": "Doc.pdf",
        "course": "Corso", "topic": "Argomento",
        "markdown_path": "courses/Corso/documents/Doc.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)
    md_path = kb_dir / "courses" / "Corso" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Doc.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Argomento\n\n"
        + "test parola " * 50, encoding="utf-8")
    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    ds_path = tmp_path / "questions.json"
    questions = [{"id": "q_001", "question": "test", "course": "Corso",
                   "expected_sources": ["Doc.pdf"], "expected_behavior": "answered"}]
    with open(ds_path, "w", encoding="utf-8") as f:
        json.dump(questions, f)

    result = runner.invoke(main, [
        "evaluate-retrieval", str(kb_dir), str(ds_path),
        "--modes", "lexical",
        "--output-dir", str(tmp_path / "out"),
    ])
    assert result.exit_code == 0
    assert "Valutazione retrieval completata" in result.output


def test_evaluate_qa_integration(tmp_path):
    import json
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)
    catalog = [{
        "source_id": "src_001", "filename": "Doc.pdf",
        "course": "Corso", "topic": "Argomento",
        "markdown_path": "courses/Corso/documents/Doc.md",
        "final_score": 0.85, "language": "it",
    }]
    with open(kb_dir / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)
    md_path = kb_dir / "courses" / "Corso" / "documents"
    md_path.mkdir(parents=True)
    (md_path / "Doc.md").write_text(
        "---\nsource_id: src_001\n---\n\n# Argomento\n\n"
        + "test parola " * 50, encoding="utf-8")
    from studygraph.search_index import build_index
    build_index(str(kb_dir))

    ds_path = tmp_path / "questions.json"
    questions = [{"id": "q_001", "question": "test", "course": "Corso",
                   "expected_sources": ["Doc.pdf"], "expected_behavior": "answered"}]
    with open(ds_path, "w", encoding="utf-8") as f:
        json.dump(questions, f)

    result = runner.invoke(main, [
        "evaluate-qa", str(kb_dir), str(ds_path),
        "--mode", "lexical",
        "--dry-run",
        "--output-dir", str(tmp_path / "out"),
    ])
    assert result.exit_code == 0
    assert "Valutazione QA completata" in result.output


def test_evaluate_missing_dataset_gives_error(tmp_path):
    runner = CliRunner()
    kb_dir = tmp_path / "kb"
    kb_dir.mkdir(parents=True)
    result = runner.invoke(main, [
        "evaluate-retrieval", str(kb_dir), str(tmp_path / "nonexistent.json"),
    ])
    assert result.exit_code != 0 or "FileNotFoundError" in result.output or "Error" in result.output


def test_demo_help():
    runner = CliRunner()
    result = runner.invoke(main, ["demo", "--help"])
    assert result.exit_code == 0
    assert "output-dir" in result.output


def test_build_help():
    runner = CliRunner()
    result = runner.invoke(main, ["build", "--help"])
    assert result.exit_code == 0
    assert "dry-run" in result.output
    assert "course" in result.output


def test_demo_dry_run(tmp_path):
    runner = CliRunner()
    from studygraph.demo import run_demo

    steps = run_demo(output_dir=str(tmp_path / "demo"))
    assert "kb" in steps
    assert "index" in steps
    assert "embed" in steps
    assert "retrieval" in steps
    assert "qa" in steps
    assert "ask" in steps
    assert steps["ask"]["answer_type"] in ("answered", "no_answer")
    assert steps["kb"]["exported"] == 3


def test_web_help():
    runner = CliRunner()
    result = runner.invoke(main, ["web", "--help"])
    assert result.exit_code == 0
    assert "port" in result.output
