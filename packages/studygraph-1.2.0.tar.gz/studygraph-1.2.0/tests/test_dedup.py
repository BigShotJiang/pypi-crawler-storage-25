from studygraph.dedup import compute_duplication_scores


def _src(sid, hash_val="aaa", name="file.pdf"):
    return {"source_id": sid, "hash": hash_val, "filename": name}


def test_same_hash_duplicate():
    sources = [_src("s1", "abc123", "doc1.pdf"), _src("s2", "abc123", "doc2.pdf")]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 1.0
    assert scores["s2"] == 1.0


def test_similar_name_no_hash_match():
    sources = [_src("s1", "aaa", "Lezione_1_introduzione.pdf"),
               _src("s2", "bbb", "Lezione-1-introduzione.pdf")]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 0.6
    assert scores["s2"] == 0.6


def test_different_documents():
    sources = [_src("s1", "aaa", "doc_a.pdf"), _src("s2", "bbb", "doc_b.pdf")]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 0.0
    assert scores["s2"] == 0.0


def test_empty_list():
    scores = compute_duplication_scores([])
    assert scores == {}


def test_single_source():
    sources = [_src("s1", "abc123", "only.pdf")]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 0.0


def test_three_sources_two_duplicates():
    sources = [
        _src("s1", "xxx", "a.pdf"),
        _src("s2", "xxx", "b.pdf"),
        _src("s3", "yyy", "c.pdf"),
    ]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 1.0
    assert scores["s2"] == 1.0
    assert scores["s3"] == 0.0


def test_no_hash_in_source():
    sources = [{"source_id": "s1", "filename": "no_hash.pdf"}]
    scores = compute_duplication_scores(sources)
    assert scores["s1"] == 0.0


def test_text_similarity_bonus(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "s1.txt").write_text("abcdefghij" * 100, encoding="utf-8")
    (extracted / "s2.txt").write_text("abcdefghij" * 100, encoding="utf-8")

    sources = [
        {"source_id": "s1", "hash": "aaa", "filename": "doc_a.pdf"},
        {"source_id": "s2", "hash": "bbb", "filename": "doc_b.pdf"},
    ]
    scores = compute_duplication_scores(sources, extracted_dir=str(extracted))
    assert scores["s1"] >= 0.70
    assert scores["s2"] >= 0.70


def test_different_text_no_bonus(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "s1.txt").write_text("abcdefghij" * 100, encoding="utf-8")
    (extracted / "s2.txt").write_text("zyxwvutsrq" * 100, encoding="utf-8")

    sources = [
        {"source_id": "s1", "hash": "aaa", "filename": "quantum_physics.pdf"},
        {"source_id": "s2", "hash": "bbb", "filename": "literature_review.pdf"},
    ]
    scores = compute_duplication_scores(sources, extracted_dir=str(extracted))
    assert scores["s1"] == 0.0
    assert scores["s2"] == 0.0


def test_hash_match_wins_over_text_similarity(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    (extracted / "s1.txt").write_text("abcdefghij" * 100, encoding="utf-8")
    (extracted / "s2.txt").write_text("abcdefghij" * 100, encoding="utf-8")

    sources = [
        {"source_id": "s1", "hash": "xxx", "filename": "a.pdf"},
        {"source_id": "s2", "hash": "xxx", "filename": "b.pdf"},
    ]
    scores = compute_duplication_scores(sources, extracted_dir=str(extracted))
    assert scores["s1"] == 1.0
    assert scores["s2"] == 1.0


def test_similar_name_and_char_count(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    content = "Page content about limits and derivatives " * 20
    (extracted / "s1.txt").write_text(content, encoding="utf-8")
    (extracted / "s2.txt").write_text(content, encoding="utf-8")

    sources = [
        {"source_id": "s1", "hash": "aaa", "filename": "Lezione_1_Limiti.pdf"},
        {"source_id": "s2", "hash": "bbb", "filename": "Lezione 1 Limiti v2.pdf"},
    ]
    scores = compute_duplication_scores(sources, extracted_dir=str(extracted))
    assert scores["s1"] >= 0.70
    assert scores["s2"] >= 0.70
