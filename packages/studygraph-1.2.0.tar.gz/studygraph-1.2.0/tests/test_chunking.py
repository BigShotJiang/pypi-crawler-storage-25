from studygraph.chunking import chunk_markdown


def _metadata(source_id="src_001", topic="Fourier"):
    return {
        "source_id": source_id,
        "filename": f"{source_id}.md",
        "course": "Analisi 1",
        "topic": topic,
        "markdown_path": f"courses/Analisi_1/documents/{source_id}.md",
    }


def test_short_text_single_chunk():
    text = "Breve contenuto di esempio."
    chunks = chunk_markdown(text, _metadata(), chunk_size=1000)
    assert len(chunks) == 1
    assert chunks[0]["source_id"] == "src_001"


def test_long_text_multiple_chunks():
    text = "# Titolo\n\n" + "\n\n".join([f"Paragrafo {i} con contenuto ripetuto per riempimento." for i in range(50)])
    chunks = chunk_markdown(text, _metadata(), chunk_size=500)
    assert len(chunks) >= 2


def test_too_short_excluded():
    text = "a"
    chunks = chunk_markdown(text, _metadata(), min_chars=100)
    assert len(chunks) == 0


def test_chunk_preserves_metadata():
    text = "# Serie\n\nContenuto della serie di Fourier.\n\nSecondo paragrafo."
    chunks = chunk_markdown(text, _metadata())
    assert len(chunks) >= 1
    c = chunks[0]
    assert c["source_id"] == "src_001"
    assert c["course"] == "Analisi 1"
    assert c["topic"] == "Fourier"
    assert c["markdown_path"] == "courses/Analisi_1/documents/src_001.md"


def test_heading_preserved():
    text = "# Titolo Principale\n\nContenuto sotto il titolo.\n\n## Sottoheading\n\nAltro contenuto."
    chunks = chunk_markdown(text, _metadata(), chunk_size=2000)
    assert len(chunks) == 1
    assert chunks[0]["heading"] == "Sottoheading"


def test_empty_text():
    chunks = chunk_markdown("", _metadata())
    assert chunks == []


def test_text_with_frontmatter():
    text = "---\nsource_id: src_001\n---\n\n# Titolo\n\nContenuto."
    chunks = chunk_markdown(text, _metadata(), chunk_size=1000)
    assert len(chunks) == 1
    assert "source_id: src_001" not in chunks[0]["text"]
    assert "Contenuto" in chunks[0]["text"]


def test_chunk_ids_are_unique():
    text = "# A\n\n" + "x\n\n" * 20 + "# B\n\n" + "y\n\n" * 20
    chunks = chunk_markdown(text, _metadata(), chunk_size=300)
    ids = [c["chunk_id"] for c in chunks]
    assert len(set(ids)) == len(ids)
    assert all(cid.startswith("src_001::") for cid in ids)
