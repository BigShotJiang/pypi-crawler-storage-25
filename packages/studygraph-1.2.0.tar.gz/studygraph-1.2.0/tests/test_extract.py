from pathlib import Path

import fitz
import pytest

from studygraph.extract import extract_text


def _make_pdf(path: Path, pages_data: list[str]):
    doc = fitz.open()
    for text in pages_data:
        page = doc.new_page()
        rect = fitz.Rect(72, 72, 540, 720)
        page.insert_textbox(rect, text, fontsize=11)
    doc.save(str(path))
    doc.close()


def test_extract_normal_text(tmp_path):
    pdf = tmp_path / "test.pdf"
    extracted = tmp_path / "extracted"
    _make_pdf(pdf, ["This is a test document with sufficient text content for analysis." * 10])

    result = extract_text(str(pdf), str(extracted), "src_001")
    assert result is not None
    assert result["num_pages"] == 1
    assert result["char_count"] > 200
    assert result["empty_pages"] == 0
    assert result["empty_pages_ratio"] == 0.0
    assert result["is_probably_scanned"] is False
    assert result["ocr_recommended"] is False


def test_empty_pages_detected(tmp_path):
    pdf = tmp_path / "test.pdf"
    extracted = tmp_path / "extracted"
    _make_pdf(pdf, [
        "Page 1 with content " * 50,
        "",
        "Page 3 with content " * 50,
    ])

    result = extract_text(str(pdf), str(extracted), "src_002")
    assert result is not None
    assert result["num_pages"] == 3
    assert result["empty_pages"] == 1
    assert result["empty_pages_ratio"] == pytest.approx(1 / 3, abs=0.1)


def test_mostly_empty_pdf_scanned(tmp_path):
    pdf = tmp_path / "test.pdf"
    extracted = tmp_path / "extracted"
    _make_pdf(pdf, [
        "x",
        "y",
        "z",
        "w",
    ])

    result = extract_text(str(pdf), str(extracted), "src_003")
    assert result is not None
    assert result["num_pages"] == 4
    assert result["char_count"] < 500
    assert result["is_probably_scanned"] is True
    assert result["ocr_recommended"] is True


def test_empty_pages_ratio_triggers_ocr(tmp_path):
    pdf = tmp_path / "test.pdf"
    extracted = tmp_path / "extracted"
    _make_pdf(pdf, [
        "Normal page with enough content to avoid scanned flag " * 10,
        "",
        "",
        "",
        "",
    ])

    result = extract_text(str(pdf), str(extracted), "src_004")
    assert result is not None
    assert result["num_pages"] == 5
    assert result["empty_pages_ratio"] > 0.50
    assert result["ocr_recommended"] is True


def test_char_count_per_page(tmp_path):
    pdf = tmp_path / "test.pdf"
    extracted = tmp_path / "extracted"
    _make_pdf(pdf, ["AAAA" * 25, "BBBB" * 25])

    result = extract_text(str(pdf), str(extracted), "src_005")
    assert result is not None
    assert result["num_pages"] == 2
    assert result["char_count_per_page"] > 50


def test_missing_file():
    result = extract_text("nonexistent.pdf", "extracted", "src_fake")
    assert result is None
