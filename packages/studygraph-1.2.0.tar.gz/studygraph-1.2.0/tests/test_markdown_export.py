from pathlib import Path

from studygraph.markdown_export import export_markdown


def _doc(sid: str, decision: str = "candidate", course: str = "Analisi_1", lang: str = "it") -> dict:
    return {
        "source_id": sid,
        "filename": f"{sid}.pdf",
        "course": course,
        "suggested_decision": decision,
        "final_decision": decision,
        "final_score": 0.7,
        "language": lang,
    }


def test_export_creates_course_subfolders(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate", "Analisi_1"), _doc("src_002", "candidate", "Programmazione")]
    for d in docs:
        (extracted / f"{d['source_id']}.txt").write_text("contenuto del documento", encoding="utf-8")

    export_markdown(docs, str(extracted), str(out_dir))
    assert (out_dir / "markdown" / "Analisi_1" / "src_001.md").exists()
    assert (out_dir / "markdown" / "Programmazione" / "src_002.md").exists()


def test_export_includes_frontmatter(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate", "Analisi_1")]
    (extracted / "src_001.txt").write_text("testo del documento", encoding="utf-8")

    export_markdown(docs, str(extracted), str(out_dir))
    md = (out_dir / "markdown" / "Analisi_1" / "src_001.md").read_text(encoding="utf-8")
    assert "---" in md
    assert "source_id: src_001" in md
    assert "final_decision: candidate" in md
    assert "score: 0.7" in md
    assert "language: it" in md
    assert "# src_001.pdf" in md
    assert "testo del documento" in md


def test_export_filters_by_decision(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
        _doc("src_003", "rejected"),
        _doc("src_004", "duplicate"),
        _doc("src_005", "private_only"),
    ]
    for d in docs:
        (extracted / f"{d['source_id']}.txt").write_text("text", encoding="utf-8")

    export_markdown(docs, str(extracted), str(out_dir))
    md_files = list((out_dir / "markdown" / "Analisi_1").rglob("*.md"))
    assert len(md_files) == 2
    assert any("src_001" in f.name for f in md_files)
    assert any("src_002" in f.name for f in md_files)


def test_export_missing_txt_skips(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate")]
    result = export_markdown(docs, str(extracted), str(out_dir))
    assert not (Path(result) / "Analisi_1").exists() or not (Path(result) / "Analisi_1").iterdir()


def test_export_empty_text_skips(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate")]
    (extracted / "src_001.txt").write_text("", encoding="utf-8")

    result = export_markdown(docs, str(extracted), str(out_dir))
    assert not list(Path(result).rglob("*.md"))


def test_export_sanitizes_course_name(tmp_path):
    extracted = tmp_path / "extracted"
    extracted.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate", "Analisi 1: Matematica")]
    (extracted / "src_001.txt").write_text("testo", encoding="utf-8")

    export_markdown(docs, str(extracted), str(out_dir))
    assert (out_dir / "markdown" / "Analisi_1__Matematica").exists()
