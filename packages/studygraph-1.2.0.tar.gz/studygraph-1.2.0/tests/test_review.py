import json
from pathlib import Path

from studygraph.review import load_review_decisions, apply_review_decisions


def _doc(sid: str, decision: str = "needs_review") -> dict:
    return {
        "source_id": sid,
        "filename": f"{sid}.pdf",
        "suggested_decision": decision,
        "final_score": 0.5,
        "course": "Test",
    }


def test_load_review_csv(tmp_path):
    csv_path = tmp_path / "reviews.csv"
    csv_path.write_text(
        "source_id,manual_decision,reviewer_note\n"
        "src_001,candidate,Buona dispensa\n"
        "src_002,rejected,PDF vuoto\n"
        "src_003,private_only,Contiene dati personali\n"
        "src_004,invalid,skip this\n",
        encoding="utf-8",
    )
    decisions = load_review_decisions(str(csv_path))
    assert len(decisions) == 3
    assert decisions[0] == {"source_id": "src_001", "manual_decision": "candidate", "reviewer_note": "Buona dispensa"}
    assert decisions[1] == {"source_id": "src_002", "manual_decision": "rejected", "reviewer_note": "PDF vuoto"}
    assert decisions[2] == {"source_id": "src_003", "manual_decision": "private_only", "reviewer_note": "Contiene dati personali"}


def test_apply_review_overrides_decision(tmp_path):
    docs = [_doc("src_001"), _doc("src_002")]
    reviews = [{"source_id": "src_001", "manual_decision": "candidate", "reviewer_note": "Good"}]
    docs_path = str(tmp_path / "documents.jsonl")

    result = apply_review_decisions(docs, reviews, docs_path)
    assert result[0]["manual_decision"] == "candidate"
    assert result[0]["final_decision"] == "candidate"
    assert result[0]["reviewer_note"] == "Good"
    assert result[1]["final_decision"] == "needs_review"


def test_apply_review_fallback_to_suggested(tmp_path):
    docs = [_doc("src_001", "reject")]
    docs_path = str(tmp_path / "documents.jsonl")
    result = apply_review_decisions(docs, [], docs_path)
    assert result[0]["final_decision"] == "reject"
    assert result[0]["manual_decision"] == ""


def test_apply_review_writes_jsonl(tmp_path):
    docs = [_doc("src_001")]
    reviews = [{"source_id": "src_001", "manual_decision": "candidate", "reviewer_note": "ok"}]
    docs_path = str(tmp_path / "documents.jsonl")
    apply_review_decisions(docs, reviews, docs_path)

    saved = json.loads(Path(docs_path).read_text(encoding="utf-8"))
    assert saved["final_decision"] == "candidate"
    assert saved["manual_decision"] == "candidate"


def test_apply_review_unknown_source_id_warns_no_crash(tmp_path):
    docs = [_doc("src_001")]
    reviews = [{"source_id": "nonexistent", "manual_decision": "candidate", "reviewer_note": ""}]
    docs_path = str(tmp_path / "documents.jsonl")
    result = apply_review_decisions(docs, reviews, docs_path)
    assert len(result) == 1
    assert result[0]["final_decision"] == "needs_review"


def test_apply_review_empty_csv(tmp_path):
    csv_path = tmp_path / "empty.csv"
    csv_path.write_text("source_id,manual_decision,reviewer_note\n", encoding="utf-8")
    decisions = load_review_decisions(str(csv_path))
    assert decisions == []


def test_load_review_csv_not_found(tmp_path):
    decisions = load_review_decisions(str(tmp_path / "nonexistent.csv"))
    assert decisions == []
