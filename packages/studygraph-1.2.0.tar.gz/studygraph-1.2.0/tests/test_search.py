import json
from pathlib import Path

from studygraph.search_index import build_index, tokenize
from studygraph.search import search


def _create_kb(tmp_path) -> Path:
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)

    docs = [
        {
            "source_id": "src_001",
            "filename": "Fourier.md",
            "course": "Analisi 1",
            "topic": "Serie di Fourier",
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
            "final_score": 0.85,
            "language": "it",
        },
        {
            "source_id": "src_002",
            "filename": "Limiti.md",
            "course": "Analisi 1",
            "topic": "Limiti di funzioni",
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
            "final_score": 0.78,
            "language": "it",
        },
        {
            "source_id": "src_003",
            "filename": "Derivate.md",
            "course": "Analisi 1",
            "topic": "Derivate",
            "markdown_path": "courses/Analisi_1/documents/Derivate.md",
            "final_score": 0.55,
            "language": "it",
        },
    ]

    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False)

    for d in docs:
        md_path = kb / d["markdown_path"]
        md_path.parent.mkdir(parents=True, exist_ok=True)
        topic_words = d["topic"].lower().replace(" ", "_")
        content = (
            f"---\nsource_id: {d['source_id']}\n---\n\n"
            f"# {d['topic']}\n\n"
            f"Questo documento riguarda {d['topic']}. "
            + " ".join([f"{topic_words}_{i}" for i in range(100)])
        )
        md_path.write_text(content, encoding="utf-8")

    return kb


def test_search_finds_relevant_document(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"))
    assert len(results) > 0
    assert results[0]["topic"] == "Serie di Fourier"


def test_results_sorted_by_score(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"), top_k=10)
    for i in range(len(results) - 1):
        assert results[i]["score"] >= results[i + 1]["score"]


def test_course_filter_works(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"), course="Fisica")
    assert len(results) == 0


def test_empty_query_returns_empty(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("", str(kb / "search_index"))
    assert results == []


def test_nonexistent_term_returns_empty(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("xyznonexistent123", str(kb / "search_index"))
    assert results == []


def test_snippet_contains_query_term(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"))
    for r in results:
        assert "fourier" in r["snippet"].lower()


def test_json_output_serializable(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"))
    json.dumps(results, ensure_ascii=False)


def test_search_returns_metadata(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = search("Fourier", str(kb / "search_index"))
    assert len(results) > 0
    r = results[0]
    assert "chunk_id" in r
    assert "source_id" in r
    assert "filename" in r
    assert "course" in r
    assert "markdown_path" in r
