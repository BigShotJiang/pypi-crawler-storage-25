import os

from studygraph.eval_report import write_retrieval_report, write_qa_report


def _retrieval_result():
    return {
        "summary": {
            "lexical": {
                "top1_accuracy": 0.75, "top3_hit_rate": 0.88, "mrr": 0.80,
                "source_hit_rate": 0.85, "no_result_correctness": 1.0, "avg_time_ms": 2.0,
                "total_queries": 4,
            },
        },
        "results": [
            {
                "mode": "lexical", "question_id": "q_001", "question": "Fourier",
                "expected_behavior": "answered", "top1_hit": True, "top3_hit": True,
                "source_hit": 1.0, "no_result_correctness": None,
                "time_ms": 1.5, "result_count": 5, "result_filenames": ["Fourier.pdf"],
            },
        ],
        "meta": {"modes": ["lexical"], "top_k": 5, "dry_run": True, "total_questions": 4},
    }


def _qa_result():
    return {
        "summary": {
            "answer_type_accuracy": 0.85, "no_answer_accuracy": 0.9,
            "citation_validity_rate": 1.0, "expected_terms_hit_rate": 0.74,
            "source_recall": 0.81, "invalid_citation_count": 0, "needs_review_count": 2,
            "total_queries": 10,
        },
        "results": [
            {
                "question_id": "q_001", "question": "Fourier",
                "expected_behavior": "answered", "actual_answer_type": "answered",
                "behavior_match": True, "citation_valid": True,
                "expected_terms_hit": ["seni"], "expected_terms_miss": [],
                "sources_found": ["Fourier.pdf"], "sources_missed": [],
                "confidence": 0.3, "answer_snippet": "Risposta di esempio.",
            },
        ],
        "meta": {"mode": "hybrid", "top_k": 5, "dry_run": True, "total_questions": 10},
    }


def test_writes_retrieval_json(tmp_path):
    out = str(tmp_path)
    write_retrieval_report(_retrieval_result(), out)
    assert os.path.isfile(os.path.join(out, "retrieval_eval.json"))


def test_writes_retrieval_csv(tmp_path):
    out = str(tmp_path)
    write_retrieval_report(_retrieval_result(), out)
    assert os.path.isfile(os.path.join(out, "retrieval_eval.csv"))


def test_writes_retrieval_md(tmp_path):
    out = str(tmp_path)
    write_retrieval_report(_retrieval_result(), out)
    assert os.path.isfile(os.path.join(out, "retrieval_eval.md"))


def test_writes_qa_json(tmp_path):
    out = str(tmp_path)
    write_qa_report(_qa_result(), out)
    assert os.path.isfile(os.path.join(out, "qa_eval.json"))


def test_writes_qa_csv(tmp_path):
    out = str(tmp_path)
    write_qa_report(_qa_result(), out)
    assert os.path.isfile(os.path.join(out, "qa_eval.csv"))


def test_writes_qa_md(tmp_path):
    out = str(tmp_path)
    write_qa_report(_qa_result(), out)
    assert os.path.isfile(os.path.join(out, "qa_eval.md"))


def test_metrics_aggregated_in_report(tmp_path):
    out = str(tmp_path)
    paths = write_retrieval_report(_retrieval_result(), out)
    import json
    with open(paths["json"], encoding="utf-8") as f:
        data = json.load(f)
    assert "summary" in data
    assert "lexical" in data["summary"]
    assert data["summary"]["lexical"]["top1_accuracy"] == 0.75
