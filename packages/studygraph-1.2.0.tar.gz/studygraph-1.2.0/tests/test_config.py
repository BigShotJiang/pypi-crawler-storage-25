import os
import tempfile
from copy import deepcopy
from pathlib import Path
from unittest import mock

import pytest

from studygraph import config as config_module


@pytest.fixture(autouse=True)
def clean_env():
    keys = [
        "STUDYGRAPH_API_KEY", "STUDYGRAPH_LLM_BASE_URL", "STUDYGRAPH_LLM_MODEL",
        "STUDYGRAPH_EMBEDDING_BASE_URL", "STUDYGRAPH_EMBEDDING_MODEL",
        "STUDYGRAPH_QA_BASE_URL", "STUDYGRAPH_QA_MODEL",
    ]
    saved = {k: os.environ.pop(k, None) for k in keys}

    env_local = Path(".env.local")
    env_backup = Path(".env.local.bak")
    renamed = False
    if env_local.exists():
        env_local.rename(env_backup)
        renamed = True

    yield

    for k, v in saved.items():
        if v is not None:
            os.environ[k] = v
        else:
            os.environ.pop(k, None)

    if renamed:
        env_backup.rename(env_local)
    elif env_local.exists():
        env_local.unlink()


def test_default_no_env_no_yaml():
    cfg = config_module.load_config()
    assert cfg["api_key"] is None
    assert cfg["llm"]["model"] == "gpt-4o-mini"
    assert cfg["llm"]["base_url"] == "https://api.openai.com/v1"
    assert cfg["scoring"]["candidate_threshold"] == 0.75


def test_api_key_from_env():
    os.environ["STUDYGRAPH_API_KEY"] = "test-key-123"
    cfg = config_module.load_config()
    assert cfg["api_key"] == "test-key-123"


def test_base_url_from_env():
    os.environ["STUDYGRAPH_LLM_BASE_URL"] = "https://custom.api/v1/"
    cfg = config_module.load_config()
    assert cfg["llm"]["base_url"] == "https://custom.api/v1"


def test_yaml_base_url_normalized():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("llm:\n  base_url: https://custom.api/v1/chat/completions\n")
        yaml_path = f.name

    try:
        cfg = config_module.load_config(yaml_path)
        assert cfg["llm"]["base_url"] == "https://custom.api/v1"
    finally:
        Path(yaml_path).unlink(missing_ok=True)


def test_model_from_env():
    os.environ["STUDYGRAPH_LLM_MODEL"] = "gemini-flash"
    cfg = config_module.load_config()
    assert cfg["llm"]["model"] == "gemini-flash"


def test_all_three_env_vars():
    os.environ["STUDYGRAPH_API_KEY"] = "key1"
    os.environ["STUDYGRAPH_LLM_BASE_URL"] = "http://example.com/api"
    os.environ["STUDYGRAPH_LLM_MODEL"] = "example-model"
    cfg = config_module.load_config()
    assert cfg["api_key"] == "key1"
    assert cfg["llm"]["base_url"] == "http://example.com/api"
    assert cfg["llm"]["model"] == "example-model"


def test_embedding_and_qa_env_vars():
    os.environ["STUDYGRAPH_EMBEDDING_BASE_URL"] = "https://embed.api/v1/embeddings"
    os.environ["STUDYGRAPH_EMBEDDING_MODEL"] = "embed-model"
    os.environ["STUDYGRAPH_QA_BASE_URL"] = "https://qa.api/v1/chat/completions"
    os.environ["STUDYGRAPH_QA_MODEL"] = "qa-model"
    cfg = config_module.load_config()
    assert cfg["embedding"]["base_url"] == "https://embed.api/v1"
    assert cfg["embedding"]["model"] == "embed-model"
    assert cfg["qa"]["base_url"] == "https://qa.api/v1"
    assert cfg["qa"]["model"] == "qa-model"


def test_yaml_merge():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("llm:\n  model: yaml-model\n  temperature: 0.5\n")
        yaml_path = f.name

    try:
        cfg = config_module.load_config(yaml_path)
        assert cfg["llm"]["model"] == "yaml-model"
        assert cfg["llm"]["temperature"] == 0.5
        assert cfg["llm"]["base_url"] == "https://api.openai.com/v1"
    finally:
        Path(yaml_path).unlink(missing_ok=True)


def test_deepcopy_isolation():
    """Two consecutive calls must not share internal dicts."""
    cfg1 = config_module.load_config()
    cfg1["llm"]["model"] = "modified-model"

    cfg2 = config_module.load_config()
    assert cfg2["llm"]["model"] == "gpt-4o-mini"


def test_dotenv_loaded():
    dotenv_path = Path(".env.local")
    if dotenv_path.exists():
        backup = dotenv_path.read_text()
        dotenv_path.rename(".env.local.bak")
    else:
        backup = None

    try:
        dotenv_path.write_text("STUDYGRAPH_API_KEY=dotenv-key")
        cfg = config_module.load_config()
        assert cfg["api_key"] == "dotenv-key"
    finally:
        dotenv_path.unlink(missing_ok=True)
        if backup is not None:
            Path(".env.local.bak").rename(".env.local")
