import json

from studygraph.retrieval_eval import evaluate_retrieval
from studygraph.retrieval_eval import _compute_summary
from studygraph.search_index import build_index


def _create_kb(tmp_path):
    kb = tmp_path / "kb"
    kb.mkdir()
    catalog = [
        {
            "source_id": "src_001", "filename": "Fourier.pdf", "course": "Analisi 1",
            "topic": "Serie di Fourier", "final_decision": "candidate", "final_score": 0.85,
            "language": "it", "page_count": 10, "char_count": 2000, "text_quality_score": 0.9,
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        },
        {
            "source_id": "src_002", "filename": "Limiti.pdf", "course": "Analisi 1",
            "topic": "Limiti", "final_decision": "candidate", "final_score": 0.78,
            "language": "it", "page_count": 8, "char_count": 1500, "text_quality_score": 0.85,
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
        },
    ]
    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    for doc in catalog:
        path = kb / doc["markdown_path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f"---\nsource_id: {doc['source_id']}\n---\n# {doc['topic']}\n\n"
            f"Questo documento riguarda {doc['topic']}.\n"
            + " ".join([f"{doc['topic'].lower().replace(' ', '_')}_{i}" for i in range(100)]),
            encoding="utf-8",
        )

    build_index(str(kb))
    return kb


def _dataset():
    return [
        {"id": "q_001", "question": "Fourier", "course": "Analisi 1",
         "expected_sources": ["Fourier.pdf"], "expected_behavior": "answered"},
        {"id": "q_002", "question": "Limiti", "course": "Analisi 1",
         "expected_sources": ["Limiti.pdf"], "expected_behavior": "answered"},
        {"id": "q_003", "question": "ricetta della carbonara", "course": "Analisi 1",
         "expected_sources": [], "expected_behavior": "no_answer"},
    ]


def test_top1_hit_correct(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical"], top_k=5)
    summary = result["summary"]["lexical"]
    assert round(summary["top1_accuracy"], 2) == 0.67  # 2/3, no_answer excluded
    assert summary["top1_accuracy_answered_only"] == 1.0


def test_top3_hit_correct(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical"], top_k=5)
    summary = result["summary"]["lexical"]
    assert round(summary["top3_hit_rate"], 2) == 0.67
    assert summary["top3_hit_rate_answered_only"] == 1.0


def test_mrr_calculated(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical"], top_k=5)
    summary = result["summary"]["lexical"]
    assert summary["mrr"] > 0


def test_no_result_correctness(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical"], top_k=5)
    summary = result["summary"]["lexical"]
    assert summary["no_result_correctness"] >= 0


def test_multiple_modes_produce_separate_records(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical", "semantic", "hybrid"], top_k=5, dry_run=True)
    assert "lexical" in result["summary"]
    assert "semantic" in result["summary"]
    assert "hybrid" in result["summary"]
    modes_in_results = set(r["mode"] for r in result["results"])
    assert modes_in_results == {"lexical", "semantic", "hybrid"}


def test_json_serializable(tmp_path):
    kb = _create_kb(tmp_path)
    dataset = _dataset()
    result = evaluate_retrieval(str(kb), dataset, modes=["lexical"], top_k=5)
    json.dumps(result)


def test_source_hit_rate_counts_misses_in_denominator():
    results = [
        {
            "top1_hit": True,
            "top3_hit": True,
            "is_no_answer": False,
            "expected_sources": ["A.pdf"],
            "result_filenames": ["A.pdf"],
            "source_hit": 1.0,
            "no_result_correctness": None,
        },
        {
            "top1_hit": False,
            "top3_hit": False,
            "is_no_answer": False,
            "expected_sources": ["B.pdf"],
            "result_filenames": ["A.pdf"],
            "source_hit": 0.0,
            "no_result_correctness": None,
        },
    ]
    summary = _compute_summary(results, [1.0, 1.0])
    assert summary["source_hit_rate"] == 0.5
