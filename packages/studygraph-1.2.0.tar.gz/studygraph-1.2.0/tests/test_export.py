import json
from pathlib import Path

from studygraph.export import export_physical


def _doc(sid: str, decision: str = "needs_review", filename: str | None = None) -> dict:
    return {
        "source_id": sid,
        "filename": filename or f"{sid}.pdf",
        "course": "Test",
        "suggested_decision": decision,
        "final_decision": decision,
        "final_score": 0.5,
        "reason": "test",
    }


def _source(sid: str, raw_dir: Path) -> dict:
    return {
        "source_id": sid,
        "filename": f"{sid}.pdf",
        "raw_path": str(raw_dir / f"{sid}.pdf"),
    }


def test_export_copies_to_correct_folders(tmp_path):
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [
        _doc("src_001", "candidate"),
        _doc("src_002", "needs_review"),
        _doc("src_003", "rejected"),
        _doc("src_004", "duplicate"),
    ]
    sources = [_source(d["source_id"], raw_dir) for d in docs]

    for s in sources:
        (raw_dir / f"{s['source_id']}.pdf").write_text("dummy pdf content")

    export_physical(docs, sources, str(out_dir))

    assert (out_dir / "candidates" / "src_001_src_001.pdf").exists()
    assert (out_dir / "needs_review" / "src_002_src_002.pdf").exists()
    assert (out_dir / "rejected" / "src_003_src_003.pdf").exists()
    assert (out_dir / "duplicates" / "src_004_src_004.pdf").exists()


def test_export_private_only(tmp_path):
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "private_only")]
    sources = [_source("src_001", raw_dir)]
    (raw_dir / "src_001.pdf").write_text("private content")

    export_physical(docs, sources, str(out_dir))
    assert (out_dir / "private_only" / "src_001_src_001.pdf").exists()


def test_export_creates_manifest(tmp_path):
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate")]
    sources = [_source("src_001", raw_dir)]
    (raw_dir / "src_001.pdf").write_text("content")

    export_physical(docs, sources, str(out_dir))
    manifest_path = out_dir / "manifest.json"
    assert manifest_path.exists()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert len(manifest) == 1
    assert manifest[0]["source_id"] == "src_001"
    assert manifest[0]["decision"] == "candidate"
    assert manifest[0]["filename"] == "src_001.pdf"
    assert manifest[0]["export_path"] != ""


def test_export_uses_final_decision(tmp_path):
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    doc = _doc("src_001", "needs_review")
    doc["final_decision"] = "candidate"
    sources = [_source("src_001", raw_dir)]
    (raw_dir / "src_001.pdf").write_text("content")

    export_physical([doc], sources, str(out_dir))
    assert (out_dir / "candidates" / "src_001_src_001.pdf").exists()
    assert not (out_dir / "needs_review" / "src_001_src_001.pdf").exists()


def test_export_missing_raw_file_skips(tmp_path):
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    docs = [_doc("src_001", "candidate")]
    sources = [{"source_id": "src_001", "filename": "gone.pdf", "raw_path": str(tmp_path / "nonexistent.pdf")}]

    manifest_path = export_physical(docs, sources, str(out_dir))
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    assert manifest[0]["warning"] == "raw file not found"


def test_export_duplicate_dedup_once(tmp_path):
    raw_dir = tmp_path / "raw"
    raw_dir.mkdir()
    out_dir = tmp_path / "output"
    out_dir.mkdir()

    (raw_dir / "shared.pdf").write_text("same content")
    same_hash = "abc123"

    docs = [
        _doc("src_001", "duplicate"),
        _doc("src_002", "duplicate"),
    ]
    sources = [
        {"source_id": "src_001", "filename": "doc_a.pdf", "raw_path": str(raw_dir / "shared.pdf"), "hash": same_hash},
        {"source_id": "src_002", "filename": "doc_b.pdf", "raw_path": str(raw_dir / "shared.pdf"), "hash": same_hash},
    ]

    export_physical(docs, sources, str(out_dir))
    dup_dir = out_dir / "duplicates"
    copied = list(dup_dir.iterdir())
    assert len(copied) == 1


def test_export_handles_empty_documents(tmp_path):
    out_dir = tmp_path / "output"
    out_dir.mkdir()
    manifest_path = export_physical([], [], str(out_dir))
    assert Path(manifest_path).exists()
    assert json.loads(Path(manifest_path).read_text(encoding="utf-8")) == []
