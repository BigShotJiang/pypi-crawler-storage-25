import json

from studygraph.qa import answer_question


def _config():
    return {
        "qa": {
            "provider": "mock",
            "model": "",
            "base_url": "",
            "api_key_env": "",
            "temperature": 0.0,
        },
        "api_key": None,
    }


def _bundle(context="", sources=None):
    sources = sources or []
    return {
        "context": context,
        "sources": sources,
        "used_chunks": len(sources),
        "total_chars": len(context),
    }


def _source(citation_id=1, text="Testo del chunk di Fourier."):
    return {
        "citation_id": citation_id,
        "chunk_id": f"src_001::000{citation_id}",
        "source_id": "src_001",
        "filename": "Fourier.md",
        "course": "Analisi 1",
        "topic": "Serie di Fourier",
        "score": 0.87,
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
    }


def test_answer_empty_context_returns_no_answer():
    result = answer_question("Domanda?", _bundle(), _config())
    assert result["answer_type"] == "no_answer"
    assert result["confidence"] == 0.0


def test_dry_run_extracts_relevant_sentence():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nLa serie di Fourier rappresenta una funzione periodica come somma di seni e coseni.\n\n[2] Altro.md | chunk src_002::0001 | topic: Altro\nTesto irrilevante.\n"
    result = answer_question("Che cos'è una serie di Fourier?", _bundle(ctx, [s1]), _config(), dry_run=True)
    assert result["answer_type"] == "answered"
    assert "Fourier" in result["answer"]


def test_dry_run_answer_includes_citation():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nLa serie di Fourier rappresenta una funzione periodica come somma di seni e coseni.\n"
    result = answer_question("serie di Fourier", _bundle(ctx, [s1]), _config(), dry_run=True)
    assert "[1]" in result["answer"]


def test_dry_run_confidence_positive_when_answered():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nLa serie di Fourier rappresenta una funzione periodica come somma di seni e coseni.\n"
    result = answer_question("serie di Fourier", _bundle(ctx, [s1]), _config(), dry_run=True)
    assert result["confidence"] > 0
    assert result["confidence"] <= 1.0


def test_no_answer_when_question_terms_not_in_context():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nLa serie di Fourier rappresenta una funzione periodica come somma di seni e coseni.\n"
    result = answer_question("ricetta carbonara", _bundle(ctx, [s1]), _config(), dry_run=True)
    assert result["answer_type"] == "no_answer"


def test_output_json_serializable():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nLa serie di Fourier rappresenta una funzione periodica.\n"
    result = answer_question("serie di Fourier", _bundle(ctx, [s1]), _config(), dry_run=True)
    json.dumps(result, ensure_ascii=False)


def test_citation_check_invalid():
    s1 = _source(1)
    ctx = "[1] Fourier.md | chunk src_001::0001 | topic: Serie di Fourier\nTesto senza citazione.\n"
    result = answer_question("serie di Fourier", _bundle(ctx, [s1]), _config(), dry_run=True)
    assert "citation_check" in result
