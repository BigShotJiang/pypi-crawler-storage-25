import json
from pathlib import Path

from studygraph.search_index import build_index
from studygraph.vector_index import build_vector_index
from studygraph.hybrid_search import hybrid_search
from studygraph.search import search


def _config():
    return {
        "embedding": {
            "provider": "mock",
            "dimensions": 384,
            "model": "",
            "base_url": "",
            "api_key_env": "STUDYGRAPH_EMBEDDING_API_KEY",
        },
        "api_key": None,
    }


def _create_kb(tmp_path) -> Path:
    kb = tmp_path / "knowledge_base"
    kb.mkdir(parents=True)

    docs = [
        {
            "source_id": "src_001",
            "filename": "Fourier.md",
            "course": "Analisi 1",
            "topic": "Serie di Fourier",
            "final_score": 0.85,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        },
        {
            "source_id": "src_002",
            "filename": "Limiti.md",
            "course": "Analisi 1",
            "topic": "Limiti di funzioni",
            "final_score": 0.78,
            "language": "it",
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
        },
    ]

    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(docs, f, ensure_ascii=False)

    for d in docs:
        md_path = kb / d["markdown_path"]
        md_path.parent.mkdir(parents=True, exist_ok=True)
        topic_words = d["topic"].lower().replace(" ", "_")
        content = (
            f"---\nsource_id: {d['source_id']}\n---\n\n"
            f"# {d['topic']}\n\n"
            f"Questo documento riguarda {d['topic']}. "
            + " ".join([f"{topic_words}_{i}" for i in range(100)])
        )
        md_path.write_text(content, encoding="utf-8")

    return kb


def test_hybrid_combines_both(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
    )
    assert len(results) > 0
    assert results[0]["score_type"] == "hybrid"


def test_semantic_weight_zero_approximates_lexical(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    lex_results = search("Fourier", str(kb / "search_index"), top_k=5)
    hybrid_results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
        semantic_weight=0.0,
    )
    assert len(hybrid_results) > 0
    assert hybrid_results[0]["chunk_id"] == lex_results[0]["chunk_id"]


def test_semantic_weight_one_equals_semantic(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    from studygraph.vector_search import semantic_search
    sem_results = semantic_search("Fourier", str(kb / "vector_index"), _config(), top_k=1)
    hybrid_results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
        semantic_weight=1.0,
        top_k=1,
    )
    assert len(hybrid_results) > 0
    if sem_results:
        assert hybrid_results[0]["chunk_id"] == sem_results[0]["chunk_id"]


def test_results_sorted_by_score(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
        top_k=10,
    )
    for i in range(len(results) - 1):
        assert results[i]["score"] >= results[i + 1]["score"]


def test_fallback_without_vector_index(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
    )
    assert len(results) > 0
    assert all(r["score_type"] == "hybrid" for r in results)


def test_json_serializable(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    build_vector_index(str(kb), _config())
    results = hybrid_search(
        "Fourier",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
    )
    json.dumps(results, ensure_ascii=False)


def test_empty_query_returns_empty(tmp_path):
    kb = _create_kb(tmp_path)
    build_index(str(kb))
    results = hybrid_search(
        "",
        str(kb / "search_index"),
        str(kb / "vector_index"),
        _config(),
    )
    assert results == []
