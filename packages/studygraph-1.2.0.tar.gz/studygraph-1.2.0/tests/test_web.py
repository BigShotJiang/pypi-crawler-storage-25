import json
import os

import pytest
from fastapi.testclient import TestClient

from studygraph.app import web_app, _load_docs

client = TestClient(web_app)


def _setup_sample_data(tmp_path):
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True)
    docs_path = output_dir / "documents.jsonl"
    docs = [
        {
            "source_id": "src_001", "filename": "Fourier.pdf", "course": "Analisi 1",
            "topic": "Serie di Fourier", "final_decision": "candidate", "final_score": 0.85,
            "suggested_decision": "candidate", "manual_decision": "", "reviewer_note": "",
            "language": "it", "page_count": 10, "char_count": 2000,
            "text_quality_score": 0.9, "is_probably_scanned": False,
            "extraction_warning": False,
        },
        {
            "source_id": "src_002", "filename": "Limiti.pdf", "course": "Analisi 1",
            "topic": "Limiti", "final_decision": "needs_review", "final_score": 0.55,
            "suggested_decision": "needs_review", "manual_decision": "", "reviewer_note": "",
            "language": "it", "page_count": 8, "char_count": 1500,
            "text_quality_score": 0.85, "is_probably_scanned": False,
            "extraction_warning": False,
        },
    ]
    with open(docs_path, "w", encoding="utf-8") as f:
        for d in docs:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    return str(output_dir), docs


def test_get_upload_page():
    response = client.get("/upload")
    assert response.status_code == 200
    assert "Carica documenti" in response.text
    assert "enctype" in response.text


def test_get_dashboard_empty():
    import studygraph.app as app_mod
    saved = app_mod._load_docs
    app_mod._load_docs = lambda output_dir="": []
    try:
        response = client.get("/dashboard")
        assert response.status_code == 200
        assert "Nessun documento" in response.text
    finally:
        app_mod._load_docs = saved


def test_get_dashboard_with_data(tmp_path):
    _, docs = _setup_sample_data(tmp_path)
    import studygraph.app as app_mod
    saved = app_mod._load_docs
    app_mod._load_docs = lambda output_dir="": docs
    try:
        response = client.get("/dashboard")
        assert response.status_code == 200
        assert "Fourier.pdf" in response.text
        assert "Limiti.pdf" in response.text
        assert "candidate" in response.text
        assert "needs_review" in response.text
    finally:
        app_mod._load_docs = saved


def test_get_search_page():
    response = client.get("/search")
    assert response.status_code == 200
    assert "Cerca" in response.text
    assert "hybrid" in response.text


def test_get_search_with_query():
    response = client.get("/search?q=Fourier&mode=lexical&top_k=3")
    assert response.status_code == 200
    assert "Fourier" in response.text


def test_get_ask_page():
    response = client.get("/ask")
    assert response.status_code == 200
    assert "Fai una domanda" in response.text
    assert "hybrid" in response.text


def test_get_ask_with_query():
    response = client.get("/ask?q=Fourier&mode=lexical&top_k=3")
    assert response.status_code == 200
    assert "Fourier" in response.text


def test_upload_no_files():
    response = client.post("/upload", data={"course": "Test", "dry_run": "true"})
    assert response.status_code in (200, 303, 307, 422)


def test_all_routes_return_html():
    for path in ["/", "/upload", "/dashboard", "/search", "/ask", "/progress"]:
        response = client.get(path)
        assert response.status_code == 200
        content_type = response.headers.get("content-type", "")
        assert "text/html" in content_type
