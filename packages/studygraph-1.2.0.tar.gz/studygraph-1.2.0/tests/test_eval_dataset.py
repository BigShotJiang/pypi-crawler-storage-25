import json

from studygraph.eval_dataset import load_eval_dataset


def _write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)


def test_load_valid_dataset(tmp_path):
    questions = [
        {"id": "q_001", "question": "test question", "course": "Corso",
         "expected_sources": ["Doc1.pdf"], "expected_behavior": "answered"},
        {"id": "q_002", "question": "another question",
         "expected_sources": [], "expected_behavior": "no_answer"},
    ]
    p = tmp_path / "questions.json"
    _write(p, questions)
    loaded = load_eval_dataset(str(p))
    assert len(loaded) == 2
    assert loaded[0]["id"] == "q_001"
    assert loaded[0]["question"] == "test question"
    assert loaded[1]["expected_behavior"] == "no_answer"


def test_empty_dataset_does_not_crash(tmp_path):
    p = tmp_path / "questions.json"
    _write(p, [])
    loaded = load_eval_dataset(str(p))
    assert loaded == []


def test_missing_question_field_raises(tmp_path):
    p = tmp_path / "questions.json"
    _write(p, [{"id": "q_001", "expected_behavior": "answered"}])
    import pytest
    with pytest.raises(ValueError, match="question"):
        load_eval_dataset(str(p))


def test_default_behavior_is_answered(tmp_path):
    p = tmp_path / "questions.json"
    _write(p, [{"id": "q_001", "question": "test"}])
    loaded = load_eval_dataset(str(p))
    assert loaded[0]["expected_behavior"] == "answered"


def test_invalid_behavior_raises(tmp_path):
    p = tmp_path / "questions.json"
    _write(p, [{"id": "q_001", "question": "test", "expected_behavior": "invalid"}])
    import pytest
    with pytest.raises(ValueError, match="expected_behavior"):
        load_eval_dataset(str(p))


def test_expected_sources_normalized_to_list(tmp_path):
    p = tmp_path / "questions.json"
    _write(p, [{"id": "q_001", "question": "test", "expected_sources": "Doc1.pdf"}])
    loaded = load_eval_dataset(str(p))
    assert loaded[0]["expected_sources"] == ["Doc1.pdf"]


def test_missing_file_raises(tmp_path):
    import pytest
    with pytest.raises(FileNotFoundError):
        load_eval_dataset(str(tmp_path / "nonexistent.json"))
