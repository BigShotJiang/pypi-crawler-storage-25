import json

from studygraph.qa_eval import evaluate_qa
from studygraph.search_index import build_index


def _create_kb(tmp_path):
    kb = tmp_path / "kb"
    kb.mkdir()
    catalog = [
        {
            "source_id": "src_001", "filename": "Fourier.pdf", "course": "Analisi 1",
            "topic": "Serie di Fourier", "final_decision": "candidate", "final_score": 0.85,
            "language": "it", "page_count": 10, "char_count": 2000, "text_quality_score": 0.9,
            "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        },
        {
            "source_id": "src_002", "filename": "Limiti.pdf", "course": "Analisi 1",
            "topic": "Limiti", "final_decision": "candidate", "final_score": 0.78,
            "language": "it", "page_count": 8, "char_count": 1500, "text_quality_score": 0.85,
            "markdown_path": "courses/Analisi_1/documents/Limiti.md",
        },
    ]
    with open(kb / "catalog.json", "w", encoding="utf-8") as f:
        json.dump(catalog, f)

    for doc in catalog:
        path = kb / doc["markdown_path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            f"---\nsource_id: {doc['source_id']}\n---\n# {doc['topic']}\n\n"
            f"Questo documento riguarda {doc['topic']}.\n"
            + " ".join([f"{doc['topic'].lower().replace(' ', '_')}_{i}" for i in range(100)]),
            encoding="utf-8",
        )

    build_index(str(kb))
    return kb


def _config():
    return {
        "embedding": {"provider": "mock", "dimensions": 384, "model": "", "base_url": ""},
        "qa": {"provider": "mock", "model": "", "base_url": "", "temperature": 0.0},
        "api_key": None,
    }


def _dataset():
    return [
        {"id": "q_001", "question": "Fourier", "course": "Analisi 1",
         "expected_sources": ["Fourier.pdf"], "expected_answer_contains": [],
         "expected_behavior": "answered"},
        {"id": "q_002", "question": "ricetta della carbonara", "course": "Analisi 1",
         "expected_sources": [], "expected_answer_contains": [],
         "expected_behavior": "no_answer"},
    ]


def test_answered_correct(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    r = next(x for x in result["results"] if x["question_id"] == "q_001")
    assert r["behavior_match"] is True
    assert r["actual_answer_type"] == "answered"


def test_no_answer_correct(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    r = next(x for x in result["results"] if x["question_id"] == "q_002")
    assert r["behavior_match"] is True
    assert r["actual_answer_type"] == "no_answer"


def test_expected_answer_contains_verified(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    r = next(x for x in result["results"] if x["question_id"] == "q_001")
    assert "expected_terms_hit" in r
    assert "expected_terms_miss" in r


def test_citation_validity(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    summary = result["summary"]
    assert "citation_validity_rate" in summary


def test_source_hit_verified(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    r = next(x for x in result["results"] if x["question_id"] == "q_001")
    assert "Fourier.pdf" in r["sources_found"] or len(r["sources_found"]) > 0


def test_needs_review_counted(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    summary = result["summary"]
    assert "needs_review_count" in summary


def test_json_serializable(tmp_path):
    kb = _create_kb(tmp_path)
    ds = _dataset()
    config = _config()
    result = evaluate_qa(str(kb), ds, mode="lexical", top_k=5, dry_run=True, config=config)
    json.dumps(result)
