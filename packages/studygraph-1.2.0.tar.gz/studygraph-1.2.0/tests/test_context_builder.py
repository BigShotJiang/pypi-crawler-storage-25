from studygraph.context_builder import build_context


def _result(chunk_id="src_001::0003", score=0.87, text="Testo del chunk di Fourier."):
    return {
        "chunk_id": chunk_id,
        "source_id": "src_001",
        "filename": "Fourier.md",
        "course": "Analisi 1",
        "topic": "Serie di Fourier",
        "score": score,
        "snippet": "snippet...",
        "markdown_path": "courses/Analisi_1/documents/Fourier.md",
        "text": text,
    }


def test_build_context_empty_results():
    result = build_context([])
    assert result["context"] == ""
    assert result["sources"] == []
    assert result["used_chunks"] == 0


def test_build_context_assigns_citation_ids():
    r1 = _result(chunk_id="a::1", text="A")
    r2 = _result(chunk_id="b::2", text="B")
    result = build_context([r1, r2], max_chars=10000)
    assert result["used_chunks"] == 2
    assert result["sources"][0]["citation_id"] == 1
    assert result["sources"][1]["citation_id"] == 2
    assert "[1]" in result["context"]
    assert "[2]" in result["context"]


def test_build_context_respects_max_chars():
    r1 = _result(chunk_id="a::1", text="X" * 500)
    r2 = _result(chunk_id="b::2", text="Y" * 500)
    result = build_context([r1, r2], max_chars=600)
    assert result["used_chunks"] == 1
    assert result["total_chars"] <= 600


def test_build_context_filters_min_score():
    r1 = _result(chunk_id="a::1", score=0.9)
    r2 = _result(chunk_id="b::2", score=0.1)
    result = build_context([r1, r2], min_score=0.5)
    assert result["used_chunks"] == 1
    assert result["sources"][0]["chunk_id"] == "a::1"


def test_build_context_deduplicates_chunk_ids():
    r1 = _result(chunk_id="a::1", text="Primo")
    r2 = _result(chunk_id="a::1", text="Secondo")
    result = build_context([r1, r2], max_chars=10000)
    assert result["used_chunks"] == 1


def test_build_context_preserves_metadata():
    r = _result(chunk_id="a::1", text="Testo")
    result = build_context([r], max_chars=10000)
    s = result["sources"][0]
    assert s["filename"] == "Fourier.md"
    assert s["course"] == "Analisi 1"
    assert s["topic"] == "Serie di Fourier"
    assert s["citation_id"] == 1
    assert "text" not in s
