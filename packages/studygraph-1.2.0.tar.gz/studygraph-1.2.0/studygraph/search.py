import json
import math
import re
from pathlib import Path

from studygraph.search_index import tokenize

SNIPPET_RADIUS = 150

TOKEN_RE = re.compile(r"[^\w\s]")


def _load_index(index_dir: str) -> dict | None:
    idx = Path(index_dir)
    meta_path = idx / "index_meta.json"
    if not meta_path.exists():
        return None

    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    chunks = []
    chunks_path = idx / "chunks.jsonl"
    if chunks_path.exists():
        with open(chunks_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    chunks.append(json.loads(line))

    terms_path = idx / "terms.json"
    terms = {}
    if terms_path.exists():
        terms = json.loads(terms_path.read_text(encoding="utf-8"))

    return {"meta": meta, "chunks": chunks, "terms": terms, "index_dir": index_dir}


def _compute_bm25_scores(
    query_tokens: list[str],
    chunks: list[dict],
    terms: dict[str, list[str]],
    k1: float = 1.2,
    b: float = 0.75,
) -> list[float]:
    n = len(chunks)
    avg_doc_len = sum(c.get("char_count", 0) for c in chunks) / max(n, 1)

    scores = [0.0] * n

    chunk_tokens = []
    for c in chunks:
        chunk_tokens.append(c.get("tokens", []))

    for qt in query_tokens:
        posting = terms.get(qt, [])
        if not posting:
            continue
        df = len(posting)
        idf = math.log((n - df + 0.5) / (df + 0.5) + 1.0)

        chunk_ids = set(posting)
        for i in range(n):
            if chunks[i]["chunk_id"] not in chunk_ids:
                continue
            tf = chunk_tokens[i].count(qt)
            doc_len = chunks[i].get("char_count", 0)
            denom = tf + k1 * (1 - b + b * doc_len / max(avg_doc_len, 1))
            scores[i] += idf * (tf * (k1 + 1)) / max(denom, 1e-10)

    return scores


def _compute_boosts(
    query_text: str,
    chunks: list[dict],
) -> list[float]:
    q_lower = query_text.lower()
    boosts = [0.0] * len(chunks)

    for i, c in enumerate(chunks):
        topic = c.get("topic", "").lower()
        filename = c.get("filename", "").lower()
        course = c.get("course", "").lower()

        if topic and q_lower in topic:
            boosts[i] += 0.25
        if filename and q_lower in filename:
            boosts[i] += 0.15
        if course and q_lower in course:
            boosts[i] += 0.05

    return boosts


def _extract_snippet(chunk_text: str, query_tokens: list[str], radius: int = SNIPPET_RADIUS) -> str:
    text_lower = chunk_text.lower()
    best_pos = -1

    for qt in query_tokens:
        pos = text_lower.find(qt)
        if pos != -1 and (best_pos == -1 or pos < best_pos):
            best_pos = pos

    if best_pos == -1:
        return chunk_text[:radius * 2].strip()

    start = max(0, best_pos - radius)
    end = min(len(chunk_text), best_pos + radius)
    snippet = chunk_text[start:end]

    if start > 0:
        snippet = "..." + snippet
    if end < len(chunk_text):
        snippet = snippet + "..."

    return snippet


def search(
    query: str,
    index_dir: str,
    course: str | None = None,
    top_k: int = 5,
) -> list[dict]:
    if not query or not query.strip():
        return []

    data = _load_index(index_dir)
    if not data:
        return []

    chunks = data["chunks"]
    terms = data["terms"]

    if not chunks:
        return []

    if course:
        course_lower = course.lower()
        chunks = [c for c in chunks if c.get("course", "").lower() == course_lower]
        if not chunks:
            return []

    query_tokens = tokenize(query)
    if not query_tokens:
        return []

    bm25_scores = _compute_bm25_scores(query_tokens, chunks, terms)
    boosts = _compute_boosts(query, chunks)

    max_bm25 = max(bm25_scores) if bm25_scores and max(bm25_scores) > 0 else 1.0
    final_scores = [
        (bm25_scores[i] / max_bm25) + boosts[i]
        for i in range(len(chunks))
    ]

    ranked = sorted(
        zip(final_scores, chunks),
        key=lambda x: -x[0],
    )

    results = []
    for score, chunk in ranked[:top_k]:
        if score <= 0:
            continue
        snippet = _extract_snippet(chunk.get("text", ""), query_tokens)
        results.append({
            "chunk_id": chunk.get("chunk_id", ""),
            "source_id": chunk.get("source_id", ""),
            "filename": chunk.get("filename", ""),
            "course": chunk.get("course", ""),
            "topic": chunk.get("topic", ""),
            "score": round(score, 3),
            "snippet": snippet,
            "markdown_path": chunk.get("markdown_path", ""),
        })

    return results
