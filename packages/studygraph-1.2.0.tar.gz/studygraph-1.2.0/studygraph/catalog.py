import csv
import json
from pathlib import Path

INCLUDED_DECISIONS = {"candidate", "needs_review"}

DECISION_FOLDERS = {
    "candidate": "candidates",
    "needs_review": "needs_review",
    "private_only": "private_only",
    "rejected": "rejected",
    "reject": "rejected",
    "duplicate": "duplicates",
}


def _filter_documents(documents: list[dict], only_candidates: bool = False) -> list[dict]:
    decisions = {"candidate"} if only_candidates else INCLUDED_DECISIONS
    return [d for d in documents if d.get("final_decision", d.get("suggested_decision", "")) in decisions]


def _build_record(doc: dict, kb_dir: str) -> dict:
    course = doc.get("course", "unknown")
    filename = doc.get("filename", "doc.pdf")
    md_name = filename.rsplit(".", 1)[0] + ".md"
    sanitized_course = _sanitize(course)

    pdf_basename = f"{doc.get('source_id', 'unknown')}_{filename}"
    decision = doc.get("final_decision", "")
    export_dir = DECISION_FOLDERS.get(decision, "rejected")

    return {
        "source_id": doc.get("source_id", ""),
        "filename": filename,
        "course": course,
        "topic": doc.get("topic", ""),
        "final_decision": doc.get("final_decision", ""),
        "final_score": doc.get("final_score", 0),
        "language": doc.get("language", "unknown"),
        "page_count": doc.get("page_count", 0),
        "char_count": doc.get("char_count", 0),
        "text_quality_score": doc.get("text_quality_score", 0),
        "markdown_path": f"courses/{sanitized_course}/documents/{md_name}",
        "source_pdf_path": f"data/output/{export_dir}/{pdf_basename}",
    }


def _sanitize(name: str) -> str:
    invalid = '<>:"/\\|?*'
    for c in invalid:
        name = name.replace(c, "_")
    name = name.strip().replace(" ", "_")
    return name if name else "unnamed"


def generate_catalog(documents: list[dict], kb_dir: str, only_candidates: bool = False) -> str:
    filtered = _filter_documents(documents, only_candidates=only_candidates)
    records = [_build_record(d, kb_dir) for d in filtered]

    kb_path = Path(kb_dir)
    kb_path.mkdir(parents=True, exist_ok=True)

    json_path = kb_path / "catalog.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)

    csv_path = kb_path / "catalog.csv"
    if records:
        fields = list(records[0].keys())
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(records)

    _generate_global_index(documents, records, kb_dir)

    return str(kb_path)


def _generate_global_index(all_documents: list[dict], catalog_records: list[dict], kb_dir: str) -> None:
    kb_path = Path(kb_dir)

    decisions = {}
    for doc in all_documents:
        d = doc.get("final_decision", doc.get("suggested_decision", "reject"))
        decisions[d] = decisions.get(d, 0) + 1

    excluded_reject = decisions.get("reject", 0)
    excluded_dup = decisions.get("duplicate", 0)
    excluded_private = decisions.get("private_only", 0)
    excluded_total = excluded_reject + excluded_dup + excluded_private

    courses = {}
    for rec in catalog_records:
        c = rec["course"]
        if c not in courses:
            courses[c] = {"total": 0, "candidate": 0, "needs_review": 0}
        courses[c]["total"] += 1
        if rec["final_decision"] == "candidate":
            courses[c]["candidate"] += 1
        else:
            courses[c]["needs_review"] += 1

    scores = [rec["final_score"] for rec in catalog_records if rec["final_score"]]
    avg_score = sum(scores) / len(scores) if scores else 0

    lines = [
        "# StudyGraph Knowledge Base",
        "",
        f"Knowledge base generata il {_today()}.",
        "",
        "## Corsi",
        "",
    ]
    for course_name, info in sorted(courses.items()):
        lines.append(
            f"- **{course_name}** "
            f"({info['total']} documenti, "
            f"{info['candidate']} candidate, "
            f"{info['needs_review']} needs_review)"
        )

    lines.extend([
        "",
        "## Statistiche globali",
        "",
        "| Metrica | Valore |",
        "|---|---:|",
        f"| Documenti nella KB | {len(catalog_records)} |",
        f"| Esclusi (reject) | {excluded_reject} |",
        f"| Esclusi (duplicate) | {excluded_dup} |",
        f"| Esclusi (private_only) | {excluded_private} |",
        f"| Totale esclusi | {excluded_total} |",
        f"| Corsi con documenti | {len(courses)} |",
        f"| Score medio | {avg_score:.3f} |",
        "",
    ])

    content = "\n".join(lines)

    idx_path = kb_path / "global_index.md"
    idx_path.write_text(content, encoding="utf-8")


def _today() -> str:
    from datetime import date
    return date.today().isoformat()
