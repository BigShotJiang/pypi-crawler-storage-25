import json
import sys
from pathlib import Path

import click

from studygraph import __version__
from studygraph.config import load_config
from studygraph.eval_dataset import load_eval_dataset
from studygraph.retrieval_eval import evaluate_retrieval
from studygraph.qa_eval import evaluate_qa
from studygraph.eval_report import write_retrieval_report, write_qa_report
from studygraph.ingest import ingest
from studygraph.extract import extract_text
from studygraph.quality import score_text_quality
from studygraph.dedup import compute_duplication_scores
from studygraph.scoring import score_document
from studygraph.decision import decide
from studygraph.dashboard import generate_csv, generate_html
from studygraph.telegram_export import ingest_telegram
from studygraph.review import load_review_decisions, apply_review_decisions
from studygraph.export import export_physical
from studygraph.markdown_export import export_markdown
from studygraph.demo import run_demo
from studygraph.build import run_build


@click.group()
@click.version_option(version=__version__, prog_name="studygraph")
def main():
    pass


@main.command()
@click.argument("input_dir", type=click.Path(exists=True))
@click.option("--course", default=None, help="Nome del corso (auto-detect da sottocartelle se omesso)")
@click.option("--max-docs", default=50, help="Numero massimo di documenti da processare")
@click.option("--dry-run", is_flag=True, help="Salta chiamate LLM, usa score euristici")
@click.option("--llm-model", default=None, help="Override modello LLM")
@click.option("--config", "cfg_path", default="config.yaml", help="Percorso file config YAML")
def audit(input_dir, course, max_docs, dry_run, llm_model, cfg_path):
    config = load_config(cfg_path)

    if dry_run:
        config["llm"]["enabled"] = False
        click.echo("  Dry-run: chiamate LLM disabilitate, usati score euristici")

    if llm_model:
        config["llm"]["model"] = llm_model

    prompts_dir = Path(__file__).parent.parent / "prompts"
    config["doc_prompt_path"] = str(prompts_dir / "document_scorer.md")
    config["risk_prompt_path"] = str(prompts_dir / "policy_risk.md")

    config["input"]["path"] = input_dir
    config["input"]["max_documents"] = max_docs

    raw_dir = config["storage"]["raw_path"]
    extracted_dir = config["storage"]["extracted_path"]
    output_dir = config["storage"]["output_path"]
    sources_path = str(Path(raw_dir).parent / "sources.jsonl")

    courses = _resolve_courses(input_dir, course)
    if not courses:
        click.echo("  Nessun corso trovato. Metti i PDF in sottocartelle o usa --course.")
        return

    all_scored_docs = []
    for c in courses:
        click.echo(f"\n{'='*60}")
        click.echo(f"Corso: {c}")
        click.echo(f"{'='*60}")

        if course:
            course_input = input_dir
            course_name = course
        else:
            course_input = str(Path(input_dir) / c) if c else input_dir
            course_name = c or "unnamed"

        click.echo(f"[1/6] Acquisizione documenti da {course_input}...")
        new_sources = ingest(
            input_dir=course_input,
            raw_dir=raw_dir,
            sources_path=sources_path,
            allowed_extensions=config["input"]["allowed_extensions"],
            course=course_name,
        )
        all_sources = _load_sources(sources_path)
        click.echo(f"  {len(new_sources)} nuovi, {len(all_sources)} totali")

        course_sources = [s for s in all_sources if s.get("course") == c or not s.get("course")]

        if not course_sources:
            click.echo(f"  Nessun documento per il corso '{c}', salto.")
            continue

        click.echo(f"[2/6] Estrazione testo dai PDF...")
        extracted_list = []
        for s in course_sources:
            meta = extract_text(
                raw_path=s["raw_path"],
                extracted_dir=extracted_dir,
                source_id=s["source_id"],
            )
            if meta:
                extracted_list.append(meta)
                _update_source_status(sources_path, s["source_id"], "extracted")
        click.echo(f"  {len(extracted_list)} documenti estratti")

        click.echo(f"[3/6] Calcolo punteggi duplicazione...")
        dup_scores = compute_duplication_scores(course_sources, extracted_dir=extracted_dir)

        click.echo(f"[4/6] Scoring documenti (potrebbe richiedere tempo)...")
        scored_docs = []
        for meta in extracted_list:
            sid = meta["source_id"]
            text_path = Path(meta["extracted_path"])
            full_text = text_path.read_text(encoding="utf-8") if text_path.exists() else ""

            quality = score_text_quality(full_text, extraction_meta=meta)
            meta.update(quality)

            scores = score_document(
                source_id=sid,
                filename=_find_source_filename(course_sources, sid),
                full_text=full_text,
                metadata=meta,
                course_name=course_name,
                config=config,
                dry_run=dry_run,
            )
            scores["duplication_score"] = dup_scores.get(sid, 0.0)

            result = decide(scores, config)
            scores["final_score"] = result["final_score"]
            scores["suggested_decision"] = result["decision"]
            scores["reason"] = result.get("reason", scores.get("doc_reason", ""))
            if not scores["reason"]:
                scores["reason"] = scores.get("risk_reason", "")

            scores["page_count"] = meta.get("num_pages", 0)
            scores["char_count"] = meta.get("char_count", 0)
            scores["text_quality_score"] = meta.get("text_quality_score", 0)
            scores["is_probably_scanned"] = meta.get("is_probably_scanned", False)
            scores["extraction_warning"] = meta.get("extraction_warning", False)
            scores["language"] = meta.get("language", "unknown")

            scores["manual_decision"] = ""
            scores["reviewer_note"] = ""
            scores["final_decision"] = scores["suggested_decision"]

            scored_docs.append(scores)
            click.echo(f"  {scores['source_id']} {scores['filename']}: {scores['suggested_decision']} ({scores['final_score']:.3f})")

        if scored_docs:
            safe_prefix = _sanitize_prefix(course_name)
            csv_path = generate_csv(scored_docs, output_dir, prefix=safe_prefix)
            html_path = generate_html(scored_docs, output_dir, prefix=safe_prefix)
            click.echo(f"[5/6] Dashboard: {csv_path}, {html_path}")
            _save_documents(scored_docs, output_dir)
            all_scored_docs.extend(scored_docs)

    if all_scored_docs:
        csv_path = generate_csv(all_scored_docs, output_dir)
        html_path = generate_html(all_scored_docs, output_dir)
        click.echo(f"\nDashboard globale: {csv_path}, {html_path}")

    decisions = {}
    for d in all_scored_docs:
        dec = d["suggested_decision"]
        decisions[dec] = decisions.get(dec, 0) + 1
    click.echo(f"\nRiepilogo: {dict(decisions)}")


@main.command()
@click.argument("export_path", type=click.Path(exists=True))
@click.argument("input_dir", type=click.Path())
@click.option("--extensions", default=".pdf,.docx,.txt,.md", help="Estensioni consentite (separate da virgola)")
def ingest_telegram_cmd(export_path, input_dir, extensions):
    click.echo("  ⚠️  Sperimentale: ingest-telegram potrebbe cambiare in future versioni.")
    exts = [e.strip().lower() for e in extensions.split(",")]
    result = ingest_telegram(export_path, input_dir, exts)
    click.echo(f"Copiati: {result['copied']}")
    click.echo(f"Saltati (placeholder): {result['skipped_placeholder']}")
    click.echo(f"Saltati (estensione): {result['skipped_extension']}")
    click.echo(f"Errori: {result['errors']}")
    for f in result["files"]:
        click.echo(f"  {f}")


@main.command()
@click.argument("documents_path", type=click.Path(exists=True))
@click.option("--output-dir", default="data/output", help="Output directory")
@click.option("--sources", default="data/sources.jsonl", help="Percorso JSONL delle sorgenti")
def export_cmd(documents_path, output_dir, sources):
    """Copia i PDF in cartelle basate sulla decisione e genera manifest.json."""
    docs = _load_documents(documents_path)
    srcs = _load_sources(sources)

    review_csv = str(Path(output_dir) / "review_decisions.csv")
    if Path(review_csv).exists():
        click.echo("  Applicazione decisioni manuali prima dell'export...")
        review = load_review_decisions(review_csv)
        if review:
            docs = apply_review_decisions(docs, review, documents_path)
            click.echo(f"  {len(review)} decisioni manuali applicate")

    config = load_config()
    extracted_dir = config["storage"]["extracted_path"]
    manifest_path = export_physical(docs, srcs, output_dir)

    counts: dict[str, int] = {}
    for d in docs:
        dec = d.get("final_decision", d.get("suggested_decision", "reject"))
        counts[dec] = counts.get(dec, 0) + 1

    click.echo("Export completato:")
    for k in ("candidate", "needs_review", "private_only", "rejected", "duplicate"):
        click.echo(f"  {k}: {counts.get(k, 0)}")
    click.echo(f"  Manifest: {manifest_path}")


@main.command()
@click.argument("csv_path", type=click.Path(exists=True))
@click.option("--documents", default="data/output/documents.jsonl", help="Percorso JSONL dei documenti")
def apply_review_cmd(csv_path, documents):
    """Applica decisioni manuali da review_decisions.csv e rigenera la dashboard."""
    docs = _load_documents(documents)
    if not docs:
        click.echo("  No documents found.")
        return

    decisions = load_review_decisions(csv_path)
    if not decisions:
        click.echo("  Nessuna decisione manuale valida trovata nel CSV.")
        return

    docs = apply_review_decisions(docs, decisions, documents)
    output_dir = str(Path(documents).parent)
    _update_dashboard(docs, output_dir)
    click.echo(f"  Applicate {len(decisions)} decisioni manuali. Dashboard aggiornata.")


@main.command()
@click.argument("documents_path", type=click.Path(exists=True))
@click.option("--output-dir", default="data/output", help="Directory di output")
def markdown_export_cmd(documents_path, output_dir):
    """Esporta il testo estratto come file Markdown per documenti candidate e needs_review."""
    docs = _load_documents(documents_path)

    review_csv = str(Path(output_dir) / "review_decisions.csv")
    if Path(review_csv).exists():
        click.echo("  Applicazione decisioni manuali prima dell'export Markdown...")
        review = load_review_decisions(review_csv)
        if review:
            docs = apply_review_decisions(docs, review, documents_path)

    config = load_config()
    extracted_dir = config["storage"]["extracted_path"]
    md_dir = export_markdown(docs, extracted_dir, output_dir)
    exported = len(list(Path(md_dir).rglob("*.md")))
    click.echo(f"  Esportati {exported} file Markdown in {md_dir}")


@main.command()
@click.argument("documents_path", type=click.Path(exists=True))
@click.option("--output-dir", default="data/output", help="Output directory per la knowledge base")
@click.option("--only-candidates", is_flag=True, help="Esporta solo candidate (esclude needs_review)")
def build_kb(documents_path, output_dir, only_candidates):
    """Costruisce la knowledge base canonica dai documenti valutati."""
    docs = _load_documents(documents_path)
    if not docs:
        click.echo("  Nessun documento trovato.")
        return

    config = load_config()
    extracted_dir = config["storage"]["extracted_path"]

    from studygraph.knowledge_base import build_knowledge_base

    stats = build_knowledge_base(
        documents=docs,
        extracted_dir=extracted_dir,
        output_dir=output_dir,
        only_candidates=only_candidates,
    )

    click.echo(f"  Knowledge base costruita: {stats['kb_dir']}")
    click.echo(f"  Documenti esportati: {stats['exported']}")
    click.echo(f"  Esclusi: {stats['excluded']}")
    click.echo(f"  Corsi: {stats['courses']}")
    click.echo(f"  Markdown validi: {stats['valid_markdown']}")
    if stats.get("too_short"):
        click.echo(f"  Troppo corti: {stats['too_short']}")


@main.command()
@click.argument("kb_dir", type=click.Path(exists=True))
@click.option("--chunk-size", default=1000, help="Dimensione target chunk in caratteri")
@click.option("--overlap", default=150, help="Overlap tra chunk in caratteri")
@click.option("--min-chars", default=10, help="Caratteri minimi per includere un chunk")
@click.option("--force", is_flag=True, help="Ricostruisce l'indice anche se esiste gia")
def index_kb(kb_dir, chunk_size, overlap, min_chars, force):
    """Indicizza la knowledge base per la ricerca locale."""
    from studygraph.search_index import build_index

    stats = build_index(
        kb_dir=kb_dir,
        chunk_size=chunk_size,
        overlap=overlap,
        min_chars=min_chars,
        force=force,
    )

    click.echo("Knowledge base indicizzata:")
    click.echo(f"  documenti: {stats['documents']}")
    click.echo(f"  chunk: {stats['chunks']}")
    click.echo(f"  termini: {stats['terms']}")
    click.echo(f"  indice: {stats['index_dir']}")


@main.command()
@click.argument("kb_dir", type=click.Path(exists=True))
@click.option("--provider", default="mock", help="Embedding provider (mock, openai-compatible)")
@click.option("--model", default="", help="Nome modello embedding")
@click.option("--batch-size", default=32, help="Batch size per embedding API")
@click.option("--force", is_flag=True, help="Forza ricostruzione indice vettoriale")
@click.option("--config", "cfg_path", default="config.yaml", help="Percorso file config YAML")
@click.option("--dry-run", is_flag=True, help="Usa mock embeddings")
def embed_kb(kb_dir, provider, model, batch_size, force, cfg_path, dry_run):
    """Genera embedding vettoriali per la knowledge base."""
    from studygraph.vector_index import build_vector_index

    config = load_config(cfg_path)
    if provider != "mock":
        config["embedding"]["provider"] = provider
    if model:
        config["embedding"]["model"] = model

    try:
        stats = build_vector_index(
            kb_dir=kb_dir,
            config=config,
            provider=provider,
            model=model,
            batch_size=batch_size,
            force=force,
            dry_run=dry_run,
        )
    except FileNotFoundError as e:
        click.echo(f"  Errore: {e}")
        return

    click.echo("Knowledge base embedded:")
    click.echo(f"  chunk: {stats['chunks']}")
    click.echo(f"  dimensioni: {stats['dimensions']}")
    click.echo(f"  provider: {stats['provider']}")
    click.echo(f"  indice: {stats['index_dir']}")


@main.command()
@click.argument("query", type=str)
@click.option("--kb-dir", default="data/output/knowledge_base", help="Directory della knowledge base")
@click.option("--course", default=None, help="Filtra risultati per corso")
@click.option("--top-k", default=5, help="Numero di risultati")
@click.option("--json", "output_json", is_flag=True, help="Output in formato JSON")
@click.option("--mode", default="lexical", type=click.Choice(["lexical", "semantic", "hybrid"]), help="Modalita di ricerca")
@click.option("--semantic-weight", default=0.45, help="Peso semantic in hybrid mode (0-1)")
@click.option("--vector-index", default=None, help="Path vector index (default: kb_dir/vector_index)")
@click.option("--config", "cfg_path", default="config.yaml", help="File config per embedding")
@click.option("--dry-run", is_flag=True, help="Usa mock embeddings per semantic/hybrid mode")
def search_kb(query, kb_dir, course, top_k, output_json, mode, semantic_weight, vector_index, cfg_path, dry_run):
    """Cerca nella knowledge base indicizzata."""
    if mode == "lexical":
        from studygraph.search import search

        results = search(
            query=query,
            index_dir=str(Path(kb_dir) / "search_index"),
            course=course,
            top_k=top_k,
        )
    else:
        config = load_config(cfg_path)
        vi = vector_index or str(Path(kb_dir) / "vector_index")

        if mode == "semantic":
            from studygraph.vector_search import semantic_search

            results = semantic_search(
                query=query,
                vector_index_dir=vi,
                config=config,
                course=course,
                top_k=top_k,
                dry_run=dry_run,
            )
        elif mode == "hybrid":
            from studygraph.hybrid_search import hybrid_search

            results = hybrid_search(
                query=query,
                index_dir=str(Path(kb_dir) / "search_index"),
                vector_index_dir=vi,
                config=config,
                course=course,
                top_k=top_k,
                semantic_weight=semantic_weight,
                dry_run=dry_run,
            )

    if output_json:
        click.echo(json.dumps(results, indent=2, ensure_ascii=False))
        return

    if not results:
        click.echo(f"Nessun risultato per: {query}")
        return

    click.echo(f"\nQuery: {query}  [modalita: {mode}]")
    if mode != "lexical":
        click.echo(f"  indice vettoriale: {vi}")
    for i, r in enumerate(results, 1):
        score_type = r.get("score_type", mode)
        click.echo(f"[{i}] {r['filename']} -- {score_type} score {r['score']:.3f}")
        click.echo(f"  Corso: {r['course']}")
        click.echo(f"  Argomento: {r['topic']}")
        click.echo(f"  Percorso: {r['markdown_path']}")
        click.echo(f"  Estratto:")
        click.echo(f"    {r['snippet']}")
        click.echo("")


@main.command()
@click.argument("question", type=str)
@click.option("--kb-dir", default="data/output/knowledge_base", help="Directory della knowledge base")
@click.option("--mode", default="hybrid", type=click.Choice(["lexical", "semantic", "hybrid"]), help="Modalita di retrieval")
@click.option("--course", default=None, help="Filtra risultati per corso")
@click.option("--top-k", default=5, help="Numero di chunk da recuperare")
@click.option("--max-context-chars", default=6000, help="Caratteri massimi per il contesto")
@click.option("--min-score", default=0.0, help="Score minimo per includere un chunk nel contesto")
@click.option("--dry-run", is_flag=True, help="Usa mock QA (estrattivo, senza chiamata LLM)")
@click.option("--json", "output_json", is_flag=True, help="Output in formato JSON")
@click.option("--config", "cfg_path", default="config.yaml", help="File config per QA")
def ask_kb(question, kb_dir, mode, course, top_k, max_context_chars, min_score, dry_run, output_json, cfg_path):
    """Risponde a una domanda usando la knowledge base."""
    from studygraph.context_builder import build_context
    from studygraph.qa import answer_question
    from studygraph.citations import format_sources
    from studygraph.config import load_config

    config = load_config(cfg_path)

    index_dir = str(Path(kb_dir) / "search_index")
    vector_index_dir = str(Path(kb_dir) / "vector_index")

    if mode == "lexical":
        from studygraph.search import search as do_search
        results = do_search(query=question, index_dir=index_dir, course=course, top_k=top_k)
    elif mode == "semantic":
        if not Path(vector_index_dir).exists():
            click.echo("  Errore: vector_index non trovato. Esegui embed-kb prima.")
            return
        from studygraph.vector_search import semantic_search
        results = semantic_search(query=question, vector_index_dir=vector_index_dir,
                                   config=config, course=course, top_k=top_k, dry_run=dry_run)
    else:
        if not Path(vector_index_dir).exists():
            click.echo("  Errore: vector_index non trovato. Esegui embed-kb prima.")
            return
        from studygraph.hybrid_search import hybrid_search
        results = hybrid_search(query=question, index_dir=index_dir,
                                 vector_index_dir=vector_index_dir, config=config,
                                 course=course, top_k=top_k, dry_run=dry_run)

    context_bundle = build_context(
        results=results,
        max_chars=max_context_chars,
        min_score=min_score,
        index_dir=index_dir,
    )

    answer = answer_question(
        question=question,
        context_bundle=context_bundle,
        config=config,
        dry_run=dry_run,
    )

    if output_json:
        click.echo(json.dumps(answer, indent=2, ensure_ascii=False))
        return

    click.echo(f"\nDomanda: {question}  [mode: {mode}]")

    if answer["answer_type"] == "no_answer":
        click.echo(f"\n{answer['answer']}")
        click.echo(f"\nTipo: no_answer (confidenza: {answer['confidence']})")
        return

    click.echo(f"\nRisposta:")
    click.echo(f"{answer['answer']}")
    click.echo(f"\nConfidenza: {answer['confidence']}")
    click.echo(f"Tipo: {answer['answer_type']}")

    if answer.get("citation_check", {}).get("valid") is False:
        click.echo("  ⚠️  Citazioni invalide: ", nl=False)
        inv = answer["citation_check"].get("invalid_citations", [])
        if inv:
            click.echo(f"citazioni inesistenti {inv}")

    sources = answer.get("sources", [])
    if sources:
        click.echo(f"\n{format_sources(sources)}")


main.add_command(ask_kb, "ask")


@main.command(name="evaluate-retrieval")
@click.argument("kb_dir", type=str)
@click.argument("dataset", type=str)
@click.option("--modes", default="lexical,semantic,hybrid", help="Modalita da confrontare, separate da virgola")
@click.option("--top-k", default=5, help="Numero di risultati da considerare")
@click.option("--course", default=None, help="Filtra per corso")
@click.option("--output-dir", default="data/output/eval", help="Directory di output per i report")
@click.option("--dry-run", is_flag=True, help="Usa mock embedding per modalita semantic/hybrid")
@click.option("--json", "output_json", is_flag=True, help="Output in formato JSON")
def evaluate_retrieval_cmd(kb_dir, dataset, modes, top_k, course, output_dir, dry_run, output_json):
    """Valuta il retrieval (lexical/semantic/hybrid) su un dataset di domande."""
    from studygraph.config import load_config

    config = load_config()
    mode_list = [m.strip() for m in modes.split(",") if m.strip()]

    questions = load_eval_dataset(dataset)

    if course:
        questions = [q for q in questions if q.get("course") == course]

    if not questions:
        click.echo("Nessuna domanda nel dataset dopo il filtro.")
        return

    result = evaluate_retrieval(
        kb_dir=kb_dir, dataset=questions, modes=mode_list,
        top_k=top_k, dry_run=dry_run, config=config,
    )

    paths = write_retrieval_report(result, output_dir)

    if output_json:
        click.echo(json.dumps(result["summary"], indent=2, ensure_ascii=False))
        return

    click.echo(f"Valutazione retrieval completata ({len(questions)} domande).")
    for m in mode_list:
        s = result["summary"].get(m, {})
        if s:
            click.echo(f"  {m}: top-1={s.get('top1_accuracy')}, MRR={s.get('mrr')}, avg={s.get('avg_time_ms')}ms")
    click.echo(f"Report salvati in: {output_dir}/")
    for k, v in paths.items():
        click.echo(f"  {v}")


@main.command()
@click.argument("kb_dir", type=str)
@click.argument("dataset", type=str)
@click.option("--mode", default="hybrid", type=click.Choice(["lexical", "semantic", "hybrid"]), help="Modalita di retrieval")
@click.option("--top-k", default=5, help="Numero di chunk da recuperare")
@click.option("--course", default=None, help="Filtra per corso")
@click.option("--output-dir", default="data/output/eval", help="Directory di output per i report")
@click.option("--dry-run", is_flag=True, help="Usa mock QA (estrattivo, senza chiamata LLM)")
@click.option("--json", "output_json", is_flag=True, help="Output in formato JSON")
def evaluate_qa_cmd(kb_dir, dataset, mode, top_k, course, output_dir, dry_run, output_json):
    """Valuta la QA (answer_type, citazioni, fonti) su un dataset di domande."""
    from studygraph.config import load_config

    config = load_config()

    questions = load_eval_dataset(dataset)

    if course:
        questions = [q for q in questions if q.get("course") == course]

    if not questions:
        click.echo("Nessuna domanda nel dataset dopo il filtro.")
        return

    result = evaluate_qa(
        kb_dir=kb_dir, dataset=questions, mode=mode,
        top_k=top_k, dry_run=dry_run, config=config,
    )

    paths = write_qa_report(result, output_dir)

    if output_json:
        click.echo(json.dumps(result["summary"], indent=2, ensure_ascii=False))
        return

    s = result["summary"]
    click.echo(f"Valutazione QA completata ({len(questions)} domande, modalita={mode}).")
    click.echo(f"  Answer type accuracy: {s.get('answer_type_accuracy')}")
    click.echo(f"  No-answer accuracy: {s.get('no_answer_accuracy')}")
    click.echo(f"  Citation validity: {s.get('citation_validity_rate')}")
    click.echo(f"  Expected terms hit: {s.get('expected_terms_hit_rate')}")
    click.echo(f"  Source recall: {s.get('source_recall')}")
    click.echo(f"Report salvati in: {output_dir}/")
    for k, v in paths.items():
        click.echo(f"  {v}")


@main.command()
@click.option("--output-dir", default="data/output/demo", help="Directory per i file demo")
def demo(output_dir):
    """Esegue una demo end-to-end: genera dati sample, KB, indici, valutazione e risposta."""
    click.echo("\nStudyGraph Demo — costruzione knowledge base sample\n")
    steps = run_demo(output_dir=output_dir)
    click.echo("\nDemo completata.\n")


@main.command()
@click.argument("input_dir", type=click.Path(exists=True))
@click.option("--course", default=None, help="Nome del corso (auto-detect da sottocartelle se omesso)")
@click.option("--dry-run", is_flag=True, help="Usa score euristici + mock embedding (nessuna API key necessaria)")
@click.option("--output-dir", default="data/output", help="Directory di output")
@click.option("--skip-export", is_flag=True, help="Salta export fisico dei PDF")
@click.option("--with-embed-real", is_flag=True, help="Usa provider embedding reale invece di mock")
def build(input_dir, course, dry_run, output_dir, skip_export, with_embed_real):
    """Pipeline completa: audit -> export -> KB -> indice -> embedding."""
    click.echo("\nStudyGraph Build — pipeline completa\n")
    steps = run_build(
        input_dir=input_dir, course=course, dry_run=dry_run,
        output_dir=output_dir, skip_export=skip_export,
        with_embed_real=with_embed_real,
    )
    click.echo("\nBuild completata.\n")


@main.command()
@click.option("--port", default=8111, help="Porta del server web")
@click.option("--host", default="127.0.0.1", help="Host del server")
def web(port, host):
    """Avvia l'interfaccia web locale (upload, dashboard, search, ask)."""
    import uvicorn
    from studygraph.app import web_app

    click.echo(f"\n  StudyGraph Web UI: http://{host}:{port}\n")
    uvicorn.run(web_app, host=host, port=port, log_level="info")


@main.command()
@click.option("--port", default=8111, help="Porta del server web")
@click.option("--host", default="127.0.0.1", help="Host del server")
def start(port, host):
    """Avvia StudyGraph: controlla i requisiti, lancia web UI e apre il browser."""
    import sys as _sys
    import time
    import threading
    import webbrowser
    import uvicorn
    from studygraph.app import web_app

    if _sys.version_info < (3, 10):
        click.echo("  Errore: StudyGraph richiede Python >= 3.10.")
        return

    click.echo("\n  StudyGraph — Build, search and ask questions on your study materials")
    click.echo(f"  Python {_sys.version_info.major}.{_sys.version_info.minor}.{_sys.version_info.micro}")
    click.echo(f"  Avvio web UI su http://{host}:{port} ...\n")

    def _run_server():
        uvicorn.run(web_app, host=host, port=port, log_level="warning")

    server_thread = threading.Thread(target=_run_server, daemon=True)
    server_thread.start()
    time.sleep(1.5)

    url = f"http://{host}:{port}"
    click.echo(f"  Apertura browser: {url}")
    webbrowser.open(url)

    click.echo("  Premi Ctrl+C per fermare il server.\n")
    try:
        while server_thread.is_alive():
            server_thread.join(1)
    except KeyboardInterrupt:
        click.echo("\n  Server fermato.")


def _resolve_courses(input_dir: str, explicit_course: str | None) -> list[str]:
    inp = Path(input_dir)
    if explicit_course:
        return [explicit_course]
    subdirs = [d.name for d in sorted(inp.iterdir()) if d.is_dir() and not d.name.startswith(".")]
    return subdirs if subdirs else [""]


def _sanitize_prefix(name: str) -> str:
    invalid = '<>:"/\\|?* '
    for c in invalid:
        name = name.replace(c, "_")
    return name


def _load_sources(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    records = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def _update_source_status(sources_path: str, source_id: str, status: str) -> None:
    records = _load_sources(sources_path)
    for r in records:
        if r["source_id"] == source_id:
            r["status"] = status
    with open(sources_path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _find_source_filename(sources: list[dict], source_id: str) -> str:
    for s in sources:
        if s["source_id"] == source_id:
            return s["filename"]
    return source_id


def _save_documents(records: list[dict], output_dir: str) -> None:
    path = Path(output_dir) / "documents.jsonl"
    with open(path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _load_documents(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    records = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def _update_dashboard(documents: list[dict], output_dir: str) -> None:
    generate_csv(documents, output_dir)
    generate_html(documents, output_dir)
    courses = set()
    for d in documents:
        c = d.get("course", "")
        if c:
            courses.add(c)
    for c in sorted(courses):
        course_docs = [d for d in documents if d.get("course") == c]
        prefix = _sanitize_prefix(c)
        generate_csv(course_docs, output_dir, prefix=prefix)
        generate_html(course_docs, output_dir, prefix=prefix)
