from pathlib import Path

import fitz


def extract_text(raw_path: str, extracted_dir: str, source_id: str) -> dict | None:
    src = Path(raw_path)
    if not src.exists():
        return None

    try:
        doc = fitz.open(str(src))
    except Exception:
        return None

    text_parts = []
    num_pages = len(doc)
    total_chars = 0
    empty_pages = 0
    for page in doc:
        t = page.get_text()
        text_parts.append(t)
        chars = len(t)
        total_chars += chars
        if chars < 50:
            empty_pages += 1

    full_text = "\n".join(text_parts)
    doc.close()

    extracted_dir_path = Path(extracted_dir)
    extracted_dir_path.mkdir(parents=True, exist_ok=True)
    out_path = extracted_dir_path / f"{source_id}.txt"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(full_text)

    lang = _detect_lang(full_text)
    empty_pages_ratio = empty_pages / max(num_pages, 1)
    char_count_per_page = total_chars / max(num_pages, 1)
    is_probably_scanned = total_chars < 500 and num_pages >= 3
    ocr_recommended = is_probably_scanned or empty_pages_ratio > 0.50

    return {
        "source_id": source_id,
        "num_pages": num_pages,
        "char_count": total_chars,
        "language": lang,
        "extracted_path": str(out_path),
        "empty_pages": empty_pages,
        "empty_pages_ratio": round(empty_pages_ratio, 4),
        "char_count_per_page": round(char_count_per_page, 1),
        "is_probably_scanned": is_probably_scanned,
        "ocr_recommended": ocr_recommended,
    }


def _detect_lang(text: str) -> str:
    try:
        from langdetect import detect

        sample = text[:2000].strip()
        if not sample:
            return "unknown"
        return detect(sample)
    except Exception:
        return "unknown"
