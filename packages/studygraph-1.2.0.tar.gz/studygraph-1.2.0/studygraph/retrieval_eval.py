import time

from studygraph.search import search
from studygraph.vector_search import semantic_search
from studygraph.hybrid_search import hybrid_search


def evaluate_retrieval(
    kb_dir: str,
    dataset: list[dict],
    modes: list[str] | None = None,
    top_k: int = 5,
    dry_run: bool = False,
    config: dict | None = None,
) -> dict:
    if modes is None:
        modes = ["lexical", "semantic", "hybrid"]

    index_dir = f"{kb_dir}/search_index"
    vector_index_dir = f"{kb_dir}/vector_index"

    per_mode = {}
    all_results = []

    for mode in modes:
        mode_results = []
        mode_times = []

        for q in dataset:
            qid = q["id"]
            question = q["question"]
            course = q.get("course") or None
            expected_sources = q.get("expected_sources", [])
            expected_behavior = q.get("expected_behavior", "answered")

            t0 = time.perf_counter()

            if mode == "lexical":
                results = search(question, index_dir, course=course, top_k=top_k)
            elif mode == "semantic":
                results = semantic_search(
                    question, vector_index_dir, config or {}, course=course,
                    top_k=top_k, dry_run=dry_run,
                )
            elif mode == "hybrid":
                results = hybrid_search(
                    question, index_dir, vector_index_dir, config or {},
                    course=course, top_k=top_k, dry_run=dry_run,
                )
            else:
                continue

            elapsed_ms = round((time.perf_counter() - t0) * 1000, 1)
            mode_times.append(elapsed_ms)

            result_filenames = [r.get("filename", "") for r in results]

            is_no_answer = expected_behavior == "no_answer"
            if is_no_answer:
                top1_hit = False
                top3_hit = False
            else:
                top1_hit = _check_source_hit(result_filenames[:1], expected_sources)
                top3_hit = _check_source_hit(result_filenames[:top_k], expected_sources)

            source_hit = 0.0
            if expected_sources and not is_no_answer:
                found = sum(
                    1 for es in expected_sources
                    if any(es in rf or rf in es for rf in result_filenames[:top_k])
                )
                source_hit = found / len(expected_sources)

            no_result_correctness = None
            if is_no_answer:
                no_result_correctness = len(results) == 0

            row = {
                "mode": mode,
                "question_id": qid,
                "question": question,
                "expected_behavior": expected_behavior,
                "expected_sources": expected_sources,
                "is_no_answer": is_no_answer,
                "top1_hit": top1_hit,
                "top3_hit": top3_hit,
                "source_hit": source_hit,
                "no_result_correctness": no_result_correctness,
                "time_ms": elapsed_ms,
                "result_count": len(results),
                "result_filenames": result_filenames,
            }
            mode_results.append(row)

        summary = _compute_summary(mode_results, mode_times)
        per_mode[mode] = summary
        all_results.extend(mode_results)

    return {
        "summary": per_mode,
        "results": all_results,
        "meta": {
            "modes": modes,
            "top_k": top_k,
            "dry_run": dry_run,
            "total_questions": len(dataset),
        },
    }


def _check_source_hit(result_filenames: list[str], expected_sources: list[str]) -> bool:
    if not expected_sources:
        return True
    return any(
        es in rf or rf in es
        for rf in result_filenames
        for es in expected_sources
    )


def _compute_summary(mode_results: list[dict], mode_times: list[float]) -> dict:
    total = len(mode_results)
    if total == 0:
        return {}

    top1 = sum(1 for r in mode_results if r["top1_hit"]) / total
    top3 = sum(1 for r in mode_results if r["top3_hit"]) / total

    answered = [r for r in mode_results if not r.get("is_no_answer", False)]
    answered_total = len(answered)
    top1_answered = sum(1 for r in answered if r["top1_hit"]) / answered_total if answered_total else 0.0
    top3_answered = sum(1 for r in answered if r["top3_hit"]) / answered_total if answered_total else 0.0

    mrr_total = 0.0
    mrr_count = 0
    no_result_correct = 0
    no_result_total = 0
    source_hit_sum = 0.0
    source_hit_count = 0

    for r in mode_results:
        if r["expected_sources"]:
            mrr_count += 1
            # MRR: 1/rank of first source hit
            rank = _first_source_rank(r["result_filenames"], r["expected_sources"])
            mrr_total += 1.0 / rank if rank > 0 else 0.0

            src_hit = r.get("source_hit", 0)
            source_hit_sum += src_hit
            source_hit_count += 1

        if r["no_result_correctness"] is not None:
            no_result_total += 1
            if r["no_result_correctness"]:
                no_result_correct += 1

    avg_time = round(sum(mode_times) / len(mode_times), 1) if mode_times else 0.0

    summary = {
        "top1_accuracy": round(top1, 3),
        "top3_hit_rate": round(top3, 3),
        "top1_accuracy_answered_only": round(top1_answered, 3),
        "top3_hit_rate_answered_only": round(top3_answered, 3),
        "mrr": round(mrr_total / max(mrr_count, 1), 3),
        "source_hit_rate": round(source_hit_sum / max(source_hit_count, 1), 3),
        "no_result_correctness": round(no_result_correct / max(no_result_total, 1), 3),
        "avg_time_ms": avg_time,
        "total_queries": total,
    }
    return summary


def _first_source_rank(result_filenames: list[str], expected_sources: list[str]) -> int:
    for i, rf in enumerate(result_filenames):
        for es in expected_sources:
            if es in rf or rf in es:
                return i + 1
    return 0
