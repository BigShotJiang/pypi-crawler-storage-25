from pathlib import Path

import click

from studygraph.config import load_config
from studygraph.ingest import ingest
from studygraph.extract import extract_text
from studygraph.quality import score_text_quality
from studygraph.dedup import compute_duplication_scores
from studygraph.scoring import score_document
from studygraph.decision import decide
from studygraph.dashboard import generate_csv, generate_html
from studygraph.export import export_physical
from studygraph.knowledge_base import build_knowledge_base
from studygraph.search_index import build_index
from studygraph.vector_index import build_vector_index


def _resolve_courses(input_dir: str, explicit_course: str | None) -> list[str]:
    inp = Path(input_dir)
    if explicit_course:
        return [explicit_course]
    subdirs = [d.name for d in sorted(inp.iterdir()) if d.is_dir() and not d.name.startswith(".")]
    return subdirs if subdirs else [""]


def _sanitize_prefix(name: str) -> str:
    invalid = '<>:"/\\|?* '
    for c in invalid:
        name = name.replace(c, "_")
    return name


def _load_sources(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    import json
    records = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def _load_documents(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    import json
    records = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def _find_source_filename(sources: list[dict], source_id: str) -> str:
    for s in sources:
        if s["source_id"] == source_id:
            return s["filename"]
    return source_id


def _update_source_status(sources_path: str, source_id: str, status: str) -> None:
    import json
    records = _load_sources(sources_path)
    for r in records:
        if r["source_id"] == source_id:
            r["status"] = status
    with open(sources_path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _save_documents(records: list[dict], output_dir: str) -> None:
    import json
    path = Path(output_dir) / "documents.jsonl"
    with open(path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def run_build(
    input_dir: str,
    course: str | None = None,
    dry_run: bool = False,
    output_dir: str = "data/output",
    skip_export: bool = False,
    with_embed_real: bool = False,
    config: dict | None = None,
) -> dict:
    steps = {}

    cfg = config or load_config()
    if dry_run:
        cfg["llm"]["enabled"] = False

    prompts_dir = Path(__file__).parent.parent / "prompts"
    cfg["doc_prompt_path"] = str(prompts_dir / "document_scorer.md")
    cfg["risk_prompt_path"] = str(prompts_dir / "policy_risk.md")

    raw_dir = cfg["storage"]["raw_path"]
    extracted_dir = cfg["storage"]["extracted_path"]
    out_dir = cfg["storage"]["output_path"]
    sources_path = str(Path(raw_dir).parent / "sources.jsonl")

    courses = _resolve_courses(input_dir, course)
    if not courses:
        click.echo("  Nessun corso trovato. Metti i PDF in sottocartelle o usa --course.")
        return {"error": "no_courses"}

    all_scored_docs = []
    for c in courses:
        click.echo(f"\n  Corso: {c}")
        if course:
            course_input = input_dir
            course_name = course
        else:
            course_input = str(Path(input_dir) / c) if c else input_dir
            course_name = c or "unnamed"

        click.echo(f"  [1/5] Ingesting documenti da {course_input}...")
        new_sources = ingest(
            input_dir=course_input,
            raw_dir=raw_dir,
            sources_path=sources_path,
            allowed_extensions=cfg["input"]["allowed_extensions"],
            course=course_name,
        )
        all_sources = _load_sources(sources_path)
        click.echo(f"    {len(new_sources)} nuovi, {len(all_sources)} totali")

        course_sources = [s for s in all_sources if s.get("course") == c or not s.get("course")]
        if not course_sources:
            click.echo(f"    Nessun documento per '{c}', skipping.")
            continue

        click.echo(f"  [2/5] Estrazione testo...")
        extracted_list = []
        for s in course_sources:
            meta = extract_text(raw_path=s["raw_path"], extracted_dir=extracted_dir, source_id=s["source_id"])
            if meta:
                extracted_list.append(meta)
                _update_source_status(sources_path, s["source_id"], "extracted")
        click.echo(f"    {len(extracted_list)} documenti estratti")

        click.echo(f"  [3/5] Scoring documenti...")
        dup_scores = compute_duplication_scores(course_sources, extracted_dir=extracted_dir)
        scored_docs = []
        for meta in extracted_list:
            sid = meta["source_id"]
            text_path = Path(meta["extracted_path"])
            full_text = text_path.read_text(encoding="utf-8") if text_path.exists() else ""
            quality = score_text_quality(full_text, extraction_meta=meta)
            meta.update(quality)
            scores = score_document(
                source_id=sid, filename=_find_source_filename(course_sources, sid),
                full_text=full_text, metadata=meta, course_name=course_name,
                config=cfg, dry_run=dry_run,
            )
            scores["duplication_score"] = dup_scores.get(sid, 0.0)
            result = decide(scores, cfg)
            scores["final_score"] = result["final_score"]
            scores["suggested_decision"] = result["decision"]
            scores["reason"] = result.get("reason", scores.get("doc_reason", ""))
            if not scores["reason"]:
                scores["reason"] = scores.get("risk_reason", "")
            scores.update({
                "page_count": meta.get("num_pages", 0),
                "char_count": meta.get("char_count", 0),
                "text_quality_score": meta.get("text_quality_score", 0),
                "is_probably_scanned": meta.get("is_probably_scanned", False),
                "extraction_warning": meta.get("extraction_warning", False),
                "language": meta.get("language", "unknown"),
                "manual_decision": "",
                "reviewer_note": "",
                "final_decision": scores["suggested_decision"],
            })
            scored_docs.append(scores)
            click.echo(f"    {scores['filename']}: {scores['suggested_decision']} ({scores['final_score']:.3f})")

        if scored_docs:
            generate_csv(scored_docs, output_dir, prefix=_sanitize_prefix(course_name))
            generate_html(scored_docs, output_dir, prefix=_sanitize_prefix(course_name))
            _save_documents(scored_docs, output_dir)
            all_scored_docs.extend(scored_docs)

    if all_scored_docs:
        generate_csv(all_scored_docs, output_dir)
        generate_html(all_scored_docs, output_dir)
    click.echo(f"\n  [4/5] Audit completato ({len(all_scored_docs)} documenti)")

    decisions = {}
    for d in all_scored_docs:
        dec = d["suggested_decision"]
        decisions[dec] = decisions.get(dec, 0) + 1
    click.echo(f"    Decisioni: {dict(decisions)}")
    steps["audit"] = {"total": len(all_scored_docs), "decisions": decisions}

    if not skip_export and all_scored_docs:
        click.echo("  Export documenti per decisione...")
        manifest_path = export_physical(all_scored_docs, _load_sources(sources_path), output_dir)
        steps["export"] = {"manifest": manifest_path}
        click.echo(f"    Manifest: {manifest_path}")

    if all_scored_docs:
        click.echo("  Costruzione knowledge base...")
        kb_stats = build_knowledge_base(documents=all_scored_docs, extracted_dir=extracted_dir, output_dir=output_dir)
        kb_dir = kb_stats["kb_dir"]
        steps["kb"] = kb_stats
        click.echo(f"    Documenti: {kb_stats['exported']}, KB: {kb_dir}")

        click.echo("  Indicizzazione per ricerca locale...")
        idx_stats = build_index(kb_dir=kb_dir, force=True)
        steps["index"] = idx_stats
        click.echo(f"    Chunk: {idx_stats['chunks']}, termini: {idx_stats['terms']}")

        embed_provider = "mock"
        if with_embed_real and not dry_run:
            embed_provider = cfg.get("embedding", {}).get("provider", "mock")
        click.echo(f"  Generazione embedding ({embed_provider})...")
        emb_stats = build_vector_index(
            kb_dir=kb_dir, config=cfg, provider=embed_provider,
            dry_run=(embed_provider == "mock"), force=True,
        )
        steps["embed"] = emb_stats
        click.echo(f"    Dimensioni: {emb_stats['dimensions']}, chunk: {emb_stats['chunks']}")

        click.echo(f"\n  Build completata. Se vuoi cercare:")
        click.echo(f"    studygraph ask \"La tua domanda\" --kb-dir {kb_dir} --mode hybrid")
        if dry_run or embed_provider == "mock":
            click.echo(f"    (aggiungi --dry-run per mock QA senza API key)")

    return steps
