from studygraph.search import search
from studygraph.vector_search import semantic_search
from studygraph.hybrid_search import hybrid_search
from studygraph.context_builder import build_context
from studygraph.qa import answer_question


def evaluate_qa(
    kb_dir: str,
    dataset: list[dict],
    mode: str = "hybrid",
    top_k: int = 5,
    dry_run: bool = False,
    config: dict | None = None,
) -> dict:
    index_dir = f"{kb_dir}/search_index"
    vector_index_dir = f"{kb_dir}/vector_index"
    if config is None:
        config = {}

    results = []

    for q in dataset:
        qid = q["id"]
        question = q["question"]
        course = q.get("course") or None
        expected_behavior = q.get("expected_behavior", "answered")
        expected_sources = q.get("expected_sources", [])
        expected_terms = q.get("expected_answer_contains", [])

        if mode == "lexical":
            search_results = search(question, index_dir, course=course, top_k=top_k)
        elif mode == "semantic":
            search_results = semantic_search(
                question, vector_index_dir, config, course=course, top_k=top_k, dry_run=dry_run,
            )
        else:
            search_results = hybrid_search(
                question, index_dir, vector_index_dir, config, course=course, top_k=top_k, dry_run=dry_run,
            )

        bundle = build_context(search_results, max_chars=6000, min_score=0.0, index_dir=index_dir)
        answer = answer_question(question, bundle, config, dry_run=dry_run)

        actual_type = answer.get("answer_type", "no_answer")
        behavior_match = actual_type == expected_behavior

        citation_check = answer.get("citation_check", {})
        citation_valid = citation_check.get("valid", True) if citation_check else True

        answer_text = answer.get("answer", "")
        answer_lower = answer_text.lower()
        terms_hit = [t for t in expected_terms if t.lower() in answer_lower]
        terms_miss = [t for t in expected_terms if t.lower() not in answer_lower]

        answer_sources = answer.get("sources", [])
        answer_filenames = [s.get("filename", "") for s in answer_sources]
        sources_found = [es for es in expected_sources if any(es in af or af in es for af in answer_filenames)]
        sources_missed = [es for es in expected_sources if not any(es in af or af in es for af in answer_filenames)]

        row = {
            "question_id": qid,
            "question": question,
            "expected_behavior": expected_behavior,
            "actual_answer_type": actual_type,
            "behavior_match": behavior_match,
            "citation_valid": citation_valid,
            "expected_terms_hit": terms_hit,
            "expected_terms_miss": terms_miss,
            "sources_found": sources_found,
            "sources_missed": sources_missed,
            "confidence": answer.get("confidence", 0),
            "answer_snippet": answer_text[:200],
        }
        results.append(row)

    summary = _compute_qa_summary(results, dataset)
    return {"summary": summary, "results": results, "meta": {"mode": mode, "top_k": top_k, "dry_run": dry_run, "total_questions": len(dataset)}}


def _compute_qa_summary(results: list[dict], dataset: list[dict]) -> dict:
    total = len(results)
    if total == 0:
        return {}

    behavior_match_count = sum(1 for r in results if r["behavior_match"])
    citation_valid_count = sum(1 for r in results if r["citation_valid"])
    invalid_citation_count = sum(1 for r in results if not r["citation_valid"])

    needs_review_count = sum(1 for r in results if r["actual_answer_type"] == "needs_review")

    no_answer_total = sum(1 for r in results if r["expected_behavior"] == "no_answer")
    no_answer_correct = sum(1 for r in results if r["expected_behavior"] == "no_answer" and r["behavior_match"])

    source_recall_total = 0
    source_recall_hits = 0
    for r in results:
        src_found = len(r["sources_found"])
        src_missed = len(r["sources_missed"])
        src_total = src_found + src_missed
        if src_total > 0:
            source_recall_total += 1
            if src_found == src_total:
                source_recall_hits += 1

    terms_hit_across = sum(len(r["expected_terms_hit"]) for r in results)
    terms_total_count = sum(len(r["expected_terms_hit"]) + len(r["expected_terms_miss"]) for r in results)
    terms_hit_rate = terms_hit_across / max(terms_total_count, 1)

    return {
        "answer_type_accuracy": round(behavior_match_count / total, 3),
        "no_answer_accuracy": round(no_answer_correct / max(no_answer_total, 1), 3),
        "citation_validity_rate": round(citation_valid_count / total, 3),
        "expected_terms_hit_rate": round(terms_hit_rate, 3),
        "source_recall": round(source_recall_hits / max(source_recall_total, 1), 3),
        "invalid_citation_count": invalid_citation_count,
        "needs_review_count": needs_review_count,
        "total_queries": total,
    }
