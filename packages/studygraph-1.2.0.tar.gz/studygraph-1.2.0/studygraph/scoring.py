from importlib import resources
from pathlib import Path

from studygraph.llm import build_compact_extract, call_llm


def score_document(
    source_id: str,
    filename: str,
    full_text: str,
    metadata: dict,
    course_name: str,
    config: dict,
    dry_run: bool,
) -> dict:
    extract = build_compact_extract(full_text, metadata)

    doc_prompt = _read_prompt(config.get("doc_prompt_path"), "document_scorer.md")
    risk_prompt = _read_prompt(config.get("risk_prompt_path"), "policy_risk.md")

    doc_prompt += f"\n\nThe course name is: {course_name}"
    risk_prompt += f"\n\nThe course name is: {course_name}"

    doc_result = call_llm(doc_prompt, extract, config, dry_run)
    risk_result = call_llm(risk_prompt, extract, config, dry_run)

    if dry_run:
        doc_score = _dry_run_doc_score(course_name, metadata)
        risk_score = _dry_run_risk_score(metadata)
    else:
        doc_score = doc_result or _dry_run_doc_score(course_name, metadata)
        risk_score = risk_result or _dry_run_risk_score(metadata)

    return {
        "source_id": source_id,
        "filename": filename,
        "course": doc_score.get("course", course_name),
        "topic": doc_score.get("topic", ""),
        "course_relevance": doc_score.get("course_relevance", 0.5),
        "study_value": doc_score.get("study_value", 0.5),
        "clarity": doc_score.get("clarity", 0.5),
        "completeness": doc_score.get("completeness", 0.5),
        "originality": doc_score.get("originality", 0.5),
        "actionability": doc_score.get("actionability", 0.5),
        "privacy_risk": risk_score.get("privacy_risk", 0.2),
        "copyright_risk": risk_score.get("copyright_risk", 0.2),
        "academic_reliability_risk": risk_score.get("academic_reliability_risk", 0.2),
        "doc_reason": doc_score.get("reason", ""),
        "risk_reason": risk_score.get("reason", ""),
    }


def _read_prompt(path: str | None, resource_name: str) -> str:
    if path and Path(path).exists():
        return Path(path).read_text(encoding="utf-8")
    return resources.files("studygraph.prompts").joinpath(resource_name).read_text(encoding="utf-8")


def _dry_run_doc_score(course: str, metadata: dict | None = None) -> dict:
    meta = metadata or {}
    char_count = meta.get("char_count", 0)
    quality = meta.get("text_quality_score", 0.5)
    is_scanned = meta.get("is_probably_scanned", False)
    empty_ratio = meta.get("empty_pages_ratio", 0)

    if char_count == 0 or quality == 0:
        return {
            "course": course,
            "topic": "empty document",
            "course_relevance": 0.0,
            "study_value": 0.0,
            "clarity": 0.0,
            "completeness": 0.0,
            "originality": 0.0,
            "actionability": 0.0,
            "reason": "Dry-run: empty or unreadable document",
        }

    if is_scanned or empty_ratio > 0.50 or quality < 0.35:
        return {
            "course": course,
            "topic": "scanned / low quality",
            "course_relevance": 0.3,
            "study_value": 0.2,
            "clarity": 0.15,
            "completeness": 0.15,
            "originality": 0.2,
            "actionability": 0.1,
            "reason": "Dry-run: scanned or low-quality document (OCR recommended)",
        }

    length_bonus = min(0.1, char_count / 200000)
    quality_bonus = max(0, quality - 0.5) * 0.3

    return {
        "course": course,
        "topic": "dry-run topic",
        "course_relevance": round(0.55 + length_bonus + quality_bonus, 4),
        "study_value": round(0.50 + length_bonus + quality_bonus, 4),
        "clarity": round(0.60 + quality_bonus, 4),
        "completeness": round(0.45 + length_bonus + quality_bonus, 4),
        "originality": round(0.40 + quality_bonus, 4),
        "actionability": round(0.35 + quality_bonus, 4),
        "reason": "Dry-run heuristic score (no LLM call)",
    }


def _dry_run_risk_score(metadata: dict | None = None) -> dict:
    meta = metadata or {}
    char_count = meta.get("char_count", 0)

    if char_count == 0:
        return {
            "privacy_risk": 0.0,
            "copyright_risk": 0.0,
            "academic_reliability_risk": 0.0,
            "reason": "Dry-run heuristic score (empty document)",
        }

    return {
        "privacy_risk": 0.10,
        "copyright_risk": 0.15,
        "academic_reliability_risk": 0.10,
        "reason": "Dry-run heuristic score (no LLM call)",
    }
