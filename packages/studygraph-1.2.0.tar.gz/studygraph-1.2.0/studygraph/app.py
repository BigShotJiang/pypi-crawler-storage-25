import json
import threading
from pathlib import Path

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse

from studygraph.config import load_config
from studygraph.search import search
from studygraph.vector_search import semantic_search
from studygraph.hybrid_search import hybrid_search
from studygraph.context_builder import build_context as build_ctx
from studygraph.qa import answer_question as do_qa
from studygraph.build import run_build
from studygraph.demo import run_demo
from studygraph import __version__

web_app = FastAPI(title="StudyGraph", version=__version__)

HERE = Path(__file__).parent
TEMPLATES_DIR = HERE / "templates"

_demo_loaded = False
_build_lock = threading.Lock()
_build_status: dict = {
    "state": "idle",
    "message": "",
    "course": "",
    "total_docs": 0,
    "error": "",
}


def _start_build_thread(input_dir: str, course: str | None, dry_run: bool) -> None:
    def _runner():
        global _build_status
        try:
            with _build_lock:
                _build_status["state"] = "running"
                _build_status["message"] = "Pipeline in corso: analisi, estrazione e scoring dei documenti..."
                _build_status["course"] = course or ""
                _build_status["error"] = ""

            stats = run_build(
                input_dir=input_dir, course=course, dry_run=dry_run,
                output_dir="data/output", skip_export=True,
                with_embed_real=False,
            )

            n = stats.get("audit", {}).get("total", 0)
            with _build_lock:
                _build_status["state"] = "complete"
                _build_status["message"] = f"Completata: {n} documenti processati."
                _build_status["total_docs"] = n
        except Exception as e:
            with _build_lock:
                _build_status["state"] = "error"
                _build_status["message"] = f"Build fallita: {e}"
                _build_status["error"] = str(e)

    t = threading.Thread(target=_runner, daemon=True)
    t.start()


def _ensure_demo_kb() -> bool:
    global _demo_loaded
    if _demo_loaded:
        return False
    kb_catalog = _kb_path() / "catalog.json"
    if kb_catalog.exists():
        _demo_loaded = True
        return False
    print("  [StudyGraph] Knowledge base non trovata, avvio demo...")
    try:
        run_demo(output_dir="data/output")
        _demo_loaded = True
        print("  [StudyGraph] Demo caricata.")
        return True
    except Exception as e:
        print(f"  [StudyGraph] Errore durante il caricamento della demo: {e}")
        return False


@web_app.on_event("startup")  # type: ignore
async def on_startup():
    _ensure_demo_kb()


@web_app.get("/run-demo", response_class=HTMLResponse)
async def trigger_demo(request: Request):
    ok = _ensure_demo_kb()
    if ok:
        return RedirectResponse(url="/?msg=demo_loaded", status_code=303)
    return RedirectResponse(url="/?msg=demo_exists", status_code=303)


def _render(name: str, ctx: dict) -> str:
    from jinja2 import Environment, FileSystemLoader
    env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)))
    tpl = env.get_template(name)
    return tpl.render(ctx)


def _docs_path(output_dir: str = "data/output") -> Path:
    return Path(output_dir) / "documents.jsonl"


def _kb_path() -> Path:
    return Path("data/output/knowledge_base")


def _load_catalog() -> list[dict]:
    p = _kb_path() / "catalog.json"
    if not p.exists():
        return []
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _load_docs(output_dir: str = "data/output") -> list[dict]:
    p = _docs_path(output_dir)
    if not p.exists():
        return []
    docs = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                docs.append(json.loads(line))
    return docs


def _prepare_results(results: list[dict], index_dir: str) -> list[dict]:
    out = []
    for r in results:
        out.append({
            "filename": r.get("filename", ""),
            "course": r.get("course", ""),
            "topic": r.get("topic", ""),
            "score": r.get("score", 0),
            "score_type": r.get("score_type", "lexical"),
            "snippet": r.get("snippet", ""),
        })
    return out


@web_app.get("/", response_class=HTMLResponse)
async def explore_page(request: Request):
    msg = request.query_params.get("msg", "")
    flash = ""
    if msg == "demo_loaded":
        flash = "Demo caricata con successo. Esplora la knowledge base qui sotto."
    elif msg == "demo_exists":
        flash = "La knowledge base esiste gia. Usa i menu per esplorarla."
    catalog = _load_catalog()
    courses_grouped: dict[str, dict[str, list[dict]]] = {}
    for doc in catalog:
        c = doc.get("course", "Senza corso")
        t = doc.get("topic", "Generico")
        courses_grouped.setdefault(c, {}).setdefault(t, []).append(doc)

    course_list = []
    all_topics = set()
    graph_nodes: list[dict] = []
    graph_edges: list[dict] = []
    nid = 0

    for cname in sorted(courses_grouped):
        cid = nid
        graph_nodes.append({"id": nid, "label": cname, "type": "course"})
        nid += 1
        topic_list = []
        doc_count = 0
        for tname in sorted(courses_grouped[cname]):
            tid = nid
            graph_nodes.append({"id": nid, "label": tname, "type": "topic"})
            graph_edges.append({"source": cid, "target": nid})
            nid += 1
            docs = courses_grouped[cname][tname]
            doc_items = []
            for d in docs:
                did = nid
                graph_nodes.append({"id": nid, "label": d.get("filename", d.get("source_id", "")), "type": "doc"})
                graph_edges.append({"source": tid, "target": nid})
                nid += 1
                doc_items.append(d)
            topic_list.append({"name": tname, "documents": doc_items})
            doc_count += len(docs)
            all_topics.add(tname)
        course_list.append({"name": cname, "topics": topic_list, "doc_count": doc_count})

    stats = {
        "n_courses": len(course_list),
        "n_documents": len(catalog),
        "n_topics": len(all_topics),
    }

    html = _render("explore.html", {
        "request": {"url": {"path": str(request.url.path)}},
        "courses": course_list,
        "stats": stats,
        "graph_data": json.dumps({"nodes": graph_nodes, "edges": graph_edges}, ensure_ascii=False),
        "flash": flash,
    })
    return HTMLResponse(html)


@web_app.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request):
    html = _render("upload.html", {"request": {"url": {"path": str(request.url.path)}}})
    return HTMLResponse(html)


@web_app.post("/upload", response_class=HTMLResponse)
async def upload_and_build(
    request: Request,
    files: list[UploadFile] = File([]),
    course: str = Form(""),
    dry_run: bool = Form(False),
):
    input_dir = Path("data/input")
    if course:
        input_dir = input_dir / course
    input_dir.mkdir(parents=True, exist_ok=True)

    saved = []
    for f in files:
        if f.filename and f.filename.lower().endswith(".pdf"):
            dest = input_dir / f.filename
            with open(dest, "wb") as buffer:
                buffer.write(await f.read())
            saved.append(f.filename)

    if saved:
        course_name = course or None
        _start_build_thread(str(input_dir), course_name, dry_run)
        return RedirectResponse(url="/progress", status_code=303)
    else:
        return RedirectResponse(url="/upload?msg=nessun_pdf", status_code=303)


@web_app.get("/progress", response_class=HTMLResponse)
async def progress_page(request: Request):
    html = _render("progress.html", {
        "request": {"url": {"path": str(request.url.path)}},
    })
    return HTMLResponse(html)


@web_app.get("/build-status")
async def build_status_endpoint():
    with _build_lock:
        return JSONResponse({
            "state": _build_status["state"],
            "message": _build_status["message"],
            "course": _build_status["course"],
            "total_docs": _build_status["total_docs"],
            "error": _build_status["error"],
        })


@web_app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request, msg: str = ""):
    docs = _load_docs()
    decisions: dict[str, int] = {}
    for d in docs:
        dec = d.get("final_decision", d.get("suggested_decision", "reject"))
        decisions[dec] = decisions.get(dec, 0) + 1
    html = _render("dashboard.html", {
        "request": {"url": {"path": str(request.url.path)}},
        "documents": docs,
        "decisions": decisions,
        "message": msg,
    })
    return HTMLResponse(html)


@web_app.get("/search", response_class=HTMLResponse)
async def search_page(
    request: Request,
    q: str = "",
    mode: str = "hybrid",
    course: str = "",
    top_k: int = 5,
):
    results = []
    error = ""
    query = q.strip()
    if query:
        config = load_config()
        kb_dir = "data/output/knowledge_base"
        index_dir = str(Path(kb_dir) / "search_index")
        vector_index_dir = str(Path(kb_dir) / "vector_index")
        c = course.strip() or None

        if not Path(index_dir).exists():
            error = "Nessuna knowledge base trovata. Carica dei PDF dalla pagina Upload per iniziare."
        elif mode in ("semantic", "hybrid") and not Path(vector_index_dir).exists():
            error = "Indice vettoriale non trovato. Esegui prima una ricerca in modalita Lexical, oppure genera gli embedding dal terminale con: studygraph embed-kb"
        else:
            try:
                if mode == "lexical":
                    raw = search(query=query, index_dir=index_dir, course=c, top_k=top_k)
                elif mode == "semantic":
                    raw = semantic_search(
                        query=query, vector_index_dir=vector_index_dir,
                        config=config, course=c, top_k=top_k, dry_run=True,
                    )
                else:
                    raw = hybrid_search(
                        query=query, index_dir=index_dir,
                        vector_index_dir=vector_index_dir, config=config,
                        course=c, top_k=top_k, dry_run=True,
                    )
                results = _prepare_results(raw, index_dir)
            except Exception:
                results = []

    html = _render("search.html", {
        "request": {"url": {"path": str(request.url.path)}},
        "query": query,
        "mode": mode,
        "course": course,
        "top_k": top_k,
        "results": results,
        "error": error,
    })
    return HTMLResponse(html)


@web_app.get("/ask", response_class=HTMLResponse)
async def ask_page(
    request: Request,
    q: str = "",
    mode: str = "hybrid",
    course: str = "",
    top_k: int = 5,
):
    answer = None
    error = ""
    question = q.strip()
    if question:
        config = load_config()
        kb_dir = "data/output/knowledge_base"
        index_dir = str(Path(kb_dir) / "search_index")
        vector_index_dir = str(Path(kb_dir) / "vector_index")
        c = course.strip() or None
        is_dry = config["qa"]["provider"] == "mock"

        if not Path(index_dir).exists():
            error = "Nessuna knowledge base trovata. Carica dei PDF dalla pagina Upload per iniziare."
        elif mode in ("semantic", "hybrid") and not Path(vector_index_dir).exists():
            error = "Indice vettoriale non trovato. Esegui prima una domanda in modalita Lexical, oppure genera gli embedding dal terminale con: studygraph embed-kb"
        else:
            try:
                if mode == "lexical":
                    raw = search(query=question, index_dir=index_dir, course=c, top_k=top_k)
                elif mode == "semantic":
                    raw = semantic_search(
                        query=question, vector_index_dir=vector_index_dir,
                        config=config, course=c, top_k=top_k, dry_run=is_dry,
                    )
                else:
                    raw = hybrid_search(
                        query=question, index_dir=index_dir,
                        vector_index_dir=vector_index_dir, config=config,
                        course=c, top_k=top_k, dry_run=is_dry,
                    )

                ctx = build_ctx(results=raw, max_chars=6000, min_score=0.0, index_dir=index_dir)
                answer = do_qa(question=question, context_bundle=ctx, config=config, dry_run=is_dry)
            except Exception:
                answer = None

    html = _render("ask.html", {
        "request": {"url": {"path": str(request.url.path)}},
        "query": question,
        "mode": mode,
        "course": course,
        "top_k": top_k,
        "answer": answer,
        "error": error,
        "is_dry": is_dry if question else True,
    })
    return HTMLResponse(html)


def main():
    import uvicorn
    uvicorn.run(web_app, host="127.0.0.1", port=8111, log_level="info")


if __name__ == "__main__":
    main()
