import csv
from pathlib import Path


def generate_csv(records: list[dict], output_path: str, prefix: str = "") -> str:
    if not records:
        return ""

    fields = [
        "filename", "source_id", "course", "topic",
        "course_relevance", "study_value", "clarity", "completeness",
        "originality", "actionability",
        "privacy_risk", "copyright_risk", "academic_reliability_risk",
        "duplication_score", "final_score",
        "suggested_decision", "manual_decision", "final_decision", "reviewer_note", "reason",
        "page_count", "char_count", "text_quality_score",
        "is_probably_scanned", "extraction_warning", "language",
    ]

    out = Path(output_path)
    out.mkdir(parents=True, exist_ok=True)
    name = f"dashboard_{prefix}.csv" if prefix else "dashboard.csv"
    csv_path = out / name

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)

    return str(csv_path)


def generate_html(records: list[dict], output_path: str, prefix: str = "") -> str:
    out = Path(output_path)
    out.mkdir(parents=True, exist_ok=True)
    name = f"dashboard_{prefix}.html" if prefix else "dashboard.html"
    html_path = out / name

    rows_html = ""
    for r in records:
        final = r.get("final_decision", r.get("suggested_decision", "reject"))
        suggested = r.get("suggested_decision", "reject")
        manual = r.get("manual_decision", "")
        color_map = {
            "candidate": "#16a34a",
            "needs_review": "#ca8a04",
            "reject": "#dc2626",
            "duplicate": "#6b7280",
            "private_only": "#6366f1",
        }
        color = color_map.get(final, "#6b7280")
        score = r.get("final_score", 0)
        reason = r.get("reason", "")
        note = r.get("reviewer_note", "")
        reason_esc = reason.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        note_esc = note.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;") if note else ""
        rows_html += f"""
        <tr>
            <td>{r.get("filename", "")}</td>
            <td>{r.get("course", "")}</td>
            <td>{r.get("topic", "")}</td>
            <td>{r.get("study_value", "")}</td>
            <td>{score}</td>
            <td style="color:{color};font-weight:600">{final}</td>
            <td>{suggested}</td>
            <td>{manual}</td>
            <td style="max-width:200px">{note_esc}</td>
            <td style="max-width:300px">{reason_esc}</td>
            <td>{r.get("page_count", "")}</td>
            <td>{r.get("char_count", "")}</td>
            <td>{r.get("text_quality_score", "")}</td>
            <td>{"yes" if r.get("is_probably_scanned") else "no"}</td>
            <td>{"yes" if r.get("extraction_warning") else "no"}</td>
            <td>{r.get("language", "")}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StudyGraph Dashboard</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f8fafc;color:#1e293b;padding:2rem}}
h1{{font-size:1.5rem;margin-bottom:0.5rem}}
.subtitle{{color:#64748b;margin-bottom:1.5rem}}
table{{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
th{{background:#1e293b;color:#fff;padding:.75rem 1rem;text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em}}
td{{padding:.75rem 1rem;border-bottom:1px solid #e2e8f0;font-size:.875rem}}
tr:hover{{background:#f1f5f9}}
.filters{{margin-bottom:1rem;display:flex;gap:.5rem;flex-wrap:wrap}}
.filters select,.filters input{{padding:.5rem;border:1px solid #cbd5e1;border-radius:6px;font-size:.875rem}}
.summary{{display:flex;gap:1rem;margin-bottom:1rem;flex-wrap:wrap}}
.summary span{{background:#fff;padding:.5rem 1rem;border-radius:6px;box-shadow:0 1px 2px rgba(0,0,0,.05);font-size:.875rem}}
</style>
</head>
<body>
<h1>StudyGraph Dashboard</h1>
<p class="subtitle">{len(records)} document{(len(records)) != 1 and "i" or "o"} analizzati</p>
<div class="summary">
    <span>Candidate: {sum(1 for r in records if r.get("final_decision", r.get("suggested_decision")) == "candidate")}</span>
    <span>Needs review: {sum(1 for r in records if r.get("final_decision", r.get("suggested_decision")) == "needs_review")}</span>
    <span>Private only: {sum(1 for r in records if r.get("final_decision", r.get("suggested_decision")) == "private_only")}</span>
    <span>Reject: {sum(1 for r in records if r.get("final_decision", r.get("suggested_decision")) == "reject")}</span>
    <span>Duplicate: {sum(1 for r in records if r.get("final_decision", r.get("suggested_decision")) == "duplicate")}</span>
</div>
<div class="filters">
    <input type="text" id="search" placeholder="Cerca per filename..." onkeyup="filterTable()">
    <select id="decisionFilter" onchange="filterTable()">
        <option value="">Tutte le decisioni</option>
        <option value="candidate">Candidate</option>
        <option value="needs_review">Needs review</option>
        <option value="private_only">Private only</option>
        <option value="reject">Reject</option>
        <option value="duplicate">Duplicate</option>
    </select>
</div>
<table>
<thead>
<tr>
    <th onclick="sortTable(0)">Filename</th>
    <th onclick="sortTable(1)">Corso</th>
    <th onclick="sortTable(2)">Argomento</th>
    <th onclick="sortTable(3)">Valore studio</th>
    <th onclick="sortTable(4)">Score finale</th>
    <th onclick="sortTable(5)">Decisione finale</th>
    <th onclick="sortTable(6)">Decisione auto</th>
    <th onclick="sortTable(7)">Decisione manuale</th>
    <th>Nota reviewer</th>
    <th>Motivo</th>
    <th>Pagine</th>
    <th>Caratteri</th>
    <th>Qualità testo</th>
    <th>Scansionato?</th>
    <th>Warning</th>
    <th>Lingua</th>
</tr>
</thead>
<tbody id="tableBody">{rows_html}
</tbody>
</table>
<script>
function filterTable(){{var s=document.getElementById('search').value.toLowerCase(),d=document.getElementById('decisionFilter').value,rows=document.querySelectorAll('#tableBody tr');rows.forEach(function(r){{var ok=true;if(d&&r.children[5].textContent.trim()!==d)ok=false;if(s&&!r.children[0].textContent.toLowerCase().includes(s))ok=false;r.style.display=ok?'':'none'}})}}
function sortTable(n){{var t=document.querySelector('table'),b=document.getElementById('tableBody'),r=Array.from(b.rows),d=r[0]&&r[0].children[n]?r[0].children[n].textContent:'';r.sort(function(a,b){{var x=a.children[n].textContent,y=b.children[n].textContent;var xv=parseFloat(x),yv=parseFloat(y);if(!isNaN(xv)&&!isNaN(yv))return xv-yv;return x.localeCompare(y)}});r.forEach(function(r){{b.appendChild(r)}})}}
</script>
</body>
</html>"""

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)

    return str(html_path)
