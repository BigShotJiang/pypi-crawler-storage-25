import re

MIN_CHARS = 200

YAML_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

def canonicalize(text: str, doc: dict) -> dict:
    frontmatter_yaml = ""
    body = text

    m = YAML_FRONTMATTER_RE.match(text)
    if m:
        frontmatter_yaml = m.group(0)
        body = text[m.end():]

    body = _normalize_headings(body)
    body = _remove_excess_whitespace(body)
    body = _remove_empty_pages(body)
    body = _ensure_document_heading(body, doc)

    frontmatter = _build_frontmatter(doc)
    full_text = frontmatter + body

    warnings = []
    if _is_too_short(body):
        warnings.append("too_short")

    return {"text": full_text, "warnings": warnings}


def _normalize_headings(text: str) -> str:
    text = re.sub(r"^#{1,6}(?!\s)", lambda m: m.group(0) + " ", text, flags=re.MULTILINE)
    text = re.sub(r"^#+\s*$", "", text, flags=re.MULTILINE)
    return text


def _remove_excess_whitespace(text: str) -> str:
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _remove_empty_pages(text: str) -> str:
    lines = text.split("\n")
    cleaned = []
    in_empty = False
    for line in lines:
        if line.strip() == "" and ("\f" in line or "Page" in line or in_empty):
            if line.strip() == "":
                if not in_empty:
                    in_empty = True
                    continue
                continue
            else:
                in_empty = True
                continue
        else:
            in_empty = False
        cleaned.append(line)
    return "\n".join(cleaned)


def _ensure_document_heading(text: str, doc: dict) -> str:
    stripped = text.strip()
    if not stripped:
        topic = doc.get("topic", doc.get("filename", "Documento"))
        return f"# {topic}\n\n"
    first_line = stripped.split("\n", 1)[0].strip()
    if not first_line.startswith("#"):
        topic = doc.get("topic", doc.get("filename", "Documento"))
        return f"# {topic}\n\n{stripped}"
    return stripped


def _is_too_short(text: str, min_chars: int = MIN_CHARS) -> bool:
    return len(text.strip()) < min_chars


def _build_frontmatter(doc: dict) -> str:
    fields = {
        "source_id": doc.get("source_id", ""),
        "filename": doc.get("filename", ""),
        "course": doc.get("course", ""),
        "topic": doc.get("topic", ""),
        "final_decision": doc.get("final_decision", ""),
        "final_score": doc.get("final_score", 0),
        "language": doc.get("language", "unknown"),
        "page_count": doc.get("page_count", 0),
        "char_count": doc.get("char_count", 0),
        "quality": doc.get("text_quality_score", 0),
    }
    yaml_lines = ["---"]
    for k, v in fields.items():
        yaml_lines.append(f"{k}: {v}")
    yaml_lines.append("---")
    yaml_lines.append("")
    return "\n".join(yaml_lines)
