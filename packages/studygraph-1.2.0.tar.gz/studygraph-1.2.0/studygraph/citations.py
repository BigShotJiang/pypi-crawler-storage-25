import re


def format_sources(sources: list[dict]) -> str:
    if not sources:
        return ""
    lines = ["Fonti:"]
    for s in sources:
        cid = s.get("citation_id", "?")
        fname = s.get("filename", "?")
        course = s.get("course", "?")
        topic = s.get("topic", "?")
        chunk_id = s.get("chunk_id", "?")
        lines.append(f"[{cid}] {fname} — {course} — {topic} — {chunk_id}")
    return "\n".join(lines)


def validate_citations(answer: str, sources: list[dict]) -> dict:
    no_answer_phrases = [
        "non ho trovato evidenza sufficiente",
        "non ho trovato informazioni",
        "no evidenza sufficiente",
        "non posso rispondere",
    ]

    is_no_answer = any(phrase in answer.lower() for phrase in no_answer_phrases)

    if is_no_answer:
        return {
            "valid": True,
            "missing_citations": False,
            "invalid_citations": [],
            "used_citation_ids": [],
        }

    found_ids = set()
    for match in re.finditer(r"\[(\d+)\]", answer):
        found_ids.add(int(match.group(1)))

    valid_ids = {s.get("citation_id", 0) for s in sources}
    invalid = [i for i in found_ids if i not in valid_ids]

    if invalid:
        return {
            "valid": False,
            "missing_citations": True,
            "invalid_citations": invalid,
            "used_citation_ids": sorted(found_ids & valid_ids),
        }

    if not found_ids:
        return {
            "valid": False,
            "missing_citations": True,
            "invalid_citations": [],
            "used_citation_ids": [],
        }

    return {
        "valid": True,
        "missing_citations": False,
        "invalid_citations": [],
        "used_citation_ids": sorted(found_ids),
    }
