import json
import re
from datetime import date
from pathlib import Path

from studygraph.chunking import chunk_markdown

STOPWORDS_IT = {
    "il", "lo", "la", "i", "gli", "le", "un", "una", "uno",
    "e", "ed", "a", "da", "di", "in", "con", "su", "per", "tra", "fra",
    "che", "non", "e", "sono", "ho", "ha", "come", "piu", "al",
    "del", "della", "dei", "degli", "delle", "alla", "alle",
    "si", "ci", "ne", "mi", "ti", "vi",
    "lo", "la", "li", "ma", "se", "o", "ad", "ha", "ho",
}

TOKEN_RE = re.compile(r"[^\w\s]")


def tokenize(text: str) -> list[str]:
    text = text.lower()
    text = TOKEN_RE.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()
    tokens = text.split()
    return [t for t in tokens if t not in STOPWORDS_IT and len(t) > 1]


def build_index(
    kb_dir: str,
    chunk_size: int = 1000,
    overlap: int = 150,
    min_chars: int = 100,
    force: bool = False,
) -> dict:
    kb_path = Path(kb_dir)
    catalog_path = kb_path / "catalog.json"

    if not catalog_path.exists():
        return {"documents": 0, "chunks": 0, "terms": 0, "index_dir": str(kb_path / "search_index")}

    index_dir = kb_path / "search_index"
    if index_dir.exists() and not force:
        meta_path = index_dir / "index_meta.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                return meta
            except (json.JSONDecodeError, OSError):
                pass

    index_dir.mkdir(parents=True, exist_ok=True)

    with open(catalog_path, encoding="utf-8") as f:
        catalog: list[dict] = json.load(f)

    all_chunks: list[dict] = []
    doc_records: list[dict] = []
    terms: dict[str, list[str]] = {}

    for record in catalog:
        md_path = kb_path / record.get("markdown_path", "")
        if not md_path.exists():
            continue

        text = md_path.read_text(encoding="utf-8")
        metadata = {
            "source_id": record.get("source_id", ""),
            "filename": record.get("filename", ""),
            "course": record.get("course", ""),
            "topic": record.get("topic", ""),
            "markdown_path": record.get("markdown_path", ""),
        }

        chunks = chunk_markdown(text, metadata, chunk_size=chunk_size, overlap=overlap, min_chars=min_chars)

        for chunk in chunks:
            tokens = tokenize(chunk["text"])
            chunk["tokens"] = tokens
            all_chunks.append(chunk)

            seen = set()
            for token in tokens:
                if token not in seen:
                    if token not in terms:
                        terms[token] = []
                    terms[token].append(chunk["chunk_id"])
                    seen.add(token)

        doc_records.append({
            "source_id": record.get("source_id", ""),
            "filename": record.get("filename", ""),
            "course": record.get("course", ""),
            "topic": record.get("topic", ""),
            "final_score": record.get("final_score", 0),
            "language": record.get("language", ""),
            "markdown_path": record.get("markdown_path", ""),
            "chunk_count": len(chunks),
        })

    _write_jsonl(index_dir / "chunks.jsonl", all_chunks)
    _write_jsonl(index_dir / "documents.jsonl", doc_records)

    terms_path = index_dir / "terms.json"
    with open(terms_path, "w", encoding="utf-8") as f:
        json.dump(terms, f, ensure_ascii=False)

    meta = {
        "version": "0.6.0",
        "created": date.today().isoformat(),
        "documents": len(doc_records),
        "chunks": len(all_chunks),
        "terms": len(terms),
        "chunk_size": chunk_size,
        "overlap": overlap,
    }
    meta_path = index_dir / "index_meta.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    return {
        "documents": meta["documents"],
        "chunks": meta["chunks"],
        "terms": meta["terms"],
        "index_dir": str(index_dir),
    }


def _write_jsonl(path: Path, records: list[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
