def decide(scores: dict, config: dict) -> dict:
    high_risk = config["scoring"]["high_risk_threshold"]
    dup_threshold = 0.90
    candidate_thr = config["scoring"]["candidate_threshold"]
    review_thr = config["scoring"]["needs_review_threshold"]

    if scores.get("privacy_risk", 0) >= high_risk:
        return _result(scores, "reject", "Alto rischio privacy")
    if scores.get("copyright_risk", 0) >= high_risk:
        return _result(scores, "reject", "Alto rischio copyright")
    if scores.get("academic_reliability_risk", 0) >= high_risk:
        return _result(scores, "needs_review", "Affidabilità accademica dubbia")
    if scores.get("duplication_score", 0) >= dup_threshold:
        return _result(scores, "duplicate", "Documento duplicato")

    risk_score = max(
        scores.get("privacy_risk", 0),
        scores.get("copyright_risk", 0),
        scores.get("academic_reliability_risk", 0),
    )

    final = (
        +0.30 * scores.get("course_relevance", 0)
        +0.25 * scores.get("study_value", 0)
        +0.15 * scores.get("clarity", 0)
        +0.15 * scores.get("completeness", 0)
        +0.10 * scores.get("originality", 0)
        +0.05 * scores.get("actionability", 0)
        -0.35 * risk_score
        -0.10 * scores.get("duplication_score", 0)
    )

    if final >= candidate_thr and risk_score < 0.40:
        return _result(scores, "candidate", "", final)
    elif final >= review_thr:
        return _result(scores, "needs_review", "", final)
    else:
        return _result(scores, "reject", "", final)


def _result(scores: dict, decision: str, reason: str, final_score: float | None = None) -> dict:
    if final_score is None:
        risk_score = max(
            scores.get("privacy_risk", 0),
            scores.get("copyright_risk", 0),
            scores.get("academic_reliability_risk", 0),
        )
        final_score = (
            +0.30 * scores.get("course_relevance", 0)
            +0.25 * scores.get("study_value", 0)
            +0.15 * scores.get("clarity", 0)
            +0.15 * scores.get("completeness", 0)
            +0.10 * scores.get("originality", 0)
            +0.05 * scores.get("actionability", 0)
            -0.35 * risk_score
            -0.10 * scores.get("duplication_score", 0)
        )

    return {
        "decision": decision,
        "final_score": round(final_score, 4),
        "reason": reason,
    }
