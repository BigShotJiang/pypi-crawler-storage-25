import os
from copy import deepcopy
from pathlib import Path

import yaml
from dotenv import load_dotenv


DEFAULT_CONFIG = {
    "project": {"name": "studygraph", "mode": "local_first"},
    "input": {"path": "./data/input", "max_documents": 50, "allowed_extensions": [".pdf"]},
    "storage": {
        "raw_path": "./data/raw",
        "extracted_path": "./data/extracted",
        "output_path": "./data/output",
    },
    "llm": {
        "enabled": True,
        "provider": "openai_compatible",
        "base_url": "https://api.openai.com/v1",
        "api_key_env": "STUDYGRAPH_API_KEY",
        "model": "gpt-4o-mini",
        "temperature": 0.1,
    },
    "scoring": {
        "risk_aggregation": "max",
        "candidate_threshold": 0.75,
        "needs_review_threshold": 0.55,
        "high_risk_threshold": 0.85,
    },
    "embedding": {
        "enabled": False,
        "provider": "mock",
        "base_url": "",
        "api_key_env": "STUDYGRAPH_EMBEDDING_API_KEY",
        "model": "",
        "dimensions": 384,
        "batch_size": 32,
    },
    "qa": {
        "enabled": True,
        "provider": "mock",
        "base_url": "",
        "model": "",
        "temperature": 0.0,
        "max_context_chars": 6000,
        "min_retrieval_score": 0.0,
        "api_key_env": "STUDYGRAPH_QA_API_KEY",
    },
}


def load_config(config_path: str | None = None) -> dict:
    _env_path = Path(".env.local")
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
    cfg = deepcopy(DEFAULT_CONFIG)
    if config_path and Path(config_path).exists():
        with open(config_path, encoding="utf-8") as f:
            loaded = yaml.safe_load(f) or {}
            _deep_merge(cfg, loaded)
    api_key = os.environ.get(cfg["llm"]["api_key_env"])
    if api_key:
        cfg["api_key"] = api_key
    else:
        cfg["api_key"] = None

    cfg["llm"]["base_url"] = _normalize_base_url(cfg["llm"].get("base_url", ""))

    base_url = os.environ.get("STUDYGRAPH_LLM_BASE_URL")
    if base_url:
        cfg["llm"]["base_url"] = _normalize_base_url(base_url)

    model = os.environ.get("STUDYGRAPH_LLM_MODEL")
    if model:
        cfg["llm"]["model"] = model

    embedding_base_url = os.environ.get("STUDYGRAPH_EMBEDDING_BASE_URL")
    if embedding_base_url:
        cfg["embedding"]["base_url"] = _normalize_base_url(embedding_base_url)

    embedding_model = os.environ.get("STUDYGRAPH_EMBEDDING_MODEL")
    if embedding_model:
        cfg["embedding"]["model"] = embedding_model

    qa_base_url = os.environ.get("STUDYGRAPH_QA_BASE_URL")
    if qa_base_url:
        cfg["qa"]["base_url"] = _normalize_base_url(qa_base_url)

    qa_model = os.environ.get("STUDYGRAPH_QA_MODEL")
    if qa_model:
        cfg["qa"]["model"] = qa_model

    qa_provider = os.environ.get("STUDYGRAPH_QA_PROVIDER")
    if qa_provider:
        cfg["qa"]["provider"] = qa_provider

    return cfg


def _normalize_base_url(base_url: str) -> str:
    base_url = (base_url or "").rstrip("/")
    if base_url.endswith("/chat/completions"):
        base_url = base_url[: -len("/chat/completions")]
    if base_url.endswith("/embeddings"):
        base_url = base_url[: -len("/embeddings")]
    return base_url


def _deep_merge(base: dict, override: dict) -> None:
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
