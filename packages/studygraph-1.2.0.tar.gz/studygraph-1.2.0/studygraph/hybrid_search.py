import json
from pathlib import Path

from studygraph.vector_search import semantic_search


def _load_index(index_dir: str) -> dict | None:
    idx = Path(index_dir)
    meta_path = idx / "index_meta.json"
    if not meta_path.exists():
        return None
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    chunks = []
    chunks_path = idx / "chunks.jsonl"
    if chunks_path.exists():
        with open(chunks_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    chunks.append(json.loads(line))
    terms_path = idx / "terms.json"
    terms = {}
    if terms_path.exists():
        terms = json.loads(terms_path.read_text(encoding="utf-8"))
    return {"meta": meta, "chunks": chunks, "terms": terms, "index_dir": index_dir}


def _compute_boosts(query_text: str, chunks: list[dict]) -> list[float]:
    q_lower = query_text.lower()
    boosts = [0.0] * len(chunks)
    for i, c in enumerate(chunks):
        topic = c.get("topic", "").lower()
        filename = c.get("filename", "").lower()
        course = c.get("course", "").lower()
        if topic and q_lower in topic:
            boosts[i] += 0.25
        if filename and q_lower in filename:
            boosts[i] += 0.15
        if course and q_lower in course:
            boosts[i] += 0.05
    return boosts


def hybrid_search(
    query: str,
    index_dir: str,
    vector_index_dir: str,
    config: dict,
    course: str | None = None,
    top_k: int = 5,
    semantic_weight: float = 0.45,
    dry_run: bool = False,
) -> list[dict]:
    if not query or not query.strip():
        return []

    from studygraph.search import search as lexical_search

    data = _load_index(index_dir)
    total_chunks = len(data["chunks"]) if data else 0

    lexical_results = lexical_search(
        query=query,
        index_dir=index_dir,
        course=course,
        top_k=max(total_chunks, 100),
    )

    semantic_results = semantic_search(
        query=query,
        vector_index_dir=vector_index_dir,
        config=config,
        course=course,
        top_k=max(total_chunks, 100),
        dry_run=dry_run,
    )

    if not lexical_results and not semantic_results:
        return []

    lexical_map = {r["chunk_id"]: r for r in lexical_results}
    semantic_map = {r["chunk_id"]: r for r in semantic_results}

    all_chunk_ids = set(lexical_map.keys()) | set(semantic_map.keys())

    all_chunks = data["chunks"] if data else []
    chunk_map = {c["chunk_id"]: c for c in all_chunks}

    lexical_max = max((r["score"] for r in lexical_results), default=1.0)
    semantic_max = max((r["score"] for r in semantic_results), default=1.0)

    scored = []
    for cid in all_chunk_ids:
        lex_score = lexical_map.get(cid, {}).get("score", 0.0)
        sem_score = semantic_map.get(cid, {}).get("score", 0.0)

        lexical_norm = lex_score / lexical_max if lexical_max > 0 else 0.0
        semantic_norm = (sem_score + 1.0) / 2.0

        chunk = chunk_map.get(cid, {})
        boost_list = _compute_boosts(query, [chunk]) if chunk else [0.0]
        boost = boost_list[0] if boost_list else 0.0

        hybrid = (
            (1.0 - semantic_weight) * lexical_norm
            + semantic_weight * semantic_norm
            + boost
        )

        source = lexical_map.get(cid) or semantic_map.get(cid) or {}
        snippet = source.get(
            "snippet",
            chunk.get("text", "")[:300] if chunk else "",
        )

        scored.append({
            "chunk_id": cid,
            "source_id": chunk.get("source_id", source.get("source_id", "")),
            "filename": chunk.get("filename", source.get("filename", "")),
            "course": chunk.get("course", source.get("course", "")),
            "topic": chunk.get("topic", source.get("topic", "")),
            "score": round(hybrid, 3),
            "score_type": "hybrid",
            "snippet": snippet,
            "markdown_path": chunk.get("markdown_path", source.get("markdown_path", "")),
        })

    scored.sort(key=lambda x: -x["score"])
    return scored[:top_k]
