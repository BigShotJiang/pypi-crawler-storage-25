import json
import shutil
from pathlib import Path


PLACEHOLDER_MARKERS = [
    "not included",
    "exceeds maximum size",
    "file not included",
    "file exceeds",
]

WHITELIST_EXTENSIONS = {".pdf", ".docx", ".txt", ".md"}


def ingest_telegram(export_path: str, input_dir: str, extensions: list[str] | None = None) -> dict:
    export_root = Path(export_path)
    input_path = Path(input_dir)
    input_path.mkdir(parents=True, exist_ok=True)

    exts = set(extensions) if extensions else WHITELIST_EXTENSIONS

    result_json = export_root / "result.json"
    if not result_json.exists():
        return {"copied": 0, "skipped_placeholder": 0, "skipped_extension": 0, "errors": 0, "files": []}

    try:
        with open(result_json, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        return {"copied": 0, "skipped_placeholder": 0, "skipped_extension": 0, "errors": 0, "files": [], "error": f"Invalid JSON: {e}"}

    copied = []
    skipped_placeholder = 0
    skipped_extension = 0
    errors = 0

    for chat in data.get("chats", {}).get("list", []):
        chat_name = chat.get("name", "unknown")
        for msg in chat.get("messages", []):
            file_val = msg.get("file")
            if not file_val or not isinstance(file_val, str):
                continue

            file_val = file_val.strip()

            if _is_placeholder(file_val):
                skipped_placeholder += 1
                continue

            source_path = export_root / file_val

            if not source_path.exists():
                skipped_placeholder += 1
                continue

            ext = source_path.suffix.lower()
            if ext not in exts:
                skipped_extension += 1
                continue

            course_dir = _sanitize_dirname(chat_name)
            dest_dir = input_path / course_dir
            dest_dir.mkdir(parents=True, exist_ok=True)

            dest_name = source_path.name
            dest = dest_dir / dest_name
            if dest.exists():
                stem = source_path.stem
                suffix = source_path.suffix
                dest = dest_dir / f"{stem}_{chat_name}_{dest_name}"

            try:
                shutil.copy2(str(source_path), str(dest))
                copied.append(str(dest))
            except Exception:
                errors += 1

    return {
        "copied": len(copied),
        "skipped_placeholder": skipped_placeholder,
        "skipped_extension": skipped_extension,
        "errors": errors,
        "files": copied,
    }


def _is_placeholder(file_val: str) -> bool:
    lower = file_val.lower()
    for marker in PLACEHOLDER_MARKERS:
        if marker in lower:
            return True
    return False


def _sanitize_dirname(name: str) -> str:
    invalid_chars = '<>:"/\\|?*'
    for c in invalid_chars:
        name = name.replace(c, "_")
    name = name.strip().rstrip(". ")
    return name if name else "unknown_chat"
