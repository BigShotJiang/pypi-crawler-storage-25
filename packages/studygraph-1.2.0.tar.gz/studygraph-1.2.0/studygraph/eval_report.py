import csv
import json
import os
from datetime import date


def write_retrieval_report(eval_result: dict, output_dir: str) -> dict:
    os.makedirs(output_dir, exist_ok=True)

    json_path = os.path.join(output_dir, "retrieval_eval.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(eval_result, f, indent=2, ensure_ascii=False)

    csv_path = os.path.join(output_dir, "retrieval_eval.csv")
    _write_retrieval_csv(eval_result, csv_path)

    md_path = os.path.join(output_dir, "retrieval_eval.md")
    _write_retrieval_md(eval_result, md_path)

    return {"json": json_path, "csv": csv_path, "md": md_path}


def write_qa_report(eval_result: dict, output_dir: str) -> dict:
    os.makedirs(output_dir, exist_ok=True)

    json_path = os.path.join(output_dir, "qa_eval.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(eval_result, f, indent=2, ensure_ascii=False)

    csv_path = os.path.join(output_dir, "qa_eval.csv")
    _write_qa_csv(eval_result, csv_path)

    md_path = os.path.join(output_dir, "qa_eval.md")
    _write_qa_md(eval_result, md_path)

    return {"json": json_path, "csv": csv_path, "md": md_path}


def _write_retrieval_csv(eval_result: dict, path: str) -> None:
    results = eval_result.get("results", [])
    if not results:
        return

    fieldnames = [
        "mode", "question_id", "question", "expected_behavior",
        "top1_hit", "top3_hit", "source_hit", "no_result_correctness",
        "time_ms", "result_count",
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for r in results:
            writer.writerow(r)


def _write_qa_csv(eval_result: dict, path: str) -> None:
    results = eval_result.get("results", [])
    if not results:
        return

    fieldnames = [
        "question_id", "question", "expected_behavior", "actual_answer_type",
        "behavior_match", "citation_valid", "confidence",
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for r in results:
            row = {k: r.get(k, "") for k in fieldnames}
            writer.writerow(row)


def _write_retrieval_md(eval_result: dict, path: str) -> None:
    summary = eval_result.get("summary", {})
    meta = eval_result.get("meta", {})
    results = eval_result.get("results", [])
    modes = meta.get("modes", [])

    lines = [
        "# Retrieval Evaluation Report",
        "",
        f"Generato il {date.today()}.",
        f"Dataset: {meta.get('total_questions', 0)} domande, top-k={meta.get('top_k', 5)}, dry-run={meta.get('dry_run', False)}.",
        "",
        "## Summary",
        "",
        "| Mode | Top-1 | Top-1 (answered) | Top-3 | Top-3 (answered) | MRR | Source Hit | No-Result Corr. | Avg ms |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]

    for m in modes:
        s = summary.get(m, {})
        if not s:
            continue
        lines.append(
            f"| {m} | {s.get('top1_accuracy', 'N/A')} | "
            f"{s.get('top1_accuracy_answered_only', 'N/A')} | "
            f"{s.get('top3_hit_rate', 'N/A')} | "
            f"{s.get('top3_hit_rate_answered_only', 'N/A')} | "
            f"{s.get('mrr', 'N/A')} | "
            f"{s.get('source_hit_rate', 'N/A')} | "
            f"{s.get('no_result_correctness', 'N/A')} | "
            f"{s.get('avg_time_ms', 'N/A')} |"
        )

    lines.extend(["", "## Per-Query Results", ""])

    if results:
        lines.append("| Question ID | Mode | Expected | Top-1 Hit | Top-3 Hit | Source Hit | Time (ms) |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|")
        for r in results:
            lines.append(
                f"| {r['question_id']} | {r['mode']} | {r['expected_behavior']} | "
                f"{r['top1_hit']} | {r['top3_hit']} | {r['source_hit']} | {r['time_ms']} |"
            )

    failed = [r for r in results if not r["top1_hit"] and r["expected_behavior"] != "no_answer"]
    if failed:
        lines.extend(["", "## Error Analysis", ""])
        lines.append("Query con top-1 miss:")
        lines.append("")
        for r in failed:
            lines.append(f"- {r['mode']}: `{r['question']}` (id={r['question_id']}) — trovato: {r['result_filenames']}")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _write_qa_md(eval_result: dict, path: str) -> None:
    summary = eval_result.get("summary", {})
    meta = eval_result.get("meta", {})
    results = eval_result.get("results", [])

    lines = [
        "# QA Evaluation Report",
        "",
        f"Generato il {date.today()}.",
        f"Dataset: {meta.get('total_questions', 0)} domande, mode={meta.get('mode', 'hybrid')}, dry-run={meta.get('dry_run', False)}.",
        "",
        "## Summary",
        "",
        "| Metric | Value |",
        "|---|---:|",
        f"| Answer type accuracy | {summary.get('answer_type_accuracy', 'N/A')} |",
        f"| No-answer accuracy | {summary.get('no_answer_accuracy', 'N/A')} |",
        f"| Citation validity rate | {summary.get('citation_validity_rate', 'N/A')} |",
        f"| Expected terms hit rate | {summary.get('expected_terms_hit_rate', 'N/A')} |",
        f"| Source recall | {summary.get('source_recall', 'N/A')} |",
        f"| Invalid citation count | {summary.get('invalid_citation_count', 0)} |",
        f"| Needs review count | {summary.get('needs_review_count', 0)} |",
        "",
        "## Per-Query Results",
        "",
    ]

    if results:
        lines.append("| Question ID | Expected | Actual | Match | Citation Valid | Terms Hit |")
        lines.append("|---|---:|---:|---:|---:|---:|")
        for r in results:
            terms_hit = ", ".join(r.get("expected_terms_hit", [])) or "-"
            lines.append(
                f"| {r['question_id']} | {r['expected_behavior']} | "
                f"{r['actual_answer_type']} | {r['behavior_match']} | "
                f"{r['citation_valid']} | {terms_hit} |"
            )

    failed = [r for r in results if not r["behavior_match"]]
    if failed:
        lines.extend(["", "## Error Analysis", ""])
        lines.append("Query con comportamento errato:")
        lines.append("")
        for r in failed:
            lines.append(
                f"- `{r['question']}` (id={r['question_id']}): atteso={r['expected_behavior']}, "
                f"ottenuto={r['actual_answer_type']}"
            )

    invalid_src = [r for r in results if r.get("sources_missed")]
    if invalid_src:
        lines.append("")
        lines.append("Query con fonti mancanti:")
        for r in invalid_src:
            if r["sources_missed"]:
                lines.append(f"- {r['question_id']}: mancanti {r['sources_missed']}, trovate {r.get('sources_found', [])}")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
