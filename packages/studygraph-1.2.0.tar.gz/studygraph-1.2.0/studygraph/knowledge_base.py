import json
from pathlib import Path

from studygraph.canonicalize import canonicalize
from studygraph.catalog import generate_catalog

INVALID_PATH_CHARS = '<>:"/\\|?*'


def _sanitize(name: str) -> str:
    for c in INVALID_PATH_CHARS:
        name = name.replace(c, "_")
    name = name.strip().replace(" ", "_")
    return name if name else "unnamed"


def _filter_documents(documents: list[dict], only_candidates: bool = False) -> list[dict]:
    decisions = {"candidate"} if only_candidates else {"candidate", "needs_review"}
    return [d for d in documents if d.get("final_decision", d.get("suggested_decision", "")) in decisions]


def _export_per_course(
    documents: list[dict],
    extracted_dir: str,
    kb_dir: str,
) -> dict:
    extracted = Path(extracted_dir)
    docs_dir = Path(kb_dir) / "courses"

    stats = {"exported": 0, "too_short": 0, "valid_markdown": 0, "warnings": []}
    course_docs = {}

    for doc in documents:
        sid = doc.get("source_id", "")
        txt_path = extracted / f"{sid}.txt"
        if not txt_path.exists():
            continue

        text = txt_path.read_text(encoding="utf-8")
        if not text.strip():
            continue

        course = doc.get("course", "unknown")
        course_slug = _sanitize(course)

        if course_slug not in course_docs:
            course_docs[course_slug] = {"name": course, "documents": []}

        md_file_name = doc.get("filename", f"{sid}.pdf").rsplit(".", 1)[0] + ".md"
        md_file_slug = _sanitize(md_file_name.replace(".md", ""))
        if md_file_slug != md_file_name.replace(".md", ""):
            md_file_name = f"{md_file_slug}.md"

        md_dir = docs_dir / course_slug / "documents"
        md_dir.mkdir(parents=True, exist_ok=True)
        md_path = md_dir / md_file_name

        result = canonicalize(text, doc)
        md_path.write_text(result["text"], encoding="utf-8")

        if "too_short" in result["warnings"]:
            stats["too_short"] += 1
        else:
            stats["valid_markdown"] += 1

        stats["exported"] += 1
        course_docs[course_slug]["documents"].append({
            "source_id": sid,
            "filename": doc.get("filename", ""),
            "md_file": md_file_name,
            "topic": doc.get("topic", ""),
            "final_decision": doc.get("final_decision", ""),
            "final_score": doc.get("final_score", 0),
            "text_quality_score": doc.get("text_quality_score", 0),
            "page_count": doc.get("page_count", 0),
            "char_count": doc.get("char_count", 0),
            "language": doc.get("language", "unknown"),
        })

    return {"course_docs": course_docs, "stats": stats}


def _build_course_index(docs_list: list[dict], course_name: str, output_dir: Path) -> None:
    lines = [
        f"# {course_name}",
        "",
        "## Documenti nella knowledge base",
        "",
        "| Documento | Topic | Score | Qualità | Decisione |",
        "|---|---:|---:|---:|---|",
    ]
    for d in docs_list:
        md_link = f"[{d['md_file']}](documents/{d['md_file']})"
        lines.append(
            f"| {md_link} | {d['topic']} | {d['final_score']:.3f} "
            f"| {d['text_quality_score']:.2f} | {d['final_decision']} |"
        )

    short_docs = [d for d in docs_list if d["char_count"] and d["char_count"] < 200]
    if short_docs:
        lines.extend(["", "## Problemi rilevati", ""])
        for d in short_docs:
            lines.append(f"- Documento troppo corto (< 200 caratteri): `{d['md_file']}`")

    content = "\n".join(lines)
    idx_path = output_dir / "index.md"
    idx_path.write_text(content, encoding="utf-8")


def _build_topics(docs_list: list[dict], output_dir: Path) -> None:
    topics = {}
    for d in docs_list:
        topic = d["topic"].strip() if d.get("topic") else ""
        if not topic:
            topic = d["filename"].rsplit(".", 1)[0] if d.get("filename") else "unknown"
        if topic not in topics:
            topics[topic] = []
        topics[topic].append(d["source_id"])

    topics_path = output_dir / "topics.json"
    with open(topics_path, "w", encoding="utf-8") as f:
        json.dump(topics, f, indent=2, ensure_ascii=False)


def build_knowledge_base(
    documents: list[dict],
    extracted_dir: str,
    output_dir: str,
    only_candidates: bool = False,
) -> dict:
    filtered = _filter_documents(documents, only_candidates=only_candidates)

    kb_dir = Path(output_dir) / "knowledge_base"
    kb_dir.mkdir(parents=True, exist_ok=True)

    per_course = _export_per_course(filtered, extracted_dir, str(kb_dir))
    course_docs = per_course["course_docs"]
    stats = per_course["stats"]

    for slug, info in course_docs.items():
        course_out = kb_dir / "courses" / slug
        course_out.mkdir(parents=True, exist_ok=True)
        _build_course_index(info["documents"], info["name"], course_out)
        _build_topics(info["documents"], course_out)

    generate_catalog(documents, str(kb_dir), only_candidates=only_candidates)

    stats["courses"] = len(course_docs)
    stats["excluded"] = len(documents) - stats["exported"]
    stats["kb_dir"] = str(kb_dir)

    return stats
