from pathlib import Path


INVALID_PATH_CHARS = '<>:"/\\|?*'


def _sanitize(name: str) -> str:
    for c in INVALID_PATH_CHARS:
        name = name.replace(c, "_")
    name = name.strip().replace(" ", "_")
    return name if name else "unnamed"


def export_markdown(
    documents: list[dict],
    extracted_dir: str,
    output_dir: str,
) -> str:
    extracted = Path(extracted_dir)
    md_root = Path(output_dir) / "markdown"

    exported = 0
    for doc in documents:
        final_decision = doc.get("final_decision", doc.get("suggested_decision", "reject"))
        if final_decision not in ("candidate", "needs_review"):
            continue

        sid = doc.get("source_id", "")
        filename = doc.get("filename", f"{sid}.pdf")

        txt_path = extracted / f"{sid}.txt"
        if not txt_path.exists():
            continue

        text = txt_path.read_text(encoding="utf-8")
        if not text.strip():
            continue

        course = doc.get("course", "unknown")
        course_dir = _sanitize(course)
        md_dir = md_root / course_dir
        md_dir.mkdir(parents=True, exist_ok=True)

        md_name = filename.rsplit(".", 1)[0] + ".md"
        md_path = md_dir / md_name

        md_name_for_path = _sanitize(md_name.replace(".md", ""))
        if md_name_for_path != md_name.replace(".md", ""):
            md_path = md_dir / f"{md_name_for_path}.md"

        frontmatter = (
            f"---\n"
            f"source_id: {sid}\n"
            f"course: {course}\n"
            f"final_decision: {final_decision}\n"
            f"score: {doc.get('final_score', 0)}\n"
            f"language: {doc.get('language', 'unknown')}\n"
            f"---\n"
            f"\n"
            f"# {filename}\n"
            f"\n"
            f"{text}\n"
        )

        md_path.write_text(frontmatter, encoding="utf-8")
        exported += 1

    return str(md_root)
