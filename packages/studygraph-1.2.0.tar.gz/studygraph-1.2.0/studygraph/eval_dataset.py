import json
import os


def load_eval_dataset(path: str) -> list[dict]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"eval dataset not found: {path}")

    with open(path, encoding="utf-8") as f:
        raw = json.load(f)

    if not isinstance(raw, list):
        raise ValueError("eval dataset must be a JSON list")

    validated = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"item {i} is not a dict")

        qid = item.get("id", f"q_{i:03d}")
        question = item.get("question", "")
        if not question:
            raise ValueError(f"item {i}: 'question' is required")

        expected_sources = _to_list(item, "expected_sources")
        expected_answer_contains = _to_list(item, "expected_answer_contains")
        expected_behavior = item.get("expected_behavior", "answered")
        if expected_behavior not in ("answered", "no_answer"):
            raise ValueError(
                f"item {i}: expected_behavior must be 'answered' or 'no_answer', got '{expected_behavior}'"
            )

        validated.append({
            "id": qid,
            "question": question,
            "course": item.get("course", ""),
            "expected_sources": expected_sources,
            "expected_answer_contains": expected_answer_contains,
            "expected_behavior": expected_behavior,
        })

    return validated


def _to_list(item: dict, key: str) -> list:
    val = item.get(key, [])
    if isinstance(val, list):
        return val
    if isinstance(val, str):
        return [val]
    return []
