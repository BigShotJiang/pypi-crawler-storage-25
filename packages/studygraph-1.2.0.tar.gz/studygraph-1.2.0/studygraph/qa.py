import json
import os
import re
import urllib.error
import urllib.request

from studygraph.search_index import tokenize
from studygraph.citations import validate_citations

NO_ANSWER_PHRASE = "Non ho trovato evidenza sufficiente nella knowledge base per rispondere."


def answer_question(
    question: str,
    context_bundle: dict,
    config: dict,
    dry_run: bool = False,
) -> dict:
    if not context_bundle.get("sources"):
        return {
            "answer": NO_ANSWER_PHRASE,
            "confidence": 0.0,
            "answer_type": "no_answer",
            "sources": [],
            "citation_check": {"valid": True},
            "reason": "no context provided",
        }

    context = context_bundle.get("context", "")
    sources = context_bundle.get("sources", [])

    if not context.strip():
        return {
            "answer": NO_ANSWER_PHRASE,
            "confidence": 0.0,
            "answer_type": "no_answer",
            "sources": [],
            "citation_check": {"valid": True},
            "reason": "empty context",
        }

    provider = config.get("qa", {}).get("provider", "mock")

    if dry_run or provider == "mock":
        return _mock_answer(question, context, sources)

    api_key = config.get("api_key") or os.environ.get(
        config.get("qa", {}).get("api_key_env", ""), ""
    )
    base_url = config.get("qa", {}).get("base_url", "").rstrip("/")
    model = config.get("qa", {}).get("model", "")

    if not api_key or not base_url or not model:
        return _mock_answer(question, context, sources)

    return _llm_answer(question, context, sources, base_url, model, api_key, config)


def _mock_answer(
    question: str,
    context: str,
    sources: list[dict],
) -> dict:
    q_tokens = [t for t in tokenize(question) if len(t) > 1]
    if not q_tokens:
        return {
            "answer": NO_ANSWER_PHRASE,
            "confidence": 0.0,
            "answer_type": "no_answer",
            "sources": [],
            "citation_check": {"valid": True},
            "reason": "empty question tokens",
        }

    paragraphs = [p.strip() for p in context.split("\n\n") if p.strip()]
    if not paragraphs:
        paragraphs = [p.strip() for p in re.split(r"(?<=[.!?])\s+", context) if p.strip()]

    scored = []
    for p in paragraphs:
        p_lower = p.lower()
        unique_hits = len({t for t in q_tokens if t in p_lower})
        total_hits = sum(1 for t in q_tokens if t in p_lower)
        if unique_hits == 0:
            continue
        score = (unique_hits * unique_hits) / max(len(q_tokens), 1) + total_hits / max(len(q_tokens), 1)
        cid_match = re.search(r"\[(\d+)\]", p)
        cid = int(cid_match.group(1)) if cid_match else None
        scored.append((score, p, cid))

    if not scored:
        return {
            "answer": NO_ANSWER_PHRASE,
            "confidence": 0.0,
            "answer_type": "no_answer",
            "sources": [],
            "citation_check": {"valid": True},
            "reason": "no question terms found in context",
        }

    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best_para, best_cid = scored[0]

    if best_para:
        best_para = re.sub(r"\s+", " ", best_para).strip()

    confidence = round(min(best_score / 3.0, 1.0), 3)

    used_sources = []
    if best_cid is not None:
        used_sources = [s for s in sources if s.get("citation_id") == best_cid]

    if used_sources and not re.search(r"\[\d+\]", best_para):
        cid = used_sources[0]["citation_id"]
        best_para = best_para.rstrip(".!?") + f". [{cid}]"

    citation_check = validate_citations(best_para, used_sources)

    return {
        "answer": best_para,
        "confidence": confidence,
        "answer_type": "answered",
        "sources": used_sources,
        "citation_check": citation_check,
        "reason": "extractive paragraph — best match from retrieved chunks",
    }


def _llm_answer(
    question: str,
    context: str,
    sources: list[dict],
    base_url: str,
    model: str,
    api_key: str,
    config: dict,
) -> dict:
    temperature = config.get("qa", {}).get("temperature", 0.0)

    system_prompt = (
        "Rispondi alla domanda usando solo il contesto fornito.\n"
        "Se il contesto non contiene informazioni sufficienti, rispondi:\n"
        f'"{NO_ANSWER_PHRASE}"\n\n'
        "Ogni affermazione sostanziale deve avere una citazione tra parentesi quadre, es. [1].\n"
        "Non usare conoscenza esterna.\n"
        "Non inventare citazioni.\n"
        "Non aggiungere informazioni che non sono nel contesto."
    )

    user_prompt = f"DOMANDA:\n{question}\n\nCONTESTO:\n{context}"

    url = f"{base_url}/chat/completions"
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": temperature,
    }).encode("utf-8")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": "StudyGraph/0.8",
    }

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
        print(f"  [QA] API error: {e}")
        return _mock_answer(question, context, sources)

    try:
        answer_text = result["choices"][0]["message"]["content"]
    except (KeyError, IndexError) as e:
        print(f"  [QA] unexpected response: {e}")
        return _mock_answer(question, context, sources)

    is_no_answer = any(phrase in answer_text.lower() for phrase in [
        "non ho trovato evidenza sufficiente",
        "non ho trovato informazioni",
        "non posso rispondere",
    ])

    citation_check = validate_citations(answer_text, sources)

    if is_no_answer:
        return {
            "answer": answer_text,
            "confidence": 0.0,
            "answer_type": "no_answer",
            "sources": [],
            "citation_check": citation_check,
            "reason": "LLM indicated insufficient evidence",
        }

    return {
        "answer": answer_text,
        "confidence": 0.5,
        "answer_type": "needs_review" if not citation_check["valid"] else "answered",
        "sources": sources if citation_check["valid"] else [],
        "citation_check": citation_check,
        "reason": "LLM answer grounded in retrieved chunks",
    }
