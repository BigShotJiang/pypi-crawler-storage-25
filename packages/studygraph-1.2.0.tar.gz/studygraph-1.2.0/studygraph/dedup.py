from pathlib import Path


def compute_duplication_scores(
    sources: list[dict],
    extracted_dir: str | None = None,
) -> dict[str, float]:
    scores: dict[str, float] = {}
    hash_groups: dict[str, list[str]] = {}
    seen_names: dict[str, list[str]] = {}

    for s in sources:
        sid = s["source_id"]
        scores[sid] = 0.0
        h = s.get("hash", "")
        name = s.get("filename", "")
        if h:
            hash_groups.setdefault(h, []).append(sid)
        if name:
            base = _normalize_name(name)
            seen_names.setdefault(base, []).append(sid)

    for group in hash_groups.values():
        if len(group) > 1:
            for sid in group:
                scores[sid] = 1.0

    for group in seen_names.values():
        if len(group) > 1:
            for sid in group:
                if scores[sid] < 0.8:
                    scores[sid] = max(scores[sid], 0.6)

    if extracted_dir:
        _add_text_similarity_scores(scores, sources, extracted_dir)

    return scores


def _add_text_similarity_scores(
    scores: dict[str, float],
    sources: list[dict],
    extracted_dir: str,
) -> None:
    sids = [s["source_id"] for s in sources]
    first_chars: dict[str, str] = {}
    char_counts: dict[str, int] = {}

    for s in sources:
        sid = s["source_id"]
        txt_path = Path(extracted_dir) / f"{sid}.txt"
        if txt_path.exists():
            try:
                text = txt_path.read_text(encoding="utf-8")
                first_chars[sid] = text[:1000]
                char_counts[sid] = len(text)
            except Exception:
                pass

    for i in range(len(sids)):
        for j in range(i + 1, len(sids)):
            a, b = sids[i], sids[j]
            if scores[a] >= 0.7 and scores[b] >= 0.7:
                continue

            fc_a = first_chars.get(a, "")
            fc_b = first_chars.get(b, "")
            cc_a = char_counts.get(a, 0)
            cc_b = char_counts.get(b, 0)

            fc_sim = _text_similarity(fc_a, fc_b)
            name_a = _find_name(sources, a)
            name_b = _find_name(sources, b)
            name_sim = _name_token_similarity(name_a, name_b)

            bonus = 0.0

            if fc_sim > 0.85:
                bonus = max(bonus, 0.70)

            if name_sim > 0.5 and cc_a > 0 and cc_b > 0:
                ratio = min(cc_a, cc_b) / max(cc_a, cc_b)
                if ratio > 0.8:
                    bonus = max(bonus, 0.75)

            if bonus > 0 and scores[a] < bonus:
                scores[a] = bonus
            if bonus > 0 and scores[b] < bonus:
                scores[b] = bonus


def _text_similarity(t1: str, t2: str) -> float:
    if not t1 or not t2:
        return 0.0
    t1 = " ".join(t1.lower().split())
    t2 = " ".join(t2.lower().split())
    if not t1 or not t2:
        return 0.0
    common = sum(1 for a, b in zip(t1, t2) if a == b)
    return common / max(len(t1), len(t2))


def _name_token_similarity(name1: str, name2: str) -> float:
    if not name1 or not name2:
        return 0.0
    n1 = _normalize_name(name1)
    n2 = _normalize_name(name2)
    if not n1 or not n2:
        return 0.0
    common = sum(1 for a, b in zip(n1, n2) if a == b)
    return common / max(len(n1), len(n2))


def _find_name(sources: list[dict], sid: str) -> str:
    for s in sources:
        if s["source_id"] == sid:
            return s.get("filename", "")
    return ""


def _normalize_name(name: str) -> str:
    name = name.lower().strip()
    name = name.rsplit(".", 1)[0] if "." in name else name
    for ch in " _-":
        name = name.replace(ch, "")
    return name
