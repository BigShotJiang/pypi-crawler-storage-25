import json
from pathlib import Path


def build_context(
    results: list[dict],
    max_chars: int = 6000,
    min_score: float = 0.0,
    index_dir: str | None = None,
) -> dict:
    if not results:
        return {"context": "", "sources": [], "used_chunks": 0, "total_chars": 0}

    filtered = [r for r in results if r.get("score", 0) >= min_score]

    chunk_texts = _load_chunk_texts(index_dir) if index_dir else {}

    seen_ids = set()
    sources = []
    citation_id = 0

    for r in filtered:
        cid = r.get("chunk_id", "")
        if not cid or cid in seen_ids:
            continue
        seen_ids.add(cid)
        citation_id += 1

        text = r.get("text") or chunk_texts.get(cid, r.get("snippet", ""))
        sources.append({
            "citation_id": citation_id,
            "chunk_id": cid,
            "source_id": r.get("source_id", ""),
            "filename": r.get("filename", ""),
            "course": r.get("course", ""),
            "topic": r.get("topic", ""),
            "score": r.get("score", 0),
            "markdown_path": r.get("markdown_path", ""),
            "text": text,
        })

    if not sources:
        return {"context": "", "sources": [], "used_chunks": 0, "total_chars": 0}

    context_parts = []
    total_chars = 0
    used_sources = []

    for s in sources:
        n = s["citation_id"]
        fname = s["filename"]
        cid = s["chunk_id"]
        topic = s["topic"]
        text = s.get("text", "")

        block = f"[{n}] {fname} | chunk {cid} | topic: {topic}\n{text}\n"
        block_chars = len(block)

        if total_chars + block_chars > max_chars:
            remaining = max_chars - total_chars
            if remaining > 100:
                truncated = text[:remaining]
                block = f"[{n}] {fname} | chunk {cid} | topic: {topic}\n{truncated}...\n"
                context_parts.append(block)
                total_chars = max_chars
                used_sources.append(s)
            break

        context_parts.append(block)
        total_chars += block_chars
        used_sources.append(s)

    context = "".join(context_parts)

    for s in used_sources:
        s.pop("text", None)

    return {
        "context": context,
        "sources": used_sources,
        "used_chunks": len(used_sources),
        "total_chars": total_chars,
    }


def _load_chunk_texts(index_dir: str) -> dict[str, str]:
    idx = Path(index_dir)
    chunks_path = idx / "chunks.jsonl"
    if not chunks_path.exists():
        return {}

    texts = {}
    with open(chunks_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                chunk = json.loads(line)
                cid = chunk.get("chunk_id", "")
                if cid:
                    texts[cid] = chunk.get("text", "")
    return texts
