import json
from datetime import datetime
from pathlib import Path

from studygraph.embeddings import embed_texts


def build_vector_index(
    kb_dir: str,
    config: dict,
    provider: str = "mock",
    model: str = "",
    batch_size: int = 32,
    force: bool = False,
    dry_run: bool = False,
) -> dict:
    kb_path = Path(kb_dir)
    vector_dir = kb_path / "vector_index"
    meta_path = vector_dir / "vector_meta.json"

    if not force and meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return {
            "chunks": meta["chunks"],
            "dimensions": meta["dimensions"],
            "provider": meta["provider"],
            "index_dir": str(vector_dir),
        }

    chunks_path = kb_path / "search_index" / "chunks.jsonl"
    if not chunks_path.exists():
        raise FileNotFoundError(
            "search_index/chunks.jsonl non trovato. Esegui index-kb prima di embed-kb."
        )

    chunks = []
    with open(chunks_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                chunks.append(json.loads(line))

    dimensions = config.get("embedding", {}).get("dimensions", 384)

    texts = [c.get("text", "") for c in chunks]
    all_embeddings = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        batch_embeddings = embed_texts(
            texts=batch,
            config=config,
            dry_run=dry_run,
        )
        all_embeddings.extend(batch_embeddings)

    if not all_embeddings:
        all_embeddings = [[] for _ in chunks]

    vector_dir.mkdir(parents=True, exist_ok=True)

    emb_path = vector_dir / "embeddings.jsonl"
    with open(emb_path, "w", encoding="utf-8") as f:
        for ch, emb in zip(chunks, all_embeddings):
            record = {
                "chunk_id": ch.get("chunk_id", ""),
                "source_id": ch.get("source_id", ""),
                "filename": ch.get("filename", ""),
                "course": ch.get("course", ""),
                "topic": ch.get("topic", ""),
                "heading": ch.get("heading", ""),
                "markdown_path": ch.get("markdown_path", ""),
                "text": ch.get("text", ""),
                "embedding": emb,
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    meta = {
        "version": "0.7.0",
        "provider": provider,
        "model": model,
        "dimensions": dimensions,
        "chunks": len(chunks),
        "created": datetime.now().strftime("%Y-%m-%d"),
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    with open(vector_dir / "provider.json", "w", encoding="utf-8") as f:
        json.dump(
            {"provider": provider, "model": model, "dimensions": dimensions},
            f,
            ensure_ascii=False,
            indent=2,
        )

    return {
        "chunks": len(chunks),
        "dimensions": dimensions,
        "provider": provider,
        "index_dir": str(vector_dir),
    }
