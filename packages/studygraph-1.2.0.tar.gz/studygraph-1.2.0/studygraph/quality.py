import re


def score_text_quality(text: str, extraction_meta: dict | None = None) -> dict:
    if not text or not text.strip():
        return {
            "text_quality_score": 0.0,
            "char_count": 0,
            "noise_ratio": 1.0,
            "extraction_warning": True,
        }

    char_count = len(text)
    alpha = len(re.findall(r"[a-zA-Zà-üÀ-Ü]", text))
    digit = len(re.findall(r"[0-9]", text))

    total_space = len(re.findall(r"\s", text))
    expected_space = len(re.findall(r"\s", text.strip()))

    noise = char_count - alpha - digit - total_space
    noise_ratio = noise / max(char_count, 1)

    valid_ratio = (alpha + digit) / max(char_count, 1)
    quality = max(0.0, min(1.0, valid_ratio * 1.2 - noise_ratio * 0.5))

    extraction_warning = False
    if quality < 0.35:
        extraction_warning = True
    if extraction_meta:
        if extraction_meta.get("is_probably_scanned"):
            extraction_warning = True
        if extraction_meta.get("empty_pages_ratio", 0) > 0.50:
            extraction_warning = True

    return {
        "text_quality_score": round(quality, 4),
        "char_count": char_count,
        "noise_ratio": round(noise_ratio, 4),
        "extraction_warning": extraction_warning,
    }
