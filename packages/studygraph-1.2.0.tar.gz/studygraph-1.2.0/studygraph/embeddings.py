import hashlib
import json
import os
import urllib.error
import urllib.request


def embed_texts(
    texts: list[str],
    config: dict,
    dry_run: bool = False,
) -> list[list[float]]:
    if not texts:
        return []

    provider = config.get("embedding", {}).get("provider", "mock")

    if dry_run or provider == "mock":
        dimensions = config.get("embedding", {}).get("dimensions", 384)
        return _mock_embed(texts, dimensions)

    api_key = config.get("api_key") or os.environ.get(config.get("embedding", {}).get("api_key_env", ""))
    if not api_key:
        dimensions = config.get("embedding", {}).get("dimensions", 384)
        return _mock_embed(texts, dimensions)

    base_url = config.get("embedding", {}).get("base_url", "").rstrip("/")
    model = config.get("embedding", {}).get("model", "")

    if not base_url or not model:
        dimensions = config.get("embedding", {}).get("dimensions", 384)
        return _mock_embed(texts, dimensions)

    return _openai_embed(texts, base_url, model, api_key)


def _mock_embed(texts: list[str], dimensions: int = 384) -> list[list[float]]:
    vectors = []
    for t in texts:
        digest = hashlib.sha256(t.encode("utf-8")).digest()
        vec = []
        for i in range(dimensions):
            b = digest[i % len(digest)]
            val = (b / 255.0) * 2.0 - 1.0
            vec.append(val)
        vectors.append(vec)
    return vectors


def _openai_embed(
    texts: list[str],
    base_url: str,
    model: str,
    api_key: str,
) -> list[list[float]]:
    url = f"{base_url}/embeddings"
    body = json.dumps({"input": texts, "model": model}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": "StudyGraph/0.7",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
        print(f"  [Embedding] API error: {e}")
        return [[] for _ in texts]

    try:
        data = result.get("data", [])
        embeddings = [item["embedding"] for item in sorted(data, key=lambda x: x.get("index", 0))]
    except (KeyError, TypeError, IndexError) as e:
        print(f"  [Embedding] unexpected response structure: {e}")
        return [[] for _ in texts]

    return embeddings
