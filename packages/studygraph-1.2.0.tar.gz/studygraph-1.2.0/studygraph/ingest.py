import hashlib
import json
import shutil
from pathlib import Path


def ingest(input_dir: str, raw_dir: str, sources_path: str, allowed_extensions: list[str] | None = None, course: str = "") -> list[dict]:
    if allowed_extensions is None:
        allowed_extensions = [".pdf"]
    input_path = Path(input_dir)
    raw_path = Path(raw_dir)
    raw_path.mkdir(parents=True, exist_ok=True)

    records = []
    existing_sources = _load_sources(sources_path)
    seen_origin = {(r["hash"], r["origin"]) for r in existing_sources}

    files = sorted(input_path.rglob("*"))
    ext_set = {e.lower() for e in allowed_extensions}

    idx = len(existing_sources) + 1
    for f in files:
        if not f.is_file():
            continue
        if f.suffix.lower() not in ext_set:
            continue

        file_hash = _hash_file(f)
        if (file_hash, str(f)) in seen_origin:
            continue

        source_id = f"src_{idx:03d}"
        dst = raw_path / f"{file_hash}{f.suffix}"
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists():
            shutil.copy2(str(f), str(dst))

        record = {
            "source_id": source_id,
            "filename": f.name,
            "hash": file_hash,
            "origin": str(f),
            "raw_path": str(dst),
            "course": course,
            "status": "ingested",
        }
        records.append(record)
        idx += 1

    all_records = existing_sources + records
    _save_sources(sources_path, all_records)
    return records


def _hash_file(path: Path, chunk_size: int = 65536) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


def _load_sources(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    records = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def _save_sources(path: str, records: list[dict]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
