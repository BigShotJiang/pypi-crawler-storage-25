import json
import os


def build_compact_extract(full_text: str, metadata: dict) -> str:
    words = full_text.split()
    pages = []
    chunk_size = 500

    if len(words) > chunk_size:
        pages.append(" ".join(words[:chunk_size]))
    else:
        pages.append(full_text)

    if len(words) > 3000:
        pages.append(" ".join(words[:3000]))
    elif len(words) > chunk_size:
        pages.append(" ".join(words))

    mid = len(words) // 2
    if len(words) > 4000:
        pages.append(" ".join(words[mid - 250 : mid + 250]))

    if len(words) > 1500:
        pages.append(" ".join(words[-1500:]))

    extract = "\n\n---\n\n".join(pages)
    meta_line = (
        f"\n\n[METADATA]\n"
        f"pages: {metadata.get('num_pages', '?')}\n"
        f"language: {metadata.get('language', '?')}\n"
        f"char_count: {metadata.get('char_count', '?')}\n"
    )
    return extract + meta_line


def call_llm(prompt: str, extract: str, config: dict, dry_run: bool = False) -> dict | None:
    if dry_run:
        return None

    api_key = config.get("api_key")
    if not api_key:
        return None

    base_url = config["llm"]["base_url"].rstrip("/")
    model = config["llm"]["model"]
    temperature = config["llm"]["temperature"]

    import urllib.request
    import urllib.error

    body = json.dumps(
        {
            "model": model,
            "messages": [
                {"role": "system", "content": prompt},
                {"role": "user", "content": extract},
            ],
            "temperature": temperature,
        }
    ).encode("utf-8")

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": "StudyGraph/0.3",
    }

    req = urllib.request.Request(
        f"{base_url}/chat/completions",
        data=body,
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        body_text = ""
        if hasattr(e, "read"):
            try:
                body_text = e.read().decode("utf-8")[:300]
            except Exception:
                pass
        print(f"  [LLM] HTTP error ({e.code}): {body_text}" if hasattr(e, "code") else f"  [LLM] HTTP error: {e}")
        return None
    except (json.JSONDecodeError, KeyError) as e:
        print(f"  [LLM] parse error: {e}")
        return None

    try:
        content = result["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        print(f"  [LLM] unexpected response structure: {result}")
        return None

    parsed = _parse_llm_json(content)
    return parsed


def _parse_llm_json(content: str) -> dict | None:
    content = content.strip()
    if content.startswith("```"):
        lines = content.splitlines()
        start = 0
        for i, line in enumerate(lines):
            if line.startswith("```"):
                start = i + 1
                break
        lines = lines[start:]
        end_lines = []
        for line in lines:
            if line.startswith("```"):
                break
            end_lines.append(line)
        content = "\n".join(end_lines)

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        import re

        match = re.search(r"\{.*\}", content, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                return None
        return None
