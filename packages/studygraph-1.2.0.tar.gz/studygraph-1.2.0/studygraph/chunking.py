import re


YAML_FRONTMATTER_RE = re.compile(r"^---\s*\n.*?\n---\s*\n", re.DOTALL)
HEADING_RE = re.compile(r"^#{1,6}\s+(.+)$", re.MULTILINE)


def chunk_markdown(
    text: str,
    metadata: dict,
    chunk_size: int = 1000,
    overlap: int = 150,
    min_chars: int = 10,
) -> list[dict]:
    body = _strip_frontmatter(text)
    if not body.strip():
        return []

    paragraphs = _split_paragraphs(body)
    if not paragraphs:
        return []

    chunks = []
    buffer: list[str] = []
    buffer_size = 0
    current_heading = ""
    overlap_buffer = ""
    used_overlap = False

    def flush():
        nonlocal buffer, buffer_size, overlap_buffer, used_overlap, current_heading
        if not buffer:
            return
        chunk_text = "\n\n".join(buffer)
        if len(chunk_text) < min_chars:
            return
        chunk = {
            "source_id": metadata.get("source_id", ""),
            "filename": metadata.get("filename", ""),
            "course": metadata.get("course", ""),
            "topic": metadata.get("topic", ""),
            "heading": current_heading,
            "text": chunk_text,
            "char_count": len(chunk_text),
            "markdown_path": metadata.get("markdown_path", ""),
        }
        chunks.append(chunk)

        if overlap > 0 and chunk_text:
            overlap_buffer = chunk_text[-overlap:]
            used_overlap = True
        else:
            overlap_buffer = ""
        buffer = []
        buffer_size = 0

    for para in paragraphs:
        heading = _detect_heading(para)
        if heading:
            current_heading = heading

        para_len = len(para)

        if buffer_size + para_len > chunk_size and buffer:
            flush()
            if used_overlap and overlap_buffer:
                buffer.append(overlap_buffer)
                buffer_size = len(overlap_buffer)
                used_overlap = False
                if heading:
                    current_heading = heading

        buffer.append(para)
        buffer_size += para_len

    flush()

    for i, c in enumerate(chunks):
        c["chunk_id"] = f"{metadata.get('source_id', 'unknown')}::{i:04d}"

    return chunks


def _strip_frontmatter(text: str) -> str:
    m = YAML_FRONTMATTER_RE.match(text)
    if m:
        return text[m.end():]
    return text


def _split_paragraphs(text: str) -> list[str]:
    raw = text.strip().split("\n\n")
    return [p.strip() for p in raw if p.strip()]


def _detect_heading(para: str) -> str:
    first_line = para.split("\n", 1)[0].strip()
    m = HEADING_RE.match(first_line)
    if m:
        return m.group(1).strip()
    return ""
