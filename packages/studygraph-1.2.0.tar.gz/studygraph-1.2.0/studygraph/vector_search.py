import json
import math
from pathlib import Path

from studygraph.embeddings import embed_texts
from studygraph.search import SNIPPET_RADIUS, _extract_snippet
from studygraph.search_index import tokenize


def cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b:
        return 0.0
    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for x, y in zip(a, b):
        dot += x * y
        norm_a += x * x
        norm_b += y * y
    denom = math.sqrt(norm_a) * math.sqrt(norm_b)
    return dot / denom if denom > 0 else 0.0


def semantic_search(
    query: str,
    vector_index_dir: str,
    config: dict,
    course: str | None = None,
    top_k: int = 5,
    dry_run: bool = False,
) -> list[dict]:
    if not query or not query.strip():
        return []

    vector_dir = Path(vector_index_dir)
    meta_path = vector_dir / "vector_meta.json"
    if not meta_path.exists():
        return []

    chunks = []
    emb_path = vector_dir / "embeddings.jsonl"
    if not emb_path.exists():
        return []

    with open(emb_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                chunks.append(json.loads(line))

    if not chunks:
        return []

    query_vec = embed_texts([query], config, dry_run=dry_run)[0]
    if not query_vec:
        return []

    scored = []
    query_tokens = tokenize(query)

    for c in chunks:
        chunk_emb = c.get("embedding", [])
        if not chunk_emb:
            continue
        if course:
            if c.get("course", "").lower() != course.lower():
                continue
        cos = cosine_similarity(query_vec, chunk_emb)
        if cos <= 0:
            continue
        snippet = _extract_snippet(c.get("text", ""), query_tokens)
        scored.append({
            "chunk_id": c.get("chunk_id", ""),
            "source_id": c.get("source_id", ""),
            "filename": c.get("filename", ""),
            "course": c.get("course", ""),
            "topic": c.get("topic", ""),
            "score": round(cos, 3),
            "score_type": "semantic",
            "snippet": snippet,
            "markdown_path": c.get("markdown_path", ""),
        })

    scored.sort(key=lambda x: -x["score"])
    return scored[:top_k]
