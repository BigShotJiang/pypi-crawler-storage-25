import json
from pathlib import Path

import click

from studygraph.knowledge_base import build_knowledge_base
from studygraph.search_index import build_index
from studygraph.vector_index import build_vector_index
from studygraph.config import load_config
from studygraph.retrieval_eval import evaluate_retrieval
from studygraph.qa_eval import evaluate_qa
from studygraph.eval_report import write_retrieval_report, write_qa_report
from studygraph.hybrid_search import hybrid_search
from studygraph.context_builder import build_context
from studygraph.qa import answer_question
from studygraph.citations import format_sources

SAMPLE_DOCUMENTS = [
    {
        "source_id": "src_001",
        "filename": "Fourier.pdf",
        "course": "Analisi 1",
        "topic": "Serie di Fourier",
        "suggested_decision": "candidate",
        "final_decision": "candidate",
        "final_score": 0.85,
        "reason": "materiale didattico completo sulle serie di Fourier",
        "manual_decision": "",
        "reviewer_note": "",
        "language": "it",
        "page_count": 10,
        "char_count": 2000,
        "text_quality_score": 0.9,
        "is_probably_scanned": False,
        "extraction_warning": False,
    },
    {
        "source_id": "src_002",
        "filename": "Limiti.pdf",
        "course": "Analisi 1",
        "topic": "Limiti",
        "suggested_decision": "candidate",
        "final_decision": "candidate",
        "final_score": 0.78,
        "reason": "chiara introduzione ai limiti con esempi",
        "manual_decision": "",
        "reviewer_note": "",
        "language": "it",
        "page_count": 8,
        "char_count": 1500,
        "text_quality_score": 0.85,
        "is_probably_scanned": False,
        "extraction_warning": False,
    },
    {
        "source_id": "src_003",
        "filename": "Derivate.pdf",
        "course": "Analisi 1",
        "topic": "Derivate",
        "suggested_decision": "needs_review",
        "final_decision": "needs_review",
        "final_score": 0.55,
        "reason": "materiale sintetico, potrebbe essere integrato",
        "manual_decision": "",
        "reviewer_note": "",
        "language": "it",
        "page_count": 3,
        "char_count": 500,
        "text_quality_score": 0.7,
        "is_probably_scanned": False,
        "extraction_warning": False,
    },
]

SAMPLE_TEXTS = {
    "src_001": (
        "# Serie di Fourier\n\n"
        "## Definizione\n\n"
        "La serie di Fourier è una rappresentazione di una funzione periodica come somma di funzioni seno e coseno. "
        "Permette di scomporre un segnale periodico nelle sue componenti armoniche fondamentali.\n\n"
        "## Proprietà\n\n"
        "- Linearità: la serie di Fourier di una combinazione lineare è la combinazione lineare delle serie.\n"
        "- Convergenza puntuale: sotto opportune condizioni, la serie converge al valore della funzione.\n"
        "- Identità di Parseval: l'energia del segnale nel dominio del tempo è uguale all'energia nel dominio delle frequenze.\n\n"
        "## Esempio\n\n"
        "Consideriamo la funzione f(x) = x per x in [-π, π]. "
        "La sua serie di Fourier è: f(x) = 2∑(-1)^(n+1) sin(nx)/n.\n\n"
        "## Applicazioni\n\n"
        "Le serie di Fourier sono fondamentali in: elaborazione dei segnali, "
        "risoluzione di equazioni differenziali, fisica, ingegneria elettrica e acustica."
    ),
    "src_002": (
        "# Limiti di funzioni\n\n"
        "## Definizione\n\n"
        "Il limite di una funzione f(x) per x che tende a c descrive il comportamento della funzione "
        "quando x si avvicina arbitrariamente a c.\n\n"
        "## Forme indeterminate\n\n"
        "0/0, ∞/∞, 0·∞, ∞-∞, 0^0, 1^∞, ∞^0\n\n"
        "## Limiti notevoli\n\n"
        "- sin(x)/x → 1 per x → 0\n"
        "- (1 - cos(x))/x² → 1/2 per x → 0\n"
        "- (1 + 1/n)^n → e per n → ∞\n\n"
        "## Regole di calcolo\n\n"
        "- Teorema del confronto (dei carabinieri)\n"
        "- Algebra dei limiti (somma, prodotto, quoziente)\n"
        "- Sostituzione diretta quando la funzione è continua"
    ),
    "src_003": (
        "# Derivate\n\n"
        "## Definizione\n\n"
        "La derivata di una funzione f in un punto x misura il tasso di variazione istantaneo.\n\n"
        "## Regole di derivazione\n\n"
        "- Regola del prodotto: (f·g)' = f'·g + f·g'\n"
        "- Regola del quoziente: (f/g)' = (f'·g - f·g')/g²\n"
        "- Regola della catena: (f∘g)' = (f'∘g)·g'\n\n"
        "## Derivate fondamentali\n\n"
        "- D[x^n] = n·x^(n-1)\n"
        "- D[sin(x)] = cos(x)\n"
        "- D[cos(x)] = -sin(x)\n"
        "- D[e^x] = e^x\n"
        "- D[ln(x)] = 1/x"
    ),
}

SAMPLE_EVAL_DATASET = [
    {"id": "q_001", "question": "Che cos'è la serie di Fourier", "course": "Analisi 1",
     "expected_sources": ["Fourier.pdf"], "expected_answer_contains": ["seni", "coseni"],
     "expected_behavior": "answered"},
    {"id": "q_002", "question": "limiti forme indeterminate notevoli", "course": "Analisi 1",
     "expected_sources": ["Limiti.pdf"], "expected_answer_contains": ["0/0"],
     "expected_behavior": "answered"},
    {"id": "q_003", "question": "somma di seni e coseni funzioni periodiche", "course": "Analisi 1",
     "expected_sources": ["Fourier.pdf"], "expected_answer_contains": [],
     "expected_behavior": "answered"},
    {"id": "q_004", "question": "ricetta della carbonara", "course": "Analisi 1",
     "expected_sources": [], "expected_answer_contains": [],
     "expected_behavior": "no_answer"},
    {"id": "q_005", "question": "Derivate regole di derivazione prodotto quoziente catena", "course": "Analisi 1",
     "expected_sources": [], "expected_answer_contains": [],
     "expected_behavior": "no_answer"},
    {"id": "q_006", "question": "forme indeterminate 0/0 e oo/oo", "course": "Analisi 1",
     "expected_sources": ["Limiti.pdf"], "expected_answer_contains": ["0/0"],
     "expected_behavior": "answered"},
    {"id": "q_007", "question": "convergenza puntuale identita di Parseval", "course": "Analisi 1",
     "expected_sources": ["Fourier.pdf"], "expected_answer_contains": ["convergenza", "parseval"],
     "expected_behavior": "answered"},
    {"id": "q_008", "question": "teorema di Pitagora", "course": "Analisi 1",
     "expected_sources": [], "expected_answer_contains": [],
     "expected_behavior": "no_answer"},
    {"id": "q_009", "question": "sin(x)/x limiti notevoli funzioni", "course": "Analisi 1",
     "expected_sources": ["Limiti.pdf"], "expected_answer_contains": [],
     "expected_behavior": "answered"},
    {"id": "q_010", "question": "Fourier identita di Parseval", "course": "Analisi 1",
     "expected_sources": ["Fourier.pdf"], "expected_answer_contains": [],
     "expected_behavior": "answered"},
]


def _create_sample_data(output_dir: str) -> None:
    extracted_dir = Path(output_dir) / "extracted"
    extracted_dir.mkdir(parents=True, exist_ok=True)
    for sid, text in SAMPLE_TEXTS.items():
        (extracted_dir / f"{sid}.txt").write_text(text, encoding="utf-8")


def run_demo(output_dir: str = "data/output/demo") -> dict:
    _create_sample_data(output_dir)
    extracted_dir = str(Path(output_dir) / "extracted")

    config = load_config()
    config["embedding"]["provider"] = "mock"
    config["embedding"]["dimensions"] = 384
    config["llm"]["enabled"] = False
    config["qa"]["provider"] = "mock"

    steps = {}

    click.echo(f"  Costruzione knowledge base da {len(SAMPLE_DOCUMENTS)} documenti...")
    kb_stats = build_knowledge_base(
        documents=SAMPLE_DOCUMENTS,
        extracted_dir=extracted_dir,
        output_dir=output_dir,
    )
    kb_dir = kb_stats["kb_dir"]
    steps["kb"] = kb_stats
    click.echo(f"    Documenti esportati: {kb_stats['exported']}, corsi: {kb_stats['courses']}")

    click.echo("  Indicizzazione per ricerca locale...")
    idx_stats = build_index(kb_dir=kb_dir)
    steps["index"] = idx_stats
    click.echo(f"    Chunk: {idx_stats['chunks']}, termini: {idx_stats['terms']}")

    click.echo("  Generazione embedding vettoriali (mock)...")
    emb_stats = build_vector_index(
        kb_dir=kb_dir, config=config, dry_run=True,
    )
    steps["embed"] = emb_stats
    click.echo(f"    Dimensioni: {emb_stats['dimensions']}, chunk: {emb_stats['chunks']}")

    click.echo("  Valutazione retrieval (lexical, semantic, hybrid)...")
    ret_result = evaluate_retrieval(
        kb_dir=kb_dir, dataset=SAMPLE_EVAL_DATASET,
        modes=["lexical", "semantic", "hybrid"], top_k=5, dry_run=True,
        config=config,
    )
    ret_paths = write_retrieval_report(ret_result, str(Path(output_dir) / "eval"))
    steps["retrieval"] = {"summary": ret_result["summary"], "paths": ret_paths}
    for m, s in ret_result["summary"].items():
        click.echo(f"    {m}: top-1={s.get('top1_accuracy')}, MRR={s.get('mrr')}")

    click.echo("  Valutazione QA...")
    qa_result = evaluate_qa(
        kb_dir=kb_dir, dataset=SAMPLE_EVAL_DATASET, mode="hybrid",
        top_k=5, dry_run=True, config=config,
    )
    qa_paths = write_qa_report(qa_result, str(Path(output_dir) / "eval"))
    steps["qa"] = {"summary": qa_result["summary"], "paths": qa_paths}
    s = qa_result["summary"]
    click.echo(f"    Answer type accuracy: {s.get('answer_type_accuracy')}")
    click.echo(f"    Citation validity: {s.get('citation_validity_rate')}")

    click.echo("  Risposta a una domanda di esempio...")
    index_dir = str(Path(kb_dir) / "search_index")
    vector_index_dir = str(Path(kb_dir) / "vector_index")
    question = "Che cos'è una serie di Fourier?"
    results = hybrid_search(
        query=question, index_dir=index_dir,
        vector_index_dir=vector_index_dir, config=config,
        course="Analisi 1", top_k=5, dry_run=True,
    )
    context_bundle = build_context(results=results, max_chars=6000, min_score=0.0, index_dir=index_dir)
    answer = answer_question(question=question, context_bundle=context_bundle, config=config, dry_run=True)
    steps["ask"] = answer
    click.echo(f"    Domanda: {question}")
    if answer["answer_type"] == "no_answer":
        click.echo(f"    Risposta: {answer['answer']}")
    else:
        click.echo(f"    Risposta: {answer['answer'][:200]}...")
        click.echo(f"    Confidenza: {answer['confidence']}")

    click.echo(f"\n  Demo completata. Output in: {output_dir}/")
    click.echo(f"  Esegui studygraph ask \"La tua domanda\" --kb-dir {kb_dir} --mode hybrid --dry-run per provare con le tue domande.")

    return steps
