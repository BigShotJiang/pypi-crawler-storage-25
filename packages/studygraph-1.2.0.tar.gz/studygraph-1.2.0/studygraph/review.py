import csv
import json
from pathlib import Path


VALID_DECISIONS = {"candidate", "needs_review", "private_only", "rejected", "duplicate"}


def load_review_decisions(csv_path: str) -> list[dict]:
    p = Path(csv_path)
    if not p.exists():
        return []
    decisions = []
    with open(p, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            source_id = row.get("source_id", "").strip()
            manual_decision = row.get("manual_decision", "").strip().lower()
            if not source_id or not manual_decision:
                continue
            if manual_decision not in VALID_DECISIONS:
                continue
            decisions.append({
                "source_id": source_id,
                "manual_decision": manual_decision,
                "reviewer_note": row.get("reviewer_note", "").strip(),
            })
    return decisions


def apply_review_decisions(
    documents: list[dict],
    review_decisions: list[dict],
    documents_path: str,
) -> list[dict]:
    lookup = {d["source_id"]: d for d in review_decisions}

    for doc in documents:
        sid = doc.get("source_id", "")
        r = lookup.get(sid)
        if r:
            doc["manual_decision"] = r["manual_decision"]
            doc["reviewer_note"] = r["reviewer_note"]
            doc["final_decision"] = r["manual_decision"]
        else:
            doc.setdefault("manual_decision", "")
            doc.setdefault("reviewer_note", "")
            doc["final_decision"] = doc.get("suggested_decision", "reject")

    path = Path(documents_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in documents:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    return documents
