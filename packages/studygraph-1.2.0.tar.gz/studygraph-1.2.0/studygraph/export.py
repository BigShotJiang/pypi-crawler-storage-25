import json
import shutil
from pathlib import Path


DECISION_FOLDERS = {
    "candidate": "candidates",
    "needs_review": "needs_review",
    "private_only": "private_only",
    "rejected": "rejected",
    "duplicate": "duplicates",
}


def export_physical(
    documents: list[dict],
    sources: list[dict],
    output_dir: str,
) -> str:
    source_lookup = {s["source_id"]: s for s in sources}
    hash_groups: dict[str, list[str]] = {}
    for s in sources:
        h = s.get("hash", "")
        if h:
            hash_groups.setdefault(h, []).append(s["source_id"])

    out = Path(output_dir)

    for folder in DECISION_FOLDERS.values():
        (out / folder).mkdir(parents=True, exist_ok=True)

    dup_hash_copied: set[str] = set()
    manifest = []

    for doc in documents:
        sid = doc.get("source_id", "")
        decision = doc.get("final_decision", doc.get("suggested_decision", "reject"))
        folder = DECISION_FOLDERS.get(decision, "rejected")
        filename = doc.get("filename", f"{sid}.pdf")

        src_info = source_lookup.get(sid, {})
        src_path_str = src_info.get("raw_path", "")
        src_path = Path(src_path_str) if src_path_str else None

        if not src_path or not src_path.exists():
            manifest.append({
                "source_id": sid,
                "filename": filename,
                "course": doc.get("course", ""),
                "decision": decision,
                "final_score": doc.get("final_score", 0),
                "export_path": "",
                "reason": doc.get("reason", ""),
                "warning": "raw file not found",
            })
            continue

        if decision == "duplicate":
            h = src_info.get("hash", "")
            if h and h in dup_hash_copied:
                manifest.append({
                    "source_id": sid,
                    "filename": filename,
                    "course": doc.get("course", ""),
                    "decision": decision,
                    "final_score": doc.get("final_score", 0),
                    "export_path": "",
                    "reason": doc.get("reason", ""),
                    "warning": "skipped (same hash already copied)",
                })
                continue
            if h:
                dup_hash_copied.add(h)

        copy_name = f"{sid}_{filename}"
        dst = out / folder / copy_name
        try:
            shutil.copy2(str(src_path), str(dst))
            manifest.append({
                "source_id": sid,
                "filename": filename,
                "course": doc.get("course", ""),
                "decision": decision,
                "final_score": doc.get("final_score", 0),
                "export_path": str(dst),
                "reason": doc.get("reason", ""),
            })
        except OSError:
            manifest.append({
                "source_id": sid,
                "filename": filename,
                "course": doc.get("course", ""),
                "decision": decision,
                "final_score": doc.get("final_score", 0),
                "export_path": "",
                "reason": doc.get("reason", ""),
                "warning": "copy failed",
            })

    manifest_path = out / "manifest.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    return str(manifest_path)
