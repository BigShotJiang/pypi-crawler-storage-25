# nyt-digits-solver

Puzzle solver for the NYT Digits game ([no longer active](https://www.nytimes.com/games/digits)).

Given a set of numbers and a target, finds the sequence of arithmetic operations (`+`, `-`, `*`, `/`) that produces the target. Also lets you explore the full set of values reachable from a given input.

## Installation

```bash
pip install nyt-digits-solver
```

## Usage

### `solve`

Returns a list of solutions. Each solution is a list of `Step(numbers, operation)` where `operation` is the step that produced that state (`None` for the initial state).

```python
import nyt_digits_solver as ds

solutions = ds.solve([1, 2, 3], target=6)
# [
#   [
#     Step(numbers=[1, 2, 3], operation=None),
#     Step(numbers=[3, 3],    operation='2+1'),
#     Step(numbers=[6],       operation='3+3'),
#   ]
# ]

for step in solutions[0]:
    if step.operation:
        print(f"{step.operation} → {step.numbers}")
# 2+1 → [3, 3]
# 3+3 → [6]
```

Find all solutions instead of just the first:

```python
all_solutions = ds.solve([1, 2, 3, 4, 5, 25], target=452, how_many_sols=None)
```

### `explore`

Returns the set of all values reachable from the input numbers via any sequence of operations.

```python
reachable = ds.explore([2, 3])
# {1, 5, 6}

452 in ds.explore([1, 2, 3, 4, 5, 25])
# True
```

## CLI

```bash
python -m nyt_digits_solver.main -n 1,2,3 -t 6
# Found 1 solution. Took 0.0 seconds.
# Start: [1, 2, 3]
# 2+1 → [3, 3]
# 3+3 → [6]
```
