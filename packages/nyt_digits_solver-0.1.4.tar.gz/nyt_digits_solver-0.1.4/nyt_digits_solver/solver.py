import bisect
import typing
from collections import deque


class Step(typing.NamedTuple):
    numbers: typing.List[int]
    operation: typing.Optional[str]  # None for the initial state


_BASE_OPS = {
    "+": lambda x, y: x + y,
    "-": lambda x, y: abs(x - y),
    "*": lambda x, y: x * y,
}


def _generate_next_moves(move: typing.List[int]):
    for i in range(len(move)):
        for j in range(i + 1, len(move)):
            remainders = [move[k] for k in range(len(move)) if k != i and k != j]
            a, b = move[i], move[j]
            operations = dict(_BASE_OPS)
            if b != 0 and a % b == 0:
                operations["/"] = lambda x, y: x // y
            elif a != 0 and b % a == 0:
                operations["/"] = lambda x, y: y // x
            for op_sym, op in operations.items():
                result = remainders[:]
                bisect.insort(result, op(a, b))
                yield result, f"{max(a, b)}{op_sym}{min(a, b)}"


def solve(
        numbers: typing.List[int],
        target: int,
        how_many_sols: int = 1) -> typing.List[typing.List[Step]]:
    start = tuple(sorted(numbers))

    # nodes[i] = (state_tuple, parent_idx, operation)
    nodes = [(start, -1, None)]
    todo = deque([0])
    visited = {start}
    solutions = []

    while todo:
        idx = todo.popleft()
        tip = list(nodes[idx][0])

        for new_tip, op_descr in _generate_next_moves(tip):
            new_state = tuple(new_tip)
            if len(new_tip) > 1:
                if new_state not in visited:
                    visited.add(new_state)
                    new_idx = len(nodes)
                    nodes.append((new_state, idx, op_descr))
                    todo.append(new_idx)
            elif new_tip[0] == target:
                path = [Step(new_tip, op_descr)]
                cur = idx
                while cur != -1:
                    state, parent_cur, op = nodes[cur]
                    path.append(Step(list(state), op))
                    cur = parent_cur
                path.reverse()
                solutions.append(path)
                if how_many_sols and len(solutions) >= how_many_sols:
                    return solutions

    return solutions


def explore(numbers: typing.List[int]) -> typing.Set[int]:
    start = tuple(sorted(numbers))
    todo = deque([start])
    visited = {start}
    reachable: typing.Set[int] = set()

    while todo:
        tip = list(todo.popleft())
        for new_tip, _ in _generate_next_moves(tip):
            new_state = tuple(new_tip)
            if len(new_tip) > 1:
                if new_state not in visited:
                    visited.add(new_state)
                    todo.append(new_state)
            else:
                reachable.add(new_tip[0])

    return reachable
