"""Tests for clm.slides.validator."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from clm.slides.validator import (
    Finding,
    ReviewMaterial,
    ValidationResult,
    validate_course,
    validate_directory,
    validate_file,
    validate_quick,
)


def _write_slide(tmp_path: Path, name: str, content: str) -> Path:
    """Write a slide file and return its path."""
    p = tmp_path / name
    p.write_text(dedent(content), encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Format checks
# ---------------------------------------------------------------------------


class TestCheckFormat:
    def test_well_formed_no_findings(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_ok.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["format"])
        assert result.findings == []

    def test_malformed_tags_attribute(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_bad_tags.py",
            """\
            # %% [markdown] tags=broken
            # ## Bad
            """,
        )
        result = validate_file(p, checks=["format"])
        assert len(result.findings) == 1
        assert result.findings[0].category == "format"
        assert "Malformed tags" in result.findings[0].message

    def test_malformed_lang_attribute(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_bad_lang.py",
            """\
            # %% [markdown] lang=de tags=["slide"]
            # ## Bad
            """,
        )
        result = validate_file(p, checks=["format"])
        assert len(result.findings) == 1
        assert result.findings[0].category == "format"
        assert "Malformed lang" in result.findings[0].message

    def test_j2_cells_skipped(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_j2.py",
            """\
            # j2 from 'macros.j2' import header
            # {{ header("T", "T") }}

            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title
            """,
        )
        result = validate_file(p, checks=["format"])
        assert result.findings == []


# ---------------------------------------------------------------------------
# Tag checks
# ---------------------------------------------------------------------------


class TestCheckTags:
    def test_valid_tags_no_findings(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_ok.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["start"]
            # starter

            # %% tags=["completed"]
            result = 42
            """,
        )
        result = validate_file(p, checks=["tags"])
        assert result.findings == []

    def test_unrecognized_tag(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_bad.py",
            """\
            # %% tags=["bogus_tag"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["tags"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "bogus_tag" in errors[0].message

    def test_tag_wrong_cell_type(self, tmp_path):
        # "answer" is valid for markdown but not code
        p = _write_slide(
            tmp_path,
            "slides_wrong.py",
            """\
            # %% tags=["answer"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["tags"])
        warnings = [f for f in result.findings if f.severity == "warning"]
        assert len(warnings) == 1
        assert "answer" in warnings[0].message

    def test_unclosed_start_at_eof(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_unclosed.py",
            """\
            # %% tags=["start"]
            # starter code

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["tags"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "start" in errors[0].message
        assert "no matching" in errors[0].message

    def test_completed_without_start(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_orphan.py",
            """\
            # %% tags=["completed"]
            result = 42
            """,
        )
        result = validate_file(p, checks=["tags"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "completed" in errors[0].message
        assert "without" in errors[0].message

    def test_consecutive_starts_without_completed(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_double_start.py",
            """\
            # %% tags=["start"]
            # first

            # %% tags=["start"]
            # second

            # %% tags=["completed"]
            result = 42
            """,
        )
        result = validate_file(p, checks=["tags"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "no matching" in errors[0].message

    def test_workshop_tag_recognized(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_ws_ok.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %%
            total = 1 + 2
            """,
        )
        result = validate_file(p, checks=["tags"])
        # No unrecognized-tag errors
        tag_errors = [f for f in result.findings if "nrecognized" in f.message]
        assert tag_errors == []

    def test_orphan_end_workshop_warns(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_orphan_end.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "end-workshop"]
            # ## Without preceding workshop
            """,
        )
        result = validate_file(p, checks=["tags"])
        warnings = [
            w for w in result.findings if w.severity == "warning" and "end-workshop" in w.message
        ]
        assert len(warnings) == 1

    def test_end_workshop_tag_recognized(self, tmp_path):
        """``end-workshop`` is a valid markdown tag — no unrecognized-tag error."""
        p = _write_slide(
            tmp_path,
            "slides_end_ws_ok.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop

            # %% [markdown] lang="de" tags=["subslide", "end-workshop"]
            # ## Next topic
            """,
        )
        result = validate_file(p, checks=["tags"])
        tag_errors = [f for f in result.findings if "nrecognized" in f.message]
        assert tag_errors == []

    def test_end_workshop_on_code_cell_warns(self, tmp_path):
        """``end-workshop`` is markdown-only, so it warns on a code cell."""
        p = _write_slide(
            tmp_path,
            "slides_end_ws_code.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop

            # %% tags=["end-workshop"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["tags"])
        warnings = [f for f in result.findings if f.severity == "warning"]
        assert any("end-workshop" in w.message and "code" in w.message for w in warnings)

    def test_valid_start_completed_pair(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_pair.py",
            """\
            # %% tags=["start"]
            # starter

            # %% tags=["completed"]
            result = 1 + 2

            # %% tags=["start"]
            # another starter

            # %% tags=["completed"]
            result2 = 3 + 4
            """,
        )
        result = validate_file(p, checks=["tags"])
        assert result.findings == []

    def test_bilingual_interleaved_start_completed_pair(self, tmp_path):
        # The canonical interleaved bilingual layout
        # [DE_start, EN_start, DE_completed, EN_completed] must not produce
        # tag errors. Each language stream has its own pending-start tracker.
        p = _write_slide(
            tmp_path,
            "slides_interleaved_tags.py",
            """\
            # %% lang="de" tags=["start"]
            def f():
                pass

            # %% lang="en" tags=["start"]
            def f():
                pass

            # %% lang="de" tags=["completed"]
            def f() -> None:
                pass

            # %% lang="en" tags=["completed"]
            def f() -> None:
                pass
            """,
        )
        result = validate_file(p, checks=["tags"])
        assert result.findings == []

    def test_bilingual_cohesion_start_completed_pair(self, tmp_path):
        # The cohesion layout
        # [DE_start, DE_completed, EN_start, EN_completed] must also pass.
        p = _write_slide(
            tmp_path,
            "slides_cohesion_tags.py",
            """\
            # %% lang="de" tags=["start"]
            def f():
                pass

            # %% lang="de" tags=["completed"]
            def f() -> None:
                pass

            # %% lang="en" tags=["start"]
            def f():
                pass

            # %% lang="en" tags=["completed"]
            def f() -> None:
                pass
            """,
        )
        result = validate_file(p, checks=["tags"])
        assert result.findings == []

    def test_two_consecutive_same_lang_starts_still_errors(self, tmp_path):
        # Per-language tracking must still flag two ``start`` cells in the
        # same language stream with no intervening ``completed``.
        p = _write_slide(
            tmp_path,
            "slides_double_de_start.py",
            """\
            # %% lang="de" tags=["start"]
            # first

            # %% lang="de" tags=["start"]
            # second

            # %% lang="de" tags=["completed"]
            result = 42
            """,
        )
        result = validate_file(p, checks=["tags"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "no matching" in errors[0].message


# ---------------------------------------------------------------------------
# Pairing checks
# ---------------------------------------------------------------------------


class TestCheckPairing:
    def test_balanced_pairing(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_paired.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["pairing"])
        assert result.findings == []

    def test_count_mismatch(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_unbalanced.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Extra German
            """,
        )
        result = validate_file(p, checks=["pairing"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "mismatch" in errors[0].message
        assert "2 German" in errors[0].message
        assert "1 English" in errors[0].message

    def test_tag_mismatch_in_pair(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_tag_mismatch.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Title
            """,
        )
        result = validate_file(p, checks=["pairing"])
        warnings = [f for f in result.findings if f.severity == "warning"]
        assert len(warnings) == 1
        assert "Tag mismatch" in warnings[0].message

    def test_voiceover_cells_excluded_from_pairing(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover text

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_file(p, checks=["pairing"])
        errors = [f for f in result.findings if f.severity == "error"]
        assert errors == []

    def test_language_neutral_cells_excluded(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_neutral.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["pairing"])
        assert result.findings == []


class TestCheckOrdering:
    """DE/EN adjacency checks (canonical layout)."""

    def test_canonical_layout_passes(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_canonical.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_file(p, checks=["pairing"])
        assert result.findings == []

    def test_voiceover_wedged_between_de_en_warns(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_wedged.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_file(p, checks=["pairing"])
        warnings = [f for f in result.findings if f.severity == "warning"]
        # The DE/EN slide pair has the DE voiceover wedged between, AND
        # the DE/EN voiceover pair has the EN slide wedged between.
        assert len(warnings) >= 1
        assert any("not adjacent" in w.message for w in warnings)

    def test_shared_cell_between_de_en_is_ok(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_shared_between.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% tags=["keep"]
            x = 1

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title
            """,
        )
        result = validate_file(p, checks=["pairing"])
        assert result.findings == []

    def test_count_mismatch_skips_ordering_check(self, tmp_path):
        # When DE/EN counts don't match, _check_pairing reports it and the
        # ordering check should not pile on with adjacency warnings for
        # the same category.
        p = _write_slide(
            tmp_path,
            "slides_count_mismatch.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 1

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 1

            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 2
            """,
        )
        result = validate_file(p, checks=["pairing"])
        # The mismatch is the only error/warning we care about — no
        # adjacency warnings should be produced for the markdown category.
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        # The voiceover category has 1 DE and 0 EN, also a mismatch — skipped.
        # The markdown category has 3 DE and 1 EN — also skipped.
        # So no adjacency findings.
        assert adjacency == []

    def test_start_completed_cohesion_layout_passes(self, tmp_path):
        # Same-language start/completed pairs are permitted to stay
        # grouped together: [DE_start, DE_completed, EN_start, EN_completed].
        # The DE_completed between DE_start and its EN partner must NOT
        # be flagged as intervening.
        p = _write_slide(
            tmp_path,
            "slides_cohesion.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% lang="de" tags=["start"]
            def begruessung(name, alter):
                return f"Hallo {name}"

            # %% lang="de" tags=["completed"]
            def begruessung(name: str, alter: int) -> str:
                return f"Hallo {name}"

            # %% lang="en" tags=["start"]
            def greeting(name, age):
                return f"Hello {name}"

            # %% lang="en" tags=["completed"]
            def greeting(name: str, age: int) -> str:
                return f"Hello {name}"
            """,
        )
        result = validate_file(p, checks=["pairing"])
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        assert adjacency == []

    def test_canonical_interleaved_start_completed_passes(self, tmp_path):
        # The canonical interleave [DE_start, EN_start, DE_completed, EN_completed]
        # also passes — start/completed cohesion is permitted, not required.
        p = _write_slide(
            tmp_path,
            "slides_interleaved.py",
            """\
            # %% lang="de" tags=["start"]
            def f():
                pass

            # %% lang="en" tags=["start"]
            def f():
                pass

            # %% lang="de" tags=["completed"]
            def f() -> None:
                pass

            # %% lang="en" tags=["completed"]
            def f() -> None:
                pass
            """,
        )
        result = validate_file(p, checks=["pairing"])
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        assert adjacency == []

    def test_start_completed_cohesion_with_voiceover(self, tmp_path):
        # Cohesion + voiceover: voiceover comes after the cohesion block.
        p = _write_slide(
            tmp_path,
            "slides_cohesion_vo.py",
            """\
            # %% lang="de" tags=["start"]
            def f():
                pass

            # %% lang="de" tags=["completed"]
            def f() -> None:
                pass

            # %% lang="en" tags=["start"]
            def f():
                pass

            # %% lang="en" tags=["completed"]
            def f() -> None:
                pass

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_file(p, checks=["pairing"])
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        assert adjacency == []

    def test_start_completed_separated_by_call_does_not_collapse(self, tmp_path):
        # Cohesion only applies when start is *immediately* followed by
        # completed (same lang). Here a `keep` cell sits between DE_start
        # and DE_completed, so they are NOT a cohesion pair. The layout
        # below therefore fails adjacency (DE_start ↔ EN_start has the
        # DE_keep and DE_completed cells in between, which are lang-tagged).
        p = _write_slide(
            tmp_path,
            "slides_split.py",
            """\
            # %% lang="de" tags=["start"]
            def f():
                pass

            # %% lang="de" tags=["keep"]
            x = 1

            # %% lang="de" tags=["completed"]
            def f() -> None:
                pass

            # %% lang="en" tags=["start"]
            def f():
                pass

            # %% lang="en" tags=["keep"]
            x = 1

            # %% lang="en" tags=["completed"]
            def f() -> None:
                pass
            """,
        )
        result = validate_file(p, checks=["pairing"])
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        # No spurious collapse: at least one adjacency warning fires
        # because start/completed aren't immediate neighbors.
        assert len(adjacency) >= 1

    def test_code_pair_separated_by_voiceover_warns(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_code_split.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% lang="de"
            print("hallo")

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% lang="en"
            print("hello")

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_file(p, checks=["pairing"])
        warnings = [f for f in result.findings if "not adjacent" in f.message]
        assert len(warnings) >= 1


# ---------------------------------------------------------------------------
# Review material extraction
# ---------------------------------------------------------------------------


class TestCodeQualityExtraction:
    def test_detects_print_calls(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_print.py",
            """\
            # %% tags=["keep"]
            x = 42
            print(x)
            """,
        )
        result = validate_file(p, checks=["code_quality"])
        assert result.review_material is not None
        assert result.review_material.code_quality is not None
        assert len(result.review_material.code_quality["print_calls"]) == 1

    def test_detects_leading_comments(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_comment.py",
            """\
            # %% tags=["keep"]
            # Calculate the result
            result = 1 + 2
            """,
        )
        result = validate_file(p, checks=["code_quality"])
        assert result.review_material is not None
        assert result.review_material.code_quality is not None
        assert len(result.review_material.code_quality["leading_comments"]) == 1

    def test_empty_when_no_issues(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_clean.py",
            """\
            # %% tags=["keep"]
            x = 42
            """,
        )
        result = validate_file(p, checks=["code_quality"])
        assert result.review_material is not None
        assert result.review_material.code_quality == {}


class TestVoiceoverGapsExtraction:
    def test_detects_missing_voiceover(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_no_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        assert result.review_material.voiceover_gaps is not None
        assert len(result.review_material.voiceover_gaps) > 0

    def test_no_gaps_when_voiceover_present(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_with_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []

    def test_no_gaps_with_bilingual_interleaved_voiceover(self, tmp_path):
        # Regression test: the canonical layout produced by ``normalize-slides``
        # puts both DE and EN content cells first, then both voiceover cells.
        # A linear scan mistakenly flags the DE slide as missing voiceover.
        p = _write_slide(
            tmp_path,
            "slides_bilingual_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []

    def test_no_gaps_with_multiple_bilingual_slides(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_multi_bilingual.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 1

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 1

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE 1

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN 1

            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 2

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 2

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE 2

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN 2
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []

    def test_detects_uncovered_de_when_only_en_voiceover(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_en_only_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert len(gaps) == 1
        assert gaps[0]["lang"] == "de"

    def test_lang_less_voiceover_covers_both_languages(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_shared_vo.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] tags=["voiceover"]
            # Shared voiceover
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []

    def test_voiceover_does_not_carry_across_slide_boundary(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_boundary.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 1

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 1

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE 1

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN 1

            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 2

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 2
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert len(gaps) == 2
        langs = {g["lang"] for g in gaps}
        assert langs == {"de", "en"}


class TestVoiceoverGapsInsideWorkshop:
    def test_workshop_internal_cells_are_suppressed(self, tmp_path):
        # Workshop heading has voiceover; subslides and code cells inside
        # the workshop have none. Expectation: zero gaps.
        p = _write_slide(
            tmp_path,
            "slides_workshop_silent.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Aufgabe 1

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Task 1

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []

    def test_workshop_heading_without_voiceover_is_flagged(self, tmp_path):
        # Bilingual workshop heading with no voiceover at all. Both DE and
        # EN heading cells must be flagged; the trailing subslide and code
        # cell are inside the workshop range and stay suppressed.
        p = _write_slide(
            tmp_path,
            "slides_workshop_no_intro.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Aufgabe 1

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Task 1

            # %% tags=["keep"]
            x = 1
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert len(gaps) == 2
        langs = {g["lang"] for g in gaps}
        assert langs == {"de", "en"}
        assert all("workshop" in g.get("heading", "").lower() for g in gaps)

    def test_workshop_heading_partial_voiceover_flags_missing_side(self, tmp_path):
        # DE heading has voiceover, EN doesn't. Only the EN heading is
        # flagged; the workshop body stays suppressed.
        p = _write_slide(
            tmp_path,
            "slides_workshop_partial_intro.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Aufgabe 1

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Task 1
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert len(gaps) == 1
        assert gaps[0]["lang"] == "en"

    def test_cells_after_end_workshop_still_require_voiceover(self, tmp_path):
        # The cell carrying ``end-workshop`` is outside the workshop. Its
        # missing voiceover must be reported. (And the workshop heading
        # has voiceover, so it stays silent.)
        p = _write_slide(
            tmp_path,
            "slides_workshop_then_normal.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN

            # %% tags=["keep"]
            x = 1

            # %% [markdown] lang="de" tags=["subslide", "end-workshop"]
            # ## Nach dem Workshop

            # %% [markdown] lang="en" tags=["subslide", "end-workshop"]
            # ## After the workshop
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert len(gaps) == 2
        langs = {g["lang"] for g in gaps}
        assert langs == {"de", "en"}

    def test_two_workshops_independent_heading_checks(self, tmp_path):
        # Two workshops in one file. First has heading voiceover; second
        # does not. Only the second workshop's heading cells flag.
        p = _write_slide(
            tmp_path,
            "slides_two_workshops.py",
            """\
            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop 1

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop 1

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE 1

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN 1

            # %% tags=["keep"]
            x = 1

            # %% [markdown] lang="de" tags=["subslide", "end-workshop"]
            # ## Zwischendurch

            # %% [markdown] lang="en" tags=["subslide", "end-workshop"]
            # ## Intermission

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE Inter

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN Inter

            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop 2

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop 2

            # %% tags=["keep"]
            y = 2
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        # Two heading cells (DE + EN) for Workshop 2 only.
        assert len(gaps) == 2
        langs = {g["lang"] for g in gaps}
        assert langs == {"de", "en"}

    def test_workshop_extends_to_eof_when_no_end_tag(self, tmp_path):
        # Common case: no ``end-workshop`` tag, workshop runs to EOF.
        # The cell after the heading must be suppressed even though it
        # would normally need voiceover.
        p = _write_slide(
            tmp_path,
            "slides_workshop_eof.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Einführung

            # %% [markdown] lang="en" tags=["slide"]
            # ## Introduction

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE Intro

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN Intro

            # %% [markdown] lang="de" tags=["subslide", "workshop"]
            # ## Workshop: Übung

            # %% [markdown] lang="en" tags=["subslide", "workshop"]
            # ## Workshop: Exercise

            # %% [markdown] lang="de" tags=["voiceover"]
            # Voiceover DE Workshop

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover EN Workshop

            # %% tags=["keep"]
            x = 1

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Aufgabe

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Task
            """,
        )
        result = validate_file(p, checks=["voiceover"])
        assert result.review_material is not None
        gaps = result.review_material.voiceover_gaps or []
        assert gaps == []


class TestCompletenessExtraction:
    def test_extracts_concepts_and_workshops(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_concepts.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Methoden

            # %% [markdown] lang="en" tags=["slide"]
            # ## Methods

            # %% [markdown] lang="de" tags=["subslide"]
            # ## Workshop: Methoden üben

            # %% [markdown] lang="en" tags=["subslide"]
            # ## Workshop: Practice Methods
            """,
        )
        result = validate_file(p, checks=["completeness"])
        assert result.review_material is not None
        c = result.review_material.completeness
        assert c is not None
        assert "Methoden" in c["slide_concepts"] or "Methods" in c["slide_concepts"]
        assert len(c["workshop_exercises"]) > 0


# ---------------------------------------------------------------------------
# validate_quick
# ---------------------------------------------------------------------------


class TestValidateQuick:
    def test_clean_file(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_ok.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title
            """,
        )
        result = validate_quick(p)
        assert result.findings == []
        assert result.review_material is None

    def test_catches_invalid_tag(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_bad.py",
            """\
            # %% tags=["invalid_tag"]
            x = 1
            """,
        )
        result = validate_quick(p)
        assert len(result.findings) == 1
        assert result.findings[0].category == "tags"

    def test_catches_unclosed_start(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_unclosed.py",
            """\
            # %% tags=["start"]
            # starter
            """,
        )
        result = validate_quick(p)
        errors = [f for f in result.findings if f.severity == "error"]
        assert len(errors) == 1
        assert "start" in errors[0].message

    def test_does_not_check_pairing(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_unpaired.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Only German
            """,
        )
        result = validate_quick(p)
        # Quick mode doesn't check pairing count/tag mismatches — these
        # would be noisy during in-progress edits where the EN counterpart
        # is not yet written.
        pairing_findings = [f for f in result.findings if f.category == "pairing"]
        assert pairing_findings == []

    def test_checks_ordering(self, tmp_path):
        # Quick mode DOES check DE/EN adjacency — this catches the
        # "voiceover wedged between DE and EN slides" anti-pattern at
        # edit time. Counts are matched, so it's safe to flag.
        p = _write_slide(
            tmp_path,
            "slides_wedged.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="de" tags=["voiceover"]
            # Sprechertext

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% [markdown] lang="en" tags=["voiceover"]
            # Voiceover text
            """,
        )
        result = validate_quick(p)
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        assert len(adjacency) >= 1

    def test_ordering_skipped_on_count_mismatch(self, tmp_path):
        # Confirm ordering check is silent during partial edits, where
        # the user has added a DE cell but not yet the EN counterpart.
        p = _write_slide(
            tmp_path,
            "slides_partial_edit.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 1

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title 1

            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel 2 (EN not yet written)
            """,
        )
        result = validate_quick(p)
        adjacency = [f for f in result.findings if "not adjacent" in f.message]
        assert adjacency == []


# ---------------------------------------------------------------------------
# validate_directory
# ---------------------------------------------------------------------------


class TestValidateDirectory:
    def test_validates_all_slide_files(self, tmp_path):
        topic_dir = tmp_path / "topic_010_intro"
        topic_dir.mkdir()
        (topic_dir / "slides_intro.py").write_text(
            '# %% [markdown] lang="de" tags=["slide"]\n# ## Titel\n'
            '# %% [markdown] lang="en" tags=["slide"]\n# ## Title\n',
            encoding="utf-8",
        )
        (topic_dir / "slides_extra.py").write_text(
            '# %% [markdown] lang="de" tags=["slide"]\n# ## Mehr\n'
            '# %% [markdown] lang="en" tags=["slide"]\n# ## More\n',
            encoding="utf-8",
        )
        # Non-slide file should be ignored
        (topic_dir / "helper.py").write_text("x = 1\n", encoding="utf-8")

        result = validate_directory(topic_dir)
        assert result.files_checked == 2
        assert result.findings == []

    def test_aggregates_findings(self, tmp_path):
        topic_dir = tmp_path / "topic_010_intro"
        topic_dir.mkdir()
        (topic_dir / "slides_bad.py").write_text(
            '# %% tags=["bogus"]\nx = 1\n',
            encoding="utf-8",
        )

        result = validate_directory(topic_dir, checks=["tags"])
        assert result.files_checked == 1
        assert len(result.findings) == 1

    def test_recurses_into_module_directory(self, tmp_path):
        # A module directory has no direct slide files but contains
        # topic subdirectories with slide files. validate_directory must
        # walk into them rather than silently returning zero files.
        module_dir = tmp_path / "module_100_basics"
        topic_dir = module_dir / "topic_010_intro"
        topic_dir.mkdir(parents=True)
        (topic_dir / "slides_intro.py").write_text(
            '# %% tags=["bogus"]\nx = 1\n',
            encoding="utf-8",
        )

        result = validate_directory(module_dir, checks=["tags"])
        assert result.files_checked == 1
        assert len(result.findings) == 1

    def test_recurses_from_slides_root(self, tmp_path):
        # The full slides/ root: nested two levels deep below the input.
        slides_root = tmp_path / "slides"
        topic_a = slides_root / "module_100" / "topic_010"
        topic_b = slides_root / "module_200" / "topic_020"
        topic_a.mkdir(parents=True)
        topic_b.mkdir(parents=True)
        (topic_a / "slides_a.py").write_text("x = 1\n", encoding="utf-8")
        (topic_b / "slides_b.py").write_text("y = 2\n", encoding="utf-8")

        result = validate_directory(slides_root, checks=["format"])
        assert result.files_checked == 2


# ---------------------------------------------------------------------------
# validate_course
# ---------------------------------------------------------------------------


class TestValidateCourse:
    def _make_course(self, tmp_path):
        """Set up a minimal course tree."""
        slides = tmp_path / "slides"
        m1 = slides / "module_100_basics"
        t1 = m1 / "topic_010_intro"
        t1.mkdir(parents=True)
        (t1 / "slides_intro.py").write_text(
            '# %% [markdown] lang="de" tags=["slide"]\n# ## Titel\n'
            '# %% [markdown] lang="en" tags=["slide"]\n# ## Title\n',
            encoding="utf-8",
        )

        specs = tmp_path / "course-specs"
        specs.mkdir()
        spec_xml = """\
<?xml version="1.0" encoding="UTF-8"?>
<course>
    <name><de>Test</de><en>Test</en></name>
    <prog-lang>python</prog-lang>
    <description><de></de><en></en></description>
    <certificate><de></de><en></en></certificate>
    <sections><section>
        <name><de>S</de><en>S</en></name>
        <topics><topic>intro</topic></topics>
    </section></sections>
</course>
"""
        spec_path = specs / "test.xml"
        spec_path.write_text(spec_xml, encoding="utf-8")
        return spec_path, slides

    def test_validates_course_slides(self, tmp_path):
        spec_path, slides_dir = self._make_course(tmp_path)
        result = validate_course(spec_path, slides_dir, checks=["format", "tags"])
        assert result.files_checked == 1
        assert result.findings == []


# ---------------------------------------------------------------------------
# ValidationResult
# ---------------------------------------------------------------------------


class TestValidationResult:
    def test_summary_no_issues(self):
        r = ValidationResult(files_checked=3)
        assert "3 files checked" in r.summary
        assert "no issues" in r.summary

    def test_summary_with_findings(self):
        r = ValidationResult(
            files_checked=1,
            findings=[
                Finding("error", "tags", "f.py", 1, "bad tag"),
                Finding("warning", "pairing", "f.py", 2, "mismatch"),
            ],
        )
        assert "1 error" in r.summary
        assert "1 warning" in r.summary

    def test_summary_with_review(self):
        r = ValidationResult(
            files_checked=1,
            review_material=ReviewMaterial(code_quality={"print_calls": []}),
        )
        assert "1 category for review" in r.summary

    def test_summary_singular_file(self):
        r = ValidationResult(files_checked=1)
        assert "1 file checked" in r.summary


# ---------------------------------------------------------------------------
# Selective checks
# ---------------------------------------------------------------------------


class TestSelectiveChecks:
    def test_only_format_checks(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_bad.py",
            """\
            # %% tags=["bogus"]
            x = 1

            # %% [markdown] lang="de" tags=["slide"]
            # ## Only German
            """,
        )
        result = validate_file(p, checks=["format"])
        # Should not report tag or pairing issues
        assert all(f.category == "format" for f in result.findings)
        assert result.review_material is None

    def test_only_review_checks(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_print.py",
            """\
            # %% tags=["bogus"]
            print(42)
            """,
        )
        result = validate_file(p, checks=["code_quality"])
        # No deterministic findings
        assert result.findings == []
        assert result.review_material is not None

    def test_default_runs_all(self, tmp_path):
        p = _write_slide(
            tmp_path,
            "slides_all.py",
            """\
            # %% [markdown] lang="de" tags=["slide"]
            # ## Titel

            # %% [markdown] lang="en" tags=["slide"]
            # ## Title

            # %% tags=["keep"]
            print(42)
            """,
        )
        result = validate_file(p)
        assert result.review_material is not None
