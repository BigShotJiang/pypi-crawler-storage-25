/*
 *  Copyright 2025-2026 Colliery Software
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

// Schema selection based on backend feature flags

// =============================================================================
// Unified Schema using Custom SQL Types
// =============================================================================
// This schema uses custom SQL types (DbUuid, DbTimestamp, DbBool) that work
// with both PostgreSQL and SQLite backends. Use this for new code.

mod unified_schema {
    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        contexts (id) {
            id -> DbUuid,
            value -> Text,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        pipeline_executions (id) {
            id -> DbUuid,
            pipeline_name -> Text,
            pipeline_version -> Text,
            status -> Text,
            context_id -> Nullable<DbUuid>,
            started_at -> DbTimestamp,
            completed_at -> Nullable<DbTimestamp>,
            error_details -> Nullable<Text>,
            recovery_attempts -> Integer,
            last_recovery_at -> Nullable<DbTimestamp>,
            paused_at -> Nullable<DbTimestamp>,
            pause_reason -> Nullable<Text>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        task_executions (id) {
            id -> DbUuid,
            pipeline_execution_id -> DbUuid,
            task_name -> Text,
            status -> Text,
            started_at -> Nullable<DbTimestamp>,
            completed_at -> Nullable<DbTimestamp>,
            attempt -> Integer,
            max_attempts -> Integer,
            error_details -> Nullable<Text>,
            trigger_rules -> Text,
            task_configuration -> Text,
            retry_at -> Nullable<DbTimestamp>,
            last_error -> Nullable<Text>,
            recovery_attempts -> Integer,
            last_recovery_at -> Nullable<DbTimestamp>,
            sub_status -> Nullable<Text>,
            claimed_by -> Nullable<DbUuid>,
            heartbeat_at -> Nullable<DbTimestamp>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        recovery_events (id) {
            id -> DbUuid,
            pipeline_execution_id -> DbUuid,
            task_execution_id -> Nullable<DbUuid>,
            recovery_type -> Text,
            recovered_at -> DbTimestamp,
            details -> Nullable<Text>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        /// Execution events table for complete audit trail of task/pipeline state transitions.
        /// Append-only: events are never updated after creation.
        execution_events (sequence_num) {
            id -> DbUuid,
            pipeline_execution_id -> DbUuid,
            task_execution_id -> Nullable<DbUuid>,
            event_type -> Text,
            event_data -> Nullable<Text>,
            worker_id -> Nullable<Text>,
            created_at -> DbTimestamp,
            sequence_num -> BigInt,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        /// Task outbox table for work distribution.
        /// Transient: rows are deleted immediately upon claiming.
        task_outbox (id) {
            id -> BigInt,
            task_execution_id -> DbUuid,
            created_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        task_execution_metadata (id) {
            id -> DbUuid,
            task_execution_id -> DbUuid,
            pipeline_execution_id -> DbUuid,
            task_name -> Text,
            context_id -> Nullable<DbUuid>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        workflow_registry (id) {
            id -> DbUuid,
            created_at -> DbTimestamp,
            data -> DbBinary,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        workflow_packages (id) {
            id -> DbUuid,
            registry_id -> DbUuid,
            package_name -> Text,
            version -> Text,
            description -> Nullable<Text>,
            author -> Nullable<Text>,
            metadata -> Text,
            storage_type -> Text,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    // =========================================================================
    // Unified Schedule Tables
    // =========================================================================

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        schedules (id) {
            id -> DbUuid,
            schedule_type -> Text,
            workflow_name -> Text,
            enabled -> DbBool,
            cron_expression -> Nullable<Text>,
            timezone -> Nullable<Text>,
            catchup_policy -> Nullable<Text>,
            start_date -> Nullable<DbTimestamp>,
            end_date -> Nullable<DbTimestamp>,
            trigger_name -> Nullable<Text>,
            poll_interval_ms -> Nullable<Integer>,
            allow_concurrent -> Nullable<DbBool>,
            next_run_at -> Nullable<DbTimestamp>,
            last_run_at -> Nullable<DbTimestamp>,
            last_poll_at -> Nullable<DbTimestamp>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        schedule_executions (id) {
            id -> DbUuid,
            schedule_id -> DbUuid,
            pipeline_execution_id -> Nullable<DbUuid>,
            scheduled_time -> Nullable<DbTimestamp>,
            claimed_at -> Nullable<DbTimestamp>,
            context_hash -> Nullable<Text>,
            started_at -> DbTimestamp,
            completed_at -> Nullable<DbTimestamp>,
            created_at -> DbTimestamp,
            updated_at -> DbTimestamp,
        }
    }

    // =========================================================================
    // Package Signing Tables
    // =========================================================================

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        signing_keys (id) {
            id -> DbUuid,
            org_id -> DbUuid,
            key_name -> Text,
            encrypted_private_key -> DbBinary,
            public_key -> DbBinary,
            key_fingerprint -> Text,
            created_at -> DbTimestamp,
            revoked_at -> Nullable<DbTimestamp>,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        trusted_keys (id) {
            id -> DbUuid,
            org_id -> DbUuid,
            key_fingerprint -> Text,
            public_key -> DbBinary,
            key_name -> Nullable<Text>,
            trusted_at -> DbTimestamp,
            revoked_at -> Nullable<DbTimestamp>,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        key_trust_acls (id) {
            id -> DbUuid,
            parent_org_id -> DbUuid,
            child_org_id -> DbUuid,
            granted_at -> DbTimestamp,
            revoked_at -> Nullable<DbTimestamp>,
        }
    }

    diesel::table! {
        use diesel::sql_types::*;
        use crate::database::universal_types::{DbUuid, DbTimestamp, DbBool, DbBinary};

        package_signatures (id) {
            id -> DbUuid,
            package_hash -> Text,
            key_fingerprint -> Text,
            signature -> DbBinary,
            signed_at -> DbTimestamp,
        }
    }

    diesel::joinable!(pipeline_executions -> contexts (context_id));
    diesel::joinable!(task_executions -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> task_executions (task_execution_id));
    diesel::joinable!(task_execution_metadata -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> contexts (context_id));
    diesel::joinable!(recovery_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(recovery_events -> task_executions (task_execution_id));
    diesel::joinable!(execution_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(execution_events -> task_executions (task_execution_id));
    diesel::joinable!(task_outbox -> task_executions (task_execution_id));
    diesel::joinable!(schedule_executions -> schedules (schedule_id));
    diesel::joinable!(schedule_executions -> pipeline_executions (pipeline_execution_id));

    diesel::allow_tables_to_appear_in_same_query!(
        contexts,
        execution_events,
        key_trust_acls,
        package_signatures,
        pipeline_executions,
        recovery_events,
        schedule_executions,
        schedules,
        signing_keys,
        task_executions,
        task_execution_metadata,
        task_outbox,
        trusted_keys,
        workflow_packages,
        workflow_registry,
    );
}

// =============================================================================
// Legacy Backend-Specific Schemas (to be removed after migration)
// =============================================================================

#[cfg(feature = "postgres")]
mod postgres_schema {
    // PostgreSQL schema using native types
    diesel::table! {
        contexts (id) {
            id -> Uuid,
            value -> Varchar,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        pipeline_executions (id) {
            id -> Uuid,
            pipeline_name -> Varchar,
            pipeline_version -> Varchar,
            status -> Varchar,
            context_id -> Nullable<Uuid>,
            started_at -> Timestamp,
            completed_at -> Nullable<Timestamp>,
            error_details -> Nullable<Text>,
            recovery_attempts -> Int4,
            last_recovery_at -> Nullable<Timestamp>,
            paused_at -> Nullable<Timestamp>,
            pause_reason -> Nullable<Text>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        task_executions (id) {
            id -> Uuid,
            pipeline_execution_id -> Uuid,
            task_name -> Varchar,
            status -> Varchar,
            started_at -> Nullable<Timestamp>,
            completed_at -> Nullable<Timestamp>,
            attempt -> Int4,
            max_attempts -> Int4,
            error_details -> Nullable<Text>,
            trigger_rules -> Text,
            task_configuration -> Text,
            retry_at -> Nullable<Timestamp>,
            last_error -> Nullable<Text>,
            recovery_attempts -> Int4,
            last_recovery_at -> Nullable<Timestamp>,
            sub_status -> Nullable<Varchar>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        recovery_events (id) {
            id -> Uuid,
            pipeline_execution_id -> Uuid,
            task_execution_id -> Nullable<Uuid>,
            recovery_type -> Varchar,
            recovered_at -> Timestamp,
            details -> Nullable<Text>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        execution_events (id) {
            id -> Uuid,
            pipeline_execution_id -> Uuid,
            task_execution_id -> Nullable<Uuid>,
            event_type -> Varchar,
            event_data -> Nullable<Text>,
            worker_id -> Nullable<Varchar>,
            created_at -> Timestamp,
            sequence_num -> Int8,
        }
    }

    diesel::table! {
        task_outbox (id) {
            id -> Int8,
            task_execution_id -> Uuid,
            created_at -> Timestamp,
        }
    }

    diesel::table! {
        task_execution_metadata (id) {
            id -> Uuid,
            task_execution_id -> Uuid,
            pipeline_execution_id -> Uuid,
            task_name -> Varchar,
            context_id -> Nullable<Uuid>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        workflow_registry (id) {
            id -> Uuid,
            created_at -> Timestamp,
            data -> Bytea,
        }
    }

    diesel::table! {
        workflow_packages (id) {
            id -> Uuid,
            registry_id -> Uuid,
            package_name -> Varchar,
            version -> Varchar,
            description -> Nullable<Text>,
            author -> Nullable<Varchar>,
            metadata -> Text,
            storage_type -> Varchar,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        schedules (id) {
            id -> Uuid,
            schedule_type -> Varchar,
            workflow_name -> Varchar,
            enabled -> Bool,
            cron_expression -> Nullable<Varchar>,
            timezone -> Nullable<Varchar>,
            catchup_policy -> Nullable<Varchar>,
            start_date -> Nullable<Timestamp>,
            end_date -> Nullable<Timestamp>,
            next_run_at -> Nullable<Timestamp>,
            last_run_at -> Nullable<Timestamp>,
            trigger_name -> Nullable<Varchar>,
            poll_interval_ms -> Nullable<Int4>,
            allow_concurrent -> Nullable<Bool>,
            last_poll_at -> Nullable<Timestamp>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    diesel::table! {
        schedule_executions (id) {
            id -> Uuid,
            schedule_id -> Uuid,
            pipeline_execution_id -> Nullable<Uuid>,
            scheduled_time -> Nullable<Timestamp>,
            claimed_at -> Nullable<Timestamp>,
            created_at -> Timestamp,
            updated_at -> Timestamp,
        }
    }

    // Package Signing Tables
    diesel::table! {
        signing_keys (id) {
            id -> Uuid,
            org_id -> Uuid,
            key_name -> Varchar,
            encrypted_private_key -> Bytea,
            public_key -> Bytea,
            key_fingerprint -> Varchar,
            created_at -> Timestamp,
            revoked_at -> Nullable<Timestamp>,
        }
    }

    diesel::table! {
        trusted_keys (id) {
            id -> Uuid,
            org_id -> Uuid,
            key_fingerprint -> Varchar,
            public_key -> Bytea,
            key_name -> Nullable<Varchar>,
            trusted_at -> Timestamp,
            revoked_at -> Nullable<Timestamp>,
        }
    }

    diesel::table! {
        key_trust_acls (id) {
            id -> Uuid,
            parent_org_id -> Uuid,
            child_org_id -> Uuid,
            granted_at -> Timestamp,
            revoked_at -> Nullable<Timestamp>,
        }
    }

    diesel::table! {
        package_signatures (id) {
            id -> Uuid,
            package_hash -> Varchar,
            key_fingerprint -> Varchar,
            signature -> Bytea,
            signed_at -> Timestamp,
        }
    }

    #[cfg(feature = "auth")]
    diesel::table! {
        auth_tokens (token_id) {
            token_id -> Varchar,
            name -> Varchar,
            role -> Varchar,
            tenant_id -> Varchar,
            created_at -> Timestamptz,
            expires_at -> Nullable<Timestamptz>,
            last_used_at -> Nullable<Timestamptz>,
            created_by_token_id -> Nullable<Varchar>,
            status -> Varchar,
        }
    }

    #[cfg(feature = "auth")]
    diesel::table! {
        auth_audit_log (id) {
            id -> Int4,
            timestamp -> Timestamptz,
            action -> Varchar,
            token_id -> Nullable<Varchar>,
            actor_token_id -> Nullable<Varchar>,
            tenant_id -> Nullable<Varchar>,
            details -> Nullable<Json>,
            ip_address -> Nullable<Inet>,
            user_agent -> Nullable<Varchar>,
            resource -> Nullable<Varchar>,
            action_type -> Nullable<Varchar>,
        }
    }

    diesel::joinable!(pipeline_executions -> contexts (context_id));
    diesel::joinable!(task_executions -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> task_executions (task_execution_id));
    diesel::joinable!(task_execution_metadata -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> contexts (context_id));
    diesel::joinable!(recovery_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(recovery_events -> task_executions (task_execution_id));
    diesel::joinable!(schedule_executions -> schedules (schedule_id));
    diesel::joinable!(schedule_executions -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(workflow_packages -> workflow_registry (registry_id));
    diesel::joinable!(execution_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(execution_events -> task_executions (task_execution_id));
    diesel::joinable!(task_outbox -> task_executions (task_execution_id));

    // API Keys table (server mode only — Postgres)
    diesel::table! {
        api_keys (id) {
            id -> Uuid,
            key_hash -> Text,
            name -> Text,
            permissions -> Text,
            created_at -> Timestamptz,
            revoked_at -> Nullable<Timestamptz>,
        }
    }

    // Auth table relationships - using allow_tables_to_appear_in_same_query instead
    // of joinable! to avoid conflicts with multiple foreign keys to same table.
    // Manual join syntax should be used in queries when joining auth tables.

    #[cfg(not(feature = "auth"))]
    diesel::allow_tables_to_appear_in_same_query!(
        api_keys,
        contexts,
        execution_events,
        key_trust_acls,
        package_signatures,
        pipeline_executions,
        recovery_events,
        schedule_executions,
        schedules,
        signing_keys,
        task_executions,
        task_execution_metadata,
        task_outbox,
        trusted_keys,
        workflow_packages,
        workflow_registry,
    );

    #[cfg(feature = "auth")]
    diesel::allow_tables_to_appear_in_same_query!(
        auth_audit_log,
        auth_tokens,
        contexts,
        execution_events,
        key_trust_acls,
        package_signatures,
        pipeline_executions,
        recovery_events,
        schedule_executions,
        schedules,
        signing_keys,
        task_executions,
        task_execution_metadata,
        task_outbox,
        trusted_keys,
        workflow_packages,
        workflow_registry,
    );
}

#[cfg(feature = "sqlite")]
mod sqlite_schema {
    // SQLite schema with appropriate type mappings
    diesel::table! {
        contexts (id) {
            id -> Binary,
            value -> Text,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        pipeline_executions (id) {
            id -> Binary,
            pipeline_name -> Text,
            pipeline_version -> Text,
            status -> Text,
            context_id -> Nullable<Binary>,
            started_at -> Text,
            completed_at -> Nullable<Text>,
            error_details -> Nullable<Text>,
            recovery_attempts -> Integer,
            last_recovery_at -> Nullable<Text>,
            paused_at -> Nullable<Text>,
            pause_reason -> Nullable<Text>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        task_executions (id) {
            id -> Binary,
            pipeline_execution_id -> Binary,
            task_name -> Text,
            status -> Text,
            started_at -> Nullable<Text>,
            completed_at -> Nullable<Text>,
            attempt -> Integer,
            max_attempts -> Integer,
            error_details -> Nullable<Text>,
            trigger_rules -> Text,
            task_configuration -> Text,
            retry_at -> Nullable<Text>,
            last_error -> Nullable<Text>,
            recovery_attempts -> Integer,
            last_recovery_at -> Nullable<Text>,
            sub_status -> Nullable<Text>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        recovery_events (id) {
            id -> Binary,
            pipeline_execution_id -> Binary,
            task_execution_id -> Nullable<Binary>,
            recovery_type -> Text,
            recovered_at -> Text,
            details -> Nullable<Text>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        execution_events (sequence_num) {
            id -> Binary,
            pipeline_execution_id -> Binary,
            task_execution_id -> Nullable<Binary>,
            event_type -> Text,
            event_data -> Nullable<Text>,
            worker_id -> Nullable<Text>,
            created_at -> Text,
            sequence_num -> BigInt,
        }
    }

    diesel::table! {
        task_outbox (id) {
            id -> BigInt,
            task_execution_id -> Binary,
            created_at -> Text,
        }
    }

    diesel::table! {
        task_execution_metadata (id) {
            id -> Binary,
            task_execution_id -> Binary,
            pipeline_execution_id -> Binary,
            task_name -> Text,
            context_id -> Nullable<Binary>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        workflow_registry (id) {
            id -> Binary,
            created_at -> Text,
            data -> Binary,
        }
    }

    diesel::table! {
        workflow_packages (id) {
            id -> Binary,
            registry_id -> Binary,
            package_name -> Text,
            version -> Text,
            description -> Nullable<Text>,
            author -> Nullable<Text>,
            metadata -> Text,
            storage_type -> Text,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        schedules (id) {
            id -> Binary,
            schedule_type -> Text,
            workflow_name -> Text,
            enabled -> Integer,
            cron_expression -> Nullable<Text>,
            timezone -> Nullable<Text>,
            catchup_policy -> Nullable<Text>,
            start_date -> Nullable<Text>,
            end_date -> Nullable<Text>,
            next_run_at -> Nullable<Text>,
            last_run_at -> Nullable<Text>,
            trigger_name -> Nullable<Text>,
            poll_interval_ms -> Nullable<Integer>,
            allow_concurrent -> Nullable<Integer>,
            last_poll_at -> Nullable<Text>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    diesel::table! {
        schedule_executions (id) {
            id -> Binary,
            schedule_id -> Binary,
            pipeline_execution_id -> Nullable<Binary>,
            scheduled_time -> Nullable<Text>,
            claimed_at -> Nullable<Text>,
            created_at -> Text,
            updated_at -> Text,
        }
    }

    // Package Signing Tables
    diesel::table! {
        signing_keys (id) {
            id -> Binary,
            org_id -> Binary,
            key_name -> Text,
            encrypted_private_key -> Binary,
            public_key -> Binary,
            key_fingerprint -> Text,
            created_at -> Text,
            revoked_at -> Nullable<Text>,
        }
    }

    diesel::table! {
        trusted_keys (id) {
            id -> Binary,
            org_id -> Binary,
            key_fingerprint -> Text,
            public_key -> Binary,
            key_name -> Nullable<Text>,
            trusted_at -> Text,
            revoked_at -> Nullable<Text>,
        }
    }

    diesel::table! {
        key_trust_acls (id) {
            id -> Binary,
            parent_org_id -> Binary,
            child_org_id -> Binary,
            granted_at -> Text,
            revoked_at -> Nullable<Text>,
        }
    }

    diesel::table! {
        package_signatures (id) {
            id -> Binary,
            package_hash -> Text,
            key_fingerprint -> Text,
            signature -> Binary,
            signed_at -> Text,
        }
    }

    diesel::joinable!(pipeline_executions -> contexts (context_id));
    diesel::joinable!(task_executions -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> task_executions (task_execution_id));
    diesel::joinable!(task_execution_metadata -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(task_execution_metadata -> contexts (context_id));
    diesel::joinable!(recovery_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(recovery_events -> task_executions (task_execution_id));
    diesel::joinable!(schedule_executions -> schedules (schedule_id));
    diesel::joinable!(schedule_executions -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(execution_events -> pipeline_executions (pipeline_execution_id));
    diesel::joinable!(execution_events -> task_executions (task_execution_id));
    diesel::joinable!(task_outbox -> task_executions (task_execution_id));

    diesel::allow_tables_to_appear_in_same_query!(
        contexts,
        execution_events,
        key_trust_acls,
        package_signatures,
        pipeline_executions,
        recovery_events,
        schedule_executions,
        schedules,
        signing_keys,
        task_executions,
        task_execution_metadata,
        task_outbox,
        trusted_keys,
    );
}

// Re-export the appropriate schema based on feature flags

// Unified schema - use this for new code (works with both backends)
pub mod unified {
    pub use super::unified_schema::*;
}

// Legacy backend-specific modules (to be removed after migration)
// Use schema::postgres::* or schema::sqlite::* for legacy code
#[cfg(feature = "postgres")]
pub mod postgres {
    pub use super::postgres_schema::*;
}

#[cfg(feature = "sqlite")]
pub mod sqlite {
    pub use super::sqlite_schema::*;
}
