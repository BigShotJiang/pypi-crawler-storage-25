from odoo import fields, models, release


class ResPartner(models.Model):
    _inherit = "res.partner"

    release = fields.Char(string="Example 0 release", default=release.series)
