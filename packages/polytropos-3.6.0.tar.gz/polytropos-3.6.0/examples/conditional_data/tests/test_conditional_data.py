from unittest import skipIf, skipUnless

from odoo.release import series
from odoo.tests import Form, TransactionCase

from polytropos import ph


class ConditionalDataCase(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        ph.logger.info("Testing Odoo with release %s", series)
        cls.partner = cls.env["res.partner"].create({"name": "Test"})

    def test_default_release_value(self):
        self.assertEqual(self.partner.release, series)

    @skipIf(ph.rel(">=18.0"), "In Odoo 18+, an extra view removes the field")
    def test_view_has_field(self):
        with Form(self.partner) as f_partner:
            self.assertEqual(f_partner.release, series)
            f_partner.release = "foo"
        self.assertEqual(self.partner.release, "foo")

    @skipUnless(ph.rel(">=18.0"), "In Odoo 18+, an extra view removes the field")
    def test_view_does_not_have_field(self):
        with self.assertRaises(AssertionError):
            with Form(self.partner) as f_partner:
                f_partner.release = "Cannot set field because it's removed in the view"
        self.partner.release = "But it is in the model"
        self.assertEqual(self.partner.release, "But it is in the model")
