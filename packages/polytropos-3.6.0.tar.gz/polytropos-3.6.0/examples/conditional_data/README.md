# Conditional Data

This example demonstrates how to define version-specific data files (XML, CSV) in Odoo
manifests.

## What It Shows

-   **Data files**: XML views, CSV imports, security rules
-   **Version conditions**: `releases = ">=18"` for Odoo 18 and later
-   **Deep merge behavior**: Lists are concatenated, not replaced

## TOML Format

```toml
[[tool.polytropos.manifest]]
depends = ["base"]
data = [
    "data/common_data.xml",
]

[[tool.polytropos.manifest]]
releases = ">=18"
data = [
    "data/v18_only_data.xml",
]
```

## Merge Behavior

Lists are appended when merging version-specific overrides:

-   Base manifest: `["data/base.xml"]`
-   v18+ override: `["data/v18.xml"]`
-   Result for v18: `["data/base.xml", "data/v18.xml"]`

This means you don't need to repeat common data files in each override.

## See Also

-   [Odoo Module Data Files](https://www.odoo.com/documentation/18.0/developer/tutorials/getting_started/03_modules.html#data-files)
