---
toc: true
---

# Src layout example

This example indicates in the pyproject:

```toml title="pyproject.toml"
[tool.polytropos]
src = "./src"
```

This means that actual module code is inside the `src` folder.

## Readme management

This markdown readme will be converted into rst and bundled as `description` in the
auto-generated `__manifest__.py` at build time.

### Auto-included split docs

> [!TIP]
>
> You will benefit from reading this README sources, to understand how this is written.

Polytropos supports [pandoc-include](https://github.com/DCsunset/pandoc-include), so you
can add a directive and everything inside `./docs` will be added:

!include`incrementSection=3` docs/\*.md

### Assets

A nice nitpick. `src` and `./src` prefixes are stripped in the description:

![Without dot](src/static/description/icon.png)
![Wit dot](./src/static/description/icon.png)

Absolute URLs are not affected:

![Polytropos icon, external](https://moduon.gitlab.io/polytropos/img/logo.svg)
