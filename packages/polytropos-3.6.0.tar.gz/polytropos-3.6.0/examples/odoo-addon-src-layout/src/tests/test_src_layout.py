from odoo.addons import src_layout
from odoo.modules.module import get_manifest
from odoo.tests import TransactionCase
from odoo.tools import file_path


class TestSrcLayout(TransactionCase):
    def test_module_importable(self):
        self.assertTrue(src_layout.found)

    def test_file_path(self):
        self.assertTrue(
            file_path("src_layout/tests/__init__.py").endswith(
                "/odoo/addons/src_layout/tests/__init__.py"
            )
        )

    def test_manifest_description_image_paths(self):
        manifest = get_manifest("src_layout")
        description = manifest.get("description", "")
        self.assertIn("/src_layout/static/description/icon.png", description)
        self.assertNotIn("src/static/description/icon.png", description)
        self.assertNotIn("./src/static/description/icon.png", description)
