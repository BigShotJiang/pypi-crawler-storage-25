# Install

    pip install git+https://gitlab.com/moduon/polytropos.git?subdirectory=examples/odoo-addon-src-layout
