from odoo.tests import TransactionCase


class ConditionalAssetsCase(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.module = cls.env["ir.module.module"].search(
            [("name", "=", "conditional_assets")], limit=1
        )
        cls.assertTrue(cls.module, "conditional_assets module should be available")

    def test_module_installed(self):
        self.assertIn(self.module.state, ("installed", "to install"))
