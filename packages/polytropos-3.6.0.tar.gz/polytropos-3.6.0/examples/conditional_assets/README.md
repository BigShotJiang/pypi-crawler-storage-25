# Conditional Assets

This example demonstrates how to define version-specific CSS assets in Odoo manifests.

## What It Shows

-   **Asset bundles**: Named collections of CSS files
-   **Include directive**: `["include", "bundle.name"]` - includes all files from
    another bundle
-   **Remove directive**: `["remove", "path/to/file.css"]` - removes a specific file
-   **After directive**: `["after", "reference.css", "new.css"]` - inserts a file after
    a reference

## TOML Format

In `pyproject.toml`, asset directives use TOML nested arrays:

```toml
[tool.polytropos.manifest.assets]
"my_module.assets_backend" = [
    ["include", "my_module.assets_common"],
    ["remove", "my_module/static/src/css/base.css"],
    ["after", "my_module/static/src/css/ref.css", "my_module/static/src/css/new.css"],
]
```

## Version-Specific Assets

Odoo 17 uses `backend_legacy.css` while Odoo 18+ uses `backend_modern.css`:

```toml
# Base manifest (all versions)
[tool.polytropos.manifest.assets]
"conditional_assets.assets_backend" = [
    ["include", "conditional_assets.assets_common"],
    ["remove", "conditional_assets/static/src/css/base.css"],
    "conditional_assets/static/src/css/backend_legacy.css",
]

# Override for Odoo 18+
[[tool.polytropos.manifest]]
releases = ">=18"

[tool.polytropos.manifest.assets]
"conditional_assets.assets_backend" = [
    ["include", "conditional_assets.assets_common"],
    ["remove", "conditional_assets/static/src/css/backend_legacy.css"],
    ["after", "...", "conditional_assets/static/src/css/backend_modern.css"],
]
```

## See Also

-   [Odoo Asset Documentation](https://www.odoo.com/documentation/19.0/developer/reference/frontend/assets.html)
