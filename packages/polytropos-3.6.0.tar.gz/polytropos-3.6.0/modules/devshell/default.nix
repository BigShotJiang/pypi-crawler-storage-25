/**
Devshell module for developing polytropos-based Odoo addons.

# Usage

Add this module to your flake to enable a development shell with all necessary
dependencies for building Odoo addons:

```nix
{
    inputs = {
        devshell.url = "github:numtide/devshell";
        nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/*";
        polytropos.url = "gitlab:moduon/polytropos";
    };

    outputs = inputs: {
        devShells.x86_64-linux.default = inputs.devshell.legacyPackages.x86_64-linux.mkShell {
            imports = [
                inputs.polytropos.modules.devshell.default
            ];
        };
    };
}
```

# Entering the Devshell

```bash
nix develop --impure
```

Or with direnv:

```bash
direnv allow
```

# What's Included

-   Python 3
-   UV
-   Build dependencies for Odoo addon development
*/
{inputs, ...}: {
  lib,
  pkgs,
  ...
}: {
  key = "polytropos#modules.devshell.default";
  imports = [
    inputs.precommix.modules.devshell.buildVars
  ];

  # Local impure build deps
  devshell.packages = [
    (lib.lowPrio pkgs.xorg.xorgproto) # Conflicts with libx11.dev
    pkgs.cairo.dev
    pkgs.cmake
    pkgs.cyrus_sasl.dev
    pkgs.gcc
    pkgs.libffi
    pkgs.libffi.dev
    pkgs.libpq.pg_config
    pkgs.libx11.dev
    pkgs.libxcb.dev
    pkgs.libxml2_13
    pkgs.libxml2_13.dev
    pkgs.libxslt
    pkgs.libxslt.dev
    pkgs.ninja
    pkgs.openldap
    pkgs.openldap.dev
    pkgs.pkg-config
    pkgs.postgresql.lib

    # HACK https://github.com/nix-community/poetry2nix/commit/632417e05a455e339ccd506a05e66711819de1f8
    # FIXME Change for perSystem
    (pkgs.writeTextFile {
      name = "openldap-lib-fix";
      destination = "/lib/libldap_r.so";
      text = "INPUT ( libldap.so )\n";
    })
  ];

  commands = [
    {package = pkgs.python3;}
    {package = pkgs.uv;}
  ];

  env = [
    {
      # Use always python as supplied by Nix
      name = "UV_PYTHON_PREFERENCE";
      value = "only-system";
    }
  ];
}
