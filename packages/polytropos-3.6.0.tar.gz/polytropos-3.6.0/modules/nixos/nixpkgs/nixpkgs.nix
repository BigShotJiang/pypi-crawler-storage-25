{inputs, ...} @ args: {
  config = import ./config.nix;
  overlays = import ./overlays.nix args;
}
