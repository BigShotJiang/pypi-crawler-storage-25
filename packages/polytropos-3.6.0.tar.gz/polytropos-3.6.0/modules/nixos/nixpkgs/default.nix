{inputs, ...} @ args: {
  nixpkgs = import ./nixpkgs.nix args;
}
