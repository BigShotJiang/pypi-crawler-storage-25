{
  permittedInsecurePackages = [
    "python3.11-pypdf2-3.0.1"
    "python3.12-pypdf2-3.0.1"
    "python3.13-pypdf2-3.0.1"
  ];
}
