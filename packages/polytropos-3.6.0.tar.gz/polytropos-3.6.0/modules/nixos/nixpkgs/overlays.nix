{inputs, ...}: [
  # HACK https://github.com/numtide/blueprint/issues/22#issuecomment-2599640569
  (final: _prev: {
    unstable = import inputs.nixpkgs-unstable {
      inherit (final) system config;
    };
  })
]
