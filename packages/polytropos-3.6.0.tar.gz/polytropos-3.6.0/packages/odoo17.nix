{
  odoo ? python.pkgs.toPythonModule pkgs.${pname},
  pkgs,
  pname,
  python ? pkgs.python311,
}:
odoo
