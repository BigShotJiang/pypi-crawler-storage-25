{
  perSystem,
  pname,
}:
perSystem.precommix.${pname}.override {
  runtimeEnv.postFlakeUpdate = ''
    uv lock --upgrade
  '';
}
