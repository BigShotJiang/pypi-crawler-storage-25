{
  pname,
  pkgs,
  flake,
}:
pkgs.writeShellApplication {
  name = pname;
  runtimeInputs = [
    flake.devShells.${pkgs.stdenv.hostPlatform.system}.default
  ];
  text = ''
    mkdocs serve "$@"
  '';
}
