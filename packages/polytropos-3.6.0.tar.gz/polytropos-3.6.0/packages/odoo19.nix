{
  odoo ? python.pkgs.toPythonModule pkgs.unstable.${pname},
  pkgs,
  pname,
  python ? pkgs.unstable.python312,
}:
odoo
