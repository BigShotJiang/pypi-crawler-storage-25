{
  lib ? pkgs.lib,
  odoo ? python.pkgs.toPythonModule pkgs.odoo,
  pkgs,
  python ? pkgs.python312,
}:
lib.throwIfNot (lib.versions.major odoo.version == "18") "Unexpected Odoo version" odoo
