{
  flake,
  inputs,
  lib ? pkgs.lib,
  pkgs,
  python ? pkgs.python3,
  ...
}: let
  projectRoot = inputs.nix-filter {
    root = ../..;
    include = [
      "docs"
      "pyproject.toml"
      "README.md"
      "src"
      "tests"
    ];
  };
  project = inputs.pyproject-nix.lib.project.loadPyproject {
    inherit projectRoot;
  };
  basePkg = python.pkgs.buildPythonPackage (project.renderers.buildPythonPackage {inherit python;});
  # HACK Make sure build environment won't pollute pandoc-include behavior
  pandoc-include = pkgs.pandoc-include.overridePythonAttrs (old: {
    makeWrapperArgs = ["--set PYTHONPATH :"] ++ (old.makeWrapperArgs or []);
  });
in
  basePkg.overridePythonAttrs (old: {
    propagatedNativeBuildInputs = (old.propagatedNativeBuildInputs or []) ++ [pkgs.pandoc pandoc-include];
    meta = old.meta // {maintainers = with lib.maintainers; [yajo];};
    passthru =
      old.passthru
      // {
        tests = flake.lib.mkAddonsTests pkgs ../../examples;
      };
  })
