# Manifest Configuration

Polytropos generates the `__manifest__.py` dynamically for each release based on your
`pyproject.toml` configuration.

## Version vs. Release

For Polytropos we use this specific terminology:

-   **Release** refers to Odoo release (Odoo 18.0, 19.0, etc.)
-   **Version** refers to your addon version (1.0.0, 2.34.1, etc.).

Therefore, a single _version_ of the addon can have different _releases_. Built
artifacts get a combination of release and version.

!!! example

    ```shell
    # Build 2 releases for the conditional_assets example
    cd examples/conditional_assets
    uv build --wheel --config-setting odoo_release=19.0
    uv build --wheel --config-setting odoo_release=18.0

    # Check all releases artifacts
    ls -1 dist/
    conditional_assets-18.0.1.0.0-py3-none-any.whl
    conditional_assets-18.0.1.0.0.tar.gz
    conditional_assets-19.0.1.0.0-py3-none-any.whl
    conditional_assets-19.0.1.0.0.tar.gz
    ```

## Dynamic Version

Your `pyproject.toml` must declare `version` as dynamic:

```toml title="pyproject.toml"
[project]
name = "odoo-addon-my-module"
version = "1.0.0"
dynamic = ["version"]
```

This is required because Polytropos generates a version that combines the Odoo release
with your module version (e.g., `18.0.1.2.3`). Without `dynamic = ["version"]`, tools
like **uv** cannot properly resolve dependencies that depend on the Odoo release.

For example, if your addon depends on `odoo-addon-other==18.0.*`, but your addon is
tagged with version `1.2.3`, uv will fail to solve dependencies because it sees a
mismatch between the static version in `[project]` and the actual wheel version.

Polytropos emits a warning during build if version is not declared as dynamic.

## Manifest values auto-populated from [project]

Several manifest fields are automatically populated from
[the standards-based `[project]` section](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
of `pyproject.toml`:

| Manifest Field                 | pyproject.toml Source                                                   |
| ------------------------------ | ----------------------------------------------------------------------- |
| `name`                         | `project.name`                                                          |
| `summary`                      | `project.description`                                                   |
| `description`                  | `project.readme` (see [README Handling](#readme-handling))              |
| `author`                       | `project.authors[*].name`                                               |
| `maintainers`                  | `project.maintainers[*].{name,email}` (see [Maintainers](#maintainers)) |
| `license`                      | `project.license`                                                       |
| `website`                      | `project.urls.Homepage`                                                 |
| `depends`                      | `project.dependencies` (see [Dependencies](#dependencies))              |
| `external_dependencies.python` | `project.dependencies` (see [Dependencies](#dependencies))              |

This avoids duplication - you define these once in `[project]` and they automatically
appear in the manifest.

The `name` field is generated from the module name (converted to title case, e.g.,
`my_module` → `My Module`). You can override it explicitly in
`[[tool.polytropos.manifest]]`.

!!! example

    These instructions:

    ```toml title="pyproject.toml"
    [build-system]
    requires = ["polytropos[build]"]
    build-backend = "polytropos.build"

    [project]
    name = "odoo-addon-my-module"
    version = "1.22.30"
    description = "My awesome Odoo module"
    authors = [
        {name = "My Name", email = "my-email@example.com"},
        {name = "Other Name", email = "other-email@example.com"},
    ]
    license = "LGPL-3"

    [project.urls]
    Homepage = "https://mywebsite.com"

    [tool.polytropos]
    default_odoo_release = "19.0"
    ```

    Produce this manifest:

    ```python title="my_module/__manifest__.py"
    {
        "name": "My Module",
        "summary": "My awesome Odoo module",
        "author": "My Name, Other Name",
        "license": "LGPL-3",
        "website": "https://mywebsite.com",
        "version": "19.0.1.22.30",
    }
    ```

Polytropos will never add any other fields to the manifest automatically.

### Maintainers

The `maintainers` field in `__manifest__.py` is not used by Odoo upstream. However, it
is used in OCA, where it expects a list of GitHub usernames. When you specify
`project.maintainers` in `pyproject.toml`, Polytropos extracts the username
automatically:

1. **[GitHub noreply email](https://docs.github.com/en/account-and-profile/reference/email-addresses-reference#your-noreply-email-address)**
   → Extracts the username from the email pattern.
1. **Regular email only** -> Uses the `email` field as-is.
1. **Name only, or regular email + name** → Uses the `name` field as-is

!!! example

    ```toml title="pyproject.toml"
    [project]
    maintainers = [
        {name = "John Doe", email = "12345+johndoe@users.noreply.github.com"},
        {name = "Alice Johnson", email = "alice@users.noreply.github.com"},
        {name = "Jane Smith", email = "jane@example.com"},
        {name = "Bob Wilson"},
        {email = "pocahontas@example.com"},
    ]
    ```

    Produces:

    ```python title="__manifest__.py"
    {
        "maintainers": [
            "johndoe",
            "alice",
            "Jane Smith",
            "Bob Wilson",
            "pocahontas@example.com",
        ]
    }
    ```

### README Handling

If `project.readme` is specified in `pyproject.toml`, Polytropos automatically converts
it into [reStructuredText syntax](https://devguide.python.org/documentation/markup/) and
sets it as the `description` field in the manifest.

The format is auto-detected from the file extension (it follows the
[PyPA specification](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/#readme)):

-   `README.md` → text/markdown
-   `README.rst` → text/x-rst
-   Other extensions → text/plain

!!! example

    ```toml title="pyproject.toml"
    [build-system]
    requires = ["polytropos[build]"]
    build-backend = "polytropos.build"

    [project]
    name = "odoo-addon-my-module"
    version = "1.0.0"
    dynamic = ["version"]
    readme = "README.md"

    [tool.polytropos]
    default_odoo_release = "19.0"
    ```

    If `README.md` contains:

    ```markdown
    # My Module

    This module does amazing things.
    ```

    The generated manifest will include:

    ```python
    {
        "name": "My Module",
        "description": """My Module
    =========

    This module does amazing things.""",
        "version": "19.0.1.0.0",
    }
    ```

    You can also use RST directly:

    ```toml title="pyproject.toml"
    [project]
    name = "odoo-addon-my-module"
    version = "1.0.0"
    dynamic = ["version"]
    readme = "README.rst"

    [tool.polytropos]
    default_odoo_release = "19.0"
    ```

#### Pandoc Include

To perform all README conversion magic, these binaries must be present:

-   [pandoc](https://pandoc.org/)
-   [pandoc-include](https://github.com/DCsunset/pandoc-include)

!!! tip

    If you build using Nix, these are already included as
    `propagatedNativeBuildInputs` of Polytropos.

!!! example

    These files:

    ```toml title="pyproject.toml"
    [build-system]
    requires = ["polytropos[build]"]
    build-backend = "polytropos.build"

    [project]
    name = "odoo-addon-my-module"
    version = "1.0.0"
    dynamic = ["version"]
    readme = "README.md"
    dependencies = ["odoo"]

    [tool.polytropos]
    default_odoo_release = "19.0"
    ```

    ```md title="README.md"
    # My Module

    !include CHANGELOG.md
    ```

    ```md title="CHANGELOG.md"
    # Changelog

    ## 1.0.0

    -   Initial release
    ```

    Produce this manifest:

    ```python
    {
        "name": "My Module",
        "description": """My Module
    =========

    Changelog
    =========

    1.0.0
    -----

    -   Initial release""",
        "version": "19.0.1.0.0",
    }
    ```

#### Image Paths

Image paths in README files are automatically adjusted to let them display properly in
Odoo's UI.

!!! example

    With this structure:

    ```
    project/
        pyproject.toml
        README.md
        src/
            static/
                description/
                icon.png
            __init__.py
    ```

    ```toml title="pyproject.toml"
    [build-system]
    requires = ["polytropos[build]"]
    build-backend = "polytropos.build"

    [project]
    name = "odoo-addon-my-module"
    version = "1.0.0"
    dynamic = ["version"]
    readme = "README.md"

    [tool.polytropos]
    default_odoo_release = "19.0"
    src = "src" # It works in non-src layout too
    ```

    ```markdown title="README.md"
    # My Module

    ![Icon](src/static/description/icon.png)
    ```

    The generated manifest will contain:

    ```python title="__manifest__.py"
    {
        "name": "My Module",
        "description": """My Module
    =========

    |Icon|

    .. |Icon| image:: /my_module/static/description/icon.png""",
        "version": "19.0.1.0.0",
    }
    ```

Polytropos uses a Lua filter to rewrite image paths during conversion:

1. Reads the `tool.polytropos.src` directory from `pyproject.toml` (default: `.`)
2. Strips the leading `./` from relative paths
3. Replaces the source directory prefix with `/<module_name>/` for Odoo's URL system

This ensures images work correctly when displayed in the Odoo UI, regardless of the
original path in your git repository.

### Project Name

The project name must start with `odoo-addon-` and use hyphens between words. This makes
your modules compatible with the wider Odoo addon package builders ecosystem.

The conversion follows these rules:

-   Package name (Python): `odoo-addon-module-name` (hyphens between words)
-   Module directory: `odoo/addons/module_name` (underscores between words)
-   Manifest name: `Module Name` (human-readable title case)

You can also override the module name explicitly. See below.

### Overriding Auto-populated Fields

If you need to override an auto-populated field, you can do so in
`[tool.polytropos.manifest]`:

```toml
[tool.polytropos.manifest]
name = "Custom Name"
author = "Custom Author"
```

!!! tip

    A warning will be emitted if you define the same field in both `[project]` and
    `[tool.polytropos.manifest]`. The manifest value takes precedence, but it's cleaner to
    define it only in `[project]`.

## Version-specific Overrides

Use overrides to specify different values per Odoo release using
[PEP 440 specifiers](https://peps.python.org/pep-0440/#version-specifiers):

```toml
[[tool.polytropos.manifest]]
depends = ["base"]
data = [
    "views/res_partner.xml"
]

[[tool.polytropos.manifest]]
releases = ">=18"
application = true

[[tool.polytropos.manifest]]
releases = "<16"
data = [
    "views/res_partner_legacy.xml"
]
```

### Merge Behavior

When merging, Polytropos follows these rules strictly:

1. `releases` key is removed (only used by Polytropos)
1. **Dicts are merged**: Keys are combined recursively
1. **Lists are combined**: Both sets of items are kept
1. **Values are replaced**: The last defined value wins

All manifest fields support overrides: `depends`, `data`, `demo`, `assets`,
`application`, `installable`, etc.

### Assets (CSS/JS)

Odoo uses asset bundles for web files. Define them in `pyproject.toml`:

```toml
[[tool.polytropos.manifest]]
depends = ["base"]
assets."my_module.assets_backend" = [
    # Include from another bundle
    ["include", "my_module.assets_common"],
    # Remove a file
    ["remove", "my_module/static/src/css/base.css"],
    # Add before a reference
    ["prepend", "my_module/static/src/css/ref.css", "my_module/static/src/css/new.css"],
    # Add after a reference
    ["after", "my_module/static/src/css/ref.css", "my_module/static/src/css/new.css"],
    # Direct file
    "my_module/static/src/css/legacy.css",
]

# Override for Odoo 18+
[[tool.polytropos.manifest]]
releases = ">=18"
assets."my_module.assets_backend" = [
    ["remove", "my_module/static/src/css/legacy.css"],
]
```

Polytropos is doing nothing special with this, just following its normal rules. Check
out
[Odoo Asset Documentation](https://www.odoo.com/documentation/19.0/developer/reference/frontend/assets.html)
to know how Odoo will process assets.

## Dependencies

If Polytropos addons don't define the `odoo` dependency, it will be implicitly added and
all releases will be buildable.

If `odoo` is defined, you will not be able to build wheels for incompatible releases.

Other dependencies can be added as `[project].dependencies` (both addons (with
`odoo-addon-` prefix) and other dependencies, for all releases), as
`[[tool.polytropos.manifest]].depends` (only addons (without prefix)) or as
`[[tool.polytropos.manifest]].external_dependencies.python` (both multi-version).

!!! example

    These instructions:

    ```toml title="pyproject.toml"
    [project]
    name = "odoo-addon-example"
    version = "1.0.0"
    dependencies = [
        # Forbid building for 17.0 or earlier
        "odoo>=18.0",

        # Depend on this OCA addon for all releases
        "odoo-addon-partner-fax",

        # Depend on this standard Python dependency on all releases
        "funcy>=1",
    ]

    [tool.polytropos]
    default_odoo_release = "19.0"

    [[tool.polytropos.manifest]]
    depends = [
        # Odoo CE/EE addons are never packaged on PyPi, so you must specify
        # these dependencies always directly here in the manifest section
        "sale",

        # You can also add OCA or other addon dependencies here if you prefer
        "queue_job",
    ]
    external_dependencies.python = [
        # You can add Python dependencies here if you prefer
        "cowsay>6",
    ]

    [[tool.polytropos.manifest]]
    # These overrides are only for Odoo 19+
    releases = ">=19"
    depends = [
        "project", # Odoo CE
        "queue_job_cron", # OCA
    ]
    external_dependencies.python = [
        "cowsay>7",
        "copier>=9.0",
    ]
    ```

    Will build this manifest for Odoo 18:

    ```python title="example/__manifest__.py"
    {
        "name": "Example",
        "version": "18.0.1.0.0",
        "depends": [
            "partner_fax",
            "sale",
            "queue_job",
        ],
        "external_dependencies": {
            "python": [
                "cowsay>6",
            ],
        },
    }
    ```

    And this manifest for Odoo 19:

    ```python title="example/__manifest__.py"
    {
        "name": "Example",
        "version": "19.0.1.0.0",
        "depends": [
            "project",
            "queue_job_cron",
            "sale",
            "queue_job",
        ],
        "external_dependencies": {
            "python": [
                "cowsay>6",
                "cowsay>7",
                "copier>=9.0",
            ],
        },
    }
    ```

    At the same time, the wheel will depend on these Python packages:

    - Odoo 18 release:
        -   `cowsay>6`
        -   `funcy>=1`
        -   `odoo-addon-partner-fax`
        -   `odoo-addon-queue-job`
        -   `odoo==18.0.*`
    - Odoo 19 release:
        -   `copier>=9.0`
        -   `cowsay>7`
        -   `odoo-addon-partner-fax`
        -   `odoo-addon-queue-job-cron`
        -   `odoo-addon-queue-job`
        -   `odoo==19.0.*`

## See Also

-   [Examples Folder](https://gitlab.com/moduon/polytropos/-/tree/main/examples) -
    Real-world module examples

## File Maps

Use `[[tool.polytropos.files]]` to override files in the built module based on the Odoo
release. This is useful when Odoo expects a fixed file path but you need different
content per release (e.g.,
[`_parse_csv` in `account.chart.template`](https://github.com/odoo/odoo/blob/b293ce50e0fc9355ffd233557f079916b514eac7/addons/account/models/chart_template.py#L1335)).

Each entry maps the contents of a `src` directory into a `dst` directory within the
addon root, overwriting any existing files. Only entries matching the target Odoo
release (via `releases` specifier) are applied.

!!! warning

    Always git-ignore `dst` files. They will differ by release. Just keep `src`
    in git and generate `dst` during build.

```toml
# For Odoo < 18, place 17.0 CSV files in the expected paths
[[tool.polytropos.files]]
releases = "<18"
src = "data/template/17.0"
dst = "data/template"

# For Odoo >= 18, place 18.0 CSV files instead
[[tool.polytropos.files]]
releases = ">=18"
src = "data/template/18.0"
dst = "data/template"
```

With this directory structure:

```
.gitignore
src/
  data/template/
    17.0/
      account.tax-es_common.csv
      account.fiscal.position-es_common.csv
    18.0/
      account.tax-es_common.csv
      account.fiscal.position-es_common.csv
  __init__.py
```

The resulting output for Odoo 18 will contain:

```
data/template/
  account.tax-es_common.csv          (contents from 18.0/)
  account.fiscal.position-es_common.csv
```

### Build modes

-   **Wheel**: Files are copied, overwriting any existing files in `dst`. An error is
    raised if the source directory does not exist.
-   **Editable**: Symlinks are created when possible. An error is raised if the source
    directory does not exist. Files not in `.gitignore` trigger a warning. Existing real
    files in `dst` are skipped with a warning.
-   **Sdist**: File maps are not applied (sdist is version-independent).

`[[tool.polytropos.files]]` must be a list (double bracket syntax).
