# Comparison with Other Tools

## Alternatives

| Tool                                                             | PEP 517 compliant | Base mechanism                                                   | Multi-release | Multi-addon | Status     |
| ---------------------------------------------------------------- | ----------------- | ---------------------------------------------------------------- | ------------- | ----------- | ---------- |
| **Polytropos**                                                   | ✅ Yes            | Read `pyproject.toml` → Generate `__manifest__.py` → Build wheel | Yes 💖        | No          | Active     |
| **[whool](https://github.com/sbidoul/whool)**                    | ✅ Yes            | Read `pyproject.toml` and `__manifest__.py` → Build wheel        | No            | No          | Active     |
| **[hatch-odoo](https://github.com/acsone/hatch-odoo)**           | ✅ Yes            | Read `pyproject.toml` and `./*/__manifest__.py` → Build wheel    | No            | Yes         | Active     |
| **[setuptools-odoo](https://github.com/acsone/setuptools-odoo)** | ⛔ No             | Read `__manifest__.py` → Generate `setup.py` → Build wheel       | No            | Yes         | Deprecated |
| **[oca.recipe.odoo](https://oca.github.io/oca.recipe.odoo/)**    | ⛔ No             | Buildout recipe → Install Odoo and addons                        | No            | Partial     | Legacy     |

In general, all other tools rely on version-specific code with a properly-formed
`__manifest__.py` file to do their job.

Polytropos, instead, allows for multi-version code and produces a version-specific
`__manifest__.py` file at build time, based on the instructions inferred from the
`pyproject.toml` file.

All PEP 517 compliant tools can be combined in the same virtualenv and are
intercompatible. Upvote [odoo/odoo#44001](https://github.com/odoo/odoo/pull/44001) if
you want Odoo to eventually become also compliant.

## How to Choose

-   Ship the same addon across multiple Odoo releases? → **Polytropos**
-   Package one addon for one Odoo release? → **whool**
-   Bundle multiple addons as a single wheel for one Odoo release? → **hatch-odoo**
-   Integration environment (include Odoo and addons)? -> **uv**, combined with the
    others
