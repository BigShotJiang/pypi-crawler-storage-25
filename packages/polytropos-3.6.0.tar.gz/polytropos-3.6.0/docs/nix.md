# Nix

Polytropos provides [Nix](https://nix.dev/) support for developing Odoo addons.

## Features

-   **Devshell module**: Ready-to-use development environment with Python, UV, and build
    dependencies
-   **Helper functions**: Utilities for building and testing Odoo addons with Nix

## API Reference

-   [Nix helpers library](api/nix/lib.md): Functions for working with Odoo versions and
    addon builds
-   [Devshell module](api/nix/devshell.md): Development shell configuration for Odoo
    addon development
