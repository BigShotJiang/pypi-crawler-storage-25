# Helpers

Polytropos provides helper functions for Odoo addon development.

## Installation

To use helpers in your addon, add `polytropos` to your external dependencies:

```toml title="pyproject.toml"
[[tool.polytropos.manifest]]
external_dependencies.python = ["polytropos"]
```

## Usage

Import the `polytropos.ph` module to use the helper functions:

```python
from polytropos import ph

if ph.rel(">=18.0"):
    # Code specific to Odoo 18+
    do_something()
else:
    # Code for Odoo 17 and earlier
    do_something_else()
```

This module requires Odoo to be installed. If Odoo is not available, importing this
module will raise `ModuleNotFoundError`.

## Logging

Polytropos uses Python's standard logging system. You can control the log level using
the `POLYTROPOS_LOGGING` environment variable:

```bash
# Set log level to DEBUG
export POLYTROPOS_LOGGING=DEBUG

# Set log level to INFO
export POLYTROPOS_LOGGING=INFO

# Set log level to WARNING (default)
export POLYTROPOS_LOGGING=WARNING
```

This is useful for debugging conditional code execution and version checks at build
time.

At run time, you can also set its value using standard Odoo logging handlers:

```shell
odoo server --log-handler polytropos:INFO
```

## See Also

-   [API Reference: polytropos.ph](api/python/ph.md)
