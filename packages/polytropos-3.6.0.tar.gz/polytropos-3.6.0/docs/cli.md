# CLI Reference

## init

Initialize a new Polytropos module:

```bash
polytropos init [<path>]
```

Creates a basic `pyproject.toml`, `.gitignore`, and `__init__.py` for an Odoo module.

### Arguments

-   `<path>` (optional): Directory for the module. Defaults to current directory. The
    module name is derived from the directory name. Creates the directory if it doesn't
    exist.

### Examples

```bash
# Initialize in new directory (creates my_module/)
polytropos init my_module

# Initialize in current directory
polytropos init
```

This creates a `pyproject.toml` with:

-   Build system configured for Polytropos
-   Project metadata (name derived from directory, version, description)
-   Default Odoo release (19.0) in `[tool.polytropos]`
