"""Integration tests for Polytropos sdist builds."""

import tarfile
import textwrap

import plumbum

from polytropos.build import build_sdist
from tests.conftest import build_file_tree


class TestSdistBuild:
    """Integration tests for building Odoo modules as sdist."""

    def test_basic_sdist(self, tmp_path):
        """Test building a basic module as sdist.

        The sdist is version-independent - it contains pyproject.toml and source
        files, but NOT a version-specific __manifest__.py. The manifest is
        generated at build time.
        """
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                    """),
                    "__init__.py": "",
                }
            )

            sdist_dir = tmp_path / "dist"
            sdist_dir.mkdir()

            result = build_sdist(str(sdist_dir), {"odoo_release": "17.0"})

            assert result == "test_module-1.0.0.tar.gz"

            sdist_path = sdist_dir / result
            assert sdist_path.exists()

            with tarfile.open(sdist_path) as tar:
                names = tar.getnames()
                assert "test_module-1.0.0/pyproject.toml" in names
                assert "test_module-1.0.0/__init__.py" in names
                assert "test_module-1.0.0/__manifest__.py" not in names

    def test_sdist_version_is_module_version_not_full_version(self, tmp_path):
        """Test that sdist uses module version, not release.module_version.

        Per documentation: sdist version should be just the module version (e.g.,
        1.2.3), not release.module_version (e.g., 18.0.1.2.3).
        """
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "2.5.3"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "19.0"

                        [[tool.polytropos.manifest]]
                    """),
                    "__init__.py": "",
                }
            )

            sdist_dir = tmp_path / "dist"
            sdist_dir.mkdir()

            result = build_sdist(str(sdist_dir), {"odoo_release": "19.0"})

            assert result == "test_module-2.5.3.tar.gz"
            assert "19.0" not in result
            assert "19.0.2.5.3" not in result
