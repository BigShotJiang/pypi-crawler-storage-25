# Polytropos tests

-   Based on pytest
-   Helpers in `conftest.py`
-   Configuration in `../pyproject.toml`

## Testing manifests

Always validate full result:

-   Good: `assert result == {"name": "Test Module", "version": "19.0.1.0.0"}`
-   Bad: `assert result["name"] == "Test Module"`

Data is processed in order of declaration. No need to expect random order in lists:

-   Good: `assert result = {"dependencies": ["a", "b"], ...}`
-   Bad: `assert set(result["dependencies"]) == {"a", "b"}`

## Import always at the top of the file

EXTREMELY IMPORTANT: Never import inside functions. Example with `textwrap.dedent`:

Bad:

    def test_something():
        from textwrap import dedent
        ...

Good:

    from textwrap import dedent

    def test_something():
        ...

## Testing multiline strings

Bad:

    assert result == "This is a multiline\nstring"

Good:

    from textwrap import dedent

    expected = dedent("""\
        This is a multiline
        string
    """).strip()
    assert result == expected

## Running tests

Always fix failing tests. Run tests with:

    uv run pytest

## Chdir with plumbum

Avoid chdir if possible. If needed:

    # Bad
    os.chdir(path)

    # Good
    with plumbum.local.cwd(path):
        ...
