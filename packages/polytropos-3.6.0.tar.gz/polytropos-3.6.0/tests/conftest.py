"""Pytest configuration and helper functions for Polytropos tests."""

import sys
import textwrap
from pathlib import Path
from typing import Any
from unittest import mock

import pytest

from polytropos import ph

# Configure pytest
pytest_plugins = []


@pytest.fixture
def mock_odoo(monkeypatch):
    """Mock Odoo package by patching the series in both ph module and import path."""
    odoo_mock = mock.MagicMock(release=mock.MagicMock(series="19.0"))
    monkeypatch.setattr(ph, "series", "19.0")
    sys.modules["odoo"] = odoo_mock
    sys.modules["odoo.release"] = odoo_mock.release
    return odoo_mock


def build_file_tree(
    spec: dict[str, Any],
    base: Path | None = None,
    dedent: bool = True,
) -> None:
    """Builds a file tree based on the received spec.

    Params:
        spec: A mapping from filesystem paths to file contents.
        base: Base directory for the files (defaults to current dir).
        dedent: Whether to dedent string contents.
    """
    if base is None:
        base = Path.cwd()

    for path, contents in spec.items():
        full_path = base / path
        full_path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(contents, Path):
            full_path.symlink_to(contents)
        elif isinstance(contents, bytes):
            full_path.write_bytes(contents)
        else:
            if dedent:
                contents = textwrap.dedent(contents)
            full_path.write_text(contents)
