"""Tests for polytropos helpers."""

import pytest

from polytropos import ph


class TestRel:
    """Tests for the rel() function."""

    @pytest.mark.parametrize(
        "spec,current,expected",
        [
            (">=17.0", "17.0", True),
            (">=17.0", "16.0", False),
            (">=17.0", "18.0", True),
            (">=18.0", "17.0", False),
            (">=18.0", "18.0", True),
            (">=18.0", "19.0", True),
            ("<18.0", "17.0", True),
            ("<18.0", "18.0", False),
            (">=17.0,<18.0", "17.0", True),
            (">=17.0,<18.0", "17.5", True),
            (">=17.0,<18.0", "18.0", False),
            (">=18.0,<19.0", "18.0", True),
            (">=18.0,<19.0", "18.5", True),
            (">=18.0,<19.0", "19.0", False),
        ],
    )
    def test_release_matching(self, spec, current, expected, monkeypatch):
        """Test that release matching works with various specifiers."""
        monkeypatch.setattr(ph, "series", current)
        result = ph.rel(spec)
        assert result is expected


def test_rel_raises_when_odoo_not_installed(monkeypatch):
    """Test that rel() raises TypeError when Odoo is not installed."""
    monkeypatch.setattr(ph, "series", None)
    with pytest.raises(TypeError):
        ph.rel(">=17.0")
