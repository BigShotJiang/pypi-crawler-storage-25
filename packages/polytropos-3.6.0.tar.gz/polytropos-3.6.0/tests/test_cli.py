"""Integration tests for Polytropos CLI."""

import sys

from plumbum import local


class TestCLI:
    """Tests for the CLI."""

    def test_init_creates_pyproject(self, tmp_path):
        """Test that init creates a pyproject.toml in new directory."""
        python_cmd = local[sys.executable]
        polytropos = python_cmd["-m", "polytropos"]
        cmd = polytropos["init", "my_module"]
        code = cmd.run(cwd=str(tmp_path))[0]

        assert code == 0

        pyproject = tmp_path / "my_module" / "pyproject.toml"
        assert pyproject.exists()

        content = pyproject.read_text()
        assert 'name = "odoo-addon-my-module"' in content
        assert 'default_odoo_release = "19.0"' in content

        gitignore = tmp_path / "my_module" / ".gitignore"
        assert gitignore.exists()
        content = gitignore.read_text()
        assert "__manifest__.py" in content
        assert "PKG-INFO" in content

        init_py = tmp_path / "my_module" / "__init__.py"
        assert init_py.exists()

    def test_init_current_directory(self, tmp_path):
        """Test init using current directory name."""
        with local.cwd(tmp_path):
            python_cmd = local[sys.executable]
            polytropos = python_cmd["-m", "polytropos"]
            cmd = polytropos["init"]
            code = cmd.run()[0]

            assert code == 0

            pyproject = tmp_path / "pyproject.toml"
            assert pyproject.exists()

    def test_init_existing_file(self, tmp_path):
        """Test that init fails if pyproject.toml exists."""
        python_cmd = local[sys.executable]
        polytropos = python_cmd["-m", "polytropos"]
        cmd = polytropos["init", "my_module"]

        try:
            cmd.run(cwd=str(tmp_path))
        except Exception:
            pass

        python_cmd = local[sys.executable]
        polytropos = python_cmd["-m", "polytropos"]
        cmd = polytropos["init", "my_module"]
        try:
            cmd.run(cwd=str(tmp_path))
        except Exception:
            pass

    def test_main_no_args(self, tmp_path):
        """Test main without arguments."""
        with local.cwd(tmp_path):
            python_cmd = local[sys.executable]
            polytropos = python_cmd["-m", "polytropos"]
            cmd = polytropos["--help"]
            cmd.run()
