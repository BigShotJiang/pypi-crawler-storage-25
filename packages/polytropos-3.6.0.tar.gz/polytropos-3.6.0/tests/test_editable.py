"""Integration tests for Polytropos editable installs."""

import ast
import textwrap
from pathlib import Path
from zipfile import ZipFile

import plumbum
import pytest

from polytropos.build import build_editable
from tests.conftest import build_file_tree


def extract_manifest_from_file(module_path: Path) -> dict:
    """Extract manifest dict from module directory."""
    manifest_path = module_path / "__manifest__.py"
    content = manifest_path.read_text()
    content = content.replace("true", "True").replace("false", "False")
    manifest_str = content.split("{", 1)[1].rsplit("}", 1)[0]
    return ast.literal_eval("{" + manifest_str + "}")


class TestEditableBuild:
    """Integration tests for editable installs of Odoo modules."""

    def test_basic_editable(self, tmp_path):
        """Test editable install of a basic module."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert manifest == {
                "name": "Test Module",
                "version": "17.0.1.0.0",
                "depends": [],
            }

            wheel_path = editable_dir / result
            assert wheel_path.exists()

            with ZipFile(wheel_path, "r") as whl:
                names = whl.namelist()
                assert "odoo_addon_test_module.pth" in names

    def test_editable_pth_points_to_real_path(self, tmp_path):
        """Test that .pth file in editable wheel points to an existing path."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            wheel_path = editable_dir / result
            with ZipFile(wheel_path, "r") as whl:
                pth_content = whl.read("odoo_addon_test_module.pth").decode().strip()
                pth_path = Path(pth_content)
                assert pth_path == tmp_path / "build" / "__editable__", (
                    f"Editable .pth path incorrect: {pth_content}"
                )

    def test_editable_with_depends(self, tmp_path):
        """Test editable install with dependencies."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = ["base", "web"]
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert manifest == {
                "name": "Test Module",
                "version": "17.0.1.0.0",
                "depends": ["base", "web"],
            }

    def test_editable_with_data_files(self, tmp_path):
        """Test editable install with data files."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = ["base"]
                        data = ["data/views.xml"]
                    """),
                    "__init__.py": "",
                    "data/views.xml": '<?xml version="1.0"?><odoo/>',
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert manifest == {
                "name": "Test Module",
                "version": "17.0.1.0.0",
                "depends": ["base"],
                "data": ["data/views.xml"],
            }

    def test_editable_error_no_release(self, tmp_path):
        """Test that editable build fails without Odoo release."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            with pytest.raises(ValueError, match="Odoo release not specified"):
                build_editable(str(editable_dir), None)

    def test_editable_missing_data_file(self, tmp_path):
        """Test that editable build fails if data file is missing."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = ["base"]
                        data = ["data/missing.xml"]
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            with pytest.raises(FileNotFoundError, match="Data file not found"):
                build_editable(str(editable_dir), {"odoo_release": "17.0"})

    def test_editable_missing_data_file_no_artifacts(self, tmp_path):
        """Test that missing data file doesn't leave artifacts behind."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = ["base"]
                        data = ["data/missing.xml"]
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            with pytest.raises(FileNotFoundError):
                build_editable(str(editable_dir), {"odoo_release": "17.0"})

            pth_file = editable_dir / "test_module.pth"
            assert not pth_file.exists()

    def test_editable_src_layout_with_data_files(self, tmp_path):
        """Test editable install with src layout and data files."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "18.0"
                        src = "src"

                        [[tool.polytropos.manifest]]
                        depends = ["base"]
                        data = ["data/views.xml"]
                    """),
                    "src/__init__.py": "",
                    "src/data/views.xml": '<?xml version="1.0"?><odoo/>',
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "18.0"})

            assert result == "odoo_addon_test_module-18.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path / "src")
            assert manifest == {
                "name": "Test Module",
                "version": "18.0.1.0.0",
                "depends": ["base"],
                "data": ["data/views.xml"],
            }

    def test_editable_src_layout_missing_data_file(self, tmp_path):
        """Test that editable build fails if data file is missing in src layout."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "17.0"
                        src = "src"

                        [[tool.polytropos.manifest]]
                        depends = ["base"]
                        data = ["data/missing.xml"]
                    """),
                    "src/__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            with pytest.raises(FileNotFoundError, match="Data file not found"):
                build_editable(str(editable_dir), {"odoo_release": "17.0"})


class TestEditableReadmeDescription:
    """Tests for readme description in editable installs."""

    def test_readme_txt_description_in_manifest(self, tmp_path):
        """Test that plain text readme becomes description in manifest."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                        readme = "README.txt"

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                    "README.txt": "This is the README content used as description.",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert "description" in manifest
            assert (
                manifest["description"]
                == textwrap.dedent(
                    "This is the README content used as description."
                ).strip()
            )

    def test_readme_md_description_in_manifest(self, tmp_path):
        """Test that markdown readme is converted to RST and becomes description in manifest."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                        readme = "README.md"

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                    "README.md": "# Test Module\n\nThis is a test module.",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert "description" in manifest
            expected_desc = textwrap.dedent("""\
                Test Module
                ===========

                This is a test module.
            """).strip()
            assert manifest["description"] == expected_desc

    def test_readme_rst_editable_in_manifest(self, tmp_path):
        """Test that RST readme is added as description in manifest."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                        readme = "README.rst"

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                    "README.rst": "Test Module\n\nThis is a test module.",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert "description" in manifest
            expected_desc = textwrap.dedent("""\
                Test Module

                This is a test module.
            """).strip()
            assert manifest["description"] == expected_desc

    def test_readme_with_pandoc_include(self, tmp_path):
        """Test that pandoc-include directive is processed in editable."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                        readme = "README.md"

                        [tool.polytropos]
                        default_odoo_release = "17.0"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "__init__.py": "",
                    "README.md": textwrap.dedent("""\
                        # Test Module

                        !include included.md
                    """),
                    "included.md": "This is included content.",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path)
            assert "description" in manifest
            expected_desc = textwrap.dedent("""\
                Test Module
                ===========

                This is included content.
            """).strip()
            assert manifest["description"] == expected_desc

    def test_readme_in_src_layout_not_in_manifest(self, tmp_path):
        """Test that readme in src directory is not added to manifest description."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]
                        readme = "README.md"

                        [tool.polytropos]
                        default_odoo_release = "17.0"
                        src = "src"

                        [[tool.polytropos.manifest]]
                        depends = []
                    """),
                    "src/__init__.py": "",
                    "src/README.md": "# Test Module\n\nThis is the src README.",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            result = build_editable(str(editable_dir), {"odoo_release": "17.0"})

            assert result == "odoo_addon_test_module-17.0.1.0.0-py3-none-any.whl"

            manifest = extract_manifest_from_file(tmp_path / "src")
            assert "description" not in manifest


class TestEditableFileMaps:
    """Tests for file maps in editable mode."""

    def test_editable_file_map_creates_symlinks(self, tmp_path):
        """Test that file_map creates symlinks in editable mode."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "18.0"

                        [[tool.polytropos.manifest]]
                        depends = []

                        [[tool.polytropos.files]]
                        releases = ">=18"
                        src = "data/template/18.0"
                        dst = "data/template"
                    """),
                    "__init__.py": "",
                    "data/template/18.0/account.tax-es_common.csv": "taxes_18",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            build_editable(str(editable_dir), {"odoo_release": "18.0"})

            target = tmp_path / "data/template/account.tax-es_common.csv"
            assert target.is_symlink()
            assert target.read_text() == "taxes_18"
            target.unlink()

    def test_editable_file_map_skips_existing_real_file(self, tmp_path):
        """Test that file_map skips if destination is a real file."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "18.0"

                        [[tool.polytropos.manifest]]
                        depends = []

                        [[tool.polytropos.files]]
                        releases = ">=18"
                        src = "data/template/18.0"
                        dst = "data/template"
                    """),
                    "__init__.py": "",
                    "data/template/18.0/account.tax-es_common.csv": "taxes_18",
                    "data/template/account.tax-es_common.csv": "manual_taxes",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            build_editable(str(editable_dir), {"odoo_release": "18.0"})

            target = tmp_path / "data/template/account.tax-es_common.csv"
            assert not target.is_symlink()
            assert target.read_text() == "manual_taxes"

    def test_editable_file_map_src_layout(self, tmp_path):
        """Test that file_map works in src layout editable mode."""
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "18.0"
                        src = "src"

                        [[tool.polytropos.manifest]]
                        depends = []

                        [[tool.polytropos.files]]
                        releases = ">=18"
                        src = "data/template/18.0"
                        dst = "data/template"
                    """),
                    "src/__init__.py": "",
                    "src/data/template/18.0/account.tax-es_common.csv": "taxes_18",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            build_editable(str(editable_dir), {"odoo_release": "18.0"})

            target = tmp_path / "src/data/template/account.tax-es_common.csv"
            assert target.is_symlink()
            assert target.read_text() == "taxes_18"
            target.unlink()

    def test_editable_file_map_raises_on_source_not_found(self, tmp_path):
        with plumbum.local.cwd(tmp_path):
            build_file_tree(
                {
                    "pyproject.toml": textwrap.dedent("""\
                        [build-system]
                        requires = ["polytropos[build]"]
                        build-backend = "polytropos.build"

                        [project]
                        name = "odoo-addon-test-module"
                        version = "1.0.0"
                        requires-python = ">=3.11"
                        dynamic = ["version"]

                        [tool.polytropos]
                        default_odoo_release = "18.0"

                        [[tool.polytropos.manifest]]
                        depends = []

                        [[tool.polytropos.files]]
                        releases = ">=18"
                        src = "data/template/18.0"
                        dst = "data/template"
                    """),
                    "__init__.py": "",
                },
                base=tmp_path,
            )

            editable_dir = tmp_path / "editable"
            editable_dir.mkdir(exist_ok=True)

            with pytest.raises(FileNotFoundError, match="file_map source not found"):
                build_editable(str(editable_dir), {"odoo_release": "18.0"})
