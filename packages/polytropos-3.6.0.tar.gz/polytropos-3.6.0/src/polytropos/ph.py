"""Polytropos helpers for Odoo addons.

This library is meant to be used by Odoo addons at runtime.
"""

import logging
import os

from packaging.specifiers import SpecifierSet
from packaging.version import Version

logger = logging.getLogger("polytropos")
if _logger_level := os.getenv("POLYTROPOS_LOGGING"):
    logger.setLevel(_logger_level)

try:
    from odoo.release import series
except ImportError:
    series = None


def rel(spec: str) -> bool:
    """Check if current Odoo release matches a PEP 440 version specifier.

    This function checks the Odoo release (e.g., "17.0", "18.0") against
    a PEP 440 specifier, useful for conditional code execution.

    Args:
        spec: PEP 440 version specifier (e.g., ">=17.0", ">=18.0,<19.0")

    Raises:
        TypeError: If series is None (Odoo not installed)

    Returns:
        True if current Odoo release matches the spec, False otherwise.
    """
    current = Version(series)
    return current in SpecifierSet(spec)
