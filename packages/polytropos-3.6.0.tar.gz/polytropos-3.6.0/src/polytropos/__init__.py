"""Polytropos - A build backend for multi-version Odoo modules."""
