# Start Postgres
export PGDATA=$TMPDIR/postgres
export PGHOST=$TMPDIR/postgres
export PGDATABASE=test
mkdir -p $PGDATA
initdb -D $PGDATA
pg_ctl -D $PGDATA -o "-k $PGDATA" start

set -x
# Install addon with tests
test -n "$addonName"
odoo -d $PGDATABASE -D $TMPDIR --stop-after-init --workers 0 --init "$addonName" --test-enable --test-tags "/$addonName"

# Assert the addon was really installed
installed=$(psql -tAc "SELECT COUNT(*) FROM ir_module_module WHERE name = '$addonName' AND state = 'installed'")

set +x
if [ "$installed" != "1" ]; then
    echo "ERROR: $addonName was not installed during test"
    exit 1
fi

# Stop Postgres
pg_ctl -D $PGDATA stop

# Success
touch $out
