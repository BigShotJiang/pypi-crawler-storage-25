{
  flake,
  inputs,
  lib ? inputs.nixpkgs.lib,
  ...
}: let
  pep440 = inputs.pyproject-nix.lib.pep440;
  pep508 = inputs.pyproject-nix.lib.pep508;
in rec {
  ADDON_PREFIX = "odoo-addon-";

  /**
  Convert a Python package name to an Odoo addon name.

  # Type
  ```
  addonName :: String -> String
  ```

  # Arguments
  - `pkgName` — Package name (e.g., "odoo-addon-example-module")

  # Returns
  - Addon name (e.g., "example_module")

  # Example
  ```nix
  addonName "odoo-addon-my-module"
  => "my_module"
  ```

  # Notes
  - Mirrors Python's polytropos.build.manifest.addon_name function
  */
  addonName = pkgName: let
    hasPrefix = lib.hasPrefix ADDON_PREFIX pkgName;
  in
    if hasPrefix
    then lib.strings.replaceStrings ["-"] ["_"] (lib.removePrefix ADDON_PREFIX pkgName)
    else builtins.throw "Invalid package name: '${pkgName}'. Package name must start with 'odoo-addon-'";

  /**
  Get the addon package name from an addon path.

  # Type
  ```
  addonPkgName :: Path -> String
  ```

  # Arguments
  - `addonPath` — Path to the addon directory

  # Returns
  Package name (e.g., "odoo-addon-example-module").
  */
  addonPkgName = addonPath: let
    project = loadPyproject addonPath;
  in
    project.pyproject.project.name;

  /**
  Get all Odoo packages for a system.

  # Type
  ```
  odooPkgs :: System -> AttrSet
  ```

  # Arguments
  - `system` — System name (e.g., "x86_64-linux")

  # Returns
  - Attribute set of Odoo packages, keyed by package name

  # Notes
  - Uses flake.packages.${system}
  */
  providedOdooPkgs = system: lib.filterAttrs (n: v: lib.hasPrefix "odoo" n) flake.packages.${system};

  /**
  Get pyproject-nix spec for an addon.

  # Type
  ```
  loadPyproject :: Path -> AttrSet
  ```

  # Arguments
  - `addonPath` — Path to the addon directory

  # Returns
  - pyproject-nix spec for the addon

  # Notes
  - Uses pyproject-nix to load the addon's pyproject.toml
  */
  loadPyproject = addonPath: let
    projectRoot = inputs.nix-filter {
      root = addonPath;
    };
    project = inputs.pyproject-nix.lib.project.loadPyproject {
      inherit projectRoot;
    };
  in
    project;

  /**
  Select the best Odoo package for a project.

  # Type
  ```
  findBestOdooPkg :: AttrSet -> Path -> Derivation
  ```

  # Arguments
  - `odooPkgs` — Attribute set of Odoo packages, keyed by package name
  - `addonPath` — Path to the addon directory

  # Returns
  - The best matching Odoo package

  # Notes
  - Priority: default_odoo_release from pyproject > highest compatible version > latest available
  */
  findBestOdooPkg = odooPkgs: addonPath: let
    project = loadPyproject addonPath;
    odooDepSpec = getOdooDepSpec project;
    defaultRelease = getDefaultOdooRelease project;

    # Newest first
    sortedOdooPkgs = lib.sort (a: b: lib.versionAtLeast a.version b.version) (lib.attrValues odooPkgs);

    isCompatible = pkg:
      if odooDepSpec == null
      then true
      else odooVersionSatisfies pkg.version odooDepSpec;
    compatibleOdooPkgs = lib.filter isCompatible sortedOdooPkgs;
  in
    if defaultRelease != null
    then odooPkgs."odoo${lib.versions.major defaultRelease}"
      or (throw "odoo package for release ${defaultRelease} not found")
    else if builtins.length compatibleOdooPkgs > 0
    then builtins.head compatibleOdooPkgs
    else if builtins.length sortedOdooPkgs > 0
    then builtins.head sortedOdooPkgs
    else throw "No Odoo packages available";

  /**
  Build a release version string from an Odoo release string.

  # Type
  ```
  buildReleaseVersion :: String -> String
  ```

  # Arguments
  - `odooRelease` — Odoo release string (e.g., "17.0.20250506")

  # Returns
  - Release version string (e.g., "17.0")

  # Notes
  - Odoo release string is split into major and minor parts
  - Result is a string with major and minor parts joined by a dot
  */
  buildReleaseVersion = odooRelease: let
    parts = lib.splitString "." odooRelease;
    major = builtins.elemAt parts 0;
    minor = builtins.elemAt parts 1;
  in "${major}.${minor}";

  /**
  Build full version string from Odoo release and module version.

  # Type
  ```
  buildFullVersion :: String -> String -> String
  ```

  # Arguments
  - `odooRelease` — Odoo release (e.g., "19.0")
  - `moduleVersion` — Module version (e.g., "1.0.0")

  # Returns
  - Full version string (e.g., "19.0.1.0.0")

  # Example
  ```nix
  buildFullVersion "19.0" "1.0.0"
  => "19.0.1.0.0"
  buildFullVersion "17.0" "1.2.3"
  => "17.0.1.2.3"
  ```

  # Notes
  - Module version must have at least 3 components (X.Y.Z)
  - Result is always A.B.X.Y.Z (5 components)
  - Mirrors Python's polytropos.build.primitives.build_full_version function
  */
  buildFullVersion = odooRelease: moduleVersion: let
    releaseVersion = buildReleaseVersion odooRelease;
    moduleParts = lib.splitVersion moduleVersion;
    moduleMajor = lib.toInt (builtins.elemAt moduleParts 0);
    moduleMinor = lib.toInt (builtins.elemAt moduleParts 1);
    modulePatch = lib.toInt (builtins.elemAt moduleParts 2);
  in
    lib.concatStringsSep "." (map toString [
      releaseVersion
      moduleMajor
      moduleMinor
      modulePatch
    ]);

  /**
  Get the default Odoo release from a pyproject.toml project.

  # Type
  ```
  getDefaultOdooRelease :: AttrSet -> String | Null
  ```

  # Arguments
  - `project` — pyproject-nix project attribute set

  # Returns
  - The default Odoo release string (e.g., "17.0") or `null` if not specified

  # Notes
  - Reads from `[tool.polytropos].default_odoo_release`
  */
  getDefaultOdooRelease = project: lib.attrByPath ["tool" "polytropos" "default_odoo_release"] null project.pyproject;

  /**
  Map a function over Odoo packages and prefix result keys with the package name.

  # Type
  ```
  mapByOdooAttrs :: {perSystem, self ? perSystem.self} -> (OdooPackage -> AttrSet) -> AttrSet
  ```

  # Arguments
  - `perSystem` — Attribute set containing Odoo packages
  - `self` — Optional: Odoo packages attribute set (defaults to perSystem.self)
  - `fn` — Function to apply to each Odoo package, returning an attribute set

  # Example
  ```nix
  mapByOdooAttrs
    {perSystem.self = flake.packages.x86_64-linux;}
    (odoo: {version = lib.versions.major odoo.version;})
  => {
    odoo17-version = "17";
    odoo18-version = "18";
  }
  ```

  # Returns
  - Attribute set with keys prefixed by package name (e.g., `odoo17-version`)

  # Notes
  - Only packages with names starting with "odoo" are included
  */
  mapByOdooAttrs = {
    perSystem,
    self ? perSystem.self,
  }: fn: let
    odooPkgs = lib.filterAttrs (n: v: lib.hasPrefix "odoo" n) self;
  in
    lib.concatMapAttrs (
      name: pkg: let
        result = fn pkg;
      in
        lib.mapAttrs' (key: lib.nameValuePair "${name}-${key}") result
    )
    odooPkgs;

  /**
  Check if an Odoo version satisfies a dependency specification.

  # Type
  ```
  odooVersionSatisfies :: String -> (String | [AttrSet]) -> Bool
  ```

  # Arguments
  - `odooVersion` — Odoo version string (e.g., "17.0" or "17.0.20250506")
  - `depSpec` — Either a PEP 440 spec string (e.g., ">=17.0") or parsed conditions

  # Returns
  - `true` if the version satisfies the specification

  # Example
  ```nix
  odooVersionSatisfies "17.0" ">=17.0"
  => true
  odooVersionSatisfies "17.0.20250506" ">=17.0"
  => true
  odooVersionSatisfies "16.0" ">=17.0"
  => false
  ```
  */
  odooVersionSatisfies = odooVersion: depSpec: let
    conds =
      if builtins.isList depSpec
      then depSpec
      else pep440.parseVersionConds depSpec;
    parsedOdooVersion = pep440.parseVersion odooVersion;
    satisfiesCond = cond: pep440.comparators.${cond.op} parsedOdooVersion cond.version;
  in
    builtins.all satisfiesCond conds;

  /**
  Check if a package (optionally with specific extras) is in a list of requirement strings.

  # Type
  ```
  hasDependency :: [String] -> String -> (String | Null) -> Bool
  ```

  # Arguments
  - `requirements` — List of PEP 508 requirement strings
  - `packageName` — Package name to check for (e.g., "polytropos")
  - `extra` — Optional extra to require (e.g., "build"), or `null` to match any

  # Returns
  - `true` if the package (with specified extra if provided) is in the requirements

  # Example
  ```nix
  hasDependency ["polytropos[build]"] "polytropos" "build"
  => true
  hasDependency ["polytropos[build]"] "polytropos" null
  => true
  hasDependency ["polytropos"] "polytropos" "build"
  => false
  hasDependency ["polytropos[test,build]"] "polytropos" "build"
  => true
  ```

  # Notes
  - Uses PEP 508 parsing to correctly identify package names
  - When `extra` is `null`, matches the package regardless of extras
  - When `extra` is provided, requires that exact extra to be present
  */
  hasDependency = requirements: packageName: extra:
    builtins.any (req: let
      parsed = pep508.parseString req;
      nameMatches = parsed.name == packageName;
      extras = parsed.extras or [];
      extraMatches = extra == null || builtins.elem extra extras;
    in
      nameMatches && extraMatches)
    requirements;

  /**
  Extract Odoo dependency specification from a pyproject.toml project.

  # Type
  ```
  getOdooDepSpec :: AttrSet -> [AttrSet] | Null
  ```

  # Arguments
  - `project` — pyproject-nix project attribute set

  # Returns
  - List of PEP 440 version conditions or `null` if odoo dependency not found

  # Example
  ```nix
  getOdooDepSpec project
  => [{ op = ">="; version = { ... }; }]
  ```

  # Notes
  - Uses PEP 508 parsing to correctly identify the "odoo" package
  - Returns parsed conditions ready for use with pep440.comparators
  */
  getOdooDepSpec = project: let
    dependencies = project.pyproject.project.dependencies or [];
    odooDeps = builtins.filter (dep: (pep508.parseString dep).name == "odoo") dependencies;
    allConditions = builtins.concatMap (dep: (pep508.parseString dep).conditions or []) odooDeps;
  in
    if builtins.length allConditions > 0
    then allConditions
    else null;

  /**
  Create a test derivation for an Odoo addon.

  # Type
  ```
  mkAddonTest :: Path -> String -> Derivation -> Derivation
  ```

  # Arguments
  - `addonPath` — Path to the addon directory
  - `odooName` — Name of the Odoo package (e.g., "odoo18")
  - `odooPkg` — Odoo package derivation

  # Returns
  - A derivation that runs Odoo tests for the addon

  # Notes
  - Uses polytropos from the flake's default package
  - Creates a Python environment with the addon installed
  - Runs Odoo with the addon and its tests
  */
  mkAddonTest = addonPath: odooName: odooPkg: let
    pkgName = addonPkgName addonPath;
    python = odooPkg.pythonModule.override {
      self = python;
      packageOverrides = lib.composeManyExtensions [
        (pyfinal: pyprev: {odoo = odooPkg;})
        (mkAddonPyOverride addonPath)
      ];
    };
    venv = python.withPackages (ps: [ps."${pkgName}"]);
    pkgs = inputs.nixpkgs.legacyPackages.${odooPkg.system};
  in
    pkgs.runCommandLocal "${pkgName}-${odooName}" {
      addonName = addonName pkgName;
      nativeBuildInputs = [venv pkgs.postgresql];
      passthru = {
        inherit python venv;
      };
    } (builtins.readFile ./addonTest.sh);

  /**
  Create test derivations for an Odoo addon across all compatible Odoo versions.

  # Type
  ```
  mkAddonTests :: String -> Path -> AttrSet
  ```

  # Arguments
  - `system` — System name (e.g., "x86_64-linux")
  - `addonPath` — Path to the addon directory

  # Returns
  - Attribute set of test derivations, one per compatible Odoo version

  # Notes
  - Loads the addon's pyproject.toml using pyproject-nix
  - Asserts the addon is built with polytropos
  - Filters Odoo packages by compatibility with the addon's odoo dependency
  - Uses PEP 440 version comparison
  */
  mkAddonTests = system: addonPath: let
    project = loadPyproject addonPath;
    odooDepSpec = getOdooDepSpec project;
    isPolytropos = hasDependency project.pyproject.build-system.requires "polytropos" "build";
    isCompatibleOdoo = name: pkg:
      if odooDepSpec == null
      then true
      else odooVersionSatisfies pkg.version odooDepSpec;
    compatibleOdooPkgs = lib.filterAttrs isCompatibleOdoo (providedOdooPkgs system);
  in
    assert lib.assertMsg isPolytropos "mkAddon requires polytropos[build] in build-system.requires";
      lib.mapAttrs (mkAddonTest addonPath) compatibleOdooPkgs;

  /**
  Build a polytropos-based Odoo addon package with tests.

  # Type
  ```
  mkAddon :: {addonPath, pkgs ...} @ args -> Derivation
  ```

  # Arguments
  - `addonPath` — Path to the addon directory
  - `pkgs` — Nixpkgs

  # Returns
  A derivation for the addon package built for the selected odoo release.

  If you want to build it for a specific Odoo version, override the `odoo`
  package in the python packages set.

  The python interpreter attached to the derivation is the same as the one for the
  Odoo package. Its package set is extended to include:
  - The selected Odoo package.
  - The addon package.
  - Polytropos package.
  */
  mkAddon = {
    addonPath,
    pkgs,
  }: let
    pkgName = addonPkgName addonPath;
    addonOverlay = mkAddonPyOverride addonPath;
    bestOdoo = findBestOdooPkg (providedOdooPkgs pkgs.stdenv.hostPlatform.system) addonPath;
    basePython = bestOdoo.pythonModule;
    python = basePython.override {
      self = python;
      packageOverrides = addonOverlay;
    };
  in
    python.pkgs.${pkgName};

  /**
  Create an overlay for an addon.

  # Type
  ```
  mkAddonOverlay :: Path -> [derivation|null] -> Overlay
  ```

  # Arguments
  - `addonPath` — Path to the addon directory
  - `final` — Final Python derivation
  - `prev` — Previous Python derivation

  # Returns
  - Python overlay with Polytropos and the addon

  # Notes
  - Overlay is a function that takes the final and previous overlays
  - Overlay adds the addon to the final overlay
  */
  mkAddonPyOverride = addonPath: pyfinal: pyprev: let
    system = pyprev.stdenv.hostPlatform.system;
    pkgName = addonPkgName addonPath;
    bestOdoo = findBestOdooPkg (providedOdooPkgs system) addonPath;
    chosenOdoo = pyprev.odoo or bestOdoo;
    odoo = chosenOdoo.override {inherit (pyfinal) python;};
    project = loadPyproject addonPath;
    self = flake.packages.${system};
    moduleVersion = project.pyproject.project.version;
    buildArgs = project.renderers.buildPythonPackage {inherit (pyprev) python;};
    addonDrv = pyprev.buildPythonPackage (lib.recursiveUpdate buildArgs {
      version = buildFullVersion odoo.version moduleVersion;
      passthru.tests = mkAddonTests system addonPath;
      pythonImportsCheck = [
        "odoo.addons.${addonName pkgName}"
      ];
    });
  in {
    inherit odoo;
    polytropos = self.default.override {inherit (pyprev) python;};
    ${project.pyproject.project.name} = addonDrv;
  };

  /**
  Build multiple polytropos-based Odoo addons from a folder.

  # Type
  ```
  mkAddons :: AttrSet -> Path -> AttrSet
  ```

  # Arguments
  - `pkgs` — Nixpkgs
  - `addonsPath` — Path to the folder containing addon subdirectories

  # Returns
  - Attribute set of addon derivations, keyed by addon name

  # Notes
  - Each subdirectory must be a polytropos-based addon
  - Uses `mkAddon` internally for each addon
  - Odoo package is selected based on project configuration
  */
  mkAddons = pkgs: addonsPath: let
    addonDirs = lib.filterAttrs (name: type: type == "directory") (builtins.readDir addonsPath);
  in
    lib.mapAttrs (
      addonName: _v:
        mkAddon {
          inherit pkgs;
          addonPath = addonsPath + "/${addonName}";
        }
    )
    addonDirs;

  /**
  Build test derivations for all addons in a folder across all compatible Odoo versions.

  # Type
  ```
  mkAddonsTests :: AttrSet -> Path -> AttrSet
  ```

  # Arguments
  - `pkgs` — Nixpkgs
  - `addonsPath` — Path to the folder containing addon subdirectories

  # Returns
  - Attribute set of test derivations, keyed by `odooName-addonName`

  # Notes
  - Each subdirectory must be a polytropos-based addon
  - Uses `mkAddonTests` internally for each addon
  - Combines tests from all addons into a flat attribute set
  */
  mkAddonsTests = pkgs: addonsPath: let
    addonDirs = lib.filterAttrs (name: type: type == "directory") (builtins.readDir addonsPath);
    addonDrvs =
      lib.mapAttrs
      (name: _type:
        mkAddon {
          inherit pkgs;
          addonPath = addonsPath + "/${name}";
        })
      addonDirs;
    addonsTests =
      lib.foldlAttrs
      (
        acc: addonName: addonDrv:
          acc
          // lib.mapAttrs'
          (testName: lib.nameValuePair "${addonName}-${testName}")
          addonDrv.passthru.tests
      )
      {}
      addonDrvs;
  in
    addonsTests;

  tests = {
    testBuildFullVersion = {
      expr = {
        basic = buildFullVersion "19.0" "1.0.0";
        with_minor = buildFullVersion "17.0" "1.2.3";
        with_patch = buildFullVersion "18.0" "2.1.0";
        different_releases = {
          seventeen = buildFullVersion "17.0" "1.0.0";
          eighteen = buildFullVersion "18.0" "1.0.0";
          nineteen = buildFullVersion "19.0" "1.0.0";
        };
      };
      expected = {
        basic = "19.0.1.0.0";
        with_minor = "17.0.1.2.3";
        with_patch = "18.0.2.1.0";
        different_releases = {
          seventeen = "17.0.1.0.0";
          eighteen = "18.0.1.0.0";
          nineteen = "19.0.1.0.0";
        };
      };
    };

    testMapByOdooAttrs = {
      expr =
        mapByOdooAttrs
        {perSystem.self = flake.packages.x86_64-linux;}
        (odoo: {version = lib.versions.major odoo.version;});
      expected = {
        odoo17-version = "17";
        odoo18-version = "18";
        odoo19-version = "19";
      };
    };

    testOdooVersionSatisfies = {
      expr = {
        gte_17 = odooVersionSatisfies "17.0" ">=17.0";
        full_version = odooVersionSatisfies "17.0.20250506" ">=17.0";
        gte_18 = odooVersionSatisfies "18.0" ">=17.0";
        lt_17 = odooVersionSatisfies "16.0" ">=17.0";
        gte_18_only = odooVersionSatisfies "18.0" ">=18.0";
        lt_18 = odooVersionSatisfies "17.0" ">=18.0";
        combined_accept = odooVersionSatisfies "18.0" ">=18.0,<19.0";
        combined_reject_high = odooVersionSatisfies "19.0" ">=18.0,<19.0";
        combined_reject_low = odooVersionSatisfies "17.0" ">=18.0,<19.0";
      };
      expected = {
        gte_17 = true;
        full_version = true;
        gte_18 = true;
        lt_17 = false;
        gte_18_only = true;
        lt_18 = false;
        combined_accept = true;
        combined_reject_high = false;
        combined_reject_low = false;
      };
    };

    testHasDependency = {
      expr = {
        with_build_extra = hasDependency ["polytropos[build]"] "polytropos" "build";
        with_version_and_build = hasDependency ["polytropos[build]>=1.0.0"] "polytropos" "build";
        with_multiple_extras = hasDependency ["polytropos[test,build]"] "polytropos" "build";
        without_required_extra = hasDependency ["polytropos"] "polytropos" "build";
        with_wrong_extra = hasDependency ["polytropos[test]"] "polytropos" "build";
        any_extra = hasDependency ["polytropos[build]"] "polytropos" null;
        no_extras_any = hasDependency ["polytropos"] "polytropos" null;
        not_present = hasDependency ["odoo>=17.0"] "polytropos" null;
        false_positive_prefix = hasDependency ["polytropos-extra"] "polytropos" null;
        odoo_dep = hasDependency ["odoo>=17.0"] "odoo" null;
        odoo_not_confused_with_addon = hasDependency ["odoo-addon-foo>=1.0"] "odoo" null;
      };
      expected = {
        with_build_extra = true;
        with_version_and_build = true;
        with_multiple_extras = true;
        without_required_extra = false;
        with_wrong_extra = false;
        any_extra = true;
        no_extras_any = true;
        not_present = false;
        false_positive_prefix = false;
        odoo_dep = true;
        odoo_not_confused_with_addon = false;
      };
    };

    testGetOdooDepSpec = {
      expr = {
        with_version = getOdooDepSpec {pyproject.project.dependencies = ["odoo>=17.0"];};
        with_range = getOdooDepSpec {pyproject.project.dependencies = ["odoo>=17.0,<18.0"];};
        with_split_range = getOdooDepSpec {pyproject.project.dependencies = ["odoo>=18.0" "odoo<19.0"];};
        without_odoo = getOdooDepSpec {pyproject.project.dependencies = ["polytropos[build]" "requests>=2.0"];};
        empty = getOdooDepSpec {pyproject.project.dependencies = [];};
      };
      expected = {
        with_version = [
          {
            op = ">=";
            version = pep440.parseVersion "17.0";
          }
        ];
        with_range = [
          {
            op = ">=";
            version = pep440.parseVersion "17.0";
          }
          {
            op = "<";
            version = pep440.parseVersion "18.0";
          }
        ];
        with_split_range = [
          {
            op = ">=";
            version = pep440.parseVersion "18.0";
          }
          {
            op = "<";
            version = pep440.parseVersion "19.0";
          }
        ];
        without_odoo = null;
        empty = null;
      };
    };

    testOdooVersionSatisfiesSplitDeps = {
      expr = {
        compatible = odooVersionSatisfies "18.0" [
          {
            op = ">=";
            version = pep440.parseVersion "18.0";
          }
          {
            op = "<";
            version = pep440.parseVersion "19.0";
          }
        ];
        too_high = odooVersionSatisfies "19.0" [
          {
            op = ">=";
            version = pep440.parseVersion "18.0";
          }
          {
            op = "<";
            version = pep440.parseVersion "19.0";
          }
        ];
        too_low = odooVersionSatisfies "17.0" [
          {
            op = ">=";
            version = pep440.parseVersion "18.0";
          }
          {
            op = "<";
            version = pep440.parseVersion "19.0";
          }
        ];
      };
      expected = {
        compatible = true;
        too_high = false;
        too_low = false;
      };
    };

    testGetOdooDepSpecEndToEnd = let
      splitProject = {pyproject.project.dependencies = ["odoo>=18.0" "odoo<19.0"];};
      combinedProject = {pyproject.project.dependencies = ["odoo>=18.0,<19.0"];};
      splitSpec = getOdooDepSpec splitProject;
      combinedSpec = getOdooDepSpec combinedProject;
    in {
      expr = {
        split_accept_18 = odooVersionSatisfies "18.0" splitSpec;
        split_reject_19 = odooVersionSatisfies "19.0" splitSpec;
        split_reject_17 = odooVersionSatisfies "17.0" splitSpec;
        combined_accept_18 = odooVersionSatisfies "18.0" combinedSpec;
        combined_reject_19 = odooVersionSatisfies "19.0" combinedSpec;
        combined_reject_17 = odooVersionSatisfies "17.0" combinedSpec;
      };
      expected = {
        split_accept_18 = true;
        split_reject_19 = false;
        split_reject_17 = false;
        combined_accept_18 = true;
        combined_reject_19 = false;
        combined_reject_17 = false;
      };
    };

    testGetDefaultOdooRelease = {
      expr = {
        with_release = getDefaultOdooRelease {pyproject.tool.polytropos.default_odoo_release = "18.0";};
        without_release = getDefaultOdooRelease {pyproject.tool.polytropos = {};};
        without_tool = getDefaultOdooRelease {pyproject = {};};
      };
      expected = {
        with_release = "18.0";
        without_release = null;
        without_tool = null;
      };
    };

    testAddonName = {
      expr = {
        simple = addonName "odoo-addon-my-module";
        with_dashes = addonName "odoo-addon-example-module-name";
        single_word = addonName "odoo-addon-base";
      };
      expected = {
        simple = "my_module";
        with_dashes = "example_module_name";
        single_word = "base";
      };
    };

    testBuildReleaseVersion = {
      expr = {
        basic = buildReleaseVersion "17.0";
        with_date = buildReleaseVersion "18.0.20250506";
        nineteen = buildReleaseVersion "19.0";
        sixteen = buildReleaseVersion "16.0";
      };
      expected = {
        basic = "17.0";
        with_date = "18.0";
        nineteen = "19.0";
        sixteen = "16.0";
      };
    };

    testProvidedOdooPkgs = {
      expr = let
        pkgs = providedOdooPkgs "x86_64-linux";
      in {
        has_odoo17 = pkgs ? odoo17;
        has_odoo18 = pkgs ? odoo18;
        has_odoo19 = pkgs ? odoo19;
        has_non_odoo = pkgs ? polytropos;
      };
      expected = {
        has_odoo17 = true;
        has_odoo18 = true;
        has_odoo19 = true;
        has_non_odoo = false;
      };
    };
  };
}
