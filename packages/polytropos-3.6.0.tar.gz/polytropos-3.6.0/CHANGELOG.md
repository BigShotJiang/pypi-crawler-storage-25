## v3.6.0 (2026-05-04)

### Feat

-   **files**: allow mapping sources to paths on build

## v3.5.0 (2026-04-24)

### Feat

-   **manifest**: add maintainers auto-population from project.maintainers

## v3.4.0 (2026-04-22)

### Feat

-   support Python 3.10 and Odoo 15-16

## v3.3.0 (2026-04-15)

### Feat

-   unified logging

### Fix

-   detect installed odoo series appropriately in Odoo 19

## v3.2.2 (2026-04-14)

### Fix

-   **nix**: build modules for the same python version as Odoo

## v3.2.1 (2026-04-13)

### Fix

-   **nix**: build addons without specific default odoo version
-   **nix**: allow building with insecure pypdf2

### Refactor

-   **nix**: share as most code as possible and change the way lib builds packages

## v3.2.0 (2026-04-01)

### Feat

-   **build**: rewrite image paths in manifest descriptions for Odoo UI
-   convert README.md into `description` inside `__manifest__.py` in RST format

## v3.1.0 (2026-03-30)

### Feat

-   **build**: validate readme is included in wheel METADATA
-   warn when version is not declared as dynamic
-   support `./src` subfolder layout
-   **docs**: easy way to run docs in any past version (from this one)
-   **nix**: add odoo19 package
-   **nix**: add devshell module

### Fix

-   **pep517**: make editable builds produce valid .pth file
-   **pep517**: use src directory as base for data file validation in editable builds
-   combine split odoo version specifiers during compatibility check
-   **nix**: addon packages get proper version number
-   **nix**: infer addon name correctly from package name
-   **nix**: make sure we can build one addon

### Refactor

-   **nix**: lib with helpers to package addons

## v3.0.2 (2026-03-25)

### Fix

-   process .gitignore appropriately

## v3.0.1 (2026-03-25)

### Refactor

-   remove warning for a perfectly valid use case
-   remove duplicate methods

## v3.0.0 (2026-03-24)

### BREAKING CHANGE

-   Import paths changed:
    -   polytropos.manifest -> polytropos.build.manifest
    -   polytropos.version -> polytropos.build.primitives
    -   polytropos.cond -> merged into polytropos.build.primitives
-   `[tool.polytropos.manifest]` must now be specified as `[[tool.polytropos.manifest]]`
    (list of tables). Existing single-table configurations will fail with a clear error
    message.
-   Automatic dependency population may change manifest contents for existing projects
-   Odoo version constraints in `[project].dependencies` now prevent building for
    incompatible releases
-   you need to set `build-system.requires = ["polytropos[build]"]` now in your addons
-   cannot build sdist and wheel with a single `uv build` call
-   addon version must have at least 3 parts
-   sdist builds contain no `__manifest__.py`
-   sdist builds without release in their version number, because they are no longer
    tied to a specific Odoo version

### Feat

-   automatic dependency population and Odoo version validation
-   helpers module

### Fix

-   **manifest**: never include odoo as a dependency
-   sdists are release-agnostic

### Refactor

-   consolidate build-time code into build/ package
-   **manifest**: reduce AI nonsense
-   simplify manifest config handling
-   **build**: only backend functions are public now
-   make build backend dependencies optional
-   use whool for wheel builds

## v2.0.4 (2026-03-19)

### Fix

-   **docs**: favicon

## v2.0.3 (2026-03-19)

### Fix

-   wrong wheel auto-deployment

## v2.0.2 (2026-03-19)

### Fix

-   use only uv version provider

## v2.0.1 (2026-03-19)

### Fix

-   dumb commit to test automatic wheel publishing

## v2.0.0 (2026-03-19)

## v1.0.0 (2026-03-19)

## v1.0.0 (2026-03-19)

-   claim pypi namespace

## v0.1.1 (2026-03-19)

### Fix

-   correct pypi user name

## v0.1.0 (2026-03-19)

### Feat

-   it's alive!
