# Test that a module can be built with lib helpers
{
  addonPath ? flake + "/examples/odoo-addon-src-layout",
  flake,
  pkgs,
  ...
}:
flake.lib.mkAddon {
  inherit addonPath pkgs;
}
