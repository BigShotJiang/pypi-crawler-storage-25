# Test that a module can be built with lib helpers
{
  addonPath ? flake + "/examples/conditional_data",
  flake,
  pkgs,
  ...
}:
flake.lib.mkAddon {
  inherit addonPath pkgs;
}
