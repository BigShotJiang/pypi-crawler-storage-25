# Polytropos

![Polytropos logo](https://gitlab.com/moduon/polytropos/-/raw/main/docs/img/logo.svg?ref_type=heads)

Polytropos is a Python build backend for Odoo modules that enables writing code once and
using it across multiple Odoo releases.

## Features

-   **Multi-release support**: Write your module once, target multiple Odoo releases
-   **Conditional manifests**: Configure different manifest values per Odoo release, to
    let you include or exclude data files per release
-   **Editable installs**: Develop in editable is supported
-   **PEP 517 compliant**: Works with any PEP 517 compatible frontend

## Quick Example

Replace your module's `__manifest__.py` with this `pyproject.toml` file:

```toml title="pyproject.toml"
[build-system]
requires = ["polytropos[build]"]
build-backend = "polytropos.build"

[project]
name = "odoo-addon-my-module"
version = "1.0.0"
dependencies = [
    # Specify supported Odoo versions here
    "odoo>=17"
]

# All versions have this data
[[tool.polytropos.manifest]]
depends = ["base"]
data = ["data/views.xml"]

# This section is only for Odoo 18+
[[tool.polytropos.manifest]]
releases = ">=18"
data = ["security/ir.model.access.csv"]
```

Then, inside the module folder:

```shell
# Don't forget the module must be a Python package
touch __init__.py

# Build wheels for different odoo releases
uv build --sdist
uv build --wheel --config-setting odoo_release=17.0
uv build --wheel --config-setting odoo_release=18.0
uv build --wheel --config-setting odoo_release=19.0

# List artifacts
ls -1 dist/
my_module-1.0.0.tar.gz
odoo_addon_my_module-17.0.1.0.0-py3-none-any.whl
odoo_addon_my_module-18.0.1.0.0-py3-none-any.whl
odoo_addon_my_module-19.0.1.0.0-py3-none-any.whl
```

Single branch, single code, multiple releases! 🤯

## Installation

Python will auto-install the build backend when you build a module.

But yes, you can install a small CLI with:

```bash
pip install polytropos[cli]
```

For development, the recommended tool you need is
[uv](https://docs.astral.sh/uv/#installation). Then:

```shell
uvx polytropos[cli] --help-all
```

## Why Polytropos?

Odoo modules traditionally require separate codebases or branches for each release.
Polytropos solves this by generating release-specific code at build time, allowing you
to maintain a single codebase.

So, it will help you or not depending on _your product vision_:

| What is your product?                           | What does that mean?                                                                                                                                     | Is Polytropos for you? |
| ----------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- |
| Odoo + its release + all addons in that release | Customers that want new features must upgrade to newer Odoo releases.                                                                                    | ⛔ No                  |
| Addons that should work always the same way     | Customers need new features and cannot wait for the upgrade to the next Odoo release; but when they upgrade, they expect the same features they have now | ✅ Yes                 |

## Examples

Check out the
[examples folder](https://gitlab.com/moduon/polytropos/-/tree/main/examples) for
real-world modules with views, models, and tests that exercise the conditional logic.

## Credits

[![Moduon logo](https://www.moduon.team/web/image/743407-d585653d/logo_moduon_menu_136x40.svg)](https://www.moduon.team/)

Polytropos is developed and maintained by **Moduon**. Need a professional Odoo partner?
[**Contact us**](https://www.moduon.team/odoo-sin-ansiedad).
