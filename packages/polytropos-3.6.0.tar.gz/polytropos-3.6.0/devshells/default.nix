{
  inputs,
  perSystem,
  ...
}:
perSystem.devshell.mkShell ({
  extraModulesPath,
  lib,
  pkgs,
  ...
}: {
  imports = [
    (extraModulesPath + "/services/postgres.nix")
    inputs.precommix.modules.devshell.default
  ];
  commands = [
    {package = pkgs.python3;}
    {package = lib.lowPrio pkgs.python310;}
    {package = pkgs.uv;}
    {package = pkgs.nixdoc;}
    {package = pkgs.pandoc;}
    {package = pkgs.pandoc-include;}
  ];

  devshell.startup.venv.text = ''
    uv sync --frozen || true
    source .venv/bin/activate
  '';

  env = [
    {
      name = "UV_SYSTEM_PYTHON";
      value = true;
    }
  ];
})
