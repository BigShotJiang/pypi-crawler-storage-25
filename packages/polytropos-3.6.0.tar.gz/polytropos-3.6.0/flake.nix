{
  nixConfig = {
    # HACK https://github.com/NixOS/nix/issues/6771
    # TODO Leave only own cache settings when fixed
    extra-trusted-public-keys = [
      "cache.nixos-cuda.org:74DUi4Ye579gUqzH4ziL9IyiJBlDpMRn9MBN8oNan9M="
      "devenv.cachix.org-1:w1cLUi8dv3hnoSPGAuibQv+f9TZLr6cv/Hm9XgU50cw="
      "flox-cache-public-1:7F4OyH7ZCnFhcze3fJdfyXYLQw/aV7GEed86nQ7IsOs="
      "moduon.cachix.org-1:sXMrTN5LuhZyh6CnzYXM4pZkah/Yy//eGKt1oOZc0zw="
      "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
      "numtide.cachix.org-1:2ps1kLBUWjxIneOy1Ik6cQjb41X0iXVXeHigGmycPPE="
    ];
    extra-substituters = [
      "https://cache.flox.dev"
      "https://cache.nixos-cuda.org"
      "https://devenv.cachix.org"
      "https://moduon.cachix.org"
      "https://nix-community.cachix.org"
      "https://numtide.cachix.org"
    ];
  };

  inputs = {
    # HACK https://github.com/numtide/blueprint/issues/147
    blueprint.inputs.nixpkgs.follows = "nixpkgs";
    blueprint.inputs.systems.follows = "systems";
    blueprint.url = "github:numtide/blueprint";
    dream2nix.inputs.nixpkgs.follows = "nixpkgs";
    dream2nix.inputs.pyproject-nix.follows = "pyproject-nix";
    dream2nix.url = "github:nix-community/dream2nix";
    maintainer-tools.flake = false;
    maintainer-tools.url = "github:OCA/maintainer-tools";
    nix-filter.url = "github:numtide/nix-filter";
    nixpkgs.url = "https://flakehub.com/f/NixOS/nixpkgs/*";
    nixpkgs-unstable.url = "https://flakehub.com/f/NixOS/nixpkgs/0.1";
    precommix.inputs.blueprint.follows = "blueprint";
    precommix.inputs.dream2nix.follows = "dream2nix";
    precommix.inputs.maintainer-tools.follows = "maintainer-tools";
    precommix.inputs.nixpkgs.follows = "nixpkgs";
    precommix.inputs.precommix.follows = "precommix";
    precommix.inputs.pyproject-nix.follows = "pyproject-nix";
    pyproject-nix.inputs.nixpkgs.follows = "nixpkgs";
    pyproject-nix.url = "github:pyproject-nix/pyproject.nix";
    systems.url = "github:nix-systems/default";

    # HACK https://github.com/NixOS/nix/issues/4945
    # Leave this input always last, so Copier can update it easily
    precommix.url = "gitlab:moduon/precommix/v0.28.0-19-g19f8f42";
  };

  outputs = _inputs: let
    inputs = _inputs.precommix.inputs // _inputs;
  in
    inputs.blueprint {
      inherit inputs;
      nixpkgs = import ./modules/nixos/nixpkgs/nixpkgs.nix {inherit inputs;};
    };
}
