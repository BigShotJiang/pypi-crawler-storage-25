"""ARAHIN CLI — entry point, REPL, 7 commands, and route pipeline."""

from __future__ import annotations

import argparse
import os
import sys
import webbrowser
from typing import Any

from rich.console import Console
from rich.prompt import Prompt
from rich.table import Table

from . import __version__
from .banner import show_splash
from .state import get_state, reset_route_state, SessionState

# Rich console
console = Console()

# Available OpenCode Go models
AVAILABLE_MODELS = [
    "deepseek-v4-flash",
    "deepseek-v4-pro",
    "glm-5",
    "glm-5.1",
    "kimi-k2.5",
    "kimi-k2.6",
    "mimo-v2.5",
    "mimo-v2.5-pro",
    "minimax-m2.5",
    "minimax-m2.7",
    "qwen3.5-plus",
    "qwen3.6-plus",
]

API_BASE = "https://opencode.ai/zen/go/v1"


# ── Command handlers ───────────────────────────────────────────────────────

API_KEY_FILE = os.path.expanduser("~/.arahin/api_key")


def _load_api_key() -> str:
    """Read persisted API key from disk. Returns '' if not found."""
    try:
        with open(API_KEY_FILE) as f:
            return f.read().strip()
    except Exception:
        return ""


def _save_api_key(key: str) -> None:
    """Persist API key to disk."""
    os.makedirs(os.path.dirname(API_KEY_FILE), exist_ok=True)
    with open(API_KEY_FILE, "w") as f:
        f.write(key)


def _delete_api_key() -> None:
    """Delete persisted API key."""
    try:
        os.remove(API_KEY_FILE)
    except Exception:
        pass


def _cmd_api(args: str, state: SessionState) -> None:
    """Set API key. No arg: show status. 'delete'/'clear': remove."""
    cmd = args.strip().lower()
    if cmd in ("delete", "clear", "remove"):
        state.api_key = ""
        _delete_api_key()
        console.print("[green][OK][/green] API key deleted.")
        return
    if not cmd:
        console.print(f"API key: {state.api_status}")
        return
    state.api_key = args.strip()
    _save_api_key(state.api_key)
    console.print(f"[green]✓[/green] API key set ({state.api_status})")


def _cmd_model(args: str, state: SessionState) -> None:
    """Switch LLM model. No arg: show current + available."""
    if not args.strip():
        console.print(f"Current model: [bold cyan]{state.model}[/bold cyan]")
        console.print(f"Available: {', '.join(AVAILABLE_MODELS)}")
        console.print("Set with: [bold]/model <name>[/bold]")
        return
    name = args.strip()
    if name not in AVAILABLE_MODELS:
        console.print(
            f"[yellow]Unknown model '{name}'.[/yellow] "
            f"Available: {', '.join(AVAILABLE_MODELS)}"
        )
        return
    state.model = name
    console.print(f"[green]✓[/green] Model set to [bold]{name}[/bold]")


def _cmd_map(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Open last generated map in browser."""
    if not state.last_map_path:
        console.print("[yellow]No map generated yet. Run a route query first.[/yellow]")
        return
    console.print(f"[MAP] Opening [bold]{state.last_map_path}[/bold]")
    webbrowser.open(f"file://{state.last_map_path}")


def _cmd_dir(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Show turn-by-turn directions from last route."""
    if not state.last_route_details:
        console.print(
            "[yellow]No route data available. Run a query first.[/yellow]"
        )
        return

    from .tools.render_map import render_turn_by_turn

    text = render_turn_by_turn(state.last_route_details)
    if not text.strip():
        console.print("[yellow]No turn-by-turn instructions available.[/yellow]")
        return

    console.print(text)


def _cmd_config(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Show all current settings."""
    table = Table(title="ARAHIN Settings", border_style="cyan")
    table.add_column("Setting", style="bold")
    table.add_column("Value")
    table.add_row("Model", state.model)
    table.add_row("API Key", state.api_status)
    table.add_row("API Base", API_BASE)
    console.print(table)


def _cmd_help(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Re-show the splash screen."""
    show_splash(console)


def _cmd_exit(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Exit the REPL."""
    console.print("[bold cyan]Goodbye![/bold cyan]")
    sys.exit(0)


def _cmd_update(args: str, state: SessionState) -> None:  # noqa: ARGS001
    """Update ARAHIN to the latest version from GitHub."""
    import shutil
    import subprocess

    # Detect installation method
    pipx_path = shutil.which("pipx")
    arahin_path = shutil.which("arahin")

    if arahin_path and pipx_path:
        # Likely installed via pipx — check
        result = subprocess.run(
            [pipx_path, "list", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        if "arahin" in result.stdout:
            console.print("[bold]Updating via pipx...[/bold]")
            subprocess.run([pipx_path, "upgrade", "arahin"])
            console.print("[green][OK] ARAHIN updated.[/green]")
            console.print(
                "[yellow][!] Restart ARAHIN to use the new version "
                "(/update can't reload the running process)[/yellow]"
            )
            return

    # pip install fallback
    pip_cmds = [
        [sys.executable, "-m", "pip", "install", "--upgrade",
         "arahin"],
        [sys.executable, "-m", "pip", "install", "--upgrade",
         "--break-system-packages", "arahin"],
    ]

    console.print("[bold]Updating via pip...[/bold]")
    for cmd in pip_cmds:
        try:
            result = subprocess.run(cmd, timeout=120)
            if result.returncode == 0:
                console.print("[green][OK] ARAHIN updated.[/green]")
                console.print(
                    "[yellow][!] Restart ARAHIN to use the new version.[/yellow]"
                )
                return
        except Exception:
            continue

    console.print(
        "[yellow]Could not auto-update.[/yellow] Try manually:\n"
        "  pipx upgrade arahin\n"
        "  # or:\n"
        "  pip install --upgrade arahin"
    )


# ── Command dispatch ───────────────────────────────────────────────────────

REPL_COMMANDS: dict[str, callable] = {
    "/api": _cmd_api,
    "/model": _cmd_model,
    "/map": _cmd_map,
    "/dir": _cmd_dir,
    "/config": _cmd_config,
    "/help": _cmd_help,
    "/exit": _cmd_exit,
}

_CMD_HELP = {
    "/api": "Set API key (session only)",
    "/model": "Switch LLM model",
    "/map": "Open route map in browser",
    "/dir": "Show turn-by-turn directions",
    "/config": "Show all settings",
    "/help": "Show this screen",
    "/exit": "Quit",
}


def _show_commands() -> None:
    """Display available commands in a table."""
    table = Table(title="Commands", border_style="cyan")
    table.add_column("Command", style="bold cyan")
    table.add_column("Description")
    for cmd in sorted(_CMD_HELP):
        table.add_row(cmd, _CMD_HELP[cmd])
    table.add_row("[dim]/[/dim]", "[dim]show this list[/dim]")
    console.print(table)


# ── Core route query pipeline ──────────────────────────────────────────────


def _print_route(
    ordered: list[dict], route_details: list[dict] | None = None
) -> None:
    """Print the route as a rich table."""
    if not ordered:
        return

    total_dist = 0.0
    total_dur = 0.0

    table = Table(
        title="ARAHIN ROUTE",
        border_style="cyan",
        header_style="bold",
    )
    table.add_column("#", style="dim")
    table.add_column("Waypoint")
    table.add_column("Distance", justify="right")
    table.add_column("Duration", justify="right")

    for i, wp in enumerate(ordered):
        label = wp["name"]
        if i == 0:
            label = f"{label} (START)"
        elif i == len(ordered) - 1:
            label = f"{label} (END)"

        dist = ""
        dur = ""
        if route_details and i < len(route_details):
            d = route_details[i]
            if d:
                dist = f"{d.get('distance_km', 0):.1f} km"
                dur = f"{d.get('duration_min', 0):.0f} min"
                total_dist += d.get("distance_km", 0)
                total_dur += d.get("duration_min", 0)

        table.add_row(str(i + 1), label, dist, dur)

    if route_details:
        table.add_row(
            "",
            "[bold]Total[/bold]",
            f"[bold]{total_dist:.1f} km[/bold]",
            f"[bold]{total_dur:.0f} min[/bold]",
        )

    console.print(table)


def _run_query(query: str, state: SessionState, show_map: bool = False) -> bool:
    """Execute full route pipeline: ReAct → optimize → render → print.

    Returns True on success, False on failure.
    """
    from .agent.controller import Agent
    from .agent.prompts import TOOLS_SCHEMA, SYSTEM_PROMPT
    from .tools.optimizer import optimize_route
    from .tools.render_map import render_route_html
    from .tools.route import get_route

    from rich.rule import Rule

    if not state.api_key:
        console.print(
            "[red]API key not set.[/red] "
            "Set it with [bold]/api <key>[/bold] "
            "or export $ARAHIN_API_KEY"
        )
        console.print(Rule(style="dim"))
        return False

    reset_route_state()

    # Step 1: ReAct loop — collect waypoints
    console.print("[bold][AI] Extracting waypoints...[/bold]")
    agent = Agent(
        api_key=state.api_key,
        model=state.model,
        api_base=API_BASE,
    )
    try:
        waypoints = agent.run(
            query, TOOLS_SCHEMA, SYSTEM_PROMPT,
            print_cb=lambda msg: console.print(msg),
        )
    except Exception as e:
        console.print(f"[red]Agent error: {e}[/red]")
        console.print(Rule(style="dim"))
        return False

    if not waypoints:
        console.print("[red][X] No waypoints could be identified.[/red]")
        console.print(Rule(style="dim"))
        return False

    # Chat response (LLM chimed in without tools)
    if len(waypoints) == 1 and "_chat" in waypoints[0]:
        console.print(Rule(style="dim"))
        return True

    console.print(f"[+] [bold]{len(waypoints)}[/bold] waypoints found.")

    # Step 2: Optimize route (TSP)
    ordered, _ = optimize_route(waypoints)
    state.last_waypoints = waypoints
    state.last_ordered = ordered

    # Step 3: Get per-leg OSRM data
    route_details: list[dict[str, Any]] = []
    for i in range(len(ordered) - 1):
        leg = get_route(ordered[i], ordered[i + 1])
        if leg:
            route_details.append(leg)
        else:
            route_details.append(
                {
                    "distance_km": 0,
                    "duration_min": 0,
                    "geometry": None,
                    "steps": [],
                }
            )
    state.last_route_details = route_details

    # Step 4: Print route table
    _print_route(ordered, route_details)

    # Step 5: Generate map (always — enables /map)
    try:
        path = render_route_html(ordered, route_details)
        state.last_map_path = path
        console.print(f"[MAP] Map saved: [dim]{path}[/dim]")
        if show_map:
            webbrowser.open(f"file://{path}")
            console.print("[MAP] Opened map in browser")
    except Exception as e:
        console.print(f"[yellow]Map render skipped: {e}[/yellow]")

    console.print(Rule(style="dim"))
    return True


# ── REPL loop ──────────────────────────────────────────────────────────────


def repl_loop(state: SessionState) -> None:
    """Run the interactive REPL."""
    from rich.rule import Rule

    # Try to enable readline for history + tab completion.
    # Falls back to plain input() if not available.
    _has_readline = True
    try:
        import readline

        COMMANDS = sorted(REPL_COMMANDS.keys())

        def complete(text: str, state_idx: int) -> str | None:
            if text.startswith("/"):
                m = [c for c in COMMANDS if c.startswith(text)]
                if state_idx < len(m):
                    return m[state_idx]
            return None

        readline.set_completer(complete)
        readline.parse_and_bind("tab: complete")
        histfile = os.path.expanduser("~/.arahin_history")
        try:
            readline.read_history_file(histfile)
        except Exception:
            pass
    except Exception:
        _has_readline = False
        histfile = None

    show_splash(console)

    while True:
        try:
            raw = input("\033[36mYou\033[0m > ")
        except (EOFError, KeyboardInterrupt):
            console.print()
            _cmd_exit("", state)
            break

        text = raw.strip()
        if not text:
            continue

        # Save to history if readline is available
        if _has_readline:
            try:
                readline.append_history_file(1, histfile)
            except Exception:
                pass

        console.print()  # blank line before response

        # Dispatch slash commands
        if text.startswith("/"):
            parts = text.split(maxsplit=1)
            cmd = parts[0].lower()
            args = parts[1] if len(parts) > 1 else ""

            handler = REPL_COMMANDS.get(cmd)
            if handler:
                handler(args, state)
            else:
                console.print(
                    f"[yellow]Unknown command: {cmd}[/yellow]\n"
                    f"Type [bold]/help[/bold] for available commands."
                )
            console.print(Rule(style="dim"))
            continue

        # Show command list when typing just "/"
        if text == "/":
            _show_commands()
            console.print(Rule(style="dim"))
            continue

        # Route query — let LLM handle everything (route or chat)
        _run_query(text, state)


# ── CLI entry point ────────────────────────────────────────────────────────


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse CLI arguments."""
    parser = argparse.ArgumentParser(
        prog="arahin",
        description="AI Route Planning Agent — Spatial-RAG + TSP",
    )
    parser.add_argument(
        "query",
        nargs="?",
        help="Route description (omit for interactive REPL mode)",
    )
    parser.add_argument(
        "--map",
        "-m",
        action="store_true",
        help="Open route map in browser",
    )
    parser.add_argument(
        "--directions",
        "-d",
        action="store_true",
        help="Print turn-by-turn directions",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"ARAHIN v{__version__}",
    )
    parser.add_argument(
        "--update",
        "-u",
        action="store_true",
        help="Update ARAHIN to the latest version",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Main entry point."""
    args = parse_args(argv)
    state = get_state()

    # Load API key: persisted file > env var > prompt user
    if not state.api_key:
        state.api_key = _load_api_key()
    if not state.api_key:
        state.api_key = os.environ.get("ARAHIN_API_KEY", "")
    if not state.api_key:
        state.api_key = os.environ.get("OPENCODE_API_KEY", "")

    # Non-interactive mode
    if args.query:
        success = _run_query(args.query, state, show_map=args.map)
        if args.directions and success:
            _cmd_dir("", state)
        sys.exit(0 if success else 1)

    # Update mode
    if args.update:
        _cmd_update("", state)
        sys.exit(0)

    # Interactive REPL mode
    try:
        repl_loop(state)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
