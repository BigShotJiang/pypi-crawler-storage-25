"""ARAHIN — AI Route Planning Agent with Spatial-RAG + TSP."""

__version__ = "1.1.1"
