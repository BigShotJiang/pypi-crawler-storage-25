"""Spatial retrieval: Overpass query → return nearby POIs.

Queries multiple OSM tag types (amenity, tourism, leisure, shop)
and filters out irrelevant results like parking lots, mailboxes,
waste bins, etc. The LLM in the ReAct loop handles semantic matching.
"""

from __future__ import annotations

from typing import Any

import requests

# OSM tag types to query for places of interest
QUERY_TAGS = {
    "amenity": [
        "restaurant", "fast_food", "cafe", "food_court", "bar", "pub",
        "ice_cream", "bakery", "pastry",
        "place_of_worship", "university", "college", "library",
        "theatre", "cinema", "nightclub", "casino",
        "hospital", "clinic", "pharmacy",
        "marketplace", "bank", "atm", "post_office",
        "bus_station", "ferry_terminal", "taxi",
        "fuel", "parking_entrance",
    ],
    "tourism": [
        "attraction", "museum", "gallery", "theme_park", "zoo",
        "viewpoint", "aquarium", "information",
    ],
    "leisure": [
        "park", "garden", "playground", "sports_centre", "stadium",
        "swimming_pool", "water_park", "nature_reserve",
    ],
    "shop": [
        "mall", "department_store", "supermarket",
        "bakery", "pastry", "confectionery",
    ],
    "historic": [
        "monument", "memorial", "castle", "ruins", "fort",
    ],
}

# Amenity types that are never useful as waypoints
EXCLUDE_AMENITIES = {
    "parking", "waste_basket", "waste_disposal", "waste_dump_site",
    "post_box", "telephone", "toilets", "bench", "shelter",
    "drinking_water", "watering_place", "vending_machine",
    "bicycle_parking", "motorcycle_parking", "charging_station",
}


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km between two coordinates."""
    import math
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(dlon / 2) ** 2
    )
    return 6371 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def spatial_rag(
    query: str,
    lat: float,
    lng: float,
    radius: float = 5,
    top_k: int = 10,
) -> list[dict[str, Any]]:
    """Return nearby POIs from Overpass within radius.

    Queries multiple OSM tag types (amenities, tourism, leisure, shops,
    historic sites) and excludes noise (parking, waste bins, etc.).
    """
    # Build a union query across all tag types
    node_lines: list[str] = []
    for tag_key, tag_values in QUERY_TAGS.items():
        for tag_val in tag_values:
            node_lines.append(
                f'node[{tag_key}="{tag_val}"](around:{radius * 1000},'
                f"{lat},{lng});"
            )

    overpass_query = (
        f"[out:json][timeout:30];(\n    "
        + "\n    ".join(node_lines)
        + "\n);out body 50;"
    )

    try:
        resp = requests.post(
            "https://overpass-api.de/api/interpreter",
            data={"data": overpass_query},
            headers={
                "User-Agent": "ARAHIN/1.0",
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            },
            timeout=30,
        )
    except requests.RequestException:
        return []

    if resp.status_code != 200:
        return []

    elements = resp.json().get("elements", [])
    if not elements:
        return []

    results: list[dict[str, Any]] = []
    for el in elements:
        tags = el.get("tags", {})
        amenity_type = tags.get("amenity", "")
        if amenity_type in EXCLUDE_AMENITIES:
            continue

        name = tags.get("name", "")
        if not name:
            continue

        dist = _haversine(lat, lng, el["lat"], el["lon"])
        if dist > radius:
            continue

        # Determine display category
        cat = (
            tags.get("amenity")
            or tags.get("tourism")
            or tags.get("leisure")
            or tags.get("shop")
            or tags.get("historic")
            or "place"
        )

        results.append({
            "name": name,
            "lat": el["lat"],
            "lng": el["lon"],
            "category": cat,
            "dist_km": round(dist, 1),
        })

    results.sort(key=lambda x: x["dist_km"])
    return results[:top_k]
