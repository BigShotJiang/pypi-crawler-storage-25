"""Forward geocode — Nominatim API. Any place, any city."""

from __future__ import annotations

import time

import requests


def geocode(place_name: str) -> dict:
    """Convert a named place to coordinates via Nominatim.

    Rate-limited to 1 req/sec (Nominatim usage policy).
    Include city context in place_name for better results, e.g.
    'Monas, Jakarta' not just 'Monas'.
    """
    time.sleep(1)  # Nominatim rate limit

    # Try the full place name first, then fallback to just the place
    # (without ", Yogyakarta" suffix that LLM sometimes adds)
    for attempt in [place_name, place_name.split(",")[0].strip()]:
        resp = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={
                "q": attempt,
                "format": "json",
                "limit": 1,
            },
            headers={
                "User-Agent": "ARAHIN/1.0 (research)",
                "Accept-Language": "id,en",
            },
            timeout=15,
        )

        if resp.status_code == 200 and resp.json():
            r = resp.json()[0]
            return {
                "name": place_name.split(",")[0].strip(),
                "lat": float(r["lat"]),
                "lng": float(r["lon"]),
                "display_name": r["display_name"],
            }

        time.sleep(0.5)

    return {"error": f"Geocode failed: {place_name}"}
