"""System prompt + 3 tool schemas for the ReAct agent."""

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "geocode",
            "description": (
                "Convert a named place to coordinates. "
                "First call for every location mentioned: "
                "'Monas, Jakarta' or 'Tokyo Tower'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "place_name": {
                        "type": "string",
                        "description": "Place name, e.g. 'Monas, Jakarta' or 'Tokyo Tower'",
                    }
                },
                "required": ["place_name"],
            },
        }
    },
    {
        "type": "function",
        "function": {
            "name": "spatial_rag",
            "description": (
                "Find places matching a natural-language description near coordinates. "
                "Use for vague queries: 'sate enak dekat Cawang', 'halal food near Central Park'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "What to find, in natural language",
                    },
                    "lat": {
                        "type": "number",
                        "description": "Latitude of search center",
                    },
                    "lng": {
                        "type": "number",
                        "description": "Longitude of search center",
                    },
                    "radius": {
                        "type": "integer",
                        "default": 5,
                        "description": "Search radius in km",
                    },
                },
                "required": ["query", "lat", "lng"],
            },
        }
    },
    {
        "type": "function",
        "function": {
            "name": "poi_search",
            "description": (
                "Search POIs by OSM amenity category near coordinates. "
                "Use for structured queries: 'cari masjid', 'cari restoran', 'cari ATM'"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Amenity type: restaurant, cafe, mosque, atm, hospital, etc.",
                    },
                    "lat": {"type": "number"},
                    "lng": {"type": "number"},
                    "radius": {
                        "type": "integer",
                        "default": 3,
                        "description": "Search radius in km",
                    },
                },
                "required": ["category", "lat", "lng"],
            },
        }
    },
]

SYSTEM_PROMPT = (
    "You are ARAHIN, an AI ReAct Agent for Hybrid Itinerary Navigation.\n\n"
    "If the user describes a route or asks for directions, extract ALL "
    "waypoints (start, destination, intermediate stops) using your tools. "
    "When waypoints are collected, output ONLY a JSON array:\n"
    '[{"name": "...", "lat": ..., "lng": ...}, ...]\n\n'
    "If the user is just chatting (greetings, questions, jokes, etc.), "
    "respond naturally and conversationally — do NOT call tools or "
    "output JSON for non-route messages.\n\n"
    "Available tools:\n"
    "- geocode(place_name): Convert a named place to coordinates.\n"
    "- spatial_rag(query, lat, lng, radius?): Nearby points of interest.\n"
    "- poi_search(category, lat, lng, radius?): POIs by category.\n\n"
    "Call ONE tool at a time. Think step by step."
)
