from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

from rich.console import Group
from rich.panel import Panel
from rich.progress import Progress
from rich.table import Column, Table

from stimela.monitoring.local import LocalReport

from .base import DisplayStyle
from .elements import status_element, timer_element

if TYPE_CHECKING:
    from stimela.task_stats import TaskInformation


class LocalDisplay(DisplayStyle):
    """Styles a rich live display appropriately for local backends.

    In addition to the attributes below, attributes will be added for each
    key in tracked_values. A *_id attribute will also be added for each key.

    Attributes:
        tracked_values:
            A mapping from name to description for quantities present in
            this display stlye.
        run_elapsed:
            A rich.Progress object tracking total time elapsed.
        run_elapsed_id:
            The task ID of the task associcated with run_elapsed.
        task_elapsed:
            A rich.Progress object tracking time elapsed in the current task.
        task_elapsed_id:
            The task ID of the task associcated with task_elapsed.
        task_maxima:
            A dict for tracking the peak values of certain progress elements.
    """

    tracked_values = {
        "cpu_usage": "CPU",
        "ram_usage": "RAM",
        "system_load": "Load",
        "disk_read": "Read",
        "disk_write": "Write",
        "task_name": "Step",
        "task_status": "Status",
        "task_command": "Command",
        "task_cpu_usage": "CPU",
        "task_ram_usage": "RAM",
        "task_peak_ram_usage": "Peak",
        "task_peak_cpu_usage": "Peak",
    }

    def __init__(self, run_timer: Progress):
        """Configures the display in local fancy mode.

        Args:
            run_timer:
                Progress object which tracks total run time.
        """

        super().__init__(run_timer)

        self.task_maxima = defaultdict(float)

        width = max(len(fn) for fn in self.tracked_values.values() if fn)

        # Set the width of the text column in the recipe timer.
        self.run_elapsed.columns[1].get_table_column().width = width - 1
        # Set the description recipe timer task.
        self.run_elapsed.update(self.run_elapsed_id, description="")

        self.task_elapsed = timer_element(width=width - 1)
        self.task_elapsed_id = self.task_elapsed.add_task("")

        for k, v in self.tracked_values.items():
            status = status_element(width=width)
            status_id = status.add_task(v, value="--")
            setattr(self, k, status)
            setattr(self, f"{k}_id", status_id)

        ram_columns = [Column(ratio=1), Column(ratio=1)]
        ram_table = Table.grid(*ram_columns, expand=True, padding=(0, 1))
        ram_table.add_row(self.task_ram_usage, self.task_peak_ram_usage)

        cpu_columns = [Column(ratio=1), Column(ratio=1)]
        cpu_table = Table.grid(*cpu_columns, expand=True, padding=(0, 1))
        cpu_table.add_row(self.task_cpu_usage, self.task_peak_cpu_usage)

        task_group = Group(self.task_elapsed, self.task_name, self.task_status, self.task_command, cpu_table, ram_table)

        system_group = Group(
            self.run_elapsed, self.cpu_usage, self.ram_usage, self.disk_read, self.disk_write, self.system_load
        )

        group_columns = [Column(ratio=1), Column(ratio=1)]
        table = Table.grid(*group_columns, expand=True)
        table.add_row(
            Panel(system_group, title="System", border_style="green", expand=True),
            Panel(
                task_group,
                title="Task",
                border_style="green",
                expand=True,
            ),
        )

        self.render_target = table

    def reset(self):
        """Reset elements of the display e.g. time elapsed in a task."""
        super().reset()
        self.task_maxima.clear()

    def update(
        self,
        task_info: TaskInformation,
        report: LocalReport,
    ):
        """Updates the progress elements using the provided values.

        Args:
            task_info:
                An object containing information about the current task.
            report:
                A Report object containing resource monitoring.
        """

        if task_info is not None:
            self.task_name.update(self.task_name_id, value=f"[bold]{task_info.description}[/bold]")

            self.task_status.update(self.task_status_id, value=f"[dim]{task_info.status or 'running'}[/dim]")
            # Sometimes the command contains square brackets which rich
            # interprets as formatting. Remove them. # TODO: Figure out
            # why the command has square brackets in the first place.
            self.task_command.update(self.task_command_id, value=f"{(task_info.command or '--').strip('([])')}")

        # Require a LocalReport to update all fields.
        if not isinstance(report, LocalReport):
            return

        self.cpu_usage.update(self.cpu_usage_id, value=f"[green]{report.sys_cpu}[/green]%")

        used = report.sys_mem_used
        total = report.sys_mem_total
        percent = (used / total) * 100

        self.ram_usage.update(
            self.ram_usage_id, value=(f"[green]{used}/{total}[/green]GB ([green]{percent:.2f}[/green]%)")
        )

        self.system_load.update(
            self.system_load_id,
            value=(
                f"[green]{report.load_1m:.2f}[/green]%/"
                f"[green]{report.load_5m:.2f}[/green]%/"
                f"[green]{report.load_15m:.2f}[/green]% "
                f"(1/5/15 min)"
            ),
        )

        self.disk_read.update(
            self.disk_read_id,
            value=(
                f"[green]{report.read_gbps:2.2f}[/green]GB/s "
                f"[green]{report.read_ms:5}[/green]ms "
                f"[green]{report.read_count:-4}[/green] reads"
            ),
        )
        self.disk_write.update(
            self.disk_write_id,
            value=(
                f"[green]{report.write_gbps:2.2f}[/green]GB/s "
                f"[green]{report.write_ms:5}[/green]ms "
                f"[green]{report.write_count:-4}[/green] writes"
            ),
        )

        self.task_cpu_usage.update(self.task_cpu_usage_id, value=f"[green]{report.cpu:2.1f}[/green]%")

        max_cpu = max(report.cpu, self.task_maxima["task_peak_cpu_usage"])
        self.task_maxima["task_peak_cpu_usage"] = max_cpu
        self.task_peak_cpu_usage.update(self.task_peak_cpu_usage_id, value=f"[green]{max_cpu:2.1f}[/green]%")

        self.task_ram_usage.update(self.task_ram_usage_id, value=f"[green]{report.mem_used}[/green]GB")

        max_ram = max(report.mem_used, self.task_maxima["task_peak_ram_usage"])
        self.task_maxima["task_peak_ram_usage"] = max_ram
        self.task_peak_ram_usage.update(self.task_peak_ram_usage_id, value=f"[green]{max_ram}[/green]GB")


class SimpleLocalDisplay(DisplayStyle):
    """Styles a rich live display appropriately for local backends.

    In addition to the attributes below, attributes will be added for each
    key in tracked_values. A *_id attribute will also be added for each key.

    Attributes:
        tracked_values:
            A mapping from name to description for quantities present in
            this display stlye.
        run_elapsed:
            A rich.Progress object tracking total time elapsed.
        run_elapsed_id:
            The task ID of the task associcated with run_elapsed.
        task_elapsed:
            A rich.Progress object tracking time elapsed in the current task.
        task_elapsed_id:
            The task ID of the task associcated with task_elapsed.
    """

    tracked_values = {
        "task_name": None,
        "task_command": None,
        "task_status": None,
        "task_cpu_usage": "CPU",
        "task_ram_usage": "RAM",
        "disk_read": "R",
        "disk_write": "W",
    }

    def __init__(self, run_timer: Progress):
        """Configures the display in local simple mode.

        Args:
            run_timer:
                Progress object which tracks total run time.
        """

        super().__init__(run_timer)

        self.run_elapsed.update(self.run_elapsed_id, description="R")
        self.task_elapsed.update(self.task_elapsed_id, description="S")

        for k, v in self.tracked_values.items():
            status = status_element(has_description=v is not None)
            status_id = status.add_task(v, value="--")
            setattr(self, k, status)
            setattr(self, f"{k}_id", status_id)

        table = Table.grid(expand=False, padding=(0, 1))
        table.add_row(
            self.run_elapsed,
            self.task_elapsed,
            self.task_name,
            self.task_status,
            self.task_command,
            self.task_cpu_usage,
            self.task_ram_usage,
            self.disk_read,
            self.disk_write,
        )

        self.render_target = table

    def update(
        self,
        task_info: TaskInformation,
        report: LocalReport,
    ):
        """Updates the progress elements using the provided values.

        Args:
            task_info:
                An object containing information about the current task.
            report:
                A Report object containing resource monitoring.
        """
        if task_info is not None:
            self.task_name.update(self.task_name_id, value=f"[bold]{task_info.description}[/bold]")

            self.task_status.update(self.task_status_id, value=f"[dim]{task_info.status or 'running'}[/dim]")

            # Sometimes the command contains square brackets which rich
            # interprets as formatting. Remove them. # TODO: Figure out
            # why the command has square brackets in the first place.
            self.task_command.update(self.task_command_id, value=f"{(task_info.command or '--').strip('([])')}")

        # Require a LocalReport to update all fields.
        if not isinstance(report, LocalReport):
            return

        self.disk_read.update(self.disk_read_id, value=f"[green]{report.read_gbps:2.2f}[/green]GB/s")
        self.disk_write.update(self.disk_write_id, value=f"[green]{report.write_gbps:2.2f}[/green]GB/s")
        self.task_cpu_usage.update(self.task_cpu_usage_id, value=f"[green]{report.cpu:2.1f}[/green]%")
        self.task_ram_usage.update(self.task_ram_usage_id, value=f"[green]{report.mem_used}[/green]GB")
