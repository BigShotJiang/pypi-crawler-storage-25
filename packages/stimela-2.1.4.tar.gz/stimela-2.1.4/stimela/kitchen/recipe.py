import copy
import fnmatch
import logging
import re
import sys
from collections import OrderedDict
from collections.abc import Mapping
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from io import StringIO
from typing import Any, Dict, Optional, Tuple, Union, get_origin

import networkx as nx
import rich.table
from omegaconf import DictConfig, ListConfig, OmegaConf

import stimela
from scabha.basetypes import UNSET, Placeholder
from scabha.cargo import Cargo, Parameter, ParameterCategory
from scabha.substitutions import SubstitutionNS
from scabha.validate import Unresolved, evaluate_and_substitute, evaluate_and_substitute_object
from stimela import backends, log_exception, stimelogging, task_stats
from stimela.backends import StimelaBackendSchema
from stimela.config import EmptyDictDefault
from stimela.display.display import display
from stimela.exceptions import (
    AssignmentError,
    BackendError,
    DefinitionError,
    FormattedTraceback,
    ParameterValidationError,
    RecipeValidationError,
    ScabhaBaseException,
    StepValidationError,
    StimelaRuntimeError,
    StimelaStepExecutionError,
)
from stimela.kitchen.run_state import RunConstraints
from stimela.stimelogging import log_rich_payload, rich_console

from .cab import Cab
from .step import Step


class DeferredAlias(Unresolved):
    """Class used as placeholder for deferred alias lookup (i.e. before an aliased value is available)"""

    pass


@dataclass
class ForLoopClause(object):
    # name of list variable
    var: str
    # This should be the name of an input that provides a list, or a list
    over: Optional[Any] = None
    # If !=0 , this is a scatter not a loop -- things may be evaluated in parallel using this many workers
    # (use -1 to scatter to unlimited number of workers)
    scatter: int = 0
    # How to indicate the status of the loop on the console.
    # Default is "i/N", where i is the current index plus 1, and N is the total number of loops.
    # A format string can be supplied instead.
    display_status: Optional[str] = None
    # Expressions to be evaluated at each iteration and accumulated into list-type outputs
    output_elements: Dict[str, Any] = EmptyDictDefault()


def IterantPlaceholder(name: str):
    return name


@dataclass
class Recipe(Cargo):
    """Represents a sequence of steps.

    Additional attributes available after validation with arguments are as per for a Cab:

        self.input_output:      combined parameter dict (self.input + self.output), maps name to Parameter

    Raises:
        various classes of validation errors
    """

    steps: Dict[str, Step] = EmptyDictDefault()  # sequence of named steps

    assign: Dict[str, Any] = EmptyDictDefault()  # assigns variables

    assign_based_on: Dict[str, Any] = EmptyDictDefault()
    # assigns variables based on values of other variables

    aliases: Dict[str, Any] = EmptyDictDefault()

    # overrides backend options
    backend: Optional[Dict[str, Any]] = None

    # make recipe a for_loop-gather (i.e. parallel for loop)
    for_loop: Optional[ForLoopClause] = None

    def __post_init__(self):
        Cargo.__post_init__(self)
        # flatten aliases and assignments
        self.aliases = self.flatten_param_dict(OrderedDict(), self.aliases)
        # check that schemas are valid
        for io in self.inputs, self.outputs:
            for name, schema in io.items():
                if not schema:
                    raise RecipeValidationError(f"recipe '{self.name}': '{name}' does not define a valid schema")
        # check for repeated aliases
        for name, alias_list in self.aliases.items():
            if name in self.inputs_outputs:
                raise RecipeValidationError(
                    f"recipe '{self.name}': alias '{name}' also appears under inputs or outputs"
                )
            if type(alias_list) is str:
                alias_list = self.aliases[name] = [alias_list]
            if not hasattr(alias_list, "__iter__") or not all(type(x) is str for x in alias_list):
                raise RecipeValidationError(f"recipe '{self.name}': alias '{name}': name or list of names expected")
            for x in alias_list:
                if "." not in x:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': alias '{name}': invalid target '{x}' (missing dot)"
                    )
        # instantiate steps if needed (when creating from an omegaconf)
        if type(self.steps) is not OrderedDict:
            steps = OrderedDict()
            for label, stepconfig in self.steps.items():
                stepconfig.name = label
                stepconfig.fqname = f"{self.name}.{label}"
                try:
                    step = OmegaConf.unsafe_merge(StepSchema.copy(), stepconfig)
                    steps[label] = Step(**step)
                except Exception as exc:
                    raise StepValidationError(f"recipe '{self.name}': error in definition of step '{label}'", exc)
            self.steps = steps
        # check that assignments don't clash with i/o parameters

        self.validate_assignments(self.assign, self.assign_based_on, self.name)

        # check that for-loop variable does not clash
        if self.for_loop:
            for io, io_label in [(self.inputs, "input"), (self.outputs, "output")]:
                if self.for_loop.var in io:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': for_loop.var={self.for_loop.var} clashes with an {io_label} parameter"
                    )
        # marked when finalized
        self._alias_map = None
        # set of keys protected from assignment
        self._protected_from_assign = set()
        self._for_loop_values = self._for_loop_scatter = None
        # process pool used to run for-loops
        self._loop_pool = None

    def validate_assignments(self, assign, assign_based_on, location):
        # collect a list of all assignments
        assignments = OrderedDict()
        for key in assign:
            assignments[key] = "assign"
        for basevar, lookup_list in assign_based_on.items():
            if not isinstance(lookup_list, Mapping):
                raise RecipeValidationError(f"{location}.{assign_based_on}.{basevar}: mapping expected")
            # for assign_list in lookup_list.values():
            #     for key in assign_list:
            #         assignments[key] = f"assign_based_on.{basevar}"
        # # check that none clash
        # for key, assign_label in assignments.items():
        #     for io, io_label in [(self.inputs, "input"), (self.outputs, "output")]:
        #         if key in io:
        #             raise RecipeValidationError(f"'{location}.{assign_label}.{key}' clashes with an {io_label}")

    def update_assignments(
        self,
        subst: SubstitutionNS,
        whose=None,
        params: Dict[str, Any] = {},
        ignore_subst_errors: bool = False,
        ignore_abo_errors: bool = False,
    ):
        """Updates variable assignments, using the recipe's (or a step's) 'assign' and 'assign_based_on' sections.
        Also updates the corresponding (recipe or step's) file logger.

        Args:
            subst (SubstitutionNS): substitution namespace
            whose (Step or None): if None, use recipe's (self) assignments, else use this step's
            params (dict, optional): dictionary of parameters
            ignore_subst_errors (bool): ignore substitution errors (default is False)

        Raises:
            AssignmentError: on errors
        """
        whose = whose or self
        # short-circuit out if nothing to do
        if not whose.assign and not whose.assign_based_on:
            return

        def flatten_dict(input_dict, output_dict={}, prefix=""):
            for name, value in input_dict.items():
                name = f"{prefix}{name}"
                if isinstance(value, (dict, OrderedDict, DictConfig)):
                    flatten_dict(value, output_dict=output_dict, prefix=f"{name}.")
                else:
                    output_dict[name] = value
            return output_dict

        # accumulate all assignments for a final round of evaluation
        assign = {}

        def do_assign(assignments):
            """Helper function to process a list of assignments.

            Called repeatedly for the assign section, and for each assign_based_on entry. Substitution errors are
            ignored at this stage, a final round of re-evaluation with ignore=False is done at the end.
            """
            # flatten assignments
            flattened = assignments  # flatten_dict(assignments)
            # drop entries protected from assignment
            flattened = {name: value for name, value in flattened.items() if name not in self._protected_from_assign}
            # merge into recipe namespace
            subst.recipe._merge_(flattened)
            # perform substitutions
            try:
                flattened = evaluate_and_substitute(
                    flattened, subst, subst.recipe, location=[whose.fqname], ignore_subst_errors=True, log=self.log
                )
            except Exception as exc:
                raise AssignmentError(f"{whose.fqname}: error evaluating assignments", exc)
            assign.update(flattened)

        # perform direct assignments
        do_assign(whose.assign)

        # add assign_based_on entries to flattened_assign
        for basevar, value_list in whose.assign_based_on.items():
            # make sure the base variable is defined
            value = None
            # it will be in subst.recipe if it was assigned, or is an input
            if basevar in subst.recipe:
                value = str(subst.recipe[basevar])
            # else it may be a for-loop index that hasn't been assigned yet -- ignore
            elif self.for_loop is not None and basevar == self.for_loop.var:
                continue
            # else it might be an input with a default, check for that
            elif basevar in self.inputs_outputs and self.inputs_outputs[basevar].default is not UNSET:
                value = str(self.inputs_outputs[basevar].default)
            # else see if it is a config setting
            elif basevar.startswith("config."):
                comps = basevar.split(".")[1:]
                try:
                    value = self.config
                    for comp in comps:
                        value = value.get(comp)
                except Exception:
                    value = None
            # nothing found? error then
            if value is None:
                if ignore_abo_errors:
                    continue
                if basevar in self.inputs_outputs:
                    raise AssignmentError(f"{whose.fqname}.assign_based_on: a value for '{basevar}' was not supplied")
                elif "." in basevar:
                    raise AssignmentError(f"{whose.fqname}.assign_based_on: '{basevar}' is not a known config item")
                else:
                    raise AssignmentError(f"{whose.fqname}.assign_based_on: '{basevar}' is not a known variable")
            # look up list of assignments
            if value not in value_list:
                if ignore_abo_errors:
                    continue
                if "DEFAULT" not in value_list:
                    raise AssignmentError(
                        f"{whose.fqname}.assign_based_on: neither the '{basevar}={value}' case nor a DEFAULT case is "
                        f"defined"
                    )
                value = "DEFAULT"
            assignments = value_list.get(value)
            # an empty section maps to None, so skip
            if assignments is None:
                continue
            if not isinstance(assignments, (dict, OrderedDict, DictConfig)):
                raise AssignmentError(
                    f"{whose.fqname}.assign_based_on.{basevar}.{value}: mapping expected, got {type(assignments)} "
                    f"instead"
                )
            # process the assignments
            do_assign(assignments)

        # do final round of substitutions
        try:
            assign = evaluate_and_substitute(
                assign,
                subst,
                subst.recipe,
                location=[whose.fqname],
                ignore_subst_errors=ignore_subst_errors,
                log=self.log,
            )
        except Exception as exc:
            raise AssignmentError(f"{whose.fqname}: error evaluating assignments", exc)
        # dispatch and reassign, since substitutions may have been performed
        for key, value in assign.items():
            if ignore_subst_errors and isinstance(value, Unresolved):
                continue
            self.assign_value(key, value, subst=subst, whose=whose)

    def assign_value(
        self,
        key: str,
        value: Any,
        override: bool = False,
        subst: Optional[Dict[str, Any]] = None,
        whose: Optional[Any] = None,
    ):
        """assigns a parameter value to the recipe. Handles nested assignments and
        assignments to local log options.
        """
        # ignore protected assignments
        if key in self._protected_from_assign and not override:
            return

        if "." in key:
            nesting, subkey = key.split(".", 1)
        else:
            nesting, subkey = None, key

        # helper function to do nested assignment of config and subst and backend
        def assign_nested(container, nested_key, value):
            comps = nested_key.split(".")
            while len(comps) > 1:
                if comps[0] not in container:
                    raise AssignmentError(f"{self.fqname}: invalid assignment {key}={value}")
                container = container[comps[0]]
                comps.pop(0)
            container[comps[0]] = value

        # assigning to input or output? Provide default
        if key in self.inputs_outputs:
            self.log.debug(f"default params assignment: {key}={value}")
            if value is UNSET:
                if key in self.defaults:
                    del self.defaults[key]
                self.inputs_outputs[key].default = UNSET
            else:
                self.defaults[key] = value
        # assigning to a substep? Invoke nested assignment
        elif nesting is not None and nesting in self.steps:
            return self.steps[nesting].assign_value(subkey, value, override=override)
        # assigning to config?
        elif nesting == "config":
            assign_nested(self.config, subkey, value)
            if subst is not None and "config" in subst:
                assign_nested(subst.config, subkey, value)
        # elif nesting == "backend":
        #     assign_nested(self.backend, subkey, value)
        elif nesting == "log":
            whose = whose or self
            self.log.debug(f"log options assignment: {key}={value}")
            whose.update_log_options(**{subkey: value})
            if whose is self and subst is not None and "recipe" in subst:
                subst.recipe.log[subkey] = value
        # in override mode, assign to assign dict for future processing
        if override:
            if value is not UNSET:
                self.assign[key] = value
            self._protected_from_assign.add(key)

    def update_log_options(self, **options):
        for setting, value in options.items():
            if isinstance(value, Unresolved):
                raise AssignmentError(f"unresolved {self.fqname}.log.{setting} setting", [value])
            try:
                self.logopts[setting] = value
            except Exception as exc:
                raise AssignmentError(f"invalid {self.fqname}.log.{setting} setting", exc)
        # propagate to children
        for step in self.steps.values():
            step.update_log_options(**options)

    @property
    def finalized(self):
        return self._alias_map is not None

    def unskip_step(self, label, unskip=True):
        self.finalize()
        step = self.steps.get(label)
        if step is None:
            raise RecipeValidationError(f"recipe '{self.name}': unknown step {label}", log=self.log)
        if unskip:
            if step._skip is True:
                self.log.warning(f"unskipping step '{label}' which is normally skipped")
            elif step._skip is not False:
                self.log.warning(f"unskipping step '{label}' which is normally conditionally skipped ('{step.skip}')")
            step.skip = step._skip = False
            step.skip_if_outputs = None
        else:
            self.log.warning(f"will skip step '{label}'")
            step.skip = step._skip = True

    def restrict_steps(
        self,
        constraints: RunConstraints,
    ) -> int:
        """Apply the state of a RunConstraints object to the current recipe.

        Given a RunConstraints object, query it for enabled, disabled and
        unskipped steps at the current recipe level before recursing into
        subrecipes. After this method is run, all the skip attributes of
        the recipe steps should be correctly set.

        Args:
            constraints:
                A RunConstraints object which can be queried for the state
                of various recipe steps (graph nodes).

        Returns:
            An integer count of the enabled steps.
        """

        self.log.info(f"selecting recipe steps for (sub)recipe: [bold green]{self.name}[/bold green]")

        enabled_steps = constraints.get_enabled_steps(self.fqname)
        disabled_steps = constraints.get_disabled_steps(self.fqname)
        unskipped_steps = constraints.get_unskipped_steps(self.fqname)

        # Make the recipe aware of the unskipped steps i.e. steps which
        # have skip fields in the recipe but which should be run regardless.
        # This does not guarantee that the step is enabled (selected).
        for step_name in unskipped_steps:
            self.unskip_step(step_name)

        # Apply the skip flags to disabled steps.
        for step_name in disabled_steps:
            step = self.steps[step_name]
            step.skip = step._skip = True

        if not enabled_steps:
            self.log.info("no steps have been selected for execution")
            return 0

        # Log the steps which have been selected to run.
        msg = " ".join(enabled_steps)
        self.log.info("the following recipe steps have been enabled:")
        self.log.info(f"    [bold green]{msg}[/bold green]")

        if disabled_steps:
            msg = " ".join(disabled_steps)
            self.log.info("the following recipe steps have been disabled:")
            self.log.info(f"    [bold grey50]{msg}[/bold grey50]")
        if unskipped_steps:
            msg = " ".join(unskipped_steps)
            self.log.info("the following recipe steps have been unskipped:")
            self.log.info(f"    [bold cyan]{msg}[/bold cyan]")

        # Recurse into subrecipes, applying the constraints.
        for step in self.steps.values():
            if isinstance(step.cargo, Recipe):
                step.cargo.restrict_steps(constraints)

        return len(enabled_steps)

    def add_step(self, step: Step, label: str = None):
        """Adds a step to the recipe. Label is auto-generated if not supplied

        Args:
            step (Step): step object to add
            label (str, optional): step label, auto-generated if None
        """
        if self.finalized:
            raise DefinitionError("recipe '{self.name}': can't add a step to a recipe that's been finalized")

        names = [s for s in self.steps if s.cab == step.cabname]
        label = label or f"{step.cabname}_{len(names) + 1}"
        self.steps[label] = step
        step.fqname = f"{self.name}.{label}"

    def add(self, cabname: str, label: str = None, params: Optional[Dict[str, Any]] = None, info: str = None):
        """Add a step to a recipe. This will create a Step instance and call add_step()

        Args:
            cabname (str): name of cab to use for this step
            label (str): Alphanumeric label (must start with a lette) for the step. If not given will be auto
                generated 'cabname_d' where d is the number of times a particular cab has been added to the recipe.
            params (Dict): A parameter dictionary
            info (str): Documentation of this step
        """
        return self.add_step(Step(cab=cabname, params=params, info=info), label=label)

    @dataclass
    class AliasInfo(object):
        label: str  # step label
        step: Step  # step
        param: str  # parameter name
        io: Dict[str, Parameter]  # points to self.inputs or self.outputs
        from_recipe: bool = False  # if True, value propagates from recipe up to step
        from_step: bool = False  # if True, value propagates from step down to recipe

    def _add_alias(
        self, alias_name: str, alias_target: Union[str, Tuple], category: Optional[int] = None, has_value=False
    ):
        wildcards = False
        if type(alias_target) is str:
            # $$ maps to full name, and $ maps to last element of name
            alias_target = alias_target.replace("$$", alias_name)
            alias_target = alias_target.replace("$", alias_name.rsplit(".", 1)[-1])
            step_spec, step_param_name = alias_target.split(".", 1)
            # treat label as a "(cabtype)" specifier?
            if re.match(r"^\(.+\)$", step_spec):
                steps = [
                    (label, step)
                    for label, step in self.steps.items()
                    if (isinstance(step.cargo, Cab) and step.cab == step_spec[1:-1])
                    or (isinstance(step.cargo, Recipe) and step.recipe == step_spec[1:-1])
                ]
                wildcards = True
            # treat label as a wildcard?
            elif any(ch in step_spec for ch in "*?["):
                steps = [(label, step) for label, step in self.steps.items() if fnmatch.fnmatchcase(label, step_spec)]
                wildcards = True
            # else treat label as a specific step name
            else:
                steps = [(step_spec, self.steps.get(step_spec))]
        else:
            step, step_spec, step_param_name = alias_target
            steps = [(step_spec, step)]

        for step_label, step in steps:
            if step is None:
                raise RecipeValidationError(
                    f"recipe '{self.name}': alias '{alias_name}' refers to unknown step '{step_label}'", log=self.log
                )
            # is the alias already defined
            existing_alias = self._alias_list.get(alias_name, [None])[0]
            # find it in inputs or outputs
            input_schema = step.inputs.get(step_param_name)
            output_schema = step.outputs.get(step_param_name)
            schema = input_schema or output_schema
            # if the step was matched by a wildcard, and it doesn't have such a parameter in the schema, or else if it
            # is already explicitly specified, then we don't alias it
            if wildcards and (schema is None or step_param_name in step.params):
                continue
            # no a wildcard, but parameter not defined? This is an error
            if schema is None:
                raise RecipeValidationError(
                    f"recipe '{self.name}': alias '{alias_name}' refers to unknown step parameter "
                    f"'{step_label}.{step_param_name}'",
                    log=self.log,
                )
            # implicit inputs cannot be aliased
            if input_schema and input_schema.implicit:
                raise RecipeValidationError(
                    f"recipe '{self.name}': alias '{alias_name}' refers to implicit input "
                    f"'{step_label}.{step_param_name}'",
                    log=self.log,
                )
            # if alias is already defined, check for conflicts
            if existing_alias is not None:
                io = existing_alias.io
                if io is self.outputs:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': output alias '{alias_name}' is defined more than once", log=self.log
                    )
                elif output_schema:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': alias '{alias_name}' refers to both an input and an output",
                        log=self.log,
                    )
                alias_schema = io[alias_name]
                # now we know it's a multiply-defined input, check for type consistency
                if alias_schema.dtype != schema.dtype:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': alias '{alias_name}': dtype {schema.dtype} of "
                        f"'{step_label}.{step_param_name}' doesn't match previous dtype {alias_schema.dtype}",
                        log=self.log,
                    )
                orig_schema = self._orig_alias_schema[alias_name]
            # else alias not yet defined, insert a schema
            else:
                # get recipe's original schema for the parameter
                io = self.inputs if input_schema else self.outputs
                # if we have a schema defined for the alias, some params must be inherited from it
                orig_schema = io.get(alias_name)
                self._orig_alias_schema[alias_name] = orig_schema
                # define schema based on copy of the target, but preserve default
                io[alias_name] = copy.copy(schema)
                alias_schema = io[alias_name]
                # if default set in recipe schema, ignore any parameter setting in the step
                if orig_schema is not None and orig_schema.default is not UNSET:
                    if step_param_name in step.params:
                        del step.params[step_param_name]
                    alias_schema.default = orig_schema.default
                # else check if explicit value or a default is specified in the step -- make it the recipe default
                else:
                    if step_param_name in step.params:
                        defval = step.params[step_param_name]
                    elif step_param_name in step.cargo.defaults:
                        defval = step.cargo.defaults[step_param_name]
                    else:
                        defval = schema.default
                    if defval is not UNSET:
                        alias_schema.required = False
                        alias_schema.default = defval
                        ## see https://github.com/caracal-pipeline/stimela/issues/284. No longer convinced
                        ## these parameters should be marked as Hidden. After all, the recipe explicitly specifies them!
                        ## mark it as hidden -- no need to expose parameters that are internally set this way
                        # alias_schema.category = ParameterCategory.Hidden
                # propagate info from recipe schema
                if orig_schema and orig_schema.info:
                    alias_schema.info = orig_schema.info
                # required flag overrides, if set from our own schema
                if orig_schema is not None and orig_schema.required is not None:
                    alias_schema.required = orig_schema.required
                # category is set by argument, else from own schema, else from target
                if category is not None:
                    alias_schema.category = category
                elif orig_schema is not None and orig_schema.category is not None:
                    alias_schema.category = orig_schema.category

            # if step parameter is implicit, mark the alias as implicit. Note that this only applies to outputs
            if schema.implicit:
                alias_schema.implicit = Unresolved(
                    f"{step_label}.{step_param_name}"
                )  # will be resolved when propagated from step
                self._implicit_params.add(alias_name)

            # this is True if the step's parameter is defined in any way (set, default, or implicit)
            have_step_param = (
                step_param_name in step.params
                or step_param_name in step.cargo.defaults
                or alias_schema.default is not UNSET
                or alias_schema.implicit is not None
            )

            # if the step parameter is set and ours isn't, mark our schema as having a default
            if have_step_param and alias_schema.default is UNSET:
                alias_schema.default = DeferredAlias(f"{step_label}.{step_param_name}")

            # alias becomes required if any step parameter it refers to is required and not set, unless
            # the original schema forces a required value
            if schema.required and not have_step_param and (orig_schema is None or orig_schema.required is None):
                alias_schema.required = True

            self._alias_map[step_label, step_param_name] = alias_name, orig_schema
            self._alias_list.setdefault(alias_name, []).append(Recipe.AliasInfo(step_label, step, step_param_name, io))

    def finalize(self, config=None, log=None, name=None, fqname=None, backend=None, nesting=0):
        if not self.finalized:
            config = config or stimela.CONFIG

            backend = OmegaConf.merge(backend or config.opts.backend, self.backend or {})

            # fully qualified name, i.e. recipe_name.step_name.step_name etc.
            self.fqname = fqname = fqname or self.fqname or self.name

            # if logger is not provided, then init one
            if log is None:
                log = stimela.logger().getChild(self.fqname)
                log.propagate = True

            # init and/or update logger options
            self.logopts = config.opts.log.copy()

            # update file logger
            logsubst = SubstitutionNS(config=config, info=dict(fqname=fqname, taskname=fqname))
            stimelogging.update_file_logger(log, self.logopts, nesting=nesting, subst=logsubst, location=[self.fqname])

            # call Cargo's finalize method
            super().finalize(config, log=log, fqname=fqname, nesting=nesting)

            # finalize steps
            for label, step in self.steps.items():
                step_log = log.getChild(label)
                step_log.propagate = False
                try:
                    step.finalize(
                        config, log=step_log, fqname=f"{fqname}.{label}", backend=backend, nesting=nesting + 1
                    )
                    # check that per-step assignments don't clash with i/o parameters
                    step.assign = self.flatten_param_dict(OrderedDict(), step.assign)
                    self.validate_assignments(step.assign, step.assign_based_on, f"{fqname}.{label}")
                except Exception as exc:
                    raise StepValidationError(
                        f"error validating step '{label}'", exc, tb=not isinstance(exc, ScabhaBaseException)
                    )

            # collect aliases
            self._alias_map = OrderedDict()
            self._alias_list = OrderedDict()
            self._orig_alias_schema = OrderedDict()

            # collect from inputs and outputs
            for io in self.inputs, self.outputs:
                for name, schema in io.items():
                    if schema.aliases:
                        ## NB skip this check, allow aliases to override
                        # if schema.dtype != "str" or schema.choices or schema.writable:
                        #     raise RecipeValidationError(
                        #         f"recipe '{self.name}': alias '{name}' should not specify type, choices or "
                        #         f"writability",
                        #         log=log
                        #     )
                        for alias_target in schema.aliases:
                            self._add_alias(name, alias_target)

            # collect from aliases section
            for name, alias_list in self.aliases.items():
                for alias_target in alias_list:
                    self._add_alias(name, alias_target)

            # automatically make aliases for step parameters that are unset, and don't have a default, and aren't
            # implict
            for label, step in self.steps.items():
                for name, schema in step.inputs_outputs.items():
                    # does it have a value set
                    has_value = name in step.params or name in step.cargo.defaults or schema.default is not UNSET
                    if (label, name) not in self._alias_map and not schema.implicit and not has_value:
                        auto_name = f"{label}.{name}"
                        if auto_name in self.inputs or auto_name in self.outputs:
                            raise RecipeValidationError(
                                f"recipe '{self.name}': auto-generated parameter name '{auto_name}' conflicts with "
                                f"another name. Please define an explicit alias for this.",
                                log=log,
                            )
                        self._add_alias(
                            auto_name,
                            (step, label, name),
                            category=ParameterCategory.Required
                            if schema.required and not has_value
                            else ParameterCategory.Obscure,
                        )

            # these will be re-merged when needed again
            self._inputs_outputs = None

            # check that for-loop is valid, if defined
            if self.for_loop is not None:
                # if for_loop.over is a str, treat it as a required input
                if type(self.for_loop.over) is str:
                    if self.for_loop.over not in self.inputs:
                        raise RecipeValidationError(
                            f"recipe '{self.name}': for_loop.over={self.for_loop.over} is not a defined input", log=log
                        )
                    # this becomes a required input
                    self.inputs[self.for_loop.over].required = True
                # else treat it as a list of values to be iterated over (and set over=None to indicate this)
                elif type(self.for_loop.over) in (list, tuple, ListConfig):
                    self._for_loop_values = list(self.for_loop.over)
                    self.for_loop.over = None
                else:
                    raise RecipeValidationError(
                        f"recipe '{self.name}': for_loop.over is of invalid type {type(self.for_loop.over)}", log=log
                    )

                # # insert empty loop variable
                # if self.for_loop.var not in self.assign:
                #     self.assign[self.for_loop.var] = ""

    def _prep_step(self, label, step, subst):
        parts = label.split("-")
        info = subst.info
        info.fqname = f"{self.fqname}.{label}"
        info.label = label
        info.label_parts = parts
        info.suffix = parts[-1] if len(parts) > 1 else ""
        subst.current = step.params
        subst.steps[label] = subst.current

    def _preprocess_parameters(self, params: Dict[str, Any]):
        # split parameters into our own, and per-step, and UNSET directives
        own_params = {}
        unset_params = set()
        for name, value in params.items():
            # if self.for_loop is not None and name == self.for_loop.var:
            #     continue # unset_params.add(name)
            if name in self.inputs_outputs:
                # if value == "UNSET":
                #     unset_params.add(name)
                # elif value == "EMPTY":
                #     own_params[name] = ""
                if value is UNSET:
                    unset_params.add(name)
                else:
                    own_params[name] = value
            elif "." not in name:
                raise ParameterValidationError(f"'{name}' does not refer to a known parameter")
            else:
                label, subname = name.split(".", 1)
                substep = self.steps.get(label)
                if substep is None:
                    raise ParameterValidationError(f"'{name}' does not refer to a known parameter or a step")
                substep.params[subname] = value
        return own_params, unset_params

    def _update_subst_namespace(self, subst: SubstitutionNS):
        """Updates subst namespace at start of prevalidate or run"""
        taskname = subst.get("self", {}).get("taskname") or self.fqname
        info = SubstitutionNS(fqname=self.fqname, taskname=taskname, label="", label_parts=[], suffix="")
        # nosubst=True means these sub-namespaces are not subject to {}-substitutions
        subst._add_("info", info, nosubst=True)
        subst.self = subst.info

        subst._add_("steps", {}, nosubst=True)
        subst._add_("previous", {}, nosubst=True)
        if "recipe" in subst:
            subst._add_("parent", subst.recipe)
        subst._add_("recipe", subst.current)

        subst.recipe.log = self.logopts
        subst.recipe._add_("steps", subst.steps, nosubst=True)

    def prevalidate(self, params: Dict[str, Any], subst: SubstitutionNS, backend=None, root=False):
        self.finalize(backend=backend)
        self.log.debug("prevalidating recipe")
        errors = []

        backend = OmegaConf.merge(backend or self.config.opts.backend, self.backend or {})

        # split parameters into our own, and per-step, and UNSET directives
        params, unset_params = self._preprocess_parameters(params)

        # our own parameters are prevalidated against the outer substitution context;
        # step parameters are prevalidated against our own subst
        subst_outer = subst.copy()
        self._update_subst_namespace(subst)

        # update assignments
        self.update_assignments(subst, params=params, ignore_subst_errors=True, ignore_abo_errors=True)
        # this may have changed the file logger, so update
        stimelogging.update_file_logger(
            self.log, self.logopts, nesting=self.nesting, subst=subst, location=[self.fqname]
        )

        # add for-loop variable to inputs, if expected there
        if self.for_loop is not None and self.for_loop.var in self.inputs:
            params[self.for_loop.var] = Placeholder(self.for_loop.var)

        # prevalidate our own parameters. This substitutes in defaults and does {}-substitutions
        # we call this twice, potentially, so define as a function
        def prevalidate_self(params):
            try:
                params1 = Cargo.prevalidate(self, params, subst=subst_outer, backend=backend)
                # mark params that have become unset
                unset_params.update(set(params) - set(params1))
                params = params1
                # validate for-loop, if needed
                self.validate_for_loop(params, strict=False)

            except ScabhaBaseException as exc:
                errors.append(exc)
            except Exception as exc:
                errors.append(RecipeValidationError("recipe failed prevalidation", exc, tb=True))

            # merge again, since values may have changed
            subst.recipe._merge_(params)
            if root:
                subst.root = subst.recipe
            return params

        params = prevalidate_self(params)

        # propagate alias values up to substeps, except for implicit values (these only ever propagate down to us)
        for name, aliases in self._alias_list.items():
            if name in params and type(params[name]) is not DeferredAlias and name not in self._implicit_params:
                for alias in aliases:
                    alias.from_recipe = True
                    alias.step.update_parameter(alias.param, params[name])
            elif name in unset_params:
                for alias in aliases:
                    alias.from_recipe = True
                    alias.step.unset_parameter(alias.param)

        # prevalidate step parameters
        # we call this twice, potentially, so define as a function

        def prevalidate_steps():
            for label, step in self.steps.items():
                self._prep_step(label, step, subst)
                # update assignments, since substitutions (info.fqname and such) may have changed
                self.update_assignments(subst, params=params, ignore_subst_errors=True, ignore_abo_errors=True)
                # update assignments based on step content
                self.update_assignments(
                    subst, whose=step, params=params, ignore_subst_errors=True, ignore_abo_errors=True
                )

                try:
                    step_params = step.prevalidate(subst.copy())
                    subst._add_("current", step_params)
                except ScabhaBaseException as exc:
                    errors.append(RecipeValidationError(f"step '{label}' failed prevalidation", exc))
                except Exception as exc:
                    errors.append(RecipeValidationError(f"step '{label}' failed prevalidation", exc, tb=True))

                # revert to recipe-level assignments
                self.update_assignments(subst, params=params, ignore_subst_errors=True, ignore_abo_errors=True)
                subst._add_("previous", subst.current, nosubst=True)
                subst.steps._add_(label, subst.previous)
            # restore current from recipe
            subst.current = subst.recipe

        prevalidate_steps()

        # now check for aliases that need to be propagated up/down
        if not errors:
            revalidate_self = revalidate_steps = False
            for name, aliases in self._alias_list.items():
                # propagate up if alias is not set, or it is implicit=Unresolved (meaning it gets set from an implicit
                # substep parameter)
                if (
                    name not in params
                    or type(params[name]) is DeferredAlias
                    or type(self.inputs_outputs[name].implicit) is Unresolved
                ):
                    from_step = False
                    for alias in aliases:
                        # if alias is set in step but not with us, mark it as propagating down
                        if alias.param in alias.step.validated_params:
                            alias.from_step = from_step = revalidate_self = True
                            params[name] = alias.step.validated_params[alias.param]
                            # and break out, we do this for the first matching step only
                            break
                    # if we propagated an input value down from a step, check if we need to propagate it up to any
                    # other steps note that this only ever applies to inputs
                    if from_step:
                        for alias in aliases:
                            if not alias.from_step:
                                alias.from_recipe = revalidate_steps = True
                                alias.step.update_parameter(alias.param, params[name])

            # do we or any steps need to be revalidated?
            if revalidate_self:
                params = prevalidate_self(params)
            if revalidate_steps:
                prevalidate_steps()

        # check for missing parameters
        missing_params = [
            name for name, schema in self.inputs_outputs.items() if schema.required and name not in params
        ]
        if missing_params:
            n = len(missing_params)
            msg = f"""recipe is missing {n} required parameter{"s" if n > 1 else ""}:"""
            errors.append(RecipeValidationError(msg, missing_params))

        if errors:
            if len(errors) == 1:
                raise errors[0]
            else:
                raise RecipeValidationError(f"recipe '{self.name}': {len(errors)} errors", errors)

        self._prevalidated_steps = subst.steps

        self.log.debug("recipe pre-validated")

        return params

    def validate_for_loop(self, params, strict=False):
        # in case of for loops, get list of values to be iterated over
        if self.for_loop is not None:
            # get scatter value
            if "for_loop.scatter" in params:
                scatter = params["for_loop.scatter"]
            elif "for_loop.scatter" in self.assign:
                scatter = self.assign["for_loop.scatter"]
            else:
                scatter = self.for_loop.scatter
            if type(scatter) is bool:
                scatter = -1 if scatter else 0
            elif type(scatter) is not int:
                raise ParameterValidationError(f"for_loop.scattter={scatter}: bool or int expected")
            self._for_loop_scatter = scatter

            # the over list can be in the for_loop clause, or in inputs
            if "for_loop.over" in params:
                values = params["for_loop.over"]
            elif "for_loop.over" in self.assign:
                values = self.assign["for_loop.over"]
            elif self.for_loop.over is not None:
                # check that it's legal
                if self.for_loop.over in self.assign:
                    values = self.assign[self.for_loop.over]
                elif self.for_loop.over in params:
                    values = params[self.for_loop.over]
                elif self.for_loop.over not in self.inputs:
                    raise ParameterValidationError(
                        f"recipe '{self.name}': for_loop.over={self.for_loop.over} does not refer to a known parameter"
                    )
                else:
                    raise ParameterValidationError(f"recipe '{self.name}': for_loop.over={self.for_loop.over} is unset")
                if strict and isinstance(values, Unresolved):
                    raise ParameterValidationError(
                        f"recipe '{self.name}': for_loop.over={self.for_loop.over} is unresolved", [values]
                    )
            else:
                if self._for_loop_values is None:
                    raise ParameterValidationError(f"recipe '{self.name}': for_loop.over is unset")
                values = self._for_loop_values
            # finalize list of values
            if type(values) is ListConfig:
                values = list(values)
            elif not isinstance(values, (list, tuple)):
                values = [values]
            if self._for_loop_values is None:
                self.log.debug(f"recipe is a for-loop with '{self.for_loop.var}' iterating over {len(values)} values")
                self.log.debug(f"loop values: {values}")
            self._for_loop_values = values
            # validate output_elements names against declared outputs
            if self.for_loop.output_elements:
                for elem_name in self.for_loop.output_elements:
                    if elem_name not in self.outputs:
                        raise ParameterValidationError(
                            f"recipe '{self.name}': for_loop.output_elements.{elem_name} "
                            f"does not correspond to a declared output"
                        )
                    elif get_origin(self.outputs[elem_name]._dtype) is not list:
                        raise ParameterValidationError(
                            f"recipe '{self.name}': for_loop.output_elements.{elem_name} "
                            f"has dtype '{self.outputs[elem_name].dtype}', expected a List type"
                        )
        # else fake a single-value list
        else:
            self._for_loop_values = [None]

    def validate_inputs(self, params: Dict[str, Any], subst: SubstitutionNS, loosely=False, remote_fs=False):
        params, _ = self._preprocess_parameters(params)

        if "current" in subst:
            subst.current._add_("steps", self._prevalidated_steps, nosubst=True)

        self.update_assignments(subst, params=params, ignore_subst_errors=True)

        params = Cargo.validate_inputs(self, params, subst=subst, loosely=loosely, remote_fs=remote_fs)

        self.validate_for_loop(params, strict=True)

        return params

    def summary(self, params: Dict[str, Any], recursive=True, ignore_missing=False):
        """Returns list of lines with a summary of the recipe state"""
        lines = [f"recipe '{self.name}':"] + Cargo.add_parameter_summary(params)
        if not ignore_missing:
            lines += [f"  {name} = ???" for name in self.inputs_outputs if name not in params]
        if recursive:
            lines.append("  steps:")
            for name, step in self.steps.items():
                stepsum = step.summary()
                lines.append(f"    {name}: {stepsum[0]}")
                lines += [f"    {x}" for x in stepsum[1:]]
        return lines

    _root_recipe_ns = None

    def rich_help(self, tree, max_category=ParameterCategory.Optional):
        Cargo.rich_help(self, tree, max_category=max_category)
        if self.for_loop:
            loop_tree = tree.add("For loop:")
            if self._for_loop_values is not None:
                over = f"{len(self._for_loop_values)} values"
            else:
                over = f"[bold]{self.for_loop.over}[/bold]"
            loop_tree.add(f"iterating [bold]{self.for_loop.var}[/bold] over {over}")
        if self.steps:
            have_skips = any(step._skip for step in self.steps.values())
            steps_tree = tree.add(
                "Steps (note [italic]some steps[/italic] are skipped by default):" if have_skips else "Steps:"
            )
            table = rich.table.Table.grid(
                "", "", "", padding=(0, 2)
            )  # , show_header=False, show_lines=False, box=rich.box.SIMPLE)
            steps_tree.add(table)
            for label, step in self.steps.items():
                style = "italic" if step._skip else "bold"
                table.add_row(f"[{style}]{label}[/{style}]", step.info)
                if step.tags:
                    table.add_row("", f"[italic](tags: {', '.join(step.tags)})[/italic]")
        else:
            steps_tree = tree.add("No recipe steps defined")

    def _update_aliases(self, name: str, value: Any):
        """Propagates recipe aliases up top parameters

        Args:
            name (str): name of recipe parameter
            value (Any): value
        """
        for alias in self._alias_list.get(name, []):
            if alias.from_recipe:
                alias.step.update_parameter(alias.param, value)

    def _iterate_loop_worker(self, params, subst, backend_settings, count, iter_var, subprocess=False, raise_exc=True):
        """ "
        Needed for concurrency
        """
        if subprocess:
            task_stats.add_subprocess_id(count)
            # When running in a processpool, gather log messages in a string
            # which can be returned to the parent process.
            rich_console.file = StringIO()
        subst.info.subprocess = task_stats.get_subprocess_id()
        taskname = subst.info.taskname
        outputs = {}
        output_elements = {}
        exception = tb = None
        task_attrs, task_kwattrs = (), {}
        try:
            # if for-loop, assign new value
            if self.for_loop:
                self.log.info(f"for loop iteration {count}: {self.for_loop.var} = {iter_var}")
                if self.for_loop.var in self.inputs_outputs:
                    params[self.for_loop.var] = iter_var
                else:
                    self.assign[self.for_loop.var] = iter_var
                # update variable index
                self.assign[f"{self.for_loop.var}@index"] = count
                # update alias
                self._update_aliases(self.for_loop.var, iter_var)
                # update status display
                status = None
                status_dict = dict(
                    index0=count,
                    index1=count + 1,
                    total=len(self._for_loop_values),
                    var=self.for_loop.var,
                    value=iter_var,
                )
                if self.for_loop.display_status:
                    try:
                        status = self.for_loop.display_status.format(**status_dict)
                    except Exception as exc:
                        self.log.warning(
                            f"error formatting for-loop status: {exc}, falling back on default status display"
                        )
                if status is None:
                    status = "{index1}/{total}".format(**status_dict)
                task_stats.declare_subtask_status(status)
                taskname = f"{taskname}.{count}"
                subst.info.taskname = taskname
                # task_stats.declare_subtask_attributes(count)
                # task_attrs = (count,)
                # NOTE(JSKenyon): This uses the default dummy_reporter i.e. won't update stats.
                context = task_stats.declare_subtask(f"({count})")
            else:
                from contextlib import nullcontext

                context = nullcontext()
            with context:
                for label, step in self.steps.items():
                    # update step info
                    self._prep_step(label, step, subst)
                    subst.info.taskname = f"{taskname}.{label}"
                    # reevaluate recipe level assignments (info.fqname etc. have changed)
                    self.update_assignments(subst, params=params)
                    # evaluate step-level assignments
                    self.update_assignments(subst, whose=step, params=params)
                    # step logger may have changed
                    stimelogging.update_file_logger(
                        step.log, step.logopts, nesting=step.nesting, subst=subst, location=[step.fqname]
                    )
                    # set our info back temporarily to update log assignments

                    ## OMS: note to self, I had this here but not sure why. Seems like a no-op. Something with logname
                    ## fiddling.
                    ## Leave as a puzzle to future self for a bit. Remove info from args.
                    # info_step = subst.info
                    # subst.info = info.copy()
                    # subst.info = info_step

                    if step.skip is True:
                        self.log.debug(f"step '{label}' will be explicitly skipped")
                    else:
                        self.log.info(f"processing step '{label}'")
                        if step.info:
                            self.log.info(f"  ({step.info})", extra=dict(color="GREEN", boldface=True))
                    try:
                        # make a copy of the subst dict since subrecipes may modify
                        step_params = step.run(backend=backend_settings, subst=subst.copy(), parent_log=self.log)
                    except ScabhaBaseException as exc:
                        newexc = StimelaStepExecutionError(f"step '{step.fqname}' has failed, aborting the recipe", exc)
                        if not exc.logged:
                            log_exception(newexc, log=step.log)
                        raise newexc

                    # put step parameters into previous and steps[label] again, as they may have changed based on
                    # outputs)
                    subst._add_("previous", step_params, nosubst=True)
                    subst.steps._add_(label, subst.previous, nosubst=True)
                    # revert to recipe level assignments

                    # now check for output aliases that need to be propagated down from steps
                    self.update_assignments(subst, whose=self, params=params)
                    for name, aliases in self._alias_list.items():
                        for alias in aliases:
                            if alias.from_step and alias.step is step:
                                # if step was skipped, mark output as not required
                                if alias.step._skip:
                                    self.outputs[name].required = False
                                # if step output is validated, add it to our output
                                # if alias.param in alias.step.validated_params:
                                #     outputs[name] = alias.step.validated_params[alias.param]
                                if alias.param in step_params:
                                    outputs[name] = step_params[alias.param]

                # evaluate output_elements expressions for this iteration
                output_elements = {}
                if self.for_loop and self.for_loop.output_elements:
                    for elem_name, expr in self.for_loop.output_elements.items():
                        value = evaluate_and_substitute_object(
                            expr,
                            subst,
                            recursion_level=-1,
                            location=[self.fqname, "for_loop", "output_elements", elem_name],
                            log=self.log,
                        )
                        output_elements[elem_name] = value

        except Exception as exc:
            # raise exception up if asked to
            if raise_exc:
                raise
            # else will be returned
            exception = exc
            tb = FormattedTraceback(sys.exc_info()[2])
        finally:
            if subprocess:
                subprocess_logs = rich_console.file.getvalue()
            else:
                subprocess_logs = None

        return (
            task_attrs,
            task_kwattrs,
            task_stats.collect_stats(),
            outputs,
            exception,
            tb,
            subprocess_logs,
            count,
            output_elements,
        )

    def build(self, backend={}, rebuild=False, build_skips=False, log: Optional[logging.Logger] = None):
        # set up backend
        backend = OmegaConf.merge(backend, self.backend or {})
        # build recursively
        log = log or self.log
        log.info(f"building image(s) for recipe '{self.fqname}'")
        for step in self.steps.values():
            step.build(backend, rebuild=rebuild, build_skips=build_skips, log=log)

    def _run(self, params: Dict[str, Any], subst: SubstitutionNS, backend: Dict = {}) -> Dict[str, Any]:
        """Internal method for running a recipe. Meant to be called from the containing step.

        Args:
            params (Dict[str, Any]): input parameters
            subst (SubstitutionNS): Substitution namespace.
            backend (Dict, optional): Extra backend settings from parent. Defaults to {}.

        Returns:
            Dict[str, Any]: Dictionary of outputs
        """
        # set up backend
        backend = OmegaConf.merge(backend, self.backend or {})

        # set up substitution namespace
        self._update_subst_namespace(subst)

        self.update_assignments(subst, params=params, ignore_subst_errors=True)

        # init backends if not already done
        if not backends.initialized:
            try:
                backend_opts = OmegaConf.merge(stimela.CONFIG.opts.backend, backend)
                backend_opts = evaluate_and_substitute_object(
                    backend_opts, subst, recursion_level=-1, location=[self.fqname, "backend"], log=self.log
                )
                if getattr(backend_opts, "verbose", 0):
                    opts_yaml = OmegaConf.to_yaml(backend_opts)
                    log_rich_payload(self.log, "initial backend settings are", opts_yaml, syntax="yaml")
                backend_opts = OmegaConf.to_object(OmegaConf.merge(StimelaBackendSchema, backend_opts))
            except Exception as exc:
                newexc = BackendError("error validating backend settings", exc)
                raise newexc from None

            stimela.backends.init_backends(backend_opts, stimela.logger())

        self.log.info(f"running recipe '{self.name}'")

        # our inputs have been validated, so propagate aliases to steps. Check for missing stuff just in case
        for name, schema in self.inputs.items():
            if name in params:
                value = params[name]
                if isinstance(value, Unresolved) and not isinstance(value, Placeholder):
                    raise RecipeValidationError(f"recipe '{self.name}' has unresolved input '{name}'", log=self.log)
                self._update_aliases(name, value)
            elif schema.required and (self.for_loop is None or name != self.for_loop.var):
                raise RecipeValidationError(f"recipe '{self.name}' is missing required input '{name}'", log=self.log)

        # form list of arguments for each invocation of the loop worker
        loop_worker_args = []
        for count, iter_var in enumerate(self._for_loop_values):
            # pass in a copy of subst and subst.info+self, since they mutate in the iteration
            subst_copy = subst.copy()
            subst_copy.info = subst.info.copy()
            subst_copy.self = subst_copy.info
            loop_worker_args.append((params, subst_copy, backend, count, iter_var))

        final_iter_outputs = {}
        nloop = len(loop_worker_args)

        # skip the trivial case
        if not nloop:
            self.log.info("this recipe is an empty for-loop: time for masterful inactivity")
        # if scatter is enabled, use a process pool
        elif self._for_loop_scatter:
            self.log.info(
                f"[yellow]Scattering recipe {self.fqname} - terminal logs "
                f"will appear on the completion of a scattered step. Log "
                f"files will be updated in real time.[/yellow]"
            )

            accumulated_elements = (
                {name: [None] * nloop for name in self.for_loop.output_elements}
                if self.for_loop and self.for_loop.output_elements
                else {}
            )
            if self._for_loop_scatter < 0:
                num_workers = nloop
            else:
                num_workers = min(self._for_loop_scatter, nloop)

            # NOTE(JSKenyon): We don't actually have the runner at this point so dynamically
            # changing the display based on the backend is problematic. The loop being run may
            # also use different backends for each step. However, in most cases a scattered
            # loop will be either remote (kube, slurm) or local, and not a mixture of the two.
            # This chooses the display based on the backend config at the recipe level - step
            # level overrides are ignored.
            backend_opts = OmegaConf.merge(stimela.CONFIG.opts.backend, backend)
            backend_opts = OmegaConf.to_object(backend_opts)
            # TODO(JSKenyon): For now, we default to a minimal display (e.g. the slurm display)
            # for the kube backend when scattering. This is consistent with the behaviour prior
            # to the addition of multiple displays. At present, the status reporter for the kube
            # backend is not configured at this point so we cannot track all the pods running
            # in the scattered loop.
            display_style = backend_opts.current_wrapper or backend_opts.current_backend
            # As noted above, use simpler slurm display when scattering with kube backend.
            display_style = "slurm" if display_style == "kube" else display_style

            # If the display is disabled at this point, it implies that we
            # should leave it that way (may be in a child process).
            pause_display = display.is_enabled
            # Disable display during pool creation so that it isn't
            # enabled in the resulting processes.
            if pause_display:
                display.disable(reset_cursor=True)
            with ProcessPoolExecutor(num_workers) as pool:
                # submit each iterant to pool
                futures = []
                for args in loop_worker_args:
                    future = pool.submit(self._iterate_loop_worker, *args, subprocess=True, raise_exc=False)
                    futures.append(future)

                # Re-enable display after pool creation.
                if pause_display:
                    display.set_display_style(display_style)
                    display.enable()
                # Set status on scatter subtask once display is re-enabled.
                task_stats.declare_subtask_status(f"0/{nloop} complete, {num_workers} workers")

                # Start a thread to monitor resource usage.
                monitor = task_stats.MonitorThread()
                monitor.start()

                # update task stats, since they're recorded independently
                # within each step, as well as get any exceptions from the
                # nested steps/recipes.
                errors = []
                nfail = ncomplete = 0
                for f in as_completed(futures):
                    attrs, kwattrs, stats, outputs, exc, tb, subprocess_logs, iter_count, iter_elements = f.result()
                    # save outputs from final iteration
                    if iter_count == nloop - 1:
                        final_iter_outputs = outputs
                    # Print the logs associated with the completed future.
                    # These are already timestamped by the child process.
                    rich_console.print(subprocess_logs, soft_wrap=True)
                    task_stats.declare_subtask_attributes(*attrs, **kwattrs)
                    task_stats.add_missing_stats(stats)
                    if exc is not None:
                        errors.append(exc)
                        if not isinstance(exc, ScabhaBaseException):
                            errors.append(tb)
                        nfail += 1
                    else:
                        ncomplete += 1
                        for name, value in iter_elements.items():
                            accumulated_elements[name][iter_count] = value
                    if ncomplete:
                        status = f"[green]{ncomplete}[/green]/{nloop} complete"
                    else:
                        status = f"0/{nloop} complete"
                    if nfail:
                        status = f"{status}, [red]{nfail}[/red] failed"
                    status = f"{status}, {num_workers} workers"
                    task_stats.declare_subtask_status(status)

                monitor.stop()  # Stop monitoring resource usage.

                if errors:
                    pool.shutdown()
                    raise StimelaRuntimeError(f"{nfail}/{nloop} jobs have failed", errors)
        # else just iterate directly
        else:
            accumulated_elements = (
                {name: [] for name in self.for_loop.output_elements}
                if self.for_loop and self.for_loop.output_elements
                else {}
            )
            for args in loop_worker_args:
                _, _, _, final_iter_outputs, _, _, _, _count, iter_elements = self._iterate_loop_worker(
                    *args, raise_exc=True
                )
                for name, value in iter_elements.items():
                    accumulated_elements[name].append(value)

        # either way, outputs contains output aliases from the last iteration
        params.update(**final_iter_outputs)
        if accumulated_elements:
            params.update(**accumulated_elements)

        # current namespace becomes recipe again
        subst.current = subst.recipe

        self.log.info(f"recipe '{self.name}' executed successfully")
        return OrderedDict((name, value) for name, value in params.items() if name in self.outputs)

    def to_dag(self, graph: Optional[nx.DiGraph] = None, parent: Optional[str] = None) -> nx.DiGraph:
        """Converts a stimela recipe into a simple directed acyclic graph.

        Uses networkx to convert a (possibly) nested recipe into a directed
        acyclic graph where node are recipes steps, and each step has its tags
        stored as node attributes. The output of this function can be used to
        reason about overall flow control.

        Args:
            graph:
                Parent graph. Implementation detail for recursion.
            parent:
                Parent node to connect children to. Implentation detail for
                recursion.

        Returns:
            A networkx.DiGraph representing the recipe.
        """

        # Here, root is a just a graph attribute we set for convenience.
        graph = graph or nx.DiGraph(root=self.fqname)

        if parent is None:  # Implies outermost level.
            graph.add_node(self.fqname)  # Add the recipe as a root node.
            parent = self.fqname

        for step_name, step in self.steps.items():
            tags = tuple(getattr(step, "tags", []))

            # Use verbose keys as we cannot guarantee uniqueness between
            # subrecipes.
            node_name = ".".join((self.fqname, step_name))
            graph.add_node(node_name, tags=tags)
            graph.add_edge(parent, node_name)

            if isinstance(step.cargo, Recipe):
                graph = step.cargo.to_dag(graph=graph, parent=node_name)

        return graph


StepSchema = OmegaConf.structured(Step)
RecipeSchema = OmegaConf.structured(Recipe)
