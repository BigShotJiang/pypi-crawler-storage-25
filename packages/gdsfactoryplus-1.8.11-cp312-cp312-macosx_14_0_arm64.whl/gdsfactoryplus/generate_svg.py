"""Generate SVG from cell."""

from __future__ import annotations

from collections.abc import Iterable
from functools import cache, partial
from inspect import signature
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    import gdsfactory as gf
    import shapely.geometry as sg

    from gdsfactoryplus.core.pdk import get_pdk
else:
    from gdsfactoryplus.core.lazy import lazy_import

    get_pdk = lazy_import("gdsfactoryplus.core.pdk", "get_pdk")
    gf = lazy_import("gdsfactory")
    sg = lazy_import("shapely.geometry")

__all__ = ["get_svg", "generate_svg", "generate_multipolygon"]


def generate_svg(
    comp: gf.Component,
    width: int,
    height: int,
    theme: str = "dark",
) -> str:
    """Generate the svg for a cell."""
    mp = generate_multipolygon(comp)
    polygons = _multipolygon_to_coords(mp)
    from gdsfactoryplus.gdsfactoryplus import generate_svg_from_polygons

    return generate_svg_from_polygons(polygons, width, height, theme)


@cache
def get_svg(
    comp: gf.Component,
    width: int,
    height: int,
    theme: str = "dark",
) -> str:
    """Get the (possible cached) svg for a cell."""
    return generate_svg(comp, width, height, theme)


def generate_multipolygon(
    comp: gf.Component,
) -> sg.MultiPolygon:
    """Generate a MultiPolygon from a component."""
    polys_dict = comp.get_polygons_points(by="tuple")
    layer = _get_main_pdk_layer()
    poly_arrays = polys_dict.get(layer, [])
    mp = sg.MultiPolygon([sg.Polygon(p) for p in poly_arrays]).buffer(0.01)
    if isinstance(mp, sg.Polygon):
        mp = sg.MultiPolygon([mp])
    return mp


def _multipolygon_to_coords(
    mp: sg.MultiPolygon,
) -> list[list[list[list[float]]]]:
    """Extract coordinate arrays from a Shapely MultiPolygon.

    Returns a list of polygons, each polygon is a list of rings (exterior + holes),
    each ring is a list of [x, y] coordinate pairs.
    """
    polygons = []
    for poly in mp.geoms:
        if not isinstance(poly, sg.Polygon):
            continue
        rings = []
        boundary = poly.boundary
        if isinstance(boundary, sg.MultiLineString):
            rings.extend([list(coord) for coord in ls.coords] for ls in boundary.geoms)
        else:
            rings.append([list(coord) for coord in boundary.coords])  # type: ignore[union-attr]
        polygons.append(rings)
    return polygons


@cache
def _get_main_pdk_layer() -> tuple[int, int]:
    pdk = get_pdk()
    layers = {str(l).upper(): tuple(l) for l in (cast(Iterable, pdk.layers) or {})}
    layer = _get_main_cross_section_layer(pdk)
    if isinstance(layer, tuple):
        return layer[:2]
    layer = layers.get(str(layer).upper())
    if layer is not None:
        return layer
    layers_sel = {k: v for k, v in layers.items() if k.endswith("WG")}
    if layers_sel:
        return next(iter(layers_sel.values()))
    layers_sel = {k: v for k, v in layers.items() if "WG" in k}
    if layers_sel:
        return next(iter(layers_sel.values()))
    return (1, 0)


def _get_main_cross_section_layer(pdk: gf.Pdk) -> Any:
    cross_section = _get_main_cross_section(pdk)
    if cross_section is None:
        return None
    for section in cross_section.sections:
        if section.layer is None:
            continue
        return section.layer
    return None


def _get_main_cross_section(pdk: gf.Pdk) -> gf.CrossSection | None:
    cross_section_name = _get_main_cross_section_name(pdk)
    if not cross_section_name:
        return None
    return pdk.get_cross_section(cross_section_name)


def _get_main_cross_section_name(pdk: gf.Pdk) -> str:
    routing_strategies = pdk.routing_strategies or {}
    if not routing_strategies:
        return next(iter(pdk.cross_sections))
    if "route_bundle" not in routing_strategies:
        route_bundle = next(iter(routing_strategies.values()))
    else:
        route_bundle = routing_strategies["route_bundle"]
    if not isinstance(route_bundle, partial):
        sig = signature(route_bundle)
        param = sig.parameters.get("cross_section", None)
        if param is None:
            return ""
        if isinstance(param.default, param.empty):
            return ""
        return param.default
    return route_bundle.keywords.get("cross_section", "")
