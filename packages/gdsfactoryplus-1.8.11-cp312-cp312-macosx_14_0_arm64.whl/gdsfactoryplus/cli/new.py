"""Create a new GDSFactory+ project."""

from __future__ import annotations

from typing import Annotated

import typer

from .app import app

__all__ = ["new"]


@app.command()
def new(
    path: Annotated[str, typer.Argument(help="Destination directory (must not exist)")],
    name: Annotated[
        str, typer.Option(help="Project name (also used as Python package name)")
    ],
    pdk: Annotated[
        str, typer.Option(help="PDK pip-install name (added to dependencies)")
    ],
    pdk_import: Annotated[
        str, typer.Option(help="PDK import path (e.g. cspdk.si220.cband)")
    ],
    version: Annotated[str, typer.Option(help="Initial version")] = "0.0.0",
    description: Annotated[
        str, typer.Option(help="Short project description")
    ] = "A GDSFactory+ project.",
    pdk_version: Annotated[
        str | None, typer.Option(help="Optional pinned PDK version")
    ] = None,
    license_kind: Annotated[
        str,
        typer.Option(
            "--license",
            help="License: proprietary, mit, apache-2.0, or bsd-3-clause",
        ),
    ] = "proprietary",
    author: Annotated[str | None, typer.Option(help="Author name")] = None,
    author_email: Annotated[str | None, typer.Option(help="Author email")] = None,
    *,
    no_git: Annotated[
        bool, typer.Option("--no-git", help="Skip git init + initial commit")
    ] = False,
) -> None:
    """Create a new GDSFactory+ project from the built-in template."""
    from gdsfactoryplus.gdsfactoryplus import new as rust_new

    rust_new(
        path=path,
        name=name,
        pdk=pdk,
        pdk_import=pdk_import,
        version=version,
        description=description,
        pdk_version=pdk_version,
        license_kind=license_kind,
        author=author,
        author_email=author_email,
        no_git=no_git,
    )
