"""GDSFactory+ CLI app."""

from __future__ import annotations

import platform
import sys

import typer

app = typer.Typer()

if sys.platform == "darwin" and platform.machine() == "x86_64":
    sys.stderr.write(
        "Error: GDSFactory+ does not support Intel-based Macs.\n"
        "Our simulations rely on JAX, which no longer distributes wheels "
        "for Intel Macs.\n"
        "Please use an Apple Silicon Mac, a Linux machine, or "
        "GDSFactory Cloud (https://gdsfactory.com/).\n"
    )
    raise SystemExit(1)

__all__ = ["app"]
