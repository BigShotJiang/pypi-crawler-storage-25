"""Extract layer stack as json."""

import json
from enum import Enum
from pathlib import Path
from typing import cast

import gdsfactory as gf

from gdsfactoryplus import settings
from gdsfactoryplus.core.pdk import get_pdk

_LayerMap = dict[str | int, list[int]]


def get_layer_stack() -> Path:
    """Get the layerstack JSON file for the active PDK, generating if needed.

    Returns:
        Path to the layerstack JSON file.
    """
    build_dir = settings.get_build_dir()
    pdk_name = settings.get_pdk_name()
    ls_path = build_dir / "layerstack" / f"{pdk_name}.json"
    if ls_path.is_file():
        return ls_path
    pdk = get_pdk()
    if pdk.layer_stack is None or pdk.layers is None:
        return ls_path
    layout = gf.Component().kcl.layout
    name_map: dict[str, list[int]] = {}
    idx_map: dict[int, list[int]] = {}
    layers = cast(type[Enum], pdk.layers)
    for member in layers:
        info = layout.get_info(member.value)
        pair = [info.layer, info.datatype]
        name_map[member.name] = pair
        idx_map[member.value] = pair
    combined_map: dict[str | int, list[int]] = {**name_map, **idx_map}
    d = _fix_layerstack_layers(pdk.layer_stack.model_dump(), combined_map)
    ls_path.parent.mkdir(parents=True, exist_ok=True)
    ls_path.write_text(json.dumps(d, indent=2))
    return ls_path


def _fix_layerstack_layers(obj: object, layer_map: _LayerMap) -> object:
    """Recursively replace KLayout layer names/indices with [layer, datatype] tuples."""
    if isinstance(obj, dict):
        return {
            k: (
                _fix_layerstack_layer_value(v, layer_map)
                if k == "layer" and not isinstance(v, dict)
                else _fix_layerstack_layers(v, layer_map)
            )
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_fix_layerstack_layers(item, layer_map) for item in obj]
    return obj


def _fix_layerstack_layer_value(value: object, layer_map: _LayerMap) -> object:
    """Convert a KLayout layer index or name to [layer, datatype]."""
    if isinstance(value, (int, str)):
        fallback = [value, 0] if isinstance(value, int) else value
        return layer_map.get(value, fallback)
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return list(value)
    return value
