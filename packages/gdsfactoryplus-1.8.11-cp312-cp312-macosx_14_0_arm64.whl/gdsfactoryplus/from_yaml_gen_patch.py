"""Patch for gdsfactory's from_yaml_gen._generate_placement_code.

The upstream function generates `inst.mirror()` calls which use kfactory's
`imirror()` (geometric reflection around a line).  However, `from_yaml.py`
(the component builder) uses `dcplx_trans *= DCplxTrans(1, 0, True, 0, 0)`
or `dmirror_x(x)`, which produce different transforms.

This patch replaces `_generate_placement_code` so the generated Python code
matches `from_yaml`'s behaviour.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gdsfactory.schematic import Placement

__all__ = ["apply_from_yaml_gen_patch"]


def _format_value(value: object) -> str:
    """Re-export the upstream helper (avoids copying it)."""
    from gdsfactory.read.from_yaml_gen import _format_value as _fv

    return _fv(value)


def _get_anchor_point_code(inst_name: str, anchor: str) -> str:
    from gdsfactory.read.from_yaml_gen import _get_anchor_point_code as _fn

    return _fn(inst_name, anchor)


def _get_anchor_value_code(inst_name: str, anchor: str, coord: str) -> str:
    from gdsfactory.read.from_yaml_gen import _get_anchor_value_code as _fn

    return _fn(inst_name, anchor, coord)


def _generate_position_code(value: str | float, coord: str) -> str:
    from gdsfactory.read.from_yaml_gen import _generate_position_code as _fn

    return _fn(value, coord)


def _generate_rotation_code(inst_name: str, placement: Placement) -> list[str]:
    """Generate rotation code lines."""
    if not placement.rotation or placement.rotation == 0:
        return []
    if placement.port:
        center_code = _get_anchor_point_code(inst_name, placement.port)
        return [f"    {inst_name}.rotate({placement.rotation}, center={center_code})"]
    return [f"    {inst_name}.rotate({placement.rotation})"]


def _generate_mirror_code(inst_name: str, placement: Placement) -> list[str]:
    """Generate mirror code lines matching from_yaml.py behaviour."""
    if not placement.mirror:
        return []
    if placement.mirror is True:
        if placement.port:
            ax = _get_anchor_value_code(inst_name, placement.port, "x")
            return [f"    {inst_name}.dmirror_x(x={ax})"]
        return [f"    {inst_name}.mirror_y()"]
    if isinstance(placement.mirror, str):
        port_x = f"{inst_name}.ports[{_format_value(placement.mirror)}].x"
        return [f"    {inst_name}.dmirror_x({port_x})"]
    return [f"    {inst_name}.dmirror_x(x={inst_name}.x)"]


def _generate_move_code(  # noqa: C901
    inst_name: str, placement: Placement
) -> list[str]:
    """Generate position/move code lines."""
    lines: list[str] = []
    x_parts: list[str] = []
    y_parts: list[str] = []

    if placement.port:
        anchor_code = _get_anchor_point_code(inst_name, placement.port)
        x_parts.append(f"-{anchor_code}[0]")
        y_parts.append(f"-{anchor_code}[1]")

    if placement.x is not None:
        x_parts.append(_generate_position_code(placement.x, "x"))
    elif placement.xmin is not None:
        lines.append(
            f"    _target_xmin = {_generate_position_code(placement.xmin, 'x')}"
        )
        lines.append(f"    _x_offset = _target_xmin - {inst_name}.xmin")
        x_parts.append("_x_offset")
    elif placement.xmax is not None:
        lines.append(
            f"    _target_xmax = {_generate_position_code(placement.xmax, 'x')}"
        )
        lines.append(f"    _x_offset = _target_xmax - {inst_name}.xmax")
        x_parts.append("_x_offset")

    if placement.y is not None:
        y_parts.append(_generate_position_code(placement.y, "y"))
    elif placement.ymin is not None:
        lines.append(
            f"    _target_ymin = {_generate_position_code(placement.ymin, 'y')}"
        )
        lines.append(f"    _y_offset = _target_ymin - {inst_name}.ymin")
        y_parts.append("_y_offset")
    elif placement.ymax is not None:
        lines.append(
            f"    _target_ymax = {_generate_position_code(placement.ymax, 'y')}"
        )
        lines.append(f"    _y_offset = _target_ymax - {inst_name}.ymax")
        y_parts.append("_y_offset")

    if placement.dx is not None:
        x_parts.append(str(placement.dx))
    if placement.dy is not None:
        y_parts.append(str(placement.dy))

    if x_parts or y_parts:
        x_expr = " + ".join(x_parts) if x_parts else "0"
        y_expr = " + ".join(y_parts) if y_parts else "0"
        lines.append(f"    {inst_name}.move(({x_expr}, {y_expr}))")

    return lines


def _generate_placement_code(inst_name: str, placement: Placement) -> list[str]:
    """Generate placement code that matches from_yaml.py behaviour."""
    lines: list[str] = []
    lines.extend(_generate_rotation_code(inst_name, placement))
    lines.extend(_generate_mirror_code(inst_name, placement))
    lines.extend(_generate_move_code(inst_name, placement))
    return lines


def apply_from_yaml_gen_patch() -> None:
    """Monkey-patch gdsfactory's from_yaml_gen module."""
    import gdsfactory.read.from_yaml_gen as mod

    mod._generate_placement_code = _generate_placement_code  # type: ignore[attr-defined]  # noqa: SLF001
