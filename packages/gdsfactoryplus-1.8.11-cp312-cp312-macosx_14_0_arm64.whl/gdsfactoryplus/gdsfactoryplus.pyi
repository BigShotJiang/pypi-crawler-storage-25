# ruff: noqa: PYI021, D415

import builtins
import typing

def generate_call_graph(
    lib_paths: dict,
    function_filter: builtins.str | None = None,
    select_path: builtins.str | None = None,
) -> typing.Any:
    r"""Generate a call graph for Python libraries"""

def generate_svg_from_polygons(
    polygons: typing.Sequence[
        typing.Sequence[typing.Sequence[typing.Sequence[builtins.float]]]
    ],
    width: builtins.int = 80,
    height: builtins.int = 80,
    theme: builtins.str = "dark",
    simplify_eps: builtins.float = 0.05,
    bbox_padding: builtins.float = 1.0,
) -> builtins.str:
    r"""Generate SVG from polygon coordinates

    Takes polygon coordinates extracted from Shapely geometry and produces
    a complete SVG string with the specified theme and dimensions.

    # Arguments
    * `polygons` - List of polygons, each polygon is a list of rings, each ring is a list of [x, y] points
    * `width` - SVG width in pixels (default: 80)
    * `height` - SVG height in pixels (default: 80)
    * `theme` - "dark" or "light" (default: "dark")
    * `simplify_eps` - RDP simplification epsilon (default: 0.05)
    * `bbox_padding` - Padding around the bounding box (default: 1.0)
    """

def get_settings() -> dict[str, typing.Any]:
    r"""Get the merged settings from all sources"""

def get_ws_port() -> builtins.int | None:
    r"""Get the websocket port

    Returns the port set via `set_ws_port()`, or `None` if not set.
    """

def new(
    path: builtins.str,
    name: builtins.str,
    pdk: builtins.str,
    pdk_import: builtins.str,
    version: builtins.str = "0.0.0",
    description: builtins.str = "A GDSFactory+ project.",
    pdk_version: builtins.str | None = None,
    license_kind: builtins.str = "proprietary",
    author: builtins.str | None = None,
    author_email: builtins.str | None = None,
    no_git: builtins.bool = False,
) -> None:
    r"""Create a new `GDSFactory`+ project from the built-in template

    # Arguments
    * `path` - Destination directory (must not exist)
    * `name` - Project name (also used as the Python package/import name)
    * `pdk` - PDK pip-install name (added to dependencies)
    * `pdk_import` - PDK import path (e.g. `cspdk.si220.cband`)
    * `version` - Initial version (PEP440)
    * `description` - Short description for README tagline + package docstring
    * `pdk_version` - Optional pinned PDK version (e.g. `0.9.0`)
    * `license_kind` - One of "proprietary", "mit", "apache-2.0", "bsd-3-clause"
    * `author` - Author name (LICENSE + pyproject.toml)
    * `author_email` - Author email (pyproject.toml)
    * `no_git` - Skip `git init` + initial commit
    """

def ping_server() -> builtins.bool | None:
    r"""Ping the `VSCode` WebSocket server to check if it's alive

    Sends a ping message and waits for a pong response.
    Returns `None` if no websocket port is configured (health checks disabled).
    Returns `True` if the server responds, `False` otherwise.
    """

def send_log_message(
    level: builtins.str, message: builtins.str, source: builtins.str = "python"
) -> None:
    r"""Send a log message to `VSCode` via WebSocket

    Convenience function to send a log message with the correct schema.

    # Arguments
    * `level` - Log level: "debug", "info", "warning", or "error"
    * `message` - The log message
    * `source` - Source identifier (default: "python")
    """

def send_message(message_json: builtins.str) -> None:
    r"""Send a JSON message to `VSCode` via WebSocket

    This function will silently ignore errors and implement a cooldown period
    to avoid spamming failed connection attempts.
    """

def serve(
    port: builtins.int = 8787,
    host: builtins.str = "127.0.0.1",
    workers: builtins.int = 1,
    reload: builtins.bool = False,
    ws_port: builtins.int | None = None,
) -> builtins.int:
    r"""Start the `GDSFactory+` background service

    This function starts a uvicorn server to serve the `GDSFactory+` API.
    It spawns the server process and exits with its exit code.

    # Arguments
    * `port` - Port on which to run the service (default: 8787)
    * `host` - Host on which to run the service (default: "127.0.0.1")
    * `workers` - Number of workers (0 = number of CPUs, default: 1)
    * `reload` - Run in reload mode for development (default: false)
    * `ws_port` - WebSocket port for communication with `VSCode` extension (default: None)
    """

def set_ws_port(port: builtins.int | None) -> None:
    r"""Set the websocket port (from CLI --ws-port argument)"""

def watch(
    server_port: builtins.int = 8787, ws_port: builtins.int | None = None
) -> None:
    r"""Watch for file changes in the current project

    This function will block and watch for file changes in the `GDSFactory+` project.
    It automatically finds the project root, reads configuration from settings,
    and notifies the `GDSFactory+` server when files change.

    The watcher uses Rust's native file system notification APIs for high performance.

    # Arguments
    * `server_port` - Port of the server to notify (default: 8787)
    * `ws_port` - WebSocket port for communication with `VSCode` extension (default: None)
    """
