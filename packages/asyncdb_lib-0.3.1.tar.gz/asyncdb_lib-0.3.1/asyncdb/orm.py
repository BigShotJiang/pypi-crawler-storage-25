"""
Async ORM with model definitions and relationships.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Optional, Type, TypeVar

ModelT = TypeVar("ModelT", bound="Model")


@dataclass
class Field:
    """Model field definition."""

    type: str = "VARCHAR"
    primary_key: bool = False
    auto_increment: bool = False
    nullable: bool = True
    unique: bool = False
    index: bool = False
    default: Any = None
    max_length: Optional[int] = None
    foreign_key: Optional[str] = None
    on_delete: str = "CASCADE"
    soft_delete: bool = False  # For soft delete support
    description: Optional[str] = None

    def to_sql(self, name: str, driver: str = "postgresql") -> str:
        """Generate SQL for field definition."""
        # Special handling for SQLite AUTOINCREMENT
        if self.auto_increment and driver == "sqlite":
            parts = [f"{name} INTEGER PRIMARY KEY AUTOINCREMENT"]
            if not self.nullable:
                parts.append("NOT NULL")
            if self.unique:
                parts.append("UNIQUE")
            if self.default is not None:
                if isinstance(self.default, str):
                    parts.append(f"DEFAULT '{self.default}'")
                else:
                    parts.append(f"DEFAULT {self.default}")
            if self.foreign_key:
                parts.append(f"REFERENCES {self.foreign_key} ON DELETE {self.on_delete}")
            return " ".join(parts)

        # Standard handling for PostgreSQL/MySQL
        parts = [name, self.type]

        if self.max_length:
            parts[-1] += f"({self.max_length})"

        if self.primary_key:
            parts.append("PRIMARY KEY")

        if not self.nullable:
            parts.append("NOT NULL")

        if self.unique:
            parts.append("UNIQUE")

        if self.default is not None:
            if isinstance(self.default, str):
                parts.append(f"DEFAULT '{self.default}'")
            else:
                parts.append(f"DEFAULT {self.default}")

        if self.auto_increment:
            parts.append("AUTO_INCREMENT")

        if self.foreign_key:
            parts.append(f"REFERENCES {self.foreign_key} ON DELETE {self.on_delete}")

        return " ".join(parts)


@dataclass
class Relationship:
    """Model relationship definition."""

    model: Type[Model]
    backref: Optional[str] = None
    lazy: bool = True


def relationship(
    model: Type[ModelT], backref: Optional[str] = None, lazy: bool = True
) -> Relationship:
    """Define a relationship between models."""
    return Relationship(model=model, backref=backref, lazy=lazy)


class ModelMetaclass(type):
    """Metaclass for Model that registers table metadata."""

    def __new__(mcs, name, bases, attrs):
        cls = super().__new__(mcs, name, bases, attrs)

        fields = {}
        relationships = {}
        table_name = attrs.get("__tablename__", name.lower())

        for attr_name, attr_value in attrs.items():
            if isinstance(attr_value, Field):
                fields[attr_name] = attr_value
            elif isinstance(attr_value, Relationship):
                relationships[attr_name] = attr_value

        # Auto-add primary key if not defined
        if not any(f.primary_key for f in fields.values()):
            fields["id"] = Field(
                type="INTEGER" if attrs.get("__driver__") == "sqlite" else "SERIAL",
                primary_key=True,
                auto_increment=True,
            )

        cls._fields = fields
        cls._relationships = relationships
        cls.__tablename__ = table_name

        return cls


class Model(metaclass=ModelMetaclass):
    """
    Base model class for ORM.

    Example:
        class User(Model):
            __tablename__ = "users"

            id = Field(primary_key=True, auto_increment=True)
            name = Field(type="VARCHAR", max_length=100, nullable=False)
            email = Field(type="VARCHAR", max_length=255, unique=True)
            created_at = Field(type="TIMESTAMP", default="NOW()")

        # Create table
        await User.create_table(db)

        # Create instance
        user = User(name="John", email="john@example.com")
        await user.save(db)

        # Query
        users = await User.objects.filter(db, name="John").all()
    """

    __tablename__: str = ""
    _fields: dict[str, Field] = {}
    _relationships: dict[str, Relationship] = {}

    def __init__(self, **kwargs):
        for field_name, field_def in self._fields.items():
            setattr(self, field_name, kwargs.get(field_name, field_def.default))

    @classmethod
    async def create_table(cls, db) -> None:
        """Create the table in the database."""
        columns = []
        indexes = []
        driver = getattr(db.config, 'driver', 'postgresql') if hasattr(db, 'config') and db.config else 'postgresql'

        for name, f in cls._fields.items():
            # Adjust types for SQLite
            field_type = f.type
            if driver == "sqlite":
                if field_type == "SERIAL":
                    field_type = "INTEGER"
                elif field_type == "TIMESTAMP":
                    field_type = "TEXT"
            
            # Create temporary field with adjusted type
            temp_field = Field(
                type=field_type,
                primary_key=f.primary_key,
                auto_increment=f.auto_increment,
                nullable=f.nullable,
                unique=f.unique,
                index=f.index,
                default=f.default,
                max_length=f.max_length,
                foreign_key=f.foreign_key,
                on_delete=f.on_delete,
            )
            columns.append(f"    {temp_field.to_sql(name, driver)}")

            if f.index:
                indexes.append(f"CREATE INDEX ON {cls.__tablename__} ({name})")

        columns_sql = ",\n".join(columns)
        sql = f"CREATE TABLE IF NOT EXISTS {cls.__tablename__} (\n{columns_sql}\n)"

        await db.execute(sql)

        for index_sql in indexes:
            await db.execute(index_sql)

    @classmethod
    async def drop_table(cls, db) -> None:
        """Drop the table from the database."""
        await db.execute(f"DROP TABLE IF EXISTS {cls.__tablename__}")

    @classmethod
    async def bulk_insert(cls, db, instances: list["Model"]) -> int:
        """Bulk insert multiple records efficiently."""
        if not instances:
            return 0

        fields = [f for f in cls._fields if not cls._fields[f].auto_increment]
        columns = ", ".join(fields)
        placeholders = ", ".join(["$" + str(i + 1) for i in range(len(fields))])

        sql = f"INSERT INTO {cls.__tablename__} ({columns}) VALUES ({placeholders})"

        for instance in instances:
            values = [getattr(instance, f) for f in fields]
            await db.execute(sql, tuple(values))

        return len(instances)

    @classmethod
    async def bulk_update(
        cls, db, instances: list["Model"], fields: list[str] | None = None
    ) -> int:
        """Bulk update multiple records."""
        if not instances:
            return 0

        pk = cls._fields.get("id") or next(f for f in cls._fields.values() if f.primary_key)
        pk_name = "id" if "id" in cls._fields else next(k for k, v in cls._fields.items() if v.primary_key)

        update_fields = fields or [f for f in cls._fields if f != pk_name and not cls._fields[f].auto_increment]

        count = 0
        for instance in instances:
            pk_value = getattr(instance, pk_name)
            set_clause = ", ".join([f"{f} = ${i+1}" for i, f in enumerate(update_fields)])
            values = [getattr(instance, f) for f in update_fields] + [pk_value]

            sql = f"UPDATE {cls.__tablename__} SET {set_clause} WHERE {pk_name} = ${len(update_fields)+1}"
            await db.execute(sql, tuple(values))
            count += 1

        return count

    @classmethod
    async def bulk_delete(cls, db, ids: list[Any]) -> int:
        """Bulk delete records by IDs."""
        if not ids:
            return 0

        pk_name = "id" if "id" in cls._fields else next(k for k, v in cls._fields.items() if v.primary_key)
        placeholders = ", ".join(["$" + str(i + 1) for i in range(len(ids))])

        sql = f"DELETE FROM {cls.__tablename__} WHERE {pk_name} IN ({placeholders})"
        result = await db.execute(sql, tuple(ids))

        return result

    async def soft_delete(self, db, deleted_field: str = "is_deleted") -> None:
        """Soft delete the record (mark as deleted without removing)."""
        pk = self._get_primary_key()
        pk_value = self._get_field_value(pk)

        # Check if model has soft delete field
        if deleted_field not in self._fields:
            # Add the field dynamically if it doesn't exist
            await db.execute(
                f"ALTER TABLE {self.__tablename__} ADD COLUMN {deleted_field} BOOLEAN DEFAULT FALSE"
            )

        sql = f"UPDATE {self.__tablename__} SET {deleted_field} = TRUE WHERE {pk} = $1"
        await db.execute(sql, (pk_value,))
        setattr(self, deleted_field, True)

    @classmethod
    async def soft_delete_many(cls, db, ids: list[Any], deleted_field: str = "is_deleted") -> int:
        """Soft delete multiple records by IDs."""
        if not ids:
            return 0

        placeholders = ", ".join(["$" + str(i + 1) for i in range(len(ids))])
        sql = f"UPDATE {cls.__tablename__} SET {deleted_field} = TRUE WHERE id IN ({placeholders})"
        result = await db.execute(sql, tuple(ids))

        return result

    @classmethod
    def objects(cls, include_deleted: bool = False, deleted_field: str = "is_deleted") -> QuerySet:
        """Get a queryset for this model, optionally including soft-deleted records."""
        qs = QuerySet(cls)
        if not include_deleted and deleted_field in cls._fields:
            qs._filters.append(f"{deleted_field} = FALSE")
        return qs

    async def save(self, db) -> None:
        """Save the model instance to the database."""
        if self._get_field_value("id"):
            await self.update(db)
        else:
            await self.insert(db)

    async def insert(self, db) -> None:
        """Insert a new record."""
        fields = [f for f in self._fields if not self._fields[f].auto_increment]
        columns = ", ".join(fields)
        placeholders = ", ".join(["$" + str(i + 1) for i in range(len(fields))])

        values = [getattr(self, f) for f in fields]

        sql = f"INSERT INTO {self.__tablename__} ({columns}) VALUES ({placeholders})"

        await db.execute(sql, tuple(values))

    async def update(self, db) -> None:
        """Update the existing record."""
        pk = self._get_primary_key()
        pk_value = self._get_field_value(pk)

        fields = [f for f in self._fields if f != pk and not self._fields[f].auto_increment]

        set_clause = ", ".join([f"{f} = ${i+1}" for i, f in enumerate(fields)])
        values = [getattr(self, f) for f in fields] + [pk_value]

        sql = f"UPDATE {self.__tablename__} SET {set_clause} WHERE {pk} = ${len(fields)+1}"

        await db.execute(sql, tuple(values))

    async def delete(self, db) -> None:
        """Delete the record from the database."""
        pk = self._get_primary_key()
        pk_value = self._get_field_value(pk)

        sql = f"DELETE FROM {self.__tablename__} WHERE {pk} = $1"
        await db.execute(sql, (pk_value,))

    @classmethod
    def objects(cls) -> QuerySet:
        """Get a queryset for this model."""
        return QuerySet(cls)

    def _get_primary_key(self) -> str:
        """Get the primary key field name."""
        for name, f in self._fields.items():
            if f.primary_key:
                return name
        return "id"

    def _get_field_value(self, name: str) -> Any:
        """Get the value of a field."""
        return getattr(self, name, None)

    def __repr__(self) -> str:
        pk = self._get_primary_key()
        pk_value = self._get_field_value(pk)
        return f"<{self.__class__.__name__} {pk}={pk_value}>"


class QuerySet:
    """Query builder for model queries."""

    def __init__(self, model: Type[Model]):
        self.model = model
        self._filters: list[str] = []
        self._params: list[Any] = []
        self._order_by: list[str] = []
        self._limit: Optional[int] = None
        self._offset: Optional[int] = None

    def filter(self, db=None, **kwargs) -> QuerySet:
        """Add WHERE filters."""
        for field_name, value in kwargs.items():
            op = "="
            if "__" in field_name:
                field_name, operator = field_name.rsplit("__", 1)
                op = self._get_operator(operator)

            self._filters.append(f"{field_name} {op} ${len(self._params)+1}")
            self._params.append(value)

        return self

    def exclude(self, **kwargs) -> QuerySet:
        """Add NOT filters."""
        for field_name, value in kwargs.items():
            self._filters.append(f"{field_name} != ${len(self._params)+1}")
            self._params.append(value)

        return self

    def order_by(self, *fields: str) -> QuerySet:
        """Add ORDER BY clause."""
        self._order_by.extend(fields)
        return self

    def limit(self, limit: int) -> QuerySet:
        """Add LIMIT clause."""
        self._limit = limit
        return self

    def offset(self, offset: int) -> QuerySet:
        """Add OFFSET clause."""
        self._offset = offset
        return self

    async def all(self, db) -> list[Model]:
        """Fetch all matching records."""
        sql = self._build_query()
        rows = await db.fetch_all(sql, tuple(self._params))

        return [self.model(**row) for row in rows]

    async def first(self, db) -> Optional[Model]:
        """Fetch the first matching record."""
        self._limit = 1
        results = await self.all(db)
        return results[0] if results else None

    async def count(self, db) -> int:
        """Count matching records."""
        base_query = self._build_query(select="COUNT(*) as count")
        result = await db.fetch_one(base_query, tuple(self._params))
        return result["count"] if result else 0

    async def exists(self, db) -> bool:
        """Check if any records match."""
        base_query = self._build_query(select="1")
        result = await db.fetch_one(base_query, tuple(self._params))
        return result is not None

    def _build_query(self, select: Optional[str] = None) -> str:
        """Build the SQL query."""
        columns = select or ", ".join(self.model._fields.keys())
        sql = f"SELECT {columns} FROM {self.model.__tablename__}"

        if self._filters:
            sql += " WHERE " + " AND ".join(self._filters)

        if self._order_by:
            sql += " ORDER BY " + ", ".join(self._order_by)

        if self._limit:
            sql += f" LIMIT {self._limit}"

        if self._offset:
            sql += f" OFFSET {self._offset}"

        return sql

    @staticmethod
    def _get_operator(op: str) -> str:
        """Convert Django-style operator to SQL."""
        ops = {
            "gt": ">",
            "gte": ">=",
            "lt": "<",
            "lte": "<=",
            "ne": "!=",
            "in": "IN",
            "like": "LIKE",
            "ilike": "ILIKE",
            "contains": "LIKE",
            "startswith": "LIKE",
            "endswith": "LIKE",
        }
        return ops.get(op, "=")
