"""
Fluent query builder for SQL generation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class QueryBuilder:
    """
    Fluent SQL query builder.

    Example:
        q = select("users").columns("id", "name").where("age > $1", 18)
        sql, params = q.build()
    """

    table: str = ""
    _columns: list[str] = field(default_factory=lambda: ["*"])
    _joins: list[str] = field(default_factory=list)
    _wheres: list[str] = field(default_factory=list)
    _params: list[Any] = field(default_factory=list)
    _order_by: list[str] = field(default_factory=list)
    _group_by: list[str] = field(default_factory=list)
    _having: list[str] = field(default_factory=list)
    _limit: Optional[int] = None
    _offset: Optional[int] = None
    _distinct: bool = False

    def columns(self, *cols: str) -> QueryBuilder:
        """Set columns to select."""
        self._columns = list(cols)
        return self

    def where(self, condition: str, *params: Any) -> QueryBuilder:
        """Add WHERE condition."""
        self._wheres.append(condition)
        self._params.extend(params)
        return self

    def and_where(self, condition: str, *params: Any) -> QueryBuilder:
        """Add AND condition."""
        if self._wheres:
            self._wheres[-1] += f" AND {condition}"
        else:
            self._wheres.append(condition)
        self._params.extend(params)
        return self

    def or_where(self, condition: str, *params: Any) -> QueryBuilder:
        """Add OR condition."""
        if self._wheres:
            self._wheres[-1] += f" OR {condition}"
        else:
            self._wheres.append(condition)
        self._params.extend(params)
        return self

    def join(
        self, table: str, on: str, join_type: str = "INNER"
    ) -> QueryBuilder:
        """Add JOIN clause."""
        self._joins.append(f"{join_type} JOIN {table} ON {on}")
        return self

    def left_join(self, table: str, on: str) -> QueryBuilder:
        """Add LEFT JOIN clause."""
        return self.join(table, on, "LEFT")

    def right_join(self, table: str, on: str) -> QueryBuilder:
        """Add RIGHT JOIN clause."""
        return self.join(table, on, "RIGHT")

    def order_by(self, *columns: str) -> QueryBuilder:
        """Add ORDER BY clause."""
        self._order_by.extend(columns)
        return self

    def group_by(self, *columns: str) -> QueryBuilder:
        """Add GROUP BY clause."""
        self._group_by.extend(columns)
        return self

    def having(self, condition: str, *params: Any) -> QueryBuilder:
        """Add HAVING condition."""
        self._having.append(condition)
        self._params.extend(params)
        return self

    def limit(self, limit: int) -> QueryBuilder:
        """Add LIMIT clause."""
        self._limit = limit
        return self

    def offset(self, offset: int) -> QueryBuilder:
        """Add OFFSET clause."""
        self._offset = offset
        return self

    def distinct(self) -> QueryBuilder:
        """Add DISTINCT."""
        self._distinct = True
        return self

    def build(self) -> tuple[str, tuple[Any, ...]]:
        """Build the SQL query."""
        distinct = "DISTINCT " if self._distinct else ""
        columns = ", ".join(self._columns) if self._columns else "*"

        sql = f"SELECT {distinct}{columns} FROM {self.table}"

        if self._joins:
            sql += " " + " ".join(self._joins)

        if self._wheres:
            sql += " WHERE " + " AND ".join(self._wheres)

        if self._group_by:
            sql += " GROUP BY " + ", ".join(self._group_by)

        if self._having:
            sql += " HAVING " + " AND ".join(self._having)

        if self._order_by:
            sql += " ORDER BY " + ", ".join(self._order_by)

        if self._limit is not None:
            sql += f" LIMIT {self._limit}"

        if self._offset is not None:
            sql += f" OFFSET {self._offset}"

        return sql, tuple(self._params)


def select(table: str) -> QueryBuilder:
    """Start a SELECT query."""
    return QueryBuilder(table=table)


def insert(table: str) -> InsertBuilder:
    """Start an INSERT query."""
    return InsertBuilder(table=table)


def update(table: str) -> UpdateBuilder:
    """Start an UPDATE query."""
    return UpdateBuilder(table=table)


def delete(table: str) -> DeleteBuilder:
    """Start a DELETE query."""
    return DeleteBuilder(table=table)


@dataclass
class InsertBuilder:
    """INSERT query builder."""

    table: str
    _columns: list[str] = field(default_factory=list)
    _values: list[list[Any]] = field(default_factory=list)
    _params: list[Any] = field(default_factory=list)

    def columns(self, *cols: str) -> InsertBuilder:
        """Set columns to insert into."""
        self._columns = list(cols)
        return self

    def values(self, *values: Any) -> InsertBuilder:
        """Add a row of values."""
        self._values.append(list(values))
        return self

    def build(self) -> tuple[str, tuple[Any, ...]]:
        """Build the INSERT query."""
        if not self._columns or not self._values:
            raise ValueError("Columns and values are required")

        cols = ", ".join(self._columns)
        placeholders = []

        for row in self._values:
            start_idx = len(self._params) + 1
            row_placeholders = [
                f"${start_idx + i}" for i in range(len(row))
            ]
            placeholders.append(f"({', '.join(row_placeholders)})")
            self._params.extend(row)

        values_str = ", ".join(placeholders)
        sql = f"INSERT INTO {self.table} ({cols}) VALUES {values_str}"

        return sql, tuple(self._params)


@dataclass
class UpdateBuilder:
    """UPDATE query builder."""

    table: str
    _sets: list[str] = field(default_factory=list)
    _wheres: list[str] = field(default_factory=list)
    _params: list[Any] = field(default_factory=list)

    def set(self, column: str, value: Any) -> UpdateBuilder:
        """Set a column value."""
        self._sets.append(f"{column} = ${len(self._params)+1}")
        self._params.append(value)
        return self

    def where(self, condition: str, *params: Any) -> UpdateBuilder:
        """Add WHERE condition."""
        self._wheres.append(condition)
        self._params.extend(params)
        return self

    def build(self) -> tuple[str, tuple[Any, ...]]:
        """Build the UPDATE query."""
        if not self._sets:
            raise ValueError("At least one SET clause is required")

        set_clause = ", ".join(self._sets)
        sql = f"UPDATE {self.table} SET {set_clause}"

        if self._wheres:
            sql += " WHERE " + " AND ".join(self._wheres)

        return sql, tuple(self._params)


@dataclass
class DeleteBuilder:
    """DELETE query builder."""

    table: str
    _wheres: list[str] = field(default_factory=list)
    _params: list[Any] = field(default_factory=list)

    def where(self, condition: str, *params: Any) -> DeleteBuilder:
        """Add WHERE condition."""
        self._wheres.append(condition)
        self._params.extend(params)
        return self

    def build(self) -> tuple[str, tuple[Any, ...]]:
        """Build the DELETE query."""
        sql = f"DELETE FROM {self.table}"

        if self._wheres:
            sql += " WHERE " + " AND ".join(self._wheres)

        return sql, tuple(self._params)
