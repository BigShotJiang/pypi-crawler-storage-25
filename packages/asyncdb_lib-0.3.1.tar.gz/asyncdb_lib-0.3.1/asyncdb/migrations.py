"""
Database migrations system.
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional


@dataclass
class Migration:
    """Single migration definition."""

    id: str
    name: str
    up: Callable
    down: Optional[Callable] = None
    created_at: datetime = field(default_factory=datetime.now)


def field(default=None):
    """Field helper for migrations."""
    return default


class Migrator:
    """
    Database migration manager.

    Example:
        migrator = Migrator("./migrations", db)

        @migrator.migration("create_users_table")
        async def create_users(m):
            await m.execute("CREATE TABLE users (id SERIAL PRIMARY KEY, name VARCHAR(255))")

        @migrator.migration("add_email_to_users")
        async def add_email(m):
            await m.execute("ALTER TABLE users ADD COLUMN email VARCHAR(255)")

        # Run migrations
        await migrator.up()

        # Rollback
        await migrator.down()
    """

    def __init__(self, migrations_dir: str, db):
        self.migrations_dir = Path(migrations_dir)
        self.db = db
        self._migrations: list[Migration] = []
        self._applied: set[str] = set()

    def migration(self, name: str) -> Callable:
        """Decorator to register a migration."""

        def decorator(func: Callable) -> Callable:
            migration_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{name}"
            migration = Migration(id=migration_id, name=name, up=func)
            self._migrations.append(migration)
            return func

        return decorator

    async def initialize(self) -> None:
        """Create migrations table if not exists."""
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS _migrations (
                id VARCHAR(255) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        rows = await self.db.fetch_all("SELECT id FROM _migrations")
        self._applied = {row["id"] for row in rows}

    async def up(self, target: Optional[str] = None) -> list[str]:
        """Run all pending migrations."""
        await self.initialize()

        applied = []
        for migration in sorted(self._migrations, key=lambda m: m.id):
            if target and migration.id > target:
                break

            if migration.id not in self._applied:
                await migration.up(self)
                await self.db.execute(
                    "INSERT INTO _migrations (id, name) VALUES ($1, $2)",
                    (migration.id, migration.name),
                )
                self._applied.add(migration.id)
                applied.append(migration.id)

        return applied

    async def down(self, steps: int = 1) -> list[str]:
        """Rollback migrations."""
        await self.initialize()

        rolled_back = []
        for migration in reversed(self._migrations):
            if len(rolled_back) >= steps:
                break

            if migration.id in self._applied:
                if migration.down:
                    await migration.down(self)

                await self.db.execute(
                    "DELETE FROM _migrations WHERE id = $1", (migration.id,)
                )
                self._applied.remove(migration.id)
                rolled_back.append(migration.id)

        return rolled_back

    async def status(self) -> list[dict[str, Any]]:
        """Get migration status."""
        await self.initialize()

        status = []
        for migration in sorted(self._migrations, key=lambda m: m.id):
            status.append(
                {
                    "id": migration.id,
                    "name": migration.name,
                    "applied": migration.id in self._applied,
                }
            )

        return status

    async def execute(self, sql: str, params: Optional[tuple] = None) -> None:
        """Execute raw SQL in migration context."""
        await self.db.execute(sql, params)

    async def create_table(self, name: str, columns: dict[str, str]) -> None:
        """Create a table."""
        cols = ", ".join(f"{k} {v}" for k, v in columns.items())
        await self.execute(f"CREATE TABLE {name} ({cols})")

    async def drop_table(self, name: str) -> None:
        """Drop a table."""
        await self.execute(f"DROP TABLE IF EXISTS {name}")

    async def add_column(
        self, table: str, column: str, type_: str, default: Optional[str] = None
    ) -> None:
        """Add a column to a table."""
        sql = f"ALTER TABLE {table} ADD COLUMN {column} {type_}"
        if default:
            sql += f" DEFAULT {default}"
        await self.execute(sql)

    async def drop_column(self, table: str, column: str) -> None:
        """Drop a column from a table."""
        await self.execute(f"ALTER TABLE {table} DROP COLUMN {column}")

    async def create_index(
        self, name: str, table: str, columns: list[str], unique: bool = False
    ) -> None:
        """Create an index."""
        unique_str = "UNIQUE " if unique else ""
        cols = ", ".join(columns)
        await self.execute(f"CREATE {unique_str}INDEX {name} ON {table} ({cols})")

    async def drop_index(self, name: str) -> None:
        """Drop an index."""
        await self.execute(f"DROP INDEX IF EXISTS {name}")
