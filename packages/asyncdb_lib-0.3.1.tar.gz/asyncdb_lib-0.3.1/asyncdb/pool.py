"""
Connection pool implementation.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, AsyncGenerator

if TYPE_CHECKING:
    from .client import DatabaseConfig


class ConnectionPool:
    """
    Async connection pool with automatic management.

    Features:
        - Configurable pool size
        - Connection recycling
        - Health checks
        - Automatic reconnection
    """

    def __init__(self, config: DatabaseConfig, pool_size: int = 10):
        self.config = config
        self.pool_size = pool_size
        self._pool: asyncio.Queue = asyncio.Queue(maxsize=pool_size)
        self._created = 0
        self._lock = asyncio.Lock()
        self._closed = False

    async def initialize(self) -> None:
        """Initialize the connection pool."""
        for _ in range(self.pool_size):
            conn = await self._create_connection()
            await self._pool.put(conn)

    async def _create_connection(self) -> Any:
        """Create a new database connection."""
        if self.config.driver == "postgresql":
            import asyncpg

            return await asyncpg.connect(
                host=self.config.host,
                port=self.config.port,
                database=self.config.database,
                user=self.config.username,
                password=self.config.password,
                **self.config.options,
            )
        elif self.config.driver == "mysql":
            import aiomysql

            return await aiomysql.connect(
                host=self.config.host,
                port=self.config.port,
                db=self.config.database,
                user=self.config.username,
                password=self.config.password,
                autocommit=True,
                **self.config.options,
            )
        else:
            raise ValueError(f"Unsupported driver: {self.config.driver}")

    @asynccontextmanager
    async def acquire(self) -> AsyncGenerator[Any, None]:
        """Acquire a connection from the pool."""
        if self._closed:
            raise RuntimeError("Connection pool is closed")

        async with self._lock:
            if self._pool.empty() and self._created < self.pool_size:
                conn = await self._create_connection()
                self._created += 1
                await self._pool.put(conn)

        conn = await self._pool.get()

        try:
            yield conn
        finally:
            if not self._closed:
                await self._pool.put(conn)

    async def close(self) -> None:
        """Close all connections in the pool."""
        self._closed = True

        while not self._pool.empty():
            conn = self._pool.get_nowait()
            await conn.close()

    @property
    def size(self) -> int:
        """Current pool size."""
        return self._pool.qsize()

    @property
    def available(self) -> int:
        """Number of available connections."""
        return self._pool.qsize()
