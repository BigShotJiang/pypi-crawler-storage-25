"""
PyAsyncDB - Modern Async Database Library

A comprehensive async database library with ORM, query builder,
connection pooling, and migrations for PostgreSQL, MySQL, and SQLite.
"""

from .client import Database, create_database, Transaction
from .orm import Model, Field, relationship
from .pool import ConnectionPool
from .query import QueryBuilder, select, insert, update, delete
from .migrations import Migration, Migrator

# Pydantic integration (optional)
try:
    from .pydantic_model import PydanticModelMixin, validate_model
    __all__ = [
        "Database",
        "create_database",
        "Transaction",
        "Model",
        "Field",
        "relationship",
        "ConnectionPool",
        "QueryBuilder",
        "select",
        "insert",
        "update",
        "delete",
        "Migration",
        "Migrator",
        "PydanticModelMixin",
        "validate_model",
    ]
except ImportError:
    __all__ = [
        "Database",
        "create_database",
        "Transaction",
        "Model",
        "Field",
        "relationship",
        "ConnectionPool",
        "QueryBuilder",
        "select",
        "insert",
        "update",
        "delete",
        "Migration",
        "Migrator",
    ]

__version__ = "0.3.1"
