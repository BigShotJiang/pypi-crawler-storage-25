"""
Basic tests for AsyncDB library.
"""

import asyncio
import pytest
from asyncdb import Database, Model, Field, select


@pytest.fixture
async def db():
    """Create test database connection."""
    db = Database("sqlite:///test.db")
    await db.connect()
    await db.execute("DROP TABLE IF EXISTS test_users")
    yield db
    await db.disconnect()


class User(Model):
    __tablename__ = "test_users"

    name = Field(type="VARCHAR", max_length=100, nullable=False)
    email = Field(type="VARCHAR", max_length=255)


@pytest.mark.asyncio
async def test_create_table(db):
    """Test table creation."""
    await User.drop_table(db)
    await User.create_table(db)

    result = await db.fetch_one(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='test_users'"
    )
    assert result is not None


@pytest.mark.asyncio
async def test_insert_and_fetch(db):
    """Test insert and fetch operations."""
    await User.create_table(db)

    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("John", "john@example.com"),
    )

    user = await db.fetch_one("SELECT * FROM test_users WHERE name = ?", ("John",))
    assert user["name"] == "John"
    assert user["email"] == "john@example.com"


@pytest.mark.asyncio
async def test_orm_operations(db):
    """Test ORM operations."""
    await User.drop_table(db)
    await User.create_table(db)

    user = User(name="Alice", email="alice@example.com")
    await user.insert(db)

    users = await User.objects().filter(name="Alice").all(db)
    assert len(users) == 1
    assert users[0].email == "alice@example.com"


@pytest.mark.asyncio
async def test_query_builder():
    """Test query builder."""
    q = select("users").columns("id", "name").where("age > $1", 18).limit(10)
    sql, params = q.build()

    assert "SELECT id, name FROM users" in sql
    assert "WHERE age > $1" in sql
    assert "LIMIT 10" in sql
    assert params == (18,)


@pytest.mark.asyncio
async def test_fetch_all(db):
    """Test fetching multiple rows."""
    await User.create_table(db)

    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("User1", "user1@example.com"),
    )
    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("User2", "user2@example.com"),
    )

    users = await db.fetch_all("SELECT * FROM test_users")
    assert len(users) == 2


@pytest.mark.asyncio
async def test_fetch_val(db):
    """Test fetching single value."""
    await User.create_table(db)

    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("Test", "test@example.com"),
    )

    count = await db.fetch_val("SELECT COUNT(*) FROM test_users")
    assert count == 1


@pytest.mark.asyncio
async def test_update(db):
    """Test update operation."""
    await User.create_table(db)

    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("Original", "original@example.com"),
    )

    await db.execute(
        "UPDATE test_users SET email = ? WHERE name = ?",
        ("updated@example.com", "Original"),
    )

    user = await db.fetch_one("SELECT * FROM test_users WHERE name = ?", ("Original",))
    assert user["email"] == "updated@example.com"


@pytest.mark.asyncio
async def test_delete(db):
    """Test delete operation."""
    await User.create_table(db)

    await db.execute(
        "INSERT INTO test_users (name, email) VALUES (?, ?)",
        ("ToDelete", "delete@example.com"),
    )

    await db.execute("DELETE FROM test_users WHERE name = ?", ("ToDelete",))

    user = await db.fetch_one("SELECT * FROM test_users WHERE name = ?", ("ToDelete",))
    assert user is None


@pytest.mark.asyncio
async def test_context_manager():
    """Test async context manager."""
    async with Database("sqlite:///test2.db") as db:
        result = await db.fetch_val("SELECT 1")
        assert result == 1
