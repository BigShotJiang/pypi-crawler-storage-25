"""
Pydantic integration for PyAsyncDB models.

Provides automatic Pydantic model generation from database models.
"""

from __future__ import annotations

from typing import Any, Optional, Type, TypeVar

try:
    from pydantic import BaseModel, Field as PydanticField, ValidationError
    from pydantic.fields import FieldInfo
    PYDANTIC_INSTALLED = True
except ImportError:
    PYDANTIC_INSTALLED = False
    BaseModel = object  # type: ignore

from .orm import Model, Field

ModelT = TypeVar("ModelT", bound=Model)


class PydanticModelMixin:
    """
    Mixin to add Pydantic model generation to database models.

    Usage:
        class User(Model, PydanticModelMixin):
            __tablename__ = "users"
            name = Field(type="VARCHAR", max_length=100)
            email = Field(type="VARCHAR", max_length=255)

        # Get Pydantic class
        UserSchema = User.pydantic_model()

        # Validate data
        user_data = UserSchema(name="John", email="john@example.com")
    """

    @classmethod
    def pydantic_model(
        cls,
        *,
        name: Optional[str] = None,
        exclude_fields: Optional[list[str]] = None,
        include_fields: Optional[list[str]] = None,
        with_id: bool = True,
    ) -> Type[BaseModel]:
        """
        Generate a Pydantic model from the database model.

        Args:
            name: Custom name for the Pydantic model
            exclude_fields: Fields to exclude from the model
            include_fields: Fields to include (if None, include all)
            with_id: Include the ID field

        Returns:
            Pydantic BaseModel class
        """
        if not PYDANTIC_INSTALLED:
            raise ImportError(
                "Pydantic is required. Install with: pip install pydantic"
            )

        exclude_fields = exclude_fields or []
        if not with_id:
            exclude_fields.append("id")

        # Build field definitions for Pydantic
        field_definitions = {}

        for field_name, field_def in cls._fields.items():
            # Skip excluded fields
            if field_name in exclude_fields:
                continue
            if include_fields and field_name not in include_fields:
                continue

            # Determine Python type
            python_type = cls._get_python_type(field_def.type)

            # Determine if field is optional
            is_optional = field_def.nullable or field_def.default is not None

            # Build Pydantic field
            pydantic_field = cls._build_pydantic_field(field_def, is_optional)

            # Add to definitions
            if is_optional:
                field_definitions[field_name] = (
                    Optional[python_type],
                    pydantic_field,
                )
            else:
                field_definitions[field_name] = (
                    python_type,
                    pydantic_field,
                )

        # Create model name
        model_name = name or f"{cls.__name__}Schema"

        # Dynamically create Pydantic model
        pydantic_model = type(model_name, (BaseModel,), field_definitions)

        # Store reference to original model
        pydantic_model._db_model = cls  # type: ignore

        return pydantic_model

    @classmethod
    def _get_python_type(cls, sql_type: str) -> type:
        """Convert SQL type to Python type."""
        type_mapping = {
            "INTEGER": int,
            "INT": int,
            "BIGINT": int,
            "SMALLINT": int,
            "SERIAL": int,
            "VARCHAR": str,
            "CHAR": str,
            "TEXT": str,
            "STRING": str,
            "BOOLEAN": bool,
            "BOOL": bool,
            "FLOAT": float,
            "REAL": float,
            "DOUBLE": float,
            "DECIMAL": float,
            "NUMERIC": float,
            "DATE": str,
            "DATETIME": str,
            "TIMESTAMP": str,
            "TIME": str,
            "JSON": dict,
            "JSONB": dict,
        }
        return type_mapping.get(sql_type.upper(), str)

    @classmethod
    def _build_pydantic_field(cls, field_def: Field, is_optional: bool) -> FieldInfo:
        """Build Pydantic Field from database Field."""
        kwargs = {}

        if field_def.default is not None:
            kwargs["default"] = field_def.default
        elif is_optional:
            kwargs["default"] = None

        if field_def.max_length:
            kwargs["max_length"] = field_def.max_length

        if field_def.description:
            kwargs["description"] = field_def.description

        if field_def.unique:
            kwargs["unique"] = True

        return PydanticField(**kwargs)  # type: ignore

    def to_dict(self) -> dict[str, Any]:
        """Convert model instance to dictionary."""
        return {
            field_name: getattr(self, field_name)
            for field_name in self._fields
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Model:
        """Create model instance from dictionary."""
        return cls(**data)

    def update_from(self, data: dict[str, Any]) -> None:
        """Update model fields from dictionary."""
        for field_name, value in data.items():
            if field_name in self._fields:
                setattr(self, field_name, value)


# Add validation decorator for models
def validate_model(model_class: Type[ModelT]) -> Type[ModelT]:
    """
    Decorator to add validation to a model.

    Usage:
        @validate_model
        class User(Model):
            __tablename__ = "users"
            email = Field(type="VARCHAR", max_length=255)
    """
    if not PYDANTIC_INSTALLED:
        return model_class

    # Generate Pydantic model
    schema = model_class.pydantic_model()

    # Store schema reference
    model_class._schema = schema  # type: ignore

    # Wrap __init__ to add validation
    original_init = model_class.__init__

    def validated_init(self, **kwargs):
        # Validate using Pydantic
        try:
            validated = schema(**kwargs)
            # Pass validated data to original init
            original_init(self, **validated.model_dump())
        except ValidationError as e:
            raise ValueError(f"Validation failed: {e}")

    model_class.__init__ = validated_init  # type: ignore

    return model_class
