"""
PyAsyncDB CLI - Command Line Interface for database management.
"""

import asyncio
import sys
from pathlib import Path

import click

from .client import Database
from .migrations import Migrator


@click.group()
@click.version_option(version="0.2.0", prog_name="pyasyncdb")
@click.pass_context
def cli(ctx):
    """PyAsyncDB - Modern Async Database CLI"""
    pass


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
@click.option("--migrations-dir", default="./migrations", help="Migrations directory")
def migrate_up(url: str, migrations_dir: str):
    """Run all pending migrations."""
    async def _run():
        db = Database(url)
        async with db:
            migrator = Migrator(migrations_dir, db)
            applied = await migrator.up()
            if applied:
                click.echo(f"Applied {len(applied)} migration(s):")
                for m in applied:
                    click.echo(f"  - {m}")
            else:
                click.echo("No pending migrations.")

    asyncio.run(_run())


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
@click.option("--migrations-dir", default="./migrations", help="Migrations directory")
@click.option("--steps", default=1, help="Number of migrations to rollback")
def migrate_down(url: str, migrations_dir: str, steps: int):
    """Rollback migrations."""
    async def _run():
        db = Database(url)
        async with db:
            migrator = Migrator(migrations_dir, db)
            rolled_back = await migrator.down(steps=steps)
            if rolled_back:
                click.echo(f"Rolled back {len(rolled_back)} migration(s):")
                for m in rolled_back:
                    click.echo(f"  - {m}")
            else:
                click.echo("No migrations to rollback.")

    asyncio.run(_run())


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
@click.option("--migrations-dir", default="./migrations", help="Migrations directory")
def migrate_status(url: str, migrations_dir: str):
    """Show migration status."""
    async def _run():
        db = Database(url)
        async with db:
            migrator = Migrator(migrations_dir, db)
            status = await migrator.status()
            if not status:
                click.echo("No migrations found.")
                return

            click.echo("Migration status:")
            for m in status:
                status_icon = "✓" if m["applied"] else "○"
                status_color = "green" if m["applied"] else "yellow"
                click.secho(f"  [{status_icon}] {m['id']} - {m['name']}", fg=status_color)

    asyncio.run(_run())


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
@click.option("--name", required=True, help="Migration name")
@click.option("--migrations-dir", default="./migrations", help="Migrations directory")
def migrate_create(name: str, migrations_dir: str):
    """Create a new migration file."""
    from datetime import datetime

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    migration_id = f"{timestamp}_{name}"
    filename = f"{migration_id}.py"

    Path(migrations_dir).mkdir(parents=True, exist_ok=True)
    filepath = Path(migrations_dir) / filename

    content = f'''"""Migration: {name}"""


async def up(migrator):
    """Apply migration."""
    # Example:
    # await migrator.create_table("users", {{
    #     "id": "SERIAL PRIMARY KEY",
    #     "name": "VARCHAR(255) NOT NULL",
    # }})
    pass


async def down(migrator):
    """Rollback migration."""
    # Example:
    # await migrator.drop_table("users")
    pass
'''

    filepath.write_text(content)
    click.echo(f"Created migration: {filepath}")


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
def shell(url: str):
    """Interactive database shell."""
    async def _run():
        db = Database(url)
        await db.connect()

        click.echo(f"Connected to {db.config.driver} database.")
        click.echo("Type SQL queries or .help for commands.")
        click.echo("Type .exit or .quit to exit.\n")

        while True:
            try:
                query = click.prompt("db> ", prompt_suffix="").strip()

                if not query:
                    continue

                if query in (".exit", ".quit"):
                    break

                if query == ".help":
                    click.echo("""
Available commands:
  .help     Show this help message
  .tables   List all tables
  .schema   Show table schema
  .exit     Exit the shell

Enter any SQL query to execute it.
""")
                    continue

                if query == ".tables":
                    if db.config.driver == "sqlite":
                        tables = await db.fetch_col(
                            "SELECT name FROM sqlite_master WHERE type='table'"
                        )
                    elif db.config.driver == "postgresql":
                        tables = await db.fetch_col(
                            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"
                        )
                    elif db.config.driver == "mysql":
                        tables = await db.fetch_col("SHOW TABLES")
                    else:
                        click.echo("Schema inspection not supported for this database")
                        continue

                    click.echo("\n".join(f"  - {t}" for t in tables))
                    continue

                if query.startswith(".schema "):
                    table_name = query[8:].strip()
                    if db.config.driver == "sqlite":
                        schema = await db.fetch_val(
                            "SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                            (table_name,)
                        )
                    elif db.config.driver == "postgresql":
                        schema = await db.fetch_all(
                            """SELECT column_name, data_type, is_nullable
                               FROM information_schema.columns
                               WHERE table_name = %s""",
                            (table_name,)
                        )
                        click.echo("\n".join(str(s) for s in schema))
                        continue
                    else:
                        click.echo("Schema inspection not supported for this database")
                        continue

                    click.echo(schema or f"Table '{table_name}' not found")
                    continue

                # Execute query
                if query.upper().startswith("SELECT"):
                    results = await db.fetch_all(query)
                    if results:
                        # Print header
                        headers = list(results[0].keys())
                        click.echo(" | ".join(headers))
                        click.echo("-" * (len(headers) * 15))
                        # Print rows
                        for row in results:
                            click.echo(" | ".join(str(v) for v in row.values()))
                        click.echo(f"\n{len(results)} row(s)")
                    else:
                        click.echo("No results")
                else:
                    result = await db.execute(query)
                    click.echo(f"Query executed. {result} row(s) affected.")

            except KeyboardInterrupt:
                click.echo("\nUse .exit to quit")
            except Exception as e:
                click.echo(f"Error: {e}")

        await db.disconnect()

    asyncio.run(_run())


@cli.command()
@click.option("--url", envvar="DATABASE_URL", required=True, help="Database URL")
def inspect(url: str):
    """Inspect database schema."""
    async def _run():
        db = Database(url)
        async with db:
            click.echo(f"Database: {db.config.database}")
            click.echo(f"Driver: {db.config.driver}\n")

            # Get tables
            if db.config.driver == "sqlite":
                tables = await db.fetch_col(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                )
            elif db.config.driver == "postgresql":
                tables = await db.fetch_col(
                    "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"
                )
            elif db.config.driver == "mysql":
                tables = await db.fetch_col("SHOW TABLES")
            else:
                click.echo("Inspection not supported for this database")
                return

            click.echo(f"Tables ({len(tables)}):")
            for table in tables:
                click.echo(f"  - {table}")

    asyncio.run(_run())


def main():
    """Entry point for CLI."""
    cli()


if __name__ == "__main__":
    main()
