"""
Database client and connection management.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional
from urllib.parse import urlparse, parse_qs

from .pool import ConnectionPool

logger = logging.getLogger(__name__)


@dataclass
class DatabaseConfig:
    """Database configuration."""

    driver: str
    host: str
    port: int
    database: str
    username: str
    password: str
    options: dict[str, Any]

    @classmethod
    def from_url(cls, url: str) -> DatabaseConfig:
        """Parse database URL into config."""
        parsed = urlparse(url)
        query = parse_qs(parsed.query)

        options = {k: v[0] if len(v) == 1 else v for k, v in query.items()}

        return cls(
            driver=parsed.scheme.split("+")[0] if "+" in parsed.scheme else parsed.scheme,
            host=parsed.hostname or "localhost",
            port=parsed.port or cls._default_port(parsed.scheme),
            database=parsed.path.lstrip("/") or "postgres",
            username=parsed.username or "postgres",
            password=parsed.password or "",
            options=options,
        )

    @staticmethod
    def _default_port(scheme: str) -> int:
        ports = {"postgresql": 5432, "mysql": 3306, "sqlite": 0}
        base = scheme.split("+")[0] if "+" in scheme else scheme
        return ports.get(base, 5432)


class Database:
    """
    Main database client class.

    Supports PostgreSQL, MySQL, and SQLite with async operations.

    Example:
        db = Database("postgresql://user:pass@localhost/mydb")
        await db.connect()
        result = await db.fetch_all("SELECT * FROM users")
        await db.disconnect()
    """

    def __init__(
        self,
        url: Optional[str] = None,
        *,
        driver: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        pool_size: int = 10,
        echo: bool = False,
        slow_query_threshold: float = 1.0,
        health_check_interval: float = 30.0,
        max_idle_time: float = 300.0,
        retry_on_disconnect: bool = True,
        **options: Any,
    ):
        if url:
            self.config = DatabaseConfig.from_url(url)
            self.config.options.update(options)
        else:
            self.config = DatabaseConfig(
                driver=driver or "postgresql",
                host=host or "localhost",
                port=port or 5432,
                database=database or "postgres",
                username=username or "postgres",
                password=password or "",
                options=options,
            )

        self.pool_size = pool_size
        self.echo = echo
        self.slow_query_threshold = slow_query_threshold
        self.health_check_interval = health_check_interval
        self.max_idle_time = max_idle_time
        self.retry_on_disconnect = retry_on_disconnect
        self._pool: Optional[ConnectionPool] = None
        self._connection: Any = None
        self._is_connected = False
        self._transaction_depth = 0
        self._query_log: list[dict] = []
        self._last_activity: datetime = datetime.now()
        
        # Event hooks
        self._on_connect: list[Callable] = []
        self._on_disconnect: list[Callable] = []
        self._on_query: list[Callable] = []
        self._on_error: list[Callable] = []

    def on_connect(self, func: Callable) -> Callable:
        """Register a hook to be called when connected."""
        self._on_connect.append(func)
        return func

    def on_disconnect(self, func: Callable) -> Callable:
        """Register a hook to be called when disconnected."""
        self._on_disconnect.append(func)
        return func

    def on_query(self, func: Callable) -> Callable:
        """Register a hook to be called before each query."""
        self._on_query.append(func)
        return func

    def on_error(self, func: Callable) -> Callable:
        """Register a hook to be called on database errors."""
        self._on_error.append(func)
        return func

    async def _emit_connect(self) -> None:
        """Emit connect event."""
        for hook in self._on_connect:
            try:
                if asyncio.iscoroutinefunction(hook):
                    await hook(self)
                else:
                    hook(self)
            except Exception as e:
                logger.warning(f"on_connect hook failed: {e}")

    async def _emit_disconnect(self) -> None:
        """Emit disconnect event."""
        for hook in self._on_disconnect:
            try:
                if asyncio.iscoroutinefunction(hook):
                    await hook(self)
                else:
                    hook(self)
            except Exception as e:
                logger.warning(f"on_disconnect hook failed: {e}")

    async def _emit_query(self, query: str, params: tuple) -> None:
        """Emit query event."""
        for hook in self._on_query:
            try:
                if asyncio.iscoroutinefunction(hook):
                    await hook(self, query, params)
                else:
                    hook(self, query, params)
            except Exception as e:
                logger.warning(f"on_query hook failed: {e}")

    async def _emit_error(self, error: Exception, query: Optional[str] = None) -> None:
        """Emit error event."""
        for hook in self._on_error:
            try:
                if asyncio.iscoroutinefunction(hook):
                    await hook(self, error, query)
                else:
                    hook(self, error, query)
            except Exception as e:
                logger.warning(f"on_error hook failed: {e}")

    async def connect(self) -> None:
        """Establish database connection."""
        if self._is_connected:
            return

        try:
            if self.config.driver == "sqlite":
                import aiosqlite

                self._connection = await aiosqlite.connect(self.config.database)
                self._connection.row_factory = aiosqlite.Row
            else:
                self._pool = ConnectionPool(self.config, self.pool_size)
                await self._pool.initialize()

            self._is_connected = True
            self._last_activity = datetime.now()
            logger.info(f"Connected to {self.config.driver} database")
            await self._emit_connect()
        except Exception as e:
            await self._emit_error(e)
            raise

    async def disconnect(self) -> None:
        """Close database connection."""
        if not self._is_connected:
            return

        try:
            if self._pool:
                await self._pool.close()
                self._pool = None
            elif self._connection:
                await self._connection.close()
                self._connection = None

            self._is_connected = False
            logger.info("Disconnected from database")
            await self._emit_disconnect()
        except Exception as e:
            await self._emit_error(e)
            raise

    async def _check_health(self) -> bool:
        """Check if connection is healthy."""
        if not self._is_connected:
            return False
        
        # Check idle time
        idle_time = (datetime.now() - self._last_activity).total_seconds()
        if idle_time > self.max_idle_time:
            logger.info("Connection idle too long, reconnecting...")
            return False
        
        # Periodic health check
        if self.health_check_interval > 0:
            try:
                if self.config.driver == "sqlite":
                    await self._connection.execute("SELECT 1")
                else:
                    async with self._pool.acquire() as conn:
                        await conn.execute("SELECT 1")
                return True
            except Exception:
                return False
        
        return True

    async def _log_query(self, query: str, params: tuple, duration: float) -> None:
        """Log query with timing information."""
        log_entry = {
            "query": query,
            "params": params,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
            "is_slow": duration > self.slow_query_threshold,
        }
        self._query_log.append(log_entry)
        self._last_activity = datetime.now()

        if self.echo:
            logger.info(f"Query: {query} | Params: {params} | Duration: {duration:.3f}s")

        if log_entry["is_slow"]:
            logger.warning(f"Slow query detected ({duration:.3f}s): {query}")

    async def _execute_with_retry(self, query: str, params: tuple, executor: Callable):
        """Execute query with automatic retry on disconnect."""
        if not self.retry_on_disconnect:
            return await executor()
        
        try:
            # Check health before executing
            if not await self._check_health():
                logger.info("Health check failed, reconnecting...")
                await self.disconnect()
                await self.connect()
            
            result = await executor()
            return result
        except Exception as e:
            # On error, try to reconnect and retry once
            if self.retry_on_disconnect:
                logger.info(f"Query failed, attempting reconnect: {e}")
                await self.disconnect()
                await self.connect()
                return await executor()
            raise

    @asynccontextmanager
    async def transaction(self):
        """
        Context manager for database transactions.

        Example:
            async with db.transaction():
                await db.execute("INSERT INTO users ...")
                await db.execute("UPDATE accounts ...")
                # Commits on success, rollbacks on error
        """
        if not self._is_connected:
            await self.connect()

        self._transaction_depth += 1
        is_outermost = self._transaction_depth == 1

        try:
            if is_outermost:
                if self._pool:
                    async with self._pool.acquire() as conn:
                        await conn.execute("BEGIN")
                        yield Transaction(self, conn)
                        await conn.execute("COMMIT")
                else:
                    await self._connection.execute("BEGIN")
                    yield Transaction(self, self._connection)
                    await self._connection.execute("COMMIT")
            else:
                # Savepoint for nested transactions
                savepoint_name = f"sp_{self._transaction_depth}"
                if self._pool:
                    async with self._pool.acquire() as conn:
                        await conn.execute(f"SAVEPOINT {savepoint_name}")
                        yield Transaction(self, conn)
                        await conn.execute(f"RELEASE SAVEPOINT {savepoint_name}")
                else:
                    await self._connection.execute(f"SAVEPOINT {savepoint_name}")
                    yield Transaction(self, self._connection)
                    await self._connection.execute(f"RELEASE SAVEPOINT {savepoint_name}")
        except Exception as e:
            # Rollback on error
            if is_outermost:
                if self._pool:
                    async with self._pool.acquire() as conn:
                        await conn.execute("ROLLBACK")
                else:
                    await self._connection.execute("ROLLBACK")
            else:
                savepoint_name = f"sp_{self._transaction_depth}"
                if self._pool:
                    async with self._pool.acquire() as conn:
                        await conn.execute(f"ROLLBACK TO SAVEPOINT {savepoint_name}")
                else:
                    await self._connection.execute(f"ROLLBACK TO SAVEPOINT {savepoint_name}")
            logger.error(f"Transaction rolled back: {e}")
            raise
        finally:
            self._transaction_depth -= 1

    async def execute(
        self, query: str, params: Optional[dict | tuple] = None, timeout: Optional[float] = None
    ) -> int:
        """Execute a query and return affected rows."""
        if not self._is_connected:
            await self.connect()

        params = params or ()
        start_time = datetime.now()
        
        # Emit query event
        await self._emit_query(query, params)

        async def _exec():
            if self._pool:
                async with self._pool.acquire() as conn:
                    cursor = await conn.execute(query, params)
                    return cursor.rowcount
            else:
                cursor = await self._connection.execute(query, params)
                await self._connection.commit()
                return cursor.rowcount

        try:
            result = await self._execute_with_retry(query, params, _exec)
        except Exception as e:
            await self._emit_error(e, query)
            raise

        duration = (datetime.now() - start_time).total_seconds()
        await self._log_query(query, params, duration)

        return result

    async def fetch_one(
        self, query: str, params: Optional[dict | tuple] = None, timeout: Optional[float] = None
    ) -> Optional[dict]:
        """Fetch a single row."""
        if not self._is_connected:
            await self.connect()

        params = params or ()
        start_time = datetime.now()

        if self._pool:
            async with self._pool.acquire() as conn:
                cursor = await conn.execute(query, params)
                row = await cursor.fetchone()
                result = dict(row) if row else None
        else:
            cursor = await self._connection.execute(query, params)
            row = await cursor.fetchone()
            result = dict(row) if row else None

        duration = (datetime.now() - start_time).total_seconds()
        await self._log_query(query, params, duration)

        return result

    async def fetch_all(
        self, query: str, params: Optional[dict | tuple] = None, timeout: Optional[float] = None
    ) -> list[dict]:
        """Fetch all rows."""
        if not self._is_connected:
            await self.connect()

        params = params or ()
        start_time = datetime.now()

        if self._pool:
            async with self._pool.acquire() as conn:
                cursor = await conn.execute(query, params)
                rows = await cursor.fetchall()
                result = [dict(row) for row in rows]
        else:
            cursor = await self._connection.execute(query, params)
            rows = await cursor.fetchall()
            result = [dict(row) for row in rows]

        duration = (datetime.now() - start_time).total_seconds()
        await self._log_query(query, params, duration)

        return result

    async def fetch_val(
        self, query: str, params: Optional[dict | tuple] = None, column: int = 0, timeout: Optional[float] = None
    ) -> Any:
        """Fetch a single value."""
        row = await self.fetch_one(query, params)
        return row[list(row.keys())[column]] if row else None

    async def fetch_col(
        self, query: str, params: Optional[dict | tuple] = None, column: int = 0
    ) -> list[Any]:
        """Fetch a single column from all rows."""
        rows = await self.fetch_all(query, params)
        if not rows:
            return []
        key = list(rows[0].keys())[column]
        return [row[key] for row in rows]

    def get_query_log(self) -> list[dict]:
        """Get the query log."""
        return self._query_log.copy()

    def clear_query_log(self) -> None:
        """Clear the query log."""
        self._query_log.clear()

    def get_slow_queries(self) -> list[dict]:
        """Get all slow queries from the log."""
        return [q for q in self._query_log if q["is_slow"]]

    async def __aenter__(self) -> Database:
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.disconnect()


class Transaction:
    """Transaction context for executing queries within a transaction."""

    def __init__(self, db: Database, connection: Any):
        self._db = db
        self._connection = connection

    async def execute(self, query: str, params: Optional[tuple] = None) -> int:
        """Execute a query within the transaction."""
        start_time = datetime.now()
        cursor = await self._connection.execute(query, params or ())
        duration = (datetime.now() - start_time).total_seconds()
        await self._db._log_query(query, params or (), duration)
        return cursor.rowcount

    async def fetch_one(self, query: str, params: Optional[tuple] = None) -> Optional[dict]:
        """Fetch a single row within the transaction."""
        start_time = datetime.now()
        cursor = await self._connection.execute(query, params or ())
        row = await cursor.fetchone()
        duration = (datetime.now() - start_time).total_seconds()
        await self._db._log_query(query, params or (), duration)
        return dict(row) if row else None

    async def fetch_all(self, query: str, params: Optional[tuple] = None) -> list[dict]:
        """Fetch all rows within the transaction."""
        start_time = datetime.now()
        cursor = await self._connection.execute(query, params or ())
        rows = await cursor.fetchall()
        duration = (datetime.now() - start_time).total_seconds()
        await self._db._log_query(query, params or (), duration)
        return [dict(row) for row in rows]

    async def fetch_val(self, query: str, params: Optional[tuple] = None, column: int = 0) -> Any:
        """Fetch a single value within the transaction."""
        row = await self.fetch_one(query, params)
        return row[list(row.keys())[column]] if row else None


def create_database(url: str) -> Database:
    """Create a new Database instance from URL."""
    return Database(url)
