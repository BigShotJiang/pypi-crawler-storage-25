"""
Telegram Bot with PyAsyncDB - Complete Example

A Telegram bot that manages users with full database integration:
- ORM with relationships
- Transactions
- Soft deletes
- Event hooks
- Connection pooling
- Query caching
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from asyncdb import (
    Database,
    Model,
    Field,
)

# Pydantic integration (optional)
try:
    from asyncdb import PydanticModelMixin
    HAS_PYDANTIC = True
except ImportError:
    HAS_PYDANTIC = False
    PydanticModelMixin = object  # Fallback

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# =============================================================================
# Database Configuration
# =============================================================================

db = Database(
    "postgresql://postgres:postgres@localhost:5432/botdb",
    pool_size=10,
    echo=False,
    slow_query_threshold=1.0,
    health_check_interval=30.0,
    max_idle_time=300.0,
    retry_on_disconnect=True,
)


# =============================================================================
# Event Hooks
# =============================================================================

@db.connect
async def on_connect(database):
    """Called when database connects."""
    logger.info("✅ Database connected!")


@db.on_disconnect
async def on_disconnect(database):
    """Called when database disconnects."""
    logger.info("❌ Database disconnected!")


@db.on_query
async def on_query(database, query, params):
    """Log all queries."""
    logger.debug(f"📝 Query: {query} | Params: {params}")


@db.on_error
async def on_error(database, error, query=None):
    """Handle database errors."""
    logger.error(f"🚨 Database error: {error} | Query: {query}")


# =============================================================================
# Database Models
# =============================================================================

class User(Model, PydanticModelMixin if HAS_PYDANTIC else object):
    """User model with soft delete support."""
    
    __tablename__ = "users"
    
    id = Field(primary_key=True, auto_increment=True)
    telegram_id = Field(type="BIGINT", unique=True, nullable=False, index=True)
    username = Field(type="VARCHAR", max_length=255, nullable=True)
    first_name = Field(type="VARCHAR", max_length=255, nullable=False)
    last_name = Field(type="VARCHAR", max_length=255, nullable=True)
    language_code = Field(type="VARCHAR", max_length=10, default="en")
    is_premium = Field(type="BOOLEAN", default=False)
    is_deleted = Field(type="BOOLEAN", default=False)  # Soft delete
    created_at = Field(type="TIMESTAMP", default="NOW()")
    updated_at = Field(type="TIMESTAMP", default="NOW()")
    
    def __repr__(self):
        return f"<User {self.telegram_id}: {self.first_name}>"


class Message(Model):
    """Message history model."""
    
    __tablename__ = "messages"
    
    id = Field(primary_key=True, auto_increment=True)
    user_id = Field(type="BIGINT", foreign_key="users.telegram_id", on_delete="CASCADE")
    chat_id = Field(type="BIGINT", nullable=False)
    message_text = Field(type="TEXT", nullable=True)
    message_date = Field(type="TIMESTAMP", nullable=False)
    is_deleted = Field(type="BOOLEAN", default=False)
    created_at = Field(type="TIMESTAMP", default="NOW()")


class Subscription(Model):
    """Premium subscription model."""
    
    __tablename__ = "subscriptions"
    
    id = Field(primary_key=True, auto_increment=True)
    user_id = Field(type="BIGINT", foreign_key="users.telegram_id", on_delete="CASCADE")
    plan_type = Field(type="VARCHAR", max_length=50, nullable=False)
    started_at = Field(type="TIMESTAMP", default="NOW()")
    expires_at = Field(type="TIMESTAMP", nullable=True)
    is_active = Field(type="BOOLEAN", default=True)


# =============================================================================
# Database Helper Functions
# =============================================================================

async def init_database():
    """Initialize database tables."""
    async with db:
        await User.create_table(db)
        await Message.create_table(db)
        await Subscription.create_table(db)
        logger.info("✅ Database tables created!")


async def get_or_create_user(telegram_user) -> User:
    """Get existing user or create new one."""
    # Try to find existing user
    user = await User.objects().filter(telegram_id=telegram_user.id).first(db)
    
    if user:
        # Update existing user
        user.username = telegram_user.username
        user.first_name = telegram_user.first_name
        user.last_name = telegram_user.last_name
        user.language_code = telegram_user.language_code
        user.is_premium = telegram_user.is_premium or False
        user.updated_at = datetime.now()
        await user.update(db)
    else:
        # Create new user
        user = User(
            telegram_id=telegram_user.id,
            username=telegram_user.username,
            first_name=telegram_user.first_name,
            last_name=telegram_user.last_name or "",
            language_code=telegram_user.language_code or "en",
            is_premium=telegram_user.is_premium or False,
        )
        await user.insert(db)
        logger.info(f"✨ New user registered: {user}")
    
    return user


async def save_message(user_id: int, chat_id: int, text: str, date: datetime):
    """Save message to history."""
    message = Message(
        user_id=user_id,
        chat_id=chat_id,
        message_text=text,
        message_date=date,
    )
    await message.insert(db)


async def get_user_stats(user: User) -> dict:
    """Get user statistics."""
    # Count messages
    message_count = await db.fetch_val(
        "SELECT COUNT(*) FROM messages WHERE user_id = $1 AND is_deleted = FALSE",
        (user.telegram_id,)
    )
    
    # Check subscription
    subscription = await Subscription.objects().filter(
        user_id=user.telegram_id,
        is_active=True
    ).first(db)
    
    return {
        "user_id": user.telegram_id,
        "username": user.username or user.first_name,
        "message_count": message_count,
        "is_premium": user.is_premium,
        "has_active_subscription": subscription is not None,
        "registered_at": user.created_at,
    }


# =============================================================================
# Bot Commands
# =============================================================================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    user = await get_or_create_user(update.effective_user)
    
    welcome_text = (
        f"👋 Cześć {user.first_name}!\n\n"
        f"Jestem botem z pełną integracją bazy danych PyAsyncDB.\n\n"
        f"Twoje dane:\n"
        f"• ID: `{user.telegram_id}`\n"
        f"• Username: @{user.username or 'brak'}\n"
        f"• Premium: {'✅ Tak' if user.is_premium else '❌ Nie'}\n\n"
        f"Dostępne komendy:\n"
        f"/stats - Twoje statystyki\n"
        f"/help - Pomoc\n"
        f"/delete - Usuń swoje konto"
    )
    
    await update.message.reply_text(welcome_text, parse_mode="Markdown")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    help_text = (
        "📖 **Pomoc**\n\n"
        "Dostępne komendy:\n\n"
        "/start - Powitanie i rejestracja\n"
        "/stats - Twoje statystyki\n"
        "/delete - Usuń swoje konto (soft delete)\n"
        "/restore - Przywróć usunięte konto\n"
        "/help - Ta wiadomość\n\n"
        "Bot używa PyAsyncDB z:\n"
        "• ORM z relacjami\n"
        "• Transakcjami\n"
        "• Soft deletes\n"
        "• Connection pooling\n"
        "• Event hooks"
    )
    
    await update.message.reply_text(help_text, parse_mode="Markdown")


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /stats command."""
    user = await User.objects().filter(telegram_id=update.effective_user.id).first(db)
    
    if not user:
        await update.message.reply_text("❌ Nie znaleziono użytkownika. Użyj /start")
        return
    
    stats = await get_user_stats(user)
    
    stats_text = (
        f"📊 **Twoje statystyki**\n\n"
        f"👤 Użytkownik: @{stats['username']}\n"
        f"💬 Wiadomości: `{stats['message_count']}`\n"
        f"⭐ Premium: {'✅' if stats['is_premium'] else '❌'}\n"
        f"🎫 Subskrypcja: {'✅ Aktywna' if stats['has_active_subscription'] else '❌ Brak'}\n"
        f"📅 Zarejestrowano: `{stats['registered_at']}`"
    )
    
    await update.message.reply_text(stats_text, parse_mode="Markdown")


async def delete_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /delete command - soft delete."""
    user = await User.objects().filter(telegram_id=update.effective_user.id).first(db)
    
    if not user:
        await update.message.reply_text("❌ Nie znaleziono użytkownika.")
        return
    
    # Soft delete user
    await user.soft_delete(db)
    
    await update.message.reply_text(
        "⚠️ Twoje konto zostało oznaczone jako usunięte.\n"
        "Użyj /restore aby przywrócić."
    )


async def restore_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /restore command - restore soft deleted user."""
    # Include deleted users in search
    user = await User.objects(include_deleted=True).filter(
        telegram_id=update.effective_user.id
    ).first(db)
    
    if not user:
        await update.message.reply_text("❌ Nie znaleziono użytkownika.")
        return
    
    if not getattr(user, "is_deleted", False):
        await update.message.reply_text("ℹ️ Twoje konto nie jest usunięte.")
        return
    
    # Restore user
    async with db.transaction() as tx:
        await tx.execute(
            "UPDATE users SET is_deleted = FALSE WHERE telegram_id = $1",
            (user.telegram_id,)
        )
        await tx.execute(
            "UPDATE messages SET is_deleted = FALSE WHERE user_id = $1",
            (user.telegram_id,)
        )
    
    await update.message.reply_text("✅ Konto zostało przywrócone!")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle incoming messages."""
    user = await get_or_create_user(update.effective_user)
    
    # Save message with transaction
    async with db.transaction():
        await save_message(
            user_id=user.telegram_id,
            chat_id=update.effective_chat.id,
            text=update.message.text,
            date=update.message.date,
        )
    
    # Echo with database info
    await update.message.reply_text(
        f"📨 Zapisałem twoją wiadomość!\n"
        f"Łącznie wiadomości: "
        f"`{await db.fetch_val('SELECT COUNT(*) FROM messages WHERE user_id = $1', (user.telegram_id,))}`",
        parse_mode="Markdown"
    )


async def bulk_import_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demonstrate bulk operations."""
    # Create test users
    test_users = [
        User(
            telegram_id=999001 + i,
            username=f"user{i}",
            first_name=f"Test{i}",
            language_code="pl",
        )
        for i in range(10)
    ]
    
    # Bulk insert
    count = await User.bulk_insert(db, test_users)
    logger.info(f"✅ Bulk inserted {count} users")
    
    await update.message.reply_text(f"✅ Dodano {count} testowych użytkowników!")


async def transaction_demo_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demonstrate transactions."""
    user = await get_or_create_user(update.effective_user)
    
    try:
        async with db.transaction() as tx:
            # Insert message in transaction
            await tx.execute(
                "INSERT INTO messages (user_id, chat_id, message_text, message_date) VALUES ($1, $2, $3, $4)",
                (user.telegram_id, update.effective_chat.id, "Transaction demo", datetime.now())
            )
            
            # This will succeed
            await tx.execute(
                "UPDATE users SET updated_at = $1 WHERE telegram_id = $2",
                (datetime.now(), user.telegram_id)
            )
            
            # Uncomment to test rollback:
            # await tx.execute("SELECT * FROM nonexistent_table")
        
        await update.message.reply_text("✅ Transakcja zakończona sukcesem!")
        
    except Exception as e:
        await update.message.reply_text(f"❌ Transakcja cofnięta: {e}")


async def query_log_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show query log."""
    log = db.get_query_log()
    slow = db.get_slow_queries()
    
    text = (
        f"📝 **Query Log**\n\n"
        f"Łącznie zapytań: `{len(log)}`\n"
        f"🐌 Wolne zapytania: `{len(slow)}`\n\n"
    )
    
    if slow:
        text += "**Ostatnie wolne zapytania:**\n"
        for q in slow[-3:]:
            text += f"• {q['duration']:.3f}s\n"
    
    await update.message.reply_text(text, parse_mode="Markdown")


# =============================================================================
# Main
# =============================================================================

async def post_init(application: Application):
    """Initialize database after bot starts."""
    await init_database()


def main():
    """Start the bot."""
    # Create application
    application = (
        Application.builder()
        .token("YOUR_BOT_TOKEN_HERE")  # Replace with your bot token
        .post_init(post_init)
        .build()
    )
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("delete", delete_command))
    application.add_handler(CommandHandler("restore", restore_command))
    application.add_handler(CommandHandler("bulk", bulk_import_command))
    application.add_handler(CommandHandler("transaction", transaction_demo_command))
    application.add_handler(CommandHandler("log", query_log_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Start bot
    print("🤖 Starting bot...")
    print("📊 PyAsyncDB Features:")
    print("  ✅ ORM with Models")
    print("  ✅ Transactions")
    print("  ✅ Soft Deletes")
    print("  ✅ Event Hooks")
    print("  ✅ Connection Pooling")
    print("  ✅ Query Logging")
    print("  ✅ Health Checks")
    print("  ✅ Bulk Operations")
    print("\n🚀 Bot is running! Press Ctrl+C to stop.")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
