"""
AsyncDB - Basic Usage Examples
"""

import asyncio
from asyncdb import Database, Model, Field, select, insert


async def basic_operations():
    """Demonstrate basic database operations."""
    print("=== Basic Operations ===\n")

    db = Database("sqlite:///example.db")

    async with db:
        # Create table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100),
                email VARCHAR(255),
                age INTEGER
            )
        """)

        # Insert
        await db.execute(
            "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
            ("Alice", "alice@example.com", 25),
        )
        await db.execute(
            "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
            ("Bob", "bob@example.com", 30),
        )

        # Fetch one
        user = await db.fetch_one("SELECT * FROM users WHERE name = ?", ("Alice",))
        print(f"Found user: {user}")

        # Fetch all
        users = await db.fetch_all("SELECT * FROM users")
        print(f"All users: {users}")

        # Update
        await db.execute(
            "UPDATE users SET age = ? WHERE name = ?",
            (26, "Alice"),
        )

        # Delete
        await db.execute("DELETE FROM users WHERE name = ?", ("Bob",))

        # Fetch value
        count = await db.fetch_val("SELECT COUNT(*) FROM users")
        print(f"Total users: {count}")


async def orm_example():
    """Demonstrate ORM usage."""
    print("\n=== ORM Example ===\n")

    db = Database("sqlite:///orm_example.db")

    class User(Model):
        __tablename__ = "users"

        id = Field(primary_key=True, auto_increment=True)
        name = Field(type="VARCHAR", max_length=100, nullable=False)
        email = Field(type="VARCHAR", max_length=255, unique=True)
        age = Field(type="INTEGER", default=0)

    async with db:
        # Create table
        await User.drop_table(db)
        await User.create_table(db)

        # Create instances
        user1 = User(name="Charlie", email="charlie@example.com", age=28)
        user2 = User(name="Diana", email="diana@example.com", age=32)

        await user1.insert(db)
        await user2.insert(db)

        # Query with filters
        young_users = await User.objects().filter(age__lt=30).all(db)
        print(f"Users under 30: {[u.name for u in young_users]}")

        # Get first
        first = await User.objects().order_by("name").first(db)
        print(f"First user: {first}")

        # Count
        count = await User.objects().count(db)
        print(f"Total users: {count}")

        # Update
        user1.age = 29
        await user1.update(db)

        # Delete
        await user2.delete(db)


async def query_builder_example():
    """Demonstrate query builder usage."""
    print("\n=== Query Builder Example ===\n")

    # SELECT
    q = (
        select("users")
        .columns("id", "name", "email")
        .where("age > $1", 18)
        .and_where("age < $2", 50)
        .order_by("name")
        .limit(10)
    )
    sql, params = q.build()
    print(f"SELECT query: {sql}")
    print(f"Parameters: {params}")

    # INSERT
    q = insert("users").columns("name", "email").values("Eve", "eve@example.com")
    sql, params = q.build()
    print(f"\nINSERT query: {sql}")
    print(f"Parameters: {params}")


async def main():
    """Run all examples."""
    try:
        await basic_operations()
        await orm_example()
        await query_builder_example()
        print("\n✅ All examples completed!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
