//! Streaming agent completion response types.
//!
//! These types are used when `stream: true`. Responses arrive as
//! Server-Sent Events (SSE), with each chunk containing a delta
//! of the full response.

mod agent_completion_chunk;
mod assistant_response_chunk;
mod message_chunk;
mod object;

pub use agent_completion_chunk::*;
pub use assistant_response_chunk::*;
pub use message_chunk::*;
pub use object::*;

#[cfg(test)]
mod agent_completion_chunk_tests;
