//! Agent definitions, configuration, and completion API types.
//!
//! An **Agent** is a fully-specified configuration of a single upstream
//! language model. It encapsulates:
//!
//! - Model identity (which LLM to use)
//! - Prompt structure (prefix/suffix messages)
//! - Decoding parameters (temperature, top_p, etc.)
//! - Provider preferences and routing
//! - Output mode, reasoning settings, and verbosity
//!
//! # Content-Addressed Identity
//!
//! Agents use **content-addressed identifiers** - their ID is derived
//! deterministically from their full definition using XXHash3-128. This ensures:
//!
//! - Two identical definitions always produce the same ID
//! - IDs can be computed anywhere (server, client, browser via WASM)
//! - No hidden mutation or "latest version" ambiguity
//!
//! # Normalization
//!
//! Before computing an ID, definitions are normalized via [`InlineAgentBase::prepare`]:
//!
//! - Default values are removed (e.g., `temperature: 1.0` becomes `None`)
//! - Empty collections are removed
//! - Collections are sorted for deterministic ordering

mod agent;
pub mod claude_agent_sdk;
pub mod codex_sdk;
pub mod completions;
mod continuation;
mod mcp;
pub mod mock;
pub mod openrouter;
mod output_mode;
pub mod request;
pub mod response;
mod upstream;

pub use agent::*;
pub use continuation::*;
pub use mcp::*;
pub use output_mode::*;
pub use upstream::*;

#[cfg(feature = "http")]
mod http;

#[cfg(feature = "http")]
pub use http::*;
