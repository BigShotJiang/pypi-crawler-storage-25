# autogen-rubric

**Post-quantum AI decision attestation for AutoGen, LlamaIndex, and any Python AI pipeline.**

Every decision your AI agents make, cryptographically signed and anchored permanently to Hedera Consensus Service. Built for EU AI Act Article 12 compliance. Zero required dependencies.

    pip install autogen-rubric

## Quick Start

    from autogen_rubric import RubricClient

    client = RubricClient(api_key="your-rubric-api-key")

    result = client.attest(
        agent_id="loan-underwriting-agent-v2",
        output="Application #12345 approved. Confidence: 0.94.",
        confidence=0.94,
    )

    print(result.attestation_id)  # Verifiable forever on Hedera
    print(result.stage)           # "pending" -> "anchored"

Get a free API key at rubric-protocol.com.

## AutoGen Integration

    from autogen import AssistantAgent, UserProxyAgent
    from autogen_rubric import RubricClient, RubricAutoGenHook

    client = RubricClient(api_key="your-key", background_queue=True)
    hook = RubricAutoGenHook(client=client, pipeline_id="compliance-pipeline-v1")

    assistant = AssistantAgent("assistant", llm_config=llm_config)
    hook.register(assistant)  # Every message now attested

    user_proxy = UserProxyAgent("user")
    user_proxy.initiate_chat(assistant, message="Review this loan application...")

## LlamaIndex Integration

    from llama_index.core.callbacks import CallbackManager
    from autogen_rubric import RubricClient, RubricLlamaIndexHandler

    client = RubricClient(api_key="your-key", background_queue=True)
    handler = RubricLlamaIndexHandler(client=client)
    callback_manager = CallbackManager([handler])

## Function Decorator

    from autogen_rubric import RubricClient, attest_function

    client = RubricClient(api_key="your-key")

    @attest_function(client=client, agent_id="risk-scorer-v2")
    def score_risk(application: dict) -> str:
        return "approved" if application["score"] > 0.7 else "declined"

## Configuration

| Parameter | Default | Description |
|---|---|---|
| api_key | required | Your Rubric API key |
| node | "us" | Federation node: us, sg, jp, ca, eu, auto |
| enterprise | False | Merkle batching for high volume |
| background_queue | False | Non-blocking attestation |
| flush_interval | 5.0 | Seconds between queue flushes |
| timeout | 15 | HTTP timeout in seconds |

## Requirements

- Python 3.9+
- Zero required dependencies for core
- AutoGen: pip install autogen-rubric[autogen]
- LlamaIndex: pip install autogen-rubric[llama]
- Both: pip install autogen-rubric[all]

## EU AI Act Article 12

Enforcement deadline: August 2, 2026.

rubric-protocol.com | Scott@Rubric-Protocol.com
Echelon Intelligence Group LLC | Wyoming, USA
