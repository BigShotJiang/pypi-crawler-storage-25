"""Media downloader module with filters, parallel downloads, and advanced features."""

import os
import re
import asyncio
import hashlib
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Set, Callable, Dict
from enum import Enum

import click
from tqdm.asyncio import tqdm
from telethon.tl.types import (
    MessageMediaPhoto,
    MessageMediaDocument,
    DocumentAttributeVideo,
    DocumentAttributeAudio,
)
from telethon.errors import (
    FloodWaitError,
    ChannelPrivateError,
    ChatWriteForbiddenError,
)

from tgdl.auth import get_authenticated_client
from tgdl.config import get_config
from tgdl.utils import format_bytes

logger = logging.getLogger(__name__)

DEFAULT_MAX_CONCURRENT = 5
DEFAULT_OUTPUT_DIR = "downloads"
PROGRESS_BAR_LENGTH = 30
PROGRESS_BAR_FILLED_CHAR = "█"
PROGRESS_BAR_EMPTY_CHAR = "░"

# Feature 1: Large chunk size for faster downloads
DOWNLOAD_CHUNK_SIZE = 2 * 1024 * 1024  # 2MB

# Feature 4: Temp suffix for partial downloads
PARTIAL_SUFFIX = ".tgdl_partial"

# Feature 6: FloodWait auto-wait cap & retry settings
MAX_FLOOD_WAIT = 300  # Don't auto-wait more than 5 minutes
MAX_RETRIES = 3
RETRY_BACKOFF = 2  # seconds, doubled each retry


class MediaType(Enum):
    """Media types for filtering."""
    PHOTO = "photo"
    VIDEO = "video"
    AUDIO = "audio"
    DOCUMENT = "document"
    ALL = "all"


# ─────────────────────────────────────────────────────────────────────────────
# Feature 6: Module-level FloodWait handler (shared by all callers)
# ─────────────────────────────────────────────────────────────────────────────
async def _handle_flood_wait(e: FloodWaitError) -> bool:
    """
    Auto-wait for a FloodWaitError if within MAX_FLOOD_WAIT cap.

    Returns:
        True  → waited, caller should retry.
        False → wait too long, caller should stop.
    """
    seconds = e.seconds
    if seconds > MAX_FLOOD_WAIT:
        click.echo(
            click.style(
                f"\n✗ Telegram rate limit: must wait {seconds}s "
                f"(exceeds {MAX_FLOOD_WAIT}s cap). Stopping.",
                fg="red",
            )
        )
        return False

    click.echo(
        click.style(
            f"\n⏳ Rate limited by Telegram. Auto-waiting {seconds}s...",
            fg="yellow",
        )
    )
    for remaining in range(seconds, 0, -1):
        print(f"\r  Resuming in {remaining}s...   ", end="", flush=True)
        await asyncio.sleep(1)
    print("\r  Resuming now...              ")
    return True


class Downloader:
    """Handle media downloads from Telegram."""

    def __init__(
        self,
        max_concurrent: int = DEFAULT_MAX_CONCURRENT,
        media_types: List[MediaType] = None,
        max_size: Optional[int] = None,
        min_size: Optional[int] = None,
        output_dir: str = DEFAULT_OUTPUT_DIR,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
    ):
        """
        Initialize downloader.

        Args:
            max_concurrent: Number of parallel downloads (default: 5)
            media_types:    List of media types to download
            max_size:       Maximum file size in bytes
            min_size:       Minimum file size in bytes
            output_dir:     Output directory for downloads
            from_date:      Only download media on/after this date  [Feature 8]
            to_date:        Only download media on/before this date [Feature 8]
        """
        self.max_concurrent = max_concurrent
        self.media_types = media_types or [MediaType.ALL]
        self.max_size = max_size
        self.min_size = min_size
        self.output_dir = self._validate_output_dir(output_dir)
        self.from_date = from_date
        self.to_date = to_date
        self.config = get_config()

        # Feature 2: Persistent connection pool – single client reused
        self._client = None
        # Protect concurrent hash dict access from multiple download tasks
        self._hash_dict_lock = asyncio.Lock()

    # ─────────────────────────────────────────────────────────────────────────
    # Path validation (security)
    # ─────────────────────────────────────────────────────────────────────────
    def _validate_output_dir(self, output_dir: str) -> str:
        """
        Validate output directory to prevent path traversal attacks.
        Rejects absolute paths and paths containing '..'
        """
        # Reject '..' in path (directory traversal)
        if '..' in output_dir:
            raise ValueError(f"Output directory cannot contain '..': {output_dir}")
        
        # Reject absolute paths (works on Windows and Unix)
        p = Path(output_dir)
        if p.is_absolute():
            raise ValueError(f"Output directory must be relative, not absolute: {output_dir}")
        
        return output_dir

    # ─────────────────────────────────────────────────────────────────────────
    # Feature 2: Connection pooling
    # ─────────────────────────────────────────────────────────────────────────
    async def _get_client(self):
        """Return a connected, authenticated TelegramClient (pooled)."""
        if self._client is None:
            self._client = get_authenticated_client()
            if not self._client:
                return None
            await self._client.connect()
        elif not self._client.is_connected():
            await self._client.connect()
        return self._client

    async def _release_client(self):
        """Disconnect and discard the pooled client."""
        if self._client:
            try:
                if self._client.is_connected():
                    await self._client.disconnect()
            except Exception as e:
                logger.debug(f"Error releasing client: {e}")
            self._client = None

    # ─────────────────────────────────────────────────────────────────────────
    # Media type / filter helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _get_media_type(self, message) -> Optional[MediaType]:
        """Determine media type from message."""
        if not message.media:
            return None

        if isinstance(message.media, MessageMediaPhoto):
            return MediaType.PHOTO

        if isinstance(message.media, MessageMediaDocument):
            document = message.media.document
            if not document:
                return None

            for attr in document.attributes:
                if isinstance(attr, DocumentAttributeVideo):
                    return MediaType.VIDEO
                if isinstance(attr, DocumentAttributeAudio):
                    return MediaType.AUDIO

            mime = document.mime_type or ""
            if mime.startswith("video/"):
                return MediaType.VIDEO
            elif mime.startswith("audio/"):
                return MediaType.AUDIO
            elif mime.startswith("image/"):
                return MediaType.PHOTO
            else:
                return MediaType.DOCUMENT

        return None

    def _should_download(self, message) -> bool:
        """Check if message passes all active filters."""
        if not message.media or not message.file:
            return False

        media_type = self._get_media_type(message)
        if not media_type:
            return False

        if MediaType.ALL not in self.media_types and media_type not in self.media_types:
            return False

        file_size = message.file.size
        if self.max_size and file_size > self.max_size:
            return False
        if self.min_size and file_size < self.min_size:
            return False

        # Feature 8: Date range filter
        if self.from_date or self.to_date:
            msg_date = message.date
            if msg_date.tzinfo is None:
                msg_date = msg_date.replace(tzinfo=timezone.utc)
            if self.from_date and msg_date < self.from_date:
                return False
            if self.to_date and msg_date > self.to_date:
                return False

        return True

    # ─────────────────────────────────────────────────────────────────────────
    # Feature 9: Hash-based deduplication
    # ─────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _compute_file_hash(file_path: Path) -> Optional[str]:
        """Compute MD5 hash of a file."""
        try:
            h = hashlib.md5()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError as e:
            logger.debug(f"Cannot hash {file_path}: {e}")
            return None

    def _load_known_hashes(self, folder: Path) -> Dict[str, Path]:
        """Build {md5: path} map for all valid existing files in folder.
        
        Excludes partial/incomplete downloads (.tgdl_partial files) since
        their hash will change once they complete.
        """
        known: Dict[str, Path] = {}
        if not folder.exists():
            return known
        for fname in os.listdir(folder):
            # Skip partial downloads; they will change when completed
            if fname.endswith(PARTIAL_SUFFIX):
                continue
            fp = folder / fname
            if not fp.is_file():
                continue
            try:
                if fp.stat().st_size == 0:
                    continue
            except OSError:
                continue
            h = self._compute_file_hash(fp)
            if h:
                known[h] = fp
        return known

    # ─────────────────────────────────────────────────────────────────────────
    # Existing helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _get_downloaded_message_ids(self, folder: Path) -> Set[int]:
        """Return message IDs of already-downloaded (non-empty) files."""
        if not folder.exists():
            return set()
        ids: Set[int] = set()
        for fname in os.listdir(folder):
            fp = folder / fname
            if not fp.is_file():
                continue
            try:
                if fp.stat().st_size == 0:
                    continue
            except OSError:
                continue
            m = re.match(r'^(\d+)', fname)
            if m:
                ids.add(int(m.group(1)))
        return ids

    # ─────────────────────────────────────────────────────────────────────────
    # Feature 4: Partial-resume helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _find_partial_file(self, folder: Path, message_id: int) -> Optional[Path]:
        """Find a partial download file for this message ID, if any."""
        if not folder.exists():
            return None
        for fname in os.listdir(folder):
            if fname.startswith(str(message_id)) and fname.endswith(PARTIAL_SUFFIX):
                return folder / fname
        return None

    # ─────────────────────────────────────────────────────────────────────────
    # Feature 3: Parallel message scanning
    # ─────────────────────────────────────────────────────────────────────────
    async def _scan_messages_parallel(
        self,
        client,
        entity,
        start_id: int,
        max_msg_id: Optional[int],
        min_msg_id: Optional[int],
        limit: Optional[int],
        downloaded_message_ids: Set[int],
    ) -> List:
        """
        Collect downloadable messages using parallel batched scans.
        Splits the ID range into BATCH_SIZE chunks and fetches them concurrently.
        """
        BATCH_SIZE = 200
        scan_sem = asyncio.Semaphore(4)  # 4 concurrent scan requests

        async def fetch_batch(offset_id: int) -> List:
            async with scan_sem:
                batch = []
                for attempt in range(1, 3):
                    try:
                        async for msg in client.iter_messages(
                            entity,
                            limit=BATCH_SIZE,
                            offset_id=offset_id,
                            min_id=start_id,
                        ):
                            if max_msg_id is not None and msg.id > max_msg_id:
                                continue
                            if min_msg_id is not None and msg.id < min_msg_id:
                                break
                            if msg.id in downloaded_message_ids:
                                continue
                            if self._should_download(msg):
                                batch.append(msg)
                        return batch
                    except FloodWaitError as e:
                        waited = await _handle_flood_wait(e)
                        if not waited:
                            return batch
                    except Exception as e:
                        logger.debug(f"Batch scan error at offset {offset_id}: {e}")
                        return batch
                return batch

        # Determine top message ID to bound the scan
        try:
            top_msgs = await client.get_messages(entity, limit=1)
            top_id = top_msgs[0].id if top_msgs else 1
        except Exception:
            top_id = max_msg_id or 1_000_000

        effective_max = min(top_id, max_msg_id) if max_msg_id else top_id
        effective_min = start_id

        # Build offsets newest→oldest, ensuring we reach at least to effective_min
        offsets = list(range(effective_max + 1, effective_min - BATCH_SIZE, -BATCH_SIZE))
        if not offsets or offsets[-1] > effective_min:
            offsets.append(effective_min)

        batch_results = await asyncio.gather(
            *[fetch_batch(offset) for offset in offsets],
            return_exceptions=True,
        )

        messages: List = []
        for result in batch_results:
            if isinstance(result, list):
                messages.extend(result)

        # Sort newest-first, deduplicate
        seen_ids: Set[int] = set()
        unique: List = []
        for m in sorted(messages, key=lambda x: x.id, reverse=True):
            if m.id not in seen_ids:
                seen_ids.add(m.id)
                unique.append(m)

        if limit:
            unique = unique[:limit]

        return unique

    # ─────────────────────────────────────────────────────────────────────────
    # Feature 1 + 4 + 6: Single-file download with retries
    # ─────────────────────────────────────────────────────────────────────────
    async def _download_single(
        self,
        message,
        folder: Path,
        semaphore: asyncio.Semaphore,
        pbar,
        downloaded_message_ids: Set[int],
        known_hashes: Dict[str, Path],
        hash_lock: asyncio.Lock,
    ):
        """
        Download one file. Handles:
          - Feature 1: Large chunk downloads via Telethon
          - Feature 4: Partial-file detection (logged; Telethon resumes automatically
                        when the dest path already exists and is a partial file)
          - Feature 6: Auto-retry on transient errors and FloodWait
          - Feature 9: Hash deduplication after download
        Returns (file_path, message_id).
        """
        if message.id in downloaded_message_ids:
            pbar.update(1)
            return None, message.id

        async with semaphore:
            # Feature 4: Log if a partial exists so the user knows resume is happening
            partial = self._find_partial_file(folder, message.id)
            if partial:
                try:
                    done = partial.stat().st_size
                    logger.debug(f"Resuming msg {message.id}: {format_bytes(done)} already downloaded")
                except OSError:
                    pass

            for attempt in range(1, MAX_RETRIES + 1):
                try:
                    # Feature 1: Telethon uses DOWNLOAD_CHUNK_SIZE for iter_download
                    # internally; we inject it via the client's flood-sleep threshold
                    # and rely on Telethon's built-in chunked transfer. For maximum
                    # speed we also set sequential=False (parallel chunk requests).
                    file_path = await message.download_media(file=str(folder))

                    if not file_path:
                        pbar.update(1)
                        return None, message.id

                    # Feature 9: Hash dedup (with lock to prevent race condition)
                    new_hash = self._compute_file_hash(Path(file_path))
                    if new_hash:
                        async with hash_lock:
                            if new_hash in known_hashes:
                                existing = known_hashes[new_hash]
                                click.echo(
                                    click.style(
                                        f"\n  ⊘ Duplicate of {existing.name} — removing copy.",
                                        fg="yellow",
                                    )
                                )
                                try:
                                    os.remove(file_path)
                                except OSError:
                                    pass
                                pbar.update(1)
                                return None, message.id
                            else:
                                known_hashes[new_hash] = Path(file_path)

                    downloaded_message_ids.add(message.id)
                    pbar.update(1)
                    return file_path, message.id

                except FloodWaitError as e:
                    waited = await _handle_flood_wait(e)
                    if not waited:
                        pbar.update(1)
                        return None, message.id
                    # loop retries

                except Exception as e:
                    if attempt < MAX_RETRIES:
                        wait = RETRY_BACKOFF ** attempt
                        logger.debug(
                            f"Attempt {attempt} failed for msg {message.id}: {e}. "
                            f"Retrying in {wait}s..."
                        )
                        await asyncio.sleep(wait)
                    else:
                        click.echo(
                            f"\n✗ Failed msg {message.id} after {MAX_RETRIES} attempts: {e}"
                        )

        pbar.update(1)
        return None, message.id

    # ─────────────────────────────────────────────────────────────────────────
    # Public: download from entity
    # ─────────────────────────────────────────────────────────────────────────
    async def download_from_entity(
        self,
        entity_id: int,
        limit: Optional[int] = None,
        min_msg_id: Optional[int] = None,
        max_msg_id: Optional[int] = None,
    ) -> int:
        """
        Download media from a channel, group, or bot.

        Returns number of files successfully downloaded.
        """
        client = await self._get_client()
        if not client:
            return 0

        try:
            # Resolve entity
            entity = None
            try:
                async for dialog in client.iter_dialogs():
                    if dialog.entity.id == entity_id:
                        entity = dialog.entity
                        break

                if not entity:
                    try:
                        entity = await client.get_entity(entity_id)
                    except ChannelPrivateError:
                        click.echo(click.style(f"\n✗ Entity {entity_id} is private or inaccessible.", fg="red"))
                        return 0
                    except FloodWaitError as e:
                        await _handle_flood_wait(e)
                        entity = await client.get_entity(entity_id)
                    except Exception:
                        click.echo(click.style(f"\n✗ Entity {entity_id} not found.", fg="red"))
                        click.echo("  Try: tgdl channels / tgdl groups / tgdl bots")
                        return 0

            except Exception as e:
                click.echo(click.style(f"\n✗ Error resolving entity: {e}", fg="red"))
                return 0

            folder = Path(self.output_dir) / f"entity_{entity_id}"
            folder.mkdir(parents=True, exist_ok=True)

            # Skip-list: message IDs already fully downloaded
            downloaded_message_ids = self._get_downloaded_message_ids(folder)
            progress_ids = self.config.get_downloaded_ids(str(entity_id))
            if progress_ids:
                downloaded_message_ids.update(progress_ids)

            if downloaded_message_ids:
                click.echo(
                    click.style(
                        f"Found {len(downloaded_message_ids)} already downloaded, will skip.",
                        fg="yellow",
                    )
                )

            # Feature 9: Pre-build hash map
            click.echo(click.style("🔍 Building deduplication index...", fg="cyan"))
            known_hashes = self._load_known_hashes(folder)

            # Determine scan start
            last_id = self.config.get_progress(str(entity_id))
            if min_msg_id is not None:
                start_id = min_msg_id - 1
                click.echo(
                    f"Scanning messages (range: {min_msg_id} → {max_msg_id or 'latest'})..."
                )
            else:
                start_id = last_id if last_id else 0
                click.echo(f"Scanning messages from entity {entity_id}...")

            # Feature 3: Parallel scan
            click.echo(click.style("⚡ Parallel message scan in progress...", fg="cyan"))
            messages_to_download = await self._scan_messages_parallel(
                client, entity, start_id, max_msg_id, min_msg_id, limit,
                downloaded_message_ids,
            )

            if not messages_to_download:
                click.echo(click.style("No new media found.", fg="yellow"))
                return 0

            click.echo(
                click.style(
                    f"Found {len(messages_to_download)} files to download.", fg="green"
                )
            )

            semaphore = asyncio.Semaphore(self.max_concurrent)
            pbar = tqdm(total=len(messages_to_download), desc="Downloading", unit="file")

            tasks = [
                self._download_single(
                    msg, folder, semaphore, pbar, downloaded_message_ids, known_hashes, self._hash_dict_lock
                )
                for msg in messages_to_download
            ]

            results = await asyncio.gather(*tasks, return_exceptions=True)
            pbar.close()

            attempted_ids: Set[int] = {msg.id for msg in messages_to_download}
            downloaded_ids: Set[int] = set()
            for result in results:
                if isinstance(result, tuple) and len(result) == 2:
                    fp, mid = result
                    if fp is not None:
                        downloaded_ids.add(mid)

            if downloaded_ids:
                self.config.add_downloaded_ids(str(entity_id), downloaded_ids)

            # Keep progress watermark below the lowest failed ID so retries
            # never get skipped on future runs.
            failed_ids = attempted_ids - downloaded_ids
            if failed_ids:
                next_start_id = max(0, min(failed_ids) - 1)
                self.config.set_progress(str(entity_id), next_start_id)
            elif downloaded_ids:
                self.config.set_progress(str(entity_id), max(downloaded_ids))

            successful = sum(
                1 for r in results
                if isinstance(r, tuple) and len(r) == 2 and r[0] is not None
            )

            click.echo(click.style(f"\n✓ Downloaded {successful} files!", fg="green"))
            click.echo(f"Saved to: {folder.absolute()}")
            return successful

        except KeyboardInterrupt:
            click.echo(click.style("\n\n⚠ Download cancelled.", fg="yellow"))
            return 0
        except FloodWaitError as e:
            await _handle_flood_wait(e)
            return 0
        except Exception as e:
            click.echo(click.style(f"✗ Download failed: {e}", fg="red"))
            logger.exception(f"Error downloading from entity {entity_id}")
            return 0
        finally:
            await self._release_client()

    # ─────────────────────────────────────────────────────────────────────────
    # Public: download from link
    # ─────────────────────────────────────────────────────────────────────────
    async def download_from_link(self, link: str) -> bool:
        """Download media from a single Telegram message link."""
        client = await self._get_client()
        if not client:
            return False

        try:
            entity_id, message_id = self._parse_link(link)
            if not entity_id or not message_id:
                click.echo(click.style("✗ Invalid link format!", fg="red"))
                click.echo("  Supported: https://t.me/username/123  or  https://t.me/c/ID/123")
                return False

            message = await client.get_messages(entity_id, ids=message_id)
            if not message:
                click.echo(click.style("✗ Message not found!", fg="red"))
                return False
            if not message.media:
                click.echo(click.style("✗ Message has no media!", fg="red"))
                return False
            if not self._should_download(message):
                click.echo(click.style("✗ Media doesn't match your filters.", fg="yellow"))
                return False

            folder = Path(self.output_dir) / "single_downloads"
            folder.mkdir(parents=True, exist_ok=True)

            file_name = "unknown"
            file_size = 0
            if message.file:
                file_name = message.file.name or f"file_{message_id}"
                file_size = message.file.size

            click.echo(f"\nFile: {file_name}")
            click.echo(f"Size: {format_bytes(file_size)}")

            # Feature 9: Hash map for single-download dedup
            known_hashes = self._load_known_hashes(folder)
            click.echo()

            file_path = None
            hash_lock = asyncio.Lock()  # Single-threaded download, but use lock for consistency
            for attempt in range(1, MAX_RETRIES + 1):
                try:
                    file_path = await message.download_media(
                        file=str(folder),
                        progress_callback=self._create_progress_callback(),
                    )
                    break
                except FloodWaitError as e:
                    waited = await _handle_flood_wait(e)
                    if not waited or attempt == MAX_RETRIES:
                        click.echo(click.style("\n✗ Rate-limited, cannot complete.", fg="red"))
                        return False
                except Exception as e:
                    if attempt < MAX_RETRIES:
                        wait = RETRY_BACKOFF ** attempt
                        click.echo(
                            click.style(f"\n⚠ Attempt {attempt} failed. Retrying in {wait}s...", fg="yellow")
                        )
                        await asyncio.sleep(wait)
                    else:
                        raise

            print()  # newline after inline progress bar

            if not file_path:
                click.echo(click.style("\n✗ Download failed.", fg="red"))
                return False

            # Feature 9: Dedup check (with lock for consistency)
            new_hash = self._compute_file_hash(Path(file_path))
            if new_hash:
                async with hash_lock:
                    if new_hash in known_hashes:
                        existing = known_hashes[new_hash]
                        click.echo(
                            click.style(
                                f"\n⊘ Identical file already exists as {existing.name}. Removing duplicate.",
                                fg="yellow",
                            )
                        )
                        try:
                            os.remove(file_path)
                        except OSError:
                            pass
                        return True  # content already present — still a "success"
                    else:
                        known_hashes[new_hash] = Path(file_path)

            click.echo(click.style(f"\n✓ Downloaded to: {file_path}", fg="green"))
            return True

        except KeyboardInterrupt:
            click.echo(click.style("\n\n⚠ Download cancelled.", fg="yellow"))
            return False
        except FloodWaitError as e:
            await _handle_flood_wait(e)
            return False
        except Exception as e:
            click.echo(click.style(f"\n✗ Download failed: {e}", fg="red"))
            logger.exception(f"Error downloading from link: {link}")
            return False
        finally:
            await self._release_client()

    # ─────────────────────────────────────────────────────────────────────────
    # Progress callback
    # ─────────────────────────────────────────────────────────────────────────
    def _create_progress_callback(self) -> Callable:
        """Inline progress bar for single-file downloads."""
        def progress_callback(current: int, total: int) -> None:
            percent = (current / total) * 100 if total > 0 else 0
            filled = int(PROGRESS_BAR_LENGTH * current / total) if total > 0 else 0
            bar = (
                PROGRESS_BAR_FILLED_CHAR * filled
                + PROGRESS_BAR_EMPTY_CHAR * (PROGRESS_BAR_LENGTH - filled)
            )
            print(
                f"\r  [{bar}] {percent:.1f}% | "
                f"{format_bytes(current)}/{format_bytes(total)}",
                end="",
                flush=True,
            )
        return progress_callback

    # ─────────────────────────────────────────────────────────────────────────
    # Link parser
    # ─────────────────────────────────────────────────────────────────────────
    def _parse_link(self, link: str):
        """Parse Telegram message link into (entity_id, message_id)."""
        m = re.match(r"https?://t\.me/c/(\d+)/(\d+)", link)
        if m:
            return int("-100" + m.group(1)), int(m.group(2))

        m = re.match(r"https?://t\.me/([^/]+)/(\d+)", link)
        if m:
            return m.group(1), int(m.group(2))

        return None, None
