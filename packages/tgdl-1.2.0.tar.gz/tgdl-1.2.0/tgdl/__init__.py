"""tgdl - High-performance Telegram media downloader CLI tool."""

__version__ = "1.2.0"
__author__ = "kavidu-dilhara"
__license__ = "MIT"

from tgdl.cli import main

__all__ = ["main", "__version__"]
