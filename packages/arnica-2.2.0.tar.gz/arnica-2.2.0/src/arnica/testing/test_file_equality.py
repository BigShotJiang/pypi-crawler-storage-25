"""
File equality test utility.

Strategy:
  1. Fast path  — compare SHA-256 digests (byte-level identity, instant).
  2. Slow path  — if digests differ, run a line-by-line unified diff and
                  produce a human-readable report: added lines, removed lines,
                  changed blocks, with line numbers throughout.

The comparison is:
  - Case-sensitive
  - Blank-line sensitive
  - Encoding-aware (defaults to UTF-8; override with `encoding=`)

Usage:
    assert_same_file("expected.txt", "actual.txt")     # raises AssertionError
    result = compare_files("expected.txt", "actual.txt")
    print(result.summary())
"""

import hashlib
import difflib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Union

PathLike = Union[str, Path]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Hunk:
    """One contiguous block of differences."""
    expected_start: int          # 1-based line number in expected file
    actual_start: int            # 1-based line number in actual file
    removed: list[str]           = field(default_factory=list)  # lines only in expected
    added: list[str]             = field(default_factory=list)  # lines only in actual
    context_before: list[str]    = field(default_factory=list)  # unchanged lines before
    context_after: list[str]     = field(default_factory=list)  # unchanged lines after

    @property
    def kind(self) -> str:
        if self.removed and self.added:
            return "changed"
        if self.removed:
            return "missing"   # present in expected, absent in actual
        return "added"         # absent in expected, present in actual


@dataclass
class FileDiffResult:
    """Holds the outcome of a file comparison."""
    files_identical: bool        # True when SHA-256 digests match
    expected_path: Path
    actual_path: Path
    expected_lines: int = 0
    actual_lines: int   = 0
    hunks: list[Hunk]   = field(default_factory=list)

    @property
    def equal(self) -> bool:
        return self.files_identical

    def summary(self, context_lines: int = 2) -> str:
        if self.equal:
            return (
                f"Files are identical.\n"
                f"  {self.expected_path}  ({self.expected_lines} lines)"
            )

        lines = [
            "Files differ:",
            f"  expected : {self.expected_path}  ({self.expected_lines} lines)",
            f"  actual   : {self.actual_path}  ({self.actual_lines} lines)",
            "",
        ]

        for hunk in self.hunks:
            if hunk.kind == "changed":
                header = (
                    f"~~ Changed  "
                    f"(expected L{hunk.expected_start}–"
                    f"L{hunk.expected_start + len(hunk.removed) - 1}  /  "
                    f"actual L{hunk.actual_start}–"
                    f"L{hunk.actual_start + len(hunk.added) - 1})"
                )
            elif hunk.kind == "missing":
                header = (
                    f"-- Missing  "
                    f"(expected L{hunk.expected_start}–"
                    f"L{hunk.expected_start + len(hunk.removed) - 1}  /  "
                    f"not present in actual)"
                )
            else:
                header = (
                    f"++ Added  "
                    f"(not in expected  /  "
                    f"actual L{hunk.actual_start}–"
                    f"L{hunk.actual_start + len(hunk.added) - 1})"
                )

            lines.append(header)

            # Context before
            for i, ctx in enumerate(hunk.context_before[-context_lines:]):
                ln = hunk.expected_start - len(hunk.context_before[-context_lines:]) + i
                lines.append(f"    {ln:>6}  {ctx}")

            # Removed lines (in expected, not in actual)
            for i, rem in enumerate(hunk.removed):
                ln = hunk.expected_start + i
                lines.append(f"  - {ln:>6}  {rem}")

            # Added lines (in actual, not in expected)
            for i, add in enumerate(hunk.added):
                ln = hunk.actual_start + i
                lines.append(f"  + {ln:>6}  {add}")

            # Context after
            for i, ctx in enumerate(hunk.context_after[:context_lines]):
                ln = hunk.expected_start + len(hunk.removed) + i
                lines.append(f"    {ln:>6}  {ctx}")

            lines.append("")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Core comparison logic
# ---------------------------------------------------------------------------

def _sha256(path: Path, encoding: str) -> str:
    """Return the SHA-256 hex digest of a text file's raw bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _parse_hunks(
    expected_lines: list[str],
    actual_lines: list[str],
    context: int = 3,
) -> list[Hunk]:
    """
    Use difflib.SequenceMatcher to extract structured hunks with line numbers.
    Each opcode group becomes one Hunk.
    """
    matcher = difflib.SequenceMatcher(
        None, expected_lines, actual_lines, autojunk=False
    )
    hunks: list[Hunk] = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue

        ctx_before = expected_lines[max(0, i1 - context): i1]
        ctx_after  = expected_lines[i2: i2 + context]

        hunk = Hunk(
            expected_start  = i1 + 1,   # convert to 1-based
            actual_start    = j1 + 1,
            removed         = expected_lines[i1:i2],
            added           = actual_lines[j1:j2],
            context_before  = ctx_before,
            context_after   = ctx_after,
        )
        hunks.append(hunk)

    return hunks


def compare_files(
    expected: PathLike,
    actual: PathLike,
    encoding: str = "utf-8",
) -> FileDiffResult:
    """
    Compare two text files and return a FileDiffResult.

    The fast SHA-256 check runs first.  If the files differ, a full
    line-by-line diff is computed and returned as structured Hunk objects.

    Parameters
    ----------
    expected:
        Path to the reference / expected file.
    actual:
        Path to the file produced by the application under test.
    encoding:
        Text encoding for both files (default: utf-8).
    """
    expected = Path(expected)
    actual   = Path(actual)

    # --- Fast path: digest comparison ---
    digest_expected = _sha256(expected, encoding)
    digest_actual   = _sha256(actual,   encoding)

    if digest_expected == digest_actual:
        exp_lines = expected.read_text(encoding=encoding).splitlines()
        return FileDiffResult(
            files_identical = True,
            expected_path   = expected,
            actual_path     = actual,
            expected_lines  = len(exp_lines),
            actual_lines    = len(exp_lines),
        )

    # --- Slow path: line-by-line diff ---
    exp_lines = expected.read_text(encoding=encoding).splitlines()
    act_lines = actual.read_text(encoding=encoding).splitlines()

    hunks = _parse_hunks(exp_lines, act_lines)

    return FileDiffResult(
        files_identical = False,
        expected_path   = expected,
        actual_path     = actual,
        expected_lines  = len(exp_lines),
        actual_lines    = len(act_lines),
        hunks           = hunks,
    )


# ---------------------------------------------------------------------------
# Assertion helper
# ---------------------------------------------------------------------------

def assert_same_file(
    expected: PathLike,
    actual: PathLike,
    encoding: str = "utf-8",
    context_lines: int = 2,
) -> None:
    """
    Assert that two text files are byte-for-byte identical.

    Raises AssertionError with a human-readable diff on failure.
    Uses raise AssertionError(...) explicitly (not the assert statement)
    so pytest always displays the full diff when called from a helper.

    Parameters
    ----------
    expected:
        Path to the reference / expected file.
    actual:
        Path to the file produced by the application under test.
    encoding:
        Text encoding (default: utf-8).
    context_lines:
        Number of unchanged lines to show around each diff hunk (default: 2).
    """
    result = compare_files(expected, actual, encoding=encoding)
    if not result.equal:
        raise AssertionError("\n" + result.summary(context_lines=context_lines))


# # ---------------------------------------------------------------------------
# # Example / quick smoke-test
# # ---------------------------------------------------------------------------

# if __name__ == "__main__":
#     import tempfile, os

#     def _write(path: str, content: str):
#         with open(path, "w", encoding="utf-8") as f:
#             f.write(content)

#     with tempfile.TemporaryDirectory() as tmp:
#         f1 = os.path.join(tmp, "expected.txt")
#         f2 = os.path.join(tmp, "actual.txt")

#         expected_content = """\
# PROGRAM start
#   SET x = 1
#   SET y = 2
#   IF x < y THEN
#     PRINT "hello"
#   END IF

#   LOOP 10
#     DO something
#   END LOOP
# END
# """
#         actual_content = """\
# PROGRAM start
#   SET x = 1
#   SET y = 99
#   IF x < y THEN
#     PRINT "hello"
#     PRINT "world"
#   END IF

#   LOOP 10
#     DO something_else
#   END LOOP
# END
# """
#         print("=== Identical files ===")
#         _write(f1, expected_content)
#         _write(f2, expected_content)
#         result = compare_files(f1, f2)
#         print(result.summary())

#         print()
#         print("=== Files with differences ===")
#         _write(f2, actual_content)
#         result = compare_files(f1, f2)
#         print(result.summary())
