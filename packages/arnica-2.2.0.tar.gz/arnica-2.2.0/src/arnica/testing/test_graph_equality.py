"""
Graph equality test utility.

Strategy:
  1. Fast path  — nx.is_isomorphic() (node/edge structure only, ignores attrs)
  2. Slow path  — detailed diff when the fast check fails or when you need
                  attribute-level validation regardless of structure.

Usage:
    assert_graphs_equal(G1, G2)          # raises AssertionError with full report
    result = compare_graphs(G1, G2)      # returns GraphDiffResult
    G = load_graph("graph.json")         # loads a node-link JSON file
"""

import json
import copy
import textwrap
from dataclasses import dataclass, field
from typing import Any

import networkx as nx

INDENT =".    "

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class GraphDiffResult:
    """Holds the outcome of a graph comparison."""
    is_isomorphic: bool
    missing_nodes: set        = field(default_factory=set)   # in G2 but not G1
    extra_nodes: set          = field(default_factory=set)   # in G1 but not G2
    missing_edges: set        = field(default_factory=set)
    extra_edges: set          = field(default_factory=set)
    node_attr_diffs: dict     = field(default_factory=dict)  # {node: {attr: (v1, v2)}}
    edge_attr_diffs: dict     = field(default_factory=dict)  # {edge: {attr: (v1, v2)}}

    @property
    def equal(self) -> bool:
        return (
            self.is_isomorphic
            and not self.node_attr_diffs
            and not self.edge_attr_diffs
        )

    def summary(self) -> str:
        if self.equal:
            return "Graphs are identical."

        lines = ["Graphs differ:"]

        if self.missing_nodes:
            lines.append(f"  Nodes missing from G1 : {sorted(self.missing_nodes)}")
        if self.extra_nodes:
            lines.append(f"  Nodes extra in G1     : {sorted(self.extra_nodes)}")
        if self.missing_edges:
            lines.append(f"  Edges missing from G1 : {sorted(self.missing_edges)}")
        if self.extra_edges:
            lines.append(f"  Edges extra in G1     : {sorted(self.extra_edges)}")

        if self.node_attr_diffs:
            lines.append("  Node attribute diffs:")
            for node, attrs in sorted(self.node_attr_diffs.items()):
                lines.append(f"    Node {node!r}:")
                for attr, (v1, v2) in sorted(attrs.items()):
                    lines.append(f"{INDENT}{attr!r}:\n{INDENT}G1={v1!r}\n{INDENT}G2={v2!r}")

        if self.edge_attr_diffs:
            lines.append("  Edge attribute diffs:")
            for edge, attrs in sorted(self.edge_attr_diffs.items()):
                lines.append(f"    Edge {edge!r}:")
                for attr, (v1, v2) in sorted(attrs.items()):
                    lines.append(f"{INDENT}{attr!r}:\n{INDENT}G1={v1!r}\n{INDENT}G2={v2!r}")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Core comparison logic
# ---------------------------------------------------------------------------

def _diff_attr_dicts(
    a: dict[str, Any],
    b: dict[str, Any],
) -> dict[str, tuple[Any, Any]]:
    """Return {key: (val_in_a, val_in_b)} for every key that differs."""
    all_keys = set(a) | set(b)
    diffs = {}
    for k in all_keys:
        va = a.get(k, _MISSING)
        vb = b.get(k, _MISSING)
        if va != vb:
            diffs[k] = (va, vb)
    return diffs


class _Missing:
    """Sentinel for absent attributes."""
    def __repr__(self):
        return "<missing>"

_MISSING = _Missing()


def compare_graphs(G1: nx.Graph, G2: nx.Graph) -> GraphDiffResult:
    """
    Compare two NetworkX graphs and return a GraphDiffResult.

    The fast isomorphism check (structure only) runs first.  Attribute
    comparison always runs so you get the full picture even when the
    topology matches.
    """
    result = GraphDiffResult(is_isomorphic=nx.is_isomorphic(G1, G2))
 
    # --- Node diff ---
    nodes1 = set(G1.nodes())
    nodes2 = set(G2.nodes())
    result.missing_nodes = nodes2 - nodes1
    result.extra_nodes   = nodes1 - nodes2
 
    # Attribute diff on common nodes
    for node in nodes1 & nodes2:
        diffs = _diff_attr_dicts(
            copy.deepcopy(dict(G1.nodes[node])),
            copy.deepcopy(dict(G2.nodes[node])),
        )
        if diffs:
            result.node_attr_diffs[node] = diffs
 
    # --- Edge diff ---
    edges1 = set(G1.edges())
    edges2 = set(G2.edges())
 
    # For undirected graphs, normalise edge tuples so (u,v) == (v,u)
    if not G1.is_directed():
        edges1 = {tuple(sorted(e)) for e in edges1}
        edges2 = {tuple(sorted(e)) for e in edges2}
 
    result.missing_edges = edges2 - edges1
    result.extra_edges   = edges1 - edges2
 
    # Attribute diff on common edges
    # get_edge_data() is safe for both Graph and MultiGraph; returns None if
    # the edge is absent.  deep-copy so shared mutable values (lists, dicts)
    # in the attribute data cannot bleed across the two sides of the comparison.
    for edge in edges1 & edges2:
        u, v = edge
        e1_data = copy.deepcopy(G1.get_edge_data(u, v) or {})
        e2_data = copy.deepcopy(G2.get_edge_data(u, v) or {})
        diffs = _diff_attr_dicts(e1_data, e2_data)
        if diffs:
            result.edge_attr_diffs[edge] = diffs
 
    return result
 


# ---------------------------------------------------------------------------
# Assertion helper (drop into any test suite)
# ---------------------------------------------------------------------------

def assert_same_graph(G1: nx.Graph, G2: nx.Graph) -> None:
    """
    Assert that two graphs are topologically and attribute-wise identical.

    Raises AssertionError with a human-readable diff on failure.
    Using raise AssertionError(...) explicitly (rather than the assert
    statement) ensures pytest displays the full diff message even when
    it is called from a helper function outside the test body.
    """
    result = compare_graphs(G1, G2)
    if not result.equal:
        raise AssertionError("\n" + result.summary())


# Alias for backwards compatibility
assert_graphs_equal = assert_same_graph


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def load_graph(path: str) -> nx.Graph:
    """Load a NetworkX node-link JSON file."""
    with open(path) as f:
        data = json.load(f)
    return nx.node_link_graph(data)


# # ---------------------------------------------------------------------------
# # Example / quick smoke-test
# # ---------------------------------------------------------------------------

# if __name__ == "__main__":
#     # Build two small graphs for demonstration
#     G1 = nx.Graph()
#     G1.add_node(1, color="red", weight=1.0)
#     G1.add_node(2, color="blue", weight=2.0)
#     G1.add_node(3, color="green", weight=3.0)
#     G1.add_edge(1, 2, label="A")
#     G1.add_edge(2, 3, label="B")

#     G2 = G1.copy()

#     print("=== Identical graphs ===")
#     result = compare_graphs(G1, G2)
#     print(result.summary())

#     print()
#     print("=== Graphs with differences ===")
#     G2.nodes[1]["color"] = "yellow"          # changed attribute
#     G2.nodes[2]["extra_attr"] = "surprise"   # added attribute
#     G2.remove_node(3)                        # removed node (also removes edge 2-3)
#     G2.add_node(4, color="purple")           # added node
#     G2.add_edge(1, 4, label="C")             # added edge

#     result = compare_graphs(G1, G2)
#     print(result.summary())
