from time import perf_counter
from typing import List, Dict, Tuple


# ──────────────────────────────────────────────────────────────
# Pure functions (easy to unit test)
# ──────────────────────────────────────────────────────────────

def compute_durations_ms(
    monitoring_times: List[Tuple[str, float]]
) -> Dict[str, float]:
    """
    Turn a list of (name, timestamp)
    into {name: elapsed_ms_since_previous_breakpoint}.
    """
    durations: Dict[str, float] = {}

    for i in range(len(monitoring_times) - 1):
        prev_ts = monitoring_times[i][1]
        name, ts = monitoring_times[i + 1]
        durations[name] = (ts - prev_ts) * 1000

    return durations


def format_durations(durations: Dict[str, float], partname:str) -> str:
    """
    Return a formatted string showing durations and percentages.
    """
    total = sum(durations.values())

    lines = []
    lines.append(f"\n {partname} Timings (Total {total:10.2f} ms)")
    lines.append("-" * 70)

    for name, ms in durations.items():
        frac = (100.0 * ms / total) if total else 0.0
        lines.append(f"{name:<40} {frac:>4.1f}% ({ms:>10.2f} ms)")

    lines.append("-" * 70)

    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────
# Small object wrapper
# ──────────────────────────────────────────────────────────────

class BpTimer:
    """
    Simple breakpoint timer utility.

    Example:
        timer = BpTimer()
        timer.breakpoint("load")
        ...
        timer.breakpoint("parse")
        ...
        timer.print()
    """

    def __init__(self, partname:str) -> None:
        self.partname = partname
        self.monitoring_times: List[Tuple[str, float]] = [("Init", perf_counter())]

    # ──────────────────────────────────────────────────────────

    def breakpoint(self, name: str) -> None:
        """Register a timing breakpoint. Time measured BEFORE the breakpoint"""
        self.monitoring_times.append((name, perf_counter()))

    # ──────────────────────────────────────────────────────────

    def durations_ms(self) -> Dict[str, float]:
        """Return section durations in milliseconds."""
        return compute_durations_ms(self.monitoring_times)

    # ──────────────────────────────────────────────────────────

    def report(self) -> str:
        """Return formatted timing report."""
        return format_durations(self.durations_ms(), self.partname)

    # ──────────────────────────────────────────────────────────

    def print(self) -> None:
        """Print formatted timing report."""
        print(self.report())

    # ──────────────────────────────────────────────────────────

    def reset(self) -> None:
        """Clear all recorded breakpoints."""
        self.monitoring_times.clear()