"""Migration command for the simplified Build AI CLI."""

from __future__ import annotations

import asyncio

import asyncpg
import typer
from infra.settings import Settings
from typing_extensions import Annotated

from cli.console import console, error, info, success, warning
from cli.context import open_admin_database
from cli.guard import require_write

from .common import (
    MIGRATIONS_DIR,
    MIGRATIONS_TABLE,
    ensure_migrations_table,
    get_migration_status,
    get_migrations_connection,
    migration_label,
    migration_requires_manual_apply,
    migration_requires_no_transaction,
    migration_requires_system_admin,
    set_owner_role,
    split_sql_statements,
)

_MIGRATION_WRITE_PROFILES = frozenset(
    {
        "internal_admin",
        "migrations-local",
        "db-admin-local",
    }
)


def migrate(
    ctx: typer.Context,
    target: Annotated[str | None, typer.Argument(help="Migration file or 'all'")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show without executing")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="Statement timeout in seconds")] = 3600,
    as_admin: Annotated[
        bool,
        typer.Option(
            "--as-admin",
            help="Run with the system-admin DB connection instead of migrations-sa.",
        ),
    ] = False,
) -> None:
    """Run the checked-in SQL migrations on the selected DB lane."""

    if target is not None and not dry_run:
        require_write(
            ctx,
            "Database migrations",
            allowed_profiles=_MIGRATION_WRITE_PROFILES,
        )
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        if not MIGRATIONS_DIR.exists():
            error(f"Migrations directory not found: {MIGRATIONS_DIR}")
            raise typer.Exit(1)

        async def open_migration_db():
            return (
                await open_admin_database(settings)
                if as_admin
                else await get_migrations_connection(settings)
            )

        if target is None or dry_run:
            migration_db = await open_migration_db()
            try:
                conn = migration_db.conn
                await conn.execute(
                    "SELECT set_config('buildai.app_env', $1, false)",
                    settings.app_env.value,
                )
                applied_set, migration_files = await get_migration_status(conn)
                pending = [f for f in migration_files if f.name not in applied_set]
                if target is None:
                    console.print(f"\n[bold]Migration Status[/bold] ({settings.app_env.value})\n")
                    console.print(
                        f"Repo total: {len(migration_files)}, "
                        f"Tracked rows: {len(applied_set)}, "
                        f"Pending: {len(pending)}\n"
                    )
                    if pending:
                        warning("Pending migrations:")
                        for item in pending[:10]:
                            console.print(f"  - {migration_label(item)}")
                        if len(pending) > 10:
                            console.print(f"  ... and {len(pending) - 10} more")
                    else:
                        success("All migrations applied")
                    return

                to_run = (
                    pending if target == "all" else [f for f in migration_files if target in f.name]
                )
                if not to_run:
                    success("No migrations to run")
                    return

                console.print("[yellow]Dry run - would apply:[/yellow]")
                for migration in to_run:
                    console.print(f"  - {migration.name}")
            finally:
                await migration_db.close()
            return

        migration_db = None
        using_owner_role = False
        conn: asyncpg.Connection | None = None
        try:
            migration_db = await open_migration_db()
            conn = migration_db.conn
            await conn.execute(
                "SELECT set_config('buildai.app_env', $1, false)",
                settings.app_env.value,
            )
            applied_set, migration_files = await get_migration_status(conn)
            to_run = (
                [f for f in migration_files if f.name not in applied_set]
                if target == "all"
                else [f for f in migration_files if target and target in f.name]
            )
            if target == "all":
                manual_apply = [f for f in to_run if migration_requires_manual_apply(f)]
                if manual_apply:
                    warning(
                        "Skipping manual-apply migration(s): "
                        + ", ".join(item.name for item in manual_apply)
                    )
                    to_run = [f for f in to_run if f not in manual_apply]
            elif any(migration_requires_manual_apply(f) for f in to_run):
                warning("Selected manual-apply migration explicitly; proceeding.")

            if not to_run:
                success("No migrations to run")
                return

            requires_system_admin = any(migration_requires_system_admin(path) for path in to_run)
            if requires_system_admin and not as_admin:
                error(
                    "Selected migration requires --as-admin. Use the system-admin connection "
                    "for ownership or pg_cron level changes."
                )
                raise typer.Exit(1)

            await ensure_migrations_table(conn)
            if not requires_system_admin:
                using_owner_role = await set_owner_role(conn)
                if not using_owner_role:
                    raise RuntimeError(
                        "Failed to SET ROLE buildai_owner. Refusing to run the migration as the caller identity."
                    )

            if settings.is_production:
                warning(f"About to run {len(to_run)} migration(s) in PRODUCTION")
                if not typer.confirm("Continue?"):
                    raise typer.Abort()

            for migration in to_run:
                info(f"Running {migration.name}...")
                sql = migration.read_text(encoding="utf-8")
                if timeout == 0:
                    await conn.execute("SET statement_timeout = '0'")
                else:
                    await conn.execute(f"SET statement_timeout = '{timeout}s'")
                if migration_requires_no_transaction(migration, sql):
                    for statement in split_sql_statements(sql):
                        await conn.execute(statement, timeout=None)
                else:
                    await conn.execute(sql, timeout=None)
                await conn.execute(
                    f"INSERT INTO {MIGRATIONS_TABLE} (filename) VALUES ($1) ON CONFLICT DO NOTHING",
                    migration.name,
                )
                success(f"  Applied {migration.name}")

            success(f"Applied {len(to_run)} migration(s)")
        except Exception as exc:
            error(str(exc))
            raise typer.Exit(1)
        finally:
            if using_owner_role and conn is not None:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass
            if migration_db is not None:
                await migration_db.close()

    asyncio.run(run())
