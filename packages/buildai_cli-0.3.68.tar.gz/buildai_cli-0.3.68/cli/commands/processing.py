"""Operator commands for the Processing API control plane."""

from __future__ import annotations

import json
import sys
from typing import Any

import httpx
import typer

from cli.commands.api_proxy import _build_url
from cli.config import resolve_api_url, resolve_credential
from cli.console import error

app = typer.Typer(help="Inspect and adjust processing manifests.", no_args_is_help=True)
queue_app = typer.Typer(help="Inspect and adjust manifest batch queues.", no_args_is_help=True)
scheduler_app = typer.Typer(help="Run bounded processing scheduler passes.", no_args_is_help=True)
stage_jobs_app = typer.Typer(help="Operate episode-scoped stage jobs.", no_args_is_help=True)
app.add_typer(queue_app, name="queue")
app.add_typer(scheduler_app, name="scheduler")
app.add_typer(stage_jobs_app, name="stage-jobs")


def _request(
    path: str,
    *,
    method: str = "GET",
    body: dict[str, Any] | None = None,
    query_params: list[str] | None = None,
) -> None:
    """Call the Build AI API with stored CLI credentials and print JSON."""
    try:
        token = resolve_credential()
    except RuntimeError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    url = _build_url(resolve_api_url(), path, query_params)
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }
    if body is not None:
        headers["Content-Type"] = "application/json"

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.request(method, url, headers=headers, json=body)
    except httpx.ConnectError:
        error("Could not connect to the Build AI API. Check your network or BUILDAI_API_URL.")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        error("Request timed out. Try a narrower queue command.")
        raise typer.Exit(1)

    try:
        payload = response.json()
    except ValueError:
        payload = {"status_code": response.status_code, "text": response.text}
    sys.stdout.write(json.dumps(payload, indent=2, default=str) + "\n")
    if response.status_code >= 400:
        raise typer.Exit(1)


def _parse_json_object(value: str | None, *, option_name: str) -> dict[str, Any]:
    """Parse an optional CLI JSON object with a useful operator error."""
    if not value:
        return {}
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        error(f"{option_name} must be valid JSON: {exc}")
        raise typer.Exit(1) from exc
    if not isinstance(parsed, dict):
        error(f"{option_name} must decode to a JSON object.")
        raise typer.Exit(1)
    return parsed


def _parse_csv(
    value: str | None,
    *,
    option_name: str,
    allowed: set[str] | None = None,
) -> list[str] | None:
    """Parse a comma-separated option while rejecting unknown control-plane keys."""
    if not value:
        return None
    parsed = [item.strip() for item in value.split(",") if item.strip()]
    unknown = sorted(set(parsed) - allowed) if allowed is not None else []
    if unknown:
        error(f"{option_name} contains unknown value(s): {', '.join(unknown)}")
        raise typer.Exit(1)
    return parsed


@queue_app.command("groups")
def queue_groups(
    manifest_id: str = typer.Argument(..., help="Processing manifest/job id."),
    group_key: str = typer.Option(
        "subject_key",
        "--group-key",
        help="Top-level manifest_items.item_metadata key to group by.",
    ),
    stale_minutes: int = typer.Option(
        30,
        "--stale-minutes",
        min=1,
        max=24 * 60,
        help="Heartbeat age threshold used for stale claimed counts.",
    ),
    limit: int = typer.Option(100, "--limit", min=1, max=500),
) -> None:
    """Show queue progress grouped by manifest-item metadata."""
    _request(
        f"/v1/processing/jobs/{manifest_id}/queue/groups",
        query_params=[
            f"group_metadata_key={group_key}",
            f"stale_minutes={stale_minutes}",
            f"limit={limit}",
        ],
    )


@queue_app.command("release-stale")
def queue_release_stale(
    manifest_id: str = typer.Argument(..., help="Processing manifest/job id."),
    stale_minutes: int = typer.Option(
        30,
        "--stale-minutes",
        min=1,
        max=24 * 60,
        help="Release claimed batches with heartbeat older than this threshold.",
    ),
    limit: int = typer.Option(100, "--limit", min=1, max=500),
    write: bool = typer.Option(
        False,
        "--write",
        help="Apply the release. Omit for dry-run preview.",
    ),
) -> None:
    """Dry-run or release stale claimed batches for one manifest."""
    _request(
        f"/v1/processing/jobs/{manifest_id}/queue/release-stale",
        method="POST",
        body={
            "stale_minutes": stale_minutes,
            "limit": limit,
            "dry_run": not write,
        },
    )


@queue_app.command("reprioritize")
def queue_reprioritize(
    manifest_id: str = typer.Argument(..., help="Processing manifest/job id."),
    group_key: str = typer.Option(
        "subject_key",
        "--group-key",
        help="Top-level manifest_items.item_metadata key that defines a group.",
    ),
    strategy: str = typer.Option(
        "finish_groups",
        "--strategy",
        help="One of: finish_groups, explicit_groups_first.",
    ),
    group_value: list[str] | None = typer.Option(
        None,
        "--group-value",
        help="Group value to pull forward. Repeat to set explicit order.",
    ),
    preview_limit: int = typer.Option(50, "--preview-limit", min=1, max=500),
    write: bool = typer.Option(
        False,
        "--write",
        help="Apply the reorder. Omit for dry-run preview.",
    ),
) -> None:
    """Dry-run or reorder pending work inside one manifest queue."""
    _request(
        f"/v1/processing/jobs/{manifest_id}/queue/reprioritize",
        method="POST",
        body={
            "group_metadata_key": group_key,
            "strategy": strategy,
            "group_values": group_value or [],
            "preview_limit": preview_limit,
            "dry_run": not write,
        },
    )


@scheduler_app.command("tick")
def scheduler_tick(
    pipeline_key: str = typer.Option("egoexo", "--pipeline-key", help="Pipeline key."),
    run_key: str | None = typer.Option(None, "--run-key", help="Pipeline run key."),
    stage_key: str | None = typer.Option(None, "--stage-key", help="Single stage to tick."),
    stages: str | None = typer.Option(
        None,
        "--stages",
        help="Comma-separated stage keys. Defaults downstream-first to all automatic stages.",
    ),
    seed_new_runs: bool = typer.Option(
        False,
        "--seed-new-runs",
        help="Create planned runs before frontier advancement when the pipeline supports it.",
    ),
    seed_limit: int = typer.Option(100, "--seed-limit", min=1, max=1000),
    seed_priority: int = typer.Option(5, "--seed-priority", min=0, max=10),
    limit: int = typer.Option(10, "--limit", min=1, max=100),
    reconcile: bool = typer.Option(False, "--reconcile", help="Finalize drained manifests."),
    reconcile_launches: bool = typer.Option(
        False,
        "--reconcile-launches",
        help="Refresh active backend launch states before frontier advancement.",
    ),
    drain_chunking: bool = typer.Option(
        False,
        "--drain-chunking",
        help="Drain global chunking manifests after frontier advancement.",
    ),
    stage_limits_json: str | None = typer.Option(
        None,
        "--stage-limits-json",
        help='Optional JSON object such as {"pose_3d": 50, "pose_2d": 4, "prepare": 20}.',
    ),
    max_submit_manifests: int = typer.Option(5, "--max-submit-manifests", min=1, max=50),
    max_tasks: int = typer.Option(4, "--max-tasks", min=1, max=1000),
    provisioning_model: str = typer.Option(
        "standard",
        "--provisioning-model",
        help="Cloud Batch provisioning model: standard or spot.",
    ),
    config_json: str | None = typer.Option(
        None,
        "--config-json",
        help="Optional processor config JSON object for single-stage ticks.",
    ),
    stage_configs_json: str | None = typer.Option(
        None,
        "--stage-configs-json",
        help="Optional JSON object mapping stage key to processor config object.",
    ),
    queue_only: bool = typer.Option(
        False, "--queue-only", help="Queue/materialize but do not submit."
    ),
    no_materialize: bool = typer.Option(False, "--no-materialize", help="Skip chunking manifests."),
    write: bool = typer.Option(
        False, "--write", help="Apply the scheduler pass. Omit for dry-run."
    ),
) -> None:
    """Run one bounded processing scheduler pass across automatic frontiers."""
    if provisioning_model not in {"standard", "spot"}:
        error("--provisioning-model must be one of: standard, spot")
        raise typer.Exit(1)
    parsed_stages = _parse_csv(stages, option_name="--stages")
    _request(
        "/v1/processing/scheduler/tick",
        method="POST",
        body={
            "pipeline_key": pipeline_key,
            "run_key": run_key,
            "stage_key": stage_key,
            "stages": parsed_stages,
            "seed_new_runs": seed_new_runs,
            "seed_limit": seed_limit,
            "seed_priority": seed_priority,
            "limit": limit,
            "reconcile": reconcile,
            "reconcile_launches": reconcile_launches,
            "drain_chunking": drain_chunking,
            "stage_limits": _parse_json_object(
                stage_limits_json,
                option_name="--stage-limits-json",
            ),
            "dry_run": not write,
            "materialize": not no_materialize,
            "submit": not queue_only,
            "max_submit_manifests": max_submit_manifests,
            "max_tasks": max_tasks,
            "provisioning_model": provisioning_model,
            "config": _parse_json_object(config_json, option_name="--config-json"),
            "stage_configs": _parse_json_object(
                stage_configs_json,
                option_name="--stage-configs-json",
            ),
        },
    )


@stage_jobs_app.command("launch-egoexo-prepare-batch")
def launch_egoexo_prepare_batch(
    limit: int = typer.Option(10, "--limit", min=1, max=200),
    run_key: str = typer.Option(..., "--run-key", help="Prepare run key to drain."),
    execution_profile_key: str = typer.Option(
        "gcp.us.media_l4",
        "--execution-profile-key",
        help="Cloud Batch execution profile used for each episode job.",
    ),
    provisioning_model: str = typer.Option(
        "standard",
        "--provisioning-model",
        help="Cloud Batch provisioning model: standard or spot.",
    ),
    lease_seconds: int = typer.Option(24 * 60 * 60, "--lease-seconds", min=600),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview ready work without leasing."),
    write: bool = typer.Option(False, "--write", help="Launch jobs. Omit for dry-run."),
) -> None:
    """Launch one Cloud Batch prepare job per ready EgoExo episode."""
    if provisioning_model not in {"standard", "spot"}:
        error("--provisioning-model must be one of: standard, spot")
        raise typer.Exit(1)
    _request(
        "/v1/processing/stage-jobs/egoexo/prepare/launch-batch",
        method="POST",
        body={
            "limit": limit,
            "run_key": run_key,
            "execution_profile_key": execution_profile_key,
            "provisioning_model": provisioning_model,
            "lease_seconds": lease_seconds,
            "dry_run": dry_run or not write,
        },
    )


@stage_jobs_app.command("launch-egoexo-pose-2d-batch")
def launch_egoexo_pose_2d_batch(
    limit: int = typer.Option(10, "--limit", min=1, max=200),
    run_key: str = typer.Option(..., "--run-key", help="Pose2D run key to drain."),
    task_count: int = typer.Option(
        8,
        "--task-count",
        min=1,
        max=1000,
        help="Cloud Batch tasks per episode job.",
    ),
    execution_profile_key: str = typer.Option(
        "gcp.us.gpu_a100",
        "--execution-profile-key",
        help="Cloud Batch execution profile used for each episode job.",
    ),
    provisioning_model: str = typer.Option(
        "standard",
        "--provisioning-model",
        help="Cloud Batch provisioning model: standard or spot.",
    ),
    max_active_jobs: int | None = typer.Option(
        None,
        "--max-active-jobs",
        min=1,
        max=1000,
        help="Maximum active episode Batch jobs for this execution profile.",
    ),
    store_heatmaps: bool = typer.Option(
        False,
        "--store-heatmaps",
        help="Persist pre-decoded Sapiens heatmap logits as optional artifacts.",
    ),
    lease_seconds: int = typer.Option(24 * 60 * 60, "--lease-seconds", min=600),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview ready work without leasing."),
    write: bool = typer.Option(False, "--write", help="Launch jobs. Omit for dry-run."),
) -> None:
    """Launch one episode-owned Cloud Batch Pose2D job per ready EgoExo episode."""
    if provisioning_model not in {"standard", "spot"}:
        error("--provisioning-model must be one of: standard, spot")
        raise typer.Exit(1)
    _request(
        "/v1/processing/stage-jobs/egoexo/pose-2d/launch-batch",
        method="POST",
        body={
            "limit": limit,
            "run_key": run_key,
            "task_count": task_count,
            "execution_profile_key": execution_profile_key,
            "provisioning_model": provisioning_model,
            "max_active_jobs": max_active_jobs,
            "config": {"store_heatmaps": store_heatmaps},
            "lease_seconds": lease_seconds,
            "dry_run": dry_run or not write,
        },
    )
