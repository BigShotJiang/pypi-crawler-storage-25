"""GigCamera operator commands for workspace-local maintenance workflows."""

from __future__ import annotations

import asyncio
import hashlib
from datetime import date
from decimal import Decimal
from typing import Literal
from uuid import UUID

import typer

from cli.console import error
from cli.context import get_cli_context, get_inspection_connection
from cli.db_broker import BrokerConnectionError
from cli.ops_init import init_ops_context
from cli.output import Format, format_option, render


def _stable_idempotency_key(*, prefix: str, parts: list[str]) -> str:
    """Hash a sorted list of identifiers into a deterministic idempotency key.

    Drain passes that retry the same in-flight set of session ids must mint
    the SAME manifest id, not a fresh one each loop. Anything keyed on
    ``uuid4()`` produces a fresh manifest per call, which at scale would let
    transient retries multiply manifests for a single batch of sessions.
    """
    digest = hashlib.sha256(":".join(sorted(parts)).encode()).hexdigest()[:24]
    return f"{prefix}:{digest}"


app = typer.Typer(no_args_is_help=True, help="GigCamera operator utilities.")

_PROGRAM_KEY = "gigcamera_daily_recap"
_DEFAULT_PROGRAM_VERSION_LABEL = "four-stage-v1"
_SUBMITTED_BY = "00000000-0000-0000-0000-000000000000"
# Drain claim retry budget. After this many attempts a row is moved to the
# terminal `quarantined` status and is no longer claimable. Operators inspect
# `last_error` on quarantined rows; reset to `pending` and zero `attempt_count`
# manually once the underlying problem is fixed.
_RECAP_QUEUE_MAX_ATTEMPTS = 5


@app.callback()
def gigcamera_callback(
    ctx: typer.Context,
    env: str | None = typer.Option(
        None,
        "--env",
        "-e",
        help="Target environment. Defaults to APP_ENV, then production.",
    ),
    auth: str = typer.Option(None, "--auth", "-a", help="Auth method: iam or password."),
    user: str = typer.Option(None, "--user", "-u", help="Override database user."),
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="Auth workflow profile. Use internal_admin for writes.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose logging."),
) -> None:
    """Capture DB-targeting flags; subcommands initialize the heavy ops context."""

    ctx.ensure_object(dict)
    ctx.obj["cli_profile"] = profile
    ctx.obj["_env"] = env
    ctx.obj["_auth"] = auth
    ctx.obj["_user"] = user
    ctx.obj["_verbose"] = verbose
    ctx.obj.setdefault("allow_write", False)
    ctx.obj.setdefault("_ops_ready", False)


def _settings_for_command(ctx: typer.Context, *, write: bool) -> object:
    """Initialize and return settings for a command, preserving test-injected settings."""

    ctx.ensure_object(dict)
    ctx.obj["allow_write"] = write
    if "settings" in ctx.obj:
        return ctx.obj["settings"]
    return init_ops_context(ctx)


def _require_internal_admin_for_write(ctx: typer.Context, *, write: bool) -> None:
    """Match DB write commands by requiring an explicit internal-admin profile."""

    if not write:
        return
    profile = (ctx.obj or {}).get("cli_profile") or "engineers-dev"
    if profile != "internal_admin":
        raise typer.BadParameter("writes require --profile internal_admin")


def _parse_ist_day(value: str, *, field_name: str) -> date:
    """Parse one ISO calendar day supplied as a GigCamera IST boundary."""

    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise typer.BadParameter(f"{field_name} must be YYYY-MM-DD") from exc


def _idempotency_key(base: str, *, run_suffix: str | None) -> str:
    """Append an operator-provided resume suffix without changing default replay keys."""

    suffix = (run_suffix or "").strip()
    return f"{base}:{suffix}" if suffix else base


async def _stale_consolidated_source_rows(
    db: object,
    *,
    day_ist: date,
    source_ids: list[UUID] | None,
) -> list[dict[str, object]]:
    """List approved source rows not actually covered by same-day consolidation."""

    rows = await db.fetch(
        """
        WITH source_rows AS (
            SELECT source.*
            FROM finance.payouts source
            WHERE COALESCE(source.metadata->>'gigcamera_surface', 'false') = 'true'
              AND source.metadata->>'payout_day_ist' = $1::text
              AND COALESCE(source.metadata->>'payout_kind', 'participant_earnings') IN (
                    'participant_earnings',
                    'participant_referral_bonus'
              )
              AND source.status = 'approved'
              AND ($2::uuid[] IS NULL OR source.id = ANY($2::uuid[]))
              AND NOT EXISTS (
                    SELECT 1
                    FROM finance.disbursements source_disbursement
                    WHERE source_disbursement.payout_id = source.id
                      AND source_disbursement.status IN ('settled', 'pending', 'sent', 'processing')
              )
        ),
        stale_sources AS (
            SELECT DISTINCT ON (source.id)
                   source.id AS source_id,
                   source.metadata->>'person_display_name' AS person_display_name,
                   source.metadata->>'person_id' AS person_id,
                   COALESCE(
                       source.metadata->>'payout_kind',
                       'participant_earnings'
                   ) AS source_kind,
                   source.net_amount AS source_amount,
                   source.metadata->>'gigcamera_provider_state' AS source_provider_state,
                   source.metadata->>'gigcamera_reason' AS source_provider_reason,
                   consolidated.id AS consolidated_id,
                   consolidated.status AS consolidated_status,
                   consolidated.net_amount AS consolidated_amount,
                   consolidated.metadata->>'worker_amount_inr' AS consolidated_worker_amount,
                   consolidated.metadata->>'referral_amount_inr' AS consolidated_referral_amount,
                   consolidated.metadata->'source_payout_ids' AS consolidated_source_ids,
                   latest.status AS consolidated_disbursement_status,
                   latest.reconciled_at AS consolidated_reconciled_at
            FROM source_rows source
            JOIN finance.payouts consolidated
              ON consolidated.org_id = source.org_id
             AND COALESCE(consolidated.metadata->>'gigcamera_surface', 'false') = 'true'
             AND consolidated.metadata->>'payout_kind' = 'participant_consolidated'
             AND consolidated.metadata->>'person_id' = source.metadata->>'person_id'
             AND consolidated.metadata->>'payout_day_ist' = source.metadata->>'payout_day_ist'
             AND consolidated.status NOT IN ('voided', 'skipped')
            LEFT JOIN LATERAL (
                SELECT status, reconciled_at
                FROM finance.disbursements disbursement
                WHERE disbursement.payout_id = consolidated.id
                ORDER BY attempt_index DESC, created_at DESC
                LIMIT 1
            ) latest ON true
            WHERE NOT (
                    COALESCE(consolidated.metadata->'source_payout_ids', '[]'::jsonb)
                    ? source.id::text
            )
              AND NOT EXISTS (
                    SELECT 1
                    FROM finance.payouts explicit_consolidated
                    WHERE explicit_consolidated.org_id = source.org_id
                      AND COALESCE(
                            explicit_consolidated.metadata->>'gigcamera_surface',
                            'false'
                          ) = 'true'
                      AND explicit_consolidated.metadata->>'payout_kind'
                            = 'participant_consolidated'
                      AND explicit_consolidated.metadata->>'person_id'
                            = source.metadata->>'person_id'
                      AND explicit_consolidated.metadata->>'payout_day_ist'
                            = source.metadata->>'payout_day_ist'
                      AND explicit_consolidated.status NOT IN ('voided', 'skipped')
                      AND COALESCE(
                            explicit_consolidated.metadata->'source_payout_ids',
                            '[]'::jsonb
                          ) ? source.id::text
              )
            ORDER BY source.id, consolidated.created_at DESC, consolidated.id DESC
        )
        SELECT *
        FROM stale_sources
        ORDER BY person_display_name, source_id
        """,
        day_ist.isoformat(),
        source_ids,
    )
    return [dict(row) for row in rows]


async def _clear_false_consolidated_submit_blocks(
    db: object,
    *,
    source_ids: list[UUID],
) -> list[UUID]:
    """Clear only metadata written by the old false consolidation submit guard."""

    if not source_ids:
        return []
    rows = await db.fetch(
        """
        UPDATE finance.payouts payout
        SET metadata = jsonb_strip_nulls(
                (
                    COALESCE(payout.metadata, '{}'::jsonb)
                    - 'gigcamera_provider_state'
                    - 'gigcamera_provider_review_needed'
                    - 'gigcamera_reason'
                    - 'gigcamera_provider_status'
                    - 'gigcamera_provider_status_code'
                    - 'gigcamera_retry_policy'
                    - 'gigcamera_retry_available'
                    - 'gigcamera_retry_guidance'
                )
                || jsonb_build_object(
                    'gigcamera_consolidation_repair',
                    jsonb_build_object(
                        'kind', 'cleared_false_consolidated_submit_block',
                        'cleared_at', now()::text
                    )
                )
            ),
            updated_at = now()
        WHERE payout.id = ANY($1::uuid[])
          AND payout.status = 'approved'
          AND payout.metadata->>'gigcamera_provider_state' = 'blocked_destination'
          AND COALESCE(payout.metadata->>'gigcamera_reason', '')
                LIKE 'this row has been consolidated into payout %; submit the consolidated row instead'
        RETURNING payout.id
        """,
        source_ids,
    )
    return [UUID(str(row["id"])) for row in rows]


async def _resolve_program_version_id(
    conn: object,
    *,
    program_version_label: str,
) -> UUID:
    """Resolve the VLM program version id used to keep candidate rows isolated."""

    row = await conn.fetchrow(
        """
        SELECT version.id
        FROM observations.gigcamera_vlm_program_versions version
        JOIN observations.gigcamera_vlm_programs program
          ON program.id = version.program_id
        WHERE program.program_key = $1
          AND version.version_label = $2
        ORDER BY version.created_at DESC, version.id DESC
        LIMIT 1
        """,
        _PROGRAM_KEY,
        program_version_label,
    )
    if row is None:
        raise typer.BadParameter(
            f"unknown GigCamera recap program version: {program_version_label}"
        )
    return UUID(str(row["id"]))


async def _stale_recap_counts(
    conn: object,
    *,
    program_version_id: UUID,
) -> list[dict[str, object]]:
    """Count stale VLM recap rows without mutating the shadow control plane."""

    rows = await conn.fetch(
        """
        SELECT
            'observations.gigcamera_vlm_evaluation_outputs' AS table_name,
            count(*)::bigint AS row_count
        FROM observations.gigcamera_vlm_evaluation_outputs output
        WHERE output.program_version_id <> $1
        UNION ALL
        SELECT
            'observations.gigcamera_vlm_evaluation_batches' AS table_name,
            count(*)::bigint AS row_count
        FROM observations.gigcamera_vlm_evaluation_batches batch
        WHERE batch.program_version_id <> $1
          AND NOT EXISTS (
              SELECT 1
              FROM observations.gigcamera_vlm_evaluation_outputs output
              WHERE output.batch_id = batch.id
                AND output.program_version_id = $1
          )
        UNION ALL
        SELECT
            'finance.gigcamera_vlm_payment_evaluations' AS table_name,
            count(*)::bigint AS row_count
        FROM finance.gigcamera_vlm_payment_evaluations evaluation
        WHERE evaluation.program_version_id <> $1
        UNION ALL
        SELECT
            'finance.gigcamera_vlm_payment_line_items' AS table_name,
            count(*)::bigint AS row_count
        FROM finance.gigcamera_vlm_payment_line_items line_item
        JOIN finance.gigcamera_vlm_payment_evaluations evaluation
          ON evaluation.id = line_item.evaluation_id
        WHERE evaluation.program_version_id <> $1
        ORDER BY table_name
        """,
        program_version_id,
    )
    return [dict(row) for row in rows]


async def _delete_stale_recaps(conn: object, *, program_version_id: UUID) -> None:
    """Delete stale generated recap rows while preserving the selected version."""

    async with conn.transaction():
        await conn.execute(
            """
            DELETE FROM finance.gigcamera_vlm_payment_evaluations evaluation
            WHERE evaluation.program_version_id <> $1
            """,
            program_version_id,
        )
        await conn.execute(
            """
            DELETE FROM observations.gigcamera_vlm_evaluation_outputs output
            WHERE output.program_version_id <> $1
            """,
            program_version_id,
        )
        await conn.execute(
            """
            DELETE FROM observations.gigcamera_vlm_evaluation_batches batch
            WHERE batch.program_version_id <> $1
              AND NOT EXISTS (
                  SELECT 1
                  FROM observations.gigcamera_vlm_evaluation_outputs output
                  WHERE output.batch_id = batch.id
              )
            """,
            program_version_id,
        )


@app.command("stale-consolidation-sources")
def stale_consolidation_sources(
    ctx: typer.Context,
    day: str = typer.Option(..., "--day", help="IST payout day to inspect (YYYY-MM-DD)."),
    source_id: list[str] | None = typer.Option(
        None,
        "--source-id",
        help="Optional source payout id to constrain the repair; repeatable.",
    ),
    write: bool = typer.Option(
        False,
        "--write",
        help=(
            "Clear bogus blocked-destination metadata on affected source rows. "
            "Does not submit payments."
        ),
    ),
    format: Format = format_option(),
) -> None:
    """Audit stale source rows left outside settled participant-day consolidation."""

    parsed_day = _parse_ist_day(day, field_name="--day")
    parsed_source_ids = [UUID(value) for value in source_id or []] or None
    settings = _settings_for_command(ctx, write=write)
    _require_internal_admin_for_write(ctx, write=write)

    async def run() -> None:
        async with get_inspection_connection(settings) as conn:
            rows = await _stale_consolidated_source_rows(
                conn,
                day_ist=parsed_day,
                source_ids=parsed_source_ids,
            )
            cleared_ids: list[UUID] = []
            if write:
                async with conn.transaction():
                    cleared_ids = await _clear_false_consolidated_submit_blocks(
                        conn,
                        source_ids=[UUID(str(row["source_id"])) for row in rows],
                    )

        delta_ids = [str(row["source_id"]) for row in rows]
        block_repair_candidate_ids = [
            str(row["source_id"])
            for row in rows
            if row.get("source_provider_state") == "blocked_destination"
            and str(row.get("source_provider_reason") or "").startswith(
                "this row has been consolidated into payout "
            )
        ]
        delta_total = sum(
            (row["source_amount"] for row in rows),
            Decimal("0"),
        ).quantize(Decimal("0.01"))
        render(
            {
                "dry_run": not write,
                "day": parsed_day.isoformat(),
                "delta_payout_count": len(delta_ids),
                "delta_payout_total_inr": delta_total,
                "delta_payout_ids": delta_ids,
                "blocked_destination_repair_candidate_count": len(block_repair_candidate_ids),
                "blocked_destination_repair_candidate_ids": block_repair_candidate_ids,
                "cleared_blocked_destination_count": len(cleared_ids),
                "cleared_blocked_destination_ids": [str(value) for value in cleared_ids],
                "rows": rows,
            },
            format=format,
        )

    try:
        asyncio.run(run())
    except BrokerConnectionError as exc:
        error(str(exc))
        raise typer.Exit(1) from None


@app.command("vlm-purge-stale-recaps")
def vlm_purge_stale_recaps(
    ctx: typer.Context,
    program_version_label: str = typer.Option(
        _DEFAULT_PROGRAM_VERSION_LABEL,
        "--program-version-label",
        help="Recap program version to keep.",
    ),
    write: bool = typer.Option(False, "--write", help="Delete stale rows."),
    format: Format = format_option(),
) -> None:
    """Purge generated recap rows that do not belong to the selected comparison version."""

    settings = _settings_for_command(ctx, write=write)
    _require_internal_admin_for_write(ctx, write=write)

    async def run() -> None:
        async with get_inspection_connection(settings) as conn:
            program_version_id = await _resolve_program_version_id(
                conn,
                program_version_label=program_version_label,
            )
            before = await _stale_recap_counts(conn, program_version_id=program_version_id)
            if write:
                await _delete_stale_recaps(conn, program_version_id=program_version_id)
            after = (
                await _stale_recap_counts(conn, program_version_id=program_version_id)
                if write
                else before
            )
            render(
                {
                    "dry_run": not write,
                    "program_version_label": program_version_label,
                    "program_version_id": str(program_version_id),
                    "before": before,
                    "after": after,
                },
                format=format,
            )

    asyncio.run(run())


async def _backfill_session_plan(
    conn: object,
    *,
    from_day: date,
    to_day: date,
    program_version_id: UUID,
    max_sessions: int | None,
) -> dict[str, object]:
    """Load bounded closed-session eligibility for extract and recap enqueueing."""

    row = await conn.fetchrow(
        """
        WITH candidate_sessions AS (
            SELECT
                session.id AS upload_session_id,
                min(claim.uploaded_day_ist) AS first_uploaded_day_ist
            FROM ops.upload_sessions session
            JOIN ops.participant_clip_fingerprint_claims claim
              ON claim.upload_session_id = session.id
            WHERE session.status = 'ingest_succeeded'
              AND claim.core_clip_id IS NOT NULL
              AND claim.uploaded_day_ist BETWEEN $1 AND $2
            GROUP BY session.id
            ORDER BY min(claim.uploaded_day_ist), session.id
            LIMIT COALESCE($4::integer, 2147483647)
        ),
        session_stats AS (
            SELECT
                candidate_sessions.upload_session_id,
                count(DISTINCT claim.id)::int AS claim_count,
                count(DISTINCT sf.frame_id)::int AS sampled_frame_count,
                bool_or(sf.frame_id IS NULL) AS has_missing_frames,
                EXISTS (
                    SELECT 1
                    FROM observations.gigcamera_vlm_evaluation_outputs output
                    WHERE output.program_version_id = $3
                      AND output.output_scope = 'aggregate'
                      AND output.upload_session_id = candidate_sessions.upload_session_id
                ) AS has_completed_recap
            FROM candidate_sessions
            JOIN ops.participant_clip_fingerprint_claims claim
              ON claim.upload_session_id = candidate_sessions.upload_session_id
             AND claim.core_clip_id IS NOT NULL
            LEFT JOIN processing.sampled_frames sf
              ON sf.clip_id = claim.core_clip_id
            GROUP BY candidate_sessions.upload_session_id
        )
        SELECT
            count(*)::int AS candidate_session_count,
            COALESCE(sum(claim_count), 0)::int AS candidate_claim_count,
            count(*) FILTER (WHERE has_missing_frames)::int AS sessions_missing_frames,
            COALESCE(sum(claim_count - LEAST(claim_count, sampled_frame_count))
                FILTER (WHERE has_missing_frames), 0)::int AS expected_extract_item_count,
            count(*) FILTER (
                WHERE sampled_frame_count >= claim_count
                  AND NOT has_completed_recap
            )::int AS sessions_ready_for_recap,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (WHERE true), ARRAY[]::uuid[]) AS candidate_session_ids,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (
                    WHERE sampled_frame_count >= claim_count
                      AND NOT has_completed_recap
                ), ARRAY[]::uuid[]) AS recap_session_ids
        FROM session_stats
        """,
        from_day,
        to_day,
        program_version_id,
        max_sessions,
    )
    if row is None:
        return {
            "candidate_session_count": 0,
            "candidate_claim_count": 0,
            "sessions_missing_frames": 0,
            "expected_extract_item_count": 0,
            "sessions_ready_for_recap": 0,
            "candidate_session_ids": [],
            "recap_session_ids": [],
        }
    return dict(row)


async def _pending_recap_queue_status_counts(conn: object) -> list[dict[str, object]]:
    """Summarize the future-session VLM recap queue without claiming work."""

    rows = await conn.fetch(
        """
        SELECT status, count(*)::int AS row_count
        FROM processing.gigcamera_recap_pending_queue
        GROUP BY status
        ORDER BY status
        """
    )
    return [dict(row) for row in rows]


async def _pending_recap_claimable_count(
    conn: object,
    *,
    limit: int,
    upload_session_ids: list[UUID] | None = None,
) -> int:
    """Count queue rows the drain command would claim on this invocation."""

    session_filter_sql = "AND upload_session_id = ANY($3::uuid[])" if upload_session_ids else ""
    args: tuple[object, ...] = (
        (limit, _RECAP_QUEUE_MAX_ATTEMPTS, upload_session_ids)
        if upload_session_ids
        else (limit, _RECAP_QUEUE_MAX_ATTEMPTS)
    )
    row = await conn.fetchrow(
        f"""
        SELECT count(*)::int AS claimable_count
        FROM (
            SELECT upload_session_id
            FROM processing.gigcamera_recap_pending_queue
            WHERE status IN ('pending', 'extract_enqueued', 'failed')
              AND (lease_expires_at IS NULL OR lease_expires_at <= now())
              AND attempt_count < $2
              {session_filter_sql}
            ORDER BY enqueued_at, upload_session_id
            LIMIT $1
        ) claimable
        """,
        *args,
    )
    return int(row["claimable_count"] if row else 0)


async def _quarantine_exhausted_pending_recap_rows(conn: object) -> int:
    """Move rows whose attempt budget is exceeded into terminal 'quarantined' status."""

    row = await conn.fetchrow(
        """
        WITH exhausted AS (
            SELECT upload_session_id
            FROM processing.gigcamera_recap_pending_queue
            WHERE status IN ('pending', 'extract_enqueued', 'failed')
              AND attempt_count >= $1
        ),
        quarantined AS (
            UPDATE processing.gigcamera_recap_pending_queue pending
            SET status = 'quarantined',
                claimed_at = NULL,
                lease_expires_at = NULL,
                last_deferred_reason = 'attempt_budget_exhausted',
                updated_at = now()
            FROM exhausted
            WHERE pending.upload_session_id = exhausted.upload_session_id
            RETURNING pending.upload_session_id
        )
        SELECT count(*)::int AS quarantined_count FROM quarantined
        """,
        _RECAP_QUEUE_MAX_ATTEMPTS,
    )
    return int(row["quarantined_count"] if row else 0)


async def _claim_pending_recap_sessions(
    conn: object,
    *,
    limit: int,
    upload_session_ids: list[UUID] | None = None,
) -> list[UUID]:
    """Lease a bounded batch of future-session recap queue rows for one worker pass."""

    session_filter_sql = "AND upload_session_id = ANY($3::uuid[])" if upload_session_ids else ""
    args: tuple[object, ...] = (
        (limit, _RECAP_QUEUE_MAX_ATTEMPTS, upload_session_ids)
        if upload_session_ids
        else (limit, _RECAP_QUEUE_MAX_ATTEMPTS)
    )
    row = await conn.fetchrow(
        f"""
        WITH next_claims AS (
            SELECT upload_session_id
            FROM processing.gigcamera_recap_pending_queue
            WHERE status IN ('pending', 'extract_enqueued', 'failed')
              AND (lease_expires_at IS NULL OR lease_expires_at <= now())
              AND attempt_count < $2
              {session_filter_sql}
            ORDER BY enqueued_at, upload_session_id
            LIMIT $1
            FOR UPDATE SKIP LOCKED
        ),
        claimed AS (
            UPDATE processing.gigcamera_recap_pending_queue pending
            SET updated_at = now(),
                claimed_at = now(),
                lease_expires_at = now() + interval '5 minutes',
                last_attempted_at = now(),
                attempt_count = pending.attempt_count + 1,
                last_error = NULL,
                last_deferred_reason = NULL
            FROM next_claims
            WHERE pending.upload_session_id = next_claims.upload_session_id
            RETURNING pending.upload_session_id
        )
        SELECT COALESCE(
            array_agg(upload_session_id ORDER BY upload_session_id),
            ARRAY[]::uuid[]
        ) AS claimed_session_ids
        FROM claimed
        """,
        *args,
    )
    values = row["claimed_session_ids"] if row else []
    return [UUID(str(value)) for value in values]


async def _pending_recap_drain_plan(
    conn: object,
    *,
    upload_session_ids: list[UUID],
    program_version_id: UUID,
) -> dict[str, list[UUID]]:
    """Classify claimed sessions into extraction, recap, completed, deferred, or skipped work.

    Sessions whose previously-enqueued extract manifest is still in flight
    (status NOT IN terminal states) are returned as ``deferred_session_ids``
    so the caller can bump their lease without minting a duplicate extract
    manifest. Without this dedup, every drain pass on an in-flight session
    would create a fresh extract manifest, multiplying load.
    """

    if not upload_session_ids:
        return {
            "missing_frame_session_ids": [],
            "ready_recap_session_ids": [],
            "completed_session_ids": [],
            "skipped_session_ids": [],
            "deferred_session_ids": [],
        }
    row = await conn.fetchrow(
        """
        WITH claimed AS (
            SELECT unnest($1::uuid[]) AS upload_session_id
        ),
        stats AS (
            SELECT
                claimed.upload_session_id,
                count(DISTINCT claim.id)::int AS claim_count,
                count(DISTINCT sf.frame_id)::int AS sampled_frame_count,
                EXISTS (
                    SELECT 1
                    FROM observations.gigcamera_vlm_evaluation_outputs output
                    WHERE output.program_version_id = $2
                      AND output.output_scope = 'aggregate'
                      AND output.upload_session_id = claimed.upload_session_id
                      AND output.status = 'completed'
                ) AS has_completed_recap,
                EXISTS (
                    SELECT 1
                    FROM processing.gigcamera_recap_pending_queue queue
                    JOIN processing.manifests manifest
                      ON manifest.id = queue.extract_manifest_id
                    WHERE queue.upload_session_id = claimed.upload_session_id
                      AND manifest.status NOT IN ('succeeded', 'failed', 'cancelled')
                ) AS has_inflight_extract
            FROM claimed
            LEFT JOIN ops.upload_sessions session
              ON session.id = claimed.upload_session_id
            LEFT JOIN ops.participant_clip_fingerprint_claims claim
              ON claim.upload_session_id = session.id
             AND claim.core_clip_id IS NOT NULL
            LEFT JOIN processing.sampled_frames sf
              ON sf.clip_id = claim.core_clip_id
             AND sf.selection_kind = 'near_90s'
            GROUP BY claimed.upload_session_id
        )
        SELECT
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (
                    WHERE claim_count > 0
                      AND sampled_frame_count < claim_count
                      AND NOT has_completed_recap
                      AND NOT has_inflight_extract
                ), ARRAY[]::uuid[]) AS missing_frame_session_ids,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (
                    WHERE claim_count > 0
                      AND sampled_frame_count >= claim_count
                      AND NOT has_completed_recap
                ), ARRAY[]::uuid[]) AS ready_recap_session_ids,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (WHERE has_completed_recap), ARRAY[]::uuid[]) AS completed_session_ids,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (
                    WHERE claim_count = 0
                      AND NOT has_completed_recap
                ), ARRAY[]::uuid[]) AS skipped_session_ids,
            COALESCE(array_agg(upload_session_id ORDER BY upload_session_id)
                FILTER (
                    WHERE claim_count > 0
                      AND sampled_frame_count < claim_count
                      AND NOT has_completed_recap
                      AND has_inflight_extract
                ), ARRAY[]::uuid[]) AS deferred_session_ids
        FROM stats
        """,
        upload_session_ids,
        program_version_id,
    )
    if row is None:
        return {
            "missing_frame_session_ids": [],
            "ready_recap_session_ids": [],
            "completed_session_ids": [],
            "skipped_session_ids": [],
            "deferred_session_ids": [],
        }
    return {
        "missing_frame_session_ids": [
            UUID(str(value)) for value in row["missing_frame_session_ids"]
        ],
        "ready_recap_session_ids": [UUID(str(value)) for value in row["ready_recap_session_ids"]],
        "completed_session_ids": [UUID(str(value)) for value in row["completed_session_ids"]],
        "skipped_session_ids": [UUID(str(value)) for value in row["skipped_session_ids"]],
        "deferred_session_ids": [UUID(str(value)) for value in row["deferred_session_ids"]],
    }


async def _mark_pending_recap_rows(
    conn: object,
    *,
    upload_session_ids: list[UUID],
    status: str,
    manifest_id: str | None = None,
    deferred_reason: str | None = None,
    error: str | None = None,
) -> None:
    """Release claimed queue rows with the manifest or terminal status reached."""

    if not upload_session_ids:
        return
    await conn.execute(
        """
        UPDATE processing.gigcamera_recap_pending_queue
        SET updated_at = now(),
            status = $2,
            claimed_at = NULL,
            lease_expires_at = CASE
                WHEN $2 = 'extract_enqueued' THEN now() + interval '5 minutes'
                WHEN $2 = 'failed' THEN now() + interval '1 minute'
                ELSE NULL::timestamptz
            END,
            extract_manifest_id = CASE
                WHEN $2 = 'extract_enqueued' THEN $3
                ELSE extract_manifest_id
            END,
            recap_manifest_id = CASE
                WHEN $2 = 'recap_enqueued' THEN $3
                ELSE recap_manifest_id
            END,
            last_error = $5,
            last_deferred_reason = $4
        WHERE upload_session_id = ANY($1::uuid[])
        """,
        upload_session_ids,
        status,
        manifest_id,
        deferred_reason,
        error,
    )


@app.command("vlm-drain-pending-recaps")
def vlm_drain_pending_recaps(
    ctx: typer.Context,
    program_version_label: str = typer.Option(
        _DEFAULT_PROGRAM_VERSION_LABEL,
        "--program-version-label",
        help="Recap program version to compare.",
    ),
    limit: int = typer.Option(25, "--limit", min=1, max=500, help="Rows to claim."),
    upload_session_ids: list[UUID] | None = typer.Option(
        None,
        "--upload-session-id",
        help="Restrict this drain pass to one or more already-queued upload sessions.",
    ),
    write: bool = typer.Option(False, "--write", help="Claim rows and enqueue manifests."),
    format: Format = format_option(),
) -> None:
    """Drain future closed-session VLM recap queue rows into processing manifests."""

    settings = _settings_for_command(ctx, write=write)
    _require_internal_admin_for_write(ctx, write=write)

    async def run() -> None:
        async with get_inspection_connection(settings) as conn:
            program_version_id = await _resolve_program_version_id(
                conn,
                program_version_label=program_version_label,
            )
            status_counts = await _pending_recap_queue_status_counts(conn)
            claimable_count = await _pending_recap_claimable_count(
                conn,
                limit=limit,
                upload_session_ids=upload_session_ids,
            )
            drain_summary: dict[str, object] = {
                "claimed_count": 0,
                "missing_frame_session_count": 0,
                "ready_recap_session_count": 0,
                "completed_session_count": 0,
                "skipped_session_count": 0,
                "deferred_session_count": 0,
                "quarantined_count": 0,
                "max_attempts": _RECAP_QUEUE_MAX_ATTEMPTS,
                "manifest_count": 0,
                "manifests": [],
            }

            if write:
                from dal.processing import recap_drain

                async with get_cli_context(
                    settings,
                    profile=ctx.obj.get("cli_profile"),
                ) as (_db, dal_ctx):
                    drain_summary = await recap_drain.run_drain_pass(
                        dal_ctx,
                        program_version_label=program_version_label,
                        limit=limit,
                        upload_session_ids=upload_session_ids,
                        submitted_by_principal=_SUBMITTED_BY,
                        max_attempts=_RECAP_QUEUE_MAX_ATTEMPTS,
                    )

            render(
                {
                    "dry_run": not write,
                    "program_version_label": program_version_label,
                    "program_version_id": str(program_version_id),
                    "limit": limit,
                    "upload_session_ids": [
                        str(upload_session_id) for upload_session_id in upload_session_ids or []
                    ],
                    "claimable_count": claimable_count,
                    "claimed_count": drain_summary["claimed_count"],
                    "status_counts": status_counts,
                    "missing_frame_session_count": drain_summary["missing_frame_session_count"],
                    "ready_recap_session_count": drain_summary["ready_recap_session_count"],
                    "completed_session_count": drain_summary["completed_session_count"],
                    "skipped_session_count": drain_summary["skipped_session_count"],
                    "deferred_session_count": drain_summary["deferred_session_count"],
                    "quarantined_count": drain_summary["quarantined_count"],
                    "max_attempts": drain_summary["max_attempts"],
                    "manifest_count": drain_summary["manifest_count"],
                    "manifests": drain_summary["manifests"],
                },
                format=format,
            )

    asyncio.run(run())


@app.command("vlm-advance-chunking", hidden=True)
def vlm_advance_chunking(
    ctx: typer.Context,
    manifest_id: str = typer.Option(..., "--manifest-id", help="Manifest to drive."),
    page_size: int = typer.Option(200, "--page-size", min=1, max=1000),
    write: bool = typer.Option(False, "--write", help="Actually advance chunking."),
    format: Format = format_option(),
) -> None:
    """Page through ``advance_chunking_manifest`` for one manifest.

    Operator-only escape hatch when the production processing-api auto-run
    tick endpoint is degraded: drives manifest chunking from the operator
    side via internal_admin auth instead of waiting for the cron tick.
    """

    settings = _settings_for_command(ctx, write=write)
    _require_internal_admin_for_write(ctx, write=write)

    async def run() -> None:
        from dal.processing import manifests as mfsts

        pages: list[dict[str, object]] = []
        async with get_cli_context(settings, profile=ctx.obj.get("cli_profile")) as (_db, dal_ctx):
            while write:
                result = await mfsts.advance_chunking_manifest(
                    dal_ctx, manifest_id, page_size=page_size
                )
                pages.append(
                    {
                        "items_added": int(result["items_added"]),
                        "total_so_far": int(result.get("total_items_so_far") or 0),
                        "completed": bool(result["completed"]),
                    }
                )
                if result["completed"]:
                    break
            if not write:
                check = await mfsts.list_chunking_manifests(dal_ctx, limit=50)
                pages.append({"chunking_manifests": [str(row["id"]) for row in check]})

        render(
            {
                "dry_run": not write,
                "manifest_id": manifest_id,
                "page_size": page_size,
                "page_count": sum(1 for p in pages if "items_added" in p),
                "pages": pages,
            },
            format=format,
        )

    asyncio.run(run())


@app.command("vlm-backfill")
def vlm_backfill(
    ctx: typer.Context,
    from_day: str = typer.Option(..., "--from", help="Inclusive start IST date."),
    to_day: str = typer.Option(..., "--to", help="Inclusive end IST date."),
    program_version_label: str = typer.Option(
        _DEFAULT_PROGRAM_VERSION_LABEL,
        "--program-version-label",
        help="Recap program version to compare.",
    ),
    phase: Literal["extract", "recap", "both"] = typer.Option(
        "both",
        "--phase",
        help="Backfill phase to enqueue.",
    ),
    max_sessions: int | None = typer.Option(
        None,
        "--max-sessions",
        min=1,
        help="Optional cap on closed sessions selected for this invocation.",
    ),
    run_suffix: str | None = typer.Option(
        None,
        "--run-suffix",
        help=(
            "Optional suffix for fresh resume manifests after a partial failed run. "
            "Leave unset to replay the canonical date-window idempotency key."
        ),
    ),
    write: bool = typer.Option(False, "--write", help="Create processing manifests."),
    format: Format = format_option(),
) -> None:
    """Dry-run or enqueue historical GigCamera VLM extract and recap manifests."""

    parsed_from_day = _parse_ist_day(from_day, field_name="--from")
    parsed_to_day = _parse_ist_day(to_day, field_name="--to")
    if parsed_from_day > parsed_to_day:
        raise typer.BadParameter("--from must be before or equal to --to")
    settings = _settings_for_command(ctx, write=write)
    _require_internal_admin_for_write(ctx, write=write)

    async def run() -> None:
        async with get_inspection_connection(settings) as conn:
            program_version_id = await _resolve_program_version_id(
                conn,
                program_version_label=program_version_label,
            )
            plan = await _backfill_session_plan(
                conn,
                from_day=parsed_from_day,
                to_day=parsed_to_day,
                program_version_id=program_version_id,
                max_sessions=max_sessions,
            )

        manifests: list[dict[str, object]] = []
        if write:
            from dal.processing import media_jobs

            candidate_ids = [str(value) for value in plan["candidate_session_ids"]]
            recap_ids = [str(value) for value in plan["recap_session_ids"]]
            async with get_cli_context(settings, profile=ctx.obj.get("cli_profile")) as (
                _db,
                dal_ctx,
            ):
                if phase in {"extract", "both"} and candidate_ids:
                    manifest = await media_jobs.queue_processor_job(
                        dal_ctx,
                        processor_ref=media_jobs.GIGCAMERA_NORMALIZE_EXTRACT_PROCESSOR_REF,
                        selection_spec={
                            "kind": "gigcamera_uploads",
                            "upload_session_ids": candidate_ids,
                            "only_missing_frames": True,
                        },
                        sink_overrides=None,
                        resource_overrides=None,
                        submitted_by_principal=_SUBMITTED_BY,
                        idempotency_key=_idempotency_key(
                            (
                                "gigcamera-vlm-backfill-extract:"
                                f"{parsed_from_day}:{parsed_to_day}:"
                                f"{program_version_label}:{max_sessions or 'all'}"
                            ),
                            run_suffix=run_suffix,
                        ),
                    )
                    manifests.append({"phase": "extract", "manifest_id": manifest["id"]})
                if phase in {"recap", "both"} and recap_ids:
                    manifest = await media_jobs.queue_processor_job(
                        dal_ctx,
                        processor_ref=media_jobs.GIGCAMERA_DAILY_RECAP_PROCESSOR_REF,
                        selection_spec={
                            "kind": "gigcamera_sessions",
                            "upload_session_ids": recap_ids,
                            "selection_kind": "near_90s",
                            "exclude_completed": True,
                        },
                        sink_overrides=None,
                        resource_overrides=None,
                        submitted_by_principal=_SUBMITTED_BY,
                        idempotency_key=_idempotency_key(
                            (
                                "gigcamera-vlm-backfill-recap:"
                                f"{parsed_from_day}:{parsed_to_day}:"
                                f"{program_version_label}:{max_sessions or 'all'}"
                            ),
                            run_suffix=run_suffix,
                        ),
                    )
                    manifests.append({"phase": "recap", "manifest_id": manifest["id"]})

        render(
            {
                "dry_run": not write,
                "from_day": parsed_from_day.isoformat(),
                "to_day": parsed_to_day.isoformat(),
                "phase": phase,
                "run_suffix": run_suffix,
                "program_version_label": program_version_label,
                "program_version_id": str(program_version_id),
                "candidate_session_count": plan["candidate_session_count"],
                "candidate_claim_count": plan["candidate_claim_count"],
                "sessions_missing_frames": plan["sessions_missing_frames"],
                "expected_extract_item_count": plan["expected_extract_item_count"],
                "sessions_ready_for_recap": plan["sessions_ready_for_recap"],
                "manifest_count": len(manifests),
                "manifests": manifests,
            },
            format=format,
        )

    asyncio.run(run())
