"""Inspect and validate Build AI's local authentication workflows.

This module separates local developer auth from API credential auth so the CLI
can explain Google Cloud, ADC, impersonation, and sanctioned workflow profiles
without relying on tribal knowledge or ambient shell state.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_GCP_PROJECT = "data-470400"
DEFAULT_ENVIRONMENT = "development"
TOKENINFO_URL = "https://www.googleapis.com/oauth2/v1/tokeninfo"
ADC_PATH = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
REPO_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class CommandResult:
    """Capture one subprocess execution without leaking shell-specific details.

    Auth diagnostics need the exact stdout/stderr emitted by `gcloud`, but they
    also need a stable shape that tests can patch and higher-level code can
    render consistently.
    """

    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str


@dataclass(frozen=True)
class LocalAuthProfile:
    """Describe one sanctioned local workflow identity.

    These profiles are intentionally few and named. Each one maps to a real
    workflow, an intended human audience, and an optional impersonation target.
    """

    name: str
    audience: str
    summary: str
    purpose: str
    requires_service: bool = False
    break_glass: bool = False
    db_access: bool = True


@dataclass(frozen=True)
class ResolvedLocalAuthProfile:
    """Bind a profile template to any concrete runtime target it needs.

    For example, `api-runtime-like` becomes actionable only after resolving a
    concrete API surface such as `core` or `ops`.
    """

    name: str
    audience: str
    summary: str
    purpose: str
    environment: str
    service_slug: str | None = None
    target_service_account: str | None = None
    target_db_user: str | None = None
    break_glass: bool = False
    db_access: bool = True

    def bootstrap_exports(self) -> list[str]:
        """Return explicit env wiring for workflows that need local runtime parity.

        The bootstrap output is designed to be copyable by a human or an agent
        without introducing another hidden config plane.
        """

        suffix = env_suffix(self.environment)
        exports = [f"export APP_ENV={self.environment}"]
        if (
            self.name in {"engineers-dev", "api-runtime-like"}
            and self.target_db_user
            and self.target_service_account
        ):
            exports.extend(
                [
                    f'export ALLOYDB_USER_{suffix}="{self.target_db_user}"',
                    f'export ALLOYDB_IAM_AUTH_{suffix}="true"',
                ]
            )
            exports.extend(
                [
                    f'export ALLOYDB_RUNTIME_IMPERSONATE_SA_{suffix}="{self.target_service_account}"',
                    f'export ALLOYDB_USE_AUTH_PROXY_{suffix}="true"',
                ]
            )
        elif self.name == "db-admin-local" and self.target_db_user and self.target_service_account:
            exports.extend(
                [
                    f'export ALLOYDB_ADMIN_IAM_USER_{suffix}="{self.target_db_user}"',
                    f'export ALLOYDB_ADMIN_IMPERSONATE_SA_{suffix}="{self.target_service_account}"',
                ]
            )
        return exports


@dataclass(frozen=True)
class AuthCheckResult:
    """Represent one doctor/check row with remediation text.

    Keeping the result shape explicit makes the same engine reusable for human
    `doctor` output, JSON automation, and tests.
    """

    code: str
    level: str
    ok: bool
    summary: str
    fix: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LocalAuthState:
    """Snapshot the machine-local auth surfaces that commonly drift apart.

    The CLI cares about both `gcloud` state and ADC state because Google treats
    them as related but distinct planes.
    """

    gcloud_available: bool
    gcloud_account: str | None
    gcloud_project: str | None
    gcloud_impersonate_service_account: str | None
    adc_path: str
    adc_exists: bool
    adc_type: str | None
    adc_target_principal: str | None
    adc_email: str | None
    adc_access_token_ok: bool
    adc_access_token_error: str | None
    api_status: str
    api_subject: str | None
    api_display_name: str | None
    api_error: str | None


@dataclass(frozen=True)
class AuthReport:
    """Bundle raw state, resolved profile, and check results for one run.

    Commands can render this report differently, but the underlying facts stay
    the same whether the caller is a human, a script, or an agent.
    """

    state: LocalAuthState
    profile: ResolvedLocalAuthProfile | None
    checks: tuple[AuthCheckResult, ...]
    next_steps: tuple[str, ...]

    @property
    def exit_code(self) -> int:
        """Return a process-friendly status code for the overall report."""

        return 1 if any(not check.ok and check.level == "error" for check in self.checks) else 0


def env_suffix(environment: str) -> str:
    """Translate the human-facing lane name into the env-var suffix convention."""

    normalized = environment.strip().lower()
    if normalized == "development":
        return "DEV"
    if normalized == "staging":
        return "STAGING"
    if normalized == "preview":
        return "PREVIEW"
    if normalized == "production":
        return "PROD"
    if normalized == "test":
        return "DEV"
    raise ValueError(f"Unsupported environment: {environment}")


def sanctioned_auth_profiles() -> tuple[LocalAuthProfile, ...]:
    """Return the supported local auth workflows in stable display order."""

    return (
        LocalAuthProfile(
            name="engineers-dev",
            audience="engineers",
            summary="Use the engineer-facing read-only DB lane.",
            purpose=(
                "Use this for direct CLI database reads and schema inspection through the "
                "engineer-facing service-account identity. Local API runtime parity should "
                "use the service-runtime profiles instead."
            ),
        ),
        LocalAuthProfile(
            name="api-runtime-like",
            audience="engineers",
            summary="Run local code with an explicit API runtime identity.",
            purpose="Use this for local parity with one deployed API surface.",
            requires_service=True,
        ),
        LocalAuthProfile(
            name="migrations-local",
            audience="founders",
            summary="Run migration flows through the canonical migrations identity.",
            purpose="Use this for reviewed DDL and scheduler ownership work.",
        ),
        LocalAuthProfile(
            name="db-admin-local",
            audience="founders",
            summary="Use the canonical AlloyDB admin identity for platform DB work.",
            purpose="Use this only for platform-level DB support and ownership repair.",
            break_glass=True,
        ),
        LocalAuthProfile(
            name="quarantine-policy-admin",
            audience="founders",
            summary="Operate the quarantine deny-policy control plane explicitly.",
            purpose="Use this only for storage deny-policy and quarantine-control work.",
            break_glass=True,
            db_access=False,
        ),
    )


def _service_targets(environment: str = DEFAULT_ENVIRONMENT) -> dict[str, dict[str, str]]:
    """Load API runtime targets from the checked-in service catalog when available."""

    try:
        from api.service_catalog import list_api_services
    except Exception:
        return {}

    catalog_environment = "staging" if environment.strip().lower() == "staging" else "production"
    return {
        service.service_slug: {
            "service_account": service.runtime_service_account,
            "db_user": service.runtime_db_user,
        }
        for service in list_api_services(catalog_environment)
    }


def resolve_sanctioned_profile(
    name: str,
    *,
    service: str | None = None,
    environment: str = DEFAULT_ENVIRONMENT,
) -> ResolvedLocalAuthProfile:
    """Resolve one profile name into a concrete target identity contract."""

    profiles = {profile.name: profile for profile in sanctioned_auth_profiles()}
    profile = profiles.get(name)
    if profile is None:
        valid = ", ".join(sorted(profiles))
        raise ValueError(f"Unknown auth profile '{name}'. Valid profiles: {valid}.")

    if profile.requires_service:
        if not service:
            raise ValueError(f"Profile '{name}' requires --service <slug>.")
        service_targets = _service_targets(environment)
        target = service_targets.get(service)
        if target is None:
            known = ", ".join(sorted(service_targets))
            raise ValueError(
                "API runtime targets are unavailable or the service slug is unknown. "
                f"Known services: {known or '(workspace install required)'}."
            )
        return ResolvedLocalAuthProfile(
            name=profile.name,
            audience=profile.audience,
            summary=profile.summary,
            purpose=profile.purpose,
            environment=environment,
            service_slug=service,
            target_service_account=target["service_account"],
            target_db_user=target["db_user"],
            break_glass=profile.break_glass,
            db_access=profile.db_access,
        )

    fixed_targets = _fixed_targets_for_environment(environment)
    target_service_account, target_db_user = fixed_targets[profile.name]
    return ResolvedLocalAuthProfile(
        name=profile.name,
        audience=profile.audience,
        summary=profile.summary,
        purpose=profile.purpose,
        environment=environment,
        target_service_account=target_service_account,
        target_db_user=target_db_user,
        break_glass=profile.break_glass,
        db_access=profile.db_access,
    )


def _fixed_targets_for_environment(
    environment: str,
) -> dict[str, tuple[str, str | None]]:
    """Return concrete fixed-profile identities for the selected environment."""

    if environment.strip().lower() == "staging":
        return {
            "engineers-dev": (
                "engineers-staging-sa@data-470400.iam.gserviceaccount.com",
                "engineers-staging-sa@data-470400.iam",
            ),
            "migrations-local": (
                "buildai-migrations-staging-sa@data-470400.iam.gserviceaccount.com",
                "buildai-migrations-staging-sa@data-470400.iam",
            ),
            "db-admin-local": (
                "buildai-db-admin-staging-sa@data-470400.iam.gserviceaccount.com",
                "buildai-db-admin-staging-sa@data-470400.iam",
            ),
            "quarantine-policy-admin": (
                "quarantine-policy-admin@data-470400.iam.gserviceaccount.com",
                None,
            ),
        }

    return {
        "engineers-dev": (
            "engineers-dev-sa@data-470400.iam.gserviceaccount.com",
            "engineers-dev-sa@data-470400.iam",
        ),
        "migrations-local": (
            "buildai-migrations-sa@data-470400.iam.gserviceaccount.com",
            "buildai-migrations-sa@data-470400.iam",
        ),
        "db-admin-local": (
            "buildai-db-admin-sa@data-470400.iam.gserviceaccount.com",
            "buildai-db-admin-sa@data-470400.iam",
        ),
        "quarantine-policy-admin": (
            "quarantine-policy-admin@data-470400.iam.gserviceaccount.com",
            None,
        ),
    }


def _run_command(argv: list[str], *, timeout: int = 20) -> CommandResult:
    """Run one external command with bounded time and normalized output fields."""

    try:
        completed = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        return CommandResult(
            argv=tuple(argv),
            returncode=127,
            stdout="",
            stderr=f"{argv[0]} is not installed or is not on PATH: {exc}",
        )
    except subprocess.TimeoutExpired as exc:
        return CommandResult(
            argv=tuple(argv),
            returncode=124,
            stdout=(exc.stdout or "").strip() if isinstance(exc.stdout, str) else "",
            stderr=(exc.stderr or "").strip() if isinstance(exc.stderr, str) else "Command timed out.",
        )
    return CommandResult(
        argv=tuple(argv),
        returncode=completed.returncode,
        stdout=completed.stdout.strip(),
        stderr=completed.stderr.strip(),
    )


def _gcloud_value(path: str) -> str | None:
    """Read one `gcloud config get-value` field without raising on unset values."""

    result = _run_command(["gcloud", "config", "get-value", path], timeout=10)
    if result.returncode != 0:
        return None
    value = result.stdout.strip()
    if not value or value == "(unset)":
        return None
    return value


def _read_adc_file() -> dict[str, Any]:
    """Parse the ADC JSON file when it exists and looks valid."""

    if not ADC_PATH.exists():
        return {}
    try:
        return json.loads(ADC_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _extract_impersonation_target(payload: dict[str, Any]) -> str | None:
    """Recover the service-account email from ADC metadata when present."""

    if payload.get("type") == "service_account":
        value = payload.get("client_email")
        return value if isinstance(value, str) and value else None

    url = payload.get("service_account_impersonation_url")
    if isinstance(url, str) and "/serviceAccounts/" in url:
        tail = url.rsplit("/serviceAccounts/", 1)[-1]
        target = tail.split(":generateAccessToken", 1)[0]
        return urllib.parse.unquote(target)

    source = payload.get("source_credentials")
    if isinstance(source, dict):
        return _extract_impersonation_target(source)
    return None


def _inspect_access_token(token: str) -> dict[str, Any]:
    """Ask Google's token introspection endpoint for email and expiry metadata."""

    if not token:
        return {}

    body = urllib.parse.urlencode({"access_token": token}).encode("utf-8")
    request = urllib.request.Request(
        TOKENINFO_URL,
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return {}


def inspect_api_auth_state() -> dict[str, Any]:
    """Resolve public API auth status without making it a hard dependency.

    Local auth work should still be inspectable even when the API credential is
    missing or the remote API is temporarily unavailable.
    """

    from cli.config import resolve_credential

    try:
        resolve_credential()
    except Exception as exc:
        return {"status": "missing", "error": str(exc)}

    try:
        from cli.internal_api import get_internal_api_client

        client = get_internal_api_client()
        try:
            access = client.access.inspect()
        finally:
            client.close()
        return {
            "status": "ok",
            "subject": access.principal_subject,
            "display_name": access.principal_display_name,
        }
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


def inspect_local_auth_state() -> LocalAuthState:
    """Gather the machine-local auth facts that most commonly drift apart."""

    gcloud_available = shutil.which("gcloud") is not None
    gcloud_account = _gcloud_value("account") if gcloud_available else None
    gcloud_project = _gcloud_value("project") if gcloud_available else None
    gcloud_impersonate = (
        _gcloud_value("auth/impersonate_service_account") if gcloud_available else None
    )

    adc_payload = _read_adc_file()
    adc_exists = ADC_PATH.exists()
    adc_type = adc_payload.get("type") if isinstance(adc_payload, dict) else None
    adc_target_principal = _extract_impersonation_target(adc_payload)

    adc_email = None
    adc_access_token_ok = False
    adc_access_token_error = None
    if gcloud_available:
        token_result = _run_command(["gcloud", "auth", "application-default", "print-access-token"])
        adc_access_token_ok = token_result.returncode == 0 and bool(token_result.stdout)
        if adc_access_token_ok:
            token_info = _inspect_access_token(token_result.stdout)
            email = token_info.get("email")
            if isinstance(email, str) and email:
                adc_email = email
        else:
            adc_access_token_error = (
                token_result.stderr or token_result.stdout or "Token mint failed."
            )

    api_state = inspect_api_auth_state()
    return LocalAuthState(
        gcloud_available=gcloud_available,
        gcloud_account=gcloud_account,
        gcloud_project=gcloud_project,
        gcloud_impersonate_service_account=gcloud_impersonate,
        adc_path=str(ADC_PATH),
        adc_exists=adc_exists,
        adc_type=adc_type if isinstance(adc_type, str) else None,
        adc_target_principal=adc_target_principal,
        adc_email=adc_email,
        adc_access_token_ok=adc_access_token_ok,
        adc_access_token_error=adc_access_token_error,
        api_status=str(api_state.get("status", "missing")),
        api_subject=api_state.get("subject") if isinstance(api_state.get("subject"), str) else None,
        api_display_name=(
            api_state.get("display_name")
            if isinstance(api_state.get("display_name"), str)
            else None
        ),
        api_error=api_state.get("error") if isinstance(api_state.get("error"), str) else None,
    )


def _development_lane_is_codified() -> tuple[bool, str]:
    """Report whether the dev AlloyDB lane has repo-owned IAM user truth today."""

    path = REPO_ROOT / "infra/production/database-dev/terragrunt.hcl"
    if not path.exists():
        return False, f"Missing {path}"
    text = path.read_text(encoding="utf-8")
    if "iam_users = []" in text:
        return (
            False,
            "infra/production/database-dev/terragrunt.hcl still declares `iam_users = []`.",
        )
    return True, "Development lane IAM users are codified in repo truth."


def bootstrap_commands(
    *,
    profile: ResolvedLocalAuthProfile | None = None,
) -> tuple[str, ...]:
    """Generate the explicit commands a user should run for the happy path."""

    steps: list[str] = [
        "gcloud auth login",
        "gcloud auth application-default login",
        f"gcloud config set project {DEFAULT_GCP_PROJECT}",
        "gcloud config unset auth/impersonate_service_account",
        "uv run buildai doctor auth",
    ]
    if profile is None:
        steps.extend(
            [
                "uv run buildai auth profiles",
                "uv run buildai auth check --profile engineers-dev --env development",
                "uv run api",
            ]
        )
        return tuple(steps)

    if profile.name == "api-runtime-like" and profile.service_slug:
        steps.append(
            f"uv run buildai auth check --profile {profile.name} --service {profile.service_slug} --env {profile.environment}"
        )
        steps.append(f"uv run api --service {profile.service_slug}")
    elif profile.name == "engineers-dev":
        steps.append(
            f"uv run buildai auth check --profile {profile.name} --env {profile.environment}"
        )
        steps.append("uv run api")
    else:
        steps.append(
            f"uv run buildai auth check --profile {profile.name} --env {profile.environment}"
        )
    return tuple(steps)


def _engineers_dev_contract_is_modeled() -> tuple[bool, str]:
    """Report whether the engineer-facing dev service account exists in repo truth."""

    iam_path = REPO_ROOT / "infra/production/iam/terragrunt.hcl"
    db_paths = (
        REPO_ROOT / "infra/production/database/terragrunt.hcl",
        REPO_ROOT / "infra/production/database-dev/terragrunt.hcl",
    )
    missing: list[str] = []

    if not iam_path.exists() or '"engineers-dev-sa"' not in iam_path.read_text(encoding="utf-8"):
        missing.append(str(iam_path))
    for db_path in db_paths:
        if not db_path.exists() or "engineers-dev-sa@" not in db_path.read_text(encoding="utf-8"):
            missing.append(str(db_path))

    if missing:
        return (
            False,
            "engineers-dev-sa is not fully modeled in repo truth yet: " + ", ".join(missing),
        )
    return True, "engineers-dev-sa is modeled in IAM plus prod/dev DB repo truth."


def build_auth_report(
    *,
    profile_name: str | None = None,
    service: str | None = None,
    environment: str = DEFAULT_ENVIRONMENT,
) -> AuthReport:
    """Run the deterministic auth checks for the requested local workflow."""

    state = inspect_local_auth_state()
    resolved_profile = None
    checks: list[AuthCheckResult] = []

    def add_check(
        code: str,
        *,
        ok: bool,
        level: str,
        summary: str,
        fix: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Append one check result in the order it should be shown to humans."""

        checks.append(
            AuthCheckResult(
                code=code,
                ok=ok,
                level=level,
                summary=summary,
                fix=fix,
                details=details or {},
            )
        )

    add_check(
        "gcloud-installed",
        ok=state.gcloud_available,
        level="error",
        summary="gcloud CLI is available." if state.gcloud_available else "gcloud CLI is missing.",
        fix="Install google-cloud-sdk before using local Build AI auth flows.",
    )
    add_check(
        "gcloud-account",
        ok=bool(state.gcloud_account),
        level="error",
        summary=(
            f"gcloud account is {state.gcloud_account}."
            if state.gcloud_account
            else "No active gcloud account is configured."
        ),
        fix="Run `gcloud auth login` with your build.ai account.",
    )
    add_check(
        "gcloud-project",
        ok=state.gcloud_project == DEFAULT_GCP_PROJECT,
        level="error",
        summary=(
            f"gcloud project is {state.gcloud_project or '(unset)'}."
            if state.gcloud_project
            else "No active gcloud project is configured."
        ),
        fix=f"Run `gcloud config set project {DEFAULT_GCP_PROJECT}`.",
        details={"expected_project": DEFAULT_GCP_PROJECT},
    )
    add_check(
        "gcloud-ambient-impersonation",
        ok=state.gcloud_impersonate_service_account is None,
        level="warning",
        summary=(
            "No ambient gcloud service-account impersonation is configured."
            if state.gcloud_impersonate_service_account is None
            else (
                "gcloud has a default impersonation target set to "
                f"{state.gcloud_impersonate_service_account}."
            )
        ),
        fix="Run `gcloud config unset auth/impersonate_service_account` so Build AI profiles stay explicit.",
    )
    add_check(
        "adc-file",
        ok=state.adc_exists,
        level="error",
        summary=(
            f"ADC file exists at {state.adc_path}."
            if state.adc_exists
            else f"ADC file is missing at {state.adc_path}."
        ),
        fix="Run `gcloud auth application-default login`.",
    )
    add_check(
        "adc-token",
        ok=state.adc_access_token_ok,
        level="error",
        summary=(
            f"ADC access token mint works as {state.adc_email or state.adc_target_principal or state.adc_type or 'current credentials'}."
            if state.adc_access_token_ok
            else "ADC access token mint failed."
        ),
        fix=(
            "Re-run `gcloud auth application-default login` and confirm the selected account has Google Cloud access."
            if not state.adc_access_token_ok
            else None
        ),
        details={"error": state.adc_access_token_error} if state.adc_access_token_error else {},
    )

    if state.gcloud_account and state.adc_email:
        add_check(
            "adc-account-match",
            ok=state.gcloud_account == state.adc_email,
            level="warning",
            summary=(
                "gcloud account and ADC identity match."
                if state.gcloud_account == state.adc_email
                else (
                    f"gcloud account is {state.gcloud_account}, but ADC mints tokens as {state.adc_email}."
                )
            ),
            fix=(
                "Re-run `gcloud auth application-default login` if you want ADC to follow the current gcloud user."
            ),
        )

    add_check(
        "api-credential",
        ok=state.api_status == "ok",
        level="warning",
        summary=(
            f"Public API credential resolves to {state.api_subject}."
            if state.api_status == "ok"
            else "Public API credential is not currently usable."
        ),
        fix="Run `buildai auth login` if you need API-backed CLI commands."
        if state.api_status != "ok"
        else None,
        details={"error": state.api_error} if state.api_error else {},
    )

    if profile_name is not None:
        try:
            resolved_profile = resolve_sanctioned_profile(
                profile_name,
                service=service,
                environment=environment,
            )
            summary = resolved_profile.summary
            if resolved_profile.service_slug:
                summary = f"{summary} Service: {resolved_profile.service_slug}."
            add_check(
                "profile-resolution",
                ok=True,
                level="info",
                summary=summary,
                details={
                    "target_service_account": resolved_profile.target_service_account,
                    "target_db_user": resolved_profile.target_db_user,
                },
            )
        except Exception as exc:
            add_check(
                "profile-resolution",
                ok=False,
                level="error",
                summary=str(exc),
                fix="Pick one of the named profiles from `buildai auth profiles` and include any required --service flag.",
            )

    if resolved_profile and resolved_profile.target_service_account:
        result = _run_command(
            [
                "gcloud",
                "auth",
                "application-default",
                "print-access-token",
                f"--impersonate-service-account={resolved_profile.target_service_account}",
            ]
        )
        add_check(
            "sa-impersonation",
            ok=result.returncode == 0 and bool(result.stdout),
            level="error",
            summary=(
                f"ADC can impersonate {resolved_profile.target_service_account}."
                if result.returncode == 0 and result.stdout
                else f"ADC could not impersonate {resolved_profile.target_service_account}."
            ),
            fix=(
                "Grant `roles/iam.serviceAccountTokenCreator` on that service account to the right group-backed local-dev audience."
                if result.returncode != 0 or not result.stdout
                else None
            ),
            details={"stderr": result.stderr} if result.stderr else {},
        )

    if resolved_profile and resolved_profile.name == "engineers-dev":
        ok, summary = _engineers_dev_contract_is_modeled()
        add_check(
            "engineers-dev-repo-contract",
            ok=ok,
            level="error",
            summary=summary,
            fix=(
                "Model engineers-dev-sa in `infra/production/iam/terragrunt.hcl` and `infra/production/database-dev/terragrunt.hcl` before treating it as the default engineer path."
                if not ok
                else None
            ),
        )

    if resolved_profile and resolved_profile.db_access and environment == "development":
        ok, summary = _development_lane_is_codified()
        add_check(
            "development-lane-contract",
            ok=ok,
            level="error",
            summary=summary,
            fix=(
                "Codify development-lane IAM users in `infra/production/database-dev/terragrunt.hcl` before treating dev auth as reliable."
                if not ok
                else None
            ),
        )

    next_steps = bootstrap_commands(profile=resolved_profile)
    return AuthReport(
        state=state,
        profile=resolved_profile,
        checks=tuple(checks),
        next_steps=next_steps,
    )


def report_as_jsonable(report: AuthReport) -> dict[str, Any]:
    """Convert the report into plain data for JSON and test assertions."""

    profile = None
    if report.profile is not None:
        profile = {
            "name": report.profile.name,
            "audience": report.profile.audience,
            "summary": report.profile.summary,
            "purpose": report.profile.purpose,
            "environment": report.profile.environment,
            "service_slug": report.profile.service_slug,
            "target_service_account": report.profile.target_service_account,
            "target_db_user": report.profile.target_db_user,
            "break_glass": report.profile.break_glass,
            "db_access": report.profile.db_access,
            "bootstrap_exports": report.profile.bootstrap_exports(),
        }
    return {
        "state": {
            "gcloud_available": report.state.gcloud_available,
            "gcloud_account": report.state.gcloud_account,
            "gcloud_project": report.state.gcloud_project,
            "gcloud_impersonate_service_account": report.state.gcloud_impersonate_service_account,
            "adc_path": report.state.adc_path,
            "adc_exists": report.state.adc_exists,
            "adc_type": report.state.adc_type,
            "adc_target_principal": report.state.adc_target_principal,
            "adc_email": report.state.adc_email,
            "adc_access_token_ok": report.state.adc_access_token_ok,
            "adc_access_token_error": report.state.adc_access_token_error,
            "api_status": report.state.api_status,
            "api_subject": report.state.api_subject,
            "api_display_name": report.state.api_display_name,
            "api_error": report.state.api_error,
        },
        "profile": profile,
        "checks": [
            {
                "code": check.code,
                "level": check.level,
                "ok": check.ok,
                "summary": check.summary,
                "fix": check.fix,
                "details": check.details,
            }
            for check in report.checks
        ],
        "next_steps": list(report.next_steps),
        "exit_code": report.exit_code,
    }
