"""Modern Stata practices skill."""
