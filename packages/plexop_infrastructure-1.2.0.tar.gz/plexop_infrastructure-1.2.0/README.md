Package with Plexop Python infrastructure
Include 
	* Logger decorator
	* Config decorator
	* Requests decorator
	* Some boto3 stuff decorators

Install from http://static.plexop.com/packages/python/plexop-infrastructure-latest.tar.gz

in order to upgrade dependencies:
cd C:\Projects\python-lambda-infrastructure-layer
pip install --upgrade -r requirements.txt --target=C:\Projects\python-lambda-infrastructure-layer\env\Lib\site-packages

# Installation
* The layer can be used as pip-installable package and as a lambda layer.  
* Packages are located in `s3://static-plexop/packages/python/plexop-infrastructure`. Open a given version and copy it's URL.
    * It can be installed via e.g. `pip install http://static.plexop.com/packages/python/plexop-infrastructure-0.2.8.tar.gz`
    * Latest version is always here: http://static.plexop.com/packages/python/plexop-infrastructure-latest.tar.gz

# Deployment
Every commit on a feature branch triggers a QA pipeline that uploads the package to **TestPyPI**, updates **Lambda**, and syncs to **S3**.

## Deploying to Production

1. Checkout `master` branch
2. git pull
3. Follow semver:
git commit -m 'fix: commit msg' --allow-empty increments PATCH version e.g. 1.0.0 -> 1.0.1
git commit -m 'feat: commit msg' --allow-empty  e.g increments MINOR versiong e.g 1.1.1 -> 1.2.0
git commit -m 'feat!: testing' --allow-empty - increments MAJOR versiong e.g 1.1.1 -> 2.0.0
4. git push

This triggers the **python-lambda-infra-layer-create-tag** pipeline, which generates a new Git tag.

After the tag is created, the **python-lambda-infra-layer-deploy** pipeline runs.  
The final two stages — **Publish to PyPI** and **Deploy to Prod environment** — both require manual approval.

This approval step is useful for verifying that the PyPI publication completed successfully before proceeding with the production deployment.
