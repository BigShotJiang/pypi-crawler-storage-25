import json
import time
from pathlib import Path
import re
from urllib.parse import urlparse, urlunparse

STATE_FILE = Path.home() / ".sprawdzai"

DEFAULT_STATE = {
    "current_backend": "remote",
    "tokens": {}
}

def load_state():
    if not STATE_FILE.exists():
        return DEFAULT_STATE.copy()
    with open(STATE_FILE, "r") as f:
        return json.load(f)

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=4)

def get_current_backend():
    return load_state()["current_backend"]

def set_current_backend(backend: str):
    state = load_state()
    state["current_backend"] = backend
    save_state(state)

def get_token(backend):
    state = load_state()
    return state["tokens"].get(backend)

def set_token(backend, token, expires_in):
    state = load_state()
    state["tokens"][backend] = {
        "token": token,
        "refresh_at": int(time.time() + expires_in // 2),
    }
    save_state(state)

def clear_token(backend):
    state = load_state()
    if backend in state["tokens"]:
        del state["tokens"][backend]
        save_state(state)

def clear_all_tokens():
    state = load_state()
    state["tokens"] = {}
    save_state(state)
    
def normalize_url(url: str) -> str:
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    path = parsed.path.rstrip("/")
    if (scheme == "http" and netloc.endswith(":80")) or (scheme == "https" and netloc.endswith(":443")):
        netloc = netloc.rsplit(":", 1)[0]
    normalized = urlunparse((scheme, netloc, path, "", "", ""))
    return normalized

def get_backend_url(name: str) -> str:
    name = name.lower()

    if name in ["l", "local"] or re.fullmatch(r"l\d+", name):
        return "http://localhost:8080"
    if name in ["r", "remote"] or re.fullmatch(r"r\d+", name):
        return "https://sprawdzai.org"

    if name.startswith("http://") or name.startswith("https://"):
        return normalize_url(name)

    raise ValueError(f"Unknown backend type: {name}")

def get_frontend_url(name: str) -> str:
    name = name.lower()

    if name in ["l", "local"] or re.fullmatch(r"l\d+", name):
        return "https://localhost"
    if name in ["r", "remote"] or re.fullmatch(r"r\d+", name):
        return "https://sprawdzai.org"

    if name.startswith("http://") or name.startswith("https://"):
        return normalize_url(name)

    raise ValueError(f"Unknown backend type: {name}")

def resolve_backend(name: str | None) -> str:
    return get_current_backend() if name is None else name
