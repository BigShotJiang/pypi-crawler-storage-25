import typer
from ..state import resolve_backend, get_token
from typing import Optional
from ..utils.error_handler import write_error

def get_auth_token(backend: Optional[str]):
    token = get_token(resolve_backend(backend))
    if token is None:
        raise Exception('You are not authenticated')
    return token['token']

def auth_token(
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Show authentication token.
    """
    token = get_token(resolve_backend(backend))
    if token is None:
        write_error('You are not authenticated')
    typer.echo(token['token'])
