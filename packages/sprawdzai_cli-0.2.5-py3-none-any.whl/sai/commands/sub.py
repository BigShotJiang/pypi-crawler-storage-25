import typer
from ..state import resolve_backend, get_frontend_url
from typing import Optional
from ..utils.error_handler import handle_response_error, write_error
from ..utils.client import APIClient
from .sync import read_dotsai, read_metadata
from pathlib import Path
import os
import webbrowser

def norm_filename(n: str):
    return (n[1:] if n[0] == '_' else n).lower()

def supath(current_path: Path, path: str, safe: bool):
    spt = path.split('/')
    for idx, el in enumerate(spt):
        if el == '.':
            continue
        if el == '..':
            current_path = current_path.parent
            continue
        try:
            filenames = os.listdir(current_path)
        except NotADirectoryError:
            write_error(f'{current_path} is not a directory')
            continue
        if el in filenames:
            current_path = current_path / el
            continue
        if idx == len(spt) - 1:
            filenames = [n for n in filenames if (current_path / n).is_file()]
        else:
            filenames = [n for n in filenames if (current_path / n).is_dir()]
        filenames = [n for n in filenames if norm_filename(n).startswith(el)]
        if len(filenames) == 0:
            write_error(f'Could not find a {"file" if len(spt) - 1 else "folder"} that starts with {el} inside folder {current_path}')
        if len(filenames) > 1 and safe:
            write_error(f'Found more than one option to complete {el} inside folder {current_path}, for example {filenames[0]} and {filenames[1]}')
        min_idx = 0
        for i in range(1, len(filenames)):
            if norm_filename(filenames[i]) < norm_filename(filenames[min_idx]):
                min_idx = i
        current_path = current_path / filenames[min_idx]

    return current_path

def open_in_browser(link: str):
    webbrowser.open_new_tab(link)

def sub(
    paths: list[str] = typer.Argument(
        help="""
Paths to submission files, in the order as they appear in submission_files metadata or on the website.

You can type only the first few letters of the filename or any other part of path to the submission,
and it will automatically take the lexicographically first completion of the path.
When searching for such files, it ignores a single `_` character at the beginning of the filename if present.
It also converts all filenames to lowercase before searching.

For example, to submit `1-train/_submission.ipynb`, you may just type `sai sub 1/s`.

This is made in order to let you quickly send submissions inside training folder (so they get the same environment as on the platform)
or to hold the submissions in a separate directory.
"""
    ),
    valid: bool = typer.Option(
        False,
        "--valid",
        "-v",
        help="Send to validation dataset."
    ),
    test: bool = typer.Option(
        False,
        "--test",
        "-t",
        help="Send to test dataset."
    ),
    all: bool = typer.Option(
        False,
        "--all",
        "-a",
        help=(
            "Send to both validation and test datasets. "
            "It will send to validation and immediately resend to test. "
            "If --test flag is passed, it will send to test set and resend to validation. "
        ),
    ),
    safe: bool = typer.Option(
        False,
        "--safe",
        "-s",
        help="If there are many completions starting with the same prefix, throw an error instead of taking alphabetically first one."
    ),
    open_browser: bool = typer.Option(
        False,
        "--open",
        "-o",
        help="Open the submission in browser. Might not work on some platforms."
    ),
    task_path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Send a submit to the current task.

    If no flag specifing which dataset to send to is provided (--test, --valid, --all), 
    then it will default to validation set if its submission limit is not 0, and otherwise test set.
    """

    backend = resolve_backend(backend)
    client = APIClient(backend)
    fontend_url = get_frontend_url(backend)

    metadata = read_metadata(task_path)
    dotsai = read_dotsai(task_path)
    if 'id' not in dotsai.keys():
        write_error('.sai file is broken (does not contain task id)')
        return
    
    task_id = dotsai['id']
    task_slug_or_id = metadata.get('slug', task_id)
    
    if 'submission_files' not in metadata:
        write_error('Could not find "submission_files" in metadata.json. Please ensure the task is synced.')
    if 'valid' not in metadata:
        write_error('Could not find "valid" in metadata.json. Please ensure the task is synced.')
    if 'test' not in metadata:
        write_error('Could not find "test" in metadata.json. Please ensure the task is synced.')
    if 'daily_submissions' not in metadata['valid']:
        write_error('Could not find "valid.daily_submissions" in metadata.json. Please ensure the task is synced.')
    if 'daily_submissions' not in metadata['test']:
        write_error('Could not find "test.daily_submissions" in metadata.json. Please ensure the task is synced.')

    is_valid = True
    if valid and test:
        write_error('You cannot pass both --valid and --test flag at once. Please use --all to automatically resend the submission.')
    if all:
        if test:
            is_valid = False
    else:
        if test:
            is_valid = False
        elif not valid:
            if metadata['valid']['daily_submissions'] == 0:
                is_valid = False

    sub_names = [f['name'] for f in metadata['submission_files']]
    if len(sub_names) != len(paths):
        write_error(f'The should be {len(sub_names)} file{"s" if len(sub_names) > 1 else ""} submitted for this task, but there {"were" if len(paths) > 1 else "was"} {len(paths)} file path{"s" if len(paths) > 1 else ""} provided.')

    typer.echo(f'Sending to ', nl=False)
    typer.secho(f'{fontend_url}/zadanie/{task_slug_or_id}', nl=False, fg='green')
    typer.echo(' as ', nl=False)
    typer.secho('valid' if is_valid else 'test', fg='blue', nl=False)
    typer.echo(':')
    files = []
    for name, path in zip(sub_names, paths):
        path = supath(task_path, path, safe)
        typer.echo(' - ', nl=False)
        typer.secho(f'{name}', nl=False, fg='green')
        typer.echo(f': {path.parent}/', nl=False)
        typer.secho(f'{path.name}', fg='blue')
        files.append(("files", (name, open(path, "rb"))))
    
    resp = client.post('/submissions', files=files, data={'task_id': task_id, 'type_': 'nonfinal' if is_valid else 'final'})

    if resp.status_code not in [200, 201]:
        handle_response_error(resp)
    
    subid = resp.json()['submission_id']
    link = f'{fontend_url}/zadanie/{task_slug_or_id}/zgloszenia/{subid}'
    typer.echo('\nSubmission sent to ', nl=False)
    typer.secho(link, fg='green')
    if open_browser:
        open_in_browser(link)
    
    if all:
        resp_test = client.post(f'/submissions/{subid}/resend')

        if resp_test.status_code not in [200, 201]:
            handle_response_error(resp_test)
        
        subid_test = resp_test.json()['submission_id']
        link_test = f'{fontend_url}/zadanie/{task_slug_or_id}/zgloszenia/{subid_test}'
        typer.echo('Resent to ', nl=False)
        typer.secho(link_test, fg='green')
    
        if open_browser:
            webbrowser.open_new_tab(link_test)
