import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets, Dataset
from ...utils.error_handler import write_error, handle_response_error

def link(
    name_or_id: str = typer.Argument(
        ...,
        help=(
            "Name or id of dataset to be linked"
        )
    ),
    valid: bool = typer.Option(
        False,
        "--valid",
        "-v",
    ),
    test: bool = typer.Option(
        False,
        "--test",
        "-t",
    ),
    nb: bool = typer.Option(
        False,
        "--notebook",
        "-n",
    ),
    chk: bool = typer.Option(
        False,
        "--checker",
        "-c",
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Link a dataset to a stage of a task.

    sai ds link name/id -> link dataset to all 4 stages
    sai ds link name/id --notebook/--checker/--valid/--test or -n/-c/-v/-t -> link dataset to 2 corresponding stages

    When passing two flags it will link dataset to this one stage, e.g.:
    sai ds link name/id --notebook --test -> link dataset to test notebook stage
    """

    dss = Datasets(path, backend)

    ds = dss.find(name_or_id, raise_not_found=False)

    if ds is None:
        files = []
        for type_ in ['dataset', 'image', 'other']:
            resp = dss.client.get(f'/files?type_={type_}')
            if resp.status_code != 200:
                handle_response_error(resp)
            files += resp.json()
        
        for f in files:
            if f['id'] == name_or_id:
                f['type_'] = 'none'
                ds = Dataset(f, path)
                typer.secho(f'Linking a new external dataset: {str(ds)}', fg='blue')
                if ds.name in dss.dss:
                    write_error(f'A dataset with name "{ds.name}" is already linked to this task. Sai does not support two datasets having the same name. Please rename the currently linked dataset with `sai ds rename {ds.name} new-name` or change the name of external dataset manually on the website.')
                dss.dss[ds.name] = ds

    if ds is None:
        write_error('Could not find dataset with specified name or id.')

    def linkk(s1: str, s2: str):
        if ds.stages[s1][s2]:
            typer.secho(f'Already linked to {s2} {"notebook" if s1 == "nb" else "checker"}.', fg='yellow')
        else:
            typer.secho(f'Linked to {s2} {"notebook" if s1 == "nb" else "checker"}!', fg='green')
            ds.stages[s1][s2] = True
    
    if nb and chk:
        write_error('Expected one or none of flags --notebook and --checker, but got both.')
    if valid and test:
        write_error('Expected one or none of flags --valid and --test, but got both.')
    
    flags = []
    if nb:
        flags.append('nb')
    if chk:
        flags.append('chk')
    if valid:
        flags.append('valid')
    if test:
        flags.append('test')
    
    if len(flags) == 0:
        linkk('nb', 'valid')
        linkk('nb', 'test')
        linkk('chk', 'valid')
        linkk('chk', 'test')
    elif len(flags) == 1:
        if flags[0] in ['nb', 'chk']:
            linkk(flags[0], 'valid')
            linkk(flags[0], 'test')
        else:
            linkk('nb', flags[0])
            linkk('chk', flags[0])
    else:
        if nb and valid:
            linkk('nb', 'valid')
        elif nb and test:
            linkk('nb', 'test')
        elif chk and valid:
            linkk('chk', 'valid')
        elif chk and test:
            linkk('chk', 'test')
    
    dss.update(dss.dss.values())

    Datasets(path, backend).show_warnings()
    