import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets, Dataset
from ...utils.error_handler import write_error, warn, handle_response_error
import tempfile
import zipfile

def create(
    name: str = typer.Argument(
        ...,
        help=(
            "Name of the dataset (name of the directory)"
        )
    ),
    valid: bool = typer.Option(
        False,
        "--valid",
        "-v",
    ),
    test: bool = typer.Option(
        False,
        "--test",
        "-t",
    ),
    nb: bool = typer.Option(
        False,
        "--notebook",
        "-n",
    ),
    chk: bool = typer.Option(
        False,
        "--checker",
        "-c",
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Create a new dataset with specified name.
    """

    dss = Datasets(path, backend)

    if name in dss.dss:
        write_error(f'A dataset with name ./{name} is already linked to this task. Please choose different name or rename the existing dataset with `sai ds rename {name} new-name`')

    dir_path = path / name

    if dir_path.exists():
        if dir_path.is_file():
            write_error(f'Specified name ./{name} is a file (expected it to not exist or be a directory).')
        warn(f'The specified dataset folder ./{name} already exists, but its contents will not be sent.')
        warn(f'Please run `sai ds send {name}` after this command to send its contents.')
    else:
        dir_path.mkdir()
    
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp_path = Path(tmp.name)
    try:
        with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as _:
            pass
        with open(tmp_path, "rb") as f:
            files_req = {"file": (f'{name}.zip', f)}
            data = {"type_": "dataset", "title": f"{dss.task['slug']} - {name}"}
            resp = dss.client.post('/files', data=data, files=files_req)
    finally:
        tmp.close()
        tmp_path.unlink()
    if resp.status_code not in [200, 201]:
        handle_response_error(resp)
    
    res = resp.json()
    res['type_'] = None
    ds = Dataset(res, path)
    dss.dss[ds.name] = ds
    typer.secho(f'Created new dataset {str(ds)}', fg='green')


    def linkk(s1: str, s2: str):
        typer.secho(f'Linked to {s2} {"notebook" if s1 == "nb" else "checker"}!', fg='green')
        ds.stages[s1][s2] = True
    
    if nb and chk:
        write_error('Expected one or none of flags --notebook and --checker, but got both.')
    if valid and test:
        write_error('Expected one or none of flags --valid and --test, but got both.')
    
    flags = []
    if nb:
        flags.append('nb')
    if chk:
        flags.append('chk')
    if valid:
        flags.append('valid')
    if test:
        flags.append('test')
    
    if len(flags) == 0:
        linkk('nb', 'valid')
        linkk('nb', 'test')
        linkk('chk', 'valid')
        linkk('chk', 'test')
    elif len(flags) == 1:
        if flags[0] in ['nb', 'chk']:
            linkk(flags[0], 'valid')
            linkk(flags[0], 'test')
        else:
            linkk('nb', flags[0])
            linkk('chk', flags[0])
    else:
        if nb and valid:
            linkk('nb', 'valid')
        elif nb and test:
            linkk('nb', 'test')
        elif chk and valid:
            linkk('chk', 'valid')
        elif chk and test:
            linkk('chk', 'test')
    
    dss.update(dss.dss.values())

    Datasets(path, backend).show_warnings()
