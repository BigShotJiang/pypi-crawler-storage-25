import typer
from typing import Optional
from pathlib import Path
from .pull import pull
from .send import send
from .create import create
from .link import link
from .unlink import unlink
from .rename import rename
from .utils import Datasets

ds_app = typer.Typer(
    no_args_is_help=False,
    help="Dataset management commands"
)

@ds_app.callback(invoke_without_command=True)
def ds(
    ctx: typer.Context, 
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    if ctx.invoked_subcommand is None:
        dss = Datasets(path, backend)

        for test in [False, True]:
            typer.secho(f'{"TEST" if test else "VALIDATION"} SUBMISSION DATASETS:', fg='blue')
            for chk in [False, True]:
                typer.secho(f'  {"Checker" if chk else "Notebook"}:', fg='blue')
                filtered = [ds for ds in dss.dss.values() if ds.stages['chk' if chk else 'nb']['test' if test else 'valid']]
                if len(filtered) == 0:
                    typer.secho('  *no datasets*', fg='black')
                else:
                    for ds in filtered:
                        typer.echo('   - ', nl=False)
                        if ds.local:
                            typer.secho(f'./{ds.name}', fg='green', nl=False)
                        else:
                            typer.secho(f'[MISSING] ./{ds.name}', fg='red', nl=False)
                        typer.echo(f' {ds.url}')
                typer.echo('')

        Datasets(path, backend).show_warnings()

ds_app.command()(pull)
ds_app.command()(send)
ds_app.command()(create)
ds_app.command()(link)
ds_app.command()(unlink)
ds_app.command()(rename)
