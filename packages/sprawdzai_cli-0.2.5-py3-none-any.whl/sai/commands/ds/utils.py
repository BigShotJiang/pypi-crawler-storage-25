from ...state import resolve_backend
from typing import Optional
from ...utils.error_handler import warn, handle_response_error, write_error
from ...utils.client import APIClient
from ..sync import read_dotsai
from pathlib import Path
import json

class Dataset:
    def __init__(self, ds, path: Path):
        self.id: str = ds['id']
        self.url: str = ds['direct_url']
        self.filename: str = ds['name']
        self.orig_name: str = ds['title']
        self.hash: str = ds['hash_md5']

        self.stages = {
            'nb': {'valid': False, 'test': False},
            'chk': {'valid': False, 'test': False}
        }
        self.apply_stage(ds['type_'])

        self.name = self.orig_name.split(" - ", 1)[1] if " - " in self.orig_name else self.orig_name
        self.path = path / self.name
        if self.path.is_file():
            write_error(f'Dataset ./{self.name} ({self.url}) exists locally, but is a file and not a folder! Please do something with the file, or rename the dataset manually on the website.')
        self.local = self.path.exists()
    
    def apply_stage(self, type_: str):
        if type_ == 'notebook_nonfinal':
            self.stages['nb']['valid'] = True
        if type_ == 'notebook_final':
            self.stages['nb']['test'] = True
        if type_ == 'checker_nonfinal':
            self.stages['chk']['valid'] = True
        if type_ == 'checker_final':
            self.stages['chk']['test'] = True
    
    def __str__(self):
        return f'{self.name} ({self.url})'

class Datasets:
    def __init__(self, path: Path, backend: Optional[str]):
        self.backend = resolve_backend(backend)
        self.client = APIClient(self.backend)
        self.path = path

        self.dotsai = read_dotsai(path)
        self.id = self.dotsai['id']
        
        task_resp = self.client.get(f'/tasks/{self.id}')
        if task_resp.status_code != 200:
            handle_response_error(task_resp)
        self.task = task_resp.json()

        self.dss: dict[str, Dataset] = {}
        for ds_dict in self.task['datasets']:
            ds = Dataset(ds_dict, path)
            if ds.name in self.dss:
                if ds.id == self.dss[ds.name].id:
                    self.dss[ds.name].apply_stage(ds_dict['type_'])
                else:
                    write_error(f'Datasets {ds.id} and {self.dss[ds.name].id} were assigned the same name by sai ({ds.name}). Sai does not support two datasets having the same name. Please edit the names manually on the website.')
            else:
                self.dss[ds.name] = ds

        self.missing = [ds for ds in self.dss.values() if not ds.local]
    
    def show_warnings(self):
        if len(self.missing) == 1:
            warn(f'Found a missing dataset {str(self.missing[0])} which is linked to this task, but is not pulled locally.')
            warn(f'Use `sai ds pull --missing` to pull this dataset.')
        elif len(self.missing) > 1:
            warn(f'Found {len(self.missing)} missing datasets which are linked to this task, but not pulled locally:')
            for ds in self.missing:
                warn(str(ds))
            warn(f'Use `sai ds pull --missing` to pull all these datasets, or `sai ds pull name/id` to pull one of them.')
    
    def find(self, name_or_id: str, raise_not_found=True):
        if name_or_id in self.dss:
            return self.dss[name_or_id]
        
        for ds in self.dss.values():
            if ds.id == name_or_id:
                return ds
        
        if raise_not_found:
            write_error('Could not find dataset with specified name or id.')
        return None

    def update(self, dss: list[Dataset]):
        task_resp = self.client.get(f'/tasks/{self.id}')
        if task_resp.status_code != 200:
            handle_response_error(task_resp)
        task = task_resp.json()

        new_dss = []
        for ds in dss:
            for s1, n1 in [('nb', 'notebook'), ('chk', 'checker')]:
                for s2, n2 in [('valid', 'nonfinal'), ('test', 'final')]:
                    if ds.stages[s1][s2]:
                        new_dss.append({
                            'file_id': ds.id,
                            'type': f'{n1}_{n2}'
                        })

        resp = self.client.put(f'/tasks/{self.id}', data={
            'title': task['title'],
            'short_description': task['short_description'],
            'slug': task['slug'],
            'tags_ids': [tag['id'] for tag in task['tags']],
            'difficulty': task['difficulty'],

            'notebook_config': json.dumps(task['notebook_config']),
            'checker_config': json.dumps(task['checker_config']),

            'compute': task['compute'],
            'submission_files': json.dumps(task['submission_files']),

            'nonfinal_submissions_per_day': task['nonfinal_submissions_per_day'],
            'nonfinal_notes_char_limit': task['nonfinal_notes_char_limit'],
            'nonfinal_stdout_char_limit': task['nonfinal_stdout_char_limit'],
            'nonfinal_stderr_char_limit': task['nonfinal_stderr_char_limit'],
            'final_submissions_per_day': task['final_submissions_per_day'],
            'final_notes_char_limit': task['final_notes_char_limit'],
            'final_stdout_char_limit': task['final_stdout_char_limit'],
            'final_stderr_char_limit': task['final_stderr_char_limit'],

            'display_ranking': task['display_ranking'],
            'score_mode': task['score_mode'],
            'baseline_score': task['baseline_score'],

            'datasets': json.dumps(new_dss)
        })
        if resp.status_code != 200:
            handle_response_error(resp)
