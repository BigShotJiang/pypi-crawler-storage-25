import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets, Dataset
from ...utils.error_handler import warn, handle_response_error
import shutil
import tempfile
from tqdm.auto import tqdm
import zipfile

def pull(
    name_or_id: Optional[str] = typer.Argument(
        None,
        help=(
            "Pull a dataset with specific name or id. "
            "If this argument is not specified, it will pull all missing datasets (ones that are linked to this task, but are not yet pulled locally)."
        )
    ),
    only_missing: bool = typer.Option(
        False,
        "--missing",
        "-m",
        help=(
            "Only pull missing datasets. "
            "If this flag is not set, datasets that are already pulled locally will be pulled again in order to allow you to "
            "update their contents in case they changed on backend "
            "(but you will get warning before that, so you don't accidentally lose local changes)."
        )
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Pull a dataset or all missing datasets linked to a task.
    """
    
    dss = Datasets(path, backend)

    tpull: list[Dataset] = []
    if name_or_id is None:
        if len(dss.dss) == 0:
            warn('There are no datasets linked to this task, so no dataset can be pulled.')
        else:
            for ds in dss.dss.values():
                if only_missing and ds.local:
                    continue
                tpull.append(ds)
            if len(tpull) == 0:
                warn('You have set the --missing flag, but all datasets are already pulled locally.')
                warn('If you think a dataset was changed on the remote and you want to redownload it, run `sai ds pull name/id` explicitly or remove the --missing flag.')
    else:
        ds = dss.find(name_or_id)
        if only_missing and ds.local:
            warn('You have set the --missing flag, but the dataset you picked is already pulled locally.')
        else:
            tpull.append(ds)
    
    if len(tpull) >= 2:
        typer.echo(f'Pulling {len(tpull)} datasets...')
    
    for ds in tpull:
        typer.echo(f'{" - " if len(tpull) >= 2 else ""}Pulling {str(ds)}...')

        dir_path = path / ds.name

        if ds.local:
            res = typer.prompt(f'You are about to pull the "{ds.name}" dataset from backend. It will overwrite all your local data inside {dir_path} folder. Do you want to pull this dataset? [y]es/[n]o')
            if type(res) != str or (res.lower() not in ['y', 'yes']):
                warn("Dataset was skipped")
                continue
            shutil.rmtree(dir_path)
        
        dir_path.mkdir(exist_ok=False)

        is_zip = ds.filename.endswith('.zip')
        if is_zip:
            tmp = tempfile.NamedTemporaryFile(delete=False)
            tmp_path = Path(tmp.name)
        else:
            tmp_path = dir_path / ds.filename
            tmp = tmp_path.open("w+b")

        url = f'/files/{ds.id}/download'
        with dss.client.get(url, stream=True) as resp:
            if resp.status_code != 200:
                if tmp_path.exists():
                    tmp.close()
                    tmp_path.unlink()
                typer.echo(f'Error while pulling {str(ds)} from {url}:')
                handle_response_error(resp)
            
            total_size = int(resp.headers.get("content-length", 0))
            
            with tqdm(total=total_size, unit='B', unit_scale=True) as pbar:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        tmp.write(chunk)
                        pbar.update(len(chunk))
        
        tmp.close()
        
        if is_zip:
            try:
                with zipfile.ZipFile(tmp_path, 'r') as zip_ref:
                    zip_ref.extractall(dir_path)
                    typer.secho(f"Unzipped contents to {dir_path.absolute()}", fg=typer.colors.GREEN)
            except zipfile.BadZipFile as e:
                typer.echo(tmp_path.absolute())
                typer.echo(e)
                shutil.move(str(tmp_path), dir_path / (ds.name + '.zip'))
                warn(f"Warning: downloaded {str(ds)} dataset is not a valid ZIP. It was placed in the folder instead of being unzipped.")
            finally:
                if tmp_path.exists():
                    tmp_path.unlink()
        else:
            typer.secho(f"Downloaded contents to {dir_path.absolute()}", fg=typer.colors.GREEN)
    
    Datasets(path, backend).show_warnings()
