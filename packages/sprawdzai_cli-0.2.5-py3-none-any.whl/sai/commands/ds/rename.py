import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets
from ...utils.error_handler import handle_response_error

def rename(
    name_or_id: str = typer.Argument(
        ...,
        help=(
            "Name or id of dataset to be renamed"
        )
    ),
    new_name: str = typer.Argument(
        ...,
        help=(
            "New name of the dataset"
        )
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Rename a dataset.
    """

    dss = Datasets(path, backend)
    ds = dss.find(name_or_id)

    data = {"type_": "dataset", "title": f"{dss.task['slug']} - {new_name}"}
    resp = dss.client.patch(f'/files/{ds.id}', data=data)

    if resp.status_code not in [200, 201]:
        handle_response_error(resp)
    
    if ds.local:
        ds.path.rename(ds.path.with_name(new_name))

    Datasets(path, backend).show_warnings()
