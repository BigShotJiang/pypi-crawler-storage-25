import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets, Dataset
import zipfile
from ...utils.error_handler import write_error, warn, handle_response_error
import tempfile
from tqdm.auto import tqdm

def format_mem(sz):
    sz = int(sz)
    if sz <= 10240:
        return f'{sz}B'
    sz = sz / 1024
    if sz <= 10240:
        return f'{sz:.2f}KB'
    sz = sz / 1024
    if sz <= 10240:
        return f'{sz:.2f}MB'
    sz = sz / 1024
    return f'{sz:.2f}GB'

def send(
    name_or_id: Optional[str] = typer.Argument(
        None,
        help=(
            "Send dataset with specific name or id. "
            "If this argument is not specified, it will send all datasets you have locally."
        )
    ),
    no_zip: bool = typer.Option(
        False,
        "--no-zip",
        "-n",
        help=(
            "If there is just one file in the dataset, with this flag you can make a dataset to be this one file "
            "instead of being a zip containing a single file. "
            "It will throw an error if there is not exactly one file in a dataset folder. "
        )
    ),
    detach: bool = typer.Option(
        False,
        "--detach",
        "-d",
        help=(
            "Instead of writing to the current dataset on backend, "
            "it will create a new dataset and write to it, leaving the current dataset unchanged on backend. "
            "Please do not use unless having a specific reason, "
            "because it can make mess in datasets and lose a lot of disk space since it will create a new dataset during each call with this flag."
        )
    ),
    zip_method: str = typer.Option(
        "deflated",
        "--zip-method",
        "-z",
        help="Compression method to use when sending datasets (`stored` - no compression, `deflated`, `bz2`, `lzma`)"
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Send a dataset or all datasets you have pulled locally.
    """

    dss = Datasets(path, backend)

    zip_method_dict = {
        'stored': zipfile.ZIP_STORED,
        'deflated': zipfile.ZIP_DEFLATED,
        'bz2': zipfile.ZIP_BZIP2,
        'lzma': zipfile.ZIP_LZMA
    }
    if zip_method not in zip_method_dict:
        write_error(f'Got unexpected zip compression method {zip_method}, expected one of: {", ".join(list(zip_method_dict.keys()))}')
    zip_method_int = zip_method_dict[zip_method]

    tsend: list[Dataset] = []
    if name_or_id is None:
        if len(dss.dss) == 0:
            warn('There are no datasets linked to this task, so no dataset can be sent.')
        else:
            for ds in dss.dss.values():
                if ds.local:
                    tsend.append(ds)
            if len(dss.dss) == 0:
                warn('You do not have any datasets pulled locally, so no dataset can be sent.')
    else:
        tsend = [dss.find(name_or_id)]
    
    if len(tsend) >= 2:
        typer.echo(f'Sending {len(tsend)} datasets...')
    
    for ds in tsend:
        typer.echo(f'{" - " if len(tsend) >= 2 else ""}Sending {str(ds)}...')

        dir_path = path / ds.name
        filename = f'{ds.name}.zip'
        files = list(dir_path.rglob("*"))
        
        if no_zip:
            if len(files) == 0:
                write_error(f'Error: --no-zip flag was passed, but {str(ds)} dataset has zero files (expected exactly one)')
            if len(files) > 1:
                write_error(f'Error: --no-zip flag was passed, but {str(ds)} dataset has more than one file (expected exactly one)')
            file = files[0]
            filename = file.name
            to_send = file
        else:
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
            to_send = Path(tmp.name)
            with zipfile.ZipFile(to_send, 'w', zip_method_int) as zipf:
                if len(files) == 0:
                    typer.echo('Dataset is empty.')
                else:
                    for file_path in tqdm(files, desc=f"Zipping"):
                        zipf.write(file_path, arcname=file_path.relative_to(dir_path))
            tmp.close()

        try:
            size = to_send.stat().st_size
            typer.echo(f'Uploading ({format_mem(size)})...')
            with open(to_send, "rb") as f:
                files_req = {"file": (filename, f)}

                if detach:
                    data = {"type_": "dataset", "title": ds.orig_name}
                    resp = dss.client.post('/files', data=data, files=files_req)
                else:
                    data = {"type_": "dataset", "title": ds.orig_name}
                    resp = dss.client.patch(f'/files/{ds.id}', data=data, files=files_req)
                
                if resp.status_code not in [200, 201]:
                    typer.echo(f'Error while sending {str(ds)}:')
                    handle_response_error(resp)
                
                res = resp.json()

                if detach:
                    ds.id = res['id']
                    typer.echo(f'Detached to id {ds.id}')
                    dss.update(dss.dss.values())
        finally:
            if to_send.exists() and not no_zip:
                to_send.unlink()

    Datasets(path, backend).show_warnings()
