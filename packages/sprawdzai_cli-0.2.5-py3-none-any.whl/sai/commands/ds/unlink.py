import typer
from typing import Optional
from pathlib import Path
from .utils import Datasets
from ...utils.error_handler import write_error

def unlink(
    name_or_id: str = typer.Argument(
        ...,
        help=(
            "Name or id of dataset to be unlinked"
        )
    ),
    valid: bool = typer.Option(
        False,
        "--valid",
        "-v",
    ),
    test: bool = typer.Option(
        False,
        "--test",
        "-t",
    ),
    nb: bool = typer.Option(
        False,
        "--notebook",
        "-n",
    ),
    chk: bool = typer.Option(
        False,
        "--checker",
        "-c",
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Unlink a dataset to from a task or a stage of this task.

    sai ds unlink name/id -> completely unlink the dataset from this task
    sai ds unlink name/id --notebook/--checker/--valid/--test or -n/-c/-v/-t -> unlink dataset from 2 corresponding stages

    When passing two flags it will unlink dataset from this one stage, e.g.:
    sai ds unlink name/id --notebook --test -> unlink dataset from test notebook stage
    """

    dss = Datasets(path, backend)

    ds = dss.find(name_or_id)

    def unlinkk(s1: str, s2: str):
        if not ds.stages[s1][s2]:
            typer.secho(f'Already unlinked from {s2} {"notebook" if s1 == "nb" else "checker"}.', fg='yellow')
        else:
            typer.secho(f'Unlinked from {s2} {"notebook" if s1 == "nb" else "checker"}!', fg='green')
            ds.stages[s1][s2] = False
    
    if nb and chk:
        write_error('Expected one or none of flags --notebook and --checker, but got both.')
    if valid and test:
        write_error('Expected one or none of flags --valid and --test, but got both.')
    
    flags = []
    if nb:
        flags.append('nb')
    if chk:
        flags.append('chk')
    if valid:
        flags.append('valid')
    if test:
        flags.append('test')
    
    if len(flags) == 0:
        unlinkk('nb', 'valid')
        unlinkk('nb', 'test')
        unlinkk('chk', 'valid')
        unlinkk('chk', 'test')
    elif len(flags) == 1:
        if flags[0] in ['nb', 'chk']:
            unlinkk(flags[0], 'valid')
            unlinkk(flags[0], 'test')
        else:
            unlinkk('nb', flags[0])
            unlinkk('chk', flags[0])
    else:
        if nb and valid:
            unlinkk('nb', 'valid')
        elif nb and test:
            unlinkk('nb', 'test')
        elif chk and valid:
            unlinkk('chk', 'valid')
        elif chk and test:
            unlinkk('chk', 'test')
    
    any_link = False
    for s1 in ['nb', 'chk']:
        for s2 in ['valid', 'test']:
            if ds.stages[s1][s2]:
                any_link = True
    
    if not any_link:
        typer.secho('Warning:', fg='red')
        typer.echo('This operation will leed the dataset to be completely unlinked from the task.')
        typer.echo('Sai does not track datasets that are not linked to any stage of the task. After running this operation, the dataset folder will be kept as is, but sai will treat it as any normal directory and not a dataset.')
        typer.echo(f'You will still be able to relink the dataset just like any normal external dataset with `sai link {ds.id}`')
        res = typer.prompt(f'Do you wish to continue? [y]es/[n]o')
        if type(res) != str or (res.lower() not in ['y', 'yes']):
            typer.secho("Operation aborted", fg='red')
            return
    
    dss.update(dss.dss.values())
    
    if not any_link:
        typer.secho(f'./{ds.name} folder is no longer tracked and considered as a dataset by sai. You can remove it if you want.', fg='green')

    Datasets(path, backend).show_warnings()
    