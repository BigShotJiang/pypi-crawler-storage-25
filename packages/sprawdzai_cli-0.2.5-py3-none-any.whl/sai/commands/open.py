# opens task in browser and shows path with id
