import typer
from ..state import resolve_backend, set_token
from ..utils.error_handler import handle_response_error
import requests
from typing import Optional
from ..utils.client import APIClient

def login(
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Login on the current backend.

    Note that backends like https://sprawdzai.org, remote, r, r1, r2 (which all point to the same address)
    will store separate authentication tokens.
    This lets you login on different accounts on r1, r2, ... or l1, l2, ... for convenience.

    Default backend is remote.
    """
    backend = resolve_backend(backend)
    client = APIClient(backend or None)

    username = typer.prompt("Username")
    password = typer.prompt("Password", hide_input=True)

    url = f"{client.base_url}/auth/login"
    resp = requests.post(url, json={"username": username, "password": password})

    if resp.status_code == 200:
        data = resp.json()
        set_token(backend, data["access_token"], data["expires_in"])
        typer.secho("Login successful.", fg=typer.colors.GREEN)
    else:
        handle_response_error(resp)
