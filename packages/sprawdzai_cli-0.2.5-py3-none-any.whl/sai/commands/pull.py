import typer
from ..state import resolve_backend
from typing import Optional
from ..utils.error_handler import handle_response_error, write_error
from ..utils.client import APIClient
from .sync import sync_task, write_dotsai
from pathlib import Path
from .ds.pull import pull as pull_datasets

def pull(
    task: str = typer.Argument(
        ...,
        help="id / slug / url"
    ),
    path: Optional[Path] = typer.Option(
        None,
        "--location",
        "-l",
        help="Path where the task should be pulled."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Pull a task from server.
    """

    backend = resolve_backend(backend)
    client = APIClient(backend)

    if '/' in task:
        spt = task.split('/')
        task_slug = None
        for i in range(len(spt) - 1):
            if spt[i] == 'zadanie':
                task_slug = spt[i + 1]
                break
        if task_slug is None:
            write_error('Could not decode task slug from the url')
        else:
            task = task_slug
    
    typer.echo(f'Pulling task {task} from {client.base_url}/tasks/{task}\n')

    task_resp = client.get(f'/tasks/{task}')
    if task_resp.status_code != 200:
        handle_response_error(task_resp)
    
    res = task_resp.json()

    if path == None:
        path = Path.cwd() / str(res['slug'])

    try:
        path.mkdir(exist_ok=False)
    except:
        write_error(f'Directory {path.absolute()} already exists.')
    
    write_dotsai(path, {'id': res['id']})
    sync_task(
        path, 
        client, 
        force_remote=True,
        simulate=False
    )
    pull_datasets(None, False, path, backend)

    typer.secho(f'Pulled task into {path.absolute()}', fg=typer.colors.GREEN)
