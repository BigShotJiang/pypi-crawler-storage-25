import os
import sys
import json
import time
import traceback
import subprocess

RESULTS_SECRET_KEY: str = "secret_key"

# This flag is set to True when it is a validation submit, and False when it is a test set submit
IS_VALID: bool = True

# How long did notebook execution take (in seconds)
# Use this for raising Time Limit Exceeded exceptions when the total time of running notebook and pickle is too large
NOTEBOOK_EXECUTION_TIME: float = 0.0

# This is the same time limit that you provide on sprawdzai.org when editing the task, just for convenience (in seconds)
NOTEBOOK_TIME_LIMIT: int = 60

# The same as NOTEBOOK_TIME_LIMIT, but the checker limit
CHECKER_TIME_LIMIT: int = 60

def check_file_exists(filepath: str) -> bool:
    if not os.path.exists(filepath):
        return False
    if not os.path.isfile(filepath):
        return False
    return True

def linear_grade(score: float, min_score: float, max_score: float, use_better: bool = False) -> int:
    if min_score > max_score:
        return linear_grade(max_score + min_score - score, max_score, min_score)
    if score <= min_score:
        return 0
    if score >= max_score:
        return 100
    if use_better:
        return int(round(99 * (score - min_score) / (max_score - min_score) + 0.5))
    return int(round(100 * (score - min_score) / (max_score - min_score)))

def safe_score(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)

        if isinstance(result, tuple):
            score, notes = result
            
            try:
                score = int(score)
            except Exception:
                raise Exception(f"Exception in safe_score() wrapper: {func.__name__} returned non-numeric value: {score}")

            return max(0, min(100, score)), notes
        else:
            try:
                score = int(result)
            except Exception:
                raise Exception(f"Exception in safe_score() wrapper: {func.__name__} returned non-numeric value: {result}")

            return max(0, min(100, score))

    return wrapper

def debug(*values, sep=' ', end='\n'):
    print(*values, sep=sep, end=end, file=sys.stderr, flush=True)

def format_time(t: float) -> str:
    t = round(t)
    if t < 0:
        return f'-{format_time(-t)}'
    if t < 3600:
        return f'{t // 60}:{t % 60:02d}'
    return f'{t // 3600}:{(t // 60) % 60:02d}:{t % 60:02d}'

def print_tree(startpath=".", prefix=""):
    entries = sorted(os.listdir(startpath))
    entries_count = len(entries)

    for index, entry in enumerate(entries):
        path = os.path.join(startpath, entry)
        connector = "└─" if index == entries_count - 1 else "├─"
        print(prefix + connector + entry)
        if os.path.isdir(path):
            extension = "    " if index == entries_count - 1 else "│ "
            print_tree(path, prefix + extension)

def run_pickle(timeout: float) -> float:
    print('Executing pickle in isolated subprocess...')
    
    start_time = time.time()

    try:
        proc = subprocess.run(
            ['python', 'subprocess_script.py'],
            timeout=timeout,
            capture_output=True,
            text=True
        )
    except subprocess.TimeoutExpired:
        raise TimeError()
    
    execution_time = time.time() - start_time

    print('pickle subprocess return code:')
    print(proc.returncode)
    print('pickle subprocess stdout:')
    print(proc.stdout)
    print('pickle subprocess stderr:')
    print(proc.stderr)

    if check_file_exists('error.txt'):
        try:
            with open('error.txt', 'r', encoding='UTF-8') as f:
                res = f.read()
        except Exception:
            traceback.print_exc()
            raise SubmissionError()
        raise SubmissionError(res)

    return execution_time

# These are the contents of those functions on SprawdzAI:
def write_result_base(score: float = 0, error: str | None = None, notes: str = ""):
    with open('result.txt', 'w', encoding='UTF-8') as f:
        json.dump({
            'notes': notes,
            'error': error,
            'score': score,
            'secret_key': RESULTS_SECRET_KEY
        }, f)
def write_ok(score: float, notes: str = ""):
    write_result_base(score, None, notes)
def write_time_error(notes: str = ""):
    write_result_base(0, "time_error", notes)
def write_memory_error(notes: str = ""):
    write_result_base(0, "memory_error", notes)
def write_submission_error(notes: str = ""):
    write_result_base(0, "runtime_error", notes)
def write_system_error(notes: str = ""):
    write_result_base(0, "system_error", notes)

class SubmissionError(Exception):
    pass

class TimeError(Exception):
    pass
