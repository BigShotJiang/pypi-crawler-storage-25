import typer
from ..state import resolve_backend
from typing import Optional
from ..utils.error_handler import handle_response_error
from ..utils.client import APIClient

def me(
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    ),
    all: bool = typer.Option(
        False, 
        "--all", 
        help="Show all information"
    )
):
    """
    Show account information.

    Use --all to show all available information.
    """

    backend = resolve_backend(backend)
    client = APIClient(backend)

    resp = client.get("/auth/me")

    if resp.status_code == 200:
        res = resp.json()
        if all:
            typer.echo('\n'.join(f'{k}: {v}' for k, v in res.items()))
        else:
            typer.echo(f'Username: {res["username"]} (id={res["id"]})')
            typer.echo(f'Discord username: {res["discord_username"]} (id={res["discord_id"]})')
            typer.echo(f'Admin: {"yes" if res["is_admin"] else "no"}')
            typer.echo(f'Verified: {"yes" if res["verified"] else "no"}')
            typer.echo(f'Can add datasets: {"yes" if res["can_add_datasets"] else "no"}')
            typer.echo(f'Can see admin panel: {"yes" if res["can_see_admin_panel"] else "no"}')
    else:
        handle_response_error(resp)
