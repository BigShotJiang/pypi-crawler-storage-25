import typer
from ..state import set_current_backend, get_current_backend, get_backend_url
from typing import Optional

def backend(
    backend: Optional[str] = typer.Argument(
        None, 
        help=(
            "Set backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Show current globally used backend, or set a new backend if provided.
    """
    if backend is not None:
        set_current_backend(backend)
    backend = get_current_backend()
    typer.echo(f"Using backend {backend} ({get_backend_url(backend)})")
