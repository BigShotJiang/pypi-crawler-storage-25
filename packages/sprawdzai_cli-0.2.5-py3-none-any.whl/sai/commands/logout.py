import typer
from ..state import resolve_backend, clear_token, clear_all_tokens
from typing import Optional

def logout(
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    ),
    all: bool = typer.Option(
        False,
        "--all",
        help="Logout from all backends (clears all stored tokens)"
    )
):
    """
    Logout from the current backend or all backends.

    Use --all to logout from all backends.
    """

    backend = resolve_backend(backend)

    if all:
        clear_all_tokens()
        typer.echo("Logged out from all backends.")
        return

    clear_token(resolve_backend(backend))
    typer.echo(f"Logged out from backend {backend}.")
