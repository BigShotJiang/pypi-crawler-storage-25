import typer
from ..state import resolve_backend
from typing import Optional
from ..utils.error_handler import handle_response_error, warn, write_error
from ..utils.client import APIClient
from pathlib import Path
import json
import hashlib
import aiofiles
import asyncio
from tqdm import tqdm
import os

def parse_time(t: str | int) -> int:
    if type(t) == int:
        return t
    if type(t) == str:
        try:
            spt = list(reversed(t.split(':')))
            mults = [ 1,  60,  60 * 60,  24 * 60 * 60 ]
            if len(spt) > len(mults):
                write_error(f"Got incorrect time limit value: {t}")
                return 0
            res = 0
            for i in range(len(spt)):
                res += mults[i] * int(spt[i])
            return res
        except typer.Exit:
            raise
        except:
            pass

    write_error(f"Got incorrect time limit value: {t}")
    return 0

def parse_memory(m: str | int) -> int:
    if type(m) == int:
        return m
    if type(m) == str and len(m) >= 2:
        try:
            if m[-1] == 'b':
                return round(float(m[:-1]))
            if m[-1] == 'k':
                return round(float(m[:-1]) * 1024)
            if m[-1] == 'm':
                return round(float(m[:-1]) * 1024 * 1024)
            if m[-1] == 'g':
                return round(float(m[:-1]) * 1024 * 1024 * 1024)
        except:
            pass

    write_error(f"Got incorrect memory limit value: {m}")
    return 0

def read_dotsai(path) -> dict:
    try:
        with open(path / '.sai', 'r', encoding='UTF-8') as f:
            txt = f.read()
            try:
                obj = json.loads(txt.split('\n')[-1])
                if 'id' not in obj.keys():
                    write_error('.sai file is broken (does not contain "id" field)')
                return obj
            except typer.Exit:
                raise
            except:
                write_error('.sai file is not in valid format')
    except typer.Exit:
        raise
    except Exception:
        write_error('Could not open .sai file (are you in a correct task folder?)')

def write_dotsai(path, obj):
    with open(path / '.sai', 'w', encoding='UTF-8') as f:
        res = json.dumps(obj, separators=(',', ':'), ensure_ascii=False)
        f.write(f'SprawdzAI CLI internal file. Do not edit manually.\n' + res)

def read_metadata(path) -> dict:
    try:
        with open(path / 'metadata.json', 'r', encoding='UTF-8') as f:
            txt = f.read()
            try:
                return json.loads(txt)
            except typer.Exit:
                raise
            except:
                write_error('metadata.json is not a json')
                return {}
    except typer.Exit:
        raise
    except:
        return {}

def read_field_file(path: Path, task_id: int) -> bytes:
    if not path.name.endswith(".ipynb"):
        with open(path, "rb") as f:
            return f.read()
    
    try:
        with open(path, "r", encoding="utf-8") as f:
            notebook = json.load(f)
        
        assert "metadata" in notebook, 'Notatnik nie zawiera pola "metadata"'

        if "kernelspec" in notebook["metadata"]:
            del notebook["metadata"]["kernelspec"]

        if "language_info" in notebook["metadata"]:
            notebook["metadata"]["language_info"]["version"] = "3.12.3"
        
        notebook["metadata"].setdefault("sprawdzai", {})
        notebook["metadata"]["sprawdzai"]["source"] = "SprawdzAI"
        notebook["metadata"]["sprawdzai"]["task_id"] = task_id

        modified = json.dumps(notebook, indent=1, ensure_ascii=False)
        return modified.encode("utf-8")

    except Exception as e:
        write_error(f"[Task {task_id}] Failed to process file {path}: {e}")

async def calc_md5(path: Path, task_id: int) -> str | None:
    if not path.exists():
        return None
    data = read_field_file(path, task_id)
    hash_md5 = hashlib.md5()
    hash_md5.update(data)
    return hash_md5.hexdigest()

def validate(n: str, v):
    # TODO: handle everything?

    if n == 'score_mode':
        return v in ["raw", "normalized", "place-based"], 'Expected one of: "raw", "normalized", "place-based"'

    if n.endswith('cpus'):
        if type(v) != int:
            return False, "Expected int"
        return 0 <= v, "Expected to be a non-negative int"

    if n.endswith('vram') or n.endswith('ram') or n.endswith('time'):
        return type(v) == int and 0 <= v, "Expected to be a non-negative integer"
    
    if n == 'difficulty':
        return v is None or (type(v) in [int, float] and 1.0 <= v and v <= 7.0), "Expected to be null or in range [1.0, 7.0]"

    if n == 'tags_ids':
        if type(v) != list:
            return False, "Expected to be a list of integers"
        for el in v:
            if type(el) != int:
                return False, "Expected all elements to be integers"

    return True, ""

def compare(v1, v2):
    if v1 is None and v2 is None:
        return True
    if v1 is None or v2 is None:
        return False

    if type(v1) in [int, float]:
        if type(v2) not in [int, float]:
            return False
        return v1 == v2
    
    if type(v1) in [str, bool]:
        if type(v1) != type(v2):
            return False
        return v1 == v2

    if type(v1) == list:
        if type(v2) != list:
            return False
        if len(v1) != len(v2):
            return False
        for i in range(len(v1)):
            if type(v1[i]) != type(v2[i]) or type(v1[i]) != type(v1[0]):
                return False
            if v1[i] != v2[i]:
                return False
        return True
    
    raise Exception(f'wtf: {v1}, {v2}')

def find_filename(path: Path, filename: str):
    res = filename
    fnd = False
    for nm in os.listdir(path):
        if nm.startswith(filename):
            if fnd:
                write_error(f"Error: Found two files for field '{filename}'")
            fnd = True
            res = nm
    return res

# Prepare backend metadata for same format
def prepare_backend_metadata(task):
    return {
        'title': task['title'],
        'short_description': task['short_description'],
        'slug': task['slug'],
        'tags_ids': [tag['id'] for tag in task['tags']],
        'difficulty': task['difficulty'],

        'notebook_time': task['notebook_config']['time_limit'],
        'notebook_ram': task['notebook_config']['ram_limit'],
        'notebook_vram': task['notebook_config']['vram_limit'],
        'notebook_cpus': int(task['notebook_config']['cpus'] * 100),
        'notebook_cpu_only': task['notebook_config']['cpu_only'],
        'notebook_allow_internet': task['notebook_config']['allow_internet'],

        'checker_time': task['checker_config']['time_limit'],
        'checker_ram': task['checker_config']['ram_limit'],
        'checker_vram': task['checker_config']['vram_limit'],
        'checker_cpus': int(task['checker_config']['cpus'] * 100),
        'checker_cpu_only': task['checker_config']['cpu_only'],
        'checker_allow_internet': task['checker_config']['allow_internet'],

        'compute': task['compute'],
        'submission_files': json.dumps(task['submission_files']),
        
        'valid_daily_submissions': task['nonfinal_submissions_per_day'],
        'valid_notes_char_limit': task['nonfinal_notes_char_limit'],
        'valid_stdout_char_limit': task['nonfinal_stdout_char_limit'],
        'valid_stderr_char_limit': task['nonfinal_stderr_char_limit'],

        'test_daily_submissions': task['final_submissions_per_day'],
        'test_notes_char_limit': task['final_notes_char_limit'],
        'test_stdout_char_limit': task['final_stdout_char_limit'],
        'test_stderr_char_limit': task['final_stderr_char_limit'],

        'display_ranking': task['display_ranking'],
        'score_mode': task['score_mode'],
        'baseline_score': task['baseline_score'],

        'statement': task['statement']['name'] + '$' + task['statement']['hash_md5'],
        'baseline': task['baseline']['name'] + '$' + task['baseline']['hash_md5'],
        'checker': task['checker']['name'] + '$' + task['checker']['hash_md5'],
        'subprocess': task['subprocess']['name'] + '$' + task['subprocess']['hash_md5'],
        'initiator': task['initiator']['name'] + '$' + task['initiator']['hash_md5'],
        'requirement': task['requirement']['name'] + '$' + task['requirement']['hash_md5'],
        'image': 'none' if task['image'] is None else task['image']['name'] + '$' + task['image']['hash_md5'],
    }

# Prepare local metadata.json for same format
def prepare_local_metadata(metadata):
    res = {}

    if 'title' in metadata:
        res['title'] = metadata['title']
    if 'short_description' in metadata:
        res['short_description'] = metadata['short_description']
    if 'slug' in metadata:
        res['slug'] = metadata['slug']
    if 'tags_ids' in metadata:
        res['tags_ids'] = metadata['tags_ids']
    if 'difficulty' in metadata:
        res['difficulty'] = metadata['difficulty']
    
    for s, g in [('notebook_limits', 'notebook'), ('checker_limits', 'checker')]:
        if s in metadata:
            el = metadata[s]
            if 'time' in el:
                res[f'{g}_time'] = parse_time(el['time'])
            if 'ram' in el:
                res[f'{g}_ram'] = parse_memory(el['ram'])
            if 'vram' in el:
                res[f'{g}_vram'] = parse_memory(el['vram'])
            if 'cpus' in el:
                res[f'{g}_cpus'] = el['cpus']
            if 'cpu_only' in el:
                res[f'{g}_cpu_only'] = el['cpu_only']
            if 'allow_internet' in el:
                res[f'{g}_allow_internet'] = el['allow_internet']
    
    if 'compute' in metadata:
        res['compute'] = metadata['compute']
    
    if 'submission_files' in metadata:
        res['submission_files'] = json.dumps([{
            'name': f['name'], 
            'max_file_size': parse_memory(f['max_file_size'])
        } for f in metadata['submission_files']])

    for t in ['valid', 'test']:
        if t in metadata:
            el = metadata[t]
            if 'daily_submissions' in el:
                res[f'{t}_daily_submissions'] = el['daily_submissions']
            if 'notes_char_limit' in el:
                res[f'{t}_notes_char_limit'] = el['notes_char_limit']
            if 'stdout_char_limit' in el:
                res[f'{t}_stdout_char_limit'] = el['stdout_char_limit']
            if 'stderr_char_limit' in el:
                res[f'{t}_stderr_char_limit'] = el['stderr_char_limit']
    
    if 'display_ranking' in metadata:
        res['display_ranking'] = metadata['display_ranking']
    if 'score_mode' in metadata:
        res['score_mode'] = metadata['score_mode']
    if 'baseline_score' in metadata:
        res['baseline_score'] = metadata['baseline_score']
    
    return res

# Write final metadata back to metadata.json file
def write_metadata(path, obj):
    with open(path / 'metadata.json', 'w', encoding='UTF-8') as f:
        json.dump({
            'title': obj['title'],
            'short_description': obj['short_description'],
            'tags_ids': obj['tags_ids'],
            'slug': obj['slug'],
            'difficulty': obj['difficulty'],

            'notebook_limits': {
                'time': obj['notebook_time'],
                'ram': obj['notebook_ram'],
                'vram': obj['notebook_vram'],
                'cpus': obj['notebook_cpus'],
                'cpu_only': obj['notebook_cpu_only'],
                'allow_internet': obj['notebook_allow_internet'],
            },
            'checker_limits': {
                'time': obj['checker_time'],
                'ram': obj['checker_ram'],
                'vram': obj['checker_vram'],
                'cpus': obj['checker_cpus'],
                'cpu_only': obj['checker_cpu_only'],
                'allow_internet': obj['checker_allow_internet'],
            },
            'compute': obj['compute'],
            'submission_files': json.loads(obj['submission_files']),
            'valid': {
                'daily_submissions': obj['valid_daily_submissions'],
                'notes_char_limit': obj['valid_notes_char_limit'],
                'stdout_char_limit': obj['valid_stdout_char_limit'],
                'stderr_char_limit': obj['valid_stderr_char_limit'],
            },
            'test': {
                'daily_submissions': obj['test_daily_submissions'],
                'notes_char_limit': obj['test_notes_char_limit'],
                'stdout_char_limit': obj['test_stdout_char_limit'],
                'stderr_char_limit': obj['test_stderr_char_limit'],
            },

            'display_ranking': obj['display_ranking'],
            'score_mode': obj['score_mode'],
            'baseline_score': obj['baseline_score'],
        }, f, indent=4, ensure_ascii=False)

# Backend request
def get_backend_request(metadata, datasets):
    return {
        'title': metadata['title'],
        'short_description': metadata['short_description'],
        'slug': metadata['slug'],
        'tags_ids': metadata['tags_ids'],
        'difficulty': metadata['difficulty'],

        'notebook_config': json.dumps({
            'time_limit': metadata['notebook_time'],
            'ram_limit': metadata['notebook_ram'],
            'vram_limit': metadata['notebook_vram'],
            'cpus': metadata['notebook_cpus'] / 100,
            'cpu_only': metadata['notebook_cpu_only'],
            'allow_internet': metadata['notebook_allow_internet'],
        }),
        'checker_config': json.dumps({
            'time_limit': metadata['checker_time'],
            'ram_limit': metadata['checker_ram'],
            'vram_limit': metadata['checker_vram'],
            'cpus': metadata['checker_cpus'] / 100,
            'cpu_only': metadata['checker_cpu_only'],
            'allow_internet': metadata['checker_allow_internet'],
        }),

        'compute': metadata['compute'],
        'submission_files': metadata['submission_files'],
        
        'nonfinal_submissions_per_day': metadata['valid_daily_submissions'],
        'nonfinal_notes_char_limit': metadata['valid_notes_char_limit'],
        'nonfinal_stdout_char_limit': metadata['valid_stdout_char_limit'],
        'nonfinal_stderr_char_limit': metadata['valid_stderr_char_limit'],

        'final_submissions_per_day': metadata['test_daily_submissions'],
        'final_notes_char_limit': metadata['test_notes_char_limit'],
        'final_stdout_char_limit': metadata['test_stdout_char_limit'],
        'final_stderr_char_limit': metadata['test_stderr_char_limit'],

        'notes_char_limit': metadata['valid_notes_char_limit'],
        'stdout_char_limit': metadata['valid_stdout_char_limit'],
        'stderr_char_limit': metadata['valid_stderr_char_limit'],

        'display_ranking': metadata['display_ranking'],
        'score_mode': metadata['score_mode'],
        'baseline_score': metadata['baseline_score'],

        'datasets': json.dumps([{'type': d['type_'], 'file_id': d['id']} for d in datasets])
    }

def sync_task(path: Path, client: APIClient, force_remote: bool, simulate: bool):
    dotsai = read_dotsai(path)
    metadata = prepare_local_metadata(read_metadata(path))
    
    # Load task from backend
    task_resp = client.get(f'/tasks/{dotsai["id"]}')
    if task_resp.status_code != 200:
        handle_response_error(task_resp)
    
    orig_task = task_resp.json()

    if not orig_task['has_edit_permission']:
        write_error('You do not have permission to edit this task.')

    # checklib
    checklib_path = path / "checklib.py"
    with open(Path(__file__).resolve().parent / "checklib.py", 'r') as f:
        checklib = f.read()
    if checklib_path.exists():
        with open(checklib_path, 'r') as f:
            if f.read() != checklib:
                warn('The checklib.py file has been modified. This is just a reference file kept in task folder mostly for autocompletion support. Its contents will now be overwritten with the standard file provided by SprawdzAI creators.')
                res = typer.prompt(f'Do you wish to continue? [y]es/[n]o')
                if type(res) != str or (res.lower() not in ['y', 'yes']):
                    typer.secho("Operation aborted", fg='red')
                    return
    with open(checklib_path, 'w') as f:
        f.write(checklib)

    # Fill to same format as metadata
    task = prepare_backend_metadata(orig_task)
    new_metadata = prepare_backend_metadata(orig_task)
    
    # Load previous response
    prev_task = dotsai.get('response', task)

    # Update local metadata with file hashes
    target_file_map = {
        'statement': 'statement.ipynb',
        'checker': 'checker.py',
        'subprocess': 'subprocess_script.py',
        'initiator': 'initiator.py',
        'requirement': 'requirements.txt',
        'image': find_filename(path, 'image'),
        'baseline': find_filename(path, 'baseline'),
    }
    for field, filename in target_file_map.items():
        hash_md5 = asyncio.run(calc_md5(path / filename, dotsai["id"]))
        if hash_md5 is not None:
            metadata[field] = filename + '$' + hash_md5
    
    no_baseline = not (path / target_file_map['baseline']).exists()
    no_image = not (path / target_file_map['image']).exists()
    if no_baseline and 'statement' in metadata:
        hash_md5 = asyncio.run(calc_md5(path / 'statement.ipynb', dotsai["id"]))
        metadata['baseline'] = 'baseline.ipynb' + '$' + hash_md5
        target_file_map['baseline'] = 'baseline.ipynb'
    if no_image:
        metadata['image'] = 'none'

    # Validate local metadata
    for n in metadata.keys():
        if n not in new_metadata.keys():
            write_error(f'metadata.json has unexpected key {n}')
        is_valid, msg = validate(n, metadata[n])
        if not is_valid:
            write_error(f'Error in metadata.json field {n}: {msg}')

    # Resolve all changes
    sent_fileds = []
    pulled_fileds = []
    conflicted_fileds = []

    for n in new_metadata.keys():
        if n not in metadata.keys():
            pulled_fileds.append(n)
            continue

        if compare(metadata[n], task[n]):
            if not compare(task[n], prev_task[n]):
                warn(f"Field {n} has changed on backend, but it has also changed locally in the same way, so no changes are made for this field.")
            continue
        
        if force_remote:
            pulled_fileds.append(n)
            continue

        if compare(task[n], prev_task[n]):
            sent_fileds.append(n)
            new_metadata[n] = metadata[n]
            continue
        
        if compare(metadata[n], prev_task[n]):
            pulled_fileds.append(n)
        else:
            conflicted_fileds.append(n)
    
    # Show info about changes
    send_to_backend = False
    if len(sent_fileds) == 0 and len(pulled_fileds) == 0 and len(conflicted_fileds) == 0:
        typer.echo('No changes were made')
    if len(sent_fileds) != 0:
        send_to_backend = True
        typer.echo(f'Sending {len(sent_fileds)} fields local -> backend ({", ".join(sent_fileds)})')  
    if len(pulled_fileds) != 0:
        typer.echo(f'Pulling {len(pulled_fileds)} fields backend -> local ({", ".join(pulled_fileds)})')
    
    # Resolve conflicts
    save_metadata = {k: v for k, v in new_metadata.items()}
    dotsai_metadata = {k: v for k, v in new_metadata.items()}
    if len(conflicted_fileds) != 0:
        if len(conflicted_fileds) == 1:
            typer.secho(f'There is 1 conflicted filed (both local and backend changed):', fg=typer.colors.RED)
        else:
            typer.secho(f'There are {len(conflicted_fileds)} conflicted fileds (both local and backend changed):', fg=typer.colors.RED)
        if not simulate:
            typer.echo('[i]gnore: Ignore conflict for now - keep local changes but don\'t send them to backend')
            typer.echo('[p]ull: Pull changes backend -> local, will overwrite local changes')
            typer.echo('[s]end: Send changes local -> backend, will keep local changes and overwrite on backend')
        for n in conflicted_fileds:
            typer.echo(f' > Field ', nl=False)
            typer.secho(n, nl=False, fg='blue')
            typer.echo(':', nl=True)
            typer.echo(f' > Original value: {prev_task[n]}')
            typer.echo(f' > Modified value on backend: {task[n]}')
            typer.echo(f' > Locally modified value: {metadata[n]}')
            if simulate:
                typer.echo('')
                continue
            valid_choices = {"i": "ignore", "p": "pull", "s": "send"}
            while True:
                choice = input(" > [i]gnore, [p]ull, [s]end: ").strip().lower()
                if choice in valid_choices.keys() or choice in valid_choices.values():
                    if choice in valid_choices.keys():
                        choice = valid_choices[choice]
                    if choice == 'ignore':
                        save_metadata[n] = metadata[n]
                        dotsai_metadata[n] = prev_task[n]
                    if choice == 'send':
                        send_to_backend = True
                        new_metadata[n] = metadata[n]
                        dotsai_metadata[n] = metadata[n]
                        save_metadata[n] = metadata[n]
                        sent_fileds.append(n)
                    if choice == 'pull':
                        save_metadata[n] = task[n]
                        pulled_fileds.append(n)
                    break
                else:
                    typer.echo("Invalid choice.")
    
    if simulate:
        return

    # Send to backend
    if send_to_backend:
        files = {}
        for field in sent_fileds:
            if field in target_file_map.keys():
                if field == 'baseline' and no_baseline:
                    filepath = path / 'statement.ipynb'
                else:
                    filepath = path / target_file_map[field]
                if field == 'image' and no_image:
                    files[field] = (target_file_map[field], b'')
                else:
                    files[field] = (target_file_map[field], read_field_file(filepath, dotsai["id"]))
        resp = client.put(
            f'/tasks/{dotsai["id"]}',
            data=get_backend_request(new_metadata, orig_task['datasets']),
            files=files
        )
        if resp.status_code != 200:
            handle_response_error(resp)
        if len(files) > 0:
            typer.secho(f'Updated backend (sent {len(files)} files)!', fg=typer.colors.GREEN)
        else:
            typer.secho(f'Updated backend!', fg=typer.colors.GREEN)
    
    # Download files
    files_to_download = []

    for field in pulled_fileds:
        if field in target_file_map.keys():

            if field == 'baseline' and no_baseline:
                if orig_task['baseline']['hash_md5'] == orig_task['statement']['hash_md5']:
                    continue
                else:
                    spt = orig_task['baseline']['name'].split('.')
                    if len(spt) <= 1:
                        target_file_map['baseline'] = 'baseline'
                    else:
                        target_file_map['baseline'] = 'baseline.' + spt[-1]
            
            if field == 'image':
                if orig_task['image'] == None:
                    if not no_image:
                        (path / target_file_map['image']).unlink()
                    continue
                elif no_image:
                    spt = orig_task['image']['name'].split('.')
                    if len(spt) <= 1:
                        target_file_map['image'] = 'image'
                    else:
                        target_file_map['image'] = 'image.' + spt[-1]
            
            files_to_download.append(field)
    
    if len(files_to_download) > 0:
        for field in tqdm(files_to_download, desc='Downloading files'):
            with client.get(f'/files/{orig_task[field]["id"]}/download', stream=True) as resp:
                if resp.status_code != 200:
                    handle_response_error(resp)
                with (path / target_file_map[field]).open("wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
    
    # Final save
    write_metadata(path, save_metadata)
    write_dotsai(path, {
        'id': dotsai['id'], 
        'response': dotsai_metadata
    })

def sync(
    simulate: bool = typer.Option(
        False,
        "--simulate",
        "-s",
        help=(
            "With this flag, you are guaranteed no changes will be made on backend or locally. "
            "Use this to see all logs sai would normally produce, but without affecting anything. "
            "Useful for example for seeing what changes have been made."
        )
    ),
    force_local: bool = typer.Option(
        False,
        "--force-local",
        "--fl",
        help=(
            "This will untrack any changes on backend and will overwrite everything with local changes. "
            "In other words, it will make exact copy of local version on backend ignoring any changes "
            "that might have came from other sources (someone else editing task or you editing it on the website). "
        ),
    ),
    force_remote: bool = typer.Option(
        False,
        "--force-remote",
        "--fr",
        help=(
            "Similar to --force-local, but will overwrite any local changes with what is on backend. "
            "In other words, it will make exact copy of remote version locally."
        ),
    ),
    path: Path = typer.Option(
        Path.cwd(),
        "--location",
        "-l",
        help="Path where the task is located (defaults to current directory)."
    ),
    backend: Optional[str] = typer.Option(
        None,
        "--backend",
        "-b",
        help=(
            "Use a different backend: "
            "local (l, l1, l2, ...), "
            "remote (r, r1, r2, ...) "
            "or full URL (https://example.com)"
        )
    )
):
    """
    Sync a task with server.
    """

    if force_local:
        dotsai = read_dotsai(path)
        write_dotsai(path, {'id': dotsai['id']})

    backend = resolve_backend(backend)
    client = APIClient(backend)
    
    sync_task(path, client, force_remote, simulate)
