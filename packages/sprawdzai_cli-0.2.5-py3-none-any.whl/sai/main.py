import typer
from typing import Optional
from .commands.backend import backend
from .commands.login import login
from .commands.logout import logout
from .commands.auth_token import auth_token
from .commands.me import me
from .commands.pull import pull
from .commands.sync import sync
from .commands.sub import sub
from .commands.ds import ds_app

def version_callback(value: bool):
    if value:
        from importlib.metadata import version
        __version__ = version("sprawdzai-cli")
        print(__version__)
        raise typer.Exit()

app = typer.Typer(
    no_args_is_help=True, 
    help="""
        SprawdzAI CLI tool.
    """
)

@app.callback()
def main_callback(
    version_flag: Optional[bool] = typer.Option(
        None,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    )
):
    pass

app.command()(backend)
app.command()(login)
app.command()(logout)
app.command()(auth_token)
app.command()(me)
app.command()(pull)
app.command()(sync)
app.command()(sub)
app.add_typer(ds_app, name="ds")

def main():
    app()
