from importlib.metadata import version
import requests
target_version = requests.get('https://sprawdzai.org/sprawdzai-cli-version').text
__version__ = version("sprawdzai-cli")
if __version__ != target_version:
    raise Exception('There is a new version of sprawdzai-cli available! Please install with:\npip install --upgrade sprawdzai-cli')

from .state import set_current_backend, get_current_backend, resolve_backend
from .state import clear_token, clear_all_tokens
from .state import get_backend_url, get_frontend_url, normalize_url
from .commands.auth_token import get_auth_token
from .utils.client import APIClient
from .utils.default_client import default_client as client
