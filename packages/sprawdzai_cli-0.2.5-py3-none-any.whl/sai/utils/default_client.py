from ..state import get_current_backend
from .client import APIClient

class DefaultClient:
    def __init__(self):
        self.client = None

    def __getattribute__(self, name):
        client = object.__getattribute__(self, "client")
        
        if client is None:
            backend = get_current_backend()
            print(f'using backend {backend}')
            client = APIClient(backend)
            object.__setattr__(self, "client", client)
        
        return getattr(client, name)

default_client = DefaultClient()
