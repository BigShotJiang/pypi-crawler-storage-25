import typer
from requests import Response
import json

def get_response_error_text(resp: Response) -> str:
    error_map = {
        404: 'Not Found (404)',
        500: 'Internal Server Error (500)',
        502: 'Bad Gateway (502)'
    }
    detail_map = {
        'user_not_authenticated': 'You are not authenticated',
        'invalid_credentials': 'Invalid login and/or password',
        'task_not_found': 'Task not found - it doesn\'t exist or you don\'t have permissions to see it (are you logged in to correct account?)',
        'slug_not_valid': 'Slug can only contain lowercase Latin latters, digits or "-" character and must be non-empty',
        'slug_not_unique': 'There already exists another task with the same slug'
    }
    err_text_begin = error_map[resp.status_code] if resp.status_code in error_map.keys() else f'Error ({resp.status_code})'

    if len(resp.text) == 0:
        return f'{err_text_begin}: [Server did not return any response]'

    try:
        res = json.loads(resp.text)
    except:
        return f'{err_text_begin}: {resp.text}'

    resp_keys = list(res.keys())
    if len(resp_keys) == 1 and resp_keys[0] == "detail":
        detail = res["detail"]
        if type(detail) == str and detail in detail_map.keys():
            return f'{err_text_begin}: {detail_map[detail]}'
        return f'{err_text_begin}: {detail}'
    return f'{err_text_begin}:\n{json.dumps(res, indent=4)}'

def write_error(txt: str):
    typer.secho(txt, err=True, fg=typer.colors.RED)
    raise typer.Exit(code=1)

def warn(txt: str):
    typer.secho(txt, err=True, fg=typer.colors.YELLOW)

def handle_response_error(resp: Response):
    write_error(get_response_error_text(resp))
    