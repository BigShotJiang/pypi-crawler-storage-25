import time
from ..state import get_backend_url, get_token, set_token
import requests

class APIClient:
    def __init__(self, backend_name: str):
        self.backend_name = backend_name
        self.base_url = get_backend_url(backend_name) + '/api'

    def _auth_header(self):
        data = get_token(self.backend_name)
        if not data:
            return {}

        if data["refresh_at"] > time.time():
            self.refresh(data["token"])
            data = get_token(self.backend_name)

        return {"Authorization": f"Bearer {data['token']}"}

    def refresh(self, token: str):
        try:
            url = f"{self.base_url}/auth/refresh"
            hdr = {"Authorization": f"Bearer {token}"}
            resp = requests.post(url, headers=hdr)
            if resp.status_code == 200:
                data = resp.json()
                set_token(
                    self.backend_name,
                    data["access_token"],
                    data["expires_in"]
                )
        except Exception as e:
            pass

    def get(self, path, **kwargs):
        return requests.get(self.base_url + path, headers=self._auth_header(), **kwargs)

    def post(self, path, json=None, **kwargs):
        return requests.post(self.base_url + path, json=json, headers=self._auth_header(), **kwargs)

    def delete(self, path, json=None, **kwargs):
        return requests.delete(self.base_url + path, json=json, headers=self._auth_header(), **kwargs)

    def put(self, path, json=None, **kwargs):
        return requests.put(self.base_url + path, json=json, headers=self._auth_header(), **kwargs)

    def patch(self, path, json=None, **kwargs):
        return requests.patch(self.base_url + path, json=json, headers=self._auth_header(), **kwargs)
