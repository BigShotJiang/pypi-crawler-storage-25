
import click
import pandas as pd

from sklearn.preprocessing import MinMaxScaler

import torch
from torch.utils.data import DataLoader

from .. import dataframe_loader, dataframe_tensor, get_device, dataframe_dataset
from ..files import H5Reader
from ..factory import save, load
from ..factory.layers import Layer, LayerList, ConstraintInfo
from ..optimize import fit_vae
from ..models.vae.vae import VAE
from ..preprocessing import ExpMinMaxScaler, get_dataset_nonzero_mask
from ..datasets import DatasetMask
from ..losses import bce_with_logits, bce, mse
from ..pathway import extract_pathway_interactions, feature_map_intersect, FeatureGroups

model = click.Group(name="model", help="VAE Model commands.")

@model.command()
@click.argument("input_path", type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str))
@click.option("--group", "-g", default=None, help="HD5F group name")
@click.option("--latent", "-l", type=int, default=256, show_default=True, help="Latent dimension size.")
@click.option("--epochs", "-e", type=int, default=20, show_default=True, help="Training epochs.")
@click.option("--batch-size", "-b", type=int, default=256)
@click.option("--encode-layers", type=str, default="400,200")
@click.option("--decode-layers", type=str, default="200,400")
@click.option("--normalize", "-n", type=str, default="none")
@click.option("--final-activation", default="none", type=click.Choice(["none", "sigmoid", "relu"]))
@click.option("--learning-rate", "-r", type=float, default=0.0001)
@click.option("--out", "-o", type=str, default=None)
@click.option("--schedule", "-s", type=str, default=None, help="20:0,20:0.1,40:.3,40:.4")
@click.option("--loss", type=click.Choice(["mse", "bce", "bce-logit"]), default="bce-logit")
@click.option("--save-stats", is_flag=True)
@click.option("--zero-mask", default=None, type=float)
@click.option("--seed", default=42, type=int)
@click.option("--bfloat16", is_flag=True)
def train_vae(input_path: str,
              group: str,
              latent: int,
              epochs: int,
              batch_size: int,
              out: str, normalize:str,
              encode_layers:str, decode_layers:str,
              learning_rate: float,
              final_activation: str,
              loss: str,
              schedule:str,
              zero_mask: float,
              save_stats: bool,
              seed: int,
              bfloat16: bool
              ):
    """
    Train VAE model from a TSV file.
    """
    device = get_device()
    dtype = torch.float32
    if bfloat16:
        dtype = torch.bfloat16

    torch.manual_seed(seed)
    df = None
    if group is not None:
        dataset = H5Reader(input_path, group)
        #TODO add normalization here
        if zero_mask is not None:
            dataset_mask = get_dataset_nonzero_mask(dataset, zero_mask)
            mask = dataset_mask[0].cpu().numpy()
            #print(mask)
            features = dataset.columns[mask]
            dataset = DatasetMask(dataset, dataset_mask, device)
        else:
            dataset.to(device)
            features = dataset.columns
    
    else:
        df = pd.read_csv(input_path, sep="\t", index_col=0)

        if normalize == "expMinMax":
            norm = ExpMinMaxScaler()
            norm.fit(df)
            df = pd.DataFrame( norm.transform(df), index=df.index, columns=df.columns)
        elif normalize == "minMax":
            norm = MinMaxScaler()
            norm.fit(df)
            df = pd.DataFrame( norm.transform(df), index=df.index, columns=df.columns)
        features = df.columns
        dataset = dataframe_dataset(df, device=device, dtype=dtype)
    
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    

    layer_sizes = list( int(i) for i in encode_layers.split(",") )
    enc_layers_list = LayerList( layer_sizes )

    layer_sizes = list( int(i) for i in decode_layers.split(",") )
    dec_layers_list = LayerList( layer_sizes, end_activation=final_activation )

    beta_schedule = None
    if schedule is not None:
        beta_schedule = []
        for b in schedule.split(","):
            e, b = b.split(":")
            beta_schedule.append( (float(b), int(e)) )
    vae = VAE(features=features,
              latent_dim=latent,
              encoder_layers=enc_layers_list,
              decoder_layers=dec_layers_list,
              device=device, dtype=dtype)

    loss_func = bce_with_logits
    if loss == "mse":
        loss_func = mse
    elif loss == "bce":
        loss_func = bce

    fit_vae(vae, dataloader, epochs=epochs,
            beta_schedule=beta_schedule, lr=learning_rate, loss=loss_func)
    click.echo("Training complete.")

    if out is None:
        click.echo(f"No output path provided, using default naming.")
        out = f"vae_latent{latent}_epochs{epochs}.model"

    save(vae, out)
    click.echo(f"Model saved, to {out}")


@model.command()
@click.argument("input_path", type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str))
@click.argument("pathway_sif", type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str))
@click.option("--epochs", "-e", type=int, default=20, show_default=True, help="Training epochs.")
@click.option("--encode-layers", type=str, default="400,200")
@click.option("--decode-layers", type=str, default="200,400")
@click.option("--normalize", "-n", type=str, default="none")
@click.option("--learning-rate", "-r", type=float, default=0.0001)
@click.option("--out", "-o", type=str, default=None)
@click.option("--loss", type=click.Choice(["mse", "bce", "bce-logit"]), default="bce-logit")
@click.option("--save-stats", is_flag=True)
def train_netvae(input_path: str, pathway_sif:str, out:str,
                encode_layers:str, decode_layers:str,
                epochs: int, normalize: str,
                learning_rate: float,
                loss:str,
                save_stats:bool):
    """Train VAE model from a TSV file."""
    df = pd.read_csv(input_path, sep="\t", index_col=0)

    feature_map = extract_pathway_interactions(pathway_sif)

    feature_map, isect = feature_map_intersect(feature_map, df.columns)

    df = df[isect]
    if normalize == "expMinMax":
        norm = ExpMinMaxScaler()
        norm.fit(df)
        df = pd.DataFrame( norm.transform(df), index=df.index, columns=df.columns)

    batch_size=256
    dataloader = dataframe_loader(df, batch_size=batch_size)

    fmap = FeatureGroups(feature_map)
    group_count = len(fmap)
    feature_count = len(isect)

    click.echo(f"Feature count {feature_count} latent_size: {group_count}")

    gcounts = [5,2,1]

    enc_layers = [
        Layer(group_count*gcounts[0], op="masked_linear", constraint=ConstraintInfo("features-to-group", fmap, out_group_count=gcounts[0])),
        Layer(group_count*gcounts[1], op="masked_linear", constraint=ConstraintInfo("group-to-group", fmap, in_group_count=gcounts[0], out_group_count=gcounts[1])),
        Layer(group_count, op="masked_linear", constraint=ConstraintInfo("group-to-group", fmap, in_group_count=gcounts[1], out_group_count=gcounts[2]))
    ]

    dec_layers = [
        Layer(group_count*gcounts[1], op="masked_linear", constraint=ConstraintInfo("group-to-group", fmap, in_group_count=gcounts[2], out_group_count=gcounts[1])),
        Layer(group_count*gcounts[0], op="masked_linear", constraint=ConstraintInfo("group-to-group", fmap, in_group_count=gcounts[1], out_group_count=gcounts[0])),
        Layer(feature_count, op="masked_linear", constraint=ConstraintInfo("group-to-features", fmap, in_group_count=gcounts[0]), activation="none")
    ]

    loss_func = bce_with_logits
    if loss == "mse":
        loss_func = mse
    elif loss == "bce":
        loss_func = bce

    schedule = [(0.0, epochs)]
    vae = VAE(list(df.columns), latent_dim=group_count, encoder_layers=enc_layers, decoder_layers=dec_layers)
    fit_vae(vae, X=dataloader, beta_schedule=schedule, lr=learning_rate, loss=loss_func)

    click.echo("Training complete.")

    if out is None:
        click.echo("No output path provided, using default naming.")
        out = f"netvae_latent{group_count}_epochs{epochs}.model"

    save(vae, out)
    click.echo(f"Model saved, to {out}")

    if save_stats:
        stats = pd.DataFrame({"mean": df.mean(), "std": df.std(ddof=0)})
        stats_path = f"{out}.stats.tsv"
        stats.to_csv(stats_path, sep="\t")
        click.echo(f"Stats saved, to {stats_path}")

@model.command()
@click.argument("input_path", type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str))
@click.argument("model_path", type=click.Path(exists=True, dir_okay=True, readable=True, path_type=str))
@click.option("--normalize", "-n", type=str, default="none")
@click.option("--out", "-o", type=str, default="embedding.tsv")
def encode(input_path: str, model_path:str, normalize:str, out:str):

    m = load(model_path)
    df = pd.read_csv(input_path, sep="\t", index_col=0)

    df = df[m.features]
    if normalize == "expMinMax":
        norm = ExpMinMaxScaler()
        norm.fit(df)
        df = pd.DataFrame( norm.transform(df), index=df.index, columns=df.columns)

    df_tensor = dataframe_tensor(df).to(get_device())
    m.to(get_device())
    result = m.encoder(df_tensor)
    
    martix = result[2].detach().cpu().numpy()
    out_df = pd.DataFrame(martix, index=df.index)
    out_df.to_csv(out, sep="\t")
