"""Vendored Lyceum security primitives — ssrf_guard."""
from __future__ import annotations

__all__ = ["ssrf_guard"]
