"""Vendored Lyceum sandbox primitives — destruction_guard + destruction_patterns."""
from __future__ import annotations

__all__ = ["destruction_guard", "destruction_patterns"]
