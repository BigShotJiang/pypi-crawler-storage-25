"""
PrimeDefender FastAPI middleware: request inspection, blocking, and bridge reporting.
"""

from primedefender_fastapi.config import PrimeDefenderSettings, clear_settings_cache, load_settings
from primedefender_fastapi.detectors import Detection
from primedefender_fastapi.middleware import PrimeDefenderMiddleware

__version__ = "0.1.0"

__all__ = [
    "PrimeDefenderMiddleware",
    "PrimeDefenderSettings",
    "Detection",
    "load_settings",
    "clear_settings_cache",
    "__version__",
]
