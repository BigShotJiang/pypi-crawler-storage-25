from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Literal, Tuple
from urllib.parse import urlparse

Mode = Literal["observe", "block"]


def _env_str(key: str, default: str = "") -> str:
    raw = os.getenv(key)
    if raw is None:
        return default
    return raw.strip()


def _env_float(key: str, default: float) -> float:
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(key: str, default: int) -> int:
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_bool(key: str, default: bool = False) -> bool:
    raw = os.getenv(key)
    if raw is None or raw == "":
        return default
    return raw.lower() in ("1", "true", "yes", "on")


def _env_mode(key: str, default: Mode) -> Mode:
    raw = (os.getenv(key) or "").strip().lower()
    if raw in ("observe", "block"):
        return raw  # type: ignore[return-value]
    return default


@dataclass(frozen=True)
class PrimeDefenderSettings:
    """Configuration for middleware and bridge reporting. Usually built via ``from_env()``."""

    bridge_url: str
    api_key: str
    site_id: str
    site_lat: float
    site_lon: float
    site_region_label: str
    private_source_label: str
    body_cap_bytes: int
    geoip_ttl_seconds: int
    geoip_timeout_seconds: float
    bridge_timeout_seconds: float
    flood_window_seconds: int
    flood_max_requests: int
    brute_force_window_seconds: int
    brute_force_max_attempts: int
    bot_window_seconds: int
    bot_max_requests: int
    scanner_window_seconds: int
    scanner_max_requests: int
    auth_bypass_mode: Mode
    suspicious_request_mode: Mode
    debug: bool

    @property
    def observe_only_detections(self) -> Tuple[str, ...]:
        names: list[str] = []
        if self.auth_bypass_mode == "observe":
            names.append("auth_bypass")
        if self.suspicious_request_mode == "observe":
            names.append("suspicious_request")
        return tuple(names)

    @property
    def resolved_bridge_url(self) -> str:
        """POST target. If env is only origin (path empty or `/`), ``/ingest`` is appended."""
        raw = (self.bridge_url or "").strip()
        if not raw:
            return raw
        parsed = urlparse(raw)
        path = parsed.path or ""
        if path in ("", "/"):
            return raw.rstrip("/") + "/ingest"
        return raw

    @property
    def enabled(self) -> bool:
        return bool(self.bridge_url and self.api_key and self.site_id)

    @classmethod
    def from_env(cls, **overrides: Any) -> PrimeDefenderSettings:
        """Load from environment variables, then apply ``overrides`` (non-``None`` keys win)."""
        data: dict[str, Any] = {
            "bridge_url": _env_str("PRIMEDEFENDER_BRIDGE_URL"),
            "api_key": _env_str("PRIMEDEFENDER_API_KEY"),
            "site_id": _env_str("PRIMEDEFENDER_SITE_ID", "primestudio-api"),
            "site_lat": _env_float("PRIMEDEFENDER_SITE_LAT", -8.6705),
            "site_lon": _env_float("PRIMEDEFENDER_SITE_LON", 115.2126),
            "site_region_label": _env_str("PRIMEDEFENDER_SITE_REGION_LABEL", "Indonesia, Bali") or "Indonesia, Bali",
            "private_source_label": _env_str("PRIMEDEFENDER_PRIVATE_SOURCE_LABEL", "Local / private network")
            or "Local / private network",
            "body_cap_bytes": _env_int("PRIMEDEFENDER_BODY_CAP_BYTES", 16_384),
            "geoip_ttl_seconds": _env_int("PRIMEDEFENDER_GEOIP_TTL_SECONDS", 3600),
            "geoip_timeout_seconds": _env_float("PRIMEDEFENDER_GEOIP_TIMEOUT_SECONDS", 2.5),
            "bridge_timeout_seconds": _env_float("PRIMEDEFENDER_BRIDGE_TIMEOUT_SECONDS", 3.0),
            "flood_window_seconds": _env_int("PRIMEDEFENDER_FLOOD_WINDOW_SECONDS", 10),
            "flood_max_requests": _env_int("PRIMEDEFENDER_FLOOD_MAX_REQUESTS", 60),
            "brute_force_window_seconds": _env_int("PRIMEDEFENDER_BRUTE_WINDOW_SECONDS", 300),
            "brute_force_max_attempts": _env_int("PRIMEDEFENDER_BRUTE_MAX_ATTEMPTS", 12),
            "bot_window_seconds": _env_int("PRIMEDEFENDER_BOT_WINDOW_SECONDS", 60),
            "bot_max_requests": _env_int("PRIMEDEFENDER_BOT_MAX_REQUESTS", 30),
            "scanner_window_seconds": _env_int("PRIMEDEFENDER_SCANNER_WINDOW_SECONDS", 300),
            "scanner_max_requests": _env_int("PRIMEDEFENDER_SCANNER_MAX_REQUESTS", 12),
            "auth_bypass_mode": _env_mode("PRIMEDEFENDER_AUTH_BYPASS_MODE", "observe"),
            "suspicious_request_mode": _env_mode("PRIMEDEFENDER_SUSPICIOUS_REQUEST_MODE", "observe"),
            "debug": _env_bool("PRIMEDEFENDER_DEBUG"),
        }
        alias_map = {
            "site_label": "site_region_label",
        }
        for key, value in overrides.items():
            if value is None:
                continue
            target = alias_map.get(key, key)
            if target not in data:
                continue
            if target in ("auth_bypass_mode", "suspicious_request_mode"):
                v = str(value).lower()
                if v in ("observe", "block"):
                    data[target] = v
                continue
            data[target] = value
        return cls(**data)  # type: ignore[arg-type]


@lru_cache(maxsize=1)
def load_settings() -> PrimeDefenderSettings:
    """Cached settings from environment (call after ``load_dotenv()`` in the host app)."""
    return PrimeDefenderSettings.from_env()


def clear_settings_cache() -> None:
    """Mainly for tests."""
    load_settings.cache_clear()
