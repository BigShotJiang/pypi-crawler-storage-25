from __future__ import annotations

import asyncio
from typing import Any, Dict, Literal, Optional

from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.types import ASGIApp
from urllib.parse import unquote_plus

from primedefender_fastapi.config import PrimeDefenderSettings, load_settings
from primedefender_fastapi.geo import GeoIPCache
from primedefender_fastapi.reporter import report_incident
from primedefender_fastapi.detectors import RequestInspector

Mode = Literal["observe", "block"]


class PrimeDefenderMiddleware(BaseHTTPMiddleware):
    """
    Security inspection + optional blocking + PrimeDefender bridge reporting.

    Usage::

        app.add_middleware(PrimeDefenderMiddleware)

    With optional overrides (still reads other options from environment)::

        app.add_middleware(
            PrimeDefenderMiddleware,
            site_label=\"Indonesia, Bali\",
            auth_bypass_mode=\"observe\",
            suspicious_request_mode=\"block\",
        )
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        settings: Optional[PrimeDefenderSettings] = None,
        site_label: Optional[str] = None,
        auth_bypass_mode: Optional[Mode] = None,
        suspicious_request_mode: Optional[Mode] = None,
    ) -> None:
        super().__init__(app)
        if settings is not None:
            self.settings = settings
        else:
            overrides: Dict[str, Any] = {}
            if site_label is not None:
                overrides["site_region_label"] = site_label
            if auth_bypass_mode is not None:
                overrides["auth_bypass_mode"] = auth_bypass_mode
            if suspicious_request_mode is not None:
                overrides["suspicious_request_mode"] = suspicious_request_mode
            self.settings = (
                PrimeDefenderSettings.from_env(**overrides) if overrides else load_settings()
            )
        self.geoip = GeoIPCache(
            ttl_seconds=self.settings.geoip_ttl_seconds,
            timeout_seconds=self.settings.geoip_timeout_seconds,
        )
        self._inspector = RequestInspector(self.settings)

    async def dispatch(self, request: Request, call_next):
        if request.method.upper() == "OPTIONS":
            return await call_next(request)

        raw_body = await request.body()
        inspected_body = raw_body[: self.settings.body_cap_bytes]
        body_text = inspected_body.decode("utf-8", errors="ignore")
        request = self._clone_request(request, raw_body)

        client_ip = self._extract_client_ip(request)
        metadata = self._build_metadata(request, client_ip, body_text, len(raw_body))
        detection = self._inspector.inspect(metadata)

        if detection:
            if detection.blocked:
                await report_incident(self.settings, self.geoip, detection, metadata)
                return JSONResponse(
                    status_code=detection.status_code,
                    content={
                        "detail": "Request blocked by PrimeDefender security middleware.",
                        "detection": detection.name,
                        "action": detection.action,
                    },
                )
            asyncio.create_task(report_incident(self.settings, self.geoip, detection, metadata))

        return await call_next(request)

    def _clone_request(self, request: Request, body: bytes) -> Request:
        async def receive() -> Dict[str, Any]:
            return {"type": "http.request", "body": body, "more_body": False}

        return Request(request.scope, receive)

    def _build_metadata(
        self, request: Request, client_ip: str, body_text: str, body_size: int
    ) -> Dict[str, Any]:
        headers = {k.lower(): v for k, v in request.headers.items()}
        method = request.method.upper()
        path = request.url.path
        query = request.url.query or ""
        decoded_query = unquote_plus(query)
        decoded_path = unquote_plus(path)
        user_agent = headers.get("user-agent", "")
        combined = "\n".join(
            [
                decoded_path,
                decoded_query,
                body_text,
                " ".join(f"{k}:{v}" for k, v in headers.items()),
            ]
        )
        return {
            "method": method,
            "path": path,
            "decoded_path": decoded_path,
            "query": query,
            "decoded_query": decoded_query,
            "headers": headers,
            "user_agent": user_agent,
            "body_text": body_text,
            "body_size": body_size,
            "client_ip": client_ip,
            "combined": combined,
        }

    def _extract_client_ip(self, request: Request) -> str:
        hdr = request.headers
        for name in ("cf-connecting-ip", "x-real-ip"):
            value = hdr.get(name)
            if value:
                return value.strip()

        forwarded_for = hdr.get("x-forwarded-for")
        if forwarded_for:
            first = forwarded_for.split(",")[0].strip()
            if first:
                return first

        if request.client and request.client.host:
            return request.client.host
        return "unknown"
