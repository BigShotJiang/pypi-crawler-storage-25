from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Pattern

from primedefender_fastapi.config import PrimeDefenderSettings
from primedefender_fastapi.rate_limit import SlidingWindowLimiter


@dataclass
class Detection:
    name: str
    category: str
    severity: str
    blocked: bool
    action: str
    status_code: int
    detail: str


SQLI_PATTERNS = (
    r"(?i)\bunion\b.{0,20}\bselect\b",
    r"(?i)\bselect\b.{0,20}\bfrom\b",
    r"(?i)\binformation_schema\b",
    r"(?i)\bor\b\s+1=1",
    r"(?i)'\s*or\s*'1'='1",
    r"(?i)\bsleep\s*\(",
    r"(?i)\bbenchmark\s*\(",
    r"(?i)\bdrop\s+table\b",
    r"(?i)\bwaitfor\s+delay\b",
)
XSS_PATTERNS = (
    r"(?i)<script\b",
    r"(?i)javascript:",
    r"(?i)onerror\s*=",
    r"(?i)onload\s*=",
    r"(?i)<svg\b",
    r"(?i)<img\b",
    r"(?i)document\.cookie",
    r"(?i)alert\s*\(",
)
PATH_TRAVERSAL_PATTERNS = (
    r"\.\./",
    r"\.\.\\",
    r"%2e%2e%2f",
    r"%252e%252e%252f",
    r"/etc/passwd",
    r"win\.ini",
    r"/proc/self/environ",
)
COMMAND_INJECTION_PATTERNS = (
    r"(?i)(?:;|\|\||&&)\s*(?:curl|wget|bash|sh|powershell|cmd\.exe|nc)\b",
    r"`[^`]+`",
    r"\$\([^)]+\)",
    r"(?i)\b(?:cmd\.exe|/bin/sh|powershell)\b",
)
FILE_INCLUSION_PATTERNS = (
    r"(?i)\b(?:php|file|zip|data|expect)://",
    r"(?i)\b(?:web-inf|phpmyadmin|wp-config\.php|\.git/config)\b",
    r"(?i)\b(?:include|require)(_once)?\b",
)
SCANNER_UA_MARKERS = (
    "sqlmap",
    "nikto",
    "nmap",
    "nessus",
    "dirbuster",
    "gobuster",
    "feroxbuster",
    "wafw00f",
    "masscan",
    "nuclei",
    "acunetix",
    "burp",
    "zaproxy",
)
BOT_UA_MARKERS = (
    "python-requests",
    "curl/",
    "wget/",
    "aiohttp",
    "scrapy",
    "httpclient",
    "okhttp",
    "libwww",
    "urllib",
    "bot",
    "crawler",
    "spider",
)
SCANNER_PATH_MARKERS = (
    "/.env",
    "/.git",
    "/wp-admin",
    "/wp-login.php",
    "/phpmyadmin",
    "/cgi-bin",
    "/actuator",
    "/vendor/phpunit",
    "/boaform",
)
AUTH_BYPASS_MARKERS = (
    "x-original-url",
    "x-rewrite-url",
    "x-forwarded-host",
    "x-host",
    "x-http-method-override",
)
AUTH_PATHS = (
    "/auth/login",
    "/auth/register",
    "/auth/forgot-password",
    "/auth/reset-password",
    "/auth/reset-password-with-code",
    "/auth/verify-reset-code",
)


def compile_pattern_buckets() -> Dict[str, List[Pattern[str]]]:
    return {
        "sqli": [re.compile(p) for p in SQLI_PATTERNS],
        "xss": [re.compile(p) for p in XSS_PATTERNS],
        "path_traversal": [re.compile(p, re.IGNORECASE) for p in PATH_TRAVERSAL_PATTERNS],
        "command_injection": [re.compile(p) for p in COMMAND_INJECTION_PATTERNS],
        "file_inclusion": [re.compile(p) for p in FILE_INCLUSION_PATTERNS],
    }


class RequestInspector:
    """Stateful rate limits + signature detection for one app instance."""

    def __init__(self, settings: PrimeDefenderSettings) -> None:
        self.settings = settings
        self.flood_limiter = SlidingWindowLimiter()
        self.brute_force_limiter = SlidingWindowLimiter()
        self.bot_limiter = SlidingWindowLimiter()
        self.scanner_limiter = SlidingWindowLimiter()
        self._compiled = compile_pattern_buckets()

    def inspect(self, meta: Dict[str, Any]) -> Optional[Detection]:
        ip = meta["client_ip"]
        method = meta["method"]
        path = meta["decoded_path"].lower()
        query = meta["decoded_query"].lower()
        combined = meta["combined"]
        ua = meta["user_agent"].lower()
        headers = meta["headers"]

        flood_count = self.flood_limiter.hit(ip, self.settings.flood_window_seconds)
        if flood_count > self.settings.flood_max_requests:
            return self._decision("ddos", "Application flood limit exceeded.", blocked=True)

        if method == "POST" and path in AUTH_PATHS:
            brute_count = self.brute_force_limiter.hit(
                f"{ip}:{path}", self.settings.brute_force_window_seconds
            )
            if brute_count > self.settings.brute_force_max_attempts:
                return self._decision("brute_force_login", "Brute force login pattern detected.", blocked=True)

        if any(marker in ua for marker in SCANNER_UA_MARKERS) or any(
            marker in path for marker in SCANNER_PATH_MARKERS
        ):
            scanner_count = self.scanner_limiter.hit(ip, self.settings.scanner_window_seconds)
            if scanner_count >= self.settings.scanner_max_requests:
                return self._decision("scanner_activity", "Scanner activity detected.", blocked=True)

        if any(marker in ua for marker in BOT_UA_MARKERS):
            bot_count = self.bot_limiter.hit(ip, self.settings.bot_window_seconds)
            if bot_count > self.settings.bot_max_requests:
                return self._decision("bot_activity", "Automated bot activity detected.", blocked=True)

        if self._matches("path_traversal", combined):
            return self._decision("path_traversal", "Path traversal signature matched.", blocked=True)
        if self._matches("file_inclusion", combined):
            return self._decision("file_inclusion", "File inclusion signature matched.", blocked=True)
        if self._matches("command_injection", combined):
            return self._decision("command_injection", "Command injection signature matched.", blocked=True)
        if self._matches("sqli", combined):
            return self._decision("sqli", "SQL injection signature matched.", blocked=True)
        if self._matches("xss", combined):
            return self._decision("xss", "XSS signature matched.", blocked=True)

        if (
            any(header in headers for header in AUTH_BYPASS_MARKERS)
            or "admin=true" in query
            or "role=admin" in query
        ):
            return self._decision("auth_bypass", "Authorization bypass probe observed.", blocked=False)

        suspicious_method = method in {"TRACE", "CONNECT"}
        suspicious_query = len(meta["query"]) > 2048 or "%25" in meta["query"]
        suspicious_body = meta["body_size"] > self.settings.body_cap_bytes
        if suspicious_method or suspicious_query or suspicious_body or not ua:
            return self._decision("suspicious_request", "Suspicious request observed.", blocked=False)

        return None

    def _decision(self, name: str, detail: str, blocked: bool) -> Detection:
        observe_only = name in self.settings.observe_only_detections
        effective_blocked = blocked and not observe_only
        action = "blocked" if effective_blocked else "observed"

        if name == "ddos":
            return Detection(name, "ddos", "critical", effective_blocked, action, 429, detail)
        if name in {"scanner_activity", "brute_force_login"}:
            return Detection(name, "intrusion", "high", effective_blocked, action, 429, detail)
        if name == "bot_activity":
            return Detection(name, "botnet", "medium", effective_blocked, action, 429, detail)
        if name == "command_injection":
            return Detection(name, "malware", "critical", effective_blocked, action, 403, detail)
        if name in {"sqli", "xss", "path_traversal", "file_inclusion"}:
            return Detection(name, "intrusion", "high", effective_blocked, action, 403, detail)
        if name == "auth_bypass":
            return Detection(name, "intrusion", "medium", effective_blocked, action, 403, detail)
        return Detection(name, "unknown", "low", effective_blocked, action, 403, detail)

    def _matches(self, bucket: str, content: str) -> bool:
        return any(pattern.search(content) for pattern in self._compiled[bucket])
