from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional, Tuple

import httpx

from primedefender_fastapi.config import PrimeDefenderSettings
from primedefender_fastapi.detectors import Detection
from primedefender_fastapi.geo import GeoIPCache, is_private_ip

logger = logging.getLogger(__name__)


def parse_header_float(raw: Optional[str]) -> Optional[float]:
    if raw is None or not str(raw).strip():
        return None
    try:
        return float(str(raw).strip())
    except ValueError:
        return None


def prime_header_overrides(meta: Dict[str, Any]) -> Tuple[Optional[float], Optional[float], str]:
    h = meta["headers"]
    lat = parse_header_float(h.get("x-prime-source-lat"))
    lon = parse_header_float(h.get("x-prime-source-lon"))
    label = (h.get("x-prime-source-label") or "").strip()
    return lat, lon, label


async def report_incident(
    settings: PrimeDefenderSettings,
    geo: GeoIPCache,
    detection: Detection,
    meta: Dict[str, Any],
) -> None:
    if not settings.enabled:
        logger.debug("PrimeDefender: skip bridge (set PRIMEDEFENDER_BRIDGE_URL, API_KEY, SITE_ID)")
        return

    url = settings.resolved_bridge_url
    if settings.debug:
        logger.debug("PrimeDefender: POST %s detection=%s", url, detection.name)

    client_ip = meta["client_ip"]
    oh_lat, oh_lon, oh_label = prime_header_overrides(meta)
    has_coord_override = oh_lat is not None and oh_lon is not None
    has_label_override = bool(oh_label)

    geo_lat: Optional[float] = None
    geo_lon: Optional[float] = None
    geo_label: Optional[str] = None
    if not has_coord_override:
        geo_lat, geo_lon, geo_label = await geo.get(client_ip)

    if has_coord_override:
        attacker_lat, attacker_lon = oh_lat, oh_lon
    else:
        attacker_lat, attacker_lon = geo_lat, geo_lon

    if attacker_lat is None or attacker_lon is None:
        attacker_lat = 0.0
        attacker_lon = 0.0

    if has_label_override:
        source_label = oh_label
    elif has_coord_override and not has_label_override:
        source_label = f"{float(attacker_lat):.3f}, {float(attacker_lon):.3f}"
    elif is_private_ip(client_ip):
        source_label = settings.private_source_label
    elif geo_label:
        source_label = geo_label
    else:
        source_label = f"Unknown location ({client_ip})"

    site_region = settings.site_region_label
    target_label = f"{settings.site_id} · {site_region}"

    payload: Dict[str, Any] = {
        "from": {
            "lat": float(attacker_lat),
            "lon": float(attacker_lon),
        },
        "to": {
            "lat": float(settings.site_lat),
            "lon": float(settings.site_lon),
        },
        "category": detection.category,
        "severity": detection.severity,
        "sourceLabel": source_label,
        "targetLabel": target_label,
        "siteId": settings.site_id,
        "createdAt": int(time.time() * 1000),
        "blocked": detection.blocked,
        "action": detection.action,
        "path": meta["path"],
        "method": meta["method"],
        "attackerIp": client_ip,
        "userAgent": meta["user_agent"],
        "detection": detection.name,
    }
    if detection.category == "ddos":
        payload["ddos"] = {"vector": "application"}

    headers = {
        "Content-Type": "application/json",
        "X-Api-Key": settings.api_key,
        "Authorization": f"Bearer {settings.api_key}",
    }

    try:
        async with httpx.AsyncClient(timeout=settings.bridge_timeout_seconds) as client:
            response = await client.post(url, json=payload, headers=headers)
    except httpx.HTTPError as exc:
        logger.warning(
            "PrimeDefender: bridge HTTP error posting to %s: %s",
            url,
            exc,
            exc_info=settings.debug,
        )
        return
    except Exception as exc:
        logger.warning(
            "PrimeDefender: bridge unexpected error posting to %s: %s",
            url,
            exc,
            exc_info=True,
        )
        return

    log_msg = (
        "PrimeDefender: bridge status=%s from=%s to=%s sourceLabel=%r targetLabel=%r detection=%s blocked=%s"
        % (
            response.status_code,
            payload["from"],
            payload["to"],
            source_label,
            target_label,
            detection.name,
            detection.blocked,
        )
    )
    if response.is_success:
        logger.info(log_msg)
    else:
        logger.warning("%s url=%s body=%r", log_msg, url, (response.text or "")[:800])
