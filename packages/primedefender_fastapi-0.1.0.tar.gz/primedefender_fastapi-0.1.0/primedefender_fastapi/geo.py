from __future__ import annotations

import ipaddress
import time
from typing import Dict, Optional, Tuple

import httpx


def is_private_ip(ip: str) -> bool:
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return True


def format_ip_location_label(
    country: Optional[str],
    region_name: Optional[str],
    city: Optional[str],
) -> Optional[str]:
    """Human-readable place name, e.g. 'Japan, Osaka' or 'United States, Virginia'."""
    if not country:
        return None
    if country == "United States":
        second = region_name or city
    else:
        second = city or region_name
    if second:
        return f"{country}, {second}"
    return country


class GeoIPCache:
    def __init__(self, ttl_seconds: int, timeout_seconds: float) -> None:
        self.ttl_seconds = ttl_seconds
        self.timeout_seconds = timeout_seconds
        self._cache: Dict[str, Tuple[float, Tuple[Optional[float], Optional[float], Optional[str]]]] = {}

    async def get(self, ip: str) -> Tuple[Optional[float], Optional[float], Optional[str]]:
        if not ip or is_private_ip(ip):
            return (None, None, None)

        now = time.time()
        cached = self._cache.get(ip)
        if cached and cached[0] > now:
            return cached[1]

        lat: Optional[float] = None
        lon: Optional[float] = None
        label: Optional[str] = None
        url = f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,lat,lon"

        try:
            async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
                response = await client.get(url)
                response.raise_for_status()
                data = response.json()
                if data.get("status") == "success":
                    lat = data.get("lat")
                    lon = data.get("lon")
                    label = format_ip_location_label(
                        data.get("country"),
                        data.get("regionName"),
                        data.get("city"),
                    )
        except Exception:
            pass

        triple = (lat, lon, label)
        self._cache[ip] = (now + self.ttl_seconds, triple)
        return triple
