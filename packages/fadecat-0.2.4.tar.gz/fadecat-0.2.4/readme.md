# Fadecat
Fadecat is a fast and easy-to-use library to enhance your terminal.

Using Fadecat allows you to choose color presets (including your custom ones) and tilt.

Standard palettes that are available after installation

| Palette | Method | Preview |
| :--- | :--- | :---: |
| **Lime** | `.lime()` | ![lime](gallery/lime.svg) |
| **Amethyst** | `.amethyst()` | ![amethyst](gallery/amethyst.svg) |
| **Unicorn** | `.unicorn()` | ![unicorn](gallery/unicorn.svg) |
| **Acid** | `.acid()` | ![acid](gallery/acid.svg) |
| **Ultraviolet** | `.ultraviolet()` | ![ultraviolet](gallery/ultraviolet.svg) |
| **Nectar** | `.nectar()` | ![nectar](gallery/nectar.svg) |
| **Moon** | `.moon()` | ![moon](gallery/moon.svg) |
| **Lagoon** | `.lagoon()` | ![lagoon](gallery/lagoon.svg) |
| **Popsicles** | `.popsicles()` | ![popsicles](gallery/popsicles.svg) |
| **Matcha** | `.matcha()` | ![matcha](gallery/matcha.svg) |
| **Cherry** | `.cherry()` | ![cherry](gallery/cherry.svg) |
| **Magma** | `.magma()` | ![magma](gallery/magma.svg) |
| **Atlantis** | `.atlantis()` | ![atlantis](gallery/atlantis.svg) |
| **Sun** | `.sun()` | ![sun](gallery/sun.svg) |
| **Orca** | `.orca()` | ![orca](gallery/orca.svg) |
| **Reef** | `.reef()` | ![reef](gallery/reef.svg) |
| **Honey** | `.honey()` | ![honey](gallery/honey.svg) |
| **Cobalt** | `.cobalt()` | ![cobalt](gallery/cobalt.svg) |
| **Garnet** | `.garnet()` | ![garnet](gallery/garnet.svg) |
| **Bamboo** | `.bamboo()` | ![bamboo](gallery/bamboo.svg) |

### Getting started
Install with pip or your favorite PyPI package manager.
```bash
pip install fadecat
```
Checking that the library was installed successfully.
```bash
pip show fadecat
```
If you have received information about the library, you can continue working.

### How to use the library
To get started, first import the library
```python
from fadecat import fadecat
```

#### Parsing the call structure
For example
```python
print(fadecat.unicorn("Hello world from unicorns! 🦄", tilt=360))
```
Let's look at each element
Element | Type | Description |
| :--- | :--- | :--- |
| **`fadecat`** | Object | An instance of the main `FadeCat` class. It initializes ANSI support and provides access to all palettes. |
| **`.unicorn`** | Method | Any palette name (like .sun, .reef, .garnet). These are dynamic methods generated from the built-in color collection. |
| **`"text"`** | String | Your text. The gradient is automatically distributed across the entire string length (including multi-line blocks). |
| **`tilt`** | Number | The gradient angle (0-360°). It allows you to change the direction of the color transition. (default 0°)|

If you want to create your own preset
```python
print(fadecat.custom("My Text", (255,0,0), (0,0,255), tilt=90))
```
Let's talk a little about custom presets
| Parameter | Type | Purpose |
| :--- | :--- | :--- |
| **`start_rgb`** | `tuple` | Starting color in (R, G, B) format. Example: `(255, 100, 0)`. |
| **`end_rgb`** | `tuple` | Ending color in (R, G, B) format. Example: `(0, 50, 200)`. |