#made by github.com/m2uroy

import sys
import ctypes
import math

class FadeCat:
    PALETTES = {
        "lime": ((113, 203, 107), (243, 252, 84)),
        "amethyst": ((137, 45, 219), (206, 135, 239)),
        "unicorn": ((241, 107, 60), (156, 36, 238)),
        "acid": ((211, 244, 58), (248, 241, 129)),
        "ultraviolet": ((177, 48, 182), (39, 1, 77)),
        "nectar": ((235, 217, 133), (191, 50, 72)),
        "moon": ((187, 195, 200), (95, 100, 107)),
        "lagoon": ((14, 133, 248), (94, 236, 191)),
        "popsicles": ((153, 221, 123), (250, 199, 219)),
        "matcha": ((175, 231, 129), (171, 227, 91)),
        "cherry": ((189, 34, 70), (89, 17, 3)),
        "magma": ((254, 2, 9), (226, 190, 88)),
        "atlantis": ((67, 198, 172), (25, 22, 84)),
        "sun": ((252, 234, 187), (248, 181, 0)),
        "orca": ((68, 160, 141), (9, 54, 55)),
        "reef": ((0, 210, 255), (58, 123, 213)),
        "honey": ((255, 183, 94), (237, 143, 3)),
        "cobalt": ((42, 31, 148), (12, 136, 238)),
        "garnet": ((237, 33, 58), (147, 41, 30)),
        "bamboo": ((85, 211, 121), (38, 103, 45)),    
    }

    def __init__(self):
        self._enable_ansi()

    def _enable_ansi(self):
        if sys.platform == "win32":
            try:
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.GetStdHandle(-11)
                mode = ctypes.c_ulong()
                kernel32.GetConsoleMode(handle, ctypes.byref(mode))
                if not (mode.value & 0x0004):
                    kernel32.SetConsoleMode(handle, mode.value | 0x0004)
            except Exception:
                pass

    def _interpolate_color(self, ratio, start_rgb, end_rgb):
        r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
        g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
        b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
        return max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))

    def _apply_gradient(self, text, start_color, end_color, tilt=0):
        if not text: return ""
        lines = text.splitlines()
        if not lines: return ""

        max_width = max(len(line) for line in lines)
        height = len(lines)
        if max_width == 0: return ""
        
        ASPECT_RATIO = 0.5
        y_scale = 1.0 / max(1, height - 1)
        x_scale = 1.0 / max_width
        rad = math.radians(tilt)
        cos_a, sin_a = math.cos(rad), math.sin(rad)
        
        min_proj, max_proj = float('inf'), float('-inf')
        char_data = []

        for y, line in enumerate(lines):
            line_data = []
            for x, char in enumerate(line):
                nx, ny = x * x_scale, (y * y_scale) * ASPECT_RATIO
                proj = nx * cos_a + ny * sin_a
                min_proj, max_proj = min(min_proj, proj), max(max_proj, proj)
                line_data.append((char, nx, ny))
            char_data.append(line_data)

        range_proj = max_proj - min_proj if (max_proj - min_proj) > 1e-6 else 1.0
        result = []
        for line_data in char_data:
            for char, nx, ny in line_data:
                proj = nx * cos_a + ny * sin_a
                ratio = max(0.0, min(1.0, (proj - min_proj) / range_proj))
                ratio = ratio * ratio * (3 - 2 * ratio)
                r, g, b = self._interpolate_color(ratio, start_color, end_color)
                result.append(f"\033[38;2;{r};{g};{b}m{char}")
            result.append("\n")

        return ''.join(result).rstrip('\n') + "\033[0m"

    def custom(self, text, start_color, end_color, tilt=0):
        return self._apply_gradient(text, start_color, end_color, tilt)

    def __getattr__(self, name):
        if name in self.PALETTES:
            start, end = self.PALETTES[name]
            return lambda text, tilt=0: self._apply_gradient(text, start, end, tilt)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

fadecat = FadeCat()