from typing import Protocol, Tuple

class GradientMethod(Protocol):
    def __call__(self, text: str, tilt: int = 0) -> str: ...

class FadeCat:
    lime: GradientMethod
    amethyst: GradientMethod
    unicorn: GradientMethod
    acid: GradientMethod
    ultraviolet: GradientMethod
    nectar: GradientMethod
    moon: GradientMethod
    lagoon: GradientMethod
    popsicles: GradientMethod
    matcha: GradientMethod
    cherry: GradientMethod
    magma: GradientMethod
    atlantis: GradientMethod
    sun: GradientMethod
    orca: GradientMethod
    reef: GradientMethod
    honey: GradientMethod
    cobalt: GradientMethod
    garnet: GradientMethod
    bamboo: GradientMethod


    def custom(self, text: str, start_color: Tuple[int, int, int], 
               end_color: Tuple[int, int, int], tilt: int = 0) -> str: ...
    
    def _apply_gradient(self, text: str, start_color: Tuple[int, int, int], 
                        end_color: Tuple[int, int, int], tilt: int = 0) -> str: ...

    def _enable_ansi(self) -> None: ...
    
    def _interpolate_color(self, ratio: float, start_rgb: Tuple[int, int, int], 
                           end_rgb: Tuple[int, int, int]) -> Tuple[int, int, int]: ...

fadecat: FadeCat