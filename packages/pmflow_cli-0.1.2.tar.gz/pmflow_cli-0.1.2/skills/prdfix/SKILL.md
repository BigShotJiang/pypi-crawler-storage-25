---
name: pmflow:prdfix
description: 回顾编码工作，生成 PRD 实现总结并创建飞书文档关联到 issue。用法：/pmflow:prdfix {slug}-{seq_num}（如 WS-3）
user-invocable: true
---

解析参数 `$ARGUMENTS`，格式为 `{slug}-{seq_num}`（如 `WS-3`），以最后一个 `-` 为分隔符拆分出 workspace slug（转小写）和 issue 序号。

执行以下步骤：

## 1. 回顾实际实现

回顾本次对话中的所有编码工作，总结**实际实现方案**。注意：
- 只总结思路和方案，不要包含具体代码
- 重点关注与原始 PRD 的差异（如有）
- 记录关键设计决策和取舍
- 包括实现过程中发现的问题和解决方式

用 Markdown 格式组织总结，包含以下部分：
- **实现概述**：一段话概括实际做了什么
- **与原始 PRD 的差异**：列出偏离原计划的地方及原因（如完全一致则注明）
- **关键设计决策**：重要的技术选型和权衡
- **已知局限 / 后续改进**：当前方案的已知限制

## 2. 创建飞书文档并关联 Issue

将上述总结内容用 Bash `cat <<'EOF'` 写入临时文件 `/tmp/prdfix-{slug}-{seq_num}.md`（不要先读取任何已有文件），然后运行命令：

```
pmflow ctx add-doc {seq_num} --workspace {slug} --title "[{slug上大写}-{seq_num}] 实现总结" --content-file /tmp/prdfix-{slug}-{seq_num}.md
```

如果命令失败，将错误信息告知用户并停止。

## 3. 将 Issue 状态更新为 DONE

运行命令：

```
pmflow issue status {seq_num} done --workspace {slug}
```

如果命令失败，将错误信息告知用户但继续执行后续步骤（状态变更失败不应阻塞工作流）。

## 4. 确认完成

命令成功后，将飞书文档链接展示给用户，确认总结已保存到对应 Issue 的上下文中，并告知 Issue 状态已更新为 DONE。
