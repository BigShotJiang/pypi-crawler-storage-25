---
name: pmflow:plan-task
description: 获取 pmflow issue 的上下文并制定实现方案。用法：/pmflow:plan-task {slug}-{seq_num}（如 WS-3）
user-invocable: true
---

解析参数 `$ARGUMENTS`，格式为 `{slug}-{seq_num}`（如 `WS-3`），以最后一个 `-` 为分隔符拆分出 workspace slug（转小写）和 issue 序号。

执行以下步骤：

## 1. 将 Issue 状态更新为 DOING

运行命令：

```
pmflow issue status {seq_num} doing --workspace {slug}
```

如果命令失败，将错误信息告知用户但继续执行后续步骤（状态变更失败不应阻塞工作流）。

## 2. 获取 Issue 的所有上下文内容

运行命令：

```
pmflow ctx dump {seq_num} --workspace {slug}
```

如果命令失败，将错误信息告知用户并停止。

## 3. 进入 Plan 模式

成功获取上下文内容后，进入 plan 模式。基于上下文中的需求文档（PRD、设计文档等），制定详细的技术实现方案：

- 仔细分析文档中的功能需求
- 根据本项目的架构确定需要创建或修改的文件
- 将工作拆解为有序的实现步骤
- 复用项目中已有的工具函数和模式
