---
name: pmflow:plan-space
description: 获取 pmflow workspace 的所有上下文（PRD、设计文档等），进入 plan 模式制定技术实现方案。用法：/pmflow:plan-space {slug}
user-invocable: true
---

从参数 `$ARGUMENTS` 中获取 workspace slug。

执行以下步骤：

## 1. 获取 Space 的所有上下文内容

运行命令：

```
pmflow ctx dump-space {slug}
```

如果命令失败，将错误信息告知用户并停止。

## 2. 进入 Plan 模式

成功获取上下文内容后，进入 plan 模式。基于上下文中的需求文档（PRD、设计文档等），制定详细的技术实现方案：

- 仔细分析文档中的功能需求
- 根据本项目的架构确定需要创建或修改的文件
- 将工作拆解为有序的实现步骤
- 复用项目中已有的工具函数和模式
