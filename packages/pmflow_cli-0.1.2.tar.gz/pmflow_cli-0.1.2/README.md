# pmflow

CLI for pmflow — an integrated project management and AI-assisted development platform.

pmflow connects project planning (PRDs, design docs) with AI coding tools, providing seamless context access via CLI and Claude Code slash commands.

## Installation

```bash
pip install pmflow-cli
```

## Quick Start

```bash
# Configure server connection
pmflow login --server https://your-server.com --token pmf_xxx

# Install Claude Code skills (optional)
pmflow skills install

# Basic commands
pmflow whoami                    # Check connection
pmflow ws list                   # List workspaces
pmflow issue list -w my-project  # List issues
pmflow ctx dump 3 -w my-project  # Dump issue context for AI
```

## Claude Code Integration

After running `pmflow skills install`, the following slash commands are available in Claude Code:

- `/pmflow:plan-space {slug}` — Load workspace context and plan implementation
- `/pmflow:plan-task {slug}-{seq}` — Load issue context and plan implementation
- `/pmflow:prdfix {slug}-{seq}` — Summarize implementation and create Feishu doc
