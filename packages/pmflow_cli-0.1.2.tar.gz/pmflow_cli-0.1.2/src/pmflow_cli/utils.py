"""Shared CLI utilities."""

import asyncio
from collections.abc import Coroutine
from typing import TypeVar

import typer

from pmflow_cli.config import CliConfig
from pmflow_cli.output import console, format_error

T = TypeVar("T")


def get_workspace(workspace: str | None) -> str:
    """Resolve workspace slug from CLI option or saved config."""
    if workspace:
        return workspace
    config = CliConfig.load()
    if not config.workspace:
        console.print(
            "[red]Error:[/red] No workspace specified. "
            "Use --workspace or set default with `pmflow ws switch`."
        )
        raise typer.Exit(1)
    return config.workspace


def run_async(coro: Coroutine[None, None, T]) -> T:
    """Run an async coroutine with user-friendly error handling.

    Wraps asyncio.run with consistent error formatting and exit code.
    """
    try:
        return asyncio.run(coro)
    except Exception as e:
        console.print(f"[red]Error:[/red] {format_error(e)}")
        raise typer.Exit(1)
