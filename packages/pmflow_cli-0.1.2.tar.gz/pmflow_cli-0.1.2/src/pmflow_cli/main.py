import typer

from pmflow_cli.commands import ai, auth, context, issue, skills, workspace

app = typer.Typer(name="pmflow", help="pmflow - Project management for AI-assisted development")

app.add_typer(auth.app, name="auth")
app.add_typer(workspace.app, name="ws", help="Workspace management")
app.add_typer(issue.app, name="issue", help="Issue management")
app.add_typer(context.app, name="ctx", help="Context (attachments/docs) management")
app.add_typer(ai.app, name="ai", help="AI-assisted PRD generation")
app.add_typer(skills.app, name="skills", help="Manage Claude Code skills")


@app.command()
def login(
    server: str = typer.Option("https://pm-flow.ai", "--server", "-s", prompt="Server URL"),
    token: str = typer.Option(..., "--token", "-t", prompt="API Token (pmf_...)"),
):
    """Configure server URL and API token."""
    from pmflow_cli.config import CliConfig
    from pmflow_cli.output import console

    config = CliConfig.load()
    config.server_url = server
    config.api_token = token
    config.save()
    console.print(f"[green]Saved.[/green] Server: {server}")


@app.command()
def logout():
    """Clear local credentials."""
    from pmflow_cli.config import CliConfig
    from pmflow_cli.output import console

    config = CliConfig.load()
    config.api_token = ""
    config.save()
    console.print("[green]Token cleared.[/green]")


@app.command()
def whoami():
    """Show current user info."""
    import asyncio

    from pmflow_cli.client import PmflowClient
    from pmflow_cli.output import console

    async def _whoami():
        async with PmflowClient() as client:
            resp = await client.http.get("/auth/me")
            resp.raise_for_status()
            return resp.json()

    try:
        user = asyncio.run(_whoami())
        console.print(f"User: {user.get('username', '')} ({user.get('email', '')})")
    except Exception as e:
        from pmflow_cli.output import format_error
        console.print(f"[red]Error:[/red] {format_error(e)}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
