import httpx

from pmflow_shared.constants import API_V1_PREFIX

from pmflow_cli.config import CliConfig


class PmflowClient:
    def __init__(self, config: CliConfig | None = None):
        self.config = config or CliConfig.load()
        self.http = httpx.AsyncClient(
            base_url=f"{self.config.server_url}{API_V1_PREFIX}",
            headers={"Authorization": f"Bearer {self.config.api_token}"},
            timeout=30.0,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.http.aclose()
