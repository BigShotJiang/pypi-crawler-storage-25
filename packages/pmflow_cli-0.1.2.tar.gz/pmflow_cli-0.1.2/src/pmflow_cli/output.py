"""Rich terminal output formatting utilities."""

import httpx
from rich.console import Console
from rich.table import Table

console = Console()


def print_table(columns: list[str], rows: list[list[str]], title: str | None = None) -> None:
    table = Table(title=title)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*row)
    console.print(table)


def format_error(exc: Exception) -> str:
    """Format an exception into a user-friendly error message."""
    if isinstance(exc, httpx.ConnectError):
        return "无法连接到服务器，请检查服务是否启动或网络连接"
    if isinstance(exc, httpx.TimeoutException):
        return "请求超时，请稍后重试"
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        if code == 401:
            return "认证失败，请运行 `pmflow auth login` 重新登录"
        if code == 403:
            return "权限不足，无法执行此操作"
        if code == 404:
            return "资源不存在，请检查参数是否正确"
        if code >= 500:
            return f"服务器错误 ({code})，请稍后重试"
        # Try to extract detail from response body
        try:
            detail = exc.response.json().get("detail", "")
            if detail:
                return detail
        except Exception:
            pass
        return f"请求失败 ({code})"
    return str(exc)
