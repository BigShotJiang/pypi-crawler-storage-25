import json
import sys
from pathlib import Path
from typing import Optional

import typer

from pmflow_cli.client import PmflowClient
from pmflow_cli.output import console, print_table
from pmflow_cli.utils import get_workspace, run_async

app = typer.Typer(name="ctx", help="Context management")


# ---------------------------------------------------------------------------
# Feishu doc helpers (via server API)
# ---------------------------------------------------------------------------


def _fetch_feishu_doc(doc_token: str) -> str:
    """Fetch feishu document content as markdown via server API."""

    async def _get():
        async with PmflowClient() as client:
            resp = await client.http.get(f"/feishu/docs/{doc_token}")
            resp.raise_for_status()
            return resp.json()

    data = run_async(_get())
    return data.get("content", "")


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def _print_contexts(contexts: list[dict], title: str, format: str):
    if format == "json":
        console.print_json(json.dumps(contexts))
        return
    if not contexts:
        console.print("No contexts found.")
        return
    print_table(
        columns=["Type", "Title", "Doc Token", "URL"],
        rows=[
            [
                c.get("type", ""),
                c.get("title", ""),
                c.get("feishu_doc_token", "") or "",
                c.get("feishu_doc_url", "") or c.get("url", "") or "",
            ]
            for c in contexts
        ],
        title=title,
    )


def _dump_contexts(contexts: list[dict]):
    """Fetch full content for each context and output as markdown."""
    for c in contexts:
        title = c.get("title", "Untitled")
        ctx_type = c.get("type", "")
        print(f"## {title}\n")

        if ctx_type == "feishu_doc" and c.get("feishu_doc_token"):
            try:
                content = _fetch_feishu_doc(c["feishu_doc_token"])
                print(content)
            except Exception as e:
                print(f"[Failed to fetch document: {e}]")
        elif c.get("content"):
            print(c["content"])
        elif c.get("url"):
            print(f"Link: {c['url']}")
        elif c.get("feishu_doc_url"):
            print(f"Link: {c['feishu_doc_url']}")
        else:
            print(f"[{ctx_type} context, no inline content]")

        print()


# ---------------------------------------------------------------------------
# Shared add-doc logic
# ---------------------------------------------------------------------------


def _add_doc_impl(
    feishu_api_path: str,
    title: str,
    doc_content: str,
) -> None:
    """Create or update a Feishu doc via server API. Shared by add_doc and add_space_doc."""
    console.print(f"Creating/updating feishu doc: {title} ...")

    async def _upsert():
        async with PmflowClient() as client:
            resp = await client.http.post(
                feishu_api_path,
                json={
                    "title": title,
                    "markdown": doc_content,
                    "create_new": True,
                },
            )
            resp.raise_for_status()
            return resp.json()

    ctx = run_async(_upsert())
    doc_url = ctx.get("feishu_doc_url", "")
    console.print(f"[green]Done![/green] {title} -> {doc_url}")


def _resolve_content(
    content: str | None,
    content_file: str | None,
) -> str:
    """Resolve document content from --content or --content-file flags."""
    if content_file:
        if content_file == "-":
            return sys.stdin.read()
        return Path(content_file).read_text(encoding="utf-8")
    if content:
        return content
    console.print("[red]Error:[/red] Provide --content or --content-file")
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Issue contexts
# ---------------------------------------------------------------------------


@app.command("list")
def list_contexts(
    seq_num: int = typer.Argument(..., help="Issue sequence number"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace slug (overrides default)"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table or json"),
):
    """List contexts for an issue."""
    slug = get_workspace(workspace)

    async def _list():
        async with PmflowClient() as client:
            resp = await client.http.get(f"/workspaces/{slug}/issues/{seq_num}/contexts")
            resp.raise_for_status()
            return resp.json()

    contexts = run_async(_list())
    _print_contexts(contexts, f"Contexts for issue #{seq_num}", format)


@app.command("dump")
def dump_issue_contexts(
    seq_num: int = typer.Argument(..., help="Issue sequence number"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace slug (overrides default)"),
):
    """Dump all context content for an issue. Fetches feishu doc content inline."""
    slug = get_workspace(workspace)

    async def _list():
        async with PmflowClient() as client:
            resp = await client.http.get(f"/workspaces/{slug}/issues/{seq_num}/contexts")
            resp.raise_for_status()
            return resp.json()

    contexts = run_async(_list())
    if not contexts:
        console.print("No contexts found.", stderr=True)
        raise typer.Exit(1)
    _dump_contexts(contexts)


# ---------------------------------------------------------------------------
# Space contexts
# ---------------------------------------------------------------------------


@app.command("list-space")
def list_space_contexts(
    slug: str = typer.Argument(..., help="Workspace slug"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table or json"),
):
    """List contexts for a workspace (space-level)."""
    async def _list():
        async with PmflowClient() as client:
            resp = await client.http.get(f"/workspaces/{slug}/contexts")
            resp.raise_for_status()
            return resp.json()

    contexts = run_async(_list())
    _print_contexts(contexts, f"Space contexts for {slug}", format)


@app.command("dump-space")
def dump_space_contexts(
    slug: str = typer.Argument(..., help="Workspace slug"),
    exclude: Optional[list[str]] = typer.Option(None, "--exclude", "-e", help="Exclude contexts whose title contains this substring (repeatable)"),
):
    """Dump all context content for a workspace. Fetches feishu doc content inline."""
    async def _list():
        async with PmflowClient() as client:
            resp = await client.http.get(f"/workspaces/{slug}/contexts")
            resp.raise_for_status()
            return resp.json()

    contexts = run_async(_list())
    if exclude:
        contexts = [c for c in contexts if not any(kw in (c.get("title") or "") for kw in exclude)]
    if not contexts:
        console.print("No contexts found.", stderr=True)
        raise typer.Exit(1)
    _dump_contexts(contexts)


# ---------------------------------------------------------------------------
# Add doc commands (issue + space)
# ---------------------------------------------------------------------------


@app.command("add-doc")
def add_doc(
    seq_num: int = typer.Argument(..., help="Issue sequence number"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace slug"),
    title: str = typer.Option(..., "--title", "-t", help="Document title"),
    content: Optional[str] = typer.Option(None, "--content", "-c", help="Markdown content"),
    content_file: Optional[str] = typer.Option(None, "--content-file", help="Read content from file (use - for stdin)"),
):
    """Create or update a Feishu doc and link it to an issue."""
    slug = get_workspace(workspace)
    doc_content = _resolve_content(content, content_file)
    _add_doc_impl(
        feishu_api_path=f"/workspaces/{slug}/issues/{seq_num}/contexts/feishu",
        title=title,
        doc_content=doc_content,
    )


@app.command("add-space-doc")
def add_space_doc(
    slug: str = typer.Argument(..., help="Workspace slug"),
    title: str = typer.Option(..., "--title", "-t", help="Document title"),
    content: Optional[str] = typer.Option(None, "--content", "-c", help="Markdown content"),
    content_file: Optional[str] = typer.Option(None, "--content-file", help="Read content from file (use - for stdin)"),
):
    """Create or update a Feishu doc and link it to a workspace (space-level)."""
    doc_content = _resolve_content(content, content_file)
    _add_doc_impl(
        feishu_api_path=f"/workspaces/{slug}/contexts/feishu",
        title=title,
        doc_content=doc_content,
    )


# ---------------------------------------------------------------------------
# Placeholder commands
# ---------------------------------------------------------------------------


@app.command()
def show(ctx_id: str):
    """Show context details."""
    raise NotImplementedError


@app.command()
def remove(ctx_id: str):
    """Remove a context."""
    raise NotImplementedError
