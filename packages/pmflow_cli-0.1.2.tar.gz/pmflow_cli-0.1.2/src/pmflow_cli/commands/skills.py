"""Install/uninstall pmflow Claude Code skills to ~/.claude/commands/pmflow/."""

import shutil
from pathlib import Path

import typer
from rich.table import Table

from pmflow_cli.output import console

app = typer.Typer(help="Manage Claude Code skills")

SKILLS_SOURCE = Path(__file__).parent.parent / "skills"
COMMANDS_TARGET = Path.home() / ".claude" / "commands" / "pmflow"
SKILL_NAMES = ["plan-space", "plan-task", "prd", "prdfix", "snapshot-space"]

# Legacy install path (pre-v0.2), cleaned up on install/uninstall
_LEGACY_TARGET = Path.home() / ".claude" / "skills"


def _clean_legacy():
    """Remove skills installed to the old ~/.claude/skills/ location."""
    for name in SKILL_NAMES:
        legacy = _LEGACY_TARGET / f"pmflow-{name}"
        if legacy.exists():
            shutil.rmtree(legacy)


@app.command()
def install(
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skills"),
):
    """Install pmflow skills into ~/.claude/commands/pmflow/ for Claude Code."""
    if not SKILLS_SOURCE.exists():
        console.print("[red]Error:[/red] Skills source directory not found. Package may be corrupted.")
        raise typer.Exit(1)

    _clean_legacy()
    COMMANDS_TARGET.mkdir(parents=True, exist_ok=True)

    installed = []
    skipped = []

    for name in SKILL_NAMES:
        src = SKILLS_SOURCE / name / "SKILL.md"
        dst = COMMANDS_TARGET / f"{name}.md"

        if dst.exists() and not force:
            skipped.append(name)
            continue

        shutil.copy2(src, dst)
        installed.append(name)

    if installed:
        console.print(f"[green]Installed {len(installed)} skill(s):[/green] {', '.join(installed)}")
    if skipped:
        console.print(f"[yellow]Skipped {len(skipped)} (already exist):[/yellow] {', '.join(skipped)}")
        console.print("Use [bold]--force[/bold] to overwrite.")

    if installed:
        console.print("\n[dim]Skills are now available as /pmflow:plan-space, /pmflow:plan-task, /pmflow:prd, /pmflow:prdfix, /pmflow:snapshot-space in Claude Code.[/dim]")


@app.command()
def uninstall():
    """Remove pmflow skills from ~/.claude/commands/pmflow/."""
    _clean_legacy()

    removed = []
    for name in SKILL_NAMES:
        dst = COMMANDS_TARGET / f"{name}.md"
        if dst.exists():
            dst.unlink()
            removed.append(name)

    # Remove the pmflow directory if empty
    if COMMANDS_TARGET.exists() and not any(COMMANDS_TARGET.iterdir()):
        COMMANDS_TARGET.rmdir()

    if removed:
        console.print(f"[green]Removed {len(removed)} skill(s):[/green] {', '.join(removed)}")
    else:
        console.print("[dim]No pmflow skills found to remove.[/dim]")


@app.command(name="list")
def list_skills():
    """List pmflow skills and their install status."""
    table = Table(title="pmflow Claude Code Skills")
    table.add_column("Skill", style="bold")
    table.add_column("Command")
    table.add_column("Status")

    for name in SKILL_NAMES:
        dst = COMMANDS_TARGET / f"{name}.md"
        status = "[green]installed[/green]" if dst.exists() else "[dim]not installed[/dim]"
        table.add_row(name, f"/pmflow:{name}", status)

    console.print(table)
