import typer

app = typer.Typer(name="auth", help="Authentication commands")


@app.command()
def token():
    """Manage API tokens."""
    raise NotImplementedError
