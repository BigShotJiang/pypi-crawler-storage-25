import typer

from pmflow_cli.client import PmflowClient
from pmflow_cli.config import CliConfig
from pmflow_cli.output import console, print_table
from pmflow_cli.utils import run_async

app = typer.Typer(name="ws", help="Workspace management")


@app.command("list")
def list_workspaces():
    """List all workspaces."""

    async def _list():
        async with PmflowClient() as client:
            resp = await client.http.get("/workspaces")
            resp.raise_for_status()
            return resp.json()

    workspaces = run_async(_list())

    config = CliConfig.load()
    print_table(
        columns=["Slug", "Name", "Active"],
        rows=[
            [w.get("slug", ""), w.get("name", ""), "*" if w.get("slug") == config.workspace else ""]
            for w in workspaces
        ],
        title="Workspaces",
    )


@app.command()
def switch(slug: str):
    """Switch active workspace."""
    config = CliConfig.load()
    config.workspace = slug
    config.save()
    console.print(f"[green]Switched to workspace:[/green] {slug}")


@app.command()
def create(name: str):
    """Create a new workspace."""
    raise NotImplementedError


@app.command()
def show(slug: str | None = None):
    """Show workspace details."""
    raise NotImplementedError


@app.command()
def delete(slug: str):
    """Delete a workspace."""
    raise NotImplementedError
