import json
from typing import Optional

import typer
from pmflow_shared.enums import IssueStatus, IssueType

from pmflow_cli.client import PmflowClient
from pmflow_cli.output import console, print_table
from pmflow_cli.utils import get_workspace, run_async

app = typer.Typer(name="issue", help="Issue management")


@app.command("list")
def list_issues(
    status: IssueStatus | None = typer.Option(None, "--status", "-s", help="Filter by status"),
    type: IssueType | None = typer.Option(None, "--type", "-t", help="Filter by type"),
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace slug (overrides default)"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table or json"),
):
    """List issues in current workspace."""
    slug = get_workspace(workspace)

    async def _list():
        async with PmflowClient() as client:
            params: dict[str, str] = {}
            if status:
                params["status"] = status.value
            if type:
                params["type"] = type.value
            resp = await client.http.get(f"/workspaces/{slug}/issues", params=params)
            resp.raise_for_status()
            return resp.json()

    data = run_async(_list())

    issues = data.get("issues", [])
    done_total = data.get("done_total", 0)

    if format == "json":
        console.print_json(json.dumps(data))
        return

    if not issues:
        console.print("No issues found.")
        return

    print_table(
        columns=["#", "Type", "Status", "Priority", "Title"],
        rows=[
            [
                str(i["sequence_num"]),
                i["type"],
                i["status"],
                str(i["priority"]),
                i["title"],
            ]
            for i in issues
        ],
        title=f"Issues in {slug}",
    )
    if done_total > 0:
        console.print(f"[dim]({done_total} done issues total)[/dim]")


@app.command()
def create(
    title: str,
    type: IssueType = IssueType.TASK,
    priority: int = 0,
):
    """Create a new issue."""
    raise NotImplementedError


@app.command()
def show(seq_num: int):
    """Show issue details."""
    raise NotImplementedError


@app.command()
def update(seq_num: int):
    """Update an issue."""
    raise NotImplementedError


@app.command("status")
def set_status(
    seq_num: int,
    status: IssueStatus,
    workspace: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace slug (overrides default)"),
):
    """Change issue status."""
    slug = get_workspace(workspace)

    async def _update():
        async with PmflowClient() as client:
            resp = await client.http.patch(
                f"/workspaces/{slug}/issues/{seq_num}/status",
                json={"status": status.value},
            )
            resp.raise_for_status()
            return resp.json()

    run_async(_update())
    console.print(f"[green]Done![/green] {slug.upper()}-{seq_num} status → {status.value}")


@app.command()
def delete(seq_num: int):
    """Delete an issue."""
    raise NotImplementedError
