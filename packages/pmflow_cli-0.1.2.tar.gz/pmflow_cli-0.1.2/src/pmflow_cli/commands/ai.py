import typer

app = typer.Typer(name="ai", help="AI-assisted features")


@app.command()
def chat(seq_num: int):
    """Start interactive AI conversation for an issue."""
    raise NotImplementedError



@app.command()
def conversations(seq_num: int):
    """List AI conversations for an issue."""
    raise NotImplementedError
