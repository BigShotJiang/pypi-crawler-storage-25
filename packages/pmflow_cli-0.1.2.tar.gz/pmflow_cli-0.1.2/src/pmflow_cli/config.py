from pathlib import Path
from dataclasses import dataclass

try:
    import tomllib
except ImportError:
    import tomli as tomllib

import tomli_w

CONFIG_DIR = Path.home() / ".pmflow"
CONFIG_FILE = CONFIG_DIR / "config.toml"


@dataclass
class CliConfig:
    server_url: str = "http://localhost:8000"
    api_token: str = ""
    workspace: str = ""
    output_format: str = "table"

    @classmethod
    def load(cls) -> "CliConfig":
        if not CONFIG_FILE.exists():
            return cls()
        data = tomllib.loads(CONFIG_FILE.read_text())
        auth = data.get("auth", {})
        defaults = data.get("defaults", {})
        return cls(
            server_url=auth.get("server_url", cls.server_url),
            api_token=auth.get("api_token", cls.api_token),
            workspace=defaults.get("workspace", cls.workspace),
            output_format=defaults.get("output_format", cls.output_format),
        )

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "auth": {"server_url": self.server_url, "api_token": self.api_token},
            "defaults": {"workspace": self.workspace, "output_format": self.output_format},
        }
        CONFIG_FILE.write_text(tomli_w.dumps(data))
