# Lixinger Python SDK

[![PyPI version](https://badge.fury.io/py/lixinger-python.svg)](https://badge.fury.io/py/lixinger-python)
[![Python 3.13+](https://img.shields.io/badge/python-3.13+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

理杏仁（Lixinger）金融数据 API 的 Python 客户端库。

## ✨ 特性

- ⚡ **完全异步** - 基于 async/await，支持并发请求
- 🤖 **AI Agent 就绪** - 完美集成 LangChain、LlamaIndex
- 📊 **Pandas 集成** - 所有数据返回 DataFrame 格式，方便数据分析
- 🔒 **类型安全** - 完整的类型提示和 Pydantic 数据验证
- 🛡️ **稳定可靠** - 内置重试机制和错误处理
- 🎯 **全面覆盖** - 支持股票、指数、基金等多种数据类型
- 📓 **Jupyter 友好** - 原生支持 top-level await

## 📦 安装

```bash
# 使用 pip
pip install lixinger-python

# 使用 uv（推荐）
uv add lixinger-python
```

## 🚀 快速开始

### 1. 配置 API Key

创建 `.env` 文件并配置你的 API Key：

```bash
cp .env.example .env
```

编辑 `.env` 文件：

```env
LIXINGER_API_KEY=your_api_key_here
```

### 2. 使用示例（异步）

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    # 创建客户端（自动从 .env 加载配置）
    async with AsyncLixingerClient() as client:
        # 获取股票基本面数据
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001", "600000"],
            start_date="2023-01-01",
            end_date="2023-12-31",
            metrics=["pe", "pb", "roe"]
        )

        print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. Jupyter Notebook 使用

```python
# 在 Jupyter 中可以直接使用 await
from lixinger import AsyncLixingerClient

client = AsyncLixingerClient()
df = await client.company.company.get_company(stock_codes=["000001"])
df
```

## 📚 主要功能

### 股票数据

- **基本面数据** - 获取股票的财务指标和估值数据
- **K线数据** - 获取不同周期的行情数据
- **财务报表** - 获取详细的财务报表数据
- **公告数据** - 获取公司公告信息
- **分红数据** - 获取分红派息记录

### 指数数据

- **指数信息** - 查询指数基本信息
- **成分股** - 获取指数成分股列表
- **K线数据** - 获取指数历史行情
- **基本面数据** - 获取指数整体估值指标
- **回撤分析** - 分析指数历史回撤情况

### 基金数据

- **基金信息** - 查询基金基本信息
- **净值数据** - 获取基金净值走势
- **持仓数据** - 查看基金持仓明细
- **资产组合** - 分析基金资产配置
- **公告信息** - 获取基金公告

## 📖 文档

- [快速开始](getting-started/quickstart.md)
- [API 参考](api/overview.md)
- [使用示例](examples/company.md)
- [开发指南](development/contributing.md)

## 🔗 相关链接

- [理杏仁官网](https://www.lixinger.com/)
- [API 文档](https://www.lixinger.com/open/api/doc)
- [GitHub 仓库](https://github.com/TedaLIEz/lixinger-python)
- [问题反馈](https://github.com/TedaLIEz/lixinger-python/issues)

## 📄 许可证

本项目采用 MIT 许可证。详见 [LICENSE](https://github.com/TedaLIEz/lixinger-python/blob/main/LICENSE) 文件。

## 🙏 致谢

感谢 [理杏仁](https://www.lixinger.com/) 提供优质的金融数据服务。
