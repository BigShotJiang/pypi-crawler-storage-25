# 测试指南

本页面介绍如何为 Lixinger Python SDK 编写和运行测试。

详细内容请参考项目根目录的 `TESTING_GUIDE.md`。
