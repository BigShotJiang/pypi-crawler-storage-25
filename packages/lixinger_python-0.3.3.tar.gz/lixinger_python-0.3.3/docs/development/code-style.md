# 代码规范

本页面介绍 Lixinger Python SDK 的代码风格和规范。

详细内容请参考项目根目录的 `CLAUDE.md`。
