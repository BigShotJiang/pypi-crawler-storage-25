# 股票数据示例

本页面展示如何使用 Lixinger SDK 获取和分析股票数据。

## ⚠️ 提示

所有 API 都是异步的，需要使用 `async`/`await`。

## 基本示例

### 获取基本面数据

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取多只股票的基本面数据
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001", "600036", "601398"],
            date="2023-12-31",
            metrics=["pe", "pb", "roe", "roa"]
        )

        print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

### 并发查询多只股票

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 并发查询，比同步快很多！
        tasks = [
            client.company.company.get_company(stock_codes=["000001"]),
            client.company.company.get_company(stock_codes=["600036"]),
            client.company.company.get_company(stock_codes=["601398"]),
        ]
        results = await asyncio.gather(*tasks)

        for df in results:
            print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

更多示例正在完善中...
