# 配置

本页面介绍如何配置 Lixinger Python SDK。

## 环境变量配置

Lixinger SDK 使用环境变量进行配置。推荐使用 `.env` 文件管理配置。

### 创建配置文件

```bash
# 1. 复制模板文件
cp .env.example .env

# 2. 编辑 .env 文件
nano .env  # 或使用你喜欢的编辑器
```

### 必需配置

#### LIXINGER_API_KEY

**说明**: 你的理杏仁 API Key

**获取方式**:

1. 访问 [理杏仁官网](https://www.lixinger.com/)
2. 注册并登录账号
3. 进入「个人中心」→「API Key 管理」
4. 创建或查看你的 API Key

**配置示例**:

```env
LIXINGER_API_KEY=your_api_key_here_1234567890abcdef
```

!!! danger "重要提示"
    - **永远不要**将 API Key 硬编码在代码中
    - **永远不要**将 `.env` 文件提交到 Git
    - **永远不要**在公开场合分享你的 API Key

### 可选配置

#### LIXINGER_BASE_URL

**说明**: API 基础 URL

**默认值**: `https://open.lixinger.com/api`

**使用场景**: 使用私有部署或测试环境

```env
LIXINGER_BASE_URL=https://your-custom-domain.com/api
```

#### LIXINGER_TIMEOUT

**说明**: 请求超时时间（秒）

**默认值**: `30.0`

**使用场景**: 查询大量数据时可能需要更长的超时时间

```env
LIXINGER_TIMEOUT=60.0
```

#### LIXINGER_MAX_RETRIES

**说明**: 请求失败时的最大重试次数

**默认值**: `3`

**使用场景**: 网络不稳定时可以增加重试次数

```env
LIXINGER_MAX_RETRIES=5
```

#### LIXINGER_PROXY

**说明**: 代理服务器地址

**默认值**: `None`

**支持的代理类型**:

- HTTP 代理: `http://host:port`
- HTTPS 代理: `https://host:port`
- SOCKS5 代理: `socks5://host:port`

**使用场景**: 需要通过代理访问 API

```env
# HTTP 代理
LIXINGER_PROXY=http://proxy.example.com:8080

# SOCKS5 代理（支持科学上网）
LIXINGER_PROXY=socks5://127.0.0.1:1080
```

#### LIXINGER_MAX_REQUESTS_PER_MINUTE

**说明**: 每分钟最大请求数（速率限制）

**默认值**: `1000`

**使用场景**: 根据你的 API 套餐限制调整

```env
LIXINGER_MAX_REQUESTS_PER_MINUTE=500
```

## 完整配置示例

以下是一个包含所有配置项的 `.env` 文件示例：

```env
# ============================================
# Lixinger Python SDK Configuration
# ============================================

# API Key（必需）
LIXINGER_API_KEY=your_api_key_here

# API 基础 URL（可选）
LIXINGER_BASE_URL=https://open.lixinger.com/api

# 请求超时（秒）
LIXINGER_TIMEOUT=30.0

# 最大重试次数
LIXINGER_MAX_RETRIES=3

# 代理设置（可选）
# LIXINGER_PROXY=socks5://127.0.0.1:1080

# 速率限制（每分钟请求数）
LIXINGER_MAX_REQUESTS_PER_MINUTE=1000
```

## 代码中的配置

除了环境变量，你也可以在创建客户端时传入配置参数：

```python
from lixinger import LixingerClient

# 使用自定义配置
client = LixingerClient(
    timeout=60.0,
    max_retries=5,
    proxy="socks5://localhost:1080",
    max_requests_per_minute=500
)
```

!!! warning "API Key 例外"
    注意：`api_key` **不能**作为参数传递，必须通过 `.env` 文件配置。这是为了防止意外泄露敏感信息。

## 配置优先级

配置的加载顺序（优先级从高到低）：

1. **代码中传入的参数** - `LixingerClient(timeout=60.0)`
2. **环境变量** - `.env` 文件中的配置
3. **默认值** - SDK 内置的默认配置

示例：

```python
# .env 文件
LIXINGER_TIMEOUT=30.0

# Python 代码
client = LixingerClient(timeout=60.0)

# 实际使用的 timeout 是 60.0（代码参数优先）
```

## 不同环境的配置

### 开发环境

```env
# .env.development
LIXINGER_API_KEY=dev_api_key
LIXINGER_TIMEOUT=60.0
LIXINGER_MAX_RETRIES=5
```

### 生产环境

```env
# .env.production
LIXINGER_API_KEY=prod_api_key
LIXINGER_TIMEOUT=30.0
LIXINGER_MAX_RETRIES=3
LIXINGER_MAX_REQUESTS_PER_MINUTE=500
```

### 加载不同环境配置

```python
from dotenv import load_dotenv
import os

# 根据环境变量决定加载哪个配置文件
env = os.getenv("ENV", "development")
load_dotenv(f".env.{env}")

from lixinger import LixingerClient
client = LixingerClient()
```

## 验证配置

创建一个简单的脚本来验证你的配置：

```python
"""验证 Lixinger SDK 配置."""

from lixinger import LixingerClient

try:
    # 创建客户端
    client = LixingerClient()

    # 尝试获取数据
    df = client.index.index.get_index(stock_codes=["000300"])

    if not df.empty:
        print("✅ 配置验证成功！")
        print(f"✅ 成功获取 {len(df)} 条数据")
        print(f"✅ 指数信息: {df['stockName'].iloc[0]}")
    else:
        print("⚠️ 配置可能有问题：返回数据为空")

except Exception as e:
    print(f"❌ 配置验证失败: {e}")
    print("\n请检查：")
    print("1. .env 文件是否存在")
    print("2. LIXINGER_API_KEY 是否正确")
    print("3. 网络连接是否正常")
```

保存为 `verify_config.py` 并运行：

```bash
uv run python verify_config.py
```

## 安全最佳实践

### ✅ 推荐做法

1. **使用 .env 文件管理敏感信息**

   ```bash
   # 确保 .env 在 .gitignore 中
   echo ".env" >> .gitignore
   ```

2. **提供 .env.example 模板**

   ```env
   # .env.example
   LIXINGER_API_KEY=your_api_key_here
   LIXINGER_TIMEOUT=30.0
   ```

3. **使用不同的 API Key**
   - 开发环境使用测试 Key
   - 生产环境使用正式 Key

4. **定期轮换 API Key**
   - 建议每 3-6 个月更换一次

### ❌ 避免的做法

1. ❌ 将 API Key 硬编码在代码中

   ```python
   # 不要这样做！
   client = LixingerClient(api_key="hardcoded_key")
   ```

2. ❌ 将 .env 文件提交到 Git

   ```bash
   # 检查是否意外提交
   git status
   ```

3. ❌ 在公开场合分享 API Key
   - 不要在 GitHub Issues 中贴出完整 Key
   - 不要在博客文章中展示真实 Key

## 常见问题

### Q: 为什么我的配置没有生效？

A: 请检查：

1. `.env` 文件是否在正确的位置（项目根目录）
2. 环境变量名是否拼写正确（区分大小写）
3. 是否重启了 Python 进程

### Q: 可以在 Docker 中使用吗？

A: 可以。推荐使用 Docker 的环境变量传递：

```dockerfile
# Dockerfile
FROM python:3.13

# 安装依赖
COPY requirements.txt .
RUN pip install -r requirements.txt

# 复制代码
COPY . /app
WORKDIR /app

# 运行时传入环境变量
CMD ["python", "main.py"]
```

```bash
# docker-compose.yml
services:
  app:
    build: .
    env_file:
      - .env
```

### Q: 如何在 CI/CD 中配置？

A: 使用 CI 平台的 Secret 功能：

```yaml
# GitHub Actions 示例
name: Test
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    env:
      LIXINGER_API_KEY: ${{ secrets.LIXINGER_API_KEY }}
    steps:
      - uses: actions/checkout@v2
      - name: Run tests
        run: pytest
```

## 下一步

- 🚀 [开始使用 SDK](quickstart.md)
- 📚 查看 [API 文档](../api/overview.md)
- 💡 浏览 [使用示例](../examples/company.md)
