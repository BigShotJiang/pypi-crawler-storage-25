# 安装

本页面介绍如何安装 Lixinger Python SDK。

## 系统要求

- **Python**: 3.13 或更高版本
- **操作系统**: Windows、macOS、Linux

## 安装方式

### 方式 1: 使用 pip（推荐）

最简单的安装方式：

```bash
pip install lixinger-python
```

### 方式 2: 使用 uv（更快）

[uv](https://github.com/astral-sh/uv) 是一个极快的 Python 包管理器：

```bash
# 安装 uv（如果还没有安装）
curl -LsSf https://astral.sh/uv/install.sh | sh

# 使用 uv 安装
uv add lixinger-python
```

### 方式 3: 从源码安装

如果你想使用最新的开发版本：

```bash
# 克隆仓库
git clone https://github.com/TedaLIEz/lixinger-python.git
cd lixinger-python

# 使用 uv 安装依赖
uv sync

# 或使用 pip
pip install -e .
```

## 验证安装

安装完成后，可以验证是否成功：

```python
# 启动 Python
python

# 导入并检查版本
>>> from lixinger import __version__
>>> print(__version__)
0.1.0

>>> from lixinger import LixingerClient
>>> # 如果没有报错，说明安装成功！
```

## 依赖项

Lixinger Python SDK 依赖以下核心库：

- **httpx** - 高性能 HTTP 客户端（支持 SOCKS 代理）
- **pandas** - 数据分析库
- **pydantic** - 数据验证库
- **python-dotenv** - 环境变量管理

这些依赖会在安装时自动安装。

## 可选依赖

如果需要数据可视化功能，可以额外安装：

```bash
# 安装可视化依赖
pip install matplotlib seaborn

# 或使用 uv
uv add matplotlib seaborn
```

## 下一步

安装完成后：

1. 📝 [配置 API Key](configuration.md)
2. 🚀 [快速入门](quickstart.md)
3. 📚 查看 [API 文档](../api/overview.md)

## 遇到问题？

### 问题 1: pip 安装失败

如果遇到权限错误：

```bash
# 使用用户安装
pip install --user lixinger-python

# 或使用虚拟环境（推荐）
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install lixinger-python
```

### 问题 2: Python 版本过低

检查你的 Python 版本：

```bash
python --version
```

如果版本低于 3.13，需要升级 Python：

- **macOS**: `brew install python@3.13`
- **Ubuntu**: `sudo apt install python3.13`
- **Windows**: 从 [python.org](https://www.python.org/downloads/) 下载安装

### 问题 3: 网络问题

如果在中国大陆安装很慢，可以使用国内镜像：

```bash
# 使用清华镜像
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple lixinger-python
```

### 更多帮助

- 查看 [GitHub Issues](https://github.com/TedaLIEz/lixinger-python/issues)
- 提交 [Bug 报告](https://github.com/TedaLIEz/lixinger-python/issues/new)
