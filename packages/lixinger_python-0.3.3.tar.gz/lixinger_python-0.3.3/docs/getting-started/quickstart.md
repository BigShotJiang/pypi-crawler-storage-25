# 快速入门

本指南将帮助你快速开始使用 Lixinger Python SDK。

## ⚠️ 重要提示

**本 SDK 采用完全异步架构**，所有 API 调用都需要使用 `async`/`await`。

## 前提条件

在开始之前，确保你已经：

1. ✅ 安装了 Python 3.13 或更高版本
2. ✅ 注册了 [理杏仁账号](https://www.lixinger.com/) 并获取了 API Key
3. ✅ 安装了 Lixinger Python SDK

如果还没有安装，请查看 [安装指南](installation.md)。

## 🚀 五分钟快速上手

### 1. 配置 API Key

创建 `.env` 文件并添加你的 API Key：

```bash
# 复制模板文件
cp .env.example .env

# 编辑 .env 文件，添加你的 API Key
# LIXINGER_API_KEY=your_api_key_here
```

!!! warning "安全提示"
    **永远不要**将 `.env` 文件提交到版本控制系统！该文件已被添加到 `.gitignore`。

### 2. 创建客户端（异步）

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    # 创建客户端（自动从 .env 加载配置）
    async with AsyncLixingerClient() as client:
        # 在这里进行 API 调用
        pass

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. 获取数据

现在你可以开始获取数据了！

#### 示例 1：获取股票基本面数据

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取平安银行和招商银行的基本面数据
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001", "600036"],
            start_date="2023-01-01",
            end_date="2023-12-31",
            metrics=["pe", "pb", "roe"]
        )

        print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

输出示例：

```
  stockCode        date     pe     pb    roe
0    000001  2023-12-31  5.23  0.67  12.8
1    600036  2023-12-31  4.85  0.89  14.2
...
```

#### 示例 2：获取指数信息

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取沪深300和中证500的信息
        df = await client.cn_index.get_index(
            stock_codes=["000300", "000905"]
        )

        print(df[["stockCode", "stockName", "source"]])

if __name__ == "__main__":
    asyncio.run(main())
```

#### 示例 3：获取基金持仓

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取基金的最近4期持仓
        df = await client.cn_fund_shareholdings.get_shareholdings(
            stock_code="000001",
            start_date="2023-01-01",
            limit=4
        )

        print(df.head())

if __name__ == "__main__":
    asyncio.run(main())
```

## 📊 数据格式

所有 API 方法都返回 **Pandas DataFrame** 格式，这让数据分析变得非常简单：

```python
import asyncio
import pandas as pd
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取数据
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001"],
            start_date="2023-01-01",
            end_date="2023-12-31",
            metrics=["pe", "pb", "roe"]
        )

        # Pandas 操作
        print(df.head())          # 查看前几行
        print(df.describe())      # 统计信息
        print(df["pe"].mean())    # 计算平均市盈率

        # 数据可视化
        df.plot(x="date", y="pe", kind="line")

if __name__ == "__main__":
    asyncio.run(main())
```

## 🎯 常见使用场景

### 场景 1：多只股票对比

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取多只股票的PE对比
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001", "600000", "600036"],
            date="2023-12-31",
            metrics=["pe", "pb"]
        )

        # 按PE排序
        df_sorted = df.sort_values("pe")
        print(df_sorted)

if __name__ == "__main__":
    asyncio.run(main())
```

### 场景 2：时间序列分析

```python
import asyncio
import matplotlib.pyplot as plt
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取某只股票的历史估值
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001"],
            start_date="2020-01-01",
            end_date="2023-12-31",
            metrics=["pe", "pb"]
        )

        # 绘制PE走势图
        plt.figure(figsize=(12, 6))
        plt.plot(df["date"], df["pe"])
        plt.title("平安银行 PE 走势")
        plt.xlabel("日期")
        plt.ylabel("PE")
        plt.show()

if __name__ == "__main__":
    asyncio.run(main())
```

### 场景 3：指数成分股分析

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 获取沪深300成分股
        constituents = await client.cn_index_constituents.get_constituents(
            stock_codes=["000300"],
            date="2023-12-31"
        )

        # 获取前10大权重股
        top10 = constituents.nlargest(10, "weight")
        print(top10[["stockCode", "stockName", "weight"]])

if __name__ == "__main__":
    asyncio.run(main())
```

### 场景 4：并发查询多只股票（异步优势）

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        # 并发查询多只股票 - 比同步快得多！
        tasks = [
            client.company.company.get_company(stock_codes=["000001"]),
            client.company.company.get_company(stock_codes=["600036"]),
            client.company.company.get_company(stock_codes=["600000"]),
        ]
        results = await asyncio.gather(*tasks)

        for df in results:
            print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

## ⚙️ 客户端配置

你可以在创建客户端时自定义配置：

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient(
        timeout=60.0,                          # 请求超时（秒）
        max_retries=5,                         # 最大重试次数
        proxy="socks5://localhost:1080",       # 代理设置
        max_requests_per_minute=500            # 速率限制
    ) as client:
        df = await client.company.company.get_company(stock_codes=["000001"])
        print(df)

if __name__ == "__main__":
    asyncio.run(main())
```

!!! note "API Key 来源"
    注意：API Key **只能**从 `.env` 文件加载，不能作为参数传递。这是为了防止意外泄露。

## 📓 Jupyter Notebook 使用

在 Jupyter Notebook 中，你可以直接使用 `await`（无需 `asyncio.run()`）：

```python
# 在 Jupyter cell 中
from lixinger import AsyncLixingerClient

client = AsyncLixingerClient()
df = await client.company.company.get_company(stock_codes=["000001"])
df
```

## 🔍 下一步

现在你已经掌握了基础用法，可以：

- 📚 查看完整的 [API 参考文档](../api/overview.md)
- 💡 浏览更多 [使用示例](../examples/company.md)
- ⚙️ 了解 [高级配置](configuration.md)

## ❓ 遇到问题？

- 查看 [配置指南](configuration.md) 了解详细的环境变量设置
- 阅读 [FAQ](../development/contributing.md) 了解常见问题
- 在 [GitHub Issues](https://github.com/TedaLIEz/lixinger-python/issues) 提问

## 📝 完整示例

这是一个完整的示例脚本：

```python
"""示例：分析沪深300成分股的估值分布."""

import asyncio
from lixinger import AsyncLixingerClient
import pandas as pd
import matplotlib.pyplot as plt

async def main():
    # 初始化客户端
    async with AsyncLixingerClient() as client:
        # 1. 获取沪深300成分股
        print("正在获取沪深300成分股...")
        constituents = await client.cn_index_constituents.get_constituents(
            stock_codes=["000300"],
            date="2023-12-31"
        )

        # 获取前50大权重股的代码
        top50_codes = constituents.nlargest(50, "weight")["stockCode"].tolist()

        # 2. 获取这些股票的基本面数据
        print(f"正在获取 {len(top50_codes)} 只股票的基本面数据...")
        fundamental = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=top50_codes,
            date="2023-12-31",
            metrics=["pe", "pb", "roe"]
        )

        # 3. 数据分析
        print("\n估值统计：")
        print(fundamental[["pe", "pb", "roe"]].describe())

        # 4. 可视化
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))

        fundamental["pe"].hist(bins=20, ax=axes[0])
        axes[0].set_title("PE 分布")
        axes[0].set_xlabel("PE")

        fundamental["pb"].hist(bins=20, ax=axes[1])
        axes[1].set_title("PB 分布")
        axes[1].set_xlabel("PB")

        fundamental["roe"].hist(bins=20, ax=axes[2])
        axes[2].set_title("ROE 分布")
        axes[2].set_xlabel("ROE (%)")

        plt.tight_layout()
        plt.savefig("valuation_analysis.png")
        print("\n图表已保存为 valuation_analysis.png")

if __name__ == "__main__":
    asyncio.run(main())
```

运行这个脚本后，你将得到沪深300前50大权重股的估值分析报告和可视化图表！
