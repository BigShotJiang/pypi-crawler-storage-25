# 资产组合

获取基金资产组合数据。

## API 端点

`POST /cn/fund/asset-combination`

## 类参考

::: lixinger.api.cn.fund.asset_combination.FundAssetCombinationAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_asset_combination

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_asset_combination.get_asset_combination(
            stock_code="000001",
            start_date="2023-01-01",
            limit=4
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_asset_combination(
        stock_code="000001",
        start_date="2023-01-01",
        limit=4
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/fund/asset-combination)
