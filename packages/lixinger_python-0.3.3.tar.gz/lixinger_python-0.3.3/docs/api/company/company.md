# 公司信息

获取股票的详细信息。

## API 端点

`POST /cn/company`

## 类参考

::: lixinger.api.cn.company.company.CompanyAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_company

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.company.get_company(
            stock_codes=["000001", "600036"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_company(stock_codes=["000001", "600036"])
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company)
