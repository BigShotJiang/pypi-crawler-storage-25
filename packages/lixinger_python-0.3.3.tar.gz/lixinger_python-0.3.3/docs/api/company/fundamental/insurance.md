# 保险企业基本面

获取保险企业的基本面指标数据。

## API 端点

`POST /cn/company/fundamental/insurance`

## 类参考

::: lixinger.api.cn.company.fundamental.insurance.InsuranceFundamentalAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_insurance_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.insurance.get_insurance_fundamental(
            stock_codes=["601318", "601336"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_insurance_fundamental(
        stock_codes=["601318", "601336"],
        metrics=["pe_ttm", "pb"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/insurance)
