# 财务报表

获取非金融企业的详细财务报表数据。

## API 端点

`POST /cn/company/fs/non_financial`

## 类参考

::: lixinger.api.cn.company.fs.non_financial.NonFinancialStatementAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_non_financial_statements

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fs.non_financial.get_non_financial_statements(
            stock_codes=["000001", "600000"],
            metrics=["revenue", "profit", "assets", "debt"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_non_financial_statements(
        stock_codes=["000001", "600000"],
        metrics=["revenue", "profit"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company/fs/non_financial)
