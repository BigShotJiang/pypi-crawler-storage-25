# K线数据

获取股票的K线（蜡烛图）数据。

## API 端点

`POST /cn/company/candlestick`

## 类参考

::: lixinger.api.cn.company.candlestick.CandlestickAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_candlestick

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.candlestick.get_candlestick(
            type="1d",
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31",
            adjust_type="hxw"  # 后复权
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_candlestick(
        type="1d",
        stock_code="000001",
        start_date="2023-01-01",
        end_date="2023-12-31",
        adjust_type="hxw"
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company/candlestick)
