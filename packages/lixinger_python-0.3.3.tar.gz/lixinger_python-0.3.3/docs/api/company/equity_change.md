# 股本变动

获取公司的股本变动历史信息。

## API 端点

`POST /cn/company/equity-change`

## 类参考

::: lixinger.api.cn.company.equity_change.EquityChangeAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_equity_change

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.equity_change.get_equity_change(
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_equity_change(
        stock_code="000001",
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company/equity-change)
