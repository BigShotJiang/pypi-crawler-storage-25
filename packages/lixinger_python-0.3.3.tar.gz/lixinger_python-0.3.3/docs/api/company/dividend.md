# 分红

获取公司分红数据。

## API 端点

`POST /cn/company/dividend`

## 类参考

::: lixinger.api.cn.company.dividend.DividendAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient

async def example():
    async with AsyncLixingerClient() as client:
        df = await client.company.dividend.get_dividend(
            stock_code="000001",
            start_date="2020-01-01",
            end_date="2023-12-31"
        )
        print(df)

asyncio.run(example())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/company/dividend)
