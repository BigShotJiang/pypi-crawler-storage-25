# 基本面数据

获取指数整体基本面数据。

## API 端点

`POST /cn/index/fundamental`

## 类参考

::: lixinger.api.cn.index.fundamental.IndexFundamentalAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

```python
import asyncio
from lixinger import AsyncLixingerClient, get_index_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_fundamental.get_fundamental(
            stock_codes=["000300", "000905"],
            metrics=["pe", "pb", "roe"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_index_fundamental(
        stock_codes=["000300", "000905"],
        metrics=["pe", "pb", "roe"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```

## 相关链接

- [官方文档](https://www.lixinger.com/open/api/doc?api-key=cn/index/fundamental)
