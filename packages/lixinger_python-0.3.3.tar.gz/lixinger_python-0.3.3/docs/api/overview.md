# API 概览

本页面提供 Lixinger Python SDK 所有 API 的快速参考。

## 📊 API 统计

当前已实现 **27 个 API 接口**：

| 模块 | API 数量 | 占比 |
|------|----------|------|
| 股票（Company） | 13 | 48.1% |
| 指数（Index） | 7 | 25.9% |
| 基金（Fund） | 7 | 25.9% |

## 🏢 股票相关 API

### 公司信息

- [`get_company()`](company/company.md) - 股票详细信息
- [`get_profile()`](company/profile.md) - 公司概况
- [`get_equity_change()`](company/equity_change.md) - 股本变动

### 基本面数据

获取股票的财务指标和估值数据。

- [`get_non_financial_fundamental()`](company/fundamental/non_financial.md) - 非金融企业基本面
- [`get_bank_fundamental()`](company/fundamental/bank.md) - 银行基本面
- [`get_insurance_fundamental()`](company/fundamental/insurance.md) - 保险企业基本面
- [`get_security_fundamental()`](company/fundamental/security.md) - 证券企业基本面
- [`get_other_financial_fundamental()`](company/fundamental/other_financial.md) - 其他金融企业基本面

### 行情数据

- [`get_candlestick()`](company/candlestick.md) - K线数据

### 其他数据

- [`get_indices()`](company/indices.md) - 所属指数
- [`get_non_financial_statements()`](company/fs/non_financial.md) - 财务报表
- [`get_announcement()`](company/announcement.md) - 公告
- [`get_dividend()`](company/dividend.md) - 分红

## 📈 指数相关 API

### 基本信息

- [`get_index()`](index/index.md) - 指数信息
- [`get_constituents()`](index/constituents.md) - 成分股列表
- [`get_constituent_weightings()`](index/constituent_weightings.md) - 成分股权重

### 行情数据

- [`get_candlestick()`](index/candlestick.md) - K线数据
- [`get_fundamental()`](index/fundamental.md) - 基本面数据

### 分析数据

- [`get_drawdown()`](index/drawdown.md) - 回撤数据

## 💼 基金相关 API

### 基本信息

- [`get_fund()`](fund/fund.md) - 基金信息
- [`get_profile()`](fund/profile.md) - 基金概况

### 净值数据

- [`get_candlestick()`](fund/candlestick.md) - K线数据

### 持仓数据

- [`get_shareholdings()`](fund/shareholdings.md) - 股票持仓
- [`get_asset_combination()`](fund/asset_combination.md) - 资产组合
- [`get_asset_industry_combination()`](fund/asset_industry_combination.md) - 行业组合

### 其他数据

- [`get_announcement()`](fund/announcement.md) - 公告

## 🎯 快速导航

### 按功能分类

=== "基本面/基础信息"
    - 股票基本面数据
    - 指数信息
    - 基金信息
    - 基金概况

=== "K线/行情数据"
    - 股票K线
    - 指数K线
    - 基金净值

=== "组合/持仓数据"
    - 基金持仓
    - 资产组合
    - 行业组合
    - 成分股

=== "公告数据"
    - 股票公告
    - 基金公告

=== "其他"
    - 分红数据
    - 回撤数据
    - 财务报表
    - 所属指数

## 💡 使用提示

!!! tip "返回格式"
    所有 API 方法都返回 Pandas DataFrame 格式，方便进行数据分析和可视化。

!!! info "认证方式"
    所有 API 都需要在 `.env` 文件中配置 `LIXINGER_API_KEY`。

!!! warning "速率限制"
    API 默认限制为每分钟 1000 次请求。超过限制会收到 429 错误。

## 📝 通用参数说明

大多数 API 都支持以下常见参数：

| 参数 | 类型 | 说明 |
|------|------|------|
| `stock_codes` | `list[str]` | 股票/指数/基金代码列表 |
| `stock_code` | `str` | 单个代码 |
| `start_date` | `str` | 开始日期 (YYYY-MM-DD) |
| `end_date` | `str` | 结束日期 (YYYY-MM-DD) |
| `date` | `str` | 指定日期 (YYYY-MM-DD) |
| `metrics` | `list[str]` | 指标列表 |
| `limit` | `int` | 限制返回数量 |

## 🔄 下一步

- 查看 [快速开始](../getting-started/quickstart.md) 了解基本用法
- 浏览 [使用示例](../examples/company.md) 查看实际代码
- 参考详细的 [API 文档](client.md) 了解每个方法的具体用法
