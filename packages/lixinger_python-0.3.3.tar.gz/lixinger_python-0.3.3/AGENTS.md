# AGENTS.md

Instructions for LLM agents implementing the Lixinger API Python SDK.

## Core References

- **API Docs**: <https://www.lixinger.com/open/api/doc>
- **Code Examples**: See `lixinger/api/` and `lixinger/models/` for patterns

## Architecture

**⚠️ IMPORTANT: This SDK is fully async/await based.**

- All API methods are `async def` and must be awaited
- Uses `httpx.AsyncClient` for non-blocking I/O
- Perfect for AI agents, Jupyter notebooks, and async web frameworks

## Critical: API Response Format

All responses follow this format:

```json
{
  "code": 1,           // 1 = success
  "message": "success",
  "data": [...]        // Return this to users
}
```

**Requirements:**
- Validate `code == 1` AND `message == "success"`
- `BaseAPI._request()` returns only `data` field (unwrapped)
- Raise `APIError` if validation fails
- Mock with full `{code, message, data}` format in tests

## Configuration

**API Key:** ALWAYS from environment variable `LIXINGER_API_KEY`. Cannot be passed as parameter.

```python
# ✅ Correct
client = AsyncLixingerClient()

# ❌ Wrong - will raise TypeError
client = AsyncLixingerClient(api_key="key")
```

**Optional env vars:** `LIXINGER_BASE_URL`, `LIXINGER_TIMEOUT`, `LIXINGER_MAX_RETRIES`, `LIXINGER_PROXY`, `LIXINGER_MAX_REQUESTS_PER_MINUTE`

## File Organization

**CRITICAL**: API endpoint path = file path

| API Documentation URL | API Endpoint | File Location | Model Location |
|-----------------------|--------------|---------------|----------------|
| `api-key=cn/company` | `/cn/company` | `lixinger/api/cn/company/` | `lixinger/models/cn/company/` |
| `api-key=cn/index` | `/cn/index` | `lixinger/api/cn/index/` | `lixinger/models/cn/index/` |
| `api-key=cn/company/equity-change` | `/cn/company/equity-change` | `lixinger/api/cn/company/equity_change.py` | `lixinger/models/cn/company/equity_change.py` |

**Naming:**
- Files: `snake_case` (e.g., `equity-change` → `equity_change.py`)
- Classes: `PascalCase` (e.g., `EquityChangeAPI`)

**Structure:**

```text
lixinger/
├── api/cn/{endpoint}/      # API implementations
└── models/cn/{endpoint}/   # Pydantic models (mirrors api/)
```

## Implementation Workflow

### 1. Study API Documentation (MANDATORY)

**⚠️ CRITICAL: Always start by reading the official API documentation at <https://www.lixinger.com/open/api/doc>**

Before writing ANY code:

1. **Navigate to the specific endpoint** you're implementing
2. **Document exactly what you find:**
   - Request parameters (names, types, required/optional)
   - Response structure (field names, types, nested objects)
   - Default values and constraints
   - Examples provided in the documentation

3. **Save a reference copy** of the documentation section for validation

**❌ NEVER:**
- Implement based on assumptions or guesses
- Skip reading the documentation
- Deviate from documented parameter names or types
- Add undocumented parameters or fields

**✅ ALWAYS:**
- Match parameter names exactly as documented
- Use exact types as specified in the API docs
- Follow documented constraints (min/max values, enums, etc.)
- Implement all documented fields (including optional ones)

### 2. Test API with curl (VERIFY BEHAVIOR)

```bash
# Load env
source .env

# Test endpoint with parameters from documentation
curl -X POST https://open.lixinger.com/api/cn/company \
  -H "Content-Type: application/json" \
  -H "Accept-Encoding: gzip, deflate, br" \
  -d "{\"token\": \"$LIXINGER_API_KEY\", \"stockCode\": [\"000001\"]}"
```

**Important:**
- Use parameters EXACTLY as shown in API documentation
- Save the raw response for reference
- Verify the response structure matches documentation
- Test edge cases (empty lists, null values, etc.)

### 3. Implement in Python (STRICT COMPLIANCE)

**File locations:**
- Extract endpoint from `api-key=` parameter in docs URL
- Map to: `lixinger/api/<endpoint>/` and `lixinger/models/<endpoint>/`

**Create:**

1. **Pydantic models** (`lixinger/models/cn/{endpoint}/`)
   - Model the unwrapped `data` field
   - **MUST match API documentation field names exactly** (case-sensitive!)
   - **MUST use correct types as documented** (str, int, float, list, etc.)
   - **Include ALL documented fields** (mark optional with `Optional[T]` or `T | None`)
   - Add field descriptions from API docs as docstrings
   - Add `__init__.py` with exports

2. **API class** (`lixinger/api/cn/{endpoint}/`)
   - Inherit from `BaseAPI`
   - **All methods MUST be async** (`async def`)
   - **Method parameters MUST match API documentation exactly**
   - Add docstring with:
     - Endpoint URL
     - Link to API documentation
     - Parameter descriptions from docs
   - Use proper type hints (match API docs)
   - **Validate parameters against documented constraints**
   - All API calls use `await self._request(...)`
   - Add `__init__.py` with exports

3. **Integrate**
   - Add to `AsyncLixingerClient` in `client.py`
   - Export in `lixinger/__init__.py`

**Compliance Checklist:**
- [ ] All parameter names match API docs exactly
- [ ] All parameter types match API docs exactly
- [ ] All response fields match API docs exactly
- [ ] Optional parameters are correctly marked
- [ ] Default values match API docs (if specified)
- [ ] Constraints are validated (enums, ranges, etc.)
- [ ] Documentation links included in docstrings

### 3. Add Tests

**Unit tests** (`tests/test_*.py`):
- **All test functions MUST be async** (`async def test_...()`)
- Add `@pytest.mark.asyncio` decorator to all async tests
- Use `await` for all API calls
- Mock with full `{code, message, data}` format
- Mock `_request` as async: `async def mock_request(...)`
- Test success, errors, edge cases
- Use `monkeypatch.setenv("LIXINGER_API_KEY", "test_key")`

**Integration tests** (`tests/test_integration.py`):
- Mark with `@pytest.mark.integration`
- Use `async with AsyncLixingerClient() as client:`
- Test with real API using `await`

**Coverage:** >80% on new code

```bash
uv run pytest --cov=lixinger --cov-report=term-missing -m "not integration"
```

### 4. Generate Documentation

**IMPORTANT**: This project auto-generates API documentation from docstrings.

#### Writing Docstrings

All public methods **MUST** have complete Google-style docstrings:

```python
async def get_data(
    self,
    stock_code: str,
    start_date: str | None = None,
    metrics: list[str] | None = None,
) -> pd.DataFrame:
    """获取股票数据.

    API Endpoint: /cn/company/data
    API Method: POST
    API Doc: https://www.lixinger.com/open/api/doc?api-key=cn/company/data

    Args:
        stock_code: 股票代码，例如 "000001" 表示平安银行
        start_date: 开始日期，格式为 YYYY-MM-DD。如果为 None，返回最新数据
        metrics: 要获取的指标列表，例如 ["pe", "pb"]。如果为 None，返回所有指标

    Returns:
        包含股票数据的 DataFrame，每行代表一个时间点，包含以下列：
        - date: 日期
        - stock_code: 股票代码
        - [其他指标列]

    Raises:
        ValueError: 当 stock_code 格式不正确时
        LixingerAPIError: 当 API 请求失败时

    Example:
        获取平安银行的市盈率和市净率：

        >>> import asyncio
        >>> async def main():
        ...     client = AsyncLixingerClient()
        ...     df = await client.company.data.get_data(
        ...         stock_code="000001",
        ...         start_date="2023-01-01",
        ...         metrics=["pe", "pb"]
        ...     )
        ...     print(df.head())
        >>> asyncio.run(main())

    Note:
        API 限制每分钟最多 1000 次请求。

    """
    data = await self._request("POST", "/cn/company/data", json=payload)
    return get_response_df(data, DataModel)
```

**Required Sections**:

- **Summary line**: 一行简短描述（必需）
- **API Endpoint**: 端点路径
- **API Method**: HTTP 方法（通常是 POST）
- **API Doc**: 官方文档链接
- **Args**: 所有参数的详细说明（必需）
- **Returns**: 返回值的详细说明，包括 DataFrame 的列（必需）
- **Raises**: 可能抛出的异常（推荐）
- **Example**: 可运行的代码示例（强烈推荐）
- **Note/Warning**: 重要提示（可选）

#### Generating Documentation Pages

After implementing API code with docstrings:

**Option 1: Auto-generate (Recommended)**

1. Edit `scripts/generate_docs.py` and add configuration:

```python
API_DOCS = {
    # ... existing configs ...

    # Add new API
    "company/your_api.md": {
        "title": "API 标题",
        "description": "API 描述",
        "endpoint": "POST /cn/company/your-api",
        "module": "lixinger.api.cn.company.your_api.YourAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    client = AsyncLixingerClient()

    # 使用示例
    df = await client.company.your_api.get_data("000001")
    print(df)

asyncio.run(main())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/your-api",
    },
}
```

2. Run generation script:

```bash
uv run python scripts/generate_docs.py
# Output: ✓ Generated: docs/api/company/your_api.md
```

#### Documentation Checklist

- [ ] All public methods have Google-style docstrings
- [ ] Docstrings include API endpoint, method, and doc link
- [ ] Args, Returns, Example sections are complete
- [ ] Generated or created documentation page
- [ ] Previewed locally and verified display
- [ ] Documentation files committed (NOT `site/` folder)

**Important**:
- ✅ Commit: `docs/` (source), `mkdocs.yml`, `scripts/generate_docs.py`
- ❌ DON'T commit: `site/` (auto-generated, in .gitignore)


### 5. Quality Checks

Run before committing:

```bash
uv run ruff check . --fix
uv run ruff format .
uv run mypy lixinger/
uv run pytest -m "not integration"
```

All must pass.

### 6. Descriptive PR description

You should link the API you implemented in PR's description or comments.

## API Requirements

- **Headers**: `Content-Type: application/json`, `Accept-Encoding: gzip, deflate, br`
- **Auth**: API key in request body as `token` field
- **Rate Limit**: 1000 requests/minute (HTTP 429 if exceeded)
- **Retry**: Implement for network failures
- **Validation**: Check response format on every request

## Code Style

- Type hints on all function signatures
- Google-style docstrings
- PEP 8 naming conventions
- No bare `except:`
- No mutable default arguments

## Quick Reference

**Read code examples:**
- `lixinger/api/base.py` - Base API class
- `lixinger/api/cn/company/` - Example implementations
- `lixinger/models/cn/company/` - Example models
- `tests/test_company.py` - Example tests

**Common patterns:**
- Response unwrapping: See `BaseAPI._request()`
- Environment config: See `config.py`
