from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_profile


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_profile(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2025-12-31T00:00:00+08:00",
                "stockCode": "510300",
                "feeder_funds": ["006131", "460300"],
                "c_name": "Custodian Name",
                "e_t_short_name": "Short Name",
                "f_c_name": "Fund Company",
                "inception_date": "2012-05-04T00:00:00+08:00",
                "op_mode": "Open",
                "m_stock_code": "510300",
                "investment_o": "Objective",
                "investment_s": "Strategy",
                "p_c_benchmark": ["Benchmark"],
                "risk_r_c": "Risk",
                "ipo_date": "2012-05-28T00:00:00+08:00",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_profile.get_profile(stock_codes=["510300"])

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "510300"
        assert df.iloc[0]["feeder_funds"] == "006131,460300"
        assert df.iloc[0]["p_c_benchmark"] == "Benchmark"
        assert isinstance(df.iloc[0]["inception_date"], pd.Timestamp)
        assert isinstance(df.iloc[0]["date"], pd.Timestamp)


@pytest.mark.asyncio
async def test_functional_get_fund_profile():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2025-12-31T00:00:00+08:00",
                "stockCode": "510300",
                "feeder_funds": ["006131"],
                "c_name": "Custodian Name",
                "e_t_short_name": "Short Name",
                "f_c_name": "Fund Company",
                "inception_date": "2012-05-04T00:00:00+08:00",
                "op_mode": "Open",
                "m_stock_code": "510300",
                "investment_o": "Objective",
                "investment_s": "Strategy",
                "p_c_benchmark": ["Benchmark"],
                "risk_r_c": "Risk",
                "ipo_date": "2012-05-28T00:00:00+08:00",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_profile(stock_codes=["510300"])
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "510300"
