from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_profile


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_profile(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "600036",
                "stockName": "招商银行",
                "chairman": "缪建民",
                "manager": "王良",
                "secretary": "彭家文",
                "webSite": "www.cmbchina.com",
                "address": "广东省深圳市福田区深南大道7088号招商银行大厦",
                "phone": "0755-83198888",
                "email": "cmb@cmbchina.com",
                "ipoDate": "2002-04-09T00:00:00",
                "mainBusiness": "一般项目:吸收公众存款;发放短期、中期和长期贷款;办理结算;办理票据贴现...",
                "profile": "招商银行股份有限公司(以下简称“本行”)于1987年3月31日经中国人民银行...",
                "businessScope": "一般项目:吸收公众存款;发放短期、中期和长期贷款;办理结算;办理票据贴现...",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.profile.get_profile(stock_codes=["600036"])

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600036"
        assert df.iloc[0]["stock_name"] == "招商银行"
        assert "chairman" in df.columns
        assert df.iloc[0]["chairman"] == "缪建民"


@pytest.mark.asyncio
async def test_functional_get_profile():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000001",
                "stockName": "平安银行",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_profile(stock_codes=["000001"])
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000001"
        assert df.iloc[0]["stock_name"] == "平安银行"
