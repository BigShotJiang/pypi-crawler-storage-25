from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_constituents


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_constituents(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000300",
                "constituents": [
                    {"stockCode": "000001", "areaCode": "cn", "market": "a"},
                    {"stockCode": "000002", "areaCode": "cn", "market": "a"},
                ],
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_constituents.get_constituents(stock_codes=["000300"], date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert df.iloc[0]["index_stock_code"] == "000300"
        assert df.iloc[0]["stock_code"] == "000001"
        assert df.iloc[0]["area_code"] == "cn"
        assert df.iloc[0]["market"] == "a"
        assert df.iloc[1]["index_stock_code"] == "000300"
        assert df.iloc[1]["stock_code"] == "000002"


@pytest.mark.asyncio
async def test_functional_get_constituents():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000300",
                "constituents": [
                    {"stockCode": "000001", "areaCode": "cn", "market": "a"},
                ],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_constituents(stock_codes=["000300"], date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["index_stock_code"] == "000300"
        assert df.iloc[0]["stock_code"] == "000001"


@pytest.mark.asyncio
async def test_get_constituents_empty(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_constituents.get_constituents(stock_codes=["999999"], date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert df.empty
