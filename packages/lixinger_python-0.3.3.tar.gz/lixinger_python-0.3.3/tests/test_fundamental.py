from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_non_financial_fundamental(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-01T00:00:00",
                "stockCode": "600519",
                "pe_ttm": 35.5,
                "pb": 8.2,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["600519"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
        assert "pe_ttm" in df.columns
        assert df.iloc[0]["pe_ttm"] == 35.5


@pytest.mark.asyncio
async def test_functional_get_non_financial_fundamental():
    from lixinger import get_non_financial_fundamental, set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [{"date": "2023-01-01T00:00:00", "stockCode": "000001"}],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_non_financial_fundamental(stock_codes=["000001"], metrics=["pe_ttm"])
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000001"
