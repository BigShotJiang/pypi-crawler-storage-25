from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_candlestick


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_candlestick(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-10T00:00:00+08:00",
                "open": 4.068,
                "close": 4.076,
                "high": 4.092,
                "low": 4.062,
                "change": 0.0015,
                "volume": 744262224,
                "amount": 3033001135,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_candlestick.get_candlestick(
            type="normal",
            stock_code="510300",
            start_date="2023-01-10",
            end_date="2023-01-10",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "510300"
        assert df.iloc[0]["open"] == 4.068


@pytest.mark.asyncio
async def test_functional_get_fund_candlestick():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-10T00:00:00+08:00",
                "open": 4.068,
                "close": 4.076,
                "high": 4.092,
                "low": 4.062,
                "change": 0.0015,
                "volume": 744262224,
                "amount": 3033001135,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_candlestick(
            type="normal",
            stock_code="510300",
            start_date="2023-01-10",
            end_date="2023-01-10",
        )
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "510300"
        assert df.iloc[0]["close"] == 4.076
