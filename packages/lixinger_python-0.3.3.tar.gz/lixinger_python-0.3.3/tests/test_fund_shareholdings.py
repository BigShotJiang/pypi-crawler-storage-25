from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_shareholdings


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_shareholdings(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "stockCode": "603369",
                "holdings": 2327899,
                "marketCap": 122913067,
                "netValueRatio": 0.0017,
                "stockAreaCode": "cn",
            },
            {
                "date": "2023-06-30T00:00:00+08:00",
                "stockCode": "250020",
                "holdings": 7400000,
                "marketCap": 742913167,
                "netValueRatio": 0.2459,
                "name": "25附息国债20",
            },
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_shareholdings.get_shareholdings(
            stock_code="510300",
            start_date="2023-01-01",
            end_date="2023-12-31",
            limit=10,
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert df.iloc[0]["fund_stock_code"] == "510300"
        assert df.iloc[0]["stock_code"] == "603369"
        assert df.iloc[0]["holdings"] == 2327899
        assert df.iloc[1]["name"] == "25附息国债20"
        assert pd.isna(df.iloc[1]["stock_area_code"])
        assert isinstance(df.iloc[0]["date"], pd.Timestamp)
        assert mock_request.call_args[1]["json"]["endDate"] == "2023-12-31"


@pytest.mark.asyncio
async def test_functional_get_fund_shareholdings():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "stockCode": "603369",
                "holdings": 2327899,
                "marketCap": 122913067,
                "netValueRatio": 0.0017,
                "stockAreaCode": "cn",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_shareholdings(stock_code="510300", start_date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["fund_stock_code"] == "510300"
        assert df.iloc[0]["stock_code"] == "603369"
