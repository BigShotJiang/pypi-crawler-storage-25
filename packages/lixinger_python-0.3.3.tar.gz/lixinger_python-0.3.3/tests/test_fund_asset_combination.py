from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_asset_combination


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_asset_combination(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "ei": 2234923780.0,
                "ei_c": 2234923780.0,
                "fii": 606604241.0,
                "fii_b": 606604241.0,
                "bs_a_sr": 121388930.0,
                "oa": 1510678.0,
                "ei_r": 0.753914,
                "fii_r": 0.204628,
                "bs_a_sr_r": 0.040949,
                "oa_r": 0.00051,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_asset_combination.get_asset_combination(
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31",
            limit=10,
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000001"
        assert df.iloc[0]["ei"] == 2234923780.0
        assert df.iloc[0]["fii"] == 606604241.0
        assert isinstance(df.iloc[0]["date"], pd.Timestamp)
        assert mock_request.call_args[1]["json"]["endDate"] == "2023-12-31"


@pytest.mark.asyncio
async def test_get_fund_asset_combination_stock_fund(client):
    # Mock response for a stock fund (missing fii)
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "ei": 10746773781.0,
                "ei_c": 10746773781.0,
                "bs_a_sr": 701160031.0,
                "oa": 30541926.0,
                "ei_r": 0.936254,
                "bs_a_sr_r": 0.061085,
                "oa_r": 0.002661,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_asset_combination.get_asset_combination(
            stock_code="110011",
            start_date="2023-01-01",
        )

        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "110011"
        assert df.iloc[0]["ei"] == 10746773781.0
        assert "fii" not in df.columns


@pytest.mark.asyncio
async def test_get_fund_asset_combination_gold_fund(client):
    # Mock response for a gold fund (with pmi)
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "pmi": 93624151038.0,
                "bs_a_sr": 327207452.0,
                "oa": 80946849.0,
                "pmi_r": 0.995659,
                "bs_a_sr_r": 0.00348,
                "oa_r": 0.000861,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_asset_combination.get_asset_combination(
            stock_code="518880",
            start_date="2023-01-01",
        )

        assert len(df) == 1
        assert df.iloc[0]["pmi"] == 93624151038.0
        assert df.iloc[0]["pmi_r"] == 0.995659
        assert "ei" not in df.columns


@pytest.mark.asyncio
async def test_functional_get_fund_asset_combination():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "ei": 2234923780.0,
                "ei_r": 0.753914,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_asset_combination(stock_code="000001", start_date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000001"
        assert df.iloc[0]["ei"] == 2234923780.0
