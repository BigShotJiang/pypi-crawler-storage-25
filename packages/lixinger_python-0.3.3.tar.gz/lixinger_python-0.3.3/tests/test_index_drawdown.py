from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import get_index_drawdown


@pytest.mark.parametrize(
    "type, stock_code, granularity, start_date, end_date",
    [
        ("normal", "000300", "fs", "2023-01-01", "2023-12-31"),
        ("total_return", "000300", "y1", None, None),
    ],
)
@pytest.mark.asyncio
async def test_get_drawdown(
    type: str,
    stock_code: str,
    granularity: str,
    start_date: str | None,
    end_date: str | None,
):
    mock_data = [
        {"date": "2023-01-03T00:00:00+08:00", "value": 0.0},
        {"date": "2023-01-04T00:00:00+08:00", "value": -0.01},
    ]
    mock_response = {
        "code": 1,
        "message": "success",
        "data": mock_data,
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_index_drawdown(
            type=type,  # type: ignore
            stock_code=stock_code,
            granularity=granularity,  # type: ignore
            start_date=start_date,
            end_date=end_date,
        )

        assert isinstance(df, pd.DataFrame)
        assert not df.empty
        assert "date" in df.columns
        assert "value" in df.columns
        assert "stock_code" in df.columns
        assert df.iloc[0]["stock_code"] == stock_code
        assert df.iloc[0]["value"] == 0.0
        assert pd.api.types.is_datetime64_any_dtype(df["date"])
