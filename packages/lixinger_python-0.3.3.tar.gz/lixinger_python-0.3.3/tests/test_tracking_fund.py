import pandas as pd
import pytest

from lixinger.api.cn.index.tracking_fund import TrackingFundAPI
from lixinger.client import AsyncLixingerClient


@pytest.mark.asyncio
async def test_get_tracking_fund(monkeypatch):
    # Mock response data
    mock_data = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "470007",
                "areaCode": "cn",
                "exchange": "jj",
                "market": "a",
                "name": "汇添富上证综合指数证券投资基金",
                "shortName": "汇添富上证综合指数A",
            },
            {
                "stockCode": "510210",
                "areaCode": "cn",
                "exchange": "sh",
                "market": "a",
                "name": "上证综指交易型开放式指数证券投资基金",
                "shortName": "上证综指ETF",
            },
        ],
    }

    async def mock_request(*args, **kwargs):
        return mock_data["data"]

    monkeypatch.setattr(TrackingFundAPI, "_request", mock_request)
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")

    client = AsyncLixingerClient()
    df = await client.cn_index_tracking_fund.get_tracking_fund(stock_code="000001")

    assert isinstance(df, pd.DataFrame)
    assert len(df) == 2
    assert set(df.columns) == {
        "stock_code",
        "name",
        "short_name",
        "area_code",
        "market",
        "exchange",
    }
    assert df.iloc[0]["stock_code"] == "470007"
    assert df.iloc[0]["name"] == "汇添富上证综合指数证券投资基金"
    assert df.iloc[1]["short_name"] == "上证综指ETF"


@pytest.mark.asyncio
async def test_get_tracking_fund_functional(monkeypatch):
    # Mock response data
    mock_data = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "470007",
                "areaCode": "cn",
                "exchange": "jj",
                "market": "a",
                "name": "汇添富上证综合指数证券投资基金",
                "shortName": "汇添富上证综合指数A",
            }
        ],
    }

    async def mock_request(*args, **kwargs):
        return mock_data["data"]

    monkeypatch.setattr(TrackingFundAPI, "_request", mock_request)
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")

    from lixinger import get_tracking_fund

    df = await get_tracking_fund(stock_code="000001")

    assert isinstance(df, pd.DataFrame)
    assert len(df) == 1
    assert df.iloc[0]["stock_code"] == "470007"
