from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_index_candlestick


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_index_candlestick(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-10T00:00:00+08:00",
                "open": 4014.71,
                "close": 4017.47,
                "change": 0.0011,
                "volume": 10175110000,
                "amount": 214871000000,
                "high": 4030.46,
                "low": 4002.23,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_candlestick.get_candlestick(
            type="normal",
            stock_code="000300",
            start_date="2023-01-10",
            end_date="2023-01-10",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000300"
        assert df.iloc[0]["open"] == 4014.71


@pytest.mark.asyncio
async def test_get_index_candlestick_with_adjust_type(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-10T00:00:00+08:00",
                "open": 4014.71,
                "close": 4017.47,
                "change": 0.0011,
                "volume": 10175110000,
                "amount": 214871000000,
                "high": 4030.46,
                "low": 4002.23,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        await client.cn_index_candlestick.get_candlestick(
            type="normal",
            stock_code="000300",
            start_date="2023-01-10",
            end_date="2023-01-10",
            adjust_type="none",
        )

        args, kwargs = mock_request.call_args
        assert kwargs["json"]["adjustType"] == "none"


@pytest.mark.asyncio
async def test_functional_get_index_candlestick():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-10T00:00:00+08:00",
                "open": 4014.71,
                "close": 4017.47,
                "change": 0.0011,
                "volume": 10175110000,
                "amount": 214871000000,
                "high": 4030.46,
                "low": 4002.23,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_index_candlestick(
            type="normal",
            stock_code="000300",
            start_date="2023-01-10",
            end_date="2023-01-10",
        )
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000300"
        assert df.iloc[0]["close"] == 4017.47
