from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger.api.cn.company.dividend import get_dividend


@pytest.mark.asyncio
async def test_get_dividend():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "content": "每10股派发现金红利17.38元（含税）",
                "registerDate": "2023-07-12T00:00:00+08:00",
                "exDate": "2023-07-13T00:00:00+08:00",
                "paymentDate": "2023-07-13T00:00:00+08:00",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.738,
                "dividendAmount": 43832091655,
                "annualNetProfit": 100000000000,
                "annualNetProfitDividendRatio": 0.438,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01", end_date="2024-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600036"
        assert df.iloc[0]["dividend"] == 1.738
        assert "fs_end_date" in df.columns
        # Test new fields
        assert df.iloc[0]["content"] == "每10股派发现金红利17.38元（含税）"
        assert df.iloc[0]["annual_net_profit"] == 100000000000
        assert df.iloc[0]["annual_net_profit_dividend_ratio"] == 0.438


@pytest.mark.asyncio
async def test_get_dividend_empty():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="000001", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert df.empty


@pytest.mark.asyncio
async def test_get_dividend_with_limit():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "registerDate": "2023-07-12T00:00:00+08:00",
                "exDate": "2023-07-13T00:00:00+08:00",
                "paymentDate": "2023-07-13T00:00:00+08:00",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.738,
                "dividendAmount": 43832091655,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01", limit=10)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1

        # Verify limit parameter was sent in the request
        call_args = mock_request.call_args
        assert call_args is not None
        json_payload = call_args.kwargs.get("json")
        assert json_payload is not None
        assert json_payload.get("limit") == 10


@pytest.mark.asyncio
async def test_get_dividend_with_optional_fields_missing():
    """Test that optional fields (content, annualNetProfit, annualNetProfitDividendRatio) can be missing."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.5,
                # Optional fields missing: content, registerDate, exDate, paymentDate,
                # dividendAmount, annualNetProfit, annualNetProfitDividendRatio, status
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["dividend"] == 1.5
        # When optional fields are missing from API response, they won't be in DataFrame
        # This is expected behavior - only fields present in the API response are included
        assert "content" not in df.columns
        assert "annual_net_profit" not in df.columns
        assert "annual_net_profit_dividend_ratio" not in df.columns
        assert "status" not in df.columns


@pytest.mark.asyncio
async def test_get_dividend_with_status_field():
    """Test that status field is properly handled when present."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.738,
                "status": "implemented",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["status"] == "implemented"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "status_value",
    [
        "board_director_plan",  # 董事会预案
        "shareholders_meeting_plan",  # 股东大会预案
        "company_plan",  # 公司预案
        "delay_implementation",  # 延迟实施
        "cancelled",  # 取消分红
        "implemented",  # 已执行
        "terminated",  # 终止
        "plan",  # 预案
    ],
)
async def test_get_dividend_with_all_status_values(status_value: str):
    """Test all possible status values from the API documentation."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.5,
                "status": status_value,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["status"] == status_value


@pytest.mark.asyncio
async def test_get_dividend_with_multiple_status_values():
    """Test multiple dividend records with different status values."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-03-25T00:00:00+08:00",
                "fsEndDate": "2022-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.738,
                "status": "implemented",
            },
            {
                "date": "2024-03-20T00:00:00+08:00",
                "fsEndDate": "2023-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.8,
                "status": "board_director_plan",
            },
            {
                "date": "2024-04-15T00:00:00+08:00",
                "fsEndDate": "2023-12-31T00:00:00+08:00",
                "currency": "CNY",
                "bonusSharesFromProfit": 0,
                "bonusSharesFromCapitalReserve": 0,
                "dividend": 1.8,
                "status": "shareholders_meeting_plan",
            },
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_dividend(stock_code="600036", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 3
        assert df.iloc[0]["status"] == "implemented"
        assert df.iloc[1]["status"] == "board_director_plan"
        assert df.iloc[2]["status"] == "shareholders_meeting_plan"
