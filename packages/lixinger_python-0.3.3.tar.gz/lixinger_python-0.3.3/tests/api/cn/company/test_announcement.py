from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger.api.cn.company.announcement import get_announcement


@pytest.mark.asyncio
async def test_get_announcement():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "linkUrl": "https://example.com/a.pdf",
                "date": "2023-01-18T00:00:00+08:00",
                "linkText": "Announcement A",
                "linkType": "pdf",
                "types": ["bm"],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_announcement(stock_code="600036", start_date="2023-01-01", end_date="2023-01-31", limit=1)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600036"
        assert df.iloc[0]["link_text"] == "Announcement A"
        assert df.iloc[0]["types"] == "bm"


@pytest.mark.asyncio
async def test_get_announcement_multiple_types():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "linkUrl": "https://example.com/b.pdf",
                "date": "2023-01-18T00:00:00+08:00",
                "linkText": "Announcement B",
                "linkType": "pdf",
                "types": ["fs", "fs_full"],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_announcement(stock_code="600036")

        assert df.iloc[0]["types"] == "fs,fs_full"


@pytest.mark.asyncio
async def test_get_announcement_empty():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_announcement(stock_code="000001")

        assert isinstance(df, pd.DataFrame)
        assert df.empty
