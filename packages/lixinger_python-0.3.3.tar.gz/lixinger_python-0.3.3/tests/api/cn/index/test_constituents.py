"""Unit tests for index constituents API."""

from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger.api.cn.index.constituents import get_constituents


@pytest.mark.asyncio
async def test_get_constituents():
    """Test get_constituents with single index."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000300.SH",
                "constituents": [
                    {
                        "stockCode": "600036",
                        "areaCode": "CN",
                        "market": "SH",
                    },
                    {
                        "stockCode": "000001",
                        "areaCode": "CN",
                        "market": "SZ",
                    },
                ],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_constituents(
            stock_codes=["000300.SH"],
            date="2024-12-31",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert "index_stock_code" in df.columns
        assert "stock_code" in df.columns
        assert df["index_stock_code"].iloc[0] == "000300.SH"
        assert df["stock_code"].iloc[0] == "600036"
        assert df["stock_code"].iloc[1] == "000001"


@pytest.mark.asyncio
async def test_get_constituents_multiple_indices():
    """Test get_constituents with multiple indices."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000001.SH",
                "constituents": [
                    {
                        "stockCode": "600036",
                        "areaCode": "CN",
                        "market": "SH",
                    },
                ],
            },
            {
                "stockCode": "399001.SZ",
                "constituents": [
                    {
                        "stockCode": "000001",
                        "areaCode": "CN",
                        "market": "SZ",
                    },
                ],
            },
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_constituents(
            stock_codes=["000001.SH", "399001.SZ"],
            date="2024-12-31",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert df["index_stock_code"].iloc[0] == "000001.SH"
        assert df["index_stock_code"].iloc[1] == "399001.SZ"


@pytest.mark.asyncio
async def test_get_constituents_empty():
    """Test get_constituents with empty response."""
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000300.SH",
                "constituents": [],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_constituents(
            stock_codes=["000300.SH"],
            date="2024-12-31",
        )

        assert isinstance(df, pd.DataFrame)
        assert df.empty
