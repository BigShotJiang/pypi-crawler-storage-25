"""Integration tests using real API responses.

These tests make actual API calls to verify the SDK works with real data.
They are separated from unit tests and can be run optionally.

Usage:
    # Run integration tests (requires LIXINGER_API_KEY in .env)
    pytest tests/test_integration.py

    # Skip integration tests
    pytest tests/ -m "not integration"

    # Run only integration tests
    pytest tests/ -m integration
"""

import os

import pytest

from lixinger import AsyncLixingerClient

# Mark all tests in this file as integration tests
pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
async def real_client():
    """Create a client with real API key for integration testing."""
    api_key = os.getenv("LIXINGER_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        pytest.skip("No valid LIXINGER_API_KEY found in environment")

    client = AsyncLixingerClient()
    yield client
    await client.close()


class TestRealAPIResponses:
    """Tests that verify SDK works with real API responses."""

    @pytest.mark.asyncio
    async def test_company_get_company_response_structure(self, real_client):
        """Test that real API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.company.company.get_company(stock_codes=["600036"])

        # Verify we get a DataFrame (unwrapped and processed)
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify columns are snake_case
        expected_cols = {
            "stock_code",
            "name",
            "market",
            "ipo_date",
            "area_code",
            "fs_table_type",
            "mutual_markets",
        }
        for col in expected_cols:
            assert col in result.columns, f"Column {col} missing from response"

        assert (result["stock_code"] == "600036").any()
        print(f"\nActual columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_company_get_profile_response_structure(self, real_client):
        """Test that real company profile API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.company.profile.get_profile(stock_codes=["600036"])

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns (at least stock_code should be there)
        assert "stock_code" in result.columns

        assert (result["stock_code"] == "600036").any()
        print(f"\nProfile columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_company_get_indices_response_structure(self, real_client):
        """Test that real company indices API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.indices.get_indices(stock_code="600519")

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        expected_cols = {"area_code", "stock_code", "source", "name"}
        for col in expected_cols:
            assert col in result.columns, f"Column {col} missing from response"

        print(f"\nIndices columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_company_get_equity_change_response_structure(self, real_client):
        """Test that real equity change API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.company.equity_change.get_equity_change(
            stock_code="600519",
            start_date="2023-01-01",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "change_reason" in result.columns
        assert "change_reason_types" in result.columns

        assert (result["stock_code"] == "600519").all()
        print(f"\nEquity change columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fs_get_non_financial_statements_response_structure(self, real_client):
        """Test that real non-financial statements API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_company_fs_non_financial.get_non_financial_statements(
            stock_codes=["600519"],
            metrics=["q.ps.toi.t"],
            start_date="2024-01-01",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "q.ps.toi.t" in result.columns

        assert (result["stock_code"] == "600519").all()
        print(f"\nNon-financial statement columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fundamental_get_fundamental_response_structure(self, real_client):
        """Test that real fundamental API response matches expected structure."""
        import pandas as pd

        # Make a real API call for fundamental data
        # Use common valuation metrics that the API accepts for this endpoint
        result = await real_client.cn_company_fundamental.get_fundamental(
            fs_type="non_financial",
            stock_codes=["600519"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        # Verify metric columns (snake_case)
        assert "pe_ttm" in result.columns
        assert "pb" in result.columns

        print(f"\nFundamental columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fundamental_bank_get_bank_fundamental_response_structure(self, real_client):
        """Test that real bank fundamental API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = await real_client.cn_company.fundamental.bank.get_bank_fundamental(
            stock_codes=["600000"],
            metrics=["pe_ttm"],
            start_date="2023-01-01",
            end_date="2023-12-31",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "pe_ttm" in result.columns

        assert (result["stock_code"] == "600000").all()
        print(f"\nBank fundamental columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_candlestick_get_candlestick_response_structure(self, real_client):
        """Test that real candlestick API response matches expected structure."""
        import pandas as pd

        # Make a real API call for candlestick data
        result = await real_client.candlestick.get_candlestick(
            type="1d",
            stock_code="600036",
            start_date="2024-01-01",
            end_date="2024-01-10",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "open" in result.columns
        assert "close" in result.columns
        assert "high" in result.columns
        assert "low" in result.columns
        assert "volume" in result.columns
        assert "amount" in result.columns

        assert (result["stock_code"] == "600036").all()
        print(f"\nCandlestick columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_company_get_dividend_response_structure(self, real_client):
        """Test that real dividend API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_company_dividend.get_dividend(
            stock_code="600036",
            start_date="2023-01-01",
            end_date="2024-01-01",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "dividend" in result.columns
        assert "fs_end_date" in result.columns

        assert (result["stock_code"] == "600036").all()
        print(f"\nDividend columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_company_get_announcement_response_structure(self, real_client):
        """Test that real announcement API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_company_announcement.get_announcement(
            stock_code="600036",
            limit=5,
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "link_url" in result.columns
        assert "types" in result.columns

        assert (result["stock_code"] == "600036").all()
        print(f"\nAnnouncement columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_get_index_response_structure(self, real_client):
        """Test that real index API response matches expected structure."""
        import pandas as pd

        # Make a real API call for index data
        result = real_client.cn_index.get_index(stock_codes=["000300"])

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "stock_code" in result.columns
        assert "name" in result.columns
        assert "source" in result.columns
        assert "area_code" in result.columns
        assert "market" in result.columns

        assert (result["stock_code"] == "000300").any()
        print(f"\nIndex columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_get_constituents_response_structure(self, real_client):
        """Test that real index constituents API response matches expected structure."""
        import pandas as pd

        # Make a real API call for index constituents
        result = real_client.cn_index_constituents.get_constituents(stock_codes=["000300"], date="2024-10-25")

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "index_stock_code" in result.columns
        assert "stock_code" in result.columns
        assert "area_code" in result.columns
        assert "market" in result.columns

        assert (result["index_stock_code"] == "000300").all()
        print(f"\nIndex constituents columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_get_constituent_weightings_response_structure(self, real_client):
        """Test that real index constituent weightings API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_index_constituent_weightings.get_constituent_weightings(
            stock_code="000300",
            start_date="2023-01-03",
            end_date="2023-01-03",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "weighting" in result.columns

        print(f"\nIndex constituent weightings columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_get_candlestick_response_structure(self, real_client):
        """Test that real index candlestick API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_index_candlestick.get_candlestick(
            type="normal",
            stock_code="000300",
            start_date="2024-01-01",
            end_date="2024-01-10",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "open" in result.columns
        assert "close" in result.columns
        assert "high" in result.columns
        assert "low" in result.columns
        assert "volume" in result.columns
        assert "amount" in result.columns

        assert (result["stock_code"] == "000300").all()
        print(f"\nIndex candlestick columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_get_drawdown_response_structure(self, real_client):
        """Test that real index drawdown API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_index_drawdown.get_drawdown(
            type="normal",
            stock_code="000300",
            granularity="fs",
            start_date="2024-01-01",
            end_date="2024-01-10",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "value" in result.columns

        assert (result["stock_code"] == "000300").all()
        print(f"\nIndex drawdown columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_index_fundamental_response_structure(self, real_client):
        """Test that real index fundamental API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_index_fundamental.get_fundamental(
            stock_codes=["000300"],
            metrics=["pe_ttm.mcw", "pb.mcw"],
            date="2023-10-30",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "pe_ttm.mcw" in result.columns
        assert "pb.mcw" in result.columns

        assert (result["stock_code"] == "000300").all()
        print(f"\nIndex fundamental columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_response_structure(self, real_client):
        """Test that real fund API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund.get_fund(stock_codes=["000001"])

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        expected_cols = {
            "stock_code",
            "name",
            "short_name",
            "fund_second_level",
            "area_code",
            "market",
            "exchange",
            "inception_date",
        }
        for col in expected_cols:
            assert col in result.columns, f"Column {col} missing from response"

        assert (result["stock_code"] == "000001").any()
        print(f"\nFund columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_profile_response_structure(self, real_client):
        """Test that real fund profile API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_profile.get_profile(stock_codes=["510300"])

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        expected_cols = {
            "date",
            "stock_code",
            "feeder_funds",
            "c_name",
            "e_t_short_name",
            "f_c_name",
            "inception_date",
            "op_mode",
            "m_stock_code",
            "investment_o",
            "investment_s",
            "p_c_benchmark",
            "risk_r_c",
            "ipo_date",
        }
        for col in expected_cols:
            assert col in result.columns, f"Column {col} missing from response"

        assert (result["stock_code"] == "510300").any()
        print(f"\nFund profile columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_candlestick_response_structure(self, real_client):
        """Test that real fund candlestick API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_candlestick.get_candlestick(
            type="normal",
            stock_code="510300",
            start_date="2024-01-01",
            end_date="2024-01-10",
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "open" in result.columns
        assert "close" in result.columns
        assert "high" in result.columns
        assert "low" in result.columns
        assert "volume" in result.columns
        assert "amount" in result.columns

        assert (result["stock_code"] == "510300").all()
        print(f"\nFund candlestick columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_shareholdings_response_structure(self, real_client):
        """Test that real fund shareholdings API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_shareholdings.get_shareholdings(
            stock_code="510300",
            start_date="2023-01-01",
            limit=1,
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "fund_stock_code" in result.columns
        assert "stock_code" in result.columns
        assert "holdings" in result.columns
        assert "market_cap" in result.columns
        assert "net_value_ratio" in result.columns

        assert (result["fund_stock_code"] == "510300").all()
        print(f"\nFund shareholdings columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_asset_combination_response_structure(self, real_client):
        """Test that real fund asset combination API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_asset_combination.get_asset_combination(
            stock_code="510300",
            start_date="2023-01-01",
            limit=1,
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        # Ratios should be present
        assert "ei_r" in result.columns or "fii_r" in result.columns or "pmi_r" in result.columns

        assert (result["stock_code"] == "510300").all()
        print(f"\nFund asset combination columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_asset_industry_combination_response_structure(self, real_client):
        """Test that real fund asset industry combination API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_asset_industry_combination.get_asset_industry_combination(
            stock_code="005827",
            start_date="2023-01-01",
            limit=1,
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "name" in result.columns
        assert "value" in result.columns
        assert "proportion" in result.columns

        assert (result["stock_code"] == "005827").all()
        print(f"\nFund asset industry combination columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_fund_get_fund_announcement_response_structure(self, real_client):
        """Test that real fund announcement API response matches expected structure."""
        import pandas as pd

        # Make a real API call
        result = real_client.cn_fund_announcement.get_announcement(
            stock_code="510300",
            start_date="2024-01-01",
            limit=5,
        )

        # Verify we get a DataFrame
        assert isinstance(result, pd.DataFrame), "Should return a pandas DataFrame"
        assert not result.empty, "Should not be empty"

        # Verify core columns
        assert "date" in result.columns
        assert "stock_code" in result.columns
        assert "link_url" in result.columns
        assert "types" in result.columns
        assert "lang" in result.columns

        assert (result["stock_code"] == "510300").all()
        print(f"\nFund announcement columns: {result.columns.tolist()}")

    @pytest.mark.asyncio
    async def test_multiple_stock_codes(self, real_client):
        """Test with multiple stock codes to verify batch handling."""
        import pandas as pd

        result = real_client.company.company.get_company(stock_codes=["600036", "000001"])

        assert isinstance(result, pd.DataFrame)
        assert len(result) >= 1
        print(f"\nReceived {len(result)} records")

    @pytest.mark.asyncio
    async def test_error_response_handling(self, real_client):
        """Test that SDK properly handles API errors."""
        from lixinger.exceptions import APIError, AuthenticationError

        # Use an invalid token to trigger an error
        original_token = real_client.config.api_key
        real_client.config.api_key = "invalid_token"

        try:
            with pytest.raises((APIError, AuthenticationError)):
                real_client.company.company.get_company(stock_codes=["600036"])
        finally:
            # Restore token
            real_client.config.api_key = original_token


class TestResponseRecording:
    """Record real API responses to create accurate mocks."""

    def test_record_company_response(self, real_client, tmp_path):
        """Record real API response to file for mock creation."""
        import json

        # Make real API call
        result = real_client.company.company.get_company(stock_codes=["600036"])

        # Convert DataFrame to dict for saving, handling Timestamps
        records = json.loads(result.to_json(orient="records", date_format="iso"))

        # Save to file
        output_file = tmp_path / "real_company_response.json"
        from pathlib import Path

        Path(output_file).write_text(json.dumps(records, indent=2, ensure_ascii=False))

        print(f"\n✓ Real API response saved to: {output_file}")
        print("Use this to create accurate mocks in test_company.py")

        # Also print to console
        print("\nResponse structure:")
        print(json.dumps(records[:1], indent=2, ensure_ascii=False))
