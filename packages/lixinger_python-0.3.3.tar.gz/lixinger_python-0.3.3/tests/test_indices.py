from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_indices


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_indices(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {"areaCode": "cn", "stockCode": "000001", "source": "csi", "name": "上证指数"},
            {},
            {"areaCode": "cn", "stockCode": "000300", "source": "csi", "name": "沪深300"},
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.indices.get_indices(stock_code="600519")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert df.iloc[0]["stock_code"] == "000001"
        assert df.iloc[1]["stock_code"] == "000300"
        assert set(df.columns) == {"area_code", "stock_code", "source", "name"}


@pytest.mark.asyncio
async def test_functional_get_indices():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {"areaCode": "cn", "stockCode": "000001", "source": "csi", "name": "上证指数"},
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_indices(stock_code="600519")
        assert len(df) == 1
        assert df.iloc[0]["name"] == "上证指数"
