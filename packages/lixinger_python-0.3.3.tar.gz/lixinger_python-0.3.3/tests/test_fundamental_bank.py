from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_bank_fundamental


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_bank_fundamental(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-12-29T00:00:00+08:00",
                "stockCode": "600000",
                "pe_ttm": 5.0216,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.fundamental.bank.get_bank_fundamental(
            stock_codes=["600000"],
            metrics=["pe_ttm"],
            date="2023-12-29",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600000"
        assert "pe_ttm" in df.columns
        assert df.iloc[0]["pe_ttm"] == 5.0216


@pytest.mark.asyncio
async def test_functional_get_bank_fundamental():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [{"date": "2023-12-29T00:00:00+08:00", "stockCode": "600000"}],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_bank_fundamental(stock_codes=["600000"], metrics=["some_metric"], start_date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600000"


@pytest.mark.asyncio
async def test_get_bank_fundamental_params(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [],
    }
    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        await client.company.fundamental.bank.get_bank_fundamental(
            stock_codes=["600000"],
            metrics=["pe_ttm"],
            start_date="2023-01-01",
            end_date="2023-12-31",
        )

        call_json = mock_request.call_args[1]["json"]
        assert call_json["stockCodes"] == ["600000"]
        assert call_json["metricsList"] == ["pe_ttm"]
        assert call_json["startDate"] == "2023-01-01"
        assert call_json["endDate"] == "2023-12-31"
