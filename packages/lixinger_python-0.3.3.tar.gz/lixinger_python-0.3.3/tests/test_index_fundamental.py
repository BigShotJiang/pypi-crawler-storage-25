from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_index_fundamental


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_index_fundamental(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-10-30T00:00:00+08:00",
                "pe_ttm.mcw": 11.1,
                "stockCode": "000300",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_fundamental.get_fundamental(
            stock_codes=["000300"],
            metrics=["pe_ttm.mcw"],
            date="2023-10-30",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000300"
        assert "pe_ttm.mcw" in df.columns
        assert df.iloc[0]["pe_ttm.mcw"] == 11.1
        assert pd.api.types.is_datetime64_any_dtype(df["date"])


@pytest.mark.asyncio
async def test_get_index_fundamental_range(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-10-30T00:00:00+08:00",
                "pe_ttm.mcw": 11.1,
                "stockCode": "000300",
            },
            {
                "date": "2023-10-27T00:00:00+08:00",
                "pe_ttm.mcw": 11.2,
                "stockCode": "000300",
            },
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_fundamental.get_fundamental(
            stock_codes=["000300"],
            metrics=["pe_ttm.mcw"],
            start_date="2023-10-25",
            end_date="2023-10-30",
        )

        assert len(df) == 2
        assert mock_request.call_args[1]["json"]["startDate"] == "2023-10-25"
        assert mock_request.call_args[1]["json"]["endDate"] == "2023-10-30"


@pytest.mark.asyncio
async def test_functional_get_index_fundamental():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [{"date": "2023-10-30T00:00:00+08:00", "stockCode": "000300"}],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_index_fundamental(stock_codes=["000300"], metrics=["pe_ttm.mcw"], date="2023-10-30")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "000300"
