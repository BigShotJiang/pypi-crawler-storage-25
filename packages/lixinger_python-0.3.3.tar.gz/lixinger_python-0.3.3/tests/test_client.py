import pytest

from lixinger import AsyncLixingerClient


@pytest.fixture(autouse=True)
def set_test_env_vars(monkeypatch):
    """Set test environment variables for all tests."""
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")


@pytest.mark.asyncio
async def test_client_initialization():
    """Test that client initializes with env vars."""
    client = AsyncLixingerClient()
    assert client.config.api_key == "test_key"
    assert client.config.base_url == "https://open.lixinger.com/api"
    await client.close()


@pytest.mark.asyncio
async def test_client_context_manager():
    """Test client works as context manager."""
    async with AsyncLixingerClient() as client:
        assert client.config.api_key == "test_key"


@pytest.mark.asyncio
async def test_client_missing_api_key(monkeypatch):
    """Test that client raises error when API key is missing."""
    monkeypatch.delenv("LIXINGER_API_KEY", raising=False)

    with pytest.raises(ValueError, match="LIXINGER_API_KEY environment variable is not set"):
        AsyncLixingerClient()


@pytest.mark.asyncio
async def test_client_override_settings():
    """Test that non-sensitive settings can be overridden."""
    client = AsyncLixingerClient(
        timeout=60.0,
        base_url="https://custom.example.com",
        proxy="socks5://localhost:1080",
    )

    assert client.config.api_key == "test_key"  # From env
    assert client.config.timeout == 60.0  # Overridden
    assert client.config.base_url == "https://custom.example.com"  # Overridden
    assert client.config.proxy == "socks5://localhost:1080"  # Overridden
    await client.close()
