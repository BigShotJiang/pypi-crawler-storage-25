"""Pytest configuration and shared fixtures."""

import pytest


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers",
        "integration: marks tests as integration tests that use real API (deselect with '-m \"not integration\"')",
    )
    config.addinivalue_line("markers", "vcr: marks tests that use VCR for recording/replaying HTTP interactions")
