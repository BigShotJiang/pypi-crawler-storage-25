from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_company


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_company(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "name": "招商银行",
                "stockCode": "600036",
                "areaCode": "cn",
                "market": "sh",
                "fsTableType": "bank",
                "mutualMarkets": ["ha"],
                "ipoDate": "2002-04-09T00:00:00",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.company.get_company(stock_codes=["600036"])

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["name"] == "招商银行"
        assert df.iloc[0]["stock_code"] == "600036"
        assert df.iloc[0]["fs_table_type"] == "bank"
        assert df.iloc[0]["mutual_markets"] == "ha"


@pytest.mark.asyncio
async def test_functional_get_company():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "name": "Test",
                "stockCode": "000001",
                "areaCode": "cn",
                "market": "sz",
                "fsTableType": "non_financial",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_company(stock_codes=["000001"])
        assert len(df) == 1
        assert df.iloc[0]["name"] == "Test"
        assert df.iloc[0]["stock_code"] == "000001"
