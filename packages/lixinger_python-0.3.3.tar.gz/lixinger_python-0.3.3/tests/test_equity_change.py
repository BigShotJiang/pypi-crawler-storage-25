from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_equity_change


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_equity_change(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-12-31T00:00:00+08:00",
                "declarationDate": "2024-04-03T00:00:00+08:00",
                "changeReason": "定期报告",
                "capitalization": 1256197800,
                "outstandingSharesA": 1256197800,
                "limitedSharesA": 0,
                "changeReasonTypes": ["periodicReport"],
                "capitalizationChangeRatio": 0,
                "outstandingSharesAChangeRatio": 0,
                "outstandingSharesHChangeRatio": 0,
                "limitedSharesAChangeRatio": 0,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.equity_change.get_equity_change(stock_code="600519", start_date="2023-01-01")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
        assert df.iloc[0]["change_reason"] == "定期报告"
        assert df.iloc[0]["change_reason_types"] == "periodicReport"
        assert df.iloc[0]["capitalization"] == 1256197800


@pytest.mark.asyncio
async def test_get_equity_change_multiple_types(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2024-10-11T00:00:00+08:00",
                "declarationDate": "2024-10-15T00:00:00+08:00",
                "changeReason": "股份回购,股权激励",
                "capitalization": 2488481340,
                "outstandingSharesA": 1918695948,
                "limitedSharesA": 569785392,
                "changeReasonTypes": ["repurchase", "equityIncentive"],
                "capitalizationChangeRatio": 0,
                "outstandingSharesAChangeRatio": -0.0043,
                "outstandingSharesHChangeRatio": 0,
                "limitedSharesAChangeRatio": 0.0147,
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.company.equity_change.get_equity_change(stock_code="600009", start_date="2024-01-01")

        assert len(df) == 1
        assert df.iloc[0]["change_reason_types"] == "repurchase,equityIncentive"


@pytest.mark.asyncio
async def test_functional_get_equity_change():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-12-31T00:00:00+08:00",
                "declarationDate": "2024-04-03T00:00:00+08:00",
                "changeReason": "定期报告",
                "capitalization": 1256197800,
                "outstandingSharesA": 1256197800,
                "limitedSharesA": 0,
                "changeReasonTypes": ["periodicReport"],
                "capitalizationChangeRatio": 0,
                "outstandingSharesAChangeRatio": 0,
                "outstandingSharesHChangeRatio": 0,
                "limitedSharesAChangeRatio": 0,
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_equity_change(stock_code="600519", start_date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
