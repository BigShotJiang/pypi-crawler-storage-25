from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_non_financial_statements


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_non_financial_statements(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2025-09-30T00:00:00+08:00",
                "currency": "CNY",
                "q": {"ps": {"toi": {"t": 130903889635}}},
                "reportDate": "2025-10-30T00:00:00+08:00",
                "reportType": "third_quarterly_report",
                "standardDate": "2025-09-30T00:00:00+08:00",
                "stockCode": "600519",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_company_fs_non_financial.get_non_financial_statements(
            stock_codes=["600519"],
            metrics=["q.ps.toi.t"],
            start_date="2023-01-01",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
        assert "q.ps.toi.t" in df.columns
        assert df.iloc[0]["q.ps.toi.t"] == 130903889635
        assert "report_date" in df.columns
        assert isinstance(df.iloc[0]["report_date"], pd.Timestamp)


@pytest.mark.asyncio
async def test_functional_get_non_financial_statements():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2025-09-30T00:00:00+08:00",
                "currency": "CNY",
                "reportDate": "2025-10-30T00:00:00+08:00",
                "reportType": "third_quarterly_report",
                "standardDate": "2025-09-30T00:00:00+08:00",
                "stockCode": "600519",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_non_financial_statements(stock_codes=["600519"], metrics=["some_metric"])
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"


@pytest.mark.asyncio
async def test_get_non_financial_statements_with_date(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-01T00:00:00+08:00",
                "currency": "CNY",
                "reportDate": "2023-01-01T00:00:00+08:00",
                "reportType": "annual",
                "standardDate": "2023-01-01T00:00:00+08:00",
                "stockCode": "600519",
            }
        ],
    }
    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_company_fs_non_financial.get_non_financial_statements(
            stock_codes=["600519"],
            metrics=["some_metric"],
            date="2023-01-01",
            end_date="2023-12-31",
        )
        assert len(df) == 1
        call_json = mock_request.call_args[1]["json"]
        assert call_json["date"] == "2023-01-01"
        assert call_json["endDate"] == "2023-12-31"
