from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_announcement


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_announcement(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "linkUrl": "http://example.com/announcement1.pdf",
                "date": "2024-01-22T00:00:00+08:00",
                "linkText": "Test Announcement 1",
                "linkType": "PDF",
                "lang": "cmn_hans_cn",
                "types": ["fs", "fs_full"],
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_announcement.get_announcement(stock_code="510300", start_date="2024-01-01", limit=1)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["link_text"] == "Test Announcement 1"
        assert df.iloc[0]["stock_code"] == "510300"
        assert df.iloc[0]["types"] == "fs,fs_full"
        assert isinstance(df.iloc[0]["date"], pd.Timestamp)
        assert mock_request.call_args[1]["json"]["stockCode"] == "510300"
        assert mock_request.call_args[1]["json"]["startDate"] == "2024-01-01"
        assert mock_request.call_args[1]["json"]["limit"] == 1


@pytest.mark.asyncio
async def test_functional_get_fund_announcement():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "linkUrl": "http://example.com/announcement2.pdf",
                "date": "2024-01-22T00:00:00+08:00",
                "linkText": "Test Announcement 2",
                "linkType": "PDF",
                "lang": "cmn_hans_cn",
                "types": ["dividend"],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_announcement(stock_code="510300", start_date="2024-01-01")
        assert len(df) == 1
        assert df.iloc[0]["link_text"] == "Test Announcement 2"
        assert df.iloc[0]["stock_code"] == "510300"
        assert df.iloc[0]["types"] == "dividend"


@pytest.mark.asyncio
async def test_get_fund_announcement_empty(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_announcement.get_announcement(stock_code="510300", start_date="2024-01-01")

        assert isinstance(df, pd.DataFrame)
        assert df.empty
