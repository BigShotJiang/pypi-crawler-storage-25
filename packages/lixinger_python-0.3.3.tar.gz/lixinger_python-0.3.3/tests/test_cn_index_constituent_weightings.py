from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_constituent_weightings


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_constituent_weightings(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-03T00:00:00+08:00",
                "weighting": 0.058007,
                "stockCode": "600519",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index_constituent_weightings.get_constituent_weightings(
            stock_code="000300", start_date="2023-01-03", end_date="2023-01-03"
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
        assert df.iloc[0]["weighting"] == 0.058007


@pytest.mark.asyncio
async def test_functional_get_constituent_weightings():
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-01-03T00:00:00+08:00",
                "weighting": 0.058007,
                "stockCode": "600519",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_constituent_weightings(stock_code="000300", start_date="2023-01-03", end_date="2023-01-03")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600519"
