from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_index


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_index(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "areaCode": "cn",
                "market": "a",
                "stockCode": "000300",
                "source": "csi",
                "fsTableType": "hybrid",
                "currency": "CNY",
                "name": "沪深300",
                "launchDate": "2005-04-08T00:00:00+08:00",
                "rebalancingFrequency": "semi-annually",
                "series": "size",
                "caculationMethod": "grading_weighted",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_index.get_index(stock_codes=["000300"], source="csi")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["name"] == "沪深300"
        assert df.iloc[0]["stock_code"] == "000300"
        assert df.iloc[0]["source"] == "csi"
        assert df.iloc[0]["fs_table_type"] == "hybrid"
        assert df.iloc[0]["caculation_method"] == "grading_weighted"


@pytest.mark.asyncio
async def test_functional_get_index():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "areaCode": "cn",
                "market": "a",
                "stockCode": "000001",
                "source": "sse",
                "fsTableType": "non_financial",
                "name": "上证指数",
                "currency": "CNY",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_index(stock_codes=["000001"])
        assert len(df) == 1
        assert df.iloc[0]["name"] == "上证指数"
        assert df.iloc[0]["stock_code"] == "000001"
