from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund_asset_industry_combination


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund_asset_industry_combination(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2025-12-31T00:00:00+08:00",
                "aic_cn": [
                    {"name": "采矿业", "value": 103284, "proportion": 0.000007},
                    {"name": "制造业", "value": 13540022277, "proportion": 0.903143},
                ],
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund_asset_industry_combination.get_asset_industry_combination(
            stock_code="005827",
            start_date="2023-01-01",
            end_date="2023-12-31",
            limit=10,
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert df.iloc[0]["stock_code"] == "005827"
        assert df.iloc[0]["name"] == "采矿业"
        assert df.iloc[0]["value"] == 103284
        assert df.iloc[1]["name"] == "制造业"
        assert isinstance(df.iloc[0]["date"], pd.Timestamp)
        assert mock_request.call_args[1]["json"]["endDate"] == "2023-12-31"


@pytest.mark.asyncio
async def test_functional_get_fund_asset_industry_combination():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "date": "2023-06-30T00:00:00+08:00",
                "aic_cn": [{"name": "制造业", "value": 1000, "proportion": 1.0}],
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund_asset_industry_combination(stock_code="005827", start_date="2023-01-01")
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "005827"
        assert df.iloc[0]["name"] == "制造业"
