from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from lixinger.api.cn.company.candlestick import get_candlestick


@pytest.fixture(autouse=True)
def setup_env(monkeypatch):
    """Set up environment variables for testing."""
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")


@pytest.mark.asyncio
async def test_get_candlestick():
    """Test get_candlestick function."""
    mock_data = [
        {
            "date": "2024-01-10T00:00:00+08:00",
            "open": 28.02,
            "close": 28.05,
            "high": 28.35,
            "low": 28.02,
            "volume": 45364000,
            "amount": 1277640000,
            "change": -0.0043,
            "stockCode": "600036",
            "to_r": 0.002199,
        },
        {
            "date": "2024-01-09T00:00:00+08:00",
            "open": 28.12,
            "close": 28.17,
            "high": 28.28,
            "low": 27.9,
            "volume": 55866300,
            "amount": 1569680000,
            "change": 0.0014,
            "stockCode": "600036",
            "to_r": 0.002708,
        },
    ]

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "code": 1,
            "message": "success",
            "data": mock_data,
        }
        mock_request.return_value = mock_response

        df = await get_candlestick(
            type="1d",
            stock_code="600036",
            start_date="2024-01-09",
            end_date="2024-01-10",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert "stock_code" in df.columns
        assert "open" in df.columns
        assert "close" in df.columns
        assert df.iloc[0]["stock_code"] == "600036"
        assert df.iloc[0]["open"] == 28.02

        # Verify request parameters
        args, kwargs = mock_request.call_args
        assert args[0] == "POST"
        assert "/cn/company/candlestick" in str(args[1])
        assert kwargs["json"]["stockCode"] == "600036"
        assert kwargs["json"]["type"] == "1d"
        assert kwargs["json"]["startDate"] == "2024-01-09"
        assert kwargs["json"]["endDate"] == "2024-01-10"
        assert "adjustType" not in kwargs["json"]


@pytest.mark.asyncio
async def test_get_candlestick_with_adjust_type():
    """Test get_candlestick function with adjust_type."""
    mock_data = [
        {
            "date": "2024-01-10T00:00:00+08:00",
            "open": 28.02,
            "close": 28.05,
            "high": 28.35,
            "low": 28.02,
            "volume": 45364000,
            "amount": 1277640000,
            "change": -0.0043,
            "stockCode": "600036",
            "to_r": 0.002199,
        }
    ]

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "code": 1,
            "message": "success",
            "data": mock_data,
        }
        mock_request.return_value = mock_response

        df = await get_candlestick(
            type="1d",
            stock_code="600036",
            start_date="2024-01-09",
            end_date="2024-01-10",
            adjust_type="qxw",
        )

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1
        assert df.iloc[0]["stock_code"] == "600036"

        # Verify request parameters
        args, kwargs = mock_request.call_args
        assert kwargs["json"]["adjustType"] == "qxw"
