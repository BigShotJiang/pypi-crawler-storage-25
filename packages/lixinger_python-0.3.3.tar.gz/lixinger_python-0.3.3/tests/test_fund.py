from unittest.mock import Mock, patch

import pandas as pd
import pytest

from lixinger import AsyncLixingerClient, get_fund


@pytest.fixture
def client():
    return AsyncLixingerClient()


@pytest.mark.asyncio
async def test_get_fund(client):
    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "026673",
                "fundSecondLevel": "hybrid",
                "areaCode": "cn",
                "market": "a",
                "exchange": "jj",
                "shortName": "长江医药健康精选混合发起",
                "name": "长江医药健康精选混合型发起式证券投资基金",
                "inceptionDate": "2026-01-23T00:00:00+08:00",
            }
        ],
    }

    with patch.object(client._http_client, "request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await client.cn_fund.get_fund(stock_codes=["026673"], page_index=0)

        assert isinstance(df, pd.DataFrame)
        assert mock_request.call_args[1]["json"]["pageIndex"] == 0
        assert len(df) == 1
        assert df.iloc[0]["name"] == "长江医药健康精选混合型发起式证券投资基金"
        assert df.iloc[0]["stock_code"] == "026673"
        assert df.iloc[0]["fund_second_level"] == "hybrid"
        assert isinstance(df.iloc[0]["inception_date"], pd.Timestamp)


@pytest.mark.asyncio
async def test_functional_get_fund():
    from lixinger import set_token

    set_token("test_key")

    mock_response = {
        "code": 1,
        "message": "success",
        "data": [
            {
                "stockCode": "000001",
                "areaCode": "cn",
                "exchange": "jj",
                "market": "a",
                "name": "华夏成长证券投资基金",
                "shortName": "华夏成长混合",
                "fundSecondLevel": "hybrid",
                "inceptionDate": "2001-12-18T00:00:00+08:00",
            }
        ],
    }

    with patch("httpx.AsyncClient.request") as mock_request:
        mock_request.return_value = Mock()
        mock_request.return_value.status_code = 200
        mock_request.return_value.json.return_value = mock_response

        df = await get_fund(stock_codes=["000001"])
        assert len(df) == 1
        assert df.iloc[0]["name"] == "华夏成长证券投资基金"
        assert df.iloc[0]["stock_code"] == "000001"
