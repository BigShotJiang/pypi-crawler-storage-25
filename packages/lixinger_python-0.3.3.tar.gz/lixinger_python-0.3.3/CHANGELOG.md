# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Add support for US stock market APIs
- Add caching mechanism for API responses

## [0.2.0] - 2026-02-26

### ⚠️ BREAKING CHANGES

This release completely migrates the SDK to async/await. All existing code must be updated.

**Migration Guide:**

```python
# v0.1.x (old - blocking)
from lixinger import LixingerClient

with LixingerClient() as client:
    df = client.company.company.get_company(["000001"])

# v0.2.0 (new - async)
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    async with AsyncLixingerClient() as client:
        df = await client.company.company.get_company(["000001"])

asyncio.run(main())
```

### Changed
- **BREAKING**: `LixingerClient` renamed to `AsyncLixingerClient`
- **BREAKING**: All API methods now return coroutines and must be awaited
- **BREAKING**: Context manager now requires `async with` instead of `with`
- **BREAKING**: `client.close()` is now async and must be awaited
- **BREAKING**: All functional APIs (e.g., `get_company()`) are now async
- Replaced `httpx.Client` with `httpx.AsyncClient`
- Replaced `time.sleep` with `asyncio.sleep` in rate limiter and retry logic

### Added
- ✨ Full async/await support throughout the SDK
- ✨ Concurrent request capability - query multiple stocks in parallel
- ✨ Native Jupyter Notebook support (top-level await)
- ✨ Perfect integration with AI Agent frameworks (LangChain, LlamaIndex)
- ✨ Compatible with async web frameworks (FastAPI, Sanic, Quart)

### Benefits
- Non-blocking I/O for better performance in async contexts
- Ability to query multiple stocks concurrently using `asyncio.gather()`
- Seamless integration with modern Python async ecosystem
- Ideal for AI agents that need to fetch financial data without blocking

## [0.1.0] - 2026-02-24

### Added
- Initial release of lixinger-python SDK
- Support for company fundamental data APIs (`/cn/company/fundamental/*`)
- Support for company profile data API (`/cn/company`)
- Support for company candlestick (OHLC) data API (`/cn/company/fs/non_financial`)
- Support for index data APIs (`/cn/index`)
- Environment-based configuration via `.env` file
- Rate limiting (1000 requests/minute)
- Automatic retry mechanism for failed requests
- SOCKS proxy support
- Full type hints and mypy support
- Comprehensive test suite with pytest
- Auto-generated documentation with MkDocs
- Pre-commit hooks for code quality

### Features
- **LixingerClient**: Main client class with context manager support
- **Data Models**: Pydantic models for type-safe API responses
- **DataFrame Support**: All API responses return pandas DataFrame
- **Error Handling**: Custom exception classes for better error handling
- **Rate Limiting**: Built-in rate limiter to prevent API throttling
- **Retry Logic**: Automatic retry with exponential backoff

### Developer Tools
- Ruff for linting and formatting
- Mypy for type checking
- Pytest for testing
- Pre-commit hooks
- MkDocs for documentation

[unreleased]: https://github.com/your-username/lixinger-python/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/your-username/lixinger-python/releases/tag/v0.1.0
