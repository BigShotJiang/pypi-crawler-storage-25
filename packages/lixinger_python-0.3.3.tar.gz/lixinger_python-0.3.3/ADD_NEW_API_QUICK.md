# 📚 添加新 API - 快速参考

## ⚠️ 重要：SDK 采用完全异步架构

所有 API 方法必须使用 `async def` 并用 `await` 调用。

## 🎯 三步添加新 API

### 1️⃣ 写代码 + Docstrings

```python
# lixinger/api/cn/company/your_api.py

class YourAPI(BaseAPI):
    """Your API description."""

    async def get_data(
        self,
        stock_code: str,
        param: str | None = None,
    ) -> pd.DataFrame:
        """一行描述.

        Args:
            stock_code: 股票代码
            param: 参数说明

        Returns:
            返回值说明

        Example:
            >>> import asyncio
            >>> async def main():
            ...     client = AsyncLixingerClient()
            ...     df = await client.your_api.get_data("000001")
            >>> asyncio.run(main())

        """
        # 使用 await 调用 _request
        data = await self._request("POST", "/endpoint", json=payload)
        return get_response_df(data, Model)
```

**关键**：
- ✅ 使用 `async def` 定义所有方法
- ✅ 使用 `await self._request(...)`
- ✅ 使用 **Google-style docstrings** + 完整**类型注解**
- ✅ Example 中展示 async/await 用法

---

### 2️⃣ 生成文档

**方式 A: 自动生成（推荐）**

```bash
# 1. 编辑 scripts/generate_docs.py，添加配置
vim scripts/generate_docs.py

# 2. 运行生成脚本
uv run python scripts/generate_docs.py
```

**方式 B: 手动创建**

```bash
# 创建文档文件
cat > docs/api/company/your_api.md << 'EOF'
# API 名称

## 类参考

::: lixinger.api.cn.company.your_api.YourAPI
    options:
      show_root_heading: true
      show_source: true
EOF
```

---

### 3️⃣ 预览 & 部署

```bash
# 本地预览
uv run mkdocs serve

# 部署到线上
uv run mkdocs gh-deploy
```

---

## ✅ 检查清单

添加新 API 时确保：

- [ ] **所有方法使用 `async def`**
- [ ] **所有 `_request` 调用使用 `await`**
- [ ] 代码使用 Google-style docstrings
- [ ] 包含 `Args`, `Returns`, `Example` 部分
- [ ] **Example 展示 async/await 用法**
- [ ] 完整的类型注解（`str`, `int | None`, `pd.DataFrame` 等）
- [ ] 运行了文档生成脚本或手动创建了文档页面
- [ ] 本地预览文档正常：`uv run mkdocs serve`
- [ ] **测试函数使用 `async def` 和 `@pytest.mark.asyncio`**

---

## 🔑 关键点

### ✅ DO (推荐做法)

```python
async def get_data(self, code: str) -> pd.DataFrame:
    """获取数据.

    Args:
        code: 股票代码

    Returns:
        数据 DataFrame

    Example:
        >>> import asyncio
        >>> async def main():
        ...     df = await get_data("000001")
        >>> asyncio.run(main())

    """
    data = await self._request("POST", "/endpoint", json={"code": code})
    return get_response_df(data, Model)
```

### ❌ DON'T (避免)

```python
def get_data(self, code):  # ❌ 缺少 async、类型注解
    """Get data."""        # ❌ Docstring 太简单、缺少 Example
    # ❌ 缺少 await
    data = self._request("POST", "/endpoint", json={"code": code})
    return data
```

---

## 📖 Docstring 最小模板

```python
async def method_name(param: type) -> return_type:
    """一行简短描述.

    Args:
        param: 参数说明

    Returns:
        返回值说明

    Example:
        >>> import asyncio
        >>> async def main():
        ...     result = await method_name("value")
        >>> asyncio.run(main())

    """
    data = await self._request("POST", "/endpoint", json={"param": param})
    return data
```

---

## 🧪 测试模板

```python
import pytest

@pytest.mark.asyncio
async def test_your_api(monkeypatch):
    """测试你的 API."""

    # Mock async _request
    async def mock_request(*args, **kwargs):
        return [{"field": "value"}]

    monkeypatch.setattr(YourAPI, "_request", mock_request)
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")

    # 使用 await 调用
    client = AsyncLixingerClient()
    df = await client.your_api.get_data("000001")

    assert not df.empty
```

---

## 🔗 完整文档

详细指南请查看：[ADD_NEW_API.md](ADD_NEW_API.md)

---

**重点**：只要写好 docstrings，文档会自动生成！✨
