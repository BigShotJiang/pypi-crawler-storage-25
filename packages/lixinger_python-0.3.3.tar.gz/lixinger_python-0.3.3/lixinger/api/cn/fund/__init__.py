"""Fund-related APIs."""

from lixinger.api.cn.fund.announcement import (
    FundAnnouncementAPI,
    get_fund_announcement,
)
from lixinger.api.cn.fund.asset_combination import (
    FundAssetCombinationAPI,
    get_fund_asset_combination,
)
from lixinger.api.cn.fund.asset_industry_combination import (
    FundAssetIndustryCombinationAPI,
    get_fund_asset_industry_combination,
)
from lixinger.api.cn.fund.candlestick import FundCandlestickAPI, get_fund_candlestick
from lixinger.api.cn.fund.fund import FundAPI, get_fund
from lixinger.api.cn.fund.profile import FundProfileAPI, get_fund_profile
from lixinger.api.cn.fund.shareholdings import FundShareholdingsAPI, get_fund_shareholdings

__all__ = [
    "FundAPI",
    "get_fund",
    "FundProfileAPI",
    "get_fund_profile",
    "FundCandlestickAPI",
    "get_fund_candlestick",
    "FundShareholdingsAPI",
    "get_fund_shareholdings",
    "FundAssetCombinationAPI",
    "get_fund_asset_combination",
    "FundAssetIndustryCombinationAPI",
    "get_fund_asset_industry_combination",
    "FundAnnouncementAPI",
    "get_fund_announcement",
]
