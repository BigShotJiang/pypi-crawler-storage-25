"""Fund profile APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund.profile import FundProfile
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundProfileAPI(BaseAPI):
    """Fund profile APIs."""

    async def get_profile(
        self,
        stock_codes: list[str],
    ) -> pd.DataFrame:
        """获取基金基本概况.

        API Endpoint: /cn/fund/profile
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/profile

        Args:
            stock_codes: 基金代码列表

        Returns:
            DataFrame containing fund profile information

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
        }

        data = await self._request("POST", "/cn/fund/profile", json=payload)
        return get_response_df(data, FundProfile)


# Functional API instance
_api_instance = FundProfileAPI()


@api
async def get_fund_profile(
    stock_codes: list[str],
) -> pd.DataFrame:
    """获取基金基本概况.

    Args:
        stock_codes: 基金代码列表

    Returns:
        DataFrame containing fund profile information

    """
    return await _api_instance.get_profile(
        stock_codes=stock_codes,
    )
