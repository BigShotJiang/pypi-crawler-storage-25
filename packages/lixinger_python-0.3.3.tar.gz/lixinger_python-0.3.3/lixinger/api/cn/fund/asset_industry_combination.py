"""Fund asset industry combination API."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund.asset_industry_combination import AssetIndustryCombination
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundAssetIndustryCombinationAPI(BaseAPI):
    """Fund asset industry combination API."""

    async def get_asset_industry_combination(
        self,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取按行业分类的股票投资组合数据.

        API Endpoint: /cn/fund/asset-industry-combination
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/asset-industry-combination

        Args:
            stock_code: 基金代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD), 可选
            limit: 限制返回的报告期数量, 可选

        Returns:
            DataFrame containing fund asset industry combination data

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
        }
        if end_date is not None:
            payload["endDate"] = end_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/fund/asset-industry-combination", json=payload)

        # Flatten nested industry combination data
        flattened_data = []
        for item in data:
            date = item["date"]
            for aic in item.get("aic_cn", []):
                record = {
                    "date": date,
                    "stock_code": stock_code,
                    **aic,
                }
                flattened_data.append(record)

        return get_response_df(flattened_data, AssetIndustryCombination)


# Functional API instance
_api_instance = FundAssetIndustryCombinationAPI()


@api
async def get_fund_asset_industry_combination(
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取按行业分类的股票投资组合数据.

    Args:
        stock_code: 基金代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD), 可选
        limit: 限制返回的报告期数量, 可选

    Returns:
        DataFrame containing fund asset industry combination data

    """
    return await _api_instance.get_asset_industry_combination(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )
