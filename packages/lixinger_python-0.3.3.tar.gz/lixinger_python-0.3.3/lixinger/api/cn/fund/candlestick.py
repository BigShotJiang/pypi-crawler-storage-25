"""Fund candlestick data APIs."""

from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund.candlestick import FundCandlestick
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundCandlestickAPI(BaseAPI):
    """Fund candlestick data APIs."""

    async def get_candlestick(
        self,
        type: Literal["normal", "total_return"],
        stock_code: str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """获取基金K线数据.

        API Endpoint: /cn/fund/candlestick
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/candlestick

        Args:
            type: K线类型 (normal, total_return)
            stock_code: 基金代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)

        Returns:
            DataFrame containing fund candlestick data

        """
        payload: dict[str, Any] = {
            "type": type,
            "stockCode": stock_code,
            "startDate": start_date,
            "endDate": end_date,
        }

        data = await self._request("POST", "/cn/fund/candlestick", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, FundCandlestick)


# Functional API instance
_api_instance = FundCandlestickAPI()


@api
async def get_fund_candlestick(
    type: Literal["normal", "total_return"],
    stock_code: str,
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    """获取基金K线数据.

    API Endpoint: /cn/fund/candlestick
    API Method: POST
    Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/candlestick

    Args:
        type: K线类型 (normal, total_return)
        stock_code: 基金代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)

    Returns:
        DataFrame containing fund candlestick data

    """
    return await _api_instance.get_candlestick(
        type=type,
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
    )
