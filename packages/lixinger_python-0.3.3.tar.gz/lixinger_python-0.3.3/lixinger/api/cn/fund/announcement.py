"""Fund announcement APIs.

This module provides APIs for querying fund announcements.
"""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund import Announcement
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundAnnouncementAPI(BaseAPI):
    """Fund announcement APIs."""

    async def get_announcement(
        self,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取基金公告数据.

        API Endpoint: /cn/fund/announcement
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/announcement

        Args:
            stock_code: 基金代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD), 可选
            limit: 限制返回数量, 可选

        Returns:
            DataFrame containing fund announcement information

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
        }
        if end_date is not None:
            payload["endDate"] = end_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/fund/announcement", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, Announcement)


# Functional API instance
_api_instance = FundAnnouncementAPI()


@api
async def get_fund_announcement(
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取基金公告数据.

    API Endpoint: /cn/fund/announcement
    API Method: POST
    Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/announcement

    Args:
        stock_code: 基金代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD), 可选
        limit: 限制返回数量, 可选

    Returns:
        DataFrame containing fund announcement information

    """
    return await _api_instance.get_announcement(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )
