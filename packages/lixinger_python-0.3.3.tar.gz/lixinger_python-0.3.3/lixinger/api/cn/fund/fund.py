"""Fund-related APIs.

This module provides APIs for querying fund information.
"""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund import Fund
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundAPI(BaseAPI):
    """Fund related APIs."""

    async def get_fund(
        self,
        stock_codes: list[str] | None = None,
        page_index: int | None = None,
    ) -> pd.DataFrame:
        """获取基金信息.

        API Endpoint: /cn/fund
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund

        Args:
            stock_codes: 基金代码列表
            page_index: 分页索引

        Returns:
            DataFrame containing fund information

        """
        payload: dict[str, Any] = {}
        if stock_codes is not None:
            payload["stockCodes"] = stock_codes
        if page_index is not None:
            payload["pageIndex"] = page_index

        data = await self._request("POST", "/cn/fund", json=payload)
        return get_response_df(data, Fund)


# Functional API instance
_api_instance = FundAPI()


@api
async def get_fund(
    stock_codes: list[str] | None = None,
    page_index: int | None = None,
) -> pd.DataFrame:
    """获取基金信息.

    Args:
        stock_codes: 基金代码列表
        page_index: 分页索引

    Returns:
        DataFrame containing fund information

    """
    return await _api_instance.get_fund(
        stock_codes=stock_codes,
        page_index=page_index,
    )
