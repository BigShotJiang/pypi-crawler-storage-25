"""Fund shareholdings API."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.fund.shareholdings import Shareholding
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class FundShareholdingsAPI(BaseAPI):
    """Fund shareholdings API."""

    async def get_shareholdings(
        self,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取基金持仓数据.

        API Endpoint: /cn/fund/shareholdings
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/shareholdings

        Args:
            stock_code: 基金代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD), 可选
            limit: 限制返回的报告期数量, 可选

        Returns:
            DataFrame containing fund shareholdings data

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
        }
        if end_date is not None:
            payload["endDate"] = end_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/fund/shareholdings", json=payload)
        for item in data:
            item["fund_stock_code"] = stock_code
        return get_response_df(data, Shareholding)


# Functional API instance
_api_instance = FundShareholdingsAPI()


@api
async def get_fund_shareholdings(
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取基金持仓数据.

    API Endpoint: /cn/fund/shareholdings
    API Method: POST
    Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/fund/shareholdings

    Args:
        stock_code: 基金代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD), 可选
        limit: 限制返回的报告期数量, 可选

    Returns:
        DataFrame containing fund shareholdings data

    """
    return await _api_instance.get_shareholdings(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )
