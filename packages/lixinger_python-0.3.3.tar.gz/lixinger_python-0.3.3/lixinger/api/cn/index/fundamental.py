"""Index fundamental APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.fundamental import IndexFundamentalData
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class IndexFundamentalAPI(BaseAPI):
    """Index fundamental APIs."""

    async def get_fundamental(
        self,
        stock_codes: list[str],
        metrics: list[str],
        date: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """获取指数基本面数据.

        API Endpoint: /cn/index/fundamental
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/index/fundamental

        Args:
            stock_codes: 指数代码列表
            metrics: 指标列表
            date: 日期 (YYYY-MM-DD), 与start_date二选一
            start_date: 开始日期 (YYYY-MM-DD), 与date二选一
            end_date: 结束日期 (YYYY-MM-DD), 可选

        Returns:
            DataFrame containing index fundamental information

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
            "metricsList": metrics,
        }
        if date is not None:
            payload["date"] = date
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date

        data = await self._request("POST", "/cn/index/fundamental", json=payload)
        return get_response_df(data, IndexFundamentalData)


# Functional API instance
_api_instance = IndexFundamentalAPI()


@api
async def get_index_fundamental(
    stock_codes: list[str],
    metrics: list[str],
    date: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    """获取指数基本面数据.

    Args:
        stock_codes: 指数代码列表
        metrics: 指标列表
        date: 日期 (YYYY-MM-DD), 与start_date二选一
        start_date: 开始日期 (YYYY-MM-DD), 与date二选一
        end_date: 结束日期 (YYYY-MM-DD), 可选

    Returns:
        DataFrame containing index fundamental information

    """
    return await _api_instance.get_fundamental(
        stock_codes=stock_codes,
        metrics=metrics,
        date=date,
        start_date=start_date,
        end_date=end_date,
    )
