"""Index constituents APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.constituents import Constituent
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class ConstituentsAPI(BaseAPI):
    """Index constituents APIs."""

    async def get_constituents(
        self,
        stock_codes: list[str],
        date: str,
    ) -> pd.DataFrame:
        """获取指数成分股列表.

        API Endpoint: /cn/index/constituents
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/index/constituents

        Args:
            stock_codes: 指数代码列表，如 ["000001.SH", "399001.SZ"]
            date: 查询日期 (YYYY-MM-DD)，返回该日期的成分股列表

        Returns:
            包含指数成分股信息的 DataFrame，包含以下字段:
                - index_stock_code: 指数代码
                - stock_code: 成分股代码
                - area_code: 地区代码
                - market: 市场

        Example:
            获取沪深300指数的成分股::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    # 查询单个指数的成分股
                    df = await client.index.get_constituents(
                        stock_codes=["000300.SH"],
                        date="2024-12-31"
                    )
                    print(df)

                    # 查询多个指数的成分股
                    df = await client.index.get_constituents(
                        stock_codes=["000001.SH", "399001.SZ"],
                        date="2024-12-31"
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
            "date": date,
        }

        data = await self._request("POST", "/cn/index/constituents", json=payload)
        flattened_data = []
        for item in data:
            index_stock_code = item["stockCode"]
            for constituent in item["constituents"]:
                constituent["index_stock_code"] = index_stock_code
                flattened_data.append(constituent)
        return get_response_df(flattened_data, Constituent)


# Functional API instance
_api_instance = ConstituentsAPI()


@api
async def get_constituents(
    stock_codes: list[str],
    date: str,
) -> pd.DataFrame:
    """获取指数成分股列表.

    Args:
        stock_codes: 指数代码列表，如 ["000001.SH", "399001.SZ"]
        date: 查询日期 (YYYY-MM-DD)，返回该日期的成分股列表

    Returns:
        包含指数成分股信息的 DataFrame，包含以下字段:
            - index_stock_code: 指数代码
            - stock_code: 成分股代码
            - area_code: 地区代码
            - market: 市场

    Example:
        获取沪深300指数的成分股::

            from lixinger import get_constituents

            # 查询单个指数的成分股
            df = await get_constituents(
                stock_codes=["000300.SH"],
                date="2024-12-31"
            )
            print(df)

    """
    return await _api_instance.get_constituents(
        stock_codes=stock_codes,
        date=date,
    )
