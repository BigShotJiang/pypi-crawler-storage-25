"""Index-related APIs.

This module provides APIs for querying index information.
"""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index import Index
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class IndexAPI(BaseAPI):
    """Index related APIs."""

    async def get_index(
        self,
        stock_codes: list[str] | None = None,
        source: str | None = None,
    ) -> pd.DataFrame:
        """获取指数基本信息.

        API Endpoint: /cn/index
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/index

        Args:
            stock_codes: 指数代码列表，如 ["000300", "000001"]。不传则返回所有指数
            source: 指数来源筛选，可选值:
                - "csi": 中证指数
                - "cni": 国证指数
                - "sse": 上证指数
                - "szse": 深证指数
                不传则返回所有来源的指数

        Returns:
            包含指数基本信息的 DataFrame，包含以下字段:
                - name: 指数名称
                - stock_code: 指数代码
                - area_code: 地区代码
                - market: 市场
                - source: 指数来源 (csi/cni/sse/szse等)
                - fs_table_type: 财报类型 (hybrid/non_financial等)
                - currency: 货币单位
                - launch_date: 发布日期
                - rebalancing_frequency: 调仓频率 (semi-annually/quarterly等)
                - caculation_method: 计算方法 (grading_weighted等)
                - series: 指数系列分类

        Example:
            获取指数基本信息::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    # 获取指定指数的信息
                    df = await client.index.get_index(
                        stock_codes=["000300", "000905"]
                    )
                    print(df[["name", "stock_code", "source", "launch_date"]])

                    # 获取中证指数系列
                    df = await client.index.get_index(source="csi")
                    print(df[["name", "stock_code"]])

                    # 获取所有指数
                    df = await client.index.get_index()
                    print(f"Total indices: {len(df)}")

        """
        payload: dict[str, Any] = {}
        if stock_codes is not None:
            payload["stockCodes"] = stock_codes
        if source is not None:
            payload["source"] = source

        data = await self._request("POST", "/cn/index", json=payload)
        return get_response_df(data, Index)


# Functional API instance
_api_instance = IndexAPI()


@api
async def get_index(
    stock_codes: list[str] | None = None,
    source: str | None = None,
) -> pd.DataFrame:
    """获取指数基本信息.

    Args:
        stock_codes: 指数代码列表，如 ["000300", "000001"]。不传则返回所有指数
        source: 指数来源筛选 (csi/cni/sse/szse)。不传则返回所有来源

    Returns:
        包含指数基本信息的 DataFrame，包含以下字段:
            - name: 指数名称
            - stock_code: 指数代码
            - area_code: 地区代码
            - market: 市场
            - source: 指数来源
            - fs_table_type: 财报类型
            - currency: 货币单位
            - launch_date: 发布日期
            - rebalancing_frequency: 调仓频率
            - caculation_method: 计算方法
            - series: 指数系列分类

    Example:
        获取指数基本信息::

            from lixinger import get_index

            # 获取指定指数
            df = await get_index(stock_codes=["000300", "000905"])
            print(df[["name", "stock_code", "source"]])

            # 获取中证指数系列
            df = await get_index(source="csi")
            print(df)

    """
    return await _api_instance.get_index(
        stock_codes=stock_codes,
        source=source,
    )
