"""Index tracking fund APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.tracking_fund import TrackingFund
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class TrackingFundAPI(BaseAPI):
    """Index tracking fund APIs."""

    async def get_tracking_fund(
        self,
        stock_code: str,
    ) -> pd.DataFrame:
        """获取跟踪基金.

        API Endpoint: /cn/index/tracking-fund
        API Method: POST
        API Doc: https://www.lixinger.com/open/api/doc?api-key=cn/index/tracking-fund

        Args:
            stock_code: 指数代码，例如 "000001" 表示上证指数

        Returns:
            DataFrame containing tracking fund information:
            - stock_code: 基金代码
            - name: 基金名称
            - short_name: 基金简称
            - area_code: 区域代码
            - market: 市场
            - exchange: 交易所

        Example:
            获取指数跟踪基金::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.cn_index_tracking_fund.get_tracking_fund(
                        stock_code="000001"
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
        }

        data = await self._request("POST", "/cn/index/tracking-fund", json=payload)
        return get_response_df(data, TrackingFund)


# Functional API instance
_api_instance = TrackingFundAPI()


@api
async def get_tracking_fund(
    stock_code: str,
) -> pd.DataFrame:
    """获取跟踪基金.

    Args:
        stock_code: 指数代码

    Returns:
        DataFrame containing tracking fund information

    """
    return await _api_instance.get_tracking_fund(
        stock_code=stock_code,
    )
