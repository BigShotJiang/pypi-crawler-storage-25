"""Index namespace for grouping related APIs."""

from lixinger.api.cn.index.candlestick import IndexCandlestickAPI
from lixinger.api.cn.index.constituent_weightings import ConstituentWeightingsAPI
from lixinger.api.cn.index.constituents import ConstituentsAPI
from lixinger.api.cn.index.drawdown import DrawdownAPI
from lixinger.api.cn.index.fundamental import IndexFundamentalAPI
from lixinger.api.cn.index.index import IndexAPI
from lixinger.api.cn.index.tracking_fund import TrackingFundAPI


class IndexNamespace:
    """Namespace for index-related APIs.

    This class groups all index-related APIs under a single namespace.
    Access APIs via their specific attributes:

    - index: Index information API (get_index)
    - constituents: Index constituents API (get_constituents)
    - constituent_weightings: Index constituent weightings API (get_constituent_weightings)
    - fundamental: Index fundamental data API (get_index_fundamental)
    - candlestick: Index candlestick data API (get_candlestick)
    - drawdown: Index drawdown data API (get_drawdown)
    - tracking_fund: Index tracking fund API (get_tracking_fund)

    """

    def __init__(  # noqa: PLR0913
        self,
        index: IndexAPI,
        constituents: ConstituentsAPI,
        constituent_weightings: ConstituentWeightingsAPI,
        fundamental: IndexFundamentalAPI,
        candlestick: IndexCandlestickAPI,
        drawdown: DrawdownAPI,
        tracking_fund: TrackingFundAPI,
    ):
        """Initialize the index namespace.

        Args:
            index: Index information API
            constituents: Index constituents API
            constituent_weightings: Index constituent weightings API
            fundamental: Index fundamental data API
            candlestick: Index candlestick data API
            drawdown: Index drawdown data API
            tracking_fund: Index tracking fund API

        """
        self.index = index
        self.constituents = constituents
        self.constituent_weightings = constituent_weightings
        self.fundamental = fundamental
        self.candlestick = candlestick
        self.drawdown = drawdown
        self.tracking_fund = tracking_fund

    # Convenience aliases for shorter access
    def get_index(self, *args, **kwargs):
        """Alias for index.get_index."""
        return self.index.get_index(*args, **kwargs)

    def get_constituents(self, *args, **kwargs):
        """Alias for constituents.get_constituents."""
        return self.constituents.get_constituents(*args, **kwargs)

    def get_constituent_weightings(self, *args, **kwargs):
        """Alias for constituent_weightings.get_constituent_weightings."""
        return self.constituent_weightings.get_constituent_weightings(*args, **kwargs)

    def get_fundamental(self, *args, **kwargs):
        """Alias for fundamental.get_fundamental."""
        return self.fundamental.get_fundamental(*args, **kwargs)

    def get_candlestick(self, *args, **kwargs):
        """Alias for candlestick.get_candlestick."""
        return self.candlestick.get_candlestick(*args, **kwargs)

    def get_drawdown(self, *args, **kwargs):
        """Alias for drawdown.get_drawdown."""
        return self.drawdown.get_drawdown(*args, **kwargs)

    def get_tracking_fund(self, *args, **kwargs):
        """Alias for tracking_fund.get_tracking_fund."""
        return self.tracking_fund.get_tracking_fund(*args, **kwargs)
