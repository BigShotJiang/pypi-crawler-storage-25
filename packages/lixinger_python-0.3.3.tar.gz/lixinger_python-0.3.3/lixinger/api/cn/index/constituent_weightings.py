"""Index constituent weightings APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.constituent_weightings import ConstituentWeighting
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class ConstituentWeightingsAPI(BaseAPI):
    """Index constituent weightings APIs."""

    async def get_constituent_weightings(
        self,
        stock_code: str,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """获取指数成分股权重数据.

        API Endpoint: /cn/index/constituent-weightings
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/index/constituent-weightings

        Args:
            stock_code: 指数代码，如 "000300" (沪深300)
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)

        Returns:
            包含指数成分股权重信息的 DataFrame，包含以下字段:
                - date: 日期
                - stock_code: 成分股代码
                - weighting: 权重（0-1之间的浮点数）

        Example:
            获取沪深300指数成分股权重::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    # 查询指定时间段的成分股权重
                    df = await client.index.get_constituent_weightings(
                        stock_code="000300",
                        start_date="2024-01-01",
                        end_date="2024-12-31"
                    )
                    print(df)

                    # 查看权重最大的成分股
                    top_stocks = df.sort_values("weighting", ascending=False).head(10)
                    print(top_stocks)

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
            "endDate": end_date,
        }

        data = await self._request("POST", "/cn/index/constituent-weightings", json=payload)
        return get_response_df(data, ConstituentWeighting)


# Functional API instance
_api_instance = ConstituentWeightingsAPI()


@api
async def get_constituent_weightings(
    stock_code: str,
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    """获取指数成分股权重数据.

    Args:
        stock_code: 指数代码，如 "000300" (沪深300)
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)

    Returns:
        包含指数成分股权重信息的 DataFrame，包含以下字段:
            - date: 日期
            - stock_code: 成分股代码
            - weighting: 权重（0-1之间的浮点数）

    Example:
        获取沪深300指数成分股权重::

            from lixinger import get_constituent_weightings

            # 查询指定时间段的成分股权重
            df = await get_constituent_weightings(
                stock_code="000300",
                start_date="2024-01-01",
                end_date="2024-12-31"
            )
            print(df)

    """
    return await _api_instance.get_constituent_weightings(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
    )
