"""Index drawdown data APIs."""

from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.drawdown import IndexDrawdown
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class DrawdownAPI(BaseAPI):
    """Index drawdown data APIs."""

    async def get_drawdown(
        self,
        type: Literal["normal", "total_return"],
        stock_code: str,
        granularity: Literal["m", "q", "hy", "y1", "y3", "y5", "y10", "fs"],
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """获取指数回撤数据.

        API Endpoint: /cn/index/drawdown
        API Method: POST

        Args:
            type: 指数类型 (normal, total_return)
            stock_code: 指数代码
            granularity: 粒度 (m, q, hy, y1, y3, y5, y10, fs)
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)

        Returns:
            DataFrame containing index drawdown data

        """
        payload: dict[str, Any] = {
            "type": type,
            "stockCode": stock_code,
            "granularity": granularity,
        }
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date

        data = await self._request("POST", "/cn/index/drawdown", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, IndexDrawdown)


# Functional API instance
_api_instance = DrawdownAPI()


@api
async def get_drawdown(
    type: Literal["normal", "total_return"],
    stock_code: str,
    granularity: Literal["m", "q", "hy", "y1", "y3", "y5", "y10", "fs"],
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    """获取指数回撤数据.

    Args:
        type: 指数类型 (normal, total_return)
        stock_code: 指数代码
        granularity: 粒度 (m, q, hy, y1, y3, y5, y10, fs)
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)

    Returns:
        DataFrame containing index drawdown data

    """
    return await _api_instance.get_drawdown(
        type=type,
        stock_code=stock_code,
        granularity=granularity,
        start_date=start_date,
        end_date=end_date,
    )
