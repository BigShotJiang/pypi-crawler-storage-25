"""Index candlestick data APIs."""

from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.index.candlestick import IndexCandlestick
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class IndexCandlestickAPI(BaseAPI):
    """Index candlestick data APIs."""

    async def get_candlestick(
        self,
        type: Literal["normal", "total_return"],
        stock_code: str,
        start_date: str,
        end_date: str,
        adjust_type: Literal["none", "qxw", "hxw"] | None = None,
    ) -> pd.DataFrame:
        """获取指数K线数据.

        API Endpoint: /cn/index/candlestick
        API Method: POST

        Args:
            type: K线类型 (normal, total_return)
            stock_code: 指数代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            adjust_type: 复权类型 (none, qxw, hxw)

        Returns:
            DataFrame containing index candlestick data

        """
        payload: dict[str, Any] = {
            "type": type,
            "stockCode": stock_code,
            "startDate": start_date,
            "endDate": end_date,
        }
        if adjust_type is not None:
            payload["adjustType"] = adjust_type

        data = await self._request("POST", "/cn/index/candlestick", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, IndexCandlestick)


# Functional API instance
_api_instance = IndexCandlestickAPI()


@api
async def get_candlestick(
    type: Literal["normal", "total_return"],
    stock_code: str,
    start_date: str,
    end_date: str,
    adjust_type: Literal["none", "qxw", "hxw"] | None = None,
) -> pd.DataFrame:
    """获取指数K线数据.

    Args:
        type: K线类型 (normal, total_return)
        stock_code: 指数代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)
        adjust_type: 复权类型 (none, qxw, hxw)

    Returns:
        DataFrame containing index candlestick data

    """
    return await _api_instance.get_candlestick(
        type=type,
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        adjust_type=adjust_type,
    )
