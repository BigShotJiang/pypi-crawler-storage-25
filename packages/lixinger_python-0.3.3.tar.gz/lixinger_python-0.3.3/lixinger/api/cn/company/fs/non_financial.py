"""Non-financial statement APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company.fs.non_financial import NonFinancialStatementSchema
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df
from lixinger.utils.dict import flatten_dict


class NonFinancialStatementAPI(BaseAPI):
    """Non-financial statement APIs."""

    async def get_non_financial_statements(
        self,
        stock_codes: list[str],
        metrics: list[str],
        date: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """获取非金融企业财务报表数据.

        API Endpoint: /cn/company/fs/non_financial
        API Method: POST
        API Doc: https://www.lixinger.com/open/api/doc?api-key=cn/company/fs/non_financial

        Args:
            stock_codes: 股票代码列表
            metrics: 指标列表
            date: 日期 (YYYY-MM-DD), 与 startDate 二选一
            start_date: 开始日期 (YYYY-MM-DD), 与 date 二选一
            end_date: 结束日期 (YYYY-MM-DD), 可选

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
            "metricsList": metrics,
        }
        if date is not None:
            payload["date"] = date
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date

        data = await self._request("POST", "/cn/company/fs/non_financial", json=payload)

        # Flatten nested metrics
        flattened_data = [flatten_dict(item) for item in data]

        return get_response_df(flattened_data, NonFinancialStatementSchema)


# Functional API instance
_api_instance = NonFinancialStatementAPI()


@api
async def get_non_financial_statements(
    stock_codes: list[str],
    metrics: list[str],
    date: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    """获取非金融企业财务报表数据."""
    return await _api_instance.get_non_financial_statements(
        stock_codes=stock_codes,
        metrics=metrics,
        date=date,
        start_date=start_date,
        end_date=end_date,
    )
