"""Financial statement APIs."""

from lixinger.api.cn.company.fs.non_financial import get_non_financial_statements

__all__ = ["get_non_financial_statements"]
