from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import Announcement
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class AnnouncementAPI(BaseAPI):
    """Company announcement APIs."""

    async def get_announcement(
        self,
        stock_code: str,
        start_date: str | None = None,
        end_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取公告数据.

        API Endpoint: /cn/company/announcement
        API Method: POST

        Args:
            stock_code: 股票代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            limit: 限制返回数量

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
        }
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/company/announcement", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, Announcement)


# Functional API instance
_api_instance = AnnouncementAPI()


@api
async def get_announcement(
    stock_code: str,
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取公告数据.

    Args:
        stock_code: 股票代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)
        limit: 限制返回数量

    """
    return await _api_instance.get_announcement(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )
