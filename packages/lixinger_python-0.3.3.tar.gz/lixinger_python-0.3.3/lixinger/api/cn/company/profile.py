"""Company profile API."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import CompanyProfile
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class CompanyProfileAPI(BaseAPI):
    """Company profile API."""

    async def get_profile(
        self,
        stock_codes: list[str],
    ) -> pd.DataFrame:
        """获取公司基本概况.

        API Endpoint: /cn/company/profile
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/company/profile

        Args:
            stock_codes: 股票代码列表

        Returns:
            包含公司基本概况的 DataFrame

        Example:
            获取公司概况::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.company.profile.get_profile(
                        stock_codes=["000001", "600036"]
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
        }
        data = await self._request("POST", "/cn/company/profile", json=payload)
        return get_response_df(data, CompanyProfile)


# Functional API instance
_api_instance = CompanyProfileAPI()


@api
async def get_profile(
    stock_codes: list[str],
) -> pd.DataFrame:
    """获取公司基本概况.

    Args:
        stock_codes: 股票代码列表

    Returns:
        包含公司基本概况的 DataFrame

    """
    return await _api_instance.get_profile(
        stock_codes=stock_codes,
    )
