"""Company namespace for grouping related APIs."""

from lixinger.api.cn.company.announcement import AnnouncementAPI
from lixinger.api.cn.company.candlestick import CandlestickAPI
from lixinger.api.cn.company.company import CompanyAPI
from lixinger.api.cn.company.dividend import DividendAPI
from lixinger.api.cn.company.equity_change import EquityChangeAPI
from lixinger.api.cn.company.fs.non_financial import NonFinancialStatementAPI
from lixinger.api.cn.company.fundamental.bank import BankFundamentalAPI
from lixinger.api.cn.company.fundamental.insurance import InsuranceFundamentalAPI
from lixinger.api.cn.company.fundamental.non_financial import NonFinancialFundamentalAPI
from lixinger.api.cn.company.fundamental.other_financial import OtherFinancialFundamentalAPI
from lixinger.api.cn.company.fundamental.security import SecurityFundamentalAPI
from lixinger.api.cn.company.indices import IndicesAPI
from lixinger.api.cn.company.profile import CompanyProfileAPI


class FundamentalNamespace:
    """Namespace for fundamental data APIs.

    Groups all fundamental data APIs by company type:
    - non_financial: Non-financial companies (非金融企业)
    - bank: Banks (银行)
    - insurance: Insurance companies (保险)
    - security: Securities companies (证券)
    - other_financial: Other financial companies (其他金融)
    """

    def __init__(
        self,
        non_financial: NonFinancialFundamentalAPI,
        bank: BankFundamentalAPI,
        insurance: InsuranceFundamentalAPI,
        security: SecurityFundamentalAPI,
        other_financial: OtherFinancialFundamentalAPI,
    ):
        """Initialize the fundamental namespace."""
        self.non_financial = non_financial
        self.bank = bank
        self.insurance = insurance
        self.security = security
        self.other_financial = other_financial


class FSNamespace:
    """Namespace for financial statement APIs."""

    def __init__(self, non_financial: NonFinancialStatementAPI):
        """Initialize the financial statement namespace."""
        self.non_financial = non_financial


class CompanyNamespace:
    """Namespace for company-related APIs.

    This class groups all company-related APIs under a single namespace.
    Access APIs via their specific attributes:

    - company: Company information API
    - profile: Company profile API
    - equity_change: Equity change API
    - fundamental: Fundamental data APIs (contains sub-APIs for different company types)
      - fundamental.non_financial: Non-financial company fundamental data
      - fundamental.bank: Bank fundamental data
      - fundamental.insurance: Insurance company fundamental data
      - fundamental.security: Securities company fundamental data
      - fundamental.other_financial: Other financial company fundamental data
    - candlestick: Candlestick data API
    - fs: Financial statement APIs
      - fs.non_financial: Non-financial statements API
    - indices: Company indices API
    - dividend: Dividend data API
    - announcement: Announcement data API

    """

    def __init__(  # noqa: PLR0913
        self,
        company: CompanyAPI,
        profile: CompanyProfileAPI,
        equity_change: EquityChangeAPI,
        fundamental_non_financial: NonFinancialFundamentalAPI,
        fundamental_bank: BankFundamentalAPI,
        fundamental_insurance: InsuranceFundamentalAPI,
        fundamental_security: SecurityFundamentalAPI,
        fundamental_other_financial: OtherFinancialFundamentalAPI,
        candlestick: CandlestickAPI,
        fs_non_financial: NonFinancialStatementAPI,
        indices: IndicesAPI,
        dividend: DividendAPI,
        announcement: AnnouncementAPI,
    ):
        """Initialize the company namespace.

        Args:
            company: Company information API
            profile: Company profile API
            equity_change: Equity change API
            fundamental_non_financial: Non-financial company fundamental data API
            fundamental_bank: Bank fundamental data API
            fundamental_insurance: Insurance company fundamental data API
            fundamental_security: Securities company fundamental data API
            fundamental_other_financial: Other financial company fundamental data API
            candlestick: Candlestick data API
            fs_non_financial: Non-financial statements API
            indices: Company indices API
            dividend: Dividend data API
            announcement: Announcement data API

        """
        self.company = company
        self.profile = profile
        self.equity_change = equity_change
        self.fundamental = FundamentalNamespace(
            non_financial=fundamental_non_financial,
            bank=fundamental_bank,
            insurance=fundamental_insurance,
            security=fundamental_security,
            other_financial=fundamental_other_financial,
        )
        self.candlestick = candlestick
        self.fs = FSNamespace(non_financial=fs_non_financial)
        self.indices = indices
        self.dividend = dividend
        self.announcement = announcement
