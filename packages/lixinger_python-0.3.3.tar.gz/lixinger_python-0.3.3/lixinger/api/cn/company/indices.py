from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import CompanyIndex
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class IndicesAPI(BaseAPI):
    """Company indices APIs."""

    async def get_indices(
        self,
        stock_code: str,
    ) -> pd.DataFrame:
        """获取股票所属指数.

        API Endpoint: /cn/company/indices
        API Method: POST

        Args:
            stock_code: 股票代码

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
        }
        data = await self._request("POST", "/cn/company/indices", json=payload)
        # Filter out empty dictionaries from the API response
        data = [item for item in data if item]
        return get_response_df(data, CompanyIndex)


# Functional API instance
_api_instance = IndicesAPI()


@api
async def get_indices(
    stock_code: str,
) -> pd.DataFrame:
    """获取股票所属指数.

    Args:
        stock_code: 股票代码

    """
    return await _api_instance.get_indices(
        stock_code=stock_code,
    )
