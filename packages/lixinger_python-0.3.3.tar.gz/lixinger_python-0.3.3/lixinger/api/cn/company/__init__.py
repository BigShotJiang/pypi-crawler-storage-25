"""Company-related APIs."""

from lixinger.api.cn.company.announcement import AnnouncementAPI, get_announcement
from lixinger.api.cn.company.candlestick import CandlestickAPI, get_candlestick
from lixinger.api.cn.company.company import CompanyAPI, get_company
from lixinger.api.cn.company.dividend import DividendAPI, get_dividend
from lixinger.api.cn.company.equity_change import EquityChangeAPI, get_equity_change
from lixinger.api.cn.company.indices import IndicesAPI, get_indices
from lixinger.api.cn.company.profile import CompanyProfileAPI, get_profile

__all__ = [
    # Company info
    "CompanyAPI",
    "get_company",
    "CompanyProfileAPI",
    "get_profile",
    # Equity
    "EquityChangeAPI",
    "get_equity_change",
    # Market data
    "CandlestickAPI",
    "get_candlestick",
    # Corporate actions
    "AnnouncementAPI",
    "get_announcement",
    "DividendAPI",
    "get_dividend",
    # Relations
    "IndicesAPI",
    "get_indices",
]
