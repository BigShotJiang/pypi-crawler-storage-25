"""Bank fundamental data APIs."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company.fundamental.bank import BankFundamentalSchema
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class BankFundamentalAPI(BaseAPI):
    """Bank fundamental data APIs."""

    async def get_bank_fundamental(
        self,
        stock_codes: list[str],
        metrics: list[str],
        date: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """获取银行基本面数据.

        API Endpoint: /cn/company/fundamental/bank
        API Method: POST
        API Doc: https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/bank

        Args:
            stock_codes: 股票代码列表
            metrics: 指标列表
            date: 日期 (YYYY-MM-DD), 与 start_date 二选一
            start_date: 开始日期 (YYYY-MM-DD), 与 date 二选一
            end_date: 结束日期 (YYYY-MM-DD), 可选

        Returns:
            包含银行基本面数据的 DataFrame

        Example:
            获取招商银行的估值指标::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.company.fundamental.bank.get_bank_fundamental(
                        stock_codes=["600036"],
                        metrics=["pe_ttm", "pb", "roe"],
                        start_date="2023-01-01",
                        end_date="2023-12-31"
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCodes": stock_codes,
            "metricsList": metrics,
        }
        if date is not None:
            payload["date"] = date
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date

        data = await self._request("POST", "/cn/company/fundamental/bank", json=payload)
        return get_response_df(data, BankFundamentalSchema)


# Functional API instance
_api_instance = BankFundamentalAPI()


@api
async def get_bank_fundamental(
    stock_codes: list[str],
    metrics: list[str],
    date: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> pd.DataFrame:
    """获取银行基本面数据.

    Args:
        stock_codes: 股票代码列表
        metrics: 指标列表
        date: 日期 (YYYY-MM-DD), 与 start_date 二选一
        start_date: 开始日期 (YYYY-MM-DD), 与 date 二选一
        end_date: 结束日期 (YYYY-MM-DD), 可选

    Returns:
        包含银行基本面数据的 DataFrame

    Example:
        获取招商银行的估值指标::

            from lixinger import get_bank_fundamental

            df = await get_bank_fundamental(
                stock_codes=["600036"],
                metrics=["pe_ttm", "pb", "roe"],
                start_date="2023-01-01",
                end_date="2023-12-31"
            )
            print(df)

    """
    return await _api_instance.get_bank_fundamental(
        stock_codes=stock_codes,
        metrics=metrics,
        date=date,
        start_date=start_date,
        end_date=end_date,
    )
