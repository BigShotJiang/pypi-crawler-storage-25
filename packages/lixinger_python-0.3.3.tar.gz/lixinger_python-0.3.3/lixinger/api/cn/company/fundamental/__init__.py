"""Fundamental data APIs.

This module provides access to fundamental data APIs for different types of companies:
- Non-financial companies (非金融企业)
- Banks (银行)
- Insurance companies (保险)
- Securities companies (证券)
- Other financial companies (其他金融)

Each company type has its own dedicated API endpoint and data model.
"""

from lixinger.api.cn.company.fundamental.bank import (
    BankFundamentalAPI,
    get_bank_fundamental,
)
from lixinger.api.cn.company.fundamental.insurance import (
    InsuranceFundamentalAPI,
    get_insurance_fundamental,
)
from lixinger.api.cn.company.fundamental.non_financial import (
    NonFinancialFundamentalAPI,
    get_non_financial_fundamental,
)
from lixinger.api.cn.company.fundamental.other_financial import (
    OtherFinancialFundamentalAPI,
    get_other_financial_fundamental,
)
from lixinger.api.cn.company.fundamental.security import (
    SecurityFundamentalAPI,
    get_security_fundamental,
)

__all__ = [
    # API Classes
    "BankFundamentalAPI",
    "InsuranceFundamentalAPI",
    "NonFinancialFundamentalAPI",
    "OtherFinancialFundamentalAPI",
    "SecurityFundamentalAPI",
    # Functional APIs
    "get_bank_fundamental",
    "get_insurance_fundamental",
    "get_non_financial_fundamental",
    "get_other_financial_fundamental",
    "get_security_fundamental",
]
