from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import Dividend
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class DividendAPI(BaseAPI):
    """Company dividend APIs."""

    async def get_dividend(
        self,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
        limit: int | None = None,
    ) -> pd.DataFrame:
        """获取分红数据.

        API Endpoint: /cn/company/dividend
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/company/dividend

        Args:
            stock_code: 股票代码
            start_date: 开始日期 (YYYY-MM-DD), 必填。起始时间和结束时间间隔不超过10年
            end_date: 结束日期 (YYYY-MM-DD), 可选。默认值是上周一
            limit: 返回最近数据的数量, 可选

        Returns:
            包含分红数据的 DataFrame

        Example:
            获取分红数据::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.company.dividend.get_dividend(
                        stock_code="600036",
                        start_date="2023-01-01",
                        end_date="2024-01-01"
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
        }
        if end_date is not None:
            payload["endDate"] = end_date
        if limit is not None:
            payload["limit"] = limit

        data = await self._request("POST", "/cn/company/dividend", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, Dividend)


# Functional API instance
_api_instance = DividendAPI()


@api
async def get_dividend(
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
    limit: int | None = None,
) -> pd.DataFrame:
    """获取分红数据.

    Args:
        stock_code: 股票代码
        start_date: 开始日期 (YYYY-MM-DD), 必填。起始时间和结束时间间隔不超过10年
        end_date: 结束日期 (YYYY-MM-DD), 可选。默认值是上周一
        limit: 返回最近数据的数量, 可选

    Returns:
        包含分红数据的 DataFrame

    """
    return await _api_instance.get_dividend(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )
