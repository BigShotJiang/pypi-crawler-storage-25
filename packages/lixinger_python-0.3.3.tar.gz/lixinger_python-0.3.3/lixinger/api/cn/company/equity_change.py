"""Company equity change API."""

from typing import Any

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import EquityChangeData
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class EquityChangeAPI(BaseAPI):
    """Company equity change API."""

    async def get_equity_change(
        self,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """获取股本变动.

        API Endpoint: /cn/company/equity-change
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/company/equity-change

        Args:
            stock_code: 股票代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD), 可选

        Returns:
            包含股本变动信息的 DataFrame

        Example:
            获取股本变动信息::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.company.equity_change.get_equity_change(
                        stock_code="000001",
                        start_date="2023-01-01",
                        end_date="2023-12-31"
                    )
                    print(df)

        """
        payload: dict[str, Any] = {
            "stockCode": stock_code,
            "startDate": start_date,
        }
        if end_date is not None:
            payload["endDate"] = end_date

        data = await self._request("POST", "/cn/company/equity-change", json=payload)
        for item in data:
            item["stockCode"] = stock_code
        return get_response_df(data, EquityChangeData)


# Functional API instance
_api_instance = EquityChangeAPI()


@api
async def get_equity_change(
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
) -> pd.DataFrame:
    """获取股本变动.

    Args:
        stock_code: 股票代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD), 可选

    Returns:
        包含股本变动信息的 DataFrame

    """
    return await _api_instance.get_equity_change(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
    )
