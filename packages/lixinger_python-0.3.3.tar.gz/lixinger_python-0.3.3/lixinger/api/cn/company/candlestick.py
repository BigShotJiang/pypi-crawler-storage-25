from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import Candlestick
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class CandlestickAPI(BaseAPI):
    """Candlestick (K-line) data APIs."""

    async def get_candlestick(
        self,
        type: Literal["1d", "1w", "1m", "5m", "15m", "30m", "60m"],
        stock_code: str,
        start_date: str,
        end_date: str,
        adjust_type: Literal["none", "qxw", "hxw"] | None = None,
    ) -> pd.DataFrame:
        """获取K线数据.

        API Endpoint: /cn/company/candlestick
        API Method: POST

        Args:
            type: K线类型 (1d, 1w, 1m, 5m, 15m, 30m, 60m)
            stock_code: 股票代码
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            adjust_type: 复权类型 (none, qxw, hxw)

        """
        payload: dict[str, Any] = {
            "type": type,
            "stockCode": stock_code,
            "startDate": start_date,
            "endDate": end_date,
        }
        if adjust_type is not None:
            payload["adjustType"] = adjust_type

        data = await self._request("POST", "/cn/company/candlestick", json=payload)
        return get_response_df(data, Candlestick)


# Functional API instance
_api_instance = CandlestickAPI()


@api
async def get_candlestick(
    type: Literal["1d", "1w", "1m", "5m", "15m", "30m", "60m"],
    stock_code: str,
    start_date: str,
    end_date: str,
    adjust_type: Literal["none", "qxw", "hxw"] | None = None,
) -> pd.DataFrame:
    """获取K线数据.

    Args:
        type: K线类型 (1d, 1w, 1m, 5m, 15m, 30m, 60m)
        stock_code: 股票代码
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)
        adjust_type: 复权类型 (none, qxw, hxw)

    """
    return await _api_instance.get_candlestick(
        type=type,
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        adjust_type=adjust_type,
    )
