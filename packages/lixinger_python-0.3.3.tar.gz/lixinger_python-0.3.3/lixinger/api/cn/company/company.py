"""Company information API."""

from typing import Any, Literal

import pandas as pd

from lixinger.api.base import BaseAPI
from lixinger.models.cn.company import Company
from lixinger.utils.api import api
from lixinger.utils.dataframe import get_response_df


class CompanyAPI(BaseAPI):
    """Company information API."""

    async def get_company(
        self,
        fs_type: Literal["non_financial", "bank", "insurance", "security", "other_financial"] | None = None,
        mutual_markets: Literal["ha"] | None = None,
        stock_codes: list[str] | None = None,
        include_delisted: bool | None = None,
    ) -> pd.DataFrame:
        """获取股票详细信息.

        API Endpoint: /cn/company
        API Method: POST
        Documentation: https://www.lixinger.com/open/api/doc?api-key=cn/company

        Args:
            fs_type: 财务报表类型 (non_financial, bank, insurance, security, other_financial)
            mutual_markets: 互联互通市场 (ha)
            stock_codes: 股票代码列表
            include_delisted: 是否包含已退市股票

        Returns:
            包含股票详细信息的 DataFrame

        Example:
            获取股票信息::

                from lixinger import AsyncLixingerClient

                async with AsyncLixingerClient() as client:
                    df = await client.company.company.get_company(
                        stock_codes=["000001", "600036"]
                    )
                    print(df)

        """
        payload: dict[str, Any] = {}
        if fs_type is not None:
            payload["fsType"] = fs_type
        if mutual_markets is not None:
            payload["mutualMarkets"] = mutual_markets
        if stock_codes is not None:
            payload["stockCodes"] = stock_codes
        if include_delisted is not None:
            payload["includeDelisted"] = include_delisted

        data = await self._request("POST", "/cn/company", json=payload)
        return get_response_df(data, Company)


# Functional API instance
_api_instance = CompanyAPI()


@api
async def get_company(
    fs_type: Literal["non_financial", "bank", "insurance", "security", "other_financial"] | None = None,
    mutual_markets: Literal["ha"] | None = None,
    stock_codes: list[str] | None = None,
    include_delisted: bool | None = None,
) -> pd.DataFrame:
    """获取股票详细信息.

    Args:
        fs_type: 财务报表类型 (non_financial, bank, insurance, security, other_financial)
        mutual_markets: 互联互通市场 (ha)
        stock_codes: 股票代码列表
        include_delisted: 是否包含已退市股票

    Returns:
        包含股票详细信息的 DataFrame

    """
    return await _api_instance.get_company(
        fs_type=fs_type,
        mutual_markets=mutual_markets,
        stock_codes=stock_codes,
        include_delisted=include_delisted,
    )
