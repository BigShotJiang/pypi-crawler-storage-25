from typing import Any

import httpx

from lixinger.config import Config, settings
from lixinger.exceptions import APIError, AuthenticationError, RateLimitError
from lixinger.utils.rate_limiter import AsyncRateLimiter
from lixinger.utils.retry import async_retry_on_failure

# Global rate limiter for functional API
_global_rate_limiter = AsyncRateLimiter(max_requests=1000)

# Lazy initialization of global http client to avoid issues with proxy/config changes
_global_http_client: httpx.AsyncClient | None = None


def get_global_client() -> httpx.AsyncClient:
    """Get or create the global HTTP client."""
    global _global_http_client  # noqa: PLW0603
    if _global_http_client is None:
        _global_http_client = httpx.AsyncClient(
            headers={
                "Content-Type": "application/json",
                "Accept-Encoding": "gzip, deflate, br",
            },
            timeout=30.0,
            follow_redirects=True,
        )
    return _global_http_client


class BaseAPI:
    """Base class for API endpoint groups."""

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        config: Config | None = None,
        rate_limiter: AsyncRateLimiter | None = None,
    ):
        self._client = client
        self._config = config or settings
        self._rate_limiter = rate_limiter or _global_rate_limiter

    @async_retry_on_failure(max_retries=3, backoff=1.0)
    async def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        """Make an API request with retry logic and rate limiting."""
        await self._rate_limiter.acquire()

        # Use the provided client or the global one
        client = self._client or get_global_client()
        api_key = self._config.api_key

        # Ensure token is in the payload
        if method.upper() == "POST" and json is not None and "token" not in json:
            json["token"] = api_key
        elif params is not None and "token" not in params:
            params["token"] = api_key

        response = await client.request(
            method,
            f"{self._config.base_url.rstrip('/')}/{endpoint.lstrip('/')}",
            params=params,
            json=json,
        )

        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded", status_code=429)
        if response.status_code == 401:
            raise AuthenticationError("Authentication failed", status_code=401)
        if response.status_code != 200:
            raise APIError(
                f"API request failed with status {response.status_code}: {response.text}",
                status_code=response.status_code,
            )

        data = response.json()
        if not isinstance(data, dict):
            raise APIError(f"API returned unexpected response type: {type(data)}")

        code = data.get("code")
        message = data.get("message")

        if code != 1 or message != "success":
            raise APIError(f"API returned error code {code}: {message}")

        return data.get("data")
