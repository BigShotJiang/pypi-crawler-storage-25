from dataclasses import dataclass
import os

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


@dataclass
class Config:
    """SDK configuration."""

    api_key: str
    base_url: str = "https://open.lixinger.com/api"
    timeout: float = 30.0
    max_retries: int = 3
    retry_backoff: float = 1.0
    max_requests_per_minute: int = 1000
    proxy: str | None = None


def get_config_from_env() -> Config:
    """Load configuration from environment variables.

    Returns:
        Config: Configuration object loaded from environment variables

    Raises:
        ValueError: If LIXINGER_API_KEY is not set

    Environment variables:
        LIXINGER_API_KEY: Your Lixinger API key (required)
        LIXINGER_BASE_URL: Base URL for API requests (optional)
        LIXINGER_TIMEOUT: Request timeout in seconds (optional)
        LIXINGER_MAX_RETRIES: Maximum number of retry attempts (optional)
        LIXINGER_PROXY: Proxy URL (optional)
        LIXINGER_MAX_REQUESTS_PER_MINUTE: Maximum requests per minute (optional)

    """
    api_key = os.getenv("LIXINGER_API_KEY")
    if not api_key:
        msg = "LIXINGER_API_KEY environment variable is not set"
        raise ValueError(msg)

    return Config(
        api_key=api_key,
        base_url=os.getenv("LIXINGER_BASE_URL", "https://open.lixinger.com/api"),
        timeout=float(os.getenv("LIXINGER_TIMEOUT", "30.0")),
        max_retries=int(os.getenv("LIXINGER_MAX_RETRIES", "3")),
        retry_backoff=1.0,
        max_requests_per_minute=int(os.getenv("LIXINGER_MAX_REQUESTS_PER_MINUTE", "1000")),
        proxy=os.getenv("LIXINGER_PROXY"),
    )


# Global settings for functional API usage
# Try to load from environment, fall back to empty config
try:
    settings = get_config_from_env()
except ValueError:
    settings = Config(api_key="")


def set_token(token: str) -> None:
    """Set the global API token.

    Args:
        token: API token to set

    """
    settings.api_key = token
