"""Dividend data models."""

import pandera.pandas as pa


class Dividend(pa.DataFrameModel):
    """Dividend data model.

    API文档: https://www.lixinger.com/open/api/doc?api-key=cn/company/dividend

    Attributes:
        date: 公告日期
        content: 内容
        bonus_shares_from_profit: 送股(股)
        bonus_shares_from_capital_reserve: 转增(股)
        dividend: 分红
        currency: 货币
        dividend_amount: 分红金额
        annual_net_profit: 年度净利润
        annual_net_profit_dividend_ratio: 年度净利润分红比例
        register_date: 股权登记日
        ex_date: 除权除息日
        payment_date: 分红到账日
        fs_end_date: 财报时间
        status: 状态（board_director_plan/shareholders_meeting_plan/company_plan/delay_implementation/cancelled/implemented/terminated/plan）
        stock_code: 股票代码（由SDK添加）

    """

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    # 必填字段
    date: pa.typing.Series[pa.typing.DateTime]
    fs_end_date: pa.typing.Series[pa.typing.DateTime]
    currency: pa.typing.Series[str]
    bonus_shares_from_profit: pa.typing.Series[float]
    bonus_shares_from_capital_reserve: pa.typing.Series[float]
    dividend: pa.typing.Series[float]
    stock_code: pa.typing.Series[str]

    # 可选字段
    content: pa.typing.Series[str] | None = pa.Field(nullable=True)
    status: pa.typing.Series[str] | None = pa.Field(nullable=True)
    register_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    ex_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    payment_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    dividend_amount: pa.typing.Series[float] | None = pa.Field(nullable=True)
    annual_net_profit: pa.typing.Series[float] | None = pa.Field(nullable=True)
    annual_net_profit_dividend_ratio: pa.typing.Series[float] | None = pa.Field(nullable=True)
