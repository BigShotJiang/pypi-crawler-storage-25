"""Bank fundamental data models."""

import pandera.pandas as pa


class BankFundamentalSchema(pa.DataFrameModel):
    """Bank fundamental data model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False  # Allow extra metrics columns

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
