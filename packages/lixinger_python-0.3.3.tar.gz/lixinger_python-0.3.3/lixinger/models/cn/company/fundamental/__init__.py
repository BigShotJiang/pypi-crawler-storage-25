"""Fundamental data models."""

from lixinger.models.cn.company.fundamental.bank import BankFundamentalSchema
from lixinger.models.cn.company.fundamental.insurance import InsuranceFundamentalSchema
from lixinger.models.cn.company.fundamental.non_financial import NonFinancialFundamentalSchema
from lixinger.models.cn.company.fundamental.other_financial import OtherFinancialFundamentalSchema
from lixinger.models.cn.company.fundamental.security import SecurityFundamentalSchema

__all__ = [
    "BankFundamentalSchema",
    "InsuranceFundamentalSchema",
    "NonFinancialFundamentalSchema",
    "OtherFinancialFundamentalSchema",
    "SecurityFundamentalSchema",
]
