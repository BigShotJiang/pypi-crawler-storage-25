"""Insurance company fundamental data models."""

import pandera.pandas as pa


class InsuranceFundamentalSchema(pa.DataFrameModel):
    """Insurance company fundamental data model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False  # Allow extra metrics columns

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
