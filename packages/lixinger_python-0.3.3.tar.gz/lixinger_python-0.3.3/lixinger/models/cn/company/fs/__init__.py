"""Financial statement models."""

from lixinger.models.cn.company.fs.non_financial import NonFinancialStatementSchema

__all__ = ["NonFinancialStatementSchema"]
