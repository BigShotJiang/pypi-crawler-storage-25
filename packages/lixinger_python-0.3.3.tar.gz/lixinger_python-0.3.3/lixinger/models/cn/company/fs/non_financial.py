"""Non-financial statement models."""

import pandera.pandas as pa


class NonFinancialStatementSchema(pa.DataFrameModel):
    """Non-financial statement model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False  # Allow extra metrics columns

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    currency: pa.typing.Series[str]
    report_date: pa.typing.Series[pa.typing.DateTime]
    report_type: pa.typing.Series[str]
    standard_date: pa.typing.Series[pa.typing.DateTime]
