"""Equity change data models."""

import pandera.pandas as pa


class EquityChangeData(pa.DataFrameModel):
    """Equity change data model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    date: pa.typing.Series[pa.typing.DateTime]
    declaration_date: pa.typing.Series[pa.typing.DateTime]
    change_reason: pa.typing.Series[str]
    capitalization: pa.typing.Series[float]
    outstanding_shares_a: pa.typing.Series[float]
    limited_shares_a: pa.typing.Series[float]
    change_reason_types: pa.typing.Series[str]
    capitalization_change_ratio: pa.typing.Series[float]
    outstanding_shares_a_change_ratio: pa.typing.Series[float]
    outstanding_shares_h_change_ratio: pa.typing.Series[float]
    limited_shares_a_change_ratio: pa.typing.Series[float]
    stock_code: pa.typing.Series[str]
