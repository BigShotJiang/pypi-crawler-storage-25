"""Company basic information models."""

import pandera.pandas as pa


class Company(pa.DataFrameModel):
    """Company information model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    name: pa.typing.Series[str]
    stock_code: pa.typing.Series[str]
    area_code: pa.typing.Series[str]
    market: pa.typing.Series[str]
    fs_table_type: pa.typing.Series[str] | None = pa.Field(nullable=True)
    mutual_markets: pa.typing.Series[str] | None = pa.Field(nullable=True)
    ipo_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    delisted_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)


class CompanyProfile(pa.DataFrameModel):
    """Company profile model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False  # Allow extra profile columns

    stock_code: pa.typing.Series[str]
