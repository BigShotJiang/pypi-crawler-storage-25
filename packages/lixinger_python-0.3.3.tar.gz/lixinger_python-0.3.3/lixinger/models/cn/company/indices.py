"""Company index model."""

import pandera.pandas as pa


class CompanyIndex(pa.DataFrameModel):
    """Company index model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    area_code: pa.typing.Series[str]
    stock_code: pa.typing.Series[str]
    source: pa.typing.Series[str]
    name: pa.typing.Series[str]
