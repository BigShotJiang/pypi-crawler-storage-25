"""Index candlestick data models."""

import pandera.pandas as pa


class IndexCandlestick(pa.DataFrameModel):
    """Index candlestick data model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    open: pa.typing.Series[float]
    high: pa.typing.Series[float]
    low: pa.typing.Series[float]
    close: pa.typing.Series[float]
    volume: pa.typing.Series[float]
    amount: pa.typing.Series[float]
    change: pa.typing.Series[float]
