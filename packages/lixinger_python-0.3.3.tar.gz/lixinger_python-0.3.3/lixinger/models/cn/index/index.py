"""Index information models."""

import pandera.pandas as pa


class Index(pa.DataFrameModel):
    """Index information model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    name: pa.typing.Series[str]
    stock_code: pa.typing.Series[str]
    area_code: pa.typing.Series[str]
    market: pa.typing.Series[str]
    source: pa.typing.Series[str]
    fs_table_type: pa.typing.Series[str] | None = pa.Field(nullable=True)
    currency: pa.typing.Series[str] | None = pa.Field(nullable=True)
    launch_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    rebalancing_frequency: pa.typing.Series[str] | None = pa.Field(nullable=True)
    caculation_method: pa.typing.Series[str] | None = pa.Field(nullable=True)
    series: pa.typing.Series[str] | None = pa.Field(nullable=True)
