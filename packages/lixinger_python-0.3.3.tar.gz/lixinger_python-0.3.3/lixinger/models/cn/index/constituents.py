"""Index constituents models."""

import pandera.pandas as pa


class Constituent(pa.DataFrameModel):
    """Index constituents model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    index_stock_code: pa.typing.Series[str]
    stock_code: pa.typing.Series[str]
    area_code: pa.typing.Series[str]
    market: pa.typing.Series[str]
