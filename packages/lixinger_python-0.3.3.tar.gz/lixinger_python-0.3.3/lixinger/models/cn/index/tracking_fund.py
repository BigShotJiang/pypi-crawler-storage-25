"""Tracking fund models."""

import pandera.pandas as pa


class TrackingFund(pa.DataFrameModel):
    """Tracking fund model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    stock_code: pa.typing.Series[str]
    name: pa.typing.Series[str]
    short_name: pa.typing.Series[str]
    area_code: pa.typing.Series[str]
    market: pa.typing.Series[str]
    exchange: pa.typing.Series[str]
