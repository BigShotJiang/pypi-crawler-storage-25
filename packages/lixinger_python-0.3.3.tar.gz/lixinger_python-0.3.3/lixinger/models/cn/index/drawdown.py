"""Index drawdown models."""

import pandera.pandas as pa


class IndexDrawdown(pa.DataFrameModel):
    """Index drawdown model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    value: pa.typing.Series[float]
