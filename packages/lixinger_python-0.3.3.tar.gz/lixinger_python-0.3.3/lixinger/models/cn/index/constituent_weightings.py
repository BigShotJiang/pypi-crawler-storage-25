"""Index constituent weightings models."""

import pandera.pandas as pa


class ConstituentWeighting(pa.DataFrameModel):
    """Index constituent weighting model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    weighting: pa.typing.Series[float]
