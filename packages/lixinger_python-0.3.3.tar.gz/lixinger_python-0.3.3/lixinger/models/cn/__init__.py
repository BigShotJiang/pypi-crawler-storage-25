"""China market models."""
