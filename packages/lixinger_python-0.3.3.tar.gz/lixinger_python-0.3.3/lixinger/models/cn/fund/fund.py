"""Fund basic information models."""

import pandera.pandas as pa


class Fund(pa.DataFrameModel):
    """Fund information model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    stock_code: pa.typing.Series[str]
    name: pa.typing.Series[str]
    short_name: pa.typing.Series[str]
    fund_first_level: pa.typing.Series[str] | None = pa.Field(nullable=True)
    fund_second_level: pa.typing.Series[str] | None = pa.Field(nullable=True)
    area_code: pa.typing.Series[str]
    market: pa.typing.Series[str]
    exchange: pa.typing.Series[str]
    inception_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    delisted_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
