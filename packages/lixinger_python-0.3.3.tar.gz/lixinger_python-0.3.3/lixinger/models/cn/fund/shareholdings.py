"""Fund shareholdings models."""

import pandera.pandas as pa


class Shareholding(pa.DataFrameModel):
    """Fund shareholdings model."""

    class Config:
        """Pandera configuration."""

        coerce = True

    fund_stock_code: pa.typing.Series[str]
    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    name: pa.typing.Series[str] | None = pa.Field(nullable=True)
    holdings: pa.typing.Series[float]
    market_cap: pa.typing.Series[float]
    net_value_ratio: pa.typing.Series[float]
    stock_area_code: pa.typing.Series[str] | None = pa.Field(nullable=True)
