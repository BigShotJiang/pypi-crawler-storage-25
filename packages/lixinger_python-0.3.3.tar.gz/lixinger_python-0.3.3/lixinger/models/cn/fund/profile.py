"""Fund profile models."""

import pandera.pandas as pa


class FundProfile(pa.DataFrameModel):
    """Fund profile model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    feeder_funds: pa.typing.Series[str] | None = pa.Field(nullable=True)
    c_name: pa.typing.Series[str] | None = pa.Field(nullable=True)
    e_t_short_name: pa.typing.Series[str] | None = pa.Field(nullable=True)
    f_c_name: pa.typing.Series[str] | None = pa.Field(nullable=True)
    inception_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
    op_mode: pa.typing.Series[str] | None = pa.Field(nullable=True)
    m_stock_code: pa.typing.Series[str] | None = pa.Field(nullable=True)
    investment_o: pa.typing.Series[str] | None = pa.Field(nullable=True)
    investment_s: pa.typing.Series[str] | None = pa.Field(nullable=True)
    p_c_benchmark: pa.typing.Series[str] | None = pa.Field(nullable=True)
    risk_r_c: pa.typing.Series[str] | None = pa.Field(nullable=True)
    ipo_date: pa.typing.Series[pa.typing.DateTime] | None = pa.Field(nullable=True)
