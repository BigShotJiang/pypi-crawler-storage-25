"""Fund asset combination models."""

import pandera.pandas as pa


class AssetCombination(pa.DataFrameModel):
    """Fund asset combination model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    date: pa.typing.Series[pa.typing.DateTime]
    stock_code: pa.typing.Series[str]
    ei: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """权益投资"""
    ei_c: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """权益投资（股票）"""
    fii: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """固定收益投资"""
    fii_b: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """固定收益投资（债券）"""
    bs_a_sr: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """银行存款和结算备付金"""
    oa: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """其他资产"""
    pmi: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """贵金属投资"""
    ei_r: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """权益投资占比"""
    fii_r: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """固定收益投资占比"""
    bs_a_sr_r: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """银行存款和结算备付金占比"""
    oa_r: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """其他资产占比"""
    pmi_r: pa.typing.Series[float] | None = pa.Field(nullable=True)
    """贵金属投资占比"""
