"""Fund asset industry combination models."""

import pandera.pandas as pa


class AssetIndustryCombination(pa.DataFrameModel):
    """Fund asset industry combination model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    date: pa.typing.Series[pa.typing.DateTime]
    """财报日期"""
    stock_code: pa.typing.Series[str]
    """基金代码"""
    name: pa.typing.Series[str]
    """行业名称"""
    value: pa.typing.Series[float]
    """公允价值"""
    proportion: pa.typing.Series[float]
    """比例"""
