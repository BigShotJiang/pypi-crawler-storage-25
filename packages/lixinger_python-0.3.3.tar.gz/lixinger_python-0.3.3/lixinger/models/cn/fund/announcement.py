"""Fund announcement data models."""

import pandera.pandas as pa


class Announcement(pa.DataFrameModel):
    """Fund announcement data model."""

    class Config:
        """Pandera configuration."""

        coerce = True
        strict = False

    link_url: pa.typing.Series[str]
    date: pa.typing.Series[pa.typing.DateTime]
    link_text: pa.typing.Series[str]
    link_type: pa.typing.Series[str]
    lang: pa.typing.Series[str]
    types: pa.typing.Series[str]
    stock_code: pa.typing.Series[str]
