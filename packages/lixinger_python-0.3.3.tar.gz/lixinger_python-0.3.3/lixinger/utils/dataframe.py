import re
from typing import Any

import pandas as pd
import pandera.pandas as pa


def camel_to_snake(name: str) -> str:
    """Convert camelCase string to snake_case."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def get_response_df(data: Any, model: type[pa.DataFrameModel]) -> pd.DataFrame:
    """Convert API response data to a validated pandas DataFrame."""
    if not data:
        return pd.DataFrame()

    df = pd.DataFrame(data)
    if df.empty:
        return df

    # Rename columns from camelCase to snake_case
    df = df.rename(columns=camel_to_snake)

    # Handle mutual_markets list to string if it exists
    if "mutual_markets" in df.columns:
        df["mutual_markets"] = df["mutual_markets"].apply(lambda x: ",".join(x) if isinstance(x, list) else x)

    # Handle change_reason_types list to string if it exists
    if "change_reason_types" in df.columns:
        df["change_reason_types"] = df["change_reason_types"].apply(lambda x: ",".join(x) if isinstance(x, list) else x)

    # Handle types list to string if it exists
    if "types" in df.columns:
        df["types"] = df["types"].apply(lambda x: ",".join(x) if isinstance(x, list) else x)

    # Handle feeder_funds list to string if it exists
    if "feeder_funds" in df.columns:
        df["feeder_funds"] = df["feeder_funds"].apply(lambda x: ",".join(x) if isinstance(x, list) else x)

    # Handle p_c_benchmark list to string if it exists
    if "p_c_benchmark" in df.columns:
        df["p_c_benchmark"] = df["p_c_benchmark"].apply(lambda x: ",".join(x) if isinstance(x, list) else x)

    # Handle datetime columns to support mixed timezones by taking the face time
    schema = model.to_schema()
    for col_name, col in schema.columns.items():
        if (
            "datetime" in str(col.dtype).lower()
            and col_name in df.columns
            and not pd.api.types.is_datetime64_any_dtype(df[col_name])
        ):
            # Extract face time to avoid mixed timezone issues (e.g. historical DST)
            df[col_name] = pd.to_datetime(df[col_name].astype(str).str.slice(0, 19), errors="coerce")

    # Validate the DataFrame using the pandera model
    return model.validate(df)
