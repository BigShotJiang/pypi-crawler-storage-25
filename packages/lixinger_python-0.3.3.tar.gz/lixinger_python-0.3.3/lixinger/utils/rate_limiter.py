import asyncio
from collections import deque
import time


class AsyncRateLimiter:
    """Async token bucket rate limiter."""

    def __init__(self, max_requests: int, window: float = 60.0):
        self.max_requests = max_requests
        self.window = window
        self.requests: deque[float] = deque()

    async def acquire(self) -> None:
        """Wait if necessary to respect rate limit."""
        now = time.time()

        # Remove old requests outside the window
        while self.requests and self.requests[0] <= now - self.window:
            self.requests.popleft()

        # Wait if at limit
        while len(self.requests) >= self.max_requests:
            now = time.time()
            # Remove old requests again inside the loop
            while self.requests and self.requests[0] <= now - self.window:
                self.requests.popleft()

            if len(self.requests) < self.max_requests:
                break

            sleep_time = self.window - (now - self.requests[0])
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)

        self.requests.append(time.time())
