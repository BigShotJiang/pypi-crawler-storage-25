from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


def api(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """Decorate async API functions to handle common logic."""

    @wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        return await func(*args, **kwargs)

    return wrapper
