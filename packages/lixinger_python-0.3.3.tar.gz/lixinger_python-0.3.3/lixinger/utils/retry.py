import asyncio
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


def async_retry_on_failure(
    max_retries: int = 3,
    backoff: float = 1.0,
    retry_on: tuple[type[Exception], ...] = (Exception,),
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Retry failed async requests with exponential backoff."""

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except retry_on as e:
                    if attempt == max_retries:
                        raise
                    wait_time = backoff * (2**attempt)
                    await asyncio.sleep(wait_time)
            raise RuntimeError("Unreachable")

        return wrapper

    return decorator
