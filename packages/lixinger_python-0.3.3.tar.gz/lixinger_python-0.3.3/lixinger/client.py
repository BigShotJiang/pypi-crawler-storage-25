import httpx

from lixinger.api.cn.company.announcement import AnnouncementAPI
from lixinger.api.cn.company.candlestick import CandlestickAPI
from lixinger.api.cn.company.company import CompanyAPI
from lixinger.api.cn.company.dividend import DividendAPI
from lixinger.api.cn.company.equity_change import EquityChangeAPI
from lixinger.api.cn.company.fs.non_financial import NonFinancialStatementAPI
from lixinger.api.cn.company.fundamental.bank import BankFundamentalAPI
from lixinger.api.cn.company.fundamental.insurance import InsuranceFundamentalAPI
from lixinger.api.cn.company.fundamental.non_financial import NonFinancialFundamentalAPI
from lixinger.api.cn.company.fundamental.other_financial import OtherFinancialFundamentalAPI
from lixinger.api.cn.company.fundamental.security import SecurityFundamentalAPI
from lixinger.api.cn.company.indices import IndicesAPI
from lixinger.api.cn.company.namespace import CompanyNamespace
from lixinger.api.cn.company.profile import CompanyProfileAPI
from lixinger.api.cn.fund import (
    FundAnnouncementAPI,
    FundAPI,
    FundAssetCombinationAPI,
    FundAssetIndustryCombinationAPI,
    FundCandlestickAPI,
    FundProfileAPI,
    FundShareholdingsAPI,
)
from lixinger.api.cn.index import (
    ConstituentsAPI,
    ConstituentWeightingsAPI,
    DrawdownAPI,
    IndexAPI,
    IndexCandlestickAPI,
    IndexFundamentalAPI,
    TrackingFundAPI,
)
from lixinger.api.cn.index.namespace import IndexNamespace
from lixinger.config import get_config_from_env
from lixinger.utils.rate_limiter import AsyncRateLimiter


class AsyncLixingerClient:
    """Async main client for Lixinger API.

    Configuration is loaded from environment variables via .env file.
    The API key is ALWAYS loaded from the LIXINGER_API_KEY environment variable.

    """

    def __init__(  # noqa: PLR0913
        self,
        *,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int | None = None,
        proxy: str | None = None,
        max_requests_per_minute: int = 1000,
    ):
        """Initialize the async Lixinger API client.

        The API key is ALWAYS loaded from the LIXINGER_API_KEY environment variable.
        Other parameters can be overridden or will be loaded from environment variables.

        Args:
            base_url: Base URL for API requests (defaults to LIXINGER_BASE_URL env var
                or https://open.lixinger.com/api)
            timeout: Request timeout in seconds (defaults to LIXINGER_TIMEOUT env var or 30.0)
            max_retries: Maximum number of retry attempts (defaults to LIXINGER_MAX_RETRIES
                env var or 3)
            proxy: Optional proxy URL (defaults to LIXINGER_PROXY env var)
            max_requests_per_minute: Maximum number of requests per minute (defaults to
                LIXINGER_MAX_REQUESTS_PER_MINUTE env var or 1000)

        Raises:
            ValueError: If LIXINGER_API_KEY environment variable is not set

        Example:
            # Load all config from .env file
            async with AsyncLixingerClient() as client:
                df = await client.company.get_company(["000001"])

            # Override specific settings
            async with AsyncLixingerClient(timeout=60.0, proxy="socks5://localhost:1080") as client:
                df = await client.company.get_company(["000001"])

        """
        # Always load config from environment
        env_config = get_config_from_env()

        # Use env config but allow overrides for non-sensitive settings
        self.config = env_config
        if base_url is not None:
            self.config.base_url = base_url
        if timeout is not None:
            self.config.timeout = timeout
        if max_retries is not None:
            self.config.max_retries = max_retries
        if proxy is not None:
            self.config.proxy = proxy
        if max_requests_per_minute is not None:
            self.config.max_requests_per_minute = max_requests_per_minute

        headers = {
            "Content-Type": "application/json",
            "Accept-Encoding": "gzip, deflate, br",
        }

        limits = httpx.Limits(max_connections=10, max_keepalive_connections=5)

        self._http_client = httpx.AsyncClient(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
            proxy=proxy,
            limits=limits,
        )

        self._rate_limiter = AsyncRateLimiter(max_requests=max_requests_per_minute)

        # Company APIs
        cn_company = CompanyAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_profile = CompanyProfileAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_equity_change = EquityChangeAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_fundamental_non_financial = NonFinancialFundamentalAPI(
            self._http_client, self.config, self._rate_limiter
        )
        cn_company_fundamental_bank = BankFundamentalAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_fundamental_insurance = InsuranceFundamentalAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_fundamental_security = SecurityFundamentalAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_fundamental_other_financial = OtherFinancialFundamentalAPI(
            self._http_client, self.config, self._rate_limiter
        )
        cn_company_candlestick = CandlestickAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_fs_non_financial = NonFinancialStatementAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_indices = IndicesAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_dividend = DividendAPI(self._http_client, self.config, self._rate_limiter)
        cn_company_announcement = AnnouncementAPI(self._http_client, self.config, self._rate_limiter)

        # Company namespace (groups all company APIs)
        self.cn_company = CompanyNamespace(
            company=cn_company,
            profile=cn_company_profile,
            equity_change=cn_company_equity_change,
            fundamental_non_financial=cn_company_fundamental_non_financial,
            fundamental_bank=cn_company_fundamental_bank,
            fundamental_insurance=cn_company_fundamental_insurance,
            fundamental_security=cn_company_fundamental_security,
            fundamental_other_financial=cn_company_fundamental_other_financial,
            candlestick=cn_company_candlestick,
            fs_non_financial=cn_company_fs_non_financial,
            indices=cn_company_indices,
            dividend=cn_company_dividend,
            announcement=cn_company_announcement,
        )

        # Legacy flat access (deprecated, for backward compatibility)
        self.cn_company_candlestick = cn_company_candlestick
        self.cn_company_fs_non_financial = cn_company_fs_non_financial
        self.cn_company_indices = cn_company_indices
        self.cn_company_dividend = cn_company_dividend
        self.cn_company_announcement = cn_company_announcement

        # Index APIs
        cn_index = IndexAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_constituents = ConstituentsAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_constituent_weightings = ConstituentWeightingsAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_candlestick = IndexCandlestickAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_drawdown = DrawdownAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_fundamental = IndexFundamentalAPI(self._http_client, self.config, self._rate_limiter)
        cn_index_tracking_fund = TrackingFundAPI(self._http_client, self.config, self._rate_limiter)

        # Index namespace (groups all index APIs)
        self.cn_index = IndexNamespace(
            index=cn_index,
            constituents=cn_index_constituents,
            constituent_weightings=cn_index_constituent_weightings,
            fundamental=cn_index_fundamental,
            candlestick=cn_index_candlestick,
            drawdown=cn_index_drawdown,
            tracking_fund=cn_index_tracking_fund,
        )

        # Legacy flat access for index APIs (deprecated, for backward compatibility)
        self.cn_index_constituents = cn_index_constituents
        self.cn_index_constituent_weightings = cn_index_constituent_weightings
        self.cn_index_candlestick = cn_index_candlestick
        self.cn_index_drawdown = cn_index_drawdown
        self.cn_index_fundamental = cn_index_fundamental
        self.cn_index_tracking_fund = cn_index_tracking_fund

        # Fund APIs
        self.cn_fund = FundAPI(self._http_client, self.config, self._rate_limiter)
        self.cn_fund_profile = FundProfileAPI(self._http_client, self.config, self._rate_limiter)
        self.cn_fund_candlestick = FundCandlestickAPI(self._http_client, self.config, self._rate_limiter)
        self.cn_fund_shareholdings = FundShareholdingsAPI(self._http_client, self.config, self._rate_limiter)
        self.cn_fund_asset_combination = FundAssetCombinationAPI(self._http_client, self.config, self._rate_limiter)
        self.cn_fund_asset_industry_combination = FundAssetIndustryCombinationAPI(
            self._http_client, self.config, self._rate_limiter
        )
        self.cn_fund_announcement = FundAnnouncementAPI(self._http_client, self.config, self._rate_limiter)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self):
        """Close the underlying HTTP client."""
        await self._http_client.aclose()

    @property
    def company(self) -> CompanyNamespace:
        """Alias for cn_company."""
        return self.cn_company

    @property
    def index(self) -> IndexNamespace:
        """Alias for cn_index."""
        return self.cn_index

    @property
    def candlestick(self) -> CandlestickAPI:
        """Alias for cn_company_candlestick."""
        return self.cn_company_candlestick

    @property
    def indices(self) -> IndicesAPI:
        """Alias for cn_company_indices."""
        return self.cn_company_indices
