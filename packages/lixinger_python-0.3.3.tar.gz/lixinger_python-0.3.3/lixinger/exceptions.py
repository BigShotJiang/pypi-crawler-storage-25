class LixingerError(Exception):
    """Base exception for Lixinger SDK."""


class APIError(LixingerError):
    """API request failed."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class RateLimitError(APIError):
    """Rate limit exceeded (429)."""


class AuthenticationError(APIError):
    """Authentication failed (401)."""


class ValidationError(LixingerError):
    """Request validation failed."""
