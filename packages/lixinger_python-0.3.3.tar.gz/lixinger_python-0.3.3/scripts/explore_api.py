#!/usr/bin/env python3
"""Explore Lixinger API to understand real response structures.

This script makes real API calls and prints the responses to help
understand the API structure and create accurate mocks.

Usage:
    python scripts/explore_api.py
"""

import json
import os
from pathlib import Path
import sys
from typing import Any

import pandas as pd

from lixinger import LixingerClient


def save_response(name: str, data: Any) -> None:
    """Save response to file for reference."""
    output_dir = Path("tests/fixtures/examples")
    output_dir.mkdir(parents=True, exist_ok=True)

    save_data = data.to_dict(orient="records") if isinstance(data, pd.DataFrame) else data

    output_file = output_dir / f"{name}_response.json"
    with output_file.open("w", encoding="utf-8") as f:
        json.dump(save_data, f, indent=2, ensure_ascii=False)

    print(f"✓ Saved to: {output_file}")


def print_structure(name: str, data: Any) -> None:
    """Print response structure for analysis."""
    print(f"\n{'=' * 60}")
    print(f"{name.upper()} Response Structure")
    print("=" * 60)

    if isinstance(data, pd.DataFrame):
        print(f"Type: pandas.DataFrame with {len(data)} rows")
        print(f"Columns: {data.columns.tolist()}")
        print("\nFirst row sample:")
        if not data.empty:
            print(json.dumps(data.iloc[0].to_dict(), indent=2, ensure_ascii=False))
    elif isinstance(data, list) and len(data) > 0:
        print(f"Type: list with {len(data)} items")
        print(f"First item keys: {list(data[0].keys())}")
        print("\nFirst item sample:")
        print(json.dumps(data[0], indent=2, ensure_ascii=False))
    elif isinstance(data, dict):
        print("Type: dict")
        print(f"Keys: {list(data.keys())}")
        print("\nSample:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print(f"Type: {type(data)}")
        print(f"Value: {data}")


def main():
    """Explore API endpoints."""
    # Check API key
    api_key = os.getenv("LIXINGER_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        print("❌ Error: No valid LIXINGER_API_KEY found in .env")
        print("   Please set your API key in the .env file")
        return 1

    print("🔍 Exploring Lixinger API...")
    print(f"   Using API key: {api_key[:10]}...")

    client = LixingerClient()

    try:
        # Test 1: Get company information
        print("\n📊 Testing: company.get_company()")
        result = client.company.get_company(stock_codes=["600036"])
        print_structure("company", result)
        save_response("company", result)

        # Test 2: Multiple stock codes
        print("\n📊 Testing: company.get_company() with multiple codes")
        result = client.company.get_company(stock_codes=["600036", "000001"])
        print(f"Returned {len(result)} records")

        # Test 3: Get company profile
        print("\n📊 Testing: company.get_profile()")
        result = client.company.get_profile(stock_codes=["600036"])
        print_structure("profile", result)
        save_response("profile", result)

        # Add more endpoint tests here as needed
        print("\n" + "=" * 60)
        print("✓ Exploration complete!")
        print("=" * 60)
        print("\nNext steps:")
        print("1. Review saved responses in tests/fixtures/examples/")
        print("2. Update mocks in tests/ to match real response structure")
        print("3. Add assertions based on real field names")

        return 0

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback

        traceback.print_exc()
        return 1

    finally:
        client.close()


if __name__ == "__main__":
    sys.exit(main())
