#!/usr/bin/env bash
# Quick publish script for lixinger-python
# Usage: ./scripts/publish.sh [test|prod]

set -e

TARGET="${1:-test}"  # Default to test

echo "🔍 Running pre-publication checks..."

# Run linters
echo "  ├─ Running ruff check..."
uv run ruff check .

echo "  ├─ Running ruff format check..."
uv run ruff format --check .

# Run type checker
echo "  ├─ Running mypy..."
uv run mypy lixinger/

# Run tests
echo "  └─ Running tests..."
uv run pytest -m "not integration" -q

echo "✅ All checks passed!"

# Clean previous builds
echo "🧹 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info

# Build the package
echo "📦 Building package..."
uv run python -m build

# Check the build
echo "🔍 Checking package..."
uv run twine check dist/*

# Upload
if [ "$TARGET" = "prod" ]; then
    echo "🚀 Publishing to PyPI (PRODUCTION)..."
    echo "⚠️  Are you sure? This cannot be undone!"
    read -p "Press Enter to continue or Ctrl+C to cancel..."
    uv run twine upload dist/*
    echo "✅ Published to PyPI!"
    echo "📌 Don't forget to tag the release:"
    echo "   git tag -a v$(grep '^version' pyproject.toml | cut -d'"' -f2) -m 'Release version $(grep '^version' pyproject.toml | cut -d'"' -f2)'"
    echo "   git push origin v$(grep '^version' pyproject.toml | cut -d'"' -f2)"
else
    echo "🧪 Publishing to TestPyPI..."
    uv run twine upload --repository testpypi dist/*
    echo "✅ Published to TestPyPI!"
    echo "📌 Test installation:"
    echo "   pip install --index-url https://test.pypi.org/simple/ lixinger-python"
fi
