"""Generate API documentation pages from API modules.

This script auto-generates markdown files for all API endpoints with correct usage examples.
"""

from pathlib import Path

# API documentation templates
API_DOCS = {
    # Company APIs
    "company/company.md": {
        "title": "公司信息",
        "description": "获取股票的详细信息。",
        "endpoint": "POST /cn/company",
        "module": "lixinger.api.cn.company.company.CompanyAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_company

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.company.get_company(
            stock_codes=["000001", "600036"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_company(stock_codes=["000001", "600036"])
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company",
    },
    "company/profile.md": {
        "title": "公司概况",
        "description": "获取公司的基本概况信息。",
        "endpoint": "POST /cn/company/profile",
        "module": "lixinger.api.cn.company.profile.CompanyProfileAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_profile

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.profile.get_profile(
            stock_codes=["000001", "600036"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_profile(stock_codes=["000001", "600036"])
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/profile",
    },
    "company/equity_change.md": {
        "title": "股本变动",
        "description": "获取公司的股本变动历史信息。",
        "endpoint": "POST /cn/company/equity-change",
        "module": "lixinger.api.cn.company.equity_change.EquityChangeAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_equity_change

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.equity_change.get_equity_change(
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_equity_change(
        stock_code="000001",
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/equity-change",
    },
    "company/candlestick.md": {
        "title": "K线数据",
        "description": "获取股票的K线（蜡烛图）数据。",
        "endpoint": "POST /cn/company/candlestick",
        "module": "lixinger.api.cn.company.candlestick.CandlestickAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_candlestick

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.candlestick.get_candlestick(
            type="1d",
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31",
            adjust_type="hxw"  # 后复权
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_candlestick(
        type="1d",
        stock_code="000001",
        start_date="2023-01-01",
        end_date="2023-12-31",
        adjust_type="hxw"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/candlestick",
    },
    "company/indices.md": {
        "title": "所属指数",
        "description": "获取股票所属的指数列表。",
        "endpoint": "POST /cn/company/indices",
        "module": "lixinger.api.cn.company.indices.IndicesAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_indices

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.indices.get_indices(
            stock_code="000001"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_indices(stock_code="000001")
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/indices",
    },
    "company/announcement.md": {
        "title": "公告",
        "description": "获取公司公告数据。",
        "endpoint": "POST /cn/company/announcement",
        "module": "lixinger.api.cn.company.announcement.AnnouncementAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient

async def example():
    async with AsyncLixingerClient() as client:
        df = await client.company.announcement.get_announcement(
            stock_code="000001",
            start_date="2023-01-01",
            limit=10
        )
        print(df)

asyncio.run(example())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/announcement",
    },
    "company/dividend.md": {
        "title": "分红",
        "description": "获取公司分红数据。",
        "endpoint": "POST /cn/company/dividend",
        "module": "lixinger.api.cn.company.dividend.DividendAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient

async def example():
    async with AsyncLixingerClient() as client:
        df = await client.company.dividend.get_dividend(
            stock_code="000001",
            start_date="2020-01-01",
            end_date="2023-12-31"
        )
        print(df)

asyncio.run(example())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/dividend",
    },
    "company/fs/non_financial.md": {
        "title": "财务报表",
        "description": "获取非金融企业的详细财务报表数据。",
        "endpoint": "POST /cn/company/fs/non_financial",
        "module": "lixinger.api.cn.company.fs.non_financial.NonFinancialStatementAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_non_financial_statements

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fs.non_financial.get_non_financial_statements(
            stock_codes=["000001", "600000"],
            metrics=["revenue", "profit", "assets", "debt"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_non_financial_statements(
        stock_codes=["000001", "600000"],
        metrics=["revenue", "profit"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fs/non_financial",
    },
    "company/fundamental/non_financial.md": {
        "title": "非金融企业基本面",
        "description": "获取非金融企业的基本面指标数据。",
        "endpoint": "POST /cn/company/fundamental/non_financial",
        "module": "lixinger.api.cn.company.fundamental.non_financial.NonFinancialFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_non_financial_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.non_financial.get_non_financial_fundamental(
            stock_codes=["000001", "600000"],
            metrics=["pe_ttm", "pb", "roe"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_non_financial_fundamental(
        stock_codes=["000001", "600000"],
        metrics=["pe_ttm", "pb", "roe"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/non_financial",
    },
    "company/fundamental/bank.md": {
        "title": "银行基本面",
        "description": "获取银行股票的基本面指标数据。",
        "endpoint": "POST /cn/company/fundamental/bank",
        "module": "lixinger.api.cn.company.fundamental.bank.BankFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_bank_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.bank.get_bank_fundamental(
            stock_codes=["600000", "600036"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_bank_fundamental(
        stock_codes=["600000", "600036"],
        metrics=["pe_ttm", "pb"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/bank",
    },
    "company/fundamental/insurance.md": {
        "title": "保险企业基本面",
        "description": "获取保险企业的基本面指标数据。",
        "endpoint": "POST /cn/company/fundamental/insurance",
        "module": "lixinger.api.cn.company.fundamental.insurance.InsuranceFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_insurance_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.insurance.get_insurance_fundamental(
            stock_codes=["601318", "601336"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_insurance_fundamental(
        stock_codes=["601318", "601336"],
        metrics=["pe_ttm", "pb"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/insurance",
    },
    "company/fundamental/security.md": {
        "title": "证券企业基本面",
        "description": "获取证券企业的基本面指标数据。",
        "endpoint": "POST /cn/company/fundamental/security",
        "module": "lixinger.api.cn.company.fundamental.security.SecurityFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_security_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.security.get_security_fundamental(
            stock_codes=["600030", "600837"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_security_fundamental(
        stock_codes=["600030", "600837"],
        metrics=["pe_ttm", "pb"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/security",
    },
    "company/fundamental/other_financial.md": {
        "title": "其他金融企业基本面",
        "description": "获取其他金融企业的基本面指标数据。",
        "endpoint": "POST /cn/company/fundamental/other_financial",
        "module": "lixinger.api.cn.company.fundamental.other_financial.OtherFinancialFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_other_financial_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.company.fundamental.other_financial.get_other_financial_fundamental(
            stock_codes=["600919"],
            metrics=["pe_ttm", "pb"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_other_financial_fundamental(
        stock_codes=["600919"],
        metrics=["pe_ttm", "pb"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/other_financial",
    },
    # Index APIs
    "index/index.md": {
        "title": "指数信息",
        "description": "获取指数基本信息。",
        "endpoint": "POST /cn/index",
        "module": "lixinger.api.cn.index.index.IndexAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_index

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index.get_index(
            stock_codes=["000300", "000905"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_index(stock_codes=["000300", "000905"])
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index",
    },
    "index/constituents.md": {
        "title": "成分股",
        "description": "获取指数成分股列表。",
        "endpoint": "POST /cn/index/constituents",
        "module": "lixinger.api.cn.index.constituents.ConstituentsAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_constituents

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_constituents.get_constituents(
            stock_codes=["000300"],
            date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_constituents(
        stock_codes=["000300"],
        date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/constituents",
    },
    "index/candlestick.md": {
        "title": "K线数据",
        "description": "获取指数K线数据。",
        "endpoint": "POST /cn/index/candlestick",
        "module": "lixinger.api.cn.index.candlestick.IndexCandlestickAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_index_candlestick

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_candlestick.get_candlestick(
            type="normal",
            stock_code="000300",
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_index_candlestick(
        type="normal",
        stock_code="000300",
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/candlestick",
    },
    "index/constituent_weightings.md": {
        "title": "成分股权重",
        "description": "获取指数成分股及其权重。",
        "endpoint": "POST /cn/index/constituent-weightings",
        "module": "lixinger.api.cn.index.constituent_weightings.ConstituentWeightingsAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_constituent_weightings

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_constituent_weightings.get_constituent_weightings(
            stock_code="000300",
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_constituent_weightings(
        stock_code="000300",
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/constituent-weightings",
    },
    "index/drawdown.md": {
        "title": "回撤数据",
        "description": "获取指数回撤数据。",
        "endpoint": "POST /cn/index/drawdown",
        "module": "lixinger.api.cn.index.drawdown.DrawdownAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_index_drawdown

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_drawdown.get_drawdown(
            type="normal",
            stock_code="000300",
            granularity="y1",
            start_date="2020-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_index_drawdown(
        type="normal",
        stock_code="000300",
        granularity="y1",
        start_date="2020-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/drawdown",
    },
    "index/fundamental.md": {
        "title": "基本面数据",
        "description": "获取指数整体基本面数据。",
        "endpoint": "POST /cn/index/fundamental",
        "module": "lixinger.api.cn.index.fundamental.IndexFundamentalAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_index_fundamental

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_fundamental.get_fundamental(
            stock_codes=["000300", "000905"],
            metrics=["pe", "pb", "roe"],
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_index_fundamental(
        stock_codes=["000300", "000905"],
        metrics=["pe", "pb", "roe"],
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/fundamental",
    },
    "index/tracking_fund.md": {
        "title": "跟踪基金",
        "description": "获取指数的跟踪基金列表。",
        "endpoint": "POST /cn/index/tracking-fund",
        "module": "lixinger.api.cn.index.tracking_fund.TrackingFundAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_tracking_fund

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_index_tracking_fund.get_tracking_fund(
            stock_code="000001"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_tracking_fund(stock_code="000001")
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/index/tracking-fund",
    },
    # Fund APIs
    "fund/fund.md": {
        "title": "基金信息",
        "description": "获取基金基本信息。",
        "endpoint": "POST /cn/fund",
        "module": "lixinger.api.cn.fund.fund.FundAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund.get_fund(
            stock_codes=["000001", "110022"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund(stock_codes=["000001", "110022"])
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund",
    },
    "fund/candlestick.md": {
        "title": "K线数据",
        "description": "获取基金净值K线数据。",
        "endpoint": "POST /cn/fund/candlestick",
        "module": "lixinger.api.cn.fund.candlestick.FundCandlestickAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_candlestick

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_candlestick.get_candlestick(
            type="normal",
            stock_code="000001",
            start_date="2023-01-01",
            end_date="2023-12-31"
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_candlestick(
        type="normal",
        stock_code="000001",
        start_date="2023-01-01",
        end_date="2023-12-31"
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/candlestick",
    },
    "fund/profile.md": {
        "title": "基金概况",
        "description": "获取基金详细概况。",
        "endpoint": "POST /cn/fund/profile",
        "module": "lixinger.api.cn.fund.profile.FundProfileAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_profile

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_profile.get_profile(
            stock_codes=["000001", "110022"]
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_profile(stock_codes=["000001", "110022"])
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/profile",
    },
    "fund/asset_combination.md": {
        "title": "资产组合",
        "description": "获取基金资产组合数据。",
        "endpoint": "POST /cn/fund/asset-combination",
        "module": "lixinger.api.cn.fund.asset_combination.FundAssetCombinationAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_asset_combination

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_asset_combination.get_asset_combination(
            stock_code="000001",
            start_date="2023-01-01",
            limit=4
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_asset_combination(
        stock_code="000001",
        start_date="2023-01-01",
        limit=4
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/asset-combination",
    },
    "fund/shareholdings.md": {
        "title": "持仓数据",
        "description": "获取基金持仓明细。",
        "endpoint": "POST /cn/fund/shareholdings",
        "module": "lixinger.api.cn.fund.shareholdings.FundShareholdingsAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_shareholdings

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_shareholdings.get_shareholdings(
            stock_code="000001",
            start_date="2023-01-01",
            limit=4
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_shareholdings(
        stock_code="000001",
        start_date="2023-01-01",
        limit=4
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/shareholdings",
    },
    "fund/announcement.md": {
        "title": "公告",
        "description": "获取基金公告数据。",
        "endpoint": "POST /cn/fund/announcement",
        "module": "lixinger.api.cn.fund.announcement.FundAnnouncementAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_announcement

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_announcement.get_announcement(
            stock_code="000001",
            start_date="2023-01-01",
            limit=10
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_announcement(
        stock_code="000001",
        start_date="2023-01-01",
        limit=10
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/announcement",
    },
    "fund/asset_industry_combination.md": {
        "title": "行业组合",
        "description": "获取基金按行业分类的股票投资组合。",
        "endpoint": "POST /cn/fund/asset-industry-combination",
        "module": "lixinger.api.cn.fund.asset_industry_combination.FundAssetIndustryCombinationAPI",
        "example": """```python
import asyncio
from lixinger import AsyncLixingerClient, get_fund_asset_industry_combination

# 方式 1: 使用异步客户端
async def example1():
    async with AsyncLixingerClient() as client:
        df = await client.cn_fund_asset_industry_combination.get_asset_industry_combination(
            stock_code="000001",
            start_date="2023-01-01",
            limit=4
        )
        print(df)

# 方式 2: 使用函数式 API（推荐）
async def example2():
    df = await get_fund_asset_industry_combination(
        stock_code="000001",
        start_date="2023-01-01",
        limit=4
    )
    print(df)

asyncio.run(example1())
```""",
        "doc_url": "https://www.lixinger.com/open/api/doc?api-key=cn/fund/asset-industry-combination",
    },
}


def generate_api_doc(config: dict) -> str:
    """Generate API documentation markdown."""
    return f"""# {config["title"]}

{config["description"]}

## API 端点

`{config["endpoint"]}`

## 类参考

::: {config["module"]}
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3

## 使用示例

{config["example"]}

## 相关链接

- [官方文档]({config["doc_url"]})
"""


def main():
    """Generate all API documentation files."""
    docs_dir = Path("docs/api")

    for file_path, config in API_DOCS.items():
        full_path = docs_dir / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)

        content = generate_api_doc(config)
        full_path.write_text(content, encoding="utf-8")
        print(f"✓ Generated: {full_path}")

    print(f"\n✨ Successfully generated {len(API_DOCS)} API documentation files!")


if __name__ == "__main__":
    main()
