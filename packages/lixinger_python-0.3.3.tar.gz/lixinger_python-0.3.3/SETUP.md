# Setup Guide

## Quick Start

1. **Copy the environment template:**
   ```bash
   cp .env.example .env
   ```

2. **Edit `.env` and add your API key:**
   ```bash
   # Open .env in your editor
   # Replace "your_api_key_here" with your actual Lixinger API key
   LIXINGER_API_KEY=your_actual_api_key_from_lixinger
   ```

3. **Install dependencies:**
   ```bash
   uv sync --dev
   ```

4. **Install pre-commit hooks:**
   ```bash
   uv run pre-commit install
   ```

5. **Run an example:**
   ```bash
   uv run python examples/company_example.py
   ```

## Getting Your API Key

1. Visit <https://www.lixinger.com/open/api>
2. Sign up or log in
3. Generate your API key
4. Copy it to your `.env` file

## Configuration Options

See `.env.example` for all available configuration options. Most users only need to set `LIXINGER_API_KEY`.

**IMPORTANT**: The API key MUST be in the `.env` file. You cannot pass it as a parameter to `AsyncLixingerClient()`. This is intentional for security reasons.

## Security Notes

- **Never commit your `.env` file** - it contains your API key
- The `.env` file is already in `.gitignore`
- Use `.env.example` as a template for others
- Each developer should have their own `.env` file
- **The API key cannot be passed as a parameter** - it must be in `.env`

## Usage

**⚠️ This SDK is fully async/await based:**

```python
import asyncio
from lixinger import AsyncLixingerClient

async def main():
    # API key is loaded from .env - cannot be passed as parameter
    async with AsyncLixingerClient() as client:
        df = await client.company.company.get_company(stock_codes=["000001"])
        print(df)

asyncio.run(main())
```

**Configuration Override:**

```python
# You can override other settings (but NOT the API key)
async with AsyncLixingerClient(
    timeout=60.0,
    proxy="socks5://localhost:1080"
) as client:
    df = await client.company.company.get_company(stock_codes=["000001"])
```

**Jupyter Notebooks:**

```python
# In Jupyter, you can use await directly at the top level
from lixinger import AsyncLixingerClient

client = AsyncLixingerClient()
df = await client.company.company.get_company(stock_codes=["000001"])
df
```

## Pre-commit Hooks

This project uses [pre-commit](https://pre-commit.com/) to automatically run linters, formatters, and tests before each commit.

### What Are Pre-commit Hooks?

Pre-commit hooks are scripts that run automatically before you commit code. They help ensure code quality by:
- Catching issues early (before CI)
- Enforcing consistent code style
- Running fast tests
- Preventing common mistakes

### Installation

Already done in Quick Start step 4! If you skipped it:

```bash
uv run pre-commit install
```

### How It Works

When you commit, pre-commit automatically runs:

1. **Ruff linter** - Checks and auto-fixes code issues
2. **Ruff formatter** - Formats code consistently
3. **Mypy** - Type checks your code
4. **Pytest** - Runs unit tests (integration tests excluded)
5. **Standard checks** - YAML, JSON, trailing whitespace, etc.

If any check fails, the commit is blocked and you'll need to fix the issues.

### Normal Workflow

```bash
# Make changes to code
git add .
git commit -m "Your commit message"

# Pre-commit hooks run automatically
# If they pass: commit succeeds ✅
# If they fail: commit blocked, fix issues ❌
```

### After Auto-fixes

Some hooks (Ruff) auto-fix issues. When this happens:

```bash
# Hooks ran and auto-fixed some issues
git add .  # Re-add the fixed files
git commit -m "Your commit message"  # Commit again
```

### Manual Execution

Run hooks without committing:

```bash
# Run all hooks on all files
uv run pre-commit run --all-files

# Run specific hook
uv run pre-commit run ruff --all-files
uv run pre-commit run mypy --all-files
uv run pre-commit run pytest-fast --all-files
```

### Skip Hooks (Use Sparingly)

```bash
# Skip all hooks (NOT RECOMMENDED)
git commit -m "WIP: work in progress" --no-verify

# Skip specific hook
SKIP=pytest-fast git commit -m "Your message"
```

**Warning**: Only skip hooks if absolutely necessary (e.g., WIP commits on feature branches).

### Hooks Included

| Hook | What it does | Auto-fix |
|------|--------------|----------|
| Ruff linter | Checks code style | ✅ Yes |
| Ruff formatter | Formats code | ✅ Yes |
| Mypy | Type checking | ❌ No |
| Pytest | Unit tests | ❌ No |
| check-yaml | Validates YAML | ❌ No |
| check-json | Validates JSON | ❌ No |
| check-toml | Validates TOML | ❌ No |
| trailing-whitespace | Removes trailing spaces | ✅ Yes |
| end-of-file-fixer | Adds newline at EOF | ✅ Yes |
| no-commit-to-branch | Prevents commits to main/master | ❌ No |

### Updating Hooks

```bash
# Update to latest versions
uv run pre-commit autoupdate
```

### Pre-commit vs CI

Pre-commit runs locally (fast feedback, < 10 seconds)
CI runs on GitHub (comprehensive checks, slower)

| Check | Pre-commit | GitHub Actions |
|-------|-----------|----------------|
| Ruff linter | ✅ | ✅ |
| Ruff formatter | ✅ | ✅ |
| Mypy | ✅ | ✅ |
| Unit tests | ✅ | ✅ |
| Integration tests | ❌ (too slow) | ✅ |
| Coverage report | ❌ | ✅ |

## Troubleshooting

### "LIXINGER_API_KEY environment variable is not set"

Make sure:
1. You created a `.env` file (copy from `.env.example`)
2. You added your API key to `.env`
3. The `.env` file is in the project root directory
4. You did NOT try to pass `api_key` as a parameter (this is not supported)

**Example `.env` file:**
```bash
LIXINGER_API_KEY=your_actual_api_key_from_lixinger
```

### Import errors

```bash
uv sync --dev
```

### "Command not found: pre-commit"

```bash
# Install dev dependencies
uv sync --dev

# Install hooks
uv run pre-commit install
```

### "Hooks not running"

```bash
# Reinstall hooks
uv run pre-commit uninstall
uv run pre-commit install
```

### "Mypy fails with import errors"

Make sure all dependencies are installed:

```bash
uv sync --dev
```

If you added new dependencies, they might need type stubs. Check `.pre-commit-config.yaml` under the mypy hook's `additional_dependencies`.

### "Tests fail in pre-commit but work normally"

Pre-commit runs in a clean environment. Make sure:
1. All dependencies are in `pyproject.toml`
2. Tests don't depend on uncommitted files
3. Tests use `monkeypatch` for environment variables
4. **All test functions are async** with `@pytest.mark.asyncio`
5. **All API calls use `await`**

**Example async test:**
```python
import pytest
from lixinger import AsyncLixingerClient

@pytest.mark.asyncio
async def test_api(monkeypatch):
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")

    async with AsyncLixingerClient() as client:
        df = await client.company.company.get_company(["000001"])
        assert not df.empty
```

### "Pre-commit is too slow"

**Tips:**
1. Commit smaller changes
2. Run hooks manually first: `uv run pre-commit run --all-files`
3. Skip specific slow hooks: `SKIP=pytest-fast git commit -m "message"`

## Best Practices

1. ✅ **Install hooks immediately** after cloning
2. ✅ **Let hooks auto-fix issues** - Don't fight the formatter
3. ✅ **Run manually** before committing large changes
4. ✅ **Fix issues locally** rather than in CI
5. ✅ **Use async/await** for all API calls
6. ✅ **Use `async with`** for client context manager
7. ❌ **Don't skip hooks** without good reason
8. ❌ **Don't commit without testing**
9. ❌ **Don't use blocking calls** in async code

## Development Workflow

```bash
# 1. Clone and setup
git clone <repo>
cd lixinger-python
cp .env.example .env
# Edit .env with your API key
uv sync --dev
uv run pre-commit install

# 2. Make changes
# ... edit code ...
# Remember: All API methods must be async def with await

# 3. Run tests manually (optional)
uv run pytest tests/ -v

# 4. Commit (hooks run automatically)
git add .
git commit -m "Your message"

# 5. Push
git push
```

Pre-commit hooks will catch most issues before they reach CI! 🎉

## Quick Examples

### Adding a New API Method

```python
# lixinger/api/cn/company/your_api.py

class YourAPI(BaseAPI):
    """Your API description."""

    async def get_data(
        self,
        stock_code: str,
    ) -> pd.DataFrame:
        """Get data for a stock.

        Args:
            stock_code: Stock code

        Returns:
            DataFrame with data

        Example:
            >>> import asyncio
            >>> async def main():
            ...     client = AsyncLixingerClient()
            ...     df = await client.your_api.get_data("000001")
            >>> asyncio.run(main())
        """
        payload = {"stockCode": stock_code}
        data = await self._request("POST", "/cn/your-api", json=payload)
        return get_response_df(data, YourModel)
```

### Writing Tests

```python
# tests/test_your_api.py

import pytest
from lixinger import AsyncLixingerClient

@pytest.mark.asyncio
async def test_your_api(monkeypatch):
    """Test your API."""

    # Mock async _request
    async def mock_request(*args, **kwargs):
        return [{"field": "value"}]

    monkeypatch.setattr(YourAPI, "_request", mock_request)
    monkeypatch.setenv("LIXINGER_API_KEY", "test_key")

    async with AsyncLixingerClient() as client:
        df = await client.your_api.get_data("000001")
        assert not df.empty
```
