# 文档系统使用指南

本项目使用 MkDocs + Material 主题 + mkdocstrings 自动生成美观的 API 文档。

## 📚 文档结构

```
docs/
├── index.md                    # 首页
├── getting-started/            # 快速开始
│   ├── installation.md         # 安装指南
│   ├── configuration.md        # 配置指南
│   └── quickstart.md          # 快速入门
├── api/                        # API 参考（自动生成）
│   ├── overview.md            # API 概览
│   ├── client.md              # 客户端文档
│   ├── company/               # 股票相关 API
│   ├── index/                 # 指数相关 API
│   └── fund/                  # 基金相关 API
├── examples/                   # 使用示例
│   ├── company.md
│   ├── index.md
│   └── fund.md
└── development/               # 开发指南
    ├── contributing.md
    ├── testing.md
    └── code-style.md
```

## 🚀 快速开始

### 预览文档

```bash
# 启动本地文档服务器（支持热重载）
uv run mkdocs serve

# 然后在浏览器打开: http://127.0.0.1:8000
```

### 构建文档

```bash
# 构建静态站点到 site/ 目录
uv run mkdocs build

# 构建并检查
uv run mkdocs build --strict
```

### 部署文档

```bash
# 部署到 GitHub Pages
uv run mkdocs gh-deploy
```

## ✨ 核心特性

### 1. 自动 API 文档

使用 mkdocstrings 从 Python docstrings 自动生成 API 文档：

```markdown
# 在 Markdown 文件中

::: lixinger.api.cn.company.fundamental.FundamentalAPI
    options:
      show_root_heading: true
      show_source: true
      heading_level: 3
```

这会自动提取类的文档字符串、方法签名、参数说明等。

### 2. 批量生成文档

使用脚本批量生成 API 文档页面：

```bash
# 运行生成脚本
uv run python scripts/generate_docs.py

# 输出：
# ✓ Generated: docs/api/company/fundamental.md
# ✓ Generated: docs/api/company/candlestick.md
# ...
# ✨ Successfully generated 17 API documentation files!
```

### 3. Material 主题特性

#### 代码高亮

```python
# 自动语法高亮
from lixinger import LixingerClient

client = LixingerClient()
df = client.company.fundamental.get_non_financial(
    stock_codes=["000001"]
)
```

#### 提示框

```markdown
!!! tip "提示"
    这是一个提示框

!!! warning "警告"
    这是一个警告框

!!! danger "危险"
    这是一个危险提示框
```

渲染效果：

!!! tip "提示"
    所有 API 返回 Pandas DataFrame 格式

!!! warning "警告"
    API Key 必须保密，不要提交到 Git

#### 选项卡

```markdown
=== "方式 1"
    第一种方式的内容

=== "方式 2"
    第二种方式的内容
```

### 4. 搜索功能

文档内置全文搜索功能，支持中英文。

### 5. 深色/浅色主题

用户可以切换深色或浅色主题，提升阅读体验。

## 📝 编写文档的最佳实践

### 1. 使用 Google-style Docstrings

```python
def get_data(stock_code: str, date: str) -> pd.DataFrame:
    """获取股票数据.

    Args:
        stock_code: 股票代码
        date: 查询日期 (YYYY-MM-DD)

    Returns:
        包含股票数据的 DataFrame

    Raises:
        ValueError: 当日期格式不正确时

    Example:
        >>> df = get_data("000001", "2023-12-31")
        >>> print(df.head())
    """
    pass
```

### 2. 添加代码示例

在每个 API 文档页面都应包含实际可运行的代码示例。

### 3. 使用类型提示

完整的类型提示会自动显示在文档中：

```python
from typing import List, Optional
import pandas as pd

def get_data(
    stock_codes: List[str],
    start_date: Optional[str] = None,
) -> pd.DataFrame:
    """..."""
    pass
```

### 4. 交叉引用

使用 Markdown 链接引用其他文档页面：

```markdown
详见 [配置指南](configuration.md)
```

## 🔧 配置说明

### mkdocs.yml

主配置文件，包含：

- **site_name**: 站点名称
- **theme**: 主题配置（Material）
- **plugins**: 插件配置（search, mkdocstrings）
- **nav**: 导航结构
- **markdown_extensions**: Markdown 扩展

### mkdocstrings 配置

```yaml
plugins:
  - mkdocstrings:
      handlers:
        python:
          options:
            docstring_style: google        # 使用 Google 风格
            show_source: true              # 显示源代码
            show_signature_annotations: true  # 显示类型注解
            merge_init_into_class: true    # 合并 __init__ 到类文档
```

## 📦 依赖说明

- **mkdocs**: 静态站点生成器
- **mkdocs-material**: Material Design 主题
- **mkdocstrings**: 从代码自动生成文档
- **mkdocstrings-python**: Python 语言支持
- **pymdown-extensions**: Markdown 扩展

## 🎯 常用命令

```bash
# 启动开发服务器
uv run mkdocs serve

# 构建静态站点
uv run mkdocs build

# 严格模式构建（有警告会失败）
uv run mkdocs build --strict

# 清理构建文件
rm -rf site/

# 部署到 GitHub Pages
uv run mkdocs gh-deploy

# 生成新的 API 文档
uv run python scripts/generate_docs.py

# 查看 MkDocs 版本
uv run mkdocs --version
```

## 🚀 CI/CD 集成

### GitHub Actions

创建 `.github/workflows/docs.yml`：

```yaml
name: Deploy Docs

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
        with:
          python-version: 3.13
      - name: Install dependencies
        run: |
          pip install mkdocs mkdocs-material mkdocstrings mkdocstrings-python
      - name: Deploy docs
        run: mkdocs gh-deploy --force
```

## 📖 参考资料

- [MkDocs 官方文档](https://www.mkdocs.org/)
- [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- [mkdocstrings 文档](https://mkdocstrings.github.io/)
- [Python Markdown 扩展](https://python-markdown.github.io/extensions/)

## ❓ 常见问题

### Q: 如何添加新的 API 文档页面？

A: 两种方式：

1. 手动创建 Markdown 文件并使用 `:::` 语法
2. 修改 `scripts/generate_docs.py` 并运行脚本

### Q: 如何修改主题样式？

A: 编辑 `mkdocs.yml` 中的 `theme.palette` 配置。

### Q: 文档没有更新怎么办？

A: 尝试清理缓存：

```bash
rm -rf site/
uv run mkdocs build
```

### Q: 如何在文档中嵌入图片？

A: 将图片放在 `docs/` 目录下，然后使用相对路径：

```markdown
![示例图片](./images/example.png)
```

## 🤝 贡献文档

欢迎改进文档！请：

1. Fork 项目
2. 创建分支：`git checkout -b docs/improve-xxx`
3. 修改文档
4. 本地预览：`uv run mkdocs serve`
5. 提交 PR

---

更新时间: 2026-01-28
