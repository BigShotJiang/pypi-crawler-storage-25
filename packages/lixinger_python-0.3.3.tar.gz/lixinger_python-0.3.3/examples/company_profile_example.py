import asyncio

from lixinger import AsyncLixingerClient, get_profile


async def main():
    # Method 1: Using the async client with environment variables
    # The API key is ALWAYS loaded from .env file (LIXINGER_API_KEY)
    print("Method 1: Using async client (loads API key from .env)...")
    # Note: Make sure you have LIXINGER_API_KEY set in your .env file
    client = AsyncLixingerClient()
    try:
        print("Fetching company profile information using client...")
        # Replace with actual stock codes
        try:
            df = await client.company.get_profile(stock_codes=["600036"])
            print(df)
        except Exception as e:
            print(f"Error fetching profile: {e}")
            print("Note: This example requires a valid LIXINGER_API_KEY in .env")
    finally:
        await client.close()

    print("\nMethod 2: Using functional API...")
    # Also loads API key from .env automatically
    try:
        df = await get_profile(stock_codes=["000001"])
        print(df)
    except Exception as e:
        print(f"Error fetching profile: {e}")


if __name__ == "__main__":
    asyncio.run(main())
