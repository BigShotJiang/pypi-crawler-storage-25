"""Index information API example.

This example demonstrates how to use the index API
to retrieve basic information about stock indices.
"""

import asyncio

from lixinger import AsyncLixingerClient, get_index


async def main():
    """Demonstrate usage of index information API."""
    # Method 1: Using the async client with context manager (recommended)
    print("Method 1: Using async client...")
    async with AsyncLixingerClient() as client:
        # Get information for specific indices
        print("\nFetching info for CSI 300 and CSI 500...")
        df = await client.index.get_index(stock_codes=["000300", "000905"])
        print(df[["name", "stock_code", "source", "launch_date"]])

        # Get all CSI indices
        print("\nFetching all CSI indices...")
        df = await client.index.get_index(source="csi")
        print(f"Total CSI indices: {len(df)}")
        print(df[["name", "stock_code", "rebalancing_frequency"]].head(10))

        # Get all indices (may be large)
        print("\nFetching all available indices...")
        df = await client.index.get_index()
        print(f"Total indices: {len(df)}")
        print("\nIndices by source:")
        print(df["source"].value_counts())

    # Method 2: Using functional API
    print("\nMethod 2: Using functional API...")
    df = await get_index(stock_codes=["000001"])  # Shanghai Composite
    print(df[["name", "stock_code", "source", "launch_date"]])


if __name__ == "__main__":
    asyncio.run(main())
