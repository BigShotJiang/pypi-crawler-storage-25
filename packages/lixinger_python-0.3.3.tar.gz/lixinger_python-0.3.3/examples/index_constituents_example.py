"""Index constituents API example.

This example demonstrates how to use the index constituents API
to retrieve constituent stocks of A-share indices.
"""

import asyncio

from lixinger import AsyncLixingerClient, get_constituents


async def main():
    """Demonstrate usage of index constituents API."""
    # Method 1: Using the async client with context manager (recommended)
    print("Method 1: Using async client...")
    async with AsyncLixingerClient() as client:
        # Get constituents of Shanghai Composite Index (000001.SH)
        print("\nFetching constituents of Shanghai Composite Index...")
        df = await client.index.get_constituents(
            stock_codes=["000001"],
            date="2024-12-31",
        )
        print(f"Total constituents: {len(df)}")
        print(df.head(10))

        # Get constituents of multiple indices
        print("\nFetching constituents of multiple indices...")
        df = await client.index.get_constituents(
            stock_codes=["000001", "399001"],  # Shanghai & Shenzhen Composite
            date="2024-12-31",
        )
        print(f"Total constituents: {len(df)}")
        print(df.head(10))

    # Method 2: Using functional API
    print("\nMethod 2: Using functional API...")
    df = await get_constituents(
        stock_codes=["000300"],  # CSI 300
        date="2024-12-31",
    )
    print(f"Total constituents: {len(df)}")
    print(df.head(10))


if __name__ == "__main__":
    asyncio.run(main())
