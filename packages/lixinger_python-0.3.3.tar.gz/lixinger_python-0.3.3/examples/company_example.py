import asyncio

from lixinger import AsyncLixingerClient, get_company


async def main():
    # Method 1: Using the async client with environment variables
    # The API key is ALWAYS loaded from .env file (LIXINGER_API_KEY)
    print("Method 1: Using async client (loads API key from .env)...")
    client = AsyncLixingerClient()
    try:
        print("Fetching company information using client...")
        df = await client.company.get_company(stock_codes=["600036"])
        print(df)
    finally:
        await client.close()

    # Method 2: Using async context manager (recommended)
    print("\nMethod 2: Using async context manager...")
    async with AsyncLixingerClient() as client:
        df = await client.company.get_company(stock_codes=["000001"])
        print(df)

    # Method 3: Using functional API (also async)
    # Also loads API key from .env automatically
    print("\nMethod 3: Using functional API (also uses .env)...")
    df = await get_company(stock_codes=["000001"])
    print(df)

    # Method 4: Override other settings (API key still from .env)
    print("\nMethod 4: Override settings (API key always from .env)...")
    client = AsyncLixingerClient(timeout=60.0, proxy="socks5://localhost:1080")
    try:
        df = await client.company.get_company(stock_codes=["600036"])
        print(df)
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
