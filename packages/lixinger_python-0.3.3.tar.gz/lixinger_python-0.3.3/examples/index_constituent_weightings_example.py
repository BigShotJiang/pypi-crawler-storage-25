"""Index constituent weightings API example.

This example demonstrates how to use the index constituent weightings API
to retrieve the weighting (proportion) of constituent stocks in an index over time.
"""

import asyncio

from lixinger import AsyncLixingerClient, get_constituent_weightings


async def main():
    """Demonstrate usage of index constituent weightings API."""
    # Method 1: Using the async client with context manager (recommended)
    print("Method 1: Using async client...")
    async with AsyncLixingerClient() as client:
        # Get constituent weightings of CSI 300 Index
        print("\nFetching constituent weightings of CSI 300 Index...")
        df = await client.index.get_constituent_weightings(
            stock_code="000300",  # CSI 300
            start_date="2024-01-01",
            end_date="2024-12-31",
        )
        print(f"Total records: {len(df)}")
        print("\nTop 10 stocks by weight:")
        top_stocks = df.sort_values("weighting", ascending=False).head(10)
        print(top_stocks[["date", "stock_code", "weighting"]])

        # Analyze weighting distribution
        print("\nWeighting statistics:")
        print(df["weighting"].describe())

    # Method 2: Using functional API
    print("\nMethod 2: Using functional API...")
    df = await get_constituent_weightings(
        stock_code="000300",
        start_date="2024-06-01",
        end_date="2024-06-30",
    )
    print(f"Total records: {len(df)}")
    print(df.head(10))


if __name__ == "__main__":
    asyncio.run(main())
