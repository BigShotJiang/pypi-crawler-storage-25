import asyncio

from lixinger import AsyncLixingerClient


async def main():
    # Method 1: Using the async client with environment variables
    # The API key is ALWAYS loaded from .env file (LIXINGER_API_KEY)
    print("Method 1: Using async client (loads API key from .env)...")
    client = AsyncLixingerClient()
    try:
        print("Fetching company information using client...")
        df = await client.company.dividend.get_dividend(stock_code="000001", start_date="2026-03-01")
        print(df)
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
