# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Python SDK for the Lixinger API, which provides financial data services. The project is in early development stages.

- **API Documentation**: https://www.lixinger.com/open/api/doc?api-key=cn/company/fundamental/non_financial
- **API Endpoint**: `https://open.lixinger.com/api`
- **Python Version**: 3.13+
- **Package Manager**: uv (fast Python package installer)
- **Main Dependencies**: httpx (with SOCKS proxy support), python-dotenv, pydantic

## Configuration

**IMPORTANT**: The SDK uses environment variables for configuration via dotenv. The API key is ALWAYS loaded from the `.env` file and CANNOT be passed as a parameter.

1. **Setup**: Copy `.env.example` to `.env` and configure:
   ```bash
   cp .env.example .env
   ```

2. **Required Environment Variables**:
   - `LIXINGER_API_KEY` - Your Lixinger API key (REQUIRED - cannot be passed as parameter)

3. **Optional Environment Variables**:
   - `LIXINGER_BASE_URL` - Custom API base URL (default: https://open.lixinger.com/api)
   - `LIXINGER_TIMEOUT` - Request timeout in seconds (default: 30.0)
   - `LIXINGER_MAX_RETRIES` - Maximum retry attempts (default: 3)
   - `LIXINGER_PROXY` - Proxy URL, supports SOCKS (default: None)
   - `LIXINGER_MAX_REQUESTS_PER_MINUTE` - Rate limit (default: 1000)

4. **Never commit `.env` files** - They are already in .gitignore

5. **Client Usage**:
   ```python
   # API key is ALWAYS from .env - cannot be passed as parameter
   client = LixingerClient()

   # You can override other settings (but NOT the API key)
   client = LixingerClient(timeout=60.0, proxy="socks5://localhost:1080")
   ```

## Development Commands

### Setup

```bash
# Install dependencies using uv
uv sync --dev

# Install pre-commit hooks (IMPORTANT!)
uv run pre-commit install
```

**Note**: Pre-commit hooks automatically run linters, formatters, and tests before each commit. See `SETUP.md` for details.

### Running

```bash
# Run the main script
uv run python main.py

# Run examples (make sure .env is configured first)
uv run python examples/company_example.py
```

### Linting

```bash
# Run Ruff linter
uv run ruff check .

# Auto-fix linting issues
uv run ruff check . --fix

# Format code
uv run ruff format .

# Check formatting (used in CI)
uv run ruff format --check .

# Run Mypy type checker
uv run mypy lixinger/
```

### Testing

```bash
# Run all tests
uv run pytest

# Run only unit tests (fast, no API key needed)
uv run pytest -m "not integration"

# Run integration tests (requires valid API key in .env)
uv run pytest -m integration

# Run specific test file
uv run pytest tests/test_client.py

# Run with coverage
uv run pytest --cov=lixinger

# Explore API and record real responses
uv run python scripts/explore_api.py
```


### Package Management

```bash
# Add a new dependency
uv add <package-name>

# Add a development dependency
uv add --dev <package-name>

# Update dependencies
uv sync
```

## API Requirements

When implementing API client functionality, ensure:

1. **Request Headers**:
   - Set `Content-Type: application/json`
   - Include `accept-encoding: gzip` (can also include deflate, br, *)

2. **Rate Limiting**:
   - Maximum 1000 requests per minute
   - Status code 429 (Too Many Requests) indicates rate limit exceeded
   - Implement retry mechanism for network issues and failures

3. **Error Handling**:
   - All API calls should have retry logic
   - Handle network issues gracefully to prevent crashes

4. **Authentication**:
   - API key is sent via query parameter `token` in POST request body
   - Never hardcode API keys in source code

5. **Response Format** (CRITICAL):
   - All Lixinger API responses follow a standard format:
     ```json
     {
       "code": 1,           // 1 = success, other values = error
       "message": "success", // "success" or error message
       "data": [...]        // Actual response payload
     }
     ```
   - Always validate `code == 1` and `message == "success"`
   - Return only the `data` field to users (unwrap the response)
   - Handle error responses appropriately

## Project Structure

```text
lixinger-python/
├── lixinger/              # Main package
│   ├── __init__.py       # Public API exports
│   ├── client.py         # LixingerClient class
│   ├── config.py         # Configuration and env loading
│   ├── exceptions.py     # Custom exception classes
│   ├── api/              # API endpoint modules
│   │   ├── base.py       # Base API class
│   │   └── cn/           # China market APIs
│   │       ├── company/  # Company-related APIs (/cn/company)
│   │       │   ├── __init__.py
│   │       │   ├── fundamental.py
│   │       │   └── candlestick.py
│   │       └── index/    # Index-related APIs (/cn/index)
│   │           ├── __init__.py
│   │           └── index.py
│   ├── models/           # Pydantic data models
│   │   └── cn/           # China market models (mirrors api/ structure)
│   │       ├── company/
│   │       │   ├── __init__.py
│   │       │   ├── company.py
│   │       │   ├── fundamental.py
│   │       │   ├── candlestick.py
│   │       │   └── equity_change.py
│   │       └── index/
│   │           ├── __init__.py
│   │           └── index.py
│   └── utils/            # Utility functions
│       ├── retry.py      # Retry logic
│       ├── rate_limiter.py  # Rate limiting
│       └── dataframe.py  # DataFrame utilities
├── tests/                # Test files
├── examples/             # Usage examples
├── .env.example          # Environment variable template
└── .env                  # Local config (git-ignored)
```

**Important**: File structure follows API endpoint paths:
- API endpoint `/cn/company` → `lixinger/api/cn/company/`
- API endpoint `/cn/index` → `lixinger/api/cn/index/`
- Models mirror the API structure → `lixinger/models/cn/company/`, `lixinger/models/cn/index/`

See `AGENTS.md` for detailed file organization rules.

## Code Style

- Use type hints for all function signatures
- Use Google-style docstrings (required for auto-generating documentation)
- Follow PEP 8 naming conventions
- Raise specific exceptions, never use bare `except:`

## Documentation

This project uses **MkDocs + mkdocstrings** to automatically generate API documentation from docstrings.

**Requirements when adding new APIs**:
- ✅ Write complete Google-style docstrings
- ✅ Include `Args`, `Returns`, and `Example` sections
- ✅ Use full type annotations

**Quick workflow**:
```bash
# 1. Write code with docstrings
# 2. Generate docs
uv run python scripts/generate_docs.py
# 3. Preview
uv run mkdocs serve
```

**Important**:
- ✅ DO commit: `docs/` (source files), `mkdocs.yml`
- ❌ DON'T commit: `site/` (auto-generated)


## CI/CD

GitHub Actions runs on every PR and push to main branches.

**Required Checks:**
- Lint (Ruff & Mypy)
- Unit Tests
- Compilation

**Optional:**
- Integration Tests (requires API key secret)

See `.github/workflows/README.md` for details.

**Local Pre-PR Check:**
```bash
# Run all checks locally before pushing
uv run ruff check .
uv run ruff format --check .
uv run mypy lixinger/
uv run pytest tests/ -m "not integration" -v
```
