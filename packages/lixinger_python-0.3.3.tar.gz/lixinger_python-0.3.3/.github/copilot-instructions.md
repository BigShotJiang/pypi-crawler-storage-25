When performing a code review:

1. Respond in English
2. If the PR is adding new API, review the request param and response param is strictly aligning with the API doc provided in PR description.

**Checklist:**
- [ ] All parameter names match API docs exactly
- [ ] All parameter types match API docs exactly
- [ ] All response fields match API docs exactly
- [ ] Optional parameters are correctly marked
- [ ] Default values match API docs (if specified)
- [ ] Constraints are validated (enums, ranges, etc.)
- [ ] Documentation links included in docstrings
