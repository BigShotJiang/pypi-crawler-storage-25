# GitHub Actions Workflows

This directory contains CI/CD workflows for the lixinger-python project.

## Workflows

### PR Checks (`pr-checks.yml`)

Runs on every pull request and push to main branches.

**Required Checks (PR Gate):**

1. **Lint Check**
   - Ruff linter (`ruff check .`)
   - Ruff formatter (`ruff format --check .`)
   - Mypy type checker (`mypy lixinger/`)

2. **Test Suite**
   - Unit tests only (integration tests excluded)
   - Runs with `pytest -m "not integration"`
   - Generates coverage report
   - Uploads to Codecov

3. **Compilation Check**
   - Python compilation (`py_compile`)
   - Import validation
   - Ensures package can be imported

**Optional Check:**

4. **Integration Tests**
   - Only runs if `LIXINGER_API_KEY` secret is available
   - Skipped for external PRs (normal behavior)
   - Tests with real API (non-blocking)

## Setup

### Required Secrets

No secrets required for basic PR checks (lint, test, compile).

### Optional Secrets

- `LIXINGER_API_KEY` - For integration tests (optional, only for internal PRs)

To add secrets:
1. Go to repository Settings → Secrets and variables → Actions
2. Add `LIXINGER_API_KEY` with your API key

## Branch Protection Rules

Recommended settings for main/master branch:

1. Require status checks to pass before merging:
   - [x] Lint (Ruff & Mypy)
   - [x] Test Suite
   - [x] Compilation Check
   - [x] All Checks Passed

2. Optional (not required):
   - [ ] Integration Tests (Optional)

3. Other recommended settings:
   - [x] Require branches to be up to date before merging
   - [x] Require conversation resolution before merging
   - [ ] Require signed commits (optional)

## Local Testing

Run the same checks locally before pushing:

```bash
# Lint checks
uv run ruff check .
uv run ruff format --check .
uv run mypy lixinger/

# Unit tests
uv run pytest tests/ -m "not integration" -v

# Compilation check
python -m py_compile lixinger/**/*.py
uv run python -c "import lixinger"

# Integration tests (optional, requires API key)
uv run pytest tests/test_integration.py -v
```

## Troubleshooting

### "Ruff check failed"
- Run `uv run ruff check . --fix` to auto-fix issues
- Run `uv run ruff format .` to format code

### "Mypy type check failed"
- Fix type hints in the reported files
- Ensure all functions have proper type annotations

### "Tests failed"
- Run `uv run pytest tests/ -v` locally to see details
- Make sure `.env` is not committed (only `.env.example`)
- Check that mocks match expected structure

### "Compilation failed"
- Check for syntax errors in Python files
- Ensure all imports are correct

### "Integration tests skipped"
- Normal for external PRs (no API key available)
- Internal PRs need `LIXINGER_API_KEY` secret configured

## CI/CD Best Practices

1. **Fast Feedback**
   - Lint checks run first (fastest)
   - Tests run in parallel with compilation
   - Integration tests are optional (non-blocking)

2. **Resource Efficiency**
   - Uses uv caching for faster installs
   - Only runs integration tests when necessary
   - Parallel job execution

3. **Security**
   - API keys stored as secrets
   - External PRs cannot access secrets
   - Integration tests continue on error

4. **Developer Experience**
   - Clear job names
   - Helpful error messages
   - Same commands work locally

## Adding New Checks

To add a new check to the PR gate:

1. Add a new job in `pr-checks.yml`
2. Add the job name to `needs:` in the `all-checks` job
3. Update branch protection rules to require the new check
4. Document the check in this README
