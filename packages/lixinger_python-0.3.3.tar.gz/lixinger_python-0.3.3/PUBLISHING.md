# Publishing to PyPI

This guide explains how to publish the `lixinger-python` SDK to PyPI.

## Prerequisites

1. **PyPI Account**: Register at https://pypi.org
2. **TestPyPI Account** (optional, for testing): Register at https://test.pypi.org
3. **API Token**: Generate an API token from your PyPI account settings

## Setup (One-time)

### 1. Install build tools

```bash
uv add --dev build twine
```

### 2. Configure PyPI credentials

Create or edit `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PRODUCTION_API_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_API_TOKEN_HERE
```

**Security Note**: Never commit `.pypirc` to version control!

### 3. Update project metadata

Before publishing, update these in `pyproject.toml`:

- `version`: Update version number (follow [Semantic Versioning](https://semver.org))
- `authors`: Add your email address
- `[project.urls]`: Update with your actual GitHub repository URLs

## Publishing Steps

### Step 1: Pre-publication checks

```bash
# Run linters
uv run ruff check .
uv run ruff format --check .

# Run type checker
uv run mypy lixinger/

# Run tests
uv run pytest -m "not integration"

# Test with integration tests (requires API key)
uv run pytest
```

### Step 2: Update version

Edit `pyproject.toml` and update the version number:

```toml
[project]
version = "0.1.1"  # Increment according to changes
```

Version guidelines:
- `0.1.0` → `0.1.1`: Bug fixes, minor changes
- `0.1.0` → `0.2.0`: New features, backward compatible
- `0.1.0` → `1.0.0`: Major changes, may break compatibility

### Step 3: Clean previous builds

```bash
rm -rf dist/ build/ *.egg-info
```

### Step 4: Build the package

```bash
uv run python -m build
```

This creates two files in `dist/`:
- `lixinger_python-x.y.z-py3-none-any.whl` (wheel format)
- `lixinger-python-x.y.z.tar.gz` (source distribution)

### Step 5: Verify the build

```bash
# Check package contents
uv run twine check dist/*

# List files in the wheel (optional)
unzip -l dist/*.whl
```

### Step 6: Test on TestPyPI (Recommended)

```bash
# Upload to TestPyPI
uv run twine upload --repository testpypi dist/*

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ lixinger-python

# Test the installation
python -c "from lixinger import LixingerClient; print('Import successful!')"
```

### Step 7: Publish to PyPI

```bash
# Upload to production PyPI
uv run twine upload dist/*
```

### Step 8: Verify installation

```bash
# Install from PyPI
pip install lixinger-python

# Or with uv
uv add lixinger-python
```

### Step 9: Tag the release in Git

```bash
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0
```

## Using in Another Project

After publishing, you can use it in your other project:

```bash
# With pip
pip install lixinger-python

# With uv
uv add lixinger-python

# Install specific version
uv add lixinger-python==0.1.0
```

In your code:

```python
from lixinger import LixingerClient

# Remember to create .env file with LIXINGER_API_KEY
with LixingerClient() as client:
    df = client.company.company.get_company(stock_codes=["600036"])
    print(df)
```

## Automation with GitHub Actions (Optional)

You can automate releases with GitHub Actions. Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.13'

      - name: Install dependencies
        run: |
          pip install build twine

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

Then add `PYPI_API_TOKEN` to your GitHub repository secrets.

## Troubleshooting

### Error: Package already exists

- You cannot re-upload the same version
- Increment the version number in `pyproject.toml`

### Error: Invalid credentials

- Check your `~/.pypirc` file
- Ensure API token is correct and has upload permissions

### Error: Package name already taken

- Choose a different name in `pyproject.toml`
- Try variations like `lixinger-sdk`, `pylixinger`, etc.

### Import errors after installation

- Ensure `lixinger/__init__.py` properly exports all public APIs
- Check that all required files are included in MANIFEST.in

## Best Practices

1. **Always test on TestPyPI first** before publishing to production PyPI
2. **Use API tokens** instead of username/password for authentication
3. **Tag releases in Git** to track versions
4. **Write a CHANGELOG.md** to document changes between versions
5. **Never commit sensitive files** like `.pypirc` or `.env`
6. **Follow semantic versioning** for version numbers
7. **Run all tests** before publishing

## Additional Resources

- [Python Packaging User Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)
- [Semantic Versioning](https://semver.org/)
- [uv Documentation](https://docs.astral.sh/uv/)
