"""
NetScout — CLI entrypoint.

Usage:
    netscout [TARGET ...] [OPTIONS]

Targets are required as positional args or via --targets-file.
"""

from __future__ import annotations

import argparse
import asyncio
import platform
import signal
import sys
import time
import urllib.request
import json

from . import __version__
from .cidr import (
    check_host_count,
    deduplicate_and_merge,
    expand_hosts,
    load_targets_file,
    parse_targets,
)
from .enumerator import (
    check_ports,
    deep_scan,
    os_fingerprint,
    quick_enum,
    resolve_hostnames,
    script_scan,
    service_version,
)
from .exporter import export_results
from .output import (
    ScanProgress,
    console,
    error,
    info,
    print_banner,
    print_quiet,
    print_range_summary,
    print_results_table,
    print_scan_summary,
    success,
    warn,
)
from .scanner import HostResult, nmap_available


# ---------------------------------------------------------------------------
# Update Checker logic
# ---------------------------------------------------------------------------

def get_latest_version_sync() -> str | None:
    try:
        req = urllib.request.Request("https://pypi.org/pypi/netscout/json", headers={"User-Agent": f"netscout/{__version__}"})
        with urllib.request.urlopen(req, timeout=1.5) as response:
            data = json.loads(response.read().decode())
            return data.get("info", {}).get("version")
    except Exception:
        return None

async def get_latest_version_async() -> str | None:
    return await asyncio.to_thread(get_latest_version_sync)

def print_update_alert(latest: str | None) -> None:
    if latest and latest != __version__:
        try:
            curr = tuple(map(int, __version__.split(".")))
            lat = tuple(map(int, latest.split(".")))
            if lat > curr:
                console.print(f"  [bold yellow] Update available! ({__version__} -> {latest})[/bold yellow]")
                console.print("  [yellow]Run 'netscout --upgrade' to automatically update.[/yellow]\n")
        except Exception:
            pass
# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="netscout",
        description="NetScout — Production-ready pentest recon CLI. Speed first.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
examples:
  netscout 10.10.10.0/24
  netscout 10.10.10.0/24 172.20.0.0/16 --port 22 80 443 --os
  netscout --targets-file ranges.txt --enum -o results.json
  netscout 192.168.1.0/24 --deep --fast -o scan.csv
        """,
    )

    parser.add_argument("targets", nargs="*", metavar="TARGET", help="Target CIDR(s), IPs, ranges, or hostnames")
    parser.add_argument("--targets-file", metavar="FILE", help="Read targets from file (one per line)")

    disc = parser.add_argument_group("Discovery")
    disc.add_argument("--tcp", action="store_true", help="TCP fallback for ICMP-dark hosts")
    disc.add_argument("--ports", metavar="TEXT", default="22,80,443,445,3389", help="Ports for TCP fallback probe (default: 22,80,443,445,3389)")
    disc.add_argument("--threads", type=int, default=150, metavar="INT", help="Concurrent threads / semaphore limit (default: 150)")
    disc.add_argument("--timeout", type=float, default=1.0, metavar="FLOAT", help="Timeout per probe in seconds (default: 1.0)")
    disc.add_argument("--fast", action="store_true", help="Use nmap T5 + max-parallelism (fastest, noisier)")

    en = parser.add_argument_group("Enumeration")
    en.add_argument("--port", nargs="+", type=int, metavar="INT", help="Check if specific port(s) are open on live hosts")
    en.add_argument("--os", action="store_true", dest="os_detect", help="Detect OS (requires root/admin, falls back to TTL)")
    en.add_argument("--services", action="store_true", help="Service version detection (nmap -sV intensity 0)")
    en.add_argument("--scripts", action="store_true", help="Run nmap default scripts (slow, explicit only)")
    en.add_argument("--enum", action="store_true", help="All fast enum: OS + banner + DNS (recommended)")
    en.add_argument("--deep", action="store_true", help="Full nmap -O -sV on live hosts (slowest, most info)")

    out = parser.add_argument_group("Output")
    out.add_argument("-o", "--output", metavar="FILE", help="Save results (auto-format: .txt .json .csv .gnmap)")
    out.add_argument("--no-color", action="store_true", help="Disable colors (for piping)")
    out.add_argument("-v", "--verbose", action="store_true", help="Show dead hosts in output")
    out.add_argument("-q", "--quiet", action="store_true", help="Only print IP:PORT pairs, no UI chrome")
    out.add_argument("--no-banner", action="store_true", help="Suppress ASCII banner")
    out.add_argument("--force", action="store_true", help="Scan ranges > 65536 hosts without confirmation")

    parser.add_argument("--upgrade", action="store_true", help="Update netscout to the latest version via pipx")
    parser.add_argument("--version", action="version", version=f"netscout {__version__}")

    return parser


# ---------------------------------------------------------------------------
# Main async logic
# ---------------------------------------------------------------------------


async def _async_main(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    """Core async workflow."""
    # Spin up background update checker so it has zero performance cost
    update_task = asyncio.create_task(get_latest_version_async())

    raw_targets: list[str] = list(args.targets) if args.targets else []

    if args.targets_file:
        raw_targets.extend(load_targets_file(args.targets_file))

    if not raw_targets:
        error("No targets specified. Use positional args or --targets-file.")
        parser.print_usage()
        # Synchronously await and print update notification if no targets passed
        try:
            latest = await update_task
            print_update_alert(latest)
        except Exception:
            pass
        sys.exit(1)

    specs, errors_list = parse_targets(raw_targets)
    for e in errors_list:
        warn(e)

    if not specs:
        error("No valid targets. Exiting.")
        sys.exit(1)

    networks, total_hosts = deduplicate_and_merge(specs)
    check_host_count(total_hosts, args.force)

    ranges_display = [str(n) for n in networks]
    all_ips = expand_hosts(networks)

    if not args.quiet:
        print_scan_summary(len(networks), total_hosts, ranges_display)

    has_nmap = nmap_available()
    if not has_nmap and not args.quiet:
        warn("nmap not found on PATH. Falling back to asyncio TCP/ICMP scanning. Install nmap for full functionality.")

    t0 = time.time()

    progress: ScanProgress | None = None
    if not args.quiet:
        progress = ScanProgress(total=total_hosts, range_label=" ".join(ranges_display[:3]))
        progress.start()

    def on_discovery(hr: HostResult) -> None:
        if progress:
            progress.advance(hr)

    from .scanner import discover_hosts

    ip_strings = [str(ip) for ip in all_ips]

    results = await discover_hosts(
        ip_strings, tcp_fallback=args.tcp, tcp_ports=[int(p) for p in args.ports.split(",")],
        timeout=args.timeout, threads=args.threads, fast=args.fast,
        os_guess=args.os_detect or args.enum, callback=on_discovery,
    )

    if progress:
        remaining = total_hosts - progress.scanned
        if remaining > 0:
            progress.advance(count=remaining)
        progress.stop()

    alive_count = sum(1 for hr in results.values() if hr.alive)

    if not args.quiet:
        info(f"Discovery complete: [green]{alive_count}[/green] alive / {total_hosts} total")

    if alive_count == 0:
        if not args.quiet:
            warn("No live hosts found.")
        if args.output:
            export_results(results, args.output)
            success(f"Results saved to {args.output}")
        return

    enum_ports = args.port or []

    if enum_ports:
        if not args.quiet:
            info(f"Checking ports: {', '.join(str(p) for p in enum_ports)}")
        await check_ports(results, enum_ports, timeout=0.5, threads=args.threads, grab_banner=True)

    if args.enum:
        if not args.quiet:
            info("Running quick enumeration (OS + banner + DNS)...")
        await quick_enum(results, ports=enum_ports, threads=args.threads)

    if args.os_detect and not args.enum:
        if not args.quiet:
            info("Extracting OS via asynchronous TTL signatures...")
        await os_fingerprint(results, deep=args.deep, fast=args.fast)

    if args.services:
        if not args.quiet:
            info("Detecting service versions (nmap -sV)...")
        await service_version(results, ports=enum_ports or None, fast=args.fast)

    if args.scripts:
        if not args.quiet:
            info("Running nmap default scripts (this may take a while)...")
        script_results = await script_scan(results, ports=enum_ports or None, fast=args.fast)
        if script_results and not args.quiet:
            for ip, scripts in script_results.items():
                console.print(f"\n  [bold]{ip}[/bold] scripts:")
                for sid, sout in scripts.items():
                    console.print(f"    [cyan]{sid}[/cyan]: {sout[:200]}")

    if args.deep:
        if not args.quiet:
            info("Running deep scan (nmap -O -sV)...")
        await deep_scan(results, ports=enum_ports or None, fast=args.fast)

    if not args.enum:
        await resolve_hostnames(results, concurrency=args.threads)

    elapsed = time.time() - t0

    if args.quiet:
        print_quiet(results)
    else:
        print_results_table(results, verbose=args.verbose)
        print_range_summary(ranges_display, results, total_hosts, elapsed)

    if args.output:
        try:
            export_results(results, args.output)
            if not args.quiet:
                success(f"Results saved to [cyan]{args.output}[/cyan]\n")
        except ValueError as exc:
            error(str(exc))
            sys.exit(1)

    if not args.quiet:
        try:
            latest = await update_task
            print_update_alert(latest)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if getattr(args, "upgrade", False):
        import subprocess
        console.print("[bold yellow][*] Upgrading NetScout via pipx...[/bold yellow]")
        subprocess.run(["pipx", "upgrade", "netscout"])
        sys.exit(0)

    if args.no_color:
        console.no_color = True

    if not args.quiet and not args.no_banner:
        print_banner()

    def _sigint_handler(sig, frame):
        console.print("\n[yellow][!] Interrupted — printing partial results...[/yellow]")
        sys.exit(130)

    signal.signal(signal.SIGINT, _sigint_handler)

    # Note: On Windows, the default ProactorEventLoop supports subprocesses.
    # Do NOT switch to WindowsSelectorEventLoopPolicy — it breaks subprocess calls.

    try:
        asyncio.run(_async_main(args, parser))
    except KeyboardInterrupt:
        console.print("\n[yellow][!] Interrupted[/yellow]")
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as exc:
        error(f"Fatal: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
