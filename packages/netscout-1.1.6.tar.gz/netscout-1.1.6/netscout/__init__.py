"""NetScout — Production-ready pentest recon CLI."""

__version__ = "1.1.6"
