# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from . import base_config_settings
from . import hr_employee
from . import hr_employee_public
