# ruff: noqa: E402
"""PyStator -- Config-driven finite state machine for Python.

Config is the single source of truth. Python provides implementations.

**Three-layer machine management** (inspired by PyCharter):

- ``machine_parser`` — parse YAML/JSON → ``MachineDefinition``
- ``machine_store``  — persist definitions (SQL, in-memory)
- ``machine_builder``— build runtime ``StateMachine`` from definitions

Quick start::

    from pystator import StateMachine
    from pystator.machine_parser import parse_machine_file
    from pystator.machine_builder import build_machine

    definition = parse_machine_file("order_fsm.yaml")
    machine = build_machine(definition)

    result = machine.process("pending", "confirm", {"valid": True})

**Subpackage organisation** (facades over implementation modules):

- ``pystator.core``          — types, engine, machine, event, session
- ``pystator.behavior``      — guards, actions, checks, effects, sinks
- ``pystator.observability`` — hooks, lint, visualization
- ``pystator.machine_parser``  — config parsing → MachineDefinition
- ``pystator.machine_store``   — pluggable definition persistence
- ``pystator.machine_builder`` — definition → StateMachine construction
"""

from __future__ import annotations

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pystator")
except Exception:
    __version__ = "0.0.0.dev0"

# ---------------------------------------------------------------------------
# Core types (re-exported from implementation modules)
# ---------------------------------------------------------------------------
from pystator._types import (
    EFFECT_TYPES,
    ActionSpec,
    CheckSpec,
    DestinationCandidate,
    DestinationCheckResult,
    GuardSpec,
    HistoryType,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    TransitionResult,
    WhenCheck,
)
from pystator.actions import ActionExecutor, ActionRegistry, ActionResult, ActionStatus
from pystator.builtins import builtin_registries, register_builtins
from pystator.checks import evaluate_check
from pystator.config.validator import ConfigValidator, validate_config
from pystator.discovery import (
    DataIngester,
    InferenceEngine,
    InferenceThresholds,
    ObservedStateEvent,
    StateClassifier,
)
from pystator.effects import apply_effect

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
from pystator.errors import (
    ActionNotFoundError,
    ConfigurationError,
    ErrorCode,
    ErrorPolicy,
    FSMError,
    GuardExecutionError,
    GuardNotFoundError,
    GuardRejectedError,
    InvalidTransitionError,
    StaleVersionError,
    TerminalStateError,
    TimeoutExpiredError,
    UndefinedStateError,
    UndefinedTriggerError,
    is_transient_error,
)

# ---------------------------------------------------------------------------
# Event
# ---------------------------------------------------------------------------
from pystator.event import Event

# ---------------------------------------------------------------------------
# Guards + Actions
# ---------------------------------------------------------------------------
from pystator.guards import (
    GuardEvaluator,
    GuardRegistry,
    GuardResult,
    all_of,
    any_of,
    equals,
    greater_than,
    in_list,
    negate,
)

# ---------------------------------------------------------------------------
# Hooks
# ---------------------------------------------------------------------------
from pystator.hooks import (
    DwellTimeTracker,
    LoggingHook,
    MetricsCollector,
    StructuredLoggingHook,
    TransitionHook,
    TransitionObserver,
)
from pystator.instance import EntitySession
from pystator.lint import LintSeverity, LintWarning, lint

# ---------------------------------------------------------------------------
# Machine + Instance
# ---------------------------------------------------------------------------
from pystator.machine import StateMachine, StateMachineBuilder, check_timeout

# ---------------------------------------------------------------------------
# Three-layer machine management
# ---------------------------------------------------------------------------
from pystator.machine_builder import (
    MachineNotFoundError,
    build_machine,
    build_machine_from_store,
)
from pystator.machine_parser import MachineDefinition, parse_machine, parse_machine_file
from pystator.machine_store import InMemoryMachineStore, MachineStoreClient

try:
    from pystator.machine_store import SQLAlchemyMachineStore
except ImportError:
    SQLAlchemyMachineStore = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------
from pystator.orchestrator import Orchestrator

# ---------------------------------------------------------------------------
# Sinks
# ---------------------------------------------------------------------------
from pystator.sinks import (
    EventSink,
    LoggingEventSink,
    LoggingMetricSink,
    MetricSink,
    configure_event_sink,
    configure_metric_sink,
    create_metric_action,
    create_publish_action,
)

# ---------------------------------------------------------------------------
# State stores (entity state persistence)
# ---------------------------------------------------------------------------
from pystator.stores import (
    AsyncStateStore,
    AuditStore,
    BatchStateStore,
    InMemoryStateStore,
    QueryableStateStore,
    StateStore,
    StateStoreClient,
    VersionedStateStore,
    batch_fallback,
)

try:
    from pystator.stores.sqlite import SQLiteStateStore
except ImportError:
    SQLiteStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.postgres import PostgresStateStore
except ImportError:
    PostgresStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.mongodb import MongoDBStateStore
except ImportError:
    MongoDBStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.redis import RedisStateStore
except ImportError:
    RedisStateStore = None  # type: ignore[assignment,misc]

# Workflow outcome (FSM-derived; same semantics as API entity ``workflow_status``)
# Parallel
from pystator._parallel import ParallelStateConfig
from pystator.workflow_status import (
    WORKFLOW_STATUS_ACTIVE,
    WORKFLOW_STATUS_COMPLETE,
    WORKFLOW_STATUS_FAILED,
    WORKFLOW_VALID_STATUSES,
    compute_workflow_status,
    persistence_flags_for_state,
)

validate_machine_config = validate_config

__all__ = [
    # Machine definition — three-layer API
    "MachineDefinition",
    "parse_machine",
    "parse_machine_file",
    "MachineStoreClient",
    "InMemoryMachineStore",
    "SQLAlchemyMachineStore",
    "build_machine",
    "build_machine_from_store",
    "MachineNotFoundError",
    # Core
    "StateMachine",
    "StateMachineBuilder",
    "ConfigValidator",
    "validate_config",
    "validate_machine_config",
    "EntitySession",
    "InferenceEngine",
    "InferenceThresholds",
    "ObservedStateEvent",
    "StateClassifier",
    "DataIngester",
    "WhenCheck",
    "Orchestrator",
    "TransitionResult",
    "DestinationCandidate",
    "DestinationCheckResult",
    "Event",
    # State stores (entity state persistence)
    "InMemoryStateStore",
    "StateStore",
    "AsyncStateStore",
    "SQLiteStateStore",
    "PostgresStateStore",
    "MongoDBStateStore",
    "RedisStateStore",
    "StateStoreClient",
    "VersionedStateStore",
    "WORKFLOW_STATUS_ACTIVE",
    "WORKFLOW_STATUS_COMPLETE",
    "WORKFLOW_STATUS_FAILED",
    "WORKFLOW_VALID_STATUSES",
    "compute_workflow_status",
    "persistence_flags_for_state",
    # Errors
    "FSMError",
    "InvalidTransitionError",
    "GuardRejectedError",
    "TerminalStateError",
    "ConfigurationError",
    "UndefinedStateError",
    "UndefinedTriggerError",
    "StaleVersionError",
    "ErrorPolicy",
    # Registries
    "GuardRegistry",
    "ActionRegistry",
    # Hooks
    "TransitionHook",
    "LoggingHook",
    # Types
    "State",
    "StateType",
    "Transition",
]
