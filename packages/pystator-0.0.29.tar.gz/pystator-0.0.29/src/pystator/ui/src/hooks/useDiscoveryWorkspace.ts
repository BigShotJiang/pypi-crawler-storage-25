'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  buildDiscoveryDraft,
  createDiscoveryDraft,
  deleteDiscoveryEntityObservations,
  deleteDiscoveryDraft,
  getApiErrorMessage,
  getDiscoveryCandidate,
  listDiscoveryMachineEntityIds,
  listDiscoveryMachines,
  listDiscoveryCandidates,
  patchDiscoveryDraft,
  previewDiscoveryDraft,
  saveDiscoveryCandidate,
  listDiscoveryShadowDiffs,
  promoteDiscoveryCandidate,
  recordDiscoveryObservation,
  validateConfig,
  type DiscoveryBuiltCandidateResponse,
  type DiscoveryBuiltCandidateSummaryItem,
  type DiscoveryDraftPatchRequest,
  type DiscoveryDraftResponse,
  type InferredEdgeApiItem,
  type DiscoveryShadowDiffResponse,
  type MachineResponse,
} from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'
import { useToastStore } from '@/stores/toast'

export interface UseDiscoveryWorkspaceResult {
  availableMachineNames: string[]
  refreshAvailableMachines: () => Promise<void>
  machineName: string
  setMachineName: (v: string) => void
  selectMachineName: (v: string) => void
  recentMachineNames: string[]
  mode: 'inference' | 'manual'
  setMode: (mode: 'inference' | 'manual') => void
  minEdgeCount: string
  setMinEdgeCount: (v: string) => void
  minConfidence: string
  setMinConfidence: (v: string) => void
  entityIds: string[]
  selectedEntityIds: string[]
  setSelectedEntityIds: (ids: string[]) => void
  previewEdges: InferredEdgeApiItem[]
  previewSelectedEdges: InferredEdgeApiItem[]
  previewObservationCount: number
  previewLoading: boolean
  preview: () => Promise<void>
  selectedEdgeKeys: string[]
  setSelectedEdgeKeys: (keys: string[]) => void
  builtCandidates: DiscoveryBuiltCandidateSummaryItem[]
  selectedVersion: string | null
  selectVersion: (v: string | null) => void
  detail: DiscoveryBuiltCandidateResponse | null
  shadowDiffs: DiscoveryShadowDiffResponse[]
  promoted: MachineResponse | null
  error: string | null
  clearError: () => void
  loadingList: boolean
  loadingDetail: boolean
  loadingShadow: boolean
  building: boolean
  observing: boolean
  promoting: boolean
  loadCandidates: () => Promise<void>
  /** Set machine in recents and load candidates + shadow for fleet navigation. */
  openMachine: (name: string) => Promise<void>
  loadDetailFor: (version: string) => Promise<void>
  loadShadow: () => Promise<void>
  build: () => Promise<void>
  saveEditedCandidate: (
    config: FSMConfig,
    targetMachineName: string,
    targetVersion?: string
  ) => Promise<DiscoveryBuiltCandidateResponse>
  promote: (version: string) => Promise<MachineResponse>
  /** Record one observation (entity + state). Returns true on success. */
  observe: (entityId: string, state: string) => Promise<boolean>
  /** Record many observations (e.g. from pasted text). Returns true on full success. */
  observeBulkFromText: (text: string) => Promise<boolean>
  drafts: DiscoveryDraftResponse[]
  activeDraftId: string | null
  selectDraft: (id: string | null) => void
  createDraft: () => Promise<void>
  deleteDraft: (draftId: string) => Promise<void>
  /** Reload entity ID list from the API (latest observations per machine). */
  refreshObservationEntities: () => Promise<void>
  deleteObservationEntity: (entityId: string) => Promise<boolean>
  loadingEntityIds: boolean
}

const DISCOVERY_LAST_MACHINE_KEY = 'pystator_discovery_last_machine'
const DISCOVERY_RECENT_MACHINES_KEY = 'pystator_discovery_recent_machines'
const MAX_RECENT_MACHINE_NAMES = 8

export function parseBulkObservationLines(
  text: string
):
  | { ok: true; items: { entityId: string; state: string }[] }
  | { ok: false; error: string } {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !l.startsWith('#'))
  const items: { entityId: string; state: string }[] = []
  for (const line of lines) {
    if (line.startsWith('{')) {
      try {
        const o = JSON.parse(line) as { entity_id?: unknown; state?: unknown }
        const entityId = typeof o.entity_id === 'string' ? o.entity_id : ''
        const state = typeof o.state === 'string' ? o.state : ''
        if (!entityId.trim() || !state.trim()) {
          return { ok: false, error: `Invalid JSON line (need entity_id + state): ${line.slice(0, 64)}` }
        }
        items.push({ entityId: entityId.trim(), state: state.trim() })
      } catch {
        return { ok: false, error: `Invalid JSON: ${line.slice(0, 64)}` }
      }
    } else {
      const comma = line.indexOf(',')
      if (comma <= 0) {
        return {
          ok: false,
          error: `Expected entity_id,state or JSON object per line: ${line.slice(0, 64)}`,
        }
      }
      const entityId = line.slice(0, comma).trim()
      const state = line.slice(comma + 1).trim()
      if (!entityId || !state) {
        return { ok: false, error: `Empty entity or state: ${line.slice(0, 64)}` }
      }
      items.push({ entityId, state })
    }
  }
  if (items.length === 0) {
    return { ok: false, error: 'No rows to import. Use entity_id,state per line or JSON lines.' }
  }
  return { ok: true, items }
}

function normalizeMachineName(value: string): string {
  return value.trim()
}

function loadRecentMachineNames(): string[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(DISCOVERY_RECENT_MACHINES_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as unknown
    if (!Array.isArray(parsed)) return []
    return parsed
      .map((v) => (typeof v === 'string' ? normalizeMachineName(v) : ''))
      .filter(Boolean)
      .slice(0, MAX_RECENT_MACHINE_NAMES)
  } catch {
    return []
  }
}

function saveRecentMachineNames(names: string[]) {
  if (typeof window === 'undefined') return
  window.localStorage.setItem(DISCOVERY_RECENT_MACHINES_KEY, JSON.stringify(names))
}

function pushRecentMachineName(current: string[], value: string): string[] {
  const normalized = normalizeMachineName(value)
  if (!normalized) return current
  const deduped = [normalized, ...current.filter((x) => x !== normalized)]
  return deduped.slice(0, MAX_RECENT_MACHINE_NAMES)
}

function buildDraftPatchFromLocal(
  mode: 'inference' | 'manual',
  minEdgeCount: string,
  minConfidence: string,
  selectedEntityIds: string[],
  selectedEdgeKeys: string[]
): DiscoveryDraftPatchRequest {
  return {
    mode,
    selected_entity_ids: [...selectedEntityIds],
    min_edge_count: Math.max(1, Number.parseInt(minEdgeCount, 10) || 1),
    min_confidence: Math.min(1, Math.max(0, Number.parseFloat(minConfidence) || 0)),
    manual_edge_selection:
      mode === 'manual'
        ? selectedEdgeKeys.map((key) => {
            const [source_state, destination_state] = key.split('|||')
            return { source_state, destination_state }
          })
        : [],
  }
}

function draftMatchesUi(
  ws: DiscoveryDraftResponse,
  mode: 'inference' | 'manual',
  minEdgeCount: string,
  minConfidence: string,
  selectedEntityIds: string[],
  selectedEdgeKeys: string[]
): boolean {
  if (ws.mode !== mode) return false
  const a = [...ws.selected_entity_ids].sort().join('\0')
  const b = [...selectedEntityIds].sort().join('\0')
  if (a !== b) return false
  const mc = Math.max(1, Number.parseInt(minEdgeCount, 10) || 1)
  const cf = Math.min(1, Math.max(0, Number.parseFloat(minConfidence) || 0))
  if (ws.min_edge_count !== mc || Math.abs(ws.min_confidence - cf) > 1e-9) return false
  if (mode !== 'manual') return true
  const serverKeys = new Set(
    ws.manual_edge_selection.map((e) => `${e.source_state}|||${e.destination_state}`)
  )
  const localKeys = new Set(selectedEdgeKeys)
  if (serverKeys.size !== localKeys.size) return false
  for (const k of localKeys) {
    if (!serverKeys.has(k)) return false
  }
  return true
}

function draftPatchFingerprint(
  mode: 'inference' | 'manual',
  minEdgeCount: string,
  minConfidence: string,
  selectedEntityIds: string[],
  selectedEdgeKeys: string[]
): string {
  const mc = Math.max(1, Number.parseInt(minEdgeCount, 10) || 1)
  const cf = Math.min(1, Math.max(0, Number.parseFloat(minConfidence) || 0))
  const entityIds = [...selectedEntityIds].sort().join('\0')
  const edgeKeys =
    mode === 'manual' ? [...new Set(selectedEdgeKeys)].sort().join('\0') : ''
  return `${mode}|${mc}|${cf}|${entityIds}|${edgeKeys}`
}

export function useDiscoveryWorkspace(): UseDiscoveryWorkspaceResult {
  const [availableMachineNames, setAvailableMachineNames] = useState<string[]>([])
  const [machineName, setMachineName] = useState('')
  const [recentMachineNames, setRecentMachineNames] = useState<string[]>([])
  const [mode, setMode] = useState<'inference' | 'manual'>('inference')
  const [minEdgeCount, setMinEdgeCount] = useState('2')
  const [minConfidence, setMinConfidence] = useState('0.5')
  const [entityIds, setEntityIds] = useState<string[]>([])
  const [selectedEntityIds, setSelectedEntityIds] = useState<string[]>([])
  const [previewEdges, setPreviewEdges] = useState<InferredEdgeApiItem[]>([])
  const [previewSelectedEdges, setPreviewSelectedEdges] = useState<InferredEdgeApiItem[]>([])
  const [previewObservationCount, setPreviewObservationCount] = useState(0)
  const [previewLoading, setPreviewLoading] = useState(false)
  const [selectedEdgeKeys, setSelectedEdgeKeys] = useState<string[]>([])
  const [builtCandidates, setBuiltCandidates] = useState<DiscoveryBuiltCandidateSummaryItem[]>([])
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null)
  const [detail, setDetail] = useState<DiscoveryBuiltCandidateResponse | null>(null)
  const [shadowDiffs, setShadowDiffs] = useState<DiscoveryShadowDiffResponse[]>([])
  const [promoted, setPromoted] = useState<MachineResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loadingList, setLoadingList] = useState(false)
  const [loadingDetail, setLoadingDetail] = useState(false)
  const [loadingShadow, setLoadingShadow] = useState(false)
  const [building, setBuilding] = useState(false)
  const [observing, setObserving] = useState(false)
  const [promoting, setPromoting] = useState(false)
  const [drafts, setDrafts] = useState<DiscoveryDraftResponse[]>([])
  const [activeDraftId, setActiveDraftId] = useState<string | null>(null)
  const [loadingEntityIds, setLoadingEntityIds] = useState(false)
  const lastHydratedDraftIdRef = useRef<string | null>(null)
  const lastPatchedFingerprintRef = useRef<string | null>(null)
  const previewRequestSeqRef = useRef(0)
  const autosaveRequestSeqRef = useRef(0)
  const activeDraftIdRef = useRef<string | null>(null)
  const machineNameRef = useRef('')
  const autoPreviewedDraftIdRef = useRef<string | null>(null)
  const toastSuccess = useToastStore((s) => s.success)

  useEffect(() => {
    activeDraftIdRef.current = activeDraftId
  }, [activeDraftId])

  useEffect(() => {
    machineNameRef.current = machineName.trim()
  }, [machineName])

  useEffect(() => {
    if (typeof window === 'undefined') return
    const last = normalizeMachineName(window.localStorage.getItem(DISCOVERY_LAST_MACHINE_KEY) ?? '')
    if (last) setMachineName(last)
    setRecentMachineNames(loadRecentMachineNames())
  }, [])

  const refreshAvailableMachines = useCallback(async () => {
    try {
      const rows = await listDiscoveryMachines({ limit: 500, offset: 0 })
      const names = rows.items.map((x) => x.machine_name).filter(Boolean)
      setAvailableMachineNames(Array.from(new Set(names)).sort())
    } catch {
      // Non-blocking.
    }
  }, [])

  useEffect(() => {
    void refreshAvailableMachines()
  }, [refreshAvailableMachines])

  useEffect(() => {
    if (typeof window === 'undefined') return
    const normalized = normalizeMachineName(machineName)
    if (!normalized) return
    window.localStorage.setItem(DISCOVERY_LAST_MACHINE_KEY, normalized)
  }, [machineName])

  const clearError = useCallback(() => setError(null), [])

  const selectMachineName = useCallback((value: string) => {
    const normalized = normalizeMachineName(value)
    setMachineName(normalized)
    if (!normalized) return
    setRecentMachineNames((prev) => {
      const next = pushRecentMachineName(prev, normalized)
      saveRecentMachineNames(next)
      return next
    })
  }, [])

  const loadCandidatesFor = useCallback(async (name: string) => {
    const n = name.trim()
    if (!n) {
      setError('Enter a machine name first.')
      return
    }
    setLoadingList(true)
    setError(null)
    try {
      const res = await listDiscoveryCandidates(n)
      setBuiltCandidates(res.built_candidates)
      setDrafts(res.drafts ?? [])
      setPromoted(null)
      try {
        const entities = await listDiscoveryMachineEntityIds(n)
        setEntityIds(entities.entity_ids)
      } catch {
        setEntityIds([])
      }
      setRecentMachineNames((prev) => {
        const next = pushRecentMachineName(prev, n)
        saveRecentMachineNames(next)
        return next
      })
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load candidates'))
    } finally {
      setLoadingList(false)
    }
  }, [])

  const loadCandidates = useCallback(async () => {
    await loadCandidatesFor(machineName)
  }, [machineName, loadCandidatesFor])

  const refreshObservationEntities = useCallback(async () => {
    const n = machineName.trim()
    if (!n) {
      setError('Enter a machine name first.')
      return
    }
    setLoadingEntityIds(true)
    setError(null)
    try {
      const entities = await listDiscoveryMachineEntityIds(n)
      setEntityIds(entities.entity_ids)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to fetch entity IDs from observations'))
      setEntityIds([])
    } finally {
      setLoadingEntityIds(false)
    }
  }, [machineName])

  const deleteObservationEntity = useCallback(
    async (entityId: string): Promise<boolean> => {
      const n = machineName.trim()
      const id = entityId.trim()
      if (!n) {
        setError('Enter a machine name first.')
        return false
      }
      if (!id) return false
      setError(null)
      try {
        const res = await deleteDiscoveryEntityObservations(n, id)
        const entities = await listDiscoveryMachineEntityIds(n)
        setEntityIds(entities.entity_ids)
        setSelectedEntityIds((prev) => prev.filter((x) => x !== id))
        const count = res.deleted_count
        toastSuccess(
          count === 0
            ? `No discovery observations removed for entity ${id}.`
            : count === 1
              ? `Deleted 1 discovery observation for entity ${id}.`
              : `Deleted ${count} discovery observations for entity ${id}.`
        )
        return true
      } catch (e) {
        setError(getApiErrorMessage(e, `Failed to delete observations for entity ${id}`))
        return false
      }
    },
    [machineName, toastSuccess]
  )

  useEffect(() => {
    if (!activeDraftId) {
      lastHydratedDraftIdRef.current = null
      lastPatchedFingerprintRef.current = null
      autoPreviewedDraftIdRef.current = null
      return
    }
    const ws = drafts.find((w) => w.id === activeDraftId)
    if (!ws) return
    if (lastHydratedDraftIdRef.current === activeDraftId) return
    lastHydratedDraftIdRef.current = activeDraftId
    setMode(ws.mode === 'manual' ? 'manual' : 'inference')
    setMinEdgeCount(String(ws.min_edge_count))
    setMinConfidence(String(ws.min_confidence))
    setSelectedEntityIds([...ws.selected_entity_ids])
    setSelectedEdgeKeys(
      ws.manual_edge_selection.map((e) => `${e.source_state}|||${e.destination_state}`)
    )
    setPreviewEdges([])
    setPreviewSelectedEdges([])
    setPreviewObservationCount(0)
  }, [activeDraftId, drafts])

  const activeDraft = activeDraftId
    ? drafts.find((w) => w.id === activeDraftId) ?? null
    : null

  useEffect(() => {
    if (!activeDraftId || !machineName.trim()) return
    const ws = activeDraft
    if (
      ws &&
      draftMatchesUi(ws, mode, minEdgeCount, minConfidence, selectedEntityIds, selectedEdgeKeys)
    ) {
      lastPatchedFingerprintRef.current = null
      return
    }
    const fingerprint = draftPatchFingerprint(
      mode,
      minEdgeCount,
      minConfidence,
      selectedEntityIds,
      selectedEdgeKeys
    )
    if (lastPatchedFingerprintRef.current === fingerprint) {
      return
    }
    const name = machineName.trim()
    const id = activeDraftId
    const timer = window.setTimeout(() => {
      void (async () => {
        const requestSeq = ++autosaveRequestSeqRef.current
        try {
          lastPatchedFingerprintRef.current = fingerprint
          const updated = await patchDiscoveryDraft(
            name,
            id,
            buildDraftPatchFromLocal(
              mode,
              minEdgeCount,
              minConfidence,
              selectedEntityIds,
              selectedEdgeKeys
            )
          )
          if (
            requestSeq !== autosaveRequestSeqRef.current ||
            activeDraftIdRef.current !== id ||
            machineNameRef.current !== name
          ) {
            return
          }
          setDrafts((prev) => prev.map((w) => (w.id === updated.id ? updated : w)))
        } catch (e) {
          if (requestSeq === autosaveRequestSeqRef.current) {
            lastPatchedFingerprintRef.current = null
          }
          setError(getApiErrorMessage(e, 'Failed to save draft'))
        }
      })()
    }, 400)
    return () => window.clearTimeout(timer)
  }, [
    activeDraftId,
    machineName,
    mode,
    minEdgeCount,
    minConfidence,
    selectedEntityIds,
    selectedEdgeKeys,
    activeDraft,
  ])

  const loadShadowFor = useCallback(async (name: string) => {
    const n = name.trim()
    if (!n) return
    setLoadingShadow(true)
    setError(null)
    try {
      const rows = await listDiscoveryShadowDiffs(n, 200)
      setShadowDiffs(rows)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load shadow diffs'))
      setShadowDiffs([])
    } finally {
      setLoadingShadow(false)
    }
  }, [])

  const openMachine = useCallback(
    async (name: string) => {
      const normalized = normalizeMachineName(name)
      selectMachineName(normalized)
      if (!normalized) return
      setSelectedVersion(null)
      setDetail(null)
      setActiveDraftId(null)
      lastHydratedDraftIdRef.current = null
      await Promise.all([loadCandidatesFor(normalized), loadShadowFor(normalized)])
    },
    [selectMachineName, loadCandidatesFor, loadShadowFor]
  )

  const loadDetailFor = useCallback(
    async (version: string) => {
      const name = machineName.trim()
      if (!name) return
      setLoadingDetail(true)
      setError(null)
      try {
        const d = await getDiscoveryCandidate(name, version)
        setDetail(d)
        setSelectedVersion(version)
      } catch (e) {
        setError(getApiErrorMessage(e, 'Failed to load candidate'))
        setDetail(null)
      } finally {
        setLoadingDetail(false)
      }
    },
    [machineName]
  )

  const loadShadow = useCallback(async () => {
    await loadShadowFor(machineName)
  }, [machineName, loadShadowFor])

  const selectDraft = useCallback((id: string | null) => {
    setSelectedVersion(null)
    setDetail(null)
    if (!id) {
      setActiveDraftId(null)
      lastHydratedDraftIdRef.current = null
      setPreviewEdges([])
      setPreviewSelectedEdges([])
      setPreviewObservationCount(0)
      return
    }
    lastHydratedDraftIdRef.current = null
    setActiveDraftId(id)
  }, [])

  const createDraft = useCallback(async () => {
    const name = machineName.trim()
    if (!name) {
      setError('Enter a machine name first.')
      return
    }
    setError(null)
    try {
      const ws = await createDiscoveryDraft(name, {})
      await loadCandidatesFor(name)
      setSelectedVersion(null)
      setDetail(null)
      lastHydratedDraftIdRef.current = null
      setActiveDraftId(ws.id)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to create draft'))
    }
  }, [machineName, loadCandidatesFor])

  const deleteDraft = useCallback(
    async (draftId: string) => {
      const name = machineName.trim()
      if (!name) return
      setError(null)
      try {
        await deleteDiscoveryDraft(name, draftId)
        setDrafts((prev) => prev.filter((w) => w.id !== draftId))
        if (activeDraftId === draftId) {
          setActiveDraftId(null)
          lastHydratedDraftIdRef.current = null
          setPreviewEdges([])
          setPreviewSelectedEdges([])
          setPreviewObservationCount(0)
        }
      } catch (e) {
        setError(getApiErrorMessage(e, 'Failed to delete draft'))
      }
    },
    [machineName, activeDraftId]
  )

  const selectVersion = useCallback(
    (v: string | null) => {
      setActiveDraftId(null)
      lastHydratedDraftIdRef.current = null
      setSelectedVersion(v)
      if (v) {
        void loadDetailFor(v)
      } else {
        setDetail(null)
      }
    },
    [loadDetailFor]
  )

  const build = useCallback(async () => {
    const name = machineName.trim()
    if (!name) {
      setError('Enter a machine name first.')
      return
    }
    if (!activeDraftId) {
      setError('Select or create a draft before building.')
      return
    }
    if (selectedEntityIds.length === 0) {
      setError('Select at least one entity ID on the draft before building.')
      return
    }
    if (mode === 'manual' && selectedEdgeKeys.length === 0) {
      setError(
        'Manual mode needs at least one edge selected. Run Preview first (so the edge list loads), then tick one or more edges—or use Inference mode to build from thresholds only.'
      )
      return
    }
    setBuilding(true)
    setError(null)
    try {
      const patchBody = buildDraftPatchFromLocal(
        mode,
        minEdgeCount,
        minConfidence,
        selectedEntityIds,
        selectedEdgeKeys
      )
      await patchDiscoveryDraft(name, activeDraftId, patchBody)
      const built = await buildDiscoveryDraft(name, activeDraftId)
      await loadCandidates()
      selectVersion(built.version)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Build failed'))
    } finally {
      setBuilding(false)
    }
  }, [
    machineName,
    loadCandidates,
    activeDraftId,
    mode,
    selectedEntityIds,
    selectedEdgeKeys,
    minEdgeCount,
    minConfidence,
    selectVersion,
  ])

  const preview = useCallback(async () => {
    const name = machineName.trim()
    if (!name) {
      setError('Enter a machine name first.')
      return
    }
    if (!activeDraftId) {
      setError('Select or create a draft before preview.')
      return
    }
    if (selectedEntityIds.length === 0) {
      setError('Select at least one entity ID on the draft before preview.')
      return
    }
    setPreviewLoading(true)
    setError(null)
    const requestSeq = ++previewRequestSeqRef.current
    const requestDraftId = activeDraftId
    try {
      await patchDiscoveryDraft(
        name,
        activeDraftId,
        buildDraftPatchFromLocal(
          mode,
          minEdgeCount,
          minConfidence,
          selectedEntityIds,
          selectedEdgeKeys
        )
      )
      const res = await previewDiscoveryDraft(name, activeDraftId)
      if (
        requestSeq !== previewRequestSeqRef.current ||
        activeDraftIdRef.current !== requestDraftId ||
        machineNameRef.current !== name
      ) {
        return
      }
      setPreviewEdges(res.edges)
      setPreviewSelectedEdges(res.selected_edges)
      setPreviewObservationCount(res.observation_count)
      if (mode === 'manual') {
        const keys = new Set(
          res.selected_edges.map((e) => `${e.source_state}|||${e.destination_state}`)
        )
        setSelectedEdgeKeys(Array.from(keys))
      }
    } catch (e) {
      if (requestSeq === previewRequestSeqRef.current) {
        setError(getApiErrorMessage(e, 'Preview failed'))
      }
    } finally {
      if (requestSeq === previewRequestSeqRef.current) {
        setPreviewLoading(false)
      }
    }
  }, [
    machineName,
    activeDraftId,
    mode,
    selectedEntityIds,
    selectedEdgeKeys,
    minEdgeCount,
    minConfidence,
  ])

  useEffect(() => {
    if (!activeDraftId || selectedVersion) {
      return
    }
    if (autoPreviewedDraftIdRef.current === activeDraftId) {
      return
    }
    if (previewLoading) {
      return
    }
    if (selectedEntityIds.length === 0) {
      return
    }
    autoPreviewedDraftIdRef.current = activeDraftId
    void preview()
  }, [activeDraftId, selectedVersion, selectedEntityIds, previewLoading, preview])

  const observe = useCallback(
    async (entityId: string, state: string): Promise<boolean> => {
      const name = machineName.trim()
      if (!name) {
        setError('Enter a machine name first.')
        return false
      }
      if (!entityId.trim() || !state.trim()) {
        setError('Entity ID and state are required.')
        return false
      }
      setObserving(true)
      setError(null)
      try {
        await recordDiscoveryObservation({
          machine_name: name,
          entity_id: entityId.trim(),
          state: state.trim(),
          source: 'ui',
        })
        return true
      } catch (e) {
        setError(getApiErrorMessage(e, 'Observation failed'))
        return false
      } finally {
        setObserving(false)
      }
    },
    [machineName]
  )

  const observeBatch = useCallback(
    async (items: { entityId: string; state: string }[]): Promise<boolean> => {
      const name = machineName.trim()
      if (!name) {
        setError('Enter a machine name first.')
        return false
      }
      if (items.length === 0) {
        setError('No valid rows to record.')
        return false
      }
      setObserving(true)
      setError(null)
      let idx = 0
      const concurrency = 5
      async function worker(): Promise<void> {
        while (idx < items.length) {
          const i = idx++
          const { entityId, state } = items[i]
          await recordDiscoveryObservation({
            machine_name: name,
            entity_id: entityId.trim(),
            state: state.trim(),
            source: 'ui-batch',
          })
        }
      }
      try {
        await Promise.all(
          Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
        )
        await loadCandidatesFor(name)
        return true
      } catch (e) {
        setError(getApiErrorMessage(e, 'Batch observation failed'))
        return false
      } finally {
        setObserving(false)
      }
    },
    [machineName, loadCandidatesFor]
  )

  const observeBulkFromText = useCallback(
    async (text: string): Promise<boolean> => {
      const parsed = parseBulkObservationLines(text)
      if (!parsed.ok) {
        setError(parsed.error)
        return false
      }
      return observeBatch(parsed.items)
    },
    [observeBatch]
  )

  const promote = useCallback(
    async (version: string) => {
      const name = machineName.trim()
      if (!name) throw new Error('Machine name required')
      setPromoting(true)
      setError(null)
      try {
        const m = await promoteDiscoveryCandidate(name, version)
        setPromoted(m)
        return m
      } catch (e) {
        const msg = getApiErrorMessage(e, 'Promote failed')
        setError(msg)
        throw e
      } finally {
        setPromoting(false)
      }
    },
    [machineName]
  )

  const saveEditedCandidate = useCallback(
    async (config: FSMConfig, targetMachineName: string, targetVersion?: string) => {
      const source = machineName.trim()
      if (!source) throw new Error('Discovery machine name required')
      const target = targetMachineName.trim()
      if (!target) throw new Error('Target machine name required')
      const valid = await validateConfig(config)
      if (!valid.valid) {
        throw new Error(valid.errors.join('; ') || 'Invalid FSM config')
      }
      const saved = await saveDiscoveryCandidate({
        source_machine_name: source,
        target_machine_name: target,
        target_version: targetVersion?.trim() || undefined,
        config: config as unknown as Record<string, unknown>,
        metadata: {
          mode,
          selected_entity_ids: selectedEntityIds,
          ...(activeDraftId ? { draft_id: activeDraftId } : {}),
        },
      })
      await loadCandidates()
      return saved
    },
    [machineName, mode, selectedEntityIds, activeDraftId, loadCandidates]
  )

  return {
    availableMachineNames,
    refreshAvailableMachines,
    machineName,
    setMachineName,
    selectMachineName,
    recentMachineNames,
    mode,
    setMode,
    minEdgeCount,
    setMinEdgeCount,
    minConfidence,
    setMinConfidence,
    entityIds,
    selectedEntityIds,
    setSelectedEntityIds,
    previewEdges,
    previewSelectedEdges,
    previewObservationCount,
    previewLoading,
    preview,
    selectedEdgeKeys,
    setSelectedEdgeKeys,
    builtCandidates,
    selectedVersion,
    selectVersion,
    detail,
    shadowDiffs,
    promoted,
    error,
    clearError,
    loadingList,
    loadingDetail,
    loadingShadow,
    building,
    observing,
    promoting,
    loadCandidates,
    openMachine,
    loadDetailFor,
    loadShadow,
    build,
    saveEditedCandidate,
    promote,
    observe,
    observeBulkFromText,
    drafts,
    activeDraftId,
    selectDraft,
    createDraft,
    deleteDraft,
    refreshObservationEntities,
    deleteObservationEntity,
    loadingEntityIds,
  }
}
