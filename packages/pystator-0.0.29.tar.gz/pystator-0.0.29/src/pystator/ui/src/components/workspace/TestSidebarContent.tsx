'use client'

import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { processEvent, ApiError } from '@/lib/api'
import ErrorDisplay from '@/components/ErrorDisplay'
import {
  useWorkspaceStore,
  selectConfig,
  selectSessionState,
  selectSetSessionState,
  selectStateTrail,
  selectProcessHistory,
  selectAddProcessResult,
  selectClearProcessHistory,
  selectResetSession,
} from '@/stores/workspace'
import type { ProcessResponse } from '@/lib/types/fsm'
import { formatProcessActionsList } from '@/lib/formatProcessActions'
import { RotateCcw, Play, History, Trash2 } from 'lucide-react'

function getUniqueTriggers(config: { transitions?: { trigger?: string }[] }): string[] {
  const set = new Set<string>()
  for (const t of config.transitions ?? []) {
    if (t.trigger) set.add(t.trigger)
  }
  return Array.from(set).sort()
}

export default function TestSidebarContent() {
  const config = useWorkspaceStore(selectConfig)
  const sessionState = useWorkspaceStore(selectSessionState)
  const setSessionState = useWorkspaceStore(selectSetSessionState)
  const stateTrail = useWorkspaceStore(selectStateTrail)
  const processHistory = useWorkspaceStore(selectProcessHistory)
  const addProcessResult = useWorkspaceStore(selectAddProcessResult)
  const resetSession = useWorkspaceStore(selectResetSession)
  const clearProcessHistory = useWorkspaceStore(selectClearProcessHistory)
  const [trigger, setTrigger] = useState('')
  const [contextJson, setContextJson] = useState('{}')
  const [result, setResult] = useState<ProcessResponse | null>(null)
  const [error, setError] = useState<Error | ApiError | null>(null)
  const [loading, setLoading] = useState(false)

  const stateNames = (config.states ?? []).map((s) => s.name)
  const triggers = getUniqueTriggers(config)
  const stateVariables = config.state_variables ?? []

  const fillFromStateVariables = useCallback(() => {
    const obj: Record<string, unknown> = {}
    for (const sv of stateVariables) {
      const key = typeof sv === 'string' ? sv : sv.key
      const def = typeof sv === 'object' && sv !== null && 'default' in sv ? sv.default : undefined
      obj[key] = def !== undefined && def !== null ? def : null
    }
    setContextJson(JSON.stringify(obj, null, 2))
  }, [stateVariables])

  const handleProcess = useCallback(async () => {
    setError(null)
    setResult(null)
    let context: Record<string, unknown> = {}
    try {
      context = contextJson.trim() ? (JSON.parse(contextJson) as Record<string, unknown>) : {}
    } catch {
      setError(new Error('Invalid context JSON'))
      return
    }
    setLoading(true)
    try {
      const res = await processEvent(config, sessionState, trigger || (triggers[0] ?? ''), context)
      setResult(res)
      addProcessResult(res)
    } catch (e) {
      setError(e instanceof ApiError ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [config, sessionState, trigger, contextJson, triggers, addProcessResult])

  const handleClearHistory = useCallback(() => {
    clearProcessHistory()
    setResult(null)
    setError(null)
  }, [clearProcessHistory])

  return (
    <div className="space-y-3 px-2 py-3">
      <div className="flex flex-wrap gap-1.5">
        <Button variant="outline" size="sm" onClick={resetSession} className="gap-1 text-xs">
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>

      {error && <ErrorDisplay error={error} className="mt-1 text-xs" />}

      <div className="space-y-2">
        <Label className="text-xs">Current state</Label>
        <select
          className="w-full rounded-md border border-input bg-background px-2.5 py-1.5 text-sm"
          value={sessionState}
          onChange={(e) => setSessionState(e.target.value)}
        >
          {stateNames.length === 0 ? (
            <option value="">No states</option>
          ) : (
            stateNames.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))
          )}
        </select>
      </div>

      <div className="space-y-2">
        <Label className="text-xs">Trigger</Label>
        <select
          className="w-full rounded-md border border-input bg-background px-2.5 py-1.5 text-sm"
          value={trigger || (triggers[0] ?? '')}
          onChange={(e) => setTrigger(e.target.value)}
        >
          {triggers.length === 0 ? (
            <option value="">No triggers</option>
          ) : (
            triggers.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))
          )}
        </select>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <Label className="text-xs">Context (JSON)</Label>
          {stateVariables.length > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-muted-foreground"
              onClick={fillFromStateVariables}
              title="Pre-fill with keys and defaults from state variables"
            >
              Fill from state variables
            </Button>
          )}
        </div>
        <textarea
          className="w-full h-16 font-mono text-xs rounded-md border border-input bg-background px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-ring"
          value={contextJson}
          onChange={(e) => setContextJson(e.target.value)}
          spellCheck={false}
          placeholder="{}"
        />
      </div>

      <Button onClick={handleProcess} disabled={loading || stateNames.length === 0} size="sm" className="w-full gap-1.5">
        {loading ? 'Processing...' : <><Play className="h-3.5 w-3.5" /> Process event</>}
      </Button>

      <div className="space-y-1.5 pt-1 border-t border-border/50">
        <span className="text-xs font-medium text-muted-foreground">State trail</span>
        <div className="flex flex-wrap gap-1">
          {stateTrail.length === 0 ? (
            <span className="text-xs text-muted-foreground">—</span>
          ) : (
            stateTrail.map((s, i) => (
              <span key={i}>
                <span className="inline-flex px-1.5 py-0.5 rounded text-xs font-medium bg-muted">{s}</span>
                {i < stateTrail.length - 1 && <span className="text-muted-foreground mx-0.5">→</span>}
              </span>
            ))
          )}
        </div>
      </div>

      {result && (
        <div className={`rounded-md border p-2 text-xs ${result.success ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-destructive/50 bg-destructive/5'}`}>
          <span className={result.success ? 'text-emerald-600 font-medium' : 'text-destructive font-medium'}>
            {result.success ? 'Success' : 'Failed'}
          </span>
          <p className="mt-0.5 text-muted-foreground">
            {result.success
              ? `${result.source_state} → ${result.target_state} (${result.trigger})`
              : result.error?.message}
          </p>
          {result.success && result.actions_to_execute.length > 0 && (
            <p className="mt-0.5 text-muted-foreground">Actions: {formatProcessActionsList(result.actions_to_execute)}</p>
          )}
        </div>
      )}

      <div className="space-y-1.5 pt-1 border-t border-border/50">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 min-w-0">
            <History className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <span className="text-xs font-medium text-muted-foreground">History</span>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-7 gap-1 text-xs shrink-0"
            disabled={processHistory.length === 0}
            onClick={handleClearHistory}
            title="Clear process event history"
          >
            <Trash2 className="h-3 w-3" />
            Clear history
          </Button>
        </div>
        {processHistory.length === 0 ? (
          <p className="text-xs text-muted-foreground">No events yet.</p>
        ) : (
          <ul className="space-y-0.5 max-h-32 overflow-auto">
            {processHistory.slice(0, 15).map((r, i) => (
              <li key={i} className="text-xs flex items-center gap-1.5">
                <span className={r.success ? 'text-emerald-600' : 'text-destructive'}>{r.success ? '✓' : '✗'}</span>
                <span className="text-muted-foreground">
                  {r.source_state} → {r.target_state ?? '—'} on {r.trigger}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
