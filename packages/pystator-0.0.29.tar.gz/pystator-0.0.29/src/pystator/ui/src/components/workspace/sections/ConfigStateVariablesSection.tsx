'use client'

import { Button } from '@/components/ui/button'
import type { FSMStateVariable } from '@/lib/types/fsm'
import { Trash2, Pencil, Variable } from 'lucide-react'
import { EmptyState } from '@/components/EmptyState'

export interface ConfigStateVariablesSectionProps {
  stateVariables: FSMStateVariable[]
  onAddVariable: () => void
  onEditVariable: (index: number) => void
  onRemove: (index: number) => void
}

export function ConfigStateVariablesSection({
  stateVariables,
  onAddVariable,
  onEditVariable,
  onRemove,
}: ConfigStateVariablesSectionProps) {
  return (
    <div className="space-y-3">
      {stateVariables.length === 0 ? (
        <EmptyState
          icon={<Variable className="h-8 w-8" />}
          title="No state variables defined"
          description="Define context keys for guards and actions."
          actionLabel="Add variable"
          onAction={onAddVariable}
        />
      ) : (
        <div className="space-y-2">
          {stateVariables.map((sv, i) => (
            <div
              key={i}
              className="flex items-center gap-2 rounded border p-2 bg-muted/30"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-1.5 flex-wrap">
                  <span className="text-sm font-medium">{sv.key || '(empty key)'}</span>
                  {(sv.type || sv.required) && (
                    <span className="text-xs text-muted-foreground">
                      ({[sv.type, sv.required ? 'required' : null].filter(Boolean).join(', ')})
                    </span>
                  )}
                </div>
                {sv.description && (
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{sv.description}</p>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0"
                onClick={() => onEditVariable(i)}
                aria-label="Edit variable"
              >
                <Pencil className="h-3.5 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0 text-destructive"
                onClick={() => onRemove(i)}
                aria-label="Remove variable"
              >
                <Trash2 className="h-3.5 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
