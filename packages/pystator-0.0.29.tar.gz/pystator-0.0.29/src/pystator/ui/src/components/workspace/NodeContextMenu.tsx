'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { FolderPlus, Pencil, Trash2, FolderOutput } from 'lucide-react'
import type { MachineBrowseTreeNode } from '@/lib/types/machine-browse'

export interface NodeContextMenuProps {
  node: MachineBrowseTreeNode
  children: React.ReactNode
  onNewSubfolder?: () => void
  onRename?: () => void
  onDelete?: () => void
  onRemoveFromFolder?: () => void
}

/**
 * Right-click context menu for folder tree nodes. Mirrors pycharter NodeContextMenu.
 */
export function NodeContextMenu({
  node,
  children,
  onNewSubfolder,
  onRename,
  onDelete,
  onRemoveFromFolder,
}: NodeContextMenuProps) {
  const isFolder = node.kind === 'folder'
  const [open, setOpen] = useState(false)
  const [position, setPosition] = useState({ x: 0, y: 0 })

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setPosition({ x: e.clientX, y: e.clientY })
    setOpen(true)
  }, [])

  useEffect(() => {
    if (!open) return
    const handler = () => setOpen(false)
    document.addEventListener('click', handler, { once: true })
    return () => document.removeEventListener('click', handler)
  }, [open])

  return (
    <div onContextMenu={handleContextMenu}>
      {children}
      <DropdownMenu open={open} onOpenChange={setOpen}>
        <DropdownMenuTrigger asChild>
          <span
            className="fixed pointer-events-none"
            style={{ left: position.x, top: position.y, width: 1, height: 1 }}
          />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-44">
          {isFolder && onNewSubfolder && (
            <DropdownMenuItem onClick={onNewSubfolder}>
              <FolderPlus className="mr-2 h-4 w-4" />
              New Subfolder
            </DropdownMenuItem>
          )}
          {isFolder && onRename && (
            <DropdownMenuItem onClick={onRename}>
              <Pencil className="mr-2 h-4 w-4" />
              Rename
            </DropdownMenuItem>
          )}
          {!isFolder && onRemoveFromFolder && (
            <DropdownMenuItem onClick={onRemoveFromFolder}>
              <FolderOutput className="mr-2 h-4 w-4" />
              Remove from Folder
            </DropdownMenuItem>
          )}
          {(isFolder || onRemoveFromFolder) && onDelete && <DropdownMenuSeparator />}
          {isFolder && onDelete && (
            <DropdownMenuItem
              onClick={onDelete}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
