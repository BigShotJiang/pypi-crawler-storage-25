'use client'

import { useCallback } from 'react'
import { ChevronRight, ChevronDown, Folder, FolderOpen, GitBranch } from 'lucide-react'
import type { MachineBrowseTreeNode } from '@/lib/types/machine-browse'
import { useMachineBrowseStore } from '@/stores/machine-browse'
import { NodeContextMenu } from './NodeContextMenu'
import { InlineRenameInput } from './InlineRenameInput'

export interface MachineFileTreeNodeProps {
  node: MachineBrowseTreeNode
  depth: number
  selectedMachineName: string | null
  onMachineNameSelect: (name: string) => void
}

/**
 * Renders a folder or machine item in the browse tree. Supports expand/collapse,
 * inline rename, and right-click context menu. Mirrors pycharter FileTreeNode.
 */
export function MachineFileTreeNode({
  node,
  depth,
  selectedMachineName,
  onMachineNameSelect,
}: MachineFileTreeNodeProps) {
  const expandedIds = useMachineBrowseStore((s) => s.expandedIds)
  const renamingNodeId = useMachineBrowseStore((s) => s.renamingNodeId)
  const toggleExpand = useMachineBrowseStore((s) => s.toggleExpand)
  const startRename = useMachineBrowseStore((s) => s.startRename)
  const cancelRename = useMachineBrowseStore((s) => s.cancelRename)
  const renameFolder = useMachineBrowseStore((s) => s.renameFolder)
  const deleteFolder = useMachineBrowseStore((s) => s.deleteFolder)
  const createFolder = useMachineBrowseStore((s) => s.createFolder)
  const removeMachineFromFolder = useMachineBrowseStore((s) => s.removeMachineFromFolder)

  const isFolder = node.kind === 'folder'
  const isExpanded = expandedIds.has(node.id)
  const isRenaming = renamingNodeId === node.id
  const machineName = node.item_label ?? node.name
  const isSelected = !isFolder && selectedMachineName === machineName

  const handleClick = useCallback(() => {
    if (isFolder) {
      toggleExpand(node.id)
    } else {
      onMachineNameSelect(machineName)
    }
  }, [isFolder, node.id, machineName, toggleExpand, onMachineNameSelect])

  const handleRenameCommit = useCallback(
    (name: string) => {
      renameFolder(node.id, name)
    },
    [node.id, renameFolder]
  )

  const handleNewSubfolder = useCallback(() => {
    createFolder('New Folder', node.id)
  }, [node.id, createFolder])

  const handleDelete = useCallback(() => {
    deleteFolder(node.id)
  }, [node.id, deleteFolder])

  const handleRemoveFromFolder = useCallback(() => {
    if (machineName) removeMachineFromFolder(machineName)
  }, [machineName, removeMachineFromFolder])

  const chevron = isFolder ? (
    isExpanded ? (
      <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    ) : (
      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    )
  ) : (
    <span className="w-3.5 shrink-0" />
  )

  const icon = isFolder ? (
    isExpanded ? (
      <FolderOpen className="h-3.5 w-3.5 shrink-0 text-amber-500" />
    ) : (
      <Folder className="h-3.5 w-3.5 shrink-0 text-amber-500" />
    )
  ) : (
    <GitBranch className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
  )

  return (
    <div>
      <NodeContextMenu
        node={node}
        onNewSubfolder={isFolder ? handleNewSubfolder : undefined}
        onRename={isFolder ? () => startRename(node.id) : undefined}
        onDelete={isFolder ? handleDelete : undefined}
        onRemoveFromFolder={!isFolder && machineName ? handleRemoveFromFolder : undefined}
      >
        <button
          type="button"
          onClick={handleClick}
          className={`flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-left text-xs transition-colors hover:bg-muted ${
            isSelected ? 'bg-primary/10 text-primary' : 'text-foreground'
          }`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
        >
          {chevron}
          {icon}
          {isRenaming ? (
            <InlineRenameInput
              initialValue={node.name}
              onCommit={handleRenameCommit}
              onCancel={cancelRename}
            />
          ) : (
            <span className="truncate">{node.name}</span>
          )}
        </button>
      </NodeContextMenu>

      {isFolder && isExpanded &&
        node.children?.map((child) => (
          <MachineFileTreeNode
            key={child.id}
            node={child}
            depth={depth + 1}
            selectedMachineName={selectedMachineName}
            onMachineNameSelect={onMachineNameSelect}
          />
        ))}
    </div>
  )
}
