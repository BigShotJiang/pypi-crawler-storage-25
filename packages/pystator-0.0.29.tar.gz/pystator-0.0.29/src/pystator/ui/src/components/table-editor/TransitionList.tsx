'use client'

import { useMemo } from 'react'
import DataTable, { type Column } from './DataTable'
import type { FSMTransition, FSMGuard, FSMAction } from '@/lib/types/fsm'

function sourceToString(source: string | string[]): string {
  return Array.isArray(source) ? source.join(', ') : source
}

function guardsToString(guards: FSMGuard | FSMGuard[] | undefined): string {
  if (!guards) return ''
  const arr = Array.isArray(guards) ? guards : [guards]
  return arr
    .map((g) => (typeof g === 'string' ? g : g.expr ? `expr:${g.expr}` : String(g)))
    .join(', ')
}

function actionsToString(actions: FSMAction | FSMAction[] | undefined): string {
  if (!actions) return ''
  const arr = Array.isArray(actions) ? actions : [actions]
  return arr.map((a) => (typeof a === 'string' ? a : a.name)).join(', ')
}

function parseGuards(input: string): FSMGuard[] | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  return trimmed
    .split(',')
    .map((s) => {
      const t = s.trim()
      if (t.startsWith('expr:')) return { expr: t.slice(5).trim() }
      return t
    })
    .filter(Boolean) as FSMGuard[]
}

function parseActions(input: string): string[] | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  return trimmed.split(',').map((s) => s.trim()).filter(Boolean)
}

function delayToString(after: number | string | undefined): string {
  if (after === undefined || after === null) return ''
  return String(after)
}

function parseDelay(input: string): number | string | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  if (/^[0-9]+[smh]$/.test(trimmed)) return trimmed
  const num = parseInt(trimmed, 10)
  return isNaN(num) ? trimmed : num
}

interface TransitionListProps {
  transitions: FSMTransition[]
  stateNames: string[]
  onChange: (transitions: FSMTransition[]) => void
}

export default function TransitionList({
  transitions,
  stateNames,
  onChange,
}: TransitionListProps) {
  const destOptions = useMemo(
    () => stateNames.map((n) => ({ value: n, label: n })),
    [stateNames],
  )

  const columns: Column<FSMTransition>[] = useMemo(
    () => [
      {
        key: 'trigger',
        header: 'Trigger',
        width: '130px',
        accessor: (r) => r.trigger ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, trigger: String(v) || undefined }),
      },
      {
        key: 'source',
        header: 'Source',
        width: '130px',
        accessor: (r) => sourceToString(r.source),
        editor: 'multiselect',
        editorOptions: { options: destOptions },
        onChange: (r, v) => {
          const parts = String(v).split(',').map((s) => s.trim()).filter(Boolean)
          return { ...r, source: parts.length === 1 ? parts[0] : parts }
        },
      },
      {
        key: 'dest',
        header: 'Dest',
        width: '130px',
        accessor: (r) => r.dest,
        editor: 'select',
        editorOptions: { options: destOptions },
        onChange: (r, v) => ({ ...r, dest: String(v) }),
      },
      {
        key: 'guards',
        header: 'Guards',
        accessor: (r) => guardsToString(r.guards),
        editor: 'text',
        onChange: (r, v) => ({ ...r, guards: parseGuards(String(v)) }),
      },
      {
        key: 'actions',
        header: 'Actions',
        accessor: (r) => actionsToString(r.actions),
        editor: 'text',
        onChange: (r, v) => ({ ...r, actions: parseActions(String(v)) }),
      },
      {
        key: 'after',
        header: 'Delay',
        width: '80px',
        accessor: (r) => delayToString(r.after),
        editor: 'text',
        onChange: (r, v) => ({ ...r, after: parseDelay(String(v)) }),
      },
      {
        key: 'region',
        header: 'Region',
        width: '100px',
        accessor: (r) => r.region ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, region: String(v) || undefined }),
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
    ],
    [destOptions],
  )

  return (
    <DataTable<FSMTransition>
      columns={columns}
      rows={transitions}
      onRowsChange={onChange}
      rowKey={(r) =>
        `${r.trigger ?? ''}-${sourceToString(r.source)}-${r.dest}-${transitions.indexOf(r)}`
      }
      onAddRow={() => ({
        trigger: '',
        source: stateNames[0] ?? '',
        dest: stateNames[0] ?? '',
      })}
      emptyMessage="No transitions defined."
      addLabel="Add transition"
    />
  )
}
