'use client'

import type { NodeProps } from '@xyflow/react'
import type { Node } from '@xyflow/react'
import { Handle, Position, useStore } from '@xyflow/react'
import type { NodeData } from '@/lib/fsmToReactFlow'
import { STATE_COLORS, CURRENT_STATE_HIGHLIGHT } from '@/lib/diagramColors'
import { EDGE_LABEL_COLORS } from '@/lib/diagramColors'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'

/**
 * Custom state node that shows the state label and, when the state belongs to a
 * region (parallel state track), a small region badge inside the box for easier identification.
 * When isCurrentState is true (entity detail view), shows a ring to indicate "you are here".
 *
 * Handles become larger and show a crosshair cursor when the diagram is in connectable mode,
 * making it easier to initiate connections by dragging. Terminal states suppress the source
 * handle because you cannot create transitions FROM a terminal state.
 */
export function StateNode({ data, id }: NodeProps<Node<NodeData>>) {
  const d = data as NodeData
  const label = d.label ?? ''
  const regionName = d.regionName
  const stateType = (d.stateType ?? 'stable') as keyof typeof STATE_COLORS
  const colors = STATE_COLORS[stateType] ?? STATE_COLORS.stable
  const isCurrentState = d.isCurrentState === true
  const isTerminal = stateType === 'terminal'
  const contextKeys = (d.contextKeys ?? []) as string[]
  const hasContextKeys = contextKeys.length > 0
  const { focusedEdgeSourceId, focusedEdgeTargetId } = useFsmDiagramFocus()
  const isFocusedSourceNode = focusedEdgeSourceId === id
  const isFocusedTargetNode = focusedEdgeTargetId === id
  const tooltipTitle = hasContextKeys
    ? `State variables: ${contextKeys.join(', ')}`
    : undefined

  // Check if the diagram allows connections (editable mode)
  const isConnectable = useStore((s) => {
    const node = s.nodeLookup.get(id)
    return node?.internals?.handleBounds != null && s.nodesConnectable
  })

  const handleClass = isConnectable
    ? '!w-3 !h-3 !border-2 cursor-crosshair'
    : '!w-2 !h-2 !border-2'

  return (
    <div
      className="rounded-md flex flex-col items-center justify-center min-w-[180px] min-h-[44px] px-3 py-2 text-center"
      title={tooltipTitle}
      style={{
        background: colors.background,
        border: `2px solid ${colors.border}`,
        color: colors.text,
        ...(isCurrentState
          ? {
              boxShadow: CURRENT_STATE_HIGHLIGHT.shadow,
              outline: `${CURRENT_STATE_HIGHLIGHT.ringWidth}px solid ${CURRENT_STATE_HIGHLIGHT.ring}`,
              outlineOffset: 2,
            }
          : isFocusedSourceNode
            ? {
                boxShadow: '0 0 0 2px rgba(59,130,246,0.25)',
                outline: '2px solid rgba(37,99,235,0.9)',
                outlineOffset: 2,
              }
            : isFocusedTargetNode
              ? {
                  boxShadow: '0 0 0 2px rgba(14,165,233,0.18)',
                  outline: '2px solid rgba(14,165,233,0.65)',
                  outlineOffset: 2,
                }
              : {}),
      }}
    >
      <Handle type="target" position={Position.Top} className={handleClass} />
      <div className="flex flex-col items-center gap-1 w-full">
        <span className="font-medium text-sm truncate w-full">{label}</span>
        <div className="flex flex-wrap items-center justify-center gap-1">
          {regionName != null && regionName !== '' && (
            <span
              className="text-xs font-medium px-1.5 py-0.5 rounded"
              style={{
                background: EDGE_LABEL_COLORS.region.bg,
                color: EDGE_LABEL_COLORS.region.text,
                border: `1px solid ${EDGE_LABEL_COLORS.region.border}`,
              }}
            >
              @ {regionName}
            </span>
          )}
          {hasContextKeys && (
            <span
              className="text-[10px] px-1 py-0.5 rounded bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300"
              title={tooltipTitle}
            >
              {contextKeys.length} var{contextKeys.length !== 1 ? 's' : ''}
            </span>
          )}
        </div>
      </div>
      {!isTerminal && (
        <Handle type="source" position={Position.Bottom} className={handleClass} />
      )}
    </div>
  )
}
