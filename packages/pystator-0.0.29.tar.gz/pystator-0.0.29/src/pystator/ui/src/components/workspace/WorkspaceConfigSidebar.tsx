'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp, Plus, Settings2, GitBranch, ArrowRightLeft, AlertCircle, FileCode2, LayoutList, Play, Variable, FolderOpen, Blocks } from 'lucide-react'
import {
  useWorkspaceStore,
  selectConfig,
  selectSetConfig,
  selectValidationResult,
  selectSetValidationResult,
  selectDiagramShowGuards,
  selectSetDiagramShowGuards,
  selectDiagramShowActions,
  selectSetDiagramShowActions,
  selectDiagramHighlightState,
  selectSetDiagramHighlightState,
  selectDiagramHighlightTransition,
  selectSetDiagramHighlightTransition,
} from '@/stores/workspace'
import { cn } from '@/lib/utils'
import TestSidebarContent from './TestSidebarContent'
import ConfigRawSidebarContent from './ConfigRawSidebarContent'
import { validateConfig, ApiError } from '@/lib/api'
import type { FSMConfig, FSMState, FSMTransition } from '@/lib/types/fsm'
import { parseSource } from './ConfigHelpers'
import { StateModal, TransitionModal, ErrorPolicyModal, StateVariableModal } from '@/components/modals'
import { Switch } from '@/components/ui/switch'
import {
  ConfigMetaSection,
  ConfigStatesSection,
  ConfigTransitionsSection,
  ConfigErrorPolicySection,
  ConfigStateVariablesSection,
} from './sections'
import { MachineBrowseContent } from './MachineBrowseContent'
import type { MachineListItem } from '@/lib/api'
import type { SidebarDisplayMode } from '@/components/layout'
import PalettePanel from './PalettePanel'
import type { StatePaletteBlockId, TemplatePaletteId, TransitionPaletteBlockId } from './paletteDefs'

const SECTION_IDS = ['meta', 'state_variables', 'states', 'transitions', 'error_policy'] as const

export interface WorkspaceConfigSidebarProps {
  /** When true, sidebar shows icon-only (e.g. when the resizable panel is collapsed). Controlled by parent when using with resizable layout. */
  isPanelCollapsed?: boolean
  /** From ResizableWorkspaceLayout: narrow panel shows icon-only tab labels when `compact`. */
  sidebarDisplayMode?: SidebarDisplayMode
  /** When provided, collapse button will shrink the resizable panel so the diagram expands. */
  onCollapseRequested?: () => void
  /** When provided, expand button will restore the resizable panel size. */
  onExpandRequested?: () => void
  /** For Browse tab: full machine list (from listMachines). */
  machineList?: MachineListItem[]
  machinesLoading?: boolean
  machineLoadError?: string | null
  /** Unique machine names for Browse list. */
  uniqueNames?: string[]
  selectedMachineName?: string | null
  onMachineNameSelect?: (name: string) => void
  onCreateMachineFromScratch?: () => void
  onSelectStateBlock?: (id: StatePaletteBlockId) => void
  onSelectTransitionBlock?: (id: TransitionPaletteBlockId) => void
  onApplyTemplate?: (id: TemplatePaletteId) => void
}

export default function WorkspaceConfigSidebar({
  isPanelCollapsed: isPanelCollapsedProp,
  sidebarDisplayMode: sidebarDisplayModeProp,
  onCollapseRequested,
  onExpandRequested,
  machineList,
  machinesLoading = false,
  machineLoadError = null,
  uniqueNames = [],
  selectedMachineName = null,
  onMachineNameSelect,
  onCreateMachineFromScratch,
  onSelectStateBlock,
  onSelectTransitionBlock,
  onApplyTemplate,
}: WorkspaceConfigSidebarProps = {}) {
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const validationResult = useWorkspaceStore(selectValidationResult)
  const setValidationResult = useWorkspaceStore(selectSetValidationResult)
  const diagramShowGuards = useWorkspaceStore(selectDiagramShowGuards)
  const setDiagramShowGuards = useWorkspaceStore(selectSetDiagramShowGuards)
  const diagramShowActions = useWorkspaceStore(selectDiagramShowActions)
  const setDiagramShowActions = useWorkspaceStore(selectSetDiagramShowActions)
  const diagramHighlightState = useWorkspaceStore(selectDiagramHighlightState)
  const setDiagramHighlightState = useWorkspaceStore(selectSetDiagramHighlightState)
  const diagramHighlightTransition = useWorkspaceStore(selectDiagramHighlightTransition)
  const setDiagramHighlightTransition = useWorkspaceStore(selectSetDiagramHighlightTransition)

  const [isCollapsedInternal, setIsCollapsedInternal] = useState(false)
  const isCollapsed = isPanelCollapsedProp !== undefined ? isPanelCollapsedProp : isCollapsedInternal
  const isCompact = sidebarDisplayModeProp === 'compact'
  const [sidebarMode, setSidebarMode] = useState<'form' | 'config' | 'test' | 'browse' | 'components'>('form')
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(SECTION_IDS))
  const [error, setError] = useState<Error | ApiError | null>(null)
  const [validating, setValidating] = useState(false)
  const [stateModalOpen, setStateModalOpen] = useState(false)
  const [stateModalIndex, setStateModalIndex] = useState<number | null>(null)
  const [transitionModalOpen, setTransitionModalOpen] = useState(false)
  const [transitionModalIndex, setTransitionModalIndex] = useState<number | null>(null)
  const [errorPolicyModalOpen, setErrorPolicyModalOpen] = useState(false)
  const [stateVariableModalOpen, setStateVariableModalOpen] = useState(false)
  const [stateVariableModalIndex, setStateVariableModalIndex] = useState<number | null>(null)
  const validateTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const states = config.states ?? []
  const transitions = config.transitions ?? []
  const stateNames = states.map((s) => s.name)
  const regionNames = states
    .filter((s) => s.type === 'parallel' && s.regions)
    .flatMap((s) => s.regions?.map((r) => r.name) ?? [])

  const updateConfig = useCallback(
    (updater: (c: FSMConfig) => FSMConfig) => {
      setConfig((prev) => updater({ ...prev }))
      setValidationResult(null)
    },
    [setConfig, setValidationResult]
  )

  const setMeta = useCallback(
    (field: 'machine_name' | 'version', value: string) => {
      updateConfig((c) => ({ ...c, meta: { ...c.meta, [field]: value } }))
    },
    [updateConfig]
  )

  const runValidate = useCallback(async () => {
    setError(null)
    setValidating(true)
    try {
      const res = await validateConfig(config)
      setValidationResult({ valid: res.valid, errors: res.errors ?? [] })
    } catch (e) {
      setError(e instanceof ApiError ? e : new Error(String(e)))
    } finally {
      setValidating(false)
    }
  }, [config, setValidationResult])

  useEffect(() => {
    if (validateTimeoutRef.current) clearTimeout(validateTimeoutRef.current)
    validateTimeoutRef.current = setTimeout(runValidate, 800)
    return () => {
      if (validateTimeoutRef.current) clearTimeout(validateTimeoutRef.current)
    }
  }, [config, runValidate])

  const addState = useCallback(
    (state: FSMState) => {
      updateConfig((c) => ({ ...c, states: [...(c.states ?? []), state] }))
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const updateState = useCallback(
    (index: number, state: FSMState) => {
      updateConfig((c) => {
        const st = [...(c.states ?? [])]
        st[index] = state
        return { ...c, states: st }
      })
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const removeState = useCallback(
    (index: number) => {
      updateConfig((c) => ({
        ...c,
        states: (c.states ?? []).filter((_, i) => i !== index),
        transitions: (c.transitions ?? []).filter((t) => {
          const src = parseSource(t.source)
          const dest = t.dest
          const name = (c.states ?? [])[index]?.name
          return name && !src.includes(name) && dest !== name
        }),
      }))
      setStateModalOpen(false)
      setStateModalIndex(null)
    },
    [updateConfig]
  )

  const addTransition = useCallback(
    (t: FSMTransition) => {
      const source = parseSource(t.source)
      const normalized: FSMTransition = { ...t, source: source.length === 1 ? source[0] : source }
      updateConfig((c) => ({ ...c, transitions: [...(c.transitions ?? []), normalized] }))
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const updateTransition = useCallback(
    (index: number, t: FSMTransition) => {
      const source = parseSource(t.source)
      const normalized: FSMTransition = { ...t, source: source.length === 1 ? source[0] : source }
      updateConfig((c) => {
        const tr = [...(c.transitions ?? [])]
        tr[index] = normalized
        return { ...c, transitions: tr }
      })
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const removeTransition = useCallback(
    (index: number) => {
      updateConfig((c) => ({ ...c, transitions: (c.transitions ?? []).filter((_, i) => i !== index) }))
      setTransitionModalOpen(false)
      setTransitionModalIndex(null)
    },
    [updateConfig]
  )

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev)
      if (next.has(sectionId)) next.delete(sectionId)
      else next.add(sectionId)
      return next
    })
  }

  const stateModalState: FSMState =
    stateModalIndex !== null && states[stateModalIndex] ? states[stateModalIndex] : { name: '', type: 'stable' }
  const transitionModalTransition: FSMTransition =
    transitionModalIndex !== null && transitions[transitionModalIndex]
      ? transitions[transitionModalIndex]
      : { trigger: '', source: '', dest: stateNames[0] ?? '' }

  const sections: { id: string; title: string; icon: typeof Settings2 }[] = [
    { id: 'meta', title: 'Meta', icon: Settings2 },
    { id: 'state_variables', title: 'State variables', icon: Variable },
    { id: 'states', title: 'States', icon: GitBranch },
    { id: 'transitions', title: 'Transitions', icon: ArrowRightLeft },
    { id: 'error_policy', title: 'Error policy', icon: AlertCircle },
  ]

  const stateVariables = config.state_variables ?? []

  const addStateVariable = useCallback(() => {
    setStateVariableModalIndex(null)
    setStateVariableModalOpen(true)
  }, [])

  const updateStateVariable = useCallback(
    (index: number, variable: import('@/lib/types/fsm').FSMStateVariable) => {
      updateConfig((c) => {
        const list = [...(c.state_variables ?? [])]
        list[index] = variable
        return { ...c, state_variables: list }
      })
    },
    [updateConfig]
  )

  const removeStateVariable = useCallback(
    (index: number) => {
      updateConfig((c) => {
        const list = (c.state_variables ?? []).filter((_, i) => i !== index)
        return { ...c, state_variables: list }
      })
    },
    [updateConfig]
  )

  return (
    <>
      <div
        className="flex flex-col bg-background border-r border-border/50 shadow-sm transition-all duration-300 w-full min-w-0"
        style={{ height: '100%', overflow: 'hidden' }}
      >
        <div
          className={cn(
            'flex items-center gap-2 px-4 py-3 border-b border-border/50 bg-muted/30',
            isCollapsed ? 'justify-center' : 'justify-between'
          )}
        >
          {!isCollapsed && (
            <div className="flex rounded-lg border border-border/70 bg-background/50 p-0.5" role="tablist" aria-label="Sidebar mode">
              <button
                type="button"
                role="tab"
                aria-label="Browse"
                title="Browse"
                aria-selected={sidebarMode === 'browse'}
                onClick={() => setSidebarMode('browse')}
                className={cn(
                  'inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium',
                  isCompact ? 'justify-center px-2 w-7' : 'h-8 gap-1.5 px-2.5',
                  sidebarMode === 'browse' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <FolderOpen className="h-3.5 w-3.5" />
                {!isCompact && <span>Browse</span>}
              </button>
              <button
                type="button"
                role="tab"
                aria-label="Form"
                title="Form"
                aria-selected={sidebarMode === 'form'}
                onClick={() => setSidebarMode('form')}
                className={cn(
                  'inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium',
                  isCompact ? 'justify-center px-2 w-7' : 'h-8 gap-1.5 px-2.5',
                  sidebarMode === 'form' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <LayoutList className="h-3.5 w-3.5" />
                {!isCompact && <span>Form</span>}
              </button>
              <button
                type="button"
                role="tab"
                aria-label="Config"
                title="Config"
                aria-selected={sidebarMode === 'config'}
                onClick={() => setSidebarMode('config')}
                className={cn(
                  'inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium',
                  isCompact ? 'justify-center px-2 w-7' : 'h-8 gap-1.5 px-2.5',
                  sidebarMode === 'config' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <FileCode2 className="h-3.5 w-3.5" />
                {!isCompact && <span>Config</span>}
              </button>
              <button
                type="button"
                role="tab"
                aria-label="Test"
                title="Test"
                aria-selected={sidebarMode === 'test'}
                onClick={() => setSidebarMode('test')}
                className={cn(
                  'inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium',
                  isCompact ? 'justify-center px-2 w-7' : 'h-8 gap-1.5 px-2.5',
                  sidebarMode === 'test' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Play className="h-3.5 w-3.5" />
                {!isCompact && <span>Test</span>}
              </button>
              <button
                type="button"
                role="tab"
                aria-label="Components"
                title="Components"
                aria-selected={sidebarMode === 'components'}
                onClick={() => setSidebarMode('components')}
                className={cn(
                  'inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium',
                  isCompact ? 'justify-center px-2 w-7' : 'h-8 gap-1.5 px-2.5',
                  sidebarMode === 'components' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Blocks className="h-3.5 w-3.5" />
                {!isCompact && <span>Components</span>}
              </button>
            </div>
          )}
          <button
            onClick={() => {
              if (isCollapsed) {
                onExpandRequested?.()
                if (isPanelCollapsedProp === undefined) setIsCollapsedInternal(false)
              } else {
                onCollapseRequested?.()
                if (isPanelCollapsedProp === undefined) setIsCollapsedInternal(true)
              }
            }}
            className="p-1.5 rounded-md hover:bg-muted transition-all duration-200 hover:scale-105 active:scale-95 shrink-0"
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronLeft className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overflow-x-hidden px-2 py-3" style={{ maxHeight: '100%' }}>
          {!isCollapsed && sidebarMode === 'browse' ? (
            <MachineBrowseContent
              uniqueNames={uniqueNames}
              selectedMachineName={selectedMachineName ?? null}
              onMachineNameSelect={onMachineNameSelect ?? (() => {})}
              onCreateMachineFromScratch={onCreateMachineFromScratch}
              loading={machinesLoading}
              error={machineLoadError}
            />
          ) : !isCollapsed && sidebarMode === 'test' ? (
            <TestSidebarContent />
          ) : !isCollapsed && sidebarMode === 'config' ? (
            <ConfigRawSidebarContent isActive={sidebarMode === 'config'} />
          ) : !isCollapsed && sidebarMode === 'components' ? (
            <PalettePanel
              className="w-full border-none bg-transparent p-1 shadow-none"
              onSelectStateBlock={onSelectStateBlock ?? (() => {})}
              onSelectTransitionBlock={onSelectTransitionBlock ?? (() => {})}
              onApplyTemplate={onApplyTemplate ?? (() => {})}
            />
          ) : (
          <>
          <div className="space-y-1">
            {sections.map((section) => {
              const isExpanded = expandedSections.has(section.id)
              const showAddButton =
                !isCollapsed &&
                (section.id === 'state_variables' ||
                  section.id === 'states' ||
                  section.id === 'transitions' ||
                  section.id === 'error_policy')
              const addDisabled = section.id === 'transitions' && stateNames.length === 0
              const handleAdd = (e: React.MouseEvent) => {
                e.stopPropagation()
                if (section.id === 'state_variables') {
                  addStateVariable()
                } else if (section.id === 'states') {
                  setStateModalIndex(null)
                  setStateModalOpen(true)
                } else if (section.id === 'transitions') {
                  setTransitionModalIndex(null)
                  setTransitionModalOpen(true)
                } else if (section.id === 'error_policy') {
                  setErrorPolicyModalOpen(true)
                }
              }
              return (
                <div key={section.id} className="mb-1">
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => toggleSection(section.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        toggleSection(section.id)
                      }
                    }}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 hover:bg-muted/50 cursor-pointer"
                    title={isCollapsed ? section.title : undefined}
                  >
                    {isCollapsed ? (
                      <section.icon className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <>
                        <div className="flex items-center gap-2.5">
                          <section.icon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">{section.title}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          {showAddButton && (
                            <button
                              type="button"
                              onClick={handleAdd}
                              disabled={addDisabled}
                              className="p-1 rounded hover:bg-muted transition-colors disabled:opacity-50 disabled:pointer-events-none"
                              aria-label={
                                section.id === 'state_variables'
                                  ? 'Add variable'
                                  : section.id === 'states'
                                    ? 'Add state'
                                    : section.id === 'transitions'
                                      ? 'Add transition'
                                      : 'Add error policy'
                              }
                              title={
                                section.id === 'state_variables'
                                  ? 'Add variable'
                                  : section.id === 'states'
                                    ? 'Add state'
                                    : section.id === 'transitions'
                                      ? 'Add transition'
                                      : 'Add error policy'
                              }
                            >
                              <Plus className="h-4 w-4 text-muted-foreground" />
                            </button>
                          )}
                          {isExpanded ? (
                            <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                          )}
                        </div>
                      </>
                    )}
                  </div>
                  {!isCollapsed && isExpanded && (
                    <div className="ml-1 mt-1 pl-2 border-l-2 border-muted">
                      {section.id === 'meta' && (
                        <ConfigMetaSection
                          config={config}
                          validationResult={validationResult}
                          error={error}
                          validating={validating}
                          setMeta={setMeta}
                          updateConfig={updateConfig}
                          runValidate={runValidate}
                        />
                      )}
                      {section.id === 'state_variables' && (
                        <ConfigStateVariablesSection
                          stateVariables={stateVariables}
                          onAddVariable={addStateVariable}
                          onEditVariable={(i) => {
                            setStateVariableModalIndex(i)
                            setStateVariableModalOpen(true)
                          }}
                          onRemove={removeStateVariable}
                        />
                      )}
                      {section.id === 'states' && (
                        <ConfigStatesSection
                          states={states}
                          onAddState={() => {
                            setStateModalIndex(null)
                            setStateModalOpen(true)
                          }}
                          onEditState={(i) => {
                            setStateModalIndex(i)
                            setStateModalOpen(true)
                          }}
                          onRemoveState={removeState}
                          onStateClick={(name) => {
                            setDiagramHighlightState(diagramHighlightState === name ? null : name)
                            setDiagramHighlightTransition(null)
                          }}
                          highlightedStateName={diagramHighlightState}
                        />
                      )}
                      {section.id === 'transitions' && (
                        <ConfigTransitionsSection
                          transitions={transitions}
                          stateNames={stateNames}
                          onAddTransition={() => {
                            setTransitionModalIndex(null)
                            setTransitionModalOpen(true)
                          }}
                          onEditTransition={(i) => {
                            setTransitionModalIndex(i)
                            setTransitionModalOpen(true)
                          }}
                          onRemoveTransition={removeTransition}
                          onTransitionClick={(t) => {
                            const already =
                              diagramHighlightTransition &&
                              diagramHighlightTransition.source === t.source &&
                              diagramHighlightTransition.target === t.target &&
                              diagramHighlightTransition.trigger === t.trigger
                            setDiagramHighlightTransition(already ? null : t)
                            setDiagramHighlightState(null)
                          }}
                          highlightedTransition={diagramHighlightTransition}
                        />
                      )}
                      {section.id === 'error_policy' && (
                        <ConfigErrorPolicySection
                          config={config}
                          onOpenModal={() => setErrorPolicyModalOpen(true)}
                          onRemove={() =>
                            updateConfig((c) => {
                              const { error_policy: _, ...rest } = c
                              return rest
                            })
                          }
                        />
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
          {!isCollapsed && (
            <div className="mt-4 pt-3 border-t border-border/50 space-y-2">
              <span className="text-xs font-medium text-muted-foreground px-2 block">Diagram</span>
              <label className="flex items-center gap-2 px-3 py-1.5 rounded-md hover:bg-muted/50 cursor-pointer text-sm">
                <Switch checked={diagramShowGuards} onCheckedChange={setDiagramShowGuards} />
                <span>Show guards</span>
              </label>
              <label className="flex items-center gap-2 px-3 py-1.5 rounded-md hover:bg-muted/50 cursor-pointer text-sm">
                <Switch checked={diagramShowActions} onCheckedChange={setDiagramShowActions} />
                <span>Show actions</span>
              </label>
            </div>
          )}
          </>
          )}
        </div>
      </div>

      <StateModal
        open={stateModalOpen}
        onOpenChange={setStateModalOpen}
        state={stateModalState}
        existingStateNames={stateNames}
        onSave={(next) => (stateModalIndex !== null ? updateState(stateModalIndex, next) : addState(next))}
        title={stateModalIndex !== null ? 'Edit state' : 'Add state'}
        description={
          stateModalIndex !== null
            ? 'Update state name, type, hierarchy, and optional hooks.'
            : 'Add a new state. Name and type are required.'
        }
        machineStateVariableKeys={stateVariables.map((sv) => sv.key)}
      />
      <TransitionModal
        open={transitionModalOpen}
        onOpenChange={setTransitionModalOpen}
        transition={transitionModalTransition}
        stateNames={stateNames}
        regionNames={regionNames}
        onSave={(next) =>
          transitionModalIndex !== null ? updateTransition(transitionModalIndex, next) : addTransition(next)
        }
        title={transitionModalIndex !== null ? 'Edit transition' : 'Add transition'}
        description={
          transitionModalIndex !== null
            ? 'Update trigger, source, destination, guards, actions, delay, and region.'
            : 'Add a new transition. Trigger, source and destination are required.'
        }
      />
      <ErrorPolicyModal
        open={errorPolicyModalOpen}
        onOpenChange={setErrorPolicyModalOpen}
        value={config.error_policy ?? null}
        onSave={(value) =>
          updateConfig((c) => {
            if (value === null) {
              const { error_policy: _, ...rest } = c
              return rest
            }
            return { ...c, error_policy: value }
          })
        }
        title="Error policy"
        description="Optional fallback state and retry attempts on error."
        allowRemove={!!config.error_policy}
      />
      <StateVariableModal
        open={stateVariableModalOpen}
        onOpenChange={setStateVariableModalOpen}
        variable={stateVariableModalIndex !== null ? stateVariables[stateVariableModalIndex] ?? { key: '' } : { key: '' }}
        existingKeys={
          stateVariableModalIndex !== null
            ? stateVariables.map((sv) => sv.key).filter((_, i) => i !== stateVariableModalIndex)
            : stateVariables.map((sv) => sv.key)
        }
        onSave={(next) => {
          if (stateVariableModalIndex !== null) {
            updateStateVariable(stateVariableModalIndex, next)
          } else {
            updateConfig((c) => ({
              ...c,
              state_variables: [...(c.state_variables ?? []), next],
            }))
          }
          setStateVariableModalOpen(false)
          setStateVariableModalIndex(null)
        }}
        title={stateVariableModalIndex !== null ? 'Edit state variable' : 'Add state variable'}
        description={
          stateVariableModalIndex !== null
            ? 'Update context key, type, and optional description or default.'
            : 'Define a context key for guards and actions. Optional validation when meta.validate_context is true.'
        }
      />
    </>
  )
}
