'use client'

import { useState, type CSSProperties } from 'react'
import type { EdgeProps } from '@xyflow/react'
import { getSmoothStepPath, EdgeLabelRenderer, BaseEdge } from '@xyflow/react'
import type { EdgeLabelData } from '@/lib/fsmToReactFlow'
import { parallelEdgeLabelDelta } from '@/lib/edgeLabelFan'
import { computeEdgeLabelZIndex } from '@/lib/edgeLabelStacking'
import { EDGE_LABEL_COLORS, EDGE_LABEL_COLORS_DEFAULT } from '@/lib/diagramColors'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'

/** Offset and radius for self-loop path (loop bulges to the right of the node) */
const SELF_LOOP_OFFSET = 56
const SELF_LOOP_RADIUS = 42

/**
 * Build SVG path and label position for a self-loop (source === target).
 * Loop bulges to the right so it does not cover the state node; label is placed beside the loop.
 */
function getSelfLoopPath(sourceX: number, sourceY: number): [path: string, labelX: number, labelY: number] {
  const cx = sourceX + SELF_LOOP_OFFSET
  const path = `M ${sourceX} ${sourceY} C ${cx} ${sourceY - SELF_LOOP_RADIUS} ${cx} ${sourceY + SELF_LOOP_RADIUS} ${sourceX} ${sourceY}`
  const labelX = sourceX + SELF_LOOP_OFFSET
  const labelY = sourceY
  return [path, labelX, labelY]
}

/** Single box per transition: one container with all metadata inside */
const transitionBoxBase: CSSProperties = {
  padding: '6px 10px',
  borderRadius: 6,
  fontSize: 11,
  fontWeight: 500,
  background: '#ffffff',
  color: '#334155',
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: '#cbd5e1',
  boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
  maxWidth: 220,
  minWidth: 80,
  textAlign: 'center',
  transition: 'box-shadow 0.15s ease, border-color 0.15s ease',
}

function boxStyle(hovered: boolean): CSSProperties {
  if (!hovered) return transitionBoxBase
  return {
    ...transitionBoxBase,
    boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
    borderColor: '#94a3b8',
  }
}

const rowStyle = { marginTop: 2, paddingLeft: 0 } as const
const firstRowStyle = { marginTop: 0 } as const
const lineStyle = (color: string) => ({
  color,
  overflow: 'hidden' as const,
  textOverflow: 'ellipsis' as const,
  whiteSpace: 'nowrap' as const,
  textAlign: 'center' as const,
})

export function EdgeWithLabel({
  id,
  source,
  target,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  style,
  markerEnd,
}: EdgeProps) {
  const { focusedEdgeId, focusedNodeId, requestFocusEdgeLabel } = useFsmDiagramFocus()
  const edgeData = (data ?? {}) as EdgeLabelData
  const isSelfLoop = edgeData.isSelfLoop === true

  const [edgePath, labelX, labelY] = isSelfLoop
    ? getSelfLoopPath(sourceX, sourceY)
    : getSmoothStepPath({
        sourceX,
        sourceY,
        targetX,
        targetY,
        sourcePosition,
        targetPosition,
      })

  const [hovered, setHovered] = useState(false)
  const isSynthetic = edgeData.isSynthetic === true
  const showHover = hovered && !isSynthetic
  const hasStructured = edgeData.trigger != null ||
    edgeData.guardsText != null ||
    edgeData.actionsText != null ||
    edgeData.delayText != null ||
    edgeData.regionText != null ||
    edgeData.isTimeout ||
    (edgeData.timeoutLabel != null && edgeData.timeoutLabel !== '')

  const labelContent = hasStructured ? (
    <div style={boxStyle(showHover)}>
      {edgeData.isTimeout ? (
        <div style={lineStyle(EDGE_LABEL_COLORS.timeout.text)}>
          {edgeData.label ?? 'timeout'}
        </div>
      ) : (
        <>
          {edgeData.trigger != null && edgeData.trigger !== '' && (
            <div style={{ ...lineStyle(EDGE_LABEL_COLORS.trigger.text), fontWeight: 600, ...firstRowStyle }}>
              {edgeData.trigger}
            </div>
          )}
          {edgeData.guardsText != null && edgeData.guardsText !== '' && (
            <div style={{ ...rowStyle, ...lineStyle(EDGE_LABEL_COLORS.guards.text) }}>
              [ {edgeData.guardsText} ]
            </div>
          )}
          {edgeData.actionsText != null && edgeData.actionsText !== '' && (
            <div style={{ ...rowStyle, ...lineStyle(EDGE_LABEL_COLORS.actions.text) }}>
              / {edgeData.actionsText}
            </div>
          )}
          {edgeData.delayText != null && edgeData.delayText !== '' && (
            <div style={{ ...rowStyle, ...lineStyle(EDGE_LABEL_COLORS.delay.text) }}>
              ⏱ {edgeData.delayText}
            </div>
          )}
          {edgeData.regionText != null && edgeData.regionText !== '' && (
            <div style={{ ...rowStyle, ...lineStyle(EDGE_LABEL_COLORS.region.text) }}>
              @{edgeData.regionText}
            </div>
          )}
          {edgeData.timeoutLabel != null && edgeData.timeoutLabel !== '' && (
            <>
              <div style={{ ...rowStyle, borderTop: '1px solid #e2e8f0', paddingTop: 4, marginTop: 4 }} />
              <div style={{ ...rowStyle, ...lineStyle(EDGE_LABEL_COLORS.timeout.text) }}>
                {edgeData.timeoutLabel}
              </div>
            </>
          )}
        </>
      )}
    </div>
  ) : edgeData.label ? (
    <div
      style={{
        ...boxStyle(showHover),
        background: edgeData.label === 'initial' ? EDGE_LABEL_COLORS.initial.bg : EDGE_LABEL_COLORS_DEFAULT.bg,
        borderColor: edgeData.label === 'initial' ? EDGE_LABEL_COLORS.initial.border : EDGE_LABEL_COLORS_DEFAULT.border,
        color: edgeData.label === 'initial' ? EDGE_LABEL_COLORS.initial.text : EDGE_LABEL_COLORS_DEFAULT.text,
      }}
    >
      {edgeData.label}
    </div>
  ) : null

  const labelZIndex = computeEdgeLabelZIndex({
    edgeId: id,
    edgeSourceId: source,
    edgeTargetId: target,
    focusedEdgeId,
    focusedNodeId,
    isTimeout: edgeData.isTimeout === true,
  })

  const isFocusedEdge = focusedEdgeId === id
  const isIncidentToFocusedNode =
    focusedNodeId != null && (source === focusedNodeId || target === focusedNodeId)
  const hasFocus = focusedEdgeId != null || focusedNodeId != null
  const shouldDim = hasFocus && !isFocusedEdge && !isIncidentToFocusedNode
  const edgeOpacity = shouldDim ? 0.2 : isFocusedEdge ? 1 : isIncidentToFocusedNode ? 0.92 : 1
  const effectiveStrokeWidth = isFocusedEdge
    ? Math.max(2, Number(style?.strokeWidth ?? 1) + 1)
    : Number(style?.strokeWidth ?? 1)
  const edgeStyle: CSSProperties = {
    ...(style as CSSProperties | undefined),
    opacity: edgeOpacity,
    strokeWidth: effectiveStrokeWidth,
  }
  const labelOpacity = shouldDim ? 0.3 : 1

  const parallelIndex = edgeData.labelParallelIndex ?? 0
  const parallelCount = edgeData.labelParallelCount ?? 1
  const { dx: labelDx, dy: labelDy } = parallelEdgeLabelDelta({
    isSelfLoop,
    sourceX,
    sourceY,
    targetX,
    targetY,
    index: parallelIndex,
    count: parallelCount,
  })
  const showAnchorCue = (isFocusedEdge || showHover) && (Math.abs(labelDx) + Math.abs(labelDy) > 2)
  const cueLength = Math.hypot(labelDx, labelDy)
  const cueAngleDeg = Math.atan2(labelDy, labelDx) * (180 / Math.PI)

  return (
    <>
      <BaseEdge id={id} path={edgePath} style={edgeStyle} markerEnd={markerEnd} />
      {labelContent ? (
        <EdgeLabelRenderer>
          {showAnchorCue ? (
            <div
              style={{
                position: 'absolute',
                transform: `translate(${labelX}px,${labelY}px) rotate(${cueAngleDeg}deg)`,
                width: cueLength,
                height: 1,
                background: '#64748b',
                opacity: shouldDim ? 0.25 : 0.55,
                transformOrigin: '0 50%',
                pointerEvents: 'none',
                zIndex: Math.max(1, labelZIndex - 1),
              }}
            />
          ) : null}
          {(isFocusedEdge || showHover) ? (
            <div
              style={{
                position: 'absolute',
                transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
                width: 6,
                height: 6,
                borderRadius: 9999,
                background: '#475569',
                opacity: shouldDim ? 0.3 : 0.75,
                pointerEvents: 'none',
                zIndex: Math.max(1, labelZIndex - 1),
              }}
            />
          ) : null}
          <div
            style={{
              position: 'absolute',
              transform: `translate(-50%, -50%) translate(${labelX + labelDx}px,${labelY + labelDy}px)`,
              pointerEvents: 'all',
              zIndex: labelZIndex,
              cursor: isSynthetic ? 'default' : 'pointer',
              opacity: labelOpacity,
            }}
            className="nodrag nopan"
            onClick={(e) => {
              e.stopPropagation()
              requestFocusEdgeLabel(id, { sourceId: source, targetId: target })
            }}
            onMouseEnter={() => !isSynthetic && setHovered(true)}
            onMouseLeave={() => setHovered(false)}
          >
            {labelContent}
          </div>
        </EdgeLabelRenderer>
      ) : null}
    </>
  )
}
