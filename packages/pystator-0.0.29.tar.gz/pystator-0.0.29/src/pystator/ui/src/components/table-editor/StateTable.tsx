'use client'

import { useMemo } from 'react'
import DataTable, { type Column } from './DataTable'
import type { FSMState } from '@/lib/types/fsm'

const STATE_TYPES: { value: string; label: string }[] = [
  { value: 'initial', label: 'initial' },
  { value: 'stable', label: 'stable' },
  { value: 'terminal', label: 'terminal' },
  { value: 'error', label: 'error' },
  { value: 'parallel', label: 'parallel' },
]

function actionsToString(actions: FSMState['on_enter']): string {
  if (!actions) return ''
  if (typeof actions === 'string') return actions
  return actions.map((a) => (typeof a === 'string' ? a : a.name)).join(', ')
}

function parseActions(input: string): string[] | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  return trimmed.split(',').map((s) => s.trim()).filter(Boolean)
}

interface StateTableProps {
  states: FSMState[]
  onChange: (states: FSMState[]) => void
  allStateNames: string[]
}

export default function StateTable({ states, onChange, allStateNames }: StateTableProps) {
  const parentOptions = useMemo(
    () => allStateNames.map((n) => ({ value: n, label: n })),
    [allStateNames],
  )

  const columns: Column<FSMState>[] = useMemo(
    () => [
      {
        key: 'name',
        header: 'Name',
        width: '150px',
        accessor: (r) => r.name,
        editor: 'text',
        onChange: (r, v) => ({ ...r, name: String(v) }),
        required: true,
      },
      {
        key: 'type',
        header: 'Type',
        width: '120px',
        accessor: (r) => r.type ?? 'stable',
        editor: 'select',
        editorOptions: { options: STATE_TYPES },
        onChange: (r, v) => ({ ...r, type: (String(v) || 'stable') as FSMState['type'] }),
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
      {
        key: 'parent',
        header: 'Parent',
        width: '130px',
        accessor: (r) => r.parent ?? '',
        editor: 'select',
        editorOptions: { options: parentOptions },
        onChange: (r, v) => ({ ...r, parent: String(v) || undefined }),
      },
      {
        key: 'on_enter',
        header: 'On enter',
        accessor: (r) => actionsToString(r.on_enter),
        editor: 'text',
        onChange: (r, v) => ({ ...r, on_enter: parseActions(String(v)) }),
      },
      {
        key: 'on_exit',
        header: 'On exit',
        accessor: (r) => actionsToString(r.on_exit),
        editor: 'text',
        onChange: (r, v) => ({ ...r, on_exit: parseActions(String(v)) }),
      },
    ],
    [parentOptions],
  )

  return (
    <DataTable<FSMState>
      columns={columns}
      rows={states}
      onRowsChange={onChange}
      rowKey={(r) => r.name || `state-${states.indexOf(r)}`}
      onAddRow={() => ({ name: `state_${states.length + 1}`, type: 'stable' })}
      canDeleteRow={() => states.length > 1}
      emptyMessage="No states defined. Add one to get started."
      addLabel="Add state"
    />
  )
}
