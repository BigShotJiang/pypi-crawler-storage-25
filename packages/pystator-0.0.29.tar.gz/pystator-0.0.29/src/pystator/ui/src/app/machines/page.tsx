'use client'

import { useCallback, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import MachineTable from '@/components/machines/MachineTable'
import MachineEditModal from '@/components/machines/MachineEditModal'
import MachineCreateModal from '@/components/machines/MachineCreateModal'
import MachineUploadModal from '@/components/machines/MachineUploadModal'
import { listMachines, deleteMachine, getMachine, downloadFsmTemplatesZip } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import { stringifyFsmConfig } from '@/lib/fsmConfigParse'
import { downloadBlob } from '@/lib/utils'
import { ROUTES } from '@/lib/constants'
import { RefreshCw, Download, Plus } from 'lucide-react'

export default function MachinesPage() {
  const router = useRouter()
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [downloadingId, setDownloadingId] = useState<string | null>(null)
  const [editingMachine, setEditingMachine] = useState<MachineListItem | null>(null)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [downloadingTemplates, setDownloadingTemplates] = useState(false)

  const fetchMachines = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await listMachines()
      setMachines(res.machines)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchMachines()
  }, [fetchMachines])

  const handleOpen = (machine: MachineListItem) => {
    sessionStorage.setItem('pystator_open_machine_id', machine.id)
    router.push(ROUTES.WORKSPACE)
  }

  const handleDelete = async (machine: MachineListItem) => {
    const confirmed = window.confirm(
      `Delete machine "${machine.name}" v${machine.version}? This cannot be undone.`
    )
    if (!confirmed) return
    setDeleting(machine.id)
    try {
      await deleteMachine(machine.id)
      setMachines((prev) => prev.filter((m) => m.id !== machine.id))
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setDeleting(null)
    }
  }

  const handleDownload = async (machine: MachineListItem) => {
    setDownloadingId(machine.id)
    try {
      const res = await getMachine(machine.id)
      const content = stringifyFsmConfig(res.config, 'yaml')
      const blob = new Blob([content], { type: 'application/x-yaml' })
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${machine.name}_v${machine.version}.yaml`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setDownloadingId(null)
    }
  }

  const handleDownloadTemplates = async () => {
    try {
      setDownloadingTemplates(true)
      const blob = await downloadFsmTemplatesZip()
      downloadBlob(blob, 'fsm_templates.zip')
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setDownloadingTemplates(false)
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="Machines"
        description="FSM definitions stored in the database"
        actions={
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadTemplates}
              disabled={downloadingTemplates}
              title="Download FSM template files"
              className="gap-1.5"
            >
              <Download className={`h-4 w-4 mr-2 ${downloadingTemplates ? 'animate-pulse' : ''}`} />
              {downloadingTemplates ? 'Downloading...' : 'Download Templates'}
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => setShowCreateModal(true)}
              title="Create new machine"
              className="gap-1.5"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Machine
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowUploadModal(true)}
              title="Upload FSM config file"
              className="gap-1.5"
            >
              <Plus className="h-4 w-4 mr-2" />
              Upload
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchMachines}
              disabled={loading}
              title="Refresh machines"
              className="gap-1.5"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        }
      />

      {error && <ErrorDisplay error={error} className="mt-4" />}

      <div className="mt-6">
        {loading && machines.length === 0 ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner />
          </div>
        ) : machines.length === 0 && !loading ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">No machines found</CardTitle>
              <CardDescription>
                Machines are created when you save from the Workspace or seed the database.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-3">
              <Button variant="outline" onClick={() => router.push(ROUTES.WORKSPACE)}>
                Open Workspace
              </Button>
              <span className="text-sm text-muted-foreground self-center">
                or run <code className="px-1.5 py-0.5 bg-muted rounded text-xs">pystator db seed</code>
              </span>
            </CardContent>
          </Card>
        ) : (
          <MachineTable
            machines={machines}
            onOpen={handleOpen}
            onEdit={(m) => setEditingMachine(m)}
            onDelete={handleDelete}
            onDownload={handleDownload}
            downloadingId={downloadingId}
          />
        )}
      </div>

      <MachineEditModal
        isOpen={editingMachine !== null}
        machine={editingMachine}
        onClose={() => setEditingMachine(null)}
        onSuccess={fetchMachines}
      />
      <MachineCreateModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSuccess={fetchMachines}
      />
      <MachineUploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={fetchMachines}
      />
    </PageContainer>
  )
}
