'use client'

import { useState, useEffect, useCallback, useRef, useMemo } from 'react'
import { ResizableWorkspaceLayout } from '@/components/layout'
import {
  useWorkspaceStore,
  selectConfig,
  selectSetConfig,
  selectSyncSessionFromConfig,
  selectLastTransition,
  selectDiagramShowGuards,
  selectDiagramShowActions,
  selectDiagramHighlightState,
  selectDiagramHighlightTransition,
  selectPastLength,
  selectFutureLength,
  selectUndo,
  selectRedo,
  selectClearConfig,
  selectViewMode,
  selectSetViewMode,
} from '@/stores/workspace'
import { useToastStore } from '@/stores/toast'
import { WorkspaceConfigSidebar, WorkspaceTableEditor } from '@/components/workspace'
import { FsmFlowDiagram, DiagramContextMenu } from '@/components/fsm-flow'
import type { DiagramContextMenuProps, PaletteDragPayload } from '@/components/fsm-flow'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { listMachines, getMachine, validateConfig } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import { parseFsmConfig, stringifyFsmConfig } from '@/lib/fsmConfigParse'
import { readFileAsText, formatFromFilename, isAllowedFsmConfigFile } from '@/lib/fsmFileImport'
import { makeBlankState, makeBlankTransition } from '@/lib/workspaceDefaults'
import { buildRequestLifecycleTemplate, buildToggleTemplate } from '@/lib/workspaceTemplates'
import { useWorkspaceSave, useToolbarCompression } from '@/hooks'
import MachineSaveModal from '@/components/machines/MachineSaveModal'
import { StateModal } from '@/components/modals/StateModal'
import { TransitionModal } from '@/components/modals/TransitionModal'
import { Save, Download, Upload, Loader2, Undo2, Redo2, RotateCcw, Ellipsis, ChevronDown, Check, Workflow, Table2 } from 'lucide-react'
import type { FSMState, FSMTransition, FSMConfig } from '@/lib/types/fsm'
import {
  STATE_BLOCKS,
  TEMPLATE_BLOCKS,
  TRANSITION_BLOCKS,
  type StatePaletteBlockId,
  type TemplatePaletteId,
  type TransitionPaletteBlockId,
} from '@/components/workspace/paletteDefs'

const STATE_PALETTE_IDS = new Set<string>(STATE_BLOCKS.map((b) => b.id))
const TRANSITION_PALETTE_IDS = new Set<string>(TRANSITION_BLOCKS.map((b) => b.id))
const TEMPLATE_PALETTE_IDS = new Set<string>(TEMPLATE_BLOCKS.map((b) => b.id))

function WorkspaceContent() {
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const syncSessionFromConfig = useWorkspaceStore(selectSyncSessionFromConfig)
  const lastTransition = useWorkspaceStore(selectLastTransition)
  const diagramShowGuards = useWorkspaceStore(selectDiagramShowGuards)
  const diagramShowActions = useWorkspaceStore(selectDiagramShowActions)
  const diagramHighlightState = useWorkspaceStore(selectDiagramHighlightState)
  const diagramHighlightTransition = useWorkspaceStore(selectDiagramHighlightTransition)
  const pastLength = useWorkspaceStore(selectPastLength)
  const futureLength = useWorkspaceStore(selectFutureLength)
  const undo = useWorkspaceStore(selectUndo)
  const redo = useWorkspaceStore(selectRedo)
  const clearConfig = useWorkspaceStore(selectClearConfig)
  const viewMode = useWorkspaceStore(selectViewMode)
  const setViewMode = useWorkspaceStore(selectSetViewMode)
  const toast = useToastStore()
  const toolbarRef = useRef<HTMLDivElement>(null)
  const isToolbarCollapsed = useToolbarCompression(toolbarRef)
  const { status: saveStatus, save } = useWorkspaceSave(config)
  const lastSavedRef = useRef<string | null>(null)
  const prevSaveStatusRef = useRef(saveStatus)
  /** Flow coordinates for the next added state (palette drop or pane double-click). */
  const pendingStateDropPositionRef = useRef<{ x: number; y: number } | null>(null)
  const [saveModalOpen, setSaveModalOpen] = useState(false)
  const [importingConfig, setImportingConfig] = useState(false)
  const importInputRef = useRef<HTMLInputElement>(null)

  // Diagram-triggered modal state
  const [stateModalOpen, setStateModalOpen] = useState(false)
  const [stateModalMode, setStateModalMode] = useState<'add' | 'edit'>('add')
  const [stateModalData, setStateModalData] = useState<FSMState>(makeBlankState())
  const [transitionModalOpen, setTransitionModalOpen] = useState(false)
  const [transitionModalMode, setTransitionModalMode] = useState<'add' | 'edit'>('add')
  const [transitionModalData, setTransitionModalData] = useState<FSMTransition>(makeBlankTransition())
  const [editingTransitionIndex, setEditingTransitionIndex] = useState<number | null>(null)

  // Context menu state
  const [contextMenu, setContextMenu] = useState<DiagramContextMenuProps | null>(null)

  const isDirty =
    lastSavedRef.current !== null &&
    JSON.stringify(config) !== lastSavedRef.current

  useEffect(() => {
    const prev = prevSaveStatusRef.current
    prevSaveStatusRef.current = saveStatus
    if (saveStatus.type === 'success') {
      if (prev.type === 'loading') {
        toast.success(saveStatus.message)
        lastSavedRef.current = JSON.stringify(config)
      }
    } else if (saveStatus.type === 'error' && prev.type === 'loading') {
      toast.error(saveStatus.message)
    }
  }, [saveStatus, config, toast])

  const [machineList, setMachineList] = useState<MachineListItem[]>([])
  const [machinesLoading, setMachinesLoading] = useState(true)
  const [machineLoadError, setMachineLoadError] = useState<string | null>(null)
  const [loadingMachine, setLoadingMachine] = useState(false)
  const [selectedMachineName, setSelectedMachineName] = useState<string | null>(null)
  const [loadedMachineId, setLoadedMachineId] = useState<string | null>(null)

  const uniqueNames = useMemo(
    () => [...new Set(machineList.map((m) => m.name))].sort(),
    [machineList]
  )

  useEffect(() => {
    const machineId = sessionStorage.getItem('pystator_open_machine_id')
    if (!machineId) return
    sessionStorage.removeItem('pystator_open_machine_id')
    getMachine(machineId)
      .then((res) => {
        const next = JSON.parse(JSON.stringify(res.config))
        setConfig(next, { replaceHistory: true })
        lastSavedRef.current = JSON.stringify(next)
        syncSessionFromConfig()
      })
      .catch(() => {})
  }, [setConfig, syncSessionFromConfig])

  useEffect(() => {
    const yamlText = sessionStorage.getItem('pystator_load_template_yaml')
    if (!yamlText) return
    sessionStorage.removeItem('pystator_load_template_yaml')
    const result = parseFsmConfig(yamlText, 'yaml')
    if (!('error' in result)) {
      const next = JSON.parse(JSON.stringify(result.config))
      setConfig(next, { replaceHistory: true })
      lastSavedRef.current = JSON.stringify(next)
      syncSessionFromConfig()
    }
  }, [setConfig, syncSessionFromConfig])

  useEffect(() => {
    let cancelled = false
    listMachines()
      .then((res) => {
        if (!cancelled) setMachineList(res.machines ?? [])
      })
      .catch((err) => {
        if (!cancelled) setMachineLoadError(err instanceof Error ? err.message : 'Failed to load machines')
      })
      .finally(() => {
        if (!cancelled) setMachinesLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  // Sync Name/Version dropdowns from loaded config when machineList is available (e.g. after sessionStorage load)
  useEffect(() => {
    if (machineList.length === 0) return
    const name = config.meta?.machine_name
    const version = config.meta?.version
    if (name && version) {
      const m = machineList.find((x) => x.name === name && x.version === version)
      if (m) {
        setLoadedMachineId(m.id)
        setSelectedMachineName(name)
      }
    }
  }, [machineList, config.meta?.machine_name, config.meta?.version])

  // Keyboard shortcuts: Undo / Redo / View mode toggle
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
        if (e.shiftKey) {
          e.preventDefault()
          redo()
        } else {
          e.preventDefault()
          undo()
        }
      }
      // Ctrl+E / Cmd+E: toggle between diagram and table view
      if ((e.metaKey || e.ctrlKey) && e.key === 'e') {
        e.preventDefault()
        setViewMode(viewMode === 'diagram' ? 'table' : 'diagram')
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo, viewMode, setViewMode])

  const loadMachine = useCallback(
    (machineId: string) => {
      if (!machineId) return
      setLoadingMachine(true)
      setMachineLoadError(null)
      getMachine(machineId)
        .then((res) => {
          const next = JSON.parse(JSON.stringify(res.config))
          setConfig(next, { replaceHistory: true })
          lastSavedRef.current = JSON.stringify(next)
          syncSessionFromConfig()
          setLoadedMachineId(machineId)
          const machine = machineList.find((m) => m.id === machineId)
          if (machine) setSelectedMachineName(machine.name)
        })
        .catch((err) => {
          setMachineLoadError(err instanceof Error ? err.message : 'Failed to load machine')
        })
        .finally(() => setLoadingMachine(false))
    },
    [setConfig, syncSessionFromConfig, machineList]
  )

  const onMachineNameSelect = useCallback(
    (name: string) => {
      setSelectedMachineName(name)
      const first = machineList.find((m) => m.name === name)
      if (first) loadMachine(first.id)
    },
    [machineList, loadMachine]
  )

  const handleCreateMachineFromScratch = useCallback(() => {
    clearConfig()
    setLoadedMachineId(null)
    setSelectedMachineName(null)
    lastSavedRef.current = null
  }, [clearConfig])

  const downloadCurrentConfig = useCallback(() => {
    const yamlText = stringifyFsmConfig(config, 'yaml')
    const name = (config?.meta?.machine_name ?? 'fsm_config').replace(/[^a-zA-Z0-9_.-]/g, '_')
    const filename = name.endsWith('.yaml') ? name : `${name}.yaml`
    const blob = new Blob([yamlText], { type: 'application/x-yaml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [config])

  const openImportFilePicker = useCallback(() => {
    importInputRef.current?.click()
  }, [])

  const handleImportFileSelected = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return

    if (!isAllowedFsmConfigFile(file.name)) {
      toast.error('Please upload a YAML or JSON file (.yaml, .yml, or .json)')
      return
    }

    if (importingConfig) return

    if (isDirty) {
      const confirmed = window.confirm(
        'Importing a file will replace the current machine config. Continue?'
      )
      if (!confirmed) return
    }

    try {
      setImportingConfig(true)
      const raw = await readFileAsText(file)
      const format = formatFromFilename(file.name)
      const parsed = parseFsmConfig(raw, format)
      if ('error' in parsed) {
        toast.error(parsed.error)
        return
      }

      const res = await validateConfig(parsed.config)
      if (!res.valid) {
        const msg = (res.errors ?? []).length > 0
          ? (res.errors ?? []).slice(0, 6).join('\n')
          : 'Config is invalid.'
        toast.error(msg)
        return
      }

      const next = JSON.parse(JSON.stringify(parsed.config))
      setConfig(next, { replaceHistory: true })
      lastSavedRef.current = JSON.stringify(next)
      syncSessionFromConfig()
      setLoadedMachineId(null)
      setSelectedMachineName(null)
      toast.success('Config imported.')
    } catch (err) {
      const ex = err as { message?: string; response?: { detail?: string } }
      const msg =
        typeof (ex.response as { detail?: string })?.detail === 'string'
          ? (ex.response as { detail: string }).detail
          : ex.message ?? 'Import failed'
      toast.error(msg)
    } finally {
      setImportingConfig(false)
    }
  }, [
    importingConfig,
    isDirty,
    setConfig,
    syncSessionFromConfig,
    toast,
  ])

  const handleSaveClick = useCallback(() => {
    setSaveModalOpen(true)
  }, [])

  const handleModalSave = useCallback(async (name: string, version: string) => {
    await save(name, version)
    setConfig((prev) => ({
      ...prev,
      meta: { ...prev.meta, machine_name: name, version },
    }))
    setSaveModalOpen(false)
  }, [save, setConfig])

  // --- Diagram editing callbacks ---

  const stateNames = (config.states ?? []).map((s) => s.name)

  const regionNames = (config.states ?? []).flatMap((s) =>
    s.regions ? s.regions.map((r) => r.name) : []
  )

  const handleDiagramPaneDoubleClick = useCallback(
    (position: { x: number; y: number }) => {
      pendingStateDropPositionRef.current = position
      setStateModalMode('add')
      setStateModalData(makeBlankState())
      setStateModalOpen(true)
    },
    []
  )

  const handleDiagramNodeDoubleClick = useCallback(
    (stateName: string) => {
      const existing = (config.states ?? []).find((s) => s.name === stateName)
      if (!existing) return
      setStateModalMode('edit')
      setStateModalData({ ...existing })
      setStateModalOpen(true)
    },
    [config.states]
  )

  const handleDiagramEdgeDoubleClick = useCallback(
    (transitionIndex: number) => {
      const existing = (config.transitions ?? [])[transitionIndex]
      if (!existing) return
      setTransitionModalMode('edit')
      setTransitionModalData({ ...existing })
      setEditingTransitionIndex(transitionIndex)
      setTransitionModalOpen(true)
    },
    [config.transitions]
  )

  const handleDiagramConnect = useCallback(
    (sourceName: string, destName: string) => {
      setTransitionModalMode('add')
      setTransitionModalData(makeBlankTransition(sourceName, destName))
      setEditingTransitionIndex(null)
      setTransitionModalOpen(true)
    },
    []
  )

  const handleDiagramNodesDelete = useCallback(
    (deletedNames: string[]) => {
      const deletedSet = new Set(deletedNames)

      // Also collect child states of deleted parent states
      for (const s of config.states ?? []) {
        if (s.parent && deletedSet.has(s.parent)) {
          deletedSet.add(s.name)
        }
      }

      setConfig((prev) => {
        const nextStates = (prev.states ?? []).filter((s) => !deletedSet.has(s.name))
        const nextTransitions = (prev.transitions ?? []).filter((t) => {
          const sources = Array.isArray(t.source) ? t.source : [t.source]
          return !sources.some((src) => deletedSet.has(src)) && !deletedSet.has(t.dest)
        })
        return { ...prev, states: nextStates, transitions: nextTransitions }
      })
    },
    [setConfig]
  )

  const handleDiagramEdgesDelete = useCallback(
    (indices: number[]) => {
      const indexSet = new Set(indices)
      setConfig((prev) => ({
        ...prev,
        transitions: (prev.transitions ?? []).filter((_, i) => !indexSet.has(i)),
      }))
    },
    [setConfig]
  )

  const handleStateSave = useCallback(
    (state: FSMState) => {
      if (stateModalMode === 'add') {
        let nextState = state
        const pending = pendingStateDropPositionRef.current
        if (pending) {
          pendingStateDropPositionRef.current = null
          nextState = {
            ...state,
            metadata: {
              ...state.metadata,
              diagram_position: { x: pending.x, y: pending.y },
            },
          }
        }
        setConfig((prev) => ({
          ...prev,
          states: [...(prev.states ?? []), nextState],
        }))
      } else {
        // Edit mode: replace by original name
        const originalName = stateModalData.name
        setConfig((prev) => {
          const nextStates = (prev.states ?? []).map((s) =>
            s.name === originalName ? state : s
          )
          // Update references in transitions if name changed
          let nextTransitions = prev.transitions ?? []
          if (originalName !== state.name) {
            nextTransitions = nextTransitions.map((t) => {
              let source = t.source
              if (Array.isArray(source)) {
                source = source.map((s) => (s === originalName ? state.name : s))
              } else if (source === originalName) {
                source = state.name
              }
              const dest = t.dest === originalName ? state.name : t.dest
              return { ...t, source, dest }
            })
            // Update parent references
            nextStates.forEach((s, i) => {
              if (s.parent === originalName) {
                nextStates[i] = { ...s, parent: state.name }
              }
              if (s.initial_child === originalName) {
                nextStates[i] = { ...nextStates[i], initial_child: state.name }
              }
            })
          }
          return { ...prev, states: nextStates, transitions: nextTransitions }
        })
      }
    },
    [stateModalMode, stateModalData.name, setConfig]
  )

  const handleTransitionSave = useCallback(
    (transition: FSMTransition) => {
      if (transitionModalMode === 'add') {
        setConfig((prev) => ({
          ...prev,
          transitions: [...(prev.transitions ?? []), transition],
        }))
      } else if (editingTransitionIndex != null) {
        setConfig((prev) => ({
          ...prev,
          transitions: (prev.transitions ?? []).map((t, i) =>
            i === editingTransitionIndex ? transition : t
          ),
        }))
      }
    },
    [transitionModalMode, editingTransitionIndex, setConfig]
  )

  const openStateModalFromPalette = useCallback((id: StatePaletteBlockId) => {
    const typeById: Record<StatePaletteBlockId, FSMState['type']> = {
      initial: 'initial',
      stable: 'stable',
      terminal: 'terminal',
      parallel: 'parallel',
    }
    setStateModalMode('add')
    setStateModalData({ ...makeBlankState(), type: typeById[id] })
    setStateModalOpen(true)
  }, [])

  const handlePaletteStateSelect = useCallback(
    (id: StatePaletteBlockId) => {
      pendingStateDropPositionRef.current = null
      openStateModalFromPalette(id)
    },
    [openStateModalFromPalette]
  )

  const handlePaletteTransitionSelect = useCallback((id: TransitionPaletteBlockId) => {
    const sourceDefault = stateNames[0] ?? ''
    const destDefault = stateNames.find((n) => n !== sourceDefault) ?? sourceDefault

    const base = makeBlankTransition(sourceDefault, destDefault)
    const prefilled: FSMTransition =
      id === 'guarded'
        ? { ...base, guards: ['condition_ok'] }
        : id === 'action'
          ? { ...base, actions: ['perform_action'] }
          : id === 'delayed'
            ? { ...base, after: '1s' }
            : base

    setTransitionModalMode('add')
    setTransitionModalData(prefilled)
    setEditingTransitionIndex(null)
    setTransitionModalOpen(true)
  }, [stateNames])

  const handlePaletteTemplateApply = useCallback((id: TemplatePaletteId) => {
    const hasExistingContent =
      (config.states?.length ?? 0) > 0 ||
      (config.transitions?.length ?? 0) > 0 ||
      (config.state_variables?.length ?? 0) > 0

    if (hasExistingContent) {
      const confirmed = window.confirm(
        'Applying a template will replace the current machine config. Continue?'
      )
      if (!confirmed) return
    }

    const next = id === 'toggle_fsm'
      ? buildToggleTemplate()
      : buildRequestLifecycleTemplate()

    setConfig(JSON.parse(JSON.stringify(next)), { replaceHistory: true })
    syncSessionFromConfig()
    setLoadedMachineId(null)
    setSelectedMachineName(null)
    lastSavedRef.current = null
    toast.success('Template applied.')
  }, [config, setConfig, syncSessionFromConfig, toast])

  const handlePaletteDrop = useCallback(
    (
      payload: PaletteDragPayload,
      flowPosition: { x: number; y: number } | null
    ) => {
      if (payload.kind === 'state' && STATE_PALETTE_IDS.has(payload.id)) {
        pendingStateDropPositionRef.current = flowPosition
        openStateModalFromPalette(payload.id as StatePaletteBlockId)
        return
      }
      pendingStateDropPositionRef.current = null
      if (payload.kind === 'transition' && TRANSITION_PALETTE_IDS.has(payload.id)) {
        handlePaletteTransitionSelect(payload.id as TransitionPaletteBlockId)
        return
      }
      if (payload.kind === 'template' && TEMPLATE_PALETTE_IDS.has(payload.id)) {
        handlePaletteTemplateApply(payload.id as TemplatePaletteId)
      }
    },
    [openStateModalFromPalette, handlePaletteTransitionSelect, handlePaletteTemplateApply]
  )

  const highlightTransition =
    diagramHighlightTransition ??
    (lastTransition
      ? {
          source: lastTransition.source_state,
          target: lastTransition.target_state,
          trigger: lastTransition.trigger,
        }
      : null)

  const versionsForSelectedName = useMemo(
    () => (selectedMachineName ? machineList.filter((m) => m.name === selectedMachineName) : []),
    [machineList, selectedMachineName]
  )

  return (
    <ResizableWorkspaceLayout
      groupId="workspace-layout"
      renderSidebar={(api) => (
        <WorkspaceConfigSidebar
          {...api}
          machineList={machineList}
          machinesLoading={machinesLoading}
          machineLoadError={machineLoadError}
          uniqueNames={uniqueNames}
          selectedMachineName={selectedMachineName}
          onMachineNameSelect={onMachineNameSelect}
          onCreateMachineFromScratch={handleCreateMachineFromScratch}
          onSelectStateBlock={handlePaletteStateSelect}
          onSelectTransitionBlock={handlePaletteTransitionSelect}
          onApplyTemplate={handlePaletteTemplateApply}
        />
      )}
    >
      <input
        ref={importInputRef}
        type="file"
        accept=".yaml,.yml,.json"
        onChange={handleImportFileSelected}
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
      />
      {viewMode === 'diagram' ? (
        <div className="absolute inset-0">
          <FsmFlowDiagram
            config={config}
            minHeight="100%"
            showGuards={diagramShowGuards}
            showActions={diagramShowActions}
            highlightState={diagramHighlightState}
            highlightTransition={highlightTransition}
            editable
            onPaneDoubleClick={handleDiagramPaneDoubleClick}
            onNodeDoubleClick={handleDiagramNodeDoubleClick}
            onEdgeDoubleClick={handleDiagramEdgeDoubleClick}
            onConnect={handleDiagramConnect}
            onNodesDelete={handleDiagramNodesDelete}
            onEdgesDelete={handleDiagramEdgesDelete}
            onPaletteDrop={handlePaletteDrop}
          />
        </div>
      ) : (
        <div className="absolute inset-0 overflow-hidden">
          <WorkspaceTableEditor />
        </div>
      )}

      {/* Machine load / save toolbar: Name + Version + Undo/Redo/Clear, with compression */}
      <div
        ref={toolbarRef}
        className="absolute top-3 right-3 z-10 flex flex-row items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm"
      >
        {!isToolbarCollapsed ? (
          <>
            {/* View mode toggle: Diagram / Table */}
            <div
              className="flex rounded-lg border border-border/70 bg-background/50 p-0.5"
              role="tablist"
              aria-label="Diagram or Table"
            >
              <button
                type="button"
                role="tab"
                aria-selected={viewMode === 'diagram'}
                onClick={() => setViewMode('diagram')}
                className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  viewMode === 'diagram'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                title="Diagram view (Ctrl+E)"
                aria-label="Diagram view"
              >
                <Workflow className="h-3.5 w-3.5" />
                Diagram
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={viewMode === 'table'}
                onClick={() => setViewMode('table')}
                className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  viewMode === 'table'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                title="Table view (Ctrl+E)"
                aria-label="Table view"
              >
                <Table2 className="h-3.5 w-3.5" />
                Table
              </button>
            </div>
            <div className="h-5 border-l border-border" />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={machinesLoading || loadingMachine || !selectedMachineName || versionsForSelectedName.length === 0}
                  className="h-7 gap-1 px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                  aria-label="Machine version"
                >
                  {loadingMachine ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <>
                      v{versionsForSelectedName.find((m) => m.id === loadedMachineId)?.version ?? config.meta?.version ?? '—'}
                      {versionsForSelectedName.length > 1 && (
                        <ChevronDown className="h-3 w-3 opacity-60" />
                      )}
                    </>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                <DropdownMenuLabel className="text-xs">
                  Versions{versionsForSelectedName.length === 0 ? '' : ` (${versionsForSelectedName.length})`}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {versionsForSelectedName.length === 0 ? (
                  <DropdownMenuItem disabled className="text-muted-foreground">
                    Select a machine in Browse
                  </DropdownMenuItem>
                ) : (
                  versionsForSelectedName.map((m) => {
                    const isActive = m.id === loadedMachineId
                    return (
                      <DropdownMenuItem
                        key={m.id}
                        onClick={() => loadMachine(m.id)}
                        className="justify-between"
                      >
                        <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                        {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                      </DropdownMenuItem>
                    )
                  })
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            {machineLoadError ? (
              <span className="text-xs text-destructive" title={machineLoadError}>
                {machineLoadError.length > 20 ? machineLoadError.slice(0, 20) + '...' : machineLoadError}
              </span>
            ) : null}
            <div className="h-5 border-l border-border" />
            <Button
              variant="ghost"
              size="sm"
              onClick={undo}
              disabled={pastLength === 0}
              className="shrink-0 p-2"
              title="Undo (Ctrl+Z)"
              aria-label="Undo"
            >
              <Undo2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={redo}
              disabled={futureLength === 0}
              className="shrink-0 p-2"
              title="Redo (Ctrl+Shift+Z)"
              aria-label="Redo"
            >
              <Redo2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearConfig}
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground shrink-0"
              title="Clear diagram"
              aria-label="Clear"
            >
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
              Clear
            </Button>
            <div className="h-5 border-l border-border" />
            <Button
              variant="outline"
              size="sm"
              onClick={downloadCurrentConfig}
              className="shrink-0 p-2"
              title="Download as YAML"
              aria-label="Download as YAML"
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={openImportFilePicker}
              disabled={importingConfig}
              className="shrink-0 p-2"
              title="Import from YAML/JSON"
              aria-label="Import from YAML/JSON"
            >
              {importingConfig ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
            </Button>
            <div className="relative inline-flex items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSaveClick}
                disabled={saveStatus.type === 'loading'}
                className="shrink-0 p-2"
                title="Save"
                aria-label={saveStatus.type === 'loading' ? 'Saving...' : 'Save'}
              >
                {saveStatus.type === 'loading' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
              </Button>
              {isDirty && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500"
                  title="Unsaved changes"
                  aria-hidden
                />
              )}
            </div>
          </>
        ) : (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="shrink-0 p-2" aria-label="More options">
                  <Ellipsis className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="text-xs">View</DropdownMenuLabel>
                <DropdownMenuRadioGroup
                  value={viewMode}
                  onValueChange={(v) => setViewMode(v as 'diagram' | 'table')}
                >
                  <DropdownMenuRadioItem value="diagram" className="text-xs">
                    <Workflow className="mr-2 h-4 w-4" />
                    Diagram
                  </DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="table" className="text-xs">
                    <Table2 className="mr-2 h-4 w-4" />
                    Table
                  </DropdownMenuRadioItem>
                </DropdownMenuRadioGroup>
                <DropdownMenuSeparator />
                <DropdownMenuLabel className="text-xs">Version</DropdownMenuLabel>
                {versionsForSelectedName.length === 0 ? (
                  <DropdownMenuItem disabled className="text-muted-foreground text-xs">
                    Select a machine in Browse
                  </DropdownMenuItem>
                ) : (
                  versionsForSelectedName.map((m) => {
                    const isActive = m.id === loadedMachineId
                    return (
                      <DropdownMenuItem
                        key={m.id}
                        onClick={() => loadMachine(m.id)}
                        className="justify-between text-xs"
                      >
                        <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                        {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                      </DropdownMenuItem>
                    )
                  })
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={undo} disabled={pastLength === 0}>
                  <Undo2 className="mr-2 h-4 w-4" />
                  Undo
                  <span className="ml-auto text-xs text-muted-foreground">Ctrl+Z</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={redo} disabled={futureLength === 0}>
                  <Redo2 className="mr-2 h-4 w-4" />
                  Redo
                  <span className="ml-auto text-xs text-muted-foreground">Ctrl+Shift+Z</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={clearConfig}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Clear
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={downloadCurrentConfig}>
                  <Download className="mr-2 h-4 w-4" />
                  Download YAML
                </DropdownMenuItem>
                <DropdownMenuItem onClick={openImportFilePicker} disabled={importingConfig}>
                  {importingConfig ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="mr-2 h-4 w-4" />
                  )}
                  Import file
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleSaveClick}
                  disabled={saveStatus.type === 'loading'}
                >
                  {saveStatus.type === 'loading' ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-2 h-4 w-4" />
                  )}
                  Save
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {isDirty ? (
              <span className="flex items-center gap-1.5" title="Unsaved changes" role="status">
                <span
                  className="w-2 h-2 rounded-full bg-amber-500 shrink-0"
                  aria-hidden
                />
                <span className="text-xs text-amber-600 dark:text-amber-400">Unsaved</span>
              </span>
            ) : null}
          </>
        )}
      </div>

      {/* Context menu */}
      {contextMenu && (
        <DiagramContextMenu {...contextMenu} />
      )}

      {/* Machine save modal */}
      <MachineSaveModal
        isOpen={saveModalOpen}
        onClose={() => setSaveModalOpen(false)}
        onSave={handleModalSave}
        defaultName={config.meta?.machine_name ?? ''}
        defaultVersion={config.meta?.version ?? '1.0.0'}
      />

      {/* Diagram-triggered state modal (add/edit) */}
      <StateModal
        open={stateModalOpen}
        onOpenChange={(open) => {
          setStateModalOpen(open)
          if (!open) pendingStateDropPositionRef.current = null
        }}
        state={stateModalData}
        existingStateNames={stateNames}
        onSave={handleStateSave}
        title={stateModalMode === 'add' ? 'Add State' : 'Edit State'}
        description={
          stateModalMode === 'add'
            ? 'Add a new state to the machine.'
            : 'Edit the selected state.'
        }
      />

      {/* Diagram-triggered transition modal (add/edit) */}
      <TransitionModal
        open={transitionModalOpen}
        onOpenChange={setTransitionModalOpen}
        transition={transitionModalData}
        stateNames={stateNames}
        regionNames={regionNames}
        onSave={handleTransitionSave}
        title={transitionModalMode === 'add' ? 'Add Transition' : 'Edit Transition'}
        description={
          transitionModalMode === 'add'
            ? 'Add a new transition between states.'
            : 'Edit the selected transition.'
        }
      />
    </ResizableWorkspaceLayout>
  )
}

export default function WorkspacePage() {
  return <WorkspaceContent />
}
