'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { ResizableTriplePanelLayout } from '@/components/layout'
import { DiscoveryCatalogPinsPanel } from '@/components/discovery/DiscoveryCatalogPinsPanel'
import { DiscoveryCandidatesColumn } from '@/components/discovery/DiscoveryCandidatesColumn'
import { DiscoveryWorkspace } from '@/components/discovery/DiscoveryWorkspace'
import { useCatalogMachinesGrouped } from '@/hooks/useCatalogMachinesGrouped'
import { useDiscoveryPinnedCatalogMachines } from '@/hooks/useDiscoveryPinnedCatalogMachines'
import { useDiscoveryWorkspace } from '@/hooks/useDiscoveryWorkspace'
import type { MachineListItem } from '@/lib/api'
import { useRef } from 'react'

const DISCOVERY_FOCUSED_PIN_KEY = 'pystator_discovery_focused_pin_id'

export default function DiscoveryPage() {
  const workspace = useDiscoveryWorkspace()
  const catalog = useCatalogMachinesGrouped()
  const pinned = useDiscoveryPinnedCatalogMachines()
  const [focusedPinId, setFocusedPinId] = useState<string | null>(null)
  const lastOpenedPinIdRef = useRef<string | null>(null)

  const focusedPin = useMemo(
    () => (focusedPinId ? pinned.pins.find((p) => p.id === focusedPinId) ?? null : null),
    [focusedPinId, pinned.pins]
  )

  const handleClearFocus = useCallback(() => {
    setFocusedPinId(null)
    workspace.selectVersion(null)
    workspace.selectDraft(null)
    workspace.setMachineName('')
  }, [workspace])

  const handleFocusPin = useCallback(
    (pin: MachineListItem) => {
      setFocusedPinId(pin.id)
      void workspace.openMachine(pin.name)
    },
    [workspace]
  )

  const handleAfterObservation = useCallback(() => {
    void workspace.refreshAvailableMachines()
  }, [workspace])

  useEffect(() => {
    if (typeof window === 'undefined') return
    const saved = window.localStorage.getItem(DISCOVERY_FOCUSED_PIN_KEY)
    if (saved && saved.trim()) {
      setFocusedPinId(saved.trim())
    }
  }, [])

  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!focusedPinId) {
      window.localStorage.removeItem(DISCOVERY_FOCUSED_PIN_KEY)
      return
    }
    window.localStorage.setItem(DISCOVERY_FOCUSED_PIN_KEY, focusedPinId)
  }, [focusedPinId])

  useEffect(() => {
    if (focusedPinId && !pinned.pins.some((p) => p.id === focusedPinId)) {
      handleClearFocus()
    }
  }, [focusedPinId, pinned.pins, handleClearFocus])

  useEffect(() => {
    if (!focusedPinId) return
    if (lastOpenedPinIdRef.current === focusedPinId) return
    const pin = pinned.pins.find((p) => p.id === focusedPinId)
    if (!pin) return
    lastOpenedPinIdRef.current = focusedPinId
    void workspace.openMachine(pin.name)
  }, [focusedPinId, pinned.pins, workspace.openMachine])

  return (
    <ResizableTriplePanelLayout
      groupId="discovery-triple"
      left={(api) => (
        <DiscoveryCatalogPinsPanel
          api={api}
          catalog={catalog}
          pinned={pinned}
          focusedPinId={focusedPinId}
          onFocusPin={handleFocusPin}
          onClearFocus={handleClearFocus}
        />
      )}
      middle={(api) => (
        <DiscoveryCandidatesColumn
          api={api}
          workspace={workspace}
          focusedPinId={focusedPinId}
          baselineCatalogMachineId={focusedPin?.id ?? null}
        />
      )}
      right={
        <DiscoveryWorkspace
          mode="threeColumn"
          workspace={workspace}
          baselineCatalogMachineId={focusedPin?.id ?? null}
          onAfterObservation={handleAfterObservation}
        />
      }
    />
  )
}
