'use client'

import { useState } from 'react'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { getSettings, saveSettings, type AppSettings } from '@/lib/settings'
import {
  ApiServerCard,
  DatabaseConfigCard,
  DiscoveryConfigCard,
  DlqConfigCard,
} from '@/components/settings'
import { Loader2 } from 'lucide-react'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'

export default function SettingsPage() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)
  const [settings, setSettings] = useState<AppSettings>(getSettings())
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const handleSave = () => {
    setSaving(true)
    setMessage(null)
    try {
      saveSettings(settings)
      setMessage({ type: 'success', text: 'Settings saved.' })
      setTimeout(() => window.location.reload(), 1000)
    } catch (e) {
      setMessage({ type: 'error', text: String(e) })
    } finally {
      setSaving(false)
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="Settings"
        description={
          version
            ? `Configure ${appName} API URL, database, discovery, and DLQ (${version})`
            : `Configure ${appName} API URL, database, discovery, and DLQ`
        }
      />

      {message && (
        <Alert className={`mt-4 ${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
          <AlertDescription className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      <div className="mt-8 space-y-6">
        <ApiServerCard
          url={settings.apiServer.url}
          onUrlChange={(url) => setSettings((s) => ({ ...s, apiServer: { ...s.apiServer, url } }))}
        />
        <DatabaseConfigCard
          connectionString={settings.database.connectionString ?? ''}
          host={settings.database.host ?? ''}
          port={settings.database.port != null ? String(settings.database.port) : ''}
          database={settings.database.database ?? ''}
          username={settings.database.username ?? ''}
          password={settings.database.password ?? ''}
          onConnectionStringChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, connectionString: v || undefined } }))
          }
          onHostChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, host: v || undefined } }))
          }
          onPortChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, port: v ? parseInt(v, 10) : undefined },
            }))
          }
          onDatabaseChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, database: v || undefined } }))
          }
          onUsernameChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, username: v || undefined } }))
          }
          onPasswordChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, password: v || undefined } }))
          }
        />
        <DiscoveryConfigCard
          backend={settings.discovery.backend}
          connectionString={settings.discovery.connectionString ?? ''}
          shadowEnabled={settings.discovery.shadowEnabled}
          minEdgeCount={String(settings.discovery.minEdgeCount)}
          minConfidence={String(settings.discovery.minConfidence)}
          driftAlertThreshold={String(settings.discovery.driftAlertThreshold)}
          driftSevereThreshold={String(settings.discovery.driftSevereThreshold)}
          driftMinSample={String(settings.discovery.driftMinSample)}
          lowSampleThreshold={String(settings.discovery.lowSampleThreshold)}
          onBackendChange={(v) =>
            setSettings((s) => ({ ...s, discovery: { ...s.discovery, backend: v } }))
          }
          onConnectionStringChange={(v) =>
            setSettings((s) => ({ ...s, discovery: { ...s.discovery, connectionString: v || undefined } }))
          }
          onShadowEnabledChange={(v) =>
            setSettings((s) => ({ ...s, discovery: { ...s.discovery, shadowEnabled: v } }))
          }
          onMinEdgeCountChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: { ...s.discovery, minEdgeCount: v ? parseInt(v, 10) : 2 },
            }))
          }
          onMinConfidenceChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: { ...s.discovery, minConfidence: v ? parseFloat(v) : 0.5 },
            }))
          }
          onDriftAlertThresholdChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: {
                ...s.discovery,
                driftAlertThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.15,
              },
            }))
          }
          onDriftSevereThresholdChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: {
                ...s.discovery,
                driftSevereThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.4,
              },
            }))
          }
          onDriftMinSampleChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: { ...s.discovery, driftMinSample: v ? Math.max(1, parseInt(v, 10)) : 3 },
            }))
          }
          onLowSampleThresholdChange={(v) =>
            setSettings((s) => ({
              ...s,
              discovery: {
                ...s.discovery,
                lowSampleThreshold: v ? Math.max(1, parseInt(v, 10)) : 10,
              },
            }))
          }
        />
        <DlqConfigCard
          enabled={settings.dlq.enabled}
          connectionString={settings.dlq.connectionString ?? ''}
          host={settings.dlq.host ?? ''}
          port={settings.dlq.port != null ? String(settings.dlq.port) : ''}
          database={settings.dlq.database ?? ''}
          username={settings.dlq.username ?? ''}
          password={settings.dlq.password ?? ''}
          tableName={settings.dlq.tableName ?? 'pystator_dead_letter_queue'}
          onEnabledChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, enabled: v } }))}
          onConnectionStringChange={(v) =>
            setSettings((s) => ({ ...s, dlq: { ...s.dlq, connectionString: v || undefined } }))
          }
          onHostChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, host: v || undefined } }))}
          onPortChange={(v) =>
            setSettings((s) => ({
              ...s,
              dlq: { ...s.dlq, port: v ? parseInt(v, 10) : undefined },
            }))
          }
          onDatabaseChange={(v) =>
            setSettings((s) => ({ ...s, dlq: { ...s.dlq, database: v || undefined } }))
          }
          onUsernameChange={(v) =>
            setSettings((s) => ({ ...s, dlq: { ...s.dlq, username: v || undefined } }))
          }
          onPasswordChange={(v) =>
            setSettings((s) => ({ ...s, dlq: { ...s.dlq, password: v || undefined } }))
          }
          onTableNameChange={(v) =>
            setSettings((s) => ({ ...s, dlq: { ...s.dlq, tableName: v || undefined } }))
          }
        />
      </div>

      <div className="flex justify-end mt-6">
        <Button onClick={handleSave} disabled={saving} size="lg">
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            'Save Settings'
          )}
        </Button>
      </div>
    </PageContainer>
  )
}
