import { clearAccessToken, getAccessToken } from './auth-storage'
import { getApiBaseUrl } from './settings'
import { AUTH_SESSION_EXPIRED_EVENT } from './constants'
import type { FSMConfig, ValidateResponse, ProcessResponse } from './types/fsm'

function handleUnauthorized(): void {
  clearAccessToken()
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT))
  }
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: unknown
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

/** Return a user-facing message from a fetch/API error, or a default. */
export function getApiErrorMessage(error: unknown, defaultMessage: string): string {
  if (error instanceof Error) return error.message || defaultMessage
  if (typeof error === 'string') return error
  return defaultMessage
}

/** Response from GET /api/v1/auth/me */
export interface AuthMeResponse {
  username: string
  auth_disabled?: boolean
}

/** Response from POST /api/v1/auth/login */
export interface AuthLoginResponse {
  access_token: string
  token_type: string
  expires_in: number
}

export function authHeaders(): Record<string, string> {
  const token = getAccessToken()
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) headers['Authorization'] = `Bearer ${token}`
  return headers
}

async function fetchApi<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, {
    ...options,
    headers: { ...authHeaders(), ...(options?.headers as Record<string, string>) },
  })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  // 204 No Content (e.g. DELETE) has no body; do not call response.json()
  if (response.status === 204) return undefined as T
  const ct = response.headers.get('content-type')
  if (ct?.includes('application/json')) return response.json()
  return response.text() as unknown as T
}

/** Fetch an endpoint and return the response body as a Blob (e.g. for ZIP download). */
export async function getBlob(endpoint: string): Promise<Blob> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, { method: 'GET', headers: authHeaders() })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.blob()
}

/**
 * Fetch with timeout for auth endpoints. On 401 clears token; on AbortError or
 * network error throws ApiError with status 0 or connection message.
 */
async function fetchWithTimeout<T>(
  url: string,
  options: RequestInit,
  timeoutMs: number
): Promise<T> {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, { ...options, signal: controller.signal })
    clearTimeout(timeoutId)
    if (response.status === 401) {
      handleUnauthorized()
      throw new ApiError('Not authenticated', 401, { detail: 'Not authenticated' })
    }
    if (!response.ok) {
      let errorData: { detail?: string }
      try {
        errorData = await response.json()
      } catch {
        errorData = { detail: response.statusText }
      }
      throw new ApiError(
        errorData.detail ?? `API request failed: ${response.statusText}`,
        response.status,
        errorData
      )
    }
    return await response.json()
  } catch (err) {
    clearTimeout(timeoutId)
    if (err instanceof ApiError) throw err
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ApiError('Request timed out', 0, { originalError: 'Timeout' })
    }
    if (err instanceof TypeError && err.message === 'Failed to fetch') {
      throw new ApiError(
        `Unable to connect to API server at ${getApiBaseUrl()}. Please ensure the API server is running.`,
        0,
        { originalError: 'NetworkError' }
      )
    }
    throw err
  }
}

/** GET /api/v1/auth/me with timeout. Used on initial load. */
export async function authMeWithTimeout(timeoutMs: number): Promise<AuthMeResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/me`
  return fetchWithTimeout<AuthMeResponse>(
    url,
    { method: 'GET', headers: authHeaders() },
    timeoutMs
  )
}

/** POST /api/v1/auth/login with timeout. */
export async function loginWithTimeout(
  username: string,
  password: string,
  timeoutMs: number
): Promise<AuthLoginResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/login`
  return fetchWithTimeout<AuthLoginResponse>(
    url,
    {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ username, password }),
    },
    timeoutMs
  )
}

export async function validateConfig(config: FSMConfig): Promise<ValidateResponse> {
  return fetchApi<ValidateResponse>('/api/v1/machines/validate', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function processEvent(
  config: FSMConfig,
  currentState: string,
  trigger: string,
  context?: Record<string, unknown>
): Promise<ProcessResponse> {
  return fetchApi<ProcessResponse>('/api/v1/process', {
    method: 'POST',
    body: JSON.stringify({ config, current_state: currentState, trigger, context: context ?? {} }),
  })
}

export async function healthCheck(): Promise<{ status: string; version?: string }> {
  return fetchApi<{ status: string; version?: string }>('/health')
}

/** Database config from API (mirrors PyCharter settings/database-config) */
export interface DatabaseConfigResponse {
  configured_url: string | null
  actual_url: string
  database_type: string
  is_default: boolean
  machine_count: number
  message: string
}

/** Request body for testing database connection */
export interface DatabaseTestRequest {
  connection_string?: string
  host?: string
  port?: number
  database?: string
  username?: string
  password?: string
}

/** Response for database connection test */
export interface DatabaseTestResponse {
  success: boolean
  message: string
}

export interface DiscoveryConfigResponse {
  backend: string
  database_url: string | null
  shadow_enabled: boolean
  min_edge_count: number
  min_confidence: number
  drift_alert_threshold: number
  drift_severe_threshold: number
  drift_min_sample: number
  low_sample_threshold: number
}

export interface DiscoveryDatabaseTestRequest {
  backend: string
  connection_string?: string
}

export interface DiscoveryDatabaseTestResponse {
  success: boolean
  message: string
}

export async function getDatabaseConfig(): Promise<DatabaseConfigResponse> {
  return fetchApi<DatabaseConfigResponse>('/api/v1/settings/database-config')
}

export async function testDatabase(
  body: DatabaseTestRequest
): Promise<DatabaseTestResponse> {
  return fetchApi<DatabaseTestResponse>('/api/v1/settings/test-database', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getDiscoveryConfig(): Promise<DiscoveryConfigResponse> {
  return fetchApi<DiscoveryConfigResponse>('/api/v1/settings/discovery-config')
}

export async function testDiscoveryDatabase(
  body: DiscoveryDatabaseTestRequest
): Promise<DiscoveryDatabaseTestResponse> {
  return fetchApi<DiscoveryDatabaseTestResponse>('/api/v1/settings/test-discovery-database', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

/** DLQ test / stats (mirrors PyCharter settings API) */
export interface DlqTestRequest {
  connection_string?: string
  host?: string
  port?: number
  database?: string
  username?: string
  password?: string
  table_name?: string
}

export interface DlqTestResponse {
  success: boolean
  message: string
}

export type DlqStatsRequest = DlqTestRequest

export interface DlqStatsResponse {
  total_messages: number
  by_reason: Record<string, number | null | undefined>
  by_stage: Record<string, number | null | undefined>
  by_status: Record<string, number | null | undefined>
}

export interface WorkerDlqConfigResponse {
  dlq_enabled: boolean
  dlq_database_url: string | null
  dlq_table_name: string
  persistence: string
}

export async function getWorkerDlqConfig(): Promise<WorkerDlqConfigResponse> {
  return fetchApi<WorkerDlqConfigResponse>('/api/v1/settings/worker-dlq-config')
}

export async function testDlq(body: DlqTestRequest): Promise<DlqTestResponse> {
  return fetchApi<DlqTestResponse>('/api/v1/settings/test-dlq', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getDlqStats(body: DlqStatsRequest): Promise<DlqStatsResponse> {
  return fetchApi<DlqStatsResponse>('/api/v1/settings/dlq-stats', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

// ---- Discovery (infer / shadow) ----

export interface DiscoveryObserveRequest {
  machine_name: string
  entity_id: string
  state: string
  observed_at?: string
  source?: string
  source_event_id?: string
  ingest_seq?: number
  metadata?: Record<string, unknown>
}

export interface DiscoveryObserveResponse {
  accepted: boolean
}

export interface DiscoveryBuildCandidateRequest {
  machine_name: string
  version?: string
  mode?: 'inference' | 'manual'
  entity_ids?: string[]
  edge_selection?: Array<{ source_state: string; destination_state: string }>
  min_edge_count?: number
  min_confidence?: number
}

export interface InferredEdgeApiItem {
  source_state: string
  destination_state: string
  count: number
  unique_entities: number
  unique_sources: number
  confidence: number
}

export interface DiscoveryBuiltCandidateResponse {
  machine_name: string
  version: string
  candidate_sequence: number
  status: string
  config: Record<string, unknown>
  metadata: Record<string, unknown>
  edges: InferredEdgeApiItem[]
}

export interface DiscoveryPreviewRequest {
  machine_name: string
  mode?: 'inference' | 'manual'
  entity_ids?: string[]
  min_edge_count?: number
  min_confidence?: number
}

export interface DiscoveryPreviewResponse {
  machine_name: string
  mode: string
  entity_ids_used: string[]
  observation_count: number
  edges: InferredEdgeApiItem[]
  selected_edges: InferredEdgeApiItem[]
}

export interface DiscoveryEntityListResponse {
  machine_name: string
  entity_ids: string[]
}

export interface DiscoveryDeleteEntityObservationsResponse {
  machine_name: string
  entity_id: string
  deleted_count: number
}

export interface DiscoverySaveCandidateRequest {
  source_machine_name: string
  target_machine_name: string
  target_version?: string
  config: Record<string, unknown>
  metadata?: Record<string, unknown>
}

export interface DiscoveryBuiltCandidateSummaryItem {
  machine_name: string
  version: string
  candidate_sequence: number
  status: string
  created_at: string
  metadata: Record<string, unknown>
  observation_count_at_build: number
  shadow_diff_count_recent: number
  drift_rate_recent: number
  build_mode: string | null
}

export interface DiscoveryDraftResponse {
  id: string
  machine_name: string
  title: string | null
  selected_entity_ids: string[]
  mode: string
  min_edge_count: number
  min_confidence: number
  manual_edge_selection: Array<{ source_state: string; destination_state: string }>
  created_at: string
  updated_at: string
  last_built_version: string | null
}

export interface DiscoveryMachineDraftsResponse {
  machine_name: string
  drafts: DiscoveryDraftResponse[]
  built_candidates: DiscoveryBuiltCandidateSummaryItem[]
}

export interface DiscoveryDraftPatchRequest {
  title?: string | null
  selected_entity_ids?: string[]
  mode?: 'inference' | 'manual'
  min_edge_count?: number
  min_confidence?: number
  manual_edge_selection?: Array<{ source_state: string; destination_state: string }>
}

export interface DiscoveryShadowDiffResponse {
  machine_name: string
  source_state: string
  trigger: string
  active_success: boolean
  active_target_state: string | null
  candidate_success: boolean
  candidate_target_state: string | null
  differs: boolean
  reason: string | null
  metadata: Record<string, unknown>
}

/** One row from GET /api/v1/discovery/machines */
export interface DiscoveryFleetMachineItem {
  machine_name: string
  last_observation_at: string | null
  observation_count: number
  candidate_count: number
  latest_candidate_version: string | null
  latest_candidate_created_at: string | null
  shadow_diff_count_recent: number
  drift_rate_recent: number
}

export interface DiscoveryFleetListResponse {
  items: DiscoveryFleetMachineItem[]
  total: number
  limit: number
  offset: number
}

export type DiscoveryFleetQueryParams = {
  query?: string
  sort?: string
  order?: 'asc' | 'desc'
  limit?: number
  offset?: number
}

export async function listDiscoveryMachines(
  params: DiscoveryFleetQueryParams = {}
): Promise<DiscoveryFleetListResponse> {
  const q = new URLSearchParams()
  if (params.query) q.set('query', params.query)
  if (params.sort) q.set('sort', params.sort)
  if (params.order) q.set('order', params.order)
  if (params.limit != null) q.set('limit', String(params.limit))
  if (params.offset != null) q.set('offset', String(params.offset))
  const s = q.toString()
  return fetchApi<DiscoveryFleetListResponse>(
    `/api/v1/discovery/machines${s ? `?${s}` : ''}`
  )
}

export async function recordDiscoveryObservation(
  body: DiscoveryObserveRequest
): Promise<DiscoveryObserveResponse> {
  return fetchApi<DiscoveryObserveResponse>('/api/v1/discovery/observations', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function buildDiscoveryCandidate(
  body: DiscoveryBuildCandidateRequest
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>('/api/v1/discovery/candidates/build', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function previewDiscoveryCandidate(
  body: DiscoveryPreviewRequest
): Promise<DiscoveryPreviewResponse> {
  return fetchApi<DiscoveryPreviewResponse>('/api/v1/discovery/candidates/preview', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function listDiscoveryMachineEntityIds(
  machineName: string
): Promise<DiscoveryEntityListResponse> {
  return fetchApi<DiscoveryEntityListResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/entities`
  )
}

export async function deleteDiscoveryEntityObservations(
  machineName: string,
  entityId: string
): Promise<DiscoveryDeleteEntityObservationsResponse> {
  return fetchApi<DiscoveryDeleteEntityObservationsResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/entities/${encodeURIComponent(entityId)}/observations`,
    { method: 'DELETE' }
  )
}

export async function listDiscoveryCandidates(
  machineName: string
): Promise<DiscoveryMachineDraftsResponse> {
  return fetchApi<DiscoveryMachineDraftsResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}`
  )
}

export async function createDiscoveryDraft(
  machineName: string,
  body: { title?: string | null } = {}
): Promise<DiscoveryDraftResponse> {
  return fetchApi<DiscoveryDraftResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function patchDiscoveryDraft(
  machineName: string,
  draftId: string,
  body: DiscoveryDraftPatchRequest
): Promise<DiscoveryDraftResponse> {
  return fetchApi<DiscoveryDraftResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}`,
    { method: 'PATCH', body: JSON.stringify(body) }
  )
}

export async function deleteDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<void> {
  await fetchApi<void>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}`,
    { method: 'DELETE' }
  )
}

export async function previewDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<DiscoveryPreviewResponse> {
  return fetchApi<DiscoveryPreviewResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}/preview`,
    { method: 'POST' }
  )
}

export async function buildDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}/build`,
    { method: 'POST' }
  )
}

export async function getDiscoveryCandidate(
  machineName: string,
  version: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/${encodeURIComponent(version)}`
  )
}

export async function getLatestDiscoveryCandidate(
  machineName: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/latest`
  )
}

export async function listDiscoveryShadowDiffs(
  machineName: string,
  limit = 100
): Promise<DiscoveryShadowDiffResponse[]> {
  const q = new URLSearchParams()
  q.set('limit', String(limit))
  return fetchApi<DiscoveryShadowDiffResponse[]>(
    `/api/v1/discovery/shadow/${encodeURIComponent(machineName)}?${q.toString()}`
  )
}

/** Machine list item from API */
export interface MachineListItem {
  id: string
  name: string
  version: string
  description?: string | null
  created_at?: string | null
  updated_at?: string | null
}

/** Machine list response */
export interface MachineListResponse {
  machines: MachineListItem[]
  count: number
}

/** Full machine response (single machine) */
export interface MachineResponse {
  id: string
  name: string
  version: string
  description?: string | null
  strict_mode: boolean
  config: FSMConfig
  created_at?: string | null
  updated_at?: string | null
}

export async function listMachines(): Promise<MachineListResponse> {
  return fetchApi<MachineListResponse>('/api/v1/machines')
}

export async function createMachine(config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>('/api/v1/machines', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function updateMachine(machineId: string, config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'PUT',
    body: JSON.stringify({ config }),
  })
}

export async function getMachine(machineId: string): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`)
}

export async function promoteDiscoveryCandidate(
  machineName: string,
  version: string
): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/${encodeURIComponent(version)}/promote`,
    { method: 'POST' }
  )
}

export async function saveDiscoveryCandidate(
  body: DiscoverySaveCandidateRequest
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>('/api/v1/discovery/candidates/save', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function deleteMachine(machineId: string): Promise<void> {
  await fetchApi<void>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'DELETE',
  })
}

// ---- Entity types ----

/** Entity state from GET /api/v1/entities/{id}/state or list */
export interface EntityState {
  entity_id: string
  current_state: string
  machine_name: string | null
  context: Record<string, unknown>
  status: 'active' | 'archived' | 'deleted'
  /** FSM workflow outcome: in progress, completed terminal, or error terminal */
  workflow_status?: 'active' | 'complete' | 'failed'
  is_terminal?: boolean | null
  labels: Record<string, string>
  updated_at: string | null
  created_at: string | null
  archived_at: string | null
  deleted_at: string | null
}

/** Paginated entity list */
export interface EntityListResponse {
  entities: EntityState[]
  total: number
  limit: number
  offset: number
  next_cursor: string | null
}

/** Trigger info from available-triggers endpoint */
export interface TriggerInfo {
  trigger: string
  target_state: string
  has_guard: boolean
  guard_description: string | null
}

/** Response from GET /api/v1/entities/{id}/available-triggers */
export interface AvailableTriggersResponse {
  entity_id: string
  current_state: string
  triggers: TriggerInfo[]
}

/** Request body for POST /api/v1/entities/{id}/dry-run */
export interface DryRunRequest {
  trigger: string
  context?: Record<string, unknown>
}

/** Response from POST /api/v1/entities/{id}/dry-run */
export interface DryRunResponse {
  would_succeed: boolean
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  actions_that_would_execute: string[]
  error_detail: string | null
}

/** Response for entity labels */
export interface EntityLabelsResponse {
  entity_id: string
  labels: Record<string, string>
}

/** Response from GET /api/v1/entities/{id}/history/stats */
export interface HistoryStatsResponse {
  entity_id: string
  total_transitions: number
  first_at: string | null
  last_at: string | null
  success_count: number
  failure_count: number
}

/** Response from DELETE /api/v1/entities/{id}/history */
export interface HistoryPurgeResponse {
  entity_id: string
  deleted_count: number
  remaining_count: number
}

/** Single history record in a snapshot */
export interface TransitionHistorySnapshotItem {
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  created_at: string
  duration_ms: number | null
}

/** Full entity snapshot for export */
export interface EntitySnapshotResponse {
  entity_id: string
  machine_name: string | null
  current_state: string
  context: Record<string, unknown>
  status: string
  labels: Record<string, string>
  history: TransitionHistorySnapshotItem[]
  exported_at: string
}

/** Response from POST /api/v1/entities/import */
export interface ImportEntityResponse {
  entity_id: string
  history_count: number
  success: boolean
}

/** Request body for POST /api/v1/entities/import */
export interface ImportEntityRequest {
  entity_id: string
  machine_name?: string
  current_state: string
  context?: Record<string, unknown>
  status?: string
  labels?: Record<string, string>
  history?: Record<string, unknown>[]
  overwrite?: boolean
}

/** Single item in bulk create request */
export interface BulkCreateEntityItem {
  entity_id: string
  machine_name: string
  machine_version?: string
  context?: Record<string, unknown>
}

/** Response for one entity in bulk create */
export interface BulkCreateEntityResult {
  entity_id: string
  success: boolean
  current_state: string | null
  error: string | null
}

/** Response from POST /api/v1/entities/bulk/create */
export interface BulkCreateEntitiesResponse {
  results: BulkCreateEntityResult[]
  total: number
  succeeded: number
  failed: number
}

/** Response for one entity in bulk event processing */
export interface BulkProcessEventResult {
  entity_id: string
  success: boolean
  source_state: string | null
  target_state: string | null
  error: string | null
}

/** Response from POST /api/v1/entities/bulk/events */
export interface BulkProcessEventsResponse {
  trigger: string
  results: BulkProcessEventResult[]
  total: number
  succeeded: number
  failed: number
}

/** Request body for POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventRequest {
  trigger: string
  context?: Record<string, unknown>
  machine_name?: string
  machine_version?: string
}

/** Response from POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventResponse {
  success: boolean
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  actions: string[]
  error: string | null
  shadow_diff?: Record<string, unknown> | null
  transition_id: string | null
}

/** Request body for POST /api/v1/entities/{id}/create */
export interface CreateEntityRequest {
  machine_name: string
  machine_version?: string
  context?: Record<string, unknown>
}

/** Response from POST /api/v1/entities/{id}/create */
export interface CreateEntityResponse extends EntityState {
  transition_id: string
}

/** Single transition history entry */
export interface TransitionHistoryEntry {
  id: string
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  created_at: string
  duration_ms?: number | null
}

// ---- Observability types ----

export interface ObservabilitySummaryResponse {
  window_start: string
  window_end: string
  active_entities: number
  transitions_total: number
  transitions_failed: number
  transition_failure_rate: number
  p95_transition_duration_ms: number | null
  worker_pending: number
  worker_claimed: number
  worker_failed: number
  worker_dead_letter: number
}

export interface ObservabilityTransitionItem {
  id: string
  entity_id: string
  machine_name: string | null
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  duration_ms: number | null
  created_at: string
}

export interface ObservabilityTransitionsResponse {
  items: ObservabilityTransitionItem[]
  total: number
  limit: number
  offset: number
}

export interface ObservabilityWorkerEventItem {
  id: string
  machine_name: string
  entity_id: string
  trigger: string
  status: 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  attempt: number
  max_attempts: number
  error_message: string | null
  fires_at: string
  claimed_by: string | null
  claimed_at: string | null
  created_at: string | null
  completed_at: string | null
  result_json: Record<string, unknown> | null
  transition_history_id: string | null
}

export interface ObservabilityWorkerEventsResponse {
  items: ObservabilityWorkerEventItem[]
  total: number
  limit: number
  offset: number
}

// ---- Analytics types ----

export interface StateDistributionItem { state: string; count: number; percentage: number }
export interface StatusDistribution { active: number; archived: number; deleted: number }
export interface MachineDistributionItem { machine_name: string; count: number }
export interface FailingEntityItem { entity_id: string; failure_count: number; last_failure_at: string }
export interface EntityHealthResponse {
  state_distribution: StateDistributionItem[]
  status_distribution: StatusDistribution
  machine_distribution: MachineDistributionItem[]
  top_failing_entities: FailingEntityItem[]
  terminal_rate: number
  total_entities: number
}

export interface TimeBucketItem { bucket_start: string; bucket_end: string; total: number; failed: number; failure_rate: number }
export interface DurationPercentiles { p50: number | null; p75: number | null; p95: number | null; p99: number | null }
export interface FailingTriggerItem { trigger: string; total: number; failed: number; failure_rate: number }
export interface FailingStateItem { state: string; total: number; failed: number; failure_rate: number }
export interface VolumeTrendItem { bucket_start: string; count: number }
export interface TransitionAnalyticsResponse {
  time_buckets: TimeBucketItem[]
  duration_percentiles: DurationPercentiles
  top_failing_triggers: FailingTriggerItem[]
  top_failing_states: FailingStateItem[]
  volume_trend: VolumeTrendItem[]
}

export interface TimelineStep {
  state: string
  entered_at: string
  exited_at: string | null
  dwell_ms: number | null
  trigger_in: string | null
  trigger_out: string | null
  success: boolean
}
export interface EntityTimelineResponse {
  entity_id: string
  machine_name: string | null
  current_state: string
  steps: TimelineStep[]
  total_dwell_ms: number
  states_visited: number
}

// ---- Entity functions ----

export async function listEntities(params?: {
  machine_name?: string
  state?: string
  status?: string
  include_archived?: boolean
  include_deleted?: boolean
  is_terminal?: boolean
  workflow_status?: 'active' | 'complete' | 'failed'
  created_after?: string
  created_before?: string
  updated_after?: string
  updated_before?: string
  labels?: string
  sort_by?: string
  sort_order?: 'asc' | 'desc'
  limit?: number
  offset?: number
  cursor?: string
  page_size?: number
}): Promise<EntityListResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.state) qs.set('state', params.state)
  if (params?.status) qs.set('status', params.status)
  if (params?.include_archived) qs.set('include_archived', 'true')
  if (params?.include_deleted) qs.set('include_deleted', 'true')
  if (params?.is_terminal != null) qs.set('is_terminal', String(params.is_terminal))
  if (params?.workflow_status) qs.set('workflow_status', params.workflow_status)
  if (params?.created_after) qs.set('created_after', params.created_after)
  if (params?.created_before) qs.set('created_before', params.created_before)
  if (params?.updated_after) qs.set('updated_after', params.updated_after)
  if (params?.updated_before) qs.set('updated_before', params.updated_before)
  if (params?.labels) qs.set('labels', params.labels)
  if (params?.sort_by) qs.set('sort_by', params.sort_by)
  if (params?.sort_order) qs.set('sort_order', params.sort_order)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  if (params?.cursor) qs.set('cursor', params.cursor)
  if (params?.page_size != null) qs.set('page_size', String(params.page_size))
  const query = qs.toString()
  return fetchApi<EntityListResponse>(`/api/v1/entities${query ? `?${query}` : ''}`)
}

export async function getEntityState(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(`/api/v1/entities/${encodeURIComponent(entityId)}/state`)
}

export async function createEntity(
  entityId: string,
  body: CreateEntityRequest
): Promise<CreateEntityResponse> {
  return fetchApi<CreateEntityResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/create`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function processEntityEvent(
  entityId: string,
  body: ProcessEntityEventRequest
): Promise<ProcessEntityEventResponse> {
  return fetchApi<ProcessEntityEventResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/events`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function getEntityHistory(
  entityId: string,
  limit = 50,
  offset = 0
): Promise<TransitionHistoryEntry[]> {
  return fetchApi<TransitionHistoryEntry[]>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history?limit=${limit}&offset=${offset}`
  )
}

export async function deleteEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(`/api/v1/entities/${encodeURIComponent(entityId)}`, {
    method: 'DELETE',
  })
}

export async function archiveEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/archive`,
    { method: 'POST' }
  )
}

export async function restoreEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/restore`,
    { method: 'POST' }
  )
}

export async function purgeEntity(entityId: string): Promise<void> {
  await fetchApi<void>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/purge`,
    { method: 'DELETE' }
  )
}

export async function getAvailableTriggers(
  entityId: string
): Promise<AvailableTriggersResponse> {
  return fetchApi<AvailableTriggersResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/available-triggers`
  )
}

export async function dryRunTransition(
  entityId: string,
  body: DryRunRequest
): Promise<DryRunResponse> {
  return fetchApi<DryRunResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/dry-run`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function getEntityLabels(
  entityId: string
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`
  )
}

export async function setEntityLabels(
  entityId: string,
  labels: Record<string, string>
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`,
    { method: 'PUT', body: JSON.stringify({ labels }) }
  )
}

export async function mergeEntityLabels(
  entityId: string,
  labels: Record<string, string>
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`,
    { method: 'PATCH', body: JSON.stringify({ labels }) }
  )
}

export async function deleteEntityLabel(
  entityId: string,
  key: string
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels/${encodeURIComponent(key)}`,
    { method: 'DELETE' }
  )
}

export async function getHistoryStats(
  entityId: string
): Promise<HistoryStatsResponse> {
  return fetchApi<HistoryStatsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history/stats`
  )
}

export async function purgeHistory(
  entityId: string,
  before: string
): Promise<HistoryPurgeResponse> {
  return fetchApi<HistoryPurgeResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history?before=${encodeURIComponent(before)}`,
    { method: 'DELETE' }
  )
}

export async function getEntitySnapshot(
  entityId: string
): Promise<EntitySnapshotResponse> {
  return fetchApi<EntitySnapshotResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/snapshot`
  )
}

export async function importEntity(
  body: ImportEntityRequest
): Promise<ImportEntityResponse> {
  return fetchApi<ImportEntityResponse>('/api/v1/entities/import', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function bulkCreateEntities(body: {
  items: BulkCreateEntityItem[]
}): Promise<BulkCreateEntitiesResponse> {
  return fetchApi<BulkCreateEntitiesResponse>('/api/v1/entities/bulk/create', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function bulkProcessEvents(body: {
  trigger: string
  entity_ids: string[]
  context?: Record<string, unknown>
  machine_name?: string
}): Promise<BulkProcessEventsResponse> {
  return fetchApi<BulkProcessEventsResponse>('/api/v1/entities/bulk/events', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

// ---- Observability ----

export async function getObservabilitySummary(params?: {
  window_hours?: number
  machine_name?: string
  entity_id?: string
}): Promise<ObservabilitySummaryResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  const query = qs.toString()
  return fetchApi<ObservabilitySummaryResponse>(
    `/api/v1/observability/summary${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityTransitions(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'success' | 'failed'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityTransitionsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityTransitionsResponse>(
    `/api/v1/observability/transitions${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityWorkerEvents(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityWorkerEventsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityWorkerEventsResponse>(
    `/api/v1/observability/worker-events${query ? `?${query}` : ''}`
  )
}

// ---- Analytics ----

export async function getEntityHealth(params?: {
  window_hours?: number
  machine_name?: string
}): Promise<EntityHealthResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  const query = qs.toString()
  return fetchApi<EntityHealthResponse>(
    `/api/v1/observability/entity-health${query ? `?${query}` : ''}`
  )
}

export async function getTransitionAnalytics(params?: {
  window_hours?: number
  machine_name?: string
  bucket_count?: number
}): Promise<TransitionAnalyticsResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.bucket_count != null) qs.set('bucket_count', String(params.bucket_count))
  const query = qs.toString()
  return fetchApi<TransitionAnalyticsResponse>(
    `/api/v1/observability/transition-analytics${query ? `?${query}` : ''}`
  )
}

export async function getEntityTimeline(entityId: string): Promise<EntityTimelineResponse> {
  return fetchApi<EntityTimelineResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/timeline`
  )
}

// ---- Entity Metrics types ----

export interface ErrorPatternItem {
  error_type: string | null
  trigger: string
  source_state: string
  count: number
  last_occurred: string
}

export interface DwellByStateItem {
  state: string
  avg_ms: number
  min_ms: number
  max_ms: number
  visit_count: number
}

export interface FleetComparison {
  entity_failure_rate: number
  fleet_failure_rate: number
  entity_avg_latency_ms: number | null
  fleet_avg_latency_ms: number | null
  latency_percentile_rank: number | null
}

export interface VelocityPoint {
  timestamp: string
  duration_ms: number
}

export interface EntityMetricsResponse {
  entity_id: string
  machine_name: string | null
  health_score: number
  health_status: 'healthy' | 'warning' | 'critical'
  staleness_seconds: number | null
  staleness_label: string
  error_patterns: ErrorPatternItem[]
  recent_failure_rate: number
  latency_percentiles: DurationPercentiles
  dwell_by_state: DwellByStateItem[]
  is_potentially_stuck: boolean
  stuck_state: string | null
  stuck_current_dwell_ms: number | null
  stuck_avg_dwell_ms: number | null
  state_revisits: Record<string, number>
  has_cycles: boolean
  fleet_comparison: FleetComparison | null
  velocity_points: VelocityPoint[]
}

export async function getEntityMetrics(
  entityId: string,
  windowHours = 24
): Promise<EntityMetricsResponse> {
  const qs = new URLSearchParams()
  if (windowHours !== 24) qs.set('window_hours', String(windowHours))
  const query = qs.toString()
  return fetchApi<EntityMetricsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/metrics${query ? `?${query}` : ''}`
  )
}

// ---- Templates ----

/** FSM templates: list and get content (YAML text) */
export interface FsmTemplatesListResponse {
  templates: string[]
}

export async function listFsmTemplates(): Promise<FsmTemplatesListResponse> {
  return fetchApi<FsmTemplatesListResponse>('/api/v1/templates/fsm')
}

/** Fetch FSM template content as YAML text (parse in UI with js-yaml). */
export async function getFsmTemplate(filename: string): Promise<string> {
  const name = filename.endsWith('.yaml') || filename.endsWith('.yml') ? filename : `${filename}.yaml`
  const url = `${getApiBaseUrl()}/api/v1/templates/fsm/${encodeURIComponent(name)}`
  const response = await fetch(url, { headers: authHeaders() })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.text()
}

/** Download all FSM templates as a ZIP file. */
export async function downloadFsmTemplatesZip(): Promise<Blob> {
  return getBlob('/api/v1/templates/fsm/zip')
}
