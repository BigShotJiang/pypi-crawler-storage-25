/**
 * Client-only store for the machine browse folder tree.
 * Persists folders and machine-to-folder assignments in localStorage.
 * Does not fetch machines; tree is built from passed-in machine names.
 */

import { create } from 'zustand'
import type {
  MachineBrowseTreeState,
  MachineBrowseTreeNode,
  MachineFolder,
} from '@/lib/types/machine-browse'
import { MACHINE_BROWSE_STORAGE_KEY } from '@/lib/types/machine-browse'

function loadFromStorage(): MachineBrowseTreeState {
  if (typeof window === 'undefined') {
    return { folders: [], assignments: {} }
  }
  try {
    const raw = window.localStorage.getItem(MACHINE_BROWSE_STORAGE_KEY)
    if (!raw) return { folders: [], assignments: {} }
    const parsed = JSON.parse(raw) as MachineBrowseTreeState
    return {
      folders: Array.isArray(parsed.folders) ? parsed.folders : [],
      assignments: parsed.assignments && typeof parsed.assignments === 'object' ? parsed.assignments : {},
    }
  } catch {
    return { folders: [], assignments: {} }
  }
}

function saveToStorage(state: MachineBrowseTreeState) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(MACHINE_BROWSE_STORAGE_KEY, JSON.stringify(state))
  } catch {
    // ignore
  }
}

/** Build tree roots from folders + assignments + current machine names. Only includes names in machineNames. */
function buildTree(
  machineNames: string[],
  folders: MachineFolder[],
  assignments: Record<string, string | null>,
): MachineBrowseTreeNode[] {
  const nameSet = new Set(machineNames)
  const rootFolders = folders.filter((f) => f.parent_id === null)
  const rootMachineNames = machineNames.filter((name) => {
    const folderId = assignments[name]
    return folderId === null || folderId === undefined || folderId === ''
  })

  const result: MachineBrowseTreeNode[] = []

  // Root folders (sorted by name)
  rootFolders
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach((f) => {
      result.push({
        id: f.id,
        name: f.name,
        kind: 'folder',
        folder_type: 'machine',
        children: buildChildren(f.id, folders, assignments, nameSet),
      })
    })

  // Root machines (sorted)
  rootMachineNames
    .slice()
    .sort((a, b) => a.localeCompare(b))
    .forEach((name) => {
    result.push({
      id: `item-${name}`,
      name,
      kind: 'item',
      folder_type: 'machine',
      item_id: name,
      item_label: name,
    })
  })

  return result
}

function buildChildren(
  parentId: string,
  folders: MachineFolder[],
  assignments: Record<string, string | null>,
  nameSet: Set<string>,
): MachineBrowseTreeNode[] {
  const children: MachineBrowseTreeNode[] = []
  const subfolders = folders.filter((f) => f.parent_id === parentId)
  const machineNamesHere = [...nameSet].filter((name) => assignments[name] === parentId)

  subfolders
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach((f) => {
      children.push({
        id: f.id,
        name: f.name,
        kind: 'folder',
        folder_type: 'machine',
        children: buildChildren(f.id, folders, assignments, nameSet),
      })
    })

  machineNamesHere
    .slice()
    .sort((a, b) => a.localeCompare(b))
    .forEach((name) => {
      children.push({
        id: `item-${name}`,
        name,
        kind: 'item',
        folder_type: 'machine',
        item_id: name,
        item_label: name,
      })
    })

  return children
}

function generateId(): string {
  return `folder-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

interface MachineBrowseStore {
  folders: MachineFolder[]
  assignments: Record<string, string | null>
  expandedIds: Set<string>
  selectedMachineName: string | null
  renamingNodeId: string | null
  error: string | null

  loadFromStorage: () => void
  buildTree: (machineNames: string[]) => MachineBrowseTreeNode[]
  createFolder: (name: string, parentId: string | null) => void
  renameFolder: (folderId: string, name: string) => void
  deleteFolder: (folderId: string) => void
  assignMachineToFolder: (machineName: string, folderId: string) => void
  removeMachineFromFolder: (machineName: string) => void
  toggleExpand: (nodeId: string) => void
  selectMachine: (name: string | null) => void
  startRename: (nodeId: string) => void
  cancelRename: () => void
}

export const useMachineBrowseStore = create<MachineBrowseStore>((set, get) => ({
  folders: [],
  assignments: {},
  expandedIds: new Set<string>(),
  selectedMachineName: null,
  renamingNodeId: null,
  error: null,

  loadFromStorage: () => {
    const state = loadFromStorage()
    set({ folders: state.folders, assignments: state.assignments })
  },

  buildTree: (machineNames) => {
    const { folders, assignments } = get()
    return buildTree(machineNames, folders, assignments)
  },

  createFolder: (name, parentId) => {
    const id = generateId()
    const newFolder: MachineFolder = { id, name, parent_id: parentId }
    set((s) => {
      const next = {
        folders: [...s.folders, newFolder],
        assignments: { ...s.assignments },
        error: null as string | null,
        expandedIds: parentId ? new Set([...s.expandedIds, parentId]) : s.expandedIds,
      }
      saveToStorage({ folders: next.folders, assignments: next.assignments })
      return next
    })
  },

  renameFolder: (folderId, name) => {
    set((s) => {
      const next = {
        ...s,
        renamingNodeId: null as string | null,
        folders: s.folders.map((f) => (f.id === folderId ? { ...f, name } : f)),
      }
      saveToStorage({ folders: next.folders, assignments: next.assignments })
      return next
    })
  },

  deleteFolder: (folderId) => {
    set((s) => {
      const folder = s.folders.find((f) => f.id === folderId)
      const parentId = folder?.parent_id ?? null
      const descendantIds = new Set<string>()
      function collect(pid: string) {
        s.folders.filter((f) => f.parent_id === pid).forEach((f) => {
          descendantIds.add(f.id)
          collect(f.id)
        })
      }
      collect(folderId)
      const nextAssignments = { ...s.assignments }
      for (const [name, fid] of Object.entries(nextAssignments)) {
        if (fid === folderId || (fid && descendantIds.has(fid))) {
          nextAssignments[name] = parentId
        }
      }
      const toRemove = new Set([folderId, ...descendantIds])
      const nextFolders = s.folders.filter((f) => !toRemove.has(f.id))
      saveToStorage({ folders: nextFolders, assignments: nextAssignments })
      return { ...s, folders: nextFolders, assignments: nextAssignments }
    })
  },

  assignMachineToFolder: (machineName, folderId) => {
    set((s) => {
      const next = { ...s, assignments: { ...s.assignments, [machineName]: folderId } }
      saveToStorage({ folders: next.folders, assignments: next.assignments })
      return next
    })
  },

  removeMachineFromFolder: (machineName) => {
    set((s) => {
      const next = { ...s, assignments: { ...s.assignments, [machineName]: null } }
      saveToStorage({ folders: next.folders, assignments: next.assignments })
      return next
    })
  },

  toggleExpand: (nodeId) => {
    set((s) => {
      const next = new Set(s.expandedIds)
      if (next.has(nodeId)) next.delete(nodeId)
      else next.add(nodeId)
      return { expandedIds: next }
    })
  },

  selectMachine: (name) => set({ selectedMachineName: name }),
  startRename: (nodeId) => set({ renamingNodeId: nodeId }),
  cancelRename: () => set({ renamingNodeId: null }),
}))
