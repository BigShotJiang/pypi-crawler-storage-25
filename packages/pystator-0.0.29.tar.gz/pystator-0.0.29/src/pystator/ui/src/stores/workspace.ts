import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import type { FSMConfig, ProcessResponse } from '@/lib/types/fsm'

export interface LastTransition {
  source_state: string
  target_state: string
  trigger: string
}

export interface DiagramHighlightTransition {
  source: string
  target: string
  trigger: string
}

export interface ValidationResult {
  valid: boolean
  errors: string[]
}

const MAX_UNDO = 50

export interface SetConfigOptions {
  replaceHistory?: boolean
}

export type ViewMode = 'diagram' | 'table'

export type TableTabId =
  | 'states'
  | 'variables'
  | 'transition_matrix'
  | 'transition_list'
  | 'state_variables'
  | 'events'
  | 'actions_guards'
  | 'error_policy'

export interface WorkspaceState {
  config: FSMConfig
  past: FSMConfig[]
  future: FSMConfig[]
  sessionState: string
  stateTrail: string[]
  lastTransition: LastTransition | null
  processHistory: ProcessResponse[]
  validationResult: ValidationResult | null
  viewMode: ViewMode
  activeTableTab: TableTabId
  diagramShowGuards: boolean
  diagramShowActions: boolean
  diagramHighlightState: string | null
  diagramHighlightTransition: DiagramHighlightTransition | null
  setConfig: (config: FSMConfig | ((prev: FSMConfig) => FSMConfig), options?: SetConfigOptions) => void
  undo: () => void
  redo: () => void
  clearConfig: () => void
  setViewMode: (mode: ViewMode) => void
  setActiveTableTab: (tab: TableTabId) => void
  setSessionState: (state: string) => void
  setLastTransition: (t: LastTransition | null) => void
  setValidationResult: (r: ValidationResult | null) => void
  setDiagramShowGuards: (v: boolean) => void
  setDiagramShowActions: (v: boolean) => void
  setDiagramHighlightState: (s: string | null) => void
  setDiagramHighlightTransition: (t: DiagramHighlightTransition | null) => void
  addProcessResult: (result: ProcessResponse) => void
  clearProcessHistory: () => void
  resetSession: () => void
  syncSessionFromConfig: () => void
}

const defaultConfig: FSMConfig = {
  meta: { machine_name: 'my_fsm', version: '1.0.0' },
  states: [
    { name: 'start', type: 'initial' },
    { name: 'end', type: 'terminal' },
  ],
  transitions: [{ trigger: 'go', source: 'start', dest: 'end' }],
}

function getInitialState(config: FSMConfig): string {
  const initial = config.states?.find((s) => s.type === 'initial')
  return initial?.name ?? config.states?.[0]?.name ?? ''
}

const initialSessionState = getInitialState(defaultConfig)

export const useWorkspaceStore = create<WorkspaceState>()(
  devtools(
    (set, get) => ({
      config: { ...defaultConfig },
      past: [],
      future: [],
      sessionState: initialSessionState,
      stateTrail: [initialSessionState],
      lastTransition: null,
      processHistory: [],
      validationResult: null,
      viewMode: 'diagram',
      activeTableTab: 'states',
      diagramShowGuards: true,
      diagramShowActions: true,
      diagramHighlightState: null,
      diagramHighlightTransition: null,

      setConfig: (updater, options) => {
        set((s) => {
          const next = typeof updater === 'function' ? updater(s.config) : updater
          if (options?.replaceHistory) {
            return { config: next, validationResult: null, past: [], future: [] }
          }
          const snap = JSON.parse(JSON.stringify(s.config)) as FSMConfig
          const newPast = [...s.past, snap].slice(-MAX_UNDO)
          return {
            config: next,
            validationResult: null,
            past: newPast,
            future: [],
          }
        })
      },

      undo: () => {
        const s = get()
        if (s.past.length === 0) return
        const prev = s.past[s.past.length - 1]
        const newPast = s.past.slice(0, -1)
        const currentSnap = JSON.parse(JSON.stringify(s.config)) as FSMConfig
        set({
          config: prev,
          past: newPast,
          future: [currentSnap, ...s.future],
          validationResult: null,
        })
        get().syncSessionFromConfig()
      },

      redo: () => {
        const s = get()
        if (s.future.length === 0) return
        const next = s.future[0]
        const newFuture = s.future.slice(1)
        const currentSnap = JSON.parse(JSON.stringify(s.config)) as FSMConfig
        set({
          config: next,
          past: [...s.past, currentSnap].slice(-MAX_UNDO),
          future: newFuture,
          validationResult: null,
        })
        get().syncSessionFromConfig()
      },

      clearConfig: () => {
        const s = get()
        const currentSnap = JSON.parse(JSON.stringify(s.config)) as FSMConfig
        const newPast = [...s.past, currentSnap].slice(-MAX_UNDO)
        const cleared = JSON.parse(JSON.stringify(defaultConfig)) as FSMConfig
        set({
          config: cleared,
          past: newPast,
          future: [],
          validationResult: null,
        })
        get().syncSessionFromConfig()
      },

      setViewMode: (mode) => set({ viewMode: mode }),
      setActiveTableTab: (tab) => set({ activeTableTab: tab }),
      setSessionState: (state) => set({ sessionState: state }),
      setLastTransition: (t) => set({ lastTransition: t }),
      setValidationResult: (r) => set({ validationResult: r }),
      setDiagramShowGuards: (v) => set({ diagramShowGuards: v }),
      setDiagramShowActions: (v) => set({ diagramShowActions: v }),
      setDiagramHighlightState: (s) => set({ diagramHighlightState: s }),
      setDiagramHighlightTransition: (t) => set({ diagramHighlightTransition: t }),

      addProcessResult: (result) => {
        set((s) => {
          const history = [result, ...s.processHistory].slice(0, 50)
          if (result.success && result.target_state) {
            return {
              processHistory: history,
              lastTransition: {
                source_state: result.source_state,
                target_state: result.target_state,
                trigger: result.trigger,
              },
              sessionState: result.target_state,
              stateTrail: [...s.stateTrail, result.target_state],
            }
          }
          return { processHistory: history, lastTransition: null }
        })
      },

      clearProcessHistory: () => set({ processHistory: [] }),

      resetSession: () => {
        const { config } = get()
        const initial = getInitialState(config)
        set({ sessionState: initial, stateTrail: [initial], lastTransition: null })
      },

      syncSessionFromConfig: () => {
        const { config } = get()
        const initial = getInitialState(config)
        set({ sessionState: initial, stateTrail: [initial] })
      },
    }),
    { name: 'workspace' },
  ),
)

// Granular selectors
export const selectConfig = (s: WorkspaceState) => s.config
export const selectSetConfig = (s: WorkspaceState) => s.setConfig
export const selectPastLength = (s: WorkspaceState) => s.past.length
export const selectFutureLength = (s: WorkspaceState) => s.future.length
export const selectUndo = (s: WorkspaceState) => s.undo
export const selectRedo = (s: WorkspaceState) => s.redo
export const selectClearConfig = (s: WorkspaceState) => s.clearConfig
export const selectViewMode = (s: WorkspaceState) => s.viewMode
export const selectSetViewMode = (s: WorkspaceState) => s.setViewMode
export const selectActiveTableTab = (s: WorkspaceState) => s.activeTableTab
export const selectSetActiveTableTab = (s: WorkspaceState) => s.setActiveTableTab
export const selectSessionState = (s: WorkspaceState) => s.sessionState
export const selectSetSessionState = (s: WorkspaceState) => s.setSessionState
export const selectStateTrail = (s: WorkspaceState) => s.stateTrail
export const selectLastTransition = (s: WorkspaceState) => s.lastTransition
export const selectSetLastTransition = (s: WorkspaceState) => s.setLastTransition
export const selectProcessHistory = (s: WorkspaceState) => s.processHistory
export const selectValidationResult = (s: WorkspaceState) => s.validationResult
export const selectSetValidationResult = (s: WorkspaceState) => s.setValidationResult
export const selectDiagramShowGuards = (s: WorkspaceState) => s.diagramShowGuards
export const selectSetDiagramShowGuards = (s: WorkspaceState) => s.setDiagramShowGuards
export const selectDiagramShowActions = (s: WorkspaceState) => s.diagramShowActions
export const selectSetDiagramShowActions = (s: WorkspaceState) => s.setDiagramShowActions
export const selectDiagramHighlightState = (s: WorkspaceState) => s.diagramHighlightState
export const selectSetDiagramHighlightState = (s: WorkspaceState) => s.setDiagramHighlightState
export const selectDiagramHighlightTransition = (s: WorkspaceState) => s.diagramHighlightTransition
export const selectSetDiagramHighlightTransition = (s: WorkspaceState) => s.setDiagramHighlightTransition
export const selectAddProcessResult = (s: WorkspaceState) => s.addProcessResult
export const selectClearProcessHistory = (s: WorkspaceState) => s.clearProcessHistory
export const selectResetSession = (s: WorkspaceState) => s.resetSession
export const selectSyncSessionFromConfig = (s: WorkspaceState) => s.syncSessionFromConfig
