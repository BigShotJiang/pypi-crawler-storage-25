"""Squashed schema: machines, entity_states, transition_history, worker_events, DLQ.

Revision ID: 20260401120000
Revises: None
Create Date: 2026-04-01

Replaces the previous linear chain of Alembic revisions with one migration that
creates the current database layout.

**Existing databases** already at the old chain head (schema matches this file's
``upgrade()`` outcome) should run::

    pystator db stamp 20260401120000

instead of ``upgrade``, after replacing migration files. Do not stamp until the
live schema matches (including DLQ in ``public`` when used).

DLQ behavior matches the former ``20260330120000`` revision: create unified
``pystator_dead_letter_queue`` if missing; skip if already unified; migrate
legacy rows if the old worker column layout is present.
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect, text
from sqlalchemy.dialects.postgresql import JSON, JSONB, UUID

revision: str = "20260401120000"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# --- DLQ (public / default schema) -------------------------------------------------

DLQ_TABLE = "pystator_dead_letter_queue"
LEGACY_NAME = f"{DLQ_TABLE}__alembic_legacy_v1"
DLQ_INDEX_COLUMNS = (
    "source_name",
    "reason",
    "status",
    "stage",
    "created_at",
    "expires_at",
)


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def _dlq_table_schema(dialect: str) -> str | None:
    return "public" if dialect == "postgresql" else None


def _parse_json_column(raw: Any) -> dict[str, Any]:
    if isinstance(raw, str):
        return json.loads(raw) if raw else {}
    if raw is None:
        return {}
    return dict(raw)


def _create_dlq_indexes(connection: sa.Connection, dialect: str) -> None:
    if dialect == "postgresql":
        qt = f'"public"."{DLQ_TABLE}"'
    else:
        qt = f'"{DLQ_TABLE}"'
    for col in DLQ_INDEX_COLUMNS:
        idx = f"ix_{DLQ_TABLE}_{col}"
        connection.execute(
            text(f'CREATE INDEX IF NOT EXISTS "{idx}" ON {qt} ("{col}")')
        )


def _create_unified_dlq_table(dialect: str) -> None:
    schema = _dlq_table_schema(dialect)
    if dialect == "postgresql":
        op.create_table(
            DLQ_TABLE,
            sa.Column("record_id", sa.Text(), nullable=False),
            sa.Column("source_name", sa.Text(), nullable=False),
            sa.Column("reason", sa.Text(), nullable=False),
            sa.Column("error_message", sa.Text(), nullable=False, server_default=""),
            sa.Column("error_type", sa.Text(), nullable=False, server_default=""),
            sa.Column("stage", sa.Text(), nullable=False, server_default=""),
            sa.Column(
                "payload",
                JSONB(astext_type=sa.Text()),
                nullable=False,
                server_default=sa.text("'{}'::jsonb"),
            ),
            sa.Column(
                "metadata",
                JSONB(astext_type=sa.Text()),
                nullable=False,
                server_default=sa.text("'{}'::jsonb"),
            ),
            sa.Column("attempt", sa.Integer(), nullable=False, server_default="1"),
            sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
            sa.Column("status", sa.Text(), nullable=False, server_default="pending"),
            sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
            sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
            sa.PrimaryKeyConstraint("record_id", name=f"{DLQ_TABLE}_pkey"),
            schema=schema,
        )
    else:
        op.create_table(
            DLQ_TABLE,
            sa.Column("record_id", sa.Text(), nullable=False),
            sa.Column("source_name", sa.Text(), nullable=False),
            sa.Column("reason", sa.Text(), nullable=False),
            sa.Column("error_message", sa.Text(), nullable=False, server_default=""),
            sa.Column("error_type", sa.Text(), nullable=False, server_default=""),
            sa.Column("stage", sa.Text(), nullable=False, server_default=""),
            sa.Column("payload", sa.Text(), nullable=False, server_default="{}"),
            sa.Column("metadata", sa.Text(), nullable=False, server_default="{}"),
            sa.Column("attempt", sa.Integer(), nullable=False, server_default="1"),
            sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
            sa.Column("status", sa.Text(), nullable=False, server_default="pending"),
            sa.Column("retry_count", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("created_at", sa.Text(), nullable=False),
            sa.Column("updated_at", sa.Text(), nullable=True),
            sa.Column("expires_at", sa.Text(), nullable=True),
            sa.PrimaryKeyConstraint("record_id", name=f"{DLQ_TABLE}_pkey"),
            schema=schema,
        )


def _copy_legacy_dlq_rows(
    connection: sa.Connection,
    dialect: str,
    rows: list[Any],
) -> None:
    if dialect == "postgresql":
        dest = f'"public"."{DLQ_TABLE}"'
        insert_sql = text(f"""
            INSERT INTO {dest} (
                record_id, source_name, reason, error_message, error_type,
                stage, payload, metadata, attempt, max_attempts, status,
                retry_count, created_at, updated_at, expires_at
            ) VALUES (
                :record_id, :source_name, :reason, :error_message, :error_type,
                :stage, CAST(:payload AS jsonb), CAST(:metadata AS jsonb),
                :attempt, :max_attempts, :status, :retry_count,
                :created_at, NULL, NULL
            )
        """)
    else:
        dest = f'"{DLQ_TABLE}"'
        insert_sql = text(f"""
            INSERT OR IGNORE INTO {dest} (
                record_id, source_name, reason, error_message, error_type,
                stage, payload, metadata, attempt, max_attempts, status,
                retry_count, created_at, updated_at, expires_at
            ) VALUES (
                :record_id, :source_name, :reason, :error_message, :error_type,
                :stage, :payload, :metadata, :attempt, :max_attempts, :status,
                :retry_count, :created_at, NULL, NULL
            )
        """)

    for row in rows:
        mapping = dict(row)
        payload = {
            "event_id": mapping["event_id"],
            "entity_id": mapping["entity_id"],
            "trigger": mapping["trigger_name"],
            "context": _parse_json_column(mapping.get("context")),
        }
        meta = _parse_json_column(mapping.get("metadata"))
        params: dict[str, Any] = {
            "record_id": mapping["record_id"],
            "source_name": mapping["machine_name"],
            "reason": mapping["reason"],
            "error_message": mapping.get("error_message") or "",
            "error_type": mapping.get("error_type") or "",
            "stage": mapping.get("stage") or "worker",
            "payload": json.dumps(payload),
            "metadata": json.dumps(meta),
            "attempt": int(mapping["attempt"]),
            "max_attempts": int(mapping["max_attempts"]),
            "status": mapping.get("status") or "pending",
            "retry_count": int(mapping.get("retry_count") or 0),
        }
        created = mapping["created_at"]
        if dialect == "postgresql":
            params["created_at"] = created
        else:
            if hasattr(created, "isoformat"):
                params["created_at"] = created.isoformat()
            else:
                params["created_at"] = str(created)

        connection.execute(insert_sql, params)


def _upgrade_dlq() -> None:
    bind = op.get_bind()
    dialect = bind.dialect.name
    schema = _dlq_table_schema(dialect)
    insp = inspect(bind)

    if not insp.has_table(DLQ_TABLE, schema=schema):
        _create_unified_dlq_table(dialect)
        _create_dlq_indexes(bind, dialect)
        return

    col_names = {c["name"] for c in insp.get_columns(DLQ_TABLE, schema=schema)}
    if "payload" in col_names:
        return

    if "trigger_name" not in col_names or "machine_name" not in col_names:
        return

    if insp.has_table(LEGACY_NAME, schema=schema):
        op.drop_table(LEGACY_NAME, schema=schema)

    op.rename_table(DLQ_TABLE, LEGACY_NAME, schema=schema)

    _create_unified_dlq_table(dialect)

    if dialect == "postgresql":
        leg = f'"public"."{LEGACY_NAME}"'
    else:
        leg = f'"{LEGACY_NAME}"'
    rows = bind.execute(text(f"SELECT * FROM {leg}")).mappings().all()
    _copy_legacy_dlq_rows(bind, dialect, rows)
    _create_dlq_indexes(bind, dialect)
    op.drop_table(LEGACY_NAME, schema=schema)


# --- Main upgrade ------------------------------------------------------------------


def upgrade() -> None:
    schema_name = _schema()
    machines_ref = f"{schema_name + '.' if schema_name else ''}machines.id"

    op.create_table(
        "machines",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("version", sa.String(50), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("strict_mode", sa.String(10), nullable=True),
        sa.Column("config_json", JSON(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("created_by", sa.String(255), nullable=True),
        sa.Column("updated_by", sa.String(255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name", "version", name="uq_machines_name_version"),
        schema=schema_name,
    )

    op.create_table(
        "entity_states",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("machine_id", UUID(as_uuid=True), nullable=True),
        sa.Column("machine_name", sa.String(255), nullable=True),
        sa.Column("current_state", sa.String(255), nullable=False),
        sa.Column("context_json", JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("is_terminal", sa.Boolean(), nullable=True),
        sa.Column(
            "version",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("1"),
        ),
        sa.Column(
            "status",
            sa.String(20),
            nullable=False,
            server_default=sa.text("'active'"),
        ),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("labels_json", sa.JSON(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["machine_id"],
            [machines_ref],
            name="fk_entity_states_machine_id",
            ondelete="SET NULL",
        ),
        sa.UniqueConstraint("entity_id", name="uq_entity_states_entity_id"),
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_entity_id",
        "entity_states",
        ["entity_id"],
        unique=True,
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_machine_id",
        "entity_states",
        ["machine_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_machine_name",
        "entity_states",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_current_state",
        "entity_states",
        ["current_state"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_is_terminal",
        "entity_states",
        ["is_terminal"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_status",
        "entity_states",
        ["status"],
        schema=schema_name,
    )

    op.create_table(
        "transition_history",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("machine_name", sa.String(255), nullable=True),
        sa.Column("source_state", sa.String(255), nullable=False),
        sa.Column("target_state", sa.String(255), nullable=True),
        sa.Column("trigger", sa.String(255), nullable=False),
        sa.Column("success", sa.Boolean(), nullable=False, default=False),
        sa.Column("error_type", sa.String(255), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("actions_executed", JSON(), nullable=True),
        sa.Column("context_snapshot", JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_entity_id",
        "transition_history",
        ["entity_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_machine_name",
        "transition_history",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_created_at",
        "transition_history",
        ["created_at"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_success",
        "transition_history",
        ["success"],
        schema=schema_name,
    )

    op.create_table(
        "worker_events",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("machine_name", sa.String(255), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("trigger", sa.String(255), nullable=False),
        sa.Column("context_json", JSON(), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column(
            "fires_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("claimed_by", sa.String(255), nullable=True),
        sa.Column("claimed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempt", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("idempotency_key", sa.String(255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("result_json", JSON(), nullable=True),
        sa.Column("transition_history_id", UUID(as_uuid=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("idempotency_key", name="uq_worker_events_idempotency_key"),
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_events_poll",
        "worker_events",
        ["status", "fires_at"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_events_entity_id",
        "worker_events",
        ["entity_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_events_machine_name",
        "worker_events",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_events_transition_history_id",
        "worker_events",
        ["transition_history_id"],
        schema=schema_name,
    )

    _upgrade_dlq()


def downgrade() -> None:
    schema_name = _schema()
    bind = op.get_bind()
    dialect = bind.dialect.name
    dlq_schema = _dlq_table_schema(dialect)
    insp = inspect(bind)

    if insp.has_table(DLQ_TABLE, schema=dlq_schema):
        op.drop_table(DLQ_TABLE, schema=dlq_schema)

    op.drop_index(
        "ix_worker_events_transition_history_id",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_events_machine_name",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_events_entity_id",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_events_poll",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_table("worker_events", schema=schema_name)

    op.drop_index(
        "ix_transition_history_success",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_created_at",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_machine_name",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_entity_id",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_table("transition_history", schema=schema_name)

    op.drop_index(
        "ix_entity_states_status",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_index(
        "ix_entity_states_is_terminal",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_index(
        "ix_entity_states_current_state",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_index(
        "ix_entity_states_machine_name",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_index(
        "ix_entity_states_machine_id",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_index(
        "ix_entity_states_entity_id",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_table("entity_states", schema=schema_name)

    op.drop_table("machines", schema=schema_name)
