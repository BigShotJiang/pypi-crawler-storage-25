"""Name and title validation utilities.

Enforces naming conventions for identifiers like machine names.
Allowed characters: lowercase alphanumerics and underscores only.
"""

from __future__ import annotations

import re

# Pattern: lowercase letters, numbers, and underscores only
NAME_PATTERN = re.compile(r"^[a-z0-9_]+$")

# Error message template
NAME_ERROR_MESSAGE = (
    "must contain only lowercase letters (a-z), numbers (0-9), and underscores (_). "
    "No spaces, uppercase letters, or special characters allowed."
)


def validate_name(name: str, field_name: str = "name") -> str:
    """Validate that a name follows the naming convention.

    Args:
        name: The name to validate.
        field_name: The name of the field (for error messages).

    Returns:
        The validated name (normalized to lowercase).

    Raises:
        ValueError: If the name doesn't match the pattern.
    """
    if not isinstance(name, str):
        raise ValueError(f"{field_name} must be a string")

    if not name:
        raise ValueError(f"{field_name} cannot be empty")

    normalized = name.lower().strip()

    if not normalized:
        raise ValueError(f"{field_name} cannot be empty after normalization")

    if not NAME_PATTERN.match(normalized):
        raise ValueError(f"{field_name} {NAME_ERROR_MESSAGE} Got: '{name}'")

    return normalized


def is_valid_name(name: str) -> bool:
    """Check if a name is valid without raising an exception.

    Args:
        name: The name to check.

    Returns:
        True if valid, False otherwise.
    """
    if not isinstance(name, str) or not name:
        return False

    normalized = name.lower().strip()
    return bool(NAME_PATTERN.match(normalized))


def normalize_name(name: str) -> str | None:
    """Normalize a name to the allowed format.

    Attempts to convert invalid names to valid ones by:
    - Converting to lowercase
    - Replacing spaces and hyphens with underscores
    - Removing invalid characters
    - Collapsing consecutive underscores
    - Stripping leading/trailing underscores

    Args:
        name: The name to normalize.

    Returns:
        Normalized name, or None if normalization fails.
    """
    if not isinstance(name, str) or not name:
        return None

    normalized = name.lower().strip()

    # Replace spaces and hyphens with underscores
    normalized = re.sub(r"[\s\-]+", "_", normalized)

    # Remove characters that aren't lowercase letters, numbers, or underscores
    normalized = re.sub(r"[^a-z0-9_]", "", normalized)

    # Collapse consecutive underscores
    normalized = re.sub(r"_+", "_", normalized)

    # Strip leading/trailing underscores
    normalized = normalized.strip("_")

    if not normalized:
        return None

    return normalized
