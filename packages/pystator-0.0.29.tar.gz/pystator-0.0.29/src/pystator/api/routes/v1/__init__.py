"""API v1 routes."""

from __future__ import annotations

from pystator.api.routes.v1 import (
    auth,
    discovery,
    docs,
    entities,
    entities_bulk,
    events,
    machines,
    observability,
    process,
    settings,
    templates,
)

__all__ = [
    "auth",
    "discovery",
    "docs",
    "entities",
    "entities_bulk",
    "events",
    "machines",
    "observability",
    "process",
    "settings",
    "templates",
]
