"""Machine config parsing — the single entry point for all FSM config ingestion.

Consolidates logic previously scattered across:
- config/loader.py (ConfigLoader.load, env substitution, format detection)
- api/routes/v1/machines.py (_config_to_meta)
- db/cli.py (_seed_machines manual meta extraction)
- worker/registry.py (_load_from_yaml raw yaml.safe_load)
- api/services/fsm_service.py (validate_config)
"""

from __future__ import annotations

import json
import os
import re
import warnings
from pathlib import Path
from typing import Any

from pystator.errors import ConfigurationError
from pystator.machine_parser.types import MachineDefinition

# Variable substitution pattern: ${VAR}, ${VAR:-default}, ${VAR:?error}
_VARIABLE_PATTERN = re.compile(r"\$\{([^}:]+)(?::([?-])([^}]*))?\}")


def parse_machine(
    config: dict[str, Any],
    *,
    validate: bool = True,
) -> MachineDefinition:
    """Parse an FSM config dict into a MachineDefinition.

    Steps:
    1. Resolve submachine references (inline expansion).
    2. Optionally validate via ConfigValidator (Pydantic).
    3. Extract canonical meta fields (name, version, description, strict_mode).
    4. Return a frozen MachineDefinition.

    Args:
        config: Raw FSM config dict (with meta, states, transitions).
        validate: If True, run Pydantic schema + semantic validation.

    Returns:
        A validated MachineDefinition.

    Raises:
        ConfigurationError: If validation fails.
        ValueError: If required meta fields are missing or invalid.
    """
    config = dict(config)  # shallow copy to avoid mutating caller's dict

    # Resolve submachines
    config = _resolve_submachines(config)

    # Validate
    if validate:
        _validate_config(config)

    # Extract meta
    meta = config.get("meta", {})
    name = meta.get("machine_name") or meta.get("name", "")
    if not name:
        raise ValueError("Machine config must have meta.machine_name (or meta.name)")

    # Normalize name
    from pystator.shared.name_validator import validate_name

    name = validate_name(name, field_name="machine_name")

    version = str(meta.get("version", "1.0.0"))
    description = meta.get("description")
    strict_raw = meta.get("strict_mode")
    if strict_raw is None:
        strict_mode = True
    elif isinstance(strict_raw, bool):
        strict_mode = strict_raw
    else:
        strict_mode = str(strict_raw).lower() in ("true", "1", "yes")

    states = config.get("states", [])
    transitions = config.get("transitions", [])

    return MachineDefinition(
        name=name,
        version=version,
        config=config,
        states=list(states),
        transitions=list(transitions),
        description=description,
        strict_mode=strict_mode,
    )


def parse_machine_file(
    path: str | Path,
    *,
    validate: bool = True,
    variables: dict[str, str] | None = None,
) -> MachineDefinition:
    """Parse an FSM config from a YAML or JSON file.

    Handles YAML/JSON detection, environment variable substitution,
    submachine resolution, and validation.

    Args:
        path: Path to .yaml, .yml, or .json file.
        validate: If True, run Pydantic schema + semantic validation.
        variables: Extra variables for ${VAR} substitution (in addition to env).

    Returns:
        A validated MachineDefinition.

    Raises:
        FileNotFoundError: If the file does not exist.
        ConfigurationError: If parsing or validation fails.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Machine config file not found: {path}")

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as e:
        raise ConfigurationError(
            f"Failed to read machine config: {e}", path=str(path)
        ) from e

    # Environment variable substitution
    content = _substitute_variables(content, str(path), variables or {})

    # Parse YAML or JSON
    config = _parse_file_content(content, path)

    # Resolve submachines relative to file directory
    config = _resolve_submachines(config, base_path=path.parent)

    # Validate
    if validate:
        _validate_config(config)

    # Extract meta and build definition
    meta = config.get("meta", {})
    name = meta.get("machine_name") or meta.get("name", "")
    if not name:
        raise ValueError(
            f"Machine config at {path} must have meta.machine_name (or meta.name)"
        )

    from pystator.shared.name_validator import validate_name

    name = validate_name(name, field_name="machine_name")

    version = str(meta.get("version", "1.0.0"))
    description = meta.get("description")
    strict_raw = meta.get("strict_mode")
    if strict_raw is None:
        strict_mode = True
    elif isinstance(strict_raw, bool):
        strict_mode = strict_raw
    else:
        strict_mode = str(strict_raw).lower() in ("true", "1", "yes")

    states = config.get("states", [])
    transitions = config.get("transitions", [])

    return MachineDefinition(
        name=name,
        version=version,
        config=config,
        states=list(states),
        transitions=list(transitions),
        description=description,
        strict_mode=strict_mode,
    )


def _resolve_submachines(
    config: dict[str, Any],
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Resolve submachine references in config (if any)."""
    has_submachine = any(s.get("submachine") for s in config.get("states", []))
    if not has_submachine:
        return config
    from pystator.config._submachine import resolve_submachines

    return resolve_submachines(config, base_path)


def _validate_config(config: dict[str, Any]) -> None:
    """Run Pydantic schema + semantic validation if available."""
    try:
        from pystator.config.validator import ConfigValidator

        validator = ConfigValidator()
        errors = validator.validate(config)
        if errors:
            raise ConfigurationError(
                f"Machine config validation failed with {len(errors)} error(s)",
                context={"errors": errors},
            )
    except ImportError:
        warnings.warn(
            "Pydantic not installed; machine config validation skipped. "
            "Install with: pip install pystator[api]",
            stacklevel=3,
        )


def _substitute_variables(
    content: str,
    path: str,
    variables: dict[str, str],
) -> str:
    """Replace ${VAR}, ${VAR:-default}, ${VAR:?error} in file content."""

    def replacer(match: re.Match[str]) -> str:
        var_name = match.group(1)
        modifier = match.group(2)
        default_or_error = match.group(3)

        value = variables.get(var_name) or os.environ.get(var_name)
        if value is not None:
            return value

        if modifier == "-":
            return default_or_error or ""
        elif modifier == "?":
            error_msg = default_or_error or f"Required variable '{var_name}' not set"
            raise ConfigurationError(
                f"Variable substitution error: {error_msg}",
                path=path,
                context={"variable": var_name},
            )
        return ""

    return _VARIABLE_PATTERN.sub(replacer, content)


def _parse_file_content(content: str, path: Path) -> dict[str, Any]:
    """Parse file content as YAML or JSON based on extension."""
    suffix = path.suffix.lower()

    if suffix in (".yaml", ".yml"):
        return _parse_yaml(content, str(path))
    elif suffix == ".json":
        return _parse_json(content, str(path))
    else:
        try:
            return _parse_yaml(content, str(path))
        except ConfigurationError:
            return _parse_json(content, str(path))


def _parse_yaml(content: str, path: str) -> dict[str, Any]:
    try:
        import yaml

        result = yaml.safe_load(content)
        if not isinstance(result, dict):
            raise ConfigurationError(
                "Machine config must be a YAML mapping (dictionary)", path=path
            )
        return result
    except ImportError as e:
        raise ConfigurationError(
            "PyYAML is required for YAML machine configs. "
            "Install with: pip install pyyaml",
            path=path,
        ) from e
    except Exception as e:
        if isinstance(e, ConfigurationError):
            raise
        raise ConfigurationError(f"Invalid YAML syntax: {e}", path=path) from e


def _parse_json(content: str, path: str) -> dict[str, Any]:
    try:
        result = json.loads(content)
        if not isinstance(result, dict):
            raise ConfigurationError(
                "Machine config must be a JSON object (dictionary)", path=path
            )
        return result
    except json.JSONDecodeError as e:
        raise ConfigurationError(f"Invalid JSON syntax: {e}", path=path) from e
