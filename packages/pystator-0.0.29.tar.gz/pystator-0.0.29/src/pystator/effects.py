"""Declarative effect execution for PyStator FSM.

Effects are simple, inline context mutations expressed in YAML config
without requiring Python functions. They are the action-side counterpart
to declarative guard checks.

Supported effects:
    set         -- Set one or more context keys
    timestamp   -- Set a field to current UTC ISO timestamp
    increment   -- Add 1 to a numeric field (default 0)
    decrement   -- Subtract 1 from a numeric field (default 0)
    append      -- Append a value to a list field
    clear       -- Remove a key from context
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


def apply_effect(effect_type: str, params: dict[str, Any], ctx: dict[str, Any]) -> None:
    """Apply a declarative effect to a context dict.

    Args:
        effect_type: One of "set", "timestamp", "increment", "decrement", "append", "clear".
        params: Effect parameters (shape depends on effect_type).
        ctx: Mutable context dict to modify in place.

    Raises:
        ValueError: If effect_type is unknown.
    """
    if effect_type == "set":
        ctx.update(params)

    elif effect_type == "timestamp":
        ctx[params["field"]] = datetime.now(UTC).isoformat()

    elif effect_type == "increment":
        field = params["field"]
        ctx[field] = ctx.get(field, 0) + 1

    elif effect_type == "decrement":
        field = params["field"]
        ctx[field] = ctx.get(field, 0) - 1

    elif effect_type == "append":
        field = params["field"]
        ctx.setdefault(field, []).append(params["value"])

    elif effect_type == "clear":
        ctx.pop(params["field"], None)

    else:
        raise ValueError(f"Unknown effect type: {effect_type}")
