# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.0.29] - 2026-03-31

### Documentation

- Update docs/guides/configuration.md,src/pystator/ui/dev.py,src/pystator/ui/server.py

## [0.0.28] - 2026-03-30

### Documentation

- Update CONTRIBUTING.md

## [0.0.3] - 2026-02-13

