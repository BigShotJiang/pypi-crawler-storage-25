"""GET / + GET /dashboard + GET /opportunities + GET /jobs/{job_id}.

Read-only browse pages backed by the local SQLite cache.

GET / redirects based on config state:
  - configured + scans  → /dashboard
  - configured + no scans → /admin/configurations (the actionable page)
  - not configured → /admin/configurations/new

Dashboard layout (matches CLI muscle memory):
  1. KPI cards (total spend / bytes / unique patterns / dbt-originated)
  2. Bar chart of the 20 most expensive jobs (per-job, NOT grouped)
  3. Table of the same 20 jobs with name + date + cost + issues count.
     Each row is clickable → /jobs/{job_id} for the full SQL + metadata.

Issues count is derived from cached ``Opportunity`` rows; until the
detection engine is wired up in this package the column reads 0 for
every job. That's expected for v1 — see spec 141, "scope = read-only
audit"; LLM solutions and detection-rule replay land later.
"""

from __future__ import annotations

from decimal import Decimal

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.models import ScanRun
from governor_audit.db.session import build_engine, create_all, make_session_factory

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def root(request: Request):
    try:
        load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)
    return RedirectResponse(url="/dashboard", status_code=303)


def _load_scans(limit: int = 20) -> list[dict]:
    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        rows = (
            session.query(ScanRun).order_by(desc(ScanRun.started_at)).limit(limit).all()
        )
        return [
            {
                "id": s.id,
                "started_at": s.started_at,
                "completed_at": s.completed_at,
                "status": s.status,
                "requested_lookback_days": s.requested_lookback_days,
                "fetched_job_count": s.fetched_job_count,
                "opportunity_count": s.opportunity_count,
                "actual_cost_usd": (
                    float(s.actual_cost_usd) if s.actual_cost_usd else 0.0
                ),
                "estimated_cost_usd": (
                    float(s.estimated_cost_usd) if s.estimated_cost_usd else 0.0
                ),
                "dbt_only_filter": s.dbt_only_filter,
                "failure_reason": s.failure_reason,
            }
            for s in rows
        ]


def _format_bytes(n: int | None) -> str:
    """Human-readable bytes (binary units)."""
    if not n:
        return "0 B"
    value = float(n)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PiB"


def _format_duration_ms(ms: int | None) -> str:
    if not ms:
        return "—"
    if ms < 1000:
        return f"{ms} ms"
    s = ms / 1000
    if s < 60:
        return f"{s:.1f} s"
    m = s / 60
    if m < 60:
        return f"{m:.1f} m"
    return f"{m / 60:.1f} h"


def _is_dbt_originated(query: str | None) -> bool:
    """Best-effort dbt detection from query body. Mirrors
    ``governor_audit.scan.information_schema.is_dbt_originated`` but
    operates on the cached ``query`` text only (BigQueryJob doesn't
    persist labels — that's deliberate per FR-042)."""
    return bool(query) and query.lstrip().startswith('/* {"app": "dbt"')


# Statement types that *materialise* data (write a table) — used by the
# manifest-free build/consumption classifier below.
_MATERIALISING_STATEMENT_TYPES = frozenset(
    {
        "CREATE_TABLE_AS_SELECT",
        "CREATE_TABLE",
        "CREATE_VIEW",
        "CREATE_MATERIALIZED_VIEW",
        "MERGE",
        "INSERT",
        "UPDATE",
        "DELETE",
        "TRUNCATE_TABLE",
    }
)


def _classify_workload(query: str | None, statement_type: str | None) -> str:
    """Workload classifier — write vs. read.

    Audit serves users who scan ANY BigQuery project, not just dbt
    shops. The original dbt-aware classifier parked manual writes
    (Airflow MERGEs, scheduled CTASes, ad-hoc CREATE TABLEs) in an
    "other" bucket that rendered as Unclassified — leaving the
    Build / Consumption split blind to most non-dbt build pipelines.

    The simpler model used here:

    * **build** — any statement that materialises data
      (CTAS, MERGE, INSERT, UPDATE, DELETE, TRUNCATE, CREATE VIEW /
      MATERIALIZED VIEW). dbt-origin is no longer required.
    * **consumption** — anything else (SELECTs, BI tools, ad-hoc
      analysts, reverse-ETL exports).

    The ``query`` argument is kept for API stability — the dashboard's
    cost-summary aggregator and the opportunities route both call
    ``_classify_workload(query, statement_type)`` — but it's now unused.
    """
    del query  # kept for API stability; no longer consulted.
    is_writer = (statement_type or "") in _MATERIALISING_STATEMENT_TYPES
    return "build" if is_writer else "consumption"


def _shorten_destination(table: str | None, project_id: str) -> str:
    """Strip the configured project prefix from a fully-qualified table
    name so the dashboard table doesn't waste 18 chars on something the
    user already chose. Returns ``dataset.table`` when the prefix
    matches, the unchanged value otherwise.
    """
    if not table or not project_id:
        return table or "—"
    prefix = f"{project_id}."
    if table.startswith(prefix):
        return table[len(prefix) :]
    return table


def _split_destination(table: str | None, project_id: str) -> tuple[str, str]:
    """Return ``(dataset, object)`` from a BigQuery table identifier."""
    shortened = _shorten_destination(table, project_id)
    if not shortened or shortened == "—":
        return "—", "—"
    parts = [p for p in shortened.split(".") if p]
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "—", parts[0]


def _build_issue_index(session, *, config_id: str) -> tuple[dict[str, int], list, dict]:
    """Walk active ``Opportunity`` rows and return:

    * ``issue_count_by_job_id``: how many findings touch each job_id.
    * ``opps``: the raw Opportunity rows (so callers can reuse the
      single query for type-card aggregation).
    * ``opp_summary``: ``{total_count, total_estimated_savings,
      total_current_cost, type_cards}`` — the shape the dashboard
      partials expect, mirroring governor-web's opportunity dashboard.

    A single opportunity may reference multiple jobs (rules group by
    table); we count every (opp, job) pairing — same as the cloud
    'issues found' surfaces.
    """
    from governor_core.opportunities.models import Opportunity

    # storage_billing_optimization is rendered in its own dashboard
    # panel (per-dataset rows + Action). Excluding it from the query-
    # cost issues summary avoids double-counting and keeps the Active
    # Issues panel about per-job query findings only.
    opps = (
        session.query(Opportunity)
        .filter(Opportunity.status == "active")
        .filter(Opportunity.config_id == config_id)
        .filter(Opportunity.opportunity_type != "storage_billing_optimization")
        .all()
    )
    issue_counts: dict[str, int] = {}
    by_type: dict[str, dict] = {}
    total_savings = 0.0
    total_current_cost = 0.0
    for opp in opps:
        for jid in opp.related_job_ids or []:
            issue_counts[jid] = issue_counts.get(jid, 0) + 1
        type_key = opp.opportunity_type
        bucket = by_type.setdefault(
            type_key,
            {
                "type_key": type_key,
                "label": type_key.replace("_", " ").title(),
                "count": 0,
                "total_cost": 0.0,
                "estimated_savings": 0.0,
            },
        )
        bucket["count"] += 1
        bucket["total_cost"] += float(opp.current_cost_estimate or 0)
        bucket["estimated_savings"] += float(opp.expected_savings or 0)
        total_savings += float(opp.expected_savings or 0)
        total_current_cost += float(opp.current_cost_estimate or 0)
    type_cards = sorted(
        by_type.values(),
        key=lambda c: (c["estimated_savings"], c["count"]),
        reverse=True,
    )
    summary = {
        "total_count": len(opps),
        "total_estimated_savings": total_savings,
        "total_current_cost": total_current_cost,
        "type_cards": type_cards,
    }
    return issue_counts, opps, summary


def _aggregate_totals_and_top_jobs(
    session, *, top_n: int = 20, project_id: str = "", config_id: str
) -> tuple[list[dict], dict, dict]:
    """Walk every cached ``BigQueryJob``. Returns (top_jobs, totals, opp_summary).

    * ``top_jobs``: top N rows ordered by issue_count desc, then by cost —
      so the user sees flagged jobs first, biggest-spender first within
      that group. Used for the bar chart + table.
    * ``totals``: aggregate counters for the KPI cards.
    * ``opp_summary``: rule-grouped breakdown for the Active Issues pane.

    Issue-first ordering matches the user's mental model — "show me what's
    actionable, biggest first" — instead of pure cost ordering which
    buries findings under expensive-but-clean jobs.
    """
    from governor_core.sync.models import BigQueryJob

    jobs = (
        session.query(BigQueryJob)
        .filter(BigQueryJob.config_id == config_id)
        .all()
    )
    issue_counts, opps_for_index, opp_summary = _build_issue_index(
        session, config_id=config_id
    )

    # Build a job_id → best opportunity_id map so the dashboard's bar
    # chart can deep-link to /opportunities/{id} instead of /jobs/{id}.
    # Picks the highest-severity issue for each job; falls back to any
    # active opportunity that lists this job in ``related_job_ids``. The
    # five issue rules outrank the SQL-rewrite suggestion rules so the
    # user lands on the most cost-impacting finding for that job.
    from governor_audit.scan.categorization import ISSUE_RULE_TYPES
    from governor_core.opportunities.models import Opportunity

    all_opps_for_jobs = (
        session.query(Opportunity)
        .filter(
            Opportunity.status == "active",
            Opportunity.config_id == config_id,
            Opportunity.opportunity_type != "storage_billing_optimization",
        )
        .all()
    )
    # Each entry: (priority_tuple, opportunity_id). max() over the
    # priority picks the best. Issues outrank improvements; within a
    # tier, higher severity wins.
    opportunity_by_job: dict[str, tuple[tuple[int, int], str]] = {}
    for opp in all_opps_for_jobs:
        is_issue = 1 if opp.opportunity_type in ISSUE_RULE_TYPES else 0
        priority = (is_issue, int(opp.severity_score or 0))
        for jid in opp.related_job_ids or []:
            current = opportunity_by_job.get(jid)
            if current is None or priority > current[0]:
                opportunity_by_job[jid] = (priority, opp.id)

    grand_total_cost = Decimal("0")
    grand_total_bytes = 0
    grand_total_jobs = 0
    build_cost = Decimal("0")
    consumption_cost = Decimal("0")
    unique_hashes: set[str] = set()
    dbt_hashes: set[str] = set()
    dbt_job_count = 0

    for job in jobs:
        grand_total_jobs += 1
        cost = job.total_cost or Decimal("0")
        grand_total_cost += cost
        grand_total_bytes += job.total_bytes_processed or 0

        # Build vs consumption split — mirrors governor-web's
        # `_cost_summary.html` cards. ``_classify_workload`` now
        # returns only 'build' or 'consumption' (any write is a build,
        # everything else is consumption — see the function docstring
        # for why we dropped dbt-origin gating).
        kind = _classify_workload(job.query, job.statement_type)
        if kind == "build":
            build_cost += cost
        else:
            consumption_cost += cost

        qh = job.query_hashes or {}
        hash_key = (
            qh.get("normalized_literals") if isinstance(qh, dict) else None
        ) or f"job:{job.job_id}"
        unique_hashes.add(hash_key)

        if _is_dbt_originated(job.query):
            dbt_job_count += 1
            dbt_hashes.add(hash_key)

    # Strict cost-desc. The bar chart is literally labelled "Top N
    # Spenders" so it must rank by cost; the issues table reads the same
    # ordering so an expensive job with one issue outranks a $0 job with
    # two. Issue count is shown as a column, not a sort key.
    top_jobs_raw = sorted(
        jobs,
        key=lambda j: j.total_cost or Decimal("0"),
        reverse=True,
    )[:top_n]

    formatted: list[dict] = []
    for job in top_jobs_raw:
        cost = job.total_cost or Decimal("0")
        share_pct = float((cost / grand_total_cost) * 100) if grand_total_cost else 0.0
        # The bar chart wants a short label — destination_table is the most
        # useful identifier when present; fall back to job_id tail.
        if job.destination_table:
            short_label = job.destination_table.split(".")[-1]
        else:
            short_label = job.job_id.split(":")[-1][-32:]
        destination_dataset, destination_object = _split_destination(
            job.destination_table, project_id
        )
        formatted.append(
            {
                "job_id": job.job_id,
                "short_label": short_label,
                "destination_table": job.destination_table or "—",
                "destination_short": _shorten_destination(
                    job.destination_table, project_id
                ),
                "destination_dataset": destination_dataset,
                "destination_object": destination_object,
                "statement_type": job.statement_type or "",
                "workload_kind": _classify_workload(job.query, job.statement_type),
                "creation_time": job.creation_time,
                "cost_usd": float(cost),
                "cost_share_pct": share_pct,
                "bytes_processed": job.total_bytes_processed or 0,
                "bytes_processed_human": _format_bytes(job.total_bytes_processed),
                "slot_time_ms": job.total_slot_ms or 0,
                "slot_time_human": _format_duration_ms(job.total_slot_ms),
                "is_dbt_originated": _is_dbt_originated(job.query),
                "issue_count": issue_counts.get(job.job_id, 0),
                "user_email": job.user_email or "",
                # Best opportunity for this job (highest-severity issue,
                # falling back to any improvement that lists this job).
                # Powers deep-links from the bar chart and the cost-driver
                # table to /opportunities/{id} instead of /jobs/{id}.
                "opportunity_id": (
                    opportunity_by_job[job.job_id][1]
                    if job.job_id in opportunity_by_job
                    else None
                ),
            }
        )

    totals = {
        "total_jobs": grand_total_jobs,
        "total_cost_usd": float(grand_total_cost),
        "build_spend": float(build_cost),
        "consumption_spend": float(consumption_cost),
        "total_bytes_processed": grand_total_bytes,
        "total_bytes_processed_human": _format_bytes(grand_total_bytes),
        "unique_query_patterns": len(unique_hashes),
        "dbt_originated_count": dbt_job_count,
        "dbt_originated_pattern_count": len(dbt_hashes),
        "total_issues": opp_summary["total_count"],
        # "Flagged spend" = current_cost summed across active opps. This
        # is measured (job-cost from INFORMATION_SCHEMA), not heuristic.
        "flagged_spend": opp_summary["total_current_cost"],
    }
    return formatted, totals, opp_summary


_DASHBOARD_PAGE_SIZE = 10
_BAR_CHART_TOP_N = 20


def _build_storage_panel(session, project_id: str, *, config_id: str) -> list[dict]:
    """Return one dashboard-row per active ``storage_billing_optimization``
    opportunity, sorted by monthly savings descending.

    Each row carries everything the partial needs to render a clickable
    summary and an inline-revealable ``ALTER SCHEMA`` snippet. The SQL
    is built server-side so the copy button can read a clean string
    without escaping concerns.
    """
    from governor_core.opportunities.models import Opportunity

    opps = (
        session.query(Opportunity)
        .filter(
            Opportunity.opportunity_type == "storage_billing_optimization",
            Opportunity.status == "active",
            Opportunity.config_id == config_id,
        )
        .all()
    )

    rows: list[dict] = []
    for opp in opps:
        evidence = opp.evidence_snapshot or {}
        dataset_name = evidence.get("dataset_name") or ""
        if not dataset_name and opp.affected_table:
            # Fallback — affected_table is "<project>.<dataset>"
            parts = opp.affected_table.split(".", 1)
            dataset_name = parts[1] if len(parts) == 2 else opp.affected_table
        full_dataset = f"{project_id}.{dataset_name}" if dataset_name else (
            opp.affected_table or ""
        )

        alter_sql = (
            f"ALTER SCHEMA `{full_dataset}`\n"
            f"SET OPTIONS(storage_billing_model = 'PHYSICAL');"
        )

        rows.append(
            {
                "opportunity_id": opp.id,
                "dataset_full": full_dataset,
                "dataset_short": dataset_name or full_dataset,
                "table_count": evidence.get("table_count", 0),
                "current_cost_monthly": float(evidence.get("logical_cost_monthly") or 0),
                "proposed_cost_monthly": float(
                    evidence.get("physical_cost_monthly") or 0
                ),
                "monthly_savings": float(evidence.get("monthly_savings") or 0),
                "annual_savings": float(evidence.get("annual_savings") or 0),
                "compression_ratio": evidence.get("compression_ratio") or 0,
                "savings_pct": evidence.get("savings_percentage") or 0,
                "current_billing_model": evidence.get(
                    "current_billing_model", "LOGICAL"
                ),
                "alter_sql": alter_sql,
            }
        )

    rows.sort(key=lambda r: r["monthly_savings"], reverse=True)
    return rows

# Sort key catalogue. Maps the ``?sort=`` query param to a function that
# extracts the comparison key from a formatted row dict. Mirrors
# governor-web's $driverSort enum on the cost-drivers table.
_SORT_KEYS = {
    "destination": lambda r: (r.get("destination_table") or "").lower(),
    "dataset": lambda r: (r.get("destination_dataset") or "").lower(),
    "object": lambda r: (r.get("destination_object") or "").lower(),
    "spend": lambda r: r.get("cost_usd") or 0,
    "bytes": lambda r: r.get("bytes_processed") or 0,
    "slot_time": lambda r: r.get("slot_time_ms") or 0,
    "issues": lambda r: r.get("issue_count") or 0,
    "workload": lambda r: r.get("workload_kind") or "",
    "source": lambda r: 0 if r.get("is_dbt_originated") else 1,
    "run_at": lambda r: r.get("creation_time") or 0,
}
_DEFAULT_SORT = "spend"
_DEFAULT_DIRECTION = "desc"


def _normalise_sort(sort: str | None, direction: str | None) -> tuple[str, str]:
    """Clamp the user-supplied query params to the allow-list."""
    s = sort if sort in _SORT_KEYS else _DEFAULT_SORT
    d = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION
    return s, d


def _apply_sort(rows: list[dict], sort_by: str, direction: str) -> list[dict]:
    key_fn = _SORT_KEYS[sort_by]
    return sorted(rows, key=key_fn, reverse=(direction == "desc"))


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    scan_status: str | None = None,
    scan_detail: str | None = None,
):
    """Dashboard is gated on the cache having at least one job.

    ``?page=N`` server-paginates the issue-only Top Cost Drivers table
    at 10 rows per page; ``?sort=spend&direction=desc`` powers the
    click-to-sort headers. Defaults to spend / desc.

    The table is restricted to jobs with ``issue_count > 0`` per the
    user's ask — "Top Cost Drivers with Issues Found" only shows rows
    the detection engine flagged. The bar chart is unaffected (it's
    labelled "Top 20 Spenders", so it ranks every job by cost).
    """
    from governor_core.utils.pagination import PaginationContext

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by, sort_dir = _normalise_sort(sort, direction)

    # Scope every read to the active (project, region) — without this
    # the SQLite cache merges every project ever scanned. See
    # ``governor_audit.scan.sentinels.config_id_for`` for the hash.
    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Bar chart: top 20 by cost (always cost-desc, never paginated).
        chart_jobs, totals, opp_summary = _aggregate_totals_and_top_jobs(
            session,
            top_n=_BAR_CHART_TOP_N,
            project_id=config.gcp_project_id,
            config_id=active_config_id,
        )
        # Table: every job, then filter to issues > 0 + apply sort.
        all_jobs, _t, _o = _aggregate_totals_and_top_jobs(
            session,
            top_n=totals["total_jobs"] or 1,
            project_id=config.gcp_project_id,
            config_id=active_config_id,
        )
        storage_panel = _build_storage_panel(
            session, config.gcp_project_id, config_id=active_config_id
        )

    if totals["total_jobs"] == 0:
        return RedirectResponse(url="/admin/configurations", status_code=303)

    issue_jobs = [j for j in all_jobs if j["issue_count"] > 0]
    issue_jobs = _apply_sort(issue_jobs, sort_by, sort_dir)

    page = max(1, page)
    pagination = PaginationContext(
        page=page,
        page_size=_DASHBOARD_PAGE_SIZE,
        total_items=len(issue_jobs),
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = PaginationContext(
            page=page,
            page_size=_DASHBOARD_PAGE_SIZE,
            total_items=len(issue_jobs),
        )

    start = (page - 1) * _DASHBOARD_PAGE_SIZE
    paged_jobs = issue_jobs[start : start + _DASHBOARD_PAGE_SIZE]

    chart_jobs_payload = [
        {
            "job_id": j["job_id"],
            "label": j["short_label"],
            "cost": j["cost_usd"],
            "bytes_human": j["bytes_processed_human"],
            "issues": j["issue_count"],
            "opportunity_id": j["opportunity_id"],
        }
        for j in chart_jobs
    ]

    return templates.TemplateResponse(
        request,
        "dashboard/index.html",
        {
            "title": "Dashboard — Governor Audit",
            "config": config,
            "chart_jobs": chart_jobs,
            "chart_jobs_payload": chart_jobs_payload,
            "table_jobs": paged_jobs,
            "totals": totals,
            "opportunities": opp_summary,
            "storage_panel": storage_panel,
            "pagination": pagination,
            "sort_by": sort_by,
            "sort_dir": sort_dir,
            "scan_banner": _scan_banner_for_dashboard(scan_status, scan_detail),
        },
    )


def _scan_banner_for_dashboard(
    scan_status: str | None, scan_detail: str | None
) -> dict | None:
    """Mirrors the banner schema from configurations.detail. Only the
    success case lands on the dashboard; the others stay on /admin/
    configurations, but we keep the mapping symmetric for safety."""
    if not scan_status:
        return None
    mapping = {
        "succeeded": ("success", "Scan succeeded."),
        "lock_held": ("warning", "Another scan is already running."),
        "bad_args": ("error", "Invalid scan parameters."),
        "error": ("error", "Scan failed."),
    }
    level, headline = mapping.get(scan_status, ("info", "Scan finished."))
    return {"level": level, "headline": headline, "detail": scan_detail or ""}


@router.get("/jobs/{job_id:path}", response_class=HTMLResponse)
def job_detail(request: Request, job_id: str):
    """Detail page for a single cached BigQuery job.

    Renders the full SQL, destination, cost, slot time, and any
    ``performance_insights`` BigQuery returned. The job_id can contain
    colons (``project:region.id``) so we use the ``:path`` converter.
    """
    from governor_core.sync.models import BigQueryJob

    templates = request.app.state.templates
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_core.opportunities.models import Opportunity

    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Filter on (job_id, active config) — old jobs from previously
        # audited projects share the same SQLite cache, so we 404 them
        # rather than render foreign data when the active project no
        # longer matches.
        job = (
            session.query(BigQueryJob)
            .filter(
                BigQueryJob.job_id == job_id,
                BigQueryJob.config_id == active_config_id,
            )
            .first()
        )
        if not job:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not cached")

        # Issues attached to this job: any active Opportunity whose
        # related_job_ids array contains this job_id. We hydrate in
        # Python because SQLite's JSON containment isn't portable.
        opps_for_job = []
        for opp in (
            session.query(Opportunity)
            .filter(
                Opportunity.status == "active",
                Opportunity.config_id == active_config_id,
            )
            .all()
        ):
            if job.job_id in (opp.related_job_ids or []):
                opps_for_job.append(
                    {
                        "id": opp.id,
                        "type": opp.opportunity_type,
                        "display_name": opp.opportunity_type.replace("_", " ").title(),
                        "affected_table": opp.affected_table,
                        "severity": opp.severity_score,
                        "current_cost": float(opp.current_cost_estimate or 0),
                        "expected_savings": float(opp.expected_savings or 0),
                        "explanation": opp.explanation,
                    }
                )
        opps_for_job.sort(key=lambda o: o["severity"], reverse=True)

        cost = job.total_cost or Decimal("0")
        bytes_processed = job.total_bytes_processed or 0
        bytes_billed = job.total_bytes_billed or 0
        slot_ms = job.total_slot_ms or 0
        duration_ms = job.duration_ms or 0
        qh = job.query_hashes or {}
        hash_value = qh.get("normalized_literals") if isinstance(qh, dict) else None

        ctx = {
            "job_id": job.job_id,
            "user_email": job.user_email or "—",
            "creation_time": job.creation_time,
            "start_time": job.start_time,
            "end_time": job.end_time,
            "destination_table": job.destination_table or "—",
            "destination_short": _shorten_destination(
                job.destination_table, config.gcp_project_id
            ),
            "statement_type": job.statement_type or "—",
            "workload_kind": _classify_workload(job.query, job.statement_type),
            "job_state": job.job_state,
            "job_type": job.job_type or "—",
            "cache_hit": bool(job.cache_hit),
            "query": job.query or "",
            "cost_usd": float(cost),
            "bytes_processed": bytes_processed,
            "bytes_billed": bytes_billed,
            "slot_time_ms": slot_ms,
            "duration_ms": duration_ms,
            "referenced_tables": job.referenced_tables or [],
            "performance_insights": job.performance_insights or {},
            "query_hash": hash_value,
            "is_dbt_originated": _is_dbt_originated(job.query),
        }

    return templates.TemplateResponse(
        request,
        "dashboard/job_detail.html",
        {
            "title": f"Job — {ctx['destination_table']}",
            "config": config,
            "job": ctx,
            "issues": opps_for_job,
        },
    )


# /opportunities lives in packages/audit/src/governor_audit/web/routes/
# opportunities.py (spec 142) — kept here previously as a stub.
