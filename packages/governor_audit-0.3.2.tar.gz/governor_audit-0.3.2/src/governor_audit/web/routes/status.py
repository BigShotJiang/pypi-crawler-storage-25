"""GET /healthz + GET /api/status."""

from __future__ import annotations

import json as _json

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.models import ScanRun
from governor_audit.db.session import build_engine, create_all, make_session_factory
from governor_audit.version import get_app_version

router = APIRouter()


@router.get("/healthz")
def healthz() -> JSONResponse:
    """Liveness probe. Used by `governor-audit start` to verify the
    server came up. The loopback-only middleware on the app guards
    against non-localhost callers.
    """
    return JSONResponse({"status": "ok", "version": get_app_version()})


@router.get("/api/status")
def api_status() -> JSONResponse:
    """Read-only JSON endpoint mirroring `governor-audit status --json`."""
    try:
        config = load_config()
    except ConfigNotFoundError:
        return JSONResponse({
            "configured": False,
            "version": get_app_version(),
        })

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        last = (
            session.query(ScanRun)
            .order_by(ScanRun.started_at.desc())
            .first()
        )

    payload = {
        "configured": True,
        "version": get_app_version(),
        "gcp_project_id": config.gcp_project_id,
        "bigquery_region": config.bigquery_region,
        "scan_defaults": {
            "lookback_days": config.scan_defaults.lookback_days,
            "dbt_only": config.scan_defaults.dbt_only,
        },
        "last_scan": (
            {
                "id": last.id,
                "started_at": last.started_at.isoformat(),
                "completed_at": (
                    last.completed_at.isoformat() if last.completed_at else None
                ),
                "status": last.status,
                "fetched_job_count": last.fetched_job_count,
                "opportunity_count": last.opportunity_count,
                "actual_cost_usd": (
                    float(last.actual_cost_usd) if last.actual_cost_usd else None
                ),
                "dbt_only_filter": last.dbt_only_filter,
            }
            if last
            else None
        ),
    }
    return JSONResponse(payload)
