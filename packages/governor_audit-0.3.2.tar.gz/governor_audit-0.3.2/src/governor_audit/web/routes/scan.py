"""POST /admin/scan — kick off a scan from the UI.

Synchronous: the request blocks until the scan completes (or fails), then
303s back to /admin/configurations (where the scan form lives). The
dashboard is gated on having at least one successful scan; before that
it just redirects here. The scan happens in-process under the same
scan-lock the CLI uses — concurrent scans (UI vs. CLI) get rejected with
``ScanLockHeldError`` exactly as they would from the terminal.

For large scans the request can take 30s–2min. Browsers typically don't
time out at the HTTP layer that fast, but if the user closes the tab
mid-flight the scan continues to completion (uvicorn doesn't cancel the
worker thread on disconnect for sync handlers). We accept this trade-off
for v1 because:

  * Scans of the recommended-default windows (≤7 days) finish in seconds
  * Cost caps fail fast at the dry-run step (~1s) before any work happens
  * The user wanted parity with the cloud's button-driven UX

A future revision could move scans to a background task with poll-based
progress, but only if real-world pilots show ≥30s waits as a problem.
"""

from __future__ import annotations

import logging
from typing import Annotated
from urllib.parse import quote

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
    session_scope,
)
from governor_audit.scan.bigquery_client import build_default_client
from governor_audit.scan.lock import ScanLockHeldError, acquire_scan_lock
from governor_audit.scan.orchestrator import run_scan

logger = logging.getLogger("governor_audit.web.scan")

router = APIRouter()


# Allowed lookback values for the dropdown. Matches the BigQuery
# INFORMATION_SCHEMA retention boundary (180 days). Anything outside
# this set is rejected with a friendly error.
_ALLOWED_DAYS = (1, 7, 30, 180)


def _redirect_after_scan(*, status: str, detail: str = "") -> RedirectResponse:
    """303 with ``?scan_status=...&scan_detail=...``. Success lands on
    /dashboard (so the user immediately sees the cost drivers); failures
    return to /admin/configurations where the form + error context live."""
    qs = f"scan_status={status}"
    if detail:
        qs += f"&scan_detail={quote(detail, safe='')}"
    target = "/dashboard" if status == "succeeded" else "/admin/configurations"
    return RedirectResponse(url=f"{target}?{qs}", status_code=303)


@router.post("/admin/scan", response_class=HTMLResponse)
def scan_submit(
    request: Request,
    days: Annotated[int, Form()],
    dbt_only: Annotated[bool, Form()] = False,
    full_refresh: Annotated[bool, Form()] = False,
) -> HTMLResponse:
    if days not in _ALLOWED_DAYS:
        return _redirect_after_scan(
            status="bad_args",
            detail=(
                f"Lookback must be one of {sorted(_ALLOWED_DAYS)} days. "
                f"Got {days}."
            ),
        )

    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    bq_client = build_default_client(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
    )

    engine = build_engine()
    create_all(engine)
    session_factory = make_session_factory(engine)

    logger.info(
        "UI scan submit: project=%s region=%s days=%d dbt_only=%s full_refresh=%s",
        config.gcp_project_id,
        config.bigquery_region,
        days,
        dbt_only,
        full_refresh,
    )

    try:
        with acquire_scan_lock():
            with session_scope(session_factory) as session:
                result = run_scan(
                    config=config,
                    session=session,
                    bq_client=bq_client,
                    lookback_days=days,
                    dbt_only=dbt_only,
                )
    except ScanLockHeldError as exc:
        return _redirect_after_scan(
            status="lock_held",
            detail=str(exc),
        )
    except Exception as exc:  # noqa: BLE001
        # BigQuery 403 / region typo / network — surface verbatim. The
        # ADC probe catches most of this at init time, but the actual
        # JOBS_BY_PROJECT query has its own permission check.
        logger.exception("UI scan failed")
        return _redirect_after_scan(
            status="error",
            detail=str(exc)[:500],
        )

    detail = (
        f"Fetched {result.fresh_job_count} jobs "
        f"({result.dbt_originated_job_count} dbt-originated, "
        f"{result.unique_query_hash_count} unique patterns), "
        f"actual cost ${result.cost_usd:.4f}."
    )
    if result.lookback_clamp_warning:
        detail = f"{result.lookback_clamp_warning} {detail}"
    return _redirect_after_scan(status="succeeded", detail=detail)
