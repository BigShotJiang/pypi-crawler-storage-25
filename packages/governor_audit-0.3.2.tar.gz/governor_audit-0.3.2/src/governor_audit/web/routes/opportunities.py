"""GET /opportunities — list every active Opportunity in the local cache.
GET /opportunities/{id} — drill-down detail page.

Read-only mirror of governor-web's `/opportunities` UX, scoped to
audit's single (project, region). The list page vendors the cloud's
templates 1:1 (summary cards, filter controls, table, pagination) and
this route hydrates the data shape those templates expect:
``opportunities`` (per-row dict), ``signals`` (filter state), ``summary``
(aggregate stats), ``available_types``,
``pagination`` (with ``query_string_without_page`` /
``query_string_without_sort_or_page``), and ``local_runtime_mode=True``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import desc

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
)
from governor_core.opportunities.catalog import get_detection_rule_catalog
from governor_core.opportunities.models import Opportunity
from governor_core.sync.models import BigQueryJob

logger = logging.getLogger("governor_audit.web.opportunities")
router = APIRouter()

_PAGE_SIZE = 10
# Default sort flipped from "savings" to "cost" in v0.0.16. Audit no
# longer displays a savings column at all (the existing governor-core
# rules emit hardcoded-percentage savings figures we refuse to surface;
# audit's own rules persist 0; only a real dry-run could justify a
# number, and audit doesn't run dry-runs).
_DEFAULT_SORT = "cost"
_DEFAULT_DIRECTION = "desc"
_VALID_SORTS = (
    "project",
    "dataset",
    "table",
    "type",
    "workload",
    "cost",
    "age",
    "state",
)


# ── Pagination wrapper — adds the query_string_without_* properties the
# cloud templates use to preserve filter state across page links ────────


@dataclass
class AuditPaginationContext:
    page: int
    page_size: int
    total_items: int
    base_query_pairs: list[tuple[str, str]] = field(default_factory=list)
    sort: str | None = None
    direction: str | None = None

    @property
    def total_pages(self) -> int:
        if self.total_items == 0:
            return 1
        return (self.total_items + self.page_size - 1) // self.page_size

    @property
    def has_prev(self) -> bool:
        return self.page > 1

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages

    @property
    def start_index(self) -> int:
        if self.total_items == 0:
            return 0
        return (self.page - 1) * self.page_size + 1

    @property
    def end_index(self) -> int:
        return min(self.page * self.page_size, self.total_items)

    def page_range(self, window: int = 2) -> list[int]:
        start = max(1, self.page - window)
        end = min(self.total_pages, self.page + window)
        return list(range(start, end + 1))

    @property
    def query_string_without_page(self) -> str:
        pairs = list(self.base_query_pairs)
        if self.sort:
            pairs.append(("sort", self.sort))
        if self.direction:
            pairs.append(("direction", self.direction))
        return urlencode(pairs)

    @property
    def query_string_without_sort_or_page(self) -> str:
        return urlencode(self.base_query_pairs)


# ── Severity bucket helper ─────────────────────────────────────────────


def _severity_bucket(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 20:
        return "medium"
    return "low"


_BUCKET_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


# ── Workload classification ─────────────────────────────────────────────
# Reuse audit's existing manifest-free build/consumption classifier so the
# Workload column doesn't render every row as "Unclassified". The helper
# inspects the job's SQL + statement_type to decide build vs consumption.


def _workload_kind_from_job(job: BigQueryJob | None) -> str | None:
    if job is None:
        return None
    if job.workload_kind:
        return job.workload_kind
    # Fall back to live classification when the column wasn't populated
    # at scan time (rows from earlier audit versions).
    from governor_audit.web.routes.findings import _classify_workload

    kind = _classify_workload(job.query, job.statement_type)
    # Map "other" → None so the template's local_runtime_mode branch
    # renders "Unclassified" only when classification really failed.
    return kind if kind in ("build", "consumption") else None


# ── Per-row view dict — matches the cloud template's expected shape ─────


def _split_table_identifier(table: str | None) -> tuple[str, str]:
    """Return ``(dataset, object)`` from a BigQuery table identifier."""
    if not table:
        return "—", "—"
    parts = [p for p in table.split(".") if p]
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "—", parts[0]


def _to_row(
    opp: Opportunity,
    *,
    project_name: str,
    job: BigQueryJob | None,
) -> dict[str, Any]:
    from governor_audit.scan.categorization import (
        ISSUE_RULE_TYPES,
    )

    severity = int(opp.severity_score or 0)
    affected_dataset, affected_object = _split_table_identifier(opp.affected_table)
    # Improvements were attached at scan time under
    # ``evidence_snapshot["_improvements"]`` (deduped by rule_type
    # downstream of detection.py). Surface a count + a "has-template"
    # count so the table can show "N suggestions, K with diffs".
    improvements = (opp.evidence_snapshot or {}).get("_improvements") or []
    improvements_with_diff = sum(
        1 for imp in improvements if imp.get("template_id")
    )
    # ``is_issue`` distinguishes the five real cost / performance issue
    # rules (slot_contention, join_explosion, partition_pruning,
    # shuffle_spill, storage_billing_optimization) from the SQL-rewrite
    # suggestion rules. Improvement-only opportunities have no issue to
    # show in the listing's "Issue" column and present their own
    # template_result as a single suggestion card on the detail page.
    is_issue = opp.opportunity_type in ISSUE_RULE_TYPES
    template_result = (opp.evidence_snapshot or {}).get("_template_result") or None
    has_self_template = bool(
        template_result
        and template_result.get("before_content")
        and template_result.get("after_content")
        and template_result.get("before_content") != template_result.get("after_content")
    )
    return {
        "id": opp.id,
        "config_id": opp.config_id,
        "project_name": project_name,
        "affected_table": opp.affected_table,
        "affected_dataset": affected_dataset,
        "affected_object": opp.dbt_model_name or affected_object,
        "dbt_model_name": opp.dbt_model_name,
        "opportunity_type": opp.opportunity_type,
        "is_issue": is_issue,
        "has_self_template": has_self_template,
        "query_workload_kind": _workload_kind_from_job(job),
        "query_cost_value": float(opp.current_cost_estimate or 0),
        "improvements_count": len(improvements),
        "improvements_with_diff_count": improvements_with_diff,
        # Audit refuses to surface a savings number — see _DEFAULT_SORT
        # comment above. The cloud rules in governor-core emit
        # hardcoded-percentage figures (slot_contention = 20 %,
        # join_explosion etc.) we don't trust enough to display, and
        # audit has no dry-run pipeline that could justify a real
        # number. Always None → table cell renders "—".
        "possible_savings_value": None,
        "occurrence_count": len(list(opp.related_job_ids or [])) or 1,
        "last_detected_at": opp.updated_at,
        "created_at": opp.created_at,
        "severity_score": severity,
        "severity_bucket": _severity_bucket(severity),
        "evidence_snapshot": opp.evidence_snapshot or {},
        "explanation": opp.explanation or "",
        "related_job_ids": list(opp.related_job_ids or []),
        # Cloud-only fields the audit templates reference but never set:
        "solution_job_status": None,
        "solution_risk_level": None,
        "recommendation_state": None,
        "optimized_cost_value": None,
        "optimized_delta_direction": None,
        "possible_savings_source_label": "detection heuristic",
    }


# ── Summary aggregator ─────────────────────────────────────────────────


def _summary_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the aggregate stats the summary cards consume. All
    savings-related fields are zeroed — the cards rendering them have
    been removed from the local-mode template (audit always uses local
    mode), but we keep the keys here so a stale partial doesn't crash."""
    total_cost = sum(r["query_cost_value"] or 0 for r in rows)

    def _kind_total(field: str, kind: str) -> float:
        return sum((r[field] or 0) for r in rows if r["query_workload_kind"] == kind)

    def _other_total(field: str) -> float:
        return sum(
            (r[field] or 0)
            for r in rows
            if r["query_workload_kind"] not in ("build", "consumption")
        )

    return {
        "active_count": len(rows),
        "with_solutions_count": 0,
        "clearing_count": 0,
        "verified_count": 0,
        "collecting_count": 0,
        "total_query_cost": total_cost,
        "build_query_cost": _kind_total("query_cost_value", "build"),
        "consumption_query_cost": _kind_total("query_cost_value", "consumption"),
        "other_query_cost": _other_total("query_cost_value"),
        # All savings keys — kept for template-shape compatibility, all 0.
        "total_savings": 0,
        "total_possible_savings": 0,
        "build_possible_savings": 0,
        "consumption_possible_savings": 0,
        "other_possible_savings": 0,
        "verified_post_merge_savings": 0,
        "clearing_savings": 0,
    }


# ── Filtering ──────────────────────────────────────────────────────────


def _apply_filters(
    rows: list[dict[str, Any]],
    *,
    search: str,
    status: str,
    projects: str,
    types: str,
    smart_view: str,
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
) -> list[dict[str, Any]]:
    out = rows
    if search:
        needle = search.lower()
        out = [
            r
            for r in out
            if needle in (r["affected_table"] or "").lower()
            or needle in (r["affected_dataset"] or "").lower()
            or needle in (r["affected_object"] or "").lower()
            or needle in (r["dbt_model_name"] or "").lower()
            or needle in r["opportunity_type"].lower()
        ]
    # `status` doesn't differentiate audit rows beyond `active`; we
    # honour the dropdown so the UI selection round-trips, but every
    # cached row is "active".
    if status not in ("all", "", "active"):
        out = []
    if projects:
        out = [r for r in out if r["config_id"] == projects]
    if types:
        out = [r for r in out if r["opportunity_type"] == types]
    if dataset:
        out = [r for r in out if (r["affected_dataset"] or "") == dataset]
    if workload:
        # ``unclassified`` covers any kind that isn't build/consumption —
        # matches the chip's "Unclassified" label in the table.
        if workload == "unclassified":
            out = [
                r
                for r in out
                if r["query_workload_kind"] not in ("build", "consumption")
            ]
        else:
            out = [r for r in out if r["query_workload_kind"] == workload]
    if suggestions:
        # Effective suggestion count: for issue rows, the attached
        # ``improvements_count``; for improvement-only rows, the row IS
        # one suggestion. Mirrors the cell logic in _table.html.
        def _eff_count(r: dict[str, Any]) -> int:
            if r.get("is_issue"):
                return r.get("improvements_count") or 0
            return 1

        def _eff_diff(r: dict[str, Any]) -> int:
            if r.get("is_issue"):
                return r.get("improvements_with_diff_count") or 0
            return 1 if r.get("has_self_template") else 0

        if suggestions == "with":
            out = [r for r in out if _eff_count(r) > 0]
        elif suggestions == "with-diff":
            out = [r for r in out if _eff_diff(r) > 0]
        elif suggestions == "none":
            out = [r for r in out if _eff_count(r) == 0]
    if smart_view == "quick-wins":
        out = [r for r in out if r["severity_bucket"] in ("critical", "high")]
    elif smart_view == "chronic":
        # Highest occurrence_count rows.
        out = sorted(out, key=lambda r: r["occurrence_count"], reverse=True)[:50]
    elif smart_view == "unaddressed":
        out = [r for r in out if r["severity_bucket"] != "low"]
    return out


# ── Sorting ────────────────────────────────────────────────────────────


def _sort_rows(
    rows: list[dict[str, Any]], sort_by: str, direction: str
) -> list[dict[str, Any]]:
    reverse = direction == "desc"
    if sort_by == "project":

        def key(r: dict[str, Any]) -> str:
            return r["project_name"] or ""

    elif sort_by == "dataset":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_dataset"] or "").lower()

    elif sort_by == "table":

        def key(r: dict[str, Any]) -> str:
            return (r["affected_object"] or r["affected_table"] or "").lower()

    elif sort_by == "type":

        def key(r: dict[str, Any]) -> str:
            return r["opportunity_type"]

    elif sort_by == "workload":

        def key(r: dict[str, Any]) -> str:
            return r["query_workload_kind"] or "zzz"

    elif sort_by == "cost":

        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    elif sort_by == "age":

        def key(r: dict[str, Any]) -> datetime:
            return r["last_detected_at"] or datetime.min

    elif sort_by == "state":
        # Cloud sorts state asc=Safe→High→Awaiting; audit's analogue
        # is severity bucket order (critical → low) — we treat
        # asc=low_severity_first, desc=critical_first.
        def key(r: dict[str, Any]) -> int:
            return _BUCKET_ORDER.get(r["severity_bucket"], 99)

        reverse = not reverse  # asc on bucket order = critical first feels wrong; flip
    else:
        # Default fallback: sort by current cost.
        def key(r: dict[str, Any]) -> float:
            return r["query_cost_value"] or 0

    return sorted(rows, key=key, reverse=reverse)


# ── Routes ─────────────────────────────────────────────────────────────


@router.get("/opportunities", response_class=HTMLResponse)
def opportunities_index(
    request: Request,
    page: int = 1,
    sort: str | None = None,
    direction: str | None = None,
    search: str = "",
    status: str = "all",
    projects: str = "",
    types: str = "",
    view: str = "",
    dataset: str = "",
    workload: str = "",
    suggestions: str = "",
) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    sort_by = sort if sort in _VALID_SORTS else _DEFAULT_SORT
    sort_dir = direction if direction in ("asc", "desc") else _DEFAULT_DIRECTION

    # Scope to the active (project, region). The SQLite cache is shared
    # across every project ever audited; without this filter, switching
    # projects shows the previous project's findings.
    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        # Storage-billing rows live in the dashboard's Storage Optimization
        # panel and are dataset-level (not per-job), so they don't belong
        # in this query-cost-driven workspace. Every other rule type
        # (issues + improvements) is listed — improvements still ride
        # along on issue rows under ``evidence_snapshot["_improvements"]``
        # for the inline diff stack on the detail page, AND they now also
        # surface as their own rows so models with only suggestions (no
        # underlying issue) still show up in /opportunities.
        _excluded_types = ["storage_billing_optimization"]
        active_rows = (
            session.query(Opportunity)
            .filter(Opportunity.status == "active")
            .filter(Opportunity.config_id == active_config_id)
            .filter(~Opportunity.opportunity_type.in_(_excluded_types))
            .order_by(desc(Opportunity.current_cost_estimate))
            .all()
        )
        if not active_rows:
            return RedirectResponse(url="/admin/configurations", status_code=303)

        # Hydrate first related job per opportunity for workload classification.
        all_job_ids: set[str] = set()
        for opp in active_rows:
            for jid in opp.related_job_ids or []:
                all_job_ids.add(jid)
        jobs_by_id: dict[str, BigQueryJob] = {}
        if all_job_ids:
            jobs = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.job_id.in_(list(all_job_ids)),
                    BigQueryJob.config_id == active_config_id,
                )
                .all()
            )
            jobs_by_id = {j.job_id: j for j in jobs}

        rows = [
            _to_row(
                opp,
                project_name=config.gcp_project_id,
                job=next(
                    (
                        jobs_by_id[j]
                        for j in (opp.related_job_ids or [])
                        if j in jobs_by_id
                    ),
                    None,
                ),
            )
            for opp in active_rows
        ]

    # Build available filter values from the full row set.
    available_types = sorted({r["opportunity_type"] for r in rows})
    available_datasets = sorted(
        {r["affected_dataset"] for r in rows if r["affected_dataset"] and r["affected_dataset"] != "—"}
    )
    available_workloads = sorted(
        {r["query_workload_kind"] for r in rows if r["query_workload_kind"]}
    )

    # Summary BEFORE filters — covers the visible workspace (audit has
    # only one project so this matches the cloud's "all rows in scope").
    summary = _summary_from_rows(rows)

    # Apply filters + sort + paginate.
    filtered = _apply_filters(
        rows,
        search=search,
        status=status,
        projects=projects,
        types=types,
        smart_view=view,
        dataset=dataset,
        workload=workload,
        suggestions=suggestions,
    )
    filtered = _sort_rows(filtered, sort_by, sort_dir)

    page = max(1, page)
    base_pairs: list[tuple[str, str]] = []
    if search:
        base_pairs.append(("search", search))
    if status and status != "all":
        base_pairs.append(("status", status))
    if types:
        base_pairs.append(("types", types))
    if view:
        base_pairs.append(("view", view))
    if dataset:
        base_pairs.append(("dataset", dataset))
    if workload:
        base_pairs.append(("workload", workload))
    if suggestions:
        base_pairs.append(("suggestions", suggestions))

    pagination = AuditPaginationContext(
        page=page,
        page_size=_PAGE_SIZE,
        total_items=len(filtered),
        base_query_pairs=base_pairs,
        sort=sort_by if sort_by != _DEFAULT_SORT else None,
        direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
    )
    if page > pagination.total_pages:
        page = pagination.total_pages
        pagination = AuditPaginationContext(
            page=page,
            page_size=_PAGE_SIZE,
            total_items=len(filtered),
            base_query_pairs=base_pairs,
            sort=sort_by if sort_by != _DEFAULT_SORT else None,
            direction=sort_dir if sort_dir != _DEFAULT_DIRECTION else None,
        )
    start = (page - 1) * _PAGE_SIZE
    paged = filtered[start : start + _PAGE_SIZE]

    signals = {
        "search": search,
        "status": status,
        "projects": projects,
        "types": types,
        "smart_view": view,
        "dataset": dataset,
        "workload": workload,
        "suggestions": suggestions,
        "sort": sort_by,
        "direction": sort_dir,
        "page": page,
    }

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/index.html",
        {
            "title": "Opportunities — Governor Audit",
            "opportunities": paged,
            "summary": summary,
            "signals": signals,
            "available_types": available_types,
            "available_datasets": available_datasets,
            "available_workloads": available_workloads,
            "pagination": pagination,
            "local_runtime_mode": True,
            "config": config,
        },
    )


@router.get("/opportunities/{opportunity_id}", response_class=HTMLResponse)
def opportunities_detail(request: Request, opportunity_id: str) -> HTMLResponse:
    try:
        config = load_config()
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup", status_code=303)

    from governor_audit.scan.sentinels import config_id_for

    active_config_id = config_id_for(config.gcp_project_id, config.bigquery_region)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)
    with factory() as session:
        opp = session.get(Opportunity, opportunity_id)
        if opp is None:
            raise HTTPException(status_code=404, detail="Opportunity not found")
        # Stale opportunity from a previously-audited project — refuse
        # to render foreign data even if the URL is still valid.
        if opp.config_id != active_config_id:
            raise HTTPException(status_code=404, detail="Opportunity not found")

        # Hydrate the offending job's SQL if a related job is still cached.
        # Scope to the active config so a job_id that happens to collide
        # across projects can't pull a foreign row.
        related_job = None
        for jid in opp.related_job_ids or []:
            related_job = (
                session.query(BigQueryJob)
                .filter(
                    BigQueryJob.job_id == jid,
                    BigQueryJob.config_id == active_config_id,
                )
                .first()
            )
            if related_job is not None:
                break

        row = _to_row(opp, project_name=config.gcp_project_id, job=related_job)

    rule_meta = next(
        (
            e
            for e in get_detection_rule_catalog()
            if e.rule_type == row["opportunity_type"]
        ),
        None,
    )

    # If the deterministic template registry produced a before/after for
    # this opportunity at scan time, compute the diff lines now so the
    # template can render them via components/code_diff.html. The result
    # was stashed by ``run_audit_detection`` under
    # ``evidence_snapshot["_template_result"]``.
    from governor_core.utils.diff import generate_code_diff

    diff_lines = None
    template_result = (row["evidence_snapshot"] or {}).get("_template_result")
    if template_result and template_result.get("before_content") and template_result.get("after_content"):
        diff_lines = generate_code_diff(
            template_result["before_content"],
            template_result["after_content"],
        )

    # ``_improvements`` carries each SQL-rewrite suggestion that fires on
    # the same destination table as this issue. Compute its diff lines
    # here so the template renders a stack of green/red diffs without
    # needing to know about generate_code_diff.
    improvements = (row["evidence_snapshot"] or {}).get("_improvements") or []
    # For improvement-only opportunities (no underlying issue, e.g.
    # select_star fired on a query with no slot/join/partition issue),
    # surface the row's own ``_template_result`` as a single suggestion
    # card so the detail layout matches the issue path. Without this,
    # improvement-only opps would render through the "Recommended fix"
    # diff inline + standalone "Original SQL" branch — visually
    # different from issue opps which always go through the cards. We
    # then null out ``template_result`` so the inline "Recommended fix"
    # section becomes text-only and the diff lives in exactly one place.
    if not row["is_issue"] and template_result and not improvements:
        improvements = [
            {
                "rule_type": row["opportunity_type"],
                "explanation": template_result.get("explanation") or row.get("explanation") or "",
                "template_id": template_result.get("template_id"),
                "before_content": template_result.get("before_content"),
                "after_content": template_result.get("after_content"),
                "rollback": template_result.get("rollback"),
                "occurrences": 1,
            }
        ]
        template_result = None
        diff_lines = None
    improvement_views: list[dict] = []
    for imp in improvements:
        view: dict = {
            "rule_type": imp.get("rule_type"),
            "explanation": imp.get("explanation"),
            "template_id": imp.get("template_id"),
            "before_content": imp.get("before_content"),
            "after_content": imp.get("after_content"),
            "rollback": imp.get("rollback"),
            "occurrences": imp.get("occurrences", 1),
            "diff_lines": None,
        }
        before = imp.get("before_content")
        after = imp.get("after_content")
        if before and after and before != after:
            view["diff_lines"] = generate_code_diff(before, after)
        # Display name from the rule catalog (best-effort).
        meta_entry = next(
            (e for e in get_detection_rule_catalog() if e.rule_type == imp.get("rule_type")),
            None,
        )
        view["display_name"] = meta_entry.display_name if meta_entry else imp.get("rule_type", "improvement")
        improvement_views.append(view)

    # Filter internal scratch keys (``_improvements``, ``_template_result``)
    # out of the evidence dict before the template iterates it. Jinja2 has
    # no ``startswith`` test, so doing it here keeps the template simple
    # and crash-free.
    visible_evidence = {
        k: v
        for k, v in (row["evidence_snapshot"] or {}).items()
        if not str(k).startswith("_")
    }

    # INFORMATION_SCHEMA.JOBS_BY_PROJECT lookup pre-filtered by job_id.
    # The card on the opportunity detail page renders this so the user
    # can paste it into the BigQuery console and inspect the offending
    # job themselves — no need to hand-craft the predicate.
    job_lookup_sql = _build_job_lookup_sql(
        related_job, config.gcp_project_id, config.bigquery_region
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "opportunities/detail.html",
        {
            "title": "Opportunity — Governor Audit",
            "row": row,
            "rule_meta": rule_meta,
            "job": related_job,
            "job_lookup_sql": job_lookup_sql,
            "template_result": template_result,
            "diff_lines": diff_lines,
            "visible_evidence": visible_evidence,
            "improvements": improvement_views,
        },
    )


def _build_job_lookup_sql(
    job: BigQueryJob | None, project_id: str, region: str
) -> str | None:
    """Render an ``INFORMATION_SCHEMA.JOBS_BY_PROJECT`` query that
    returns exactly the row corresponding to ``job``.

    Includes a tight ``creation_time`` predicate when we know it,
    because BigQuery requires a partition filter on that view's
    underlying table to keep scan cost bounded.
    """
    if job is None or not job.job_id:
        return None
    region_clean = (region or "us").strip().lower()
    project_clean = (project_id or "").strip()
    if not project_clean:
        return None

    if job.creation_time is not None:
        ts_iso = job.creation_time.replace(microsecond=0).isoformat()
        # Add a 1-hour buffer either side so timezone or rounding skew
        # doesn't drop the row from the scan.
        time_clause = (
            f"  AND creation_time BETWEEN "
            f"TIMESTAMP_SUB(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
            f"      AND TIMESTAMP_ADD(TIMESTAMP(\"{ts_iso}\"), INTERVAL 1 HOUR)\n"
        )
    else:
        time_clause = (
            "  AND creation_time >= "
            "TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 180 DAY)\n"
        )

    safe_job_id = job.job_id.replace("'", "\\'")
    # Curated column list — the fields useful for diagnosing a single
    # job. Mirrors the scan-time SELECT in
    # ``governor_audit.scan.information_schema.build_information_schema_query``
    # so what the user inspects matches what audit consumed.
    select_clause = (
        "SELECT\n"
        "    job_id,\n"
        "    user_email,\n"
        "    creation_time,\n"
        "    start_time,\n"
        "    end_time,\n"
        "    statement_type,\n"
        "    state,\n"
        "    cache_hit,\n"
        "    error_result,\n"
        "    total_slot_ms,\n"
        "    total_bytes_processed,\n"
        "    total_bytes_billed,\n"
        "    destination_table,\n"
        "    referenced_tables,\n"
        "    labels,\n"
        "    query_info.performance_insights AS performance_insights,\n"
        "    query_info.query_hashes AS query_hashes,\n"
        "    timeline,\n"
        "    query\n"
    )
    return (
        select_clause
        + f"FROM `{project_clean}.region-{region_clean}`."
        "INFORMATION_SCHEMA.JOBS_BY_PROJECT\n"
        f"WHERE job_id = '{safe_job_id}'\n"
        + time_clause
    )


__all__ = ["router"]
