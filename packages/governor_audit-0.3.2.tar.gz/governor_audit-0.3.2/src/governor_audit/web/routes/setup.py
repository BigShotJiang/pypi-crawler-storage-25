"""/setup/* — first-run wizard.

Vendored from governor_web's local-mode setup flow but tailored to
audit's data model. Two active steps:

  GET  /setup                  → /setup/account (entry point)
  GET  /setup/account          → step1: ADC probe
  POST /setup/account          → if ADC ok, redirect to /setup/target
  GET  /setup/target           → step2: pick project + region
  POST /setup/target           → ADC probe against target, save config,
                                 kick off the first scan inline, redirect
                                 to /dashboard on success.

The wizard is the only entry point for first-run users — every other
route checks for ``ConfigNotFoundError`` and redirects here. Once a
config exists, the wizard short-circuits to /admin/configurations so the
URL doesn't accidentally clobber state.

The legacy LLM step (``/setup/llm``) is gone — audit doesn't use the
LLM in this build, so asking for an API key just adds friction. The
URL is kept as a 308 redirect for any in-flight bookmarks. The LLM
config still lives in ``AuditConfig`` and on /admin/settings/llm so a
future build can re-enable it without a schema migration.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import ValidationError

from governor_audit.auth.adc import ProbeStatus, probe_adc
from governor_audit.config.loader import (
    ConfigNotFoundError,
    load_config,
    save_config,
)
from governor_audit.config.schema import (
    AuditConfig,
    ScanDefaults,
    WebUIConfig,
)
from governor_audit.web.routes.configurations import (
    _active_principal,
    _has_adc,
    _spawn_scan_in_background,
    gcp_projects_for_picker,
)

logger = logging.getLogger("governor_audit.web.setup")
router = APIRouter()


_STEP_LABELS = ["Google", "Audit Target"]
_TOTAL_STEPS = len(_STEP_LABELS)
_ALLOWED_LOOKBACK_DAYS = (1, 7, 30, 180)
_DEFAULT_LOOKBACK_DAYS = 1


def _wizard_ctx(step: int, **extra) -> dict:
    return {
        "current_step": step,
        "total_steps": _TOTAL_STEPS,
        "step_labels": _STEP_LABELS,
        **extra,
    }


# ─── Entry redirect ──────────────────────────────────────────────────


@router.get("/setup", response_class=HTMLResponse)
def setup_root(request: Request):
    """If config already exists, jump straight to the configuration
    page (no point re-entering the wizard). Otherwise: enter the
    wizard at step 1."""
    try:
        load_config()
        return RedirectResponse(url="/admin/configurations", status_code=303)
    except ConfigNotFoundError:
        return RedirectResponse(url="/setup/account", status_code=303)


# ─── Step 1 — Google account / ADC ───────────────────────────────────


@router.get("/setup/account", response_class=HTMLResponse)
def setup_account(request: Request):
    # ``_has_adc()`` is the wizard gate — it returns True for any
    # loadable creds, including the "authorized_user" type produced by
    # ``gcloud auth application-default login`` (which carries no
    # email on the cred object). ``_active_principal()`` is best-effort
    # and may be None even when ADC is present.
    has_adc = _has_adc()
    principal = _active_principal() if has_adc else None
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/step1_account.html",
        _wizard_ctx(
            1,
            title="Sign in — Governor Audit Setup",
            adc_ok=has_adc,
            principal=principal,
            probe_message=None if has_adc else "Run `gcloud auth application-default login` then click Re-check.",
        ),
    )


@router.post("/setup/account", response_class=HTMLResponse)
def setup_account_continue(request: Request):
    if not _has_adc():
        return RedirectResponse(url="/setup/account", status_code=303)
    return RedirectResponse(url="/setup/target", status_code=303)


# ─── Step 2 — pick project + region ──────────────────────────────────


@router.get("/setup/target", response_class=HTMLResponse)
def setup_target(request: Request):
    # Match step 1's gate. ``_active_principal()`` returns None for the
    # ``authorized_user`` creds that ``gcloud auth application-default
    # login`` writes (the email isn't on the cred object), and gating on
    # it here would bounce the user back to step 1 — an infinite loop —
    # even though their ADC is fine. ``_has_adc()`` is the right check.
    if not _has_adc():
        return RedirectResponse(url="/setup/account", status_code=303)
    picker = gcp_projects_for_picker()
    return request.app.state.templates.TemplateResponse(
        request,
        "setup/step2_target.html",
        _wizard_ctx(
            2,
            title="Audit target — Governor Audit Setup",
            principal=picker.principal,
            gcp_projects=picker.projects,
            discovery_error=picker.discovery_error,
            errors={},
            form_data={},
        ),
    )


@router.post("/setup/target", response_class=HTMLResponse)
def setup_target_save(
    request: Request,
    gcp_project_id: Annotated[str, Form()],
    bigquery_region: Annotated[str, Form()],
    lookback_days: Annotated[int, Form()] = _DEFAULT_LOOKBACK_DAYS,
):
    project = (gcp_project_id or "").strip()
    region = (bigquery_region or "").strip()
    form_data = {
        "gcp_project_id": project,
        "bigquery_region": region,
        "lookback_days": lookback_days,
    }
    picker = gcp_projects_for_picker()

    def _render_error(errors: dict, status: int = 422) -> HTMLResponse:
        return request.app.state.templates.TemplateResponse(
            request,
            "setup/step2_target.html",
            _wizard_ctx(
                2,
                title="Audit target — Governor Audit Setup",
                principal=picker.principal,
                gcp_projects=picker.projects,
                discovery_error=picker.discovery_error,
                errors=errors,
                form_data=form_data,
            ),
            status_code=status,
        )

    field_errors: dict[str, str] = {}
    if not project:
        field_errors["gcp_project_id"] = "GCP project ID is required."
    if not region:
        field_errors["bigquery_region"] = "BigQuery region is required."
    if lookback_days not in _ALLOWED_LOOKBACK_DAYS:
        field_errors["lookback_days"] = (
            f"Lookback must be one of {sorted(_ALLOWED_LOOKBACK_DAYS)} days."
        )
    if field_errors:
        return _render_error(field_errors)

    # ADC probe against the chosen target — cheap dry-run that catches
    # IAM / wrong-region issues before we write the config file.
    logger.info("setup wizard: probing ADC against %s / %s", project, region)
    probe = probe_adc(project, region)
    if probe.status is ProbeStatus.ADC_MISSING:
        return _render_error({"_general":
            "ADC vanished between step 1 and now. Run `gcloud auth application-default login` and start over from /setup/account."},
            status=400)
    if probe.status is ProbeStatus.IAM_INSUFFICIENT:
        return _render_error({"_general":
            f"Permission denied on '{project}'. The active gcloud principal "
            f"{'(' + probe.principal + ') ' if probe.principal else ''}"
            "needs roles/bigquery.resourceViewer + roles/bigquery.jobUser."},
            status=403)
    if probe.status is ProbeStatus.REGION_UNKNOWN:
        return _render_error({"bigquery_region":
            f"Region '{region}' or project '{project}' not found by BigQuery. "
            "Check the region matches a real BigQuery location (e.g. 'us', 'eu', 'australia-southeast1')."},
            status=422)
    if not probe.ok:
        return _render_error({"_general": f"ADC probe failed: {probe.message}"}, status=500)

    # Probe succeeded — write the AuditConfig. ``scan_defaults`` carries
    # the user's chosen lookback so subsequent scans from the
    # configurations page default to the same window.
    try:
        config = AuditConfig.model_validate({
            "gcp_project_id": project,
            "bigquery_region": region,
            "scan_defaults": ScanDefaults(lookback_days=lookback_days),
            "web_ui": WebUIConfig(),
        })
    except ValidationError as exc:
        return _render_error({"_general": f"Config validation failed: {exc}"}, status=422)

    save_config(config)
    logger.info(
        "setup wizard: config written for %s / %s (lookback=%dd)",
        project, region, lookback_days,
    )

    # Kick off the first scan in a background daemon thread and 303
    # straight to the configurations page. The orchestrator persists
    # ``ScanRun.status="running"`` synchronously before any BigQuery
    # work, so the configurations page's scan history table renders
    # the in-flight row immediately.
    _spawn_scan_in_background(
        config,
        days=lookback_days,
        dbt_only=config.scan_defaults.dbt_only,
    )
    return RedirectResponse(
        url="/admin/configurations?scan_status=started",
        status_code=303,
    )


# ─── Backward-compat redirects ───────────────────────────────────────
# Old wizards routed through /setup/llm and /setup/complete. Both URLs
# are kept alive as redirects so any in-flight bookmarks land somewhere
# useful instead of 404ing.


@router.get("/setup/llm")
@router.post("/setup/llm")
def setup_llm_redirect():
    return RedirectResponse(url="/admin/configurations", status_code=308)


@router.get("/setup/complete")
def setup_complete_redirect():
    return RedirectResponse(url="/admin/configurations", status_code=308)


__all__ = ["router"]
