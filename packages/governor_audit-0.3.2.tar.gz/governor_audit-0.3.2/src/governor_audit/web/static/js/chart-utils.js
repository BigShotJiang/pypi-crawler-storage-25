/**
 * Shared chart utilities for Governor.
 * Provides brand colours, formatters, axis styling,
 * and resize/theme helpers consumed by dashboard-charts.js and inline chart scripts.
 */
(function() {
  'use strict';

  var ChartUtils = {};

  // --- Dark mode & accessibility detection ---

  ChartUtils.isDarkMode = function() {
    return document.documentElement.classList.contains('dark');
  };

  // --- Brand colour constants ---

  ChartUtils.BRAND_COLORS = {
    primary:   '#275FE3',
    secondary: '#6E94F8',
    dark:      '#20236A',
    soft:      '#91AFF9',
    highlight: '#EAEFFE'
  };

  ChartUtils.CHART_COLORS = {
    cost:     { light: '#275FE3', dark: '#275FE3' },
    build:    { light: '#275FE3', dark: '#275FE3' },
    consumption: { light: '#0F766E', dark: '#34D399' },
    bytes:    { light: '#20236A', dark: '#91AFF9' },
    slots:    { light: '#8B5CF6', dark: '#8B5CF6' },
    emphasis: { light: '#20236A', dark: '#6E94F8' }
  };

  // --- Formatters ---

  ChartUtils.formatCurrency = function(value) {
    if (value >= 10000000) {
      return '$' + (value / 1000000).toFixed(1) + 'M';
    } else if (value >= 10000) {
      return '$' + (value / 1000).toFixed(1) + 'k';
    } else if (value >= 1) {
      return '$' + value.toFixed(2);
    } else {
      return '$' + value.toFixed(2);
    }
  };

  ChartUtils.formatBytesValue = function(value) {
    if (value == null || value === 0) return '0 B';
    var units = [
      [Math.pow(1024, 5), 'PB'],
      [Math.pow(1024, 4), 'TB'],
      [Math.pow(1024, 3), 'GB'],
      [Math.pow(1024, 2), 'MB'],
      [1024, 'KB']
    ];
    for (var i = 0; i < units.length; i++) {
      if (value >= units[i][0]) {
        return (value / units[i][0]).toFixed(1) + ' ' + units[i][1];
      }
    }
    return value + ' B';
  };

  ChartUtils.formatSlotHours = function(slotMs) {
    if (slotMs == null || slotMs === 0) return '0.0 slot-hrs';
    var hrs = slotMs / 3600000;
    if (hrs >= 1000) return (hrs / 1000).toFixed(1) + 'k slot-hrs';
    if (hrs >= 1) return hrs.toFixed(1) + ' slot-hrs';
    return slotMs.toLocaleString() + ' slot-ms';
  };

  ChartUtils.formatNumber = function(value) {
    if (value == null) return '0';
    return value.toLocaleString();
  };

  ChartUtils.formatDate = function(dateStr) {
    if (!dateStr) return '';
    var dateOnly = String(dateStr).split(' ')[0];
    var parts = dateOnly.split('-');
    if (parts.length >= 3) {
      return parts[2] + '/' + parts[1];
    }
    return dateOnly;
  };

  // --- Axis styling ---

  ChartUtils.getAxisStyle = function(isDark) {
    return {
      textColor:  isDark ? '#e2e8f0' : '#1e293b',
      lineColor:  isDark ? '#475569' : '#e2e8f0',
      splitColor: isDark ? '#334155' : '#f1f5f9'
    };
  };

  // --- Area gradient ---

  ChartUtils.getAreaGradient = function(hexColor, isDark) {
    var r = parseInt(hexColor.slice(1, 3), 16);
    var g = parseInt(hexColor.slice(3, 5), 16);
    var b = parseInt(hexColor.slice(5, 7), 16);
    return {
      type: 'linear',
      x: 0, y: 0, x2: 0, y2: 1,
      colorStops: [{
        offset: 0,
        color: 'rgba(' + r + ',' + g + ',' + b + ',' + (isDark ? 0.3 : 0.2) + ')'
      }, {
        offset: 1,
        color: 'rgba(' + r + ',' + g + ',' + b + ',' + (isDark ? 0.05 : 0.02) + ')'
      }]
    };
  };

  // --- Chart resize utility ---

  ChartUtils.setupChartResize = function(charts) {
    if (typeof ResizeObserver !== 'undefined') {
      var observer = new ResizeObserver(function(entries) {
        entries.forEach(function(entry) {
          var chart = echarts.getInstanceByDom(entry.target);
          if (chart) chart.resize();
        });
      });
      charts.forEach(function(chart) {
        if (chart && chart.getDom) observer.observe(chart.getDom());
      });
      return;
    }
    // Fallback: debounced window resize
    var timeout;
    window.addEventListener('resize', function() {
      clearTimeout(timeout);
      timeout = setTimeout(function() {
        charts.forEach(function(chart) {
          if (chart) chart.resize();
        });
      }, 100);
    });
  };

  // --- Theme change watcher ---

  ChartUtils.setupThemeWatcher = function(reinitCallback) {
    var observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.attributeName === 'class') {
          reinitCallback();
        }
      });
    });
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    });
    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', reinitCallback);
    }
  };

  // --- Helper: get series color for current theme ---

  ChartUtils.getSeriesColor = function(series) {
    var isDark = ChartUtils.isDarkMode();
    var entry = ChartUtils.CHART_COLORS[series];
    return entry ? (isDark ? entry.dark : entry.light) : ChartUtils.BRAND_COLORS.primary;
  };

  ChartUtils.getEmphasisColor = function() {
    var isDark = ChartUtils.isDarkMode();
    return isDark ? ChartUtils.CHART_COLORS.emphasis.dark : ChartUtils.CHART_COLORS.emphasis.light;
  };

  // Export globally
  window.ChartUtils = ChartUtils;
})();
