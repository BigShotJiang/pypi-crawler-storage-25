"""Jinja filters for the audit web UI.

Mirrors ``governor_web.template_filters`` (the cloud's filter module) so
templates copied from there work as-is. We only carry the helpers
audit actually uses — ``timeago`` for "Last scan: 5 minutes ago" style
relative timestamps on the configuration page.
"""

from __future__ import annotations

from datetime import datetime


def timeago(dt: datetime | None) -> str:
    """Format datetime as relative time if < 24h, else absolute date.

    Vendored from governor_web/template_filters.timeago. Returns:
      - "Never" when dt is None
      - "Just now" when < 60 s
      - "5 minutes ago" / "3 hours ago" within 24 h
      - "Apr 28, 2026" otherwise
    """
    if dt is None:
        return "Never"

    now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
    delta = now - dt
    secs = delta.total_seconds()

    if secs < 0:
        # Future timestamp — surface verbatim, don't lie about elapsed.
        return dt.strftime("%b %d, %Y")
    if secs < 60:
        return "Just now"
    if secs < 3600:
        n = int(secs // 60)
        return f"{n} minute{'s' if n != 1 else ''} ago"
    if secs < 86_400:
        n = int(secs // 3600)
        return f"{n} hour{'s' if n != 1 else ''} ago"
    return dt.strftime("%b %d, %Y")


__all__ = ["timeago"]
