"""Default BigQuery client implementing ``BigQueryClientProtocol``.

Thin wrapper over ``google.cloud.bigquery.Client`` that exposes the
two methods the scan orchestrator needs (``dry_run`` and ``query_rows``)
plus the parameter-binding plumbing.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Iterable

from governor_audit.scan.information_schema import DryRunEstimate

logger = logging.getLogger("governor_audit.scan.bigquery_client")


class _GoogleBigQueryClient:
    """Production client; constructed from ADC."""

    def __init__(self, project_id: str, region: str) -> None:
        from google.cloud import bigquery

        self._project_id = project_id
        self._region = region
        self._client = bigquery.Client(project=project_id)
        self._bigquery = bigquery

    def _build_job_config(self, params: dict[str, Any], *, dry_run: bool):
        bq_params = []
        for name, value in params.items():
            if isinstance(value, datetime):
                bq_params.append(
                    self._bigquery.ScalarQueryParameter(name, "TIMESTAMP", value)
                )
            elif isinstance(value, int):
                bq_params.append(
                    self._bigquery.ScalarQueryParameter(name, "INT64", value)
                )
            else:
                bq_params.append(
                    self._bigquery.ScalarQueryParameter(name, "STRING", str(value))
                )
        return self._bigquery.QueryJobConfig(
            query_parameters=bq_params,
            dry_run=dry_run,
            use_query_cache=False,
        )

    def dry_run(self, query: str, params: dict[str, Any]) -> DryRunEstimate:
        cfg = self._build_job_config(params, dry_run=True)
        job = self._client.query(query, job_config=cfg, location=self._region)
        bytes_billed = int(job.total_bytes_processed or 0)
        from governor_audit.scan.information_schema import estimated_cost_usd
        return DryRunEstimate(
            bytes_billed=bytes_billed,
            cost_usd=estimated_cost_usd(bytes_billed),
        )

    def query_rows(self, query: str, params: dict[str, Any]) -> Iterable[dict[str, Any]]:
        cfg = self._build_job_config(params, dry_run=False)
        job = self._client.query(query, job_config=cfg, location=self._region)
        for row in job.result():
            yield dict(row.items())


def build_default_client(project_id: str, region: str):
    """Construct the production BigQuery client. Raises ``ImportError``
    if ``google-cloud-bigquery`` isn't installed (the CLI surfaces this
    with a clear message)."""
    return _GoogleBigQueryClient(project_id, region)


__all__ = ["build_default_client"]
