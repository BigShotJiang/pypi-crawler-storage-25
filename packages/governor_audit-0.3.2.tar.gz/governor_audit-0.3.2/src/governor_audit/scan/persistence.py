"""Map BigQuery INFORMATION_SCHEMA rows → ``BigQueryJob`` ORM instances.

Each row from ``bq_client.query_rows`` is a dict whose shape mirrors
the ``SELECT`` clause built by
``governor_audit.scan.information_schema.build_information_schema_query``.
Some columns are STRUCTs that the BigQuery Python client decodes to
dicts (``destination_table``) or lists of dicts
(``referenced_tables``, ``labels``, ``timeline``); we serialise those
shapes directly into the ORM's JSONB columns.

We also compute ``total_cost`` from ``total_bytes_billed`` using the
on-demand pricing constant — the cloud sync worker does the same thing,
keeping cost rendering consistent across the two products.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Any, Iterable

from governor_audit.scan.information_schema import (
    ON_DEMAND_USD_PER_TB,
    estimated_cost_usd,
)


def _format_table_ref(value: Any) -> str | None:
    """Flatten a BigQuery table reference struct to ``project.dataset.table``."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        proj = value.get("project_id") or value.get("projectId") or ""
        ds = value.get("dataset_id") or value.get("datasetId") or ""
        tbl = value.get("table_id") or value.get("tableId") or ""
        parts = [p for p in (proj, ds, tbl) if p]
        return ".".join(parts) if parts else None
    return None


def _normalise_struct_list(value: Any) -> list | None:
    """Return a JSON-serialisable list of dicts (or None).

    BigQuery client may return ``Row`` / ``Struct`` instances that aren't
    plain dicts. We coerce each element to a dict the JSONB column can
    persist.
    """
    if not value:
        return None
    out: list = []
    for item in value:
        if isinstance(item, dict):
            out.append(dict(item))
        elif hasattr(item, "items"):
            out.append({k: v for k, v in item.items()})
        else:
            out.append({"value": str(item)})
    return out or None


def _normalise_struct(value: Any) -> dict | None:
    if not value:
        return None
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "items"):
        return {k: v for k, v in value.items()}
    return None


def _duration_ms(start: datetime | None, end: datetime | None) -> int | None:
    if not start or not end:
        return None
    delta = end - start
    return max(0, int(delta.total_seconds() * 1000))


def row_to_bigquery_job(
    row: dict[str, Any],
    *,
    config_id: str,
    sync_id: str,
):
    """Construct a ``BigQueryJob`` ORM instance from one INFORMATION_SCHEMA row.

    Imported lazily so unit-test modules can reuse the helper without
    pulling in the full SQLAlchemy registry.
    """
    from governor_core.sync.models import BigQueryJob

    bytes_billed = int(row.get("total_bytes_billed") or 0)
    total_cost = (
        Decimal(str(round(estimated_cost_usd(bytes_billed), 4))) if bytes_billed else None
    )

    return BigQueryJob(
        id=uuid.uuid4().hex,
        config_id=config_id,
        sync_id=sync_id,
        job_id=row["job_id"],
        user_email=row.get("user_email") or "unknown",
        query=row.get("query"),
        creation_time=row["creation_time"],
        start_time=row.get("start_time"),
        end_time=row.get("end_time"),
        duration_ms=_duration_ms(row.get("start_time"), row.get("end_time")),
        total_slot_ms=row.get("total_slot_ms"),
        total_bytes_processed=row.get("total_bytes_processed"),
        total_bytes_billed=bytes_billed or None,
        total_cost=total_cost,
        job_state=row.get("state") or "DONE",
        job_type="QUERY",
        error_result=_normalise_struct(row.get("error_result")),
        total_modified_partitions=row.get("total_modified_partitions"),
        cache_hit=row.get("cache_hit"),
        destination_table=_format_table_ref(row.get("destination_table")),
        referenced_tables=_normalise_struct_list(row.get("referenced_tables")),
        statement_type=row.get("statement_type"),
        performance_insights=_normalise_struct(row.get("performance_insights")),
        query_hashes=_normalise_struct(row.get("query_hashes")),
        timeline=_normalise_struct_list(row.get("timeline")),
    )


def persist_jobs(
    session, rows: Iterable[dict[str, Any]], *, config_id: str, sync_id: str
) -> int:
    """Insert one ``BigQueryJob`` row per scan-row dict.

    Skips rows whose ``job_id`` already exists (ON CONFLICT semantics
    via a SELECT/INSERT instead of UPSERT — SQLite's INSERT OR IGNORE
    would also work but the explicit check makes the test path simpler).
    Returns the number of rows actually persisted.
    """
    from governor_core.sync.models import BigQueryJob

    persisted = 0
    rows = list(rows)
    if not rows:
        return 0

    seen_ids = {
        jid for (jid,) in session.query(BigQueryJob.job_id)
        .filter(BigQueryJob.job_id.in_([r["job_id"] for r in rows]))
        .all()
    }

    for row in rows:
        if row["job_id"] in seen_ids:
            continue
        session.add(
            row_to_bigquery_job(row, config_id=config_id, sync_id=sync_id)
        )
        persisted += 1

    session.flush()
    return persisted


__all__ = [
    "ON_DEMAND_USD_PER_TB",
    "persist_jobs",
    "row_to_bigquery_job",
]
