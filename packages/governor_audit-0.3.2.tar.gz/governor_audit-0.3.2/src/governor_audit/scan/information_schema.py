"""BigQuery INFORMATION_SCHEMA query builder.

The query targets ``<project>.region-<region>.INFORMATION_SCHEMA.JOBS_BY_PROJECT``
which carries every BigQuery job submitted by any principal in the project.

Filters applied (per the BigQuery doc + spec 141 FRs):

- ``job_type = 'QUERY'`` — exclude LOAD/EXTRACT/COPY (covered by other rules later)
- ``state = 'DONE'`` — only completed jobs
- ``statement_type IS NOT NULL AND statement_type != 'SCRIPT'`` — the doc
  explicitly warns that SCRIPT rows duplicate child-job stats; including
  them double-counts cost
- ``error_result IS NULL`` — failed queries aren't billed for
  ``total_bytes_billed``, so cost rules would mis-attribute on them
- (optional) ``STARTS_WITH(query, '/* {"app": "dbt"')`` when ``dbt_only=True``

Columns selected (cross-referenced with what
``governor_core.sync.models.BigQueryJob`` already declares):

  Already on BigQueryJob (re-populated by us, no schema change):
    job_id, user_email, query, creation_time, start_time, end_time,
    total_slot_ms, total_bytes_processed, total_bytes_billed,
    destination_table, referenced_tables, statement_type, cache_hit,
    error_result, total_modified_partitions, performance_insights,
    query_hashes, timeline, bi_engine_mode, bi_engine_reasons

  NEW for governor-audit (extracted at scan time, NOT persisted on
  BigQueryJob — derived values stored on AuditOpportunityMetadata):
    labels  → is_dbt_originated, dbt_node_id, dbt_invocation_id

The ``BigQueryClientProtocol`` indirection lets tests substitute a fake
client without monkey-patching ``google.cloud.bigquery``.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable, Protocol

# 180-day INFORMATION_SCHEMA.JOBS retention per the BigQuery doc:
#   "This view displays running jobs along with job history for the
#    past 180 days."
# Anything beyond this is silently empty; the orchestrator clamps to it.
INFORMATION_SCHEMA_RETENTION_DAYS = 180


@dataclass(frozen=True)
class DryRunEstimate:
    bytes_billed: int
    cost_usd: float


class BigQueryClientProtocol(Protocol):
    """Minimal surface the scan orchestrator needs from a BigQuery client."""

    def dry_run(self, query: str, params: dict[str, Any]) -> DryRunEstimate:
        ...

    def query_rows(
        self, query: str, params: dict[str, Any]
    ) -> Iterable[dict[str, Any]]:
        ...


# On-demand pricing as of 2026-04 — used to convert estimated bytes-billed
# into USD for the user's cost-cap message. Not used for billing accounting.
ON_DEMAND_USD_PER_TB = 6.25

# The dbt-bigquery adapter prepends this comment header to every compiled
# query. Stable across dbt 1.7+ / dbt-bigquery 1.x. Used as a fallback
# attribution path; the primary path is the labels check below.
DBT_QUERY_PREFIX = '/* {"app": "dbt"'

# Labels the dbt-bigquery adapter sets on every job. Their presence is
# the most reliable dbt-originated signal — labels survive query
# rewrites and proxies that the comment prefix doesn't.
DBT_LABEL_KEYS = frozenset({"dbt_invocation_id", "dbt_orchestrator"})

# Per-resource label key carrying the dbt node id (e.g. "model.warehouse.fct_orders").
# This is the manifest-free way to attribute a BigQuery job to a dbt model.
DBT_NODE_ID_LABEL_KEY = "node_id"


def estimated_cost_usd(bytes_billed: int) -> float:
    """Convert bytes-billed → USD at current on-demand price."""
    return (bytes_billed / 1024 ** 4) * ON_DEMAND_USD_PER_TB


def build_information_schema_query(
    *,
    project_id: str,
    region: str,
    window_start: datetime,
    window_end: datetime,
    dbt_only: bool = False,
) -> tuple[str, dict[str, Any]]:
    """Return (sql, params) for the INFORMATION_SCHEMA.JOBS_BY_PROJECT query.

    Date values + the dbt prefix string are passed as parameters — never
    string-interpolated — so the user can't be tricked into running a
    different query by a crafted config value.
    """
    where_extra = ""
    params: dict[str, Any] = {
        "window_start": window_start,
        "window_end": window_end,
    }
    if dbt_only:
        where_extra = "AND STARTS_WITH(query, @dbt_prefix)"
        params["dbt_prefix"] = DBT_QUERY_PREFIX

    sql = f"""
        SELECT
            job_id,
            user_email,
            query,
            creation_time,
            start_time,
            end_time,
            total_slot_ms,
            total_bytes_processed,
            total_bytes_billed,
            destination_table,
            referenced_tables,
            statement_type,
            cache_hit,
            error_result,
            state,
            total_modified_partitions,
            labels,
            query_info.performance_insights AS performance_insights,
            query_info.query_hashes AS query_hashes,
            timeline
        FROM `{project_id}.region-{region}`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
        WHERE creation_time BETWEEN @window_start AND @window_end
          AND job_type = 'QUERY'
          AND state = 'DONE'
          AND statement_type IS NOT NULL
          AND statement_type != 'SCRIPT'
          AND error_result IS NULL
          {where_extra}
        ORDER BY creation_time DESC
    """.strip()
    return sql, params


def _label_value(job: dict[str, Any], key: str) -> str | None:
    """Pull a single label value from the job's ``labels`` array.

    BigQuery returns labels as ``ARRAY<STRUCT<key STRING, value STRING>>``.
    The Python BQ client deserialises this to a list of dicts. Returns
    ``None`` if the label isn't present or labels is missing entirely.
    """
    labels = job.get("labels")
    if not labels:
        return None
    for label in labels:
        if isinstance(label, dict) and label.get("key") == key:
            value = label.get("value")
            if isinstance(value, str) and value:
                return value
    return None


def is_dbt_originated(job: dict[str, Any]) -> bool:
    """Return True if this BigQuery job was produced by dbt.

    Resolution order (highest confidence first):
      1. ``labels`` contains ``dbt_invocation_id`` or ``dbt_orchestrator`` —
         the dbt-bigquery adapter sets these on every compiled query and
         labels can't be stripped by query rewriting tools.
      2. The query body starts with the dbt comment prefix
         ``/* {"app": "dbt"`` — a fallback for older dbt versions or
         non-standard wrappers that don't propagate labels.

    Either signal is sufficient.
    """
    labels = job.get("labels") or []
    for label in labels:
        if isinstance(label, dict) and label.get("key") in DBT_LABEL_KEYS:
            return True
    query_text = job.get("query") or ""
    return query_text.lstrip().startswith(DBT_QUERY_PREFIX)


def extract_dbt_node_id(job: dict[str, Any]) -> str | None:
    """Return the dbt node identifier (e.g. "model.warehouse.fct_orders")
    from the job's labels, or None if the job is not dbt-originated or
    its dbt version doesn't emit the ``node_id`` label.

    This is the manifest-free way to attribute a BigQuery job to a dbt
    model — same answer the manifest's nodes lookup would give us, but
    sourced from BigQuery's own job log instead of a separate file.
    """
    return _label_value(job, DBT_NODE_ID_LABEL_KEY)


def extract_dbt_invocation_id(job: dict[str, Any]) -> str | None:
    """Return the dbt invocation UUID from the job's labels, or None.

    Useful for grouping all BigQuery jobs that came from the same
    ``dbt run`` / ``dbt build`` invocation, e.g. to see "this single dbt
    run cost $X across N models".
    """
    return _label_value(job, "dbt_invocation_id")


def extract_query_hash(job: dict[str, Any]) -> str | None:
    """Return the ``normalized_literals`` query hash from the job's
    ``query_info`` block, or None if absent (cache hits don't have one).

    The hash ignores comments, parameter values, UDFs, and literals —
    so three runs of the same logical query with different ``WHERE``
    constants share the same hash. Lets the UI roll up "1247 occurrences
    of this query, total cost $X" instead of 1247 near-identical findings.
    """
    query_hashes = job.get("query_hashes")
    if isinstance(query_hashes, dict):
        value = query_hashes.get("normalized_literals")
        if isinstance(value, str) and value:
            return value
    return None


def clamp_lookback_days(requested: int) -> tuple[int, str | None]:
    """Clamp the user's requested lookback to the INFORMATION_SCHEMA
    180-day retention. Returns ``(effective_days, warning_message)``;
    ``warning_message`` is ``None`` when no clamp was applied.
    """
    if requested <= INFORMATION_SCHEMA_RETENTION_DAYS:
        return requested, None
    return (
        INFORMATION_SCHEMA_RETENTION_DAYS,
        (
            f"Requested --days={requested} but INFORMATION_SCHEMA.JOBS only "
            f"retains {INFORMATION_SCHEMA_RETENTION_DAYS} days of history. "
            f"Clamped to {INFORMATION_SCHEMA_RETENTION_DAYS}."
        ),
    )


__all__ = [
    "BigQueryClientProtocol",
    "DBT_QUERY_PREFIX",
    "DBT_LABEL_KEYS",
    "DBT_NODE_ID_LABEL_KEY",
    "DryRunEstimate",
    "INFORMATION_SCHEMA_RETENTION_DAYS",
    "ON_DEMAND_USD_PER_TB",
    "build_information_schema_query",
    "clamp_lookback_days",
    "estimated_cost_usd",
    "extract_dbt_invocation_id",
    "extract_dbt_node_id",
    "extract_query_hash",
    "is_dbt_originated",
]
