"""Advisory scan lock at ``~/.governor-audit/scan.lock``.

Single-tenant invariant per research D-8. The lock is a JSON file
containing the holding scan's PID + start time. ``governor-audit unlock``
clears stale locks (PID gone).
"""

from __future__ import annotations

import json
import os
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from governor_audit.config.loader import config_dir, ensure_config_dir

LOCK_FILENAME = "scan.lock"


class ScanLockHeldError(Exception):
    def __init__(self, holder_pid: int, started_at: str | None) -> None:
        self.holder_pid = holder_pid
        self.started_at = started_at
        super().__init__(
            f"Scan lock held by PID {holder_pid}"
            + (f" (started {started_at})" if started_at else "")
            + ". If the process is dead, run `governor-audit unlock`."
        )


def lock_path(dir_override: Path | None = None) -> Path:
    return config_dir(dir_override) / LOCK_FILENAME


def _pid_alive(pid: int) -> bool:
    """Return True if a process with this PID is currently running."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but we can't signal it — treat as alive.
        return True
    return True


def read_lock(dir_override: Path | None = None) -> dict | None:
    path = lock_path(dir_override)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


@contextmanager
def acquire_scan_lock(dir_override: Path | None = None):
    """Acquire the scan lock for the duration of the context.

    Raises ``ScanLockHeldError`` if another live process holds it.
    Clears stale locks (holding PID is gone) and proceeds.
    """
    ensure_config_dir(dir_override)
    path = lock_path(dir_override)

    existing = read_lock(dir_override)
    if existing is not None:
        holder_pid = int(existing.get("pid", -1))
        if holder_pid > 0 and _pid_alive(holder_pid):
            raise ScanLockHeldError(holder_pid, existing.get("started_at"))
        # Stale lock — silently take it over.
        path.unlink(missing_ok=True)

    payload = {
        "pid": os.getpid(),
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    path.write_text(json.dumps(payload))
    try:
        yield path
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


__all__ = ["ScanLockHeldError", "acquire_scan_lock", "lock_path", "read_lock"]
