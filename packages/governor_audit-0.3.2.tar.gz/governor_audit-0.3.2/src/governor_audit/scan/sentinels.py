"""Sentinel parent-row helpers for the audit cache.

``governor_core.sync.models.BigQueryJob`` and
``governor_core.opportunities.models.Opportunity`` carry mandatory FKs
to ``manifest_configurations.id`` (which itself FKs ``users.id``) and
``detection_jobs.id``. Cloud governor populates those via the full
sync/detection orchestration; the audit package has no users or
manifest concept, so we synthesise stable sentinel rows.

Idempotent — these functions are safe to call on every scan. They use
SQLAlchemy core inserts on the stub ``users`` table (declared by
``declare_web_stub_tables``) so we don't need to import the web ORM.

ID conventions (deterministic — repeated scans hit the same rows):
  user                     audit-system
  manifest_configuration   audit-{project_id}-{region} truncated to 36 chars
  detection_job            tied to scan_run_id (one per scan)
  sync_operation           tied to scan_run_id (one per scan)
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from sqlalchemy import insert, select

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

SENTINEL_USER_ID = "audit-system"


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def config_id_for(project_id: str, region: str) -> str:
    """Deterministic, FK-safe ManifestConfiguration id for (project, region).

    Hashed so it always fits the 36-char column even if the project name
    is long; deterministic so subsequent scans in the same project find
    and reuse the same row. The web routes also import this to scope
    dashboard / opportunities reads to the active project — without it
    the SQLite cache merges every project ever scanned.
    """
    digest = hashlib.sha1(f"{project_id}|{region}".encode("utf-8")).hexdigest()
    return f"audit-{digest[:30]}"


# Backward-compat alias — keep the old underscore-prefixed name working
# for any in-flight imports outside this package.
_config_id_for = config_id_for


def ensure_sentinel_user(session: "Session") -> str:
    """Insert the audit-system user if missing. Returns the id."""
    from governor_core.db.base import Base

    users = Base.metadata.tables["users"]
    existing = session.execute(
        select(users.c.id).where(users.c.id == SENTINEL_USER_ID)
    ).first()
    if existing:
        return SENTINEL_USER_ID
    session.execute(insert(users).values(id=SENTINEL_USER_ID))
    return SENTINEL_USER_ID


def ensure_sentinel_config(
    session: "Session", *, project_id: str, region: str, user_id: str
) -> str:
    """Insert the per-(project, region) sentinel ManifestConfiguration if
    missing. Returns the id. The config is otherwise unused — its only
    purpose is to satisfy FKs from ``bigquery_jobs`` and ``opportunities``.
    """
    from governor_core.configurations.models import ManifestConfiguration

    config_id = config_id_for(project_id, region)
    existing = session.get(ManifestConfiguration, config_id)
    if existing is not None:
        return config_id

    now = _utcnow()
    config = ManifestConfiguration(
        id=config_id,
        name=f"governor-audit · {project_id} ({region})",
        gcp_project_id=project_id,
        manifest_source="audit",
        status="active",
        version=1,
        created_at=now,
        updated_at=now,
        created_by_id=user_id,
        updated_by_id=user_id,
    )
    session.add(config)
    session.flush()
    return config_id


def create_sync_operation(
    session: "Session", *, config_id: str, scan_run_id: str
) -> str:
    """Create a SyncOperation row tied to this scan. Each scan gets its
    own sync_operation so cascades stay clean. The id mirrors scan_run_id
    so the two are easy to correlate during debugging.
    """
    from governor_core.sync.models import SyncOperation

    sync_id = f"syncop-{scan_run_id[:30]}"
    now = _utcnow()
    sync_op = SyncOperation(
        id=sync_id,
        config_id=config_id,
        status="completed",
        queued_at=now,
        started_at=now,
        completed_at=now,
        triggered_by="manual",
        retry_count=0,
    )
    session.add(sync_op)
    session.flush()
    return sync_id


def create_detection_job(
    session: "Session", *, config_id: str, sync_id: str, scan_run_id: str
) -> str:
    """Create a DetectionJob row that owns the Opportunities produced by
    this scan. Required because ``Opportunity.first_detection_job_id`` is
    not nullable.
    """
    from governor_core.opportunities.models import DetectionJob

    detection_id = f"detjob-{scan_run_id[:30]}"
    now = _utcnow()
    detection_job = DetectionJob(
        id=detection_id,
        config_id=config_id,
        sync_id=sync_id,
        status="completed",
        queued_at=now,
        started_at=now,
        completed_at=now,
    )
    session.add(detection_job)
    session.flush()
    return detection_id


__all__ = [
    "SENTINEL_USER_ID",
    "config_id_for",
    "create_detection_job",
    "create_sync_operation",
    "ensure_sentinel_config",
    "ensure_sentinel_user",
]
