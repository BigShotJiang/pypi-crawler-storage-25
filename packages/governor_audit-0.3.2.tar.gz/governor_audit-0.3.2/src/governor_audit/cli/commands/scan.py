"""``governor-audit scan`` — fetch INFORMATION_SCHEMA + run detection rules.

Per [contracts/cli.md § scan](../../../../specs/141-production-audit/contracts/cli.md#scan).
Exit codes are part of the user-facing contract.
"""

from __future__ import annotations

import logging
from typing import Annotated, Optional

import typer
from rich.console import Console

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.db.session import (
    build_engine,
    create_all,
    make_session_factory,
    session_scope,
)
from governor_audit.scan.bigquery_client import build_default_client
from governor_audit.scan.lock import ScanLockHeldError, acquire_scan_lock
from governor_audit.scan.orchestrator import run_scan

EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_BAD_ARGS = 2
EXIT_LOCK_HELD = 7
EXIT_BIGQUERY_ERROR = 9


def scan_command(
    days: Annotated[
        Optional[int],
        typer.Option("--days", help="Lookback window. Defaults to config."),
    ] = None,
    min_cost: Annotated[
        Optional[float],
        typer.Option("--min-cost", help="Filter findings below this USD. Defaults to config."),
    ] = None,
    full_refresh: Annotated[
        bool,
        typer.Option("--full-refresh/--incremental", help="Evict cached jobs and re-fetch."),
    ] = False,
    dbt_only: Annotated[
        Optional[bool],
        typer.Option(
            "--dbt-only/--no-dbt-only",
            help=(
                "Narrow to dbt-originated jobs (queries starting with "
                "/* {\"app\": \"dbt\"). Defaults to config.scan_defaults.dbt_only."
            ),
        ),
    ] = None,
) -> None:
    """Run a fresh scan against BigQuery INFORMATION_SCHEMA."""
    console = Console()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    try:
        config = load_config()
    except ConfigNotFoundError as exc:
        console.print(f"[red]✗[/] {exc}")
        raise typer.Exit(EXIT_BAD_ARGS) from None

    bq_client = build_default_client(
        project_id=config.gcp_project_id,
        region=config.bigquery_region,
    )

    engine = build_engine()
    create_all(engine)
    session_factory = make_session_factory(engine)

    try:
        with acquire_scan_lock():
            with session_scope(session_factory) as session:
                result = run_scan(
                    config=config,
                    session=session,
                    bq_client=bq_client,
                    lookback_days=days,
                    dbt_only=dbt_only,
                )
    except ScanLockHeldError as exc:
        console.print(f"[red]✗[/] {exc}")
        raise typer.Exit(EXIT_LOCK_HELD) from None
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]✗[/] BigQuery query failed: {exc}")
        raise typer.Exit(EXIT_BIGQUERY_ERROR) from None

    filter_label = "dbt-originated only" if result.dbt_only_filter else "all jobs"
    if result.lookback_clamp_warning:
        console.print(f"[yellow]⚠ {result.lookback_clamp_warning}[/]")

    console.print(
        f"\n[green]Scan succeeded[/] ({filter_label}). "
        f"Fetched {result.fresh_job_count} jobs "
        f"({result.dbt_originated_job_count} dbt-originated, "
        f"{result.unique_query_hash_count} unique query patterns), "
        f"actual cost {result.cost_usd:.4f} USD.\n"
    )
    console.print("Open [cyan]http://localhost:8765[/] to browse "
                  "(run `make audit-run` to start the local UI).")
