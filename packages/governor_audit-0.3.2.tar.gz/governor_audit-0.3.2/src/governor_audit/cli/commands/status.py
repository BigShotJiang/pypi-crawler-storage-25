"""``governor-audit status`` — print current config + last scan + server state."""

from __future__ import annotations

import json as _json
from typing import Annotated

import typer
from rich.console import Console

from governor_audit.config.loader import ConfigNotFoundError, load_config
from governor_audit.version import get_app_version


def status_command(
    json: Annotated[
        bool,
        typer.Option("--json", help="Emit a single JSON object."),
    ] = False,
) -> None:
    """Print the current state of the package."""
    console = Console()
    try:
        config = load_config()
    except ConfigNotFoundError:
        if json:
            console.print(_json.dumps({"configured": False, "version": get_app_version()}))
        else:
            console.print("governor-audit is not yet configured.")
            console.print("Run [cyan]governor-audit init --help[/] to begin.")
        raise typer.Exit(0)

    payload = {
        "configured": True,
        "version": get_app_version(),
        "gcp_project_id": config.gcp_project_id,
        "bigquery_region": config.bigquery_region,
        "manifest": {
            "content_hash": config.manifest.content_hash,
            "uploaded_at": config.manifest.uploaded_at.isoformat(),
            "model_count": config.manifest.model_count,
        },
        "web_ui": {
            "port": config.web_ui.port,
            "bind_address": config.web_ui.bind_address,
        },
    }
    if json:
        console.print(_json.dumps(payload, indent=2))
        raise typer.Exit(0)

    console.print(f"[bold]Governor Audit v{get_app_version()}[/]\n")
    console.print(f"Project:  [cyan]{config.gcp_project_id}[/]")
    console.print(f"Region:   [cyan]{config.bigquery_region}[/]")
    console.print(
        f"Manifest: [cyan]{config.manifest.content_hash[:19]}…[/] "
        f"({config.manifest.model_count} models, "
        f"uploaded {config.manifest.uploaded_at.strftime('%Y-%m-%d %H:%M UTC')})"
    )
    console.print(
        f"Web UI:   http://{config.web_ui.bind_address}:{config.web_ui.port}"
    )
