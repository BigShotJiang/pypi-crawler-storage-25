"""``governor-audit reset`` — wipe cached scan data.

Drops every BigQuery job, opportunity, detection-history, and scan-run
row collected from past scans. The configuration file
(``~/.governor-audit/config.json``) is preserved — you don't need to
re-enter project / region / region after a reset, just run a fresh
scan to repopulate.

Use cases:
- The cache picked up rows from a project you no longer audit.
- A bad scan run inserted nonsense data and you want a clean baseline.
- You're handing off the laptop and want the cache zero'd before you do.
"""

from __future__ import annotations

import logging
from typing import Annotated

import typer
from rich.console import Console

logger = logging.getLogger("governor_audit.cli.reset")
console = Console()


def reset_command(
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip the confirmation prompt. Use in non-interactive scripts.",
        ),
    ] = False,
) -> None:
    """Wipe all cached scan data. Configuration is preserved."""
    # Lazy imports — avoid pulling SQLAlchemy / governor-core into
    # `governor-audit --help` so the help screen stays snappy.
    from governor_audit.db.models import AuditOpportunityMetadata, ScanRun
    from governor_audit.db.session import (
        build_engine,
        create_all,
        make_session_factory,
        session_scope,
    )
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import (
        DetectionJob,
        Opportunity,
        OpportunityDetectionHistory,
    )
    from governor_core.sync.models import (
        BigQueryJob,
        SyncOperation,
        TableColumnMetadata,
        TableStorageMetric,
    )

    if not yes:
        console.print(
            "[bold red]This will permanently delete[/] every cached "
            "BigQuery job, opportunity, detection history, and scan-run "
            "row from the local cache."
        )
        console.print(
            "Configuration ([cyan]~/.governor-audit/config.json[/]) is preserved."
        )
        if not typer.confirm("Continue?", default=False):
            console.print("[yellow]Aborted.[/] Nothing was deleted.")
            raise typer.Exit(1)

    engine = build_engine()
    create_all(engine)
    factory = make_session_factory(engine)

    with session_scope(factory) as session:
        jobs_deleted = session.query(BigQueryJob).delete(synchronize_session=False)
        opps_deleted = session.query(Opportunity).delete(synchronize_session=False)
        storage_deleted = session.query(TableStorageMetric).delete(
            synchronize_session=False
        )
        # Children of opportunities / scans / configs.
        session.query(OpportunityDetectionHistory).delete(synchronize_session=False)
        session.query(AuditOpportunityMetadata).delete(synchronize_session=False)
        session.query(TableColumnMetadata).delete(synchronize_session=False)
        session.query(DetectionJob).delete(synchronize_session=False)
        session.query(SyncOperation).delete(synchronize_session=False)
        scans_deleted = session.query(ScanRun).delete(synchronize_session=False)
        # Drop the audit sentinel ManifestConfiguration too — the next
        # scan recreates it from the config file.
        session.query(ManifestConfiguration).delete(synchronize_session=False)

    logger.info(
        "audit reset: deleted %d jobs, %d opportunities, %d storage rows, %d scans",
        jobs_deleted,
        opps_deleted,
        storage_deleted,
        scans_deleted,
    )
    console.print(
        f"[green]✓[/] Deleted {jobs_deleted:,} cached job(s), "
        f"{opps_deleted:,} opportunit{'y' if opps_deleted == 1 else 'ies'}, "
        f"{storage_deleted:,} storage metric(s), "
        f"and {scans_deleted:,} scan run(s)."
    )
    console.print(
        "Run [cyan]governor-audit scan[/] (or open the web UI) to repopulate."
    )


__all__ = ["reset_command"]
