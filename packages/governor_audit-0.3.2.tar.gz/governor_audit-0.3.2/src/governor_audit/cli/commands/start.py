"""``governor-audit start`` — boot the local web UI.

- Default = backgrounded subprocess; pidfile at ~/.governor-audit/server.pid;
  logs at ~/.governor-audit/server.log; ``governor-audit stop`` terminates.
- ``--fg`` runs uvicorn in the foreground (Ctrl+C to stop), for users
  who want to stay attached.

Loopback-only: bind defaults to 127.0.0.1 (the FastAPI app rejects
non-loopback Host: headers as defence-in-depth). Optionally opens the
default browser once the server is reachable.
"""

from __future__ import annotations

import logging
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from typing import Annotated

import typer
from rich.console import Console

from governor_audit.cli import state as _state
from governor_audit.config.loader import ensure_config_dir

logger = logging.getLogger("governor_audit.cli.start")
console = Console()


def _port_in_use(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.2)
        try:
            s.connect((host, port))
            return True
        except OSError:
            return False


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _wait_for_server(
    proc: subprocess.Popen, host: str, port: int, timeout_seconds: float = 15.0
) -> tuple[bool, int | None]:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        exit_code = proc.poll()
        if exit_code is not None:
            return False, exit_code
        if _port_in_use(host, port):
            return True, None
        time.sleep(0.2)
    return False, None


def _open_browser_when_ready(url: str, host: str, port: int) -> None:
    """Wait until uvicorn binds, then open the default browser. Bounded
    so we don't spin if uvicorn fails to come up."""
    for _ in range(40):  # ~4 seconds
        if _port_in_use(host, port):
            webbrowser.open(url)
            return
        time.sleep(0.1)


def start_command(
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Bind address. Must be a loopback IP — non-loopback values are "
             "rejected by the LoopbackOnlyMiddleware regardless.",
    ),
    port: int = typer.Option(
        8765,
        "--port",
        "-p",
        help="Port to bind. Default 8765.",
    ),
    reload: bool = typer.Option(
        False,
        "--reload",
        help="Enable uvicorn auto-reload (dev only). Implies --fg.",
    ),
    open_browser: bool = typer.Option(
        True,
        "--open/--no-open",
        help="Open the URL in your default browser once the server boots.",
    ),
    fg: bool = typer.Option(
        False,
        "--fg",
        help="Run uvicorn in the foreground (blocks until Ctrl+C). "
             "Default: backgrounded subprocess; use `governor-audit stop` "
             "to terminate.",
    ),
) -> None:
    """Start the local web UI and (optionally) open it in your browser.

    First-run users are routed through the /setup wizard automatically —
    no `governor-audit init` step required. Re-runs land on the dashboard.
    """
    url = f"http://{host}:{port}"

    # Check for an existing managed server.
    existing_pid = _state.read_pid()
    if existing_pid and _is_process_running(existing_pid):
        if _port_in_use(host, port):
            console.print(
                f"[green]Server already running[/] on {url} "
                f"(PID {existing_pid})"
            )
            if open_browser:
                webbrowser.open(url)
            return
    elif existing_pid:
        # Stale pidfile — clean up before starting fresh.
        _state.clear_pid()

    # `--reload` requires uvicorn to manage its own process tree, which
    # doesn't play well with pidfile + subprocess detach. Force foreground.
    if reload and not fg:
        fg = True
        console.print("[yellow]--reload implies --fg; running in foreground.[/]")

    if fg:
        console.print(f"[bold]Governor Audit[/bold] → {url}")
        console.print("  • First run? The browser will walk you through setup.")
        console.print("  • Press [bold]Ctrl+C[/bold] to stop.")
        if open_browser:
            threading.Thread(
                target=_open_browser_when_ready,
                args=(url, host, port),
                daemon=True,
            ).start()
        # Lazy import — keeps `governor-audit --help` snappy.
        import uvicorn
        uvicorn.run(
            "governor_audit.web.main:app",
            host=host,
            port=port,
            reload=reload,
            log_level="info",
        )
        return

    # ── Backgrounded path ──────────────────────────────────────────────
    ensure_config_dir()
    log_path = _state.log_file()
    log_handle = log_path.open("ab")
    try:
        proc = subprocess.Popen(
            [
                sys.executable, "-m", "uvicorn",
                "governor_audit.web.main:app",
                "--host", host,
                "--port", str(port),
                "--log-level", "info",
            ],
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log_handle.close()

    ready, exit_code = _wait_for_server(proc, host, port)
    if not ready:
        _state.clear_pid()
        if exit_code is None:
            proc.terminate()
            reason = "did not become ready within 15 seconds"
        else:
            reason = f"exited with code {exit_code}"
        console.print(f"[red]Server failed to start:[/] {reason}")
        console.print(f"  See logs: {log_path}")
        raise typer.Exit(code=1)

    _state.write_pid(proc.pid)
    console.print(f"[green]Server started[/] on {url} (PID {proc.pid})")
    console.print(f"  Logs: {log_path}")
    console.print("  Stop: [bold]governor-audit stop[/]")

    if open_browser:
        webbrowser.open(url)


__all__ = ["start_command"]
