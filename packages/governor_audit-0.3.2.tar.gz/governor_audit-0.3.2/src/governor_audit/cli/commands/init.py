"""``governor-audit init`` — configure the audit target.

Per [contracts/cli.md § init](../../../../specs/141-production-audit/contracts/cli.md#init).
Argument names, exit codes, and message format are part of the
user-facing contract.

**v2 change**: no ``--manifest`` argument. The package never reads a
manifest. ``--dbt-only-default`` added so the user can persist their
preferred default for the per-scan ``--dbt-only`` flag.
"""

from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

from governor_audit.auth.adc import ProbeStatus, probe_adc
from governor_audit.config.loader import (
    ConfigNotFoundError,
    load_config,
    save_config,
)
from governor_audit.config.schema import (
    DEFAULT_LOOKBACK_DAYS,
    DEFAULT_PORT,
    AuditConfig,
    ScanDefaults,
    WebUIConfig,
)

EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_BAD_ARGS = 2
EXIT_ADC_MISSING = 3
EXIT_CONFIG_CONFLICT = 4
EXIT_IAM_INSUFFICIENT = 6


def init_command(
    project: Annotated[
        str,
        typer.Option(
            "--project", help="GCP project ID being audited.", show_default=False
        ),
    ],
    region: Annotated[
        str,
        typer.Option(
            "--region",
            help="BigQuery region (e.g. 'us', 'australia-southeast1').",
            show_default=False,
        ),
    ],
    port: Annotated[
        int,
        typer.Option("--port", help="Local web UI port.", min=1024, max=65535),
    ] = DEFAULT_PORT,
    lookback_days: Annotated[
        int,
        typer.Option(
            "--lookback-days",
            help="Default --days for `scan` when not specified.",
            min=1,
            max=365,
        ),
    ] = DEFAULT_LOOKBACK_DAYS,
    dbt_only_default: Annotated[
        bool,
        typer.Option(
            "--dbt-only-default/--all-jobs-default",
            help=(
                "Default value of --dbt-only for `scan` when not passed. "
                "When True, scans narrow to queries starting with "
                "/* {\"app\": \"dbt\". Per-scan override always wins."
            ),
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force/--no-force",
            help="Overwrite an existing config when fields conflict.",
        ),
    ] = False,
) -> None:
    """Configure governor-audit against a project / region."""
    console = Console()

    # Step 1 — refuse to silently overwrite a conflicting config.
    if not force:
        try:
            existing = load_config()
        except ConfigNotFoundError:
            existing = None
        if existing is not None:
            conflicts: list[str] = []
            if existing.gcp_project_id != project:
                conflicts.append(
                    f"  gcp_project_id: {existing.gcp_project_id!r} → {project!r}"
                )
            if existing.bigquery_region.lower() != region.lower():
                conflicts.append(
                    f"  bigquery_region: {existing.bigquery_region!r} → {region!r}"
                )
            if conflicts:
                console.print(
                    "[bold red]Existing config conflicts with the new arguments:[/]\n"
                    + "\n".join(conflicts)
                    + "\n\nRe-run with --force to overwrite, or use "
                    "`governor-audit config <key> <value>` for a single field."
                )
                raise typer.Exit(EXIT_CONFIG_CONFLICT)

    # Step 2 — probe ADC against the requested project + region.
    console.print(f"Probing ADC against {project} / {region}…")
    probe = probe_adc(project, region)
    if probe.status is ProbeStatus.ADC_MISSING:
        console.print(f"[bold red]✗[/] {probe.message}")
        raise typer.Exit(EXIT_ADC_MISSING)
    if probe.status is ProbeStatus.IAM_INSUFFICIENT:
        console.print(f"[bold red]✗[/] {probe.message}")
        raise typer.Exit(EXIT_IAM_INSUFFICIENT)
    if probe.status is ProbeStatus.REGION_UNKNOWN:
        console.print(f"[bold red]✗[/] {probe.message}")
        raise typer.Exit(EXIT_BAD_ARGS)
    if not probe.ok:
        console.print(f"[bold red]✗[/] ADC probe failed: {probe.message}")
        raise typer.Exit(EXIT_GENERIC)
    console.print(
        f"[green]✓[/] ADC verified — authenticated"
        f"{' as ' + probe.principal if probe.principal else ''}"
    )

    # Step 3 — write config.
    config = AuditConfig.model_validate({
        "gcp_project_id": project,
        "bigquery_region": region,
        "scan_defaults": ScanDefaults(
            lookback_days=lookback_days,
            dbt_only=dbt_only_default,
        ),
        "web_ui": WebUIConfig(port=port),
    })
    saved_path = save_config(config)
    console.print(f"[green]✓[/] Config written to {saved_path}\n")

    # Step 4 — friendly hint.
    console.print("Next: run a scan")
    if dbt_only_default:
        console.print("  [cyan]governor-audit scan[/]  [dim](dbt-only by default)[/]")
    else:
        console.print("  [cyan]governor-audit scan[/]")
        console.print("  [cyan]governor-audit scan --dbt-only[/]  [dim](narrow to dbt-originated jobs)[/]")
