"""Pidfile + log-file helpers for the managed web server.

Files live under ``~/.governor-audit/`` next to ``config.json`` so the
release flow (`make audit-reset`) wipes them in one go.
"""

from __future__ import annotations

from pathlib import Path

from governor_audit.config.loader import config_dir as _config_dir


def pid_file(dir_override: Path | None = None) -> Path:
    return _config_dir(dir_override) / "server.pid"


def log_file(dir_override: Path | None = None) -> Path:
    return _config_dir(dir_override) / "server.log"


def read_pid(dir_override: Path | None = None) -> int | None:
    """Return the managed server's PID, or None if no pidfile / invalid."""
    path = pid_file(dir_override)
    if not path.exists():
        return None
    try:
        return int(path.read_text().strip())
    except (OSError, ValueError):
        return None


def write_pid(pid: int, dir_override: Path | None = None) -> None:
    path = pid_file(dir_override)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(pid))


def clear_pid(dir_override: Path | None = None) -> None:
    try:
        pid_file(dir_override).unlink()
    except FileNotFoundError:
        pass


__all__ = ["pid_file", "log_file", "read_pid", "write_pid", "clear_pid"]
