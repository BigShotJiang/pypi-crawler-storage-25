"""SQLAlchemy engine + session factory for ``~/.governor-audit/state.db``.

Single-process, single-tenant SQLite with WAL mode. The compat shim is
applied to the metadata at import time of ``governor_audit.db.base``;
this module just builds the engine + session.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

# Importing ``base`` triggers metadata registration + sqlite_compat shim.
from governor_audit.config.loader import config_dir, ensure_config_dir
from governor_audit.db.base import Base, attach_sqlite_pragmas

DB_FILENAME = "state.db"
DB_FILE_MODE = 0o600


def db_path(dir_override: Path | None = None) -> Path:
    return config_dir(dir_override) / DB_FILENAME


def database_url(dir_override: Path | None = None) -> str:
    return f"sqlite:///{db_path(dir_override)}"


def build_engine(
    *,
    dir_override: Path | None = None,
    in_memory: bool = False,
) -> Engine:
    """Build a SQLAlchemy engine pointing at the audit cache."""
    if in_memory:
        url = "sqlite:///:memory:"
    else:
        ensure_config_dir(dir_override)
        url = database_url(dir_override)
    engine = create_engine(url, future=True)
    attach_sqlite_pragmas(engine)
    return engine


def create_all(engine: Engine) -> None:
    """Create every table registered on ``Base.metadata`` (core + audit)."""
    Base.metadata.create_all(engine)


def chmod_db_file(dir_override: Path | None = None) -> None:
    """Apply 0600 to the on-disk SQLite file. No-op if file is missing."""
    path = db_path(dir_override)
    if path.exists():
        os.chmod(path, DB_FILE_MODE)


def make_session_factory(engine: Engine):
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)


@contextmanager
def session_scope(session_factory):
    """Provide a transactional scope around a series of operations."""
    session: Session = session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


__all__ = [
    "DB_FILENAME",
    "Base",
    "build_engine",
    "chmod_db_file",
    "create_all",
    "database_url",
    "db_path",
    "make_session_factory",
    "session_scope",
]
