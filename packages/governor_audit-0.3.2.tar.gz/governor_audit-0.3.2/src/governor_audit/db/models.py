"""governor-audit's own SQLite tables: ``ScanRun`` + ``AuditOpportunityMetadata``.

The reused tables (``BigQueryJob``, ``Opportunity``, ``DetectionJob``,
``ManifestConfiguration``, etc.) come from ``governor_core`` ORM models
via the shared ``Base.metadata``. We do NOT redeclare them — see
data-model.md § "Tables imported from governor-core".

Audit-specific indexes on the reused ``bigquery_jobs`` table are added
at the bottom of this module (after model registration) so they live in
the audit-side schema without modifying the upstream model class.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column

from governor_core.db.base import Base


def _utcnow() -> datetime:
    from datetime import timezone
    return datetime.now(timezone.utc)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


class ScanRun(Base):
    """One row per ``governor-audit scan`` invocation.

    Audit-of-audit log surface — every BigQuery query the package issues
    is recorded with its dry-run estimate, actual bytes billed, manifest
    hash in effect, and resulting opportunity count. Surfaced in the
    web UI under ``/scans``.
    """

    __tablename__ = "scan_runs"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="running")
    requested_lookback_days: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_window_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    actual_window_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    cached_job_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    fetched_job_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    dry_run_estimated_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    actual_bytes_billed: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True
    )
    estimated_cost_usd: Mapped[Decimal] = mapped_column(
        Numeric(10, 4), nullable=False, default=Decimal("0")
    )
    actual_cost_usd: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 4), nullable=True
    )
    gcp_project_id: Mapped[str] = mapped_column(String(64), nullable=False)
    bigquery_region: Mapped[str] = mapped_column(String(64), nullable=False)
    # NEW: tracks whether this scan was filtered to dbt-originated jobs.
    # Cached rows from the opposite filter setting are not reusable for
    # the other filter, so this is the cache-key discriminator too.
    dbt_only_filter: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    opportunity_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    failure_reason: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    failure_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow, onupdate=_utcnow
    )

    @staticmethod
    def new_id() -> str:
        return _new_id("scan")


class AuditOpportunityMetadata(Base):
    """Audit-side provenance for each opportunity row.

    Sidecar table — does NOT modify ``governor_core.opportunities.models.Opportunity``
    (which would violate FR-042). Carries: which scan produced this
    opportunity, dbt attribution derived from BigQuery labels at scan
    time (manifest-free), and the normalized-literals query hash used
    for grouping near-identical queries.

    **v2 change**: ``manifest_content_hash`` and ``is_stale`` removed
    (no manifest to track). ``is_dbt_originated`` added.

    **v2.1 change** (this commit): ``dbt_node_id``,
    ``dbt_invocation_id``, ``query_hash`` added. All three are derived
    from BigQuery's INFORMATION_SCHEMA columns at scan time — no
    governor-core schema change required.
    """

    __tablename__ = "audit_opportunity_metadata"

    opportunity_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("opportunities.id", ondelete="CASCADE"),
        primary_key=True,
    )
    scan_run_id: Mapped[str] = mapped_column(
        String(80),
        ForeignKey("scan_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    is_dbt_originated: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    # NEW: dbt attribution from BigQuery labels (manifest-free). All
    # nullable because non-dbt jobs (analyst SQL, BI tools, etc.) don't
    # carry these labels.
    dbt_node_id: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        doc="dbt node identifier from labels.node_id, e.g. 'model.warehouse.fct_orders'",
    )
    dbt_invocation_id: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        doc="dbt invocation UUID from labels.dbt_invocation_id, groups jobs from one `dbt run`",
    )
    # NEW: query-hash grouping. From query_info.query_hashes.normalized_literals.
    # Same hash → same logical query (different literals/comments/parameters).
    # Lets the UI roll up "1247 occurrences of this query" instead of
    # 1247 individual findings.
    query_hash: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        doc="normalized_literals hash from query_info.query_hashes",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )


# Audit-side indexes on the reused bigquery_jobs table — added after
# model registration so they don't require touching the upstream model.
# These accelerate the incremental-fetch and findings-attribution
# workflows critical to scan performance (SC-002 / SC-003).
_bq_jobs_table = Base.metadata.tables.get("bigquery_jobs")
if _bq_jobs_table is not None:
    Index(
        "ix_audit_bigquery_jobs_creation_time",
        _bq_jobs_table.c.creation_time,
    )

Index("ix_audit_scan_runs_started_at", ScanRun.started_at)
Index("ix_audit_scan_runs_status", ScanRun.status)

# Roll-up indexes for the UI: "show me all findings for this dbt model"
# / "group by query hash". Both are nullable, but indexed where present.
Index("ix_audit_opp_metadata_dbt_node_id", AuditOpportunityMetadata.dbt_node_id)
Index("ix_audit_opp_metadata_query_hash", AuditOpportunityMetadata.query_hash)


__all__ = ["ScanRun", "AuditOpportunityMetadata"]
