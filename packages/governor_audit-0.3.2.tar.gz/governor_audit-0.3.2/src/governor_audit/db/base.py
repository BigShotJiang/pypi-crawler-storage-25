"""Shared SQLAlchemy ``Base`` for governor-audit's SQLite cache.

Re-exports ``governor_core.db.base.Base`` so the audit package's
SQLite cache sits on the same metadata as the cloud version's
Postgres schema. Detection rules consume ``BigQueryJob`` and
``Opportunity`` ORM instances directly without translation
(see data-model.md § Reuse of governor-core).

Importing this module transitively registers every core ORM table —
including ``shadow_validation_runs`` and ``pull_request_records`` that
governor-audit doesn't use. The schema rows are inert metadata-only;
no behavioural code is loaded. The forbidden-imports linter (T024)
checks for *direct* imports from those packages in `governor_audit.*`,
not the transitive metadata registration through ``governor_core.db.base``.

The SQLite compat shim is applied exactly once at module import time;
it's idempotent (per its docstring), so re-imports are no-ops.
"""

from __future__ import annotations

from governor_core.db.base import Base
from governor_core.db.sqlite_compat import (
    apply_sqlite_compat,
    attach_sqlite_pragmas,
    declare_web_stub_tables,
)

# Core ORM models declare ForeignKey("users.id") and similar; the
# canonical ``users`` table lives in governor_web. Without governor_web
# being imported, schema sort fails. Declare minimal stubs so create_all
# can resolve the FKs without governor_web in the dependency tree.
declare_web_stub_tables(Base.metadata)

# Apply the SQLite shim to ALL registered tables (core + audit's own
# additions, which register themselves below in db/models.py).
apply_sqlite_compat(Base.metadata)

# Eagerly import this package's own models so they register with the
# shared metadata before any caller calls create_all().
from governor_audit.db import models as _audit_models  # noqa: F401, E402

# Re-apply the shim to pick up any audit-owned columns (idempotent).
apply_sqlite_compat(Base.metadata)


__all__ = ["Base", "apply_sqlite_compat", "attach_sqlite_pragmas"]
