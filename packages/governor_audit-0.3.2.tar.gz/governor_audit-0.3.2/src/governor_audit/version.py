from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version


def get_app_version() -> str:
    """Return the installed governor-audit package version."""
    try:
        return version("governor-audit")
    except PackageNotFoundError:
        return "0.0.0"
