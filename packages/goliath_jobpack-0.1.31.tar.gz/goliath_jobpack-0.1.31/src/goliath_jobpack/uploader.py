from __future__ import annotations

import hashlib
import hmac
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac_sha256(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _get_signing_key(secret: str, date_stamp: str, region: str, service: str) -> bytes:
    k_date = _hmac_sha256(f"AWS4{secret}".encode("utf-8"), date_stamp)
    k_region = _hmac_sha256(k_date, region)
    k_service = _hmac_sha256(k_region, service)
    return _hmac_sha256(k_service, "aws4_request")


def _resolve_credentials() -> tuple[str, str, str | None]:
    """Return (access_key, secret_key, session_token) from environment."""
    access_key = os.environ.get("AWS_ACCESS_KEY_ID", "")
    secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
    session_token = os.environ.get("AWS_SESSION_TOKEN")

    if not access_key or not secret_key:
        raise RuntimeError(
            "AWS credentials not found. Set AWS_ACCESS_KEY_ID and "
            "AWS_SECRET_ACCESS_KEY environment variables."
        )

    return access_key, secret_key, session_token


def _resolve_region(region: str | None) -> str:
    if region:
        return region
    return os.environ.get("AWS_DEFAULT_REGION", os.environ.get("AWS_REGION", "us-east-1"))


def upload_file_to_s3(
    *,
    file_path: Path,
    bucket: str,
    key: str,
    region: str | None = None,
) -> dict:
    access_key, secret_key, session_token = _resolve_credentials()
    region = _resolve_region(region)

    payload = file_path.read_bytes()
    payload_hash = _sha256(payload)
    content_type = "application/zip"

    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")

    host = f"{bucket}.s3.{region}.amazonaws.com"
    url = f"https://{host}/{key}"

    # Build canonical headers
    headers: dict[str, str] = {
        "host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
        "content-type": content_type,
    }
    if session_token:
        headers["x-amz-security-token"] = session_token

    signed_header_names = sorted(headers.keys())
    signed_headers_str = ";".join(signed_header_names)
    canonical_headers = "".join(f"{k}:{headers[k]}\n" for k in signed_header_names)

    canonical_request = "\n".join([
        "PUT",
        f"/{key}",
        "",  # no query string
        canonical_headers,
        signed_headers_str,
        payload_hash,
    ])

    credential_scope = f"{date_stamp}/{region}/s3/aws4_request"
    string_to_sign = "\n".join([
        "AWS4-HMAC-SHA256",
        amz_date,
        credential_scope,
        _sha256(canonical_request.encode("utf-8")),
    ])

    signing_key = _get_signing_key(secret_key, date_stamp, region, "s3")
    signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization = (
        f"AWS4-HMAC-SHA256 Credential={access_key}/{credential_scope}, "
        f"SignedHeaders={signed_headers_str}, Signature={signature}"
    )

    request_headers = {
        "Authorization": authorization,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
        "Content-Type": content_type,
    }
    if session_token:
        request_headers["x-amz-security-token"] = session_token

    req = urllib.request.Request(url, data=payload, headers=request_headers, method="PUT")

    try:
        urllib.request.urlopen(req)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"S3 upload failed (HTTP {exc.code}): {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"S3 upload failed: {exc.reason}") from exc

    return {
        "bucket": bucket,
        "key": key,
        "file_name": file_path.name,
    }
