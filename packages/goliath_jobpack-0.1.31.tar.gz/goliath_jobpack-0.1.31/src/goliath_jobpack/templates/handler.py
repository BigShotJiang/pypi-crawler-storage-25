from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


async def main(event: dict, context: dict) -> dict:
    logger.info("Hello from Goliath job packager")
    logger.info("Event: %s", event)
    logger.info("Context: %s", context)

    return {
        "success": True,
        "message": "Job completed successfully",
    }


if __name__ == "__main__":
    sample_event = {"job_id": "example-123", "action": "process"}
    sample_context = {"region": "us-east-1", "timeout": 300}
    asyncio.run(main(sample_event, sample_context))
