"""Generate markdown and HTML documentation from goliath-jobpack source code."""
from __future__ import annotations

import ast
import textwrap
from dataclasses import dataclass, field
from pathlib import Path

import click

SRC_DIR = Path(__file__).parent

# Modules to document, in display order
DOCUMENTED_MODULES = [
    ("config", "Configuration"),
    ("builder", "Builder"),
    ("uploader", "Uploader"),
    ("utils", "Utilities"),
]

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>goliath-jobpack docs</title>
<style>
  :root {{
    --bg: #0e1117;
    --fg: #c9d1d9;
    --accent: #58a6ff;
    --accent2: #f0883e;
    --border: #30363d;
    --code-bg: #161b22;
    --card-bg: #161b22;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--fg);
    line-height: 1.6;
    max-width: 900px;
    margin: 0 auto;
    padding: 2rem 1.5rem;
  }}
  h1 {{
    color: var(--accent);
    font-size: 2rem;
    border-bottom: 2px solid var(--border);
    padding-bottom: 0.5rem;
    margin-bottom: 1.5rem;
  }}
  h2 {{
    color: var(--accent2);
    font-size: 1.4rem;
    margin-top: 2.5rem;
    margin-bottom: 0.75rem;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.3rem;
  }}
  h3 {{
    color: var(--accent);
    font-size: 1.1rem;
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
  }}
  h4 {{
    color: var(--fg);
    font-size: 1rem;
    margin-top: 1rem;
    margin-bottom: 0.3rem;
  }}
  code {{
    background: var(--code-bg);
    padding: 0.15em 0.4em;
    border-radius: 4px;
    font-size: 0.9em;
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
  }}
  pre {{
    background: var(--code-bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 1rem;
    overflow-x: auto;
    margin: 0.75rem 0;
  }}
  pre code {{
    background: none;
    padding: 0;
  }}
  p {{ margin: 0.5rem 0; }}
  ul, ol {{ padding-left: 1.5rem; margin: 0.5rem 0; }}
  li {{ margin: 0.25rem 0; }}
  table {{
    border-collapse: collapse;
    width: 100%;
    margin: 0.75rem 0;
  }}
  th, td {{
    border: 1px solid var(--border);
    padding: 0.5rem 0.75rem;
    text-align: left;
  }}
  th {{ background: var(--code-bg); color: var(--accent); }}
  hr {{ border: none; border-top: 1px solid var(--border); margin: 2rem 0; }}
  a {{ color: var(--accent); text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .version {{ color: #8b949e; font-size: 0.9rem; }}
</style>
</head>
<body>
{body}
</body>
</html>
"""


# ---------------------------------------------------------------------------
# AST extraction helpers
# ---------------------------------------------------------------------------

@dataclass
class FuncInfo:
    name: str
    args: str
    returns: str | None
    docstring: str | None
    decorators: list[str] = field(default_factory=list)
    is_async: bool = False


@dataclass
class ClassInfo:
    name: str
    bases: list[str]
    docstring: str | None
    fields: list[tuple[str, str, str | None]]  # (name, annotation, default)
    methods: list[FuncInfo]


@dataclass
class ModuleInfo:
    docstring: str | None
    functions: list[FuncInfo]
    classes: list[ClassInfo]
    constants: list[tuple[str, str]]  # (name, value_repr)


def _format_arg(arg: ast.arg) -> str:
    name = arg.arg
    if arg.annotation:
        name += f": {ast.unparse(arg.annotation)}"
    return name


def _extract_func(node: ast.FunctionDef | ast.AsyncFunctionDef) -> FuncInfo:
    args_parts: list[str] = []
    args_obj = node.args

    # Positional args (skip 'self'/'cls')
    positional = args_obj.args
    defaults = args_obj.defaults
    n_defaults = len(defaults)
    for i, arg in enumerate(positional):
        if arg.arg in ("self", "cls"):
            continue
        s = _format_arg(arg)
        default_idx = i - (len(positional) - n_defaults)
        if default_idx >= 0:
            s += f" = {ast.unparse(defaults[default_idx])}"
        args_parts.append(s)

    if args_obj.vararg:
        args_parts.append(f"*{_format_arg(args_obj.vararg)}")
    elif args_obj.kwonlyargs:
        args_parts.append("*")

    kw_defaults = args_obj.kw_defaults
    for i, arg in enumerate(args_obj.kwonlyargs):
        s = _format_arg(arg)
        if kw_defaults[i] is not None:
            s += f" = {ast.unparse(kw_defaults[i])}"
        args_parts.append(s)

    if args_obj.kwarg:
        args_parts.append(f"**{_format_arg(args_obj.kwarg)}")

    returns = ast.unparse(node.returns) if node.returns else None
    decorators = [ast.unparse(d) for d in node.decorator_list]
    docstring = ast.get_docstring(node)

    return FuncInfo(
        name=node.name,
        args=", ".join(args_parts),
        returns=returns,
        docstring=docstring,
        decorators=decorators,
        is_async=isinstance(node, ast.AsyncFunctionDef),
    )


def _extract_class(node: ast.ClassDef) -> ClassInfo:
    bases = [ast.unparse(b) for b in node.bases]
    docstring = ast.get_docstring(node)
    fields: list[tuple[str, str, str | None]] = []
    methods: list[FuncInfo] = []

    for child in ast.iter_child_nodes(node):
        if isinstance(child, ast.AnnAssign) and isinstance(child.target, ast.Name):
            ann = ast.unparse(child.annotation)
            default = ast.unparse(child.value) if child.value else None
            fields.append((child.target.id, ann, default))
        elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not child.name.startswith("_") or child.name == "__init__":
                methods.append(_extract_func(child))

    return ClassInfo(
        name=node.name,
        bases=bases,
        docstring=docstring,
        fields=fields,
        methods=methods,
    )


def parse_module(filepath: Path) -> ModuleInfo:
    """Parse a Python file and extract documentation-relevant info."""
    tree = ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))

    docstring = ast.get_docstring(tree)
    functions: list[FuncInfo] = []
    classes: list[ClassInfo] = []
    constants: list[tuple[str, str]] = []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not node.name.startswith("_"):
                functions.append(_extract_func(node))
        elif isinstance(node, ast.ClassDef):
            if not node.name.startswith("_"):
                classes.append(_extract_class(node))
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.isupper():
                    try:
                        val = ast.unparse(node.value)
                        if len(val) <= 120:
                            constants.append((target.id, val))
                    except Exception:
                        pass

    return ModuleInfo(
        docstring=docstring,
        functions=functions,
        classes=classes,
        constants=constants,
    )


# ---------------------------------------------------------------------------
# Click command extraction
# ---------------------------------------------------------------------------

def _extract_click_commands() -> list[dict]:
    """Extract Click command metadata from cli.py using AST."""
    filepath = SRC_DIR / "cli.py"
    tree = ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))

    commands: list[dict] = []
    for node in ast.iter_child_nodes(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        decorators = [ast.unparse(d) for d in node.decorator_list]
        is_command = any("cli.command" in d for d in decorators)
        if not is_command:
            continue

        # Extract arguments and options from decorators
        args: list[str] = []
        options: list[str] = []
        for dec in decorators:
            if "click.argument" in dec:
                # Pull out the first string arg
                for child in ast.walk(node.decorator_list[decorators.index(dec)]):
                    if isinstance(child, ast.Constant) and isinstance(child.value, str):
                        args.append(child.value)
                        break
            elif "click.option" in dec:
                for child in ast.walk(node.decorator_list[decorators.index(dec)]):
                    if isinstance(child, ast.Constant) and isinstance(child.value, str) and child.value.startswith("--"):
                        options.append(child.value)
                        break

        docstring = ast.get_docstring(node) or ""
        commands.append({
            "name": node.name,
            "docstring": docstring,
            "args": args,
            "options": options,
        })

    return commands


# ---------------------------------------------------------------------------
# Markdown generation
# ---------------------------------------------------------------------------

def _md_func(fn: FuncInfo) -> str:
    """Render a function as markdown."""
    prefix = "async " if fn.is_async else ""
    sig = f"`{prefix}def {fn.name}({fn.args})`"
    if fn.returns:
        sig += f" -> `{fn.returns}`"

    lines = [f"#### {fn.name}", "", sig, ""]
    if fn.docstring:
        lines.append(fn.docstring)
        lines.append("")
    return "\n".join(lines)


def _md_class(cls: ClassInfo) -> str:
    """Render a class as markdown."""
    bases_str = f"({', '.join(cls.bases)})" if cls.bases else ""
    lines = [f"### {cls.name}{bases_str}", ""]

    if cls.docstring:
        lines.append(cls.docstring)
        lines.append("")

    if cls.fields:
        lines.append("| Field | Type | Default |")
        lines.append("|-------|------|---------|")
        for name, ann, default in cls.fields:
            lines.append(f"| `{name}` | `{ann}` | {f'`{default}`' if default else '—'} |")
        lines.append("")

    for method in cls.methods:
        if method.name != "__init__":
            lines.append(_md_func(method))

    return "\n".join(lines)


def generate_markdown() -> str:
    """Generate full markdown documentation for goliath-jobpack."""
    from . import __version__

    parts: list[str] = []
    parts.append(f"# goliath-jobpack")
    parts.append("")
    parts.append(f"*Version {__version__}*")
    parts.append("")
    parts.append("Build and upload Python job packages for the Goliath scheduler.")
    parts.append("")

    # --- CLI commands section ---
    parts.append("## CLI Commands")
    parts.append("")
    parts.append("All commands are available via `goliath <command>`.")
    parts.append("")

    commands = _extract_click_commands()
    for cmd in commands:
        name = cmd["name"]
        parts.append(f"### goliath {name}")
        parts.append("")
        if cmd["docstring"]:
            parts.append(cmd["docstring"])
            parts.append("")
        usage_parts = [f"goliath {name}"]
        for a in cmd["args"]:
            usage_parts.append(f"[{a}]")
        for o in cmd["options"]:
            usage_parts.append(f"{o}")
        parts.append(f"```")
        parts.append(" ".join(usage_parts))
        parts.append("```")
        parts.append("")

    # --- Module sections ---
    for module_name, section_title in DOCUMENTED_MODULES:
        filepath = SRC_DIR / f"{module_name}.py"
        if not filepath.exists():
            continue

        info = parse_module(filepath)

        parts.append(f"## {section_title}")
        parts.append("")
        parts.append(f"`goliath_jobpack.{module_name}`")
        parts.append("")

        if info.docstring:
            parts.append(info.docstring)
            parts.append("")

        if info.constants:
            parts.append("**Constants:**")
            parts.append("")
            for name, value in info.constants:
                parts.append(f"- `{name}` = `{value}`")
            parts.append("")

        for cls in info.classes:
            parts.append(_md_class(cls))

        for fn in info.functions:
            parts.append(_md_func(fn))

    # --- Job format section ---
    parts.append("## Job Package Format")
    parts.append("")
    parts.append("Jobs are defined by a `job.toml` file:")
    parts.append("")
    toml_template = SRC_DIR / "templates" / "job.toml"
    if toml_template.exists():
        parts.append("```toml")
        parts.append(toml_template.read_text(encoding="utf-8").strip())
        parts.append("```")
        parts.append("")

    # --- Handler template section ---
    parts.append("## Handler Template")
    parts.append("")
    parts.append("The starter `handler.py` generated by `goliath init`:")
    parts.append("")
    handler_template = SRC_DIR / "templates" / "handler.py"
    if handler_template.exists():
        parts.append("```python")
        parts.append(handler_template.read_text(encoding="utf-8").strip())
        parts.append("```")
        parts.append("")

    return "\n".join(parts)


def _md_to_html(text: str) -> str:
    """Convert a subset of markdown to HTML (headings, code blocks, tables, inline markup, lists, paragraphs)."""
    import html as _html
    import re

    lines = text.split("\n")
    out: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # Fenced code blocks
        if line.startswith("```"):
            lang = line[3:].strip()
            code_lines: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code_lines.append(_html.escape(lines[i]))
                i += 1
            i += 1  # skip closing ```
            out.append(f"<pre><code>{'&#10;'.join(code_lines)}</code></pre>")
            continue

        # Headings
        if line.startswith("#"):
            m = re.match(r"^(#{1,6})\s+(.*)", line)
            if m:
                level = len(m.group(1))
                out.append(f"<h{level}>{_inline(m.group(2))}</h{level}>")
                i += 1
                continue

        # Horizontal rule
        if re.match(r"^---+\s*$", line):
            out.append("<hr>")
            i += 1
            continue

        # Table
        if "|" in line and i + 1 < len(lines) and re.match(r"^\|[-| :]+\|$", lines[i + 1].strip()):
            header_cells = [c.strip() for c in line.strip().strip("|").split("|")]
            i += 2  # skip header and separator
            rows: list[list[str]] = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            out.append("<table>")
            out.append("<tr>" + "".join(f"<th>{_inline(c)}</th>" for c in header_cells) + "</tr>")
            for row in rows:
                out.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in row) + "</tr>")
            out.append("</table>")
            continue

        # Unordered list
        if re.match(r"^[-*]\s+", line):
            out.append("<ul>")
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i]):
                content = re.sub(r"^[-*]\s+", "", lines[i])
                out.append(f"<li>{_inline(content)}</li>")
                i += 1
            out.append("</ul>")
            continue

        # Ordered list
        if re.match(r"^\d+\.\s+", line):
            out.append("<ol>")
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                content = re.sub(r"^\d+\.\s+", "", lines[i])
                out.append(f"<li>{_inline(content)}</li>")
                i += 1
            out.append("</ol>")
            continue

        # Blank line
        if not line.strip():
            i += 1
            continue

        # Paragraph
        out.append(f"<p>{_inline(line)}</p>")
        i += 1

    return "\n".join(out)


def _inline(text: str) -> str:
    """Handle inline markdown: code, bold, italic, links."""
    import html as _html
    import re

    # Inline code (must be first to avoid processing markup inside code)
    parts: list[str] = []
    last = 0
    for m in re.finditer(r"`([^`]+)`", text):
        parts.append(_apply_inline_markup(_html.escape(text[last:m.start()])))
        parts.append(f"<code>{_html.escape(m.group(1))}</code>")
        last = m.end()
    parts.append(_apply_inline_markup(_html.escape(text[last:])))
    return "".join(parts)


def _apply_inline_markup(text: str) -> str:
    """Apply bold, italic, and link markup to already-escaped text."""
    import re

    # Bold
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Italic
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    return text


def generate_html(markdown_text: str) -> str:
    """Convert markdown to a styled HTML page."""
    body = _md_to_html(markdown_text)
    return HTML_TEMPLATE.format(body=body)
