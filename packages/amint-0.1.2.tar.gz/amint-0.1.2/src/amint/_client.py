from __future__ import annotations

from ._tracing import TracerWrapper, TracerConfig
from ._exceptions import AmintError


class Amint:
    _instance: Amint | None = None

    def __init__(self, config: TracerConfig):
        self._tracer_wrapper = TracerWrapper(config=config)

    @staticmethod
    def init(api_key: str | None = None):
        if Amint._instance is not None:
            return

        if not api_key:
            raise AmintError("Set the api_key")

        config = TracerConfig(
            headers={"Authorization": f"Bearer {api_key}"}
        )

        Amint._instance = Amint(config=config)