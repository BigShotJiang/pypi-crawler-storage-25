#!/bin/bash
if [[ "$OSTYPE" != "darwin"* ]]; then
	echo 'This script is intended to be run on macOS.'
	exit 1
fi
if [[ "$STDBUF_ACTIVE" != "1" ]]; then
	export STDBUF_ACTIVE=1
	exec stdbuf -oL "$0" "$@"
fi
while getopts "hn:" opt; do
	case $opt in
	h)
		echo "Usage: $0 [-h] [-n]"
		exit 0
		;;
	n) DRY=true ;;
	*)
		echo "Invalid option"
		exit 1
		;;
	esac
done
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
cd "${SCRIPT_DIR}/.."
exec > >(sed 's/\x1b\[[0-9;]*m//g' | tee -a build-mac-appstore.log) 2>&1
VERSION=$(sed -n 's/^__version__ = "\([0-9\.]*\).*/\1/p' gedcom_dna_finder/__init__.py)
echo '--------------------------------'
echo "Building app version ${VERSION} for Mac App Store."
date
echo '--------------------------------'
security unlock-keychain -p "$(cat ~/.config/p)" ~/Library/Keychains/login.keychain-db
if [[ ! -e 'dist/gedcom-dna-finder.app' ]]; then
	echo 'Built app not found, building now.'
	./dev/build.sh
fi
AS_APP_CERT=$(security find-identity -v -p codesigning 2>/dev/null |
	grep "3rd Party Mac Developer Application" |
	grep -Eo '[0-9A-Z]{40}' | head -1)
AS_INST_CERT=$(security find-identity -v 2>/dev/null |
	grep "3rd Party Mac Developer Installer" |
	grep -Eo '[0-9A-Z]{40}' | head -1)

if [[ -n "${AS_APP_CERT}" && -n "${AS_INST_CERT}" ]]; then
	echo "Building App Store package..."
	APP_SRC="dist/gedcom-dna-finder.app"
	APP_AS="dist/gedcom-dna-finder-appstore.app"
	PKG="dist/gedcom-dna-finder.pkg"

	# Work from a clean copy so the notarised Developer-ID build is untouched
	rm -rf "${APP_AS}"
	cp -R "${APP_SRC}" "${APP_AS}"

	# Embed provisioning profile (required for TestFlight eligibility).
	PROVISION_PROFILE="${HOME}/Library/MobileDevice/Provisioning Profiles/gedcom-dna-finder.provisionprofile"
	if [[ ! -f "${PROVISION_PROFILE}" ]]; then
		PROVISION_PROFILE="$(dirname "$0")/gedcom-dna-finder.provisionprofile"
	fi
	if [[ ! -f "${PROVISION_PROFILE}" ]]; then
		PROVISION_PROFILE="dev/gedcom-dna-finder.provisionprofile"
	fi
	if [[ -f "${PROVISION_PROFILE}" ]]; then
		cp "${PROVISION_PROFILE}" "${APP_AS}/Contents/embedded.provisionprofile"
		echo "Embedded provisioning profile from: ${PROVISION_PROFILE}"
	else
		echo "WARNING: No provisioning profile found; app will not be TestFlight-eligible."
		echo "  Place gedcom-dna-finder.provisionprofile in ~/Library/MobileDevice/Provisioning Profiles/ or dev/"
	fi
	#
	# Ensure all files are readable by non-root users (App Store error 90255).
	chmod -R a+rX "${APP_AS}"
	# Ensure no files are quarantined
	xattr -rd com.apple.quarantine "${APP_AS}"
	[ -e "${APP_AS}/Contents/embedded.provisionprofile" ] && xattr -c "${APP_AS}/Contents/embedded.provisionprofile"

	# Re-sign bottom-up with the App Store identity.
	# --deep triggers errSecInternalComponent on Python .so extension modules,
	# so sign nested components individually first, then the executable, then
	# the bundle. The sandbox entitlement only needs to be on the main executable.
	while IFS= read -r -d '' f; do
		codesign --force --sign "${AS_APP_CERT}" "$f" || {
			echo "App Store code-signing failed on: $f"
			exit 1
		}
	done < <(find "${APP_AS}" -type f \( -name "*.so" -o -name "*.dylib" -o -name 'Python' \) -print0)

	find "${APP_AS}" -type f -perm +111 -exec codesign --force --options runtime --sign "${AS_APP_CERT}" {} \;

	echo "Signing provisioning profile."
	codesign --force --verbose \
		--sign "${AS_APP_CERT}" \
		--entitlements "./dev/entitlements-appstore.plist" \
		"${APP_AS}/Contents/embedded.provisionprofile" || {
		echo "App Store code-signing of provision profile failed."
		exit 1
	}

	echo "Signing entitlements."
	codesign --force --verbose \
		--sign "${AS_APP_CERT}" \
		--entitlements "./dev/entitlements-appstore.plist" \
		"${APP_AS}/Contents/MacOS/gedcom-dna-finder" || {
		echo "App Store code-signing of main executable failed."
		exit 1
	}

	codesign --force --verbose \
		--sign "${AS_APP_CERT}" \
		--entitlements "./dev/entitlements-appstore.plist" \
		"${APP_AS}" || {
		echo "App Store code-signing of bundle failed."
		exit 1
	}

	productbuild \
		--component "${APP_AS}" /Applications \
		--sign "${AS_INST_CERT}" \
		"${PKG}" || {
		echo "productbuild failed."
		exit 1
	}

	[ "${DRY}" ] || rm -rf "${APP_AS}"
	echo "App Store package created: ${PKG}"
else
	echo "No App Store signing certificates found; skipping pkg creation."
	[[ -z "${AS_APP_CERT}" ]] && echo "  Missing: 3rd Party Mac Developer Application"
	[[ -z "${AS_INST_CERT}" ]] && echo "  Missing: 3rd Party Mac Developer Installer"
	exit 1
fi
echo "Submitting App Store package to app store..."
apiKey=$(cat "${HOME}/.appstoreconnect/apikey.txt")
apiIssuer=$(cat "${HOME}/.appstoreconnect/apiissuer.txt")
appid=$(cat "${HOME}/.appstoreconnect/appid.txt")
version=$(grep __version__ gedcom_dna_finder/__init__.py | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+')
[ -z "${apiKey}" ] || [ -z "${apiIssuer}" ] || [ -z "${version}" ] || [ -z "${appid}" ] && {
	echo "Need apiKey, apiIssuer, version, and appid to be set for app store upload."
	exit 1
}
# optional steps - not use to submit to app store, just validate pkg
#xcrun altool --validate-app -f dist/gedcom-dna-finder.pkg -t macos --apiKey "${apiKey}" --apiIssuer "${apiIssuer}"
echo 'Uploading with the following command:'
echo xcrun altool --upload-package dist/gedcom-dna-finder.pkg --type osx --bundle-id "com.ajkessel.gedcom-dna-finder" --bundle-short-version-string "${version}" --bundle-version "${version}" --apiKey "${apiKey}" --apiIssuer "${apiIssuer}" --apple-id "${appid}"
[ "${DRY}" ] || xcrun altool --upload-package dist/gedcom-dna-finder.pkg --type osx --bundle-id "com.ajkessel.gedcom-dna-finder" --bundle-short-version-string "${version}" --bundle-version "${version}" --apiKey "${apiKey}" --apiIssuer "${apiIssuer}" --apple-id "${appid}"
