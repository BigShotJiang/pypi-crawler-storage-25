"""Tests for llm_route.semaphores — SemaphoreManager."""

from __future__ import annotations

import asyncio

import pytest

from llm_route.models import RequestClass
from llm_route.semaphores import SemaphoreManager


@pytest.fixture
def sem_manager(two_deployments, concurrency_config) -> SemaphoreManager:
    return SemaphoreManager(two_deployments, concurrency_config)


class TestSemaphoreManager:
    async def test_acquire_and_release(self, sem_manager):
        assert sem_manager.inflight("eastus-1") == 0
        assert sem_manager.available("eastus-1", RequestClass.LIGHT) is True

        async with sem_manager.acquire("eastus-1", RequestClass.LIGHT):
            assert sem_manager.inflight("eastus-1") == 1
            assert sem_manager.inflight("eastus-1", RequestClass.LIGHT) == 1

        assert sem_manager.inflight("eastus-1") == 0

    async def test_available_permits_decrements(self, sem_manager, concurrency_config):
        initial = concurrency_config.light  # 5
        assert sem_manager.available_permits("eastus-1", RequestClass.LIGHT) == initial

        async with sem_manager.acquire("eastus-1", RequestClass.LIGHT):
            assert sem_manager.available_permits("eastus-1", RequestClass.LIGHT) == initial - 1

        assert sem_manager.available_permits("eastus-1", RequestClass.LIGHT) == initial

    async def test_inflight_filtered_by_class(self, sem_manager):
        async with sem_manager.acquire("eastus-1", RequestClass.LIGHT):
            async with sem_manager.acquire("eastus-1", RequestClass.MEDIUM):
                assert sem_manager.inflight("eastus-1") == 2
                assert sem_manager.inflight("eastus-1", RequestClass.LIGHT) == 1
                assert sem_manager.inflight("eastus-1", RequestClass.MEDIUM) == 1
                assert sem_manager.inflight("eastus-1", RequestClass.HEAVY) == 0

    async def test_timeout_on_acquire(self, sem_manager):
        """When all permits are taken, acquire should timeout."""
        # heavy limit is 1
        async with sem_manager.acquire("eastus-1", RequestClass.HEAVY):
            assert sem_manager.available("eastus-1", RequestClass.HEAVY) is False
            with pytest.raises(asyncio.TimeoutError):
                async with sem_manager.acquire("eastus-1", RequestClass.HEAVY, timeout=0.05):
                    pass  # should not reach here

    async def test_class_isolation_heavy_doesnt_block_light(self, sem_manager):
        """Exhausting heavy permits should not affect light permits."""
        # heavy limit is 1
        async with sem_manager.acquire("eastus-1", RequestClass.HEAVY):
            assert sem_manager.available("eastus-1", RequestClass.HEAVY) is False
            assert sem_manager.available("eastus-1", RequestClass.LIGHT) is True

            async with sem_manager.acquire("eastus-1", RequestClass.LIGHT):
                assert sem_manager.inflight("eastus-1") == 2

    async def test_unknown_deployment_raises(self, sem_manager):
        with pytest.raises(KeyError, match="Unknown deployment/class"):
            async with sem_manager.acquire("nonexistent", RequestClass.LIGHT):
                pass

    async def test_available_permits_unknown_returns_zero(self, sem_manager):
        assert sem_manager.available_permits("nonexistent", RequestClass.LIGHT) == 0
        assert sem_manager.available("nonexistent", RequestClass.LIGHT) is False

    async def test_deployment_isolation(self, sem_manager):
        """Acquiring on eastus-1 should not affect eastus-2."""
        async with sem_manager.acquire("eastus-1", RequestClass.HEAVY):
            assert sem_manager.inflight("eastus-1", RequestClass.HEAVY) == 1
            assert sem_manager.inflight("eastus-2", RequestClass.HEAVY) == 0
            assert sem_manager.available("eastus-2", RequestClass.HEAVY) is True
