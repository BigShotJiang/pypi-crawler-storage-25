"""Tests for llm_route.cooldown — CooldownTracker."""

from __future__ import annotations

import pytest

from llm_route.cooldown import CooldownTracker


class TestCooldownTracker:
    def test_not_cooled_initially(self):
        tracker = CooldownTracker(default_cooldown=10.0)
        assert tracker.is_cooled("dep1") is False
        assert tracker.remaining_seconds("dep1") == 0.0
        assert tracker.total_429s("dep1") == 0

    def test_mark_cooled_uses_default(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: now)

        tracker = CooldownTracker(default_cooldown=10.0)
        tracker.mark_cooled("dep1")

        assert tracker.is_cooled("dep1") is True
        assert tracker.remaining_seconds("dep1") == 10.0

    def test_mark_cooled_uses_custom_retry_after(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: now)

        tracker = CooldownTracker(default_cooldown=10.0)
        tracker.mark_cooled("dep1", retry_after=25.0)

        assert tracker.is_cooled("dep1") is True
        assert tracker.remaining_seconds("dep1") == 25.0

    def test_cooldown_expires(self, monkeypatch):
        current_time = [1000.0]
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: current_time[0])

        tracker = CooldownTracker(default_cooldown=5.0)
        tracker.mark_cooled("dep1")

        assert tracker.is_cooled("dep1") is True

        # Advance past expiry
        current_time[0] = 1006.0
        assert tracker.is_cooled("dep1") is False
        assert tracker.remaining_seconds("dep1") == 0.0

    def test_clear_removes_cooldown(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: now)

        tracker = CooldownTracker(default_cooldown=10.0)
        tracker.mark_cooled("dep1")
        assert tracker.is_cooled("dep1") is True

        tracker.clear("dep1")
        assert tracker.is_cooled("dep1") is False

    def test_clear_nonexistent_is_noop(self):
        tracker = CooldownTracker()
        tracker.clear("nonexistent")  # should not raise

    def test_total_429s_increments(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: now)

        tracker = CooldownTracker()
        assert tracker.total_429s("dep1") == 0

        tracker.mark_cooled("dep1")
        assert tracker.total_429s("dep1") == 1

        tracker.mark_cooled("dep1")
        assert tracker.total_429s("dep1") == 2

    def test_min_cooldown_remaining_none_when_empty(self):
        tracker = CooldownTracker()
        assert tracker.min_cooldown_remaining() is None

    def test_min_cooldown_remaining_returns_shortest(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: now)

        tracker = CooldownTracker(default_cooldown=10.0)
        tracker.mark_cooled("dep1", retry_after=20.0)
        tracker.mark_cooled("dep2", retry_after=5.0)

        result = tracker.min_cooldown_remaining()
        assert result == 5.0

    def test_min_cooldown_remaining_excludes_expired(self, monkeypatch):
        current_time = [1000.0]
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: current_time[0])

        tracker = CooldownTracker()
        tracker.mark_cooled("dep1", retry_after=3.0)
        tracker.mark_cooled("dep2", retry_after=10.0)

        current_time[0] = 1004.0  # dep1 expired, dep2 has 6s left
        result = tracker.min_cooldown_remaining()
        assert result == pytest.approx(6.0)
