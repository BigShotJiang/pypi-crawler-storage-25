"""Tests for llm_route.token_tracker — TokenTracker."""

from __future__ import annotations

import pytest

from llm_route.token_tracker import TokenTracker


class TestTokenTracker:
    def test_usage_zero_initially(self):
        tracker = TokenTracker(window_seconds=60)
        assert tracker.usage("dep1") == 0
        assert tracker.total_all_time("dep1") == 0

    def test_record_and_usage(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 500)
        tracker.record("dep1", 300)

        assert tracker.usage("dep1") == 800
        assert tracker.total_all_time("dep1") == 800

    def test_utilization(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 30_000)

        assert tracker.utilization("dep1", 60_000) == pytest.approx(0.5)
        assert tracker.utilization("dep1", 30_000) == pytest.approx(1.0)

    def test_utilization_caps_at_one(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 100_000)

        assert tracker.utilization("dep1", 60_000) == 1.0

    def test_utilization_zero_quota(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker()
        tracker.record("dep1", 100)
        assert tracker.utilization("dep1", 0) == 1.0

    def test_remaining(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 40_000)

        assert tracker.remaining("dep1", 60_000) == 20_000
        assert tracker.remaining("dep1", 30_000) == 0  # capped at 0

    def test_sliding_window_pruning(self, monkeypatch):
        current_time = [1000.0]
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: current_time[0])

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 500)

        current_time[0] = 1030.0
        tracker.record("dep1", 300)

        # Both in window
        assert tracker.usage("dep1") == 800

        # Advance past first record's window
        current_time[0] = 1061.0
        assert tracker.usage("dep1") == 300  # first record pruned

        # Advance past all
        current_time[0] = 1100.0
        assert tracker.usage("dep1") == 0

    def test_total_all_time_survives_pruning(self, monkeypatch):
        current_time = [1000.0]
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: current_time[0])

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 500)

        current_time[0] = 1100.0  # past window
        assert tracker.usage("dep1") == 0
        assert tracker.total_all_time("dep1") == 500

    def test_separate_deployments(self, monkeypatch):
        now = 1000.0
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: now)

        tracker = TokenTracker(window_seconds=60)
        tracker.record("dep1", 100)
        tracker.record("dep2", 200)

        assert tracker.usage("dep1") == 100
        assert tracker.usage("dep2") == 200
