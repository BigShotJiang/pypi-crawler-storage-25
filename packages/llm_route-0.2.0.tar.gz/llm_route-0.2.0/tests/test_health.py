"""Tests for llm_route.health — build_health_report."""

from __future__ import annotations

import pytest

from llm_route.config import DeploymentConfig, RequestClassConfig
from llm_route.cooldown import CooldownTracker
from llm_route.health import build_health_report
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker


@pytest.fixture
def cooldown() -> CooldownTracker:
    return CooldownTracker(default_cooldown=10.0)


@pytest.fixture
def semaphores(two_deployments, concurrency_config) -> SemaphoreManager:
    return SemaphoreManager(two_deployments, concurrency_config)


@pytest.fixture
def token_tracker() -> TokenTracker:
    return TokenTracker(window_seconds=60)


class TestBuildHealthReport:
    def test_all_healthy(self, two_deployments, cooldown, semaphores, token_tracker):
        report = build_health_report(
            deployments=two_deployments,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert report.active_deployments == 2
        assert report.cooled_deployments == 0
        assert report.total_inflight == 0
        assert len(report.deployments) == 2

        for dep_health in report.deployments:
            assert dep_health.healthy is True
            assert dep_health.enabled is True
            assert dep_health.inflight == 0
            assert dep_health.cooled_until is None
            assert dep_health.total_429s == 0

    def test_one_cooled(self, two_deployments, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        cooldown.mark_cooled("eastus-1", retry_after=30.0)

        report = build_health_report(
            deployments=two_deployments,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert report.active_deployments == 1
        assert report.cooled_deployments == 1

        east1 = next(d for d in report.deployments if d.name == "eastus-1")
        east2 = next(d for d in report.deployments if d.name == "eastus-2")

        assert east1.healthy is False
        assert east1.cooled_until is not None
        assert east1.total_429s == 1
        assert east2.healthy is True

    def test_disabled_deployment(self, dep_east1, cooldown, token_tracker):
        disabled = DeploymentConfig(
            name="disabled-dep",
            endpoint="https://x.openai.azure.com/",
            api_key="k",
            deployment_name="gpt-4o",
            enabled=False,
        )
        deps = [dep_east1, disabled]
        sem = SemaphoreManager(deps, RequestClassConfig())

        report = build_health_report(
            deployments=deps,
            cooldown=cooldown,
            semaphores=sem,
            token_tracker=token_tracker,
        )
        assert report.active_deployments == 1

        dis_health = next(d for d in report.deployments if d.name == "disabled-dep")
        assert dis_health.enabled is False
        assert dis_health.healthy is False

    def test_with_token_usage(self, two_deployments, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: 1000.0)
        token_tracker.record("eastus-1", 5000)

        report = build_health_report(
            deployments=two_deployments,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )

        east1 = next(d for d in report.deployments if d.name == "eastus-1")
        assert east1.tpm_used == 5000
        assert east1.tpm_quota == 120_000

    def test_semaphore_available_in_report(
        self, two_deployments, cooldown, semaphores, token_tracker, concurrency_config
    ):
        report = build_health_report(
            deployments=two_deployments,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        east1 = next(d for d in report.deployments if d.name == "eastus-1")
        assert east1.semaphore_available["light"] == concurrency_config.light
        assert east1.semaphore_available["medium"] == concurrency_config.medium
        assert east1.semaphore_available["heavy"] == concurrency_config.heavy

    def test_error_and_request_counts(self, two_deployments, cooldown, semaphores, token_tracker):
        report = build_health_report(
            deployments=two_deployments,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            total_errors={"eastus-1": 3},
            total_requests={"eastus-1": 100, "eastus-2": 50},
        )

        east1 = next(d for d in report.deployments if d.name == "eastus-1")
        east2 = next(d for d in report.deployments if d.name == "eastus-2")

        assert east1.total_errors == 3
        assert east1.total_requests == 100
        assert east2.total_errors == 0
        assert east2.total_requests == 50
