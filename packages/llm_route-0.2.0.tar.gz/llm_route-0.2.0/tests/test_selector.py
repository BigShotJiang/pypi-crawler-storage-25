"""Tests for llm_route.selector — DeploymentSelector."""

from __future__ import annotations

import pytest

from llm_route.config import DeploymentConfig, RequestClassConfig
from llm_route.cooldown import CooldownTracker
from llm_route.models import RequestClass
from llm_route.selector import DeploymentSelector
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker


@pytest.fixture
def cooldown() -> CooldownTracker:
    return CooldownTracker(default_cooldown=10.0)


@pytest.fixture
def semaphores(two_deployments, concurrency_config) -> SemaphoreManager:
    return SemaphoreManager(two_deployments, concurrency_config)


@pytest.fixture
def token_tracker() -> TokenTracker:
    return TokenTracker(window_seconds=60)


@pytest.fixture
def selector(two_deployments) -> DeploymentSelector:
    return DeploymentSelector(two_deployments)


class TestDeploymentSelector:
    def test_prefers_lower_inflight_per_weight(self, selector, cooldown, semaphores, token_tracker, monkeypatch):
        """With no inflight, should select higher-weight deployment or either (random tie-break).
        With inflight on one, should prefer the other."""
        # Force deterministic random
        monkeypatch.setattr("llm_route.selector.random.random", lambda: 0.5)

        # Record usage to tip token balance toward eastus-1 being "busier"
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: 1000.0)
        token_tracker.record("eastus-1", 50_000)

        result = selector.select(
            request_class=RequestClass.LIGHT,
            exclude=set(),
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert result is not None
        # eastus-2 has more remaining TPM proportionally, so it may be preferred
        # The key invariant: it returns a valid deployment
        assert result.name in ("eastus-1", "eastus-2")

    def test_skips_cooled_deployments(self, selector, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        cooldown.mark_cooled("eastus-1", retry_after=30.0)

        result = selector.select(
            request_class=RequestClass.LIGHT,
            exclude=set(),
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert result is not None
        assert result.name == "eastus-2"

    def test_skips_excluded_deployments(self, selector, cooldown, semaphores, token_tracker):
        result = selector.select(
            request_class=RequestClass.LIGHT,
            exclude={"eastus-1"},
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert result is not None
        assert result.name == "eastus-2"

    def test_returns_none_when_all_excluded(self, selector, cooldown, semaphores, token_tracker):
        result = selector.select(
            request_class=RequestClass.LIGHT,
            exclude={"eastus-1", "eastus-2"},
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert result is None

    def test_returns_none_when_all_cooled(self, selector, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        cooldown.mark_cooled("eastus-1")
        cooldown.mark_cooled("eastus-2")

        result = selector.select(
            request_class=RequestClass.LIGHT,
            exclude=set(),
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
        )
        assert result is None

    async def test_skips_deployments_with_no_permits(
        self, two_deployments, concurrency_config, cooldown, token_tracker
    ):
        """When heavy permits (limit=1) are exhausted, selector skips that deployment."""
        sem = SemaphoreManager(two_deployments, concurrency_config)
        sel = DeploymentSelector(two_deployments)

        async with sem.acquire("eastus-1", RequestClass.HEAVY):
            result = sel.select(
                request_class=RequestClass.HEAVY,
                exclude=set(),
                cooldown=cooldown,
                semaphores=sem,
                token_tracker=token_tracker,
            )
            assert result is not None
            assert result.name == "eastus-2"

    def test_weight_computation(self, dep_east1, dep_east2):
        """eastus-1 has 120k TPM, eastus-2 has 60k. Weight ratio should be 2:1."""
        sel = DeploymentSelector([dep_east1, dep_east2])
        assert sel.get_weight("eastus-1") == 2.0
        assert sel.get_weight("eastus-2") == 1.0

    def test_skips_disabled_deployments(self, dep_east1, cooldown, token_tracker):
        disabled = DeploymentConfig(
            name="disabled-dep",
            endpoint="https://x.openai.azure.com/",
            api_key="k",
            deployment_name="gpt-4o",
            enabled=False,
        )
        deps = [dep_east1, disabled]
        sem = SemaphoreManager(deps, RequestClassConfig())
        sel = DeploymentSelector(deps)

        result = sel.select(
            request_class=RequestClass.LIGHT,
            exclude=set(),
            cooldown=cooldown,
            semaphores=sem,
            token_tracker=token_tracker,
        )
        assert result is not None
        assert result.name == "eastus-1"
