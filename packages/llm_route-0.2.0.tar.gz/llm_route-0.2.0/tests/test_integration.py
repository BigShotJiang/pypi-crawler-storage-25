"""Integration tests — exercise llm-route as an external consumer would.

These tests import ONLY from the public API (`from llm_route import ...`)
and mock at the HTTP layer using respx so the full OpenAI SDK path is tested.
"""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest
import respx

from llm_route import (
    DeploymentConfig,
    RequestClass,
    RequestClassConfig,
    RouterConfig,
    RouterExhaustedError,
    SmartRouter,
)

# ---------------------------------------------------------------------------
# Helpers — realistic Azure OpenAI response payloads
# ---------------------------------------------------------------------------


def _chat_completion_json(content: str = "Hello!", prompt_tokens: int = 10, completion_tokens: int = 20) -> dict:
    """Return a realistic Azure OpenAI chat completion response body."""
    return {
        "id": "chatcmpl-abc123",
        "object": "chat.completion",
        "created": 1700000000,
        "model": "gpt-4o",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }


def _429_response(retry_after: str = "2") -> httpx.Response:
    """Return a 429 rate-limit response."""
    return httpx.Response(
        status_code=429,
        json={"error": {"message": "Rate limit exceeded", "type": "rate_limit_error"}},
        headers={"retry-after": retry_after},
    )


def _500_response() -> httpx.Response:
    """Return a 500 server error response."""
    return httpx.Response(
        status_code=500,
        json={"error": {"message": "Internal server error", "type": "server_error"}},
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config_two_deployments() -> RouterConfig:
    """Two deployments with different TPM quotas — the standard test setup."""
    return RouterConfig(
        deployments=[
            DeploymentConfig(
                name="east-1",
                endpoint="https://east1.openai.azure.com",
                api_key="fake-key-1",
                deployment_name="gpt-4o",
                tpm_quota=120_000,
            ),
            DeploymentConfig(
                name="east-2",
                endpoint="https://east2.openai.azure.com",
                api_key="fake-key-2",
                deployment_name="gpt-4o",
                tpm_quota=60_000,
            ),
        ],
        default_timeout=10.0,
        max_retries=3,
        cooldown_seconds=5.0,
        concurrency=RequestClassConfig(light=5, medium=3, heavy=1),
    )


@pytest.fixture
def config_three_deployments() -> RouterConfig:
    """Three deployments for multi-failover testing."""
    return RouterConfig(
        deployments=[
            DeploymentConfig(
                name="primary",
                endpoint="https://primary.openai.azure.com",
                api_key="key-1",
                deployment_name="gpt-4o",
                tpm_quota=120_000,
            ),
            DeploymentConfig(
                name="secondary",
                endpoint="https://secondary.openai.azure.com",
                api_key="key-2",
                deployment_name="gpt-4o",
                tpm_quota=120_000,
            ),
            DeploymentConfig(
                name="tertiary",
                endpoint="https://tertiary.openai.azure.com",
                api_key="key-3",
                deployment_name="gpt-4o",
                tpm_quota=60_000,
            ),
        ],
        default_timeout=10.0,
        max_retries=3,
        cooldown_seconds=5.0,
    )


# ---------------------------------------------------------------------------
# 1. Public API import test — verifies the consumer-facing surface
# ---------------------------------------------------------------------------


class TestPublicAPI:
    """Verify that all documented public API imports work."""

    def test_all_public_classes_importable(self):
        """A consumer should be able to import everything from llm_route."""
        from llm_route import (
            RequestClass,
            SmartRouter,
        )

        assert SmartRouter is not None
        assert RequestClass.LIGHT.value == "light"
        assert RequestClass.MEDIUM.value == "medium"
        assert RequestClass.HEAVY.value == "heavy"

    def test_version_exposed(self):
        import llm_route

        assert hasattr(llm_route, "__version__")
        assert llm_route.__version__ == "0.2.0"

    def test_route_result_importable(self):
        from llm_route import RouteResult

        assert RouteResult is not None


# ---------------------------------------------------------------------------
# 2. Config loading — JSON file and programmatic
# ---------------------------------------------------------------------------


class TestConfigLoading:
    def test_config_from_json_file(self, tmp_path):
        """Consumer loads config from a JSON file — the primary config path."""
        config_data = {
            "deployments": [
                {
                    "name": "east-1",
                    "endpoint": "https://east1.openai.azure.com",
                    "api_key": "test-key",
                    "deployment_name": "gpt-4o",
                    "tpm_quota": 100_000,
                }
            ],
            "default_timeout": 30.0,
            "max_retries": 2,
            "cooldown_seconds": 8.0,
            "concurrency": {"light": 15, "medium": 8, "heavy": 2},
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config_data))

        config = RouterConfig.from_file(str(config_file))
        assert len(config.deployments) == 1
        assert config.deployments[0].name == "east-1"
        assert config.default_timeout == 30.0
        assert config.concurrency.heavy == 2

    def test_config_from_json_creates_working_router(self, tmp_path):
        """Config loaded from JSON should produce a functional router."""
        config_data = {
            "deployments": [
                {
                    "name": "test-dep",
                    "endpoint": "https://test.openai.azure.com",
                    "api_key": "key",
                    "deployment_name": "gpt-4o",
                }
            ],
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config_data))

        config = RouterConfig.from_file(str(config_file))
        router = SmartRouter(config=config)
        health = router.health()
        assert health.active_deployments == 1
        assert health.deployments[0].name == "test-dep"

    def test_programmatic_config(self):
        """Consumer builds config in code — no file needed."""
        config = RouterConfig(
            deployments=[
                DeploymentConfig(
                    name="inline",
                    endpoint="https://inline.openai.azure.com",
                    api_key="key",
                    deployment_name="gpt-4o",
                    tpm_quota=80_000,
                ),
            ],
        )
        router = SmartRouter(config=config)
        assert router.health().active_deployments == 1

    def test_no_deployments_raises(self):
        """Consumer gets a clear error if no deployments are configured."""
        with pytest.raises(ValueError, match="No deployments configured"):
            SmartRouter()


# ---------------------------------------------------------------------------
# 3. Full routing lifecycle with respx HTTP mocking
# ---------------------------------------------------------------------------


class TestRoutingLifecycle:
    """Test the full request path: router → OpenAI SDK → HTTP → response."""

    @respx.mock
    async def test_successful_completion(self, config_two_deployments):
        """Basic happy path — request is routed and response returned."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("Hello from east-1"))
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("Hello from east-2"))
        )

        router = SmartRouter(config=config_two_deployments)
        result = await router.complete(
            messages=[{"role": "user", "content": "Hi"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.completion.choices[0].message.content in ("Hello from east-1", "Hello from east-2")
        assert result.completion.usage.total_tokens == 30
        assert result.deployment_name in ("east-1", "east-2")
        assert result.attempts == 1
        assert result.tokens_used == 30
        await router.close()

    @respx.mock
    async def test_completion_with_parameters(self, config_two_deployments):
        """Verify that temperature, max_tokens etc are passed through."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("response"))
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("response"))
        )

        router = SmartRouter(config=config_two_deployments)
        await router.complete(
            messages=[{"role": "user", "content": "test"}],
            temperature=0.1,
            max_tokens=500,
            request_class=RequestClass.MEDIUM,
        )

        # Verify at least one call was made with the right parameters
        total_calls = len(respx.calls)
        assert total_calls >= 1
        request_body = json.loads(respx.calls[0].request.content)
        assert request_body["temperature"] == 0.1
        assert request_body["max_tokens"] == 500
        await router.close()

    @respx.mock
    async def test_health_after_successful_requests(self, config_two_deployments):
        """Health report reflects token usage after requests."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("ok", prompt_tokens=100, completion_tokens=200))
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("ok", prompt_tokens=100, completion_tokens=200))
        )

        router = SmartRouter(config=config_two_deployments)

        # Make a few requests
        for _ in range(3):
            await router.complete(
                messages=[{"role": "user", "content": "test"}],
                request_class=RequestClass.LIGHT,
            )

        health = router.health()
        assert health.active_deployments == 2
        assert health.total_inflight == 0  # all requests finished
        # At least one deployment should have recorded token usage
        total_tpm = sum(d.tpm_used for d in health.deployments)
        assert total_tpm > 0
        await router.close()

    @respx.mock
    async def test_close_is_idempotent(self, config_two_deployments):
        """Calling close() multiple times should not raise."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )

        router = SmartRouter(config=config_two_deployments)
        await router.complete(messages=[{"role": "user", "content": "hi"}])
        await router.close()
        await router.close()  # should not raise


# ---------------------------------------------------------------------------
# 4. 429 failover — the core differentiator
# ---------------------------------------------------------------------------


class TestFailover:
    """Test that 429s and 5xxs trigger failover to the next deployment."""

    @respx.mock
    async def test_429_failover_to_next_deployment(self, config_two_deployments):
        """When east-1 returns 429, the request should succeed on east-2."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="2")
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("from east-2"))
        )

        router = SmartRouter(config=config_two_deployments)
        result = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.completion.choices[0].message.content == "from east-2"
        # east-1 should now be in cooldown
        health = router.health()
        east1 = next(d for d in health.deployments if d.name == "east-1")
        assert east1.healthy is False
        assert east1.total_429s >= 1
        await router.close()

    @respx.mock
    async def test_5xx_failover(self, config_two_deployments):
        """500 errors should also trigger failover."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_500_response()
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("from east-2"))
        )

        router = SmartRouter(config=config_two_deployments)
        result = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.completion.choices[0].message.content == "from east-2"
        await router.close()

    @respx.mock
    async def test_multi_deployment_failover_chain(self, config_three_deployments):
        """429 on primary → 429 on secondary → success on tertiary."""
        respx.post("https://primary.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response()
        )
        respx.post("https://secondary.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response()
        )
        respx.post("https://tertiary.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("tertiary saved us"))
        )

        router = SmartRouter(config=config_three_deployments)
        result = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.completion.choices[0].message.content == "tertiary saved us"
        health = router.health()
        assert health.cooled_deployments >= 2
        await router.close()

    @respx.mock
    async def test_all_deployments_429_raises_exhausted(self, config_two_deployments):
        """When ALL deployments return 429, raise RouterExhaustedError."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="30")
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="30")
        )

        router = SmartRouter(config=config_two_deployments)
        with pytest.raises(RouterExhaustedError):
            await router.complete(
                messages=[{"role": "user", "content": "test"}],
                request_class=RequestClass.LIGHT,
            )
        await router.close()

    @respx.mock
    async def test_429_cooldown_prevents_reuse(self, config_two_deployments):
        """After a 429, the cooled deployment should not be selected for subsequent requests."""
        east1_calls = []
        east2_calls = []

        def east1_handler(request):
            east1_calls.append(1)
            if len(east1_calls) == 1:
                return _429_response(retry_after="60")
            return httpx.Response(200, json=_chat_completion_json("east-1"))

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=east1_handler
        )

        def east2_handler(request):
            east2_calls.append(1)
            return httpx.Response(200, json=_chat_completion_json("east-2"))

        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=east2_handler
        )

        router = SmartRouter(config=config_two_deployments)

        # First request: east-1 returns 429, falls over to east-2
        r1 = await router.complete(messages=[{"role": "user", "content": "first"}], request_class=RequestClass.LIGHT)
        assert r1.completion.choices[0].message.content == "east-2"

        # Second request: east-1 is still cooled, should go directly to east-2
        r2 = await router.complete(messages=[{"role": "user", "content": "second"}], request_class=RequestClass.LIGHT)
        assert r2.completion.choices[0].message.content == "east-2"

        # east-1 should only have been called once (the initial 429)
        assert len(east1_calls) == 1
        # east-2 should have handled both successful requests
        assert len(east2_calls) == 2
        await router.close()


# ---------------------------------------------------------------------------
# 5. Request class isolation
# ---------------------------------------------------------------------------


class TestRequestClassIsolation:
    """Verify that heavy requests don't starve light ones."""

    @respx.mock
    async def test_heavy_concurrency_limit_enforced(self, config_two_deployments):
        """With heavy limit=1, a second concurrent heavy request should still complete
        (queued on semaphore, then proceeds when the first finishes)."""

        # Slow response for heavy requests
        async def slow_response(request):
            await asyncio.sleep(0.1)
            return httpx.Response(200, json=_chat_completion_json("heavy done"))

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=slow_response
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=slow_response
        )

        router = SmartRouter(config=config_two_deployments)

        # Launch 3 heavy requests concurrently (limit is 1 per deployment, 2 deployments)
        tasks = [
            router.complete(messages=[{"role": "user", "content": f"heavy-{i}"}], request_class=RequestClass.HEAVY)
            for i in range(3)
        ]
        results = await asyncio.gather(*tasks)

        # All 3 should complete (2 immediate on 2 deployments, 1 queued then completes)
        assert len(results) == 3
        assert all(r.completion.choices[0].message.content == "heavy done" for r in results)
        await router.close()

    @respx.mock
    async def test_light_requests_not_blocked_by_heavy(self, config_two_deployments):
        """Light requests should proceed even when heavy slots are occupied."""
        call_order = []

        async def track_response(request):
            body = json.loads(request.content)
            msg = body["messages"][0]["content"]
            call_order.append(msg)
            if "heavy" in msg:
                await asyncio.sleep(0.2)
            return httpx.Response(200, json=_chat_completion_json(f"reply to {msg}"))

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=track_response
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=track_response
        )

        router = SmartRouter(config=config_two_deployments)

        # Start a heavy request, then immediately fire light requests
        heavy_task = asyncio.create_task(
            router.complete(messages=[{"role": "user", "content": "heavy-work"}], request_class=RequestClass.HEAVY)
        )
        await asyncio.sleep(0.01)  # let heavy start

        light_results = await asyncio.gather(
            *[
                router.complete(messages=[{"role": "user", "content": f"light-{i}"}], request_class=RequestClass.LIGHT)
                for i in range(3)
            ]
        )

        heavy_result = await heavy_task

        # Light requests should all complete
        assert len(light_results) == 3
        assert heavy_result.completion.choices[0].message.content is not None
        await router.close()


# ---------------------------------------------------------------------------
# 6. Weighted routing behavior
# ---------------------------------------------------------------------------


class TestWeightedRouting:
    """Verify the selector prefers higher-capacity deployments."""

    @respx.mock
    async def test_higher_capacity_deployment_gets_more_traffic(self):
        """With 120K TPM vs 60K TPM, east-1 should receive ~2x more requests."""
        east1_count = []
        east2_count = []

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=lambda req: (east1_count.append(1), httpx.Response(200, json=_chat_completion_json()))[1]
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            side_effect=lambda req: (east2_count.append(1), httpx.Response(200, json=_chat_completion_json()))[1]
        )

        config = RouterConfig(
            deployments=[
                DeploymentConfig(
                    name="east-1",
                    endpoint="https://east1.openai.azure.com",
                    api_key="k1",
                    deployment_name="gpt-4o",
                    tpm_quota=120_000,
                ),
                DeploymentConfig(
                    name="east-2",
                    endpoint="https://east2.openai.azure.com",
                    api_key="k2",
                    deployment_name="gpt-4o",
                    tpm_quota=60_000,
                ),
            ],
            default_timeout=10.0,
        )
        router = SmartRouter(config=config)

        # Send 30 sequential requests (sequential so selector sees inflight=0 each time)
        for _ in range(30):
            await router.complete(
                messages=[{"role": "user", "content": "test"}],
                request_class=RequestClass.LIGHT,
            )

        # east-1 (2x weight) should get roughly 2x traffic
        # With random tie-breaking, we allow some variance
        total = len(east1_count) + len(east2_count)
        assert total == 30
        # east-1 should get at least 15 (majority) — with 2x weight and random ties
        assert len(east1_count) >= 15, f"east-1 got {len(east1_count)}/30, expected majority"
        await router.close()


# ---------------------------------------------------------------------------
# 7. Health report as monitoring endpoint
# ---------------------------------------------------------------------------


class TestHealthAsMonitoring:
    """Test health report structure for use as a /health endpoint."""

    def test_health_report_serializable(self, config_two_deployments):
        """Health report should be JSON-serializable for API responses."""
        router = SmartRouter(config=config_two_deployments)
        health = router.health()

        # model_dump() is what you'd use in FastAPI
        data = health.model_dump()
        serialized = json.dumps(data, default=str)
        parsed = json.loads(serialized)

        assert len(parsed["deployments"]) == 2
        assert "total_inflight" in parsed
        assert "active_deployments" in parsed
        assert "cooled_deployments" in parsed

        # Each deployment has the expected fields
        dep = parsed["deployments"][0]
        assert "name" in dep
        assert "healthy" in dep
        assert "tpm_used" in dep
        assert "tpm_quota" in dep
        assert "semaphore_available" in dep

    @respx.mock
    async def test_health_reflects_degraded_state(self, config_two_deployments):
        """After failures, health report shows degraded state."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="60")
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )

        router = SmartRouter(config=config_two_deployments)
        await router.complete(messages=[{"role": "user", "content": "test"}], request_class=RequestClass.LIGHT)

        health = router.health()
        # One deployment should be cooled
        healthy = [d for d in health.deployments if d.healthy]
        unhealthy = [d for d in health.deployments if not d.healthy]
        assert len(healthy) == 1
        assert len(unhealthy) == 1
        assert unhealthy[0].total_429s >= 1
        assert health.cooled_deployments == 1
        assert health.active_deployments == 1
        await router.close()


# ---------------------------------------------------------------------------
# 8. Error handling — consumer-facing errors
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_no_config_clear_error(self):
        """Consumer gets a clear ValueError with no deployments."""
        with pytest.raises(ValueError, match="No deployments configured"):
            SmartRouter()

    @respx.mock
    async def test_streaming_returns_async_iterator(self, config_two_deployments):
        """Consumer gets an async iterator of chunks when stream=True."""

        def _sse_stream(content_parts: list[str], prompt_tokens: int = 10, completion_tokens: int = 5) -> str:
            lines = []
            for part in content_parts:
                chunk = {
                    "id": "chatcmpl-stream",
                    "object": "chat.completion.chunk",
                    "created": 1700000000,
                    "model": "gpt-4o",
                    "choices": [{"index": 0, "delta": {"content": part}, "finish_reason": None}],
                }
                lines.append(f"data: {json.dumps(chunk)}\n\n")
            # Final chunk with usage
            final = {
                "id": "chatcmpl-stream",
                "object": "chat.completion.chunk",
                "created": 1700000000,
                "model": "gpt-4o",
                "choices": [],
                "usage": {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": prompt_tokens + completion_tokens,
                },
            }
            lines.append(f"data: {json.dumps(final)}\n\n")
            lines.append("data: [DONE]\n\n")
            return "".join(lines)

        sse_body = _sse_stream(["Hello", " from", " stream"])

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"content-type": "text/event-stream"},
            )
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"content-type": "text/event-stream"},
            )
        )

        router = SmartRouter(config=config_two_deployments)
        stream = await router.complete(
            messages=[{"role": "user", "content": "hi"}],
            stream=True,
            request_class=RequestClass.LIGHT,
        )

        collected = []
        async for chunk in stream:
            collected.append(chunk)

        # Should have content chunks + final usage chunk
        assert len(collected) >= 3
        content_parts = [c.choices[0].delta.content for c in collected if c.choices]
        assert "".join(content_parts) == "Hello from stream"
        await router.close()

    @respx.mock
    async def test_exhausted_error_message_is_helpful(self, config_two_deployments):
        """RouterExhaustedError should tell the consumer what happened."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="60")
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="60")
        )

        router = SmartRouter(config=config_two_deployments)
        with pytest.raises(RouterExhaustedError, match="All backends exhausted"):
            await router.complete(messages=[{"role": "user", "content": "test"}], request_class=RequestClass.LIGHT)
        await router.close()

    @respx.mock
    async def test_4xx_client_error_propagated_not_retried(self, config_two_deployments):
        """A 400 Bad Request should propagate immediately, not trigger failover."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(400, json={"error": {"message": "Invalid request"}})
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )

        router = SmartRouter(config=config_two_deployments)
        from openai import BadRequestError

        with pytest.raises(BadRequestError):
            await router.complete(messages=[{"role": "user", "content": "test"}], request_class=RequestClass.LIGHT)

        # east-2 should NOT have been called — 400 is not retryable
        east2_calls = [c for c in respx.calls if "east2" in str(c.request.url)]
        assert len(east2_calls) == 0
        await router.close()


# ---------------------------------------------------------------------------
# 9. Streaming with failover
# ---------------------------------------------------------------------------


class TestStreamingFailover:
    """Test streaming with 429 failover across deployments."""

    @respx.mock
    async def test_stream_429_failover_to_next_deployment(self, config_two_deployments):
        """When east-1 returns 429 on a streaming request, stream from east-2."""
        sse_body = _build_sse_stream(["Streamed", " from", " east-2"])

        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=_429_response(retry_after="2")
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"content-type": "text/event-stream"},
            )
        )

        router = SmartRouter(config=config_two_deployments)
        stream = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            stream=True,
            request_class=RequestClass.LIGHT,
        )

        collected = []
        async for chunk in stream:
            collected.append(chunk)

        content_parts = [c.choices[0].delta.content for c in collected if c.choices]
        assert "".join(content_parts) == "Streamed from east-2"
        await router.close()


# ---------------------------------------------------------------------------
# 10. Model filtering
# ---------------------------------------------------------------------------


class TestModelFiltering:
    """Verify that model parameter filters to matching deployments."""

    @respx.mock
    async def test_model_filter_routes_to_matching_deployment(self):
        """With mixed models, model filter picks the right one."""
        config = RouterConfig(
            deployments=[
                DeploymentConfig(
                    name="mini-1",
                    endpoint="https://mini1.openai.azure.com",
                    api_key="k1",
                    deployment_name="gpt-4o-mini",
                    tpm_quota=120_000,
                ),
                DeploymentConfig(
                    name="full-1",
                    endpoint="https://full1.openai.azure.com",
                    api_key="k2",
                    deployment_name="gpt-4o",
                    tpm_quota=60_000,
                ),
            ],
            default_timeout=10.0,
        )

        respx.post("https://mini1.openai.azure.com/openai/deployments/gpt-4o-mini/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("from mini"))
        )
        respx.post("https://full1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("from full"))
        )

        router = SmartRouter(config=config)

        # Request gpt-4o-mini — should only go to mini-1
        result = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            model="gpt-4o-mini",
        )
        assert result.completion.choices[0].message.content == "from mini"
        assert result.deployment_name == "mini-1"

        # Request gpt-4o — should only go to full-1
        result = await router.complete(
            messages=[{"role": "user", "content": "test"}],
            model="gpt-4o",
        )
        assert result.completion.choices[0].message.content == "from full"
        assert result.deployment_name == "full-1"
        await router.close()

    @respx.mock
    async def test_no_model_filter_uses_all_deployments(self):
        """Without model filter, all deployments are eligible."""
        config = RouterConfig(
            deployments=[
                DeploymentConfig(
                    name="dep-1",
                    endpoint="https://dep1.openai.azure.com",
                    api_key="k1",
                    deployment_name="gpt-4o-mini",
                    tpm_quota=60_000,
                ),
                DeploymentConfig(
                    name="dep-2",
                    endpoint="https://dep2.openai.azure.com",
                    api_key="k2",
                    deployment_name="gpt-4o",
                    tpm_quota=60_000,
                ),
            ],
            default_timeout=10.0,
        )

        respx.post("https://dep1.openai.azure.com/openai/deployments/gpt-4o-mini/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("ok"))
        )
        respx.post("https://dep2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json("ok"))
        )

        router = SmartRouter(config=config)
        result = await router.complete(messages=[{"role": "user", "content": "test"}])
        assert result.deployment_name in ("dep-1", "dep-2")
        await router.close()


# ---------------------------------------------------------------------------
# 11. Extra kwargs passthrough
# ---------------------------------------------------------------------------


class TestExtraKwargs:
    @respx.mock
    async def test_response_format_and_seed_passed_through(self, config_two_deployments):
        """Extra kwargs like response_format and seed reach the OpenAI call."""
        respx.post("https://east1.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )
        respx.post("https://east2.openai.azure.com/openai/deployments/gpt-4o/chat/completions").mock(
            return_value=httpx.Response(200, json=_chat_completion_json())
        )

        router = SmartRouter(config=config_two_deployments)
        await router.complete(
            messages=[{"role": "user", "content": "test"}],
            response_format={"type": "json_object"},
            seed=42,
        )

        request_body = json.loads(respx.calls[0].request.content)
        assert request_body["response_format"] == {"type": "json_object"}
        assert request_body["seed"] == 42
        await router.close()


def _build_sse_stream(content_parts: list[str], prompt_tokens: int = 10, completion_tokens: int = 5) -> str:
    """Build an SSE response body for streaming tests."""
    lines = []
    for part in content_parts:
        chunk = {
            "id": "chatcmpl-stream",
            "object": "chat.completion.chunk",
            "created": 1700000000,
            "model": "gpt-4o",
            "choices": [{"index": 0, "delta": {"content": part}, "finish_reason": None}],
        }
        lines.append(f"data: {json.dumps(chunk)}\n\n")
    final = {
        "id": "chatcmpl-stream",
        "object": "chat.completion.chunk",
        "created": 1700000000,
        "model": "gpt-4o",
        "choices": [],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }
    lines.append(f"data: {json.dumps(final)}\n\n")
    lines.append("data: [DONE]\n\n")
    return "".join(lines)
