"""Tests for llm_route.config — RouterConfig, DeploymentConfig, RequestClassConfig."""

from __future__ import annotations

import json

import pytest

from llm_route.config import DeploymentConfig, RequestClassConfig, RouterConfig
from llm_route.models import RequestClass


class TestDeploymentConfig:
    def test_minimal_valid(self):
        dep = DeploymentConfig(
            name="d1",
            endpoint="https://d1.openai.azure.com/",
            api_key="key",
            deployment_name="gpt-4o",
        )
        assert dep.name == "d1"
        assert dep.tpm_quota == 60_000
        assert dep.max_concurrency == 50
        assert dep.enabled is True
        assert dep.api_version == "2024-12-01-preview"

    def test_custom_values(self):
        dep = DeploymentConfig(
            name="d2",
            endpoint="https://d2.openai.azure.com/",
            api_key="key2",
            deployment_name="gpt-4o-mini",
            tpm_quota=200_000,
            max_concurrency=100,
            enabled=False,
            api_version="2024-06-01",
        )
        assert dep.tpm_quota == 200_000
        assert dep.enabled is False
        assert dep.api_version == "2024-06-01"

    def test_missing_required_field_raises(self):
        with pytest.raises(Exception):
            DeploymentConfig(name="d1", endpoint="https://x.com/", api_key="k")


class TestRequestClassConfig:
    def test_defaults(self):
        cfg = RequestClassConfig()
        assert cfg.light == 20
        assert cfg.medium == 10
        assert cfg.heavy == 3

    def test_get_limit_returns_correct_values(self):
        cfg = RequestClassConfig(light=8, medium=4, heavy=2)
        assert cfg.get_limit(RequestClass.LIGHT) == 8
        assert cfg.get_limit(RequestClass.MEDIUM) == 4
        assert cfg.get_limit(RequestClass.HEAVY) == 2

    def test_custom_values(self):
        cfg = RequestClassConfig(light=100, medium=50, heavy=10)
        assert cfg.get_limit(RequestClass.LIGHT) == 100


class TestRouterConfig:
    def test_defaults(self):
        cfg = RouterConfig()
        assert cfg.deployments == []
        assert cfg.default_timeout == 60.0
        assert cfg.max_retries == 3
        assert cfg.cooldown_seconds == 10.0
        assert cfg.token_window_seconds == 60
        assert cfg.redis_url is None

    def test_from_dict(self):
        cfg = RouterConfig(
            deployments=[
                {
                    "name": "d1",
                    "endpoint": "https://d1.openai.azure.com/",
                    "api_key": "key",
                    "deployment_name": "gpt-4o",
                    "tpm_quota": 100_000,
                }
            ],
            default_timeout=30.0,
            max_retries=5,
        )
        assert len(cfg.deployments) == 1
        assert cfg.deployments[0].name == "d1"
        assert cfg.deployments[0].tpm_quota == 100_000
        assert cfg.default_timeout == 30.0
        assert cfg.max_retries == 5

    def test_from_file(self, tmp_path):
        data = {
            "deployments": [
                {
                    "name": "file-dep",
                    "endpoint": "https://x.openai.azure.com/",
                    "api_key": "k",
                    "deployment_name": "gpt-4o",
                }
            ],
            "default_timeout": 45.0,
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(data))

        cfg = RouterConfig.from_file(str(config_file))
        assert cfg.deployments[0].name == "file-dep"
        assert cfg.default_timeout == 45.0

    def test_concurrency_config_nested(self):
        cfg = RouterConfig(
            concurrency={"light": 15, "medium": 8, "heavy": 2},
        )
        assert cfg.concurrency.get_limit(RequestClass.LIGHT) == 15
        assert cfg.concurrency.get_limit(RequestClass.HEAVY) == 2
