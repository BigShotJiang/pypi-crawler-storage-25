"""Tests for llm_route.retry — RetryOrchestrator."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from openai import APIStatusError
from openai.types.chat import ChatCompletion, ChatCompletionChunk, ChatCompletionMessage
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_chunk import Choice as ChunkChoice
from openai.types.chat.chat_completion_chunk import ChoiceDelta
from openai.types.completion_usage import CompletionUsage

from llm_route.cooldown import CooldownTracker
from llm_route.models import RequestClass, RouteRequest, RouterExhaustedError
from llm_route.retry import RetryOrchestrator
from llm_route.selector import DeploymentSelector
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker


def _make_completion(content: str = "hello", total_tokens: int = 100) -> ChatCompletion:
    """Create a minimal ChatCompletion for tests."""
    return ChatCompletion(
        id="chatcmpl-test",
        choices=[
            Choice(
                index=0,
                message=ChatCompletionMessage(role="assistant", content=content),
                finish_reason="stop",
            )
        ],
        created=1700000000,
        model="gpt-4o",
        object="chat.completion",
        usage=CompletionUsage(prompt_tokens=50, completion_tokens=50, total_tokens=total_tokens),
    )


def _make_429_error() -> APIStatusError:
    """Create a mock 429 APIStatusError."""
    resp = MagicMock()
    resp.status_code = 429
    resp.headers = {"retry-after": "5"}
    resp.json.return_value = {"error": {"message": "rate limited"}}
    err = APIStatusError(
        message="rate limited",
        response=resp,
        body={"error": {"message": "rate limited"}},
    )
    return err


def _make_500_error() -> APIStatusError:
    """Create a mock 500 APIStatusError."""
    resp = MagicMock()
    resp.status_code = 500
    resp.headers = {}
    resp.json.return_value = {"error": {"message": "internal error"}}
    err = APIStatusError(
        message="internal error",
        response=resp,
        body={"error": {"message": "internal error"}},
    )
    return err


@pytest.fixture
def route_request() -> RouteRequest:
    return RouteRequest(
        messages=[{"role": "user", "content": "test"}],
        request_class=RequestClass.LIGHT,
    )


@pytest.fixture
def orchestrator() -> RetryOrchestrator:
    return RetryOrchestrator()


@pytest.fixture
def selector(two_deployments) -> DeploymentSelector:
    return DeploymentSelector(two_deployments)


@pytest.fixture
def cooldown() -> CooldownTracker:
    return CooldownTracker(default_cooldown=5.0)


@pytest.fixture
def semaphores(two_deployments, concurrency_config) -> SemaphoreManager:
    return SemaphoreManager(two_deployments, concurrency_config)


@pytest.fixture
def token_tracker() -> TokenTracker:
    return TokenTracker(window_seconds=60)


class TestRetryOrchestrator:
    async def test_successful_first_attempt(
        self, orchestrator, route_request, selector, cooldown, semaphores, token_tracker
    ):
        completion = _make_completion()
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)

        result = await orchestrator.execute(
            request=route_request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=10.0,
            max_retries=3,
        )

        assert result.completion.id == "chatcmpl-test"
        assert result.completion.choices[0].message.content == "hello"
        mock_client.chat.completions.create.assert_called_once()

    async def test_failover_on_429(
        self, orchestrator, route_request, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        completion = _make_completion(content="from second backend")
        error_429 = _make_429_error()

        call_count = [0]

        async def mock_create(**kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise error_429
            return completion

        mock_client = AsyncMock()
        mock_client.chat.completions.create = mock_create

        result = await orchestrator.execute(
            request=route_request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=30.0,
            max_retries=3,
        )

        assert result.completion.choices[0].message.content == "from second backend"
        assert call_count[0] == 2

    async def test_failover_on_5xx(
        self, orchestrator, route_request, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        completion = _make_completion(content="recovered")
        error_500 = _make_500_error()

        call_count = [0]

        async def mock_create(**kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise error_500
            return completion

        mock_client = AsyncMock()
        mock_client.chat.completions.create = mock_create

        result = await orchestrator.execute(
            request=route_request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=30.0,
            max_retries=3,
        )

        assert result.completion.choices[0].message.content == "recovered"
        assert call_count[0] == 2

    async def test_all_backends_exhausted_raises(
        self, orchestrator, route_request, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)

        error_429 = _make_429_error()

        async def always_fail(**kwargs):
            raise error_429

        mock_client = AsyncMock()
        mock_client.chat.completions.create = always_fail

        # max_retries=2 matches the 2 deployments — both fail, loop exits
        with pytest.raises(RouterExhaustedError, match="All backends exhausted"):
            await orchestrator.execute(
                request=route_request,
                selector=selector,
                cooldown=cooldown,
                semaphores=semaphores,
                token_tracker=token_tracker,
                get_client=lambda dep: mock_client,
                timeout=30.0,
                max_retries=2,
            )

    async def test_records_token_usage_on_success(
        self, orchestrator, route_request, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        completion = _make_completion(total_tokens=250)
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)

        await orchestrator.execute(
            request=route_request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=10.0,
            max_retries=3,
        )

        # At least one deployment should have recorded 250 tokens
        total = sum(token_tracker.usage(name) for name in selector.deployment_names)
        assert total == 250


def _make_chunk(content: str | None = None, usage: CompletionUsage | None = None) -> ChatCompletionChunk:
    """Create a minimal ChatCompletionChunk for tests."""
    choices = []
    if content is not None:
        choices.append(
            ChunkChoice(
                index=0,
                delta=ChoiceDelta(role="assistant", content=content),
                finish_reason=None,
            )
        )
    return ChatCompletionChunk(
        id="chatcmpl-stream-test",
        choices=choices,
        created=1700000000,
        model="gpt-4o",
        object="chat.completion.chunk",
        usage=usage,
    )


class _MockAsyncStream:
    """Simulate an OpenAI AsyncStream for testing."""

    def __init__(self, chunks: list[ChatCompletionChunk]) -> None:
        self._chunks = chunks
        self._index = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._index >= len(self._chunks):
            raise StopAsyncIteration
        chunk = self._chunks[self._index]
        self._index += 1
        return chunk


class TestRetryOrchestratorStream:
    async def test_successful_stream(self, orchestrator, selector, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        chunks = [
            _make_chunk("Hello"),
            _make_chunk(" world"),
            _make_chunk(None, usage=CompletionUsage(prompt_tokens=10, completion_tokens=5, total_tokens=15)),
        ]
        mock_stream = _MockAsyncStream(chunks)
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_stream)

        request = RouteRequest(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
            stream=True,
        )

        collected = []
        async for chunk in orchestrator.execute_stream(
            request=request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=10.0,
            max_retries=3,
        ):
            collected.append(chunk)

        assert len(collected) == 3
        assert collected[0].choices[0].delta.content == "Hello"
        assert collected[1].choices[0].delta.content == " world"

    async def test_stream_records_token_usage(
        self, orchestrator, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.token_tracker.time.monotonic", lambda: 1000.0)

        chunks = [
            _make_chunk("Hi"),
            _make_chunk(None, usage=CompletionUsage(prompt_tokens=50, completion_tokens=50, total_tokens=100)),
        ]
        mock_stream = _MockAsyncStream(chunks)
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_stream)

        request = RouteRequest(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
            stream=True,
        )

        async for _ in orchestrator.execute_stream(
            request=request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=10.0,
            max_retries=3,
        ):
            pass

        total = sum(token_tracker.usage(name) for name in selector.deployment_names)
        assert total == 100

    async def test_stream_429_failover(self, orchestrator, selector, cooldown, semaphores, token_tracker, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        chunks = [_make_chunk("recovered")]
        mock_stream = _MockAsyncStream(chunks)
        error_429 = _make_429_error()
        call_count = [0]

        async def mock_create(**kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise error_429
            return mock_stream

        mock_client = AsyncMock()
        mock_client.chat.completions.create = mock_create

        request = RouteRequest(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
            stream=True,
        )

        collected = []
        async for chunk in orchestrator.execute_stream(
            request=request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=30.0,
            max_retries=3,
        ):
            collected.append(chunk)

        assert len(collected) == 1
        assert collected[0].choices[0].delta.content == "recovered"
        assert call_count[0] == 2

    async def test_stream_all_backends_exhausted(
        self, orchestrator, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)

        error_429 = _make_429_error()

        async def always_fail(**kwargs):
            raise error_429

        mock_client = AsyncMock()
        mock_client.chat.completions.create = always_fail

        request = RouteRequest(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
            stream=True,
        )

        with pytest.raises(RouterExhaustedError, match="All backends exhausted"):
            async for _ in orchestrator.execute_stream(
                request=request,
                selector=selector,
                cooldown=cooldown,
                semaphores=semaphores,
                token_tracker=token_tracker,
                get_client=lambda dep: mock_client,
                timeout=30.0,
                max_retries=2,
            ):
                pass

    async def test_stream_passes_stream_options(
        self, orchestrator, selector, cooldown, semaphores, token_tracker, monkeypatch
    ):
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        chunks = [_make_chunk("ok")]
        mock_stream = _MockAsyncStream(chunks)
        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_stream)

        request = RouteRequest(
            messages=[{"role": "user", "content": "test"}],
            request_class=RequestClass.LIGHT,
            stream=True,
        )

        async for _ in orchestrator.execute_stream(
            request=request,
            selector=selector,
            cooldown=cooldown,
            semaphores=semaphores,
            token_tracker=token_tracker,
            get_client=lambda dep: mock_client,
            timeout=10.0,
            max_retries=3,
        ):
            pass

        call_kwargs = mock_client.chat.completions.create.call_args[1]
        assert call_kwargs["stream_options"] == {"include_usage": True}
        assert call_kwargs["stream"] is True
