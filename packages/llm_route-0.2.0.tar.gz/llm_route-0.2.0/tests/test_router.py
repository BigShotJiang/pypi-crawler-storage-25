"""Integration tests for llm_route.router — SmartRouter."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from openai import APIStatusError
from openai.types.chat import ChatCompletion, ChatCompletionChunk, ChatCompletionMessage
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_chunk import Choice as ChunkChoice
from openai.types.chat.chat_completion_chunk import ChoiceDelta
from openai.types.completion_usage import CompletionUsage

from llm_route.config import RouterConfig
from llm_route.models import RequestClass, RouterExhaustedError
from llm_route.router import SmartRouter


def _make_completion(content: str = "hello", total_tokens: int = 100) -> ChatCompletion:
    return ChatCompletion(
        id="chatcmpl-test",
        choices=[
            Choice(
                index=0,
                message=ChatCompletionMessage(role="assistant", content=content),
                finish_reason="stop",
            )
        ],
        created=1700000000,
        model="gpt-4o",
        object="chat.completion",
        usage=CompletionUsage(prompt_tokens=50, completion_tokens=50, total_tokens=total_tokens),
    )


def _make_429_error() -> APIStatusError:
    resp = MagicMock()
    resp.status_code = 429
    resp.headers = {"retry-after": "5"}
    resp.json.return_value = {"error": {"message": "rate limited"}}
    return APIStatusError(
        message="rate limited",
        response=resp,
        body={"error": {"message": "rate limited"}},
    )


class TestSmartRouter:
    def test_raises_without_deployments(self):
        with pytest.raises(ValueError, match="No deployments configured"):
            SmartRouter(config=RouterConfig())

    async def test_successful_routing(self, router_config):
        router = SmartRouter(config=router_config)
        completion = _make_completion(content="routed response")

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)

        # Patch _get_client to return our mock
        router._get_client = lambda dep: mock_client

        result = await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.completion.choices[0].message.content == "routed response"
        await router.close()

    async def test_429_failover(self, router_config, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        router = SmartRouter(config=router_config)
        completion = _make_completion(content="failover success")
        error_429 = _make_429_error()

        call_count = [0]

        async def mock_create(**kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise error_429
            return completion

        mock_client = AsyncMock()
        mock_client.chat.completions.create = mock_create
        router._get_client = lambda dep: mock_client

        result = await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            request_class=RequestClass.LIGHT,
            timeout=30.0,
        )

        assert result.completion.choices[0].message.content == "failover success"
        assert call_count[0] == 2
        await router.close()

    def test_health_report(self, router_config):
        router = SmartRouter(config=router_config)
        report = router.health()

        assert report.active_deployments == 2
        assert report.cooled_deployments == 0
        assert report.total_inflight == 0
        assert len(report.deployments) == 2

        for dep in report.deployments:
            assert dep.healthy is True

    async def test_streaming_returns_chunks(self, router_config):
        router = SmartRouter(config=router_config)

        chunks = [
            ChatCompletionChunk(
                id="chatcmpl-stream",
                choices=[
                    ChunkChoice(index=0, delta=ChoiceDelta(role="assistant", content="hello"), finish_reason=None)
                ],
                created=1700000000,
                model="gpt-4o",
                object="chat.completion.chunk",
                usage=None,
            ),
            ChatCompletionChunk(
                id="chatcmpl-stream",
                choices=[],
                created=1700000000,
                model="gpt-4o",
                object="chat.completion.chunk",
                usage=CompletionUsage(prompt_tokens=10, completion_tokens=5, total_tokens=15),
            ),
        ]

        class _MockStream:
            def __init__(self, items):
                self._items = iter(items)

            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=_MockStream(chunks))
        router._get_client = lambda dep: mock_client

        stream = await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            stream=True,
        )

        collected = []
        async for chunk in stream:
            collected.append(chunk)

        assert len(collected) == 2
        assert collected[0].choices[0].delta.content == "hello"
        await router.close()

    async def test_health_reflects_cooldown(self, router_config, monkeypatch):
        monkeypatch.setattr("llm_route.cooldown.time.monotonic", lambda: 1000.0)
        monkeypatch.setattr("llm_route.retry.time.monotonic", lambda: 1000.0)

        # max_retries must match deployment count so loop exits after all fail
        router_config.max_retries = 2
        router = SmartRouter(config=router_config)
        error_429 = _make_429_error()

        # Make both deployments fail to trigger cooldowns
        async def always_fail(**kwargs):
            raise error_429

        mock_client = AsyncMock()
        mock_client.chat.completions.create = always_fail
        router._get_client = lambda dep: mock_client

        with pytest.raises(RouterExhaustedError):
            await router.complete(
                messages=[{"role": "user", "content": "hello"}],
                request_class=RequestClass.LIGHT,
                timeout=30.0,
            )

        report = router.health()
        cooled = [d for d in report.deployments if not d.healthy]
        assert len(cooled) >= 1  # at least one deployment was cooled
        assert report.cooled_deployments >= 1
        await router.close()

    async def test_async_context_manager(self, router_config):
        async with SmartRouter(config=router_config) as router:
            report = router.health()
            assert report.active_deployments == 2
        # After exiting, clients should be cleared
        assert len(router._clients) == 0

    async def test_route_result_has_metadata(self, router_config):
        router = SmartRouter(config=router_config)
        completion = _make_completion(content="test", total_tokens=42)

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)
        router._get_client = lambda dep: mock_client

        result = await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            request_class=RequestClass.LIGHT,
        )

        assert result.deployment_name in ("eastus-1", "eastus-2")
        assert result.attempts == 1
        assert result.tokens_used == 42
        assert result.completion.choices[0].message.content == "test"
        await router.close()

    async def test_model_filter(self, router_config):
        """Only eastus-1 has gpt-4o, so model filter should route there."""
        router = SmartRouter(config=router_config)
        completion = _make_completion(content="filtered")

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)
        router._get_client = lambda dep: mock_client

        # Both deployments have deployment_name="gpt-4o" in conftest,
        # so both should be eligible
        result = await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            model="gpt-4o",
        )
        assert result.completion.choices[0].message.content == "filtered"
        await router.close()

    async def test_model_filter_no_match(self, router_config):
        """If no deployment matches the model, raise RouterExhaustedError."""
        router = SmartRouter(config=router_config)

        mock_client = AsyncMock()
        router._get_client = lambda dep: mock_client

        with pytest.raises(RouterExhaustedError):
            await router.complete(
                messages=[{"role": "user", "content": "hello"}],
                model="nonexistent-model",
                timeout=1.0,
            )
        await router.close()

    async def test_extra_kwargs_passthrough(self, router_config):
        """response_format and seed should be passed to OpenAI."""
        router = SmartRouter(config=router_config)
        completion = _make_completion()

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=completion)
        router._get_client = lambda dep: mock_client

        await router.complete(
            messages=[{"role": "user", "content": "hello"}],
            response_format={"type": "json_object"},
            seed=42,
        )

        call_kwargs = mock_client.chat.completions.create.call_args[1]
        assert call_kwargs["response_format"] == {"type": "json_object"}
        assert call_kwargs["seed"] == 42
        await router.close()
