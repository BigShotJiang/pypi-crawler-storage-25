"""llm-route — Intelligent LLM routing library."""

from llm_route.config import DeploymentConfig, RequestClassConfig, RouterConfig
from llm_route.models import (
    DeploymentHealth,
    HealthReport,
    RequestClass,
    RouteRequest,
    RouteResult,
    RouterExhaustedError,
)

__version__ = "0.2.0"
__all__ = [
    "DeploymentConfig",
    "DeploymentHealth",
    "HealthReport",
    "RequestClass",
    "RequestClassConfig",
    "RouteRequest",
    "RouteResult",
    "RouterConfig",
    "RouterExhaustedError",
    "SmartRouter",
]


def __getattr__(name: str):
    if name == "SmartRouter":
        from llm_route.router import SmartRouter

        return SmartRouter
    raise AttributeError(f"module 'llm_route' has no attribute {name!r}")
