"""Sliding window token usage tracking per deployment."""

from __future__ import annotations

import time
from collections import defaultdict, deque


class TokenTracker:
    """Track actual token usage per deployment in a sliding time window.

    Used by the selector to prefer deployments with more remaining TPM headroom.
    Each record is a (monotonic_timestamp, token_count) pair stored in a deque.
    Expired entries are pruned lazily on each read.
    """

    def __init__(self, window_seconds: int = 60) -> None:
        self._window = window_seconds
        self._records: dict[str, deque[tuple[float, int]]] = defaultdict(deque)
        self._totals: dict[str, int] = defaultdict(int)

    def record(self, deployment_name: str, tokens: int) -> None:
        """Record token usage for a deployment."""
        now = time.monotonic()
        self._records[deployment_name].append((now, tokens))
        self._totals[deployment_name] += tokens

    def usage(self, deployment_name: str) -> int:
        """Return total tokens used in the current window."""
        self._prune(deployment_name)
        q = self._records.get(deployment_name)
        if not q:
            return 0
        return sum(tokens for _, tokens in q)

    def utilization(self, deployment_name: str, tpm_quota: int) -> float:
        """Return 0.0-1.0 utilization ratio for a deployment."""
        if tpm_quota <= 0:
            return 1.0
        return min(1.0, self.usage(deployment_name) / tpm_quota)

    def remaining(self, deployment_name: str, tpm_quota: int) -> int:
        """Estimated remaining tokens in the current window."""
        return max(0, tpm_quota - self.usage(deployment_name))

    def total_all_time(self, deployment_name: str) -> int:
        """Total tokens ever recorded for a deployment (not windowed)."""
        return self._totals.get(deployment_name, 0)

    def _prune(self, deployment_name: str) -> None:
        """Remove entries older than the window."""
        q = self._records.get(deployment_name)
        if not q:
            return
        cutoff = time.monotonic() - self._window
        while q and q[0][0] < cutoff:
            q.popleft()
