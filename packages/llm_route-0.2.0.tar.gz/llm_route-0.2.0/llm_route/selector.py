"""Weighted least-outstanding deployment selection algorithm."""

from __future__ import annotations

import random

from llm_route.config import DeploymentConfig
from llm_route.cooldown import CooldownTracker
from llm_route.models import RequestClass
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker


class DeploymentSelector:
    """Select the best deployment for a request using weighted least-outstanding.

    Algorithm:
    1. Filter out disabled deployments
    2. Filter out cooled-down deployments (429 backoff)
    3. Filter out deployments in the exclude set (already tried this request)
    4. Filter out deployments with no available semaphore permits for request class
    5. Score remaining: inflight / weight (lower is better)
    6. Break ties by remaining TPM estimate (higher is better)
    7. Break remaining ties randomly (prevents deterministic hotspots)

    Weight is derived from tpm_quota: weight = tpm_quota / min_tpm_quota.
    A deployment with 2x the TPM quota gets 2x the weight, meaning it needs
    2x the inflight requests to be equally "loaded".
    """

    def __init__(self, deployments: list[DeploymentConfig]) -> None:
        self._deployments = {d.name: d for d in deployments}
        self._weights: dict[str, float] = {}
        self._compute_weights(deployments)

    def _compute_weights(self, deployments: list[DeploymentConfig]) -> None:
        enabled = [d for d in deployments if d.enabled]
        if not enabled:
            return
        min_tpm = min(d.tpm_quota for d in enabled)
        if min_tpm <= 0:
            min_tpm = 1
        for d in enabled:
            self._weights[d.name] = d.tpm_quota / min_tpm

    def select(
        self,
        request_class: RequestClass,
        exclude: set[str],
        cooldown: CooldownTracker,
        semaphores: SemaphoreManager,
        token_tracker: TokenTracker,
        model: str | None = None,
    ) -> DeploymentConfig | None:
        """Return the best available deployment, or None if all are exhausted/cooled.

        Args:
            model: If set, only consider deployments with this deployment_name.
        """
        candidates: list[tuple[float, int, float, DeploymentConfig]] = []

        for name, dep in self._deployments.items():
            if not dep.enabled:
                continue
            if name in exclude:
                continue
            if model is not None and dep.deployment_name != model:
                continue
            if cooldown.is_cooled(name):
                continue
            if not semaphores.available(name, request_class):
                continue

            weight = self._weights.get(name, 1.0)
            inflight = semaphores.inflight(name)
            score = inflight / weight if weight > 0 else float("inf")
            remaining_tpm = token_tracker.remaining(name, dep.tpm_quota)
            tie_breaker = random.random()

            # sort key: lowest score, then highest remaining TPM, then random
            candidates.append((score, -remaining_tpm, tie_breaker, dep))

        if not candidates:
            return None

        candidates.sort(key=lambda x: (x[0], x[1], x[2]))
        return candidates[0][3]

    def get_weight(self, name: str) -> float:
        """Return the computed weight for a deployment."""
        return self._weights.get(name, 1.0)

    @property
    def deployment_names(self) -> list[str]:
        return list(self._deployments.keys())
