"""Health report aggregation for all deployments."""

from __future__ import annotations

from llm_route.config import DeploymentConfig
from llm_route.cooldown import CooldownTracker
from llm_route.models import DeploymentHealth, HealthReport, RequestClass
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker


def build_health_report(
    deployments: list[DeploymentConfig],
    cooldown: CooldownTracker,
    semaphores: SemaphoreManager,
    token_tracker: TokenTracker,
    total_errors: dict[str, int] | None = None,
    total_requests: dict[str, int] | None = None,
) -> HealthReport:
    """Build a health report for all deployments."""
    total_errors = total_errors or {}
    total_requests = total_requests or {}
    items: list[DeploymentHealth] = []
    total_inflight = 0
    active = 0
    cooled = 0

    for dep in deployments:
        is_cooled = cooldown.is_cooled(dep.name)
        inflight = semaphores.inflight(dep.name)
        total_inflight += inflight

        if dep.enabled and not is_cooled:
            active += 1
        if is_cooled:
            cooled += 1

        items.append(
            DeploymentHealth(
                name=dep.name,
                endpoint=dep.endpoint,
                enabled=dep.enabled,
                healthy=dep.enabled and not is_cooled,
                inflight=inflight,
                cooled_until=cooldown.cooled_until(dep.name),
                tpm_used=token_tracker.usage(dep.name),
                tpm_quota=dep.tpm_quota,
                total_requests=total_requests.get(dep.name, 0),
                total_429s=cooldown.total_429s(dep.name),
                total_errors=total_errors.get(dep.name, 0),
                semaphore_available={rc.value: semaphores.available_permits(dep.name, rc) for rc in RequestClass},
            )
        )

    return HealthReport(
        deployments=items,
        total_inflight=total_inflight,
        active_deployments=active,
        cooled_deployments=cooled,
    )
