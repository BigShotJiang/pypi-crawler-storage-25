"""Retry-on-different-backend orchestrator with deadline enforcement."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import AsyncIterator, Callable

from openai import APIStatusError, AsyncAzureOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from llm_route.config import DeploymentConfig
from llm_route.cooldown import CooldownTracker
from llm_route.models import RouteRequest, RouteResult, RouterExhaustedError
from llm_route.selector import DeploymentSelector
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker

logger = logging.getLogger(__name__)


def _parse_retry_after(error: APIStatusError) -> float | None:
    """Extract Retry-After from a 429 response."""
    try:
        response = getattr(error, "response", None)
        if response is not None:
            # Try standard header first
            ra = response.headers.get("retry-after")
            if ra:
                return float(ra)
            # Azure-specific millisecond header
            ra_ms = response.headers.get("retry-after-ms")
            if ra_ms:
                return float(ra_ms) / 1000.0
    except (ValueError, AttributeError):
        pass
    return None


class RetryOrchestrator:
    """Execute a request across multiple deployments with deadline.

    On each attempt:
    1. Select best deployment via weighted least-outstanding
    2. Acquire concurrency semaphore for (deployment, request_class)
    3. Call Azure OpenAI with remaining deadline as timeout
    4. On 429: parse Retry-After, mark cooldown, try next deployment
    5. On 5xx: try next deployment
    6. On success: record token usage, return response
    7. On deadline or all deployments exhausted: raise RouterExhaustedError
    """

    async def execute(
        self,
        request: RouteRequest,
        selector: DeploymentSelector,
        cooldown: CooldownTracker,
        semaphores: SemaphoreManager,
        token_tracker: TokenTracker,
        get_client: Callable[[DeploymentConfig], AsyncAzureOpenAI],
        timeout: float,
        max_retries: int,
    ) -> RouteResult:
        deadline = time.monotonic() + timeout
        tried: set[str] = set()
        last_error: Exception | None = None
        total_errors: dict[str, int] = {}
        attempts = 0

        while time.monotonic() < deadline:
            deployment = selector.select(
                request_class=request.request_class,
                exclude=tried,
                cooldown=cooldown,
                semaphores=semaphores,
                token_tracker=token_tracker,
                model=request.model,
            )

            if deployment is None:
                # No deployment available right now.
                # Could be: all failed (tried), all cooled, or all semaphores full.
                cooldown_wait = cooldown.min_cooldown_remaining()
                remaining = deadline - time.monotonic()

                if len(tried) >= max_retries:
                    # Hit the retry limit on actual backend failures — stop.
                    break

                if cooldown_wait is not None and cooldown_wait < min(5.0, remaining):
                    # A cooled deployment will become available soon.
                    await asyncio.sleep(cooldown_wait + 0.1)
                    continue

                if remaining > 0.2:
                    # Semaphores may be full — wait briefly for a slot to free up.
                    await asyncio.sleep(0.1)
                    continue

                # Deadline about to expire — stop.
                break

            attempts += 1

            try:
                response = await self._call_deployment(
                    deployment=deployment,
                    request=request,
                    semaphores=semaphores,
                    get_client=get_client,
                    deadline=deadline,
                )

                # Record token usage
                tokens_used = 0
                if response.usage:
                    tokens_used = response.usage.total_tokens
                    token_tracker.record(deployment.name, tokens_used)

                logger.info(
                    "request_routed",
                    extra={
                        "deployment": deployment.name,
                        "attempt": attempts,
                        "tokens": tokens_used,
                    },
                )
                return RouteResult(
                    completion=response,
                    deployment_name=deployment.name,
                    attempts=attempts,
                    tokens_used=tokens_used,
                )

            except _RetryOnNextBackend as e:
                tried.add(deployment.name)
                last_error = e.original
                total_errors[deployment.name] = total_errors.get(deployment.name, 0) + 1

                if isinstance(e.original, APIStatusError) and e.original.status_code == 429:
                    retry_after = _parse_retry_after(e.original)
                    cooldown.mark_cooled(deployment.name, retry_after)

                logger.info(
                    "retrying_next_backend",
                    extra={
                        "failed_deployment": deployment.name,
                        "attempt": attempts,
                        "error": str(e.original),
                    },
                )

                if len(tried) >= max_retries:
                    break
                continue

            except Exception:
                # Non-retryable error — propagate immediately
                raise

        raise RouterExhaustedError(
            f"All backends exhausted after {len(tried)} attempts. "
            f"Tried: {', '.join(tried) or 'none available'}. "
            f"Last error: {last_error}"
        )

    async def _call_deployment(
        self,
        deployment: DeploymentConfig,
        request: RouteRequest,
        semaphores: SemaphoreManager,
        get_client: Callable[[DeploymentConfig], AsyncAzureOpenAI],
        deadline: float,
    ) -> ChatCompletion:
        """Call a specific deployment within the semaphore and deadline."""
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise _RetryOnNextBackend(TimeoutError("deadline exceeded"))

        sem_timeout = min(remaining, 10.0)
        try:
            async with semaphores.acquire(deployment.name, request.request_class, timeout=sem_timeout):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise _RetryOnNextBackend(TimeoutError("deadline exceeded after semaphore"))

                client = get_client(deployment)
                kwargs = request.openai_kwargs()
                kwargs["model"] = deployment.deployment_name

                return await asyncio.wait_for(
                    client.chat.completions.create(**kwargs),
                    timeout=remaining,
                )

        except asyncio.TimeoutError as e:
            raise _RetryOnNextBackend(e)

        except APIStatusError as e:
            if e.status_code == 429 or e.status_code >= 500:
                raise _RetryOnNextBackend(e)
            raise  # 4xx (not 429) is a client error, don't retry

    async def execute_stream(
        self,
        request: RouteRequest,
        selector: DeploymentSelector,
        cooldown: CooldownTracker,
        semaphores: SemaphoreManager,
        token_tracker: TokenTracker,
        get_client: Callable[[DeploymentConfig], AsyncAzureOpenAI],
        timeout: float,
        max_retries: int,
    ) -> AsyncIterator[ChatCompletionChunk]:
        """Execute a streaming request across deployments with failover.

        Retries happen only during connection setup. Once the first chunk
        is yielded, the stream is committed to a single deployment.
        The concurrency semaphore is held for the entire stream duration.
        """
        deadline = time.monotonic() + timeout
        tried: set[str] = set()
        last_error: Exception | None = None
        attempts = 0

        while time.monotonic() < deadline:
            deployment = selector.select(
                request_class=request.request_class,
                exclude=tried,
                cooldown=cooldown,
                semaphores=semaphores,
                token_tracker=token_tracker,
                model=request.model,
            )

            if deployment is None:
                cooldown_wait = cooldown.min_cooldown_remaining()
                remaining = deadline - time.monotonic()

                if len(tried) >= max_retries:
                    break

                if cooldown_wait is not None and cooldown_wait < min(5.0, remaining):
                    await asyncio.sleep(cooldown_wait + 0.1)
                    continue

                if remaining > 0.2:
                    await asyncio.sleep(0.1)
                    continue

                break

            attempts += 1

            try:
                remaining = deadline - time.monotonic()
                sem_timeout = min(remaining, 10.0)

                async with semaphores.acquire(deployment.name, request.request_class, timeout=sem_timeout):
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise _RetryOnNextBackend(TimeoutError("deadline exceeded after semaphore"))

                    client = get_client(deployment)
                    kwargs = request.openai_kwargs()
                    kwargs["model"] = deployment.deployment_name
                    kwargs["stream_options"] = {"include_usage": True}

                    # Errors during create() trigger failover
                    try:
                        stream = await asyncio.wait_for(
                            client.chat.completions.create(**kwargs),
                            timeout=remaining,
                        )
                    except asyncio.TimeoutError as e:
                        raise _RetryOnNextBackend(e)
                    except APIStatusError as e:
                        if e.status_code == 429 or e.status_code >= 500:
                            raise _RetryOnNextBackend(e)
                        raise

                    # Stream opened — committed to this deployment.
                    # Mid-stream errors propagate to the caller.
                    usage_tokens = 0
                    async for chunk in stream:
                        if chunk.usage:
                            usage_tokens = chunk.usage.total_tokens
                        yield chunk

                    if usage_tokens:
                        token_tracker.record(deployment.name, usage_tokens)

                    logger.info(
                        "stream_routed",
                        extra={
                            "deployment": deployment.name,
                            "attempt": attempts,
                            "tokens": usage_tokens,
                        },
                    )
                    return

            except _RetryOnNextBackend as e:
                tried.add(deployment.name)
                last_error = e.original

                if isinstance(e.original, APIStatusError) and e.original.status_code == 429:
                    retry_after = _parse_retry_after(e.original)
                    cooldown.mark_cooled(deployment.name, retry_after)

                logger.info(
                    "stream_retrying_next_backend",
                    extra={
                        "failed_deployment": deployment.name,
                        "attempt": attempts,
                        "error": str(e.original),
                    },
                )

                if len(tried) >= max_retries:
                    break
                continue

            except Exception:
                raise

        raise RouterExhaustedError(
            f"All backends exhausted after {len(tried)} attempts. "
            f"Tried: {', '.join(tried) or 'none available'}. "
            f"Last error: {last_error}"
        )


class _RetryOnNextBackend(Exception):
    """Internal: wraps an error that should trigger failover to next backend."""

    def __init__(self, original: Exception) -> None:
        self.original = original
        super().__init__(str(original))
