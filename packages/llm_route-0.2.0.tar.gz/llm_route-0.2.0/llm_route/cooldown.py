"""429 cooldown tracker — marks deployments as unavailable after throttling."""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class CooldownTracker:
    """Track per-deployment cooldown periods after 429 responses.

    When a deployment returns HTTP 429, it is marked as "cooled down"
    for a duration derived from the Retry-After header (or a default).
    The selector skips cooled deployments when choosing where to route.

    All timestamps use time.monotonic() for accuracy (immune to clock adjustments).
    """

    def __init__(self, default_cooldown: float = 10.0) -> None:
        self._default_cooldown = default_cooldown
        self._cooldowns: dict[str, float] = {}  # name -> monotonic expiry
        self._total_429s: dict[str, int] = {}

    def mark_cooled(self, name: str, retry_after: float | None = None) -> None:
        """Mark a deployment as cooled down.

        Args:
            name: Deployment name.
            retry_after: Seconds to cool down. If None, uses default.
        """
        duration = retry_after if retry_after is not None else self._default_cooldown
        self._cooldowns[name] = time.monotonic() + duration
        self._total_429s[name] = self._total_429s.get(name, 0) + 1
        logger.warning(
            "deployment_cooled",
            extra={"deployment": name, "retry_after": duration, "total_429s": self._total_429s[name]},
        )

    def is_cooled(self, name: str) -> bool:
        """Check if a deployment is currently in cooldown."""
        expiry = self._cooldowns.get(name)
        if expiry is None:
            return False
        if time.monotonic() >= expiry:
            del self._cooldowns[name]
            return False
        return True

    def cooled_until(self, name: str) -> datetime | None:
        """Return the wall-clock time when cooldown expires, or None."""
        expiry = self._cooldowns.get(name)
        if expiry is None:
            return None
        remaining = expiry - time.monotonic()
        if remaining <= 0:
            return None
        return (
            datetime.now(timezone.utc)
            .replace(microsecond=0)
            .__add__(__import__("datetime").timedelta(seconds=remaining))
        )

    def remaining_seconds(self, name: str) -> float:
        """Seconds remaining in cooldown, or 0 if not cooled."""
        expiry = self._cooldowns.get(name)
        if expiry is None:
            return 0.0
        remaining = expiry - time.monotonic()
        return max(0.0, remaining)

    def clear(self, name: str) -> None:
        """Manually clear cooldown for a deployment."""
        self._cooldowns.pop(name, None)

    def total_429s(self, name: str) -> int:
        """Total number of 429s recorded for this deployment."""
        return self._total_429s.get(name, 0)

    def min_cooldown_remaining(self) -> float | None:
        """Return the shortest remaining cooldown across all deployments, or None."""
        now = time.monotonic()
        remaining = [exp - now for exp in self._cooldowns.values() if exp > now]
        return min(remaining) if remaining else None
