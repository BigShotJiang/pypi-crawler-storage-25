"""Enums and Pydantic schemas for llm-route."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class RequestClass(str, Enum):
    """Concurrency class for request isolation."""

    LIGHT = "light"
    MEDIUM = "medium"
    HEAVY = "heavy"


class RouteRequest(BaseModel):
    """A chat completion request to be routed."""

    messages: list[dict]
    request_class: RequestClass = RequestClass.MEDIUM
    model: str | None = None
    timeout: float | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    stop: list[str] | str | None = None
    stream: bool = False
    extra_kwargs: dict = Field(default_factory=dict)

    def openai_kwargs(self) -> dict:
        """Return kwargs to pass to openai chat.completions.create()."""
        kwargs: dict = {"messages": self.messages}
        if self.temperature is not None:
            kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            kwargs["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            kwargs["top_p"] = self.top_p
        if self.stop is not None:
            kwargs["stop"] = self.stop
        if self.stream:
            kwargs["stream"] = True
        kwargs.update(self.extra_kwargs)
        return kwargs


class DeploymentHealth(BaseModel):
    """Health status of a single deployment."""

    name: str
    endpoint: str
    enabled: bool
    healthy: bool
    inflight: int = 0
    cooled_until: datetime | None = None
    tpm_used: int = 0
    tpm_quota: int = 0
    total_requests: int = 0
    total_429s: int = 0
    total_errors: int = 0
    semaphore_available: dict[str, int] = Field(default_factory=dict)


class HealthReport(BaseModel):
    """Aggregate health report for all deployments."""

    deployments: list[DeploymentHealth]
    total_inflight: int = 0
    active_deployments: int = 0
    cooled_deployments: int = 0


class RouteResult(BaseModel):
    """Wrapper around a ChatCompletion with routing metadata."""

    model_config = {"arbitrary_types_allowed": True}

    completion: object  # ChatCompletion — arbitrary_types_allowed for openai types
    deployment_name: str
    attempts: int = 1
    tokens_used: int = 0


class RouterExhaustedError(Exception):
    """All backends failed, cooled down, or deadline expired."""

    pass
