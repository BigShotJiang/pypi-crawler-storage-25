"""Per-(deployment, request_class) concurrency isolation using asyncio semaphores."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from llm_route.config import DeploymentConfig, RequestClassConfig
from llm_route.models import RequestClass


class SemaphoreManager:
    """Manage concurrency limits per deployment per request class.

    Each (deployment, request_class) pair gets its own asyncio.Semaphore.
    This prevents heavy requests from starving light ones on the same deployment.
    """

    def __init__(self, deployments: list[DeploymentConfig], config: RequestClassConfig) -> None:
        self._semaphores: dict[tuple[str, RequestClass], asyncio.Semaphore] = {}
        self._inflight: dict[tuple[str, RequestClass], int] = {}

        for dep in deployments:
            for rc in RequestClass:
                key = (dep.name, rc)
                limit = config.get_limit(rc)
                self._semaphores[key] = asyncio.Semaphore(limit)
                self._inflight[key] = 0

    @asynccontextmanager
    async def acquire(self, name: str, request_class: RequestClass, timeout: float = 10.0) -> AsyncIterator[None]:
        """Acquire a semaphore permit. Raises TimeoutError if timeout expires.

        Usage:
            async with sem_manager.acquire("eastus-1", RequestClass.HEAVY):
                # do work
        """
        key = (name, request_class)
        sem = self._semaphores.get(key)
        if sem is None:
            raise KeyError(f"Unknown deployment/class: {name}/{request_class.value}")

        await asyncio.wait_for(sem.acquire(), timeout=timeout)
        self._inflight[key] += 1
        try:
            yield
        finally:
            self._inflight[key] -= 1
            sem.release()

    def available(self, name: str, request_class: RequestClass) -> bool:
        """Check if at least one permit is available (non-blocking)."""
        key = (name, request_class)
        sem = self._semaphores.get(key)
        if sem is None:
            return False
        return sem._value > 0

    def inflight(self, name: str, request_class: RequestClass | None = None) -> int:
        """Current inflight count for a deployment, optionally filtered by class."""
        if request_class is not None:
            return self._inflight.get((name, request_class), 0)
        return sum(self._inflight.get((name, rc), 0) for rc in RequestClass)

    def available_permits(self, name: str, request_class: RequestClass) -> int:
        """Number of available permits for a deployment/class pair."""
        key = (name, request_class)
        sem = self._semaphores.get(key)
        if sem is None:
            return 0
        return sem._value
