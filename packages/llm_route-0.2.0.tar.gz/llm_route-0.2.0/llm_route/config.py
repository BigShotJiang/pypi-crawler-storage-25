"""Configuration via Pydantic Settings — env vars + optional JSON config file."""

from __future__ import annotations

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

from llm_route.models import RequestClass


class DeploymentConfig(BaseModel):
    """Configuration for a single Azure OpenAI deployment."""

    name: str
    endpoint: str
    api_key: str
    deployment_name: str
    api_version: str = "2024-12-01-preview"
    tpm_quota: int = 60_000
    max_concurrency: int = 50
    enabled: bool = True


class RequestClassConfig(BaseModel):
    """Per-deployment concurrency limits by request class."""

    light: int = 20
    medium: int = 10
    heavy: int = 3

    def get_limit(self, request_class: RequestClass) -> int:
        return {
            RequestClass.LIGHT: self.light,
            RequestClass.MEDIUM: self.medium,
            RequestClass.HEAVY: self.heavy,
        }[request_class]


class RouterConfig(BaseSettings):
    """Router configuration. Loaded from env vars and/or JSON config file.

    Env var prefix: LLM_ROUTE_
    JSON config: set LLM_ROUTE_CONFIG_FILE env var to a JSON file path.

    Example env vars:
        LLM_ROUTE_DEFAULT_TIMEOUT=60.0
        LLM_ROUTE_MAX_RETRIES=3
        LLM_ROUTE_CONFIG_FILE=./config.json
    """

    model_config = SettingsConfigDict(
        env_prefix="LLM_ROUTE_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    deployments: list[DeploymentConfig] = []
    concurrency: RequestClassConfig = RequestClassConfig()
    default_timeout: float = 60.0
    max_retries: int = 3
    cooldown_seconds: float = 10.0
    token_window_seconds: int = 60
    redis_url: str | None = None

    @classmethod
    def from_file(cls, path: str) -> RouterConfig:
        """Load config from a JSON file."""
        import json
        from pathlib import Path

        data = json.loads(Path(path).read_text())
        return cls(**data)
