"""SmartRouter — main entry point that composes all routing components."""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import AsyncIterator

from openai import AsyncAzureOpenAI
from openai.types.chat import ChatCompletionChunk

from llm_route.config import DeploymentConfig, RouterConfig
from llm_route.cooldown import CooldownTracker
from llm_route.health import build_health_report
from llm_route.models import HealthReport, RequestClass, RouteRequest, RouteResult
from llm_route.retry import RetryOrchestrator
from llm_route.selector import DeploymentSelector
from llm_route.semaphores import SemaphoreManager
from llm_route.token_tracker import TokenTracker

logger = logging.getLogger(__name__)


class SmartRouter:
    """Intelligent LLM router with weighted least-outstanding selection.

    Drop-in replacement for direct Azure OpenAI calls. Routes requests
    across multiple deployments with automatic failover, 429 cooldown,
    and request class isolation.

    Usage:
        router = SmartRouter()  # reads config from env/file
        response = await router.complete(
            messages=[{"role": "user", "content": "Hello"}],
            request_class=RequestClass.LIGHT,
        )

    Or with explicit config:
        config = RouterConfig(deployments=[...])
        router = SmartRouter(config=config)
    """

    def __init__(self, config: RouterConfig | None = None) -> None:
        self._config = config or RouterConfig()
        if not self._config.deployments:
            raise ValueError(
                "No deployments configured. Set LLM_ROUTE_DEPLOYMENTS env var or pass deployments in RouterConfig."
            )

        self._selector = DeploymentSelector(self._config.deployments)
        self._cooldown = CooldownTracker(self._config.cooldown_seconds)
        self._semaphores = SemaphoreManager(self._config.deployments, self._config.concurrency)
        self._token_tracker = TokenTracker(self._config.token_window_seconds)
        self._retry = RetryOrchestrator()
        self._clients: dict[str, AsyncAzureOpenAI] = {}
        self._total_requests: dict[str, int] = defaultdict(int)
        self._total_errors: dict[str, int] = defaultdict(int)

        logger.info(
            "router_initialized",
            extra={
                "deployments": [
                    {"name": d.name, "tpm": d.tpm_quota, "weight": self._selector.get_weight(d.name)}
                    for d in self._config.deployments
                    if d.enabled
                ],
            },
        )

    def _get_client(self, deployment: DeploymentConfig) -> AsyncAzureOpenAI:
        """Get or create an AsyncAzureOpenAI client for a deployment."""
        if deployment.name not in self._clients:
            self._clients[deployment.name] = AsyncAzureOpenAI(
                azure_endpoint=deployment.endpoint,
                api_key=deployment.api_key,
                api_version=deployment.api_version,
                max_retries=0,  # we handle retries ourselves
            )
        return self._clients[deployment.name]

    async def complete(
        self,
        messages: list[dict],
        request_class: RequestClass = RequestClass.MEDIUM,
        model: str | None = None,
        timeout: float | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        top_p: float | None = None,
        stop: list[str] | str | None = None,
        stream: bool = False,
        **kwargs,
    ) -> RouteResult | AsyncIterator[ChatCompletionChunk]:
        """Route a chat completion request to the best available deployment.

        Args:
            messages: OpenAI-format messages list.
            request_class: Concurrency class (LIGHT, MEDIUM, HEAVY).
            model: Filter to deployments with this deployment_name (e.g. "gpt-4o-mini").
            timeout: Total deadline in seconds. Defaults to config value.
            temperature: Sampling temperature.
            max_tokens: Maximum completion tokens.
            top_p: Nucleus sampling parameter.
            stop: Stop sequences.
            stream: If True, return an async iterator of ChatCompletionChunk.
            **kwargs: Extra OpenAI params (response_format, seed, etc.).

        Returns:
            RouteResult when stream=False (contains completion + deployment metadata),
            AsyncIterator[ChatCompletionChunk] when stream=True.

        Raises:
            RouterExhaustedError: All backends failed or deadline expired.
        """
        request = RouteRequest(
            messages=messages,
            request_class=request_class,
            model=model,
            timeout=timeout,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            stop=stop,
            stream=stream,
            extra_kwargs=kwargs if kwargs else {},
        )

        effective_timeout = request.timeout or self._config.default_timeout

        if stream:
            return self._retry.execute_stream(
                request=request,
                selector=self._selector,
                cooldown=self._cooldown,
                semaphores=self._semaphores,
                token_tracker=self._token_tracker,
                get_client=self._get_client,
                timeout=effective_timeout,
                max_retries=self._config.max_retries,
            )

        return await self._retry.execute(
            request=request,
            selector=self._selector,
            cooldown=self._cooldown,
            semaphores=self._semaphores,
            token_tracker=self._token_tracker,
            get_client=self._get_client,
            timeout=effective_timeout,
            max_retries=self._config.max_retries,
        )

    def health(self) -> HealthReport:
        """Return health status of all deployments."""
        return build_health_report(
            deployments=self._config.deployments,
            cooldown=self._cooldown,
            semaphores=self._semaphores,
            token_tracker=self._token_tracker,
            total_errors=dict(self._total_errors),
            total_requests=dict(self._total_requests),
        )

    async def close(self) -> None:
        """Close all OpenAI clients."""
        for client in self._clients.values():
            await client.close()
        self._clients.clear()

    async def __aenter__(self) -> SmartRouter:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()
