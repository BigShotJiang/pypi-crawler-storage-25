## Scope

- [ ] One feature, behavior change, or hardening effort only
- [ ] Linked spec / issue / audit finding:
- [ ] User-facing command or API surface changed:
- [ ] Existing CLI help output changed: yes / no
- [ ] No unrelated changes bundled

## Rollback

- [ ] Rollback path documented:
- [ ] State/data migration impact: none / described below

## Verification

- [ ] Local tests passed:
- [ ] Coverage gate passed:
- [ ] Lint/type/guardrail checks passed:
- [ ] Slow or real-model proofs run, or explicitly not required:

## Notes

Describe assumptions, skipped checks, or production risks reviewers should know.
