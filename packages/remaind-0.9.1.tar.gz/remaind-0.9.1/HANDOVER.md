# Remaind — Handover & Real-Model Testing Guide

This document is the handover package for **Remaind v0.6.4**. It explains what
the product is, how to install it, **how to test it end-to-end against a real
local model**, and how to implement it in an agent. It is self-contained — for
the deep programmatic integration guide see [`docs/integration.md`](docs/integration.md).

---

## 1. What Remaind is

Remaind is a **durable context ledger, compaction pipeline, and resume
substrate for long-running AI agents** — a Python 3.11+ CLI library. It
preserves the meaningful state of an agent run across context-window resets:
a fresh agent loads the local `.context/` directory, understands what happened
before, knows what must happen next, and continues — without the user
reconstructing the work.

It is a **substrate, not a framework**: it does not run your agent or call your
model. Your agent loop reads from and writes to it; Remaind owns the
`.context/` directory.

**100% local.** No cloud API, no API key. Two runtime dependencies
(`jsonschema`, `pyyaml`). Model-backed compaction talks to a *local* model
runtime over plain HTTP using only the standard library.

---

## 2. Status — what is and isn't verified

| | |
|---|---|
| **Published** | `pip install remaind` → **v0.6.4** on PyPI |
| **Repo** | `magpiexyz-lab/Remaind` (private) |
| **Tests** | package tests, starter-kit tests, `ruff`, `mypy`, web lint/build, and release zip build verified |
| **Verified end-to-end** | CLI lifecycle, the full Python API, persistence, redaction, error handling, the website — all exercised against real clean-room installs |
| **Real-model compaction** | Verified against a running local Ollama model with `qwen3.6-35b-a3b-full:latest`, `REMAIND_OLLAMA_NUM_CTX=262144`, and `REMAIND_LOCAL_MODEL_TIMEOUT=360`. |

The core package now treats local model output as messy by default: it disables
Ollama thinking traces unless opted in, extracts balanced JSON from mixed
responses, ignores invalid model-proposed state enum values, and exposes a
timeout override for large local models.

New raw events also carry writer-owned hash-chain metadata. `remaind validate`
recomputes that chain to detect continuity-breaking edits, deletions, or
reordering, and resume packets label retrieved evidence with mechanical trust
hints such as `user`, `verified_tool`, `assistant`, and `source_linked_memory`.

---

## 3. Install

Use a virtual environment — standard practice, and on macOS it sidesteps the
`externally-managed-environment` block on Homebrew / system Python:

```sh
python3 -m venv .venv && source .venv/bin/activate
pip install remaind
```

Python ≥ 3.11. That's the whole install — no extras, no optional
dependencies, no keys.

```sh
remaind --version      # remaind 0.6.4
remaind --help         # init, validate, status, doctor, compact, resume, rollback
```

---

## 4. Set up a real local model

Remaind's compactor talks to a **local model runtime**. Pick one:

### Option A — Ollama (auto-detected, zero config)

```sh
# install Ollama (https://ollama.com), then:
ollama serve                 # starts the runtime on localhost:11434
ollama pull llama3.1         # or qwen2.5, mistral — any instruct/chat model
```

That's it. Remaind auto-detects Ollama on its default port — nothing to
configure.

### Option B — an OpenAI-compatible server (opt-in)

vLLM, llama.cpp's server, LM Studio, etc. expose an OpenAI-compatible API.
These have no canonical port, so they are **opt-in** via one env var:

```sh
# start your server, e.g. vLLM on :8000, then:
export REMAIND_OPENAI_BASE_URL=http://localhost:8000/v1
```

> **Pick an instruct/chat model.** Compaction sends a structured prompt; an
> embedding or base (non-chat) model cannot follow it — the candidate gets
> rejected by the validator (safe, but compaction makes no progress). If the
> runtime's *first* model isn't a chat model, set `REMAIND_OLLAMA_MODEL` /
> `REMAIND_OPENAI_MODEL` explicitly.

If no runtime is reachable, `remaind compact` silently falls back to a
rule-based compactor (deterministic bookkeeping — it does **not** summarize;
the handover grows). So a model is required for *real* compaction.

---

## 5. Verify it works end-to-end with a real model

With a runtime from §4 running:

```sh
mkdir remaind-test && cd remaind-test
remaind init                       # creates ./.context/
```

Seed a few events so there is something to compact (events are logged through
the Python API — there is no `remaind log` command):

```python
# seed.py
import remaind
base = "."
state = remaind.status(base)
sid, tid = state["session_id"], state["task_id"]
w = remaind.EventWriter.open(base)

def log(t, a, s, **k):
    w.append(remaind.EventInput(type=t, actor=a, summary=s,
                                session_id=sid, task_id=tid, **k))

log("user_message", "user", "Refactor the auth module to TokenV2",
    content="Please migrate src/auth/ to the new token format", importance=3)
log("assistant_message", "assistant", "Proposed the plan",
    content="1) introduce TokenV2  2) migrate the middleware  3) tests")
log("tool_result", "tool:bash", "test suite passed", content="all tests passing", importance=2)
log("decision", "assistant", "chose token format v2",
    content="v2 is forward-compatible", importance=2)
remaind.update_state(base, lambda st: {**st, "next_step": "wire TokenV2 into the middleware"})
print("seeded")
```

```sh
python seed.py
remaind compact
```

**What to check:**

1. The output line names the runtime, e.g.
   `Compacted via local model via Ollama (llama3.1): ... handover 1240 -> 690 chars (-550)`.
   - `via local model via Ollama (…)` / `via OpenAI-compatible API (…)` →
     **the real model ran.** `via rule-based fallback` → no runtime was
     detected (re-check §4).
2. The handover size delta is reported. A real model should usually shrink a
   non-trivial handover, but a tiny seed handover may grow because the model is
   adding the required structured continuity sections.
3. Inspect `.context/active/handover.md` — it should be a coherent, compressed
   continuity document that still preserves the decisions, the importance-3
   user instruction, and a grounded `next_step`.
4. `remaind compact` again, or `remaind resume`, then `remaind validate` —
   everything should stay well-formed.

**If the candidate is rejected** (`compaction rejected by validator: …`):
that is the safety boundary working — a weak model produced an unfaithful
candidate, so the prior handover was kept untouched. Try a stronger
instruct model. Nothing is lost.

Repeat with the other runtime (Option B) to verify the OpenAI-compatible path.

---

## 6. The CLI

Seven commands cover the whole lifecycle. Every state-mutating command snapshots
the prior version before writing.

| Command | What it does |
|---|---|
| `remaind init [--path P] [--force]` | Create `.context/`. `--force` backs up an existing one first. |
| `remaind validate [--path P]` | Walk the structural checklist: layout, schemas, state, handover, events, SQLite. |
| `remaind status [--path P] [--json]` | Goal, status, next step, token band, event counts, compaction recommendation. |
| `remaind doctor [--path P] [--json]` | Read-only health check for context validity and local model runtime detection. |
| `remaind compact [--path P]` | Run the compaction pipeline, gated by structured validation. Uses a local model automatically (see §4), else the rule-based fallback. Reports which compactor ran. |
| `remaind resume [--path P] [--next-tool T] [--memories K] [--excerpts N]` | Build `active/resume_packet.md` and consult the resume gate. |
| `remaind rollback [--path P] --to TS` | Restore derived files from history as of `TS` (ISO 8601 or `20260514T035433Z`). `events.jsonl` is never touched. |

---

## 7. Implementing Remaind in an agent

`import remaind` is the entire stable public API. The integration is a loop
your harness drives. Minimal shape (full guide + exception reference in
[`docs/integration.md`](docs/integration.md)):

```python
import remaind

base = "./my-agent-run"
remaind.init(base)                                    # once

state = remaind.status(base)
sid, tid = state["session_id"], state["task_id"]
writer = remaind.EventWriter.open(base)

def log(type_, actor, summary, *, content=None, importance=1):
    writer.append(remaind.EventInput(
        type=type_, actor=actor, summary=summary,
        session_id=sid, task_id=tid, content=content, importance=importance,
    ))

while not done:
    user_msg = get_user_message()
    log("user_message", "user", user_msg[:80], content=user_msg, importance=3)

    reply, tool_calls, total_tokens = run_model_turn(...)
    log("assistant_message", "assistant", reply[:80], content=reply)
    for call in tool_calls:
        log("tool_call", f"tool:{call.name}", call.summary, content=call.args)
        log("tool_result", f"tool:{call.name}", call.result_summary,
            content=call.result, importance=2)

    # feed Remaind your token estimate; it tells you the band
    remaind.update_state(base, lambda st: {**st, "estimated_context_tokens": total_tokens})

    cs = remaind.compaction_status(base)
    if cs.compaction_urgent:
        try:
            remaind.compact(base)               # uses your local model
        except remaind.CompactionRejected:
            pass                                # prior handover kept — safe

    if cs.band == "emergency":
        packet = remaind.resume(base).packet
        reset_model_context(packet.content)     # YOUR code injects the packet
```

Key points:
- **Importance drives compaction.** Tag every event `0`–`3` honestly.
  `≥ 2` must survive every compaction; `3` (critical user instruction / active
  next step) must be explicit in state or handover.
- **Redaction and large-output routing are automatic** on every `append` —
  secrets are hashed before disk; oversized/binary content goes to
  `artifacts/` with excerpts + a hash kept in the event.
- **Injecting the resume packet is your job.** `resume` assembles it; your
  harness decides where it goes (typically the fresh context's system prompt).
- Before resuming, check `packet.gate` — it interrupts on conflicts, a missing
  `next_step`, an unrepresented user instruction, or a risky next tool.

---

## 8. The `.context/` directory

One directory per project. Created by `remaind init`:

```
.context/
├── CONTRACT.md            the binding contract — read this first
├── active/
│   ├── state.json         derived working state (atomic replace)
│   ├── handover.md         compact continuity document (atomic replace)
│   ├── resume_packet.md    runtime — assembled fresh-context packet
│   └── history/            runtime — snapshots of every prior version
├── logs/
│   └── events.jsonl       append-only raw timeline (source of truth)
├── schemas/               JSON Schemas + thresholds / redaction / tools config
├── db/context.sqlite      runtime — memory index + FTS5
└── artifacts/             runtime — large + binary outputs
```

**Authority order** (lower wins when sources disagree): latest user
instruction → `events.jsonl` → `state.json` → `handover.md` → derived
memories. A stale summary can never override a newer user instruction.

---

## 9. Environment variables

All optional — the Ollama path needs none.

| Variable | Effect |
|---|---|
| `OLLAMA_HOST` | Ollama base URL. Default `http://localhost:11434`. |
| `REMAIND_OLLAMA_MODEL` | Which installed Ollama model to use. Default: the first it reports. |
| `REMAIND_OLLAMA_THINK` | Whether to allow Ollama thinking traces. Default `false` for JSON-safe compaction. |
| `REMAIND_OLLAMA_TEMPERATURE` | Ollama generation temperature. Default `0.1`. |
| `REMAIND_OLLAMA_NUM_CTX` | Optional Ollama context-window override for large local models. |
| `REMAIND_OLLAMA_NUM_PREDICT` | Optional Ollama output-token override for longer handovers. |
| `REMAIND_OPENAI_BASE_URL` | `/v1` base URL of an OpenAI-compatible server (vLLM / llama.cpp / LM Studio). Setting it opts into that runtime — it takes precedence over Ollama. |
| `REMAIND_OPENAI_MODEL` | Which model to request from that server. Default: the first it reports. |
| `REMAIND_OPENAI_TEMPERATURE` | OpenAI-compatible generation temperature. Default `0.1`. |
| `REMAIND_OPENAI_MAX_TOKENS` | Optional OpenAI-compatible output-token override. |
| `REMAIND_LOCAL_MODEL_TIMEOUT` | Chat request timeout in seconds. Default `120`; raise it for very large local models. |
| `REMAIND_DISABLE_LOCAL_MODEL` | Set to a non-empty value to force the rule-based compactor and skip detection. |

---

## 10. How compaction works (the safety model)

A **compactor only ever proposes a candidate** — a structured validator
decides whether to accept it. The validator runs six mechanical checks
(decisions preserved, `next_step` grounded, importance-3 items represented,
latest user instruction preserved, …). If *any* check fails, the candidate is
**rejected** and the prior handover is kept untouched; a `validation` event
records why.

This is why a weak local model **cannot corrupt context** — the worst case is
a rejected candidate and a handover that didn't shrink. The model proposes;
only the validator disposes.

---

## 11. Known limitations

- **OpenAI-compatible runtimes are opt-in, not probed** — no canonical port;
  set `REMAIND_OPENAI_BASE_URL`.
- **Model selection is naive** — the first model the runtime lists is used
  unless a model env var is set. Point it at a real instruct/chat model.
- **No auth on the OpenAI-compatible path** — no `Authorization` header is
  sent; a local server requiring a key is not supported.
- **Detection is silent and best-effort** — a ~1s probe; a runtime that's up
  but slow reads as absent → silent rule-based fallback. Check the
  `remaind compact` output line to confirm which compactor ran.
- **The rule-based fallback does not summarize** — it is bookkeeping; the
  handover grows. A model is required for real compression.
- **Single-writer** — do not point two processes at one `.context/`.
- **v1 non-goals** — no remote sync, no hosted UI, no multi-agent coordination,
  no vector search.

---

## 12. More

- **Full integration guide** (public API, the five-step integration,
  exception reference): [`docs/integration.md`](docs/integration.md)
- **CONTRACT.md** — the binding contract — ships inside `.context/` after
  `remaind init`.
- **Website**: <https://remaind.draftlabs.org> (How it works · Demo · Docs · Integrate)
