"""Small dependency-free terminal selection helpers."""

from __future__ import annotations

import importlib
import os
import shutil
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any, Generic, TextIO, TypeVar, cast

T = TypeVar("T")

_ENTER = "enter"
_ESCAPE = "escape"
_UP = "up"
_DOWN = "down"
_HOME = "home"
_END = "end"
_PAGE_UP = "page_up"
_PAGE_DOWN = "page_down"
_CTRL_H = "ctrl+h"
_UNKNOWN = "unknown"


class TerminalSelectionCancelled(Exception):
    """Raised when a user cancels an interactive terminal selection."""


@dataclass(frozen=True)
class MenuChoice(Generic[T]):
    """A selectable terminal menu entry."""

    label: str
    value: T
    shortcut: str | None = None


def select_menu(
    *,
    title: str,
    choices: Sequence[MenuChoice[T]],
    stdin: TextIO,
    stdout: TextIO,
    default_index: int = 0,
    max_visible: int = 12,
) -> T | None:
    """Return a selected value using Up/Down + Enter, or None when unsupported."""

    if not choices:
        raise ValueError("select_menu requires at least one choice")
    if not _supports_interactive_keys(stdin, stdout):
        return None
    index = min(max(default_index, 0), len(choices) - 1)
    start = 0
    rendered_lines = 0

    with _raw_terminal(stdin):
        while True:
            page_size = _page_size(max_visible=max_visible)
            start = _window_start(index, start, page_size=page_size)
            rendered_lines = _render_menu(
                title=title,
                choices=choices,
                selected_index=index,
                start=start,
                page_size=page_size,
                stdout=stdout,
                previous_lines=rendered_lines,
            )
            key = _read_key(stdin)
            if key == _ENTER:
                selected = choices[index]
                _finish_menu(
                    title=title,
                    selected_label=selected.label,
                    stdout=stdout,
                    previous_lines=rendered_lines,
                )
                return selected.value
            if key == _ESCAPE:
                _clear_previous(stdout, rendered_lines)
                raise TerminalSelectionCancelled("selection cancelled")
            if key in {_UP, "k"}:
                index = max(0, index - 1)
                continue
            if key in {_DOWN, "j"}:
                index = min(len(choices) - 1, index + 1)
                continue
            if key == _HOME:
                index = 0
                continue
            if key == _END:
                index = len(choices) - 1
                continue
            if key == _PAGE_UP:
                index = max(0, index - page_size)
                continue
            if key == _PAGE_DOWN:
                index = min(len(choices) - 1, index + page_size)
                continue
            shortcut_index = _shortcut_index(choices, key)
            if shortcut_index is not None:
                index = shortcut_index
                if _shortcut_is_immediate(choices[index].shortcut):
                    selected = choices[index]
                    _finish_menu(
                        title=title,
                        selected_label=selected.label,
                        stdout=stdout,
                        previous_lines=rendered_lines,
                    )
                    return selected.value
                continue


def _supports_interactive_keys(stdin: TextIO, stdout: TextIO) -> bool:
    if not stdin.isatty() or not stdout.isatty():
        return False
    try:
        stdin.fileno()
        stdout.fileno()
    except (AttributeError, OSError):
        return False
    return True


class _raw_terminal:
    def __init__(self, stdin: TextIO) -> None:
        self._stdin = stdin
        self._fd: int | None = None
        self._old_attrs: Any | None = None

    def __enter__(self) -> None:
        if os.name == "nt":
            return
        import termios
        import tty

        self._fd = self._stdin.fileno()
        self._old_attrs = termios.tcgetattr(self._fd)
        tty.setcbreak(self._fd)

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if os.name == "nt" or self._fd is None or self._old_attrs is None:
            return
        import termios

        termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old_attrs)


def _read_key(stdin: TextIO) -> str:
    if os.name == "nt":
        return _read_windows_key()
    return _read_posix_key(stdin)


def _read_windows_key() -> str:
    module = importlib.import_module("msvcrt")
    getch_name = "getch"
    getch = cast(Callable[[], bytes], getattr(module, getch_name))

    char = getch()
    if char == b"\x03":
        raise KeyboardInterrupt
    if char in {b"\r", b"\n"}:
        return _ENTER
    if char == b"\x1b":
        return _ESCAPE
    if char == b"\x08":
        return _CTRL_H
    if char not in {b"\x00", b"\xe0"}:
        return char.decode("utf-8", errors="ignore").lower() or _UNKNOWN
    code = getch()
    return {
        b"H": _UP,
        b"P": _DOWN,
        b"G": _HOME,
        b"O": _END,
        b"I": _PAGE_UP,
        b"Q": _PAGE_DOWN,
    }.get(code, _UNKNOWN)


def _read_posix_key(stdin: TextIO) -> str:
    import select

    fd = stdin.fileno()
    data = os.read(fd, 1)
    if not data:
        return _ESCAPE
    if data == b"\x03":
        raise KeyboardInterrupt
    if data == b"\x08":
        return _CTRL_H
    if data in {b"\r", b"\n"}:
        return _ENTER
    if data != b"\x1b":
        return data.decode("utf-8", errors="ignore").lower() or _UNKNOWN
    if not select.select([fd], [], [], 0.05)[0]:
        return _ESCAPE
    second = os.read(fd, 1)
    if second != b"[":
        return _ESCAPE
    if not select.select([fd], [], [], 0.05)[0]:
        return _UNKNOWN
    third = os.read(fd, 1)
    if third in {b"A", b"k"}:
        return _UP
    if third in {b"B", b"j"}:
        return _DOWN
    if third == b"H":
        return _HOME
    if third == b"F":
        return _END
    if third in {b"1", b"5", b"6", b"4"}:
        if select.select([fd], [], [], 0.05)[0]:
            os.read(fd, 1)
        return {
            b"1": _HOME,
            b"4": _END,
            b"5": _PAGE_UP,
            b"6": _PAGE_DOWN,
        }.get(third, _UNKNOWN)
    return _UNKNOWN


def _page_size(*, max_visible: int) -> int:
    height = shutil.get_terminal_size(fallback=(100, 24)).lines
    return max(4, min(max_visible, height - 6))


def _window_start(index: int, start: int, *, page_size: int) -> int:
    if index < start:
        return index
    if index >= start + page_size:
        return index - page_size + 1
    return start


def _shortcut_index(choices: Sequence[MenuChoice[Any]], key: str) -> int | None:
    if not key or key == _UNKNOWN:
        return None
    for index, choice in enumerate(choices):
        if choice.shortcut and key == choice.shortcut.lower():
            return index
    if key.isdecimal():
        parsed = int(key)
        if 1 <= parsed <= min(len(choices), 9):
            return parsed - 1
    return None


def _shortcut_is_immediate(shortcut: str | None) -> bool:
    return bool(shortcut and shortcut.lower().startswith("ctrl+"))


def _shortcut_label(shortcut: str) -> str:
    if shortcut.lower().startswith("ctrl+"):
        _, key = shortcut.split("+", 1)
        return f"Ctrl+{key.upper()}"
    return shortcut


def _render_menu(
    *,
    title: str,
    choices: Sequence[MenuChoice[Any]],
    selected_index: int,
    start: int,
    page_size: int,
    stdout: TextIO,
    previous_lines: int,
) -> int:
    _clear_previous(stdout, previous_lines)
    end = min(len(choices), start + page_size)
    lines = [
        title,
        "Use Up/Down to move, Enter to select, Esc to cancel.",
        "",
    ]
    if start > 0:
        lines.append("  ...")
    for index in range(start, end):
        choice = choices[index]
        prefix = "> " if index == selected_index else "  "
        line = prefix + choice.label
        if choice.shortcut:
            line += f"  ({_shortcut_label(choice.shortcut)})"
        if index == selected_index:
            line = f"\x1b[7m{line}\x1b[0m"
        lines.append(_truncate_for_terminal(line))
    if end < len(choices):
        lines.append("  ...")
    if len(choices) > page_size:
        lines.append(f"Showing {start + 1}-{end} of {len(choices)}")
    stdout.write("\n".join(lines) + "\n")
    stdout.flush()
    return len(lines)


def _finish_menu(
    *,
    title: str,
    selected_label: str,
    stdout: TextIO,
    previous_lines: int,
) -> None:
    _clear_previous(stdout, previous_lines)
    stdout.write(f"{title}: {selected_label}\n")
    stdout.flush()


def _clear_previous(stdout: TextIO, previous_lines: int) -> None:
    if previous_lines <= 0:
        return
    stdout.write(f"\x1b[{previous_lines}F\x1b[J")


def _truncate_for_terminal(text: str) -> str:
    width = shutil.get_terminal_size(fallback=(100, 24)).columns
    if width <= 10 or len(text) <= width:
        return text
    return text[: max(1, width - 3)] + "..."
