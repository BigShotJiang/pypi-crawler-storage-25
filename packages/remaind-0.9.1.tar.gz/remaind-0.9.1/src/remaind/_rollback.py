"""Rollback target normalization and history discovery.

History snapshot filenames use ``utc_now_filename_safe_us()`` —
``%Y%m%dT%H%M%S_%fZ`` — which sorts lexicographically by time. This module
turns user-supplied timestamps into that shape and walks history
directories to find the latest snapshot at or before a target.
"""

from __future__ import annotations

import datetime as _dt
import re
from pathlib import Path

from ._errors import RemaindError

_FILENAME_SAFE = re.compile(r"^(\d{8})T(\d{6})Z$")
_FILENAME_SAFE_US = re.compile(r"^(\d{8})T(\d{6})_(\d{6})Z$")


class RollbackError(RemaindError):
    """Raised when rollback input is unparseable or cannot proceed."""


def normalize_target(target: str) -> str:
    """Normalize ``target`` to the filename-safe-us format.

    Accepted inputs:

    * ``20260514T035433_254699Z`` — filename-safe-us, returned verbatim.
    * ``20260514T035433Z``         — filename-safe; microseconds padded to ``999999``.
    * ``2026-05-14T03:54:33.254699Z`` — ISO 8601 with microseconds.
    * ``2026-05-14T03:54:33Z``     — ISO 8601 without microseconds (padded).
    * ``2026-05-14T03:54:33+00:00`` — ISO 8601 with explicit UTC offset.

    Padding microseconds to ``999999`` captures any snapshot taken during
    the named second.
    """
    if not isinstance(target, str):
        raise RollbackError(f"target must be a string, got {type(target).__name__}")
    s = target.strip()
    if not s:
        raise RollbackError("target is empty")

    if _FILENAME_SAFE_US.match(s):
        return s
    if m := _FILENAME_SAFE.match(s):
        date, time = m.group(1), m.group(2)
        return f"{date}T{time}_999999Z"

    iso = s.replace("Z", "+00:00") if s.endswith("Z") else s
    try:
        dt = _dt.datetime.fromisoformat(iso)
    except ValueError as exc:
        raise RollbackError(f"unparseable timestamp: {target!r}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.UTC)
    dt = dt.astimezone(_dt.UTC)
    # If the user supplied no microseconds, pad to capture the entire second.
    if "." not in s:
        dt = dt.replace(microsecond=999_999)
    return dt.strftime("%Y%m%dT%H%M%S_%fZ")


def discover_snapshots(history_dir: Path) -> list[Path]:
    """Return snapshot files in ``history_dir`` sorted by filename (== time)."""
    if not history_dir.is_dir():
        return []
    return sorted(p for p in history_dir.iterdir() if p.is_file())


def find_snapshot_active_at(
    history_dir: Path, target: str
) -> Path | None:
    """Return the snapshot whose content was active at ``target``, or ``None``.

    Snapshots are named by **supersede time** — when they were replaced by a
    later write. The snapshot whose content was active at moment ``T`` is
    therefore the one with the smallest filename strictly greater than ``T``:
    content that survived until that supersede point.

    Returns ``None`` only when ``target`` is past every snapshot (the
    currently-active file was already in place at ``T`` — no rollback
    needed) or the history directory is empty.
    """
    snapshots = discover_snapshots(history_dir)
    after = [p for p in snapshots if p.stem > target]
    return after[0] if after else None
