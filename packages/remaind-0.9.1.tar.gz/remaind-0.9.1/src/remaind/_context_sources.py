"""Normalized context sources for the context engineering engine."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from ._tokens import estimate_tokens

ContextAuthority = Literal[
    "current_user",
    "current_session",
    "live_status",
    "product_authority",
    "handover",
    "source_evidence",
    "derived_memory",
    "generated_answer",
]
ContextFreshness = Literal["live", "current", "recent", "historical", "static"]
ContextSourceType = Literal[
    "answer_instruction",
    "active_state",
    "artifact_inventory",
    "benchmark_evidence",
    "benchmark_profile",
    "compaction_source",
    "conversation",
    "current_question",
    "decision_ledger",
    "deep_evidence",
    "document_chunk",
    "document_head",
    "document_tail",
    "handover",
    "packet_history",
    "presence",
    "preference_state",
    "memory_record",
    "memory_relation",
    "note_ledger",
    "plan_reconciliation",
    "product_plan",
    "product_status",
    "progress",
    "raw_log",
    "resume_packet",
    "resume_gate",
    "runtime_status",
    "search_evidence",
    "source_metadata",
    "stale_memory_warning",
    "structured_marker",
    "turn_evidence",
]

AUTHORITY_ORDER: tuple[ContextAuthority, ...] = (
    "current_user",
    "current_session",
    "live_status",
    "product_authority",
    "handover",
    "source_evidence",
    "derived_memory",
    "generated_answer",
)

AUTHORITY_RANK: dict[ContextAuthority, int] = {
    authority: len(AUTHORITY_ORDER) - index for index, authority in enumerate(AUTHORITY_ORDER)
}

FRESHNESS_RANK: dict[ContextFreshness, int] = {
    "live": 5,
    "current": 4,
    "recent": 3,
    "historical": 2,
    "static": 1,
}


@dataclass(frozen=True)
class ContextSource:
    id: str
    title: str
    source_type: ContextSourceType
    authority: ContextAuthority
    freshness: ContextFreshness
    content: str
    mandatory: bool
    reason: str
    budget_group: str = "general"
    path: Path | None = None
    timestamp: str | None = None

    @property
    def token_count(self) -> int:
        return estimate_tokens(self.content)

    @property
    def priority(self) -> tuple[int, int]:
        return (
            AUTHORITY_RANK[self.authority],
            FRESHNESS_RANK[self.freshness],
        )


@dataclass(frozen=True)
class OmittedContextSource:
    id: str
    title: str
    source_type: str
    reason: str
    token_count: int


def context_source_from_lines(
    *,
    id: str,
    title: str,
    source_type: ContextSourceType,
    authority: ContextAuthority,
    freshness: ContextFreshness,
    lines: list[str],
    mandatory: bool,
    reason: str,
    budget_group: str = "general",
    path: Path | None = None,
    timestamp: str | None = None,
) -> ContextSource:
    return ContextSource(
        id=id,
        title=title,
        source_type=source_type,
        authority=authority,
        freshness=freshness,
        content="\n".join(lines).rstrip() + "\n",
        mandatory=mandatory,
        reason=reason,
        budget_group=budget_group,
        path=path,
        timestamp=timestamp,
    )
