"""Resolved on-disk paths inside a `.context/` root."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ContextPaths:
    root: Path

    @classmethod
    def at(cls, base: Path) -> ContextPaths:
        """Return paths rooted at ``base/.context``."""
        return cls(root=base / ".context")

    # Top-level
    @property
    def readme(self) -> Path:
        return self.root / "README.md"

    @property
    def contract(self) -> Path:
        return self.root / "CONTRACT.md"

    # active/
    @property
    def active_dir(self) -> Path:
        return self.root / "active"

    @property
    def state_json(self) -> Path:
        return self.active_dir / "state.json"

    @property
    def handover_md(self) -> Path:
        return self.active_dir / "handover.md"

    @property
    def history_dir(self) -> Path:
        return self.active_dir / "history"

    @property
    def resume_packet(self) -> Path:
        return self.active_dir / "resume_packet.md"

    @property
    def progress_snapshot(self) -> Path:
        return self.active_dir / "progress_snapshot.json"

    @property
    def presence_snapshot(self) -> Path:
        return self.active_dir / "presence_snapshot.json"

    @property
    def product_status_json(self) -> Path:
        return self.active_dir / "product_status.json"

    @property
    def product_status_md(self) -> Path:
        return self.active_dir / "product_status.md"

    @property
    def plan_reconciliation_json(self) -> Path:
        return self.active_dir / "plan_reconciliation.json"

    @property
    def plan_reconciliation_md(self) -> Path:
        return self.active_dir / "plan_reconciliation.md"

    # logs/
    @property
    def logs_dir(self) -> Path:
        return self.root / "logs"

    @property
    def events_jsonl(self) -> Path:
        return self.logs_dir / "events.jsonl"

    @property
    def progress_jsonl(self) -> Path:
        return self.logs_dir / "progress.jsonl"

    @property
    def presence_jsonl(self) -> Path:
        return self.logs_dir / "presence.jsonl"

    @property
    def product_status_jsonl(self) -> Path:
        return self.logs_dir / "product_status.jsonl"

    @property
    def plan_reconciliation_jsonl(self) -> Path:
        return self.logs_dir / "plan_reconciliation.jsonl"

    # schemas/
    @property
    def schemas_dir(self) -> Path:
        return self.root / "schemas"

    @property
    def event_schema(self) -> Path:
        return self.schemas_dir / "event.schema.json"

    @property
    def state_schema(self) -> Path:
        return self.schemas_dir / "state.schema.json"

    @property
    def memory_schema(self) -> Path:
        return self.schemas_dir / "memory.schema.json"

    @property
    def validation_schema(self) -> Path:
        return self.schemas_dir / "validation.schema.json"

    @property
    def thresholds_yaml(self) -> Path:
        return self.schemas_dir / "thresholds.yaml"

    @property
    def redaction_yaml(self) -> Path:
        return self.schemas_dir / "redaction.yaml"

    @property
    def tools_yaml(self) -> Path:
        return self.schemas_dir / "tools.yaml"

    @property
    def migrations_state_dir(self) -> Path:
        return self.schemas_dir / "migrations" / "state"

    @property
    def migrations_events_dir(self) -> Path:
        return self.schemas_dir / "migrations" / "events"

    # Runtime (git-ignored, created by later phases)
    @property
    def db_dir(self) -> Path:
        return self.root / "db"

    @property
    def db_sqlite(self) -> Path:
        return self.db_dir / "context.sqlite"

    @property
    def artifacts_dir(self) -> Path:
        return self.root / "artifacts"

    @property
    def large_docs_dir(self) -> Path:
        return self.root / "large-docs"
