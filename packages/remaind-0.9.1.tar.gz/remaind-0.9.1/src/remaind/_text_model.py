"""Local text-model transport shared by Remaind runtime features.

This module owns the HTTP boundary for local model runtimes. It is deliberately
small: no SDKs and no cloud defaults. OpenAI-compatible local endpoints may opt
into a bearer token via ``REMAIND_OPENAI_API_KEY`` when the local server requires
one. Higher-level features provide their own prompts, schemas, and validation.
"""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from ._errors import RemaindError

DEFAULT_OLLAMA_HOST = "http://localhost:11434"
DEFAULT_LOCAL_MODEL_TEMPERATURE = 0.1
PROBE_TIMEOUT_S = 1.0
CHAT_TIMEOUT_S = 600.0
OLLAMA_API_VALUES = frozenset({"auto", "chat", "generate"})
OPENAI_API_VALUES = frozenset({"auto", "chat", "completions"})

Transport = Callable[[str, dict[str, Any]], dict[str, Any]]


class TextModelError(RemaindError):
    """Raised when a local text model cannot complete a request."""


@dataclass(frozen=True)
class ModelInfo:
    kind: str
    model: str
    endpoint: str
    api_mode: str | None = None
    context_window_tokens: int | None = None

    @property
    def label(self) -> str:
        if self.kind == "ollama":
            mode = f" {self.api_mode}" if self.api_mode else ""
            return f"local model via Ollama{mode} ({self.model})"
        return f"local model via OpenAI-compatible API ({self.model})"


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise TextModelError(f"{name} must be one of: true, false, 1, 0, yes, no")


def _env_float(name: str, *, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError as exc:
        raise TextModelError(f"{name} must be a number") from exc


def _env_positive_float(name: str, *, default: float) -> float:
    value = _env_float(name, default=default)
    if value <= 0:
        raise TextModelError(f"{name} must be greater than zero")
    return value


def _env_int_optional(name: str) -> int | None:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return None
    try:
        value = int(raw)
    except ValueError as exc:
        raise TextModelError(f"{name} must be an integer") from exc
    if value <= 0:
        raise TextModelError(f"{name} must be greater than zero")
    return value


def _env_choice(name: str, *, default: str, choices: frozenset[str]) -> str:
    raw = os.environ.get(name)
    value = default if raw is None or raw.strip() == "" else raw.strip().lower()
    if value not in choices:
        allowed = ", ".join(sorted(choices))
        raise TextModelError(f"{name} must be one of: {allowed}")
    return value


def _chat_timeout_s() -> float:
    return _env_positive_float("REMAIND_LOCAL_MODEL_TIMEOUT", default=CHAT_TIMEOUT_S)


def _ollama_host() -> str:
    host = os.environ.get("OLLAMA_HOST", "").strip() or DEFAULT_OLLAMA_HOST
    if not host.startswith(("http://", "https://")):
        host = f"http://{host}"
    return host.rstrip("/")


def _openai_base_url() -> str | None:
    raw = os.environ.get("REMAIND_OPENAI_BASE_URL", "").strip()
    if not raw:
        return None
    if not raw.startswith(("http://", "https://")):
        raw = f"http://{raw}"
    return raw.rstrip("/")


def _openai_auth_headers() -> dict[str, str]:
    token = os.environ.get("REMAIND_OPENAI_API_KEY", "").strip()
    if not token:
        return {}
    return {"Authorization": f"Bearer {token}"}


def _openai_transport() -> Transport:
    headers = _openai_auth_headers()

    def post(url: str, body: dict[str, Any]) -> dict[str, Any]:
        return _urllib_post_json(url, body, headers=headers)

    return post


def _urllib_post_json(
    url: str, body: dict[str, Any], *, headers: dict[str, str] | None = None
) -> dict[str, Any]:
    data = json.dumps(body).encode("utf-8")
    request_headers = {"Content-Type": "application/json", **(headers or {})}
    req = urllib.request.Request(
        url, data=data, headers=request_headers, method="POST"
    )
    with urllib.request.urlopen(req, timeout=_chat_timeout_s()) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _http_post_json(
    url: str, body: dict[str, Any], timeout: float
) -> dict[str, Any] | None:
    data = json.dumps(body).encode("utf-8")
    try:
        req = urllib.request.Request(
            url, data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _http_get_json(
    url: str, timeout: float, *, headers: dict[str, str] | None = None
) -> dict[str, Any] | None:
    try:
        req = urllib.request.Request(url, headers=headers or {}, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _ollama_models(host: str, timeout: float = PROBE_TIMEOUT_S) -> list[str]:
    payload = _http_get_json(f"{host}/api/tags", timeout)
    if payload is None:
        return []
    models = payload.get("models")
    if not isinstance(models, list):
        return []
    return [
        str(m["name"])
        for m in models
        if isinstance(m, dict) and isinstance(m.get("name"), str)
    ]


def _ollama_show(
    host: str, model: str, timeout: float = PROBE_TIMEOUT_S
) -> dict[str, Any] | None:
    return _http_post_json(f"{host}/api/show", {"model": model}, timeout)


def _ollama_api_mode_from_env() -> str:
    return _env_choice(
        "REMAIND_OLLAMA_API", default="auto", choices=OLLAMA_API_VALUES
    )


def _openai_models(base_url: str, timeout: float = PROBE_TIMEOUT_S) -> list[str]:
    payload = _http_get_json(
        f"{base_url}/models", timeout, headers=_openai_auth_headers()
    )
    if payload is None:
        return []
    data = payload.get("data")
    if not isinstance(data, list):
        return []
    return [
        str(m["id"])
        for m in data
        if isinstance(m, dict) and isinstance(m.get("id"), str)
    ]


def _pick_model(models: list[str], env_var: str) -> str | None:
    if not models:
        return None
    preferred = os.environ.get(env_var, "").strip()
    if preferred:
        for name in models:
            if name == preferred or name.split(":", 1)[0] == preferred:
                return name
    return models[0]


def _openai_api_mode_from_env() -> str:
    return _env_choice(
        "REMAIND_OPENAI_API", default="auto", choices=OPENAI_API_VALUES
    )


def _post_model_request(
    transport: Transport, url: str, body: dict[str, Any]
) -> dict[str, Any]:
    try:
        return transport(url, body)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace").strip()
        suffix = f": {detail}" if detail else ""
        raise TextModelError(
            f"could not reach the local model at {url}: HTTP {exc.code}{suffix}"
        ) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise TextModelError(
            f"could not reach the local model at {url}: {type(exc).__name__}: {exc}"
        ) from exc
    except Exception as exc:
        raise TextModelError(
            f"the local model call failed: {type(exc).__name__}: {exc}"
        ) from exc


def _ollama_options(*, max_tokens: int | None = None) -> dict[str, Any]:
    options: dict[str, Any] = {
        "temperature": _env_float(
            "REMAIND_OLLAMA_TEMPERATURE", default=DEFAULT_LOCAL_MODEL_TEMPERATURE
        )
    }
    num_ctx = _env_int_optional("REMAIND_OLLAMA_NUM_CTX")
    if num_ctx is not None:
        options["num_ctx"] = num_ctx
    num_predict = max_tokens if max_tokens is not None else _env_int_optional(
        "REMAIND_OLLAMA_NUM_PREDICT"
    )
    if num_predict is not None:
        options["num_predict"] = num_predict
    return options


def _openai_options(body: dict[str, Any]) -> dict[str, Any]:
    patched = dict(body)
    patched["temperature"] = _env_float(
        "REMAIND_OPENAI_TEMPERATURE", default=DEFAULT_LOCAL_MODEL_TEMPERATURE
    )
    max_tokens = _env_int_optional("REMAIND_OPENAI_MAX_TOKENS")
    if max_tokens is not None and "max_tokens" not in patched:
        patched["max_tokens"] = max_tokens
    return patched


def strip_model_artifacts(text: str) -> str:
    cleaned = text.strip()
    if "</think>" in cleaned:
        return cleaned.split("</think>", 1)[1].strip()
    return cleaned


def _balanced_json_candidates(text: str) -> list[str]:
    candidates: list[str] = []
    for start, char in enumerate(text):
        if char != "{":
            continue
        depth = 0
        in_string = False
        escaped = False
        for idx in range(start, len(text)):
            current = text[idx]
            if in_string:
                if escaped:
                    escaped = False
                elif current == "\\":
                    escaped = True
                elif current == '"':
                    in_string = False
                continue
            if current == '"':
                in_string = True
            elif current == "{":
                depth += 1
            elif current == "}":
                depth -= 1
                if depth == 0:
                    candidates.append(text[start : idx + 1])
                    break
    return candidates


def _loads_json_object(candidate: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(candidate)
    except (json.JSONDecodeError, ValueError):
        return None
    return payload if isinstance(payload, dict) else None


def _best_payload(objects: list[dict[str, Any]]) -> dict[str, Any] | None:
    for obj in objects:
        if "new_handover" in obj:
            return obj
    return objects[0] if objects else None


def extract_json_payload(text: str) -> dict[str, Any]:
    cleaned = strip_model_artifacts(text)
    objects: list[dict[str, Any]] = []
    whole = _loads_json_object(cleaned)
    if whole is not None:
        objects.append(whole)
    for fence in re.finditer(
        r"```(?:json)?\s*(.*?)\s*```", cleaned, re.DOTALL | re.IGNORECASE
    ):
        fenced = _loads_json_object(fence.group(1).strip())
        if fenced is not None:
            objects.append(fenced)
    for candidate in _balanced_json_candidates(cleaned):
        payload = _loads_json_object(candidate)
        if payload is not None:
            objects.append(payload)
    best = _best_payload(objects)
    if best is not None:
        return best
    raise TextModelError("could not extract a JSON object from the model's text output")


def _ollama_completion_prompt(system_text: str, user_text: str) -> str:
    return (
        "System instructions:\n"
        f"{system_text.strip()}\n\n"
        "User input:\n"
        f"{user_text.strip()}\n\n"
        "Assistant response:\n"
    )


def _ollama_chat_body(
    model: str,
    system_text: str,
    user_text: str,
    *,
    json_mode: bool,
    max_tokens: int | None,
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_text},
            {"role": "user", "content": user_text},
        ],
        "stream": False,
        "think": _env_bool("REMAIND_OLLAMA_THINK", default=False),
        "options": _ollama_options(max_tokens=max_tokens),
    }
    if json_mode:
        body["format"] = "json"
    return body


def _ollama_generate_body(
    model: str,
    system_text: str,
    user_text: str,
    *,
    json_mode: bool,
    max_tokens: int | None,
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "model": model,
        "prompt": _ollama_completion_prompt(system_text, user_text),
        "stream": False,
        "options": _ollama_options(max_tokens=max_tokens),
    }
    if json_mode:
        body["format"] = "json"
    return body


def _ollama_chat_content(response: dict[str, Any]) -> Any:
    message = response.get("message") if isinstance(response, dict) else None
    return message.get("content") if isinstance(message, dict) else None


def _ollama_generate_content(response: dict[str, Any]) -> Any:
    return response.get("response") if isinstance(response, dict) else None


def _openai_completion_prompt(system_text: str, user_text: str, *, json_mode: bool) -> str:
    suffix = "\n\nReturn one raw JSON object only." if json_mode else ""
    return (
        "System instructions:\n"
        f"{system_text.strip()}\n\n"
        "User input:\n"
        f"{user_text.strip()}\n\n"
        "Assistant response:"
        f"{suffix}"
    )


def _openai_chat_content(response: dict[str, Any]) -> Any:
    choices = response.get("choices") if isinstance(response, dict) else None
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        message = choices[0].get("message")
        if isinstance(message, dict):
            return message.get("content")
    return None


def _openai_completion_content(response: dict[str, Any]) -> Any:
    choices = response.get("choices") if isinstance(response, dict) else None
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        return choices[0].get("text")
    return None


class TextModelClient:
    """Thin client for one selected local text model."""

    def __init__(
        self,
        info: ModelInfo,
        *,
        transport: Transport | None = None,
    ) -> None:
        self._info = info
        self._transport = transport or _urllib_post_json

    @classmethod
    def from_env(cls) -> TextModelClient | None:
        if os.environ.get("REMAIND_DISABLE_LOCAL_MODEL", "").strip():
            return None
        oai_base = _openai_base_url()
        if oai_base is not None:
            model = _pick_model(_openai_models(oai_base), "REMAIND_OPENAI_MODEL")
            if model is not None:
                return cls(
                    ModelInfo(
                        kind="openai-compatible",
                        model=model,
                        endpoint=oai_base,
                        api_mode=_openai_api_mode_from_env(),
                    ),
                    transport=_openai_transport(),
                )
        host = _ollama_host()
        model = _pick_model(_ollama_models(host), "REMAIND_OLLAMA_MODEL")
        if model is not None:
            return cls(
                ModelInfo(
                    kind="ollama",
                    model=model,
                    endpoint=host,
                    api_mode=_ollama_api_mode_from_env(),
                )
            )
        return None

    @property
    def label(self) -> str:
        return self._info.label

    def describe(self) -> ModelInfo:
        return self._info

    def available(self) -> bool:
        if self._info.kind == "ollama":
            return self._info.model in _ollama_models(self._info.endpoint)
        return self._info.model in _openai_models(self._info.endpoint)

    def smoke_test(self) -> dict[str, Any]:
        """Run a tiny generation proof against the selected runtime/model."""
        try:
            content = self.complete(
                'Return exactly this JSON object: {"remaind_smoke":"ok"}',
                system=(
                    "You are a local Remaind readiness probe. Return only JSON. "
                    "Do not include markdown."
                ),
                json_mode=True,
                max_tokens=64,
            )
            payload = extract_json_payload(content)
        except TextModelError as exc:
            return {
                "ok": False,
                "api": self._info.api_mode or "auto",
                "error": str(exc),
            }
        if payload.get("remaind_smoke") == "ok":
            return {"ok": True, "api": self._info.api_mode or "auto"}
        return {
            "ok": False,
            "api": self._info.api_mode or "auto",
            "error": "the local model did not return the expected smoke payload",
        }

    def complete(
        self,
        prompt: str,
        *,
        system: str | None = None,
        json_mode: bool = False,
        max_tokens: int | None = None,
    ) -> str:
        system_text = system or "You are a local Remaind text model."
        if self._info.kind == "ollama":
            return self._complete_ollama(
                system_text,
                prompt,
                json_mode=json_mode,
                max_tokens=max_tokens,
            )
        return self._complete_openai(
            system_text, prompt, json_mode=json_mode, max_tokens=max_tokens
        )

    def _complete_ollama(
        self,
        system_text: str,
        user_text: str,
        *,
        json_mode: bool,
        max_tokens: int | None,
    ) -> str:
        mode = self._info.api_mode or "auto"
        failures: list[str] = []
        if mode in {"chat", "auto"}:
            try:
                response = _post_model_request(
                    self._transport,
                    f"{self._info.endpoint}/api/chat",
                    _ollama_chat_body(
                        self._info.model,
                        system_text,
                        user_text,
                        json_mode=json_mode,
                        max_tokens=max_tokens,
                    ),
                )
                content = _ollama_chat_content(response)
                if not isinstance(content, str) or not content.strip():
                    raise TextModelError("the local model returned no message content")
                return strip_model_artifacts(content)
            except TextModelError as exc:
                if mode == "chat":
                    raise
                failures.append(f"chat failed: {exc}")
        if mode in {"generate", "auto"}:
            try:
                response = _post_model_request(
                    self._transport,
                    f"{self._info.endpoint}/api/generate",
                    _ollama_generate_body(
                        self._info.model,
                        system_text,
                        user_text,
                        json_mode=json_mode,
                        max_tokens=max_tokens,
                    ),
                )
                content = _ollama_generate_content(response)
                if not isinstance(content, str) or not content.strip():
                    raise TextModelError("the local model returned no message content")
                return strip_model_artifacts(content)
            except TextModelError as exc:
                failures.append(f"generate failed: {exc}")
        detail = "; ".join(failures) or f"unsupported Ollama API mode {mode}"
        raise TextModelError(detail)

    def _complete_openai(
        self,
        system_text: str,
        user_text: str,
        *,
        json_mode: bool,
        max_tokens: int | None,
    ) -> str:
        mode = self._info.api_mode or "auto"
        failures: list[str] = []
        if mode in {"chat", "auto"}:
            try:
                body: dict[str, Any] = {
                    "model": self._info.model,
                    "messages": [
                        {"role": "system", "content": system_text},
                        {"role": "user", "content": user_text},
                    ],
                    "stream": False,
                }
                if json_mode:
                    body["response_format"] = {"type": "json_object"}
                if max_tokens is not None:
                    body["max_tokens"] = max_tokens
                response = _post_model_request(
                    self._transport,
                    f"{self._info.endpoint}/chat/completions",
                    _openai_options(body),
                )
                content = _openai_chat_content(response)
                if not isinstance(content, str) or not content.strip():
                    raise TextModelError("the local model returned no message content")
                return strip_model_artifacts(content)
            except TextModelError as exc:
                if mode == "chat":
                    raise
                failures.append(f"chat failed: {exc}")
        if mode in {"completions", "auto"}:
            try:
                body = {
                    "model": self._info.model,
                    "prompt": _openai_completion_prompt(
                        system_text, user_text, json_mode=json_mode
                    ),
                    "stream": False,
                }
                if max_tokens is not None:
                    body["max_tokens"] = max_tokens
                response = _post_model_request(
                    self._transport,
                    f"{self._info.endpoint}/completions",
                    _openai_options(body),
                )
                content = _openai_completion_content(response)
                if not isinstance(content, str) or not content.strip():
                    raise TextModelError("the local model returned no completion text")
                return strip_model_artifacts(content)
            except TextModelError as exc:
                failures.append(f"completions failed: {exc}")
        detail = "; ".join(failures) or f"unsupported OpenAI-compatible API mode {mode}"
        raise TextModelError(detail)
