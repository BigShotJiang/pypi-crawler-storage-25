"""Normalization helpers for imperfect local-model document summaries.

These helpers intentionally preserve only candidates that can be mapped back to
already verified source items. They are isolated from the main pipeline because
silent rewrites are the highest-risk part of model-output handling.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

from ._doc_cache import SUPPORT_TYPES
from ._doc_planner import ChunkPlan
from ._large_doc import LargeDocumentIngestResult

_TOPIC_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]{3,}")
_EVIDENCE_TEXT_KEYS = (
    "quote",
    "quote_text",
    "text",
    "fact_text",
    "claim_text",
    "final_synthesis_phrase",
    "synthesis_phrase",
    "signal_value",
    "answer",
    "final_answer",
    "phrase",
)

def _coerce_source_lines(value: Any, chunk: ChunkPlan) -> list[int] | None:
    if isinstance(value, int | str):
        try:
            line = int(value)
        except (TypeError, ValueError):
            return None
        if chunk.line_start <= line <= chunk.line_end:
            return [line, line]
        return None
    if isinstance(value, list) and value:
        try:
            numbers = [int(item) for item in value if isinstance(item, int | str)]
        except (TypeError, ValueError):
            return None
        if len(numbers) == 1:
            numbers = [numbers[0], numbers[0]]
        if len(numbers) >= 2:
            start, end = numbers[0], numbers[1]
            if chunk.line_start <= start <= end <= chunk.line_end:
                return [start, end]
    if isinstance(value, dict):
        start_raw = value.get("start") or value.get("line_start")
        end_raw = value.get("end") or value.get("line_end") or start_raw
        if start_raw is None or end_raw is None:
            return None
        try:
            start, end = int(start_raw), int(end_raw)
        except (TypeError, ValueError):
            return None
        if chunk.line_start <= start <= end <= chunk.line_end:
            return [start, end]
    return None

def _first_text_value(candidate: dict[str, Any]) -> str:
    preferred = (
        "synthesis_phrase",
        "final_synthesis_phrase",
        "answer",
        "final_answer",
        "phrase",
        "claim_text",
        "text",
        "claim",
    )
    for key in preferred:
        value = candidate.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    for value in candidate.values():
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""

def _topics_from_text(text: str) -> list[str]:
    return sorted({match.group(0).lower() for match in _TOPIC_RE.finditer(text)})[:10]

def _entities_from_text(text: str) -> list[str]:
    return sorted(
        {
            match.group(0)
            for match in _TOPIC_RE.finditer(text)
            if match.group(0).isupper() or match.group(0)[:1].isupper()
        }
    )[:10]


def _topic_terms(summary: dict[str, Any]) -> set[str]:
    terms: set[str] = set()
    for field in ("topics", "entities"):
        raw = summary.get(field)
        if isinstance(raw, list):
            terms.update(str(item).strip().lower() for item in raw if str(item).strip())
    for item in summary.get("claims", []) if isinstance(summary.get("claims"), list) else []:
        if isinstance(item, dict):
            terms.update(
                token.lower() for token in _TOPIC_RE.findall(str(item.get("text") or ""))
            )
    return {term for term in terms if term}


def _normalize_chunk_shorthand(
    candidate: dict[str, Any],
    *,
    ingest: LargeDocumentIngestResult,
    chunk: ChunkPlan,
    rows: dict[int, str],
) -> dict[str, Any] | None:
    if "claims" in candidate and "verified_quotes" in candidate:
        return None
    hints = _verified_evidence_hints(candidate, chunk=chunk, rows=rows)
    if hints:
        claims: list[dict[str, Any]] = []
        fragments: list[dict[str, Any]] = []
        quotes: list[dict[str, Any]] = []
        seen: set[tuple[str, int, int]] = set()
        for text, hint_lines in hints:
            key = (text.lower(), int(hint_lines[0]), int(hint_lines[1]))
            if key in seen:
                continue
            seen.add(key)
            claims.append({"text": text, "source_lines": hint_lines})
            fragments.append(
                {
                    "text": text,
                    "source_lines": hint_lines,
                    "confidence": 0.75,
                }
            )
            quotes.append({"quote": text, "source_lines": hint_lines})
        combined = " ".join(text for text, _ in hints)
        return {
            "doc_id": ingest.stats.doc_id,
            "source_hash": ingest.stats.sha256,
            "chunk_id": chunk.chunk_id,
            "line_start": chunk.line_start,
            "line_end": chunk.line_end,
            "task_relevance": 0.9,
            "claims": claims,
            "contradictions": [],
            "decisions": [],
            "constraints": [],
            "revocations": [],
            "candidate_answer_fragments": fragments,
            "adversarial_flags": [],
            "verified_quotes": quotes,
            "topics": _topics_from_text(combined),
            "entities": _entities_from_text(combined),
        }
    source_lines = _coerce_source_lines(candidate.get("source_lines"), chunk)
    if source_lines is None:
        source_lines = _coerce_source_lines(candidate.get("source_line"), chunk)
    if source_lines is None:
        return None
    start, end = source_lines
    cited = "\n".join(rows.get(line, "") for line in range(start, end + 1)).strip()
    if not cited:
        return None
    text = _first_text_value(candidate) or cited
    if text not in cited:
        matching_lines = [
            line_no
            for line_no, row in sorted(rows.items())
            if text and text in row
        ]
        if not matching_lines:
            return None
        source_lines = [matching_lines[0], matching_lines[-1]]
        start, end = source_lines
        cited = "\n".join(rows.get(line, "") for line in range(start, end + 1)).strip()
    quote = text
    return {
        "doc_id": ingest.stats.doc_id,
        "source_hash": ingest.stats.sha256,
        "chunk_id": chunk.chunk_id,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
        "task_relevance": 0.9,
        "claims": [{"text": text, "source_lines": source_lines}],
        "contradictions": [],
        "decisions": [],
        "constraints": [],
        "revocations": [],
        "candidate_answer_fragments": [
            {"text": text, "source_lines": source_lines, "confidence": 0.75}
        ],
        "adversarial_flags": [],
        "verified_quotes": [{"quote": quote, "source_lines": source_lines}],
        "topics": _topics_from_text(text),
        "entities": _entities_from_text(text),
    }

def _iter_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from _iter_dicts(item)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_dicts(item)

def _verified_evidence_hints(
    candidate: dict[str, Any],
    *,
    chunk: ChunkPlan,
    rows: dict[int, str],
) -> list[tuple[str, list[int]]]:
    hints: list[tuple[str, list[int]]] = []
    seen: set[tuple[str, int, int]] = set()
    for item in _iter_dicts(candidate):
        source_lines = _coerce_source_lines(item.get("source_lines"), chunk)
        if source_lines is None:
            source_lines = _coerce_source_lines(item.get("source_line"), chunk)
        if source_lines is None:
            continue
        start, end = source_lines
        cited = "\n".join(rows.get(line, "") for line in range(start, end + 1)).strip()
        if not cited:
            continue
        candidate_texts = [
            str(item.get(key)).strip()
            for key in _EVIDENCE_TEXT_KEYS
            if isinstance(item.get(key), str) and str(item.get(key)).strip()
        ]
        if not candidate_texts:
            candidate_texts = [cited]
        for text in candidate_texts:
            if text not in cited:
                continue
            key = (text.lower(), start, end)
            if key in seen:
                continue
            seen.add(key)
            hints.append((text, source_lines))
            break
    return hints

def _source_item_matching_text(
    text: str,
    sources: Iterable[dict[str, Any]],
) -> dict[str, Any] | None:
    needle = text.strip()
    if not needle:
        return None
    for item in sources:
        if not isinstance(item, dict):
            continue
        item_text = str(item.get("text") or item.get("quote") or "").strip()
        if not item_text:
            continue
        if needle in item_text or item_text in needle:
            lines = item.get("source_lines")
            if isinstance(lines, list) and len(lines) == 2:
                return item
    return None

def _normalize_group_reducer_shorthand(
    candidate: dict[str, Any],
    *,
    group: dict[str, Any],
) -> dict[str, Any] | None:
    normalized = _normalize_group_reducer_partial_schema(candidate, group=group)
    if normalized is not None:
        return normalized

    text = _first_text_value(candidate)
    source_item = _source_item_matching_text(
        text,
        [
            *group.get("claims", []),
            *group.get("candidate_answer_fragments", []),
            *group.get("verified_quotes", []),
        ],
    )
    if source_item is None:
        return None
    lines = source_item["source_lines"]
    normalized = dict(group)
    normalized["claims"] = [{"text": text, "source_lines": lines}]
    normalized["candidate_answer_fragments"] = [
        {"text": text, "source_lines": lines, "confidence": 0.8}
    ]
    normalized["verified_quotes"] = [
        {
            "quote": str(source_item.get("quote") or source_item.get("text") or text),
            "source_lines": lines,
        }
    ]
    normalized["topics"] = sorted(
        {*[str(t) for t in normalized.get("topics", [])], *_topics_from_text(text)}
    )[:80]
    normalized["entities"] = sorted(
        {*[str(e) for e in normalized.get("entities", [])], *_entities_from_text(text)}
    )[:80]
    return normalized

def _normalize_candidate_source_items(
    candidate: dict[str, Any],
    *,
    field: str,
    sources: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    raw = candidate.get(field)
    if not isinstance(raw, list):
        return []
    normalized: list[dict[str, Any]] = []
    seen: set[tuple[str, int, int]] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        text = str(
            item.get("text")
            or item.get("quote")
            or item.get("claim_text")
            or item.get("final_synthesis_phrase")
            or ""
        ).strip()
        if not text:
            continue
        source_item = _source_item_matching_text(text, sources)
        if source_item is None:
            continue
        lines = source_item["source_lines"]
        key = (text.lower(), int(lines[0]), int(lines[1]))
        if key in seen:
            continue
        seen.add(key)
        if field == "verified_quotes":
            normalized.append(
                {
                    "quote": str(source_item.get("quote") or source_item.get("text") or text),
                    "source_lines": lines,
                }
            )
        elif field == "candidate_answer_fragments":
            normalized.append(
                {
                    "text": text,
                    "source_lines": lines,
                    "confidence": float(item.get("confidence", 0.75)),
                }
            )
        elif field == "adversarial_flags":
            normalized.append({"kind": text, "source_lines": lines})
        else:
            normalized.append({"text": text, "source_lines": lines})
    return normalized

def _normalize_group_reducer_partial_schema(
    candidate: dict[str, Any],
    *,
    group: dict[str, Any],
) -> dict[str, Any] | None:
    """Fill reducer bookkeeping only when candidate content is already verified."""

    source_items = [
        item
        for field in ("claims", "candidate_answer_fragments", "verified_quotes")
        for item in group.get(field, [])
        if isinstance(item, dict)
    ]
    if not source_items:
        return None
    fields = (
        "claims",
        "contradictions",
        "decisions",
        "constraints",
        "revocations",
        "candidate_answer_fragments",
        "adversarial_flags",
        "verified_quotes",
    )
    normalized_fields = {
        field: _normalize_candidate_source_items(candidate, field=field, sources=source_items)
        for field in fields
    }
    if not any(normalized_fields.values()):
        return None

    normalized = dict(group)
    for field, items in normalized_fields.items():
        if items:
            normalized[field] = items
    chunk_ids = candidate.get("supporting_chunk_ids") or candidate.get("chunk_ids")
    if isinstance(chunk_ids, list) and chunk_ids:
        allowed = {
            str(item)
            for item in group.get("supporting_chunk_ids", [])
            if isinstance(item, str)
        }
        selected = [str(item) for item in chunk_ids if str(item) in allowed]
        if selected:
            normalized["supporting_chunk_ids"] = selected
    normalized["doc_id"] = str(group.get("doc_id") or "")
    normalized["source_hash"] = str(group.get("source_hash") or "")
    normalized["group_id"] = str(group.get("group_id") or "")
    normalized["line_start"] = int(group.get("line_start", 1))
    normalized["line_end"] = int(group.get("line_end", 1))
    normalized["task_relevance"] = float(
        candidate.get("task_relevance", group.get("task_relevance", 0.0))
    )
    normalized["topics"] = sorted(
        {
            *[str(t) for t in normalized.get("topics", []) if str(t).strip()],
            *[str(t) for t in candidate.get("topics", []) if isinstance(t, str)],
        }
    )[:80]
    normalized["entities"] = sorted(
        {
            *[str(e) for e in normalized.get("entities", []) if str(e).strip()],
            *[str(e) for e in candidate.get("entities", []) if isinstance(e, str)],
        }
    )[:80]
    return normalized

def _normalize_global_reducer_shorthand(
    candidate: dict[str, Any],
    *,
    mechanical: dict[str, Any],
    groups: list[dict[str, Any]],
) -> dict[str, Any] | None:
    normalized = _normalize_global_reducer_partial_schema(
        candidate,
        mechanical=mechanical,
        groups=groups,
    )
    if normalized is not None:
        return normalized

    text = _first_text_value(candidate)
    source_item = _source_item_matching_text(
        text,
        [
            *mechanical.get("claims", []),
            *mechanical.get("candidate_answer_fragments", []),
            *mechanical.get("verified_quotes", []),
        ],
    )
    if source_item is None:
        return None
    lines = source_item["source_lines"]
    normalized = dict(mechanical)
    normalized["claims"] = [{"text": text, "source_lines": lines}]
    normalized["candidate_answer_fragments"] = [
        {"text": text, "source_lines": lines, "confidence": 0.8}
    ]
    normalized["verified_quotes"] = [
        {
            "quote": str(source_item.get("quote") or source_item.get("text") or text),
            "source_lines": lines,
        }
    ]
    normalized["answer_affecting_claims"] = [
        {
            "text": text,
            "source_lines": lines,
            "supporting_chunk_ids": _supporting_chunks_for_lines(groups, lines),
            "confidence": 0.8,
            "support_type": "verified_quote",
        }
    ]
    normalized["topics"] = sorted(
        {*[str(t) for t in normalized.get("topics", [])], *_topics_from_text(text)}
    )[:80]
    normalized["entities"] = sorted(
        {*[str(e) for e in normalized.get("entities", [])], *_entities_from_text(text)}
    )[:80]
    return normalized

def _normalize_answer_claims(
    candidate: dict[str, Any],
    *,
    sources: list[dict[str, Any]],
    groups: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    raw = candidate.get("answer_affecting_claims")
    if not isinstance(raw, list):
        return []
    normalized: list[dict[str, Any]] = []
    seen: set[tuple[str, int, int, str]] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or item.get("claim_text") or "").strip()
        if not text:
            continue
        source_item = _source_item_matching_text(text, sources)
        if source_item is None:
            continue
        lines = source_item["source_lines"]
        support_type = str(item.get("support_type") or item.get("source") or "verified_quote")
        if support_type not in SUPPORT_TYPES:
            support_type = "verified_quote"
        key = (text.lower(), int(lines[0]), int(lines[1]), support_type)
        if key in seen:
            continue
        seen.add(key)
        confidence = item.get("confidence", 0.75)
        normalized.append(
            {
                "text": text,
                "source_lines": lines,
                "supporting_chunk_ids": _supporting_chunks_for_lines(groups, lines),
                "confidence": float(confidence) if isinstance(confidence, int | float) else 0.75,
                "support_type": support_type,
            }
        )
    return normalized

def _normalize_global_reducer_partial_schema(
    candidate: dict[str, Any],
    *,
    mechanical: dict[str, Any],
    groups: list[dict[str, Any]],
) -> dict[str, Any] | None:
    sources = [
        item
        for field in ("claims", "candidate_answer_fragments", "verified_quotes")
        for item in mechanical.get(field, [])
        if isinstance(item, dict)
    ]
    if not sources:
        return None
    fields = (
        "claims",
        "contradictions",
        "decisions",
        "constraints",
        "revocations",
        "candidate_answer_fragments",
        "adversarial_flags",
        "verified_quotes",
    )
    normalized_fields = {
        field: _normalize_candidate_source_items(candidate, field=field, sources=sources)
        for field in fields
    }
    answer_claims = _normalize_answer_claims(
        candidate,
        sources=sources,
        groups=groups,
    )
    if not any(normalized_fields.values()) and not answer_claims:
        return None
    normalized = dict(mechanical)
    for field, items in normalized_fields.items():
        if items:
            normalized[field] = items
    if answer_claims:
        normalized["answer_affecting_claims"] = answer_claims
    normalized["doc_id"] = str(mechanical.get("doc_id") or "")
    normalized["source_hash"] = str(mechanical.get("source_hash") or "")
    normalized["line_start"] = int(mechanical.get("line_start", 1))
    normalized["line_end"] = int(mechanical.get("line_end", 1))
    normalized["task_relevance"] = float(
        candidate.get("task_relevance", mechanical.get("task_relevance", 0.0))
    )
    normalized["topics"] = sorted(
        {
            *[str(t) for t in normalized.get("topics", []) if str(t).strip()],
            *[str(t) for t in candidate.get("topics", []) if isinstance(t, str)],
        }
    )[:80]
    normalized["entities"] = sorted(
        {
            *[str(e) for e in normalized.get("entities", []) if str(e).strip()],
            *[str(e) for e in candidate.get("entities", []) if isinstance(e, str)],
        }
    )[:80]
    return normalized

def _supporting_chunks_for_lines(groups: list[dict[str, Any]], lines: list[int]) -> list[str]:
    start, end = int(lines[0]), int(lines[1])
    supporting: list[str] = []
    for group in groups:
        if int(group.get("line_end", 0)) < start or int(group.get("line_start", 0)) > end:
            continue
        for chunk_id in group.get("supporting_chunk_ids", []):
            if isinstance(chunk_id, str) and chunk_id not in supporting:
                supporting.append(chunk_id)
    return supporting
