"""Crash-safe project progress snapshots.

This module records the small piece of state an operator needs after a
terminal, model server, or shell session disappears: what Remaind was doing,
what was already saved, what failed, and what should happen next. The latest
snapshot is atomic for fast resume; the JSONL journal is append-only and fsynced
so each checkpoint survives abrupt process loss after the write returns.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._jsonl import append_jsonl
from ._memory_records import records_from_progress_snapshot, upsert_memory_records
from ._paths import ContextPaths
from ._plan_reconciliation import update_plan_reconciliation_from_progress
from ._product_status import (
    clean_product_status_text,
    looks_like_memory_question_text,
    masks_remaind_artifact_review_step,
    update_product_status_from_progress,
)
from ._timestamps import utc_now_filename_safe_us, utc_now_iso

PROGRESS_SCHEMA_VERSION = "1.0.0"


def new_progress_operation_id() -> str:
    """Return a sortable id for one user-visible Remaind operation."""

    return f"progress_{utc_now_filename_safe_us()}"


def load_progress_snapshot(base: Path) -> dict[str, Any] | None:
    """Load the latest active progress snapshot, if one exists and is valid."""

    path = ContextPaths.at(Path(base)).progress_snapshot
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def record_progress_snapshot(
    base: Path,
    *,
    operation_id: str,
    phase: str,
    task: str,
    document_path: Path | str | None = None,
    packet_path: Path | str | None = None,
    answer_path: Path | str | None = None,
    model_label: str | None = None,
    model_error: str | None = None,
    answer: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Persist the latest progress snapshot and append it to the journal."""

    paths = ContextPaths.at(Path(base))
    state = _load_json(paths.state_json)
    previous = load_progress_snapshot(base) or {}
    metadata_payload = dict(metadata or {})
    operation_kind = _clean(metadata_payload.get("operation_kind")) or "run"
    completed = phase == "completed" and model_error is None
    blocked = bool(model_error) or phase == "blocked"
    status = "blocked" if blocked else ("done" if completed else "implementing")
    task_text = _clean(task)
    packet = _string_path(packet_path)
    answer_file = _string_path(answer_path)
    last_completed = _last_completed_tasks(
        state,
        previous,
        completed_task=(
            task_text if completed and operation_kind != "memory_question" else None
        ),
    )
    next_step = _next_step(
        state,
        task=task_text,
        phase=phase,
        packet_path=packet,
        answer_path=answer_file,
        model_error=model_error,
    )
    development_plan_focus = _development_plan_focus(state, task_text)
    if operation_kind == "memory_question" and looks_like_memory_question_text(
        development_plan_focus
    ):
        development_plan_focus = "Use the loaded product authority files."
    snapshot: dict[str, Any] = {
        "schema_version": PROGRESS_SCHEMA_VERSION,
        "operation_id": operation_id,
        "updated_at": utc_now_iso(),
        "phase": phase,
        "status": status,
        "development_plan_focus": development_plan_focus,
        "plan_status": _plan_status(
            phase,
            model_error=model_error,
            operation_kind=operation_kind,
        ),
        "active_task": (
            f"Answer memory-state question: {task_text}"
            if operation_kind == "memory_question"
            else _state_text(state, "active_task") or task_text
        ),
        "last_completed_tasks": last_completed,
        "error_or_blocker": _clean(model_error) or None,
        "incomplete_task_due_to_blocker": task_text if blocked else None,
        "recovery_step": (
            f"Fix the blocker, then retry the incomplete task: {task_text}"
            if blocked
            else None
        ),
        "ready_for_new_instructions": True,
        "next_step_after_unblock": (
            "After the incomplete task succeeds, continue with the next step "
            "from the loaded development plan. If the next plan step is not "
            "explicit in this snapshot, ask for project status so Remaind can "
            "recompute it from the saved packet and project files."
            if blocked
            else None
        ),
        "next_plan_step": next_step,
        "document_path": _string_path(document_path),
        "packet_path": packet,
        "answer_path": answer_file,
        "model_label": model_label,
        "answer_excerpt": _clean(answer)[:1200] if answer else None,
        "metadata": metadata_payload,
    }
    _write_snapshot(paths, snapshot)
    append_jsonl(paths.progress_jsonl, snapshot)
    update_product_status_from_progress(base, snapshot)
    update_plan_reconciliation_from_progress(base, snapshot)
    upsert_memory_records(
        base,
        records_from_progress_snapshot(snapshot, base=Path(base)),
    )
    return snapshot


def render_progress_snapshot(snapshot: dict[str, Any]) -> str:
    """Render a snapshot as a resume-packet section."""

    rows = [
        "## Crash-Safe Progress Snapshot",
        "",
        (
            "This section is the latest atomic Remaind operation checkpoint. "
            "Use it for crash recovery, current blockers, incomplete tasks, and "
            "saved packet/answer locations after a terminal or model "
            "interruption."
        ),
        (
            "Do not treat this operation checkpoint as the product roadmap by "
            "itself. For product scope, active plan, and next TODOs, prefer "
            "loaded product authority files, status files, handovers, and the "
            "latest user instruction."
        ),
        "",
    ]
    fields = (
        "updated_at",
        "operation_id",
        "phase",
        "status",
        "development_plan_focus",
        "plan_status",
        "active_task",
        "error_or_blocker",
        "incomplete_task_due_to_blocker",
        "recovery_step",
        "next_step_after_unblock",
        "next_plan_step",
        "packet_path",
        "answer_path",
        "document_path",
    )
    for field in fields:
        value = snapshot.get(field)
        if field == "next_plan_step" and isinstance(value, str):
            if _is_remaind_artifact_review_step(value):
                value = "Continue the product plan."
        if value in (None, "", []):
            value = "(none)"
        rows.append(f"- **{field}**: {value}")
    completed = snapshot.get("last_completed_tasks")
    rows.append("- **last_completed_tasks**:")
    if isinstance(completed, list) and completed:
        for item in completed[:2]:
            rows.append(f"  - {item}")
    else:
        rows.append("  - (none)")
    rows.append("")
    return "\n".join(rows)


def _write_snapshot(paths: ContextPaths, snapshot: dict[str, Any]) -> None:
    atomic_write_text(
        paths.progress_snapshot,
        json.dumps(snapshot, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "progress_snapshot",
    )


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _clean(value: object) -> str:
    return clean_product_status_text(value)


def _string_path(value: Path | str | None) -> str | None:
    if value is None:
        return None
    return str(value)


def _state_text(state: dict[str, Any], field: str) -> str:
    return _clean(state.get(field))


def _development_plan_focus(state: dict[str, Any], task: str) -> str:
    current_goal = _state_text(state, "current_goal")
    if current_goal and current_goal.lower() != "initialize remaind context.":
        return current_goal
    return task


def _last_completed_tasks(
    state: dict[str, Any],
    previous: dict[str, Any],
    *,
    completed_task: str | None,
) -> list[str]:
    values: list[str] = []
    for item in state.get("completed_work") or []:
        text = _clean(item)
        if text and not looks_like_memory_question_text(text):
            values.append(text)
    previous_items = previous.get("last_completed_tasks")
    if isinstance(previous_items, list):
        for item in previous_items:
            text = _clean(item)
            if text and not looks_like_memory_question_text(text):
                values.append(text)
    if completed_task:
        values.append(completed_task)
    deduped: list[str] = []
    for item in values:
        if item in deduped:
            continue
        deduped.append(item)
    return deduped[-2:]


def _plan_status(
    phase: str,
    *,
    model_error: str | None,
    operation_kind: str = "run",
) -> str:
    if model_error or phase == "blocked":
        return "Blocked; packet/progress were preserved for recovery."
    if operation_kind == "memory_question":
        return (
            "Memory-state question answered. This does not mark product "
            "implementation progress complete."
        )
    if phase == "completed":
        return "Completed; answer and packet were preserved."
    if phase == "packet_ready":
        return "Evidence packet saved; model answer may still be pending."
    if phase == "model_call_started":
        return "Model call started after packet checkpoint."
    return "Started; progress checkpoint saved."


def _next_step(
    state: dict[str, Any],
    *,
    task: str,
    phase: str,
    packet_path: str | None,
    answer_path: str | None,
    model_error: str | None,
) -> str:
    if model_error or phase == "blocked":
        suffix = f" using saved packet {packet_path}" if packet_path else ""
        return f"Fix the blocker and retry the incomplete task{suffix}: {task}"
    if phase == "completed":
        state_next = _state_text(state, "next_step")
        if state_next and not _is_remaind_artifact_review_step(state_next):
            return state_next
        return "Continue the product plan."
    if phase == "packet_ready":
        return (
            f"If interrupted, resume from saved packet {packet_path}"
            if packet_path
            else "If interrupted, reopen Remaind and ask for project status."
        )
    return _state_text(state, "next_step") or f"Continue task: {task}"


def _is_remaind_artifact_review_step(text: str) -> bool:
    return masks_remaind_artifact_review_step(text)
