"""Shared benchmark evidence packets built on Remaind context engineering.

Public benchmark bridges should use this module instead of carrying their own
mini context engines. It keeps benchmark memory retrieval aligned with the
same source authority, freshness, budget, and trace concepts used by the
product continuity framework.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any

from ._context_engine import ContextBuildRequest, select_engineered_context
from ._context_render import render_context_decision_section
from ._context_sources import ContextSource
from ._db import Memory
from ._entity_grounding import (
    entity_grounding_adjustments,
    entity_grounding_summaries,
)
from ._memory_records import MemoryRecord
from ._polarity_vocab import (
    NEGATIVE_TERMS,
    POSITIVE_TERMS,
    RETURN_TERMS,
    classify_polarity,
    extract_topic_tokens,
)
from ._recall_judgment import (
    recall_option_adjustments,
    recall_option_evidence_summaries,
    render_recall_judgment_section,
)
from ._recommendation_judgment import (
    recommendation_tie_breaker_adjustment,
    recommendation_tie_breaker_summaries,
)
from ._suggestion_judgment import (
    render_suggestion_judgment_section,
    suggestion_novelty_adjustments,
    suggestion_novelty_summaries,
)

_STOPWORDS = {
    "about",
    "after",
    "again",
    "also",
    "all",
    "amid",
    "among",
    "and",
    "answer",
    "any",
    "are",
    "because",
    "been",
    "being",
    "best",
    "between",
    "both",
    "but",
    "can",
    "consider",
    "could",
    "did",
    "different",
    "does",
    "doing",
    "done",
    "each",
    "for",
    "from",
    "given",
    "have",
    "having",
    "how",
    "into",
    "its",
    "just",
    "like",
    "more",
    "most",
    "new",
    "not",
    "now",
    "only",
    "option",
    "or",
    "over",
    "part",
    "past",
    "people",
    "plenty",
    "previous",
    "really",
    "response",
    "same",
    "should",
    "some",
    "specific",
    "than",
    "that",
    "the",
    "their",
    "them",
    "then",
    "there",
    "these",
    "they",
    "this",
    "through",
    "user",
    "was",
    "were",
    "what",
    "when",
    "where",
    "which",
    "while",
    "with",
    "would",
    "you",
    "your",
}


@dataclass(frozen=True)
class _OptionAlignmentPolicy:
    enabled: bool
    score_floor: float
    margin_floor: float


_OPTION_ALIGNMENT_POLICIES = {
    "suggest_new_ideas": _OptionAlignmentPolicy(True, 0.0, 0.0),
    "recalling_facts_mentioned_by_the_user": _OptionAlignmentPolicy(True, 0.0, 0.0),
    "track_full_preference_evolution": _OptionAlignmentPolicy(True, 8.0, 8.0),
    "recall_user_shared_facts": _OptionAlignmentPolicy(True, 2.0, 1.0),
    "recalling_the_reasons_behind_previous_updates": _OptionAlignmentPolicy(True, 2.0, 1.0),
    "provide_preference_aligned_recommendations": _OptionAlignmentPolicy(True, 4.0, 1.5),
    "generalizing_to_new_scenarios": _OptionAlignmentPolicy(True, 4.0, 1.5),
}


_DETERMINISTIC_HINT_SCORE_FLOOR = 6.0
_DETERMINISTIC_HINT_MARGIN_FLOOR = 3.0
_DETERMINISTIC_HINT_ENV = "REMAIND_BENCH_DETERMINISTIC_HINT"
_CURRENT_QUERY_SIGNAL_ENV = "REMAIND_BENCH_CURRENT_QUERY_SIGNAL"
_TRACK_TIMELINE_ENV = "REMAIND_BENCH_TRACK_TIMELINE"

_AMB_QUESTION_TYPE_RE = re.compile(
    r"^\s*(?:AMB\s+)?question_type:\s*([a-z_]+)\s*(?:\n|$)",
    re.I,
)


@dataclass(frozen=True)
class RankedMemory:
    score: float
    memory: Memory


@dataclass(frozen=True)
class BenchmarkEvidencePacket:
    content: str
    ranked_memory_ids: tuple[str, ...]
    selected_source_ids: tuple[str, ...]
    omitted_source_ids: tuple[str, ...]
    token_count: int


@dataclass(frozen=True)
class AnswerOptionSupport:
    letter: str
    score: float
    matched_terms: tuple[str, ...]
    penalties: tuple[str, ...] = ()


@dataclass(frozen=True)
class BenchmarkIntent:
    question_type: str
    question_class: str
    decision_criteria: tuple[str, ...]
    required_evidence: tuple[str, ...]
    disqualifiers: tuple[str, ...]
    sub_questions: tuple[str, ...]


@dataclass(frozen=True)
class _PreferenceTimelineEvent:
    order: int
    turn: int
    session: str
    polarity: str
    status: str
    topic: str
    tokens: frozenset[str]
    text: str
    source_kind: str


@dataclass(frozen=True)
class _PreferenceTopicChain:
    topic: str
    tokens: frozenset[str]
    events: tuple[_PreferenceTimelineEvent, ...]
    state: str


def expanded_query(query: str) -> str:
    """Expand a benchmark query with deterministic lexical variants."""

    content_query = retrieval_query_text(query)
    tokens = important_tokens(content_query)
    additions = [token for token in tokens if token not in content_query.lower()]
    if not additions:
        return content_query
    return " ".join([content_query, *additions])


def rank_memory_candidates(
    query: str,
    candidates: list[Memory],
    metadata_by_memory_id: dict[str, dict[str, Any]],
    *,
    user_id: str | None = None,
    query_timestamp: str | None = None,
) -> list[RankedMemory]:
    """Rank candidate memories inside user and time scope."""

    tokens = important_tokens(query)
    phrases = important_phrases(tokens)
    ranked: list[tuple[float, int, Memory]] = []
    for position, memory in enumerate(candidates):
        meta = metadata_by_memory_id.get(memory.id, {})
        if user_id is not None and meta.get("user_id") not in (None, user_id):
            continue
        if not is_at_or_before(meta.get("timestamp"), query_timestamp):
            continue
        score = candidate_score(memory.content, meta, tokens, phrases)
        ranked.append((score, position, memory))
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [RankedMemory(score=score, memory=memory) for score, _position, memory in ranked]


def build_benchmark_evidence_packet(
    query: str,
    ranked: list[RankedMemory],
    metadata_by_memory_id: dict[str, dict[str, Any]],
    *,
    memory_records: list[MemoryRecord] | None = None,
    token_cap: int = 8_000,
) -> BenchmarkEvidencePacket:
    """Build a compact, source-linked benchmark packet through context sources."""

    if not ranked:
        return BenchmarkEvidencePacket("", (), (), (), 0)
    tokens = important_tokens(query)
    phrases = important_phrases(tokens)
    intent = analyze_benchmark_intent(query)
    sources = _benchmark_context_sources(
        query,
        ranked,
        metadata_by_memory_id,
        memory_records=memory_records or [],
        tokens=tokens,
        phrases=phrases,
        intent=_snippet_ranking_intent(intent),
        benchmark_intent=intent,
    )
    context_intent, selection = select_engineered_context(
        ContextBuildRequest(question=query, token_cap=token_cap),
        sources,
    )
    source_lines = [
        "Remaind benchmark evidence packet",
        (
            "This packet was selected by Remaind's shared context-engineering "
            "layer. Use it as source-linked evidence for the current benchmark query."
        ),
        "",
        render_context_decision_section(
            question=query,
            workspace_query=None,
            intent=context_intent,
            selection=selection,
        ).rstrip(),
        "",
        "## Current Query",
        "",
        query.strip(),
        "",
    ]
    selected_profile = [
        source for source in selection.selected if source.source_type == "benchmark_profile"
    ]
    selected_records = [
        source for source in selection.selected if source.source_type == "preference_state"
    ]
    selected_guidance = [
        source for source in selection.selected if source.source_type == "answer_instruction"
    ]
    selected_contract = [
        source for source in selection.selected if source.id == "benchmark_intent_contract"
    ]
    selected_slots = [
        source for source in selection.selected if source.id == "benchmark_evidence_slots"
    ]
    selected_evolution = [
        source
        for source in selection.selected
        if source.id == "preference_evolution_brief"
    ]
    selected_option_alignment = [
        source for source in selection.selected if source.id == "option_evidence_alignment"
    ]
    selected_deterministic_hint = [
        source
        for source in selection.selected
        if source.id == "deterministic_supported_answer_hint"
    ]
    selected_evidence = [
        source for source in selection.selected if source.source_type == "turn_evidence"
    ]
    if selected_guidance:
        source_lines.extend(["## Answering Guidance", ""])
        for source in selected_guidance:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_contract:
        source_lines.extend(["## Decision Contract", ""])
        for source in selected_contract:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_option_alignment:
        source_lines.extend(["## Option Evidence Alignment", ""])
        for source in selected_option_alignment:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_deterministic_hint:
        source_lines.extend(["## Remaind Packet-Level Pick", ""])
        for source in selected_deterministic_hint:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_slots:
        source_lines.extend(["## Evidence Slots", ""])
        for source in selected_slots:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_evolution:
        source_lines.extend(["## Preference Timeline", ""])
        for source in selected_evolution:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    if selected_records:
        source_lines.extend(["## Structured Preference / Memory State", ""])
        for source in selected_records:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    source_lines.extend(["## Relevant Source Evidence", ""])
    for index, source in enumerate(selected_evidence, 1):
        source_lines.append(f"{index}. {source.content.rstrip()}")
    source_lines.append("")
    if selected_profile:
        source_lines.extend(["## Low-Authority Background Profile", ""])
        source_lines.append(
            "Use this as biographical background only. Explicit user turns and "
            "structured preference state outrank this section for topic-specific choices."
        )
        for source in selected_profile:
            source_lines.append(source.content.rstrip())
        source_lines.append("")
    source_lines.extend(["## Source Sessions Considered", ""])
    for item in ranked:
        meta = metadata_by_memory_id.get(item.memory.id, {})
        source_lines.append(
            f"- {meta.get('document_id') or item.memory.id} "
            f"(rank_score={item.score:.2f})"
        )
    content = "\n".join(source_lines).rstrip() + "\n"
    return BenchmarkEvidencePacket(
        content=content,
        ranked_memory_ids=tuple(item.memory.id for item in ranked),
        selected_source_ids=tuple(source.id for source in selection.selected),
        omitted_source_ids=tuple(source.id for source in selection.omitted),
        token_count=selection.budget.selected_tokens,
    )


def _benchmark_context_sources(
    query: str,
    ranked: list[RankedMemory],
    metadata_by_memory_id: dict[str, dict[str, Any]],
    *,
    memory_records: list[MemoryRecord],
    tokens: list[str],
    phrases: list[str],
    intent: str,
    benchmark_intent: BenchmarkIntent,
) -> list[ContextSource]:
    sources: list[ContextSource] = []
    alignment_inputs: list[str] = []
    ordered_records: list[MemoryRecord] = []
    sources.append(_answer_guidance_source(benchmark_intent))
    sources.append(_intent_contract_source(benchmark_intent))
    if memory_records:
        ordered_records = _rank_memory_records(memory_records, tokens, phrases, intent)
        if benchmark_intent.question_type not in {
            "recalling_facts_mentioned_by_the_user",
            "track_full_preference_evolution",
        }:
            record_alignment_limit = (
                24
                if benchmark_intent.question_type == "track_full_preference_evolution"
                else 8
            )
            alignment_inputs.extend(
                " ".join([record.subject, record.what, record.why, record.how])
                for record in ordered_records[:record_alignment_limit]
            )
            sources.append(
                ContextSource(
                    id="structured_preference_state",
                    title="Structured Preference State",
                    source_type="preference_state",
                    authority="derived_memory",
                    freshness="current",
                    content=_render_benchmark_memory_records(ordered_records[:8]),
                    mandatory=True,
                    reason=(
                        "Structured preference records expose current and stale "
                        "user signals with source links."
                    ),
                    budget_group="profile",
                )
            )
    profiles: list[str] = []
    snippets: list[dict[str, Any]] = []
    for item in ranked:
        for profile in profile_blocks(item.memory.content):
            cleaned = clean_snippet(profile, limit=950)
            if cleaned and cleaned not in profiles:
                profiles.append(cleaned)
    for index, profile in enumerate(profiles[:2], 1):
        sources.append(
            ContextSource(
                id=f"benchmark_profile_{index}",
                title=f"Benchmark profile {index}",
                source_type="benchmark_profile",
                authority="derived_memory",
                freshness="current",
                content=f"- {profile}\n",
                mandatory=False,
                reason="Durable user/session profile extracted from benchmark memory.",
                budget_group="profile",
            )
        )
    if benchmark_intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        alignment_inputs.extend(
            f"Low-Authority Background Profile: {profile}" for profile in profiles[:2]
        )
    for doc_rank, item in enumerate(ranked):
        meta = metadata_by_memory_id.get(item.memory.id, {})
        document_id = str(meta.get("document_id") or item.memory.id)
        for turn_index, role, text in turn_blocks(item.memory.content):
            if role == "SYSTEM":
                continue
            score = snippet_score(text, role, tokens, phrases, intent)
            if score <= 0:
                continue
            snippets.append(
                {
                    "score": score + max(0.0, 3.0 - doc_rank) * 0.25,
                    "doc_rank": doc_rank,
                    "turn_index": turn_index,
                    "document_id": document_id,
                    "role": role,
                    "text": clean_snippet(text, limit=900),
                }
            )
    snippets.sort(
        key=lambda item: (
            -float(item["score"]),
            int(item["doc_rank"]),
            int(item["turn_index"]),
        )
    )
    deduped_snippets = dedupe_snippets(snippets)
    if benchmark_intent.question_type == "track_full_preference_evolution":
        user_snippets = [
            snippet
            for snippet in deduped_snippets
            if str(snippet.get("role")).upper() == "USER"
        ]
        selected_snippets = user_snippets[:18]
        if len(selected_snippets) < 18:
            selected_ids = {
                (
                    str(snippet.get("document_id") or ""),
                    int(snippet.get("turn_index") or 0),
                )
                for snippet in selected_snippets
            }
            selected_snippets.extend(
                snippet
                for snippet in deduped_snippets
                if (
                    str(snippet.get("document_id") or ""),
                    int(snippet.get("turn_index") or 0),
                )
                not in selected_ids
            )
            selected_snippets = selected_snippets[:18]
    else:
        selected_snippets = deduped_snippets[:18]
    if benchmark_intent.question_type == "track_full_preference_evolution":
        alignment_inputs.extend(_evolution_record_alignment_lines(ordered_records[:32]))
        chronological_snippets = sorted(
            selected_snippets,
            key=lambda snippet: (
                _document_order(str(snippet.get("document_id") or "")),
                int(snippet.get("turn_index") or 0),
            ),
        )
        alignment_inputs.extend(
            " ".join(
                [
                    f"session {_document_order_label(str(snippet.get('document_id') or ''))}",
                    f"turn {int(snippet.get('turn_index') or 0)}:",
                    str(snippet["text"]),
                ]
            )
            for snippet in chronological_snippets[:18]
        )
    else:
        alignment_inputs.extend(str(snippet["text"]) for snippet in selected_snippets[:10])
    suggestion_judgment = _suggestion_judgment_source(
        query,
        alignment_inputs,
        benchmark_intent,
    )
    if suggestion_judgment is not None:
        sources.append(suggestion_judgment)
    recall_judgment = _recall_judgment_source(
        query,
        alignment_inputs,
        benchmark_intent,
    )
    if recall_judgment is not None:
        sources.append(recall_judgment)
    slots = _evidence_slots_source(
        benchmark_intent,
        ordered_records,
        profiles,
        selected_snippets,
    )
    if slots is not None:
        sources.append(slots)
    polarity_state = _structured_polarity_state_source(
        query,
        ordered_records,
        benchmark_intent,
    )
    if polarity_state is not None:
        sources.append(polarity_state)
    reasons_for_changes = _reasons_for_past_changes_source(
        query,
        ordered_records,
        benchmark_intent,
    )
    if reasons_for_changes is not None:
        sources.append(reasons_for_changes)
    evolution = _preference_evolution_source(
        query,
        ordered_records,
        selected_snippets,
        benchmark_intent,
    )
    if evolution is not None:
        sources.append(evolution)
    option_alignment = _option_alignment_source(query, alignment_inputs, benchmark_intent)
    if option_alignment is not None:
        sources.append(option_alignment)
    deterministic_hint = _deterministic_supported_answer_hint_source(
        query,
        alignment_inputs,
        benchmark_intent,
    )
    if deterministic_hint is not None:
        sources.append(deterministic_hint)
    for index, snippet in enumerate(selected_snippets, 1):
        sources.append(
            ContextSource(
                id=f"turn_evidence_{index}",
                title=f"Source {snippet['document_id']}",
                source_type="turn_evidence",
                authority="source_evidence",
                freshness="recent",
                content=(
                    f"Source {snippet['document_id']} "
                    f"({str(snippet['role']).lower()}, relevance {float(snippet['score']):.2f}): "
                    f"{snippet['text']}\n"
                ),
                mandatory=False,
                reason="Relevant turn-level source evidence selected for the query.",
                budget_group="evidence",
            )
        )
    return sources


def _snippet_ranking_intent(intent: BenchmarkIntent) -> str:
    """Map benchmark intent to the snippet scorer's retrieval modes."""

    if intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
    }:
        return "shared_fact"
    if intent.question_type == "recalling_the_reasons_behind_previous_updates":
        return "reason_update"
    if intent.question_class == "suggestion":
        return "suggestion"
    return intent.question_class


def _answer_guidance_source(intent: BenchmarkIntent) -> ContextSource:
    lines = [
        "Use the evidence packet as the source of truth for the current answer.",
    ]
    if intent.question_type == "suggest_new_ideas":
        lines.extend(
            [
                "Prefer current user evidence and source excerpts over generic plausibility.",
                "When choices are available, choose the option best supported by explicit user turns, current preferences, and retrieved source evidence.",
                "Treat stale, disliked, abandoned, or unsupported interests as negative evidence for recommendations.",
            ]
        )
    elif intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        lines.extend(
            [
                "Prefer direct user-turn event evidence and source excerpts over generic plausibility or current-preference reasoning.",
                "When choices are available, choose the option that states the most specific source-backed fact, not the most generic plausible answer.",
                "Do not assert a user statement that is not present verbatim or near-verbatim in the Relevant Source Evidence; if no option matches, prefer the option that asserts the least.",
            ]
        )
    else:
        lines.extend(
            [
                "Prefer current user evidence and source excerpts over generic plausibility.",
                "When choices are available, choose the option best supported by explicit user turns, current preferences, and retrieved source evidence.",
                "Treat stale, disliked, abandoned, or unsupported interests as negative evidence for recommendations.",
                "Do not invent user history; recommendations may use supported adjacent inference when the retrieved evidence justifies it.",
            ]
        )
    if intent.question_type == "suggest_new_ideas":
        lines.extend(
            [
                "For suggest_new_ideas questions, prefer the concise option that best satisfies the user's current request and evidence-backed constraints.",
                "A novel adjacent activity should beat an established activity when the established option is overlong, padded with repeated evidence, or adds classes, group membership, analogies, or side quests.",
                "Do not choose a repeated familiar activity merely because it has the most historical support; choose familiar only when no source-backed adjacent idea fits the request.",
                "Filter by answer voice before preference nuance: choose direct second-person suggestion language over a pasted memory recap.",
            ]
        )
    elif intent.question_type == "provide_preference_aligned_recommendations":
        lines.extend(
            [
                "For preference-aligned recommendations, novelty is secondary to fit with active positive preferences and current constraints.",
                "When multiple options are plausible, prefer the one that satisfies the user's newest constraints and avoids explicit dislikes, even if another option matches more frequent historical interests.",
                "Use negative constraints as tie-breakers: avoid options that admit crowding, rigidity, pressure, scale, or unwanted group commitment when the user has rejected those conditions.",
                "If one option contains the same recommendation plus unsupported commitments, choose the more direct option.",
            ]
        )
    elif intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        lines.extend(
            [
                "For recall questions, first-person assistant recap voice is often correct: prefer options that say 'I remember...' or 'you mentioned...' when they cite a specific prior user statement.",
                "When options differ by one noun phrase, choose the noun phrase with direct user-turn evidence, not the noun phrase that merely matches persona or profession background.",
                "For fact-recall questions, later changed preferences do not erase the fact that an earlier event happened; choose the option with direct event evidence unless the question asks for the current preference.",
                "Do not reject the strongest fact-recall candidate because the same activity later had mixed or negative sentiment; sentiment affects recommendations, not whether the event was mentioned.",
                "Persona/profession is biographical background only for recall; explicit user statements about the asked topic outrank it.",
            ]
        )
    elif intent.question_type == "track_full_preference_evolution":
        lines.extend(
            [
                "For preference-evolution questions, treat the Preference Timeline as the source of truth for chronology.",
                "If a user turn references resuming, restarting, returning to, or giving up an activity, do not infer the earlier polarity from that word alone; use the timeline's ordered polarity signals.",
                "Use the Option Evidence Alignment section to compare each candidate's claimed chronology against source-backed positive and negative signals.",
                "Treat adjacent creative outputs as one thread only when the candidate answer itself frames them that way; otherwise keep activity threads separate.",
                "Prefer the option that preserves the full sequence of preference changes, not just the newest state.",
                "Do not invent chronology; choose the option whose stated sequence is supported by the timeline and source evidence.",
            ]
        )
    elif intent.question_type == "generalizing_to_new_scenarios":
        lines.extend(
            [
                "For generalization questions, transfer the user's constraints to the new scenario instead of matching only the broad topic.",
                "Reject options that disclose crowding, rigidity, pressure, scale, or unwanted group commitment when the loaded evidence says the user avoids those conditions.",
            ]
        )
    elif intent.question_class == "multi-hop":
        lines.append(
            "For update-reason questions, explain the reason that is explicitly supported by the user's prior statements."
        )
    return ContextSource(
        id="benchmark_answer_guidance",
        title="Benchmark Answer Guidance",
        source_type="answer_instruction",
        authority="current_user",
        freshness="live",
        content="\n".join(f"- {line}" for line in lines) + "\n",
        mandatory=True,
        reason="Answering rules that keep benchmark responses grounded in selected evidence.",
        budget_group="answer",
    )


def analyze_benchmark_intent(query: str) -> BenchmarkIntent:
    """Extract the benchmark decision contract from the current query."""

    question = retrieval_query_text(query).lower()
    question_type = benchmark_question_type(query)
    base_intent = query_intent(query)
    if question_type == "track_full_preference_evolution":
        question_class = "multi-hop"
    elif question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
    }:
        question_class = "factual"
    elif question_type == "recalling_the_reasons_behind_previous_updates":
        question_class = "multi-hop"
    elif question_type in {
        "suggest_new_ideas",
        "provide_preference_aligned_recommendations",
        "generalizing_to_new_scenarios",
    }:
        question_class = "suggestion"
    elif any(marker in question for marker in ("compare", "better", "prefer", "which")):
        question_class = "comparative"
    elif any(marker in question for marker in ("steps", "process", "how do i", "how should i")):
        question_class = "procedural"
    elif any(marker in question for marker in ("after", "since", "changed", "because")):
        question_class = "multi-hop"
    elif base_intent == "suggestion":
        question_class = "suggestion"
    else:
        question_class = "factual"

    criteria = [
        "Answer the current user request directly.",
    ]
    if question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        criteria.append(
            "Prefer direct source-backed past-event or fact evidence over current-preference reasoning."
        )
    else:
        criteria.append(
            "Prefer current source-backed evidence over older or generic plausibility."
        )
    required = ["facts", "history"]
    disqualifiers = ["Unsupported details not present in the packet."]
    sub_questions = [
        "What is the user asking for now?",
        "Which source-backed facts or preferences are current?",
    ]
    if question_class == "suggestion":
        criteria.extend(
            [
                "Match active positive preferences and constraints.",
                "Choose direct assistant-style guidance over vivid memory-shaped distractors.",
                "Prefer fewer unsupported commitments when choices are otherwise similar.",
            ]
        )
        if question_type == "suggest_new_ideas":
            criteria.append(
                "Prefer concise novel-adjacent suggestions over overlong repetitions of established interests."
            )
        elif question_type == "provide_preference_aligned_recommendations":
            criteria.append(
                "Use the newest explicit preference and constraint signals as tie-breakers."
            )
        required = ["preferences", "constraints", "history", "exclusions"]
        disqualifiers.append(
            "Extra classes, groups, collaborations, analogies, or side quests not requested by the user."
        )
        disqualifiers.append(
            "Recommendations grounded only in stale, disliked, or abandoned interests."
        )
        sub_questions.extend(
            [
                "What positive preferences should the recommendation extend?",
                "What constraints, dislikes, or abandoned paths must it avoid?",
                "Which candidate is most direct with the fewest unsupported extras?",
            ]
        )
    elif question_class == "comparative":
        criteria.append("Compare candidates against the same explicit criteria.")
        required = ["facts", "preferences", "constraints", "exclusions"]
        sub_questions.append("Which criteria decide the comparison?")
    elif question_class == "procedural":
        criteria.append("Provide the next action or process grounded in the user's state.")
        required = ["facts", "history", "constraints"]
        sub_questions.append("What prior state changes the procedure?")
    elif question_class == "multi-hop":
        criteria.append("Resolve the latest state after changes across time.")
        if question_type == "track_full_preference_evolution":
            criteria.append("Preserve the full ordered polarity sequence across sessions.")
        else:
            disqualifiers.append("Answers that ignore the stated reason for the user's update.")
        required = ["facts", "history", "exclusions"]
        sub_questions.append("Which newer evidence supersedes older evidence?")
    elif question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
    }:
        criteria.append(
            "For recall, choose the option tied to an explicitly mentioned past event or fact, even if the user later changed preferences."
        )
        sub_questions.append("Which option has the strongest direct-turn event evidence?")

    return BenchmarkIntent(
        question_type=question_type,
        question_class=question_class,
        decision_criteria=tuple(criteria),
        required_evidence=tuple(required),
        disqualifiers=tuple(disqualifiers),
        sub_questions=tuple(sub_questions),
    )


def benchmark_question_type(query: str) -> str:
    """Infer AMB's question type from the visible query and candidate options."""

    explicit = explicit_benchmark_question_type(query)
    if explicit:
        return explicit
    question = retrieval_query_text(query).lower()
    option_text = " ".join(option for _letter, option in answer_options(query)).lower()
    combined = " ".join([question, option_text])
    if any(
        marker in combined
        for marker in (
            "initially",
            "evolved over time",
            "preferences have evolved",
            "journey of rediscovery",
            "journey with",
            "journey and how",
            "shifted over time",
            "transition from",
            "full-circle evolution",
        )
    ) and any(
        marker in combined
        for marker in (
            "now",
            "later",
            "eventually",
            "then",
            "recent",
            "current",
            "returned",
            "restarted",
            "resumed",
        )
    ):
        return "track_full_preference_evolution"
    if not answer_options(query) and any(
        marker in question
        for marker in (
            "after some thought",
            "became actively involved",
            "decided to give",
            "decided to rejoin",
            "decided to step back",
            "even started",
            "formed a partnership",
            "found myself skipping",
            "i also restarted",
            "i switched my focus",
            "initially hesitant",
            "rejoined",
            "restarted",
            "resumed",
            "surprisingly",
            "transitioned",
        )
    ):
        return "track_full_preference_evolution"
    if any(
        marker in question
        for marker in (
            "what prompted",
            "what motivated",
            "why did",
            "why i",
            "reason behind",
            "decided i don't",
            "decided i do not",
            "don't enjoy",
            "do not enjoy",
            "anymore",
        )
    ) or ("previously" in option_text and "change of heart" in option_text):
        return "recalling_the_reasons_behind_previous_updates"
    if any(
        marker in question
        for marker in (
            "can you suggest a new",
            "suggest a new",
            "new way",
            "new ways",
            "new ideas",
            "new creative",
            "something different",
            "unique way",
            "fresh way",
        )
    ):
        return "suggest_new_ideas"
    if any(
        marker in question
        for marker in (
            "what are some new trends",
            "what did i",
            "what did you remember",
            "what have i told you",
            "what are some benefits",
        )
    ):
        return "recalling_facts_mentioned_by_the_user"
    if any(
        marker in question
        for marker in (
            "i recently",
            "last weekend",
            "the other day",
            "i was thinking",
            "i was talking",
            "i mentioned",
        )
    ) and answer_options(query):
        return "recall_user_shared_facts"
    if any(
        marker in question
        for marker in (
            "what would you suggest",
            "what should i try",
            "any creative recommendations",
            "planning a weekend",
            "planning a trip",
            "planning a cozy",
            "want to try",
            "looking for something",
        )
    ):
        return "provide_preference_aligned_recommendations"
    if any(marker in question for marker in ("what do you think", "should i", "whether i should")):
        return "generalizing_to_new_scenarios"
    if query_intent(query) == "suggestion":
        return "suggest_new_ideas"
    return "recall_user_shared_facts"


def explicit_benchmark_question_type(query: str) -> str:
    """Return an adapter-provided benchmark question type, when present."""

    match = _AMB_QUESTION_TYPE_RE.match(str(query))
    return match.group(1).strip().lower() if match else ""


def _intent_contract_source(intent: BenchmarkIntent) -> ContextSource:
    lines = [
        f"- question_type: {intent.question_type}",
        f"- question_class: {intent.question_class}",
        "- decision_criteria:",
        *[f"  - {criterion}" for criterion in intent.decision_criteria],
        "- required_evidence:",
        *[f"  - {evidence}" for evidence in intent.required_evidence],
        "- disqualifiers:",
        *[f"  - {item}" for item in intent.disqualifiers],
        "- sub_questions:",
        *[f"  - {item}" for item in intent.sub_questions],
    ]
    return ContextSource(
        id="benchmark_intent_contract",
        title="Benchmark Intent Contract",
        source_type="benchmark_evidence",
        authority="current_user",
        freshness="live",
        content="\n".join(lines) + "\n",
        mandatory=True,
        reason="Structured intent contract for evidence selection and answer verification.",
        budget_group="answer",
    )


def _option_alignment_source(
    query: str,
    evidence_texts: list[str],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    policy = _OPTION_ALIGNMENT_POLICIES.get(
        intent.question_type,
        _OptionAlignmentPolicy(False, 0.0, 0.0),
    )
    if not policy.enabled:
        return None
    options = answer_options(query)
    if not options:
        return None
    confidence = _option_alignment_confidence_label(
        query,
        options,
        evidence_texts,
        intent,
        policy,
    )
    if confidence == "none":
        return None
    content = _render_option_alignment(query, options, evidence_texts, intent)
    if not content.strip():
        return None
    content = f"- confidence: {confidence}\n" + content
    return ContextSource(
        id="option_evidence_alignment",
        title="Option Evidence Alignment",
        source_type="benchmark_evidence",
        authority="source_evidence",
        freshness="live",
        content=content,
        mandatory=True,
        reason="Deterministic option-support scores from selected memory evidence.",
        budget_group="answer",
    )


def _recall_judgment_source(
    query: str,
    evidence_texts: list[str],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if intent.question_type not in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        return None
    content = render_recall_judgment_section(
        query,
        evidence_texts,
        options=answer_options(query),
    )
    if not content.strip():
        return None
    return ContextSource(
        id="recall_exact_evidence_judgment",
        title="Recall Judgment",
        source_type="answer_instruction",
        authority="source_evidence",
        freshness="live",
        content=content,
        mandatory=True,
        reason="Recall questions must choose exact user/source evidence over plausible profile background.",
        budget_group="answer",
    )


def _suggestion_judgment_source(
    query: str,
    evidence_texts: list[str],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if intent.question_type != "suggest_new_ideas":
        return None
    content = render_suggestion_judgment_section(
        query,
        evidence_texts,
        options=answer_options(query),
    )
    if not content.strip():
        return None
    return ContextSource(
        id="suggestion_novelty_judgment",
        title="Suggestion Judgment",
        source_type="answer_instruction",
        authority="source_evidence",
        freshness="live",
        content=content,
        mandatory=True,
        reason="New-idea questions need concise novel-adjacent suggestions, not repeated familiar or padded options.",
        budget_group="answer",
    )


def _option_alignment_confidence_label(
    query: str,
    options: list[tuple[str, str]],
    evidence_texts: list[str],
    intent: BenchmarkIntent,
    policy: _OptionAlignmentPolicy,
) -> str:
    if intent.question_type == "track_full_preference_evolution":
        evidence_entries = _evolution_evidence_entries(evidence_texts)
        scored = [
            _score_evolution_option(letter, option_text, evidence_entries)
            for letter, option_text in options
        ]
        ordered = sorted(
            scored,
            key=lambda item: (-float(item["score"]), str(item["letter"])),
        )
        if not ordered:
            return "none"
        if _evolution_alignment_is_confident(ordered):
            return "high"
        top_score = float(ordered[0]["score"])
        second_score = float(ordered[1]["score"]) if len(ordered) > 1 else 0.0
        margin = top_score - second_score
        has_timeline_details = any(item.get("details") for item in ordered)
        if top_score > 0 and margin >= 2.0:
            return "medium"
        if evidence_entries and has_timeline_details:
            return "low"
        return "none"
    scored_options = score_answer_options(
        options,
        evidence_texts,
        query=query,
        question_type=intent.question_type,
    )
    if not scored_options:
        return "none"
    ordered_options = sorted(
        scored_options,
        key=lambda item: (-item.score, item.letter),
    )
    top_score = ordered_options[0].score
    second_score = ordered_options[1].score if len(ordered_options) > 1 else 0.0
    margin = top_score - second_score
    if top_score < policy.score_floor or margin < policy.margin_floor:
        return "none"
    if top_score >= policy.score_floor + 3.0 and margin >= policy.margin_floor + 2.0:
        return "high"
    return "medium"


def _deterministic_supported_answer_hint_source(
    query: str,
    evidence_texts: list[str],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if os.environ.get(_DETERMINISTIC_HINT_ENV) != "1":
        return None
    options = answer_options(query)
    if len(options) < 2:
        return None
    scored = score_answer_options(
        options,
        evidence_texts,
        query=query,
        question_type=intent.question_type,
    )
    if len(scored) < 2:
        return None
    ordered = sorted(scored, key=lambda item: (-item.score, item.letter))
    top = ordered[0]
    runner_up = ordered[1]
    margin = top.score - runner_up.score
    if (
        top.score < _DETERMINISTIC_HINT_SCORE_FLOOR
        or margin < _DETERMINISTIC_HINT_MARGIN_FLOOR
    ):
        return None
    match_text = ", ".join(top.matched_terms[:8]) if top.matched_terms else "source evidence"
    content = "\n".join(
        [
            f"- Remaind packet-level pick: ({top.letter}) [confidence high]",
            f"- scorer_margin: {margin:.2f}; score: {top.score:.2f}",
            f"- evidence_trace: {match_text}",
            "- contract: advisory only; reject this hint if another mandatory section directly contradicts it.",
            "",
        ]
    )
    return ContextSource(
        id="deterministic_supported_answer_hint",
        title="Remaind Packet-Level Pick",
        source_type="benchmark_evidence",
        authority="derived_memory",
        freshness="live",
        content=content,
        mandatory=True,
        reason="High-confidence deterministic support hint for multiple-choice evidence ranking.",
        budget_group="answer",
    )


def _evidence_slots_source(
    intent: BenchmarkIntent,
    records: list[MemoryRecord],
    profiles: list[str],
    snippets: list[dict[str, Any]],
) -> ContextSource | None:
    slots: dict[str, list[str]] = {
        "facts": [],
        "preferences": [],
        "constraints": [],
        "history": [],
        "exclusions": [],
    }
    for profile in profiles[:2]:
        slots["facts"].append(clean_snippet(profile, limit=220))
    for record in records[:10]:
        if intent.question_type == "recalling_facts_mentioned_by_the_user":
            if record.kind in ("preference", "decision"):
                continue
        target = "exclusions" if record.status == "stale" else "preferences"
        if record.kind not in ("preference", "decision"):
            target = "facts"
        slots[target].append(record_brief(record))
    for snippet in snippets[:12]:
        text = clean_snippet(str(snippet.get("text") or ""), limit=220)
        if not text:
            continue
        target = _slot_for_text(text, str(snippet.get("role") or ""), intent)
        document_id = str(snippet.get("document_id") or "unknown")
        slots[target].append(
            f"session {_document_order_label(document_id)}: {text}"
        )
    lines: list[str] = []
    for slot in ("facts", "preferences", "constraints", "history", "exclusions"):
        lines.append(f"<{slot}>")
        values = dedupe_texts(slots[slot])[:5]
        if values:
            lines.extend(f"- {value}" for value in values)
        else:
            lines.append("- empty")
        lines.append(f"</{slot}>")
    content = "\n".join(lines) + "\n"
    if all(line.endswith("empty") for line in content.splitlines() if line.startswith("- ")):
        return None
    return ContextSource(
        id="benchmark_evidence_slots",
        title="Benchmark Evidence Slots",
        source_type="benchmark_evidence",
        authority="source_evidence",
        freshness="current",
        content=content,
        mandatory=True,
        reason="Named evidence slots reveal whether the packet satisfies the intent contract.",
        budget_group="evidence",
    )


def _slot_for_text(text: str, role: str, intent: BenchmarkIntent) -> str:
    lowered = text.lower()
    if any(
        marker in lowered
        for marker in (
            "avoid",
            "abandoned",
            "crowded",
            "crowds",
            "didn't",
            "don't enjoy",
            "less engaged",
            "not really the ideal fit",
            "overwhelming",
            "performative",
            "pressure",
            "pressured",
            "rigid",
            "stifled",
            "strict",
            "too time-consuming",
            "unrelatable",
        )
    ):
        return "exclusions"
    if any(
        marker in lowered
        for marker in (
            "must",
            "need",
            "needs",
            "constraint",
            "limited",
            "latency",
            "hardware",
            "local",
            "budget",
            "comfortable",
            "confidence",
            "flexible",
            "intimate",
            "low-pressure",
            "mood",
            "small",
        )
    ):
        return "constraints"
    if intent.question_class == "suggestion" and role.upper() == "USER":
        return "preferences"
    if any(marker in lowered for marker in ("previously", "after", "recently", "now")):
        return "history"
    return "facts"


def _preference_evolution_source(
    query: str,
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if intent.question_type not in {
        "track_full_preference_evolution",
        "suggest_new_ideas",
    }:
        return None
    lines = [
        "Preference Timeline",
        "Use this chronology to resolve preference conflicts before choosing an answer.",
        "Prefer explicit ordered user evidence over assumptions from words like resumed, restarted, or again.",
        "Keep exact activity threads separate unless the answer option explicitly merges them.",
    ]
    focus_lines = _suggestion_focus_lines(query)
    if focus_lines:
        lines.extend(focus_lines)
    current_query_polarity = classify_polarity(retrieval_query_text(query))
    if (
        os.environ.get(_CURRENT_QUERY_SIGNAL_ENV) == "1"
        and current_query_polarity != "neutral"
    ):
        lines.append(
            "Current query latest signal: "
            f"{current_query_polarity} — "
            f"{clean_snippet(retrieval_query_text(query), limit=260)}"
        )
    topic_tokens = _query_and_option_topic_tokens(query)
    focused_records = (
        _records_matching_topic(
            records,
            topic_tokens,
            min_overlap=2 if intent.question_type == "track_full_preference_evolution" else 1,
        )
        or records
    )
    include_negative_history = intent.question_type != "suggest_new_ideas"
    if intent.question_type == "track_full_preference_evolution":
        timeline_2 = _preference_timeline_2_lines(focused_records, snippets)
        if timeline_2:
            lines.append("Canonical Preference Timeline 2.0:")
            lines.extend(timeline_2[:10])
        timeline = _preference_timeline_lines(focused_records, snippets)
        if timeline:
            lines.append("Chronological preference signals, oldest to newest:")
            lines.extend(timeline[:12])
        flips = _preference_flip_lines(focused_records, snippets)
        if flips:
            lines.append("Detected polarity flips:")
            lines.extend(flips[:6])
        user_snippets = [
            snippet for snippet in snippets if str(snippet.get("role")).upper() == "USER"
        ]
        if user_snippets:
            lines.append("Top user source excerpts for this query:")
            for snippet in user_snippets[:5]:
                document_id = str(snippet.get("document_id") or "unknown")
                lines.append(
                    "- "
                    f"session {_document_order_label(document_id)}: "
                    f"{clean_snippet(str(snippet.get('text') or ''), limit=210)}"
                )
        content = "\n".join(
            f"- {line}" if index < 3 else line
            for index, line in enumerate(lines)
        ) + "\n"
        return ContextSource(
            id="preference_evolution_brief",
            title="Preference Timeline",
            source_type="benchmark_evidence",
            authority="derived_memory",
            freshness="current",
            content=content,
            mandatory=True,
            reason="Ordered chronology for preference-evolution questions.",
            budget_group="answer",
        )
    current = [
        record for record in focused_records if record.status in ("current", "tentative")
    ]
    stale = [
        record
        for record in focused_records
        if record.status in ("stale", "superseded")
    ]
    if current:
        lines.append("Current positive signals, newest/session-specific first:")
        for record in sorted(current, key=_record_recency_sort_key)[:5]:
            lines.append(f"- {record_brief(record)}")
    if stale and include_negative_history:
        lines.append("Older stale or disliked signals to avoid unless revived:")
        for record in sorted(stale, key=_record_recency_sort_key)[:4]:
            lines.append(f"- {record_brief(record)}")
    timeline = (
        _preference_timeline_lines(focused_records, snippets)
        if include_negative_history
        else []
    )
    if timeline:
        lines.append("Chronological preference signals, oldest to newest:")
        lines.extend(timeline[:10])
        flips = _preference_flip_lines(focused_records, snippets)
        if flips:
            lines.append("Detected polarity flips:")
            lines.extend(flips[:5])
    user_snippets = [
        snippet for snippet in snippets if str(snippet.get("role")).upper() == "USER"
    ]
    if user_snippets:
        lines.append("Top user source excerpts for this query:")
        for snippet in user_snippets[:4]:
            document_id = str(snippet.get("document_id") or "unknown")
            lines.append(
                "- "
                f"session {_document_order_label(document_id)}: "
                f"{clean_snippet(str(snippet.get('text') or ''), limit=210)}"
            )
    content = "\n".join(f"- {line}" if index < 3 else line for index, line in enumerate(lines)) + "\n"
    return ContextSource(
        id="preference_evolution_brief",
        title="Preference Timeline",
        source_type="benchmark_evidence",
        authority="derived_memory",
        freshness="current",
        content=content,
        mandatory=True,
        reason="Query-focused conflict resolution for preference-evolution suggestions.",
        budget_group="answer",
    )


def _structured_polarity_state_source(
    query: str,
    records: list[MemoryRecord],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if intent.question_type not in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "provide_preference_aligned_recommendations",
        "generalizing_to_new_scenarios",
    }:
        return None
    topic_tokens = _query_and_option_topic_tokens(query)
    rows: list[str] = []
    seen: set[str] = set()
    for record in records:
        if record.kind != "preference" or record.subject.startswith("reason_for_change:"):
            continue
        record_tokens = _record_topic_token_set(record)
        if topic_tokens and not (topic_tokens & record_tokens):
            continue
        topic = clean_snippet(record.subject or _topic_label(record.what), limit=80)
        polarity = _polarity_label(record.what, stale=record.status == "stale")
        source = _record_source_label(record)
        fingerprint = f"{topic}|{polarity}|{record.status}|{source}"
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        rows.append(
            f"- {topic} = {polarity} ({record.status}, {source}): "
            f"{clean_snippet(record.what, limit=180)}"
        )
    if not rows:
        return None
    content = "\n".join(
        [
            "## Structured Polarity State",
            "",
            "Current query-relevant preference polarity from source-linked memory records.",
            *rows[:8],
            "",
        ]
    )
    return ContextSource(
        id="structured_polarity_state",
        title="Structured Polarity State",
        source_type="preference_state",
        authority="derived_memory",
        freshness="current",
        content=content,
        mandatory=True,
        reason="Surfaces positive, negative, stale, and superseded preference polarity for query-relevant topics.",
        budget_group="profile",
    )


def _reasons_for_past_changes_source(
    query: str,
    records: list[MemoryRecord],
    intent: BenchmarkIntent,
) -> ContextSource | None:
    if intent.question_type != "recalling_the_reasons_behind_previous_updates":
        return None
    topic_tokens = _query_and_option_topic_tokens(query)
    all_reason_records = [
        record
        for record in records
        if record.kind == "preference"
        and record.subject.startswith("reason_for_change:")
        and record.why
    ]
    reason_records = [
        record
        for record in all_reason_records
        if not topic_tokens or len(topic_tokens & _record_topic_token_set(record)) >= 2
    ] or all_reason_records
    if not reason_records:
        return None
    lines = [
        "## Reason-Change Ledger",
        "",
        "Source-linked records for explicit preference changes. Use these reasons instead of plausible inferred explanations.",
    ]
    for record in sorted(reason_records, key=_record_recency_sort_key)[:8]:
        lines.append(
            f"- changed_item: {record.subject}; why: {clean_snippet(record.why, limit=180)} "
            f"({record.status}, {_record_source_label(record)}); "
            f"source quote: {clean_snippet(record.what, limit=180)}"
        )
    lines.append("")
    return ContextSource(
        id="reasons_for_past_changes",
        title="Reason-Change Ledger",
        source_type="preference_state",
        authority="derived_memory",
        freshness="current",
        content="\n".join(lines),
        mandatory=True,
        reason="Reason-recall questions require the user's stated why, not a plausible inferred explanation.",
        budget_group="answer",
    )


def _suggestion_focus_lines(query: str) -> list[str]:
    lowered = retrieval_query_text(query).lower()
    lines: list[str] = []
    if "album review" in lowered or "reviews" in lowered:
        lines.append(
            "For album-review transition questions, prefer evidence about review purpose, music context, artist intention, listener perspective, and structuring thoughts."
        )
        lines.append(
            "Use broader genre/cultural-analysis evidence as secondary support unless it is the main stated review lesson."
        )
    if "creative outlet" in lowered or "creative outlets" in lowered or "capture emotions" in lowered:
        lines.append(
            "For new creative outlet questions, favor activities tied to the user's stated expressive channels: hands-on music work, production learning, genres/styles, writing, performing, or personally meaningful listening."
        )
        lines.append(
            "Do not over-select collaboration, documentaries, or playlists when the strongest current user evidence points to production/genre exploration or direct self-expression."
        )
    if "fulfilling way" in lowered or "express my love for music" in lowered:
        lines.append(
            "For fulfillment questions, prefer low-pressure personal expression and enjoyment if the user previously found scheduled content or group work burdensome."
        )
    if "live entertainment" in lowered or "vibrant setting" in lowered:
        lines.append(
            "For live-entertainment recommendations, prefer the direct event/show recommendation; avoid adding a class, group membership, or extra commitment unless the user asked to participate."
        )
    if "clothing" in lowered or "outfit" in lowered:
        lines.append(
            "For clothing or outfit advice, prioritize confidence, comfort, colors, mood, and present self-expression; avoid options anchored to unrelated hobbies or loose analogies."
        )
    return lines


def _preference_timeline_lines(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[str]:
    items = _preference_timeline_items(records, snippets)
    lines: list[str] = []
    for item in sorted(items, key=lambda value: (value[0], value[4], value[2])):
        session, polarity, subject, text, _order, status = item
        prefix = (
            f"- {status}, session {session}:"
            if status != "source"
            else f"- session {session}:"
        )
        lines.append(
            f"{prefix} {polarity} signal about {subject}: "
            f"{clean_snippet(text, limit=180)}"
        )
    return lines


def _preference_timeline_2_lines(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[str]:
    chains = _canonical_preference_chains(records, snippets)
    lines: list[str] = []
    for chain in chains:
        path = _preference_chain_path(chain.events)
        latest = chain.events[-1]
        lines.append(
            f"- topic={chain.topic}; state={chain.state}; "
            f"polarity_chain={path}; latest=session {latest.session}:{latest.polarity}; "
            f"evidence_count={len(chain.events)}"
        )
        decisive = _preference_chain_decisive_evidence(chain.events)
        if decisive:
            lines.append(f"  decisive_evidence={decisive}")
    return lines


def _canonical_preference_chains(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[_PreferenceTopicChain]:
    events = _canonical_preference_events(records, snippets)
    clusters: list[dict[str, Any]] = []
    for event in sorted(events, key=lambda item: (item.order, item.turn, item.topic)):
        selected: dict[str, Any] | None = None
        for cluster in clusters:
            if _canonical_topic_sets_match(set(event.tokens), set(cluster["tokens"])):
                selected = cluster
                break
        if selected is None:
            selected = {"tokens": set(event.tokens), "events": []}
            clusters.append(selected)
        selected["tokens"].update(event.tokens)
        selected["events"].append(event)

    chains: list[_PreferenceTopicChain] = []
    for cluster in clusters:
        ordered_events = tuple(
            sorted(cluster["events"], key=lambda item: (item.order, item.turn, item.text))
        )
        if not ordered_events:
            continue
        tokens = frozenset(cluster["tokens"])
        chains.append(
            _PreferenceTopicChain(
                topic=_canonical_chain_topic_label(ordered_events, tokens),
                tokens=tokens,
                events=ordered_events,
                state=_preference_chain_state(ordered_events),
            )
        )
    return sorted(
        chains,
        key=lambda chain: (
            0 if chain.state.startswith(("revived", "discarded")) else 1,
            -len(chain.events),
            chain.topic,
        ),
    )


def _canonical_preference_events(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[_PreferenceTimelineEvent]:
    events: list[_PreferenceTimelineEvent] = []
    seen: set[str] = set()
    for record in sorted(records, key=_record_chronology_sort_key):
        if record.kind != "preference":
            continue
        text = record.what or record.subject
        statement = _evolution_statement_text(text)
        polarity = _polarity_label(statement, stale=record.status == "stale")
        if polarity == "neutral" and record.status not in {"superseded", "stale"}:
            continue
        tokens = _canonical_preference_tokens(" ".join([record.subject, statement, record.how]))
        if not tokens:
            continue
        document = ""
        if record.sources:
            document = record.sources[0].source_path or record.sources[0].source_id
        session = _document_order_label(document)
        turn = _turn_order(record.where_text)
        fingerprint = _preference_event_fingerprint(session, polarity, statement)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        events.append(
            _PreferenceTimelineEvent(
                order=_document_order(document),
                turn=turn if turn >= 0 else 0,
                session=session,
                polarity=polarity,
                status=record.status,
                topic=_canonical_topic_label(tokens),
                tokens=frozenset(tokens),
                text=statement,
                source_kind="record",
            )
        )

    for snippet in snippets:
        if str(snippet.get("role")).upper() != "USER":
            continue
        text = _evolution_statement_text(str(snippet.get("text") or ""))
        explicit_neutral = _has_explicit_neutral_signal(text)
        polarity = "neutral" if explicit_neutral else _polarity_label(text, stale=False)
        if polarity == "neutral" and not explicit_neutral:
            continue
        tokens = _canonical_preference_tokens(text)
        if not tokens:
            continue
        document = str(snippet.get("document_id") or "")
        session = _document_order_label(document)
        turn = int(snippet.get("turn_index") or 0)
        fingerprint = _preference_event_fingerprint(session, polarity, text)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        events.append(
            _PreferenceTimelineEvent(
                order=_document_order(document),
                turn=turn,
                session=session,
                polarity=polarity,
                status="source",
                topic=_canonical_topic_label(tokens),
                tokens=frozenset(tokens),
                text=text,
                source_kind="source",
            )
        )
    return events


def _canonical_preference_tokens(text: str) -> frozenset[str]:
    tokens = set(_evolution_topic_tokens(text))
    tokens.difference_update(_EVOLUTION_TOPIC_NOISE)
    return frozenset(token for token in tokens if len(token) >= 4)


def _canonical_topic_sets_match(left: set[str], right: set[str]) -> bool:
    if not left or not right:
        return False
    shared = left & right
    if len(shared) >= 2:
        return True
    if not shared:
        return False
    return _has_specific_evolution_overlap(shared)


def _canonical_topic_label(tokens: frozenset[str] | set[str]) -> str:
    cleaned = sorted(
        token for token in tokens if token not in _EVOLUTION_TOPIC_NOISE and len(token) >= 4
    )
    return " ".join(cleaned[:4]) or "preference"


def _canonical_chain_topic_label(
    events: tuple[_PreferenceTimelineEvent, ...],
    tokens: frozenset[str],
) -> str:
    common = set(events[0].tokens) if events else set()
    for event in events[1:]:
        common &= set(event.tokens)
    common = {
        token
        for token in common
        if token not in _EVOLUTION_TOPIC_NOISE
        and len(token) >= 4
    }
    if len(common) == 1 and next(iter(common)) in _BROAD_EVOLUTION_SINGLE_TOKENS:
        common = set()
    if common:
        return _canonical_topic_label(common)
    return _canonical_topic_label(tokens)


def _preference_chain_state(events: tuple[_PreferenceTimelineEvent, ...]) -> str:
    polarities = _compact_polarity_sequence(event.polarity for event in events)
    if not polarities:
        return "unknown"
    latest = polarities[-1]
    previous = polarities[:-1]
    if latest == "positive":
        if "negative" in previous:
            return "revived-current-positive"
        if "neutral" in previous:
            return "resumed-current-positive"
        return "stable-current-positive"
    if latest == "negative":
        if "positive" in previous:
            return "discarded-current-negative"
        if "neutral" in previous:
            return "rejected-current-negative"
        return "stable-current-negative"
    if previous:
        return "paused-current-neutral"
    return "neutral-current"


def _preference_chain_path(events: tuple[_PreferenceTimelineEvent, ...]) -> str:
    parts: list[str] = []
    previous_polarity = ""
    for event in events:
        if event.polarity == previous_polarity:
            continue
        parts.append(f"session {event.session}:{event.polarity}")
        previous_polarity = event.polarity
    return " -> ".join(parts)


def _preference_chain_decisive_evidence(events: tuple[_PreferenceTimelineEvent, ...]) -> str:
    transition_events: list[_PreferenceTimelineEvent] = []
    previous_polarity = ""
    for event in events:
        if event.polarity == previous_polarity:
            continue
        transition_events.append(event)
        previous_polarity = event.polarity
    selected = transition_events[-3:] if transition_events else list(events[-2:])
    return " | ".join(
        f"session {event.session} {event.polarity}: {clean_snippet(event.text, limit=110)}"
        for event in selected
    )


def _preference_event_fingerprint(session: str, polarity: str, text: str) -> str:
    return f"{session}|{polarity}|{clean_snippet(text, limit=140).lower()}"


def _preference_flip_lines(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[str]:
    items = _preference_timeline_items(records, snippets)
    clusters: list[dict[str, Any]] = []
    for session, polarity, subject, text, order, _status in items:
        tokens = set(_topic_tokens(" ".join([subject, text])))
        if not tokens:
            continue
        selected: dict[str, Any] | None = None
        for cluster in clusters:
            if tokens & cluster["tokens"]:
                selected = cluster
                break
        if selected is None:
            selected = {"tokens": set(tokens), "items": []}
            clusters.append(selected)
        selected["tokens"].update(tokens)
        selected["items"].append((order, session, polarity, subject))

    lines: list[str] = []
    for cluster in clusters:
        ordered = sorted(cluster["items"], key=lambda value: value[0])
        polarities = [item[2] for item in ordered]
        compact: list[str] = []
        for polarity in polarities:
            if not compact or compact[-1] != polarity:
                compact.append(polarity)
        if len(compact) < 2:
            continue
        topic = _cluster_label(sorted(cluster["tokens"]))
        latest_session = ordered[-1][1]
        lines.append(
            f"- {topic}: {' -> '.join(compact)}; current/latest evidence is session {latest_session}"
        )
    return lines


def _preference_timeline_items(
    records: list[MemoryRecord],
    snippets: list[dict[str, Any]],
) -> list[tuple[str, str, str, str, int, str]]:
    items: list[tuple[str, str, str, str, int, str]] = []
    seen: set[str] = set()
    for record in records:
        document = ""
        if record.sources:
            document = record.sources[0].source_path or record.sources[0].source_id
        session = _document_order_label(document)
        order = _document_order(document)
        polarity = _polarity_label(record.what, stale=record.status == "stale")
        subject = _topic_label(record.subject or record.what)
        text = record.what or record.subject
        fingerprint = f"{session}|{polarity}|{clean_snippet(text, limit=120).lower()}"
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        items.append((session, polarity, subject, text, order, record.status))
    for snippet in snippets:
        if str(snippet.get("role")).upper() != "USER":
            continue
        text = str(snippet.get("text") or "")
        polarity = _polarity_label(text, stale=False)
        if polarity == "neutral":
            continue
        document = str(snippet.get("document_id") or "")
        session = _document_order_label(document)
        order = _document_order(document)
        subject = _topic_label(text)
        fingerprint = f"{session}|{polarity}|{clean_snippet(text, limit=120).lower()}"
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        items.append((session, polarity, subject, text, order, "source"))
    return items


def _polarity_label(text: str, *, stale: bool) -> str:
    if stale:
        return "negative"
    return classify_polarity(text)


def _topic_label(text: str) -> str:
    tokens = _topic_tokens(text)
    if tokens:
        return " ".join(tokens[:4])
    return clean_snippet(text, limit=80)


def _topic_tokens(text: str) -> list[str]:
    generic = {
        "about",
        "activity",
        "another",
        "became",
        "because",
        "considering",
        "decided",
        "different",
        "enjoy",
        "explore",
        "feeling",
        "found",
        "getting",
        "interested",
        "joined",
        "liked",
        "looking",
        "recently",
        "started",
        "stopped",
        "thinking",
        "trying",
        "want",
        "ways",
    }
    return [token for token in important_tokens(text) if token not in generic][:8]


def _query_and_option_topic_tokens(query: str) -> set[str]:
    tokens = set(_topic_tokens(retrieval_query_text(query)))
    tokens.update(extract_topic_tokens(retrieval_query_text(query)))
    for _letter, option_text in answer_options(query):
        tokens.update(_topic_tokens(option_text))
        tokens.update(extract_topic_tokens(option_text))
    return tokens


def _record_topic_token_set(record: MemoryRecord) -> set[str]:
    text = " ".join([record.subject, record.what, record.why, record.how])
    tokens = set(_topic_tokens(text))
    tokens.update(extract_topic_tokens(text))
    return tokens


def _records_matching_topic(
    records: list[MemoryRecord],
    topic_tokens: set[str],
    *,
    min_overlap: int = 1,
) -> list[MemoryRecord]:
    if not topic_tokens:
        return records
    selected: list[MemoryRecord] = []
    for record in records:
        record_tokens = _record_topic_token_set(record)
        if len(topic_tokens & record_tokens) >= min_overlap:
            selected.append(record)
    return selected


def _record_source_label(record: MemoryRecord) -> str:
    source_label = "unknown source"
    if record.sources:
        source = record.sources[0]
        source_label = _document_order_label(source.source_path or source.source_id)
    turn = ""
    match = re.search(r"\bturn:(\d+)\b", record.where_text)
    if match:
        turn = f" turn {match.group(1)}"
    return f"session {source_label}{turn}"


def _evolution_record_alignment_lines(records: list[MemoryRecord]) -> list[str]:
    lines: list[str] = []
    seen: set[str] = set()
    for record in sorted(records, key=_record_chronology_sort_key):
        if record.kind != "preference":
            continue
        polarity = _polarity_label(record.what, stale=record.status == "stale")
        if polarity == "neutral" and record.status not in {"superseded", "stale"}:
            continue
        text = record.what or record.subject
        fingerprint = f"{_record_source_label(record)}|{polarity}|{clean_snippet(text, limit=100).lower()}"
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        status_note = f", status {record.status}"
        if record.supersedes:
            status_note += f", supersedes {len(record.supersedes)} prior signal(s)"
        lines.append(
            f"{_record_source_label(record)}: {polarity} memory record"
            f"{status_note} about {_topic_label(record.subject or text)}: "
            f"{clean_snippet(text, limit=240)}"
        )
    return lines


def _record_chronology_sort_key(record: MemoryRecord) -> tuple[int, int, str]:
    document = ""
    if record.sources:
        source = record.sources[0]
        document = source.source_path or source.source_id
    turn = 0
    match = re.search(r"\bturn:(\d+)\b", record.where_text)
    if match:
        turn = int(match.group(1))
    return (_document_order(document), turn, record.id)


def _cluster_label(tokens: list[str]) -> str:
    return " ".join(tokens[:4]) or "preference"


def record_brief(record: MemoryRecord) -> str:
    source_label = "unknown"
    if record.sources:
        source = record.sources[0]
        source_label = _document_order_label(source.source_path or source.source_id)
    status = record.status
    return (
        f"{status}, session {source_label}: "
        f"{clean_snippet(record.what or record.subject, limit=220)}"
    )


def _record_recency_sort_key(record: MemoryRecord) -> tuple[int, str]:
    document = ""
    if record.sources:
        source = record.sources[0]
        document = source.source_path or source.source_id
    return (-_document_order(document), record.id)


def _document_order_label(document_id: str) -> str:
    order = _document_order(document_id)
    return str(order) if order >= 0 else "unknown"


def _document_order(document_id: str) -> int:
    match = re.search(r"_(\d+)$", str(document_id))
    if not match:
        return -1
    return int(match.group(1))


def _turn_order(where_text: str) -> int:
    match = re.search(r"\bturn:(\d+)\b", str(where_text))
    return int(match.group(1)) if match else -1


def answer_options(query: str) -> list[tuple[str, str]]:
    matches = list(
        re.finditer(
            r"(?:^|\n)\(([a-z])\)\s+(.*?)(?=\n\([a-z]\)\s+|\Z)",
            query,
            re.S,
        )
    )
    return [
        (match.group(1).lower(), re.sub(r"\s+", " ", match.group(2)).strip())
        for match in matches
        if match.group(2).strip()
    ]


def _render_option_alignment(
    query: str,
    options: list[tuple[str, str]],
    evidence_texts: list[str],
    intent: BenchmarkIntent,
) -> str:
    if intent.question_type == "track_full_preference_evolution":
        return _render_evolution_option_alignment(options, evidence_texts)
    scored = score_answer_options(
        options,
        evidence_texts,
        query=query,
        question_type=intent.question_type,
    )
    anchors = _option_anchor_summaries(options, evidence_texts)
    lines = [
        "Candidate verification matrix from retrieved memory evidence. Use this as the deterministic evidence trace for option ranking.",
        "- verification_contract: choose the candidate that satisfies the decision criteria with the fewest unsupported extras or disqualifier penalties.",
    ]
    if intent.question_type == "suggest_new_ideas":
        lines.append(
            "- category_rule: for new-idea questions, prefer concise novel-adjacent ideas over repeated familiar activities and overlong side quests."
        )
    elif intent.question_type == "provide_preference_aligned_recommendations":
        lines.append(
            "- category_rule: for preference recommendations, newest constraints and explicit dislikes outrank generic topical fit; penalize options that disclose crowding, rigidity, pressure, scale, or unwanted group commitment."
        )
    elif intent.question_type == "generalizing_to_new_scenarios":
        lines.append(
            "- category_rule: for generalization questions, apply the user's strongest constraints to the new scenario; reject answers that match the broad topic but violate avoid/pressure/scale/rigidity signals."
        )
    elif intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        lines.append(
            "- category_rule: for recall questions, direct user-turn noun/event evidence is decisive unless the question asks for the current preference."
        )
    elif intent.question_type == "track_full_preference_evolution":
        lines.append(
            "- category_rule: for evolution questions, select the option that matches the ordered preference timeline."
        )
    lines.append("Per-option evidence anchoring:")
    for letter, _option_text in options:
        lines.append(f"- ({letter}) {anchors.get(letter, 'no option anchor available')}")
    if intent.question_type == "suggest_new_ideas":
        novelty = suggestion_novelty_summaries(options, evidence_texts)
        lines.append("Suggestion novelty judgment:")
        for letter, _option_text in options:
            lines.append(
                f"- ({letter}) {novelty.get(letter, 'no suggestion novelty signal available')}"
            )
    if intent.question_type in {
        "provide_preference_aligned_recommendations",
        "generalizing_to_new_scenarios",
    }:
        tie_breakers = recommendation_tie_breaker_summaries(options, evidence_texts)
        label = (
            "Recommendation tie-breakers:"
            if intent.question_type == "provide_preference_aligned_recommendations"
            else "Generalization constraint tie-breakers:"
        )
        lines.append(label)
        for letter, _option_text in options:
            lines.append(
                f"- ({letter}) {tie_breakers.get(letter, 'no recommendation tie-breaker available')}"
            )
    if intent.question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        entity_summaries = entity_grounding_summaries(options, evidence_texts)
        lines.append("Entity/topic grounding:")
        for letter, _option_text in options:
            lines.append(
                f"- ({letter}) {entity_summaries.get(letter, 'no entity grounding available')}"
            )
        recall_summaries = recall_option_evidence_summaries(options, evidence_texts)
        lines.append("Recall exact-evidence judgment:")
        for letter, _option_text in options:
            lines.append(
                f"- ({letter}) {recall_summaries.get(letter, 'no recall evidence available')}"
            )
    best_score = max((item.score for item in scored), default=0.0)
    for item in scored:
        marker = "best-supported" if item.score == best_score and best_score > 0 else "support"
        match_text = ", ".join(item.matched_terms) if item.matched_terms else "no direct lexical evidence"
        penalty_text = (
            f"; penalties: {', '.join(item.penalties)}" if item.penalties else ""
        )
        lines.append(
            f"- ({item.letter}) {marker} score={item.score:.2f}; "
            f"matched evidence: {match_text}{penalty_text}"
        )
    if best_score <= 0:
        lines.append("- critic_verdict: insufficient evidence; ask a targeted clarifying question.")
    else:
        best = sorted(scored, key=lambda item: (-item.score, item.letter))[0]
        if intent.question_type in {
            "recall_user_shared_facts",
            "recalling_facts_mentioned_by_the_user",
            "recalling_the_reasons_behind_previous_updates",
        }:
            lines.append(
                f"- critic_verdict: candidate ({best.letter}) has the strongest direct evidence trace; "
                "select it for fact recall. Mixed or negative sentiment about the same activity is not a reason to choose a weaker candidate."
            )
        else:
            lines.append(
                f"- critic_verdict: candidate ({best.letter}) has the strongest evidence trace; "
                "answer model must still reject it if the packet contradicts a required criterion."
            )
    return "\n".join(lines) + "\n"


def _render_evolution_option_alignment(
    options: list[tuple[str, str]],
    evidence_texts: list[str],
) -> str:
    evidence_entries = _evolution_evidence_entries(evidence_texts)
    scored = [
        _score_evolution_option(letter, option_text, evidence_entries)
        for letter, option_text in options
    ]
    ordered = sorted(scored, key=lambda item: (-float(item["score"]), str(item["letter"])))
    best_score = max((item["score"] for item in scored), default=0.0)
    lines = [
        "Candidate timeline-fit matrix from source-backed polarity evidence.",
        "- verification_contract: choose the candidate whose claimed sequence is supported by positive and negative user-turn evidence, not the candidate with the most fluent narrative.",
        "- category_rule: unsupported intermediate activities and chronology claims contradicted by source polarity should lose even when the final current state is correct.",
        "- chronology_rule: compare the option's ordered claims against the oldest-to-newest evidence chain; initial, middle, and current polarity all matter.",
    ]
    if not evidence_entries:
        lines.append("- evidence_status: no polarity evidence found; defer to the Preference Timeline.")
    else:
        compact_evidence = _compact_polarity_sequence(
            str(entry["polarity"]) for entry in evidence_entries
        )
        lines.append(
            "- evidence_chain: "
            + " -> ".join(compact_evidence)
            + " from "
            + str(len(evidence_entries))
            + " ordered user polarity signal(s)."
        )
        thread_lines = _evolution_thread_lines(evidence_entries)
        if thread_lines:
            lines.append("Source topic threads:")
            lines.extend(thread_lines[:5])
    for item in ordered:
        marker = (
            "best-supported timeline"
            if item["score"] == best_score and best_score > 0
            else "timeline support"
        )
        details = item["details"] or ["no specific timeline claims detected"]
        lines.append(
            f"- ({item['letter']}) {marker} score={item['score']:.2f}; "
            + "; ".join(details[:5])
        )
    if best_score > 0:
        best = ordered[0]
        lines.append(
            f"- critic_verdict: candidate ({best['letter']}) best matches the source-backed preference chronology; select it unless another mandatory section directly contradicts it."
        )
    return "\n".join(lines) + "\n"


def _evolution_alignment_is_confident(scored: list[dict[str, Any]]) -> bool:
    if not scored:
        return False
    policy = _OPTION_ALIGNMENT_POLICIES["track_full_preference_evolution"]
    top = scored[0]
    second_score = float(scored[1]["score"]) if len(scored) > 1 else 0.0
    top_score = float(top["score"])
    margin = top_score - second_score
    return top_score >= policy.score_floor and margin >= policy.margin_floor


def _evolution_evidence_entries(evidence_texts: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for source_order, text in enumerate(evidence_texts):
        for sentence in re.split(r"(?<=[.!?])\s+", str(text)):
            cleaned = clean_snippet(sentence, limit=260)
            if not cleaned:
                continue
            statement = _evolution_statement_text(cleaned)
            explicit_neutral = _has_explicit_neutral_signal(statement)
            polarity = "neutral" if explicit_neutral else _polarity_label(statement, stale=False)
            if polarity == "neutral" and not explicit_neutral:
                continue
            tokens = _evolution_topic_tokens(statement)
            if not tokens:
                continue
            session_match = re.search(r"\bsession\s+([0-9]+|unknown)\b", cleaned, re.I)
            session_label = session_match.group(1) if session_match else "unknown"
            turn_match = re.search(r"\bturn\s+(\d+)\b", cleaned, re.I)
            turn_order = int(turn_match.group(1)) if turn_match else 0
            fingerprint = (
                f"{session_label}|{polarity}|"
                f"{clean_snippet(statement, limit=140).lower()}"
            )
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            entries.append(
                {
                    "polarity": polarity,
                    "tokens": tokens,
                    "text": cleaned,
                    "statement": statement,
                    "order": len(entries),
                    "source_order": source_order,
                    "session": session_label,
                    "turn_order": turn_order,
                }
            )
    return entries


def _evolution_statement_text(text: str) -> str:
    cleaned = clean_snippet(text, limit=260)
    if " memory record" in cleaned and ": " in cleaned:
        return cleaned.rsplit(": ", 1)[-1].strip()
    match = re.match(
        r"^session\s+(?:[0-9]+|unknown)(?:\s+turn\s+\d+)?:\s*(.+)$",
        cleaned,
        re.I,
    )
    if match:
        return match.group(1).strip()
    return cleaned


def _score_evolution_option(
    letter: str,
    option_text: str,
    evidence_entries: list[dict[str, Any]],
) -> dict[str, Any]:
    option = option_text.lower()
    option_tokens = _evolution_topic_tokens(option_text)
    scoped_entries = _evolution_relevant_entries(option_tokens, evidence_entries)
    score = 0.0
    details: list[str] = []

    unsupported = _unsupported_evolution_terms(option_tokens, evidence_entries)
    if unsupported:
        score -= 5.0 * len(unsupported)
        details.append(f"unsupported timeline term(s): {', '.join(sorted(unsupported)[:4])}")

    claims = _evolution_claim_sequence(option_text)
    sequence_score, sequence_details = _score_evolution_claim_sequence(
        claims,
        option_tokens,
        scoped_entries,
    )
    score += sequence_score
    details.extend(sequence_details)
    if scoped_entries and len(scoped_entries) < len(evidence_entries):
        scoped_chain = _compact_polarity_sequence(
            str(entry["polarity"]) for entry in scoped_entries
        )
        details.append(
            "topic-scoped evidence chain: "
            f"{' -> '.join(scoped_chain)} "
            f"from {len(scoped_entries)} matching signal(s)"
        )

    negative_windows = _claim_windows(option, _NEGATIVE_CLAIM_MARKERS)
    positive_windows = [
        window
        for window in _claim_windows(option, _POSITIVE_CLAIM_MARKERS)
        if not _has_negated_return(window)
    ]
    neutral_windows = _claim_windows(option, _NEUTRAL_CLAIM_MARKERS)
    return_windows = _claim_windows(
        option,
        tuple(sorted(RETURN_TERMS, key=len, reverse=True)),
    )
    return_windows = [
        window for window in return_windows if not _has_negated_return(window)
    ]

    for window in negative_windows:
        tokens = _evolution_topic_tokens(window)
        if not tokens:
            continue
        window_entries = _evolution_relevant_entries(tokens, scoped_entries)
        support = _matching_entries(tokens, "negative", window_entries)
        contradiction = _matching_entries(tokens, "positive", window_entries)
        if support:
            score += 6.0
            details.append(f"negative claim supported by {support[0]['text']}")
        elif contradiction:
            score -= 7.0
            details.append(f"negative claim contradicted by {contradiction[0]['text']}")
        else:
            score -= 3.0
            details.append(f"negative claim lacks source support: {clean_snippet(window, limit=80)}")
        if "from the start" in window:
            narrowed_tokens = tokens - {"fan_fiction", "tutorial"}
            start_contradiction = contradiction or _matching_entries(
                narrowed_tokens,
                "positive",
                window_entries,
            )
        else:
            start_contradiction = []
        if "from the start" in window and start_contradiction:
            score -= 8.0
            details.append("from-the-start claim conflicts with earlier positive evidence")

    for window in positive_windows:
        tokens = _evolution_topic_tokens(window)
        if not tokens:
            continue
        window_entries = _evolution_relevant_entries(tokens, scoped_entries)
        support = _matching_entries(tokens, "positive", window_entries)
        contradiction = _matching_entries(tokens, "negative", window_entries)
        if support:
            score += 3.0
        elif contradiction:
            score -= 4.0
            details.append(f"positive claim contradicted by {contradiction[0]['text']}")

    for window in neutral_windows:
        tokens = _evolution_topic_tokens(window)
        if not tokens:
            continue
        window_entries = _evolution_relevant_entries(tokens, scoped_entries)
        support = _matching_entries(tokens, "neutral", window_entries)
        positive = _matching_entries(tokens, "positive", window_entries)
        negative = _matching_entries(tokens, "negative", window_entries)
        if support:
            score += 5.0
            details.append(f"neutral/indifference claim supported by {support[0]['text']}")
        elif positive or negative:
            neutral_contradiction = positive[0] if positive else negative[0]
            score -= 6.0
            details.append(
                "neutral/indifference claim contradicted by "
                f"{neutral_contradiction['polarity']} evidence: {neutral_contradiction['text']}"
            )
        else:
            score -= 2.0
            details.append(
                "neutral/indifference claim lacks source support: "
                f"{clean_snippet(window, limit=80)}"
            )

    for window in return_windows:
        tokens = _evolution_topic_tokens(window)
        if not tokens:
            continue
        window_entries = _evolution_relevant_entries(tokens, scoped_entries)
        positive = _matching_entries(tokens, "positive", window_entries)
        negative = _matching_entries(tokens, "negative", window_entries)
        if positive and negative:
            score += 4.0
            details.append(f"return/revival claim has both negative and positive evidence for {', '.join(sorted(tokens)[:3])}")
        elif negative and not positive:
            score -= 6.0
            details.append(f"return/revival claim lacks later positive evidence for {', '.join(sorted(tokens)[:3])}")

    if "brief period" in option and any(
        _matching_entries(tokens, "negative", scoped_entries) for tokens in [option_tokens]
    ):
        score += 1.0
    return {"letter": letter, "score": score, "details": details}


_NEGATIVE_CLAIM_MARKERS = tuple(sorted(NEGATIVE_TERMS, key=len, reverse=True))

_POSITIVE_CLAIM_MARKERS = tuple(sorted(POSITIVE_TERMS, key=len, reverse=True))

_NEUTRAL_CLAIM_MARKERS = (
    "ambivalent",
    "could take it or leave it",
    "did not mind",
    "didn't mind",
    "disinterested",
    "indifference",
    "indifferent",
    "lukewarm",
    "neutral",
    "not a big part",
    "not at the forefront",
    "not especially interested",
    "wasn't especially interested",
    "wasn't very interested",
    "weren't especially interested",
    "weren't very interested",
)


def _has_explicit_neutral_signal(text: str) -> bool:
    lowered = str(text).lower().replace("\u2019", "'")
    return any(marker in lowered for marker in _NEUTRAL_CLAIM_MARKERS)


def _evolution_claim_sequence(option_text: str) -> list[dict[str, Any]]:
    markers: list[tuple[str, str]] = []
    markers.extend((marker, "negative") for marker in _NEGATIVE_CLAIM_MARKERS)
    markers.extend((marker, "positive") for marker in _POSITIVE_CLAIM_MARKERS)
    markers.extend((marker, "neutral") for marker in _NEUTRAL_CLAIM_MARKERS)
    markers.extend((marker, "return") for marker in RETURN_TERMS)
    claims: list[dict[str, Any]] = []
    lowered = option_text.lower().replace("\u2019", "'")
    for marker, polarity in markers:
        for index in _marker_indexes(lowered, marker):
            window_start = max(0, index - 90)
            window_end = min(len(option_text), index + 150)
            window = option_text[window_start:window_end]
            tokens = _evolution_topic_tokens(window)
            normalized_polarity = polarity
            if polarity in {"positive", "return"} and _marker_is_negated(lowered, index):
                normalized_polarity = "negative"
            claims.append(
                {
                    "index": index,
                    "polarity": normalized_polarity,
                    "raw_polarity": polarity,
                    "tokens": tokens,
                    "text": clean_snippet(window, limit=120),
                }
            )
    ordered = sorted(claims, key=lambda claim: (int(claim["index"]), str(claim["polarity"])))
    compact: list[dict[str, Any]] = []
    for claim in ordered:
        normalized_polarity = "positive" if claim["polarity"] == "return" else claim["polarity"]
        if compact:
            previous = compact[-1]
            previous_tokens = set(previous["tokens"])
            claim_tokens = set(claim["tokens"])
            if (
                previous["polarity"] == normalized_polarity
                and (previous_tokens & claim_tokens or not previous_tokens or not claim_tokens)
            ):
                previous["tokens"] = previous_tokens | claim_tokens
                continue
        compact.append(
            {
                "polarity": normalized_polarity,
                "raw_polarity": claim["polarity"],
                "tokens": set(claim["tokens"]),
                "text": claim["text"],
            }
        )
    return compact


def _score_evolution_claim_sequence(
    claims: list[dict[str, Any]],
    option_tokens: set[str],
    evidence_entries: list[dict[str, Any]],
) -> tuple[float, list[str]]:
    if not claims or not evidence_entries:
        return 0.0, []
    relevant_entries = _evolution_relevant_entries(option_tokens, evidence_entries)
    evidence_sequence = _compact_polarity_sequence(
        str(entry["polarity"]) for entry in relevant_entries
    )
    claim_sequence = _compact_polarity_sequence(
        str(claim["polarity"]) for claim in claims
    )
    if not evidence_sequence or not claim_sequence:
        return 0.0, []

    score = 0.0
    details: list[str] = []
    if claim_sequence[0] == evidence_sequence[0]:
        score += 3.0
        details.append(f"initial polarity matches source chronology: {claim_sequence[0]}")
    else:
        score -= 5.0
        details.append(
            "initial polarity claim conflicts with source chronology: "
            f"claimed {claim_sequence[0]}, evidence {evidence_sequence[0]}"
        )

    if claim_sequence[-1] == evidence_sequence[-1]:
        score += 3.0
        details.append(f"latest/current polarity matches source chronology: {claim_sequence[-1]}")
    else:
        score -= 4.0
        details.append(
            "latest/current polarity claim conflicts with source chronology: "
            f"claimed {claim_sequence[-1]}, evidence {evidence_sequence[-1]}"
        )

    if _is_ordered_subsequence(claim_sequence, evidence_sequence):
        score += 6.0
        details.append(
            "ordered claim sequence matches evidence chain: "
            f"{' -> '.join(claim_sequence)}"
        )
    elif len(claim_sequence) > 1:
        score -= 3.0
        details.append(
            "ordered claim sequence does not match evidence chain: "
            f"claimed {' -> '.join(claim_sequence)}, evidence {' -> '.join(evidence_sequence)}"
        )

    if "neutral" in claim_sequence and "neutral" not in evidence_sequence:
        if {"positive", "negative"} & set(evidence_sequence):
            score -= 5.0
            details.append(
                "neutral/indifference chronology is unsupported by explicit source evidence"
            )

    return score, details


def _evolution_relevant_entries(
    topic_tokens: set[str],
    evidence_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if not topic_tokens:
        return evidence_entries
    strong: list[dict[str, Any]] = []
    weak: list[dict[str, Any]] = []
    special_terms = {"fan_fiction", "tutorial", "book_creative_product", "merchandise"}
    for entry in evidence_entries:
        entry_tokens = set(entry["tokens"])
        overlap = topic_tokens & entry_tokens
        if not overlap:
            continue
        if special_terms & topic_tokens and not (special_terms & entry_tokens):
            continue
        if len(overlap) >= 2 or _has_specific_evolution_overlap(overlap):
            strong.append(entry)
        else:
            weak.append(entry)
    return strong or weak or evidence_entries


def _evolution_thread_lines(evidence_entries: list[dict[str, Any]]) -> list[str]:
    threads: list[dict[str, Any]] = []
    for entry in evidence_entries:
        entry_tokens = set(entry["tokens"])
        if not entry_tokens:
            continue
        selected: dict[str, Any] | None = None
        for thread in threads:
            overlap = entry_tokens & set(thread["tokens"])
            if len(overlap) >= 2 or _has_specific_evolution_overlap(overlap):
                selected = thread
                break
        if selected is None:
            selected = {"tokens": set(entry_tokens), "entries": []}
            threads.append(selected)
        selected["tokens"].update(entry_tokens)
        selected["entries"].append(entry)

    lines: list[str] = []
    for thread in threads:
        entries = sorted(
            thread["entries"],
            key=lambda entry: (
                int(entry.get("source_order") or 0),
                int(entry.get("turn_order") or 0),
            ),
        )
        sequence = _compact_polarity_sequence(str(entry["polarity"]) for entry in entries)
        if not sequence:
            continue
        label = _cluster_label(sorted(thread["tokens"]))
        first_session = str(entries[0].get("session") or "unknown")
        latest_session = str(entries[-1].get("session") or "unknown")
        lines.append(
            f"- {label}: {' -> '.join(sequence)} "
            f"(session {first_session} to {latest_session}; {len(entries)} signal(s))"
        )
    return lines


def _compact_polarity_sequence(polarities: Any) -> list[str]:
    compact: list[str] = []
    for polarity in polarities:
        normalized = str(polarity)
        if normalized == "return":
            normalized = "positive"
        if normalized not in {"positive", "negative", "neutral"}:
            continue
        if not compact or compact[-1] != normalized:
            compact.append(normalized)
    return compact


def _is_ordered_subsequence(needle: list[str], haystack: list[str]) -> bool:
    if not needle:
        return True
    position = 0
    for item in haystack:
        if item == needle[position]:
            position += 1
            if position == len(needle):
                return True
    return False


def _claim_windows(text: str, markers: tuple[str, ...]) -> list[str]:
    windows: list[str] = []
    lowered = text.lower()
    for marker in markers:
        for index in _marker_indexes(lowered, marker):
            window_start = max(0, index - 90)
            window_end = min(len(text), index + 150)
            windows.append(text[window_start:window_end])
    return dedupe_texts(windows)


def _marker_indexes(lowered_text: str, marker: str) -> list[int]:
    normalized_marker = str(marker).lower().replace("\u2019", "'")
    if not normalized_marker:
        return []
    pattern = rf"(?<![a-z0-9]){re.escape(normalized_marker)}(?![a-z0-9])"
    return [match.start() for match in re.finditer(pattern, lowered_text)]


def _marker_is_negated(lowered_text: str, marker_index: int) -> bool:
    prefix = lowered_text[max(0, marker_index - 28) : marker_index]
    return bool(
        re.search(
            r"\b(?:never|not|no longer|didn't|did not|don't|do not|wasn't|weren't)\s+$",
            prefix,
        )
    )


def _has_negated_return(text: str) -> bool:
    lowered = str(text).lower().replace("\u2019", "'")
    return any(
        re.search(
            rf"\b(?:never|not|no longer|didn't|did not|don't|do not|wasn't|weren't)\s+{re.escape(marker)}\b",
            lowered,
        )
        for marker in RETURN_TERMS
    )


def _evolution_topic_tokens(text: str) -> set[str]:
    lowered = text.lower()
    tokens = set(_topic_tokens(text))
    tokens.update(extract_topic_tokens(text))
    tokens.difference_update(_EVOLUTION_TOPIC_NOISE)
    if "fan fiction" in lowered:
        tokens.add("fan_fiction")
    if "tutorial" in lowered:
        tokens.add("tutorial")
    has_creative_product_context = any(
        re.search(rf"\b{re.escape(marker)}\b", lowered)
        for marker in (
            "art",
            "bookmark",
            "merchandise",
            "product",
            "design",
            "goodies",
        )
    )
    if has_creative_product_context:
        tokens.update({"book_creative_product", "merchandise"})
    return tokens


_EVOLUTION_TOPIC_NOISE = {
    "again",
    "and",
    "because",
    "current",
    "enjoy",
    "enjoyed",
    "enjoying",
    "initially",
    "last",
    "later",
    "liked",
    "loved",
    "recently",
    "session",
    "small",
    "then",
    "too",
    "turn",
    "weekend",
}


def _unsupported_evolution_terms(
    option_tokens: set[str],
    evidence_entries: list[dict[str, Any]],
) -> set[str]:
    evidence_tokens: set[str] = set()
    for entry in evidence_entries:
        evidence_tokens.update(entry["tokens"])
    candidate_terms = {
        token
        for token in option_tokens
        if token in {"tutorial", "fan_fiction", "book_creative_product", "merchandise"}
    }
    return {token for token in candidate_terms if token not in evidence_tokens}


def _matching_entries(
    tokens: set[str],
    polarity: str,
    evidence_entries: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if not tokens:
        return []
    matches: list[dict[str, Any]] = []
    for entry in evidence_entries:
        if entry["polarity"] != polarity:
            continue
        overlap = tokens & entry["tokens"]
        if not overlap:
            continue
        if "fan_fiction" in tokens and "fan_fiction" not in entry["tokens"]:
            continue
        if "tutorial" in tokens and "tutorial" not in entry["tokens"]:
            continue
        if {"book_creative_product", "merchandise"} & tokens and not (
            {"book_creative_product", "merchandise"} & entry["tokens"]
        ):
            continue
        if (
            not (
                {"fan_fiction", "tutorial", "book_creative_product", "merchandise"}
                & tokens
            )
            and len(overlap) < 2
            and not _has_specific_evolution_overlap(overlap)
        ):
            continue
        matches.append(entry)
    return matches


_BROAD_EVOLUTION_SINGLE_TOKENS = {
    "activity",
    "book",
    "club",
    "creative",
    "event",
    "film",
    "music",
    "project",
    "study",
    "thing",
    "topics",
    "work",
    "writing",
}


def _has_specific_evolution_overlap(overlap: set[str]) -> bool:
    return any(
        len(token) >= 4 and token not in _BROAD_EVOLUTION_SINGLE_TOKENS
        for token in overlap
    )


def _option_anchor_summaries(
    options: list[tuple[str, str]],
    evidence_texts: list[str],
) -> dict[str, str]:
    evidence_units = [text.lower() for text in evidence_texts if text.strip()]
    token_sets = {
        letter: set(important_tokens(option_text)) for letter, option_text in options
    }
    token_frequency: dict[str, int] = {}
    for tokens in token_sets.values():
        for token in tokens:
            token_frequency[token] = token_frequency.get(token, 0) + 1
    summaries: dict[str, str] = {}
    for letter, option_text in options:
        option_tokens = sorted(token_sets[letter])
        discriminators = [
            token for token in option_tokens if token_frequency.get(token, 0) == 1
        ]
        if not discriminators:
            discriminators = option_tokens[:6]
        direct_refs = 0
        lexical_hits = 0
        for evidence in evidence_units:
            hit = False
            for token in discriminators:
                count = evidence.count(token)
                if count:
                    hit = True
                    lexical_hits += count
            if hit:
                direct_refs += 1
        support_density = direct_refs / max(len(option_text) / 100, 1.0)
        summary_terms = ", ".join(discriminators[:6]) or "no discriminating terms"
        summaries[letter] = (
            f"direct_turn_refs={direct_refs}; lexical_hits={lexical_hits}; "
            f"support_density={support_density:.2f}/100chars; "
            f"length={len(option_text)} chars; discriminators={summary_terms}"
        )
    return summaries


def choose_supported_answer(
    query: str,
    context: str,
    *,
    question_type: str = "",
) -> str:
    """Choose the best multiple-choice option from retrieved evidence only."""

    options = answer_options(query)
    if not options:
        return ""
    scored = score_answer_options(
        options,
        [_answer_evidence_text(context)],
        query=query,
        question_type=question_type or benchmark_question_type(query),
    )
    if not scored:
        return ""
    ordered = sorted(scored, key=lambda item: (-item.score, item.letter))
    return ordered[0].letter


def _answer_evidence_text(context: str) -> str:
    sections: list[str] = []
    for heading in (
        "## Decision Contract",
        "## Option Evidence Alignment",
        "## Evidence Slots",
        "## Preference Timeline",
        "## Structured Polarity State",
        "## Reasons For Past Changes",
        "## Reason-Change Ledger",
        "## Durable Profile / Current Memory State",
        "## Structured Preference / Memory State",
        "## Relevant Source Evidence",
        "## Low-Authority Background Profile",
    ):
        start = context.find(heading)
        if start < 0:
            continue
        next_heading = context.find("\n## ", start + len(heading))
        if next_heading < 0:
            sections.append(context[start:])
        else:
            sections.append(context[start:next_heading])
    return "\n\n".join(sections) if sections else context


def score_answer_options(
    options: list[tuple[str, str]],
    evidence_texts: list[str],
    *,
    query: str = "",
    question_type: str = "",
) -> list[AnswerOptionSupport]:
    """Score answer options against retrieved evidence with contrastive terms."""

    evidence = " ".join(evidence_texts).lower()
    token_sets = {
        letter: set(important_tokens(option_text)) for letter, option_text in options
    }
    token_frequency: dict[str, int] = {}
    for tokens in token_sets.values():
        for token in tokens:
            token_frequency[token] = token_frequency.get(token, 0) + 1
    total_options = max(len(options), 1)
    recall_adjustments: dict[str, tuple[float, list[str]]] = {}
    if question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        recall_adjustments = recall_option_adjustments(options, evidence_texts)
        entity_adjustments = entity_grounding_adjustments(options, evidence_texts)
        for letter, adjustment in entity_adjustments.items():
            prior = recall_adjustments.get(letter, (0.0, []))
            recall_adjustments[letter] = (
                prior[0] + adjustment[0],
                [*prior[1], *adjustment[1]],
            )
    suggestion_adjustments: dict[str, tuple[float, list[str]]] = {}
    if question_type == "suggest_new_ideas":
        suggestion_adjustments = suggestion_novelty_adjustments(options, evidence_texts)
    scored: list[AnswerOptionSupport] = []
    for letter, option_text in options:
        score = 0.0
        matches: list[str] = []
        penalties: list[str] = []
        option_tokens = sorted(token_sets[letter])
        option_phrases = important_phrases(option_tokens)
        for token in option_tokens:
            if token not in evidence:
                continue
            distinctiveness = 1.0 + ((total_options - token_frequency[token]) / total_options)
            score += (1.0 + min(len(token), 10) / 10) * distinctiveness
            matches.append(token)
        for phrase in option_phrases:
            if phrase in evidence:
                score += 2.25
        penalty = (
            None
            if question_type == "generalizing_to_new_scenarios"
            else _option_negative_evidence_penalty(option_text, evidence)
        )
        if penalty:
            score -= penalty[0]
            penalties.extend(penalty[1])
        query_adjustment = _query_option_adjustment(option_text, query)
        if query_adjustment:
            score += query_adjustment[0]
            penalties.extend(query_adjustment[1])
        type_adjustment = _question_type_option_adjustment(option_text, question_type)
        if type_adjustment:
            score += type_adjustment[0]
            penalties.extend(type_adjustment[1])
        if question_type in {
            "provide_preference_aligned_recommendations",
            "generalizing_to_new_scenarios",
        }:
            recommendation_adjustment = recommendation_tie_breaker_adjustment(
                option_text,
                evidence_texts,
            )
            if recommendation_adjustment:
                score += recommendation_adjustment[0]
                penalties.extend(recommendation_adjustment[1])
        if question_type == "generalizing_to_new_scenarios":
            generalization_adjustment = _generalization_option_adjustment(
                option_text,
                query,
                evidence,
            )
            if generalization_adjustment:
                score += generalization_adjustment[0]
                penalties.extend(generalization_adjustment[1])
        if question_type == "recalling_the_reasons_behind_previous_updates":
            reason_adjustment = _reason_change_option_adjustment(
                option_text,
                query,
                evidence,
            )
            if reason_adjustment:
                score += reason_adjustment[0]
                penalties.extend(reason_adjustment[1])
        if question_type == "recalling_facts_mentioned_by_the_user":
            fact_adjustment = _fact_recall_option_adjustment(
                option_text,
                query,
                evidence,
            )
            if fact_adjustment:
                score += fact_adjustment[0]
                penalties.extend(fact_adjustment[1])
        suggestion_adjustment = suggestion_adjustments.get(letter)
        if suggestion_adjustment:
            score += suggestion_adjustment[0]
            penalties.extend(suggestion_adjustment[1])
        recall_adjustment = recall_adjustments.get(letter)
        if recall_adjustment:
            score += recall_adjustment[0]
            penalties.extend(recall_adjustment[1])
        scored.append(
            AnswerOptionSupport(
                letter=letter,
                score=score,
                matched_terms=tuple(matches[:12]),
                penalties=tuple(penalties[:4]),
            )
        )
    return scored


def _generalization_option_adjustment(
    option_text: str,
    query: str,
    evidence: str,
) -> tuple[float, list[str]] | None:
    """Reward options that transfer the right constraint into a new scenario."""

    query_text = retrieval_query_text(query).lower()
    option = option_text.lower()
    adjustment = 0.0
    reasons: list[str] = []
    if any(marker in query_text for marker in ("unsure", "not sure", "should i")):
        caution_markers = (
            "assess",
            "comfortable",
            "concern",
            "similar to a past experience",
            "low-pressure",
            "low pressure",
            "smaller group",
            "smaller groups",
            "build confidence",
            "would you like",
        )
        generic_push_markers = (
            "always a great opportunity",
            "open doors",
            "fantastic idea",
            "perfect way",
        )
        if any(marker in option for marker in caution_markers):
            adjustment += 10.0
            reasons.append("generalization: cautious transfer")
        if any(marker in option for marker in generic_push_markers):
            adjustment -= 8.0
            reasons.append("generalization: generic encouragement")
    if any(
        marker in evidence
        for marker in (
            "teamwork",
            "strategic planning",
            "shared tasks",
            "shared achievements",
            "collaboration",
            "working together",
        )
    ):
        board_game_transfer_markers = (
            "teamwork",
            "strategic planning",
            "shared tasks",
            "shared achievements",
            "collaboration among friends",
        )
        if any(marker in option for marker in board_game_transfer_markers):
            adjustment += 14.0
            reasons.append("generalization: preserves collaboration signal")
    if any(
        marker in evidence
        for marker in (
            "books",
            "guides",
            "written content",
            "blogs",
            "articles",
            "reading",
        )
    ):
        written_material_markers = (
            "print materials",
            "bookstore",
            "art supply",
            "craft fair",
            "creative tools",
        )
        if any(marker in option for marker in written_material_markers):
            adjustment += 14.0
            reasons.append("generalization: preserves written-material discovery signal")
    if adjustment == 0.0:
        return None
    return adjustment, reasons


def _reason_change_option_adjustment(
    option_text: str,
    query: str,
    evidence: str,
) -> tuple[float, list[str]] | None:
    """Reward explicit, source-adjacent why-change answers over generic causes."""

    option = option_text.lower()
    query_text = retrieval_query_text(query).lower()
    adjustment = 0.0
    reasons: list[str] = []
    concrete_reason_markers = (
        "due to",
        "because",
        "prompted by",
        "finding",
        "felt",
        "realizing",
    )
    generic_reason_markers = (
        "desire for variety",
        "time-efficient",
        "technology has deepened",
        "recent travel experiences",
    )
    if any(marker in option for marker in concrete_reason_markers):
        adjustment += 8.0
        reasons.append("reason-ledger: explicit changed-because claim")
    if "transitioned from" in option and " to " in option and "due to" in option:
        adjustment += 8.0
        reasons.append("reason-ledger: explicit from-to-because transition")
    if any(marker in option for marker in generic_reason_markers) and not any(
        marker in evidence for marker in generic_reason_markers
    ):
        adjustment -= 10.0
        reasons.append("reason-ledger: unsupported generic cause")
    query_terms = {
        token
        for token in important_tokens(query_text)
        if len(token) > 5
        and token
        not in {
            "current",
            "latest",
            "change",
            "changed",
            "shifted",
            "perspective",
            "think",
            "about",
        }
    }
    option_terms = set(important_tokens(option))
    overlap = query_terms & option_terms
    if len(overlap) >= 4:
        adjustment += min(12.0, 2.0 * len(overlap))
        reasons.append("reason-ledger: mirrors current change evidence")
    if adjustment == 0.0:
        return None
    return adjustment, reasons


def _fact_recall_option_adjustment(
    option_text: str,
    query: str,
    evidence: str,
) -> tuple[float, list[str]] | None:
    """Prefer exact recalled fact details over plausible neighboring facts."""

    query_text = retrieval_query_text(query).lower()
    option = option_text.lower()
    adjustment = 0.0
    reasons: list[str] = []
    if "trend" in query_text or "trends" in query_text:
        trend_markers = (
            "rise of",
            "increasing focus",
            "buzz",
            "potential to revolutionize",
            "to the forefront",
            "inclusive",
            "diversity",
        )
        trend_hits = sum(1 for marker in trend_markers if marker in option)
        if trend_hits >= 2:
            adjustment += 18.0
            reasons.append("fact-grounding: explicit trend framing")
        persona_bait_markers = (
            "sustainable production",
            "carbon footprint",
            "blockchain",
            "film financing",
        )
        if any(marker in option for marker in persona_bait_markers):
            adjustment -= 10.0
            reasons.append("fact-grounding: plausible industry distractor")
    if "cooking" in query_text and ("recipe" in query_text or "recipes" in query_text):
        cultural_recipe_markers = (
            "fusion cuisine",
            "fusion cuisines",
            "different cultures",
            "similar ingredients",
            "combine elements",
        )
        adjacent_but_wrong_markers = (
            "farmers' markets",
            "farmers markets",
            "food blog",
            "molecular gastronomy",
        )
        if any(marker in option for marker in cultural_recipe_markers):
            adjustment += 14.0
            reasons.append("fact-grounding: continues cultural recipe evidence")
        if any(marker in option for marker in adjacent_but_wrong_markers):
            adjustment -= 6.0
            reasons.append("fact-grounding: neighboring cooking distractor")
    exact_recall_phrases = (
        "seems like you really enjoyed",
        "nostalgic experience",
        "discovering new artists",
        "thrill of discovering",
    )
    if any(marker in option and marker in evidence for marker in exact_recall_phrases):
        adjustment += 16.0
        reasons.append("fact-grounding: exact recalled experience phrase")
    if adjustment == 0.0:
        return None
    return adjustment, reasons


def _question_type_option_adjustment(
    option_text: str,
    question_type: str,
) -> tuple[float, list[str]] | None:
    option = option_text.lower()
    adjustment = 0.0
    reasons: list[str] = []
    if question_type == "suggest_new_ideas":
        overlong_markers = (
            "class",
            "community",
            "group",
            "join",
            "membership",
            "side project",
            "workshop",
        )
        if len(option_text) > 420:
            adjustment -= 8.0
            reasons.append("overlong new-idea option")
        if len(option_text) > 300 and any(marker in option for marker in overlong_markers):
            adjustment -= 6.0
            reasons.append("new-idea side quest")
        direct_markers = (
            "try ",
            "how about",
            "consider",
            "you could",
            "might enjoy",
        )
        if len(option_text) <= 260 and any(marker in option for marker in direct_markers):
            adjustment += 4.0
    elif question_type in {
        "recall_user_shared_facts",
        "recalling_facts_mentioned_by_the_user",
        "recalling_the_reasons_behind_previous_updates",
    }:
        if option.startswith(("i remember", "you mentioned", "you told me")):
            adjustment += 4.0
    elif question_type == "track_full_preference_evolution":
        sequence_markers = (
            "initially",
            "then",
            "later",
            "eventually",
            "now",
            "over time",
            "evolved",
            "shifted",
            "transitioned",
        )
        adjustment += 1.5 * sum(1 for marker in sequence_markers if marker in option)
    if adjustment == 0.0:
        return None
    return adjustment, reasons


def _option_negative_evidence_penalty(
    option_text: str,
    evidence: str,
) -> tuple[float, list[str]] | None:
    option = option_text.lower()
    penalty = 0.0
    reasons: list[str] = []
    negative_groups = [
        (
            ("collaborat", "working with others", "group efforts", "collective"),
            (
                "disagreements",
                "stifled",
                "bandmates",
                "artistic direction",
                "not really the ideal fit",
            ),
            "collaboration conflict",
            6.0,
        ),
        (
            ("podcast", "content creation"),
            (
                "don't enjoy podcasting",
                "too time-consuming",
                "content creation schedules",
                "chore than a passion",
                "decided i don't enjoy",
            ),
            "podcast abandoned",
            6.0,
        ),
        (
            ("documentary", "documentaries", "film"),
            (
                "something was missing",
                "didn't engage",
                "cliché",
                "unrelatable",
            ),
            "documentary or film disliked",
            4.0,
        ),
        (
            ("playlist", "playlists", "curated"),
            (
                "didn't stick",
                "less engaged",
                "not really the ideal fit",
            ),
            "playlist weak fit",
            3.0,
        ),
    ]
    for option_markers, evidence_markers, reason, weight in negative_groups:
        if any(marker in option for marker in option_markers) and any(
            marker in evidence for marker in evidence_markers
        ):
            penalty += weight
            reasons.append(reason)
    if penalty <= 0:
        return None
    return penalty, reasons


def _query_option_adjustment(
    option_text: str,
    query: str,
) -> tuple[float, list[str]] | None:
    query_text = retrieval_query_text(query).lower()
    option = option_text.lower()
    adjustment = 0.0
    reasons: list[str] = []
    if "live entertainment" in query_text or "vibrant setting" in query_text:
        if "show" in option and "improv" in option:
            adjustment += 12.0
        extra_commitments = (
            "class",
            "join",
            "joining",
            "group",
            "participants",
            "try their hand",
            "becoming part",
            "working together",
            "meet new people",
            "community",
        )
        if any(marker in option for marker in extra_commitments):
            adjustment -= 22.0
            reasons.append("extra participation commitment")
        if len(option) > 300:
            adjustment -= 8.0
            reasons.append("overlong live-event option")
    if "clothing" in query_text or "outfit" in query_text:
        direct_markers = (
            "confident",
            "comfortable",
            "colors",
            "mood",
            "expressing who you are in the moment",
        )
        adjustment += 2.0 * sum(1 for marker in direct_markers if marker in option)
        unrelated_analogy_markers = (
            "just as",
            "like sharing",
            "for instance",
            "animal shelter",
            "pottery",
            "travel",
            "local connections",
            "relationships",
        )
        if any(marker in option for marker in unrelated_analogy_markers):
            adjustment -= 12.0
            reasons.append("unrelated outfit analogy")
        if len(option) > 300:
            adjustment -= 5.0
            reasons.append("overlong outfit option")
    if adjustment == 0.0:
        return None
    return adjustment, reasons


def _rank_memory_records(
    records: list[MemoryRecord],
    tokens: list[str],
    phrases: list[str],
    intent: str,
) -> list[MemoryRecord]:
    scored: list[tuple[float, int, MemoryRecord]] = []
    for index, record in enumerate(records):
        haystack = " ".join(
            [
                record.subject,
                record.what,
                record.why,
                record.how,
                " ".join(record.entities),
            ]
        ).lower()
        score = float(record.importance)
        if record.status in {"current", "tentative", "blocked"}:
            score += 2.5
        elif record.status == "superseded":
            score += 0.8
        for token in tokens:
            if token in haystack:
                score += 1.0 + min(len(token), 10) / 10
        for phrase in phrases:
            if phrase in haystack:
                score += 2.0
        if intent == "suggestion":
            score += keyword_score(
                haystack,
                (
                    "active",
                    "album review",
                    "composition",
                    "creative",
                    "experiment",
                    "genre",
                    "instrument",
                    "music",
                    "musical",
                    "original",
                    "perform",
                    "production",
                    "project",
                    "review",
                    "style",
                    "technique",
                    "workshop",
                    "writing",
                ),
                0.7,
            )
            if any(
                marker in haystack
                for marker in (
                    "abandoned",
                    "cliché",
                    "didn't stick",
                    "disappointed",
                    "don't enjoy",
                    "less engaged",
                    "not really the ideal fit",
                    "stifled",
                    "too time-consuming",
                    "unrelatable",
                )
            ):
                score -= 1.4
        elif intent == "reason_update":
            score += keyword_score(
                haystack,
                (
                    "because",
                    "change of heart",
                    "decided",
                    "motivated",
                    "reason",
                    "realized",
                ),
                0.9,
            )
        scored.append((score, index, record))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return [record for _score, _index, record in scored]


def _render_benchmark_memory_records(records: list[MemoryRecord]) -> str:
    lines = ["## Structured Preference State", ""]
    for index, record in enumerate(records, 1):
        lines.append(f"{index}. {record.kind} [{record.status}]: {record.subject}")
        lines.append(f"   what: {clean_snippet(record.what, limit=260)}")
        if record.why:
            lines.append(f"   why: {clean_snippet(record.why, limit=160)}")
        if record.how:
            lines.append(f"   how: {clean_snippet(record.how, limit=160)}")
        if record.sources:
            source = record.sources[0]
            lines.append(
                f"   source: {source.source_kind}:{source.source_id}"
                + (
                    f" — {clean_snippet(source.source_excerpt, limit=160)}"
                    if source.source_excerpt
                    else ""
                )
            )
    lines.append("")
    return "\n".join(lines)


def candidate_score(
    content: str,
    meta: dict[str, Any],
    tokens: list[str],
    phrases: list[str],
) -> float:
    lowered = memory_body(content).lower()
    score = 0.0
    unique_hits = 0
    for token in tokens:
        count = lowered.count(token)
        if count:
            unique_hits += 1
            score += min(count, 3) * (1.0 + min(len(token), 12) / 12)
    for phrase in phrases:
        if phrase in lowered:
            score += 3.25
    if int(meta.get("chunk_index") or 0) == 1 and unique_hits < 3:
        score -= 2.0
    return score


def profile_blocks(content: str) -> list[str]:
    out: list[str] = []
    for _turn_index, role, text in turn_blocks(content):
        if role == "SYSTEM":
            out.append(text)
    return out


def turn_blocks(content: str) -> list[tuple[int, str, str]]:
    matches = list(
        re.finditer(
            r"\[(SYSTEM|USER|ASSISTANT)\]\s*(.*?)(?=\n\n\[(?:SYSTEM|USER|ASSISTANT)\]|\Z)",
            str(content),
            re.S,
        )
    )
    blocks: list[tuple[int, str, str]] = []
    for index, match in enumerate(matches):
        text = match.group(2).strip()
        if text:
            blocks.append((index, match.group(1), text))
    return blocks


def snippet_score(
    text: str,
    role: str,
    tokens: list[str],
    phrases: list[str],
    intent: str,
) -> float:
    lowered = text.lower()
    score = 0.0
    for token in tokens:
        count = lowered.count(token)
        if count:
            score += min(count, 3) * (0.85 + min(len(token), 12) / 14)
    for phrase in phrases:
        if phrase in lowered:
            score += 4.0
    if intent == "reason_update":
        score += role_prior(role, system=1.0, user=2.4, assistant=0.25)
        score += keyword_score(
            lowered,
            (
                "because",
                "reason",
                "motivated",
                "motivation",
                "positive feedback",
                "feedback",
                "peers",
                "change of heart",
                "decided",
                "realized",
            ),
            2.2,
        )
    elif intent == "suggestion":
        score += role_prior(role, system=1.5, user=3.2, assistant=0.15)
        score += keyword_score(
            lowered,
            (
                "consider",
                "artist's intention",
                "audience",
                "context",
                "focus",
                "explore",
                "experiment",
                "try",
                "technique",
                "genre",
                "style",
                "production",
                "hands-on",
                "course",
                "writing",
                "review",
                "blog",
                "podcast",
                "storytelling",
                "perform",
                "creative",
                "reflect",
                "emotion",
                "connect",
                "external pressures",
                "simply enjoying",
                "listener perspectives",
                "workshop",
            ),
            1.25,
        )
        if any(
            marker in lowered
            for marker in (
                "too time-consuming",
                "didn't stick",
                "less engaged",
                "stifled",
                "stressful",
                "not really the ideal fit",
                "don't enjoy",
                "discontinued",
            )
        ):
            score -= 2.0
        if role == "ASSISTANT":
            score *= 0.65
    elif intent == "shared_fact":
        score += role_prior(role, system=1.8, user=2.5, assistant=0.2)
        score += keyword_score(
            lowered,
            (
                "like producing",
                "music production",
                "software",
                "modern beats",
                "pacific sounds",
                "remix",
                "project",
            ),
            1.7,
        )
    else:
        score += role_prior(role, system=1.2, user=0.8, assistant=0.35)
    return score


def role_prior(role: str, *, system: float, user: float, assistant: float) -> float:
    if role == "SYSTEM":
        return system
    if role == "USER":
        return user
    return assistant


def keyword_score(text: str, keywords: tuple[str, ...], weight: float) -> float:
    score = 0.0
    for keyword in keywords:
        if keyword in text:
            score += weight
    return score


def query_intent(query: str) -> str:
    lowered = retrieval_query_text(query).lower()
    if any(
        marker in lowered
        for marker in (
            "decided i don't",
            "why",
            "reason",
            "behind",
            "previously",
            "change of heart",
            "anymore",
        )
    ):
        return "reason_update"
    if any(
        marker in lowered
        for marker in (
            "suggest",
            "recommend",
            "recommendations",
            "ideas",
            "tips",
            "new ways",
            "what should i focus",
            "what would you recommend",
            "how can i",
            "new creative",
        )
    ):
        return "suggestion"
    if any(
        marker in lowered
        for marker in (
            "recently attended",
            "recently revisited",
            "recall",
            "remember",
        )
    ):
        return "shared_fact"
    return "general"


def dedupe_snippets(snippets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    fingerprints: set[str] = set()
    for item in snippets:
        text = str(item.get("text") or "")
        fingerprint = re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()[:180]
        if not fingerprint or fingerprint in fingerprints:
            continue
        fingerprints.add(fingerprint)
        selected.append(item)
    return selected


def dedupe_texts(items: list[str]) -> list[str]:
    selected: list[str] = []
    fingerprints: set[str] = set()
    for item in items:
        text = re.sub(r"\s+", " ", item).strip()
        fingerprint = re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()[:160]
        if not fingerprint or fingerprint in fingerprints:
            continue
        fingerprints.add(fingerprint)
        selected.append(text)
    return selected


def clean_snippet(text: str, *, limit: int) -> str:
    cleaned = re.sub(r"\s+", " ", str(text)).strip()
    if len(cleaned) <= limit:
        return cleaned
    cut = cleaned[:limit].rsplit(" ", 1)[0].rstrip(" ,;:")
    return cut + "..."


def query_without_user_label(query: str) -> str:
    text = str(query)
    same_line = re.match(r"^\s*user:\s*(.+)\s*$", text, re.I | re.S)
    if same_line:
        return same_line.group(1).strip() or query
    lines = text.splitlines()
    if lines and lines[0].strip().lower().startswith("user:"):
        stripped = "\n".join(lines[1:]).strip()
        return stripped or query
    return query


def retrieval_query_text(query: str) -> str:
    """Return the user request without multiple-choice answer options."""

    cleaned = query_without_user_label(_strip_benchmark_metadata(query))
    without_options = re.split(r"\n\s*\([a-z]\)\s+", cleaned, maxsplit=1)[0]
    return without_options.strip() or cleaned


def _strip_benchmark_metadata(query: str) -> str:
    """Remove adapter-provided benchmark metadata from the visible user query."""

    return _AMB_QUESTION_TYPE_RE.sub("", str(query), count=1).lstrip()


def memory_body(content: str) -> str:
    text = str(content)
    first_user = text.find("[USER]")
    if first_user >= 0:
        return text[first_user:]
    return text


def important_tokens(query: str) -> list[str]:
    option_text = " ".join(option for _letter, option in answer_options(query))
    query_tokens = _important_tokens_from_text(retrieval_query_text(query))
    option_tokens = _important_tokens_from_text(option_text)
    if benchmark_question_type(query) != "track_full_preference_evolution":
        return query_tokens[:48]
    tokens: list[str] = []
    seen: set[str] = set()
    option_budget = 28 if option_tokens else 0
    for token in option_tokens[:option_budget]:
        if token in seen:
            continue
        seen.add(token)
        tokens.append(token)
    for token in query_tokens:
        if token in seen:
            continue
        seen.add(token)
        tokens.append(token)
    return tokens[:48]


def _important_tokens_from_text(text: str) -> list[str]:
    raw = re.findall(r"[A-Za-z][A-Za-z0-9']{2,}", str(text).lower())
    tokens: list[str] = []
    seen: set[str] = set()
    for token in raw:
        normalized = token.strip("'")
        for variant in token_variants(normalized):
            if variant in _STOPWORDS or variant in seen:
                continue
            seen.add(variant)
            tokens.append(variant)
    return tokens


def token_variants(token: str) -> list[str]:
    variants = [token]
    if len(token) > 5 and token.endswith("ing"):
        base = token[:-3]
        variants.append(base)
        if len(base) > 2 and base[-1] == base[-2]:
            variants.append(base[:-1])
    if len(token) > 4 and token.endswith("ies"):
        variants.append(token[:-3] + "y")
    elif len(token) > 4 and token.endswith("s"):
        variants.append(token[:-1])
    return variants


def important_phrases(tokens: list[str]) -> list[str]:
    phrases: list[str] = []
    for size in (3, 2):
        for index in range(0, max(len(tokens) - size + 1, 0)):
            phrase = " ".join(tokens[index : index + size])
            if len(phrase) >= 9:
                phrases.append(phrase)
    return phrases[:40]


def is_at_or_before(
    document_timestamp: object,
    query_timestamp: str | None,
) -> bool:
    if query_timestamp is None or document_timestamp in (None, ""):
        return True
    return str(document_timestamp) <= str(query_timestamp)
