"""Group/global reduction and packet evidence rendering for document compaction."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from ._adversarial import scan_text
from ._context_engine import ContextBuildRequest, select_engineered_context
from ._context_render import render_context_decision_section
from ._context_sources import ContextSource
from ._doc_cache import (
    GLOBAL_REDUCE_PROMPT_VERSION,
    GROUP_REDUCE_PROMPT_VERSION,
    DocumentCompactionError,
    DocumentTextModel,
    _prompt,
    _render_prompt,
)
from ._doc_extractor import (
    _candidate_text,
    _line_ranges,
    _parse_candidate,
    _redact_value,
    _schema_errors,
)
from ._doc_normalizers import (
    _normalize_global_reducer_shorthand,
    _normalize_group_reducer_shorthand,
    _supporting_chunks_for_lines,
    _topic_terms,
)
from ._large_doc import slice_large_document
from ._redaction import Redactor
from ._text_model import TextModelError

_MAX_EVIDENCE_LINES_PER_CLAIM = 12
GROUP_REDUCE_MAX_TOKENS = 4096
GLOBAL_REDUCE_MAX_TOKENS = 4096
_EVIDENCE_FIELDS = (
    "claims",
    "contradictions",
    "decisions",
    "constraints",
    "revocations",
    "candidate_answer_fragments",
    "adversarial_flags",
    "verified_quotes",
)


def _summary_has_evidence(summary: dict[str, Any]) -> bool:
    if float(summary.get("task_relevance", 0.0)) > 0.0:
        return True
    for field in _EVIDENCE_FIELDS:
        value = summary.get(field)
        if isinstance(value, list) and value:
            return True
    return False

def _merge_source_items(summaries: list[dict[str, Any]], field: str, *, limit: int = 80) -> list[dict[str, Any]]:
    seen: set[tuple[str, tuple[int, int]]] = set()
    out: list[dict[str, Any]] = []
    for summary in summaries:
        raw = summary.get(field)
        if not isinstance(raw, list):
            continue
        for item in raw:
            if not isinstance(item, dict):
                continue
            lines = item.get("source_lines")
            if not isinstance(lines, list) or len(lines) != 2:
                continue
            text = str(item.get("text") or item.get("quote") or item.get("kind") or "").strip()
            if not text:
                continue
            key = (text.lower(), (int(lines[0]), int(lines[1])))
            if key in seen:
                continue
            seen.add(key)
            if field == "verified_quotes":
                out.append({"quote": str(item.get("quote") or text), "source_lines": lines})
            elif field == "adversarial_flags":
                out.append({"kind": str(item.get("kind") or text), "source_lines": lines})
            elif field == "candidate_answer_fragments":
                out.append(
                    {
                        "text": text,
                        "source_lines": lines,
                        "confidence": float(item.get("confidence", 0.5)),
                    }
                )
            else:
                out.append({"text": text, "source_lines": lines})
            if len(out) >= limit:
                return out
    return out

def _mechanical_group_summaries(
    chunk_summaries: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    if not chunk_summaries:
        return []
    topic_to_chunks: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for summary in chunk_summaries:
        terms = _topic_terms(summary) or {"general"}
        for term in sorted(terms):
            topic_to_chunks[term].append(summary)
    ranked = Counter({term: len(items) for term, items in topic_to_chunks.items()})
    groups: list[dict[str, Any]] = []
    used: set[str] = set()
    for idx, (topic, _) in enumerate(ranked.most_common(12), start=1):
        members = [
            item
            for item in topic_to_chunks[topic]
            if str(item.get("chunk_id") or "") not in used
        ]
        if not members:
            continue
        for member in members:
            used.add(str(member.get("chunk_id") or ""))
        lines = [
            int(line)
            for member in members
            for line in (member.get("line_start"), member.get("line_end"))
            if isinstance(line, int)
        ]
        supporting = [str(member.get("chunk_id")) for member in members]
        groups.append(
            {
                "doc_id": str(members[0].get("doc_id") or ""),
                "source_hash": str(members[0].get("source_hash") or ""),
                "group_id": f"group_{idx:03d}_{topic[:40]}",
                "supporting_chunk_ids": supporting,
                "line_start": min(lines) if lines else 1,
                "line_end": max(lines) if lines else 1,
                "task_relevance": max(
                    float(member.get("task_relevance", 0.0)) for member in members
                ),
                "claims": _merge_source_items(members, "claims"),
                "contradictions": _merge_source_items(members, "contradictions"),
                "decisions": _merge_source_items(members, "decisions"),
                "constraints": _merge_source_items(members, "constraints"),
                "revocations": _merge_source_items(members, "revocations"),
                "candidate_answer_fragments": _merge_source_items(
                    members, "candidate_answer_fragments"
                ),
                "adversarial_flags": _merge_source_items(members, "adversarial_flags"),
                "verified_quotes": _merge_source_items(members, "verified_quotes"),
                "topics": sorted({topic, *[t for m in members for t in m.get("topics", []) if isinstance(t, str)]})[:40],
                "entities": sorted({e for m in members for e in m.get("entities", []) if isinstance(e, str)})[:40],
            }
        )
    leftovers = [
        item for item in chunk_summaries if str(item.get("chunk_id") or "") not in used
    ]
    if leftovers:
        lines = [
            int(line)
            for member in leftovers
            for line in (member.get("line_start"), member.get("line_end"))
            if isinstance(line, int)
        ]
        groups.append(
            {
                "doc_id": str(leftovers[0].get("doc_id") or ""),
                "source_hash": str(leftovers[0].get("source_hash") or ""),
                "group_id": "group_misc",
                "supporting_chunk_ids": [str(member.get("chunk_id")) for member in leftovers],
                "line_start": min(lines) if lines else 1,
                "line_end": max(lines) if lines else 1,
                "task_relevance": max(float(member.get("task_relevance", 0.0)) for member in leftovers),
                "claims": _merge_source_items(leftovers, "claims"),
                "contradictions": _merge_source_items(leftovers, "contradictions"),
                "decisions": _merge_source_items(leftovers, "decisions"),
                "constraints": _merge_source_items(leftovers, "constraints"),
                "revocations": _merge_source_items(leftovers, "revocations"),
                "candidate_answer_fragments": _merge_source_items(
                    leftovers, "candidate_answer_fragments"
                ),
                "adversarial_flags": _merge_source_items(leftovers, "adversarial_flags"),
                "verified_quotes": _merge_source_items(leftovers, "verified_quotes"),
                "topics": sorted({t for m in leftovers for t in m.get("topics", []) if isinstance(t, str)})[:40],
                "entities": sorted({e for m in leftovers for e in m.get("entities", []) if isinstance(e, str)})[:40],
            }
        )
    return groups

def _mechanical_global_summary(
    groups: list[dict[str, Any]], *, doc_id: str, source_hash: str, line_count: int
) -> dict[str, Any]:
    claims = _merge_source_items(groups, "claims", limit=120)
    fragments = _merge_source_items(groups, "candidate_answer_fragments", limit=120)
    verified_quotes = _merge_source_items(groups, "verified_quotes", limit=80)
    verified_quote_refs = _verified_quote_refs(verified_quotes)
    answer_claims: list[dict[str, Any]] = []
    for item in [*fragments, *claims]:
        text = str(item.get("text") or "").strip()
        lines = item.get("source_lines")
        if not text or not isinstance(lines, list) or len(lines) != 2:
            continue
        answer_claims.append(
            {
                "text": text,
                "source_lines": lines,
                "supporting_chunk_ids": _supporting_chunks_for_lines(groups, lines),
                "confidence": float(item.get("confidence", 0.75)),
                "support_type": _mechanical_support_type(text, lines, verified_quote_refs),
            }
        )
        if len(answer_claims) >= 60:
            break
    if not answer_claims and claims:
        for item in claims[:20]:
            text = str(item["text"])
            lines = item["source_lines"]
            answer_claims.append(
                {
                    "text": text,
                    "source_lines": lines,
                    "supporting_chunk_ids": _supporting_chunks_for_lines(
                        groups, lines
                    ),
                    "confidence": 0.6,
                    "support_type": _mechanical_support_type(
                        text,
                        lines,
                        verified_quote_refs,
                    ),
                }
            )
    return {
        "doc_id": doc_id,
        "source_hash": source_hash,
        "line_start": 1,
        "line_end": max(1, line_count),
        "task_relevance": max([float(g.get("task_relevance", 0.0)) for g in groups] or [0.0]),
        "claims": claims,
        "contradictions": _merge_source_items(groups, "contradictions", limit=80),
        "decisions": _merge_source_items(groups, "decisions", limit=80),
        "constraints": _merge_source_items(groups, "constraints", limit=80),
        "revocations": _merge_source_items(groups, "revocations", limit=80),
        "candidate_answer_fragments": fragments,
        "adversarial_flags": _merge_source_items(groups, "adversarial_flags", limit=80),
        "verified_quotes": verified_quotes,
        "topics": sorted({t for g in groups for t in g.get("topics", []) if isinstance(t, str)})[:80],
        "entities": sorted({e for g in groups for e in g.get("entities", []) if isinstance(e, str)})[:80],
        "answer_affecting_claims": answer_claims,
    }

def _verified_quote_refs(items: list[dict[str, Any]]) -> set[tuple[str, int, int]]:
    refs: set[tuple[str, int, int]] = set()
    for item in items:
        quote = str(item.get("quote") or item.get("text") or "").strip()
        lines = item.get("source_lines")
        if not quote or not isinstance(lines, list) or len(lines) != 2:
            continue
        refs.add((quote, int(lines[0]), int(lines[1])))
    return refs

def _mechanical_support_type(
    text: str,
    lines: list[Any],
    verified_quote_refs: set[tuple[str, int, int]],
) -> str:
    if (
        isinstance(lines, list)
        and len(lines) == 2
        and (text.strip(), int(lines[0]), int(lines[1])) in verified_quote_refs
    ):
        return "verified_quote"
    return "summary_only"

def _validate_reducer_candidate(
    *,
    schema_name: str,
    candidate: dict[str, Any],
    line_start: int,
    line_end: int,
) -> None:
    errors = _schema_errors(schema_name, candidate)
    if errors:
        raise DocumentCompactionError("; ".join(errors))
    for label, source_lines in _line_ranges(candidate):
        if len(source_lines) != 2:
            raise DocumentCompactionError(f"{label}.source_lines must be [start,end]")
        start, end = int(source_lines[0]), int(source_lines[1])
        if start < line_start or end > line_end or start > end:
            raise DocumentCompactionError(
                f"{label}.source_lines {start}-{end} outside {line_start}-{line_end}"
            )
    findings = scan_text(
        f"{schema_name}_candidate",
        _candidate_text(candidate),
        source_id=str(candidate.get("group_id") or candidate.get("doc_id") or ""),
        trusted_tool_result=False,
    )
    if findings:
        issues = ", ".join(str(getattr(item, "issue", "")) for item in findings)
        raise DocumentCompactionError(f"adversarial reducer output: {issues}")

def _reduce_one_group_with_model(
    *,
    model: DocumentTextModel,
    task: str,
    group: dict[str, Any],
    chunk_summaries_by_id: dict[str, dict[str, Any]],
    redactor: Redactor,
) -> dict[str, Any]:
    chunk_summaries = [
        chunk_summaries_by_id[chunk_id]
        for chunk_id in group.get("supporting_chunk_ids", [])
        if isinstance(chunk_id, str) and chunk_id in chunk_summaries_by_id
    ]
    summaries_json = json.dumps(
        chunk_summaries or [group],
        indent=2,
        sort_keys=True,
    )
    context_sources = [
        ContextSource(
            id="group_reduce_task",
            title="Group Reduce Task",
            source_type="current_question",
            authority="current_user",
            freshness="live",
            content=f"Task:\n{task.strip()}\n",
            mandatory=True,
            reason="The user task defines relevance for group reduction.",
            budget_group="task",
        ),
        ContextSource(
            id="validated_chunk_summaries",
            title="Validated Chunk Summaries",
            source_type="deep_evidence",
            authority="source_evidence",
            freshness="current",
            content=summaries_json,
            mandatory=True,
            reason="Only validated chunk summaries may support group claims.",
            budget_group="deep_evidence",
        ),
    ]
    intent, selection = select_engineered_context(
        ContextBuildRequest(
            question=task,
            token_cap=sum(source.token_count for source in context_sources),
        ),
        context_sources,
    )
    prompt = _render_prompt(
        _prompt(GROUP_REDUCE_PROMPT_VERSION),
        {
            "context_engineering": render_context_decision_section(
                question=task,
                workspace_query=None,
                intent=intent,
                selection=selection,
            ),
            "task": task,
            "chunk_summaries": summaries_json,
        },
    )
    candidate = _parse_candidate(
        model.complete(
            prompt,
            system="Return only valid JSON for Remaind group_summary_v1.",
            json_mode=True,
            max_tokens=GROUP_REDUCE_MAX_TOKENS,
        ),
        schema_name="group_summary_v1",
    )
    try:
        _validate_reducer_candidate(
            schema_name="group_summary_v1",
            candidate=candidate,
            line_start=int(group.get("line_start", 1)),
            line_end=int(group.get("line_end", 1)),
        )
    except DocumentCompactionError:
        normalized = _normalize_group_reducer_shorthand(candidate, group=group)
        if normalized is None:
            raise
        candidate = normalized
        _validate_reducer_candidate(
            schema_name="group_summary_v1",
            candidate=candidate,
            line_start=int(group.get("line_start", 1)),
            line_end=int(group.get("line_end", 1)),
        )
    redacted = _redact_value(candidate, redactor)
    if not isinstance(redacted, dict):
        raise DocumentCompactionError("group reducer redaction produced non-object")
    return redacted

def _reduce_groups(
    *,
    model: DocumentTextModel,
    task: str,
    chunk_summaries: list[dict[str, Any]],
    redactor: Redactor,
) -> tuple[list[dict[str, Any]], list[str]]:
    evidence_summaries = [
        summary for summary in chunk_summaries if _summary_has_evidence(summary)
    ]
    mechanical = _mechanical_group_summaries(evidence_summaries)
    if len(evidence_summaries) <= 1:
        return mechanical, []
    by_id = {
        str(summary.get("chunk_id")): summary
        for summary in evidence_summaries
        if summary.get("chunk_id")
    }
    reduced: list[dict[str, Any]] = []
    fallbacks: list[str] = []
    for group in mechanical:
        try:
            reduced.append(
                _reduce_one_group_with_model(
                    model=model,
                    task=task,
                    group=group,
                    chunk_summaries_by_id=by_id,
                    redactor=redactor,
                )
            )
        except (DocumentCompactionError, TextModelError) as exc:
            fallbacks.append(f"{group.get('group_id')}: {exc}")
            reduced.append(group)
    return reduced, fallbacks

def _reduce_global(
    *,
    model: DocumentTextModel,
    task: str,
    groups: list[dict[str, Any]],
    doc_id: str,
    source_hash: str,
    line_count: int,
    redactor: Redactor,
) -> tuple[dict[str, Any], list[str]]:
    mechanical = _mechanical_global_summary(
        groups,
        doc_id=doc_id,
        source_hash=source_hash,
        line_count=line_count,
    )
    if not groups:
        return mechanical, []
    if len(groups) == 1:
        supporting = groups[0].get("supporting_chunk_ids")
        if isinstance(supporting, list) and len(supporting) <= 1:
            return mechanical, []
    groups_json = json.dumps(groups, indent=2, sort_keys=True)
    context_sources = [
        ContextSource(
            id="global_reduce_task",
            title="Global Reduce Task",
            source_type="current_question",
            authority="current_user",
            freshness="live",
            content=f"Task:\n{task.strip()}\n",
            mandatory=True,
            reason="The user task defines answer-affecting claims for global reduction.",
            budget_group="task",
        ),
        ContextSource(
            id="validated_group_summaries",
            title="Validated Group Summaries",
            source_type="deep_evidence",
            authority="source_evidence",
            freshness="current",
            content=groups_json,
            mandatory=True,
            reason="Only validated group summaries may support global claims.",
            budget_group="deep_evidence",
        ),
    ]
    intent, selection = select_engineered_context(
        ContextBuildRequest(
            question=task,
            token_cap=sum(source.token_count for source in context_sources),
        ),
        context_sources,
    )
    prompt = _render_prompt(
        _prompt(GLOBAL_REDUCE_PROMPT_VERSION),
        {
            "context_engineering": render_context_decision_section(
                question=task,
                workspace_query=None,
                intent=intent,
                selection=selection,
            ),
            "task": task,
            "group_summaries": groups_json,
        },
    )
    try:
        candidate = _parse_candidate(
            model.complete(
                prompt,
                system="Return only valid JSON for Remaind global_summary_v1.",
                json_mode=True,
                max_tokens=GLOBAL_REDUCE_MAX_TOKENS,
            ),
            schema_name="global_summary_v1",
        )
        try:
            _validate_reducer_candidate(
                schema_name="global_summary_v1",
                candidate=candidate,
                line_start=1,
                line_end=max(1, line_count),
            )
        except DocumentCompactionError:
            normalized = _normalize_global_reducer_shorthand(
                candidate,
                mechanical=mechanical,
                groups=groups,
            )
            if normalized is None:
                raise
            candidate = normalized
            _validate_reducer_candidate(
                schema_name="global_summary_v1",
                candidate=candidate,
                line_start=1,
                line_end=max(1, line_count),
            )
        redacted = _redact_value(candidate, redactor)
        if not isinstance(redacted, dict):
            raise DocumentCompactionError("global reducer redaction produced non-object")
        return redacted, []
    except (DocumentCompactionError, TextModelError) as exc:
        return mechanical, [f"global: {exc}"]

def _validate_group_and_global(groups: list[dict[str, Any]], global_summary: dict[str, Any]) -> None:
    for group in groups:
        errors = _schema_errors("group_summary_v1", group)
        if errors:
            raise DocumentCompactionError("group summary failed schema: " + "; ".join(errors))
    errors = _schema_errors("global_summary_v1", global_summary)
    if errors:
        raise DocumentCompactionError("global summary failed schema: " + "; ".join(errors))

def _format_claim(item: dict[str, Any]) -> str:
    lines = item.get("source_lines")
    line_label = f"lines {lines[0]}-{lines[1]}" if isinstance(lines, list) and len(lines) == 2 else "lines ?"
    text = str(item.get("text") or item.get("quote") or item.get("kind") or "").strip()
    return f"- {text} ({line_label})"

def build_evidence_block(
    *,
    document_path: Path,
    global_summary: dict[str, Any],
    failures: list[dict[str, Any]],
    quarantined: list[dict[str, Any]],
    reducer_fallbacks: list[str] | None = None,
) -> str:
    rows: list[str] = ["## Deep Compaction Summary"]
    claims = global_summary.get("claims") if isinstance(global_summary, dict) else []
    if isinstance(claims, list) and claims:
        rows.extend(_format_claim(item) for item in claims[:20] if isinstance(item, dict))
    else:
        rows.append("- No source-linked claims were produced.")

    rows.append("\n## Source-Linked Claims")
    answer_claims = global_summary.get("answer_affecting_claims")
    if isinstance(answer_claims, list) and answer_claims:
        emitted_claims: set[tuple[str, int, int, str]] = set()
        for claim in answer_claims[:40]:
            if not isinstance(claim, dict):
                continue
            support = str(claim.get("support_type") or "summary_only")
            lines = claim.get("source_lines")
            if isinstance(lines, list) and len(lines) == 2:
                key = (str(claim.get("text") or ""), int(lines[0]), int(lines[1]), support)
                if key in emitted_claims:
                    continue
                emitted_claims.add(key)
            rows.append(f"{_format_claim(claim)} [support: {support}]")
    else:
        rows.append("- No answer-affecting claims were produced.")

    rows.append("\n## Contradictions / Revocations")
    surfaced = 0
    for field in ("contradictions", "revocations"):
        items = global_summary.get(field)
        if isinstance(items, list):
            for item in items[:20]:
                if isinstance(item, dict):
                    rows.append(_format_claim(item))
                    surfaced += 1
    if surfaced == 0:
        rows.append("- None surfaced.")

    rows.append("\n## Exact Evidence Lines")
    emitted_ranges: set[tuple[int, int]] = set()
    if isinstance(answer_claims, list):
        for claim in answer_claims[:40]:
            if not isinstance(claim, dict):
                continue
            support = str(claim.get("support_type") or "summary_only")
            lines = claim.get("source_lines")
            if support == "summary_only" or not isinstance(lines, list) or len(lines) != 2:
                rows.append(f"- summary_only: {str(claim.get('text') or '').strip()}")
                continue
            start, end = int(lines[0]), int(lines[1])
            if end - start + 1 > _MAX_EVIDENCE_LINES_PER_CLAIM:
                end = start + _MAX_EVIDENCE_LINES_PER_CLAIM - 1
            if (start, end) in emitted_ranges:
                continue
            emitted_ranges.add((start, end))
            result = slice_large_document(document_path, start=start, end=end)
            rows.append(f"### Evidence lines {start}-{end}")
            for row in result.lines:
                rows.append(f"{row['line']}: {row['text']}")

    rows.append("\n## Omitted or Failed Chunks")
    reducer_fallbacks = reducer_fallbacks or []
    if not failures and not quarantined and not reducer_fallbacks:
        rows.append("- None.")
    for failure in failures[:50]:
        rows.append(
            "- failed "
            f"{failure.get('chunk_id')} lines {failure.get('line_start')}-"
            f"{failure.get('line_end')}: {failure.get('stage')} "
            f"({failure.get('reason')})"
        )
    for item in quarantined[:50]:
        rows.append(
            "- quarantined "
            f"{item.get('chunk_id')} lines {item.get('line_start')}-"
            f"{item.get('line_end')}: {', '.join(item.get('finding_kinds') or [])}"
        )
    for fallback in reducer_fallbacks[:20]:
        rows.append(f"- reducer fallback: {fallback}")
    return "\n".join(rows).strip()
