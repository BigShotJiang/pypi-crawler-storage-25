"""`remaind` CLI dispatcher.

Subcommands resolved in Phase 3: ``init``, ``validate``. Later phases add
``status``, ``compact``, ``resume``, ``rollback``, ``doctor``, ``monitor``.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__
from ._cwd import safe_cwd
from ._local_compactor import CompactorResponseError
from .commands import bench as bench_cmd
from .commands import compact as compact_cmd
from .commands import continuity as continuity_cmd
from .commands import daemon as daemon_cmd
from .commands import doctor as doctor_cmd
from .commands import init as init_cmd
from .commands import large_doc as large_doc_cmd
from .commands import launch as launch_cmd
from .commands import memory as memory_cmd
from .commands import monitor as monitor_cmd
from .commands import public_bench as public_bench_cmd
from .commands import resume as resume_cmd
from .commands import rollback as rollback_cmd
from .commands import run as run_cmd
from .commands import status as status_cmd
from .commands import validate as validate_cmd


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="remaind",
        description="Durable context for long-running agents.",
    )
    parser.add_argument(
        "--version", action="version", version=f"remaind {__version__}"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="bootstrap a .context/ directory")
    p_init.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_init.add_argument(
        "--force",
        action="store_true",
        help="back up existing .context/ before reinitializing",
    )

    p_val = sub.add_parser(
        "validate", help="verify .context/ is well-formed"
    )
    p_val.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )

    p_compact = sub.add_parser(
        "compact",
        help="run manual compaction (uses a local model if one is running)",
    )
    p_compact.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )

    p_resume = sub.add_parser(
        "resume", help="build a fresh-context resume packet"
    )
    p_resume.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_resume.add_argument(
        "--next-tool",
        dest="next_tool",
        default=None,
        help="tool the agent plans to call next; consults tools.yaml for risk",
    )
    p_resume.add_argument(
        "--memories",
        dest="k_memories",
        type=int,
        default=5,
        help="max memories to include via FTS retrieval",
    )
    p_resume.add_argument(
        "--excerpts",
        dest="raw_excerpt_count",
        type=int,
        default=20,
        help="max raw-log excerpts to include",
    )

    p_rollback = sub.add_parser(
        "rollback", help="restore derived files from history"
    )
    p_rollback.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_rollback.add_argument(
        "--to",
        dest="target",
        required=True,
        help="target timestamp (filename-safe like 20260514T035433Z or ISO 8601)",
    )

    p_status = sub.add_parser(
        "status", help="summarize the current context state"
    )
    p_status.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_status.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_doctor = sub.add_parser(
        "doctor",
        help="run a read-only health check for context + local model runtime",
    )
    p_doctor.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_doctor.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )
    p_doctor.add_argument(
        "--smoke",
        action="store_true",
        help="run a tiny real generation check against the detected local model",
    )

    p_monitor = sub.add_parser(
        "monitor",
        help="run scheduler-friendly health checks and emit alerts",
    )
    p_monitor.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory (default: current working directory)",
    )
    p_monitor.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )
    p_monitor.add_argument(
        "--smoke",
        action="store_true",
        help="include the doctor local-model generation smoke test",
    )
    p_monitor.add_argument(
        "--large-doc",
        dest="large_docs",
        action="append",
        default=[],
        help=(
            "large document path or doc_id to inspect; repeatable. "
            "If omitted, all registered large documents are inspected."
        ),
    )

    p_launch = sub.add_parser(
        "launch",
        help="activate Remaind memory, prove runtime readiness, then start",
    )
    p_launch.add_argument(
        "--path",
        type=Path,
        default=None,
        help="project folder to prepare (default: ask, or current folder in scripts)",
    )
    p_launch.add_argument(
        "--project",
        dest="workspace_query",
        help=(
            "product/workspace name to find in existing Remaind memory "
            "(folder names, state, handover, and recent events)"
        ),
    )
    p_launch.add_argument(
        "--runtime",
        choices=["auto", "ollama", "openai-compatible", "fallback"],
        default="auto",
        help="runtime to use after memory is active",
    )
    p_launch.add_argument(
        "--model",
        help="model name to select from the chosen runtime",
    )
    p_launch.add_argument(
        "--yolo-model",
        action="store_true",
        help=(
            "allow a manually named local model to continue without a launch "
            "smoke test"
        ),
    )
    p_launch.add_argument(
        "--input",
        dest="input_mode",
        choices=["ask", "paste", "file", "resume", "handover", "empty"],
        default=None,
        help="start mode after readiness passes",
    )
    p_launch.add_argument(
        "--file",
        type=Path,
        help="file to process when --input file is used",
    )
    p_launch.add_argument(
        "--task",
        help=(
            "question for ask mode or task for file/paste mode; file/paste "
            "defaults to following the supplied prompt"
        ),
    )
    p_launch.add_argument(
        "--token-cap",
        type=int,
        default=None,
        help="approximate token cap for file/paste evidence packets",
    )
    p_launch.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default=os.environ.get("REMAIND_MEMORY_MODE", "turbo"),
        help=(
            "Remaind memory packet mode for any model "
            "(default: turbo; use deep for fuller memory)"
        ),
    )
    p_launch.add_argument(
        "--answer-key",
        type=Path,
        default=None,
        help=(
            "optional JSON answer key for file/paste mode; if omitted, "
            "Remaind auto-detects known answer-key filenames"
        ),
    )
    p_launch.add_argument(
        "--require-answer-key-pass",
        action="store_true",
        help="file/paste mode exits non-zero unless answer-key validation passes",
    )
    p_launch.add_argument(
        "--deep-compact",
        action="store_true",
        help="use hierarchical local-model document compaction for file/paste mode",
    )
    p_launch.add_argument(
        "--deep-compact-mode",
        choices=["lenient", "strict"],
        default="lenient",
        help="deep-compaction failure policy for file/paste mode",
    )
    p_launch.add_argument(
        "--reuse-deep-compact",
        action="store_true",
        help="reuse a matching deep-compaction cache for file/paste mode",
    )
    p_launch.add_argument(
        "--deep-compact-chunk-tokens",
        type=int,
        default=None,
        help=(
            "target tokens per deep-compaction extraction chunk for file/paste "
            "mode; lower values improve responsiveness on slower local models"
        ),
    )
    p_launch.add_argument(
        "--max-results",
        type=int,
        default=run_cmd.DEFAULT_MAX_RESULTS,
        help="maximum search hits per query in file/paste mode",
    )
    p_launch.add_argument(
        "--accept-fallback",
        action="store_true",
        help="allow packet-only fallback when no local model runtime is selected",
    )
    p_launch.add_argument(
        "--non-interactive",
        action="store_true",
        help="fail clearly instead of prompting for missing required values",
    )
    p_launch.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable launch report",
    )

    p_ask = sub.add_parser(
        "ask",
        help="ask the active Remaind memory in plain language",
    )
    p_ask.add_argument("question", nargs="*", help="question to ask from memory")
    p_ask.add_argument(
        "--path",
        type=Path,
        default=None,
        help="workspace folder (default: current folder or project lookup)",
    )
    p_ask.add_argument(
        "--project",
        dest="workspace_query",
        help="product/workspace name to find in existing Remaind memory",
    )
    p_ask.add_argument(
        "--runtime",
        choices=["auto", "ollama", "openai-compatible", "fallback"],
        default="auto",
        help="runtime to use for the answer",
    )
    p_ask.add_argument("--model", help="model name to select from the chosen runtime")
    p_ask.add_argument(
        "--yolo-model",
        action="store_true",
        help="allow a manually named local model without a launch smoke test",
    )
    p_ask.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default=os.environ.get("REMAIND_MEMORY_MODE", "turbo"),
        help="Remaind memory packet mode",
    )
    p_ask.add_argument(
        "--accept-fallback",
        action="store_true",
        help="allow packet-only fallback if no model runtime is available",
    )
    p_ask.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the terminal answer",
    )

    p_chat = sub.add_parser(
        "chat",
        help="stay inside an interactive Remaind memory chat",
    )
    p_chat.add_argument(
        "--path",
        type=Path,
        default=None,
        help="workspace folder (default: ask, or current folder in scripts)",
    )
    p_chat.add_argument(
        "--project",
        dest="workspace_query",
        help="product/workspace name to find in existing Remaind memory",
    )
    p_chat.add_argument(
        "--runtime",
        choices=["auto", "ollama", "openai-compatible", "fallback"],
        default="auto",
        help="runtime to use for answers",
    )
    p_chat.add_argument("--model", help="model name to select from the chosen runtime")
    p_chat.add_argument(
        "--yolo-model",
        action="store_true",
        help="allow a manually named local model without a launch smoke test",
    )
    p_chat.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default=os.environ.get("REMAIND_MEMORY_MODE", "turbo"),
        help="Remaind memory packet mode",
    )
    p_chat.add_argument(
        "--accept-fallback",
        action="store_true",
        help="allow packet-only fallback if no model runtime is available",
    )

    p_context = sub.add_parser(
        "context",
        help="inspect the engineered memory context before a model sees it",
    )
    context_sub = p_context.add_subparsers(dest="context_command", required=True)
    p_context_inspect = context_sub.add_parser(
        "inspect",
        help="build and print the memory context for a plain-language question",
    )
    p_context_inspect.add_argument(
        "question",
        nargs="*",
        help="question whose engineered context should be inspected",
    )
    p_context_inspect.add_argument(
        "--path",
        type=Path,
        default=None,
        help="workspace folder (default: current folder or project lookup)",
    )
    p_context_inspect.add_argument(
        "--project",
        dest="workspace_query",
        help="product/workspace name to find in existing Remaind memory",
    )
    p_context_inspect.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default=os.environ.get("REMAIND_MEMORY_MODE", "turbo"),
        help="Remaind memory packet mode",
    )
    p_context_inspect.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the Markdown context packet",
    )

    p_continuity = sub.add_parser(
        "continuity",
        help="inspect continuity scorecards, evidence, and cross-tool adapters",
    )
    continuity_sub = p_continuity.add_subparsers(
        dest="continuity_command",
        required=True,
    )
    p_continuity_scorecard = continuity_sub.add_parser(
        "scorecard",
        help="show current project-continuity metrics",
    )
    p_continuity_scorecard.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_continuity_scorecard.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable scorecard",
    )
    p_continuity_evidence = continuity_sub.add_parser(
        "evidence",
        help="show claim-to-source continuity evidence links",
    )
    p_continuity_evidence.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_continuity_evidence.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable evidence map",
    )
    p_continuity_export = continuity_sub.add_parser(
        "export",
        help="export Remaind continuity context for coding-agent tools",
    )
    p_continuity_export.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_continuity_export.add_argument(
        "--target",
        dest="targets",
        action="append",
        choices=[
            "all",
            "claude-code",
            "cursor",
            "windsurf",
            "codex",
            "qwen-code",
            "langgraph",
            "mcp",
        ],
        default=None,
        help="adapter target to write; repeatable; default: all",
    )
    p_continuity_export.add_argument(
        "--out",
        type=Path,
        default=None,
        help="output folder (default: .context/adapters)",
    )
    p_continuity_export.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable export report",
    )

    p_memory = sub.add_parser(
        "memory",
        help="agent-facing tools to update and inspect continuity memory",
    )
    memory_sub = p_memory.add_subparsers(dest="memory_command", required=True)
    p_memory_plan = memory_sub.add_parser("plan", help="show the current plan state")
    p_memory_plan.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_memory_block = memory_sub.add_parser(
        "block",
        help="mark a task blocked with the blocker that stopped it",
    )
    p_memory_block.add_argument("task", help="task that could not be completed")
    p_memory_block.add_argument(
        "--reason",
        required=True,
        help="specific error or blocker that stopped the task",
    )
    p_memory_block.add_argument(
        "--project",
        dest="workspace_query",
        default=None,
        help="product/workspace name for plan reconciliation",
    )
    p_memory_block.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_memory_block.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable result",
    )
    p_memory_decision = memory_sub.add_parser(
        "decision",
        help="record a durable decision",
    )
    p_memory_decision.add_argument("text", nargs="+", help="decision text")
    p_memory_decision.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_memory_decision.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable result",
    )
    p_memory_promote = memory_sub.add_parser(
        "promote",
        help="promote a fact or workflow note to durable memory",
    )
    p_memory_promote.add_argument("text", nargs="+", help="memory text")
    p_memory_promote.add_argument(
        "--rationale",
        default=None,
        help="why this should be durable",
    )
    p_memory_promote.add_argument(
        "--tag",
        dest="tags",
        action="append",
        default=[],
        help="tag for the promoted memory; repeatable",
    )
    p_memory_promote.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_memory_promote.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable result",
    )
    p_memory_changed = memory_sub.add_parser(
        "changed",
        help="show recent high-signal changes since the last session",
    )
    p_memory_changed.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="workspace folder (default: current working directory)",
    )
    p_memory_changed.add_argument(
        "--limit",
        type=int,
        default=12,
        help="maximum recent events to show",
    )

    p_daemon = sub.add_parser(
        "daemon",
        help="manage always-present local Remaind workspace presence",
    )
    daemon_sub = p_daemon.add_subparsers(dest="daemon_command", required=True)
    p_daemon_start = daemon_sub.add_parser("start", help="start the presence daemon")
    p_daemon_start.add_argument(
        "--interval",
        type=float,
        default=float(os.environ.get(daemon_cmd.DAEMON_INTERVAL_ENV, "30")),
        help="seconds between workspace index refreshes",
    )
    p_daemon_start.add_argument(
        "--foreground",
        action="store_true",
        help="run in the foreground instead of backgrounding",
    )
    daemon_sub.add_parser("stop", help="stop the presence daemon")
    p_daemon_run = daemon_sub.add_parser("run", help="run the daemon worker loop")
    p_daemon_run.add_argument(
        "--interval",
        type=float,
        default=float(os.environ.get(daemon_cmd.DAEMON_INTERVAL_ENV, "30")),
        help="seconds between workspace index refreshes",
    )
    p_daemon_run.add_argument(
        "--once",
        action="store_true",
        help="refresh the index once and exit",
    )
    p_daemon_status = daemon_sub.add_parser("status", help="show presence status")
    p_daemon_status.add_argument(
        "--cwd",
        type=Path,
        default=safe_cwd(),
        help="folder to check for active memory",
    )
    p_daemon_status.add_argument(
        "--short",
        action="store_true",
        help="only print the active-memory line for shell hooks",
    )
    p_daemon_status.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of human-readable status",
    )
    p_daemon_reindex = daemon_sub.add_parser(
        "reindex",
        help="refresh the workspace index now",
    )
    p_daemon_reindex.add_argument(
        "--cwd",
        type=Path,
        default=safe_cwd(),
        help="folder to use as the discovery starting point",
    )
    p_daemon_reindex.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of human-readable status",
    )
    p_daemon_observe = daemon_sub.add_parser(
        "observe",
        help="record privacy-safe shell activity for the active workspace",
    )
    p_daemon_observe.add_argument(
        "--cwd",
        type=Path,
        default=safe_cwd(),
        help="folder where the command ran",
    )
    p_daemon_observe.add_argument(
        "--command",
        dest="observed_command",
        required=True,
        help="command line to summarize; terminal output is never recorded",
    )
    p_daemon_observe.add_argument(
        "--exit-code",
        type=int,
        required=True,
        help="command exit code",
    )
    p_daemon_observe.add_argument(
        "--duration-ms",
        type=int,
        default=None,
        help="optional command duration in milliseconds",
    )
    p_daemon_observe.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of human-readable status",
    )
    p_shell = daemon_sub.add_parser(
        "shell-init",
        help="print a shell hook that announces active Remaind memory",
    )
    p_shell.add_argument(
        "--shell",
        choices=["zsh", "bash", "fish"],
        default="zsh",
        help="shell syntax to print",
    )
    p_install_shell = daemon_sub.add_parser(
        "install-shell-hook",
        help="install the presence hook into your shell startup file",
    )
    p_install_shell.add_argument(
        "--shell",
        choices=["zsh", "bash", "fish"],
        default="zsh",
        help="shell startup file syntax to install",
    )
    p_install_shell.add_argument(
        "--rc-file",
        type=Path,
        default=None,
        help="override the shell startup file path",
    )
    p_install_shell.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of human-readable status",
    )

    p_run = sub.add_parser(
        "run",
        help="run a task against a huge local prompt/document through Remaind",
    )
    p_run.add_argument("file", type=Path)
    p_run.add_argument("task", help="task to execute against the local file")
    p_run.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory for .context/ (default: current working directory)",
    )
    p_run.add_argument(
        "--title",
        help="human title to store in the manifest and memory pointer",
    )
    p_run.add_argument(
        "--query",
        dest="queries",
        action="append",
        default=[],
        help="extra search query to force into the evidence packet; repeatable",
    )
    p_run.add_argument(
        "--context",
        type=int,
        default=run_cmd.DEFAULT_CONTEXT_LINES,
        help="number of lines of context around each search hit",
    )
    p_run.add_argument(
        "--max-results",
        type=int,
        default=run_cmd.DEFAULT_MAX_RESULTS,
        help="maximum hits per generated search query",
    )
    p_run.add_argument(
        "--head-lines",
        type=int,
        default=run_cmd.DEFAULT_HEAD_LINES,
        help="number of document head lines to include as orientation",
    )
    p_run.add_argument(
        "--tail-lines",
        type=int,
        default=run_cmd.DEFAULT_TAIL_LINES,
        help="number of document tail lines to include as orientation",
    )
    p_run.add_argument(
        "--query-count",
        dest="query_count",
        type=int,
        default=run_cmd.DEFAULT_QUERY_COUNT,
        help="maximum number of generated/planned search queries",
    )
    p_run.add_argument(
        "--token-cap",
        type=int,
        default=None,
        help=(
            "approximate token cap for the compact evidence packet "
            "(default: product-standard bands from model context, fallback 24000)"
        ),
    )
    p_run.add_argument(
        "--answer-key",
        type=Path,
        default=None,
        help=(
            "optional JSON answer key; if omitted, Remaind auto-detects "
            "<file>_private_answer_key.json or <file>_answer_key.json"
        ),
    )
    p_run.add_argument(
        "--require-answer-key-pass",
        action="store_true",
        help="exit non-zero unless an answer key is found and validation passes",
    )
    p_run.add_argument(
        "--deep-compact",
        action="store_true",
        help="run hierarchical local-model document compaction before answering",
    )
    p_run.add_argument(
        "--deep-compact-mode",
        choices=["lenient", "strict"],
        default="lenient",
        help="deep-compaction failure policy (default: lenient)",
    )
    p_run.add_argument(
        "--reuse-deep-compact",
        action="store_true",
        help="reuse a matching deep-compaction cache if one exists",
    )
    p_run.add_argument(
        "--deep-compact-chunk-tokens",
        type=int,
        default=None,
        help=(
            "target tokens per deep-compaction extraction chunk; lower values "
            "improve responsiveness on slower local models"
        ),
    )
    p_run.add_argument(
        "--no-model",
        action="store_true",
        help="prepare the evidence packet without calling a local model",
    )
    p_run.add_argument(
        "--no-init",
        action="store_true",
        help="fail instead of initializing .context/ automatically",
    )
    p_run.add_argument(
        "--model",
        help="local model override for this run",
    )
    p_run.add_argument(
        "--ollama-host",
        help="Ollama host override for this run",
    )
    p_run.add_argument(
        "--ollama-api",
        choices=["auto", "chat", "generate"],
        help="Ollama API mode override for this run",
    )
    p_run.add_argument(
        "--openai-base-url",
        help="OpenAI-compatible local /v1 endpoint for this run",
    )
    p_run.add_argument(
        "--num-ctx",
        type=int,
        help="Ollama num_ctx override for this run",
    )
    p_run.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_bench = sub.add_parser("bench", help="run executable Remaind benchmarks")
    bench_sub = p_bench.add_subparsers(dest="bench_name", required=True)
    p_bench_sovereign = bench_sub.add_parser(
        "sovereign",
        help="prove beyond-context continuity, revocation, and adversarial handling",
    )
    p_bench_sovereign.add_argument(
        "--workdir",
        type=Path,
        default=bench_cmd.DEFAULT_WORKDIR,
        help=(
            "benchmark workspace "
            f"(default: {bench_cmd.DEFAULT_WORKDIR.as_posix()})"
        ),
    )
    p_bench_sovereign.add_argument(
        "--target-tokens",
        type=int,
        default=bench_cmd.DEFAULT_TARGET_TOKENS,
        help="approximate source archive size to generate",
    )
    p_bench_sovereign.add_argument(
        "--force",
        action="store_true",
        help="replace an existing benchmark .context/ in --workdir",
    )
    p_bench_sovereign.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )
    p_bench_continuity = bench_sub.add_parser(
        "continuity",
        help="prove project continuity across reset, blockers, stale answers, and rollback",
    )
    p_bench_continuity.add_argument(
        "--workdir",
        type=Path,
        default=bench_cmd.DEFAULT_CONTINUITY_WORKDIR,
        help=(
            "benchmark workspace "
            f"(default: {bench_cmd.DEFAULT_CONTINUITY_WORKDIR.as_posix()})"
        ),
    )
    p_bench_continuity.add_argument(
        "--force",
        action="store_true",
        help="replace an existing benchmark .context/ in --workdir",
    )
    p_bench_continuity.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_public_bench = sub.add_parser(
        "public-bench",
        help="prepare and verify Remaind adapters for public benchmarks",
    )
    public_bench_sub = p_public_bench.add_subparsers(
        dest="public_bench_name",
        required=True,
    )
    p_amb = public_bench_sub.add_parser(
        "amb",
        help="install Remaind as an Agent Memory Benchmark memory provider",
    )
    amb_sub = p_amb.add_subparsers(
        dest="amb_command",
        required=True,
    )
    p_amb_prepare = amb_sub.add_parser(
        "prepare",
        help="write the AMB provider adapter and patch AMB's provider registry",
    )
    p_amb_prepare.add_argument(
        "--amb-repo",
        type=Path,
        required=True,
        help="path to a local agent-memory-benchmark checkout",
    )
    p_amb_prepare.add_argument(
        "--remaind-source",
        type=Path,
        default=None,
        help=(
            "Remaind source path for AMB's Python environment "
            "(default: this installed/source package)"
        ),
    )
    p_amb_prepare.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )
    p_amb_report = amb_sub.add_parser(
        "report",
        help="summarize an AMB result file with category and evidence diagnostics",
    )
    p_amb_report.add_argument(
        "--result",
        type=Path,
        required=True,
        help="path to an AMB result JSON or JSON.GZ file",
    )
    p_amb_report.add_argument(
        "--format",
        dest="output_format",
        choices=["markdown", "json", "csv"],
        default="markdown",
        help="report output format",
    )
    p_amb_report.add_argument(
        "--output",
        type=Path,
        default=None,
        help="optional file to write the rendered report",
    )
    p_amb_taxonomy = amb_sub.add_parser(
        "taxonomy",
        help="write a scoped AMB failure taxonomy for review and phase tracking",
    )
    p_amb_taxonomy.add_argument(
        "--result",
        type=Path,
        required=True,
        help="path to an AMB result JSON or JSON.GZ file",
    )
    p_amb_taxonomy.add_argument(
        "--format",
        dest="output_format",
        choices=["markdown", "json", "csv"],
        default="csv",
        help="taxonomy output format",
    )
    p_amb_taxonomy.add_argument(
        "--output",
        type=Path,
        default=None,
        help="optional file to write the rendered taxonomy",
    )
    p_amb_diff = amb_sub.add_parser(
        "diff",
        help="compare two AMB result files by overall and category accuracy",
    )
    p_amb_diff.add_argument(
        "--baseline",
        type=Path,
        required=True,
        help="path to the baseline AMB result JSON or JSON.GZ file",
    )
    p_amb_diff.add_argument(
        "--candidate",
        type=Path,
        required=True,
        help="path to the candidate AMB result JSON or JSON.GZ file",
    )
    p_amb_diff.add_argument(
        "--format",
        dest="output_format",
        choices=["markdown", "json", "csv"],
        default="markdown",
        help="diff output format",
    )
    p_amb_diff.add_argument(
        "--output",
        type=Path,
        default=None,
        help="optional file to write the rendered diff",
    )
    p_amb_offline = amb_sub.add_parser(
        "offline-score",
        help="score Remaind's deterministic packet picker without spending answer-model quota",
    )
    p_amb_offline.add_argument(
        "--result",
        type=Path,
        required=True,
        help="path to an AMB result JSON or JSON.GZ file with stored contexts",
    )
    p_amb_offline.add_argument(
        "--format",
        dest="output_format",
        choices=["markdown", "json", "csv"],
        default="markdown",
        help="offline score output format",
    )
    p_amb_offline.add_argument(
        "--failures-only",
        action="store_true",
        help="replay only failed AMB queries from the stored result file",
    )
    p_amb_offline.add_argument(
        "--category",
        action="append",
        default=[],
        help="limit offline replay to one AMB question category; repeat for multiple categories",
    )
    p_amb_offline.add_argument(
        "--output",
        type=Path,
        default=None,
        help="optional file to write the rendered offline score",
    )
    p_state_bench = public_bench_sub.add_parser(
        "state-bench",
        help="prepare Remaind as a STATE-Bench retrieve_learnings backend",
    )
    state_bench_sub = p_state_bench.add_subparsers(
        dest="state_bench_command",
        required=True,
    )
    p_state_prepare = state_bench_sub.add_parser(
        "prepare",
        help="ingest STATE-Bench training trajectories and install the agent adapter",
    )
    p_state_prepare.add_argument(
        "--state-bench-repo",
        type=Path,
        required=True,
        help="path to a local STATE-Bench checkout",
    )
    p_state_prepare.add_argument(
        "--train-dir",
        type=Path,
        help=(
            "training trajectories directory "
            "(default: <state-bench-repo>/datasets/train_task_trajectories)"
        ),
    )
    p_state_prepare.add_argument(
        "--workdir",
        type=Path,
        default=public_bench_cmd.DEFAULT_STATE_BENCH_WORKDIR,
        help=(
            "Remaind benchmark workspace "
            f"(default: {public_bench_cmd.DEFAULT_STATE_BENCH_WORKDIR.as_posix()})"
        ),
    )
    p_state_prepare.add_argument(
        "--force",
        action="store_true",
        help="replace an existing Remaind STATE-Bench context in --workdir",
    )
    p_state_prepare.add_argument(
        "--no-install-agent",
        action="store_true",
        help="build the learning artifact without writing the STATE-Bench agent file",
    )
    p_state_prepare.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )
    p_state_retrieve = state_bench_sub.add_parser(
        "retrieve",
        help="smoke-test retrieval from a Remaind STATE-Bench learning artifact",
    )
    source_group = p_state_retrieve.add_mutually_exclusive_group(required=True)
    source_group.add_argument(
        "--artifact",
        type=Path,
        help="state_bench_learnings.json produced by prepare",
    )
    source_group.add_argument(
        "--workdir",
        type=Path,
        help="Remaind STATE-Bench workdir produced by prepare",
    )
    p_state_retrieve.add_argument("query", help="retrieval query")
    p_state_retrieve.add_argument(
        "--top-k",
        type=int,
        default=3,
        help="number of learnings to retrieve",
    )
    p_state_retrieve.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_large_doc = sub.add_parser(
        "large-doc",
        help="register and query large local documents through terminal-backed access",
    )
    large_doc_sub = p_large_doc.add_subparsers(dest="large_doc_command", required=True)

    p_large_doc_ingest = large_doc_sub.add_parser(
        "ingest",
        help="index a local document without copying it into .context/",
    )
    p_large_doc_ingest.add_argument("file", type=Path)
    p_large_doc_ingest.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory containing .context/ (default: current working directory)",
    )
    p_large_doc_ingest.add_argument(
        "--title",
        help="human title to store in the manifest and memory pointer",
    )
    p_large_doc_ingest.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_large_doc_search = large_doc_sub.add_parser(
        "search",
        help="search a local document and return line-numbered evidence",
    )
    p_large_doc_search.add_argument("file", type=Path)
    p_large_doc_search.add_argument("query")
    p_large_doc_search.add_argument(
        "--context",
        type=int,
        default=2,
        help="number of lines of context around each hit",
    )
    p_large_doc_search.add_argument(
        "--max-results",
        type=int,
        default=12,
        help="maximum search hits to return",
    )
    p_large_doc_search.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory containing .context/ for --verify",
    )
    p_large_doc_search.add_argument(
        "--verify",
        action="store_true",
        help="verify the source file still matches its Remaind manifest",
    )
    p_large_doc_search.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_large_doc_slice = large_doc_sub.add_parser(
        "slice",
        help="return an exact inclusive line range from a local document",
    )
    p_large_doc_slice.add_argument("file", type=Path)
    p_large_doc_slice.add_argument("--start", type=int, required=True)
    p_large_doc_slice.add_argument("--end", type=int, required=True)
    p_large_doc_slice.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory containing .context/ for --verify",
    )
    p_large_doc_slice.add_argument(
        "--verify",
        action="store_true",
        help="verify the source file still matches its Remaind manifest",
    )
    p_large_doc_slice.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    for name, help_text in (
        ("head", "return the first lines from a local document"),
        ("tail", "return the last lines from a local document"),
    ):
        p_edge = large_doc_sub.add_parser(name, help=help_text)
        p_edge.add_argument("file", type=Path)
        p_edge.add_argument(
            "--lines",
            type=int,
            default=80,
            help="number of lines to return",
        )
        p_edge.add_argument(
            "--path",
            type=Path,
            default=safe_cwd(),
            help="base directory containing .context/ for --verify",
        )
        p_edge.add_argument(
            "--verify",
            action="store_true",
            help="verify the source file still matches its Remaind manifest",
        )
        p_edge.add_argument(
            "--json",
            dest="as_json",
            action="store_true",
            help="emit JSON instead of the human-readable report",
        )

    p_large_doc_inspect = large_doc_sub.add_parser(
        "inspect",
        help="inspect a large-doc manifest and its deep-compaction runs",
    )
    p_large_doc_inspect.add_argument("target", help="document path or doc_id")
    p_large_doc_inspect.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory containing .context/ (default: current working directory)",
    )
    p_large_doc_inspect.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    p_large_doc_prune = large_doc_sub.add_parser(
        "prune-deep-compactions",
        help="remove deep-compaction cache runs for a large document",
    )
    p_large_doc_prune.add_argument("--doc", required=True, help="document path or doc_id")
    p_large_doc_prune.add_argument(
        "--keep-latest",
        type=int,
        default=1,
        help="number of newest runs to keep (default: 1)",
    )
    p_large_doc_prune.add_argument(
        "--path",
        type=Path,
        default=safe_cwd(),
        help="base directory containing .context/ (default: current working directory)",
    )
    p_large_doc_prune.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="emit JSON instead of the human-readable report",
    )

    return parser


def _run_init(args: argparse.Namespace) -> int:
    try:
        paths = init_cmd.run(args.path, force=args.force)
    except init_cmd.InitError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(f"Initialized {paths.root}\n")
    return 0


def _run_validate(args: argparse.Namespace) -> int:
    report = validate_cmd.run(args.path)
    for label in report.passed:
        sys.stdout.write(f"  ok    {label}\n")
    for label, reason in report.failed:
        sys.stdout.write(f"  FAIL  {label}: {reason}\n")
    if report.ok:
        sys.stdout.write(f"OK   {len(report.passed)} checks passed\n")
        return 0
    sys.stdout.write(
        f"FAIL {len(report.failed)} check(s) failed "
        f"({len(report.passed)} passed)\n"
    )
    return 1


def _run_compact(args: argparse.Namespace) -> int:
    # Compaction uses a local model automatically if one is running, and the
    # rule-based compactor otherwise — there is nothing to configure.
    try:
        result = compact_cmd.run(args.path)
    except compact_cmd.CompactionRejected as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        for item in exc.validation["missing_items"]:
            sys.stderr.write(f"  missing: {item}\n")
        for item in exc.validation["unsupported_claims"]:
            sys.stderr.write(f"  unsupported: {item}\n")
        sys.stderr.write(
            f"  validation event: {exc.validation_event_id}\n"
        )
        return 2
    except CompactorResponseError as exc:
        sys.stderr.write(f"remaind: model compaction failed: {exc}\n")
        return 1
    except compact_cmd.CompactionError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    before = result.handover_chars_before
    after = result.handover_chars_after
    delta = after - before
    sign = "+" if delta >= 0 else ""
    sys.stdout.write(
        f"Compacted via {result.compactor_label}: "
        f"{result.preserved_count} preserved / "
        f"{result.window_size} window event(s); "
        f"handover {before} -> {after} chars ({sign}{delta}); "
        f"compaction event {result.compaction_event_id}; "
        f"validation event {result.validation_event_id}\n"
    )
    return 0


def _run_rollback(args: argparse.Namespace) -> int:
    try:
        result = rollback_cmd.run(args.path, target=args.target)
    except rollback_cmd.RollbackError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(
        f"Rolled back to {result.normalized_target}: "
        f"{len(result.restored)} restored, {len(result.skipped)} skipped "
        f"(event {result.rollback_event_id})\n"
    )
    for kind, snapshot in result.restored.items():
        sys.stdout.write(f"  restored {kind}: {snapshot.name}\n")
    for kind, reason in result.skipped.items():
        sys.stdout.write(f"  skipped  {kind}: {reason}\n")
    # If nothing was actually restored (e.g. timestamp earlier than any
    # snapshot, or no snapshots exist yet) the command is a no-op from the
    # operator's standpoint. Returning 0 here would silently fool cron/CI
    # callers into thinking the rollback succeeded.
    return 0 if result.restored else 1


def _run_resume(args: argparse.Namespace) -> int:
    try:
        result = resume_cmd.run(
            args.path,
            next_tool=args.next_tool,
            k_memories=args.k_memories,
            raw_excerpt_count=args.raw_excerpt_count,
        )
    except resume_cmd.ResumeError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    packet = result.packet
    sys.stdout.write(
        f"Resume packet written ({packet.token_count}/{packet.token_cap} tokens, "
        f"{len(packet.included_memory_ids)} memories, "
        f"{len(packet.included_event_ids)} raw excerpts)\n"
    )
    if packet.exceeded_cap:
        sys.stderr.write("remaind: WARNING packet exceeded token cap\n")
    if packet.gate.concerns:
        sys.stderr.write(
            f"remaind: resume gate raised {len(packet.gate.concerns)} concern(s)"
            f"{' (URGENT)' if packet.gate.urgent else ''}:\n"
        )
        for c in packet.gate.concerns:
            sys.stderr.write(f"  - {c}\n")
    return 0


def _run_status(args: argparse.Namespace) -> int:
    try:
        rendered = status_cmd.run(args.path, as_json=args.as_json)
    except status_cmd.StatusError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(rendered)
    return 0


def _run_doctor(args: argparse.Namespace) -> int:
    result = doctor_cmd.check(args.path, smoke=args.smoke)
    rendered = (
        json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
        if args.as_json
        else doctor_cmd.render_human(result)
    )
    sys.stdout.write(rendered)
    return 0 if result.ok else 1


def _run_monitor(args: argparse.Namespace) -> int:
    result = monitor_cmd.check(
        args.path,
        smoke=args.smoke,
        large_doc_targets=args.large_docs or None,
    )
    rendered = (
        json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
        if args.as_json
        else monitor_cmd.render_human(result)
    )
    sys.stdout.write(rendered)
    return 0 if result.ok else 2


def _run_launch(args: argparse.Namespace) -> int:
    try:
        result = launch_cmd.execute(
            launch_cmd.LaunchOptions(
                path=args.path,
                workspace_query=args.workspace_query,
                runtime=args.runtime,
                model=args.model,
                yolo_model=args.yolo_model,
                input_mode=args.input_mode,
                file=args.file,
                task=args.task,
                non_interactive=args.non_interactive,
                accept_fallback=args.accept_fallback,
                token_cap=args.token_cap,
                memory_mode=args.memory_mode,
                max_results=args.max_results,
                answer_key_path=args.answer_key,
                require_answer_key_pass=args.require_answer_key_pass,
                deep_compact=args.deep_compact,
                deep_compact_mode=args.deep_compact_mode,
                reuse_deep_compact=args.reuse_deep_compact,
                deep_compact_chunk_tokens=args.deep_compact_chunk_tokens,
                show_progress=not args.as_json,
            )
        )
    except launch_cmd.LaunchError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    rendered = (
        launch_cmd.render_json(result)
        if args.as_json
        else launch_cmd.render_human(result)
    )
    sys.stdout.write(rendered)
    if result.run_result and result.run_result.get("model_error"):
        return 1
    return 0


def _launch_from_presence_args(
    args: argparse.Namespace,
    *,
    input_mode: str,
    task: str | None,
) -> launch_cmd.LaunchOptions:
    has_explicit_workspace = args.path is not None or args.workspace_query is not None
    return launch_cmd.LaunchOptions(
        path=args.path,
        workspace_query=args.workspace_query,
        runtime=args.runtime,
        model=args.model,
        yolo_model=args.yolo_model,
        input_mode=input_mode,
        task=task,
        non_interactive=task is not None
        and (has_explicit_workspace or not sys.stdin.isatty()),
        accept_fallback=args.accept_fallback,
        memory_mode=args.memory_mode,
        skip_runtime_selection=getattr(args, "skip_runtime_selection", False),
        show_progress=not getattr(args, "as_json", False),
    )


def _run_ask(args: argparse.Namespace) -> int:
    question = " ".join(args.question).strip()
    try:
        result = launch_cmd.execute(
            _launch_from_presence_args(
                args,
                input_mode="ask",
                task=question or None,
            )
        )
    except launch_cmd.LaunchError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    rendered = (
        launch_cmd.render_json(result)
        if args.as_json
        else launch_cmd.render_human(result)
    )
    sys.stdout.write(rendered)
    if result.run_result and result.run_result.get("model_error"):
        return 1
    return 0


def _run_chat(args: argparse.Namespace) -> int:
    try:
        result = launch_cmd.execute(
            _launch_from_presence_args(args, input_mode="ask", task=None)
        )
    except launch_cmd.LaunchError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    rendered = launch_cmd.render_human(result)
    sys.stdout.write(rendered)
    if result.run_result and result.run_result.get("model_error"):
        return 1
    return 0


def _run_context(args: argparse.Namespace) -> int:
    if args.context_command != "inspect":
        return 2
    question = " ".join(args.question).strip()
    if not question:
        question = "what is the current plan, latest progress, blockers, and next step?"
    has_explicit_workspace = args.path is not None or args.workspace_query is not None
    try:
        result = launch_cmd.inspect_context(
            launch_cmd.LaunchOptions(
                path=args.path,
                workspace_query=args.workspace_query,
                runtime="fallback",
                input_mode="empty",
                non_interactive=has_explicit_workspace or not sys.stdin.isatty(),
                accept_fallback=True,
                memory_mode=args.memory_mode,
                skip_runtime_selection=True,
                show_progress=False,
            ),
            question,
        )
    except launch_cmd.LaunchError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    if args.as_json:
        sys.stdout.write(json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n")
    else:
        sys.stdout.write(result.content)
    return 0


def _run_continuity(args: argparse.Namespace) -> int:
    if args.continuity_command == "scorecard":
        score_result = continuity_cmd.run_scorecard(args.path)
        sys.stdout.write(
            continuity_cmd.render_scorecard_result(score_result, as_json=args.as_json)
        )
        return 0
    if args.continuity_command == "evidence":
        evidence_result = continuity_cmd.run_evidence(args.path)
        sys.stdout.write(
            continuity_cmd.render_evidence_result(evidence_result, as_json=args.as_json)
        )
        return 0
    if args.continuity_command == "export":
        try:
            export_result = continuity_cmd.run_export(
                args.path,
                targets=args.targets,
                output_dir=args.out,
            )
        except (continuity_cmd.ContinuityError, ValueError) as exc:
            sys.stderr.write(f"remaind: {exc}\n")
            return 1
        sys.stdout.write(
            continuity_cmd.render_export_result(export_result, as_json=args.as_json)
        )
        return 0
    return 2


def _run_memory(args: argparse.Namespace) -> int:
    if args.memory_command == "plan":
        sys.stdout.write(memory_cmd.run_plan(args.path))
        return 0
    if args.memory_command == "block":
        try:
            result = memory_cmd.run_block(
                args.path,
                task=args.task,
                reason=args.reason,
                workspace_query=args.workspace_query,
            )
        except (memory_cmd.ContinuityError, ValueError) as exc:
            sys.stderr.write(f"remaind: {exc}\n")
            return 1
        sys.stdout.write(memory_cmd.render_tool_result(result, as_json=args.as_json))
        return 0
    if args.memory_command == "decision":
        try:
            result = memory_cmd.run_decision(args.path, text=" ".join(args.text))
        except (memory_cmd.ContinuityError, ValueError) as exc:
            sys.stderr.write(f"remaind: {exc}\n")
            return 1
        sys.stdout.write(memory_cmd.render_tool_result(result, as_json=args.as_json))
        return 0
    if args.memory_command == "promote":
        try:
            result = memory_cmd.run_promote(
                args.path,
                text=" ".join(args.text),
                rationale=args.rationale,
                tags=args.tags,
            )
        except (memory_cmd.ContinuityError, ValueError) as exc:
            sys.stderr.write(f"remaind: {exc}\n")
            return 1
        sys.stdout.write(memory_cmd.render_tool_result(result, as_json=args.as_json))
        return 0
    if args.memory_command == "changed":
        sys.stdout.write(memory_cmd.run_changed(args.path, limit=args.limit))
        return 0
    return 2


def _default_chat_args() -> argparse.Namespace:
    model = (
        os.environ.get("REMAIND_OPENAI_MODEL")
        or os.environ.get("REMAIND_OLLAMA_MODEL")
        or None
    )
    return argparse.Namespace(
        path=None,
        workspace_query=None,
        runtime="auto",
        model=model,
        yolo_model=False,
        accept_fallback=False,
        memory_mode=os.environ.get("REMAIND_MEMORY_MODE", "turbo"),
        skip_runtime_selection=True,
    )


def _run_daemon(args: argparse.Namespace) -> int:
    try:
        if args.daemon_command == "start":
            status_result = daemon_cmd.start(
                interval_s=args.interval,
                foreground=args.foreground,
            )
            sys.stdout.write(daemon_cmd.render_status(status_result))
            return 0
        if args.daemon_command == "stop":
            status_result = daemon_cmd.stop()
            sys.stdout.write(daemon_cmd.render_status(status_result))
            return 0
        if args.daemon_command == "run":
            daemon_cmd.run_forever(interval_s=args.interval, once=args.once)
            return 0
        if args.daemon_command == "status":
            status_result = daemon_cmd.status(cwd=args.cwd)
            rendered = (
                json.dumps(status_result.to_dict(), indent=2, sort_keys=True) + "\n"
                if args.as_json
                else daemon_cmd.render_status(status_result, short=args.short)
            )
            sys.stdout.write(rendered)
            return 0
        if args.daemon_command == "reindex":
            reindex_result = daemon_cmd.reindex(cwd=args.cwd)
            sys.stdout.write(
                daemon_cmd.render_reindex(reindex_result, as_json=args.as_json)
            )
            return 0
        if args.daemon_command == "observe":
            capture_result = daemon_cmd.observe_activity(
                cwd=args.cwd,
                command=args.observed_command,
                exit_code=args.exit_code,
                duration_ms=args.duration_ms,
            )
            if args.as_json:
                sys.stdout.write(
                    json.dumps(capture_result.to_dict(), indent=2, sort_keys=True)
                    + "\n"
                )
            elif capture_result.captured:
                updated = (
                    "updated product status"
                    if capture_result.product_status_updated
                    else "logged activity"
                )
                sys.stdout.write(f"Presence observed: {updated}\n")
            return 0
        if args.daemon_command == "shell-init":
            sys.stdout.write(daemon_cmd.shell_init(args.shell))
            return 0
        if args.daemon_command == "install-shell-hook":
            install_result = daemon_cmd.install_shell_hook(
                args.shell,
                rc_file=args.rc_file,
            )
            if args.as_json:
                sys.stdout.write(
                    json.dumps(install_result.to_dict(), indent=2, sort_keys=True)
                    + "\n"
                )
            else:
                verb = "Installed" if install_result.changed else "Already installed"
                sys.stdout.write(
                    f"{verb} Remaind presence hook: {install_result.rc_file}\n"
                )
            return 0
    except daemon_cmd.DaemonError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    return 2


def _run_run(args: argparse.Namespace) -> int:
    def progress(message: str) -> None:
        sys.stderr.write(message.rstrip() + "\n")
        sys.stderr.flush()

    try:
        result = run_cmd.execute(
            args.path,
            args.file,
            args.task,
            title=args.title,
            auto_init=not args.no_init,
            context=args.context,
            max_results=args.max_results,
            head_lines=args.head_lines,
            tail_lines=args.tail_lines,
            query_count=args.query_count,
            token_cap=args.token_cap,
            no_model=args.no_model,
            model_name=args.model,
            openai_base_url=args.openai_base_url,
            ollama_host=args.ollama_host,
            ollama_api=args.ollama_api,
            num_ctx=args.num_ctx,
            extra_queries=args.queries,
            answer_key_path=args.answer_key,
            deep_compact=args.deep_compact,
            deep_compact_mode=args.deep_compact_mode,
            reuse_deep_compact=args.reuse_deep_compact,
            deep_compact_chunk_tokens=args.deep_compact_chunk_tokens,
            progress_callback=None if args.as_json else progress,
        )
    except run_cmd.RunError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    rendered = run_cmd.render_json(result) if args.as_json else run_cmd.render_human(result)
    sys.stdout.write(rendered)
    if args.require_answer_key_pass:
        if not result.answer_key_path:
            sys.stderr.write("remaind: answer key required but none was found\n")
            return 2
        if not result.answer_validation or not result.answer_validation.get("passed"):
            sys.stderr.write("remaind: answer key validation failed\n")
            return 2
    if result.model_error:
        return 1
    return 0


def _run_bench(args: argparse.Namespace) -> int:
    try:
        if args.bench_name == "sovereign":
            sovereign_result = bench_cmd.run_sovereign(
                workdir=args.workdir,
                target_tokens=args.target_tokens,
                force=args.force,
            )
            if args.as_json:
                sys.stdout.write(
                    json.dumps(sovereign_result.to_dict(), indent=2, sort_keys=True)
                    + "\n"
                )
            else:
                status = "PASS" if sovereign_result.passed else "FAIL"
                sys.stdout.write(f"Sovereign benchmark: {status}\n")
                sys.stdout.write(f"Workspace:      {sovereign_result.workdir}\n")
                sys.stdout.write(f"Archive:        {sovereign_result.archive_path}\n")
                sys.stdout.write(
                    f"Archive size:   {sovereign_result.archive_tokens} tokens approx, "
                    f"{sovereign_result.archive_bytes} bytes, "
                    f"{sovereign_result.line_count} lines\n"
                )
                sys.stdout.write(
                    f"Resume packet:  {sovereign_result.resume_tokens}/"
                    f"{sovereign_result.resume_token_cap} tokens\n"
                )
                sys.stdout.write(
                    f"Gate concerns:  {len(sovereign_result.gate_concerns)}\n"
                )
                for check in sovereign_result.checks:
                    marker = "ok" if check.passed else "FAIL"
                    sys.stdout.write(f"  {marker:4} {check.name}: {check.detail}\n")
            return 0 if sovereign_result.passed else 1
        if args.bench_name == "continuity":
            continuity_result = bench_cmd.run_continuity(
                workdir=args.workdir,
                force=args.force,
            )
            if args.as_json:
                sys.stdout.write(
                    json.dumps(continuity_result.to_dict(), indent=2, sort_keys=True)
                    + "\n"
                )
            else:
                status = "PASS" if continuity_result.passed else "FAIL"
                sys.stdout.write(f"Project continuity benchmark: {status}\n")
                sys.stdout.write(f"Workspace:      {continuity_result.workdir}\n")
                sys.stdout.write(
                    f"Resume packet:  {continuity_result.resume_packet_path}\n"
                )
                sys.stdout.write(
                    f"Large document: {continuity_result.large_doc_manifest}\n"
                )
                sys.stdout.write(
                    f"Scorecard:      {continuity_result.scorecard.overall_score:.2f} "
                    f"({continuity_result.evidence_links} evidence links)\n"
                )
                for check in continuity_result.checks:
                    marker = "ok" if check.passed else "FAIL"
                    sys.stdout.write(f"  {marker:4} {check.name}: {check.detail}\n")
            return 0 if continuity_result.passed else 1
    except bench_cmd.BenchmarkError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    return 2


def _run_public_bench(args: argparse.Namespace) -> int:
    try:
        if args.public_bench_name == "amb":
            if args.amb_command == "prepare":
                amb_prepare_result = public_bench_cmd.run_amb_prepare(
                    amb_repo=args.amb_repo,
                    remaind_source_path=args.remaind_source,
                )
                sys.stdout.write(
                    public_bench_cmd.render_amb_prepare(
                        amb_prepare_result,
                        as_json=args.as_json,
                    )
                )
                return 0
            if args.amb_command == "report":
                amb_report = public_bench_cmd.run_amb_report(
                    result_path=args.result,
                )
                rendered = public_bench_cmd.render_amb_score_report(
                    amb_report,
                    output_format=args.output_format,
                )
                if args.output is not None:
                    args.output.parent.mkdir(parents=True, exist_ok=True)
                    args.output.write_text(rendered, encoding="utf-8")
                    sys.stdout.write(f"AMB report written: {args.output}\n")
                else:
                    sys.stdout.write(rendered)
                return 0
            if args.amb_command == "taxonomy":
                amb_taxonomy = public_bench_cmd.run_amb_taxonomy(
                    result_path=args.result,
                )
                rendered = public_bench_cmd.render_amb_failure_taxonomy(
                    amb_taxonomy,
                    output_format=args.output_format,
                )
                if args.output is not None:
                    args.output.parent.mkdir(parents=True, exist_ok=True)
                    args.output.write_text(rendered, encoding="utf-8")
                    sys.stdout.write(f"AMB failure taxonomy written: {args.output}\n")
                else:
                    sys.stdout.write(rendered)
                return 0
            if args.amb_command == "diff":
                amb_diff = public_bench_cmd.run_amb_diff(
                    baseline_path=args.baseline,
                    candidate_path=args.candidate,
                )
                rendered = public_bench_cmd.render_amb_score_diff(
                    amb_diff,
                    output_format=args.output_format,
                )
                if args.output is not None:
                    args.output.parent.mkdir(parents=True, exist_ok=True)
                    args.output.write_text(rendered, encoding="utf-8")
                    sys.stdout.write(f"AMB diff written: {args.output}\n")
                else:
                    sys.stdout.write(rendered)
                return 0
            if args.amb_command == "offline-score":
                offline_score = public_bench_cmd.run_amb_offline_score(
                    result_path=args.result,
                    failures_only=bool(args.failures_only),
                    categories=tuple(args.category or ()),
                )
                rendered = public_bench_cmd.render_amb_offline_score(
                    offline_score,
                    output_format=args.output_format,
                )
                if args.output is not None:
                    args.output.parent.mkdir(parents=True, exist_ok=True)
                    args.output.write_text(rendered, encoding="utf-8")
                    sys.stdout.write(f"AMB offline score written: {args.output}\n")
                else:
                    sys.stdout.write(rendered)
                return 0
        if args.public_bench_name == "state-bench":
            if args.state_bench_command == "prepare":
                state_prepare_result = public_bench_cmd.run_state_bench_prepare(
                    state_bench_repo=args.state_bench_repo,
                    train_dir=args.train_dir,
                    workdir=args.workdir,
                    force=args.force,
                    install_agent=not args.no_install_agent,
                )
                sys.stdout.write(
                    public_bench_cmd.render_state_bench_prepare(
                        state_prepare_result,
                        as_json=args.as_json,
                    )
                )
                return 0
            if args.state_bench_command == "retrieve":
                retrieval_result = public_bench_cmd.run_state_bench_retrieve(
                    artifact=args.artifact,
                    workdir=args.workdir,
                    query=args.query,
                    top_k=args.top_k,
                )
                sys.stdout.write(
                    public_bench_cmd.render_state_bench_retrieval(
                        retrieval_result,
                        as_json=args.as_json,
                    )
                )
                return 0 if retrieval_result.learnings else 1
    except public_bench_cmd.AMBBenchmarkError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    except public_bench_cmd.PublicBenchmarkError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    return 2


def _run_large_doc(args: argparse.Namespace) -> int:
    try:
        if args.large_doc_command == "ingest":
            ingest_result = large_doc_cmd.run_ingest(
                args.path,
                args.file,
                title=args.title,
            )
            rendered = (
                large_doc_cmd.render_json(ingest_result)
                if args.as_json
                else large_doc_cmd.render_human_ingest(ingest_result)
            )
        elif args.large_doc_command == "search":
            search_result = large_doc_cmd.run_search(
                args.file,
                args.query,
                context=args.context,
                max_results=args.max_results,
                base=args.path,
                verify=args.verify,
            )
            rendered = (
                large_doc_cmd.render_json(search_result)
                if args.as_json
                else large_doc_cmd.render_human_search(search_result)
            )
        elif args.large_doc_command == "slice":
            lines_result = large_doc_cmd.run_slice(
                args.file,
                start=args.start,
                end=args.end,
                base=args.path,
                verify=args.verify,
            )
            rendered = (
                large_doc_cmd.render_json(lines_result)
                if args.as_json
                else large_doc_cmd.render_human_lines(lines_result)
            )
        elif args.large_doc_command == "head":
            head_result = large_doc_cmd.run_head(
                args.file,
                lines=args.lines,
                base=args.path,
                verify=args.verify,
            )
            rendered = (
                large_doc_cmd.render_json(head_result)
                if args.as_json
                else large_doc_cmd.render_human_lines(head_result)
            )
        elif args.large_doc_command == "tail":
            tail_result = large_doc_cmd.run_tail(
                args.file,
                lines=args.lines,
                base=args.path,
                verify=args.verify,
            )
            rendered = (
                large_doc_cmd.render_json(tail_result)
                if args.as_json
                else large_doc_cmd.render_human_lines(tail_result)
            )
        elif args.large_doc_command == "inspect":
            inspect_result = large_doc_cmd.run_inspect(args.path, args.target)
            rendered = (
                json.dumps(inspect_result, indent=2, sort_keys=True) + "\n"
                if args.as_json
                else large_doc_cmd.render_human_inspect(inspect_result)
            )
        elif args.large_doc_command == "prune-deep-compactions":
            prune_result = large_doc_cmd.run_prune_deep_compactions(
                args.path,
                args.doc,
                keep_latest=args.keep_latest,
            )
            rendered = (
                json.dumps(prune_result, indent=2, sort_keys=True) + "\n"
                if args.as_json
                else large_doc_cmd.render_human_prune(prune_result)
            )
        else:
            return 2
    except large_doc_cmd.LargeDocumentError as exc:
        sys.stderr.write(f"remaind: {exc}\n")
        return 1
    sys.stdout.write(rendered)
    return 0


def main(argv: list[str] | None = None) -> int:
    raw_argv = sys.argv[1:] if argv is None else argv
    if not raw_argv:
        return _run_chat(_default_chat_args())
    args = _build_parser().parse_args(argv)
    if args.command == "init":
        return _run_init(args)
    if args.command == "validate":
        return _run_validate(args)
    if args.command == "status":
        return _run_status(args)
    if args.command == "doctor":
        return _run_doctor(args)
    if args.command == "monitor":
        return _run_monitor(args)
    if args.command == "launch":
        return _run_launch(args)
    if args.command == "ask":
        return _run_ask(args)
    if args.command == "chat":
        return _run_chat(args)
    if args.command == "context":
        return _run_context(args)
    if args.command == "continuity":
        return _run_continuity(args)
    if args.command == "memory":
        return _run_memory(args)
    if args.command == "daemon":
        return _run_daemon(args)
    if args.command == "run":
        return _run_run(args)
    if args.command == "compact":
        return _run_compact(args)
    if args.command == "resume":
        return _run_resume(args)
    if args.command == "rollback":
        return _run_rollback(args)
    if args.command == "bench":
        return _run_bench(args)
    if args.command == "public-bench":
        return _run_public_bench(args)
    if args.command == "large-doc":
        return _run_large_doc(args)
    return 2
