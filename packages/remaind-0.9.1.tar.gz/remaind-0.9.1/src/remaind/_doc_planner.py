"""Chunk planning for deep document compaction."""

from __future__ import annotations

import os
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from ._doc_cache import DEEP_COMPACT_CHUNK_TOKENS_ENV, DocumentCompactionError, _read_jsonl_objects
from ._tokens import estimate_tokens

_DEFAULT_CHUNK_TOKENS = 8_000
_MIN_CHUNK_TOKENS = 500
_MAX_MODEL_CHUNK_FRACTION = 0.16


@dataclass(frozen=True)
class ChunkPlan:
    chunk_id: str
    line_start: int
    line_end: int
    approx_tokens: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

def _iter_source_lines(path: Path) -> Iterable[tuple[int, str]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            for number, line in enumerate(handle, start=1):
                yield number, line.rstrip("\r\n")
    except UnicodeDecodeError as exc:
        raise DocumentCompactionError(
            f"{path}: invalid UTF-8 at byte {exc.start}; convert the file to UTF-8 "
            "before deep compaction"
        ) from exc

def _chunk_token_override(chunk_tokens: int | None) -> int | None:
    if chunk_tokens is not None:
        if chunk_tokens < _MIN_CHUNK_TOKENS:
            raise DocumentCompactionError(
                f"deep-compaction chunk tokens must be at least {_MIN_CHUNK_TOKENS}"
            )
        return chunk_tokens
    raw = os.environ.get(DEEP_COMPACT_CHUNK_TOKENS_ENV, "").strip()
    if not raw:
        return None
    try:
        value = int(raw)
    except ValueError as exc:
        raise DocumentCompactionError(
            f"{DEEP_COMPACT_CHUNK_TOKENS_ENV} must be an integer"
        ) from exc
    if value < _MIN_CHUNK_TOKENS:
        raise DocumentCompactionError(
            f"{DEEP_COMPACT_CHUNK_TOKENS_ENV} must be at least {_MIN_CHUNK_TOKENS}"
        )
    return value

def _chunk_token_target(
    num_ctx: int | None,
    *,
    chunk_tokens: int | None = None,
) -> int:
    override = _chunk_token_override(chunk_tokens)
    if override is not None:
        return override
    if num_ctx and num_ctx > 0:
        return max(2_000, min(16_000, int(num_ctx * _MAX_MODEL_CHUNK_FRACTION)))
    return _DEFAULT_CHUNK_TOKENS

def plan_chunks(
    document_path: Path,
    *,
    num_ctx: int | None = None,
    chunk_tokens: int | None = None,
) -> list[ChunkPlan]:
    target = _chunk_token_target(num_ctx, chunk_tokens=chunk_tokens)
    chunks: list[ChunkPlan] = []
    start = 1
    end = 0
    used = 0
    for line_no, text in _iter_source_lines(document_path):
        line_tokens = max(1, estimate_tokens(text))
        if end >= start and used + line_tokens > target:
            chunks.append(
                ChunkPlan(
                    chunk_id=f"chunk_{len(chunks) + 1:05d}",
                    line_start=start,
                    line_end=end,
                    approx_tokens=used,
                )
            )
            start = line_no
            used = 0
        end = line_no
        used += line_tokens
    if end >= start:
        chunks.append(
            ChunkPlan(
                chunk_id=f"chunk_{len(chunks) + 1:05d}",
                line_start=start,
                line_end=end,
                approx_tokens=used,
            )
        )
    return chunks

def _load_chunk_plan(path: Path) -> list[ChunkPlan]:
    chunks: list[ChunkPlan] = []
    for item in _read_jsonl_objects(path):
        try:
            chunks.append(
                ChunkPlan(
                    chunk_id=str(item["chunk_id"]),
                    line_start=int(item["line_start"]),
                    line_end=int(item["line_end"]),
                    approx_tokens=int(item.get("approx_tokens") or 1),
                )
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise DocumentCompactionError(
                f"invalid chunk plan record in {path}: {exc}"
            ) from exc
    return chunks
