"""Per-chunk extraction, validation, quarantine, and persistence helpers."""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from jsonschema import ValidationError

from ._adversarial import scan_text
from ._context_engine import ContextBuildRequest, select_engineered_context
from ._context_render import render_context_decision_section
from ._context_sources import ContextSource
from ._doc_cache import (
    CHUNK_EXTRACT_PROMPT_VERSION,
    DocumentCompactionError,
    DocumentTextModel,
    _prompt,
    _render_prompt,
)
from ._doc_normalizers import _normalize_chunk_shorthand, _topic_terms
from ._doc_planner import ChunkPlan
from ._jsonl import append_jsonl
from ._large_doc import LargeDocumentIngestResult, slice_large_document
from ._paths import ContextPaths
from ._redaction import Redactor
from ._schemas import bundled_schema, make_validator
from ._text_model import TextModelError, extract_json_payload
from ._timestamps import utc_now_iso

CHUNK_EXTRACT_MAX_TOKENS = 2048
_TASK_IDENTIFIER_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
_TASK_HYPHEN_IDENTIFIER_RE = re.compile(r"\b[A-Z0-9]{2,}(?:-[A-Z0-9]{2,})+\b")
_LOCAL_EVIDENCE_LIMIT = 3
_IDENTIFIER_LOOKUP_CUES = (
    "find",
    "locate",
    "exact",
    "token",
    "checksum",
    "cite",
    "answer with",
)


def _high_signal_task_terms(task: str) -> list[str]:
    terms = {
        match.group(0)
        for pattern in (_TASK_IDENTIFIER_RE, _TASK_HYPHEN_IDENTIFIER_RE)
        for match in pattern.finditer(task)
    }
    return sorted(terms)


def _is_identifier_lookup_task(task: str) -> bool:
    task_lower = task.lower()
    return any(cue in task_lower for cue in _IDENTIFIER_LOOKUP_CUES)


def _term_variants(term: str) -> set[str]:
    normalized = term.strip().lower()
    if not normalized:
        return set()
    variants = {normalized}
    spaced = normalized.replace("_", " ").replace("-", " ")
    if spaced != normalized:
        variants.add(spaced)
    compact = normalized.replace("_", "").replace("-", "")
    if compact != normalized:
        variants.add(compact)
    return variants


def _line_has_negative_evidence(line_lower: str, variant: str) -> bool:
    escaped = re.escape(variant)
    patterns = (
        rf"\bno\s+{escaped}\b",
        rf"\bwithout\s+{escaped}\b",
        rf"\b(?:contains?|includes?|has|carries)\s+no\s+{escaped}\b",
        rf"\b(?:does\s+not|doesn't|do\s+not|don't|cannot|can't|never)\s+"
        rf"(?:contain|include|carry|state|show|provide|mention)?\s*{escaped}\b",
    )
    return any(re.search(pattern, line_lower) for pattern in patterns)


def _empty_chunk_summary(
    *, ingest: LargeDocumentIngestResult, chunk: ChunkPlan
) -> dict[str, Any]:
    return {
        "doc_id": ingest.stats.doc_id,
        "source_hash": ingest.stats.sha256,
        "chunk_id": chunk.chunk_id,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
        "task_relevance": 0.0,
        "claims": [],
        "contradictions": [],
        "decisions": [],
        "constraints": [],
        "revocations": [],
        "candidate_answer_fragments": [],
        "adversarial_flags": [],
        "verified_quotes": [],
        "topics": [],
        "entities": [],
    }


def _local_relevance_candidate(
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    chunk: ChunkPlan,
    rows: dict[int, str],
) -> dict[str, Any] | None:
    terms = _high_signal_task_terms(task)
    if not terms or not _is_identifier_lookup_task(task):
        return None

    positive_rows: list[tuple[int, str, str]] = []
    for line_no, row in sorted(rows.items()):
        line_lower = row.lower()
        for term in terms:
            variants = _term_variants(term)
            if not any(variant in line_lower for variant in variants):
                continue
            if any(_line_has_negative_evidence(line_lower, variant) for variant in variants):
                continue
            positive_rows.append((line_no, row.strip(), term))
            break

    if not positive_rows:
        return _empty_chunk_summary(ingest=ingest, chunk=chunk)

    claims: list[dict[str, Any]] = []
    fragments: list[dict[str, Any]] = []
    quotes: list[dict[str, Any]] = []
    cited_terms: set[str] = set()
    combined_text: list[str] = []
    for line_no, text, term in positive_rows[:_LOCAL_EVIDENCE_LIMIT]:
        if not text:
            continue
        source_lines = [line_no, line_no]
        claims.append({"text": text, "source_lines": source_lines})
        fragments.append(
            {"text": text, "source_lines": source_lines, "confidence": 0.95}
        )
        quotes.append({"quote": text, "source_lines": source_lines})
        cited_terms.add(term)
        combined_text.append(text)

    if not claims:
        return _empty_chunk_summary(ingest=ingest, chunk=chunk)

    uppercase_entities = {
        token
        for text in combined_text
        for token in re.findall(r"\b[A-Z][A-Z0-9_-]{2,}\b", text)
    }
    topics = sorted({term.lower() for term in cited_terms})[:10]
    entities = sorted({*cited_terms, *uppercase_entities})[:10]
    return {
        "doc_id": ingest.stats.doc_id,
        "source_hash": ingest.stats.sha256,
        "chunk_id": chunk.chunk_id,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
        "task_relevance": 1.0,
        "claims": claims,
        "contradictions": [],
        "decisions": [],
        "constraints": [],
        "revocations": [],
        "candidate_answer_fragments": fragments,
        "adversarial_flags": [],
        "verified_quotes": quotes,
        "topics": topics,
        "entities": entities,
    }


def _slice_text(document_path: Path, chunk: ChunkPlan) -> tuple[str, dict[int, str]]:
    result = slice_large_document(document_path, start=chunk.line_start, end=chunk.line_end)
    rows = {int(row["line"]): str(row["text"]) for row in result.lines}
    text = "\n".join(f"{line}: {value}" for line, value in rows.items())
    return text, rows

def _candidate_text(candidate: dict[str, Any]) -> str:
    pieces: list[str] = []

    def visit(value: Any) -> None:
        if isinstance(value, str):
            pieces.append(value)
        elif isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            for item in value.values():
                visit(item)

    visit(candidate)
    return "\n".join(pieces)

def _redact_value(value: Any, redactor: Redactor) -> Any:
    return redactor.redact_value(value)[0]

def _line_ranges(candidate: dict[str, Any]) -> Iterable[tuple[str, list[int]]]:
    for section in (
        "claims",
        "contradictions",
        "decisions",
        "constraints",
        "revocations",
        "candidate_answer_fragments",
        "adversarial_flags",
        "verified_quotes",
        "answer_affecting_claims",
    ):
        raw = candidate.get(section)
        if not isinstance(raw, list):
            continue
        for idx, item in enumerate(raw):
            if isinstance(item, dict) and isinstance(item.get("source_lines"), list):
                yield f"{section}[{idx}]", item["source_lines"]

def _verify_source_bounds(candidate: dict[str, Any], chunk: ChunkPlan) -> None:
    for label, source_lines in _line_ranges(candidate):
        if len(source_lines) != 2:
            raise DocumentCompactionError(f"{label}.source_lines must be [start,end]")
        start, end = source_lines
        if not isinstance(start, int) or not isinstance(end, int) or start > end:
            raise DocumentCompactionError(f"{label}.source_lines is invalid")
        if start < chunk.line_start or end > chunk.line_end:
            raise DocumentCompactionError(
                f"{label}.source_lines {start}-{end} outside chunk "
                f"{chunk.line_start}-{chunk.line_end}"
            )

def _verify_quotes(candidate: dict[str, Any], rows: dict[int, str]) -> None:
    raw = candidate.get("verified_quotes")
    if not isinstance(raw, list):
        return
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            continue
        quote = str(item.get("quote") or "")
        source_lines = item.get("source_lines")
        if not quote or not isinstance(source_lines, list) or len(source_lines) != 2:
            continue
        start, end = int(source_lines[0]), int(source_lines[1])
        cited = "\n".join(rows.get(line, "") for line in range(start, end + 1))
        if quote not in cited:
            raise DocumentCompactionError(
                f"verified_quotes[{idx}] quote does not appear in cited lines"
            )

def _sanitize_failure(
    *,
    chunk: ChunkPlan,
    stage: str,
    reason: str,
    source_hash: str,
) -> dict[str, Any]:
    return {
        "chunk_id": chunk.chunk_id,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
        "stage": stage,
        "reason": reason[:500],
        "source_hash": source_hash,
        "ts": utc_now_iso(),
    }

def _sanitize_quarantine(
    *,
    chunk: ChunkPlan,
    findings: list[Any],
    source_hash: str,
) -> dict[str, Any]:
    severities = [str(getattr(item, "severity", "")) for item in findings]
    return {
        "chunk_id": chunk.chunk_id,
        "line_start": chunk.line_start,
        "line_end": chunk.line_end,
        "finding_kinds": [str(getattr(item, "issue", "")) for item in findings],
        "rules": [str(getattr(item, "rule", "")) for item in findings],
        "severity": "high" if "high" in severities else (severities[0] if severities else ""),
        "source_hash": source_hash,
        "ts": utc_now_iso(),
    }

def _schema_errors(schema_name: str, candidate: dict[str, Any]) -> list[str]:
    validator = make_validator(bundled_schema(schema_name))
    errors = sorted(validator.iter_errors(candidate), key=lambda e: list(e.absolute_path))
    return [error.message for error in errors]

def _parse_candidate(raw: str, *, schema_name: str) -> dict[str, Any]:
    try:
        candidate = extract_json_payload(raw)
    except TextModelError as exc:
        raise DocumentCompactionError(str(exc)) from exc
    wrapped = candidate.get(schema_name)
    if isinstance(wrapped, dict) and "doc_id" not in candidate:
        return wrapped
    return candidate

def _extract_chunk_once(
    *,
    model: DocumentTextModel,
    task: str,
    ingest: LargeDocumentIngestResult,
    chunk: ChunkPlan,
    raw_chunk: str,
) -> dict[str, Any]:
    context_sources = [
        ContextSource(
            id="chunk_task",
            title="Extraction Task",
            source_type="current_question",
            authority="current_user",
            freshness="live",
            content=f"Task:\n{task.strip()}\n",
            mandatory=True,
            reason="The user task defines what meaning the chunk extraction should preserve.",
            budget_group="task",
        ),
        ContextSource(
            id="chunk_source_manifest",
            title="Chunk Source Manifest",
            source_type="source_metadata",
            authority="source_evidence",
            freshness="current",
            content=(
                f"doc_id: {ingest.stats.doc_id}\n"
                f"source_hash: {ingest.stats.sha256}\n"
                f"chunk_id: {chunk.chunk_id}\n"
                f"line_range: {chunk.line_start}-{chunk.line_end}\n"
            ),
            mandatory=True,
            reason="The manifest bounds every source_lines value and cache identity.",
            budget_group="metadata",
        ),
        ContextSource(
            id="chunk_lines",
            title="Line-Numbered Chunk",
            source_type="document_chunk",
            authority="source_evidence",
            freshness="current",
            content=raw_chunk,
            mandatory=True,
            reason="Only this exact line-numbered chunk may support extracted facts.",
            budget_group="source",
        ),
    ]
    intent, selection = select_engineered_context(
        ContextBuildRequest(
            question=task,
            token_cap=sum(source.token_count for source in context_sources),
        ),
        context_sources,
    )
    context_decision = render_context_decision_section(
        question=task,
        workspace_query=None,
        intent=intent,
        selection=selection,
    )
    prompt = _render_prompt(
        _prompt(CHUNK_EXTRACT_PROMPT_VERSION),
        {
            "context_engineering": context_decision,
            "task": task,
            "doc_id": ingest.stats.doc_id,
            "source_hash": ingest.stats.sha256,
            "chunk_id": chunk.chunk_id,
            "line_start": chunk.line_start,
            "line_end": chunk.line_end,
            "chunk": raw_chunk,
        },
    )
    raw = model.complete(
        prompt,
        system="Return only valid JSON for Remaind chunk_summary_v1.",
        json_mode=True,
        max_tokens=CHUNK_EXTRACT_MAX_TOKENS,
    )
    return _parse_candidate(raw, schema_name="chunk_summary_v1")


def _finalize_chunk_candidate(
    *,
    candidate: dict[str, Any],
    ingest: LargeDocumentIngestResult,
    chunk: ChunkPlan,
    rows: dict[int, str],
    redactor: Redactor,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    errors = _schema_errors("chunk_summary_v1", candidate)
    if errors:
        normalized = _normalize_chunk_shorthand(
            candidate,
            ingest=ingest,
            chunk=chunk,
            rows=rows,
        )
        if normalized is not None:
            candidate = normalized
            errors = _schema_errors("chunk_summary_v1", candidate)
    if errors:
        raise ValidationError("; ".join(errors))
    _verify_source_bounds(candidate, chunk)
    _verify_quotes(candidate, rows)
    findings = scan_text(
        "deep_compaction_chunk_summary",
        _candidate_text(candidate),
        source_id=chunk.chunk_id,
        trusted_tool_result=False,
    )
    if findings:
        return (
            None,
            _sanitize_quarantine(
                chunk=chunk, findings=findings, source_hash=ingest.stats.sha256
            ),
        )
    redacted = _redact_value(candidate, redactor)
    if isinstance(redacted, dict):
        return redacted, None
    raise DocumentCompactionError("redaction produced non-object candidate")

def _process_chunk(
    *,
    base: Path,
    model: DocumentTextModel,
    task: str,
    ingest: LargeDocumentIngestResult,
    document_path: Path,
    chunk: ChunkPlan,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any] | None]:
    redactor = Redactor.from_config_path(ContextPaths.at(base).redaction_yaml)
    raw_chunk, rows = _slice_text(document_path, chunk)
    local_candidate = _local_relevance_candidate(
        task=task,
        ingest=ingest,
        chunk=chunk,
        rows=rows,
    )
    if local_candidate is not None:
        try:
            summary, quarantine = _finalize_chunk_candidate(
                candidate=local_candidate,
                ingest=ingest,
                chunk=chunk,
                rows=rows,
                redactor=redactor,
            )
            return summary, None, quarantine
        except (DocumentCompactionError, ValidationError) as exc:
            return (
                None,
                _sanitize_failure(
                    chunk=chunk,
                    stage="validation",
                    reason=str(exc),
                    source_hash=ingest.stats.sha256,
                ),
                None,
            )
    last_error: tuple[str, str] | None = None
    for attempt in range(2):
        try:
            candidate = _extract_chunk_once(
                model=model,
                task=task,
                ingest=ingest,
                chunk=chunk,
                raw_chunk=raw_chunk,
            )
            summary, quarantine = _finalize_chunk_candidate(
                candidate=candidate,
                ingest=ingest,
                chunk=chunk,
                rows=rows,
                redactor=redactor,
            )
            return summary, None, quarantine
        except (DocumentCompactionError, TextModelError, ValidationError) as exc:
            last_error = ("validation", str(exc))
            if attempt == 0:
                continue
    stage, reason = last_error or ("unknown", "unknown chunk extraction failure")
    return (
        None,
        _sanitize_failure(
            chunk=chunk, stage=stage, reason=reason, source_hash=ingest.stats.sha256
        ),
        None,
    )

def _halve_chunk(chunk: ChunkPlan) -> list[ChunkPlan]:
    if chunk.line_start >= chunk.line_end:
        return []
    midpoint = (chunk.line_start + chunk.line_end) // 2
    return [
        ChunkPlan(
            chunk_id=f"{chunk.chunk_id}_a",
            line_start=chunk.line_start,
            line_end=midpoint,
            approx_tokens=max(1, chunk.approx_tokens // 2),
        ),
        ChunkPlan(
            chunk_id=f"{chunk.chunk_id}_b",
            line_start=midpoint + 1,
            line_end=chunk.line_end,
            approx_tokens=max(1, chunk.approx_tokens // 2),
        ),
    ]

def _update_topic_index(path: Path, summary: dict[str, Any]) -> None:
    chunk_id = str(summary.get("chunk_id") or "")
    for term in sorted(_topic_terms(summary)):
        append_jsonl(path, {"term": term, "chunk_id": chunk_id})

def _processed_chunk_ids(
    *,
    summaries: list[dict[str, Any]],
    failures: list[dict[str, Any]],
    quarantined: list[dict[str, Any]],
) -> set[str]:
    processed: set[str] = set()
    for collection in (summaries, failures, quarantined):
        for item in collection:
            chunk_id = item.get("chunk_id")
            if isinstance(chunk_id, str) and chunk_id:
                processed.add(chunk_id)
    return processed

def _has_split_children(chunk_id: str, chunks: list[ChunkPlan]) -> bool:
    prefix = f"{chunk_id}_"
    return any(chunk.chunk_id.startswith(prefix) for chunk in chunks)
