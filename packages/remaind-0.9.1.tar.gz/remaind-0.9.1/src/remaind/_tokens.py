"""Token estimators.

Remaind uses conservative local estimators instead of model SDK tokenizers.
``approx_chars_div_4`` is ``ceil(len(text) / 4)`` and intentionally
over-estimates relative to many real tokenizers. ``model_profile_or_approx`` is
the production-safe compaction estimator name used in bundled thresholds; until
a selected runtime provides a real tokenizer profile, it resolves to the same
conservative approximation.
"""

from __future__ import annotations

import json
import math
from typing import Any

APPROX_CHARS_DIV_4 = "approx_chars_div_4"
MODEL_PROFILE_OR_APPROX = "model_profile_or_approx"
KNOWN_METHODS: tuple[str, ...] = (APPROX_CHARS_DIV_4, MODEL_PROFILE_OR_APPROX)


def estimate_tokens_chars_div_4(text: str) -> int:
    """``ceil(len(text) / 4)``. Returns 0 for empty input."""
    if not text:
        return 0
    return math.ceil(len(text) / 4)


def serialize_for_estimate(obj: Any) -> str:
    """Canonical string form used when estimating non-string inputs."""
    if isinstance(obj, str):
        return obj
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def estimate_tokens(content: Any, *, method: str = APPROX_CHARS_DIV_4) -> int:
    """Estimate the token count of ``content`` using ``method``."""
    if method not in KNOWN_METHODS:
        raise ValueError(
            f"unknown token estimator method: {method!r}. "
            f"Known methods: {', '.join(KNOWN_METHODS)}"
        )
    return estimate_tokens_chars_div_4(serialize_for_estimate(content))
