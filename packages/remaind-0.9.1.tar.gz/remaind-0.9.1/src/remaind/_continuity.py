"""Project-continuity scorecards, evidence maps, memory tools, and adapters.

Remaind's continuity layer answers a different question than generic memory:
can a fresh agent resume the right product work with grounded evidence? This
module exposes the deterministic product surface for that contract. It reads
the existing .context artifacts as the source of truth, writes agent-facing
updates through the normal event/progress/memory paths, and exports portable
context files for other coding agents without making those files authoritative.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

from ._atomic import atomic_write_text
from ._db import Memory, insert_memory, open_db
from ._errors import RemaindError
from ._events import EventInput, EventWriter
from ._jsonl import iter_jsonl
from ._memory_records import (
    MemoryRecordSource,
    backfill_memory_records,
    make_memory_record,
    memory_record_id_for_source,
    search_memory_records,
    upsert_memory_record,
)
from ._paths import ContextPaths
from ._plan_reconciliation import (
    load_plan_reconciliation,
    render_plan_reconciliation,
)
from ._product_status import load_product_status, render_product_status
from ._progress import load_progress_snapshot, record_progress_snapshot
from ._state_writer import update_state
from ._timestamps import utc_now_iso
from ._tokens import estimate_tokens
from ._ulid import new_ulid

CONTINUITY_SCHEMA_VERSION = "1.0.0"

ContinuityMetricKey = Literal[
    "continuity_success_rate",
    "next_step_accuracy",
    "blocker_awareness",
    "stale_truth_rejection",
    "source_coverage",
    "packet_efficiency",
    "recovery_integrity",
]

AdapterTarget = Literal[
    "claude-code",
    "cursor",
    "windsurf",
    "codex",
    "qwen-code",
    "langgraph",
    "mcp",
]

ADAPTER_TARGETS: tuple[AdapterTarget, ...] = (
    "claude-code",
    "cursor",
    "windsurf",
    "codex",
    "qwen-code",
    "langgraph",
    "mcp",
)

_MISSING = "(not captured)"
_GENERIC_NEXT_STEP_MARKERS = (
    "review the workspace product plan",
    "continue the product plan",
    "capture the product goal",
    "no pending plan item",
)


class ContinuityError(RemaindError):
    """Raised when continuity tooling cannot safely read or write context."""


@dataclass(frozen=True)
class ContinuityMetric:
    key: ContinuityMetricKey
    label: str
    score: float
    passed: bool
    detail: str
    evidence: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ContinuityScorecard:
    schema_version: str
    generated_at: str
    workspace: Path
    overall_score: float
    passed: bool
    metrics: tuple[ContinuityMetric, ...]
    next_step: str
    blocker: str
    evidence_links: int

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["workspace"] = str(self.workspace)
        payload["metrics"] = [metric.to_dict() for metric in self.metrics]
        return payload


@dataclass(frozen=True)
class EvidenceLink:
    id: str
    relationship: str
    claim: str
    source: str
    authority: str
    freshness: str
    note: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AdapterExportResult:
    base: Path
    output_dir: Path
    files: tuple[Path, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "base": str(self.base),
            "output_dir": str(self.output_dir),
            "files": [str(path) for path in self.files],
        }


@dataclass(frozen=True)
class MemoryToolResult:
    action: str
    message: str
    event_id: str | None = None
    memory_id: str | None = None
    progress_operation_id: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_continuity_scorecard(base: Path) -> ContinuityScorecard:
    """Build a transparent continuity scorecard from current .context state."""

    base = Path(base).resolve()
    backfill_memory_records(base)
    paths = ContextPaths.at(base)
    product_status = load_product_status(base)
    plan_reconciliation = load_plan_reconciliation(base)
    progress = load_progress_snapshot(base)
    evidence = build_evidence_map(base)
    packet_tokens, packet_cap = _resume_packet_numbers(paths.resume_packet)
    metrics = (
        _metric_continuity_anchors(paths, product_status, plan_reconciliation, progress),
        _metric_next_step(plan_reconciliation, product_status),
        _metric_blocker_awareness(plan_reconciliation, product_status, progress),
        _metric_stale_truth(plan_reconciliation, product_status),
        _metric_source_coverage(plan_reconciliation, evidence),
        _metric_packet_efficiency(paths.resume_packet, packet_tokens, packet_cap),
        _metric_recovery_integrity(paths),
    )
    overall = round(sum(metric.score for metric in metrics) / len(metrics), 4)
    next_step = _current_next_step(plan_reconciliation, product_status)
    blocker = _current_blocker(plan_reconciliation, product_status, progress)
    return ContinuityScorecard(
        schema_version=CONTINUITY_SCHEMA_VERSION,
        generated_at=utc_now_iso(),
        workspace=base,
        overall_score=overall,
        passed=all(metric.passed for metric in metrics),
        metrics=metrics,
        next_step=next_step,
        blocker=blocker,
        evidence_links=len(evidence),
    )


def render_scorecard(scorecard: ContinuityScorecard) -> str:
    """Render a human-readable continuity scorecard."""

    rows = [
        "Remaind Continuity Scorecard",
        f"Workspace: {scorecard.workspace}",
        f"Overall: {_pct(scorecard.overall_score)} ({'pass' if scorecard.passed else 'needs attention'})",
        f"Current blocker: {scorecard.blocker or '(none)'}",
        f"Next step: {scorecard.next_step or _MISSING}",
        f"Evidence links: {scorecard.evidence_links}",
        "",
    ]
    for metric in scorecard.metrics:
        marker = "ok" if metric.passed else "CHECK"
        rows.append(f"{marker:5} {_pct(metric.score):>4} {metric.label}")
        rows.append(f"      {metric.detail}")
        for item in metric.evidence[:3]:
            rows.append(f"      evidence: {item}")
    rows.append("")
    return "\n".join(rows)


def build_evidence_map(base: Path) -> list[EvidenceLink]:
    """Return source-visible continuity evidence links."""

    base = Path(base).resolve()
    backfill_memory_records(base)
    paths = ContextPaths.at(base)
    links: list[EvidenceLink] = []
    product_status = load_product_status(base)
    plan_reconciliation = load_plan_reconciliation(base)
    progress = load_progress_snapshot(base)

    if product_status:
        links.extend(_product_status_links(product_status))
    if plan_reconciliation:
        links.extend(_plan_reconciliation_links(plan_reconciliation))
    if progress:
        links.extend(_progress_links(progress))
    links.extend(_memory_record_links(base))
    links.extend(_event_links(paths.events_jsonl))
    links.extend(_memory_links(base))
    return _dedupe_links(links)


def render_evidence_map(links: list[EvidenceLink]) -> str:
    """Render evidence relationships as a concise audit table."""

    rows = [
        "Remaind Evidence Map",
        "claim -> source evidence",
        "",
    ]
    if not links:
        rows.append("(no continuity evidence has been captured yet)")
        rows.append("")
        return "\n".join(rows)
    for link in links:
        rows.append(f"- {link.relationship}: {link.claim}")
        rows.append(f"  source: {link.source}")
        rows.append(f"  authority: {link.authority}; freshness: {link.freshness}")
        if link.note:
            rows.append(f"  note: {link.note}")
    rows.append("")
    return "\n".join(rows)


def render_current_plan(base: Path) -> str:
    """Render the current plan state for an agent-facing memory tool."""

    plan = load_plan_reconciliation(base)
    status = load_product_status(base)
    if plan:
        return render_plan_reconciliation(plan)
    if status:
        return render_product_status(status)
    return (
        "No current product plan has been captured yet. Add a PLAN, STATUS, "
        "TODO, HANDOVER, CLAUDE, AGENTS, README, docs, or experiment file, "
        "then run `remaind launch` or `remaind continuity scorecard` again.\n"
    )


def mark_task_blocked(
    base: Path,
    *,
    task: str,
    reason: str,
    workspace_query: str | None = None,
) -> MemoryToolResult:
    """Record a blocker and update product status + plan reconciliation."""

    _require_initialized_context(base)
    task_text = _clean(task)
    reason_text = _clean(reason)
    if not task_text:
        raise ValueError("task must not be empty")
    if not reason_text:
        raise ValueError("reason must not be empty")
    operation_id = f"continuity_blocked_{new_ulid()}"
    snapshot = record_progress_snapshot(
        base,
        operation_id=operation_id,
        phase="blocked",
        task=task_text,
        model_error=reason_text,
        metadata={
            "operation_kind": "agent_memory_tool",
            "workspace_query": workspace_query or "",
            "tool": "mark_task_blocked",
        },
    )
    upsert_memory_record(
        base,
        make_memory_record(
            kind="blocker",
            subject=task_text,
            who="agent",
            what=reason_text,
            when_text=str(snapshot.get("updated_at") or ""),
            where_text=str(base),
            why=f"Task remained incomplete: {task_text}",
            how=f"Fix the blocker, then retry: {task_text}",
            status="blocked",
            confidence=0.95,
            importance=3,
            entities=tuple([task_text, reason_text]),
            sources=(
                MemoryRecordSource(
                    source_id=operation_id,
                    source_kind="progress_snapshot",
                    source_path=str(ContextPaths.at(base).progress_jsonl),
                    source_excerpt=json.dumps(snapshot, sort_keys=True)[:900],
                ),
            ),
            record_id=memory_record_id_for_source("blocker", operation_id),
        ),
    )
    return MemoryToolResult(
        action="mark_task_blocked",
        message=f"Blocked task recorded: {task_text}",
        progress_operation_id=operation_id,
        payload=snapshot,
    )


def record_decision(base: Path, *, text: str) -> MemoryToolResult:
    """Append a durable decision event and mirror it into active state."""

    _require_initialized_context(base)
    decision = _clean(text)
    if not decision:
        raise ValueError("decision text must not be empty")
    event = _append_event(
        base,
        event_type="decision",
        actor="agent",
        summary=f"Decision recorded: {decision[:140]}",
        content=decision,
        importance=3,
        tags=["decision", "continuity"],
        source="remaind memory decision",
    )
    upsert_memory_record(
        base,
        make_memory_record(
            kind="decision",
            subject=decision[:120],
            who="agent",
            what=decision,
            when_text=str(event.get("timestamp") or ""),
            where_text="remaind memory decision",
            why="Recorded through the agent-facing memory decision tool.",
            how="Apply this decision unless a newer source supersedes it.",
            status="current",
            confidence=0.96,
            importance=3,
            source_event_ids=(str(event["id"]),),
            entities=tuple(decision.split()[:8]),
            sources=(
                MemoryRecordSource(
                    source_id=str(event["id"]),
                    source_kind="event",
                    source_path=str(ContextPaths.at(base).events_jsonl),
                    source_excerpt=decision[:900],
                ),
            ),
            record_id=memory_record_id_for_source("decision", str(event["id"])),
        ),
    )
    update_state(
        base,
        lambda state: {
            **state,
            "decisions": _append_unique(state.get("decisions"), decision),
            "latest_user_instruction_event_id": event["id"],
            "updated_at": utc_now_iso(),
        },
    )
    return MemoryToolResult(
        action="record_decision",
        message="Decision recorded.",
        event_id=str(event["id"]),
        payload={"decision": decision},
    )


def promote_to_memory(
    base: Path,
    *,
    text: str,
    rationale: str | None = None,
    tags: list[str] | None = None,
) -> MemoryToolResult:
    """Promote a durable fact/workflow note into the SQLite memory index."""

    _require_initialized_context(base)
    content = _clean(text)
    if not content:
        raise ValueError("memory text must not be empty")
    event = _append_event(
        base,
        event_type="decision",
        actor="agent",
        summary=f"Promote durable memory: {content[:140]}",
        content=content,
        importance=3,
        tags=["memory", "continuity", *(tags or [])],
        source="remaind memory promote",
    )
    now = utc_now_iso()
    memory = Memory(
        id=f"mem_{new_ulid()}",
        memory_type="fact",
        content=content,
        rationale=_clean(rationale) or f"Promoted from event {event['id']}.",
        confidence=0.95,
        importance=3,
        created_at=now,
        updated_at=now,
        last_accessed_at=now,
        source_event_ids=[str(event["id"])],
        tags=["continuity", *(tags or [])],
    )
    conn = open_db(base)
    try:
        insert_memory(conn, memory)
    finally:
        conn.close()
    upsert_memory_record(
        base,
        make_memory_record(
            kind="note",
            subject=content[:120],
            who="agent",
            what=content,
            when_text=str(event.get("timestamp") or ""),
            where_text="remaind memory promote",
            why=rationale or "Promoted as durable continuity memory.",
            how="Use as source-linked continuity evidence.",
            status="current",
            confidence=0.95,
            importance=3,
            source_event_ids=(str(event["id"]),),
            entities=tuple([*(tags or []), *content.split()[:8]]),
            sources=(
                MemoryRecordSource(
                    source_id=str(event["id"]),
                    source_kind="event",
                    source_path=str(ContextPaths.at(base).events_jsonl),
                    source_excerpt=content[:900],
                ),
            ),
            record_id=memory_record_id_for_source("note", str(event["id"])),
        ),
    )
    return MemoryToolResult(
        action="promote_to_memory",
        message="Durable memory promoted.",
        event_id=str(event["id"]),
        memory_id=memory.id,
        payload=memory.to_dict(),
    )


def render_changes_since_last_session(base: Path, *, limit: int = 12) -> str:
    """Render recent high-signal continuity changes."""

    paths = ContextPaths.at(Path(base))
    events = _recent_events(paths.events_jsonl, limit=limit)
    rows = [
        "Remaind Changes Since Last Session",
        "",
    ]
    progress = load_progress_snapshot(base)
    if progress:
        rows.extend(
            [
                f"Latest progress: {_field(progress, 'phase')} / {_field(progress, 'status')}",
                f"Task: {_progress_task(progress)}",
                f"Blocker: {_field(progress, 'error_or_blocker')}",
                "",
            ]
        )
    if not events:
        rows.append("No high-signal events found yet.")
        rows.append("")
        return "\n".join(rows)
    for event in events:
        rows.append(
            f"- {event.get('timestamp', '?')} [{event.get('type', '?')}] "
            f"{event.get('summary', '')}"
        )
    rows.append("")
    return "\n".join(rows)


def export_adapters(
    base: Path,
    *,
    targets: list[str] | None = None,
    output_dir: Path | None = None,
) -> AdapterExportResult:
    """Export current continuity state into cross-tool adapter files."""

    base = Path(base).resolve()
    _require_initialized_context(base)
    selected = _normalize_targets(targets)
    output = (
        Path(output_dir).resolve()
        if output_dir is not None
        else ContextPaths.at(base).root / "adapters"
    )
    scorecard = build_continuity_scorecard(base)
    evidence = build_evidence_map(base)
    markdown = _adapter_markdown(base, scorecard, evidence)
    files: list[Path] = []
    for target in selected:
        files.extend(_write_adapter(target, output, markdown, scorecard, evidence))
    return AdapterExportResult(base=base, output_dir=output, files=tuple(files))


def _metric_continuity_anchors(
    paths: ContextPaths,
    product_status: dict[str, Any] | None,
    plan_reconciliation: dict[str, Any] | None,
    progress: dict[str, Any] | None,
) -> ContinuityMetric:
    anchors = {
        "product_status": product_status is not None,
        "plan_reconciliation": plan_reconciliation is not None,
        "events_log": paths.events_jsonl.is_file(),
        "progress_or_resume": progress is not None or paths.resume_packet.is_file(),
    }
    score = sum(1 for ok in anchors.values() if ok) / len(anchors)
    missing = [name for name, ok in anchors.items() if not ok]
    detail = (
        "All mandatory continuity anchors are present."
        if not missing
        else "Missing anchors: " + ", ".join(missing)
    )
    return ContinuityMetric(
        key="continuity_success_rate",
        label="Continuity success readiness",
        score=score,
        passed=score == 1.0,
        detail=detail,
        evidence=tuple(name for name, ok in anchors.items() if ok),
    )


def _metric_next_step(
    plan: dict[str, Any] | None,
    status: dict[str, Any] | None,
) -> ContinuityMetric:
    next_step = _current_next_step(plan, status)
    score = 1.0 if next_step and not _is_generic_next_step(next_step) else 0.0
    detail = (
        f"Grounded next step: {next_step}"
        if score
        else "No specific next step is grounded in current continuity state."
    )
    evidence = []
    if plan:
        evidence.append("active/plan_reconciliation.json")
    if status:
        evidence.append("active/product_status.json")
    return ContinuityMetric(
        key="next_step_accuracy",
        label="Next-step accuracy",
        score=score,
        passed=score >= 1.0,
        detail=detail,
        evidence=tuple(evidence),
    )


def _metric_blocker_awareness(
    plan: dict[str, Any] | None,
    status: dict[str, Any] | None,
    progress: dict[str, Any] | None,
) -> ContinuityMetric:
    blocker = _current_blocker(plan, status, progress)
    if not blocker:
        return ContinuityMetric(
            key="blocker_awareness",
            label="Blocker awareness",
            score=1.0,
            passed=True,
            detail="No active blocker is recorded.",
            evidence=("active/product_status.json",) if status else (),
        )
    raw_items = plan.get("items") if isinstance(plan, dict) else []
    items = raw_items if isinstance(raw_items, list) else []
    has_blocked_item = any(
        isinstance(item, dict) and item.get("status") == "blocked"
        for item in items
    )
    fix = _field(plan or status or {}, "fix_instruction")
    score = 1.0 if has_blocked_item and fix != _MISSING else 0.5 if fix != _MISSING else 0.0
    return ContinuityMetric(
        key="blocker_awareness",
        label="Blocker awareness",
        score=score,
        passed=score >= 1.0,
        detail=f"Active blocker: {blocker}; recovery instruction: {fix}",
        evidence=("active/plan_reconciliation.json", "active/progress_snapshot.json"),
    )


def _metric_stale_truth(
    plan: dict[str, Any] | None,
    status: dict[str, Any] | None,
) -> ContinuityMetric:
    authority_files = plan.get("authority_files") if isinstance(plan, dict) else []
    source = _field(status or {}, "source")
    operation_kind = _field(status or {}, "operation_kind")
    has_authority = isinstance(authority_files, list) and len(authority_files) > 0
    not_memory_question_state = operation_kind != "memory_question"
    if has_authority and not_memory_question_state:
        score = 1.0
        detail = "Current state is anchored to product authority files and not a generated memory-question answer."
    elif has_authority:
        score = 0.75
        detail = "Product authority files exist; latest status came from a memory question and must stay lower authority."
    else:
        score = 0.25 if source != _MISSING else 0.0
        detail = "No product authority file is recorded, so stale generated answers are harder to demote."
    return ContinuityMetric(
        key="stale_truth_rejection",
        label="Stale-truth rejection",
        score=score,
        passed=score >= 0.75,
        detail=detail,
        evidence=tuple(str(path) for path in authority_files[:5]) if isinstance(authority_files, list) else (),
    )


def _metric_source_coverage(
    plan: dict[str, Any] | None,
    evidence: list[EvidenceLink],
) -> ContinuityMetric:
    items = plan.get("items") if isinstance(plan, dict) else []
    plan_items = [item for item in items if isinstance(item, dict)] if isinstance(items, list) else []
    covered = [
        item for item in plan_items
        if _field(item, "source") != _MISSING and _field(item, "line_number") != _MISSING
    ]
    if plan_items:
        score = len(covered) / len(plan_items)
        detail = f"{len(covered)}/{len(plan_items)} plan items link to source file lines."
    else:
        score = 0.0
        detail = "No structured plan items are available to link to source evidence."
    if evidence and score < 1.0:
        score = max(score, min(0.5, len(evidence) / 20))
    return ContinuityMetric(
        key="source_coverage",
        label="Source coverage",
        score=round(score, 4),
        passed=score >= 0.8,
        detail=detail,
        evidence=tuple(link.source for link in evidence[:5]),
    )


def _metric_packet_efficiency(
    packet_path: Path,
    token_count: int | None,
    token_cap: int | None,
) -> ContinuityMetric:
    if not packet_path.is_file() or token_count is None:
        return ContinuityMetric(
            key="packet_efficiency",
            label="Packet efficiency",
            score=0.0,
            passed=False,
            detail="No active resume packet exists yet.",
            evidence=(),
        )
    if token_cap is None or token_cap <= 0:
        return ContinuityMetric(
            key="packet_efficiency",
            label="Packet efficiency",
            score=0.75,
            passed=True,
            detail=f"Resume packet exists with {token_count} estimated tokens; cap unavailable.",
            evidence=(str(packet_path),),
        )
    ratio = token_count / token_cap
    score = max(0.0, min(1.0, 1.0 - max(ratio - 0.70, 0.0)))
    return ContinuityMetric(
        key="packet_efficiency",
        label="Packet efficiency",
        score=round(score, 4),
        passed=token_count <= token_cap,
        detail=f"Resume packet uses {token_count}/{token_cap} estimated tokens.",
        evidence=(str(packet_path),),
    )


def _metric_recovery_integrity(paths: ContextPaths) -> ContinuityMetric:
    histories = {
        "state": (paths.history_dir / "state").is_dir(),
        "product_status": (paths.history_dir / "product_status").is_dir(),
        "plan_reconciliation": (paths.history_dir / "plan_reconciliation").is_dir(),
        "progress_snapshot": (paths.history_dir / "progress_snapshot").is_dir(),
    }
    rollback_events = [
        event for event in _iter_valid_events(paths.events_jsonl)
        if event.get("type") == "rollback"
    ]
    score = sum(1 for ok in histories.values() if ok) / len(histories)
    if rollback_events:
        score = 1.0
    missing = [name for name, ok in histories.items() if not ok]
    detail = (
        "Rollback event exists and append-only history is available."
        if rollback_events
        else (
            "Snapshot histories available for rollback."
            if not missing
            else "Missing snapshot histories: " + ", ".join(missing)
        )
    )
    return ContinuityMetric(
        key="recovery_integrity",
        label="Recovery integrity",
        score=round(score, 4),
        passed=score >= 0.75,
        detail=detail,
        evidence=tuple(name for name, ok in histories.items() if ok),
    )


def _product_status_links(status: dict[str, Any]) -> list[EvidenceLink]:
    fields = (
        ("plan_focus", "current_development_plan_focus", "status -> product status"),
        ("plan_progress", "plan_status_and_progress", "progress -> product status"),
        ("blocker", "error_or_blocker", "blocker -> product status"),
        ("next_step", "aligned_next_plan_step", "next step -> product status"),
    )
    links = []
    for link_id, field_name, relationship in fields:
        value = _field(status, field_name)
        if value == _MISSING:
            continue
        links.append(
            EvidenceLink(
                id=f"product_status:{link_id}",
                relationship=relationship,
                claim=value,
                source="active/product_status.json",
                authority="derived_memory",
                freshness="current",
                note="latest durable product-continuation status",
            )
        )
    return links


def _plan_reconciliation_links(plan: dict[str, Any]) -> list[EvidenceLink]:
    links: list[EvidenceLink] = []
    next_step = _field(plan, "aligned_next_plan_step")
    if next_step != _MISSING:
        links.append(
            EvidenceLink(
                id="plan_reconciliation:next_step",
                relationship="next step -> reconciled plan",
                claim=next_step,
                source="active/plan_reconciliation.json",
                authority="product_authority",
                freshness="current",
                note="computed from product status, project plan files, and blocker state",
            )
        )
    items = plan.get("items")
    if isinstance(items, list):
        for index, item in enumerate(items[:40], start=1):
            if not isinstance(item, dict):
                continue
            text = _field(item, "text")
            if text == _MISSING:
                continue
            source = _field(item, "source")
            line = _field(item, "line_number")
            status = _field(item, "status")
            links.append(
                EvidenceLink(
                    id=f"plan_item:{index}",
                    relationship="plan item -> source line",
                    claim=f"{status}: {text}",
                    source=f"{source}:{line}",
                    authority="product_authority",
                    freshness="current",
                    note="; ".join(str(x) for x in item.get("evidence") or [])[:400],
                )
            )
    return links


def _progress_links(progress: dict[str, Any]) -> list[EvidenceLink]:
    links: list[EvidenceLink] = []
    blocker = _field(progress, "error_or_blocker")
    if blocker != _MISSING:
        links.append(
            EvidenceLink(
                id="progress:blocker",
                relationship="blocker -> failed command/result",
                claim=blocker,
                source="active/progress_snapshot.json",
                authority="source_evidence",
                freshness="current",
                note=f"incomplete task: {_field(progress, 'incomplete_task_due_to_blocker')}",
            )
        )
    phase = _field(progress, "phase")
    if phase != _MISSING:
        links.append(
            EvidenceLink(
                id="progress:phase",
                relationship="latest work -> progress checkpoint",
                claim=f"{phase}: {_progress_task(progress)}",
                source="active/progress_snapshot.json",
                authority="source_evidence",
                freshness="current",
                note="crash-safe operation checkpoint",
            )
        )
    return links


def _memory_record_links(base: Path) -> list[EvidenceLink]:
    records = search_memory_records(
        base,
        "",
        statuses=("current", "tentative", "blocked", "resolved", "superseded", "stale"),
        limit=80,
    )
    links: list[EvidenceLink] = []
    for record in records:
        source_bits = [
            f"{source.source_kind}:{source.source_id}" for source in record.sources[:3]
        ]
        links.append(
            EvidenceLink(
                id=f"memory_record:{record.id}",
                relationship=f"{record.kind} -> structured memory source",
                claim=f"{record.status}: {record.subject} — {record.what}",
                source=", ".join(source_bits) or ", ".join(record.source_event_ids),
                authority="derived_memory",
                freshness="recent" if record.status != "stale" else "historical",
                note=(
                    f"who={record.who}; when={record.when_text}; "
                    f"why={record.why or '(not captured)'}"
                ),
            )
        )
    return links


def _event_links(path: Path) -> list[EvidenceLink]:
    links: list[EvidenceLink] = []
    for lineno, event in enumerate(_iter_valid_events(path), start=1):
        event_type = str(event.get("type") or "")
        if event_type not in {"decision", "rollback", "command_output", "memory"}:
            continue
        raw_tags = event.get("tags")
        tags = raw_tags if isinstance(raw_tags, list) else []
        relationship = {
            "decision": "decision -> source event",
            "rollback": "rollback -> source event",
            "command_output": "tool result -> source event",
        }.get(event_type, "event -> source log")
        links.append(
            EvidenceLink(
                id=f"event:{event.get('id', lineno)}",
                relationship=relationship,
                claim=str(event.get("summary") or ""),
                source=f"logs/events.jsonl:{lineno}",
                authority="source_evidence",
                freshness="recent",
                note=", ".join(str(tag) for tag in tags[:8]),
            )
        )
    return links[-80:]


def _memory_links(base: Path) -> list[EvidenceLink]:
    paths = ContextPaths.at(base)
    if not paths.db_sqlite.exists():
        return []
    links: list[EvidenceLink] = []
    conn = open_db(base)
    try:
        rows = conn.execute(
            """
            SELECT id, content, source_event_ids, updated_at, tags
            FROM memories
            ORDER BY updated_at DESC, id DESC
            LIMIT 80
            """
        ).fetchall()
    except sqlite3.DatabaseError:
        return []
    finally:
        conn.close()
    for row in rows:
        source_ids = _loads_list(row["source_event_ids"])
        links.append(
            EvidenceLink(
                id=f"memory:{row['id']}",
                relationship="memory -> source event",
                claim=str(row["content"]),
                source=", ".join(source_ids) if source_ids else "memories row without source_event_ids",
                authority="derived_memory",
                freshness="recent",
                note=str(row["tags"] or ""),
            )
        )
    return links


def _adapter_markdown(
    base: Path,
    scorecard: ContinuityScorecard,
    evidence: list[EvidenceLink],
) -> str:
    plan = load_plan_reconciliation(base)
    status = load_product_status(base)
    rows = [
        "# Remaind Continuity Context",
        "",
        "This file is generated from Remaind. Treat `.context/` as the source of truth.",
        "",
        "## Current Continuity Summary",
        "",
        f"- Workspace: {base}",
        f"- Overall score: {_pct(scorecard.overall_score)}",
        f"- Current blocker: {scorecard.blocker or '(none)'}",
        f"- Next step: {scorecard.next_step or _MISSING}",
        "",
        "## Authority Rules",
        "",
        "- Prefer current user instructions over all historical state.",
        "- Prefer product plan/status files and Remaind plan reconciliation over old packets or model answers.",
        "- Treat generated answers as lower authority than source events, plan files, progress snapshots, and handovers.",
        "- If evidence is missing, say what is missing instead of guessing.",
        "",
    ]
    if plan:
        rows.extend(["## Product Plan Reconciliation", "", render_plan_reconciliation(plan).strip(), ""])
    elif status:
        rows.extend(["## Product Status", "", render_product_status(status).strip(), ""])
    rows.extend(["## Continuity Scorecard", ""])
    for metric in scorecard.metrics:
        rows.append(f"- {_pct(metric.score)} {metric.label}: {metric.detail}")
    rows.extend(["", "## Evidence Links", ""])
    for link in evidence[:30]:
        rows.append(f"- {link.relationship}: {link.claim} [{link.source}]")
    rows.append("")
    return "\n".join(rows)


def _write_adapter(
    target: AdapterTarget,
    output: Path,
    markdown: str,
    scorecard: ContinuityScorecard,
    evidence: list[EvidenceLink],
) -> list[Path]:
    if target == "claude-code":
        path = output / "claude-code" / "CLAUDE.md"
        return [_write(path, markdown)]
    if target == "cursor":
        path = output / "cursor" / ".cursor" / "rules" / "remaind-continuity.mdc"
        content = (
            "---\n"
            "description: Current Remaind continuity state for this project\n"
            "alwaysApply: true\n"
            "---\n\n"
            + markdown
        )
        return [_write(path, content)]
    if target == "windsurf":
        path = output / "windsurf" / ".windsurf" / "rules" / "remaind-continuity.md"
        return [_write(path, markdown)]
    if target == "codex":
        path = output / "codex" / "AGENTS.md"
        return [_write(path, markdown)]
    if target == "qwen-code":
        path = output / "qwen-code" / "QWEN.md"
        return [_write(path, markdown)]
    if target == "langgraph":
        path = output / "langgraph" / "remaind_continuity_state.json"
        payload = {
            "scorecard": scorecard.to_dict(),
            "evidence": [link.to_dict() for link in evidence],
            "generated_at": utc_now_iso(),
        }
        return [_write(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")]
    if target == "mcp":
        path = output / "mcp" / "remaind-context.resources.json"
        payload = {
            "schema_version": CONTINUITY_SCHEMA_VERSION,
            "resources": [
                {
                    "uri": "remaind://continuity/scorecard",
                    "name": "Remaind Continuity Scorecard",
                    "mimeType": "application/json",
                    "text": json.dumps(scorecard.to_dict(), sort_keys=True),
                },
                {
                    "uri": "remaind://continuity/evidence",
                    "name": "Remaind Evidence Map",
                    "mimeType": "application/json",
                    "text": json.dumps([link.to_dict() for link in evidence], sort_keys=True),
                },
                {
                    "uri": "remaind://continuity/context",
                    "name": "Remaind Continuity Context",
                    "mimeType": "text/markdown",
                    "text": markdown,
                },
            ],
        }
        return [_write(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")]
    raise ValueError(f"unsupported adapter target: {target}")


def _write(path: Path, content: str) -> Path:
    atomic_write_text(path, content)
    return path


def _normalize_targets(targets: list[str] | None) -> tuple[AdapterTarget, ...]:
    if not targets or "all" in targets:
        return ADAPTER_TARGETS
    normalized: list[AdapterTarget] = []
    for target in targets:
        if target not in ADAPTER_TARGETS:
            raise ValueError(f"unsupported adapter target: {target}")
        normalized.append(target)
    return tuple(dict.fromkeys(normalized))


def _append_event(
    base: Path,
    *,
    event_type: str,
    actor: str,
    summary: str,
    content: str,
    importance: int,
    tags: list[str],
    source: str,
) -> dict[str, Any]:
    state = _load_state(base)
    return EventWriter.open(base).append(
        EventInput(
            type=event_type,
            actor=actor,
            summary=summary,
            content=content,
            importance=importance,
            session_id=str(state.get("session_id") or "unknown"),
            task_id=str(state.get("task_id") or "unknown"),
            tags=tags,
            source=source,
            metadata={"continuity_tool": True},
        )
    )


def _load_state(base: Path) -> dict[str, Any]:
    path = ContextPaths.at(base).state_json
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ContinuityError(
            f"{ContextPaths.at(base).root} is not initialized; run `remaind init --path {base}` first"
        ) from exc
    return payload if isinstance(payload, dict) else {}


def _require_initialized_context(base: Path) -> None:
    paths = ContextPaths.at(Path(base))
    if not paths.state_json.is_file():
        raise ContinuityError(
            f"{paths.root} is not initialized; run `remaind init --path {Path(base)}` first"
        )


def _iter_valid_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [
        obj for _lineno, obj, err in iter_jsonl(path)
        if err is None and obj is not None
    ]


def _recent_events(path: Path, *, limit: int) -> list[dict[str, Any]]:
    events = [
        event for event in _iter_valid_events(path)
        if int(event.get("importance", 0)) >= 2
    ]
    return events[-max(1, limit):]


def _resume_packet_numbers(path: Path) -> tuple[int | None, int | None]:
    if not path.exists():
        return None, None
    text = path.read_text(encoding="utf-8")
    token_count = estimate_tokens(text)
    token_cap: int | None = None
    for line in text.splitlines()[:12]:
        if line.startswith("Token cap:"):
            raw = line.split(":", 1)[1].strip()
            if raw.isdigit():
                token_cap = int(raw)
            break
    return token_count, token_cap


def _current_next_step(
    plan: dict[str, Any] | None,
    status: dict[str, Any] | None,
) -> str:
    for source in (plan, status):
        value = _field(source or {}, "aligned_next_plan_step")
        if value != _MISSING:
            return value
    return ""


def _current_blocker(
    plan: dict[str, Any] | None,
    status: dict[str, Any] | None,
    progress: dict[str, Any] | None,
) -> str:
    for source in (plan, status, progress):
        value = _field(source or {}, "error_or_blocker")
        if value != _MISSING:
            return value
    return ""


def _field(mapping: dict[str, Any], key: str) -> str:
    value = mapping.get(key)
    if value in (None, "", []):
        return _MISSING
    return " ".join(str(value).split())


def _progress_task(progress: dict[str, Any]) -> str:
    for key in (
        "incomplete_task_due_to_blocker",
        "active_task",
        "development_plan_focus",
        "next_plan_step",
    ):
        value = _field(progress, key)
        if value != _MISSING and value != "Initialize Remaind context.":
            return value
    return _MISSING


def _pct(score: float) -> str:
    return f"{round(score * 100):d}%"


def _clean(value: object) -> str:
    return " ".join(str(value or "").split())


def _is_generic_next_step(value: str) -> bool:
    lowered = value.lower()
    return any(marker in lowered for marker in _GENERIC_NEXT_STEP_MARKERS)


def _append_unique(values: object, new_value: str) -> list[str]:
    out: list[str] = []
    if isinstance(values, list):
        out.extend(str(item) for item in values if str(item).strip())
    if new_value not in out:
        out.append(new_value)
    return out


def _loads_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if item]
    if not isinstance(value, str) or not value:
        return []
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(item) for item in parsed if item]


def _dedupe_links(links: list[EvidenceLink]) -> list[EvidenceLink]:
    seen: set[tuple[str, str, str]] = set()
    out: list[EvidenceLink] = []
    for link in links:
        key = (link.relationship, link.claim, link.source)
        if key in seen:
            continue
        seen.add(key)
        out.append(link)
    return out
