"""Trust labels and tamper-evident event chain helpers."""

from __future__ import annotations

import hashlib
import json
from typing import Any

CHAIN_ALGORITHM = "sha256"
GENESIS_HASH = "0" * 64
EVENT_CHAIN_METADATA_KEY = "event_chain"


def event_trust_label(event: dict[str, Any]) -> str:
    """Return a coarse trust label for an event.

    These labels are intentionally mechanical. They are provenance hints for
    retrieval/resume surfaces, not a truth oracle.
    """
    actor = str(event.get("actor") or "")
    source = str(event.get("source") or "")
    event_type = str(event.get("type") or "")

    if event_type == "user_message" and actor == "user":
        return "user"
    if actor.startswith("tool:") or source.startswith("tool:") or event_type == "tool_result":
        return "verified_tool"
    if actor == "system" or source.startswith("remaind"):
        return "system"
    if event_type in {"compaction", "resume"}:
        return "derived"
    if event_type == "assistant_message" or actor == "assistant":
        return "assistant"
    return "untrusted_evidence"


def memory_trust_label(memory: Any) -> str:
    """Return a coarse trust label for a retrieved memory row."""
    source_event_ids = getattr(memory, "source_event_ids", None) or []
    if source_event_ids:
        return "source_linked_memory"
    return "derived_memory"


def canonical_event_payload(event: dict[str, Any]) -> str:
    """Canonical JSON used for event hash-chain digesting.

    Chain metadata itself is excluded so the digest commits to the actual event
    payload without self-reference.
    """
    payload = dict(event)
    metadata = dict(payload.get("metadata") or {})
    metadata.pop(EVENT_CHAIN_METADATA_KEY, None)
    payload["metadata"] = metadata
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def event_payload_hash(event: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_event_payload(event).encode("utf-8")).hexdigest()


def event_chain_hash(previous_hash: str, payload_hash: str) -> str:
    material = f"{CHAIN_ALGORITHM}:{previous_hash}:{payload_hash}".encode()
    return hashlib.sha256(material).hexdigest()


def chain_metadata(previous_hash: str, event: dict[str, Any]) -> dict[str, str]:
    """Build event-chain metadata for ``event``."""
    payload_hash = event_payload_hash(event)
    return {
        "algorithm": CHAIN_ALGORITHM,
        "previous_hash": previous_hash,
        "payload_hash": payload_hash,
        "chain_hash": event_chain_hash(previous_hash, payload_hash),
    }


def validate_chain_metadata(
    event: dict[str, Any], *, previous_hash: str
) -> str | None:
    """Return an error string when event chain metadata is invalid."""
    metadata = event.get("metadata")
    if not isinstance(metadata, dict):
        return "metadata is not an object"
    chain = metadata.get(EVENT_CHAIN_METADATA_KEY)
    if not isinstance(chain, dict):
        return "missing event_chain metadata"
    if chain.get("algorithm") != CHAIN_ALGORITHM:
        return "event_chain algorithm must be sha256"
    if chain.get("previous_hash") != previous_hash:
        return (
            "event_chain previous_hash mismatch: "
            f"expected {previous_hash}, got {chain.get('previous_hash')}"
        )
    payload_hash = event_payload_hash(event)
    if chain.get("payload_hash") != payload_hash:
        return "event_chain payload_hash mismatch"
    chain_hash = event_chain_hash(previous_hash, payload_hash)
    if chain.get("chain_hash") != chain_hash:
        return "event_chain chain_hash mismatch"
    return None
