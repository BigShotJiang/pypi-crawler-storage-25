"""Shared new-idea suggestion judgment for Remaind context packets."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

from ._entity_grounding import entity_anchor_terms, important_entity_terms

_NEW_IDEA_MARKERS = (
    "suggest a new",
    "new idea",
    "new ideas",
    "new way",
    "new ways",
    "something different",
    "fresh idea",
    "fresh way",
    "unique way",
)

_DIRECT_SUGGESTION_MARKERS = (
    "try ",
    "how about",
    "consider",
    "you could",
    "might enjoy",
)

_PADDING_MARKERS = (
    "class",
    "community",
    "group",
    "join",
    "membership",
    "side project",
    "volunteer",
    "workshop",
)

_REPEAT_MARKERS = (
    "again",
    "another",
    "continue",
    "keep",
    "more of",
    "return to",
    "same",
)

_STOP_TERMS = {
    "activity",
    "activities",
    "again",
    "also",
    "answer",
    "could",
    "idea",
    "ideas",
    "might",
    "new",
    "option",
    "something",
    "suggest",
    "suggestion",
    "that",
    "this",
    "try",
    "user",
    "what",
    "with",
    "would",
    "you",
    "your",
}


@dataclass(frozen=True)
class SuggestionNoveltyJudgment:
    score_adjustment: float
    support_refs: int
    overlap_terms: tuple[str, ...]
    novel_terms: tuple[str, ...]
    reasons: tuple[str, ...]
    decision_signal: str


def looks_like_new_idea_request(question: str) -> bool:
    lowered = question.lower()
    return any(marker in lowered for marker in _NEW_IDEA_MARKERS)


def suggestion_novelty_judgments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, SuggestionNoveltyJudgment]:
    evidence_units = [
        re.sub(r"\s+", " ", str(text)).strip().lower()
        for text in evidence_texts
        if str(text).strip()
    ]
    evidence_terms = set(_suggestion_terms(" ".join(evidence_units)))
    evidence_anchors = entity_anchor_terms(" ".join(evidence_units))
    lengths = {letter: len(option_text) for letter, option_text in options}
    shortest_length = min(lengths.values(), default=0)
    judgments: dict[str, SuggestionNoveltyJudgment] = {}
    for letter, option_text in options:
        option = option_text.lower()
        option_length = lengths[letter]
        option_terms = set(_suggestion_terms(option_text))
        option_anchors = entity_anchor_terms(option_text)
        overlap = tuple(sorted((option_terms & evidence_terms) - _STOP_TERMS)[:8])
        novel = tuple(sorted((option_terms - evidence_terms) - _STOP_TERMS)[:8])
        support_refs = sum(
            1
            for unit in evidence_units
            if any(term in unit for term in overlap)
        )
        score = 0.0
        reasons: list[str] = []
        if option_length > 420:
            score -= 30.0
            reasons.append("overlong new-idea option")
        elif option_length > 380:
            score -= 12.0
            reasons.append("long new-idea option")
        if option_length > 300 and any(marker in option for marker in _PADDING_MARKERS):
            score -= 14.0
            reasons.append("new-idea side quest")
        if _is_autobiographical_memory(option):
            score -= 18.0
            reasons.append("autobiographical memory, not a suggestion")
        if (
            shortest_length
            and 80 <= shortest_length <= 300
            and option_length > shortest_length * 2.0
        ):
            score -= 28.0
            reasons.append("padded relative to concise candidate")
        elif (
            shortest_length
            and 80 <= shortest_length <= 260
            and option_length > shortest_length * 1.55
        ):
            score -= 14.0
            reasons.append("longer than concise candidate")
        if option_length <= 280 and any(marker in option for marker in _DIRECT_SUGGESTION_MARKERS):
            score += 14.0
            reasons.append("direct concise suggestion")
        elif option_length <= 380 and any(
            marker in option for marker in _DIRECT_SUGGESTION_MARKERS
        ):
            score += 12.0
            reasons.append("direct bounded suggestion")
        if overlap and novel and option_length <= 320:
            score += 12.0
            reasons.append("novel adjacent idea")
        matched_anchors = option_anchors & evidence_anchors
        unsupported_anchors = option_anchors - evidence_anchors
        if matched_anchors:
            score += min(16.0, 8.0 * len(matched_anchors))
            reasons.append("source-backed suggestion anchor")
        if unsupported_anchors and evidence_anchors and option_length > 360:
            score -= min(12.0, 6.0 * len(unsupported_anchors))
            reasons.append("unsupported neighboring suggestion anchor")
        repeated = any(marker in option for marker in _REPEAT_MARKERS)
        mostly_familiar = len(overlap) >= 3 and len(novel) <= 2
        if (
            shortest_length
            and option_length == shortest_length
            and option_length <= 260
            and not repeated
            and novel
        ):
            score += 6.0
            reasons.append("most concise viable suggestion")
        if repeated or (mostly_familiar and support_refs >= 2):
            score -= 5.0
            reasons.append("repeated familiar activity")
        if support_refs == 0 and len(overlap) == 0:
            score -= 6.0
            reasons.append("no source-adjacent support")
        if "padded relative to concise candidate" in reasons:
            signal = "penalize padded option"
        elif "new-idea side quest" in reasons:
            signal = "penalize padded side quest"
        elif "novel adjacent idea" in reasons:
            signal = "prefer novel adjacent concise idea"
        elif "repeated familiar activity" in reasons:
            signal = "penalize repeated familiar activity"
        elif support_refs:
            signal = "supported suggestion"
        else:
            signal = "unsupported suggestion"
        judgments[letter] = SuggestionNoveltyJudgment(
            score_adjustment=score,
            support_refs=support_refs,
            overlap_terms=overlap,
            novel_terms=novel,
            reasons=tuple(reasons),
            decision_signal=signal,
        )
    return judgments


def suggestion_novelty_adjustments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, tuple[float, list[str]]]:
    adjustments: dict[str, tuple[float, list[str]]] = {}
    for letter, judgment in suggestion_novelty_judgments(options, evidence_texts).items():
        if judgment.score_adjustment != 0.0:
            adjustments[letter] = (
                judgment.score_adjustment,
                [f"suggestion: {reason}" for reason in judgment.reasons],
            )
    return adjustments


def suggestion_novelty_summaries(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, str]:
    summaries: dict[str, str] = {}
    for letter, judgment in suggestion_novelty_judgments(options, evidence_texts).items():
        summaries[letter] = (
            f"support_refs={judgment.support_refs}; "
            f"overlap_terms={_join_or_none(judgment.overlap_terms)}; "
            f"novel_terms={_join_or_none(judgment.novel_terms)}; "
            f"decision_signal={judgment.decision_signal}"
        )
    return summaries


def render_suggestion_judgment_section(
    question: str,
    evidence_texts: Sequence[str],
    *,
    options: Sequence[tuple[str, str]] = (),
) -> str:
    if not looks_like_new_idea_request(question):
        return ""
    rows = [
        "## Suggestion Judgment",
        "",
        (
            "Use this section when the user asks for a new, fresh, or different "
            "idea."
        ),
        (
            "Rule: prefer concise novel-adjacent ideas that extend the loaded "
            "evidence. Penalize repeated familiar activities, long padded "
            "answers, and suggestions that add classes, groups, memberships, or "
            "side quests the user did not ask for."
        ),
        "",
    ]
    if options:
        rows.append("Candidate suggestion novelty:")
        summaries = suggestion_novelty_summaries(options, evidence_texts)
        for letter, _option_text in options:
            rows.append(f"- ({letter}) {summaries[letter]}")
        rows.append("")
    return "\n".join(rows)


def _suggestion_terms(text: str) -> list[str]:
    return [
        term
        for term in important_entity_terms(text)
        if term not in _STOP_TERMS and len(term) >= 3
    ]


def _is_autobiographical_memory(option: str) -> bool:
    stripped = option.strip()
    return stripped.startswith(
        (
            "i joined ",
            "i started ",
            "i signed ",
            "i found ",
            "i decided ",
            "i began ",
            "i tried ",
            "instead of ",
            "another initiative i ",
        )
    )


def _join_or_none(values: Sequence[str]) -> str:
    return ", ".join(values) if values else "none"
