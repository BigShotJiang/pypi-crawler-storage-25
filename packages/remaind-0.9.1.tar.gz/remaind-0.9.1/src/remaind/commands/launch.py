"""`remaind launch` — memory-state startup flow.

Launch is the product front door: it activates a workspace memory state,
proves the local runtime is usable, and only then accepts a file, paste,
resume, or empty session start. That ordering is intentional. Large prompts
must not enter the system until the memory store and runtime are ready.
"""

from __future__ import annotations

import getpass
import json
import os
import re
import shutil
import subprocess
import sys
import time
from collections.abc import Callable, Iterator, Sequence
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field, replace
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, TextIO
from urllib.parse import urlparse

from .._atomic import atomic_write_text
from .._context_engine import ContextBuildRequest, build_context_packet
from .._context_intent import classify_context_intent
from .._context_sources import (
    ContextAuthority,
    ContextFreshness,
    ContextSource,
    ContextSourceType,
    context_source_from_lines,
)
from .._cwd import safe_cwd
from .._db import open_db
from .._document_compaction import DEEP_COMPACTION_RECOMMENDED_TOKENS
from .._errors import RemaindError
from .._jsonl import iter_jsonl
from .._local_compactor import (
    CompactorResponseError,
    OllamaCompactor,
    OpenAICompatibleCompactor,
)
from .._memory_context import structured_memory_context_sources
from .._packet_policy import packet_policy_for_context
from .._paths import ContextPaths
from .._plan_reconciliation import (
    ensure_plan_reconciliation,
    load_plan_reconciliation,
    render_plan_reconciliation,
)
from .._presence import load_presence_snapshot, render_presence_snapshot
from .._product_status import (
    ensure_product_status_seed,
    load_product_status,
    render_product_status,
)
from .._progress import load_progress_snapshot, render_progress_snapshot
from .._recall_judgment import render_recall_judgment_section
from .._recommendation_engine import (
    build_recommendation_decision,
    render_recommendation_decision,
)
from .._recommendation_judgment import render_recommendation_judgment_section
from .._suggestion_judgment import render_suggestion_judgment_section
from .._terminal import MenuChoice, TerminalSelectionCancelled, select_menu
from .._text_model import (
    DEFAULT_OLLAMA_HOST,
    _ollama_api_mode_from_env,
    _ollama_host,
    _ollama_models,
    _ollama_show,
    _openai_base_url,
    _openai_models,
)
from .._timestamps import utc_now_filename_safe_us, utc_now_iso
from . import compact as compact_cmd
from . import init as init_cmd
from . import resume as resume_cmd
from . import run as run_cmd
from . import validate as validate_cmd

__all__ = [
    "Check",
    "ContextInspectResult",
    "LaunchError",
    "LaunchOptions",
    "LaunchResult",
    "ReadinessReport",
    "RuntimeProfile",
    "execute",
    "inspect_context",
    "render_human",
    "render_json",
]

INPUT_MODES = frozenset({"ask", "paste", "file", "resume", "handover", "empty"})
RUNTIME_KINDS = frozenset({"auto", "ollama", "openai-compatible", "fallback"})
DEFAULT_TASK = "Analyze the supplied prompt and follow its instructions."
DEFAULT_PASTE_END_MARKER = ".remaind end"
MIN_FREE_BYTES = 100 * 1024 * 1024
DISCOVERY_ROOTS_ENV = "REMAIND_LAUNCH_DISCOVERY_ROOTS"
WORKSPACE_ALIASES_ENV = "REMAIND_LAUNCH_WORKSPACE_ALIASES"
LAUNCH_MODEL_TIMEOUT_ENV = "REMAIND_LAUNCH_MODEL_TIMEOUT"
DEEPSEEK_PROFILE_SWITCHER_ENV = "REMAIND_DEEPSEEK_PROFILE_SWITCHER"
DEEPSEEK_PROFILE_PICKER_ENV = "REMAIND_DEEPSEEK_PROFILE_PICKER"
DEFAULT_LAUNCH_MODEL_TIMEOUT_S = 20.0
DISCOVERY_MAX_DEPTH = 4
DISCOVERY_LIMIT = 40
DISCOVERY_SEARCH_MAX_DEPTH = 7
DISCOVERY_SEARCH_LIMIT = 500
WORKSPACE_INDEX_EVENT_LIMIT = 200
WORKSPACE_INDEX_ARTIFACT_LIMIT = 12
WORKSPACE_INDEX_OLDEST_ARTIFACTS = 4
WORKSPACE_INDEX_ARTIFACT_CHARS = 12_000
WORKSPACE_INDEX_CHILD_LIMIT = 200
WORKSPACE_MATCH_MIN_SCORE = 45
WORKSPACE_CLEAR_MATCH_SCORE = 160
WORKSPACE_CLEAR_MATCH_GAP = 80
MEMORY_QUESTION_RESUME_MAX_CHARS = 120_000
MEMORY_QUESTION_PACKET_MAX_CHARS = 60_000
MEMORY_QUESTION_CHILD_PROJECT_LIMIT = 2
MEMORY_QUESTION_CHILD_PROJECT_FILE_LIMIT = 8
MEMORY_QUESTION_CHILD_PROJECT_FILE_CHARS = 16_000
MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_LIMIT = 4
MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_CHARS = 8_000
MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_LINES = 110
MEMORY_QUESTION_REPO_PLAN_REVIEW_ITEM_LIMIT = 12
MEMORY_QUESTION_HISTORY_LIMIT = 4
MEMORY_QUESTION_DEFAULT_PACKET_LIMIT = 2
MEMORY_QUESTION_ALL_PACKET_BUDGET_CHARS = 240_000
CONTINUATION_CRITICAL_FILE_CHARS = 12_000
CONTINUATION_CRITICAL_PACKET_CHARS = 16_000
CONTINUATION_CRITICAL_HISTORY_LIMIT = 2
PACKET_HISTORY_CRITICAL_FILE_CHARS = 4_000
PACKET_HISTORY_CRITICAL_FILE_LINES = 80
PACKET_HISTORY_CRITICAL_TOTAL_CHARS = 24_000
_MANUAL_PATH = object()
_MANUAL_MODEL = object()
_API_MODEL = object()
_KEEP_DEEPSEEK_PROFILE = object()
_BACK = object()
_TRANSIENT_MODEL_ERROR_MARKERS = (
    "connection refused",
    "connection reset",
    "compute error",
    "http 500",
    "http 503",
    "remote end closed connection",
    "remotedisconnected",
    "server disconnected",
    "server_error",
    "service unavailable",
    "timed out",
    "timeout",
    "urlopen error",
)

_WORKSPACE_SEARCH_STOPWORDS = frozenset(
    {
        "about",
        "active",
        "and",
        "app",
        "are",
        "current",
        "for",
        "from",
        "latest",
        "memory",
        "next",
        "project",
        "status",
        "task",
        "the",
        "this",
        "todo",
        "todos",
        "what",
        "with",
        "work",
        "workspace",
    }
)

_PACKET_HISTORY_QUERY_TERMS = frozenset(
    {
        "packet",
        "packets",
        "run_packet",
        "resume_packet",
        "run_answer",
        "history",
        "histories",
    }
)
_CONTINUATION_QUERY_TERMS = frozenset(
    {
        "build",
        "continue",
        "continuation",
        "handoff",
        "implementation",
        "load",
        "next",
        "pickup",
        "plan",
        "progress",
        "resume",
        "scope",
        "state",
        "status",
        "todo",
        "todos",
        "work",
        "working",
    }
)


@dataclass(frozen=True)
class _MemoryMode:
    label: str
    resume_memories: int
    resume_excerpts: int
    output_tokens: int
    run_token_cap: int | None


_REMAIND_MEMORY_MODES: dict[str, _MemoryMode] = {
    "turbo": _MemoryMode(
        label="Turbo - fastest; compact memory packet",
        resume_memories=1,
        resume_excerpts=3,
        output_tokens=1024,
        run_token_cap=12_000,
    ),
    "standard": _MemoryMode(
        label="Standard - balanced memory packet",
        resume_memories=5,
        resume_excerpts=20,
        output_tokens=4096,
        run_token_cap=None,
    ),
    "deep": _MemoryMode(
        label="Deep - fuller memory packet",
        resume_memories=8,
        resume_excerpts=30,
        output_tokens=8192,
        run_token_cap=None,
    ),
}
_DEEPSEEK_PROFILE_DEFAULT_SWITCHER = (
    Path.home() / "sovereign-local-ai/scripts/switch_deepseek_profile.sh"
)
_DEEPSEEK_PROFILE_ENV = Path.home() / ".remaind-sovereign/.env"
_DEEPSEEK_PROFILES = {
    "nitro": {
        "label": "Nitro - fastest, 65k context, experimental",
        "ctx": "65536",
    },
    "turbo": {
        "label": "Turbo - faster, 65k context",
        "ctx": "65536",
    },
    "stable": {
        "label": "Stable - larger, 131k context",
        "ctx": "131072",
    },
}
DOCUMENT_EXTENSIONS = frozenset(
    {
        ".csv",
        ".html",
        ".json",
        ".jsonl",
        ".log",
        ".md",
        ".rst",
        ".text",
        ".txt",
        ".tsv",
        ".xml",
        ".yaml",
        ".yml",
    }
)
DISCOVERY_SKIP_DIRS = frozenset(
    {
        ".cache",
        ".context",
        ".git",
        ".hg",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".svn",
        ".venv",
        "__pycache__",
        "dist",
        "node_modules",
        "site-packages",
        "venv",
    }
)


class LaunchError(RemaindError):
    """Raised when `remaind launch` cannot continue safely."""


class _LaunchBack(Exception):
    """Internal control flow for interactive Back selections."""


@dataclass(frozen=True)
class _WorkspaceIndexEntry:
    path: Path
    text: str
    tokens: frozenset[str]


@dataclass(frozen=True)
class _WorkspaceAlias:
    query: str
    path: Path
    terms: frozenset[str]


@dataclass(frozen=True)
class _ResolvedProject:
    path: Path
    query: str | None = None


@dataclass(frozen=True)
class _LaunchIntent:
    mode: str
    question: str | None = None
    file_path: Path | None = None


@dataclass(frozen=True)
class _RepoPlanItem:
    status: str
    text: str
    source: str
    line_number: int


@dataclass(frozen=True)
class LaunchOptions:
    path: Path | None = None
    workspace_query: str | None = None
    runtime: str = "auto"
    model: str | None = None
    yolo_model: bool = False
    input_mode: str | None = None
    file: Path | None = None
    task: str | None = None
    non_interactive: bool = False
    accept_fallback: bool = False
    token_cap: int | None = None
    max_results: int = run_cmd.DEFAULT_MAX_RESULTS
    answer_key_path: Path | None = None
    require_answer_key_pass: bool = False
    deep_compact: bool = False
    deep_compact_mode: str = "lenient"
    reuse_deep_compact: bool = False
    deep_compact_chunk_tokens: int | None = None
    memory_mode: str = field(
        default_factory=lambda: os.environ.get("REMAIND_MEMORY_MODE", "turbo")
    )
    skip_runtime_selection: bool = False
    show_progress: bool = True
    stdin: TextIO | None = None
    stdout: TextIO | None = None


@dataclass(frozen=True)
class RuntimeProfile:
    kind: str
    model: str | None
    endpoint: str | None
    context_window_tokens: int | None
    context_window_estimated: bool
    supports_compaction: bool
    warnings: list[str] = field(default_factory=list)
    unverified: bool = False
    api_key: str | None = field(default=None, repr=False, compare=False)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.pop("api_key", None)
        return payload


@dataclass(frozen=True)
class Check:
    name: str
    passed: bool
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ReadinessReport:
    ready: bool
    checks: list[Check]
    warnings: list[str]
    failures: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LaunchResult:
    project: str
    context_store: str
    initialized_context: bool
    runtime: RuntimeProfile
    memory_mode: str
    readiness: ReadinessReport
    input_mode: str
    run_result: dict[str, Any] | None = None
    resume_packet_path: str | None = None
    captured_input_path: str | None = None
    message: str | None = None
    rendered_inline: bool = False

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["runtime"] = self.runtime.to_dict()
        payload["readiness"] = self.readiness.to_dict()
        return payload


@dataclass(frozen=True)
class ContextInspectResult:
    project: str
    context_store: str
    initialized_context: bool
    memory_mode: str
    context_source_path: str
    content: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _out(options: LaunchOptions) -> TextIO:
    return options.stdout or sys.stdout


def _stdin(options: LaunchOptions) -> TextIO:
    return options.stdin or sys.stdin


def _is_interactive(options: LaunchOptions) -> bool:
    return not options.non_interactive and _stdin(options).isatty()


def _back_choice() -> MenuChoice[object]:
    return MenuChoice("Back", _BACK, shortcut="b")


def _ask(options: LaunchOptions, question: str, *, default: str | None = None) -> str:
    if options.non_interactive or not _stdin(options).isatty():
        if default is not None:
            return default
        raise LaunchError(f"missing required value in non-interactive mode: {question}")
    suffix = f" [{default}]" if default else ""
    _out(options).write(f"{question}{suffix}: ")
    _out(options).flush()
    answer = _stdin(options).readline().strip()
    return answer or (default or "")


def _ask_secret(options: LaunchOptions, question: str, *, default: str = "") -> str:
    if not _is_interactive(options):
        return default
    prompt = f"{question}: "
    if options.stdin is None and options.stdout is None:
        return getpass.getpass(prompt).strip()
    _out(options).write(prompt)
    _out(options).flush()
    return _stdin(options).readline().strip()


@contextmanager
def _patched_env(updates: dict[str, str | None]) -> Iterator[None]:
    previous: dict[str, str | None] = {
        key: os.environ.get(key) for key in updates
    }
    for key, value in updates.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    try:
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _memory_mode(options: LaunchOptions) -> _MemoryMode:
    key = (options.memory_mode or "turbo").strip().lower()
    mode = _REMAIND_MEMORY_MODES.get(key)
    if mode is None:
        allowed = ", ".join(sorted(_REMAIND_MEMORY_MODES))
        raise LaunchError(f"unsupported Remaind memory mode {key!r}; choose {allowed}")
    return mode


def _memory_mode_env(mode: _MemoryMode) -> dict[str, str | None]:
    return {
        "REMAIND_MEMORY_MODE": _memory_mode_key(mode),
        "REMAIND_OPENAI_MAX_TOKENS": str(mode.output_tokens),
        "REMAIND_OLLAMA_NUM_PREDICT": str(mode.output_tokens),
    }


def _memory_mode_key(mode: _MemoryMode) -> str:
    for key, candidate in _REMAIND_MEMORY_MODES.items():
        if candidate == mode:
            return key
    raise LaunchError("internal Remaind memory mode is not registered")


def _resume_kwargs(options: LaunchOptions) -> dict[str, int]:
    mode = _memory_mode(options)
    return {
        "k_memories": mode.resume_memories,
        "raw_excerpt_count": mode.resume_excerpts,
    }


def _run_resume(base: Path, options: LaunchOptions) -> resume_cmd.ResumeResult:
    resume_kwargs = _resume_kwargs(options)
    return resume_cmd.run(
        base,
        k_memories=resume_kwargs["k_memories"],
        raw_excerpt_count=resume_kwargs["raw_excerpt_count"],
    )


def _select_menu_value(
    options: LaunchOptions,
    *,
    title: str,
    choices: list[MenuChoice[Any]],
    default_index: int = 0,
) -> Any | None:
    if options.non_interactive:
        return None
    try:
        return select_menu(
            title=title,
            choices=choices,
            stdin=_stdin(options),
            stdout=_out(options),
            default_index=default_index,
        )
    except TerminalSelectionCancelled as exc:
        raise LaunchError("selection cancelled") from exc


def _progress_callback(options: LaunchOptions) -> Callable[[str], None] | None:
    if not options.show_progress:
        return None

    def emit(message: str) -> None:
        _out(options).write(message.rstrip() + "\n")
        _out(options).flush()

    return emit


def _confirm(
    options: LaunchOptions, question: str, *, default_yes: bool = True
) -> bool:
    if options.non_interactive or not _stdin(options).isatty():
        return default_yes
    selected = _select_menu_value(
        options,
        title=question,
        choices=[
            MenuChoice("Yes", True, shortcut="y"),
            MenuChoice("No", False, shortcut="n"),
        ],
        default_index=0 if default_yes else 1,
    )
    if selected is not None:
        return bool(selected)
    suffix = " [Y/n]" if default_yes else " [y/N]"
    _out(options).write(f"{question}{suffix}: ")
    _out(options).flush()
    answer = _stdin(options).readline().strip().lower()
    if not answer:
        return default_yes
    return answer in {"y", "yes"}


def _display_path(path: Path) -> str:
    try:
        return str(path.expanduser().resolve())
    except OSError:
        return str(path.expanduser())


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[tuple[int, int]] = set()
    out: list[Path] = []
    for path in paths:
        try:
            expanded = path.expanduser()
            stat = expanded.stat()
            resolved = expanded.resolve()
        except OSError:
            continue
        key = (stat.st_dev, stat.st_ino)
        if key in seen:
            continue
        seen.add(key)
        out.append(resolved)
    return out


def _project_relative_path(project_dir: Path, path: Path) -> str:
    """Return a stable project-relative display path across symlinked tmp dirs."""

    candidates = [(path, project_dir)]
    try:
        candidates.append((path.resolve(), project_dir.resolve()))
    except OSError:
        pass
    for candidate_path, candidate_project in candidates:
        try:
            return candidate_path.relative_to(candidate_project).as_posix()
        except ValueError:
            continue
    return path.name


def _workspace_aliases_path() -> Path:
    raw = os.environ.get(WORKSPACE_ALIASES_ENV, "").strip()
    if raw:
        return Path(raw).expanduser()
    return Path.home() / ".remaind" / "workspace-aliases.json"


def _load_workspace_aliases() -> list[_WorkspaceAlias]:
    path = _workspace_aliases_path()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    raw_aliases = payload.get("aliases") if isinstance(payload, dict) else None
    if not isinstance(raw_aliases, list):
        return []
    aliases: list[_WorkspaceAlias] = []
    for item in raw_aliases:
        if not isinstance(item, dict):
            continue
        query = item.get("query")
        raw_path = item.get("path")
        if not isinstance(query, str) or not isinstance(raw_path, str):
            continue
        terms = frozenset(_project_query_terms(query))
        if not terms:
            continue
        workspace = Path(raw_path).expanduser()
        try:
            resolved = workspace.resolve()
        except OSError:
            continue
        if not (resolved / ".context").is_dir():
            continue
        aliases.append(_WorkspaceAlias(query=query, path=resolved, terms=terms))
    return aliases


def _aliases_for_workspace(path: Path) -> list[_WorkspaceAlias]:
    try:
        resolved = path.expanduser().resolve()
    except OSError:
        return []
    return [alias for alias in _load_workspace_aliases() if alias.path == resolved]


def _is_within_depth(path: Path, root: Path, *, max_depth: int) -> bool:
    try:
        relative = path.relative_to(root)
    except ValueError:
        return False
    return len(relative.parts) <= max_depth


def _discovery_roots(cwd: Path, *, base: Path | None = None) -> list[Path]:
    roots = [cwd]
    home = Path.home().expanduser().resolve()
    try:
        cwd.relative_to(home)
        cwd_under_home = True
    except ValueError:
        cwd_under_home = False
    if cwd_under_home and cwd.parent not in {cwd, home}:
        roots.append(cwd.parent)
    if base is not None:
        roots.append(base)
    docs = Path.home() / "Documents"
    roots.extend(
        [
            docs / "Remaind",
            docs / "Codex",
            docs,
        ]
    )
    raw = os.environ.get(DISCOVERY_ROOTS_ENV, "").strip()
    if raw:
        roots.extend(Path(item).expanduser() for item in raw.split(os.pathsep) if item)
    return [root for root in _dedupe_paths(roots) if root.exists() and root.is_dir()]


def _walk_limited(root: Path, *, max_depth: int) -> Iterator[tuple[Path, list[str], list[str]]]:
    for dirpath, dirnames, filenames in os.walk(root):
        current = Path(dirpath)
        if not _is_within_depth(current, root, max_depth=max_depth):
            dirnames[:] = []
            continue
        dirnames[:] = [
            name
            for name in dirnames
            if name not in DISCOVERY_SKIP_DIRS and not name.endswith(".app")
        ]
        yield current, dirnames, filenames


def _discover_project_folders(
    cwd: Path,
    *,
    max_depth: int = DISCOVERY_MAX_DEPTH,
    limit: int = DISCOVERY_LIMIT,
) -> list[Path]:
    candidates = [cwd]
    for root in _discovery_roots(cwd):
        for current, _dirnames, _filenames in _walk_limited(
            root,
            max_depth=max_depth,
        ):
            if (current / ".context").is_dir():
                candidates.append(current)
                if len(candidates) >= limit:
                    return _dedupe_paths(candidates)
    return _dedupe_paths(candidates)[:limit]


def _workspace_index_candidates(cwd: Path, visible_candidates: list[Path]) -> list[Path]:
    candidates = list(visible_candidates)
    candidates.extend(alias.path for alias in _load_workspace_aliases())
    candidates.extend(
        _discover_project_folders(
            cwd,
            max_depth=DISCOVERY_SEARCH_MAX_DEPTH,
            limit=DISCOVERY_SEARCH_LIMIT,
        )
    )
    return _dedupe_paths(candidates)[:DISCOVERY_SEARCH_LIMIT]


def _normalize_workspace_text(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))


def _project_query_terms(query: str) -> list[str]:
    terms = re.findall(r"[a-z0-9]+", query.lower())
    return [
        term
        for term in terms
        if len(term) > 1 and term not in _WORKSPACE_SEARCH_STOPWORDS
    ]


def _remember_workspace_alias(query: str, path: Path) -> None:
    terms = _project_query_terms(query)
    if not terms:
        return
    try:
        resolved = path.expanduser().resolve()
    except OSError:
        return
    if not (resolved / ".context").is_dir():
        return
    alias_path = _workspace_aliases_path()
    aliases = _load_workspace_aliases()
    normalized_query = _normalize_workspace_text(query)
    rows = [
        {
            "query": alias.query,
            "terms": sorted(alias.terms),
            "path": str(alias.path),
        }
        for alias in aliases
        if not (
            alias.path == resolved
            and _normalize_workspace_text(alias.query) == normalized_query
        )
    ]
    rows.append(
        {
            "query": query.strip(),
            "terms": terms,
            "path": str(resolved),
            "updated_at": utc_now_iso(),
        }
    )
    content = json.dumps(
        {
            "version": 1,
            "aliases": rows,
        },
        indent=2,
        sort_keys=True,
    )
    atomic_write_text(alias_path, content + "\n")


def _safe_read_text(path: Path, *, max_chars: int = 20_000) -> str:
    try:
        return path.read_text(encoding="utf-8")[:max_chars]
    except OSError:
        return ""


def _workspace_artifact_files(active_path: Path, history_dir: Path) -> list[Path]:
    candidates: list[Path] = []
    if active_path.is_file():
        candidates.append(active_path)
    if history_dir.is_dir():
        try:
            history_files = [path for path in history_dir.iterdir() if path.is_file()]
        except OSError:
            history_files = []
        history_files.sort(
            key=lambda path: (
                _safe_mtime_ns(path),
                path.name,
            ),
            reverse=True,
        )
        recent_limit = max(
            0,
            WORKSPACE_INDEX_ARTIFACT_LIMIT
            - len(candidates)
            - WORKSPACE_INDEX_OLDEST_ARTIFACTS,
        )
        selected_history = [
            *history_files[:recent_limit],
            *reversed(history_files[-WORKSPACE_INDEX_OLDEST_ARTIFACTS:]),
        ]
        candidates.extend(_dedupe_paths(selected_history))
    return candidates[:WORKSPACE_INDEX_ARTIFACT_LIMIT]


def _safe_mtime_ns(path: Path) -> int:
    try:
        return path.stat().st_mtime_ns
    except OSError:
        return 0


def _workspace_child_project_dirs(path: Path) -> list[Path]:
    try:
        children = [
            child
            for child in path.iterdir()
            if child.is_dir()
            and child.name not in DISCOVERY_SKIP_DIRS
            and not child.name.startswith(".")
            and not child.name.endswith(".app")
        ]
    except OSError:
        return []
    children.sort(key=lambda child: child.name.lower())
    return children[:WORKSPACE_INDEX_CHILD_LIMIT]


def _workspace_search_text(path: Path) -> str:
    paths = ContextPaths.at(path)
    parts = [path.name, str(path)]
    child_projects = _workspace_child_project_dirs(path)
    if child_projects:
        parts.append(" ".join(child.name for child in child_projects))
        parts.append(" ".join(str(child) for child in child_projects))
    aliases = _aliases_for_workspace(path)
    if aliases:
        parts.append(" ".join(alias.query for alias in aliases))
        parts.append(" ".join(term for alias in aliases for term in alias.terms))
    parts.append(_safe_read_text(paths.handover_md))
    parts.append(_safe_read_text(paths.state_json))
    parts.append(_safe_read_text(paths.resume_packet, max_chars=WORKSPACE_INDEX_ARTIFACT_CHARS))
    artifact_paths: list[Path] = [
        *_workspace_artifact_files(
            paths.active_dir / "run_packet.md",
            paths.history_dir / "run_packet",
        ),
        *_workspace_artifact_files(
            paths.active_dir / "run_answer.md",
            paths.history_dir / "run_answer",
        ),
        *_workspace_artifact_files(
            paths.resume_packet,
            paths.history_dir / "resume_packet",
        ),
    ]
    for artifact_path in artifact_paths:
        parts.append(
            _safe_read_text(
                artifact_path,
                max_chars=WORKSPACE_INDEX_ARTIFACT_CHARS,
            )
        )
    event_rows = []
    try:
        for index, (_lineno, obj, err) in enumerate(iter_jsonl(paths.events_jsonl)):
            if index >= WORKSPACE_INDEX_EVENT_LIMIT:
                break
            if err is not None or obj is None:
                continue
            for key in ("summary", "type", "task_id", "session_id"):
                value = obj.get(key)
                if isinstance(value, str):
                    event_rows.append(value)
    except OSError:
        pass
    parts.extend(event_rows)
    return "\n".join(part for part in parts if part)


def _workspace_index_entry(path: Path) -> _WorkspaceIndexEntry:
    text = _workspace_search_text(path)
    normalized = _normalize_workspace_text(text)
    return _WorkspaceIndexEntry(
        path=path,
        text=normalized,
        tokens=frozenset(normalized.split()),
    )


def _query_phrases(terms: list[str]) -> list[str]:
    phrases: list[str] = []
    for width in (3, 2):
        if len(terms) < width:
            continue
        for index in range(0, len(terms) - width + 1):
            phrases.append(" ".join(terms[index : index + width]))
    return phrases


def _fuzzy_token_match(term: str, tokens: frozenset[str]) -> bool:
    if len(term) < 4:
        return False
    for token in tokens:
        if abs(len(token) - len(term)) > 2:
            continue
        if SequenceMatcher(None, term, token).ratio() >= 0.84:
            return True
    return False


def _workspace_match_score(path: Path, query: str, entry: _WorkspaceIndexEntry | None = None) -> int:
    terms = _project_query_terms(query)
    if not terms:
        return 0
    normalized_query = " ".join(terms)
    name = _normalize_workspace_text(path.name)
    full_path = _normalize_workspace_text(str(path))
    path_tokens = frozenset(full_path.split())
    name_tokens = frozenset(name.split())
    if entry is None:
        entry = _workspace_index_entry(path)

    score = 0
    path_segments = {
        _normalize_workspace_text(part)
        for part in path.parts
        if _normalize_workspace_text(part)
    }
    if normalized_query in path_segments:
        score += 260
    if name == normalized_query:
        score += 240
    if normalized_query in name:
        score += 180
    if normalized_query in full_path:
        score += 120
    if normalized_query in entry.text:
        score += 130

    for phrase in _query_phrases(terms):
        if phrase in name:
            score += 90
        if phrase in full_path:
            score += 60
        if phrase in entry.text:
            score += 75

    matched_terms = 0
    for term in terms:
        term_matched = False
        if term in name_tokens:
            score += 90
            term_matched = True
        elif _fuzzy_token_match(term, name_tokens):
            score += 55
            term_matched = True
        if term in path_tokens:
            score += 45
            term_matched = True
        elif _fuzzy_token_match(term, path_tokens):
            score += 25
            term_matched = True
        if term in entry.tokens:
            score += 60
            term_matched = True
        elif _fuzzy_token_match(term, entry.tokens):
            score += 35
            term_matched = True
        if term_matched:
            matched_terms += 1

    coverage = matched_terms / len(terms)
    if coverage == 1:
        score += 70
    elif coverage >= 0.6:
        score += 30
    elif coverage < 0.34:
        score = 0
    return score


def _rank_project_folders(candidates: list[Path], query: str) -> list[tuple[int, Path]]:
    scored: list[tuple[int, Path]] = []
    for candidate in _dedupe_paths(candidates):
        if not (candidate / ".context").is_dir():
            continue
        entry = _workspace_index_entry(candidate)
        score = _workspace_match_score(candidate, query, entry)
        if score >= WORKSPACE_MATCH_MIN_SCORE:
            scored.append((score, candidate))
    scored.sort(key=lambda item: (-item[0], str(item[1]).lower()))
    return scored


def _match_project_folders(candidates: list[Path], query: str) -> list[Path]:
    scored = _rank_project_folders(candidates, query)
    return [path for _score, path in scored]


def _clear_workspace_match(scored: list[tuple[int, Path]]) -> Path | None:
    if not scored:
        return None
    top_score, top_path = scored[0]
    if top_score < WORKSPACE_CLEAR_MATCH_SCORE:
        return top_path if len(scored) == 1 else None
    if len(scored) == 1:
        return top_path
    second_score = scored[1][0]
    if top_score - second_score >= WORKSPACE_CLEAR_MATCH_GAP:
        return top_path
    if top_score >= second_score * 2:
        return top_path
    return None


def _resolve_project_query(
    options: LaunchOptions,
    *,
    query: str,
    candidates: list[Path],
) -> Path | None:
    query = query.strip()
    if not query:
        return None
    scored = _rank_project_folders(candidates, query)
    matches = [path for _score, path in scored]
    clear_match = _clear_workspace_match(scored)
    if clear_match is None and not matches:
        if options.non_interactive or not _is_interactive(options):
            raise LaunchError(
                f"no workspace memory matched project {query!r} "
                f"after indexing {len(candidates)} memory folder(s); "
                "try a related topic or use --path"
            )
        _out(options).write(
            f"No workspace memory matched {query!r} after indexing "
            f"{len(candidates)} memory folder(s). Choose from the list instead.\n"
        )
        return None
    if clear_match is not None:
        selected = clear_match
        _remember_workspace_alias(query, selected)
        if _is_interactive(options) and options.show_progress:
            _out(options).write(f"Workspace memory: {_display_path(selected)}\n")
        return selected
    if options.non_interactive or not _is_interactive(options):
        preview = "; ".join(_display_path(path) for path in matches[:5])
        raise LaunchError(
            f"project {query!r} matched multiple workspace memories: {preview}"
        )
    selected = _select_path_from_menu(
        options,
        title=f"Workspace matches for {query!r}",
        candidates=matches,
        manual_prompt="Workspace folder path",
        create_if_missing=False,
        default_index=1,
    )
    _remember_workspace_alias(query, selected)
    return selected


def _manual_path_selection(
    options: LaunchOptions,
    *,
    prompt: str,
    create_if_missing: bool,
) -> Path:
    raw = _ask(options, prompt)
    if not raw:
        raise LaunchError(f"{prompt.lower()} is required")
    path = Path(raw).expanduser()
    if path.exists():
        return path.resolve()
    if not create_if_missing:
        raise LaunchError(f"path does not exist: {path}")
    if not _confirm(options, f"Create folder {path}?", default_yes=False):
        raise LaunchError("workspace folder was not created")
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def _select_path_from_menu(
    options: LaunchOptions,
    *,
    title: str,
    candidates: list[Path],
    manual_prompt: str,
    create_if_missing: bool,
    default_index: int | None = 1,
    allow_back: bool = False,
) -> Path:
    if not _is_interactive(options):
        if candidates and default_index is not None:
            return candidates[default_index - 1]
        return _manual_path_selection(
            options,
            prompt=manual_prompt,
            create_if_missing=create_if_missing,
        )

    choices: list[MenuChoice[Any]] = [
        MenuChoice(_display_path(path), path)
        for path in candidates
    ]
    choices.append(MenuChoice("Type a path manually", _MANUAL_PATH, shortcut="m"))
    if allow_back:
        choices.append(_back_choice())
    selected = _select_menu_value(
        options,
        title=title,
        choices=choices,
        default_index=(default_index - 1) if candidates and default_index else 0,
    )
    if selected is _BACK:
        raise _LaunchBack
    if selected is _MANUAL_PATH:
        return _manual_path_selection(
            options,
            prompt=manual_prompt,
            create_if_missing=create_if_missing,
        )
    if isinstance(selected, Path):
        return selected

    _out(options).write(f"{title}\n")
    for idx, path in enumerate(candidates, start=1):
        _out(options).write(f"  {idx}. {_display_path(path)}\n")
    _out(options).write("  m. Type a path manually\n")
    if allow_back:
        _out(options).write("  b. Back\n")
    while True:
        default = str(default_index) if candidates and default_index is not None else "m"
        answer = _ask(options, "Select", default=default).strip()
        if allow_back and answer.lower() in {"b", "back"}:
            raise _LaunchBack
        if answer.lower() in {"m", "manual"}:
            return _manual_path_selection(
                options,
                prompt=manual_prompt,
                create_if_missing=create_if_missing,
            )
        try:
            index = int(answer)
        except ValueError:
            path = Path(answer).expanduser()
            if path.exists():
                return path.resolve()
            if create_if_missing:
                if _confirm(options, f"Create folder {path}?", default_yes=False):
                    path.mkdir(parents=True, exist_ok=True)
                    return path.resolve()
                raise LaunchError("workspace folder was not created") from None
            back_hint = ", `b`" if allow_back else ""
            _out(options).write(
                f"Choose a number, `m`{back_hint}, or an existing path.\n"
            )
            continue
        if 1 <= index <= len(candidates):
            return candidates[index - 1]
        back_hint = ", `b`" if allow_back else ""
        _out(options).write(f"Choose 1-{len(candidates)}, `m`{back_hint}, or a path.\n")


def _resolve_project_folder(options: LaunchOptions) -> _ResolvedProject:
    if options.path is not None and options.workspace_query:
        raise LaunchError("choose either --path or --project, not both")
    if options.path is not None:
        base = Path(options.path).expanduser()
        base.mkdir(parents=True, exist_ok=True)
        return _ResolvedProject(base.resolve())

    cwd = safe_cwd()
    candidates = _discover_project_folders(cwd)
    index_candidates = _workspace_index_candidates(cwd, candidates)
    if options.workspace_query:
        selected = _resolve_project_query(
            options,
            query=options.workspace_query,
            candidates=index_candidates,
        )
        if selected is None:
            raise LaunchError(
                f"no workspace memory matched project {options.workspace_query!r}"
            )
        return _ResolvedProject(selected, options.workspace_query)
    if options.non_interactive or not _stdin(options).isatty():
        return _ResolvedProject(cwd)

    query = _ask(options, "Product or workspace name (leave blank to browse)")
    selected = _resolve_project_query(
        options,
        query=query,
        candidates=index_candidates,
    )
    if selected is not None:
        return _ResolvedProject(selected, query.strip() or None)

    selected = _select_path_from_menu(
        options,
        title="Workspaces with memory",
        candidates=candidates,
        manual_prompt="Workspace folder path",
        create_if_missing=True,
        default_index=1,
    )
    _remember_workspace_alias(query, selected)
    return _ResolvedProject(selected, query.strip() or None)


def _ensure_context(base: Path) -> bool:
    paths = ContextPaths.at(base)
    if paths.root.is_dir():
        return False
    init_cmd.run(base)
    return True


def _require_valid_context(base: Path) -> None:
    try:
        report = validate_cmd.run(base)
    except OSError as exc:
        raise LaunchError(
            f"Memory state could not be read at {base}: {exc}. "
            "Grant terminal access to this workspace or choose another one."
        ) from exc
    if report.ok:
        return
    detail = "; ".join(f"{label}: {reason}" for label, reason in report.failed)
    raise LaunchError(f"Memory state validation failed: {detail}")


def _env_flag(name: str) -> str:
    return os.environ.get(name, "").strip().lower()


def _read_env_file(path: Path | None = None) -> dict[str, str]:
    env_path = path or _DEEPSEEK_PROFILE_ENV
    if not env_path.is_file():
        return {}
    try:
        lines = env_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return {}
    values: dict[str, str] = {}
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip("'\"")
    return values


def _deepseek_switcher_path() -> Path | None:
    raw = os.environ.get(DEEPSEEK_PROFILE_SWITCHER_ENV, "").strip()
    path = Path(raw).expanduser() if raw else _DEEPSEEK_PROFILE_DEFAULT_SWITCHER
    return path if path.is_file() and os.access(path, os.X_OK) else None


def _deepseek_switcher_help(switcher: Path) -> str:
    try:
        completed = subprocess.run(
            [str(switcher), "--help"],
            check=False,
            capture_output=True,
            text=True,
            timeout=3,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return f"{completed.stdout}\n{completed.stderr}".lower()


def _supported_deepseek_profiles(switcher: Path) -> set[str]:
    baseline = {"stable", "turbo"}
    help_text = _deepseek_switcher_help(switcher)
    if not help_text:
        return baseline
    advertised = {
        profile for profile in _DEEPSEEK_PROFILES if profile in help_text
    }
    return advertised or baseline


def _deepseek_switcher_supports_option(switcher: Path, option: str) -> bool:
    return option.lower() in _deepseek_switcher_help(switcher)


def _looks_like_deepseek_runtime() -> bool:
    forced = _env_flag(DEEPSEEK_PROFILE_PICKER_ENV)
    if forced in {"1", "true", "yes", "on"}:
        return True
    if forced in {"0", "false", "no", "off"}:
        return False
    candidates = [
        os.environ.get("REMAIND_OPENAI_MODEL", ""),
        os.environ.get("SOVEREIGN_MODEL", ""),
        os.environ.get("SOVEREIGN_MODEL_PROFILE", ""),
    ]
    return any("deepseek" in value.lower() for value in candidates)


def _current_deepseek_profile() -> str | None:
    env = _read_env_file()
    raw = (
        os.environ.get("SOVEREIGN_MODEL_PROFILE", "")
        or env.get("SOVEREIGN_MODEL_PROFILE", "")
        or ""
    ).lower()
    if "nitro" in raw:
        return "nitro"
    if "turbo" in raw:
        return "turbo"
    if "stable" in raw:
        return "stable"
    ctx = (
        os.environ.get("REMAIND_OPENAI_NUM_CTX", "")
        or os.environ.get("REMAIND_OLLAMA_NUM_CTX", "")
        or env.get("SOVEREIGN_NUM_CTX", "")
    ).strip()
    if ctx == _DEEPSEEK_PROFILES["turbo"]["ctx"]:
        return "turbo"
    if ctx == _DEEPSEEK_PROFILES["stable"]["ctx"]:
        return "stable"
    return None


def _apply_deepseek_env_after_switch(
    profile: str,
    *,
    env: dict[str, str] | None = None,
) -> None:
    values = env or _read_env_file()
    ctx = values.get("SOVEREIGN_NUM_CTX") or _DEEPSEEK_PROFILES[profile]["ctx"]
    if ctx:
        os.environ["REMAIND_OPENAI_NUM_CTX"] = ctx
        os.environ["REMAIND_OLLAMA_NUM_CTX"] = ctx

    model = (
        values.get("REMAIND_OPENAI_MODEL")
        or values.get("SOVEREIGN_MODEL")
        or os.environ.get("REMAIND_OPENAI_MODEL")
        or "deepseek-v4-flash"
    )
    os.environ["REMAIND_OPENAI_MODEL"] = model

    base_url = (
        values.get("REMAIND_OPENAI_BASE_URL")
        or values.get("SOVEREIGN_OPENAI_BASE_URL")
        or os.environ.get("REMAIND_OPENAI_BASE_URL")
    )
    if base_url:
        os.environ["REMAIND_OPENAI_BASE_URL"] = base_url

    key_file = (
        values.get("REMAIND_OPENAI_API_KEY_FILE")
        or values.get("SOVEREIGN_OPENAI_API_KEY_FILE")
    )
    if not os.environ.get("REMAIND_OPENAI_API_KEY") and key_file:
        path = Path(key_file).expanduser()
        if path.is_file():
            os.environ["REMAIND_OPENAI_API_KEY"] = path.read_text(
                encoding="utf-8"
            ).strip()


def _switch_deepseek_profile(
    path: Path,
    profile: str,
    *,
    extra_args: Sequence[str] = (),
) -> str:
    try:
        completed = subprocess.run(
            [str(path), profile, *extra_args],
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or str(exc)).strip()
        raise LaunchError(f"DeepSeek profile switch failed: {detail}") from exc
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise LaunchError(f"DeepSeek profile switch failed: {exc}") from exc
    _apply_deepseek_env_after_switch(profile)
    return completed.stdout.strip()


def _deepseek_switch_args(
    options: LaunchOptions,
    *,
    switcher: Path,
    allow_back: bool,
) -> list[str]:
    if not _deepseek_switcher_supports_option(switcher, "--free-memory"):
        return []
    choices: list[MenuChoice[Any]] = [
        MenuChoice(
            "Yes - pause other local model servers first",
            True,
            "y",
        ),
        MenuChoice(
            "No - leave other model servers running",
            False,
            "n",
        ),
    ]
    if allow_back:
        choices.append(_back_choice())
    selected = _select_menu_value(
        options,
        title="Free memory before starting DeepSeek?",
        choices=choices,
        default_index=1,
    )
    if selected is _BACK:
        raise _LaunchBack
    return ["--free-memory"] if selected is True else ["--no-free-memory"]


def _maybe_select_deepseek_profile(
    options: LaunchOptions,
    *,
    allow_back: bool = False,
) -> bool:
    if (
        options.skip_runtime_selection
        or options.non_interactive
        or not _is_interactive(options)
    ):
        return False
    switcher = _deepseek_switcher_path()
    if switcher is None or not _looks_like_deepseek_runtime():
        return False

    current = _current_deepseek_profile()
    supported_profiles = _supported_deepseek_profiles(switcher)
    current_label = (
        str(_DEEPSEEK_PROFILES[current]["label"])
        if current in _DEEPSEEK_PROFILES
        else "detected profile"
    )
    choices: list[MenuChoice[Any]] = [
        MenuChoice(f"Keep current ({current_label})", _KEEP_DEEPSEEK_PROFILE, "k"),
    ]
    if "nitro" in supported_profiles:
        choices.append(
            MenuChoice(str(_DEEPSEEK_PROFILES["nitro"]["label"]), "nitro", "n")
        )
    if "turbo" in supported_profiles:
        choices.append(
            MenuChoice(str(_DEEPSEEK_PROFILES["turbo"]["label"]), "turbo", "t")
        )
    if "stable" in supported_profiles:
        choices.append(
            MenuChoice(str(_DEEPSEEK_PROFILES["stable"]["label"]), "stable", "s")
        )
    if allow_back:
        choices.append(_back_choice())
    selected = _select_menu_value(
        options,
        title="DeepSeek mode",
        choices=choices,
        default_index=0,
    )
    if selected is _BACK:
        raise _LaunchBack
    if selected in {None, _KEEP_DEEPSEEK_PROFILE}:
        if current in _DEEPSEEK_PROFILES:
            extra_args = _deepseek_switch_args(
                options,
                switcher=switcher,
                allow_back=allow_back,
            )
            if "--free-memory" in extra_args:
                _out(options).write(
                    f"Restarting DeepSeek {current} mode and freeing memory...\n"
                )
                _out(options).flush()
                _switch_deepseek_profile(
                    switcher,
                    current,
                    extra_args=extra_args,
                )
                return True
            _apply_deepseek_env_after_switch(current)
        return False
    profile = str(selected)
    extra_args = _deepseek_switch_args(
        options,
        switcher=switcher,
        allow_back=allow_back,
    )
    if profile == current and "--free-memory" not in extra_args:
        _apply_deepseek_env_after_switch(profile)
        return False
    _out(options).write(f"Switching DeepSeek to {profile} mode...\n")
    _out(options).flush()
    _switch_deepseek_profile(switcher, profile, extra_args=extra_args)
    return True


def _model_match(models: list[str], preferred: str | None) -> str | None:
    if not models:
        return None
    if preferred:
        for name in models:
            if name == preferred or name.split(":", 1)[0] == preferred:
                return name
        return None
    return models[0]


def _profile_key(profile: RuntimeProfile) -> tuple[str, str | None, str | None]:
    return (profile.kind, profile.endpoint, profile.model)


def _endpoint_is_local(endpoint: str | None) -> bool:
    if not endpoint:
        return False
    host = (urlparse(endpoint).hostname or "").lower()
    return host in {"localhost", "127.0.0.1", "::1"} or host.endswith(".local")


def _openai_secret_env(profile: RuntimeProfile) -> dict[str, str | None]:
    if profile.kind != "openai-compatible" or not profile.api_key:
        return {}
    return {"REMAIND_OPENAI_API_KEY": profile.api_key}


def _openai_profiles_for_endpoint(
    endpoint: str,
    *,
    api_key: str | None,
) -> list[RuntimeProfile]:
    with _patched_env({"REMAIND_OPENAI_API_KEY": api_key}):
        models = _openai_models(endpoint)
    return [
        _openai_profile_for_model(endpoint, model, api_key=api_key)
        for model in models
    ]


def _openai_profile_for_model(
    endpoint: str, model: str, *, api_key: str | None = None
) -> RuntimeProfile:
    context = _context_from_env()
    warnings: list[str] = []
    estimated = context is None
    if context is None:
        context = 4096
        warnings.append(
            "OpenAI-compatible runtime did not report a context window; using "
            "a conservative 4096-token estimate."
        )
    if not _endpoint_is_local(endpoint):
        warnings.append(
            "Remote API model selected; prompts are sent to the configured "
            "OpenAI-compatible endpoint. The API key is not stored by Remaind."
        )
    return RuntimeProfile(
        kind="openai-compatible",
        model=model,
        endpoint=endpoint,
        context_window_tokens=context,
        context_window_estimated=estimated,
        supports_compaction=True,
        warnings=warnings,
        api_key=api_key,
    )


def _normalize_endpoint(raw: str) -> str:
    endpoint = raw.strip()
    if not endpoint:
        raise LaunchError("endpoint is required for YOLO model mode")
    if not endpoint.startswith(("http://", "https://")):
        endpoint = f"http://{endpoint}"
    return endpoint.rstrip("/")


def _unverified_profile_for_model(
    kind: str,
    endpoint: str,
    model: str,
) -> RuntimeProfile:
    context = _context_from_env()
    warnings = [
        "YOLO model mode selected: Remaind did not verify this model before "
        "continuing. If it cannot load, the later model call will fail clearly."
    ]
    estimated = context is None
    if context is None:
        context = 4096
        runtime = "Ollama" if kind == "ollama" else "OpenAI-compatible"
        warnings.append(
            f"{runtime} context window was not verified; using a conservative "
            "4096-token estimate."
        )
    return RuntimeProfile(
        kind=kind,
        model=model,
        endpoint=endpoint,
        context_window_tokens=context,
        context_window_estimated=estimated,
        supports_compaction=True,
        warnings=warnings,
        unverified=True,
    )


def _explicit_yolo_profile(options: LaunchOptions) -> RuntimeProfile:
    if options.runtime == "fallback":
        raise LaunchError("--yolo-model cannot be combined with --runtime fallback")
    if not options.model or not options.model.strip():
        raise LaunchError("--yolo-model requires --model in non-interactive mode")
    model = options.model.strip()
    if options.runtime == "openai-compatible":
        endpoint = _openai_base_url()
        if endpoint is None:
            raise LaunchError(
                "--yolo-model with --runtime openai-compatible requires "
                "REMAIND_OPENAI_BASE_URL"
            )
        return _unverified_profile_for_model("openai-compatible", endpoint, model)
    if options.runtime == "ollama":
        return _unverified_profile_for_model("ollama", _ollama_host(), model)

    endpoint = _openai_base_url()
    if endpoint is not None:
        return _unverified_profile_for_model("openai-compatible", endpoint, model)
    return _unverified_profile_for_model("ollama", _ollama_host(), model)


def _ollama_profile_for_model(endpoint: str, model: str) -> RuntimeProfile:
    configured_context = _context_from_env()
    discovered_context = _context_from_ollama_show(_ollama_show(endpoint, model))
    context = configured_context or discovered_context
    warnings: list[str] = []
    estimated = context is None
    if context is None:
        context = 4096
        warnings.append(
            "Ollama did not report a context window; using a conservative "
            "4096-token estimate."
        )
    return RuntimeProfile(
        kind="ollama",
        model=model,
        endpoint=endpoint,
        context_window_tokens=context,
        context_window_estimated=estimated,
        supports_compaction=True,
        warnings=warnings,
    )


def _ollama_candidate_profile_for_model(endpoint: str, model: str) -> RuntimeProfile:
    context = _context_from_env()
    return RuntimeProfile(
        kind="ollama",
        model=model,
        endpoint=endpoint,
        context_window_tokens=context,
        context_window_estimated=context is None,
        supports_compaction=True,
        warnings=[],
    )


def _hydrate_runtime_profile(profile: RuntimeProfile) -> RuntimeProfile:
    if profile.kind == "ollama" and profile.endpoint and profile.model:
        return _ollama_profile_for_model(profile.endpoint, profile.model)
    return profile


def _context_from_env() -> int | None:
    for name in ("REMAIND_OPENAI_NUM_CTX", "REMAIND_OLLAMA_NUM_CTX"):
        raw = os.environ.get(name, "").strip()
        if not raw:
            continue
        try:
            value = int(raw)
        except ValueError:
            continue
        if value > 0:
            return value
    return None


def _context_from_ollama_show(payload: dict[str, Any] | None) -> int | None:
    if not isinstance(payload, dict):
        return None
    model_info = payload.get("model_info")
    if not isinstance(model_info, dict):
        return None
    for key, value in model_info.items():
        if not isinstance(key, str):
            continue
        normalized = key.lower()
        if normalized.endswith(".context_length") or normalized in {
            "context_length",
            "n_ctx",
            "num_ctx",
        }:
            try:
                parsed = int(value)
            except (TypeError, ValueError):
                continue
            if parsed > 0:
                return parsed
    return None


def _openai_profile(options: LaunchOptions) -> RuntimeProfile | None:
    endpoint = _openai_base_url()
    if endpoint is None:
        return None
    models = _openai_models(endpoint)
    model = _model_match(models, options.model or os.environ.get("REMAIND_OPENAI_MODEL"))
    if model is None:
        return None
    return _openai_profile_for_model(endpoint, model)


def _ollama_profile(options: LaunchOptions) -> RuntimeProfile | None:
    endpoint = _ollama_host()
    models = _ollama_models(endpoint)
    model = _model_match(models, options.model or os.environ.get("REMAIND_OLLAMA_MODEL"))
    if model is None:
        return None
    return _ollama_profile_for_model(endpoint, model)


def _candidate_runtime_profiles(options: LaunchOptions) -> list[RuntimeProfile]:
    if os.environ.get("REMAIND_DISABLE_LOCAL_MODEL"):
        return []
    profiles: list[RuntimeProfile] = []
    if options.runtime in {"auto", "openai-compatible"}:
        endpoint = _openai_base_url()
        if endpoint is not None:
            profiles.extend(
                _openai_profile_for_model(endpoint, model)
                for model in _openai_models(endpoint)
            )
    if options.runtime in {"auto", "ollama"}:
        endpoint = _ollama_host()
        profiles.extend(
            _ollama_candidate_profile_for_model(endpoint, model)
            for model in _ollama_models(endpoint)
        )

    seen: set[tuple[str, str | None, str | None]] = set()
    deduped: list[RuntimeProfile] = []
    for profile in profiles:
        key = _profile_key(profile)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(profile)
    return deduped


def _runtime_label(
    profile: RuntimeProfile,
    *,
    current: bool = False,
    show_runtime: bool = False,
) -> str:
    raw_model = str(profile.model or "Unknown model")
    label = _friendly_model_label(raw_model)
    details: list[str] = []
    if label != raw_model:
        details.append(raw_model)
    if show_runtime:
        if profile.kind == "ollama":
            details.append("Ollama")
        elif _endpoint_is_local(profile.endpoint):
            details.append("local server")
        else:
            details.append("API")
    if profile.unverified:
        details.append("YOLO / skips model test")
    if profile.context_window_tokens:
        context = f"{profile.context_window_tokens:,} ctx"
        if profile.context_window_estimated:
            context += " estimated"
        details.append(context)
    if current:
        details.append("current default")
    if details:
        label += f" ({'; '.join(details)})"
    return label


def _friendly_model_label(model: str) -> str:
    normalized = model.split(":", 1)[0].lower().replace("_", "-")
    if normalized == "deepseek-v4-flash":
        return "DeepSeek V4 Flash"
    if normalized.startswith("deepseek"):
        words = [word for word in normalized.replace("-", " ").split() if word]
        return " ".join(_friendly_deepseek_word(word) for word in words)
    return model


def _friendly_deepseek_word(word: str) -> str:
    if word == "deepseek":
        return "DeepSeek"
    if word.startswith("v") and word[1:].isdigit():
        return word.upper()
    return word.capitalize()


def _candidate_yolo_profile(profile: RuntimeProfile) -> RuntimeProfile:
    if profile.kind not in {"ollama", "openai-compatible"}:
        raise LaunchError("YOLO model mode needs a local model runtime")
    if not profile.model or not profile.endpoint:
        raise LaunchError("YOLO model mode needs a model and local endpoint")
    context = profile.context_window_tokens
    context_estimated = profile.context_window_estimated
    warnings = [
        *profile.warnings,
        "YOLO model mode selected: Remaind did not verify this model before "
        "continuing. If it cannot load, the later model call will fail clearly.",
    ]
    if context is None:
        context = 4096
        context_estimated = True
        warnings.append(
            "Context window was not verified; using a conservative "
            "4096-token estimate."
        )
    return RuntimeProfile(
        kind=profile.kind,
        model=profile.model,
        endpoint=profile.endpoint,
        context_window_tokens=context,
        context_window_estimated=context_estimated,
        supports_compaction=profile.supports_compaction,
        warnings=warnings,
        unverified=True,
    )


def _select_api_runtime_profile(
    options: LaunchOptions,
    *,
    allow_back: bool = False,
) -> RuntimeProfile:
    default_endpoint = _openai_base_url() or "https://api.openai.com/v1"
    raw_endpoint = _ask(
        options,
        "OpenAI-compatible API /v1 endpoint"
        + (" (type b to go back)" if allow_back else ""),
        default=default_endpoint,
    )
    if allow_back and raw_endpoint.strip().lower() in {"b", "back"}:
        raise _LaunchBack
    endpoint = _normalize_endpoint(raw_endpoint)

    existing_key = os.environ.get("REMAIND_OPENAI_API_KEY", "").strip()
    api_key = existing_key
    if not api_key:
        api_key = _ask_secret(
            options,
            "API key (optional, hidden, not saved)",
            default="",
        )

    profiles = _openai_profiles_for_endpoint(endpoint, api_key=api_key or None)
    if not profiles:
        model = _ask(
            options,
            "Model name"
            + (" (leave blank to go back)" if allow_back else ""),
        ).strip()
        if not model:
            if allow_back:
                raise _LaunchBack
            raise LaunchError("model name is required for API model mode")
        return _openai_profile_for_model(endpoint, model, api_key=api_key or None)

    selected = _select_runtime_profile_from_menu(
        options,
        title="API models",
        candidates=profiles,
        current=profiles[0],
        allow_yolo=False,
        allow_api=False,
        allow_back=allow_back,
    )
    if selected is None:
        return profiles[0]
    return selected


def _yolo_runtime_target(
    options: LaunchOptions,
    *,
    current: RuntimeProfile | None,
) -> tuple[str, str]:
    if options.runtime == "fallback":
        raise LaunchError("YOLO model mode needs a local model runtime")
    if options.runtime == "ollama":
        return ("ollama", _ollama_host())
    if options.runtime == "openai-compatible":
        endpoint = _openai_base_url()
        if endpoint is not None:
            return ("openai-compatible", endpoint)
        endpoint = _normalize_endpoint(
            _ask(
                options,
                "Local model server URL",
                default="http://127.0.0.1:8000/v1",
            )
        )
        return ("openai-compatible", endpoint)
    if current is not None and current.kind in {"ollama", "openai-compatible"}:
        if current.endpoint:
            return (current.kind, current.endpoint)
    endpoint = _openai_base_url()
    if endpoint is not None:
        return ("openai-compatible", endpoint)
    return ("ollama", _ollama_host())


def _select_yolo_runtime_profile(
    options: LaunchOptions,
    *,
    current: RuntimeProfile | None = None,
    allow_back: bool = False,
) -> RuntimeProfile:
    kind, endpoint = _yolo_runtime_target(options, current=current)

    env_default = (
        os.environ.get("REMAIND_OLLAMA_MODEL", "")
        if kind == "ollama"
        else os.environ.get("REMAIND_OPENAI_MODEL", "")
    ).strip()
    current_default = current.model if current is not None and current.kind == kind else None
    default_model = current_default or options.model or env_default or None
    model = _ask(
        options,
        "Model name to load in YOLO mode"
        + (" (type b to go back)" if allow_back else ""),
        default=default_model,
    ).strip()
    if allow_back and model.lower() in {"b", "back"}:
        raise _LaunchBack
    if not model:
        if allow_back:
            raise _LaunchBack
        raise LaunchError("model name is required for YOLO model mode")
    return _unverified_profile_for_model(kind, endpoint, model)


def _select_runtime_profile_from_menu(
    options: LaunchOptions,
    *,
    title: str,
    candidates: list[RuntimeProfile],
    current: RuntimeProfile | None = None,
    allow_yolo: bool = True,
    allow_api: bool = True,
    allow_back: bool = False,
) -> RuntimeProfile | None:
    if not candidates and not allow_yolo and not allow_api:
        return None
    current_key = _profile_key(current) if current is not None else None
    default_index = 0
    if current_key is not None:
        for index, profile in enumerate(candidates):
            if _profile_key(profile) == current_key:
                default_index = index
                break
    choices: list[MenuChoice[Any]] = []
    yolo_index_by_key: dict[tuple[str, str | None, str | None], int] = {}
    for index, profile in enumerate(candidates):
        show_runtime = sum(
            1 for candidate in candidates if candidate.model == profile.model
        ) > 1
        key = _profile_key(profile)
        choices.append(
            MenuChoice(
                _runtime_label(
                    profile,
                    current=key == current_key,
                    show_runtime=show_runtime,
                ),
                profile,
                shortcut=str(index + 1) if index < 9 else None,
            )
        )
        if allow_yolo:
            yolo_index_by_key[key] = len(choices)
            choices.append(
                MenuChoice(
                    _runtime_label(
                        _candidate_yolo_profile(profile),
                        current=key == current_key,
                        show_runtime=show_runtime,
                    ),
                    _candidate_yolo_profile(profile),
                )
            )
    if allow_api:
        choices.append(
            MenuChoice(
                "Connect API model (OpenAI-compatible)",
                _API_MODEL,
                shortcut="a",
            )
        )
    if allow_yolo:
        choices.append(
            MenuChoice(
                "Model not listed (advanced)",
                _MANUAL_MODEL,
                shortcut="m",
            )
        )
    if current is not None and current.kind == "fallback":
        choices.append(
            MenuChoice(
                "Continue without a model (packet-only)",
                current,
                shortcut="n",
            )
        )
        default_index = len(choices) - 1
    elif options.yolo_model and current_key in yolo_index_by_key:
        default_index = yolo_index_by_key[current_key]
    if allow_back:
        choices.append(_back_choice())

    while True:
        selected = _select_menu_value(
            options,
            title=title,
            choices=choices,
            default_index=default_index,
        )
        if selected is _BACK:
            raise _LaunchBack
        if isinstance(selected, RuntimeProfile):
            return selected if selected.unverified else _hydrate_runtime_profile(selected)
        if selected is _API_MODEL:
            try:
                return _select_api_runtime_profile(options, allow_back=allow_back)
            except _LaunchBack:
                continue
        if selected is _MANUAL_MODEL:
            try:
                return _select_yolo_runtime_profile(
                    options,
                    current=current,
                    allow_back=allow_back,
                )
            except _LaunchBack:
                continue
        break

    _out(options).write(f"{title}\n")
    for index, choice in enumerate(choices, start=1):
        _out(options).write(f"  {index}. {choice.label}\n")
    while True:
        default = str(default_index + 1)
        answer = _ask(options, "Select model", default=default).strip().lower()
        if allow_back and answer in {"b", "back"}:
            raise _LaunchBack
        if allow_yolo and answer in {"m", "manual", "other", "not listed"}:
            try:
                return _select_yolo_runtime_profile(
                    options,
                    current=current,
                    allow_back=allow_back,
                )
            except _LaunchBack:
                continue
        if allow_api and answer in {"a", "api", "cloud"}:
            try:
                return _select_api_runtime_profile(options, allow_back=allow_back)
            except _LaunchBack:
                continue
        if current is not None and current.kind == "fallback" and answer in {
            "n",
            "no",
            "none",
            "fallback",
        }:
            return current
        try:
            index = int(answer)
        except ValueError:
            _out(options).write(f"Choose 1-{len(choices)}.\n")
            continue
        if 1 <= index <= len(choices):
            choice_value = choices[index - 1].value
            if isinstance(choice_value, RuntimeProfile):
                return (
                    choice_value
                    if choice_value.unverified
                    else _hydrate_runtime_profile(choice_value)
                )
            if choice_value is _MANUAL_MODEL:
                try:
                    return _select_yolo_runtime_profile(
                        options,
                        current=current,
                        allow_back=allow_back,
                    )
                except _LaunchBack:
                    continue
            if choice_value is _API_MODEL:
                try:
                    return _select_api_runtime_profile(options, allow_back=allow_back)
                except _LaunchBack:
                    continue
            if choice_value is _BACK:
                raise _LaunchBack
        back_hint = " or `b` to go back" if allow_back else ""
        _out(options).write(f"Choose 1-{len(choices)}{back_hint}.\n")


def _maybe_select_runtime_interactively(
    options: LaunchOptions,
    profile: RuntimeProfile,
    *,
    allow_back: bool = False,
) -> tuple[RuntimeProfile, bool]:
    if (
        options.skip_runtime_selection
        or not _is_interactive(options)
        or (profile.kind == "fallback" and options.runtime == "fallback")
    ):
        return profile, False
    if options.yolo_model and not options.model:
        return (
            _select_yolo_runtime_profile(
                options,
                current=profile,
                allow_back=allow_back,
            ),
            True,
        )
    if options.model:
        return profile, False
    candidates = _candidate_runtime_profiles(options)
    if not candidates and profile.kind != "fallback":
        return profile, False
    selected = _select_runtime_profile_from_menu(
        options,
        title="Models",
        candidates=candidates,
        current=profile,
        allow_back=allow_back,
    )
    return selected or profile, True


def _fallback_profile(reason: str | None = None) -> RuntimeProfile:
    warnings = [
        reason
        or "No local model runtime selected; Remaind can still prepare memory "
        "and evidence packets without model generation."
    ]
    return RuntimeProfile(
        kind="fallback",
        model=None,
        endpoint=None,
        context_window_tokens=None,
        context_window_estimated=True,
        supports_compaction=False,
        warnings=warnings,
    )


def select_runtime(options: LaunchOptions) -> RuntimeProfile:
    if options.runtime not in RUNTIME_KINDS:
        allowed = ", ".join(sorted(RUNTIME_KINDS))
        raise LaunchError(f"--runtime must be one of: {allowed}")
    if options.yolo_model:
        if options.runtime == "fallback":
            raise LaunchError("--yolo-model cannot be combined with --runtime fallback")
        if options.model:
            return _explicit_yolo_profile(options)
        if options.non_interactive:
            raise LaunchError("--yolo-model requires --model in non-interactive mode")
        return _fallback_profile("YOLO model mode requested; choose a model manually.")

    if options.runtime == "fallback":
        return _fallback_profile("Rule-based fallback selected explicitly.")
    if options.runtime == "openai-compatible":
        profile = _openai_profile(options)
        if profile is None:
            if _is_interactive(options):
                return _fallback_profile(
                    "OpenAI-compatible API requested; connect an API model."
                )
            raise LaunchError(
                "OpenAI-compatible runtime was requested but no reachable model "
                "was found. Set REMAIND_OPENAI_BASE_URL and REMAIND_OPENAI_MODEL."
            )
        return profile
    if options.runtime == "ollama":
        profile = _ollama_profile(options)
        if profile is None:
            raise LaunchError(
                "Ollama runtime was requested but no reachable model was found. "
                f"Start Ollama at {DEFAULT_OLLAMA_HOST} or set OLLAMA_HOST."
            )
        return profile

    # Auto mode honors an explicitly configured OpenAI-compatible endpoint
    # first. That prevents a user's DeepSeek/llama-server setup from being
    # silently shadowed just because Ollama also happens to be running.
    profile = _openai_profile(options)
    if profile is not None:
        return profile
    profile = _ollama_profile(options)
    if profile is not None:
        return profile
    return _fallback_profile()


def _check_context_writable(paths: ContextPaths) -> tuple[bool, str]:
    probe = paths.root / ".launch-write-test"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as exc:
        return False, str(exc)
    return True, "writable"


def _check_sqlite(base: Path) -> tuple[bool, str]:
    try:
        conn = open_db(base)
        conn.execute("SELECT 1").fetchone()
        conn.close()
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"
    return True, "ready"


def _check_disk(base: Path) -> tuple[bool, str]:
    try:
        usage = shutil.disk_usage(base)
    except OSError as exc:
        return False, str(exc)
    if usage.free < MIN_FREE_BYTES:
        return False, f"only {usage.free} bytes free"
    free_mb = usage.free // (1024 * 1024)
    return True, f"{free_mb} MB free"


def _positive_float_env(name: str, *, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def _launch_smoke_timeout_value() -> str:
    launch_timeout = _positive_float_env(
        LAUNCH_MODEL_TIMEOUT_ENV,
        default=DEFAULT_LAUNCH_MODEL_TIMEOUT_S,
    )
    current_raw = os.environ.get("REMAIND_LOCAL_MODEL_TIMEOUT", "").strip()
    if not current_raw:
        return str(launch_timeout)
    try:
        current = float(current_raw)
    except ValueError:
        return str(launch_timeout)
    return str(min(current, launch_timeout)) if current > 0 else str(launch_timeout)


def _runtime_smoke(profile: RuntimeProfile) -> tuple[bool, str]:
    if profile.kind == "fallback":
        return True, "packet-only fallback"
    if not profile.model or not profile.endpoint:
        return False, "runtime did not resolve a model"
    previous_timeout = os.environ.get("REMAIND_LOCAL_MODEL_TIMEOUT")
    os.environ["REMAIND_LOCAL_MODEL_TIMEOUT"] = _launch_smoke_timeout_value()
    try:
        if profile.kind == "ollama":
            result = OllamaCompactor(
                host=profile.endpoint,
                model=profile.model,
                api_mode=_ollama_api_mode_from_env(),
            ).smoke_test()
        else:
            with _patched_env(_openai_secret_env(profile)):
                result = OpenAICompatibleCompactor(
                    base_url=profile.endpoint,
                    model=profile.model,
                ).smoke_test()
    except CompactorResponseError as exc:
        return False, str(exc)
    finally:
        if previous_timeout is None:
            os.environ.pop("REMAIND_LOCAL_MODEL_TIMEOUT", None)
        else:
            os.environ["REMAIND_LOCAL_MODEL_TIMEOUT"] = previous_timeout
    if result.get("ok"):
        api = result.get("api")
        return True, str(api or "passed")
    return False, str(result.get("error") or "test prompt failed")


def run_readiness_checks(
    base: Path,
    profile: RuntimeProfile,
    *,
    fallback_accepted: bool,
) -> ReadinessReport:
    paths = ContextPaths.at(base)
    checks: list[Check] = []
    warnings = list(profile.warnings)
    failures: list[str] = []

    def add(name: str, passed: bool, detail: str = "") -> None:
        checks.append(Check(name, passed, detail))
        if not passed:
            failures.append(f"{name}: {detail}".rstrip(": "))

    add(".context", paths.root.is_dir(), str(paths.root))
    writable, writable_detail = _check_context_writable(paths)
    add("context_writable", writable, writable_detail)

    validation = validate_cmd.run(base)
    validation_detail = (
        "valid"
        if validation.ok
        else "; ".join(f"{label}: {reason}" for label, reason in validation.failed)
    )
    add("schemas_valid", validation.ok, validation_detail)

    sqlite_ok, sqlite_detail = _check_sqlite(base)
    add("sqlite", sqlite_ok, sqlite_detail)

    disk_ok, disk_detail = _check_disk(base)
    add("disk_space", disk_ok, disk_detail)

    if profile.kind == "fallback":
        accepted = fallback_accepted
        add("runtime_reachable", accepted, "fallback accepted" if accepted else "")
        add("model_reachable", accepted, "fallback accepted" if accepted else "")
        add("test_prompt", accepted, "not run in fallback mode" if accepted else "")
        if accepted:
            warnings.append(
                "No local model will be called; file/paste modes will prepare "
                "packets unless another runtime is selected."
            )
    elif profile.unverified:
        add("runtime_reachable", True, f"{profile.kind} selected without probe")
        add("model_reachable", True, f"{profile.model} (unverified)")
        add("test_prompt", True, "skipped by YOLO model mode")
        warnings.append(
            "Model readiness was skipped by YOLO model mode; the first real "
            "model call is the proof."
        )
    else:
        add("runtime_reachable", True, profile.kind)
        add("model_reachable", bool(profile.model), profile.model or "")
        smoke_ok, smoke_detail = _runtime_smoke(profile)
        add("test_prompt", smoke_ok, smoke_detail)

    if profile.context_window_tokens:
        detail = f"{profile.context_window_tokens} tokens"
        if profile.context_window_estimated:
            detail += " estimated"
            warnings.append("Context window is estimated, not reported by runtime.")
        add("context_window", True, detail)
    elif profile.kind == "fallback":
        add("context_window", True, "not applicable in fallback mode")
    else:
        add("context_window", False, "unknown")

    policy = packet_policy_for_context(profile.context_window_tokens)
    add("packet_policy", True, policy.summary)

    return ReadinessReport(
        ready=not failures,
        checks=checks,
        warnings=warnings,
        failures=failures,
    )


def _can_continue_packet_only(readiness: ReadinessReport) -> bool:
    if readiness.ready or not readiness.failures:
        return False
    model_readiness_checks = {
        "context_window",
        "model_reachable",
        "runtime_reachable",
        "test_prompt",
    }
    failed_checks = {
        failure.split(":", 1)[0].strip()
        for failure in readiness.failures
        if failure.strip()
    }
    return bool(failed_checks) and failed_checks <= model_readiness_checks


def _maybe_continue_packet_only(
    base: Path,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    options: LaunchOptions,
) -> tuple[RuntimeProfile, ReadinessReport]:
    if (
        readiness.ready
        or profile.kind == "fallback"
        or options.non_interactive
        or not _stdin(options).isatty()
        or not _can_continue_packet_only(readiness)
    ):
        return profile, readiness
    if not _confirm(
        options,
        (
            "The local model failed its readiness check. Continue with "
            "memory-only packet fallback?"
        ),
        default_yes=True,
    ):
        return profile, readiness
    fallback = _fallback_profile(
        "Local model readiness failed; continuing with packet-only fallback. "
        "Original failure(s): "
        + "; ".join(readiness.failures)
    )
    fallback_readiness = run_readiness_checks(
        base,
        fallback,
        fallback_accepted=True,
    )
    return fallback, fallback_readiness


def _maybe_reselect_runtime_after_failure(
    base: Path,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    options: LaunchOptions,
) -> tuple[RuntimeProfile, ReadinessReport]:
    if (
        readiness.ready
        or profile.kind == "fallback"
        or options.model
        or options.non_interactive
        or not _stdin(options).isatty()
        or not _can_continue_packet_only(readiness)
    ):
        return profile, readiness

    failed: set[tuple[str, str | None, str | None]] = {_profile_key(profile)}
    while True:
        candidates = [
            candidate
            for candidate in _candidate_runtime_profiles(options)
            if _profile_key(candidate) not in failed
        ]
        if not candidates:
            return profile, readiness
        selected = _select_runtime_profile_from_menu(
            options,
            title="Selected model failed readiness. Choose another model",
            candidates=candidates,
            allow_back=True,
        )
        if selected is None:
            return profile, readiness
        selected_readiness = run_readiness_checks(
            base,
            selected,
            fallback_accepted=False,
        )
        if selected_readiness.ready or not _can_continue_packet_only(selected_readiness):
            return selected, selected_readiness
        failed.add(_profile_key(selected))
        profile = selected
        readiness = selected_readiness


def _select_input_mode(options: LaunchOptions, *, allow_back: bool = False) -> str:
    if options.input_mode:
        if options.input_mode not in INPUT_MODES:
            allowed = ", ".join(sorted(INPUT_MODES))
            raise LaunchError(f"--input must be one of: {allowed}")
        return options.input_mode
    if not _is_interactive(options):
        return "empty"
    choices = [
        ("1", "ask", "Ask from memory state", "a"),
        ("2", "paste", "Paste prompt", "p"),
        ("3", "file", "Load prompt from file", "f"),
        ("4", "resume", "Prepare memory packet only", "r"),
        ("5", "handover", "Update handover.md", "ctrl+h"),
    ]
    selected = _select_menu_value(
        options,
        title="How do you want to continue?",
        choices=[
            MenuChoice(label, mode, shortcut=shortcut)
            for _number, mode, label, shortcut in choices
        ]
        + ([_back_choice()] if allow_back else []),
        default_index=0,
    )
    if selected is _BACK:
        raise _LaunchBack
    if isinstance(selected, str):
        return selected

    _out(options).write("How do you want to continue?\n")
    for number, _mode, label, _shortcut in choices:
        _out(options).write(f"  {number}. {label}\n")
    if allow_back:
        _out(options).write("  b. Back\n")
    while True:
        answer = _ask(options, "Select input mode", default="1").lower()
        if allow_back and answer in {"b", "back"}:
            raise _LaunchBack
        for number, mode, label, shortcut in choices:
            if answer in {number, mode, label.lower()}:
                return mode
            if answer == shortcut:
                return mode
        back_hint = ", or back" if allow_back else ""
        _out(options).write(
            f"Choose ask, paste, file, resume, handover{back_hint}.\n"
        )


def _looks_like_document_path(raw: str) -> Path | None:
    candidate = Path(raw).expanduser()
    if not candidate.is_file():
        return None
    if candidate.suffix.lower() not in DOCUMENT_EXTENSIONS:
        return None
    return candidate.resolve()


def _classify_launch_intent(raw: str) -> _LaunchIntent:
    text = " ".join(raw.strip().split())
    lowered = text.lower()
    tokens = set(re.findall(r"[a-z0-9]+", lowered))
    doc_path = _looks_like_document_path(text)
    if doc_path is not None:
        return _LaunchIntent("file", file_path=doc_path)
    if lowered in {"empty", "start empty", "terminal", "shell", "continue in shell"}:
        return _LaunchIntent("empty")
    if lowered in {
        "resume",
        "resume packet",
        "prepare resume",
        "prepare memory",
        "prepare memory packet",
        "memory packet",
    }:
        return _LaunchIntent("resume")
    if lowered.startswith(("prepare ", "build ", "create ", "generate ")) and (
        "resume" in tokens or ("memory" in tokens and "packet" in tokens)
    ):
        return _LaunchIntent("resume")
    if lowered in {
        "handover",
        "update handover",
        "update handover.md",
        "create handover",
        "create handover.md",
        "save handover",
        "save handover.md",
        "compact",
        "ctrl+h",
    }:
        return _LaunchIntent("handover")
    if "handover" in tokens and tokens & {"update", "save", "create", "write"}:
        return _LaunchIntent("handover")
    if lowered in {"paste", "paste prompt", "paste input"}:
        return _LaunchIntent("paste")
    if lowered in {"file", "load file", "load prompt", "load prompt from file"}:
        return _LaunchIntent("file")
    return _LaunchIntent("ask", question=text)


def _select_launch_intent(
    options: LaunchOptions,
    *,
    allow_back: bool = False,
) -> _LaunchIntent:
    if options.input_mode:
        return _LaunchIntent(_select_input_mode(options, allow_back=allow_back))
    if not _is_interactive(options):
        return _LaunchIntent("empty")

    prompt = (
        "What do you want to do? Ask in plain language, or press Enter for options"
    )
    if allow_back:
        prompt += " (type back to go back)"
    raw = _ask(options, prompt).strip()
    if raw:
        if allow_back and raw.lower() in {"b", "back"}:
            raise _LaunchBack
        return _classify_launch_intent(raw)
    return _LaunchIntent(_select_input_mode(options, allow_back=allow_back))


def _task(options: LaunchOptions) -> str:
    if options.task and options.task.strip():
        return options.task.strip()
    if options.non_interactive or not _stdin(options).isatty():
        return DEFAULT_TASK
    raw = _ask(
        options,
        "What should the memory state do with this input?",
        default=DEFAULT_TASK,
    )
    return raw.strip() or DEFAULT_TASK


def _question(
    options: LaunchOptions,
    *,
    allow_back: bool = False,
    allow_empty: bool = False,
    prompt: str | None = None,
) -> str:
    if options.task and options.task.strip():
        return options.task.strip()
    if not _is_interactive(options):
        raise LaunchError("--task is required when --input ask is used")
    prompt = prompt or "What do you want to know about this workspace?"
    if allow_back:
        prompt += " (leave blank to go back)"
    elif allow_empty:
        prompt += " (leave blank to finish)"
    raw = _ask(options, prompt)
    if not raw.strip():
        if allow_back:
            raise _LaunchBack
        if allow_empty:
            return ""
        raise LaunchError("question cannot be empty")
    return raw.strip()


def _runtime_run_kwargs(profile: RuntimeProfile) -> dict[str, Any]:
    if profile.kind == "ollama":
        return {
            "model_name": profile.model,
            "ollama_host": profile.endpoint,
            "ollama_api": os.environ.get("REMAIND_OLLAMA_API") or "auto",
            "num_ctx": profile.context_window_tokens,
        }
    if profile.kind == "openai-compatible":
        return {
            "model_name": profile.model,
            "openai_base_url": profile.endpoint,
            "openai_api_key": profile.api_key,
            "num_ctx": profile.context_window_tokens,
        }
    return {}


def _runtime_compact_env(profile: RuntimeProfile) -> dict[str, str | None]:
    if profile.kind == "ollama":
        env = {
            "OLLAMA_HOST": profile.endpoint,
            "REMAIND_OLLAMA_MODEL": profile.model,
            "REMAIND_OPENAI_BASE_URL": None,
            "REMAIND_OPENAI_MODEL": None,
            "REMAIND_DISABLE_LOCAL_MODEL": None,
        }
        if profile.context_window_tokens:
            env["REMAIND_OLLAMA_NUM_CTX"] = str(profile.context_window_tokens)
        return env
    if profile.kind == "openai-compatible":
        env = {
            "REMAIND_OPENAI_BASE_URL": profile.endpoint,
            "REMAIND_OPENAI_MODEL": profile.model,
            "REMAIND_OLLAMA_MODEL": None,
            "REMAIND_DISABLE_LOCAL_MODEL": None,
            **_openai_secret_env(profile),
        }
        if profile.context_window_tokens:
            env["REMAIND_OPENAI_NUM_CTX"] = str(profile.context_window_tokens)
        return env
    return {"REMAIND_DISABLE_LOCAL_MODEL": "1"}


def _run_file(
    base: Path,
    profile: RuntimeProfile,
    options: LaunchOptions,
    file_path: Path,
    *,
    task_override: str | None = None,
    emit_progress: bool = True,
    extra_queries: list[str] | None = None,
    progress_kind: str = "run",
) -> run_cmd.RunResult:
    deep_compact = _should_deep_compact(options, file_path)
    mode = _memory_mode(options)
    token_cap = options.token_cap
    if token_cap is None:
        token_cap = mode.run_token_cap
    with _patched_env(_memory_mode_env(mode)):
        return run_cmd.execute(
            base,
            file_path,
            task_override or _task(options),
            auto_init=False,
            no_model=profile.kind == "fallback",
            token_cap=token_cap,
            max_results=options.max_results,
            answer_key_path=options.answer_key_path,
            deep_compact=deep_compact,
            deep_compact_mode=options.deep_compact_mode,
            reuse_deep_compact=options.reuse_deep_compact,
            deep_compact_chunk_tokens=options.deep_compact_chunk_tokens,
            extra_queries=extra_queries,
            progress_callback=_progress_callback(options) if emit_progress else None,
            progress_kind=progress_kind,
            **_runtime_run_kwargs(profile),
        )


def _read_text_for_question(path: Path, *, max_chars: int) -> tuple[str, bool]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return "", False
    if len(text) <= max_chars:
        return text, False
    return text[:max_chars], True


def _all_artifact_files(active_path: Path, history_dir: Path) -> list[Path]:
    candidates: list[Path] = []
    if active_path.is_file():
        candidates.append(active_path)
    if history_dir.is_dir():
        history_files = [path for path in history_dir.iterdir() if path.is_file()]
        history_files.sort(
            key=lambda path: (
                _safe_mtime_ns(path),
                path.name,
            ),
            reverse=True,
        )
        candidates.extend(history_files)
    return candidates


def _is_generated_memory_question_packet(path: Path) -> bool:
    text, _truncated = _read_text_for_question(path, max_chars=12_000)
    return (
        "Remaind Memory Question Source" in text
        or "/artifacts/launch-questions/" in text
        or "\\artifacts\\launch-questions\\" in text
    )


def _artifact_pair_key(path: Path, active_path: Path) -> str:
    if path == active_path:
        return "__active__"
    return path.name


def _filter_generated_memory_question_artifacts(
    paths: ContextPaths,
    *,
    packet_files: list[Path],
    answer_files: list[Path],
) -> tuple[list[Path], list[Path]]:
    """Remove Remaind's own generated Q&A artifacts from continuation context."""

    active_packet_path = paths.active_dir / "run_packet.md"
    active_answer_path = paths.active_dir / "run_answer.md"
    generated_keys: set[str] = set()
    kept_packet_files: list[Path] = []
    for path in packet_files:
        key = _artifact_pair_key(path, active_packet_path)
        if _is_generated_memory_question_packet(path):
            generated_keys.add(key)
            continue
        kept_packet_files.append(path)
    kept_answer_files = [
        path
        for path in answer_files
        if _artifact_pair_key(path, active_answer_path) not in generated_keys
    ]
    return kept_packet_files, kept_answer_files


def _question_requests_packet_history(question: str) -> bool:
    terms = set(_project_query_terms(question))
    lowered = question.lower()
    if terms & _PACKET_HISTORY_QUERY_TERMS:
        return True
    return (
        "run packet" in lowered
        or "resume packet" in lowered
        or "run answer" in lowered
    )


def _question_requests_all_packet_context(question: str) -> bool:
    if _question_requested_packet_count(question) is not None:
        return False
    terms = set(_project_query_terms(question))
    if not terms & _PACKET_HISTORY_QUERY_TERMS:
        return False
    return bool(terms & {"all", "complete", "everything", "every", "full"})


def _question_requested_packet_count(question: str) -> int | None:
    lowered = question.lower()
    match = re.search(
        r"\b(?:last|latest|recent)\s+(\d{1,2})\s+"
        r"(?:run[_\s-]*)?(?:packets?|answers?)\b",
        lowered,
    )
    if match is None:
        match = re.search(
            r"\b(\d{1,2})\s+(?:most\s+)?(?:recent|latest|last)\s+"
            r"(?:run[_\s-]*)?(?:packets?|answers?)\b",
            lowered,
        )
    if match is None:
        return None
    return max(1, min(int(match.group(1)), 20))


def _artifact_relevance_score(path: Path, terms: list[str]) -> int:
    if not terms:
        return 0
    text = _normalize_workspace_text(
        _safe_read_text(path, max_chars=WORKSPACE_INDEX_ARTIFACT_CHARS)
    )
    if not text:
        return 0
    tokens = frozenset(text.split())
    score = 0
    for term in terms:
        if term in tokens:
            score += 3
        elif term in text:
            score += 1
    for phrase in _query_phrases(terms):
        if phrase in text:
            score += 4
    return score


def _child_project_relevance_score(path: Path, terms: list[str]) -> int:
    if not terms:
        return 0
    name = _normalize_workspace_text(path.name)
    full_path = _normalize_workspace_text(str(path))
    name_tokens = frozenset(name.split())
    path_tokens = frozenset(full_path.split())
    score = 0
    normalized_query = " ".join(terms)
    if name == normalized_query:
        score += 160
    if normalized_query in name:
        score += 110
    if normalized_query in full_path:
        score += 70
    for phrase in _query_phrases(terms):
        if phrase in name:
            score += 50
        if phrase in full_path:
            score += 30
    for term in terms:
        if term in name_tokens:
            score += 35
        elif _fuzzy_token_match(term, name_tokens):
            score += 20
        if term in path_tokens:
            score += 15
    return score


def _matching_child_project_dirs(base: Path, query_text: str | None) -> list[Path]:
    if not query_text:
        return []
    terms = _project_query_terms(query_text)
    if not terms:
        return []
    ranked = [
        (_child_project_relevance_score(path, terms), path)
        for path in _workspace_child_project_dirs(base)
    ]
    ranked = [(score, path) for score, path in ranked if score >= 35]
    ranked.sort(key=lambda item: (-item[0], item[1].name.lower()))
    return [path for _score, path in ranked[:MEMORY_QUESTION_CHILD_PROJECT_LIMIT]]


def _project_context_file_score(path: Path) -> int:
    name = path.name.lower()
    relative = str(path).lower()
    parts = tuple(part.lower() for part in path.parts)
    score = 0
    if name == "claude.md":
        # Root CLAUDE.md commonly carries product rules and scope locks. It
        # must outrank audit/quality plans and command templates when the user
        # asks for project status.
        score += 900
    if name == "experiment.yaml" and "experiment" in parts:
        # Product/spec source of truth for experiment-template projects.
        score += 850
    if relative.endswith("/docs/project-state.md") or relative.endswith(
        "/docs/project_state.md",
    ):
        score += 840
    if relative.endswith("/docs/master-plan.md") or relative.endswith(
        "/docs/master_plan.md",
    ):
        score += 780
    if relative.endswith((
        "/docs/status.md",
        "/docs/plan.md",
        "/docs/todo.md",
        "/docs/handover.md",
        "/docs/roadmap.md",
    )):
        score += 760
    if name in {"product.md", "product.yaml", "product.yml", "spec.md"}:
        score += 760
    if name in {"handover.md", "plan.md", "todo.md", "status.md"}:
        score += 700
    if "plan" in name:
        score += 80
    elif name == "readme.md":
        score += 120
    elif name in {"claude.md", "agents.md"}:
        score += 60
    high_value_markers = (
        "plan",
        "roadmap",
        "scope",
        "status",
        "todo",
        "next",
        "handover",
        "brief",
        "incident",
        "rollback",
        "recovery",
        "monitor",
        "security",
        "skill",
        "command",
        "pattern",
    )
    supporting_markers = (
        "architecture",
        "design",
        "experiment",
    )
    if "/.claude/" in relative:
        score += 45
    if "/commands/" in relative:
        score += 120
    if "/patterns/" in relative:
        score += 40
    if "/stacks/hosting/" in relative:
        score += 120
    if "/skills/" in relative or "/procedures/" in relative:
        score -= 80
    if "/experiment/" in relative:
        score += 30
    if name in {
        "deploy.md",
        "incident-response.md",
        "iterate.md",
        "railway.md",
        "recovery.md",
        "rollback.md",
        "vercel.md",
    }:
        score += 180
    if name.startswith("state-"):
        score -= 140
    for marker in high_value_markers:
        if marker in name:
            score += 90
        if f"/{marker}" in relative:
            score += 20
    for marker in supporting_markers:
        if marker in name:
            score += 30
        if f"/{marker}" in relative:
            score += 10
    return score


def _is_explicit_lower_authority_query(terms: list[str] | None) -> bool:
    if not terms:
        return False
    return bool(
        {
            "audit",
            "champion",
            "elevation",
            "quality",
            "world",
            "world-champion",
        }
        & set(terms)
    )


def _is_lower_authority_project_context(path: Path) -> bool:
    relative = str(path).lower()
    return (
        "world-champion" in relative
        or "quality-elevation" in relative
        or "/.claude/commands/" in relative
        or "/.claude/patterns/" in relative
    )


def _is_product_authority_candidate(project_dir: Path, path: Path) -> bool:
    relative = _project_relative_path(project_dir, path).lower()
    name = path.name.lower()
    return (
        relative == "claude.md"
        or relative in {"experiment/experiment.yaml", "experiment/experiment.yml"}
        or relative
        in {
            "docs/project-state.md",
            "docs/project_state.md",
            "docs/master-plan.md",
            "docs/master_plan.md",
            "docs/status.md",
            "docs/plan.md",
            "docs/todo.md",
            "docs/handover.md",
            "docs/roadmap.md",
        }
        or relative in {"status.md", "todo.md", "handover.md", "plan.md"}
        or name
        in {
            "product.md",
            "product.yaml",
            "product.yml",
            "spec.md",
            "spec.yaml",
            "spec.yml",
        }
    )


def _project_context_files(
    project_dir: Path,
    *,
    query_terms: list[str] | None = None,
) -> list[Path]:
    candidates: list[Path] = []
    root_authority_names = {
        "agents.md",
        "claude.md",
        "handover.md",
        "plan.md",
        "readme.md",
        "status.md",
        "todo.md",
    }
    try:
        candidates.extend(
            path
            for path in project_dir.iterdir()
            if path.is_file() and path.name.lower() in root_authority_names
        )
    except OSError:
        pass
    for relative_dir in ("docs", ".claude", "experiment"):
        docs_dir = project_dir / relative_dir
        if not docs_dir.is_dir():
            continue
        try:
            docs = [
                path
                for path in docs_dir.rglob("*")
                if path.is_file()
                and path.suffix.lower() in DOCUMENT_EXTENSIONS
                and not any(part in DISCOVERY_SKIP_DIRS for part in path.parts)
            ]
        except OSError:
            docs = []
        candidates.extend(path for path in docs if _project_context_file_score(path))
    deduped = _dedupe_paths(candidates)
    if (
        any(_is_product_authority_candidate(project_dir, path) for path in deduped)
        and not _is_explicit_lower_authority_query(query_terms)
    ):
        deduped = [
            path for path in deduped if not _is_lower_authority_project_context(path)
        ]
    ranked = [
        (_project_context_file_score(path), index, path)
        for index, path in enumerate(deduped)
    ]
    ranked.sort(key=lambda item: (-item[0], item[1], str(item[2]).lower()))
    return [
        path
        for score, _index, path in ranked
        if score > 0
    ][:MEMORY_QUESTION_CHILD_PROJECT_FILE_LIMIT]


def _project_authority_file_score(project_dir: Path, path: Path) -> int:
    relative = _project_relative_path(project_dir, path).lower()
    name = path.name.lower()
    if relative == "claude.md":
        return 1_000
    if relative in {"experiment/experiment.yaml", "experiment/experiment.yml"}:
        return 950
    if relative in {"docs/project-state.md", "docs/project_state.md"}:
        return 925
    if relative in {"status.md", "todo.md", "handover.md", "plan.md"}:
        return 900
    if relative in {
        "docs/status.md",
        "docs/plan.md",
        "docs/todo.md",
        "docs/handover.md",
    }:
        return 890
    if relative in {
        "docs/master-plan.md",
        "docs/master_plan.md",
        "docs/roadmap.md",
    }:
        return 875
    if name in {
        "product.md",
        "product.yaml",
        "product.yml",
        "spec.md",
        "spec.yaml",
        "spec.yml",
    }:
        return 850
    return 0


def _project_authority_files(project_dir: Path, files: list[Path]) -> list[Path]:
    ranked = [
        (_project_authority_file_score(project_dir, path), index, path)
        for index, path in enumerate(files)
    ]
    ranked = [(score, index, path) for score, index, path in ranked if score > 0]
    ranked.sort(key=lambda item: (-item[0], item[1], str(item[2]).lower()))
    return [path for _score, _index, path in ranked][
        :MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_LIMIT
    ]


def _plain_plan_item_text(text: str) -> str:
    cleaned = re.sub(r"[*`#]+", "", text).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = re.sub(r"^\[[ xX]\]\s*", "", cleaned)
    code_pattern = (
        r"^(?P<code>(?:S|PR)-[A-Z]|[hb]-\d{1,4}|[HB]-\d{1,4})\b"
        r"(?:\s*\([^)]*\))?\s*[:\-\u2013\u2014]\s*(?P<body>.+)$"
    )
    match = re.match(code_pattern, cleaned)
    if not match:
        return cleaned
    return match.group("body").strip()


def _yaml_plan_label_from_window(lines: list[str], status_index: int) -> str | None:
    start = max(0, status_index - 8)
    window = lines[start : status_index + 1]
    fields: dict[str, str] = {}
    for raw in window:
        stripped = raw.strip().strip("-").strip()
        match = re.match(r"(id|name|title|summary|description)\s*:\s*(.+)$", stripped)
        if not match:
            continue
        value = match.group(2).strip().strip("'\"")
        if value:
            fields[match.group(1)] = value
    body = fields.get("name") or fields.get("title") or fields.get("summary")
    if not body:
        body = fields.get("description")
    code = fields.get("id")
    if body and code:
        return body
    return body or code


def _extract_repo_plan_items(project_dir: Path, files: list[Path]) -> list[_RepoPlanItem]:
    items: list[_RepoPlanItem] = []
    authority_files = _project_authority_files(project_dir, files)
    if authority_files:
        files = authority_files
    for path in files:
        relative = _project_relative_path(project_dir, path)
        text = _safe_read_text(path, max_chars=120_000)
        lines = text.splitlines()
        for index, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                continue
            checklist = re.match(r"^[-*]\s*\[(?P<mark>[ xX])\]\s*(?P<body>.+)$", stripped)
            if checklist:
                status = "done" if checklist.group("mark").lower() == "x" else "pending"
                items.append(
                    _RepoPlanItem(
                        status=status,
                        text=_plain_plan_item_text(checklist.group("body")),
                        source=relative,
                        line_number=index + 1,
                    )
                )
                continue
            next_match = re.match(
                r"^(?:immediate\s+)?next(?:\s+step)?\s*:\s*(?P<body>.+)$",
                stripped,
                flags=re.IGNORECASE,
            )
            if next_match:
                items.append(
                    _RepoPlanItem(
                        status="next",
                        text=_plain_plan_item_text(next_match.group("body")),
                        source=relative,
                        line_number=index + 1,
                    )
                )
                continue
            status_match = re.match(
                r"status\s*:\s*(?P<status>pending|todo|open|blocked|done|complete|completed|pass|passing)\b",
                stripped,
                flags=re.IGNORECASE,
            )
            if status_match:
                raw_status = status_match.group("status").lower()
                status = "pending"
                if raw_status in {"done", "complete", "completed", "pass", "passing"}:
                    status = "done"
                elif raw_status == "blocked":
                    status = "blocked"
                label = _yaml_plan_label_from_window(lines, index)
                if label:
                    items.append(
                        _RepoPlanItem(
                            status=status,
                            text=_plain_plan_item_text(label),
                            source=relative,
                            line_number=index + 1,
                        )
                    )
                continue
            coded = re.match(
                r"^[-*]\s*(?P<body>(?:\*\*)?(?:S|PR)-[A-Z](?:\*\*)?.+)$",
                stripped,
            )
            if coded:
                items.append(
                    _RepoPlanItem(
                        status="planned",
                        text=_plain_plan_item_text(coded.group("body")),
                        source=relative,
                        line_number=index + 1,
                    )
                )
    deduped: list[_RepoPlanItem] = []
    seen: set[tuple[str, str]] = set()
    for item in items:
        key = (item.status, item.text.lower())
        if key in seen or not item.text:
            continue
        seen.add(key)
        deduped.append(item)
    priority = {"next": 0, "blocked": 1, "pending": 2, "planned": 3, "done": 4}
    deduped.sort(key=lambda item: priority.get(item.status, 5))
    return deduped


def _render_repo_plan_review(project_dir: Path, files: list[Path]) -> list[str]:
    authority_files = _project_authority_files(project_dir, files)
    if not authority_files:
        return []
    items = _extract_repo_plan_items(project_dir, authority_files)
    rows = [
        "## REMAIND-LAUNCH-CONTEXT REPO PLAN REVIEW",
        "",
        (
            "This section is computed by reviewing the repo's loaded product "
            "plan, status, handover, TODO, roadmap, and framework files. Use it "
            "to suggest the next step in plain English before falling back to "
            "older packets."
        ),
        (
            "Rule: plan/framework IDs are trace labels, not user-facing tasks. "
            "Do not expose labels like S-A, h-01, b-001, or PR-A in the terminal "
            "answer unless the user explicitly asks for source IDs. Explain the "
            "milestone in ordinary language."
        ),
        "",
        "Reviewed plan/framework files:",
    ]
    for path in authority_files:
        rows.append(f"- {_project_relative_path(project_dir, path)}")
    rows.append("")
    if not items:
        rows.extend(
            [
                "Detected plan items: none with explicit status/checklist/next-step markers.",
                (
                    "Suggested next step: read the highest-authority product "
                    "files above and explain what plan/status marker is missing."
                ),
                "",
            ]
        )
        return rows
    rows.append("Detected plan/progress items:")
    for item in items[:MEMORY_QUESTION_REPO_PLAN_REVIEW_ITEM_LIMIT]:
        rows.append(
            f"- {item.status}: {item.text} "
            f"(source: {item.source}:{item.line_number})"
        )
    actionable = next(
        (item for item in items if item.status in {"next", "blocked", "pending", "planned"}),
        None,
    )
    rows.append("")
    if actionable:
        rows.append(
            "Suggested next step: "
            f"{actionable.text} (from {actionable.source}:{actionable.line_number})."
        )
    else:
        rows.append(
            "Suggested next step: no pending plan item was detected; ask for "
            "current product instructions or inspect the status/handover files."
        )
    rows.append("")
    return rows


def _render_project_authority_brief(project_dir: Path, files: list[Path]) -> list[str]:
    authority_files = _project_authority_files(project_dir, files)
    if not authority_files:
        return []
    product_status_files = [
        path
        for path in authority_files
        if path.name.lower() in {"status.md", "todo.md", "handover.md", "plan.md"}
    ]
    rows = [
        "## REMAIND-LAUNCH-CONTEXT PROJECT AUTHORITY BRIEF",
        "",
        f"Project folder: {project_dir.name}",
        f"Path: {project_dir}",
        (
            "Use this brief as the highest-authority product context for "
            "workspace status, continuation, TODO, and next-step questions."
        ),
        (
            "Authority order: root product/spec/status/handover/plan files beat "
            "audit, quality, world-champion, agent-command, rollback, "
            "incident-response, and template-improvement docs unless one of "
            "these authority files points to those docs as the current focus."
        ),
        (
            "Continuation rule: do not make the user's status question, packet "
            "generation, model verification, or Remaind runtime readiness the "
            "product's next implementation step. If no status or handover file "
            "names a more recent task, choose the earliest pending product-plan "
            "spike, behavior, or task from these authority files."
        ),
        (
            "Progress evidence rule: do not infer that a product component, "
            "spike, behavior, or test is implemented merely because it appears "
            "in a spec or architecture section. Only status, handover, TODO, "
            "plan files, or explicit current conversation can prove completed "
            "implementation progress. Treat fields that say `pending` as pending."
        ),
        "",
    ]
    if product_status_files:
        rows.append(
            "Loaded product status/handover files: "
            + ", ".join(_project_relative_path(project_dir, path) for path in product_status_files)
        )
    else:
        rows.append(
            "Loaded product status/handover files: none. Specific implementation "
            "progress is not captured in the loaded authority files."
        )
    rows.append("")
    for path in authority_files:
        text, truncated = _read_text_for_question(
            path,
            max_chars=MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_CHARS,
        )
        rows.append(f"Authority file: {_project_relative_path(project_dir, path)}")
        if truncated:
            rows.append(
                "Note: excerpt truncated to "
                f"{MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_CHARS} characters."
            )
        for line in text.strip().splitlines()[
            :MEMORY_QUESTION_PROJECT_AUTHORITY_FILE_LINES
        ]:
            rows.append(f"  {line}")
        rows.append("")
    return rows


def _project_plan_file_status(project_dir: Path, files: list[Path]) -> list[str]:
    if _project_authority_files(project_dir, files):
        files = [
            path
            for path in files
            if _project_authority_file_score(project_dir, path) > 0
        ]
    expected: list[str] = []
    for path in files:
        name = path.name.lower()
        if "plan" not in name and name not in {"todo.md", "status.md", "handover.md"}:
            continue
        text = _safe_read_text(path, max_chars=120_000)
        for match in re.finditer(r"\*\*File to create:\*\*\s*`([^`]+)`", text):
            rel = match.group(1).strip()
            if rel and rel not in expected:
                expected.append(rel)
    if not expected:
        return []
    rows = [
        "#### Current implementation file status from loaded plan",
        "",
        (
            "This status is computed from plan entries that say "
            "`File to create`. The first missing file is usually the next "
            "implementation target unless a newer status/handover file says "
            "otherwise."
        ),
        "",
    ]
    for rel in expected[:24]:
        path = project_dir / rel
        if path.is_file():
            try:
                size = path.stat().st_size
            except OSError:
                size = 0
            rows.append(f"- `{rel}`: exists ({size} bytes)")
        else:
            rows.append(f"- `{rel}`: missing")
    if len(expected) > 24:
        rows.append(f"- note: {len(expected) - 24} additional planned file(s) omitted")
    rows.append("")
    return rows


def _render_matching_child_project_context(
    base: Path,
    query_text: str | None,
) -> list[str]:
    matches = _matching_child_project_dirs(base, query_text)
    if not matches:
        return []
    query_terms = _project_query_terms(query_text or "")
    project_files = [
        (project_dir, _project_context_files(project_dir, query_terms=query_terms))
        for project_dir in matches
    ]
    rows: list[str] = []
    for project_dir, files in project_files:
        rows.extend(_render_project_authority_brief(project_dir, files))
        rows.extend(_render_repo_plan_review(project_dir, files))
    if rows:
        rows.append("")
    rows.extend([
        "## Matching Project Folder Context",
        "",
        (
            "This workspace memory matched a child project folder. Treat these "
            "project files as current workspace evidence when reconstructing "
            "the active product plan."
        ),
        (
            "HARD RULE: if this section is present, the matching project files "
            "are already loaded below. Do not say the product files, plan, or "
            "roadmap are missing; answer from these files and name any specific "
            "file that supports the next step."
        ),
        (
            "PRODUCT AUTHORITY RULE: root product/spec files such as CLAUDE.md, "
            "experiment/experiment.yaml, STATUS.md, TODO.md, HANDOVER.md, and "
            "PLAN.md define product scope and current plan. Audit, quality, "
            "world-champion, agent, command, rollback, incident-response, or "
            "template-improvement docs are lower-authority implementation "
            "evidence unless a higher-authority product/spec file points to "
            "them as the current focus."
        ),
        "",
    ])
    for project_dir, files in project_files:
        rows.append(f"### Project folder: {project_dir.name}")
        rows.append("")
        rows.append(f"Path: {project_dir}")
        rows.append("")
        rows.extend(_project_plan_file_status(project_dir, files))
        if not files:
            rows.append("No README, handover, plan, status, or docs files found.")
            rows.append("")
            continue
        for index, path in enumerate(files, start=1):
            text, truncated = _read_text_for_question(
                path,
                max_chars=MEMORY_QUESTION_CHILD_PROJECT_FILE_CHARS,
            )
            rows.append(f"#### {index}. {_project_relative_path(project_dir, path)}")
            rows.append("")
            if truncated:
                rows.append(
                    "Note: content truncated to "
                    f"{MEMORY_QUESTION_CHILD_PROJECT_FILE_CHARS} characters."
                )
                rows.append("")
            rows.append("```text")
            rows.append(text.strip())
            rows.append("```")
            rows.append("")
    return rows


def _prioritize_artifacts_for_question(files: list[Path], question: str) -> list[Path]:
    terms = _project_query_terms(question)
    if not terms:
        return files
    ranked = [
        (_artifact_relevance_score(path, terms), index, path)
        for index, path in enumerate(files)
    ]
    ranked.sort(key=lambda item: (-item[0], item[1]))
    return [path for _score, _index, path in ranked]


def _question_requests_continuation_brief(question: str) -> bool:
    return classify_context_intent(question).wants_continuation


def _question_requests_workspace_continuation(
    question: str,
    workspace_query: str | None,
) -> bool:
    return classify_context_intent(
        question,
        workspace_query=workspace_query,
    ).wants_continuation


def _render_current_conversation(
    conversation_history: list[tuple[str, str | None]],
) -> list[str]:
    if not conversation_history:
        return []
    rows = [
        "## Current Terminal Conversation",
        "",
        "This conversation happened after the memory packet was built. Treat it as newer than contradictory historical packet text.",
    ]
    for index, (question, answer) in enumerate(conversation_history, start=1):
        rows.append("")
        rows.append(f"### Turn {index}")
        rows.append("")
        rows.append(f"User: {question.strip()}")
        if answer:
            rows.append("")
            rows.append(f"Assistant: {answer.strip()}")
    return rows


def _render_current_runtime_authority(
    profile: RuntimeProfile,
    readiness: ReadinessReport,
) -> list[str]:
    rows = [
        "## REMAIND-LAUNCH-CONTEXT CURRENT RUNTIME STATUS",
        "",
        (
            "This block is authoritative for the current terminal request. "
            "Older packet, answer, event, or resume text may contain historical "
            "model failures; do not report those as current blockers unless "
            "they are repeated in Current failures below."
        ),
        "",
        f"- Current readiness: {'ready' if readiness.ready else 'blocked'}",
        f"- Runtime: {profile.kind}",
    ]
    if profile.model:
        rows.append(f"- Model: {profile.model}")
    if profile.endpoint:
        rows.append(f"- Endpoint: {profile.endpoint}")
    if profile.context_window_tokens:
        rows.append(f"- Context window: {profile.context_window_tokens} tokens")
    if readiness.failures:
        rows.append("- Current failures: " + "; ".join(readiness.failures))
    else:
        rows.append("- Current failures: none")
        if profile.kind != "fallback":
            rows.append(
                "- Current model status: this answer request reached the selected "
                "runtime; historical 401, connection-refused, RemoteDisconnected, "
                "or local-model-failed entries are not current blockers."
            )
            if profile.unverified:
                rows.append(
                    "- YOLO readiness note: the preflight model probe was skipped, "
                    "but a displayed answer proves the selected model completed "
                    "this real request. Do not list model verification as a "
                    "current blocker or next TODO."
                )
    warnings = _runtime_warnings_for_model_context(profile, readiness)
    if warnings:
        label = "Current warnings" if readiness.failures else "Current non-blocking warnings"
        rows.append(f"- {label}: " + "; ".join(warnings))
    return rows


def _runtime_warnings_for_model_context(
    profile: RuntimeProfile,
    readiness: ReadinessReport,
) -> list[str]:
    warnings = list(readiness.warnings)
    if profile.unverified and not readiness.failures:
        warnings = [
            warning
            for warning in warnings
            if "YOLO model mode" not in warning
            and "Model readiness was skipped" not in warning
        ]
    return warnings


def _artifact_inventory_line(kind: str, path: Path, active_path: Path) -> str:
    label = "active" if path == active_path else "history"
    try:
        stat = path.stat()
    except OSError:
        return f"- {kind}: {path.name} ({label}); unreadable; path: {path}"
    return (
        f"- {kind}: {path.name} ({label}); "
        f"{stat.st_size:,} bytes; modified_ns={stat.st_mtime_ns}; path: {path}"
    )


def _render_packet_inventory(paths: ContextPaths) -> list[str]:
    packet_files = _all_artifact_files(
        paths.active_dir / "run_packet.md",
        paths.history_dir / "run_packet",
    )
    answer_files = _all_artifact_files(
        paths.active_dir / "run_answer.md",
        paths.history_dir / "run_answer",
    )
    rows = [
        "## Workspace Packet Inventory",
        "",
        (
            f"Found {len(packet_files)} run packet(s) and "
            f"{len(answer_files)} run answer note(s). This inventory is always "
            "included so the model knows what packet evidence exists for the selected workspace."
        ),
        "",
    ]
    if not packet_files and not answer_files:
        rows.append("No prior run packets or answer notes found.")
        return rows
    for path in packet_files:
        rows.append(
            _artifact_inventory_line(
                "run_packet",
                path,
                paths.active_dir / "run_packet.md",
            )
        )
    for path in answer_files:
        rows.append(
            _artifact_inventory_line(
                "run_answer",
                path,
                paths.active_dir / "run_answer.md",
            )
        )
    return rows


def _should_render_progress_snapshot(
    snapshot: dict[str, Any],
    *,
    has_child_project_context: bool,
) -> bool:
    if not has_child_project_context:
        return True
    phase = str(snapshot.get("phase") or "").lower()
    status = str(snapshot.get("status") or "").lower()
    return bool(
        snapshot.get("error_or_blocker")
        or phase in {"blocked", "model_call_started", "packet_ready", "started"}
        or status in {"blocked", "implementing"}
    )


def _render_artifacts(
    *,
    title: str,
    files: list[Path],
    active_path: Path,
    per_file_max_chars: int,
    total_budget_chars: int | None = None,
) -> list[str]:
    rows = [f"## {title}", ""]
    if not files:
        rows.append("No recent files found.")
        return rows
    remaining = total_budget_chars
    omitted: list[Path] = []
    for index, path in enumerate(files, start=1):
        if remaining is not None and remaining <= 0:
            omitted.extend(files[index - 1 :])
            break
        read_limit = per_file_max_chars
        if remaining is not None:
            read_limit = min(read_limit, remaining)
        text, truncated = _read_text_for_question(
            path,
            max_chars=read_limit,
        )
        if remaining is not None:
            remaining -= len(text)
        label = "active" if path == active_path else "history"
        rows.append(f"### {index}. {path.name} ({label})")
        rows.append("")
        rows.append(f"Path: {path}")
        if truncated:
            rows.append(
                f"Note: content truncated to {read_limit} characters for this memory question."
            )
        rows.append("")
        rows.append("```text")
        rows.append(text.strip())
        rows.append("```")
        rows.append("")
    if omitted:
        rows.append("### Omitted because the packet-context budget was reached")
        rows.append("")
        for path in omitted:
            rows.append(f"- {path}")
    return rows


def _append_indented_text(rows: list[str], text: str, *, empty: str = "(empty)") -> None:
    body = text.strip()
    if not body:
        rows.append(f"  {empty}")
        return
    for line in body.splitlines():
        rows.append(f"  {line}")


def _append_limited_indented_text(
    rows: list[str],
    text: str,
    *,
    max_lines: int,
    empty: str = "(empty)",
) -> None:
    body = text.strip()
    if not body:
        rows.append(f"  {empty}")
        return
    lines = body.splitlines()
    for line in lines[:max_lines]:
        rows.append(f"  {line}")
    if len(lines) > max_lines:
        rows.append(f"  note: truncated to first {max_lines} lines")


def _render_continuation_critical_context(paths: ContextPaths) -> list[str]:
    rows = [
        "## REMAIND-LAUNCH-CONTEXT CONTINUATION BRIEF EVIDENCE",
        "",
        (
            "Purpose: this marker block is force-included in the Remaind run "
            "packet before normal search evidence. Use it as the first source "
            "for the active plan, current state, latest progress, blockers, "
            "and next implementation step."
        ),
        "",
    ]
    active_packet_path = paths.active_dir / "run_packet.md"
    active_run_is_memory_question = _is_generated_memory_question_packet(
        active_packet_path,
    )
    critical_files = [
        ("active/handover.md", paths.handover_md, CONTINUATION_CRITICAL_FILE_CHARS),
        ("active/state.json", paths.state_json, CONTINUATION_CRITICAL_FILE_CHARS),
        (
            "active/resume_packet.md",
            paths.resume_packet,
            CONTINUATION_CRITICAL_FILE_CHARS,
        ),
    ]
    if not active_run_is_memory_question:
        critical_files.extend(
            [
                (
                    "active/run_packet.md",
                    active_packet_path,
                    CONTINUATION_CRITICAL_PACKET_CHARS,
                ),
            ],
        )
    for label, path, max_chars in critical_files:
        text, truncated = _read_text_for_question(path, max_chars=max_chars)
        rows.append(f"{label}:")
        rows.append(f"  path: {path}")
        if truncated:
            rows.append(f"  note: truncated to {max_chars} characters")
        _append_indented_text(rows, text, empty="not found")
        rows.append("")
    rows.append("active/run_answer.md:")
    rows.append(f"  path: {paths.active_dir / 'run_answer.md'}")
    rows.append(
        "  skipped: model-generated answer notes are lower-authority than "
        "project files, handover/state, resume packets, and run packets for "
        "continuation planning"
    )
    rows.append("")
    if active_run_is_memory_question:
        rows.append("active/run_packet.md:")
        rows.append(f"  path: {active_packet_path}")
        rows.append(
            "  skipped: generated memory-question packet; not project-plan evidence",
        )
        rows.append("")

    history_packet_files = [
        path
        for path in _all_artifact_files(
            active_packet_path,
            paths.history_dir / "run_packet",
        )
        if path != active_packet_path
    ]
    history_packet_files, _ = _filter_generated_memory_question_artifacts(
        paths,
        packet_files=history_packet_files,
        answer_files=[],
    )
    history_files = [
        (
            "recent historical run_answer",
            [],
            CONTINUATION_CRITICAL_FILE_CHARS,
        ),
        (
            "recent historical run_packet",
            history_packet_files,
            CONTINUATION_CRITICAL_PACKET_CHARS,
        ),
    ]
    for label, history, max_chars in history_files:
        rows.append(f"{label}:")
        history = history[:CONTINUATION_CRITICAL_HISTORY_LIMIT]
        if not history:
            rows.append("  not found")
            rows.append("")
            continue
        for path in history:
            text, truncated = _read_text_for_question(path, max_chars=max_chars)
            rows.append(f"  file: {path}")
            if truncated:
                rows.append(f"  note: truncated to {max_chars} characters")
            _append_indented_text(rows, text, empty="empty")
            rows.append("")
    return rows


def _render_packet_history_critical_context(
    *,
    packet_files: list[Path],
    answer_files: list[Path],
    active_packet_path: Path,
    active_answer_path: Path,
) -> list[str]:
    rows = [
        "## REMAIND-LAUNCH-CONTEXT PACKET HISTORY EVIDENCE",
        "",
        (
            "Purpose: this marker block is force-included in the Remaind run "
            "packet for packet-history questions. It carries the selected "
            "recent packet and answer-note contents before ordinary search "
            "evidence so the model can answer from real workspace artifacts."
        ),
        "",
    ]
    remaining = PACKET_HISTORY_CRITICAL_TOTAL_CHARS
    omitted: list[Path] = []

    def append_artifact(kind: str, path: Path, active_path: Path) -> None:
        nonlocal remaining
        if remaining <= 0:
            omitted.append(path)
            return
        read_limit = min(PACKET_HISTORY_CRITICAL_FILE_CHARS, remaining)
        text, truncated = _read_text_for_question(path, max_chars=read_limit)
        remaining -= len(text)
        label = "active" if path == active_path else "history"
        rows.append(f"{kind}: {path.name} ({label})")
        rows.append(f"  path: {path}")
        if truncated:
            rows.append(f"  note: truncated to {read_limit} characters")
        _append_limited_indented_text(
            rows,
            text,
            max_lines=PACKET_HISTORY_CRITICAL_FILE_LINES,
            empty="empty",
        )
        rows.append("")

    for path in packet_files:
        append_artifact("run_packet", path, active_packet_path)
    for path in answer_files:
        append_artifact("run_answer", path, active_answer_path)
    if omitted:
        rows.append("omitted due to packet-history marker budget:")
        for path in omitted:
            rows.append(f"  - {path}")
    return rows


def _build_memory_question_source(
    base: Path,
    *,
    question: str,
    workspace_query: str | None,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    conversation_history: list[tuple[str, str | None]],
) -> Path:
    paths = ContextPaths.at(base)
    sources: list[ContextSource] = [
        context_source_from_lines(
            id="current_question",
            title="Current Question",
            source_type="current_question",
            authority="current_user",
            freshness="live",
            lines=[],
            mandatory=True,
            reason="The user request is always the highest-authority context.",
            budget_group="question",
        )
    ]

    def add_source(
        *,
        id: str,
        title: str,
        source_type: ContextSourceType,
        authority: ContextAuthority,
        freshness: ContextFreshness,
        lines: list[str],
        mandatory: bool,
        reason: str,
        budget_group: str = "general",
    ) -> None:
        if not lines:
            return
        sources.append(
            context_source_from_lines(
                id=id,
                title=title,
                source_type=source_type,
                authority=authority,
                freshness=freshness,
                lines=lines,
                mandatory=mandatory,
                reason=reason,
                budget_group=budget_group,
            )
        )

    add_source(
        id="runtime_authority",
        title="Current Runtime Status",
        source_type="runtime_status",
        authority="live_status",
        freshness="live",
        lines=_render_current_runtime_authority(profile, readiness),
        mandatory=True,
        reason="Live runtime state prevents stale model-failure history from winning.",
        budget_group="status",
    )
    project_context_query = " ".join(
        part for part in (workspace_query, question) if part
    )
    child_context = _render_matching_child_project_context(
        base,
        project_context_query,
    )
    has_child_project_context = bool(child_context)
    intent = classify_context_intent(question, workspace_query=workspace_query)
    wants_continuation_brief = intent.wants_continuation
    product_status = load_product_status(base)
    if product_status and wants_continuation_brief:
        add_source(
            id="product_status",
            title="Product Continuation Status",
            source_type="product_status",
            authority="live_status",
            freshness="current",
            lines=render_product_status(product_status).splitlines(),
            mandatory=True,
            reason="Durable current product state answers progress, blockers, and next-step questions.",
            budget_group="status",
        )
    plan_reconciliation = load_plan_reconciliation(base)
    if plan_reconciliation and wants_continuation_brief:
        add_source(
            id="plan_reconciliation",
            title="Product Plan Reconciliation",
            source_type="plan_reconciliation",
            authority="product_authority",
            freshness="current",
            lines=render_plan_reconciliation(plan_reconciliation).splitlines(),
            mandatory=True,
            reason="Reconciliation maps saved activity and blockers onto the active product plan.",
            budget_group="plan",
        )
    presence_snapshot = load_presence_snapshot(base)
    if presence_snapshot and wants_continuation_brief:
        add_source(
            id="presence_snapshot",
            title="Remaind Presence Snapshot",
            source_type="presence",
            authority="live_status",
            freshness="current",
            lines=render_presence_snapshot(presence_snapshot).splitlines(),
            mandatory=True,
            reason="Latest shell activity is newer than packets and captures outside-Remaind work.",
            budget_group="presence",
        )
    progress_snapshot = load_progress_snapshot(base)
    if progress_snapshot and _should_render_progress_snapshot(
        progress_snapshot,
        has_child_project_context=has_child_project_context,
    ):
        add_source(
            id="progress_snapshot",
            title="Crash-Safe Progress Snapshot",
            source_type="progress",
            authority="live_status",
            freshness="current",
            lines=render_progress_snapshot(progress_snapshot).splitlines(),
            mandatory=True,
            reason="Crash-safe operation state captures active blockers and incomplete tasks.",
            budget_group="progress",
        )
    if wants_continuation_brief:
        sources.extend(
            structured_memory_context_sources(
                base,
                question=question,
                limit=10,
            )
        )
    if child_context:
        add_source(
            id="matching_child_project_context",
            title="Matching Project Folder Context",
            source_type="product_plan",
            authority="product_authority",
            freshness="current",
            lines=child_context,
            mandatory=True,
            reason="Matching child project files outrank parent workspace packets for product scope and plan.",
            budget_group="plan",
        )
    wants_packet_history = intent.wants_packet_history
    requested_packet_count = intent.requested_packet_count
    wants_all_packet_context = requested_packet_count is None and (
        intent.wants_all_packets
        or (wants_continuation_brief and not has_child_project_context)
    )
    if wants_all_packet_context:
        packet_limit: int | None = None
    elif requested_packet_count is not None:
        packet_limit = requested_packet_count
    elif wants_packet_history:
        packet_limit = MEMORY_QUESTION_HISTORY_LIMIT
    else:
        packet_limit = MEMORY_QUESTION_DEFAULT_PACKET_LIMIT
    packet_files = _all_artifact_files(
        paths.active_dir / "run_packet.md",
        paths.history_dir / "run_packet",
    )
    answer_files = _all_artifact_files(
        paths.active_dir / "run_answer.md",
        paths.history_dir / "run_answer",
    )
    if wants_continuation_brief:
        packet_files, answer_files = _filter_generated_memory_question_artifacts(
            paths,
            packet_files=packet_files,
            answer_files=answer_files,
        )
        answer_files = []
    if packet_limit is not None:
        packet_files = packet_files[:packet_limit]
        answer_files = answer_files[:packet_limit]
    if wants_continuation_brief and requested_packet_count is None:
        packet_files = _prioritize_artifacts_for_question(packet_files, question)
        answer_files = _prioritize_artifacts_for_question(answer_files, question)
    if wants_packet_history or (
        wants_continuation_brief and not has_child_project_context
    ):
        add_source(
            id="packet_history_critical_context",
            title="Packet History Evidence",
            source_type="packet_history",
            authority="source_evidence",
            freshness="recent",
            lines=_render_packet_history_critical_context(
                packet_files=packet_files,
                answer_files=answer_files,
                active_packet_path=paths.active_dir / "run_packet.md",
                active_answer_path=paths.active_dir / "run_answer.md",
            ),
            mandatory=True,
            reason="Explicit packet/history requests and parent-workspace continuation need packet evidence.",
            budget_group="packet",
        )
    if wants_continuation_brief and not has_child_project_context:
        add_source(
            id="continuation_critical_context",
            title="Continuation Critical Context",
            source_type="packet_history",
            authority="source_evidence",
            freshness="recent",
            lines=_render_continuation_critical_context(paths),
            mandatory=True,
            reason="When no matching child project is loaded, recent active/history artifacts anchor continuation.",
            budget_group="packet",
        )
    if wants_continuation_brief and has_child_project_context and not wants_packet_history:
        add_source(
            id="parent_workspace_packet_context_policy",
            title="Parent Workspace Packet Context Policy",
            source_type="artifact_inventory",
            authority="source_evidence",
            freshness="current",
            lines=[
                "## Parent Workspace Packet Context",
                "",
                (
                    "Omitted for this continuation answer because a matching "
                    "child project folder is loaded above. Use the child project "
                    "files as the product plan; ask for packet history explicitly "
                    "to inspect parent workspace packets or prior answers."
                ),
                "",
            ],
            mandatory=True,
            reason="This prevents parent packet noise from overriding matching child project plans.",
            budget_group="policy",
        )
    live_status_lines = [
            "## Current Live Launch Status",
            "",
            f"- Current readiness: {'ready' if readiness.ready else 'blocked'}",
            f"- Runtime: {profile.kind}",
    ]
    if profile.model:
        live_status_lines.append(f"- Model: {profile.model}")
    if profile.endpoint:
        live_status_lines.append(f"- Endpoint: {profile.endpoint}")
    if profile.context_window_tokens:
        live_status_lines.append(f"- Context window: {profile.context_window_tokens} tokens")
    if profile.unverified:
        live_status_lines.append(
            "- Model preflight: skipped by YOLO/unverified mode; if this "
            "terminal answer is displayed, the live model call has already "
            "succeeded. Do not turn preflight verification into a next TODO."
        )
    for check in readiness.checks:
        status = "ok" if check.passed else "failed"
        detail = f" - {check.detail}" if check.detail else ""
        live_status_lines.append(f"- Check {check.name}: {status}{detail}")
    warnings = _runtime_warnings_for_model_context(profile, readiness)
    if warnings:
        label = "Current warnings" if readiness.failures else "Current non-blocking warnings"
        live_status_lines.append(f"- {label}: " + "; ".join(warnings))
    if readiness.failures:
        live_status_lines.append("- Current failures: " + "; ".join(readiness.failures))
    else:
        live_status_lines.append("- Current failures: none")
    add_source(
        id="current_live_launch_status",
        title="Current Live Launch Status",
        source_type="runtime_status",
        authority="live_status",
        freshness="live",
        lines=live_status_lines,
        mandatory=True,
        reason="Live launch status is the freshest runtime evidence.",
        budget_group="status",
    )
    add_source(
        id="current_terminal_conversation",
        title="Current Terminal Conversation",
        source_type="conversation",
        authority="current_session",
        freshness="live",
        lines=_render_current_conversation(conversation_history),
        mandatory=bool(conversation_history),
        reason="Current launch conversation overrides contradictory older memory.",
        budget_group="conversation",
    )
    if wants_continuation_brief and has_child_project_context and not wants_packet_history:
        add_source(
            id="current_resume_packet_policy",
            title="Current Resume Packet Policy",
            source_type="resume_packet",
            authority="source_evidence",
            freshness="current",
            lines=[
                "## Current Resume Packet",
                "",
                (
                    "Omitted for this child-project continuation answer so parent "
                    "workspace resume text cannot override the matching project files."
                ),
                "",
            ],
            mandatory=True,
            reason="Matching child project files are more authoritative than parent resume text.",
            budget_group="policy",
        )
    else:
        resume_rows = ["## Current Resume Packet", ""]
        resume_text, resume_truncated = _read_text_for_question(
            paths.resume_packet,
            max_chars=MEMORY_QUESTION_RESUME_MAX_CHARS,
        )
        if resume_truncated:
            resume_rows.append(
                f"Note: resume packet truncated to {MEMORY_QUESTION_RESUME_MAX_CHARS} characters for this memory question."
            )
            resume_rows.append("")
        resume_rows.append("```text")
        resume_rows.append(resume_text.strip())
        resume_rows.append("```")
        resume_rows.append("")
        add_source(
            id="current_resume_packet",
            title="Current Resume Packet",
            source_type="resume_packet",
            authority="source_evidence",
            freshness="current",
            lines=resume_rows,
            mandatory=True,
            reason="The resume packet is the canonical compact workspace state.",
            budget_group="resume",
        )
    if wants_continuation_brief and has_child_project_context and not wants_packet_history:
        add_source(
            id="workspace_packet_inventory_policy",
            title="Workspace Packet Inventory Policy",
            source_type="artifact_inventory",
            authority="source_evidence",
            freshness="current",
            lines=[
                "## Workspace Packet Inventory",
                "",
                (
                    "Omitted for this child-project continuation answer. Ask "
                    "for packet history explicitly to inspect prior packets or "
                    "answer notes."
                ),
                "",
            ],
            mandatory=True,
            reason="Packet inventory is omitted unless the user explicitly asks for packet history.",
            budget_group="policy",
        )
    else:
        add_source(
            id="workspace_packet_inventory",
            title="Workspace Packet Inventory",
            source_type="artifact_inventory",
            authority="source_evidence",
            freshness="current",
            lines=_render_packet_inventory(paths),
            mandatory=True,
            reason="The model needs to know what packet evidence exists before answering history questions.",
            budget_group="packet",
        )

    if wants_all_packet_context:
        all_packet_instruction = []
        if wants_continuation_brief:
            all_packet_instruction.append(
                "The user wants to continue this workspace. Load the resume "
                "packet plus every packet and answer note that fits the fixed "
                "budget below, then reconstruct the active plan and next step "
                "from that evidence."
            )
        else:
            all_packet_instruction.append(
                "The user asked for full packet context. Load every packet and "
                "answer note that fits the fixed budget below; use the inventory "
                "above to explain any omissions."
            )
        all_packet_instruction.append("")
        add_source(
            id="all_packet_context_instruction",
            title="All Packet Context Instruction",
            source_type="answer_instruction",
            authority="current_session",
            freshness="live",
            lines=all_packet_instruction,
            mandatory=True,
            reason="The user explicitly requested full packet context.",
            budget_group="instruction",
        )
    if (packet_files or answer_files) and not (
        wants_continuation_brief
        and has_child_project_context
        and not wants_packet_history
    ):
        packet_artifact_lines = _render_artifacts(
                title=(
                    "Workspace Run Packets (all, budgeted)"
                    if wants_all_packet_context
                    else f"Recent Run Packets (latest {len(packet_files)})"
                ),
                files=packet_files,
                active_path=paths.active_dir / "run_packet.md",
                per_file_max_chars=MEMORY_QUESTION_PACKET_MAX_CHARS,
                total_budget_chars=(
                    MEMORY_QUESTION_ALL_PACKET_BUDGET_CHARS
                    if wants_all_packet_context
                    else None
                ),
        )
        add_source(
            id="workspace_run_packets",
            title="Workspace Run Packets",
            source_type="packet_history",
            authority="source_evidence",
            freshness="recent",
            lines=packet_artifact_lines,
            mandatory=wants_packet_history,
            reason="Run packets provide source-linked historical evidence.",
            budget_group="packet",
        )
        answer_artifact_lines = _render_artifacts(
                title=(
                    "Workspace Run Answers (all, budgeted)"
                    if wants_all_packet_context
                    else f"Recent Run Answers (latest {len(answer_files)})"
                ),
                files=answer_files,
                active_path=paths.active_dir / "run_answer.md",
                per_file_max_chars=MEMORY_QUESTION_PACKET_MAX_CHARS,
                total_budget_chars=(
                    MEMORY_QUESTION_ALL_PACKET_BUDGET_CHARS
                    if wants_all_packet_context
                    else None
                ),
        )
        add_source(
            id="workspace_run_answers",
            title="Workspace Run Answers",
            source_type="packet_history",
            authority="generated_answer",
            freshness="historical",
            lines=answer_artifact_lines,
            mandatory=wants_packet_history and not wants_continuation_brief,
            reason="Old model answers are useful for explicit history questions but lower authority than plans and packets.",
            budget_group="answer",
        )
    judgment_evidence_texts = [source.content for source in sources]
    recommendation_decision = render_recommendation_decision(
        build_recommendation_decision(
            question,
            judgment_evidence_texts,
        )
    )
    if recommendation_decision:
        add_source(
            id="recommendation_engine",
            title="Remaind Recommendation Engine",
            source_type="answer_instruction",
            authority="current_session",
            freshness="live",
            lines=recommendation_decision.splitlines(),
            mandatory=True,
            reason="Universal recommendation engine selects or shapes the next action from current evidence.",
            budget_group="answer",
        )
    recommendation_judgment = render_recommendation_judgment_section(
        question,
        judgment_evidence_texts,
    )
    if recommendation_judgment:
        add_source(
            id="recommendation_judgment",
            title="Recommendation Judgment",
            source_type="answer_instruction",
            authority="current_session",
            freshness="live",
            lines=recommendation_judgment.splitlines(),
            mandatory=True,
            reason="Shared recommendation judgment keeps memory answers aligned to current constraints.",
            budget_group="answer",
        )
    recall_judgment = render_recall_judgment_section(
        question,
        judgment_evidence_texts,
    )
    if recall_judgment:
        add_source(
            id="recall_judgment",
            title="Recall Judgment",
            source_type="answer_instruction",
            authority="current_session",
            freshness="live",
            lines=recall_judgment.splitlines(),
            mandatory=True,
            reason="Shared recall judgment keeps memory answers grounded in exact user/source evidence.",
            budget_group="answer",
        )
    suggestion_judgment = render_suggestion_judgment_section(
        question,
        judgment_evidence_texts,
    )
    if suggestion_judgment:
        add_source(
            id="suggestion_judgment",
            title="Suggestion Judgment",
            source_type="answer_instruction",
            authority="current_session",
            freshness="live",
            lines=suggestion_judgment.splitlines(),
            mandatory=True,
            reason="Shared suggestion judgment separates new adjacent ideas from repeated or padded options.",
            budget_group="answer",
        )
    context_packet = build_context_packet(
        ContextBuildRequest(
            question=question,
            workspace_query=workspace_query,
            context_window_tokens=profile.context_window_tokens,
        ),
        sources,
    )
    question_dir = paths.artifacts_dir / "launch-questions"
    safe_name = utc_now_filename_safe_us()
    source_path = question_dir / f"{safe_name}-memory-question.md"
    atomic_write_text(source_path, context_packet.content)
    return source_path


def _question_task_with_live_status(
    question: str,
    *,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    conversation_history: list[tuple[str, str | None]] | None = None,
    workspace_query: str | None = None,
) -> str:
    """Add fresh launch state so old runtime failures do not look current."""

    rows = [
        question.strip(),
        "",
        "Current live launch status for this answer:",
        "- This block is newer than all older model/runtime events in the memory packet.",
        "- Because this answer is being generated, the selected model is reachable for this request.",
        "- Do not report older connection-refused, RemoteDisconnected, or local-model-failed events as current blockers when Current failures is none.",
        "- HARD RULE: if Current failures is none, do not list model/runtime/API-key/connectivity as a current blocker. At most, call older model errors historical notes.",
        "- Treat older model failures as historical unless they are repeated in Current failures below.",
        f"- Current readiness: {'ready' if readiness.ready else 'blocked'}",
        f"- Runtime: {profile.kind}",
    ]
    if profile.model:
        rows.append(f"- Model: {profile.model}")
    if profile.endpoint:
        rows.append(f"- Endpoint: {profile.endpoint}")
    if profile.context_window_tokens:
        rows.append(f"- Context window: {profile.context_window_tokens} tokens")
    if profile.unverified:
        rows.append(
            "- Model preflight: skipped by YOLO/unverified mode; if this "
            "terminal answer is displayed, the live model call has already "
            "succeeded. Do not turn preflight verification into a next TODO."
        )
    for check in readiness.checks:
        status = "ok" if check.passed else "failed"
        detail = f" - {check.detail}" if check.detail else ""
        rows.append(f"- Check {check.name}: {status}{detail}")
    warnings = _runtime_warnings_for_model_context(profile, readiness)
    if warnings:
        label = "Current warnings" if readiness.failures else "Current non-blocking warnings"
        rows.append(f"- {label}: " + "; ".join(warnings))
    if readiness.failures:
        rows.append("- Current failures: " + "; ".join(readiness.failures))
    else:
        rows.append("- Current failures: none")
    if conversation_history:
        rows.append("")
        rows.append("Current terminal conversation in this launch:")
        rows.append(
            "- The conversation below is newer than all packet/history text and must override contradictory older memory."
        )
        for index, (past_question, past_answer) in enumerate(
            conversation_history,
            start=1,
        ):
            rows.append(f"- User turn {index}: {past_question.strip()}")
            if past_answer:
                rows.append(f"- Assistant turn {index}: {past_answer.strip()}")
    rows.append("")
    if _question_requests_workspace_continuation(question, workspace_query):
        rows.append(
            "This is a workspace continuation request. Before recommending work, "
            "reconstruct the active plan from the resume packet and packet "
            "library. Answer with: Product scope, Active plan, Latest progress, "
            "Current blockers, Next TODOs, and Immediate next implementation step. "
            "If Matching Project Folder Context is present in the packet, treat "
            "it as primary plan evidence and do not claim project files are "
            "missing. When it conflicts with parent workspace resume or packet "
            "text, use the matching child project files for product scope and "
            "next-step planning. "
            "Runtime readiness, packet generation, and the user's status "
            "question are not product progress or implementation steps. If no "
            "status/handover file names the latest product task, say that "
            "specific progress is not captured and pick the earliest pending "
            "product-plan spike, behavior, or task from the loaded product "
            "authority files. "
            "Translate internal plan IDs, spike codes, behavior IDs, and "
            "hypothesis IDs into plain English for non-technical users. Do "
            "not make the user understand labels like S-A, h-01, b-001, or "
            "PR-A. Hide those labels in the terminal answer unless the user "
            "explicitly asks for source IDs. "
            "Prefer current terminal conversation, then current resume packet, "
            "then recent/all packet evidence. If the plan cannot be determined "
            "from loaded evidence, say exactly what is missing instead of "
            "inventing it."
        )
        rows.append("")
    rows.append(
        "Answer the user's question directly in terminal-chat style. When giving "
        "status, use Current status, Latest progress, Current blockers, and "
        "Next TODOs when those sections fit the question. Do not mention packet "
        "paths unless the user asks for them. Distinguish current blockers from "
        "historical blockers. If the user corrected a stale blocker earlier in "
        "this terminal conversation, treat the correction as current. Keep the "
        "answer understandable without requiring the user to decode internal "
        "plan symbols; prefer names like relay implementation, renderer "
        "integration, or command approval flow over framework codes. When the "
        "answer recommends a next path, use Recommendation Judgment to apply "
        "recency, explicit constraints, dislikes, and avoid/pressure/scale "
        "conflicts before choosing. When the answer recalls what the user said "
        "or mentioned, use Recall Judgment: direct user/source evidence outranks "
        "persona, profession, background profile, and generic plausibility."
    )
    return "\n".join(rows)


def _memory_question_extra_queries(
    question: str,
    *,
    workspace_query: str | None = None,
) -> list[str]:
    queries = [question]
    if _question_requests_workspace_continuation(question, workspace_query):
        queries.extend(
            [
                "Matching Project Folder Context",
                "Parent Workspace Packet Context",
                "the matching project files are already loaded below",
                "Current Question",
                "Ask for packet history explicitly",
                "next implementation step",
                "current product plan",
                "Task A3",
                "Files to modify",
                "Acceptance criteria",
                "File to create",
            ],
        )
        if workspace_query:
            queries.append(workspace_query)
    return queries


def _run_resume_question(
    base: Path,
    profile: RuntimeProfile,
    options: LaunchOptions,
    question: str,
    readiness: ReadinessReport,
    conversation_history: list[tuple[str, str | None]] | None = None,
    workspace_query: str | None = None,
) -> run_cmd.RunResult:
    source_path = _build_memory_question_source(
        base,
        question=question,
        workspace_query=workspace_query,
        profile=profile,
        readiness=readiness,
        conversation_history=conversation_history or [],
    )
    return _run_file(
        base,
        profile,
        options,
        source_path,
        task_override=_question_task_with_live_status(
            question,
            profile=profile,
            readiness=readiness,
            conversation_history=conversation_history,
            workspace_query=workspace_query,
        ),
        emit_progress=False,
        extra_queries=_memory_question_extra_queries(
            question,
            workspace_query=workspace_query,
        ),
        progress_kind="memory_question",
    )


def _run_memory_question(
    base: Path,
    profile: RuntimeProfile,
    options: LaunchOptions,
    question: str,
    readiness: ReadinessReport,
    conversation_history: list[tuple[str, str | None]] | None = None,
    workspace_query: str | None = None,
) -> run_cmd.RunResult:
    run_result = _run_resume_question(
        base,
        profile,
        options,
        question,
        readiness,
        conversation_history=conversation_history,
        workspace_query=workspace_query,
    )
    run_result = _maybe_retry_transient_model_failure(
        base,
        profile,
        options,
        question,
        readiness,
        run_result,
        conversation_history=conversation_history,
        workspace_query=workspace_query,
    )
    _enforce_answer_key_policy(options, run_result)
    return run_result


def _transient_model_error(model_error: str | None) -> bool:
    if not model_error:
        return False
    lowered = model_error.lower()
    return any(marker in lowered for marker in _TRANSIENT_MODEL_ERROR_MARKERS)


def _model_error_needs_free_memory(model_error: str | None) -> bool:
    if not model_error:
        return False
    lowered = model_error.lower()
    return any(
        marker in lowered
        for marker in ("compute error", "insufficient memory", "outofmemory")
    )


def _wait_for_runtime(profile: RuntimeProfile, *, attempts: int, delay_s: float) -> bool:
    for attempt in range(attempts):
        ok, _detail = _runtime_smoke(profile)
        if ok:
            return True
        if attempt + 1 < attempts:
            time.sleep(delay_s)
    return False


def _restart_deepseek_for_retry(
    profile: RuntimeProfile,
    *,
    free_memory: bool = False,
) -> bool:
    if not profile.model or "deepseek" not in profile.model.lower():
        return False
    if not _endpoint_is_local(profile.endpoint):
        return False
    switcher = _deepseek_switcher_path()
    current = _current_deepseek_profile()
    if switcher is None or current not in _DEEPSEEK_PROFILES:
        return False
    extra_args: list[str] = []
    if free_memory and _deepseek_switcher_supports_option(switcher, "--free-memory"):
        extra_args.append("--free-memory")
    elif _deepseek_switcher_supports_option(switcher, "--no-free-memory"):
        extra_args.append("--no-free-memory")
    try:
        _switch_deepseek_profile(switcher, current, extra_args=extra_args)
    except LaunchError:
        return False
    return _wait_for_runtime(profile, attempts=6, delay_s=2.0)


def _maybe_retry_transient_model_failure(
    base: Path,
    profile: RuntimeProfile,
    options: LaunchOptions,
    question: str,
    readiness: ReadinessReport,
    run_result: run_cmd.RunResult,
    conversation_history: list[tuple[str, str | None]] | None = None,
    workspace_query: str | None = None,
) -> run_cmd.RunResult:
    if getattr(run_result, "answer", None) or not _transient_model_error(
        getattr(run_result, "model_error", None)
    ):
        return run_result
    if profile.kind == "fallback" or not _endpoint_is_local(profile.endpoint):
        return run_result
    runtime_ready = _wait_for_runtime(profile, attempts=4, delay_s=1.0)
    if not runtime_ready:
        runtime_ready = _restart_deepseek_for_retry(profile)
    if (
        not runtime_ready
        and _model_error_needs_free_memory(getattr(run_result, "model_error", None))
        and _is_interactive(options)
        and _confirm(
            options,
            "DeepSeek ran out of GPU memory. Free memory and retry now?",
            default_yes=True,
        )
    ):
        runtime_ready = _restart_deepseek_for_retry(profile, free_memory=True)
    if not runtime_ready:
        return run_result
    return _run_resume_question(
        base,
        profile,
        options,
        question,
        readiness,
        conversation_history=conversation_history,
        workspace_query=workspace_query,
    )


def _question_result_message(run_result: run_cmd.RunResult) -> str:
    if getattr(run_result, "model_error", None):
        return (
            "Memory packet prepared, but the model answer failed. "
            "Restart or reselect the model, then ask again."
        )
    return "Answered from the current memory state."


def _render_memory_answer(run_result: dict[str, Any]) -> str:
    answer = run_result.get("answer")
    if answer:
        return str(answer).strip() + "\n"
    model_error = run_result.get("model_error")
    if model_error:
        return (
            "Memory packet prepared, but the model answer failed.\n"
            f"Model error: {model_error}\n"
        )
    return (
        "Memory packet prepared. No model answer was generated for this "
        "question.\n"
    )


def _run_interactive_memory_chat(
    base: Path,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    options: LaunchOptions,
    *,
    allow_back: bool,
    initial_question: str | None = None,
    workspace_query: str | None = None,
) -> run_cmd.RunResult | None:
    last_result: run_cmd.RunResult | None = None
    conversation_history: list[tuple[str, str | None]] = []
    asked_any = False
    queued_question = initial_question
    while True:
        if queued_question is not None:
            question = queued_question
            queued_question = None
        else:
            question = _question(
                options,
                allow_back=allow_back if not asked_any else False,
                allow_empty=not allow_back or asked_any,
                prompt=None if not asked_any else "What else do you want to know?",
            )
        if not question:
            break
        run_result = _run_memory_question(
            base,
            profile,
            options,
            question,
            readiness,
            conversation_history=conversation_history,
            workspace_query=workspace_query,
        )
        last_result = run_result
        _out(options).write(_render_memory_answer(run_result.to_dict()))
        _out(options).flush()
        answer = getattr(run_result, "answer", None)
        model_error = getattr(run_result, "model_error", None)
        conversation_history.append(
            (
                question,
                str(answer).strip()
                if answer
                else (
                    f"Model error: {model_error}"
                    if model_error
                    else "No model answer generated."
                ),
            )
        )
        if getattr(run_result, "model_error", None):
            break
        asked_any = True
    return last_result


def _run_handover_update(
    base: Path,
    profile: RuntimeProfile,
    options: LaunchOptions,
) -> str:
    if _is_interactive(options) and options.show_progress:
        if not _confirm(
            options,
            "Update active/handover.md now?",
            default_yes=True,
        ):
            return "Handover update cancelled."
    with _patched_env(_runtime_compact_env(profile)):
        try:
            result = compact_cmd.run(base)
        except compact_cmd.CompactionRejected as exc:
            raise LaunchError(
                f"handover update rejected by validator: {exc}"
            ) from exc
        except CompactorResponseError as exc:
            raise LaunchError(f"model handover update failed: {exc}") from exc
        except compact_cmd.CompactionError as exc:
            raise LaunchError(str(exc)) from exc
    before = result.handover_chars_before
    after = result.handover_chars_after
    delta = after - before
    sign = "+" if delta >= 0 else ""
    path = ContextPaths.at(base).handover_md
    return (
        f"Updated handover.md via {result.compactor_label}: "
        f"{before} -> {after} chars ({sign}{delta}); "
        f"{result.preserved_count} preserved / {result.window_size} event(s); "
        f"compaction event {result.compaction_event_id}; "
        f"validation event {result.validation_event_id}; "
        f"path: {path}"
    )


def _estimated_file_tokens(file_path: Path) -> int:
    try:
        size = Path(file_path).expanduser().stat().st_size
    except OSError:
        return 0
    return max(1, size // 4)


def _should_deep_compact(options: LaunchOptions, file_path: Path) -> bool:
    if options.deep_compact:
        return True
    tokens = _estimated_file_tokens(file_path)
    if tokens <= DEEP_COMPACTION_RECOMMENDED_TOKENS:
        return False
    if options.non_interactive or not _stdin(options).isatty():
        return False
    return _confirm(
        options,
        (
            f"File is approximately {tokens:,} tokens. Use deep compaction? "
            "(adds local model calls; resumable and cacheable)"
        ),
        default_yes=True,
    )


def _registered_large_documents(base: Path) -> list[Path]:
    root = ContextPaths.at(base).root / "large-docs"
    if not root.is_dir():
        return []
    candidates: list[Path] = []
    for manifest in sorted(root.glob("*/manifest.json")):
        try:
            payload = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        raw_path = payload.get("path")
        if not isinstance(raw_path, str) or not raw_path:
            continue
        path = Path(raw_path).expanduser()
        if path.is_file():
            candidates.append(path)
    return _dedupe_paths(candidates)


def _discover_document_files(base: Path) -> list[Path]:
    candidates = _registered_large_documents(base)
    for root in _discovery_roots(safe_cwd(), base=base):
        for current, _dirnames, filenames in _walk_limited(
            root,
            max_depth=DISCOVERY_MAX_DEPTH,
        ):
            for filename in sorted(filenames):
                path = current / filename
                if path.suffix.lower() not in DOCUMENT_EXTENSIONS:
                    continue
                if path.name.startswith("."):
                    continue
                try:
                    if not path.is_file() or path.stat().st_size <= 0:
                        continue
                except OSError:
                    continue
                candidates.append(path)
                if len(candidates) >= DISCOVERY_LIMIT:
                    return _dedupe_paths(candidates)
    return _dedupe_paths(candidates)[:DISCOVERY_LIMIT]


def _select_prompt_file(
    base: Path,
    options: LaunchOptions,
    *,
    allow_back: bool = False,
) -> Path:
    candidates = _discover_document_files(base)
    if not candidates:
        if allow_back:
            _out(options).write("No prompt files were found. Going back.\n")
            raise _LaunchBack
        return _manual_path_selection(
            options,
            prompt="Prompt file path",
            create_if_missing=False,
        )
    return _select_path_from_menu(
        options,
        title="Prompt files and registered large documents",
        candidates=candidates,
        manual_prompt="Prompt file path",
        create_if_missing=False,
        default_index=1,
        allow_back=allow_back,
    )


def _capture_paste(base: Path, options: LaunchOptions) -> Path:
    paths = ContextPaths.at(base)
    capture_dir = paths.artifacts_dir / "launch-pastes"
    capture_path = capture_dir / f"paste-{utc_now_filename_safe_us()}.md"

    stdin = _stdin(options)
    if stdin.isatty() and not options.non_interactive:
        _out(options).write(
            "Paste your prompt now. Finish with a line containing only "
            f"{DEFAULT_PASTE_END_MARKER}\n"
        )
        lines: list[str] = []
        while True:
            line = stdin.readline()
            if line == "":
                break
            if line.rstrip("\n") == DEFAULT_PASTE_END_MARKER:
                break
            lines.append(line)
        content = "".join(lines)
    else:
        content = stdin.read()

    if not content.strip():
        raise LaunchError("paste input was empty")
    atomic_write_text(capture_path, content if content.endswith("\n") else content + "\n")
    return capture_path


def _dispatch(
    base: Path,
    profile: RuntimeProfile,
    readiness: ReadinessReport,
    mode: str,
    options: LaunchOptions,
    *,
    allow_back: bool = False,
    initial_question: str | None = None,
    workspace_query: str | None = None,
) -> tuple[dict[str, Any] | None, str | None, str | None, str | None, bool]:
    if mode == "empty":
        return (
            None,
            None,
            None,
            "Memory state is active and control returned to your shell. "
            "Natural-language questions typed after this point go to your shell, "
            "not to the memory state. To ask from memory, run `remaind launch` "
            "and choose Ask from memory state, or run `remaind launch --input ask "
            "--task \"your question\"`.",
            False,
        )
    if mode == "ask":
        _run_resume(base, options)
        if _is_interactive(options) and options.task is None and options.show_progress:
            run_result = _run_interactive_memory_chat(
                base,
                profile,
                readiness,
                options,
                allow_back=allow_back,
                initial_question=initial_question,
                workspace_query=workspace_query,
            )
            return (
                run_result.to_dict() if run_result else None,
                str(ContextPaths.at(base).resume_packet),
                None,
                "Memory chat ended.",
                True,
            )
        question = initial_question or _question(options, allow_back=allow_back)
        run_result = _run_memory_question(
            base,
            profile,
            options,
            question,
            readiness,
            workspace_query=workspace_query,
        )
        return (
            run_result.to_dict(),
            str(ContextPaths.at(base).resume_packet),
            None,
            _question_result_message(run_result),
            False,
        )
    if mode == "resume":
        _run_resume(base, options)
        resume_packet = ContextPaths.at(base).resume_packet
        if (
            not options.non_interactive
            and _stdin(options).isatty()
            and _confirm(
                options,
                "Memory packet is ready. Ask from it now?",
                default_yes=True,
            )
        ):
            if options.task is None and options.show_progress:
                run_result = _run_interactive_memory_chat(
                    base,
                    profile,
                    readiness,
                    options,
                    allow_back=allow_back,
                    initial_question=initial_question,
                    workspace_query=workspace_query,
                )
                return (
                    run_result.to_dict() if run_result else None,
                    str(resume_packet),
                    None,
                    "Memory chat ended.",
                    True,
                )
            question = initial_question or _question(options, allow_back=allow_back)
            run_result = _run_memory_question(
                base,
                profile,
                options,
                question,
                readiness,
                workspace_query=workspace_query,
            )
            return (
                run_result.to_dict(),
                str(resume_packet),
                None,
                _question_result_message(run_result),
                False,
            )
        return (
            None,
            str(resume_packet),
            None,
            "Memory packet is ready. To ask from it, run `remaind launch` "
            "and choose Ask from memory state.",
            False,
        )
    if mode == "handover":
        return (None, None, None, _run_handover_update(base, profile, options), False)
    if mode == "file":
        file_path = options.file
        if file_path is None:
            if options.non_interactive:
                raise LaunchError("--file is required when --input file is used")
            file_path = _select_prompt_file(base, options, allow_back=allow_back)
        run_result = _run_file(base, profile, options, file_path)
        _enforce_answer_key_policy(options, run_result)
        return (run_result.to_dict(), None, None, "File prompt processed.", False)
    if mode == "paste":
        capture_path = _capture_paste(base, options)
        run_result = _run_file(base, profile, options, capture_path)
        _enforce_answer_key_policy(options, run_result)
        return (
            run_result.to_dict(),
            None,
            str(capture_path),
            "Pasted prompt captured and processed.",
            False,
        )
    raise LaunchError(f"unsupported input mode: {mode}")


def _enforce_answer_key_policy(
    options: LaunchOptions, run_result: run_cmd.RunResult
) -> None:
    if not options.require_answer_key_pass:
        return
    if not run_result.answer_key_path:
        raise LaunchError("answer key validation was required, but no key was found")
    if (
        not run_result.answer_validation
        or not run_result.answer_validation.get("passed")
    ):
        raise LaunchError("answer key validation failed")


def execute(options: LaunchOptions) -> LaunchResult:
    memory_mode_key = (options.memory_mode or "turbo").strip().lower()
    _memory_mode(options)
    can_choose_project = options.path is None and _is_interactive(options)

    while True:
        resolved_project = _resolve_project_folder(options)
        base = resolved_project.path
        workspace_query = resolved_project.query
        initialized = _ensure_context(base)

        # Product invariant: the context must validate before selecting a model
        # or accepting a large prompt.
        _require_valid_context(base)
        ensure_product_status_seed(base, workspace_query=workspace_query)
        ensure_plan_reconciliation(base, workspace_query=workspace_query)
        try:
            _maybe_select_deepseek_profile(
                options,
                allow_back=can_choose_project,
            )
        except _LaunchBack:
            if can_choose_project:
                continue
            raise LaunchError("there is no previous launcher step") from None
        profile = select_runtime(options)

        while True:
            try:
                profile, runtime_menu_shown = _maybe_select_runtime_interactively(
                    options,
                    profile,
                    allow_back=can_choose_project,
                )
            except _LaunchBack:
                if can_choose_project:
                    break
                raise LaunchError("there is no previous launcher step") from None

            fallback_accepted = (
                profile.kind != "fallback"
                or options.accept_fallback
                or options.runtime == "fallback"
            )
            if profile.kind == "fallback" and not fallback_accepted:
                fallback_accepted = _confirm(
                    options,
                    "No local model runtime was detected. Continue with packet-only fallback?",
                    default_yes=False,
                )
            readiness = run_readiness_checks(
                base,
                profile,
                fallback_accepted=fallback_accepted,
            )
            try:
                profile, readiness = _maybe_reselect_runtime_after_failure(
                    base,
                    profile,
                    readiness,
                    options,
                )
            except _LaunchBack:
                continue
            profile, readiness = _maybe_continue_packet_only(
                base,
                profile,
                readiness,
                options,
            )
            if not readiness.ready:
                raise LaunchError(
                    "readiness failed; fix the listed checks before pasting or "
                    "loading large prompts: "
                    + "; ".join(readiness.failures)
                )

            can_back_from_mode = (
                _is_interactive(options)
                and options.input_mode is None
                and (runtime_menu_shown or can_choose_project)
            )
            restart_project = False
            while True:
                try:
                    intent = _select_launch_intent(
                        options,
                        allow_back=can_back_from_mode,
                    )
                except _LaunchBack:
                    if runtime_menu_shown:
                        break
                    restart_project = can_choose_project
                    break
                try:
                    (
                        run_result,
                        resume_packet_path,
                        captured_path,
                        message,
                        rendered_inline,
                    ) = _dispatch(
                        base,
                        profile,
                        readiness,
                        intent.mode,
                        replace(options, file=intent.file_path or options.file),
                        allow_back=can_back_from_mode,
                        initial_question=intent.question,
                        workspace_query=workspace_query,
                    )
                except _LaunchBack:
                    continue
                return LaunchResult(
                    project=str(base),
                    context_store=str(ContextPaths.at(base).root),
                    initialized_context=initialized,
                    runtime=profile,
                    memory_mode=memory_mode_key,
                    readiness=readiness,
                    input_mode=intent.mode,
                    run_result=run_result,
                    resume_packet_path=resume_packet_path,
                    captured_input_path=captured_path,
                    message=message,
                    rendered_inline=rendered_inline,
                )
            if restart_project:
                break
            continue


def inspect_context(options: LaunchOptions, question: str) -> ContextInspectResult:
    """Build the engineered memory-question context without calling a model."""

    if not question.strip():
        raise LaunchError("context inspect requires a plain-language question")
    memory_mode_key = (options.memory_mode or "turbo").strip().lower()
    _memory_mode(options)
    resolved_project = _resolve_project_folder(options)
    base = resolved_project.path
    workspace_query = resolved_project.query
    initialized = _ensure_context(base)
    _require_valid_context(base)
    ensure_product_status_seed(base, workspace_query=workspace_query)
    ensure_plan_reconciliation(base, workspace_query=workspace_query)
    profile = _fallback_profile(
        "Context inspect builds the memory packet only; it does not call a model."
    )
    readiness = run_readiness_checks(base, profile, fallback_accepted=True)
    if not readiness.ready:
        raise LaunchError(
            "context inspect readiness failed: " + "; ".join(readiness.failures)
        )
    _run_resume(base, options)
    source_path = _build_memory_question_source(
        base,
        question=question,
        workspace_query=workspace_query,
        profile=profile,
        readiness=readiness,
        conversation_history=[],
    )
    content = source_path.read_text(encoding="utf-8")
    return ContextInspectResult(
        project=str(base),
        context_store=str(ContextPaths.at(base).root),
        initialized_context=initialized,
        memory_mode=memory_mode_key,
        context_source_path=str(source_path),
        content=content,
    )


def render_human(result: LaunchResult) -> str:
    if result.rendered_inline:
        return ""
    if result.input_mode == "handover" and result.message:
        return result.message.rstrip() + "\n"
    if result.input_mode in {"ask", "resume"} and result.run_result:
        answer = result.run_result.get("answer")
        if answer:
            return _render_memory_answer(result.run_result)
        if result.run_result.get("model_error"):
            return _render_memory_answer(result.run_result)
        if result.input_mode == "ask":
            return _render_memory_answer(result.run_result)

    rows: list[str] = [
        "Memory state: ACTIVE",
        f"Workspace: {result.project}",
        f"Memory store: {result.context_store}",
        "Execution: local-first",
        "Cloud memory: off",
        "",
        "Readiness check",
    ]
    for check in result.readiness.checks:
        status = "ok" if check.passed else "FAIL"
        detail = f": {check.detail}" if check.detail else ""
        rows.append(f"{check.name}: {status}{detail}")
    rows.append(f"Runtime: {result.runtime.kind}")
    if result.runtime.model:
        rows.append(f"Model: {result.runtime.model}")
    if result.runtime.endpoint:
        rows.append(f"Endpoint: {result.runtime.endpoint}")
    if result.runtime.context_window_tokens:
        context = f"{result.runtime.context_window_tokens} tokens"
        if result.runtime.context_window_estimated:
            context += " estimated"
        rows.append(f"Context window: {context}")
    rows.append(f"Remaind mode: {result.memory_mode}")
    rows.append("Status: ready")
    if result.readiness.warnings:
        rows.append("Warnings:")
        for warning in result.readiness.warnings:
            rows.append(f"  - {warning}")
    rows.append("")
    rows.append(f"Start mode: {result.input_mode}")
    if result.captured_input_path:
        rows.append(f"Captured input: {result.captured_input_path}")
    if result.resume_packet_path:
        rows.append(f"Memory packet: {result.resume_packet_path}")
    if result.run_result:
        rows.append(f"Question packet: {result.run_result['packet_path']}")
        rows.append(f"Answer file: {result.run_result['answer_path']}")
        model_error = result.run_result.get("model_error")
        if model_error:
            rows.append(f"Model error: {model_error}")
        answer = result.run_result.get("answer")
        if answer:
            rows.append("")
            rows.append("Answer:")
            rows.append(str(answer).strip())
    if result.message:
        rows.append(result.message)
    return "\n".join(rows).rstrip() + "\n"


def render_json(result: LaunchResult) -> str:
    return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
