"""`remaind memory` — agent-facing continuity update tools."""

from __future__ import annotations

import json
from pathlib import Path

from .._continuity import (
    ContinuityError,
    MemoryToolResult,
    mark_task_blocked,
    promote_to_memory,
    record_decision,
    render_changes_since_last_session,
    render_current_plan,
)

__all__ = [
    "ContinuityError",
    "MemoryToolResult",
    "render_tool_result",
    "run_block",
    "run_changed",
    "run_decision",
    "run_plan",
    "run_promote",
]


def run_plan(base: Path) -> str:
    return render_current_plan(base)


def run_block(
    base: Path,
    *,
    task: str,
    reason: str,
    workspace_query: str | None = None,
) -> MemoryToolResult:
    return mark_task_blocked(
        base,
        task=task,
        reason=reason,
        workspace_query=workspace_query,
    )


def run_decision(base: Path, *, text: str) -> MemoryToolResult:
    return record_decision(base, text=text)


def run_promote(
    base: Path,
    *,
    text: str,
    rationale: str | None = None,
    tags: list[str] | None = None,
) -> MemoryToolResult:
    return promote_to_memory(base, text=text, rationale=rationale, tags=tags)


def run_changed(base: Path, *, limit: int = 12) -> str:
    return render_changes_since_last_session(base, limit=limit)


def render_tool_result(result: MemoryToolResult, *, as_json: bool = False) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    rows = [result.message]
    if result.event_id:
        rows.append(f"Event: {result.event_id}")
    if result.memory_id:
        rows.append(f"Memory: {result.memory_id}")
    if result.progress_operation_id:
        rows.append(f"Progress: {result.progress_operation_id}")
    rows.append("")
    return "\n".join(rows)
