"""`remaind monitor` — scheduler-friendly health and alert surface.

The command is intentionally read-only. It combines the structural validator,
status payload, doctor readiness check, and deep-compaction run inspection into
one machine-friendly result that can be used from cron, launchd, systemd, CI,
or external uptime checks. Alerting is represented by a non-zero process exit
plus structured JSON/human output; Remaind stays local-first and does not send
alerts to a hosted service.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .._paths import ContextPaths
from . import doctor as doctor_cmd
from . import large_doc as large_doc_cmd
from . import status as status_cmd
from . import validate as validate_cmd


@dataclass(frozen=True)
class MonitorCheck:
    name: str
    ok: bool
    detail: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MonitorResult:
    path: str
    ok: bool
    checks: list[MonitorCheck]
    recommendations: list[str]
    schema_version: str = "monitor_v1"

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "path": self.path,
            "ok": self.ok,
            "checks": [check.to_dict() for check in self.checks],
            "recommendations": self.recommendations,
        }


def _discover_large_doc_targets(base: Path) -> list[str]:
    root = ContextPaths.at(base).large_docs_dir
    if not root.is_dir():
        return []
    return sorted(
        path.parent.name
        for path in root.glob("*/manifest.json")
        if path.is_file()
    )


def _deep_compaction_checks(base: Path, targets: list[str]) -> tuple[list[MonitorCheck], list[str]]:
    checks: list[MonitorCheck] = []
    recommendations: list[str] = []
    if not targets:
        return ([MonitorCheck("large_docs", True, "no large documents registered")], [])

    for target in targets:
        try:
            inspected = large_doc_cmd.run_inspect(base, target)
        except large_doc_cmd.LargeDocumentError as exc:
            checks.append(MonitorCheck(f"large_doc:{target}", False, str(exc)))
            recommendations.append(
                f"Re-ingest or remove the stale large-doc target {target!r}."
            )
            continue

        doc_id = str(inspected.get("doc_id") or target)
        runs = inspected.get("deep_compactions")
        if not isinstance(runs, list) or not runs:
            checks.append(
                MonitorCheck(
                    f"large_doc:{doc_id}",
                    True,
                    "manifest readable; no deep-compaction runs",
                )
            )
            continue

        unhealthy: list[str] = []
        for run in runs:
            status = str(run.get("status") or "unknown")
            failed = int(run.get("chunks_failed") or 0)
            quarantined = int(run.get("chunks_quarantined") or 0)
            if status != "completed" or failed or quarantined:
                unhealthy.append(
                    f"{run.get('run_id')}: status={status}, "
                    f"failed={failed}, quarantined={quarantined}"
                )
        if unhealthy:
            checks.append(
                MonitorCheck(
                    f"large_doc:{doc_id}:deep_compactions",
                    False,
                    "; ".join(unhealthy[:5]),
                )
            )
            recommendations.append(
                f"Inspect {doc_id} with `remaind large-doc inspect {doc_id}`; "
                "resume interrupted runs or prune failed caches after review."
            )
        else:
            checks.append(
                MonitorCheck(
                    f"large_doc:{doc_id}:deep_compactions",
                    True,
                    f"{len(runs)} completed run(s), no failures or quarantines",
                )
            )
    return checks, recommendations


def _doctor_monitor_detail(runtime: dict[str, Any]) -> str:
    detail = [
        f"runtime={runtime.get('status', 'unknown')}",
        f"mode={runtime.get('compaction_mode', 'unknown')}",
    ]
    if runtime.get("label"):
        detail.append(f"label={runtime['label']}")
    if runtime.get("model"):
        detail.append(f"model={runtime['model']}")
    generation = runtime.get("generation_check")
    if isinstance(generation, dict):
        detail.append("generation=ok" if generation.get("ok") else "generation=failed")
        if generation.get("api"):
            detail.append(f"api={generation['api']}")
        if generation.get("error"):
            detail.append(f"error={generation['error']}")
    if runtime.get("error"):
        detail.append(f"error={runtime['error']}")
    return ", ".join(detail)


def check(
    base: Path,
    *,
    smoke: bool = False,
    large_doc_targets: list[str] | None = None,
) -> MonitorResult:
    base = Path(base).expanduser().resolve()
    checks: list[MonitorCheck] = []
    recommendations: list[str] = []

    validation = validate_cmd.run(base)
    checks.append(
        MonitorCheck(
            "validate",
            validation.ok,
            "ok"
            if validation.ok
            else "; ".join(f"{label}: {reason}" for label, reason in validation.failed),
        )
    )
    if not validation.ok:
        recommendations.append("Run `remaind validate` and repair failed checks.")

    try:
        payload = status_cmd.build_status_payload(base)
    except status_cmd.StatusError as exc:
        checks.append(MonitorCheck("status", False, str(exc)))
        recommendations.append("Restore or regenerate active/state.json.")
    else:
        malformed = int(payload.get("events", {}).get("malformed_lines") or 0)
        compaction = payload.get("compaction", {})
        urgent = bool(compaction.get("urgent"))
        checks.append(
            MonitorCheck(
                "status",
                malformed == 0 and not urgent,
                (
                    f"events={payload.get('events', {}).get('count', 0)}, "
                    f"malformed={malformed}, "
                    f"compaction={'urgent' if urgent else 'ok'}"
                ),
            )
        )
        if malformed:
            recommendations.append("Repair malformed logs/events.jsonl lines.")
        if urgent:
            recommendations.append("Run `remaind compact` before continuing work.")

    doctor = doctor_cmd.check(base, smoke=smoke)
    doctor_ok = doctor.ok
    if smoke:
        generation = doctor.runtime.get("generation_check")
        doctor_ok = doctor_ok and isinstance(generation, dict) and bool(
            generation.get("ok")
        )
        if not doctor_ok and "Monitor smoke mode requires a usable local model." not in recommendations:
            recommendations.append(
                "Monitor smoke mode requires a usable local model. Start the "
                "runtime or run without --smoke for packet-only deployments."
            )
    checks.append(
        MonitorCheck(
            "doctor",
            doctor_ok,
            _doctor_monitor_detail(doctor.runtime)
            + (
                ""
                if doctor_ok or not doctor.recommendations
                else "; " + "; ".join(doctor.recommendations)
            ),
        )
    )
    recommendations.extend(doctor.recommendations)

    targets = (
        [str(target) for target in large_doc_targets]
        if large_doc_targets
        else _discover_large_doc_targets(base)
    )
    large_doc_checks, large_doc_recommendations = _deep_compaction_checks(base, targets)
    checks.extend(large_doc_checks)
    recommendations.extend(large_doc_recommendations)

    ok = all(check.ok for check in checks)
    return MonitorResult(
        path=str(base),
        ok=ok,
        checks=checks,
        recommendations=list(dict.fromkeys(recommendations)),
    )


def render_human(result: MonitorResult) -> str:
    rows = [
        f"Monitor: {'OK' if result.ok else 'ALERT'}",
        f"Path:    {result.path}",
        "",
        "Checks:",
    ]
    for check_item in result.checks:
        rows.append(
            f"  {'OK' if check_item.ok else 'ALERT'} "
            f"{check_item.name}: {check_item.detail}"
        )
    rows.append("")
    if result.recommendations:
        rows.append("Recommendations:")
        for recommendation in result.recommendations:
            rows.append(f"  - {recommendation}")
    else:
        rows.append("Recommendations: (none)")
    return "\n".join(rows) + "\n"


def run(
    base: Path,
    *,
    as_json: bool = False,
    smoke: bool = False,
    large_doc_targets: list[str] | None = None,
) -> str:
    result = check(base, smoke=smoke, large_doc_targets=large_doc_targets)
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    return render_human(result)
