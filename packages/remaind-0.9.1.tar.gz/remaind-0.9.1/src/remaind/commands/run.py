"""`remaind run` — execute a task against a large local prompt/document."""

from __future__ import annotations

import json
import os
import re
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Protocol

from .._atomic import atomic_write_text
from .._context_engine import ContextBuildRequest, select_engineered_context
from .._context_render import render_context_decision_section
from .._context_sources import ContextSource
from .._document_compaction import (
    DeepCompactionResult,
    DocumentCompactionError,
    execute_deep_compaction,
)
from .._errors import RemaindError
from .._events import EventInput, EventWriter
from .._large_doc import (
    LargeDocumentError,
    LargeDocumentIngestResult,
    LargeDocumentLinesResult,
    LargeDocumentSearchResult,
    head_large_document,
    ingest_large_document,
    search_large_document,
    tail_large_document,
)
from .._local_compactor import CompactorResponseError
from .._packet_policy import context_window_from_env, resolve_packet_token_cap
from .._paths import ContextPaths
from .._product_status import clean_product_status_text
from .._progress import new_progress_operation_id, record_progress_snapshot
from .._recall_judgment import render_recall_judgment_section
from .._recommendation_engine import (
    build_recommendation_decision,
    render_recommendation_decision,
)
from .._recommendation_judgment import render_recommendation_judgment_section
from .._state_writer import update_state
from .._suggestion_judgment import render_suggestion_judgment_section
from .._text_model import (
    ModelInfo,
    TextModelClient,
    TextModelError,
    _openai_api_mode_from_env,
    _openai_transport,
    extract_json_payload,
)
from .._tokens import estimate_tokens
from . import init as init_cmd

__all__ = [
    "RunError",
    "RunResult",
    "TextModel",
    "execute",
    "render_human",
    "render_json",
]

DEFAULT_CONTEXT_LINES = 2
DEFAULT_HEAD_LINES = 80
DEFAULT_TAIL_LINES = 120
DEFAULT_MAX_RESULTS = 8
DEFAULT_QUERY_COUNT = 6
DEFAULT_TOKEN_CAP = 24_000
DEFAULT_MARKER_SECTION_LIMIT = 80
DEFAULT_MARKER_SECTION_LINES = 10
FINAL_GATE_MARKER_LINES = 28
REMAIND_LAUNCH_MARKER_LINES = 220
REMAIND_LAUNCH_PACKET_MARKER_LINES = 520
DEFAULT_MODEL_PROMPT_CONTEXT_FRACTION = 0.80
MAX_MODEL_PROMPT_FRACTION_ENV = "REMAIND_MAX_MODEL_PROMPT_FRACTION"

_TOKEN_RE = re.compile(r"[A-Za-z0-9_:/.-]{3,}")
_THINK_RE = re.compile(r"(?is)<think\b[^>]*>.*?</think>\s*")
_MARKER_HEADING_RE = re.compile(
    r"^#{1,6}\s+("
    r"TRUE-SIGNAL[-\w]*|"
    r"FALSE-COSMIC-SIGNAL-DECOY[-\w]*|"
    r"FALSE[-\w]*SIGNAL[-\w]*|"
    r"COUNTERFEIT-SIGNAL[-\w]*|"
    r"REVOCATION[-\w]*|"
    r"LABYRINTH-CHECKPOINT|"
    r"FINAL\s+LABYRINTH\s+GATE|"
    r"REMAIND-LAUNCH-CONTEXT(?:\s+.*)?"
    r")\b",
    re.IGNORECASE,
)
_STOPWORDS = {
    "about",
    "above",
    "after",
    "again",
    "against",
    "also",
    "and",
    "answer",
    "because",
    "before",
    "being",
    "below",
    "could",
    "document",
    "file",
    "find",
    "for",
    "from",
    "have",
    "into",
    "make",
    "need",
    "only",
    "please",
    "prompt",
    "report",
    "solve",
    "summarize",
    "task",
    "that",
    "the",
    "their",
    "there",
    "these",
    "this",
    "through",
    "using",
    "what",
    "when",
    "where",
    "which",
    "with",
    "would",
}


class RunError(RemaindError):
    """Raised when a `remaind run` operation cannot complete safely."""


class TextModel(Protocol):
    """Minimal text-generation boundary used by `remaind run`."""

    label: str

    def generate(self, system_text: str, user_text: str) -> str:
        ...


class _LocalTextModel:
    def __init__(self, *, label: str, handler: Callable[[str, str], str]) -> None:
        self.label = label
        self._handler = handler

    def generate(self, system_text: str, user_text: str) -> str:
        return self._handler(system_text, user_text)


class _DocumentTextModelAdapter:
    def __init__(self, model: TextModel) -> None:
        self._model = model
        self.label = model.label

    def complete(
        self,
        prompt: str,
        *,
        system: str | None = None,
        json_mode: bool = False,
        max_tokens: int | None = None,
    ) -> str:
        _ = (json_mode, max_tokens)
        return self._model.generate(system or "You are a local Remaind model.", prompt)

    def describe(self) -> ModelInfo:
        return ModelInfo(kind="run-detected", model=self.label, endpoint="run")


@dataclass(frozen=True)
class RunResult:
    """Result of executing a task through Remaind large-document retrieval."""

    base: str
    document_path: str
    task: str
    ingest: dict[str, Any]
    queries: list[str]
    searches: list[dict[str, Any]]
    head: dict[str, Any]
    tail: dict[str, Any]
    packet_path: str
    answer_path: str
    packet_tokens: int
    token_cap: int
    model_prompt_tokens: int | None
    model_prompt_safe_limit: int | None
    model_label: str | None
    answer: str | None
    model_error: str | None
    answer_key_path: str | None
    answer_validation: dict[str, Any] | None
    deep_compaction: dict[str, Any] | None
    event_ids: list[str]
    initialized_context: bool
    omitted_sections: list[str]

    @property
    def answered(self) -> bool:
        return bool(self.answer)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@contextmanager
def _patched_env(updates: dict[str, str | None]) -> Iterator[None]:
    old: dict[str, str | None] = {}
    for key, value in updates.items():
        old[key] = os.environ.get(key)
        if value is None or value == "":
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    try:
        yield
    finally:
        for key, value in old.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def _resolve_token_cap(*, token_cap: int | None, num_ctx: int | None) -> int:
    """Resolve the run packet budget from explicit config or model context.

    The compact evidence packet should be large enough to use the selected
    local model's native window, but not so large that it crowds out the task
    instructions and answer space. Operators can still force an exact value.
    """

    return resolve_packet_token_cap(
        explicit_token_cap=token_cap,
        context_window_tokens=num_ctx,
    )


def _model_context_window(num_ctx: int | None) -> int | None:
    if num_ctx is not None and num_ctx > 0:
        return num_ctx
    return context_window_from_env()


def _max_model_prompt_fraction() -> float:
    raw = os.environ.get(MAX_MODEL_PROMPT_FRACTION_ENV, "").strip()
    if not raw:
        return DEFAULT_MODEL_PROMPT_CONTEXT_FRACTION
    try:
        value = float(raw)
    except ValueError as exc:
        raise RunError(f"{MAX_MODEL_PROMPT_FRACTION_ENV} must be a number") from exc
    if not 0.1 <= value <= 0.95:
        raise RunError(f"{MAX_MODEL_PROMPT_FRACTION_ENV} must be between 0.1 and 0.95")
    return value


def _model_prompt_preflight(
    system_text: str,
    user_text: str,
    *,
    num_ctx: int | None,
) -> tuple[int, int | None, str | None]:
    """Return prompt estimate, safe limit, and a skip reason when too large."""

    prompt_tokens = estimate_tokens(system_text) + estimate_tokens(user_text)
    context_window = _model_context_window(num_ctx)
    if context_window is None:
        return prompt_tokens, None, None

    fraction = _max_model_prompt_fraction()
    safe_limit = max(1, int(context_window * fraction))
    if prompt_tokens <= safe_limit:
        return prompt_tokens, safe_limit, None
    return (
        prompt_tokens,
        safe_limit,
        (
            "local model request skipped to prevent timeout: estimated prompt "
            f"{prompt_tokens} tokens exceeds safe limit {safe_limit} "
            f"({fraction:.0%} of configured context {context_window}). "
            "Rerun with a smaller --token-cap, a larger model context, or adjust "
            f"{MAX_MODEL_PROMPT_FRACTION_ENV}."
        ),
    )


def _clean_model_text(content: str) -> str:
    cleaned = _THINK_RE.sub("", content).strip()
    return cleaned or content.strip()


def _normalize_for_validation(value: object) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text


def _answer_key_candidates(document_path: Path) -> list[Path]:
    path = Path(document_path).expanduser().resolve()
    stem = path.stem
    return [
        path.with_name(f"{stem}_private_answer_key.json"),
        path.with_name(f"{stem}_answer_key.json"),
        path.with_name(f"{stem}.answer_key.json"),
        path.with_name("private_answer_key.json"),
        path.with_name("answer_key.json"),
    ]


def _resolve_answer_key_path(
    document_path: Path, answer_key_path: Path | None
) -> Path | None:
    if answer_key_path is not None:
        path = Path(answer_key_path).expanduser().resolve()
        if not path.is_file():
            raise RunError(f"answer key does not exist: {path}")
        return path
    for candidate in _answer_key_candidates(document_path):
        if candidate.is_file():
            return candidate
    return None


def _validate_answer_against_key(
    *,
    answer: str | None,
    document_path: Path,
    answer_key_path: Path | None,
) -> tuple[str | None, dict[str, Any] | None]:
    key_path = _resolve_answer_key_path(document_path, answer_key_path)
    if key_path is None:
        return None, None
    if not answer:
        return str(key_path), {
            "passed": False,
            "reason": "answer key found, but no model answer was generated",
            "checks": [],
        }

    try:
        key = json.loads(key_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RunError(f"could not read answer key {key_path}: {exc}") from exc

    normalized_answer = _normalize_for_validation(answer)
    checks: list[dict[str, Any]] = []
    required_exact = key.get("required_final_output_exact")
    if isinstance(required_exact, str) and required_exact.strip():
        expected = required_exact.strip()
        actual = answer.strip()
        checks.append(
            {
                "name": "required_final_output_exact",
                "passed": actual == expected,
                "required": True,
            }
        )
    else:
        for field_name in (
            "exact_final_synthesis_phrase",
            "true_category",
            "true_failure_mode",
            "true_operating_principle",
            "authority_hierarchy",
            "checksum_seed",
        ):
            expected = key.get(field_name)
            if not isinstance(expected, str) or not expected.strip():
                continue
            checks.append(
                {
                    "name": field_name,
                    "passed": _normalize_for_validation(expected) in normalized_answer,
                    "required": True,
                }
            )

    fragment_coverage: dict[str, Any] = {}
    for field_name in ("true_fragments", "decoy_fragments", "revocation_fragments"):
        raw_items = key.get(field_name)
        if not isinstance(raw_items, list):
            continue
        missing: list[str] = []
        found = 0
        for item in raw_items:
            if not isinstance(item, dict):
                continue
            label = str(item.get("label") or "").strip()
            text = str(item.get("text") or "").strip()
            label_hit = bool(label) and _normalize_for_validation(label) in normalized_answer
            text_hit = bool(text) and _normalize_for_validation(text) in normalized_answer
            if label_hit or text_hit:
                found += 1
            elif label:
                missing.append(label)
        fragment_coverage[field_name] = {
            "found": found,
            "total": len(raw_items),
            "missing_labels": missing[:25],
        }

    required_checks = [check for check in checks if check.get("required")]
    passed = bool(required_checks) and all(check["passed"] for check in required_checks)
    return str(key_path), {
        "passed": passed,
        "checks": checks,
        "fragment_coverage": fragment_coverage,
    }


def _detect_text_model() -> TextModel | None:
    """Return a local text model using the same runtime env as compaction."""

    client = TextModelClient.from_env()
    if client is None:
        return None

    def generate(system_text: str, user_text: str) -> str:
        try:
            return _clean_model_text(client.complete(user_text, system=system_text))
        except TextModelError as exc:
            raise CompactorResponseError(str(exc)) from exc

    return _LocalTextModel(label=client.label, handler=generate)


def _openai_text_model(base_url: str, model_name: str) -> TextModel:
    """Return the explicitly selected OpenAI-compatible model only."""

    client = TextModelClient(
        ModelInfo(
            kind="openai-compatible",
            model=model_name,
            endpoint=base_url.rstrip("/"),
            api_mode=_openai_api_mode_from_env(),
        ),
        transport=_openai_transport(),
    )

    def generate(system_text: str, user_text: str) -> str:
        try:
            return _clean_model_text(client.complete(user_text, system=system_text))
        except TextModelError as exc:
            raise CompactorResponseError(str(exc)) from exc

    return _LocalTextModel(label=client.label, handler=generate)


def _ensure_context(base: Path, *, auto_init: bool) -> bool:
    paths = ContextPaths.at(base)
    if paths.state_json.is_file():
        return False
    if not auto_init:
        raise RunError(f"state.json not found at {paths.state_json}; run `remaind init`")
    init_cmd.run(base)
    return True


def _read_session_ids(base: Path) -> tuple[str, str]:
    path = ContextPaths.at(base).state_json
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RunError(f"could not read Remaind state at {path}: {exc}") from exc
    session_id = str(state.get("session_id") or "")
    task_id = str(state.get("task_id") or "")
    if not session_id or not task_id:
        raise RunError("Remaind state is missing session_id or task_id")
    return session_id, task_id


def _ingest_if_needed(
    base: Path, document_path: Path, *, title: str | None
) -> LargeDocumentIngestResult:
    # Re-ingest intentionally: `remaind run` is a durable user action, so it
    # should refresh the source manifest/memory and leave an event trail even
    # when this exact file was indexed before.
    return ingest_large_document(base, document_path, title=title)


def _unique(values: list[str], *, limit: int) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        normalized = " ".join(value.strip().split())
        if len(normalized) < 3:
            continue
        if len(normalized) > 180:
            normalized = normalized[:180].rsplit(" ", 1)[0] or normalized[:180]
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(normalized)
        if len(out) >= limit:
            break
    return out


def _fallback_queries(task: str, *, limit: int) -> list[str]:
    quoted = [
        item.strip()
        for match in re.findall(r'"([^"]+)"|\'([^\']+)\'', task)
        for item in match
        if item.strip()
    ]
    tokens = [
        token
        for token in _TOKEN_RE.findall(task)
        if token.lower() not in _STOPWORDS and not token.isdigit()
    ]
    candidates: list[str] = []
    candidates.extend(quoted)
    if len(task) <= 180:
        candidates.append(task)
    for width in (5, 4, 3, 2, 1):
        for idx in range(0, len(tokens), width):
            chunk = " ".join(tokens[idx : idx + width])
            if chunk:
                candidates.append(chunk)
    lower_task = task.lower()
    if any(word in lower_task for word in ("puzzle", "labyrinth", "benchmark")):
        candidates.extend(
            [
                "TRUE-SIGNAL-FINAL",
                "Final Labyrinth Gate",
                "Correct authority hierarchy",
                "Correct checksum seed",
                "true product category",
                "true failure mode",
                "true operating principle",
                "FALSE-COSMIC-SIGNAL-DECOY",
                "COUNTERFEIT-SIGNAL-DECOY",
                "REVOCATION-REVOKE",
            ]
        )
    return _unique(candidates, limit=limit)


def _format_lines(result: LargeDocumentLinesResult, *, max_rows: int) -> str:
    rows = result.lines[:max_rows]
    if not rows:
        return "(no lines)"
    return "\n".join(f"{row['line']}: {row['text']}" for row in rows)


def _is_marker_heading(line: str) -> bool:
    return bool(_MARKER_HEADING_RE.match(line.strip()))


def _marker_line_limit(heading: str) -> int:
    upper = heading.upper()
    if "REMAIND-LAUNCH-CONTEXT" in upper and "PACKET HISTORY" in upper:
        return REMAIND_LAUNCH_PACKET_MARKER_LINES
    if "REMAIND-LAUNCH-CONTEXT" in upper:
        return REMAIND_LAUNCH_MARKER_LINES
    if "FINAL LABYRINTH GATE" in upper:
        return FINAL_GATE_MARKER_LINES
    return DEFAULT_MARKER_SECTION_LINES


def _extract_marker_sections(
    document_path: Path,
    *,
    limit: int = DEFAULT_MARKER_SECTION_LIMIT,
) -> list[LargeDocumentLinesResult]:
    """Return compact labeled evidence blocks from structured benchmark docs."""

    path = Path(document_path).expanduser().resolve()
    sections: list[LargeDocumentLinesResult] = []
    current: list[dict[str, Any]] | None = None
    current_limit = DEFAULT_MARKER_SECTION_LINES

    def flush_current() -> None:
        nonlocal current
        if current is None:
            return
        sections.append(
            LargeDocumentLinesResult(
                path=str(path),
                mode="marker",
                start=current[0]["line"],
                end=current[-1]["line"],
                lines=current,
            )
        )
        current = None

    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for lineno, raw_line in enumerate(handle, start=1):
                line = raw_line.rstrip("\r\n")
                if _is_marker_heading(line):
                    flush_current()
                    if len(sections) >= limit:
                        break
                    current = [{"line": lineno, "text": line}]
                    current_limit = _marker_line_limit(line)
                    continue

                if current is None:
                    continue
                if line.startswith("#") or line.startswith("Record "):
                    flush_current()
                    if len(sections) >= limit:
                        break
                    continue
                if len(current) >= current_limit:
                    flush_current()
                    if len(sections) >= limit:
                        break
                    continue
                current.append({"line": lineno, "text": line})
    except OSError as exc:
        raise RunError(f"could not read document markers from {path}: {exc}") from exc

    if len(sections) < limit:
        flush_current()
    return sections


def _format_marker_sections(sections: list[LargeDocumentLinesResult]) -> str:
    if not sections:
        return "(no marker sections found)"
    rendered: list[str] = []
    for section in sections:
        rendered.append(f"### Marker Lines {section.start}-{section.end}")
        rendered.append(_format_lines(section, max_rows=len(section.lines)))
    return "\n\n".join(rendered)


def _query_generation_prompt(
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    head: LargeDocumentLinesResult,
    tail: LargeDocumentLinesResult,
    query_count: int,
) -> tuple[str, str]:
    system = (
        "You are Remaind's local retrieval planner. Return only JSON. "
        "Generate search queries that will find exact evidence in the local "
        "source document. Do not answer the task."
    )
    metadata = (
        "Document metadata:\n"
        f"title: {ingest.stats.title}\n"
        f"path: {ingest.stats.path}\n"
        f"lines: {ingest.stats.lines}\n"
        f"bytes: {ingest.stats.bytes}\n"
    )
    head_text = "Document head:\n" + _format_lines(head, max_rows=30) + "\n"
    tail_text = "Document tail:\n" + _format_lines(tail, max_rows=40) + "\n"
    sources = [
        ContextSource(
            id="retrieval_planner_task",
            title="Retrieval Planner Task",
            source_type="current_question",
            authority="current_user",
            freshness="live",
            content=f"Task:\n{task}\n",
            mandatory=True,
            reason="The user task defines which exact evidence the planner must find.",
            budget_group="task",
        ),
        ContextSource(
            id="retrieval_source_metadata",
            title="Retrieval Source Metadata",
            source_type="source_metadata",
            authority="source_evidence",
            freshness="current",
            content=metadata,
            mandatory=True,
            reason="The manifest scopes retrieval to the indexed local source.",
            budget_group="metadata",
        ),
        ContextSource(
            id="retrieval_document_head",
            title="Retrieval Document Head",
            source_type="document_head",
            authority="source_evidence",
            freshness="static",
            content=head_text,
            mandatory=True,
            reason="The head gives the planner source vocabulary and structure.",
            budget_group="orientation",
        ),
        ContextSource(
            id="retrieval_document_tail",
            title="Retrieval Document Tail",
            source_type="document_tail",
            authority="source_evidence",
            freshness="static",
            content=tail_text,
            mandatory=True,
            reason="The tail gives the planner closing signals and final-answer vocabulary.",
            budget_group="orientation",
        ),
    ]
    intent, selection = select_engineered_context(
        ContextBuildRequest(
            question=task,
            token_cap=sum(source.token_count for source in sources),
        ),
        sources,
    )
    user = (
        render_context_decision_section(
            question=task,
            workspace_query=None,
            intent=intent,
            selection=selection,
        )
        + "\n"
        + "\n\n".join(source.content.rstrip() for source in selection.selected)
        + "\n\n"
        "Return JSON in this exact shape:\n"
        f'{{"queries":["query one","query two"],"max_queries":{query_count}}}'
    )
    return system, user


def _model_queries(
    model: TextModel | None,
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    head: LargeDocumentLinesResult,
    tail: LargeDocumentLinesResult,
    query_count: int,
) -> list[str]:
    fallback = _fallback_queries(task, limit=query_count)
    if model is None:
        return fallback
    try:
        system, user = _query_generation_prompt(
            task=task,
            ingest=ingest,
            head=head,
            tail=tail,
            query_count=query_count,
        )
        payload = extract_json_payload(model.generate(system, user))
    except (CompactorResponseError, ValueError):
        return fallback
    raw = payload.get("queries")
    if not isinstance(raw, list):
        return fallback
    generated = [str(item) for item in raw if isinstance(item, str)]
    return _unique([*generated, *fallback], limit=query_count)


def _search_all(
    base: Path,
    document_path: Path,
    queries: list[str],
    *,
    context: int,
    max_results: int,
) -> list[LargeDocumentSearchResult]:
    results: list[LargeDocumentSearchResult] = []
    for query in queries:
        try:
            result = search_large_document(
                document_path,
                query,
                context=context,
                max_results=max_results,
                base=base,
                verify=True,
            )
        except LargeDocumentError:
            continue
        if result.hit_count:
            results.append(result)
    return results


def _search_section(result: LargeDocumentSearchResult) -> str:
    rows = [
        f"### Query: {result.query}",
        f"path: {result.path}",
        f"match_mode: {result.match_mode}",
        f"hits: {result.hit_count}",
    ]
    if result.integrity:
        rows.append(f"source_verified: {result.integrity.get('verified')}")
    for hit in result.hits:
        rows.append("")
        rows.append(f"line {hit.line}: {hit.text}")
        if hit.context:
            rows.append("context:")
            for row in hit.context:
                marker = ">" if row["line"] == hit.line else " "
                rows.append(f"{marker} {row['line']}: {row['text']}")
    return "\n".join(rows)


def _append_budgeted(
    parts: list[str],
    section: str,
    *,
    token_cap: int,
    omitted: list[str],
) -> None:
    candidate = "\n\n".join([*parts, section]) if parts else section
    if estimate_tokens(candidate) <= token_cap:
        parts.append(section)
    else:
        heading = section.splitlines()[0].lstrip("# ").strip() if section else "section"
        omitted.append(heading)


def _build_packet(
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    markers: list[LargeDocumentLinesResult],
    head: LargeDocumentLinesResult,
    tail: LargeDocumentLinesResult,
    searches: list[LargeDocumentSearchResult],
    token_cap: int,
    deep_evidence_block: str | None = None,
) -> tuple[str, int, list[str]]:
    metadata = {
        "title": ingest.stats.title,
        "path": ingest.stats.path,
        "doc_id": ingest.stats.doc_id,
        "sha256": ingest.stats.sha256,
        "bytes": ingest.stats.bytes,
        "lines": ingest.stats.lines,
        "manifest_path": ingest.manifest_path,
        "source_event_id": ingest.source_event_id,
        "memory_id": ingest.memory_id,
    }
    header = (
        "# Remaind Run Packet\n\n"
        "This packet is selected local evidence for one task. The source "
        "document remains on disk and was not copied into model context.\n\n"
        "## Task\n\n"
        f"{task.strip()}\n\n"
        "## Source\n\n"
        f"```json\n{json.dumps(metadata, indent=2, sort_keys=True)}\n```"
    )
    sources: list[ContextSource] = [
        ContextSource(
            id="run_task_source",
            title="Run Task and Source",
            source_type="source_metadata",
            authority="current_user",
            freshness="live",
            content=header,
            mandatory=True,
            reason="The user task and verified source manifest define this run.",
            budget_group="metadata",
        )
    ]
    if deep_evidence_block:
        sources.append(
            ContextSource(
                id="deep_evidence",
                title="Deep Compaction Evidence",
                source_type="deep_evidence",
                authority="source_evidence",
                freshness="current",
                content=deep_evidence_block.strip() + "\n",
                mandatory=False,
                reason="Validated deep-compaction evidence is the highest-value summary for huge files.",
                budget_group="deep_evidence",
            )
        )
    if markers:
        sources.append(
            ContextSource(
                id="structured_marker_evidence",
                title="Structured Marker Evidence",
                source_type="structured_marker",
                authority="source_evidence",
                freshness="current",
                content=(
                    "## Structured Marker Evidence\n\n"
                    + _format_marker_sections(markers)
                    + "\n"
                ),
                mandatory=False,
                reason="Exact marker slices can carry answers, revocations, or final gates.",
                budget_group="marker",
            )
        )
    sources.append(
        ContextSource(
            id="document_head",
            title="Document Head",
            source_type="document_head",
            authority="source_evidence",
            freshness="static",
            content=(
                "## Document Head\n\n"
                + _format_lines(head, max_rows=len(head.lines))
                + "\n"
            ),
            mandatory=False,
            reason="The document head orients the task and source structure.",
            budget_group="orientation",
        )
    )
    sources.append(
        ContextSource(
            id="document_tail",
            title="Document Tail",
            source_type="document_tail",
            authority="source_evidence",
            freshness="static",
            content=(
                "## Document Tail\n\n"
                + _format_lines(tail, max_rows=len(tail.lines))
                + "\n"
            ),
            mandatory=False,
            reason="The document tail often contains final answers or closing instructions.",
            budget_group="orientation",
        )
    )
    for index, result in enumerate(searches, start=1):
        sources.append(
            ContextSource(
                id=f"search_evidence_{index}",
                title=f"Search Evidence: {result.query}",
                source_type="search_evidence",
                authority="source_evidence",
                freshness="current",
                content="## Search Evidence\n\n" + _search_section(result) + "\n",
                mandatory=False,
                reason="Exact search hits are source-linked evidence for the task.",
                budget_group="search",
            )
        )
    judgment_evidence_texts = _judgment_evidence_texts(
        markers=markers,
        head=head,
        tail=tail,
        searches=searches,
        deep_evidence_block=deep_evidence_block,
    )
    recommendation_decision = render_recommendation_decision(
        build_recommendation_decision(
            task,
            judgment_evidence_texts,
        )
    )
    if recommendation_decision:
        sources.append(
            ContextSource(
                id="recommendation_engine",
                title="Remaind Recommendation Engine",
                source_type="answer_instruction",
                authority="current_session",
                freshness="live",
                content=recommendation_decision,
                mandatory=True,
                reason="Universal recommendation engine selects or shapes the next action from current evidence.",
                budget_group="answer",
            )
        )
    recommendation_judgment = render_recommendation_judgment_section(
        task,
        judgment_evidence_texts,
    )
    if recommendation_judgment:
        sources.append(
            ContextSource(
                id="recommendation_judgment",
                title="Recommendation Judgment",
                source_type="answer_instruction",
                authority="current_session",
                freshness="live",
                content=recommendation_judgment,
                mandatory=True,
                reason="Shared recommendation judgment applies current constraints before suggesting a path.",
                budget_group="answer",
            )
        )
    recall_judgment = render_recall_judgment_section(
        task,
        judgment_evidence_texts,
    )
    if recall_judgment:
        sources.append(
            ContextSource(
                id="recall_judgment",
                title="Recall Judgment",
                source_type="answer_instruction",
                authority="current_session",
                freshness="live",
                content=recall_judgment,
                mandatory=True,
                reason="Shared recall judgment requires exact user/source evidence before stating remembered facts.",
                budget_group="answer",
            )
        )
    suggestion_judgment = render_suggestion_judgment_section(
        task,
        judgment_evidence_texts,
    )
    if suggestion_judgment:
        sources.append(
            ContextSource(
                id="suggestion_judgment",
                title="Suggestion Judgment",
                source_type="answer_instruction",
                authority="current_session",
                freshness="live",
                content=suggestion_judgment,
                mandatory=True,
                reason="Shared suggestion judgment separates new adjacent ideas from repeated or padded options.",
                budget_group="answer",
            )
        )
    intent, selection = select_engineered_context(
        ContextBuildRequest(question=task, token_cap=token_cap),
        sources,
    )
    parts = [
        sources[0].content,
        render_context_decision_section(
            question=task,
            workspace_query=None,
            intent=intent,
            selection=selection,
        ),
    ]
    selected_ids = {source.id for source in selection.selected}
    for source in sources[1:]:
        if source.id in selected_ids:
            parts.append(source.content)
    packet = "\n\n".join(parts).strip() + "\n"
    omitted = [omitted_source.title for omitted_source in selection.omitted]
    return packet, estimate_tokens(packet), omitted


def _judgment_evidence_texts(
    *,
    markers: list[LargeDocumentLinesResult],
    head: LargeDocumentLinesResult,
    tail: LargeDocumentLinesResult,
    searches: list[LargeDocumentSearchResult],
    deep_evidence_block: str | None,
) -> list[str]:
    evidence: list[str] = []
    if deep_evidence_block:
        evidence.append(deep_evidence_block)
    if markers:
        evidence.append(_format_marker_sections(markers))
    evidence.append(_format_lines(head, max_rows=len(head.lines)))
    evidence.append(_format_lines(tail, max_rows=len(tail.lines)))
    evidence.extend(_search_section(result) for result in searches)
    return [item for item in evidence if item.strip()]


def _answer_prompt(task: str, packet: str) -> tuple[str, str]:
    system = (
        "You are running inside Remaind. Use only the supplied local evidence "
        "packet. Cite line numbers when lines are available. If the evidence is "
        "insufficient, say what is missing and which extra search query or slice "
        "would be useful. Do not claim you read the whole source file directly."
    )
    user = (
        f"{packet}\n\n"
        "## Required Response\n\n"
        f"Complete this task:\n{task.strip()}\n"
    )
    return system, user


def _write_active_packet(base: Path, packet: str) -> Path:
    paths = ContextPaths.at(base)
    packet_path = paths.active_dir / "run_packet.md"
    atomic_write_text(
        packet_path,
        packet,
        history_dir=paths.history_dir / "run_packet",
    )
    return packet_path


def _answer_placeholder(*, model_error: str | None = None, pending: bool = False) -> str:
    if pending:
        return (
            "Model answer pending.\n\n"
            "Remaind has already written the evidence packet. If the local model "
            "request times out or is interrupted, rerun from the packet path shown "
            "in the terminal output instead of reloading the source file directly.\n"
        )
    if model_error:
        return (
            "Model answer was not generated.\n\n"
            f"Reason: {model_error}\n\n"
            "The Remaind evidence packet was preserved. Review run_packet.md or "
            "rerun with a larger REMAIND_LOCAL_MODEL_TIMEOUT / smaller token cap.\n"
        )
    return "No model answer was generated.\n"


def _write_active_answer(
    base: Path,
    answer: str | None,
    *,
    model_error: str | None = None,
    pending: bool = False,
) -> Path:
    paths = ContextPaths.at(base)
    answer_path = paths.active_dir / "run_answer.md"
    content = answer if answer is not None else _answer_placeholder(
        model_error=model_error,
        pending=pending,
    )
    atomic_write_text(
        answer_path,
        content.strip() + "\n",
        history_dir=paths.history_dir / "run_answer",
    )
    return answer_path


def _write_active_outputs(
    base: Path,
    packet: str,
    answer: str | None,
    *,
    model_error: str | None = None,
) -> tuple[Path, Path]:
    packet_path = _write_active_packet(base, packet)
    answer_path = _write_active_answer(base, answer, model_error=model_error)
    return packet_path, answer_path


def _log_run(
    base: Path,
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    queries: list[str],
    packet_path: Path,
    answer_path: Path,
    answer: str | None,
    model_error: str | None,
    model_prompt_tokens: int | None,
    model_prompt_safe_limit: int | None,
    model_label: str | None,
    answer_key_path: str | None,
    answer_validation: dict[str, Any] | None,
    deep_compaction: dict[str, Any] | None,
) -> list[str]:
    session_id, task_id = _read_session_ids(base)
    writer = EventWriter.open(base)
    user_event = writer.append(
        EventInput(
            type="user_message",
            actor="user",
            summary=f"Run task against local document: {task[:120]}",
            content=task,
            session_id=session_id,
            task_id=task_id,
            importance=3,
            metadata={"document_path": ingest.stats.path, "doc_id": ingest.stats.doc_id},
        )
    )
    payload = {
        "document": ingest.to_dict(),
        "queries": queries,
        "packet_path": str(packet_path),
        "answer_path": str(answer_path),
        "model_label": model_label,
        "model_prompt_tokens": model_prompt_tokens,
        "model_prompt_safe_limit": model_prompt_safe_limit,
        "answer_excerpt": (answer or "")[:4000],
        "model_error": model_error,
        "answer_key_path": answer_key_path,
        "answer_validation": answer_validation,
        "deep_compaction": deep_compaction,
    }
    result_event = writer.append(
        EventInput(
            type="tool_result",
            actor="tool:remaind-run",
            summary="Executed large local prompt through Remaind run",
            content=json.dumps(payload, indent=2, sort_keys=True),
            session_id=session_id,
            task_id=task_id,
            importance=2,
            source_event_ids=[str(user_event["id"]), ingest.source_event_id],
            tags=["remaind_run", "large_doc", ingest.stats.doc_id],
            metadata={
                "document_path": ingest.stats.path,
                "doc_id": ingest.stats.doc_id,
                "packet_path": str(packet_path),
                "answer_path": str(answer_path),
                "model_label": model_label,
                "model_error": model_error,
                "model_prompt_tokens": model_prompt_tokens,
                "model_prompt_safe_limit": model_prompt_safe_limit,
                "answer_key_path": answer_key_path,
                "answer_validation_passed": (
                    answer_validation.get("passed")
                    if isinstance(answer_validation, dict)
                    else None
                ),
                "deep_compaction_run_id": (
                    deep_compaction.get("run_id")
                    if isinstance(deep_compaction, dict)
                    else None
                ),
            },
        )
    )
    return [str(user_event["id"]), str(result_event["id"])]


def _deep_compaction_metadata(
    result: DeepCompactionResult | None,
) -> dict[str, Any] | None:
    if result is None:
        return None
    data = result.to_dict()
    data.pop("evidence_block", None)
    data.pop("global_summary", None)
    return data


def _update_state_summary(
    base: Path,
    *,
    task: str,
    ingest: LargeDocumentIngestResult,
    answer_path: Path,
    packet_path: Path,
    model_error: str | None = None,
    progress_kind: str = "run",
) -> None:
    tracking_task = clean_product_status_text(task)
    is_memory_question = progress_kind == "memory_question"

    def patch(state: dict[str, Any]) -> dict[str, Any]:
        files = list(state.get("files_touched") or [])
        for item in (ingest.stats.path, str(packet_path), str(answer_path)):
            if item not in files:
                files.append(item)
        completed_work = list(state.get("completed_work") or [])
        open_blockers = [
            item
            for item in list(state.get("open_blockers") or [])
            if not str(item).startswith("Current run blocked:")
        ]
        if model_error:
            blocker = f"Current run blocked: {model_error[:240]}"
            if blocker not in open_blockers:
                open_blockers.append(blocker)
        elif not is_memory_question:
            completed = f"Completed run task: {tracking_task[:220]}"
            if completed not in completed_work:
                completed_work.append(completed)
        return {
            **state,
            "current_goal": (
                state.get("current_goal") or "Initialize Remaind context."
                if is_memory_question
                else tracking_task[:240]
            ),
            "active_task": (
                f"Answer memory question: {tracking_task[:220]}"
                if is_memory_question
                else f"Run large local document task for {ingest.stats.title}"
            ),
            "status": "blocked" if model_error else "done",
            "next_step": (
                f"Fix the blocker, then retry the incomplete task from preserved "
                f"packet {packet_path} and answer note {answer_path}"
                if model_error
                else f"Review {answer_path}"
            ),
            "completed_work": completed_work[-50:],
            "open_blockers": open_blockers[-25:],
            "files_touched": files,
        }

    update_state(base, patch)


def _update_state_progress_checkpoint(
    base: Path,
    *,
    task: str,
    status: str,
    next_step: str,
    document_path: Path | None = None,
    packet_path: Path | None = None,
    answer_path: Path | None = None,
    progress_kind: str = "run",
) -> None:
    tracking_task = clean_product_status_text(task)
    is_memory_question = progress_kind == "memory_question"

    def patch(state: dict[str, Any]) -> dict[str, Any]:
        files = list(state.get("files_touched") or [])
        for item in (document_path, packet_path, answer_path):
            if item is None:
                continue
            text = str(item)
            if text not in files:
                files.append(text)
        return {
            **state,
            "current_goal": (
                state.get("current_goal") or "Initialize Remaind context."
                if is_memory_question
                else tracking_task[:240]
            ),
            "active_task": (
                f"Answer memory question: {tracking_task[:220]}"
                if is_memory_question
                else f"In progress: {tracking_task[:220]}"
            ),
            "status": status,
            "next_step": next_step,
            "files_touched": files,
        }

    update_state(base, patch)


def execute(
    base: Path,
    document_path: Path,
    task: str,
    *,
    title: str | None = None,
    auto_init: bool = True,
    context: int = DEFAULT_CONTEXT_LINES,
    max_results: int = DEFAULT_MAX_RESULTS,
    head_lines: int = DEFAULT_HEAD_LINES,
    tail_lines: int = DEFAULT_TAIL_LINES,
    query_count: int = DEFAULT_QUERY_COUNT,
    token_cap: int | None = None,
    no_model: bool = False,
    model: TextModel | None = None,
    model_name: str | None = None,
    openai_base_url: str | None = None,
    openai_api_key: str | None = None,
    ollama_host: str | None = None,
    ollama_api: str | None = None,
    num_ctx: int | None = None,
    extra_queries: list[str] | None = None,
    answer_key_path: Path | None = None,
    deep_compact: bool = False,
    deep_compact_mode: str = "lenient",
    reuse_deep_compact: bool = False,
    deep_compact_chunk_tokens: int | None = None,
    deep_compaction_model: Any | None = None,
    progress_callback: Callable[[str], None] | None = None,
    progress_kind: str = "run",
) -> RunResult:
    """Run a task against a large local prompt/document.

    The source file remains on disk. Remaind stores a manifest, retrieves
    selected exact evidence, writes a compact active packet, and optionally
    asks a detected local model to answer from that packet.
    """

    base = Path(base).expanduser().resolve()
    if not task.strip():
        raise RunError("task must not be empty")
    initialized_context = _ensure_context(base, auto_init=auto_init)
    progress_operation_id = new_progress_operation_id()
    _update_state_progress_checkpoint(
        base,
        task=task,
        status="implementing",
        next_step=(
            "Run started. If the terminal is interrupted, reopen Remaind and "
            "ask for project status; the progress snapshot will point to the "
            "latest saved checkpoint."
        ),
        document_path=document_path,
        progress_kind=progress_kind,
    )
    record_progress_snapshot(
        base,
        operation_id=progress_operation_id,
        phase="started",
        task=task,
        document_path=document_path,
        metadata={"operation_kind": progress_kind},
    )

    env_updates: dict[str, str | None] = {}
    if openai_base_url is not None:
        env_updates["REMAIND_OPENAI_BASE_URL"] = openai_base_url
        if openai_api_key is not None:
            env_updates["REMAIND_OPENAI_API_KEY"] = openai_api_key
    elif ollama_host is not None or ollama_api is not None:
        # An explicit Ollama run must not be shadowed by a configured
        # OpenAI-compatible endpoint from the user's launcher environment.
        env_updates["REMAIND_OPENAI_BASE_URL"] = None
        env_updates["REMAIND_OPENAI_MODEL"] = None
        env_updates["REMAIND_OPENAI_API_KEY"] = None
    if ollama_host is not None:
        env_updates["OLLAMA_HOST"] = ollama_host
    if ollama_api is not None:
        env_updates["REMAIND_OLLAMA_API"] = ollama_api
    if num_ctx is not None:
        env_updates["REMAIND_OLLAMA_NUM_CTX"] = str(num_ctx)
        env_updates["REMAIND_OPENAI_NUM_CTX"] = str(num_ctx)
    if model_name:
        if openai_base_url is not None:
            env_updates["REMAIND_OPENAI_MODEL"] = model_name
        elif ollama_host is not None or ollama_api is not None:
            env_updates["REMAIND_OLLAMA_MODEL"] = model_name
        else:
            env_updates["REMAIND_OLLAMA_MODEL"] = model_name
            env_updates["REMAIND_OPENAI_MODEL"] = model_name

    with _patched_env(env_updates):
        resolved_token_cap = _resolve_token_cap(token_cap=token_cap, num_ctx=num_ctx)
        if no_model:
            detected_model = None
        elif model is not None:
            detected_model = model
        elif openai_base_url is not None and model_name:
            detected_model = _openai_text_model(openai_base_url, model_name)
        else:
            detected_model = _detect_text_model()
        if deep_compact and no_model and deep_compaction_model is None:
            raise RunError(
                "--deep-compact requires local model calls; remove --no-model "
                "or run without deep compaction"
            )
        try:
            ingest = _ingest_if_needed(base, document_path, title=title)
            head = head_large_document(
                document_path, lines=head_lines, base=base, verify=True
            )
            tail = tail_large_document(
                document_path, lines=tail_lines, base=base, verify=True
            )
            # Deep compaction can involve long local-model calls. Build the
            # first checkpoint packet from deterministic fallback queries so
            # the run has a recoverable packet before any model request.
            queries = _model_queries(
                None if deep_compact else detected_model,
                task=task,
                ingest=ingest,
                head=head,
                tail=tail,
                query_count=query_count,
            )
            if extra_queries:
                queries = _unique([*extra_queries, *queries], limit=query_count)
            searches = _search_all(
                base,
                document_path,
                queries,
                context=context,
                max_results=max_results,
            )
            markers = _extract_marker_sections(document_path)
        except LargeDocumentError as exc:
            _update_state_progress_checkpoint(
                base,
                task=task,
                status="blocked",
                next_step=f"Fix source-document error, then retry: {exc}",
                document_path=document_path,
                progress_kind=progress_kind,
            )
            record_progress_snapshot(
                base,
                operation_id=progress_operation_id,
                phase="blocked",
                task=task,
                document_path=document_path,
                model_label=detected_model.label if detected_model is not None else None,
                model_error=str(exc),
                metadata={"operation_kind": progress_kind},
            )
            raise RunError(str(exc)) from exc

        packet, packet_tokens, omitted_sections = _build_packet(
            task=task,
            ingest=ingest,
            markers=markers,
            head=head,
            tail=tail,
            searches=searches,
            token_cap=resolved_token_cap,
        )
        # Checkpoint the packet before the expensive model call. Large local
        # models and deep compaction can time out after minutes; the operator
        # should still have a durable baseline evidence packet to resume from
        # instead of losing the whole run.
        packet_path = _write_active_packet(base, packet)
        answer_path = _write_active_answer(base, None, pending=True)
        _update_state_progress_checkpoint(
            base,
            task=task,
            status="implementing",
            next_step=(
                f"Evidence packet saved at {packet_path}. If the terminal "
                "or model call is interrupted, resume from this packet."
            ),
            document_path=document_path,
            packet_path=packet_path,
            answer_path=answer_path,
            progress_kind=progress_kind,
        )
        record_progress_snapshot(
            base,
            operation_id=progress_operation_id,
            phase="packet_ready",
            task=task,
            document_path=ingest.stats.path,
            packet_path=packet_path,
            answer_path=answer_path,
            model_label=detected_model.label if detected_model is not None else None,
            metadata={"operation_kind": progress_kind},
        )
        if progress_callback is not None:
            progress_callback(f"Packet checkpoint written: {packet_path}")
        answer: str | None = None
        model_error: str | None = None
        model_prompt_tokens: int | None = None
        model_prompt_safe_limit: int | None = None
        deep_result: DeepCompactionResult | None = None
        if deep_compact:
            try:
                deep_model = deep_compaction_model
                if deep_model is None and detected_model is not None:
                    deep_model = TextModelClient.from_env() or _DocumentTextModelAdapter(
                        detected_model
                    )
                deep_result = execute_deep_compaction(
                    base=base,
                    document_path=document_path,
                    task=task,
                    ingest=ingest,
                    num_ctx=num_ctx,
                    mode=deep_compact_mode,
                    reuse=reuse_deep_compact,
                    model=deep_model,
                    progress=progress_callback,
                    chunk_tokens=deep_compact_chunk_tokens,
                )
                packet, packet_tokens, omitted_sections = _build_packet(
                    task=task,
                    ingest=ingest,
                    markers=markers,
                    head=head,
                    tail=tail,
                    searches=searches,
                    token_cap=resolved_token_cap,
                    deep_evidence_block=deep_result.evidence_block,
                )
                packet_path = _write_active_packet(base, packet)
            except DocumentCompactionError as exc:
                model_error = f"deep compaction failed: {exc}"
        if detected_model is not None:
            if model_error is None:
                try:
                    system, user = _answer_prompt(task, packet)
                    (
                        model_prompt_tokens,
                        model_prompt_safe_limit,
                        model_prompt_error,
                    ) = _model_prompt_preflight(system, user, num_ctx=num_ctx)
                    if model_prompt_error:
                        model_error = model_prompt_error
                    else:
                        record_progress_snapshot(
                            base,
                            operation_id=progress_operation_id,
                            phase="model_call_started",
                            task=task,
                            document_path=ingest.stats.path,
                            packet_path=packet_path,
                            answer_path=answer_path,
                            model_label=detected_model.label,
                            metadata={"operation_kind": progress_kind},
                        )
                        answer = detected_model.generate(system, user)
                except CompactorResponseError as exc:
                    model_error = f"local model failed: {exc}"
        answer_key_found, answer_validation = _validate_answer_against_key(
            answer=answer,
            document_path=document_path,
            answer_key_path=answer_key_path,
        )

    answer_path = _write_active_answer(base, answer, model_error=model_error)
    event_ids = _log_run(
        base,
        task=task,
        ingest=ingest,
        queries=queries,
        packet_path=packet_path,
        answer_path=answer_path,
        answer=answer,
        model_error=model_error,
        model_prompt_tokens=model_prompt_tokens,
        model_prompt_safe_limit=model_prompt_safe_limit,
        model_label=detected_model.label if detected_model is not None else None,
        answer_key_path=answer_key_found,
        answer_validation=answer_validation,
        deep_compaction=_deep_compaction_metadata(deep_result),
    )
    _update_state_summary(
        base,
        task=task,
        ingest=ingest,
        answer_path=answer_path,
        packet_path=packet_path,
        model_error=model_error,
        progress_kind=progress_kind,
    )
    record_progress_snapshot(
        base,
        operation_id=progress_operation_id,
        phase="blocked" if model_error else "completed",
        task=task,
        document_path=ingest.stats.path,
        packet_path=packet_path,
        answer_path=answer_path,
        model_label=detected_model.label if detected_model is not None else None,
        model_error=model_error,
        answer=answer,
        metadata={
            "operation_kind": progress_kind,
            "event_ids": event_ids,
            "packet_tokens": packet_tokens,
            "token_cap": resolved_token_cap,
        },
    )

    return RunResult(
        base=str(base),
        document_path=ingest.stats.path,
        task=task,
        ingest=ingest.to_dict(),
        queries=queries,
        searches=[item.to_dict() for item in searches],
        head=head.to_dict(),
        tail=tail.to_dict(),
        packet_path=str(packet_path),
        answer_path=str(answer_path),
        packet_tokens=packet_tokens,
        token_cap=resolved_token_cap,
        model_prompt_tokens=model_prompt_tokens,
        model_prompt_safe_limit=model_prompt_safe_limit,
        model_label=detected_model.label if detected_model is not None else None,
        answer=answer,
        model_error=model_error,
        answer_key_path=answer_key_found,
        answer_validation=answer_validation,
        deep_compaction=_deep_compaction_metadata(deep_result),
        event_ids=event_ids,
        initialized_context=initialized_context,
        omitted_sections=omitted_sections,
    )


def render_human(result: RunResult) -> str:
    if result.model_error:
        status = "model failed after packet prepared"
    else:
        status = "answered" if result.answer else "packet prepared"
    rows = [
        f"Remaind run: {status}",
        f"Document:    {result.document_path}",
        f"Packet:      {result.packet_path}",
        f"Answer:      {result.answer_path}",
        f"Packet size: {result.packet_tokens}/{result.token_cap} tokens approx",
        f"Model:       {result.model_label or 'not used'}",
    ]
    if result.deep_compaction:
        rows.append(
            "Deep compaction: "
            f"{result.deep_compaction.get('status')} "
            f"({result.deep_compaction.get('chunks_succeeded')}/"
            f"{result.deep_compaction.get('chunks_total')} chunks, "
            f"{result.deep_compaction.get('chunks_failed')} failed, "
            f"{result.deep_compaction.get('chunks_quarantined')} quarantined)"
        )
        reducer_fallbacks = result.deep_compaction.get("reducer_fallbacks") or []
        if reducer_fallbacks:
            rows.append(
                "Reducer fallback: "
                f"{len(reducer_fallbacks)} reducer stage(s) used verified "
                "mechanical evidence"
            )
        rows.append(f"Deep run:    {result.deep_compaction.get('run_dir')}")
    if result.model_prompt_tokens is not None:
        safe = (
            f" / safe limit {result.model_prompt_safe_limit}"
            if result.model_prompt_safe_limit is not None
            else ""
        )
        rows.append(f"Model prompt: {result.model_prompt_tokens} tokens approx{safe}")
    if result.model_error:
        rows.append(f"Model error: {result.model_error}")
    if result.answer_key_path:
        validation_status = (
            "passed"
            if result.answer_validation and result.answer_validation.get("passed")
            else "failed"
        )
        rows.append(f"Answer key:  {validation_status} ({result.answer_key_path})")
        if result.answer_validation:
            for check in result.answer_validation.get("checks", []):
                marker = "PASS" if check.get("passed") else "FAIL"
                rows.append(f"  - {check.get('name')}: {marker}")
    if result.initialized_context:
        rows.append("Context:     initialized automatically")
    if result.queries:
        rows.append("Queries:")
        for query in result.queries:
            rows.append(f"  - {query}")
    if result.omitted_sections:
        rows.append("Omitted from packet due to token cap:")
        for section in result.omitted_sections:
            rows.append(f"  - {section}")
    rows.append("")
    rows.append("Answer:")
    if result.answer:
        rows.append(result.answer)
    elif result.model_error:
        rows.append(
            "No model answer was generated. The packet is preserved; review it "
            "or rerun with a larger REMAIND_LOCAL_MODEL_TIMEOUT / smaller token cap."
        )
    else:
        rows.append("No local model was detected; review the packet above.")
    return "\n".join(rows).rstrip() + "\n"


def render_json(result: RunResult) -> str:
    return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
