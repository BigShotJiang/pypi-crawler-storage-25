"""`remaind bench` — executable product proofs."""

from __future__ import annotations

from pathlib import Path

from .._benchmark import (
    DEFAULT_TARGET_TOKENS,
    DEFAULT_WORKDIR,
    BenchmarkError,
    SovereignBenchmarkResult,
    run_sovereign_benchmark,
)
from .._continuity_benchmark import (
    DEFAULT_CONTINUITY_WORKDIR,
    ProjectContinuityBenchmarkResult,
    run_project_continuity_benchmark,
)

__all__ = [
    "DEFAULT_TARGET_TOKENS",
    "DEFAULT_WORKDIR",
    "DEFAULT_CONTINUITY_WORKDIR",
    "BenchmarkError",
    "ProjectContinuityBenchmarkResult",
    "SovereignBenchmarkResult",
    "run_project_continuity_benchmark",
    "run_sovereign_benchmark",
]


def run_sovereign(
    *,
    workdir: Path = DEFAULT_WORKDIR,
    target_tokens: int = DEFAULT_TARGET_TOKENS,
    force: bool = False,
) -> SovereignBenchmarkResult:
    return run_sovereign_benchmark(
        workdir,
        target_tokens=target_tokens,
        force=force,
    )


def run_continuity(
    *,
    workdir: Path = DEFAULT_CONTINUITY_WORKDIR,
    force: bool = False,
) -> ProjectContinuityBenchmarkResult:
    return run_project_continuity_benchmark(workdir, force=force)
