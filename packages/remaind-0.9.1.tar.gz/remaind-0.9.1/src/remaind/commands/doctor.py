"""`remaind doctor` — operator readiness check.

Doctor is intentionally read-only. It combines structural validation, status,
and local-model runtime detection so an operator can answer one question:
"is this context safe to resume, and will compaction use a real local model?"
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .._local_compactor import detect_local_compactor
from . import status as status_cmd
from . import validate as validate_cmd


@dataclass(frozen=True)
class DoctorResult:
    path: str
    ok: bool
    validation_ok: bool
    validation_failed: list[tuple[str, str]]
    status_ok: bool
    status_error: str | None
    runtime: dict[str, Any]
    recommendations: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _runtime_payload(base: Path, *, smoke: bool = False) -> tuple[dict[str, Any], list[str]]:
    recommendations: list[str] = []
    if os.environ.get("REMAIND_DISABLE_LOCAL_MODEL", "").strip():
        recommendations.append(
            "Local-model detection is disabled by REMAIND_DISABLE_LOCAL_MODEL; "
            "compaction will use the rule-based fallback."
        )
        return (
            {
                "status": "disabled",
                "compaction_mode": "rule_based_fallback",
                "label": None,
                "model": None,
            },
            recommendations,
        )

    try:
        compactor = detect_local_compactor(base)
    except Exception as exc:  # pragma: no cover - defensive operator surface
        recommendations.append(
            "Local-model detection failed; run `remaind status` and inspect "
            "local runtime environment variables."
        )
        return (
            {
                "status": "error",
                "compaction_mode": "rule_based_fallback",
                "label": None,
                "model": None,
                "error": f"{type(exc).__name__}: {exc}",
            },
            recommendations,
        )

    if compactor is None:
        recommendations.append(
            "No local model runtime detected. Start Ollama on localhost:11434 "
            "or set REMAIND_OPENAI_BASE_URL for vLLM, llama.cpp, LM Studio, "
            "or another OpenAI-compatible local server."
        )
        return (
            {
                "status": "not_detected",
                "compaction_mode": "rule_based_fallback",
                "label": None,
                "model": None,
            },
            recommendations,
        )

    payload: dict[str, Any] = {
        "status": "detected",
        "compaction_mode": "local_model",
        "label": getattr(compactor, "label", type(compactor).__name__),
        "model": getattr(compactor, "model", None),
    }
    api_mode = getattr(compactor, "api_mode", None)
    if api_mode:
        payload["api_mode"] = api_mode

    if smoke:
        smoke_test = getattr(compactor, "smoke_test", None)
        if callable(smoke_test):
            result = smoke_test()
            payload["generation_check"] = result
            if not result.get("ok"):
                payload["status"] = "generation_failed"
                payload["compaction_mode"] = "local_model_unusable"
                recommendations.append(
                    "The local model was detected, but a real generation smoke "
                    "test failed. Fix the model/runtime or choose another model "
                    "before relying on model-backed compaction."
                )
        else:
            payload["generation_check"] = {
                "ok": False,
                "error": "selected runtime does not expose a smoke test",
            }
            payload["status"] = "generation_unknown"
            recommendations.append(
                "The selected runtime was detected but cannot be smoke-tested."
            )

    return (payload, recommendations)


def check(base: Path, *, smoke: bool = False) -> DoctorResult:
    base = Path(base)
    validation = validate_cmd.run(base)
    status_ok = True
    status_error: str | None = None
    try:
        status_cmd.build_status_payload(base)
    except status_cmd.StatusError as exc:
        status_ok = False
        status_error = str(exc)

    runtime, recommendations = _runtime_payload(base, smoke=smoke)
    if not validation.ok:
        # The first validation failure is `.context/: missing: …` when the
        # operator has not run `remaind init` yet. Recommending
        # `remaind validate` in that case is misleading — what they need is
        # `remaind init`. Detect this explicitly and surface the correct
        # action so the operator does not chase the wrong recommendation.
        context_missing = any(
            label == ".context/" and "missing" in reason
            for label, reason in validation.failed
        )
        if context_missing:
            recommendations.append(
                "Run `remaind init` to create the .context/ directory."
            )
        else:
            recommendations.append(
                "Run `remaind validate` and repair failed checks."
            )
    if not status_ok:
        recommendations.append("Run `remaind status` after restoring state.json.")

    generation = runtime.get("generation_check")
    generation_ok = True
    if isinstance(generation, dict):
        generation_ok = bool(generation.get("ok"))

    ok = validation.ok and status_ok and generation_ok
    return DoctorResult(
        path=str(base),
        ok=ok,
        validation_ok=validation.ok,
        validation_failed=list(validation.failed),
        status_ok=status_ok,
        status_error=status_error,
        runtime=runtime,
        recommendations=recommendations,
    )


def render_human(result: DoctorResult) -> str:
    lines: list[str] = []
    lines.append(f"Doctor: {'OK' if result.ok else 'FAIL'}")
    lines.append(f"Path:   {result.path}")
    lines.append("")
    lines.append(
        f"Context validation: {'ok' if result.validation_ok else 'failed'}"
    )
    for label, reason in result.validation_failed:
        lines.append(f"  FAIL {label}: {reason}")
    lines.append(f"Status read:        {'ok' if result.status_ok else 'failed'}")
    if result.status_error:
        lines.append(f"  {result.status_error}")
    lines.append("")
    runtime = result.runtime
    lines.append(f"Runtime:            {runtime['status']}")
    lines.append(f"Compaction mode:    {runtime['compaction_mode']}")
    if runtime.get("label"):
        lines.append(f"Runtime label:      {runtime['label']}")
    if runtime.get("model"):
        lines.append(f"Model:              {runtime['model']}")
    if runtime.get("api_mode"):
        lines.append(f"Ollama API mode:    {runtime['api_mode']}")
    generation = runtime.get("generation_check")
    if isinstance(generation, dict):
        lines.append(
            "Generation check:   "
            + ("ok" if generation.get("ok") else "failed")
        )
        if generation.get("api"):
            lines.append(f"Generation API:     {generation['api']}")
        if generation.get("error"):
            lines.append(f"Generation error:   {generation['error']}")
    if runtime.get("error"):
        lines.append(f"Runtime error:      {runtime['error']}")
    lines.append("")
    if result.recommendations:
        lines.append("Recommendations:")
        for item in result.recommendations:
            lines.append(f"  - {item}")
    else:
        lines.append("Recommendations:   (none)")
    return "\n".join(lines) + "\n"


def run(base: Path, *, as_json: bool = False, smoke: bool = False) -> str:
    result = check(base, smoke=smoke)
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    return render_human(result)
