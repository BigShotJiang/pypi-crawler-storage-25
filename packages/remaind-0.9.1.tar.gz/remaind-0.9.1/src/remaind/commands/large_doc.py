"""`remaind large-doc` — register and query large local documents."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Protocol

from .._large_doc import (
    LargeDocumentError,
    LargeDocumentIngestResult,
    LargeDocumentLinesResult,
    LargeDocumentSearchResult,
    head_large_document,
    ingest_large_document,
    large_document_stats,
    search_large_document,
    slice_large_document,
    tail_large_document,
    verify_large_document,
)
from .._paths import ContextPaths

__all__ = [
    "LargeDocumentError",
    "LargeDocumentIngestResult",
    "LargeDocumentLinesResult",
    "LargeDocumentSearchResult",
    "run_ingest",
    "run_search",
    "run_slice",
    "run_head",
    "run_tail",
    "run_verify",
    "run_inspect",
    "run_prune_deep_compactions",
    "render_human_ingest",
    "render_human_inspect",
    "render_human_prune",
    "render_human_search",
    "render_human_lines",
]


class _DictRenderable(Protocol):
    def to_dict(self) -> dict[str, Any]:
        ...


def _json(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True) + "\n"


def run_ingest(
    base: Path, document_path: Path, *, title: str | None = None
) -> LargeDocumentIngestResult:
    return ingest_large_document(base, document_path, title=title)


def run_search(
    document_path: Path,
    query: str,
    *,
    context: int = 2,
    max_results: int = 12,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentSearchResult:
    return search_large_document(
        document_path,
        query,
        context=context,
        max_results=max_results,
        base=base,
        verify=verify,
    )


def run_slice(
    document_path: Path,
    *,
    start: int,
    end: int,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    return slice_large_document(
        document_path,
        start=start,
        end=end,
        base=base,
        verify=verify,
    )


def run_head(
    document_path: Path,
    *,
    lines: int = 80,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    return head_large_document(
        document_path, lines=lines, base=base, verify=verify
    )


def run_tail(
    document_path: Path,
    *,
    lines: int = 80,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    return tail_large_document(
        document_path, lines=lines, base=base, verify=verify
    )


def run_verify(base: Path, document_path: Path) -> dict[str, Any]:
    return verify_large_document(base, document_path)


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _manifest_for_target(base: Path, target: str) -> tuple[Path, dict[str, Any]]:
    base = Path(base).expanduser().resolve()
    paths = ContextPaths.at(base)
    maybe_path = Path(target).expanduser()
    doc_id = large_document_stats(base, maybe_path).doc_id if maybe_path.exists() else target
    manifest_path = paths.large_docs_dir / doc_id / "manifest.json"
    manifest = _load_json(manifest_path)
    if manifest is not None:
        return manifest_path, manifest
    if maybe_path.exists():
        resolved = str(maybe_path.resolve())
        for candidate in paths.large_docs_dir.glob("*/manifest.json"):
            manifest = _load_json(candidate)
            if manifest is not None and str(manifest.get("path") or "") == resolved:
                return candidate, manifest
    raise LargeDocumentError(f"no large-doc manifest found for {target!r}")


def _deep_run_summaries(doc_dir: Path) -> list[dict[str, Any]]:
    root = doc_dir / "deep-compactions"
    if not root.is_dir():
        return []
    runs: list[dict[str, Any]] = []
    for manifest_path in root.glob("*/manifest.json"):
        manifest = _load_json(manifest_path) or {}
        run_dir = manifest_path.parent
        runs.append(
            {
                "run_id": str(manifest.get("run_id") or run_dir.name),
                "status": str(manifest.get("status") or "unknown"),
                "run_dir": str(run_dir),
                "created_at": manifest.get("created_at"),
                "updated_at": manifest.get("updated_at"),
                "chunks_total": int(manifest.get("chunks_total") or 0),
                "chunks_succeeded": int(manifest.get("chunks_succeeded") or 0),
                "chunks_failed": int(manifest.get("chunks_failed") or 0),
                "chunks_quarantined": int(manifest.get("chunks_quarantined") or 0),
                "cache_key": str(manifest.get("cache_key") or ""),
            }
        )
    runs.sort(key=lambda item: str(item.get("updated_at") or ""), reverse=True)
    return runs


def run_inspect(base: Path, target: str) -> dict[str, Any]:
    manifest_path, manifest = _manifest_for_target(base, target)
    return {
        "manifest_path": str(manifest_path),
        "doc_id": str(manifest.get("doc_id") or manifest_path.parent.name),
        "path": str(manifest.get("path") or ""),
        "sha256": str(manifest.get("sha256") or ""),
        "bytes": int(manifest.get("bytes") or 0),
        "lines": int(manifest.get("lines") or 0),
        "title": str(manifest.get("title") or ""),
        "deep_compactions": _deep_run_summaries(manifest_path.parent),
    }


def run_prune_deep_compactions(
    base: Path, target: str, *, keep_latest: int = 1
) -> dict[str, Any]:
    if keep_latest < 0:
        raise LargeDocumentError("--keep-latest must be >= 0")
    manifest_path, manifest = _manifest_for_target(base, target)
    root = manifest_path.parent / "deep-compactions"
    runs = _deep_run_summaries(manifest_path.parent)
    keep = {str(item["run_id"]) for item in runs[:keep_latest]}
    removed: list[str] = []
    if root.is_dir():
        for run_dir in root.iterdir():
            if not run_dir.is_dir() or run_dir.name in keep:
                continue
            shutil.rmtree(run_dir)
            removed.append(str(run_dir))
    return {
        "doc_id": str(manifest.get("doc_id") or manifest_path.parent.name),
        "manifest_path": str(manifest_path),
        "kept": sorted(keep),
        "removed": removed,
    }


def render_human_ingest(result: LargeDocumentIngestResult) -> str:
    stats = result.stats
    return (
        f"Indexed large document: {stats.title}\n"
        f"  doc_id:   {stats.doc_id}\n"
        f"  path:     {stats.path}\n"
        f"  size:     {stats.bytes} bytes, {stats.lines} lines\n"
        f"  sha256:   {stats.sha256}\n"
        f"  manifest: {result.manifest_path}\n"
        f"  event:    {result.source_event_id}\n"
        f"  memory:   {result.memory_id}\n"
    )


def render_human_inspect(result: dict[str, Any]) -> str:
    rows = [
        f"Large document: {result.get('title')}",
        f"  doc_id:   {result.get('doc_id')}",
        f"  path:     {result.get('path')}",
        f"  size:     {result.get('bytes')} bytes, {result.get('lines')} lines",
        f"  sha256:   {result.get('sha256')}",
        f"  manifest: {result.get('manifest_path')}",
        "Deep compactions:",
    ]
    runs = result.get("deep_compactions")
    if not isinstance(runs, list) or not runs:
        rows.append("  none")
    else:
        for item in runs:
            rows.append(
                "  "
                f"{item.get('run_id')}: {item.get('status')} "
                f"{item.get('chunks_succeeded')}/{item.get('chunks_total')} chunks, "
                f"{item.get('chunks_failed')} failed, "
                f"{item.get('chunks_quarantined')} quarantined"
            )
            rows.append(f"    {item.get('run_dir')}")
    return "\n".join(rows) + "\n"


def render_human_prune(result: dict[str, Any]) -> str:
    rows = [
        f"Pruned deep compactions for {result.get('doc_id')}",
        f"  kept:    {', '.join(result.get('kept') or []) or 'none'}",
        f"  removed: {len(result.get('removed') or [])}",
    ]
    for item in result.get("removed") or []:
        rows.append(f"    {item}")
    return "\n".join(rows) + "\n"


def render_human_search(result: LargeDocumentSearchResult) -> str:
    rows = [
        f"Search: {result.query!r}",
        f"Path:   {result.path}",
        f"Mode:   {result.match_mode}",
        f"Hits:   {result.hit_count} returned"
        + (" (limit reached; more may exist)" if result.may_have_more else ""),
    ]
    if result.integrity:
        status = "verified" if result.integrity["verified"] else "changed"
        rows.append(f"Source: {status} against {result.integrity['manifest_path']}")
    for hit in result.hits:
        rows.append("")
        rows.append(f"line {hit.line}: {hit.text}")
        context_lines = [row for row in hit.context if row["line"] != hit.line]
        if context_lines:
            rows.append("context:")
            for row in hit.context:
                prefix = ">" if row["line"] == hit.line else " "
                rows.append(f"{prefix} {row['line']}: {row['text']}")
    return "\n".join(rows) + "\n"


def render_human_lines(result: LargeDocumentLinesResult) -> str:
    rows = [f"{result.mode}: {result.path}"]
    if result.start is not None and result.end is not None:
        rows.append(f"range: {result.start}-{result.end}")
    rows.append(f"lines: {len(result.lines)}")
    if result.integrity:
        status = "verified" if result.integrity["verified"] else "changed"
        rows.append(f"source: {status} against {result.integrity['manifest_path']}")
    rows.append("")
    for row in result.lines:
        rows.append(f"{row['line']}: {row['text']}")
    return "\n".join(rows) + "\n"


def render_json(result: _DictRenderable) -> str:
    return _json(result.to_dict())
