"""`remaind public-bench` — bridges to external public benchmarks."""

from __future__ import annotations

from pathlib import Path

from .._amb_benchmark import (
    AMBBenchmarkError,
    AMBDiffReport,
    AMBFailureTaxonomy,
    AMBOfflineScoreReport,
    AMBPrepareResult,
    AMBScoreReport,
    build_amb_failure_taxonomy,
    build_amb_offline_score,
    build_amb_score_diff,
    build_amb_score_report,
    prepare_amb,
    render_amb_failure_taxonomy,
    render_amb_offline_score,
    render_amb_prepare,
    render_amb_score_diff,
    render_amb_score_report,
)
from .._public_benchmarks import (
    DEFAULT_STATE_BENCH_WORKDIR,
    PublicBenchmarkError,
    StateBenchPrepareResult,
    StateBenchRetrieval,
    prepare_state_bench,
    render_state_bench_prepare,
    render_state_bench_retrieval,
    retrieve_state_bench_learnings,
    search_state_bench_memory,
)

__all__ = [
    "AMBBenchmarkError",
    "AMBDiffReport",
    "AMBFailureTaxonomy",
    "AMBOfflineScoreReport",
    "AMBPrepareResult",
    "AMBScoreReport",
    "DEFAULT_STATE_BENCH_WORKDIR",
    "PublicBenchmarkError",
    "StateBenchPrepareResult",
    "StateBenchRetrieval",
    "render_amb_failure_taxonomy",
    "render_amb_offline_score",
    "render_amb_prepare",
    "render_amb_score_report",
    "render_amb_score_diff",
    "render_state_bench_prepare",
    "render_state_bench_retrieval",
    "run_amb_diff",
    "run_amb_offline_score",
    "run_amb_taxonomy",
    "run_amb_prepare",
    "run_amb_report",
    "run_state_bench_prepare",
    "run_state_bench_retrieve",
]


def run_amb_prepare(
    *,
    amb_repo: Path,
    remaind_source_path: Path | None = None,
) -> AMBPrepareResult:
    return prepare_amb(
        amb_repo=amb_repo,
        remaind_source_path=remaind_source_path,
    )


def run_amb_report(*, result_path: Path) -> AMBScoreReport:
    return build_amb_score_report(result_path)


def run_amb_taxonomy(*, result_path: Path) -> AMBFailureTaxonomy:
    return build_amb_failure_taxonomy(result_path)


def run_amb_diff(*, baseline_path: Path, candidate_path: Path) -> AMBDiffReport:
    return build_amb_score_diff(
        baseline_path=baseline_path,
        candidate_path=candidate_path,
    )


def run_amb_offline_score(
    *,
    result_path: Path,
    failures_only: bool = False,
    categories: tuple[str, ...] = (),
) -> AMBOfflineScoreReport:
    return build_amb_offline_score(
        result_path,
        failures_only=failures_only,
        categories=categories,
    )


def run_state_bench_prepare(
    *,
    state_bench_repo: Path,
    workdir: Path = DEFAULT_STATE_BENCH_WORKDIR,
    train_dir: Path | None = None,
    force: bool = False,
    install_agent: bool = True,
) -> StateBenchPrepareResult:
    return prepare_state_bench(
        state_bench_repo=state_bench_repo,
        workdir=workdir,
        train_dir=train_dir,
        force=force,
        install_agent=install_agent,
    )


def run_state_bench_retrieve(
    *,
    artifact: Path | None = None,
    workdir: Path | None = None,
    query: str,
    top_k: int = 3,
) -> StateBenchRetrieval:
    if artifact is not None and workdir is not None:
        raise PublicBenchmarkError("pass either --artifact or --workdir, not both")
    if artifact is None and workdir is None:
        raise PublicBenchmarkError("pass --artifact or --workdir")
    if artifact is not None:
        return retrieve_state_bench_learnings(
            artifact_path=artifact,
            query=query,
            top_k=top_k,
        )
    assert workdir is not None
    return search_state_bench_memory(workdir=workdir, query=query, top_k=top_k)
