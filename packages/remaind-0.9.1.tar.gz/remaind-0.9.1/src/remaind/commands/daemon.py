"""`remaind daemon` — lightweight local presence for Remaind workspaces."""

from __future__ import annotations

import json
import os
import shlex
import signal
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from .._atomic import atomic_write_text
from .._cwd import safe_cwd
from .._errors import RemaindError
from .._jsonl import append_jsonl
from .._paths import ContextPaths
from .._plan_reconciliation import update_plan_reconciliation_from_presence
from .._product_status import update_product_status_from_presence
from .._timestamps import utc_now_filename_safe_us, utc_now_iso
from . import launch as launch_cmd

REMAIND_HOME_ENV = "REMAIND_HOME"
DAEMON_INTERVAL_ENV = "REMAIND_DAEMON_INTERVAL"
DEFAULT_INTERVAL_S = 30.0
INDEX_VERSION = 1
WORKSPACE_PREVIEW_CHARS = 2_000
PRESENCE_SCHEMA_VERSION = "1.0.0"
MAX_CHANGED_FILES = 80
MAX_COMMAND_PREVIEW_CHARS = 240
_IGNORED_COMMANDS = {
    "",
    "cd",
    "clear",
    "exit",
    "fg",
    "bg",
    "history",
    "jobs",
    "ls",
    "pwd",
}
_MEANINGFUL_COMMANDS = {
    "bun",
    "cargo",
    "deno",
    "docker",
    "git",
    "go",
    "make",
    "mvn",
    "node",
    "npm",
    "pnpm",
    "pytest",
    "python",
    "python3",
    "remaind",
    "ruff",
    "swift",
    "tox",
    "tsc",
    "uv",
    "yarn",
}
_SECRET_MARKERS = (
    "api_key",
    "api-key",
    "apikey",
    "authorization",
    "bearer",
    "client_secret",
    "password",
    "secret",
    "token",
)


class DaemonError(RemaindError):
    """Raised when the Remaind presence daemon cannot complete an action."""


@dataclass(frozen=True)
class WorkspaceRecord:
    path: str
    name: str
    aliases: list[str]
    search_text_preview: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ReindexResult:
    index_path: str
    updated_at: str
    workspaces: list[WorkspaceRecord]

    def to_dict(self) -> dict[str, Any]:
        return {
            "index_path": self.index_path,
            "updated_at": self.updated_at,
            "workspaces": [workspace.to_dict() for workspace in self.workspaces],
        }


@dataclass(frozen=True)
class DaemonStatus:
    running: bool
    pid: int | None
    index_path: str
    indexed_workspaces: int
    updated_at: str | None
    active_workspace: str | None
    active_workspace_name: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PresenceCaptureResult:
    captured: bool
    workspace: str | None
    activity_path: str | None
    snapshot_path: str | None
    product_status_updated: bool
    activity: dict[str, Any] | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ShellHookInstallResult:
    shell: str
    rc_file: str
    changed: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def state_dir() -> Path:
    raw = os.environ.get(REMAIND_HOME_ENV, "").strip()
    if raw:
        return Path(raw).expanduser()
    return Path.home() / ".remaind"


def index_path() -> Path:
    return state_dir() / "workspace-index.json"


def pid_path() -> Path:
    return state_dir() / "daemon.pid"


def heartbeat_path() -> Path:
    return state_dir() / "daemon-heartbeat.json"


def log_path() -> Path:
    return state_dir() / "daemon.log"


def _ensure_state_dir() -> Path:
    root = state_dir()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _load_pid() -> int | None:
    path = pid_path()
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not raw.isdigit():
        return None
    return int(raw)


def _process_alive(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _workspace_record(path: Path) -> WorkspaceRecord:
    aliases = [alias.query for alias in launch_cmd._aliases_for_workspace(path)]
    search_text = launch_cmd._workspace_search_text(path)
    preview = " ".join(search_text.split())[:WORKSPACE_PREVIEW_CHARS]
    return WorkspaceRecord(
        path=str(path.expanduser().resolve()),
        name=path.name,
        aliases=aliases,
        search_text_preview=preview,
    )


def _workspace_candidates(cwd: Path) -> list[Path]:
    visible = launch_cmd._discover_project_folders(cwd)
    return [
        path
        for path in launch_cmd._workspace_index_candidates(cwd, visible)
        if (path / ".context").is_dir()
    ]


def _load_index() -> dict[str, Any]:
    try:
        return json.loads(index_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def reindex(*, cwd: Path | None = None) -> ReindexResult:
    base = (cwd or safe_cwd()).expanduser().resolve()
    _ensure_state_dir()
    records = [_workspace_record(path) for path in _workspace_candidates(base)]
    records.sort(key=lambda record: record.path.lower())
    updated_at = utc_now_iso()
    payload = {
        "version": INDEX_VERSION,
        "updated_at": updated_at,
        "workspaces": [record.to_dict() for record in records],
    }
    atomic_write_text(index_path(), json.dumps(payload, indent=2, sort_keys=True) + "\n")
    return ReindexResult(
        index_path=str(index_path()),
        updated_at=updated_at,
        workspaces=records,
    )


def _workspace_from_record(record: dict[str, Any]) -> Path | None:
    raw = record.get("path")
    if not isinstance(raw, str) or not raw:
        return None
    path = Path(raw).expanduser()
    return path if (path / ".context").is_dir() else None


def _nearest_workspace(cwd: Path) -> Path | None:
    current = cwd.expanduser().resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".context").is_dir():
            return candidate
    payload = _load_index()
    records = payload.get("workspaces")
    if not isinstance(records, list):
        return None
    matches: list[Path] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        workspace = _workspace_from_record(record)
        if workspace is None:
            continue
        try:
            current.relative_to(workspace)
        except ValueError:
            continue
        matches.append(workspace)
    matches.sort(key=lambda path: len(path.parts), reverse=True)
    return matches[0] if matches else None


def _split_command(command: str) -> list[str]:
    try:
        return shlex.split(command)
    except ValueError:
        return command.split()


def _redact_command_token(token: str, *, previous_sensitive: bool = False) -> str:
    lowered = token.lower()
    if previous_sensitive:
        return "<redacted>"
    if "=" in token:
        key, _value = token.split("=", 1)
        if any(marker in key.lower() for marker in _SECRET_MARKERS):
            return f"{key}=<redacted>"
    if any(marker in lowered for marker in _SECRET_MARKERS):
        if "=" in token:
            key, _value = token.split("=", 1)
            return f"{key}=<redacted>"
        return token
    return token


def _command_preview(command: str) -> tuple[str, str]:
    tokens = _split_command(command.strip())
    if not tokens:
        return "", ""
    preview_tokens: list[str] = []
    previous_sensitive = False
    for token in tokens[:12]:
        redacted = _redact_command_token(token, previous_sensitive=previous_sensitive)
        preview_tokens.append(redacted)
        lowered = token.lower().lstrip("-")
        previous_sensitive = any(marker in lowered for marker in _SECRET_MARKERS)
    if len(tokens) > 12:
        preview_tokens.append("...")
    preview = " ".join(preview_tokens)
    if len(preview) > MAX_COMMAND_PREVIEW_CHARS:
        preview = preview[: MAX_COMMAND_PREVIEW_CHARS - 3].rstrip() + "..."
    executable = Path(tokens[0]).name.lower()
    return preview, executable


def _is_remaind_presence_command(command: str) -> bool:
    tokens = _split_command(command.strip())
    if len(tokens) < 3:
        return False
    return tokens[0] == "remaind" and tokens[1] == "daemon" and tokens[2] in {
        "observe",
        "status",
        "shell-init",
        "reindex",
    }


def _git_root(cwd: Path) -> Path | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(cwd), "rev-parse", "--show-toplevel"],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    raw = result.stdout.strip()
    return Path(raw).resolve() if raw else None


def _git_changed_files(cwd: Path) -> tuple[str | None, str | None, list[str]]:
    root = _git_root(cwd)
    if root is None:
        return None, None, []
    try:
        branch_result = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "--abbrev-ref", "HEAD"],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
        status_result = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain=v1"],
            check=False,
            capture_output=True,
            text=True,
            timeout=3,
        )
    except (OSError, subprocess.SubprocessError):
        return str(root), None, []
    branch = branch_result.stdout.strip() if branch_result.returncode == 0 else None
    changed: list[str] = []
    if status_result.returncode == 0:
        for raw in status_result.stdout.splitlines():
            if not raw:
                continue
            path = raw[3:].strip()
            if " -> " in path:
                path = path.split(" -> ", 1)[1].strip()
            if not _include_changed_path(path):
                continue
            changed.append(path)
            if len(changed) >= MAX_CHANGED_FILES:
                break
    return str(root), branch, changed


def _include_changed_path(path: str) -> bool:
    normalized = path.strip()
    if normalized.startswith("./"):
        normalized = normalized[2:]
    return not (
        normalized == ".context"
        or normalized.startswith(".context/")
        or normalized == ".remaind"
        or normalized.startswith(".remaind/")
    )


def _meaningful_presence_activity(
    *,
    executable: str,
    command_preview: str,
    exit_code: int,
    changed_files: list[str],
) -> bool:
    if _is_remaind_presence_command(command_preview):
        return False
    if executable in _IGNORED_COMMANDS:
        return bool(changed_files)
    if changed_files:
        return True
    if executable in _MEANINGFUL_COMMANDS:
        return True
    return False


def observe_activity(
    *,
    cwd: Path,
    command: str,
    exit_code: int,
    duration_ms: int | None = None,
) -> PresenceCaptureResult:
    workspace = _nearest_workspace(cwd)
    preview, executable = _command_preview(command)
    if workspace is None or not preview:
        return PresenceCaptureResult(False, None, None, None, False, None)
    git_root, git_branch, changed_files = _git_changed_files(cwd)
    meaningful = _meaningful_presence_activity(
        executable=executable,
        command_preview=preview,
        exit_code=exit_code,
        changed_files=changed_files,
    )
    activity = {
        "schema_version": PRESENCE_SCHEMA_VERSION,
        "activity_id": f"presence_{utc_now_filename_safe_us()}",
        "updated_at": utc_now_iso(),
        "workspace": str(workspace),
        "cwd": str(cwd.expanduser().resolve()),
        "command_preview": preview,
        "executable": executable,
        "exit_code": exit_code,
        "duration_ms": duration_ms,
        "git_root": git_root,
        "git_branch": git_branch,
        "changed_files": changed_files,
        "changed_file_count": len(changed_files),
        "changed_files_truncated": len(changed_files) >= MAX_CHANGED_FILES,
        "meaningful": meaningful,
        "privacy": "command metadata only; terminal output is not recorded",
    }
    paths = ContextPaths.at(workspace)
    atomic_write_text(
        paths.presence_snapshot,
        json.dumps(activity, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "presence_snapshot",
    )
    append_jsonl(paths.presence_jsonl, activity)
    append_jsonl(state_dir() / "presence.jsonl", activity)
    product_status_updated = False
    if meaningful:
        update_product_status_from_presence(workspace, activity)
        update_plan_reconciliation_from_presence(workspace, activity)
        product_status_updated = True
    return PresenceCaptureResult(
        True,
        str(workspace),
        str(paths.presence_jsonl),
        str(paths.presence_snapshot),
        product_status_updated,
        activity,
    )


def status(*, cwd: Path | None = None) -> DaemonStatus:
    pid = _load_pid()
    payload = _load_index()
    records = payload.get("workspaces")
    workspace = _nearest_workspace(cwd or safe_cwd())
    return DaemonStatus(
        running=_process_alive(pid),
        pid=pid,
        index_path=str(index_path()),
        indexed_workspaces=len(records) if isinstance(records, list) else 0,
        updated_at=payload.get("updated_at") if isinstance(payload.get("updated_at"), str) else None,
        active_workspace=str(workspace) if workspace is not None else None,
        active_workspace_name=workspace.name if workspace is not None else None,
    )


def render_status(result: DaemonStatus, *, short: bool = False) -> str:
    if short:
        if result.active_workspace:
            return f"Remaind memory active: {result.active_workspace_name}\n"
        return ""
    rows = [
        f"Daemon: {'running' if result.running else 'stopped'}",
        f"PID: {result.pid if result.pid is not None else 'none'}",
        f"Index: {result.index_path}",
        f"Indexed workspaces: {result.indexed_workspaces}",
        f"Updated: {result.updated_at or 'never'}",
    ]
    if result.active_workspace:
        rows.append(f"Active memory: {result.active_workspace}")
    else:
        rows.append("Active memory: none for this folder")
    return "\n".join(rows) + "\n"


def render_reindex(result: ReindexResult, *, as_json: bool = False) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    rows = [
        f"Indexed {len(result.workspaces)} workspace(s).",
        f"Index: {result.index_path}",
    ]
    for workspace in result.workspaces:
        alias_text = f" aliases={', '.join(workspace.aliases)}" if workspace.aliases else ""
        rows.append(f"- {workspace.path}{alias_text}")
    return "\n".join(rows) + "\n"


def run_forever(*, interval_s: float = DEFAULT_INTERVAL_S, once: bool = False) -> None:
    _ensure_state_dir()
    atomic_write_text(pid_path(), f"{os.getpid()}\n")
    try:
        while True:
            result = reindex()
            heartbeat = {
                "pid": os.getpid(),
                "updated_at": result.updated_at,
                "indexed_workspaces": len(result.workspaces),
            }
            atomic_write_text(
                heartbeat_path(),
                json.dumps(heartbeat, indent=2, sort_keys=True) + "\n",
            )
            if once:
                return
            time.sleep(max(1.0, interval_s))
    except KeyboardInterrupt:
        return


def start(*, interval_s: float = DEFAULT_INTERVAL_S, foreground: bool = False) -> DaemonStatus:
    existing_pid = _load_pid()
    if _process_alive(existing_pid):
        return status()
    _ensure_state_dir()
    reindex()
    if foreground:
        run_forever(interval_s=interval_s)
        return status()
    with log_path().open("ab") as log:
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "remaind",
                "daemon",
                "run",
                "--interval",
                str(interval_s),
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    atomic_write_text(pid_path(), f"{process.pid}\n")
    return status()


def stop() -> DaemonStatus:
    pid = _load_pid()
    if _process_alive(pid):
        assert pid is not None
        os.kill(pid, signal.SIGTERM)
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            if not _process_alive(pid):
                break
            time.sleep(0.05)
    return status()


def shell_init(shell: Literal["zsh", "bash", "fish"]) -> str:
    if shell == "zsh":
        return """# Remaind presence hook for zsh.
_remaind_presence_last_command=""
_remaind_presence_started_s=0
_remaind_presence_preexec() {
  _remaind_presence_last_command="$1"
  _remaind_presence_started_s="$(date +%s 2>/dev/null || echo 0)"
}
_remaind_presence_precmd() {
  local exit_code="$?"
  if [[ -n "$_remaind_presence_last_command" ]]; then
    local now_s duration_ms
    now_s="$(date +%s 2>/dev/null || echo "$_remaind_presence_started_s")"
    duration_ms=$(( (now_s - _remaind_presence_started_s) * 1000 ))
    remaind daemon observe --cwd "$PWD" --command "$_remaind_presence_last_command" --exit-code "$exit_code" --duration-ms "$duration_ms" >/dev/null 2>&1 || true
    _remaind_presence_last_command=""
  fi
  local message
  message="$(remaind daemon status --short --cwd "$PWD" 2>/dev/null)" || return 0
  [[ -n "$message" ]] && print -r -- "$message"
}
autoload -Uz add-zsh-hook
add-zsh-hook preexec _remaind_presence_preexec
add-zsh-hook precmd _remaind_presence_precmd
"""
    if shell == "bash":
        return """# Remaind presence hook for bash.
_remaind_presence_last_command=""
_remaind_presence_started_s=0
_remaind_presence_in_hook=0
_remaind_presence_preexec() {
  [[ "$_remaind_presence_in_hook" == "1" ]] && return 0
  case "$BASH_COMMAND" in
    _remaind_presence_*|remaind\\ daemon\\ observe*|remaind\\ daemon\\ status*) return 0 ;;
  esac
  _remaind_presence_last_command="$BASH_COMMAND"
  _remaind_presence_started_s="$(date +%s 2>/dev/null || echo 0)"
}
_remaind_presence_prompt() {
  local exit_code="$?"
  _remaind_presence_in_hook=1
  if [[ -n "$_remaind_presence_last_command" ]]; then
    local now_s duration_ms
    now_s="$(date +%s 2>/dev/null || echo "$_remaind_presence_started_s")"
    duration_ms=$(( (now_s - _remaind_presence_started_s) * 1000 ))
    remaind daemon observe --cwd "$PWD" --command "$_remaind_presence_last_command" --exit-code "$exit_code" --duration-ms "$duration_ms" >/dev/null 2>&1 || true
    _remaind_presence_last_command=""
  fi
  local message
  message="$(remaind daemon status --short --cwd "$PWD" 2>/dev/null)" || message=""
  [[ -n "$message" ]] && printf '%s\\n' "$message"
  _remaind_presence_in_hook=0
}
trap _remaind_presence_preexec DEBUG
PROMPT_COMMAND="_remaind_presence_prompt${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
"""
    return """# Remaind presence hook for fish.
set -g _remaind_presence_last_command ""
set -g _remaind_presence_started_s 0
function _remaind_presence_preexec --on-event fish_preexec
    set -g _remaind_presence_last_command $argv[1]
    set -g _remaind_presence_started_s (date +%s 2>/dev/null; or echo 0)
end
function _remaind_presence_postexec --on-event fish_postexec
    set exit_code $status
    if test -n "$_remaind_presence_last_command"
        set now_s (date +%s 2>/dev/null; or echo $_remaind_presence_started_s)
        set duration_ms (math "($now_s - $_remaind_presence_started_s) * 1000")
        remaind daemon observe --cwd "$PWD" --command "$_remaind_presence_last_command" --exit-code "$exit_code" --duration-ms "$duration_ms" >/dev/null 2>&1; or true
        set -g _remaind_presence_last_command ""
    end
end
function _remaind_presence_prompt --on-event fish_prompt
    set message (remaind daemon status --short --cwd "$PWD" ^/dev/null)
    test -n "$message"; and echo "$message"
end
"""


def _default_rc_file(shell: Literal["zsh", "bash", "fish"]) -> Path:
    if shell == "zsh":
        return Path.home() / ".zshrc"
    if shell == "bash":
        return Path.home() / ".bashrc"
    return Path.home() / ".config" / "fish" / "config.fish"


def install_shell_hook(
    shell: Literal["zsh", "bash", "fish"],
    *,
    rc_file: Path | None = None,
) -> ShellHookInstallResult:
    """Install the presence hook into a shell startup file idempotently."""

    target = (rc_file or _default_rc_file(shell)).expanduser()
    start = "# >>> remaind presence hook >>>"
    end = "# <<< remaind presence hook <<<"
    hook = shell_init(shell).rstrip()
    block = f"{start}\n{hook}\n{end}\n"
    try:
        current = target.read_text(encoding="utf-8") if target.exists() else ""
    except OSError as exc:
        raise DaemonError(f"could not read shell rc file {target}: {exc}") from exc
    if start in current and end in current:
        before, rest = current.split(start, 1)
        _old_block, after = rest.split(end, 1)
        prefix = before.rstrip()
        next_content = (prefix + "\n\n" if prefix else "") + block + after.lstrip("\n")
    else:
        separator = "\n\n" if current.strip() else ""
        next_content = current.rstrip() + separator + block
    changed = next_content != current
    if changed:
        try:
            atomic_write_text(target, next_content)
        except OSError as exc:
            raise DaemonError(f"could not write shell rc file {target}: {exc}") from exc
    return ShellHookInstallResult(shell=shell, rc_file=str(target), changed=changed)
