"""`remaind status` and `remaind status --json`.

Combines the on-disk derived state with computed observations of
``events.jsonl`` (event count, malformed-line count, raw bytes) and the
current threshold band math. Outputs either a human-readable report or a
JSON document suitable for ``jq`` consumption.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .._compaction import compute_compaction_status
from .._errors import RemaindError
from .._jsonl import iter_jsonl
from .._paths import ContextPaths
from .._plan_reconciliation import load_plan_reconciliation
from .._thresholds import compute_bands, load_default_profile


class StatusError(RemaindError):
    """Raised when status cannot read the active state."""


def _events_summary(paths: ContextPaths) -> dict[str, int]:
    count = 0
    malformed = 0
    if paths.events_jsonl.is_file():
        for _lineno, obj, err in iter_jsonl(paths.events_jsonl):
            if err is None and obj is not None:
                count += 1
            else:
                malformed += 1
        raw_bytes = paths.events_jsonl.stat().st_size
    else:
        raw_bytes = 0
    return {
        "count": count,
        "malformed_lines": malformed,
        "raw_log_bytes": raw_bytes,
    }


def build_status_payload(base: Path) -> dict[str, Any]:
    paths = ContextPaths.at(Path(base))
    if not paths.state_json.is_file():
        raise StatusError(f"state.json not found at {paths.state_json}")
    try:
        state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise StatusError(f"state.json is unparseable: {exc}") from exc

    bands = compute_bands(load_default_profile(paths.thresholds_yaml))
    payload = dict(state)
    payload["events"] = _events_summary(paths)
    payload["thresholds"] = asdict(bands)
    compaction = compute_compaction_status(state, bands)
    payload["compaction"] = {
        "needed": compaction.compaction_needed,
        "urgent": compaction.compaction_urgent,
        "recommendation": compaction.recommendation,
    }
    reconciliation = load_plan_reconciliation(base)
    if reconciliation:
        payload["plan_reconciliation"] = {
            "current_development_plan_focus": reconciliation.get(
                "current_development_plan_focus"
            ),
            "plan_status_and_progress": reconciliation.get("plan_status_and_progress"),
            "error_or_blocker": reconciliation.get("error_or_blocker"),
            "incomplete_task_due_to_blocker": reconciliation.get(
                "incomplete_task_due_to_blocker"
            ),
            "aligned_next_plan_step": reconciliation.get("aligned_next_plan_step"),
            "updated_at": reconciliation.get("updated_at"),
        }
    return payload


def _format_list(label: str, items: list[str]) -> list[str]:
    if not items:
        return [f"{label}: (none)"]
    lines = [f"{label} ({len(items)}):"]
    for item in items:
        lines.append(f"  - {item}")
    return lines


def render_human(payload: dict[str, Any]) -> str:
    rows: list[str] = []
    rows.append(f"session_id: {payload['session_id']}")
    rows.append(f"task_id:    {payload['task_id']}")
    rows.append("")
    rows.append(f"Goal:        {payload['current_goal']}")
    rows.append(f"Active task: {payload['active_task']}")
    rows.append(f"Status:      {payload['status']}")
    rows.append(f"Next step:   {payload['next_step']}")
    rows.append("")
    tokens = payload["estimated_context_tokens"]
    band = payload["threshold_band"]
    rows.append(f"Tokens:      {tokens} (band={band})")
    t = payload["thresholds"]
    rows.append(
        f"Thresholds:  required={t['required']}  "
        f"warn={t['warning']}  hard={t['hard']}  emerg={t['emergency']}"
    )
    comp = payload["compaction"]
    flag = "URGENT" if comp["urgent"] else ("needed" if comp["needed"] else "no")
    rows.append(f"Compaction:  {flag} — {comp['recommendation']}")
    rows.append("")
    e = payload["events"]
    rows.append(
        f"Events:                 {e['count']} "
        f"({e['raw_log_bytes']} bytes; {e['malformed_lines']} malformed)"
    )
    rows.append(
        f"Latest user instruction: "
        f"{payload['latest_user_instruction_event_id'] or '(none)'}"
    )
    rows.append(
        f"Last compaction:         "
        f"{payload['last_compaction_event_id'] or '(none)'}"
    )
    rows.append(
        f"Last validation:         "
        f"{payload['last_validation_event_id'] or '(none)'}"
    )
    rows.append("")
    rows.extend(_format_list("Blockers", payload["open_blockers"]))
    reconciliation = payload.get("plan_reconciliation")
    if isinstance(reconciliation, dict):
        rows.append("")
        rows.append("Plan reconciliation:")
        rows.append(
            "  Focus: "
            f"{reconciliation.get('current_development_plan_focus') or '(none)'}"
        )
        rows.append(
            "  Progress: "
            f"{reconciliation.get('plan_status_and_progress') or '(none)'}"
        )
        rows.append(
            "  Blocker: "
            f"{reconciliation.get('error_or_blocker') or '(none)'}"
        )
        rows.append(
            "  Next: "
            f"{reconciliation.get('aligned_next_plan_step') or '(none)'}"
        )
    rows.append("")
    rows.extend(_format_list("Decisions", payload["decisions"]))
    rows.append("")
    rows.extend(_format_list("Files touched", payload["files_touched"]))
    rows.append("")
    rows.append(f"Updated: {payload['updated_at']}")
    return "\n".join(rows) + "\n"


def run(base: Path, *, as_json: bool = False) -> str:
    payload = build_status_payload(base)
    if as_json:
        return json.dumps(payload, indent=2) + "\n"
    return render_human(payload)
