"""`remaind continuity` — scorecards, evidence maps, and adapter exports."""

from __future__ import annotations

import json
from pathlib import Path

from .._continuity import (
    AdapterExportResult,
    ContinuityError,
    ContinuityScorecard,
    EvidenceLink,
    build_continuity_scorecard,
    build_evidence_map,
    export_adapters,
    render_evidence_map,
    render_scorecard,
)

__all__ = [
    "AdapterExportResult",
    "ContinuityError",
    "ContinuityScorecard",
    "EvidenceLink",
    "run_evidence",
    "run_export",
    "run_scorecard",
    "render_evidence_result",
    "render_export_result",
    "render_scorecard_result",
]


def run_scorecard(base: Path) -> ContinuityScorecard:
    return build_continuity_scorecard(base)


def render_scorecard_result(
    result: ContinuityScorecard,
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    return render_scorecard(result)


def run_evidence(base: Path) -> list[EvidenceLink]:
    return build_evidence_map(base)


def render_evidence_result(
    result: list[EvidenceLink],
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(
            [link.to_dict() for link in result],
            indent=2,
            sort_keys=True,
        ) + "\n"
    return render_evidence_map(result)


def run_export(
    base: Path,
    *,
    targets: list[str] | None = None,
    output_dir: Path | None = None,
) -> AdapterExportResult:
    return export_adapters(base, targets=targets, output_dir=output_dir)


def render_export_result(
    result: AdapterExportResult,
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    rows = [
        f"Continuity adapters written to {result.output_dir}",
        "",
    ]
    rows.extend(f"- {path}" for path in result.files)
    rows.append("")
    return "\n".join(rows)
