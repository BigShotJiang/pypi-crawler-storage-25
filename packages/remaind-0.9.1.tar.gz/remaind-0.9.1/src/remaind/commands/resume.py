"""`remaind resume` — build the resume packet for a fresh agent run.

Writes ``active/resume_packet.md`` atomically (with a history snapshot under
``active/history/resume_packet/``) and appends a ``resume`` event recording
what was assembled and what the gate found.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .._atomic import atomic_write_text
from .._errors import RemaindError
from .._events import EventInput, EventWriter
from .._paths import ContextPaths
from .._resume_packet import ResumePacket, build_resume_packet


@dataclass(frozen=True)
class ResumeResult:
    packet: ResumePacket
    resume_event_id: str
    history_path: Path | None


class ResumeError(RemaindError):
    """Raised when a resume packet cannot be built."""


def run(
    base: Path,
    *,
    next_tool: str | None = None,
    k_memories: int = 5,
    raw_excerpt_count: int = 20,
) -> ResumeResult:
    base = Path(base)
    paths = ContextPaths.at(base)
    if not paths.state_json.is_file():
        raise ResumeError(
            f"no .context/ found at {base} — run `remaind init` first"
        )
    packet = build_resume_packet(
        base,
        k_memories=k_memories,
        raw_excerpt_count=raw_excerpt_count,
        next_tool=next_tool,
    )

    history_dir = paths.history_dir / "resume_packet"
    history_path = atomic_write_text(
        paths.resume_packet, packet.content, history_dir=history_dir
    )

    state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    writer = EventWriter.open(base)
    event = writer.append(
        EventInput(
            type="resume",
            actor="remaind resume",
            summary=(
                f"Built resume packet — "
                f"{packet.token_count}/{packet.token_cap} tokens, "
                f"{len(packet.included_memory_ids)} memories, "
                f"{len(packet.included_event_ids)} raw excerpts, "
                f"gate {'INTERRUPT' if packet.gate.should_interrupt else 'ok'}"
            ),
            session_id=state["session_id"],
            task_id=state["task_id"],
            content=None,
            importance=1,
            tags=["resume"],
            source="remaind resume",
            source_event_ids=list(packet.included_event_ids),
            metadata={
                "token_count": packet.token_count,
                "token_cap": packet.token_cap,
                "memory_count": len(packet.included_memory_ids),
                "raw_excerpt_count": len(packet.included_event_ids),
                "gate_should_interrupt": packet.gate.should_interrupt,
                "gate_urgent": packet.gate.urgent,
                "gate_concerns_count": len(packet.gate.concerns),
                "next_tool": next_tool,
                "exceeded_cap": packet.exceeded_cap,
            },
        )
    )

    return ResumeResult(
        packet=packet,
        resume_event_id=event["id"],
        history_path=history_path,
    )
