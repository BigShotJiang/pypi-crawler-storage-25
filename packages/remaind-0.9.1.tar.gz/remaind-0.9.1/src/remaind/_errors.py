"""Shared exception hierarchy for Remaind."""

from __future__ import annotations


class RemaindError(Exception):
    """Base class for all Remaind-specific errors.

    Catch this when a caller needs one stable boundary for product-level
    failures while preserving the more specific exception classes.
    """

