"""Shared recommendation judgment helpers for Remaind context packets.

The benchmark bridge and product launch flows both need the same behavior:
recommendations should honor current constraints instead of choosing the most
generic topical fit. This module keeps that logic in one place so ordinary
memory answers and public-benchmark packets cannot drift apart.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

from ._polarity_vocab import classify_polarity

_STOPWORDS = {
    "about",
    "after",
    "again",
    "also",
    "and",
    "are",
    "away",
    "best",
    "better",
    "could",
    "currently",
    "event",
    "fit",
    "for",
    "from",
    "have",
    "into",
    "large",
    "like",
    "more",
    "most",
    "new",
    "next",
    "now",
    "option",
    "recommend",
    "recommendation",
    "should",
    "some",
    "that",
    "the",
    "this",
    "though",
    "try",
    "user",
    "what",
    "with",
    "would",
    "you",
    "your",
}


@dataclass(frozen=True)
class RecommendationConstraintFamily:
    key: str
    label: str
    evidence_markers: tuple[str, ...]
    option_conflicts: tuple[str, ...]
    option_matches: tuple[str, ...]


@dataclass(frozen=True)
class RecommendationTieBreaker:
    score_adjustment: float
    conflicts: tuple[str, ...]
    matches: tuple[str, ...]
    recent_positive_terms: tuple[str, ...]
    reasons: tuple[str, ...]
    decision_signal: str


RECOMMENDATION_CONSTRAINT_FAMILIES = (
    RecommendationConstraintFamily(
        key="avoid_crowds",
        label="crowd/overwhelm",
        evidence_markers=(
            "avoid crowds",
            "away from crowds",
            "crowded",
            "crowds",
            "large groups",
            "too many people",
            "overwhelming",
            "overstimulating",
            "busy settings",
            "packed",
        ),
        option_conflicts=(
            "crowded",
            "large crowd",
            "large festival",
            "big festival",
            "big event",
            "packed",
            "busy venue",
            "overwhelming",
            "large-scale",
            "large scale",
        ),
        option_matches=(
            "away from crowds",
            "uncrowded",
            "small",
            "intimate",
            "quiet",
            "cozy",
            "boutique",
            "at your own pace",
            "self-paced",
        ),
    ),
    RecommendationConstraintFamily(
        key="avoid_rigidity",
        label="rigidity/structure",
        evidence_markers=(
            "rigid",
            "too structured",
            "structured format",
            "strict",
            "formal",
            "formulaic",
            "inflexible",
            "fixed schedule",
            "rigidity",
        ),
        option_conflicts=(
            "rigid",
            "structured",
            "formal",
            "strict",
            "fixed schedule",
            "set schedule",
            "curriculum",
            "club",
            "membership",
            "class",
        ),
        option_matches=(
            "flexible",
            "casual",
            "self-guided",
            "open-ended",
            "loose",
            "at your own pace",
            "drop-in",
        ),
    ),
    RecommendationConstraintFamily(
        key="avoid_pressure",
        label="pressure/performance",
        evidence_markers=(
            "pressure",
            "pressured",
            "stressful",
            "competitive",
            "performative",
            "obligation",
            "commitment",
            "draining",
            "chore",
        ),
        option_conflicts=(
            "competitive",
            "competition",
            "contest",
            "performance",
            "performative",
            "commitment",
            "obligation",
            "public",
            "showcase",
            "challenge",
            "team",
        ),
        option_matches=(
            "low-pressure",
            "low pressure",
            "relaxed",
            "private",
            "gentle",
            "no pressure",
            "self-paced",
            "informal",
        ),
    ),
    RecommendationConstraintFamily(
        key="prefer_intimacy",
        label="intimacy/scale",
        evidence_markers=(
            "intimate",
            "small",
            "small group",
            "one-on-one",
            "cozy",
            "boutique",
            "quiet",
            "low-key",
            "local artists",
            "at my own pace",
        ),
        option_conflicts=(
            "large",
            "large-scale",
            "large scale",
            "big festival",
            "crowded",
            "massive",
            "busy",
            "group class",
            "community event",
        ),
        option_matches=(
            "intimate",
            "small",
            "one-on-one",
            "cozy",
            "boutique",
            "quiet",
            "low-key",
            "local",
            "at your own pace",
        ),
    ),
    RecommendationConstraintFamily(
        key="avoid_group_commitment",
        label="group/commitment",
        evidence_markers=(
            "avoid group",
            "don't want to join",
            "do not want to join",
            "group felt",
            "collaboration conflict",
            "disagreements",
            "stifled",
            "working with others",
            "membership",
        ),
        option_conflicts=(
            "join",
            "group",
            "club",
            "class",
            "membership",
            "collaboration",
            "team",
            "community",
        ),
        option_matches=(
            "solo",
            "self-guided",
            "independent",
            "one-on-one",
            "private",
            "at your own pace",
        ),
    ),
)

_RECENCY_MARKERS = (
    "recently",
    "lately",
    "now",
    "currently",
    "these days",
    "newer",
    "latest",
    "after",
    "started",
    "stopped",
    "decided",
    "switched",
    "no longer",
)

_RECOMMENDATION_REQUEST_MARKERS = (
    "recommend",
    "recommendation",
    "suggest",
    "suggestion",
    "what should i",
    "what should we",
    "what would fit",
    "what fits",
    "which option",
    "best option",
    "better option",
    "next step",
)


def looks_like_recommendation_request(question: str) -> bool:
    """Return true when a user asks Remaind to choose or recommend a path."""

    lowered = question.lower()
    return _contains_any(lowered, _RECOMMENDATION_REQUEST_MARKERS)


def recommendation_tie_breaker(
    option_text: str,
    evidence_texts: Sequence[str],
) -> RecommendationTieBreaker:
    """Score one candidate recommendation against source-backed constraints."""

    active_constraints = active_recommendation_constraints(evidence_texts)
    conflicts = _option_constraint_conflicts(option_text, active_constraints)
    matches = _option_constraint_matches(option_text, active_constraints)
    recent_terms = recent_positive_evidence_terms(evidence_texts)
    option_terms = set(important_recommendation_terms(option_text))
    recent_hits = tuple(sorted(option_terms & recent_terms)[:5])
    score_adjustment = 0.0
    reasons: list[str] = []
    if conflicts:
        score_adjustment -= 7.0 * len(conflicts)
        reasons.extend(f"recommendation conflict: {key}" for key in conflicts)
    if matches:
        score_adjustment += 3.5 * len(matches)
        reasons.extend(f"constraint fit: {key}" for key in matches)
    if recent_hits:
        score_adjustment += min(3.0, 0.75 * len(recent_hits))
        reasons.append("recent positive preference match")
    if conflicts:
        decision_signal = "penalize disclosed conflict with current constraints"
    elif matches:
        decision_signal = "reward explicit fit with current constraints"
    elif recent_hits:
        decision_signal = "reward match to recent positive evidence"
    else:
        decision_signal = "no decisive recommendation tie-breaker"
    return RecommendationTieBreaker(
        score_adjustment=score_adjustment,
        conflicts=tuple(conflicts),
        matches=tuple(matches),
        recent_positive_terms=recent_hits,
        reasons=tuple(reasons),
        decision_signal=decision_signal,
    )


def recommendation_tie_breaker_adjustment(
    option_text: str,
    evidence_texts: Sequence[str],
) -> tuple[float, list[str]] | None:
    """Return a scorer adjustment compatible with benchmark option scoring."""

    result = recommendation_tie_breaker(option_text, evidence_texts)
    if result.score_adjustment == 0.0:
        return None
    return result.score_adjustment, list(result.reasons)


def recommendation_tie_breaker_summaries(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, str]:
    """Render compact per-option summaries for an evidence packet."""

    summaries: dict[str, str] = {}
    for letter, option_text in options:
        result = recommendation_tie_breaker(option_text, evidence_texts)
        conflict_text = ", ".join(result.conflicts) if result.conflicts else "none"
        match_text = ", ".join(result.matches) if result.matches else "none"
        recency_text = (
            ", ".join(result.recent_positive_terms)
            if result.recent_positive_terms
            else "none"
        )
        summaries[letter] = (
            f"constraint_conflicts={conflict_text}; "
            f"constraint_matches={match_text}; "
            f"recency_hits={recency_text}; "
            f"decision_signal={result.decision_signal}"
        )
    return summaries


def render_recommendation_judgment_section(
    question: str,
    evidence_texts: Sequence[str],
    *,
    options: Sequence[tuple[str, str]] = (),
) -> str:
    """Render product-facing recommendation rules grounded in loaded evidence."""

    if not looks_like_recommendation_request(question):
        return ""
    active_constraints = active_recommendation_constraints(evidence_texts)
    recent_terms = sorted(recent_positive_evidence_terms(evidence_texts))[:12]
    rows = [
        "## Recommendation Judgment",
        "",
        (
            "Use this section when the answer recommends, chooses, prioritizes, "
            "or suggests a next path."
        ),
        (
            "Rule: current constraints and explicit dislikes outrank generic "
            "topic fit. Penalize options that admit crowding, rigidity, pressure, "
            "oversized scale, or unwanted group commitment when those conditions "
            "appear in the evidence."
        ),
        "",
    ]
    if active_constraints:
        rows.append("Active constraint families found in loaded evidence:")
        for family in active_constraints:
            rows.append(f"- {family.key}: {family.label}")
    else:
        rows.append("Active constraint families found in loaded evidence: none")
    if recent_terms:
        rows.append("Recent positive evidence terms: " + ", ".join(recent_terms))
    if options:
        rows.append("")
        rows.append("Candidate recommendation tie-breakers:")
        summaries = recommendation_tie_breaker_summaries(options, evidence_texts)
        for letter, _option_text in options:
            rows.append(f"- ({letter}) {summaries[letter]}")
    rows.append("")
    return "\n".join(rows)


def active_recommendation_constraints(
    evidence_texts: Sequence[str],
) -> tuple[RecommendationConstraintFamily, ...]:
    evidence = " ".join(evidence_texts).lower()
    return tuple(
        family
        for family in RECOMMENDATION_CONSTRAINT_FAMILIES
        if _contains_any(evidence, family.evidence_markers)
    )


def recent_positive_evidence_terms(evidence_texts: Sequence[str]) -> set[str]:
    terms: set[str] = set()
    for text in evidence_texts:
        lowered = text.lower()
        if not _contains_any(lowered, _RECENCY_MARKERS):
            continue
        if classify_polarity(lowered) == "negative":
            continue
        terms.update(important_recommendation_terms(lowered))
    return terms


def important_recommendation_terms(text: str) -> list[str]:
    values = [
        match.group(0).lower()
        for match in re.finditer(r"[a-z][a-z0-9_-]{2,}", text.lower())
    ]
    return [
        value
        for value in values
        if value not in _STOPWORDS and not value.isdigit()
    ]


def _option_constraint_conflicts(
    option_text: str,
    active_constraints: tuple[RecommendationConstraintFamily, ...],
) -> list[str]:
    option = option_text.lower()
    return [
        family.key
        for family in active_constraints
        if _recommendation_option_conflicts_family(option, family)
    ]


def _option_constraint_matches(
    option_text: str,
    active_constraints: tuple[RecommendationConstraintFamily, ...],
) -> list[str]:
    option = option_text.lower()
    return [
        family.key
        for family in active_constraints
        if _contains_any(option, family.option_matches)
    ]


def _contains_any(text: str, markers: Sequence[str]) -> bool:
    return any(marker in text for marker in markers)


def _recommendation_option_conflicts_family(
    option: str,
    family: RecommendationConstraintFamily,
) -> bool:
    if _contains_any(option, family.option_conflicts):
        return True
    if family.key == "avoid_crowds" and "large" in option and any(
        marker in option for marker in ("festival", "event", "venue", "group")
    ):
        return True
    return False
