"""Terminal-backed access to large local documents.

The large-document layer is intentionally simple: Remaind stores a durable
manifest, event, and memory pointer, while the source document stays at its
original local path. Agents can then search or slice exact lines through the
terminal instead of asking an agent UI to load a file that exceeds its reader
limit or a model's live context window.
"""

from __future__ import annotations

import hashlib
import json
import re
import shlex
from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._db import Memory, insert_memory, open_db
from ._errors import RemaindError
from ._events import EventInput, EventWriter
from ._paths import ContextPaths
from ._timestamps import utc_now_iso
from ._ulid import new_memory_id

LARGE_DOC_TAG = "large_doc"
LARGE_DOC_BRIDGE_TAG = "large_doc_bridge"
MAX_EVENT_CONTENT_CHARS = 12_000

_SEARCH_TOKEN_RE = re.compile(r"[A-Za-z0-9_:/.-]+")


class LargeDocumentError(RemaindError):
    """Raised when a large-document operation cannot complete safely."""


@dataclass(frozen=True)
class LargeDocumentStats:
    """Metadata for a source document registered with Remaind."""

    path: str
    doc_id: str
    sha256: str
    bytes: int
    lines: int
    title: str
    manifest_path: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LargeDocumentIngestResult:
    """Result of registering a large document."""

    stats: LargeDocumentStats
    source_event_id: str
    memory_id: str
    manifest_path: str

    def to_dict(self) -> dict[str, Any]:
        data = self.stats.to_dict()
        data.update(
            {
                "indexed": True,
                "source_event_id": self.source_event_id,
                "memory_id": self.memory_id,
                "manifest_path": self.manifest_path,
            }
        )
        return data


@dataclass(frozen=True)
class LargeDocumentSearchHit:
    """One line match plus nearby context."""

    line: int
    text: str
    context: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {"line": self.line, "text": self.text, "context": self.context}


@dataclass(frozen=True)
class LargeDocumentSearchResult:
    """Search results from a large local document."""

    path: str
    query: str
    match_mode: str
    hit_count: int
    max_results: int
    may_have_more: bool
    hits: list[LargeDocumentSearchHit]
    integrity: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "path": self.path,
            "query": self.query,
            "match_mode": self.match_mode,
            "hit_count": self.hit_count,
            "max_results": self.max_results,
            "may_have_more": self.may_have_more,
            "hits": [hit.to_dict() for hit in self.hits],
        }
        if self.integrity is not None:
            out["integrity"] = self.integrity
        return out


@dataclass(frozen=True)
class LargeDocumentLinesResult:
    """Exact line rows returned by slice/head/tail."""

    path: str
    mode: str
    lines: list[dict[str, Any]]
    start: int | None = None
    end: int | None = None
    integrity: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "path": self.path,
            "mode": self.mode,
            "lines": self.lines,
        }
        if self.start is not None:
            out["start"] = self.start
        if self.end is not None:
            out["end"] = self.end
        if self.integrity is not None:
            out["integrity"] = self.integrity
        return out


def _resolve_existing_file(path: Path) -> Path:
    resolved = Path(path).expanduser().resolve()
    if not resolved.exists():
        raise LargeDocumentError(f"file does not exist: {resolved}")
    if not resolved.is_file():
        raise LargeDocumentError(f"path is not a file: {resolved}")
    return resolved


def _iter_lines(path: Path) -> Iterable[tuple[int, str]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            for number, line in enumerate(handle, start=1):
                yield number, line.rstrip("\r\n")
    except UnicodeDecodeError as exc:
        raise LargeDocumentError(
            f"{path}: invalid UTF-8 at byte {exc.start}; convert the file to UTF-8 "
            "before ingesting it"
        ) from exc


def _slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-._")
    return slug[:80] or "document"


def _doc_id(path: Path, digest: str) -> str:
    return f"{_slug(path.stem)}-{digest[:12]}"


def _title(path: Path, explicit: str | None = None) -> str:
    if explicit:
        return explicit
    for _, line in _iter_lines(path):
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("#").strip() or path.name
        if stripped:
            return stripped[:120]
    return path.name


def large_document_stats(
    base: Path, document_path: Path, *, title: str | None = None
) -> LargeDocumentStats:
    """Return deterministic metadata for ``document_path`` under ``base``."""

    base = Path(base).expanduser().resolve()
    path = _resolve_existing_file(document_path)

    h = hashlib.sha256()
    line_count = 0
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
            line_count += chunk.count(b"\n")
    digest = h.hexdigest()
    size = path.stat().st_size
    if size:
        with path.open("rb") as handle:
            handle.seek(-1, 2)
            if handle.read(1) != b"\n":
                line_count += 1

    doc_id = _doc_id(path, digest)
    manifest_path = ContextPaths.at(base).large_docs_dir / doc_id / "manifest.json"
    return LargeDocumentStats(
        path=str(path),
        doc_id=doc_id,
        sha256=digest,
        bytes=size,
        lines=line_count,
        title=_title(path, title),
        manifest_path=str(manifest_path),
    )


def _sample(path: Path, *, head: int = 30, tail: int = 30) -> dict[str, Any]:
    head_lines: list[dict[str, Any]] = []
    ring: deque[dict[str, Any]] = deque(maxlen=tail)
    for number, text in _iter_lines(path):
        item = {"line": number, "text": text}
        if len(head_lines) < head:
            head_lines.append(item)
        ring.append(item)
    return {"head": head_lines, "tail": list(ring)}


def _json(data: dict[str, Any]) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


def _shell_quote(value: str | Path) -> str:
    return shlex.quote(str(value))


def _load_session_ids(base: Path) -> tuple[str, str]:
    paths = ContextPaths.at(base)
    if not paths.state_json.is_file():
        raise LargeDocumentError(
            f"state.json not found at {paths.state_json}; run `remaind init` first"
        )
    try:
        state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise LargeDocumentError(f"state.json is unparseable: {exc}") from exc
    session_id = str(state.get("session_id") or "")
    task_id = str(state.get("task_id") or "")
    if not session_id or not task_id:
        raise LargeDocumentError("state.json is missing session_id or task_id")
    return session_id, task_id


def _manifest_payload(base: Path, stats: LargeDocumentStats) -> dict[str, Any]:
    quoted_base = _shell_quote(base)
    quoted_path = _shell_quote(stats.path)
    return {
        **stats.to_dict(),
        "commands": {
            "ingest": f"remaind large-doc ingest {quoted_path} --path {quoted_base}",
            "search": (
                f"remaind large-doc search {quoted_path} 'QUERY' "
                f"--path {quoted_base} --verify"
            ),
            "slice": (
                f"remaind large-doc slice {quoted_path} --start START --end END "
                f"--path {quoted_base} --verify"
            ),
            "head": (
                f"remaind large-doc head {quoted_path} --lines 80 "
                f"--path {quoted_base} --verify"
            ),
            "tail": (
                f"remaind large-doc tail {quoted_path} --lines 80 "
                f"--path {quoted_base} --verify"
            ),
            "run": f"remaind run {quoted_path} 'TASK' --path {quoted_base}",
        },
        "notes": [
            "The source file is not copied into .context/.",
            "Use search/slice/head/tail for exact terminal-backed evidence.",
            "Use remaind run FILE 'TASK' to execute a task through a compact evidence packet.",
        ],
    }


def _write_manifest(base: Path, stats: LargeDocumentStats) -> Path:
    manifest = Path(stats.manifest_path)
    payload = _manifest_payload(base, stats)
    atomic_write_text(
        manifest,
        _json(payload) + "\n",
        history_dir=manifest.parent / "history",
    )
    return manifest


def _memory_content(base: Path, stats: LargeDocumentStats) -> str:
    quoted_base = _shell_quote(base)
    quoted_path = _shell_quote(stats.path)
    return (
        f"Large local document indexed for terminal-backed sovereign access. "
        f"Title: {stats.title}. Path: {stats.path}. Doc ID: {stats.doc_id}. "
        f"Bytes: {stats.bytes}. Lines: {stats.lines}. SHA256: {stats.sha256}. "
        f"Manifest: {stats.manifest_path}. The source file is not copied into "
        ".context/. For files above an agent file-reader limit, retrieve exact "
        "evidence through Remaind: "
        f"cd {quoted_base} && remaind large-doc search {quoted_path} 'QUERY' "
        f"--path {quoted_base} --verify; "
        f"or remaind large-doc slice {quoted_path} --start START --end END "
        f"--path {quoted_base} --verify; "
        f"or remaind run {quoted_path} 'TASK' --path {quoted_base}."
    )


def _make_memory(content: str, *, source_event_ids: list[str], tags: list[str]) -> Memory:
    now = utc_now_iso()
    return Memory(
        id=new_memory_id(),
        memory_type="fact",
        content=content,
        rationale=(
            "Remaind large-doc metadata. Raw document content remains local at "
            "the source path; search and slice commands return exact evidence."
        ),
        confidence=1.0,
        importance=3,
        created_at=now,
        updated_at=now,
        last_accessed_at=now,
        source_event_ids=source_event_ids,
        tags=tags,
    )


def ingest_large_document(
    base: Path, document_path: Path, *, title: str | None = None
) -> LargeDocumentIngestResult:
    """Register a local document and write durable Remaind pointers.

    The source file is not copied into ``.context/``. Remaind records the
    absolute source path, content hash, line count, manifest, event, and memory
    pointer so fresh agents can discover exact search/slice commands.
    """

    base = Path(base).expanduser().resolve()
    path = _resolve_existing_file(document_path)
    session_id, task_id = _load_session_ids(base)
    stats = large_document_stats(base, path, title=title)
    manifest = _write_manifest(base, stats)
    sample = _sample(path)

    event_payload = {
        "large_doc": stats.to_dict(),
        "sample": sample,
        "usage": {
            "search": _manifest_payload(base, stats)["commands"]["search"],
            "slice": _manifest_payload(base, stats)["commands"]["slice"],
        },
    }
    event_content = _json(event_payload)
    if len(event_content) > MAX_EVENT_CONTENT_CHARS:
        event_content = event_content[:MAX_EVENT_CONTENT_CHARS] + "\n...TRUNCATED..."

    writer = EventWriter.open(base)
    event = writer.append(
        EventInput(
            type="tool_result",
            actor="tool:remaind-large-doc",
            summary=f"Indexed large local document: {stats.title}",
            content=event_content,
            session_id=session_id,
            task_id=task_id,
            importance=3,
            tags=[LARGE_DOC_BRIDGE_TAG, LARGE_DOC_TAG, stats.doc_id],
            metadata=stats.to_dict(),
        )
    )

    memory = _make_memory(
        _memory_content(base, stats),
        source_event_ids=[str(event["id"])],
        tags=[LARGE_DOC_BRIDGE_TAG, LARGE_DOC_TAG, stats.doc_id, "manifest"],
    )
    conn = open_db(base)
    try:
        with conn:
            conn.execute(
                "DELETE FROM memories WHERE instr(' ' || tags || ' ', ?) > 0",
                (f" {stats.doc_id} ",),
            )
            insert_memory(conn, memory)
    finally:
        conn.close()

    return LargeDocumentIngestResult(
        stats=stats,
        source_event_id=str(event["id"]),
        memory_id=memory.id,
        manifest_path=str(manifest),
    )


def _manifest_candidates(base: Path, document_path: Path) -> list[tuple[Path, dict[str, Any]]]:
    paths = ContextPaths.at(Path(base).expanduser().resolve())
    if not paths.large_docs_dir.is_dir():
        return []
    target = str(_resolve_existing_file(document_path))
    matches: list[tuple[Path, dict[str, Any]]] = []
    for manifest_path in paths.large_docs_dir.glob("*/manifest.json"):
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if str(manifest.get("path") or "") == target:
            matches.append((manifest_path, manifest))
    matches.sort(key=lambda item: (item[0].stat().st_mtime, str(item[0])), reverse=True)
    return matches


def verify_large_document(
    base: Path, document_path: Path, *, strict: bool = True
) -> dict[str, Any]:
    """Compare a source document against its latest Remaind manifest."""

    base = Path(base).expanduser().resolve()
    path = _resolve_existing_file(document_path)
    candidates = _manifest_candidates(base, path)
    if not candidates:
        message = f"no large-doc manifest found for {path} under {ContextPaths.at(base).large_docs_dir}"
        if strict:
            raise LargeDocumentError(message)
        return {"verified": False, "reason": message, "path": str(path)}

    manifest_path, manifest = candidates[0]
    current = large_document_stats(base, path)
    checks = {
        "sha256": str(manifest.get("sha256") or "") == current.sha256,
        "bytes": int(manifest.get("bytes") or -1) == current.bytes,
        "lines": int(manifest.get("lines") or -1) == current.lines,
    }
    verified = all(checks.values())
    result = {
        "verified": verified,
        "manifest_path": str(manifest_path),
        "path": str(path),
        "doc_id": str(manifest.get("doc_id") or ""),
        "expected_sha256": str(manifest.get("sha256") or ""),
        "current_sha256": current.sha256,
        "expected_bytes": int(manifest.get("bytes") or -1),
        "current_bytes": current.bytes,
        "expected_lines": int(manifest.get("lines") or -1),
        "current_lines": current.lines,
        "checks": checks,
    }
    if strict and not verified:
        raise LargeDocumentError(
            f"large document has changed since ingest: {path} "
            f"(manifest {manifest_path})"
        )
    return result


def _integrity_if_requested(
    base: Path | None, path: Path, *, verify: bool
) -> dict[str, Any] | None:
    if not verify:
        return None
    if base is None:
        raise LargeDocumentError("verify=True requires a Remaind base path")
    return verify_large_document(base, path)


def _query_matchers(query: str) -> list[tuple[str, Callable[[str], bool]]]:
    if query.startswith("/") and query.endswith("/") and len(query) > 2:
        try:
            regex = re.compile(query[1:-1], re.IGNORECASE)
        except re.error as exc:
            raise LargeDocumentError(f"invalid regex query: {exc}") from exc
        return [("regex", lambda text: bool(regex.search(text)))]

    raw_terms = _SEARCH_TOKEN_RE.findall(query)
    terms = [part.lower() for part in raw_terms]
    if not terms:
        raise LargeDocumentError("query has no searchable terms")
    exact = query.lower()
    return [
        ("exact", lambda text: exact in text.lower()),
        ("all_terms", lambda text: all(term in text.lower() for term in terms)),
        ("any_term", lambda text: any(term in text.lower() for term in terms)),
    ]


def _search_with_matcher(
    path: Path,
    matcher: Callable[[str], bool],
    *,
    context: int,
    max_results: int,
) -> list[LargeDocumentSearchHit]:
    if max_results <= 0:
        return []
    context = max(context, 0)
    previous: deque[dict[str, Any]] = deque(maxlen=context)
    pending: list[dict[str, Any]] = []
    hits: list[LargeDocumentSearchHit] = []

    for number, text in _iter_lines(path):
        row = {"line": number, "text": text}
        next_pending: list[dict[str, Any]] = []
        for item in pending:
            item["context"].append(row)
            item["remaining"] -= 1
            if item["remaining"] > 0:
                next_pending.append(item)
        pending = next_pending

        if len(hits) < max_results and matcher(text):
            hit_context = [dict(item) for item in previous]
            hit_context.append(row)
            hits.append(
                LargeDocumentSearchHit(
                    line=number,
                    text=text,
                    context=hit_context,
                )
            )
            if context:
                pending.append({"context": hit_context, "remaining": context})

        previous.append(row)
        if len(hits) >= max_results and not pending:
            break

    return hits


def search_large_document(
    document_path: Path,
    query: str,
    *,
    context: int = 2,
    max_results: int = 12,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentSearchResult:
    """Search a large local document without loading it into model context."""

    path = _resolve_existing_file(document_path)
    integrity = _integrity_if_requested(base, path, verify=verify)
    match_mode = "none"
    hits: list[LargeDocumentSearchHit] = []
    for name, matcher in _query_matchers(query):
        hits = _search_with_matcher(
            path,
            matcher,
            context=context,
            max_results=max_results,
        )
        if hits:
            match_mode = name
            break
    return LargeDocumentSearchResult(
        path=str(path),
        query=query,
        match_mode=match_mode,
        hit_count=len(hits),
        max_results=max_results,
        may_have_more=len(hits) >= max_results and max_results > 0,
        hits=hits,
        integrity=integrity,
    )


def slice_large_document(
    document_path: Path,
    *,
    start: int,
    end: int,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    """Return an exact inclusive line range from a local document."""

    if start < 1 or end < start:
        raise LargeDocumentError("slice requires 1 <= start <= end")
    path = _resolve_existing_file(document_path)
    integrity = _integrity_if_requested(base, path, verify=verify)
    rows = [
        {"line": number, "text": text}
        for number, text in _iter_lines(path)
        if start <= number <= end
    ]
    return LargeDocumentLinesResult(
        path=str(path),
        mode="slice",
        start=start,
        end=end,
        lines=rows,
        integrity=integrity,
    )


def head_large_document(
    document_path: Path,
    *,
    lines: int = 80,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    """Return the first ``lines`` rows from a local document."""

    if lines < 1:
        raise LargeDocumentError("line count must be >= 1")
    path = _resolve_existing_file(document_path)
    integrity = _integrity_if_requested(base, path, verify=verify)
    rows = []
    for number, text in _iter_lines(path):
        rows.append({"line": number, "text": text})
        if len(rows) >= lines:
            break
    return LargeDocumentLinesResult(
        path=str(path), mode="head", lines=rows, integrity=integrity
    )


def tail_large_document(
    document_path: Path,
    *,
    lines: int = 80,
    base: Path | None = None,
    verify: bool = False,
) -> LargeDocumentLinesResult:
    """Return the last ``lines`` rows from a local document."""

    if lines < 1:
        raise LargeDocumentError("line count must be >= 1")
    path = _resolve_existing_file(document_path)
    integrity = _integrity_if_requested(base, path, verify=verify)
    ring: deque[dict[str, Any]] = deque(maxlen=lines)
    for number, text in _iter_lines(path):
        ring.append({"line": number, "text": text})
    return LargeDocumentLinesResult(
        path=str(path),
        mode="tail",
        lines=list(ring),
        integrity=integrity,
    )
