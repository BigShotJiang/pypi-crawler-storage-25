"""Shared state, cache identity, and artifact discovery for deep document compaction."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass
from importlib.resources import files
from pathlib import Path
from typing import Any, Protocol

from ._errors import RemaindError
from ._jsonl import iter_jsonl
from ._paths import ContextPaths
from ._text_model import ModelInfo, TextModelClient

CHUNK_EXTRACT_PROMPT_VERSION = "chunk_extract_v1"
GROUP_REDUCE_PROMPT_VERSION = "group_reduce_v1"
GLOBAL_REDUCE_PROMPT_VERSION = "global_reduce_v1"
DEEP_COMPACTION_RECOMMENDED_TOKENS = 300_000
DEEP_COMPACT_CHUNK_TOKENS_ENV = "REMAIND_DEEP_COMPACT_CHUNK_TOKENS"

AUTHORITY_ORDER = (
    "raw_source_lines",
    "verified_slices_searches",
    "deep_summaries",
    "model_answer",
)
SUPPORT_TYPES = frozenset(
    {"raw_line", "verified_quote", "cross_chunk_synthesis", "summary_only"}
)
PROGRESS_TAG = "deep_compact_progress"


class DocumentCompactionError(RemaindError):
    """Raised when deep document compaction cannot complete safely."""


class DocumentCompactionInterrupted(DocumentCompactionError):
    """Raised when an interrupted deep-compaction run was checkpointed."""


class DocumentTextModel(Protocol):
    @property
    def label(self) -> str:
        ...

    def complete(
        self,
        prompt: str,
        *,
        system: str | None = None,
        json_mode: bool = False,
        max_tokens: int | None = None,
    ) -> str:
        ...

    def describe(self) -> ModelInfo:
        ...


@dataclass(frozen=True)
class DeepCompactionResult:
    doc_id: str
    run_id: str
    run_dir: str
    manifest_path: str
    cache_key: str
    reused: bool
    status: str
    chunks_total: int
    chunks_succeeded: int
    chunks_failed: int
    chunks_quarantined: int
    evidence_block: str
    failures: list[dict[str, Any]]
    quarantined: list[dict[str, Any]]
    reducer_fallbacks: list[str]
    global_summary: dict[str, Any] | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

def prompt_file_hash(version: str) -> str:
    path = files("remaind") / "_templates" / "prompts" / f"{version}.md"
    return hashlib.sha256(path.read_bytes()).hexdigest()

def _prompt(version: str) -> str:
    path = files("remaind") / "_templates" / "prompts" / f"{version}.md"
    return path.read_text(encoding="utf-8")

def _render_prompt(template: str, values: dict[str, Any]) -> str:
    rendered = template
    for key, value in values.items():
        rendered = rendered.replace("{{ " + key + " }}", str(value))
    return rendered

def _model_identity(model: DocumentTextModel | None) -> tuple[str, str, str | None]:
    if model is None:
        client = TextModelClient.from_env()
        if client is None:
            return "none", "none", None
        info = client.describe()
    else:
        describe = getattr(model, "describe", None)
        if callable(describe):
            info = describe()
        else:
            return "injected", str(getattr(model, "label", "injected-model")), None
    return info.kind, info.model, info.api_mode


def _model_from_env_or_injected(model: DocumentTextModel | None) -> DocumentTextModel:
    if os.environ.get("REMAIND_DISABLE_LOCAL_MODEL", "").strip() and model is None:
        raise DocumentCompactionError(
            "deep compaction requires local model calls, but "
            "REMAIND_DISABLE_LOCAL_MODEL is set"
        )
    if model is not None:
        return model
    client = TextModelClient.from_env()
    if client is None:
        raise DocumentCompactionError(
            "deep compaction requires a reachable local model; none was detected"
        )
    return client


def _cache_key(
    *,
    source_hash: str,
    task: str,
    model: DocumentTextModel | None,
    num_ctx: int | None,
    chunk_token_target: int,
) -> str:
    runtime_kind, model_name, api_mode = _model_identity(model)
    prompt_hashes = {
        CHUNK_EXTRACT_PROMPT_VERSION: prompt_file_hash(CHUNK_EXTRACT_PROMPT_VERSION),
        GROUP_REDUCE_PROMPT_VERSION: prompt_file_hash(GROUP_REDUCE_PROMPT_VERSION),
        GLOBAL_REDUCE_PROMPT_VERSION: prompt_file_hash(GLOBAL_REDUCE_PROMPT_VERSION),
    }
    settings = {
        "num_ctx": num_ctx,
        "ollama_temperature": os.environ.get("REMAIND_OLLAMA_TEMPERATURE", ""),
        "ollama_num_predict": os.environ.get("REMAIND_OLLAMA_NUM_PREDICT", ""),
        "openai_temperature": os.environ.get("REMAIND_OPENAI_TEMPERATURE", ""),
        "openai_max_tokens": os.environ.get("REMAIND_OPENAI_MAX_TOKENS", ""),
        "json_mode": True,
        "api_mode": api_mode,
        "chunk_token_target": chunk_token_target,
    }
    payload = {
        "source_hash": source_hash,
        "task_fingerprint": hashlib.sha256(task.strip().encode("utf-8")).hexdigest(),
        "runtime_kind": runtime_kind,
        "model_name": model_name,
        "schema_versions": [
            "chunk_summary_v1",
            "group_summary_v1",
            "global_summary_v1",
        ],
        "prompt_versions": [
            CHUNK_EXTRACT_PROMPT_VERSION,
            GROUP_REDUCE_PROMPT_VERSION,
            GLOBAL_REDUCE_PROMPT_VERSION,
        ],
        "prompt_file_hash": prompt_hashes,
        "extraction_settings": settings,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def _run_root(base: Path, doc_id: str) -> Path:
    return ContextPaths.at(base).large_docs_dir / doc_id / "deep-compactions"

def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None

def _find_cached_run(base: Path, doc_id: str, cache_key: str) -> Path | None:
    root = _run_root(base, doc_id)
    if not root.is_dir():
        return None
    candidates: list[tuple[float, Path]] = []
    for manifest_path in root.glob("*/manifest.json"):
        manifest = _load_json(manifest_path)
        if not manifest:
            continue
        if manifest.get("cache_key") != cache_key:
            continue
        if manifest.get("status") not in {"completed", "partial"}:
            continue
        candidates.append((manifest_path.stat().st_mtime, manifest_path.parent))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1]

def _find_resumable_run(base: Path, doc_id: str, cache_key: str) -> Path | None:
    root = _run_root(base, doc_id)
    if not root.is_dir():
        return None
    candidates: list[tuple[float, Path]] = []
    for manifest_path in root.glob("*/manifest.json"):
        manifest = _load_json(manifest_path)
        if not manifest:
            continue
        if manifest.get("cache_key") != cache_key:
            continue
        if manifest.get("status") not in {"running", "interrupted"}:
            continue
        candidates.append((manifest_path.stat().st_mtime, manifest_path.parent))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1]

def _read_jsonl_objects(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    return [obj for _, obj, err in iter_jsonl(path) if err is None and obj is not None]
