"""Post-ingest reconciliation for Agent Memory Benchmark records."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from pathlib import Path

from ._db import open_db
from ._memory_records import MemoryRecord, upsert_memory_records
from ._polarity_vocab import classify_polarity, extract_topic_tokens


@dataclass(frozen=True)
class AMBReconciliationResult:
    users_scanned: int
    preference_records_scanned: int
    records_changed: int
    supersedes_links: int


def reconcile_amb_preference_records(
    base: Path,
    *,
    user_id: str | None = None,
) -> AMBReconciliationResult:
    """Wire preference supersedes chains after AMB session ingest."""

    from ._memory_records import _row_to_record

    conn = open_db(Path(base))
    try:
        params: list[str] = []
        where = ["kind = ?"]
        params.append("preference")
        if user_id:
            where.append("who = ?")
            params.append(f"user:{user_id}")
        rows = conn.execute(
            f"""
            SELECT *
            FROM memory_records
            WHERE {' AND '.join(where)}
            ORDER BY who, created_at, id
            """,
            tuple(params),
        ).fetchall()
        records = [_row_to_record(conn, row) for row in rows]
    finally:
        conn.close()

    by_user: dict[str, list[MemoryRecord]] = {}
    for record in records:
        by_user.setdefault(record.who, []).append(record)

    changed: dict[str, MemoryRecord] = {}
    supersedes_links = 0
    for user_records in by_user.values():
        prior: list[MemoryRecord] = []
        for record in sorted(user_records, key=_record_chronology_key):
            current_record = changed.get(record.id, record)
            polarity = _record_polarity(current_record)
            tokens = _record_topic_tokens(current_record)
            if polarity == "neutral" or not tokens:
                prior.append(current_record)
                continue

            candidate = _latest_different_polarity_match(
                current_record,
                polarity=polarity,
                tokens=tokens,
                prior_records=[changed.get(item.id, item) for item in prior],
            )
            if candidate is not None:
                supersedes = _append_unique(current_record.supersedes, candidate.id)
                if supersedes != current_record.supersedes:
                    current_record = replace(current_record, supersedes=supersedes)
                    changed[current_record.id] = current_record
                    supersedes_links += 1
                if candidate.status != "superseded":
                    changed[candidate.id] = replace(candidate, status="superseded")
            prior.append(current_record)

    if changed:
        upsert_memory_records(Path(base), list(changed.values()))
    return AMBReconciliationResult(
        users_scanned=len(by_user),
        preference_records_scanned=len(records),
        records_changed=len(changed),
        supersedes_links=supersedes_links,
    )


def _latest_different_polarity_match(
    record: MemoryRecord,
    *,
    polarity: str,
    tokens: set[str],
    prior_records: list[MemoryRecord],
) -> MemoryRecord | None:
    for candidate in reversed(prior_records):
        candidate_polarity = _record_polarity(candidate)
        if candidate_polarity == polarity or candidate_polarity == "neutral":
            continue
        if _topic_sets_match(tokens, _record_topic_tokens(candidate)):
            return candidate
    return None


def _record_polarity(record: MemoryRecord) -> str:
    if "negative" in record.entities or record.status == "stale":
        return "negative"
    if "positive" in record.entities:
        return "positive"
    return classify_polarity(" ".join([record.subject, record.what, record.how]))


def _record_topic_tokens(record: MemoryRecord) -> set[str]:
    return set(extract_topic_tokens(" ".join([record.subject, record.what])))


def _topic_sets_match(left: set[str], right: set[str]) -> bool:
    if not left or not right:
        return False
    shared = left & right
    if len(shared) >= 2:
        return True
    if not shared:
        return False
    token = next(iter(shared))
    return len(token) >= 5 and (len(left) <= 2 or len(right) <= 2)


def _record_chronology_key(record: MemoryRecord) -> tuple[int, int, str, str]:
    document = ""
    if record.sources:
        document = record.sources[0].source_path or record.sources[0].source_id
    document_order = _document_order(document)
    turn_order = _turn_order(record.where_text)
    return (
        document_order if document_order >= 0 else 1_000_000,
        turn_order if turn_order >= 0 else 1_000_000,
        record.created_at,
        record.id,
    )


def _document_order(document: str) -> int:
    match = re.search(r"_(\d+)$", str(document))
    return int(match.group(1)) if match else -1


def _turn_order(where_text: str) -> int:
    match = re.search(r"\bturn:(\d+)\b", str(where_text))
    return int(match.group(1)) if match else -1


def _append_unique(values: tuple[str, ...], value: str) -> tuple[str, ...]:
    out = list(values)
    if value not in out:
        out.append(value)
    return tuple(out)
