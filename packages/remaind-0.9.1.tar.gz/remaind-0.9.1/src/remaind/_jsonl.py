"""Line-by-line JSONL helpers with parse-error reporting."""

from __future__ import annotations

import json
import os
from collections.abc import Iterator
from pathlib import Path


def append_jsonl(path: Path, record: dict) -> None:
    """Append one JSON object to ``path`` and fsync the file.

    Deep document compaction stores rebuildable artifacts as JSONL. Those
    artifacts do not need the event log's chain hashing, but they do need a
    durable append boundary so an interrupted run can resume without silently
    losing the last completed chunk.
    """

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True))
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def iter_jsonl(path: Path) -> Iterator[tuple[int, dict | None, str | None]]:
    """Yield ``(line_number, parsed_object, error_message)`` for each line.

    Blank lines are skipped silently. On parse failure or non-object payload,
    ``parsed_object`` is ``None`` and ``error_message`` describes the problem.
    """
    with path.open("r", encoding="utf-8") as f:
        for lineno, raw in enumerate(f, start=1):
            stripped = raw.strip()
            if not stripped:
                continue
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError as exc:
                yield lineno, None, f"line {lineno}: invalid JSON: {exc.msg}"
                continue
            if not isinstance(obj, dict):
                yield lineno, None, (
                    f"line {lineno}: expected JSON object, "
                    f"got {type(obj).__name__}"
                )
                continue
            yield lineno, obj, None
