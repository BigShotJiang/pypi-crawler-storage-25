"""Durable product-continuation status for crash-safe resume.

Progress snapshots record what Remaind just did. This module turns the latest
snapshot into the product-state facts an operator needs after reopening a
workspace: plan focus, progress, completed work, blockers, incomplete work, and
the next aligned step.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._jsonl import append_jsonl
from ._paths import ContextPaths
from ._timestamps import utc_now_filename_safe_us, utc_now_iso

PRODUCT_STATUS_SCHEMA_VERSION = "1.0.0"

_LIVE_STATUS_MARKERS = (
    "Current live launch status for this answer:",
    "Current terminal conversation before this answer:",
)


def load_product_status(base: Path) -> dict[str, Any] | None:
    """Load the latest durable product status, if it exists and is valid."""

    path = ContextPaths.at(Path(base)).product_status_json
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def update_product_status_from_progress(
    base: Path,
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    """Persist product-continuation status derived from a progress snapshot."""

    paths = ContextPaths.at(Path(base))
    previous = load_product_status(base)
    status = _build_product_status(snapshot, previous=previous)
    atomic_write_text(
        paths.product_status_json,
        json.dumps(status, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "product_status",
    )
    atomic_write_text(
        paths.product_status_md,
        render_product_status(status),
        history_dir=paths.history_dir / "product_status_md",
    )
    append_jsonl(paths.product_status_jsonl, status)
    return status


def ensure_product_status_seed(
    base: Path,
    *,
    workspace_query: str | None = None,
) -> dict[str, Any]:
    """Create the initial product-continuation status if none exists yet.

    Launch can activate a remembered workspace before any new run, handover,
    or model answer has happened. This seed gives continuation questions a
    stable current-state anchor from the first moment memory is active.
    """

    previous = load_product_status(base)
    if previous is not None:
        return previous
    query = clean_product_status_text(workspace_query)
    if query:
        plan_focus = (
            f"Workspace memory was activated for product or workspace '{query}'. "
            "No explicit implementation task has been captured in product "
            "status yet."
        )
    else:
        plan_focus = (
            "Workspace memory is active. No explicit implementation task has "
            "been captured in product status yet."
        )
    status: dict[str, Any] = {
        "schema_version": PRODUCT_STATUS_SCHEMA_VERSION,
        "updated_at": utc_now_iso(),
        "operation_id": f"product_status_seed_{utc_now_filename_safe_us()}",
        "current_development_plan_focus": plan_focus,
        "plan_status_and_progress": (
            "Memory is initialized, but no product implementation progress has "
            "been recorded through Remaind yet. Use the loaded product authority "
            "files, handover, and saved packets to identify the real plan state."
        ),
        "active_task": "",
        "last_two_completed_tasks": [],
        "error_or_blocker": "",
        "incomplete_task_due_to_blocker": "",
        "ready_for_new_instructions": True,
        "fix_instruction": "No active blocker is recorded.",
        "next_step_after_blocker": (
            "No active blocker; proceed with the aligned next plan step."
        ),
        "aligned_next_plan_step": (
            "Review the workspace product plan and continue with the earliest "
            "pending implementation task. If no plan file exists, capture the "
            "product goal and next step in Remaind before implementation starts."
        ),
        "preventive_saving_status": (
            "Active. Remaind created this initial product status when the "
            "workspace memory was activated; subsequent Remaind operations "
            "update it atomically and append history to logs/product_status.jsonl."
        ),
        "packet_path": "",
        "answer_path": "",
        "source": "launch_seed",
        "operation_kind": "launch_seed",
    }
    paths = ContextPaths.at(base)
    atomic_write_text(
        paths.product_status_json,
        json.dumps(status, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "product_status",
    )
    atomic_write_text(
        paths.product_status_md,
        render_product_status(status),
        history_dir=paths.history_dir / "product_status_md",
    )
    append_jsonl(paths.product_status_jsonl, status)
    return status


def update_product_status_from_presence(
    base: Path,
    presence: dict[str, Any],
) -> dict[str, Any]:
    """Persist product-continuation status inferred from shell activity."""

    paths = ContextPaths.at(Path(base))
    previous = load_product_status(base)
    status = _build_product_status_from_presence(presence, previous=previous)
    atomic_write_text(
        paths.product_status_json,
        json.dumps(status, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "product_status",
    )
    atomic_write_text(
        paths.product_status_md,
        render_product_status(status),
        history_dir=paths.history_dir / "product_status_md",
    )
    append_jsonl(paths.product_status_jsonl, status)
    return status


def render_product_status(status: dict[str, Any]) -> str:
    """Render product status as a model-readable Markdown evidence section."""

    rows = [
        "## Product Continuation Status",
        "",
        (
            "This is the latest durable product-state record. Use it with the "
            "workspace's product authority files to answer status, progress, "
            "blocker, continuation, and next-step questions."
        ),
        "",
        "### Current Development Plan Focus",
        "",
        _field(status, "current_development_plan_focus"),
        "",
        "### Plan Status And Progress",
        "",
        _field(status, "plan_status_and_progress"),
        "",
        "### Last Two Completed Tasks",
    ]
    completed = status.get("last_two_completed_tasks")
    if isinstance(completed, list) and completed:
        rows.extend(f"- {item}" for item in completed[:2])
    else:
        rows.append("- (none captured yet)")
    rows.extend(
        [
            "",
            "### Current Blocker",
            "",
            _field(status, "error_or_blocker"),
            "",
            "### Incomplete Task Due To Blocker",
            "",
            _field(status, "incomplete_task_due_to_blocker"),
            "",
            "### Recovery Readiness",
            "",
            (
                "- Ready for new instructions: "
                f"{'yes' if status.get('ready_for_new_instructions') else 'no'}"
            ),
            f"- Fix instruction: {_field(status, 'fix_instruction')}",
            f"- Next step after blocker: {_field(status, 'next_step_after_blocker')}",
            "",
            "### Aligned Next Plan Step",
            "",
            _field(status, "aligned_next_plan_step"),
            "",
            "### Preventive Saving",
            "",
            _field(status, "preventive_saving_status"),
            "",
            "### Evidence",
            "",
            f"- Updated at: {_field(status, 'updated_at')}",
            f"- Operation id: {_field(status, 'operation_id')}",
            f"- Packet path: {_field(status, 'packet_path')}",
            f"- Answer path: {_field(status, 'answer_path')}",
            "",
        ]
    )
    return "\n".join(rows)


def clean_product_status_text(value: object) -> str:
    """Normalize saved status text and remove launch-only prompt wrappers."""

    text = " ".join(str(value or "").strip().split())
    for marker in _LIVE_STATUS_MARKERS:
        if marker in text:
            text = text.split(marker, 1)[0].strip()
    return text


def masks_remaind_artifact_review_step(text: str) -> bool:
    """Return true for Remaind artifact-review steps that are not product work."""

    lowered = text.lower()
    return (
        "review" in lowered
        and ".context" in lowered
        and ("run_answer.md" in lowered or "run_packet.md" in lowered)
    )


def looks_like_memory_question_text(text: str) -> bool:
    """Return true for interactive memory questions, not product tasks."""

    lowered = clean_product_status_text(text).lower()
    if not lowered:
        return False
    prefixes = (
        "current plan progress",
        "project status",
        "product status",
        "status of",
        "what is the status",
        "what's the status",
        "what was the latest progress",
        "what are the next todos",
        "what are the next todo",
    )
    return lowered.endswith("?") or lowered.startswith(prefixes)


def _build_product_status(
    snapshot: dict[str, Any],
    *,
    previous: dict[str, Any] | None,
) -> dict[str, Any]:
    metadata = snapshot.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    operation_kind = clean_product_status_text(metadata.get("operation_kind")) or "run"
    is_memory_question = operation_kind == "memory_question"
    blocked = bool(snapshot.get("error_or_blocker")) or (
        str(snapshot.get("status") or "").lower() == "blocked"
    )
    active_task = clean_product_status_text(snapshot.get("active_task"))
    plan_focus = clean_product_status_text(snapshot.get("development_plan_focus"))
    if is_memory_question:
        plan_focus = _previous_text(
            previous,
            "current_development_plan_focus",
            "No explicit product plan focus captured yet. Use product authority files.",
            reject_memory_question=True,
        )
    if not plan_focus:
        plan_focus = active_task or "No explicit product plan focus captured yet."
    last_completed = _clean_completed_tasks(snapshot.get("last_completed_tasks"))
    if is_memory_question:
        last_completed = _previous_list(previous, "last_two_completed_tasks")
    blocker = clean_product_status_text(snapshot.get("error_or_blocker"))
    incomplete = clean_product_status_text(snapshot.get("incomplete_task_due_to_blocker"))
    next_step = clean_product_status_text(snapshot.get("next_plan_step"))
    if is_memory_question:
        next_step = _previous_text(
            previous,
            "aligned_next_plan_step",
            "Use the loaded product authority files to choose the next plan step.",
        )
    if masks_remaind_artifact_review_step(next_step):
        next_step = "Continue the product plan."
    if not next_step:
        next_step = "Continue the product plan."
    if blocked:
        plan_status = (
            "Blocked. Remaind preserved the latest packet, answer note, and "
            "product status so the incomplete task can be retried after the "
            "blocker is fixed."
        )
        fix_instruction = (
            f"Fix this blocker, then retry the incomplete task: {incomplete or active_task}"
        )
        next_after_blocker = clean_product_status_text(
            snapshot.get("next_step_after_unblock")
        ) or next_step
    else:
        if is_memory_question:
            plan_status = (
                "Answered a memory-state question. This does not mark product "
                "implementation progress complete; use product authority files, "
                "handovers, and explicit saved status for actual plan progress."
            )
        elif str(snapshot.get("phase") or "").lower() == "completed":
            plan_status = (
                "Latest Remaind operation completed and saved its packet/answer. "
                "This does not mean the product plan is complete; continue using "
                "the loaded product authority files for implementation progress."
            )
        else:
            plan_status = clean_product_status_text(snapshot.get("plan_status"))
        if not plan_status:
            plan_status = (
                "No blocker is recorded. Continue in alignment with the loaded "
                "product scope and development plan."
            )
        fix_instruction = "No active blocker is recorded."
        next_after_blocker = "No active blocker; proceed with the aligned next plan step."
        incomplete = ""
        blocker = ""
    return {
        "schema_version": PRODUCT_STATUS_SCHEMA_VERSION,
        "updated_at": clean_product_status_text(snapshot.get("updated_at")),
        "operation_id": clean_product_status_text(snapshot.get("operation_id")),
        "current_development_plan_focus": plan_focus,
        "plan_status_and_progress": plan_status,
        "active_task": active_task,
        "last_two_completed_tasks": last_completed,
        "error_or_blocker": blocker,
        "incomplete_task_due_to_blocker": incomplete,
        "ready_for_new_instructions": True,
        "fix_instruction": fix_instruction,
        "next_step_after_blocker": next_after_blocker,
        "aligned_next_plan_step": next_step,
        "preventive_saving_status": (
            "Active. Remaind writes this product status atomically to "
            "active/product_status.md and active/product_status.json, and "
            "appends each update to logs/product_status.jsonl with fsync."
        ),
        "packet_path": clean_product_status_text(snapshot.get("packet_path")),
        "answer_path": clean_product_status_text(snapshot.get("answer_path")),
        "source": "progress_snapshot",
        "operation_kind": operation_kind,
    }


def _clean_completed_tasks(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    cleaned: list[str] = []
    for item in value:
        text = _normalize_completed_task_text(clean_product_status_text(item))
        if not text or text in cleaned or looks_like_memory_question_text(text):
            continue
        cleaned.append(text)
    return cleaned[-2:]


def _build_product_status_from_presence(
    presence: dict[str, Any],
    *,
    previous: dict[str, Any] | None,
) -> dict[str, Any]:
    command = clean_product_status_text(presence.get("command_preview"))
    exit_code_raw = presence.get("exit_code")
    exit_code = int(exit_code_raw) if isinstance(exit_code_raw, int) else None
    changed_files = presence.get("changed_files")
    changed_count = len(changed_files) if isinstance(changed_files, list) else 0
    failed = exit_code is not None and exit_code != 0
    previous_focus = _previous_text(
        previous,
        "current_development_plan_focus",
        "Use the loaded product authority files.",
        reject_memory_question=True,
    )
    previous_next = _previous_text(
        previous,
        "aligned_next_plan_step",
        "Continue the product plan.",
    )
    if failed:
        blocker = f"Terminal command failed with exit code {exit_code}: {command}"
        incomplete = f"Fix or retry terminal activity: {command}"
        plan_status = (
            "Observed shell activity failed after memory was activated. "
            "Remaind preserved the failure metadata and changed-file summary "
            "so the next instruction can repair the interrupted work."
        )
        fix_instruction = f"Fix the failed terminal command, then retry: {command}"
        next_after_blocker = previous_next
        completed = _previous_list(previous, "last_two_completed_tasks")
        aligned_next = f"Fix the failed terminal command first: {command}"
    else:
        blocker = ""
        incomplete = ""
        if changed_count:
            plan_status = (
                f"Observed shell activity completed and {changed_count} changed "
                "file(s) are present in the workspace. Use the product plan to "
                "decide whether this work completes the current task."
            )
            completed_text = (
                f"Observed successful terminal work: {command} "
                f"({changed_count} changed file(s))"
            )
        else:
            plan_status = (
                "Observed shell activity completed after memory was activated. "
                "No changed files were detected from git status."
            )
            completed_text = f"Observed successful terminal work: {command}"
        completed = _append_recent_task(
            _previous_list(previous, "last_two_completed_tasks"),
            completed_text,
        )
        fix_instruction = "No active blocker is recorded."
        next_after_blocker = "No active blocker; proceed with the aligned next plan step."
        aligned_next = previous_next or "Continue the product plan."
    return {
        "schema_version": PRODUCT_STATUS_SCHEMA_VERSION,
        "updated_at": clean_product_status_text(presence.get("updated_at")),
        "operation_id": clean_product_status_text(presence.get("activity_id")),
        "current_development_plan_focus": previous_focus,
        "plan_status_and_progress": plan_status,
        "active_task": command,
        "last_two_completed_tasks": completed,
        "error_or_blocker": blocker,
        "incomplete_task_due_to_blocker": incomplete,
        "ready_for_new_instructions": True,
        "fix_instruction": fix_instruction,
        "next_step_after_blocker": next_after_blocker,
        "aligned_next_plan_step": aligned_next,
        "preventive_saving_status": (
            "Active. Remaind observed shell activity through the presence layer, "
            "wrote active/presence_snapshot.json, appended logs/presence.jsonl "
            "with fsync, and updated product status atomically."
        ),
        "packet_path": "",
        "answer_path": "",
        "source": "presence_activity",
        "operation_kind": "presence_activity",
    }


def _append_recent_task(previous: list[str], task: str) -> list[str]:
    text = _normalize_completed_task_text(clean_product_status_text(task))
    if not text:
        return previous[-2:]
    values = [item for item in previous if item != text]
    values.append(text)
    return values[-2:]


def _field(status: dict[str, Any], key: str) -> str:
    value = status.get(key)
    if value in (None, "", []):
        return "(none)"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)


def _normalize_completed_task_text(text: str) -> str:
    prefixes = ("Completed run task:",)
    for prefix in prefixes:
        if text.startswith(prefix):
            return text[len(prefix) :].strip()
    return text


def _previous_text(
    previous: dict[str, Any] | None,
    key: str,
    default: str,
    *,
    reject_memory_question: bool = False,
) -> str:
    if previous is None:
        return default
    value = clean_product_status_text(previous.get(key))
    if reject_memory_question and looks_like_memory_question_text(value):
        return default
    return value or default


def _previous_list(previous: dict[str, Any] | None, key: str) -> list[str]:
    if previous is None:
        return []
    return _clean_completed_tasks(previous.get(key))
