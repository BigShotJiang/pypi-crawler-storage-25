"""Schema loading and validator construction.

`.context/schemas/` is canonical. Validators are built from the on-disk
schemas so that downstream tools reading `.context/` see exactly the same
contract Remaind enforces. The bundled copies in
``remaind._templates/schemas`` are init defaults only.
"""

from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path

from jsonschema import Draft202012Validator

SCHEMA_FILES = (
    "event.schema.json",
    "state.schema.json",
    "memory.schema.json",
    "validation.schema.json",
    "chunk_summary_v1.schema.json",
    "group_summary_v1.schema.json",
    "global_summary_v1.schema.json",
)


def _schema_filename(name: str) -> str:
    if name in SCHEMA_FILES:
        return name
    candidate = f"{name}.schema.json"
    if candidate in SCHEMA_FILES:
        return candidate
    raise KeyError(f"unknown schema: {name!r}")


def bundled_schema(name: str) -> dict:
    """Return the bundled (init-default) copy of a schema."""
    filename = _schema_filename(name)
    res = files("remaind") / "_templates" / "schemas" / filename
    return json.loads(res.read_text(encoding="utf-8"))


def ensure_bundled_schemas(base: Path) -> None:
    """Copy missing bundled schemas into ``base/.context/schemas``.

    Existing schema files are intentionally left untouched. `.context/schemas`
    is the canonical contract for a project, so this helper only installs new
    bundled defaults needed by newer Remaind features.
    """

    from ._paths import ContextPaths

    schemas_dir = ContextPaths.at(Path(base).expanduser().resolve()).schemas_dir
    schemas_dir.mkdir(parents=True, exist_ok=True)
    bundled_dir = files("remaind") / "_templates" / "schemas"
    for filename in SCHEMA_FILES:
        dst = schemas_dir / filename
        if dst.exists():
            continue
        src = bundled_dir / filename
        dst.write_bytes(src.read_bytes())


def load_schema(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def make_validator(schema: dict) -> Draft202012Validator:
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)
