"""Append-only event writer.

Builds a fully-formed event from caller-supplied fields, applies redaction
and large-output routing, validates the result against the on-disk event
schema, and appends a single JSON line to ``logs/events.jsonl``. The writer
uses a small interprocess lock around chain-hash calculation and append so
concurrent CLI commands cannot corrupt the event hash chain.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows fallback
    fcntl = None  # type: ignore[assignment]

try:
    import msvcrt as _msvcrt
except ImportError:  # pragma: no cover - non-Windows platforms
    _msvcrt = None  # type: ignore[assignment]

from jsonschema import Draft202012Validator

from ._artifacts import ArtifactStore
from ._configs import load_yaml_mapping
from ._errors import RemaindError
from ._paths import ContextPaths
from ._redaction import Redactor
from ._schemas import load_schema, make_validator
from ._timestamps import utc_now_iso
from ._trust import GENESIS_HASH, chain_metadata
from ._ulid import new_event_id

_EVENT_VERSION = "1.0.0"
_DEFAULT_LARGE_OUTPUT_BYTES = 4096
_DEFAULT_ARTIFACT_EXCERPT_CHARS = 500


@dataclass
class EventInput:
    """Caller-facing fields for constructing a single event.

    The writer fills in ``id``, ``timestamp``, the content excerpt / hash /
    bytes / ref triple, ``is_binary``, and ``redacted``.

    Pass text as ``str`` whenever possible. ``bytes`` are treated as opaque
    binary unless they decode cleanly as high-confidence UTF-8 text; decoded
    text bytes go through the same redaction path as ``str`` content before
    anything is written to disk.
    """

    type: str
    actor: str
    summary: str
    session_id: str
    task_id: str
    content: str | bytes | None = None
    content_type: str = "text/plain"
    importance: int = 1
    tags: Sequence[str] = field(default_factory=list)
    source: str = ""
    source_event_ids: Sequence[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class EventValidationError(RemaindError):
    """Raised when a constructed event fails schema validation.

    The offending event is exposed on ``event`` for diagnostic logging.
    Nothing is appended to ``events.jsonl`` when this is raised.
    """

    def __init__(self, event: dict, errors: list) -> None:
        super().__init__(
            "event failed schema validation: "
            + "; ".join(e.message for e in errors)
        )
        self.event = event
        self.errors = errors


class EventWriter:
    def __init__(
        self,
        paths: ContextPaths,
        *,
        redactor: Redactor,
        event_validator: Draft202012Validator,
        large_output_bytes: int = _DEFAULT_LARGE_OUTPUT_BYTES,
        artifact_excerpt_chars: int = _DEFAULT_ARTIFACT_EXCERPT_CHARS,
    ) -> None:
        self._paths = paths
        self._redactor = redactor
        self._validator = event_validator
        self._large_output_bytes = int(large_output_bytes)
        self._artifact_excerpt_chars = int(artifact_excerpt_chars)
        self._artifacts = ArtifactStore(paths.artifacts_dir)

    @classmethod
    def open(cls, base: Path) -> EventWriter:
        """Build a writer from an initialized ``.context/`` rooted at ``base``."""
        paths = ContextPaths.at(Path(base))
        redactor = Redactor.from_config_path(paths.redaction_yaml)
        validator = make_validator(load_schema(paths.event_schema))
        thresholds = load_yaml_mapping(paths.thresholds_yaml).get("default", {})
        return cls(
            paths,
            redactor=redactor,
            event_validator=validator,
            large_output_bytes=int(
                thresholds.get("large_output_bytes", _DEFAULT_LARGE_OUTPUT_BYTES)
            ),
            artifact_excerpt_chars=int(
                thresholds.get(
                    "artifact_excerpt_chars", _DEFAULT_ARTIFACT_EXCERPT_CHARS
                )
            ),
        )

    @property
    def paths(self) -> ContextPaths:
        return self._paths

    def append(self, event: EventInput) -> dict:
        """Materialize, validate, and append an event. Return the written dict."""
        self._paths.logs_dir.mkdir(parents=True, exist_ok=True)
        with self._event_lock():
            previous_hash = self._latest_chain_hash()
            (
                head,
                tail,
                content_ref,
                content_hash,
                content_bytes,
                is_binary,
                redacted,
                content_type,
            ) = self._route_content(event)

            full = {
                "schema_version": _EVENT_VERSION,
                "id": new_event_id(),
                "timestamp": utc_now_iso(),
                "session_id": event.session_id,
                "task_id": event.task_id,
                "type": event.type,
                "actor": event.actor,
                "summary": event.summary,
                "content_type": content_type,
                "is_binary": is_binary,
                "content_excerpt_head": head,
                "content_excerpt_tail": tail,
                "content_ref": content_ref,
                "content_hash": content_hash,
                "content_bytes": content_bytes,
                "importance": int(event.importance),
                "tags": list(event.tags),
                "redacted": redacted,
                "source": event.source,
                "source_event_ids": list(event.source_event_ids),
                "metadata": dict(event.metadata),
            }
            full_metadata = full["metadata"]
            assert isinstance(full_metadata, dict)
            full_metadata["event_chain"] = chain_metadata(previous_hash, full)

            errors = sorted(
                self._validator.iter_errors(full),
                key=lambda e: list(e.absolute_path),
            )
            if errors:
                raise EventValidationError(full, errors)

            with self._paths.events_jsonl.open("a", encoding="utf-8") as f:
                f.write(json.dumps(full) + "\n")
                f.flush()
                os.fsync(f.fileno())

        return full

    @contextmanager
    def _event_lock(self):
        lock_path = self._paths.logs_dir / "events.jsonl.lock"
        with lock_path.open("a+") as lock_file:
            if fcntl is not None:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
            elif _msvcrt is not None:
                lock_file.seek(0)
                _msvcrt.locking(lock_file.fileno(), _msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                if fcntl is not None:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                elif _msvcrt is not None:
                    lock_file.seek(0)
                    _msvcrt.locking(lock_file.fileno(), _msvcrt.LK_UNLCK, 1)

    def _latest_chain_hash(self) -> str:
        if not self._paths.events_jsonl.exists():
            return GENESIS_HASH
        latest = GENESIS_HASH
        with self._paths.events_jsonl.open("r", encoding="utf-8") as f:
            for raw in f:
                stripped = raw.strip()
                if not stripped:
                    continue
                obj = json.loads(stripped)
                metadata = obj.get("metadata") or {}
                chain = metadata.get("event_chain") or {}
                latest = str(chain.get("chain_hash") or GENESIS_HASH)
        return latest

    def _route_content(
        self, event: EventInput
    ) -> tuple[str | None, str | None, str | None, str | None, int, bool, bool, str]:
        content = event.content
        if content is None:
            return None, None, None, None, 0, False, False, event.content_type

        if isinstance(content, (bytes, bytearray)):
            data = bytes(content)
            text = _decode_text_bytes(data)
            if text is not None:
                return self._route_text_content(text, event.content_type)

            stored = self._artifacts.write_bytes(data)
            content_type = event.content_type
            if content_type == "text/plain":
                # default for str — override for raw bytes
                content_type = "application/octet-stream"
            ref = stored.path.relative_to(self._paths.root).as_posix()
            return None, None, ref, stored.sha256, stored.bytes, True, False, content_type

        if isinstance(content, str):
            return self._route_text_content(content, event.content_type)

        raise TypeError(
            f"event.content must be str | bytes | None, "
            f"got {type(content).__name__}"
        )

    def _route_text_content(
        self, content: str, content_type: str
    ) -> tuple[str | None, str | None, str | None, str | None, int, bool, bool, str]:
        text, was_redacted = self._redactor.redact(content)
        data = text.encode("utf-8")
        content_bytes = len(data)
        content_hash = hashlib.sha256(data).hexdigest()
        if content_bytes > self._large_output_bytes:
            stored = self._artifacts.write_text(text)
            head = text[: self._artifact_excerpt_chars]
            tail = text[-self._artifact_excerpt_chars :]
            ref = stored.path.relative_to(self._paths.root).as_posix()
            return (
                head,
                tail,
                ref,
                content_hash,
                content_bytes,
                False,
                was_redacted,
                content_type,
            )
        return (
            text,
            None,
            None,
            content_hash,
            content_bytes,
            False,
            was_redacted,
            content_type,
        )


def _decode_text_bytes(data: bytes) -> str | None:
    """Return decoded UTF-8 text when bytes are very likely textual."""
    if not data:
        return ""
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    if "\x00" in text:
        return None
    allowed_controls = {"\n", "\r", "\t", "\f", "\b"}
    suspicious = 0
    for ch in text:
        if ch.isprintable() or ch in allowed_controls:
            continue
        suspicious += 1
    if suspicious / max(len(text), 1) > 0.02:
        return None
    return text
