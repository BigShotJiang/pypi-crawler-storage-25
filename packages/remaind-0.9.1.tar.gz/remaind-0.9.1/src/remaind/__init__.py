"""Remaind — durable context for long-running agents.

This module is the **public API**. Everything exported here is stable: the
names, their import paths, and their behaviour will not change without a
version bump and a changelog entry.

The underscore-prefixed modules (``remaind._events``, ``remaind._compactor``,
``remaind._llm_compactor``, …) are **internal**. They may be renamed or
restructured at any time — do not import from them directly. Advanced harnesses
that need the low-level handover compactor protocol should import from
``remaind.compactor_protocol``; the root-level protocol names remain as
compatibility re-exports.

Operator integration guide: ``docs/integration.md`` in the repository.

Quick orientation — the operator loop::

    import remaind

    remaind.init(base)                        # once: create .context/
    writer = remaind.EventWriter.open(base)    # log events as work happens
    writer.append(remaind.EventInput(...))
    status = remaind.compaction_status(base)   # monitor the token band
    if status.compaction_needed:
        remaind.compact(base)                  # validated compaction
    result = remaind.resume(base)              # build a fresh-context packet
"""

from importlib.metadata import PackageNotFoundError, version

from ._amb_benchmark import (
    AMBBenchmarkError,
    AMBDiffReport,
    AMBFailureTaxonomy,
    AMBOfflineScoreReport,
    AMBPrepareResult,
    AMBScoreReport,
    build_amb_failure_taxonomy,
    build_amb_offline_score,
    build_amb_score_diff,
    build_amb_score_report,
    prepare_amb,
)
from ._benchmark import (
    BenchmarkCheck,
    BenchmarkError,
    SovereignBenchmarkResult,
    run_sovereign_benchmark,
)
from ._compaction import CompactionStatus, compaction_status
from ._compactor import (
    CompactionCandidate,
    CompactionSources,
    Compactor,
    default_compact,
    select_sources,
)
from ._continuity import (
    AdapterExportResult,
    ContinuityError,
    ContinuityMetric,
    ContinuityScorecard,
    EvidenceLink,
    MemoryToolResult,
    build_continuity_scorecard,
    build_evidence_map,
    export_adapters,
    mark_task_blocked,
    promote_to_memory,
    record_decision,
)
from ._continuity_benchmark import (
    ProjectContinuityBenchmarkResult,
    run_project_continuity_benchmark,
)
from ._errors import RemaindError
from ._events import EventInput, EventValidationError, EventWriter
from ._handover_writer import HandoverValidationError, write_handover
from ._large_doc import (
    LargeDocumentError,
    LargeDocumentIngestResult,
    LargeDocumentLinesResult,
    LargeDocumentSearchHit,
    LargeDocumentSearchResult,
    LargeDocumentStats,
    head_large_document,
    ingest_large_document,
    large_document_stats,
    search_large_document,
    slice_large_document,
    tail_large_document,
    verify_large_document,
)
from ._local_compactor import CompactorResponseError
from ._memory_records import (
    MemoryRecord,
    MemoryRecordBackfillResult,
    MemoryRecordSource,
    backfill_memory_records,
    search_memory_records,
)
from ._paths import ContextPaths
from ._public_benchmarks import (
    PublicBenchmarkError,
    StateBenchPrepareResult,
    StateBenchRetrieval,
    prepare_state_bench,
    retrieve_state_bench_learnings,
)
from ._recommendation_engine import (
    RecommendationCandidate,
    RecommendationCandidateScore,
    RecommendationDecision,
    build_recommendation_decision,
    render_recommendation_decision,
)
from ._resume_gate import GateAssessment
from ._resume_packet import ResumePacket, build_resume_packet
from ._state_writer import StateValidationError, update_state
from ._tokens import estimate_tokens
from .commands.compact import (
    CompactionError,
    CompactionRejected,
    CompactionResult,
)
from .commands.compact import run as compact
from .commands.doctor import DoctorResult
from .commands.doctor import check as doctor
from .commands.init import InitError
from .commands.init import run as init
from .commands.launch import LaunchError, LaunchOptions, LaunchResult
from .commands.launch import execute as launch
from .commands.monitor import MonitorResult
from .commands.monitor import check as monitor
from .commands.resume import ResumeError, ResumeResult
from .commands.resume import run as resume
from .commands.rollback import RollbackError, RollbackResult
from .commands.rollback import run as rollback
from .commands.run import RunError, RunResult
from .commands.run import execute as run_prompt
from .commands.status import StatusError
from .commands.status import build_status_payload as status
from .commands.validate import ValidationReport
from .commands.validate import run as validate

try:
    # Single source of truth: the installed package metadata (pyproject.toml).
    __version__ = version("remaind")
except PackageNotFoundError:  # pragma: no cover - running from source tree
    __version__ = "0.0.0+source"


__all__ = [
    "__version__",
    # --- paths -----------------------------------------------------------
    "ContextPaths",
    # --- common errors ---------------------------------------------------
    "RemaindError",
    # --- high-level operations (mirror the CLI verbs) --------------------
    "init",
    "validate",
    "status",
    "compact",
    "resume",
    "rollback",
    "doctor",
    "monitor",
    "launch",
    "run_prompt",
    "run_sovereign_benchmark",
    "run_project_continuity_benchmark",
    "prepare_amb",
    "build_amb_score_report",
    "build_amb_failure_taxonomy",
    "build_amb_score_diff",
    "build_amb_offline_score",
    "prepare_state_bench",
    "retrieve_state_bench_learnings",
    "build_continuity_scorecard",
    "build_evidence_map",
    "export_adapters",
    "mark_task_blocked",
    "record_decision",
    "promote_to_memory",
    "backfill_memory_records",
    "search_memory_records",
    "RecommendationCandidate",
    "RecommendationCandidateScore",
    "RecommendationDecision",
    "build_recommendation_decision",
    "render_recommendation_decision",
    "ingest_large_document",
    "large_document_stats",
    "search_large_document",
    "slice_large_document",
    "head_large_document",
    "tail_large_document",
    "verify_large_document",
    # --- event logging ---------------------------------------------------
    "EventWriter",
    "EventInput",
    "EventValidationError",
    # --- derived-state writes -------------------------------------------
    "update_state",
    "StateValidationError",
    "write_handover",
    "HandoverValidationError",
    # --- token budget + compaction monitoring ---------------------------
    "estimate_tokens",
    "compaction_status",
    "CompactionStatus",
    # --- compaction: result + error types -------------------------------
    "CompactionResult",
    "CompactionError",
    "CompactionRejected",
    # --- low-level compactor protocol compatibility re-exports ----------
    # Prefer `remaind.compactor_protocol` for new advanced integrations.
    "Compactor",
    "CompactionSources",
    "CompactionCandidate",
    "select_sources",
    "default_compact",
    "CompactorResponseError",
    "BenchmarkCheck",
    "BenchmarkError",
    "ContinuityMetric",
    "ContinuityError",
    "ContinuityScorecard",
    "EvidenceLink",
    "AdapterExportResult",
    "MemoryToolResult",
    "MemoryRecord",
    "MemoryRecordSource",
    "MemoryRecordBackfillResult",
    "SovereignBenchmarkResult",
    "ProjectContinuityBenchmarkResult",
    "AMBBenchmarkError",
    "AMBDiffReport",
    "AMBFailureTaxonomy",
    "AMBOfflineScoreReport",
    "AMBPrepareResult",
    "AMBScoreReport",
    "PublicBenchmarkError",
    "StateBenchPrepareResult",
    "StateBenchRetrieval",
    "LargeDocumentStats",
    "LargeDocumentIngestResult",
    "LargeDocumentSearchHit",
    "LargeDocumentSearchResult",
    "LargeDocumentLinesResult",
    "LargeDocumentError",
    # --- resume ----------------------------------------------------------
    "build_resume_packet",
    "ResumePacket",
    "ResumeResult",
    "ResumeError",
    "GateAssessment",
    # --- per-command result / error types -------------------------------
    "InitError",
    "ValidationReport",
    "StatusError",
    "RollbackResult",
    "RollbackError",
    "RunResult",
    "RunError",
    "DoctorResult",
    "MonitorResult",
    "LaunchOptions",
    "LaunchResult",
    "LaunchError",
]
