"""Context engineering orchestration for model-facing Remaind packets."""

from __future__ import annotations

from dataclasses import dataclass

from ._context_budget import (
    ContextSelection,
    context_token_cap_for_window,
    select_context_sources,
)
from ._context_intent import ContextIntent, classify_context_intent
from ._context_render import render_context_packet
from ._context_sources import ContextSource


@dataclass(frozen=True)
class ContextBuildRequest:
    question: str
    workspace_query: str | None = None
    context_window_tokens: int | None = None
    token_cap: int | None = None


@dataclass(frozen=True)
class ContextPacket:
    content: str
    intent: ContextIntent
    selection: ContextSelection


def select_engineered_context(
    request: ContextBuildRequest,
    sources: list[ContextSource],
) -> tuple[ContextIntent, ContextSelection]:
    """Classify intent and select context sources under the request budget."""

    intent = classify_context_intent(
        request.question,
        workspace_query=request.workspace_query,
    )
    token_cap = request.token_cap or context_token_cap_for_window(
        request.context_window_tokens
    )
    selection = select_context_sources(
        sources,
        intent=intent,
        token_cap=token_cap,
    )
    return intent, selection


def build_context_packet(
    request: ContextBuildRequest,
    sources: list[ContextSource],
) -> ContextPacket:
    """Classify, budget, and render model context from normalized sources."""

    intent, selection = select_engineered_context(request, sources)
    return ContextPacket(
        content=render_context_packet(
            question=request.question,
            workspace_query=request.workspace_query,
            intent=intent,
            selection=selection,
        ),
        intent=intent,
        selection=selection,
    )
