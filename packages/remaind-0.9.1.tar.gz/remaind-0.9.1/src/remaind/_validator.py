"""Mechanical compaction validator.

Runs the six §13 checks against a (sources, candidate) pair and emits a
result dict that conforms to ``validation.schema.json``. The result is also
schema-validated before return — a bug in this module cannot silently ship
a malformed validation event.

Reject-on-any-false. If *any* required boolean is false, ``verdict`` is
``"reject"`` and the caller MUST keep the previous handover/state.
"""

from __future__ import annotations

import json
from typing import Any

from ._adversarial import scan_text
from ._compactor import CompactionCandidate, CompactionSources
from ._schemas import bundled_schema, make_validator


def _check_completed_work_preserved(
    sources: CompactionSources,
    candidate: CompactionCandidate,
    missing: list[str],
) -> bool:
    old = set(sources.current_state.get("completed_work", []) or [])
    new = set(candidate.new_state.get("completed_work", []) or [])
    dropped = old - new
    if dropped:
        for item in sorted(dropped):
            missing.append(f"completed_work: dropped {item!r}")
        return False
    return True


def _check_decisions_preserved(
    sources: CompactionSources,
    candidate: CompactionCandidate,
    missing: list[str],
) -> bool:
    old = set(sources.current_state.get("decisions", []) or [])
    new = set(candidate.new_state.get("decisions", []) or [])
    dropped = old - new
    if dropped:
        for item in sorted(dropped):
            missing.append(f"decisions: dropped {item!r}")
        return False
    return True


def _check_next_step_grounded(
    sources: CompactionSources,
    candidate: CompactionCandidate,
    unsupported: list[str],
) -> bool:
    next_step = (candidate.new_state.get("next_step") or "").strip()
    if not next_step:
        unsupported.append("next_step is empty")
        return False
    return True


def _check_latest_user_instruction_preserved(
    sources: CompactionSources,
    candidate: CompactionCandidate,
    missing: list[str],
) -> bool:
    old = sources.current_state.get("latest_user_instruction_event_id")
    new = candidate.new_state.get("latest_user_instruction_event_id")
    if old is None:
        return True
    if new != old:
        missing.append(
            f"latest_user_instruction_event_id changed from {old!r} to {new!r}"
        )
        return False
    return True


def _check_importance_3_items_preserved(
    sources: CompactionSources,
    candidate: CompactionCandidate,
    missing: list[str],
) -> bool:
    if not sources.importance_critical:
        return True
    handover = candidate.new_handover or ""
    state_blob = json.dumps(candidate.new_state, sort_keys=True)
    failed = False
    for ev in sources.importance_critical:
        evid = ev.get("id")
        summary = (ev.get("summary") or "").strip()
        if evid and (evid in handover or evid in state_blob):
            continue
        if summary and (summary in handover or summary in state_blob):
            continue
        missing.append(
            f"importance=3 event {evid!r} not represented in handover or state"
        )
        failed = True
    return not failed


def _check_no_superseded_memory_as_current(
    sources: CompactionSources, candidate: CompactionCandidate
) -> bool:
    # V1 does not deep-link memory IDs into state, so the check is trivially
    # True. When Phase 12+ adds memory references to state, this expands to
    # cross-check against the memories table's supersedes column.
    return True


def _check_adversarial_content_clean(
    candidate: CompactionCandidate,
    unsupported: list[str],
) -> tuple[bool, list[dict[str, str]]]:
    findings = []
    findings.extend(
        scan_text(
            "candidate_handover",
            candidate.new_handover,
            source_id="new_handover",
        )
    )
    findings.extend(
        scan_text(
            "candidate_state",
            json.dumps(candidate.new_state, sort_keys=True, default=str),
            source_id="new_state",
        )
    )
    findings.extend(
        scan_text(
            "candidate_summary",
            candidate.summary,
            source_id="summary",
        )
    )
    findings.extend(
        scan_text(
            "candidate_rationale",
            candidate.rationale,
            source_id="rationale",
        )
    )
    for finding in findings:
        unsupported.append(
            f"adversarial {finding.severity}: {finding.source}: {finding.issue}"
        )
    return not findings, [finding.to_dict() for finding in findings]


def validate_candidate(
    sources: CompactionSources, candidate: CompactionCandidate
) -> dict[str, Any]:
    """Run the §13 checks and return a validation-schema-conformant dict."""
    missing: list[str] = []
    unsupported: list[str] = []

    completed_work_preserved = _check_completed_work_preserved(
        sources, candidate, missing
    )
    decisions_preserved = _check_decisions_preserved(sources, candidate, missing)
    next_step_grounded = _check_next_step_grounded(
        sources, candidate, unsupported
    )
    latest_user_instruction_preserved = (
        _check_latest_user_instruction_preserved(sources, candidate, missing)
    )
    importance_3_items_preserved = _check_importance_3_items_preserved(
        sources, candidate, missing
    )
    no_superseded_memory_as_current = _check_no_superseded_memory_as_current(
        sources, candidate
    )
    adversarial_content_clean, adversarial_findings = (
        _check_adversarial_content_clean(candidate, unsupported)
    )

    all_pass = all(
        (
            completed_work_preserved,
            decisions_preserved,
            next_step_grounded,
            latest_user_instruction_preserved,
            importance_3_items_preserved,
            no_superseded_memory_as_current,
            adversarial_content_clean,
        )
    )
    result: dict[str, Any] = {
        "completed_work_preserved": completed_work_preserved,
        "decisions_preserved": decisions_preserved,
        "next_step_grounded": next_step_grounded,
        "latest_user_instruction_preserved": latest_user_instruction_preserved,
        "importance_3_items_preserved": importance_3_items_preserved,
        "no_superseded_memory_as_current": no_superseded_memory_as_current,
        "adversarial_content_clean": adversarial_content_clean,
        "adversarial_findings": adversarial_findings,
        "missing_items": missing,
        "unsupported_claims": unsupported,
        "verdict": "accept" if all_pass else "reject",
    }

    # Self-check: our own output must validate against the bundled schema.
    validator = make_validator(bundled_schema("validation.schema.json"))
    errors = list(validator.iter_errors(result))
    if errors:  # pragma: no cover - defensive; indicates a bug in this module
        msg = "; ".join(e.message for e in errors)
        raise RuntimeError(f"validator produced non-conformant result: {msg}")
    return result
