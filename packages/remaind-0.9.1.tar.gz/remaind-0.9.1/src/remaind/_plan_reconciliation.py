"""Durable reconciliation between saved activity and the product plan.

Product status records what just happened. Plan reconciliation answers the next
question: how does that activity advance, block, or leave untouched the active
product plan? The artifact created here is intentionally conservative: a plan
item is only marked complete when the source plan/status says it is complete.
Observed commands and generated packets can move an item to in progress or
blocked, but they do not silently rewrite the product roadmap.
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._jsonl import append_jsonl
from ._paths import ContextPaths
from ._product_status import clean_product_status_text, load_product_status
from ._recommendation_engine import (
    RecommendationDecision,
    build_recommendation_decision,
    candidates_from_plan_items,
)
from ._timestamps import utc_now_iso

PLAN_RECONCILIATION_SCHEMA_VERSION = "1.0.0"

_MAX_CHILD_PROJECTS = 2
_MAX_CONTEXT_FILES = 8
_MAX_AUTHORITY_FILES = 5
_MAX_PLAN_ITEMS = 40
_PLAN_FILE_READ_CHARS = 160_000
_DISCOVERY_CHILD_LIMIT = 200
_DISCOVERY_SKIP_DIRS = {
    ".context",
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "dist",
    "node_modules",
    "venv",
}
_DOCUMENT_EXTENSIONS = frozenset({".md", ".markdown", ".txt", ".yaml", ".yml"})
_WORKSPACE_SEARCH_STOPWORDS = frozenset(
    {
        "about",
        "active",
        "and",
        "app",
        "are",
        "build",
        "building",
        "continue",
        "current",
        "for",
        "from",
        "latest",
        "memory",
        "next",
        "project",
        "status",
        "task",
        "the",
        "this",
        "todo",
        "todos",
        "what",
        "with",
        "work",
        "workspace",
    }
)


@dataclass(frozen=True)
class PlanItem:
    key: str
    text: str
    source_status: str
    status: str
    source: str
    line_number: int
    evidence: tuple[str, ...]


def load_plan_reconciliation(base: Path) -> dict[str, Any] | None:
    """Load the latest plan reconciliation artifact, if present."""

    path = ContextPaths.at(Path(base)).plan_reconciliation_json
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def ensure_plan_reconciliation(
    base: Path,
    *,
    workspace_query: str | None = None,
) -> dict[str, Any]:
    """Recompute and persist plan reconciliation for an activated workspace."""

    return update_plan_reconciliation(
        base,
        workspace_query=workspace_query,
        source="launch_activation",
    )


def update_plan_reconciliation(
    base: Path,
    *,
    workspace_query: str | None = None,
    source: str = "manual",
) -> dict[str, Any]:
    """Persist a fresh product-plan reconciliation artifact."""

    base = Path(base)
    paths = ContextPaths.at(base)
    product_status = load_product_status(base)
    progress_snapshot = _load_json(paths.progress_snapshot)
    presence_snapshot = _load_json(paths.presence_snapshot)
    project_dirs = _project_dirs_for_reconciliation(base, workspace_query, product_status)
    authority_files: list[Path] = []
    plan_items: list[PlanItem] = []
    for project_dir in project_dirs:
        files = _project_context_files(project_dir, query_text=workspace_query)
        project_authority = _project_authority_files(project_dir, files)
        authority_files.extend(project_authority)
        plan_items.extend(
            _extract_plan_items(
                project_dir,
                project_authority or files,
                product_status=product_status,
                progress_snapshot=progress_snapshot,
                presence_snapshot=presence_snapshot,
            )
        )
    plan_items = _dedupe_plan_items(plan_items)[:_MAX_PLAN_ITEMS]
    actionable = _select_actionable_item(plan_items)
    blocker = _current_blocker(product_status, progress_snapshot, presence_snapshot)
    incomplete = _current_incomplete_task(product_status, progress_snapshot, presence_snapshot)
    item_dicts = [asdict(item) for item in plan_items]
    blocker_candidate = ""
    if blocker:
        blocker_candidate = (
            "Fix the current blocker, then retry: "
            f"{incomplete or actionable.text if actionable else 'the interrupted task'}"
        )
    recommendation_decision = build_recommendation_decision(
        "What is the recommended next product step?",
        _recommendation_evidence_texts(
            product_status,
            progress_snapshot,
            presence_snapshot,
            plan_items,
            authority_files,
            blocker=blocker,
        ),
        candidates=candidates_from_plan_items(
            item_dicts,
            blocker_candidate=blocker_candidate,
        ),
    )
    if recommendation_decision.selected_action:
        aligned_next = recommendation_decision.selected_action
    elif blocker:
        aligned_next = blocker_candidate
    elif actionable:
        aligned_next = actionable.text
    else:
        aligned_next = (
            "No pending plan item was detected. Capture or update a product plan "
            "file before continuing implementation."
        )
    if blocker:
        next_after_blocker = actionable.text if actionable else "Continue with the first pending plan item."
    elif actionable:
        next_after_blocker = "No active blocker; proceed with the aligned next plan step."
    else:
        next_after_blocker = "No active blocker is recorded."
    payload: dict[str, Any] = {
        "schema_version": PLAN_RECONCILIATION_SCHEMA_VERSION,
        "updated_at": utc_now_iso(),
        "source": source,
        "workspace": str(base),
        "workspace_query": clean_product_status_text(workspace_query),
        "project_paths": [str(path) for path in project_dirs],
        "authority_files": [_relative_to_any(path, project_dirs) for path in authority_files],
        "current_development_plan_focus": _plan_focus(product_status, actionable),
        "plan_status_and_progress": _plan_status(plan_items, blocker=blocker),
        "last_two_completed_tasks": _last_two_completed_tasks(product_status),
        "error_or_blocker": blocker,
        "incomplete_task_due_to_blocker": incomplete,
        "ready_for_new_instructions": True,
        "fix_instruction": (
            f"Fix this blocker, then retry the incomplete task: {incomplete}"
            if blocker and incomplete
            else ("No active blocker is recorded." if not blocker else f"Fix this blocker: {blocker}")
        ),
        "next_step_after_blocker": next_after_blocker,
        "aligned_next_plan_step": aligned_next,
        "recommendation_decision": _recommendation_decision_payload(recommendation_decision),
        "items": item_dicts,
        "preventive_saving_status": (
            "Active. Remaind recomputes this reconciliation at launch and after "
            "progress or presence updates, writes active/plan_reconciliation.* "
            "atomically, and appends logs/plan_reconciliation.jsonl with fsync."
        ),
    }
    atomic_write_text(
        paths.plan_reconciliation_json,
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        history_dir=paths.history_dir / "plan_reconciliation",
    )
    atomic_write_text(
        paths.plan_reconciliation_md,
        render_plan_reconciliation(payload),
        history_dir=paths.history_dir / "plan_reconciliation_md",
    )
    append_jsonl(paths.plan_reconciliation_jsonl, payload)
    return payload


def update_plan_reconciliation_from_progress(
    base: Path,
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    """Recompute reconciliation after a crash-safe progress update."""

    workspace_query = _workspace_query_from_status(load_product_status(base))
    metadata = snapshot.get("metadata")
    if isinstance(metadata, dict):
        workspace_query = clean_product_status_text(
            metadata.get("workspace_query")
        ) or workspace_query
    return update_plan_reconciliation(
        base,
        workspace_query=workspace_query,
        source="progress_snapshot",
    )


def update_plan_reconciliation_from_presence(
    base: Path,
    presence: dict[str, Any],
) -> dict[str, Any]:
    """Recompute reconciliation after privacy-safe shell activity."""

    _ = presence
    return update_plan_reconciliation(
        base,
        workspace_query=_workspace_query_from_status(load_product_status(base)),
        source="presence_activity",
    )


def render_plan_reconciliation(payload: dict[str, Any]) -> str:
    """Render reconciliation as model-readable Markdown."""

    rows = [
        "## Product Plan Reconciliation",
        "",
        (
            "This is Remaind's structured view of how saved activity maps to "
            "the product plan. Treat it as higher authority than old packets "
            "or old model answers for continuation, status, blocker, and next "
            "step questions."
        ),
        "",
        "### Current Development Plan Focus",
        "",
        _field(payload, "current_development_plan_focus"),
        "",
        "### Plan Status And Progress",
        "",
        _field(payload, "plan_status_and_progress"),
        "",
        "### Last Two Completed Tasks",
    ]
    completed = payload.get("last_two_completed_tasks")
    if isinstance(completed, list) and completed:
        rows.extend(f"- {item}" for item in completed[:2])
    else:
        rows.append("- (none captured yet)")
    rows.extend(
        [
            "",
            "### Current Blocker",
            "",
            _field(payload, "error_or_blocker"),
            "",
            "### Incomplete Task Due To Blocker",
            "",
            _field(payload, "incomplete_task_due_to_blocker"),
            "",
            "### Next Step",
            "",
            _field(payload, "aligned_next_plan_step"),
            "",
            "### Recovery",
            "",
            f"- Ready for new instructions: {'yes' if payload.get('ready_for_new_instructions') else 'no'}",
            f"- Fix instruction: {_field(payload, 'fix_instruction')}",
            f"- Next step after blocker: {_field(payload, 'next_step_after_blocker')}",
            "",
            "### Reconciled Plan Items",
        ]
    )
    items = payload.get("items")
    if isinstance(items, list) and items:
        for item in items[:12]:
            if not isinstance(item, dict):
                continue
            evidence = item.get("evidence")
            evidence_text = ""
            if isinstance(evidence, list) and evidence:
                evidence_text = f" Evidence: {'; '.join(str(value) for value in evidence[:2])}"
            rows.append(
                "- "
                f"{_field(item, 'status')}: {_field(item, 'text')} "
                f"(source: {_field(item, 'source')}:{_field(item, 'line_number')})."
                f"{evidence_text}"
            )
    else:
        rows.append("- (no structured plan items detected)")
    recommendation = payload.get("recommendation_decision")
    if isinstance(recommendation, dict):
        rows.extend(
            [
                "",
                "### Recommendation Decision",
                "",
                f"- Selected action: {_field(recommendation, 'selected_action')}",
                f"- Confidence: {_field(recommendation, 'confidence')}",
            ]
        )
        constraints = recommendation.get("constraints")
        if isinstance(constraints, list) and constraints:
            rows.append(
                "- Active constraints: "
                + ", ".join(str(item) for item in constraints[:8])
            )
        candidates = recommendation.get("candidates")
        if isinstance(candidates, list) and candidates:
            rows.append("- Candidate scores:")
            for candidate in candidates[:6]:
                if not isinstance(candidate, dict):
                    continue
                rows.append(
                    "  - "
                    f"{_field(candidate, 'id')}: {_field(candidate, 'text')} "
                    f"(score={_field(candidate, 'score')}; "
                    f"source={_field(candidate, 'source')})"
                )
    rows.extend(
        [
            "",
            "### Authority Files",
        ]
    )
    authority_files = payload.get("authority_files")
    if isinstance(authority_files, list) and authority_files:
        rows.extend(f"- {path}" for path in authority_files[:12])
    else:
        rows.append("- (none detected)")
    rows.extend(
        [
            "",
            "### Preventive Saving",
            "",
            _field(payload, "preventive_saving_status"),
            "",
        ]
    )
    return "\n".join(rows)


def _recommendation_decision_payload(
    decision: RecommendationDecision,
) -> dict[str, Any]:
    """Return the durable JSON form of the universal recommendation decision."""

    return {
        "selected_action": decision.selected_action,
        "confidence": decision.confidence,
        "criteria": list(decision.criteria),
        "constraints": [
            f"{constraint.key}: {constraint.label}"
            for constraint in decision.constraints
        ],
        "evidence": list(decision.evidence),
        "warnings": list(decision.warnings),
        "candidates": [
            {
                "id": scored.candidate.id,
                "text": scored.candidate.text,
                "source": scored.candidate.source,
                "score": f"{scored.score:.1f}",
                "conflicts": list(scored.conflicts),
                "matches": list(scored.matches),
                "reasons": list(scored.reasons),
            }
            for scored in decision.candidates
        ],
    }


def _recommendation_evidence_texts(
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
    plan_items: Sequence[PlanItem],
    authority_files: Sequence[Path],
    *,
    blocker: str,
) -> list[str]:
    rows: list[str] = []
    for label, source in (
        ("product_status", product_status),
        ("progress_snapshot", progress_snapshot),
        ("presence_snapshot", presence_snapshot),
    ):
        if not isinstance(source, dict):
            continue
        rows.append(f"## {label}")
        for key, value in source.items():
            if isinstance(value, str) and clean_product_status_text(value):
                rows.append(f"- {key}: {clean_product_status_text(value)}")
            elif isinstance(value, list):
                cleaned = [clean_product_status_text(item) for item in value]
                cleaned = [item for item in cleaned if item]
                if cleaned:
                    rows.append(f"- {key}: {', '.join(cleaned[:6])}")
    if blocker:
        rows.append(f"- current_blocker: {blocker}")
    if plan_items:
        rows.append("## plan_items")
        for item in plan_items[:_MAX_PLAN_ITEMS]:
            rows.append(f"- {item.status}: {item.text} (source: {item.source})")
    for path in authority_files[:_MAX_AUTHORITY_FILES]:
        text = _safe_read_text(path, max_chars=12_000).strip()
        if text:
            rows.append(f"## authority_file: {path.name}")
            rows.append(text)
    return ["\n".join(rows)] if rows else []


def _project_dirs_for_reconciliation(
    base: Path,
    workspace_query: str | None,
    product_status: dict[str, Any] | None,
) -> list[Path]:
    candidates = [base]
    query = clean_product_status_text(workspace_query) or _workspace_query_from_status(product_status)
    if query:
        candidates.extend(_matching_child_project_dirs(base, query))
    return _dedupe_paths(candidates)


def _matching_child_project_dirs(base: Path, query: str) -> list[Path]:
    terms = _project_query_terms(query)
    if not terms:
        return []
    ranked = [
        (_child_project_relevance_score(child, terms), child)
        for child in _workspace_child_project_dirs(base)
    ]
    ranked = [(score, path) for score, path in ranked if score >= 35]
    ranked.sort(key=lambda item: (-item[0], item[1].name.lower()))
    return [path for _score, path in ranked[:_MAX_CHILD_PROJECTS]]


def _project_context_files(
    project_dir: Path,
    *,
    query_text: str | None,
) -> list[Path]:
    candidates: list[Path] = []
    root_authority_names = {
        "agents.md",
        "claude.md",
        "handover.md",
        "plan.md",
        "readme.md",
        "status.md",
        "todo.md",
    }
    if project_dir.is_dir():
        candidates.extend(
            path
            for path in project_dir.iterdir()
            if path.is_file() and path.name.lower() in root_authority_names
        )
    for relative_dir in ("docs", "experiment"):
        docs_dir = project_dir / relative_dir
        if not docs_dir.is_dir():
            continue
        for path in _iter_document_files(docs_dir):
            if _project_context_file_score(path) > 0:
                candidates.append(path)
    deduped = _dedupe_paths(candidates)
    if (
        any(_is_product_authority_candidate(project_dir, path) for path in deduped)
        and not _is_explicit_lower_authority_query(_project_query_terms(query_text or ""))
    ):
        deduped = [
            path for path in deduped if not _is_lower_authority_project_context(path)
        ]
    ranked = [
        (_project_context_file_score(path), index, path)
        for index, path in enumerate(deduped)
    ]
    ranked.sort(key=lambda item: (-item[0], item[1], str(item[2]).lower()))
    return [path for score, _index, path in ranked if score > 0][:_MAX_CONTEXT_FILES]


def _project_authority_files(project_dir: Path, files: list[Path]) -> list[Path]:
    ranked = [
        (_project_authority_file_score(project_dir, path), index, path)
        for index, path in enumerate(files)
    ]
    ranked = [(score, index, path) for score, index, path in ranked if score > 0]
    ranked.sort(key=lambda item: (-item[0], item[1], str(item[2]).lower()))
    return [path for _score, _index, path in ranked][:_MAX_AUTHORITY_FILES]


def _extract_plan_items(
    project_dir: Path,
    files: list[Path],
    *,
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
) -> list[PlanItem]:
    items: list[PlanItem] = []
    for path in files:
        relative = _relative_path(path, project_dir)
        text = _safe_read_text(path, max_chars=_PLAN_FILE_READ_CHARS)
        lines = text.splitlines()
        for index, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                continue
            item = _plan_item_from_line(
                stripped,
                lines=lines,
                line_index=index,
                source=relative,
            )
            if item is None:
                continue
            items.append(
                _reconcile_item(
                    item,
                    product_status=product_status,
                    progress_snapshot=progress_snapshot,
                    presence_snapshot=presence_snapshot,
                )
            )
    return items


def _plan_item_from_line(
    stripped: str,
    *,
    lines: list[str],
    line_index: int,
    source: str,
) -> PlanItem | None:
    checklist = re.match(r"^[-*]\s*\[(?P<mark>[ xX])\]\s*(?P<body>.+)$", stripped)
    if checklist:
        source_status = "done" if checklist.group("mark").lower() == "x" else "pending"
        text = _plain_plan_item_text(checklist.group("body"))
        return _new_plan_item(source_status, text, source, line_index + 1)
    next_match = re.match(
        r"^(?:immediate\s+)?next(?:\s+step)?\s*:\s*(?P<body>.+)$",
        stripped,
        flags=re.IGNORECASE,
    )
    if next_match:
        return _new_plan_item(
            "next",
            _plain_plan_item_text(next_match.group("body")),
            source,
            line_index + 1,
        )
    status_match = re.match(
        r"status\s*:\s*(?P<status>pending|todo|open|blocked|done|complete|completed|pass|passing)\b",
        stripped,
        flags=re.IGNORECASE,
    )
    if status_match:
        raw_status = status_match.group("status").lower()
        source_status = "pending"
        if raw_status in {"done", "complete", "completed", "pass", "passing"}:
            source_status = "done"
        elif raw_status == "blocked":
            source_status = "blocked"
        label = _yaml_plan_label_from_window(lines, line_index)
        if label:
            return _new_plan_item(
                source_status,
                _plain_plan_item_text(label),
                source,
                line_index + 1,
            )
    coded = re.match(
        r"^[-*]\s*(?P<body>(?:\*\*)?(?:S|PR)-[A-Z](?:\*\*)?.+)$",
        stripped,
    )
    if coded:
        return _new_plan_item(
            "planned",
            _plain_plan_item_text(coded.group("body")),
            source,
            line_index + 1,
        )
    return None


def _new_plan_item(
    source_status: str,
    text: str,
    source: str,
    line_number: int,
) -> PlanItem | None:
    text = clean_product_status_text(text)
    if not text:
        return None
    status = {
        "done": "completed",
        "blocked": "blocked",
        "next": "active",
        "pending": "pending",
        "planned": "planned",
    }.get(source_status, "planned")
    return PlanItem(
        key=_item_key(text, source),
        text=text,
        source_status=source_status,
        status=status,
        source=source,
        line_number=line_number,
        evidence=(f"plan source says {source_status}",),
    )


def _reconcile_item(
    item: PlanItem,
    *,
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
) -> PlanItem:
    evidence = list(item.evidence)
    status = item.status
    blocker_text = _current_blocker(product_status, progress_snapshot, presence_snapshot)
    incomplete_text = _current_incomplete_task(
        product_status,
        progress_snapshot,
        presence_snapshot,
    )
    activity = _activity_text(product_status, progress_snapshot, presence_snapshot)
    if blocker_text and _matches_item(item, f"{blocker_text} {incomplete_text}"):
        status = "blocked"
        evidence.append("current blocker matches this plan item")
    elif status not in {"completed", "blocked"} and activity and _matches_item(item, activity):
        status = "in_progress"
        evidence.append("latest saved activity matches this plan item")
    return PlanItem(
        key=item.key,
        text=item.text,
        source_status=item.source_status,
        status=status,
        source=item.source,
        line_number=item.line_number,
        evidence=tuple(_dedupe_strings(evidence)),
    )


def _dedupe_plan_items(items: list[PlanItem]) -> list[PlanItem]:
    by_key: dict[str, PlanItem] = {}
    for item in items:
        existing = by_key.get(item.key)
        if existing is None or _status_priority(item.status) < _status_priority(existing.status):
            by_key[item.key] = item
    values = list(by_key.values())
    values.sort(
        key=lambda item: (
            _status_priority(item.status),
            item.source.lower(),
            item.line_number,
            item.text.lower(),
        )
    )
    return values


def _select_actionable_item(items: list[PlanItem]) -> PlanItem | None:
    for status in ("blocked", "in_progress", "active", "pending", "planned"):
        for item in items:
            if item.status == status:
                return item
    return None


def _plan_focus(
    product_status: dict[str, Any] | None,
    actionable: PlanItem | None,
) -> str:
    current = _status_text(product_status, "current_development_plan_focus")
    if current and "No explicit product plan focus captured yet" not in current:
        return current
    if actionable is not None:
        return actionable.text
    return "No explicit product plan focus captured yet. Use product authority files."


def _plan_status(items: list[PlanItem], *, blocker: str) -> str:
    if not items:
        return (
            "No structured product plan items were detected. Add or update a "
            "PLAN, STATUS, TODO, HANDOVER, CLAUDE, experiment, or docs plan file."
        )
    counts: dict[str, int] = {}
    for item in items:
        counts[item.status] = counts.get(item.status, 0) + 1
    parts = [
        f"{label}: {counts[label]}"
        for label in ("completed", "blocked", "in_progress", "active", "pending", "planned")
        if counts.get(label)
    ]
    prefix = "Blocked. " if blocker else ""
    return prefix + "Reconciled plan items: " + ", ".join(parts) + "."


def _current_blocker(
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
) -> str:
    for source in (product_status, progress_snapshot):
        text = _status_text(source, "error_or_blocker")
        if text:
            return text
    if presence_snapshot and presence_snapshot.get("exit_code") not in (None, 0):
        return (
            "Terminal command failed with exit code "
            f"{presence_snapshot.get('exit_code')}: "
            f"{clean_product_status_text(presence_snapshot.get('command_preview'))}"
        )
    return ""


def _current_incomplete_task(
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
) -> str:
    for source in (product_status, progress_snapshot):
        text = _status_text(source, "incomplete_task_due_to_blocker")
        if text:
            return text
    if presence_snapshot and presence_snapshot.get("exit_code") not in (None, 0):
        return f"Fix or retry terminal activity: {_status_text(presence_snapshot, 'command_preview')}"
    return ""


def _last_two_completed_tasks(product_status: dict[str, Any] | None) -> list[str]:
    if not isinstance(product_status, dict):
        return []
    value = product_status.get("last_two_completed_tasks")
    if not isinstance(value, list):
        return []
    return [
        clean_product_status_text(item)
        for item in value
        if clean_product_status_text(item)
    ][-2:]


def _activity_text(
    product_status: dict[str, Any] | None,
    progress_snapshot: dict[str, Any] | None,
    presence_snapshot: dict[str, Any] | None,
) -> str:
    parts: list[str] = []
    for source in (product_status, progress_snapshot):
        if not isinstance(source, dict):
            continue
        for key in (
            "current_development_plan_focus",
            "active_task",
            "aligned_next_plan_step",
            "plan_status_and_progress",
        ):
            value = clean_product_status_text(source.get(key))
            if value:
                parts.append(value)
        completed = source.get("last_two_completed_tasks")
        if isinstance(completed, list):
            parts.extend(clean_product_status_text(item) for item in completed)
    if isinstance(presence_snapshot, dict):
        parts.append(clean_product_status_text(presence_snapshot.get("command_preview")))
        changed_files = presence_snapshot.get("changed_files")
        if isinstance(changed_files, list):
            parts.extend(clean_product_status_text(path) for path in changed_files)
    return " ".join(part for part in parts if part)


def _matches_item(item: PlanItem, text: str) -> bool:
    item_terms = set(_project_query_terms(item.text))
    text_terms = set(_project_query_terms(text))
    if not item_terms or not text_terms:
        return False
    overlap = item_terms & text_terms
    if len(overlap) >= min(3, len(item_terms)):
        return True
    if item_terms and len(overlap) / len(item_terms) >= 0.5:
        return True
    normalized_item = _normalize_text(item.text)
    normalized_text = _normalize_text(text)
    return bool(normalized_item and normalized_item in normalized_text)


def _plain_plan_item_text(text: str) -> str:
    cleaned = re.sub(r"[*`#]+", "", text).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = re.sub(r"^\[[ xX]\]\s*", "", cleaned)
    code_pattern = (
        r"^(?P<code>(?:S|PR)-[A-Z]|[hb]-\d{1,4}|[HB]-\d{1,4})\b"
        r"(?:\s*\([^)]*\))?\s*[:\-\u2013\u2014]\s*(?P<body>.+)$"
    )
    match = re.match(code_pattern, cleaned)
    if match:
        return match.group("body").strip()
    paren_code_pattern = r"^(?P<body>.+?)\s*\((?:S|PR)-[A-Z]\)\s*$"
    match = re.match(paren_code_pattern, cleaned)
    if match:
        return match.group("body").strip()
    return cleaned


def _yaml_plan_label_from_window(lines: list[str], status_index: int) -> str | None:
    start = max(0, status_index - 8)
    window = lines[start : status_index + 1]
    fields: dict[str, str] = {}
    for raw in window:
        stripped = raw.strip().strip("-").strip()
        match = re.match(r"(id|name|title|summary|description)\s*:\s*(.+)$", stripped)
        if not match:
            continue
        value = match.group(2).strip().strip("'\"")
        if value:
            fields[match.group(1)] = value
    body = fields.get("name") or fields.get("title") or fields.get("summary")
    if not body:
        body = fields.get("description")
    return body or fields.get("id")


def _project_context_file_score(path: Path) -> int:
    name = path.name.lower()
    relative = str(path).lower()
    parts = tuple(part.lower() for part in path.parts)
    score = 0
    if name == "claude.md":
        score += 900
    if name == "experiment.yaml" and "experiment" in parts:
        score += 850
    if relative.endswith(("/docs/project-state.md", "/docs/project_state.md")):
        score += 840
    if relative.endswith(("/docs/master-plan.md", "/docs/master_plan.md")):
        score += 780
    if relative.endswith(
        (
            "/docs/status.md",
            "/docs/plan.md",
            "/docs/todo.md",
            "/docs/handover.md",
            "/docs/roadmap.md",
        )
    ):
        score += 760
    if name in {"product.md", "product.yaml", "product.yml", "spec.md"}:
        score += 760
    if name in {"handover.md", "plan.md", "todo.md", "status.md"}:
        score += 700
    if "plan" in name:
        score += 80
    elif name == "readme.md":
        score += 120
    elif name in {"agents.md"}:
        score += 60
    return score


def _project_authority_file_score(project_dir: Path, path: Path) -> int:
    relative = _relative_path(path, project_dir).lower()
    name = path.name.lower()
    if relative == "claude.md":
        return 1_000
    if relative in {"experiment/experiment.yaml", "experiment/experiment.yml"}:
        return 950
    if relative in {"docs/project-state.md", "docs/project_state.md"}:
        return 925
    if relative in {"status.md", "todo.md", "handover.md", "plan.md"}:
        return 900
    if relative in {
        "docs/status.md",
        "docs/plan.md",
        "docs/todo.md",
        "docs/handover.md",
    }:
        return 890
    if relative in {"docs/master-plan.md", "docs/master_plan.md", "docs/roadmap.md"}:
        return 875
    if name in {
        "product.md",
        "product.yaml",
        "product.yml",
        "spec.md",
        "spec.yaml",
        "spec.yml",
    }:
        return 850
    return 0


def _is_product_authority_candidate(project_dir: Path, path: Path) -> bool:
    relative = _relative_path(path, project_dir).lower()
    name = path.name.lower()
    return (
        relative == "claude.md"
        or relative in {"experiment/experiment.yaml", "experiment/experiment.yml"}
        or relative
        in {
            "docs/project-state.md",
            "docs/project_state.md",
            "docs/master-plan.md",
            "docs/master_plan.md",
            "docs/status.md",
            "docs/plan.md",
            "docs/todo.md",
            "docs/handover.md",
            "docs/roadmap.md",
            "status.md",
            "todo.md",
            "handover.md",
            "plan.md",
        }
        or name
        in {
            "product.md",
            "product.yaml",
            "product.yml",
            "spec.md",
            "spec.yaml",
            "spec.yml",
        }
    )


def _is_explicit_lower_authority_query(terms: list[str]) -> bool:
    return bool({"audit", "champion", "elevation", "quality", "world"} & set(terms))


def _is_lower_authority_project_context(path: Path) -> bool:
    relative = str(path).lower()
    return (
        "world-champion" in relative
        or "quality-elevation" in relative
        or "/.claude/commands/" in relative
        or "/.claude/patterns/" in relative
    )


def _workspace_child_project_dirs(path: Path) -> list[Path]:
    try:
        children = [
            child
            for child in path.iterdir()
            if child.is_dir()
            and child.name not in _DISCOVERY_SKIP_DIRS
            and not child.name.startswith(".")
            and not child.name.endswith(".app")
        ]
    except OSError:
        return []
    children.sort(key=lambda child: child.name.lower())
    return children[:_DISCOVERY_CHILD_LIMIT]


def _iter_document_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            name
            for name in dirnames
            if name not in _DISCOVERY_SKIP_DIRS and not name.endswith(".app")
        ]
        current = Path(dirpath)
        for filename in filenames:
            path = current / filename
            if path.suffix.lower() in _DOCUMENT_EXTENSIONS:
                files.append(path)
    return files


def _project_query_terms(query: str) -> list[str]:
    terms = re.findall(r"[a-z0-9]+", query.lower())
    return [
        term
        for term in terms
        if len(term) > 1 and term not in _WORKSPACE_SEARCH_STOPWORDS
    ]


def _child_project_relevance_score(path: Path, terms: list[str]) -> int:
    name = _normalize_text(path.name)
    full_path = _normalize_text(str(path))
    name_tokens = frozenset(name.split())
    path_tokens = frozenset(full_path.split())
    score = 0
    normalized_query = " ".join(terms)
    if name == normalized_query:
        score += 160
    if normalized_query in name:
        score += 110
    if normalized_query in full_path:
        score += 70
    for phrase in _query_phrases(terms):
        if phrase in name:
            score += 50
        if phrase in full_path:
            score += 30
    for term in terms:
        if term in name_tokens:
            score += 35
        elif _fuzzy_token_match(term, name_tokens):
            score += 20
        if term in path_tokens:
            score += 15
    return score


def _query_phrases(terms: list[str]) -> list[str]:
    phrases: list[str] = []
    for width in (3, 2):
        if len(terms) < width:
            continue
        for index in range(0, len(terms) - width + 1):
            phrases.append(" ".join(terms[index : index + width]))
    return phrases


def _fuzzy_token_match(term: str, tokens: frozenset[str]) -> bool:
    if len(term) < 4:
        return False
    for token in tokens:
        if abs(len(token) - len(term)) > 2:
            continue
        if SequenceMatcher(None, term, token).ratio() >= 0.84:
            return True
    return False


def _status_priority(status: str) -> int:
    return {
        "blocked": 0,
        "in_progress": 1,
        "active": 2,
        "pending": 3,
        "planned": 4,
        "completed": 5,
    }.get(status, 6)


def _item_key(text: str, source: str) -> str:
    terms = _project_query_terms(text)
    if terms:
        return " ".join(terms[:10])
    return f"{source}:{text.lower()}"


def _field(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if value in (None, "", []):
        return "(none)"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)


def _status_text(payload: dict[str, Any] | None, key: str) -> str:
    if not isinstance(payload, dict):
        return ""
    return clean_product_status_text(payload.get(key))


def _workspace_query_from_status(product_status: dict[str, Any] | None) -> str:
    focus = _status_text(product_status, "current_development_plan_focus")
    match = re.search(r"product or workspace '([^']+)'", focus)
    if match:
        return match.group(1)
    return ""


def _safe_read_text(path: Path, *, max_chars: int) -> str:
    try:
        return path.read_text(encoding="utf-8")[:max_chars]
    except OSError:
        return ""


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _relative_path(path: Path, base: Path) -> str:
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.name


def _relative_to_any(path: Path, bases: list[Path]) -> str:
    for base in bases:
        try:
            return f"{base.name}/{path.relative_to(base).as_posix()}"
        except ValueError:
            continue
    return str(path)


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    seen: set[Path] = set()
    out: list[Path] = []
    for path in paths:
        try:
            resolved = path.expanduser().resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        out.append(resolved)
    return out


def _dedupe_strings(values: list[str]) -> list[str]:
    out: list[str] = []
    for value in values:
        cleaned = clean_product_status_text(value)
        if cleaned and cleaned not in out:
            out.append(cleaned)
    return out


def _normalize_text(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))
