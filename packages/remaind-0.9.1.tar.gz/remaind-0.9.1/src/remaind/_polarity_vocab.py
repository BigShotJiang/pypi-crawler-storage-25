"""Shared polarity, return-signal, reason, and topic helpers.

Remaind uses these helpers for both product memory extraction and benchmark
evidence rendering so that preference state is classified once, consistently.
"""

from __future__ import annotations

import re
from typing import Literal

Polarity = Literal["positive", "negative", "neutral"]

NEGATIVE_TERMS = (
    "abandoned",
    "annoying",
    "avoid",
    "boring",
    "can't stand",
    "cannot stand",
    "cancel",
    "decided to step back",
    "did not engage",
    "did not match",
    "did not mesh",
    "did not resonate",
    "did not stick",
    "didn't engage",
    "didn't match",
    "didn't mesh",
    "didn't quite mesh",
    "didn't resonate",
    "didn't sit well",
    "didn't stick",
    "discontinued",
    "dislike",
    "disliked",
    "disliking",
    "do not enjoy",
    "do not feel that connection",
    "don't enjoy",
    "don't feel that connection",
    "fed up",
    "felt formulaic",
    "found it hard to engage",
    "found it unfulfilling",
    "found myself skipping",
    "gave up",
    "hate",
    "hated",
    "lacked depth",
    "less engaged",
    "less engaging",
    "less enjoyable",
    "lost interest",
    "more like a chore",
    "never enjoyed",
    "no longer enjoy",
    "no longer find",
    "not being objective",
    "not for me",
    "not fond",
    "not ideal",
    "not into",
    "not my thing",
    "not really my thing",
    "not really the ideal fit",
    "not resonate",
    "overly formal",
    "rather not",
    "rigid",
    "stopped",
    "stepped back",
    "stressful",
    "tedious",
    "tired of",
    "too time-consuming",
    "turned out to be more stressful",
    "was not a fan",
    "was not fond",
    "wasn't a fan",
    "wasn't fond",
    "weary of",
)

POSITIVE_TERMS = (
    "adore",
    "adored",
    "appreciate",
    "became actively involved",
    "became interested",
    "crazy about",
    "creative",
    "decided to give",
    "decided to rejoin",
    "drawn to",
    "embraced",
    "enjoy",
    "enjoyed",
    "even started",
    "excited",
    "excited about",
    "excited by",
    "favorite",
    "favourite",
    "focus on",
    "fond of",
    "formed a partnership",
    "genuinely enjoy",
    "i am interested",
    "i enjoy",
    "i like",
    "i love",
    "i prefer",
    "i switched my focus",
    "i want",
    "i'm interested",
    "interested",
    "into",
    "keen on",
    "liked",
    "love",
    "obsessed with",
    "passionate about",
    "positive feedback",
    "received positive",
    "re-engaged",
    "rejoined",
    "renewed enthusiasm",
    "restarted",
    "returned",
    "returned to",
    "revived",
    "started",
    "started listening",
    "surprisingly",
    "thrilled",
    "transitioned",
)

NEUTRAL_TRY_TERMS = (
    "dabbled in",
    "experimented with",
    "gave it a shot",
    "tried but",
    "tried creating",
    "tried reading",
)

RETURN_TERMS = (
    "came back to",
    "got back into",
    "picked back up",
    "re-engaged",
    "rejoined",
    "rekindled",
    "renewed",
    "restarted",
    "returned",
    "returned to",
    "resumed",
    "revived",
)

_TOPIC_STOPWORDS = {
    "about",
    "actively",
    "after",
    "again",
    "also",
    "another",
    "because",
    "became",
    "being",
    "cannot",
    "could",
    "decided",
    "different",
    "enjoy",
    "enjoyed",
    "excited",
    "explore",
    "feeling",
    "finally",
    "focus",
    "found",
    "from",
    "gave",
    "getting",
    "hard",
    "have",
    "interested",
    "joined",
    "like",
    "liked",
    "looking",
    "more",
    "much",
    "myself",
    "really",
    "recently",
    "resumed",
    "started",
    "stopped",
    "that",
    "this",
    "thinking",
    "through",
    "tried",
    "trying",
    "want",
    "with",
}


def classify_polarity(text: str) -> Polarity:
    """Classify explicit user sentiment while preferring negatives on conflict."""

    normalized = _normalize(text)
    if any(_contains_term(normalized, term) for term in NEGATIVE_TERMS):
        return "negative"
    if any(_contains_term(normalized, term) for term in POSITIVE_TERMS):
        return "positive"
    return "neutral"


def has_return_signal(text: str) -> bool:
    """Return whether text explicitly signals a revived or resumed preference."""

    normalized = _normalize(text)
    return any(_contains_term(normalized, term) for term in RETURN_TERMS)


def extract_reason_clause(text: str) -> str:
    """Extract the explicit reason clause from a user statement, if present."""

    cleaned = re.sub(r"\s+", " ", str(text).replace("\u2019", "'")).strip()
    patterns = (
        r"\bbecause\s+(.+)",
        r"\bdue to\s+(.+)",
        r"\bsince\s+(.+)",
        r"\bso that\s+(.+)",
        r"\bprompted by\s+(.+)",
        r"\bmotivated by\s+(.+)",
        r"\binspired by\s+(.+)",
        r"\bafter I\s+(.+)",
        r"\bafter realizing\s+(.+)",
        r"\bnow that\s+(.+)",
        r"\brealizing that\s+(.+)",
    )
    for pattern in patterns:
        match = re.search(pattern, cleaned, re.I)
        if match:
            return _trim_reason(match.group(1))
    return ""


def extract_topic_tokens(text: str) -> list[str]:
    """Return compact topic tokens suitable for preference matching."""

    normalized = _normalize(text)
    tokens = re.findall(r"[a-z][a-z0-9_-]{2,}", normalized)
    out: list[str] = []
    for token in tokens:
        if token in _TOPIC_STOPWORDS:
            continue
        if token in _all_marker_tokens():
            continue
        if token not in out:
            out.append(token)
    return out[:8]


def _trim_reason(reason: str) -> str:
    sentence = re.split(r"(?<=[.!?])\s+", reason.strip(), maxsplit=1)[0]
    return sentence.strip()[:260]


def _normalize(text: str) -> str:
    return (
        str(text)
        .lower()
        .replace("\u2019", "'")
        .replace("\u2018", "'")
        .replace("\u201c", '"')
        .replace("\u201d", '"')
    )


def _contains_term(normalized_text: str, term: str) -> bool:
    normalized_term = _normalize(term)
    if not normalized_term:
        return False
    pattern = rf"(?<![a-z0-9]){re.escape(normalized_term)}(?![a-z0-9])"
    return re.search(pattern, normalized_text) is not None


def _all_marker_tokens() -> set[str]:
    tokens: set[str] = set()
    for term in NEGATIVE_TERMS + POSITIVE_TERMS + NEUTRAL_TRY_TERMS + RETURN_TERMS:
        tokens.update(re.findall(r"[a-z][a-z0-9_-]{2,}", _normalize(term)))
    return tokens
