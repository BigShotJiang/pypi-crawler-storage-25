"""Deterministic project-continuity benchmark.

This benchmark is Remaind-owned: it tests whether project continuity survives a
forced reset, stale generated answers, changed requirements, active blockers,
large local documents, rollback, and next-step reconstruction. It does not call
a model; the point is to prove the continuity substrate before model quality is
introduced as another variable.
"""

from __future__ import annotations

import json
import shutil
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ._benchmark import BenchmarkCheck, BenchmarkError
from ._continuity import (
    ContinuityScorecard,
    build_continuity_scorecard,
    build_evidence_map,
    record_decision,
)
from ._events import EventInput, EventWriter
from ._large_doc import ingest_large_document
from ._paths import ContextPaths
from ._plan_reconciliation import ensure_plan_reconciliation, load_plan_reconciliation
from ._product_status import ensure_product_status_seed
from ._progress import record_progress_snapshot
from ._resume_packet import build_resume_packet
from ._state_writer import update_state
from ._timestamps import utc_now_filename_safe_us
from .commands.init import run as init_context
from .commands.rollback import run as rollback_context

DEFAULT_CONTINUITY_WORKDIR = Path(".remaind_bench") / "continuity"


@dataclass(frozen=True)
class ProjectContinuityBenchmarkResult:
    workdir: Path
    scorecard: ContinuityScorecard
    resume_packet_path: Path
    large_doc_manifest: Path
    evidence_links: int
    checks: list[BenchmarkCheck] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(check.passed for check in self.checks)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["workdir"] = str(self.workdir)
        payload["scorecard"] = self.scorecard.to_dict()
        payload["resume_packet_path"] = str(self.resume_packet_path)
        payload["large_doc_manifest"] = str(self.large_doc_manifest)
        payload["checks"] = [asdict(check) for check in self.checks]
        payload["passed"] = self.passed
        return payload


def run_project_continuity_benchmark(
    workdir: Path = DEFAULT_CONTINUITY_WORKDIR,
    *,
    force: bool = False,
) -> ProjectContinuityBenchmarkResult:
    """Run the deterministic project-continuity benchmark."""

    workdir = Path(workdir).resolve()
    _prepare_workdir(workdir, force=force)
    init_context(workdir)
    project = _write_project(workdir)
    ensure_product_status_seed(workdir, workspace_query="continuity-bench")
    ensure_plan_reconciliation(workdir, workspace_query="continuity-bench")
    _append_stale_generated_answer(workdir)
    record_decision(
        workdir,
        text=(
            "Requirement changed: local-only relay replaces the older hosted "
            "relay idea for continuity benchmarking."
        ),
    )
    large_doc_manifest = Path(
        ingest_large_document(
            workdir,
            _write_large_doc(project),
            title="Continuity benchmark source manual",
        ).manifest_path
    )
    record_progress_snapshot(
        workdir,
        operation_id="continuity_benchmark_completed_scope",
        phase="completed",
        task="Capture product scope",
        metadata={"workspace_query": "continuity-bench"},
    )
    record_progress_snapshot(
        workdir,
        operation_id="continuity_benchmark_blocked_relay",
        phase="blocked",
        task="Build local relay for offline continuity",
        model_error="relay port already allocated during integration test",
        metadata={"workspace_query": "continuity-bench"},
    )
    rollback_restored = _prove_rollback(workdir)
    packet = build_resume_packet(workdir)
    paths = ContextPaths.at(workdir)
    paths.resume_packet.write_text(packet.content, encoding="utf-8")
    scorecard = build_continuity_scorecard(workdir)
    evidence = build_evidence_map(workdir)
    evidence_text = json.dumps(
        [link.to_dict() for link in evidence],
        sort_keys=True,
    ).lower()
    plan = load_plan_reconciliation(workdir) or {}
    packet_text = packet.content
    next_step = str(plan.get("aligned_next_plan_step") or "")
    checks = [
        _check(
            "forced-reset-resume-packet",
            "## Product Plan Reconciliation" in packet_text
            and "Build local relay for offline continuity" in packet_text,
            "fresh resume packet includes mandatory plan reconciliation",
        ),
        _check(
            "stale-generated-answer-demoted",
            "hosted relay" not in next_step.lower()
            and "local relay" in json.dumps(plan).lower(),
            "stale generated answer did not override current product plan",
        ),
        _check(
            "blocker-recovery-path",
            "relay port already allocated" in scorecard.blocker
            and scorecard.next_step.startswith("Fix the current blocker"),
            "active blocker drives the next action before ordinary plan work",
        ),
        _check(
            "changed-requirement-current",
            "local-only relay replaces" in evidence_text,
            "changed requirement is represented as source evidence",
        ),
        _check(
            "large-doc-source-linked",
            large_doc_manifest.is_file(),
            f"large local document manifest exists at {large_doc_manifest}",
        ),
        _check(
            "rollback-integrity",
            rollback_restored,
            "rollback restored a derived state snapshot and appended a rollback event",
        ),
        _check(
            "continuity-scorecard-passable",
            scorecard.overall_score >= 0.75
            and any(metric.key == "source_coverage" for metric in scorecard.metrics),
            f"scorecard produced transparent continuity metrics ({scorecard.overall_score:.2f})",
        ),
        _check(
            "evidence-map-linked",
            any(link.relationship == "blocker -> failed command/result" for link in evidence)
            and any(link.relationship == "plan item -> source line" for link in evidence),
            "evidence map links blocker and plan claims to source artifacts",
        ),
    ]
    return ProjectContinuityBenchmarkResult(
        workdir=workdir,
        scorecard=scorecard,
        resume_packet_path=paths.resume_packet,
        large_doc_manifest=large_doc_manifest,
        evidence_links=len(evidence),
        checks=checks,
    )


def _prepare_workdir(workdir: Path, *, force: bool) -> None:
    if workdir.exists() and force:
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    if ContextPaths.at(workdir).root.exists():
        raise BenchmarkError(
            f"{ContextPaths.at(workdir).root} already exists; pass --force to replace it"
        )


def _write_project(workdir: Path) -> Path:
    project = workdir / "continuity-bench"
    project.mkdir(parents=True)
    (project / "PLAN.md").write_text(
        "\n".join(
            [
                "# Continuity Benchmark Product Plan",
                "",
                "- [x] Capture product scope",
                "- [ ] Build local relay for offline continuity",
                "- [ ] Add adapter export for coding agents",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (project / "STATUS.md").write_text(
        "\n".join(
            [
                "# Status",
                "",
                "Immediate next step: Build local relay for offline continuity",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return project


def _write_large_doc(project: Path) -> Path:
    path = project / "SOURCE_MANUAL.md"
    lines = ["# Continuity Benchmark Manual", ""]
    for index in range(1, 220):
        lines.append(
            f"Manual line {index:03d}: local continuity evidence should stay "
            "source-linked after reset."
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _append_stale_generated_answer(base: Path) -> None:
    state = json.loads(ContextPaths.at(base).state_json.read_text(encoding="utf-8"))
    EventWriter.open(base).append(
        EventInput(
            type="assistant_message",
            actor="assistant",
            summary="Stale generated answer claims the hosted relay is next",
            content=(
                "Outdated answer: the next step is to build a hosted relay. "
                "This answer is intentionally stale and must not override the "
                "current product plan."
            ),
            importance=2,
            session_id=str(state["session_id"]),
            task_id=str(state["task_id"]),
            tags=["benchmark", "stale-answer"],
            source="continuity benchmark fixture",
        )
    )


def _prove_rollback(base: Path) -> bool:
    update_state(base, lambda state: {**state, "next_step": "rollback proof v1"})
    time.sleep(0.002)
    target = utc_now_filename_safe_us()
    time.sleep(0.002)
    update_state(base, lambda state: {**state, "next_step": "rollback proof v2"})
    result = rollback_context(base, target=target)
    return "state" in result.restored and bool(result.rollback_event_id)


def _check(name: str, condition: bool, detail: str) -> BenchmarkCheck:
    return BenchmarkCheck(name=name, passed=bool(condition), detail=detail)
