"""Markdown rendering for engineered model context."""

from __future__ import annotations

from ._context_budget import ContextSelection
from ._context_intent import ContextIntent
from ._context_sources import AUTHORITY_ORDER


def render_context_packet(
    *,
    question: str,
    workspace_query: str | None,
    intent: ContextIntent,
    selection: ContextSelection,
) -> str:
    """Render selected context sources into a model-facing Markdown packet."""

    rows = [
        "# Remaind Memory Question Source",
        "",
        "This temporary source is generated for one interactive memory question.",
        (
            "Current launch status and current terminal conversation are newer "
            "than stored packet/history content."
        ),
        "",
    ]
    rows.extend(
        render_context_decision_section(
            question=question,
            workspace_query=workspace_query,
            intent=intent,
            selection=selection,
        ).rstrip().splitlines()
    )
    rows.extend(
        [
            "",
            "## Current Question",
            "",
            question.strip(),
            "",
        ]
    )
    for source in selection.selected:
        if source.source_type == "current_question":
            continue
        rows.append(source.content.rstrip())
        rows.append("")
    return "\n".join(rows).rstrip() + "\n"


def render_context_decision_section(
    *,
    question: str,
    workspace_query: str | None,
    intent: ContextIntent,
    selection: ContextSelection,
) -> str:
    """Render the reusable context-engine trace section."""

    rows = [
        "## Context Engineering Decision",
        "",
        f"- Intent: {intent.kind}",
        f"- Reason: {intent.reason}",
        f"- Workspace query: {workspace_query or '(none)'}",
        f"- Token budget: {selection.budget.selected_tokens}/{selection.budget.token_cap}",
        f"- Mandatory source tokens: {selection.budget.mandatory_tokens}",
        "",
        "## Context Authority Rules",
        "",
        (
            "Use higher-authority and fresher evidence over lower-authority or "
            "older evidence when sources conflict."
        ),
    ]
    for index, authority in enumerate(AUTHORITY_ORDER, start=1):
        rows.append(f"{index}. {authority.replace('_', ' ')}")
    rows.extend(
        [
            "",
            "## Context Trace",
            "",
        ]
    )
    for source in selection.selected:
        marker = "mandatory" if source.mandatory else "selected"
        path = f"; path={source.path}" if source.path is not None else ""
        rows.append(
            f"- {marker}: {source.id} ({source.source_type}, "
            f"authority={source.authority}, freshness={source.freshness}, "
            f"tokens={source.token_count}{path}) — {source.reason}"
        )
    if selection.omitted:
        rows.extend(["", "## Omitted Evidence", ""])
        for omitted_source in selection.omitted:
            rows.append(
                f"- {omitted_source.id} ({omitted_source.source_type}, "
                f"tokens={omitted_source.token_count}): {omitted_source.reason}"
            )
    return "\n".join(rows).rstrip() + "\n"
