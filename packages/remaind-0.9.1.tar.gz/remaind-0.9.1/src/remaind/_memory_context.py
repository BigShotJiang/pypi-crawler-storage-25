"""Context-source adapters for structured memory records."""

from __future__ import annotations

from pathlib import Path

from ._context_sources import ContextSource
from ._memory_records import (
    MemoryRecord,
    backfill_memory_records,
    render_memory_records,
    search_memory_records,
)


def structured_memory_context_sources(
    base: Path,
    *,
    question: str,
    limit: int = 10,
) -> list[ContextSource]:
    """Return structured memory records as context-engine sources."""

    backfill_memory_records(base)
    records = search_memory_records(
        base,
        question,
        limit=limit,
    )
    if not records:
        return []
    return [
        ContextSource(
            id="structured_memory_records",
            title="Structured Memory Records",
            source_type="memory_record",
            authority="derived_memory",
            freshness="recent",
            content=render_memory_records(
                records,
                title="Structured Continuity Memory",
            ),
            mandatory=False,
            reason=(
                "Structured who/what/when/where/why/how records preserve "
                "decisions, notes, blockers, tasks, and preferences with sources."
            ),
            budget_group="memory",
        )
    ]


def memory_record_context_source(
    records: list[MemoryRecord],
    *,
    source_id: str = "structured_memory_records",
    title: str = "Structured Memory Records",
    mandatory: bool = False,
) -> ContextSource | None:
    if not records:
        return None
    return ContextSource(
        id=source_id,
        title=title,
        source_type="memory_record",
        authority="derived_memory",
        freshness="recent",
        content=render_memory_records(records, title=title),
        mandatory=mandatory,
        reason="Structured memory records provide source-linked continuity state.",
        budget_group="memory",
    )
