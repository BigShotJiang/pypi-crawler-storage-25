"""Hierarchical document extraction for large source files.

This is document compaction: a large local file is chunked, summarized into
validated source-linked records, reduced, and expanded back into exact line
evidence for ``remaind run``. It is distinct from ``_compaction.py`` (handover
status), ``_compactor.py`` (the event-log Compactor protocol), and
``_local_compactor.py`` (model-backed handover compaction). The extractor here
does not implement the handover Compactor protocol because it consumes source
document lines and produces evidence artifacts, not a new handover.

The implementation is split across focused ``_doc_*`` modules:
``_doc_planner`` plans line-range chunks, ``_doc_extractor`` handles per-chunk
model output, ``_doc_normalizers`` contains guarded model-output rewrites,
``_doc_reducer`` performs group/global reduction and evidence rendering, and
``_doc_cache`` owns shared cache identity and result types.

Interrupted runs raise ``DocumentCompactionInterrupted`` after preserving the
baseline run packet and resumable cursor, so operators can continue with
``--reuse-deep-compact`` instead of restarting the whole source file.
"""

from __future__ import annotations

import hashlib
import json
import os
import signal
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._doc_cache import (
    AUTHORITY_ORDER as AUTHORITY_ORDER,
)
from ._doc_cache import (
    CHUNK_EXTRACT_PROMPT_VERSION as CHUNK_EXTRACT_PROMPT_VERSION,
)
from ._doc_cache import (
    DEEP_COMPACT_CHUNK_TOKENS_ENV as DEEP_COMPACT_CHUNK_TOKENS_ENV,
)
from ._doc_cache import (
    DEEP_COMPACTION_RECOMMENDED_TOKENS as DEEP_COMPACTION_RECOMMENDED_TOKENS,
)
from ._doc_cache import (
    GLOBAL_REDUCE_PROMPT_VERSION as GLOBAL_REDUCE_PROMPT_VERSION,
)
from ._doc_cache import (
    GROUP_REDUCE_PROMPT_VERSION as GROUP_REDUCE_PROMPT_VERSION,
)
from ._doc_cache import (
    PROGRESS_TAG,
    DeepCompactionResult,
    DocumentCompactionError,
    DocumentCompactionInterrupted,
    DocumentTextModel,
    _cache_key,
    _find_cached_run,
    _find_resumable_run,
    _load_json,
    _model_from_env_or_injected,
    _read_jsonl_objects,
    _run_root,
)
from ._doc_cache import (
    SUPPORT_TYPES as SUPPORT_TYPES,
)
from ._doc_cache import (
    prompt_file_hash as prompt_file_hash,
)
from ._doc_extractor import (
    _halve_chunk,
    _has_split_children,
    _process_chunk,
    _processed_chunk_ids,
    _update_topic_index,
)
from ._doc_planner import (
    ChunkPlan as ChunkPlan,
)
from ._doc_planner import (
    _chunk_token_target,
    _load_chunk_plan,
    plan_chunks,
)
from ._doc_reducer import (
    _reduce_global,
    _reduce_groups,
    _validate_group_and_global,
    build_evidence_block,
)
from ._events import EventInput, EventWriter
from ._jsonl import append_jsonl
from ._large_doc import LargeDocumentError, LargeDocumentIngestResult, verify_large_document
from ._paths import ContextPaths
from ._redaction import Redactor
from ._schemas import ensure_bundled_schemas
from ._timestamps import utc_now_iso
from ._ulid import new_ulid


def _write_manifest(run_dir: Path, manifest: dict[str, Any]) -> None:
    atomic_write_text(
        run_dir / "manifest.json",
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
    )

def _verify_ingested_source(base: Path, document_path: Path) -> None:
    try:
        verify_large_document(base, document_path)
    except LargeDocumentError as exc:
        raise DocumentCompactionError(str(exc)) from exc

def _preflight_model(model: DocumentTextModel) -> None:
    smoke_test = getattr(model, "smoke_test", None)
    if not callable(smoke_test):
        return
    result = smoke_test()
    if bool(result.get("ok")):
        return
    error = str(result.get("error") or "model generation smoke test failed")
    raise DocumentCompactionError(
        "deep compaction local model preflight failed: "
        f"{error}. Run `remaind doctor --smoke` or select a working model."
    )

def _completed_result(run_dir: Path, *, reused: bool, evidence_block: str | None = None) -> DeepCompactionResult:
    manifest = _load_json(run_dir / "manifest.json") or {}
    failures = _read_jsonl_objects(run_dir / "failures.jsonl")
    quarantined = _read_jsonl_objects(run_dir / "quarantined.jsonl")
    reducer_fallbacks = [
        str(item)
        for item in (manifest.get("reducer_fallbacks") or [])
        if isinstance(item, str)
    ]
    global_summary = _load_json(run_dir / "global_summary.json")
    if evidence_block is None and global_summary is not None:
        document_path = Path(str(manifest.get("document_path") or ""))
        evidence_block = build_evidence_block(
            document_path=document_path,
            global_summary=global_summary,
            failures=failures,
            quarantined=quarantined,
            reducer_fallbacks=reducer_fallbacks,
        )
    return DeepCompactionResult(
        doc_id=str(manifest.get("doc_id") or ""),
        run_id=str(manifest.get("run_id") or run_dir.name),
        run_dir=str(run_dir),
        manifest_path=str(run_dir / "manifest.json"),
        cache_key=str(manifest.get("cache_key") or ""),
        reused=reused,
        status=str(manifest.get("status") or "completed"),
        chunks_total=int(manifest.get("chunks_total") or 0),
        chunks_succeeded=int(manifest.get("chunks_succeeded") or 0),
        chunks_failed=len(failures),
        chunks_quarantined=len(quarantined),
        evidence_block=evidence_block or "",
        failures=failures,
        quarantined=quarantined,
        reducer_fallbacks=reducer_fallbacks,
        global_summary=global_summary,
    )

def _load_session_ids(base: Path) -> tuple[str, str]:
    paths = ContextPaths.at(base)
    state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    return str(state["session_id"]), str(state["task_id"])

def _maybe_emit_progress(
    base: Path,
    *,
    chunk_index: int,
    total: int,
    run_id: str,
    doc_id: str,
    final: bool = False,
    totals: dict[str, Any] | None = None,
) -> None:
    debug = bool(os.environ.get("REMAIND_DEEP_COMPACT_DEBUG", "").strip())
    cadence = max(1, min(25, total // 10 or 1))
    if not final and not debug and chunk_index % cadence != 0:
        return
    session_id, task_id = _load_session_ids(base)
    content = json.dumps(
        {
            "run_id": run_id,
            "doc_id": doc_id,
            "chunk_index": chunk_index,
            "chunks_total": total,
            "final": final,
            "totals": totals or {},
        },
        sort_keys=True,
    )
    EventWriter.open(base).append(
        EventInput(
            type="tool_result",
            actor="tool:remaind-deep-compact",
            summary=(
                "Deep document compaction complete"
                if final
                else f"Deep document compaction progress {chunk_index}/{total}"
            ),
            content=content,
            session_id=session_id,
            task_id=task_id,
            importance=0,
            tags=[PROGRESS_TAG, "deep_compaction", doc_id, run_id],
            metadata={
                "run_id": run_id,
                "doc_id": doc_id,
                "chunk_index": chunk_index,
                "chunks_total": total,
                "final": final,
                "totals": totals or {},
            },
        )
    )

def _raise_keyboard_interrupt(signum: int, frame: Any) -> None:
    _ = (signum, frame)
    raise KeyboardInterrupt

@contextmanager
def _sigterm_as_interrupt() -> Iterator[None]:
    if threading.current_thread() is not threading.main_thread():
        yield
        return
    previous = signal.getsignal(signal.SIGTERM)
    signal.signal(signal.SIGTERM, _raise_keyboard_interrupt)
    try:
        yield
    finally:
        signal.signal(signal.SIGTERM, previous)

def execute_deep_compaction(
    *,
    base: Path,
    document_path: Path,
    task: str,
    ingest: LargeDocumentIngestResult,
    num_ctx: int | None = None,
    mode: str = "lenient",
    reuse: bool = False,
    model: DocumentTextModel | None = None,
    progress: Callable[[str], None] | None = None,
    chunk_tokens: int | None = None,
) -> DeepCompactionResult:
    """Run or reuse a deep-compaction artifact tree for one document/task."""

    if mode not in {"lenient", "strict"}:
        raise DocumentCompactionError("--deep-compact-mode must be lenient or strict")
    base = Path(base).expanduser().resolve()
    document_path = Path(document_path).expanduser().resolve()
    ensure_bundled_schemas(base)
    _verify_ingested_source(base, document_path)
    chunk_token_target = _chunk_token_target(num_ctx, chunk_tokens=chunk_tokens)
    cache_key = _cache_key(
        source_hash=ingest.stats.sha256,
        task=task,
        model=model,
        num_ctx=num_ctx,
        chunk_token_target=chunk_token_target,
    )
    if reuse:
        cached = _find_cached_run(base, ingest.stats.doc_id, cache_key)
        if cached is not None:
            return _completed_result(cached, reused=True)
        resumable = _find_resumable_run(base, ingest.stats.doc_id, cache_key)
    else:
        resumable = None

    selected_model = _model_from_env_or_injected(model)
    _preflight_model(selected_model)
    started = time.monotonic()
    if resumable is not None:
        run_dir = resumable
        manifest = _load_json(run_dir / "manifest.json") or {}
        run_id = str(manifest.get("run_id") or run_dir.name)
        chunks = _load_chunk_plan(run_dir / "chunks.jsonl")
        chunk_summaries = _read_jsonl_objects(run_dir / "chunk_summaries.jsonl")
        failures = _read_jsonl_objects(run_dir / "failures.jsonl")
        quarantined = _read_jsonl_objects(run_dir / "quarantined.jsonl")
        succeeded = len(chunk_summaries)
        manifest.update(
            {
                "status": "running",
                "updated_at": utc_now_iso(),
                "chunks_total": len(chunks),
                "chunks_succeeded": succeeded,
                "chunks_failed": len(failures),
                "chunks_quarantined": len(quarantined),
                "chunk_token_target": chunk_token_target,
                "resumed_at": utc_now_iso(),
            }
        )
        _write_manifest(run_dir, manifest)
    else:
        run_id = f"deep_{new_ulid()}"
        run_dir = _run_root(base, ingest.stats.doc_id) / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        chunks = plan_chunks(
            document_path,
            num_ctx=num_ctx,
            chunk_tokens=chunk_token_target,
        )
        for chunk in chunks:
            append_jsonl(run_dir / "chunks.jsonl", chunk.to_dict())
        manifest = {
            "schema_version": "deep_compaction_run_v1",
            "run_id": run_id,
            "doc_id": ingest.stats.doc_id,
            "document_path": ingest.stats.path,
            "source_hash": ingest.stats.sha256,
            "task_fingerprint": hashlib.sha256(task.strip().encode("utf-8")).hexdigest(),
            "cache_key": cache_key,
            "status": "running",
            "created_at": utc_now_iso(),
            "updated_at": utc_now_iso(),
            "cursor": 0,
            "chunks_total": len(chunks),
            "chunks_succeeded": 0,
            "chunk_token_target": chunk_token_target,
            "model_label": getattr(selected_model, "label", "local model"),
            "prompt_versions": [
                CHUNK_EXTRACT_PROMPT_VERSION,
                GROUP_REDUCE_PROMPT_VERSION,
                GLOBAL_REDUCE_PROMPT_VERSION,
            ],
            "authority_order": list(AUTHORITY_ORDER),
        }
        _write_manifest(run_dir, manifest)
        chunk_summaries = []
        failures = []
        quarantined = []
        succeeded = 0

    processed_ids = _processed_chunk_ids(
        summaries=chunk_summaries,
        failures=failures,
        quarantined=quarantined,
    )
    chunks_to_process = [
        chunk
        for chunk in chunks
        if chunk.chunk_id not in processed_ids
        and not _has_split_children(chunk.chunk_id, chunks)
    ]
    planned_total = len(chunks)
    processed_before = planned_total - len(chunks_to_process)
    index = processed_before
    if progress is not None:
        action = "resuming" if resumable is not None else "starting"
        progress(
            f"Deep compaction: {action} {len(chunks_to_process)}/"
            f"{planned_total} chunk(s) in {run_dir}"
        )
    with _sigterm_as_interrupt():
        try:
            for chunk in chunks_to_process:
                index += 1
                if progress is not None:
                    progress(
                        f"Deep compaction: chunk {index}/{planned_total} "
                        f"{chunk.chunk_id} lines {chunk.line_start}-{chunk.line_end}"
                    )
                summary, failure, quarantine = _process_chunk(
                    base=base,
                    model=selected_model,
                    task=task,
                    ingest=ingest,
                    document_path=document_path,
                    chunk=chunk,
                )
                if summary is not None:
                    append_jsonl(run_dir / "chunk_summaries.jsonl", summary)
                    _update_topic_index(run_dir / "topic_index.jsonl", summary)
                    chunk_summaries.append(summary)
                    succeeded += 1
                    processed_ids.add(chunk.chunk_id)
                elif quarantine is not None:
                    append_jsonl(run_dir / "quarantined.jsonl", quarantine)
                    quarantined.append(quarantine)
                    processed_ids.add(chunk.chunk_id)
                elif failure is not None:
                    halves = _halve_chunk(chunk)
                    recovered = False
                    if halves:
                        planned_total += len(halves)
                        for half in halves:
                            if half.chunk_id not in {item.chunk_id for item in chunks}:
                                append_jsonl(run_dir / "chunks.jsonl", half.to_dict())
                                chunks.append(half)
                            half_summary, half_failure, half_quarantine = _process_chunk(
                                base=base,
                                model=selected_model,
                                task=task,
                                ingest=ingest,
                                document_path=document_path,
                                chunk=half,
                            )
                            if half_summary is not None:
                                append_jsonl(run_dir / "chunk_summaries.jsonl", half_summary)
                                _update_topic_index(run_dir / "topic_index.jsonl", half_summary)
                                chunk_summaries.append(half_summary)
                                succeeded += 1
                                recovered = True
                                processed_ids.add(half.chunk_id)
                            elif half_quarantine is not None:
                                append_jsonl(run_dir / "quarantined.jsonl", half_quarantine)
                                quarantined.append(half_quarantine)
                                processed_ids.add(half.chunk_id)
                            elif half_failure is not None:
                                append_jsonl(run_dir / "failures.jsonl", half_failure)
                                failures.append(half_failure)
                                processed_ids.add(half.chunk_id)
                    if not recovered and not halves:
                        append_jsonl(run_dir / "failures.jsonl", failure)
                        failures.append(failure)
                        processed_ids.add(chunk.chunk_id)
                manifest.update(
                    {
                        "cursor": index,
                        "updated_at": utc_now_iso(),
                        "chunks_succeeded": succeeded,
                        "chunks_failed": len(failures),
                        "chunks_quarantined": len(quarantined),
                        "chunks_total": planned_total,
                    }
                )
                _write_manifest(run_dir, manifest)
                _maybe_emit_progress(
                    base,
                    chunk_index=index,
                    total=planned_total,
                    run_id=run_id,
                    doc_id=ingest.stats.doc_id,
                )
                if progress is not None:
                    progress(
                        f"Deep compaction: persisted {succeeded} succeeded, "
                        f"{len(failures)} failed, {len(quarantined)} quarantined"
                    )
        except KeyboardInterrupt:
            manifest.update(
                {
                    "status": "interrupted",
                    "updated_at": utc_now_iso(),
                    "chunks_succeeded": succeeded,
                    "chunks_failed": len(failures),
                    "chunks_quarantined": len(quarantined),
                    "chunks_total": planned_total,
                }
            )
            _write_manifest(run_dir, manifest)
            raise DocumentCompactionInterrupted(
                "deep compaction interrupted; baseline packet and partial "
                f"run are preserved. Resume with --reuse-deep-compact. "
                f"Run directory: {run_dir}"
            ) from None

    if mode == "strict" and (failures or quarantined):
        manifest.update({"status": "failed", "updated_at": utc_now_iso()})
        _write_manifest(run_dir, manifest)
        raise DocumentCompactionError(
            f"deep compaction failed in strict mode: "
            f"{len(failures)} failed, {len(quarantined)} quarantined"
        )

    chunk_summaries = _read_jsonl_objects(run_dir / "chunk_summaries.jsonl")
    redactor = Redactor.from_config_path(ContextPaths.at(base).redaction_yaml)
    groups, group_fallbacks = _reduce_groups(
        model=selected_model,
        task=task,
        chunk_summaries=chunk_summaries,
        redactor=redactor,
    )
    for group in groups:
        append_jsonl(run_dir / "group_summaries.jsonl", group)
    global_summary, global_fallbacks = _reduce_global(
        model=selected_model,
        task=task,
        groups=groups,
        doc_id=ingest.stats.doc_id,
        source_hash=ingest.stats.sha256,
        line_count=ingest.stats.lines,
        redactor=redactor,
    )
    _validate_group_and_global(groups, global_summary)
    _verify_ingested_source(base, document_path)
    reducer_fallbacks = [*group_fallbacks, *global_fallbacks]
    atomic_write_text(
        run_dir / "global_summary.json",
        json.dumps(global_summary, indent=2, sort_keys=True) + "\n",
    )
    evidence_block = build_evidence_block(
        document_path=document_path,
        global_summary=global_summary,
        failures=failures,
        quarantined=quarantined,
        reducer_fallbacks=reducer_fallbacks,
    )
    final_status = "partial" if failures or quarantined else "completed"
    manifest.update(
        {
            "status": final_status,
            "updated_at": utc_now_iso(),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "chunks_succeeded": succeeded,
            "chunks_failed": len(failures),
            "chunks_quarantined": len(quarantined),
            "global_summary_path": str(run_dir / "global_summary.json"),
            "reducer_fallbacks": reducer_fallbacks,
        }
    )
    _write_manifest(run_dir, manifest)
    _maybe_emit_progress(
        base,
        chunk_index=planned_total,
        total=planned_total,
        run_id=run_id,
        doc_id=ingest.stats.doc_id,
        final=True,
        totals={
            "succeeded": succeeded,
            "failed": len(failures),
            "quarantined": len(quarantined),
            "elapsed_seconds": manifest["elapsed_seconds"],
        },
    )
    if progress is not None:
        progress(f"Deep compaction: {final_status} ({run_dir})")
    return _completed_result(run_dir, reused=False, evidence_block=evidence_block)
