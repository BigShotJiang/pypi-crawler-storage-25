"""Agent Memory Benchmark adapter installation.

AMB (Agent Memory Benchmark) evaluates memory systems through an external
provider registry. Remaind does not vendor AMB or its datasets; this module
installs a small provider into a local AMB checkout so official AMB runs can
use Remaind as the memory backend.
"""

from __future__ import annotations

import gzip
import json
import re
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

from ._atomic import atomic_write_text
from ._errors import RemaindError

AMB_PROVIDER_NAME = "remaind"
AMB_PROVIDER_FILENAME = "remaind.py"
AMB_REGISTRY_BEGIN = "# BEGIN REMAIND PROVIDER"
AMB_REGISTRY_END = "# END REMAIND PROVIDER"


class AMBBenchmarkError(RemaindError):
    """Raised when the AMB bridge cannot be installed or verified."""


@dataclass(frozen=True)
class AMBPrepareResult:
    amb_repo: Path
    provider_path: Path
    registry_path: Path
    remaind_source_path: Path
    provider_name: str = AMB_PROVIDER_NAME

    def to_dict(self) -> dict[str, str]:
        payload = asdict(self)
        return {key: str(value) for key, value in payload.items()}


@dataclass(frozen=True)
class AMBCategoryReport:
    category: str
    total: int
    correct: int
    accuracy: float
    avg_context_tokens: float
    avg_retrieve_time_ms: float
    structured_context_rate: float

    def to_dict(self) -> dict[str, int | float | str]:
        return asdict(self)


@dataclass(frozen=True)
class AMBQueryDiagnostic:
    query_id: str
    category: str
    correct: bool
    answer: str
    gold_answers: tuple[str, ...]
    context_tokens: int
    retrieve_time_ms: float
    answer_guidance: bool
    structured_context: bool
    selected_structured_context: bool
    option_alignment: bool
    source_evidence_count: int
    judge_reason: str

    def to_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload["gold_answers"] = list(self.gold_answers)
        return payload


@dataclass(frozen=True)
class AMBFailureTaxonomyItem:
    category: str
    failure_pattern: str
    query_id: str
    picked: str
    gold: str
    suspected_root_cause: str
    judge_reason: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class AMBFailureTaxonomy:
    result_path: Path
    total_failures: int
    items: tuple[AMBFailureTaxonomyItem, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "result_path": str(self.result_path),
            "total_failures": self.total_failures,
            "items": [item.to_dict() for item in self.items],
        }


@dataclass(frozen=True)
class AMBCategoryDelta:
    category: str
    baseline_total: int
    baseline_correct: int
    baseline_accuracy: float
    candidate_total: int
    candidate_correct: int
    candidate_accuracy: float
    accuracy_delta: float

    def to_dict(self) -> dict[str, int | float | str]:
        return asdict(self)


@dataclass(frozen=True)
class AMBDiffReport:
    baseline_path: Path
    candidate_path: Path
    baseline_correct: int
    baseline_total: int
    baseline_accuracy: float
    candidate_correct: int
    candidate_total: int
    candidate_accuracy: float
    accuracy_delta: float
    category_deltas: tuple[AMBCategoryDelta, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "baseline_path": str(self.baseline_path),
            "candidate_path": str(self.candidate_path),
            "baseline_correct": self.baseline_correct,
            "baseline_total": self.baseline_total,
            "baseline_accuracy": self.baseline_accuracy,
            "candidate_correct": self.candidate_correct,
            "candidate_total": self.candidate_total,
            "candidate_accuracy": self.candidate_accuracy,
            "accuracy_delta": self.accuracy_delta,
            "category_deltas": [item.to_dict() for item in self.category_deltas],
        }


@dataclass(frozen=True)
class AMBScoreReport:
    result_path: Path
    dataset: str
    split: str
    memory_provider: str
    mode: str
    run_name: str
    total_queries: int
    correct: int
    accuracy: float
    ingested_docs: int
    ingestion_time_ms: float
    avg_context_tokens: float
    avg_retrieve_time_ms: float
    answer_guidance_rate: float
    structured_context_rate: float
    category_reports: tuple[AMBCategoryReport, ...]
    diagnostics: tuple[AMBQueryDiagnostic, ...]
    warnings: tuple[str, ...]

    @property
    def failed_queries(self) -> tuple[AMBQueryDiagnostic, ...]:
        return tuple(item for item in self.diagnostics if not item.correct)

    def to_dict(self) -> dict[str, object]:
        return {
            "result_path": str(self.result_path),
            "dataset": self.dataset,
            "split": self.split,
            "memory_provider": self.memory_provider,
            "mode": self.mode,
            "run_name": self.run_name,
            "total_queries": self.total_queries,
            "correct": self.correct,
            "accuracy": self.accuracy,
            "ingested_docs": self.ingested_docs,
            "ingestion_time_ms": self.ingestion_time_ms,
            "avg_context_tokens": self.avg_context_tokens,
            "avg_retrieve_time_ms": self.avg_retrieve_time_ms,
            "answer_guidance_rate": self.answer_guidance_rate,
            "structured_context_rate": self.structured_context_rate,
            "category_reports": [
                category.to_dict() for category in self.category_reports
            ],
            "diagnostics": [item.to_dict() for item in self.diagnostics],
            "failed_queries": [item.to_dict() for item in self.failed_queries],
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True)
class AMBOfflineCategoryReport:
    category: str
    total: int
    offline_correct: int
    offline_accuracy: float
    answerer_correct: int
    answerer_accuracy: float
    rescued_failures: int
    introduced_risks: int

    def to_dict(self) -> dict[str, int | float | str]:
        return asdict(self)


@dataclass(frozen=True)
class AMBOfflineQueryDiagnostic:
    query_id: str
    category: str
    offline_pick: str
    answerer_pick: str
    gold_letters: tuple[str, ...]
    offline_correct: bool
    answerer_correct: bool

    def to_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload["gold_letters"] = list(self.gold_letters)
        return payload


@dataclass(frozen=True)
class AMBOfflineScoreReport:
    result_path: Path
    total_queries: int
    offline_correct: int
    offline_accuracy: float
    answerer_correct: int
    answerer_accuracy: float
    rescued_failures: int
    introduced_risks: int
    category_reports: tuple[AMBOfflineCategoryReport, ...]
    diagnostics: tuple[AMBOfflineQueryDiagnostic, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "result_path": str(self.result_path),
            "total_queries": self.total_queries,
            "offline_correct": self.offline_correct,
            "offline_accuracy": self.offline_accuracy,
            "answerer_correct": self.answerer_correct,
            "answerer_accuracy": self.answerer_accuracy,
            "rescued_failures": self.rescued_failures,
            "introduced_risks": self.introduced_risks,
            "category_reports": [item.to_dict() for item in self.category_reports],
            "diagnostics": [item.to_dict() for item in self.diagnostics],
        }


def prepare_amb(
    *,
    amb_repo: Path,
    remaind_source_path: Path | None = None,
) -> AMBPrepareResult:
    """Install Remaind as an AMB memory provider in a local checkout."""

    repo = Path(amb_repo).expanduser().resolve()
    _validate_amb_repo(repo)
    source_path = (
        Path(remaind_source_path).expanduser().resolve()
        if remaind_source_path is not None
        else Path(__file__).resolve().parents[1]
    )
    _validate_remaind_source_path(source_path)

    provider_path = repo / "src" / "memory_bench" / "memory" / AMB_PROVIDER_FILENAME
    registry_path = repo / "src" / "memory_bench" / "memory" / "__init__.py"
    atomic_write_text(
        provider_path,
        _render_amb_provider_source(source_path),
    )
    atomic_write_text(
        registry_path,
        _patch_amb_registry(registry_path.read_text(encoding="utf-8")),
    )
    return AMBPrepareResult(
        amb_repo=repo,
        provider_path=provider_path,
        registry_path=registry_path,
        remaind_source_path=source_path,
    )


def build_amb_score_report(result_path: Path) -> AMBScoreReport:
    """Build a transparent scorecard from an AMB JSON/JSON.GZ result file."""

    path = Path(result_path).expanduser().resolve()
    if not path.is_file():
        raise AMBBenchmarkError(f"AMB result file not found: {path}")
    payload = _read_json_result(path)
    results = payload.get("results")
    if not isinstance(results, list):
        raise AMBBenchmarkError("AMB result file is missing a results array")

    diagnostics = tuple(_query_diagnostic(item) for item in results if isinstance(item, dict))
    total = _int(payload.get("total_queries"), len(diagnostics))
    correct = _int(payload.get("correct"), sum(1 for item in diagnostics if item.correct))
    accuracy = _float(
        payload.get("accuracy"),
        (correct / total) if total else 0.0,
    )
    structured_rate = (
        sum(1 for item in diagnostics if item.structured_context) / len(diagnostics)
        if diagnostics
        else 0.0
    )
    guidance_rate = (
        sum(1 for item in diagnostics if item.answer_guidance) / len(diagnostics)
        if diagnostics
        else 0.0
    )
    category_reports = _category_reports(diagnostics)
    warnings = _amb_report_warnings(
        total=total,
        accuracy=accuracy,
        answer_guidance_rate=guidance_rate,
        structured_context_rate=structured_rate,
        diagnostics=diagnostics,
    )
    return AMBScoreReport(
        result_path=path,
        dataset=str(payload.get("dataset") or ""),
        split=str(payload.get("split") or ""),
        memory_provider=str(payload.get("memory_provider") or payload.get("memory") or ""),
        mode=str(payload.get("mode") or ""),
        run_name=str(payload.get("run_name") or ""),
        total_queries=total,
        correct=correct,
        accuracy=accuracy,
        ingested_docs=_int(payload.get("ingested_docs"), 0),
        ingestion_time_ms=_float(payload.get("ingestion_time_ms"), 0.0),
        avg_context_tokens=_float(payload.get("avg_context_tokens"), _avg(item.context_tokens for item in diagnostics)),
        avg_retrieve_time_ms=_float(payload.get("avg_retrieve_time_ms"), _avg(item.retrieve_time_ms for item in diagnostics)),
        answer_guidance_rate=guidance_rate,
        structured_context_rate=structured_rate,
        category_reports=category_reports,
        diagnostics=diagnostics,
        warnings=warnings,
    )


def render_amb_score_report(
    report: AMBScoreReport,
    *,
    output_format: Literal["markdown", "json", "csv"] = "markdown",
) -> str:
    if output_format == "json":
        return json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n"
    if output_format == "csv":
        return _render_amb_report_csv(report)
    if output_format != "markdown":
        raise AMBBenchmarkError(f"unsupported AMB report format: {output_format}")
    return _render_amb_report_markdown(report)


def build_amb_failure_taxonomy(result_path: Path) -> AMBFailureTaxonomy:
    """Classify failed AMB queries into stable, reviewable failure buckets."""

    report = build_amb_score_report(result_path)
    items = tuple(_failure_taxonomy_item(item) for item in report.failed_queries)
    return AMBFailureTaxonomy(
        result_path=report.result_path,
        total_failures=len(items),
        items=items,
    )


def render_amb_failure_taxonomy(
    taxonomy: AMBFailureTaxonomy,
    *,
    output_format: Literal["markdown", "json", "csv"] = "csv",
) -> str:
    if output_format == "json":
        return json.dumps(taxonomy.to_dict(), indent=2, sort_keys=True) + "\n"
    if output_format == "markdown":
        return _render_amb_failure_taxonomy_markdown(taxonomy)
    if output_format == "csv":
        return _render_amb_failure_taxonomy_csv(taxonomy)
    raise AMBBenchmarkError(f"unsupported AMB taxonomy format: {output_format}")


def build_amb_score_diff(
    *,
    baseline_path: Path,
    candidate_path: Path,
) -> AMBDiffReport:
    """Compare two AMB result files at overall and per-category levels."""

    baseline = build_amb_score_report(baseline_path)
    candidate = build_amb_score_report(candidate_path)
    baseline_by_category = {
        item.category: item for item in baseline.category_reports
    }
    candidate_by_category = {
        item.category: item for item in candidate.category_reports
    }
    category_deltas: list[AMBCategoryDelta] = []
    for category in sorted(baseline_by_category.keys() | candidate_by_category.keys()):
        left = baseline_by_category.get(category)
        right = candidate_by_category.get(category)
        baseline_accuracy = left.accuracy if left is not None else 0.0
        candidate_accuracy = right.accuracy if right is not None else 0.0
        category_deltas.append(
            AMBCategoryDelta(
                category=category,
                baseline_total=left.total if left is not None else 0,
                baseline_correct=left.correct if left is not None else 0,
                baseline_accuracy=baseline_accuracy,
                candidate_total=right.total if right is not None else 0,
                candidate_correct=right.correct if right is not None else 0,
                candidate_accuracy=candidate_accuracy,
                accuracy_delta=candidate_accuracy - baseline_accuracy,
            )
        )
    return AMBDiffReport(
        baseline_path=baseline.result_path,
        candidate_path=candidate.result_path,
        baseline_correct=baseline.correct,
        baseline_total=baseline.total_queries,
        baseline_accuracy=baseline.accuracy,
        candidate_correct=candidate.correct,
        candidate_total=candidate.total_queries,
        candidate_accuracy=candidate.accuracy,
        accuracy_delta=candidate.accuracy - baseline.accuracy,
        category_deltas=tuple(category_deltas),
    )


def render_amb_score_diff(
    diff: AMBDiffReport,
    *,
    output_format: Literal["markdown", "json", "csv"] = "markdown",
) -> str:
    if output_format == "json":
        return json.dumps(diff.to_dict(), indent=2, sort_keys=True) + "\n"
    if output_format == "csv":
        return _render_amb_score_diff_csv(diff)
    if output_format == "markdown":
        return _render_amb_score_diff_markdown(diff)
    raise AMBBenchmarkError(f"unsupported AMB diff format: {output_format}")


def build_amb_offline_score(
    result_path: Path,
    *,
    failures_only: bool = False,
    categories: tuple[str, ...] = (),
) -> AMBOfflineScoreReport:
    """Score Remaind's deterministic evidence picker without calling an LLM."""

    from ._benchmark_evidence import choose_supported_answer

    path = Path(result_path).expanduser().resolve()
    if not path.is_file():
        raise AMBBenchmarkError(f"AMB result file not found: {path}")
    payload = _read_json_result(path)
    results = payload.get("results")
    if not isinstance(results, list):
        raise AMBBenchmarkError("AMB result file is missing a results array")
    diagnostics: list[AMBOfflineQueryDiagnostic] = []
    category_filter = {category for category in categories if category}
    for item in results:
        if not isinstance(item, dict):
            continue
        category = _query_category(item)
        if failures_only and bool(item.get("correct")):
            continue
        if category_filter and category not in category_filter:
            continue
        offline_pick = choose_supported_answer(
            str(item.get("query") or ""),
            str(item.get("context") or ""),
            question_type=category,
        )
        gold_letters = _gold_answer_letters(item.get("gold_answers"))
        answerer_pick = str(item.get("answer") or item.get("prediction") or "").strip().lower()
        diagnostics.append(
            AMBOfflineQueryDiagnostic(
                query_id=str(item.get("query_id") or item.get("id") or ""),
                category=category,
                offline_pick=offline_pick,
                answerer_pick=answerer_pick,
                gold_letters=gold_letters,
                offline_correct=bool(offline_pick and offline_pick in gold_letters),
                answerer_correct=bool(item.get("correct")),
            )
        )
    total = len(diagnostics)
    offline_correct = sum(1 for item in diagnostics if item.offline_correct)
    answerer_correct = sum(1 for item in diagnostics if item.answerer_correct)
    rescued = sum(
        1 for item in diagnostics if item.offline_correct and not item.answerer_correct
    )
    risks = sum(
        1 for item in diagnostics if item.answerer_correct and not item.offline_correct
    )
    return AMBOfflineScoreReport(
        result_path=path,
        total_queries=total,
        offline_correct=offline_correct,
        offline_accuracy=(offline_correct / total) if total else 0.0,
        answerer_correct=answerer_correct,
        answerer_accuracy=(answerer_correct / total) if total else 0.0,
        rescued_failures=rescued,
        introduced_risks=risks,
        category_reports=_offline_category_reports(diagnostics),
        diagnostics=tuple(diagnostics),
    )


def render_amb_offline_score(
    report: AMBOfflineScoreReport,
    *,
    output_format: Literal["markdown", "json", "csv"] = "markdown",
) -> str:
    if output_format == "json":
        return json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n"
    if output_format == "csv":
        return _render_amb_offline_score_csv(report)
    if output_format == "markdown":
        return _render_amb_offline_score_markdown(report)
    raise AMBBenchmarkError(f"unsupported AMB offline score format: {output_format}")


def render_amb_prepare(
    result: AMBPrepareResult,
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    run_template = amb_run_template(result.amb_repo, result.remaind_source_path)
    return (
        "\n".join(
            [
                "Agent Memory Benchmark bridge: ready",
                f"AMB repo:            {result.amb_repo}",
                f"Provider adapter:    {result.provider_path}",
                f"Registry patched:    {result.registry_path}",
                f"Remaind source path: {result.remaind_source_path}",
                f"Provider name:       {result.provider_name}",
                "",
                "Smoke-test provider discovery:",
                (
                    f"cd {result.amb_repo} && "
                    f"REMAIND_SOURCE_PATH={result.remaind_source_path} "
                    "uv run omb providers"
                ),
                "",
                "Official AMB run template:",
                run_template,
                "",
                "Official scoring is owned by AMB and requires its configured judge runtime.",
            ]
        )
        + "\n"
    )


def _read_json_result(path: Path) -> dict[str, object]:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            loaded = json.load(handle)
    else:
        loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise AMBBenchmarkError("AMB result file must contain a JSON object")
    return loaded


def _query_diagnostic(item: dict[str, object]) -> AMBQueryDiagnostic:
    context = str(item.get("context") or "")
    return AMBQueryDiagnostic(
        query_id=str(item.get("query_id") or item.get("id") or ""),
        category=_query_category(item),
        correct=bool(item.get("correct")),
        answer=str(item.get("answer") or item.get("prediction") or ""),
        gold_answers=tuple(str(value) for value in _list_value(item.get("gold_answers"))),
        context_tokens=_int(item.get("context_tokens"), 0),
        retrieve_time_ms=_float(item.get("retrieve_time_ms"), 0.0),
        answer_guidance="## Answering Guidance" in context,
        structured_context="Structured Preference / Memory State" in context,
        selected_structured_context="selected: structured_preference_state" in context,
        option_alignment="## Option Evidence Alignment" in context,
        source_evidence_count=context.count("selected: turn_evidence_"),
        judge_reason=str(item.get("judge_reason") or ""),
    )


def _query_category(item: dict[str, object]) -> str:
    meta = item.get("meta")
    if isinstance(meta, dict):
        question_type = meta.get("question_type")
        if question_type:
            return str(question_type)
    axes = item.get("category_axes")
    if isinstance(axes, dict):
        for key in ("Question Type", "question_type", "category"):
            value = axes.get(key)
            values = _list_value(value)
            if values:
                return str(values[0])
    return "uncategorized"


def _category_reports(
    diagnostics: tuple[AMBQueryDiagnostic, ...],
) -> tuple[AMBCategoryReport, ...]:
    grouped: dict[str, list[AMBQueryDiagnostic]] = {}
    for item in diagnostics:
        grouped.setdefault(item.category, []).append(item)
    reports: list[AMBCategoryReport] = []
    for category in sorted(grouped):
        items = grouped[category]
        total = len(items)
        correct = sum(1 for item in items if item.correct)
        reports.append(
            AMBCategoryReport(
                category=category,
                total=total,
                correct=correct,
                accuracy=(correct / total) if total else 0.0,
                avg_context_tokens=_avg(item.context_tokens for item in items),
                avg_retrieve_time_ms=_avg(item.retrieve_time_ms for item in items),
                structured_context_rate=(
                    sum(1 for item in items if item.structured_context) / total
                    if total
                    else 0.0
                ),
            )
        )
    return tuple(reports)


def _offline_category_reports(
    diagnostics: list[AMBOfflineQueryDiagnostic],
) -> tuple[AMBOfflineCategoryReport, ...]:
    grouped: dict[str, list[AMBOfflineQueryDiagnostic]] = {}
    for item in diagnostics:
        grouped.setdefault(item.category, []).append(item)
    reports: list[AMBOfflineCategoryReport] = []
    for category in sorted(grouped):
        items = grouped[category]
        total = len(items)
        offline_correct = sum(1 for item in items if item.offline_correct)
        answerer_correct = sum(1 for item in items if item.answerer_correct)
        reports.append(
            AMBOfflineCategoryReport(
                category=category,
                total=total,
                offline_correct=offline_correct,
                offline_accuracy=(offline_correct / total) if total else 0.0,
                answerer_correct=answerer_correct,
                answerer_accuracy=(answerer_correct / total) if total else 0.0,
                rescued_failures=sum(
                    1
                    for item in items
                    if item.offline_correct and not item.answerer_correct
                ),
                introduced_risks=sum(
                    1
                    for item in items
                    if item.answerer_correct and not item.offline_correct
                ),
            )
        )
    return tuple(reports)


def _gold_answer_letters(value: object) -> tuple[str, ...]:
    letters: list[str] = []
    for item in _list_value(value):
        text = str(item).strip().lower()
        letter = ""
        if len(text) == 1 and text.isalpha():
            letter = text
        else:
            match = re.match(r"^\(?([a-z])\)", text)
            if match:
                letter = match.group(1)
        if letter and letter not in letters:
            letters.append(letter)
    return tuple(letters)


def _amb_report_warnings(
    *,
    total: int,
    accuracy: float,
    answer_guidance_rate: float,
    structured_context_rate: float,
    diagnostics: tuple[AMBQueryDiagnostic, ...],
) -> tuple[str, ...]:
    warnings: list[str] = []
    if total == 0:
        warnings.append("No AMB queries were found in the result file.")
    if total < 20:
        warnings.append("This is a smoke run; use at least 20 queries for tuning signal.")
    if accuracy < 0.8 and total >= 10:
        warnings.append("Accuracy is below 80%; inspect failed-query diagnostics before claiming benchmark strength.")
    if answer_guidance_rate < 0.95 and diagnostics:
        warnings.append("Answering guidance was not included for every query.")
    if structured_context_rate < 0.95 and diagnostics:
        warnings.append("Structured memory state was not included for every query.")
    if any(item.source_evidence_count == 0 for item in diagnostics):
        warnings.append("At least one query had no selected turn-level source evidence.")
    return tuple(warnings)


def _render_amb_report_markdown(report: AMBScoreReport) -> str:
    lines = [
        "# AMB Scorecard",
        "",
        f"- Result: `{report.result_path}`",
        f"- Dataset/split: `{report.dataset}` / `{report.split}`",
        f"- Provider/mode: `{report.memory_provider}` / `{report.mode}`",
        f"- Run: `{report.run_name}`",
        f"- Accuracy: **{report.correct}/{report.total_queries} ({_pct(report.accuracy)})**",
        f"- Ingested docs: {report.ingested_docs}",
        f"- Avg context tokens: {report.avg_context_tokens:.1f}",
        f"- Avg retrieval: {report.avg_retrieve_time_ms:.1f} ms",
        f"- Answering-guidance inclusion: {_pct(report.answer_guidance_rate)}",
        f"- Structured-state inclusion: {_pct(report.structured_context_rate)}",
        "",
    ]
    if report.warnings:
        lines.extend(["## Warnings", ""])
        lines.extend(f"- {warning}" for warning in report.warnings)
        lines.append("")
    lines.extend(
        [
            "## Category Diagnostics",
            "",
            "| Category | Correct | Accuracy | Avg Context Tokens | Avg Retrieval | Structured State |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for category in report.category_reports:
        lines.append(
            f"| {category.category} | {category.correct}/{category.total} | "
            f"{_pct(category.accuracy)} | {category.avg_context_tokens:.1f} | "
            f"{category.avg_retrieve_time_ms:.1f} ms | "
            f"{_pct(category.structured_context_rate)} |"
        )
    lines.append("")
    lines.extend(["## Failed Queries", ""])
    if not report.failed_queries:
        lines.append("No failed queries in this run.")
    else:
        for item in report.failed_queries:
            gold = "; ".join(item.gold_answers[:2])
            lines.extend(
                [
                    f"### {item.query_id or '(missing query id)'}",
                    f"- Category: {item.category}",
                    f"- Answer: `{item.answer}`",
                    f"- Gold: {gold}",
                    f"- Context tokens: {item.context_tokens}",
                    f"- Retrieval: {item.retrieve_time_ms:.1f} ms",
                    f"- Structured state: {'yes' if item.structured_context else 'no'}",
                    f"- Source evidence selected: {item.source_evidence_count}",
                    f"- Judge: {item.judge_reason or '(not provided)'}",
                    "",
                ]
            )
    return "\n".join(lines).rstrip() + "\n"


def _render_amb_report_csv(report: AMBScoreReport) -> str:
    lines = [
        (
            "scope,category,total,correct,accuracy,avg_context_tokens,"
            "avg_retrieve_time_ms,answer_guidance_rate,structured_context_rate"
        ),
        (
            f"overall,,{report.total_queries},{report.correct},{report.accuracy:.4f},"
            f"{report.avg_context_tokens:.2f},{report.avg_retrieve_time_ms:.2f},"
            f"{report.answer_guidance_rate:.4f},{report.structured_context_rate:.4f}"
        ),
    ]
    for category in report.category_reports:
        lines.append(
            f"category,{_csv_cell(category.category)},{category.total},{category.correct},"
            f"{category.accuracy:.4f},{category.avg_context_tokens:.2f},"
            f"{category.avg_retrieve_time_ms:.2f},,"
            f"{category.structured_context_rate:.4f}"
        )
    return "\n".join(lines) + "\n"


def _failure_taxonomy_item(item: AMBQueryDiagnostic) -> AMBFailureTaxonomyItem:
    pattern, root_cause = _failure_pattern_and_root_cause(item)
    gold = item.gold_answers[-1] if item.gold_answers else ""
    return AMBFailureTaxonomyItem(
        category=item.category,
        failure_pattern=pattern,
        query_id=item.query_id,
        picked=item.answer,
        gold=gold,
        suspected_root_cause=root_cause,
        judge_reason=item.judge_reason,
    )


def _failure_pattern_and_root_cause(item: AMBQueryDiagnostic) -> tuple[str, str]:
    category = item.category
    if category == "track_full_preference_evolution":
        return (
            "preference_state_sequence",
            "Preference chronology or polarity flip evidence was insufficiently discriminative.",
        )
    if category == "provide_preference_aligned_recommendations":
        return (
            "subtle_preference_judgment",
            "Recommendation needed stronger current preference, constraint, or tie-breaker evidence.",
        )
    if category == "recall_user_shared_facts":
        return (
            "generic_over_grounded_recall",
            "Answer likely preferred plausible background over direct user-turn fact evidence.",
        )
    if category == "suggest_new_ideas":
        return (
            "novelty_or_length_bias",
            "New-idea choice likely needed stronger concise-vs-padded or novelty-adjacent guidance.",
        )
    if category == "generalizing_to_new_scenarios":
        return (
            "generalization_tie_breaker",
            "Generalization needed clearer constraints, polarity state, or self-disclosure penalties.",
        )
    if category == "recalling_the_reasons_behind_previous_updates":
        return (
            "wrong_reason_substitution",
            "Reason-for-change evidence was missing, buried, or not tied to the option reason claim.",
        )
    if category == "recalling_facts_mentioned_by_the_user":
        return (
            "recall_distractor_indistinguishable",
            "Options likely differed by a small noun phrase without enough direct-turn anchoring.",
        )
    return (
        "unclassified",
        "Failure needs manual review before assigning a durable root cause.",
    )


def _render_amb_failure_taxonomy_csv(taxonomy: AMBFailureTaxonomy) -> str:
    lines = [
        "category,failure_pattern,query_id,picked,gold,suspected_root_cause,judge_reason"
    ]
    for item in taxonomy.items:
        lines.append(
            ",".join(
                [
                    _csv_cell(item.category),
                    _csv_cell(item.failure_pattern),
                    _csv_cell(item.query_id),
                    _csv_cell(item.picked),
                    _csv_cell(item.gold),
                    _csv_cell(item.suspected_root_cause),
                    _csv_cell(item.judge_reason),
                ]
            )
        )
    return "\n".join(lines) + "\n"


def _render_amb_failure_taxonomy_markdown(taxonomy: AMBFailureTaxonomy) -> str:
    lines = [
        "# AMB Failure Taxonomy",
        "",
        f"- Result: `{taxonomy.result_path}`",
        f"- Failures: {taxonomy.total_failures}",
        "",
        "| Category | Failure Pattern | Query ID | Picked | Gold | Suspected Root Cause |",
        "|---|---|---|---|---|---|",
    ]
    for item in taxonomy.items:
        lines.append(
            f"| {item.category} | {item.failure_pattern} | `{item.query_id}` | "
            f"`{item.picked}` | `{item.gold}` | {item.suspected_root_cause} |"
        )
    return "\n".join(lines) + "\n"


def _render_amb_score_diff_csv(diff: AMBDiffReport) -> str:
    lines = [
        (
            "scope,category,baseline_total,baseline_correct,baseline_accuracy,"
            "candidate_total,candidate_correct,candidate_accuracy,accuracy_delta"
        ),
        (
            f"overall,,{diff.baseline_total},{diff.baseline_correct},"
            f"{diff.baseline_accuracy:.4f},{diff.candidate_total},"
            f"{diff.candidate_correct},{diff.candidate_accuracy:.4f},"
            f"{diff.accuracy_delta:.4f}"
        ),
    ]
    for item in diff.category_deltas:
        lines.append(
            f"category,{_csv_cell(item.category)},{item.baseline_total},"
            f"{item.baseline_correct},{item.baseline_accuracy:.4f},"
            f"{item.candidate_total},{item.candidate_correct},"
            f"{item.candidate_accuracy:.4f},{item.accuracy_delta:.4f}"
        )
    return "\n".join(lines) + "\n"


def _render_amb_score_diff_markdown(diff: AMBDiffReport) -> str:
    lines = [
        "# AMB Score Diff",
        "",
        f"- Baseline: `{diff.baseline_path}`",
        f"- Candidate: `{diff.candidate_path}`",
        (
            f"- Overall: {diff.baseline_correct}/{diff.baseline_total} "
            f"({_pct(diff.baseline_accuracy)}) -> "
            f"{diff.candidate_correct}/{diff.candidate_total} "
            f"({_pct(diff.candidate_accuracy)}) "
            f"({_signed_pct(diff.accuracy_delta)})"
        ),
        "",
        "| Category | Baseline | Candidate | Delta |",
        "|---|---:|---:|---:|",
    ]
    for item in diff.category_deltas:
        lines.append(
            f"| {item.category} | {item.baseline_correct}/{item.baseline_total} "
            f"({_pct(item.baseline_accuracy)}) | {item.candidate_correct}/"
            f"{item.candidate_total} ({_pct(item.candidate_accuracy)}) | "
            f"{_signed_pct(item.accuracy_delta)} |"
        )
    return "\n".join(lines) + "\n"


def _render_amb_offline_score_markdown(report: AMBOfflineScoreReport) -> str:
    lines = [
        "# AMB Offline Score",
        "",
        f"- Result: `{report.result_path}`",
        (
            f"- Deterministic Remaind pick: {report.offline_correct}/{report.total_queries} "
            f"({_pct(report.offline_accuracy)})"
        ),
        (
            f"- Original answerer: {report.answerer_correct}/{report.total_queries} "
            f"({_pct(report.answerer_accuracy)})"
        ),
        f"- Potential rescues: {report.rescued_failures}",
        f"- Introduced risks: {report.introduced_risks}",
        "",
        "| Category | Offline | Answerer | Rescues | Risks |",
        "|---|---:|---:|---:|---:|",
    ]
    for category in report.category_reports:
        lines.append(
            f"| {category.category} | {category.offline_correct}/{category.total} "
            f"({_pct(category.offline_accuracy)}) | "
            f"{category.answerer_correct}/{category.total} "
            f"({_pct(category.answerer_accuracy)}) | {category.rescued_failures} | "
            f"{category.introduced_risks} |"
        )
    misses = [
        item
        for item in report.diagnostics
        if item.answerer_correct and not item.offline_correct
    ][:20]
    if misses:
        lines.extend(["", "## First Introduced Risks", ""])
        for miss in misses:
            gold = ", ".join(miss.gold_letters)
            lines.append(
                f"- `{miss.query_id or '(missing query id)'}` [{miss.category}]: "
                f"offline `{miss.offline_pick or '(none)'}`, "
                f"answerer `{miss.answerer_pick}`, gold `{gold}`"
            )
    return "\n".join(lines) + "\n"


def _render_amb_offline_score_csv(report: AMBOfflineScoreReport) -> str:
    lines = [
        (
            "scope,category,total,offline_correct,offline_accuracy,"
            "answerer_correct,answerer_accuracy,rescued_failures,introduced_risks"
        ),
        (
            f"overall,,{report.total_queries},{report.offline_correct},"
            f"{report.offline_accuracy:.4f},{report.answerer_correct},"
            f"{report.answerer_accuracy:.4f},{report.rescued_failures},"
            f"{report.introduced_risks}"
        ),
    ]
    for item in report.category_reports:
        lines.append(
            f"category,{_csv_cell(item.category)},{item.total},"
            f"{item.offline_correct},{item.offline_accuracy:.4f},"
            f"{item.answerer_correct},{item.answerer_accuracy:.4f},"
            f"{item.rescued_failures},{item.introduced_risks}"
        )
    return "\n".join(lines) + "\n"


def _list_value(value: object) -> list[object]:
    if isinstance(value, list):
        return value
    if value in (None, ""):
        return []
    return [value]


def _int(value: object, default: int) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float | str):
        try:
            return int(value)
        except ValueError:
            return default
    return default


def _float(value: object, default: float) -> float:
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, int | float):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return default
    return default


def _avg(values: Iterable[float | int]) -> float:
    items = [float(value) for value in values]
    return sum(items) / len(items) if items else 0.0


def _pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _signed_pct(value: float) -> str:
    sign = "+" if value >= 0 else ""
    return f"{sign}{value * 100:.1f}pp"


def _csv_cell(value: str) -> str:
    if any(char in value for char in ',\n"'):
        return '"' + value.replace('"', '""') + '"'
    return value


def amb_run_template(amb_repo: Path, remaind_source_path: Path) -> str:
    return (
        f"cd {Path(amb_repo).expanduser().resolve()} && "
        f"REMAIND_SOURCE_PATH={Path(remaind_source_path).expanduser().resolve()} "
        "GEMINI_API_KEY=<your-key> "
        "OMB_ANSWER_LLM=gemini OMB_ANSWER_MODEL=gemini-2.5-pro "
        "OMB_JUDGE_LLM=gemini OMB_JUDGE_MODEL=gemini-2.5-flash "
        "uv run omb run --dataset personamem --split 32k "
        "--memory remaind --llm gemini --query-limit 20"
    )


def _validate_amb_repo(repo: Path) -> None:
    required = [
        repo / "src" / "memory_bench" / "memory" / "base.py",
        repo / "src" / "memory_bench" / "memory" / "__init__.py",
        repo / "src" / "memory_bench" / "models.py",
        repo / "src" / "memory_bench" / "cli.py",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise AMBBenchmarkError(
            "not an Agent Memory Benchmark checkout; missing " + ", ".join(missing)
        )


def _validate_remaind_source_path(source_path: Path) -> None:
    required = [
        source_path / "remaind" / "__init__.py",
        source_path / "remaind" / "_amb_reconciliation.py",
        source_path / "remaind" / "_benchmark_evidence.py",
        source_path / "remaind" / "_db.py",
        source_path / "remaind" / "_events.py",
        source_path / "remaind" / "_memory_records.py",
        source_path / "remaind" / "_paths.py",
        source_path / "remaind" / "_polarity_vocab.py",
        source_path / "remaind" / "_ulid.py",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise AMBBenchmarkError(
            "Remaind source path is incomplete for the AMB provider; missing "
            + ", ".join(missing)
        )


def _patch_amb_registry(registry_source: str) -> str:
    block = "\n".join(
        [
            AMB_REGISTRY_BEGIN,
            "from .remaind import RemaindMemoryProvider",
            "",
            'REGISTRY["remaind"] = RemaindMemoryProvider',
            AMB_REGISTRY_END,
            "",
        ]
    )
    if AMB_REGISTRY_BEGIN in registry_source:
        before, rest = registry_source.split(AMB_REGISTRY_BEGIN, 1)
        _old, after = rest.split(AMB_REGISTRY_END, 1)
        return before.rstrip() + "\n\n" + block + after.lstrip()
    return registry_source.rstrip() + "\n\n" + block


def _render_amb_provider_source(remaind_source_path: Path) -> str:
    return _AMB_PROVIDER_TEMPLATE.replace(
        "__REMAIND_SOURCE_PATH__",
        json.dumps(str(remaind_source_path)),
    )


_AMB_PROVIDER_TEMPLATE = '''"""Remaind provider for Agent Memory Benchmark.

Generated by `remaind public-bench amb prepare`.

Set REMAIND_SOURCE_PATH to a Remaind source checkout when the package is not
installed in AMB's Python environment.
"""

from __future__ import annotations

import json
import os
import hashlib
import re
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Any

_DEFAULT_REMAIND_SOURCE = __REMAIND_SOURCE_PATH__
_configured_source = os.environ.get("REMAIND_SOURCE_PATH") or _DEFAULT_REMAIND_SOURCE
if _configured_source and _configured_source not in sys.path:
    sys.path.insert(0, _configured_source)

import remaind
from memory_bench.models import Document

from remaind._db import Memory, get_memory, insert_memory, open_db, search_memories
from remaind._events import EventInput, EventWriter
from remaind._paths import ContextPaths
from remaind._ulid import new_ulid
from remaind._benchmark_evidence import (
    build_benchmark_evidence_packet,
    expanded_query,
    rank_memory_candidates,
)
from remaind._amb_reconciliation import reconcile_amb_preference_records
from remaind._memory_records import (
    memory_records_for_source_ids,
    upsert_amb_session_memory_records,
)

from .base import MemoryProvider

_INDEX_FILENAME = "amb_remaind_index.jsonl"
_SESSION_ID = "amb-remaind"


class RemaindMemoryProvider(MemoryProvider):
    name = "remaind"
    description = (
        "Local-first Remaind memory provider using source-linked events and "
        "SQLite retrieval."
    )
    kind = "local"
    provider = "Remaind"
    variant = "local"
    link = "https://github.com/magpiexyz-lab/Remaind"
    concurrency = 4

    def __init__(self) -> None:
        self._base: Path | None = None
        self._index_path: Path | None = None
        self._store_dir: Path | None = None
        self._query_lookup: dict[tuple[str | None, str], tuple[str, set[str], str]] | None = None
        self._query_lookup_lock = threading.Lock()

    def prepare(
        self,
        store_dir: Path,
        unit_ids: set[str] | None = None,
        reset: bool = True,
    ) -> None:
        self._store_dir = Path(store_dir)
        with self._query_lookup_lock:
            self._query_lookup = None
        base = Path(store_dir) / "remaind-context"
        paths = ContextPaths.at(base)
        if reset and paths.root.exists():
            shutil.rmtree(paths.root)
        base.mkdir(parents=True, exist_ok=True)
        if not paths.state_json.is_file():
            remaind.init(base)
        self._base = base
        self._index_path = base / _INDEX_FILENAME
        if reset:
            self._index_path.write_text("", encoding="utf-8")

    def ingest(self, documents: list[Document]) -> None:
        base = self._require_base()
        index_path = self._require_index_path()
        writer = EventWriter.open(base)
        conn = open_db(base)
        try:
            for doc in documents:
                memory_id = f"mem_{new_ulid()}"
                content = _format_session_document(doc)
                event = writer.append(
                    EventInput(
                        type="tool_result",
                        actor="amb",
                        summary=f"AMB document {doc.id} session",
                        session_id=_SESSION_ID,
                        task_id=str(doc.id or "amb-document"),
                        content=content,
                        importance=2,
                        tags=_tags_for_document(doc),
                        source="Agent Memory Benchmark dataset",
                        metadata={
                            "benchmark": "Agent Memory Benchmark",
                            "document_id": doc.id,
                            "user_id": doc.user_id,
                            "timestamp": doc.timestamp,
                            "context": doc.context,
                            "chunk_index": 1,
                            "chunk_count": 1,
                        },
                    )
                )
                now = str(event["timestamp"])
                insert_memory(
                    conn,
                    Memory(
                        id=memory_id,
                        memory_type="fact",
                        content=content,
                        rationale="Ingested from Agent Memory Benchmark document.",
                        confidence=0.9,
                        importance=2,
                        created_at=now,
                        updated_at=now,
                        last_accessed_at=now,
                        source_event_ids=[str(event["id"])],
                        tags=_tags_for_document(doc),
                    ),
                )
                upsert_amb_session_memory_records(
                    base,
                    memory_id=memory_id,
                    content=content,
                    metadata={
                        "document_id": doc.id,
                        "user_id": doc.user_id,
                        "timestamp": doc.timestamp,
                    },
                    source_event_ids=[str(event["id"])],
                )
                _append_index_record(
                    index_path,
                    {
                        "memory_id": memory_id,
                        "document_id": doc.id,
                        "user_id": doc.user_id,
                        "timestamp": doc.timestamp,
                        "context": doc.context,
                        "chunk_index": 1,
                        "chunk_count": 1,
                        "source_event_ids": [str(event["id"])],
                    },
                )
        finally:
            conn.close()
        reconcile_amb_preference_records(base)

    def retrieve(
        self,
        query: str,
        k: int = 10,
        user_id: str | None = None,
        query_timestamp: str | None = None,
    ) -> tuple[list[Document], dict | None]:
        retrieve_started = time.perf_counter()
        base = self._require_base()
        index = _load_index(self._require_index_path())
        conn = open_db(base)
        try:
            candidates = search_memories(
                conn,
                expanded_query(query),
                limit=max(int(k) * 80, 80),
            )
            candidates = _with_scoped_user_memories(conn, candidates, index, user_id)
        finally:
            conn.close()

        packet_query, allowed_document_ids, trace_query_id = self._query_context_for_retrieval(
            query,
            user_id,
        )
        if allowed_document_ids:
            candidates = [
                memory
                for memory in candidates
                if str(index.get(memory.id, {}).get("document_id") or "")
                in allowed_document_ids
            ]

        ranked = rank_memory_candidates(
            query,
            candidates,
            index,
            user_id=user_id,
            query_timestamp=query_timestamp,
        )
        raw_results: list[dict[str, Any]] = []
        selected = ranked[: min(max(int(k), 1), 8)]
        packet_ranked = ranked[: min(max(int(k) * 3, 16), 32)]
        for ranked_memory in selected:
            score = ranked_memory.score
            memory = ranked_memory.memory
            meta = index.get(memory.id, {})
            raw_results.append(
                {
                    "memory_id": memory.id,
                    "document_id": meta.get("document_id"),
                    "source_event_ids": memory.source_event_ids,
                    "confidence": memory.confidence,
                    "importance": memory.importance,
                    "tags": memory.tags,
                    "rank_score": round(score, 4),
                }
            )
        structured_records = memory_records_for_source_ids(
            base,
            [ranked_memory.memory.id for ranked_memory in packet_ranked],
            statuses=("current", "tentative", "blocked", "stale", "superseded"),
            limit=120,
        )
        packet = build_benchmark_evidence_packet(
            packet_query,
            packet_ranked,
            index,
            memory_records=structured_records,
        )
        _write_trace_record(
            self._store_dir,
            {
                "query_id": trace_query_id,
                "query_hash": _query_hash(query),
                "packet_md": packet.content,
                "scorer_state": {
                    "selected_source_ids": list(packet.selected_source_ids),
                    "omitted_source_ids": list(packet.omitted_source_ids),
                    "token_count": packet.token_count,
                    "allowed_document_ids": sorted(allowed_document_ids),
                },
                "ranking_metadata": raw_results,
                "retrieved_memory_ids": [ranked_memory.memory.id for ranked_memory in packet_ranked],
                "timing": {
                    "retrieve_time_ms": round((time.perf_counter() - retrieve_started) * 1000, 3),
                },
            },
        )
        if not packet.content:
            return [], {"provider": self.name, "results": raw_results}
        packet_meta = index.get(selected[0].memory.id, {}) if selected else {}
        documents = [
            Document(
                id="remaind-evidence-packet",
                content=packet.content,
                user_id=packet_meta.get("user_id") or user_id,
                timestamp=packet_meta.get("timestamp"),
                context="source-linked Remaind evidence packet",
            )
        ]

        return documents, {"provider": self.name, "results": raw_results}

    def _require_base(self) -> Path:
        if self._base is None:
            raise RuntimeError("RemaindMemoryProvider.prepare() must run before use")
        return self._base

    def _require_index_path(self) -> Path:
        if self._index_path is None:
            raise RuntimeError("RemaindMemoryProvider.prepare() must run before use")
        return self._index_path

    def _query_context_for_retrieval(
        self,
        query: str,
        user_id: str | None,
    ) -> tuple[str, set[str], str]:
        lookup = self._load_query_lookup()
        if not lookup:
            if _require_scoped_personamem(self._store_dir):
                raise RuntimeError(
                    "Remaind scoped AMB run requires PersonaMem query metadata, "
                    "but no query lookup was available"
                )
            return query, set(), _query_hash(query)
        return (
            lookup.get((user_id, query))
            or lookup.get((None, query))
            or (query, set(), _query_hash(query))
        )

    def _load_query_lookup(self) -> dict[tuple[str | None, str], tuple[str, set[str], str]]:
        with self._query_lookup_lock:
            if self._query_lookup is not None:
                return self._query_lookup
            store_dir = self._store_dir
            if store_dir is None:
                self._query_lookup = {}
                return self._query_lookup
            if "personamem" not in store_dir.parts:
                self._query_lookup = {}
                return self._query_lookup
            split = store_dir.parent.name
            if split not in {"32k", "128k", "1M"}:
                self._query_lookup = {}
                return self._query_lookup
            try:
                from memory_bench.dataset.personamem import PersonaMemDataset
            except Exception:
                self._query_lookup = {}
                return self._query_lookup
            dataset = PersonaMemDataset()
            try:
                queries = dataset.load_queries(split)
            except Exception:
                self._query_lookup = {}
                return self._query_lookup
            query_lookup: dict[tuple[str | None, str], tuple[str, set[str], str]] = {}
            for item in queries:
                retrieval_query = item.meta.get("retrieval_query")
                if not retrieval_query:
                    continue
                question_type = str(item.meta.get("question_type") or "").strip()
                packet_query = item.query
                if question_type:
                    packet_query = f"AMB question_type: {question_type}\\n\\n{item.query}"
                query_id = _query_id_for_dataset_item(item, str(retrieval_query))
                value = (packet_query, set(str(gold_id) for gold_id in item.gold_ids), query_id)
                query_lookup[(item.user_id, str(retrieval_query))] = value
                query_lookup.setdefault((None, str(retrieval_query)), value)
            self._query_lookup = query_lookup
            return self._query_lookup


_SECRET_PATTERNS = (
    re.compile(r"AIza[0-9A-Za-z_-]{20,}"),
    re.compile(r"sk-[0-9A-Za-z_-]{20,}"),
    re.compile(r"(?i)(api[_-]?key|authorization|bearer|password|secret|token)\\s*[:=]\\s*[^\\s,;]+"),
)


def _query_id_for_dataset_item(item: Any, retrieval_query: str) -> str:
    for attr in ("query_id", "id"):
        value = getattr(item, attr, None)
        if value:
            return str(value)
    meta = getattr(item, "meta", None)
    if isinstance(meta, dict):
        for key in ("query_id", "id"):
            value = meta.get(key)
            if value:
                return str(value)
    return _query_hash(retrieval_query)


def _query_hash(query: str) -> str:
    return hashlib.sha256(str(query).encode("utf-8")).hexdigest()[:16]


def _trace_enabled() -> bool:
    value = os.environ.get("REMAIND_BENCH_TRACE", "")
    return value.lower() in {"1", "true", "yes", "on"}


def _require_scoped_personamem(store_dir: Path | None) -> bool:
    value = os.environ.get("REMAIND_BENCH_REQUIRE_SCOPED", "")
    if value.lower() not in {"1", "true", "yes", "on"}:
        return False
    if store_dir is None:
        return False
    parts = set(Path(store_dir).parts)
    return "personamem" in parts


def _write_trace_record(
    store_dir: Path | None,
    record: dict[str, Any],
) -> None:
    if not _trace_enabled():
        return
    query_id = str(record.get("query_id") or record.get("query_hash") or "")
    if not query_id:
        raise RuntimeError("Remaind trace record missing query_id/query_hash")
    redacted = _redact_trace_value(record)
    payload = json.dumps(redacted, sort_keys=True)
    if _contains_secret(payload):
        raise RuntimeError("Remaind trace redaction failed; refusing to write trace")
    trace_dir = _trace_dir(store_dir)
    trace_dir.mkdir(parents=True, exist_ok=True)
    trace_path = trace_dir / "remaind_amb_trace.jsonl"
    with trace_path.open("a", encoding="utf-8") as handle:
        handle.write(payload + "\\n")


def _trace_dir(store_dir: Path | None) -> Path:
    configured = os.environ.get("REMAIND_BENCH_TRACE_DIR")
    if configured:
        return Path(configured).expanduser()
    if store_dir is not None:
        return Path(store_dir) / "remaind-traces"
    return Path.cwd() / "remaind-traces"


def _redact_trace_value(value: Any) -> Any:
    if isinstance(value, str):
        out = value
        for pattern in _SECRET_PATTERNS:
            out = pattern.sub("[REDACTED]", out)
        return out
    if isinstance(value, list):
        return [_redact_trace_value(item) for item in value]
    if isinstance(value, tuple):
        return [_redact_trace_value(item) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _redact_trace_value(item)
            for key, item in value.items()
            if str(key).lower()
            not in {"api_key", "apikey", "authorization", "headers", "password", "secret", "token"}
        }
    return value


def _contains_secret(text: str) -> bool:
    return any(pattern.search(text) for pattern in _SECRET_PATTERNS)


def _format_session_document(doc: Document) -> str:
    fields = [
        "Agent Memory Benchmark session",
        f"Document ID: {doc.id}",
        f"User ID: {doc.user_id or 'global'}",
        f"Timestamp: {doc.timestamp or 'unknown'}",
        f"Context: {doc.context or 'none'}",
        "",
        doc.content,
    ]
    return "\\n".join(fields).strip()


def _with_scoped_user_memories(
    conn: Any,
    candidates: list[Any],
    index: dict[str, dict[str, Any]],
    user_id: str | None,
) -> list[Any]:
    if user_id is None:
        return candidates
    by_id = {memory.id: memory for memory in candidates}
    for memory_id, meta in index.items():
        if meta.get("user_id") != user_id or memory_id in by_id:
            continue
        memory = get_memory(conn, memory_id)
        if memory is not None:
            by_id[memory.id] = memory
    return list(by_id.values())


def _tags_for_document(doc: Document) -> list[str]:
    tags = ["amb", "agent_memory_benchmark", "document"]
    if doc.user_id:
        tags.append(f"user_{_safe_tag(doc.user_id)}")
    if doc.id:
        tags.append(f"doc_{_safe_tag(doc.id)}")
    return tags


def _safe_tag(value: object) -> str:
    text = str(value).strip().lower()
    out = []
    for char in text:
        out.append(char if char.isalnum() else "_")
    tag = "".join(out).strip("_")
    return tag or "unknown"


def _append_index_record(path: Path, record: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\\n")


def _load_index(path: Path) -> dict[str, dict[str, Any]]:
    if not path.is_file():
        return {}
    out: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8") as handle:
        for raw in handle:
            stripped = raw.strip()
            if not stripped:
                continue
            record = json.loads(stripped)
            memory_id = record.get("memory_id")
            if memory_id:
                out[str(memory_id)] = record
    return out
'''
