"""SQLite memory index with FTS5 retrieval.

Layout (per CONTRACT.md §21):

* ``memories`` — one row per memory, mirroring memory.schema.json.
* ``memories_fts`` — FTS5 external-content virtual table indexing
  ``content``, ``rationale``, and ``tags``. Kept in sync with the
  ``memories`` table via INSERT/UPDATE/DELETE triggers.
* ``events_index`` — standalone FTS5 virtual table holding high-importance
  events (importance >= 2). Stores ``event_id``, ``type``, ``importance``,
  ``timestamp`` as ``UNINDEXED`` metadata; indexes ``summary``, ``tags``,
  and ``content_excerpt_head``.

Default BM25 ranking is used in v1.
"""

from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ._paths import ContextPaths

SCHEMA_VERSION = "1.0.0"

_EVENT_FTS_IMPORTANCE_MIN = 2
_FTS_TOKEN_RE = re.compile(r"\w+")


def _fts_query(query: str) -> str:
    """Turn plain text into a safe FTS5 query.

    Remaind search APIs accept user/state text, not raw FTS syntax. Quoting
    each token prevents reserved words such as AND, OR, NOT, and NEAR from
    being interpreted as operators.
    """
    terms = [match.group(0).lower() for match in _FTS_TOKEN_RE.finditer(query)]
    return " OR ".join(f'"{term}"' for term in terms)


@dataclass
class Memory:
    """In-memory representation of a memories row."""

    id: str
    memory_type: str
    content: str
    rationale: str
    confidence: float
    importance: int
    created_at: str
    updated_at: str
    last_accessed_at: str
    alternatives: list[str] = field(default_factory=list)
    source_event_ids: list[str] = field(default_factory=list)
    supersedes: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def connect(path: Path) -> sqlite3.Connection:
    """Open a connection with safe defaults."""
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def bootstrap(conn: sqlite3.Connection) -> None:
    """Create the schema. Idempotent."""
    with conn:
        conn.executescript(_SCHEMA_SQL)


def open_db(base: Path) -> sqlite3.Connection:
    """Open (creating if necessary) the SQLite DB for the context at ``base``."""
    paths = ContextPaths.at(Path(base))
    paths.db_dir.mkdir(parents=True, exist_ok=True)
    conn = connect(paths.db_sqlite)
    bootstrap(conn)
    return conn


# --------------------------------------------------------------------- memories


def _memory_to_row(mem: Memory) -> tuple:
    return (
        mem.id,
        mem.memory_type,
        mem.content,
        mem.rationale,
        json.dumps(mem.alternatives),
        json.dumps(mem.source_event_ids),
        json.dumps(mem.supersedes),
        float(mem.confidence),
        int(mem.importance),
        mem.created_at,
        mem.updated_at,
        mem.last_accessed_at,
        " ".join(mem.tags),
        mem.schema_version,
    )


def _row_to_memory(row: sqlite3.Row) -> Memory:
    return Memory(
        id=row["id"],
        memory_type=row["memory_type"],
        content=row["content"],
        rationale=row["rationale"],
        alternatives=json.loads(row["alternatives"]),
        source_event_ids=json.loads(row["source_event_ids"]),
        supersedes=json.loads(row["supersedes"]),
        confidence=row["confidence"],
        importance=row["importance"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        last_accessed_at=row["last_accessed_at"],
        tags=row["tags"].split() if row["tags"] else [],
        schema_version=row["schema_version"],
    )


def insert_memory(conn: sqlite3.Connection, mem: Memory) -> None:
    with conn:
        conn.execute(
            """
            INSERT INTO memories (
                id, memory_type, content, rationale,
                alternatives, source_event_ids, supersedes,
                confidence, importance,
                created_at, updated_at, last_accessed_at,
                tags, schema_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            _memory_to_row(mem),
        )


def update_memory(conn: sqlite3.Connection, mem: Memory) -> None:
    with conn:
        cursor = conn.execute(
            """
            UPDATE memories SET
                memory_type = ?,
                content = ?,
                rationale = ?,
                alternatives = ?,
                source_event_ids = ?,
                supersedes = ?,
                confidence = ?,
                importance = ?,
                created_at = ?,
                updated_at = ?,
                last_accessed_at = ?,
                tags = ?,
                schema_version = ?
            WHERE id = ?
            """,
            (
                mem.memory_type,
                mem.content,
                mem.rationale,
                json.dumps(mem.alternatives),
                json.dumps(mem.source_event_ids),
                json.dumps(mem.supersedes),
                float(mem.confidence),
                int(mem.importance),
                mem.created_at,
                mem.updated_at,
                mem.last_accessed_at,
                " ".join(mem.tags),
                mem.schema_version,
                mem.id,
            ),
        )
        if cursor.rowcount == 0:
            raise KeyError(f"memory {mem.id!r} not found")


def delete_memory(conn: sqlite3.Connection, mem_id: str) -> None:
    with conn:
        conn.execute("DELETE FROM memories WHERE id = ?", (mem_id,))


def get_memory(conn: sqlite3.Connection, mem_id: str) -> Memory | None:
    row = conn.execute(
        "SELECT * FROM memories WHERE id = ?", (mem_id,)
    ).fetchone()
    return _row_to_memory(row) if row is not None else None


def superseded_memory_ids(conn: sqlite3.Connection) -> set[str]:
    """Return memory IDs superseded by newer memories."""
    out: set[str] = set()
    rows = conn.execute("SELECT supersedes FROM memories").fetchall()
    for row in rows:
        try:
            values = json.loads(row["supersedes"] or "[]")
        except json.JSONDecodeError:
            continue
        if isinstance(values, list):
            out.update(str(value) for value in values if value)
    return out


def search_memories(
    conn: sqlite3.Connection, query: str, *, limit: int = 10
) -> list[Memory]:
    limit = int(limit)
    if limit <= 0:
        return []
    fts_query = _fts_query(query)
    if not fts_query:
        return []
    fetch_limit = max(limit * 10, limit, 50)
    rows = conn.execute(
        """
        SELECT memories.*
        FROM memories_fts
        JOIN memories ON memories.id = memories_fts.memory_id
        WHERE memories_fts MATCH ?
        ORDER BY bm25(memories_fts)
        LIMIT ?
        """,
        (fts_query, fetch_limit),
    ).fetchall()
    superseded = superseded_memory_ids(conn)
    out: list[Memory] = []
    for row in rows:
        memory = _row_to_memory(row)
        if memory.id in superseded:
            continue
        out.append(memory)
        if len(out) >= limit:
            break
    return out


# ----------------------------------------------------------------- events_index


def index_event(conn: sqlite3.Connection, event: dict[str, Any]) -> bool:
    """Insert ``event`` into events_index if importance >= 2.

    Returns True when the event was indexed, False otherwise.
    """
    importance = int(event.get("importance", 0))
    if importance < _EVENT_FTS_IMPORTANCE_MIN:
        return False
    tags = event.get("tags") or []
    if not isinstance(tags, list):
        tags = [str(tags)]
    head = event.get("content_excerpt_head") or ""
    with conn:
        conn.execute(
            """
            INSERT INTO events_index
                (event_id, type, importance, timestamp,
                 summary, tags, content_excerpt_head)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event["id"],
                event["type"],
                importance,
                event["timestamp"],
                event.get("summary") or "",
                " ".join(str(t) for t in tags),
                head,
            ),
        )
    return True


def search_events(
    conn: sqlite3.Connection, query: str, *, limit: int = 10
) -> list[dict[str, Any]]:
    limit = int(limit)
    if limit <= 0:
        return []
    fts_query = _fts_query(query)
    if not fts_query:
        return []
    rows = conn.execute(
        """
        SELECT event_id, type, importance, timestamp,
               summary, tags, content_excerpt_head
        FROM events_index
        WHERE events_index MATCH ?
        ORDER BY bm25(events_index)
        LIMIT ?
        """,
        (fts_query, limit),
    ).fetchall()
    return [
        {
            "event_id": r["event_id"],
            "type": r["type"],
            "importance": r["importance"],
            "timestamp": r["timestamp"],
            "summary": r["summary"],
            "tags": r["tags"].split() if r["tags"] else [],
            "content_excerpt_head": r["content_excerpt_head"],
        }
        for r in rows
    ]


# ---------------------------------------------------------------------- schema

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS memories (
    id                  TEXT PRIMARY KEY,
    memory_type         TEXT NOT NULL,
    content             TEXT NOT NULL,
    rationale           TEXT NOT NULL,
    alternatives        TEXT NOT NULL,
    source_event_ids    TEXT NOT NULL,
    supersedes          TEXT NOT NULL,
    confidence          REAL NOT NULL,
    importance          INTEGER NOT NULL,
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    last_accessed_at    TEXT NOT NULL,
    tags                TEXT NOT NULL,
    schema_version      TEXT NOT NULL
);

-- Standalone FTS5 table (not external-content) so COUNT and DELETE behave
-- intuitively for the validate consistency check. Storage cost: content +
-- rationale + tags are duplicated, which is negligible at v1 scale.
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    memory_id UNINDEXED,
    content,
    rationale,
    tags,
    tokenize='unicode61'
);

CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memories_fts(memory_id, content, rationale, tags)
    VALUES (new.id, new.content, new.rationale, new.tags);
END;

CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
    DELETE FROM memories_fts WHERE memory_id = old.id;
END;

CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
    DELETE FROM memories_fts WHERE memory_id = old.id;
    INSERT INTO memories_fts(memory_id, content, rationale, tags)
    VALUES (new.id, new.content, new.rationale, new.tags);
END;

CREATE VIRTUAL TABLE IF NOT EXISTS events_index USING fts5(
    event_id UNINDEXED,
    type UNINDEXED,
    importance UNINDEXED,
    timestamp UNINDEXED,
    summary,
    tags,
    content_excerpt_head,
    tokenize='unicode61'
);

CREATE TABLE IF NOT EXISTS memory_records (
    id                  TEXT PRIMARY KEY,
    kind                TEXT NOT NULL,
    subject             TEXT NOT NULL,
    who                 TEXT NOT NULL,
    what                TEXT NOT NULL,
    when_text           TEXT NOT NULL,
    where_text          TEXT NOT NULL,
    why                 TEXT NOT NULL,
    how                 TEXT NOT NULL,
    status              TEXT NOT NULL,
    confidence          REAL NOT NULL,
    importance          INTEGER NOT NULL,
    source_event_ids    TEXT NOT NULL,
    supersedes          TEXT NOT NULL,
    entities            TEXT NOT NULL,
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    schema_version      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_record_sources (
    record_id           TEXT NOT NULL,
    source_id           TEXT NOT NULL,
    source_kind         TEXT NOT NULL,
    source_path         TEXT NOT NULL,
    source_excerpt      TEXT NOT NULL,
    PRIMARY KEY (record_id, source_id, source_kind),
    FOREIGN KEY (record_id) REFERENCES memory_records(id) ON DELETE CASCADE
);

CREATE VIRTUAL TABLE IF NOT EXISTS memory_records_fts USING fts5(
    record_id UNINDEXED,
    kind,
    subject,
    what,
    why,
    how,
    entities,
    tokenize='unicode61'
);

CREATE TRIGGER IF NOT EXISTS memory_records_ai AFTER INSERT ON memory_records BEGIN
    INSERT INTO memory_records_fts(record_id, kind, subject, what, why, how, entities)
    VALUES (new.id, new.kind, new.subject, new.what, new.why, new.how, new.entities);
END;

CREATE TRIGGER IF NOT EXISTS memory_records_ad AFTER DELETE ON memory_records BEGIN
    DELETE FROM memory_records_fts WHERE record_id = old.id;
END;

CREATE TRIGGER IF NOT EXISTS memory_records_au AFTER UPDATE ON memory_records BEGIN
    DELETE FROM memory_records_fts WHERE record_id = old.id;
    INSERT INTO memory_records_fts(record_id, kind, subject, what, why, how, entities)
    VALUES (new.id, new.kind, new.subject, new.what, new.why, new.how, new.entities);
END;
"""
