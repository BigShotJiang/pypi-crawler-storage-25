"""Shared packet sizing policy for Remaind context windows."""

from __future__ import annotations

import os
from dataclasses import dataclass

UNKNOWN_CONTEXT_TOKEN_CAP = 24_000
SMALL_CONTEXT_PACKET_FRACTION = 0.2
PACKET_TOKEN_BANDS: tuple[tuple[int, int, str], ...] = (
    (130_000, 18_000, "0-130k context -> adaptive packet up to 18k"),
    (150_000, 25_000, "131k-150k context -> 25k packet"),
    (250_000, 40_000, "150k-250k context -> 40k packet"),
    (500_000, 80_000, "250k-500k context -> 80k packet"),
    (1_000_000, 160_000, "500k-1M context -> 160k packet"),
)
OVER_1M_PACKET_TOKENS = 240_000
OVER_1M_LABEL = ">1M context -> 240k packet"
RAW_EXCERPT_MAX_TOKENS = 24_000


@dataclass(frozen=True)
class PacketPolicy:
    context_window_tokens: int | None
    packet_tokens: int
    resume_packet_tokens: int
    raw_excerpt_tokens: int
    label: str

    @property
    def summary(self) -> str:
        return (
            f"{self.label}; run/resume packet cap {self.packet_tokens} tokens; "
            f"raw excerpt cap {self.raw_excerpt_tokens} tokens"
        )


def positive_int(value: object) -> int | None:
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def context_window_from_env() -> int | None:
    for key in (
        "REMAIND_CONTEXT_WINDOW",
        "REMAIND_OLLAMA_NUM_CTX",
        "REMAIND_OPENAI_NUM_CTX",
        "SOVEREIGN_NUM_CTX",
    ):
        parsed = positive_int(os.environ.get(key))
        if parsed is not None:
            return parsed
    return None


def packet_tokens_for_context(context_window_tokens: int | None) -> tuple[int, str]:
    context_window = positive_int(context_window_tokens)
    if context_window is None:
        return UNKNOWN_CONTEXT_TOKEN_CAP, "unknown context -> 24k fallback packet"

    first_upper, first_cap, first_label = PACKET_TOKEN_BANDS[0]
    if context_window <= first_upper:
        cap = min(
            first_cap,
            max(2_000, int(context_window * SMALL_CONTEXT_PACKET_FRACTION)),
        )
        return cap, first_label

    for upper_bound, cap, label in PACKET_TOKEN_BANDS[1:]:
        if context_window <= upper_bound:
            return cap, label

    return OVER_1M_PACKET_TOKENS, OVER_1M_LABEL


def packet_policy_for_context(context_window_tokens: int | None) -> PacketPolicy:
    cap, label = packet_tokens_for_context(context_window_tokens)
    raw_cap = min(max(cap // 4, 2_000), RAW_EXCERPT_MAX_TOKENS)
    return PacketPolicy(
        context_window_tokens=positive_int(context_window_tokens),
        packet_tokens=cap,
        resume_packet_tokens=cap,
        raw_excerpt_tokens=raw_cap,
        label=label,
    )


def resolve_packet_token_cap(
    *,
    explicit_token_cap: int | None,
    context_window_tokens: int | None,
    env_keys: tuple[str, ...] = (
        "REMAIND_RUN_TOKEN_CAP",
        "REMAIND_PACKET_TOKENS",
        "REMAIND_RUN_PACKET_TOKENS",
    ),
) -> int:
    explicit = positive_int(explicit_token_cap)
    if explicit is not None:
        return explicit

    for key in env_keys:
        env_cap = positive_int(os.environ.get(key))
        if env_cap is not None:
            return env_cap

    context_window = positive_int(context_window_tokens)
    if context_window is None:
        context_window = context_window_from_env()
    return packet_policy_for_context(context_window).packet_tokens
