"""Universal recommendation decisions for normal Remaind product flows.

The benchmark bridge, launch questions, document runs, and plan reconciliation
all need the same contract: when Remaind recommends a path, it should name the
criteria, constraints, evidence, candidates, conflicts, confidence, and selected
action. This module keeps that decision object deterministic and reusable.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from ._recommendation_judgment import (
    RecommendationConstraintFamily,
    active_recommendation_constraints,
    important_recommendation_terms,
    looks_like_recommendation_request,
    recommendation_tie_breaker,
)

_MAX_CANDIDATES = 10
_EVIDENCE_PREVIEW_CHARS = 220

_CANDIDATE_PATTERNS: tuple[tuple[re.Pattern[str], float], ...] = (
    (re.compile(r"aligned_next_plan_step[\"']?\s*[:=]\s*[\"']?(?P<body>[^\"'\n]+)"), 22.0),
    (re.compile(r"Suggested next step:\s*(?P<body>.+)", flags=re.IGNORECASE), 20.0),
    (re.compile(r"Immediate next(?: implementation)? step:\s*(?P<body>.+)", flags=re.IGNORECASE), 20.0),
    (re.compile(r"Next(?: implementation)? step:\s*(?P<body>.+)", flags=re.IGNORECASE), 18.0),
    (re.compile(r"-\s*(?:blocked|in_progress|active):\s*(?P<body>.+)", flags=re.IGNORECASE), 17.0),
    (re.compile(r"-\s*(?:pending|planned):\s*(?P<body>.+)", flags=re.IGNORECASE), 12.0),
    (re.compile(r"-\s*\[[ xX ]\]\s*(?P<body>.+)", flags=re.IGNORECASE), 10.0),
)

_NOISE_PREFIXES = (
    "no active blocker",
    "no pending plan item",
    "none",
)


@dataclass(frozen=True)
class RecommendationCandidate:
    """One possible action Remaind can recommend."""

    id: str
    text: str
    source: str
    base_score: float = 0.0


@dataclass(frozen=True)
class RecommendationCandidateScore:
    """Scored recommendation candidate with auditable reasons."""

    candidate: RecommendationCandidate
    score: float
    conflicts: tuple[str, ...]
    matches: tuple[str, ...]
    recent_positive_terms: tuple[str, ...]
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class RecommendationDecision:
    """The universal recommendation object rendered into normal Remaind packets."""

    applies: bool
    question: str
    selected_action: str
    confidence: str
    criteria: tuple[str, ...]
    constraints: tuple[RecommendationConstraintFamily, ...]
    evidence: tuple[str, ...]
    candidates: tuple[RecommendationCandidateScore, ...]
    warnings: tuple[str, ...]


def build_recommendation_decision(
    question: str,
    evidence_texts: Sequence[str],
    *,
    candidates: Sequence[RecommendationCandidate] = (),
) -> RecommendationDecision:
    """Build a deterministic recommendation decision for normal product flows."""

    inferred = list(candidates) or infer_recommendation_candidates(evidence_texts)
    applies = looks_like_recommendation_request(question) or bool(inferred)
    constraints = active_recommendation_constraints(evidence_texts)
    evidence = _evidence_preview(evidence_texts, constraints)
    criteria = (
        "Prefer the current product plan or live status over stale packets.",
        "Fix active blockers before advancing to the next plan item.",
        "Honor explicit user constraints and dislikes before generic topical fit.",
        "Prefer recent positive evidence when multiple paths are viable.",
        "If no grounded candidate exists, ask for or capture the missing plan state.",
    )
    if not applies:
        return RecommendationDecision(
            applies=False,
            question=question,
            selected_action="",
            confidence="none",
            criteria=criteria,
            constraints=constraints,
            evidence=evidence,
            candidates=(),
            warnings=(),
        )

    scored = tuple(
        sorted(
            (_score_candidate(candidate, question, evidence_texts) for candidate in inferred),
            key=lambda item: (-item.score, item.candidate.id),
        )
    )
    warnings: list[str] = []
    if not scored:
        selected_action = (
            "No explicit candidate was loaded. Generate the recommendation from the "
            "current plan, constraints, and source evidence; do not invent completed work."
        )
        confidence = "low"
        warnings.append("No explicit candidate action was found in loaded evidence.")
    else:
        selected_action = scored[0].candidate.text
        confidence = _confidence(scored)
        if confidence == "low":
            warnings.append("Candidate margin is low; explain the evidence and ask if the plan is stale.")

    return RecommendationDecision(
        applies=True,
        question=question,
        selected_action=selected_action,
        confidence=confidence,
        criteria=criteria,
        constraints=constraints,
        evidence=evidence,
        candidates=scored[:_MAX_CANDIDATES],
        warnings=tuple(warnings),
    )


def render_recommendation_decision(decision: RecommendationDecision) -> str:
    """Render the universal recommendation object for model-facing packets."""

    if not decision.applies:
        return ""
    rows = [
        "## Remaind Recommendation Engine",
        "",
        f"Selected action: {decision.selected_action}",
        f"Confidence: {decision.confidence}",
        "",
        "Decision criteria:",
    ]
    rows.extend(f"- {criterion}" for criterion in decision.criteria)
    rows.append("")
    if decision.constraints:
        rows.append("Active constraints:")
        rows.extend(
            f"- {constraint.key}: {constraint.label}"
            for constraint in decision.constraints
        )
    else:
        rows.append("Active constraints: none found in loaded evidence")
    if decision.evidence:
        rows.append("")
        rows.append("Evidence used:")
        rows.extend(f"- {item}" for item in decision.evidence)
    if decision.candidates:
        rows.append("")
        rows.append("Candidate scores:")
        for scored in decision.candidates:
            conflicts = ", ".join(scored.conflicts) if scored.conflicts else "none"
            matches = ", ".join(scored.matches) if scored.matches else "none"
            reasons = "; ".join(scored.reasons) if scored.reasons else "base evidence only"
            rows.append(
                f"- {scored.candidate.id}: {scored.candidate.text} "
                f"(score={scored.score:.1f}; source={scored.candidate.source}; "
                f"conflicts={conflicts}; matches={matches}; reasons={reasons})"
            )
    if decision.warnings:
        rows.append("")
        rows.append("Warnings:")
        rows.extend(f"- {warning}" for warning in decision.warnings)
    rows.append("")
    return "\n".join(rows)


def infer_recommendation_candidates(
    evidence_texts: Sequence[str],
) -> tuple[RecommendationCandidate, ...]:
    """Infer candidate actions from loaded plan/status/reconciliation evidence."""

    candidates: list[RecommendationCandidate] = []
    seen: set[str] = set()
    for source_index, text in enumerate(evidence_texts, start=1):
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            for pattern, base_score in _CANDIDATE_PATTERNS:
                match = pattern.search(stripped)
                if not match:
                    continue
                body = _clean_candidate_text(match.group("body"))
                key = body.lower()
                if not body or key in seen:
                    continue
                seen.add(key)
                candidates.append(
                    RecommendationCandidate(
                        id=f"c{len(candidates) + 1}",
                        text=body,
                        source=f"evidence:{source_index}",
                        base_score=base_score,
                    )
                )
                break
            if len(candidates) >= _MAX_CANDIDATES:
                return tuple(candidates)
    return tuple(candidates)


def candidates_from_plan_items(
    items: Sequence[Mapping[str, object]],
    *,
    blocker_candidate: str = "",
) -> tuple[RecommendationCandidate, ...]:
    """Create recommendation candidates from a plan reconciliation item list."""

    candidates: list[RecommendationCandidate] = []
    seen: set[str] = set()
    if blocker_candidate:
        clean = _clean_candidate_text(blocker_candidate)
        if clean:
            seen.add(clean.lower())
            candidates.append(
                RecommendationCandidate(
                    id="fix_blocker",
                    text=clean,
                    source="current_blocker",
                    base_score=28.0,
                )
            )
    for index, item in enumerate(items, start=1):
        text = _clean_candidate_text(str(item.get("text") or ""))
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        status = str(item.get("status") or "")
        candidates.append(
            RecommendationCandidate(
                id=f"plan_{index}",
                text=text,
                source=f"plan_item:{status or 'unknown'}",
                base_score=_plan_status_score(status),
            )
        )
    return tuple(candidates[:_MAX_CANDIDATES])


def _score_candidate(
    candidate: RecommendationCandidate,
    question: str,
    evidence_texts: Sequence[str],
) -> RecommendationCandidateScore:
    tie = recommendation_tie_breaker(candidate.text, evidence_texts)
    question_terms = set(important_recommendation_terms(question))
    candidate_terms = set(important_recommendation_terms(candidate.text))
    overlap = question_terms & candidate_terms
    score = candidate.base_score + tie.score_adjustment + min(4.0, len(overlap) * 0.8)
    reasons = list(tie.reasons)
    if overlap:
        reasons.append("question-term fit")
    return RecommendationCandidateScore(
        candidate=candidate,
        score=score,
        conflicts=tie.conflicts,
        matches=tie.matches,
        recent_positive_terms=tie.recent_positive_terms,
        reasons=tuple(reasons),
    )


def _confidence(candidates: Sequence[RecommendationCandidateScore]) -> str:
    if not candidates:
        return "low"
    top = candidates[0].score
    runner_up = candidates[1].score if len(candidates) > 1 else 0.0
    margin = top - runner_up
    if top >= 22.0 and margin >= 5.0:
        return "high"
    if top >= 14.0 and margin >= 2.0:
        return "medium"
    return "low"


def _evidence_preview(
    evidence_texts: Sequence[str],
    constraints: Sequence[RecommendationConstraintFamily],
) -> tuple[str, ...]:
    previews: list[str] = []
    markers = tuple(marker for family in constraints for marker in family.evidence_markers)
    for text in evidence_texts:
        for raw_line in text.splitlines():
            line = raw_line.strip().strip("-").strip()
            if not line:
                continue
            lowered = line.lower()
            if (
                _contains_recommendation_signal(lowered)
                or any(marker in lowered for marker in markers)
            ):
                previews.append(_truncate(line, _EVIDENCE_PREVIEW_CHARS))
                break
        if len(previews) >= 6:
            break
    return tuple(_dedupe(previews))


def _contains_recommendation_signal(lowered: str) -> bool:
    return any(
        marker in lowered
        for marker in (
            "next step",
            "aligned_next_plan_step",
            "current constraint",
            "blocker",
            "pending",
            "planned",
            "recently",
            "latest progress",
        )
    )


def _clean_candidate_text(text: str) -> str:
    cleaned = re.sub(r"\s+", " ", text).strip().strip("-").strip()
    cleaned = re.sub(r"\s*\([^)]*source:[^)]+\)\s*$", "", cleaned, flags=re.IGNORECASE)
    cleaned = cleaned.strip("`'\" ")
    if not cleaned:
        return ""
    lowered = cleaned.lower()
    if any(lowered.startswith(prefix) for prefix in _NOISE_PREFIXES):
        return ""
    return cleaned


def _plan_status_score(status: str) -> float:
    normalized = status.lower()
    if normalized == "blocked":
        return 24.0
    if normalized in {"in_progress", "active"}:
        return 20.0
    if normalized == "pending":
        return 15.0
    if normalized == "planned":
        return 12.0
    return 8.0


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def _dedupe(values: Sequence[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(value)
    return out
