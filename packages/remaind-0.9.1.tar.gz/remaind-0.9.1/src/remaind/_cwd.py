"""Safe current-working-directory helpers."""

from __future__ import annotations

import os
from pathlib import Path


def safe_cwd() -> Path:
    """Return a usable current directory even when the real cwd is unreadable."""

    try:
        return Path.cwd().resolve()
    except OSError:
        raw = os.environ.get("PWD", "").strip()
        if raw:
            try:
                return Path(raw).expanduser().resolve()
            except OSError:
                pass
        try:
            return Path.home().resolve()
        except OSError:
            return Path("/")
