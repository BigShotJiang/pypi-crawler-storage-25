"""Deterministic entity/topic grounding for option-level memory answers.

Memory failures often come from broad-domain overlap: "film newsletter" is not
"documentaries" just because both mention film, and "book club" is not "book
blog" just because both mention books. This module extracts lightweight topic
anchors and exposes contrastive option adjustments that prefer exact entities
over plausible neighboring entities.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

_STOPWORDS = {
    "about",
    "again",
    "also",
    "and",
    "answer",
    "because",
    "been",
    "being",
    "could",
    "did",
    "does",
    "enjoy",
    "enjoyed",
    "fact",
    "facts",
    "for",
    "from",
    "have",
    "into",
    "like",
    "liked",
    "mention",
    "mentioned",
    "more",
    "most",
    "new",
    "not",
    "option",
    "past",
    "previously",
    "recall",
    "remember",
    "said",
    "shared",
    "should",
    "that",
    "the",
    "this",
    "told",
    "user",
    "what",
    "with",
    "would",
    "you",
    "your",
}

ENTITY_TYPE_ANCHORS = {
    "album",
    "article",
    "blog",
    "club",
    "cinema",
    "class",
    "classes",
    "community",
    "course",
    "documentary",
    "documentaries",
    "exhibition",
    "exhibitions",
    "festival",
    "forum",
    "journal",
    "meetup",
    "membership",
    "newsletter",
    "podcast",
    "playlist",
    "review",
    "reviews",
    "show",
    "studio",
    "workshop",
}

DOMAIN_TERMS = {
    "art",
    "book",
    "books",
    "film",
    "films",
    "literature",
    "movie",
    "movies",
    "music",
    "novel",
    "novels",
    "painting",
    "production",
    "reading",
    "theater",
    "writing",
}


@dataclass(frozen=True)
class EntityGroundingJudgment:
    score_adjustment: float
    direct_refs: int
    exact_phrases: tuple[str, ...]
    matched_entity_anchors: tuple[str, ...]
    unsupported_entity_anchors: tuple[str, ...]
    conflicting_entity_anchors: tuple[str, ...]
    reasons: tuple[str, ...]
    decision_signal: str


def entity_grounding_judgments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, EntityGroundingJudgment]:
    """Return contrastive entity grounding judgments for candidate options."""

    evidence_units = [
        re.sub(r"\s+", " ", str(text)).strip().lower()
        for text in evidence_texts
        if str(text).strip()
    ]
    evidence = " ".join(evidence_units)
    evidence_anchors = {
        anchor
        for anchor in ENTITY_TYPE_ANCHORS
        if _term_present(anchor, evidence)
    }
    option_terms = {
        letter: tuple(important_entity_terms(option_text))
        for letter, option_text in options
    }
    term_frequency: dict[str, int] = {}
    for terms in option_terms.values():
        for term in set(terms):
            term_frequency[term] = term_frequency.get(term, 0) + 1

    judgments: dict[str, EntityGroundingJudgment] = {}
    for letter, _option_text in options:
        terms = option_terms[letter]
        option_anchors = {
            _normalize_anchor(term)
            for term in terms
            if _normalize_anchor(term) in ENTITY_TYPE_ANCHORS
        }
        discriminators = tuple(
            term for term in terms if term_frequency.get(term, 0) == 1
        ) or terms[:8]
        phrases = _entity_phrases(discriminators)
        matched_anchors = tuple(
            sorted(anchor for anchor in option_anchors if anchor in evidence_anchors)
        )
        unsupported_anchors = tuple(
            sorted(anchor for anchor in option_anchors if anchor not in evidence_anchors)
        )
        direct_refs = 0
        exact_phrases: set[str] = set()
        for unit in evidence_units:
            if any(_term_present(term, unit) for term in discriminators):
                direct_refs += 1
            for phrase in phrases:
                if phrase in unit:
                    exact_phrases.add(phrase)
        conflicting_anchors = tuple(
            sorted(
                anchor
                for anchor in evidence_anchors
                if anchor not in option_anchors and unsupported_anchors
            )
        )[:5]
        score = 0.0
        reasons: list[str] = []
        if matched_anchors:
            score += 6.0 + 1.5 * len(matched_anchors)
            reasons.append("entity anchor matched")
        if exact_phrases:
            score += min(6.0, 2.0 * len(exact_phrases))
            reasons.append("exact entity phrase matched")
        if direct_refs:
            score += min(5.0, float(direct_refs))
        if unsupported_anchors and conflicting_anchors:
            score -= 8.0 + 1.5 * len(unsupported_anchors)
            reasons.append("neighbor entity mismatch")
        elif unsupported_anchors and not direct_refs:
            score -= 4.0
            reasons.append("unsupported entity anchor")
        if matched_anchors or exact_phrases:
            signal = "grounded exact entity"
        elif conflicting_anchors:
            signal = "reject neighboring entity"
        elif direct_refs:
            signal = "partial lexical support"
        else:
            signal = "no grounded entity"
        judgments[letter] = EntityGroundingJudgment(
            score_adjustment=score,
            direct_refs=direct_refs,
            exact_phrases=tuple(sorted(exact_phrases)[:5]),
            matched_entity_anchors=matched_anchors,
            unsupported_entity_anchors=unsupported_anchors,
            conflicting_entity_anchors=conflicting_anchors,
            reasons=tuple(reasons),
            decision_signal=signal,
        )
    return judgments


def entity_grounding_adjustments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, tuple[float, list[str]]]:
    """Return scorer-compatible adjustments for entity grounding."""

    adjustments: dict[str, tuple[float, list[str]]] = {}
    for letter, judgment in entity_grounding_judgments(options, evidence_texts).items():
        if judgment.score_adjustment != 0.0:
            adjustments[letter] = (
                judgment.score_adjustment,
                [f"entity: {reason}" for reason in judgment.reasons],
            )
    return adjustments


def entity_grounding_summaries(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, str]:
    """Render compact topic/entity summaries for an evidence packet."""

    summaries: dict[str, str] = {}
    for letter, judgment in entity_grounding_judgments(options, evidence_texts).items():
        summaries[letter] = (
            f"direct_refs={judgment.direct_refs}; "
            f"matched_entity_anchors={_join_or_none(judgment.matched_entity_anchors)}; "
            f"unsupported_entity_anchors={_join_or_none(judgment.unsupported_entity_anchors)}; "
            f"conflicting_entity_anchors={_join_or_none(judgment.conflicting_entity_anchors)}; "
            f"exact_phrases={_join_or_none(judgment.exact_phrases)}; "
            f"decision_signal={judgment.decision_signal}"
        )
    return summaries


def important_entity_terms(text: str) -> list[str]:
    values = [
        _normalize_anchor(match.group(0).lower())
        for match in re.finditer(r"[a-z][a-z0-9_-]{2,}", text.lower())
    ]
    return [
        value
        for value in values
        if value not in _STOPWORDS and not value.isdigit()
    ]


def entity_anchor_terms(text: str) -> set[str]:
    terms = set(important_entity_terms(text))
    return {term for term in terms if term in ENTITY_TYPE_ANCHORS}


def entity_domain_terms(text: str) -> set[str]:
    terms = set(important_entity_terms(text))
    return {term for term in terms if term in DOMAIN_TERMS}


def _entity_phrases(terms: Sequence[str]) -> tuple[str, ...]:
    phrases: list[str] = []
    limited = list(terms[:8])
    for size in (4, 3, 2):
        for index in range(0, max(len(limited) - size + 1, 0)):
            phrase = " ".join(limited[index : index + size])
            if len(phrase) >= 9:
                phrases.append(phrase)
    return tuple(dict.fromkeys(phrases))


def _normalize_anchor(term: str) -> str:
    if term == "documentaries":
        return "documentary"
    if term == "classes":
        return "class"
    if term.endswith("s") and len(term) > 4 and term[:-1] in ENTITY_TYPE_ANCHORS:
        return term[:-1]
    return term


def _term_present(term: str, text: str) -> bool:
    normalized = _normalize_anchor(term)
    forms = {normalized}
    if normalized == "documentary":
        forms.add("documentaries")
    elif normalized.endswith("y"):
        forms.add(normalized[:-1] + "ies")
    else:
        forms.add(normalized + "s")
    return any(re.search(rf"\b{re.escape(form)}\b", text) for form in forms)


def _join_or_none(values: Sequence[str]) -> str:
    return ", ".join(values) if values else "none"
