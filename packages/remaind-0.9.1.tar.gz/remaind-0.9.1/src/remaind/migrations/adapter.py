"""Read-time event adapter runner.

Applies an ordered chain of :class:`EventAdapter` steps to a single event
dict. Adapters never rewrite ``events.jsonl`` — they only transform the
in-memory view of an event when it is read.
"""

from __future__ import annotations

from collections.abc import Iterable
from copy import deepcopy

from .._errors import RemaindError
from .protocol import EventAdapter


class EventAdapterError(RemaindError):
    """Structured failure raised when an event adapter step fails."""

    def __init__(
        self,
        message: str,
        *,
        step_name: str,
        from_version: str,
        to_version: str,
        original_event: dict,
    ) -> None:
        super().__init__(message)
        self.step_name = step_name
        self.from_version = from_version
        self.to_version = to_version
        self.original_event = original_event


def run_event_adapters(
    event: dict, chain: Iterable[EventAdapter]
) -> dict:
    """Apply ``chain`` to ``event`` in order, returning a new dict.

    A no-op chain (empty iterable) returns a deep copy of the input.
    The input is never mutated. On step failure, raises
    :class:`EventAdapterError` with the unchanged original event attached.
    """
    steps = list(chain)
    if not steps:
        return deepcopy(event)

    current = deepcopy(event)
    for step in steps:
        try:
            current = step(current)
        except Exception as exc:
            raise EventAdapterError(
                f"event adapter {getattr(step, 'name', repr(step))!r} failed: {exc}",
                step_name=getattr(step, "name", repr(step)),
                from_version=getattr(step, "from_version", "?"),
                to_version=getattr(step, "to_version", "?"),
                original_event=deepcopy(event),
            ) from exc
    return current
