"""Schema migration interfaces.

Two distinct chains live here:

* **State migrations** (`runner`) — pure write-time migration primitives for
  future schema changes. The v1 schema currently has no registered migration
  steps, so runtime code validates current-schema files directly.
* **Event adapters** (`adapter`) — read-time only, applied lazily per event
  when ``events.jsonl`` is consumed. Adapters must never rewrite the raw log.
"""

from .adapter import EventAdapterError, run_event_adapters
from .protocol import EventAdapter, StateMigration
from .runner import MigrationError, run_state_migrations

__all__ = [
    "EventAdapter",
    "EventAdapterError",
    "MigrationError",
    "StateMigration",
    "run_event_adapters",
    "run_state_migrations",
]
