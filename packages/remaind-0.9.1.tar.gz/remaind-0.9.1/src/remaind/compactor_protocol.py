"""Stable home for low-level handover compactor protocol primitives.

Most integrations should use the high-level operations exported from
``import remaind``. This module exists for advanced harnesses that need to
provide a custom handover compactor while avoiding imports from underscore
modules.

The compatibility re-exports at ``import remaind`` remain supported through
the 1.x release line. Any root-level removal would be a 2.0-only breaking
change.
"""

from __future__ import annotations

from ._compactor import (
    CompactionCandidate,
    CompactionSources,
    Compactor,
    default_compact,
    select_sources,
)
from ._local_compactor import CompactorResponseError

__all__ = [
    "Compactor",
    "CompactionSources",
    "CompactionCandidate",
    "select_sources",
    "default_compact",
    "CompactorResponseError",
]
