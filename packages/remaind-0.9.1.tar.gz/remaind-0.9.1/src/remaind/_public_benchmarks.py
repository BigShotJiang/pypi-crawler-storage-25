"""Adapters for public memory and continuity benchmarks.

The first supported external benchmark is Microsoft's STATE-Bench. Remaind
does not vendor or modify the benchmark; it prepares a source-linked learning
artifact and installs a small STATE-Bench agent adapter that exposes the
benchmark's official ``retrieve_learnings(query, top_k)`` hook.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ._atomic import atomic_write_text
from ._db import Memory, insert_memory, open_db, search_memories
from ._errors import RemaindError
from ._events import EventInput, EventWriter
from ._paths import ContextPaths
from ._timestamps import utc_now_iso
from ._ulid import new_ulid
from .commands import init as init_cmd

STATE_BENCH_ARTIFACT_SCHEMA_VERSION = "remaind-state-bench-learnings-v1"
STATE_BENCH_AGENT_FILENAME = "remaind_state_bench_agent.py"
STATE_BENCH_AGENT_CLASS = "RemaindStateBenchAgent"
DEFAULT_STATE_BENCH_WORKDIR = Path(".remaind_bench/public/state-bench")

_WORD_RE = re.compile(r"[a-z0-9_]{3,}", re.IGNORECASE)
_TASK_DONE_RE = re.compile(r"\[TASK_DONE\]", re.IGNORECASE)
_MAX_FIELD_CHARS = 420
_MAX_LEARNING_CHARS = 2_500


class PublicBenchmarkError(RemaindError):
    """Raised when a public benchmark adapter cannot be prepared or queried."""


@dataclass(frozen=True)
class StateBenchLearning:
    id: str
    domain: str
    task_id: str
    text: str
    source_path: str
    source_sha256: str
    source_event_ids: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class StateBenchPrepareResult:
    state_bench_repo: Path
    train_dir: Path
    workdir: Path
    artifact_path: Path
    agent_path: Path | None
    trajectory_count: int
    learning_count: int
    domains: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "state_bench_repo": str(self.state_bench_repo),
            "train_dir": str(self.train_dir),
            "workdir": str(self.workdir),
            "artifact_path": str(self.artifact_path),
            "agent_path": str(self.agent_path) if self.agent_path else None,
            "trajectory_count": self.trajectory_count,
            "learning_count": self.learning_count,
            "domains": list(self.domains),
            "agent_class": STATE_BENCH_AGENT_CLASS,
            "artifact_env": "REMAIND_STATE_BENCH_LEARNINGS",
            "run_template": state_bench_run_template(self.artifact_path),
        }


@dataclass(frozen=True)
class StateBenchRetrieval:
    query: str
    top_k: int
    artifact_path: Path
    learnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "top_k": self.top_k,
            "artifact_path": str(self.artifact_path),
            "learnings": list(self.learnings),
        }


def prepare_state_bench(
    *,
    state_bench_repo: Path,
    workdir: Path = DEFAULT_STATE_BENCH_WORKDIR,
    train_dir: Path | None = None,
    force: bool = False,
    install_agent: bool = True,
) -> StateBenchPrepareResult:
    """Prepare Remaind as a STATE-Bench memory backend.

    The function reads checked-in STATE-Bench training trajectories, creates a
    deterministic procedural-learning artifact, stores each learning through
    Remaind events + SQLite memory, and optionally installs the STATE-Bench
    agent class under ``<state_bench_repo>/agents/``.
    """

    repo = Path(state_bench_repo).expanduser().resolve()
    _validate_state_bench_repo(repo)
    source_train_dir = (
        Path(train_dir).expanduser().resolve()
        if train_dir is not None
        else repo / "datasets" / "train_task_trajectories"
    )
    if not source_train_dir.is_dir():
        raise PublicBenchmarkError(
            f"STATE-Bench train trajectories not found: {source_train_dir}"
        )

    target_workdir = Path(workdir).expanduser().resolve()
    context_root = ContextPaths.at(target_workdir).root
    if context_root.exists():
        if not force:
            raise PublicBenchmarkError(
                f"refused: {context_root} already exists; pass --force to rebuild"
            )
        shutil.rmtree(context_root)
    target_workdir.mkdir(parents=True, exist_ok=True)
    init_cmd.run(target_workdir, force=False)

    raw_learnings = _build_state_bench_learnings(source_train_dir)
    if not raw_learnings:
        raise PublicBenchmarkError(
            f"no STATE-Bench trajectories found under {source_train_dir}"
        )

    writer = EventWriter.open(target_workdir)
    conn = open_db(target_workdir)
    stored: list[StateBenchLearning] = []
    try:
        for learning in raw_learnings:
            event = writer.append(
                EventInput(
                    type="tool_result",
                    actor="remaind",
                    summary=(
                        "STATE-Bench procedural learning: "
                        f"{learning.domain}/{learning.task_id}"
                    ),
                    session_id="public-bench-state-bench",
                    task_id=learning.task_id,
                    content=learning.text,
                    importance=2,
                    tags=[
                        "public_benchmark",
                        "state_bench",
                        learning.domain,
                        "procedural_learning",
                    ],
                    source=learning.source_path,
                    metadata={
                        "benchmark": "STATE-Bench",
                        "domain": learning.domain,
                        "task_id": learning.task_id,
                        "source_sha256": learning.source_sha256,
                    },
                )
            )
            stored_learning = StateBenchLearning(
                id=learning.id,
                domain=learning.domain,
                task_id=learning.task_id,
                text=learning.text,
                source_path=learning.source_path,
                source_sha256=learning.source_sha256,
                source_event_ids=[str(event["id"])],
                tags=learning.tags,
            )
            insert_memory(
                conn,
                Memory(
                    id=f"mem_{new_ulid()}",
                    memory_type="fact",
                    content=learning.text,
                    rationale="Extracted from STATE-Bench training trajectory.",
                    confidence=0.85,
                    importance=2,
                    created_at=str(event["timestamp"]),
                    updated_at=str(event["timestamp"]),
                    last_accessed_at=str(event["timestamp"]),
                    source_event_ids=[str(event["id"])],
                    tags=[
                        "state_bench",
                        learning.domain,
                        "procedural_learning",
                        *learning.tags,
                    ],
                ),
            )
            stored.append(stored_learning)
    finally:
        conn.close()

    artifact_path = target_workdir / "state_bench_learnings.json"
    artifact = {
        "schema_version": STATE_BENCH_ARTIFACT_SCHEMA_VERSION,
        "benchmark": "STATE-Bench",
        "generated_at": utc_now_iso(),
        "state_bench_repo": str(repo),
        "train_dir": str(source_train_dir),
        "remaind_workdir": str(target_workdir),
        "trajectory_count": len(raw_learnings),
        "learning_count": len(stored),
        "domains": sorted({learning.domain for learning in stored}),
        "learnings": [learning.to_dict() for learning in stored],
    }
    atomic_write_text(artifact_path, json.dumps(artifact, indent=2) + "\n")

    agent_path = install_state_bench_agent(repo) if install_agent else None
    return StateBenchPrepareResult(
        state_bench_repo=repo,
        train_dir=source_train_dir,
        workdir=target_workdir,
        artifact_path=artifact_path,
        agent_path=agent_path,
        trajectory_count=len(raw_learnings),
        learning_count=len(stored),
        domains=sorted({learning.domain for learning in stored}),
    )


def retrieve_state_bench_learnings(
    *,
    artifact_path: Path,
    query: str,
    top_k: int = 3,
) -> StateBenchRetrieval:
    artifact = _load_state_bench_artifact(Path(artifact_path).expanduser().resolve())
    query_text = query.strip()
    if not query_text:
        raise PublicBenchmarkError("query must not be empty")
    if top_k <= 0:
        raise PublicBenchmarkError("top_k must be positive")
    ranked = _rank_state_bench_learnings(query_text, artifact["learnings"])
    return StateBenchRetrieval(
        query=query_text,
        top_k=top_k,
        artifact_path=Path(artifact_path).expanduser().resolve(),
        learnings=[item["text"] for item in ranked[:top_k]],
    )


def search_state_bench_memory(
    *,
    workdir: Path,
    query: str,
    top_k: int = 3,
) -> StateBenchRetrieval:
    base = Path(workdir).expanduser().resolve()
    if not ContextPaths.at(base).state_json.is_file():
        raise PublicBenchmarkError(
            f"{ContextPaths.at(base).root} is not initialized; run STATE-Bench prepare first"
        )
    conn = open_db(base)
    try:
        memories = search_memories(conn, query, limit=top_k)
    finally:
        conn.close()
    return StateBenchRetrieval(
        query=query.strip(),
        top_k=top_k,
        artifact_path=base / "state_bench_learnings.json",
        learnings=[memory.content for memory in memories],
    )


def install_state_bench_agent(state_bench_repo: Path) -> Path:
    repo = Path(state_bench_repo).expanduser().resolve()
    _validate_state_bench_repo(repo)
    agents_dir = repo / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    agent_path = agents_dir / STATE_BENCH_AGENT_FILENAME
    atomic_write_text(agent_path, _STATE_BENCH_AGENT_SOURCE)
    return agent_path


def state_bench_run_template(artifact_path: Path) -> str:
    artifact = str(Path(artifact_path).expanduser().resolve())
    return (
        f"REMAIND_STATE_BENCH_LEARNINGS={artifact} "
        "uv run python -m state_bench.scripts.run_batch "
        "--domain <travel|customer_support|shopping_assistant> "
        "--agent-class RemaindStateBenchAgent "
        "--agent-model-name <agent-model> "
        "--agent-model-reasoning-level <reasoning-level> "
        "--num-runs 5 --num-workers <workers> "
        "--output-dir outputs/<domain>/test_trajectories"
    )


def render_state_bench_prepare(
    result: StateBenchPrepareResult,
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    lines = [
        "STATE-Bench public benchmark bridge: ready",
        f"STATE-Bench repo: {result.state_bench_repo}",
        f"Train data:       {result.train_dir}",
        f"Remaind workdir:  {result.workdir}",
        f"Artifact:         {result.artifact_path}",
        f"Agent adapter:    {result.agent_path or '(not installed)'}",
        f"Trajectories:     {result.trajectory_count}",
        f"Learnings:        {result.learning_count}",
        f"Domains:          {', '.join(result.domains)}",
        "",
        "Official run template:",
        result.to_dict()["run_template"],
        "",
        "Then compute metrics with STATE-Bench's compute_metrics command.",
    ]
    return "\n".join(lines) + "\n"


def render_state_bench_retrieval(
    result: StateBenchRetrieval,
    *,
    as_json: bool = False,
) -> str:
    if as_json:
        return json.dumps(result.to_dict(), indent=2, sort_keys=True) + "\n"
    lines = [
        "STATE-Bench retrieval proof",
        f"Artifact: {result.artifact_path}",
        f"Query:    {result.query}",
        f"Top K:    {result.top_k}",
    ]
    if result.learnings:
        for index, learning in enumerate(result.learnings, start=1):
            lines.append("")
            lines.append(f"{index}. {learning}")
    else:
        lines.append("")
        lines.append("No grounded learning matched this query.")
    return "\n".join(lines) + "\n"


def _validate_state_bench_repo(repo: Path) -> None:
    required = [
        repo / "USE_CUSTOM_CLIENT.md",
        repo / "state_bench" / "agents" / "state_bench.py",
        repo / "state_bench" / "scripts" / "run_batch.py",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise PublicBenchmarkError(
            "not a STATE-Bench checkout; missing " + ", ".join(missing)
        )


def _build_state_bench_learnings(train_dir: Path) -> list[StateBenchLearning]:
    out: list[StateBenchLearning] = []
    for path in sorted(train_dir.glob("*/*.json")):
        learning = _learning_from_trajectory(path, train_dir)
        if learning is not None:
            out.append(learning)
    return out


def _learning_from_trajectory(
    path: Path,
    train_dir: Path,
) -> StateBenchLearning | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PublicBenchmarkError(f"could not read STATE-Bench trajectory {path}: {exc}") from exc
    conversation = payload.get("conversation")
    if not isinstance(conversation, list) or not conversation:
        return None
    domain = path.parent.name
    task_id = path.stem
    first_user = _first_message(conversation, "user")
    last_user = _last_message(conversation, "user")
    assistant_messages = [
        msg
        for msg in conversation
        if isinstance(msg, dict) and msg.get("role") == "assistant"
    ]
    tool_calls = _tool_call_summaries(assistant_messages)
    constraints = _constraint_summaries(assistant_messages)
    completion = "completed" if last_user and _TASK_DONE_RE.search(last_user) else "not marked complete"
    text_parts = [
        f"STATE-Bench {domain} learning for task {task_id}.",
        f"User goal pattern: {_clip(first_user or 'No user request captured.')}",
        f"Useful procedure: {_clip('; '.join(tool_calls) or 'No tool sequence captured.')}",
        f"Important constraints and observations: {_clip('; '.join(constraints) or 'No explicit constraints captured.')}",
        f"Outcome: {completion}.",
        f"Source trajectory: {path.relative_to(train_dir)}.",
    ]
    text = " ".join(text_parts)
    if len(text) > _MAX_LEARNING_CHARS:
        text = text[: _MAX_LEARNING_CHARS - 1].rstrip() + "…"
    rel = str(path.relative_to(train_dir))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    stable_id = hashlib.sha256(f"{rel}:{digest}".encode()).hexdigest()[:16]
    tags = sorted(
        {
            domain,
            *_tokens(task_id.replace("-", " ").replace("_", " ")),
            *(call.split("(", 1)[0] for call in tool_calls[:8]),
        }
    )
    return StateBenchLearning(
        id=stable_id,
        domain=domain,
        task_id=task_id,
        text=text,
        source_path=rel,
        source_sha256=digest,
        tags=tags,
    )


def _first_message(conversation: list[Any], role: str) -> str | None:
    for msg in conversation:
        if isinstance(msg, dict) and msg.get("role") == role:
            content = msg.get("content")
            if isinstance(content, str) and content.strip():
                return content.strip()
    return None


def _last_message(conversation: list[Any], role: str) -> str | None:
    for msg in reversed(conversation):
        if isinstance(msg, dict) and msg.get("role") == role:
            content = msg.get("content")
            if isinstance(content, str) and content.strip():
                return content.strip()
    return None


def _tool_call_summaries(messages: list[dict[str, Any]]) -> list[str]:
    out: list[str] = []
    for msg in messages:
        calls = msg.get("tool_calls") or []
        if not isinstance(calls, list):
            continue
        for call in calls:
            if not isinstance(call, dict):
                continue
            name = str(call.get("name") or "unknown_tool")
            raw_args = call.get("arguments")
            raw_result = call.get("result")
            args = raw_args if isinstance(raw_args, dict) else {}
            result = raw_result if isinstance(raw_result, dict) else {}
            arg_text = _dict_excerpt(args, max_items=3)
            result_text = _result_excerpt(result)
            summary = f"{name}({arg_text})"
            if result_text:
                summary += f" -> {result_text}"
            out.append(summary)
    return out


def _constraint_summaries(messages: list[dict[str, Any]]) -> list[str]:
    out: list[str] = []
    for msg in messages:
        calls = msg.get("tool_calls") or []
        if not isinstance(calls, list):
            continue
        for call in calls:
            if not isinstance(call, dict):
                continue
            result = call.get("result")
            if not isinstance(result, dict):
                continue
            rules = result.get("rules")
            if isinstance(rules, dict):
                for key, value in list(rules.items())[:4]:
                    out.append(f"{key}: {_clip(str(value), 160)}")
            for key in ("status", "reason", "message", "error", "policy", "refund_amount", "fee"):
                value = result.get(key)
                if value not in (None, "", [], {}):
                    out.append(f"{key}: {_clip(str(value), 160)}")
    deduped: list[str] = []
    seen: set[str] = set()
    for item in out:
        if item not in seen:
            seen.add(item)
            deduped.append(item)
    return deduped[:12]


def _dict_excerpt(values: dict[str, Any], *, max_items: int) -> str:
    items = []
    for key, value in list(values.items())[:max_items]:
        items.append(f"{key}={_clip(str(value), 80)}")
    return ", ".join(items)


def _result_excerpt(result: dict[str, Any]) -> str:
    preferred: list[str] = []
    for key in (
        "status",
        "reason",
        "refund_amount",
        "cancellation_fee",
        "change_fee",
        "fare_difference",
        "price",
        "total",
        "message",
        "error",
    ):
        value = result.get(key)
        if value not in (None, "", [], {}):
            preferred.append(f"{key}={_clip(str(value), 90)}")
    if preferred:
        return ", ".join(preferred[:4])
    return _dict_excerpt(result, max_items=3)


def _clip(text: str, limit: int = _MAX_FIELD_CHARS) -> str:
    text = " ".join(text.split())
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def _tokens(text: str) -> list[str]:
    return [match.group(0).lower() for match in _WORD_RE.finditer(text)]


def _load_state_bench_artifact(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise PublicBenchmarkError(f"STATE-Bench learning artifact not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PublicBenchmarkError(f"invalid STATE-Bench learning artifact: {path}") from exc
    if payload.get("schema_version") != STATE_BENCH_ARTIFACT_SCHEMA_VERSION:
        raise PublicBenchmarkError(
            f"unsupported STATE-Bench artifact schema: {payload.get('schema_version')!r}"
        )
    learnings = payload.get("learnings")
    if not isinstance(learnings, list):
        raise PublicBenchmarkError("STATE-Bench artifact is missing a learnings list")
    return payload


def _rank_state_bench_learnings(
    query: str,
    learnings: list[Any],
) -> list[dict[str, Any]]:
    query_terms = set(_tokens(query))
    if not query_terms:
        return []
    ranked: list[tuple[float, dict[str, Any]]] = []
    for item in learnings:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or "")
        haystack = " ".join(
            [
                text,
                str(item.get("domain") or ""),
                str(item.get("task_id") or ""),
                " ".join(str(tag) for tag in item.get("tags") or []),
            ]
        )
        terms = set(_tokens(haystack))
        overlap = query_terms & terms
        if not overlap:
            continue
        phrase_bonus = 0.0
        lower_haystack = haystack.lower()
        for term in query_terms:
            if term in lower_haystack:
                phrase_bonus += 0.04
        score = len(overlap) + phrase_bonus
        score += min(len(overlap) / max(len(query_terms), 1), 1.0)
        ranked.append((score, item))
    ranked.sort(
        key=lambda pair: (
            pair[0],
            str(pair[1].get("domain") or ""),
            str(pair[1].get("task_id") or ""),
        ),
        reverse=True,
    )
    return [item for _score, item in ranked]


_STATE_BENCH_AGENT_SOURCE = '''"""Remaind adapter for STATE-Bench.

Generated by `remaind public-bench state-bench prepare`.

Set REMAIND_STATE_BENCH_LEARNINGS to the generated
state_bench_learnings.json artifact before running STATE-Bench.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

from state_bench.agents.state_bench import StateBenchAgent

_WORD_RE = re.compile(r"[a-z0-9_]{3,}", re.IGNORECASE)
_ARTIFACT_ENV = "REMAIND_STATE_BENCH_LEARNINGS"
_SCHEMA_VERSION = "remaind-state-bench-learnings-v1"


class RemaindStateBenchAgent(StateBenchAgent):
    """STATE-Bench agent that retrieves procedural learnings from Remaind."""

    def retrieve_learnings(self, query: str, top_k: int = 3) -> list[str]:
        artifact_path = os.environ.get(_ARTIFACT_ENV)
        if not artifact_path:
            raise RuntimeError(f"{_ARTIFACT_ENV} must point to state_bench_learnings.json")
        payload = json.loads(Path(artifact_path).read_text(encoding="utf-8"))
        if payload.get("schema_version") != _SCHEMA_VERSION:
            raise RuntimeError(f"unsupported Remaind learning artifact: {payload.get('schema_version')!r}")
        learnings = payload.get("learnings")
        if not isinstance(learnings, list):
            raise RuntimeError("Remaind learning artifact is missing a learnings list")
        ranked = _rank_learnings(query, learnings)
        return [item["text"] for item in ranked[: max(1, int(top_k or 3))]]


def _tokens(text: str) -> set[str]:
    return {match.group(0).lower() for match in _WORD_RE.finditer(text)}


def _rank_learnings(query: str, learnings: list[Any]) -> list[dict[str, Any]]:
    query_terms = _tokens(query)
    if not query_terms:
        return []
    ranked: list[tuple[float, dict[str, Any]]] = []
    for item in learnings:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or "")
        haystack = " ".join(
            [
                text,
                str(item.get("domain") or ""),
                str(item.get("task_id") or ""),
                " ".join(str(tag) for tag in item.get("tags") or []),
            ]
        )
        terms = _tokens(haystack)
        overlap = query_terms & terms
        if not overlap:
            continue
        lower_haystack = haystack.lower()
        phrase_bonus = sum(0.04 for term in query_terms if term in lower_haystack)
        score = len(overlap) + phrase_bonus + min(len(overlap) / max(len(query_terms), 1), 1.0)
        ranked.append((score, item))
    ranked.sort(
        key=lambda pair: (
            pair[0],
            str(pair[1].get("domain") or ""),
            str(pair[1].get("task_id") or ""),
        ),
        reverse=True,
    )
    return [item for _score, item in ranked]
'''
