"""Deterministic intent classification for context engineering."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

ContextIntentKind = Literal[
    "continue_work",
    "status",
    "debug_blocker",
    "packet_history",
    "handover",
    "implementation",
    "general_memory",
]


@dataclass(frozen=True)
class ContextIntent:
    kind: ContextIntentKind
    wants_continuation: bool
    wants_status: bool
    wants_debug: bool
    wants_packet_history: bool
    wants_all_packets: bool
    wants_handover: bool
    requested_packet_count: int | None
    reason: str


def classify_context_intent(
    question: str,
    *,
    workspace_query: str | None = None,
) -> ContextIntent:
    """Classify the user's context need without calling a model."""

    text = " ".join(question.strip().split())
    lowered = text.lower()
    terms = _terms(text)
    query_terms = _terms(workspace_query or "")
    requested_packet_count = _requested_packet_count(lowered)
    wants_all_packets = _wants_all_packet_context(lowered, terms)
    wants_packet_history = (
        requested_packet_count is not None
        or wants_all_packets
        or _wants_packet_history(lowered, terms)
    )
    wants_handover = "handover" in terms or "handoff" in terms
    wants_debug = bool(
        terms
        & {
            "blocked",
            "blocker",
            "bug",
            "crash",
            "debug",
            "error",
            "failed",
            "failure",
            "fix",
            "issue",
            "problem",
            "stuck",
        }
    )
    wants_status = bool(
        terms
        & {
            "progress",
            "plan",
            "plans",
            "scope",
            "state",
            "status",
            "todo",
            "todos",
        }
    )
    continuation = _wants_continuation(lowered, terms) or _matches_workspace_name(
        terms,
        query_terms,
    )
    if wants_packet_history:
        return ContextIntent(
            "packet_history",
            wants_continuation=continuation,
            wants_status=wants_status,
            wants_debug=wants_debug,
            wants_packet_history=True,
            wants_all_packets=wants_all_packets,
            wants_handover=wants_handover,
            requested_packet_count=requested_packet_count,
            reason="The question explicitly asks for packet or answer history.",
        )
    if wants_handover:
        return ContextIntent(
            "handover",
            wants_continuation=True,
            wants_status=wants_status,
            wants_debug=wants_debug,
            wants_packet_history=False,
            wants_all_packets=False,
            wants_handover=True,
            requested_packet_count=None,
            reason="The question asks for handover or handoff information.",
        )
    if wants_debug:
        return ContextIntent(
            "debug_blocker",
            wants_continuation=True,
            wants_status=wants_status,
            wants_debug=True,
            wants_packet_history=False,
            wants_all_packets=False,
            wants_handover=False,
            requested_packet_count=None,
            reason="The question asks about a blocker, failure, or repair path.",
        )
    if continuation:
        return ContextIntent(
            "continue_work",
            wants_continuation=True,
            wants_status=wants_status,
            wants_debug=False,
            wants_packet_history=False,
            wants_all_packets=False,
            wants_handover=False,
            requested_packet_count=None,
            reason="The question asks to continue or matches the active product name.",
        )
    if wants_status:
        return ContextIntent(
            "status",
            wants_continuation=True,
            wants_status=True,
            wants_debug=False,
            wants_packet_history=False,
            wants_all_packets=False,
            wants_handover=False,
            requested_packet_count=None,
            reason="The question asks for status, plan, progress, scope, or TODOs.",
        )
    if terms & {"build", "create", "implement", "modify", "ship", "write"}:
        return ContextIntent(
            "implementation",
            wants_continuation=True,
            wants_status=False,
            wants_debug=False,
            wants_packet_history=False,
            wants_all_packets=False,
            wants_handover=False,
            requested_packet_count=None,
            reason="The question asks for implementation work.",
        )
    return ContextIntent(
        "general_memory",
        wants_continuation=False,
        wants_status=False,
        wants_debug=False,
        wants_packet_history=False,
        wants_all_packets=False,
        wants_handover=False,
        requested_packet_count=None,
        reason="No specialized context intent was detected.",
    )


def _terms(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9][a-z0-9_-]*", text.lower()))


def _requested_packet_count(lowered: str) -> int | None:
    patterns = (
        r"\blast\s+(\d{1,2})\s+(?:packets?|answers?|runs?)\b",
        r"\blatest\s+(\d{1,2})\s+(?:packets?|answers?|runs?)\b",
        r"\b(\d{1,2})\s+(?:latest|recent)\s+(?:packets?|answers?|runs?)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, lowered)
        if match:
            value = int(match.group(1))
            return max(1, min(value, 20))
    return None


def _wants_all_packet_context(lowered: str, terms: set[str]) -> bool:
    return (
        "all packets" in lowered
        or "all packet" in lowered
        or "full packet" in lowered
        or "full history" in lowered
        or bool(terms & {"all", "full"} and terms & {"history", "packets"})
    )


def _wants_packet_history(lowered: str, terms: set[str]) -> bool:
    return (
        "packet history" in lowered
        or "run packet" in lowered
        or "answer note" in lowered
        or bool(terms & {"packet", "packets", "answer", "answers"} and terms & {"history", "latest", "last", "recent"})
    )


def _wants_continuation(lowered: str, terms: set[str]) -> bool:
    direct_phrases = (
        "continue building",
        "continue work",
        "continue working",
        "current state",
        "handover info",
        "latest progress",
        "next step",
        "next todo",
        "next todos",
        "pick up",
        "product scope",
        "project status",
        "what's next",
        "what next",
        "whats next",
        "what should i do next",
        "where we left off",
    )
    if any(phrase in lowered for phrase in direct_phrases):
        return True
    if terms & {"continue", "continuation", "handoff", "handover", "pickup"}:
        return True
    if terms & {"next"} and terms & {"step", "task", "todo", "todos"}:
        return True
    return bool(
        terms & {"next", "work", "working"}
        and terms & {"product", "project", "step"}
    )


def _matches_workspace_name(terms: set[str], query_terms: set[str]) -> bool:
    if not terms or not query_terms:
        return False
    if terms == query_terms:
        return True
    if len(terms) <= 3 and terms <= query_terms:
        return True
    return len(terms) <= 3 and bool(terms & query_terms)
