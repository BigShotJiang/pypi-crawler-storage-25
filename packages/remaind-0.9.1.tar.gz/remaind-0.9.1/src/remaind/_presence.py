"""Privacy-safe shell presence snapshots."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ._paths import ContextPaths


def load_presence_snapshot(base: Path) -> dict[str, Any] | None:
    """Load the latest shell presence snapshot, if it exists and is valid."""

    path = ContextPaths.at(Path(base)).presence_snapshot
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def render_presence_snapshot(snapshot: dict[str, Any]) -> str:
    """Render privacy-safe shell activity as packet evidence."""

    changed_files = snapshot.get("changed_files")
    rows = [
        "## Remaind Presence Snapshot",
        "",
        (
            "This is the latest privacy-safe shell activity observed after "
            "workspace memory was activated. It records command metadata, exit "
            "status, duration, and changed-file summaries; it never records "
            "terminal output."
        ),
        "",
        f"- Updated at: {_field(snapshot, 'updated_at')}",
        f"- Command: {_field(snapshot, 'command_preview')}",
        f"- Exit code: {_field(snapshot, 'exit_code')}",
        f"- Duration ms: {_field(snapshot, 'duration_ms')}",
        f"- Working folder: {_field(snapshot, 'cwd')}",
        f"- Git branch: {_field(snapshot, 'git_branch')}",
        f"- Meaningful activity: {'yes' if snapshot.get('meaningful') else 'no'}",
        "",
        "### Changed Files",
        "",
    ]
    if isinstance(changed_files, list) and changed_files:
        rows.extend(f"- {path}" for path in changed_files[:80])
    else:
        rows.append("- (none detected)")
    rows.append("")
    return "\n".join(rows)


def _field(snapshot: dict[str, Any], key: str) -> str:
    value = snapshot.get(key)
    if value in (None, "", []):
        return "(none)"
    return str(value)
