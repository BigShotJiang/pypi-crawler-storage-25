"""Intent-aware context budget selection."""

from __future__ import annotations

from dataclasses import dataclass

from ._context_intent import ContextIntent
from ._context_sources import ContextSource, OmittedContextSource


@dataclass(frozen=True)
class ContextBudgetPlan:
    token_cap: int
    mandatory_tokens: int
    selected_tokens: int


@dataclass(frozen=True)
class ContextSelection:
    selected: list[ContextSource]
    omitted: list[OmittedContextSource]
    budget: ContextBudgetPlan


def context_token_cap_for_window(context_window_tokens: int | None) -> int:
    """Return a conservative model-source budget for memory questions."""

    if context_window_tokens is None or context_window_tokens <= 0:
        return 120_000
    return max(24_000, min(context_window_tokens, 240_000))


def select_context_sources(
    sources: list[ContextSource],
    *,
    intent: ContextIntent,
    token_cap: int,
) -> ContextSelection:
    """Select sources under budget while preserving mandatory authority."""

    mandatory = [source for source in sources if source.mandatory]
    optional = [source for source in sources if not source.mandatory]
    selected = list(mandatory)
    used = sum(source.token_count for source in selected)
    omitted: list[OmittedContextSource] = []
    ordered_optional = sorted(
        enumerate(optional),
        key=lambda item: _optional_sort_key(item[1], item[0], intent),
    )
    for _index, source in ordered_optional:
        cost = source.token_count
        if used + cost <= token_cap:
            selected.append(source)
            used += cost
            continue
        omitted.append(
            OmittedContextSource(
                id=source.id,
                title=source.title,
                source_type=source.source_type,
                reason=(
                    f"omitted by context budget for intent {intent.kind}; "
                    f"needed {cost} token(s), {max(token_cap - used, 0)} available"
                ),
                token_count=cost,
            )
        )
    selected.sort(key=lambda source: sources.index(source))
    mandatory_tokens = sum(source.token_count for source in mandatory)
    return ContextSelection(
        selected=selected,
        omitted=omitted,
        budget=ContextBudgetPlan(
            token_cap=token_cap,
            mandatory_tokens=mandatory_tokens,
            selected_tokens=used,
        ),
    )


def _optional_sort_key(
    source: ContextSource,
    index: int,
    intent: ContextIntent,
) -> tuple[int, int, int]:
    intent_boost = _intent_group_boost(source, intent)
    authority, freshness = source.priority
    return (-(intent_boost + authority), -freshness, index)


def _intent_group_boost(source: ContextSource, intent: ContextIntent) -> int:
    if intent.wants_packet_history and source.budget_group in {"packet", "answer"}:
        return 10
    if intent.wants_debug and source.budget_group in {"presence", "progress", "status"}:
        return 10
    if intent.wants_continuation and source.budget_group in {"plan", "status", "presence"}:
        return 8
    if intent.wants_continuation and source.source_type in {
        "blocker_ledger",
        "decision_ledger",
        "memory_record",
        "note_ledger",
        "preference_state",
        "stale_memory_warning",
    }:
        return 7
    if intent.wants_handover and source.source_type == "handover":
        return 8
    return 0
