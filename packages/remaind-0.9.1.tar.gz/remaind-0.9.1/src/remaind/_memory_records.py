"""Structured continuity memory records.

Events remain Remaind's source of truth. This module maintains a derived,
queryable SQLite layer for the who/what/when/where/why/how state that a fresh
agent needs before continuing work or answering memory benchmark questions.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from ._db import open_db
from ._jsonl import iter_jsonl
from ._paths import ContextPaths
from ._polarity_vocab import classify_polarity, extract_reason_clause
from ._product_status import clean_product_status_text
from ._timestamps import utc_now_iso

MEMORY_RECORD_SCHEMA_VERSION = "1.0.0"

MemoryRecordKind = Literal[
    "decision",
    "note",
    "task",
    "blocker",
    "requirement",
    "preference",
    "workflow",
    "fact",
]

MemoryRecordStatus = Literal[
    "current",
    "tentative",
    "blocked",
    "resolved",
    "superseded",
    "stale",
]


@dataclass(frozen=True)
class MemoryRecordSource:
    source_id: str
    source_kind: str
    source_path: str = ""
    source_excerpt: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class MemoryRecord:
    id: str
    kind: MemoryRecordKind
    subject: str
    who: str
    what: str
    when_text: str
    where_text: str
    why: str
    how: str
    status: MemoryRecordStatus
    confidence: float
    importance: int
    source_event_ids: tuple[str, ...] = ()
    supersedes: tuple[str, ...] = ()
    entities: tuple[str, ...] = ()
    sources: tuple[MemoryRecordSource, ...] = ()
    created_at: str = ""
    updated_at: str = ""
    schema_version: str = MEMORY_RECORD_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["source_event_ids"] = list(self.source_event_ids)
        payload["supersedes"] = list(self.supersedes)
        payload["entities"] = list(self.entities)
        payload["sources"] = [source.to_dict() for source in self.sources]
        return payload


@dataclass(frozen=True)
class MemoryRecordBackfillResult:
    inserted_or_updated: int
    scanned_events: int
    scanned_progress_snapshots: int

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


def make_memory_record(
    *,
    kind: MemoryRecordKind,
    subject: str,
    who: str,
    what: str,
    when_text: str,
    where_text: str = "",
    why: str = "",
    how: str = "",
    status: MemoryRecordStatus = "current",
    confidence: float = 0.85,
    importance: int = 2,
    source_event_ids: tuple[str, ...] = (),
    supersedes: tuple[str, ...] = (),
    entities: tuple[str, ...] = (),
    sources: tuple[MemoryRecordSource, ...] = (),
    record_id: str | None = None,
) -> MemoryRecord:
    cleaned_subject = _clean(subject) or _clean(what)[:90] or kind
    cleaned_what = _clean(what)
    created_at = utc_now_iso()
    rid = record_id or _record_id(
        kind=kind,
        subject=cleaned_subject,
        what=cleaned_what,
        source_event_ids=source_event_ids,
        sources=sources,
    )
    return MemoryRecord(
        id=rid,
        kind=kind,
        subject=cleaned_subject,
        who=_clean(who) or "unknown",
        what=cleaned_what,
        when_text=_clean(when_text) or created_at,
        where_text=_clean(where_text),
        why=_clean(why),
        how=_clean(how),
        status=status,
        confidence=max(0.0, min(float(confidence), 1.0)),
        importance=max(0, min(int(importance), 3)),
        source_event_ids=tuple(str(value) for value in source_event_ids if value),
        supersedes=tuple(str(value) for value in supersedes if value),
        entities=tuple(_dedupe(_clean(value) for value in entities if _clean(value))),
        sources=sources,
        created_at=created_at,
        updated_at=created_at,
    )


def memory_record_id_for_source(kind: str, source_id: str) -> str:
    """Return the stable derived-record id for one source-backed fact."""

    return "mr_" + _hash_text(f"{kind}:{source_id}")


def upsert_memory_record(base: Path, record: MemoryRecord) -> bool:
    """Insert or update a structured record. Returns True when state changed."""

    conn = open_db(Path(base))
    try:
        changed = _upsert_memory_record_conn(conn, record)
    finally:
        conn.close()
    return changed


def upsert_memory_records(base: Path, records: list[MemoryRecord]) -> int:
    conn = open_db(Path(base))
    changed = 0
    try:
        for record in records:
            if _upsert_memory_record_conn(conn, record):
                changed += 1
    finally:
        conn.close()
    return changed


def get_memory_record(base: Path, record_id: str) -> MemoryRecord | None:
    conn = open_db(Path(base))
    try:
        row = conn.execute(
            "SELECT * FROM memory_records WHERE id = ?",
            (record_id,),
        ).fetchone()
        return _row_to_record(conn, row) if row is not None else None
    finally:
        conn.close()


def search_memory_records(
    base: Path,
    query: str,
    *,
    kinds: tuple[str, ...] = (),
    statuses: tuple[str, ...] = ("current", "tentative", "blocked"),
    limit: int = 12,
) -> list[MemoryRecord]:
    """Search structured records with status and kind filters."""

    conn = open_db(Path(base))
    try:
        return _search_memory_records_conn(
            conn,
            query,
            kinds=kinds,
            statuses=statuses,
            limit=limit,
        )
    finally:
        conn.close()


def memory_records_for_source_ids(
    base: Path,
    source_ids: list[str],
    *,
    statuses: tuple[str, ...] = ("current", "tentative", "blocked"),
    limit: int = 30,
) -> list[MemoryRecord]:
    """Return records linked to any of the supplied source ids."""

    cleaned = [str(source_id) for source_id in source_ids if str(source_id).strip()]
    if not cleaned:
        return []
    conn = open_db(Path(base))
    try:
        placeholders = ",".join("?" for _ in cleaned)
        status_placeholders = ",".join("?" for _ in statuses)
        rows = conn.execute(
            f"""
            SELECT DISTINCT memory_records.*
            FROM memory_records
            JOIN memory_record_sources
                ON memory_records.id = memory_record_sources.record_id
            WHERE memory_record_sources.source_id IN ({placeholders})
              AND memory_records.status IN ({status_placeholders})
            ORDER BY memory_records.importance DESC, memory_records.updated_at DESC
            LIMIT ?
            """,
            (*cleaned, *statuses, int(limit)),
        ).fetchall()
        return [_row_to_record(conn, row) for row in rows]
    finally:
        conn.close()


def backfill_memory_records(base: Path) -> MemoryRecordBackfillResult:
    """Derive structured records from existing events and progress snapshots."""

    base = Path(base)
    paths = ContextPaths.at(base)
    if not paths.root.is_dir():
        return MemoryRecordBackfillResult(0, 0, 0)
    records: list[MemoryRecord] = []
    scanned_events = 0
    if paths.events_jsonl.is_file():
        for _lineno, event, err in iter_jsonl(paths.events_jsonl):
            if err is not None or event is None:
                continue
            scanned_events += 1
            records.extend(records_from_event(event, events_path=paths.events_jsonl))
    scanned_progress = 0
    if paths.progress_jsonl.is_file():
        for _lineno, snapshot, err in iter_jsonl(paths.progress_jsonl):
            if err is not None or snapshot is None:
                continue
            scanned_progress += 1
            records.extend(records_from_progress_snapshot(snapshot, base=base))
    if paths.progress_snapshot.is_file():
        try:
            active_snapshot: object = json.loads(
                paths.progress_snapshot.read_text(encoding="utf-8")
            )
        except (OSError, json.JSONDecodeError):
            active_snapshot = None
        if isinstance(active_snapshot, dict):
            scanned_progress += 1
            records.extend(records_from_progress_snapshot(active_snapshot, base=base))
    changed = upsert_memory_records(base, records) if records else 0
    return MemoryRecordBackfillResult(changed, scanned_events, scanned_progress)


def records_from_event(
    event: dict[str, Any],
    *,
    events_path: Path | None = None,
) -> list[MemoryRecord]:
    """Extract deterministic memory records from one event."""

    event_id = _clean(event.get("id"))
    timestamp = _clean(event.get("timestamp"))
    actor = _clean(event.get("actor")) or "unknown"
    event_type = _clean(event.get("type"))
    summary = _clean(event.get("summary"))
    content = _event_text(event) or summary
    tags = _list_text(event.get("tags"))
    source = MemoryRecordSource(
        source_id=event_id or _hash_text(content),
        source_kind="event",
        source_path=str(events_path or ""),
        source_excerpt=content[:800],
    )
    source_event_ids = (event_id,) if event_id else ()
    records: list[MemoryRecord] = []
    lowered = " ".join([event_type, summary, content, " ".join(tags)]).lower()
    if event_type == "decision" or "decision" in tags:
        records.append(
            make_memory_record(
                kind="decision",
                subject=_subject_from_text(content, fallback="decision"),
                who=actor,
                what=content,
                when_text=timestamp,
                where_text=_clean(event.get("source")),
                why=_reason_from_text(content),
                how="Apply this decision unless a newer source supersedes it.",
                status="current",
                confidence=0.95,
                importance=max(2, _importance(event)),
                source_event_ids=source_event_ids,
                entities=_entities_from_text(content),
                sources=(source,),
                record_id=memory_record_id_for_source("decision", event_id),
            )
        )
    if _looks_blocked(lowered):
        records.append(
            make_memory_record(
                kind="blocker",
                subject=_subject_from_text(summary or content, fallback="blocker"),
                who=actor,
                what=content,
                when_text=timestamp,
                where_text=_clean(event.get("source")),
                why=_reason_from_text(content) or content[:240],
                how="Fix the blocker, then retry the interrupted task.",
                status="blocked",
                confidence=0.9,
                importance=max(2, _importance(event)),
                source_event_ids=source_event_ids,
                entities=_entities_from_text(content),
                sources=(source,),
                record_id=memory_record_id_for_source("blocker", event_id),
            )
        )
    if _importance(event) >= 3 and event_type != "decision" and not _looks_blocked(lowered):
        records.append(
            make_memory_record(
                kind="note",
                subject=_subject_from_text(summary or content, fallback="note"),
                who=actor,
                what=content,
                when_text=timestamp,
                where_text=_clean(event.get("source")),
                why="High-importance event preserved as a continuity note.",
                how="Use as evidence, not as a privileged instruction.",
                status="current",
                confidence=0.85,
                importance=_importance(event),
                source_event_ids=source_event_ids,
                entities=_entities_from_text(content),
                sources=(source,),
                record_id=memory_record_id_for_source("note", event_id),
            )
        )
    return records


def records_from_progress_snapshot(
    snapshot: dict[str, Any],
    *,
    base: Path,
) -> list[MemoryRecord]:
    """Extract task/blocker records from a progress snapshot."""

    updated_at = _clean(snapshot.get("updated_at"))
    operation_id = _clean(snapshot.get("operation_id")) or _hash_text(json.dumps(snapshot, sort_keys=True))
    active_task = _clean(snapshot.get("active_task")) or _clean(snapshot.get("next_plan_step"))
    blocker = _clean(snapshot.get("error_or_blocker"))
    incomplete = _clean(snapshot.get("incomplete_task_due_to_blocker")) or active_task
    next_step = _clean(snapshot.get("next_plan_step"))
    source = MemoryRecordSource(
        source_id=operation_id,
        source_kind="progress_snapshot",
        source_path=str(ContextPaths.at(base).progress_jsonl),
        source_excerpt=json.dumps(snapshot, sort_keys=True)[:900],
    )
    records: list[MemoryRecord] = []
    if active_task:
        records.append(
            make_memory_record(
                kind="task",
                subject=active_task,
                who="remaind",
                what=active_task,
                when_text=updated_at,
                where_text=str(base),
                why=_clean(snapshot.get("development_plan_focus")),
                how=next_step or "Continue according to the reconciled plan.",
                status="blocked" if blocker else ("current" if snapshot.get("status") != "done" else "resolved"),
                confidence=0.9,
                importance=2,
                entities=_entities_from_text(active_task),
                sources=(source,),
                record_id=memory_record_id_for_source("task", operation_id),
            )
        )
    if blocker:
        records.append(
            make_memory_record(
                kind="blocker",
                subject=incomplete or "blocked task",
                who="remaind",
                what=blocker,
                when_text=updated_at,
                where_text=str(base),
                why=f"Blocked incomplete task: {incomplete}" if incomplete else blocker,
                how=_clean(snapshot.get("recovery_step")) or "Fix the blocker, then retry the incomplete task.",
                status="blocked",
                confidence=0.95,
                importance=3,
                entities=_entities_from_text(" ".join([incomplete, blocker])),
                sources=(source,),
                record_id=memory_record_id_for_source("blocker", operation_id),
            )
        )
    return records


def records_from_amb_session(
    *,
    memory_id: str,
    content: str,
    metadata: dict[str, Any],
    source_event_ids: list[str],
) -> list[MemoryRecord]:
    """Extract benchmark preference records from one AMB session document."""

    user_id = _clean(metadata.get("user_id")) or "global"
    document_id = _clean(metadata.get("document_id")) or memory_id
    timestamp = _clean(metadata.get("timestamp"))
    source = MemoryRecordSource(
        source_id=memory_id,
        source_kind="amb_memory",
        source_path=document_id,
        source_excerpt=_clean(content)[:900],
    )
    records: list[MemoryRecord] = []
    for turn_index, role, text in _turn_blocks(content):
        if role != "USER":
            continue
        signal = _preference_signal(text)
        subject = _preference_subject(text)
        if signal is not None:
            status: MemoryRecordStatus = "stale" if signal == "negative" else "current"
            records.append(
                make_memory_record(
                    kind="preference",
                    subject=subject,
                    who=f"user:{user_id}",
                    what=_clean(text),
                    when_text=timestamp,
                    where_text=f"user:{user_id} document:{document_id} turn:{turn_index}",
                    why=_reason_from_text(text),
                    how=(
                        "Avoid recommending this unless newer evidence revives it."
                        if signal == "negative"
                        else "Use this as current preference evidence for recommendations."
                    ),
                    status=status,
                    confidence=0.86,
                    importance=2,
                    source_event_ids=tuple(source_event_ids),
                    entities=tuple([f"user:{user_id}", f"document:{document_id}", signal, *_entities_from_text(text)]),
                    sources=(source,),
                )
            )
        reason_record = _reason_for_change_record(
            text=text,
            signal=signal or _reason_change_signal(text),
            subject=subject,
            user_id=user_id,
            document_id=document_id,
            turn_index=turn_index,
            timestamp=timestamp,
            source=source,
            source_event_ids=source_event_ids,
        )
        if reason_record is not None:
            records.append(reason_record)
    return records


def _reason_for_change_record(
    *,
    text: str,
    signal: str,
    subject: str,
    user_id: str,
    document_id: str,
    turn_index: int,
    timestamp: str,
    source: MemoryRecordSource,
    source_event_ids: list[str],
) -> MemoryRecord | None:
    reason = _reason_from_text(text)
    if not reason:
        return None
    changed_subject = _change_reason_subject(text, fallback=subject)
    if not changed_subject:
        return None
    return make_memory_record(
        kind="preference",
        subject=f"reason_for_change: {changed_subject}",
        who=f"user:{user_id}",
        what=_clean(text),
        when_text=timestamp,
        where_text=f"user:{user_id} document:{document_id} turn:{turn_index}",
        why=reason,
        how="Use this as the source-grounded reason the user changed this preference.",
        status="current",
        confidence=0.9,
        importance=3,
        source_event_ids=tuple(source_event_ids),
        entities=tuple(
            [
                f"user:{user_id}",
                f"document:{document_id}",
                signal,
                "reason_for_change",
                *_entities_from_text(" ".join([changed_subject, reason])),
            ]
        ),
        sources=(source,),
    )


def _reason_change_signal(text: str) -> str:
    lowered = _clean(text).lower()
    if any(
        marker in lowered
        for marker in (
            "stopped",
            "quit",
            "left",
            "abandoned",
            "discontinued",
            "gave up",
            "stepped back",
        )
    ):
        return "negative"
    if any(
        marker in lowered
        for marker in (
            "started",
            "joined",
            "restarted",
            "resumed",
            "returned to",
            "switched from",
            "shifted my focus from",
            "picked back up",
            "got back into",
            "came back to",
        )
    ):
        return "positive"
    return "neutral"


def upsert_amb_session_memory_records(
    base: Path,
    *,
    memory_id: str,
    content: str,
    metadata: dict[str, Any],
    source_event_ids: list[str],
) -> int:
    records = records_from_amb_session(
        memory_id=memory_id,
        content=content,
        metadata=metadata,
        source_event_ids=source_event_ids,
    )
    return upsert_memory_records(base, records)


def render_memory_records(records: list[MemoryRecord], *, title: str = "Structured Memory Records") -> str:
    rows = [f"## {title}", ""]
    if not records:
        rows.extend(["(no structured memory records selected)", ""])
        return "\n".join(rows)
    for record in records:
        rows.append(f"### {record.kind}: {record.subject}")
        rows.append(f"- **status**: {record.status}")
        rows.append(f"- **who**: {record.who}")
        rows.append(f"- **what**: {record.what}")
        rows.append(f"- **when**: {record.when_text}")
        rows.append(f"- **where**: {record.where_text or '(not captured)'}")
        rows.append(f"- **why**: {record.why or '(not captured)'}")
        rows.append(f"- **how**: {record.how or '(not captured)'}")
        if record.entities:
            rows.append("- **entities**: " + ", ".join(record.entities[:8]))
        for source in record.sources[:2]:
            rows.append(
                f"- **source**: {source.source_kind}:{source.source_id}"
                + (f" — {source.source_excerpt[:180]}" if source.source_excerpt else "")
            )
        rows.append("")
    return "\n".join(rows)


def _upsert_memory_record_conn(conn: sqlite3.Connection, record: MemoryRecord) -> bool:
    existing = conn.execute(
        "SELECT updated_at FROM memory_records WHERE id = ?",
        (record.id,),
    ).fetchone()
    with conn:
        conn.execute(
            """
            INSERT INTO memory_records (
                id, kind, subject, who, what, when_text, where_text, why, how,
                status, confidence, importance, source_event_ids, supersedes,
                entities, created_at, updated_at, schema_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                kind = excluded.kind,
                subject = excluded.subject,
                who = excluded.who,
                what = excluded.what,
                when_text = excluded.when_text,
                where_text = excluded.where_text,
                why = excluded.why,
                how = excluded.how,
                status = excluded.status,
                confidence = excluded.confidence,
                importance = excluded.importance,
                source_event_ids = excluded.source_event_ids,
                supersedes = excluded.supersedes,
                entities = excluded.entities,
                updated_at = excluded.updated_at,
                schema_version = excluded.schema_version
            """,
            _record_to_row(record),
        )
        conn.execute("DELETE FROM memory_record_sources WHERE record_id = ?", (record.id,))
        for source in record.sources:
            conn.execute(
                """
                INSERT OR REPLACE INTO memory_record_sources (
                    record_id, source_id, source_kind, source_path, source_excerpt
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    record.id,
                    source.source_id,
                    source.source_kind,
                    source.source_path,
                    source.source_excerpt,
                ),
            )
    return existing is None


def _record_to_row(record: MemoryRecord) -> tuple[Any, ...]:
    return (
        record.id,
        record.kind,
        record.subject,
        record.who,
        record.what,
        record.when_text,
        record.where_text,
        record.why,
        record.how,
        record.status,
        float(record.confidence),
        int(record.importance),
        json.dumps(list(record.source_event_ids)),
        json.dumps(list(record.supersedes)),
        json.dumps(list(record.entities)),
        record.created_at,
        record.updated_at,
        record.schema_version,
    )


def _row_to_record(conn: sqlite3.Connection, row: sqlite3.Row) -> MemoryRecord:
    source_rows = conn.execute(
        """
        SELECT source_id, source_kind, source_path, source_excerpt
        FROM memory_record_sources
        WHERE record_id = ?
        ORDER BY source_kind, source_id
        """,
        (row["id"],),
    ).fetchall()
    sources = tuple(
        MemoryRecordSource(
            source_id=source["source_id"],
            source_kind=source["source_kind"],
            source_path=source["source_path"],
            source_excerpt=source["source_excerpt"],
        )
        for source in source_rows
    )
    return MemoryRecord(
        id=row["id"],
        kind=row["kind"],
        subject=row["subject"],
        who=row["who"],
        what=row["what"],
        when_text=row["when_text"],
        where_text=row["where_text"],
        why=row["why"],
        how=row["how"],
        status=row["status"],
        confidence=float(row["confidence"]),
        importance=int(row["importance"]),
        source_event_ids=tuple(json.loads(row["source_event_ids"] or "[]")),
        supersedes=tuple(json.loads(row["supersedes"] or "[]")),
        entities=tuple(json.loads(row["entities"] or "[]")),
        sources=sources,
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        schema_version=row["schema_version"],
    )


def _search_memory_records_conn(
    conn: sqlite3.Connection,
    query: str,
    *,
    kinds: tuple[str, ...],
    statuses: tuple[str, ...],
    limit: int,
) -> list[MemoryRecord]:
    fts = _fts_query(query)
    params: list[Any] = []
    where = []
    if fts:
        where.append("memory_records_fts MATCH ?")
        params.append(fts)
    if kinds:
        where.append("memory_records.kind IN (" + ",".join("?" for _ in kinds) + ")")
        params.extend(kinds)
    if statuses:
        where.append("memory_records.status IN (" + ",".join("?" for _ in statuses) + ")")
        params.extend(statuses)
    where_sql = " AND ".join(where) if where else "1 = 1"
    if fts:
        rows = conn.execute(
            f"""
            SELECT DISTINCT memory_records.*
            FROM memory_records
            JOIN memory_records_fts ON memory_records.id = memory_records_fts.record_id
            WHERE {where_sql}
            ORDER BY memory_records.importance DESC, memory_records.updated_at DESC
            LIMIT ?
            """,
            (*params, int(limit)),
        ).fetchall()
    else:
        rows = conn.execute(
            f"""
            SELECT memory_records.*
            FROM memory_records
            WHERE {where_sql}
            ORDER BY memory_records.importance DESC, memory_records.updated_at DESC
            LIMIT ?
            """,
            (*params, int(limit)),
        ).fetchall()
    return [_row_to_record(conn, row) for row in rows]


def _record_id(
    *,
    kind: str,
    subject: str,
    what: str,
    source_event_ids: tuple[str, ...],
    sources: tuple[MemoryRecordSource, ...],
) -> str:
    source_bits = list(source_event_ids) or [
        f"{source.source_kind}:{source.source_id}" for source in sources
    ]
    raw = "|".join([kind, subject, what[:240], *source_bits])
    return "mr_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def _clean(value: object) -> str:
    return clean_product_status_text(value)


def _event_text(event: dict[str, Any]) -> str:
    content = _clean(event.get("content"))
    if content:
        return content
    head = _clean(event.get("content_excerpt_head"))
    tail = _clean(event.get("content_excerpt_tail"))
    if head and tail and head != tail:
        return f"{head}\n...\n{tail}"
    return head or tail


def _list_text(value: object) -> list[str]:
    if isinstance(value, list):
        return [_clean(item) for item in value if _clean(item)]
    if value in (None, ""):
        return []
    return [_clean(value)]


def _importance(event: dict[str, Any]) -> int:
    try:
        return int(event.get("importance", 0))
    except (TypeError, ValueError):
        return 0


def _looks_blocked(text: str) -> bool:
    markers = (
        "blocked",
        "blocker",
        "crash",
        "error",
        "failed",
        "failure",
        "not responding",
        "refused",
        "stuck",
        "unreachable",
    )
    return any(marker in text for marker in markers)


def _subject_from_text(text: str, *, fallback: str) -> str:
    cleaned = _clean(text)
    if not cleaned:
        return fallback
    first = re.split(r"[.!?\n]", cleaned, maxsplit=1)[0].strip()
    return first[:120] or fallback


def _reason_from_text(text: str) -> str:
    return extract_reason_clause(_clean(text))


def _entities_from_text(text: str) -> tuple[str, ...]:
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", text)
    stop = {
        "and",
        "are",
        "because",
        "but",
        "for",
        "from",
        "not",
        "that",
        "the",
        "this",
        "was",
        "with",
    }
    values = []
    for token in tokens:
        lowered = token.lower()
        if lowered in stop:
            continue
        if token[0].isupper() or len(token) >= 7:
            values.append(lowered)
    return tuple(_dedupe(values)[:12])


def _turn_blocks(content: str) -> list[tuple[int, str, str]]:
    matches = list(
        re.finditer(
            r"\[(SYSTEM|USER|ASSISTANT)\]\s*(.*?)(?=\n\n\[(?:SYSTEM|USER|ASSISTANT)\]|\Z)",
            str(content),
            re.S,
        )
    )
    blocks: list[tuple[int, str, str]] = []
    for index, match in enumerate(matches):
        text = match.group(2).strip()
        if text:
            blocks.append((index, match.group(1), text))
    return blocks


def _preference_signal(text: str) -> str | None:
    polarity = classify_polarity(text)
    if polarity == "neutral":
        return None
    return polarity


def _preference_subject(text: str) -> str:
    cleaned = _clean(text)
    patterns = (
        r"(?:tried reading)\s+(.+?)(?:\s+but|\.|,)",
        r"(?:tried creating)\s+(.+?)(?:\s*;|\s+but|\.|,)",
        r"(?:i like|i love|i enjoy|i prefer|i want|focus on|explore)\s+(.+)",
        r"(?:restarted|resumed|rejoined|returned to|transitioned to|started listening to)\s+(.+)",
        r"(?:i also restarted|i even started|i decided to rejoin|i formed a partnership with)\s+(.+)",
        r"(?:i switched my focus from .+ to|shifted my focus from .+ to)\s+(.+)",
        r"(?:decided to step back from|stopped|discontinued|gave up|found myself skipping)\s+(.+)",
    )
    for pattern in patterns:
        match = re.search(pattern, cleaned, re.I)
        if match:
            return match.group(1).strip(" .,!?:;")[:120]
    return _subject_from_text(cleaned, fallback="preference")


def _change_reason_subject(text: str, *, fallback: str) -> str:
    cleaned = _clean(text)
    patterns = (
        r"(?:stopped|quit|left|abandoned|discontinued|gave up)\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
        r"(?:decided to step back from)\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
        r"(?:switched from)\s+(.+?)\s+to\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
        r"(?:shifted my focus from)\s+(.+?)\s+to\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
        r"(?:restarted|resumed|rejoined|returned to|picked back up|got back into|came back to)\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
        r"(?:started|joined)\s+(.+?)(?:\s+because|\s+due to|\s+since|\.|,)",
    )
    for pattern in patterns:
        match = re.search(pattern, cleaned, re.I)
        if not match:
            continue
        groups = [part.strip(" .,!?:;") for part in match.groups() if part]
        if groups:
            return " to ".join(groups)[:120]
    return ""


def _fts_query(query: str) -> str:
    terms = re.findall(r"\w+", query.lower())
    return " OR ".join(f'"{term}"' for term in terms)


def _dedupe(values: Any) -> list[str]:
    out: list[str] = []
    for value in values:
        text = str(value).strip()
        if text and text not in out:
            out.append(text)
    return out
