"""Mechanical resume gate.

Implements the §8 contract:

  *The agent should interrupt the user only when:*
  - raw log, state, and handover conflict
  - ``next_step`` is missing
  - latest user instruction is not represented
  - resume confidence is low and the next planned tool has ``mutates``,
    ``spends_money``, or ``external_side_effect``

Tool risk is mechanical and comes from ``schemas/tools.yaml`` — this module
never infers risk from prose.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ._adversarial import scan_packet_inputs
from ._configs import load_yaml_mapping


@dataclass(frozen=True)
class GateAssessment:
    should_interrupt: bool
    concerns: list[str]
    next_tool: str | None = None
    next_tool_risk: dict[str, bool] | None = None
    urgent: bool = False
    confidence_low: bool = field(default=False)
    adversarial_findings: list[dict[str, str]] = field(default_factory=list)


def load_tools_config(path: Path) -> dict[str, dict[str, Any]]:
    """Read ``tools.yaml`` into ``{tool_name: {mutates, spends_money, ...}}``."""
    data = load_yaml_mapping(path)
    tools = data.get("tools", []) or []
    if not isinstance(tools, list):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for entry in tools:
        if not isinstance(entry, dict) or "name" not in entry:
            continue
        out[str(entry["name"])] = {
            "mutates": bool(entry.get("mutates", False)),
            "spends_money": bool(entry.get("spends_money", False)),
            "external_side_effect": bool(entry.get("external_side_effect", False)),
            "description": str(entry.get("description", "")),
        }
    return out


def _has_any_risk(risk: dict[str, bool] | None) -> bool:
    if not risk:
        return False
    return any(bool(risk.get(k)) for k in ("mutates", "spends_money", "external_side_effect"))


def evaluate_gate(
    state: dict,
    handover: str,
    raw_excerpts: list[dict],
    *,
    memories: list[Any] | None = None,
    next_tool: str | None = None,
    tools_config: dict[str, dict[str, Any]] | None = None,
) -> GateAssessment:
    """Run the §8 checks. Returns whether to interrupt the user."""
    concerns: list[str] = []

    # 1. next_step missing
    next_step = (state.get("next_step") or "").strip()
    if not next_step:
        concerns.append("next_step is missing or empty")

    # 2. latest user instruction not represented
    latest_id = state.get("latest_user_instruction_event_id")
    if latest_id:
        in_excerpts = any(e.get("id") == latest_id for e in raw_excerpts)
        in_handover = latest_id in (handover or "")
        if not (in_excerpts or in_handover):
            concerns.append(
                f"latest_user_instruction_event_id {latest_id!r} not represented "
                f"in handover or raw log excerpts"
            )

    # 3. log/state/handover conflict (v1 mechanical proxy)
    #    Decisions in state should be referenced somewhere in handover; if not,
    #    that's a soft conflict (handover and state diverged).
    for decision in state.get("decisions", []) or []:
        if decision and decision not in (handover or ""):
            concerns.append(
                f"state decision not represented in handover: {decision!r}"
            )
    for blocker in state.get("open_blockers", []) or []:
        if blocker and blocker not in (handover or ""):
            concerns.append(
                f"state blocker not represented in handover: {blocker!r}"
            )

    adversarial = scan_packet_inputs(
        handover=handover,
        state=state,
        raw_excerpts=raw_excerpts,
        memories=memories or [],
    )
    for finding in adversarial[:10]:
        source_id = f" {finding.source_id}" if finding.source_id else ""
        concerns.append(
            f"adversarial {finding.severity}: {finding.source}{source_id}: "
            f"{finding.issue}"
        )
    if len(adversarial) > 10:
        concerns.append(f"adversarial review has {len(adversarial) - 10} additional finding(s)")

    confidence_low = bool(concerns)

    # 4. next-tool risk * confidence
    tools_config = tools_config or {}
    risk = tools_config.get(next_tool) if next_tool else None
    risk_flags = (
        {
            "mutates": bool(risk.get("mutates", False)),
            "spends_money": bool(risk.get("spends_money", False)),
            "external_side_effect": bool(risk.get("external_side_effect", False)),
        }
        if risk
        else None
    )
    urgent = confidence_low and _has_any_risk(risk_flags)

    should_interrupt = bool(concerns)
    return GateAssessment(
        should_interrupt=should_interrupt,
        concerns=concerns,
        next_tool=next_tool,
        next_tool_risk=risk_flags,
        urgent=urgent,
        confidence_low=confidence_low,
        adversarial_findings=[finding.to_dict() for finding in adversarial],
    )
