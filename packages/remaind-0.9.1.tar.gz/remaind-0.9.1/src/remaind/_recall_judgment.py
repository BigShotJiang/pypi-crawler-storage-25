"""Shared recall judgment helpers for Remaind context packets.

Recall questions are a different task than recommendations: the right answer is
the exact thing the user previously said, not the most plausible fact implied by
their profile. This module keeps that rule shared by benchmark packets and the
normal product flows so they cannot drift.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

_STOPWORDS = {
    "about",
    "also",
    "and",
    "answer",
    "anything",
    "asked",
    "before",
    "did",
    "does",
    "enjoy",
    "enjoyed",
    "fact",
    "facts",
    "for",
    "from",
    "have",
    "hear",
    "heard",
    "know",
    "like",
    "liked",
    "mention",
    "mentioned",
    "memory",
    "previously",
    "recall",
    "remember",
    "remembered",
    "said",
    "say",
    "share",
    "shared",
    "that",
    "the",
    "this",
    "told",
    "user",
    "what",
    "when",
    "where",
    "which",
    "with",
    "you",
    "your",
}

_RECALL_REQUEST_MARKERS = (
    "what did i",
    "what did you remember",
    "what do you remember",
    "what have i told you",
    "what did i tell you",
    "what did i say",
    "what did i mention",
    "what have i mentioned",
    "what did i share",
    "what have i shared",
    "do you remember",
    "remind me what",
    "recall what",
)

_RECAP_VOICE_MARKERS = (
    "i remember",
    "you mentioned",
    "you told me",
    "you shared",
    "you said",
    "i recall",
)

_BACKGROUND_MARKERS = (
    "low-authority background profile",
    "background profile",
    "benchmark profile",
    "biographical background",
    "persona/profession",
    "profession is biographical",
    "durable user/session profile",
)

_QUESTION_ONLY_MARKERS = (
    "## current question",
    "## task",
    "candidate verification matrix",
    "per-option evidence anchoring",
)


@dataclass(frozen=True)
class RecallEvidenceUnit:
    text: str
    authority: str


@dataclass(frozen=True)
class RecallOptionJudgment:
    score_adjustment: float
    direct_refs: int
    background_refs: int
    exact_phrase_hits: tuple[str, ...]
    unsupported_terms: tuple[str, ...]
    reasons: tuple[str, ...]
    decision_signal: str


def looks_like_recall_request(question: str) -> bool:
    """Return true when the user asks to recall what was said or shared."""

    lowered = question.lower()
    return any(marker in lowered for marker in _RECALL_REQUEST_MARKERS)


def important_recall_terms(text: str) -> list[str]:
    """Extract terms that can discriminate one recalled fact from another."""

    terms = [
        match.group(0).lower()
        for match in re.finditer(r"[a-z][a-z0-9_-]{2,}", text.lower())
    ]
    return [term for term in terms if term not in _STOPWORDS and not term.isdigit()]


def recall_option_judgments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, RecallOptionJudgment]:
    """Judge each candidate answer against exact user/source evidence."""

    evidence_units = _evidence_units(evidence_texts)
    option_terms = {
        letter: tuple(important_recall_terms(option_text))
        for letter, option_text in options
    }
    term_frequency: dict[str, int] = {}
    for terms in option_terms.values():
        for term in set(terms):
            term_frequency[term] = term_frequency.get(term, 0) + 1

    judgments: dict[str, RecallOptionJudgment] = {}
    for letter, option_text in options:
        terms = option_terms[letter]
        discriminators = tuple(
            term for term in terms if term_frequency.get(term, 0) == 1
        )
        if not discriminators:
            discriminators = terms[:8]
        phrases = _discriminator_phrases(discriminators)
        direct_units: list[RecallEvidenceUnit] = []
        background_units: list[RecallEvidenceUnit] = []
        direct_terms: set[str] = set()
        exact_phrases: set[str] = set()

        for unit in evidence_units:
            unit_hits = [
                term for term in discriminators if _term_present(term, unit.text)
            ]
            phrase_hits = [
                phrase for phrase in phrases if _phrase_present(phrase, unit.text)
            ]
            if not unit_hits and not phrase_hits:
                continue
            if unit.authority == "background":
                background_units.append(unit)
                continue
            direct_units.append(unit)
            direct_terms.update(unit_hits)
            exact_phrases.update(phrase_hits)

        unsupported = tuple(
            term for term in discriminators if term not in direct_terms
        )[:6]
        score = 0.0
        reasons: list[str] = []
        if direct_units:
            score += 9.0 + min(6.0, len(direct_terms) * 1.25)
            reasons.append("direct user/source evidence")
        if exact_phrases:
            score += min(5.0, len(exact_phrases) * 2.0)
            reasons.append("exact phrase evidence")
        if background_units and not direct_units:
            score -= 8.0
            reasons.append("background/profile only")
        if not direct_units:
            score -= 3.0
            reasons.append("no direct user evidence")
        has_recap_voice = option_text.lower().strip().startswith(_RECAP_VOICE_MARKERS)
        if has_recap_voice and direct_units:
            score += 2.5
            reasons.append("recap voice backed by evidence")
        elif has_recap_voice and not direct_units:
            score -= 2.5
            reasons.append("recap voice without evidence")

        if direct_units:
            signal = "choose exact user/source evidence over plausible background"
        elif background_units:
            signal = "penalize profile-only plausibility"
        else:
            signal = "unsupported by loaded recall evidence"
        judgments[letter] = RecallOptionJudgment(
            score_adjustment=score,
            direct_refs=len(direct_units),
            background_refs=len(background_units),
            exact_phrase_hits=tuple(sorted(exact_phrases)[:4]),
            unsupported_terms=unsupported,
            reasons=tuple(reasons),
            decision_signal=signal,
        )
    return judgments


def recall_option_adjustments(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, tuple[float, list[str]]]:
    """Return scorer-compatible adjustments for contrastive recall options."""

    adjustments: dict[str, tuple[float, list[str]]] = {}
    for letter, judgment in recall_option_judgments(options, evidence_texts).items():
        if judgment.score_adjustment != 0.0:
            adjustments[letter] = (
                judgment.score_adjustment,
                [f"recall: {reason}" for reason in judgment.reasons],
            )
    return adjustments


def recall_option_evidence_summaries(
    options: Sequence[tuple[str, str]],
    evidence_texts: Sequence[str],
) -> dict[str, str]:
    """Render compact per-option summaries for recall evidence packets."""

    summaries: dict[str, str] = {}
    for letter, judgment in recall_option_judgments(options, evidence_texts).items():
        phrase_text = (
            ", ".join(judgment.exact_phrase_hits)
            if judgment.exact_phrase_hits
            else "none"
        )
        unsupported = (
            ", ".join(judgment.unsupported_terms)
            if judgment.unsupported_terms
            else "none"
        )
        summaries[letter] = (
            f"direct_user_refs={judgment.direct_refs}; "
            f"background_only_refs={judgment.background_refs}; "
            f"exact_phrases={phrase_text}; "
            f"unsupported_discriminators={unsupported}; "
            f"decision_signal={judgment.decision_signal}"
        )
    return summaries


def render_recall_judgment_section(
    question: str,
    evidence_texts: Sequence[str],
    *,
    options: Sequence[tuple[str, str]] = (),
) -> str:
    """Render product-facing recall rules grounded in loaded evidence."""

    if not looks_like_recall_request(question):
        return ""
    evidence_units = _evidence_units(evidence_texts)
    focus_terms = important_recall_terms(question)
    direct_hits = _matching_units(evidence_units, focus_terms, authority="direct")
    background_hits = _matching_units(evidence_units, focus_terms, authority="background")
    rows = [
        "## Recall Judgment",
        "",
        (
            "Use this section when the answer recalls what the user said, "
            "mentioned, told the system, or shared earlier."
        ),
        (
            "Rule: direct user/source evidence outranks plausible background, "
            "persona, profession, or generic profile fit. If loaded evidence "
            "does not show the recalled fact, say that instead of inferring it."
        ),
        "",
    ]
    if focus_terms:
        rows.append("Recall focus terms: " + ", ".join(focus_terms[:10]))
    if direct_hits:
        rows.append("Direct source evidence found:")
        for unit in direct_hits[:5]:
            rows.append(f"- {unit.text}")
    else:
        rows.append("Direct source evidence found: none in loaded context")
    if background_hits:
        rows.append("Background-only hints found:")
        for unit in background_hits[:3]:
            rows.append(f"- {unit.text}")
        rows.append("Background-only hints are not enough for a recall answer.")
    if options:
        rows.append("")
        rows.append("Candidate recall evidence:")
        summaries = recall_option_evidence_summaries(options, evidence_texts)
        for letter, _option_text in options:
            rows.append(f"- ({letter}) {summaries[letter]}")
    rows.append("")
    return "\n".join(rows)


def _evidence_units(evidence_texts: Sequence[str]) -> list[RecallEvidenceUnit]:
    units: list[RecallEvidenceUnit] = []
    for text in evidence_texts:
        for raw_unit in _split_evidence_text(str(text)):
            cleaned = re.sub(r"\s+", " ", raw_unit).strip()
            if len(cleaned) < 8:
                continue
            lowered = cleaned.lower()
            if any(marker in lowered for marker in _QUESTION_ONLY_MARKERS):
                continue
            authority = (
                "background"
                if any(marker in lowered for marker in _BACKGROUND_MARKERS)
                else "direct"
            )
            units.append(RecallEvidenceUnit(cleaned[:360], authority))
    return units


def _split_evidence_text(text: str) -> list[str]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) > 1:
        return lines
    return [part.strip() for part in re.split(r"(?<=[.!?])\s+", text) if part.strip()]


def _matching_units(
    units: Sequence[RecallEvidenceUnit],
    terms: Sequence[str],
    *,
    authority: str,
) -> list[RecallEvidenceUnit]:
    if not terms:
        return []
    matches: list[RecallEvidenceUnit] = []
    for unit in units:
        if unit.authority != authority:
            continue
        if any(_term_present(term, unit.text) for term in terms):
            matches.append(unit)
    return matches


def _discriminator_phrases(terms: Sequence[str]) -> tuple[str, ...]:
    phrases: list[str] = []
    limited_terms = list(terms[:8])
    for size in (4, 3, 2):
        for index in range(0, max(len(limited_terms) - size + 1, 0)):
            phrase = " ".join(limited_terms[index : index + size])
            if len(phrase) >= 9:
                phrases.append(phrase)
    return tuple(dict.fromkeys(phrases))


def _term_present(term: str, text: str) -> bool:
    lowered = text.lower()
    forms = _term_forms(term)
    return any(re.search(rf"\b{re.escape(form)}[a-z0-9_-]*\b", lowered) for form in forms)


def _phrase_present(phrase: str, text: str) -> bool:
    normalized_text = re.sub(r"\s+", " ", text.lower())
    normalized_phrase = re.sub(r"\s+", " ", phrase.lower())
    return normalized_phrase in normalized_text


def _term_forms(term: str) -> tuple[str, ...]:
    forms = [term]
    if term.endswith("ies") and len(term) > 4:
        forms.append(term[:-3] + "y")
    if term.endswith("s") and len(term) > 4:
        forms.append(term[:-1])
    if len(term) > 7:
        forms.append(term[:7])
    return tuple(dict.fromkeys(forms))
