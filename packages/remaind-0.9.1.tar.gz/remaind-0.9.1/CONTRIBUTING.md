# Contributing

Remaind is local-first infrastructure for long-running AI work. Changes should
be small enough to review carefully and explicit enough to roll back safely.

## Pull Request Scope

- Keep one product feature, behavior change, or hardening effort per pull
  request.
- Do not bundle unrelated commands, website changes, packaging changes, or
  monitor/ops work into a feature PR unless the PR is specifically about that
  release surface.
- For risky or multi-phase work, split the rollout into reviewable phases:
  primitives/refactor, hidden implementation behind a flag, then user-facing
  wiring. Each phase must have its own tests and acceptance criteria.
- If a planned phase changes during implementation, update the PR description
  before review so reviewers are not signing an outdated contract.

## Review Contract

Every PR must state:

- The user problem being solved.
- The exact command or API surface changed.
- Whether existing CLI help output changed.
- How rollback works if the change fails after release.
- Which tests were run locally, including any skipped slow/model-backed proofs.

## CLI Flag Naming

Keep new flags predictable:

- Prefer positive nouns for configuration, such as `--model`, `--answer-key`,
  or `--deep-compact-chunk-tokens`.
- Use `--no-X` only for explicit opt-outs of behavior that would otherwise run,
  such as `--no-model`.
- Use `--<verb>-X` only for actions or reuse semantics, such as
  `--reuse-deep-compact`.
- Do not rename existing flags casually; add aliases only when there is a clear
  migration story.

## Verification

Before requesting review, run the local gate that matches the blast radius:

```sh
.venv/bin/python -m pytest -q
.venv/bin/python -m pytest --cov=src/remaind --cov-report=term-missing --cov-fail-under=80 -q
ruff check src tests scripts starter-kits/sovereign-memory-starter
mypy
python scripts/secret_scan.py
python scripts/validate_product_guardrails.py
python scripts/check_pr_scope.py origin/main...HEAD
```

For local-model features, add deterministic fake-model tests to CI and keep
real DeepSeek, Qwen, or GPT-OSS proofs in a slow/opt-in lane unless the release
spec explicitly requires a real-model proof.

The coverage gate is intentionally strict and tracks the current release bar.
If it fails, add focused tests or document an explicit release-manager decision
to lower the threshold; do not silently relax it as part of an unrelated PR.

## Evidence Discipline

Remaind evidence labels are product-critical. Do not promote derived or
model-authored text to `raw_line` or `verified_quote` unless the implementation
has verified it against the local source bytes or exact source line text.
Fallback paths must become more conservative, not more confident.
