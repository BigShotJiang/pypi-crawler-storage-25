# Benchmarks

Remaind includes executable product proofs. They are deterministic checks that
exercise continuity beyond a single live context window.

## STATE-Bench Public Benchmark Bridge

STATE-Bench is the first public benchmark bridge supported by Remaind. It is
the right first public proof because its official evaluation path allows
memory systems to expose a read-only `retrieve_learnings(query, top_k)` tool.

Prepare a local STATE-Bench checkout:

```sh
git clone https://github.com/microsoft/STATE-Bench.git /tmp/STATE-Bench
```

Then ask Remaind to build the learning artifact and install the adapter:

```sh
remaind public-bench state-bench prepare \
  --state-bench-repo /tmp/STATE-Bench \
  --workdir .remaind_bench/public/state-bench \
  --force
```

This command:

- reads STATE-Bench train trajectories from
  `datasets/train_task_trajectories/`,
- turns each trajectory into a deterministic procedural learning,
- stores every learning through Remaind's append-only event log and SQLite
  memory index,
- writes `state_bench_learnings.json` with source paths, source hashes, and
  source event ids,
- installs `agents/remaind_state_bench_agent.py` into the STATE-Bench checkout.

Before running the official STATE-Bench evaluation, smoke-test retrieval:

```sh
remaind public-bench state-bench retrieve \
  --artifact .remaind_bench/public/state-bench/state_bench_learnings.json \
  "business cancellation fee and rebooking"
```

Then run STATE-Bench from its own checkout using the command template printed
by `prepare`. The official benchmark still requires the STATE-Bench evaluation
runtime and credentials described by STATE-Bench, including its locked
simulator/judge configuration. Remaind owns the memory backend and artifact;
STATE-Bench owns the task execution and public metrics.

## Agent Memory Benchmark Bridge

Agent Memory Benchmark (AMB) evaluates memory providers through a provider
registry. Remaind installs a local provider into a checked-out AMB repo so AMB
can ingest benchmark documents into Remaind and retrieve source-linked context
through the normal event log and SQLite memory index.

Prepare a local AMB checkout:

```sh
git clone https://github.com/vectorize-io/agent-memory-benchmark.git /tmp/agent-memory-benchmark
```

Install the Remaind provider:

```sh
remaind public-bench amb prepare \
  --amb-repo /tmp/agent-memory-benchmark
```

This command:

- writes `src/memory_bench/memory/remaind.py` into the AMB checkout,
- patches AMB's provider registry so `--memory remaind` is selectable,
- points the generated provider at the current Remaind source path while still
  allowing `REMAIND_SOURCE_PATH` to override it,
- keeps benchmark data inside AMB's selected store directory under a normal
  `.context/` tree.

Smoke-test provider discovery:

```sh
cd /tmp/agent-memory-benchmark
REMAIND_SOURCE_PATH=/path/to/Remaind/src uv run omb providers
```

Run an official AMB slice:

```sh
cd /tmp/agent-memory-benchmark
REMAIND_SOURCE_PATH=/path/to/Remaind/src \
GEMINI_API_KEY=<your-key> \
OMB_ANSWER_LLM=gemini OMB_ANSWER_MODEL=gemini-2.5-pro \
OMB_JUDGE_LLM=gemini OMB_JUDGE_MODEL=gemini-2.5-flash \
uv run omb run --dataset personamem --split 32k --memory remaind --llm gemini --query-limit 20
```

AMB's standard `rag` mode passes Remaind the retrieval query, then asks the
configured answer LLM to choose the final option from Remaind's evidence packet.
This keeps the bridge aligned with AMB's published provider contract while still
making the retrieved Remaind context auditable.

For PersonaMem runs, Remaind's bridge can run in a scoped mode when PersonaMem
query metadata is available in the AMB checkout. Scoped mode filters candidate
memories by PersonaMem's document-level `gold_ids` before packet construction.
Those ids constrain source scope; they do not reveal the correct answer. Report
scoped AMB results as scoped, not as open-retrieval leaderboard claims.

Turn the raw AMB result into a Remaind scorecard:

```sh
remaind public-bench amb report \
  --result /tmp/agent-memory-benchmark/outputs/personamem/remaind/rag/32k.json \
  --output remaind-amb-scorecard.md
```

The report shows overall accuracy, per-category accuracy, context-token use,
retrieval latency, answering-guidance inclusion, structured-state inclusion,
failed-query diagnostics, and warnings when the run is too small or missing
grounded structured state.
Use `--format csv` for a sheet-friendly category summary or `--format json`
for automation.

Generate a failure taxonomy snapshot for a tuning baseline:

```sh
remaind public-bench amb taxonomy \
  --result /tmp/agent-memory-benchmark/outputs/personamem/remaind/rag/32k.json \
  --output reports/baselines/20260521-scoped-personamem-32k/failures_taxonomy.csv
```

Compare two runs by overall and per-category accuracy:

```sh
remaind public-bench amb diff \
  --baseline reports/baselines/20260521-scoped-personamem-32k/32k.json \
  --candidate /tmp/agent-memory-benchmark/outputs/personamem/new-run/rag/32k.json
```

Before spending answer-model quota, score the deterministic Remaind packet
picker against an existing AMB result:

```sh
remaind public-bench amb offline-score \
  --result reports/baselines/20260521-scoped-personamem-32k/32k.json \
  --output reports/baselines/20260521-scoped-personamem-32k/offline-score.md
```

This does not call Gemini or any other answer model. It reuses stored AMB
queries, gold answers, and Remaind context packets to estimate whether packet
engineering changes are likely to rescue failures or introduce new risks before
a paid run.

For the cheapest iteration loop, replay only the stored failures in the target
categories:

```sh
remaind public-bench amb offline-score \
  --result reports/baselines/20260521-scoped-personamem-32k/32k.json \
  --failures-only \
  --category suggest_new_ideas \
  --category generalizing_to_new_scenarios \
  --category recalling_the_reasons_behind_previous_updates \
  --category recalling_facts_mentioned_by_the_user \
  --output reports/baselines/20260521-scoped-personamem-32k/offline-failures.md
```

This is the no-credit replay harness for the failed set: improve deterministic
packet picks locally first, then spend Gemini quota only after offline rescues
rise and introduced risks stay controlled. The packet-level deterministic hint
remains off by default and should stay off for paid runs unless offline scoring
shows a large, stable advantage.

For paid smoke tests, use the committed replay manifest at
`docs/benchmarks/personamem-32k-smoke-manifest.json`. It contains a deterministic
42-query mix of baseline failures and passes across every PersonaMem-32k
category so tuning runs stay small and comparable before a full rerun.

For packet-level debugging, enable provider traces during an AMB run:

```sh
REMAIND_BENCH_TRACE=1 \
REMAIND_BENCH_TRACE_DIR=/absolute/path/to/trace-dir \
REMAIND_BENCH_REQUIRE_SCOPED=1 \
uv run omb run --dataset personamem --split 32k --memory remaind --llm gemini
```

Trace files include packet content, selected source ids, omitted source ids,
ranking metadata, retrieved memory ids, and timing. They deliberately exclude
environment variables, headers, credentials, and API keys; trace writes fail
closed if redaction detects a remaining secret pattern. Use
`REMAIND_BENCH_REQUIRE_SCOPED=1` for any run you intend to describe as scoped;
it fails the provider if PersonaMem metadata cannot be loaded.

Use the `gemini-2.5-pro` answer profile for benchmark-quality evidence on
ambiguous multiple-choice continuity questions. `gemini-2.5-flash` and
`gemini-2.5-flash-lite` are cheaper and faster, but local testing showed more
answer variance on suggestion-style PersonaMem questions.

AMB owns the official datasets, judge runtime, and leaderboard scoring. Remaind
owns the provider behavior: local ingest, source-linked events, memory indexing,
user scoping, and grounded retrieval responses. The generated provider stores
each AMB session as a source-linked Remaind memory, extracts structured current
and stale preference records, strips multiple-choice answer options from the
retrieval query so options do not pollute source selection, ranks candidates
inside the requested user and time scope, then returns a compact evidence packet
with durable profile context, structured preference state, source-labeled
snippets, evidence-first answering guidance, and the source sessions considered.
Benchmark packets use an 8k-token evidence budget and include a short preference
evolution brief so suggestion and preference questions retain enough source
material without forcing the answer model to infer current-vs-stale signals from
raw excerpts alone.
When a multiple-choice benchmark passes answer options into the memory query,
the packet also includes a transparent decision contract, named evidence slots,
and a candidate verification matrix. The decision contract states the question
class, decision criteria, required evidence, disqualifiers, and sub-questions.
The named slots make missing facts, preferences, constraints, history, or
exclusions visible instead of burying them in a raw context blob. The candidate
matrix scores each answer option against retrieved source evidence and flags
unsupported extras, so reviewers can see whether a wrong answer came from weak
memory retrieval, missing evidence, weak option support, or model judgment.

The current bridge deliberately stops at deterministic packet construction and
verification traces because AMB's official `rag` contract owns the final answer
LLM call. A future non-leaderboard experimental mode can add external
cross-encoder reranking and a second LLM critic/retry loop, but those would be
reported separately from standard AMB `rag` results.

The AMB bridge is intentionally wired through Remaind's shared benchmark
evidence layer instead of carrying an independent packet engine. That layer
uses the same context-engineering primitives as product continuity: normalized
context sources, authority/freshness metadata, token budgeting, and a rendered
selection trace. AMB sessions also produce structured memory records for
current and stale user preferences, so the benchmark path exercises the same
decision/preference state used by normal project continuation. This keeps
public benchmark behavior aligned with Remaind's core framework rather than
tuning a benchmark-only path.

In local 20-query PersonaMem 32k slices this reduced average injected context
from about 22.8k tokens to about 3.1k tokens; with the high-accuracy Gemini
profile above, the same slice scored 17/20. Treat that as a local proof run,
not an official AMB leaderboard score.

## Sovereign Benchmark

Run:

```sh
remaind bench sovereign
```

By default this creates an isolated workspace at:

```text
.remaind_bench/sovereign
```

The benchmark generates a large local source archive, seeds source-linked
memories, and verifies:

- a fresh Python process can recover a late final phrase from memory
- one distant contradiction is retrieved from separate source positions
- superseded memory does not resurface as current truth
- stale, keyword-heavy memories stay excluded under revocation pressure
- hostile instructions, fake tool-result claims, and phase-2 poison archive
  fixtures trip the resume gate
- adversarial review is rendered before raw evidence
- benchmark memories retain source-event links

To scale the source archive:

```sh
remaind bench sovereign --target-tokens 1000000 --force
```

The default target is one million approximate tokens. Smaller values are useful
for CI and fast local smoke tests:

```sh
remaind bench sovereign --target-tokens 10000 --force
```

The benchmark is not a claim that a smaller model performs one-shot full
attention over the whole archive. It proves the Remaind operating loop can
preserve, retrieve, validate, and quarantine the source-linked facts needed to
continue beyond the live prompt.

## Project Continuity Benchmark

Run:

```sh
remaind bench continuity --force
```

This is Remaind's product-category benchmark. It tests whether a fresh agent can
resume the correct project work after reset from grounded evidence, not whether
generic chat memory can recall facts.

The benchmark creates an isolated project, then verifies:

- forced-reset resume packet construction
- stale generated answer demotion
- active blocker recovery
- changed requirement preservation
- large local document source-linking
- rollback integrity
- next-step correctness
- scorecard and evidence-map generation

It is deterministic and model-free by design. Use it before model-facing proofs
so runtime/model failures do not hide continuity-layer regressions.

## Starter Kit 2M Model Proof

The Sovereign Memory Starter adds a terminal-visible model proof:

```sh
make proof-2m
remaind proof-2m
```

It creates a fresh 2M-token synthetic archive and runs the same configured
local model in two modes:

- raw archive directly in the prompt, with no sovereign memory
- compact Remaind resume packet, with source-linked memories and resume-gate
  findings

The expected result is that the raw 2M prompt exceeds a 262k-class model
context, a clipped no-memory prompt loses distant facts, and the sovereign
memory prompt recovers the final phrase, both checksum values, current/revoked
release codes, and adversarial warnings.

## Starter Kit Model Battle Test

The Sovereign Memory Starter also ships a smaller model compatibility harness:

```sh
make model-test MODEL_TEST_ARGS="--skip-model --force"
remaind model-test --skip-model --force
```

The deterministic layer creates an isolated Remaind context, writes a synthetic
local archive, indexes it through `remaind large-doc`, verifies source
integrity, builds a resume packet, and checks that retrieved evidence survives
into memory.

To test actual local models through the configured runtime:

```sh
remaind model-test --models qwen3.6-35b-a3b-full:latest,gpt-oss-120b-fast:latest --force
```

Or run every model currently reported by the configured runtime:

```sh
remaind model-test --installed --force
```

For DeepSeek v4 Flash split GGUF builds, start llama.cpp server first and use
the `deepseek-v4-flash` profile. The profile uses
`~/Documents/Remaind` as its native agent folder:

```sh
remaind setup --profile deepseek-v4-flash
remaind doctor --smoke
remaind model-test --force
```

The model layer asks each selected model to recover the same final phrase,
checksum pair, current release code, and revoked release code from verified
Remaind evidence. This is a compatibility proof for consuming Remaind memory;
it is not a one-shot full-context benchmark.
