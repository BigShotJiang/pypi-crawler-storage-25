# Security

Remaind is a local-first memory substrate. The repo should never contain live
credentials, hosted-project fallbacks, private local ledgers, or machine-local
operator files.

## Secret Handling

- Do not commit `.env`, `.env.local`, `.env.*.local`, `.vercel/`, service
  account JSON, private keys, or generated `.context/` runtime data.
- Run `python scripts/secret_scan.py` before release. CI runs the same current
  tree scan on every push and pull request.
- Run `python -m pip_audit -r requirements.lock` and
  `python -m pip_audit -r requirements-dev.lock` before release. CI runs the
  same locked dependency audits.
- Optional local hardening: install `gitleaks` and run
  `gitleaks detect --source . --no-git --redact --config .gitleaks.toml`
  before pushing.

## Reported Token Procedure

If a report says a live token existed in any checkout, treat it as exposed
unless proven otherwise.

1. Rotate or revoke the token in the provider dashboard.
2. Scan current files:

   ```sh
   python scripts/secret_scan.py
   rg -n "VERCEL_OIDC_TOKEN|BEGIN .*PRIVATE KEY|SUPABASE_SERVICE_ROLE_KEY" .
   ```

3. Scan git history:

   ```sh
   git log --all -p -- .env.local
   git log --all -S "VERCEL_OIDC_TOKEN" --source -- .
   git log --all -S "SUPABASE_SERVICE_ROLE_KEY" --source -- .
   ```

4. If a secret landed in history, rotate it first, then remove the blob with
   `git filter-repo` or BFG and force-push with operator approval.

## Web Environment

The marketing surface requires explicit Supabase env vars. It intentionally
does not ship production fallbacks:

```sh
cp web/.env.local.example web/.env.local
```

PostHog analytics are optional. If `NEXT_PUBLIC_POSTHOG_KEY` is blank,
analytics calls are disabled.
