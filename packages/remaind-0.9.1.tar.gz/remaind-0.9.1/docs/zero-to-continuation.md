# Zero-to-Continuation Workflow

This guide describes the intended day-one Remaind experience: start a project,
work normally, survive a terminal crash or model failure, and later ask
Remaind what the product is, where the plan stands, what just happened, and
what to do next.

The goal is not to make users manage memory files by hand. Remaind should feel
like an always-present state layer under the terminal.

## One-Time Setup

Install the shell presence hook once:

```sh
remaind daemon install-shell-hook --shell zsh
```

Open a new terminal after installation. The hook activates automatically in
folders that belong to a remembered workspace.

The hook is privacy-safe: it records command metadata, exit code, duration,
current folder, git branch, and changed-file summaries. It does not record
terminal output.

## Start a New Product

From the project folder, run:

```sh
remaind launch
```

Then describe the product in plain language when Remaind asks what you want to
do. A good first request is:

```text
We are starting PRODUCT_NAME. Create the initial product scope, development
plan, current status, and next implementation step.
```

Remaind creates or refreshes these durable anchors under `.context/active/`:

- `product_status.md` and `product_status.json`
- `plan_reconciliation.md` and `plan_reconciliation.json`
- `progress_snapshot.json`
- `presence_snapshot.json` after observed shell activity
- `run_packet.md`, `run_answer.md`, and `resume_packet.md` when questions or
  packet operations run

If the repository already has a product plan, README, status file, or handover,
Remaind treats those as higher-authority product evidence than old packet
history.

## Work Normally

Keep using the terminal and editor. When the shell hook is active, meaningful
developer commands and failed commands are captured as progress signals. That
lets Remaind update product status and map the work back to the active plan
without requiring you to stop after every command.

Use this when you want a deliberate checkpoint:

```sh
remaind launch
```

Then ask:

```text
Save the current product status, latest completed work, blockers, and next step.
```

Use `Update handover.md` from the launcher, or press `Ctrl+H` in supported
terminal selectors, when you want a compact handover for the next session.

## Continue Later

From a clean terminal, run:

```sh
remaind launch
```

When asked for a product or workspace name, type the product name. Exact folder
names are not required. Remaind searches remembered workspaces, aliases,
handover/state files, recent events, packet history, and matching child project
folders.

Then ask in plain language:

```text
I want to continue building this product. What is the current plan, latest
progress, blockers, unfinished work, and next implementation step?
```

The answer should be based on the current product plan, product status,
progress snapshot, plan reconciliation, recent presence activity, and relevant
packets. If the last activity failed, Remaind should identify:

- the blocker,
- the task that stayed incomplete,
- the next action to fix it,
- and the plan step to resume after the blocker is cleared.

If there is no blocker, Remaind should continue from the next plan-aligned
implementation step.

## Debug Stale Answers

If an answer feels wrong or stale, inspect the exact context before calling a
model:

```sh
remaind context inspect --project "PRODUCT_NAME" \
  "current plan, latest progress, blockers, and next step"
```

The inspect packet shows selected evidence, omitted evidence, freshness, and
authority labels. If the current plan or status is missing there, the issue is
context selection. If the evidence is present but the answer is wrong, the
issue is model interpretation.

## What Remaind Can and Cannot Know

Remaind can know work that is represented in at least one of these places:

- repository files such as README, plan, status, handover, specs, or tests,
- Remaind packets and answers,
- product status and plan reconciliation artifacts,
- progress snapshots,
- shell presence metadata,
- large-document/deep-compaction artifacts.

Remaind cannot perfectly know work done completely outside the repository and
outside the presence layer. For critical decisions, write them into a plan,
status, handover, source file, or ask Remaind to save a checkpoint.

## Production Expectations

A healthy continuation answer should always include plain-English versions of:

- product scope,
- current development plan focus,
- plan status and progress,
- last completed work,
- current blocker or confirmation that none is known,
- unfinished task if a blocker stopped work,
- immediate next step,
- next plan step after the blocker is fixed.

Internal plan IDs can appear only when useful as supporting references. The
primary answer should be understandable to a non-technical product owner.
