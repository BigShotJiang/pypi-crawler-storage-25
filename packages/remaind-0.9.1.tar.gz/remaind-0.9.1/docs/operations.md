# Operations

This page is the release/operator checklist for a local-first Remaind install.
It is designed to be copied into CI, cron, or a local launch script.

## Deployment Gate

Run these before publishing a wheel, starter kit, or website deployment:

```sh
python scripts/secret_scan.py
python scripts/validate_product_guardrails.py
python scripts/check_pr_scope.py origin/main...HEAD
python -m pip_audit -r requirements.lock
python -m pip_audit -r requirements-dev.lock
python -m pytest --cov=src/remaind --cov-report=term-missing --cov-fail-under=80 -q
ruff check src tests scripts starter-kits/sovereign-memory-starter
mypy
python -m build --sdist --wheel
```

For the web surface:

```sh
cd web
npm ci
npm audit --audit-level=moderate
npm run validate:events
npm run lint
npx tsc --noEmit
npm run build
```

## Monitoring Surfaces

Remaind is local-first, so monitoring is command and file based:

- `remaind validate` verifies schemas, raw-log integrity, memory index health,
  large-doc manifests, and tamper-evident event chains.
- `remaind status --json` emits current state, token band, event counts,
  malformed raw-log line count, and compaction recommendation.
- `remaind doctor --json` checks context validity, state readability, and local
  runtime detection. Add `--smoke` to run a real tiny generation check.
- `remaind monitor --json` combines validation, status, doctor readiness, and
  deep-compaction run inspection into one scheduler-friendly alert surface.
  It exits non-zero on invalid context, malformed logs, urgent compaction,
  failed/interrupted deep-compaction runs, or quarantined chunks.
- `remaind large-doc inspect <doc-id-or-path>` reports deep-compaction run
  status, progress, failed chunks, quarantines, and cache identity.
- `remaind resume` includes a compact pointer to recent deep-compaction runs
  when they exist, so a resumed agent can reuse local artifacts without
  embedding the full evidence packet in the resume payload.
- `remaind run ... --require-answer-key-pass` exits non-zero when a benchmark
  answer key is present and the model answer fails validation.

For recurring monitoring, schedule:

```sh
remaind monitor --path /path/to/project --json
```

Alert on its non-zero exit code. For model-backed environments, use
`remaind monitor --smoke` so the readiness check includes a real tiny
generation call and fails if no usable local runtime is available. Benchmark
jobs should additionally alert on non-zero exit from `remaind run ...
--require-answer-key-pass`.

## Always-Present Terminal Workflow

The shortest path is plain `remaind`. With no subcommand, Remaind opens the
interactive memory chat: type the product or workspace name, then ask in plain
language.

```sh
remaind
```

Example first prompt:

```text
termob
```

Example question:

```text
We need to continue building Termob. What is the next implementation step?
```

When a selected workspace contains a matching child project folder, Remaind
loads that project folder as the primary context for continuation questions. It
omits parent-workspace packet text and prior model-generated answer notes unless
you explicitly ask for packet history, so stale failed answers do not override
the current project plan.

Remaind can run as a lightweight local presence layer so memory feels available
without walking through the full launcher every time.
For the full start-a-project, work, crash-recover, and continue-later path, see
[zero-to-continuation.md](zero-to-continuation.md).

Start or refresh the local workspace index:

```sh
remaind daemon start
remaind daemon reindex
remaind daemon status
```

Install a shell hint for the current terminal session:

```sh
eval "$(remaind daemon shell-init --shell zsh)"
```

Or install it permanently into your shell startup file:

```sh
remaind daemon install-shell-hook --shell zsh
```

After that, when the prompt is inside a folder that belongs to a remembered
workspace, the shell prints a small presence line:

```text
Remaind memory active: Local-LLM-Test
```

The shell hook is also the privacy-safe presence layer. After each prompt, it
records command metadata for the active workspace: sanitized command preview,
exit code, rough duration, current folder, git branch, and changed-file summary.
It does not record terminal output. Meaningful developer activity and failed
developer commands update `.context/active/product_status.*` and recompute
`.context/active/plan_reconciliation.*`; every captured activity writes
`.context/active/presence_snapshot.json` and appends
`.context/logs/presence.jsonl` with fsync. That gives Remaind enough evidence
to survive terminal crashes and answer “what changed, what failed, how does it
advance the product plan, and what is next?” even when the work happened
outside an explicit `remaind run`.

You can exercise the same path manually, which is useful for shell integration
tests:

```sh
remaind daemon observe --cwd "$PWD" --command "pytest -q" --exit-code 1
```

Ask directly from the active workspace memory:

```sh
remaind ask "what is the current plan, latest progress, blockers, and next step?"
```

Inspect exactly what Remaind will load for a question without calling a model:

```sh
remaind context inspect --project termob "what is the current plan, latest progress, blockers, and next step?"
```

The inspect packet includes the detected intent, source authority order,
selected evidence, and any omitted evidence. Use it when an answer feels stale:
it shows whether the model saw the current product plan, progress snapshot,
plan reconciliation, presence activity, resume packet, and packet history that
the question required.
For large-document tasks, `remaind run FILE "TASK" --no-model` provides the
same packet-only inspection path for the run evidence packet; resume packets
and compaction prompts also include the context-engine trace automatically.

Or stay inside Remaind until you press Enter on a blank question:

```sh
remaind chat
```

`remaind ask` and `remaind chat` are thin entry points over the same
`remaind launch` packet pipeline. They still build the resume/run packets,
carry continuation evidence, use the selected runtime, and write
`.context/active/run_packet.md` plus `.context/active/run_answer.md`.
The moment a workspace is activated, launch also creates
`.context/active/product_status.md`, `.context/active/product_status.json`, and
`.context/logs/product_status.jsonl` if they do not exist yet. That first seed
does not claim implementation progress; it records that memory is active, no
blocker is known, Remaind is ready for instructions, and future operations will
update the product state atomically.
Launch also creates or refreshes `.context/active/plan_reconciliation.md`,
`.context/active/plan_reconciliation.json`, and
`.context/logs/plan_reconciliation.jsonl`. The reconciliation artifact parses
loaded product authority files, removes internal plan IDs from user-facing next
steps, and maps progress or presence activity onto plan items without claiming
completion unless the source plan/status says the item is complete.
Each operation also writes a crash-safe progress checkpoint at
`.context/active/progress_snapshot.json` and an append-only journal at
`.context/logs/progress.jsonl`. Those records are flushed to disk at start,
packet-ready, model-call-started, and final completed/blocked states. If the
terminal disappears or the model times out, the next memory question can still
see the active task, latest blocker, incomplete task, last completed tasks,
saved packet, answer note, and recovery step.

Workspace lookup is content-aware. `remaind launch --project NAME`,
`remaind ask --project NAME ...`, and the daemon index search folder names,
child project folder names, local aliases, `active/handover.md`,
`active/state.json`, recent events, `resume_packet.md`, and recent
`run_packet.md` / `run_answer.md` history. That means an older project can
still be found when the product name appears only in prior packets or when the
workspace memory lives at a monorepo parent folder. For matching child project
folders, memory questions include README/plan/status docs from that child so
the model can reconstruct the product plan instead of only seeing the parent
workspace state. Continuation questions also prioritize packet artifacts that
match the user's product/query terms before newer unrelated packet noise.

## Remaind Memory Modes

`remaind launch` defaults to a model-agnostic Turbo memory mode. This is a
Remaind packet-shaping choice, not a DeepSeek runtime profile, so it works the
same way for Ollama models, OpenAI-compatible local servers, API-backed models,
YOLO launches, and packet-only fallback.

Available modes:

- `turbo` (default): fastest daily workflow. Includes 1 memory, 3 raw excerpts,
  caps generated answers at 1024 tokens for local transports, and uses a 12k
  run-packet cap unless `--token-cap` is explicitly supplied.
- `standard`: balanced workflow. Includes 5 memories, 20 raw excerpts, and a
  4096 output-token cap while keeping the normal context-window packet policy.
- `deep`: fullest memory workflow. Includes 8 memories, 30 raw excerpts, and an
  8192 output-token cap while keeping the normal context-window packet policy.

Use:

```sh
remaind launch                         # turbo
remaind launch --memory-mode standard
remaind launch --memory-mode deep
REMAIND_MEMORY_MODE=deep remaind launch
```

DeepSeek Stable/Turbo/Nitro remains a separate server-speed choice. Remaind
memory mode controls how much memory and evidence Remaind sends to whichever
model was selected.

## Deep-Compaction Tuning

`remaind run ... --deep-compact` defaults to an `8000` token source-chunk
target, capped by a conservative fraction of the selected model context. Use
`--deep-compact-chunk-tokens N` or `REMAIND_DEEP_COMPACT_CHUNK_TOKENS=N` when a
local runtime needs different checkpoint behavior.

Lower the value for slower models, smaller context windows, or timeout-prone
llama.cpp / OpenAI-compatible servers. Raise it only for stable long-context
runtimes where fewer, larger extraction calls are worth the latency. The chunk
target is part of the deep-compaction cache key, so changing it intentionally
creates a fresh run.

Deep-compaction extraction and reduction use bounded structured-output budgets
internally (`2048` tokens for chunk extraction, `4096` for group/global
reduction). These caps keep operator-level answer settings such as
`REMAIND_OPENAI_MAX_TOKENS` from turning each chunk extraction into an
unbounded long-generation request. The environment override still applies to
the final answer call when Remaind has assembled the packet.

Per-chunk progress events are written at `importance=0` with the tag
`deep_compact_progress` so resume-packet raw excerpts (which include
`importance>=2`) are not polluted. Set `REMAIND_DEEP_COMPACT_DEBUG=1` to
upgrade the cadence to one event per chunk; the default is one event every
N chunks plus a final summary, scaled to the chunk count. Use the debug
cadence when diagnosing per-chunk failures or quarantine patterns; leave
it off in production to avoid event-log bloat on long runs.

### 1M+ Local-Model Acceptance Proof

The real 1M+-token DeepSeek proof is a hardware acceptance test, not a default
CI job. It requires a local model that can complete every extraction chunk,
the final answer call, and the answer-key check within the operator's timeout
budget.

Run the executable proof with:

```sh
REMAIND_INTEGRATION_REAL_MODEL_1M=1 \
REMAIND_OPENAI_BASE_URL=http://127.0.0.1:11442/v1 \
REMAIND_OPENAI_MODEL=deepseek-v4-flash \
REMAIND_OPENAI_API=chat \
REMAIND_OPENAI_API_KEY="$(cat /path/to/local-api-key.txt)" \
REMAIND_OPENAI_NUM_CTX=131072 \
REMAIND_LOCAL_MODEL_TIMEOUT=3600 \
REMAIND_INTEGRATION_COMMAND_TIMEOUT_S=14400 \
REMAIND_INTEGRATION_1M_CHUNK_TOKENS=8000 \
python -m pytest -q tests/test_deep_compaction_integration.py::test_deep_compact_real_model_1m_answer_key -m "slow and integration"
```

If the local runtime shows GPU/Metal out-of-memory or stalls in `llama.cpp`
slot status, lower the server context window and `REMAIND_INTEGRATION_1M_CHUNK_TOKENS`
before rerunning. A passing run must report the answer-key check as passed;
a smoke proof on a small document does not satisfy the 1M+ acceptance
criterion.

## Deep-Compaction Operator Assumptions

The `--deep-compact` pipeline carries several load-bearing assumptions that
operators should know before depending on its answer for downstream work.

- **Local model JSON-mode support.** Extraction and reduction prompts request
  structured JSON output. Ollama and OpenAI-compatible runtimes that do not
  honor JSON mode fall through Remaind's JSON-recovery heuristics, but
  consistent failures land in `failures.jsonl` and shrink the evidence
  surface. New deep-compaction runs perform a tiny generation preflight before
  chunk work starts, and operators should still run `remaind doctor --smoke`
  before scheduled runs so runtime load failures are caught outside the job.
- **Model identity stability.** The cache key includes `model_name` as
  reported by the runtime. Ollama unpinned tags (e.g. `qwen3:latest`) can
  swap the underlying weights when the model file is updated; the cache key
  will match but the model is different. Pin tags explicitly via
  `REMAIND_OLLAMA_MODEL` for reproducible cached runs.
- **The Ollama auto-pick may pick an unloadable model.** Without
  `REMAIND_OLLAMA_MODEL`, Remaind picks the first model reported by
  `ollama list`. If that model fails to load (GGUF corruption, GPU OOM,
  partial-download blob), the deep-compaction preflight will catch it and
  fail the run cleanly — but the preflight error is not visible until an
  operator runs `remaind run --deep-compact` against it. Run
  `remaind doctor --smoke` first to confirm the auto-picked model loads,
  and pin a known-working model with `REMAIND_OLLAMA_MODEL` for any
  scheduled work.
- **Single-chunk documents skip the LLM reducer entirely.** For documents
  that fit in one chunk, the reducer's mechanical merge path takes over and
  emits `support_type` values directly. This is correct behavior, but
  small-doc results do not exercise the same code path as large-doc runs.
- **Failed and quarantined chunks reduce evidence silently.** Unrecovered
  chunks fall back to mechanical retrieval for their line ranges; the
  answering model still receives a packet but it is missing structured
  evidence for those ranges. Inspect `failures.jsonl` and `quarantined.jsonl`
  under the run directory before trusting the answer on adversarial or
  partial corpora. `remaind monitor` exits non-zero when these are present.
- **Per-chunk timeout.** `REMAIND_LOCAL_MODEL_TIMEOUT` (default 120s) caps
  each model call. For slow CPU-only runtimes or unusually long chunks,
  raise this. The setting is independent of the cache key, so changing it
  does not invalidate prior runs.
- **Concurrent runs against the same document are not coordinated.** Two
  shells running `remaind run FILE TASK --deep-compact --reuse-deep-compact`
  simultaneously will each create separate runs with distinct ULID
  `run_id`s when neither sees the other's manifest yet. Both runs complete
  correctly; the cache simply contains duplicate work. Coordinate manually,
  or wait for the first run's manifest to land before starting the second.
- **Windows locking is CI-certified for concurrent event appends.** The event
  writer uses `fcntl` locking on Unix and an `msvcrt` byte-range lock fallback
  on Windows. CI runs the concurrent hash-chain append proof on
  `windows-latest` so Windows support is not limited to monkeypatched Unix
  coverage.

## DeepSeek Stable / Turbo / Nitro Profiles

On MOSAI local-DeepSeek installs, `remaind launch` detects the profile switcher
at `~/sovereign-local-ai/scripts/switch_deepseek_profile.sh` and shows a
`DeepSeek mode` selector before model selection:

- `Stable - larger, 131k context` restores the wider `ctx=131072` profile,
  conservative batching, larger resume/file packets, and max DeepSeek Code
  reasoning.
- `Turbo - faster, 65k context` sets the supervised llama-server profile to
  `ctx=65536`, larger batch/ubatch values, flash attention on, smaller Remaind
  packets, and low DeepSeek Code reasoning.
- `Nitro - fastest, 65k context, experimental` keeps the Turbo packet/context
  shape and starts llama.cpp with `--spec-type ngram-simple` for n-gram
  speculative decoding. Nitro is optional: if server startup, `/v1/models`, or
  a small completion smoke fails, the profile switcher rolls back to Turbo and
  reports the failure. Remaind only shows Nitro when the installed switcher
  advertises Nitro support. When the switcher supports memory cleanup, launch
  asks `Free memory before starting DeepSeek?` before Nitro starts; answering
  yes explicitly pauses resident Ollama models plus known local image/video
  services so DeepSeek has more unified memory headroom.

Advanced Nitro experiments are exposed on the switcher, not hidden in
Remaind. Operators can A/B test latency tuning with
`switch_deepseek_profile.sh nitro --poll N --poll-batch 0|1 --threads N
--threads-batch N`. Apple GPU wired-memory changes are opt-in only through
`--wired-limit-mb N`; this requires an elevated shell and should be used only
when large-context runs are stalling or hitting memory pressure.

The switcher restarts the launchd-managed DeepSeek server, updates the
Remaind environment, and launch then runs the normal readiness smoke before
accepting a question, file, paste, resume, or empty session. Operators can set
`REMAIND_DEEPSEEK_PROFILE_SWITCHER` to a custom switcher path or
`REMAIND_DEEPSEEK_PROFILE_PICKER=0` to hide the picker.

## Local OpenAI-Compatible Authentication

When Remaind talks to a local OpenAI-compatible server (vLLM, llama.cpp, an
internal proxy) that requires an `Authorization: Bearer …` header, supply the
token via the `REMAIND_OPENAI_API_KEY` environment variable. The token is sent
on every model-discovery probe and every generation request through the
shared transport layer.

For interactive use, `remaind launch` can collect the endpoint and optional
token through `Connect API model (OpenAI-compatible)`. That token is held only
inside the current launcher process and forwarded to readiness checks plus any
run started from that launch. It is not written into `.context/`, run packets,
resume packets, or event logs.

Security guidance:

- **Treat the env var as a secret.** Source it from a vault, a `direnv` file
  outside the repo, or a CI-managed secret store; never commit it. The
  bundled `scripts/secret_scan.py` rejects any `REMAIND_OPENAI_API_KEY=…`
  (or `OPENAI_API_KEY=…`) assignment in the tree that does not look like a
  placeholder (`your-…`, `<…>`, `$…`, `placeholder`, `example`,
  `local-…-token`).
- **The token never appears in `remaind` stdout or stderr.** `remaind doctor`
  has been smoke-tested with a planted token; the value does not surface
  in the human-readable or JSON output.
- **Local-server response bodies can echo headers.** Remaind surfaces the
  remote server's response body in error messages so misconfigurations are
  debuggable. A non-standard local server that echoes the `Authorization`
  header in its 4xx/5xx body would leak the token into `run_answer.md` and
  the event log. Confirm your local server does not echo headers before
  enabling auth in shared/CI environments.

## `remaind run` Exit-Code Semantics

`remaind run` is suitable for cron/CI gating without extra flags:

- **Exit 0**: a clean completion. The packet was written, the answering model
  responded, and (when `--require-answer-key-pass` is set) the answer-key
  check passed.
- **Exit 1**: a recoverable failure. The packet is still preserved on disk so
  the evidence remains useful for manual inspection, but the model call did
  not produce an answer. This covers deep-compaction preflight failure,
  deep-compaction transport failure, answer-model timeout, and answer-model
  HTTP errors. The reason is surfaced in `run_answer.md` and the
  `model_error` field of the JSON output.
- **Exit 2**: with `--require-answer-key-pass`, no answer key was found, or
  the answer-key validation failed. The packet may still be present; this
  exit code separates "answer wrong" from "model unreachable" so callers can
  distinguish them.

Scheduled jobs that need to alert on model-call failure get the right signal
out of the box: any non-zero exit is actionable. Add
`--require-answer-key-pass` only when the additional answer-key gate is
desired on top of the default model-error signal.

## Rollback

Use rollback when a derived file is wrong or unsafe:

```sh
remaind rollback --to 2026-05-14T03:54:33Z
```

Rollback restores validated point-in-time snapshots of `state.json`,
`HANDOVER.md`, and `resume_packet.md`. It never rewrites `events.jsonl`; it
appends a high-importance rollback event with the restored snapshot names, so
the audit trail remains intact. The pre-rollback active files are also
snapshotted, making rollback reversible.
