# Sovereign Memory Starter Kit

The starter kit is the product packaging layer for Remaind. Remaind remains the
durable context ledger; the starter kit turns that ledger into a complete local
agent setup with installer scripts, model profiles, agent adapters, and a
continuity proof.

Source:

```text
starter-kits/sovereign-memory-starter/
```

## Product Positioning

```text
Sovereign Memory: 100% local memory for AI agents working beyond one context window.
```

The kit is designed for users who want memory they can carry between machines
or local agent shells without a hosted memory service. It helps local models
continue work that is larger than their live context window by refreshing a
validated resume packet before each new session.

## What It Includes

- local installer
- one-command bootstrap/setup and readiness checks
- Remaind bootstrap
- optional managed local Python bootstrap through checksum-verified `uv`
- startup prompt generator
- generated local connector prompt
- model profiles
- Qwen Code adapter
- built-in console adapter
- synthetic continuity proof
- adversarial memory and compaction-output proof
- beyond-context benchmark proof
- terminal-visible 2M-token model A/B proof
- memory-first startup with `remaind launch`
- direct huge-prompt terminal execution with `remaind run FILE "TASK"`
- universal Remaind memory modes (`turbo`, `standard`, `deep`) for shaping
  packets consistently across any selected model
- model battle-test harness for comparing configured or installed local models
- documentation and unit tests

## Supported Today

Executable runtime:

```text
ollama
llama-server / OpenAI-compatible local endpoint
```

Executable agents:

```text
qwen-code
console
```

Model profiles:

```text
qwen-large
qwen-small
deepseek
deepseek-v4-flash
glm
minimax
llama
custom
```

Ollama model calls use `SOVEREIGN_OLLAMA_API=auto` by default. That keeps Qwen
on the chat path when available and falls back to the completion/generate path
for completion-only GGUF builds. Split GGUF builds such as DeepSeek v4 Flash
should run through llama.cpp server with `SOVEREIGN_OPENAI_BASE_URL` pointing
at its `/v1` endpoint.

Profile-native agent folders:

```text
Qwen profiles:     ~/Documents/Qwen-Code
DeepSeek profiles: ~/Documents/Remaind
```

The operator can override the folder with `--agent-workdir`, but the built-in
DeepSeek profiles now make `~/Documents/Remaind` the default launch surface.
The installer preserves unmanaged files in that folder and writes sovereign
bridge sidecars when needed.

The runtime and agent layers are explicit extension points for LM Studio,
vLLM, Aider, Continue, and custom CLIs.

The installed starter command is `remaind`. The older `sovereign` command is
kept as a compatibility alias. Raw ledger commands remain available through
`remaind core ...` when an operator needs the underlying package CLI directly.

For a guided memory-first start, users can run:

```bash
remaind launch
remaind launch --path ./my-project --input file --file /absolute/path/to/huge-prompt.md
cat /absolute/path/to/huge-prompt.md | remaind launch --path ./my-project --input paste --task "solve this task"
```

`remaind launch` validates `.context/`, checks the configured local runtime,
and only then accepts paste/file input. Paste mode captures text locally before
dispatching through the large-prompt packet flow.

For a direct one-shot huge local prompt/report, users can run:

```bash
remaind run /absolute/path/to/huge-prompt.md "solve this task"
```

That keeps the file local, builds a compact evidence packet, calls the
configured local model, and writes the packet/answer under `.context/active/`.

## Build The Zip

From the repo root:

```sh
scripts/build-sovereign-memory-starter.sh
```

The release archive is written to:

```text
dist/sovereign-memory-starter-v<pyproject-version>.zip
```

To write release archives somewhere else:

```sh
SOVEREIGN_STARTER_DIST=starter-dist scripts/build-sovereign-memory-starter.sh
```

The GitHub release workflow uploads this zip as a release asset so users can
download the starter kit without cloning the repository.

When `dist/remaind-<version>-py3-none-any.whl` exists, the builder includes it
under `wheels/` so the starter installs the exact package from the same release.
Source checkouts without a local wheel fall back to the pinned package in
`requirements.txt`.

The build excludes installed memory state, virtual environments, generated
bootstrap tools, proof/benchmark artifacts, 2M proof artifacts, `.env`,
pycache files, and OS metadata.

The installer leaves `MASTER_INITIAL_PROMPT.md` as the shareable template and
writes machine-specific paths to `MASTER_INITIAL_PROMPT.local.md`.

## Bootstrap Path

For users who may not have Python 3.11+ installed:

```sh
./bootstrap.sh --profile qwen-large --agent qwen-code
```

The bootstrap script first looks for an existing Python 3.11+ executable. If
none is available, it downloads a pinned `uv` release archive, checks the
archive against the release SHA-256 file, installs `uv` under `.bootstrap/`,
uses it to install a managed local Python, and then runs `install.sh`.

It does not use `sudo` and does not install Python globally. Use
`./bootstrap.sh --no-download` to require an already-installed Python.

## Privacy Rule

Share the starter kit source or release zip. Do not share a user's installed
`.context/` folder unless the user intentionally wants to share memory history.
