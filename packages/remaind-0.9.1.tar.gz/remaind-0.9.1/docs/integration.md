# Integrating Remaind into your agent

This guide shows how to wire Remaind into an agent harness. It uses only the
public API — `import remaind` — and every code block runs against the real
surface.

If you only want the CLI, see the [README](../README.md). This guide is for
operators integrating Remaind **programmatically** into a long-running agent.

---

## 1. Mental model

Remaind is a **substrate, not a framework.** It does not run your agent, call
your model, or manage your context window. It is the durable memory your
agent loop reads from and writes to. You own the loop; Remaind owns the
`.context/` directory.

```
   init ──▶ log events ──▶ track the budget ──▶ compact ──▶ resume into a
              ▲                                              fresh context
              │                                                  │
              └──────────────────────────────────────────────────┘
```

Three sources of truth live in `.context/`, with a strict authority order
(lower wins when they disagree):

1. Latest explicit user instruction
2. `logs/events.jsonl` — the append-only raw timeline
3. `active/state.json` — derived working state
4. `active/handover.md` — the compact continuity document
5. Derived memories

A stale summary can never override a newer user instruction. The full
contract is in `.context/CONTRACT.md` after you run `init`.

---

## 2. Install

```sh
python3 -m pip install --upgrade remaind
```

Requires Python 3.11+. Two runtime dependencies, no optional extras. Remaind's
memory/state artifacts are local-first. Model-backed answers and compaction can
use a local runtime or an OpenAI-compatible API endpoint over HTTP using only
the Python standard library. API keys are only needed when the endpoint you
choose requires one.

---

## 3. The public API

`import remaind` is the entire stable surface. Everything in
`remaind.__all__` is stable; the underscore-prefixed modules
(`remaind._events`, …) are internal and may change — do not import from them.
Advanced custom handover compactors should import low-level protocol primitives
from `remaind.compactor_protocol`; the same names remain at the package root
only as compatibility re-exports.

```python
import remaind

remaind.__all__   # the full public surface
remaind.__version__
```

---

## 4. Initialize — once per project

```python
import remaind

base = "./my-agent-run"          # the directory that will contain .context/
remaind.init(base)               # creates base/.context/  (raises InitError if it exists)
```

Every event you log needs a `session_id` and a `task_id`. They are generated
by `init` and live in the state — read them once and hold them for the run:

```python
state = remaind.status(base)
session_id = state["session_id"]
task_id = state["task_id"]
```

---

## 5. Log events as the agent works

This is the continuous part of the loop. Open one `EventWriter` for the run
and append an event for every meaningful thing that happens.

```python
writer = remaind.EventWriter.open(base)

writer.append(remaind.EventInput(
    type="user_message",
    actor="user",
    summary="Asked to refactor the auth module",   # short — for handovers & search
    session_id=session_id,
    task_id=task_id,
    content="Please refactor src/auth/ to use the new token format...",
    importance=3,                                  # a critical user instruction
))
```

**Event types** (`type=`): `user_message`, `assistant_message`, `tool_call`,
`tool_result`, `command_output`, `file_change`, `decision`, `error`,
`compaction`, `validation`, `resume`, `rollback`, `init`.

**Importance** drives what compaction must preserve — tag it honestly:

| importance | meaning | examples |
|---|---|---|
| `0` | trace / debug | verbose logs you will rarely need again |
| `1` | normal useful event | routine tool calls, assistant turns |
| `2` | decision, correction, constraint, file change, blocker, meaningful result | a design decision, a test passing, a file written, a blocker hit |
| `3` | explicit remember instruction, active next step, active blocker, critical user instruction | "always use X", the current next step, a hard blocker |

Compaction **must** keep every `importance >= 2` event in the summary chain;
`importance == 3` items must be explicitly represented in state or handover.
Get this wrong and either the handover bloats (everything tagged 3) or
load-bearing context is lost (everything tagged 1).

Three things happen automatically on every `append`:

- **Redaction.** Secrets (API keys, JWTs, AWS credentials, bearer tokens, …)
  are replaced with deterministic hashes *before* the event touches disk.
  You never have to scrub `content` yourself.
- **Tamper evidence.** New events carry hash-chain metadata. `remaind
  validate` recomputes the chain and reports when a chained event edit,
  deletion, or reorder breaks continuity.
- **Large-output routing.** `content` over the byte threshold (or any truly
  binary `bytes` payload) is written to `.context/artifacts/` and the event
  stores head/tail excerpts + a SHA-256 + the artifact path — the raw log
  stays small.

If a `bytes` payload decodes cleanly as high-confidence UTF-8 text, Remaind
decodes it first and applies the same redaction path as `str` content. Still,
pass text as `str` when you can; pass `bytes` for genuinely opaque binary
artifacts. Opaque binary artifacts are stored by content hash and are not
redacted because Remaind cannot safely interpret arbitrary binary formats.

A typical turn:

```python
def log(type_, actor, summary, *, content=None, importance=1):
    writer.append(remaind.EventInput(
        type=type_, actor=actor, summary=summary,
        session_id=session_id, task_id=task_id,
        content=content, importance=importance,
    ))

log("assistant_message", "assistant", "Proposed the refactor plan", content=reply)
log("tool_call", "tool:bash", "ran the test suite", content="pytest -q")
log("tool_result", "tool:bash", "all tests pass", content=test_output, importance=2)
log("decision", "assistant", "chose token format v2", content=rationale, importance=2)
```

You can also keep the derived files current as work progresses:

```python
remaind.update_state(base, lambda st: {
    **st,
    "next_step": "wire the new token format into the middleware",
    "decisions": st["decisions"] + ["token format v2"],   # lists are append-only
})
```

`update_state` validates the result against the state schema, recomputes the
threshold band, and writes atomically with a history snapshot. A
schema-invalid mutation raises `StateValidationError` and leaves
`state.json` untouched.

---

## 5.1. Register large local documents

Some agent shells expose a file-reader tool with a size cap. A terminal
process can still stream the file. `remaind large-doc` makes that a first-class
Remaind flow instead of a one-off helper script.

CLI:

```sh
remaind large-doc ingest /absolute/path/to/huge.md --path ./my-agent-run
remaind large-doc search /absolute/path/to/huge.md "exact phrase" --path ./my-agent-run --verify --json
remaind large-doc slice /absolute/path/to/huge.md --start 33557 --end 33565 --path ./my-agent-run --verify --json
remaind launch --path ./my-agent-run
cat /absolute/path/to/huge.md | remaind launch --path ./my-agent-run --input paste --task "solve this task"
remaind run /absolute/path/to/huge.md "solve this task" --path ./my-agent-run
```

Public API:

```python
result = remaind.ingest_large_document(base, "/absolute/path/to/huge.md")
hits = remaind.search_large_document(
    "/absolute/path/to/huge.md",
    "exact phrase",
    context=2,
    max_results=12,
    base=base,
    verify=True,
)
evidence = remaind.slice_large_document(
    "/absolute/path/to/huge.md",
    start=33557,
    end=33565,
    base=base,
    verify=True,
)
answer = remaind.run_prompt(
    base,
    "/absolute/path/to/huge.md",
    "solve this task",
)
```

`ingest_large_document` does not copy the source file into `.context/`. It
stores a local manifest under `.context/large-docs/`, appends a source-linked
event, and creates a searchable memory pointer containing exact future
commands. `search_large_document` and `slice_large_document` stream the source
file from disk and return line-numbered evidence.

This is the right path for files that exceed an agent UI's direct file-reader
limit or a model's live prompt. It is not one-shot full-context attention over
the whole file; it is source-linked retrieval, then normal reasoning over the
retrieved evidence.

`remaind run FILE "TASK"` is the high-level terminal path. It initializes
`.context/` when needed, ingests the file, includes document head/tail
orientation, asks the configured local model for retrieval queries when a model
is available, searches/slices verified evidence, writes
`.context/active/run_packet.md`, calls the same local model with that compact
packet, writes `.context/active/run_answer.md`, and logs the task/result back
to the append-only event log. Use `--no-model` when you only want the packet.

For 1M-4M token source files, use:

```sh
remaind run /absolute/path/to/huge.md "solve this task" --deep-compact
remaind run /absolute/path/to/huge.md "solve this task" --deep-compact --deep-compact-mode strict
remaind run /absolute/path/to/huge.md "solve this task" --deep-compact --reuse-deep-compact
remaind run /absolute/path/to/huge.md "solve this task" --deep-compact --deep-compact-chunk-tokens 2000
```

Deep compaction is local-first. Remaind chunks the file by line range, calls the
selected local model for structured per-chunk extraction, validates JSON schema,
source-line bounds, and verbatim quotes, scans derived text for adversarial
instructions, redacts derived summaries, writes resumable artifacts under
`.context/large-docs/<doc_id>/deep-compactions/<run_id>/`, reduces the evidence,
and injects exact raw source lines for answer-affecting claims into
`run_packet.md`.

`lenient` mode keeps going when individual chunks fail and surfaces failures in
stdout and the packet; those runs report `partial` rather than pretending the
deep pass was clean. `strict` fails the run on any unrecovered chunk. In both
modes Remaind writes a baseline packet before deep compaction begins, so a slow
or interrupted local model does not leave the operator with zero usable packet.
For slower local runtimes, lower `--deep-compact-chunk-tokens` or set
`REMAIND_DEEP_COMPACT_CHUNK_TOKENS`. The default target is `8000` tokens per
source chunk, capped by a conservative fraction of the selected model context.
Lower it when a local model times out or has a small context window; raise it
only for stable long-context runtimes where fewer, larger extraction calls are
worth the latency. The chunk target is included in the cache key.

Inspect and clean deep-compaction runs with:

```sh
remaind large-doc inspect /absolute/path/to/huge.md
remaind large-doc inspect <doc_id>
remaind large-doc prune-deep-compactions --doc <doc_id-or-path> --keep-latest 2
```

`remaind launch` is the memory-state front door. It resolves a workspace,
creates or loads `.context/`, validates the memory state, selects a local
runtime/model, runs a tiny readiness prompt, and only then routes into ask,
paste, file, resume, or empty-session mode. Ask mode builds the current memory
packet and runs a question against it, so the user experience stays “ask from
this terminal state” instead of “go talk to a Remaind folder.” In human output,
ask mode prints the model answer directly and hides packet paths; the packet and
answer files are still written under `.context/active/` for audit, recovery, and
JSON callers. Ask packets include the current launch readiness state as fresh
evidence, so older model/runtime failures in the memory packet are treated as
historical unless the current readiness check still reports them. The
interactive ask loop also carries the current terminal conversation forward on
follow-up questions, so user corrections made during the same launch are newer
than contradictory packet text. When a question asks for recent packets or
packet history, launch adds the latest run packets and answer notes to the
question source before dispatching through the normal `remaind run` packet flow.
Before dispatch, the context engineering layer classifies the user's intent,
normalizes each possible source with authority and freshness labels, applies a
budget based on the selected model context window, and renders a trace of what
was selected or omitted. You can inspect that model-facing source without a
model call with `remaind context inspect --project NAME "QUESTION"`. The same
engine also wraps `remaind run` retrieval-planner prompts and evidence packets,
generated resume packets, local handover compaction prompts, and deep-document
compaction extraction/reduction prompts, so every model-facing context path
exposes its source authority and budgeting decision. Every memory question includes a packet/answer inventory
for the selected workspace, plus recent packet context. If the user asks for
all packets or full history, launch loads every packet and answer note that
fits the fixed question-source budget and lists omitted files instead of
silently overflowing the model context. Continuation requests such as `continue working`,
`what is the next step?`, `latest progress`, or `project status` are treated as
project-brief requests: launch loads the resume packet plus budgeted packet
library context and the durable product-plan reconciliation artifact, then
instructs the model to reconstruct product scope, active plan, latest progress,
current blockers, next TODOs, and the immediate implementation step before
answering. The reconciliation artifact is refreshed at launch and after
progress/presence updates, so saved activity is mapped back to the plan before
old packets or old generated answers are considered.

Recommendation requests also pass through Remaind's universal recommendation
engine before the model answers. The engine is shared by `remaind launch`,
`remaind ask`, `remaind run`, and product-plan reconciliation. It names the
selected action, confidence, decision criteria, active constraints, evidence,
candidate scores, conflicts, and warnings, then renders that decision into the
model-facing packet. This makes open-ended questions such as `what should we do
next?` use the same constraint-aware judgment Remaind applies during benchmark
and plan-reconciliation work, instead of leaving each surface to invent its own
recommendation logic.
Paste mode also retries once when a local endpoint disconnects during the first
answer call; for DeepSeek profile-switcher installs, launch can restart the
current profile before retrying. If DeepSeek reports a GPU-memory compute
error, interactive launch can ask to free memory and retry instead of returning
the raw server failure. Explicit OpenAI-compatible runs stay pinned to the
selected endpoint/model during that retry instead of falling through to Ollama
while the endpoint is loading. Paste mode accepts stdin or an interactive paste
capture and writes it to `.context/artifacts/launch-pastes/` before dispatching
through the same `remaind run` packet flow.

Interactive launch asks for a product or workspace name before showing the
manual folder picker. The lookup builds a deeper workspace-memory index and
searches existing `.context` workspaces by folder name, path topics,
`active/handover.md`, `active/state.json`, and recent event summaries, so a
user can type `Rutwais` even when the actual folder is a dated session path. It
also tolerates hyphenated names, close spellings, and related topic phrases, so
queries like `merchant refunds` can find a memory whose handover talks about a
Stripe refund dashboard. One clear match activates automatically. Ambiguous
matches are shown as selectable full paths. If the typed name has no match and
the user chooses a folder from the picker, launch stores that typed phrase as a
local workspace alias so future launches can activate the memory directly.
Non-interactive callers can use:

```sh
remaind launch --project "Rutwais" --input ask --task "latest progress and next TODOs?"
```

Launch uses Remaind Turbo memory mode by default for every model. Turbo is
provider-agnostic packet shaping: 1 memory, 3 raw excerpts, a 1024 answer-token
cap for local transports, and a 12k run-packet cap. It is separate from
DeepSeek Stable/Turbo/Nitro runtime profiles. Use
`remaind launch --memory-mode standard` for balanced packets or
`remaind launch --memory-mode deep` / `REMAIND_MEMORY_MODE=deep` when a fuller
memory packet matters more than startup speed.

When run interactively, `remaind launch` uses arrow-key terminal pickers:

- Before the workspace picker, launch accepts a product/workspace name, builds a
  workspace-memory index, and activates the matching memory state automatically
  when there is one clear match. Leave it blank to browse. The workspace picker
  lists full paths for the current directory and discovered nearby folders that
  already contain `.context/`.
- After readiness, launch accepts plain-language intent before showing the
  continuation menu. A sentence such as `what is the next step?` or
  `latest progress and TODOs` starts memory chat directly. Phrases such as
  `prepare memory packet`, `update handover`, `paste`, `file`, or an existing
  document path route to the matching workflow. Press Enter to use the
  arrow-key picker instead.
- The model picker lists detected local Ollama/OpenAI-compatible models before
  readiness runs. If the selected model fails its smoke test, launch offers the
  remaining detected models before packet-only fallback. Launch smoke tests use
  `REMAIND_LAUNCH_MODEL_TIMEOUT` (default `20` seconds), capped separately from
  longer answer/deep-compaction calls. Known local DeepSeek models use friendly
  labels such as `DeepSeek V4 Flash` while keeping the raw model id visible in
  the option details.
- MOSAI/DeepSeek installs that expose
  `~/sovereign-local-ai/scripts/switch_deepseek_profile.sh` get a `DeepSeek
  mode` picker before model selection. `Stable - larger, 131k context` uses
  the widest profile, `Turbo - faster, 65k context` switches the supervised
  llama-server profile to lower latency packets, and `Nitro - fastest, 65k
  context, experimental` keeps Turbo's packet shape while enabling llama.cpp
  n-gram speculative decoding. Set `REMAIND_DEEPSEEK_PROFILE_SWITCHER` to point
  at a different switcher, or set `REMAIND_DEEPSEEK_PROFILE_PICKER=0` to hide
  the picker. When the switcher supports memory cleanup, launch asks
  `Free memory before starting DeepSeek?` for every profile, including keeping
  the current mode, so competing local model servers are paused only with
  explicit operator consent.
- Users without a local model can choose
  `Connect API model (OpenAI-compatible)` from the same picker. Launch asks for
  the API service's `/v1` endpoint, accepts an optional bearer token for the
  current process only, discovers available models from `/models`, and then runs
  the normal readiness check. The token is not persisted to `.context/`.
- Advanced operators can choose the YOLO variant of any detected model from the
  same picker, for example `DeepSeek V4 Flash (deepseek-v4-flash; ...)` or its
  `YOLO / skips model test` variant, or pass
  `--yolo-model --model MODEL` in scripts. The picker stays model-name first
  and hides provider endpoints. `Model not listed` is only for unusual cases
  where a local model exists but discovery cannot see it. YOLO mode is
  intentionally explicit: it skips only the model smoke test, labels the model
  as unverified, and still runs memory, schema, disk, packet-policy, and
  context checks before the workflow continues.
- File mode lists registered large documents first, then nearby
  Markdown/text/JSON-style files.
- The continuation picker lets operators move between asking from memory state,
  paste, file, resume, and `Update handover.md` workflows without remembering
  command flags. `Ctrl+H` activates the handover update action in terminal
  selectors; because some terminals treat `Ctrl+H` as Backspace, the visible
  menu row remains the reliable fallback. The no-question/empty path is
  intentionally hidden from the
  interactive menu so users do not type natural-language questions into their
  shell after memory-state setup returns; scripts can still request it with
  `--input empty`. Resume mode prepares `.context/active/resume_packet.md` and,
  in interactive terminals, offers to answer a question from that packet before
  returning to the shell.
- Operators use Up/Down to move and Enter to select. The visible `Back` row
  returns to the previous launcher step; for example, start mode can return to
  model selection, model selection can return to workspace selection, and file or
  question subflows can return to start mode. Press `m` on path pickers to enter
  a manual path. Terminals that do not support raw key input fall back to the
  numbered prompt.

Set `REMAIND_LAUNCH_DISCOVERY_ROOTS` to an `os.pathsep`-separated list of
extra roots when your Remaind projects live outside the current tree,
`~/Documents/Remaind`, or nearby Documents/Codex folders.

Assumptions to make explicit in your agent harness:

- The source file must remain available at the path recorded during ingest.
- Use `verify=True` / `--verify` before trusting retrieved slices; if the file
  has changed, Remaind raises `LargeDocumentError`.
- Broad searches return only up to `max_results`; when `may_have_more` is
  true, narrow the query or run another search before treating results as
  exhaustive.
- Raw `@file` loading is outside Remaind and may still fail in an agent UI.

---

## 6. Track the context budget

Remaind does **not** see your real model context window. You feed it an
estimate; it tells you which band you are in.

After each model turn, update the estimate and check the band:

```python
# `estimate_tokens` is the chars/4 approximation Remaind uses internally;
# substitute your model's real token count if you have it.
tokens = remaind.estimate_tokens(whole_context_so_far)
remaind.update_state(base, lambda st: {**st, "estimated_context_tokens": tokens})

cs = remaind.compaction_status(base)
print(cs.band)                 # "normal" | "warning" | "hard" | "emergency"
print(cs.recommendation)       # human-readable next action
if cs.compaction_needed:
    ...                        # see the next section
if cs.compaction_urgent:
    ...                        # band is "hard" or "emergency" — compact now
```

The default bands are 40k / 60k / 70k / 80k (`required` / `warning` / `hard`
/ `emergency`), configurable in `.context/schemas/thresholds.yaml`.

---

## 7. Compact when the band climbs

Compaction reduces the active context while preserving everything
load-bearing. **A compactor only ever proposes a candidate** — a structured
validator decides whether to accept it. If the candidate drops a decision,
ungrounds `next_step`, or fails to represent an `importance == 3` item, the
validator rejects it and the prior handover is kept untouched.

```python
try:
    result = remaind.compact(base)
    print(f"handover {result.handover_chars_before} -> {result.handover_chars_after} chars")
except remaind.CompactionRejected as exc:
    # The candidate was unfaithful. Nothing was lost — the prior handover
    # stands. A `validation` event was appended recording why.
    print("rejected:", exc.validation["missing_items"], exc.validation["unsupported_claims"])
except remaind.CompactionError as exc:
    print("compaction could not run:", exc)
```

On accept, `compact` appends a `compaction` event and a `validation` event,
writes the new handover atomically (snapshotting the old one), and advances
the compaction anchor.

### Compaction uses your selected model runtime — automatically

`remaind.compact(base)` takes no model arguments. It is invisible by design,
and supports local-first runtimes over plain HTTP with no SDK:

- **[Ollama](https://ollama.com)** — **auto-detected** on its universal
  default port (`localhost:11434`). If it's running, Remaind just uses it.
- **OpenAI-compatible endpoints** — vLLM, llama.cpp's server, LM Studio, Qwen
  API-style services, and similar `/v1` endpoints. These have no canonical
  port, so they're **opt-in**: set `REMAIND_OPENAI_BASE_URL` to the endpoint's
  `/v1` base URL and Remaind uses it (it takes precedence over Ollama). Set
  `REMAIND_OPENAI_API_KEY` only when the endpoint requires a bearer token.
- If neither is reachable, compaction falls back to `default_compact` —
  deterministic rule-based bookkeeping that never fails. (It advances the
  anchor and rewrites a `## Compaction Notes` section but does **not**
  actually summarize — the handover grows. Run a local model for real
  compression.)

`remaind compact` prints which compactor ran (`via local model via Ollama
(…)` / `via local model via Ollama auto (…)` /
`via OpenAI-compatible API (…)` / `rule-based fallback`) so you can confirm
your model is in use.

Ollama models are supported through both chat and completion APIs. Chat-capable
models such as Qwen normally use `/api/chat`; completion-only or chat-fragile
GGUF builds can use `/api/generate`. The default `REMAIND_OLLAMA_API=auto`
tries chat first, then completion/generate. Use `remaind doctor --smoke` to
prove the selected model can actually generate before relying on it.

For recurring operator checks, use `remaind monitor --json`. It combines
validation, status, doctor readiness, and deep-compaction run inspection into a
single non-zero exit signal suitable for cron, launchd, systemd, or CI alerts.
Use `remaind monitor --smoke` when a model-backed deployment must alert if the
local runtime is missing or cannot complete a tiny generation check.

OpenAI-compatible local servers are also adaptive. `REMAIND_OPENAI_API=auto`
tries `/chat/completions` first and then `/completions`, which covers
llama.cpp-style servers that expose completion-only model metadata.

Optional environment overrides — the Ollama zero-config path needs none:

| Variable | Effect |
|---|---|
| `OLLAMA_HOST` | Ollama's base URL (default `http://localhost:11434`). |
| `REMAIND_OLLAMA_MODEL` | Which Ollama model to use (default: the first it reports). |
| `REMAIND_OLLAMA_API` | Ollama API mode: `auto`, `chat`, or `generate`. Default `auto`. |
| `REMAIND_OLLAMA_THINK` | Whether to allow Ollama thinking traces. Default `false` for JSON-safe compaction. |
| `REMAIND_OLLAMA_TEMPERATURE` | Ollama generation temperature. Default `0.1`. |
| `REMAIND_OLLAMA_NUM_CTX` | Optional Ollama context-window override for large local models. |
| `REMAIND_OLLAMA_NUM_PREDICT` | Optional Ollama output-token override for longer handovers. |
| `REMAIND_OPENAI_BASE_URL` | `/v1` base URL of an OpenAI-compatible server, e.g. `http://localhost:8000/v1`. Opts into that runtime. |
| `REMAIND_OPENAI_MODEL` | Which model to request from that server (default: the first it reports). |
| `REMAIND_OPENAI_API` | OpenAI-compatible API mode: `auto`, `chat`, or `completions`. Default `auto`. |
| `REMAIND_OPENAI_API_KEY` | Optional bearer token for local OpenAI-compatible servers that require authorization. Omit it for no-auth local servers. |
| `REMAIND_OPENAI_TEMPERATURE` | OpenAI-compatible generation temperature. Default `0.1`. |
| `REMAIND_OPENAI_MAX_TOKENS` | Optional OpenAI-compatible output-token override. |
| `REMAIND_LOCAL_MODEL_TIMEOUT` | Local model request timeout in seconds. Default `600`; raise it for very large local models. |
| `REMAIND_MAX_MODEL_PROMPT_FRACTION` | Safety cap for model request size as a fraction of the configured context window. Default `0.80`; Remaind preserves the packet and skips the model call before entering the timeout-prone edge of the window. |
| `REMAIND_DISABLE_LOCAL_MODEL` | Set to force the rule-based compactor. |

Interactive `remaind launch` can collect the OpenAI-compatible endpoint and
token without requiring these variables ahead of time. Scripted or unattended
usage should continue to use environment variables so secrets stay out of shell
history and process arguments.

Whatever the model returns is still a *candidate* — it flows through the
same structured validator as the rule-based compactor, so a weak local
model cannot corrupt context. The worst case is a rejected candidate and
the prior handover kept. An unreachable runtime or an unusable response
surfaces as `CompactorResponseError`.

Advanced: `compact(base, compactor=...)` still accepts any object satisfying
the `Compactor` protocol if you need a custom transport — see
`select_sources`, `CompactionSources`, and `CompactionCandidate`.

---

## 8. Resume into a fresh context

When you start a fresh model context (a new run, or after hitting the
window limit), build a resume packet and inject it:

```python
result = remaind.resume(base)
fresh_context = result.packet.content     # markdown — assembled for a fresh agent
```

`resume` writes `.context/active/resume_packet.md`, appends a `resume`
event, and returns a `ResumeResult`. The packet bundles the handover,
selected state fields, FTS-retrieved memories, and recent high-importance
raw-log excerpts — token-capped.

Resume packets also render mechanical trust hints for retrieved evidence. These
labels are provenance hints, not a truth oracle: `user` means an explicit user
message, `verified_tool` means a tool-sourced result, `assistant` means an
assistant-authored event, and `source_linked_memory` means a memory with source
event IDs.

**Injecting the packet is your job.** Remaind assembles it; your harness
decides where it goes — typically prepended to the new context's system
prompt or sent as the first user message:

```python
new_session = start_model_session(system_prompt=BASE_PROMPT + "\n\n" + fresh_context)
```

Before continuing, check the **resume gate**:

```python
gate = result.packet.gate
if gate.should_interrupt:
    # raw log / state / handover conflict, a missing next_step, an
    # unrepresented user instruction, or a risky next tool — surface to
    # the user instead of resuming silently.
    for concern in gate.concerns:
        print("RESUME GATE:", concern)
    if gate.urgent:
        ...   # low confidence AND the next tool mutates / spends money / has side effects
```

---

## 9. Rollback

Every state and handover write snapshots the prior version. If a compaction
or a series of edits went wrong, restore the derived files as of a
timestamp — `events.jsonl` is never touched:

```python
try:
    result = remaind.rollback(base, target="2026-05-14T03:54:33Z")
    print("restored:", result.restored, "skipped:", result.skipped)
except remaind.RollbackError as exc:
    print("rollback failed:", exc)
```

`target` accepts ISO 8601 or the filename-safe form (`20260514T035433Z`).
Rollback restores validated snapshot bytes exactly. It does not call
`update_state`, refresh `updated_at`, or re-derive threshold fields under a
new config. Rollback is itself reversible — it snapshots the pre-rollback
files first.

---

## 10. A complete minimal agent loop

```python
import remaind

base = "./my-agent-run"
remaind.init(base)

state = remaind.status(base)
sid, tid = state["session_id"], state["task_id"]
writer = remaind.EventWriter.open(base)

def log(type_, actor, summary, *, content=None, importance=1):
    writer.append(remaind.EventInput(
        type=type_, actor=actor, summary=summary,
        session_id=sid, task_id=tid, content=content, importance=importance,
    ))

# No compactor to wire — remaind.compact() uses your local model if one is
# running, and the rule-based compactor otherwise.

while not done:
    user_msg = get_user_message()
    log("user_message", "user", user_msg[:80], content=user_msg, importance=3)

    reply, tool_calls, total_tokens = run_model_turn(...)
    log("assistant_message", "assistant", reply[:80], content=reply)
    for call in tool_calls:
        log("tool_call", f"tool:{call.name}", call.summary, content=call.args)
        log("tool_result", f"tool:{call.name}", call.result_summary,
            content=call.result, importance=2)

    # Keep the token estimate current.
    remaind.update_state(base, lambda st: {**st, "estimated_context_tokens": total_tokens})

    cs = remaind.compaction_status(base)
    if cs.compaction_urgent:
        try:
            remaind.compact(base)   # uses your local model if one is running
        except remaind.CompactionRejected:
            pass            # prior handover kept — safe to continue

    if cs.band == "emergency":
        packet = remaind.resume(base).packet
        reset_model_context(packet.content)     # your code injects it
```

---

## 11. Project continuity integration

For long-running product work, wire these calls into your agent harness:

```python
scorecard = remaind.build_continuity_scorecard(base)
evidence = remaind.build_evidence_map(base)

if scorecard.blocker:
    show_operator(scorecard.blocker, scorecard.next_step)

remaind.record_decision(base, text="Use local-first continuity state.")
remaind.mark_task_blocked(
    base,
    task="Build local bridge",
    reason="integration test failed",
)
remaind.promote_to_memory(
    base,
    text="The adapter export must remain source-linked.",
    tags=["adapter"],
)
remaind.export_adapters(base)
```

Equivalent CLI tools:

```sh
remaind continuity scorecard --path "$PROJECT"
remaind continuity evidence --path "$PROJECT"
remaind continuity export --path "$PROJECT"
remaind memory plan --path "$PROJECT"
remaind memory block "Build local bridge" --reason "integration test failed" --path "$PROJECT"
remaind memory decision "Use local-first continuity state." --path "$PROJECT"
remaind memory promote "The adapter export must remain source-linked." --tag adapter --path "$PROJECT"
remaind memory changed --path "$PROJECT"
```

Run the deterministic continuity proof:

```sh
remaind bench continuity --force
```

---

## 12. What Remaind does NOT do for you

Be honest with yourself about the boundaries:

- **It does not call your model or run your loop.** You drive everything.
- **It does not see your real context window.** It tracks the estimate
  *you* feed into `estimated_context_tokens`.
- **It does not decide event importance.** You tag every event; compaction
  fidelity depends on you tagging honestly.
- **It does not inject the resume packet.** `resume` assembles it; placing
  it into a fresh model context is your harness's job.
- **The rule-based fallback does not summarize.** When no local model is
  running, compaction is bookkeeping — the handover grows. Run a local
  model (Ollama, or an OpenAI-compatible server) for real compression.
- **It is single-writer.** Do not point two processes at one `.context/`.
- **It does no remote sync, no hosted UI, no multi-agent coordination** —
  these are explicit v1 non-goals.

---

## 13. Exception reference

| Exception | Raised by | When | What to do |
|---|---|---|---|
| `InitError` | `init` | `.context/` already exists (without `force=True`), or a bad target | Use `init(base, force=True)` to back up + reinit, or pick a clean `base` |
| `EventValidationError` | `EventWriter.append` | the constructed event fails the event schema | A bug in the event you built — inspect `exc.event`; nothing was appended |
| `StateValidationError` | `update_state` | the mutator returned a schema-invalid state | Fix the mutator; `state.json` was left untouched |
| `HandoverValidationError` | `write_handover` | the new handover is missing a required H2 section | Add the missing section(s) in `exc.missing` |
| `CompactionRejected` | `compact` | the structured validator rejected the candidate | Nothing lost — prior handover stands. Inspect `exc.validation`; retry or compact a smaller window |
| `CompactorResponseError` | `compact` (local-model path) | the local model was unreachable or returned an unusable response | Transient — retry; check the local model runtime is up |
| `CompactionError` | `compact` | compaction could not run at all | Inspect the message; often an upstream problem (unreadable `.context/`) |
| `RollbackError` | `rollback` | unparseable `target`, or no snapshot covers it | Check the timestamp format and that history exists for that time |
| `StatusError` | `status` | `state.json` is missing or unreadable | Run `remaind validate` to diagnose the `.context/` |
| `RunError` | `run_prompt`, `remaind run` | source file missing, context cannot initialize, retrieval fails, or the local model call fails | Check the file path, run `remaind doctor --smoke`, or retry with `--no-model` to inspect the packet |
| `LaunchError` | `launch`, `remaind launch` | project setup, readiness, runtime selection, or input capture failed before prompt intake | Fix the failed readiness check; use `--runtime fallback --input empty` for packet-only/local setup |
| `LargeDocumentError` | `ingest_large_document`, `search_large_document`, `slice_large_document`, `head_large_document`, `tail_large_document` | source file missing, context not initialized for ingest, invalid regex, or invalid line range | Run `remaind init` for the base context, verify the source file path, and retry with a valid query/range |
