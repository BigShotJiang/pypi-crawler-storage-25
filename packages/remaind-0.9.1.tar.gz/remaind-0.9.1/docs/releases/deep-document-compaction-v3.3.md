# Deep Document Compaction v3.3

This note records the post-audit implementation state for Remaind deep
document compaction. It supersedes the v3.2 planning text where the shipped
code intentionally differs from the original module and file-name sketch.

## Shipped Schema Names

Deep-compaction schemas use the same file-name convention as the rest of
Remaind's bundled schemas:

- `src/remaind/_templates/schemas/chunk_summary_v1.schema.json`
- `src/remaind/_templates/schemas/group_summary_v1.schema.json`
- `src/remaind/_templates/schemas/global_summary_v1.schema.json`

The earlier `chunk_summary_v1.json` / `group_summary_v1.json` /
`global_summary_v1.json` names were planning names only.

## Operator Knobs

`remaind run FILE "TASK" --deep-compact` accepts:

- `--deep-compact-mode {lenient,strict}`: lenient keeps going with visible
  failures; strict fails on any unrecovered chunk.
- `--reuse-deep-compact`: reuses a prior run only when the full cache key
  matches.
- `--deep-compact-chunk-tokens N`: overrides the source-chunk target. The same
  value can be supplied with `REMAIND_DEEP_COMPACT_CHUNK_TOKENS=N`.

Chunk-token overrides are part of the cache key. Changing the value
intentionally creates a fresh deep-compaction run.

## Module Layout

The original `_document_compaction.py` implementation shipped correctly but
became too large to maintain comfortably. The post-audit split keeps
`_document_compaction.py` as the orchestration and compatibility surface, with
focused helpers:

- `_doc_cache.py`: cache identity, run manifests, result types, runtime/model
  selection, shared constants, and prompt hashing.
- `_doc_planner.py`: line-based chunk planning and chunk-token targeting.
- `_doc_extractor.py`: per-chunk extraction, schema validation, quote
  verification, adversarial quarantine, redaction, persistence, and topic index
  writes.
- `_doc_normalizers.py`: deterministic normalization of common local-model
  shorthand outputs, with direct adversarial unit coverage.
- `_doc_reducer.py`: group/global reduction, mechanical fallback semantics, and
  evidence-block construction.

This keeps the public behavior unchanged while making the high-risk normalizer
surface testable in isolation.

## Encoding Policy

Large-document and deep-compaction source readers require valid UTF-8. Invalid
bytes now raise a clear `LargeDocumentError` or `DocumentCompactionError`
instead of being silently replaced. CRLF and LF line endings normalize to the
same line text for source-linked quote verification.

## Public API Note

Advanced custom handover compactors should import protocol primitives from
`remaind.compactor_protocol`. Root-level names such as `remaind.Compactor` and
`remaind.default_compact` remain available as compatibility re-exports through
the 1.x release line. Moving those names exclusively under
`remaind.compactor_protocol` would be a 2.0-only breaking change.
