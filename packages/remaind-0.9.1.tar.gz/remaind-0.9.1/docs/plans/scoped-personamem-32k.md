# Official Plan: Scoped PersonaMem-32k Accuracy Program

Status: approved for execution.

This program improves Remaind's scoped Agent Memory Benchmark PersonaMem-32k
performance while keeping every change tied to a real product capability. The
run is scoped because the AMB provider filters retrieved candidates by
PersonaMem-supplied `gold_ids` at the document level. Those ids define source
scope; they do not reveal answers. Public claims must distinguish this scoped
run from any open-retrieval AMB benchmark.

## Guiding Principles

- Target ladder: minimum pass `>85%`, strong pass `>90%`, world-class public
  target `94-97%`, and `100%` only after a gold-label ambiguity audit.
- No benchmark overfit: every fix must justify a product capability; hardcoded
  topic rules are smells to generalize or retire.
- Category-gated and confidence-gated: packet sections and deterministic hints
  ship per category with explicit thresholds.
- Schema after code: prove a change in code first; migrate only when derived
  state cannot express the intent.
- Shared helpers, not just constants: polarity and reason modules expose
  classifier functions so callers do not reimplement classification.
- Reconciliation discipline: pure extractors work per source; cross-record
  wiring such as `supersedes` lives in a post-ingest pass.
- Public-claims discipline: internal and external docs use "scoped AMB run"
  unless a separate unscoped run exists.

## Per-Phase Acceptance

Every phase produces these artifacts:

1. Failure taxonomy snapshot with `category`, `failure_pattern`, `query_id`,
   `picked`, `gold`, and `suspected_root_cause`.
2. Local tests plus adversarial fixtures where polarity, recency, negation, or
   reason extraction changes.
3. Packet snapshot tests per affected question type.
4. Deterministic smoke run for affected categories: fixed seed, saved
   `smoke_queries.json`, same answerer, same scorer build.
5. Full scoped PersonaMem-32k comparison against the locked baseline.
6. Tiered regression gate: no material overall regression, no per-category
   regression greater than `1pp` without written justification, net positive
   score, and targeted category positive.

Before any paid answer-model run, execute `remaind public-bench amb
offline-score` against the latest stored result and review rescues versus
introduced risks. Deterministic packet hints stay disabled unless this no-credit
check shows favorable risk.

## Trace Rules

- `REMAIND_BENCH_TRACE=1` enables trace writes.
- `REMAIND_BENCH_TRACE_DIR=/absolute/path` controls the trace destination.
- Trace records use PersonaMem `query_id` when available, otherwise a stable
  `query_hash`.
- Trace allowlist: packet content, scorer state, ranking metadata, retrieved
  memory ids, and per-query timing.
- Trace forbidden data: environment variables, API keys, raw credentials,
  request headers, response headers, and host-shell state. Redaction fails
  closed.

## Phases

### Phase 0: Snapshot, Traces, Failure Taxonomy

- Resolve the current benchmark worktree state without losing in-flight AMB
  improvements.
- Lock the scoped 32k baseline and archive `rag/32k.json` plus category
  reports under `reports/baselines/<date>/`.
- Extend the generated AMB provider to honor `REMAIND_BENCH_TRACE` and
  `REMAIND_BENCH_TRACE_DIR`, including query-id fallback and secret redaction.
- Generate `failures_taxonomy.csv` for the baseline.
- Add `remaind public-bench amb diff <run_a> <run_b>`.

Acceptance: baseline archived, custom trace directory verified, taxonomy CSV
reviewed, redaction test passes, and baseline-to-baseline diff is zero.

### Phase 1: Shared Polarity and Reason Engine

- Add `src/remaind/_polarity_vocab.py` with shared terms and helpers:
  `classify_polarity`, `has_return_signal`, `extract_reason_clause`, and
  `extract_topic_tokens`.
- Refactor existing polarity and reason callers to use the shared helpers.
- Add missing positive, negative, neutral-try, and return vocabulary from the
  failure audit.
- Do not add a schema migration in this phase.

Acceptance: at least 30 adversarial fixtures pass, helper usage is enforced,
affected recall categories lift in smoke, and the 32k tiered gate passes.

### Phase 2: Preference Timelines and Supersedes Reconciliation

- Keep `records_from_amb_session` as a pure per-session extractor.
- Add a post-ingest reconciliation pass that wires `supersedes` for polarity
  flips on the same user/topic chain.
- Extend preference timeline rendering to consume superseded records.
- Add a polarity column only if existing fields cannot express the chain.

Acceptance: join-to-leave fixtures produce an idempotent supersedes chain and
the 32k tiered gate passes.

### Phase 3: Structured Reason-for-Change Memory

- Extract explicit transition reasons such as "I stopped X because Y" and
  "I switched from A to B since C".
- Emit `reason_for_change` records and let reconciliation link them to prior
  preference records.

Acceptance: reason-recall category lift is positive and the tiered gate passes.

### Phase 4: Category-Gated Packet Sections

- Add `Structured Polarity State` for recall, fact-recall, preference-aligned
  recommendation, and generalization questions.
- Add `Reasons For Past Changes` only for reason-recall questions.
- Keep these sections additive; do not change scoring in this phase.

Acceptance: snapshots reviewed, category smoke lifts, untouched categories have
no material regression, and the tiered gate passes.

### Phase 5: Confidence-Gated Option Alignment

- Replace binary option-alignment enablement with per-category config.
- Keep existing enabled categories, pilot recall and reason-recall only after
  smoke shows lift, and defer preference-aligned/generalization until stable.
- Relax evolution confidence only on phrase requirements, not on score or
  margin floors, until A/B data supports it.

Acceptance: every newly whitelisted category shows smoke lift and the 32k gate
passes.

### Phase 6: High-Confidence Deterministic Hints

- Surface `choose_supported_answer` only when absolute score and margin clear
  configured high-confidence thresholds.
- Add anti-confabulation guidance across categories.
- Track answer-vs-hint agreement in diagnostics.

Acceptance: negation-fabrication failures drop and no category regresses more
than `1pp`.

### Phase 7: Full 32k Rerun, Sampled Split Gates, Failure Audit

- Run full scoped PersonaMem-32k and compare failure taxonomy to Phase 0.
- Run deterministic sampled 8k and 128k smoke gates.
- Defer 1M to release-candidate proof.
- Classify remaining failures as extraction miss, scorer miss, ambiguous gold,
  or answer-model error despite correct packet.
- Retire hardcoded topic rules that no longer affect accuracy.

Acceptance: target tier achieved, failure ledger written, and hardcoded-rule
audit reviewed.

### Phase 8: Public Benchmark Documentation

- Update benchmark docs and changelog with scoped scores, sampled split smokes,
  per-category breakdown, ambiguous-gold subset, and product capabilities.
- Tag a release only if the tier transition warrants it.

Acceptance: every benchmark claim clearly says scoped or open-retrieval, and
every claim ties to product capability.
