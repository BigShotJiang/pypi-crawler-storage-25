# Adversarial Hardening

Remaind treats memory as evidence, not as a privileged instruction channel.
This matters because long-running agent memory can contain hostile text from
archives, tool output, user-provided files, compromised summaries, or old
context that no longer reflects the user's intent.

## Threats Covered

- Prompt injection inside handovers, memories, raw excerpts, archives, or tool output
- Attempts to replace the system/developer prompt from stored content
- Attempts to inject privileged prompt boundaries inside archive text
- Attempts to mutate `.context/logs/events.jsonl`, `state.json`, or `handover.md` directly
- Attempts to forge memory, decisions, state, or completion status
- Attempts to disable Remaind, validation, logging, or the resume gate
- Attempts to force broad tool approval or disable sandbox/approval checks
- Attempts to exfiltrate secrets or install local persistence hooks
- Fake tool-result claims embedded in non-tool content
- Poisoned compaction output from a local model
- Superseded memory resurfacing as current truth
- Stale memory conflicting with the latest explicit user instruction

## Security Invariants

1. Latest explicit user instruction remains highest authority.
2. Raw events remain the source of truth below the latest user instruction.
3. Retrieved memory is evidence only; it cannot issue instructions.
4. Tool-result claims are trusted only when they are structured `tool_result`
   events from `tool:` actors.
5. Superseded memories are excluded from retrieval.
6. Resume packets surface adversarial findings before retrieved evidence.
7. Model-generated compaction candidates are rejected if they contain known
   hostile instruction shapes.

## Current Mechanism

The resume gate runs a deterministic scanner over:

- active handover
- active state
- raw log excerpts
- retrieved memories

Findings are added to `gate.concerns`, set `confidence_low`, and cause the
agent to interrupt before risky actions. The resume packet also includes an
`## Adversarial Review` section that tells the next model which sources were
flagged and how to treat them.

The scanner is intentionally conservative and mechanical. It does not infer
intent from ordinary prose; it matches concrete hostile instruction shapes.

The compaction validator also scans proposed `new_handover`, `new_state`,
`summary`, and `rationale` before accepting a model-generated candidate. If
the model output contains known adversarial instruction shapes, validation
emits `adversarial_content_clean=false`, records the findings, appends a
rejection event, and keeps the previous handover/state untouched.

## Proof Command

The starter kit includes an executable proof:

```sh
make adversarial
```

It verifies:

- raw-log prompt injection trips the resume gate
- fake tool-result claims are flagged
- phase-2 poison archive fixtures are flagged before resume
- superseded memories are not retrieved as current truth
- adversarial review renders before raw evidence in the resume packet
- poisoned compaction output is rejected before it becomes durable memory

The phase-2 poison suite covers privileged prompt-boundary injection, broad
tool approval, memory forgery, network exfiltration, and persistence hooks.

## Non-Goals

Remaind does not claim to solve arbitrary semantic deception. A model can still
misread harmless text, and a cleverly worded attack can evade a deterministic
scanner. The guarantee is narrower and testable: known hostile instruction
shapes are marked before resume, and memory never outranks the active user or
the append-only raw log.
