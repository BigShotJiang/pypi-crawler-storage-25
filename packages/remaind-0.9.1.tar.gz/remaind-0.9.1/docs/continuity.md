# Project Continuity

Remaind treats memory as continuity, not recall. The operational question is:
can a fresh agent reopen a project and continue the correct work from grounded
evidence after the context window, terminal session, or model process is gone?

The continuity layer is built on the existing `.context/` source of truth:
events, product status, plan reconciliation, progress snapshots, resume
packets, large-document manifests, rollback history, and promoted memories.
Public benchmark bridges use the same context-engineering contract: source
evidence is normalized, ranked by authority/freshness, budgeted, and rendered
with a visible trace instead of being assembled through benchmark-specific
prompt stuffing.

## Structured Memory Records

Remaind now derives a queryable continuity layer from the existing source
events and progress snapshots. Each record carries the operational shape a
fresh agent needs: who made the note or decision, what changed, when it
happened, where it came from, why it matters, how to act on it, its current
status, and the source event or artifact that supports it.

The derived records cover decisions, notes, tasks, blockers, requirements,
preferences, workflows, and facts. They do not replace the append-only event
log. They are rebuildable evidence indexes used by resume packets, launch
questions, continuity evidence, public benchmark adapters, and Python
integrations through `remaind.backfill_memory_records()` and
`remaind.search_memory_records()`.

## Scorecard

Run:

```sh
remaind continuity scorecard --path /path/to/project
```

The scorecard reports:

- continuity success readiness
- next-step accuracy
- blocker awareness
- stale-truth rejection
- source coverage
- packet efficiency
- recovery integrity

JSON output:

```sh
remaind continuity scorecard --path /path/to/project --json
```

The scorecard is deliberately transparent: every metric includes the evidence
it used. A low score is a product signal that the project needs a stronger
plan/status file, a fresher resume packet, or better source-linked progress.

## Evidence Map

Run:

```sh
remaind continuity evidence --path /path/to/project
```

The evidence map renders relationships such as:

- plan item -> source line
- blocker -> failed command/result
- decision -> source event
- memory -> source event
- rollback -> source event

This is the operator-facing trust view. It lets a human or agent inspect why
Remaind believes the current plan, blocker, and next step are true.

## Agent-Facing Memory Tools

Agents and shell workflows can update continuity state without writing raw
`.context/` files by hand:

```sh
remaind memory plan --path /path/to/project
remaind memory block "Build local bridge" --reason "integration test failed" --path /path/to/project
remaind memory decision "Use local-first state as the source of truth" --path /path/to/project
remaind memory promote "The adapter export must stay source-linked" --tag adapter --path /path/to/project
remaind memory changed --path /path/to/project
```

These commands write through the normal Remaind substrate: append-only events,
progress snapshots, product status, plan reconciliation, and the SQLite memory
index where appropriate.

## Cross-Tool Adapters

Run:

```sh
remaind continuity export --path /path/to/project
```

By default this writes adapter files under `.context/adapters/` for:

- Claude Code: `claude-code/CLAUDE.md`
- Cursor: `cursor/.cursor/rules/remaind-continuity.mdc`
- Windsurf: `windsurf/.windsurf/rules/remaind-continuity.md`
- Codex: `codex/AGENTS.md`
- Qwen Code: `qwen-code/QWEN.md`
- LangGraph: `langgraph/remaind_continuity_state.json`
- MCP-compatible tooling: `mcp/remaind-context.resources.json`

Adapter files are exports, not the source of truth. The canonical state remains
inside `.context/`.

## Project Continuity Benchmark

Run:

```sh
remaind bench continuity --force
```

The benchmark verifies Remaind-owned continuity behavior:

- forced reset resume packet includes plan reconciliation
- stale generated answers do not override current plan evidence
- active blockers drive the next action
- changed requirements are captured as source evidence
- large local documents are source-linked instead of copied into context
- rollback restores derived state and appends an event
- scorecard and evidence map expose the result

This benchmark does not call a model. It proves the continuity substrate before
model quality is introduced as a separate variable.
