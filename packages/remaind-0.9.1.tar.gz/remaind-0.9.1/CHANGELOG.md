# Changelog

## Unreleased

## v0.9.1

- Refresh first-run README and integration docs for the PyPI install path.
  The docs now use the official `python3 -m pip install --upgrade remaind`
  command, explain what the package installs, and distinguish Remaind's
  local-first memory from optional local or API-backed model runtimes.
- Update the package description so PyPI reflects Remaind as local-first
  memory and context continuity rather than local-model-only memory.

## v0.9.0

- Add a universal recommendation engine for normal Remaind product flows.
  `remaind launch`, `remaind ask`, `remaind run`, and product-plan
  reconciliation now share the same constraint-aware recommendation decision
  object, including selected action, confidence, criteria, active constraints,
  evidence, candidate scores, conflicts, and warnings.
- Add the project-continuity product layer. Remaind now exposes
  `remaind continuity scorecard`, `remaind continuity evidence`, and
  `remaind continuity export` so operators can inspect continuity readiness,
  claim-to-source trust links, and cross-tool adapter files for Claude Code,
  Cursor, Windsurf, Codex, Qwen Code, LangGraph, and MCP-compatible tooling.
- Add agent-facing memory tools: `remaind memory plan`, `memory block`,
  `memory decision`, `memory promote`, and `memory changed`. These commands
  write through the existing append-only event log, product status, plan
  reconciliation, progress snapshots, and memory index rather than creating a
  parallel state system.
- Add `remaind bench continuity`, a deterministic Remaind-owned benchmark for
  forced reset, stale answer demotion, blocker recovery, changed requirements,
  large-document source linking, rollback integrity, next-step accuracy, and
  evidence-map generation.
- Add the first public benchmark bridge: `remaind public-bench state-bench`.
  Remaind can now ingest STATE-Bench training trajectories, persist
  source-linked procedural learnings through the normal event/memory substrate,
  install a STATE-Bench `RemaindStateBenchAgent`, and smoke-test
  `retrieve_learnings` before an official STATE-Bench run.
- Add the Agent Memory Benchmark bridge: `remaind public-bench amb prepare`.
  Remaind can now install a real AMB `remaind` memory provider into a local AMB
  checkout, ingest benchmark documents through Remaind's event and memory
  substrate, and expose source-linked retrieval for official AMB runs.
- Update the AMB run template to select Gemini explicitly for answer generation
  so the official runner does not fall back to a Groq default when only a Gemini
  key is configured.
- Reposition the website around the broader service category: continuity
  beyond context windows. The landing page, metadata, signup flow, footer, AI
  crawler summary, docs, and integration copy now make clear that Remaind helps
  local models, API-backed models, coding agents, and automation workflows keep
  project state across resets while preserving the local-first memory story.
- Replace the How It Works reference page with an animated continuity workflow
  that shows work becoming packets, packets becoming model-ready context,
  progress moving forward, and the updated state looping into the next session.
- Add restrained landing-page motion: a gently drifting hero mark, signal-line
  sweep, staged hero reveal, living status dot, metric-card sheen, and subtle
  panel icon motion so the page feels active without becoming distracting.
- Refine the below-hero landing sections with calmer visual bands, stronger
  card surfaces, clearer proof metrics, and a more intentional final signup
  area so the page reads cleanly after the first viewport.
- Move Docs into the website footer and make the header navigation focus on
  How it works, Demo, Log in, and Early access.
- Simplify the website footer by removing duplicate in-page navigation links
  and switching the footer mark to a clean transparent production asset derived
  from the official square logo.

## v0.8.1

- Refresh website brand assets from the latest Remaind logo direction. The
  site now uses clean transparent SVG marks instead of image exports with baked
  preview backgrounds, updates the header wordmark, app icon, and hero
  watermark, and documents the brand-asset usage rules. The visible website
  lockup now uses cache-busted brand asset URLs, a larger header wordmark, and
  a first-viewport hero lockup so browsers cannot keep showing the prior mark
  and the brand update is visually obvious on the public site. The hero
  background now uses the official square logo as a clean transparent PNG
  export instead of the simplified SVG watermark.
- Refresh the Remaind website around the current local-AI positioning. The
  landing page now leads with the shift from capped, expensive hosted AI toward
  local AI, explains the continuity and reliability problems Remaind removes,
  frames capabilities as user outcomes instead of implementation mechanics, and
  repeats a minimal email/password early-access signup path throughout the page.
- Harden 1M-class deep-compaction answer-key runs. Exact identifier lookup
  tasks now locally recognize high-signal source terms, skip irrelevant
  negative-evidence filler chunks with validated empty summaries, and promote
  exact answer-bearing lines into verified quote evidence without spending a
  model call per chunk. Reducers now ignore empty chunk summaries before
  deciding whether model reduction is needed, and chunk shorthand repair accepts
  singular `source_line` only when the quoted text is byte-grounded in the
  cited source line. The real local DeepSeek 1M proof now completes with
  127/127 chunks succeeded, 0 failed, and 0 quarantined.

## v0.8.0

- Route `remaind context inspect` through the sovereign-memory starter launcher
  so the production `remaind` command reaches core Remaind context inspection
  instead of falling through to the configured agent.
- Add an end-to-end zero-to-continuation regression proof. The test starts a
  fresh project, activates Remaind memory, loads a product plan, records a
  failed developer command through presence, verifies the matching plan item is
  marked blocked, and confirms the next continuation context includes the
  product-plan reconciliation.
- Extend the zero-to-continuation proof with the successful-work path. A fresh
  project now proves that successful observed work updates product status,
  marks the matching plan item in progress without falsely completing it, and
  keeps the reconciliation in the next continuation context.
- Add a formal context engineering layer across every model-facing Remaind
  context path. Memory questions, `remaind run` retrieval-planner prompts and
  evidence packets, resume packets, handover compaction prompts, and
  deep-document extraction/reduction prompts now classify intent, label
  candidate sources by authority and freshness, budget selected context, and
  render an explicit trace of selected and omitted evidence. `remaind context
  inspect [--project NAME] "QUESTION"` prints the memory-question context packet
  without calling a model, so stale or incomplete answers can be debugged from
  the terminal.
- Seed durable product-continuation status as soon as `remaind launch` activates
  a workspace memory. A fresh workspace now has
  `.context/active/product_status.md`, `.context/active/product_status.json`,
  and `.context/logs/product_status.jsonl` before the first model answer,
  packet run, or handover update, so continuation questions always have a
  stable current-state anchor instead of depending only on historical packets.
- Add durable product-plan reconciliation. Remaind now writes
  `.context/active/plan_reconciliation.md`,
  `.context/active/plan_reconciliation.json`, and
  `.context/logs/plan_reconciliation.jsonl`, refreshes them at launch and after
  progress/presence updates, maps saved activity and blockers to plan items, and
  uses the reconciliation as high-authority context for continuation, resume,
  and status paths.
- Add the privacy-safe Remaind presence layer. `remaind daemon shell-init` now
  installs shell hooks that observe command metadata, exit codes, duration, and
  git changed-file summaries after each prompt. The hooks write
  `.context/active/presence_snapshot.json`, append `.context/logs/presence.jsonl`
  with fsync, and update product status for meaningful development activity or
  failed developer commands without recording terminal output.
- Add `remaind daemon install-shell-hook` for idempotent, one-time installation
  of the presence hook into `.zshrc`, `.bashrc`, or fish config.
- Strengthen continuation context for product work: launch now includes a
  product-authority brief, repo-plan review, and plain-English next-step rules
  for matching child projects, while filtering lower-authority process docs and
  generated Remaind Q&A artifacts out of ordinary continuation answers.
- Add crash-safe progress checkpoints for every `remaind run` / memory-question
  operation. Remaind now writes `.context/active/progress_snapshot.json` and
  appends `.context/logs/progress.jsonl` at run start, packet-ready,
  model-call-started, and final completed/blocked states, so a terminal crash
  or local-model timeout preserves the active task, blocker, incomplete work,
  last completed tasks, saved packet, answer note, and next recovery step.
  Resume packets and memory-question sources include the latest progress
  snapshot as authoritative current status evidence.
- Make bare `remaind` enter the interactive memory chat. Users can now type
  `remaind`, enter a product/workspace name, and ask to continue building
  without remembering the `ask` or `chat` subcommands.
- Improve continuation answers for child projects: matching project files now
  outrank parent workspace packet history, generated Remaind Q&A artifacts are
  filtered out of continuation context, and plan `File to create` entries are
  summarized as exists/missing before the model answers.
- Add the first always-present terminal layer: `remaind ask "..."` asks the
  active/project-matched memory state without walking through the full launcher,
  `remaind chat` keeps the user inside the memory-question loop, and
  `remaind daemon start|status|reindex|shell-init` maintains a local workspace
  index plus optional shell prompt hint (`Remaind memory active: ...`). These
  commands reuse the proven `remaind launch` packet pipeline, so continuation
  evidence, packet history, runtime selection, and audit artifacts stay
  consistent with the main launcher.
- Make old-project lookup search prior packet and answer history. Product names
  that only appear in previous `run_packet.md`, `run_answer.md`, or
  `resume_packet.md` artifacts can now activate the matching workspace, and
  continuation questions prioritize matching packet evidence before newer
  unrelated packet noise.
- Let product-name lookup match child project folders inside a workspace memory.
  If a monorepo has memory at the parent folder but the product lives in a
  child folder, `remaind ask --project NAME ...` can activate the parent memory
  and include matching child README/plan/status docs in the question packet.
- Add an authoritative current-runtime marker to memory-question packets so
  historical model/API-key/connection failures from older packets are not
  misreported as current blockers after the current model call succeeds.
- Let `remaind launch` activate an existing workspace memory by product or
  workspace name before showing the folder picker. Interactive launch now asks
  for a product/workspace name first, builds a deeper workspace-memory index,
  and searches existing `.context` folders by folder name, path topics,
  `active/handover.md`, `active/state.json`, and recent event summaries. The
  index tolerates hyphenated folder names, close spellings, and related topic
  phrases, then auto-selects the matching memory state when there is one clear
  match. When there is no match and the user picks a folder from the list,
  launch remembers that typed name as a local workspace alias for future
  launches. Scripts can use `remaind launch --project "Rutwais"` for the same
  behavior without typing an absolute path.
- Add `Update handover.md` to the interactive `remaind launch` flow. The
  start-mode menu now has a visible handover action plus a `Ctrl+H` shortcut
  for terminal selectors; the action runs the existing validated compaction
  pipeline and reports the updated `active/handover.md`.
- Render `Ask from memory state` answers like direct terminal replies: the
  human output now prints the model answer first without packet paths or
  readiness details, while packets remain written under `.context/active/` for
  audit and recovery. Interactive ask mode now stays in a memory-question loop
  until the user leaves the next question blank, so follow-up questions do not
  fall through into the shell. Ask packets also include a fresh launch-status
  block so older model/runtime failures in memory are not mistaken for current
  blockers. Follow-up questions now carry the current terminal conversation
  forward, so user corrections in the same launch override stale packet
  failures. Questions that ask for packets or packet history include the latest
  run packets and answer notes in the memory-question source. The interactive
  continuation step now accepts plain-language intent before showing the menu:
  typing `what is the next step?` starts memory chat directly, while phrases
  like `prepare memory packet`, `update handover`, or a document path route to
  the matching workflow; pressing Enter still opens the arrow-key picker.
  Memory questions now treat prior run packets as a workspace evidence library:
  every question includes a packet/answer inventory plus recent packet context,
  and explicit requests for all packets load every packet and answer note that
  fits the fixed question-source budget with omissions made transparent.
  Continuation requests such as `continue working`, `what is the next step?`,
  `latest progress`, or `project status` now trigger a structured project
  brief: the model is told to reconstruct product scope, active plan, latest
  progress, blockers, next TODOs, and the immediate implementation step from
  the resume packet plus budgeted packet-library context.
  If a local model disconnects during the first ask call, launch now waits for
  the local endpoint to recover and retries once; DeepSeek installs with the
  profile switcher can restart the current profile automatically before that
  retry. If DeepSeek reports a GPU-memory compute error, interactive launch can
  ask to free memory and retry instead of printing the raw server failure.
  Explicit OpenAI-compatible runs also stay pinned to that selected endpoint/model
  instead of drifting into Ollama while the endpoint is loading.
- Make DeepSeek easier to recognize in `remaind launch` model selection by
  rendering known local DeepSeek models with friendly labels such as
  `DeepSeek V4 Flash` while keeping the raw model id visible in the details.
- Offer the explicit `Free memory before starting DeepSeek?` preflight for
  every DeepSeek profile switch, including Turbo and keeping the current mode,
  so operators can pause competing local model servers before the first real
  model call.
- Report macOS folder-permission failures during `remaind launch` as actionable
  launcher errors instead of raw tracebacks.
- Reframe `remaind launch` output around memory state instead of treating
  Remaind like a destination folder: the picker now asks users to continue from
  a workspace memory state, the report says `Memory state: ACTIVE`, and ask
  mode reports `Answered from the current memory state`.
- Clarify the `remaind launch` start-mode picker so the question path is
  labeled `Ask from memory state`, and remove the no-question/empty
  path from the normal interactive menu. Scripts can still use `--input empty`;
  the empty completion message now warns that natural-language text typed
  afterward goes to the shell, not to the memory state.
- Add universal Remaind memory modes for `remaind launch`. `turbo` is now the
  default for every model/provider and sends compact packets (1 memory, 3 raw
  excerpts, 1024 output-token cap, and a 12k run-packet cap) for faster daily
  startup; `standard` and `deep` remain available via
  `--memory-mode standard|deep` or `REMAIND_MEMORY_MODE` when fuller memory is
  more important than speed.
- Add a first-class `DeepSeek mode` picker to `remaind launch` for MOSAI
  local-DeepSeek installs. Users can choose `Stable - larger, 131k context`,
  `Turbo - faster, 65k context`, `Nitro - fastest, 65k context,
  experimental`, or keep the current profile without typing the internal
  switcher path; launch updates the active environment and then runs the
  normal readiness checks. Nitro-capable switchers can also ask whether to
  free memory before starting DeepSeek, making competing-model cleanup
  explicit instead of silent.
- Harden CLI startup when the shell's current directory is unreadable. Parser
  defaults now fall back to `$PWD`, the home directory, or `/` instead of
  crashing before `--version` or help can render.
- Add a guided `Connect API model (OpenAI-compatible)` path to
  `remaind launch`. Users without a local LLM can choose an API endpoint from
  the model picker, enter an optional bearer token for the current launch only,
  select a discovered API model, and continue through the same readiness and
  run flows without pre-exporting environment variables.
- Add a visible `Back` option to the interactive `remaind launch` menus. Users
  can now move from start mode back to model selection, from model selection
  back to project selection, and from file/question subflows back to start mode
  without cancelling the launcher or typing shell commands.
- Add `remaind launch --input ask --task "..."` and an interactive
  "Ask from memory state" start mode. Ask mode builds the current resume
  packet and runs the question against it, so users can ask things like
  `status of Rutwais?` from the memory state instead of accidentally sending natural
  language to the shell. Interactive resume mode now offers to ask a question
  from the newly prepared resume packet before returning.
- Add an interactive local-model selector to `remaind launch`. After the
  project folder is chosen, launch lists detected Ollama/OpenAI-compatible
  models before readiness; if the selected model fails its smoke test, the
  operator can choose another detected model before packet-only fallback.
- Add explicit `remaind launch --yolo-model --model MODEL` support plus
  selectable YOLO entries for every detected model, e.g. `deepseek-v4-flash`
  and `deepseek-v4-flash (YOLO / skips model test)`. Operators no longer need
  to type a known model name just to bypass the launch smoke test; the advanced
  manual entry remains only for models that are genuinely not listed. Memory,
  disk, schema, and packet checks still run and the report labels YOLO models
  as unverified.
- Add `REMAIND_LAUNCH_MODEL_TIMEOUT` (default `20` seconds) so launch
  readiness probes stay responsive even when longer answer/deep-compaction
  calls use a larger `REMAIND_LOCAL_MODEL_TIMEOUT`.
- Improve `remaind launch` interactive UX with arrow-key terminal pickers for
  project folders, prompt files, confirmations, and start-mode selection. The
  project picker shows full paths for current/discovered `.context` folders,
  and file mode lists registered large documents before nearby
  text/Markdown/JSON-style files while preserving manual path entry and
  non-interactive `--path` / `--file` behavior.

## v0.7.1

- Harden deep-compaction runtime preflight: `TextModelClient.smoke_test()`
  runs a tiny JSON-mode generation probe before creating any deep-compaction
  artifact tree. Listed-but-unloadable local models (GGUF corruption, GPU
  OOM, partial blobs) now fail fast with the baseline packet preserved
  instead of producing a run full of failed chunks.
- Add `REMAIND_OPENAI_API_KEY` support for local OpenAI-compatible servers
  that require bearer-token auth (vLLM, llama.cpp, internal proxies). The
  token is sent on every model-discovery probe and generation request and
  is never echoed in `remaind` stdout, stderr, or the JSON output.
- Cap deep-compaction structured extraction (`2048` tokens) and reduction
  (`4096` tokens) outputs so operator-level `REMAIND_OPENAI_MAX_TOKENS`
  settings cannot turn every chunk request into an unbounded long-generation
  request. The cap is per-call, not part of the cache key, so changing it
  does not silently invalidate prior runs.
- Add an `msvcrt` byte-range lock fallback in the event writer for Windows
  hosts where `fcntl` is unavailable, plus a `windows-latest` CI job that
  exercises the concurrent hash-chain append proof on a real Windows runner
  so the locking path is no longer limited to monkeypatched Unix coverage.
- Add `tests/test_deep_compaction_integration.py` opt-in slow-test suite,
  including a 1M-token answer-key harness gated by
  `REMAIND_INTEGRATION_REAL_MODEL_1M=1` for hardware acceptance proofs.
  Register `slow` and `integration` pytest markers in `pyproject.toml`.
- Fix `remaind rollback` exiting 0 when no snapshots were restored. A
  rollback to a timestamp earlier than any history is now a clear failure
  (exit 1) so cron/CI callers are not silently fooled into thinking the
  rollback succeeded.
- Fix `remaind doctor` recommending `remaind validate` on uninitialized
  directories. When the validation failure is `.context/: missing`, doctor
  now recommends `remaind init` — the operator's actual next step.
- Catch arbitrary local-server bearer tokens in `scripts/secret_scan.py`.
  The existing `sk-…` literal pattern missed non-OpenAI-format tokens
  (vLLM UUIDs, llama.cpp project IDs) assigned to `REMAIND_OPENAI_API_KEY`
  or `OPENAI_API_KEY`; the new `openai_api_key_assignment` regex catches
  them while excluding common placeholders.
- Add a shared `RemaindError` catch-property regression test asserting
  every concrete error class remains catchable through `RemaindError` with
  `isinstance` specificity preserved.
- Document seven load-bearing deep-compaction operator assumptions in
  `docs/operations.md` (model JSON-mode requirement, Ollama unpinned-tag
  drift, single-chunk reducer skip, silent evidence reduction on
  failures, per-chunk timeout sizing, uncoordinated concurrent runs,
  Windows CI-certification), plus `REMAIND_DEEP_COMPACT_DEBUG`,
  `REMAIND_OPENAI_API_KEY` security guidance, the Ollama auto-pick risk,
  and the documented `remaind run` exit-code contract (0 / 1 / 2).
- Document the 1M+ local-model acceptance proof command in
  `docs/operations.md` so operators can run it against their own
  hardware.

## v0.7.0

- Promote deep document compaction to a release-ready feature after the
  post-implementation audit chain. The shipped path supports
  `remaind run FILE "TASK" --deep-compact`, resumable artifacts, source-linked
  exact evidence expansion, answer-key validation, and local-first operation
  through configured Ollama or OpenAI-compatible runtimes.
- Split the deep-compaction implementation into focused internal modules:
  `_doc_planner`, `_doc_cache`, `_doc_extractor`, `_doc_normalizers`, and
  `_doc_reducer`, while keeping `_document_compaction` as the orchestration and
  compatibility surface.
- Add `remaind.compactor_protocol` as the stable public home for advanced
  handover compactor integrations. Root-level protocol re-exports remain
  supported through the 1.x release line; moving them exclusively under
  `remaind.compactor_protocol` would be a 2.0-only breaking change.
- Require valid UTF-8 in large-doc and deep-compaction source readers, and
  normalize CRLF/LF source lines consistently for quote verification.
- Backfill direct adversarial coverage for every deep-compaction normalizer,
  expand benchmark coverage, and add an error-hierarchy catch-property test
  proving all concrete errors remain catchable through `RemaindError`.
- Raise the enforced pytest coverage gate from 75% to 80% and update
  contributor/release documentation to match the stricter bar.
- Document the shipped deep-compaction v3.3 details, including `.schema.json`
  schema names, `--deep-compact-chunk-tokens`, module layout, encoding policy,
  and compactor protocol support timeline.
- Document deep-compaction operator assumptions, including JSON-mode model
  requirements, cache/model identity stability, single-chunk reducer behavior,
  partial evidence handling, timeout tuning, concurrent run behavior, and
  unverified Windows locking.
- Add a deep-compaction model preflight so listed-but-unloadable local models
  fail before chunk extraction starts, preserving the baseline packet without
  creating a run full of failed chunk artifacts.
- Add an `msvcrt` event-lock fallback for Windows, unit coverage for the
  non-`fcntl` lock path, and a targeted `windows-latest` CI proof for
  concurrent event append locking.
- Fix `remaind rollback` so a no-op rollback that restores zero snapshots exits
  non-zero instead of silently reporting success to cron or CI callers.
- Support bearer-token authentication for local OpenAI-compatible runtimes via
  `REMAIND_OPENAI_API_KEY`, covering llama.cpp servers configured with an
  operator-owned local API key.
- Cap deep-compaction structured extraction/reduction output sizes independently
  of final-answer output settings, preventing large `REMAIND_OPENAI_MAX_TOKENS`
  values from making every chunk extraction generate unnecessarily long JSON.
- Add an opt-in 1M+-token real-model answer-key integration proof so the
  original DeepSeek acceptance criterion is executable on operator hardware
  instead of being tracked only as a manual checklist item.

## v0.6.7

- Add a shared `RemaindError` base class while preserving every existing
  specific error type for backwards-compatible callers.
- Add recursive `Redactor.redact_value(...)` for safe structured payload
  redaction and migrate deep-compaction payload redaction to the shared API.
- Add direct CLI parser coverage for command help, version output, deep
  compaction flags, launch mode flags, and large-doc cache pruning defaults.
- Bound runtime dependencies to supported major versions (`jsonschema<5`,
  `pyyaml<7`) while keeping the locked install set unchanged.
- Add enforceable PR quality gates: a pull-request template, a scope-check CI
  job for oversized multi-feature changes, and a pytest coverage gate.
- Document CLI flag-naming conventions and deep-compaction chunk-token tuning.
- Tighten deep-compaction mechanical fallback semantics so only byte-verified
  source quotes are labeled `verified_quote`; model-derived fallback claims are
  marked `summary_only` and are not expanded as raw evidence.
- Add resume-packet pointers to recent deep-compaction runs, including run id,
  document id, status, cache prefix, model label, and chunk/claim counts without
  embedding full document evidence.
- Expand direct `TextModelClient` coverage across Ollama, OpenAI-compatible
  runtimes, JSON extraction, environment selection, availability probes, and
  transport failure handling.
- Add `remaind run FILE "TASK" --deep-compact`, a local-first hierarchical
  document compaction path for million-token source files. It chunks by line
  range, extracts structured evidence with the selected local model, validates
  schema/bounds/quotes, quarantines hostile derived text, redacts summaries,
  reduces to answer-affecting claims, and expands exact raw source lines into
  `run_packet.md`.
- Add resumable deep-compaction artifacts under
  `.context/large-docs/<doc_id>/deep-compactions/<run_id>/` plus
  `remaind large-doc inspect` and `remaind large-doc prune-deep-compactions`.
- Preserve a baseline `run_packet.md` before any deep-compaction model call so
  timeouts or interrupted local model requests do not leave operators with zero
  packet.
- Convert interrupted deep-compaction runs into a clean Remaind error with the
  baseline packet preserved and an explicit `--reuse-deep-compact` resume path.
- Add visible deep-compaction progress plus `--deep-compact-chunk-tokens` /
  `REMAIND_DEEP_COMPACT_CHUNK_TOKENS` so slower local runtimes can trade more
  chunks for shorter individual model requests and resumable checkpoints.
- Add `remaind monitor`, a scheduler-friendly health and alert command that
  combines validation, status, doctor readiness, and deep-compaction run
  inspection with a non-zero alert exit code.
- Add `remaind launch` as the memory-first project startup flow: it resolves a
  project folder, creates or loads `.context/`, validates it, proves runtime
  readiness, then routes into paste, file, resume, or empty-session mode.
- Add safe paste capture after readiness: pasted prompts are written to a local
  `.context/artifacts/launch-pastes/` file before being processed through
  Remaind's large-prompt packet path.
- Make explicit Ollama `remaind run` executions override any configured
  OpenAI-compatible endpoint so model selection stays predictable.
- Add pinned Python runtime/dev lock files, locked dependency audits in CI and
  release, stronger current-tree secret scanning, and an operations checklist
  for monitoring, alerting, and rollback.

## v0.6.6

- Make `remaind` the primary installed starter launcher while keeping
  `sovereign` as a compatibility alias and exposing raw core CLI access through
  `remaind core ...`.
- Add `remaind run FILE "TASK"` for direct terminal execution against huge
  local prompts/documents through a compact evidence packet and the configured
  local model.

## v0.6.5

- Add `remaind large-doc`, a first-class terminal-backed path for indexing,
  searching, and slicing large local documents without relying on agent UI file
  readers or copying the source file into `.context/`.
- Add source-manifest verification, large-doc manifest validation, and starter
  prompt guidance so agents avoid raw `@file` loading for oversized local files.
- Add the Sovereign Memory Starter `model-test` battle harness for deterministic
  Remaind retrieval checks plus optional local model matrix testing.
- Extend the starter runtime layer to support OpenAI-compatible local servers
  such as llama.cpp server, including the DeepSeek v4 Flash split-GGUF profile.
- Make DeepSeek profiles folder-native by defaulting their agent workdir to
  `~/Documents/DeepCode` while keeping Qwen profiles on `~/Documents/Qwen-Code`.
- Route `remaind model-test` through the installed launcher as a management
  command so compatibility proofs do not accidentally start an agent shell.
- Add adaptive Ollama API support for local models that expose completion only:
  `REMAIND_OLLAMA_API=auto` now tries `/api/chat` first and falls back to
  `/api/generate`, with smoke-test diagnostics through `remaind doctor --smoke`.
- Add a `deepseek-v4-flash` starter-kit profile and carry the same adaptive
  chat/generate runtime through setup, compaction, chat, and doctor checks.
- Add the Sovereign Memory Starter `proof-2m` terminal A/B demo command for
  raw 2M prompt failure versus compact resume-packet success on a local model.

## v0.6.4

- Add writer-owned SHA-256 event-chain metadata for new raw events.
- Teach `remaind validate` to verify the event chain and report
  continuity-breaking edits, deletions, or reordering.
- Label resume-packet evidence with mechanical trust hints such as `user`,
  `verified_tool`, `assistant`, `derived_memory`, and
  `source_linked_memory`.
- Add regression coverage for writer-owned chain metadata and tamper detection.

## v0.6.3

- Add a starter-kit `bootstrap.sh` path that can install a managed local
  Python through checksum-verified `uv` when Python 3.11+ is missing.

## v0.6.2

- Add phase-2 adversarial scanner rules for prompt-boundary injection,
  permission escalation, memory forgery, network exfiltration, and persistence
  hooks.
- Expand the remaind benchmark and starter proof with poison archive and
  revocation-pressure checks.

## v0.6.1

- Add `remaind doctor`, a read-only context and local-runtime health check.
- Make resume-packet included ID metadata match the sections that actually
  survive the packet budget.
- Redact high-confidence UTF-8 byte payloads before storage.
- Harden web security headers, environment handling, privacy/terms pages, and
  analytics event validation.
- Harden CI/release with current-tree secret scanning, tag/version checks,
  expanded wheel smoke tests, least-privilege permissions, and artifact
  retention.
- Add product guardrails that reject hard-coded docs test counts and hosted
  service fallbacks.
- Quote plain-text FTS queries before SQLite search so reserved words are
  treated as terms.
- Add EventWriter-level ULID clock-regression coverage.
- Clarify proprietary license/versioning posture and archive boundaries.

## v0.6.0

- Add `remaind bench sovereign`, a deterministic beyond-context benchmark for
  fresh-process retrieval, distant contradiction detection, superseded-memory
  exclusion, source links, and adversarial resume-gate handling.
- Add starter-kit `make bench` / `remaind bench` wrappers for the same proof.

## v0.5.0

- Add adversarial resume scanning for poisoned handovers, raw excerpts, state,
  and retrieved memories.
- Add an `## Adversarial Review` section to resume packets before retrieved
  evidence.
- Reject model-generated compaction candidates that contain known hostile
  instruction shapes before they can update handover/state.
- Exclude superseded memories from FTS retrieval.
- Add the starter-kit `make adversarial` proof and wire it into CI.

## v0.4.1

Starter-kit setup release.

- Add `make setup` as the beginner-safe one-command setup path.
- Add `remaind setup` for refreshing local configuration without reinstalling.
- Upgrade `remaind doctor` into a readiness checklist with concrete fixes.
- Let the installed `remaind` launcher run management commands such as `doctor`,
  `verify`, and `proof`.
- Harden launcher detection so managed wrappers are not mistaken for real agent CLIs.
- Fix `uninstall.sh --install-bin` for clean temporary installs and test automation.
- Verify the release zip install path for both console and Qwen Code adapters.

## v0.4.0

First Sovereign Memory product release.

- Harden core local-model compaction for Qwen / DeepSeek-style thinking models.
- Disable Ollama thinking traces by default for JSON-safe compaction.
- Add local-model generation controls: timeout, context window, output tokens, and temperature.
- Recover balanced JSON payloads from mixed model output before validation.
- Ignore invalid model-proposed state enum values before writing state.
- Verify real compaction against local Ollama with `qwen3.6-35b-a3b-full:latest`.
- Ship the Sovereign Memory Starter kit as a release zip.
- Add the starter-kit deterministic continuity proof.
- Align product copy around 100% local memory for AI agents working beyond one context window.
- Upgrade GitHub Actions to Node 24-compatible action versions.
