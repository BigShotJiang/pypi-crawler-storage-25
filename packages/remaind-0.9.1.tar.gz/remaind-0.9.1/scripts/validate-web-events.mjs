#!/usr/bin/env node

import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const repoRoot = new URL("..", import.meta.url).pathname;
const eventsYaml = readFileSync(join(repoRoot, "experiment/EVENTS.yaml"), "utf8");

const documented = new Set();
const requiredProperties = new Map();
let inEvents = false;
let currentEvent = null;
let currentProperty = null;
for (const line of eventsYaml.split("\n")) {
  if (line === "events:") {
    inEvents = true;
    continue;
  }
  if (!inEvents) continue;
  const match = line.match(/^  ([a-z][a-z0-9_]*):$/);
  if (match) {
    currentEvent = match[1];
    currentProperty = null;
    documented.add(currentEvent);
    requiredProperties.set(currentEvent, new Set());
    continue;
  }
  const propMatch = line.match(/^      ([a-z][a-z0-9_]*):$/);
  if (propMatch && currentEvent) {
    currentProperty = propMatch[1];
    continue;
  }
  const requiredMatch = line.match(/^        required:\s*true\s*$/);
  if (requiredMatch && currentEvent && currentProperty) {
    requiredProperties.get(currentEvent).add(currentProperty);
  }
}

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === "node_modules" || name === ".next") continue;
    const path = join(dir, name);
    const st = statSync(path);
    if (st.isDirectory()) {
      walk(path, out);
    } else if (/\.(ts|tsx)$/.test(name)) {
      out.push(path);
    }
  }
  return out;
}

const used = new Map();
const missingRequired = [];
for (const file of walk(join(repoRoot, "web"))) {
  const text = readFileSync(file, "utf8");
  const re = /\b(?:trackEvent|trackServerEvent)\(\s*["']([a-z][a-z0-9_]*)["']/g;
  for (const match of text.matchAll(re)) {
    const event = match[1];
    if (!used.has(event)) used.set(event, []);
    used.get(event).push(file.replace(repoRoot, ""));
    const required = requiredProperties.get(event) ?? new Set();
    if (required.size === 0) continue;
    const callText = text.slice(match.index, text.indexOf(")", match.index) + 1);
    for (const prop of required) {
      const propPattern = new RegExp(`\\b${prop}\\b\\s*:`);
      if (!propPattern.test(callText)) {
        missingRequired.push(
          `${file.replace(repoRoot, "")}: ${event} missing required ${prop}`,
        );
      }
    }
  }
}

const undocumented = [...used.keys()].filter((event) => !documented.has(event));
const unused = [...documented].filter((event) => !used.has(event));

if (undocumented.length || unused.length || missingRequired.length) {
  if (undocumented.length) {
    console.error("Undocumented analytics events:");
    for (const event of undocumented) {
      console.error(`  - ${event}: ${used.get(event).join(", ")}`);
    }
  }
  if (unused.length) {
    console.error("Documented analytics events with no web call:");
    for (const event of unused) {
      console.error(`  - ${event}`);
    }
  }
  if (missingRequired.length) {
    console.error("Analytics calls missing required properties:");
    for (const item of missingRequired) {
      console.error(`  - ${item}`);
    }
  }
  process.exit(1);
}

console.log(`analytics events ok (${used.size} event names)`);
