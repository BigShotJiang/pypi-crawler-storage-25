#!/usr/bin/env python3
"""Fail CI when obvious live credentials are present in the current tree."""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {
    ".git",
    ".mypy_cache",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "build",
    "dist",
    "htmlcov",
    "node_modules",
    "starter-dist",
    "tests",
    "__pycache__",
}
SKIP_SUFFIXES = {
    ".ico",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".zip",
    ".whl",
    ".gz",
    ".sqlite",
}

PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("vercel_oidc_token", re.compile(r"VERCEL_OIDC_TOKEN\s*=\s*\S+")),
    ("private_key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    (
        "jwt_literal",
        re.compile(
            r"\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b"
        ),
    ),
    ("github_token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{30,}\b")),
    ("openai_key", re.compile(r"\bsk-[A-Za-z0-9]{32,}\b")),
    ("anthropic_key", re.compile(r"\bsk-ant-[A-Za-z0-9_-]{32,}\b")),
    # Catch arbitrary bearer tokens assigned to the local-OpenAI-compatible
    # env vars. Local vLLM/llama.cpp servers often use non-sk-format tokens
    # (UUIDs, project IDs, etc.) that the openai_key literal pattern misses.
    # Excludes obvious placeholders to keep false-positives down.
    (
        "openai_api_key_assignment",
        re.compile(
            r"(?i)\b(?:REMAIND_)?OPENAI_API_KEY\s*=\s*[\"']?"
            r"(?!your-|<|\$|placeholder|example|local-\S*-token|\s)"
            r"[A-Za-z0-9_.\-]{12,}"
        ),
    ),
    ("aws_access_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("aws_secret_key_assignment", re.compile(r"(?i)aws_secret_access_key\s*=\s*\S+")),
    (
        "supabase_service_role",
        re.compile(
            r"SUPABASE_SERVICE_ROLE_KEY\s*=\s*[\"']?(?!your-|<|\$|supabase\.|process\.)[A-Za-z0-9_-]{20,}"
        ),
    ),
]


def should_skip(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return True
    return path.suffix.lower() in SKIP_SUFFIXES


def main() -> int:
    findings: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or should_skip(path):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        rel = path.relative_to(ROOT)
        for name, pattern in PATTERNS:
            for match in pattern.finditer(text):
                line = text.count("\n", 0, match.start()) + 1
                findings.append(f"{rel}:{line}: {name}")

    if findings:
        print("Potential secrets found:", file=sys.stderr)
        for item in findings:
            print(f"  - {item}", file=sys.stderr)
        return 1
    print("secret scan ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
