#!/usr/bin/env python3
"""Guard against oversized, multi-feature pull requests.

The check is intentionally conservative: small PRs pass even when they touch
several support surfaces, while large PRs must stay within one primary product
area. This catches the failure mode where unrelated features are bundled into
one review without blocking normal docs/tests/changelog companions.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MAX_FILES = 30
SUPPORT_SCOPES = {"docs", "tests", "process", "packaging"}


def changed_files(diff_range: str) -> list[str]:
    proc = subprocess.run(
        ["git", "diff", "--name-only", "--diff-filter=ACMRT", diff_range],
        cwd=ROOT,
        check=True,
        text=True,
        capture_output=True,
    )
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def primary_scope(path: str) -> str:
    parts = Path(path).parts
    if not parts:
        return "unknown"
    if parts[0] == ".github" or path == "CONTRIBUTING.md" or parts[0] == "scripts":
        return "process"
    if parts[0] in {"README.md", "CHANGELOG.md", "HANDOVER.md", "docs"}:
        return "docs"
    if parts[0] in {"pyproject.toml", "requirements.lock", "requirements-dev.lock"}:
        return "packaging"
    if parts[0] == "web":
        return "web"
    if parts[0] == "starter-kits":
        return "starter-kit"
    if parts[0] == "tests":
        return "tests"
    if len(parts) >= 3 and parts[0] == "src" and parts[1] == "remaind":
        if len(parts) >= 4 and parts[2] == "commands":
            return f"command:{Path(parts[3]).stem}"
        stem = Path(parts[2]).stem
        if stem.startswith("_document_compaction") or stem.startswith("_doc_"):
            return "document-compaction"
        if stem in {"_text_model", "_local_compactor"}:
            return "local-model"
        return f"core:{stem.lstrip('_')}"
    return parts[0]


def scope_findings(files: list[str], *, max_files: int) -> list[str]:
    scopes = {primary_scope(path) for path in files}
    primary_scopes = scopes - SUPPORT_SCOPES
    findings: list[str] = []
    if len(files) > max_files and len(primary_scopes) > 1:
        findings.append(
            f"{len(files)} changed files across {len(primary_scopes)} primary scopes "
            f"({', '.join(sorted(primary_scopes))}); split this into focused PRs "
            f"or lower blast radius below {max_files} files."
        )
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("diff_range", help="git diff range, for example origin/main...HEAD")
    parser.add_argument(
        "--max-files",
        type=int,
        default=int(os.environ.get("REMAIND_PR_SCOPE_MAX_FILES", DEFAULT_MAX_FILES)),
    )
    args = parser.parse_args(argv)

    files = changed_files(args.diff_range)
    findings = scope_findings(files, max_files=args.max_files)
    if findings:
        print("Pull request scope check failed:", file=sys.stderr)
        for finding in findings:
            print(f"  - {finding}", file=sys.stderr)
        print("\nChanged files:", file=sys.stderr)
        for path in files:
            print(f"  - {path} [{primary_scope(path)}]", file=sys.stderr)
        return 1
    print(f"PR scope ok: {len(files)} changed file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
