#!/usr/bin/env python3
"""Validate product-scope guardrails that docs and web code must keep."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC_PATHS = [
    ROOT / "README.md",
    ROOT / "HANDOVER.md",
    *sorted((ROOT / "docs").glob("*.md")),
    *sorted((ROOT / "web/app").rglob("*.tsx")),
    *sorted((ROOT / "web/components").rglob("*.tsx")),
    ROOT / "web/public/llms.txt",
]
STALE_TEST_COUNT_RE = re.compile(
    r"\b\d{2,5}\s+(?:tests?|test functions|passed|passing)\b",
    re.IGNORECASE,
)
HOSTED_FALLBACK_PATTERNS = [
    ("production_supabase_url", re.compile(r"https://[a-z0-9]+\.supabase\.co")),
    ("jwt_literal", re.compile(r"\beyJ[A-Za-z0-9_-]{20,}\.")),
    ("posthog_project_key", re.compile(r"\bphc_[A-Za-z0-9]{20,}\b")),
]


def _line_number(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def check_docs_have_no_hardcoded_test_counts() -> list[str]:
    findings: list[str] = []
    for path in DOC_PATHS:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        for match in STALE_TEST_COUNT_RE.finditer(text):
            findings.append(
                f"{path.relative_to(ROOT)}:{_line_number(text, match.start())}: "
                f"hard-coded test count `{match.group(0)}`"
            )
    return findings


def check_web_has_no_hosted_fallbacks() -> list[str]:
    findings: list[str] = []
    paths = [
        ROOT / "web/lib/supabase-env.ts",
        ROOT / "web/lib/analytics-env.ts",
        ROOT / "web/lib/analytics.ts",
        ROOT / "web/lib/analytics-server.ts",
    ]
    for path in paths:
        text = path.read_text(encoding="utf-8")
        for name, pattern in HOSTED_FALLBACK_PATTERNS:
            for match in pattern.finditer(text):
                findings.append(
                    f"{path.relative_to(ROOT)}:{_line_number(text, match.start())}: "
                    f"{name} must not be hard-coded"
                )
    supabase_env = (ROOT / "web/lib/supabase-env.ts").read_text(encoding="utf-8")
    if "requiredPublicEnv" not in supabase_env:
        findings.append("web/lib/supabase-env.ts: missing requiredPublicEnv guard")

    example = ROOT / "web/.env.local.example"
    if not example.is_file():
        findings.append("web/.env.local.example: missing")
    else:
        text = example.read_text(encoding="utf-8")
        for key in (
            "NEXT_PUBLIC_SUPABASE_URL",
            "NEXT_PUBLIC_SUPABASE_ANON_KEY",
            "NEXT_PUBLIC_POSTHOG_KEY",
            "NEXT_PUBLIC_POSTHOG_HOST",
        ):
            if key not in text:
                findings.append(f"web/.env.local.example: missing {key}")
        for name, pattern in HOSTED_FALLBACK_PATTERNS:
            for match in pattern.finditer(text):
                if name == "production_supabase_url" and "your-project-ref" in match.group(0):
                    continue
                findings.append(
                    f"web/.env.local.example:{_line_number(text, match.start())}: "
                    f"{name} must be placeholder-only"
                )
    return findings


def check_web_dependency_pins() -> list[str]:
    findings: list[str] = []
    package = json.loads((ROOT / "web/package.json").read_text(encoding="utf-8"))
    deps = package.get("dependencies", {})
    for name in ("@supabase/ssr", "@supabase/supabase-js"):
        version = str(deps.get(name, ""))
        if not version or version.startswith(("^", "~", "*")):
            findings.append(f"web/package.json: {name} must be pinned exactly")
    return findings


def check_license_posture() -> list[str]:
    findings: list[str] = []
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
    archive_readme = (ROOT / "template-archive/README.md").read_text(
        encoding="utf-8"
    )
    if 'license = { text = "Proprietary" }' not in pyproject:
        findings.append("pyproject.toml: project license must remain Proprietary")
    if "Remaind is proprietary and all rights are reserved" not in readme:
        findings.append("README.md: missing proprietary license posture")
    if "All rights reserved" not in license_text:
        findings.append("LICENSE: missing all-rights-reserved language")
    if "License: MIT" in archive_readme:
        findings.append("template-archive/README.md: archived MIT badge must not appear")
    if "not part of the active Remaind package" not in archive_readme:
        findings.append("template-archive/README.md: missing archive boundary")
    return findings


def main() -> int:
    findings = [
        *check_docs_have_no_hardcoded_test_counts(),
        *check_web_has_no_hosted_fallbacks(),
        *check_web_dependency_pins(),
        *check_license_posture(),
    ]
    if findings:
        print("Product guardrail violations:", file=sys.stderr)
        for item in findings:
            print(f"  - {item}", file=sys.stderr)
        return 1
    print("product guardrails ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
