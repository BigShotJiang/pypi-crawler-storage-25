# Architecture

Sovereign Memory Starter is local continuity infrastructure for AI agents.

The product is split into four layers.

## 1. Memory Core

The memory core is Remaind's `.context/` ledger:

- append-only event log
- active state
- compact handover
- resume packet
- validation and rollback support

The raw event log is the source of truth. Derived files can be regenerated.

## 2. Startup Prompt Generator

The startup generator:

- reads the current Remaind resume packet
- wraps it in local operating rules
- writes `.context/active/startup_prompt.md`
- writes `MASTER_INITIAL_PROMPT.local.md` during install so external agent sessions can find the memory root

Any agent with filesystem access can use that file as its working memory.

The resume packet includes an adversarial review before raw evidence. Retrieved
memory and raw excerpts are treated as evidence, not instructions.
Model-generated compaction output is also scanned before acceptance; poisoned
handover/state candidates are rejected and the previous memory state is kept.

The beyond-context benchmark lives outside the user's normal `.context/` in
`.sovereign_bench/`. It creates its own Remaind ledger so product proofs do not
pollute daily working memory.

## 3. Model Runtime Adapter

The runtime adapter calls the local model for compaction and optional chat.

Executable today:

```text
ollama
```

Designed extension points:

```text
lm-studio
llama.cpp
vllm
openai-compatible-local
```

Model identity is configuration:

```text
SOVEREIGN_MODEL_PROFILE
SOVEREIGN_MODEL
SOVEREIGN_NUM_CTX
SOVEREIGN_OLLAMA_API
SOVEREIGN_CLEANUP_STYLE
```

This keeps the memory layer independent from Qwen, DeepSeek, GLM, Minimax, or
any other specific model family.

## 4. Agent Adapter

The agent adapter injects the startup prompt into a human-facing assistant
surface.

Executable today:

```text
qwen-code
console
```

Designed extension points:

```text
aider
continue
custom-cli
```

Qwen Code is the first fully wired adapter. The built-in console works without
Qwen Code and talks directly to the configured local model runtime.

## Authority Order

When sources conflict, use:

```text
latest user instruction -> events.jsonl -> state.json -> handover.md -> derived memories
```

## Privacy Model

Everything is local. There is no hosted memory service. The `.context/` folder
may contain sensitive work history, so do not share it casually.
