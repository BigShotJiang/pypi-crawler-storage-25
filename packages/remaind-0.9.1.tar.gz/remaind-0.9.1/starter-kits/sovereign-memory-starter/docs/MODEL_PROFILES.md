# Model Profiles

Model profiles are default settings for local models. They live in:

```text
profiles/model_profiles.json
```

The installer and `remaind setup` read the selected profile and write `.env`.
Runtime code then uses that configuration to call the local model and tune
Remaind thresholds.

## Built-In Profiles

```text
qwen-large   Qwen large local model
qwen-small   Qwen smaller local model
deepseek     DeepSeek reasoning model through Ollama
deepseek-v4-flash DeepSeek v4 flash local GGUF through llama.cpp server
glm          GLM local model through Ollama
minimax      Minimax-style local model placeholder
llama        Llama local model through Ollama
custom       User-provided local model
```

## Pick A Profile

```bash
remaind setup --profile deepseek
remaind setup --profile deepseek-v4-flash
```

DeepSeek profiles are also folder-aware. They default the agent workdir to:

```text
~/Documents/Remaind
```

Qwen profiles continue to use:

```text
~/Documents/Qwen-Code
```

Override the exact model name:

```bash
remaind setup --profile custom --model my-model:latest --num-ctx 65536
```

## Profile Fields

```json
{
  "runtime": "ollama",
  "model": "model-name:tag",
  "ollama_api": "auto",
  "openai_base_url": "http://127.0.0.1:18080/v1",
  "agent_workdir": "~/Documents/Remaind",
  "num_ctx": 32768,
  "cleanup_style": "thinking-tags",
  "system_prefix": "/no_think\n",
  "disable_thinking": true
}
```

`cleanup_style` controls how the runtime removes model scratch output before
Remaind validates compaction JSON. Reasoning models commonly use
`thinking-tags`; standard instruct models can use `none`.

`agent_workdir` is optional. When present, `install.sh` and `remaind setup`
use it as the profile-native folder unless the operator passes
`--agent-workdir`.
