# Operations

## Daily Start

```bash
remaind
```

With the default `qwen-code` adapter, this starts Qwen Code with local memory
attached. With the `deepseek-code` adapter, it refreshes memory, updates
`.deepcode/AGENTS.md` and `.deepcode/settings.json`, then launches the native
Deep Code terminal.

Manual equivalent:

```bash
cd ~/Documents/Qwen-Code
make memory
qwen --yolo --dangerously-skip-permissions
```

With the `console` adapter, `remaind` opens the built-in local model console.

Profile-native folders:

```text
Qwen profiles:     ~/Documents/Qwen-Code
DeepSeek profiles: ~/Documents/Remaind
```

The profile folder is where the starter writes the local `Makefile`,
`README-SOVEREIGN.md`, and prompt bridge for the configured agent adapter.
DeepSeek Code receives the live Remaind startup prompt through
`.deepcode/AGENTS.md` and the selected local runtime through
`.deepcode/settings.json`. Use `--agent-workdir` only when you want to override
the profile default.
Existing unmanaged files are preserved; in that case the bridge is written as a
`.sovereign` sidecar and the `remaind` launcher refreshes memory directly
from the memory root.

## Memory Packet Modes

`remaind launch` defaults to `turbo` memory mode for every configured model.
Turbo sends a compact packet for faster daily startup: 1 memory, 3 raw excerpts,
and a 1024 output-token budget. Use `--memory-mode standard` for balanced
packets or `--memory-mode deep` when a fuller memory packet matters more than
speed.

```bash
remaind launch --memory-mode turbo
remaind launch --memory-mode standard
remaind launch --memory-mode deep
```

The setting is model-agnostic. It is separate from DeepSeek runtime profiles:
Stable/Turbo/Nitro tune the DeepSeek server; Remaind memory mode tunes the
packet sent to whichever model is selected.

## Install Or Reinstall

Use the bootstrap path when you want the kit to handle a missing Python 3.11+
runtime:

```bash
./bootstrap.sh --profile qwen-large --agent qwen-code
```

Use the direct installer only when Python 3.11+ is already available:

```bash
./install.sh --profile qwen-large --agent qwen-code
```

To block network bootstrap downloads:

```bash
./bootstrap.sh --no-download --agent console
```

## Built-In Console

```bash
make chat
```

This tests the memory loop without any external agent shell. It loads the
startup prompt, chats through the configured local runtime, logs the session,
and refreshes memory when the session ends.

## Health Check

```bash
remaind doctor
make verify
```

This runs tests, validates `.context`, checks runtime/model readiness, builds a
resume packet, and refreshes the startup prompt.

To refresh configuration without reinstalling:

```bash
remaind setup
```

## Run A Huge Prompt From Terminal

For the guided path, use `remaind launch`. It activates memory, validates the
project, checks the configured runtime/model, then lets you paste text, load a
file, resume, or start an empty session:

```bash
remaind launch
remaind launch --path . --input file --file /absolute/path/to/huge-prompt.md
cat /absolute/path/to/huge-prompt.md | remaind launch --path . --input paste --task "solve this task"
```

Paste mode captures stdin or terminal paste into
`.context/artifacts/launch-pastes/` after readiness passes, then processes that
captured file through Remaind's normal large-prompt packet flow.

Use `remaind run` when a source prompt or report is too large for direct model
context or an agent file-reader limit:

```bash
remaind run /absolute/path/to/huge-prompt.md "solve this task"
```

The command keeps the source file on disk, initializes `.context/` for the
current project folder when needed, indexes the file, retrieves selected
evidence, writes `.context/active/run_packet.md`, calls the configured local
model, writes `.context/active/run_answer.md`, and records the task/result in
Remaind. Add `--no-model` to prepare the packet without generation.

## Continuity Proof

Run the built-in proof without any private archive:

```bash
make proof
```

This generates a synthetic long archive, indexes distant signals, and proves a
fresh process can recover the late signal from local memory.

For a model-backed proof:

```bash
make proof-model
```

## Adversarial Proof

```bash
make adversarial
remaind adversarial
```

This verifies prompt-injection detection, fake tool-result quarantine,
phase-2 poison archive detection, superseded-memory exclusion, adversarial
review placement in the resume packet, and poisoned compaction-output
rejection.

## Beyond-Context Benchmark

```bash
make bench
remaind bench
```

This generates a large local source archive and proves fresh-process retrieval,
single distant contradiction detection, revocation pressure handling,
superseded-memory exclusion, source links, and adversarial resume-gate
handling.

## 2M Terminal Proof

```bash
make proof-2m
remaind proof-2m
```

This is the live model A/B proof. It creates a fresh synthetic archive, asks
the configured local model to read the raw 2M-token prompt without memory, then
asks the same model from the compact sovereign resume packet.

Expected result:

```text
raw 2M prompt: rejected by the model context limit
clipped no-memory prompt: missing distant facts
sovereign memory prompt: final phrase, checksums, release codes, and adversarial warnings PASS
```

To skip the slow clipped-tail control:

```bash
make proof-2m PROOF_2M_ARGS="--skip-tail-control"
remaind proof-2m --skip-tail-control
```

## Model Battle Test

Fast deterministic check:

```bash
make model-test MODEL_TEST_ARGS="--skip-model --force"
```

Configured local model:

```bash
remaind model-test --force
```

Specific local models:

```bash
remaind model-test --models qwen3.6-35b-a3b-full:latest,gpt-oss-120b-fast:latest --force
```

All models reported by the configured runtime:

```bash
remaind model-test --installed --force
```

This checks whether models can consume verified Remaind evidence. It is smaller
than `proof-2m` and better for compatibility work across Qwen, DeepSeek, GPT
OSS-style local builds, and future model profiles.

## DeepSeek V4 Flash Through llama.cpp Server

Split GGUF DeepSeek v4 Flash builds should run through llama.cpp server instead
of the Ollama blob import path.

Start the server in one terminal:

```bash
remaind llama-server \
  --binary /path/to/llama-server \
  --model-path /path/to/DeepSeek-V4-Flash-IQ2_XXS-XL-00001-of-00002.gguf \
  --alias deepseek-v4-flash-local \
  --port 18080
```

Then configure and test Remaind in another terminal:

```bash
remaind setup --profile deepseek-v4-flash
remaind doctor --smoke
remaind model-test --force
```

The `deepseek` and `deepseek-v4-flash` profiles default the agent work folder
to `~/Documents/Remaind` and the agent adapter to `deepseek-code`. Check the
effective value with:

```bash
remaind profiles
remaind doctor
```

## Change Model

Use `remaind setup` for normal changes:

```bash
remaind setup --profile deepseek
remaind setup --profile deepseek-v4-flash
remaind setup --profile glm
remaind setup --profile llama
```

You can also reinstall with a different profile:

```bash
./install.sh --profile deepseek
./install.sh --profile deepseek-v4-flash
./install.sh --profile glm
./install.sh --profile llama
```

For a custom local model:

```bash
remaind setup --profile custom --model my-local-model:latest --num-ctx 65536
./install.sh --profile custom --model my-local-model:latest --num-ctx 65536
```

Then run:

```bash
make tune
make verify
remaind doctor --smoke
```

## Change Agent Adapter

Qwen Code adapter:

```bash
./install.sh --agent qwen-code --agent-workdir ~/Documents/Qwen-Code
```

DeepSeek Code adapter:

```bash
./install.sh --profile deepseek-v4-flash --agent deepseek-code --agent-cli deepcode
```

This uses `~/Documents/Remaind` unless `--agent-workdir` is supplied. The
manual equivalent after setup is:

```bash
cd ~/Documents/Remaind
make memory
deepcode
```

Built-in console only:

```bash
./install.sh --agent console
```

## Important Memory Actions

Log meaningful events:

```bash
make log type=decision actor=assistant summary="Chose local runtime" content="Use Ollama as the first supported runtime adapter."
```

Compact memory:

```bash
make compact
```

Refresh startup prompt:

```bash
make startup
```

## Files To Protect

Do not share these unless you intend to share memory history:

```text
.context/
.env
MASTER_INITIAL_PROMPT.local.md
.sovereign_bench/
.sovereign_2m_proof/
```

Safe-to-share product files are the starter kit source files before install.
