#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

MEMORY_ROOT="${SOVEREIGN_MEMORY_ROOT:-$KIT_ROOT}"
MODEL_PROFILE="${SOVEREIGN_MODEL_PROFILE:-qwen-large}"
RUNTIME="${SOVEREIGN_RUNTIME:-ollama}"
AGENT="${SOVEREIGN_AGENT:-qwen-code}"
AGENT_CLI="${SOVEREIGN_AGENT_CLI:-qwen}"
AGENT_WORKDIR="${SOVEREIGN_AGENT_WORKDIR:-${QWEN_WORKDIR:-$HOME/Documents/Qwen-Code}}"
INSTALL_BIN="${INSTALL_BIN:-$HOME/bin}"
MODEL="${SOVEREIGN_MODEL:-}"
NUM_CTX="${SOVEREIGN_NUM_CTX:-${QWEN_NUM_CTX:-}}"
OLLAMA_HOST="${OLLAMA_HOST:-http://localhost:11434}"
OPENAI_BASE_URL="${SOVEREIGN_OPENAI_BASE_URL:-${REMAIND_OPENAI_BASE_URL:-}}"
SKIP_SHELL_RC=0
MODEL_EXPLICIT=0
NUM_CTX_EXPLICIT=0
RUNTIME_EXPLICIT=0
AGENT_WORKDIR_EXPLICIT=0
AGENT_EXPLICIT=0
AGENT_CLI_EXPLICIT=0
OPENAI_BASE_URL_EXPLICIT=0

usage() {
  cat <<'EOF'
Usage: ./install.sh [options]

Core options:
  --memory-root PATH       Memory system root. Default: this folder.
  --profile NAME           Model profile. Default: qwen-large.
                           Built-ins: qwen-large, qwen-small, deepseek,
                           deepseek-v4-flash, glm, minimax, llama, custom.
  --runtime NAME           Model runtime adapter. Default: ollama.
  --model NAME             Override model name from the profile.
  --num-ctx TOKENS         Override context window from the profile.
  --ollama-host URL        Ollama host. Default: http://localhost:11434.
  --openai-base-url URL    OpenAI-compatible local /v1 endpoint.

Agent options:
  --agent NAME             Agent adapter. Default: qwen-code. Also supports:
                           deepseek-code, console.
  --agent-cli NAME         Agent CLI command. Default: qwen.
  --agent-workdir PATH     Agent project folder. Default: selected profile folder,
                           otherwise ~/Documents/Qwen-Code.
  --qwen-workdir PATH      Alias for --agent-workdir.
  --install-bin PATH       Folder for launcher wrappers. Default: ~/bin.

Other:
  --skip-shell-rc          Do not edit ~/.zshrc or ~/.bashrc.
  -h, --help               Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --memory-root)
      MEMORY_ROOT="$2"; shift 2 ;;
    --profile|--model-profile)
      MODEL_PROFILE="$2"; shift 2 ;;
    --runtime)
      RUNTIME="$2"; RUNTIME_EXPLICIT=1; shift 2 ;;
    --model)
      MODEL="$2"; MODEL_EXPLICIT=1; shift 2 ;;
    --num-ctx)
      NUM_CTX="$2"; NUM_CTX_EXPLICIT=1; shift 2 ;;
    --ollama-host)
      OLLAMA_HOST="$2"; shift 2 ;;
    --openai-base-url)
      OPENAI_BASE_URL="$2"; OPENAI_BASE_URL_EXPLICIT=1; shift 2 ;;
    --agent)
      AGENT="$2"; AGENT_EXPLICIT=1; shift 2 ;;
    --agent-cli)
      AGENT_CLI="$2"; AGENT_CLI_EXPLICIT=1; shift 2 ;;
    --agent-workdir|--qwen-workdir)
      AGENT_WORKDIR="$2"; AGENT_WORKDIR_EXPLICIT=1; shift 2 ;;
    --install-bin)
      INSTALL_BIN="$2"; shift 2 ;;
    --skip-shell-rc)
      SKIP_SHELL_RC=1; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2
      usage
      exit 2 ;;
  esac
done

expand_path() {
  local input="$1"
  if [[ "$input" == "~" ]]; then
    printf '%s\n' "$HOME"
  elif [[ "$input" == "~/"* ]]; then
    printf '%s/%s\n' "$HOME" "${input#\~/}"
  else
    printf '%s\n' "$input"
  fi
}

MEMORY_ROOT="$(expand_path "$MEMORY_ROOT")"
AGENT_WORKDIR="$(expand_path "$AGENT_WORKDIR")"
INSTALL_BIN="$(expand_path "$INSTALL_BIN")"
PYTHON_BIN="${PYTHON_BIN:-}"

if [[ -z "$PYTHON_BIN" ]]; then
  if command -v python3.11 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3.11)"
  elif command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v python3)"
  else
    echo "Python 3.11+ is required." >&2
    exit 1
  fi
fi

"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 11):
    raise SystemExit("Python 3.11+ is required.")
PY

profile_reader='
import json, os
from pathlib import Path
profile = os.environ["MODEL_PROFILE"]
path = Path(os.environ["KIT_ROOT"]) / "profiles" / "model_profiles.json"
payload = json.loads(path.read_text())
profiles = payload.get("profiles", {})
data = profiles.get(profile)
if data is None:
    raise SystemExit(f"Unknown model profile: {profile}")
print(data.get("model", ""))
print(data.get("num_ctx", ""))
print(data.get("runtime", ""))
print(data.get("openai_base_url", ""))
print(data.get("agent_workdir", ""))
print(data.get("agent", ""))
print(data.get("agent_cli", ""))
'
profile_values="$(
  KIT_ROOT="$KIT_ROOT" MODEL_PROFILE="$MODEL_PROFILE" "$PYTHON_BIN" -c "$profile_reader"
)"
PROFILE_MODEL="$(printf '%s\n' "$profile_values" | sed -n '1p')"
PROFILE_NUM_CTX="$(printf '%s\n' "$profile_values" | sed -n '2p')"
PROFILE_RUNTIME="$(printf '%s\n' "$profile_values" | sed -n '3p')"
PROFILE_OPENAI_BASE_URL="$(printf '%s\n' "$profile_values" | sed -n '4p')"
PROFILE_AGENT_WORKDIR="$(printf '%s\n' "$profile_values" | sed -n '5p')"
PROFILE_AGENT="$(printf '%s\n' "$profile_values" | sed -n '6p')"
PROFILE_AGENT_CLI="$(printf '%s\n' "$profile_values" | sed -n '7p')"
if [[ "$MODEL_EXPLICIT" != "1" && -z "$MODEL" ]]; then
  MODEL="$PROFILE_MODEL"
fi
if [[ "$NUM_CTX_EXPLICIT" != "1" && -z "$NUM_CTX" ]]; then
  NUM_CTX="$PROFILE_NUM_CTX"
fi
if [[ "$RUNTIME_EXPLICIT" != "1" && -n "$PROFILE_RUNTIME" ]]; then
  RUNTIME="$PROFILE_RUNTIME"
fi
if [[ "$OPENAI_BASE_URL_EXPLICIT" != "1" && -z "$OPENAI_BASE_URL" && -n "$PROFILE_OPENAI_BASE_URL" ]]; then
  OPENAI_BASE_URL="$PROFILE_OPENAI_BASE_URL"
fi
if [[ "$AGENT_WORKDIR_EXPLICIT" != "1" && -n "$PROFILE_AGENT_WORKDIR" ]]; then
  AGENT_WORKDIR="$(expand_path "$PROFILE_AGENT_WORKDIR")"
fi
if [[ "$AGENT_EXPLICIT" != "1" && -n "$PROFILE_AGENT" ]]; then
  AGENT="$PROFILE_AGENT"
fi
if [[ "$AGENT_CLI_EXPLICIT" != "1" && -n "$PROFILE_AGENT_CLI" ]]; then
  AGENT_CLI="$PROFILE_AGENT_CLI"
fi

if [[ "$AGENT" == "qwen-code" ]] && ! command -v "$AGENT_CLI" >/dev/null 2>&1; then
  echo "Warning: $AGENT_CLI command not found yet. Install Qwen Code before using the Qwen Code adapter." >&2
fi
if [[ "$AGENT" == "deepseek-code" ]] && ! command -v "$AGENT_CLI" >/dev/null 2>&1; then
  echo "Warning: $AGENT_CLI command not found yet. Install Deep Code before using the DeepSeek Code adapter." >&2
fi

mkdir -p "$MEMORY_ROOT" "$INSTALL_BIN"
mkdir -p "$AGENT_WORKDIR"

KIT_ROOT_RESOLVED="$(cd "$KIT_ROOT" && pwd)"
MEMORY_ROOT_RESOLVED="$(cd "$MEMORY_ROOT" && pwd)"
if [[ "$MEMORY_ROOT_RESOLVED" != "$KIT_ROOT_RESOLVED" ]]; then
  echo "Copying starter kit files into memory root..."
  for item in \
    requirements.txt \
    .env.example \
    MASTER_INITIAL_PROMPT.md \
    Makefile \
    bootstrap.sh \
    install.sh \
    uninstall.sh \
    scripts \
    sovereign_memory \
    profiles \
    docs \
    tests \
    wheels
  do
    if [[ -e "$KIT_ROOT/$item" ]]; then
      rm -rf "$MEMORY_ROOT/$item"
      cp -pR "$KIT_ROOT/$item" "$MEMORY_ROOT/$item"
    fi
  done
fi

cd "$MEMORY_ROOT"

echo "Creating Python environment..."
"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
shopt -s nullglob
LOCAL_REMAIND_WHEELS=(wheels/remaind-*.whl)
shopt -u nullglob
if [[ ${#LOCAL_REMAIND_WHEELS[@]} -gt 0 ]]; then
  .venv/bin/python -m pip install "${LOCAL_REMAIND_WHEELS[0]}"
else
  .venv/bin/python -m pip install -r requirements.txt
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
fi

env_writer='
from pathlib import Path
import os

path = Path(".env")
values = {}
if path.exists():
    for line in path.read_text().splitlines():
        if "=" in line and not line.strip().startswith("#"):
            key, value = line.split("=", 1)
            values[key] = value
updates = {
    "SOVEREIGN_MEMORY_ROOT": os.environ["MEMORY_ROOT"],
    "SOVEREIGN_CONTEXT_ROOT": os.environ["MEMORY_ROOT"],
    "SOVEREIGN_MODEL_PROFILE": os.environ["MODEL_PROFILE"],
    "SOVEREIGN_RUNTIME": os.environ["RUNTIME"],
    "SOVEREIGN_AGENT": os.environ["AGENT"],
    "SOVEREIGN_AGENT_CLI": os.environ["AGENT_CLI"],
    "SOVEREIGN_AGENT_WORKDIR": os.environ["AGENT_WORKDIR"],
    "INSTALL_BIN": os.environ["INSTALL_BIN"],
    "OLLAMA_HOST": os.environ["OLLAMA_HOST"],
    "REMAIND_OLLAMA_MODEL": os.environ["MODEL"],
    "SOVEREIGN_OPENAI_BASE_URL": os.environ["OPENAI_BASE_URL"],
    "REMAIND_OPENAI_BASE_URL": os.environ["OPENAI_BASE_URL"],
    "REMAIND_OPENAI_MODEL": os.environ["MODEL"],
}
if os.environ.get("MODEL_EXPLICIT") == "1":
    updates["SOVEREIGN_MODEL"] = os.environ["MODEL"]
if os.environ.get("NUM_CTX_EXPLICIT") == "1":
    updates["SOVEREIGN_NUM_CTX"] = os.environ["NUM_CTX"]
values.update(updates)
template = Path(".env.example").read_text().splitlines()
keys = []
out = []
for line in template:
    if "=" in line and not line.strip().startswith("#"):
        key = line.split("=", 1)[0]
        default = line.split("=", 1)[1]
        keys.append(key)
        out.append(f"{key}={values.get(key, default)}")
    else:
        out.append(line)
for key, value in values.items():
    if key not in keys:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
'
MEMORY_ROOT="$MEMORY_ROOT" MODEL_PROFILE="$MODEL_PROFILE" RUNTIME="$RUNTIME" \
  AGENT="$AGENT" AGENT_CLI="$AGENT_CLI" AGENT_WORKDIR="$AGENT_WORKDIR" \
  INSTALL_BIN="$INSTALL_BIN" OLLAMA_HOST="$OLLAMA_HOST" OPENAI_BASE_URL="$OPENAI_BASE_URL" \
  MODEL="$MODEL" NUM_CTX="$NUM_CTX" \
  MODEL_EXPLICIT="$MODEL_EXPLICIT" NUM_CTX_EXPLICIT="$NUM_CTX_EXPLICIT" \
  .venv/bin/python -c "$env_writer"

.venv/bin/python - <<'PY'
from pathlib import Path
from sovereign_memory.runtime import SovereignConfig

config = SovereignConfig.from_env()
template = Path("MASTER_INITIAL_PROMPT.md")
path = Path("MASTER_INITIAL_PROMPT.local.md")
text = template.read_text(encoding="utf-8")
text = text.replace("{{SOVEREIGN_MEMORY_ROOT}}", str(config.base))
path.write_text(text, encoding="utf-8")
PY

CONTEXT_CREATED=0
if [[ ! -d .context ]]; then
  echo "Initializing Remaind context..."
  .venv/bin/remaind init
  CONTEXT_CREATED=1
else
  echo "Existing .context found; keeping it."
fi

if [[ "$CONTEXT_CREATED" == "1" ]]; then
  echo "Bootstrapping memory state..."
  .venv/bin/python scripts/sovereign.py bootstrap
else
  echo "Refreshing existing memory configuration..."
  .venv/bin/python scripts/sovereign.py tune-thresholds
  .venv/bin/python scripts/sovereign.py startup
fi

detect_real_agent() {
  local cli="$1"
  local wrapper="$2"
  local path_part candidate
  IFS=':' read -r -a path_parts <<< "${PATH:-}"
  for path_part in "${path_parts[@]}"; do
    candidate="$path_part/$cli"
    if [[ -x "$candidate" && "$candidate" != "$wrapper" ]]; then
      if grep -q 'sovereign-memory-starter managed launcher' "$candidate" 2>/dev/null; then
        continue
      fi
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  for candidate in /opt/homebrew/bin/"$cli" /usr/local/bin/"$cli" /usr/bin/"$cli"; do
    if [[ -x "$candidate" && "$candidate" != "$wrapper" ]]; then
      if grep -q 'sovereign-memory-starter managed launcher' "$candidate" 2>/dev/null; then
        continue
      fi
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

is_managed_launcher() {
  local target="$1"
  [[ -f "$target" ]] || return 1
  grep -q 'sovereign-memory-starter managed launcher' "$target" 2>/dev/null && return 0
  grep -q 'MASTER_INITIAL_PROMPT.local.md' "$target" 2>/dev/null && return 0
  grep -q 'scripts/sovereign.py chat' "$target" 2>/dev/null && return 0
  [[ "$(basename "$target")" == "qwen-start" ]] && grep -q 'sovereign' "$target" 2>/dev/null && return 0
  return 1
}

ensure_safe_launcher_target() {
  local target="$1"
  local label="$2"
  if [[ -e "$target" ]] && ! is_managed_launcher "$target"; then
    echo "Refusing to overwrite existing $label: $target" >&2
    echo "Choose a different --install-bin path or move that file first." >&2
    exit 1
  fi
}

managed_agent_bridge_target() {
  local target="$1"
  local label="$2"
  if [[ -e "$target" ]] && ! grep -Eq 'sovereign-memory-starter managed agent bridge|SOVEREIGN_MEMORY_ROOT' "$target" 2>/dev/null; then
    echo "Warning: preserving existing $label: $target" >&2
    echo "Writing sovereign bridge sidecar: $target.sovereign" >&2
    printf '%s\n' "$target.sovereign"
    return 0
  fi
  printf '%s\n' "$target"
}

agent_wrapper_name() {
  if [[ "$AGENT" == "qwen-code" ]]; then
    printf 'qwen\n'
  else
    printf '%s\n' "$AGENT_CLI"
  fi
}

echo "Installing launcher wrappers..."
ensure_safe_launcher_target "$INSTALL_BIN/remaind" "remaind launcher"
ensure_safe_launcher_target "$INSTALL_BIN/sovereign" "sovereign launcher"
ensure_safe_launcher_target "$INSTALL_BIN/qwen-start" "qwen-start launcher"

if [[ "$AGENT" == "qwen-code" ]]; then
  AGENT_WRAPPER="$INSTALL_BIN/$(agent_wrapper_name)"
  ensure_safe_launcher_target "$AGENT_WRAPPER" "agent wrapper"
  REAL_AGENT="$(detect_real_agent "$AGENT_CLI" "$AGENT_WRAPPER" || true)"
  cat > "$AGENT_WRAPPER" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail

REAL_AGENT="$REAL_AGENT"
AGENT_CLI="$AGENT_CLI"
AGENT_WORKDIR="$AGENT_WORKDIR"
MEMORY_ROOT="$MEMORY_ROOT"
MASTER_PROMPT="\$MEMORY_ROOT/MASTER_INITIAL_PROMPT.local.md"

resolve_real_agent() {
  local path_part candidate
  IFS=':' read -r -a path_parts <<< "\${PATH:-}"
  for path_part in "\${path_parts[@]}"; do
    candidate="\$path_part/\$AGENT_CLI"
    if [[ -x "\$candidate" && "\$candidate" != "\$0" ]]; then
      if grep -q 'sovereign-memory-starter managed launcher' "\$candidate" 2>/dev/null; then
        continue
      fi
      printf '%s\n' "\$candidate"
      return 0
    fi
  done
  for candidate in /opt/homebrew/bin/"\$AGENT_CLI" /usr/local/bin/"\$AGENT_CLI" /usr/bin/"\$AGENT_CLI"; do
    if [[ -x "\$candidate" && "\$candidate" != "\$0" ]]; then
      if grep -q 'sovereign-memory-starter managed launcher' "\$candidate" 2>/dev/null; then
        continue
      fi
      printf '%s\n' "\$candidate"
      return 0
    fi
  done
  return 1
}

if [[ -z "\$REAL_AGENT" || ! -x "\$REAL_AGENT" ]]; then
  REAL_AGENT="\$(resolve_real_agent || true)"
fi

if [[ -z "\$REAL_AGENT" ]]; then
  echo "Missing agent CLI: \$AGENT_CLI. Install Qwen Code or set SOVEREIGN_AGENT_CLI to the real command." >&2
  exit 127
fi

args=()
for arg in "\$@"; do
  case "\$arg" in
    --dangerously-skip-permissions)
      ;;
    *)
      args+=("\$arg")
      ;;
  esac
done

if [[ "\${SOVEREIGN_MEMORY_ATTACHED:-0}" != "1" && ( "\$PWD" == "\$AGENT_WORKDIR" || "\$PWD" == "\$AGENT_WORKDIR"/* ) ]]; then
  if [[ -d "\$MEMORY_ROOT" && -f "\$MASTER_PROMPT" ]]; then
    (cd "\$MEMORY_ROOT" && .venv/bin/python scripts/sovereign.py startup >/dev/null) || true
    exec "\$REAL_AGENT" \\
      --include-directories "\$MEMORY_ROOT" \\
      --append-system-prompt "\$(cat "\$MASTER_PROMPT")" \\
      "\${args[@]}"
  fi
fi

exec "\$REAL_AGENT" "\${args[@]}"
EOF
  chmod +x "$AGENT_WRAPPER"

  cat > "$INSTALL_BIN/remaind" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail

MEMORY_ROOT="$MEMORY_ROOT"
MASTER_PROMPT="\$MEMORY_ROOT/MASTER_INITIAL_PROMPT.local.md"
AGENT_WORKDIR="$AGENT_WORKDIR"
INSTALL_BIN="$INSTALL_BIN"
CALLER_PWD="\${PWD:-}"
RUNTIME="$RUNTIME"
MODEL="$MODEL"
NUM_CTX="$NUM_CTX"
OLLAMA_HOST_VALUE="$OLLAMA_HOST"
OPENAI_BASE_URL_VALUE="$OPENAI_BASE_URL"

configure_remaind_runtime() {
  export OLLAMA_HOST="\$OLLAMA_HOST_VALUE"
  if [[ -n "\$NUM_CTX" ]]; then
    export REMAIND_OLLAMA_NUM_CTX="\$NUM_CTX"
  fi
  if [[ "\$RUNTIME" == "ollama" ]]; then
    export REMAIND_OLLAMA_MODEL="\$MODEL"
    export REMAIND_OLLAMA_API="${REMAIND_OLLAMA_API:-auto}"
  else
    export REMAIND_OPENAI_MODEL="\$MODEL"
    if [[ -n "\$OPENAI_BASE_URL_VALUE" ]]; then
      export REMAIND_OPENAI_BASE_URL="\$OPENAI_BASE_URL_VALUE"
    fi
  fi
}

core_remaind() {
  configure_remaind_runtime
  cd "\$CALLER_PWD"
  exec "\$MEMORY_ROOT/.venv/bin/remaind" "\$@"
}

if [[ ! -d "\$MEMORY_ROOT" ]]; then
  echo "Missing Remaind memory root: \$MEMORY_ROOT" >&2
  exit 1
fi

case "\${1:-}" in
  -h|--help)
    cd "\$MEMORY_ROOT"
    exec .venv/bin/python scripts/sovereign.py --help
    ;;
  --version)
    exec "\$MEMORY_ROOT/.venv/bin/remaind" --version
    ;;
  core)
    shift
    core_remaind "\$@"
    ;;
  init|rollback|large-doc|run|context)
    core_remaind "\$@"
    ;;
  launch)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    REMAIND_CALLER_PWD="\$CALLER_PWD" exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  setup|doctor|monitor|status|validate|resume|startup|profiles|compact|bench|proof-2m|model-test|ask|chat|log|bootstrap|tune-thresholds)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  verify|proof|proof-model|adversarial|test)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    exec make "\$command" "\$@"
    ;;
esac

configured_agent="\$(awk -F= '\$1 == "SOVEREIGN_AGENT" {print \$2; exit}' "\$MEMORY_ROOT/.env" 2>/dev/null)"
if [[ "\$configured_agent" == "console" ]]; then
  cd "\$MEMORY_ROOT"
  exec .venv/bin/python scripts/sovereign.py chat "\$@"
fi

if [[ ! -f "\$MASTER_PROMPT" ]]; then
  echo "Missing master prompt: \$MASTER_PROMPT" >&2
  exit 1
fi

cd "\$AGENT_WORKDIR"
export PATH="\$INSTALL_BIN:\$PATH"

echo "Loading sovereign memory from agent workdir..."
(cd "\$MEMORY_ROOT" && .venv/bin/python scripts/sovereign.py startup >/dev/null)

echo "Starting Qwen Code with sovereign memory."
SOVEREIGN_MEMORY_ATTACHED=1 exec "$AGENT_CLI" \\
  --include-directories "\$MEMORY_ROOT" \\
  --append-system-prompt "\$(cat "\$MASTER_PROMPT")" \\
  --yolo \\
  --dangerously-skip-permissions \\
  "\$@"
EOF
  chmod +x "$INSTALL_BIN/remaind"

  AGENT_MAKEFILE="$(managed_agent_bridge_target "$AGENT_WORKDIR/Makefile" "agent Makefile")"
  AGENT_README="$(managed_agent_bridge_target "$AGENT_WORKDIR/README-SOVEREIGN.md" "agent README")"

  cat > "$AGENT_MAKEFILE" <<EOF
# sovereign-memory-starter managed agent bridge
SOVEREIGN_MEMORY_ROOT ?= $MEMORY_ROOT
SOVEREIGN_ENGINE_ROOT ?= $MEMORY_ROOT
SOVEREIGN_PY := \$(SOVEREIGN_ENGINE_ROOT)/.venv/bin/python
SOVEREIGN_CLI := \$(SOVEREIGN_ENGINE_ROOT)/scripts/sovereign.py

.PHONY: start remaind sovereign setup memory doctor verify adversarial bench proof-2m prompt

start remaind sovereign:
	"$INSTALL_BIN/remaind"

setup:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" setup

memory:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" startup

doctor:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" doctor

verify:
	"\$(SOVEREIGN_PY)" -m unittest discover -s "\$(SOVEREIGN_ENGINE_ROOT)/tests" -v
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" validate
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" doctor
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" resume
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" startup
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_ENGINE_ROOT)/scripts/adversarial_proof.py"

adversarial:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_ENGINE_ROOT)/scripts/adversarial_proof.py"

bench:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" bench --force

proof-2m:
	"\$(SOVEREIGN_PY)" "\$(SOVEREIGN_CLI)" proof-2m

prompt:
	@cat "\$(SOVEREIGN_MEMORY_ROOT)/MASTER_INITIAL_PROMPT.local.md"
EOF

  cat > "$AGENT_README" <<EOF
# Sovereign Memory Boot

<!-- sovereign-memory-starter managed agent bridge -->

Start the configured agent with local sovereign memory attached:

\`\`\`bash
remaind
\`\`\`

Manual equivalent:

\`\`\`bash
cd "$AGENT_WORKDIR"
make memory
qwen --yolo --dangerously-skip-permissions
\`\`\`

Memory root:

\`\`\`text
$MEMORY_ROOT
\`\`\`

Connector prompt:

\`\`\`text
$MEMORY_ROOT/MASTER_INITIAL_PROMPT.local.md
\`\`\`
EOF
elif [[ "$AGENT" == "deepseek-code" ]]; then
  cat > "$INSTALL_BIN/remaind" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail

MEMORY_ROOT="$MEMORY_ROOT"
AGENT_WORKDIR="$AGENT_WORKDIR"
AGENT_CLI="$AGENT_CLI"
INSTALL_BIN="$INSTALL_BIN"
CALLER_PWD="\${PWD:-}"
RUNTIME="$RUNTIME"
MODEL="$MODEL"
NUM_CTX="$NUM_CTX"
OLLAMA_HOST_VALUE="$OLLAMA_HOST"
OPENAI_BASE_URL_VALUE="$OPENAI_BASE_URL"

configure_remaind_runtime() {
  export OLLAMA_HOST="\$OLLAMA_HOST_VALUE"
  if [[ -n "\$NUM_CTX" ]]; then
    export REMAIND_OLLAMA_NUM_CTX="\$NUM_CTX"
  fi
  if [[ "\$RUNTIME" == "ollama" ]]; then
    export REMAIND_OLLAMA_MODEL="\$MODEL"
    export REMAIND_OLLAMA_API="${REMAIND_OLLAMA_API:-auto}"
  else
    export REMAIND_OPENAI_MODEL="\$MODEL"
    if [[ -n "\$OPENAI_BASE_URL_VALUE" ]]; then
      export REMAIND_OPENAI_BASE_URL="\$OPENAI_BASE_URL_VALUE"
    fi
  fi
}

core_remaind() {
  configure_remaind_runtime
  cd "\$CALLER_PWD"
  exec "\$MEMORY_ROOT/.venv/bin/remaind" "\$@"
}

if [[ ! -d "\$MEMORY_ROOT" ]]; then
  echo "Missing Remaind memory root: \$MEMORY_ROOT" >&2
  exit 1
fi

case "\${1:-}" in
  -h|--help)
    cd "\$MEMORY_ROOT"
    exec .venv/bin/python scripts/sovereign.py --help
    ;;
  --version)
    exec "\$MEMORY_ROOT/.venv/bin/remaind" --version
    ;;
  core)
    shift
    core_remaind "\$@"
    ;;
  init|rollback|large-doc|run|context)
    core_remaind "\$@"
    ;;
  launch)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    REMAIND_CALLER_PWD="\$CALLER_PWD" exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  setup|doctor|monitor|status|validate|resume|startup|profiles|compact|bench|proof-2m|model-test|ask|chat|log|bootstrap|tune-thresholds)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  verify|proof|proof-model|adversarial|test)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    exec make "\$command" "\$@"
    ;;
esac

configured_agent="\$(awk -F= '\$1 == "SOVEREIGN_AGENT" {print \$2; exit}' "\$MEMORY_ROOT/.env" 2>/dev/null)"
if [[ "\$configured_agent" == "console" ]]; then
  cd "\$MEMORY_ROOT"
  exec .venv/bin/python scripts/sovereign.py chat "\$@"
fi

if ! command -v "\$AGENT_CLI" >/dev/null 2>&1; then
  echo "Missing DeepSeek Code CLI: \$AGENT_CLI" >&2
  echo "Expected launch surface: cd \"\$AGENT_WORKDIR\" && \$AGENT_CLI" >&2
  exit 127
fi

cd "\$AGENT_WORKDIR"
export PATH="\$INSTALL_BIN:\$PATH"

echo "Loading Remaind memory into DeepSeek Code..."
(cd "\$MEMORY_ROOT" && .venv/bin/python scripts/sovereign.py startup >/dev/null)

if [[ ! -f "\$AGENT_WORKDIR/.deepcode/AGENTS.md" ]]; then
  echo "Missing DeepSeek memory bridge: \$AGENT_WORKDIR/.deepcode/AGENTS.md" >&2
  exit 1
fi
if [[ ! -f "\$AGENT_WORKDIR/.deepcode/settings.json" ]]; then
  echo "Missing DeepSeek runtime bridge: \$AGENT_WORKDIR/.deepcode/settings.json" >&2
  exit 1
fi
if [[ ! -f "\$AGENT_WORKDIR/.agents/skills/remaind-large-doc/SKILL.md" ]]; then
  echo "Missing DeepSeek large-document guard: \$AGENT_WORKDIR/.agents/skills/remaind-large-doc/SKILL.md" >&2
  exit 1
fi

echo "Starting DeepSeek Code with Remaind memory."
SOVEREIGN_MEMORY_ATTACHED=1 exec "\$AGENT_CLI" "\$@"
EOF
  chmod +x "$INSTALL_BIN/remaind"
else
  cat > "$INSTALL_BIN/remaind" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail
MEMORY_ROOT="$MEMORY_ROOT"
CALLER_PWD="\${PWD:-}"
RUNTIME="$RUNTIME"
MODEL="$MODEL"
NUM_CTX="$NUM_CTX"
OLLAMA_HOST_VALUE="$OLLAMA_HOST"
OPENAI_BASE_URL_VALUE="$OPENAI_BASE_URL"

configure_remaind_runtime() {
  export OLLAMA_HOST="\$OLLAMA_HOST_VALUE"
  if [[ -n "\$NUM_CTX" ]]; then
    export REMAIND_OLLAMA_NUM_CTX="\$NUM_CTX"
  fi
  if [[ "\$RUNTIME" == "ollama" ]]; then
    export REMAIND_OLLAMA_MODEL="\$MODEL"
    export REMAIND_OLLAMA_API="${REMAIND_OLLAMA_API:-auto}"
  else
    export REMAIND_OPENAI_MODEL="\$MODEL"
    if [[ -n "\$OPENAI_BASE_URL_VALUE" ]]; then
      export REMAIND_OPENAI_BASE_URL="\$OPENAI_BASE_URL_VALUE"
    fi
  fi
}

core_remaind() {
  configure_remaind_runtime
  cd "\$CALLER_PWD"
  exec "\$MEMORY_ROOT/.venv/bin/remaind" "\$@"
}

cd "\$MEMORY_ROOT"
case "\${1:-}" in
  -h|--help)
    exec .venv/bin/python scripts/sovereign.py --help
    ;;
  --version)
    exec .venv/bin/remaind --version
    ;;
  core)
    shift
    core_remaind "\$@"
    ;;
  init|rollback|large-doc|run|context)
    core_remaind "\$@"
    ;;
  launch)
    command="\$1"
    shift
    cd "\$MEMORY_ROOT"
    REMAIND_CALLER_PWD="\$CALLER_PWD" exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  setup|doctor|monitor|status|validate|resume|startup|profiles|compact|bench|proof-2m|model-test|ask|chat|log|bootstrap|tune-thresholds)
    command="\$1"
    shift
    exec .venv/bin/python scripts/sovereign.py "\$command" "\$@"
    ;;
  verify|proof|proof-model|adversarial|test)
    command="\$1"
    shift
    exec make "\$command" "\$@"
    ;;
esac
exec .venv/bin/python scripts/sovereign.py chat "\$@"
EOF
  chmod +x "$INSTALL_BIN/remaind"
fi

cat > "$INSTALL_BIN/sovereign" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail
exec "$INSTALL_BIN/remaind" "\$@"
EOF
chmod +x "$INSTALL_BIN/sovereign"

cat > "$INSTALL_BIN/qwen-start" <<EOF
#!/usr/bin/env bash
# sovereign-memory-starter managed launcher
set -euo pipefail
exec "$INSTALL_BIN/remaind" "\$@"
EOF
chmod +x "$INSTALL_BIN/qwen-start"

if [[ "$SKIP_SHELL_RC" != "1" ]]; then
  SHELL_NAME="$(basename "${SHELL:-}")"
  if [[ "$SHELL_NAME" == "zsh" ]]; then
    RC_FILE="$HOME/.zshrc"
  else
    RC_FILE="$HOME/.bashrc"
  fi
  touch "$RC_FILE"
  if ! grep -q 'sovereign-memory-starter' "$RC_FILE"; then
    {
      echo ""
      echo "# sovereign-memory-starter"
      echo "export PATH=\"$INSTALL_BIN:\$PATH\""
    } >> "$RC_FILE"
  fi
fi

echo ""
echo "Readiness check:"
.venv/bin/python scripts/sovereign.py doctor

echo ""
echo "Install complete."
echo ""
echo "Profile: $MODEL_PROFILE"
echo "Runtime: $RUNTIME"
echo "Model:   $MODEL"
echo "Agent:   $AGENT"
echo "Folder:  $AGENT_WORKDIR"
echo ""
echo "Daily start:"
echo "  remaind"
echo ""
if [[ "$AGENT" == "qwen-code" ]]; then
  echo "Manual start:"
  echo "  cd \"$AGENT_WORKDIR\""
  echo "  make memory"
  echo "  qwen --yolo --dangerously-skip-permissions"
elif [[ "$AGENT" == "deepseek-code" ]]; then
  echo "Manual start:"
  echo "  cd \"$AGENT_WORKDIR\""
  echo "  make memory"
  echo "  $AGENT_CLI"
fi
echo ""
echo "Compatibility alias:"
echo "  sovereign"
echo ""
echo "If your shell cannot find remaind yet, open a new terminal or run:"
echo "  export PATH=\"$INSTALL_BIN:\$PATH\""
