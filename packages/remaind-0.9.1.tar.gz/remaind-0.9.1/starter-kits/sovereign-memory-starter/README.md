# Sovereign Memory Starter

Sovereign Memory Starter is 100% local memory for AI agents working beyond one
context window.

It gives a local assistant durable working memory across sessions without using
a hosted memory service. It logs important events, compacts them with a local
model, builds a resume packet, and turns that packet into a startup prompt that
can be injected into an agent shell such as Qwen Code or used by the built-in
local console. The goal is to let local/open-source models continue tasks that
are bigger than their live context window.

## What The Product Is

This is **local continuity infrastructure for AI agents**.

It is not a cloud app. It is not a hosted database. It is not a replacement for
your model's live context window.

It is a local substrate made of:

- **Remaind** for durable context, event logs, validation, compaction, and resume packets
- **model runtime adapters** for local model calls through Ollama or OpenAI-compatible local servers
- **agent adapters** for attaching memory to an agent shell, including Qwen Code and DeepSeek Code
- **model profiles** for Qwen, DeepSeek, DeepSeek v4 Flash, GLM, Minimax-style, Llama, and custom local models
- **profile-native work folders** so each model/agent can attach to the folder you select during `remaind launch`
- **runtime auto paths** for Ollama chat/generate and llama.cpp/vLLM/LM Studio chat-completions
- **startup prompts** that connect any new session to the current memory state
- **adversarial checks** that quarantine hostile instructions inside retrieved memory
- **bootstrap support** that can install a managed local Python when Python 3.11+ is missing

The core loop:

```text
events -> compact handover/state -> resume packet -> startup prompt -> agent session
```

The product promise:

```text
Bring your local model. Keep memory beyond the context window.
```

## Context Band Policy

Remaind does not make packets bigger just because a model advertises a larger
window. Evidence and resume packets use conservative product-standard bands,
with manual override when a harder task truly needs more room.

| Native model context | Default packet cap |
| --- | ---: |
| `0-130k` | adaptive, up to `18k` |
| `131k-150k` | `25k` |
| `150k-250k` | `40k` |
| `250k-500k` | `80k` |
| `500k-1M` | `160k` |
| `>1M` | `240k` |

Override a run packet when needed:

```bash
remaind run /path/to/file.md "solve this task" --token-cap 40000
```

For benchmark-style tasks, place a JSON answer key next to the document:

```text
my_task_private_answer_key.json
```

Then run:

```bash
remaind run /path/to/my_task.md "solve this task" --require-answer-key-pass
```

Remaind auto-detects the key, compares the answer, and exits non-zero when
validation is required but fails.

## Monitoring

Run a local health check with alert-grade exit codes:

```bash
remaind monitor --alert-on-warning
```

Use `--smoke` when you want the monitor to include a real model-generation
check. On alert, Remaind writes a local health event into the event log and
exits non-zero so cron, launchd, or a supervisor can notify you.

Pre-context failures, such as a missing file path before Remaind can attach to a
project, are reported on stderr with a non-zero exit code. Once a context is
available, health alerts are recorded as local Remaind events.

## What You Get

After install, daily use is one command:

```bash
remaind
```

That command:

1. refreshes memory
2. builds the startup prompt
3. starts the configured agent adapter
4. attaches the memory folder
5. appends the master memory prompt

For the default Qwen Code adapter, the manual equivalent is:

```bash
cd ~/Documents/Qwen-Code
make memory
qwen --yolo --dangerously-skip-permissions
```

The installer adds a local compatibility wrapper so that command can keep
working even when a Qwen Code build no longer accepts older permissive flags.

## Install These First

- macOS or Linux shell environment
- Ollama with an installed model, or an OpenAI-compatible local server such as llama.cpp
- optional: llama.cpp `llama-server`, if using split GGUF models such as DeepSeek v4 Flash
- optional: Qwen Code CLI, if using the default `qwen-code` agent adapter
- optional: Deep Code CLI (`deepcode`), if using the `deepseek-code` adapter

Python 3.11+ is required for Remaind, but the starter kit can bootstrap a
managed local Python with `uv` if Python is missing. The managed bootstrap uses
no `sudo`, installs under this folder's `.bootstrap/`, and verifies the `uv`
archive against its release SHA-256 file before using it.

Remaind is installed automatically into the starter kit's local Python
environment. Release zips include the matching `remaind` wheel when available;
source checkouts fall back to the pinned package in `requirements.txt`. No API
key or hosted memory account is required.

Example model installs:

```bash
ollama pull qwen3.6-35b-a3b-full:latest
ollama pull deepseek-r1:32b
ollama pull llama3.1:8b
```

For split GGUF builds such as DeepSeek v4 Flash, start a local llama.cpp server
instead of importing the split files into Ollama:

```bash
remaind llama-server \
  --binary /path/to/llama-server \
  --model-path /path/to/DeepSeek-V4-Flash-IQ2_XXS-XL-00001-of-00002.gguf \
  --alias deepseek-v4-flash-local \
  --port 18080
```

## One-Command Setup

Unzip this folder where you want the memory system to live, then run:

```bash
./bootstrap.sh
```

If Python 3.11+ is already installed, `bootstrap.sh` uses it and delegates to
`install.sh`. If Python is missing, it installs a managed Python locally and
then continues setup.

To require an already-installed Python and block bootstrap downloads:

```bash
./bootstrap.sh --no-download
```

Default direct install when Python is already available:

```bash
./install.sh --profile qwen-large --agent qwen-code
```

`make setup` still runs the direct installer. After installation, `remaind
setup` can refresh configuration, rebuild memory prompts, and show the
readiness checklist without reinstalling everything.

Start with universal Remaind Turbo memory mode:

```bash
remaind launch                    # Turbo memory mode, any model
remaind launch --memory-mode deep # fuller memory packet
```

Turbo is the default Remaind memory packet mode for every model profile. It
keeps daily startup fast by sending 1 memory, 3 raw excerpts, and a smaller
answer budget. Use `--memory-mode standard` or `--memory-mode deep` when you
want a fuller memory packet instead of the fastest path.

Use a different local model profile:

```bash
./bootstrap.sh --profile deepseek
./bootstrap.sh --profile deepseek-v4-flash
./bootstrap.sh --profile glm
./bootstrap.sh --profile minimax
./bootstrap.sh --profile llama
```

Use a specific custom model:

```bash
./bootstrap.sh \
  --profile custom \
  --model my-local-model:latest \
  --num-ctx 65536
```

Use only the built-in local console, without Qwen Code:

```bash
./bootstrap.sh --agent console --profile llama
```

After install, open a new terminal or make sure the install bin is on PATH:

```bash
export PATH="$HOME/bin:$PATH"
```

Then start:

```bash
remaind
```

Useful setup variants:

```bash
make setup SETUP_ARGS="--agent console --profile llama"
remaind setup --profile deepseek
remaind setup --profile deepseek-v4-flash
remaind setup --model my-local-model:latest --num-ctx 65536
remaind doctor --smoke
```

DeepSeek profiles use `~/Documents/Remaind` as their native agent folder.
That means `remaind setup --profile deepseek` and
`remaind setup --profile deepseek-v4-flash` write the memory Makefile,
`README-SOVEREIGN.md`, `.deepcode/AGENTS.md`, and
`.deepcode/settings.json` bridges there unless you override it. Existing
unmanaged files are preserved and receive `.sovereign` sidecars instead of
being overwritten:

```bash
remaind setup --profile deepseek-v4-flash --agent-workdir ~/Documents/Remaind
```

## Commands

From the memory folder:

```bash
make setup     # install and initialize the local memory system
./bootstrap.sh # setup, including managed Python if needed
make doctor    # check Remaind + runtime/model readiness
make verify    # tests + validate + doctor + resume + startup
make startup   # rebuild .context/active/startup_prompt.md
make compact   # compact memory with the configured local model
make chat      # built-in local model chat with memory loaded
make profiles  # list available model profiles
make proof     # generate a synthetic long archive and test fresh retrieval
make proof-model # same proof, plus a local model answer check
make proof-2m  # terminal-visible 2M-token A/B test with and without memory
make model-test # deterministic retrieval plus optional local model matrix
make llama-server # start a llama.cpp OpenAI-compatible server
make adversarial # prove hostile memory is flagged before resume
make bench     # run the beyond-context contradiction/revocation benchmark
```

Large local text/Markdown files that exceed an agent file-reader limit should
go through Remaind, not raw `@file` loading:

```bash
remaind launch
remaind launch --path . --input file --file /absolute/path/to/huge.md
cat /absolute/path/to/huge.md | remaind launch --path . --input paste --task "solve this task"
remaind large-doc ingest /absolute/path/to/huge.md --path .
remaind large-doc search /absolute/path/to/huge.md "needle phrase" --path . --verify
remaind large-doc slice /absolute/path/to/huge.md --start 1000 --end 1040 --path . --verify
remaind run /absolute/path/to/huge-prompt.md "solve this task" --path .
```

`remaind launch` is the front door. It turns memory on, validates `.context/`,
checks the configured runtime/model, then lets you paste, load a file, resume,
or start empty. Paste mode captures text locally after readiness passes, so a
long terminal session stays seamless without sending raw pasted text directly to
the model before memory is active.

`remaind run` is the direct terminal path for huge prompts. It initializes the
project `.context/` if needed, indexes the source file, builds
`.context/active/run_packet.md`, calls the configured local model with that
compact packet, writes `.context/active/run_answer.md`, and logs the task back
into Remaind.

From the default Qwen Code adapter folder:

```bash
make setup     # refresh memory configuration
make memory    # refresh startup prompt
make doctor    # show readiness checklist
make verify    # verify the memory system
make prompt    # print the master connector prompt
```

After installation, the `remaind` launcher also accepts management commands:

```bash
remaind setup
remaind launch
remaind doctor
remaind verify
remaind proof
remaind proof-2m
remaind model-test
remaind llama-server
remaind adversarial
remaind bench
```

The old `sovereign` command remains as a compatibility alias. To reach the raw
package CLI directly, prefix it with `core`:

```bash
remaind core init --path .
remaind core large-doc ingest /absolute/path/to/huge.md --path .
remaind core run /absolute/path/to/huge-prompt.md "solve this task" --path .
```

## Model Profiles

Profiles live in:

```text
profiles/model_profiles.json
```

Built-ins:

```text
qwen-large
qwen-small
deepseek
deepseek-v4-flash
glm
minimax
llama
custom
```

Profiles are defaults, not prisons. Override the runtime, model, context
window, OpenAI-compatible endpoint, or agent folder at install time or in
`.env`.

## Supported Adapters

Executable today:

```text
runtime: ollama
runtime: llama-server
runtime: OpenAI-compatible local endpoint
agent: qwen-code
agent: deepseek-code
agent: console
```

Designed extension points:

```text
runtime: LM Studio
runtime: vLLM
agent: Aider
agent: Continue
agent: custom CLI
```

## Connect Another AI Session

After install, paste `MASTER_INITIAL_PROMPT.local.md` as the first message in
any AI session that has filesystem access. It tells the session where the
memory root is and which startup prompt to load.

Before install, `MASTER_INITIAL_PROMPT.md` is the shareable template. The
installer writes the local machine-specific prompt to
`MASTER_INITIAL_PROMPT.local.md`, which is ignored by git.

## Built-In Continuity Proof

Run a synthetic proof without using any private archive:

```bash
make proof
```

For an end-to-end local model check:

```bash
make proof-model
```

The proof generates a long local archive, indexes distant signals, recovers the
late signal from a fresh process, and checks that the final phrase can be
recovered from retrieved evidence.

## Built-In Adversarial Proof

Run:

```bash
make adversarial
```

The proof verifies that prompt injection in memory trips the resume gate, fake
tool-result claims are not trusted, phase-2 poison archive fixtures are
flagged, superseded memories do not resurface as current truth, adversarial
review appears before raw evidence, and poisoned compaction output is rejected
before it becomes memory.

## Built-In Beyond-Context Benchmark

Run:

```bash
make bench
```

The benchmark generates a large local source archive, stores source-linked
memories, and verifies from a fresh process that the system can recover the
late final phrase, detect one distant contradiction, honor a superseded memory,
withstand revocation pressure, and quarantine hostile instructions before
resume.

## Terminal 2M Proof

Run the live A/B demo:

```bash
make proof-2m
remaind proof-2m
```

This creates a fresh 2M-token synthetic archive, sends the raw archive directly
to the configured local model with no sovereign memory, then sends the compact
Remaind resume packet to the same model. The expected shape is:

```text
raw 2M prompt: rejected because it exceeds the model context
clipped no-memory prompt: partial answer, distant facts missing
sovereign memory prompt: all distant facts recovered
```

The full no-memory prompt and memory-backed model answer are written under
`.sovereign_2m_proof/`. For a faster smoke run that skips the slow clipped-tail
control:

```bash
make proof-2m PROOF_2M_ARGS="--skip-tail-control"
```

## Model Battle Test

Run a deterministic Remaind retrieval check without model generation:

```bash
make model-test MODEL_TEST_ARGS="--skip-model --force"
remaind model-test --skip-model --force
```

Run the same memory task against explicit local models:

```bash
remaind model-test --models qwen3.6-35b-a3b-full:latest,gpt-oss-120b-fast:latest --force
```

Run every model currently reported by the configured runtime:

```bash
remaind model-test --installed --force
```

For DeepSeek v4 Flash through llama.cpp server:

```bash
remaind setup --profile deepseek-v4-flash
remaind doctor --smoke
remaind model-test --force
```

The test creates an isolated archive, indexes it through `remaind large-doc`,
verifies the source hash/bytes/lines, builds a resume packet, and asks each
model to recover the same final phrase, checksum pair, current code, and
revoked code from verified evidence.

## Sharing With Other People

Share this starter kit, not your `.context/` folder.

Each person should run `make setup` and get their own `.context` ledger.
Copying `.context/` copies memory history and may include private data.

## Privacy

The kit is local-first:

```text
no hosted memory service
no cloud API key requirement
raw events stay on disk
the user owns the memory folder
```

## Uninstall

```bash
./uninstall.sh
```

This removes launcher wrappers from the install bin. It does not delete your
memory folder.

## More

- [Architecture](docs/ARCHITECTURE.md)
- [Operations](docs/OPERATIONS.md)
- [Model Profiles](docs/MODEL_PROFILES.md)
