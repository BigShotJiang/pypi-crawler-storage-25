from __future__ import annotations

import inspect
import json
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

import remaind
from remaind._atomic import atomic_write_text
from remaind._packet_policy import packet_policy_for_context
from remaind.commands import run as run_cmd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from model_battle_test import (
    answer_checks as model_battle_answer_checks,
)
from model_battle_test import (
    parse_models,
    run_battle_test,
)
from proof_2m import answer_checks
from sovereign_memory.runtime import (
    SovereignConfig,
    doctor,
    extract_json_object,
    load_env_file,
    load_model_profiles,
    local_chat,
    memory_mode_settings,
    render_startup_prompt,
    runtime_models,
    strip_model_artifacts,
    strip_qwen_thinking,
    write_agent_bridge,
    write_env_file,
)


class QwenCleanupTests(unittest.TestCase):
    def test_strip_closed_thinking_block(self) -> None:
        content = '<think>{"draft": true}</think>\n{"new_handover": "ok"}'
        self.assertEqual(strip_qwen_thinking(content), '{"new_handover": "ok"}')

    def test_generic_cleanup_alias(self) -> None:
        content = "<think>scratch</think>\nfinal"
        self.assertEqual(strip_model_artifacts(content), "final")

    def test_extracts_balanced_json_with_required_key(self) -> None:
        content = 'noise {"x": 1} then {"new_handover": "has { braces }", "summary": "ok"}'
        payload = extract_json_object(content, required_key="new_handover")
        self.assertEqual(payload, {"new_handover": "has { braces }", "summary": "ok"})

    def test_strip_returns_json_payload_from_mixed_text(self) -> None:
        content = 'notes first\n{"new_handover": "ok", "state_updates": {}}\ntrailing'
        self.assertEqual(
            json.loads(strip_qwen_thinking(content)),
            {"new_handover": "ok", "state_updates": {}},
        )


class StartupPromptTests(unittest.TestCase):
    def test_startup_prompt_wraps_resume_packet(self) -> None:
        prompt = render_startup_prompt("# Resume Packet\n\n## Resume Gate\n\n- concerns: (none)")
        self.assertIn("Local Sovereign Assistant Startup Prompt", prompt)
        self.assertIn("authority order", prompt)
        self.assertIn("remaind large-doc", prompt)
        self.assertIn("# Resume Packet", prompt)


class Proof2MTests(unittest.TestCase):
    def test_answer_checks_require_all_distant_facts(self) -> None:
        answer = (
            "continuity survives rotation when state is source-linked\n"
            "4F92 and 9C17\n"
            "current IRON-NEW, revoked IRON-OLD"
        )
        self.assertTrue(all(answer_checks(answer).values()))

    def test_answer_checks_detect_clipped_context_loss(self) -> None:
        answer = "continuity survives rotation when state is source-linked; NOT_FOUND"
        checks = answer_checks(answer)
        self.assertTrue(checks["final_phrase"])
        self.assertFalse(checks["checksum_4F92"])
        self.assertFalse(checks["checksum_9C17"])
        self.assertFalse(checks["current_IRON_NEW"])
        self.assertFalse(checks["revoked_IRON_OLD"])


class ModelBattleTests(unittest.TestCase):
    def test_model_battle_answer_checks_require_all_fields(self) -> None:
        answer = "MODEL MEMORY MATRIX HOLDS THE LINE\nA17F C93B EMBER-CURRENT EMBER-REVOKED"
        self.assertTrue(all(model_battle_answer_checks(answer).values()))

    def test_model_battle_answer_checks_detect_missing_fields(self) -> None:
        checks = model_battle_answer_checks("MODEL MEMORY MATRIX HOLDS THE LINE A17F")
        self.assertTrue(checks["final_phrase"])
        self.assertTrue(checks["checksum_one"])
        self.assertFalse(checks["checksum_two"])
        self.assertFalse(checks["current_code"])
        self.assertFalse(checks["revoked_code"])

    def test_parse_models_prefers_explicit_list(self) -> None:
        config = SovereignConfig()
        self.assertEqual(
            parse_models("qwen:latest, deepseek:local", config, installed=False),
            ["qwen:latest", "deepseek:local"],
        )

    def test_model_battle_deterministic_skip_model(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            workdir = Path(tmp) / "battle"
            result = run_battle_test(
                config=SovereignConfig(base=Path(tmp)),
                workdir=workdir,
                models=[],
                force=True,
                skip_model=True,
            )
            self.assertTrue(result["passed"])
            self.assertTrue(result["context"]["deterministic_passed"])
            self.assertTrue(result["context"]["search"]["integrity"]["verified"])


class ConfigTests(unittest.TestCase):
    def test_atomic_write_temp_names_are_unique(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "state.json"
            first = atomic_write_text(target, "one")
            second = atomic_write_text(target, "two")

        self.assertIsNone(first)
        self.assertIsNone(second)
        source = Path(inspect.getsourcefile(atomic_write_text) or "")
        self.assertIn("uuid", source.read_text(encoding="utf-8"))

    def test_event_writer_preserves_hash_chain_under_concurrency(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            remaind.init(base)
            state = remaind.status(base)

            def append_event(index: int) -> str:
                writer = remaind.EventWriter.open(base)
                event = writer.append(
                    remaind.EventInput(
                        type="tool_result",
                        actor="test",
                        summary=f"concurrent event {index}",
                        content=f"event {index}",
                        importance=1,
                        session_id=state["session_id"],
                        task_id=state["task_id"],
                    )
                )
                return str(event["id"])

            with ThreadPoolExecutor(max_workers=4) as pool:
                event_ids = list(pool.map(append_event, range(8)))
            report = remaind.validate(base)

        self.assertEqual(len(event_ids), 8)
        self.assertTrue(report.ok, report.failed)

    def test_env_file_and_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / ".env").write_text(
                "SOVEREIGN_MODEL=test-model\n"
                "SOVEREIGN_NUM_CTX=4096\n"
                "SOVEREIGN_MEMORY_MODE=turbo\n"
                "SOVEREIGN_AGENT_WORKDIR=~/Agent-Test\n",
                encoding="utf-8",
            )
            self.assertEqual(load_env_file(base)["SOVEREIGN_MODEL"], "test-model")
            config = SovereignConfig.from_env(base=base)
            self.assertEqual(config.model, "test-model")
            self.assertEqual(config.num_ctx, 4096)
            self.assertEqual(config.memory_mode, "turbo")
            self.assertEqual(config.compaction_num_predict, 1024)
            self.assertEqual(config.resume_memories, 1)
            self.assertEqual(config.resume_excerpts, 3)

    def test_memory_mode_settings_are_model_agnostic(self) -> None:
        self.assertEqual(
            memory_mode_settings("turbo"),
            {
                "compaction_num_predict": 1024,
                "resume_memories": 1,
                "resume_excerpts": 3,
            },
        )
        self.assertEqual(memory_mode_settings("deep")["resume_excerpts"], 30)

    def test_profiles_load(self) -> None:
        profiles = load_model_profiles(Path(__file__).resolve().parents[1])
        self.assertIn("qwen-large", profiles)
        self.assertIn("deepseek", profiles)
        self.assertIn("deepseek-v4-flash", profiles)
        self.assertEqual(profiles["deepseek"]["agent"], "deepseek-code")
        self.assertEqual(profiles["deepseek"]["agent_cli"], "deepcode")
        self.assertEqual(profiles["deepseek"]["agent_workdir"], "~/Documents/Remaind")
        self.assertEqual(
            profiles["deepseek-v4-flash"]["agent_workdir"],
            "~/Documents/Remaind",
        )

    def test_profile_agent_workdir_default_is_used(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / "profiles").mkdir()
            (base / "profiles" / "model_profiles.json").write_text(
                json.dumps(
                    {
                        "profiles": {
                            "deepseek-v4-flash": {
                                "runtime": "llama-server",
                                "model": "deepseek-v4-flash-local",
                                "openai_base_url": "http://127.0.0.1:18080/v1",
                                "agent": "deepseek-code",
                                "agent_cli": "dc",
                                "agent_workdir": "~/sovereign-local-ai",
                                "num_ctx": 4096,
                            }
                        }
                    }
                ),
                encoding="utf-8",
            )
            (base / ".env").write_text(
                "SOVEREIGN_MODEL_PROFILE=deepseek-v4-flash\n",
                encoding="utf-8",
            )
            config = SovereignConfig.from_env(base=base)

        self.assertEqual(config.runtime, "llama-server")
        self.assertEqual(config.model, "deepseek-v4-flash-local")
        self.assertEqual(config.agent, "deepseek-code")
        self.assertEqual(config.agent_cli, "dc")
        self.assertEqual(config.agent_workdir, Path("~/sovereign-local-ai").expanduser())

    def test_write_agent_bridge_uses_profile_workdir(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp) / "memory"
            workdir = Path(tmp) / "DeepCode"
            install_bin = Path(tmp) / "bin"
            config = SovereignConfig(
                base=base,
                agent="qwen-code",
                agent_cli="qwen",
                agent_workdir=workdir,
                install_bin=install_bin,
            )
            paths = write_agent_bridge(config)
            self.assertEqual(
                {path.name for path in paths},
                {"Makefile", "README-SOVEREIGN.md"},
            )
            makefile = workdir / "Makefile"
            readme = workdir / "README-SOVEREIGN.md"
            self.assertIn(str(base), makefile.read_text(encoding="utf-8"))
            self.assertIn(str(workdir), readme.read_text(encoding="utf-8"))

    def test_write_agent_bridge_preserves_unmanaged_makefile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp) / "memory"
            workdir = Path(tmp) / "DeepCode"
            workdir.mkdir()
            unmanaged = workdir / "Makefile"
            unmanaged.write_text("user-target:\n\t@true\n", encoding="utf-8")
            config = SovereignConfig(
                base=base,
                agent="qwen-code",
                agent_workdir=workdir,
                install_bin=Path(tmp) / "bin",
            )
            paths = write_agent_bridge(config)
            self.assertIn(workdir / "Makefile.sovereign", paths)
            self.assertEqual(unmanaged.read_text(encoding="utf-8"), "user-target:\n\t@true\n")

    def test_write_deepseek_bridge_generates_deepcode_agents_md(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp) / "memory"
            workdir = Path(tmp) / "sovereign-local-ai"
            install_bin = Path(tmp) / "bin"
            startup = base / ".context" / "active" / "startup_prompt.md"
            startup.parent.mkdir(parents=True)
            startup.write_text("Remaind startup packet", encoding="utf-8")
            workdir.mkdir()
            (workdir / "AGENTS.md").write_text(
                "# Project Rules\n\nKeep changes scoped.\n",
                encoding="utf-8",
            )
            config = SovereignConfig(
                base=base,
                agent="deepseek-code",
                agent_cli="dc",
                agent_workdir=workdir,
                install_bin=install_bin,
            )
            paths = write_agent_bridge(config)

            agents_path = workdir / ".deepcode" / "AGENTS.md"
            self.assertIn(agents_path, paths)
            text = agents_path.read_text(encoding="utf-8")
            self.assertIn("Remaind Memory For DeepSeek Code", text)
            self.assertIn("startup prompt:", text)
            self.assertIn(str(startup), text)
            self.assertIn("Keep changes scoped.", text)

    def test_packet_policy_uses_product_bands(self) -> None:
        self.assertEqual(packet_policy_for_context(130_000).packet_tokens, 18_000)
        self.assertEqual(packet_policy_for_context(131_072).packet_tokens, 25_000)
        self.assertEqual(packet_policy_for_context(250_000).packet_tokens, 40_000)
        self.assertEqual(packet_policy_for_context(500_000).packet_tokens, 80_000)
        self.assertEqual(packet_policy_for_context(1_000_000).packet_tokens, 160_000)

    def test_run_auto_validates_private_answer_key(self) -> None:
        class FakeModel:
            label = "fake local model"

            def generate(self, system_text: str, user_text: str) -> str:
                return (
                    "SOLVED: EXACT\n"
                    "MODE: TEST\n"
                    "CHECKSUM: OK\n"
                    "DECISION: FOLLOWED"
                )

        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            document = base / "case.md"
            document.write_text("# Case\n", encoding="utf-8")
            document.with_name("case_private_answer_key.json").write_text(
                json.dumps(
                    {
                        "required_final_output_exact": (
                            "SOLVED: EXACT\n"
                            "MODE: TEST\n"
                            "CHECKSUM: OK\n"
                            "DECISION: FOLLOWED"
                        )
                    }
                ),
                encoding="utf-8",
            )
            result = run_cmd.execute(
                base / "context",
                document,
                "solve exactly",
                model=FakeModel(),
                num_ctx=131_072,
            )

        self.assertEqual(result.token_cap, 25_000)
        self.assertIsNotNone(result.answer_key_path)
        self.assertTrue(result.answer_validation["passed"])

    def test_write_env_file_preserves_template_order(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / ".env.example").write_text(
                "# example\nSOVEREIGN_MODEL_PROFILE=qwen-large\nSOVEREIGN_MODEL=\n",
                encoding="utf-8",
            )
            write_env_file(
                base,
                {
                    "SOVEREIGN_MODEL_PROFILE": "llama",
                    "SOVEREIGN_MODEL": "llama3.1:8b",
                    "INSTALL_BIN": "~/bin",
                },
            )
            text = (base / ".env").read_text(encoding="utf-8")
            self.assertTrue(text.startswith("# example\nSOVEREIGN_MODEL_PROFILE=llama"))
            values = load_env_file(base)
            self.assertEqual(values["SOVEREIGN_MODEL"], "llama3.1:8b")
            self.assertEqual(values["INSTALL_BIN"], "~/bin")

    def test_local_chat_generate_mode_uses_completion_endpoint(self) -> None:
        calls = []

        def fake_post(url: str, body: dict, *, timeout: float) -> dict:
            calls.append((url, body, timeout))
            return {"response": "<think>scratch</think>\nREADY"}

        config = SovereignConfig(
            runtime="ollama",
            model="deepseek-v4-flash:iq2_xxs_xl",
            ollama_api="generate",
            num_ctx=4096,
            cleanup_style="thinking-tags",
        )
        with patch("sovereign_memory.runtime.post_json", side_effect=fake_post):
            answer = local_chat(config, [{"role": "user", "content": "ping"}])

        self.assertEqual(answer, "READY")
        self.assertEqual(calls[0][0], "http://localhost:11434/api/generate")
        self.assertIn("USER:", calls[0][1]["prompt"])
        self.assertNotIn("messages", calls[0][1])

    def test_local_chat_auto_falls_back_to_generate(self) -> None:
        calls = []

        def fake_post(url: str, body: dict, *, timeout: float) -> dict:
            calls.append(url)
            if url.endswith("/api/chat"):
                raise RuntimeError("chat failed")
            return {"response": "READY"}

        config = SovereignConfig(
            runtime="ollama",
            model="completion-only",
            ollama_api="auto",
            num_ctx=4096,
        )
        with patch("sovereign_memory.runtime.post_json", side_effect=fake_post):
            answer = local_chat(config, [{"role": "user", "content": "ping"}])

        self.assertEqual(answer, "READY")
        self.assertEqual(
            calls,
            [
                "http://localhost:11434/api/chat",
                "http://localhost:11434/api/generate",
            ],
        )

    def test_local_chat_openai_runtime_uses_chat_completions(self) -> None:
        calls = []

        def fake_post(url: str, body: dict, *, timeout: float) -> dict:
            calls.append((url, body, timeout))
            return {"choices": [{"message": {"content": "<think>x</think>\nREADY"}}]}

        config = SovereignConfig(
            runtime="llama-server",
            openai_base_url="http://127.0.0.1:18080/v1",
            model="deepseek-v4-flash-local",
            cleanup_style="thinking-tags",
        )
        with patch("sovereign_memory.runtime.post_json", side_effect=fake_post):
            answer = local_chat(config, [{"role": "user", "content": "ping"}])

        self.assertEqual(answer, "READY")
        self.assertEqual(calls[0][0], "http://127.0.0.1:18080/v1/chat/completions")
        self.assertEqual(calls[0][1]["model"], "deepseek-v4-flash-local")

    def test_runtime_models_reads_openai_compatible_models(self) -> None:
        payload = {"data": [{"id": "deepseek-v4-flash-local"}]}
        config = SovereignConfig(
            runtime="llama-server",
            openai_base_url="http://127.0.0.1:18080/v1",
            model="deepseek-v4-flash-local",
        )
        with patch("sovereign_memory.runtime.get_json", return_value=payload):
            self.assertEqual(runtime_models(config), ["deepseek-v4-flash-local"])

    def test_doctor_reports_ready_checklist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            remaind.init(base)
            (base / ".context" / "active" / "startup_prompt.md").write_text(
                "prompt",
                encoding="utf-8",
            )
            install_bin = base / "bin"
            install_bin.mkdir()
            (install_bin / "sovereign").write_text("#!/usr/bin/env bash\n", encoding="utf-8")
            config = SovereignConfig(
                base=base,
                agent="console",
                install_bin=install_bin,
                model="test-model:latest",
                num_ctx=4096,
            )
            show = {
                "model_info": {"test.context_length": 8192},
                "details": {"parameter_size": "test"},
                "capabilities": ["completion"],
            }
            with (
                patch(
                    "sovereign_memory.runtime._ollama_tags",
                    return_value=(True, ["test-model:latest"], None),
                ),
                patch("sovereign_memory.runtime.ollama_show", return_value=show),
            ):
                report = doctor(config)
            self.assertTrue(report["ready"])
            self.assertEqual(report["blockers"], [])
            self.assertIn("checks", report)

    def test_doctor_blocks_when_model_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            remaind.init(base)
            config = SovereignConfig(base=base, agent="console", model="missing:latest")
            with patch(
                "sovereign_memory.runtime._ollama_tags",
                return_value=(True, ["other:latest"], None),
            ):
                report = doctor(config)
            self.assertFalse(report["ready"])
            self.assertTrue(any(item["label"] == "Model installed" for item in report["blockers"]))


if __name__ == "__main__":
    unittest.main()
