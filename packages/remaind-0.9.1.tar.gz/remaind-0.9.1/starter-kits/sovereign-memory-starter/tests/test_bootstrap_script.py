from __future__ import annotations

import os
import subprocess
import unittest
from pathlib import Path

KIT_ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = KIT_ROOT / "bootstrap.sh"
INSTALL = KIT_ROOT / "install.sh"
UNINSTALL = KIT_ROOT / "uninstall.sh"


class BootstrapScriptTests(unittest.TestCase):
    def test_help_is_available_without_running_installer(self) -> None:
        result = subprocess.run(
            ["bash", str(BOOTSTRAP), "--help"],
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("Usage: ./bootstrap.sh", result.stdout)
        self.assertIn("--no-download", result.stdout)

    def test_no_download_fails_cleanly_when_python_is_missing(self) -> None:
        env = os.environ.copy()
        env["SOVEREIGN_BOOTSTRAP_SKIP_SYSTEM_PYTHON"] = "1"
        result = subprocess.run(
            ["bash", str(BOOTSTRAP), "--no-download", "--agent", "console"],
            check=False,
            capture_output=True,
            text=True,
            env=env,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Python 3.11+ is missing", result.stderr)

    def test_script_uses_local_checksum_verified_bootstrap(self) -> None:
        text = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertNotIn("| sh", text)
        self.assertNotRegex(text, r"(^|\n)\s*sudo\b")
        self.assertIn(".sha256", text)
        self.assertIn("--tlsv1.2", text)
        self.assertIn(".bootstrap", text)
        self.assertIn("UV_PYTHON_INSTALL_DIR", text)
        self.assertIn("UV_PYTHON_BIN_DIR", text)

    def test_shell_tilde_expansion_uses_literal_pattern(self) -> None:
        for script in (BOOTSTRAP, INSTALL, UNINSTALL):
            text = script.read_text(encoding="utf-8")
            self.assertIn(r"${input#\~/}", text)
            self.assertNotIn(r"${input#~/}", text)

    def test_installed_launcher_routes_model_test(self) -> None:
        text = INSTALL.read_text(encoding="utf-8")
        self.assertIn("proof-2m|model-test|ask", text)
        self.assertIn("LOCAL_REMAIND_WHEELS", text)
        self.assertIn("wheels/remaind-*.whl", text)
        self.assertIn("Copying starter kit files into memory root", text)
        self.assertIn('cp -pR "$KIT_ROOT/$item"', text)

    def test_installer_makes_remaind_primary_launcher(self) -> None:
        install_text = INSTALL.read_text(encoding="utf-8")
        uninstall_text = UNINSTALL.read_text(encoding="utf-8")
        self.assertIn('$INSTALL_BIN/remaind', install_text)
        self.assertIn('exec "$INSTALL_BIN/remaind" "\\$@"', install_text)
        self.assertIn('core_remaind() {', install_text)
        self.assertIn("configure_remaind_runtime() {", install_text)
        self.assertIn("init|rollback|large-doc|run|context)", install_text)
        self.assertIn("launch)", install_text)
        self.assertIn("setup|doctor|monitor|status", install_text)
        self.assertIn("REMAIND_CALLER_PWD", install_text)
        self.assertIn('export REMAIND_OLLAMA_MODEL="\\$MODEL"', install_text)
        self.assertIn('export REMAIND_OPENAI_MODEL="\\$MODEL"', install_text)
        self.assertIn('remove_managed_launcher "$INSTALL_BIN/remaind"', uninstall_text)


if __name__ == "__main__":
    unittest.main()
