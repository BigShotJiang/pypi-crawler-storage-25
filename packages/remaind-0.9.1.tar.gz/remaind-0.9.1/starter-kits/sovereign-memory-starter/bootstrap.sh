#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

PYTHON_VERSION="${SOVEREIGN_BOOTSTRAP_PYTHON_VERSION:-3.12}"
UV_VERSION="${SOVEREIGN_BOOTSTRAP_UV_VERSION:-0.11.14}"
BOOTSTRAP_DIR="${SOVEREIGN_BOOTSTRAP_DIR:-$KIT_ROOT/.bootstrap}"
BOOTSTRAP_BIN="$BOOTSTRAP_DIR/bin"
BOOTSTRAP_PYTHON_DIR="$BOOTSTRAP_DIR/python"
BOOTSTRAP_CACHE_DIR="$BOOTSTRAP_DIR/cache"
DOWNLOADS_ALLOWED=1
INSTALL_ARGS=()

usage() {
  cat <<'EOF'
Usage: ./bootstrap.sh [bootstrap options] [installer options]

Bootstrap options:
  --python-version VERSION  Managed Python version to install with uv. Default: 3.12.
  --uv-version VERSION      uv version to install if uv is missing. Default: 0.11.14.
  --bootstrap-dir PATH      Local bootstrap tool folder. Default: ./.bootstrap.
  --no-download             Refuse network downloads; fail if Python 3.11+ is missing.
  -h, --help                Show this help.

Everything else is passed to ./install.sh, for example:
  ./bootstrap.sh --agent console --profile llama --skip-shell-rc

Security posture:
  - no sudo
  - no global Python install
  - no shell rc edits beyond what ./install.sh normally controls
  - uv archive downloads are checked against the release SHA-256 file
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --python-version)
      PYTHON_VERSION="$2"; shift 2 ;;
    --uv-version)
      UV_VERSION="$2"; shift 2 ;;
    --bootstrap-dir)
      BOOTSTRAP_DIR="$2"; BOOTSTRAP_BIN="$BOOTSTRAP_DIR/bin"; shift 2 ;;
    --no-download)
      DOWNLOADS_ALLOWED=0; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      INSTALL_ARGS+=("$1"); shift ;;
  esac
done

expand_path() {
  local input="$1"
  if [[ "$input" == "~" ]]; then
    printf '%s\n' "$HOME"
  elif [[ "$input" == "~/"* ]]; then
    printf '%s/%s\n' "$HOME" "${input#\~/}"
  else
    printf '%s\n' "$input"
  fi
}

BOOTSTRAP_DIR="$(expand_path "$BOOTSTRAP_DIR")"
BOOTSTRAP_BIN="$BOOTSTRAP_DIR/bin"
BOOTSTRAP_PYTHON_DIR="$BOOTSTRAP_DIR/python"
BOOTSTRAP_CACHE_DIR="$BOOTSTRAP_DIR/cache"

is_python_311() {
  local candidate="$1"
  [[ -x "$candidate" ]] || return 1
  "$candidate" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3, 11) else 1)
PY
}

find_python() {
  local candidate name
  if [[ "${SOVEREIGN_BOOTSTRAP_SKIP_SYSTEM_PYTHON:-0}" == "1" ]]; then
    return 1
  fi
  if [[ -n "${PYTHON_BIN:-}" ]] && is_python_311 "$PYTHON_BIN"; then
    printf '%s\n' "$PYTHON_BIN"
    return 0
  fi
  for name in python3.14 python3.13 python3.12 python3.11 python3; do
    candidate="$(command -v "$name" 2>/dev/null || true)"
    if [[ -n "$candidate" ]] && is_python_311 "$candidate"; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

download_file() {
  local url="$1"
  local dest="$2"
  if command -v curl >/dev/null 2>&1; then
    curl --proto '=https' --tlsv1.2 --fail --location --show-error --silent "$url" -o "$dest"
  elif command -v wget >/dev/null 2>&1; then
    wget --https-only --quiet -O "$dest" "$url"
  else
    echo "Missing downloader: install curl or wget, then rerun ./bootstrap.sh." >&2
    exit 1
  fi
}

sha256_file() {
  local path="$1"
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$path" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$path" | awk '{print $1}'
  else
    echo "Missing SHA-256 tool: install shasum or sha256sum." >&2
    exit 1
  fi
}

platform_asset() {
  local os arch libc
  os="$(uname -s)"
  arch="$(uname -m)"
  case "$arch" in
    arm64|aarch64) arch="aarch64" ;;
    x86_64|amd64) arch="x86_64" ;;
    *)
      echo "Unsupported CPU architecture for managed bootstrap: $arch" >&2
      exit 1 ;;
  esac

  case "$os" in
    Darwin)
      printf 'uv-%s-apple-darwin.tar.gz\n' "$arch" ;;
    Linux)
      libc="gnu"
      if command -v ldd >/dev/null 2>&1 && ldd --version 2>&1 | grep -qi musl; then
        libc="musl"
      fi
      printf 'uv-%s-unknown-linux-%s.tar.gz\n' "$arch" "$libc" ;;
    *)
      echo "Unsupported OS for managed bootstrap: $os" >&2
      exit 1 ;;
  esac
}

install_uv() {
  mkdir -p "$BOOTSTRAP_BIN"
  local asset url checksum_url tmp archive checksum expected actual extracted uv_path
  asset="$(platform_asset)"
  url="https://releases.astral.sh/github/uv/releases/download/$UV_VERSION/$asset"
  checksum_url="$url.sha256"
  tmp="$(mktemp -d)"
  archive="$tmp/$asset"
  checksum="$tmp/$asset.sha256"

  echo "Installing uv $UV_VERSION locally..."
  echo "Downloading $asset"
  download_file "$url" "$archive"
  download_file "$checksum_url" "$checksum"

  expected="$(awk '{print $1}' "$checksum" | sed 's/^sha256://')"
  actual="$(sha256_file "$archive")"
  if [[ -z "$expected" || "$expected" != "$actual" ]]; then
    echo "Checksum mismatch for $asset." >&2
    echo "Expected: $expected" >&2
    echo "Actual:   $actual" >&2
    exit 1
  fi

  extracted="$tmp/extracted"
  mkdir -p "$extracted"
  tar -xzf "$archive" -C "$extracted"
  uv_path="$(find "$extracted" -type f -name uv -perm -111 | head -n 1)"
  if [[ -z "$uv_path" ]]; then
    echo "Downloaded uv archive did not contain an executable uv binary." >&2
    exit 1
  fi
  cp "$uv_path" "$BOOTSTRAP_BIN/uv"
  chmod +x "$BOOTSTRAP_BIN/uv"
  "$BOOTSTRAP_BIN/uv" --version
}

find_uv() {
  local candidate
  candidate="${SOVEREIGN_BOOTSTRAP_UV_BIN:-}"
  if [[ -n "$candidate" && -x "$candidate" ]]; then
    printf '%s\n' "$candidate"
    return 0
  fi
  candidate="$BOOTSTRAP_BIN/uv"
  if [[ -x "$candidate" ]]; then
    printf '%s\n' "$candidate"
    return 0
  fi
  candidate="$(command -v uv 2>/dev/null || true)"
  if [[ -n "$candidate" ]]; then
    printf '%s\n' "$candidate"
    return 0
  fi
  return 1
}

python_bin="$(find_python || true)"
if [[ -z "$python_bin" ]]; then
  if [[ "$DOWNLOADS_ALLOWED" != "1" ]]; then
    echo "Python 3.11+ is missing and downloads are disabled." >&2
    echo "Install Python 3.11+ or rerun without --no-download." >&2
    exit 1
  fi

  uv_bin="$(find_uv || true)"
  if [[ -z "$uv_bin" ]]; then
    install_uv
    uv_bin="$BOOTSTRAP_BIN/uv"
  fi

  mkdir -p "$BOOTSTRAP_PYTHON_DIR" "$BOOTSTRAP_CACHE_DIR"
  echo "Installing managed Python $PYTHON_VERSION with uv..."
  env \
    PATH="$BOOTSTRAP_BIN:${PATH:-}" \
    UV_CACHE_DIR="$BOOTSTRAP_CACHE_DIR" \
    UV_PYTHON_CACHE_DIR="$BOOTSTRAP_CACHE_DIR/python-archives" \
    UV_PYTHON_BIN_DIR="$BOOTSTRAP_BIN" \
    UV_PYTHON_INSTALL_DIR="$BOOTSTRAP_PYTHON_DIR" \
    "$uv_bin" python install "$PYTHON_VERSION"
  python_bin="$(env \
    PATH="$BOOTSTRAP_BIN:${PATH:-}" \
    UV_CACHE_DIR="$BOOTSTRAP_CACHE_DIR" \
    UV_PYTHON_CACHE_DIR="$BOOTSTRAP_CACHE_DIR/python-archives" \
    UV_PYTHON_BIN_DIR="$BOOTSTRAP_BIN" \
    UV_PYTHON_INSTALL_DIR="$BOOTSTRAP_PYTHON_DIR" \
    "$uv_bin" python find "$PYTHON_VERSION")"
  if ! is_python_311 "$python_bin"; then
    echo "Managed Python install did not produce a Python 3.11+ executable." >&2
    exit 1
  fi
fi

echo "Using Python: $python_bin"
cd "$KIT_ROOT"
PYTHON_BIN="$python_bin" ./install.sh "${INSTALL_ARGS[@]}"
