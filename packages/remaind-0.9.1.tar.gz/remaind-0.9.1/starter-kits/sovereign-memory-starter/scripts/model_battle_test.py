from __future__ import annotations

import argparse
import json
import shutil
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any

import remaind

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sovereign_memory.runtime import (
    SovereignConfig,
    local_chat,
    model_system_prefix,
    runtime_models,
)

BASE = Path(__file__).resolve().parents[1]
DEFAULT_WORKDIR = BASE / ".sovereign_model_battle"
ARCHIVE_NAME = "model_battle_archive.md"

FINAL_PHRASE = "MODEL MEMORY MATRIX HOLDS THE LINE"
CHECKSUM_ONE = "A17F"
CHECKSUM_TWO = "C93B"
CURRENT_CODE = "EMBER-CURRENT"
REVOKED_CODE = "EMBER-REVOKED"


def write_archive(path: Path, *, lines: int = 1600) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    signals = {
        11: f"Signal Alpha: Atlas checksum claim one is {CHECKSUM_ONE}.",
        641: f"Signal Beta: Atlas checksum claim two is {CHECKSUM_TWO}.",
        1040: f"Signal Gamma: release code {REVOKED_CODE} is revoked.",
        1240: f"Signal Delta: release code {CURRENT_CODE} is current.",
        1530: f"Correct final synthesis phrase: {FINAL_PHRASE}.",
    }
    with path.open("w", encoding="utf-8") as handle:
        handle.write("# Remaind Model Battle Test Archive\n\n")
        for line in range(1, lines + 1):
            if line in signals:
                handle.write(signals[line] + "\n")
            else:
                handle.write(
                    f"Filler row {line:05d}. This row creates distance but carries no answer.\n"
                )
    return {
        "path": str(path),
        "lines": lines + 2,
        "signals": signals,
        "expected": expected_answer(),
    }


def expected_answer() -> dict[str, str]:
    return {
        "final_phrase": FINAL_PHRASE,
        "checksum_one": CHECKSUM_ONE,
        "checksum_two": CHECKSUM_TWO,
        "current_code": CURRENT_CODE,
        "revoked_code": REVOKED_CODE,
    }


def answer_checks(answer: str) -> dict[str, bool]:
    upper = answer.upper()
    return {
        "final_phrase": FINAL_PHRASE in upper,
        "checksum_one": CHECKSUM_ONE in upper,
        "checksum_two": CHECKSUM_TWO in upper,
        "current_code": CURRENT_CODE in upper,
        "revoked_code": REVOKED_CODE in upper,
    }


def _context_paths(workdir: Path) -> tuple[Path, Path]:
    context = workdir / "context"
    archive = workdir / ARCHIVE_NAME
    return context, archive


def prepare_context(workdir: Path, *, force: bool = False) -> dict[str, Any]:
    context, archive = _context_paths(workdir)
    if force and workdir.exists():
        shutil.rmtree(workdir, ignore_errors=True)
    workdir.mkdir(parents=True, exist_ok=True)
    if not (context / ".context" / "active" / "state.json").exists():
        remaind.init(context)

    archive_info = write_archive(archive)
    ingest = remaind.ingest_large_document(context, archive, title="Model Battle Archive")
    final_search = remaind.search_large_document(
        archive,
        "Correct final synthesis phrase",
        base=context,
        verify=True,
        context=2,
        max_results=3,
    )
    checksum_search = remaind.search_large_document(
        archive,
        "Atlas checksum claim",
        base=context,
        verify=True,
        context=1,
        max_results=5,
    )
    release_search = remaind.search_large_document(
        archive,
        "release code",
        base=context,
        verify=True,
        context=1,
        max_results=5,
    )
    slice_result = remaind.slice_large_document(
        archive,
        start=1530,
        end=1532,
        base=context,
        verify=True,
    )
    packet = remaind.resume(context, k_memories=5, raw_excerpt_count=5).packet
    validation = remaind.validate(context)

    deterministic_checks = {
        "archive_written": archive.exists(),
        "large_doc_ingested": Path(ingest.manifest_path).exists(),
        "search_verified": bool(final_search.integrity and final_search.integrity["verified"]),
        "final_phrase_found": FINAL_PHRASE in json.dumps(final_search.to_dict()).upper(),
        "checksum_pair_found": CHECKSUM_ONE in json.dumps(checksum_search.to_dict())
        and CHECKSUM_TWO in json.dumps(checksum_search.to_dict()),
        "release_codes_found": CURRENT_CODE in json.dumps(release_search.to_dict())
        and REVOKED_CODE in json.dumps(release_search.to_dict()),
        "slice_verified": bool(slice_result.integrity and slice_result.integrity["verified"]),
        "resume_has_memory": ingest.memory_id in packet.included_memory_ids,
        "context_valid": validation.ok,
    }
    return {
        "workdir": str(workdir),
        "context": str(context),
        "archive": archive_info,
        "ingest": ingest.to_dict(),
        "search": final_search.to_dict(),
        "evidence": {
            "final_phrase": final_search.to_dict(),
            "checksums": checksum_search.to_dict(),
            "release_codes": release_search.to_dict(),
        },
        "slice": slice_result.to_dict(),
        "resume_tokens": packet.token_count,
        "resume_token_cap": packet.token_cap,
        "deterministic_checks": deterministic_checks,
        "deterministic_passed": all(deterministic_checks.values()),
        "validation_failed": validation.failed,
    }


def model_prompt(context_result: dict[str, Any]) -> str:
    evidence = json.dumps(context_result["evidence"], indent=2, sort_keys=True)
    slice_result = json.dumps(context_result["slice"], indent=2, sort_keys=True)
    expected_keys = ", ".join(expected_answer())
    return (
        "Use only the verified Remaind large-doc evidence below. Return a concise "
        "answer containing these fields as plain text: "
        f"{expected_keys}. Do not invent missing values.\n\n"
        "Verified search evidence:\n"
        f"{evidence}\n\n"
        "Verified slice evidence:\n"
        f"{slice_result}\n"
    )


def run_model(
    config: SovereignConfig, model: str, context_result: dict[str, Any]
) -> dict[str, Any]:
    model_config = replace(config, model=model)
    available = runtime_models(model_config)
    installed = model in available if available else False
    if available and not installed:
        return {
            "model": model,
            "runtime": model_config.runtime,
            "installed": False,
            "passed": False,
            "error": f"model is not reported by {model_config.runtime}: {model}",
        }

    prompt = model_prompt(context_result)
    try:
        answer = local_chat(
            model_config,
            [
                {
                    "role": "system",
                    "content": (
                        model_system_prefix(model_config)
                        + "You are testing Remaind model compatibility. "
                        "Use only supplied evidence."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0,
        )
    except Exception as exc:
        return {
            "model": model,
            "runtime": model_config.runtime,
            "installed": installed,
            "passed": False,
            "error": str(exc),
        }

    checks = answer_checks(answer)
    return {
        "model": model,
        "runtime": model_config.runtime,
        "installed": installed,
        "passed": all(checks.values()),
        "checks": checks,
        "answer": answer,
    }


def parse_models(value: str | None, config: SovereignConfig, *, installed: bool) -> list[str]:
    if value:
        return [part.strip() for part in value.split(",") if part.strip()]
    if installed:
        return runtime_models(config)
    return [config.model]


def run_battle_test(
    *,
    config: SovereignConfig,
    workdir: Path,
    models: list[str],
    force: bool,
    skip_model: bool,
) -> dict[str, Any]:
    context_result = prepare_context(workdir, force=force)
    model_results: list[dict[str, Any]] = []
    if not skip_model:
        for model in models:
            model_results.append(run_model(config, model, context_result))

    return {
        "passed": context_result["deterministic_passed"]
        and (skip_model or (bool(model_results) and all(item["passed"] for item in model_results))),
        "skip_model": skip_model,
        "models_requested": models,
        "context": context_result,
        "models": model_results,
    }


def render_human(result: dict[str, Any]) -> str:
    rows = []
    rows.append(f"Model battle test: {'PASS' if result['passed'] else 'FAIL'}")
    rows.append(f"Workspace: {result['context']['workdir']}")
    rows.append("")
    rows.append("Deterministic Remaind checks:")
    for name, passed in result["context"]["deterministic_checks"].items():
        rows.append(f"  {'ok' if passed else 'FAIL':4} {name}")
    rows.append("")
    if result["skip_model"]:
        rows.append("Model generation: skipped")
    elif result["models"]:
        rows.append("Model generation:")
        for item in result["models"]:
            rows.append(f"  {'ok' if item['passed'] else 'FAIL':4} {item['model']}")
            if item.get("error"):
                rows.append(f"       error: {item['error']}")
            elif item.get("checks"):
                missing = [key for key, passed in item["checks"].items() if not passed]
                if missing:
                    rows.append(f"       missing: {', '.join(missing)}")
    else:
        rows.append("Model generation: no models requested")
    return "\n".join(rows) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Battle-test Remaind memory compatibility across local models."
    )
    parser.add_argument("--models", default=None, help="comma-separated local model names")
    parser.add_argument(
        "--installed",
        action="store_true",
        help="test every model currently reported by the configured runtime",
    )
    parser.add_argument("--workdir", type=Path, default=DEFAULT_WORKDIR)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--skip-model", action="store_true")
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args()

    config = SovereignConfig.from_env()
    models = parse_models(args.models, config, installed=args.installed)
    result = run_battle_test(
        config=config,
        workdir=args.workdir,
        models=models,
        force=args.force,
        skip_model=args.skip_model,
    )
    if args.as_json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(render_human(result), end="")
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
