from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
from dataclasses import replace
from pathlib import Path

import remaind

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sovereign_memory.runtime import (
    SovereignConfig,
    apply_setup,
    ask_local_model_with_memory,
    bootstrap_context,
    build_startup_prompt,
    compact_with_local_model,
    doctor,
    load_model_profiles,
    local_chat,
    log_event,
    memory_mode_settings,
    model_system_prefix,
    render_compaction_result,
    tune_thresholds,
    write_agent_bridge,
    write_env_file,
)


def _prompt(question: str, *, default: str | None = None) -> str:
    suffix = f" [{default}]" if default is not None else ""
    answer = input(f"{question}{suffix}: ").strip()
    return answer or (default or "")


def _yes_no(question: str, *, default: bool = True) -> bool:
    hint = "Y/n" if default else "y/N"
    answer = input(f"{question} [{hint}]: ").strip().lower()
    if not answer:
        return default
    return answer in {"y", "yes"}


def _parse_file_and_optional_task(raw: str) -> tuple[Path, str | None]:
    value = raw.strip()
    if value.startswith("@"):
        value = value[1:].strip()

    try:
        tokens = shlex.split(value)
    except ValueError:
        tokens = value.split()

    if tokens:
        first = tokens[0].removeprefix("@")
        first_path = Path(first).expanduser()
        if first_path.exists():
            task = " ".join(tokens[1:]).strip() or None
            return first_path.resolve(), task

    full_path = Path(value).expanduser()
    if full_path.exists():
        return full_path.resolve(), None

    parts = value.split()
    for end in range(len(parts) - 1, 0, -1):
        candidate_text = " ".join(parts[:end]).removeprefix("@")
        candidate = Path(candidate_text).expanduser()
        if candidate.exists():
            task = " ".join(parts[end:]).strip() or None
            return candidate.resolve(), task

    return full_path.resolve(), None


def _slugify_session_name(value: str) -> str:
    cleaned = "".join(char.lower() if char.isalnum() else "-" for char in value.strip())
    cleaned = "-".join(part for part in cleaned.split("-") if part)
    return cleaned[:48] or "session"


def _session_meta_path(session_dir: Path) -> Path:
    return session_dir / ".remaind-session.json"


def _write_session_meta(session_dir: Path, *, name: str, parent: Path) -> None:
    from datetime import UTC, datetime

    meta = {
        "name": name,
        "path": str(session_dir),
        "parent": str(parent),
        "created_at": datetime.now(UTC).isoformat(),
        "kind": "remaind-session",
    }
    _session_meta_path(session_dir).write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")


def _session_label(session_dir: Path) -> str:
    meta_path = _session_meta_path(session_dir)
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(meta, dict) and meta.get("name"):
                return str(meta["name"])
        except Exception:
            pass
    return session_dir.name


def _session_dirs(project: Path) -> list[Path]:
    sessions_root = project / "sessions"
    if not sessions_root.exists():
        return []
    sessions = [
        path
        for path in sessions_root.iterdir()
        if path.is_dir() and not path.name.startswith(".")
    ]
    return sorted(sessions, key=lambda path: path.stat().st_mtime, reverse=True)


def _create_session(project: Path, name: str) -> Path:
    from datetime import datetime

    sessions_root = project / "sessions"
    sessions_root.mkdir(parents=True, exist_ok=True)
    slug = _slugify_session_name(name)
    stem = f"{datetime.now().strftime('%Y-%m-%d-%H%M')}-{slug}"
    session_dir = sessions_root / stem
    counter = 2
    while session_dir.exists():
        session_dir = sessions_root / f"{stem}-{counter}"
        counter += 1
    session_dir.mkdir(parents=True)
    (session_dir / "files").mkdir()
    (session_dir / "outputs").mkdir()
    _write_session_meta(session_dir, name=name, parent=project)
    return session_dir.resolve()


def _choose_session(project: Path, *, non_interactive: bool) -> Path:
    sessions = _session_dirs(project)
    if not sessions:
        raise SystemExit(f"no saved sessions found under {project / 'sessions'}")
    if non_interactive or not sys.stdin.isatty():
        return sessions[0].resolve()

    print("Resume session")
    for index, session_dir in enumerate(sessions, start=1):
        label = _session_label(session_dir)
        print(f"  {index}. {label} — {session_dir.name}")
    raw = _prompt("Select", default="1")
    try:
        return sessions[int(raw) - 1].resolve()
    except (ValueError, IndexError):
        raise SystemExit(f"invalid session selection: {raw}") from None


def _resolve_session_workspace(
    *,
    project: Path,
    session_mode: str | None,
    session_name: str | None,
    session_path: str | None,
    input_file: str | None,
    task: str | None,
    non_interactive: bool,
) -> tuple[Path, str]:
    if session_path:
        selected = Path(session_path).expanduser().resolve()
        selected.mkdir(parents=True, exist_ok=True)
        if not _session_meta_path(selected).exists():
            _write_session_meta(selected, name=selected.name, parent=project)
        return selected, "selected"

    modes = ["new", "resume", "folder"]
    labels = {
        "new": "Start a new session folder",
        "resume": "Resume an old session folder",
        "folder": "Use selected folder directly",
    }
    mode = session_mode
    if mode is None:
        if non_interactive or not sys.stdin.isatty():
            mode = "folder"
        else:
            mode = _select_from_list(
                title="Session workspace",
                values=modes,
                labels=labels,
                default="new",
                non_interactive=False,
            )

    if mode == "folder":
        return project, "folder"
    if mode == "resume":
        return _choose_session(project, non_interactive=non_interactive), "resumed"
    if mode == "new":
        default_name = task or None
        if not default_name and input_file:
            file_path, inferred_task = _parse_file_and_optional_task(input_file)
            default_name = inferred_task or file_path.stem
        if not default_name:
            default_name = "session"
        name = session_name or (
            default_name
            if non_interactive or not sys.stdin.isatty()
            else _prompt("Session name", default=default_name)
        )
        return _create_session(project, name), "created"

    raise SystemExit(f"unknown session mode: {mode}")


def _select_from_list(
    *,
    title: str,
    values: list[str],
    labels: dict[str, str],
    default: str,
    non_interactive: bool,
) -> str:
    if non_interactive or not sys.stdin.isatty():
        return default
    print(title)
    for index, value in enumerate(values, start=1):
        label = labels.get(value, value)
        marker = " (current)" if value == default else ""
        print(f"  {index}. {value} — {label}{marker}")
    raw = _prompt("Select", default=str(values.index(default) + 1 if default in values else 1))
    try:
        selected = values[int(raw) - 1]
    except (ValueError, IndexError):
        raise SystemExit(f"invalid selection: {raw}") from None
    return selected


def _profile_updates(
    *,
    config: SovereignConfig,
    profile_name: str | None,
    runtime: str | None,
    model: str | None,
    num_ctx: int | None,
    openai_base_url: str | None,
    ollama_host: str | None,
    agent: str | None,
    agent_cli: str | None,
    agent_workdir: Path | None,
) -> dict:
    updates: dict[str, object] = {}
    if profile_name:
        profiles = load_model_profiles(config.engine_base)
        if profile_name not in profiles:
            names = ", ".join(sorted(profiles)) or "(none)"
            raise SystemExit(f"unknown profile: {profile_name}. Available profiles: {names}")
        updates["SOVEREIGN_MODEL_PROFILE"] = profile_name
        profile = profiles.get(profile_name, {})
        if isinstance(profile, dict):
            selected_runtime = str(runtime or profile.get("runtime") or "").lower()
            if runtime is None and profile.get("runtime"):
                updates["SOVEREIGN_RUNTIME"] = profile["runtime"]
            if model is None and profile.get("model"):
                updates["SOVEREIGN_MODEL"] = profile["model"]
            if num_ctx is None and profile.get("num_ctx"):
                updates["SOVEREIGN_NUM_CTX"] = profile["num_ctx"]
            if profile.get("ollama_api"):
                updates["SOVEREIGN_OLLAMA_API"] = profile["ollama_api"]
            if openai_base_url is None and profile.get("openai_base_url"):
                updates["SOVEREIGN_OPENAI_BASE_URL"] = profile["openai_base_url"]
                updates["REMAIND_OPENAI_BASE_URL"] = profile["openai_base_url"]
            if selected_runtime == "ollama" and openai_base_url is None:
                updates["SOVEREIGN_OPENAI_BASE_URL"] = None
                updates["REMAIND_OPENAI_BASE_URL"] = None
                updates["REMAIND_OPENAI_MODEL"] = None
            if agent is None and profile.get("agent"):
                updates["SOVEREIGN_AGENT"] = profile["agent"]
            if agent_cli is None and profile.get("agent_cli"):
                updates["SOVEREIGN_AGENT_CLI"] = profile["agent_cli"]
            _apply_profile_agent_defaults(
                updates=updates,
                profile_name=profile_name,
                profile=profile,
                agent=agent,
                agent_cli=agent_cli,
                agent_workdir=agent_workdir,
            )

    if runtime:
        updates["SOVEREIGN_RUNTIME"] = runtime
    if model:
        updates["SOVEREIGN_MODEL"] = model
    if num_ctx is not None:
        updates["SOVEREIGN_NUM_CTX"] = num_ctx
    if ollama_host:
        updates["OLLAMA_HOST"] = ollama_host.rstrip("/")
    if openai_base_url:
        updates["SOVEREIGN_OPENAI_BASE_URL"] = openai_base_url.rstrip("/")
        updates["REMAIND_OPENAI_BASE_URL"] = openai_base_url.rstrip("/")
    if agent:
        updates["SOVEREIGN_AGENT"] = agent
    if agent_cli:
        updates["SOVEREIGN_AGENT_CLI"] = agent_cli
    if agent_workdir is not None:
        updates["SOVEREIGN_AGENT_WORKDIR"] = str(agent_workdir)
    return updates


def _memory_mode_updates(mode: str) -> dict[str, object]:
    key = (mode or "turbo").strip().lower()
    settings = memory_mode_settings(key)
    return {
        "SOVEREIGN_MEMORY_MODE": key,
        "REMAIND_MEMORY_MODE": key,
        "SOVEREIGN_COMPACTION_NUM_PREDICT": settings["compaction_num_predict"],
        "RESUME_MEMORIES": settings["resume_memories"],
        "RESUME_EXCERPTS": settings["resume_excerpts"],
    }


def _agent_defaults_for_profile(profile_name: str) -> dict[str, str]:
    if profile_name.startswith("qwen"):
        return {
            "SOVEREIGN_AGENT": "qwen-code",
            "SOVEREIGN_AGENT_CLI": "qwen",
            "SOVEREIGN_AGENT_WORKDIR": "~/Documents/Qwen-Code",
        }
    return {}


def _resolve_agent_executable(agent_cli: str, install_bin: Path) -> str:
    candidates: list[Path] = []
    for entry in os.environ.get("PATH", "").split(os.pathsep):
        if entry:
            candidates.append(Path(entry) / agent_cli)
    candidates.extend(
        [
            install_bin / agent_cli,
            Path("/opt/homebrew/bin") / agent_cli,
            Path("/usr/local/bin") / agent_cli,
            Path("/usr/bin") / agent_cli,
        ]
    )
    for candidate in candidates:
        if not candidate.exists() or not os.access(candidate, os.X_OK):
            continue
        try:
            text = candidate.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            text = ""
        if "sovereign-memory-starter managed launcher" in text:
            continue
        return str(candidate)
    resolved = shutil.which(agent_cli)
    if resolved:
        return resolved
    raise SystemExit(f"agent CLI not found: {agent_cli}")


def _launch_agent(config: SovereignConfig) -> None:
    startup_prompt, _ = build_startup_prompt(config)
    write_agent_bridge(config)
    config.agent_workdir.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PATH"] = f"{config.install_bin}{os.pathsep}{env.get('PATH', '')}"
    env["SOVEREIGN_MEMORY_ATTACHED"] = "1"

    if config.agent == "console":
        subprocess.run(
            [sys.executable, str(config.engine_base / "scripts/sovereign.py"), "chat"],
            cwd=config.engine_base,
            env=env,
            check=True,
        )
        return

    agent_exe = _resolve_agent_executable(config.agent_cli, config.install_bin)
    if config.agent == "qwen-code":
        cmd = [
            agent_exe,
            "--include-directories",
            str(config.base),
            "--append-system-prompt",
            startup_prompt,
            "--yolo",
        ]
    else:
        cmd = [agent_exe]

    subprocess.run(cmd, cwd=config.agent_workdir, env=env, check=True)


def _apply_profile_agent_defaults(
    *,
    updates: dict[str, object],
    profile_name: str,
    profile: dict,
    agent: str | None,
    agent_cli: str | None,
    agent_workdir: Path | None,
) -> None:
    defaults = _agent_defaults_for_profile(profile_name)
    if agent is None and not profile.get("agent") and defaults.get("SOVEREIGN_AGENT"):
        updates["SOVEREIGN_AGENT"] = defaults["SOVEREIGN_AGENT"]
    if agent_cli is None and not profile.get("agent_cli") and defaults.get("SOVEREIGN_AGENT_CLI"):
        updates["SOVEREIGN_AGENT_CLI"] = defaults["SOVEREIGN_AGENT_CLI"]
    if (
        agent_workdir is None
        and not profile.get("agent_workdir")
        and defaults.get("SOVEREIGN_AGENT_WORKDIR")
    ):
        updates["SOVEREIGN_AGENT_WORKDIR"] = defaults["SOVEREIGN_AGENT_WORKDIR"]


def run_launch(args: argparse.Namespace, config: SovereignConfig) -> None:
    caller_pwd = Path(os.environ.get("REMAIND_CALLER_PWD") or Path.cwd()).expanduser().resolve()
    profiles = load_model_profiles(config.base)
    profile_names = list(profiles)
    profile_labels = {
        name: str(profile.get("label", name)) if isinstance(profile, dict) else name
        for name, profile in profiles.items()
    }

    print("Remaind Launch")
    print("Local-first memory: on")
    print("Cloud memory: off")
    print("")

    if args.path:
        project = Path(args.path).expanduser().resolve()
    elif args.non_interactive or not sys.stdin.isatty():
        project = caller_pwd
    elif _yes_no(f"Use current folder {caller_pwd}?", default=True):
        project = caller_pwd
    else:
        project = Path(_prompt("Project folder", default=str(config.agent_workdir))).expanduser().resolve()

    if not project.exists():
        if args.non_interactive or _yes_no(f"Create folder {project}?", default=True):
            project.mkdir(parents=True, exist_ok=True)
        else:
            raise SystemExit(f"folder does not exist: {project}")

    session_workspace, session_status = _resolve_session_workspace(
        project=project,
        session_mode=args.session,
        session_name=args.session_name,
        session_path=args.session_path,
        input_file=args.file,
        task=args.task,
        non_interactive=args.non_interactive,
    )

    profile = args.profile
    if profile is None and profile_names:
        profile = _select_from_list(
            title="Select model profile",
            values=profile_names,
            labels=profile_labels,
            default=config.model_profile if config.model_profile in profiles else profile_names[0],
            non_interactive=args.non_interactive,
        )

    updates = _profile_updates(
        config=config,
        profile_name=profile,
        runtime=args.runtime,
        model=args.model,
        num_ctx=args.num_ctx,
        openai_base_url=args.openai_base_url,
        ollama_host=args.ollama_host,
        agent=args.agent,
        agent_cli=args.agent_cli,
        agent_workdir=session_workspace,
    )
    updates.update(_memory_mode_updates(args.memory_mode or "turbo"))
    updates["SOVEREIGN_CONTEXT_ROOT"] = str(session_workspace)
    if updates:
        write_env_file(config.engine_base, updates)
    config = SovereignConfig.from_env(base=config.engine_base)

    print("")
    print("Activating Remaind memory...")
    result = apply_setup(config)
    report = result["doctor"]
    print("")
    print("Remaind Memory: ACTIVE")
    print(f"Project:       {project}")
    print(f"Session:       {config.agent_workdir} ({session_status})")
    print(f"Engine root:   {config.engine_base}")
    print(f"Context store: {config.base / '.context'}")
    print(f"Runtime:       {config.runtime}")
    print(f"Model:         {config.model}")
    print(f"Remaind mode:  {config.memory_mode}")
    print(f"Status:        {'ready' if report.get('ready') else 'blocked'}")
    print("")
    print_doctor(report)

    if not report.get("ready"):
        if args.non_interactive or not _yes_no(
            "Readiness is blocked. Continue with memory-only workflow?", default=False
        ):
            raise SystemExit("launch stopped because readiness is blocked")

    mode = args.input_mode
    modes = ["paste", "file", "resume", "empty", "agent"]
    if mode is None:
        mode = _select_from_list(
            title="How do you want to start?",
            values=modes,
            labels={
                "paste": "Paste prompt safely",
                "file": "Load prompt from file",
                "resume": "Show resume/startup packet",
                "empty": "Memory active, no initial source",
                "agent": "Start configured agent now",
            },
            default="agent",
            non_interactive=args.non_interactive,
        )

    if mode == "resume":
        _prompt_text, resume_result = build_startup_prompt(config)
        startup_path = config.base / ".context" / "active" / "startup_prompt.md"
        print(f"Startup prompt: {startup_path}")
        print(
            f"Resume packet:  {resume_result.packet.token_count}/"
            f"{resume_result.packet.token_cap} tokens"
        )
        return

    if mode == "file":
        raw_file = args.file or _prompt("Prompt file", default="")
        file_path, inferred_task = _parse_file_and_optional_task(raw_file)
        if not file_path.exists():
            raise SystemExit(
                f"file does not exist: {file_path}\n"
                "Tip: enter the file path first. You may put the task after it, "
                'for example: /path/to/file.md "solve this puzzle"'
            )
        task = args.task or inferred_task or _prompt("Task", default="Solve this task")
        sys.stdout.flush()
        cmd = [
            str(config.install_bin / "remaind"),
            "run",
            str(file_path),
            task,
            "--path",
            str(config.base),
            "--num-ctx",
            str(config.num_ctx),
        ]
        if args.packet_tokens is not None:
            cmd.extend(["--token-cap", str(args.packet_tokens)])
        if args.answer_key:
            cmd.extend(["--answer-key", args.answer_key])
        if args.require_answer_key_pass:
            cmd.append("--require-answer-key-pass")
        subprocess.run(cmd, cwd=config.base, check=True)
        return

    if mode == "paste":
        print("Paste the prompt now. Finish with Ctrl-D.")
        content = sys.stdin.read()
        if not content.strip():
            raise SystemExit("no pasted content received")
        capture_dir = config.base / ".context" / "captured_prompts"
        capture_dir.mkdir(parents=True, exist_ok=True)
        capture_path = capture_dir / "launch_paste.md"
        capture_path.write_text(content, encoding="utf-8")
        task = args.task or "Solve this pasted task"
        sys.stdout.flush()
        cmd = [
            str(config.install_bin / "remaind"),
            "run",
            str(capture_path),
            task,
            "--path",
            str(config.base),
            "--num-ctx",
            str(config.num_ctx),
        ]
        if args.packet_tokens is not None:
            cmd.extend(["--token-cap", str(args.packet_tokens)])
        if args.answer_key:
            cmd.extend(["--answer-key", args.answer_key])
        if args.require_answer_key_pass:
            cmd.append("--require-answer-key-pass")
        subprocess.run(cmd, cwd=config.base, check=True)
        return

    if mode == "empty":
        print("Memory is active. Start your session normally when ready.")
        print(f"Agent folder: {config.agent_workdir}")
        print(f"Start agent:  {config.install_bin / 'remaind'}")
        return

    if mode == "agent":
        _launch_agent(config)
        return

    raise SystemExit(f"unknown launch input mode: {mode}")


def print_doctor(report: dict) -> None:
    checks = report.get("checks") or []
    if checks:
        print(f"readiness:          {'ready' if report.get('ready') else 'blocked'}")
        print("")
        for item in checks:
            marker = {
                "ok": "[OK]",
                "warn": "[WARN]",
                "fail": "[FAIL]",
            }.get(item.get("status"), "[INFO]")
            print(f"{marker} {item.get('label')}: {item.get('detail')}")
            if item.get("fix"):
                print(f"      fix: {item['fix']}")
        print("")

    print(f"context root:       {report['base']}")
    if report.get("engine_base"):
        print(f"engine root:        {report['engine_base']}")
    print(f"runtime:            {report['runtime']}")
    print(f"agent:              {report['agent']}")
    print(f"agent CLI:          {report['agent_cli']}")
    print(f"agent workdir:      {report['agent_workdir']}")
    print(f"install bin:        {report['install_bin']}")
    print(f"profile:            {report['profile']}")
    print(f"Remaind valid:      {report['remaind_ok']}")
    print(f"Ollama host:        {report['ollama_host']}")
    print(f"Ollama API:         {report.get('ollama_api', 'auto')}")
    if report.get("openai_base_url"):
        print(f"OpenAI base URL:    {report['openai_base_url']}")
    print(f"model:              {report['model']}")
    print(f"model installed:    {report['model_present']}")
    print(f"configured num_ctx: {report['num_ctx']}")
    packet_policy = report.get("packet_policy") or {}
    if packet_policy:
        print(
            "packet policy:      "
            f"{packet_policy.get('packet_tokens')} token packet "
            f"({packet_policy.get('label')})"
        )
    if report.get("model_context_length"):
        print(f"model context:      {report['model_context_length']}")
    if report.get("model_parameters"):
        print(f"model parameters:   {report['model_parameters']}")
    if report.get("capabilities"):
        print(f"capabilities:       {', '.join(report['capabilities'])}")
    if report.get("remaind_failed"):
        print("Remaind failures:")
        for label, reason in report["remaind_failed"]:
            print(f"  - {label}: {reason}")


def print_setup_result(result: dict) -> None:
    action = "created" if result["context_created"] else "refreshed"
    print(f"Sovereign memory {action}.")
    print(f"Startup prompt: {result['startup_prompt']}")
    if result.get("master_prompt"):
        print(f"Master prompt:  {result['master_prompt']}")
    if result.get("agent_bridge_paths"):
        print(f"Agent bridge:   {', '.join(result['agent_bridge_paths'])}")
    print(f"Resume packet:  {result['resume_tokens']}/{result['resume_token_cap']} tokens")
    print("")
    print_doctor(result["doctor"])


def run_monitor(args: argparse.Namespace, config: SovereignConfig) -> int:
    report = doctor(config, smoke=args.smoke)
    warnings = report.get("warnings") or []
    blockers = report.get("blockers") or []
    alert = bool(blockers) or (args.alert_on_warning and bool(warnings))
    status = "ALERT" if alert else "OK"
    payload = {
        "status": status,
        "ready": report.get("ready"),
        "blocker_count": len(blockers),
        "warning_count": len(warnings),
        "model": report.get("model"),
        "runtime": report.get("runtime"),
        "generation_ok": report.get("generation_ok"),
        "generation_detail": report.get("generation_detail"),
        "packet_policy": report.get("packet_policy"),
        "startup_prompt": report.get("startup_prompt"),
    }

    if alert or args.log_ok:
        event_id = log_event(
            config,
            event_type="error" if alert else "tool_result",
            actor="remaind monitor",
            summary=f"Remaind monitor {status.lower()}",
            content=json.dumps(report, indent=2, sort_keys=True),
            importance=3 if alert else 1,
            tags=["monitor", status.lower()],
            metadata=payload,
        )
        payload["event_id"] = event_id

    if args.as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"Remaind monitor: {status}")
        print(f"ready: {report.get('ready')}")
        print(f"blockers: {len(blockers)}")
        print(f"warnings: {len(warnings)}")
        print(f"model: {report.get('model')}")
        if report.get("generation_ok") is not None:
            print(f"generation: {report.get('generation_detail')}")
        policy = report.get("packet_policy") or {}
        if policy:
            print(
                "packet policy: "
                f"{policy.get('packet_tokens')} tokens "
                f"({policy.get('label')})"
            )
        if payload.get("event_id"):
            print(f"alert event: {payload['event_id']}")
    return 2 if alert else 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Operate a local sovereign memory system.")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("bootstrap", help="seed initial Remaind state after install")
    setup = sub.add_parser("setup", help="configure and refresh local sovereign memory")
    setup.add_argument("--profile", "--model-profile", dest="profile", default=None)
    setup.add_argument("--runtime", default=None)
    setup.add_argument("--model", default=None)
    setup.add_argument("--num-ctx", type=int, default=None)
    setup.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default=None,
        help="Remaind memory packet mode for any model",
    )
    setup.add_argument("--ollama-host", default=None)
    setup.add_argument("--openai-base-url", default=None)
    setup.add_argument("--agent", choices=["qwen-code", "deepseek-code", "console"], default=None)
    setup.add_argument("--agent-cli", default=None)
    setup.add_argument("--agent-workdir", "--qwen-workdir", dest="agent_workdir", default=None)
    setup.add_argument("--install-bin", default=None)

    launch = sub.add_parser("launch", help="guided Remaind memory launcher")
    launch.add_argument("--path", default=None, help="agent/session folder to attach")
    launch.add_argument("--profile", "--model-profile", dest="profile", default=None)
    launch.add_argument("--runtime", default=None)
    launch.add_argument("--model", default=None)
    launch.add_argument("--num-ctx", type=int, default=None)
    launch.add_argument(
        "--memory-mode",
        choices=["turbo", "standard", "deep"],
        default="turbo",
        help="Remaind memory packet mode for any model",
    )
    launch.add_argument("--ollama-host", default=None)
    launch.add_argument("--openai-base-url", default=None)
    launch.add_argument(
        "--packet-tokens",
        type=int,
        default=None,
        help="force the run evidence packet token budget; default uses product-standard context bands",
    )
    launch.add_argument("--agent", choices=["qwen-code", "deepseek-code", "console"], default=None)
    launch.add_argument("--agent-cli", default=None)
    launch.add_argument(
        "--input",
        dest="input_mode",
        choices=["paste", "file", "resume", "empty", "agent"],
        default=None,
    )
    launch.add_argument("--file", default=None)
    launch.add_argument("--task", default=None)
    launch.add_argument("--answer-key", default=None)
    launch.add_argument("--require-answer-key-pass", action="store_true")
    launch.add_argument(
        "--session",
        choices=["new", "resume", "folder"],
        default=None,
        help="session workspace mode",
    )
    launch.add_argument("--session-name", default=None)
    launch.add_argument("--session-path", default=None)
    launch.add_argument("--json", action="store_true", dest="as_json")
    launch.add_argument("--non-interactive", action="store_true")

    doctor_parser = sub.add_parser("doctor", help="check Remaind and Ollama/model readiness")
    doctor_parser.add_argument(
        "--smoke",
        action="store_true",
        help="run a tiny real generation check against the configured model",
    )
    monitor_parser = sub.add_parser("monitor", help="run health monitor and log alerts")
    monitor_parser.add_argument("--smoke", action="store_true")
    monitor_parser.add_argument("--alert-on-warning", action="store_true")
    monitor_parser.add_argument("--log-ok", action="store_true")
    monitor_parser.add_argument("--json", action="store_true", dest="as_json")
    sub.add_parser("status", help="show Remaind status")
    sub.add_parser("validate", help="validate .context")
    sub.add_parser("resume", help="build .context/active/resume_packet.md")
    sub.add_parser("startup", help="build .context/active/startup_prompt.md")
    sub.add_parser("tune-thresholds", help="tune Remaind thresholds to configured context window")
    sub.add_parser("profiles", help="list model profiles")
    bench = sub.add_parser("bench", help="run the sovereign beyond-context benchmark")
    bench.add_argument("--target-tokens", type=int, default=1_000_000)
    bench.add_argument("--force", action="store_true")
    proof_2m = sub.add_parser(
        "proof-2m",
        help="run the terminal-visible 2M-token model A/B proof",
    )
    proof_2m.add_argument("--target-tokens", type=int, default=2_000_000)
    proof_2m.add_argument("--workdir", default=None)
    proof_2m.add_argument("--model", default=None)
    proof_2m.add_argument("--num-ctx", type=int, default=None)
    proof_2m.add_argument("--tail-lines", type=int, default=5000)
    proof_2m.add_argument("--skip-tail-control", action="store_true")
    proof_2m.add_argument("--keep-workdir", action="store_true")
    model_test = sub.add_parser(
        "model-test",
        help="battle-test Remaind memory compatibility against local models",
    )
    model_test.add_argument("--models", default=None)
    model_test.add_argument("--installed", action="store_true")
    model_test.add_argument("--workdir", default=None)
    model_test.add_argument("--force", action="store_true")
    model_test.add_argument("--skip-model", action="store_true")
    model_test.add_argument("--json", action="store_true", dest="as_json")
    llama_server = sub.add_parser(
        "llama-server",
        help="start a llama.cpp OpenAI-compatible local model server",
    )
    llama_server.add_argument("--binary", default=None)
    llama_server.add_argument("--model-path", default=None)
    llama_server.add_argument("--alias", default=None)
    llama_server.add_argument("--host", default="127.0.0.1")
    llama_server.add_argument("--port", type=int, default=18080)
    llama_server.add_argument("--ctx-size", type=int, default=None)
    llama_server.add_argument("--webui", action="store_true")
    llama_server.add_argument("--extra-arg", action="append", default=[])

    compact = sub.add_parser("compact", help="compact with the configured local model")
    compact.add_argument("--timeout", type=float, default=None)

    ask = sub.add_parser("ask", help="ask the local model with the current Remaind startup prompt")
    ask.add_argument("prompt", nargs="*", help="prompt to send")

    sub.add_parser("chat", help="start an interactive local console with Remaind memory")

    log = sub.add_parser("log", help="append a Remaind event")
    log.add_argument("event_type")
    log.add_argument("actor")
    log.add_argument("summary")
    log.add_argument("--content", default=None)
    log.add_argument("--importance", type=int, default=1)
    log.add_argument("--tag", action="append", default=[])
    log.add_argument("--metadata-json", default=None)

    args = parser.parse_args()
    config = SovereignConfig.from_env()

    if args.command == "bootstrap":
        tune_thresholds(config)
        bootstrap_context(config)
        build_startup_prompt(config)
        print("Bootstrapped local sovereign memory context.")
        return

    if args.command == "setup":
        updates = {}
        if args.profile:
            profiles = load_model_profiles(config.engine_base)
            if args.profile not in profiles:
                names = ", ".join(sorted(profiles)) or "(none)"
                raise SystemExit(f"unknown profile: {args.profile}. Available profiles: {names}")
            updates["SOVEREIGN_MODEL_PROFILE"] = args.profile
            profile = profiles.get(args.profile, {})
            if isinstance(profile, dict):
                if args.runtime is None and profile.get("runtime"):
                    updates["SOVEREIGN_RUNTIME"] = profile["runtime"]
                if args.model is None and profile.get("model"):
                    updates["SOVEREIGN_MODEL"] = profile["model"]
                if args.num_ctx is None and profile.get("num_ctx"):
                    updates["SOVEREIGN_NUM_CTX"] = profile["num_ctx"]
                if profile.get("ollama_api"):
                    updates["SOVEREIGN_OLLAMA_API"] = profile["ollama_api"]
                if args.openai_base_url is None and profile.get("openai_base_url"):
                    updates["SOVEREIGN_OPENAI_BASE_URL"] = profile["openai_base_url"]
                if args.agent is None and profile.get("agent"):
                    updates["SOVEREIGN_AGENT"] = profile["agent"]
                if args.agent_cli is None and profile.get("agent_cli"):
                    updates["SOVEREIGN_AGENT_CLI"] = profile["agent_cli"]
                if args.agent_workdir is None and profile.get("agent_workdir"):
                    updates["SOVEREIGN_AGENT_WORKDIR"] = profile["agent_workdir"]
        if args.runtime:
            updates["SOVEREIGN_RUNTIME"] = args.runtime
        if args.model:
            updates["SOVEREIGN_MODEL"] = args.model
        if args.num_ctx is not None:
            updates["SOVEREIGN_NUM_CTX"] = args.num_ctx
        if args.ollama_host:
            updates["OLLAMA_HOST"] = args.ollama_host.rstrip("/")
        if args.openai_base_url:
            updates["SOVEREIGN_OPENAI_BASE_URL"] = args.openai_base_url.rstrip("/")
        if args.agent:
            updates["SOVEREIGN_AGENT"] = args.agent
        if args.agent_cli:
            updates["SOVEREIGN_AGENT_CLI"] = args.agent_cli
        if args.agent_workdir:
            updates["SOVEREIGN_AGENT_WORKDIR"] = args.agent_workdir
        if args.install_bin:
            updates["INSTALL_BIN"] = args.install_bin
        if args.memory_mode:
            updates.update(_memory_mode_updates(args.memory_mode))

        if updates:
            write_env_file(config.engine_base, updates)
            config = SovereignConfig.from_env(base=config.engine_base)

        print_setup_result(apply_setup(config))
        return

    if args.command == "launch":
        run_launch(args, config)
        return

    if args.command == "tune-thresholds":
        tune_thresholds(config)
        print(f"Tuned thresholds for num_ctx={config.num_ctx}.")
        return

    if args.command == "profiles":
        profiles = load_model_profiles(config.engine_base)
        for name, profile in profiles.items():
            label = profile.get("label", name) if isinstance(profile, dict) else name
            model = profile.get("model", "") if isinstance(profile, dict) else ""
            num_ctx = profile.get("num_ctx", "") if isinstance(profile, dict) else ""
            agent = profile.get("agent", "") if isinstance(profile, dict) else ""
            workdir = profile.get("agent_workdir", "") if isinstance(profile, dict) else ""
            suffix = f" agent={agent}" if agent else ""
            suffix += f" workdir={workdir}" if workdir else ""
            print(f"{name:18} {model:36} ctx={num_ctx}  {label}{suffix}")
        return

    if args.command == "bench":
        cmd = [
            str(config.engine_base / ".venv/bin/remaind"),
            "bench",
            "sovereign",
            "--workdir",
            str(config.engine_base / ".sovereign_bench"),
            "--target-tokens",
            str(args.target_tokens),
        ]
        if args.force:
            cmd.append("--force")
        subprocess.run(cmd, cwd=config.engine_base, check=True)
        return

    if args.command == "proof-2m":
        cmd = [
            sys.executable,
            str(config.engine_base / "scripts/proof_2m.py"),
            "--target-tokens",
            str(args.target_tokens),
            "--tail-lines",
            str(args.tail_lines),
        ]
        if args.workdir:
            cmd.extend(["--workdir", args.workdir])
        if args.model:
            cmd.extend(["--model", args.model])
        if args.num_ctx is not None:
            cmd.extend(["--num-ctx", str(args.num_ctx)])
        if args.skip_tail_control:
            cmd.append("--skip-tail-control")
        if args.keep_workdir:
            cmd.append("--keep-workdir")
        subprocess.run(cmd, cwd=config.engine_base, check=True)
        return

    if args.command == "model-test":
        cmd = [
            sys.executable,
            str(config.engine_base / "scripts/model_battle_test.py"),
        ]
        if args.models:
            cmd.extend(["--models", args.models])
        if args.installed:
            cmd.append("--installed")
        if args.workdir:
            cmd.extend(["--workdir", args.workdir])
        if args.force:
            cmd.append("--force")
        if args.skip_model:
            cmd.append("--skip-model")
        if args.as_json:
            cmd.append("--json")
        subprocess.run(cmd, cwd=config.engine_base, check=True)
        return

    if args.command == "llama-server":
        binary = (
            args.binary
            or os.environ.get("SOVEREIGN_LLAMA_SERVER_BIN")
            or shutil.which("llama-server")
        )
        if not binary:
            raise SystemExit(
                "llama-server binary not found. Pass --binary or set SOVEREIGN_LLAMA_SERVER_BIN."
            )
        model_path = args.model_path or os.environ.get("SOVEREIGN_LLAMA_MODEL_PATH")
        if not model_path:
            raise SystemExit(
                "model path is required. Pass --model-path or set SOVEREIGN_LLAMA_MODEL_PATH."
            )
        alias = args.alias or config.model
        ctx_size = args.ctx_size or config.num_ctx
        cmd = [
            binary,
            "-m",
            model_path,
            "--alias",
            alias,
            "--host",
            args.host,
            "--port",
            str(args.port),
            "--ctx-size",
            str(ctx_size),
            "--reasoning",
            "off",
            "--reasoning-format",
            "none",
        ]
        if not args.webui:
            cmd.append("--no-webui")
        cmd.extend(args.extra_arg)
        print(f"Starting llama-server for {alias} at http://{args.host}:{args.port}/v1")
        subprocess.run(cmd, cwd=config.engine_base, check=True)
        return

    if args.command == "doctor":
        print_doctor(doctor(config, smoke=args.smoke))
        return

    if args.command == "monitor":
        raise SystemExit(run_monitor(args, config))

    if args.command == "status":
        subprocess.run(
            [
                str(config.engine_base / ".venv/bin/remaind"),
                "status",
                "--path",
                str(config.base),
            ],
            cwd=config.engine_base,
            check=True,
        )
        return

    if args.command == "validate":
        subprocess.run(
            [
                str(config.engine_base / ".venv/bin/remaind"),
                "validate",
                "--path",
                str(config.base),
            ],
            cwd=config.engine_base,
            check=True,
        )
        return

    if args.command == "resume":
        tune_thresholds(config)
        result = remaind.resume(
            config.base,
            k_memories=config.resume_memories,
            raw_excerpt_count=config.resume_excerpts,
        )
        print(
            f"Resume packet written "
            f"({result.packet.token_count}/{result.packet.token_cap} tokens, "
            f"{len(result.packet.included_memory_ids)} memories, "
            f"{len(result.packet.included_event_ids)} raw excerpts)"
        )
        if result.packet.gate.concerns:
            print("resume gate concerns:")
            for concern in result.packet.gate.concerns:
                print(f"  - {concern}")
        return

    if args.command == "startup":
        tune_thresholds(config)
        prompt, result = build_startup_prompt(config)
        bridge_paths = write_agent_bridge(config)
        path = config.base / ".context" / "active" / "startup_prompt.md"
        print(
            f"Startup prompt written to {path} "
            f"({result.packet.token_count}/{result.packet.token_cap} resume tokens)"
        )
        if bridge_paths:
            print(f"Agent bridge refreshed: {', '.join(str(path) for path in bridge_paths)}")
        if result.packet.gate.concerns:
            print("resume gate concerns:")
            for concern in result.packet.gate.concerns:
                print(f"  - {concern}")
        return

    if args.command == "compact":
        if args.timeout is not None:
            config = replace(config, compaction_timeout=args.timeout)
        result = compact_with_local_model(config)
        print(render_compaction_result(result, model=config.model))
        return

    if args.command == "ask":
        prompt = " ".join(args.prompt).strip() or "Summarize current state and next step."
        answer, result = ask_local_model_with_memory(config, prompt)
        print(
            f"[memory] resume packet: {result.packet.token_count}/{result.packet.token_cap} tokens"
        )
        print(f"[model] {config.model}\n")
        print(answer)
        return

    if args.command == "chat":
        startup_prompt, result = build_startup_prompt(config)
        print(
            f"Sovereign console ready "
            f"({result.packet.token_count}/{result.packet.token_cap} resume tokens)."
        )
        print("Type /exit to stop.\n")
        messages = [{"role": "system", "content": model_system_prefix(config) + startup_prompt}]
        while True:
            try:
                user_text = input("you> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not user_text:
                continue
            if user_text in {"/exit", "/quit"}:
                break

            log_event(
                config,
                event_type="user_message",
                actor="user",
                summary=user_text[:120],
                content=user_text,
                importance=3,
                tags=["console"],
            )
            messages.append({"role": "user", "content": user_text})
            answer = local_chat(config, messages)
            messages.append({"role": "assistant", "content": answer})
            log_event(
                config,
                event_type="assistant_message",
                actor="assistant",
                summary=answer[:120],
                content=answer,
                importance=1,
                tags=["console"],
            )
            print(f"\nassistant> {answer}\n")

        build_startup_prompt(config)
        print("Session logged. Startup prompt refreshed.")
        return

    if args.command == "log":
        metadata = json.loads(args.metadata_json) if args.metadata_json else None
        event_id = log_event(
            config,
            event_type=args.event_type,
            actor=args.actor,
            summary=args.summary,
            content=args.content,
            importance=args.importance,
            tags=args.tag,
            metadata=metadata,
        )
        print(event_id)
        return

    raise SystemExit(f"unknown command: {args.command}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"sovereign: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
