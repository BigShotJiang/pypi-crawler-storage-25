from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sovereign_memory.runtime import (
    SovereignConfig,
    build_startup_prompt,
    local_chat,
    model_system_prefix,
)

BASE = Path(__file__).resolve().parents[1]
STORE = BASE / ".sovereign_proof"
ARCHIVE = STORE / "generated_continuity_archive.md"
INDEX = STORE / "index.json"
FINAL_PHRASE = "continuity survives rotation when state is source-linked"

SIGNALS = {
    "A": (36, "The test is not about storage. It is about continuity under model rotation."),
    "B": (1200, "Memory fails when operational causality is detached from facts."),
    "C": (2400, "The next model is the primary reader of the handoff."),
    "D": (4200, "A safe handoff must preserve source-linked execution state."),
    "E": (6600, "Facts, decisions, assumptions, open loops, and rejected paths must stay separate."),
    "F": (8800, "Search alone retrieves text but does not preserve authority, revocation, or causality."),
    "G": (10400, "Compression is safe only when reversible pointers exist."),
    "H": (11950, f"Final synthesis phrase: {FINAL_PHRASE}."),
}


def filler(line: int) -> str:
    return (
        f"Record {line:05d}. This filler line exists to create distance. "
        "It should not be enough to answer the final test without the signal index."
    )


def generate_archive(lines: int = 12000) -> dict[str, object]:
    STORE.mkdir(exist_ok=True)
    signal_by_line = {line: (key, text) for key, (line, text) in SIGNALS.items()}
    index: dict[str, object] = {
        "archive": str(ARCHIVE),
        "line_count": lines,
        "signals": {},
    }
    with ARCHIVE.open("w", encoding="utf-8") as handle:
        handle.write("# Sovereign Continuity Proof Archive\n\n")
        for line in range(1, lines + 1):
            if line in signal_by_line:
                key, text = signal_by_line[line]
                handle.write(f"SIGNAL {key}: {text}\n")
                index["signals"][key] = {"line": line + 2, "text": text}
            else:
                handle.write(f"{filler(line)}\n")
    INDEX.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return index


def load_index() -> dict[str, object]:
    if not INDEX.exists():
        raise SystemExit("proof index is missing; run `make proof` first")
    return json.loads(INDEX.read_text(encoding="utf-8"))


def fresh_lookup(signal: str) -> dict[str, object]:
    index = load_index()
    item = index["signals"][signal]
    return {"signal": signal, **item}


def run_fresh_lookup(signal: str) -> dict[str, object]:
    result = subprocess.run(
        [sys.executable, str(Path(__file__).resolve()), "lookup", "--signal", signal],
        cwd=BASE,
        text=True,
        capture_output=True,
        check=True,
    )
    return json.loads(result.stdout)


def run_proof(*, ask_model: bool) -> None:
    print("1. Generating a synthetic long archive...")
    index = generate_archive()
    print(f"   Archive: {ARCHIVE}")
    print(f"   Signals: {len(index['signals'])}")

    print("2. Looking up early signal from the current process...")
    early = fresh_lookup("A")
    print(f"   A line {early['line']}: {early['text']}")

    print("3. Looking up late signal from a separate fresh process...")
    late = run_fresh_lookup("H")
    print(f"   H line {late['line']}: {late['text']}")
    if FINAL_PHRASE not in str(late["text"]):
        raise AssertionError("fresh lookup failed to recover final phrase")

    print("4. Verifying cross-signal continuity answer...")
    signals = index["signals"]
    required = ["A", "B", "D", "E", "F", "G", "H"]
    for key in required:
        if key not in signals:
            raise AssertionError(f"missing signal {key}")
    print("   Deterministic proof: PASS")

    if ask_model:
        print("5. Asking the configured local model using only retrieved signals...")
        config = SovereignConfig.from_env()
        startup_prompt, result = build_startup_prompt(config)
        evidence = "\n".join(
            f"Signal {key}: {signals[key]['text']}" for key in sorted(signals)
        )
        prompt = (
            "Use only this retrieved local evidence. Explain the product category, "
            "why search alone is insufficient, and recover the final synthesis phrase.\n\n"
            f"{evidence}"
        )
        answer = local_chat(
            config,
            [
                {"role": "system", "content": model_system_prefix(config) + startup_prompt},
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
        )
        if FINAL_PHRASE not in answer.lower():
            raise AssertionError(f"model did not recover final phrase:\n{answer}")
        print(f"   Local model proof: PASS ({result.packet.token_count} resume tokens)")
        print()
        print(answer)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a synthetic sovereign memory continuity proof.")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("--ask-model", action="store_true")
    lookup = sub.add_parser("lookup")
    lookup.add_argument("--signal", required=True)
    args = parser.parse_args()

    if args.command == "run":
        run_proof(ask_model=args.ask_model)
        return
    if args.command == "lookup":
        print(json.dumps(fresh_lookup(args.signal.upper()), sort_keys=True))
        return
    raise SystemExit(f"unknown command: {args.command}")


if __name__ == "__main__":
    main()
