# Лабораторные работы

Студент: Гутман М.И.
Группа: 6304

## Структура проекта
- `part1_download.py` - скрипт для скачивания изображений
- `.gitignore` - список игнорируемых файлов
- `.flake8` - конфигурация линтера
для установки 
pip install --index-url https://pypi.org/simple/ --extra-index-url https://pypi.org/project/metetl-gutmanm-6304/0.1.1/ metetl-gutman-6304-l5

