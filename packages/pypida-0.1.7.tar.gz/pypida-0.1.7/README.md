# PyPIDA v0.1.2

Secure E2EE messaging protocol with Deterministic Identity. Optimized for Mobile.

## Quick Start
```python
from pypida.core import PIDA

# 1. Initialize (Auto-load or Create)
URL = "[https://your-relay.workers.dev](https://your-relay.workers.dev)"
client = PIDA.load_local(URL) or PIDA.create(URL)

print(f"Identity: {client.id}")

# 2. Encrypt for a peer
encrypted_msg = client.encrypt("Hello PIDA!", peer_public_key_pem)