import requests, uuid, base64, hashlib, os, json, time, math, shutil, tempfile
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class PIDA:
    def __init__(self, relay_url, seed_uuid, nickname="Anonymous", config_file=None):
        self.relay = relay_url.rstrip('/')
        self.id = seed_uuid
        self.nickname = nickname
        self.inbox = []
        self.block_list = []
        self.CONFIG_FILE = config_file or ".pida_config"
        
        # Identity Derivation
        seed = hashlib.sha256(self.id.encode()).digest()
        self.priv_key = ec.derive_private_key(int.from_bytes(seed, "big"), ec.SECP256R1())
        self.pub_key_pem = self.priv_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
        
        self._load_config()

    @classmethod
    def create(cls, relay_url, nickname="Anonymous", config_file=None):
        return cls(relay_url, str(uuid.uuid4()), nickname, config_file)

    # --- QUẢN LÝ INBOX ---
    def view_inbox(self):
        """Trả về danh sách tin nhắn hiện có trong máy"""
        return self.inbox

    def delete_message(self, msg_uuid):
        """Xóa một tin nhắn cụ thể khỏi máy bằng UUID"""
        original_len = len(self.inbox)
        self.inbox = [m for m in self.inbox if m.get('uuid') != msg_uuid]
        if len(self.inbox) < original_len:
            self._save_config()
            return True
        return False

    # --- QUẢN LÝ BLOCKLIST ---
    def get_blocklist(self):
        """Xem danh sách đen"""
        return self.block_list

    def add_block(self, target_uuid):
        """Thêm một ID vào danh sách chặn"""
        if target_uuid not in self.block_list:
            self.block_list.append(target_uuid)
            self._save_config()
            return True
        return False

    def remove_block(self, target_uuid):
        """Gỡ chặn cho một ID"""
        if target_uuid in self.block_list:
            self.block_list.remove(target_uuid)
            self._save_config()
            return True
        return False

    # --- HỆ THỐNG LƯU TRỮ & HEALTH ---
    def _save_config(self):
        data = {"uuid": self.id, "nickname": self.nickname, "block_list": self.block_list, "inbox": self.inbox}
        tmp_config = self.CONFIG_FILE + ".tmp"
        with open(tmp_config, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        shutil.move(tmp_config, self.CONFIG_FILE)
        if os.name != 'nt': 
            try: os.chmod(self.CONFIG_FILE, 0o600)
            except: pass

    def _load_config(self):
        if os.path.exists(self.CONFIG_FILE):
            try:
                with open(self.CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.id = data.get("uuid", self.id)
                    self.nickname = data.get("nickname", self.nickname)
                    self.block_list = data.get("block_list", [])
                    self.inbox = data.get("inbox", [])
            except: pass

    def health_check(self):
        """Kiểm tra status code của Worker & Backend"""
        try:
            res = requests.get(self.relay, timeout=5)
            c_res = requests.get(f"{self.relay}/challenge?address=test")
            return {"worker": res.status_code, "b2_api": c_res.status_code, "id": self.id}
        except Exception as e:
            return {"error": str(e)}

    # --- CORE MESSAGING ---
    def send_file(self, to_id, peer_pub_pem, filepath, chunk_size=512*1024):
        if not os.path.exists(filepath): return {"error": "File not found"}
        f_id = f"{int(time.time()*1000):x}-{uuid.uuid4()}"
        f_name = os.path.basename(filepath)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            temp_p = os.path.join(tmpdir, f_name)
            shutil.copy2(filepath, temp_p)
            with open(temp_p, "rb") as f:
                chunks = math.ceil(os.path.getsize(temp_p) / chunk_size)
                for i in range(chunks):
                    requests.post(f"{self.relay}/upload", json={
                        "file_id": f_id, "chunk_index": i, 
                        "data": base64.b64encode(f.read(chunk_size)).decode(), "to_id": to_id
                    })
            return self.send_message(to_id, peer_pub_pem, f"FILE_SHARE:{f_id}|NAME:{f_name}", is_file=True)

    def send_message(self, to_id, peer_pub_pem, content, is_file=False):
        m_id = f"{int(time.time()*1000):x}-{uuid.uuid4()}"
        key = self._get_shared_secret(peer_pub_pem)
        nonce = os.urandom(12)
        ct = AESGCM(key).encrypt(nonce, content.encode(), None)
        msg = {
            "id": m_id, "from": self.id, "nickname": self.nickname, "to": to_id,
            "content": base64.b64encode(nonce + ct).decode(),
            "type": "file" if is_file else "text", "timestamp": int(time.time()*1000),
            "sender_pub": self.pub_key_pem
        }
        # PoW Diff 4
        nonce_pow = 0
        while True:
            h = hashlib.sha256(f"{m_id}{nonce_pow}".encode()).hexdigest()
            if h.startswith('0000'): break
            nonce_pow += 1
        return requests.post(f"{self.relay}/send", json={"msg": msg, "pow": {"nonce": nonce_pow, "hash": h}}).json()

    def sync(self):
        try:
            c_res = requests.get(f"{self.relay}/challenge?address={self.id}").json()
            challenge = c_res['challenge']
            sig = self.priv_key.sign(challenge.encode(), ec.ECDSA(hashes.SHA256()))
            res = requests.post(f"{self.relay}/get", json={
                "address": self.id, "challenge": challenge, "signature": base64.b64encode(sig).decode()
            })
            if res.status_code != 200: return self.inbox
            
            for m in res.json().get('messages', []):
                if m['from'] in self.block_list:
                    self.ack(m['id']); continue
                try:
                    peer_key = self._get_shared_secret(m['sender_pub'])
                    raw = base64.b64decode(m['content'])
                    plain = AESGCM(peer_key).decrypt(raw[:12], raw[12:], None).decode()
                    
                    entry = {
                        "uuid": m['id'], "sender": m['from'], "nickname": m.get('nickname', 'Anon'),
                        "content": plain, "time": time.strftime('%H:%M:%S', time.localtime(m['timestamp']/1000))
                    }
                    if m['type'] == "file" and "FILE_SHARE:" in plain:
                        fid = plain.split('|')[0].split(':')[1]
                        entry["link"] = f"{self.relay}/get-file?file_id={fid}&to_id={self.id}"
                    
                    self.inbox.append(entry)
                    self.ack(m['id'])
                except: continue
            self._save_config()
            return self.inbox
        except: return self.inbox

    def ack(self, m_id):
        requests.post(f"{self.relay}/ack", json={"id": m_id, "address": self.id})

    def _get_shared_secret(self, pem):
        peer = serialization.load_pem_public_key(pem.encode())
        shared = self.priv_key.exchange(ec.ECDH(), peer)
        return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'pida-e2ee').derive(shared)

    def disconnect(self):
        self._save_config()
        self.inbox = []