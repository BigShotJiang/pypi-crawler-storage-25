"""Unit tests (no external dependencies)."""
