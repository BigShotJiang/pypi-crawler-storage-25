"""Structured denial + corrective-action types for the Clampd SDK.

Mirrors the v0.20 gateway JSON wire shape (`denial: StructuredDenial`).
The gateway emits this on every Deny/Downscope response; the SDK parses it
into typed objects so callers can pattern-match on the corrective variant
instead of parsing a free-text string.

LLM-facing rendering lives in `render_corrective_for_llm` — same template
set as the TypeScript SDK so error messages are identical across languages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Union

Confidence = Literal["high", "medium", "low"]
Source = Literal[
    "rule",
    "rule_dynamic",
    "scope",
    "boundary",
    "cedar",
    "sdk_override",
    "bundle",
    "gateway",
]


# ── Corrective action variants (one per oneof case) ──────────────────────


@dataclass(frozen=True)
class SwitchTool:
    tool: str
    scope: str | None = None


@dataclass(frozen=True)
class DownscopeTo:
    scope: str


@dataclass(frozen=True)
class RenameField:
    # `from` is a Python keyword — use trailing underscore. The JSON wire
    # key is still "from"; the parser maps both directions.
    from_: str
    to: str


@dataclass(frozen=True)
class RedactValue:
    json_path: str
    mask: str


@dataclass(frozen=True)
class SplitRequest:
    max_items_per_batch: int
    current_items: int


@dataclass(frozen=True)
class WaitAndRetry:
    retry_after_seconds: int
    window_label: str | None = None


@dataclass(frozen=True)
class RequestApproval:
    ticket_template_url: str
    approver_role: str | None = None


@dataclass(frozen=True)
class SwitchEndpoint:
    from_url: str
    to_url: str


@dataclass(frozen=True)
class NoCorrection:
    pass


CorrectiveActionVariant = Union[
    SwitchTool,
    DownscopeTo,
    RenameField,
    RedactValue,
    SplitRequest,
    WaitAndRetry,
    RequestApproval,
    SwitchEndpoint,
    NoCorrection,
]


@dataclass
class CorrectiveAction:
    """Typed corrective with a single `action` variant + LLM-facing metadata."""

    action: CorrectiveActionVariant
    human_explanation: str = ""
    confidence: Confidence = "medium"
    source: Source = "rule"

    @classmethod
    def from_json(cls, d: dict[str, Any] | None) -> "CorrectiveAction | None":
        if not d:
            return None
        action_obj = d.get("action") or {}
        variant = _parse_variant(action_obj)
        if variant is None:
            return None
        confidence = d.get("confidence") or "medium"
        if confidence not in ("high", "medium", "low"):
            confidence = "medium"
        source = d.get("source") or "rule"
        return cls(
            action=variant,
            human_explanation=d.get("human_explanation") or "",
            confidence=confidence,  # type: ignore[arg-type]
            source=source,  # type: ignore[arg-type]
        )


def _parse_variant(obj: dict[str, Any]) -> CorrectiveActionVariant | None:
    """Pick the single populated oneof key and build the matching variant."""
    if "switch_tool" in obj:
        v = obj["switch_tool"] or {}
        return SwitchTool(tool=v.get("tool", ""), scope=v.get("scope"))
    if "downscope_to" in obj:
        v = obj["downscope_to"] or {}
        return DownscopeTo(scope=v.get("scope", ""))
    if "rename_field" in obj:
        v = obj["rename_field"] or {}
        return RenameField(from_=v.get("from", ""), to=v.get("to", ""))
    if "redact_value" in obj:
        v = obj["redact_value"] or {}
        return RedactValue(json_path=v.get("json_path", ""), mask=v.get("mask", ""))
    if "split_request" in obj:
        v = obj["split_request"] or {}
        return SplitRequest(
            max_items_per_batch=int(v.get("max_items_per_batch", 0)),
            current_items=int(v.get("current_items", 0)),
        )
    if "wait_and_retry" in obj:
        v = obj["wait_and_retry"] or {}
        return WaitAndRetry(
            retry_after_seconds=int(v.get("retry_after_seconds", 0)),
            window_label=v.get("window_label"),
        )
    if "request_approval" in obj:
        v = obj["request_approval"] or {}
        return RequestApproval(
            ticket_template_url=v.get("ticket_template_url", ""),
            approver_role=v.get("approver_role"),
        )
    if "switch_endpoint" in obj:
        v = obj["switch_endpoint"] or {}
        return SwitchEndpoint(
            from_url=v.get("from_url", ""), to_url=v.get("to_url", "")
        )
    if "no_correction" in obj:
        return NoCorrection()
    return None


# ── StructuredDenial ─────────────────────────────────────────────────────


@dataclass
class StructuredDenial:
    """Carries the rule/policy that fired + a typed corrective for the LLM.

    Emitted by the gateway on every Deny/Downscope. Absent on Allow.
    """

    rule_id: str = ""
    violated_predicate: str = ""
    offending_value: str = ""
    corrective: CorrectiveAction | None = None
    reason_codes: list[str] = field(default_factory=list)
    boundary_violation: str | None = None
    boundary_matched_rule: str | None = None
    idempotency_key: str | None = None

    @classmethod
    def from_json(cls, d: dict[str, Any] | None) -> "StructuredDenial | None":
        if not d:
            return None
        return cls(
            rule_id=d.get("rule_id") or "",
            violated_predicate=d.get("violated_predicate") or "",
            offending_value=d.get("offending_value") or "",
            corrective=CorrectiveAction.from_json(d.get("corrective")),
            reason_codes=list(d.get("reason_codes") or []),
            boundary_violation=d.get("boundary_violation"),
            boundary_matched_rule=d.get("boundary_matched_rule"),
            idempotency_key=d.get("idempotency_key"),
        )


def synthetic_denial(
    rule_id: str,
    violated_predicate: str,
    *,
    corrective: CorrectiveAction | None = None,
) -> StructuredDenial:
    """Build a denial for SDK-side error conditions (gateway timeout, circuit
    breaker, network failure) where no gateway StructuredDenial was returned.
    Uses synthetic `SDK/...` rule IDs so observability can distinguish these
    from real rule denials."""
    return StructuredDenial(
        rule_id=rule_id,
        violated_predicate=violated_predicate,
        corrective=corrective,
    )


# ── LLM-facing render templates ──────────────────────────────────────────


def render_corrective_for_llm(c: CorrectiveAction | None) -> str:
    """Render a corrective into a tool_result-suitable string.

    Returns "" for low-confidence correctives (dashboard-only). LLM tool
    loops use this string as the `tool_result.content` so the model can
    pattern-match on the suggested action.

    Template set is shared with the TypeScript SDK — keep in sync.
    """
    if c is None:
        return ""
    if c.confidence == "low":
        return ""

    explanation = c.human_explanation or "denied"
    action = c.action

    if isinstance(action, SwitchTool):
        return f"Denied: {explanation}\nTry the `{action.tool}` tool instead."
    if isinstance(action, DownscopeTo):
        return f"Denied: {explanation}\nRetry under scope `{action.scope}`."
    if isinstance(action, RenameField):
        return (
            f"Denied: {explanation}\nRename `{action.from_}` → "
            f"`{action.to}` and retry."
        )
    if isinstance(action, RedactValue):
        return (
            f"Denied: {explanation}\nRemove the value at "
            f"`{action.json_path}` before retry."
        )
    if isinstance(action, SplitRequest):
        return (
            f"Denied: {explanation}\nSplit into batches of "
            f"≤ {action.max_items_per_batch}."
        )
    if isinstance(action, WaitAndRetry):
        suffix = f" ({action.window_label})" if action.window_label else ""
        return (
            f"Denied: {explanation}\nRetry after "
            f"{action.retry_after_seconds}s{suffix}."
        )
    if isinstance(action, RequestApproval):
        return (
            f"Denied: {explanation}\nFile an approval request: "
            f"{action.ticket_template_url}"
        )
    if isinstance(action, SwitchEndpoint):
        return (
            f"Denied: {explanation}\nUse `{action.to_url}` instead of "
            f"`{action.from_url}`."
        )
    if isinstance(action, NoCorrection):
        return f"Denied: {explanation}"
    return f"Denied: {explanation}"


__all__ = [
    "CorrectiveAction",
    "CorrectiveActionVariant",
    "Confidence",
    "DownscopeTo",
    "NoCorrection",
    "RedactValue",
    "RenameField",
    "RequestApproval",
    "Source",
    "SplitRequest",
    "StructuredDenial",
    "SwitchEndpoint",
    "SwitchTool",
    "WaitAndRetry",
    "render_corrective_for_llm",
    "synthetic_denial",
]
