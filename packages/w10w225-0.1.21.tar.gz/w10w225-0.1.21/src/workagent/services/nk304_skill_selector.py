"""nk304 skill auto-selection based on pending_item metadata.

WBS 8-1-1 .. 8-2-2

Selects relevant nk304 skill files based on the pending_item payload,
and renders template variables (e.g. {{room_id}}) with actual values.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Skill directory layout
# ---------------------------------------------------------------------------

_DEFAULT_SKILLS_DIR = Path.home() / ".personal-work-agent" / "skills" / "internal"

_SKILL_IDS = ("nk304-chat", "nk304-memo", "nk304-ticket", "nk304-file", "nk304-user")

# Agent DM rooms are direct-message sessions where the user talks to the
# agent itself.  Chat-room skills are not useful in that context.
_AGENT_DM_ROOM_PREFIXES = ("agent-dm:", "dm:", "direct:")


# ---------------------------------------------------------------------------
# Keyword tables for request-text matching
# ---------------------------------------------------------------------------

_MEMO_KEYWORDS = frozenset(["메모", "memo", "노트", "note", "기록"])
_TICKET_KEYWORDS = frozenset(["티켓", "ticket", "태스크", "task", "이슈", "issue"])
_FILE_KEYWORDS = frozenset(["파일", "file", "다운로드", "download", "첨부", "attachment", "용량", "storage"])
_USER_KEYWORDS = frozenset(["유저", "user", "사용자", "멤버", "member", "프로필", "profile"])


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def select_nk304_skills(pending_item_payload: dict[str, Any]) -> list[str]:
    """Return a list of nk304 skill IDs relevant for the given pending item.

    Parameters
    ----------
    pending_item_payload:
        The ``payload`` dict from an ``AgentPendingItemRecord``.

    Returns
    -------
    list[str]
        Skill directory names (e.g. ``["nk304-chat", "nk304-ticket"]``).
    """
    skills: list[str] = []

    room_id = str(pending_item_payload.get("roomId") or "").strip()
    if room_id and not _is_agent_dm(pending_item_payload):
        skills.append("nk304-chat")

    request_text = _extract_request_text(pending_item_payload).lower()

    if any(kw in request_text for kw in _MEMO_KEYWORDS):
        skills.append("nk304-memo")
    if any(kw in request_text for kw in _TICKET_KEYWORDS):
        skills.append("nk304-ticket")
    if any(kw in request_text for kw in _FILE_KEYWORDS):
        skills.append("nk304-file")
    if any(kw in request_text for kw in _USER_KEYWORDS):
        skills.append("nk304-user")

    return skills


def load_nk304_skill_contents(
    skill_ids: list[str],
    payload: dict[str, Any],
    *,
    skills_dir: Path | None = None,
) -> list[str]:
    """Load and render SKILL.md files for the given skill IDs.

    Template variables like ``{{room_id}}`` are replaced with values
    from the pending item payload.

    Parameters
    ----------
    skill_ids:
        Output of :func:`select_nk304_skills`.
    payload:
        The pending item payload (used for template variable substitution).
    skills_dir:
        Override the default external skills directory.

    Returns
    -------
    list[str]
        Rendered skill markdown contents.
    """
    base_dir = skills_dir or _DEFAULT_SKILLS_DIR
    template_vars = _build_template_vars(payload)
    contents: list[str] = []

    for skill_id in skill_ids:
        skill_file = base_dir / skill_id / "SKILL.md"
        if not skill_file.is_file():
            continue
        raw_text = skill_file.read_text(encoding="utf-8")
        rendered = _render_template(raw_text, template_vars)
        contents.append(rendered)

    return contents


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _is_agent_dm(payload: dict[str, Any]) -> bool:
    """Check whether the room is an agent direct-message session."""
    room_id = str(payload.get("roomId") or "").strip().lower()
    return any(room_id.startswith(prefix) for prefix in _AGENT_DM_ROOM_PREFIXES)


def _extract_request_text(payload: dict[str, Any]) -> str:
    """Extract the user's request text from the payload."""
    return (
        str(payload.get("requestText") or "").strip()
        or str(payload.get("replyText") or "").strip()
    )


def _build_template_vars(payload: dict[str, Any]) -> dict[str, str]:
    """Build the template variable mapping from the payload."""
    return {
        "room_id": str(payload.get("roomId") or "").strip(),
        "workspace_id": str(payload.get("workspaceId") or "").strip(),
        "user_id": str(
            payload.get("requestingUserId")
            or payload.get("replyingUserId")
            or ""
        ).strip(),
        "session_id": str(payload.get("sessionId") or "").strip(),
        "thread_id": str(payload.get("threadId") or "").strip(),
    }


def _render_template(text: str, variables: dict[str, str]) -> str:
    """Replace ``{{variable_name}}`` placeholders with actual values."""
    def _replacer(match: re.Match[str]) -> str:
        key = match.group(1).strip()
        return variables.get(key, match.group(0))

    return re.sub(r"\{\{(\s*\w+\s*)\}\}", _replacer, text)
