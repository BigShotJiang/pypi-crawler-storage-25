from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.services.action_executor import ActionExecutor
from workagent.services.action_parser import ActionParser
from workagent.services.chat_pipeline import ChatPipeline
from workagent.services.document_pipeline import DocumentPipeline
from workagent.services.file_memory import FileMemoryStore
from workagent.services.local_agent_store import LocalAgentStore
from workagent.services.nk304_transport import Nk304Transport
from workagent.services.request_router import RequestRouter


@dataclass(frozen=True, slots=True)
class _RelayExecutionResult:
    text: str


class _ConfiguredRelayExecutor:
    def __init__(self, *, executor, model: str | None) -> None:  # noqa: ANN001
        self.executor = executor
        self.model = model

    async def run(self, prompt: str) -> _RelayExecutionResult:
        import re

        output = await asyncio.to_thread(self.executor.run_fresh, model=self.model, prompt=prompt)
        normalized = self.executor.normalize_output(output)
        text = (
            str(normalized.draft or "").strip()
            or str(normalized.clarification_question or "").strip()
            or str(getattr(output, "assistant_text", "") or "").strip()
        )
        # Collapse excessive blank lines (3+ newlines -> 2)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return _RelayExecutionResult(text=text)


class _DirectSlackConnector:
    """Execute Slack actions using w10w225 CLI directly."""

    async def execute(self, action_payload: dict[str, object]) -> dict[str, object]:
        import asyncio
        import json
        import subprocess

        channel_id = str(action_payload.get("channelId") or "").strip()
        content = str(action_payload.get("content") or action_payload.get("text") or "").strip()
        thread_ts = str(action_payload.get("threadTs") or action_payload.get("thread_ts") or "").strip()
        kind = str(action_payload.get("kind") or "").strip()

        if not channel_id or not content:
            # Try to extract from target
            target = action_payload.get("target") or action_payload.get("targetRef") or {}
            if isinstance(target, str):
                try:
                    target = json.loads(target)
                except (json.JSONDecodeError, TypeError):
                    target = {}
            if isinstance(target, dict):
                channel_id = channel_id or str(target.get("channelId") or "").strip()
                thread_ts = thread_ts or str(target.get("threadTs") or "").strip()

        if not channel_id or not content:
            return {"error": "Missing channelId or content", "success": False}

        if kind == "slack_thread_reply" and thread_ts:
            cmd = ["w10w225", "slack", "reply", "--channel", channel_id, "--thread-ts", thread_ts, "--text", content]
        else:
            cmd = ["w10w225", "slack", "send", "--channel", channel_id, "--text", content]

        try:
            result = await asyncio.to_thread(
                subprocess.run, cmd, capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                try:
                    return json.loads(result.stdout)
                except (json.JSONDecodeError, TypeError):
                    return {"success": True, "output": result.stdout.strip()}
            return {"error": result.stderr.strip() or "Command failed", "success": False}
        except Exception as exc:
            return {"error": str(exc), "success": False}


class _Nk304WriteConnector:
    """Execute nk304 write operations (memo, ticket, chat) using Nk304ApiClient.

    WBS 6-10-1 .. 6-10-7: ActionExecutor nk304 write connectors.
    """

    async def execute(self, action_payload: dict[str, object]) -> dict[str, object]:
        import logging

        from workagent.cli_tools.nk304_api_client import Nk304ApiClient, Nk304TokenError

        logger = logging.getLogger("workagent.nk304_write_connector")
        kind = str(action_payload.get("kind") or "").strip()

        try:
            client = Nk304ApiClient.from_env()
        except Nk304TokenError as exc:
            return {"error": str(exc), "success": False}

        try:
            if kind == "nk304_memo_create":
                return await self._memo_create(client, action_payload)
            if kind == "nk304_memo_update":
                return await self._memo_update(client, action_payload)
            if kind == "nk304_memo_delete":
                return await self._memo_delete(client, action_payload)
            if kind == "nk304_ticket_create":
                return await self._ticket_create(client, action_payload)
            if kind == "nk304_ticket_comment":
                return await self._ticket_comment(client, action_payload)
            if kind == "nk304_ticket_update":
                return await self._ticket_update(client, action_payload)
            if kind == "nk304_chat_message":
                return await self._chat_message(client, action_payload)
            if kind == "nk304_chat_edit":
                return await self._chat_edit(client, action_payload)
            if kind == "nk304_chat_delete":
                return await self._chat_delete(client, action_payload)
            if kind == "nk304_chat_reply":
                return await self._chat_reply(client, action_payload)
            if kind == "nk304_wiki_set":
                return await self._wiki_set(client, action_payload)
            if kind == "nk304_wiki_create":
                return await self._wiki_create(client, action_payload)
            if kind == "nk304_wiki_edit":
                return await self._wiki_edit(client, action_payload)
            if kind == "nk304_wiki_delete":
                return await self._wiki_delete(client, action_payload)
            if kind == "nk304_notice_create":
                return await self._notice_create(client, action_payload)
            if kind == "nk304_notice_update":
                return await self._notice_update(client, action_payload)
            if kind == "nk304_notice_delete":
                return await self._notice_delete(client, action_payload)
            return {"error": f"Unsupported nk304 action kind: {kind}", "success": False}
        except Exception as exc:
            logger.exception("nk304 write connector failed for kind=%s", kind)
            return {"error": str(exc), "success": False}

    @staticmethod
    async def _memo_create(client: object, payload: dict[str, object]) -> dict[str, object]:
        title = str(payload.get("title") or "").strip()
        body = str(payload.get("body") or payload.get("content") or "").strip()
        if not title or not body:
            return {"error": "Missing title or body for memo create", "success": False}
        result = await client.post("/api/v2/memos", json_body={"title": title, "body": body})  # type: ignore[union-attr]
        return {"success": True, **result}

    @staticmethod
    async def _memo_update(client: object, payload: dict[str, object]) -> dict[str, object]:
        memo_id = str(payload.get("memoId") or payload.get("memo_id") or "").strip()
        if not memo_id:
            return {"error": "Missing memoId for memo update", "success": False}
        request_body: dict[str, object] = {}
        title = str(payload.get("title") or "").strip()
        body = str(payload.get("body") or payload.get("content") or "").strip()
        if title:
            request_body["title"] = title
        if body:
            request_body["body"] = body
        if not request_body:
            return {"error": "No fields to update for memo", "success": False}
        result = await client.patch(f"/api/v2/memos/{memo_id}", json_body=request_body)  # type: ignore[union-attr]
        return {"success": True, **result}

    @staticmethod
    async def _memo_delete(client: object, payload: dict[str, object]) -> dict[str, object]:
        memo_id = str(payload.get("memoId") or payload.get("memo_id") or "").strip()
        if not memo_id:
            return {"error": "Missing memoId for memo delete", "success": False}
        result = await client.delete(f"/api/v2/memos/{memo_id}")  # type: ignore[union-attr]
        return {"success": True, **result}

    @staticmethod
    async def _ticket_create(client: object, payload: dict[str, object]) -> dict[str, object]:
        # Tickets in nk304 are created as chat messages with message_type="ticket"
        # via POST /open-chat/rooms/{room_id}/messages, requiring ticketDraft metadata
        # (description, dueAt, assigneeUserIds, etc.). This flow is too complex for
        # direct agent execution -- use the write-draft flow instead.
        return {
            "error": (
                "Direct ticket creation is not supported. "
                "Tickets must be created via the chat message flow "
                "(POST /open-chat/rooms/{roomId}/messages with messageType='ticket' "
                "and ticketDraft metadata). Use the write-draft mechanism instead."
            ),
            "success": False,
        }

    @staticmethod
    async def _ticket_comment(client: object, payload: dict[str, object]) -> dict[str, object]:
        ticket_id = str(payload.get("ticketId") or payload.get("ticket_id") or "").strip()
        content = str(payload.get("content") or "").strip()
        if not ticket_id or not content:
            return {"error": "Missing ticketId or content for ticket comment", "success": False}
        result = await client.post(  # type: ignore[union-attr]
            f"/api/v2/open-chat/tickets/{ticket_id}/comments",
            json_body={"content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _ticket_update(client: object, payload: dict[str, object]) -> dict[str, object]:
        ticket_id = str(payload.get("ticketId") or payload.get("ticket_id") or "").strip()
        status = str(payload.get("status") or "").strip()
        if not ticket_id or not status:
            return {"error": "Missing ticketId or status for ticket update", "success": False}
        result = await client.patch(  # type: ignore[union-attr]
            f"/api/v2/open-chat/tickets/{ticket_id}/status",
            json_body={"status": status},
        )
        return {"success": True, **result}

    @staticmethod
    async def _chat_message(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        content = str(payload.get("content") or payload.get("text") or "").strip()
        if not room_id or not content:
            return {"error": "Missing roomId or content for chat message", "success": False}
        result = await client.post(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/messages",
            json_body={"content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _chat_edit(client: object, payload: dict[str, object]) -> dict[str, object]:
        message_id = str(payload.get("messageId") or payload.get("message_id") or "").strip()
        content = str(payload.get("content") or "").strip()
        if not message_id or not content:
            return {"error": "Missing messageId or content for chat edit", "success": False}
        result = await client.patch(  # type: ignore[union-attr]
            f"/api/v2/open-chat/messages/{message_id}",
            json_body={"content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _chat_delete(client: object, payload: dict[str, object]) -> dict[str, object]:
        message_id = str(payload.get("messageId") or payload.get("message_id") or "").strip()
        if not message_id:
            return {"error": "Missing messageId for chat delete", "success": False}
        result = await client.delete(  # type: ignore[union-attr]
            f"/api/v2/open-chat/messages/{message_id}",
        )
        return {"success": True, **result}

    @staticmethod
    async def _chat_reply(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        message_id = str(payload.get("messageId") or payload.get("message_id") or "").strip()
        content = str(payload.get("content") or payload.get("text") or "").strip()
        if not room_id or not message_id or not content:
            return {"error": "Missing roomId, messageId, or content for chat reply", "success": False}
        result = await client.post(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/messages",
            json_body={"content": content, "parentId": message_id},
        )
        return {"success": True, **result}

    @staticmethod
    async def _wiki_create(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        title = str(payload.get("title") or "").strip()
        content = str(payload.get("content") or "").strip()
        if not room_id or not title or not content:
            return {"error": "Missing roomId, title, or content for wiki create", "success": False}
        result = await client.post(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/wikis",
            json_body={"title": title, "content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _wiki_edit(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        wiki_id = str(payload.get("wikiId") or payload.get("wiki_id") or "").strip()
        if not room_id or not wiki_id:
            return {"error": "Missing roomId or wikiId for wiki edit", "success": False}
        request_body: dict[str, object] = {}
        title = str(payload.get("title") or "").strip()
        content = str(payload.get("content") or "").strip()
        if title:
            request_body["title"] = title
        if content:
            request_body["content"] = content
        if not request_body:
            return {"error": "No fields to update for wiki edit", "success": False}
        result = await client.patch(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/wikis/{wiki_id}",
            json_body=request_body,
        )
        return {"success": True, **result}

    @staticmethod
    async def _wiki_delete(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        wiki_id = str(payload.get("wikiId") or payload.get("wiki_id") or "").strip()
        if not room_id or not wiki_id:
            return {"error": "Missing roomId or wikiId for wiki delete", "success": False}
        result = await client.delete(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/wikis/{wiki_id}",
        )
        return {"success": True, **result}

    @staticmethod
    async def _wiki_set(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        title = str(payload.get("title") or "Wiki").strip()
        content = str(payload.get("content") or "").strip()
        if not room_id or not content:
            return {"error": "Missing roomId or content for wiki set", "success": False}
        result = await client.put(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/wiki",
            json_body={"title": title, "content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _notice_create(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        title = str(payload.get("title") or "공지").strip()
        content = str(payload.get("content") or "").strip()
        if not room_id or not content:
            return {"error": "Missing roomId or content for notice create", "success": False}
        result = await client.post(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/notices",
            json_body={"title": title, "content": content},
        )
        return {"success": True, **result}

    @staticmethod
    async def _notice_update(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        notice_id = str(payload.get("noticeId") or payload.get("notice_id") or "").strip()
        if not room_id or not notice_id:
            return {"error": "Missing roomId or noticeId for notice update", "success": False}
        request_body: dict[str, object] = {}
        title = str(payload.get("title") or "").strip()
        content = str(payload.get("content") or "").strip()
        if title:
            request_body["title"] = title
        if content:
            request_body["content"] = content
        if not request_body:
            return {"error": "No fields to update for notice", "success": False}
        result = await client.patch(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/notices/{notice_id}",
            json_body=request_body,
        )
        return {"success": True, **result}

    @staticmethod
    async def _notice_delete(client: object, payload: dict[str, object]) -> dict[str, object]:
        room_id = str(payload.get("roomId") or payload.get("room_id") or "").strip()
        notice_id = str(payload.get("noticeId") or payload.get("notice_id") or "").strip()
        if not room_id or not notice_id:
            return {"error": "Missing roomId or noticeId for notice delete", "success": False}
        result = await client.delete(  # type: ignore[union-attr]
            f"/api/v2/open-chat/rooms/{room_id}/notices/{notice_id}",
        )
        return {"success": True, **result}


class _NoopConnector:
    """Placeholder for unimplemented action connectors."""

    async def execute(self, action_payload: dict[str, object]) -> dict[str, object]:
        return {"error": "Action not implemented", "success": False}


def _build_action_connectors(outbound_processor=None) -> dict[str, object]:  # noqa: ANN001
    slack = _DirectSlackConnector()
    nk304 = _Nk304WriteConnector()
    noop = _NoopConnector()
    return {
        "slack_send_message": slack,
        "slack_thread_reply": slack,
        "nk304_memo_create": nk304,
        "nk304_memo_update": nk304,
        "nk304_memo_delete": nk304,
        "nk304_ticket_create": nk304,
        "nk304_ticket_comment": nk304,
        "nk304_ticket_update": nk304,
        "nk304_chat_message": nk304,
        "nk304_chat_edit": nk304,
        "nk304_chat_delete": nk304,
        "nk304_chat_reply": nk304,
        "nk304_wiki_set": nk304,
        "nk304_wiki_create": nk304,
        "nk304_wiki_edit": nk304,
        "nk304_wiki_delete": nk304,
        "nk304_notice_create": nk304,
        "nk304_notice_update": nk304,
        "nk304_notice_delete": nk304,
        "gitlab_note_create": noop,
        "jira_comment_create": noop,
        "confluence_comment_create": noop,
        "generic_external_action": noop,
    }


def build_request_router(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    sync_api,
    executor,
    model: str | None,
    outbound_processor,
) -> RequestRouter:
    transport = Nk304Transport(session_factory=session_factory, sync_api=sync_api)
    relay_executor = _ConfiguredRelayExecutor(executor=executor, model=model)
    action_executor = ActionExecutor(connectors=_build_action_connectors(outbound_processor))
    pwa_home = Path.home() / ".personal-work-agent"
    agent_store = LocalAgentStore(agents_dir=pwa_home / "agents")
    memory_store = FileMemoryStore(memory_dir=pwa_home / "memory")
    return RequestRouter(
        chat_pipeline=ChatPipeline(
            executor=relay_executor,
            transport=transport,
            action_parser=ActionParser(),
            action_executor=action_executor,
            agent_store=agent_store,
            memory_store=memory_store,
        ),
        document_pipeline=DocumentPipeline(
            executor=relay_executor,
            transport=transport,
            agent_store=agent_store,
        ),
        session_factory=session_factory,
    )
