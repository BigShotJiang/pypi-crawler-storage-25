# Copyright 2020 Open Reaction Database Project Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Name/string resolution to structured messages or identifiers."""

import re
import urllib.error
import urllib.parse
import urllib.request

from rdkit import Chem
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_random_exponential

import ord_schema
from ord_schema import message_helpers
from ord_schema.logging import get_logger
from ord_schema.proto import reaction_pb2

logger = get_logger(__name__)

_COMPOUND_STRUCTURAL_IDENTIFIERS = [
    reaction_pb2.CompoundIdentifier.SMILES,
    reaction_pb2.CompoundIdentifier.INCHI,
    reaction_pb2.CompoundIdentifier.MOLBLOCK,
    reaction_pb2.CompoundIdentifier.CXSMILES,
    reaction_pb2.CompoundIdentifier.XYZ,
]

_USERNAME = "github-actions"
_EMAIL = "github-actions@github.com"


def canonicalize_smiles(smiles: str) -> str:
    """Canonicalizes a SMILES string.

    Args:
        smiles: SMILES string.

    Returns:
        Canonicalized SMILES string.

    Raises:
        ValueError: If the SMILES cannot be parsed by RDKit.
    """
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        raise ValueError(f"Could not parse SMILES: {smiles}")
    return Chem.MolToSmiles(mol)


def name_resolve(value_type: str, value: str) -> tuple[str, str]:
    """Resolves compound identifiers to SMILES via multiple APIs."""
    for resolver, resolver_func in _NAME_RESOLVERS.items():
        try:
            smiles = resolver_func(value_type, value)
            if smiles is not None:
                return smiles, resolver
        except urllib.error.HTTPError as error:
            logger.info(f"{resolver} could not resolve {value_type} {value}: {error}")
    raise ValueError(f"Could not resolve {value_type} {value} to SMILES")


def resolve_names(message: ord_schema.Message) -> bool:
    """Attempts to resolve compound NAME identifiers to SMILES.

    When a NAME identifier is resolved, a SMILES identifier is added to the list
    of identifiers for that compound. Note that this function moves on to the
    next Compound after the first successful name resolution.

    Args:
        message: Protocol buffer tree containing Compound submessages (e.g. Reaction or ReactionInput).

    Returns:
        Boolean whether `message` was modified.
    """
    modified = False
    compounds = message_helpers.find_submessages(message, reaction_pb2.Compound)
    for compound in compounds:
        if any(identifier.type in _COMPOUND_STRUCTURAL_IDENTIFIERS for identifier in compound.identifiers):
            continue  # Compound already has a structural identifier.
        for identifier in compound.identifiers:
            if identifier.type == identifier.NAME:
                try:
                    smiles, resolver = name_resolve("name", identifier.value)
                    new_identifier = compound.identifiers.add()
                    new_identifier.type = new_identifier.SMILES
                    new_identifier.value = smiles
                    new_identifier.details = f"NAME resolved by the {resolver}"
                    modified = True
                    break
                except ValueError:
                    pass
    return modified


def _is_pubchem_busy(exception: BaseException) -> bool:
    # PubChem returns 503 PUGREST.ServerBusy when its service-wide concurrent
    # request load is shedding (independent of any per-IP quota). Retry only
    # that case; 404 (unknown name) and other 4xx codes should fall through.
    return isinstance(exception, urllib.error.HTTPError) and exception.code == 503


@retry(
    retry=retry_if_exception(_is_pubchem_busy),
    stop=stop_after_attempt(5),
    wait=wait_random_exponential(multiplier=1, max=8),
    reraise=True,
)
def _pubchem_resolve(value_type: str, value: str) -> str:
    """Resolves compound identifiers to SMILES via the PubChem REST API."""
    with urllib.request.urlopen(
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/{value_type}/"
        f"{urllib.parse.quote(value)}/property/IsomericSMILES/txt"
    ) as response:
        return response.read().decode().strip()


def _opsin_resolve(value_type: str, value: str) -> str:
    """Resolves systematic IUPAC names to SMILES via the OPSIN web service.

    OPSIN is a parser for systematic IUPAC nomenclature, not a lookup service:
    it will refuse trade names, trivial names, and abbreviations (e.g. "aspirin",
    "THF") with an HTTP 404. Treat it strictly as a complement to PubChem.
    """
    del value_type  # OPSIN only supports names.
    with urllib.request.urlopen(f"https://www.ebi.ac.uk/opsin/ws/{urllib.parse.quote(value)}.smi") as response:
        return response.read().decode().strip()


def resolve_input(input_string: str) -> reaction_pb2.ReactionInput:
    """Resolve a text-based description of an input in one of the following
    formats:
        (1) [AMOUNT] of [NAME]
        (2) [AMOUNT] of [CONCENTRATION] [SOLUTE] in [SOLVENT]

    Args:
        input_string: String describing the input.

    Returns:
        ReactionInput message.

    Raises:
        ValueError: if the string cannot be parsed properly.
    """
    reaction_input = reaction_pb2.ReactionInput()
    if " of " not in input_string:
        raise ValueError("String does not match template!")
    amount_string, description = input_string.split(" of ")
    if " in " not in description:
        component_name = description
        component = reaction_input.components.add()
        component.CopyFrom(message_helpers.build_compound(name=component_name.strip(), amount=amount_string))
        resolve_names(reaction_input)
        return reaction_input
    pattern = re.compile(r"(\d+.?\d*)\s?(\w+)\s(.+)\sin\s(.+)")
    match = pattern.fullmatch(description.strip())
    if not match:
        raise ValueError("String did not match template!")
    conc_value, conc_units, solute_name, solvent_name = match.groups()
    assert solute_name is not None  # Type hint.
    assert solvent_name is not None  # Type hint.
    solute = reaction_input.components.add()
    solvent = reaction_input.components.add()
    solute.CopyFrom(message_helpers.build_compound(name=solute_name.strip()))
    solvent.CopyFrom(message_helpers.build_compound(name=solvent_name.strip(), amount=amount_string))
    if solvent.amount.WhichOneof("kind") != "volume":
        raise ValueError("Total amount of solution must be a volume!")
    solvent.amount.volume_includes_solutes = True
    message_helpers.set_solute_moles(solute, [solvent], f"{conc_value} {conc_units}")
    resolve_names(reaction_input)
    return reaction_input


# Standard name resolvers.
#
# PubChem handles the bulk of inputs (trade names, trivial names, abbreviations,
# CAS numbers), and OPSIN is a reliable fallback for systematic IUPAC names when
# PubChem is unavailable or rate-limited.
#
# Previously also included NCI/CADD (cactus.nci.nih.gov) and eMolecules, which
# are both effectively dead: cactus has been returning uniform 503s with a silent
# blog since 2013, and eMolecules' public /lookup?q= endpoint now always replies
# "__END__" (their current API requires authentication).
_NAME_RESOLVERS = {
    "PubChem API": _pubchem_resolve,
    "OPSIN": _opsin_resolve,
}
