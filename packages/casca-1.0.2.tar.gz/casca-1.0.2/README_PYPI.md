# Casca

**A lightweight, zero-dependency Python TUI framework**

> ⚠️ **Note:** This project is currently private. It will be made public on GitHub soon.

Build beautiful terminal user interfaces with CSS-like styling and a DOM-like widget tree.

[![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

##  Features

- **Zero Dependencies** - Standard library only
- **CSS-Like Styling** - Familiar selector syntax
- **Flexbox Layouts** - Row/column with percentage sizing
- **20+ Widgets** - Buttons, inputs, tables, trees, dialogs
- **Full Type Hints** - Complete mypy support
- **Built-in Logging** - Structured debug output

---

##  Quick Start

```bash
pip install casca
```

```python
from casca import App, Container, Label, run_app

CSS = """
#root {
    border: solid;
    border-color: cyan;
    padding: 1;
}
"""

ui = Container(
    Label("Hello from Casca!"),
    id="root",
)

run_app(ui, css=CSS)
```

---

##  What's Included

**Basic Widgets:** Container, Label, Button, Card, ScrollView

**Forms:** Input, TextArea, Select, Checkbox, RadioGroup

**Data:** ListView, DataGrid, Table, TreeView

**Advanced:** VirtualScrollView (10K+ items), Grid layout, Dialogs, Toasts

---

##  Documentation

- **Website:** https://casca.abdallahzain.dev/
- **API Reference:** https://casca.abdallahzain.dev/docs.html
- **Examples:** https://casca.abdallahzain.dev/examples.html

---

##  Example

```python
from casca import App, Container, Label, Input, Button

class LoginApp(App):
    def build_ui(self):
        return Container(
            Label("🔐 Login"),
            Input(placeholder="Username"),
            Input(placeholder="Password"),
            Button("Login", on_click=self.login),
            id="root",
        )
    
    def login(self, event):
        self.show_toast("Welcome!", level="info")

LoginApp().run()
```

---

##  Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Lint
ruff check casca/

# Type check
mypy casca/
```

---

##  Stats

- **Tests:** 450+
- **Coverage:** 75%+
- **Type Coverage:** 100% (core)
- **Dependencies:** 0 (runtime)

---

##  Contributing

1. Fork the repo
2. Create a feature branch
3. Add tests for new features
4. Submit a PR

See [CONTRIBUTING.md](docs/CONTRIBUTING.md) for details.

---

##  License

MIT License - See [LICENSE](LICENSE) for details.

---

**Built with ❤️ using Casca**
