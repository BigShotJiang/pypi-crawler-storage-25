# Casca

**A lightweight, zero-dependency Python TUI framework**

> ⚠️ **Note:** This project is currently private. It will be made public on GitHub soon.

Build beautiful terminal user interfaces with CSS-like styling and a DOM-like widget tree.

[![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Website](https://img.shields.io/badge/docs-casca.abdallahzain.dev-blue)](https://casca.abdallahzain.dev/)

---

##  Quick Start

```bash
pip install casca
```

```python
from casca import App, Container, Label, run_app

CSS = """
#root {
    border: solid;
    border-color: cyan;
    padding: 1;
}
"""

ui = Container(
    Label("Hello from Casca!"),
    id="root",
)

run_app(ui, css=CSS)
```

**Press 'q' to exit, F2 for studio mode, F12 for screenshots**

---

##  Features

- **Zero Dependencies** - Standard library only at runtime
- **CSS-Like Styling** - Familiar selector syntax with cascade
- **Flexbox Layouts** - Row/column with percentage sizing
- **20+ Widgets** - Buttons, inputs, tables, trees, dialogs, and more
- **Full Type Hints** - Complete mypy support on core modules
- **Built-in Logging** - Structured debug output

---

##  Full Documentation

Visit **[https://casca.abdallahzain.dev](https://casca.abdallahzain.dev)** for:

-  [Complete API Reference](https://casca.abdallahzain.dev/docs.html)
-  [Component Library](https://casca.abdallahzain.dev/components.html)
-  [Code Examples](https://casca.abdallahzain.dev/examples.html)
-  [Troubleshooting Guide](https://casca.abdallahzain.dev/docs.html#dev-debugging)

---

##  Example: Login Form

```python
from casca import App, Container, Label, Input, Button, Checkbox

class LoginApp(App):
    def build_ui(self):
        return Container(
            Label("🔐 SECURE LOGIN"),
            Input(placeholder="Username"),
            Input(placeholder="Password"),
            Checkbox("Remember me"),
            Button("Login", on_click=self.login),
            id="root",
        )
    
    def login(self, event):
        self.show_toast("✅ Login successful!", level="info")

LoginApp().run()
```

---

##  Widget Library

**Basic:** Container, Label, Button, Card, Header, ScrollView

**Forms:** Input, TextArea, Select, Checkbox, RadioGroup

**Data:** ListView, DataGrid, Table, TreeView

**Advanced:** VirtualScrollView (10K+ items), Grid layout, Menu, Slider, Tooltip

**Dialogs:** Alert, Confirm, Prompt, Modal

**Visual:** ProgressBar, Spinner, BarChart, Gauge, Heatmap

---

##  Development

```bash
# Clone and install
git clone https://github.com/Abdallah4Z/casca.git
cd casca
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Lint and format
ruff check casca/ tests/
ruff format casca/ tests/

# Type check
mypy casca/
```

---

##  Project Stats

| Metric | Value |
|--------|-------|
| Tests | 450+ |
| Coverage | 75%+ |
| Type Coverage | 100% (core) |
| Runtime Deps | 0 |
| Widgets | 20+ |

---

##  Configuration

**pyproject.toml:**
```toml
[tool.ruff]
target-version = "py310"
line-length = 100

[tool.mypy]
python_version = "3.10"
warn_return_any = true
```

---

##  Contributing

Contributions welcome! See [CONTRIBUTING.md](docs/CONTRIBUTING.md) for guidelines.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Add tests for new features
4. Commit changes (`git commit -m 'feat: add amazing feature'`)
5. Push and open a PR

---

##  License

MIT License - See [LICENSE](LICENSE) for details.

---

##  Acknowledgments

Inspired by Textual, Blessed, and CSS Flexbox.

---

**Built with ❤️ using Casca** | [Website](https://casca.abdallahzain.dev) | [GitHub](https://github.com/Abdallah4Z/casca)
