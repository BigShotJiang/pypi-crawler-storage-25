"""ShieldPi MCP — Model Context Protocol server for ShieldPi Watchtower."""

__version__ = "0.5.0"
