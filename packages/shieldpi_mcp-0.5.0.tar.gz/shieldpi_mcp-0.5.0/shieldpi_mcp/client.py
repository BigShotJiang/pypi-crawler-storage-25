"""Async HTTP client for api.shieldpi.io.

Wraps the public + authenticated REST surface so MCP tools can call it without
each one re-implementing auth, retries, and error formatting.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_BASE_URL = os.getenv("SHIELDPI_API_BASE", "https://api.shieldpi.io")
DEFAULT_TIMEOUT = float(os.getenv("SHIELDPI_TIMEOUT", "30"))
USER_AGENT = "shieldpi-mcp/0.1.0 (+https://shieldpi.io)"


class ShieldPiAPIError(RuntimeError):
    """Raised when api.shieldpi.io returns a non-2xx response."""

    def __init__(self, status: int, body: str, url: str) -> None:
        super().__init__(f"ShieldPi API {status} on {url}: {body[:300]}")
        self.status = status
        self.body = body
        self.url = url


class ShieldPiClient:
    """Thin async wrapper around api.shieldpi.io.

    Public endpoints work without an API key. Authenticated endpoints require
    `SHIELDPI_API_KEY` (set in env or passed to the constructor) — the client
    sends it as both `X-API-Key` and `Authorization: Bearer` because different
    routes accept different conventions.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | None = None,
    ) -> None:
        self.api_key = api_key or os.getenv("SHIELDPI_API_KEY")
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout or DEFAULT_TIMEOUT
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "ShieldPiClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
        )
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _auth_headers(self) -> dict[str, str]:
        # ShieldPi backend reads `X-API-Key` (verified via
        # backend/app/core/deps.py:get_current_customer at line 30).
        # Earlier versions sent BOTH X-API-Key and Authorization: Bearer
        # for the same key value — dropped to single header to avoid
        # double-exposure in any logging layer.
        if not self.api_key:
            return {}
        return {"X-API-Key": self.api_key}

    def require_key(self, tool_name: str) -> None:
        if not self.api_key:
            raise ShieldPiAPIError(
                status=401,
                body=(
                    f"Tool `{tool_name}` requires a ShieldPi API key. "
                    f"Set SHIELDPI_API_KEY in your MCP client config "
                    f"(get one at https://shieldpi.io/dashboard/api-keys)."
                ),
                url=f"{self.base_url}/_local",
            )

    async def get(
        self, path: str, params: dict[str, Any] | None = None, auth: bool = False
    ) -> Any:
        assert self._client is not None, "ShieldPiClient must be used as `async with`"
        headers = self._auth_headers() if auth else {}
        resp = await self._client.get(path, params=params, headers=headers)
        return self._parse(resp)

    async def post(
        self, path: str, json: dict[str, Any] | None = None, auth: bool = True
    ) -> Any:
        assert self._client is not None, "ShieldPiClient must be used as `async with`"
        headers = self._auth_headers() if auth else {}
        resp = await self._client.post(path, json=json, headers=headers)
        return self._parse(resp)

    async def patch(
        self, path: str, json: dict[str, Any] | None = None, auth: bool = True
    ) -> Any:
        assert self._client is not None, "ShieldPiClient must be used as `async with`"
        headers = self._auth_headers() if auth else {}
        resp = await self._client.patch(path, json=json, headers=headers)
        return self._parse(resp)

    @staticmethod
    def _parse(resp: httpx.Response) -> Any:
        if resp.status_code >= 400:
            raise ShieldPiAPIError(resp.status_code, resp.text, str(resp.url))
        if resp.headers.get("content-type", "").startswith("application/json"):
            return resp.json()
        return resp.text
