"""ShieldPi MCP server — the conversational SOC for AI agents.

Exposes 25 tools that wrap api.shieldpi.io so any MCP-compatible client
(Claude Desktop, Claude Code, Cursor, Continue, etc.) can:

- Query the ShieldPi V7 methodology, attack graph, model families, leaderboard
- Look up models in the registry + their tested security posture
- Browse the 27,000+ attack technique library by category
- Kick off scans against a target and pull back forensic results
- Generate drop-in runtime guardrails from scan findings
- Operate the AI SOC analyst: list + drill into triaged incidents,
  escalate/resolve/suppress, kick off on-demand triage (NEW in v0.4.0)
- Operate the Live Agent Monitor SOC: list runtime alerts, drill into
  forensic detail, replay kill chains, triage + resolve alerts

Complementary to the ``shieldpi`` SDK (https://pypi.org/project/shieldpi/).
The SDK captures agent events; this MCP server queries the resulting alerts
+ incidents + scan intelligence + derived guardrails. Recommended install
in deployed agents: ``pip install "shieldpi[all]"`` then
``import shieldpi.auto`` — one line, zero code changes.

Tier-1 tools (no API key required):
  get_methodology, get_attack_graph, get_model_families,
  get_leaderboard_feed, get_leaderboard, get_model_registry

Tier-2 tools (require SHIELDPI_API_KEY env var):
  list_attack_categories, list_attack_techniques,
  start_scan, get_scan_status, get_scan_intelligence,
  get_scan_guardrails, export_scan_guardrails,          # v0.3.0
  get_incidents, get_incident_detail, trigger_triage,   # v0.4.0
  set_incident_status,                                  # v0.4.0
  get_onboarding_status, download_scan_bundle,          # v0.5.0
  get_live_alerts, get_alert_detail, acknowledge_alert, resolve_alert,
  list_monitor_sessions, get_session_events

Run as a stdio MCP server: `shieldpi-mcp` (entry point) or
`python -m shieldpi_mcp.server`.
"""

from __future__ import annotations

import json
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from shieldpi_mcp.client import DEFAULT_BASE_URL, ShieldPiAPIError, ShieldPiClient

mcp = FastMCP(
    name="shieldpi",
    instructions=(
        "ShieldPi is the AI SOC platform: a scanner (27,000+ attack techniques, 4 "
        "scan modes — Browser/API/Agent/Model), a runtime monitor (the `shieldpi` "
        "PyPI SDK — install with `pip install \"shieldpi[all]\"` and add `import "
        "shieldpi.auto` to any LangChain/LangGraph/OpenAI/Anthropic agent for "
        "zero-code event capture), and — new in MCP v0.3.0 — an auto-guardrail "
        "generator that turns scan findings into deployable runtime guardrails. "
        "Use these tools to browse the attack catalog, run scans, fetch breach "
        "forensics, generate guardrails from findings, and operate the live-agent "
        "SOC. Public docs: https://shieldpi.io/methodology · SDK quickstart: "
        "https://shieldpi.io/docs/live-agent-monitor · Leaderboard: "
        "https://shieldpi.info"
    ),
)


# ---------------------------------------------------------------------------
# Tier-1 tools (public, no API key required)
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_methodology() -> str:
    """Return ShieldPi's full V7 scoring + dedup + judge + breach-layer methodology.

    Use this when the user asks "how does ShieldPi score a model?", "what does
    ExploitDepth L3 mean?", or wants to cite the methodology in a report.
    Returns the same JSON document published at /api/intelligence/methodology.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/methodology")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_attack_graph() -> str:
    """Return the cross-customer anonymized attack-success graph.

    Maps attack technique → success rate per model family. The graph gets
    smarter as more scans complete (network effect). Useful when the user
    asks "which jailbreaks work on Claude / GPT / Gemini today?"
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/attack-graph")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_model_families() -> str:
    """Return ShieldPi's model-family taxonomy + similarity edges.

    Useful when the user wants to know what families ShieldPi recognizes
    (anthropic / openai / google / meta / qwen / kimi / deepseek / etc.) and
    how findings transfer across families.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/families")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_leaderboard_feed() -> str:
    """Return the live leaderboard feed — the data behind shieldpi.info.

    Gives every model with a recent ShieldPi scan: best security score, grade,
    last-tested timestamp, weakest category. Updated as scans complete.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/leaderboard-feed")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_leaderboard(limit: int = 30) -> str:
    """Return the public model leaderboard sorted by best security score.

    Args:
        limit: max number of models to return (default 30, capped server-side).
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/models/leaderboard", params={"limit": limit})
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_model_registry(family: str | None = None) -> str:
    """Return the registry of models ShieldPi knows how to test.

    Args:
        family: optional family filter (anthropic, openai, google, meta, qwen, ...).
            When omitted, returns all 38+ supported models.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/models/registry")
    if family:
        # Server doesn't filter; do it client-side so the LLM only sees what it asked for.
        if isinstance(data, dict) and "models" in data:
            data = {
                **data,
                "models": [
                    m for m in data["models"]
                    if m.get("family", "").lower() == family.lower()
                ],
            }
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Tier-2 tools (require API key)
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_attack_categories() -> str:
    """List the 15 attack categories ShieldPi tests against.

    Requires SHIELDPI_API_KEY (free tier works). Each category includes the
    technique count, OWASP LLM mapping, and OWASP Agentic mapping.
    """
    async with ShieldPiClient() as client:
        client.require_key("list_attack_categories")
        data = await client.get("/api/attacks/categories", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def list_attack_techniques(
    category: str | None = None,
    source: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> str:
    """Browse the 27,000+ attack technique library.

    Args:
        category: optional category filter (e.g. "prompt_injection", "jailbreak",
            "agent_exploitation", "data_exfiltration").
        source: optional source filter (e.g. "github:elder-plinius/L1B3RT45",
            "shieldpi:agent_attack_library", "agentdojo").
        limit: max techniques per page (default 25, max 100).
        offset: pagination offset.

    Requires SHIELDPI_API_KEY.
    """
    params: dict[str, Any] = {"limit": min(limit, 100), "offset": offset}
    if category:
        params["category"] = category
    if source:
        params["source"] = source
    async with ShieldPiClient() as client:
        client.require_key("list_attack_techniques")
        data = await client.get("/api/attacks", params=params, auth=True)
    return json.dumps(data, indent=2)


# Map MCP `depth` to backend ScanConfig values. Backend caps
# max_attacks_per_category at 100 and timeout_seconds at 3600.
_DEPTH_PRESETS: dict[str, dict[str, int]] = {
    "quick":    {"max_attacks_per_category": 5,  "timeout_seconds": 300},
    "standard": {"max_attacks_per_category": 10, "timeout_seconds": 600},
    "deep":     {"max_attacks_per_category": 50, "timeout_seconds": 1800},
}


@mcp.tool()
async def start_scan(
    target_url: str,
    mode: Literal["browser", "api", "agent", "model"] = "browser",
    target_name: str | None = None,
    depth: Literal["quick", "standard", "deep"] = "standard",
) -> str:
    """Start a ShieldPi scan against a target URL.

    Internally does the two-step backend flow: creates a Target via
    `POST /api/targets`, then starts the scan via `POST /api/scans`.

    Args:
        target_url: URL or model identifier to scan. For `mode=model`, pass an
            OpenRouter slug like "anthropic/claude-sonnet-4.5" or "openai/gpt-4o";
            this tool auto-prefixes with `model://` if needed. For `mode=agent`,
            pass an agent identifier; auto-prefixed with `agent://`.
        mode: scan mode — browser (web app), api (REST), agent (live agent),
            model (LLM via OpenRouter). Default: browser.
        target_name: human-readable label for the target. Defaults to the URL.
        depth: quick (~5min, 5 attacks per category), standard (~10min, 10/cat),
            deep (~30min, 50/cat). Default: standard.

    Returns JSON with target_id, scan_id, and the dashboard URL where progress
    can be watched. Pass scan_id to `get_scan_status` (poll) or
    `get_scan_intelligence` (final results).

    Requires SHIELDPI_API_KEY.
    """
    # Normalize URL for non-HTTP modes
    normalized_url = target_url
    if mode == "model" and not target_url.startswith(("model://", "http://", "https://")):
        normalized_url = f"model://{target_url}"
    elif mode == "agent" and not target_url.startswith(("agent://", "http://", "https://")):
        normalized_url = f"agent://{target_url}"

    target_body = {
        "name": target_name or target_url,
        "url": normalized_url,
        "scan_mode": mode,
    }
    config_body = {**_DEPTH_PRESETS[depth], "target_name": target_name or target_url}
    scan_body: dict[str, Any] = {"config": config_body}

    async with ShieldPiClient() as client:
        client.require_key("start_scan")
        # Step 1: create the Target.
        target = await client.post("/api/targets", json=target_body, auth=True)
        target_id = target["id"]
        # Step 2: start the Scan against the new Target.
        scan_body["target_id"] = target_id
        scan = await client.post("/api/scans", json=scan_body, auth=True)
        scan_id = scan["id"]

    result = {
        "target_id": target_id,
        "scan_id": scan_id,
        "status": scan.get("status", "queued"),
        "depth": depth,
        "mode": mode,
        "target_name": target_name or target_url,
        "target_url": normalized_url,
        "dashboard_url": f"https://shieldpi.io/dashboard/scans/{scan_id}",
        "next_step": (
            f"Poll `get_scan_status(scan_id='{scan_id}')` until status is 'completed' "
            f"or 'completed_partial' (typically 5–30 min depending on depth). "
            f"Then call `get_scan_intelligence(scan_id='{scan_id}')` for the full "
            f"breach forensics package."
        ),
    }
    return json.dumps(result, indent=2)


@mcp.tool()
async def get_scan_status(scan_id: str) -> str:
    """Get the current status of an in-progress scan.

    Cheap to call repeatedly — lighter than `get_scan_intelligence`.
    Use this to poll while a scan is running.

    Args:
        scan_id: UUID returned by `start_scan`.

    Returns JSON with status (queued | running | completed | completed_partial |
    failed), current phase, and elapsed time. Once status is `completed` or
    `completed_partial`, switch to `get_scan_intelligence` for results.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_scan_status")
        data = await client.get(f"/api/scans/{scan_id}/status", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_scan_intelligence(scan_id: str) -> str:
    """Pull the full intelligence + breach-forensics package for a scan.

    Returns: security score + grade + per-category results + extracted breach
    artifacts (creds / PII / code / tools) + kill chain narrative + business
    impact estimate. Only meaningful once the scan reaches `completed` or
    `completed_partial` — call `get_scan_status` first to check.

    Args:
        scan_id: UUID returned by `start_scan` or visible in the dashboard URL.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_scan_intelligence")
        data = await client.get(f"/api/scans/{scan_id}/intelligence", auth=True)
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Tier-2 Onboarding + CI bundle (v0.5.0)
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_onboarding_status() -> str:
    """Check the customer's ShieldPi onboarding progress.

    Returns a 6-step checklist — API key, first target, runtime monitoring
    enabled, first SDK event received, webhook configured, first alert —
    with per-step done/pending status derived from live account state
    (no separate tracking table, so it's always accurate). Includes the
    next_step_id so the LLM can walk the user through the first
    incomplete step.

    Use when the user asks "what's left before I'm protected?" or "am I
    fully set up?".

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_onboarding_status")
        data = await client.get("/api/onboarding/status", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def download_scan_bundle(scan_id: str) -> str:
    """Get the CI-friendly artifact bundle manifest for a completed scan.

    The bundle endpoint returns a ZIP with:
        • report.json (always)
        • report.pdf (when the plan permits)
        • guardrails/python.py, langchain.py, nemo.co, rules.json, stats.json
        • README.md

    Since MCP returns strings, this tool returns a *manifest* —
    metadata plus the signed URL the customer can curl from CI — rather
    than the raw zip bytes (which wouldn't survive serialization).
    For actually downloading, the CI pipeline uses:
        curl -H "X-API-Key: shpi_xxx" \\
             -o bundle.zip \\
             https://api.shieldpi.io/api/scans/{scan_id}/bundle

    Args:
        scan_id: UUID of a completed scan.

    Requires SHIELDPI_API_KEY.
    """
    # Confirm the scan exists + the customer has access by hitting
    # /guardrails (lightweight — no zip build) first, then return the
    # bundle download URL + stats.
    async with ShieldPiClient() as client:
        client.require_key("download_scan_bundle")
        meta = await client.get(f"/api/scans/{scan_id}/guardrails", auth=True)
    bundle_url = f"{DEFAULT_BASE_URL}/api/scans/{scan_id}/bundle"
    manifest = {
        "scan_id": scan_id,
        "bundle_url": bundle_url,
        "bundle_format": "zip",
        "curl": (
            f'curl -H "X-API-Key: $SHIELDPI_API_KEY" -o bundle.zip '
            f'"{bundle_url}"'
        ),
        "contains": [
            "report.json",
            "report.pdf (when plan permits)",
            "guardrails/python.py",
            "guardrails/langchain.py",
            "guardrails/nemo.co",
            "guardrails/rules.json",
            "guardrails/stats.json",
            "README.md",
        ],
        "stats": meta.get("stats", {}),
    }
    return json.dumps(manifest, indent=2)


# ---------------------------------------------------------------------------
# Tier-2 AI SOC Analyst (v0.4.0) — triaged incidents + kill-chain replay
#
# Incidents are Claude-triaged clusters of raw alerts. One incident ==
# one attack attempt. Use these tools when the user asks "what actually
# happened?" instead of "what alerts fired?".
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_incidents(
    status: Literal["open", "triaged", "escalated", "resolved", "suppressed"] | None = None,
    severity: Literal["critical", "high", "medium", "low"] | None = None,
    target_id: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> str:
    """List triaged incidents for the current ShieldPi customer.

    An incident is a cluster of related runtime alerts from one agent
    session that ShieldPi's AI SOC analyst has processed into a single
    verdict. Each incident carries an ai_summary, ai_severity, a
    false-positive flag, an ai_recommended_action, and an ai_kill_chain
    reconstruction.

    Args:
        status: triage lifecycle filter —
            open = not yet triaged
            triaged = AI has produced a verdict
            escalated = human attention requested
            resolved = analyst fixed it
            suppressed = confirmed false positive (AI or human).
        severity: roll-up severity filter.
        target_id: scope to one monitored agent.
        limit: max rows (default 50, capped server-side at 500).
        offset: pagination offset.

    Returns JSON list of incidents sorted by most recent activity.

    Requires SHIELDPI_API_KEY.
    """
    params: dict[str, Any] = {"limit": min(limit, 500), "offset": offset}
    if status:
        params["status"] = status
    if severity:
        params["severity"] = severity
    if target_id:
        params["target_id"] = target_id
    async with ShieldPiClient() as client:
        client.require_key("get_incidents")
        data = await client.get("/api/agent-monitor/incidents", params=params, auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_incident_detail(incident_id: str) -> str:
    """Full detail for one incident — kill chain + linked alerts + AI verdict.

    Returns the incident's rolled-up metadata, the AI analyst's
    structured verdict (summary, attacker_intent, kill_chain reconstruction,
    recommended_action), and every alert that was clustered into this
    incident in chronological order.

    Use this after ``get_incidents`` when the user asks to "walk through"
    a specific triaged case.

    Args:
        incident_id: UUID from ``get_incidents``.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_incident_detail")
        data = await client.get(
            f"/api/agent-monitor/incidents/{incident_id}", auth=True
        )
    return json.dumps(data, indent=2)


@mcp.tool()
async def trigger_triage(
    target_id: str | None = None,
    run_ai: bool = True,
    max_alerts: int = 200,
) -> str:
    """Kick off an on-demand triage pass.

    The customer's background Celery worker already runs triage every
    60 seconds. Use this tool for a synchronous "triage now" when the
    user wants a fresh verdict immediately after new alerts fire.

    Args:
        target_id: scope to one monitored agent. Omit to triage
            every target for this customer.
        run_ai: set to False to skip the Claude call (correlation +
            linking only — fast, no API spend).
        max_alerts: ceiling on how many untriaged alerts this call
            will process (default 200).

    Returns a summary: alerts_scanned, alerts_linked, incidents_created,
    incidents_updated, incidents_ai_triaged, incidents_ai_skipped.

    Requires SHIELDPI_API_KEY.
    """
    body: dict[str, Any] = {"run_ai": run_ai, "max_alerts": max_alerts}
    if target_id:
        body["target_id"] = target_id
    async with ShieldPiClient() as client:
        client.require_key("trigger_triage")
        data = await client.post(
            "/api/agent-monitor/triage/run", json=body, auth=True
        )
    return json.dumps(data, indent=2)


@mcp.tool()
async def set_incident_status(
    incident_id: str,
    status: Literal["open", "triaged", "escalated", "resolved", "suppressed"],
    note: str | None = None,
) -> str:
    """Human override for an incident's lifecycle status.

    Use when the analyst (or the LLM acting on the analyst's behalf)
    wants to:
        - escalate — flag for senior review
        - resolve  — confirm mitigated
        - suppress — confirm false positive / not actionable
        - open     — re-open a previously-closed incident

    Args:
        incident_id: UUID of the incident.
        status: new lifecycle state.
        note: optional resolution note (reserved for future audit log;
            currently unused by the API but accepted for forward
            compatibility).

    Requires SHIELDPI_API_KEY.
    """
    body: dict[str, Any] = {"status": status}
    if note:
        body["resolution_note"] = note
    async with ShieldPiClient() as client:
        client.require_key("set_incident_status")
        data = await client.patch(
            f"/api/agent-monitor/incidents/{incident_id}", json=body, auth=True
        )
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Tier-2 Auto-Guardrail Generator (v0.3.0) — close the loop
#
# Scanner finds a vulnerability → generator produces a deployable guardrail.
# Sprint 2 of the AI SOC platform. Competitors (Lakera, NeMo) sell
# hand-written guardrails; we derive them per-customer from the actual
# attacks that hit their agent.
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_scan_guardrails(scan_id: str) -> str:
    """Return auto-generated runtime guardrails for a completed scan.

    Every L2+ true-positive finding in the scan becomes one or more
    deployable guardrail rules. Patterns are drawn from categories like
    prompt-injection, jailbreak, tool-abuse, data-exfil, credential-leak,
    and encoding-bypass.

    Response JSON includes per-rule metadata (scope, pattern type, action,
    severity) plus aggregate stats (total findings, qualifying, by_scope,
    by_action). Use `export_scan_guardrails` to pull the same rules as a
    deployable Python / LangChain / NeMo Colang file.

    Args:
        scan_id: UUID of a scan that has reached status `completed` or
            `completed_partial`.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_scan_guardrails")
        data = await client.get(f"/api/scans/{scan_id}/guardrails", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def export_scan_guardrails(
    scan_id: str,
    format: Literal["python", "langchain", "nemo", "json"] = "python",
) -> str:
    """Export scan guardrails as a deployable file.

    Returns the file body as a string so you can paste it directly into a
    codebase, save it to disk, or walk the user through each rule.

    Formats:
        - `python`    — drop-in ``.py`` middleware with
                        `check_input()` / `check_output()` / `check_tool_call()`
                        helpers. Works in any Python agent.
        - `langchain` — ``BaseCallbackHandler`` subclass for LangChain /
                        LangGraph agents. Blocks at `on_tool_start` /
                        `on_chat_model_start` / `on_llm_end`.
        - `nemo`      — NeMo Guardrails Colang (`.co`) rails file.
        - `json`      — raw rules + envelope (for custom enforcement layers).

    Args:
        scan_id: UUID of a completed scan.
        format: output format. Default: `python` (the most universal).

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("export_scan_guardrails")
        body = await client.get(
            f"/api/scans/{scan_id}/guardrails/export",
            params={"format": format},
            auth=True,
        )
    # json format comes back parsed — serialize back for the MCP string channel
    if isinstance(body, (dict, list)):
        return json.dumps(body, indent=2)
    return str(body)


# ---------------------------------------------------------------------------
# Tier-2 Live Agent Monitor — the SOC for AI agents
#
# These wrap /api/agent-monitor/* — the runtime monitoring product. Customers
# install ShieldPi's SDK (sdks/shieldpi-python) into their deployed agent;
# every prompt+response goes through ShieldPi's detectors; alerts land in
# the agent_alerts table. These tools let you operate the SOC from inside
# any MCP client (Claude Desktop / Code / Cursor / Continue).
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_live_alerts(
    severity: Literal["critical", "high", "medium", "low"] | None = None,
    status: Literal["open", "acknowledged", "resolved", "false_positive"] = "open",
    target_id: str | None = None,
    limit: int = 50,
) -> str:
    """List runtime alerts from deployed agents being monitored by ShieldPi.

    This is the primary "what's happening on my agents right now" tool.
    Alerts come from the Live Agent Monitor SDK installed inside customer
    agents — every prompt+response gets analyzed by ShieldPi's 6 detectors
    (pattern match / trajectory / memory poisoning / memory integrity /
    response leak / cross-session correlation) and any detection becomes
    an alert in this list.

    Args:
        severity: filter by severity. Omit to see all.
        status: filter by triage status (default: open — un-triaged alerts).
        target_id: scope to one specific monitored agent. Omit to see all.
        limit: max alerts to return (default 50, max 200).

    Returns JSON with alert list — each includes alert_type (e.g.
    `prompt_injection`, `data_exfil`, `memory_poison`), severity,
    confidence (0-1), evidence (the matching prompt/response excerpt),
    session_id (drill in via `get_session_events`), and alert_id (drill in
    via `get_alert_detail` or triage via `acknowledge_alert`).

    Requires SHIELDPI_API_KEY.
    """
    params: dict[str, Any] = {"status": status, "limit": min(limit, 200)}
    if severity:
        params["severity"] = severity
    if target_id:
        params["target_id"] = target_id
    async with ShieldPiClient() as client:
        client.require_key("get_live_alerts")
        data = await client.get("/api/agent-monitor/alerts", params=params, auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_alert_detail(alert_id: str) -> str:
    """Pull the full forensic detail for one runtime alert.

    Returns: alert metadata + the full session event chain leading up to
    the alert (the kill chain replay) + extracted artifacts (credentials,
    PII, code, tool calls) + matched attack technique from ShieldPi's
    27,000-technique library.

    Use this after `get_live_alerts` to drill into the worst alert and
    walk the user through what actually happened.

    Args:
        alert_id: UUID returned in `get_live_alerts`.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_alert_detail")
        data = await client.get(f"/api/agent-monitor/alerts/{alert_id}/detail", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def acknowledge_alert(alert_id: str) -> str:
    """Mark an alert as acknowledged (triaged but not yet resolved).

    Use when an analyst has seen the alert and is investigating but the
    underlying issue isn't fixed yet. Distinguishes alerts that need
    eyes-on (open) from alerts being worked (acknowledged).

    Args:
        alert_id: UUID of the alert to acknowledge.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("acknowledge_alert")
        data = await client.post(f"/api/agent-monitor/alerts/{alert_id}/ack", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def resolve_alert(alert_id: str, note: str | None = None) -> str:
    """Mark an alert as resolved (analyst confirmed + mitigated).

    Use after the underlying issue is fixed (agent updated, attacker
    blocked, etc.) so the alert disappears from the open queue.

    Args:
        alert_id: UUID of the alert to resolve.
        note: optional resolution note for the audit log.

    Requires SHIELDPI_API_KEY.
    """
    body: dict[str, Any] = {}
    if note:
        body["note"] = note
    async with ShieldPiClient() as client:
        client.require_key("resolve_alert")
        data = await client.post(
            f"/api/agent-monitor/alerts/{alert_id}/resolve", json=body, auth=True
        )
    return json.dumps(data, indent=2)


@mcp.tool()
async def list_monitor_sessions(target_id: str | None = None, limit: int = 25) -> str:
    """List recent monitored sessions across one or all deployed agents.

    A "session" is a conversation between a user and a monitored agent —
    every prompt + response + tool call from that conversation lives in
    one session. Use this to find sessions worth drilling into via
    `get_session_events`, especially when investigating an alert.

    Args:
        target_id: scope to one monitored agent. Omit to see across all.
        limit: max sessions to return (default 25, max 200).

    Returns JSON list with session metadata: started_at, event_count,
    alert_count, target_id, session_id.

    Requires SHIELDPI_API_KEY.
    """
    params: dict[str, Any] = {"limit": min(limit, 200)}
    if target_id:
        params["target_id"] = target_id
    async with ShieldPiClient() as client:
        client.require_key("list_monitor_sessions")
        data = await client.get("/api/agent-monitor/sessions", params=params, auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_session_events(session_id: str, limit: int = 100) -> str:
    """Get the full event chain for one monitored session.

    Returns every prompt, response, and tool call from the session in
    order — the raw conversation that ShieldPi's detectors saw. This is
    the kill-chain replay: walk the conversation turn by turn to
    understand exactly what the attacker tried.

    Args:
        session_id: UUID from `get_live_alerts` (alert.session_id) or
            from `list_monitor_sessions`.
        limit: max events to return (default 100, max 500).

    Requires SHIELDPI_API_KEY.
    """
    params = {"limit": min(limit, 500)}
    async with ShieldPiClient() as client:
        client.require_key("get_session_events")
        data = await client.get(
            f"/api/agent-monitor/sessions/{session_id}/events", params=params, auth=True
        )
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MCP server over stdio (Claude Desktop / Code / Cursor default)."""
    try:
        mcp.run()
    except ShieldPiAPIError as exc:
        # FastMCP catches tool errors per-call; this only fires if the loop itself dies.
        raise SystemExit(f"shieldpi-mcp fatal: {exc}") from exc


if __name__ == "__main__":
    main()
