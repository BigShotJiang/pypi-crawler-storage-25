from setuptools import setup, find_packages

setup(
    name="pillarola",
    version="1.1.6",
    description="Video downloader",
    author="Pillar",
    packages=find_packages(),
    install_requires=[
        "yt-dlp",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "download=initializer.downloader:download_vide",
        ],
    },
)