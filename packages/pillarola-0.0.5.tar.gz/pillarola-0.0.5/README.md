syntax:

pip install Pillarola==v1.0.0

download Video_url['your specified url']

video will be downloaded!