from rich.console import Console
from rich.panel import Panel

console = Console()


def banner():
    console.print(
        Panel.fit(
            "⚡ pillarola\nZero-setup video downloader",
            style="bold green"
        )
    )


def start_download(url):
    console.print(f"\n🚀 [green]Downloading:[/green] {url}")


def success():
    console.print("\n✅ [bold green]Done! File saved to Downloads[/bold green]")


def error(msg):
    console.print(f"\n❌ [red]{msg}[/red]")