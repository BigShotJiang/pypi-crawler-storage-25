import os
import yt_dlp
import shutil

from .ffmpeg import ensure_ffmpeg
from .ui import start_download, success, error


def get_format():
    if shutil.which("ffmpeg"):
        return "bestvideo+bestaudio/best"
    return "best"


# -----------------------------
# PROGRESS HOOK
# -----------------------------
from rich.console import Console
console = Console()

def progress_hook(d):
    if d["status"] == "downloading":
        percent = d.get("_percent_str", "").strip()
        speed = d.get("_speed_str", "N/A")
        eta = d.get("_eta_str", "N/A")

        console.print(
            f"[cyan]📥 {percent}[/cyan] | ⚡ {speed} | ⏳ {eta}",
            end="\r"
        )

    elif d["status"] == "finished":
        console.print("\n✅ Download complete! Processing...")


# -----------------------------
# MAIN FUNCTION
# -----------------------------
def download_video(url: str, audio_only: bool = False):
    downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(downloads_dir, exist_ok=True)

    ffmpeg_path = ensure_ffmpeg()

    ydl_opts = {
        "format": "bestaudio/best" if audio_only else get_format(),
        "outtmpl": os.path.join(downloads_dir, "%(title).50s.%(ext)s"),
        "restrictfilenames": True,
        "progress_hooks": [progress_hook],
        "noplaylist": True,
        "quiet": False,
        "ffmpeg_location": ffmpeg_path,
    }

    if not audio_only:
        ydl_opts["merge_output_format"] = "mp4"

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            start_download(url)
            ydl.download([url])
            success()

    except Exception as e:
        error(str(e))