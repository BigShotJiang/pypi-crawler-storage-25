import os
import shutil
import urllib.request
import zipfile
import tempfile

from .config import FFMPEG_PATH, FFMPEG_DIR


FFMPEG_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"


def ensure_ffmpeg(console=None):
    # 1. System ffmpeg
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg

    # 2. Cached ffmpeg
    if os.path.exists(FFMPEG_PATH):
        return FFMPEG_PATH

    if console:
        console.print("⚡ FFmpeg not found. Installing automatically...")

    os.makedirs(FFMPEG_DIR, exist_ok=True)

    try:
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = os.path.join(tmp, "ffmpeg.zip")

            urllib.request.urlretrieve(FFMPEG_URL, zip_path)

            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(tmp)

            extracted_folder = None
            for folder in os.listdir(tmp):
                path = os.path.join(tmp, folder)
                if os.path.isdir(path) and "ffmpeg" in folder:
                    extracted_folder = path
                    break

            if not extracted_folder:
                raise RuntimeError("FFmpeg extraction failed")

            bin_dir = os.path.join(extracted_folder, "bin")

            if not os.path.exists(bin_dir):
                raise RuntimeError("Invalid FFmpeg structure")

            for file in os.listdir(bin_dir):
                src = os.path.join(bin_dir, file)
                dst = os.path.join(FFMPEG_DIR, file)
                shutil.copy2(src, dst)

        return FFMPEG_PATH

    except Exception as e:
        raise RuntimeError(f"FFmpeg install failed: {e}")