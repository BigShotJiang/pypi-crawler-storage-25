import typer
from .downloader import download_video
from .ui import banner

app = typer.Typer(help="⚡ pillarola - Zero setup video downloader")

@app.command()
def main(
    url: str,
    audio: bool = typer.Option(False, "--audio", help="Download audio only")
):
    banner()
    download_video(url, audio)

if __name__ == "__main__":
    app()