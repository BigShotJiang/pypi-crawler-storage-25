import os
import yt_dlp
import sys
import threading
import shutil
print('Establishing connection to server...')
try:
    def get_format():
        if shutil.which("ffmpeg"):
            return "bestvideo+bestaudio/best"
        else:
            return "best"
    

    def progress_hook(d):
        if d['status'] == 'downloading':
            percent = d.get('_percent_str', '0%')
            speed = d.get('_speed_str', 'N/A')
            eta = d.get('_eta_str', 'N/A')
            print(f"\r📥 {percent} | ⚡ {speed} | ⏳ {eta}", end='', flush=True)

        elif d['status'] == 'finished':
            print("\n✅ Download complete! Processing file...")


    def download_video(url, audio_only=False):
        downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
        os.makedirs(downloads_dir, exist_ok=True)

        ydl_opts = {
            'format': get_format(),
            'outtmpl': os.path.join(downloads_dir, '%(title).50s.%(ext)s'),
            'restrictfilenames': True,
            'progress_hooks': [progress_hook],
            'noplaylist': True,
            'quiet': True,
            'ffmpeg_location': 'ffmpeg',
        }

        if not audio_only:
            ydl_opts['merge_output_format'] = 'mp4'

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                print(f"\n🚀 Starting: {info['title']}")
                ydl.download([url])

        except Exception as e:
            print(f"\n❌ Failed ({url}): {e}")


    def main():
        
        urls = []
        audio_mode = False

        if len(sys.argv) > 1:
            for arg in sys.argv[1:]:
                if arg in ("--audio", "-a"):
                    audio_mode = True
                else:
                    urls.append(arg)
        else:
            print("Paste URLs (type 'done' to start):")
            while True:
                u = input("> ").strip()
                if u.lower() == "done":
                    break
                if u.startswith(("http://", "https://")):
                    urls.append(u)
                else:
                    print("❌ Invalid URL")

        if not urls:
            print("❌ No valid URLs provided")
            return

        threads = []

        for url in urls:
            t = threading.Thread(target=download_video, args=(url, audio_mode))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

    


    if __name__ == "__main__":
        main()
except ConnectionAbortedError:
    print("\n💀 Connection was lost. Please check your internet connection and try again.")

except ConnectionError:
    print("\n🌐 Network error. Please check your connection and try again.")

except KeyboardInterrupt:
    print("\n🚪 Exiting...")
    sys.exit()
except ConnectionRefusedError:
    print("\n💀 Connection refused. The server may be down or blocking requests.")
    sys.exit()

