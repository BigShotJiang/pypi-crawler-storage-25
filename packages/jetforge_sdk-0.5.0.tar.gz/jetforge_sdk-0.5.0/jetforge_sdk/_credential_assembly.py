"""JIT credential assembly helpers for ``DataAssetClient.dispatch_resolve_credential``.

JETP-082 §09/04 — local placement assembly mirroring (a minimal subset of)
``jetforge.services.credential_auth_injector.build_injection``. We
deliberately do NOT import the server-side implementation here — the SDK
must remain decoupled from the JetForge backend package.

This module covers four placement transports sufficient for the v1.3
``DATABASE`` + ``DATA_API`` data-asset handlers:

* ``header`` (incl. default ``Authorization`` for ``bearer`` / ``basic`` kinds)
* ``query``
* ``cookie``
* ``body``
* ``database_dsn`` (``user`` / ``password`` / ``parameter:{key}``)

Anything beyond this surface is recorded in the bundle's ``notes`` field
for the handler to inspect; the SDK never fails the resolve call just
because a placement is unrecognised.

Every helper here is **pure** and free of network IO; this is what makes
unit tests cheap and the secret-handling path auditable.
"""
from __future__ import annotations

import base64
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


__all__ = [
    "AuthBundle",
    "apply_placement",
]


def _empty_bundle() -> dict[str, Any]:
    return {
        "credential_id": None,
        "kind": None,
        "headers": {},
        "query": {},
        "cookies": {},
        "body_patches": {},
        "dsn_overrides": {},
        "expires_at": None,
        "secret": None,
        "notes": [],
    }


# Public alias for callers that want a typed dict-shape reference.
AuthBundle = dict


# JETP-082.1 v0.3 — ``resolve_binding`` deleted (50-line fn removed).
# Rationale (service boundary autonomy, D9): callers do not project
# their identity onto JetForge's binding-axis namespace; the server
# computes ``binding_key`` from the OBO act-chain alone. See
# ``03_sdk_protocol/01_dispatch_resolve_credential_v2.md`` §2.2.


def _safe_template(template: Optional[str], default: str = "{token}") -> str:
    return template if template else default


def _render(template: str, secret: dict[str, Any]) -> str:
    """Apply str.format against the secret dict.

    Wraps KeyError so the caller can short-circuit with a single
    structured log line — the ``KeyError`` message itself never
    references which secret key was missing in our log line; we only
    include the placement label.
    """
    return template.format(**secret)


def _b64_basic(username: str, password: str) -> str:
    raw = f"{username}:{password}".encode()
    return "Basic " + base64.b64encode(raw).decode("ascii")


def _apply_database_dsn(
    bundle: dict[str, Any],
    *,
    name: str,
    template: str,
    secret: dict[str, Any],
) -> bool:
    """Return True on success, False on validation failure."""
    rendered = _render(template, secret)
    if name == "user":
        bundle["dsn_overrides"]["user"] = rendered
        bundle["notes"].append("dsn_override:user")
        return True
    if name == "password":
        bundle["dsn_overrides"]["password"] = rendered
        bundle["notes"].append("dsn_override:password")
        return True
    if name.startswith("parameter:"):
        param_key = name.split(":", 1)[1]
        if not param_key:
            return False
        bundle["dsn_overrides"].setdefault("params", {})[param_key] = rendered
        bundle["notes"].append(f"dsn_override:parameter:{param_key}")
        return True
    return False


def apply_placement(
    *,
    asset_id: str,
    manifest: dict[str, Any],
    resolved: dict[str, Any],
) -> Optional[dict[str, Any]]:
    """Build an ``auth_bundle`` from ``manifest`` + ``resolved`` (server).

    ``resolved`` shape mirrors ``ResolvedCredential``:
      ``{credential_id, kind, secret, expires_at?, placement_hint?}``

    Returns ``None`` on any of:
      * ``secret`` not a dict / missing
      * template KeyError
      * unsupported ``database_dsn`` slot name

    All None paths emit a structured log line **without** secret bytes.
    """
    secret = resolved.get("secret")
    if not isinstance(secret, dict):
        logger.error(
            "[JETP-082/sdk] resolve(%s) returned non-dict secret; "
            "rejecting bundle",
            asset_id,
        )
        return None

    bundle = _empty_bundle()
    bundle["credential_id"] = resolved.get("credential_id")
    bundle["kind"] = resolved.get("kind") or manifest.get("kind")
    bundle["expires_at"] = resolved.get("expires_at")
    bundle["secret"] = secret  # handlers that need raw access (rare)

    placement = manifest.get("placement") or {}
    location = (placement.get("location") or "header").lower()
    name = placement.get("name")
    template = placement.get("value_template")
    manifest_kind = (manifest.get("kind") or "").lower()

    try:
        if location == "database_dsn":
            if not name:
                logger.error(
                    "[JETP-082/sdk] resolve(%s) database_dsn placement "
                    "missing 'name'; rejecting bundle",
                    asset_id,
                )
                return None
            ok = _apply_database_dsn(
                bundle,
                name=name,
                template=_safe_template(template),
                secret=secret,
            )
            if not ok:
                logger.error(
                    "[JETP-082/sdk] resolve(%s) database_dsn name=%r is "
                    "not in {user, password, parameter:*}; rejecting",
                    asset_id, name,
                )
                return None
            return bundle

        # JETP-082 v1.4 — ``db-password`` credentials carry the full DSN
        # tuple in ``secret`` (``{username, password, host?, port?,
        # database?, ssl_mode?, ...}``). The placement *template* is
        # meaningless for this kind; the auth bundle is the secret itself
        # projected into ``dsn_overrides``. This branch lets jetagents'
        # ``DatabaseHandler`` consume the bundle uniformly regardless of
        # whether the asset's manifest carries a hand-tuned
        # ``database_dsn`` placement or the default ``driver-kwargs`` one.
        if manifest_kind == "db-password":
            user = secret.get("username") or secret.get("user")
            pwd = secret.get("password")
            if user is None or pwd is None:
                logger.warning(
                    "[JETP-082/sdk] resolve(%s) db-password requires "
                    "secret['username'|'user'] + secret['password']; "
                    "rejecting bundle",
                    asset_id,
                )
                return None
            bundle["dsn_overrides"]["user"] = str(user)
            bundle["dsn_overrides"]["password"] = str(pwd)
            for opt_key in ("host", "port", "database", "ssl_mode", "schema"):
                val = secret.get(opt_key)
                if val is not None:
                    bundle["dsn_overrides"][opt_key] = val
            params = secret.get("params") or secret.get("parameters")
            if isinstance(params, dict) and params:
                bundle["dsn_overrides"].setdefault("params", {}).update(params)
            bundle["notes"].append("db-password:dsn_overrides")
            return bundle

        if manifest_kind == "bearer" and location == "header":
            token = secret.get("token")
            if token is None:
                logger.warning(
                    "[JETP-082/sdk] resolve(%s) bearer requires "
                    "secret['token']; rejecting bundle",
                    asset_id,
                )
                return None
            header_name = name or "Authorization"
            bundle["headers"][header_name] = f"Bearer {token}"
            bundle["notes"].append(f"header:{header_name}=bearer")
            return bundle

        if manifest_kind == "basic" and location == "header":
            user = secret.get("username") or secret.get("user")
            pwd = secret.get("password")
            if user is None or pwd is None:
                logger.warning(
                    "[JETP-082/sdk] resolve(%s) basic requires "
                    "secret['username'|'user'] + secret['password']; "
                    "rejecting bundle",
                    asset_id,
                )
                return None
            header_name = name or "Authorization"
            bundle["headers"][header_name] = _b64_basic(str(user), str(pwd))
            bundle["notes"].append(f"header:{header_name}=basic")
            return bundle

        # Generic kinds (static_api_key etc.) over header / query / cookie / body
        rendered = _render(_safe_template(template), secret)

        if location == "header":
            header_name = name or "Authorization"
            bundle["headers"][header_name] = rendered
            bundle["notes"].append(f"header:{header_name}")
            return bundle
        if location == "query":
            if not name:
                logger.error(
                    "[JETP-082/sdk] resolve(%s) query placement missing "
                    "'name'; rejecting bundle",
                    asset_id,
                )
                return None
            bundle["query"][name] = rendered
            bundle["notes"].append(f"query:{name}")
            return bundle
        if location == "cookie":
            if not name:
                logger.error(
                    "[JETP-082/sdk] resolve(%s) cookie placement missing "
                    "'name'; rejecting bundle",
                    asset_id,
                )
                return None
            bundle["cookies"][name] = rendered
            bundle["notes"].append(f"cookie:{name}")
            return bundle
        if location == "body":
            if not name:
                logger.error(
                    "[JETP-082/sdk] resolve(%s) body placement missing "
                    "'name'; rejecting bundle",
                    asset_id,
                )
                return None
            bundle["body_patches"][name] = rendered
            bundle["notes"].append(f"body:{name}")
            return bundle

        # Unrecognised placement — keep the bundle but flag for handler.
        bundle["notes"].append(
            f"placement_unhandled:{manifest_kind}:{location}"
        )
        return bundle

    except KeyError as exc:
        # secret bytes never appear in the log: only the placement label.
        logger.warning(
            "[JETP-082/sdk] resolve(%s) placement_template_keyerror "
            "(missing key in secret for kind=%s location=%s name=%s); "
            "rejecting bundle",
            asset_id, manifest_kind, location, name,
        )
        return None
    except Exception:
        logger.exception(
            "[JETP-082/sdk] resolve(%s) placement assembly failed unexpectedly",
            asset_id,
        )
        return None
