"""DataAsset client SDK — JETP-082.

Lightweight async client over the JetForge dispatch endpoint
(``GET /api/v1/sdk/data-assets/dispatch``). The client handles:

* ETag round-tripping (304 fast path).
* In-memory ``DataAssetMeta`` cache keyed by asset id.
* ``since_revision`` cursor for incremental sync.
* Pagination loop until exhaustion.
* Optional kind filter.

Design contracts mirror ``ForgeClient`` (same auth header convention,
same httpx flavour) so JetAgents resolvers can multiplex both clients
on the same HTTP layer.

References
----------
- ``docs/proposals/JETP-082-data-asset-layer/00_protocol/03_data_asset_dispatch_protocol.md``
- ``docs/proposals/JETP-082-data-asset-layer/03_dispatch_backend/01_dispatch_endpoint_design.md``
"""
from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx

from jetforge_sdk._credential_resolve import (
    INTERNAL_AUDIENCE as _INTERNAL_AUDIENCE,
    INTERNAL_RESOLVE_PATH_TEMPLATE as _INTERNAL_RESOLVE_PATH_TEMPLATE,
    ResolveRequest,
    dispatch_resolve_credential as _dispatch_resolve_credential_impl,
)

logger = logging.getLogger(__name__)


__all__ = [
    "DataAssetClient",
    "DataAssetClientError",
    "DataAssetMeta",
    "DataAssetSyncResult",
]


class DataAssetClientError(RuntimeError):
    """Raised on fatal protocol violations.

    Network / 5xx / rate-limit errors are *handled internally* (logged +
    last-known-good cache returned). Callers see this exception only
    when the JetForge contract is broken (e.g. body fails Pydantic
    validation or status mismatch on a seen-good token).
    """


# ---------------------------------------------------------------------------
# Wire dataclasses (mirror dispatch_manifest.py from JetForge but kept
# decoupled — SDK consumers should not import server-side packages.)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DataAssetProvider:
    """Resource provider principal (JETP-029 alignment)."""

    kind: str
    key: str

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DataAssetProvider":
        return cls(kind=str(raw.get("kind", "user")), key=str(raw.get("key", "")))


@dataclass(frozen=True)
class DataAssetPricing:
    base_price: int = 0
    currency: str = "credits"
    pricing_model: str = "per_use"
    subscription_period_days: Optional[int] = None
    subscription_credits: Optional[int] = None
    max_concurrent: Optional[int] = None
    extra_dimensions: Optional[dict[str, Any]] = None

    @classmethod
    def from_dict(
        cls, raw: Optional[dict[str, Any]]
    ) -> Optional["DataAssetPricing"]:
        if raw is None:
            return None
        return cls(
            base_price=int(raw.get("base_price", 0)),
            currency=str(raw.get("currency", "credits")),
            pricing_model=str(raw.get("pricing_model", "per_use")),
            subscription_period_days=raw.get("subscription_period_days"),
            subscription_credits=raw.get("subscription_credits"),
            max_concurrent=raw.get("max_concurrent"),
            extra_dimensions=raw.get("extra_dimensions"),
        )


@dataclass(frozen=True)
class DataAssetMeta:
    """Wire projection of a JetForge ``DataAsset`` row.

    Frozen + slots-friendly: SDK consumers can hash/compare for diffing.
    Use :meth:`from_dict` to coerce raw dispatch payloads.
    """

    id: str
    name: str
    version: str
    revision: int
    kind: str
    org_id: str
    visibility: str
    usability: str
    provider: DataAssetProvider
    updated_at: str
    display_name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    tags: tuple[str, ...] = ()
    input_schema: Optional[dict[str, Any]] = None
    output_schema: Optional[dict[str, Any]] = None
    connection: Optional[dict[str, Any]] = None
    auth_manifest: Optional[dict[str, Any]] = None
    billable: bool = False
    pricing: Optional[DataAssetPricing] = None
    health_status: Optional[str] = None

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DataAssetMeta":
        tags_raw = raw.get("tags") or ()
        return cls(
            id=str(raw["id"]),
            name=str(raw["name"]),
            version=str(raw["version"]),
            revision=int(raw["revision"]),
            kind=str(raw["kind"]),
            org_id=str(raw["org_id"]),
            visibility=str(raw["visibility"]),
            usability=str(raw["usability"]),
            provider=DataAssetProvider.from_dict(raw.get("provider") or {}),
            updated_at=str(raw["updated_at"]),
            display_name=raw.get("display_name"),
            description=raw.get("description"),
            category=raw.get("category"),
            tags=tuple(tags_raw),
            input_schema=raw.get("input_schema"),
            output_schema=raw.get("output_schema"),
            connection=raw.get("connection"),
            auth_manifest=raw.get("auth_manifest"),
            billable=bool(raw.get("billable", False)),
            pricing=DataAssetPricing.from_dict(raw.get("pricing")),
            health_status=raw.get("health_status"),
        )


@dataclass
class DataAssetSyncResult:
    """Outcome of a :meth:`DataAssetClient.sync` round.

    * ``not_modified`` — server returned 304; caller's cache is fresh.
    * ``updated`` — server returned 200 + a body; caller cache updated.
    * ``degraded`` — server returned 200 with ``degraded=true`` (last-good
      snapshot served while upstream is down). Cache is updated, but the
      caller may want to flag the stale-window.
    """

    digest: str
    revision_high_water: int
    fetched: int
    pages: int
    not_modified: bool = False
    degraded: bool = False
    rate_limited: bool = False
    upstream_unavailable: bool = False
    items: list[DataAssetMeta] = field(default_factory=list)

    @property
    def assets(self) -> list[DataAssetMeta]:
        # Manifest-shape alias consumed by jetagents ``ForgeDataAssetAdapter``
        # (it does ``getattr(manifest, "assets", []) or []``). Keep
        # ``items`` as the canonical attribute; ``assets`` is a forward
        # name-compat surface so the manifest contract reads naturally.
        return self.items


# ---------------------------------------------------------------------------
# DataAssetClient
# ---------------------------------------------------------------------------


class DataAssetClient:
    """Async client for JetForge data-asset dispatch.

    The client is **stateful**: it tracks the last digest and last
    ``revision_high_water`` so subsequent calls become 304 / incremental.
    Construct one client per ``(base_url, api_key, org_id)`` tuple; share
    it across worker tasks.

    Example::

        client = DataAssetClient(base_url="http://jetforge:8000", api_key="jf_...")
        await client.initialize()
        result = await client.sync()  # cold path: fetches all pages
        result2 = await client.sync()  # warm: 304, no body
        for asset in client.snapshot():
            print(asset.id, asset.kind, asset.org_id)

    """

    DEFAULT_PAGE_SIZE = 200
    DISPATCH_PATH = "/api/v1/sdk/data-assets/dispatch"
    # JETP-082 §09/04 — internal credential-resolve endpoint constants;
    # re-exported as class attributes to keep the public surface stable
    # and to give tests / docs a single canonical reference.
    INTERNAL_RESOLVE_PATH_TEMPLATE = _INTERNAL_RESOLVE_PATH_TEMPLATE
    INTERNAL_AUDIENCE = _INTERNAL_AUDIENCE

    def __init__(
        self,
        base_url: str,
        *,
        api_key: Optional[str] = None,
        service_token: Optional[str] = None,
        request_timeout: float = 15.0,
        page_size: int = DEFAULT_PAGE_SIZE,
        org_id: Optional[str] = None,
        max_pages_per_sync: int = 50,
    ) -> None:
        if page_size <= 0 or page_size > 1000:
            raise ValueError("page_size must be in (0, 1000]")
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        # JETP-082 §09/04 — service_token is the bearer used against the
        # /api/v1/internal/* endpoints (must be in
        # ``JETFORGE_INTERNAL_SERVICE_TOKENS``). When unset we fall back to
        # ``api_key`` (handy for local dev) and also honour the
        # ``JETFORGE_SDK_INTERNAL_SERVICE_TOKEN`` env var.
        self._service_token = (
            service_token
            or os.environ.get("JETFORGE_SDK_INTERNAL_SERVICE_TOKEN")
            or None
        )
        self._timeout = float(request_timeout)
        self._page_size = page_size
        self._org_id = org_id
        self._max_pages = max_pages_per_sync

        self._http: Optional[httpx.AsyncClient] = None
        self._lock = asyncio.Lock()

        self._last_digest: Optional[str] = None
        self._last_revision: int = 0
        self._cache: dict[str, DataAssetMeta] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        if self._http is not None:
            return
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
            headers=self._headers(),
        )

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def __aenter__(self) -> "DataAssetClient":
        await self.initialize()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def snapshot(self) -> list[DataAssetMeta]:
        """Return the latest in-memory cache (immutable copy)."""
        return list(self._cache.values())

    def get(self, asset_id: str) -> Optional[DataAssetMeta]:
        return self._cache.get(asset_id)

    @property
    def last_digest(self) -> Optional[str]:
        return self._last_digest

    @property
    def last_revision(self) -> int:
        return self._last_revision

    async def sync(
        self,
        *,
        kind: Optional[str] = None,
        force_full: bool = False,
    ) -> DataAssetSyncResult:
        """Pull the latest manifest with ETag + ``since_revision`` semantics.

        On 304, the in-memory cache is left untouched and ``not_modified``
        is set.

        ``force_full`` resets the ``since_revision`` cursor — useful after
        a process restart or whenever the consumer wants to re-prime the
        full state.
        """
        await self.initialize()
        async with self._lock:
            since = 0 if force_full else self._last_revision
            digest_hint = None if force_full else self._last_digest
            return await self._sync_impl(
                kind=kind, since=since, digest_hint=digest_hint
            )

    async def dispatch_resolve_credential(
        self,
        *,
        request: "ResolveRequest",
        bearer_token: str,
        manifest: Any = None,
    ) -> Optional[dict[str, Any]]:
        """JIT decrypt + locally assemble the auth bundle (SDK v0.5.0 / v0.3 path B).

        Thin facade — the heavy lifting (HTTP, payload validation,
        placement assembly) lives in
        :func:`jetforge_sdk._credential_resolve.dispatch_resolve_credential`.
        Keeping the entry point on this class preserves the
        ``DataAssetResolver._sdk.dispatch_resolve_credential`` protocol
        consumed by jetagents (see JETP-082.1 §03_sdk_protocol/01).

        Parameters
        ----------
        request:
            :class:`ResolveRequest` (``tool_id`` + ``environment``). All
            caller identity / binding-axis projection has been removed
            from the SDK; the server reads them from the OBO bearer JWT.
        bearer_token:
            OBO JWT minted by jetagents ``AuthAssembler``; carries the
            current ``current_act_chain``.
        manifest:
            Optional manifest passed to ``apply_placement`` for local
            bundle assembly. The server uses **none** of it.

        See spec ``03_sdk_protocol/01_dispatch_resolve_credential_v2.md``
        for the full contract; ``None`` on every failure path with
        structured logs that never carry secret bytes.
        """
        await self.initialize()
        assert self._http is not None
        return await _dispatch_resolve_credential_impl(
            self._http,
            request=request,
            bearer_token=bearer_token,
            manifest=manifest,
            api_key=self._api_key,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Accept": "application/json"}
        if self._api_key:
            h["Authorization"] = f"Bearer {self._api_key}"
        return h

    async def _sync_impl(
        self,
        *,
        kind: Optional[str],
        since: int,
        digest_hint: Optional[str],
    ) -> DataAssetSyncResult:
        assert self._http is not None
        params: dict[str, Any] = {
            "since_revision": since,
            "page": 1,
            "page_size": self._page_size,
        }
        if kind is not None:
            params["kind"] = kind
        if self._org_id is not None:
            params["org_id"] = self._org_id

        headers: dict[str, str] = {}
        if digest_hint is not None and since == 0:
            # Only 304-probe on a full refresh; on incremental polls we
            # always want the body.
            headers["If-None-Match"] = f'"{digest_hint}"'
            params["digest"] = digest_hint

        first = await self._http.get(
            self.DISPATCH_PATH,
            params=params,
            headers=headers,
        )

        if first.status_code == 304:
            return DataAssetSyncResult(
                digest=self._last_digest or "",
                revision_high_water=self._last_revision,
                fetched=0,
                pages=0,
                not_modified=True,
                items=list(self._cache.values()),
            )
        if first.status_code == 429:
            retry = first.headers.get("Retry-After", "1")
            logger.warning(
                "dispatch rate-limited; retry-after=%s", retry
            )
            return DataAssetSyncResult(
                digest=self._last_digest or "",
                revision_high_water=self._last_revision,
                fetched=0,
                pages=0,
                rate_limited=True,
                items=list(self._cache.values()),
            )
        if first.status_code == 503:
            logger.warning("dispatch upstream unavailable")
            return DataAssetSyncResult(
                digest=self._last_digest or "",
                revision_high_water=self._last_revision,
                fetched=0,
                pages=0,
                upstream_unavailable=True,
                items=list(self._cache.values()),
            )
        first.raise_for_status()

        payload = first.json()
        digest = str(payload["digest"])
        rev_hw = int(payload["revision_high_water"])
        pages = int(payload.get("pages", 1))
        degraded = bool(payload.get("degraded", False))

        all_items: list[DataAssetMeta] = []
        for raw in payload.get("assets") or ():
            asset = DataAssetMeta.from_dict(raw)
            self._cache[asset.id] = asset
            all_items.append(asset)

        cur = 1
        while cur < pages and cur < self._max_pages:
            cur += 1
            params["page"] = cur
            page_res = await self._http.get(
                self.DISPATCH_PATH, params=params
            )
            if page_res.status_code != 200:
                logger.warning(
                    "dispatch pagination broke at page=%d status=%d",
                    cur, page_res.status_code,
                )
                break
            page_body = page_res.json()
            for raw in page_body.get("assets") or ():
                asset = DataAssetMeta.from_dict(raw)
                self._cache[asset.id] = asset
                all_items.append(asset)
            # Trust the original digest/revision; they are org-wide and
            # only computed once per request even across pages.

        self._last_digest = digest
        self._last_revision = rev_hw
        return DataAssetSyncResult(
            digest=digest,
            revision_high_water=rev_hw,
            fetched=len(all_items),
            pages=pages,
            degraded=degraded,
            items=all_items,
        )
