"""
JetForge SDK — Client library for JetForge integration.

Provides:
- ForgeClient: async HTTP/WebSocket client for capability discovery and updates
- Data models: CapabilityMetadata, PromptContent, AgentConfigContent, etc.
- Adapters: ForgeComponentAdapter, ForgeToolAdapter

Quick start::

    from jetforge_sdk import ForgeClient

    client = ForgeClient(base_url="http://jetforge:8000", api_key="...")
    await client.initialize()
    capabilities = await client.get_all_metadata()
"""

from jetforge_sdk.admin import (
    AdminError,
    DryRunIssue,
    DryRunSummary,
    ModelLakeAdminClient,
    SpecLifecycleResponse,
    SpecRow,
)
from jetforge_sdk._credential_resolve import (
    ResolveRequest,
    dispatch_resolve_credential_legacy,
)
from jetforge_sdk.data_asset_client import (
    DataAssetClient,
    DataAssetClientError,
    DataAssetMeta,
    DataAssetPricing,
    DataAssetProvider,
    DataAssetSyncResult,
)
from jetforge_sdk.forge_client import (
    AgentConfigContent,
    CacheEntry,
    CapabilityMetadata,
    CapabilityType,
    ForgeClient,
    PromptContent,
    SkillFileInfo,
)

__all__ = [
    "AdminError",
    "AgentConfigContent",
    "CacheEntry",
    "CapabilityMetadata",
    "CapabilityType",
    "DataAssetClient",
    "DataAssetClientError",
    "DataAssetMeta",
    "DataAssetPricing",
    "DataAssetProvider",
    "DataAssetSyncResult",
    "DryRunIssue",
    "DryRunSummary",
    "ForgeClient",
    "ModelLakeAdminClient",
    "PromptContent",
    "ResolveRequest",
    "SkillFileInfo",
    "SpecLifecycleResponse",
    "SpecRow",
    "dispatch_resolve_credential_legacy",
]

# JETP-082.1 v0.3 path B — hard break vs 0.4.x:
#   * ``ResolveRequest`` only accepts ``tool_id`` + ``environment``;
#   * ``DataAssetClient.dispatch_resolve_credential`` requires ``bearer_token``;
#   * ``resolve_binding`` removed; ``dispatch_resolve_credential_legacy``
#     kept (DeprecationWarning) for un-migrated GET callers.
__version__ = "0.5.0"
