"""
jetforge_sdk.admin.cli — argparse-based CLI for RFC-006 §13 spec lifecycle.

Usage::

    jetforge spec upload anthropic.yaml --dry-run
    jetforge spec dryrun anthropic.yaml
    jetforge spec activate anthropic-claude-3-5-sonnet --version 1.2.0
    jetforge spec rollback anthropic-claude-3-5-sonnet \
        --to-version 1.1.0 --reason "regression in tool calls"
    jetforge spec list --status active
    jetforge spec versions anthropic-claude-3-5-sonnet

Environment variables:
- ``JETFORGE_MODEL_LAKE_BASE_URL``  (default ``http://localhost:8080``)
- ``JETFORGE_MODEL_LAKE_TOKEN``     admin JWT (Bearer)
- ``JETFORGE_AUTH_INSTANCE_ID``     optional X-Auth-Instance-ID

Exit codes:
- 0  success
- 1  generic CLI error / unhandled exception
- 2  argument parse error (argparse default)
- 3  AdminError (HTTP 4xx/5xx with structured error envelope)
- 4  IO error reading the YAML file

Spec mapping: AC-ADM-009-SDK (RFC-006 §13).
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from jetforge_sdk.admin.model_lake_specs import (
    AdminError,
    ModelLakeAdminClient,
    SpecLifecycleResponse,
    SpecRow,
)


_EXIT_OK = 0
_EXIT_GENERIC = 1
_EXIT_ARG = 2  # argparse default
_EXIT_ADMIN_ERR = 3
_EXIT_IO_ERR = 4


# ── helpers ─────────────────────────────────────────────────────────────────


def _read_yaml(path: str) -> bytes:
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as e:
        print(f"error: cannot read {path}: {e}", file=sys.stderr)
        sys.exit(_EXIT_IO_ERR)
    if not data:
        print(f"error: {path} is empty", file=sys.stderr)
        sys.exit(_EXIT_IO_ERR)
    return data


def _make_client(args: argparse.Namespace) -> ModelLakeAdminClient:
    base_url = (
        args.base_url
        or os.environ.get("JETFORGE_MODEL_LAKE_BASE_URL")
        or "http://localhost:8080"
    )
    token = args.token or os.environ.get("JETFORGE_MODEL_LAKE_TOKEN")
    auth_instance_id = (
        args.auth_instance_id or os.environ.get("JETFORGE_AUTH_INSTANCE_ID")
    )
    return ModelLakeAdminClient(
        base_url=base_url,
        token=token,
        auth_instance_id=auth_instance_id,
        timeout=args.timeout,
    )


def _print_lifecycle(resp: SpecLifecycleResponse, *, json_out: bool) -> None:
    if json_out:
        print(json.dumps(resp.raw, indent=2, sort_keys=True))
        return
    status = resp.status or ("draft" if not resp.persisted else resp.status or "active")
    print(f"spec_id : {resp.spec_id}")
    print(f"version : {resp.version}")
    print(f"vendor  : {resp.vendor}")
    print(f"sha256  : {resp.sha256_hex}")
    print(f"status  : {status}")
    print(f"persist : {resp.persisted}")
    dr = resp.dry_run
    if dr.total or dr.issues:
        print(
            f"dryrun  : total={dr.total} passed={dr.passed} skipped={dr.skipped} "
            f"all_passed={dr.all_passed} duration_ms={dr.duration_ms}"
        )
        for i, issue in enumerate(dr.issues):
            print(
                f"  [{i:02d}] {issue.severity} name={issue.name} mode={issue.mode} "
                f"kind={issue.kind} reason={issue.reason}"
            )


def _print_rows(rows: list[SpecRow], *, json_out: bool) -> None:
    if json_out:
        print(
            json.dumps(
                [r.__dict__ for r in rows],
                indent=2,
                sort_keys=True,
            )
        )
        return
    if not rows:
        print("(no specs)")
        return
    headers = ["spec_id", "version", "status", "canary%", "vendor", "realm_id"]
    print("\t".join(headers))
    for r in rows:
        print(
            "\t".join(
                [
                    r.spec_id,
                    r.version,
                    r.status,
                    str(r.canary_percent),
                    r.vendor,
                    r.realm_id,
                ]
            )
        )


# ── command handlers ────────────────────────────────────────────────────────


def _cmd_upload(args: argparse.Namespace) -> int:
    yaml_bytes = _read_yaml(args.path)
    with _make_client(args) as cli:
        resp = cli.upload_yaml_bytes(
            yaml_bytes,
            dry_run=args.dry_run,
            skip_dryrun=args.skip_dryrun,
            note=args.note,
            idempotency_key=args.idempotency_key,
        )
    _print_lifecycle(resp, json_out=args.json)
    return _EXIT_OK


def _cmd_dryrun(args: argparse.Namespace) -> int:
    yaml_bytes = _read_yaml(args.path)
    with _make_client(args) as cli:
        resp = cli.dryrun_yaml_bytes(
            yaml_bytes,
            skip_dryrun=args.skip_dryrun,
            note=args.note,
        )
    _print_lifecycle(resp, json_out=args.json)
    if not resp.dry_run.all_passed and resp.dry_run.total > 0:
        return _EXIT_GENERIC
    return _EXIT_OK


def _cmd_activate(args: argparse.Namespace) -> int:
    with _make_client(args) as cli:
        data = cli.activate(
            args.spec_id,
            args.version,
            reason=args.reason,
            idempotency_key=args.idempotency_key,
        )
    if args.json:
        print(json.dumps(data, indent=2, sort_keys=True))
    else:
        print(f"activated: {args.spec_id}@{args.version}")
        if data:
            for k, v in sorted(data.items()):
                print(f"  {k}: {v}")
    return _EXIT_OK


def _cmd_rollback(args: argparse.Namespace) -> int:
    with _make_client(args) as cli:
        data = cli.rollback(
            args.spec_id,
            args.to_version,
            reason=args.reason,
            idempotency_key=args.idempotency_key,
        )
    if args.json:
        print(json.dumps(data, indent=2, sort_keys=True))
    else:
        print(f"rolled back: {args.spec_id} -> {args.to_version}")
        if data:
            for k, v in sorted(data.items()):
                print(f"  {k}: {v}")
    return _EXIT_OK


def _cmd_list(args: argparse.Namespace) -> int:
    with _make_client(args) as cli:
        rows = cli.list_specs(
            vendor=args.vendor,
            status=args.status,
            page=args.page,
            page_size=args.page_size,
        )
    _print_rows(rows, json_out=args.json)
    return _EXIT_OK


def _cmd_versions(args: argparse.Namespace) -> int:
    with _make_client(args) as cli:
        rows = cli.list_versions(args.spec_id)
    _print_rows(rows, json_out=args.json)
    return _EXIT_OK


# ── argparse wiring ─────────────────────────────────────────────────────────


def _add_global_flags(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--base-url",
        default=None,
        help="model-lake base URL (default: $JETFORGE_MODEL_LAKE_BASE_URL or http://localhost:8080)",
    )
    p.add_argument(
        "--token",
        default=None,
        help="admin JWT (default: $JETFORGE_MODEL_LAKE_TOKEN)",
    )
    p.add_argument(
        "--auth-instance-id",
        default=None,
        help="X-Auth-Instance-ID header value (default: $JETFORGE_AUTH_INSTANCE_ID)",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="HTTP timeout in seconds (default: 30.0)",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="emit raw JSON instead of human-readable lines",
    )


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="jetforge",
        description="JetForge admin CLI (RFC-006 §13 spec lifecycle).",
    )
    sub = p.add_subparsers(dest="resource", required=True)

    spec = sub.add_parser(
        "spec",
        help="model-lake spec lifecycle: upload / dryrun / activate / rollback / list / versions",
    )
    spec_sub = spec.add_subparsers(dest="action", required=True)

    up = spec_sub.add_parser("upload", help="upload a spec YAML")
    up.add_argument("path", help="path to OpenAPI spec YAML file")
    up.add_argument("--dry-run", action="store_true", help="validate-only; do not persist")
    up.add_argument("--skip-dryrun", action="store_true", help="skip L3 conformance (admin only)")
    up.add_argument("--note", default="", help="upload note (audit metadata)")
    up.add_argument("--idempotency-key", default=None)
    _add_global_flags(up)
    up.set_defaults(func=_cmd_upload)

    dr = spec_sub.add_parser("dryrun", help="dry-run a spec YAML (never persists)")
    dr.add_argument("path")
    dr.add_argument("--skip-dryrun", action="store_true")
    dr.add_argument("--note", default="")
    _add_global_flags(dr)
    dr.set_defaults(func=_cmd_dryrun)

    act = spec_sub.add_parser("activate", help="activate a spec version")
    act.add_argument("spec_id")
    act.add_argument("--version", required=True)
    act.add_argument("--reason", default="")
    act.add_argument("--idempotency-key", default=None)
    _add_global_flags(act)
    act.set_defaults(func=_cmd_activate)

    rb = spec_sub.add_parser("rollback", help="rollback to a deprecated version")
    rb.add_argument("spec_id")
    rb.add_argument("--to-version", required=True)
    rb.add_argument(
        "--reason",
        required=True,
        help="rollback reason (audited; required by server)",
    )
    rb.add_argument("--idempotency-key", default=None)
    _add_global_flags(rb)
    rb.set_defaults(func=_cmd_rollback)

    ls = spec_sub.add_parser("list", help="list specs (active by default)")
    ls.add_argument("--vendor", default=None)
    ls.add_argument("--status", default=None, choices=["active", "draft", "deprecated", "disabled"])
    ls.add_argument("--page", type=int, default=None)
    ls.add_argument("--page-size", type=int, default=None)
    _add_global_flags(ls)
    ls.set_defaults(func=_cmd_list)

    vers = spec_sub.add_parser("versions", help="list all versions for a spec")
    vers.add_argument("spec_id")
    _add_global_flags(vers)
    vers.set_defaults(func=_cmd_versions)

    return p


# ── entry point ─────────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        return _EXIT_ARG

    try:
        return int(func(args) or _EXIT_OK)
    except AdminError as e:
        print(f"admin error: {e}", file=sys.stderr)
        if e.body:
            try:
                print(json.dumps(e.body, indent=2, sort_keys=True), file=sys.stderr)
            except (TypeError, ValueError):
                print(str(e.body), file=sys.stderr)
        return _EXIT_ADMIN_ERR
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return _EXIT_GENERIC


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
