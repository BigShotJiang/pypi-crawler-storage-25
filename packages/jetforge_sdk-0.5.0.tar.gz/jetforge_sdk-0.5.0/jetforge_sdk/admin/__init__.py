"""
jetforge_sdk.admin — Model-Lake admin API client surface.

RFC-006 §13 admin tooling consumer-side library. Provides:
- ModelLakeAdminClient: synchronous HTTP client for spec lifecycle (upload /
  dryrun / activate / canary / rollback / delete / gc) operations.
- AdminError / SpecLifecycleResponse / DryRunSummary / SpecRow data classes.
- jetforge_sdk.admin.cli: Typer-free argparse-based CLI exposing
  ``jetforge spec ...`` subcommands (entry point declared in pyproject.toml).

Spec mapping:
- AC-ADM-009-SDK (RFC-006 §13 AC table, post-deviation D13): a
  ``jetforge spec upload anthropic.yaml --dry-run`` invocation must exit 0
  and print spec_id + version + status=draft.
"""

from jetforge_sdk.admin.model_lake_specs import (
    AdminError,
    DryRunIssue,
    DryRunSummary,
    ModelLakeAdminClient,
    SpecLifecycleResponse,
    SpecRow,
)

__all__ = [
    "AdminError",
    "DryRunIssue",
    "DryRunSummary",
    "ModelLakeAdminClient",
    "SpecLifecycleResponse",
    "SpecRow",
]
