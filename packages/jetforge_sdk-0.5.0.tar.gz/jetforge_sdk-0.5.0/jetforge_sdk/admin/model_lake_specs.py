"""
ModelLakeAdminClient — synchronous HTTP client for model-lake RFC-006 §13
admin spec lifecycle endpoints.

Design contract:
- Synchronous (httpx.Client) — admin tooling runs from operator workstations
  / CI scripts where async machinery would be overkill.
- Stateless: no caching, no retries beyond httpx defaults; caller decides.
- Fail-fast on HTTP 4xx/5xx — raise ``AdminError`` carrying the parsed
  jperrcode envelope (``code`` + ``message``).
- All request/response shapes mirror
  model-lake/internal/features/api/admin/specs/dto.go 1:1.
- AuthN: a Bearer token is required (admin JWT); the client also forwards an
  optional ``X-Auth-Instance-ID`` header (multi-region federation per
  RFC-005 §11).
- Idempotency: caller may pass ``Idempotency-Key`` header verbatim — the
  client does not generate one (idempotent semantics belong to the caller).

Spec mapping: RFC-006 §13 §1 endpoint table; AC-ADM-009-SDK acceptance.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import httpx


# ── error envelope ──────────────────────────────────────────────────────────


class AdminError(RuntimeError):
    """Raised on HTTP 4xx/5xx with the model-lake jperrcode envelope."""

    def __init__(
        self,
        status_code: int,
        code: int | None,
        message: str,
        body: Any | None = None,
    ) -> None:
        super().__init__(f"[HTTP {status_code} code={code}] {message}")
        self.status_code = status_code
        self.code = code
        self.message = message
        self.body = body


# ── DTOs (mirror dto.go) ────────────────────────────────────────────────────


@dataclass
class DryRunIssue:
    """Mirror of model-lake admin_specs.DryRunIssue."""

    severity: str
    name: str = ""
    mode: str = ""
    kind: str = ""
    reason: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DryRunIssue":
        return cls(
            severity=d.get("severity", ""),
            name=d.get("name", ""),
            mode=d.get("mode", ""),
            kind=d.get("kind", ""),
            reason=d.get("reason", ""),
        )


@dataclass
class DryRunSummary:
    """Mirror of model-lake admin_specs.DryRunSummary."""

    total: int = 0
    passed: int = 0
    skipped: int = 0
    duration_ms: int = 0
    all_passed: bool = True
    issues: list[DryRunIssue] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any] | None) -> "DryRunSummary":
        if not d:
            return cls()
        return cls(
            total=int(d.get("total", 0)),
            passed=int(d.get("passed", 0)),
            skipped=int(d.get("skipped", 0)),
            duration_ms=int(d.get("duration_ms", 0)),
            all_passed=bool(d.get("all_passed", True)),
            issues=[DryRunIssue.from_dict(i) for i in (d.get("issues") or [])],
        )


@dataclass
class SpecLifecycleResponse:
    """Combined upload / dryrun / activate / rollback response shape.

    Successful uploads / dryruns return a non-empty ``spec_id`` + ``version``;
    activate / rollback / canary do not always echo these (the API typically
    returns an audit-emitting 200 with a thin payload), so fields are
    optional.
    """

    spec_id: str = ""
    version: str = ""
    vendor: str = ""
    sha256_hex: str = ""
    persisted: bool = False
    status: str = ""
    dry_run: DryRunSummary = field(default_factory=DryRunSummary)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SpecLifecycleResponse":
        return cls(
            spec_id=str(d.get("spec_id", "")),
            version=str(d.get("version", "")),
            vendor=str(d.get("vendor", "")),
            sha256_hex=str(d.get("sha256_hex", "")),
            persisted=bool(d.get("persisted", False)),
            status=str(d.get("status", "")),
            dry_run=DryRunSummary.from_dict(d.get("dry_run")),
            raw=d,
        )


@dataclass
class SpecRow:
    """Mirror of model-lake admin_specs.SpecRow (list / get item)."""

    spec_id: str
    version: str
    status: str
    vendor: str = ""
    canary_percent: int = 0
    shadow_rate: float = 0.0
    sha256_hex: str = ""
    activated_at: int = 0
    deactivated_at: int = 0
    created_at: int = 0
    created_by: str = ""
    realm_id: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SpecRow":
        return cls(
            spec_id=str(d.get("spec_id", "")),
            version=str(d.get("version", "")),
            status=str(d.get("status", "")),
            vendor=str(d.get("vendor", "")),
            canary_percent=int(d.get("canary_percent", 0)),
            shadow_rate=float(d.get("shadow_rate", 0.0)),
            sha256_hex=str(d.get("sha256_hex", "")),
            activated_at=int(d.get("activated_at", 0)),
            deactivated_at=int(d.get("deactivated_at", 0)),
            created_at=int(d.get("created_at", 0)),
            created_by=str(d.get("created_by", "")),
            realm_id=str(d.get("realm_id", "")),
        )


# ── client ──────────────────────────────────────────────────────────────────


class ModelLakeAdminClient:
    """Sync admin client for RFC-006 §13 spec lifecycle.

    Usage::

        with ModelLakeAdminClient(
            base_url="https://model-lake.example.com",
            token="<admin JWT>",
        ) as cli:
            resp = cli.upload_yaml_bytes(yaml_bytes, dry_run=True)
            print(resp.spec_id, resp.version, resp.dry_run.all_passed)
    """

    DEFAULT_TIMEOUT = 30.0

    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        *,
        auth_instance_id: str | None = None,
        timeout: float | None = None,
        client: httpx.Client | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.auth_instance_id = auth_instance_id
        self.timeout = timeout if timeout is not None else self.DEFAULT_TIMEOUT
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=self.timeout)

    def __enter__(self) -> "ModelLakeAdminClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    # ── private plumbing ───────────────────────────────────────────────

    def _headers(self, idempotency_key: str | None = None) -> dict[str, str]:
        h: dict[str, str] = {"Accept": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        if self.auth_instance_id:
            h["X-Auth-Instance-ID"] = self.auth_instance_id
        if idempotency_key:
            h["Idempotency-Key"] = idempotency_key
        return h

    def _do_json(
        self,
        method: str,
        path: str,
        *,
        json_body: Any | None = None,
        params: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = self._headers(idempotency_key=idempotency_key)
        if json_body is not None:
            headers["Content-Type"] = "application/json"

        resp = self._client.request(
            method,
            url,
            headers=headers,
            json=json_body,
            params=params,
        )
        body: Any
        try:
            body = resp.json() if resp.content else {}
        except json.JSONDecodeError:
            body = {"raw": resp.text}

        if resp.status_code >= 400:
            code = body.get("code") if isinstance(body, dict) else None
            message = (
                body.get("message")
                if isinstance(body, dict) and body.get("message")
                else resp.reason_phrase
            )
            raise AdminError(resp.status_code, code, str(message), body=body)

        if isinstance(body, dict) and "data" in body:
            data = body["data"]
            if isinstance(data, dict):
                return data
            return {"value": data}
        return body if isinstance(body, dict) else {"value": body}

    # ── upload / dryrun ───────────────────────────────────────────────

    def upload_yaml_bytes(
        self,
        yaml_bytes: bytes,
        *,
        dry_run: bool = False,
        skip_dryrun: bool = False,
        note: str = "",
        idempotency_key: str | None = None,
    ) -> SpecLifecycleResponse:
        """POST /admin/v1/specs/upload — upload + optional dryrun.

        Payload follows admin_specs.UploadInput exactly. ``yaml`` is sent as
        a JSON-base64-decoded bytes field (the model-lake handler already
        accepts ``yaml: []byte`` JSON encoding).
        """
        payload: dict[str, Any] = {
            "yaml": list(yaml_bytes),
            "dry_run": dry_run,
            "skip_dryrun": skip_dryrun,
        }
        if note:
            payload["note"] = note
        data = self._do_json(
            "POST",
            "/admin/v1/specs/upload",
            json_body=payload,
            idempotency_key=idempotency_key,
        )
        return SpecLifecycleResponse.from_dict(data)

    def dryrun_yaml_bytes(
        self,
        yaml_bytes: bytes,
        *,
        skip_dryrun: bool = False,
        note: str = "",
    ) -> SpecLifecycleResponse:
        """POST /admin/v1/specs/dryrun — never persists, always validates."""
        payload: dict[str, Any] = {
            "yaml": list(yaml_bytes),
            "dry_run": True,
            "skip_dryrun": skip_dryrun,
        }
        if note:
            payload["note"] = note
        data = self._do_json("POST", "/admin/v1/specs/dryrun", json_body=payload)
        return SpecLifecycleResponse.from_dict(data)

    # ── lifecycle ──────────────────────────────────────────────────────

    def activate(
        self,
        spec_id: str,
        version: str,
        *,
        reason: str = "",
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """POST /admin/v1/specs/{spec_id}/activate."""
        return self._do_json(
            "POST",
            f"/admin/v1/specs/{spec_id}/activate",
            json_body={"version": version, "reason": reason},
            idempotency_key=idempotency_key,
        )

    def rollback(
        self,
        spec_id: str,
        to_version: str,
        *,
        reason: str,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """POST /admin/v1/specs/{spec_id}/rollback.

        Per RFC-006 §13 AC-ADM-007 the target version must be deprecated
        within 30 days; the server returns 422 + ``ErrSpecRollbackOutOfWindow``
        otherwise.
        """
        return self._do_json(
            "POST",
            f"/admin/v1/specs/{spec_id}/rollback",
            json_body={"to_version": to_version, "reason": reason},
            idempotency_key=idempotency_key,
        )

    # ── query ──────────────────────────────────────────────────────────

    def list_specs(
        self,
        *,
        vendor: str | None = None,
        status: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
    ) -> list[SpecRow]:
        """GET /admin/v1/specs — list active specs (caller realm + system)."""
        params: dict[str, Any] = {}
        if vendor:
            params["vendor"] = vendor
        if status:
            params["status"] = status
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        data = self._do_json("GET", "/admin/v1/specs", params=params or None)
        items = data.get("items", []) if isinstance(data, dict) else []
        return [SpecRow.from_dict(i) for i in items]

    def get_spec(self, spec_id: str) -> dict[str, Any]:
        """GET /admin/v1/specs/{spec_id}."""
        return self._do_json("GET", f"/admin/v1/specs/{spec_id}")

    def list_versions(self, spec_id: str) -> list[SpecRow]:
        """GET /admin/v1/specs/{spec_id}/versions."""
        data = self._do_json("GET", f"/admin/v1/specs/{spec_id}/versions")
        items = data.get("items", []) if isinstance(data, dict) else []
        return [SpecRow.from_dict(i) for i in items]
