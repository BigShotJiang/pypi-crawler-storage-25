"""``DataAssetClient.dispatch_resolve_credential`` implementation (v0.5.0).

JETP-082.1 v0.3 path B — caller envelope is reduced to **two fields**:

* ``tool_id``：what to resolve credentials for
* ``environment``：runtime context

The caller's identity, organisation membership, binding axis projection,
hash algorithm — *everything else* — is the JetForge server's domain.
The SDK simply forwards the OBO ``Authorization: Bearer <token>`` header;
the server's ``inbound_act`` middleware reads the JWT act-chain and the
``caller_org_resolver`` derives the rest.

Why the rewrite?
================
v0.4.x had the caller compute ``binding_key`` itself, which leaked
JetForge's binding-axis concept into every consumer (领域泄漏 P4). v0.3
adopts the "service boundary autonomy" principle: caller declares intent
(``tool_id`` + ``environment``); resource owner (JetForge) decides how
to look up the credential. See spec ``03_sdk_protocol/01_dispatch_resolve
_credential_v2.md``.

Break change
============
SDK 0.5.0 is a *hard* break:
* ``ResolveRequest`` dataclass no longer accepts ``binding_key`` /
  ``binding_axes`` / ``principal_*`` (constructing with those raises
  ``TypeError``).
* The legacy ``dispatch_resolve_credential(tool_id=, binding_key=, ...)``
  positional/keyword form is **removed**.
* ``dispatch_resolve_credential_legacy`` is retained for un-migrated
  callers; it issues a ``DeprecationWarning`` and uses the old GET path.

See ``02_audit_trail.md`` AC-SDK-001~006 for acceptance contracts.
"""
from __future__ import annotations

import hashlib
import logging
import time
import warnings
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from jetforge_sdk._credential_assembly import apply_placement


logger = logging.getLogger(__name__)


__all__ = [
    "INTERNAL_AUDIENCE",
    "INTERNAL_RESOLVE_PATH_TEMPLATE",
    "ResolveRequest",
    "coerce_manifest",
    "dispatch_resolve_credential",
    "dispatch_resolve_credential_legacy",
]


INTERNAL_RESOLVE_PATH_TEMPLATE = (
    "/api/v1/internal/tools/{tool_id}/credentials/resolve"
)
INTERNAL_AUDIENCE = "jetforge.internal"


# Retry policy — POST is idempotent w/ Idempotency-Key header.
_RETRY_MAX = 3
_RETRY_BASE_BACKOFF_S = 0.2


# ---------- Public dataclass ----------


@dataclass(frozen=True, slots=True)
class ResolveRequest:
    """Minimal v0.3 path B caller envelope.

    Fields
    ------
    tool_id:
        Logical tool / data-asset identifier (e.g. ``"forge--query-data--v1_0_0"``).
        Used both for the URL path and as a body field for audit symmetry.
    environment:
        Runtime context (e.g. ``"production"`` / ``"default"`` / ``"staging"``).
        The server projects this onto the ``environment`` axis when computing
        the binding key — caller does *not* know which axes the manifest
        declares.

    Notes
    -----
    * ``frozen=True`` + ``slots=True``：immutable, lightweight; safe to
      pass through retry/cache layers without defensive copies.
    * Constructing with any other keyword (``binding_key``, ``principal_*``,
      ``org_id``, ``axes``, ...) raises ``TypeError`` — protected by
      ``slots``. This is the v0.5.0 break-change guard.
    """

    tool_id: str
    environment: str

    def __post_init__(self) -> None:
        if not self.tool_id or not isinstance(self.tool_id, str):
            raise ValueError(f"ResolveRequest.tool_id must be non-empty str, got {self.tool_id!r}")
        if not self.environment or not isinstance(self.environment, str):
            raise ValueError(
                f"ResolveRequest.environment must be non-empty str, got {self.environment!r}"
            )


def coerce_manifest(manifest: Any) -> Optional[dict[str, Any]]:
    """Normalise pydantic / dict manifests to a plain ``dict``.

    Returns ``None`` when the input is empty (``{}`` or falsy) — the
    caller treats that as "asset has no auth requirement".

    Kept for compatibility with ``DataAssetClient`` which still passes
    ``manifest`` for *local* placement assembly (``apply_placement``).
    """
    if isinstance(manifest, dict):
        return manifest if manifest else None
    dumper = getattr(manifest, "model_dump", None)
    if callable(dumper):
        try:
            dumped = dumper(mode="json")
        except TypeError:
            dumped = dumper()
        if isinstance(dumped, dict):
            return dumped if dumped else None
    d = getattr(manifest, "__dict__", None)
    if isinstance(d, dict) and d:
        return d
    return None


# ---------- v0.5.0 main entrypoint ----------


async def dispatch_resolve_credential(
    http: httpx.AsyncClient,
    *,
    request: ResolveRequest,
    bearer_token: str,
    manifest: Any = None,
    api_key: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """JetForge POST v2 resolve — JIT decrypt + local placement assembly.

    Parameters
    ----------
    http:
        An ``httpx.AsyncClient`` pre-configured by ``DataAssetClient`` (base
        URL, default headers, transport pool).
    request:
        Mandatory :class:`ResolveRequest` — must hold non-empty
        ``tool_id`` and ``environment``.
    bearer_token:
        OBO JWT carrying the caller's act-chain. JetForge will reject
        the request with 401 if missing; we fail-fast here to avoid a
        wasted round-trip.
    manifest:
        Optional manifest dict / pydantic model. **Server uses none of
        it**; we keep it only to feed ``apply_placement`` for the local
        bundle. ``None`` → handler downstream gets ``{}`` placement which
        is acceptable for ``db-password`` (server kind override).
    api_key:
        Optional site-level network-layer auth (``X-API-Key`` header).
        Independent of caller identity.

    Returns
    -------
    Local auth bundle dict, or ``None`` on any failure path (with a
    structured log line free of secret bytes).
    """
    if not bearer_token:
        raise ValueError("dispatch_resolve_credential: bearer_token is required (v0.3 path B)")

    body = {
        "tool_id": request.tool_id,
        "environment": request.environment,
    }
    headers: dict[str, str] = {
        "Authorization": f"Bearer {bearer_token}",
        "X-Service-Audience": INTERNAL_AUDIENCE,
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Idempotency-Key": _idempotency_key(bearer_token, body),
    }
    if api_key:
        headers["X-API-Key"] = api_key

    path = INTERNAL_RESOLVE_PATH_TEMPLATE.format(tool_id=request.tool_id)

    response: httpx.Response | None = None
    last_exc: Exception | None = None
    for attempt in range(_RETRY_MAX):
        try:
            response = await http.post(path, json=body, headers=headers)
        except httpx.TimeoutException as exc:
            last_exc = exc
            logger.warning(
                "[JETP-082.1/sdk] resolve(%s) timeout attempt=%d/%d",
                request.tool_id,
                attempt + 1,
                _RETRY_MAX,
            )
            if attempt == _RETRY_MAX - 1:
                return None
            await _sleep_backoff(attempt)
            continue
        except httpx.TransportError as exc:
            last_exc = exc
            logger.warning(
                "[JETP-082.1/sdk] resolve(%s) transport error %s attempt=%d/%d",
                request.tool_id,
                type(exc).__name__,
                attempt + 1,
                _RETRY_MAX,
            )
            if attempt == _RETRY_MAX - 1:
                return None
            await _sleep_backoff(attempt)
            continue
        except Exception as exc:
            logger.exception(
                "[JETP-082.1/sdk] resolve(%s) unexpected error: %s",
                request.tool_id,
                type(exc).__name__,
            )
            return None
        # Successful HTTP exchange — break retry loop.
        break

    if response is None:
        logger.error(
            "[JETP-082.1/sdk] resolve(%s) exhausted retries: %s",
            request.tool_id,
            last_exc,
        )
        return None

    status = response.status_code
    if status != 200:
        if status in (401, 403):
            logger.warning(
                "[JETP-082.1/sdk] resolve(%s) %d — bearer_token rejected / "
                "audience misconfigured?",
                request.tool_id,
                status,
            )
        elif status == 404:
            logger.info(
                "[JETP-082.1/sdk] resolve(%s) 404 — credential not found "
                "for env=%s (server-side caller_org derivation may have "
                "fallen through)",
                request.tool_id,
                request.environment,
            )
        elif status == 405:
            logger.error(
                "[JETP-082.1/sdk] resolve(%s) 405 — JetForge does not "
                "support POST v2; upgrade server to JETP-082.1 minimum version",
                request.tool_id,
            )
        elif status == 429:
            logger.warning(
                "[JETP-082.1/sdk] resolve(%s) 429 rate-limited",
                request.tool_id,
            )
        else:
            logger.error(
                "[JETP-082.1/sdk] resolve(%s) status=%d — bundle=None",
                request.tool_id,
                status,
            )
        return None

    try:
        payload = response.json()
    except Exception:
        logger.error(
            "[JETP-082.1/sdk] resolve(%s) 200 with non-JSON body; rejecting bundle",
            request.tool_id,
        )
        return None

    if not isinstance(payload, dict):
        logger.error(
            "[JETP-082.1/sdk] resolve(%s) 200 with non-object body; rejecting bundle",
            request.tool_id,
        )
        return None

    manifest_dict = coerce_manifest(manifest) or {}
    return apply_placement(
        asset_id=request.tool_id,
        manifest=manifest_dict,
        resolved=payload,
    )


# ---------- Legacy GET shim ----------


async def dispatch_resolve_credential_legacy(
    http: httpx.AsyncClient,
    *,
    base_url: Optional[str] = None,  # noqa: ARG001 — kept for legacy signature compat
    api_key: Optional[str],
    asset_id: str,
    binding_key: str,
    environment: str,
    principal_ctx: Optional[dict[str, Any]] = None,  # noqa: ARG001 — kept for legacy callers
    manifest: Any = None,
) -> Optional[dict[str, Any]]:
    """v0.4.x compatibility shim — GET ``/internal/credentials/resolve``.

    Emits a ``DeprecationWarning``. New code MUST use
    :func:`dispatch_resolve_credential` with a :class:`ResolveRequest`.

    Server v2 (JETP-082.1) still accepts the legacy GET route for safety;
    however binding-axis introspection is *not* performed — the server
    matches ``binding_key`` exactly. If you need ``caller_org_source``
    in your audit trail, migrate to v0.5.0 + POST v2.
    """
    warnings.warn(
        "dispatch_resolve_credential_legacy is deprecated; migrate to "
        "dispatch_resolve_credential(request=ResolveRequest(...), bearer_token=...)",
        DeprecationWarning,
        stacklevel=2,
    )

    params = {"binding_key": binding_key, "environment": environment}
    headers: dict[str, str] = {
        "X-Service-Audience": INTERNAL_AUDIENCE,
        "Accept": "application/json",
    }
    if api_key:
        headers["X-API-Key"] = api_key
        headers["Authorization"] = f"Bearer {api_key}"  # legacy auth surface

    path = INTERNAL_RESOLVE_PATH_TEMPLATE.format(tool_id=asset_id)

    try:
        response = await http.get(path, params=params, headers=headers)
    except (httpx.TimeoutException, httpx.TransportError) as exc:
        logger.warning(
            "[JETP-082.1/sdk-legacy] resolve(%s) transport error: %s",
            asset_id,
            type(exc).__name__,
        )
        return None
    except Exception:
        logger.exception("[JETP-082.1/sdk-legacy] resolve(%s) unexpected error", asset_id)
        return None

    if response.status_code != 200:
        return None
    try:
        payload = response.json()
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None

    manifest_dict = coerce_manifest(manifest) or {}
    return apply_placement(asset_id=asset_id, manifest=manifest_dict, resolved=payload)


# ---------- Internals ----------


def _idempotency_key(bearer_token: str, body: dict[str, Any]) -> str:
    """``hash(bearer_token + body + minute_bucket)`` — stable across SDK retries.

    Server uses this to de-duplicate audit log entries from retries (AC-SDK-005).
    Minute bucket guarantees that retries within the same minute share a key
    while different requests (even with the same body) get different keys.
    """
    h = hashlib.sha256()
    h.update(bearer_token.encode("utf-8"))
    h.update(b"\x00")
    for k in sorted(body.keys()):
        h.update(k.encode("utf-8"))
        h.update(b"=")
        h.update(str(body[k]).encode("utf-8"))
        h.update(b"\x00")
    minute_bucket = int(time.time() // 60)
    h.update(str(minute_bucket).encode("utf-8"))
    return h.hexdigest()


async def _sleep_backoff(attempt: int) -> None:
    """Exponential backoff with cap; async-only (anyio-friendly)."""
    import asyncio

    delay = min(_RETRY_BASE_BACKOFF_S * (2**attempt), 1.0)
    await asyncio.sleep(delay)
