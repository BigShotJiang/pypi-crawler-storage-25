"""Unit tests for ``jetforge_sdk.data_asset_client.DataAssetClient``.

We use ``httpx.MockTransport`` so the test runs entirely offline; every
behavior the client has against the JetForge dispatch protocol is
exercised against a recorded fixture rather than a live socket.

Covers:
  * Cold sync — fetches all pages and populates the cache.
  * Warm sync — sends If-None-Match → 304 → cache untouched.
  * Incremental sync — uses ``since_revision`` cursor on follow-up calls.
  * Rate-limit (429) → ``rate_limited=True`` flag, no exception.
  * 503 upstream-unavailable → ``upstream_unavailable=True`` flag.
  * Pagination pages > 1 round-trips to the server.
  * ``force_full=True`` resets the since cursor.
"""
from __future__ import annotations

import json
from typing import Any, Callable, Optional

import httpx
import pytest

from jetforge_sdk.data_asset_client import (
    DataAssetClient,
    DataAssetMeta,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_asset(
    *,
    asset_id: str = "da-x-1.0.0-aaaa",
    org_id: str = "org-1",
    revision: int = 1700000000_000_000,
    kind: str = "DATABASE",
) -> dict[str, Any]:
    return {
        "id": asset_id,
        "name": asset_id.split("-")[1],
        "version": "1.0.0",
        "revision": revision,
        "resource_type": "data_asset",
        "kind": kind,
        "org_id": org_id,
        "provider": {"kind": "user", "key": "u-1"},
        "visibility": "ORG_SHARED",
        "usability": "ORG_MEMBERS",
        "billable": False,
        "updated_at": "2026-05-09T08:30:14Z",
    }


def _manifest_payload(
    *,
    digest: str,
    rev_hw: int,
    page: int = 1,
    pages: int = 1,
    total: int = 1,
    page_size: int = 200,
    assets: Optional[list[dict[str, Any]]] = None,
    degraded: bool = False,
    org_id: str = "org-1",
) -> dict[str, Any]:
    return {
        "protocol_version": "v1",
        "org_id": org_id,
        "digest": digest,
        "revision_high_water": rev_hw,
        "page": page,
        "page_size": page_size,
        "pages": pages,
        "total": total,
        "assets": assets or [_make_asset(revision=rev_hw)],
        "degraded": degraded,
        "served_at": "2026-05-09T22:48:00Z",
    }


class _RecordingTransport(httpx.MockTransport):
    """Transport that records every request + dispatches via a callable."""

    def __init__(self, handler: Callable[[httpx.Request], httpx.Response]):
        self.calls: list[httpx.Request] = []

        def _wrapped(request: httpx.Request) -> httpx.Response:
            self.calls.append(request)
            return handler(request)

        super().__init__(_wrapped)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def make_client() -> Callable[[httpx.MockTransport], DataAssetClient]:
    """Return a factory that wires a DataAssetClient onto a mock transport."""

    def _factory(transport: httpx.MockTransport) -> DataAssetClient:
        client = DataAssetClient(
            base_url="http://forge.test",
            api_key="jf_test",
            page_size=2,
            max_pages_per_sync=10,
        )
        # Replace the to-be-created http client with one bound to the
        # mock transport; client.initialize() then no-ops.
        client._http = httpx.AsyncClient(  # type: ignore[attr-defined]
            base_url="http://forge.test",
            transport=transport,
            headers={"Authorization": "Bearer jf_test"},
        )
        return client

    return _factory


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


async def test_cold_sync_fetches_one_page(make_client: Any) -> None:
    digest = "d" * 64
    rev = 1700000000_000_001

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=_manifest_payload(digest=digest, rev_hw=rev))

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        result = await client.sync()

    assert result.not_modified is False
    assert result.fetched == 1
    assert result.digest == digest
    assert result.revision_high_water == rev
    assert client.last_digest == digest
    assert isinstance(result.items[0], DataAssetMeta)
    assert client.snapshot()[0].id == "da-x-1.0.0-aaaa"
    assert len(transport.calls) == 1


async def test_warm_sync_returns_304_without_body(make_client: Any) -> None:
    digest = "d" * 64
    rev = 1700000000_000_002

    def handler(request: httpx.Request) -> httpx.Response:
        # First request (since=0) → 200 cold; subsequent (since>=rev) → 304.
        since = int(request.url.params.get("since_revision", "0"))
        if since == 0:
            return httpx.Response(
                200, json=_manifest_payload(digest=digest, rev_hw=rev)
            )
        return httpx.Response(304)

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        first = await client.sync()
        second = await client.sync()

    assert first.not_modified is False
    assert second.not_modified is True
    assert second.digest == digest
    assert client.snapshot()[0].id == "da-x-1.0.0-aaaa"


async def test_pagination_walks_all_pages(make_client: Any) -> None:
    digest = "d" * 64
    rev = 1700000000_000_003

    def handler(request: httpx.Request) -> httpx.Response:
        page = int(request.url.params.get("page", "1"))
        assets = [
            _make_asset(asset_id=f"da-x{idx}-1.0.0-aaaa", revision=rev - idx)
            for idx in range((page - 1) * 2, page * 2)
        ]
        body = _manifest_payload(
            digest=digest,
            rev_hw=rev,
            page=page,
            pages=3,
            total=6,
            page_size=2,
            assets=assets,
        )
        return httpx.Response(200, json=body)

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        result = await client.sync()

    assert result.pages == 3
    assert result.fetched == 6
    assert len(client.snapshot()) == 6
    assert len(transport.calls) == 3


async def test_429_marks_rate_limited(make_client: Any) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            429,
            headers={"Retry-After": "2"},
            json={
                "error": "rate_limited",
                "scope": "per_key",
                "retry_after_seconds": 2,
            },
        )

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        result = await client.sync()

    assert result.rate_limited is True
    assert result.fetched == 0


async def test_503_marks_upstream_unavailable(make_client: Any) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, json={"error": "upstream_unavailable"})

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        result = await client.sync()

    assert result.upstream_unavailable is True
    assert result.fetched == 0


async def test_force_full_resets_since(make_client: Any) -> None:
    digest1 = "1" * 64
    rev_seq = iter([1700000000_000_010, 1700000000_000_020])

    def handler(request: httpx.Request) -> httpx.Response:
        rev = next(rev_seq, 1700000000_000_999)
        body = _manifest_payload(digest=digest1, rev_hw=rev)
        return httpx.Response(200, json=body)

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        await client.sync()
        await client.sync(force_full=True)

    # Both calls run with since=0 (cold + forced); ``force_full`` also
    # drops the digest hint so the response body is always returned.
    assert transport.calls[0].url.params.get("since_revision") == "0"
    assert "If-None-Match" not in transport.calls[0].headers
    assert transport.calls[1].url.params.get("since_revision") == "0"
    assert "If-None-Match" not in transport.calls[1].headers


async def test_incremental_sync_uses_cursor(make_client: Any) -> None:
    digest = "d" * 64
    rev1 = 1700000000_000_100
    rev2 = 1700000000_000_200

    def handler(request: httpx.Request) -> httpx.Response:
        since = int(request.url.params.get("since_revision", "0"))
        if since == 0:
            body = _manifest_payload(digest=digest, rev_hw=rev1)
        else:
            body = _manifest_payload(
                digest=digest, rev_hw=rev2, total=1, pages=1
            )
        return httpx.Response(200, json=body)

    transport = _RecordingTransport(handler)
    async with make_client(transport) as client:
        first = await client.sync()
        assert first.revision_high_water == rev1
        second = await client.sync()  # uses last_revision as cursor
        assert second.revision_high_water == rev2

    assert transport.calls[1].url.params.get("since_revision") == str(rev1)


def test_data_asset_meta_from_dict_handles_optionals() -> None:
    raw = _make_asset()
    meta = DataAssetMeta.from_dict(raw)
    assert meta.id == "da-x-1.0.0-aaaa"
    assert meta.tags == ()
    assert meta.pricing is None
    assert meta.connection is None


def test_data_asset_meta_round_trip_with_pricing() -> None:
    raw = _make_asset()
    raw["pricing"] = {
        "base_price": 5,
        "currency": "credits",
        "pricing_model": "per_use",
        "max_concurrent": 8,
    }
    raw["connection"] = {"driver": "postgresql", "host": "db"}
    raw["tags"] = ["sales", "orders"]
    meta = DataAssetMeta.from_dict(raw)
    assert meta.pricing is not None
    assert meta.pricing.base_price == 5
    assert meta.pricing.max_concurrent == 8
    assert meta.tags == ("sales", "orders")
    assert meta.connection == {"driver": "postgresql", "host": "db"}
