"""Unit tests for ``apply_placement`` with ``kind=db-password`` secrets.

JETP-082 v1.4 — DATABASE assets carry the full DSN tuple in ``secret`` and
the manifest's placement template is meaningless for ``db-password``. The
SDK MUST project the secret into ``dsn_overrides`` regardless of the
``placement.value_template`` value (often the default ``Bearer {token}``
from the credential factory), so downstream ``DatabaseHandler`` always
gets a usable bundle.
"""
from __future__ import annotations

from jetforge_sdk._credential_assembly import apply_placement


_MANIFEST_DEFAULT_PLACEMENT = {
    "kind": "db-password",
    "binding": ["tool", "env", "org"],
    "version": "1",
    "placement": {
        # Deliberately the "wrong" template — that's the bug we close.
        # Even though the placement says Authorization/Bearer/{token},
        # the SDK must NOT try to render that template against a DSN
        # secret; it must dump the DSN tuple into ``dsn_overrides``.
        "name": "Authorization",
        "location": "driver-kwargs",
        "sensitive": True,
        "value_template": "Bearer {token}",
    },
    "provenance": "org",
}


def _resolved(secret: dict[str, object]) -> dict[str, object]:
    return {
        "credential_id": 99,
        "kind": "db-password",
        "secret": secret,
        "expires_at": None,
        "placement_hint": None,
    }


def test_db_password_projects_dsn_overrides_ignoring_placement_template() -> None:
    bundle = apply_placement(
        asset_id="da-pcb-cost-db-1.0.0-c81e",
        manifest=_MANIFEST_DEFAULT_PLACEMENT,
        resolved=_resolved(
            {"username": "postgres", "password": "jiepei123456"}
        ),
    )
    assert bundle is not None
    assert bundle["credential_id"] == 99
    assert bundle["kind"] == "db-password"
    assert bundle["dsn_overrides"] == {
        "user": "postgres",
        "password": "jiepei123456",
    }
    assert "db-password:dsn_overrides" in bundle["notes"]
    # Header/query/body slots must stay empty — the secret is for the driver.
    assert bundle["headers"] == {}
    assert bundle["query"] == {}
    assert bundle["cookies"] == {}
    assert bundle["body_patches"] == {}


def test_db_password_carries_optional_dsn_fields() -> None:
    bundle = apply_placement(
        asset_id="da-x",
        manifest=_MANIFEST_DEFAULT_PLACEMENT,
        resolved=_resolved(
            {
                "username": "ro_user",
                "password": "pw",
                "host": "10.0.0.1",
                "port": 5432,
                "database": "costdb",
                "ssl_mode": "require",
                "schema": "public",
                "params": {"application_name": "jetagents"},
            }
        ),
    )
    assert bundle is not None
    assert bundle["dsn_overrides"] == {
        "user": "ro_user",
        "password": "pw",
        "host": "10.0.0.1",
        "port": 5432,
        "database": "costdb",
        "ssl_mode": "require",
        "schema": "public",
        "params": {"application_name": "jetagents"},
    }


def test_db_password_accepts_user_alias() -> None:
    bundle = apply_placement(
        asset_id="da-x",
        manifest=_MANIFEST_DEFAULT_PLACEMENT,
        resolved=_resolved({"user": "u", "password": "p"}),
    )
    assert bundle is not None
    assert bundle["dsn_overrides"]["user"] == "u"
    assert bundle["dsn_overrides"]["password"] == "p"


def test_db_password_rejects_when_username_missing() -> None:
    bundle = apply_placement(
        asset_id="da-x",
        manifest=_MANIFEST_DEFAULT_PLACEMENT,
        resolved=_resolved({"password": "p"}),  # no username
    )
    assert bundle is None


def test_db_password_rejects_when_password_missing() -> None:
    bundle = apply_placement(
        asset_id="da-x",
        manifest=_MANIFEST_DEFAULT_PLACEMENT,
        resolved=_resolved({"username": "u"}),  # no password
    )
    assert bundle is None


def test_db_password_with_explicit_database_dsn_placement_still_works() -> None:
    """Backwards compat: assets that DO specify ``database_dsn`` placement
    must still flow through ``_apply_database_dsn`` (not the new branch).
    """
    manifest = {
        "kind": "db-password",
        "placement": {
            "name": "password",
            "location": "database_dsn",
            "value_template": "{password}",
        },
    }
    bundle = apply_placement(
        asset_id="da-x",
        manifest=manifest,
        resolved=_resolved({"username": "u", "password": "sekret"}),
    )
    assert bundle is not None
    # The explicit ``database_dsn:password`` branch wins; the new db-password
    # default branch only fires when the placement does NOT match the
    # database_dsn shape.
    assert bundle["dsn_overrides"] == {"password": "sekret"}
    assert "dsn_override:password" in bundle["notes"]
