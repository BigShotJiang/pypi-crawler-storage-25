"""
Unit tests for jetforge_sdk.admin.ModelLakeAdminClient.

These tests use httpx.MockTransport so no live model-lake server is required.
They cover the wire contract documented in
model-lake/internal/features/api/admin/specs/dto.go.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from jetforge_sdk.admin import (
    AdminError,
    DryRunSummary,
    ModelLakeAdminClient,
    SpecLifecycleResponse,
    SpecRow,
)


# ── helpers ──────────────────────────────────────────────────────────────────


def _success(data: Any) -> httpx.Response:
    return httpx.Response(200, json={"code": 0, "message": "ok", "data": data})


def _error(status: int, code: int, message: str) -> httpx.Response:
    return httpx.Response(
        status,
        json={"code": code, "message": message, "data": None},
    )


def _make_client(handler) -> ModelLakeAdminClient:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(transport=transport)
    return ModelLakeAdminClient(
        base_url="http://test.invalid",
        token="test-token",
        auth_instance_id="auth-1",
        client=http,
    )


# ── upload / dryrun ─────────────────────────────────────────────────────────


def test_upload_yaml_bytes_happy_persists():
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["headers"] = dict(request.headers)
        captured["body"] = json.loads(request.content.decode())
        return _success(
            {
                "spec_id": "anthropic-claude",
                "version": "1.2.0",
                "vendor": "anthropic",
                "sha256_hex": "ab" * 32,
                "persisted": True,
                "dry_run": {
                    "total": 3,
                    "passed": 3,
                    "skipped": 0,
                    "duration_ms": 12,
                    "all_passed": True,
                    "issues": [],
                },
            }
        )

    cli = _make_client(handler)
    resp = cli.upload_yaml_bytes(
        b"openapi: 3.1.0\n",
        dry_run=False,
        note="ship",
        idempotency_key="key-1",
    )
    assert isinstance(resp, SpecLifecycleResponse)
    assert resp.spec_id == "anthropic-claude"
    assert resp.version == "1.2.0"
    assert resp.persisted is True
    assert resp.dry_run.all_passed is True

    assert captured["url"].endswith("/admin/v1/specs/upload")
    assert captured["headers"]["authorization"] == "Bearer test-token"
    assert captured["headers"]["x-auth-instance-id"] == "auth-1"
    assert captured["headers"]["idempotency-key"] == "key-1"
    body = captured["body"]
    assert body["dry_run"] is False
    assert body["note"] == "ship"
    assert body["yaml"] == list(b"openapi: 3.1.0\n")


def test_dryrun_yaml_bytes_does_not_persist():
    seen: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["body"] = json.loads(request.content.decode())
        return _success(
            {
                "spec_id": "anthropic-claude",
                "version": "1.2.0",
                "sha256_hex": "ab" * 32,
                "persisted": False,
                "dry_run": {
                    "total": 5,
                    "passed": 4,
                    "skipped": 0,
                    "duration_ms": 30,
                    "all_passed": False,
                    "issues": [
                        {
                            "severity": "fixture",
                            "name": "tools_basic",
                            "kind": "request_round_trip",
                            "reason": "field mismatch: stop_sequences",
                        }
                    ],
                },
            }
        )

    cli = _make_client(handler)
    resp = cli.dryrun_yaml_bytes(b"openapi: 3.1.0\n")
    assert resp.persisted is False
    assert resp.dry_run.all_passed is False
    assert len(resp.dry_run.issues) == 1
    assert resp.dry_run.issues[0].name == "tools_basic"

    assert seen["url"].endswith("/admin/v1/specs/dryrun")
    assert seen["body"]["dry_run"] is True


def test_upload_admin_error_envelope():
    def handler(request: httpx.Request) -> httpx.Response:
        return _error(422, 4106, "spec validation failed: missing servers")

    cli = _make_client(handler)
    with pytest.raises(AdminError) as ei:
        cli.upload_yaml_bytes(b"openapi: 3.1.0\n", dry_run=True)
    assert ei.value.status_code == 422
    assert ei.value.code == 4106
    assert "spec validation failed" in ei.value.message


# ── lifecycle ───────────────────────────────────────────────────────────────


def test_activate_sends_correct_payload():
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode())
        return _success({"activated": True, "version": "1.2.0"})

    cli = _make_client(handler)
    out = cli.activate("anthropic-claude", "1.2.0", reason="ga", idempotency_key="k1")
    assert out["activated"] is True
    assert captured["url"].endswith("/admin/v1/specs/anthropic-claude/activate")
    assert captured["body"] == {"version": "1.2.0", "reason": "ga"}


def test_rollback_out_of_window_propagates_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return _error(422, 4111, "spec rollback target deprecated more than 30 days")

    cli = _make_client(handler)
    with pytest.raises(AdminError) as ei:
        cli.rollback(
            "anthropic-claude",
            "1.0.0",
            reason="please please",
        )
    assert ei.value.status_code == 422
    assert "more than 30 days" in ei.value.message


def test_rollback_happy():
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode())
        return _success({"rolled_back": True, "to_version": "1.1.0"})

    cli = _make_client(handler)
    out = cli.rollback(
        "anthropic-claude",
        "1.1.0",
        reason="regression in tool calls",
    )
    assert out["rolled_back"] is True
    assert captured["body"]["to_version"] == "1.1.0"
    assert "regression" in captured["body"]["reason"]


# ── query ────────────────────────────────────────────────────────────────────


def test_list_specs_returns_typed_rows():
    def handler(request: httpx.Request) -> httpx.Response:
        params = dict(request.url.params)
        assert params.get("status") == "active"
        return _success(
            {
                "total": 2,
                "items": [
                    {
                        "spec_id": "openai-chat",
                        "version": "1.0.0",
                        "status": "active",
                        "canary_percent": 0,
                        "vendor": "openai",
                        "realm_id": "r-a",
                    },
                    {
                        "spec_id": "anthropic-claude",
                        "version": "1.2.0",
                        "status": "active",
                        "canary_percent": 25,
                        "vendor": "anthropic",
                        "realm_id": "r-a",
                    },
                ],
            }
        )

    cli = _make_client(handler)
    rows = cli.list_specs(status="active")
    assert len(rows) == 2
    assert all(isinstance(r, SpecRow) for r in rows)
    assert rows[1].canary_percent == 25
    assert rows[1].vendor == "anthropic"


def test_list_versions_empty_ok():
    def handler(request: httpx.Request) -> httpx.Response:
        return _success({"total": 0, "items": []})

    cli = _make_client(handler)
    rows = cli.list_versions("never-uploaded")
    assert rows == []


# ── dataclass helpers ───────────────────────────────────────────────────────


def test_dryrun_summary_handles_none():
    s = DryRunSummary.from_dict(None)
    assert s.total == 0
    assert s.all_passed is True
    assert s.issues == []
