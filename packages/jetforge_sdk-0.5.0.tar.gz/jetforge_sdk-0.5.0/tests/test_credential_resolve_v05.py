"""JETP-082.1 v0.3 path B — SDK v0.5.0 dispatch_resolve_credential tests.

Covers acceptance criteria AC-SDK-001 through AC-SDK-006:

* AC-SDK-001: POST body is exactly ``{"tool_id", "environment"}``;
  Authorization header carries OBO bearer; no other identity fields.
* AC-SDK-002: ResolveRequest rejects v0.4.x kwargs (TypeError).
* AC-SDK-003: happy path returns assembled bundle.
* AC-SDK-005: retries on transport errors with Idempotency-Key stable
  per minute bucket.
* AC-SDK-006: empty bearer_token short-circuits before HTTP.

Tests run entirely offline via ``httpx.MockTransport``.
"""
from __future__ import annotations

import warnings
from typing import Any

import httpx
import pytest

from jetforge_sdk import ResolveRequest, dispatch_resolve_credential_legacy
from jetforge_sdk._credential_resolve import (
    INTERNAL_RESOLVE_PATH_TEMPLATE,
    dispatch_resolve_credential,
)


# ---------- Fixtures ----------


def _server_resolved(
    *,
    credential_id: int = 123,
    kind: str = "static_api_key",
    secret: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "credential_id": credential_id,
        "kind": kind,
        "secret": secret if secret is not None else {"token": "sk-x"},
        "expires_at": None,
        "placement_hint": None,
    }


def _manifest_header_apikey() -> dict[str, Any]:
    return {
        "kind": "static_api_key",
        "placement": {
            "location": "header",
            "name": "X-Api-Key",
            "value_template": "{token}",
        },
    }


def _http_recording(handler):
    """Return an ``httpx.AsyncClient`` whose transport routes through ``handler``.

    ``handler`` is a callable ``(request) -> httpx.Response``.
    """
    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(base_url="https://jetforge.test", transport=transport)


# ---------- AC-SDK-001 ----------


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-001")
async def test_post_body_only_contains_tool_id_and_environment() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["body"] = request.content
        captured["headers"] = dict(request.headers)
        return httpx.Response(200, json=_server_resolved())

    async with _http_recording(handler) as http:
        await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo-jwt-abc",
            manifest=_manifest_header_apikey(),
            api_key="site-key",
        )

    assert captured["method"] == "POST"
    assert captured["path"] == INTERNAL_RESOLVE_PATH_TEMPLATE.format(tool_id="t1")

    import json as _json

    body = _json.loads(captured["body"])
    assert body == {"tool_id": "t1", "environment": "default"}
    assert "principal" not in body
    assert "binding_key" not in body
    assert "axes" not in body
    assert "org_id" not in body

    assert captured["headers"]["authorization"] == "Bearer obo-jwt-abc"
    assert captured["headers"]["x-api-key"] == "site-key"
    assert captured["headers"]["x-service-audience"] == "jetforge.internal"
    assert "idempotency-key" in captured["headers"]


# ---------- AC-SDK-002 ----------


@pytest.mark.ac("AC-SDK-002")
def test_resolve_request_rejects_v04_kwargs() -> None:
    """``slots=True`` dataclass forbids unknown fields → TypeError."""
    with pytest.raises(TypeError):
        ResolveRequest(tool_id="t1", environment="default", binding_key="legacy")  # type: ignore[call-arg]


@pytest.mark.ac("AC-SDK-002")
def test_resolve_request_rejects_principal_kwargs() -> None:
    with pytest.raises(TypeError):
        ResolveRequest(  # type: ignore[call-arg]
            tool_id="t1",
            environment="default",
            principal_kind="user",
            principal_key="u1",
        )


@pytest.mark.ac("AC-SDK-002")
def test_resolve_request_validates_fields() -> None:
    with pytest.raises(ValueError):
        ResolveRequest(tool_id="", environment="default")
    with pytest.raises(ValueError):
        ResolveRequest(tool_id="t1", environment="")


@pytest.mark.ac("AC-SDK-002")
def test_resolve_request_is_frozen() -> None:
    r = ResolveRequest(tool_id="t1", environment="default")
    with pytest.raises((AttributeError, TypeError)):
        r.tool_id = "t2"  # type: ignore[misc]


# ---------- AC-SDK-003 ----------


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-003")
async def test_happy_path_returns_assembled_bundle() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=_server_resolved(secret={"token": "sk-real"}))

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
            manifest=_manifest_header_apikey(),
        )

    assert bundle is not None
    assert bundle["credential_id"] == 123
    assert bundle["kind"] == "static_api_key"
    assert bundle["headers"]["X-Api-Key"] == "sk-real"


# ---------- AC-SDK-005 ----------


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-005")
async def test_retries_on_transport_error_then_succeeds() -> None:
    call_count = {"n": 0}

    def handler(_: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        if call_count["n"] < 2:
            raise httpx.ConnectError("simulated network glitch")
        return httpx.Response(200, json=_server_resolved())

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )

    assert bundle is not None
    assert call_count["n"] == 2


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-005")
async def test_retries_exhausted_returns_none() -> None:
    call_count = {"n": 0}

    def handler(_: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        raise httpx.ConnectError("permanent down")

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )

    assert bundle is None
    assert call_count["n"] == 3  # _RETRY_MAX


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-005")
async def test_idempotency_key_stable_within_minute() -> None:
    """同一分钟内同 (bearer, body) 的 Idempotency-Key 应稳定."""
    keys: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        keys.append(request.headers["idempotency-key"])
        return httpx.Response(200, json=_server_resolved())

    async with _http_recording(handler) as http:
        for _ in range(3):
            await dispatch_resolve_credential(
                http,
                request=ResolveRequest(tool_id="t1", environment="default"),
                bearer_token="obo",
            )

    assert len(set(keys)) == 1  # 同分钟同 bearer / body → 同 key


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-005")
async def test_idempotency_key_differs_per_bearer() -> None:
    """不同 bearer 应得到不同 Idempotency-Key（避免不同 caller 串审计）."""
    keys: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        keys.append(request.headers["idempotency-key"])
        return httpx.Response(200, json=_server_resolved())

    async with _http_recording(handler) as http:
        await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo-a",
        )
        await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo-b",
        )

    assert len(set(keys)) == 2


# ---------- AC-SDK-006 ----------


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-006")
async def test_empty_bearer_token_raises_before_http() -> None:
    call_count = {"n": 0}

    def handler(_: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        return httpx.Response(200, json=_server_resolved())

    async with _http_recording(handler) as http:
        with pytest.raises(ValueError, match="bearer_token is required"):
            await dispatch_resolve_credential(
                http,
                request=ResolveRequest(tool_id="t1", environment="default"),
                bearer_token="",
            )

    assert call_count["n"] == 0  # never reached server


# ---------- HTTP error paths ----------


@pytest.mark.asyncio
async def test_http_404_returns_none() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "not found"})

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )
    assert bundle is None


@pytest.mark.asyncio
async def test_http_401_returns_none() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "bearer rejected"})

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )
    assert bundle is None


@pytest.mark.asyncio
async def test_http_405_returns_none() -> None:
    """旧 server 没 POST 路由 → SDK 不 fallback (v0.3 极简)."""

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(405, json={"detail": "method not allowed"})

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )
    assert bundle is None


@pytest.mark.asyncio
async def test_non_json_body_returns_none() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"not json", headers={"content-type": "text/plain"})

    async with _http_recording(handler) as http:
        bundle = await dispatch_resolve_credential(
            http,
            request=ResolveRequest(tool_id="t1", environment="default"),
            bearer_token="obo",
        )
    assert bundle is None


# ---------- Legacy shim ----------


@pytest.mark.asyncio
@pytest.mark.ac("AC-SDK-004")
async def test_legacy_shim_uses_get_and_warns() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["path"] = request.url.path
        captured["query"] = dict(request.url.params)
        return httpx.Response(200, json=_server_resolved())

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        async with _http_recording(handler) as http:
            bundle = await dispatch_resolve_credential_legacy(
                http,
                api_key="k",
                asset_id="t1",
                binding_key="tool=t1|env=default",
                environment="default",
                manifest=_manifest_header_apikey(),
            )

    assert bundle is not None
    assert captured["method"] == "GET"
    assert captured["query"]["binding_key"] == "tool=t1|env=default"
    assert any(issubclass(item.category, DeprecationWarning) for item in w)


# ---------- _credential_assembly: resolve_binding deleted ----------


def test_resolve_binding_function_removed() -> None:
    """v0.5.0 hard break: resolve_binding is gone from public API."""
    from jetforge_sdk import _credential_assembly

    assert not hasattr(_credential_assembly, "resolve_binding")
    assert "resolve_binding" not in _credential_assembly.__all__
