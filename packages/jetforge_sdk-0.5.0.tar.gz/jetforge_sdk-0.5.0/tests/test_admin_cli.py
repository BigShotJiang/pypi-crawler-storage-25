"""
Unit tests for jetforge_sdk.admin.cli.

These cover AC-ADM-009-SDK (RFC-006 §13): a single canonical end-to-end
``jetforge spec upload anthropic.yaml --dry-run`` invocation must exit 0
and print spec_id + version + status=draft.

We mock ModelLakeAdminClient via dependency injection (monkeypatching
_make_client) so the tests stay hermetic.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from jetforge_sdk.admin import cli as admin_cli
from jetforge_sdk.admin.model_lake_specs import ModelLakeAdminClient


# ── helper ──────────────────────────────────────────────────────────────────


def _client_with_handler(handler) -> ModelLakeAdminClient:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(transport=transport)
    return ModelLakeAdminClient(
        base_url="http://test.invalid",
        token="t",
        client=http,
    )


def _patch_client(monkeypatch: pytest.MonkeyPatch, handler) -> None:
    def fake_make_client(args):
        return _client_with_handler(handler)

    monkeypatch.setattr(admin_cli, "_make_client", fake_make_client)


# ── canonical AC-ADM-009-SDK ────────────────────────────────────────────────


def test_spec_upload_dry_run_exit0_prints_draft(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys,
):
    yaml_path = tmp_path / "anthropic.yaml"
    yaml_path.write_text("openapi: 3.1.0\ninfo: {title: a, version: 1.0.0}\n")

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content.decode())
        assert body["dry_run"] is True
        return httpx.Response(
            200,
            json={
                "code": 0,
                "message": "ok",
                "data": {
                    "spec_id": "anthropic-claude",
                    "version": "1.2.0",
                    "vendor": "anthropic",
                    "sha256_hex": "ab" * 32,
                    "persisted": False,
                    "dry_run": {
                        "total": 0,
                        "passed": 0,
                        "skipped": 0,
                        "duration_ms": 0,
                        "all_passed": True,
                        "issues": [],
                    },
                },
            },
        )

    _patch_client(monkeypatch, handler)
    rc = admin_cli.main(
        ["spec", "upload", str(yaml_path), "--dry-run"]
    )
    assert rc == 0
    out = capsys.readouterr().out
    assert "spec_id : anthropic-claude" in out
    assert "version : 1.2.0" in out
    assert "status  : draft" in out


# ── error path ──────────────────────────────────────────────────────────────


def test_spec_upload_admin_error_exit3(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys,
):
    yaml_path = tmp_path / "bad.yaml"
    yaml_path.write_text("openapi: 3.1.0\n")

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json={"code": 4106, "message": "spec validation failed", "data": None},
        )

    _patch_client(monkeypatch, handler)
    rc = admin_cli.main(["spec", "upload", str(yaml_path), "--dry-run"])
    assert rc == 3
    err = capsys.readouterr().err
    assert "admin error" in err
    assert "spec validation failed" in err


def test_spec_upload_missing_file_exit4(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
):
    with pytest.raises(SystemExit) as ei:
        admin_cli.main(
            ["spec", "upload", str(tmp_path / "nope.yaml"), "--dry-run"]
        )
    assert ei.value.code == 4


# ── activate / rollback CLI sanity ──────────────────────────────────────────


def test_spec_activate_emits_payload(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys,
):
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(
            200,
            json={"code": 0, "message": "ok", "data": {"activated": True}},
        )

    _patch_client(monkeypatch, handler)
    rc = admin_cli.main(
        [
            "spec",
            "activate",
            "anthropic-claude",
            "--version",
            "1.2.0",
            "--reason",
            "ga",
        ]
    )
    assert rc == 0
    assert captured["url"].endswith("/admin/v1/specs/anthropic-claude/activate")
    assert captured["body"] == {"version": "1.2.0", "reason": "ga"}


def test_spec_rollback_requires_reason(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
    capsys,
):
    # argparse rejects missing --reason → exit 2
    with pytest.raises(SystemExit) as ei:
        admin_cli.main(
            [
                "spec",
                "rollback",
                "anthropic-claude",
                "--to-version",
                "1.1.0",
            ]
        )
    assert ei.value.code == 2


def test_spec_list_renders_rows(
    monkeypatch: pytest.MonkeyPatch,
    capsys,
):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "code": 0,
                "message": "ok",
                "data": {
                    "total": 1,
                    "items": [
                        {
                            "spec_id": "openai-chat",
                            "version": "1.0.0",
                            "status": "active",
                            "canary_percent": 0,
                            "vendor": "openai",
                            "realm_id": "r-a",
                        }
                    ],
                },
            },
        )

    _patch_client(monkeypatch, handler)
    rc = admin_cli.main(["spec", "list", "--status", "active"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "openai-chat" in out
    assert "active" in out
