from pathlib import Path
from driftstone import Driftstone

client = Driftstone(api_key="dk-661f7eb4-ee24-4f73-96c4-2dc0d283a235")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

app = client.app.init("typedef-app", type="openclaw", version_path=config_folder)

channel = app.channel.init("my-api", type="api")

# stream = channel.run(
#     user_id="stephen@pickaxe.co", 
#     input="hello world"
# )

# for event in stream:
#     print(event)
