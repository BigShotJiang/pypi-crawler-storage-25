## Driftstone - Python

Python SDK for the Driftstone API.

### Install

```bash
pip install driftstone
```

### Quick Start

```python
from driftstone import Driftstone

client = Driftstone(api_key="your-api-key")

app = client.app.init("typedef-app", 
    type="claude", 
    version_path=".openclaw"
)

channel = app.channel.init("my-api", 
    type="api"
)

stream = channel.run(
    session_id="my-custom-session-id",
    user_id="stephen@pickaxe.co",
    input="hello world"
)

for event in stream:
    if event.done:
        break

    print(event)

```

### Using A Context Manager

```python
from driftstone import Driftstone

with Driftstone(api_key="your-api-key") as client:
    app = client.app.init("typedef-app", 
        type="claude", 
        version_path=".openclaw"
    )

    channel = app.channel.init("my-api", 
        type="api"
    )

    stream = channel.run(
        session_id="my-custom-session-id",
        user_id="stephen@pickaxe.co",
        input="hello world"
    )

    for event in stream:
        if event.done:
            break

        print(event)
    
```