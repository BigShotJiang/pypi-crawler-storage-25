class DriftstoneError(Exception):
    """Base exception for the Driftstone SDK."""


class DriftstoneHTTPError(DriftstoneError):
    """Raised when the underlying HTTP request fails."""


class DriftstoneResponseError(DriftstoneError):
    """Raised when an API response cannot be parsed as expected."""


class DriftstoneAPIError(DriftstoneError):
    """Raised when the Driftstone API returns an error."""
