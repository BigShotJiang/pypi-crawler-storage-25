from __future__ import annotations

from typing import Optional

from ..models.session import DriftstoneSessionModel, SessionType
from ..models.channel import ChannelType
from ..exceptions import DriftstoneError
from ._base import AppBase

class DriftstoneSession(AppBase):
    def create(
        self, 
        type: ChannelType,
    ) -> DriftstoneSessionModel:
        if type not in ("api", "imessage"):
            raise DriftstoneError("type must be either 'api' or 'imessage'")
        
        session_create_res = self._client._request("POST", "/session/create", {
            "appId": self._app_id,
            "type": type,
        })

        return DriftstoneSessionModel._from_api(
            session_create_res["data"],
        )

    def retrieve(self, session_id: str) -> DriftstoneSessionModel:
        try:
            if not session_id or not isinstance(session_id, str):
                raise Exception("session_id must be a non-empty string")
        
            session_get_res = self._client._request("GET", f"/session/{session_id}")
            
            return DriftstoneSessionModel._from_api(
                session_get_res["data"],
            )
        except DriftstoneError:
            return None
        except Exception as e:
            raise e

    def update(
        self,
        session_id: str,
        *,
        type: Optional[SessionType] = None,
        user_ids: Optional[list[str]] = None,
    ) -> DriftstoneSessionModel:
        if not session_id or not isinstance(session_id, str):
            raise DriftstoneError("session_id must be a non-empty string")

        if type is None and user_ids is None:
            raise DriftstoneError("At least one of 'type' or 'user_ids' must be provided")

        payload: dict[str, object] = {}

        if type is not None:
            if type not in ("single", "multiple"):
                raise DriftstoneError("type must be either 'single' or 'multiple'")
            payload["type"] = type

        if user_ids is not None:
            if not isinstance(user_ids, list) or not all(isinstance(uid, str) and uid.strip() for uid in user_ids):
                raise DriftstoneError("user_ids must be a list of non-empty strings")
            payload["userIds"] = user_ids

        session_update_res = self._client._request("PATCH", f"/session/{session_id}", payload)

        return DriftstoneSessionModel._from_api(
            session_update_res["data"],
        )

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 10,
    ) -> list[DriftstoneSessionModel]:
        if not isinstance(page, int) or page < 1:
            raise DriftstoneError("page must be a positive integer")
        if not isinstance(page_size, int) or page_size < 1:
            raise DriftstoneError("page_size must be a positive integer")

        session_list_res = self._client._request(
            "GET",
            "/session/list",
            {
                "appId": self._app_id,
                "page": page,
                "pageSize": page_size,
            },
        )

        data = session_list_res.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected 'data' to be a list in session list response")

        return [DriftstoneSessionModel._from_api(item) for item in data]

    def delete(self, session_id: str) -> bool:
        if not session_id or not isinstance(session_id, str):
            raise DriftstoneError("session_id must be a non-empty string")
        
        self._client._request("DELETE", f"/session/{session_id}")

        return True
