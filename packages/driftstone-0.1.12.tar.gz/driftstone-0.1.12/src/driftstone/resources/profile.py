from __future__ import annotations

from typing import Optional

from ..exceptions import DriftstoneError
from ..models.profile import DriftstoneProfileModel
from ._base import AppBase
from .state import DriftstoneState

class DriftstoneProfile(AppBase):
    def init(
        self, 
        identifier: str,
        *,
        state_path: str,
        access_group_id: Optional[str] = None,
        auto_update_state: bool = True,
    ) -> DriftstoneProfileModel:
        trimmed_identifier = identifier.strip()
        if not trimmed_identifier:
            raise DriftstoneError("identifier must be a non-empty string")

        if not state_path or not isinstance(state_path, str):
            raise DriftstoneError("state_path must be a non-empty string")
        
        if access_group_id is not None and (not isinstance(access_group_id, str) or not access_group_id.strip()):
            raise DriftstoneError("name must be a non-empty string")

        path_data = DriftstoneState._validate_state_path(state_path)
        _, sha256 = DriftstoneState._build_zip(path_data["path"])

        additional_payload = {}
        if access_group_id is not None:
            additional_payload["accessGroupId"] = access_group_id.strip()

        profile_create_res = self._client._request("POST", "/profile/create", {
            "appId": self._app_id,
            "identifier": trimmed_identifier,
            **additional_payload,
            "returnIfExist": True,
        })

        profile_id = profile_create_res["data"]["id"]
        state = DriftstoneState(self._client, self._app_id, profile_id)

        has_updated_zip = False
        if auto_update_state:
            latest_res = self._client._request("GET", "/state/latest", {
                "profileId": profile_id,
            })
            
            has_updated_zip = bool(latest_res.get("data") and latest_res["data"].get("sha256") != sha256)

        if not profile_create_res.get("exists", False) or \
            not profile_create_res["data"].get("headStateId") or \
            has_updated_zip:
            state.create(state_path)
        
        profile_res = self._client._request("GET", f"/profile/{profile_id}")

        return DriftstoneProfileModel._from_api(
            profile_res["data"], 
            state=state,
        )
    
    def retrieve(self, profile_id: str) -> DriftstoneProfileModel:
        try:
            if not profile_id or not isinstance(profile_id, str):
                raise Exception("profile_id must be a non-empty string")
        
            profile_res = self._client._request("GET", f"/profile/{profile_id}")
            
            state = DriftstoneState(self._client, self._app_id, profile_res["data"]["id"])

            return DriftstoneProfileModel._from_api(
                profile_res["data"], 
                state=state,
            )
        except DriftstoneError:
            return None
        except Exception as e:
            raise e
     
    def state(self, profile_id: str) -> DriftstoneState:
        trimmed_profile_id = profile_id.strip()
        if not profile_id:
            raise DriftstoneError("profile_id must be a non-empty string")
        return DriftstoneState(self._client, self._app_id, trimmed_profile_id)
