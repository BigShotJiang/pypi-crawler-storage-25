
from __future__ import annotations

from typing import Optional

from .._internal.constants import AVAILABLE_APP_TYPES
from ..models.app import (
    ApplicationType,
    DriftstoneAppModel, 
    AppInitLimit, 
    AppInitCredential,
)
from ..exceptions import DriftstoneError
from ._base import ResourceBase
from .version import DriftstoneVersion
from .access_group import DriftstoneAccessGroup
from .channel import DriftstoneChannel
from .session import DriftstoneSession
from .profile import DriftstoneProfile
from .instance import DriftstoneInstance
from .conflict import DriftstoneConflict

class DriftstoneApp(ResourceBase):
    def _build_app_model(self, app_data: dict) -> DriftstoneAppModel:
        app_id = app_data["id"]

        version = DriftstoneVersion(self._client, app_id)
        access_group = DriftstoneAccessGroup(self._client, app_id)
        channel = DriftstoneChannel(self._client, app_id)
        session = DriftstoneSession(self._client, app_id)
        profile = DriftstoneProfile(self._client, app_id)
        instance = DriftstoneInstance(self._client, app_id)
        conflict = DriftstoneConflict(self._client, app_id)

        return DriftstoneAppModel._from_api(
            app_data,
            version=version,
            channel=channel,
            session=session,
            access_group=access_group,
            profile=profile,
            instance=instance,
            conflict=conflict,
        )

    def init(
        self, 
        slug: str,
        *,
        type: ApplicationType,
        version_path: str,
        name: Optional[str] = None,
        limit: Optional[AppInitLimit] = None,
        credentials: Optional[list[AppInitCredential]] = None,
        auto_update_version: bool = True,
    ) -> DriftstoneAppModel:
        trimmed_slug = slug.strip()
        if not trimmed_slug:
            raise DriftstoneError("slug must be a non-empty string")
        
        if not all(c.isalnum() or c in "-_" for c in trimmed_slug):
            raise DriftstoneError("slug must be URL-safe (only contain letters, numbers, hyphens, and underscores)")

        if trimmed_slug[0] in "-_" or trimmed_slug[-1] in "-_":
            raise DriftstoneError("slug cannot start or end with a hyphen or underscore")
        
        if type not in AVAILABLE_APP_TYPES:
            raise DriftstoneError(f"type must be one of {AVAILABLE_APP_TYPES}")

        if not version_path or not isinstance(version_path, str):
            raise DriftstoneError("version_path must be a non-empty string")
        
        if name is not None and (not isinstance(name, str) or not name.strip()):
            raise DriftstoneError("name must be a non-empty string")
        
        if limit is not None and (not isinstance(limit, dict) or "amount" not in limit or "interval" not in limit):
            raise DriftstoneError("limit must be a dictionary with 'amount' and 'interval' keys")
        
        if credentials is not None and (not isinstance(credentials, list) or not all(isinstance(cred, dict) for cred in credentials)):
            raise DriftstoneError("credentials must be a list of dictionaries")
        
        if type == "openclaw":
            raise NotImplementedError("Application type 'openclaw' is not yet supported. Please use 'claude' for now.")

        path_data = DriftstoneVersion._validate_version_path(version_path)
        _, sha256 = DriftstoneVersion._build_zip(path_data["path"])

        additional_payload = {}
        if name is not None:
            additional_payload["name"] = name.strip()
        if limit is not None:
            additional_payload["limit"] = limit
        if credentials is not None:
            additional_payload["credentials"] = credentials

        app_create_res = self._client._request("POST", "/app/create", {
            "slug": trimmed_slug,
            "type": path_data["type"],
            **additional_payload,
            "returnIfExist": True,
        })

        app_id = app_create_res["data"]["id"]
        version = DriftstoneVersion(self._client, app_id)

        has_updated_zip = False
        if auto_update_version:
            latest_res = self._client._request("GET", "/version/latest", {
                "appId": app_id,
            })
            
            has_updated_zip = bool(latest_res.get("data") and latest_res["data"].get("sha256") != sha256)

        if not app_create_res.get("exists", False) or \
            not app_create_res["data"].get("headVersionId") or \
            has_updated_zip:
            version.create(version_path)
        
        app_res = self._client._request("GET", f"/app/{app_id}")

        return self._build_app_model(app_res["data"])

    def retrieve(
        self, 
        *, 
        app_id: Optional[str] = None,
        slug: Optional[str] = None,
    ) -> DriftstoneAppModel:
        try:
            if not app_id and not slug:
                raise Exception("Either app_id or slug must be provided")
            
            if app_id and slug:
                raise Exception("Only one of app_id or slug can be provided, not both")
            
            if app_id and not isinstance(app_id, str):
                raise Exception("app_id must be a string")
            
            if slug and not isinstance(slug, str):
                raise Exception("slug must be a string")
        
            app_res = self._client._request("GET", f"/app/{app_id or slug}")

            return self._build_app_model(app_res["data"])
        except DriftstoneError:
            return None
        except Exception as e:
            raise e

    def delete(self, app_id: str) -> bool:
        if not isinstance(app_id, str) or not app_id.strip():
            raise DriftstoneError("app_id must be a non-empty string")

        self._client._request("DELETE", f"/app/{app_id.strip()}")

        return True
    
    def channel(self, app_id: str) -> DriftstoneChannel:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneChannel(self._client, trimmed_app_id)

    def instance(self, app_id: str) -> DriftstoneInstance:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneInstance(self._client, trimmed_app_id)

    def access_group(self, app_id: str) -> DriftstoneAccessGroup:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneAccessGroup(self._client, trimmed_app_id)

    def profile(self, app_id: str) -> DriftstoneProfile:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneProfile(self._client, trimmed_app_id)

    def conflict(self, app_id: str) -> DriftstoneConflict:
        trimmed_app_id = app_id.strip()
        if not trimmed_app_id:
            raise DriftstoneError("app_id must be a non-empty string")
        return DriftstoneConflict(self._client, trimmed_app_id)
