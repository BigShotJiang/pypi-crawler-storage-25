"""Driftstone SDK resource modules."""
