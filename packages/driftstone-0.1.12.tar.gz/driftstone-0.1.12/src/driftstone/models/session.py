from __future__ import annotations

from typing import Mapping, Any, Literal, Optional
from dataclasses import dataclass
from datetime import datetime

SessionType = Literal["single", "multiple"]

@dataclass(frozen=True, slots=True)
class DriftstoneSessionModel:
    id: str
    appId: str
    type: SessionType
    userIds: list[str]
    profileIds: list[str]
    metadata: Optional[dict[str, str]]
    externalId: Optional[str]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneSessionModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            type=payload["type"],
            userIds=payload["userIds"],
            profileIds=payload["profileIds"],
            metadata=payload.get("metadata"),
            externalId=payload.get("externalId"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
