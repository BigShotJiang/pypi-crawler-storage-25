from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping, Optional

InstanceStatus = Literal["running", "terminated"]

@dataclass(frozen=True, slots=True)
class DriftstoneInstanceModel:
    id: str
    appId: str
    versionId: str
    channelId: str
    sessionId: str
    profileId: str
    accessGroupId: str
    stateId: Optional[str]
    identifier: str
    timeout: int
    totalCost: float
    costBreakdown: dict[str, float]
    tokenBreakdown: dict[str, int]
    metadata: Optional[dict[str, str]]
    status: InstanceStatus
    error: Optional[str]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneInstanceModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            versionId=payload["versionId"],
            channelId=payload["channelId"],
            sessionId=payload["sessionId"],
            profileId=payload["profileId"],
            accessGroupId=payload["accessGroupId"],
            stateId=payload.get("stateId"),
            identifier=payload["identifier"],
            timeout=payload["timeout"],
            totalCost=payload["totalCost"],
            costBreakdown=payload["costBreakdown"],
            tokenBreakdown=payload["tokenBreakdown"],
            metadata=payload.get("metadata"),
            status=payload["status"],
            error=payload.get("error"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
