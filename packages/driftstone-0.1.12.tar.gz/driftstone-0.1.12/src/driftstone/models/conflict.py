from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping, Optional

ConflictReason = Literal["missing_head_state", "missing_state_branch", "merge_conflict"]


@dataclass(frozen=True, slots=True)
class DriftstoneConflictModel:
    id: str
    appId: str
    syncId: str
    profileId: str
    versionId: str
    stateId: str
    stateBranch: str
    reason: ConflictReason
    error: Optional[str]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneConflictModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            syncId=payload["syncId"],
            profileId=payload["profileId"],
            versionId=payload["versionId"],
            stateId=payload["stateId"],
            stateBranch=payload["stateBranch"],
            reason=payload["reason"],
            error=payload.get("error"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
