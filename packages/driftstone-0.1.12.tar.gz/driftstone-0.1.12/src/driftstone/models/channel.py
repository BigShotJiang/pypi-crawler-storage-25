from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import (
    Any,
    AsyncIterator, 
    Iterator, 
    Literal,
    Mapping, 
    Optional, 
    Protocol, 
    TypedDict
)

from .response import ResponseRunStreamEvent

ChannelType = Literal["api", "imessage"]

class ChannelRun(Protocol):
    def __call__(
        self, 
        user_id: str, 
        session_id: Optional[str] = None,
        input: str = ""
    ) -> Iterator[ResponseRunStreamEvent]: ...

class ChannelRunAsync(Protocol):
    def __call__(
        self, 
        user_id: str, 
        session_id: Optional[str] = None,
        input: str = ""
    ) -> AsyncIterator[ResponseRunStreamEvent]: ...

class ChannelRunner(Protocol):
    def __call__(
        self, 
        user_id: str, 
        session_id: Optional[str] = None,
        input: str = ""
    ) -> Iterator[ResponseRunStreamEvent]: ...

class ChannelRunnerAsync(Protocol):
    def __call__(
        self, 
        user_id: str, 
        session_id: Optional[str] = None,
        input: str = ""
    ) -> AsyncIterator[ResponseRunStreamEvent]: ...

class ChannelAPIWebhook(TypedDict):
    name: str
    url: str
    headers: Optional[dict[str, str]]

class ChannelIMessageData(TypedDict):
    sendBlueAPIKey: str
    sendBlueSecretKey: str
    fromNumber: str

@dataclass(frozen=True, slots=True)
class DriftstoneChannelModel:
    id: str
    appId: str
    type: ChannelType
    name: str
    webhook: Optional[ChannelAPIWebhook]
    data: Optional[ChannelIMessageData]
    createdAt: datetime
    updatedAt: datetime

    run: ChannelRun
    run_async: ChannelRunAsync

    @classmethod
    def _from_api(
        cls, 
        payload: Mapping[str, Any],
        run: ChannelRunner,
        run_async: ChannelRunnerAsync,
    ) -> "DriftstoneChannelModel":
        channel_id = payload["id"]

        def channel_run(
            user_id: str, 
            session_id: Optional[str] = None,
            input: str = ""
        ) -> Iterator[ResponseRunStreamEvent]:
            for event in run(
                channel_id, 
                user_id,
                session_id,
                input
            ):
                yield event

        async def channel_run_async(
            user_id: str, 
            session_id: Optional[str] = None,
            input: str = ""
        ) -> AsyncIterator[ResponseRunStreamEvent]:
            async for event in run_async(
                channel_id, 
                user_id, 
                session_id,
                input
            ):
                yield event

        return cls(
            id=payload["id"],
            appId=payload["appId"],
            type=payload["type"],
            name=payload["name"],
            webhook=payload.get("webhook"),
            data=payload.get("data"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
            
            run=channel_run,
            run_async=channel_run_async,
        )
