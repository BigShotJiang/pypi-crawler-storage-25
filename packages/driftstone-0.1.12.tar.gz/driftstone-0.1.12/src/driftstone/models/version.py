from __future__ import annotations

from typing import Mapping, Any, Optional, Dict, TypedDict
from dataclasses import dataclass
from datetime import datetime

class HashMapItem(TypedDict):
    id: str
    hash: str

@dataclass(frozen=True, slots=True)
class DriftstoneVersionModel:
    id: str
    appId: str
    version: int
    commitHash: str
    gitOrigin: str
    gitBranch: str
    storageUrl: str
    map: Optional[Dict[str, HashMapItem]]
    metadata: Optional[dict[str, str]]
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneVersionModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            version=payload["version"],
            commitHash=payload["commitHash"],
            gitOrigin=payload["gitOrigin"],
            gitBranch=payload["gitBranch"],
            storageUrl=payload["storageUrl"],
            map=payload.get("map"),
            metadata=payload.get("metadata"),
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
