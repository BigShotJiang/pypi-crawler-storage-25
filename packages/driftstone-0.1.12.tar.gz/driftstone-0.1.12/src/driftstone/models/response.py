from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Any

@dataclass(frozen=True, slots=True)
class ResponseRunStreamEvent:
    instance_id: str
    index: int
    data: Any
    done: Optional[bool] = None
    error: Optional[str] = None
