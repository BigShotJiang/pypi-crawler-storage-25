from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Mapping

AccessGroupLimitReset = Literal["daily", "monthly", "yearly"]


@dataclass(frozen=True, slots=True)
class DriftstoneAccessGroupModel:
    id: str
    appId: str
    name: str
    limit: int
    limitReset: AccessGroupLimitReset
    limitMessage: str
    createdAt: datetime
    updatedAt: datetime

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneAccessGroupModel":
        return cls(
            id=payload["id"],
            appId=payload["appId"],
            name=payload["name"],
            limit=payload["limit"],
            limitReset=payload["limitReset"],
            limitMessage=payload["limitMessage"],
            createdAt=datetime.fromisoformat(payload["createdAt"]),
            updatedAt=datetime.fromisoformat(payload["updatedAt"]),
        )
