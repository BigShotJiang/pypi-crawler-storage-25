import logging
import json

logger = logging.getLogger("driftstone")
logger.setLevel(logging.WARNING)
logger.addHandler(logging.NullHandler())

logging.basicConfig(
    format="[%(funcName)s][%(asctime)s]: %(levelname)s %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
)

def set_debug(enabled: bool) -> None:
    logger.setLevel(logging.INFO if enabled else logging.WARNING)

def safe_parse_json(raw: str):
    try:
        return json.loads(raw)
    except Exception as e:
        logger.error("Failed to parse JSON: %s", e)
        return None
