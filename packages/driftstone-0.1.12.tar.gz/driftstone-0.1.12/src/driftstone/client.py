from __future__ import annotations

from typing import Any, Literal

import httpx

from ._internal.constants import DEFAULT_API_BASE_URL
from ._internal.utils import logger, set_debug
from ._internal.transport import Method, Transport
from .resources.app import DriftstoneApp
from .version import __version__

class Driftstone:
    def __init__(
        self,
        api_key: str,
        *,
        version: Literal["v1"] = "v1",
        timeout: float = 30.0,
        debug: bool = False,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.debug = debug
        set_debug(self.debug)
        
        logger.info("Initializing Driftstone client with provided API key")

        trimmed_key = api_key.strip()
        if not trimmed_key:
            raise ValueError("api_key must be provided")
        if not trimmed_key.startswith("dk-"):
            raise ValueError("Invalid Driftstone API key")

        self.api_key = trimmed_key
        self.version = version
        self.timeout = timeout
        self.base_url = f"{DEFAULT_API_BASE_URL}/{self.version}"

        self._transport = Transport(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.timeout,
            user_agent=f"Driftstone-python/{__version__}",
            http_client=http_client,
        )

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "Driftstone":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _request(
        self,
        method: Method,
        path: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self._transport.request(method, path, payload)

    @property
    def app(self) -> DriftstoneApp:
        return DriftstoneApp(self)
    
