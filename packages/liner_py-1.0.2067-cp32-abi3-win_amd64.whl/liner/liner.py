import ctypes
import os
dll = ctypes.CDLL(os.path.dirname(__file__) + '/liner.dll')
liner = dll.liner
linex = dll.linex
del ctypes, os, dll
