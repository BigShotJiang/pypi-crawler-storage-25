"""Helpers to build Plotly subplots figures."""

import textwrap

import numpy as np
from typing import List, Tuple
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def build_new_figure_plotly(row: int, col: int, title: str = None) -> go.Figure:
    """Create a new Plotly figure.

    Args:
        row (int): Row index.
        col (int): Col index.
        title (str): Title of the figure.

    Returns:
        go.Figure: Plotly figure.
    """

    figure = make_subplots(
        rows=row,
        cols=col,
        # empty subplot titles at first.
        subplot_titles=tuple([" " for i in range(row * col)]),
        vertical_spacing=0.15,
        horizontal_spacing=0.12,
    )
    figure.update_layout(margin=dict(t=0, l=0, r=0, b=0))
    _set_legend_pos(figure)
    if title:
        figure.update_layout(title_text=title, title_x=0, title_y=0.85, title_xref="paper")

    return figure


def add_curve_plotly(
    fig: go.Figure,
    x: np.ndarray,
    y: np.ndarray,
    linewidth: int,
    custom_style: dict,
    legend: str,
    graph_position: int,
    ncols: int,
    curve_number: int,
):
    """Add a curve on a Plotly figure.
    In reality, add two traces:
        - a line
        - N markers, as defined in `symbols_makevery`

    Args:
        fig (go.Figure): Plotly figure.
        x (np.ndarray): X values.
        y (np.ndarray): Y values.
        pos (List[int]): (row, col) indexes
        linewidth (int): Width of the line.
        custom_style (dict): Style parameters.
        legend (str): Graph legend.
        graph_position (int): Index of the graph.
        curve_number (int): Index of the curve.
    """
    row, col = _calc_row_col(graph_position, ncols)
    symbols_markevery = custom_style["markevery"]
    fig.add_trace(
        go.Scatter(
            mode="lines",
            x=x,
            y=y,
            name=legend,
            # unique legendgroup per curve.
            legendgroup=f"group{graph_position}_{curve_number}",
            # share legend per subplot, displayed only if legend.
            legend=f"legend{graph_position}" if legend else None,
            line={
                "width": linewidth,
                "color": custom_style["color"],
                "dash": custom_style["linestyle"],
            },
            showlegend=True if legend else False,
        ),
        row=row,
        col=col,
    )
    fig.add_trace(
        go.Scatter(
            mode="markers",
            x=x[symbols_markevery],
            y=y[symbols_markevery],
            name=legend,
            legend=f"legend{graph_position}" if legend else None,
            legendgroup=f"group{graph_position}_{curve_number}",
            marker={
                "symbol": custom_style["marker"],
                "color": custom_style["color"],
            },
            showlegend=False,
        ),
        row=row,
        col=col,
    )


def set_labels_plotly(
    figure: go.Figure,
    x_label: str,
    y_label: str,
    title: str,
    graph_position: int,
    ncols: int,
):
    """Add title and axes labels to a Plotly subplot.

    Args:
        figure (go.Figure): Plotly figure.
        x_label (str): Label for the X axis.
        y_label (str): Label for the Y axis.
        title (str): Title of the subplot.
        graph_position (int): Index of the graph.
        ncols (int): Number of columns.
    """
    row, col = _calc_row_col(graph_position, ncols)
    figure.update_xaxes(
        title_text=x_label,
        row=row,
        col=col,
        automargin=True,
        mirror=True,
        matches="x",
    )
    figure.update_yaxes(
        title_text=y_label,
        row=row,
        col=col,
        automargin=True,
        mirror=True,
    )
    if title:
        figure.layout.annotations[graph_position - 1].update(text=title)


def _set_legend_pos(fig: go.Figure):
    """Position each subplot legend next to it, for Plotly subplots only.

    Args:
        fig (go.Figure): Plotly figure.
    """
    for i, (xaxis, yaxis) in enumerate(zip(fig.select_xaxes(), fig.select_yaxes()), 1):
        fig.update_layout(
            {
                f"legend{i}": {
                    "y": yaxis.domain[1],
                    "x": xaxis.domain[1] + 0.001,
                    "yanchor": "top",
                    "tracegroupgap": 0,
                }
            }
        )


def _calc_row_col(idx: int, ncols: int) -> Tuple[int, int]:
    """Returns the (row, col) indexes for Plotly subplots.
    **WARNING**: this function assume that idx start at 1 !!

    Args:
        idx (int): Graph index. Start at 1.
        ncols (int): Number of columns.

    Returns:
        Tuple[int, int]: (row, col) indexes.
    """
    row = (idx - 1) // ncols + 1
    col = (idx - 1) % ncols + 1
    return row, col


def merge_views(views: List[go.Figure]) -> go.Figure:
    """
    Merge multiples Plotly figures, `views`, into a main one.
    This is a workaround for using buttons to switch from one figure to another within
    the Plotly framework. Each "tab" updates curve visibility and adjust layout (plots
    title, axis labels, ...).

    Add also:
        - a common style (white bg, black lines and grey grid)
        - menu to toggle "shared" axes.
        - annotations for each menu.

    Args:
        views (List[go.Figure]): Plotly figures to show.
        show (bool): Disable show for testing.

    Returns:
        go.Figure: Main figure.
    """
    # init main figure
    main_fig = go.Figure()
    idx = _populate_main_fig(main_fig, views)

    used_axes_per_fig = _get_used_axes_per_fig(views)
    _add_menu_annotations(views)
    layouts_modifs = _get_layouts_modifs_per_view(views, used_axes_per_fig)

    # set first layout + theme
    main_fig.layout = views[0].layout
    main_fig.layout.plot_bgcolor = "#FFFFFF"
    for ax in used_axes_per_fig[0]:
        main_fig.layout[ax].linecolor = "black"
        main_fig.layout[ax].gridcolor = "lightgrey"
    # set first view
    for fig in main_fig.data[idx[1] :]:
        fig.visible = False

    # prepare different views
    unshared_x, shared_x, unshared_y, shared_y = {}, {}, {}, {}
    for ax in used_axes_per_fig[0]:
        if "xaxis" in ax:
            unshared_x[f"{ax}.matches"] = None
            shared_x[f"{ax}.matches"] = "x"
        elif "yaxis" in ax:
            unshared_y[f"{ax}.matches"] = None
            shared_y[f"{ax}.matches"] = "y"

    # set menus
    main_fig.update_layout(
        updatemenus=[
            # menu views
            dict(
                y=1.3,
                x=0,
                type="buttons",
                direction="right",
                xanchor="left",
                yanchor="top",
                pad={"l": 50},
                buttons=[
                    dict(
                        label=f"Fig. {v+1}",
                        method="update",
                        # play with visibility to look like "switching views"
                        args=[
                            {
                                "visible": [
                                    (True if i >= idx[v] and i < idx[v + 1] else False)
                                    for i in range(len(main_fig.data))
                                ],
                            },
                            layouts_modifs[v],
                        ],
                    )
                    for v in range(len(views))
                ],
            ),
            dict(
                y=1.3,
                x=0,
                type="buttons",
                direction="right",
                xanchor="left",
                yanchor="top",
                pad={"l": 90, "t": 40},
                buttons=[
                    dict(
                        label=f"On",
                        method="relayout",
                        args=[shared_x],
                    ),
                    dict(
                        label=f"Off",
                        method="relayout",
                        args=[unshared_x],
                    ),
                ],
            ),
            dict(
                y=1.3,
                x=0,
                type="buttons",
                direction="right",
                xanchor="left",
                yanchor="top",
                active=1,
                pad={"l": 300, "t": 40},
                buttons=[
                    dict(
                        label=f"On",
                        method="relayout",
                        args=[shared_y],
                    ),
                    dict(
                        label=f"Off",
                        method="relayout",
                        args=[unshared_y],
                    ),
                ],
            ),
        ]
    )

    return main_fig


def _populate_main_fig(main_fig: go.Figure, views: List[go.Figure]) -> List[int]:
    """Add traces to main figure.

    Args:
        main_fig (go.Figure): Main figure.
        views (List[go.Figure]): Figures to plot.

    Returns:
        List[int]: List of indexes of the last trace of each figure.
    """
    idx = [0]
    for fig in views:
        for t in fig.data:
            main_fig.add_trace(t)
        idx.append(idx[-1] + len(fig.data))
    return idx


def _get_used_axes_per_fig(views: List[go.Figure]) -> List[list]:
    """Get the list of used axes per figure. Format is "xaxisN" and "yaxisN".

    Args:
        views (List[go.Figure]): Figures to plot.

    Returns:
        List[list]: List of used axes per figure.
    """
    used_axes_per_fig = []
    for v in views:
        vaxis = set()
        for t in v.data:
            vaxis.add("xaxis" if t.xaxis == "x" else f"xaxis{t.xaxis.split('x')[-1]}")
            vaxis.add("yaxis" if t.yaxis == "y" else f"yaxis{t.yaxis.split('y')[-1]}")
        used_axes_per_fig.append(list((vaxis)))
    return used_axes_per_fig


def _add_menu_annotations(views: List[go.Figure]):
    """The annotations will be completely overwritten when switching views.
    so add the menu annotations to each figure beforehand.

    Args:
        views (List[go.Figure]): List of views.
    """
    for fig in views:
        fig.add_annotation(
            text="Link X-Axes: ",
            x=0,
            y=1.3,
            yshift=-45,
            align="left",
            yref="paper",
            xref="paper",
            xanchor="left",
            yanchor="top",
            showarrow=False,
        )
        fig.add_annotation(
            text="Link Y-Axes: ",
            x=0,
            y=1.3,
            yshift=-45,
            xshift=210,
            align="left",
            yref="paper",
            xref="paper",
            xanchor="left",
            yanchor="top",
            showarrow=False,
        )
        fig.add_annotation(
            text="View: ",
            yshift=-5,
            x=0,
            y=1.3,
            align="left",
            yref="paper",
            xref="paper",
            xanchor="left",
            yanchor="top",
            showarrow=False,
        )


def _get_layouts_modifs_per_view(
    views: List[go.Figure], used_axes_per_fig: List[list]
) -> List[dict]:
    """
    Specifies the changes to be made to the layout (titles, axes domain and title, ...)
    of the main figure when switching views.
    **WARNING**: overwrite annotations completly.

    Args:
        view (List[go.Figure]): Figures to plot.

    Returns:
        List[dict]: Layout modifications per view.
    """
    layouts = []

    for i, v in enumerate(views):
        lay = v.layout.to_plotly_json()
        lay_args = {"title": lay["title"], "annotations": lay["annotations"]}
        for ax in used_axes_per_fig[0]:
            if ax not in used_axes_per_fig[i]:
                lay_args[f"{ax}.visible"] = False
                lay_args[f"{ax}.showline"] = False
                lay_args[f"{ax}.domain"] = [0, 0.001]  # trick to remove interactions. thanks claude
            else:
                lay_args[f"{ax}.domain"] = lay[ax]["domain"]
                if "title" in lay[ax].keys():
                    lay_args[f"{ax}.title"] = lay[ax]["title"]
                else:
                    lay_args[f"{ax}.title"] = None
                lay_args[f"{ax}.visible"] = True
                lay_args[f"{ax}.showline"] = True
                lay_args[f"{ax}.autorange"] = True

        layouts.append(lay_args)

    return layouts
