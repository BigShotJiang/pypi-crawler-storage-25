"""Helpers to build Matplotlib subplots figures."""

import matplotlib.pyplot as plt
import numpy as np


def set_labels_matplotlib(ax: plt.Axes, x_label: str, y_label: str, title: str):
    """Add title and axes labels to a Matplotlib subplot.

    Args:
        ax (plt.Axes): Matplotlib axes.
        x_label (str): Label for the X-axis.
        y_label (str): Label for the Y-axis.
        title (str): Title of the subplot.
    """
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title, fontweight="bold")


def add_curve_matplotlib(
    ax: plt.Axes,
    x: np.ndarray,
    y: np.ndarray,
    linewidth: int,
    custom_style: dict,
):
    """Add a curve on a Matplotlib figure.

    Args:
        ax (plt.Axes): Matplotlib axes.
        x (np.ndarray): X values.
        y (np.ndarray): Y values.
        linewidth (int): Width of the line.
        custom_style (dict): Style parameters.
    """
    ax.plot(
        x,
        y,
        **custom_style,
        linewidth=linewidth,
    )
