"""Tests for briefing reader protocol."""

from __future__ import annotations

from typing import Any

from bpsai_agent_lounge.briefing import BriefingReader


class TestBriefingReader:
    """AC: BriefingReader protocol: load latest briefing on session startup."""

    def test_conforming_class_is_instance(self):
        class MyReader:
            def load_briefing(self) -> dict[str, Any] | None: ...

        assert isinstance(MyReader(), BriefingReader)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            pass

        assert not isinstance(Incomplete(), BriefingReader)

    def test_protocol_methods(self):
        members = {m for m in dir(BriefingReader) if not m.startswith("_")}
        assert {"load_briefing"} <= members
