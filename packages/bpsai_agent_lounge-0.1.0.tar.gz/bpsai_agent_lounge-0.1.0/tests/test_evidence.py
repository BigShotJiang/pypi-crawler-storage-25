"""Tests for evidence mapper protocol."""

from __future__ import annotations

from typing import Any

from bpsai_agent_lounge.evidence import EvidenceMapper


class TestEvidenceMapper:
    """AC: EvidenceMapper protocol: transform raw observations into structured evidence."""

    def test_conforming_class_is_instance(self):
        class MyMapper:
            def map_observation(
                self, observation: dict[str, Any],
            ) -> dict[str, Any]: ...

        assert isinstance(MyMapper(), EvidenceMapper)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            pass

        assert not isinstance(Incomplete(), EvidenceMapper)

    def test_protocol_methods(self):
        members = {m for m in dir(EvidenceMapper) if not m.startswith("_")}
        assert {"map_observation"} <= members
