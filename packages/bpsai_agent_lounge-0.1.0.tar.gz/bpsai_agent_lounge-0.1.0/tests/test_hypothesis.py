"""Tests for hypothesis lifecycle types and transition validation."""

from __future__ import annotations

from typing import Any

import pytest

from bpsai_agent_lounge.hypothesis import (
    VALID_TRANSITIONS,
    HypothesisLifecycle,
    HypothesisStatus,
    validate_transition,
)


class TestHypothesisStatus:
    """AC: HypothesisStatus enum with all lifecycle states."""

    def test_observed(self):
        assert HypothesisStatus.OBSERVED.value == "observed"

    def test_instrumented(self):
        assert HypothesisStatus.INSTRUMENTED.value == "instrumented"

    def test_incubating(self):
        assert HypothesisStatus.INCUBATING.value == "incubating"

    def test_actionable(self):
        assert HypothesisStatus.ACTIONABLE.value == "actionable"

    def test_closed(self):
        assert HypothesisStatus.CLOSED.value == "closed"

    def test_all_five_members(self):
        assert len(HypothesisStatus) == 5


class TestValidTransitions:
    """AC: Transition validation logic extracted."""

    def test_observed_to_instrumented(self):
        assert HypothesisStatus.INSTRUMENTED in VALID_TRANSITIONS[HypothesisStatus.OBSERVED]

    def test_instrumented_to_incubating(self):
        assert HypothesisStatus.INCUBATING in VALID_TRANSITIONS[HypothesisStatus.INSTRUMENTED]

    def test_incubating_to_actionable(self):
        assert HypothesisStatus.ACTIONABLE in VALID_TRANSITIONS[HypothesisStatus.INCUBATING]

    def test_any_to_closed(self):
        for status in HypothesisStatus:
            if status == HypothesisStatus.CLOSED:
                continue
            assert HypothesisStatus.CLOSED in VALID_TRANSITIONS[status]

    def test_closed_has_no_forward_transitions(self):
        assert VALID_TRANSITIONS[HypothesisStatus.CLOSED] == set()

    def test_no_skip_transitions(self):
        """Cannot jump observed -> actionable."""
        assert HypothesisStatus.ACTIONABLE not in VALID_TRANSITIONS[HypothesisStatus.OBSERVED]


class TestValidateTransition:
    """AC: validate_transition function enforces the state machine."""

    def test_valid_forward(self):
        assert validate_transition(HypothesisStatus.OBSERVED, HypothesisStatus.INSTRUMENTED) is True

    def test_valid_close(self):
        assert validate_transition(HypothesisStatus.INCUBATING, HypothesisStatus.CLOSED) is True

    def test_invalid_skip(self):
        assert validate_transition(HypothesisStatus.OBSERVED, HypothesisStatus.ACTIONABLE) is False

    def test_invalid_backwards(self):
        assert validate_transition(HypothesisStatus.ACTIONABLE, HypothesisStatus.OBSERVED) is False

    def test_closed_cannot_transition(self):
        assert validate_transition(HypothesisStatus.CLOSED, HypothesisStatus.OBSERVED) is False

    def test_same_state(self):
        assert validate_transition(HypothesisStatus.OBSERVED, HypothesisStatus.OBSERVED) is False


class TestHypothesisLifecycle:
    """AC: HypothesisLifecycle protocol with add/advance/close/update_confidence/needs_reevaluation."""

    def test_is_runtime_checkable(self):
        assert hasattr(HypothesisLifecycle, "__protocol_attrs__") or hasattr(
            HypothesisLifecycle, "__abstractmethods__"
        )

    def test_conforming_class_is_instance(self):
        class MyLifecycle:
            def add(self, hypothesis_id: str, pattern: str, status: HypothesisStatus) -> None: ...
            def advance(self, hypothesis_id: str, new_status: HypothesisStatus) -> None: ...
            def close(self, hypothesis_id: str, reason: str) -> None: ...
            def update_confidence(
                self, hypothesis_id: str, confidence: float, evidence: dict[str, Any]
            ) -> None: ...
            def needs_reevaluation(self) -> list[str]: ...

        assert isinstance(MyLifecycle(), HypothesisLifecycle)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            def add(self, hypothesis_id: str, pattern: str, status: HypothesisStatus) -> None: ...

        assert not isinstance(Incomplete(), HypothesisLifecycle)

    def test_protocol_methods_exist(self):
        expected = {"add", "advance", "close", "update_confidence", "needs_reevaluation"}
        # Check via annotations or dir
        members = {
            m for m in dir(HypothesisLifecycle) if not m.startswith("_")
        }
        assert expected <= members
