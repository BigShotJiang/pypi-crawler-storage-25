"""Tests for package-level exports and dependency constraints."""

from __future__ import annotations


class TestPackageExports:
    """AC: bpsai_agent_lounge exports all required types."""

    def test_hypothesis_status_exported(self):
        from bpsai_agent_lounge import HypothesisStatus

        assert HypothesisStatus is not None

    def test_hypothesis_lifecycle_exported(self):
        from bpsai_agent_lounge import HypothesisLifecycle

        assert HypothesisLifecycle is not None

    def test_validate_transition_exported(self):
        from bpsai_agent_lounge import validate_transition

        assert validate_transition is not None

    def test_channel_client_exported(self):
        from bpsai_agent_lounge import ChannelClient

        assert ChannelClient is not None

    def test_channel_observer_exported(self):
        from bpsai_agent_lounge import ChannelObserver

        assert ChannelObserver is not None

    def test_belief_store_exported(self):
        from bpsai_agent_lounge import BeliefStore

        assert BeliefStore is not None

    def test_evidence_mapper_exported(self):
        from bpsai_agent_lounge import EvidenceMapper

        assert EvidenceMapper is not None

    def test_briefing_reader_exported(self):
        from bpsai_agent_lounge import BriefingReader

        assert BriefingReader is not None

    def test_standup_reporter_exported(self):
        from bpsai_agent_lounge import StandupReporter

        assert StandupReporter is not None

    def test_valid_transitions_exported(self):
        from bpsai_agent_lounge import VALID_TRANSITIONS

        assert VALID_TRANSITIONS is not None


class TestAllExportedSymbolsCovered:
    """AC: 100% of exported symbols in __all__."""

    def test_all_symbols_in_all_are_importable(self):
        import bpsai_agent_lounge

        for name in bpsai_agent_lounge.__all__:
            obj = getattr(bpsai_agent_lounge, name, None)
            assert obj is not None, f"{name} in __all__ but not importable"

    def test_all_public_symbols_in_all(self):
        """Every public attr that isn't dunder should be in __all__."""
        import types

        import bpsai_agent_lounge

        public_attrs = {
            k
            for k in dir(bpsai_agent_lounge)
            if not k.startswith("_") and k != "annotations"
        }
        all_set = set(bpsai_agent_lounge.__all__)
        missing = public_attrs - all_set
        missing = {
            m
            for m in missing
            if not isinstance(getattr(bpsai_agent_lounge, m), types.ModuleType)
        }
        assert missing == set(), f"Public symbols not in __all__: {missing}"


class TestNoDependencyOnFramework:
    """AC: Package imports only bpsai-agent-core -- no framework dependency."""

    def test_no_framework_import(self):
        import inspect
        import pathlib

        import bpsai_agent_lounge

        source_file = inspect.getfile(bpsai_agent_lounge)
        pkg_dir = pathlib.Path(source_file).parent
        for py_file in pkg_dir.glob("*.py"):
            content = py_file.read_text()
            assert "bpsai_framework" not in content, (
                f"{py_file.name} imports from bpsai_framework"
            )
            assert "import yaml" not in content, (
                f"{py_file.name} imports yaml (framework dependency)"
            )
