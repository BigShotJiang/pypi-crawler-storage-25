"""Tests for channel coordination protocols."""

from __future__ import annotations

from typing import Any

from bpsai_agent_lounge.channels import ChannelClient, ChannelObserver


class TestChannelClient:
    """AC: ChannelClient protocol: send/receive coordination messages."""

    def test_conforming_class_is_instance(self):
        class MyClient:
            def send(self, channel: str, message: dict[str, Any]) -> None: ...
            def receive(self, channel: str) -> list[dict[str, Any]]: ...

        assert isinstance(MyClient(), ChannelClient)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            def send(self, channel: str, message: dict[str, Any]) -> None: ...

        assert not isinstance(Incomplete(), ChannelClient)

    def test_protocol_methods(self):
        members = {m for m in dir(ChannelClient) if not m.startswith("_")}
        assert {"send", "receive"} <= members


class TestChannelObserver:
    """AC: ChannelObserver protocol: subscribe to channel events."""

    def test_conforming_class_is_instance(self):
        class MyObserver:
            def subscribe(self, channel: str, callback: Any) -> None: ...
            def unsubscribe(self, channel: str) -> None: ...

        assert isinstance(MyObserver(), ChannelObserver)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            pass

        assert not isinstance(Incomplete(), ChannelObserver)

    def test_protocol_methods(self):
        members = {m for m in dir(ChannelObserver) if not m.startswith("_")}
        assert {"subscribe", "unsubscribe"} <= members
