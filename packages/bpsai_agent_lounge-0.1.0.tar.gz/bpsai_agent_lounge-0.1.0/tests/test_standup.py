"""Tests for standup/reporting protocol."""

from __future__ import annotations

from typing import Any

from bpsai_agent_lounge.standup import StandupReporter


class TestStandupReporter:
    """AC: Standup/reporting protocol: compose session summary for briefing push."""

    def test_conforming_class_is_instance(self):
        class MyReporter:
            def compose_summary(self) -> dict[str, Any]: ...
            def push_briefing(self, summary: dict[str, Any]) -> None: ...

        assert isinstance(MyReporter(), StandupReporter)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            def compose_summary(self) -> dict[str, Any]: ...

        assert not isinstance(Incomplete(), StandupReporter)

    def test_protocol_methods(self):
        members = {m for m in dir(StandupReporter) if not m.startswith("_")}
        assert {"compose_summary", "push_briefing"} <= members
