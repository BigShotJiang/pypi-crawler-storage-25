"""Behavioral tests for hypothesis lifecycle via concrete stub.

Tests: state transitions (valid/invalid/raise), close-from-any-state,
confidence update + evidence accumulation, needs_reevaluation date logic.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

import pytest

from bpsai_agent_lounge.hypothesis import (
    HypothesisLifecycle,
    HypothesisStatus,
    validate_transition,
)


# ---------------------------------------------------------------------------
# Concrete stub implementing HypothesisLifecycle for behavioral tests
# ---------------------------------------------------------------------------

class _HypothesisRecord:
    """Internal record for a single hypothesis."""

    def __init__(self, pattern: str, status: HypothesisStatus) -> None:
        self.pattern = pattern
        self.status = status
        self.confidence: float = 0.0
        self.evidence_snapshots: list[dict[str, Any]] = []
        self.close_reason: str | None = None
        self.last_evaluated: datetime = datetime.now(UTC)
        self.reevaluate_after: datetime = datetime.now(UTC) + timedelta(days=7)


class StubLifecycle:
    """Reference implementation that exercises all HypothesisLifecycle methods."""

    def __init__(self) -> None:
        self._records: dict[str, _HypothesisRecord] = {}

    def add(
        self, hypothesis_id: str, pattern: str, status: HypothesisStatus,
    ) -> None:
        self._records[hypothesis_id] = _HypothesisRecord(pattern, status)

    def advance(
        self, hypothesis_id: str, new_status: HypothesisStatus,
    ) -> None:
        rec = self._records[hypothesis_id]
        if not validate_transition(rec.status, new_status):
            raise ValueError(
                f"Invalid transition: {rec.status.value} -> {new_status.value}"
            )
        rec.status = new_status

    def close(self, hypothesis_id: str, reason: str) -> None:
        rec = self._records[hypothesis_id]
        if not validate_transition(rec.status, HypothesisStatus.CLOSED):
            raise ValueError(
                f"Cannot close from {rec.status.value}"
            )
        rec.status = HypothesisStatus.CLOSED
        rec.close_reason = reason

    def update_confidence(
        self, hypothesis_id: str, confidence: float, evidence: dict[str, Any],
    ) -> None:
        rec = self._records[hypothesis_id]
        rec.confidence = confidence
        rec.evidence_snapshots.append(evidence)
        rec.last_evaluated = datetime.now(UTC)
        rec.reevaluate_after = datetime.now(UTC) + timedelta(days=7)

    def needs_reevaluation(self) -> list[str]:
        now = datetime.now(UTC)
        return [
            hid
            for hid, rec in self._records.items()
            if rec.status != HypothesisStatus.CLOSED and rec.reevaluate_after <= now
        ]


class TestStubConformance:
    """Stub conforms to HypothesisLifecycle protocol."""

    def test_stub_conforms_to_protocol(self):
        assert isinstance(StubLifecycle(), HypothesisLifecycle)


class TestTransitionsRaiseOnInvalid:
    """AC: invalid transitions raise."""

    def _lifecycle(self) -> StubLifecycle:
        lc = StubLifecycle()
        lc.add("h1", "pattern-a", HypothesisStatus.OBSERVED)
        return lc

    def test_skip_raises(self):
        lc = self._lifecycle()
        with pytest.raises(ValueError, match="Invalid transition"):
            lc.advance("h1", HypothesisStatus.ACTIONABLE)

    def test_backward_raises(self):
        lc = self._lifecycle()
        lc.advance("h1", HypothesisStatus.INSTRUMENTED)
        with pytest.raises(ValueError, match="Invalid transition"):
            lc.advance("h1", HypothesisStatus.OBSERVED)

    def test_same_state_raises(self):
        lc = self._lifecycle()
        with pytest.raises(ValueError, match="Invalid transition"):
            lc.advance("h1", HypothesisStatus.OBSERVED)

    def test_closed_cannot_advance(self):
        lc = self._lifecycle()
        lc.close("h1", "done")
        with pytest.raises(ValueError, match="Invalid transition"):
            lc.advance("h1", HypothesisStatus.INSTRUMENTED)


class TestAllValidForwardTransitions:
    """AC: all valid forward transitions pass."""

    @pytest.mark.parametrize(
        "path",
        [
            [
                HypothesisStatus.OBSERVED,
                HypothesisStatus.INSTRUMENTED,
                HypothesisStatus.INCUBATING,
                HypothesisStatus.ACTIONABLE,
            ],
        ],
    )
    def test_full_forward_path(self, path: list[HypothesisStatus]):
        lc = StubLifecycle()
        lc.add("h1", "p", path[0])
        for next_status in path[1:]:
            lc.advance("h1", next_status)
        assert lc._records["h1"].status == path[-1]

    @pytest.mark.parametrize(
        "from_s,to_s",
        [
            (HypothesisStatus.OBSERVED, HypothesisStatus.INSTRUMENTED),
            (HypothesisStatus.INSTRUMENTED, HypothesisStatus.INCUBATING),
            (HypothesisStatus.INCUBATING, HypothesisStatus.ACTIONABLE),
        ],
    )
    def test_each_forward_step(
        self, from_s: HypothesisStatus, to_s: HypothesisStatus,
    ):
        lc = StubLifecycle()
        lc.add("h1", "p", from_s)
        lc.advance("h1", to_s)
        assert lc._records["h1"].status == to_s


class TestCloseFromAnyState:
    """AC: close-from-any-state behavior via concrete stub."""

    @pytest.mark.parametrize(
        "start",
        [
            HypothesisStatus.OBSERVED,
            HypothesisStatus.INSTRUMENTED,
            HypothesisStatus.INCUBATING,
            HypothesisStatus.ACTIONABLE,
        ],
    )
    def test_close_from_state(self, start: HypothesisStatus):
        lc = StubLifecycle()
        lc.add("h1", "p", start)
        lc.close("h1", "no longer relevant")
        assert lc._records["h1"].status == HypothesisStatus.CLOSED
        assert lc._records["h1"].close_reason == "no longer relevant"

    def test_close_already_closed_raises(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc.close("h1", "done")
        with pytest.raises(ValueError, match="Cannot close"):
            lc.close("h1", "again")


class TestConfidenceUpdateAndEvidenceAccumulation:
    """AC: confidence update + evidence snapshot accumulation."""

    def test_single_update(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc.update_confidence("h1", 0.75, {"metric": "latency", "value": 120})
        rec = lc._records["h1"]
        assert rec.confidence == 0.75
        assert len(rec.evidence_snapshots) == 1
        assert rec.evidence_snapshots[0]["metric"] == "latency"

    def test_multiple_updates_accumulate(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc.update_confidence("h1", 0.5, {"trial": 1})
        lc.update_confidence("h1", 0.7, {"trial": 2})
        lc.update_confidence("h1", 0.9, {"trial": 3})
        rec = lc._records["h1"]
        assert rec.confidence == 0.9
        assert len(rec.evidence_snapshots) == 3
        assert [e["trial"] for e in rec.evidence_snapshots] == [1, 2, 3]

    def test_confidence_replaces_not_adds(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc.update_confidence("h1", 0.3, {"a": 1})
        lc.update_confidence("h1", 0.8, {"b": 2})
        assert lc._records["h1"].confidence == 0.8  # replaced, not 1.1


class TestNeedsReevaluation:
    """AC: needs_reevaluation date logic."""

    def test_fresh_hypothesis_not_due(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        assert lc.needs_reevaluation() == []

    def test_overdue_hypothesis_returned(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc._records["h1"].reevaluate_after = datetime.now(UTC) - timedelta(days=1)
        assert "h1" in lc.needs_reevaluation()

    def test_closed_hypothesis_excluded(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc._records["h1"].reevaluate_after = datetime.now(UTC) - timedelta(days=1)
        lc.close("h1", "done")
        assert "h1" not in lc.needs_reevaluation()

    def test_update_confidence_resets_reevaluation(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc._records["h1"].reevaluate_after = datetime.now(UTC) - timedelta(days=1)
        assert "h1" in lc.needs_reevaluation()
        lc.update_confidence("h1", 0.5, {"check": True})
        assert "h1" not in lc.needs_reevaluation()

    def test_multiple_hypotheses_filtered(self):
        lc = StubLifecycle()
        lc.add("h1", "p", HypothesisStatus.OBSERVED)
        lc.add("h2", "q", HypothesisStatus.INCUBATING)
        lc.add("h3", "r", HypothesisStatus.ACTIONABLE)
        # Only h2 is overdue
        lc._records["h2"].reevaluate_after = datetime.now(UTC) - timedelta(hours=1)
        result = lc.needs_reevaluation()
        assert result == ["h2"]
