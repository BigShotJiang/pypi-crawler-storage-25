"""Tests for belief store interface."""

from __future__ import annotations

from typing import Any

from bpsai_agent_lounge.beliefs import BeliefStore


class TestBeliefStore:
    """AC: BeliefStore interface: read/write belief state."""

    def test_conforming_class_is_instance(self):
        class MyStore:
            def read(self, key: str) -> Any: ...
            def write(self, key: str, value: Any) -> None: ...
            def keys(self) -> list[str]: ...
            def delete(self, key: str) -> None: ...

        assert isinstance(MyStore(), BeliefStore)

    def test_non_conforming_class_not_instance(self):
        class Incomplete:
            def read(self, key: str) -> Any: ...

        assert not isinstance(Incomplete(), BeliefStore)

    def test_protocol_methods(self):
        members = {m for m in dir(BeliefStore) if not m.startswith("_")}
        assert {"read", "write", "keys", "delete"} <= members
