"""BPS AI Agent Lounge — channels, beliefs, hypothesis lifecycle."""

__version__ = "0.1.0"

from bpsai_agent_lounge.beliefs import BeliefStore
from bpsai_agent_lounge.briefing import BriefingReader
from bpsai_agent_lounge.channels import ChannelClient, ChannelObserver
from bpsai_agent_lounge.evidence import EvidenceMapper
from bpsai_agent_lounge.hypothesis import (
    VALID_TRANSITIONS,
    HypothesisLifecycle,
    HypothesisStatus,
    validate_transition,
)
from bpsai_agent_lounge.standup import StandupReporter

__all__ = [
    # hypothesis lifecycle
    "HypothesisLifecycle",
    "HypothesisStatus",
    "VALID_TRANSITIONS",
    "validate_transition",
    # channels
    "ChannelClient",
    "ChannelObserver",
    # beliefs
    "BeliefStore",
    # evidence
    "EvidenceMapper",
    # briefing
    "BriefingReader",
    # standup
    "StandupReporter",
]
