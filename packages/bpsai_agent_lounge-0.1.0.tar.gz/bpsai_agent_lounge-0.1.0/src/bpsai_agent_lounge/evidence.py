"""Evidence mapper protocol.

Defines the contract for transforming raw observations into
structured evidence for hypothesis evaluation.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class EvidenceMapper(Protocol):
    """Protocol for transforming raw observations into structured evidence."""

    def map_observation(
        self, observation: dict[str, Any],
    ) -> dict[str, Any]: ...
