"""Standup/reporting protocol.

Defines the contract for composing session summaries and pushing
briefing updates to the Lounge ecosystem.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class StandupReporter(Protocol):
    """Protocol for composing session summary and pushing briefings."""

    def compose_summary(self) -> dict[str, Any]: ...

    def push_briefing(self, summary: dict[str, Any]) -> None: ...
