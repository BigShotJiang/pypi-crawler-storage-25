"""Briefing reader protocol.

Defines the contract for loading the latest briefing on session startup.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class BriefingReader(Protocol):
    """Protocol for loading latest briefing on session startup."""

    def load_briefing(self) -> dict[str, Any] | None: ...
