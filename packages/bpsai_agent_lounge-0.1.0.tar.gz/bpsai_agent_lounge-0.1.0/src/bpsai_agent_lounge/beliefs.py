"""Belief store interface.

Defines the contract for reading and writing agent belief state
within the Lounge ecosystem.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class BeliefStore(Protocol):
    """Protocol for reading and writing belief state."""

    def read(self, key: str) -> Any: ...

    def write(self, key: str, value: Any) -> None: ...

    def keys(self) -> list[str]: ...

    def delete(self, key: str) -> None: ...
