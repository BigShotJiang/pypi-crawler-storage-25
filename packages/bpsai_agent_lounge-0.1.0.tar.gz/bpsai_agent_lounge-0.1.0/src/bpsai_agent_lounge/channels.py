"""Channel coordination protocols.

Defines the contracts for sending/receiving coordination messages
and subscribing to channel events in the Lounge ecosystem.
"""

from __future__ import annotations

from typing import Any, Callable, Protocol, runtime_checkable


@runtime_checkable
class ChannelClient(Protocol):
    """Protocol for sending and receiving coordination messages."""

    def send(self, channel: str, message: dict[str, Any]) -> None: ...

    def receive(self, channel: str) -> list[dict[str, Any]]: ...


@runtime_checkable
class ChannelObserver(Protocol):
    """Protocol for subscribing to channel events."""

    def subscribe(self, channel: str, callback: Callable[..., Any]) -> None: ...

    def unsubscribe(self, channel: str) -> None: ...
