"""Hypothesis lifecycle types and transition validation.

Extracted from bpsai-framework engine/hypothesis_types.py and
engine/hypothesis_backlog.py. Defines the state machine that governs
hypothesis progression: observed -> instrumented -> incubating -> actionable
(or closed from any state).
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Protocol, runtime_checkable


class HypothesisStatus(Enum):
    """Lifecycle states for a hypothesis."""

    OBSERVED = "observed"
    INSTRUMENTED = "instrumented"
    INCUBATING = "incubating"
    ACTIONABLE = "actionable"
    CLOSED = "closed"


# Valid forward transitions. Any non-closed state may also transition to CLOSED.
VALID_TRANSITIONS: dict[HypothesisStatus, set[HypothesisStatus]] = {
    HypothesisStatus.OBSERVED: {HypothesisStatus.INSTRUMENTED, HypothesisStatus.CLOSED},
    HypothesisStatus.INSTRUMENTED: {HypothesisStatus.INCUBATING, HypothesisStatus.CLOSED},
    HypothesisStatus.INCUBATING: {HypothesisStatus.ACTIONABLE, HypothesisStatus.CLOSED},
    HypothesisStatus.ACTIONABLE: {HypothesisStatus.CLOSED},
    HypothesisStatus.CLOSED: set(),
}


def validate_transition(
    from_status: HypothesisStatus,
    to_status: HypothesisStatus,
) -> bool:
    """Return True if transitioning from *from_status* to *to_status* is allowed."""
    return to_status in VALID_TRANSITIONS.get(from_status, set())


@runtime_checkable
class HypothesisLifecycle(Protocol):
    """Protocol for managing hypothesis lifecycle.

    Any agent participating in the Lounge ecosystem that tracks
    hypotheses must implement this interface.
    """

    def add(
        self, hypothesis_id: str, pattern: str, status: HypothesisStatus,
    ) -> None: ...

    def advance(
        self, hypothesis_id: str, new_status: HypothesisStatus,
    ) -> None: ...

    def close(self, hypothesis_id: str, reason: str) -> None: ...

    def update_confidence(
        self, hypothesis_id: str, confidence: float, evidence: dict[str, Any],
    ) -> None: ...

    def needs_reevaluation(self) -> list[str]: ...
