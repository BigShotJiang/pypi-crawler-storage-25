# bpsai-agent-lounge

Lounge coordination contracts for BPS AI agents — channels, beliefs, hypothesis lifecycle, evidence, briefings, and standups.

Provides the protocols and state machine that agents implement to participate in the Lounge ecosystem for multi-agent coordination.

## Installation

```bash
pip install bpsai-agent-lounge
```

## Quick Start

### Hypothesis Lifecycle

Manage hypothesis state progression (observed -> instrumented -> incubating -> actionable -> closed):

```python
from bpsai_agent_lounge import HypothesisStatus, validate_transition, VALID_TRANSITIONS

# Check valid transitions
assert validate_transition(HypothesisStatus.OBSERVED, HypothesisStatus.INSTRUMENTED)
assert validate_transition(HypothesisStatus.INCUBATING, HypothesisStatus.CLOSED)
assert not validate_transition(HypothesisStatus.OBSERVED, HypothesisStatus.ACTIONABLE)
```

Implement the `HypothesisLifecycle` protocol to manage hypotheses in your agent:

```python
from bpsai_agent_lounge import HypothesisLifecycle, HypothesisStatus


class MyHypothesisManager:
    """Implements HypothesisLifecycle protocol."""

    def __init__(self):
        self._hypotheses = {}

    def add(self, hypothesis_id, pattern, status):
        self._hypotheses[hypothesis_id] = {
            "pattern": pattern, "status": status, "confidence": 0.0,
        }

    def advance(self, hypothesis_id, new_status):
        h = self._hypotheses[hypothesis_id]
        if not validate_transition(h["status"], new_status):
            raise ValueError(f"Invalid: {h['status']} -> {new_status}")
        h["status"] = new_status

    def close(self, hypothesis_id, reason):
        self._hypotheses[hypothesis_id]["status"] = HypothesisStatus.CLOSED

    def update_confidence(self, hypothesis_id, confidence, evidence):
        self._hypotheses[hypothesis_id]["confidence"] = confidence

    def needs_reevaluation(self):
        return [hid for hid, h in self._hypotheses.items() if h["confidence"] < 0.5]


assert isinstance(MyHypothesisManager(), HypothesisLifecycle)
```

### Channel Coordination

Implement `ChannelClient` and `ChannelObserver` for inter-agent messaging:

```python
from bpsai_agent_lounge import ChannelClient, ChannelObserver


class MyChannelClient:
    """Implements ChannelClient protocol."""

    def __init__(self):
        self._channels: dict[str, list] = {}

    def send(self, channel, message):
        self._channels.setdefault(channel, []).append(message)

    def receive(self, channel):
        return self._channels.get(channel, [])


assert isinstance(MyChannelClient(), ChannelClient)
```

### Belief Store

Implement `BeliefStore` for shared agent belief state:

```python
from bpsai_agent_lounge import BeliefStore


class MyBeliefStore:
    """Implements BeliefStore protocol."""

    def __init__(self):
        self._data = {}

    def read(self, key):
        return self._data.get(key)

    def write(self, key, value):
        self._data[key] = value

    def keys(self):
        return list(self._data.keys())

    def delete(self, key):
        self._data.pop(key, None)


assert isinstance(MyBeliefStore(), BeliefStore)
```

### Evidence, Briefings, and Standups

Additional protocols for domain-specific coordination:

```python
from bpsai_agent_lounge import EvidenceMapper, BriefingReader, StandupReporter

# EvidenceMapper — maps raw observations into typed evidence
# BriefingReader — loads briefing documents for agents
# StandupReporter — composes summaries and pushes briefings
```

## API Reference

| Export | Kind | Purpose |
|--------|------|---------|
| `HypothesisStatus` | Enum | Lifecycle states (OBSERVED, INSTRUMENTED, INCUBATING, ACTIONABLE, CLOSED) |
| `VALID_TRANSITIONS` | Dict | Allowed state transitions |
| `validate_transition` | Function | Check if a transition is valid |
| `HypothesisLifecycle` | Protocol | Full hypothesis management interface |
| `ChannelClient` | Protocol | Send/receive coordination messages |
| `ChannelObserver` | Protocol | Subscribe/unsubscribe to channel events |
| `BeliefStore` | Protocol | Read/write shared belief state |
| `EvidenceMapper` | Protocol | Map observations to typed evidence |
| `BriefingReader` | Protocol | Load briefing documents |
| `StandupReporter` | Protocol | Compose summaries and push briefings |

## Requirements

- Python >= 3.11
- `bpsai-agent-core >= 0.1.0`

## License

Proprietary - BPS AI Software
