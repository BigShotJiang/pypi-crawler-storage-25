# SovereignBox

**Local-first, encrypted AI memory and identity standard.**

SovereignBox lets you own your AI conversation context — stored locally in an encrypted vault, portable across AI systems, and fully under your control.

## Features

- 🔐 **Encrypted vault** — Scrypt KDF + Fernet (AES-128-CBC + HMAC-SHA256)
- 📋 **Typed schema** — Pydantic v2 models for Identity, Preferences, and History
- 🔄 **Portable** — JSON export/import across any AI system
- 💻 **CLI** — Full command-line interface
- 🐍 **Python API** — Embeddable in any Python application

## Installation

```bash
pip install sovereignbox
```

## Quick Start

```bash
export SOVEREIGNBOX_PASSPHRASE=mysecretpassphrase

sovereignbox init
sovereignbox set-name "Alice"
sovereignbox set-style --verbosity detailed --tone professional
sovereignbox history add --system openai --summary "Discussed Python async patterns"
sovereignbox history list
sovereignbox info
sovereignbox export ./backup.json
```

## Python API

```python
from sovereignbox import PassportStore, Vault
from sovereignbox.schema.history import Session

vault = Vault("~/.sovereignbox/vault.db", passphrase="secret")
store = PassportStore(vault)

passport = store.load_or_create()
passport.identity.personal_info.display_name = "Alice"
session = Session(system_id="openai", summary="Chat about Python")
passport.history.add_session(session)
store.save(passport)
```

## Schema

- `DataPassport` — root document
  - `Identity` — who you are (name, email, AI personas, trust levels)
  - `Preferences` — how you like AI to respond (verbosity, tone, topics)
  - `InteractionHistory` — sessions and messages across AI systems

## Environment Variables

| Variable | Default | Notes |
|---|---|---|
| `SOVEREIGNBOX_VAULT` | `~/.sovereignbox/vault.db` | Override vault path |
| `SOVEREIGNBOX_PASSPHRASE` | *(interactive prompt)* | Set in scripts/CI |

## License

Apache 2.0
