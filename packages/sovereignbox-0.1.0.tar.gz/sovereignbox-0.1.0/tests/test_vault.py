import pytest
import tempfile
from pathlib import Path
from sovereignbox.vault.storage import Vault
from sovereignbox.vault.passport_store import PassportStore
from sovereignbox.schema.passport import DataPassport


@pytest.fixture
def vault(tmp_path):
    return Vault(tmp_path / "test.db", "testpass")


def test_put_get(vault):
    vault.put("ns", "key1", "value1")
    assert vault.get("ns", "key1") == "value1"


def test_get_missing(vault):
    assert vault.get("ns", "nonexistent") is None


def test_put_overwrite(vault):
    vault.put("ns", "k", "v1")
    vault.put("ns", "k", "v2")
    assert vault.get("ns", "k") == "v2"


def test_delete(vault):
    vault.put("ns", "k", "v")
    assert vault.delete("ns", "k") is True
    assert vault.get("ns", "k") is None


def test_delete_missing(vault):
    assert vault.delete("ns", "no_such_key") is False


def test_list_keys(vault):
    vault.put("ns", "a", "1")
    vault.put("ns", "b", "2")
    vault.put("other", "c", "3")
    keys = vault.list_keys("ns")
    assert sorted(keys) == ["a", "b"]


def test_exists(vault):
    assert vault.exists("ns", "k") is False
    vault.put("ns", "k", "v")
    assert vault.exists("ns", "k") is True


def test_namespace_isolation(vault):
    vault.put("ns1", "key", "v1")
    vault.put("ns2", "key", "v2")
    assert vault.get("ns1", "key") == "v1"
    assert vault.get("ns2", "key") == "v2"


@pytest.fixture
def store(tmp_path):
    vault = Vault(tmp_path / "store.db", "pass123")
    return PassportStore(vault)


def test_store_load_or_create(store):
    p = store.load_or_create()
    assert isinstance(p, DataPassport)


def test_store_save_load(store):
    p = DataPassport()
    p.identity.personal_info.display_name = "Alice"
    store.save(p)
    loaded = store.load()
    assert loaded is not None
    assert loaded.identity.personal_info.display_name == "Alice"


def test_store_load_none(store):
    assert store.load() is None


def test_store_exists(store):
    assert not store.exists()
    store.load_or_create()
    assert store.exists()


def test_store_delete(store):
    store.load_or_create()
    assert store.delete() is True
    assert store.load() is None


def test_store_multiple_slots(store):
    p1 = DataPassport()
    p1.identity.personal_info.display_name = "Alice"
    p2 = DataPassport()
    p2.identity.personal_info.display_name = "Bob"
    store.save(p1, slot="alice")
    store.save(p2, slot="bob")
    assert store.load("alice").identity.personal_info.display_name == "Alice"
    assert store.load("bob").identity.personal_info.display_name == "Bob"
    assert sorted(store.list_slots()) == ["alice", "bob"]
