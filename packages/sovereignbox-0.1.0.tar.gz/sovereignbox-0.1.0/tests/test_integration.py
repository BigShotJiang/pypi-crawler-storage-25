import pytest
import json
from pathlib import Path
from sovereignbox.vault.storage import Vault
from sovereignbox.vault.passport_store import PassportStore
from sovereignbox.schema.passport import DataPassport
from sovereignbox.schema.history import Session


def test_full_lifecycle(tmp_path):
    vault = Vault(tmp_path / "vault.db", "integration-secret")
    store = PassportStore(vault)

    passport = store.load_or_create()
    passport.identity.personal_info.display_name = "Integration User"
    passport.preferences.response_style.verbosity = "detailed"
    session = Session(system_id="openai", summary="First session")
    passport.history.add_session(session)
    store.save(passport)

    vault2 = Vault(tmp_path / "vault.db", "integration-secret")
    store2 = PassportStore(vault2)
    loaded = store2.load()
    assert loaded is not None
    assert loaded.identity.personal_info.display_name == "Integration User"
    assert loaded.preferences.response_style.verbosity == "detailed"
    assert len(loaded.history.sessions) == 1
    assert loaded.history.sessions[0].summary == "First session"


def test_export_import(tmp_path):
    vault = Vault(tmp_path / "vault.db", "pass")
    store = PassportStore(vault)
    p = store.load_or_create()
    p.identity.personal_info.display_name = "Exported User"
    store.save(p)

    export_file = tmp_path / "export.json"
    export_file.write_text(store.load().to_json())

    vault2 = Vault(tmp_path / "vault2.db", "different-pass")
    store2 = PassportStore(vault2)
    p2 = DataPassport.from_json(export_file.read_text())
    store2.save(p2)
    loaded = store2.load()
    assert loaded.identity.personal_info.display_name == "Exported User"
