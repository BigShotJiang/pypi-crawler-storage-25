import pytest
from sovereignbox.schema.identity import Identity, PersonalInfo, AIPersona, TrustLevel
from sovereignbox.schema.preferences import Preferences, ResponseStyle, TopicPreference
from sovereignbox.schema.history import InteractionHistory, Session, Message, MessageRole
from sovereignbox.schema.passport import DataPassport


def test_identity_defaults():
    i = Identity()
    assert i.id
    assert i.personal_info.locale == "en-US"


def test_identity_personal_info():
    i = Identity(personal_info=PersonalInfo(display_name="Alice"))
    assert i.personal_info.display_name == "Alice"


def test_trust_level_enum():
    assert TrustLevel.high == "high"


def test_ai_persona():
    p = AIPersona(name="GPT-4", system_id="openai", trust_level=TrustLevel.verified)
    assert p.trust_level == TrustLevel.verified


def test_preferences_defaults():
    p = Preferences()
    assert p.response_style.verbosity == "balanced"
    assert p.preferred_languages == ["en"]


def test_topic_preference():
    p = Preferences(topic_preferences={"python": TopicPreference.like})
    assert p.topic_preferences["python"] == "like"


def test_message_role_enum():
    assert MessageRole.user == "user"
    m = Message(role=MessageRole.user, content="hello")
    assert m.content == "hello"


def test_session_add_messages():
    s = Session(system_id="openai")
    s.messages.append(Message(role=MessageRole.user, content="hi"))
    assert len(s.messages) == 1


def test_interaction_history_add_session():
    h = InteractionHistory()
    s = Session(system_id="openai", summary="test")
    h.add_session(s)
    assert len(h.sessions) == 1


def test_interaction_history_recent():
    h = InteractionHistory()
    for i in range(5):
        h.add_session(Session(system_id="openai", summary=f"s{i}"))
    assert len(h.recent(3)) == 3


def test_interaction_history_max_sessions():
    h = InteractionHistory(max_sessions=5)
    for i in range(10):
        h.add_session(Session(system_id="test", summary=f"s{i}"))
    assert len(h.sessions) == 5


def test_data_passport_defaults():
    p = DataPassport()
    assert p.schema_version == "1.0.0"
    assert p.identity is not None


def test_data_passport_json_roundtrip():
    p = DataPassport()
    p.identity.personal_info.display_name = "Bob"
    json_str = p.to_json()
    p2 = DataPassport.from_json(json_str)
    assert p2.identity.personal_info.display_name == "Bob"


def test_data_passport_touch():
    p = DataPassport()
    old = p.updated_at
    import time; time.sleep(0.01)
    p.touch()
    assert p.updated_at >= old
