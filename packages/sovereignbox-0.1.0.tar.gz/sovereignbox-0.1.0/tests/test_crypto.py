import pytest
from sovereignbox.vault.crypto import VaultCrypto, CryptoError


def test_encrypt_decrypt_roundtrip():
    c = VaultCrypto("secret")
    blob = c.encrypt("hello world")
    assert c.decrypt(blob) == "hello world"


def test_different_salts():
    c = VaultCrypto("secret")
    b1 = c.encrypt("msg")
    b2 = c.encrypt("msg")
    assert b1 != b2


def test_wrong_passphrase():
    c1 = VaultCrypto("correct")
    c2 = VaultCrypto("wrong")
    blob = c1.encrypt("secret data")
    with pytest.raises(CryptoError):
        c2.decrypt(blob)


def test_empty_passphrase_raises():
    with pytest.raises(CryptoError):
        VaultCrypto("")


def test_corrupted_ciphertext():
    c = VaultCrypto("secret")
    blob = c.encrypt("data")
    corrupted = blob[:-5] + b"\x00\x00\x00\x00\x00"
    with pytest.raises(CryptoError):
        c.decrypt(corrupted)


def test_too_short_ciphertext():
    c = VaultCrypto("secret")
    with pytest.raises(CryptoError):
        c.decrypt(b"\x00" * 10)


def test_unicode_payload():
    c = VaultCrypto("passphrase")
    payload = "こんにちは 🔒"
    assert c.decrypt(c.encrypt(payload)) == payload


def test_large_payload():
    c = VaultCrypto("passphrase")
    big = "x" * 100_000
    assert c.decrypt(c.encrypt(big)) == big
