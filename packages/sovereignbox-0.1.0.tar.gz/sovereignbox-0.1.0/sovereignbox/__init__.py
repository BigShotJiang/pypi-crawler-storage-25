"""SovereignBox — local-first, encrypted AI memory and identity standard."""

__version__ = "0.1.0"
__author__ = "SovereignBox Contributors"
__license__ = "Apache-2.0"

from sovereignbox.schema.passport import DataPassport
from sovereignbox.schema.identity import Identity, PersonalInfo, AIPersona, TrustLevel
from sovereignbox.schema.preferences import Preferences, ResponseStyle, TopicPreference
from sovereignbox.schema.history import InteractionHistory, Session, Message, MessageRole
from sovereignbox.vault.crypto import VaultCrypto, CryptoError
from sovereignbox.vault.storage import Vault
from sovereignbox.vault.passport_store import PassportStore

__all__ = [
    "__version__",
    "DataPassport",
    "Identity",
    "PersonalInfo",
    "AIPersona",
    "TrustLevel",
    "Preferences",
    "ResponseStyle",
    "TopicPreference",
    "InteractionHistory",
    "Session",
    "Message",
    "MessageRole",
    "VaultCrypto",
    "CryptoError",
    "Vault",
    "PassportStore",
]
