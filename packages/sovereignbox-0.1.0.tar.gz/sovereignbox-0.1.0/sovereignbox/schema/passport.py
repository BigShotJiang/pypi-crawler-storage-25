from __future__ import annotations
from typing import Optional
from pydantic import BaseModel, Field
from datetime import datetime
from sovereignbox.schema.identity import Identity
from sovereignbox.schema.preferences import Preferences
from sovereignbox.schema.history import InteractionHistory


class DataPassport(BaseModel):
    schema_version: str = "1.0.0"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    identity: Identity = Field(default_factory=Identity)
    preferences: Preferences = Field(default_factory=Preferences)
    history: InteractionHistory = Field(default_factory=InteractionHistory)

    def touch(self) -> None:
        self.updated_at = datetime.utcnow()
        self.identity.update()

    def to_json(self) -> str:
        return self.model_dump_json(indent=2)

    @classmethod
    def from_json(cls, data: str) -> "DataPassport":
        return cls.model_validate_json(data)
