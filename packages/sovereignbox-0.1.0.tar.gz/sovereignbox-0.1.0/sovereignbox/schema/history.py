from __future__ import annotations
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field
import uuid
from datetime import datetime


class MessageRole(str, Enum):
    user = "user"
    assistant = "assistant"
    system = "system"


class Message(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    tokens: Optional[int] = None


class Session(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    system_id: str
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = None
    summary: Optional[str] = None
    messages: List[Message] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)


class InteractionHistory(BaseModel):
    sessions: List[Session] = Field(default_factory=list)
    max_sessions: int = 500

    def add_session(self, session: Session) -> None:
        self.sessions.append(session)
        if len(self.sessions) > self.max_sessions:
            self.sessions = self.sessions[-self.max_sessions:]

    def recent(self, n: int = 10) -> List[Session]:
        return self.sessions[-n:]
