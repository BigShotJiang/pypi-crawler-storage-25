from __future__ import annotations
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field
import uuid
from datetime import datetime


class TrustLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"
    verified = "verified"


class PersonalInfo(BaseModel):
    display_name: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None
    locale: str = "en-US"
    timezone: Optional[str] = None


class AIPersona(BaseModel):
    name: str
    system_id: str
    trust_level: TrustLevel = TrustLevel.medium
    notes: Optional[str] = None


class Identity(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    personal_info: PersonalInfo = Field(default_factory=PersonalInfo)
    ai_personas: List[AIPersona] = Field(default_factory=list)

    def update(self) -> None:
        self.updated_at = datetime.utcnow()
