from __future__ import annotations
from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field


class TopicPreference(str, Enum):
    like = "like"
    dislike = "dislike"
    neutral = "neutral"


class ResponseStyle(BaseModel):
    verbosity: str = "balanced"
    tone: str = "professional"
    use_markdown: bool = True
    use_code_blocks: bool = True
    max_response_length: Optional[int] = None


class Preferences(BaseModel):
    response_style: ResponseStyle = Field(default_factory=ResponseStyle)
    topic_preferences: dict[str, TopicPreference] = Field(default_factory=dict)
    preferred_languages: List[str] = Field(default_factory=lambda: ["en"])
    custom: dict = Field(default_factory=dict)
