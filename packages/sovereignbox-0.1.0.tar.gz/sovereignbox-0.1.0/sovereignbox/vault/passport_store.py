from __future__ import annotations
from pathlib import Path
from typing import Optional
from sovereignbox.vault.storage import Vault
from sovereignbox.schema.passport import DataPassport

_NAMESPACE = "passport"
_DEFAULT_SLOT = "default"


class PassportStore:
    def __init__(self, vault: Vault) -> None:
        self._vault = vault

    def save(self, passport: DataPassport, slot: str = _DEFAULT_SLOT) -> None:
        passport.touch()
        self._vault.put(_NAMESPACE, slot, passport.to_json())

    def load(self, slot: str = _DEFAULT_SLOT) -> Optional[DataPassport]:
        data = self._vault.get(_NAMESPACE, slot)
        if data is None:
            return None
        return DataPassport.from_json(data)

    def load_or_create(self, slot: str = _DEFAULT_SLOT) -> DataPassport:
        passport = self.load(slot)
        if passport is None:
            passport = DataPassport()
            self.save(passport, slot)
        return passport

    def delete(self, slot: str = _DEFAULT_SLOT) -> bool:
        return self._vault.delete(_NAMESPACE, slot)

    def list_slots(self) -> list[str]:
        return self._vault.list_keys(_NAMESPACE)

    def exists(self, slot: str = _DEFAULT_SLOT) -> bool:
        return self._vault.exists(_NAMESPACE, slot)
