from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Optional, List, Tuple
from sovereignbox.vault.crypto import VaultCrypto, CryptoError


class Vault:
    def __init__(self, db_path: str | Path, passphrase: str) -> None:
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._crypto = VaultCrypto(passphrase)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self._path)

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS vault_records (
                    namespace TEXT NOT NULL,
                    record_id TEXT NOT NULL,
                    data BLOB NOT NULL,
                    PRIMARY KEY (namespace, record_id)
                )
                """
            )

    def put(self, namespace: str, record_id: str, value: str) -> None:
        blob = self._crypto.encrypt(value)
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO vault_records (namespace, record_id, data) VALUES (?, ?, ?)",
                (namespace, record_id, blob),
            )

    def get(self, namespace: str, record_id: str) -> Optional[str]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT data FROM vault_records WHERE namespace=? AND record_id=?",
                (namespace, record_id),
            ).fetchone()
        if row is None:
            return None
        return self._crypto.decrypt(bytes(row[0]))

    def delete(self, namespace: str, record_id: str) -> bool:
        with self._conn() as conn:
            cur = conn.execute(
                "DELETE FROM vault_records WHERE namespace=? AND record_id=?",
                (namespace, record_id),
            )
            return cur.rowcount > 0

    def list_keys(self, namespace: str) -> List[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT record_id FROM vault_records WHERE namespace=? ORDER BY record_id",
                (namespace,),
            ).fetchall()
        return [r[0] for r in rows]

    def exists(self, namespace: str, record_id: str) -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT 1 FROM vault_records WHERE namespace=? AND record_id=?",
                (namespace, record_id),
            ).fetchone()
        return row is not None
