from __future__ import annotations
import os
import base64
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet, InvalidToken


SCRYPT_N = 2 ** 14
SCRYPT_R = 8
SCRYPT_P = 1
SALT_LENGTH = 32
KEY_LENGTH = 32


class CryptoError(Exception):
    pass


class VaultCrypto:
    def __init__(self, passphrase: str) -> None:
        if not passphrase:
            raise CryptoError("Passphrase must not be empty")
        self._passphrase = passphrase.encode()

    def _derive_key(self, salt: bytes) -> bytes:
        kdf = Scrypt(
            salt=salt,
            length=KEY_LENGTH,
            n=SCRYPT_N,
            r=SCRYPT_R,
            p=SCRYPT_P,
            backend=default_backend(),
        )
        raw = kdf.derive(self._passphrase)
        return base64.urlsafe_b64encode(raw)

    def encrypt(self, plaintext: str) -> bytes:
        salt = os.urandom(SALT_LENGTH)
        key = self._derive_key(salt)
        token = Fernet(key).encrypt(plaintext.encode())
        return salt + token

    def decrypt(self, ciphertext: bytes) -> str:
        if len(ciphertext) < SALT_LENGTH:
            raise CryptoError("Ciphertext too short")
        salt, token = ciphertext[:SALT_LENGTH], ciphertext[SALT_LENGTH:]
        key = self._derive_key(salt)
        try:
            return Fernet(key).decrypt(token).decode()
        except InvalidToken as exc:
            raise CryptoError("Decryption failed — wrong passphrase or corrupted data") from exc
