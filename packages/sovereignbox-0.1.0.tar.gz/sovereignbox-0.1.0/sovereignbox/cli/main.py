from __future__ import annotations
import os
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from sovereignbox.vault.storage import Vault
from sovereignbox.vault.passport_store import PassportStore
from sovereignbox.schema.identity import AIPersona, TrustLevel
from sovereignbox.schema.history import Session, Message, MessageRole

console = Console()

_DEFAULT_VAULT = Path.home() / ".sovereignbox" / "vault.db"


def _get_store(vault_path: str, passphrase: str) -> PassportStore:
    vault = Vault(vault_path, passphrase)
    return PassportStore(vault)


def _passphrase_option(ctx: click.Context, param: click.Parameter, value: Optional[str]) -> str:
    if value:
        return value
    env = os.environ.get("SOVEREIGNBOX_PASSPHRASE")
    if env:
        return env
    return click.prompt("Passphrase", hide_input=True)


@click.group()
@click.version_option(package_name="sovereignbox")
@click.option(
    "--vault",
    default=str(_DEFAULT_VAULT),
    envvar="SOVEREIGNBOX_VAULT",
    show_default=True,
    help="Path to vault database file.",
)
@click.option(
    "--passphrase",
    default=None,
    envvar="SOVEREIGNBOX_PASSPHRASE",
    callback=_passphrase_option,
    is_eager=False,
    expose_value=True,
    help="Vault passphrase (or set SOVEREIGNBOX_PASSPHRASE env var).",
)
@click.pass_context
def cli(ctx: click.Context, vault: str, passphrase: str) -> None:
    """SovereignBox — local-first, encrypted AI memory and identity."""
    ctx.ensure_object(dict)
    ctx.obj["vault"] = vault
    ctx.obj["passphrase"] = passphrase


@cli.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialise a new passport in the vault."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    if store.exists():
        console.print("[yellow]Passport already exists.[/yellow]")
        return
    store.load_or_create()
    console.print("[green]✓ Passport initialised.[/green]")


@cli.command()
@click.pass_context
def info(ctx: click.Context) -> None:
    """Display passport summary."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load()
    if passport is None:
        console.print("[red]No passport found. Run `sovereignbox init` first.[/red]")
        sys.exit(1)
    t = Table(title="SovereignBox Passport")
    t.add_column("Field", style="cyan")
    t.add_column("Value")
    t.add_row("Schema version", passport.schema_version)
    t.add_row("Identity ID", passport.identity.id)
    t.add_row("Display name", passport.identity.personal_info.display_name or "—")
    t.add_row("Created", str(passport.created_at)[:19])
    t.add_row("Updated", str(passport.updated_at)[:19])
    t.add_row("Sessions", str(len(passport.history.sessions)))
    console.print(t)


@cli.command("set-name")
@click.argument("name")
@click.pass_context
def set_name(ctx: click.Context, name: str) -> None:
    """Set display name on the passport."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load_or_create()
    passport.identity.personal_info.display_name = name
    store.save(passport)
    console.print(f"[green]✓ Display name set to '{name}'.[/green]")


@cli.command("set-style")
@click.option("--verbosity", type=click.Choice(["concise", "balanced", "detailed"]), default=None)
@click.option("--tone", type=click.Choice(["casual", "professional", "technical"]), default=None)
@click.option("--no-markdown", is_flag=True, default=False)
@click.pass_context
def set_style(ctx: click.Context, verbosity: Optional[str], tone: Optional[str], no_markdown: bool) -> None:
    """Update response style preferences."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load_or_create()
    style = passport.preferences.response_style
    if verbosity:
        style.verbosity = verbosity
    if tone:
        style.tone = tone
    if no_markdown:
        style.use_markdown = False
    store.save(passport)
    console.print("[green]✓ Response style updated.[/green]")


@cli.group()
def history() -> None:
    """Manage interaction history."""


@history.command("add")
@click.option("--system", required=True, help="AI system identifier (e.g. openai).")
@click.option("--summary", required=True, help="Session summary.")
@click.option("--tags", default="", help="Comma-separated tags.")
@click.pass_context
def history_add(ctx: click.Context, system: str, summary: str, tags: str) -> None:
    """Add a session to interaction history."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load_or_create()
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    session = Session(system_id=system, summary=summary, tags=tag_list)
    passport.history.add_session(session)
    store.save(passport)
    console.print(f"[green]✓ Session added (ID: {session.id[:8]}…).[/green]")


@history.command("list")
@click.option("--n", default=10, show_default=True, help="Number of recent sessions.")
@click.pass_context
def history_list(ctx: click.Context, n: int) -> None:
    """List recent interaction sessions."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load()
    if passport is None:
        console.print("[red]No passport found.[/red]")
        sys.exit(1)
    sessions = passport.history.recent(n)
    if not sessions:
        console.print("No sessions recorded.")
        return
    t = Table(title=f"Last {n} Sessions")
    t.add_column("ID", style="dim")
    t.add_column("System")
    t.add_column("Summary")
    t.add_column("Tags")
    t.add_column("Started")
    for s in sessions:
        t.add_row(
            s.id[:8] + "…",
            s.system_id,
            (s.summary or "")[:60],
            ", ".join(s.tags),
            str(s.started_at)[:19],
        )
    console.print(t)


@cli.command("export")
@click.argument("output_path")
@click.pass_context
def export_cmd(ctx: click.Context, output_path: str) -> None:
    """Export passport to a JSON file."""
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    passport = store.load()
    if passport is None:
        console.print("[red]No passport found.[/red]")
        sys.exit(1)
    Path(output_path).write_text(passport.to_json())
    console.print(f"[green]✓ Exported to {output_path}[/green]")


@cli.command("import")
@click.argument("input_path")
@click.pass_context
def import_cmd(ctx: click.Context, input_path: str) -> None:
    """Import passport from a JSON file."""
    from sovereignbox.schema.passport import DataPassport
    store = _get_store(ctx.obj["vault"], ctx.obj["passphrase"])
    data = Path(input_path).read_text()
    passport = DataPassport.from_json(data)
    store.save(passport)
    console.print(f"[green]✓ Imported passport (ID: {passport.identity.id[:8]}…).[/green]")
