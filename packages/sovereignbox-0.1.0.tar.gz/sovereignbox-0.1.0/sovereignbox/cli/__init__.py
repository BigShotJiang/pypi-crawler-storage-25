from sovereignbox.cli.main import cli

__all__ = ["cli"]
