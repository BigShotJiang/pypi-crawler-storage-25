# Contributing to SovereignBox

We welcome contributions! Please open an issue or pull request on GitHub.

## Development Setup

```bash
git clone https://github.com/sovereignbox/sovereignbox
cd sovereignbox
pip install -e ".[dev]"
pytest tests/ -v
```
