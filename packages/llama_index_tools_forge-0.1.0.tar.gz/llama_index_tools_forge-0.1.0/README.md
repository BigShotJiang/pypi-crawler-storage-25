# llama-index-tools-forge

Forge Verify tools for [LlamaIndex](https://github.com/run-llama/llama_index). Verify every AI agent action against your policies **before** execution.

## Install

```bash
pip install llama-index-tools-forge
```

## Quick Start

```python
import os
from llama_index.core.agent import FunctionAgent
from llama_index.core.tools import FunctionTool
from llama_index.llms.openai import OpenAI
from forge_llamaindex import ForgeVerifyToolSpec

os.environ["VERITERA_API_KEY"] = "vt_live_..."

# Create Forge verification tools
forge = ForgeVerifyToolSpec(policy="finance-controls")
forge_tools = forge.to_tool_list()

# Your application tools
def send_payment(amount: float, recipient: str) -> str:
    """Send a payment to a recipient."""
    return f"Sent ${amount} to {recipient}"

app_tools = [FunctionTool.from_defaults(fn=send_payment)]

# Create agent with all tools
agent = FunctionAgent(
    tools=forge_tools + app_tools,
    llm=OpenAI(model="gpt-4.1"),
    system_prompt=(
        "Before executing any sensitive action, ALWAYS call verify_action first. "
        "Only proceed if the result is APPROVED."
    ),
)

response = await agent.run("Send $500 to vendor@acme.com")
```

## Two Integration Points

### 1. Tool Spec — agent calls verify explicitly

```python
from forge_llamaindex import ForgeVerifyToolSpec

spec = ForgeVerifyToolSpec(policy="finance-controls")
tools = spec.to_tool_list()
# Provides: verify_action, get_proof, check_health
```

### 2. Event Handler — automatic audit trail

```python
from forge_llamaindex import ForgeEventHandler
import llama_index.core.instrumentation as instrument

handler = ForgeEventHandler(
    policy="finance-controls",
    block_on_deny=True,  # raise exception on denied actions
)
dispatcher = instrument.get_dispatcher()
dispatcher.add_event_handler(handler)
```

The event handler intercepts all agent tool calls and verifies them through Forge automatically.

## Configuration

```python
spec = ForgeVerifyToolSpec(
    api_key="vt_live_...",           # or VERITERA_API_KEY env var
    agent_id="prod-rag-agent",
    policy="finance-controls",
    fail_closed=True,                # deny when API is unreachable
)
```

## LlamaHub

This package follows the `llama-index-tools-*` naming convention and can be submitted to [LlamaHub](https://llamahub.ai) for discovery.

## License

MIT — [Veritera AI](https://veritera.ai)
