# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from __future__ import annotations

import queue
import threading
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from loguru import logger

from metrana.renderer.encoder import Encoder
from metrana.utils import logging as metrana_logging
from metrana.utils.enums import BackpressureStrategy, CloseStrategy
from metrana.utils.error_sink import ErrorSink
from metrana.utils.exceptions import (
    MetranaEventQueueFullError,
    UnrecognizedMetranaBackpressureStrategyError,
)

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

_RENDERING_SUBDIR = "renderings"

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


@dataclass(frozen=True)
class _RenderEvent:
    """
    Event sent from log_rendering callers to the rendering dispatcher's consumer thread.
    """

    frame: np.ndarray
    rl_step: int
    episode: int
    env_id: str | None


class RenderingDispatcher:
    """
    Bounded queue + dedicated consumer thread that encodes frames to per-episode
    H.264 video files.

    The consumer thread owns a dict of currently-open Encoders keyed by env_id and
    routes incoming frames to the correct encoder, opening a new one when the
    (env_id, episode) pair changes and closing the previous one. Concurrent open
    encoders are capped by max_concurrent_encoders — frames for env_ids beyond the
    cap are subject to the configured backpressure strategy at enqueue time.

    PyAV is imported lazily by the Encoder; an ImportError on first encoder open is
    surfaced via the error queue so the training thread is never blocked by a missing
    optional dependency.
    """

    _SHUTDOWN_SENTINEL: object = object()
    _CONSUME_GET_TIMEOUT = 0.5

    def __init__(
        self,
        output_dir: str | Path | None,
        run_name: str,
        fps: int,
        max_concurrent_encoders: int,
        queue_max_size: int | None,
        backpressure_strategy: BackpressureStrategy,
        close_strategy: CloseStrategy,
        error_sink: ErrorSink,
        max_event_queue_timeout: float,
    ) -> None:
        """
        Initialize the dispatcher and start the consumer thread.

        Args:
            output_dir: Base directory under which run-scoped subdirs are created.
                If None, defaults to ~/.metrana/renderings.
            run_name: Name of the current run, used as the subdirectory under
                output_dir to keep different runs' renderings separate.
            fps: Frames per second to encode at. Locked at construction time and
                applied to every encoder spawned by this dispatcher.
            max_concurrent_encoders: Maximum number of open encoders at any one time.
                Frames for new env_ids beyond this cap are dropped/blocked/raised
                according to backpressure_strategy. Defaults to 1.
            queue_max_size: Maximum number of pending frames in the bounded queue.
                None or 0 means unbounded.
            backpressure_strategy: Strategy applied when the frame queue is full
                (Block, DropNew, or Raise).
            close_strategy: Shutdown strategy applied to the rendering pipeline,
                independent of the metric pipeline's close strategy. Immediate drops
                queued frames; CompletePending and CompleteAll both drain the queue
                fully (CompletePending is treated as CompleteAll because there is no
                separate "in-flight request" notion for video — a warn-once is emitted
                if CompletePending is selected).
            error_sink: Shared error sink for surfacing errors; matches the
                metric pipeline's sink so error_strategy applies uniformly.
            max_event_queue_timeout: Timeout in seconds for blocking enqueue when the
                strategy is Block.
        """

        if max_concurrent_encoders < 1:
            raise ValueError(f"max_concurrent_encoders must be >= 1, got {max_concurrent_encoders}.")

        if output_dir is None:
            base_dir = Path.home() / ".metrana" / _RENDERING_SUBDIR
        else:
            base_dir = Path(output_dir).expanduser()

        self._run_output_dir = base_dir / run_name
        self._fps = fps
        self._max_concurrent_encoders = max_concurrent_encoders
        self._backpressure_strategy = backpressure_strategy
        self._close_strategy = close_strategy
        self._error_sink = error_sink
        self._max_event_queue_timeout = max_event_queue_timeout
        self._drain_on_exit = True

        maxsize = queue_max_size if queue_max_size is not None else 0
        self._queue: queue.Queue = queue.Queue(maxsize=maxsize)
        self._encoders: dict[str | None, Encoder] = {}
        self._accept_new_events = True
        self._stopped = False

        self._thread = threading.Thread(
            target=self._consume_loop,
            name="metrana-renderer",
            daemon=True,
        )
        self._thread.start()

    @property
    def run_output_dir(self) -> Path:
        """Directory under which this run's rendering files are written."""

        return self._run_output_dir

    def _output_path_for(self, env_id: str | None, episode: int) -> Path:
        """
        Build the output path for a given (env_id, episode) pair.

        Args:
            env_id: Environment identifier; None becomes "default".
            episode: Episode index.

        Returns:
            Path to the .mp4 file for this encoder.
        """

        env_segment = env_id if env_id is not None else "default"
        return self._run_output_dir / f"{env_segment}_{episode}.mp4"

    def _close_encoder(self, env_id: str | None) -> None:
        """
        Close the encoder for the given env_id (if any) and remove it from the registry.

        Args:
            env_id: Environment identifier whose encoder should be closed.
        """

        encoder = self._encoders.pop(env_id, None)
        if encoder is None:
            return

        try:
            encoder.close()
        except Exception as e:
            logger.warning(f"Error closing rendering encoder for env_id={env_id}: {e}")
            self._report_error(e)
        else:
            logger.debug(
                f"Closed rendering for env_id={env_id} episode={encoder.episode} "
                f"frames={encoder.frame_count} path={encoder.output_path}"
            )

    def _open_encoder(self, env_id: str | None, episode: int, rl_step: int) -> Encoder | None:
        """
        Open a new encoder for the given env_id at the given episode.

        Args:
            env_id: Environment identifier.
            episode: Episode index for the new encoder.
            rl_step: RL step at which the encoder is being opened.

        Returns:
            The newly opened Encoder, or None if construction failed (the error is
            forwarded to the error queue and a warning logged).
        """

        output_path = self._output_path_for(env_id, episode)

        try:
            encoder = Encoder(
                output_path=output_path,
                fps=self._fps,
                env_id=env_id,
                episode=episode,
                rl_step=rl_step,
            )
        except ImportError as e:
            metrana_logging.warn_once(
                str(e),
                key="rendering_pyav_missing",
            )
            self._report_error(e)
            return None
        except Exception as e:
            logger.warning(f"Failed to open rendering encoder for env_id={env_id} episode={episode}: {e}")
            self._report_error(e)
            return None

        self._encoders[env_id] = encoder
        logger.debug(f"Opened rendering for env_id={env_id} episode={episode} path={output_path}")
        return encoder

    def _report_error(self, error: Exception) -> None:
        """
        Forward an error to the shared error sink, mirroring the metric pipeline's
        behaviour. The sink applies the configured ErrorStrategy and handles any
        queue-full conditions internally.

        Args:
            error: Exception to report.
        """

        self._error_sink.report(error, warn_key=f"rendering_error_{type(error).__name__}")

    def _handle_event(self, event: _RenderEvent) -> None:
        """
        Route a single render event to the correct encoder, opening or rolling encoders
        as needed. Errors during write are reported to the error queue and the encoder
        is closed defensively.

        Args:
            event: Event drained from the queue.
        """

        env_id = event.env_id
        existing = self._encoders.get(env_id)

        if existing is not None and existing.episode != event.episode:
            self._close_encoder(env_id)
            existing = None

        if existing is None:
            if env_id not in self._encoders and len(self._encoders) >= self._max_concurrent_encoders:
                metrana_logging.warn_once(
                    f"Reached max_concurrent_encoders={self._max_concurrent_encoders}; "
                    f"dropping frames for env_id={env_id}.",
                    key="rendering_max_concurrent_reached",
                )
                return

            existing = self._open_encoder(env_id=env_id, episode=event.episode, rl_step=event.rl_step)
            if existing is None:
                return

        try:
            existing.write_frame(event.frame, rl_step=event.rl_step)
        except Exception as e:
            logger.warning(f"Error encoding rendering frame for env_id={env_id} episode={event.episode}: {e}")
            self._report_error(e)
            self._close_encoder(env_id)

    def _drain_queue(self) -> None:
        """
        Drain any remaining events from the queue without blocking. Called during
        shutdown so in-flight frames are flushed to their respective encoders before
        closing them.
        """

        while True:
            try:
                event = self._queue.get_nowait()
            except queue.Empty:
                break

            if event is self._SHUTDOWN_SENTINEL:
                continue

            self._handle_event(event)

    def _close_all_encoders(self) -> None:
        """
        Close every open encoder. Used at shutdown.
        """

        for env_id in list(self._encoders.keys()):
            self._close_encoder(env_id)

    def _consume_loop(self) -> None:
        """
        Consumer thread entry point. Drains events from the queue and routes them to
        encoders until the shutdown sentinel is received, then drains any remaining
        events and closes all open encoders.
        """

        logger.debug("Rendering dispatcher consumer thread started.")

        try:
            while True:
                try:
                    event = self._queue.get(timeout=self._CONSUME_GET_TIMEOUT)
                except queue.Empty:
                    if not self._accept_new_events:
                        break
                    continue

                if event is self._SHUTDOWN_SENTINEL:
                    break

                self._handle_event(event)

            if self._drain_on_exit:
                self._drain_queue()
        finally:
            self._close_all_encoders()
            logger.debug("Rendering dispatcher consumer thread exited.")

    def enqueue(self, frame: np.ndarray, rl_step: int, episode: int, env_id: str | None) -> None:
        """
        Enqueue a frame for asynchronous encoding. Applies the configured backpressure
        strategy if the queue is full.

        Args:
            frame: uint8 numpy frame to encode.
            rl_step: RL step at which the frame was logged.
            episode: Episode index this frame belongs to.
            env_id: Environment identifier.

        Raises:
            MetranaEventQueueFullError: If backpressure strategy is Raise and the queue
                is full, or strategy is Block and the put times out.
            UnrecognizedMetranaBackpressureStrategyError: If the strategy is unrecognized.
        """

        if not self._accept_new_events:
            metrana_logging.warn_once(
                "Rendering dispatcher is not accepting new events. Skipping log_rendering.",
                key="rendering_no_new_events",
            )
            return

        event = _RenderEvent(frame=frame, rl_step=rl_step, episode=episode, env_id=env_id)

        try:
            if self._backpressure_strategy is BackpressureStrategy.Block:
                self._queue.put(event, timeout=self._max_event_queue_timeout)
            else:
                self._queue.put_nowait(event)

        except queue.Full as e:
            if self._backpressure_strategy is BackpressureStrategy.DropNew:
                metrana_logging.warn_once(
                    "Rendering queue is full. Dropping frame.",
                    key="rendering_queue_full",
                )
                logger.trace(f"Rendering queue is full. Dropping frame for env_id={env_id}.")

            elif self._backpressure_strategy in [BackpressureStrategy.Raise, BackpressureStrategy.Block]:
                raise MetranaEventQueueFullError(
                    "Rendering queue is full and backpressure strategy is Raise (or Block timed out)."
                ) from e

            else:
                raise UnrecognizedMetranaBackpressureStrategyError(
                    f"Unrecognized backpressure strategy: {self._backpressure_strategy}. "
                    f"This should be unreachable, please report this as a bug."
                ) from e

    def close(self, timeout: float | None = None) -> None:
        """
        Stop accepting new events, signal the consumer thread to drain (or skip drain
        on Immediate) and exit, then join up to timeout seconds. Idempotent.

        Args:
            timeout: Maximum seconds to wait for the consumer thread to exit. None
                means wait indefinitely — appropriate for the default CompleteAll
                strategy where every queued frame must be encoded.
        """

        if self._stopped:
            return

        if self._close_strategy is CloseStrategy.Immediate:
            self.force_immediate_close(timeout=timeout)
            return

        if self._close_strategy is CloseStrategy.CompletePending:
            metrana_logging.warn_once(
                "Rendering close strategy CompletePending behaves identically to CompleteAll for video "
                "(there is no separate in-flight request notion); the queue will be drained in full.",
                key="rendering_complete_pending_alias",
            )

        self._stopped = True
        self._accept_new_events = False
        self._drain_on_exit = True

        try:
            self._queue.put_nowait(self._SHUTDOWN_SENTINEL)
        except queue.Full:
            # The consumer's get timeout will pick up _accept_new_events and exit.
            pass

        self._thread.join(timeout=timeout)
        if self._thread.is_alive():
            logger.warning(
                f"Rendering dispatcher consumer thread did not exit within {timeout}s; abandoning. "
                f"Some frames may not have been written."
            )

    def force_immediate_close(self, timeout: float | None) -> None:
        """
        Shut the dispatcher down without draining the pending queue. Used for the
        Immediate close strategy and from the logger's kill() path.

        Discards any queued frames that have not yet been routed to an encoder, then
        signals the consumer thread to exit. Encoders that are already open are
        flushed and closed by the consumer thread's finally block.

        Args:
            timeout: Maximum seconds to wait for the consumer thread to exit. None
                means wait indefinitely.
        """

        self._stopped = True
        self._accept_new_events = False
        self._drain_on_exit = False

        while True:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break

        try:
            self._queue.put_nowait(self._SHUTDOWN_SENTINEL)
        except queue.Full:
            pass

        self._thread.join(timeout=timeout)
        if self._thread.is_alive():
            logger.warning(
                f"Rendering dispatcher consumer thread did not exit within {timeout}s during immediate close; "
                f"abandoning."
            )
