# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import queue

from loguru import logger

from metrana.utils import logging
from metrana.utils.enums import ErrorStrategy
from metrana.utils.exceptions import (
    MetranaErrorQueueFullError,
    UnrecognizedMetranaErrorStrategyError,
)

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class ErrorSink:

    PRIORITY_QUEUE_MAX_SIZE = 16

    def __init__(
        self,
        error_strategy: ErrorStrategy,
        standard_max_size: int,
    ) -> None:
        """
        Centralised handler for errors raised by dispatcher worker threads.

        Owns two queues. Errors put on the priority queue are always raised the
        next time a logger method calls raise_pending, regardless of the
        configured ErrorStrategy — this is reserved for errors that mean the
        run cannot proceed (e.g. invalid metric names). Errors put on the
        standard queue are handled according to ErrorStrategy: dropped silently,
        warned once, or queued for raising at the next log/close call.

        Producers (dispatchers) just call report() or report_priority() and do
        not branch on strategy themselves.

        Args:
            error_strategy: How to handle standard errors: Silent, Warn,
                RaiseOnLog, or RaiseOnClose.
            standard_max_size: Maximum size of the standard queue (0 = unbounded).
        """

        self.error_strategy = error_strategy

        self._priority: queue.Queue[Exception] = queue.Queue(maxsize=self.PRIORITY_QUEUE_MAX_SIZE)
        self._standard: queue.Queue[Exception] = queue.Queue(maxsize=standard_max_size)

    @staticmethod
    def _drain(q: queue.Queue) -> list[Exception]:
        """
        Drain all items currently in the queue into a list.

        Args:
            q: The queue to drain.

        Returns:
            List of items removed from the queue, in FIFO order.
        """

        items: list[Exception] = []

        while not q.empty():
            try:
                items.append(q.get_nowait())
            except queue.Empty:
                break

        return items

    def report(self, exc: Exception, *, warn_key: str | None = None) -> None:
        """
        Report a standard (non-fatal) error. Behaviour depends on the configured
        ErrorStrategy: Silent traces and drops, Warn logs once and drops,
        RaiseOnLog/RaiseOnClose enqueue for later raising.

        If the standard queue is full under a Raise* strategy, the overflow is
        escalated to the priority queue as a MetranaErrorQueueFullError so the
        condition surfaces on the next logger call rather than silently growing.

        Args:
            exc: The exception to report.
            warn_key: Deduplication key used under the Warn strategy so callers
                with multiple distinct error sites of the same exception type
                are not collapsed into a single warning. Defaults to the
                exception's type name when not provided.
        """

        if self.error_strategy is ErrorStrategy.Silent:
            logger.trace(f"Error: {exc}")
            return

        if self.error_strategy is ErrorStrategy.Warn:
            key = warn_key if warn_key is not None else type(exc).__name__
            logging.warn_once(f"Error: {exc}", key=key)
            return

        if self.error_strategy in (ErrorStrategy.RaiseOnLog, ErrorStrategy.RaiseOnClose):
            try:
                self._standard.put_nowait(exc)
            except queue.Full:
                self.report_priority(
                    MetranaErrorQueueFullError(
                        "Standard error queue is full; escalating overflow to priority. " f"Original error: {exc}"
                    )
                )
            return

        self.report_priority(
            UnrecognizedMetranaErrorStrategyError(
                f"Unrecognized error strategy: {self.error_strategy}. "
                f"This should be unreachable, please report this as a bug."
            )
        )

    def report_priority(self, exc: Exception) -> None:
        """
        Report a fatal error that must surface on the next logger call regardless
        of the configured ErrorStrategy.

        If the priority queue is full, the new error is dropped (the first
        priority error is the one that matters) and a one-shot warning is
        emitted so the drop is observable.

        Args:
            exc: The exception to report.
        """

        try:
            self._priority.put_nowait(exc)
        except queue.Full:
            logging.warn_once(
                f"Priority error queue is full; dropping error: {exc}",
                key="priority_error_queue_full",
            )

    def has_priority(self) -> bool:
        """
        Check whether any priority errors are pending.

        Returns:
            True if the priority queue has at least one error.
        """

        return not self._priority.empty()

    def raise_pending(self, *, is_close: bool = False) -> None:
        """
        Drain pending errors and raise them as an ExceptionGroup if any are due.

        Priority errors are always drained and raised. Standard errors are
        drained and raised only when the strategy permits — RaiseOnLog raises
        on every call; RaiseOnClose raises only when is_close is True.

        Args:
            is_close: True if this call is from logger close(); enables draining
                of the standard queue under RaiseOnClose.

        Raises:
            ExceptionGroup: If there are any drained errors that are due to be
                raised in this call.
        """

        exceptions: list[Exception] = self._drain(self._priority)

        should_raise_standard = self.error_strategy is ErrorStrategy.RaiseOnLog or (
            is_close and self.error_strategy is ErrorStrategy.RaiseOnClose
        )

        if should_raise_standard:
            exceptions.extend(self._drain(self._standard))

        if exceptions:
            raise ExceptionGroup("Metrana encountered the following errors during operation:", exceptions)
