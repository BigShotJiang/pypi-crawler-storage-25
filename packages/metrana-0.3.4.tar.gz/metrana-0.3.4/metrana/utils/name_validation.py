# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from typing import Mapping

from metrana.utils.exceptions import MetranaMetricNameError

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

# Mirrors the QL-reserved set in services/ingestion_svc/src/service/validation.rs
# (`is_ql_reserved_char`). Names addressable as a QL BareToken cannot contain any
# of these characters.
QL_RESERVED_CHARS: frozenset[str] = frozenset('()[],=<>!~"|')

# Mirrors `is_label_encoding_char` — additional chars reserved by the FlatLabels
# `k=v&k=v` storage encoding. Applies to label keys and label values.
LABEL_ENCODING_CHARS: frozenset[str] = frozenset("&=")

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def validate_name(value: str, field: str) -> None:
    """
    Validate a name-shaped value (metric name, scale, attribute path, etc.)
    against the same rules the ingestion service enforces in
    services/ingestion_svc/src/service/validation.rs::validate_name. Catching
    these errors client-side means the user's run crashes synchronously at the
    log() call site rather than asynchronously inside a dispatcher worker.

    Rejects: empty values, leading ':', any whitespace or control character,
    and any QL-reserved character `()[],=<>!~"|`.

    Args:
        value: The string to validate.
        field: Human-readable name of the field being validated, used in the
            error message (e.g. "metric_name", "scale").

    Raises:
        MetranaMetricNameError: If the value violates any of the rules above.
            The message includes a suggested underscore-substituted replacement
            when the offending character is whitespace, since that is by far
            the most common user mistake.
    """

    if not value:
        raise MetranaMetricNameError(f"{field} must not be empty.")

    if value.startswith(":"):
        raise MetranaMetricNameError(f"{field} '{value}' must not start with ':'.")

    for char in value:
        if char.isspace() or not char.isprintable():
            suggested = value.replace(" ", "_") if " " in value else None
            hint = f" Did you mean '{suggested}'?" if suggested is not None else ""
            raise MetranaMetricNameError(f"{field} '{value}' contains whitespace or control character {char!r}.{hint}")

        if char in QL_RESERVED_CHARS:
            raise MetranaMetricNameError(
                f"{field} '{value}' contains reserved character {char!r}. " f'Reserved by query language: ()[],=<>!~"|'
            )


def validate_label(key: str, value: str) -> None:
    """
    Validate a label key/value pair against the rules in
    services/ingestion_svc/src/service/validation.rs::validate_label.

    Label keys inherit the name rules plus the FlatLabels storage-encoding
    chars (&, =). Label values reject only control characters and the storage
    encoding chars; whitespace and QL-reserved chars are allowed since values
    are addressable through the QL quoted-string form.

    Args:
        key: The label key.
        value: The label value.

    Raises:
        MetranaMetricNameError: If the key or value violates any of the rules.
    """

    if not key:
        raise MetranaMetricNameError("label key must not be empty.")

    if key.startswith(":"):
        raise MetranaMetricNameError(f"label key '{key}' must not start with ':'.")

    for char in key:
        if char.isspace() or not char.isprintable():
            raise MetranaMetricNameError(f"label key '{key}' contains whitespace or control character {char!r}.")

        if char in QL_RESERVED_CHARS or char in LABEL_ENCODING_CHARS:
            raise MetranaMetricNameError(
                f"label key '{key}' contains reserved character {char!r}. " f'Reserved: ()[],=<>!~"|&'
            )

    for char in value:
        if not char.isprintable():
            raise MetranaMetricNameError(f"label value for key '{key}' contains control character {char!r}.")

        if char in LABEL_ENCODING_CHARS:
            raise MetranaMetricNameError(
                f"label value for key '{key}' contains reserved character {char!r}. " f"Reserved: =&"
            )


def validate_labels(
    labels: Mapping[str, str],
    cache: set[tuple[str, str]] | None = None,
) -> None:
    """
    Validate every key/value pair in a labels mapping. Optionally take a cache
    set of (key, value) tuples already known to be valid; pairs found in the
    cache are skipped, and pairs that pass validation are added to the cache so
    subsequent calls only pay the hash-lookup cost.

    Iteration shape lives here rather than at the call site so callers (the
    logger hot path, future SDK helpers, tests) do not duplicate the loop or
    the cache-hit fast path.

    Args:
        labels: Mapping of label key/value pairs to validate.
        cache: Optional mutable set of (key, value) pairs already validated.
            When provided, validated pairs are added in-place; pairs already
            present are skipped.

    Raises:
        MetranaMetricNameError: If any label violates the validation rules.
    """

    for key, value in labels.items():
        pair = (key, value)
        if cache is not None and pair in cache:
            continue

        validate_label(key, value)

        if cache is not None:
            cache.add(pair)
