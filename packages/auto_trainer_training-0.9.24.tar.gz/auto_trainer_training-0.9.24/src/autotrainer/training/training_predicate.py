import hashlib
from enum import IntEnum
from sys import float_info
from typing import List, Union, Dict, Any, Optional, Tuple

from typing_extensions import Self
from autotrainer.api import ApiEventKind

from autotrainer.core import get_verbose_logger
from autotrainer.core.reach_event import ReachEventMethod, ReachEventOutcome

from .configurable import configurable
from .event import (
    ApiEventSource,
    TrainingPredicateApiEvent,
    TrainingPredicateApiEventKind,
)

logger = get_verbose_logger(__name__)
from .training_protocols import TrainingPredicateProtocol
from .training_protocols import PredicateContext, TrainingPhaseProtocol, class_from_dict, class_to_dict

_FLOAT_COMPARISON = float_info.epsilon * 2


class TrainingPredicate(ApiEventSource):
    def __init__(self, child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        self._child: Optional[TrainingPredicateProtocol] = child
        self._min_trials_to_evaluate: Optional[int] = min_trials_to_evaluate
        self._target_path: Optional[str] = None

    @property
    @configurable(required=False, envelope=True)
    def child(self) -> Optional[TrainingPredicateProtocol]:
        return self._child

    @child.setter
    def child(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._child = value

    @property
    @configurable(required=False, default=None)
    def min_trials_to_evaluate(self) -> Optional[int]:
        """Minimum number of sessions before this predicate can evaluate to True.
        Especially useful on fallback and advance predicates to prevent premature
        phase transitions before enough data has been collected."""
        return self._min_trials_to_evaluate

    @min_trials_to_evaluate.setter
    def min_trials_to_evaluate(self, value: Optional[int]) -> None:
        self._min_trials_to_evaluate = value

    def _get_common_event_data(self, phase: TrainingPhaseProtocol, role: str) -> Dict[str, Any]:
        return {
            "phaseId": phase.phase_id if hasattr(phase, "phase_id") else None,
            "predicateType": self.__class__.__name__,
            "role": role,
            "path": self._target_path or "",
        }

    def _emit_evaluation_started(self, phase: TrainingPhaseProtocol,
                                  extra_data: Optional[Dict[str, Any]] = None) -> None:
        data = self._get_common_event_data(phase, "unknown")
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolPredicateEvent,
            TrainingPredicateApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingPredicateApiEventKind.EVALUATION_STARTED,
                data=data,
            )
        )

    def _emit_evaluated_true(self, phase: TrainingPhaseProtocol,
                              extra_data: Optional[Dict[str, Any]] = None) -> None:
        data = {**self._get_common_event_data(phase, "unknown"), "result": True}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolPredicateEvent,
            TrainingPredicateApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingPredicateApiEventKind.EVALUATED_TRUE,
                data=data,
            )
        )

    def _emit_evaluated_false(self, phase: TrainingPhaseProtocol,
                               extra_data: Optional[Dict[str, Any]] = None) -> None:
        data = {**self._get_common_event_data(phase, "unknown"), "result": False}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolPredicateEvent,
            TrainingPredicateApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingPredicateApiEventKind.EVALUATED_FALSE,
                data=data,
            )
        )

    def _emit_short_circuited(self, phase: TrainingPhaseProtocol, reason: str,
                               extra_data: Optional[Dict[str, Any]] = None) -> None:
        data = {**self._get_common_event_data(phase, "unknown"), "reason": reason}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolPredicateEvent,
            TrainingPredicateApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingPredicateApiEventKind.SHORT_CIRCUITED,
                data=data,
            )
        )

    def _emit_error(self, phase: TrainingPhaseProtocol,
                     extra_data: Optional[Dict[str, Any]] = None) -> None:
        data = self._get_common_event_data(phase, "unknown")
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolPredicateEvent,
            TrainingPredicateApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingPredicateApiEventKind.ERROR,
                data=data,
            )
        )

    def _evaluate_gate(self, phase: TrainingPhaseProtocol,
                       context: PredicateContext) -> Tuple[bool, Optional[str]]:
        if self._min_trials_to_evaluate is not None:
            if context.progress is None or context.progress.session_count < self._min_trials_to_evaluate:
                return False, "min_trials_not_met"
        if self._child is not None:
            result = self._child.evaluate(phase, context)
            if not result:
                return False, "base_predicate_false"
        return True, None

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        session_count = context.progress.session_count if context.progress is not None else 0
        self._emit_evaluation_started(phase, {
            "minTrialsToEvaluate": self._min_trials_to_evaluate,
            "sessionCount": session_count,
            "hasChild": self._child is not None,
        })

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_short_circuited(phase, reason)
            return False

        self._emit_evaluated_true(phase)
        return True

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {}
        if self._child is not None:
            result["child"] = self._child.to_dict()
        if self._min_trials_to_evaluate is not None:
            result["min_trials_to_evaluate"] = self._min_trials_to_evaluate
        return result if result else None

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, self._to_dict())

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]):
        return class_from_dict(data)


class CompoundPredicate(TrainingPredicate):
    class CompoundType(IntEnum):
        AND = 0
        OR = 1

    def __init__(self, compound_type: CompoundType, predicates: List[TrainingPredicate],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._compound_type = compound_type
        self._predicates = predicates

    @property
    @configurable()
    def compound_type(self) -> "CompoundPredicate.CompoundType":
        return self._compound_type

    @compound_type.setter
    def compound_type(self, value: "CompoundPredicate.CompoundType") -> None:
        self._compound_type = value

    @property
    @configurable(envelope=True)
    def predicates(self) -> List[TrainingPredicate]:
        return self._predicates

    @predicates.setter
    def predicates(self, value: List[TrainingPredicate]) -> None:
        self._predicates = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        child_paths = [pred._target_path or "" for pred in self.predicates]
        self._emit_evaluation_started(phase, {
            "compoundType": self.compound_type.name,
            "predicateCount": len(self.predicates),
            "childPaths": child_paths,
        })

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_evaluated_false(phase, {"reason": reason})
            return False

        if self.compound_type == CompoundPredicate.CompoundType.AND:
            for predicate in self.predicates:
                if not predicate.evaluate(phase, context):
                    self._emit_evaluated_false(phase, {"determiningChildPath": predicate._target_path or ""})
                    return False
            self._emit_evaluated_true(phase)
            return True
        else:
            for predicate in self.predicates:
                if predicate.evaluate(phase, context):
                    self._emit_evaluated_true(phase, {"determiningChildPath": predicate._target_path or ""})
                    return True
            self._emit_evaluated_false(phase)
            return False

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "compound_type": self.compound_type.name,
            "predicates": [predicate.to_dict() for predicate in self.predicates]
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        compound_type = CompoundPredicate.CompoundType[data["compound_type"]]
        predicates = [TrainingPredicate.from_dict(d) for d in data["predicates"]]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(compound_type, predicates, child, data.get("min_trials_to_evaluate"))


class NumberComparisonType(IntEnum):
    LT = 0
    LTE = 1
    EQ = 2
    GTE = 3
    GT = 4


def compare_numbers(comparison_type: NumberComparisonType,
                    resolved_value: Optional[Union[int, float]], compare_value: Union[int, float]) -> bool:
    if resolved_value is None:
        return False

    if comparison_type == NumberComparisonType.LT:
        return resolved_value < compare_value
    elif comparison_type == NumberComparisonType.LTE:
        return resolved_value <= compare_value
    elif comparison_type == NumberComparisonType.EQ:
        if isinstance(resolved_value, float) or isinstance(compare_value, float):
            return abs(resolved_value - compare_value) < _FLOAT_COMPARISON
        else:
            return resolved_value == compare_value
    elif comparison_type == NumberComparisonType.GTE:
        return resolved_value >= compare_value
    elif comparison_type == NumberComparisonType.GT:
        return resolved_value > compare_value

    return False


class NumberComparisonPredicate(TrainingPredicate):
    def __init__(self, comparison_type: NumberComparisonType, path: str, value: Union[int, float],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)
        self._comparison_type = comparison_type
        if not isinstance(path, list):
            self._path = path.split(".")
        else:
            self._path = path

        self._value = value

    @property
    @configurable()
    def comparison_type(self) -> NumberComparisonType:
        return self._comparison_type

    @comparison_type.setter
    def comparison_type(self, value: NumberComparisonType) -> None:
        self._comparison_type = value

    @property
    @configurable()
    def path(self) -> List[str]:
        return self._path

    @path.setter
    def path(self, value: List[str]) -> None:
        self._path = value

    @property
    @configurable()
    def value(self) -> Union[int, float]:
        return self._value

    @value.setter
    def value(self, value: Union[int, float]):
        self._value = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        path_str = ".".join(self.path)
        self._emit_evaluation_started(phase, {
            "comparisonType": self.comparison_type.name,
            "path": path_str,
            "compareValue": self.value,
        })

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_evaluated_false(phase, {"reason": reason})
            return False

        resolved = context.resolve_path(self.path)
        if resolved is None:
            self._emit_short_circuited(phase, "missing_path_value", {"path": path_str})
            return False

        result = compare_numbers(self.comparison_type, resolved, self.value)
        extra = {"resolvedValue": resolved, "compareValue": self.value}
        if result:
            self._emit_evaluated_true(phase, extra)
        else:
            self._emit_evaluated_false(phase, extra)
        return result

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "comparison_type": self.comparison_type.name,
            "path": self.path,
            "value": self.value
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        comparison_type = NumberComparisonType[data["comparison_type"]]
        path = data["path"]
        value = data["value"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(comparison_type, path, value, child, data.get("min_trials_to_evaluate"))


class MathComparisonPredicate(NumberComparisonPredicate):
    _configurable_exclude = {"path"}

    class MathOperationType(IntEnum):
        ADD = 0
        SUBTRACT = 1
        MULTIPLY = 2
        DIVIDE = 3

    def __init__(self, comparison_type: NumberComparisonType,
                 left_path: str, math_operation: MathOperationType,
                 right_path: str, value: Union[int, float],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(comparison_type, left_path, value, child, min_trials_to_evaluate)
        self._math_operation = math_operation
        if not isinstance(right_path, list):
            self._right_path = right_path.split(".")
        else:
            self._right_path = right_path

    @property
    @configurable()
    def left_path(self) -> List[str]:
        return self._path

    @left_path.setter
    def left_path(self, value: List[str]) -> None:
        self._path = value

    @property
    @configurable()
    def math_operation(self) -> "MathComparisonPredicate.MathOperationType":
        return self._math_operation

    @math_operation.setter
    def math_operation(self, value: "MathComparisonPredicate.MathOperationType") -> None:
        self._math_operation = value

    @property
    @configurable()
    def right_path(self) -> List[str]:
        return self._right_path

    @right_path.setter
    def right_path(self, value: List[str]) -> None:
        self._right_path = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        left_path_str = ".".join(self.path)
        right_path_str = ".".join(self.right_path)
        self._emit_evaluation_started(phase, {
            "comparisonType": self.comparison_type.name,
            "leftPath": left_path_str,
            "rightPath": right_path_str,
            "mathOperation": self.math_operation.name,
            "compareValue": self.value,
        })

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_evaluated_false(phase, {"reason": reason})
            return False

        left_value = context.resolve_path(self.path)
        right_value = context.resolve_path(self.right_path)

        if left_value is None:
            self._emit_short_circuited(phase, "missing_left_value", {"leftPath": left_path_str})
            return False

        if right_value is None:
            self._emit_short_circuited(phase, "missing_right_value", {"rightPath": right_path_str})
            return False

        if self.math_operation == MathComparisonPredicate.MathOperationType.ADD:
            computed_value = left_value + right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.SUBTRACT:
            computed_value = left_value - right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.MULTIPLY:
            computed_value = left_value * right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.DIVIDE:
            if right_value == 0:
                self._emit_short_circuited(phase, "division_by_zero")
                return False
            computed_value = left_value / right_value
        else:
            self._emit_error(phase, {
                "errorType": "UnknownMathOperation",
                "message": f"Unknown math operation: {self.math_operation}",
            })
            return False

        result = compare_numbers(self.comparison_type, computed_value, self.value)
        extra = {
            "leftValue": left_value,
            "rightValue": right_value,
            "computedValue": computed_value,
            "compareValue": self.value,
        }
        if result:
            self._emit_evaluated_true(phase, extra)
        else:
            self._emit_evaluated_false(phase, extra)
        return result

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "comparison_type": self.comparison_type.name,
            "left_path": self.path,
            "math_operation": self.math_operation.name,
            "right_path": self.right_path,
            "value": self.value
        }
        base = TrainingPredicate._to_dict(self)
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        comparison_type = NumberComparisonType[data["comparison_type"]]
        left_path = data["left_path"]
        math_operation = MathComparisonPredicate.MathOperationType[data["math_operation"]]
        right_path = data["right_path"]
        value = data["value"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(comparison_type, left_path, math_operation, right_path, value, child,
                   data.get("min_trials_to_evaluate"))


class PelletReachTimePredicate(TrainingPredicate):
    def __init__(self, max_reach_time: float, require_first: bool = False,
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._max_reach_time = max_reach_time
        self._require_first = require_first

    @property
    @configurable()
    def max_reach_time(self) -> float:
        return self._max_reach_time

    @max_reach_time.setter
    def max_reach_time(self, value: float) -> None:
        self._max_reach_time = value

    @property
    @configurable()
    def require_first(self) -> bool:
        return self._require_first

    @require_first.setter
    def require_first(self, value: bool) -> None:
        self._require_first = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        self._emit_evaluation_started(phase, {
            "maxReachTime": self._max_reach_time,
            "requireFirst": self._require_first,
        })

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_evaluated_false(phase, {"reason": reason})
            return False

        if context.algorithm is None:
            self._emit_short_circuited(phase, "missing_algorithm")
            return False

        reaches = context.algorithm.trial_reaches
        reach_count = len(reaches)

        for reach in reaches:
            if reach.outcome == ReachEventOutcome.EATEN and reach.method == ReachEventMethod.RIGHT_HAND:
                if reach.delay_since_presented <= self._max_reach_time:
                    self._emit_evaluated_true(phase, {
                        "reachCount": reach_count,
                        "matchingReach": {
                            "delaySincePresented": reach.delay_since_presented,
                            "outcome": reach.outcome,
                            "method": reach.method,
                        },
                    })
                    return True
                if self._require_first:
                    self._emit_evaluated_false(phase, {
                        "reachCount": reach_count,
                        "firstReach": {
                            "delaySincePresented": reach.delay_since_presented,
                            "outcome": reach.outcome,
                            "method": reach.method,
                        },
                    })
                    return False

        self._emit_evaluated_false(phase, {
            "reachCount": reach_count,
            "reason": "no_matching_reach",
        })
        return False

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "max_reach_time": self._max_reach_time,
            "require_first": self._require_first
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        max_reach_time = data["max_reach_time"]
        require_first = data["require_first"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(max_reach_time, require_first, child, data.get("min_trials_to_evaluate"))


class PythonPredicate(TrainingPredicate):
    def __init__(self, python_code: str, child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._python_code = python_code
        self._compiled_eval = None
        self._compiled_exec = None
        self._use_exec = False

    @property
    @configurable()
    def python_code(self) -> str:
        return self._python_code

    @python_code.setter
    def python_code(self, value: str) -> None:
        self._python_code = value
        self._compiled_eval = None
        self._compiled_exec = None
        self._use_exec = False

    @property
    def _code_hash(self) -> str:
        return hashlib.sha256(self._python_code.encode()).hexdigest()[:16]

    def _ensure_compiled(self) -> None:
        if self._compiled_eval is not None or self._compiled_exec is not None:
            return
        try:
            self._compiled_eval = compile(self._python_code, "<PythonPredicate>", "eval")
        except SyntaxError:
            self._compiled_exec = compile(self._python_code, "<PythonPredicate>", "exec")
            self._use_exec = True

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        self._emit_evaluation_started(phase, {"pythonCodeHash": self._code_hash})

        passed, reason = self._evaluate_gate(phase, context)
        if not passed:
            self._emit_evaluated_false(phase, {"reason": reason})
            return False

        namespace = {"context": context, "phase": phase}
        try:
            self._ensure_compiled()
            if self._use_exec:
                exec(self._compiled_exec, namespace)
                result = bool(namespace.get("result", False))
            else:
                result = bool(eval(self._compiled_eval, namespace))

            if result:
                self._emit_evaluated_true(phase, {"pythonCodeHash": self._code_hash})
            else:
                self._emit_evaluated_false(phase, {"pythonCodeHash": self._code_hash})
            return result

        except Exception as exc:
            logger.error("PythonPredicate error evaluating: %s", self._python_code, exc_info=True)
            self._emit_error(phase, {
                "errorType": exc.__class__.__name__,
                "message": str(exc),
                "pythonCodeHash": self._code_hash,
            })
            return False

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "python_code": self.python_code
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        python_code = data["python_code"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(python_code, child, data.get("min_trials_to_evaluate"))
