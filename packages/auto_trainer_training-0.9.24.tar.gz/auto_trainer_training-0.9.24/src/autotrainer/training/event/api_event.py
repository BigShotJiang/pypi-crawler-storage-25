from dataclasses import dataclass
from datetime import datetime, timezone
from enum import IntEnum
import logging
from time import perf_counter_ns
from typing import Any, Dict, Mapping, Optional

from autotrainer.api import ApiEvent, ApiEventKind

try:
    from autotrainer.core.event.event_info import EventInfo as _EventClass
except ImportError:
    _EventClass = ApiEvent

_event_manager = None
_event_manager_resolved = False
logger = logging.getLogger(__name__)


def _get_event_manager():
    global _event_manager, _event_manager_resolved

    if _event_manager is not None:
        if getattr(_event_manager, "is_valid", True):
            return _event_manager
        _event_manager = None
        _event_manager_resolved = False

    if _event_manager_resolved:
        return None

    try:
        from autotrainer.core import EventManager
        _event_manager = EventManager.default()
        _event_manager_resolved = True
    except ImportError:
        # The core package is optional; do not retry every event when it is absent.
        _event_manager = None
        _event_manager_resolved = True
    except Exception:
        # Default-manager creation may fail transiently. Leave resolution open so a
        # later event can retry instead of disabling protocol events forever.
        logger.exception("failed to resolve default EventManager")
        _event_manager = None
        _event_manager_resolved = False

    return _event_manager


@dataclass(frozen=True)
class ProtocolEventPayload:
    target_id: str
    event_type: IntEnum
    data: Optional[Mapping[str, Any]] = None

    def to_context(self) -> Dict[str, Any]:
        return {
            "targetId": self.target_id,
            "eventType": int(self.event_type),
            "data": self.data,
        }


def create_api_event(kind: ApiEventKind, payload: ProtocolEventPayload) -> ApiEvent:
    return _EventClass(
        kind=kind,
        when=datetime.now(timezone.utc),
        index=perf_counter_ns(),
        context=payload.to_context(),
    )


class ApiEventSource:
    def _emit_api_event(self, kind: ApiEventKind, payload: ProtocolEventPayload) -> None:
        event = create_api_event(kind, payload)
        mgr = _get_event_manager()
        if mgr is not None:
            mgr.post_event(event)


class ProtocolApiEventKind(IntEnum):
    ATTACHED = 10
    DETACHED = 20
    SESSION_STARTED = 30
    SESSION_CAPTURE_ENDED = 40
    SESSION_ENDED = 50


@dataclass(frozen=True)
class ProtocolApiEvent(ProtocolEventPayload):
    event_type: ProtocolApiEventKind


class TrainingPlanApiEventKind(IntEnum):
    LOADED = 10
    ATTACHMENT_CHANGED = 20
    AUTOMATIC_CHANGED = 30
    CURRENT_PHASE_CHANGED = 40
    PROGRESS_STATE_CHANGED = 50
    PROGRESS_LOADED = 60


@dataclass(frozen=True)
class TrainingPlanApiEvent(ProtocolEventPayload):
    event_type: TrainingPlanApiEventKind


class TrainingPhaseApiEventKind(IntEnum):
    ENTERED = 10
    EXITED = 20
    RESUMED = 30
    ADVANCE_READINESS_CHANGED = 40
    FALLBACK_READINESS_CHANGED = 50
    CONFIGURATION_APPLIED = 60


@dataclass(frozen=True)
class TrainingPhaseApiEvent(ProtocolEventPayload):
    event_type: TrainingPhaseApiEventKind


class TrainingPredicateApiEventKind(IntEnum):
    EVALUATION_STARTED = 10
    EVALUATED_TRUE = 20
    EVALUATED_FALSE = 30
    SHORT_CIRCUITED = 40
    ERROR = 50


@dataclass(frozen=True)
class TrainingPredicateApiEvent(ProtocolEventPayload):
    event_type: TrainingPredicateApiEventKind


class TrainingActionApiEventKind(IntEnum):
    BEGAN = 10
    RESUMED = 20
    EVALUATION_STARTED = 30
    EVALUATED = 40
    SHORT_CIRCUITED = 50
    COMPLETION_CHANGED = 60
    STATE_CHANGED = 70
    ERROR = 80


@dataclass(frozen=True)
class TrainingActionApiEvent(ProtocolEventPayload):
    event_type: TrainingActionApiEventKind


class TrainingProgressApiEventKind(IntEnum):
    ATTEMPT_STARTED = 10
    SESSION_COUNT_CHANGED = 20
    COUNTER_CHANGED = 30
    TIMER_STARTED = 40
    TIMER_PAUSED = 50
    PELLET_LOCATION_CHANGED = 60
    USER_CONTEXT_CHANGED = 70


@dataclass(frozen=True)
class TrainingProgressApiEvent(ProtocolEventPayload):
    event_type: TrainingProgressApiEventKind
