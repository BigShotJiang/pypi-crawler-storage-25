import hashlib
from sys import float_info
from typing import List, Optional, Dict, Any, Tuple, Union

from typing_extensions import Self
from autotrainer.api import ApiEventKind

from autotrainer.core import get_verbose_logger

from .configurable import configurable
from .event import (
    ApiEventSource,
    TrainingActionApiEvent,
    TrainingActionApiEventKind,
)
from .training_predicate import TrainingPredicate
from .training_protocols import (TrainingActionProtocol, TrainingPhaseProtocol, PredicateContext,
                                 class_from_dict, class_to_dict, TrainingPredicateProtocol)
from .value_provider import BooleanValueProvider, ValueProvider

logger = get_verbose_logger(__name__)

_FLOAT_COMPARISON = float_info.epsilon * 2


class TrainingAction(TrainingActionProtocol, ApiEventSource):
    def __init__(self, predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        self._predicate = predicate
        self._min_trials_to_complete = min_trials_to_complete

        self._is_complete: bool = False
        self._min_trials_met: bool = True
        self._trial_count_at_begin: int = 0

        self._target_path: Optional[str] = None
        self._eval_started_emitted: bool = False

    @property
    @configurable(required=False, envelope=True, default=None)
    def predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._predicate

    @predicate.setter
    def predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._predicate = value

    @property
    @configurable(required=False, default=0)
    def min_trials_to_complete(self) -> int:
        return self._min_trials_to_complete

    @min_trials_to_complete.setter
    def min_trials_to_complete(self, value: int) -> None:
        self._min_trials_to_complete = value

    @property
    def has_progress(self) -> bool:
        return self.predicate is not None or self.min_trials_to_complete > 0

    @property
    def is_complete(self) -> bool:
        if not self._min_trials_met:
            return False
        if self.predicate is None:
            return True
        return self._is_complete

    def _get_common_event_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "phaseId": phase.phase_id if hasattr(phase, "phase_id") else None,
            "actionType": self.__class__.__name__,
            "path": self._target_path or "",
            "hasProgress": self.has_progress,
            "isComplete": self.is_complete,
        }

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {}

    def _emit_began(self, phase: TrainingPhaseProtocol) -> None:
        common_data = self._get_common_event_data(phase)
        data = {
            **common_data,
            "minTrialsToComplete": self._min_trials_to_complete,
            "trialCountAtBegin": self._trial_count_at_begin,
            "hasPredicate": self._predicate is not None,
        }
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.BEGAN,
                data=data,
            )
        )

    def _emit_resumed(self, phase: TrainingPhaseProtocol) -> None:
        common_data = self._get_common_event_data(phase)
        data = {
            **common_data,
            "minTrialsToComplete": self._min_trials_to_complete,
            "trialCountAtBegin": self._trial_count_at_begin,
            "hasPredicate": self._predicate is not None,
        }
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.RESUMED,
                data=data,
            )
        )

    def _emit_evaluation_started(self, phase: TrainingPhaseProtocol) -> None:
        if self._eval_started_emitted:
            return
        self._eval_started_emitted = True
        common_data = self._get_common_event_data(phase)
        data = {
            **common_data,
            "minTrialsToComplete": self._min_trials_to_complete,
            "trialCountAtBegin": self._trial_count_at_begin,
            "hasPredicate": self._predicate is not None,
        }
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.EVALUATION_STARTED,
                data=data,
            )
        )

    def _emit_evaluated(self, phase: TrainingPhaseProtocol, extra_data: Optional[Dict[str, Any]] = None) -> None:
        common_data = self._get_common_event_data(phase)
        data = {**common_data}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.EVALUATED,
                data=data,
            )
        )

    def _emit_short_circuit(self, phase: TrainingPhaseProtocol, reason: str,
                            extra_data: Optional[Dict[str, Any]] = None) -> None:
        common_data = self._get_common_event_data(phase)
        data = {**common_data, "reason": reason}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.SHORT_CIRCUITED,
                data=data,
            )
        )

    def _emit_completion_changed(self, phase: TrainingPhaseProtocol,
                                 old_complete: bool, new_complete: bool) -> None:
        if old_complete == new_complete:
            return
        common_data = self._get_common_event_data(phase)
        data = {
            **common_data,
            "oldIsComplete": old_complete,
            "newIsComplete": new_complete,
        }
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.COMPLETION_CHANGED,
                data=data,
            )
        )

    def _emit_state_changed(self, phase: TrainingPhaseProtocol,
                            extra_data: Optional[Dict[str, Any]] = None) -> None:
        common_data = self._get_common_event_data(phase)
        state_data = self._get_state_data(phase)
        data = {**common_data, **state_data}
        if extra_data:
            data.update(extra_data)
        self._emit_api_event(
            ApiEventKind.protocolActionEvent,
            TrainingActionApiEvent(
                target_id=self._target_path or "",
                event_type=TrainingActionApiEventKind.STATE_CHANGED,
                data=data,
            )
        )

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        if context.progress is not None:
            self._trial_count_at_begin = context.progress.session_count
        else:
            self._trial_count_at_begin = 0

        self._emit_began(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        self._emit_resumed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete
        self._eval_started_emitted = False

        self._emit_evaluation_started(phase)

        if self.min_trials_to_complete > 0:
            self._min_trials_met = (context.progress is not None
                                    and (context.progress.session_count - self._trial_count_at_begin)
                                    >= self.min_trials_to_complete)
        else:
            self._min_trials_met = True

        if not self._min_trials_met:
            self._emit_short_circuit(phase, "min_trials_not_met", {"minTrialsMet": False})

        predicate_result = None
        if self.predicate is not None:
            if self._min_trials_met:
                predicate_result = self.predicate.evaluate(phase, context)
                self._is_complete = predicate_result
                if not predicate_result:
                    self._emit_short_circuit(phase, "predicate_false", {"predicateResult": False})
            else:
                self._is_complete = False

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        self._emit_evaluated(phase, {
            "minTrialsMet": self._min_trials_met,
            "predicateResult": predicate_result,
        })

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        return {"trial_count_at_begin": self._trial_count_at_begin}

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        self._trial_count_at_begin = data.get("trial_count_at_begin", 0)

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {}
        if self.predicate is not None:
            result["predicate"] = self.predicate.to_dict()
        if self.min_trials_to_complete > 0:
            result["min_trials_to_complete"] = self.min_trials_to_complete
        return result if result else None

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, self._to_dict())

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> Optional[Self]:
        return class_from_dict(data)

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(predicate=predicate, min_trials_to_complete=min_trials_to_complete)


class HeadMagnetIntensityAction(TrainingAction):
    def __init__(self, start: float, increment: float, end: float, pellet_delta: int,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._start = start
        self._increment = increment
        self._end = end
        self._pellet_delta = pellet_delta

        self.increment_start_pellet_count = 0
        self.current_intensity = 0

    @property
    @configurable()
    def start(self) -> float:
        return self._start

    @start.setter
    def start(self, value: float) -> None:
        self._start = value

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @increment.setter
    def increment(self, value: float) -> None:
        self._increment = value

    @property
    @configurable()
    def end(self) -> float:
        return self._end

    @end.setter
    def end(self, value: float) -> None:
        self._end = value

    @property
    @configurable(aliases=["pellet delta"])
    def pellet_delta(self) -> int:
        return self._pellet_delta

    @pellet_delta.setter
    def pellet_delta(self, value: int) -> None:
        self._pellet_delta = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        if not super().is_complete:
            return False
        return abs(self.current_intensity) >= self.end - _FLOAT_COMPARISON

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "start": self._start,
            "increment": self._increment,
            "end": self._end,
            "pelletDelta": self._pellet_delta,
            "incrementStartPelletCount": self.increment_start_pellet_count,
            "currentIntensity": self.current_intensity,
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self.increment_start_pellet_count = context.progress.pellets_consumed
        self.current_intensity = self.start
        if context.tunnel_device is not None:
            context.tunnel_device.update_head_magnet_intensity(self.start)

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if context.tunnel_device is not None:
            context.tunnel_device.update_head_magnet_intensity(self.current_intensity)

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete

        super().evaluate(phase, context)

        if context.progress is None:
            self._emit_short_circuit(phase, "missing_progress")
            return False

        if context.tunnel_device is None:
            self._emit_short_circuit(phase, "missing_tunnel_device")
            return False

        pellets_consumed = context.progress.pellets_consumed
        if pellets_consumed - self.increment_start_pellet_count > self.pellet_delta:
            current = context.tunnel_device.head_magnet_intensity
            if current is None:
                current = self.current_intensity
            intensity = min(self.end, current + self.increment)
            self.current_intensity = intensity
            self.increment_start_pellet_count = pellets_consumed
            context.tunnel_device.update_head_magnet_intensity(intensity)

            self._emit_state_changed(phase, {
                "pelletsConsumed": pellets_consumed,
                "nextIntensity": min(self.end, intensity + self.increment) if intensity < self.end else None,
            })

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "current_intensity": self.current_intensity,
            "increment_start_pellet_count": self.increment_start_pellet_count,
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self.current_intensity = data["current_intensity"]
        self.increment_start_pellet_count = data.get(
            "increment_start_pellet_count", data.get("pellet_start", 0)
        )

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "start": self.start,
            "increment": self.increment,
            "end": self.end,
            "pellet_delta": self.pellet_delta
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(data["start"], data["increment"], data["end"], data["pellet_delta"],
                   predicate, min_trials_to_complete)


class ReachDistanceBasicAction(TrainingAction):
    def __init__(self, increment: float, distance: float, pellet_delta: int,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._increment = increment
        self._distance = distance
        self._pellet_delta = pellet_delta

        self.current_increment_pellet_count = 0
        self.initial_y = 0
        self.current_delta_y = 0
        self.distance_reached_pellet_count = 0
        self._has_initial_position = False
        self._has_valid_position = False

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @increment.setter
    def increment(self, value: float) -> None:
        self._increment = value

    @property
    @configurable(aliases=["reach distance"])
    def distance(self) -> float:
        return self._distance

    @distance.setter
    def distance(self, value: float) -> None:
        self._distance = value

    @property
    @configurable(aliases=["pellet delta"])
    def pellet_delta(self) -> int:
        return self._pellet_delta

    @pellet_delta.setter
    def pellet_delta(self, value: int) -> None:
        self._pellet_delta = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def _has_reached_distance(self) -> bool:
        return abs(self.current_delta_y) >= self.distance - _FLOAT_COMPARISON

    @property
    def is_complete(self) -> bool:
        if not self._has_initial_position or not self._has_valid_position:
            return False
        if not super().is_complete:
            return False
        if not self._has_reached_distance:
            return False
        if self.distance_reached_pellet_count == 0:
            return False
        return self.current_increment_pellet_count - self.distance_reached_pellet_count >= self.pellet_delta

    def _initialize_position(self, context: PredicateContext) -> bool:
        if (context.progress is None
                or context.pellet_device is None
                or context.pellet_device.last_dcs_set_position is None):
            return False
        self.current_increment_pellet_count = context.progress.pellets_consumed
        self.initial_y = context.pellet_device.last_dcs_set_position.y
        self.current_delta_y = 0
        self.distance_reached_pellet_count = 0
        self._has_initial_position = True
        self._has_valid_position = True
        return True

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "increment": self._increment,
            "distance": self._distance,
            "pelletDelta": self._pellet_delta,
            "currentIncrementPelletCount": self.current_increment_pellet_count,
            "initialY": self.initial_y,
            "currentDeltaY": self.current_delta_y,
            "distanceReachedPelletCount": self.distance_reached_pellet_count,
            "hasInitialPosition": self._has_initial_position,
            "hasValidPosition": self._has_valid_position,
            "hasReachedDistance": self._has_reached_distance,
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self.current_increment_pellet_count = context.progress.pellets_consumed if context.progress is not None else 0
        self.initial_y = 0.0
        self.current_delta_y = 0
        self.distance_reached_pellet_count = 0
        self._has_initial_position = False
        self._has_valid_position = False
        self._initialize_position(context)

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if context.pellet_device is None or context.pellet_device.last_dcs_set_position is None:
            self._has_valid_position = False
            self._emit_short_circuit(phase,
                                     "missing_pellet_device" if context.pellet_device is None else "missing_position")
            return
        if not self._has_initial_position:
            self._initialize_position(context)
            self._emit_state_changed(phase)
            return
        context.pellet_device.set_dcs_y(self.initial_y + self.current_delta_y)
        self._has_valid_position = True

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete
        old_has_valid_position = self._has_valid_position
        self._eval_started_emitted = False
        self._emit_evaluation_started(phase)

        if context.progress is None:
            self._emit_short_circuit(phase, "missing_progress")
            return False

        if context.pellet_device is None:
            self._emit_short_circuit(phase, "missing_pellet_device")
            return False

        if context.pellet_device.last_dcs_set_position is None:
            self._has_valid_position = False
            self._emit_short_circuit(phase, "missing_position")
            return False

        if not self._has_initial_position and not self._initialize_position(context):
            self._emit_short_circuit(phase, "invalid_position")
            return False

        self._has_valid_position = True

        super().evaluate(phase, context)

        state_changed = False
        if context.progress.pellets_consumed - self.current_increment_pellet_count > self.pellet_delta:
            self.current_increment_pellet_count = context.progress.pellets_consumed
            if not self._has_reached_distance:
                last_position = context.pellet_device.last_dcs_set_position
                if last_position is None:
                    return False
                distance = min(self.initial_y + self.distance, last_position.y + self.increment)
                self.current_delta_y = distance - self.initial_y
                context.pellet_device.set_dcs_y(distance)
                state_changed = True
                if self._has_reached_distance:
                    self.distance_reached_pellet_count = self.current_increment_pellet_count
            elif self.distance_reached_pellet_count == 0:
                self.distance_reached_pellet_count = self.current_increment_pellet_count
                state_changed = True

        if state_changed or (old_has_valid_position != self._has_valid_position):
            self._emit_state_changed(phase)

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "current_increment_pellet_count": self.current_increment_pellet_count,
            "initial_y": self.initial_y,
            "current_delta_y": self.current_delta_y,
            "distance_reached_pellet_count": self.distance_reached_pellet_count,
            "has_initial_position": self._has_initial_position
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self.current_increment_pellet_count = data.get("current_increment_pellet_count", 0)
        self.initial_y = data.get("initial_y", 0.0)
        self.current_delta_y = data.get("current_delta_y", 0.0)
        self.distance_reached_pellet_count = data.get("distance_reached_pellet_count", 0)
        self._has_initial_position = data.get(
            "has_initial_position",
            any(key in data for key in ("initial_y", "current_delta_y"))
        )

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "distance": self.distance,
            "increment": self.increment,
            "pellet_delta": self.pellet_delta
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(data["increment"], data["distance"], data["pellet_delta"],
                   predicate, min_trials_to_complete)


class _StepRelativeProgress:
    """Proxy that presents progress values relative to a captured step baseline."""

    _NUMERIC_FIELDS = (
        "session_count", "pellets_presented", "pellets_consumed",
        "successful_reaches", "total_reaches", "time_in_training", "phase_attempts",
    )

    def __init__(self, real_progress, baseline: Dict[str, Any]):
        self._real = real_progress
        self._baseline = baseline

    def __getattr__(self, name: str):
        if name in _StepRelativeProgress._NUMERIC_FIELDS:
            real_value = getattr(self._real, name)
            return real_value - self._baseline.get(name, 0)
        return getattr(self._real, name)


class ReachDistanceMultiAction(TrainingAction):
    def __init__(self, increment: float, distance: float, z_increment: float, max_y: float,
                 next_predicate: Optional[TrainingPredicateProtocol] = None,
                 previous_predicate: Optional[TrainingPredicateProtocol] = None,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._increment = increment
        self._distance = distance
        self._z_increment = z_increment
        self._max_y = max_y
        self._next_predicate = next_predicate
        self._previous_predicate = previous_predicate
        self._next_predicate_dict = next_predicate.to_dict() if next_predicate is not None else None
        self._previous_predicate_dict = previous_predicate.to_dict() if previous_predicate is not None else None
        self._active_next_predicate: Optional[TrainingPredicateProtocol] = None
        self._active_previous_predicate: Optional[TrainingPredicateProtocol] = None
        self._step_baseline: Optional[Dict[str, Any]] = None

        self.initial_y: float = 0.0
        self.initial_z: float = 0.0
        self.current_delta_y: float = 0.0
        self.current_delta_z: float = 0.0
        self.current_step_count: int = 0
        self.has_reached_final_position: bool = False
        self._has_initial_position: bool = False
        self._has_valid_position: bool = False

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @increment.setter
    def increment(self, value: float) -> None:
        self._increment = value

    @property
    @configurable()
    def distance(self) -> float:
        return self._distance

    @distance.setter
    def distance(self, value: float) -> None:
        self._distance = value

    @property
    @configurable()
    def z_increment(self) -> float:
        return self._z_increment

    @z_increment.setter
    def z_increment(self, value: float) -> None:
        self._z_increment = value

    @property
    @configurable()
    def max_y(self) -> float:
        return self._max_y

    @max_y.setter
    def max_y(self, value: float) -> None:
        self._max_y = value

    @property
    @configurable(required=False, envelope=True, default=None)
    def next_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._next_predicate

    @next_predicate.setter
    def next_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._next_predicate = value
        self._next_predicate_dict = value.to_dict() if value is not None else None

    @property
    @configurable(required=False, envelope=True, default=None)
    def previous_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._previous_predicate

    @previous_predicate.setter
    def previous_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._previous_predicate = value
        self._previous_predicate_dict = value.to_dict() if value is not None else None

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        if not self._has_initial_position or not self._has_valid_position:
            return False
        if not super().is_complete:
            return False
        return self.has_reached_final_position

    def _current_y(self) -> float:
        return self.initial_y + self.current_delta_y

    def _current_z(self) -> float:
        return self.initial_z + self.current_delta_z

    def _forward_limit_y(self) -> float:
        return min(self.initial_y + self.distance, self.max_y)

    def _initialize_position(self, context: PredicateContext) -> bool:
        if context.pellet_device is None or context.pellet_device.last_dcs_set_position is None:
            return False
        self.initial_y = context.pellet_device.last_dcs_set_position.y
        self.initial_z = context.pellet_device.last_dcs_set_position.z
        self.current_delta_y = 0.0
        self.current_delta_z = 0.0
        self.current_step_count = 0
        self.has_reached_final_position = False
        self._has_initial_position = True
        self._has_valid_position = True
        return True

    def _capture_step_baseline(self, progress) -> Dict[str, Any]:
        if progress is None:
            return {}
        return {
            "session_count": progress.session_count,
            "pellets_presented": progress.pellets_presented,
            "pellets_consumed": progress.pellets_consumed,
            "successful_reaches": progress.successful_reaches,
            "total_reaches": progress.total_reaches,
            "time_in_training": progress.time_in_training,
            "phase_attempts": progress.phase_attempts,
        }

    def _start_new_step(self, context: PredicateContext) -> None:
        self._step_baseline = self._capture_step_baseline(context.progress)
        self._recreate_active_predicates()

    def _clone_predicate(self, predicate_dict, configured_predicate):
        if predicate_dict is None:
            return None
        try:
            return TrainingPredicate.from_dict(predicate_dict)
        except Exception:
            return configured_predicate

    def _recreate_active_predicates(self) -> None:
        self._active_next_predicate = self._clone_predicate(
            self._next_predicate_dict, self._next_predicate)
        self._active_previous_predicate = self._clone_predicate(
            self._previous_predicate_dict, self._previous_predicate)

        self._copy_predicate_path(self._active_next_predicate, self._next_predicate)
        self._copy_predicate_path(self._active_previous_predicate, self._previous_predicate)

    def _copy_predicate_path(self, active_predicate, configured_predicate) -> None:
        if active_predicate is None:
            return
        if configured_predicate is not None and hasattr(configured_predicate, "_target_path"):
            if hasattr(active_predicate, "_target_path"):
                active_predicate._target_path = configured_predicate._target_path

    def _step_context(self, context: PredicateContext) -> PredicateContext:
        if self._step_baseline is None or context.progress is None:
            return context
        return PredicateContext(
            progress=_StepRelativeProgress(context.progress, self._step_baseline),
            algorithm=context.algorithm,
            pellet_device=context.pellet_device,
            tunnel_device=context.tunnel_device,
            capture_analysis_result=context.capture_analysis_result,
        )

    def _move_forward(self, context: PredicateContext) -> bool:
        current_y = self._current_y()
        new_y = min(self._forward_limit_y(), current_y + self.increment)
        y_delta_moved = new_y - current_y
        if y_delta_moved <= _FLOAT_COMPARISON:
            self.has_reached_final_position = True
            return False
        new_z = self._current_z() + self.z_increment
        context.pellet_device.set_dcs_y(new_y)
        context.pellet_device.set_dcs_z(new_z)
        self.current_delta_y = new_y - self.initial_y
        self.current_delta_z = new_z - self.initial_z
        self.current_step_count += 1
        if abs(new_y - self._forward_limit_y()) <= _FLOAT_COMPARISON:
            self.has_reached_final_position = True
        return True

    def _move_backward(self, context: PredicateContext) -> bool:
        current_y = self._current_y()
        new_y = max(self.initial_y, current_y - self.increment)
        if abs(new_y - current_y) <= _FLOAT_COMPARISON:
            return False
        new_z = self._current_z() - self.z_increment
        context.pellet_device.set_dcs_y(new_y)
        context.pellet_device.set_dcs_z(new_z)
        self.current_delta_y = new_y - self.initial_y
        self.current_delta_z = new_z - self.initial_z
        self.current_step_count -= 1
        self.has_reached_final_position = False
        return True

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "increment": self._increment,
            "distance": self._distance,
            "zIncrement": self._z_increment,
            "maxY": self._max_y,
            "hasNextPredicate": self._next_predicate is not None,
            "hasPreviousPredicate": self._previous_predicate is not None,
            "initialY": self.initial_y,
            "initialZ": self.initial_z,
            "currentDeltaY": self.current_delta_y,
            "currentDeltaZ": self.current_delta_z,
            "currentStepCount": self.current_step_count,
            "hasReachedFinalPosition": self.has_reached_final_position,
            "hasInitialPosition": self._has_initial_position,
            "hasValidPosition": self._has_valid_position,
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self.initial_y = 0.0
        self.initial_z = 0.0
        self.current_delta_y = 0.0
        self.current_delta_z = 0.0
        self.current_step_count = 0
        self.has_reached_final_position = False
        self._has_initial_position = False
        self._has_valid_position = False
        self._initialize_position(context)
        self._start_new_step(context)

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if context.pellet_device is None or context.pellet_device.last_dcs_set_position is None:
            self._has_valid_position = False
            self._emit_short_circuit(phase,
                                     "missing_pellet_device" if context.pellet_device is None else "missing_position")
            return
        if not self._has_initial_position:
            self._initialize_position(context)
            self._start_new_step(context)
            self._emit_state_changed(phase)
            return
        context.pellet_device.set_dcs_y(self.initial_y + self.current_delta_y)
        context.pellet_device.set_dcs_z(self.initial_z + self.current_delta_z)
        self._has_valid_position = True

        if self._step_baseline is None:
            self._start_new_step(context)
        else:
            self._recreate_active_predicates()

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete
        old_delta_y = self.current_delta_y
        old_delta_z = self.current_delta_z
        old_step_count = self.current_step_count
        self._eval_started_emitted = False
        self._emit_evaluation_started(phase)

        if context.progress is None:
            self._emit_short_circuit(phase, "missing_progress")
            return False

        if context.pellet_device is None:
            self._emit_short_circuit(phase, "missing_pellet_device")
            return False

        if context.pellet_device.last_dcs_set_position is None:
            self._has_valid_position = False
            self._emit_short_circuit(phase, "missing_position")
            return False

        if not self._has_initial_position and not self._initialize_position(context):
            self._emit_short_circuit(phase, "invalid_position")
            return False

        self._has_valid_position = True

        if self._step_baseline is None:
            self._start_new_step(context)

        super().evaluate(phase, context)

        step_ctx = self._step_context(context)
        next_fires = (self._active_next_predicate is not None
                      and self._active_next_predicate.evaluate(phase, step_ctx))
        previous_fires = (self._active_previous_predicate is not None
                          and self._active_previous_predicate.evaluate(phase, step_ctx))

        moved = False
        movement_direction = None
        if next_fires:
            moved = self._move_forward(context)
            if moved:
                movement_direction = "forward"
        elif previous_fires:
            moved = self._move_backward(context)
            if moved:
                movement_direction = "backward"

        if moved:
            self._start_new_step(context)

        state_changed = (old_delta_y != self.current_delta_y or
                        old_delta_z != self.current_delta_z or
                        old_step_count != self.current_step_count)

        if state_changed:
            self._emit_state_changed(phase, {
                "nextPredicateResult": next_fires,
                "previousPredicateResult": previous_fires,
                "movementDirection": movement_direction,
            })

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "initial_y": self.initial_y,
            "initial_z": self.initial_z,
            "current_delta_y": self.current_delta_y,
            "current_delta_z": self.current_delta_z,
            "current_step_count": self.current_step_count,
            "has_reached_final_position": self.has_reached_final_position,
            "has_initial_position": self._has_initial_position,
            "step_baseline": self._step_baseline,
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self.initial_y = data.get("initial_y", 0.0)
        self.initial_z = data.get("initial_z", 0.0)
        self.current_delta_y = data.get("current_delta_y", 0.0)
        self.current_delta_z = data.get("current_delta_z", 0.0)
        self.current_step_count = data.get("current_step_count", 0)
        self.has_reached_final_position = data.get("has_reached_final_position", False)
        self._has_initial_position = data.get(
            "has_initial_position",
            any(key in data for key in ("initial_y", "initial_z", "current_delta_y", "current_delta_z"))
        )
        self._step_baseline = data.get("step_baseline")

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "increment": self.increment,
            "distance": self.distance,
            "z_increment": self.z_increment,
            "max_y": self.max_y,
        }
        if self._next_predicate is not None:
            result["next_predicate"] = self._next_predicate.to_dict()
        if self._previous_predicate is not None:
            result["previous_predicate"] = self._previous_predicate.to_dict()
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        next_predicate = TrainingPredicate.from_dict(data.get("next_predicate"))
        previous_predicate = TrainingPredicate.from_dict(data.get("previous_predicate"))
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(data["increment"], data["distance"], data["z_increment"], data["max_y"],
                   next_predicate, previous_predicate, predicate, min_trials_to_complete)


class CompoundTrainingAction(TrainingAction):
    def __init__(self, actions: Optional[List[TrainingAction]] = None,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._actions: List[TrainingAction] = list(actions) if actions else []
        self._active_index: int = 0

    @property
    @configurable(envelope=True)
    def actions(self) -> Tuple[TrainingAction, ...]:
        return tuple(self._actions)

    @actions.setter
    def actions(self, value: List[TrainingAction]) -> None:
        self._actions = list(value)
        self._active_index = 0

    def add_action(self, action: TrainingAction) -> None:
        self._actions.append(action)

    def remove_action(self, index: int) -> None:
        self._actions.pop(index)

    def clear_actions(self) -> None:
        self._actions.clear()
        self._active_index = 0

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        if not super().is_complete:
            return False
        if not self._actions:
            return True
        if self._active_index < len(self._actions) - 1:
            return False
        return self._actions[-1].is_complete

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "activeIndex": self._active_index,
            "actionCount": len(self._actions),
            "activeChildPath": self._actions[self._active_index]._target_path if self._actions and self._active_index < len(self._actions) else None,
            "activeChildType": self._actions[self._active_index].__class__.__name__ if self._actions and self._active_index < len(self._actions) else None,
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        if self._actions:
            self._actions[0].begin(phase, context)

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if self._actions and self._active_index < len(self._actions):
            self._actions[self._active_index].resume(phase, context)

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete

        super().evaluate(phase, context)

        if not self._actions:
            self._emit_short_circuit(phase, "no_child_actions")
            return True

        active_action = self._actions[self._active_index]

        active_action.evaluate(phase, context)

        if active_action.is_complete:
            if self._active_index < len(self._actions) - 1:
                self._active_index += 1
                self._actions[self._active_index].begin(phase, context)

                self._emit_state_changed(phase)
                self._emit_completion_changed(phase, old_is_complete, self.is_complete)
                return False

            self._emit_completion_changed(phase, old_is_complete, self.is_complete)
            return True
        else:
            if not active_action.has_progress:
                self._emit_short_circuit(phase, "current_action_incomplete")

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "active_index": self._active_index,
            "action_progress": [action.serialize_progress() for action in self._actions]
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self._active_index = data["active_index"]
        action_progress = data["action_progress"]
        for idx, action in enumerate(self._actions):
            if idx < len(action_progress):
                action.deserialize_progress(action_progress[idx])

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "actions": [action.to_dict() for action in self._actions]
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        actions = [TrainingAction.from_dict(entry) for entry in data["actions"]]
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(actions, predicate, min_trials_to_complete)


class ShuffledPropertyEnabledAction(TrainingAction):
    def __init__(self, property_path: str, value: bool, count: int, percentage: float,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0,
                 linked_property_paths: Optional[List[List[str]]] = None,
                 conditional_providers: Optional[List[Tuple[List[str], ValueProvider]]] = None):
        super().__init__(predicate, min_trials_to_complete)
        if not isinstance(property_path, list):
            self._property_path: List[str] = property_path.split(".")
        else:
            self._property_path = property_path
        self._value = value
        self._count = count
        self._percentage = percentage
        self._linked_property_paths: List[List[str]] = linked_property_paths if linked_property_paths else []
        self._conditional_providers: List[Tuple[List[str], ValueProvider]] = (
            conditional_providers if conditional_providers else [])
        self._provider = BooleanValueProvider(value, count, percentage, shuffle=True)

    @property
    @configurable()
    def property_path(self) -> List[str]:
        """Runtime context path to the property toggled each trial."""
        return self._property_path

    @property_path.setter
    def property_path(self, value: List[str]) -> None:
        self._property_path = value

    @property
    @configurable()
    def value(self) -> bool:
        return self._value

    @value.setter
    def value(self, val: bool) -> None:
        self._value = val

    @property
    @configurable()
    def count(self) -> int:
        return self._count

    @count.setter
    def count(self, value: int) -> None:
        self._count = value

    @property
    @configurable()
    def percentage(self) -> float:
        return self._percentage

    @percentage.setter
    def percentage(self, value: float) -> None:
        self._percentage = value

    @property
    @configurable(required=False)
    def linked_property_paths(self) -> List[List[str]]:
        return self._linked_property_paths

    @linked_property_paths.setter
    def linked_property_paths(self, value: List[List[str]]) -> None:
        self._linked_property_paths = value

    @property
    @configurable(required=False)
    def conditional_providers(self) -> List[Tuple[List[str], ValueProvider]]:
        """Each entry is a [propertyPath, valueProviderEnvelope] pair applied when the primary value matches."""
        return self._conditional_providers

    @conditional_providers.setter
    def conditional_providers(self, value: List[Tuple[List[str], ValueProvider]]) -> None:
        self._conditional_providers = value

    def _apply_provider_value_internal(self, context: PredicateContext, next_value: bool) -> None:
        result = context.resolve_path_parent(self.property_path)
        if result is not None:
            setattr(result[0], result[1], next_value)
        else:
            logger.warning(f"failed to resolve property path {self.property_path} on context")
        for linked_path in self.linked_property_paths:
            linked_result = context.resolve_path_parent(linked_path)
            if linked_result is not None:
                setattr(linked_result[0], linked_result[1], next_value)
            else:
                logger.warning(f"failed to resolve linked property path {linked_path} on context")
        if next_value == self.value:
            for cp_path, cp_provider in self.conditional_providers:
                cp_result = context.resolve_path_parent(cp_path)
                if cp_result is not None:
                    setattr(cp_result[0], cp_result[1], cp_provider.get_next_value())
                else:
                    logger.warning(f"failed to resolve conditional provider path {cp_path} on context")

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "propertyPath": self._property_path,
            "value": self._value,
            "count": self._count,
            "percentage": self._percentage,
            "linkedPropertyPaths": self._linked_property_paths,
            "conditionalProvidersCount": len(self._conditional_providers),
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        next_value = self._provider.get_next_value()
        self._apply_provider_value_internal(context, next_value)

        self._emit_state_changed(phase, {"appliedValue": next_value})

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)
        next_value = self._provider.get_next_value()
        self._apply_provider_value_internal(context, next_value)

        self._emit_state_changed(phase, {"appliedValue": next_value})
        return False

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "property_path": self.property_path,
            "value": self.value,
            "count": self.count,
            "percentage": self.percentage,
        }
        if self.linked_property_paths:
            result["linked_property_paths"] = self.linked_property_paths
        if self.conditional_providers:
            result["conditional_providers"] = [
                {"property_path": cp_path, "value_provider": cp_provider.to_dict()}
                for cp_path, cp_provider in self.conditional_providers
            ]
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        linked_property_paths = data.get("linked_property_paths", [])
        conditional_providers = [
            (entry["property_path"], class_from_dict(entry["value_provider"]))
            for entry in data.get("conditional_providers", [])
        ]
        return cls(data["property_path"], data["value"], data["count"], data["percentage"],
                   predicate, min_trials_to_complete, linked_property_paths, conditional_providers)


class RepeatedTrainingAction(TrainingAction):
    def __init__(self, action: TrainingAction, value_provider: ValueProvider, property_path: Union[List[str], str],
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)

        if isinstance(property_path, list):
            self._property_path: List[str] = property_path
        else:
            self._property_path = property_path.split(".")

        self._value_provider = value_provider
        self._action_dict = action.to_dict()
        self._current_action: TrainingAction = action
        self._values_consumed: int = 0
        self._last_applied_value = None

    @property
    @configurable()
    def property_path(self) -> List[str]:
        """Runtime context path where each value from the provider is written."""
        return self._property_path

    @property_path.setter
    def property_path(self, value: List[str]) -> None:
        self._property_path = value

    @property
    @configurable(envelope=True)
    def action(self) -> TrainingAction:
        return self._current_action

    @action.setter
    def action(self, value: TrainingAction) -> None:
        self._current_action = value
        self._action_dict = value.to_dict()

    @property
    @configurable(envelope=True)
    def value_provider(self) -> ValueProvider:
        return self._value_provider

    @value_provider.setter
    def value_provider(self, value: ValueProvider) -> None:
        self._value_provider = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        return self.is_iteration_complete and not self._value_provider.has_next_value()

    @property
    def is_iteration_complete(self) -> bool:
        return self._current_action.is_complete and super().is_complete

    def _apply_next_value(self, context: PredicateContext) -> None:
        self._last_applied_value = self._value_provider.get_next_value()
        self._values_consumed += 1
        result = context.resolve_path_parent(self.property_path)
        if result is not None:
            setattr(result[0], result[1], self._last_applied_value)

    def _assign_child_paths(self, child_action: TrainingAction) -> None:
        if self._target_path is not None:
            child_action._target_path = f"{self._target_path}.currentAction"
            if child_action.predicate is not None:
                child_action.predicate._target_path = f"{child_action._target_path}.predicate"

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "propertyPath": self._property_path,
            "childActionType": self._current_action.__class__.__name__,
            "valueProviderType": self._value_provider.__class__.__name__,
            "valuesConsumed": self._values_consumed,
            "lastAppliedValue": self._last_applied_value,
            "hasNextValue": self._value_provider.has_next_value(),
            "childTargetPath": self._current_action._target_path,
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self._apply_next_value(context)
        self._assign_child_paths(self._current_action)
        self._current_action.begin(phase, context)

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if self._last_applied_value is not None:
            result = context.resolve_path_parent(self.property_path)
            if result is not None:
                setattr(result[0], result[1], self._last_applied_value)
        self._assign_child_paths(self._current_action)
        self._current_action.resume(phase, context)

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete

        super().evaluate(phase, context)

        self._current_action.evaluate(phase, context)

        if self.is_iteration_complete and self._value_provider.has_next_value():
            self._apply_next_value(context)
            self._current_action = TrainingAction.from_dict(self._action_dict)  # type: ignore
            self._assign_child_paths(self._current_action)
            self._current_action.begin(phase, context)

            self._emit_state_changed(phase)
        elif self.is_iteration_complete and not self._value_provider.has_next_value():
            self._emit_short_circuit(phase, "value_provider_exhausted")

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "values_consumed": self._values_consumed,
            "last_applied_value": self._last_applied_value,
            "action_progress": self._current_action.serialize_progress()
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        values_consumed = data.get("values_consumed", 0)
        for _ in range(values_consumed):
            if self._value_provider.has_next_value():
                self._value_provider.get_next_value()
        self._values_consumed = values_consumed
        self._last_applied_value = data.get("last_applied_value")
        if values_consumed > 1:
            self._current_action = TrainingAction.from_dict(self._action_dict)  # type: ignore
        self._assign_child_paths(self._current_action)
        self._current_action.deserialize_progress(data.get("action_progress", {}))

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "action": self._action_dict,
            "value_provider": self._value_provider.to_dict(),
            "property_path": self.property_path
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        action = TrainingAction.from_dict(data["action"])
        value_provider = class_from_dict(data["value_provider"])
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(action, value_provider, data["property_path"], predicate, min_trials_to_complete)


class PythonTrainingAction(TrainingAction):
    def __init__(self, python_code: str, predicate: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._python_code = python_code
        self._compiled_code = None
        self._state: Dict[str, Any] = {}

    @property
    @configurable()
    def python_code(self) -> str:
        return self._python_code

    @python_code.setter
    def python_code(self, value: str) -> None:
        self._python_code = value
        self._compiled_code = None

    @property
    def _code_hash(self) -> str:
        return hashlib.sha256(self._python_code.encode()).hexdigest()[:16]

    def _ensure_compiled(self) -> None:
        if self._compiled_code is None:
            self._compiled_code = compile(self._python_code, "<PythonTrainingAction>", "exec")

    def _get_state_data(self, phase: TrainingPhaseProtocol) -> Dict[str, Any]:
        return {
            "pythonCodeHash": self._code_hash,
            "stateKeys": list(self._state.keys()),
        }

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self._state = {}
        self._ensure_compiled()

        self._emit_state_changed(phase)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        self._ensure_compiled()

        self._emit_state_changed(phase)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        old_is_complete = self.is_complete
        old_state_keys = set(self._state.keys())

        super().evaluate(phase, context)
        self._ensure_compiled()
        namespace = {"context": context, "phase": phase, "state": self._state}
        error_occurred = False
        error_type = None
        error_message = None
        try:
            exec(self._compiled_code, namespace)
        except Exception as exc:
            logger.error("PythonTrainingAction error evaluating: %s", self._python_code, exc_info=True)
            error_occurred = True
            error_type = exc.__class__.__name__
            error_message = str(exc)

        if error_occurred:
            self._emit_short_circuit(phase, "python_exception", {
                "errorType": error_type,
                "message": error_message,
            })

        new_state_keys = set(self._state.keys())
        if old_state_keys != new_state_keys:
            self._emit_state_changed(phase, {
                "stateKeysBefore": list(old_state_keys),
                "stateKeysAfter": list(new_state_keys),
            })

        self._emit_completion_changed(phase, old_is_complete, self.is_complete)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress["state"] = self._state
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self._state = data.get("state", {})

    def _to_dict(self) -> Dict[str, Any]:
        result = {"python_code": self.python_code}
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        python_code = data["python_code"]
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(python_code, predicate, min_trials_to_complete)
