import uuid
from enum import IntEnum
from typing import List, Dict, Any, Optional, Callable

from autotrainer.core import get_verbose_logger
from typing_extensions import Self
from autotrainer.api import ApiEventKind

import humps

from .configurable import configurable
from .event_slot import EventSlot
from .event import (
    ApiEventSource,
    TrainingPhaseApiEvent,
    TrainingPhaseApiEventKind,
    TrainingProgressApiEvent,
    TrainingProgressApiEventKind,
)
from .training_protocols import PredicateContext, TrainingPhaseProtocol, TrainingActionProtocol, \
    TrainingPredicateProtocol
from .training_predicate import TrainingPredicate, CompoundPredicate
from .training_action import (TrainingAction, CompoundTrainingAction, RepeatedTrainingAction,
                              ReachDistanceMultiAction)
from .training_progress import TrainingProgress, ProgressKey

logger = get_verbose_logger(__name__)


class SessionResult(IntEnum):
    NONE = 0
    FALLBACK = 10
    ADVANCE = 20


class TrainingPhase(TrainingPhaseProtocol, ApiEventSource):
    def __init__(self, phase_id: Optional[str] = None):
        self._phase_id = phase_id or str(uuid.uuid4())
        self._name: str = ""
        self._description: str = ""
        self._fallback_condition: Optional[TrainingPredicateProtocol] = None
        self._advance_condition: Optional[TrainingPredicateProtocol] = None
        self._session_actions: List[TrainingActionProtocol] = []

        self._send_x: Optional[float] = None
        self._send_y: Optional[float] = None
        self._send_z: Optional[float] = None

        self._is_pellet_delivery_enabled: bool = False

        self._use_magnet_baseline_intensity: bool = False
        self._magnet_intensity: Optional[float] = None

        self._is_pellet_cover_enabled: bool = False

        self._is_pellet_shift_enabled: bool = False

        self._is_auto_clamp_enabled: bool = False
        self._auto_clamp_no_activity_release_delay: float = 0.0
        self._auto_clamp_release_load_count: int = 0

        self._version_id: int = 1
        self._plan_id: Optional[str] = None

        self._progress = TrainingProgress()

        self._would_advance: bool = False
        self._would_fallback: bool = False

        self.property_changed = EventSlot()

        self._progress_property_listener = None

    @property
    def phase_id(self) -> str:
        return self._phase_id

    @property
    @configurable(required=False, default=0)
    def version_id(self) -> int:
        return self._version_id

    @version_id.setter
    def version_id(self, value: int) -> None:
        self._version_id = value

    @property
    @configurable()
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    @configurable()
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value

    @property
    @configurable(required=False, envelope=True, aliases=["fallback", "fallback condition"], default=None)
    def fallback_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._fallback_condition

    @fallback_predicate.setter
    def fallback_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._fallback_condition = value
        self._assign_paths()

    @property
    @configurable(required=False, envelope=True, aliases=["advance", "advance condition"], default=None)
    def advance_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._advance_condition

    @advance_predicate.setter
    def advance_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._advance_condition = value
        self._assign_paths()

    @property
    @configurable(required=False, envelope=True, aliases=["trial actions", "actions"], default=[])
    def session_actions(self) -> List[TrainingActionProtocol]:
        return self._session_actions

    @session_actions.setter
    def session_actions(self, value: List[Callable[[Self, PredicateContext], None]]) -> None:
        self._session_actions = value
        self._assign_paths()

    @property
    def progress(self) -> TrainingProgress:
        return self._progress

    @progress.setter
    def progress(self, value: TrainingProgress) -> None:
        old_progress = self._progress
        self._progress = self._on_property_changed("progress", value, self._progress)

        if old_progress != value:
            if self._progress_property_listener is not None and old_progress is not None:
                old_progress.property_changed -= self._progress_property_listener

            self._progress_property_listener = self._on_progress_property_changed
            if self._progress is not None:
                self._progress.property_changed += self._progress_property_listener

    @property
    @configurable(required=False, aliases=["pellet x", "pellet send x"], default=None)
    def send_x(self) -> Optional[float]:
        return self._send_x

    @send_x.setter
    def send_x(self, value: Optional[float]) -> None:
        self._send_x = value

    @property
    @configurable(required=False, aliases=["pellet y", "pellet send y"], default=None)
    def send_y(self) -> Optional[float]:
        return self._send_y

    @send_y.setter
    def send_y(self, value: Optional[float]) -> None:
        self._send_y = value

    @property
    @configurable(required=False, aliases=["pellet z", "pellet send z"], default=None)
    def send_z(self) -> Optional[float]:
        return self._send_z

    @send_z.setter
    def send_z(self, value: Optional[float]) -> None:
        self._send_z = value

    @property
    @configurable(required=False, aliases=["pellet delivery"], default=False)
    def is_pellet_delivery_enabled(self) -> bool:
        return self._is_pellet_delivery_enabled

    @is_pellet_delivery_enabled.setter
    def is_pellet_delivery_enabled(self, value: bool) -> None:
        self._is_pellet_delivery_enabled = value

    @property
    @configurable(required=False, aliases=["pellet cover", "cover"], default=False)
    def is_pellet_cover_enabled(self) -> bool:
        return self._is_pellet_cover_enabled

    @is_pellet_cover_enabled.setter
    def is_pellet_cover_enabled(self, value: bool) -> None:
        self._is_pellet_cover_enabled = value

    @property
    @configurable(required=False, aliases=["magnet baseline", "baseline", "baseline intensity"], default=False)
    def use_magnet_baseline_intensity(self) -> bool:
        """If True, takes priority over any magnet_intensity value."""
        return self._use_magnet_baseline_intensity

    @use_magnet_baseline_intensity.setter
    def use_magnet_baseline_intensity(self, value: bool) -> None:
        self._use_magnet_baseline_intensity = value

    @property
    @configurable(required=False, aliases=["magnet intensity", "head intensity", "head magnet"], default=None)
    def magnet_intensity(self) -> Optional[float]:
        return self._magnet_intensity

    @magnet_intensity.setter
    def magnet_intensity(self, value: Optional[float]) -> None:
        self._magnet_intensity = value

    @property
    @configurable(required=False, aliases=["pellet shift", "send location shift"], default=False)
    def is_pellet_shift_enabled(self) -> bool:
        return self._is_pellet_shift_enabled

    @is_pellet_shift_enabled.setter
    def is_pellet_shift_enabled(self, value: bool) -> None:
        self._is_pellet_shift_enabled = value

    @property
    @configurable(required=False, aliases=["head clamp", "head fixation", "auto-clamp"], default=False)
    def is_auto_clamp_enabled(self) -> bool:
        return self._is_auto_clamp_enabled

    @is_auto_clamp_enabled.setter
    def is_auto_clamp_enabled(self, value: bool) -> None:
        self._is_auto_clamp_enabled = value

    @property
    @configurable(required=False, aliases=["release delay", "head fixation duration"], default=2.0)
    def auto_clamp_no_activity_release_delay(self) -> float:
        return self._auto_clamp_no_activity_release_delay

    @auto_clamp_no_activity_release_delay.setter
    def auto_clamp_no_activity_release_delay(self, value: float) -> None:
        self._auto_clamp_no_activity_release_delay = value

    @property
    @configurable(required=False, default=5)
    def auto_clamp_release_load_count(self) -> int:
        return self._auto_clamp_release_load_count

    @auto_clamp_release_load_count.setter
    def auto_clamp_release_load_count(self, value: int) -> None:
        self._auto_clamp_release_load_count = value

    @property
    def would_advance(self) -> bool:
        return self._would_advance

    @property
    def would_fallback(self) -> bool:
        return self._would_fallback

    def enter(self, context: PredicateContext, is_resume: bool = False) -> None:
        plan_id = self._plan_id

        if not is_resume:
            pellet_location = None
            if context.pellet_device is not None and context.pellet_device.last_dcs_set_position is not None:
                location = context.pellet_device.last_dcs_set_position
                pellet_location = [location.x, location.y, location.z]

            self._emit_api_event(
                ApiEventKind.protocolProgressEvent,
                TrainingProgressApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingProgressApiEventKind.ATTEMPT_STARTED,
                    data={
                        "phaseId": self.phase_id,
                        "attempt": self.progress.phase_attempts + 1,
                        "pelletStartLocation": pellet_location,
                    },
                )
            )

        if context.algorithm is not None:
            context.algorithm.reset_configuration()
            context.algorithm.pellet_delivery_enabled = self.is_pellet_delivery_enabled
            context.algorithm.pellet_cover_enabled = self.is_pellet_cover_enabled
            context.algorithm.intersession_pellet_shift_enabled = self.is_pellet_shift_enabled

            context.algorithm.head_fixation_enabled = self.is_auto_clamp_enabled

            if self.auto_clamp_no_activity_release_delay > 0.0:
                context.algorithm.auto_clamp_no_activity_release_delay = self.auto_clamp_no_activity_release_delay

            if self._auto_clamp_release_load_count > 0:
                context.algorithm.auto_clamp_release_load_count = self._auto_clamp_release_load_count

        if context.pellet_device is not None:
            if self.send_x is not None:
                context.pellet_device.set_dcs_x(self.send_x)
            if self.send_y is not None:
                context.pellet_device.set_dcs_y(self.send_y)
            if self.send_z is not None:
                context.pellet_device.set_dcs_z(self.send_z)

        if context.tunnel_device is not None:
            if self._use_magnet_baseline_intensity and context.algorithm is not None:
                context.tunnel_device.update_head_magnet_intensity(context.algorithm.baseline_intensity)
            elif self.magnet_intensity is not None:
                context.tunnel_device.update_head_magnet_intensity(self.magnet_intensity)

        if not is_resume:
            if context.pellet_device is not None and context.pellet_device.last_dcs_set_position is not None:
                location = (context.pellet_device.last_dcs_set_position.x,
                            context.pellet_device.last_dcs_set_position.y,
                            context.pellet_device.last_dcs_set_position.z)
            else:
                location = None

            self.progress = TrainingProgress(self.progress.phase_attempts + 1, location)
            self._begin_session_actions(context)
        else:
            if context.pellet_device is not None and self.progress.pellet_start_location is not None:
                context.pellet_device.set_dcs_x(self.progress.pellet_start_location[0])
                context.pellet_device.set_dcs_y(self.progress.pellet_start_location[1])
                context.pellet_device.set_dcs_z(self.progress.pellet_start_location[2])
            self._resume_session_actions(context)

        config_data = {
            "sendX": self.send_x,
            "sendY": self.send_y,
            "sendZ": self.send_z,
            "isPelletDeliveryEnabled": self.is_pellet_delivery_enabled,
            "isPelletCoverEnabled": self.is_pellet_cover_enabled,
            "isPelletShiftEnabled": self.is_pellet_shift_enabled,
            "isAutoClampEnabled": self.is_auto_clamp_enabled,
            "autoClampNoActivityReleaseDelay": self.auto_clamp_no_activity_release_delay,
            "autoClampReleaseLoadCount": self.auto_clamp_release_load_count,
            "useMagnetBaselineIntensity": self.use_magnet_baseline_intensity,
            "magnetIntensity": self.magnet_intensity,
        }

        self._emit_api_event(
            ApiEventKind.protocolPhaseEvent,
            TrainingPhaseApiEvent(
                target_id=self.phase_id,
                event_type=TrainingPhaseApiEventKind.CONFIGURATION_APPLIED,
                data=config_data,
            )
        )

        if is_resume:
            self._emit_api_event(
                ApiEventKind.protocolPhaseEvent,
                TrainingPhaseApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingPhaseApiEventKind.RESUMED,
                    data={
                        "planId": plan_id,
                        "phaseId": self.phase_id,
                    },
                )
            )

        self._emit_api_event(
            ApiEventKind.protocolPhaseEvent,
            TrainingPhaseApiEvent(
                target_id=self.phase_id,
                event_type=TrainingPhaseApiEventKind.ENTERED,
                data={
                    "planId": plan_id,
                    "phaseId": self.phase_id,
                    "attempt": self.progress.phase_attempts,
                    "reason": "resume" if is_resume else "enter",
                },
            )
        )

        self._evaluate_predicates(context)

    def exit(self, context: PredicateContext) -> None:
        self._emit_api_event(
            ApiEventKind.protocolPhaseEvent,
            TrainingPhaseApiEvent(
                target_id=self.phase_id,
                event_type=TrainingPhaseApiEventKind.EXITED,
                data={
                    "planId": self._plan_id,
                    "phaseId": self.phase_id,
                },
            )
        )

    def session_started(self) -> None:
        self.progress.session_count += 1
        self.progress.progress_resumed()

        self._emit_api_event(
            ApiEventKind.protocolProgressEvent,
            TrainingProgressApiEvent(
                target_id=self.phase_id,
                event_type=TrainingProgressApiEventKind.TIMER_STARTED,
                data={
                    "phaseId": self.phase_id,
                    "timestamp": self.progress.timestamp.isoformat() if self.progress.timestamp else None,
                },
            )
        )

    def capture_ended(self) -> None:
        self.progress.progress_paused()

        self._emit_api_event(
            ApiEventKind.protocolProgressEvent,
            TrainingProgressApiEvent(
                target_id=self.phase_id,
                event_type=TrainingProgressApiEventKind.TIMER_PAUSED,
                data={
                    "phaseId": self.phase_id,
                    "timeInTraining": self.progress.time_in_training,
                },
            )
        )

    def session_ended(self, context: PredicateContext) -> SessionResult:
        self._evaluate_session_actions(context)

        return self._evaluate_predicates(context)

    def attach(self, context: PredicateContext):
        if self.progress.phase_attempts == 0 and context.pellet_device.last_dcs_set_position is not None:
            self.progress.pellet_start_location = context.pellet_device.last_dcs_set_position
            self.progress.pellet_current_location = context.pellet_device.last_dcs_set_position

    def _evaluate_predicates(self, context: PredicateContext) -> SessionResult:
        old_would_advance = self._would_advance
        old_would_fallback = self._would_fallback

        self._would_advance = self._on_property_changed("would_advance", self._should_advance(context),
                                                        self._would_advance)

        self._would_fallback = self._on_property_changed("would_fallback", self._should_fallback(context),
                                                         self._would_fallback)

        if old_would_advance != self._would_advance:
            self._emit_api_event(
                ApiEventKind.protocolPhaseEvent,
                TrainingPhaseApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingPhaseApiEventKind.ADVANCE_READINESS_CHANGED,
                    data={"wouldAdvance": self._would_advance},
                )
            )

        if old_would_fallback != self._would_fallback:
            self._emit_api_event(
                ApiEventKind.protocolPhaseEvent,
                TrainingPhaseApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingPhaseApiEventKind.FALLBACK_READINESS_CHANGED,
                    data={"wouldFallback": self._would_fallback},
                )
            )

        if self._would_advance:
            return SessionResult.ADVANCE

        if self._would_fallback:
            return SessionResult.FALLBACK

        return SessionResult.NONE

    def _begin_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.begin(self, context)

    def _resume_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.resume(self, context)

    def _evaluate_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.evaluate(self, context)

    def _should_fallback(self, context: PredicateContext) -> bool:
        # Check time elapsed too long without enough successful reaches and revert to the last phase, etc.
        context.progress = self.progress
        if self.fallback_predicate is not None:
            return self.fallback_predicate.evaluate(self, context)

        return False

    def _should_advance(self, context: PredicateContext) -> bool:
        context.progress = self.progress
        # Move to the next training phase when any required conditions are met
        if self.advance_predicate is not None:
            return self.advance_predicate.evaluate(self, context) and self._are_actions_complete()

        if any(action.has_progress for action in self.session_actions):
            return self._are_actions_complete()

        return False

    def _are_actions_complete(self):
        return all(((not action.has_progress) or action.is_complete) for action in self.session_actions)

    def _assign_predicate_path(self, predicate: Optional[TrainingPredicateProtocol], base_path: str) -> None:
        if predicate is None:
            return
        predicate._target_path = base_path
        if hasattr(predicate, "child") and predicate.child is not None:
            self._assign_predicate_path(predicate.child, f"{base_path}.child")
        if isinstance(predicate, CompoundPredicate):
            for idx, child_pred in enumerate(predicate.predicates):
                self._assign_predicate_path(child_pred, f"{base_path}.predicates[{idx}]")

    def _assign_action_path(self, action: TrainingActionProtocol, base_path: str) -> None:
        if action is None:
            return
        action._target_path = base_path
        if hasattr(action, "predicate") and action.predicate is not None:
            self._assign_predicate_path(action.predicate, f"{base_path}.predicate")
        if isinstance(action, ReachDistanceMultiAction):
            if action.next_predicate is not None:
                self._assign_predicate_path(action.next_predicate, f"{base_path}.nextPredicate")
            if action.previous_predicate is not None:
                self._assign_predicate_path(action.previous_predicate, f"{base_path}.previousPredicate")
        if isinstance(action, CompoundTrainingAction):
            for idx, child_action in enumerate(action._actions):
                self._assign_action_path(child_action, f"{base_path}.actions[{idx}]")
        if isinstance(action, RepeatedTrainingAction) and action._current_action is not None:
            self._assign_action_path(action._current_action, f"{base_path}.currentAction")

    def _assign_paths(self) -> None:
        if self._advance_condition is not None:
            self._assign_predicate_path(self._advance_condition, f"{self.phase_id}:advancePredicate")
        if self._fallback_condition is not None:
            self._assign_predicate_path(self._fallback_condition, f"{self.phase_id}:fallbackPredicate")
        for idx, action in enumerate(self._session_actions):
            self._assign_action_path(action, f"{self.phase_id}:sessionActions[{idx}]")

    def _on_progress_property_changed(self, property_name: str, new_value: Any, old_value: Any) -> None:
        if property_name == "session_count":
            delta = new_value - old_value if old_value is not None else new_value
            self._emit_api_event(
                ApiEventKind.protocolProgressEvent,
                TrainingProgressApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingProgressApiEventKind.SESSION_COUNT_CHANGED,
                    data={
                        "phaseId": self.phase_id,
                        "sessionCount": new_value,
                        "delta": delta,
                    },
                )
            )
        elif property_name in ("pellets_presented", "pellets_consumed", "successful_reaches", "total_reaches"):
            counter_name_map = {
                "pellets_presented": "pelletsPresented",
                "pellets_consumed": "pelletsConsumed",
                "successful_reaches": "successfulReaches",
                "total_reaches": "totalReaches",
            }
            delta = new_value - old_value if old_value is not None else new_value
            self._emit_api_event(
                ApiEventKind.protocolProgressEvent,
                TrainingProgressApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingProgressApiEventKind.COUNTER_CHANGED,
                    data={
                        "phaseId": self.phase_id,
                        "name": counter_name_map[property_name],
                        "value": new_value,
                        "delta": delta,
                    },
                )
            )
        elif property_name in ("pellet_start_location", "pellet_current_location"):
            location_name_map = {
                "pellet_start_location": "pelletStartLocation",
                "pellet_current_location": "pelletCurrentLocation",
            }
            self._emit_api_event(
                ApiEventKind.protocolProgressEvent,
                TrainingProgressApiEvent(
                    target_id=self.phase_id,
                    event_type=TrainingProgressApiEventKind.PELLET_LOCATION_CHANGED,
                    data={
                        "phaseId": self.phase_id,
                        "name": location_name_map[property_name],
                        "value": list(new_value) if new_value is not None else None,
                    },
                )
            )

    def _on_property_changed(self, property_name, new_value, old_value):
        if old_value == new_value:
            return old_value

        for listener in self.property_changed:
            listener(property_name, new_value, old_value)

        return new_value

    def serialize_progress(self) -> Dict[str, Any]:
        progress = self.progress.to_dict()

        progress[ProgressKey.PHASE_ID] = self.phase_id
        progress[ProgressKey.VERSION_ID] = self.version_id
        progress[ProgressKey.ACTION_CONTEXT] = [action.serialize_progress() for action in self.session_actions]

        return progress

    def deserialize_progress(self, progress_item: Dict[str, Any]) -> None:
        self.progress = TrainingProgress.from_dict(progress_item)

        if self.progress.action_context is not None:
            for idx, context in enumerate(self.progress.action_context):
                self.session_actions[idx].deserialize_progress(context)

        self._assign_paths()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON serialization"""
        data = {
            "phase_id": self.phase_id,
            "version_id": self.version_id,
            "name": self.name,
            "description": self.description,

            "fallback_predicate": self.fallback_predicate.to_dict() if self.fallback_predicate else None,
            "advance_predicate": self.advance_predicate.to_dict() if self.advance_predicate else None,
            "session_actions": [action.to_dict() for action in self.session_actions],

            "send_x": self.send_x,
            "send_y": self.send_y,
            "send_z": self.send_z,

            "is_pellet_delivery_enabled": self.is_pellet_delivery_enabled,
            "is_pellet_cover_enabled": self.is_pellet_cover_enabled,
            "use_magnet_baseline_intensity": self.use_magnet_baseline_intensity,
            "magnet_intensity": self.magnet_intensity,
            "is_pellet_shift_enabled": self.is_pellet_shift_enabled,
            "is_auto_clamp_enabled": self.is_auto_clamp_enabled,
            "auto_clamp_no_activity_release_delay": self.auto_clamp_no_activity_release_delay,
            "auto_clamp_release_load_count": self.auto_clamp_release_load_count
        }
        return humps.camelize(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Deserialize from dictionary"""
        data = humps.decamelize(data)
        phase = cls(data["phase_id"])
        phase.version_id = data.get("version_id", 0)
        phase.name = data["name"]
        phase.description = data["description"]

        phase.fallback_predicate = TrainingPredicate.from_dict(data.get("fallback_predicate", None))
        phase.advance_predicate = TrainingPredicate.from_dict(data.get("advance_predicate", None))
        if "session_actions" in data:
            phase.session_actions = [TrainingAction.from_dict(d) for d in data["session_actions"]]
        else:
            phase.session_actions = []

        phase.send_x = data.get("send_x", None)
        phase.send_y = data.get("send_y", None)
        phase.send_z = data.get("send_z", None)

        phase.is_pellet_delivery_enabled = data.get("is_pellet_delivery_enabled", False)
        phase.is_pellet_cover_enabled = data.get("is_pellet_cover_enabled", False)
        phase.use_magnet_baseline_intensity = data.get("use_magnet_baseline_intensity", False)
        phase.magnet_intensity = data.get("magnet_intensity", None)
        phase.is_pellet_shift_enabled = data.get("is_pellet_shift_enabled", False)
        phase.is_auto_clamp_enabled = data.get("is_auto_clamp_enabled", False)
        phase.auto_clamp_no_activity_release_delay = data.get("auto_clamp_no_activity_release_delay", 2.0)
        phase.auto_clamp_release_load_count = data.get("auto_clamp_release_load_count", 5)

        phase._assign_paths()

        return phase

    def status(self) -> str:
        status = ""

        return status

    def progress_status(self) -> str:
        return self.progress.status()
