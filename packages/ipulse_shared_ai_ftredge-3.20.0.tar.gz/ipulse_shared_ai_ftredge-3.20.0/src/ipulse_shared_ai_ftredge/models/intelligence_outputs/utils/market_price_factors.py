"""
Market Price Factor Models -- 4-Quadrant Framework for Investment Analysis.

Replaces the asymmetric drivers-only + risks-only model with a symmetrical
2x2 matrix that separates factors by LIKELIHOOD and DIRECTION:

+--------------+----------------------------+----------------------------+
|              | POSITIVE  (Upside)         | NEGATIVE  (Downside)       |
+--------------+----------------------------+----------------------------+
| >50% Likely  | DRIVERS                    | FRICTIONS                  |
| (Expected)   | Forces pushing price up    | Forces pulling price down  |
+--------------+----------------------------+----------------------------+
| <50% Likely  | OPPORTUNITIES              | RISKS                     |
| (Possible)   | Bull-case triggers         | Bear-case triggers         |
+--------------+----------------------------+----------------------------+

Scenario Construction
---------------------
  Base Case (Most Reasonable) = net( SUM Drivers  +  SUM Frictions )
                                 ^ positive values   ^ negative values

  Bull Case = Base Case  +  SUM( Opportunity.upside_impact_pct  x Probability )
  Bear Case = Base Case  +  SUM( Risk.downside_impact_pct       x Probability )
                                 ^ negative values, so this subtracts

Sign convention (consistent across all quadrants):
  - Upside fields are always  >= 0   (drivers, opportunities)
  - Downside fields are always <= 0   (frictions, risks)
  - Formulas use pure addition -- signs encode direction.

Category taxonomy
-----------------
Drivers and Frictions share the SAME category enum per asset class because
the same macro-force can exert upward OR downward pressure depending on
conditions (e.g., "macroeconomic" -> low rates = driver, high rates = friction).

Opportunities and Risks are discrete probabilistic events described by
event_name + probability (no category enum needed).
"""

from enum import StrEnum, auto
from typing import List, Optional, Union

from pydantic import BaseModel, Field


# ================================================================================
# 1.  CATEGORY ENUMS  (shared by Drivers AND Frictions within each asset class)
# ================================================================================

class AutoLower(StrEnum):
    """StrEnum whose auto() values are lower-case."""
    @staticmethod
    def _generate_next_value_(name, start, count, last_values):
        return name.lower()


# --------------------------- Equity ------------------------------------------
class EquityFactorCategory(AutoLower):
    """
    Factor categories for equity (stock) investments.
    Used identically for both Drivers (positive pressure) and Frictions (negative pressure).

    Universal categories (shared with all asset classes):
      - macroeconomic_and_macrofinancial -- real-economy conditions (GDP, inflation, employment) AND financial-system dynamics (credit cycles, yield curves, liquidity, debt levels)
      - political_and_geopolitical -- trade agreements/wars, sanctions, elections, regional conflicts
      - regulatory              -- regulatory changes, compliance burden, tax policy, antitrust

    Equity-specific categories:
      - competitive_positioning    -- market share, pricing power, moat width, brand strength, network effects
      - management_and_governance  -- CEO integrity, top talent, insider alignment, board quality, succession
      - capital_allocation          -- buybacks, dividends, M&A strategy, debt management, treasury policy
      - innovation_and_product     -- R&D breakthroughs, product launches, patents, technology advantages
      - operational_efficiency     -- margin structure, supply chain, cost optimization, capacity utilization
      - sector_and_industry        -- sector growth/decline, cyclicality, consolidation, structural shifts
    """
    # Universal
    MACROECONOMIC_AND_MACROFINANCIAL = auto()  # type: ignore
    POLITICAL_AND_GEOPOLITICAL = auto()  # type: ignore
    REGULATORY = auto()  # type: ignore
    # Equity-specific
    COMPETITIVE_POSITIONING = auto()  # type: ignore
    MANAGEMENT_AND_GOVERNANCE = auto()  # type: ignore
    CAPITAL_ALLOCATION = auto()  # type: ignore
    INNOVATION_AND_PRODUCT = auto()  # type: ignore
    OPERATIONAL_EFFICIENCY = auto()  # type: ignore
    SECTOR_AND_INDUSTRY = auto()  # type: ignore


# --------------------------- Crypto ------------------------------------------
class CryptoFactorCategory(AutoLower):
    """
    Factor categories for cryptocurrency investments.
    Used identically for both Drivers (positive pressure) and Frictions (negative pressure).

    Universal categories:
      - macroeconomic_and_macrofinancial -- risk-on/off sentiment, real yields, dollar strength, liquidity cycles, credit conditions, debt-cycle positioning
      - political_and_geopolitical -- sanctions driving crypto adoption, geopolitical instability
      - regulatory              -- regulatory clarity/crackdowns, licensing frameworks, stablecoin rules

    Crypto-specific categories:
      - adoption_and_network    -- active addresses, TVL, developer activity, real-world utility, dApp usage
      - technology_and_protocol -- scalability upgrades, L2 solutions, interoperability, consensus changes
      - tokenomics_and_supply   -- halving events, token burns, staking rewards, vesting unlocks, inflation
      - ecosystem_and_defi      -- DeFi protocol growth, RWA tokenization, NFT integration, composability
      - institutional_participation -- ETF approvals, custody solutions, institutional allocations, treasury adoption
    """
    # Universal
    MACROECONOMIC_AND_MACROFINANCIAL = auto()  # type: ignore
    POLITICAL_AND_GEOPOLITICAL = auto()  # type: ignore
    REGULATORY = auto()  # type: ignore
    # Crypto-specific
    ADOPTION_AND_NETWORK = auto()  # type: ignore
    TECHNOLOGY_AND_PROTOCOL = auto()  # type: ignore
    TOKENOMICS_AND_SUPPLY = auto()  # type: ignore
    ECOSYSTEM_AND_DEFI = auto()  # type: ignore
    INSTITUTIONAL_PARTICIPATION = auto()  # type: ignore


# --------------------------- Commodity ---------------------------------------
class CommodityFactorCategory(AutoLower):
    """
    Factor categories for commodity investments.
    Used identically for both Drivers (positive pressure) and Frictions (negative pressure).

    Universal categories:
      - macroeconomic_and_macrofinancial -- global GDP, industrial output, emerging-market demand, currency effects, commodity-financing conditions, credit availability
      - political_and_geopolitical -- trade embargoes, sanctions, regional conflict disrupting supply routes
      - regulatory              -- environmental regulations, export controls, carbon pricing, subsidies

    Commodity-specific categories:
      - supply_dynamics         -- production capacity, cuts, disruptions, mine closures, infrastructure failures
      - demand_dynamics         -- industrial demand cycles, green-transition demand, seasonal patterns
      - producer_and_cartel     -- OPEC+ coordination, major-producer decisions, concentration effects
      - substitution_and_technology -- alternative materials/products, extraction tech, energy-transition effects
      - storage_and_logistics   -- inventory levels, strategic reserves, shipping costs, storage capacity
      - climate_and_environment -- weather patterns, natural disasters, crop yields, El Nino/La Nina, ESG shifts
    """
    # Universal
    MACROECONOMIC_AND_MACROFINANCIAL = auto()  # type: ignore
    POLITICAL_AND_GEOPOLITICAL = auto()  # type: ignore
    REGULATORY = auto()  # type: ignore
    # Commodity-specific
    SUPPLY_DYNAMICS = auto()  # type: ignore
    DEMAND_DYNAMICS = auto()  # type: ignore
    PRODUCER_AND_CARTEL = auto()  # type: ignore
    SUBSTITUTION_AND_TECHNOLOGY = auto()  # type: ignore
    STORAGE_AND_LOGISTICS = auto()  # type: ignore
    CLIMATE_AND_ENVIRONMENT = auto()  # type: ignore


# --------------------------- Index -------------------------------------------
class IndexFactorCategory(AutoLower):
    """
    Factor categories for index and index-tracking instrument investments.
    Used identically for both Drivers (positive pressure) and Frictions (negative pressure).

    Universal categories:
      - macroeconomic_and_macrofinancial -- aggregate GDP growth, rate environment, inflation expectations, financial conditions indices, credit spreads, systemic leverage
      - political_and_geopolitical -- broad market impact of geopolitical events, trade policy
      - regulatory              -- cross-sector regulatory trends, tax policy affecting equities broadly

    Index-specific categories:
      - constituent_fundamentals        -- aggregate earnings, revenue growth, margin trends across constituents
      - sector_rotation_and_thematic    -- rotation into/out of index-heavy sectors, thematic momentum
      - capital_flows                   -- passive fund inflows, pension allocation, retail participation, ETF flows
      - market_structure                -- index reconstitution, inclusion/exclusion events, methodology changes
    """
    # Universal
    MACROECONOMIC_AND_MACROFINANCIAL = auto()  # type: ignore
    POLITICAL_AND_GEOPOLITICAL = auto()  # type: ignore
    REGULATORY = auto()  # type: ignore
    # Index-specific
    CONSTITUENT_FUNDAMENTALS = auto()  # type: ignore
    SECTOR_ROTATION_AND_THEMATIC = auto()  # type: ignore
    CAPITAL_FLOWS = auto()  # type: ignore
    MARKET_STRUCTURE = auto()  # type: ignore


# --------------------------- Forex -------------------------------------------
class ForexFactorCategory(AutoLower):
    """
    Factor categories for forex (currency pair) investments.
    Used identically for both Drivers (positive pressure) and Frictions (negative pressure).

    Universal categories (shared with all asset classes):
      - macroeconomic_and_macrofinancial -- GDP differentials, inflation divergence, employment data, current account balances, debt-to-GDP, credit conditions across currency zones
      - political_and_geopolitical -- elections, regime changes, sanctions, regional conflicts affecting currency stability
      - regulatory -- capital controls, foreign investment restrictions, financial market regulations

    Forex-specific categories:
      - monetary_policy_and_interest_rates -- central bank rate decisions, forward guidance, rate differentials, quantitative easing/tightening
      - trade_balance_and_capital_flows -- trade surplus/deficit trends, FDI flows, portfolio investment shifts, remittance patterns
      - carry_and_positioning -- interest rate carry attractiveness, speculative positioning, COT data, risk reversals
      - technical_and_market_structure -- liquidity conditions, order flow dynamics, market microstructure, algorithmic trading patterns
      - intervention_and_central_bank_action -- direct FX intervention, verbal intervention, reserve management, currency peg defense
    """
    # Universal
    MACROECONOMIC_AND_MACROFINANCIAL = auto()  # type: ignore
    POLITICAL_AND_GEOPOLITICAL = auto()  # type: ignore
    REGULATORY = auto()  # type: ignore
    # Forex-specific
    MONETARY_POLICY_AND_INTEREST_RATES = auto()  # type: ignore
    TRADE_BALANCE_AND_CAPITAL_FLOWS = auto()  # type: ignore
    CARRY_AND_POSITIONING = auto()  # type: ignore
    TECHNICAL_AND_MARKET_STRUCTURE = auto()  # type: ignore
    INTERVENTION_AND_CENTRAL_BANK_ACTION = auto()  # type: ignore


# ================================================================================
# 2.  CATEGORY DESCRIPTIONS  (human-readable per-value descriptions)
#
#     Useful for:
#       - Injecting into Gemini responseSchema description fields
#       - Prompt assembly context
#       - Documentation / tooltips
# ================================================================================

EQUITY_FACTOR_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "macroeconomic_and_macrofinancial": "Real-economy conditions AND financial-system dynamics shaping the business environment. Examples include GDP growth, interest rates, inflation, employment, consumer spending, credit cycles, yield-curve shifts, corporate debt levels, and banking-sector stress -- but any economy-wide or financial-system condition that materially affects the stock qualifies.",
    "political_and_geopolitical": "Government actions and international dynamics that alter the operating landscape. Examples include trade policies, sanctions, elections, and regional conflicts -- but any political or geopolitical development with material impact qualifies.",
    "regulatory": "Changes in laws, rules, or enforcement that affect the company or its sector. Examples include new regulations, compliance burdens, tax policy shifts, and antitrust actions -- but any regulatory development with material impact qualifies.",
    "competitive_positioning": "Shifts in the company's standing relative to peers and substitutes. Examples include market share changes, pricing power, moat strength, and network effects -- but any factor affecting competitive advantage qualifies.",
    "management_and_governance": "Leadership quality and corporate governance factors. Examples include CEO integrity, executive talent depth, insider alignment, board independence, and succession planning -- but any governance-related factor qualifies.",
    "capital_allocation": "How the company deploys and returns capital. Examples include buyback programs, dividend policy, M&A strategy, debt management, and share issuance -- but any capital deployment decision with material price impact qualifies.",
    "innovation_and_product": "Product development and technological progress. Examples include R&D breakthroughs, new product launches, patent protections, and pipeline milestones -- but any innovation-related factor qualifies.",
    "operational_efficiency": "Execution quality and cost structure dynamics. Examples include margin trends, supply chain resilience, cost discipline, and capacity utilization -- but any operational factor affecting profitability qualifies.",
    "sector_and_industry": "Industry-wide structural forces beyond the individual company. Examples include sector growth trajectories, cyclical patterns, consolidation trends, and structural shifts -- but any sector-level dynamic qualifies.",
}

CRYPTO_FACTOR_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "macroeconomic_and_macrofinancial": "Broad economic AND financial-system conditions influencing crypto risk appetite. Examples include risk-on/off sentiment, real yields, dollar strength, global liquidity cycles, credit tightening/easing, stablecoin reserve stability, and long-term debt-cycle positioning -- but any macro or macrofinancial force affecting crypto valuations qualifies.",
    "political_and_geopolitical": "Government and geopolitical dynamics affecting crypto markets. Examples include sanctions driving crypto adoption, capital controls, and geopolitical instability -- but any political development with material crypto impact qualifies.",
    "regulatory": "Regulatory developments shaping the crypto landscape. Examples include licensing frameworks, stablecoin rules, exchange regulations, and CBDC competition -- but any regulatory action affecting crypto qualifies.",
    "adoption_and_network": "Growth in usage, users, and network utility. Examples include active address growth, TVL expansion, developer activity, and real-world dApp usage -- but any adoption or network metric shift qualifies.",
    "technology_and_protocol": "Protocol-level improvements and technical developments. Examples include scalability upgrades, L2 solutions, interoperability advances, and security enhancements -- but any technical evolution affecting the asset qualifies.",
    "tokenomics_and_supply": "Supply mechanics and token economic design. Examples include halving events, token burns, staking dynamics, and vesting unlocks -- but any supply-side or tokenomic factor qualifies.",
    "ecosystem_and_defi": "Growth and evolution of the broader on-chain ecosystem. Examples include DeFi protocol expansion, RWA tokenization, composability advances, and yield opportunities -- but any ecosystem development qualifies.",
    "institutional_participation": "Institutional engagement and infrastructure maturation. Examples include ETF approvals, custody solutions, institutional allocations, and corporate treasury adoption -- but any institutional-grade development qualifies.",
}

COMMODITY_FACTOR_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "macroeconomic_and_macrofinancial": "Broad economic AND financial-system forces driving commodity demand and pricing. Examples include global GDP, industrial output, emerging-market consumption, currency effects, commodity-financing conditions, letter-of-credit availability, and futures-curve structure -- but any macro or macrofinancial condition affecting commodity prices qualifies.",
    "political_and_geopolitical": "Government and geopolitical forces affecting commodity flows. Examples include trade embargoes, sanctions, and regional conflicts disrupting supply routes -- but any political development with material commodity impact qualifies.",
    "regulatory": "Regulatory actions shaping commodity production and trade. Examples include environmental regulations, export controls, carbon pricing, and mining permits -- but any regulatory factor affecting commodity markets qualifies.",
    "supply_dynamics": "Changes in commodity production and availability. Examples include capacity expansions or cuts, mine closures, infrastructure failures, and OPEC+ quotas -- but any supply-side development qualifies.",
    "demand_dynamics": "Shifts in commodity consumption patterns and needs. Examples include industrial demand cycles, green-transition demand drivers, and seasonal patterns -- but any demand-side factor qualifies.",
    "producer_and_cartel": "Actions by major producers and coordinated supply groups. Examples include OPEC+ coordination, major-producer output decisions, and supply concentration effects -- but any producer-level action qualifies.",
    "substitution_and_technology": "Technologies or alternatives that reshape commodity demand. Examples include substitute materials, extraction technology advances, and energy-transition effects -- but any substitution or tech-driven shift qualifies.",
    "storage_and_logistics": "Physical storage, transport, and inventory dynamics. Examples include inventory builds or drawdowns, strategic reserves, shipping costs, and warehousing capacity -- but any logistics factor qualifies.",
    "climate_and_environment": "Weather patterns, natural events, and environmental shifts affecting production or demand. Examples include droughts, floods, El Nino/La Nina cycles, crop yield variability, and ESG-driven demand changes -- but any climate or environmental factor with material commodity impact qualifies.",
}

INDEX_FACTOR_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "macroeconomic_and_macrofinancial": "Economy-wide AND financial-system forces affecting the index as a whole. Examples include aggregate GDP growth, rate environment, inflation expectations, employment trends, financial conditions indices, credit spreads, systemic leverage, and banking-sector health -- but any macro or macrofinancial condition moving the broad market qualifies.",
    "political_and_geopolitical": "Political and geopolitical events with broad market impact. Examples include trade policy shifts, geopolitical tensions, and election outcomes affecting index constituents -- but any political development with market-wide effect qualifies.",
    "regulatory": "Regulatory trends affecting the market broadly. Examples include cross-sector regulation, tax policy changes, and ESG mandates -- but any regulatory action with index-level impact qualifies.",
    "constituent_fundamentals": "Aggregate financial performance of index members. Examples include earnings momentum, revenue growth, and margin trends across constituents -- but any constituent-level fundamental shift affecting the index qualifies.",
    "sector_rotation_and_thematic": "Shifts in sector leadership and thematic momentum within the index. Examples include rotation into/out of index-heavy sectors and thematic trends reshaping constituent mix -- but any sector or thematic rebalancing qualifies.",
    "capital_flows": "Investment flows into or out of index-tracking instruments. Examples include passive fund inflows, pension reallocation, retail participation surges, and global capital seeking index exposure -- but any flow dynamic qualifies.",
    "market_structure": "Structural and mechanical changes affecting index composition or demand. Examples include reconstitution events, inclusion/exclusion effects, and methodology changes -- but any structural factor affecting index dynamics qualifies.",
}

FOREX_FACTOR_CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "macroeconomic_and_macrofinancial": "GDP differentials, inflation divergence, employment data, and financial conditions across currency zones. Examples include relative GDP growth, purchasing power parity shifts, current account balances, debt-to-GDP ratios, and credit conditions -- but any macroeconomic or macrofinancial divergence between the base and quote currency zones qualifies.",
    "political_and_geopolitical": "Government actions and geopolitical events affecting currency stability and flows. Examples include elections, regime changes, sanctions, trade wars, and regional conflicts -- but any political or geopolitical development with material FX impact qualifies.",
    "regulatory": "Regulatory changes affecting currency markets and capital mobility. Examples include capital controls, foreign investment restrictions, financial market regulations, and cross-border transaction rules -- but any regulatory development affecting FX qualifies.",
    "monetary_policy_and_interest_rates": "Central bank decisions and rate differentials driving currency valuations. Examples include rate decisions, forward guidance, quantitative easing/tightening, and interest rate differentials between currency zones -- but any monetary policy action affecting the pair qualifies.",
    "trade_balance_and_capital_flows": "Trade and investment flows between currency zones. Examples include trade surplus/deficit trends, foreign direct investment, portfolio investment shifts, and remittance patterns -- but any trade or capital flow dynamic affecting the pair qualifies.",
    "carry_and_positioning": "Interest rate carry attractiveness and speculative market positioning. Examples include carry trade dynamics, COT speculative positioning, risk reversals, and crowded trade unwinds -- but any positioning or carry-related factor qualifies.",
    "technical_and_market_structure": "Liquidity conditions and market microstructure dynamics. Examples include bid-ask spreads, order flow imbalances, algorithmic trading patterns, and option barrier levels -- but any market structure factor affecting price dynamics qualifies.",
    "intervention_and_central_bank_action": "Direct or indirect central bank actions in currency markets. Examples include FX intervention (buying/selling reserves), verbal intervention, reserve management operations, and currency peg defense -- but any central bank action targeting exchange rates qualifies.",
}

# Convenience lookup by subject_category string
FACTOR_CATEGORY_DESCRIPTIONS_BY_SUBJECT: dict[str, dict[str, str]] = {
    "equity": EQUITY_FACTOR_CATEGORY_DESCRIPTIONS,
    "crypto": CRYPTO_FACTOR_CATEGORY_DESCRIPTIONS,
    "commodity": COMMODITY_FACTOR_CATEGORY_DESCRIPTIONS,
    "index": INDEX_FACTOR_CATEGORY_DESCRIPTIONS,
    "forex": FOREX_FACTOR_CATEGORY_DESCRIPTIONS,
}

# Convenience lookup: subject_category -> enum class
FACTOR_CATEGORY_ENUM_BY_SUBJECT: dict[str, type[AutoLower]] = {
    "equity": EquityFactorCategory,
    "crypto": CryptoFactorCategory,
    "commodity": CommodityFactorCategory,
    "index": IndexFactorCategory,
    "forex": ForexFactorCategory,
}

# Convenience lookup: subject_category -> list of valid category strings
# Auto-derived from the enum classes above -- single source of truth.
FACTOR_CATEGORIES_BY_SUBJECT: dict[str, list[str]] = {
    subject: [member.value for member in enum_cls]
    for subject, enum_cls in FACTOR_CATEGORY_ENUM_BY_SUBJECT.items()
}


# ================================================================================
# 3.  QUADRANT MODELS  (generic base classes -- category typed per asset class)
# ================================================================================

# -- 3a. Top-left: DRIVERS (>50 % likely, positive) --------------------------

class MarketDriver(BaseModel):
    """
    A market force with >50% likelihood that exerts POSITIVE price pressure.
    Part of the Base-Case calculation.
    """
    category: str = Field(
        ...,
        description="Factor category from the asset-class-specific taxonomy. Same categories used for both drivers and frictions."
    )
    description: str = Field(
        ...,
        description="Why this factor drives the price up -- its mechanism, contributing conditions, and expected persistence (30-60 words)"
    )
    expected_impact_pct: float = Field(
        ...,
        ge=0.0,
        description="Expected positive impact on close price as percentage points (e.g., 5.2 means +5.2%). Specify with 1 decimal place."
    )


# -- 3b. Top-right: FRICTIONS (>50 % likely, negative) -----------------------

class MarketFriction(BaseModel):
    """
    A market force with >50% likelihood that exerts NEGATIVE price pressure.
    Part of the Base-Case calculation.
    """
    category: str = Field(
        ...,
        description="Factor category from the asset-class-specific taxonomy. Same categories used for both drivers and frictions."
    )
    description: str = Field(
        ...,
        description="Why this factor pulls the price down -- its mechanism, contributing conditions, and expected persistence (30-60 words)"
    )
    expected_impact_pct: float = Field(
        ...,
        le=0.0,
        description="Expected negative impact on close price as percentage points (e.g., -3.1 means -3.1%). Specify with 1 decimal place."
    )


# -- 3c. Bottom-left: OPPORTUNITIES (<50 % likely, positive) -----------------

class MarketOpportunity(BaseModel):
    """
    A discrete event with <50% likelihood that could trigger UPSIDE.
    Contributes to Bull-Case scenario beyond the Base Case.
    """
    event_name: str = Field(
        ...,
        description="Short name of the potential upside event (5-15 words)"
    )
    description: str = Field(
        ...,
        description="What the event is, what would trigger it, and why it would drive the price up (30-60 words)"
    )
    probability: float = Field(
        ...,
        ge=0.0,
        lt=0.5,
        description="Probability of event materializing (0.0 to <0.5). Specify with 2 decimal places."
    )
    upside_impact_pct: float = Field(
        ...,
        ge=0.0,
        description="Expected positive impact on close price if event materializes, as percentage points (e.g., 8.0 means +8.0%). Specify with 1 decimal place."
    )


# -- 3d. Bottom-right: RISKS (<50 % likely, negative) ------------------------

class MarketRisk(BaseModel):
    """
    A discrete event with <50% likelihood that could trigger DOWNSIDE.
    Contributes to Bear-Case scenario beyond the Base Case.
    """
    event_name: str = Field(
        ...,
        description="Short name of the potential downside event (5-15 words)"
    )
    description: str = Field(
        ...,
        description="What the event is, what would trigger it, and why it would push the price down (30-60 words)"
    )
    probability: float = Field(
        ...,
        ge=0.0,
        lt=0.5,
        description="Probability of event materializing (0.0 to <0.5). Specify with 2 decimal places."
    )
    downside_impact_pct: float = Field(
        ...,
        le=0.0,
        description="Expected negative impact on close price if event materializes, as percentage points (e.g., -5.0 means -5.0%). Specify with 1 decimal place."
    )


# ================================================================================
# 4.  ASSET-CLASS-SPECIFIC TYPED MODELS  (category field pinned to the enum)
# ================================================================================

# --------------------------- Equity ------------------------------------------

class EquityDriver(MarketDriver):
    """Equity-specific driver with typed category."""
    category: EquityFactorCategory  # type: ignore[assignment]

class EquityFriction(MarketFriction):
    """Equity-specific friction with typed category."""
    category: EquityFactorCategory  # type: ignore[assignment]

class EquityOpportunity(MarketOpportunity):
    """Equity-specific opportunity (no category enum -- event-based)."""
    pass

class EquityRisk(MarketRisk):
    """Equity-specific risk (no category enum -- event-based)."""
    pass


# --------------------------- Crypto ------------------------------------------

class CryptoDriver(MarketDriver):
    """Crypto-specific driver with typed category."""
    category: CryptoFactorCategory  # type: ignore[assignment]

class CryptoFriction(MarketFriction):
    """Crypto-specific friction with typed category."""
    category: CryptoFactorCategory  # type: ignore[assignment]

class CryptoOpportunity(MarketOpportunity):
    """Crypto-specific opportunity (no category enum -- event-based)."""
    pass

class CryptoRisk(MarketRisk):
    """Crypto-specific risk (no category enum -- event-based)."""
    pass


# --------------------------- Commodity ---------------------------------------

class CommodityDriver(MarketDriver):
    """Commodity-specific driver with typed category."""
    category: CommodityFactorCategory  # type: ignore[assignment]

class CommodityFriction(MarketFriction):
    """Commodity-specific friction with typed category."""
    category: CommodityFactorCategory  # type: ignore[assignment]

class CommodityOpportunity(MarketOpportunity):
    """Commodity-specific opportunity (no category enum -- event-based)."""
    pass

class CommodityRisk(MarketRisk):
    """Commodity-specific risk (no category enum -- event-based)."""
    pass


# --------------------------- Index -------------------------------------------

class IndexDriver(MarketDriver):
    """Index-specific driver with typed category."""
    category: IndexFactorCategory  # type: ignore[assignment]

class IndexFriction(MarketFriction):
    """Index-specific friction with typed category."""
    category: IndexFactorCategory  # type: ignore[assignment]

class IndexOpportunity(MarketOpportunity):
    """Index-specific opportunity (no category enum -- event-based)."""
    pass

class IndexRisk(MarketRisk):
    """Index-specific risk (no category enum -- event-based)."""
    pass


# --------------------------- Forex -------------------------------------------

class ForexDriver(MarketDriver):
    """Forex-specific driver with typed category."""
    category: ForexFactorCategory  # type: ignore[assignment]

class ForexFriction(MarketFriction):
    """Forex-specific friction with typed category."""
    category: ForexFactorCategory  # type: ignore[assignment]

class ForexOpportunity(MarketOpportunity):
    """Forex-specific opportunity (no category enum -- event-based)."""
    pass

class ForexRisk(MarketRisk):
    """Forex-specific risk (no category enum -- event-based)."""
    pass


# ================================================================================
# 5.  UNION TYPES  (for generic handling across asset classes)
# ================================================================================

AnyFactorCategory = Union[EquityFactorCategory, CryptoFactorCategory, CommodityFactorCategory, IndexFactorCategory, ForexFactorCategory]

AnyMarketDriver = Union[EquityDriver, CryptoDriver, CommodityDriver, IndexDriver, ForexDriver]
AnyMarketFriction = Union[EquityFriction, CryptoFriction, CommodityFriction, IndexFriction, ForexFriction]
AnyMarketOpportunity = Union[EquityOpportunity, CryptoOpportunity, CommodityOpportunity, IndexOpportunity, ForexOpportunity]
AnyMarketRisk = Union[EquityRisk, CryptoRisk, CommodityRisk, IndexRisk, ForexRisk]
