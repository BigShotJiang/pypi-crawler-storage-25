"""Market-specific event class for equity, crypto, commodity, and index predictions."""
from typing import ClassVar, Dict, Any, Optional
from pydantic import Field, field_validator
from .time_series_prediction_event_base import TimeSeriesPredictionEventBase
from ..utils.market_price_factors import (
    EquityFactorCategory,
    CryptoFactorCategory,
    CommodityFactorCategory,
    IndexFactorCategory,
)


class FincoreMarketPredictionEvent(TimeSeriesPredictionEventBase):
    """
        Market event model for equity, crypto, commodity, and index assets.
    
        Extends TimeSeriesPredictionEventBase with market-specific context fields.
        Maps to BigQuery table: prediction_events.
    
        Event type compatibility:
        - V2 event types: horizon_driver, horizon_friction, horizon_tail_opportunity,
            horizon_tail_risk, period_scenario_rationale
        - Legacy event types continue to be accepted for backward compatibility.
    
        Validation behavior:
        - Driver, friction, and risk-style events use subject-category factor enums.
        - Tail and scenario rationale events are allowed to use non-factor categories
            (for example: tail_opportunity, tail_risk, scenario_rationale).
    """
    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = "dp_oracle_fincore_prediction_market__datasets.prediction_events"
    VERSION: ClassVar[int] = 1
    DOMAIN: ClassVar[str] = "oracle_fincore_prediction_market"
    OBJ_REF: ClassVar[str] = "mrktevent"
    
    # --- Market-Specific Context ---
    # Made optional to support lightweight catalog entries or data from older pipelines
    subject_category: Optional[str] = Field(None, description="Asset category: equity, crypto, commodity, index")
    subject_category_detailed: Optional[str] = Field(None, description="Detailed category: common_stock, etf, bitcoin, gold, oil")
    
    @field_validator('event_category')
    @classmethod
    def validate_event_category(cls, v: str, info) -> str:
        """Validate event category using event-type-aware market rules."""
        if not info.data:
            return v
            
        subject_category = info.data.get('subject_category', '').lower()
        event_type = info.data.get('event_type', '').lower()

        # Tail/scenario-style events have specialized categories that are intentionally
        # outside market factor enums.
        event_types_with_freeform_categories = {
            'horizon_tail_opportunity',
            'horizon_tail_risk',
            'period_scenario_rationale',
        }
        if event_type in event_types_with_freeform_categories:
            return v

        # Driver/friction/risk style events should use factor taxonomies.
        event_types_requiring_factor_category = {
            'horizon_driver',
            'horizon_friction',
            'horizon_risk',
            'period_driver',
            'period_risk',
        }
        if event_type and event_type not in event_types_requiring_factor_category:
            return v
        
        # Map subject categories to their factor category enums
        factor_category_enums = {
            'equity': EquityFactorCategory,
            'crypto': CryptoFactorCategory,
            'commodity': CommodityFactorCategory,
            'index': IndexFactorCategory
        }
        
        # Get the appropriate enum class based on subject category
        enum_class = factor_category_enums.get(subject_category)
        
        # Validate if we have an enum class
        if enum_class:
            valid_categories = [member.value for member in enum_class]
            if v not in valid_categories:
                raise ValueError(
                    f"Invalid event_category '{v}' for {subject_category} {event_type}. "
                    f"Valid categories: {', '.join(valid_categories)}"
                )
        
        return v
    
    def to_bigquery_row(self) -> Dict[str, Any]:
        """Convert to BigQuery row format."""
        return self.model_dump(mode='json', exclude_none=False)
    
    @classmethod
    def from_bigquery_row(cls, row: Dict[str, Any]) -> "FincoreMarketPredictionEvent":
        """Create instance from BigQuery row."""
        return cls(**row)
