module.exports = require('./usersController');
