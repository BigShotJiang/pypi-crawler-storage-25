"""initra package."""

__version__ = "0.1.0"

from .cli import main

__all__ = ["__version__", "main"]
