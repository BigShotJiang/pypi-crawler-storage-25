# -*- coding: utf-8 -*-

import os
import sys
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.offsetbox import OffsetImage, AnnotationBbox

# =========================
# DETECCIÓN DE ENTORNO
# =========================

def en_colab():
    return "google.colab" in sys.modules

# =========================
# RUTAS
# =========================

BASE_DIR = os.path.dirname(__file__)

def get_asset(path):
    return os.path.join(BASE_DIR, "assets", path)

# ============================================================
# 🟢 ANIMACIÓN COLAB (TU VERSIÓN ORIGINAL)
# ============================================================

def _animacion_colab(t, x, v=None, a=None):

    from IPython.display import HTML, display

    n_graficas = 1 + (v is not None) + (a is not None)

    fig = plt.figure(figsize=(10, 3*n_graficas + 3))
    gs = fig.add_gridspec(
        n_graficas + 1,
        1,
        height_ratios=[1]*n_graficas + [2]
    )

    axes = []
    idx = 0

    ax_x = fig.add_subplot(gs[idx]); idx+=1
    ax_x.set_xlim(0, t[-1])
    ax_x.set_ylim(-105,105)
    ax_x.set_title("x vs t")
    ax_x.grid()
    axes.append(("x", ax_x))

    if v is not None:
        ax_v = fig.add_subplot(gs[idx]); idx+=1
        ax_v.set_xlim(0, t[-1])
        ax_v.set_ylim(-51,51)
        ax_v.set_title("v vs t")
        ax_v.grid()
        axes.append(("v", ax_v))

    if a is not None:
        ax_a = fig.add_subplot(gs[idx]); idx+=1
        ax_a.set_xlim(0, t[-1])
        ax_a.set_ylim(-20,20)
        ax_a.set_title("a vs t")
        ax_a.grid()
        axes.append(("a", ax_a))

    ax_mov = fig.add_subplot(gs[idx])
    ax_mov.set_xlim(-100,100)
    ax_mov.set_ylim(0,100)
    ax_mov.axis("off")

    y_suelo = 15

    ax_mov.plot([-100,100],[y_suelo,y_suelo],color="black")

    for m in [-100,-50,0,50,100]:
        ax_mov.plot([m,m],[y_suelo-2,y_suelo+2],color="black")
        ax_mov.text(m,y_suelo-5,str(m),ha='center',fontsize=8)

    player_img = plt.imread(get_asset("player.png"))
    background_img = plt.imread(get_asset("background.png"))

    ax_mov.imshow(background_img, extent=[-100,100,0,100])

    imagebox = OffsetImage(player_img, zoom=0.25)
    ab = AnnotationBbox(imagebox,(0,y_suelo+5),frameon=False)
    ax_mov.add_artist(ab)

    lineas = {}
    puntos = {}

    for nombre, ax in axes:
        lineas[nombre], = ax.plot([],[])
        puntos[nombre], = ax.plot([],[],'o')

    def update(frame):

        t_sim = t[:frame+1]
        x_sim = x[:frame+1]

        if v is not None:
            v_sim = v[:frame+1]
        if a is not None:
            a_sim = a[:frame+1]

        for nombre,_ in axes:

            if nombre=="x":
                lineas["x"].set_data(t_sim,x_sim)
                puntos["x"].set_data([t_sim[-1]],[x_sim[-1]])

            elif nombre=="v":
                lineas["v"].set_data(t_sim,v_sim)
                puntos["v"].set_data([t_sim[-1]],[v_sim[-1]])

            elif nombre=="a":
                lineas["a"].set_data(t_sim,a_sim)
                puntos["a"].set_data([t_sim[-1]],[a_sim[-1]])

        ab.xybox = (x_sim[-1], y_suelo+5)

        return list(lineas.values()) + list(puntos.values()) + [ab]

    ani = FuncAnimation(fig, update, frames=len(t), interval=100)

    display(HTML(ani.to_jshtml()))
    plt.close()

# ============================================================
# 🔵 ANIMACIÓN VENTANA (TU VERSIÓN BUENA)
# ============================================================

def _animacion_ventana(t, x, v=None, a=None):
    import matplotlib

    if matplotlib.get_backend().lower() == "agg":
        plt.switch_backend("TkAgg")
    n_graficas = 1 + (v is not None) + (a is not None)

    fig = plt.figure(figsize=(10, 3*n_graficas + 3))
    gs = fig.add_gridspec(n_graficas + 1, 1,
                          height_ratios=[1]*n_graficas + [2])

    axes = []
    idx = 0

    ax_x = fig.add_subplot(gs[idx]); idx+=1
    ax_x.set_xlim(0, t[-1])
    ax_x.set_ylim(-105,105)
    ax_x.set_title("x vs t")
    ax_x.grid()
    axes.append(("x", ax_x))

    if v is not None:
        ax_v = fig.add_subplot(gs[idx]); idx+=1
        ax_v.set_xlim(0, t[-1])
        ax_v.set_ylim(-51,51)
        ax_v.set_title("v vs t")
        ax_v.grid()
        axes.append(("v", ax_v))

    if a is not None:
        ax_a = fig.add_subplot(gs[idx]); idx+=1
        ax_a.set_xlim(0, t[-1])
        ax_a.set_ylim(-20,20)
        ax_a.set_title("a vs t")
        ax_a.grid()
        axes.append(("a", ax_a))

    ax_mov = fig.add_subplot(gs[idx])
    ax_mov.set_xlim(-100,100)
    ax_mov.set_ylim(0,100)
    ax_mov.axis("off")

    y_suelo = 15

    ax_mov.plot([-100,100],[y_suelo,y_suelo],color="black")

    for m in [-100,-50,0,50,100]:
        ax_mov.plot([m,m],[y_suelo-2,y_suelo+2],color="black")
        ax_mov.text(m,y_suelo-5,str(m),ha='center',fontsize=8)

    player_img = plt.imread(get_asset("player.png"))
    background_img = plt.imread(get_asset("Background.png"))

    ax_mov.imshow(background_img, extent=[-100,100,0,100])

    imagebox = OffsetImage(player_img, zoom=0.25)
    ab = AnnotationBbox(imagebox,(0,y_suelo+5),frameon=False)
    ax_mov.add_artist(ab)

    lineas = {}
    puntos = {}

    for nombre, ax in axes:
        lineas[nombre], = ax.plot([],[])
        puntos[nombre], = ax.plot([],[],'o')

    estado = {
        "pausado": False,
        "loop": False,
        "solo_una_vez": False
    }

    frame_actual = {"k": 0}

    def update(_):

        if not estado["pausado"]:

            if frame_actual["k"] >= len(t)-1:

                if estado["loop"]:
                    frame_actual["k"] = 0

                elif estado["solo_una_vez"]:
                    estado["pausado"] = True

            else:
                frame_actual["k"] += 1

        k = frame_actual["k"]

        t_sim = t[:k+1]
        x_sim = x[:k+1]

        if v is not None:
            v_sim = v[:k+1]
        if a is not None:
            a_sim = a[:k+1]

        for nombre,_ in axes:

            if nombre=="x":
                lineas["x"].set_data(t_sim,x_sim)
                puntos["x"].set_data([t_sim[-1]],[x_sim[-1]])

            elif nombre=="v":
                lineas["v"].set_data(t_sim,v_sim)
                puntos["v"].set_data([t_sim[-1]],[v_sim[-1]])

            elif nombre=="a":
                lineas["a"].set_data(t_sim,a_sim)
                puntos["a"].set_data([t_sim[-1]],[a_sim[-1]])

        ab.xybox = (x_sim[-1], y_suelo+5)

        return list(lineas.values()) + list(puntos.values()) + [ab]

    fig._ani = FuncAnimation(fig, update, interval=100)

    def on_key(event):

        if event.key == " ":
            estado["pausado"] = not estado["pausado"]

        elif event.key == "right":
            frame_actual["k"] = min(len(t)-1, frame_actual["k"] + 1)

        elif event.key == "left":
            frame_actual["k"] = max(0, frame_actual["k"] - 1)

        elif event.key == "r":
            frame_actual["k"] = 0
            estado["pausado"] = False

        elif event.key == "l":
            estado["loop"] = not estado["loop"]
            estado["solo_una_vez"] = False

        elif event.key == "s":
            estado["solo_una_vez"] = True
            estado["loop"] = False

    fig.canvas.mpl_connect("key_press_event", on_key)

    plt.show()

# =========================
# FUNCIONES PÚBLICAS
# =========================

def simular_pos(t, x):
    if en_colab():
        _animacion_colab(t, x)
    else:
        _animacion_ventana(t, x)

def simular_vel_y_pos(t, v, x):
    if en_colab():
        _animacion_colab(t, x, v=v)
    else:
        _animacion_ventana(t, x, v=v)

def simular_a_vel_y_pos(t, a, v, x):
    if en_colab():
        _animacion_colab(t, x, v=v, a=a)
    else:
        _animacion_ventana(t, x, v=v, a=a)