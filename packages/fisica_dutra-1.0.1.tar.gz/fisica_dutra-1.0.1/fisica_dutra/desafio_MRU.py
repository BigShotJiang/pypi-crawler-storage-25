# -*- coding: utf-8 -*-
import pygame
import matplotlib
matplotlib.use("Agg")
import matplotlib.backends.backend_agg as agg
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
import time
import pickle
import numpy as np
import sys
import os

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(__file__)
    return os.path.join(base_path, relative_path)

def abrir_datos(grupo):
    archivo = resource_path("assets/Grupo" + str(grupo))
    with open(archivo, "rb") as fichero:
        datos = pickle.load(fichero)
    return datos

def obtener_puntaje(x_i, v, t_jugador, x_jugador):
    coeficientes = np.polyfit(t_jugador, x_jugador, 1)
    x_i_jugador = coeficientes[1]
    v_jugador = coeficientes[0]

    if abs(x_i - x_i_jugador) > 1 or abs(v - v_jugador) > 1:
        puntaje = "perdieron"
    else:
        diferencia_promedio = (abs(x_i - x_i_jugador) + abs(v - v_jugador)) / 2 * 100
        diferencia_promedio = int(diferencia_promedio * 10) / 10
        puntaje = str(100 - diferencia_promedio)

    return puntaje

def graficar(t1, x1, t2, x2, xlim_max):
    fig, ax = plt.subplots(figsize=[6,2.85], dpi=133)

    ax.plot(t1, x1, t2, x2)
    ax.set_title("$x = f(t)$", fontsize=14)
    ax.set_xlabel("$t(s)$", fontsize=12)
    ax.set_ylabel("$x(m)$", fontsize=12)

    plt.xlim([0, xlim_max])
    plt.ylim([0, 105])

    ax.xaxis.set_label_coords(1.1, -0.05)
    ax.grid(True)

    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())

    ax.tick_params(which='major', width=2, length=9)
    ax.tick_params(which='minor', width=1.2, length=4)

    ax.set_aspect(0.03)

    canvas = agg.FigureCanvasAgg(fig)
    canvas.draw()

    renderer = canvas.get_renderer()
    raw_data = renderer.buffer_rgba()
    size = canvas.get_width_height()

    surf = pygame.image.frombuffer(raw_data, size, "RGBA")
    plt.close()

    return surf

def desafio_MRU(t_jugador, x_jugador, grupo):

    pygame.init()
    screen = pygame.display.set_mode((800,600))

    # -------- ASSETS --------
    background = pygame.image.load(resource_path('assets/background.png'))
    pygame.display.set_caption("DESAFÍO MRU")

    icon = pygame.image.load(resource_path('assets/icon.png'))
    pygame.display.set_icon(icon)

    font = pygame.font.Font(resource_path('assets/CaviarDreams.ttf'), 45)

    playerImg = pygame.image.load(resource_path('assets/player.png'))
    simulacionImg = pygame.image.load(resource_path('assets/player_simulacion.png'))

    playerX = 10
    playerY = 370

    simulacionX = 1000
    simulacionY = 370

    def player(x,y):
        screen.blit(playerImg,(x,y))

    def simulacion(x,y):
        screen.blit(simulacionImg, (x,y))

    def textos_finalizo(puntaje):
        if puntaje == "perdieron":
            perdieron_text = font.render("PERDIERON :(", True, (255,255,255))
            screen.blit(perdieron_text,(100, 450))
        else:
            ganaron_text = font.render("¡¡GANARON!!", True, (255,255,255))
            texto_puntaje = "Puntuación: " + puntaje + "/100"
            puntaje_text = font.render(texto_puntaje, True, (255,255,255))
            screen.blit(ganaron_text,(40, 450))
            screen.blit(puntaje_text,(40, 500))

    # -------- LÓGICA ORIGINAL --------

    x_jugador_simulacion = [x_jugador[0]]

    datos = abrir_datos(grupo)

    x_i = datos[0]
    x_i = ((x_i[1] + 1) / 2 - 5) / 3

    v = datos[1]
    v = ((v[1] + 1) / 2 - 5) / 3

    t = [0]
    x = [x_i]

    dt = t_jugador[-1] / len(t_jugador)

    while len(t) < len(t_jugador):
        t.append(t[-1] + dt)
        x.append(v * t[-1] + x_i)

    puntaje = obtener_puntaje(x_i, v, t_jugador, x_jugador)

    t_simulacion = [0]
    x_simulacion = [x[0]]

    k = 0
    t1 = time.time()

    running = True
    surf = None

    while running:
        screen.blit(background,(0,0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False 

        if k < len(t) - 1 and time.time() - t1 >= t[k]:
            k += 1
            t_simulacion.append(t[k])
            x_simulacion.append(x[k])
            x_jugador_simulacion.append(x_jugador[k])

            surf = graficar(
                t_simulacion,
                x_simulacion,
                t_simulacion,
                x_jugador_simulacion,
                5
            )

            playerX = x_jugador_simulacion[-1]*7
            simulacionX = x_simulacion[-1]*7

        if surf is not None:
            screen.blit(surf, (0,0))

        if k >= len(t) - 1:
            surf = graficar(t, x, t_jugador, x_jugador, t[-1])
            screen.blit(surf, (0,0))
            textos_finalizo(puntaje)

        simulacion(simulacionX,simulacionY)
        player(playerX,playerY)

        pygame.display.update()