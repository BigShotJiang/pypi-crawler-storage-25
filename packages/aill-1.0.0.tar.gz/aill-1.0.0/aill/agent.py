"""
Agent adapter layer.

Accepts any agent object and normalizes it to the standard interface.
Only `send(message: str) -> str` is required on the user's agent.
Missing methods are filled in with default implementations built on top of `send`.
"""

from __future__ import annotations
from typing import Any
from .exceptions import ConfigError


class AgentAdapter:
    """
    Wraps a user-supplied agent and exposes a standard interface.

    Standard methods:
        send(message)         -> str   — required
        reset()               -> None
        remember(content)     -> None
        save()                -> Any
        restore(snapshot)     -> None
        compact()             -> None
    """

    def __init__(self, agent: Any):
        if not callable(getattr(agent, "send", None)):
            raise ConfigError(
                "Agent must implement a `send(message: str) -> str` method."
            )
        self._agent = agent
        self._history: list[dict] = []   # fallback history store when agent lacks one
        self._system: str = ""

    # ------------------------------------------------------------------
    # Core: delegate to the underlying agent
    # ------------------------------------------------------------------

    def send(self, message: str) -> str:
        """Send a user message and return the agent's reply."""
        reply = self._agent.send(message)
        self._history.append({"role": "user", "content": message})
        self._history.append({"role": "assistant", "content": reply})
        return reply

    def send_with_system(self, system: str, message: str) -> str:
        """Send with a one-shot system prompt override (used by context)."""
        if hasattr(self._agent, "send_with_system"):
            return self._agent.send_with_system(system, message)
        # fallback: prepend system as a user turn prefix
        full_message = f"[System instruction]: {system}\n\n{message}" if system else message
        return self.send(full_message)

    # ------------------------------------------------------------------
    # Context management
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Clear all conversation history."""
        if hasattr(self._agent, "reset"):
            self._agent.reset()
        self._history.clear()

    def remember(self, content: str) -> None:
        """
        Inject background information without counting as a conversation turn.
        On agents that support it natively, delegates to agent.remember().
        Otherwise, injects as a system-level note via send.
        """
        if hasattr(self._agent, "remember"):
            self._agent.remember(content)
        else:
            # Inject as a silent system note; do not record in history
            note = f"[Background information]: {content}"
            self._agent.send(note)

    def save(self) -> Any:
        """Save and return a snapshot of the current context state."""
        if hasattr(self._agent, "save"):
            return {"agent_snapshot": self._agent.save(), "history": list(self._history)}
        return {"history": list(self._history)}

    def restore(self, snapshot: Any) -> None:
        """Restore context to a previously saved snapshot."""
        if hasattr(self._agent, "restore") and "agent_snapshot" in snapshot:
            self._agent.restore(snapshot["agent_snapshot"])
        self._history = list(snapshot.get("history", []))

    def compact(self) -> None:
        """
        Compress context by summarizing history.
        Delegates to agent.compact() if available, otherwise
        asks the agent to summarize its own history and resets.
        """
        if hasattr(self._agent, "compact"):
            self._agent.compact()
            self._history.clear()
        else:
            if self._history:
                history_text = "\n".join(
                    f"{m['role']}: {m['content']}" for m in self._history
                )
                summary = self._agent.send(
                    f"Please summarize the following conversation concisely:\n\n{history_text}"
                )
                self.reset()
                self.remember(f"[Conversation summary]: {summary}")

    # ------------------------------------------------------------------
    # Memory: delegate to agent if available
    # ------------------------------------------------------------------

    def memory_save(self, content: Any, key: str = "", tags: list[str] | None = None) -> None:
        if hasattr(self._agent, "memory_save"):
            self._agent.memory_save(content, key=key, tags=tags or [])

    def memory_get(self, key: str) -> str:
        if hasattr(self._agent, "memory_get"):
            return self._agent.memory_get(key)
        return ""

    def memory_search(self, query: str, top_k: int = 5) -> list[str]:
        if hasattr(self._agent, "memory_search"):
            return self._agent.memory_search(query, top_k=top_k)
        return []
