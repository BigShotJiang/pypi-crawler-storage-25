"""
aill PromptConfig — prompt template configuration.

Each operation has:
  - A `*_system` string attribute  (the system prompt)
  - A `*_user` string attribute    (the user message template, with {placeholders})
  - A `build_*` method             (assembles the final (system, user) tuple)

Users can customize at any granularity:
  - Change one string:   config.judge_system = "..."
  - Change the template: config.judge_user = "..."
  - Override the whole build method for full control:
        class MyConfig(PromptConfig):
            def build_judge(self, condition): return ("sys", f"user: {condition}")
"""

from __future__ import annotations

import json
import re
import dataclasses
from typing import Any


class PromptConfig:

    # ------------------------------------------------------------------
    # @ask
    # ------------------------------------------------------------------

    ask_system: str = (
        "You are a helpful assistant executing a task as instructed."
    )

    def build_ask(self, prompt: str) -> tuple[str, str]:
        return self.ask_system, prompt

    # ------------------------------------------------------------------
    # @judge
    # ------------------------------------------------------------------

    judge_system: str = (
        "You are a precise evaluator. "
        "You must respond with a single boolean value."
    )
    judge_user: str = (
        "[Condition]\n"
        "{condition}\n\n"
        "[Output Format]\n"
        "Reply with only: true or false\n"
        "No explanation. No punctuation. Lowercase only."
    )

    def build_judge(self, condition: str) -> tuple[str, str]:
        user = self.judge_user.format(condition=condition)
        return self.judge_system, user

    # ------------------------------------------------------------------
    # @pick
    # ------------------------------------------------------------------

    pick_system: str = (
        "You are a decision-making assistant. "
        "You must select exactly one option."
    )
    pick_user: str = (
        "[Instruction]\n"
        "{instruction}\n\n"
        "[Options]\n"
        "{options_list}\n\n"
        "[Output Format]\n"
        "Reply with only the number of your chosen option (e.g. 1, 2, 3).\n"
        "No explanation. No punctuation."
    )

    def build_pick(self, instruction: str, options: list) -> tuple[str, str]:
        options_list = "\n".join(f"{i + 1}. {opt}" for i, opt in enumerate(options))
        user = self.pick_user.format(instruction=instruction, options_list=options_list)
        return self.pick_system, user

    # ------------------------------------------------------------------
    # @plan
    # ------------------------------------------------------------------

    plan_system: str = (
        "You are a planning assistant. "
        "Break down goals into clear, executable steps."
    )
    plan_user: str = (
        "[Goal]\n"
        "{goal}\n\n"
        "[Output Format]\n"
        "Return a numbered list of steps. Each step on its own line.\n"
        "Example format:\n"
        "1. First step\n"
        "2. Second step\n"
        "3. Third step\n"
        "No explanation before or after the list."
    )

    def build_plan(self, goal: str) -> tuple[str, str]:
        user = self.plan_user.format(goal=goal)
        return self.plan_system, user

    # ------------------------------------------------------------------
    # @extract — primitive types
    # ------------------------------------------------------------------

    extract_primitive_system: str = (
        "You are a precise data extractor. "
        "Extract exactly what is requested and return it in the specified format."
    )
    extract_primitive_user: str = (
        "[Source Text]\n"
        "{source_text}\n\n"
        "[Extraction Task]\n"
        "{hint}\n\n"
        "[Output Format]\n"
        "Return only the extracted value as: {format_instruction}\n"
        "No explanation. No extra text."
    )

    def build_extract_primitive(self, source_text: str, hint: str, format_instruction: str) -> tuple[str, str]:
        user = self.extract_primitive_user.format(
            source_text=source_text,
            hint=hint or "Extract the requested information.",
            format_instruction=format_instruction,
        )
        return self.extract_primitive_system, user

    # ------------------------------------------------------------------
    # @extract — custom type / dict schema
    # ------------------------------------------------------------------

    extract_schema_system: str = (
        "You are a precise data extractor. "
        "Extract structured data and return valid JSON."
    )
    extract_schema_user: str = (
        "[Source Text]\n"
        "{source_text}\n\n"
        "[Extraction Task]\n"
        "{hint}\n\n"
        "[Target Schema]\n"
        "{schema}\n\n"
        "[Output Format]\n"
        "Return only a valid JSON object matching the schema above.\n"
        "No explanation. No markdown code blocks. Raw JSON only."
    )

    def build_extract_schema(self, source_text: str, hint: str, schema: str) -> tuple[str, str]:
        user = self.extract_schema_user.format(
            source_text=source_text,
            hint=hint or "Extract structured information according to the schema.",
            schema=schema,
        )
        return self.extract_schema_system, user

    # ------------------------------------------------------------------
    # @extract — semantic sort
    # ------------------------------------------------------------------

    extract_sort_system: str = (
        "You are a ranking assistant. "
        "Reorder items based on semantic relevance."
    )
    extract_sort_user: str = (
        "[Items]\n"
        "{items_text}\n\n"
        "[Ranking Criterion]\n"
        "{criterion}\n\n"
        "[Output Format]\n"
        "Return only a JSON array of the original item indices in your preferred order (0-based).\n"
        "Example: [2, 0, 3, 1]\n"
        "No explanation."
    )

    def build_extract_sort(self, items_text: str, criterion: str) -> tuple[str, str]:
        user = self.extract_sort_user.format(items_text=items_text, criterion=criterion)
        return self.extract_sort_system, user

    # ------------------------------------------------------------------
    # @eval — single dimension
    # ------------------------------------------------------------------

    eval_single_system: str = (
        "You are an objective evaluator. "
        "Score content on a scale from 0.0 to 1.0."
    )
    eval_single_user: str = (
        "[Content]\n"
        "{content}\n\n"
        "[Criterion]\n"
        "{criterion}\n\n"
        "[Output Format]\n"
        "Return only a decimal number between 0.0 and 1.0 (e.g. 0.75).\n"
        "No explanation. No extra text."
    )

    def build_eval_single(self, content: str, criterion: str) -> tuple[str, str]:
        user = self.eval_single_user.format(content=content, criterion=criterion)
        return self.eval_single_system, user

    # ------------------------------------------------------------------
    # @eval — multi-dimension
    # ------------------------------------------------------------------

    eval_multi_system: str = (
        "You are an objective evaluator. "
        "Score content on multiple dimensions, each from 0.0 to 1.0."
    )
    eval_multi_user: str = (
        "[Content]\n"
        "{content}\n\n"
        "[Dimensions]\n"
        "{dimensions}\n\n"
        "[Output Format]\n"
        "Return only a valid JSON object with each dimension as a key and its score as a float.\n"
        "Example: {example}\n"
        "No explanation. Raw JSON only."
    )

    def build_eval_multi(self, content: str, dimensions: dict) -> tuple[str, str]:
        dims_text = "\n".join(f"- {k}" for k in dimensions.keys())
        example = json.dumps({k: 0.0 for k in dimensions.keys()})
        user = self.eval_multi_user.format(
            content=content,
            dimensions=dims_text,
            example=example,
        )
        return self.eval_multi_system, user

    # ------------------------------------------------------------------
    # @validate
    # ------------------------------------------------------------------

    validate_system: str = (
        "You are a strict content validator. "
        "Evaluate whether the given content satisfies the condition."
    )
    validate_user: str = (
        "[Content]\n"
        "{content}\n\n"
        "[Condition]\n"
        "{condition}\n\n"
        "[Output Format]\n"
        "Line 1: pass or fail\n"
        "Line 2: one-sentence reason (required when fail, optional when pass)"
    )

    def build_validate(self, content: str, condition: str) -> tuple[str, str]:
        user = self.validate_user.format(content=content, condition=condition)
        return self.validate_system, user

    # ------------------------------------------------------------------
    # @act
    # ------------------------------------------------------------------

    act_system: str = (
        "You are an autonomous agent. "
        "Select the most appropriate tool and call it to complete the task. "
        "You must respond with a valid tool call in the specified format."
    )
    act_user: str = (
        "[Task]\n"
        "{instruction}\n\n"
        "[Available Tools]\n"
        "{tools}\n\n"
        "[Output Format]\n"
        '{{"tool": "<tool_name>", "args": {{"<param>": <value>}}}}\n'
        "Raw JSON only. No explanation."
    )

    def build_act(self, instruction: str, tools: list[dict]) -> tuple[str, str]:
        tools_text = ""
        for i, t in enumerate(tools, 1):
            tools_text += f"{i}. {t['signature']}\n"
            if t.get("doc"):
                tools_text += f"   {t['doc']}\n"
            tools_text += "\n"
        user = self.act_user.format(
            instruction=instruction,
            tools=tools_text.strip(),
        )
        return self.act_system, user

    # ------------------------------------------------------------------
    # Shared parsing helpers (not templates, but kept here for cohesion)
    # ------------------------------------------------------------------

    @staticmethod
    def parse_judge(response: str) -> bool:
        normalized = response.strip().lower()
        if normalized in ("true", "yes", "1"):
            return True
        if normalized in ("false", "no", "0"):
            return False
        return "true" in normalized

    @staticmethod
    def parse_pick(response: str, options: list) -> Any:
        try:
            index = int(response.strip()) - 1
            return options[index]
        except (ValueError, IndexError):
            for char in response:
                if char.isdigit():
                    index = int(char) - 1
                    if 0 <= index < len(options):
                        return options[index]
            return options[0]

    @staticmethod
    def parse_plan(response: str) -> list[str]:
        steps = []
        for line in response.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            cleaned = re.sub(r"^\d+[\.\)]\s*", "", line)
            if cleaned:
                steps.append(cleaned)
        return steps

    @staticmethod
    def parse_validate(response: str) -> tuple[bool, str]:
        lines = response.strip().splitlines()
        verdict = lines[0].strip().lower() if lines else "fail"
        reason = lines[1].strip() if len(lines) > 1 else ""
        return verdict == "pass", reason

    @staticmethod
    def schema_from_type(type_) -> str:
        if isinstance(type_, dict):
            lines = []
            for k, v in type_.items():
                type_name = v.__name__ if hasattr(v, "__name__") else str(v)
                lines.append(f'  "{k}": {type_name}')
            return "{\n" + ",\n".join(lines) + "\n}"
        if dataclasses.is_dataclass(type_):
            lines = []
            for field in dataclasses.fields(type_):
                type_name = (
                    field.type
                    if isinstance(field.type, str)
                    else getattr(field.type, "__name__", str(field.type))
                )
                lines.append(f'  "{field.name}": {type_name}')
            return "{\n" + ",\n".join(lines) + "\n}"
        return str(type_)

    @staticmethod
    def type_format_instruction(type_) -> str:
        origin = getattr(type_, "__origin__", None)
        args = getattr(type_, "__args__", ())
        if type_ is str:
            return "a plain string"
        if type_ is int:
            return "an integer number"
        if type_ is float:
            return "a decimal number (e.g. 3.14)"
        if type_ is bool:
            return "true or false"
        if origin is list and args:
            inner = args[0].__name__ if hasattr(args[0], "__name__") else str(args[0])
            return f'a JSON array of {inner} values, e.g. ["a", "b"]'
        return "the extracted value as JSON"


# Module-level default instance — importable as `from aill import config`
config = PromptConfig()
