class AIError(Exception):
    """Base class for all aill exceptions."""


class ValidationError(AIError):
    """Raised when ai.validate() condition is not met."""

    def __init__(self, reason: str = ""):
        self.reason = reason
        super().__init__(reason)


class TimeoutError(AIError):
    """Raised when ai.timeout() block exceeds the time limit."""


class CancelError(AIError):
    """Raised when ai.confirm() is rejected by the user."""


class ConfigError(AIError):
    """Raised when the agent is misconfigured (e.g. missing send method)."""
