"""
aill v1.0 — AIL v1.0 的 Python 实现

aill 是 AIL（AI-driven workflow Language）v1.0 规范的 Python SDK 实现。
用户直接编写 Python 代码即可使用 AIL 的全部能力，无需学习新语法。

Usage:
    from aill import AI, config, PromptConfig
    ai = AI(agent=my_agent, config=config)
"""

from .runtime import Runtime as AI
from .runtime import sorted
from .exceptions import (
    AIError,
    ValidationError,
    TimeoutError,
    CancelError,
    ConfigError,
)
from .prompts import PromptConfig, config

ai: AI | None = None

__all__ = [
    "AI",
    "ai",
    "sorted",
    "PromptConfig",
    "config",
    "AIError",
    "ValidationError",
    "TimeoutError",
    "CancelError",
    "ConfigError",
]
