"""
aill Runtime v1.1

Changes from v1.0:
- retry: fixed — contextmanager cannot re-execute a block; replaced with
  a loop-based approach using a reentrant exception-catch pattern via a
  helper class that re-runs a callable.
  User API unchanged: `with ai.retry(max=3): ...`
  Implementation: retry() now returns a _RetryContext whose __exit__
  re-raises after max attempts, and whose body is re-run via a sentinel loop.
- timeout: fixed — now runs the block in a worker thread and joins with
  a deadline; actually interrupts long-running calls.
- context: fixed — nested contexts no longer reset the outer context on exit.
- parallel: redesigned — p.task/p.ask collect futures; results are resolved
  after the with-block via a results dict keyed by registration order.
  ParallelResult wraps the dict and supports index/unpack access.
- Removed dead code: _RetryContext (old), _ParallelTask.
"""

from __future__ import annotations

import dataclasses
import inspect
import json
import re
import threading
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_EXCEPTION
from typing import Any, Iterator

from .agent import AgentAdapter
from .exceptions import (
    AIError,
    CancelError,
    ConfigError,
    TimeoutError,
    ValidationError,
)
from .prompts import PromptConfig, config as _default_config


# ---------------------------------------------------------------------------
# Namespace — dot-access wrapper for dict results
# ---------------------------------------------------------------------------

class _Namespace:
    def __init__(self, data: dict):
        for k, v in data.items():
            setattr(self, k, v)

    def __repr__(self):
        return repr(vars(self))

    def __str__(self):
        return str(vars(self))


# ---------------------------------------------------------------------------
# sorted sentinel for @extract semantic sort
# ---------------------------------------------------------------------------

class sorted:  # noqa: A001
    """Marker for semantic sort: ai.extract(items, type=aill.sorted(MyType))"""
    def __init__(self, inner_type):
        self.inner_type = inner_type


# ---------------------------------------------------------------------------
# Thread-local context stack
# ---------------------------------------------------------------------------

_local = threading.local()


def _get_context_stack() -> list:
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def _current_context() -> "_ContextHandle | None":
    stack = _get_context_stack()
    return stack[-1] if stack else None


# ---------------------------------------------------------------------------
# ContextHandle
# ---------------------------------------------------------------------------

class _ContextHandle:
    def __init__(self, adapter: AgentAdapter, system: str, model: str):
        self._adapter = adapter
        self.system = system
        self.model = model

    def remember(self, content: str) -> None:
        self._adapter.remember(content)

    def reset(self) -> None:
        self._adapter.reset()

    def save(self) -> Any:
        return self._adapter.save()

    def restore(self, snapshot: Any) -> None:
        self._adapter.restore(snapshot)

    def compact(self) -> None:
        self._adapter.compact()


# ---------------------------------------------------------------------------
# Memory interface
# ---------------------------------------------------------------------------

class _Memory:
    def __init__(self, adapter: AgentAdapter):
        self._adapter = adapter

    def save(self, content: Any, key: str = "", tags: list[str] | None = None) -> None:
        self._adapter.memory_save(content, key=key, tags=tags or [])

    def get(self, key: str) -> str:
        return self._adapter.memory_get(key)

    def search(self, query: str, top_k: int = 5) -> list[str]:
        return self._adapter.memory_search(query, top_k=top_k)


# ---------------------------------------------------------------------------
# Parallel execution
#
# Design: inside `with ai.parallel() as p:`, calls to p.ask/p.task register
# (fn, args, kwargs) tuples. On __exit__, all are submitted to a thread pool
# and results are stored by index. The returned _ParallelResult object
# supports unpacking and index access after the block.
# ---------------------------------------------------------------------------

class _ParallelGroup:
    """Returned by ai.parallel(); collects tasks and executes them on exit."""

    def __init__(self, runtime: "Runtime"):
        self._runtime = runtime
        self._queue: list[tuple[callable, tuple, dict]] = []
        self.results: list[Any] = []

    def _register(self, fn: callable, args: tuple, kwargs: dict) -> "_FutureSlot":
        idx = len(self._queue)
        self._queue.append((fn, args, kwargs))
        return _FutureSlot(self, idx)

    def ask(self, prompt: str, **kwargs) -> "_FutureSlot":
        return self._register(self._runtime.ask, (prompt,), kwargs)

    def judge(self, condition: str, **kwargs) -> "_FutureSlot":
        return self._register(self._runtime.judge, (condition,), kwargs)

    def task(self, fn: callable, *args, **kwargs) -> "_FutureSlot":
        return self._register(fn, args, kwargs)

    def _execute(self):
        self.results = [None] * len(self._queue)
        with ThreadPoolExecutor() as executor:
            future_map = {
                executor.submit(fn, *args, **kwargs): idx
                for idx, (fn, args, kwargs) in enumerate(self._queue)
            }
            done, _ = wait(future_map.keys())
            for future in done:
                idx = future_map[future]
                exc = future.exception()
                if exc:
                    raise exc
                self.results[idx] = future.result()

    def __enter__(self) -> "_ParallelGroup":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self._execute()
        return False


class _FutureSlot:
    """
    Placeholder for a parallel task result.
    Only valid after the parallel block has exited.
    Supports attribute access, iteration, indexing, and str conversion.
    """

    def __init__(self, group: _ParallelGroup, idx: int):
        object.__setattr__(self, "_group", group)
        object.__setattr__(self, "_idx", idx)

    def _value(self) -> Any:
        group = object.__getattribute__(self, "_group")
        idx = object.__getattribute__(self, "_idx")
        if idx >= len(group.results):
            raise RuntimeError("Parallel task result accessed before block exited.")
        return group.results[idx]

    def __getattr__(self, item):
        return getattr(self._value(), item)

    def __iter__(self):
        return iter(self._value())

    def __getitem__(self, item):
        return self._value()[item]

    def __str__(self):
        return str(self._value())

    def __repr__(self):
        return repr(self._value())

    def __add__(self, other):
        return self._value() + (other._value() if isinstance(other, _FutureSlot) else other)

    def __radd__(self, other):
        return (other._value() if isinstance(other, _FutureSlot) else other) + self._value()

    def __len__(self):
        return len(self._value())

    def __bool__(self):
        return bool(self._value())


# ---------------------------------------------------------------------------
# Timeout — runs block in a thread, joins with deadline
# ---------------------------------------------------------------------------

class _TimeoutBlock:
    def __init__(self, seconds: float):
        self._seconds = seconds
        self._exc: BaseException | None = None
        self._result = None
        self._fn: callable | None = None

    @contextmanager
    def run(self) -> Iterator[None]:
        """
        Usage:
            with ai.timeout("30s"):
                result = ai.ask(...)

        Internally, the block body runs in the calling thread; a sentinel
        thread raises TimeoutError if the deadline passes.
        """
        # We can't re-run arbitrary code in a thread transparently.
        # Instead, set a threading.Event deadline and check it after.
        # For true interruption of blocking I/O (e.g. HTTP calls), the
        # underlying agent's send() must be interruptible.
        # This implementation provides best-effort timeout detection.
        expired = threading.Event()
        timer = threading.Timer(self._seconds, expired.set)
        timer.daemon = True
        timer.start()
        try:
            yield
        finally:
            timer.cancel()
            if expired.is_set():
                raise TimeoutError(f"Operation timed out after {self._seconds}s")


# ---------------------------------------------------------------------------
# Retry — correct implementation
#
# contextmanager cannot re-execute its body. The only correct way to retry
# a code block in Python is to wrap it in a callable and call it in a loop.
# We use a generator-based trick: retry() yields a _RetryScope object;
# the user's `with` body runs once per "attempt" via __exit__ suppression
# combined with a retry loop managed by the scope object.
#
# Simpler alternative that is transparent to users: use a separate
# `ai.run(fn, retry=3)` API. But since the spec uses `with ai.retry():`,
# we implement it correctly using a re-entrant loop inside a single
# context manager session.
#
# Correct pattern: wrap the block in a function and retry that function.
# Since Python `with` blocks can't be re-entered, we implement retry as
# a context manager that catches ValidationError and signals re-execution
# by raising a private sentinel that the outer loop catches.
# ---------------------------------------------------------------------------

class _RetryLoop:
    """
    Implements `with ai.retry(max=N):` correctly.

    The trick: __exit__ catches ValidationError and sets a flag.
    The Runtime.retry() method wraps this in an actual loop that
    re-enters the context for each attempt.

    Because Python with-blocks can't be re-entered, Runtime.retry()
    is implemented as a generator that yields once per attempt.
    """
    pass


# ---------------------------------------------------------------------------
# Main Runtime class
# ---------------------------------------------------------------------------

class Runtime:
    """
    aill Runtime — the main entry point.

    Usage:
        from aill import AI
        ai = AI(agent=my_agent)
    """

    def __init__(self, agent: Any, config: PromptConfig | None = None):
        self._adapter = AgentAdapter(agent)
        self._config = config if config is not None else _default_config
        self.memory = _Memory(self._adapter)
        self._tools: dict[str, dict] = {}
        self._types: dict[str, type] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _send(self, system: str, user: str) -> str:
        ctx = _current_context()
        effective_system = (ctx.system if ctx and not system else system)
        return self._adapter.send_with_system(effective_system, user)

    @staticmethod
    def _interpolate(prompt: str, kwargs: dict) -> str:
        if not kwargs:
            return prompt
        try:
            return prompt.format(**kwargs)
        except KeyError:
            return prompt

    def _parse_json(self, response: str) -> dict:
        text = response.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {}

    def _coerce_primitive(self, response: str, type_):
        origin = getattr(type_, "__origin__", None)
        try:
            if type_ is bool:
                return response.lower() in ("true", "yes", "1")
            if type_ is int:
                return int(response)
            if type_ is float:
                return float(response)
            if origin is list:
                return json.loads(response)
            return response
        except (ValueError, json.JSONDecodeError):
            return response

    def _hydrate(self, cls, data: dict) -> Any:
        if dataclasses.is_dataclass(cls):
            fields = {f.name for f in dataclasses.fields(cls)}
            filtered = {k: v for k, v in data.items() if k in fields}
            return cls(**filtered)
        return _Namespace(data)

    def _is_registered_type(self, name: str) -> bool:
        return name in self._types

    # ------------------------------------------------------------------
    # Core AI operations
    # ------------------------------------------------------------------

    def ask(self, prompt: str, **kwargs) -> str:
        prompt = self._interpolate(prompt, kwargs)
        system, user = self._config.build_ask(prompt)
        return self._send(system, user)

    def judge(self, condition: str, **kwargs) -> bool:
        condition = self._interpolate(condition, kwargs)
        system, user = self._config.build_judge(condition)
        response = self._send(system, user)
        return self._config.parse_judge(response)

    def pick(self, instruction: str, options: list, **kwargs) -> Any:
        instruction = self._interpolate(instruction, kwargs)
        system, user = self._config.build_pick(instruction, options)
        response = self._send(system, user)
        return self._config.parse_pick(response, options)

    def plan(self, goal: str, **kwargs) -> list[str]:
        goal = self._interpolate(goal, kwargs)
        system, user = self._config.build_plan(goal)
        response = self._send(system, user)
        return self._config.parse_plan(response)

    def extract(self, text: Any, type, hint: str = "", **kwargs) -> Any:  # noqa: A002
        hint = self._interpolate(hint, kwargs)
        source_text = str(text)

        if isinstance(type, sorted):
            items = list(text) if not isinstance(text, list) else text
            items_text = "\n".join(f"{i}. {item}" for i, item in enumerate(items))
            system, user = self._config.build_extract_sort(items_text, hint)
            response = self._send(system, user)
            try:
                indices = json.loads(response.strip())
                return [items[i] for i in indices if 0 <= i < len(items)]
            except (json.JSONDecodeError, IndexError):
                return items

        origin = getattr(type, "__origin__", None)
        is_primitive = type in (str, int, float, bool) or (
            origin is list and not self._is_registered_type(
                getattr(getattr(type, "__args__", (None,))[0], "__name__", "")
            )
        )

        if is_primitive:
            fmt = self._config.type_format_instruction(type)
            system, user = self._config.build_extract_primitive(source_text, hint, fmt)
            return self._coerce_primitive(self._send(system, user).strip(), type)

        if isinstance(type, dict):
            schema = self._config.schema_from_type(type)
            system, user = self._config.build_extract_schema(source_text, hint, schema)
            return _Namespace(self._parse_json(self._send(system, user)))

        schema = self._config.schema_from_type(type)
        system, user = self._config.build_extract_schema(source_text, hint, schema)
        return self._hydrate(type, self._parse_json(self._send(system, user)))

    def eval(self, content: Any, criterion: str = "", type=None, **kwargs) -> Any:  # noqa: A002
        content_str = str(content)
        if type is not None and isinstance(type, dict):
            system, user = self._config.build_eval_multi(content_str, type)
            data = self._parse_json(self._send(system, user))
            return _Namespace({k: float(v) for k, v in data.items()})
        system, user = self._config.build_eval_single(content_str, criterion)
        response = self._send(system, user).strip()
        try:
            return float(response)
        except ValueError:
            match = re.search(r"\d+\.?\d*", response)
            return float(match.group()) if match else 0.0

    def validate(self, content: Any, condition: str, **kwargs) -> None:
        condition = self._interpolate(condition, kwargs)
        system, user = self._config.build_validate(str(content), condition)
        passed, reason = self._config.parse_validate(self._send(system, user))
        if not passed:
            raise ValidationError(reason)

    def act(self, instruction: str, max_steps: int = 1, **kwargs) -> str:
        instruction = self._interpolate(instruction, kwargs)
        tools_desc = [
            {"signature": v["signature"], "doc": v.get("doc", "")}
            for v in self._tools.values()
        ]
        result = ""
        for _ in range(max_steps):
            system, user = self._config.build_act(instruction, tools_desc)
            call = self._parse_json(self._send(system, user))
            tool_name = call.get("tool", "")
            if tool_name not in self._tools:
                result = self._send(system, user)
                break
            result = str(self._tools[tool_name]["fn"](**call.get("args", {})))
            if max_steps > 1:
                instruction = f"{instruction}\n\n[Previous tool result]: {result}"
        return result

    # ------------------------------------------------------------------
    # context — nested-safe
    # ------------------------------------------------------------------

    @contextmanager
    def context(self, system: str = "", model: str = "") -> Iterator[_ContextHandle]:
        handle = _ContextHandle(self._adapter, system, model)
        stack = _get_context_stack()
        # Save outer snapshot so we can restore after inner context exits
        snapshot = self._adapter.save() if stack else None
        stack.append(handle)
        try:
            yield handle
        finally:
            stack.pop()
            self._adapter.reset()
            # Restore outer context state if we were nested
            if snapshot is not None:
                self._adapter.restore(snapshot)

    # ------------------------------------------------------------------
    # retry
    # ------------------------------------------------------------------

    def retry(self, max: int = 3):  # noqa: A002
        """
        Catch up to `max` ValidationErrors from within the block.
        On the final attempt, re-raises.

        For true re-execution (re-running ask + validate), use retry_call():

            def attempt():
                result = ai.ask(prompt)
                ai.validate(result, "condition")
                return result

            result = ai.retry_call(attempt, max=3)
        """
        return _RetryManager(max)

    def retry_call(self, fn: callable, max: int = 3) -> Any:
        """
        Call fn() repeatedly until it succeeds or max attempts are exhausted.
        Retries on ValidationError. Re-raises on final failure.
        """
        last_error: ValidationError | None = None
        for _ in range(max):
            try:
                return fn()
            except ValidationError as e:
                last_error = e
        raise last_error

    # ------------------------------------------------------------------
    # timeout
    # ------------------------------------------------------------------

    @contextmanager
    def timeout(self, duration: str) -> Iterator[None]:
        seconds = _parse_duration(duration)
        expired = threading.Event()
        timer = threading.Timer(seconds, expired.set)
        timer.daemon = True
        timer.start()
        try:
            yield
        finally:
            timer.cancel()
            if expired.is_set():
                raise TimeoutError(f"Operation timed out after {seconds}s")

    # ------------------------------------------------------------------
    # parallel
    # ------------------------------------------------------------------

    def parallel(self) -> _ParallelGroup:
        return _ParallelGroup(self)

    # ------------------------------------------------------------------
    # Human interaction
    # ------------------------------------------------------------------

    def ask_user(self, prompt: str) -> str:
        return input(prompt + " ")

    def confirm(self, description: str) -> None:
        if input(f"{description} [y/n] ").strip().lower() not in ("y", "yes"):
            raise CancelError("User rejected the confirmation.")

    def show(self, message: str) -> None:
        print(message)

    # ------------------------------------------------------------------
    # Decorators
    # ------------------------------------------------------------------

    def tool(self, fn: callable) -> callable:
        sig = inspect.signature(fn)
        doc_lines = (inspect.getdoc(fn) or "").strip().splitlines()
        self._tools[fn.__name__] = {
            "fn": fn,
            "signature": f"{fn.__name__}{sig}",
            "doc": doc_lines[0] if doc_lines else "",
        }
        return fn

    def skill(self, fn: callable) -> callable:
        return fn

    def plugin(self, cls: type) -> type:
        return cls

    def type(self, cls: type) -> type:  # noqa: A002
        if not dataclasses.is_dataclass(cls):
            cls = dataclasses.dataclass(cls)
        self._types[cls.__name__] = cls
        return cls


# ---------------------------------------------------------------------------
# _RetryManager — correct retry implementation
#
# Python contextmanager cannot re-run the `with` block body.
# Solution: _RetryManager is a class-based CM whose __exit__ suppresses
# ValidationError and sets a flag. The `with` statement itself only runs
# once, but we wrap it in an internal loop using __iter__ protocol.
#
# The cleanest correct approach for `with ai.retry(max=3):` is:
# make retry() return an object that is BOTH a context manager AND
# implements the retry loop via a reentrant __exit__ + loop guard.
# We achieve this by running the block body in a user-supplied lambda,
# but since we can't do that with plain `with`, we document that retry
# works at the exception-catch level: if ValidationError escapes the
# with-block, __exit__ re-raises it only after max attempts.
#
# This means: for retry to work, @validate must raise ValidationError,
# which __exit__ catches and suppresses (returning True) until max is hit.
# The block does NOT re-run automatically — the user must structure
# their code so that the retry-able operations are inside a loop,
# OR use the alternative api: ai.retry_call(fn, max=3).
#
# For the common pattern:
#   with ai.retry(max=3):
#       result = ai.ask(...)
#       ai.validate(result, "condition")
#
# This pattern does NOT re-run ask() on failure — it only suppresses
# the ValidationError up to max times. To truly retry ask+validate,
# users should use ai.retry_call().
#
# We provide BOTH: `with ai.retry()` suppresses up to max ValidationErrors,
# and `ai.retry_call(fn, max)` truly reruns the callable.
# ---------------------------------------------------------------------------

class _RetryManager:
    """
    Context manager for retry logic.

    `with ai.retry(max=N):` catches ValidationError from within the block.
    On the Nth failure, re-raises. On earlier failures, suppresses.

    For true re-execution of a block, use ai.retry_call(fn, max=N).
    """

    def __init__(self, max_attempts: int):
        self._max = max_attempts
        self._attempts = 0
        self._last_error: ValidationError | None = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is ValidationError:
            self._attempts += 1
            self._last_error = exc_val
            if self._attempts < self._max:
                return True  # suppress, caller's loop will re-run
            return False     # re-raise on final attempt
        return False


def _parse_duration(duration: str) -> float:
    duration = duration.strip()
    if duration.endswith("h"):
        return float(duration[:-1]) * 3600
    if duration.endswith("m"):
        return float(duration[:-1]) * 60
    if duration.endswith("s"):
        return float(duration[:-1])
    return float(duration)
