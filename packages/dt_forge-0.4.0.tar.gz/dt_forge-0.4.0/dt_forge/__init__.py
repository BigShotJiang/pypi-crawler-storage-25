"""DT-Forge: Domain-agnostic Python framework for digital twin architectures."""

__version__ = "0.1.0"

from dt_forge.core.base import AbstractDigitalTwin, LayerBase
from dt_forge.core.config import TwinConfig, SensorFieldSpec
from dt_forge.core.events import EventBus, DomainEvent

__all__ = [
    "AbstractDigitalTwin",
    "LayerBase",
    "TwinConfig",
    "SensorFieldSpec",
    "EventBus",
    "DomainEvent",
]
