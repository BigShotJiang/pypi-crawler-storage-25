from dt_forge.ml.corpus import TrainingCorpus

__all__ = ["TrainingCorpus"]
