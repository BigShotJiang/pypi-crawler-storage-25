"""MQTT ingestor with Pydantic schema validation and dead-letter routing."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable, TYPE_CHECKING

from dt_forge.core.base import LayerBase
from dt_forge.core.events import DomainEvent
from dt_forge.network.transport import MQTTTransport

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.writer import TelemetryRouter

log = logging.getLogger(__name__)


class MQTTIngestor(LayerBase):
    """
    Subscribes to the twin's telemetry topic, validates incoming payloads,
    and routes valid messages to the TelemetryRouter.

    Invalid messages are forwarded to the dead-letter topic.
    """

    layer_name = "network"

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        router: "TelemetryRouter",
        schema_validator: Callable[[dict], dict] | None = None,
    ):
        super().__init__(config, event_bus)
        self.router = router
        self._validator = schema_validator or self._default_validator
        self._transport = MQTTTransport(config, role="ingestor")
        self._dead_letter_topic = f"dt/{config.asset_id}/dead_letter"
        self._loop: asyncio.AbstractEventLoop | None = None

    def _default_validator(self, payload: dict) -> dict:
        """Keep only numeric values whose key matches a declared sensor field.

        Always passes through the ``fault_injected`` marker so the
        TelemetryRouter can log fault events. Anything else is dropped.
        """
        allowed = set(self.config.field_names) | {"fault_injected"}
        return {
            k: v
            for k, v in payload.items()
            if k in allowed and isinstance(v, (int, float, bool))
        }

    def _on_message(self, payload: dict) -> None:
        try:
            validated = self._validator(payload)
        except Exception as e:
            log.warning("Invalid telemetry payload: %s — %s", payload, e)
            self._transport.publish(
                self._dead_letter_topic,
                {"error": str(e), "payload": payload},
            )
            return

        if self._loop is None:
            log.warning("Message received before event loop was captured; dropping")
            return

        asyncio.run_coroutine_threadsafe(self.router.route(validated), self._loop)
        asyncio.run_coroutine_threadsafe(
            self.bus.publish(
                DomainEvent(
                    event_type="telemetry.received",
                    source_layer="network",
                    source_asset=self.config.asset_id,
                    payload={"field_count": len(validated)},
                )
            ),
            self._loop,
        )

    async def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._running = True
        self._transport.connect()
        self._transport.subscribe(self.config.topic_telemetry, self._on_message)
        self.log.info(
            "MQTT ingestor listening on '%s'", self.config.topic_telemetry
        )
        while self._running:
            await asyncio.sleep(1.0)

    async def stop(self) -> None:
        self._running = False
        self._transport.disconnect()
