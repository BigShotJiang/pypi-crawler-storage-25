"""Versioned rule repository — stores reactive rules in PostgreSQL with hot-reload."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from dt_forge.data.storage.postgres import PostgresAdapter

log = logging.getLogger(__name__)

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS dt_rules (
    id          SERIAL PRIMARY KEY,
    asset_id    TEXT NOT NULL,
    rule_name   TEXT NOT NULL,
    rule_json   JSONB NOT NULL,
    version     INTEGER NOT NULL DEFAULT 1,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  DOUBLE PRECISION NOT NULL,
    updated_at  DOUBLE PRECISION NOT NULL
);
"""


@dataclass
class PersistedRule:
    rule_name: str
    condition_type: str       # "threshold" | "custom_fn_name"
    params: dict[str, Any]
    severity: str             # "warning" | "critical"
    version: int = 1
    is_active: bool = True


class RuleRepository:
    """
    PostgreSQL-backed rule store. Supports:
    - Adding/updating/deactivating rules
    - Hot-reload: callers poll load_active_rules() to get the latest set
    - Version audit trail
    """

    def __init__(self, pg: "PostgresAdapter", asset_id: str) -> None:
        self._pg = pg
        self._asset_id = asset_id

    async def setup(self) -> None:
        await self._pg.execute(_CREATE_TABLE)
        log.info("RuleRepository ready for asset %s", self._asset_id)

    async def upsert(self, rule: PersistedRule) -> None:
        existing = await self._pg.fetchrow(
            "SELECT id, version FROM dt_rules WHERE asset_id=$1 AND rule_name=$2",
            self._asset_id, rule.rule_name,
        )
        now = time.time()
        if existing:
            await self._pg.execute(
                """UPDATE dt_rules
                   SET rule_json=$1, version=$2, is_active=$3, updated_at=$4
                   WHERE id=$5""",
                json.dumps({"condition_type": rule.condition_type,
                            "params": rule.params, "severity": rule.severity}),
                existing["version"] + 1,
                rule.is_active,
                now,
                existing["id"],
            )
        else:
            await self._pg.execute(
                """INSERT INTO dt_rules (asset_id, rule_name, rule_json, version,
                                        is_active, created_at, updated_at)
                   VALUES ($1,$2,$3,$4,$5,$6,$7)""",
                self._asset_id, rule.rule_name,
                json.dumps({"condition_type": rule.condition_type,
                            "params": rule.params, "severity": rule.severity}),
                rule.version, rule.is_active, now, now,
            )

    async def deactivate(self, rule_name: str) -> None:
        await self._pg.execute(
            "UPDATE dt_rules SET is_active=FALSE, updated_at=$1 WHERE asset_id=$2 AND rule_name=$3",
            time.time(), self._asset_id, rule_name,
        )

    async def load_active_rules(self) -> list[PersistedRule]:
        rows = await self._pg.fetch(
            "SELECT rule_name, rule_json, version FROM dt_rules "
            "WHERE asset_id=$1 AND is_active=TRUE ORDER BY rule_name",
            self._asset_id,
        )
        result = []
        for row in rows:
            data = row["rule_json"] if isinstance(row["rule_json"], dict) else json.loads(row["rule_json"])
            result.append(PersistedRule(
                rule_name=row["rule_name"],
                condition_type=data["condition_type"],
                params=data["params"],
                severity=data["severity"],
                version=row["version"],
            ))
        return result

    async def history(self, rule_name: str) -> list[dict]:
        rows = await self._pg.fetch(
            "SELECT * FROM dt_rules WHERE asset_id=$1 AND rule_name=$2 ORDER BY version",
            self._asset_id, rule_name,
        )
        # Decode rule_json so callers get the same shape as load_active_rules
        # (asyncpg may return a JSON string for JSONB columns depending on the
        # codec configuration).
        for row in rows:
            raw = row.get("rule_json")
            if isinstance(raw, str):
                try:
                    row["rule_json"] = json.loads(raw)
                except Exception:
                    pass
        return rows
