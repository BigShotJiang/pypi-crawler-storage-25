"""ThresholdRuleEngine with FSM powered by the transitions library."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from transitions import Machine

from dt_forge.core.base import LayerBase
from dt_forge.core.events import DomainEvent
from dt_forge.reactive.base import Rule

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.storage.base import TimeSeriesStore, CacheStore, DocumentStore

log = logging.getLogger(__name__)


class ThresholdRuleEngine(LayerBase):
    """
    Evaluates per-field threshold rules and drives a finite state machine.

    States: running → warning → shutdown
    Custom Rule objects can be added alongside the built-in threshold checks.
    """

    layer_name = "reactive"

    _states = ["running", "warning", "shutdown"]
    _transitions = [
        {"trigger": "raise_warning", "source": "running", "dest": "warning"},
        {"trigger": "shutdown_asset", "source": ["running", "warning"], "dest": "shutdown"},
        {"trigger": "recover", "source": "warning", "dest": "running"},
        {"trigger": "restart", "source": "shutdown", "dest": "running"},
    ]

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        ts_store: "TimeSeriesStore",
        cache: "CacheStore",
        doc_store: "DocumentStore",
        custom_rules: list[Rule] | None = None,
        eval_interval: int = 5,
    ):
        super().__init__(config, event_bus)
        self.ts = ts_store
        self.cache = cache
        self.doc = doc_store
        self.custom_rules = custom_rules or []
        self.eval_interval = eval_interval

        # ignore_invalid_triggers prevents the library from raising MachineError
        # when a trigger is fired that has no transition from the current state.
        Machine(
            model=self,
            states=self._states,
            initial="running",
            transitions=self._transitions,
            ignore_invalid_triggers=True,
        )

    async def evaluate(self) -> str:
        """Run threshold + custom rules, drive FSM, return current state."""
        crit, warn = 0, 0

        for field, t in self.config.thresholds.items():
            val = self.ts.get_latest(field)
            if val is None:
                continue
            low = t.get("low", False)
            if (low and val < t["crit"]) or (not low and val > t["crit"]):
                crit += 1
            elif (low and val < t["warn"]) or (not low and val > t["warn"]):
                warn += 1

        readings = {f: self.ts.get_latest(f) for f in self.config.field_names}
        for rule in self.custom_rules:
            trigger = rule.evaluate(readings)
            if trigger == "critical":
                crit += 1
            elif trigger == "warning":
                warn += 1

        previous = self.state  # type: ignore[attr-defined]

        if crit > 0 and self.state != "shutdown":  # type: ignore[attr-defined]
            self.shutdown_asset()  # type: ignore[attr-defined]
        elif warn > 0 and self.state == "running":  # type: ignore[attr-defined]
            self.raise_warning()  # type: ignore[attr-defined]
        elif warn == 0 and self.state == "warning":  # type: ignore[attr-defined]
            self.recover()  # type: ignore[attr-defined]

        current = self.state  # type: ignore[attr-defined]

        if current != previous:
            severity = "critical" if current == "shutdown" else "warning"
            self.doc.log_event(
                "state_change",
                {"from": previous, "to": current},
                severity=severity,
            )
            await self.bus.publish(
                DomainEvent(
                    event_type="state.changed",
                    source_layer="reactive",
                    source_asset=self.config.asset_id,
                    payload={"from": previous, "to": current},
                    severity=severity,
                )
            )
            self.log.info("State: %s → %s", previous, current)

        self.cache.set_state(current)
        return current

    async def start(self) -> None:
        self._running = True
        self.log.info("ThresholdRuleEngine started (interval=%ds)", self.eval_interval)
        while self._running:
            try:
                await self.evaluate()
            except Exception as e:
                self.log.error("Rule engine error: %s", e)
            await asyncio.sleep(self.eval_interval)

    def get_state(self) -> str:
        # self.state is injected at runtime by transitions.Machine; mypy cannot see it.
        return self.state  # type: ignore[attr-defined]
