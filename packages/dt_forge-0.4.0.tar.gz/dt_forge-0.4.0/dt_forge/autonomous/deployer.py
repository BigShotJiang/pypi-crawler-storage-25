"""PolicyDeployer: live RL inference using a trained SB3 policy."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from dt_forge.autonomous.gym_env import GenericTwinEnv
    from dt_forge.data.storage.base import TimeSeriesStore
    from dt_forge.network.transport import MQTTTransport
    from dt_forge.core.config import TwinConfig

log = logging.getLogger(__name__)


class PolicyDeployer:
    """
    Loads a trained SB3 policy and applies it in a live twin loop.

    On each step_once() call:
    1. Reads current observations from InfluxDB
    2. Runs the policy to get an action
    3. Publishes the control command via MQTT
    """

    def __init__(
        self,
        policy_path: str,
        config: "TwinConfig",
        ts_store: "TimeSeriesStore",
        mqtt_transport: "MQTTTransport",
        obs_fields: list[str],
        control_field: str,
        ctrl_min: float,
        ctrl_max: float,
        algorithm: str = "SAC",
    ):
        from stable_baselines3 import SAC, TD3, PPO, A2C

        self._cfg = config
        self._ts = ts_store
        self._mqtt = mqtt_transport
        self._obs_fields = obs_fields
        self._control_field = control_field
        self._ctrl_min = ctrl_min
        self._ctrl_max = ctrl_max

        _algo_map = {"SAC": SAC, "TD3": TD3, "PPO": PPO, "A2C": A2C}
        AlgoClass = _algo_map.get(algorithm.upper(), SAC)
        self._policy = AlgoClass.load(policy_path)
        log.info("PolicyDeployer loaded '%s' (%s)", policy_path, algorithm)

    def _get_observation(self) -> np.ndarray:
        return np.array(
            [self._ts.get_latest(f) or 0.0 for f in self._obs_fields],
            dtype=np.float32,
        )

    def _scale_action(self, action: np.ndarray) -> float:
        a = float(np.clip(action[0], -1.0, 1.0))
        return self._ctrl_min + (a + 1.0) / 2.0 * (self._ctrl_max - self._ctrl_min)

    async def step_once(self) -> float:
        obs = self._get_observation()
        action, _ = self._policy.predict(obs, deterministic=True)
        ctrl = self._scale_action(action)
        self._mqtt.publish(
            self._cfg.topic_control,
            {self._control_field: round(ctrl, 4)},
        )
        return ctrl
