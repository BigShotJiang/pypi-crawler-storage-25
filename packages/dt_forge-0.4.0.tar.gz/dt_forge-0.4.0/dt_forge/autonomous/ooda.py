"""OODALoop: Observe-Orient-Decide-Act autonomous control layer."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

from dt_forge.autonomous.base import AbstractAutonomousController
from dt_forge.core.base import LayerBase
from dt_forge.core.events import DomainEvent

if TYPE_CHECKING:
    from dt_forge.autonomous.deployer import PolicyDeployer
    from dt_forge.autonomous.overseer import AutonomousOverseer
    from dt_forge.autonomous.planner import GoalPlanner
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.storage.base import CacheStore, DocumentStore, TimeSeriesStore
    from dt_forge.intelligent.mas import MultiAgentSystem
    from dt_forge.notifications.notifier import HumanNotifier
    from dt_forge.reactive.rule_engine import ThresholdRuleEngine
    from dt_forge.services.ditto.client import DittoClient
    from dt_forge.simulation.base import TwinModel

log = logging.getLogger(__name__)


class OODALoop(LayerBase, AbstractAutonomousController):
    """
    The OODA loop provides full situational awareness and autonomous control.

    Observe  — gather state from all lower layers
    Orient   — contextualise using models, history, goals
    Decide   — select action plan (rule-based, RL policy, goal planner)
    Act      — execute actions on lower layers or via connectors
    """

    layer_name = "autonomous"

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        ts_store: "TimeSeriesStore",
        cache: "CacheStore",
        doc_store: "DocumentStore",
        ditto_client: "DittoClient",
        models: dict[str, "TwinModel"],
        reactive: "ThresholdRuleEngine",
        mas: "MultiAgentSystem",
        connectors: list,
        planner: "GoalPlanner",
        policy: "PolicyDeployer | None" = None,
        loop_interval: int = 5,
        notifier: "HumanNotifier | None" = None,
        overseer: "AutonomousOverseer | None" = None,
    ):
        super().__init__(config, event_bus)
        self.ts = ts_store
        self.cache = cache
        self.doc = doc_store
        self.ditto = ditto_client
        self.models = models
        self.reactive = reactive
        self.mas = mas
        self.connectors = connectors
        self.planner = planner
        self.policy = policy
        self.loop_interval = loop_interval
        self.notifier = notifier
        # Optional LLM overseer — when set, its strategic decision is merged
        # into the assessment dict the rule-based planner produces.
        self.overseer = overseer

    async def observe(self) -> dict:
        base = {
            "state": self.cache.get_state(),
            "health": self.cache.get_latest_cached("health_score"),
            "telemetry": {
                f: self.ts.get_latest(f) for f in self.config.field_names
            },
            "recent_events": self.doc.get_recent_events(5),
        }
        if self.mas:
            base["mas_findings"] = {
                a.agent_name: self.mas.get_agent_detail(a.agent_name)
                for a in self.mas.agents
            }
        return base

    async def direct_agent(self, agent_name: str, question: str) -> str:
        """Send a targeted query to a named MAS agent from the autonomous layer."""
        if self.mas is None:
            return "MAS layer not available."
        return await self.mas.ask_agent(agent_name, question)

    async def orient(self, observation: dict) -> dict:
        assessment = await self.planner.assess(observation)
        if self.overseer is not None:
            try:
                decision = await self.overseer.run(observation)
                # The overseer's strategic decision joins the rule-based
                # assessment under explicit keys so safety constraints in
                # decide() can still take precedence over it.
                assessment["overseer_action"] = decision.action
                assessment["overseer_reasoning"] = decision.reasoning
                assessment["overseer_risk_level"] = decision.risk_level
                assessment["overseer_goals_addressed"] = decision.goals_addressed
                assessment["overseer_agent_queries"] = decision.agent_queries
                # Audit trail for every overseer decision.
                try:
                    self.doc.log_event(
                        "ooda_overseer_decision",
                        {
                            "action":           decision.action,
                            "reasoning":        decision.reasoning,
                            "risk_level":       decision.risk_level,
                            "goals_addressed":  decision.goals_addressed,
                            "agent_queries":    decision.agent_queries,
                        },
                        severity="info",
                    )
                except Exception as e:
                    self.log.debug("Overseer audit log failed: %s", e)
            except Exception as e:
                self.log.error("Overseer.run failed: %s", e)
        return assessment

    async def decide(self, observation: dict, assessment: dict) -> dict:
        # Layer 1 — hard safety constraints from the rule-based planner.
        # These override the overseer.
        if assessment.get("requires_human_intervention"):
            return {
                "action": "request_human",
                "reason": assessment.get("reason", "intervention required"),
            }
        if assessment.get("requires_shutdown"):
            return {
                "action": "shutdown",
                "reason": assessment.get("reason", "autonomous shutdown"),
            }
        if assessment.get("needs_external_data"):
            return {
                "action": "query_peer",
                "target_twin": assessment.get("target_twin", ""),
                "query": assessment.get("query", {}),
            }

        # Layer 2 — strategic decision from the overseer (if configured).
        # The overseer chooses among the actions declared at construction time.
        overseer_action = assessment.get("overseer_action")
        if overseer_action and overseer_action != "no_action":
            return {
                "action":      overseer_action,
                "reason":      assessment.get("overseer_reasoning", ""),
                "risk_level":  assessment.get("overseer_risk_level", "low"),
                "source":      "overseer",
            }

        # Layer 3 — RL tactical optimisation when conditions are nominal.
        if self.policy and assessment.get("risk_level") == "low":
            return {"action": "rl_control"}
        return {"action": "maintain_current"}

    async def act(self, plan: dict) -> None:
        action = plan["action"]

        if action == "request_human":
            self.doc.log_event(
                "human_intervention_requested", plan, severity="critical"
            )
            await self.bus.publish(
                DomainEvent(
                    event_type="autonomous.human_requested",
                    source_layer="autonomous",
                    source_asset=self.config.asset_id,
                    payload=plan,
                    severity="critical",
                )
            )
            self.log.warning("Human intervention requested: %s", plan.get("reason"))
            if self.notifier:
                await self.notifier.send(plan.get("reason", "intervention required"), plan)

        elif action == "shutdown":
            self.reactive.shutdown_asset()  # type: ignore[attr-defined]
            self.doc.log_event("autonomous_shutdown", plan, severity="critical")

        elif action == "query_peer":
            for conn in self.connectors:
                if conn.can_reach(plan.get("target_twin", "")):
                    result = await conn.query(plan["target_twin"], plan.get("query", {}))
                    self.doc.log_event("peer_query", {"result": result}, severity="info")
                    break

        elif action == "rl_control":
            if self.policy:
                await self.policy.step_once()

        elif plan.get("source") == "overseer":
            # Overseer-defined action: publish an event so domain code can act
            # on it. Subclasses that know the overseer's action vocabulary
            # should override act() to drive their own actuators.
            await self.bus.publish(
                DomainEvent(
                    event_type=f"autonomous.{action}",
                    source_layer="autonomous",
                    source_asset=self.config.asset_id,
                    payload=plan,
                )
            )
            self.doc.log_event(
                f"autonomous_{action}",
                plan,
                severity=plan.get("risk_level", "info") if plan.get("risk_level") in ("info", "warning", "critical") else "info",
            )

    async def start(self) -> None:
        self._running = True
        self.log.info("OODA autonomous loop started (interval=%ds)", self.loop_interval)
        while self._running:
            try:
                obs = await self.observe()
                assessment = await self.orient(obs)
                plan = await self.decide(obs, assessment)
                await self.act(plan)
                try:
                    # Publish a compact summary for the dashboard and monitoring tools.
                    # Wrapped in try/except so a Redis outage cannot kill the control loop.
                    self.cache.set_latest("ooda_last_cycle", {
                        "action":     plan.get("action", "unknown"),
                        "reason":     plan.get("reason", ""),
                        "risk_level": assessment.get("risk_level", ""),
                        "ts_s":       int(time.time()),
                    })
                except Exception:
                    pass
            except Exception as e:
                self.log.error("OODA loop error: %s", e)
            await asyncio.sleep(self.loop_interval)
