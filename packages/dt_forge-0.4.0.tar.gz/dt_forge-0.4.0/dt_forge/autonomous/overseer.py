"""AutonomousOverseer: LLM-driven Layer 6 decision agent for the OODA loop."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Awaitable

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.intelligent.mas import MultiAgentSystem

log = logging.getLogger(__name__)


@dataclass
class OverseerDecision:
    """Structured output from one overseer reasoning cycle."""
    action: str
    reasoning: str
    risk_level: str
    goals_addressed: list[str] = field(default_factory=list)
    agent_queries: list[dict] = field(default_factory=list)


def _safe_default() -> OverseerDecision:
    """Fresh fallback decision (never shared between cycles to avoid mutation)."""
    return OverseerDecision(
        action="no_action",
        reasoning="Overseer did not produce a structured decision — defaulting to no_action.",
        risk_level="low",
    )


class AutonomousOverseer:
    """
    LangChain tool-calling agent that drives the OODA orient and decide phases.

    On each call to run(), the overseer:
      1. Receives a formatted observation including all MAS agent findings
      2. Optionally calls query_mas_agent to interrogate specific agents
      3. Calls submit_decision to produce a structured OverseerDecision

    The decision is logged verbatim for human audit.  The OODA loop's decide()
    method then applies hard safety constraints on top — the overseer handles
    strategy, the constraints handle safety boundaries.

    Parameters
    ----------
    config         : TwinConfig
    llm            : LangChain chat model (ChatOllama, ChatOpenAI, etc.)
    mas            : The OODA loop's own MultiAgentSystem
    goals          : Goal names in priority order (used in system prompt)
    available_actions : Action strings the overseer may choose
    extra_query_fn : Optional async (agent_name, question) -> str for cross-MAS queries
    """

    def __init__(
        self,
        config: "TwinConfig",
        llm,
        mas: "MultiAgentSystem",
        goals: list[str],
        available_actions: list[str],
        extra_query_fn: Callable[[str, str], Awaitable[str]] | None = None,
    ):
        from langchain_classic.agents import AgentExecutor, create_tool_calling_agent
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
        from langchain_core.tools import StructuredTool

        self._mas = mas
        self._available_actions = available_actions
        self._extra_query_fn = extra_query_fn
        self._captured: OverseerDecision | None = None
        self._queries: list[dict] = []

        async def _query_agent(agent_name: str, question: str) -> str:
            """Query a named MAS agent for deeper analysis on a specific topic.

            agent_name: exact agent name (e.g. 'irrigation_decision', 'soil_moisture_monitor')
            question: specific analytical question to put to the agent
            """
            try:
                if self._extra_query_fn:
                    result = await self._extra_query_fn(agent_name, question)
                else:
                    result = await self._mas.ask_agent(agent_name, question)
                self._queries.append({
                    "agent": agent_name,
                    "question": question,
                    "answer": result[:500],
                })
                return result
            except Exception as e:
                return f"Error querying '{agent_name}': {e}"

        def _submit_decision(
            action: str,
            reasoning: str,
            risk_level: str,
            goals_addressed: list[str] | None = None,
        ) -> str:
            """Submit your final autonomous decision. You MUST call this tool.

            action       : one of the available actions listed in your instructions
            reasoning    : full explanation — cite specific agent findings and sensor values
            risk_level   : 'low', 'medium', 'high', or 'critical'
            goals_addressed : list of goal names this decision serves
            """
            self._captured = OverseerDecision(
                action=action,
                reasoning=reasoning,
                risk_level=risk_level,
                goals_addressed=goals_addressed or [],
                agent_queries=list(self._queries),
            )
            return "Decision recorded."

        tools = [
            StructuredTool.from_function(
                coroutine=_query_agent,
                name="query_mas_agent",
                description=(
                    "Query a specific MAS agent by name for deeper analysis. "
                    "Use when findings are ambiguous or you need more detail before deciding."
                ),
            ),
            StructuredTool.from_function(
                func=_submit_decision,
                name="submit_decision",
                description=(
                    "Submit your final autonomous decision. "
                    "MUST be called before finishing your analysis."
                ),
            ),
        ]

        prompt = ChatPromptTemplate.from_messages([
            ("system", self._system_prompt(config, goals, available_actions)),
            ("human", "{input}"),
            MessagesPlaceholder("agent_scratchpad"),
        ])

        agent = create_tool_calling_agent(llm, tools, prompt)
        self.executor = AgentExecutor(
            agent=agent, tools=tools,
            verbose=False,
            max_iterations=8,  # cap tool-call rounds to prevent runaway LLM loops
            return_intermediate_steps=False,
        )

    @staticmethod
    def _system_prompt(config, goals: list[str], available_actions: list[str]) -> str:
        goals_block = "\n".join(f"  {i+1}. {g}" for i, g in enumerate(goals))
        actions_block = ", ".join(f"'{a}'" for a in available_actions)
        return (
            f"You are the Autonomous Overseer of the '{config.asset_name}' digital twin "
            f"(ID: {config.asset_id}). You are Layer 6 — the highest-level autonomous "
            f"decision maker in a layered control architecture.\n\n"
            "LAYER RESPONSIBILITIES:\n"
            "  Layer 4 – Reactive:   Threshold rules, FSM transitions, PID control. "
            "Handles routine, deterministic situations automatically. You do NOT duplicate these.\n"
            "  Layer 5 – Intelligent: MAS agents that diagnose, analyse, and reason. "
            "They observe and produce findings but CANNOT act on their own.\n"
            "  Layer 6 – You:        Strategic, goal-driven decisions. You read MAS findings, "
            "query agents for deeper analysis when needed, and decide what the system should do "
            "at a level no lower layer can handle alone.\n\n"
            f"YOUR DECLARED GOALS (priority order):\n{goals_block}\n\n"
            f"AVAILABLE ACTIONS: {actions_block}\n\n"
            "YOUR PROCESS EACH CYCLE:\n"
            "1. Read the MAS agent findings. Agents flagging anomalies deserve attention.\n"
            "2. If any finding is ambiguous or you need deeper analysis, call query_mas_agent.\n"
            "3. Assess whether the situation requires strategic intervention or is already "
            "handled by lower layers.\n"
            "4. Reason explicitly about your declared goals and which are at risk.\n"
            "5. Call submit_decision with: action, your full reasoning (cite findings and "
            "sensor values), risk level, and which goals your decision addresses.\n\n"
            "CONSTRAINTS:\n"
            "- Choose 'no_action' when the reactive layer already covers the situation.\n"
            "- Only escalate to actuating actions (e.g. 'irrigate') when agent findings or "
            "telemetry justify it beyond what rule-based layers already handle.\n"
            "- Your reasoning is logged verbatim for human audit — be specific and traceable.\n"
            "- You MUST call submit_decision before finishing."
        )

    def _format_observation(self, observation: dict) -> str:
        lines = ["=== CURRENT SYSTEM STATE ==="]

        # Generic top-level fields that any OODA.observe() produces.
        if "state" in observation:
            lines.append(f"  operational_state: {observation['state']}")
        if "health" in observation and observation["health"] is not None:
            v = observation["health"]
            lines.append(f"  health_score: {v:.2f}" if isinstance(v, float) else f"  health_score: {v}")

        telemetry = observation.get("telemetry") or {}
        if telemetry:
            lines.append("\n=== TELEMETRY ===")
            for key, v in telemetry.items():
                if v is None:
                    lines.append(f"  {key}: n/a")
                elif isinstance(v, float):
                    lines.append(f"  {key}: {v:.4f}")
                else:
                    lines.append(f"  {key}: {v}")

        # Domain-specific subclasses may inject extra context — call back into
        # an overridable hook rather than baking field names into the framework.
        extra_lines = self._format_extra_context(observation)
        if extra_lines:
            lines.append("\n=== EXTRA CONTEXT ===")
            lines.extend(f"  {line}" for line in extra_lines)

        # MAS findings — consolidated from all twins
        all_findings: dict = observation.get("all_mas_findings") or {}
        if not all_findings:
            own = observation.get("mas_findings")
            if own:
                all_findings = {"this_twin": own}

        if all_findings:
            lines.append("\n=== MAS AGENT FINDINGS ===")
            for twin_label, findings in all_findings.items():
                if not findings:
                    continue
                lines.append(f"\n[{twin_label.upper()} agents]")
                for agent_name, detail in findings.items():
                    if not detail:
                        lines.append(f"  {agent_name}: (no data yet)")
                        continue
                    err = detail.get("error")
                    if err:
                        lines.append(f"  {agent_name}: ERROR — {err}")
                        continue
                    anomaly = detail.get("anomaly", False)
                    findings_inner = detail.get("findings") or {}
                    action  = findings_inner.get("action", "monitoring")
                    summary = findings_inner.get("summary", "")
                    flag = "⚠ ANOMALY" if anomaly else "OK"
                    lines.append(f"  {agent_name} [{flag}] action={action}")
                    if summary:
                        lines.append(f"    {summary[:350]}")

        recent = observation.get("recent_events", [])
        if recent:
            lines.append("\n=== RECENT EVENTS ===")
            for ev in recent[:5]:
                sev   = ev.get("severity", "info").upper()
                etype = ev.get("event_type", "unknown")
                lines.append(f"  [{sev}] {etype}")

        if self._mas:
            names = [a.agent_name for a in self._mas.agents]
            lines.append(f"\nAgents you can query: {', '.join(names)}")

        return "\n".join(lines)

    def _format_extra_context(self, observation: dict) -> list[str]:
        """Override in a subclass to add domain-specific context lines.

        Each returned string is a single context line shown to the overseer
        LLM. Return an empty list (the default) to add nothing.
        """
        return []

    async def run(self, observation: dict) -> OverseerDecision:
        """Run one overseer cycle. Returns a structured OverseerDecision."""
        # Reset per-cycle state so findings from the previous run don't bleed through.
        # _captured and _queries are written by tool closures (_submit_decision, _query_agent).
        self._captured = None
        self._queries = []
        try:
            await self.executor.ainvoke({"input": self._format_observation(observation)})
        except Exception as e:
            log.error("AutonomousOverseer cycle error: %s", e)
        if self._captured is None:
            log.warning("Overseer did not call submit_decision — applying safe default")
            return _safe_default()
        return self._captured
