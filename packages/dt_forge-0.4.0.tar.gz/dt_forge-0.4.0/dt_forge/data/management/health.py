"""Composite health score calculator."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.data.storage.base import TimeSeriesStore

log = logging.getLogger(__name__)


class HealthScoreCalculator:
    """
    Computes a 0–100 composite health score from threshold violations.

    Each field contributes equally; being in warning zone costs 50% of its
    weight and critical costs 100%.
    """

    def __init__(self, thresholds: dict):
        self.thresholds = thresholds

    def compute(self, ts_store: "TimeSeriesStore") -> float:
        if not self.thresholds:
            return 100.0

        total_penalty = 0.0
        weight_per_field = 100.0 / len(self.thresholds)

        for field, t in self.thresholds.items():
            try:
                val = ts_store.get_latest(field)
                if val is None:
                    continue
                low = t.get("low", False)
                in_crit = (low and val < t["crit"]) or (
                    not low and val > t["crit"]
                )
                in_warn = (low and val < t["warn"]) or (
                    not low and val > t["warn"]
                )
                if in_crit:
                    total_penalty += weight_per_field
                elif in_warn:
                    total_penalty += weight_per_field * 0.5
            except Exception as e:
                log.debug("Health calc error for '%s': %s", field, e)

        return max(0.0, round(100.0 - total_penalty, 1))
