"""Data management pipeline: smoothing, rate-of-change, quality flags, health score."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import numpy as np

from dt_forge.core.base import LayerBase
from dt_forge.data.management.health import HealthScoreCalculator

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.storage.base import TimeSeriesStore, CacheStore

log = logging.getLogger(__name__)


class DataManagementPipeline(LayerBase):
    """
    Periodic pipeline: rolling smoothing, rate-of-change, quality flags,
    composite health score.
    """

    layer_name = "data_management"

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        ts_store: "TimeSeriesStore",
        cache: "CacheStore",
        interval: int = 10,
        smooth_window: int = 5,
        lookback_minutes: int = 5,
    ):
        super().__init__(config, event_bus)
        self.ts = ts_store
        self.cache = cache
        self.interval = interval
        self.smooth_window = smooth_window
        self.lookback_minutes = lookback_minutes
        self.health_calc = HealthScoreCalculator(config.thresholds)

    async def run_once(self) -> None:
        processed = {}
        for fname in self.config.field_names:
            try:
                df = self.ts.query_recent(fname, minutes=self.lookback_minutes)
                if df is None or len(df) < 3:
                    continue
                vals = df["_value"].astype(float).values
                window = min(self.smooth_window, len(vals))
                smoothed = float(
                    np.convolve(vals, np.ones(window) / window, mode="valid")[-1]
                )
                roc = float(vals[-1] - vals[-2]) if len(vals) >= 2 else 0.0
                processed[f"{fname}_smooth"] = round(smoothed, 4)
                processed[f"{fname}_roc"] = round(roc, 4)
                processed[f"{fname}_quality"] = self._quality_flag(fname, vals[-1])
            except Exception as e:
                log.debug("Pipeline processing error for '%s': %s", fname, e)

        if processed:
            self.ts.write_point("asset_processed", processed)
            for k, v in processed.items():
                self.cache.set_latest(k, v)

        health = self.health_calc.compute(self.ts)
        self.ts.write_point("asset_health", {"health_score": health})
        self.cache.set_latest("health_score", health)

    def _quality_flag(self, field: str, value: float) -> float:
        t = self.config.thresholds.get(field)
        if not t:
            return 1.0
        low = t.get("low", False)
        if (low and value < t["crit"]) or (not low and value > t["crit"]):
            return 3.0
        if (low and value < t["warn"]) or (not low and value > t["warn"]):
            return 2.0
        return 1.0

    async def start(self) -> None:
        self._running = True
        self.log.info("Data management pipeline started (interval=%ss)", self.interval)
        while self._running:
            try:
                await self.run_once()
            except Exception as e:
                self.log.error("Pipeline error: %s", e)
            await asyncio.sleep(self.interval)
