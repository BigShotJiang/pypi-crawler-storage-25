"""MongoDB document store adapter."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig

log = logging.getLogger(__name__)


class MongoAdapter:
    """MongoDB adapter for asset metadata and event documents."""

    def __init__(self, config: "TwinConfig"):
        from pymongo import MongoClient

        self._cfg = config.mongo
        self._asset_id = config.asset_id
        self._client = MongoClient(self._cfg.uri)
        self._db = self._client[self._cfg.db]
        self._assets = self._db["assets"]
        self._events = self._db["events"]

    def upsert_asset_metadata(self, data: dict) -> None:
        try:
            self._assets.update_one(
                {"asset_id": self._asset_id},
                {"$set": {**data, "asset_id": self._asset_id,
                           "updated_at": datetime.now(timezone.utc)}},
                upsert=True,
            )
        except Exception as e:
            log.error("MongoDB upsert error: %s", e)

    def get_asset_metadata(self) -> dict:
        try:
            doc = self._assets.find_one(
                {"asset_id": self._asset_id}, {"_id": 0}
            )
            return doc or {}
        except Exception as e:
            log.error("MongoDB get_asset_metadata error: %s", e)
            return {}

    def log_event(
        self, event_type: str, payload: dict, severity: str = "info"
    ) -> None:
        try:
            self._events.insert_one({
                "asset_id": self._asset_id,
                "event_type": event_type,
                "payload": payload,
                "severity": severity,
                "timestamp": datetime.now(timezone.utc),
            })
        except Exception as e:
            log.error("MongoDB log_event error: %s", e)

    def get_recent_events(self, n: int = 20) -> list[dict]:
        try:
            cursor = (
                self._events
                .find({"asset_id": self._asset_id}, {"_id": 0})
                .sort("timestamp", -1)
                .limit(n)
            )
            return list(cursor)
        except Exception as e:
            log.error("MongoDB get_recent_events error: %s", e)
            return []

    def get_events_by_type(self, event_type: str, n: int = 20) -> list[dict]:
        """Return the most recent ``n`` events of a specific type, newest first."""
        try:
            cursor = (
                self._events
                .find(
                    {"asset_id": self._asset_id, "event_type": event_type},
                    {"_id": 0},
                )
                .sort("timestamp", -1)
                .limit(n)
            )
            return list(cursor)
        except Exception as e:
            log.error("MongoDB get_events_by_type error: %s", e)
            return []

    def close(self) -> None:
        self._client.close()
