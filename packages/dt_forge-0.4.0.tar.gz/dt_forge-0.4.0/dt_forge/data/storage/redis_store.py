"""Redis cache and pub/sub adapter."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig

log = logging.getLogger(__name__)


class RedisAdapter:
    """Redis adapter for fast state cache and pub/sub."""

    def __init__(self, config: "TwinConfig"):
        import redis as redis_lib

        self._cfg = config.redis
        self._asset_id = config.asset_id
        self._client = redis_lib.Redis.from_url(
            self._cfg.url, db=self._cfg.db, decode_responses=True
        )
        self._prefix = f"dt:{self._asset_id}"

    def set_latest(self, field: str, value: Any) -> None:
        try:
            self._client.set(f"{self._prefix}:latest:{field}", json.dumps(value))
        except Exception as e:
            log.debug("Redis set_latest error for '%s': %s", field, e)

    def get_latest_cached(self, field: str) -> Any:
        try:
            raw = self._client.get(f"{self._prefix}:latest:{field}")
            if raw is not None:
                return json.loads(raw)
        except Exception as e:
            log.debug("Redis get_latest_cached error for '%s': %s", field, e)
        return None

    def set_state(self, state: str) -> None:
        try:
            self._client.set(f"{self._prefix}:state", state)
        except Exception as e:
            log.debug("Redis set_state error: %s", e)

    def get_state(self) -> str:
        try:
            val = self._client.get(f"{self._prefix}:state")
            return val or "unknown"
        except Exception as e:
            log.debug("Redis get_state error: %s", e)
            return "unknown"

    async def publish(self, channel: str, message: dict) -> None:
        # The underlying redis-py client is synchronous; run it in the default
        # executor so a slow Redis hop cannot stall the asyncio event loop.
        payload = json.dumps(message, default=str)
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(
                None, lambda: self._client.publish(channel, payload)
            )
        except Exception as e:
            log.debug("Redis publish error on '%s': %s", channel, e)

    def close(self) -> None:
        self._client.close()
