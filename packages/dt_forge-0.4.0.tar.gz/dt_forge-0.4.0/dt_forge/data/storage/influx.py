"""InfluxDB 2 time-series adapter."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig

log = logging.getLogger(__name__)


class InfluxAdapter:
    """InfluxDB 2 adapter for time-series sensor data."""

    def __init__(self, config: "TwinConfig"):
        from influxdb_client import InfluxDBClient, WriteOptions
        from influxdb_client.client.write_api import SYNCHRONOUS

        self._cfg = config.influx
        self._asset_id = config.asset_id
        self._client = InfluxDBClient(
            url=self._cfg.url,
            token=self._cfg.token,
            org=self._cfg.org,
        )
        self._write_api = self._client.write_api(write_options=SYNCHRONOUS)
        self._query_api = self._client.query_api()

    def write_point(
        self,
        measurement: str,
        fields: dict[str, float],
        tags: dict[str, str] | None = None,
    ) -> None:
        from influxdb_client import Point
        from influxdb_client.domain.write_precision import WritePrecision

        p = Point(measurement).tag("asset_id", self._asset_id)
        if tags:
            for k, v in tags.items():
                p = p.tag(k, v)
        for k, v in fields.items():
            p = p.field(k, float(v))
        p = p.time(datetime.now(timezone.utc), WritePrecision.S)
        try:
            self._write_api.write(
                bucket=self._cfg.bucket, org=self._cfg.org, record=p
            )
        except Exception as e:
            log.error("InfluxDB write error: %s", e)

    def query_recent(
        self,
        field: str,
        minutes: int = 10,
        measurement: str = "asset_telemetry",
    ):
        import pandas as pd

        query = f"""
        from(bucket: "{self._cfg.bucket}")
          |> range(start: -{minutes}m)
          |> filter(fn: (r) => r._measurement == "{measurement}")
          |> filter(fn: (r) => r.asset_id == "{self._asset_id}")
          |> filter(fn: (r) => r._field == "{field}")
          |> sort(columns: ["_time"])
        """
        try:
            return self._query_api.query_data_frame(query, org=self._cfg.org)
        except Exception as e:
            log.error("InfluxDB query error: %s", e)
            return pd.DataFrame()

    def get_latest(
        self, field: str, measurement: str = "asset_telemetry"
    ) -> float | None:
        query = f"""
        from(bucket: "{self._cfg.bucket}")
          |> range(start: -1h)
          |> filter(fn: (r) => r._measurement == "{measurement}")
          |> filter(fn: (r) => r.asset_id == "{self._asset_id}")
          |> filter(fn: (r) => r._field == "{field}")
          |> last()
        """
        try:
            tables = self._query_api.query(query, org=self._cfg.org)
            for table in tables:
                for record in table.records:
                    return float(record.get_value())
        except Exception as e:
            log.debug("InfluxDB get_latest error for '%s': %s", field, e)
        return None

    def query_recent_fields(
        self,
        fields: list[str],
        minutes: int = 60,
        measurement: str = "asset_telemetry",
    ) -> dict[str, list[dict]]:
        """Query multiple fields over a time window in a single Flux request.

        Returns a dict mapping each field name to a list of
        ``{"ts": float_unix_seconds, "value": float}`` dicts, oldest first.
        Fields with no data will map to an empty list.
        """
        if not fields:
            return {}
        fields_filter = " or ".join(f'r._field == "{f}"' for f in fields)
        query = f"""
        from(bucket: "{self._cfg.bucket}")
          |> range(start: -{minutes}m)
          |> filter(fn: (r) => r._measurement == "{measurement}")
          |> filter(fn: (r) => r.asset_id == "{self._asset_id}")
          |> filter(fn: (r) => {fields_filter})
          |> sort(columns: ["_time"])
        """
        result: dict[str, list[dict]] = {f: [] for f in fields}
        try:
            tables = self._query_api.query(query, org=self._cfg.org)
            for table in tables:
                for record in table.records:
                    field = record.get_field()
                    if field in result:
                        result[field].append({
                            "ts":    record.get_time().timestamp(),
                            "value": float(record.get_value()),
                        })
        except Exception as e:
            log.error("InfluxDB query_recent_fields error: %s", e)
        return result

    def close(self) -> None:
        self._client.close()
