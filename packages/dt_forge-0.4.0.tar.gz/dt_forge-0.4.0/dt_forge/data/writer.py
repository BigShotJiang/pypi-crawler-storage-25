"""TelemetryRouter: validates and fans out incoming telemetry to storage backends."""

from __future__ import annotations

import time
import asyncio
import logging
from typing import TYPE_CHECKING

from dt_forge.core.base import LayerBase
from dt_forge.core.events import DomainEvent

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.storage.base import TimeSeriesStore, DocumentStore, CacheStore

log = logging.getLogger(__name__)


class TelemetryRouter(LayerBase):
    """
    Receives validated telemetry and fans it out to the appropriate stores.

    This is the entry point for data arriving from the network layer.
    """

    layer_name = "data"

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        ts_store: "TimeSeriesStore",
        doc_store: "DocumentStore",
        cache: "CacheStore",
    ):
        super().__init__(config, event_bus)
        self.ts = ts_store
        self.doc = doc_store
        self.cache = cache
        # Bound at 1000 to apply backpressure: if downstream processing stalls,
        # put() will block the ingest caller rather than growing memory unboundedly.
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=1000)

    async def route(self, data: dict) -> None:
        """Enqueue incoming telemetry for async processing."""
        await self._queue.put(data)

    async def _process(self, data: dict) -> None:
        fields = {
            k: float(v)
            for k, v in data.items()
            if k in self.config.field_names and v is not None
        }

        if fields:
            self.ts.write_point("asset_telemetry", fields)
            for k, v in fields.items():
                self.cache.set_latest(k, v)

        if data.get("fault_injected"):
            self.doc.log_event(
                "fault_injected", {"readings": fields}, severity="warning"
            )

        self.cache.set_latest("last_seen", time.time())

        await self.bus.publish(
            DomainEvent(
                event_type="telemetry.routed",
                source_layer="data",
                source_asset=self.config.asset_id,
                payload=fields,
            )
        )

    async def start(self) -> None:
        self._running = True
        self.log.info("TelemetryRouter started")
        while self._running:
            try:
                # 1-second timeout lets the loop re-check _running without blocking
                # indefinitely when the queue is empty (avoids a stuck shutdown).
                data = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                await self._process(data)
                self._queue.task_done()
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                self.log.error("TelemetryRouter error: %s", e)

    async def stop(self) -> None:
        self._running = False
        # Drain remaining items
        while not self._queue.empty():
            try:
                data = self._queue.get_nowait()
                await self._process(data)
                self._queue.task_done()
            except Exception:
                break
