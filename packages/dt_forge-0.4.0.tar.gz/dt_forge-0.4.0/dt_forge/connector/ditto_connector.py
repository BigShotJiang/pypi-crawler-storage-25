"""DittoConnector: cross-twin queries via Eclipse Ditto REST API."""

from __future__ import annotations

import logging
from typing import Any, Callable, Awaitable, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig

log = logging.getLogger(__name__)


class DittoConnector:
    """Cross-twin queries via Eclipse Ditto REST API (services layer)."""

    connector_type = "ditto"
    layer = "services"

    def __init__(
        self,
        config: "TwinConfig",
        remote_ditto_url: str | None = None,
    ):
        self._cfg = config.ditto
        self.ditto_url = remote_ditto_url or self._cfg.url
        self._auth = (self._cfg.user, self._cfg.password)
        self._namespace = self._cfg.namespace

    def can_reach(self, target_twin_id: str) -> bool:
        """Cheap optimistic check.

        We don't issue a live HTTP probe here because ``can_reach`` is called
        from async contexts (notably ``ConnectorRegistry.find_route``) and a
        blocking ``httpx.get`` would stall the event loop. ``query()``/``push()``
        already report transport failures via raised exceptions; use them when
        you need a real availability check.
        """
        return bool(target_twin_id)

    async def can_reach_async(self, target_twin_id: str) -> bool:
        """Live HTTP probe — call from async code when you actually need it."""
        thing_id = f"{self._namespace}:{target_twin_id}"
        try:
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    f"{self.ditto_url}/api/2/things/{thing_id}",
                    auth=self._auth,
                    timeout=5.0,
                )
                return r.status_code == 200
        except Exception:
            return False

    async def query(self, target_twin_id: str, request: dict) -> dict:
        thing_id = f"{self._namespace}:{target_twin_id}"
        feature = request.get("feature", "telemetry")
        async with httpx.AsyncClient() as client:
            r = await client.get(
                f"{self.ditto_url}/api/2/things/{thing_id}"
                f"/features/{feature}/properties",
                auth=self._auth,
                timeout=10.0,
            )
            r.raise_for_status()
            return r.json()

    async def push(self, target_twin_id: str, data: dict) -> None:
        thing_id = f"{self._namespace}:{target_twin_id}"
        # Copy so we don't mutate the caller's dict when extracting metadata.
        payload = dict(data)
        feature = payload.pop("_feature", "external_input")
        async with httpx.AsyncClient() as client:
            await client.patch(
                f"{self.ditto_url}/api/2/things/{thing_id}"
                f"/features/{feature}/properties",
                json=payload,
                auth=self._auth,
                timeout=10.0,
            )

    async def subscribe(
        self,
        target_twin_id: str,
        event_type: str,
        handler: Callable[[dict], Awaitable[None]],
    ) -> None:
        log.warning(
            "DittoConnector.subscribe not implemented — use MQTT or SSE for streaming"
        )
