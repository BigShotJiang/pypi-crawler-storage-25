"""Central registries for layers, models, and services."""

from __future__ import annotations

import logging
from typing import Any, Generic, TypeVar

log = logging.getLogger(__name__)

T = TypeVar("T")


class _Registry(Generic[T]):
    def __init__(self, label: str):
        self._items: dict[str, T] = {}
        self._label = label

    def register(self, name: str, item: T) -> None:
        if name in self._items:
            log.warning("%s registry: overwriting '%s'", self._label, name)
        self._items[name] = item

    def get(self, name: str) -> T:
        if name not in self._items:
            raise KeyError(f"{self._label} '{name}' not registered")
        return self._items[name]

    def all(self) -> dict[str, T]:
        return dict(self._items)

    def names(self) -> list[str]:
        return list(self._items.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._items


class LayerRegistry(_Registry[Any]):
    """Registry for DT layer instances."""

    def __init__(self):
        super().__init__("Layer")


class ModelRegistry(_Registry[Any]):
    """Registry for simulation model instances."""

    def __init__(self):
        super().__init__("Model")


class ServiceRegistry(_Registry[Any]):
    """Registry for service instances with topological sort."""

    def __init__(self):
        super().__init__("Service")

    def resolve_order(self) -> list[Any]:
        """Return services in dependency-safe start order (topological sort).

        Raises ``ValueError`` if the dependency graph contains a cycle.
        """
        services = self._items
        visited: set[str] = set()
        in_stack: set[str] = set()
        order: list[Any] = []

        def visit(name: str, path: list[str]) -> None:
            if name in visited:
                return
            if name in in_stack:
                cycle = " → ".join(path + [name])
                raise ValueError(f"Service dependency cycle detected: {cycle}")
            in_stack.add(name)
            svc = services.get(name)
            if svc is not None:
                for dep in getattr(svc, "dependencies", []):
                    visit(dep, path + [name])
            in_stack.discard(name)
            visited.add(name)
            if svc is not None:
                order.append(svc)

        for name in services:
            visit(name, [])
        return order
