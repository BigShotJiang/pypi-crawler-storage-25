"""Lifecycle manager for orchestrating twin initialisation, running, and shutdown."""

from __future__ import annotations

import asyncio
import logging
import signal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.core.base import AbstractDigitalTwin

log = logging.getLogger(__name__)


class TwinLifecycle:
    """
    Manages the full lifecycle of one or more digital twins.

    Usage::

        lifecycle = TwinLifecycle()
        lifecycle.add(my_twin)
        asyncio.run(lifecycle.run_forever())
    """

    def __init__(self):
        self._twins: list["AbstractDigitalTwin"] = []

    def add(self, twin: "AbstractDigitalTwin") -> None:
        self._twins.append(twin)

    async def initialise_all(self) -> None:
        for twin in self._twins:
            log.info("Initialising twin: %s", twin.config.asset_id)
            await twin.initialise()

    async def start_all(self) -> None:
        tasks = [asyncio.create_task(t.start()) for t in self._twins]
        await asyncio.gather(*tasks)

    async def stop_all(self) -> None:
        for twin in reversed(self._twins):
            log.info("Stopping twin: %s", twin.config.asset_id)
            await twin.stop()

    async def run_forever(self) -> None:
        """Initialise all twins, run until SIGINT/SIGTERM, then stop cleanly."""
        loop = asyncio.get_running_loop()
        stop_event = asyncio.Event()

        def _handle_signal():
            log.info("Shutdown signal received")
            stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _handle_signal)

        await self.initialise_all()
        run_task = asyncio.create_task(self.start_all())

        await stop_event.wait()
        run_task.cancel()
        await self.stop_all()
        log.info("All twins stopped")
