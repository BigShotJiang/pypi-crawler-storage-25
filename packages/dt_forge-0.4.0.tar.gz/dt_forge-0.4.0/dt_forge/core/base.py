"""Core abstract base classes for all DT layers and the twin itself."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus


class LayerBase(ABC):
    """Abstract base for all DT layers."""

    layer_name: str = "unnamed"

    def __init__(self, config: "TwinConfig", event_bus: "EventBus"):
        self.config = config
        self.bus = event_bus
        self.log = logging.getLogger(
            f"dt_forge.{self.layer_name}.{config.asset_id}"
        )
        self._running = False

    async def initialise(self) -> None:
        """One-time setup (DB seeds, graph build, model load). Override if needed."""

    @abstractmethod
    async def start(self) -> None:
        """Begin the layer's continuous operation."""
        ...

    async def stop(self) -> None:
        """Graceful shutdown. Override to release resources."""
        self._running = False

    @property
    def is_running(self) -> bool:
        return self._running


class AbstractDigitalTwin(ABC):
    """
    A complete digital twin instance.

    Subclass this to create an asset-specific twin.
    At minimum, provide the config and override build_layers().
    """

    def __init__(self, config: "TwinConfig"):
        from dt_forge.core.events import EventBus

        self.config = config
        self.bus = EventBus()
        self.layers: dict[str, LayerBase] = {}
        self.connectors: list = []       # populated by ConnectorRegistry
        self.log = logging.getLogger(
            f"dt_forge.twin.{config.asset_id}"
        )

    @abstractmethod
    def build_layers(self) -> dict[str, LayerBase]:
        """
        Return a dict of layer_name → LayerBase instances.

        ``initialise()`` runs every layer's ``initialise()`` in insertion order
        (so data layer prerequisites complete before, e.g., the services layer
        registers Ditto things). ``start()`` then launches every layer
        concurrently — the loops are long-running and have no in-order
        startup requirements. ``stop()`` runs in reverse insertion order.
        """
        ...

    async def initialise(self) -> None:
        self.layers = self.build_layers()
        for name, layer in self.layers.items():
            self.log.info("Initialising layer: %s", name)
            await layer.initialise()

    async def start(self) -> None:
        # All layer loops are independent and run concurrently. Insertion order
        # determines initialise() and stop() sequencing, not start() order.
        tasks = [
            asyncio.create_task(layer.start(), name=name)
            for name, layer in self.layers.items()
        ]
        await asyncio.gather(*tasks)

    async def stop(self) -> None:
        # Reverse insertion order: autonomous → intelligent → reactive → data.
        # This ensures no layer is shut down while a higher layer still depends on it.
        for layer in reversed(list(self.layers.values())):
            await layer.stop()

    async def run(self) -> None:
        """Convenience: initialise then start."""
        await self.initialise()
        await self.start()
