"""FastAPI app factory for the digital twin service layer."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.services.base import ServiceRegistry

log = logging.getLogger(__name__)


def create_app(
    config: "TwinConfig",
    service_registry: "ServiceRegistry",
    include_chat: bool = True,
) -> FastAPI:
    """Build and return the FastAPI application for this twin."""
    from dt_forge.services.api.routes import build_router
    from dt_forge.services.api.streaming import build_chat_router

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        log.info("FastAPI server started for twin '%s'", config.asset_id)
        yield
        log.info("FastAPI server stopping for twin '%s'", config.asset_id)

    app = FastAPI(
        title=f"Digital Twin: {config.asset_name}",
        description=f"DT-Forge REST API for asset '{config.asset_id}'",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(build_router(config, service_registry))

    if include_chat:
        app.include_router(
            build_chat_router(config, service_registry), prefix="/api"
        )

    return app
