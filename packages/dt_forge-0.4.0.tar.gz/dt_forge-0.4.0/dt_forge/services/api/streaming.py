"""SSE streaming endpoint for agent interactions."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import AsyncGenerator, TYPE_CHECKING

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.services.base import ServiceRegistry

log = logging.getLogger(__name__)


class ChatRequest(BaseModel):
    message: str
    stream: bool = True


def build_chat_router(
    config: "TwinConfig", service_registry: "ServiceRegistry"
) -> APIRouter:
    router = APIRouter()

    @router.post("/chat")
    async def chat(req: ChatRequest):
        try:
            mas_svc = service_registry.get("intelligent")
            agent = getattr(mas_svc, "agents", [None])[0]
            if agent is None:
                return {"response": "No agent available"}

            if req.stream:
                async def _generate() -> AsyncGenerator[str, None]:
                    try:
                        if hasattr(agent, "ask_stream"):
                            async for chunk in agent.ask_stream(req.message):
                                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
                        else:
                            response = await agent.ask(req.message)
                            yield f"data: {json.dumps({'chunk': response})}\n\n"
                        yield "data: [DONE]\n\n"
                    except Exception as e:
                        yield f"data: {json.dumps({'error': str(e)})}\n\n"

                return StreamingResponse(
                    _generate(), media_type="text/event-stream"
                )
            else:
                response = await agent.ask(req.message)
                return {"response": response}

        except KeyError:
            return {"response": "Intelligent layer not available"}
        except Exception as e:
            log.error("Chat endpoint error: %s", e)
            return {"response": f"Error: {e}"}

    return router
