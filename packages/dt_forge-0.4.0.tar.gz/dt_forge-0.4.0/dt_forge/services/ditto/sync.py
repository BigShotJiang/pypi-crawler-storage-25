"""DittoSyncService: keeps the Eclipse Ditto Thing synchronised with live state."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from dt_forge.core.base import LayerBase

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.core.events import EventBus
    from dt_forge.data.storage.base import TimeSeriesStore, CacheStore, DocumentStore
    from dt_forge.services.ditto.client import DittoClient

log = logging.getLogger(__name__)


class DittoSyncService(LayerBase):
    """Keeps the Eclipse Ditto Thing synchronised with live twin state."""

    layer_name = "service_ditto"
    service_name = "ditto_sync"
    dependencies: list[str] = []

    def __init__(
        self,
        config: "TwinConfig",
        event_bus: "EventBus",
        *,
        ts_store: "TimeSeriesStore",
        cache: "CacheStore",
        ditto_client: "DittoClient",
        doc_store: "DocumentStore | None" = None,
        sync_interval: int = 5,
    ):
        super().__init__(config, event_bus)
        self.ts = ts_store
        self.cache = cache
        self.ditto = ditto_client
        self.doc = doc_store
        self.sync_interval = sync_interval

    async def initialise(self) -> None:
        await self.ditto.wait_for_ready()
        try:
            await self.ditto.create_policy()
        except Exception as e:
            self.log.error(
                "Ditto create_policy failed (continuing — sync loop may fail later): %s", e,
            )
        try:
            await self.ditto.create_thing(self.config)
        except Exception as e:
            self.log.error(
                "Ditto create_thing failed (continuing — sync loop may fail later): %s", e,
            )

    async def sync_once(self) -> None:
        telemetry = {
            f: (self.ts.get_latest(f) or 0.0) for f in self.config.field_names
        }
        await self.ditto.update_feature("telemetry", telemetry)

        health = self.cache.get_latest_cached("health_score") or 100.0
        state = self.cache.get_state()
        await self.ditto.update_feature(
            "health",
            {"health_score": health, "operational_state": state},
        )

    async def start(self) -> None:
        self._running = True
        self.log.info("DittoSyncService started (interval=%ds)", self.sync_interval)
        while self._running:
            try:
                await self.sync_once()
            except Exception as e:
                self.log.error("Ditto sync error: %s", e)
            await asyncio.sleep(self.sync_interval)
