"""CompositeService: a service composed of other services."""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)


class CompositeService:
    """
    A service that wraps and coordinates multiple child services.

    Starts children in dependency order, stops in reverse.
    """

    service_name: str = "composite"
    dependencies: list[str] = []

    def __init__(self, name: str, services: list):
        self.service_name = name
        self._services = services

    async def start(self) -> None:
        log.info("CompositeService '%s' starting %d services", self.service_name, len(self._services))
        tasks = [asyncio.create_task(svc.start()) for svc in self._services]
        await asyncio.gather(*tasks)

    async def stop(self) -> None:
        for svc in reversed(self._services):
            try:
                await svc.stop()
            except Exception as e:
                log.error("Error stopping service in composite: %s", e)
