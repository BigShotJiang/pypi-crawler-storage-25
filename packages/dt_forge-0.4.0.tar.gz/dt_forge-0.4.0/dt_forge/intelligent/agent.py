"""DiagnosticAgent: LangChain agent wired to the twin's live data stores."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, AsyncIterator

if TYPE_CHECKING:
    from dt_forge.core.config import TwinConfig
    from dt_forge.data.storage.base import TimeSeriesStore, DocumentStore
    from dt_forge.intelligent.knowledge_graph import KnowledgeGraph
    from dt_forge.services.ditto.client import DittoClient

log = logging.getLogger(__name__)


class DiagnosticAgent:
    """LangChain agent with tools wired to the twin's data stores."""

    agent_name: str = "diagnostic"
    domain: str = "general"
    priority: int = 10

    def __init__(
        self,
        config: "TwinConfig",
        *,
        llm,
        ditto_client: "DittoClient",
        ts_store: "TimeSeriesStore",
        doc_store: "DocumentStore",
        knowledge_graph: "KnowledgeGraph",
    ):
        from langchain_classic.agents import AgentExecutor, create_tool_calling_agent
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

        from dt_forge.intelligent.tools import (
            make_twin_state_tool,
            make_sensor_tool,
            make_diagnose_tool,
            make_event_log_tool,
            make_components_tool,
        )

        self.config = config
        self.kg = knowledge_graph
        self._ts_store = ts_store
        self._doc_store = doc_store

        tools = [
            make_twin_state_tool(ditto_client),
            make_sensor_tool(ts_store, config),
            make_diagnose_tool(knowledge_graph, ts_store, config),
            make_event_log_tool(doc_store),
            make_components_tool(knowledge_graph),
        ]
        # Subclasses register domain-specific tools via _build_extra_tools().
        # Any instance state the tool closures need must be set on `self` in
        # the subclass __init__ BEFORE calling super().__init__(...).
        tools.extend(self._build_extra_tools())

        prompt = ChatPromptTemplate.from_messages([
            ("system", self._system_prompt()),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ])

        agent = create_tool_calling_agent(llm, tools, prompt)
        self.executor = AgentExecutor(
            agent=agent, tools=tools, verbose=False,
            return_intermediate_steps=True,
        )
        self._last_intermediate_steps: list = []

    def _system_prompt(self) -> str:
        return (
            f"You are the diagnostic AI agent for the digital twin of "
            f"'{self.config.asset_name}' (type: {self.config.asset_type}, "
            f"ID: {self.config.asset_id}). "
            "You have access to tools that let you read sensor data, "
            "diagnose faults using the knowledge graph, retrieve recent events, "
            "and get the full twin state. "
            "Be concise and actionable. Always cite specific sensor values "
            "and failure modes when diagnosing issues."
        )

    async def ask(self, question: str) -> str:
        try:
            result = await self.executor.ainvoke({"input": question})
            self._last_intermediate_steps = result.get("intermediate_steps", [])
            return result.get("output", "No response generated.")
        except Exception as e:
            log.error("DiagnosticAgent.ask error: %s", e)
            self._last_intermediate_steps = []
            return f"Agent error: {e}"

    def get_last_tool_calls(self) -> list[dict]:
        """Return last run's tool calls as serialisable dicts."""
        result = []
        for action, observation in self._last_intermediate_steps:
            result.append({
                "tool":   getattr(action, "tool", str(action)),
                "input":  getattr(action, "tool_input", {}),
                "output": str(observation)[:600],  # truncate to avoid bloating MongoDB documents and LLM context
            })
        return result

    def _build_extra_tools(self) -> list:
        """Return additional LangChain tools for this agent.

        Override in subclasses to inject domain-specific tools *before* the
        AgentExecutor is compiled. Set any instance state the tool closures
        need on ``self`` in the subclass ``__init__`` *before* calling
        ``super().__init__(...)`` — this method is invoked during the parent's
        constructor.
        """
        return []

    async def observe(self) -> dict:
        return {"question": "Is there anything anomalous?", "anomaly_detected": False}

    async def reason(self, observations: dict) -> dict:
        answer = await self.ask(
            "Summarise the current health of the asset and highlight any issues."
        )
        return {"summary": answer, "agent": self.agent_name}

    async def act(self, findings: dict) -> None:
        log.info("[%s] Findings: %s", self.agent_name, findings.get("summary", ""))


def build_llm(config: "TwinConfig"):
    """Build an LLM from the twin's LLM config."""
    cfg = config.llm
    if cfg.provider == "openai":
        from langchain_openai import ChatOpenAI
        kwargs = {"model": cfg.model, "temperature": cfg.temperature}
        if cfg.api_key:
            kwargs["api_key"] = cfg.api_key
        return ChatOpenAI(**kwargs)
    elif cfg.provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        kwargs = {"model": cfg.model, "temperature": cfg.temperature}
        if cfg.api_key:
            kwargs["api_key"] = cfg.api_key
        return ChatAnthropic(**kwargs)
    elif cfg.provider == "ollama":
        from langchain_ollama import ChatOllama
        url = cfg.base_url or "http://localhost:11434"
        return ChatOllama(model=cfg.model, base_url=url)
    else:
        raise ValueError(f"Unsupported LLM provider: {cfg.provider}")
