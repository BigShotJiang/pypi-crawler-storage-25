# Release Readiness Validation

<p className="craik-meta"><span>4 min read</span><span>For maintainers</span><span>Updated 2026-05-22</span></p>

<div className="craik-lead">

**What you'll find here**

The repository-owned readiness record for Craik releases. The current
pre-release gate is `0.12.0`; historical sign-offs remain below for
audit continuity.

</div>

## v0.12.0 Goal Workflow

<div className="craik-keypoint">

**Structural CI guard generalization starts the v0.12.0 release train.**

`0.12.0` begins with G0 before functional migration,
internationalization, and compatibility work. G0 strengthens the
release-readiness writer-coverage guard with qualified call
resolution, explicit dynamic-dispatch allowlisting, and a complementary
dead-code scan.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>G0 structural CI guard generalization</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/819">#819</a> · release-readiness writer coverage resolves calls through qualified function paths and import maps, registry-dispatched callables use a capped documented allowlist, and <code>scripts/check_dead_code.py</code> runs vulture at confidence 80 as a complementary dead-code gate</dd></div>

</div>

### v0.12.0 Validation Commands

Run the structural gate from a clean checkout before starting
functional v0.12.0 implementation goals:

```bash
uv run python scripts/check_release_readiness.py
uv run python scripts/check_dead_code.py
uv run pytest tests/test_release_readiness_guards.py tests/test_dead_code_check.py -v
```

## v0.11.0 Goal Workflow

<div className="craik-keypoint">

**Product surfaces and channel operations are ready for release prep.**

`0.11.0` moves Craik beyond command-only operation with a terminal UI,
authenticated dashboard, desktop companion, service-managed gateway,
real channel adapters, approval UX, diagnostics/update workflows, and
multimodal companion contracts. Each goal lands through its own issue
and PR before release prep; all v0.11.0 implementation goal issues are
closed.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Release signing-key asset rules</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/787">#787</a> · signed annotated tag rules, GitHub Release public signing-key asset, and fingerprint verification gate</dd></div>
<div><dt>Release signing-key and URL-scheme remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/812">#812</a> · local signing-key exports are ignored, public signing keys remain GitHub Release assets, and future <code>craik://</code> handlers are documented as review-only with no direct mutating actions</dd></div>
<div><dt>Terminal UI</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/788">#788</a> · <code>craik --tui</code>, <code>craik tui</code>, shared slash commands, multiline composer, status/model/session/approval/artifact/gateway/skill panels, autocomplete metadata, redacted approval modal fixture, tests, and guide docs</dd></div>
<div><dt>Authenticated local dashboard</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/789">#789</a> · <code>craik dashboard</code>, local-only default bind, token or active operator-session auth, status/provider/session/run/handoff/receipt/approval/gateway/skill/model pages, shared slash-command action route, route tests, and security docs</dd></div>
<div><dt>Dashboard action remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/808">#808</a> · dashboard action POSTs enforce local Origin checks for browser requests and reject mutating slash-command families from the generic read-only action endpoint</dd></div>
<div><dt>Dashboard session binding remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/809">#809</a> · tokenless dashboard mode requires <code>X-Craik-Operator-Session</code> to match the active operator session token, and preview output warns about the required header</dd></div>
<div><dt>Follow-up dashboard, service, and Discord remediation</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/821">#821</a> · dashboard session binding uses a random per-session token instead of JWT <code>jti</code>, systemd gateway units tolerate executable paths with spaces, and Discord webhook diagnostics distinguish verifier unavailability from invalid signatures</dd></div>
<div><dt>Desktop companion MVP</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/790">#790</a> · <code>craik desktop</code> status, menu, action, approval notification, and update-check surfaces for local dashboard launch, gateway command actions, provider/auth health, doctor, and redacted notification deep links</dd></div>
<div><dt>Gateway service lifecycle</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/791">#791</a> · <code>craik gateway install</code>, <code>uninstall</code>, <code>status</code>, <code>logs</code>, <code>doctor</code>, <code>stop</code>, and <code>restart</code> with launchd/systemd generation, Windows plan, stale pid recovery, and log discovery</dd></div>
<div><dt>Gateway service executable remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/810">#810</a> · generated launchd, systemd, and Windows service-plan output uses the absolute <code>craik</code> executable path resolved at install time</dd></div>
<div><dt>Real channel adapters</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/792">#792</a> · WebChat, Telegram, Discord, and Slack adapter contracts, setup and doctor commands, secret-reference plans, inbound normalization, pairing/allowlist policy gates, redacted outbound delivery receipts, and channel security docs</dd></div>
<div><dt>Channel persistence remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/807">#807</a> · channel setup writes adapter contracts, pairings, allowlists, and policy envelopes through production CLI paths; webhook ingress receipts use shared persistence; readiness checks writer reachability through wrappers</dd></div>
<div><dt>Channel webhook signature remediation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/811">#811</a> · webhook ingress verifies WebChat/Craik HMAC, Slack signatures and replay timestamps, Telegram secret-token headers, and fail-closed Discord native signature support warnings</dd></div>
<div><dt>Approval UX</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/793">#793</a> · <code>/approvals</code>, <code>craik approvals list</code>, <code>show</code>, <code>approve</code>, and <code>deny</code>, dashboard queue payloads, TUI approval modal/counts, desktop notifications, decision receipts, retry-path linkage, and lifecycle tests</dd></div>
<div><dt>Doctor, fix, and update</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/794">#794</a> · <code>craik doctor</code>, <code>craik doctor --fix</code>, <code>craik update --check</code>, expanded operator/provider/model/gateway/channel/security diagnostics, explicit dry-run fix plans, unsafe fix confirmation, JSON output, and fixture tests</dd></div>
<div><dt>Multimodal and companion contracts</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/795">#795</a> · voice posture, speech-to-text and text-to-speech adapter contracts, multimodal artifact references, mobile/desktop/visual companion decisions, work-graph visual bridge, accessibility requirements, transcript/media metadata redaction, and fixture tests</dd></div>
<div><dt>Release prep</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/823">#823</a> · version declarations, changelog promotion, roadmap/readiness documentation, package-lock metadata, and release validation gate before maintainer signing</dd></div>

</div>

## v0.11.0 Release Readiness

<div className="craik-keypoint">

**Status: ready for maintainer signing after release-prep PR lands.**

The v0.11.0 milestone contains the TUI, authenticated dashboard,
desktop companion, gateway service lifecycle, real channel adapters,
approval UX, doctor/update workflow, multimodal companion contracts,
and all follow-up remediation. Tagging remains gated on the final
release-prep validation and maintainer-managed GPG signing.

</div>

<div className="craik-fields">

<div>
<dt>Gate</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Evidence</dd>
</div>

<div><dt>Implementation</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Operator-facing TUI, dashboard, desktop, gateway, channel, approval, diagnostic, update, and multimodal surfaces landed through issue-linked PRs and follow-up remediation.</dd></div>
<div><dt>Security</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Dashboard session binding uses a random per-session token, dashboard actions reject mutating slash commands and enforce local Origin checks, gateway service units use absolute executable paths, channel signatures verify platform-specific boundaries, and release key asset rules are documented.</dd></div>
<div><dt>Structural guards</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Release readiness resolves writer reachability through qualified import-aware call graphs and the complementary dead-code check runs vulture at confidence 80.</dd></div>
<div><dt>Known blockers</dt><dt><span className="craik-fields__type">none known</span></dt><dd>No open v0.11.0 milestone issue remains. Tagging is gated on the release-prep PR, signed annotated tag creation, GitHub Release publication, and signing-key asset verification.</dd></div>

</div>

### v0.11.0 Validation Commands

Run the full release gate from a clean checkout before tagging
`0.11.0`:

```bash
uv run python scripts/check_version_consistency.py
uv run python scripts/check_release_version.py
uv run ruff check
uv run mypy
uv run python scripts/generate_cli_reference.py --check
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_dead_code.py
uv run python scripts/check_changed_file_strictness.py
uv run python scripts/check_max_file_lines.py
uv run python scripts/quickstart_smoke.py
uv run pytest
```

## v0.10.0 Goal Workflow

<div className="craik-keypoint">

**Agent shell and setup UX gate is ready for release prep.**

`0.10.0` turns the root CLI into a usable agent shell, adds progressive
setup guidance before auth is configured, introduces browser-assisted
provider login, and exposes model, session, profile, usage, and
learning-loop controls through operator-facing commands. The
implementation goal landed through a green PR tied to the v0.10.0
milestone before release prep begins.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Agent shell and setup UX</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/779">#779</a> · root shell launch, <code>craik chat</code>, slash commands, readiness states, provider login, model/session/profile controls, and learning-loop command surfaces</dd></div>
<div><dt>Release prep</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/781">#781</a> · version declarations, changelog, roadmap, release-readiness docs, generated references, and validation gate</dd></div>

</div>

## v0.10.0 Release Readiness

<div className="craik-keypoint">

**Status: ready for release checks after release-prep PR lands.**

The v0.10.0 milestone contains the agent shell, progressive setup
states, browser-assisted provider login, secure credential-storage
posture reporting, model/session/profile UX, usage summaries, and
learning-loop controls. Release prep owns the final version bump,
changelog promotion, signed tag, package publication, docs
publication, and post-release verification.

</div>

<div className="craik-fields">

<div>
<dt>Gate</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Evidence</dd>
</div>

<div><dt>Implementation</dt><dt><span className="craik-fields__type">ready</span></dt><dd>The root <code>craik</code> shell can launch before auth, one-shot chat works through <code>craik chat</code> and <code>craik --one-shot</code>, readiness states explain setup gaps, and slash commands route users toward setup, auth, provider, model, session, approval, and doctor actions.</dd></div>
<div><dt>Auth and credentials</dt><dt><span className="craik-fields__type">ready</span></dt><dd><code>craik auth login</code> provides browser-assisted provider setup for hosted providers and guided fallback for local models while keeping output redacted and surfacing credential-storage posture.</dd></div>
<div><dt>Runtime UX</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Model aliases, fallbacks, status, probes, session list/show/resume/rename/export/prune/delete, local profiles, usage summaries, and insight summaries are exposed through command surfaces and generated CLI reference docs.</dd></div>
<div><dt>Learning controls</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Skill telemetry, proposals, eval, promote, rollback, and history commands preserve the policy boundary: agents can propose improvement paths, but promotion remains an operator-governed action.</dd></div>
<div><dt>Tests</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Focused v0.10 shell, readiness, slash-command, provider-login, model/session/profile, learning-loop, release-readiness guard, and runtime-layout tests landed with the implementation PR. Full local validation passed with loopback access enabled for HTTP-server tests.</dd></div>
<div><dt>Docs</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Agent shell, model/session/profile UX, readiness states, slash commands, authentication, quickstart, learning-loop, roadmap, generated CLI reference, and release-readiness docs are updated.</dd></div>
<div><dt>Known blockers</dt><dt><span className="craik-fields__type">none known</span></dt><dd>No unresolved v0.10.0 implementation blocker remains. Tagging is gated on release-prep validation and maintainer signing.</dd></div>

</div>

### v0.10.0 Validation Commands

Run the full release gate from a clean checkout before tagging
`0.10.0`:

```bash
uv run python scripts/check_version_consistency.py
uv run ruff check
uv run mypy
uv run python scripts/generate_cli_reference.py --check
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_dead_code.py
uv run python scripts/check_changed_file_strictness.py
uv run python scripts/check_max_file_lines.py
uv run python scripts/quickstart_smoke.py
uv run pytest
```

### Release Signing-Key Asset Gate

Every release must be cut from a signed annotated tag and must publish
the ASCII-armored public release signing key on the matching GitHub
Release as `craik-release-signing-key.asc`. This asset is the public
key operators can import or inspect; it is not a detached tag
signature. The embedded Git tag signature remains the integrity check
for the release commit.

```bash
git tag -v vX.Y.Z
git ls-remote --tags origin vX.Y.Z
gpg --show-keys --with-fingerprint craik-release-signing-key.asc
gh release view vX.Y.Z --repo eidetic-labs/craik --json assets --jq '.assets[].name'
```

Release prep is not complete until the fingerprint shown for
`craik-release-signing-key.asc` matches the key reported by
`git tag -v vX.Y.Z`.

## v0.9.0 Goal Workflow

<div className="craik-keypoint">

**Persistent agent runtime gate is ready for release prep.**

`0.9.0` adds provider-backed persistent sessions, guided provider
setup, Gemini and local model routes, provider certification, explicit
failure recovery, and a deterministic persistent-agent launch demo.
All implementation goals landed through green PRs tied to the v0.9.0
milestone before release prep begins.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Provider setup</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/737">#737</a> · guided setup for OpenAI, Anthropic, Gemini, and local models</dd></div>
<div><dt>Gemini runtime</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/738">#738</a> · Gemini generateContent adapter, docs, and runner matrix coverage</dd></div>
<div><dt>Local model presets</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/740">#740</a> · Ollama, LM Studio, vLLM, and generic OpenAI-compatible presets</dd></div>
<div><dt>Persistent prompt loop</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/741">#741</a> · persistent session prompt execution with events, receipts, and handoff links</dd></div>
<div><dt>Provider certification matrix</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/742">#742</a> · generated matrix for hosted, local, and fixture provider routes</dd></div>
<div><dt>Failure recovery</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/743">#743</a> · stale pid/endpoint, auth, provider, sandbox, reconnect, and resume states</dd></div>
<div><dt>Persistent launch demo</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/744">#744</a> · deterministic launch, prompt, receipts, handoff, and status demo</dd></div>
<div><dt>Security and sandbox boundaries</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/745">#745</a> · persistent-agent state boundaries, redacted inspection surfaces, environment receipt links, and denied side-effect receipts</dd></div>
<div><dt>Readiness docs reconciliation</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/756">#756</a> · roadmap and release-readiness docs reflect the closed v0.9.0 goal workflow</dd></div>
<div><dt>CLI auth coverage remediation</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/759">#759</a> · release-readiness auth guard now scans every <code>cli_*.py</code> module and stateful CLI commands require the canonical operator session check, with explicit bootstrap/demo/CI policy-test exemptions</dd></div>

</div>

## v0.9.0 Release Readiness

<div className="craik-keypoint">

**Status: ready for pre-release checks after docs reconciliation lands.**

The v0.9.0 milestone now contains provider setup, Gemini runtime
support, local model presets, provider-backed persistent sessions,
provider certification, explicit failure recovery, a launch demo,
persistent-agent security boundaries, MCP routing decisions, sandbox
backend tracking, browser/tool boundary tracking, sandbox policy
validation, and environment capability receipts. Release prep remains
responsible for the version bump, final changelog section, signed tag,
publish, and post-publish verification.

</div>

<div className="craik-fields">

<div>
<dt>Gate</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Evidence</dd>
</div>

<div><dt>Implementation</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Persistent sessions can launch, prompt providers, persist events, carry receipt and handoff links, recover from stale process, auth, provider, and sandbox states, and route through OpenAI, Anthropic, Gemini, local, and fixture providers.</dd></div>
<div><dt>Tests</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Focused coverage exists for provider setup, Gemini transport, local presets, persistent prompt execution, provider certification, recovery, launch demo behavior, environment receipt linkage, and denied side-effect receipts.</dd></div>
<div><dt>Docs</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Persistent-agent runtime, authentication, local model setup, provider routing, provider certification, persistent-agent security, execution-environment security, and environment receipt docs are updated.</dd></div>
<div><dt>Security</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Session inspection uses redacted views, persistent agents retain references instead of secrets, environment receipts link provider and sandbox boundaries to sessions, and missing side-effect grants produce denial receipts.</dd></div>
<div><dt>Milestone provenance</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Backfill issues <a href="https://github.com/eidetic-labs/craik/issues/765">#765</a> through <a href="https://github.com/eidetic-labs/craik/issues/773">#773</a> link MCP, sandbox, browser boundary, sandbox policy, and environment receipt tiles to implementation evidence.</dd></div>
<div><dt>Known blockers</dt><dt><span className="craik-fields__type">none known</span></dt><dd>No unresolved v0.9.0 implementation blocker remains. Tagging is gated on release-prep validation.</dd></div>

</div>

### v0.9.0 Validation Commands

Run the full release gate from a clean checkout before promoting
`0.9.0` into release prep:

```bash
uv run python scripts/check_version_consistency.py
uv run ruff check
uv run mypy
uv run python scripts/generate_cli_reference.py --check
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_changed_file_strictness.py
uv run pytest tests/test_provider_cli.py tests/test_provider_runtime.py tests/test_local_model_presets.py tests/test_agent_sessions.py tests/test_agent_session_integrity.py tests/test_provider_certification.py tests/test_cli_agents.py tests/test_cli_operator_auth.py tests/test_release_readiness_guards.py tests/test_demos.py tests/test_environment_receipts.py tests/test_sandbox_policy_boundaries.py -q
uv run pytest
```

## v0.8.0 Goal Workflow

<div className="craik-keypoint">

**Operator integrations and always-on gateway gate.**

`0.8.0` ships a foreground gateway daemon, setup/diagnostics/update
operator commands, channel contracts, messaging fixture ingress,
identity pairing, allowlists, channel policy envelopes, webhook
validation, scheduled automations, and gateway receipts. Each
remediation issue shipped implementation, tests, docs, validation, a
green PR, merge, issue closure, and branch pruning before release prep.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Runnable gateway daemon and runtime state</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/713">#713</a> · <code>craik gateway start</code>, pid-file lock, <code>/health</code>, and persisted lifecycle transitions</dd></div>
<div><dt>Gateway/channel contract persistence</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/723">#723</a> · typed local-store helpers for adapter contracts, pairings, allowlists, schedules, automations, policies, and gateway receipts</dd></div>
<div><dt>Webhook hardening</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/715">#715</a> · body cap, JSON depth cap, timestamp freshness, normalized signature headers, and persistent replay detection</dd></div>
<div><dt>Operator auth for diagnostics/reconfiguration</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/719">#719</a> · active operator session required before reading local diagnostics or reconfiguring an existing setup</dd></div>
<div><dt>Schedule throttle</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/718">#718</a> · cron-like schedules reject runs more frequent than every five minutes</dd></div>
<div><dt>Pairing token expiry</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/721">#721</a> · channel identity pairings require and enforce expiry</dd></div>
<div><dt>Public-bind TLS warning and override</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/722">#722</a> · public gateway binds require policy plus explicit insecure-public acknowledgement</dd></div>
<div><dt>Release-readiness structural guards</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/720">#720</a> · writer and operator-auth guard coverage widened for v0.8.0 surfaces</dd></div>
<div><dt>End-to-end gateway pipeline test</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/717">#717</a> · integrated daemon, webhook, channel policy, receipt, schedule, and store coverage</dd></div>
<div><dt>Readiness, security, and changelog reconciliation</dt><dt><span className="craik-fields__type">ready after this PR</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/714">#714</a> · docs now reflect shipped behavior and residual limitations</dd></div>
<div><dt>Release prep</dt><dt><span className="craik-fields__type">pending</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/716">#716</a> · version bump, final changelog section, tag, publish, and verification remain the final gate</dd></div>

</div>

## v0.8.0 Release Readiness

<div className="craik-keypoint">

**Status: ready for release prep after docs reconciliation lands.**

All implementation remediation goals are closed. The shipped daemon is
a foreground local service with health checks and persisted lifecycle
state; hosted public operation, production dispatch loops, and broad
third-party channel adapters remain future surfaces.

</div>

<div className="craik-fields">

<div>
<dt>Gate</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Evidence</dd>
</div>

<div><dt>Implementation</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Gateway setup, diagnostics, foreground daemon, webhook validation, messaging fixture ingress, identity pairing, allowlists, policy envelopes, schedules, automations, and gateway receipts are implemented and persisted.</dd></div>
<div><dt>Tests</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Focused unit coverage exists for each surface plus <code>tests/test_v0_8_0_gateway_pipeline_e2e.py</code> for the integrated flow.</dd></div>
<div><dt>Security</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Webhook payload limits, timestamp/replay checks, operator session gates, pairing expiry, schedule throttling, and public-bind policy/TLS acknowledgement are covered.</dd></div>
<div><dt>Known blockers</dt><dt><span className="craik-fields__type">none known</span></dt><dd>No unresolved v0.8.0 implementation blocker remains. Tagging is gated on #716 release-prep validation.</dd></div>

</div>

### v0.8.0 Validation Commands

Run the full release gate from a clean checkout before promoting
`0.8.0` into release prep:

```bash
uv run python scripts/check_version_consistency.py
uv run ruff check
uv run mypy
uv run python scripts/generate_cli_reference.py --check
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_changed_file_strictness.py
uv run pytest tests/test_v0_8_0_gateway_pipeline_e2e.py tests/test_gateway.py tests/test_webhook_ingress.py tests/test_channel_identity.py tests/test_channel_allowlist.py tests/test_channel_policy.py tests/test_scheduled_automations.py tests/test_schedules.py tests/test_gateway_receipts.py tests/test_store.py -q
uv run pytest
```

## v0.7.0 Goal Workflow

<div className="craik-keypoint">

**Operator experience gate.**

`0.7.0` ships a read-only operator surface for inspecting project
state without reading raw logs. Each goal issue must ship
implementation, tests, docs, validation, a green PR, merge, issue
closure, and branch pruning before the next goal begins.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Dashboard / TUI decision</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/685">#685</a> · CLI-first <code>craik operator overview</code> · read-only snapshot and formatter contract</dd></div>
<div><dt>Work graph explorer</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/686">#686</a> · <code>craik operator work-graph</code> · terminal view and JSON export</dd></div>
<div><dt>Handoff viewer</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/687">#687</a> · <code>craik operator handoff</code> · durable summary, risks, receipts, and next steps</dd></div>
<div><dt>Receipt viewer</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/688">#688</a> · <code>craik operator receipt</code> · capability and plugin receipt inspection</dd></div>
<div><dt>Contradiction inbox</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/689">#689</a> · <code>craik operator contradictions</code> · contradiction and operator-attention queue</dd></div>
<div><dt>Evidence and assumption views</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/690">#690</a> · <code>craik operator evidence</code> · evidence and assumptions kept separate</dd></div>
<div><dt>Delegation queue</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/691">#691</a> · <code>craik operator delegations</code> · human delegation inspection</dd></div>
<div><dt>Budget / quota view</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/692">#692</a> · <code>craik operator budget</code> · explicit missing budget and quota data</dd></div>
<div><dt>Instruction distillation view</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/693">#693</a> · <code>craik operator instructions</code> · sources, snapshots, provenance, proposals, and reviews</dd></div>
<div><dt>Quality gate view</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/694">#694</a> · <code>craik operator quality</code> · handoff, evidence, critic, and red-team signals</dd></div>
<div><dt>Memory impact preview</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/695">#695</a> · <code>craik operator memory-impact</code> · previewed durable-memory effects</dd></div>
<div><dt>Known traps view</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/696">#696</a> · <code>craik operator traps</code> · known traps and negative knowledge</dd></div>
<div><dt>Run delta view</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/697">#697</a> · <code>craik operator run-delta</code> · recovery and continuity deltas</dd></div>
<div><dt>Release readiness and docs assessment</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/698">#698</a> · final 0.7.0 readiness record, changelog, and docs assessment</dd></div>

</div>

## v0.7.0 Release Readiness

<div className="craik-keypoint">

**Status: ready for release prep.**

All v0.7.0 operator-experience goals have shipped implementation,
tests, docs, validation, a green PR, merge, issue closure, and branch
pruning. No known release blockers remain as of 2026-05-21.

</div>

<div className="craik-fields">

<div>
<dt>Gate</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Evidence</dd>
</div>

<div><dt>Implementation</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Read-only <code>craik operator</code> commands cover overview, work graph, handoffs, receipts, contradictions, evidence, delegations, budget, instructions, quality, memory impact, traps, and run deltas.</dd></div>
<div><dt>Tests</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Focused CLI and formatter coverage exists for each operator surface view, with full-suite validation required before release prep.</dd></div>
<div><dt>Docs</dt><dt><span className="craik-fields__type">ready</span></dt><dd>Reference docs, generated CLI docs, roadmap, changelog, and this readiness record are updated to current docs quality.</dd></div>
<div><dt>Known blockers</dt><dt><span className="craik-fields__type">none known</span></dt><dd>No unresolved v0.7.0 blocker is recorded after the goal workflow assessment.</dd></div>

</div>

### v0.7.0 Validation Commands

Run the full release gate from a clean checkout before promoting
`0.7.0` into release prep:

```bash
uv run python scripts/check_version_consistency.py
uv run ruff check
uv run mypy src
uv run python scripts/generate_cli_reference.py --check
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run python scripts/check_release_readiness.py
find src -name '*.py' -print0 | xargs -0 uv run python scripts/check_max_file_lines.py
uv run pytest tests/test_cli_operator_auth.py tests/test_cli_operator_scoping.py tests/test_operator_view_sanitization.py tests/test_release_readiness_guards.py -q
uv run pytest
```

## v0.6.0 Goal Workflow

<div className="craik-keypoint">

**Skills, plugins, and ecosystem foundations gate.**

`0.6.0` ships reusable skill contracts and governed plugin ecosystem
contracts without weakening Craik's no-ambient-authority runtime
model. Each goal issue shipped implementation, tests, docs, validation,
a green PR, merge, issue closure, and branch pruning before the next
goal began.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Skill package format</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/659">#659</a> · <code>craik.skill_package</code> · semantic package versions and no runtime authority</dd></div>
<div><dt>Project-scoped and global skills</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/660">#660</a> · <code>craik.skill_registry</code> · active entry and precedence invariants</dd></div>
<div><dt>Context contracts for skills</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/661">#661</a> · <code>craik.skill_invocation_context</code> · package context requirements and redacted invocation records</dd></div>
<div><dt>Plugin descriptor format</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/662">#662</a> · <code>craik.plugin_descriptor</code> · trust boundary, capabilities, docs, security notes, and compatibility</dd></div>
<div><dt>Probationary plugins</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/663">#663</a> · <code>craik.plugin_probation</code> · evidence-backed criteria and decisions before durable trust</dd></div>
<div><dt>Plugin capability grants</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/664">#664</a> · <code>craik.plugin_capability_grant</code> · explicit operations, scoped targets, approvals, expiry, and authorization helper</dd></div>
<div><dt>Plugin receipts</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/665">#665</a> · <code>craik.plugin_receipt</code> · redacted descriptor, grant, probation, evidence, and handoff links</dd></div>
<div><dt>Adapter packages</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/666">#666</a> · <code>craik.adapter_package</code> · semantic versions, runner modes, Python/platform compatibility, docs, and provenance</dd></div>
<div><dt>Reference integrations</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/667">#667</a> · <code>craik.reference_integration</code> · safe reproducible skill, plugin, and adapter examples</dd></div>
<div><dt>Community skills docs</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/668">#668</a> · package, context, registry, review, and security guidance</dd></div>
<div><dt>Community plugins docs</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/669">#669</a> · descriptors, probation, grants, receipts, adapters, references, and security guidance</dd></div>
<div><dt>Release readiness and docs assessment</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/670">#670</a> · this release record, roadmap, changelog, and release automation hygiene</dd></div>

</div>

## v0.6.0 Release Readiness

<div className="craik-keypoint">

**Ready for release prep.**

The v0.6.0 skills, plugins, and ecosystem foundations surface is
implemented in typed contracts, local-store persistence, validation
helpers, operator-visible receipt formatting, reference documentation,
and community guides. Release prep still owns the version bump,
generated docs lockfile, release heading promotion, full release
validation, tag creation, PyPI publish, docs deployment, and GitHub
Release verification.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Validation</dd>
</div>

<div>
<dt>Runtime contracts</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>skill_package</code> · <code>skill_registry</code> · <code>skill_invocation_context</code> · <code>plugin_descriptor</code> · <code>plugin_probation</code> · <code>plugin_capability_grant</code> · <code>plugin_receipt</code> · <code>adapter_package</code> · <code>reference_integration</code>.</dd>
</div>

<div>
<dt>Docs</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Reference pages and guides cover skill packages, skill registries, skill contexts, plugin descriptors, plugin probation, plugin grants, plugin receipts, adapter packages, reference integrations, community skills, and community plugins. Sidebars and index navigation include the community guides.</dd>
</div>

<div>
<dt>Validation commands</dt>
<dt><span className="craik-fields__type">passed</span></dt>
<dd>Focused slices passed across goal PRs. Final readiness validation passed <code>uv run python scripts/check_version_consistency.py</code>, <code>uv run ruff check</code>, <code>uv run mypy src</code>, <code>uv run python scripts/check_doc_links.py</code>, <code>uv run python scripts/check_public_docs_hygiene.py</code>, <code>uv run python scripts/check_release_readiness.py</code>, and full <code>uv run pytest</code> with loopback access enabled for local HTTP-server tests.</dd>
</div>

<div>
<dt>Security notes</dt>
<dt><span className="craik-fields__type">reviewed</span></dt>
<dd>Skills remain instruction packages with no runtime authority. Plugin descriptors declare needs but grant nothing. Probation blocks durable trust until evidence-backed criteria and decisions pass. Plugin grants require explicit operations, scoped targets, expiry, and approval metadata. Denied, expired, and approval-required grants do not authorize execution. Plugin receipts must be redacted and cannot mark result metadata as unredacted.</dd>
</div>

<div>
<dt>Release automation hygiene</dt>
<dt><span className="craik-fields__type">addressed</span></dt>
<dd>The publish workflow changelog extractor now accepts release headings with an em dash, en dash, or ASCII hyphen between the version and date, avoiding the v0.5.0 GitHub Release note extraction failure.</dd>
</div>

<div>
<dt>Release blocker state</dt>
<dt><span className="craik-fields__type">none known</span></dt>
<dd>The v0.6.0 milestone has no open implementation goals other than this readiness issue. No critical release blocker is known before release-prep validation.</dd>
</div>

<div>
<dt>Release actions</dt>
<dt><span className="craik-fields__type">pending release prep</span></dt>
<dd>Release prep must bump version declarations to <code>0.6.0</code>, regenerate generated docs artifacts if required, promote the changelog heading to <code>0.6.0 — 2026-05-21</code>, run the full release validation suite, create the signed tag, publish to PyPI, verify the docs site, and verify GitHub Release creation.</dd>
</div>

</div>

## v0.5.0 Goal Workflow

<div className="craik-keypoint">

**Quality, continuity, and recovery gate.**

`0.5.0` starts with one goal issue for each roadmap capability plus a
release-readiness issue. Each issue must ship implementation, tests,
docs, and requirement validation before the milestone closes.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Goal issue</dd>
</div>

<div><dt>Recovery mode</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/636">#636</a> · <code>craik run recover</code> · <code>craik.recovery_session</code></dd></div>
<div><dt>Runtime critic</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/637">#637</a> · <code>craik.runtime_critic_finding</code></dd></div>
<div><dt>Red team mode</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/638">#638</a> · <code>craik.red_team_finding</code></dd></div>
<div><dt>Evidence coverage score</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/639">#639</a> · <code>craik.evidence_coverage_score</code></dd></div>
<div><dt>Handoff quality score</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/640">#640</a> · <code>craik.handoff_quality_score</code></dd></div>
<div><dt>Context debt tracking</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/641">#641</a> · <code>craik.context_debt_record</code></dd></div>
<div><dt>Evidence expiration rules</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/642">#642</a> · attestation and freshness expiry checks</dd></div>
<div><dt>Tool result attestation</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/643">#643</a> · <code>craik.tool_result_attestation</code></dd></div>
<div><dt>Knowledge freshness probes</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/644">#644</a> · <code>craik.knowledge_freshness_probe</code></dd></div>
<div><dt>Scratchpad with expiry</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/645">#645</a> · <code>craik.scratchpad_record</code></dd></div>
<div><dt>Known traps</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/646">#646</a> · <code>craik.known_trap</code></dd></div>
<div><dt>Negative knowledge</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/647">#647</a> · <code>craik.negative_knowledge</code></dd></div>
<div><dt>First-class unknowns</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/648">#648</a> · <code>craik.unknown_record</code></dd></div>
<div><dt>Release readiness and docs assessment</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/649">#649</a> · this release record</dd></div>
<div><dt>Structured context requests</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/650">#650</a> · <code>craik.context_request</code></dd></div>
<div><dt>Agent exit discipline</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/651">#651</a> · <code>craik.exit_discipline_check</code></dd></div>
<div><dt>What changed since last time deltas</dt><dt><span className="craik-fields__type">ready</span></dt><dd><a href="https://github.com/eidetic-labs/craik/issues/652">#652</a> · <code>craik.run_delta</code></dd></div>

</div>

## v0.5.0 Release Readiness

<div className="craik-keypoint">

**Remediated and release-ready.**

The v0.5.0 quality, continuity, and recovery surface is implemented in
typed contracts, local-store persistence, runtime helpers, operator
views, capture CLI surfaces, recovery/delta operator gates, and
reference documentation. The post-readiness remediation closed the gap
between contract definitions and production capture paths. Release prep
updates the version declarations, changelog heading, generated docs
lockfile, package verification, tag checks, PyPI publish, docs deployment
verification, and GitHub release verification.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Validation</dd>
</div>

<div>
<dt>Runtime contracts</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>recovery_session</code> · <code>run_delta</code> · <code>runtime_critic_finding</code> · <code>red_team_finding</code> · <code>handoff_quality_score</code> · <code>evidence_coverage_score</code> · <code>context_debt_record</code> · <code>tool_result_attestation</code> · <code>knowledge_freshness_probe</code> · <code>scratchpad_record</code> · <code>known_trap</code> · <code>negative_knowledge</code> · <code>unknown_record</code> · <code>context_request</code> · <code>exit_discipline_check</code>.</dd>
</div>

<div>
<dt>Operator surfaces</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Quality gate, known traps, negative knowledge, run delta, recovery, scratchpad, unknowns, context requests, context debt, critic findings, red-team findings, and exit-discipline states are formatted or captured without granting policy authority. Knowledge-resolution views distinguish unresolved records, verified receipt links, and missing or tampered receipt links.</dd>
</div>

<div>
<dt>CLI exercise path</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>craik knowledge</code> captures scratchpad, unknown, context-request, known-trap, and negative-knowledge records, and resolves unknown, context-request, and context-debt records with operator receipt linkage; <code>craik review</code> captures critic and red-team findings; <code>craik run recover</code> and <code>craik run delta</code> expose recovery and changed-since-last-time summaries from local durable state behind an active operator session.</dd>
</div>

<div>
<dt>Validation commands</dt>
<dt><span className="craik-fields__type">passed</span></dt>
<dd><code>uv run pytest tests/test_v0_5_0_pipeline_e2e.py</code> plus the focused readiness slice: <code>uv run pytest tests/test_recovery.py tests/test_critics.py tests/test_quality_scores.py tests/test_context_debt.py tests/test_freshness.py tests/test_known_traps.py tests/test_scratchpad.py tests/test_exit_discipline.py tests/test_operator_views.py tests/test_store.py</code>.</dd>
</div>

<div>
<dt>Security notes</dt>
<dt><span className="craik-fields__type">reviewed</span></dt>
<dd>Critic and red-team findings are non-authoritative by default; freshness and evidence-expiry checks warn or block silent reliance but do not prove truth; scratchpad content expires instead of becoming project memory; negative knowledge requires evidence and scope; resolved unknowns, fulfilled context requests, and resolved context debt require operator receipt links; tool attestations and recovery sessions carry local HMAC integrity metadata; existing recovery/delta state requires an active operator session.</dd>
</div>

<div>
<dt>Release blocker state</dt>
<dt><span className="craik-fields__type">none known</span></dt>
<dd>No critical v0.5.0 implementation blocker is known after remediation of the capture-layer readiness findings. Tagging is gated on the release-prep PR checks and version/tag validation.</dd>
</div>

<div>
<dt>Release actions</dt>
<dt><span className="craik-fields__type">pending tag</span></dt>
<dd><code>0.5.0</code> version declarations, release notes, and docs lockfile are prepared in the release-prep branch. The release tag, PyPI package, docs deployment, and GitHub Release are verified after the release-prep PR lands.</dd>
</div>

</div>

## v0.4.0 Release Readiness

<div className="craik-keypoint">

**Runtime instruction distillation gate.**

`0.4.0` lands the declared-instruction pipeline that turns project
instruction files into typed, provenance-linked, reviewable
constraints. Sources are registered explicitly, snapshots drive stale
invalidation, extracted statements carry line/range provenance,
categories and contradiction reports keep review queues explainable,
approval receipts are required before a constraint becomes governing,
and active constraints flow into case files and compiled prompts.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Release notes</dd>
</div>

<div>
<dt>Package version</dt>
<dt><span className="craik-fields__type">shipped</span></dt>
<dd><code>pyproject.toml</code>, <code>src/craik/__init__.py</code>, <code>docs/package.json</code>, and <code>docs/package-lock.json</code> declare <code>0.4.0</code>.</dd>
</div>

<div>
<dt>Instruction source registry</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Projects can register declared instruction sources with typed source metadata, canonical paths, owner identity, path confinement, registry receipts, and project-scoped active source lists.</dd>
</div>

<div>
<dt>Source ingestion</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Markdown, Cursor rules, Codex, Copilot, and policy document sources parse into candidate statements without treating arbitrary repository Markdown as authority.</dd>
</div>

<div>
<dt>Source snapshots and stale invalidation</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Registered sources are hashed with normalized newlines and tracked as <code>new</code>, <code>unchanged</code>, <code>changed</code>, or <code>missing</code>; changed, missing, newly observed, or omitted sources defer derived proposals.</dd>
</div>

<div>
<dt>Line/range provenance</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Extracted statements persist deterministic provenance records with source ID, snapshot ID, path, line and column ranges, summaries, and excerpt hashes.</dd>
</div>

<div>
<dt>Instruction categorization</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Provenanced statements become reviewable proposals with deterministic category traceability across policy, security, boundary, command, instruction, handoff, memory, preference, and stale-risk classes.</dd>
</div>

<div>
<dt>Inter-source contradictions</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Normalized policy, boundary, command, instruction, and security-rule proposals open contradiction reports for cross-source conflicts while skipping same-source and stale deferred items.</dd>
</div>

<div>
<dt>Approval flow and receipts</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Proposals become governing only through explicit operator approval receipts; re-approval is idempotent, rejections are receipted, stale or contradicted approvals require override rationale, and active consumers exclude constraints whose approval receipt HMAC is missing or invalid.</dd>
</div>

<div>
<dt>Case-file and prompt-compilation integration</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Case files include deterministic governing distillation evidence, and compiled prompts render exactly one <code>Active instruction constraints</code> section with ordered items, provenance annotations, empty-state behavior, and stale-exclusion warnings.</dd>
</div>

<div>
<dt>Distillation CLI</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>craik instructions register</code>, <code>ingest</code>, <code>list</code>, <code>approve</code>, <code>reject</code>, and <code>show</code> expose source registration, pipeline execution, proposal review, approval decisions, rejection decisions, and provenance-aware item inspection through the active operator session.</dd>
</div>

<div>
<dt>Reference documentation</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>docs/reference/instruction-sources.md</code>, <code>docs/reference/distilled-instructions.md</code>, <code>docs/reference/instruction-approval.md</code>, and <code>docs/guides/managing-instructions.md</code> document the shipped v0.4.0 operator surface and link through the sidebars.</dd>
</div>

<div>
<dt>Release actions</dt>
<dt><span className="craik-fields__type">complete</span></dt>
<dd><code>v0.4.0</code> is tagged, published to PyPI, and represented by the GitHub Release. The GitHub milestone is closed with zero open issues.</dd>
</div>

</div>

### v0.4.0 Verification Commands

Run these before release prep and again before tagging:

```bash
uv run python scripts/check_version_consistency.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_doc_links.py
uv run python scripts/check_public_docs_hygiene.py
uv run pytest tests/test_instruction_sources.py tests/test_instruction_ingestion.py tests/test_instruction_provenance.py tests/test_instruction_distillation.py tests/test_instruction_invalidation.py tests/test_instruction_contradictions.py tests/test_instruction_promotion.py tests/test_instruction_runtime_context.py tests/test_instruction_workflow_docs.py tests/test_instruction_pipeline_e2e.py tests/test_case_files.py tests/test_prompts.py tests/test_contracts.py -q
```

### v0.4.0 Security Notes

The v0.4.0 trust boundary is also documented in
[SECURITY.md](https://github.com/eidetic-labs/craik/blob/main/SECURITY.md).

- Instruction sources must be registered explicitly and remain confined
  to the registered project root before ingestion.
- Raw source files and distilled proposals are evidence, not authority;
  only governing constraints backed by approval receipts enter case
  files and compiled prompts.
- Stale or contradicted approvals require an explicit override and
  rationale, and review receipts record whether stale or contradiction
  guards were bypassed.
- Approval receipt HMACs, backed by an owner-only local secret, are
  verified before governing constraints are rendered into case files,
  onboarding context, handoffs, or compiled prompts.
- Release workflows pin GitHub Actions to immutable SHAs and attest package
  provenance before PyPI publish.
- Stale governing items are excluded from compiled prompt context and
  surfaced as distillation warnings instead of silent authority.
- Contradiction detection opens reviewable reports for cross-source
  policy, boundary, command, instruction, and security-rule conflicts.

## v0.3.0 Release Readiness

<div className="craik-keypoint">

**Multi-agent review and coordination gate.**

`0.3.0` lands the governed multi-agent surface: authenticated mailbox
messages, intent-lock coordination across simultaneous runs, structured
debate with adjudication, cross-agent review, human delegation pause and
resume, scope-change decisions, and live work-graph coordination. The same
release tightens the security boundary: identity-isolated handoff
consumption, role-allowlist dispatch, operator-bound delegation resolution,
and authenticated mailbox sends.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Release notes</dd>
</div>

<div>
<dt>Package version</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>pyproject.toml</code>, <code>src/craik/__init__.py</code>, <code>docs/package.json</code>, and <code>docs/package-lock.json</code> declare <code>0.3.0</code>.</dd>
</div>

<div>
<dt>Multi-agent messaging</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Receipt-backed <code>craik agent-message</code> and local-store helpers send and receive authenticated typed messages linked to tasks, runs, handoffs, and roles. Senders are authenticated against the run's role state, message bodies are bounded, and same-subject repeats get unique IDs instead of overwriting.</dd>
</div>

<div>
<dt>Intent-lock coordination</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Overlapping active scopes on the same project block before new loop phases or tool dispatch and persist a denial receipt, so simultaneous runs cannot race the same intent lock.</dd>
</div>

<div>
<dt>Structured debate</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>The debate runtime helper creates role-linked debate turns, summarizes agreement or disagreement, and resolves by adjudication receipt or human-delegation receipt.</dd>
</div>

<div>
<dt>Cross-agent review</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>The review protocol helper creates receipted review requests for worker results, handoffs, or debate summaries and completes them with typed findings linked back to the reviewed artifacts.</dd>
</div>

<div>
<dt>Human delegation</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Runs can be interrupted with receipted delegation requests, resolved or cancelled by CLI, and resumed from the recorded response. Resolution requires resolver operator identity and rejects attempts to resume a paused run opened by another operator.</dd>
</div>

<div>
<dt>Scope-change protocol</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Discovered work outside the current intent lock interrupts the run, records a scope-change request receipt, and exposes <code>craik scope-change decide</code> for explicit expand, sibling-task, handoff, or denial decisions before continuing.</dd>
</div>

<div>
<dt>Live work graph</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Mailbox messages, reviews, debates, delegations, and scope-change artifacts persist work-graph events that can be queried as active coordination state.</dd>
</div>

<div>
<dt>Identity isolation</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Consuming a handoff records an explicit consumer credential and operator assignment, rejects producer identity reuse by default, and requires an explicit continuation flag plus rationale when reuse is intentional.</dd>
</div>

<div>
<dt>Handoff consumption</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>craik task resume --from-handoff</code> creates a follow-up task, case file, and pending run that record source handoff provenance while requiring an explicit consumer credential and operator identity.</dd>
</div>

<div>
<dt>Role-based dispatch</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>craik run execute --role</code> records a policy-checked specialist role assignment, dispatch receipt, and run-level role metadata. Role dispatch requires explicit role allowlists and gates runner overrides behind the <code>role.runner.override</code> policy capability.</dd>
</div>

<div>
<dt>Release actions</dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Create immutable tag <code>v0.3.0</code>, run the protected publish workflow, then verify PyPI and docs after publication.</dd>
</div>

</div>

### v0.3.0 Verification Commands

Run these before tagging:

```bash
uv run python scripts/check_version_consistency.py
uv run python scripts/check_release_version.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_release_tag.py --tag v0.3.0 --expected-version 0.3.0
uv run pytest tests/test_agent_mailbox.py tests/test_intent_lock_coordination.py tests/test_role_dispatch.py tests/test_scope_changes.py tests/integration/test_multi_agent_v030_flow.py -q
```

### v0.3.0 Security Notes

- Delegation resolution requires resolver operator identity and rejects
  attempts to resume a paused run opened by another operator.
- Mailbox sends authenticate `from_agent` against the sender run's role
  state before storing the message or receipt.
- Role dispatch requires explicit role allowlists and gates runner
  overrides behind the `role.runner.override` policy capability.
- Mailbox message bodies are bounded and repeated same-subject messages
  receive unique IDs instead of overwriting the latest message.
- Handoff consumption records an explicit consumer credential and
  operator assignment, rejects producer identity reuse by default, and
  requires an explicit continuation flag plus rationale when reuse is
  intentional.

## v0.2.0 Release Readiness

<div className="craik-keypoint">

**Durable execution continuity gate.**

`0.2.0` hardens the provider-backed loop into durable execution: resumable
phase boundaries, wall-clock and provider-token budgets, sandboxed shell tool
dispatch, run recovery commands, tool-result attestations, and local-store
migrations.

</div>

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Release notes</dd>
</div>

<div>
<dt>Package version</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>pyproject.toml</code>, <code>src/craik/__init__.py</code>, <code>docs/package.json</code>, and <code>docs/package-lock.json</code> declare <code>0.2.0</code>.</dd>
</div>

<div>
<dt>Resumable execution</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Interrupted runs reopen from persisted phase outputs, stable idempotency keys prevent duplicate phase output capture, and <code>craik run resume</code> continues unfinished provider-backed runs.</dd>
</div>

<div>
<dt>Budgets</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Per-run wall-clock budgets, provider token ledgers, and pre-dispatch time checks interrupt before additional provider calls or side effects when exhausted.</dd>
</div>

<div>
<dt>Sandboxed tool execution</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Configured shell tool calls execute through the local-process sandbox backend, propagate cancellation to in-flight commands, and record hashed tool-result attestations linked to side-effect receipts.</dd>
</div>

<div>
<dt>Recovery and observability</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd><code>craik run show</code>, <code>craik run cancel</code>, <code>craik run delta</code>, and persisted exit-discipline checks expose continuity state and handoff readiness.</dd>
</div>

<div>
<dt>Storage migrations</dt>
<dt><span className="craik-fields__type">ready</span></dt>
<dd>Local-store migrations now run through a registered, forward-only framework with compatibility fixtures, ordering tests, and migration failure guidance.</dd>
</div>

<div>
<dt>Release actions</dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Create immutable tag <code>v0.2.0</code>, run the protected publish workflow, then verify PyPI and docs after publication.</dd>
</div>

</div>

### v0.2.0 Verification Commands

Run these before tagging:

```bash
uv run python scripts/check_version_consistency.py
uv run python scripts/check_release_version.py
uv run python scripts/check_release_readiness.py
uv run python scripts/check_release_tag.py --tag v0.2.0 --expected-version 0.2.0
uv run pytest tests/test_loop.py tests/test_local_process_backend.py tests/test_loop_tool_dispatch.py tests/test_store.py tests/test_cli.py tests/test_handoffs.py tests/test_provider_runner.py -q
```

### v0.2.0 Security Notes

- Shell execution remains policy-gated and only registered command references
  are routed to the local-process sandbox backend.
- The local-process backend avoids shell expansion and propagates cancellation
  to in-flight subprocesses.
- Budget checks happen before provider calls and immediately before tool
  dispatch, preventing exhausted runs from producing new side effects.
- Tool-result attestations hash redacted replay payloads and link each
  dispatched result to its side-effect receipt.

## v0.1.0 Release Readiness

<div className="craik-keypoint">

**In-repo green.**

All in-repo readiness gates are passing. The remaining work is the
maintainer-driven `v0.1.0` tag and the protected publication workflow.

</div>

## Snapshot

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Notes</dd>
</div>

<div>
<dt>Code health</dt>
<dt><span className="craik-fields__type">green</span></dt>
<dd>CI, CodeQL, version checks, file-size budget, build, doctor all pass.</dd>
</div>

<div>
<dt>Test coverage</dt>
<dt><span className="craik-fields__type">green</span></dt>
<dd>HTTP transport, credentials, OIDC, governance, redaction, handoffs.</dd>
</div>

<div>
<dt>Security hygiene</dt>
<dt><span className="craik-fields__type">green</span></dt>
<dd>No leaked secret patterns. Operator and credential stores are file-locked, atomic, and owner-only.</dd>
</div>

<div>
<dt>Documentation</dt>
<dt><span className="craik-fields__type">green</span></dt>
<dd>Roadmap, README, changelog, limitations, mvp docs, Docusaurus build.</dd>
</div>

<div>
<dt>Operational state</dt>
<dt><span className="craik-fields__type">green</span></dt>
<dd>Milestones present. 22 issues closed for v0.1.0. No blockers open. Dependabot clear.</dd>
</div>

<div>
<dt>External release actions</dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Tag and publish remain maintainer actions.</dd>
</div>

</div>

## Code health

<div className="craik-grid">

<div><h4>CI on main</h4><p>Latest <code>ci.yml</code> run on <code>main</code> completed <code>success</code>: <a href="https://github.com/eidetic-labs/craik/actions/runs/26010629626">run 26010629626</a>.</p></div>

<div><h4>CodeQL</h4><p>Latest <code>codeql.yml</code> run on <code>main</code> completed <code>success</code>: <a href="https://github.com/eidetic-labs/craik/actions/runs/26010629612">run 26010629612</a>.</p></div>

<div><h4>Code scanning</h4><p>Zero open alerts via <code>gh api repos/eidetic-labs/craik/code-scanning/alerts</code>.</p></div>

<div><h4>Version consistency</h4><p><code>uv run python scripts/check_release_version.py</code>.</p></div>

<div><h4>File-size budget</h4><p><code>find src -name "*.py" -print0 | xargs -0 uv run python scripts/check_max_file_lines.py</code>.</p></div>

<div><h4><code>craik --version</code></h4><p>Prints <code>0.1.0</code> via <code>uv run craik --version</code>.</p></div>

<div><h4><code>craik doctor</code></h4><p>Runs to completion against a fresh <code>CRAIK_HOME</code>. An entirely empty home correctly reports missing local state.</p></div>

<div><h4>Package artifacts</h4><p><code>uv build</code> produced <code>dist/craik-0.1.0.tar.gz</code> and <code>dist/craik-0.1.0-py3-none-any.whl</code>.</p></div>

</div>

## Test coverage

<div className="craik-fields">

<div>
<dt>Area</dt>
<dt><span className="craik-fields__type">Coverage</span></dt>
<dd>Test files</dd>
</div>

<div>
<dt>HTTP transport</dt>
<dt><span className="craik-fields__type">integration</span></dt>
<dd><code>tests/integration/test_http_transport_round_trip.py</code></dd>
</div>

<div>
<dt>Credential sources</dt>
<dt><span className="craik-fields__type">unit</span></dt>
<dd>API keys · local-CLI OAuth · CLI bridge · secret references · Stigmem references · marker / no-credential behavior · credential pools. Files: <code>test_auth_api_key_source.py</code>, <code>test_auth_local_cli_oauth.py</code>, <code>test_auth_cli_bridge.py</code>, <code>test_auth_secret_ref.py</code>, <code>test_auth_profiles.py</code>, <code>test_auth_credential_pool.py</code>, <code>test_provider_runtime.py</code>.</dd>
</div>

<div>
<dt>OIDC &amp; workload identity</dt>
<dt><span className="craik-fields__type">unit</span></dt>
<dd>Operator auth · session storage · GitHub Actions · Kubernetes · generic file/env tokens · RFC 8693 exchange. Files: <code>test_oidc_operator.py</code>, <code>test_operator_session_store.py</code>, <code>test_workload_identity.py</code>, <code>test_oidc_exchange_secret_manager.py</code>.</dd>
</div>

<div>
<dt>JWT hardening</dt>
<dt><span className="craik-fields__type">unit</span></dt>
<dd>Rejects <code>alg=none</code>, unknown <code>kid</code>, tampered payloads, asymmetric/symmetric confusion (<code>test_oidc_operator.py</code>).</dd>
</div>

<div>
<dt>Governance behavior</dt>
<dt><span className="craik-fields__type">unit</span></dt>
<dd>Credential-scoped receipts · operator-scoped receipts · policy-bound credentials · policy-bound operators · approval gates · expiry-as-risk · per-credential redaction · handoff identity isolation. Files: <code>test_provider_runtime.py</code>, <code>test_policy.py</code>, <code>test_loop.py</code>, <code>test_case_files.py</code>, <code>test_redaction.py</code>, <code>test_handoffs.py</code>.</dd>
</div>

</div>

**Focused readiness set:** ran the combined readiness subset with
`uv run pytest tests/integration/test_http_transport_round_trip.py
tests/test_auth_api_key_source.py tests/test_auth_local_cli_oauth.py
tests/test_auth_cli_bridge.py tests/test_auth_secret_ref.py
tests/test_auth_profiles.py tests/test_auth_credential_pool.py
tests/test_oidc_operator.py tests/test_operator_session_store.py
tests/test_workload_identity.py
tests/test_oidc_exchange_secret_manager.py
tests/test_provider_runtime.py tests/test_policy.py
tests/test_case_files.py tests/test_handoffs.py -q` — all passed.

## Security hygiene

<div className="craik-grid">

<div><h4>Secret-pattern grep</h4><p>No raw secret patterns in tests or scripts: <code>grep -rE "sk-[a-zA-Z0-9]{`{20,}`}|xoxb-|ghp_|ANTHROPIC.{`{0,5}`}=.{`{20,}`}" tests/ scripts/</code>.</p></div>

<div><h4>Operator session file</h4><p>Owner-only <code>0o600</code> writes in <code>src/craik/runtime/auth/operator/store.py</code>.</p></div>

<div><h4>Auth profiles store</h4><p><code>auth-profiles.json</code> writes are file-locked and atomic via <code>fcntl.flock</code> + tempfile + <code>os.replace</code> in <code>src/craik/runtime/auth/store.py</code>.</p></div>

<div><h4>Credential pool store</h4><p>Pool writes are file-locked and atomic in <code>src/craik/runtime/auth/pool.py</code>.</p></div>

<div><h4>Resolver errors</h4><p>Reference-level error wording such as <code>secret reference could not be resolved</code> — never raw values.</p></div>

</div>

## Documentation

<div className="craik-grid">

<div><h4>Roadmap gates</h4><p>Exactly 12 release gates <code>v0.1.0</code>–<code>v0.12.0</code>, no gaps.</p></div>

<div><h4>Roadmap auth scope</h4><p><code>docs/roadmap.md</code> states <code>v0.1.0</code> includes OIDC, pluggable credentials, operator + credential identity on receipts, policy-bound auth, approval-gated first use, expiry risk, per-credential redaction, handoff identity bookkeeping.</p></div>

<div><h4>Changelog</h4><p><code>CHANGELOG.md</code> <code>## 0.1.0 - 2026-05-17</code> narrates Phase A and Phase B.</p></div>

<div><h4>README</h4><p>"What Works Today" names OIDC and typed credential profiles.</p></div>

<div><h4>Auth on-ramp</h4><p><code>docs/guides/authentication.md</code> exists and is linked from <code>docs/index.md</code>. <code>docs/guides/quickstart.md</code> covers it.</p></div>

<div><h4>Limitations honesty</h4><p><code>docs/limitations.md</code> no longer treats shipped auth capabilities as future work.</p></div>

<div><h4>MVP docs</h4><p><code>docs/mvp.md</code> and <code>docs/mvp-roadmap.md</code> reflect the expanded <code>v0.1.0</code> scope including OIDC and credential profiles.</p></div>

<div><h4>Docs build</h4><p><code>npm run build</code> from <code>docs/</code> succeeds.</p></div>

</div>

## Operational state

<div className="craik-grid">

<div><h4>Milestones</h4><p><code>v0.1.0</code>–<code>v0.12.0</code> exist with titles matching the roadmap.</p></div>

<div><h4>v0.1.0 milestone</h4><p>22 closed issues · 0 open issues.</p></div>

<div><h4>Blockers</h4><p>No open PRs or open issues currently blocking the release.</p></div>

<div><h4>Dependabot</h4><p>Alert #1 fixed.</p></div>

<div><h4>Tag posture</h4><p>Tag <code>v0.1.0</code> does not exist locally. Tagging is a maintainer release action and should happen only after this report is accepted.</p></div>

</div>

## External release actions

<div className="craik-fields">

<div>
<dt>Action</dt>
<dt><span className="craik-fields__type">Status</span></dt>
<dd>Notes</dd>
</div>

<div>
<dt>Create and push tag <code>v0.1.0</code></dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Maintainer action.</dd>
</div>

<div>
<dt>Run protected package publication workflow</dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Maintainer action.</dd>
</div>

<div>
<dt>Optional live-provider smoke tests</dt>
<dt><span className="craik-fields__type">pending</span></dt>
<dd>Require real provider credentials and an operator IdP. Fixture, cassette, and in-process socket paths are already validated in-repo.</dd>
</div>

</div>

## What's next

<div className="craik-next">

<a href="../mvp-roadmap/">
<strong>Read</strong>
<span>MVP roadmap</span>
<small>The work this readiness report validates.</small>
</a>

<a href="../limitations/">
<strong>Read</strong>
<span>Limitations</span>
<small>Honest scope after v0.1.0 ships.</small>
</a>

<a href="../security/release-process/">
<strong>Read</strong>
<span>Security release process</span>
<small>The release-day procedure for security-sensitive work.</small>
</a>

</div>
