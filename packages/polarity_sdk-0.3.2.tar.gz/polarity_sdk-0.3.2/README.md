# polarity-sdk

Python SDK for [Polarity](https://plr.sh) — agent evaluation, sandboxed execution, and LLM observability.

This is the **canonical install name**. It's a thin alias that pulls in
`polarity-keystone`, which ships the actual code. Both names refer to
the same package; use whichever feels right.

## Install

```bash
pip install polarity-sdk
```

## Quickstart

```python
import polarity as plr
from openai import OpenAI

client = plr.wrap(OpenAI())

@plr.traced("workflow")
def run(prompt: str):
    return client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )

run("hello world")
```

Traces appear at https://app.polarity.so.

## Configuration

| Env var | Purpose |
| --- | --- |
| `POLARITY_API_KEY` | Required. Get one at https://app.polarity.so |
| `POLARITY_BASE_URL` | Optional. Defaults to `https://api.plr.sh` |

Legacy `KEYSTONE_*` env vars continue to work indefinitely.

## More

Full docs at https://docs.polarity.so.
