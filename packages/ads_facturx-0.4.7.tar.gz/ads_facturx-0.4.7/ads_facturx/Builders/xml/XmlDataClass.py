from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, List


@dataclass
class AddressXML:
    adr_l1: str
    adr_l2: Optional[str]
    adr_l3: Optional[str]
    postcode: str
    city: str
    country_id: str

@dataclass
class PartyXML:
    name: str
    address: AddressXML
    vat: Optional[str]
    siren: Optional[str] = None

@dataclass
class InvoiceXML:
    name: str
    order: str
    date: str
    expiration: str
    type_code: str
    date_format: str
    currency: str
    reference: Optional[str]
    salesperson: Optional[str]
    description: Optional[List[str]]
    line_total_amount: str
    tax_total_amount : str
    grand_total_amount: str

@dataclass
class InvoiceLineXML:

    product_code: Optional[str]
    type_line: str
    line_id: str
    product_description: str
    product_type: Optional[str]
    quantity: str
    unit_price: str
    unit_code: Optional[str]
    unit_code_xml: Optional[str]
    tva_code: str
    tva_type: Optional[str]
    line_amount: str

@dataclass
class InvoiceSummaryXML:
    rate: str
    base_amount: str
    vat_amount: str
    vat_code : str
    exempt:Optional[str] = None

@dataclass
class DataXML:
    seller: PartyXML
    buyer: PartyXML
    invoice: InvoiceXML
    invoice_lines: List[InvoiceLineXML]
    invoice_summary: List[InvoiceSummaryXML]



