import xml.etree.ElementTree as ET
from xml.dom import minidom
from ads_facturx.Builders.xml.XmlDataClass import AddressXML, PartyXML, InvoiceXML, InvoiceLineXML, InvoiceSummaryXML, DataXML
import os

class FacturxXmlSerializer:

    def __init__(self):

        self.ns_rsm = "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
        self.ns_ram = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
        self.ns_udt = "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"

        self.root = None
        self.agreement = None
        self.sctt = None
        self.deliverysettlement = None
        self.tradesettlement = None

    def _build_root(self):
        return  ET.Element("rsm:CrossIndustryInvoice", {
        "xmlns:rsm":  self.ns_rsm,
        "xmlns:ram":  self.ns_ram,
        "xmlns:udt":  self.ns_udt
    })

    def _build_context(self, root):
        ctx = ET.SubElement(root, "rsm:ExchangedDocumentContext")
        guideline = ET.SubElement(ctx, "ram:GuidelineSpecifiedDocumentContextParameter")
        ET.SubElement(guideline, "ram:ID").text = "urn:cen.eu:en16931:2017"

    def _build_agreement(self,sctt):
        return  ET.SubElement(sctt, "ram:ApplicableHeaderTradeAgreement")

    def _build_sctt(self, root):
        return ET.SubElement(root, "rsm:SupplyChainTradeTransaction")

    def _build_doc(self,root,data: InvoiceXML):
        doc = ET.SubElement(root, "rsm:ExchangedDocument")
        ET.SubElement(doc, "ram:ID").text = data.order
        ET.SubElement(doc, "ram:TypeCode").text = data.type_code

        issue = ET.SubElement(doc, "ram:IssueDateTime")
        ET.SubElement(issue, "udt:DateTimeString", {"format": data.date_format }).text = data.date

        note = ET.SubElement(doc, "ram:IncludedNote")
        ET.SubElement(note, "ram:Content").text = data.description
        ET.SubElement(note, "ram:SubjectCode").text = "AAI" #TODO data.note_content

    def _build_item(self, sctt, lines: list[InvoiceLineXML]):

        for line in lines:

            item = ET.SubElement(sctt, "ram:IncludedSupplyChainTradeLineItem")
            doc_line = ET.SubElement(item, "ram:AssociatedDocumentLineDocument")
            ET.SubElement(doc_line, "ram:LineID").text = line.line_id
            product = ET.SubElement(item, "ram:SpecifiedTradeProduct")
            ET.SubElement(product, "ram:Name").text = line.product_description
            agreement = ET.SubElement(item, "ram:SpecifiedLineTradeAgreement")
            price = ET.SubElement(agreement, "ram:NetPriceProductTradePrice")
            ET.SubElement(price, "ram:ChargeAmount").text = line.unit_price
            delivery = ET.SubElement(item, "ram:SpecifiedLineTradeDelivery")
            ET.SubElement(delivery,"ram:BilledQuantity",{"unitCode":line.unit_code_xml}).text = line.quantity
            linesettlement = ET.SubElement(item, "ram:SpecifiedLineTradeSettlement")
            tax = ET.SubElement(linesettlement, "ram:ApplicableTradeTax")
            ET.SubElement(tax, "ram:TypeCode").text = "VAT"
            ET.SubElement(tax, "ram:CategoryCode").text = line.tva_type
            ET.SubElement(tax, "ram:RateApplicablePercent").text = line.tva_code
            summation = ET.SubElement(linesettlement,"ram:SpecifiedTradeSettlementLineMonetarySummation" )
            ET.SubElement(summation,"ram:LineTotalAmount").text = line.line_amount


    def _build_sellertradeparty(self, agreement, party :PartyXML):

        p = ET.SubElement(agreement, "ram:SellerTradeParty")

        ET.SubElement(p, "ram:Name").text = party.name

        addr = ET.SubElement(p, "ram:PostalTradeAddress")

        ET.SubElement(addr, "ram:PostcodeCode").text = party.address.postcode
        ET.SubElement(addr, "ram:LineOne").text = party.address.adr_l1

        if party.address.adr_l2:
            ET.SubElement(addr, "ram:LineTwo").text = party.address.adr_l2

        if party.address.adr_l3:
            ET.SubElement(addr, "ram:LineThree").text = party.address.adr_l3

        ET.SubElement(addr, "ram:CityName").text = party.address.city
        ET.SubElement(addr, "ram:CountryID").text = party.address.country_id

        if party.vat:
            tax = ET.SubElement(p, "ram:SpecifiedTaxRegistration")
            ET.SubElement(tax, "ram:ID", {"schemeID": "VA"}).text = party.vat

    def _build_buyertradeparty(self, agreement, party: PartyXML):

        p = ET.SubElement(agreement, "ram:BuyerTradeParty")

        ET.SubElement(p, "ram:Name").text = party.name

        addr = ET.SubElement(p, "ram:PostalTradeAddress")

        ET.SubElement(addr, "ram:PostcodeCode").text = party.address.postcode
        ET.SubElement(addr, "ram:LineOne").text = party.address.adr_l1

        if party.address.adr_l2:
            ET.SubElement(addr, "ram:LineTwo").text = party.address.adr_l2

        if party.address.adr_l3:
            ET.SubElement(addr, "ram:LineThree").text = party.address.adr_l3

        ET.SubElement(addr, "ram:CityName").text = party.address.city
        ET.SubElement(addr, "ram:CountryID").text = party.address.country_id

        if party.vat:
            tax = ET.SubElement(p, "ram:SpecifiedTaxRegistration")
            ET.SubElement(tax, "ram:ID", {"schemeID": "VA"}).text = party.vat

    def _build_parties(self,agreement,seller: PartyXML,buyer: PartyXML):

        self._build_sellertradeparty(agreement,seller)
        self._build_buyertradeparty(agreement,buyer)

    def _build_Deliverysettlement(self,sctt,data: InvoiceXML):

        deliverysettlement = ET.SubElement(sctt, "ram:ApplicableHeaderTradeDelivery")
        return deliverysettlement

    def _build_Tradesettlement(self,sctt,data: InvoiceXML):

        tradesettlement = ET.SubElement(sctt, "ram:ApplicableHeaderTradeSettlement")
        ET.SubElement(tradesettlement, "ram:InvoiceCurrencyCode").text = data.currency
        return tradesettlement

    def _build_tax(self,settlement,datas: list[InvoiceSummaryXML]):

        for data in datas:
            tax = ET.SubElement(settlement, "ram:ApplicableTradeTax")

            ET.SubElement(tax, "ram:CalculatedAmount").text = data.vat_amount
            ET.SubElement(tax, "ram:TypeCode").text = "VAT"

            if data.exempt:
                ET.SubElement(tax, "ram:ExemptionReason").text = data.exempt

            ET.SubElement(tax, "ram:BasisAmount").text = data.base_amount
            ET.SubElement(tax, "ram:CategoryCode").text = data.vat_code
            ET.SubElement(tax, "ram:RateApplicablePercent").text = data.rate

    def _build_payment_terms(self,settlement,data: InvoiceXML):
        payment = ET.SubElement(settlement, "ram:SpecifiedTradePaymentTerms")
        ET.SubElement(payment, "ram:Description").text = "Paiement à échéance"

        due = ET.SubElement(payment, "ram:DueDateDateTime")
        ET.SubElement(
            due,
            "udt:DateTimeString",
            {"format": "102"}
        ).text = data.expiration

    def _build_totals(self,settlement,data: InvoiceXML):

        totals = ET.SubElement(settlement,"ram:SpecifiedTradeSettlementHeaderMonetarySummation")
        ET.SubElement(totals, "ram:LineTotalAmount").text = data.line_total_amount
        ET.SubElement(totals, "ram:TaxBasisTotalAmount").text =data.line_total_amount
        ET.SubElement(totals,"ram:TaxTotalAmount",{"currencyID": data.currency}).text = data.tax_total_amount
        ET.SubElement(totals, "ram:GrandTotalAmount").text = data.grand_total_amount
        ET.SubElement(totals, "ram:DuePayableAmount").text = data.grand_total_amount


    def serialize(self,mapped):

        self.root = self._build_root()

        self._build_context(self.root)

        self._build_doc(self.root,mapped.invoice)

        self.sctt = self._build_sctt(self.root)

        self._build_item(self.sctt,mapped.invoice_lines)

        self.agreement = self._build_agreement(self.sctt)

        self._build_parties(self.agreement, mapped.seller,mapped.buyer)

        self.deliverysettlement = self._build_Deliverysettlement(self.sctt,mapped.invoice)

        self.tradesettlement = self._build_Tradesettlement(self.sctt,mapped.invoice)

        self._build_tax(self.tradesettlement,mapped.invoice_summary)

        self._build_payment_terms(self.tradesettlement,mapped.invoice)

        self._build_totals(self.tradesettlement,mapped.invoice)

        xml = ET.tostring(self.root, encoding="utf-8")

        return minidom.parseString(xml).toprettyxml(indent="  ",encoding="utf-8").decode()
