from ads_facturx.models.models import InvoiceType

class PolicyFactory:

    def get(self, doc_type: InvoiceType):

        if doc_type == InvoiceType.INVOICE:
            return InvoicePolicy()

        if doc_type == InvoiceType.CREDIT_NOTE:
            return CreditNotePolicy()

        if doc_type == InvoiceType.SELF_BILLING:
            return SelfBillingPolicy()

    def vat_ExemptionReason(self, vat_code):
        return "Vat exempt" if vat_code in ("E") else None


class InvoicePolicy(PolicyFactory):
    pass

class CreditNotePolicy(PolicyFactory):
    pass

class SelfBillingPolicy(PolicyFactory):
    pass
