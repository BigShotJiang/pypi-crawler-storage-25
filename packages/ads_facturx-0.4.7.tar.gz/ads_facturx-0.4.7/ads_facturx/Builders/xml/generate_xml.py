from .FacturXMapper import FacturXMapper
from .XmlSerializer import FacturxXmlSerializer
from ...models.models import DevisData
import os


def write_xml_from_string(xml_string: str, destination_folder: str, file_name: str):
    if not file_name.endswith(".xml"):
        file_name += ".xml"
    os.makedirs(destination_folder, exist_ok=True)
    file_path = os.path.join(destination_folder, file_name)
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(xml_string)
    return file_path

def export_invoice(data: DevisData):

    mapper = FacturXMapper()
    serializer = FacturxXmlSerializer()

    mapped = mapper.map(data)
    return serializer.serialize(mapped)