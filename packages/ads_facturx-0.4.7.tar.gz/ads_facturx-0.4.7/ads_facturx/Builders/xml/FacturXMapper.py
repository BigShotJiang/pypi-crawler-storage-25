from ads_facturx.Builders.xml.FacturXPolicy import PolicyFactory
from ads_facturx.Builders.xml.XmlDataClass import DataXML, PartyXML, AddressXML, InvoiceXML, InvoiceLineXML, \
    InvoiceSummaryXML
from ads_facturx.models import DevisData

class FacturXMapper:

    def map(self, data= DevisData) -> DataXML:

        self.policy = PolicyFactory().get(data.invoice.type_code)

        seller          = self.map_party(data.seller)
        buyer           = self.map_party(data.buyer)
        invoice         = self.map_invoice(data.invoice)
        invoice_lines   = [self.map_invoice_lines(l) for l in data.invoice_lines]
        invoice_summary = [self.map_invoice_summary(l) for l in data.invoice_summary]

        return DataXML(
            seller         = seller,
            buyer          = buyer,
            invoice        = invoice,
            invoice_lines  = invoice_lines,
            invoice_summary= invoice_summary
        )

    def map_party(self, party):

        addr = party.address

        return PartyXML(
            name   = party.name,
            siren = party.siren,
            vat    = party.vat,
            address= AddressXML(
                    adr_l1     = addr.adr_l1,
                    adr_l2     = addr.adr_l2,
                    adr_l3     = addr.adr_l3,
                    postcode   = addr.postcode,
                    city       = addr.city,
                    country_id = addr.country_id,
                )
        )

    def map_invoice_lines(self, invoice_lines):

        return InvoiceLineXML(
            product_code        = invoice_lines.product_code,
            type_line           = invoice_lines.type_line,
            line_id             = str(invoice_lines.line_id),
            product_description = invoice_lines.product_description,
            product_type        = invoice_lines.product_type,
            quantity            = str(invoice_lines.quantity),
            unit_price          = str(invoice_lines.unit_price),
            unit_code           = invoice_lines.unit_code,
            unit_code_xml       = invoice_lines.unit_code_xml,
            tva_code            = str(invoice_lines.tva_code),
            tva_type            = invoice_lines.tva_type,
            line_amount         = str(invoice_lines.line_amount)
        )

    def map_invoice(self,invoice):
        return InvoiceXML(
            name              = invoice.name,
            order             = invoice.order,
            date              = invoice.date,
            expiration        = invoice.expiration,
            type_code         = invoice.type_code,
            date_format       = invoice.date_format,
            currency          = invoice.currency,
            reference         = invoice.reference,
            salesperson       = invoice.salesperson,
            description       = invoice.description,
            line_total_amount = str(invoice.line_total_amount),
            tax_total_amount  = str(invoice.tax_total_amount),
            grand_total_amount= str(invoice.grand_total_amount)
        )

    def map_invoice_summary(self,invoice_summary):
        return InvoiceSummaryXML(
            rate       = str(invoice_summary.rate),
            base_amount= str(invoice_summary.base_amount),
            vat_amount = str(invoice_summary.vat_amount),
            vat_code = str(invoice_summary.vat_code),
            exempt= self.policy.vat_ExemptionReason(invoice_summary.vat_code)
        )
