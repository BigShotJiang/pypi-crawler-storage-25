from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib import colors

def get_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="Right",
        fontSize=9,
        alignment=TA_RIGHT
    ))
    styles.add(ParagraphStyle(
        name="Titles",
        fontSize=14,
        spaceAfter=12,
        bold=True
    ))

    styles.add(ParagraphStyle(
    name="TempTitle",
    parent=styles["Normal"],
    fontSize=14,
    textColor=colors.black,
    fontName="Helvetica",
    bold=True
))

    styles.add(ParagraphStyle(
        name="Bold",
        parent=styles["Normal"],
        fontSize=9,
        textColor=colors.black,
        fontName="Helvetica-Bold"
))

    styles.add(ParagraphStyle(
    name="Rights",
    parent=styles["Normal"],
    fontSize=9,
    alignment=2  # 0=left, 1=center, 2=right
))

    styles.add(ParagraphStyle(
        name="Normal_9",
        parent=styles["Normal"],
        fontSize=9
    ))

    styles.add(ParagraphStyle(
        name="Tiny",
        parent=styles["Normal"],
        fontSize=7,
        alignment=0  # 0=left, 1=center, 2=right
    ))

    styles.add(ParagraphStyle(
        name="TinyBold",
        parent=styles["Normal"],
        fontSize=7,
        alignment=0,
        fontName="Helvetica-Bold",
        bold=True
    ))

    styles.add(ParagraphStyle(
        name="Header",
        parent=styles["Normal"],
        fontSize=9,
        alignment=1,  # centre
        fontName="Helvetica-Bold"
    ))

    styles.add(ParagraphStyle(
        name="HeaderL",
        parent=styles["Normal"],
        fontSize=9,
        alignment=0,  # centre
        fontName="Helvetica-Bold"
    ))

    styles.add(ParagraphStyle(
        name="HeaderR",
        parent=styles["Normal"],
        fontSize=9,
        alignment=2,
        fontName="Helvetica-Bold"
    ))

    return styles
