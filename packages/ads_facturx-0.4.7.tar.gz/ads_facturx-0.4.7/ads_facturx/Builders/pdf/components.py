from reportlab.platypus import Table, TableStyle, Paragraph, KeepInFrame
from reportlab.lib import colors
from reportlab.lib.units import mm


class ItemsTableComponent:

    def __init__(self, invoice, styles):
        self.invoice = invoice
        self.styles = styles
        self.config = InvoiceConfig

    def build(self):

        rows = [self._build_header()]
        style_commands = self._base_style()

        for index, item in enumerate(self.invoice.invoice_lines, start=1):

            row = self._build_row(item)
            rows.append(row)

            if index % 2 == 1:
                style_commands.append(
                    ("BACKGROUND", (0, index), (-1, index), colors.whitesmoke)
                )

        table = Table(
            rows,
            colWidths=self.config.col_widths,
            repeatRows=1,
            hAlign="CENTER",
            vAlign="TOP",
        )

        table.setStyle(TableStyle(style_commands))

        return [table]

    def _build_header(self):

        labels = self.config.labels

        return [
            Paragraph(labels["description"], self.styles["HeaderL"]),
            Paragraph(labels["quantity"], self.styles["Header"]),
            Paragraph(labels["unit"], self.styles["Header"]),
            Paragraph(labels["unit_price"], self.styles["Header"]),
            Paragraph(labels["vat"], self.styles["Header"]),
            Paragraph(labels["amount"], self.styles["Header"]),
        ]


    def _build_row(self, item):

        if item.type_line in ["comment", "title"]:
            return self._build_special_row(item)

        return self._build_standard_row(item)


    def _build_special_row(self, item):

        style = (
            self.styles["Normal_9"]
            if item.type_line == "comment"
            else self.styles["Bold"]
        )

        desc = KeepInFrame(
            self.config.comment_width,
            20,
            [Paragraph(item.product_description, style)],
            mode="shrink"
        )

        return [desc, "", "", "", "", ""]

    # -------------------------------------------------
    # STANDARD ROW
    # -------------------------------------------------
    def _build_standard_row(self, item):

        desc = KeepInFrame(
            self.config.description_max_width,
            self.config.description_max_height,
            [Paragraph(item.product_description, self.styles["Normal"])],
            mode="shrink"
        )

        return [
            desc,
            Paragraph(f"{item.quantity:.3f}", self.styles["Rights"]),
            Paragraph(item.unit_code, self.styles["Rights"]),
            Paragraph(f"{item.unit_price:.2f}", self.styles["Rights"]),
            Paragraph(f"{item.tva_code} %", self.styles["Rights"]),
            Paragraph(f"{item.line_amount:.2f} €", self.styles["Rights"]),
        ]


    def _base_style(self):

        return [
            ("LINEBELOW", (0, 0), (-1, 0), 1, colors.black),
            ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("TOPPADDING", (0, 0), (-1, -1), 1),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ]

# document_configs/invoice_config.py

from dataclasses import dataclass


@dataclass
class InvoiceConfig:

    labels = {
        "description": "Description",
        "quantity": "Quantité",
        "unit": "Unité",
        "unit_price": "Prix unitaire",
        "vat": "TVA",
        "amount": "Montant HT",
    }

    col_widths = [90*mm, 20*mm, 15*mm, 20*mm, 20*mm, 25*mm]

    description_max_width = 2400
    description_max_height = 10000

    comment_width = 90