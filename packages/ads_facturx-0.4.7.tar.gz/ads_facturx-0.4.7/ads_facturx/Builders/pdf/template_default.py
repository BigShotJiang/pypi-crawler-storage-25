from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import PageBreak, KeepTogether
from reportlab.platypus import Paragraph, Table, TableStyle, Spacer, KeepInFrame


def partner(elements, styles, data):

    company = data.buyer
    rf = data.reference_box

    lines = [
        company.name,
        f"{company.address.adr_l1} {company.address.adr_l2} {company.address.adr_l3}",
        f"{company.address.postcode} {company.address.city} - {company.address.country_id}",
        f"SIREN : {company.siren}"
    ]

    right_content = [Paragraph(line, styles["Normal_9"]) for line in lines]

    # ----------- GAUCHE -----------
    empty = Paragraph("", styles["Titles"])


    type_fac =""
    if data.invoice.type_code=='380':
         type_fac="Facture"
    if data.invoice.type_code=='381':
         type_fac="Avoir"
    if data.invoice.type_code=='389':
         type_fac="AutoFacturation"

    title = Paragraph(
        f"<b>{type_fac} : {data.invoice.name}</b>",
        styles["TempTitle"]
    )

    table_data = []
    for item in rf:
        style = styles["TinyBold"] if item.rb_type == "title" else styles["Tiny"]

        label_text = item.rb_label if item.rb_label else ""

        label = KeepInFrame(50*mm, 10*mm,[Paragraph(label_text, style)], mode='shrink')
        description = KeepInFrame(50*mm, 10*mm,[Paragraph(item.rb_dscription, styles["Tiny"])], mode='shrink')

        table_data.append([label, description])

    if len(table_data)>0:
        inner_table = Table(table_data, colWidths=[35*mm, 55*mm])
        inner_table.setStyle([

            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
            ("TOPPADDING", (0, 0), (-1, -1), 0),
        ])

        left_content = Table([[title],
                              [empty],
                             [inner_table]])
    else:
        left_content = title

    # ----------- TABLE PRINCIPALE -----------
    main_table = Table(
        [[left_content, empty,
              [empty,empty,right_content]]],
        colWidths=[90*mm, 20*mm,80*mm]
    )

    main_table.setStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ])

    elements.append(main_table)

def format_date(date):
    date_obj = datetime.strptime(date, "%Y%m%d")
    return date_obj.strftime("%d/%m/%Y")

def four_columns_block(elements, styles, data,col_widths=None):

    invoice = data.invoice
    elements.append(Spacer(1, 10))
    columns = [
        ("Adhérent", invoice.member),
        ("Date de la facture", format_date(invoice.date)),
        ("Date d'échéance", format_date(invoice.expiration)),
        ("Référence", invoice.reference),
    ]


    cells = []
    for title, content in columns:
        cells.append(
            Paragraph(
                f"<b>{title}</b><br/>{content}",
                styles["Normal_9"]
            )
        )

    table = Table(
        [cells],   # ← UNE seule ligne
        colWidths=col_widths,
        hAlign="LEFT"
    )

    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))

    elements.append(table)

def footer_information(elements, styles, data):
    table_data = []
    for row in data.footer_information:
        text = f"{row.fi_label} {row.fi_dscription}" if row.fi_label !="" else row.fi_dscription
        if row.fi_type == 'title':
            table_data.append([Paragraph(text, styles["TinyBold"])])
        else:
            table_data.append([Paragraph(text, styles["Tiny"])])

    # Créer le tableau
    table = Table(table_data, colWidths=[190*mm])

    # Construire le style
    style_commands = [
        ("BOX", (0, 0), (-1, -1), 0.5, colors.grey),  # Encadré global
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0)
    ]

    table.setStyle(TableStyle(style_commands))
    elements.append(Spacer(1, 15))
    elements.append(KeepTogether(table))
    elements.append(Spacer(1, 15))

def items_table(elements, styles, data):
    rows = [[
        Paragraph("Description", styles["HeaderL"]),
        Paragraph("Quantité", styles["Header"]),
        Paragraph("Unité", styles["Header"]),
        Paragraph("Prix unitaire", styles["Header"]),
        Paragraph("TVA", styles["Header"]),
        Paragraph("Montant HT", styles["Header"])
    ]]

    style_commands = [
        ("LINEBELOW", (0,0), (-1,0), 1, colors.black),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ('TOPPADDING', (0, 0), (-1, -1), 1),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1)
    ]

    row_index = 1  # on commence après le header

    max_width = 2400*mm
    max_height = 10000

    for item in data.invoice_lines:

        # --- ligne description (si type_line = comment ou title) ---
        if item.type_line in ["comment", "title"]:

            if item.type_line=='comment':
                style = styles["Normal_9"]
            elif item.type_line=='title':
                style = styles["Bold"]


            product_description = KeepInFrame(90*mm, 20, [
                Paragraph(item.product_description, style)
            ], mode='shrink')
            rows.append([product_description,"","","",""])

        else:

            product_description = KeepInFrame(max_width, max_height, [
                Paragraph(item.product_description, styles['Normal'])
            ], mode='shrink')
            quantity = Paragraph(f"{item.quantity:.3f}", styles['Rights'])
            unit = Paragraph(f"{item.unit_code}", styles['Rights'])
            unit_price = Paragraph(f"{item.unit_price:.2f}", styles['Rights'])
            tva_code = Paragraph(f"{item.tva_code} %", styles['Rights'])
            amount = Paragraph(f"{item.line_amount:.2f} €", styles['Rights'])

            rows.append([
                product_description,
                quantity,
                unit,
                unit_price,
                tva_code,
                amount,
            ])

        if row_index % 2 == 1:
            style_commands.append(
                ("BACKGROUND", (0, row_index), (-1, row_index), colors.whitesmoke)
            )

        row_index += 1

    table = Table(
        rows,
        colWidths=[90*mm, 20*mm,15*mm,  20*mm, 20*mm, 25*mm],
        repeatRows=1,
        vAlign='TOP',
        hAlign="CENTER"
    )

    table.setStyle(TableStyle(style_commands))

    elements.append(table)

def annexe_table(elements, styles, data):
    rows = [[
        Paragraph("no_bon", styles["Header"]),
        Paragraph("date", styles["Header"]),
        Paragraph("silo", styles["Header"]),
        Paragraph("bonliv", styles["Header"]),
        Paragraph("poids livre", styles["Header"]),
        Paragraph("hum", styles["Header"]),
        Paragraph("imp", styles["Header"]),
        Paragraph("amb", styles["Header"]),
        Paragraph("divers", styles["Header"])
    ]]

    max_width = 2400 * mm
    max_height = 10000  # hauteur max de la cellule

    for item in data:
        no_bon = KeepInFrame(max_width, max_height,
                                          [Paragraph(item["no_bon"], styles['Rights'])], mode='shrink')
        date = KeepInFrame(max_width, max_height, [Paragraph(f"{item["date"]}", styles['Normal'])], mode='shrink')
        silo = KeepInFrame(max_width, max_height, [Paragraph(f"{item["silo"]}", styles['Rights'])],
                                 mode='shrink')
        bonliv = KeepInFrame(max_width, max_height, [Paragraph(f"{item["bonliv"]}", styles['Rights'])],
                               mode='shrink')
        poids_livre = KeepInFrame(max_width, max_height,
                             [Paragraph(f"{item["poids_livre"]:.3f}", styles['Rights'])], mode='shrink')
        hum = KeepInFrame(max_width, max_height,
                                          [Paragraph(f"{item["hum"]}", styles['Rights'])], mode='shrink')
        imp = KeepInFrame(max_width, max_height, [Paragraph(f"{item["imp"]}", styles['Rights'])], mode='shrink')

        divers = KeepInFrame(max_width, max_height,
                             [Paragraph(f"{item["divers"]}", styles['Rights'])], mode='shrink')

        rows.append([
            no_bon,
            date,
            silo,
            bonliv,
            poids_livre,
            hum,
            imp,
            divers
        ])

    table = Table(
        rows,
        colWidths=[20 * mm, 20 * mm, 20 * mm, 20 * mm, 20 * mm],
        rowHeights=9 * mm,
        repeatRows=1,
        vAlign='Top',
        hAlign="CENTER"
    )

    style_commands = [
        # Header
        ("LINEBELOW", (0, 0), (-1, 0), 1, colors.black),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ]

    # Alternance de couleurs (lignes de données uniquement)
    for row_index in range(1, len(rows)):
        if row_index % 2 == 1:
            style_commands.append(
                ("BACKGROUND", (0, row_index), (-1, row_index), colors.whitesmoke)
            )

    elements.append(PageBreak())
    elements.append(Paragraph("Annexe détail produit(s) vendu(s)", styles["Titles"]))
    table.setStyle(TableStyle(style_commands))
    elements.append(table)
    elements.append(Spacer(1, 15))

def summary_tables(elements,styles,data):
    elements.append(Spacer(1, 15))
    rows = [[
        Paragraph("Taux TVA", styles["HeaderR"]),
        Paragraph("Base HT", styles["HeaderR"]),
        Paragraph("MT TVA", styles["HeaderR"]),
        Paragraph("TTC", styles["HeaderR"])
    ]]


    invoice_ttc = f"""{data.invoice.grand_total_amount:.2f}€"""
    invoice_sum = data.invoice_summary


    for line in invoice_sum:

            taux_tva = Paragraph(f"""{line.rate:.2f}%""", styles["Rights"])
            base_ht = Paragraph(f"""{line.base_amount:.2f}€""", styles["Rights"])
            mt_tva = Paragraph(f"""{line.vat_amount:.2f}€""", styles["Rights"])
            mt_ttc = Paragraph(f"""{(line.base_amount + line.vat_amount):.2f}€""", styles["Rights"])
            rows.append([taux_tva, base_ht, mt_tva, mt_ttc])

    rows.append(["", "","Total :",invoice_ttc])

    # Création du tableau
    table = Table(
        rows,
        colWidths=[25 * mm, 25 * mm, 25 * mm, 25 * mm],
        rowHeights=6 * mm,
        vAlign='Top',
        hAlign="RIGHT"
    )

    style_commands = [
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, len(rows)-1), (-1, len(rows)-1), "Helvetica-Bold"),
        ('TOPPADDING', (0, 0), (-1, -1), 1),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1)
    ]

    # Alternance de couleurs (lignes de données uniquement)
    for row_index in range(1, len(rows)):
        if row_index % 2 == 1:
            style_commands.append(
                ("BACKGROUND", (0, row_index), (-1, row_index), colors.whitesmoke)
            )

    table.setStyle(TableStyle(style_commands))
    elements.append(KeepTogether(table))

def invoice_description(elements, styles, data):
    for line in data.invoice.description:
        elements.append(Paragraph(line, styles["Normal_9"]))
        elements.append(Spacer(1, 4))

def draw_footer(canvas, doc, footer):
    canvas.saveState()
    canvas.setFont("Helvetica", 10)

    # --- Position verticale de départ ---
    y_start = 20 * mm

    # --- Trait de séparation ---
    canvas.setLineWidth(0.5)
    canvas.line(doc.leftMargin, y_start + 10, doc.pagesize[0] - doc.rightMargin, y_start + 10)

    # --- Texte centré ---
    line = f"{footer.left} | {footer.middle} | {footer.right}"


    # drawCentredString centre horizontalement sur la page
    canvas.drawCentredString(doc.pagesize[0]/2, y_start, line)
    y_start -= 15  # espace entre les lignes (10 points)
    canvas.drawCentredString(doc.pagesize[0]/2, y_start, footer.bottom)
    y_start -= 15
    # --- Numéro de page (droite) ---
    canvas.drawCentredString(
        doc.pagesize[0]/2,
        y_start,
        f"Page {doc.page}"
    )

    canvas.restoreState()

def draw_header(canvas, doc, company, logopath):
    canvas.saveState()

    HEADER_Y = doc.pagesize[1] - 10 * mm
    DELTA_IMAGE = 50
    logo = ImageReader(str(Path(logopath)))
    canvas.drawImage(
        logo,
        doc.leftMargin,
        HEADER_Y - 25*mm,
        width=38*mm,
        height=38*mm,
        preserveAspectRatio=True,
        mask="auto"
    )
    y=HEADER_Y
    # --- COMPANY NAME ---
    canvas.setFont("Helvetica", 10)
    canvas.drawString(
        doc.leftMargin + DELTA_IMAGE + 35 * mm,
        y,

        company[0].information
    )

    y -= 11
    canvas.setFont("Helvetica", 8)
    canvas.drawString(
        doc.leftMargin + DELTA_IMAGE + 35 * mm,
        y,
        company[1].information
    )

    y -= 11
    canvas.drawString(
        doc.leftMargin + DELTA_IMAGE + 35 * mm,
        y,
        company[2].information
    )
    y -= 11
    canvas.drawString(
        doc.leftMargin + DELTA_IMAGE + 35 * mm,
        y,
        company[3].information
    )
    y -= 11
    canvas.drawString(
        doc.leftMargin + DELTA_IMAGE + 35 * mm,
        y,
        company[4].information
    )

    canvas.restoreState()
