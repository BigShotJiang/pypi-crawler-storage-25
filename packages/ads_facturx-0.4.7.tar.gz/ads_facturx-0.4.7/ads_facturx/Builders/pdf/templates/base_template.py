from ads_facturx.models.models import DevisData
from ads_facturx.Builders.pdf.components import ItemsTableComponent
from ads_facturx.Builders.pdf.styles import get_styles

class BaseTemplateInvoice:


    def build_story(self, invoice: DevisData,style):
        story = []

        story.extend(ItemsTableComponent(invoice, style).build())
        # story.extend(ItemsTableComponent(invoice).build())
        # story.extend(TotalsComponent(invoice).build())

        return story

class BaseTemplateSelfBilling:

    def build_story(self, invoice: DevisData,style):
        story = []

        story.extend(ItemsTableComponent(invoice, style).build())
        # story.extend(ItemsTableComponent(invoice).build())
        # story.extend(TotalsComponent(invoice).build())

        return story

class BaseTemplateCreditNote:

    def build_story(self, invoice: DevisData,style):
        story = []

        story.extend(ItemsTableComponent(invoice, style).build())
        # story.extend(ItemsTableComponent(invoice).build())
        # story.extend(TotalsComponent(invoice).build())

        return story
