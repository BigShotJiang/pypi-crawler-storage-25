from ads_facturx.Builders.pdf.themes.default import DefaultTheme
from ads_facturx.models.models import InvoiceType

from templates.base_template import (
    BaseTemplateInvoice,BaseTemplateSelfBilling, BaseTemplateCreditNote
)


class TemplateResolver:

    _registry = {

        ("base", InvoiceType.INVOICE):
            BaseTemplateInvoice,
        ("base", InvoiceType.SELF_BILLING):
            BaseTemplateSelfBilling,
        ("base", InvoiceType.CREDIT_NOTE):
            BaseTemplateCreditNote,
    }


    @classmethod
    def resolve(cls, client, document_type):

        template = cls._registry.get(
            (client, document_type)
        )

        if template:
            return template()

        raise ValueError("No template found")

class StyleResolver:

    _registry = {

        ("default"):
            DefaultTheme,

    }

    @classmethod
    def resolve(cls, style):

        template = cls._registry.get(
            (style)
        )

        if template:
            return template()

        raise ValueError("No template found")