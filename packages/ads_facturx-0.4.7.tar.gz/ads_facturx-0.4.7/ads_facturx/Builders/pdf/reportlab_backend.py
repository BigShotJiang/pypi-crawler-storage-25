from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader


class ReportlabCanvasBackend:

    def __init__(self, canvas, doc):
        self.canvas = canvas
        self.doc = doc

    def draw_image(self, path, x, y, w, h):
        img = ImageReader(path)
        self.canvas.drawImage(img, x, y, width=w, height=h, preserveAspectRatio=True, mask="auto")

    def draw_text(self, text, x, y, font="Helvetica", size=9):
        self.canvas.setFont(font, size)
        self.canvas.drawString(x, y, text)

    def save(self):
        self.canvas.saveState()

    def restore(self):
        self.canvas.restoreState()