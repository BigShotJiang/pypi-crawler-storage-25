# styles/factories.py

from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors


def create_heading_style(
    name="Heading",
    font_size=18,
    color=colors.black,
):

    return ParagraphStyle(
        name=name,
        fontName="Helvetica-Bold",
        fontSize=font_size,
        textColor=color,
        spaceAfter=12,
    )


def create_body_style():

    return ParagraphStyle(
        name="Body",
        fontName="Helvetica",
        fontSize=10,
        leading=14,
    )