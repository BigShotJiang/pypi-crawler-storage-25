from reportlab.platypus import SimpleDocTemplate, PageTemplate, Frame
from reportlab.lib.units import mm
from reportlab.lib.pagesizes import A4

class PDFRenderer:

    def render(self, story, title, output_path: str):

        HEADER_HEIGHT = 20 * mm
        FOOTER_HEIGHT = 15 * mm
        doc = SimpleDocTemplate(
            output_path,
            title=title,
            author="Alchimie Data Solutions",
            creator="Alchimie Data Solutions",
            pagesize=A4,
            rightMargin=10 * mm,
            leftMargin=10 * mm,
            topMargin=HEADER_HEIGHT + 20 * mm,
            bottomMargin=FOOTER_HEIGHT + 10 * mm
        )

        doc.build(story)