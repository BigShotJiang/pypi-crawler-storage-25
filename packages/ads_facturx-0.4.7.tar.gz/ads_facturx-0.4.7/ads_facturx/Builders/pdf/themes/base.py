from dataclasses import dataclass
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle


@dataclass
class Theme:

    primary_color: any
    secondary_color: any

    heading_style: ParagraphStyle
    body_style: ParagraphStyle
    table_header_style: ParagraphStyle