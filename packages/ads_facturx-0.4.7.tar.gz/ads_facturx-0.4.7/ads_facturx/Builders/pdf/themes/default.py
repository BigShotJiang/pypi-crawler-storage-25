from reportlab.lib import colors

from ads_facturx.Builders.pdf.style.styles import (
    create_heading_style,
    create_body_style,
)
from ads_facturx.Builders.pdf.themes.base import Theme

DefaultTheme = Theme(
    primary_color=colors.HexColor("#2E3A59"),
    secondary_color=colors.HexColor("#F5F6FA"),

    heading_style=create_heading_style(
        color=colors.HexColor("#2E3A59")
    ),

    body_style=create_body_style(),

    table_header_style=create_heading_style(
        name="TableHeader",
        font_size=11,
        color=colors.white,
    )
)