from pydantic import BaseModel, Field, constr, field_validator
from typing import List, Optional
from enum import Enum

class VatCategory(str, Enum):
    S = "S"     # Standard rate
    E = "E"     # Exempt
    AE = "AE"   # Reverse charge
    O = "O"     # Outside scope
    AA = "AA"     #Reduced rate
    Z = "Z"     #Zero rate
    K = "K"     #Livraison intercommunautaire
    G = "G"     #Export hors UE
    L = "L"


class CurrencyCode(str, Enum):
    EUR = "EUR"


class DateFormat(str, Enum):
    YYYYMMDD = "102"

class Address(BaseModel):
    adr_l1: str
    adr_l2: Optional[str] = None
    adr_l3: Optional[str] = None
    postcode: str
    city: str
    country_id: constr(min_length=2, max_length=2)

class Partner(BaseModel):
    name: str
    code: str
    address: Address
    siren: Optional[str] = None
    vat: Optional[str] = None

class Reference_box(BaseModel):
    rb_type: str
    rb_label: Optional[str]
    rb_dscription: str

class Footer_information(BaseModel):
    fi_type: str
    fi_label: Optional[str]
    fi_dscription: str

class InvoiceType(str, Enum):
    INVOICE = "380"
    CREDIT_NOTE = "381"
    SELF_BILLING = "389"

class Invoice(BaseModel):
    name: str
    order: str
    member: str
    date: constr(min_length=8, max_length=8)  # YYYYMMDD
    expiration: constr(min_length=8, max_length=8)
    type_code: InvoiceType
    date_format: str
    currency: str
    reference: Optional[str] = None
    salesperson: Optional[str] = None
    description: Optional[List[str]] = None
    line_total_amount: float
    tax_total_amount : float
    grand_total_amount: float


class InvoiceLine(BaseModel):

    product_code: Optional[str] = None
    type_line: str
    line_id: int
    product_description: str
    product_type: Optional[str] = None
    quantity: Optional[float] = None
    unit_price: Optional[float] = None
    unit_code: Optional[str] = None
    unit_code_xml: Optional[str] = None
    tva_code: Optional[float] = None
    tva_type: Optional[VatCategory] = None
    line_amount: float


class InvoiceSummary(BaseModel):
    rate: float
    base_amount: float
    vat_amount: float
    vat_code: str

class Footer(BaseModel):
    left: Optional[str] = None
    middle: Optional[str] = None
    right: Optional[str] = None
    bottom: Optional[str] = None


class Other(BaseModel):
    terms_url: Optional[str] = None

class Identification(BaseModel):
    society: str
    sort_order: int
    formatting: str
    size: str
    text_alignment: str
    information: str

class DevisData(BaseModel):
    identification : List[Identification]
    seller: Partner
    buyer: Partner
    invoice: Invoice
    invoice_lines: List[InvoiceLine]
    invoice_summary: List[InvoiceSummary]
    footer: Optional[Footer] = None
    other: Optional[Other] = None
    reference_box : List[Reference_box]
    footer_information : List[Footer_information]
