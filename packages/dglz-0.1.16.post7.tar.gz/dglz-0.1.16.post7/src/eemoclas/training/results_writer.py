"""ResultsWriter -- Per-epoch metrics CSV writer + background plot generator.

CSV is appended synchronously each epoch.  Plots are regenerated in a
background thread so training is never blocked.

Directory layout::

    {log_dir}/
    ├── metrics.csv
    └── plot/
        ├── single/   (one metric per PNG)
        └── compare/  (train vs val overlay per PNG)

Apache-2.0  --  SuShuHeng
"""
from __future__ import annotations

import csv
import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

logger = logging.getLogger("dglz.training")

# CSV column definitions -- compatible with all 6 DGLZ classifiers.
# val_balanced_accuracy is removed (deprecated).
CSV_COLUMNS = [
    "epoch",
    "train_loss", "train_accuracy",
    "val_loss", "val_accuracy", "val_macro_f1", "val_auc",
    "lr", "epoch_time",
]

# (csv_key, plot_title, y_axis_label)
SINGLE_METRICS: list[tuple[str, str, str]] = [
    ("train_loss",      "Training Loss",       "Loss"),
    ("train_accuracy",  "Training Accuracy",   "Accuracy"),
    ("train_auc",       "Training AUC",        "AUC"),
    ("train_macro_f1",  "Training Macro F1",   "F1"),
    ("val_loss",        "Validation Loss",      "Loss"),
    ("val_accuracy",    "Validation Accuracy",  "Accuracy"),
    ("val_auc",         "Validation AUC",       "AUC"),
    ("val_macro_f1",    "Validation Macro F1",  "F1"),
    ("lr",              "Learning Rate",        "LR"),
    ("epoch_time",      "Epoch Time",           "Seconds"),
]

# (train_key, val_key, metric_name_for_filename)
COMPARE_METRICS: list[tuple[str, str, str]] = [
    ("train_loss",     "val_loss",     "loss"),
    ("train_accuracy", "val_accuracy", "accuracy"),
]


class ResultsWriter:
    """Per-epoch metrics CSV writer + background plot generator."""

    def __init__(
        self,
        save_dir: Path,
        *,
        columns: list[str] | None = None,
        dual_line_metrics: list[tuple] | None = None,
    ) -> None:
        self._save_dir = Path(save_dir)
        self._csv_path = self._save_dir / "metrics.csv"
        self._single_dir = self._save_dir / "plot" / "single"
        self._compare_dir = self._save_dir / "plot" / "compare"

        self._columns = columns if columns is not None else list(CSV_COLUMNS)
        self._dual_line_metrics = dual_line_metrics or []

        self._single_dir.mkdir(parents=True, exist_ok=True)
        self._compare_dir.mkdir(parents=True, exist_ok=True)

        self._history: list[dict] = []
        self._executor = ThreadPoolExecutor(max_workers=1)

        # Resume: load existing CSV data, or create fresh file
        loaded = self._load_existing_csv()
        if loaded > 0:
            logger.info("ResultsWriter: loaded %d epochs from existing CSV", loaded)
            self._executor.submit(self._generate_all_plots)
        else:
            self._write_csv_header()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def append_epoch(self, metrics: dict) -> None:
        """Append one epoch's metrics to CSV + trigger background plot regeneration."""
        self._history.append(metrics)
        self._write_csv_row(metrics)
        self._executor.submit(self._generate_all_plots)

    def finalize(self) -> None:
        """Wait for background plot generation to finish. Call on training end/interrupt."""
        self.executor_shutdown(wait=True)

    def trim_after_epoch(self, max_epoch: int) -> None:
        """Remove epochs > *max_epoch* from both history and CSV."""
        original_len = len(self._history)
        self._history = [
            h for h in self._history if h.get("epoch", 0) <= max_epoch
        ]
        trimmed = original_len - len(self._history)
        if trimmed > 0:
            logger.info("ResultsWriter: trimmed %d rows with epoch > %d", trimmed, max_epoch)
            self._write_csv_header()
            for h in self._history:
                self._write_csv_row(h)
            self._executor.submit(self._generate_all_plots)

    def verify_consistency(self, checkpoint_epoch: int) -> None:
        """Ensure CSV history matches checkpoint epoch count.

        Checkpoint is the source of truth. Trims CSV if it has more rows
        than checkpoint_epoch + 1 (checkpoint_epoch is 0-based).
        """
        max_allowed_epoch = checkpoint_epoch + 1
        extra = [h for h in self._history if h.get("epoch", 0) > max_allowed_epoch]
        if extra:
            logger.warning(
                "CSV has %d rows with epoch > %d (checkpoint_epoch=%d), trimming",
                len(extra), max_allowed_epoch, checkpoint_epoch,
            )
            self.trim_after_epoch(max_allowed_epoch)

    def load_history(self, history: list[dict]) -> None:
        """Load history from checkpoint (used for plot continuity on resume)."""
        if history:
            self._history = list(history)
            self._executor.submit(self._generate_all_plots)

    # ------------------------------------------------------------------
    # Train-only mode support
    # ------------------------------------------------------------------

    def set_train_only(self, train_only: bool) -> None:
        """Switch between normal and train-only CSV column layout.

        When *train_only* is True the CSV header is rewritten to exclude
        ``val_*`` columns (they would always be empty), any stale
        ``val_*.png`` / ``compare_*.png`` files left from a previous
        normal-mode run are removed, and val keys are stripped from
        in-memory history so plots are regenerated cleanly.
        """
        if not train_only:
            return

        val_cols = {c for c in self._columns if c.startswith("val_")}
        if not val_cols:
            return  # already in train-only layout

        self._columns = [c for c in self._columns if c not in val_cols]

        # Strip val keys from in-memory history
        for h in self._history:
            for vc in val_cols:
                h.pop(vc, None)

        # Rewrite CSV with new columns (preserve existing rows)
        self._write_csv_header()
        for h in self._history:
            self._write_csv_row(h)

        # Remove stale plot files from a previous normal-mode run
        self._cleanup_stale_plots()

        # Regenerate plots with clean (no val) history
        if self._history:
            self._executor.submit(self._generate_all_plots)

    def _cleanup_stale_plots(self) -> None:
        """Delete val_*.png and compare_*.png that are no longer relevant."""
        removed = 0
        for p in self._single_dir.glob("val_*.png"):
            p.unlink(missing_ok=True)
            removed += 1
        for p in self._compare_dir.glob("compare_*.png"):
            p.unlink(missing_ok=True)
            removed += 1
        if removed:
            logger.info("ResultsWriter: cleaned up %d stale val/compare plot(s)", removed)

    # ------------------------------------------------------------------
    # Executor lifecycle (Python 3.12/3.13 safe)
    # ------------------------------------------------------------------

    def executor_shutdown(self, wait: bool = True) -> None:
        """Shut down the background executor thread pool."""
        try:
            self._executor.shutdown(wait=wait)
        except RuntimeError:
            pass

    # ------------------------------------------------------------------
    # CSV I/O
    # ------------------------------------------------------------------

    def _load_existing_csv(self) -> int:
        """Load existing CSV into ``_history``. Returns rows loaded."""
        if not self._csv_path.exists():
            return 0
        try:
            with open(self._csv_path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                if reader.fieldnames is None:
                    return 0
                count = 0
                for row in reader:
                    try:
                        parsed = {}
                        for col in self._columns:
                            val = row.get(col, "")
                            if val == "" or val is None:
                                parsed[col] = None
                            elif col == "epoch":
                                parsed[col] = int(val)
                            else:
                                parsed[col] = float(val)
                        self._history.append(parsed)
                        count += 1
                    except (ValueError, TypeError) as exc:
                        logger.warning("ResultsWriter: skipping malformed CSV row: %s", exc)
                return count
        except Exception as exc:
            logger.warning("ResultsWriter: failed to read CSV: %s", exc)
            return 0

    def _write_csv_header(self) -> None:
        with open(self._csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self._columns)
            writer.writeheader()

    def _write_csv_row(self, metrics: dict) -> None:
        row = {}
        for col in self._columns:
            val = metrics.get(col)
            if val is None:
                row[col] = ""
            elif isinstance(val, float):
                row[col] = f"{val:.6f}"
            else:
                row[col] = val
        with open(self._csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self._columns)
            writer.writerow(row)

    # ------------------------------------------------------------------
    # Plot generation (runs in background thread)
    # ------------------------------------------------------------------

    def _generate_all_plots(self) -> None:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib not installed; skipping plot generation")
            return

        epochs = [h.get("epoch", i + 1) for i, h in enumerate(self._history)]
        if not epochs:
            return

        for key, title, ylabel in SINGLE_METRICS:
            values = [h.get(key) for h in self._history]
            if all(v is None for v in values):
                continue
            self._plot_single(plt, epochs, values, title, ylabel,
                              self._single_dir / f"{key}.png")

        for train_key, val_key, name in COMPARE_METRICS:
            train_vals = [h.get(train_key) for h in self._history]
            val_vals = [h.get(val_key) for h in self._history]
            if all(v is None for v in train_vals) or all(v is None for v in val_vals):
                continue
            self._plot_compare(plt, epochs, train_vals, val_vals,
                               train_key, val_key,
                               self._compare_dir / f"compare_{name}.png")

        # Dual-line plots (e.g., subject vs emotion metrics)
        for key1, key2, title, ylabel, filename in self._dual_line_metrics:
            vals1 = [h.get(key1) for h in self._history]
            vals2 = [h.get(key2) for h in self._history]
            if all(v is None for v in vals1) and all(v is None for v in vals2):
                continue
            self._plot_dual_line(
                plt, epochs, vals1, vals2, title, ylabel,
                key1, key2,
                self._single_dir / f"{filename}.png",
            )

        plt.close("all")

    @staticmethod
    def _plot_single(plt, epochs, values, title, ylabel, save_path):
        fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
        valid = [(e, v) for e, v in zip(epochs, values) if v is not None]
        if valid:
            es, vs = zip(*valid)
            ax.plot(es, vs, linewidth=1.5)
        ax.set_title(title)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(save_path)
        plt.close(fig)

    @staticmethod
    def _plot_compare(plt, epochs, train_vals, val_vals, train_label, val_label, save_path):
        fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
        valid_train = [(e, v) for e, v in zip(epochs, train_vals) if v is not None]
        valid_val = [(e, v) for e, v in zip(epochs, val_vals) if v is not None]
        if valid_train:
            es, vs = zip(*valid_train)
            ax.plot(es, vs, linewidth=1.5, label=train_label, color="steelblue")
        if valid_val:
            es, vs = zip(*valid_val)
            ax.plot(es, vs, linewidth=1.5, label=val_label, color="coral")
        ax.set_title(f"{train_label.replace('train_', '').replace('_', ' ').title()} "
                     f"Comparison (Train vs Val)")
        ax.set_xlabel("Epoch")
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(save_path)
        plt.close(fig)

    @staticmethod
    def _plot_dual_line(plt, epochs, vals1, vals2, title, ylabel,
                        label1, label2, save_path):
        fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
        valid1 = [(e, v) for e, v in zip(epochs, vals1) if v is not None]
        valid2 = [(e, v) for e, v in zip(epochs, vals2) if v is not None]
        if valid1:
            es, vs = zip(*valid1)
            ax.plot(es, vs, linewidth=1.5, label=label1, color="steelblue")
        if valid2:
            es, vs = zip(*valid2)
            ax.plot(es, vs, linewidth=1.5, label=label2, color="coral")
        ax.set_title(title)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        ax.legend()
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(save_path)
        plt.close(fig)
