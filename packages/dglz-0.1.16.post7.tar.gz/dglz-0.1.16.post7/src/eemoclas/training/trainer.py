"""Per-model trainer with Rich display support.

Features:

* Train / validation loop with epoch-level metrics
* Checkpoint saving (``best_model.ckpt``, ``latest_model.ckpt``)
* Configurable monitoring metric for best-checkpoint selection
* Early stopping
* Rich progress bar + log panel (``--verbose``) or silent progress bar
* ASCII-box log file via :mod:`eemoclas.utils.log_formatter`
* Per-epoch ``metrics_history.csv``
* Config snapshot saved alongside checkpoints

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import csv
import logging
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from eemoclas.training.checkpoint import load_checkpoint, save_checkpoint
from eemoclas.training.results_writer import ResultsWriter
from eemoclas.training.early_stopping import EarlyStopping
from eemoclas.training.loss import compute_class_weights, create_criterion
from eemoclas.training.metrics import compute_train_metrics, compute_val_metrics
from eemoclas.training.optimizer import create_optimizer
from eemoclas.training.scheduler import create_scheduler
from eemoclas.utils.log_formatter import (
    box_footer,
    box_header,
    box_line,
    epoch_separator,
    epoch_title,
    metrics_line,
)
from eemoclas.utils.paths import ensure_dir

logger = logging.getLogger("dglz.training")


class Trainer:
    """Per-model trainer orchestrating the full training lifecycle.

    Parameters
    ----------
    config:
        Full configuration dictionary.  Expected top-level sections:
        ``training``, ``dataset``, ``model``, etc.
    model:
        A ``torch.nn.Module`` to train.
    device:
        The torch device to train on.
    manifest_df:
        Optional manifest DataFrame used to compute automatic class weights
        when ``training.class_weight`` is ``"auto"``.
    verbose:
        When ``True`` enables the Rich live display.  When ``False`` only
        file logging and a silent progress bar are used.

    Attributes
    ----------
    checkpoint_metric:
        Metric key used to decide whether the current model is the best
        (default ``"val_accuracy"``).
    """

    def __init__(
        self,
        config: dict,
        model: nn.Module,
        device: torch.device,
        manifest_df=None,
        verbose: bool = True,
    ) -> None:
        self.config = config
        self.model = model.to(device)
        self.device = device
        self.verbose = verbose
        self.epochs = int(config["training"]["epochs"])
        self.batch_size = int(config["training"]["batch_size"])

        # ---- Resolve early_stop config (nested > legacy flat) ----
        es_cfg = config["training"].get("early_stop", None)
        if isinstance(es_cfg, dict) and es_cfg:
            self._es_enable = es_cfg.get("enable", True)
            es_patience = int(es_cfg.get("patience", 15))
            es_metric = es_cfg.get("early_metric", "val_accuracy")
            es_mode = es_cfg.get("metric_mode", _metric_mode(es_metric))
            es_delta = float(es_cfg.get("up_delta", 1e-6))
        else:
            # Legacy fallback
            self._es_enable = True
            es_patience = int(config["training"].get("early_stopping_patience", 15))
            es_metric = config["training"].get(
                "checkpoint_metric", "val_accuracy"
            )
            es_mode = _metric_mode(es_metric)
            es_delta = 0.0

        self.checkpoint_metric = es_metric  # used for best-model tracking too
        self.early_stopping = EarlyStopping(
            patience=es_patience, mode=es_mode, min_delta=es_delta,
        )

        # ---- Resolve monitor_best config (nested > legacy flat) ----
        mb_cfg = config["training"].get("monitor_best", None)
        if isinstance(mb_cfg, dict) and mb_cfg:
            self._monitor_metric = mb_cfg.get(
                "monitor_metric", self.checkpoint_metric
            )
            self._monitor_mode = mb_cfg.get(
                "metric_mode", _metric_mode(self._monitor_metric)
            )
            self.save_latest = mb_cfg.get("save_latest", True)
            self._save_best_auc = mb_cfg.get("save_best_auc", False)
            self._save_best_acc = mb_cfg.get("save_best_acc", True)
        else:
            # Legacy fallback
            self._monitor_metric = self.checkpoint_metric
            self._monitor_mode = _metric_mode(self._monitor_metric)
            self.save_latest = config["training"].get("save_latest", True)
            self._save_best_auc = False
            self._save_best_acc = config["training"].get("save_best", True)

        # Directories
        self.checkpoint_dir = ensure_dir(
            config.get("checkpoint_dir", "checkpoints")
        )
        self.log_dir = ensure_dir(config.get("log_dir", "logs"))

        # ---- Detect multi-task mode ----
        loss_cfg = config["training"].get("loss", "cross_entropy")
        self._is_multitask = isinstance(loss_cfg, dict)

        # ResultsWriter for CSV + plots
        if self._is_multitask:
            from eemoclas.training.multitask_metrics import MULTITASK_CSV_COLUMNS, MULTITASK_DUAL_LINE_METRICS
            self.results_writer = ResultsWriter(
                self.log_dir,
                columns=MULTITASK_CSV_COLUMNS,
                dual_line_metrics=MULTITASK_DUAL_LINE_METRICS,
            )
        else:
            self.results_writer = ResultsWriter(self.log_dir)

        # Resolve class weights for "auto" mode
        class_weight_cfg = config["training"].get("class_weight", None)
        auto_weights: torch.Tensor | None = None
        if class_weight_cfg == "auto" and manifest_df is not None:
            # Determine the label column name from manifest
            label_col = _detect_label_column(manifest_df)
            auto_weights = compute_class_weights(manifest_df, label_col=label_col)
            if auto_weights is not None:
                auto_weights = auto_weights.to(device)

        if self._is_multitask:
            from eemoclas.training.multitask_loss import MultiTaskLoss
            self.multitask_loss = MultiTaskLoss(config["training"]).to(device)
            self.criterion = None
        else:
            self.multitask_loss = None
            self.criterion = create_criterion(config, class_weights=auto_weights)
        self.optimizer = create_optimizer(self.model, config)
        if self._is_multitask:
            # Add multitask_loss learnable parameters to the optimizer
            mt_params = list(self.multitask_loss.parameters())
            if mt_params:
                self.optimizer.add_param_group({
                    "params": mt_params,
                    **{k: v for k, v in self.optimizer.param_groups[0].items()
                       if k != "params"},
                })
        self.scheduler = create_scheduler(self.optimizer, config)

        # Tracking state
        self.best_metric_value: float = (
            -float("inf") if self._monitor_mode == "max" else float("inf")
        )
        self._metrics_history: list[dict] = []
        self._start_time: float = 0.0

        # Additional best-checkpoint trackers (AUC, ACC)
        self._best_auc_value: float = -float("inf")
        self._best_acc_value: float = -float("inf")
        self._best_metrics_snapshot: dict | None = None

        # ---- Configurable extra best checkpoints ----
        self._extra_best_trackers: list[dict] = []
        for entry in config["training"].get("best_checkpoints", []):
            metric = entry["metric"]
            mode = entry.get("metric_mode", _metric_mode(metric))
            self._extra_best_trackers.append({
                "metric": metric,
                "filename": entry["filename"],
                "mode": mode,
                "best_value": -float("inf") if mode == "max" else float("inf"),
            })

        # ---- Augmentation flags (read from config, applied in train_epoch) ----
        aug_cfg = config.get("augmentation", {})
        self._aug_enabled = aug_cfg.get("enabled", False) if isinstance(aug_cfg, dict) else False
        self._aug_gaussian_std: float = 0.0
        self._aug_time_mask_max_ratio: float = 0.0
        self._aug_channel_drop_prob: float = 0.0
        if self._aug_enabled:
            # Resolve branch config: dual models use nested pp/raw; single models use flat
            branch_cfg = aug_cfg.get("pp", aug_cfg)
            gn = branch_cfg.get("gaussian_noise", {})
            if isinstance(gn, dict) and gn.get("enabled", False):
                self._aug_gaussian_std = float(gn.get("std", 0.01))
            tm = branch_cfg.get("time_mask", {})
            if isinstance(tm, dict) and tm.get("enabled", False):
                self._aug_time_mask_max_ratio = float(tm.get("max_mask_ratio", 0.1))
            cd = branch_cfg.get("channel_dropout", {})
            if isinstance(cd, dict) and cd.get("enabled", False):
                self._aug_channel_drop_prob = float(cd.get("drop_prob", 0.1))

        # ---- Mixup ----
        self._mixup_alpha: float = float(config["training"].get("mixup_alpha", 0.0))

        # ---- Checkpoint interval ----
        self._checkpoint_interval: int = int(
            config["training"].get("checkpoint_interval", 0)
        )

        # ---- Train-only mode (detected at fit() time) ----
        self._train_only: bool = False

        # ---- SWA (Stochastic Weight Averaging) ----
        self._swa_start_epoch: int = int(config["training"].get("swa_start_epoch", 0))
        self._swa_model = None
        self._swa_scheduler = None
        if self._swa_start_epoch > 0:
            from torch.optim.swa_utils import AveragedModel
            self._swa_model = AveragedModel(self.model)
            self._swa_scheduler = torch.optim.swa_utils.SWALR(
                self.optimizer, swa_lr=float(config["training"].get("swa_lr", 0.00005)),
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def train_epoch(self, dataloader: DataLoader, optimizer, criterion) -> dict:
        """Run a single training epoch.

        Parameters
        ----------
        dataloader:
            Training data loader.
        optimizer:
            Optimizer instance.
        criterion:
            Loss function.

        Returns
        -------
        dict
            ``{"loss": float, "accuracy": float}``
        """
        self.model.train()
        total_loss = 0.0
        all_preds: list[np.ndarray] = []
        all_labels: list[np.ndarray] = []
        all_probs: list[np.ndarray] = [] if self._train_only else None  # only collect in train-only mode
        n_batches = 0

        for batch in dataloader:
            # Support (x, y) tuples, dict batches, or raw tensors
            if isinstance(batch, (list, tuple)):
                x, y = batch[0], batch[1]
                token_meta = None
            elif isinstance(batch, dict):
                x = batch["x"]
                y = batch.get("y")
                token_meta = batch.get("token_meta")
            else:
                x, y = batch, None
                token_meta = None

            x = x.to(self.device, non_blocking=True)
            if y is not None:
                y = y.to(self.device, non_blocking=True)
                if y.dim() > 1:
                    y = y.squeeze(-1)

            # ---- Apply on-device augmentations (training only) ----
            if self._aug_enabled:
                x = self._apply_augmentations(x)

            optimizer.zero_grad()
            # Support dual-branch models that accept x_raw
            x_raw = batch.get("x_raw") if isinstance(batch, dict) else None
            if x_raw is not None:
                x_raw = x_raw.to(self.device, non_blocking=True)
            stats_raw = batch.get("stats_raw") if isinstance(batch, dict) else None
            if stats_raw is not None:
                stats_raw = stats_raw.to(self.device, non_blocking=True)
            stats_pp = batch.get("stats_pp") if isinstance(batch, dict) else None
            if stats_pp is not None:
                stats_pp = stats_pp.to(self.device, non_blocking=True)
            logits = self.model(
                x, token_meta=token_meta, x_raw=x_raw,
                stats_raw=stats_raw, stats_pp=stats_pp,
            )

            if y is not None:
                # ---- Mixup loss (mixed labels) ----
                if self._mixup_alpha > 0 and self.model.training:
                    lam = np.random.beta(self._mixup_alpha, self._mixup_alpha)
                    if lam < 0.5:
                        lam = 1 - lam
                    batch_size = x.size(0)
                    index = torch.randperm(batch_size, device=x.device)
                    mixed_logits = lam * logits + (1 - lam) * logits[index].detach()
                    # Use simple label mix: lam * CE(logits, y) + (1-lam) * CE(logits, y[index])
                    loss = lam * criterion(logits, y) + (1 - lam) * criterion(logits, y[index])
                else:
                    loss = criterion(logits, y)
                loss.backward()
                # Gradient clipping
                clip_val = self.config.get("training", {}).get("gradient_clip_val", 0.0)
                if clip_val > 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=clip_val)
                optimizer.step()

                total_loss += loss.item() * x.size(0)
                preds = logits.argmax(dim=1).detach().cpu().numpy()
                labels = y.detach().cpu().numpy()
                all_preds.append(preds)
                all_labels.append(labels)
                if all_probs is not None:
                    probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
                    all_probs.append(probs)
                n_batches += 1

        if n_batches == 0:
            if self._train_only:
                return {"loss": 0.0, "accuracy": 0.0, "macro_f1": 0.0, "auc": 0.0}
            return {"loss": 0.0, "accuracy": 0.0}

        avg_loss = total_loss / sum(p.shape[0] for p in all_preds)
        y_true = np.concatenate(all_labels)
        y_pred = np.concatenate(all_preds)

        if self._train_only:
            y_prob = np.concatenate(all_probs)
            return compute_val_metrics(avg_loss, y_true, y_pred, y_prob)

        return compute_train_metrics(avg_loss, y_true, y_pred)

    def _train_epoch_multitask(self, dataloader: DataLoader, optimizer) -> dict:
        """Run a single training epoch with multi-task loss.

        Adapted from :meth:`train_epoch` for the AllInOne model.  Uses
        ``self.multitask_loss`` instead of a criterion, sigmoid + binary
        thresholding instead of softmax + argmax, and returns per-task
        metrics via :func:`compute_multitask_train_metrics`.

        Parameters
        ----------
        dataloader:
            Training data loader.  Batches must be dicts with keys
            ``"x"``, ``"y"``, ``"group_label"``, ``"trial_emotion_labels"``.
        optimizer:
            Optimizer instance.

        Returns
        -------
        dict
            Keys: ``total_loss``, ``subject_loss``, ``emotion_loss``,
            ``subject_accuracy``, ``emotion_accuracy``.
        """
        from eemoclas.training.multitask_metrics import compute_multitask_train_metrics

        self.model.train()
        total_loss = 0.0
        total_subject_loss = 0.0
        total_emotion_loss = 0.0
        n_samples = 0
        all_group_labels: list[np.ndarray] = []
        all_group_preds: list[np.ndarray] = []
        all_emotion_labels: list[np.ndarray] = []
        all_emotion_preds: list[np.ndarray] = []

        for batch in dataloader:
            x = batch["x"]
            y = batch.get("y")
            token_meta = batch.get("token_meta")

            x = x.to(self.device, non_blocking=True)

            # ---- Apply on-device augmentations (training only) ----
            if self._aug_enabled:
                x = self._apply_augmentations(x)

            optimizer.zero_grad()
            x_raw = batch.get("x_raw")
            if x_raw is not None:
                x_raw = x_raw.to(self.device, non_blocking=True)
            stats_raw = batch.get("stats_raw")
            if stats_raw is not None:
                stats_raw = stats_raw.to(self.device, non_blocking=True)
            stats_pp = batch.get("stats_pp")
            if stats_pp is not None:
                stats_pp = stats_pp.to(self.device, non_blocking=True)
            logits = self.model(
                x, token_meta=token_meta, x_raw=x_raw,
                stats_raw=stats_raw, stats_pp=stats_pp,
            )

            if y is not None:
                targets = {
                    "group_label": batch["group_label"].to(self.device, non_blocking=True).float(),
                    "trial_emotion_labels": batch["trial_emotion_labels"].to(self.device, non_blocking=True).float(),
                }
                loss_dict = self.multitask_loss(logits, targets)
                loss = loss_dict["loss"]
                loss.backward()
                clip_val = self.config.get("training", {}).get("gradient_clip_val", 0.0)
                if clip_val > 0:
                    all_params = list(self.model.parameters()) + list(self.multitask_loss.parameters())
                    torch.nn.utils.clip_grad_norm_(all_params, max_norm=clip_val)
                optimizer.step()

                bs = x.size(0)
                total_loss += loss.item() * bs
                total_subject_loss += loss_dict["subject_loss"].item() * bs
                total_emotion_loss += loss_dict["emotion_loss"].item() * bs

                probs = torch.sigmoid(logits).detach().cpu().numpy()
                preds = (probs > 0.5).astype(int)

                # Subject task: column 0
                all_group_labels.append(batch["group_label"].numpy())
                all_group_preds.append(preds[:, 0])

                # Emotion task: columns 1-8, flattened
                all_emotion_labels.append(batch["trial_emotion_labels"].numpy().reshape(-1))
                all_emotion_preds.append(preds[:, 1:9].reshape(-1))

                n_samples += bs

        if n_samples == 0:
            return {
                "total_loss": 0.0, "subject_loss": 0.0, "emotion_loss": 0.0,
                "subject_accuracy": 0.0, "emotion_accuracy": 0.0,
            }

        avg_total_loss = total_loss / n_samples
        avg_subject_loss = total_subject_loss / n_samples
        avg_emotion_loss = total_emotion_loss / n_samples
        group_labels = np.concatenate(all_group_labels)
        group_preds = np.concatenate(all_group_preds)
        emotion_labels = np.concatenate(all_emotion_labels)
        emotion_preds = np.concatenate(all_emotion_preds)

        return compute_multitask_train_metrics(
            avg_subject_loss, avg_emotion_loss, avg_total_loss,
            group_labels, group_preds,
            emotion_labels, emotion_preds,
        )

    def validate_epoch(self, dataloader: DataLoader, criterion) -> dict:
        """Run a single validation epoch.

        Parameters
        ----------
        dataloader:
            Validation data loader.
        criterion:
            Loss function.

        Returns
        -------
        dict
            ``{"loss": float, "accuracy": float,
              "macro_f1": float, "auc": float | None}``
        """
        self.model.eval()
        total_loss = 0.0
        all_preds: list[np.ndarray] = []
        all_labels: list[np.ndarray] = []
        all_probs: list[np.ndarray] = []
        n_samples = 0

        with torch.no_grad():
            for batch in dataloader:
                if isinstance(batch, (list, tuple)):
                    x, y = batch[0], batch[1]
                    token_meta = None
                elif isinstance(batch, dict):
                    x = batch["x"]
                    y = batch.get("y")
                    token_meta = batch.get("token_meta")
                else:
                    x, y = batch, None
                    token_meta = None

                x = x.to(self.device, non_blocking=True)
                # Support dual-branch models that accept x_raw
                x_raw = batch.get("x_raw") if isinstance(batch, dict) else None
                if x_raw is not None:
                    x_raw = x_raw.to(self.device, non_blocking=True)
                stats_raw = batch.get("stats_raw") if isinstance(batch, dict) else None
                if stats_raw is not None:
                    stats_raw = stats_raw.to(self.device, non_blocking=True)
                stats_pp = batch.get("stats_pp") if isinstance(batch, dict) else None
                if stats_pp is not None:
                    stats_pp = stats_pp.to(self.device, non_blocking=True)
                logits = self.model(
                    x, token_meta=token_meta, x_raw=x_raw,
                    stats_raw=stats_raw, stats_pp=stats_pp,
                )

                if y is not None:
                    y = y.to(self.device, non_blocking=True)
                    if y.dim() > 1:
                        y = y.squeeze(-1)
                    loss = criterion(logits, y)
                    total_loss += loss.item() * x.size(0)

                    probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
                    preds = logits.argmax(dim=1).detach().cpu().numpy()
                    labels = y.detach().cpu().numpy()

                    all_preds.append(preds)
                    all_labels.append(labels)
                    all_probs.append(probs)
                    n_samples += x.size(0)

        if n_samples == 0:
            return {"loss": 0.0, "accuracy": 0.0, "macro_f1": 0.0}

        avg_loss = total_loss / n_samples
        y_true = np.concatenate(all_labels)
        y_pred = np.concatenate(all_preds)
        y_prob = np.concatenate(all_probs)

        return compute_val_metrics(avg_loss, y_true, y_pred, y_prob)

    def _validate_epoch_multitask(self, dataloader: DataLoader) -> dict:
        """Run a single validation epoch with multi-task loss.

        Adapted from :meth:`validate_epoch` for the AllInOne model.
        Uses sigmoid + binary thresholding and returns per-task metrics
        via :func:`compute_multitask_val_metrics`.

        Parameters
        ----------
        dataloader:
            Validation data loader.  Batches must be dicts with keys
            ``"x"``, ``"y"``, ``"group_label"``, ``"trial_emotion_labels"``.

        Returns
        -------
        dict
            Keys include ``total_loss``, ``subject_*`` and ``emotion_*``
            metrics (accuracy, auc, f1, etc.).
        """
        from eemoclas.training.multitask_metrics import compute_multitask_val_metrics

        self.model.eval()
        total_loss = 0.0
        total_subject_loss = 0.0
        total_emotion_loss = 0.0
        n_samples = 0
        all_group_labels: list[np.ndarray] = []
        all_group_preds: list[np.ndarray] = []
        all_group_probs: list[np.ndarray] = []
        all_emotion_labels: list[np.ndarray] = []
        all_emotion_preds: list[np.ndarray] = []
        all_emotion_probs: list[np.ndarray] = []

        with torch.no_grad():
            for batch in dataloader:
                x = batch["x"]
                y = batch.get("y")
                token_meta = batch.get("token_meta")

                x = x.to(self.device, non_blocking=True)
                x_raw = batch.get("x_raw")
                if x_raw is not None:
                    x_raw = x_raw.to(self.device, non_blocking=True)
                stats_raw = batch.get("stats_raw")
                if stats_raw is not None:
                    stats_raw = stats_raw.to(self.device, non_blocking=True)
                stats_pp = batch.get("stats_pp")
                if stats_pp is not None:
                    stats_pp = stats_pp.to(self.device, non_blocking=True)
                logits = self.model(
                    x, token_meta=token_meta, x_raw=x_raw,
                    stats_raw=stats_raw, stats_pp=stats_pp,
                )

                if y is not None:
                    targets = {
                        "group_label": batch["group_label"].to(self.device, non_blocking=True).float(),
                        "trial_emotion_labels": batch["trial_emotion_labels"].to(self.device, non_blocking=True).float(),
                    }
                    loss_dict = self.multitask_loss(logits, targets)
                    bs = x.size(0)
                    total_loss += loss_dict["loss"].item() * bs
                    total_subject_loss += loss_dict["subject_loss"].item() * bs
                    total_emotion_loss += loss_dict["emotion_loss"].item() * bs

                    probs = torch.sigmoid(logits).detach().cpu().numpy()
                    preds = (probs > 0.5).astype(int)

                    # Subject task: column 0
                    all_group_labels.append(batch["group_label"].numpy())
                    all_group_preds.append(preds[:, 0])
                    all_group_probs.append(probs[:, 0])

                    # Emotion task: columns 1-8, flattened
                    all_emotion_labels.append(batch["trial_emotion_labels"].numpy().reshape(-1))
                    all_emotion_preds.append(preds[:, 1:9].reshape(-1))
                    all_emotion_probs.append(probs[:, 1:9].reshape(-1))

                    n_samples += bs

        if n_samples == 0:
            return {
                "total_loss": 0.0, "subject_loss": 0.0, "emotion_loss": 0.0,
                "subject_accuracy": 0.0, "emotion_accuracy": 0.0,
                "subject_auc": 0.0, "emotion_auc": 0.0,
            }

        avg_total_loss = total_loss / n_samples
        avg_subject_loss = total_subject_loss / n_samples
        avg_emotion_loss = total_emotion_loss / n_samples
        group_labels = np.concatenate(all_group_labels)
        group_preds = np.concatenate(all_group_preds)
        group_probs = np.concatenate(all_group_probs)
        emotion_labels = np.concatenate(all_emotion_labels)
        emotion_preds = np.concatenate(all_emotion_preds)
        emotion_probs = np.concatenate(all_emotion_probs)

        return compute_multitask_val_metrics(
            avg_subject_loss, avg_emotion_loss, avg_total_loss,
            group_labels, group_preds, group_probs,
            emotion_labels, emotion_preds, emotion_probs,
        )

    def fit(self, train_loader: DataLoader, val_loader: DataLoader,
            *, resume_path: str | None = None) -> dict:
        """Execute the full training loop.

        For each epoch the following steps are performed:

        1. Train epoch -> train metrics
        2. Validate epoch -> val metrics
        3. Log to file (ASCII box) and terminal (Rich if verbose)
        4. Update progress bar
        5. Check if val metric improved -> save ``best_model.ckpt``
        6. Save ``latest_model.ckpt``
        7. Check early stopping
        8. Append to ``metrics_history.csv``

        Parameters
        ----------
        train_loader:
            DataLoader for the training split.
        val_loader:
            DataLoader for the validation split.

        Returns
        -------
        dict
            Training summary with keys ``epochs_trained``,
            ``best_epoch``, ``best_metrics``, ``total_time_seconds``,
            ``early_stopped``.
        """
        self._start_time = time.time()
        display = self._create_display()
        best_epoch = 0
        best_metrics: dict = {}
        early_stopped = False

        # ---- Detect train-only mode (empty val_loader) ----
        self._train_only = (
            hasattr(val_loader, "dataset")
            and len(val_loader.dataset) == 0
        )
        if self._train_only:
            if self.verbose:
                logger.info("Train-only mode: no validation set, using train metrics for monitoring.")
            self.results_writer.set_train_only(True)

        # --- Resume from checkpoint if provided ---
        start_epoch = 1
        combined: dict = {}
        if resume_path:
            info = self.resume_from_checkpoint(resume_path)
            start_epoch = info["epoch"] + 1
            # Restore early stopping state
            if info.get("early_stopping_state"):
                self.early_stopping.load_state_dict(info["early_stopping_state"])
            # Restore scheduler state
            if info.get("scheduler_state_dict") and self.scheduler is not None:
                self.scheduler.load_state_dict(info["scheduler_state_dict"])
            # Load history into ResultsWriter for plot continuity
            if info.get("history"):
                self.results_writer.load_history(info["history"])
            self.results_writer.verify_consistency(info["epoch"])
            logger.info(
                "=== Training resumed from epoch %d ===", start_epoch,
            )
        else:
            logger.info("=== Training started ===")

        try:
            if display is not None:
                display.start()

            for epoch in range(start_epoch, self.epochs + 1):
                epoch_start = time.time()

                # 1. Train
                if self._is_multitask:
                    train_metrics = self._train_epoch_multitask(train_loader, self.optimizer)
                else:
                    train_metrics = self.train_epoch(train_loader, self.optimizer, self.criterion)

                # 2. Validate (or skip in train-only mode)
                if self._train_only:
                    val_metrics = {}
                elif self._is_multitask:
                    val_metrics = self._validate_epoch_multitask(val_loader)
                else:
                    val_metrics = self.validate_epoch(val_loader, self.criterion)

                # 3. Step scheduler / SWA
                if self._swa_start_epoch > 0 and epoch >= self._swa_start_epoch:
                    self._swa_model.update_parameters(self.model)
                    self._swa_scheduler.step()
                elif self.scheduler is not None:
                    if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                        raw_key = self.checkpoint_metric.replace("val_", "")
                        if self._train_only:
                            monitor_val = train_metrics.get(raw_key, train_metrics.get("loss", 0.0))
                        else:
                            monitor_val = val_metrics.get(raw_key, val_metrics.get("loss", 0.0))
                        self.scheduler.step(monitor_val)
                    else:
                        self.scheduler.step()

                # 4. Merge metrics for logging
                if self._is_multitask:
                    combined = {}
                    for k, v in train_metrics.items():
                        combined[f"train_{k}"] = v
                    for k, v in val_metrics.items():
                        combined[f"val_{k}"] = v
                else:
                    combined = {f"train_{k}": v for k, v in train_metrics.items()}
                    combined.update({f"val_{k}": v for k, v in val_metrics.items()})
                combined["epoch"] = epoch
                combined["lr"] = self.optimizer.param_groups[0]["lr"]
                combined["time_s"] = round(time.time() - epoch_start, 2)
                combined["epoch_time"] = combined["time_s"]

                # 5. Log to file
                self._log_epoch(epoch, train_metrics, val_metrics, combined)

                # 6. Check best (primary monitor_metric with multi-metric tiebreaker)
                monitor_key = self._resolve_monitor_key(self._monitor_metric)
                current_score = combined.get(
                    monitor_key,
                    combined.get("val_loss", combined.get("train_loss", 0.0)),
                )
                is_best = self._is_better_with_tiebreak(
                    combined, self._best_metrics_snapshot,
                    self._monitor_metric, self._monitor_mode,
                )
                if is_best:
                    self.best_metric_value = current_score
                    best_epoch = epoch
                    best_metrics = copy_metrics(combined)
                    self._best_metrics_snapshot = best_metrics
                    save_checkpoint(
                        self.model,
                        self.optimizer,
                        epoch,
                        best_metrics,
                        self.config,
                        self.checkpoint_dir / "best_model.ckpt",
                        scheduler=self.scheduler,
                        history=list(self.results_writer._history),
                        best_values={"primary": self.best_metric_value},
                        early_stopping_state=self.early_stopping.state_dict(),
                    )
                    logger.info("New best model at epoch %d (%s=%.4f)", epoch, monitor_key, current_score)

                # 6b. Additional best checkpoints (AUC, ACC)
                if self._save_best_auc:
                    auc_key = self._resolve_monitor_key("val_auc")
                    auc_val = combined.get(auc_key, None)
                    auc_suffix = "train_auc" if self._train_only else "val_auc"
                    if auc_val is not None and auc_val > self._best_auc_value:
                        self._best_auc_value = auc_val
                        save_checkpoint(
                            self.model, self.optimizer, epoch,
                            copy_metrics(combined), self.config,
                            self.checkpoint_dir / f"best_{auc_suffix}.ckpt",
                            scheduler=self.scheduler,
                            history=list(self.results_writer._history),
                            best_values={"primary": self.best_metric_value},
                            early_stopping_state=self.early_stopping.state_dict(),
                        )
                        logger.info("New best AUC at epoch %d (%s=%.4f)", epoch, auc_suffix, auc_val)

                if self._save_best_acc:
                    acc_key = self._resolve_monitor_key("val_accuracy")
                    acc_val = combined.get(acc_key, None)
                    acc_suffix = "train_accuracy" if self._train_only else "val_accuracy"
                    if acc_val is not None and acc_val > self._best_acc_value:
                        self._best_acc_value = acc_val
                        # Avoid duplicate save if same as primary monitor
                        if acc_key != monitor_key or not is_best:
                            save_checkpoint(
                                self.model, self.optimizer, epoch,
                                copy_metrics(combined), self.config,
                                self.checkpoint_dir / f"best_{acc_suffix}.ckpt",
                                scheduler=self.scheduler,
                                history=list(self.results_writer._history),
                                best_values={"primary": self.best_metric_value},
                                early_stopping_state=self.early_stopping.state_dict(),
                            )
                        logger.info("New best accuracy at epoch %d (%s=%.4f)", epoch, acc_suffix, acc_val)

                # 6c. Configurable extra best checkpoints
                for tracker in self._extra_best_trackers:
                    val = combined.get(tracker["metric"])
                    if val is None:
                        continue
                    is_better = (
                        val > tracker["best_value"]
                        if tracker["mode"] == "max"
                        else val < tracker["best_value"]
                    )
                    if is_better:
                        tracker["best_value"] = val
                        save_checkpoint(
                            self.model, self.optimizer, epoch,
                            copy_metrics(combined), self.config,
                            self.checkpoint_dir / tracker["filename"],
                            scheduler=self.scheduler,
                            history=list(self.results_writer._history),
                            best_values={"primary": self.best_metric_value},
                            early_stopping_state=self.early_stopping.state_dict(),
                        )
                        logger.info(
                            "New best %s at epoch %d (%.4f)",
                            tracker["metric"], epoch, val,
                        )

                # 7. Save latest
                if self.save_latest:
                    save_checkpoint(
                        self.model,
                        self.optimizer,
                        epoch,
                        combined,
                        self.config,
                        self.checkpoint_dir / "latest_model.ckpt",
                        scheduler=self.scheduler,
                        history=list(self.results_writer._history),
                        best_values={"primary": self.best_metric_value},
                        early_stopping_state=self.early_stopping.state_dict(),
                    )

                # 7b. Periodic checkpoint snapshot
                if self._checkpoint_interval > 0 and epoch % self._checkpoint_interval == 0:
                    save_checkpoint(
                        self.model, self.optimizer, epoch,
                        copy_metrics(combined), self.config,
                        self.checkpoint_dir / f"epoch_{epoch:03d}.ckpt",
                        scheduler=self.scheduler,
                        history=list(self.results_writer._history),
                        best_values={"primary": self.best_metric_value},
                        early_stopping_state=self.early_stopping.state_dict(),
                    )

                # 8. Append to CSV + trigger background plot generation
                self.results_writer.append_epoch(combined)

                # 9. Update display
                if display is not None:
                    display.update(epoch, metrics=combined)

                # 10. Early stopping
                if self._es_enable:
                    es_key = self._resolve_monitor_key(self.checkpoint_metric)
                    es_score = combined.get(es_key, current_score)
                    if self.early_stopping.step(es_score):
                        early_stopped = True
                        logger.info("Early stopping at epoch %d.", epoch)
                        break

        except KeyboardInterrupt:
            logger.warning(
                "Training interrupted by user at epoch %d. Saving state...", epoch,
            )
            if combined:
                save_checkpoint(
                    self.model, self.optimizer, epoch, combined, self.config,
                    self.checkpoint_dir / "latest_model.ckpt",
                    scheduler=self.scheduler,
                    history=list(self.results_writer._history),
                    best_values={"primary": self.best_metric_value},
                    early_stopping_state=self.early_stopping.state_dict(),
                )
            self.results_writer.finalize()
            early_stopped = True
        finally:
            if display is not None:
                display.stop()

        # SWA: update batch norm statistics with averaged model
        if self._swa_start_epoch > 0 and self._swa_model is not None:
            logger.info("Updating SWA batch norm statistics...")
            torch.optim.swa_utils.update_bn(train_loader, self._swa_model, device=self.device)
            # Copy SWA weights back to the main model for checkpointing
            self.model.load_state_dict(
                {k: v for k, v in self._swa_model.module.state_dict().items()},
            )
            logger.info("SWA weights applied to model.")

        # Finalize: wait for background plot generation
        self.results_writer.finalize()

        total_time = round(time.time() - self._start_time, 2)

        summary = {
            "epochs_trained": epoch,
            "best_epoch": best_epoch,
            "best_metrics": best_metrics,
            "total_time_seconds": total_time,
            "early_stopped": early_stopped,
        }

        logger.info(
            "Training complete: %d epochs, best epoch=%d, time=%.1fs",
            epoch,
            best_epoch,
            total_time,
        )

        return summary

    def resume_from_checkpoint(self, path: str | Path) -> dict:
        """Resume training state from a checkpoint.

        Parameters
        ----------
        path:
            Path to a ``.ckpt`` file.

        Returns
        -------
        dict
            Full checkpoint info including epoch, metrics, scheduler_state_dict,
            history, early_stopping_state.
        """
        info = load_checkpoint(path, self.model, device=self.device)

        # Restore optimizer state
        ckpt = torch.load(str(Path(path)), map_location=self.device, weights_only=False)
        if "optimizer_state_dict" in ckpt:
            self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])

        # Reset early stopping best score if metrics are available
        metrics = info.get("metrics", {})
        monitor_key = self.checkpoint_metric
        if monitor_key in metrics:
            self.best_metric_value = metrics[monitor_key]
            self._best_metrics_snapshot = metrics

        logger.info("Resumed from checkpoint at epoch %d.", info["epoch"])
        return info

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _create_display(self):
        """Instantiate the appropriate display (Rich or silent)."""
        try:
            if self.verbose:
                from eemoclas.utils.verbose_display import VerboseLiveDisplay
                return VerboseLiveDisplay(total_epochs=self.epochs, description="Training")
            else:
                from eemoclas.utils.verbose_display import SilentProgressBar
                return SilentProgressBar(total_epochs=self.epochs, description="Training")
        except Exception:
            logger.debug("Rich display unavailable; falling back to log-only mode.")
            return None

    def _log_epoch(
        self,
        epoch: int,
        train_metrics: dict,
        val_metrics: dict,
        combined: dict,
    ) -> None:
        """Write an epoch's results to the log file.

        Uses a compact single-line format per epoch for easy parsing and
        grep-ability, similar to JwzTumor's epoch log style.
        """
        from eemoclas.utils.verbose_display import _fmt_value

        # Format metrics as "key=value" pairs
        train_parts = [
            f"{k}={_fmt_value(k, v)}" for k, v in train_metrics.items() if isinstance(v, (int, float))
        ]
        val_parts = [
            f"{k}={_fmt_value(k, v)}" for k, v in val_metrics.items() if isinstance(v, (int, float))
        ]

        lr = combined.get("lr", 0.0)
        lr_str = _fmt_value("lr", lr)
        time_s = combined.get("time_s", 0.0)

        if self._train_only:
            logger.info(
                "[Epoch %d/%d]  train: %s | lr=%s | time=%.1fs",
                epoch,
                self.epochs,
                " | ".join(train_parts) if train_parts else "N/A",
                lr_str,
                time_s,
            )
        else:
            logger.info(
                "[Epoch %d/%d]  train: %s | val: %s | lr=%s | time=%.1fs",
                epoch,
                self.epochs,
                " | ".join(train_parts) if train_parts else "N/A",
                " | ".join(val_parts) if val_parts else "N/A",
                lr_str,
                time_s,
            )

        # Log checkpoint metric if improved
        monitor_key = self._resolve_monitor_key(self.checkpoint_metric)
        if monitor_key in combined:
            val = combined[monitor_key]
            logger.info(
                "  monitor (%s): %s",
                monitor_key,
                _fmt_value(monitor_key, val),
            )

    def _is_improvement(self, score: float, *, mode: str | None = None) -> bool:
        """Check whether *score* improves the tracked best."""
        mode = mode or _metric_mode(self._monitor_metric)
        if mode == "max":
            return score > self.best_metric_value
        else:
            return score < self.best_metric_value

    def _resolve_monitor_key(self, key: str) -> str:
        """Remap val_* keys to train_* in train-only mode."""
        if self._train_only and key.startswith("val_"):
            return key.replace("val_", "train_", 1)
        return key

    def _is_better_with_tiebreak(
        self,
        current: dict,
        best: dict | None,
        primary_key: str,
        mode: str,
    ) -> bool:
        """Check whether *current* epoch metrics beat *best* using multi-metric tiebreaker.

        When the primary metric is strictly better → True.
        When strictly worse → False.
        When tied, break via: val_auc → val_macro_f1 → train_accuracy → prefer newer.

        Parameters
        ----------
        current : dict
            Current epoch's full metrics dict.
        best : dict | None
            Previous best epoch's full metrics dict.  ``None`` means first epoch.
        primary_key : str
            Metric name used as the primary criterion.
        mode : str
            ``"max"`` (higher is better) or ``"min"`` (lower is better).

        Returns
        -------
        bool
            ``True`` when *current* should replace the stored best.
        """
        def _cmp(cur_val, best_val, m):
            """Return 1 if cur is better, -1 if worse, 0 if tied."""
            if m == "max":
                if cur_val > best_val:
                    return 1
                if cur_val < best_val:
                    return -1
            else:
                if cur_val < best_val:
                    return 1
                if cur_val > best_val:
                    return -1
            return 0

        cur_primary = current.get(primary_key)
        if cur_primary is None:
            return False

        # First epoch → always best
        if best is None:
            return True

        best_primary = best.get(primary_key)
        if best_primary is None:
            return True

        # 1. Primary metric comparison
        cmp = _cmp(cur_primary, best_primary, mode)
        if cmp > 0:
            return True
        if cmp < 0:
            return False

        # Primary tied — walk the tiebreaker chain
        if self._train_only:
            tiebreaker_keys: list[tuple[str, str]] = [
                ("train_auc", "max"),
                ("train_macro_f1", "max"),
                ("train_accuracy", "max"),
            ]
        else:
            tiebreaker_keys = [
                ("val_auc", "max"),
                ("val_macro_f1", "max"),
                ("train_accuracy", "max"),
            ]
        for key, key_mode in tiebreaker_keys:
            cur_val = current.get(key)
            best_val = best.get(key)
            if cur_val is None or best_val is None:
                continue
            cmp = _cmp(float(cur_val), float(best_val), key_mode)
            if cmp > 0:
                return True
            if cmp < 0:
                return False

        # All tiebreakers equal → prefer newer epoch
        return True

    def _apply_augmentations(self, x: torch.Tensor) -> torch.Tensor:
        """Apply configured on-device augmentations to a training batch.

        Applied after x.to(device), before model forward pass.
        Each augmentation is applied independently per batch.
        """
        # GaussianNoise
        if self._aug_gaussian_std > 0:
            x = x + torch.randn_like(x) * self._aug_gaussian_std

        # TimeMask: mask a contiguous region on the last dimension (time axis)
        if self._aug_time_mask_max_ratio > 0:
            mask_ratio = random.uniform(0, self._aug_time_mask_max_ratio)
            if mask_ratio > 0:
                T = x.shape[-1]
                mask_len = max(1, int(T * mask_ratio))
                start = random.randint(0, T - mask_len)
                x[..., start:start + mask_len] = 0

        # ChannelDropout: zero out entire channels on dim=-2
        if self._aug_channel_drop_prob > 0:
            C = x.shape[-2]
            mask = (torch.rand(C) > self._aug_channel_drop_prob).to(x.device)
            x = x * mask.view(*([1] * (x.dim() - 2)), C, 1)

        return x


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------

def _metric_mode(metric_name: str) -> str:
    """Determine whether a metric should be maximised or minimised.

    Returns ``"max"`` for accuracy / AUC / F1-type metrics and ``"min"``
    for loss-type metrics.
    """
    loss_keywords = ("loss",)
    lower = metric_name.lower()
    for kw in loss_keywords:
        if kw in lower:
            return "min"
    return "max"


def _detect_label_column(manifest_df) -> str:
    """Detect the label column name in a manifest DataFrame.

    Checks for common names in order: ``"y"``, ``"label"``,
    ``"emotion_label"``, ``"group_label"``.
    """
    candidates = ["y", "label", "emotion_label", "group_label"]
    for col in candidates:
        if col in manifest_df.columns:
            return col
    # Fall back to the last column
    return manifest_df.columns[-1]


def copy_metrics(d: dict) -> dict:
    """Deep-copy a metrics dictionary."""
    import copy
    return copy.deepcopy(d)
