"""Rich terminal display and CSV export for evaluation metrics."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from eemoclas.metrics.evaluator import EvaluationResult


def print_metrics(
    result: EvaluationResult,
    title: str,
    console: Console | None = None,
) -> None:
    if console is None:
        from eemoclas.cli.utils import console as default_console
        console = default_console

    table = Table(show_header=True, border_style="cyan", expand=False)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    table.add_row("Accuracy", f"{result.accuracy:.4f}")
    table.add_row("AUC", f"{result.auc:.4f}" if result.auc is not None else "N/A")
    table.add_row("Macro F1", f"{result.macro_f1:.4f}")
    table.add_row("Samples", str(result.n_samples))

    console.print(Panel(table, title=title, border_style="green", expand=False))


def save_metrics_csv(
    result: EvaluationResult,
    path: str,
    label: str = "",
    append: bool = False,
) -> None:
    row = {
        "label": label,
        "accuracy": result.accuracy,
        "auc": result.auc if result.auc is not None else "",
        "macro_f1": result.macro_f1,
        "n_samples": result.n_samples,
    }
    df = pd.DataFrame([row])

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    if append and p.exists():
        existing = pd.read_csv(p)
        df = pd.concat([existing, df], ignore_index=True)

    df.to_csv(p, index=False)
