"""Evaluation metrics for inference results."""

from eemoclas.metrics.evaluator import EvaluationResult, evaluate
from eemoclas.metrics.ground_truth import resolve_ground_truth

__all__ = ["EvaluationResult", "evaluate", "resolve_ground_truth"]
