"""Binary classification evaluation metrics."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


@dataclass(frozen=True)
class EvaluationResult:
    accuracy: float
    auc: float | None
    macro_f1: float
    n_samples: int


def evaluate(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray | None = None,
) -> EvaluationResult:
    if len(y_true) != len(y_pred):
        raise ValueError(
            f"y_true length ({len(y_true)}) != y_pred length ({len(y_pred)})"
        )
    n = len(y_true)
    acc = float(accuracy_score(y_true, y_pred))
    f1 = float(f1_score(y_true, y_pred, average="macro", zero_division=0.0, labels=[0, 1]))
    auc: float | None = None
    if y_prob is not None:
        if len(np.unique(y_true)) > 1:
            auc = float(roc_auc_score(y_true, y_prob))
    return EvaluationResult(accuracy=acc, auc=auc, macro_f1=f1, n_samples=n)
