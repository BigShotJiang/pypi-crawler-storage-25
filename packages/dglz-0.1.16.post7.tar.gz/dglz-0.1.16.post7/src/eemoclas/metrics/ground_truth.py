"""Resolve ground truth labels for evaluation."""

from __future__ import annotations

import pandas as pd


def resolve_ground_truth(
    predictions_df: pd.DataFrame,
    manifest_df: pd.DataFrame | None = None,
    ground_truth_path: str | None = None,
    label_column: str | None = None,
) -> pd.Series | None:
    # 1. External ground truth CSV
    if ground_truth_path is not None:
        gt_df = pd.read_csv(ground_truth_path)
        if label_column is None or label_column not in gt_df.columns:
            return None
        if "sample_id" in gt_df.columns and "sample_id" in predictions_df.columns:
            merged = predictions_df.merge(gt_df[["sample_id", label_column]], on="sample_id", how="left")
            series = merged[label_column]
            if series.isna().any():
                return None
            return series
        if "subject_id" in gt_df.columns and "subject_id" in predictions_df.columns:
            merged = predictions_df.merge(gt_df[["subject_id", label_column]], on="subject_id", how="left")
            series = merged[label_column]
            if series.isna().any():
                return None
            return series
        # Row-aligned fallback
        if len(gt_df) == len(predictions_df):
            return gt_df[label_column]
        return None

    # 2. From manifest
    if manifest_df is not None and label_column is not None:
        if label_column not in manifest_df.columns:
            return None
        if "sample_id" in predictions_df.columns and "sample_id" in manifest_df.columns:
            merged = predictions_df.merge(manifest_df[["sample_id", label_column]], on="sample_id", how="left")
            series = merged[label_column]
            if series.isna().any():
                return None
            return series
        if "subject_id" in predictions_df.columns and "subject_id" in manifest_df.columns:
            merged = predictions_df.merge(manifest_df[["subject_id", label_column]], on="subject_id", how="left")
            series = merged[label_column]
            if series.isna().any():
                return None
            return series

    return None
