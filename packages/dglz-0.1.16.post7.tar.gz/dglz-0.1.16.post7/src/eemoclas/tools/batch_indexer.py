"""Batch indexer -- extract subsets from a resampled manifest CSV.

Generates batch CSV files (manifest subsets) for incremental training.

Supports three modes:
  - ``random``: pure random shuffle (original behaviour).
  - ``subject``: subject-isolated -- all samples from the same subject
    stay in the same batch.
  - ``stratified_subject``: subject-isolated + group_label stratification
    -- each batch maintains approximately the same positive/negative ratio.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Mode: random (original)
# ---------------------------------------------------------------------------

def create_batch_indexes(
    manifest_path: str,
    output_dir: str,
    batch_sizes: list[int],
    seed: int | None = None,
    prefix: str = "batch",
) -> dict:
    """从 manifest CSV 不放回抽取，生成 batch 索引文件。

    Parameters
    ----------
    manifest_path:
        输入 manifest.csv 文件路径。
    output_dir:
        输出目录（不存在则创建）。
    batch_sizes:
        每个 batch 的样本数量列表。长度决定 batch 数量。
    seed:
        随机种子，确保可复现。None 时不设种子。
    prefix:
        输出文件前缀，默认 "batch"。

    Returns
    -------
    dict
        抽取摘要信息（total_samples, num_batches, batch_sizes, remainder_size, ...）。
    """
    manifest_path = Path(manifest_path)
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    df = pd.read_csv(manifest_path)
    total = len(df)

    _validate_batch_sizes(batch_sizes, total)

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(seed)
    indices = np.arange(total)
    rng.shuffle(indices)

    output_files: list[str] = []
    offset = 0

    for i, size in enumerate(batch_sizes):
        batch_indices = indices[offset : offset + size]
        batch_df = df.iloc[batch_indices].reset_index(drop=True)
        filename = f"{prefix}_{i + 1:03d}.csv"
        batch_df.to_csv(out / filename, index=False)
        output_files.append(filename)
        offset += size

    # Remainder
    remainder_size = total - offset
    if remainder_size > 0:
        rem_indices = indices[offset:]
        rem_df = df.iloc[rem_indices].reset_index(drop=True)
        rem_filename = "remainder.csv"
        rem_df.to_csv(out / rem_filename, index=False)
        output_files.append(rem_filename)

    result = {
        "mode": "random",
        "source_manifest": str(manifest_path),
        "total_samples": total,
        "num_batches": len(batch_sizes),
        "batch_sizes": batch_sizes,
        "remainder_size": remainder_size,
        "seed": seed,
        "output_files": output_files,
    }

    with open(out / "batch_summary.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result


# ---------------------------------------------------------------------------
# Mode: subject (subject-isolated)
# ---------------------------------------------------------------------------

def create_batch_indexes_subject(
    manifest_path: str,
    output_dir: str,
    batch_sizes: list[int],
    seed: int | None = None,
    prefix: str = "batch",
) -> dict:
    """Subject-isolated batch splitting.

    All samples from the same ``subject_id`` are guaranteed to be in the
    same batch.  Subjects are greedily assigned to batches using a
    best-fit-decreasing strategy (sort by sample count descending, assign
    to batch with most remaining capacity).
    """
    manifest_path = Path(manifest_path)
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    df = pd.read_csv(manifest_path)
    _validate_batch_sizes(batch_sizes, len(df))
    _require_column(df, "subject_id")

    rng = np.random.default_rng(seed)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # Group by subject_id → (sample_count, row_indices)
    subject_groups = _build_subject_groups(df)

    # Assign subjects to batches (greedy best-fit-decreasing)
    assignment = _assign_subjects_greedy(
        subject_groups, batch_sizes, rng,
    )

    # Write batch CSVs
    output_files, batch_actual_sizes, batch_subject_counts = (
        _write_subject_batches(df, assignment, batch_sizes, prefix, out)
    )

    total = len(df)
    allocated = sum(batch_actual_sizes)
    remainder_size = total - allocated

    # Remainder: subjects not assigned to any batch
    if remainder_size > 0:
        assigned_indices = set()
        for indices_list in assignment.values():
            for idx_list in indices_list:
                assigned_indices.update(idx_list)
        rem_df = df.drop(list(assigned_indices)).reset_index(drop=True)
        if len(rem_df) > 0:
            rem_df.to_csv(out / "remainder.csv", index=False)
            output_files.append("remainder.csv")

    result = {
        "mode": "subject",
        "source_manifest": str(manifest_path),
        "total_samples": total,
        "num_batches": len(batch_sizes),
        "batch_sizes": batch_sizes,
        "batch_actual_sizes": batch_actual_sizes,
        "batch_subject_counts": batch_subject_counts,
        "remainder_size": remainder_size,
        "seed": seed,
        "output_files": output_files,
    }

    with open(out / "batch_summary.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result


# ---------------------------------------------------------------------------
# Mode: stratified_subject (subject-isolated + group_label stratified)
# ---------------------------------------------------------------------------

def create_batch_indexes_stratified(
    manifest_path: str,
    output_dir: str,
    batch_sizes: list[int],
    seed: int | None = None,
    prefix: str = "batch",
) -> dict:
    """Subject-isolated + stratified batch splitting.

    Like ``create_batch_indexes_subject`` but additionally ensures that
    each batch maintains approximately the same ``group_label`` ratio as
    the full dataset.  Subjects within each label stratum are assigned
    independently to balance label counts per batch.
    """
    manifest_path = Path(manifest_path)
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    df = pd.read_csv(manifest_path)
    _validate_batch_sizes(batch_sizes, len(df))
    _require_column(df, "subject_id")
    _require_column(df, "group_label")

    rng = np.random.default_rng(seed)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    total = len(df)
    num_batches = len(batch_sizes)

    # Build subject groups
    subject_groups = _build_subject_groups(df)

    # Get group_label per subject (from first row)
    subject_labels = (
        df.groupby("subject_id", sort=False)["group_label"].first().to_dict()
    )

    # Separate subjects by label
    strata: dict[int, list[str]] = {}
    for sid, label in subject_labels.items():
        strata.setdefault(int(label), []).append(sid)

    # For each stratum, calculate per-batch target sample count
    stratum_totals: dict[int, int] = {}
    for label, sids in strata.items():
        stratum_totals[label] = sum(len(subject_groups[sid]) for sid in sids)

    # Per-stratum per-batch targets (proportional)
    stratum_batch_targets: dict[int, list[int]] = {}
    for label, stratum_total in stratum_totals.items():
        ratio = stratum_total / total
        targets = [max(1, round(size * ratio)) for size in batch_sizes]
        stratum_batch_targets[label] = targets

    # Greedy assignment per stratum
    # batch_remaining[label][batch_idx] = remaining capacity for this label
    batch_remaining: dict[int, list[int]] = {
        label: list(targets) for label, targets in stratum_batch_targets.items()
    }

    # assignment: batch_idx → list of list of row indices
    assignment: dict[int, list[list[int]]] = {i: [] for i in range(num_batches)}
    batch_sample_count = [0] * num_batches

    for label, sids in strata.items():
        # Shuffle subjects within stratum
        sid_list = list(sids)
        rng.shuffle(sid_list)

        # Sort by sample count descending for better packing
        sid_list.sort(key=lambda s: len(subject_groups[s]), reverse=True)

        for sid in sid_list:
            sample_count = len(subject_groups[sid])

            # Find batch with most remaining capacity for this label
            best_batch = -1
            best_remaining = -1
            for bi in range(num_batches):
                remaining = batch_remaining[label][bi]
                if remaining >= sample_count and remaining > best_remaining:
                    best_remaining = remaining
                    best_batch = bi

            # If no batch has enough remaining capacity, use the one with most room
            if best_batch == -1:
                best_batch = int(np.argmax(batch_remaining[label]))

            assignment[best_batch].append(subject_groups[sid])
            batch_remaining[label][best_batch] -= sample_count
            batch_sample_count[best_batch] += sample_count

    # Write batch CSVs
    output_files, batch_actual_sizes, batch_subject_counts = (
        _write_subject_batches(df, assignment, batch_sizes, prefix, out)
    )

    # Label distribution per batch
    batch_label_distribution: list[dict[str, int]] = []
    for bi in range(num_batches):
        label_counts: dict[str, int] = {}
        for row_indices in assignment[bi]:
            for idx in row_indices:
                gl = int(df.iloc[idx]["group_label"])
                key = f"group_{gl}"
                label_counts[key] = label_counts.get(key, 0) + 1
        batch_label_distribution.append(label_counts)

    allocated = sum(batch_actual_sizes)
    remainder_size = total - allocated

    # Remainder
    if remainder_size > 0:
        assigned_indices = set()
        for indices_list in assignment.values():
            for idx_list in indices_list:
                assigned_indices.update(idx_list)
        rem_df = df.drop(list(assigned_indices)).reset_index(drop=True)
        if len(rem_df) > 0:
            rem_df.to_csv(out / "remainder.csv", index=False)
            output_files.append("remainder.csv")

    result = {
        "mode": "stratified_subject",
        "source_manifest": str(manifest_path),
        "total_samples": total,
        "num_batches": num_batches,
        "batch_sizes": batch_sizes,
        "batch_actual_sizes": batch_actual_sizes,
        "batch_subject_counts": batch_subject_counts,
        "batch_label_distribution": batch_label_distribution,
        "remainder_size": remainder_size,
        "seed": seed,
        "output_files": output_files,
    }

    with open(out / "batch_summary.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result


# ---------------------------------------------------------------------------
# Ratio → batch_sizes conversion
# ---------------------------------------------------------------------------

def ratios_to_batch_sizes(total: int, ratios: list[float]) -> list[int]:
    """Convert a list of ratios to absolute batch sizes.

    Handles rounding to ensure sizes sum to ≤ total.

    Parameters
    ----------
    total : int
        Total number of samples.
    ratios : list[float]
        Ratios (e.g. [0.6, 0.2, 0.2]).  Sum should be ≤ 1.0.

    Returns
    -------
    list[int]
        Absolute batch sizes.
    """
    ratio_sum = sum(ratios)
    if ratio_sum <= 0 or ratio_sum > 1.0 + 1e-9:
        raise ValueError(
            f"ratios must sum to (0, 1.0], got {ratio_sum:.4f}"
        )

    # Calculate raw sizes
    sizes = [int(total * r) for r in ratios]

    # Ensure each size is at least 1 (if ratio > 0)
    for i in range(len(sizes)):
        if ratios[i] > 0 and sizes[i] == 0:
            sizes[i] = 1

    # Adjust if sum exceeds total
    while sum(sizes) > total:
        # Reduce the largest batch
        max_idx = int(np.argmax(sizes))
        sizes[max_idx] -= 1

    return sizes


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_batch_sizes(batch_sizes: list[int], total: int) -> None:
    """Validate batch_sizes list."""
    if not batch_sizes:
        raise ValueError("batch_sizes must not be empty")
    for i, sz in enumerate(batch_sizes):
        if sz <= 0:
            raise ValueError(f"batch_sizes[{i}] must be > 0, got {sz}")
    if sum(batch_sizes) > total:
        raise ValueError(
            f"batch sizes sum ({sum(batch_sizes)}) exceeds total samples ({total})"
        )


def _require_column(df: pd.DataFrame, col: str) -> None:
    """Raise ValueError if col is not in df."""
    if col not in df.columns:
        raise ValueError(
            f"Manifest missing required column '{col}'. "
            f"Available: {list(df.columns)}"
        )


def _build_subject_groups(df: pd.DataFrame) -> dict[str, list[int]]:
    """Build mapping: subject_id → list of positional row indices."""
    groups: dict[str, list[int]] = {}
    for idx, row in df.iterrows():
        sid = str(row["subject_id"])
        groups.setdefault(sid, []).append(idx)
    return groups


def _assign_subjects_greedy(
    subject_groups: dict[str, list[int]],
    batch_sizes: list[int],
    rng: np.random.Generator,
) -> dict[int, list[list[int]]]:
    """Greedy best-fit-decreasing subject → batch assignment.

    Sort subjects by sample count descending, assign each to the batch
    with the most remaining capacity that can still fit the subject.

    Returns dict: batch_idx → list of row-index-lists (one per subject).
    """
    num_batches = len(batch_sizes)
    remaining = list(batch_sizes)  # mutable remaining capacity per batch
    assignment: dict[int, list[list[int]]] = {i: [] for i in range(num_batches)}

    # Sort subjects by sample count descending (better bin packing)
    sorted_subjects = sorted(
        subject_groups.keys(),
        key=lambda s: len(subject_groups[s]),
        reverse=True,
    )

    # Shuffle within same-size groups for randomness
    # (just shuffle first, then stable sort by count desc)
    sid_list = list(sorted_subjects)
    rng.shuffle(sid_list)
    sid_list.sort(key=lambda s: len(subject_groups[s]), reverse=True)

    for sid in sid_list:
        indices = subject_groups[sid]
        count = len(indices)

        # Find batch with most remaining capacity that fits
        best_batch = -1
        best_rem = -1
        for bi in range(num_batches):
            if remaining[bi] >= count and remaining[bi] > best_rem:
                best_rem = remaining[bi]
                best_batch = bi

        # If no batch fits, use the one with most capacity anyway
        if best_batch == -1:
            best_batch = int(np.argmax(remaining))

        assignment[best_batch].append(indices)
        remaining[best_batch] -= count

    return assignment


def _write_subject_batches(
    df: pd.DataFrame,
    assignment: dict[int, list[list[int]]],
    batch_sizes: list[int],
    prefix: str,
    out: Path,
) -> tuple[list[str], list[int], list[int]]:
    """Write batch CSVs from subject assignment.

    Returns (output_files, batch_actual_sizes, batch_subject_counts).
    """
    output_files: list[str] = []
    batch_actual_sizes: list[int] = []
    batch_subject_counts: list[int] = []

    for i, target_size in enumerate(batch_sizes):
        row_indices = []
        for indices_list in assignment.get(i, []):
            row_indices.extend(indices_list)

        batch_df = df.iloc[row_indices].reset_index(drop=True)
        filename = f"{prefix}_{i + 1:03d}.csv"
        batch_df.to_csv(out / filename, index=False)
        output_files.append(filename)
        batch_actual_sizes.append(len(batch_df))
        batch_subject_counts.append(len(assignment.get(i, [])))

    return output_files, batch_actual_sizes, batch_subject_counts
