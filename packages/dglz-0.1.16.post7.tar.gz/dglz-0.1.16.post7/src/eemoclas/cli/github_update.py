"""Package metadata helpers and GitHub source functions for ``eemo update --dist-repo``."""

from __future__ import annotations

import json
import logging
import re
import urllib.error
import urllib.request
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_GITHUB_API = "https://api.github.com"


# ---------------------------------------------------------------------------
# Package metadata
# ---------------------------------------------------------------------------


def _find_pyproject_toml() -> str:
    """Walk upward from the installed package to find ``pyproject.toml``."""
    from eemoclas import __file__ as pkg_init

    if pkg_init is None:
        return ""
    current = Path(pkg_init).resolve().parent
    for _ in range(20):
        candidate = current / "pyproject.toml"
        if candidate.is_file():
            return str(candidate)
        parent = current.parent
        if parent == current:
            break
        current = parent
    return ""


def get_project_package_name() -> str:
    """Read ``[project].name`` from ``pyproject.toml``, falling back to ``\"DGLZ\"``."""
    path = _find_pyproject_toml()
    if not path:
        return "DGLZ"
    try:
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("name", "DGLZ")
    except Exception:
        return "DGLZ"


def normalize_package_name(name: str) -> str:
    """Lowercase, replace ``_`` and ``.`` with ``-``."""
    return name.lower().replace("_", "-").replace(".", "-")


# ---------------------------------------------------------------------------
# GitHub URL parsing
# ---------------------------------------------------------------------------

_SSH_PATTERN = re.compile(r"git@github\.com:(.+?)(?:\.git)?$")
_OWNER_REPO_PATTERN = re.compile(r"^([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$")


def parse_github_repo_url(url: str) -> tuple[str, str]:
    """Return ``(owner, repo)`` from various GitHub URL formats.

    Raises ``ValueError`` for non-GitHub URLs or malformed input.
    """
    import urllib.parse

    if not url or not url.strip():
        raise ValueError("Empty repository URL")

    url = url.strip()

    # SSH: git@github.com:owner/repo.git
    m = _SSH_PATTERN.match(url)
    if m:
        parts = m.group(1).split("/")
        if len(parts) == 2:
            return parts[0], parts[1]

    # Strip git+ prefix
    cleaned = url
    if cleaned.startswith("git+"):
        cleaned = cleaned[4:]

    # HTTPS: https://github.com/owner/repo(.git)?
    parsed = urllib.parse.urlparse(cleaned)
    if parsed.scheme and parsed.netloc:
        if parsed.netloc != "github.com":
            raise ValueError("--dist-repo currently supports GitHub repository URLs only.")
        path = parsed.path.lstrip("/")
        if path.endswith(".git"):
            path = path[:-4]
        parts = path.split("/")
        if len(parts) == 2 and parts[0] and parts[1]:
            return parts[0], parts[1]
        if len(parts) > 2:
            raise ValueError(
                f"GitHub URL should be owner/repo, got extra path segments: {parsed.path}"
            )

    # Bare owner/repo
    m = _OWNER_REPO_PATTERN.match(url)
    if m:
        return m.group(1), m.group(2)

    raise ValueError(f"Cannot parse repository URL: {url!r}")


# ---------------------------------------------------------------------------
# GitHub API
# ---------------------------------------------------------------------------


def github_api_get_json(url: str) -> Any:
    """GET *url* and return parsed JSON.

    Uses ``urllib.request`` with ``User-Agent: eemo-cli-updater``.
    Raises ``ValueError`` on HTTP 404 or JSON errors,
    ``ConnectionError`` on network failures or HTTP 403 (rate limit).
    """
    req = urllib.request.Request(url, headers={"User-Agent": "eemo-cli-updater"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise ValueError(
                f"GitHub API HTTP {exc.code} for {url}"
            ) from exc
        if exc.code == 403:
            raise ConnectionError(
                f"GitHub API rate limit exceeded. Try again later or use --dist-repo with a valid token."
            ) from exc
        raise ConnectionError(f"GitHub API HTTP {exc.code} for {url}") from exc
    except (OSError, urllib.error.URLError) as exc:
        raise ConnectionError(f"Network error accessing {url}: {exc}") from exc

    try:
        return json.loads(body)
    except (json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"Invalid JSON from {url}: {exc}") from exc


# ---------------------------------------------------------------------------
# Release helpers
# ---------------------------------------------------------------------------


def get_github_release(
    owner: str,
    repo: str,
    tag: str | None = None,
    prerelease: bool = False,
    package_name: str = "dglz",
    asset_pattern: str | None = None,
) -> dict:
    """Fetch a GitHub release dict.

    * *tag*: ``/repos/{o}/{r}/releases/tags/{tag}``
    * no *tag*: ``/repos/{o}/{r}/releases`` then pick the non-draft
      release with the **highest** version that has a matching ``.whl``
      asset.  Matches by ``<pkg>-*.whl`` prefix, or by *asset_pattern*
      if given.  When *prerelease* is False, skip prerelease releases.
    """
    from packaging.version import InvalidVersion, Version

    base = f"{_GITHUB_API}/repos/{owner}/{repo}/releases"

    if tag:
        return github_api_get_json(f"{base}/tags/{tag}")

    prefix = f"{normalize_package_name(package_name)}-"
    releases: list[dict] = github_api_get_json(base)

    best_rel: dict | None = None
    best_ver: Version | None = None
    for rel in releases:
        if rel.get("draft"):
            continue
        if not prerelease and rel.get("prerelease"):
            continue
        assets = rel.get("assets", [])
        wheel_assets = [a for a in assets if a.get("name", "").endswith(".whl")]
        matched = False
        if asset_pattern:
            if any(fnmatch(a["name"], asset_pattern) for a in wheel_assets):
                matched = True
        else:
            if any(a["name"].startswith(prefix) for a in wheel_assets):
                matched = True
        if not matched:
            continue
        # Extract version from the matching wheel filename (canonical source)
        ver_str: str | None = None
        for a in wheel_assets:
            name = a["name"]
            if asset_pattern and not fnmatch(name, asset_pattern):
                continue
            if not asset_pattern and not name.startswith(prefix):
                continue
            # wheel name: {pkg}-{version}-{python}-{abi}-{platform}.whl
            stem = name[:-4]
            parts = stem.split("-")
            if len(parts) >= 2:
                ver_str = parts[1]
                break
        # Fallback to tag_name if wheel name doesn't parse
        if ver_str is None:
            tag_name = rel.get("tag_name", "")
            ver_str = tag_name.lstrip("v") if tag_name.startswith("v") else tag_name
        try:
            ver = Version(ver_str)
        except InvalidVersion:
            continue
        if best_ver is None or ver > best_ver:
            best_ver = ver
            best_rel = rel

    if best_rel is not None:
        return best_rel

    raise ValueError(
        f"No non-draft release with a .whl asset found for {owner}/{repo}"
    )


def select_wheel_asset(
    release: dict,
    package_name: str = "dglz",
    asset_pattern: str | None = None,
) -> dict:
    """Select the best ``.whl`` asset from a GitHub release dict.

    * If *asset_pattern* is given, use ``fnmatch``.
    * Otherwise match ``<normalized-package-name>-*.whl``.
    * Prefer ``py3-none-any.whl`` among matches.
    * Raise ``ValueError`` if no wheel matches or no unique choice.
    """
    assets = release.get("assets", [])

    # Only consider .whl assets
    wheel_assets = [a for a in assets if a.get("name", "").endswith(".whl")]

    if not wheel_assets:
        names = [a.get("name", "?") for a in assets]
        raise ValueError(
            f"No .whl assets found in release. Available: {names}"
        )

    # Determine pattern
    if asset_pattern is not None:
        pattern = asset_pattern
    else:
        pattern = f"{normalize_package_name(package_name)}-*.whl"

    matched = [a for a in wheel_assets if fnmatch(a["name"], pattern)]

    if not matched:
        names = [a["name"] for a in assets]
        raise ValueError(
            f"No wheel matching '{pattern}'. Available assets: {names}"
        )

    if len(matched) == 1:
        return matched[0]

    # Prefer py3-none-any.whl
    pure = [a for a in matched if a["name"].endswith("py3-none-any.whl")]
    if len(pure) == 1:
        return pure[0]

    # Try packaging.tags for compatibility preference (optional)
    try:
        import packaging.tags

        tag_strs = {str(t) for t in packaging.tags.sys_tags()}
        best = None
        for a in matched:
            name = a["name"]
            # wheel: {name}-{version}-{python}-{abi}-{platform}.whl
            parts = name[:-4].split("-")
            if len(parts) >= 5:
                wheel_tags = "-".join(parts[2:])
                if wheel_tags in tag_strs:
                    best = a
                    break
        if best is not None:
            return best
    except ImportError:
        pass

    raise ValueError(
        f"Multiple wheels match '{pattern}': {[a['name'] for a in matched]}. "
        "Use --asset-pattern to select one."
    )
