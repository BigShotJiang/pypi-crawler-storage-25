# src/eemoclas/cli/pred_cmd.py
"""``eemo pred`` -- single model prediction."""

from __future__ import annotations

from typing import Optional

import typer

_VALID_MODELS = (
    "subject_state", "normal_emotion", "depression_emotion",
    "dual_subject_state", "dual_normal_emotion", "dual_depression_emotion",
)


def register(app: typer.Typer) -> None:
    """Register the ``pred`` command on the top-level Typer app."""

    @app.command(name="pred", help="单模型预测")
    def pred(
        name: str = typer.Argument(
            ...,
            help=f"模型名称: {', '.join(_VALID_MODELS)}",
        ),
        config: str = typer.Option(..., "--config", help="配置 YAML 文件路径"),
        model_path: str = typer.Option(..., "--model", help="模型检查点文件路径 (.ckpt)"),
        data: str = typer.Option(..., "--data", help="数据清单 CSV 或数据目录路径"),
        output: str = typer.Option("outputs/pred.csv", "--output", help="预测结果输出 CSV 路径"),
        batch_index: Optional[str] = typer.Option(
            None, "--batch-index", "-b",
            help="batch_index CSV 路径（指定测试子集）",
        ),
        ground_truth: Optional[str] = typer.Option(
            None, "--ground-truth", "-g",
            help="ground truth CSV 路径",
        ),
        label_col: Optional[str] = typer.Option(
            None, "--label-col", "-l",
            help="ground truth 列名",
        ),
        metrics_output: Optional[str] = typer.Option(
            None, "--metrics-output",
            help="指标输出 CSV 路径",
        ),
    ) -> None:
        """运行单模型预测，支持 batch-index 和评估指标。"""
        from eemoclas.cli.predict_impl import run_predict

        run_predict(
            name=name,
            config_path=config,
            model_path=model_path,
            data_path=data,
            output_path=output,
            batch_index_path=batch_index,
            ground_truth_path=ground_truth,
            label_col=label_col,
            metrics_output_path=metrics_output,
        )
