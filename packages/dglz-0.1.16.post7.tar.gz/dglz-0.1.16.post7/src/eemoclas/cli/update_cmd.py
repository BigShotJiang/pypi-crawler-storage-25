"""``eemo update`` -- check PyPI/GitHub and upgrade DGLZ.

Flow:
1. Query PyPI for latest version (3s timeout)
2. If already latest -> green message + exit
3. Synchronous pip install with 3-attempt fallback (all platforms)
4. On Windows: if pip fails (file lock), fall back to detached .bat script
5. On success -> generate UPDATE.md + Rich panels + log to ~/.dglz/update.log

New in V0.1.16+:
- --dist-repo enables GitHub Release wheel mode (skips PyPI)
- Automatic mode tries PyPI first, falls back to GitHub
- --tag, --asset-pattern, --dry-run, --pre, --index-url, --extra-index-url
"""

from __future__ import annotations

import enum
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

import typer
from packaging.version import Version

from eemoclas.__version__ import __version__
from eemoclas.cli.update_log import (
    filter_updates,
    load_update_log,
    render_rich_changelog,
    render_rich_migration,
    render_update_md,
)
from eemoclas.cli.utils import console
from eemoclas.cli.version_check import check_for_update, log_update

logger = logging.getLogger(__name__)

app = typer.Typer(help="更新 DGLZ 到最新版本")

_SKIP_VERSION_HINT = False

_DEFAULT_DIST_REPO = "https://github.com/SuShuheng/dglz-dist.git"


class _GitHubNetworkError(typer.Exit):
    """Raised when GitHub is unreachable — typer.Exit subclass so the CLI exits cleanly.

    Also carries ``is_network_error = True`` so the automatic-fallback path can
    distinguish it from non-network GitHub failures (missing wheel, bad tag, etc.).
    """

    is_network_error: bool = True

    def __init__(self, message: str = ""):
        self.message = message
        super().__init__(code=1)


class _PyPIStatus(enum.Enum):
    NEWER = "newer"
    ALREADY_LATEST = "already_latest"
    NETWORK_ERROR = "network_error"
    MISSING = "missing"


def _check_pypi_for_update(pre: bool = False) -> tuple[_PyPIStatus, Optional[str]]:
    """Check PyPI for updates, returning a structured status.

    Returns (status, latest_version_str).
    """
    latest, has_update, error_type = check_for_update()
    if latest is None:
        if error_type == "missing":
            return _PyPIStatus.MISSING, None
        return _PyPIStatus.NETWORK_ERROR, None
    if has_update:
        return _PyPIStatus.NEWER, latest
    return _PyPIStatus.ALREADY_LATEST, latest


def _extract_version_from_wheel_name(name: str) -> str:
    """Extract version from a wheel filename.

    ``dglz-0.1.15.post19-py3-none-any.whl`` -> ``0.1.15.post19``
    """
    stem = name[:-4] if name.endswith(".whl") else name  # strip .whl
    parts = stem.split("-")
    if len(parts) >= 2:
        return parts[1]
    raise ValueError(f"Cannot extract version from wheel name: {name!r}")


def _extract_version_from_tag(tag: str) -> str:
    """Extract version from a release tag name.

    ``v0.1.15.post19`` -> ``0.1.15.post19``
    """
    if tag.startswith("v"):
        return tag[1:]
    return tag


def _build_pip_args_pypi(
    pre: bool = False,
    index_url: Optional[str] = None,
    extra_index_url: Optional[str] = None,
) -> list[str]:
    """Build pip install arguments for PyPI mode."""
    args = ["--no-cache-dir", "--upgrade"]
    if pre:
        args.append("--pre")
    if index_url:
        args.extend(["--index-url", index_url])
    if extra_index_url:
        args.extend(["--extra-index-url", extra_index_url])
    args.append("DGLZ")
    return args


def _run_pip_install(args: list[str], timeout: int = 120) -> subprocess.CompletedProcess:
    """Run pip install with the given arguments."""
    return subprocess.run(
        [sys.executable, "-m", "pip", "install"] + args,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _is_windows() -> bool:
    """Return True if running on Windows."""
    return sys.platform == "win32"


def _generate_bat_script(pip_args: list[str], label: str, python_exe: str, log_dir: str, pypi_fallback: bool = True) -> str:
    """Generate a Windows .bat script that waits and runs pip install.

    The script:
    1. Waits 3 seconds for the CLI process to exit (release file lock)
    2. Runs pip install with provided args (3 attempts)
    3. Writes result to update.log (without URLs)
    4. Self-deletes
    """
    # Quote each pip arg for safety in batch (handles spaces/URLs)
    quoted_args = " ".join(f'"{a}"' for a in pip_args)
    # Log label: use version only, strip URLs to avoid leaking download links
    safe_label = label.split(" ")[0] if " " in label else label

    # Third retry: keep original args in GitHub mode, fall back to DGLZ in PyPI mode
    third_cmd = (
        f'"{python_exe}" -m pip install --no-cache-dir --upgrade DGLZ'
        if pypi_fallback
        else f'"{python_exe}" -m pip install --no-cache-dir --upgrade {quoted_args}'
    )

    return f"""@echo off
timeout /t 3 /nobreak >nul

if not exist "{log_dir}" mkdir "{log_dir}"

echo [%date% %time%] ATTEMPTING ^| {safe_label} >> "{log_dir}\\update.log"

"{python_exe}" -m pip install --no-cache-dir {quoted_args}
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {safe_label} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] RETRY ^| {safe_label} >> "{log_dir}\\update.log"
"{python_exe}" -m pip install --no-cache-dir --upgrade {quoted_args}
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {safe_label} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] RETRY2 ^| {safe_label} >> "{log_dir}\\update.log"
{third_cmd}
if %errorlevel% equ 0 (
    echo [%date% %time%] SUCCESS ^| {safe_label} >> "{log_dir}\\update.log"
    goto :self_delete
)

echo [%date% %time%] FAILED ^| {safe_label} >> "{log_dir}\\update.log"

:self_delete
del /f "%~f0"
exit
"""


def _windows_detached_update(pip_args: list[str], label: str, console_obj, pypi_fallback: bool = True) -> None:
    """Generate a detached .bat script to update DGLZ on Windows."""
    from eemoclas.cli.utils import print_cli_warning

    python_exe = sys.executable
    log_dir = str(Path.home() / ".dglz")

    try:
        script_content = _generate_bat_script(pip_args, label, python_exe, log_dir, pypi_fallback=pypi_fallback)
    except Exception as exc:
        print_cli_warning(f"无法生成更新脚本: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"bat generation error: {exc}")
        raise typer.Exit(code=1)

    bat_path = os.path.join(tempfile.gettempdir(), "_dglz_update.bat")
    try:
        with open(bat_path, "w", encoding="utf-8") as f:
            f.write(script_content)
    except Exception as exc:
        print_cli_warning(f"无法写入更新脚本: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"bat write error: {exc}")
        raise typer.Exit(code=1)

    try:
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        DETACHED_PROCESS = 0x00000008
        subprocess.Popen(
            ["cmd", "/c", bat_path],
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
        )
    except Exception as exc:
        print_cli_warning(f"无法启动更新进程: {exc}")
        console_obj.print("  [bold]请手动运行:[/bold] pip install DGLZ --upgrade")
        log_update("FAILED", f"popen error: {exc}")
        raise typer.Exit(code=1)

    print_cli_warning(
        "Windows 下无法直接替换正在运行的 eemo.exe。\n"
        f"  将在后台启动更新脚本，请等待更新完成后重新运行 eemo。"
    )
    console_obj.print(
        f"  更新完成后，日志将写入: {os.path.join(log_dir, 'update.log')}"
    )
    console_obj.print()
    log_update("DETACHED", f"{__version__} -> {label} (Windows bat)")
    raise typer.Exit(code=0)


def _do_pip_install(
    pip_args: list[str],
    label: str,
    dry_run: bool = False,
    pypi_fallback: bool = True,
    quiet: bool = False,
) -> bool:
    """Run pip install with 3-attempt fallback. Returns True on success.

    In dry-run mode, prints the command and returns True without running.
    When *pypi_fallback* is False (GitHub wheel mode), retries keep the
    original wheel URL instead of falling back to ``pip install DGLZ``.
    When *quiet* is True, suppress error output and just raise on failure
    (used before fallback to avoid duplicate error messages).
    """
    from eemoclas.cli.utils import print_cli_error

    # Build recovery command: use pip_args for context-aware suggestion
    if pypi_fallback:
        recovery_cmd = "pip install DGLZ --upgrade"
    else:
        recovery_cmd = f"pip install {' '.join(pip_args)}"

    cmd_display = f"{sys.executable} -m pip install {' '.join(pip_args)}"

    if dry_run:
        console.print(f"  [bold cyan]\\[dry-run][/bold cyan] {cmd_display}")
        return True

    console.print()
    with console.status("[bold cyan]正在更新 DGLZ...[/bold cyan]"):
        result = None
        try:
            result = _run_pip_install(pip_args)

            if result.returncode != 0:
                logger.info("First install failed: %s", result.stderr.strip())
                result = _run_pip_install(["--upgrade"] + [a for a in pip_args if a != "--upgrade"])

                if result.returncode != 0:
                    logger.info("Second attempt failed: %s", result.stderr.strip())
                    if pypi_fallback:
                        result = _run_pip_install(["--upgrade", "DGLZ"])
                    else:
                        result = _run_pip_install(pip_args)

        except subprocess.TimeoutExpired:
            if not quiet:
                print_cli_error("更新超时（120s）。")
                console.print(f"  [bold]请手动运行:[/bold] {recovery_cmd}")
            log_update("FAILED", f"timeout, {__version__} -> {label}")
            raise typer.Exit(code=1)

    if result is not None and result.returncode != 0:
        if _is_windows():
            logger.info("Synchronous update failed on Windows, falling back to detached bat script")
            _windows_detached_update(pip_args, label, console, pypi_fallback=pypi_fallback)
            return False  # unreachable
        if not quiet:
            print_cli_error(f"更新失败: {result.stderr.strip()}")
            console.print(f"  [bold]请手动运行:[/bold] {recovery_cmd}")
        log_update("FAILED", f"{__version__} -> {label}, stderr: {result.stderr.strip()[:200]}")
        raise typer.Exit(code=1)

    return True


def _show_success_panel(old_version: str, new_version: str, source: str, extra_info: str = "") -> None:
    """Print the update success panel."""
    from rich.panel import Panel
    from rich.text import Text

    parts = [f"V{old_version} → V{new_version}", f"来源: {source}"]
    if extra_info:
        parts.append(extra_info)

    success_text = Text.from_markup("\n".join(parts))
    console.print(Panel(
        success_text,
        title="[bold green]✔ 更新成功[/bold green]",
        border_style="green",
        expand=False,
    ))
    log_update("SUCCESS", f"{old_version} -> {new_version} ({source})")


def _show_changelog(latest: str) -> None:
    """Show changelog and migration panels, generate UPDATE.md."""
    try:
        all_rows = load_update_log()
    except Exception:
        all_rows = []

    filtered = filter_updates(all_rows, __version__, latest)

    update_md_path: str | None = None
    try:
        md_content = render_update_md(filtered, __version__, latest)
        update_md_path = os.path.join(os.getcwd(), "UPDATE.md")
        with open(update_md_path, "w", encoding="utf-8") as f:
            f.write(md_content)
    except Exception as exc:
        logger.warning("Failed to generate UPDATE.md: %s", exc)

    if filtered:
        console.print()
        render_rich_changelog(filtered, console)
        console.print()
        render_rich_migration(filtered, console)

    if update_md_path:
        abs_path = os.path.abspath(update_md_path)
        console.print()
        console.print(f"  [bold]更新日志已保存至:[/bold] {abs_path}")


def _github_update(
    dist_repo: str,
    tag: Optional[str],
    asset_pattern: Optional[str],
    pre: bool,
    dry_run: bool,
) -> None:
    """Perform GitHub Release-based update flow."""
    from eemoclas.cli.github_update import (
        get_github_release,
        get_project_package_name,
        parse_github_repo_url,
        select_wheel_asset,
    )
    from eemoclas.cli.utils import print_cli_error, print_cli_success

    try:
        owner, repo = parse_github_repo_url(dist_repo)
    except ValueError as exc:
        print_cli_error(f"无法解析仓库地址: {exc}")
        raise typer.Exit(code=1)

    console.print(f"  GitHub 仓库: [cyan]{owner}/{repo}[/cyan]")

    package_name = get_project_package_name()

    # Get release
    try:
        release = get_github_release(owner, repo, tag=tag, prerelease=pre, package_name=package_name, asset_pattern=asset_pattern)
    except ConnectionError as exc:
        print_cli_error(f"无法连接 GitHub: {exc}")
        log_update("FAILED", f"{__version__} -> ? (GitHub unreachable)")
        raise _GitHubNetworkError(str(exc)) from exc
    except ValueError as exc:
        print_cli_error(f"未找到发布版本: {exc}")
        log_update("FAILED", f"{__version__} -> ? (GitHub release not found)")
        raise typer.Exit(code=1)

    release_tag = release.get("tag_name", "unknown")

    # Select wheel asset
    try:
        asset = select_wheel_asset(release, package_name=package_name, asset_pattern=asset_pattern)
    except ValueError as exc:
        print_cli_error(f"未找到匹配的 wheel 文件: {exc}")
        log_update("FAILED", f"{__version__} -> {release_tag} (no matching wheel)")
        raise typer.Exit(code=1)

    wheel_name = asset.get("name", "unknown")
    wheel_url = asset.get("browser_download_url", "")

    if not wheel_url:
        print_cli_error(f"wheel 文件缺少下载链接: {wheel_name}")
        raise typer.Exit(code=1)

    # Version comparison
    try:
        gh_version_str = _extract_version_from_wheel_name(wheel_name)
    except ValueError:
        gh_version_str = _extract_version_from_tag(release_tag)

    gh_version = Version(gh_version_str)
    current_version = Version(__version__)

    # If explicit --tag, install even if not newer
    if tag is None and gh_version <= current_version:
        print_cli_success(f"GitHub 最新版本 V{gh_version_str}，当前已是最新 V{__version__}")
        console.print()
        log_update("ALREADY_LATEST", f"{__version__} (GitHub: {release_tag})")
        raise typer.Exit(code=0)

    if dry_run:
        console.print(f"  [bold cyan]\\[dry-run][/bold cyan] 将从 GitHub Release 安装:")
        console.print(f"    Release: {release_tag}")
        console.print(f"    Wheel:   {wheel_name}")
        console.print(f"    URL:     {wheel_url}")
        pip_args = ["--upgrade", wheel_url]
        cmd_display = f"{sys.executable} -m pip install {' '.join(pip_args)}"
        console.print(f"    Command: {cmd_display}")
        log_update("DRY_RUN", f"{__version__} -> {gh_version_str} (GitHub: {release_tag})")
        raise typer.Exit(code=0)

    # Install
    pip_args = ["--upgrade", wheel_url]
    label = f"{gh_version_str} (GitHub: {release_tag})"
    _do_pip_install(pip_args, label, dry_run=False, pypi_fallback=False)

    extra_info = f"Release: {release_tag} | Wheel: {wheel_name}"
    _show_success_panel(__version__, gh_version_str, "GitHub Release", extra_info)
    _show_changelog(gh_version_str)


@app.callback(invoke_without_command=True)
def update(
    dist_repo: bool = typer.Option(
        False,
        "--dist-repo",
        help="启用 GitHub Release wheel 模式（跳过 PyPI）。",
    ),
    dist_repo_url: Optional[str] = typer.Option(
        None,
        "--dist-repo-url",
        help="GitHub 分发仓库 URL（需要 --dist-repo，默认使用 DGLZ 官方仓库）。",
    ),
    tag: Optional[str] = typer.Option(
        None,
        "--tag",
        help="指定 GitHub Release 标签（需要 --dist-repo）。",
    ),
    asset_pattern: Optional[str] = typer.Option(
        None,
        "--asset-pattern",
        help="wheel 文件名匹配模式（需要 --dist-repo）。",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="仅显示将要执行的命令，不实际安装。",
    ),
    pre: bool = typer.Option(
        False,
        "--pre",
        help="包含预发布版本。",
    ),
    index_url: Optional[str] = typer.Option(
        None,
        "--index-url",
        help="PyPI 索引 URL（仅 PyPI 模式）。",
    ),
    extra_index_url: Optional[str] = typer.Option(
        None,
        "--extra-index-url",
        help="额外 PyPI 索引 URL（仅 PyPI 模式）。",
    ),
) -> None:
    """检查并更新 DGLZ 到最新版本，显示更新日志。"""
    global _SKIP_VERSION_HINT
    _SKIP_VERSION_HINT = True

    from rich.panel import Panel
    from rich.text import Text
    from eemoclas.cli.utils import print_cli_error, print_cli_success, print_cli_warning

    # --- Validate option dependencies ---
    if tag is not None and not dist_repo:
        print_cli_error("--tag 需要 --dist-repo 参数。")
        raise typer.Exit(code=1)

    if asset_pattern is not None and not dist_repo:
        print_cli_error("--asset-pattern 需要 --dist-repo 参数。")
        raise typer.Exit(code=1)

    if dist_repo_url is not None and not dist_repo:
        print_cli_error("--dist-repo-url 需要 --dist-repo 参数。")
        raise typer.Exit(code=1)

    if dist_repo:
        repo = dist_repo_url or _DEFAULT_DIST_REPO

        # Warn and ignore PyPI-only options
        if index_url is not None:
            print_cli_warning("--index-url 在 GitHub 模式下被忽略。")
        if extra_index_url is not None:
            print_cli_warning("--extra-index-url 在 GitHub 模式下被忽略。")

        # --- Explicit GitHub mode ---
        console.print()
        _github_update(repo, tag, asset_pattern, pre, dry_run)
        console.print()
        return

    # --- Automatic mode: PyPI first, then GitHub fallback ---
    console.print()
    pypi_status, pypi_latest = _check_pypi_for_update(pre=pre)

    if pypi_status == _PyPIStatus.NEWER and pypi_latest is not None:
        # PyPI has newer version -> try install from PyPI
        pip_args = _build_pip_args_pypi(pre=pre, index_url=index_url, extra_index_url=extra_index_url)
        label = pypi_latest

        if dry_run:
            cmd_display = f"{sys.executable} -m pip install {' '.join(pip_args)}"
            console.print(f"  [bold cyan]\\[dry-run][/bold cyan] {cmd_display}")
            log_update("DRY_RUN", f"{__version__} -> {pypi_latest} (PyPI)")
            console.print()
            raise typer.Exit(code=0)

        # Show version info panel
        try:
            all_rows = load_update_log()
        except Exception:
            all_rows = []

        filtered = filter_updates(all_rows, __version__, pypi_latest)
        n_versions = len({r["version"] for r in filtered}) if filtered else 0

        info_text = Text.from_markup(
            f"当前版本:  V{__version__}\n"
            f"最新版本:  V{pypi_latest}\n"
            f"版本差距:  {n_versions} 个版本\n\n"
            f"即将更新: V{__version__} → V{pypi_latest}"
        )
        console.print(Panel(info_text, title="DGLZ 版本更新", border_style="blue", expand=False))

        try:
            _do_pip_install(pip_args, label, dry_run=False, quiet=True)
        except (typer.Exit, SystemExit) as e:
            # Windows detached update succeeds with exit code 0 — don't fall back
            exit_code = getattr(e, "exit_code", getattr(e, "code", 1))
            if exit_code == 0:
                raise
            # Non-zero exit: pip failed -> try GitHub fallback
            logger.info("PyPI install failed (exit %s), trying GitHub fallback", exit_code)
            console.print()
            print_cli_warning("PyPI 安装失败，尝试从 GitHub Release 安装...")
            _github_update(_DEFAULT_DIST_REPO, tag=None, asset_pattern=None, pre=pre, dry_run=False)
            console.print()
            return

        _show_success_panel(__version__, pypi_latest, "PyPI")
        _show_changelog(pypi_latest)
        console.print()
        return

    # PyPI has no newer version, is missing, or network error -> check GitHub
    if pypi_status in (_PyPIStatus.ALREADY_LATEST, _PyPIStatus.NETWORK_ERROR, _PyPIStatus.MISSING):
        logger.info("PyPI status=%s, trying GitHub fallback", pypi_status.value)
        pypi_was_network_error = pypi_status == _PyPIStatus.NETWORK_ERROR

        # Show user-facing Rich hint about why we're falling back to GitHub
        if pypi_status == _PyPIStatus.MISSING:
            print_cli_warning("PyPI 上未找到 DGLZ 包，正在从 GitHub Release 检查更新...")
        elif pypi_status == _PyPIStatus.NETWORK_ERROR:
            print_cli_warning("无法连接 PyPI，正在从 GitHub Release 检查更新...")
        elif pypi_status == _PyPIStatus.ALREADY_LATEST:
            console.print(f"  PyPI 当前已是最新版本 V{pypi_latest}，正在从 GitHub Release 检查是否有更新版本...")
            console.print()

        # If custom index URLs were provided, try pip install with them first —
        # the version check used the public PyPI, but a private index may have newer.
        if index_url or extra_index_url:
            pip_args = _build_pip_args_pypi(pre=pre, index_url=index_url, extra_index_url=extra_index_url)
            label = "custom-index"

            if dry_run:
                cmd_display = f"{sys.executable} -m pip install {' '.join(pip_args)}"
                console.print(f"  [bold cyan]\\[dry-run][/bold cyan] {cmd_display}")
                log_update("DRY_RUN", f"{__version__} -> ? (custom index)")
                console.print()
                raise typer.Exit(code=0)

            try:
                _do_pip_install(pip_args, label, dry_run=False, quiet=True)
                from rich.panel import Panel
                console.print(Panel(
                    f"来源: Custom Index\n版本: V{__version__}",
                    title="[bold green]✔ 自定义索引安装完成[/bold green]",
                    border_style="green",
                    expand=False,
                ))
                log_update("SUCCESS", f"{__version__} (Custom Index)")
                console.print()
                return
            except (typer.Exit, SystemExit) as e:
                exit_code = getattr(e, "exit_code", getattr(e, "code", 1))
                if exit_code == 0:
                    raise
                logger.info("Custom index install failed (exit %s), trying GitHub", exit_code)

        gh_was_network_error = False
        try:
            _github_update(_DEFAULT_DIST_REPO, tag=None, asset_pattern=None, pre=pre, dry_run=dry_run)
            console.print()
            return
        except _GitHubNetworkError:
            gh_was_network_error = True
            raise
        except (typer.Exit, SystemExit):
            raise
        finally:
            if pypi_was_network_error and gh_was_network_error:
                print_cli_error("PyPI 和 GitHub 均无法连接，请检查网络。")
                log_update("FAILED", f"{__version__} -> ? (both sources unreachable)")

    # Should not reach here, but just in case
    print_cli_error("无法完成更新。")
    log_update("FAILED", f"{__version__} -> ?")
    raise typer.Exit(code=1)
