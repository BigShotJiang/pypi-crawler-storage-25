# src/eemoclas/cli/predict_impl.py
"""Prediction implementation for ``eemo pred``.

Loads a model checkpoint, creates a dataset from a manifest, runs inference,
and saves the predictions to a CSV file. Supports batch-index filtering
and evaluation metrics output.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)
from eemoclas.utils.config import load_config, resolve_c_eff


def run_predict(
    name: str,
    config_path: str,
    model_path: str,
    data_path: str,
    output_path: str,
    batch_index_path: str | None = None,
    ground_truth_path: str | None = None,
    label_col: str | None = None,
    metrics_output_path: str | None = None,
) -> None:
    print_cli_header(f"Pred -- {name}")

    # --- Validate inputs ---
    if not os.path.isfile(config_path):
        print_cli_error(f"Config file not found: {config_path}")
        raise SystemExit(1)
    if not os.path.isfile(model_path):
        print_cli_error(f"Checkpoint not found: {model_path}")
        raise SystemExit(1)
    if batch_index_path and not os.path.isfile(batch_index_path):
        print_cli_error(f"Batch index file not found: {batch_index_path}")
        raise SystemExit(1)
    if ground_truth_path and not os.path.isfile(ground_truth_path):
        print_cli_error(f"Ground truth file not found: {ground_truth_path}")
        raise SystemExit(1)

    # --- Resolve manifest ---
    manifest_path = _resolve_manifest(data_path)
    if manifest_path is None:
        print_cli_error(f"No manifest found in: {data_path}")
        raise SystemExit(1)

    console.print(f"  Manifest: [cyan]{manifest_path}[/cyan]")
    console.print(f"  Checkpoint: [cyan]{model_path}[/cyan]")
    if batch_index_path:
        console.print(f"  Batch index: [cyan]{batch_index_path}[/cyan]")

    # --- Load config ---
    cfg = load_config(config_path)
    c_eff = resolve_c_eff(cfg)

    # --- Device ---
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    console.print(f"  Device: [cyan]{device}[/cyan]")

    # --- Create model and load checkpoint ---
    from eemoclas.model.model_factory import create_model
    from eemoclas.training.checkpoint import load_checkpoint

    model = create_model(name, cfg)
    ckpt_data = load_checkpoint(model_path, model, device)
    model = model.to(device)
    console.print(f"  Checkpoint loaded from epoch {ckpt_data['epoch']}")

    # --- Create dataset and dataloader ---
    from eemoclas.datasets.resampled_dataset import ResampledTensorDataset
    from eemoclas.datasets.collate import collate_fn
    from torch.utils.data import DataLoader

    dataset = ResampledTensorDataset(
        manifest_path,
        batch_index_csv=batch_index_path,
        load_raw=_is_dual_model(name),
    )
    loader = DataLoader(
        dataset,
        batch_size=cfg.get("training", {}).get("batch_size", 16),
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=0,
    )
    console.print(f"  Dataset: [cyan]{len(dataset)}[/cyan] samples")

    # --- Run prediction ---
    from eemoclas.prediction.predictor import Predictor

    predictor = Predictor(model, device, cfg)
    results_df = predictor.predict(loader)

    # Add sample_id from manifest to results
    results_df["sample_id"] = dataset.manifest["sample_id"].values[:len(results_df)]

    # --- Save predictions ---
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(output_path, index=False)

    print_cli_success(f"Predictions saved to {output_path}")
    console.print(f"  Total samples: [cyan]{len(results_df)}[/cyan]")

    # --- Metrics ---
    _maybe_compute_metrics(
        results_df=results_df,
        manifest_df=dataset.manifest,
        name=name,
        ground_truth_path=ground_truth_path,
        label_col=label_col,
        metrics_output_path=metrics_output_path,
        output_path=output_path,
    )

    console.print()


def _resolve_manifest(data_path: str) -> str | None:
    if os.path.isfile(data_path):
        return os.path.abspath(data_path)

    candidate = os.path.join(data_path, "manifest.csv")
    if os.path.isfile(candidate):
        return os.path.abspath(candidate)

    return None


def _is_dual_model(name: str) -> bool:
    return name.startswith("dual_")


def _maybe_compute_metrics(
    results_df: pd.DataFrame,
    manifest_df: pd.DataFrame,
    name: str,
    ground_truth_path: str | None,
    label_col: str | None,
    metrics_output_path: str | None,
    output_path: str,
) -> None:
    from eemoclas.metrics.evaluator import evaluate
    from eemoclas.metrics.display import print_metrics, save_metrics_csv
    from eemoclas.metrics.ground_truth import resolve_ground_truth

    # Auto-detect label column if not specified
    if label_col is None:
        if "subject_state" in name:
            label_col = "group_label"
        else:
            label_col = "emotion_label"

    y_true = resolve_ground_truth(
        predictions_df=results_df,
        manifest_df=manifest_df,
        ground_truth_path=ground_truth_path,
        label_column=label_col,
    )

    if y_true is None:
        console.print("  [dim]No ground truth found, skipping metrics.[/dim]")
        return

    y_true = y_true.values[:len(results_df)]
    y_pred = results_df["y_pred"].values[:len(y_true)]
    y_prob = results_df["y_prob_1"].values[:len(y_true)] if "y_prob_1" in results_df.columns else None

    result = evaluate(y_true, y_pred, y_prob)

    print_metrics(result, title=f"Metrics -- {name}")

    if metrics_output_path is not None:
        save_metrics_csv(result, metrics_output_path, label=name)
        console.print(f"  Metrics saved to [cyan]{metrics_output_path}[/cyan]")
