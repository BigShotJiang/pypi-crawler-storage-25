"""Base dataset that reads .pt samples via manifest.csv."""

from __future__ import annotations

import torch
import pandas as pd
from torch.utils.data import Dataset
from pathlib import Path

_REQUIRED_FIELDS = ("x", "y", "subject_id", "token_meta", "meta")


class ResampledTensorDataset(Dataset):
    """Base dataset that reads ``.pt`` sample files listed in a manifest CSV.

    Each row in the manifest must contain at least a ``sample_path`` column
    pointing to a ``.pt`` file.  The loaded sample must be a ``dict`` with the
    keys ``x``, ``y``, ``subject_id``, ``token_meta``, and ``meta``.

    Parameters
    ----------
    manifest_file:
        Path to the manifest CSV file.
    load_raw:
        If ``True``, also load the raw (un-preprocessed) sample from the
        ``raw_sample_path`` column and add it to the returned dict as
        ``x_raw``.  Requires the manifest to contain a ``raw_sample_path``
        column (produced by ``eemo resample --save-raw``).
    batch_index_csv:
        Optional path or list of paths to batch CSVs containing a
        ``sample_id`` column.  When a list is provided, sample IDs from
        all CSVs are merged (union, deduplicated).  The manifest is then
        filtered to include only the merged samples, preserving the
        original manifest order.
    """

    def __init__(
        self,
        manifest_file: str,
        *,
        load_raw: bool = False,
        batch_index_csv: str | list[str] | None = None,
    ) -> None:
        self.manifest_path = Path(manifest_file)
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"Manifest file not found: {manifest_file}")

        self.manifest = pd.read_csv(manifest_file)
        self.load_raw = load_raw

        # batch_index mode: filter manifest to specified sample IDs
        if batch_index_csv is not None:
            paths = [batch_index_csv] if isinstance(batch_index_csv, str) else batch_index_csv
            batch_ids: set = set()
            for p in paths:
                if not Path(p).exists():
                    raise FileNotFoundError(f"batch_index_csv not found: {p}")
                df = pd.read_csv(p)
                batch_ids |= set(df["sample_id"])
            if not batch_ids:
                raise ValueError("batch_index_csv merge resulted in zero sample IDs")
            self.manifest = self.manifest[
                self.manifest["sample_id"].isin(batch_ids)
            ].reset_index(drop=True)

        # Validate required columns exist
        required_columns = {"sample_path", "subject_id"}
        missing = required_columns - set(self.manifest.columns)
        if missing:
            raise ValueError(
                f"Manifest is missing required columns: {sorted(missing)}"
            )

        if load_raw and "raw_sample_path" not in self.manifest.columns:
            raise ValueError(
                "load_raw=True requires 'raw_sample_path' column in manifest. "
                "Run `eemo resample --save-raw` first."
            )

    # ------------------------------------------------------------------
    # Dataset protocol
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.manifest)

    def __getitem__(self, idx: int) -> dict:
        """Load a ``.pt`` sample from the manifest's ``sample_path`` column."""
        row = self.manifest.iloc[idx]
        sample_path = str(row["sample_path"]).replace("\\", "/")
        sample: dict = torch.load(sample_path, weights_only=False)
        self._validate_sample(sample)

        # Load raw data if requested
        if self.load_raw:
            raw_path = str(row.get("raw_sample_path", "")).replace("\\", "/")
            if raw_path and raw_path.strip():
                raw_sample: dict = torch.load(raw_path, weights_only=False)
                sample["x_raw"] = raw_sample["x"]
            else:
                raise ValueError(
                    f"load_raw=True but row {idx} has empty raw_sample_path"
                )

        return sample

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate_sample(self, sample: dict) -> None:
        """Validate that *sample* contains every required top-level field.

        Subclasses should call ``super()._validate_sample(sample)`` first and
        then perform their own additional checks.
        """
        for field in _REQUIRED_FIELDS:
            if field not in sample:
                raise ValueError(
                    f"Sample missing required field: {field!r}. "
                    f"Present keys: {sorted(sample.keys())}"
                )

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def get_subject_ids(self) -> list[str]:
        """Return the sorted unique ``subject_id`` values in the manifest."""
        return sorted(self.manifest["subject_id"].unique().tolist())
