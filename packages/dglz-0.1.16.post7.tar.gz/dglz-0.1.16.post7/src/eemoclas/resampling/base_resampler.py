"""Abstract base class for EEG resamplers."""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import multiprocessing
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import torch
import yaml

logger = logging.getLogger(__name__)


class BaseResampler(ABC):
    """Base class for all resampling pipelines.

    Parameters
    ----------
    config : dict
        Full configuration dictionary.  Must contain at least
        ``config["data"]["output_dir"]``.
    """

    def __init__(self, config: dict) -> None:
        self.config = config
        self.output_dir = Path(config["data"]["output_dir"])
        self.samples_dir = self.output_dir / "samples"
        self.samples_dir.mkdir(parents=True, exist_ok=True)
        self._workers: int = config.get("resample", {}).get("workers", 1)

    # ------------------------------------------------------------------
    # Abstract
    # ------------------------------------------------------------------

    @abstractmethod
    def run(self) -> None:
        """Execute the full resampling pipeline."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Parallel execution helper
    # ------------------------------------------------------------------

    def _parallel_map(
        self,
        func: Callable[..., list[dict]],
        items: list[Any],
        *,
        desc: str = "processing",
        item_weights: list[int] | None = None,
        shared_counter: "multiprocessing.Value | None" = None,
        initializer: "Callable | None" = None,
        initargs: "tuple | None" = None,
    ) -> list[dict]:
        """Apply *func* to each item, optionally in parallel with Rich progress.

        When ``workers > 1``, uses :class:`ProcessPoolExecutor` with *spawn*
        context to bypass the GIL for CPU-bound preprocessing (bandpass filter,
        z-score, clip).  Results are collected in the original *items* order
        so that manifest rows stay deterministic regardless of process
        scheduling.

        Note: *func* must be picklable (module-level function, not a closure
        or bound method) when ``workers > 1``.

        Parameters
        ----------
        func:
            A callable that takes a single item and returns a list of
            manifest-row dicts.
        items:
            Iterable of work items (e.g. subject entries).
        desc:
            Human-readable label for log messages and progress bar.
        item_weights:
            Optional per-item weights (e.g. expected sample counts).
            When provided, progress tracks total weight instead of item count.
        shared_counter:
            Optional ``multiprocessing.Value('i', 0, lock=True)`` for
            fine-grained per-sample progress.  Workers increment it per
            sample; a polling thread reads it and advances the progress bar.
        initializer / initargs:
            Passed to ``ProcessPoolExecutor`` so workers can access the
            shared counter via a module-level variable.

        Returns
        -------
        list[dict]
            All manifest rows, concatenated in input order.
        """
        import threading

        workers = max(1, self._workers)
        total = sum(item_weights) if item_weights else len(items)

        if total == 0:
            return []

        # Try Rich progress bar; fall back to plain loop
        progress = self._create_progress(desc, total, workers)
        all_rows: list[dict] = []

        # Polling thread for fine-grained per-sample progress
        _poll_thread = None
        _stop_event = None
        _poll_last = [0]

        if shared_counter is not None and workers > 1:
            _stop_event = threading.Event()

            def _poll_counter():
                while not _stop_event.wait(0.15):
                    with shared_counter.get_lock():
                        cur = shared_counter.value
                    delta = cur - _poll_last[0]
                    if delta > 0 and progress is not None:
                        progress.advance(delta)
                        _poll_last[0] = cur

            _poll_thread = threading.Thread(target=_poll_counter, daemon=True)
            _poll_thread.start()

        try:
            if workers == 1 or total <= 1:
                # Sequential path
                for idx, item in enumerate(items):
                    all_rows.extend(func(item))
                    if progress is not None:
                        weight = item_weights[idx] if item_weights else 1
                        progress.advance(weight)
            else:
                # Parallel path — use separate processes to bypass GIL on CPU-bound work
                logger.info(
                    "%s: using %d worker processes for %d items",
                    desc, workers, len(items),
                )

                indexed_results: dict[int, list[dict]] = {}
                ctx = multiprocessing.get_context("spawn")
                pool_kw: dict[str, Any] = {
                    "max_workers": workers,
                    "mp_context": ctx,
                }
                if initializer is not None:
                    pool_kw["initializer"] = initializer
                if initargs is not None:
                    pool_kw["initargs"] = initargs

                with ProcessPoolExecutor(**pool_kw) as pool:
                    futures = {
                        pool.submit(func, item): idx
                        for idx, item in enumerate(items)
                    }
                    try:
                        for future in as_completed(futures):
                            idx = futures[future]
                            try:
                                indexed_results[idx] = future.result()
                            except Exception:
                                if progress is not None:
                                    progress.stop()
                                logger.exception(
                                    "%s: worker failed for item index %d", desc, idx
                                )
                                raise
                            # Per-subject advance only when no shared counter
                            if shared_counter is None and progress is not None:
                                weight = item_weights[idx] if item_weights else 1
                                progress.advance(weight)
                    except KeyboardInterrupt:
                        for f in futures:
                            f.cancel()
                        pool.shutdown(wait=False, cancel_futures=True)
                        raise

                # Stop polling and sync final count
                if _poll_thread is not None:
                    _stop_event.set()
                    _poll_thread.join()
                    with shared_counter.get_lock():
                        remaining = shared_counter.value - _poll_last[0]
                    if remaining > 0 and progress is not None:
                        progress.advance(remaining)

                # Re-assemble in original order.
                for idx in range(len(items)):
                    all_rows.extend(indexed_results.get(idx, []))
        finally:
            if progress is not None:
                progress.stop()

        return all_rows

    def _create_progress(self, desc: str, total: int, workers: int):
        """Create a Rich progress display if available."""
        try:
            from rich.progress import (
                Progress, SpinnerColumn, BarColumn, TextColumn,
                TimeElapsedColumn, TimeRemainingColumn, MofNCompleteColumn,
            )
            from eemoclas.cli.utils import console

            progress = Progress(
                SpinnerColumn(),
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                MofNCompleteColumn(),
                TimeElapsedColumn(),
                TimeRemainingColumn(),
                console=console,
                transient=False,
            )
            task_id = progress.add_task(desc, total=total)
            progress.start()

            # Wrapper to allow advance via task_id
            class _ProgressWrapper:
                def __init__(self, progress, task_id):
                    self._progress = progress
                    self._task_id = task_id

                def advance(self, advance=1):
                    self._progress.advance(self._task_id, advance=advance)

                def stop(self):
                    self._progress.stop()

            return _ProgressWrapper(progress, task_id)
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def save_sample(self, sample: dict, sample_id: str) -> str:
        """Save a sample dictionary as a ``.pt`` file.

        Parameters
        ----------
        sample : dict
            Arbitrary payload (tensors, strings, lists, etc.).
        sample_id : str
            Unique identifier used as the file name (without extension).

        Returns
        -------
        str
            Absolute path to the saved file.
        """
        path = self.samples_dir / f"{sample_id}.pt"
        torch.save(sample, str(path))
        return str(path)

    def write_manifest(self, rows: list[dict]) -> None:
        """Write a list of row-dicts as ``manifest.csv``.

        Duplicates (by ``sample_id``) are removed before writing.
        Path columns (``sample_path``, ``raw_sample_path``) are normalised
        to forward slashes for cross-platform (Windows/Linux) compatibility.

        Parameters
        ----------
        rows : list[dict]
            Each dict represents one row in the manifest.
        """
        if not rows:
            # Write an empty CSV so downstream tools don't break.
            pd.DataFrame().to_csv(self.output_dir / "manifest.csv", index=False)
            return
        df = pd.DataFrame(rows)
        if "sample_id" in df.columns:
            before = len(df)
            df = df.drop_duplicates(subset=["sample_id"], keep="first")
            dup_count = before - len(df)
            if dup_count > 0:
                logger.warning(
                    "Removed %d duplicate sample_id(s) from manifest.", dup_count,
                )
        # Normalise path columns to forward slashes for cross-platform compat
        for _col in ("sample_path", "raw_sample_path"):
            if _col in df.columns:
                df[_col] = df[_col].apply(
                    lambda p: str(p).replace("\\", "/") if pd.notna(p) else p
                )
        df.to_csv(self.output_dir / "manifest.csv", index=False)

    def write_stats(self, stats: dict) -> None:
        """Write ``stats.json`` to the output directory.

        Parameters
        ----------
        stats : dict
            Statistics dictionary (JSON-serialisable).
        """
        stats_path = self.output_dir / "stats.json"
        with open(stats_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

    def save_config_snapshot(self) -> None:
        """Save the current config as ``config_snapshot.yaml``."""
        snapshot_path = self.output_dir / "config_snapshot.yaml"
        with open(snapshot_path, "w", encoding="utf-8") as f:
            yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def validate_token_meta(self, x: torch.Tensor, token_meta: list[dict]) -> None:
        """Validate that ``token_meta`` length matches the spatial dimension of *x*.

        For shape ``[C_eff, T]`` or ``[8, C_eff, T]`` the expected length is
        ``C_eff`` (the second-to-last dimension).

        Parameters
        ----------
        x : torch.Tensor
            Data tensor.
        token_meta : list[dict]
            Per-token metadata.

        Raises
        ------
        ValueError
            If the lengths do not match.
        """
        expected = x.shape[-2]
        actual = len(token_meta)
        if actual != expected:
            raise ValueError(
                f"token_meta length {actual} != C_eff {expected}"
            )
