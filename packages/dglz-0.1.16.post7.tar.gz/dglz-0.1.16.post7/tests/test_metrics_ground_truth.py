"""Tests for ground truth resolution."""

import pandas as pd
import pytest

from eemoclas.metrics.ground_truth import resolve_ground_truth


class TestResolveGroundTruth:
    def _make_pred_df(self, n=4):
        return pd.DataFrame({
            "sample_id": [f"s{i}" for i in range(n)],
            "y_pred": [0, 1, 1, 0][:n],
        })

    def _make_manifest_df(self, n=4):
        return pd.DataFrame({
            "sample_id": [f"s{i}" for i in range(n)],
            "group_label": [0, 1, 1, 0][:n],
            "emotion_label": [0, 1, 0, 1][:n],
        })

    def test_from_ground_truth_csv_by_sample_id(self, tmp_path):
        pred_df = self._make_pred_df()
        manifest_df = self._make_manifest_df()
        gt_path = str(tmp_path / "gt.csv")
        pd.DataFrame({"sample_id": ["s0", "s1", "s2", "s3"], "label": [0, 1, 1, 0]}).to_csv(gt_path, index=False)

        result = resolve_ground_truth(pred_df, manifest_df, ground_truth_path=gt_path, label_column="label")
        assert result is not None
        assert len(result) == 4
        assert list(result) == [0, 1, 1, 0]

    def test_from_manifest_group_label(self):
        pred_df = self._make_pred_df()
        manifest_df = self._make_manifest_df()
        result = resolve_ground_truth(pred_df, manifest_df, label_column="group_label")
        assert result is not None
        assert len(result) == 4

    def test_no_ground_truth_returns_none(self):
        pred_df = self._make_pred_df()
        manifest_df = pd.DataFrame({"sample_id": ["s0", "s1", "s2", "s3"]})
        result = resolve_ground_truth(pred_df, manifest_df)
        assert result is None

    def test_by_subject_id(self, tmp_path):
        pred_df = pd.DataFrame({
            "subject_id": ["sub0", "sub1"],
            "y_pred": [0, 1],
        })
        manifest_df = pd.DataFrame({
            "subject_id": ["sub0", "sub1"],
            "group_label": [0, 1],
        })
        result = resolve_ground_truth(pred_df, manifest_df, label_column="group_label")
        assert result is not None
        assert list(result) == [0, 1]

    def test_ground_truth_csv_row_aligned(self, tmp_path):
        pred_df = pd.DataFrame({"y_pred": [0, 1]})
        manifest_df = pd.DataFrame({"sample_id": ["s0", "s1"]})
        gt_path = str(tmp_path / "gt.csv")
        pd.DataFrame({"label": [0, 1]}).to_csv(gt_path, index=False)

        result = resolve_ground_truth(pred_df, manifest_df, ground_truth_path=gt_path, label_column="label")
        assert result is not None
        assert list(result) == [0, 1]
