"""Tests for eemo tool data-to-batchs-index CLI command."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest
from typer.testing import CliRunner

from eemoclas.cli.tool_cmd import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def manifest_csv(tmp_path: Path) -> Path:
    """Create a small manifest CSV for testing."""
    rows = []
    for i in range(20):
        rows.append({
            "sample_id": f"sample_{i:04d}",
            "sample_path": f"samples/sample_{i:04d}.pt",
            "subject_id": f"sub_{i % 5}",
            "group_label": i % 2,
        })
    csv_path = tmp_path / "manifest.csv"
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    return csv_path


@pytest.fixture
def batch_config_json(tmp_path: Path) -> Path:
    """Create a batch config JSON file."""
    config = {"batch_sizes": [5, 5], "seed": 42}
    config_path = tmp_path / "batch_config.json"
    with open(config_path, "w") as f:
        json.dump(config, f)
    return config_path


class TestToolCmd:
    def test_batch_sizes_success(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-s", "42",
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()
        assert (tmp_path / "out" / "batch_002.csv").exists()
        assert (tmp_path / "out" / "remainder.csv").exists()

    def test_batch_config_success(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path, batch_config_json: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-c", str(batch_config_json),
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()

    def test_neither_sizes_nor_config(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
        ])
        assert result.exit_code == 1

    def test_both_sizes_and_config(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path, batch_config_json: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-c", str(batch_config_json),
        ])
        assert result.exit_code == 1

    def test_missing_manifest(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(tmp_path / "nonexistent.csv"),
            "-o", str(tmp_path / "out"),
            "-b", "5",
        ])
        assert result.exit_code == 1

    def test_verbose_output(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "-v",
        ])
        assert result.exit_code == 0
        # Verbose mode should include summary info
        assert "总样本" in result.output or "batch" in result.output.lower()

    def test_ratios_with_random_mode(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "--ratios", "0.5,0.3,0.2",
            "-s", "42",
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()
        assert (tmp_path / "out" / "batch_002.csv").exists()
        assert (tmp_path / "out" / "batch_003.csv").exists()

    def test_ratios_conflict_with_batch_sizes(self, runner: CliRunner, manifest_csv: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(manifest_csv),
            "-o", str(tmp_path / "out"),
            "-b", "5,5",
            "--ratios", "0.5,0.5",
        ])
        assert result.exit_code == 1


class TestSubjectMode:
    """Tests for --mode subject (subject-isolated batching)."""

    @pytest.fixture
    def subject_manifest(self, tmp_path: Path) -> Path:
        """Manifest with 4 subjects, 5 samples each, group_label balanced."""
        rows = []
        for sub_idx, sub_id in enumerate(["sub_A", "sub_B", "sub_C", "sub_D"]):
            gl = sub_idx % 2  # 0, 1, 0, 1
            for j in range(5):
                rows.append({
                    "sample_id": f"s_{sub_id}_{j}",
                    "sample_path": f"samples/s_{sub_id}_{j}.pt",
                    "subject_id": sub_id,
                    "group_label": gl,
                })
        csv_path = tmp_path / "manifest.csv"
        pd.DataFrame(rows).to_csv(csv_path, index=False)
        return csv_path

    def test_subject_isolation(self, runner: CliRunner, subject_manifest: Path, tmp_path: Path):
        """All samples from same subject must be in the same batch."""
        result = runner.invoke(app, [
            "-m", str(subject_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "subject",
            "-b", "10,10",
            "-s", "42",
        ])
        assert result.exit_code == 0

        # Check each batch: no subject should appear in multiple batches
        all_batches_subjects: list[set[str]] = []
        for batch_file in ["batch_001.csv", "batch_002.csv"]:
            batch_df = pd.read_csv(tmp_path / "out" / batch_file)
            subjects_in_batch = set(batch_df["subject_id"])
            all_batches_subjects.append(subjects_in_batch)

        # No overlap between batches
        assert all_batches_subjects[0].isdisjoint(all_batches_subjects[1])

    def test_subject_mode_verbose(self, runner: CliRunner, subject_manifest: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(subject_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "subject",
            "-b", "10,10",
            "-s", "42",
            "-v",
        ])
        assert result.exit_code == 0
        assert "Subject" in result.output or "subject" in result.output.lower()

    def test_subject_with_ratios(self, runner: CliRunner, subject_manifest: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(subject_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "subject",
            "--ratios", "0.5,0.5",
            "-s", "42",
        ])
        assert result.exit_code == 0


class TestStratifiedSubjectMode:
    """Tests for --mode stratified_subject (subject-isolated + stratified)."""

    @pytest.fixture
    def stratified_manifest(self, tmp_path: Path) -> Path:
        """Manifest with 6 subjects, balanced group_labels, varying sample counts."""
        rows = []
        # Group 0 (healthy): sub_A(6 samples), sub_C(4 samples), sub_E(5 samples)
        # Group 1 (depressed): sub_B(6 samples), sub_D(4 samples), sub_F(5 samples)
        subjects = [
            ("sub_A", 0, 6), ("sub_B", 1, 6),
            ("sub_C", 0, 4), ("sub_D", 1, 4),
            ("sub_E", 0, 5), ("sub_F", 1, 5),
        ]
        for sub_id, gl, n_samples in subjects:
            for j in range(n_samples):
                rows.append({
                    "sample_id": f"s_{sub_id}_{j}",
                    "sample_path": f"samples/s_{sub_id}_{j}.pt",
                    "subject_id": sub_id,
                    "group_label": gl,
                })
        csv_path = tmp_path / "manifest.csv"
        pd.DataFrame(rows).to_csv(csv_path, index=False)
        return csv_path

    def test_stratified_subject_isolation(
        self, runner: CliRunner, stratified_manifest: Path, tmp_path: Path,
    ):
        """Subjects should not be split across batches."""
        result = runner.invoke(app, [
            "-m", str(stratified_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "stratified_subject",
            "-b", "15,15",
            "-s", "42",
        ])
        assert result.exit_code == 0

        all_subjects: list[set[str]] = []
        for batch_file in ["batch_001.csv", "batch_002.csv"]:
            batch_df = pd.read_csv(tmp_path / "out" / batch_file)
            all_subjects.append(set(batch_df["subject_id"]))

        # No subject in more than one batch
        assert all_subjects[0].isdisjoint(all_subjects[1])

    def test_stratified_label_balance(
        self, runner: CliRunner, stratified_manifest: Path, tmp_path: Path,
    ):
        """Each batch should have roughly balanced group_label counts."""
        result = runner.invoke(app, [
            "-m", str(stratified_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "stratified_subject",
            "-b", "15,15",
            "-s", "42",
        ])
        assert result.exit_code == 0

        for batch_file in ["batch_001.csv", "batch_002.csv"]:
            batch_df = pd.read_csv(tmp_path / "out" / batch_file)
            gl_counts = batch_df["group_label"].value_counts()
            # Each batch should have both labels
            assert len(gl_counts) == 2
            # Ratio should be roughly 1:1 (within tolerance)
            ratio = gl_counts[0] / gl_counts[1]
            assert 0.3 < ratio < 3.0

    def test_stratified_verbose(
        self, runner: CliRunner, stratified_manifest: Path, tmp_path: Path,
    ):
        result = runner.invoke(app, [
            "-m", str(stratified_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "stratified_subject",
            "-b", "15,15",
            "-s", "42",
            "-v",
        ])
        assert result.exit_code == 0
        # Verbose should show label distribution
        assert "标签分布" in result.output or "group_" in result.output

    def test_stratified_with_ratios(
        self, runner: CliRunner, stratified_manifest: Path, tmp_path: Path,
    ):
        result = runner.invoke(app, [
            "-m", str(stratified_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "stratified_subject",
            "--ratios", "0.5,0.25,0.25",
            "-s", "42",
        ])
        assert result.exit_code == 0
        assert (tmp_path / "out" / "batch_001.csv").exists()
        assert (tmp_path / "out" / "batch_002.csv").exists()
        assert (tmp_path / "out" / "batch_003.csv").exists()

    def test_invalid_mode(self, runner: CliRunner, stratified_manifest: Path, tmp_path: Path):
        result = runner.invoke(app, [
            "-m", str(stratified_manifest),
            "-o", str(tmp_path / "out"),
            "--mode", "invalid",
            "-b", "10,10",
        ])
        assert result.exit_code == 1
