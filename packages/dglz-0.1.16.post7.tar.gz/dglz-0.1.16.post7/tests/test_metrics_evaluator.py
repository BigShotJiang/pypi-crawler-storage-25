"""Tests for metrics evaluator."""

import numpy as np
import pytest

from eemoclas.metrics.evaluator import EvaluationResult, evaluate


class TestEvaluate:
    def test_perfect_binary(self):
        y_true = np.array([0, 0, 1, 1, 0, 1, 1, 0])
        y_pred = np.array([0, 0, 1, 1, 0, 1, 1, 0])
        y_prob = np.array([0.1, 0.2, 0.9, 0.8, 0.3, 0.7, 0.85, 0.15])
        result = evaluate(y_true, y_pred, y_prob)
        assert result.accuracy == 1.0
        assert result.auc == 1.0
        assert result.macro_f1 == 1.0
        assert result.n_samples == 8

    def test_no_prob_auc_is_none(self):
        y_true = np.array([0, 1, 1, 0])
        y_pred = np.array([0, 1, 0, 0])
        result = evaluate(y_true, y_pred)
        assert result.auc is None
        assert result.accuracy == 0.75
        assert result.n_samples == 4

    def test_length_mismatch_raises(self):
        y_true = np.array([0, 1])
        y_pred = np.array([0])
        with pytest.raises(ValueError, match="length"):
            evaluate(y_true, y_pred)

    def test_single_class_macro_f1(self):
        y_true = np.array([1, 1, 1])
        y_pred = np.array([1, 1, 1])
        result = evaluate(y_true, y_pred)
        assert result.accuracy == 1.0
        assert result.macro_f1 == pytest.approx(0.5)

    def test_evaluation_result_dataclass(self):
        r = EvaluationResult(accuracy=0.9, auc=0.85, macro_f1=0.88, n_samples=100)
        assert r.accuracy == 0.9
        assert r.auc == 0.85
