"""Tests for Ctrl+C graceful shutdown handling."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


class TestMainInterrupt:
    """Layer 1: main.py global KeyboardInterrupt fallback."""

    def test_keyboard_interrupt_exits_130(self):
        """main() catches KeyboardInterrupt and raises SystemExit(130)."""
        from eemoclas.cli.main import main

        with patch("eemoclas.cli.main.app") as mock_app:
            mock_app.side_effect = KeyboardInterrupt()
            with patch("eemoclas.cli.version_check.notify_if_update_available"):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 130

    def test_systemexit_zero_returns_normally(self):
        """main() returns normally when SystemExit(0) is raised."""
        from eemoclas.cli.main import main

        with patch("eemoclas.cli.main.app") as mock_app:
            mock_app.side_effect = SystemExit(0)
            with patch("eemoclas.cli.version_check.notify_if_update_available"):
                # SystemExit(0) is caught; exit_code=0 so no re-raise
                main()

    def test_systemexit_nonzero_passes_through(self):
        """main() lets SystemExit(1) pass without modification."""
        from eemoclas.cli.main import main

        with patch("eemoclas.cli.main.app") as mock_app:
            mock_app.side_effect = SystemExit(1)
            with patch("eemoclas.cli.version_check.notify_if_update_available"):
                with pytest.raises(SystemExit) as exc_info:
                    main()
                assert exc_info.value.code == 1


class TestTrainImplInterrupt:
    """Layer 2: train_impl.py training entry KeyboardInterrupt."""

    def test_training_interrupt_prints_message(self):
        """run_training() catches KeyboardInterrupt and raises SystemExit(130)."""
        from eemoclas.cli.train_impl import run_training

        with patch("eemoclas.config.loader.load_config") as mock_load, \
             patch("eemoclas.training.experiment.ExperimentManager"), \
             patch("eemoclas.training.orchestrator.MultiModelTrainer") as MockTrainer:
            mock_config = MagicMock()
            mock_config.models = {}
            mock_config.model_names.return_value = []
            mock_config.runtime_config_display_sections.return_value = []
            mock_load.return_value = mock_config
            with patch("eemoclas.config.overrides.apply_overrides"), \
                 patch("eemoclas.utils.logger.setup_experiment_logger"), \
                 patch("eemoclas.utils.display.print_training_config_panel"), \
                 patch("eemoclas.utils.display.print_multi_model_summary"):
                MockTrainer.return_value.run.side_effect = KeyboardInterrupt()
                with pytest.raises(SystemExit) as exc_info:
                    run_training("fake_config.yaml")
                assert exc_info.value.code == 130


class TestTrainerDisplayCleanup:
    """Layer 3: trainer.py display.stop() called in finally."""

    def test_display_stop_called_on_keyboard_interrupt(self, tmp_path):
        """Trainer.fit() calls display.stop() even when KeyboardInterrupt fires."""
        from eemoclas.training.trainer import Trainer
        import torch

        model = torch.nn.Linear(10, 2)
        mock_display = MagicMock()
        call_count = [0]
        def train_epoch_side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] >= 2:
                raise KeyboardInterrupt()
            return {"loss": 0.5, "accuracy": 0.7}

        trainer = Trainer.__new__(Trainer)
        trainer.model = model
        trainer.optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        trainer.criterion = torch.nn.CrossEntropyLoss()
        trainer.scheduler = None
        trainer.epochs = 5
        trainer.device = torch.device("cpu")
        trainer.log_dir = tmp_path / "logs"
        trainer.log_dir.mkdir(parents=True, exist_ok=True)
        trainer.checkpoint_dir = tmp_path / "ckpts"
        trainer.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        trainer.config = {"training": {}}
        trainer.save_latest = False
        trainer._start_time = 0
        trainer._monitor_metric = "val_loss"
        trainer._monitor_mode = "min"
        trainer._save_best_auc = False
        trainer._save_best_acc = False
        trainer._best_metrics_snapshot = None
        trainer._es_enable = False
        trainer._swa_start_epoch = 0
        trainer._swa_model = None
        trainer.results_writer = MagicMock()
        trainer._log_epoch = MagicMock()
        trainer._create_display = MagicMock(return_value=mock_display)
        trainer.train_epoch = MagicMock(side_effect=train_epoch_side_effect)
        trainer.validate_epoch = MagicMock(return_value={"loss": 0.6, "accuracy": 0.6})
        trainer.best_metric_value = float("inf")
        trainer.checkpoint_metric = "val_loss"
        trainer.early_stopping = MagicMock()
        trainer._is_multitask = False
        trainer._extra_best_trackers = []
        trainer._checkpoint_interval = 0
        trainer._train_only = False

        dummy_dataset = torch.utils.data.TensorDataset(
            torch.randn(4, 10), torch.randint(0, 2, (4,))
        )
        train_loader = torch.utils.data.DataLoader(dummy_dataset, batch_size=2)
        val_loader = torch.utils.data.DataLoader(dummy_dataset, batch_size=2)

        with patch("eemoclas.training.trainer.save_checkpoint") as mock_save:
            result = trainer.fit(train_loader, val_loader)

        mock_display.stop.assert_called_once()
        assert result["early_stopped"] is True
        mock_save.assert_called()

    def test_display_stop_called_on_normal_exit(self, tmp_path):
        """Trainer.fit() calls display.stop() on normal completion."""
        from eemoclas.training.trainer import Trainer
        import torch

        model = torch.nn.Linear(10, 2)
        mock_display = MagicMock()

        trainer = Trainer.__new__(Trainer)
        trainer.model = model
        trainer.optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        trainer.criterion = torch.nn.CrossEntropyLoss()
        trainer.scheduler = None
        trainer.epochs = 1
        trainer.device = torch.device("cpu")
        trainer.log_dir = tmp_path / "logs"
        trainer.log_dir.mkdir(parents=True, exist_ok=True)
        trainer.checkpoint_dir = tmp_path / "ckpts"
        trainer.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        trainer.config = {"training": {}}
        trainer.save_latest = False
        trainer._start_time = 0
        trainer._monitor_metric = "val_loss"
        trainer._monitor_mode = "min"
        trainer._save_best_auc = False
        trainer._save_best_acc = False
        trainer._best_metrics_snapshot = None
        trainer._es_enable = False
        trainer._swa_start_epoch = 0
        trainer._swa_model = None
        trainer.results_writer = MagicMock()
        trainer._log_epoch = MagicMock()
        trainer._create_display = MagicMock(return_value=mock_display)
        trainer.train_epoch = MagicMock(return_value={"loss": 0.5, "accuracy": 0.7})
        trainer.validate_epoch = MagicMock(return_value={"loss": 0.6, "accuracy": 0.6})
        trainer.best_metric_value = float("inf")
        trainer.checkpoint_metric = "val_loss"
        trainer.early_stopping = MagicMock()
        trainer._is_multitask = False
        trainer._extra_best_trackers = []
        trainer._checkpoint_interval = 0
        trainer._train_only = False

        dummy_dataset = torch.utils.data.TensorDataset(
            torch.randn(4, 10), torch.randint(0, 2, (4,))
        )
        train_loader = torch.utils.data.DataLoader(dummy_dataset, batch_size=2)
        val_loader = torch.utils.data.DataLoader(dummy_dataset, batch_size=2)

        with patch("eemoclas.training.trainer.save_checkpoint"):
            result = trainer.fit(train_loader, val_loader)

        mock_display.stop.assert_called_once()
        assert result is not None


class TestOrchestratorSequentialInterrupt:
    """Layer 3b: _train_sequential() marks model as failed on KeyboardInterrupt."""

    def test_sequential_interrupt_marks_model_failed(self, tmp_path):
        """When KeyboardInterrupt fires mid-model, that model is marked 'failed'."""
        from eemoclas.training.orchestrator import MultiModelTrainer
        from eemoclas.config.dataclasses import Config, ExperimentConfig

        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            models={},
        )
        trainer = MultiModelTrainer(cfg, ["model_a"], mode="sequential")
        trainer._train_single = MagicMock(side_effect=KeyboardInterrupt())

        # Spy on the real ExperimentManager's update_model_state
        original_update = trainer.experiment_mgr.update_model_state
        calls = []
        def spy_update(*args, **kwargs):
            calls.append((args, kwargs))
            return original_update(*args, **kwargs)
        trainer.experiment_mgr.update_model_state = spy_update

        with pytest.raises(KeyboardInterrupt):
            trainer._train_sequential(["model_a"])

        # Verify model_a was marked as failed
        assert any(
            args[0] == "model_a" and args[1] == "failed"
            for args, kwargs in calls
        ), f"Expected ('model_a', 'failed') in calls, got {calls}"


class TestOrchestratorParallelJoinTimeout:
    """Layer 3b: _train_parallel uses join(timeout) + terminate."""

    def test_parallel_join_uses_timeout(self, tmp_path):
        """_train_parallel calls p.join(timeout=3600) not p.join()."""
        from eemoclas.training.orchestrator import MultiModelTrainer
        from eemoclas.config.dataclasses import Config, ExperimentConfig
        import inspect

        cfg = Config(
            experiment=ExperimentConfig(name="test", save_dir=str(tmp_path)),
            models={},
        )
        trainer = MultiModelTrainer(cfg, ["m1"], mode="parallel")
        source = inspect.getsource(trainer._train_parallel)
        assert "join(timeout=" in source


class TestPreloadDisplayCleanup:
    """Layer 3c: PreloadDisplay __del__ + stop()."""

    def test_preload_display_del_no_live(self):
        """PreloadDisplay.__del__ with no Live instance doesn't error."""
        from eemoclas.datasets.preloaded_dataset import PreloadDisplay

        display = PreloadDisplay("test_model", verbose=False)
        display.__del__()  # should not raise

    def test_preload_display_del_with_live(self):
        """PreloadDisplay.__del__ calls stop() on Live instance."""
        from eemoclas.datasets.preloaded_dataset import PreloadDisplay

        display = PreloadDisplay.__new__(PreloadDisplay)
        display._verbose = True
        mock_live = MagicMock()
        display._live = mock_live
        display._model_name = "test"

        display.__del__()
        mock_live.stop.assert_called_once()

    def test_preload_display_del_safe_on_shutdown(self):
        """PreloadDisplay.__del__ doesn't crash if Live.stop() raises."""
        from eemoclas.datasets.preloaded_dataset import PreloadDisplay

        display = PreloadDisplay.__new__(PreloadDisplay)
        display._verbose = True
        mock_live = MagicMock()
        mock_live.stop.side_effect = RuntimeError("interpreter shutdown")
        display._live = mock_live
        display._model_name = "test"

        display.__del__()  # should not raise


class TestResamplerInterrupt:
    """Layer 3d: base_resampler interrupt handling."""

    def test_resampler_parallel_cancels_futures_on_interrupt(self):
        """_parallel_map cancels futures on KeyboardInterrupt."""
        from eemoclas.resampling.base_resampler import BaseResampler

        # Create a concrete subclass to avoid abstract instantiation error
        class ConcreteResampler(BaseResampler):
            def run(self):
                pass

        resampler = ConcreteResampler.__new__(ConcreteResampler)
        resampler._workers = 2

        mock_future = MagicMock()
        mock_future.result.side_effect = KeyboardInterrupt()

        with patch("eemoclas.resampling.base_resampler.multiprocessing") as mock_mp, \
             patch("eemoclas.resampling.base_resampler.ProcessPoolExecutor") as MockPool, \
             patch("eemoclas.resampling.base_resampler.as_completed", return_value=[mock_future]):
            mock_ctx = MagicMock()
            mock_mp.get_context.return_value = mock_ctx
            mock_pool = MagicMock()
            MockPool.return_value.__enter__ = MagicMock(return_value=mock_pool)
            MockPool.return_value.__exit__ = MagicMock(return_value=False)
            mock_pool.submit.return_value = mock_future

            with pytest.raises(KeyboardInterrupt):
                resampler._parallel_map(
                    func=lambda x: [{"a": 1}],
                    items=["item1", "item2"],
                    desc="test",
                )

            mock_pool.shutdown.assert_called_with(wait=False, cancel_futures=True)
