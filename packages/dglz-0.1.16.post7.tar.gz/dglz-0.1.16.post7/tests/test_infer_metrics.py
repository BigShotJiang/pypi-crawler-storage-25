# tests/test_infer_metrics.py
"""Integration tests for infer-three-stage batch-index and metrics."""

import inspect

import pytest

from eemoclas.cli.infer_three_stage_cmd import infer_three_stage


class TestInferThreeStageParams:
    def test_cli_accepts_batch_index_params(self):
        """CLI accepts all new parameters."""
        sig = inspect.signature(infer_three_stage)
        param_names = set(sig.parameters)
        assert "batch_index" in param_names
        assert "ground_truth" in param_names
        assert "label_col" in param_names
        assert "metrics_output" in param_names
