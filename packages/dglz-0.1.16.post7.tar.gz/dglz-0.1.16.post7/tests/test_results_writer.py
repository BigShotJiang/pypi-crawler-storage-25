"""Tests for ResultsWriter (CSV + background plot generation)."""
from __future__ import annotations

import csv
from pathlib import Path

import pytest

from eemoclas.training.results_writer import ResultsWriter, CSV_COLUMNS


class TestResultsWriterInit:
    """Tests for ResultsWriter initialization."""

    def test_creates_directories(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        assert (tmp_path / "results").is_dir()
        assert (tmp_path / "results" / "plot" / "single").is_dir()
        assert (tmp_path / "results" / "plot" / "compare").is_dir()

    def test_creates_csv_with_header(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.finalize()
        csv_path = tmp_path / "results" / "metrics.csv"
        assert csv_path.exists()
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            assert reader.fieldnames == CSV_COLUMNS


class TestResultsWriterAppend:
    """Tests for epoch data appending."""

    def test_append_writes_csv_row(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5, "train_accuracy": 0.8})
        rw.finalize()
        csv_path = tmp_path / "results" / "metrics.csv"
        with open(csv_path) as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 1
        assert rows[0]["epoch"] == "1"
        assert rows[0]["train_loss"] == "0.500000"

    def test_append_accumulates_history(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw.append_epoch({"epoch": 2, "train_loss": 0.4})
        assert len(rw._history) == 2
        rw.finalize()

    def test_floats_formatted_to_6_decimals(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.123456789})
        rw.finalize()
        csv_path = tmp_path / "results" / "metrics.csv"
        with open(csv_path) as f:
            rows = list(csv.DictReader(f))
        assert rows[0]["train_loss"] == "0.123457"


class TestResultsWriterResume:
    """Tests for CSV resume/trim behavior."""

    def test_loads_existing_csv(self, tmp_path: Path):
        rw1 = ResultsWriter(tmp_path / "results")
        rw1.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw1.append_epoch({"epoch": 2, "train_loss": 0.4})
        rw1.finalize()

        rw2 = ResultsWriter(tmp_path / "results")
        assert len(rw2._history) == 2
        assert rw2._history[0]["epoch"] == 1
        rw2.finalize()

    def test_trim_after_epoch(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw.append_epoch({"epoch": 2, "train_loss": 0.4})
        rw.append_epoch({"epoch": 3, "train_loss": 0.3})
        rw.trim_after_epoch(2)
        assert len(rw._history) == 2
        rw.finalize()

    def test_trim_rewrites_csv(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw.append_epoch({"epoch": 2, "train_loss": 0.4})
        rw.append_epoch({"epoch": 3, "train_loss": 0.3})
        rw.trim_after_epoch(1)
        rw.finalize()
        csv_path = tmp_path / "results" / "metrics.csv"
        with open(csv_path) as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 1
        assert rows[0]["epoch"] == "1"

    def test_consistency_check_trims_extra_rows(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw.append_epoch({"epoch": 2, "train_loss": 0.4})
        rw.append_epoch({"epoch": 3, "train_loss": 0.3})
        rw.verify_consistency(checkpoint_epoch=1)
        assert len(rw._history) == 2  # epochs 1 and 2 (0-based: epoch <= 1+1)
        rw.finalize()

    def test_load_history_from_list(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        history = [{"epoch": i, "train_loss": 0.5 / i} for i in range(1, 4)]
        rw.load_history(history)
        assert len(rw._history) == 3
        rw.finalize()


class TestResultsWriterPlot:
    """Tests for plot generation."""

    def test_generates_single_plots(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        for i in range(1, 6):
            rw.append_epoch({"epoch": i, "train_loss": 0.5 / i, "val_loss": 0.6 / i,
                             "train_accuracy": 0.5 + 0.1 * i, "val_accuracy": 0.5 + 0.08 * i,
                             "val_auc": 0.6 + 0.05 * i, "val_macro_f1": 0.5 + 0.03 * i,
                             "lr": 0.001, "epoch_time": 10.0 + i})
        rw.finalize()
        single_dir = tmp_path / "results" / "plot" / "single"
        assert (single_dir / "train_loss.png").exists()
        assert (single_dir / "val_loss.png").exists()
        assert (single_dir / "train_accuracy.png").exists()
        assert (single_dir / "val_accuracy.png").exists()

    def test_generates_compare_plots(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        for i in range(1, 6):
            rw.append_epoch({"epoch": i, "train_loss": 0.5 / i, "val_loss": 0.6 / i,
                             "train_accuracy": 0.5 + 0.1 * i, "val_accuracy": 0.5 + 0.08 * i})
        rw.finalize()
        compare_dir = tmp_path / "results" / "plot" / "compare"
        assert (compare_dir / "compare_loss.png").exists()
        assert (compare_dir / "compare_accuracy.png").exists()

    def test_no_plot_for_all_none_metric(self, tmp_path: Path):
        rw = ResultsWriter(tmp_path / "results")
        rw.append_epoch({"epoch": 1, "train_loss": 0.5})
        rw.finalize()
        single_dir = tmp_path / "results" / "plot" / "single"
        assert (single_dir / "train_loss.png").exists()

    def test_train_only_generates_train_auc_plot(self, tmp_path: Path):
        """Train-only mode produces train_auc and train_macro_f1 plots."""
        rw = ResultsWriter(tmp_path / "results")
        rw.set_train_only(True)
        for i in range(1, 4):
            rw.append_epoch({
                "epoch": i, "train_loss": 0.5 / i,
                "train_accuracy": 0.5 + 0.1 * i,
                "train_auc": 0.6 + 0.05 * i,
                "train_macro_f1": 0.5 + 0.03 * i,
                "lr": 0.001, "epoch_time": 10.0,
            })
        rw.finalize()
        single_dir = tmp_path / "results" / "plot" / "single"
        assert (single_dir / "train_loss.png").exists()
        assert (single_dir / "train_accuracy.png").exists()
        assert (single_dir / "train_auc.png").exists()
        assert (single_dir / "train_macro_f1.png").exists()
        # No val plots
        assert not list(single_dir.glob("val_*.png"))

    def test_train_only_no_compare_plots(self, tmp_path: Path):
        """Train-only mode skips compare plots."""
        rw = ResultsWriter(tmp_path / "results")
        rw.set_train_only(True)
        for i in range(1, 4):
            rw.append_epoch({
                "epoch": i, "train_loss": 0.5 / i,
                "train_accuracy": 0.5 + 0.1 * i,
                "lr": 0.001, "epoch_time": 10.0,
            })
        rw.finalize()
        compare_dir = tmp_path / "results" / "plot" / "compare"
        assert not list(compare_dir.glob("compare_*.png"))

    def test_train_only_csv_excludes_val_columns(self, tmp_path: Path):
        """Train-only mode CSV header has no val_* columns."""
        rw = ResultsWriter(tmp_path / "results")
        rw.set_train_only(True)
        rw.append_epoch({
            "epoch": 1, "train_loss": 0.5, "train_accuracy": 0.7,
            "train_auc": 0.85, "train_macro_f1": 0.68,
            "lr": 0.001, "epoch_time": 10.0,
        })
        rw.finalize()
        csv_path = tmp_path / "results" / "metrics.csv"
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            assert reader.fieldnames is not None
            assert not any(c.startswith("val_") for c in reader.fieldnames)

    def test_train_only_cleans_stale_val_plots(self, tmp_path: Path):
        """set_train_only removes leftover val_*.png from a prior run."""
        rw = ResultsWriter(tmp_path / "results")
        # First run with validation
        for i in range(1, 4):
            rw.append_epoch({
                "epoch": i, "train_loss": 0.5 / i, "val_loss": 0.6 / i,
                "train_accuracy": 0.5 + 0.1 * i, "val_accuracy": 0.5 + 0.08 * i,
            })
        rw.finalize()
        single_dir = tmp_path / "results" / "plot" / "single"
        assert (single_dir / "val_loss.png").exists()

        # Second run in train-only mode on same dir
        rw2 = ResultsWriter(tmp_path / "results")
        rw2.set_train_only(True)
        rw2.finalize()
        assert not (single_dir / "val_loss.png").exists()
