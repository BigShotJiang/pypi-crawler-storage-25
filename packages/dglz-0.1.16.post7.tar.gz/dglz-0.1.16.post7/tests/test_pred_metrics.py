# tests/test_pred_metrics.py
"""Integration tests for eemo pred with batch-index and metrics."""

import inspect

import pytest


class TestPredBatchIndex:
    def test_cli_accepts_batch_index_params(self):
        """CLI accepts all new parameters."""
        from eemoclas.cli.predict_impl import run_predict
        sig = inspect.signature(run_predict)
        param_names = set(sig.parameters)
        assert "batch_index_path" in param_names
        assert "ground_truth_path" in param_names
        assert "label_col" in param_names
        assert "metrics_output_path" in param_names
