"""Tests for metrics display utilities."""

import pandas as pd
import pytest

from eemoclas.metrics.display import print_metrics, save_metrics_csv
from eemoclas.metrics.evaluator import EvaluationResult


class TestSaveMetricsCsv:
    def test_save_single_result(self, tmp_path):
        result = EvaluationResult(accuracy=0.9, auc=0.85, macro_f1=0.88, n_samples=100)
        out_path = str(tmp_path / "metrics.csv")
        save_metrics_csv(result, out_path, label="subject_state")

        df = pd.read_csv(out_path)
        assert len(df) == 1
        assert df.iloc[0]["label"] == "subject_state"
        assert df.iloc[0]["accuracy"] == pytest.approx(0.9)
        assert df.iloc[0]["auc"] == pytest.approx(0.85)
        assert df.iloc[0]["macro_f1"] == pytest.approx(0.88)
        assert df.iloc[0]["n_samples"] == 100

    def test_save_no_auc(self, tmp_path):
        result = EvaluationResult(accuracy=0.8, auc=None, macro_f1=0.75, n_samples=50)
        out_path = str(tmp_path / "metrics.csv")
        save_metrics_csv(result, out_path, label="normal_emotion")

        df = pd.read_csv(out_path)
        assert df.iloc[0]["auc"] == "" or pd.isna(df.iloc[0]["auc"])

    def test_save_appends_to_existing(self, tmp_path):
        r1 = EvaluationResult(accuracy=0.9, auc=0.85, macro_f1=0.88, n_samples=100)
        r2 = EvaluationResult(accuracy=0.7, auc=0.72, macro_f1=0.68, n_samples=80)
        out_path = str(tmp_path / "metrics.csv")
        save_metrics_csv(r1, out_path, label="routing")
        save_metrics_csv(r2, out_path, label="overall", append=True)

        df = pd.read_csv(out_path)
        assert len(df) == 2
        assert df.iloc[0]["label"] == "routing"
        assert df.iloc[1]["label"] == "overall"


class TestPrintMetrics:
    def test_print_does_not_crash(self):
        from io import StringIO
        from rich.console import Console

        buf = StringIO()
        c = Console(file=buf, force_terminal=True)
        result = EvaluationResult(accuracy=0.9, auc=0.85, macro_f1=0.88, n_samples=100)
        print_metrics(result, "Test Model", c)
        output = buf.getvalue()
        assert "accuracy" in output.lower()
        assert "0.9" in output
