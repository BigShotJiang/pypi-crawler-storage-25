"""Tests for github_update: package metadata helpers and GitHub source functions."""

from __future__ import annotations

import json
from unittest import mock

import pytest


# ---------------------------------------------------------------------------
# parse_github_repo_url
# ---------------------------------------------------------------------------


class TestParseGitHubRepoUrl:
    """Tests for parse_github_repo_url()."""

    def test_https_git_suffix(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        owner, repo = parse_github_repo_url(
            "https://github.com/SuShuheng/dglz.git"
        )
        assert owner == "SuShuheng"
        assert repo == "dglz"

    def test_https_no_git_suffix(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        owner, repo = parse_github_repo_url(
            "https://github.com/SuShuheng/dglz"
        )
        assert owner == "SuShuheng"
        assert repo == "dglz"

    def test_git_plus_https(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        owner, repo = parse_github_repo_url(
            "git+https://github.com/SuShuheng/dglz.git"
        )
        assert owner == "SuShuheng"
        assert repo == "dglz"

    def test_ssh_format(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        owner, repo = parse_github_repo_url(
            "git@github.com:SuShuheng/dglz.git"
        )
        assert owner == "SuShuheng"
        assert repo == "dglz"

    def test_owner_repo_shorthand(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        owner, repo = parse_github_repo_url("SuShuheng/dglz")
        assert owner == "SuShuheng"
        assert repo == "dglz"

    def test_non_github_url_raises_value_error(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError, match="GitHub"):
            parse_github_repo_url("https://gitlab.com/foo/bar.git")

    def test_github_com_in_hostname_rejected(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError, match="GitHub"):
            parse_github_repo_url("https://evilgithub.com/SuShuheng/dglz")

    def test_github_com_subdomain_rejected(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError, match="GitHub"):
            parse_github_repo_url("https://not.github.com.evil.org/SuShuheng/dglz")

    def test_extra_path_segments_rejected(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError, match="extra path"):
            parse_github_repo_url("https://github.com/SuShuheng/dglz-dist/releases/tag/v1")

    def test_trailing_slash_rejected(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        # Trailing slash creates empty third segment
        with pytest.raises(ValueError):
            parse_github_repo_url("https://github.com/SuShuheng/dglz-dist/")

    def test_invalid_shorthand_raises_value_error(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError):
            parse_github_repo_url("onlyonepart")

    def test_empty_string_raises_value_error(self):
        from eemoclas.cli.github_update import parse_github_repo_url

        with pytest.raises(ValueError):
            parse_github_repo_url("")


# ---------------------------------------------------------------------------
# normalize_package_name
# ---------------------------------------------------------------------------


class TestNormalizePackageName:
    """Tests for normalize_package_name()."""

    def test_dglz_lowercase(self):
        from eemoclas.cli.github_update import normalize_package_name

        assert normalize_package_name("DGLZ") == "dglz"

    def test_underscores_to_dashes(self):
        from eemoclas.cli.github_update import normalize_package_name

        assert normalize_package_name("my_package") == "my-package"

    def test_dots_to_dashes(self):
        from eemoclas.cli.github_update import normalize_package_name

        assert normalize_package_name("my.package") == "my-package"

    def test_mixed(self):
        from eemoclas.cli.github_update import normalize_package_name

        assert normalize_package_name("My_Package.Name") == "my-package-name"


# ---------------------------------------------------------------------------
# get_project_package_name
# ---------------------------------------------------------------------------


class TestGetProjectPackageName:
    """Tests for get_project_package_name()."""

    def test_reads_from_pyproject(self, tmp_path):
        from eemoclas.cli.github_update import get_project_package_name

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "DGLZ"\n', encoding="utf-8")

        with mock.patch(
            "eemoclas.cli.github_update._find_pyproject_toml",
            return_value=str(pyproject),
        ):
            assert get_project_package_name() == "DGLZ"

    def test_fallback_to_dglz_on_missing_file(self):
        from eemoclas.cli.github_update import get_project_package_name

        with mock.patch(
            "eemoclas.cli.github_update._find_pyproject_toml",
            return_value="/nonexistent/pyproject.toml",
        ):
            assert get_project_package_name() == "DGLZ"

    def test_fallback_on_invalid_toml(self, tmp_path):
        from eemoclas.cli.github_update import get_project_package_name

        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("this is not valid toml {{{{", encoding="utf-8")

        with mock.patch(
            "eemoclas.cli.github_update._find_pyproject_toml",
            return_value=str(pyproject),
        ):
            assert get_project_package_name() == "DGLZ"


# ---------------------------------------------------------------------------
# github_api_get_json
# ---------------------------------------------------------------------------


class TestGithubApiGetJson:
    """Tests for github_api_get_json()."""

    def test_successful_request(self):
        from eemoclas.cli.github_update import github_api_get_json

        payload = {"tag_name": "v1.0.0"}
        mock_resp = mock.MagicMock()
        mock_resp.read.return_value = json.dumps(payload).encode()
        mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = mock.MagicMock(return_value=False)

        with mock.patch("urllib.request.urlopen", return_value=mock_resp):
            result = github_api_get_json("https://api.github.com/repos/o/r/releases")

        assert result == payload

    def test_404_raises_value_error(self):
        from eemoclas.cli.github_update import github_api_get_json
        import urllib.error

        err = urllib.error.HTTPError(
            url="https://api.github.com/repos/o/r/releases",
            code=404,
            msg="Not Found",
            hdrs=None,
            fp=None,
        )

        with mock.patch("urllib.request.urlopen", side_effect=err):
            with pytest.raises(ValueError):
                github_api_get_json("https://api.github.com/repos/o/r/releases")

    def test_403_raises_connection_error(self):
        """HTTP 403 (rate limit) raises ConnectionError, not ValueError."""
        from eemoclas.cli.github_update import github_api_get_json
        import urllib.error

        err = urllib.error.HTTPError(
            url="https://api.github.com/repos/o/r/releases",
            code=403,
            msg="Forbidden",
            hdrs=None,
            fp=None,
        )

        with mock.patch("urllib.request.urlopen", side_effect=err):
            with pytest.raises(ConnectionError):
                github_api_get_json("https://api.github.com/repos/o/r/releases")

    def test_network_error_raises_connection_error(self):
        from eemoclas.cli.github_update import github_api_get_json

        with mock.patch("urllib.request.urlopen", side_effect=OSError("network")):
            with pytest.raises(ConnectionError):
                github_api_get_json("https://api.github.com/repos/o/r/releases")

    def test_json_parse_error_raises_value_error(self):
        from eemoclas.cli.github_update import github_api_get_json

        mock_resp = mock.MagicMock()
        mock_resp.read.return_value = b"not json"
        mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = mock.MagicMock(return_value=False)

        with mock.patch("urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(ValueError):
                github_api_get_json("https://api.github.com/repos/o/r/releases")

    def test_sets_user_agent_header(self):
        from eemoclas.cli.github_update import github_api_get_json

        payload = {"ok": True}
        mock_resp = mock.MagicMock()
        mock_resp.read.return_value = json.dumps(payload).encode()
        mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = mock.MagicMock(return_value=False)

        with mock.patch("urllib.request.urlopen", return_value=mock_resp) as mock_open:
            github_api_get_json("https://api.github.com/repos/o/r/releases")
            req = mock_open.call_args[0][0]
            assert req.get_header("User-agent") == "eemo-cli-updater"


# ---------------------------------------------------------------------------
# get_github_release
# ---------------------------------------------------------------------------


class TestGetGithubRelease:
    """Tests for get_github_release()."""

    def test_with_tag(self):
        from eemoclas.cli.github_update import get_github_release

        release = {"tag_name": "v1.0.0", "assets": []}

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=release
        ) as mock_api:
            result = get_github_release("owner", "repo", tag="v1.0.0")

        assert result == release
        mock_api.assert_called_once_with(
            "https://api.github.com/repos/owner/repo/releases/tags/v1.0.0"
        )

    def test_without_tag_no_prerelease(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v1.1.0",
                "draft": False,
                "prerelease": True,
                "assets": [{"name": "dglz-1.1.0-py3-none-any.whl"}],
            },
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-1.0.0-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ) as mock_api:
            result = get_github_release("owner", "repo")

        assert result["tag_name"] == "v1.0.0"
        mock_api.assert_called_once_with(
            "https://api.github.com/repos/owner/repo/releases"
        )

    def test_with_prerelease_picks_non_draft_with_wheel(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v2.0.0-beta",
                "draft": True,
                "prerelease": True,
                "assets": [{"name": "dglz-2.0.0b1-py3-none-any.whl"}],
            },
            {
                "tag_name": "v2.0.0-alpha",
                "draft": False,
                "prerelease": True,
                "assets": [{"name": "dglz-2.0.0a1-py3-none-any.whl"}],
            },
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ) as mock_api:
            result = get_github_release("owner", "repo", prerelease=True)

        assert result["tag_name"] == "v2.0.0-alpha"
        mock_api.assert_called_once_with(
            "https://api.github.com/repos/owner/repo/releases"
        )

    def test_with_prerelease_no_suitable_release(self):
        from eemoclas.cli.github_update import get_github_release

        # All releases are draft
        releases = [
            {
                "tag_name": "v2.0.0-beta",
                "draft": True,
                "prerelease": True,
                "assets": [{"name": "dglz-2.0.0b1-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            with pytest.raises(ValueError, match="release"):
                get_github_release("owner", "repo", prerelease=True)

    def test_skips_release_with_unrelated_wheel(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v2.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "other-pkg-2.0.0-py3-none-any.whl"}],
            },
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-1.0.0-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo")

        assert result["tag_name"] == "v1.0.0"


# ---------------------------------------------------------------------------
# select_wheel_asset
# ---------------------------------------------------------------------------


class TestGetGithubReleaseHighestVersion:
    """Tests that get_github_release picks the highest version, not first match."""

    def test_picks_highest_version(self):
        from eemoclas.cli.github_update import get_github_release

        # API returns older release first, newer second
        releases = [
            {
                "tag_name": "v0.1.15",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.15-py3-none-any.whl"}],
            },
            {
                "tag_name": "v0.1.17",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.17-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo")

        assert result["tag_name"] == "v0.1.17"

    def test_skips_lower_version_when_higher_exists(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v0.1.17",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.17-py3-none-any.whl"}],
            },
            {
                "tag_name": "v0.1.15",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.15-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo")

        assert result["tag_name"] == "v0.1.17"

    def test_skips_unrelated_when_higher_exists(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v0.1.15",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "other-pkg-0.1.15-py3-none-any.whl"}],
            },
            {
                "tag_name": "v0.1.17",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.17-py3-none-any.whl"}],
            },
            {
                "tag_name": "v0.1.10",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-0.1.10-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo")

        # Picks v0.1.17 (highest matching dglz-* wheel), not v0.1.15 (unrelated)
        # or v0.1.10 (lower version)
        assert result["tag_name"] == "v0.1.17"


class TestSelectWheelAsset:
    """Tests for select_wheel_asset()."""

    def _release(self, assets: list[dict]) -> dict:
        return {"tag_name": "v1.0.0", "assets": assets}

    def test_selects_matching_wheel(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "source.tar.gz", "browser_download_url": "https://example.com/source.tar.gz"},
            {"name": "dglz-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/dglz.whl"},
        ])
        result = select_wheel_asset(release)
        assert result["name"] == "dglz-1.0.0-py3-none-any.whl"

    def test_prefers_py3_none_any(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "dglz-1.0.0-cp313-cp313-linux_x86_64.whl", "browser_download_url": "https://example.com/linux.whl"},
            {"name": "dglz-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/pure.whl"},
        ])
        result = select_wheel_asset(release)
        assert result["name"] == "dglz-1.0.0-py3-none-any.whl"

    def test_no_wheel_raises_listing_assets(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "source.tar.gz"},
            {"name": "README.md"},
        ])
        with pytest.raises(ValueError, match="source.tar.gz"):
            select_wheel_asset(release)

    def test_custom_asset_pattern(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "dglz-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/a.whl"},
            {"name": "custom-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/b.whl"},
        ])
        result = select_wheel_asset(release, asset_pattern="custom-*.whl")
        assert result["name"] == "custom-1.0.0-py3-none-any.whl"

    def test_multiple_matching_no_clear_winner_raises(self):
        from eemoclas.cli.github_update import select_wheel_asset

        # Two platform-specific wheels, no py3-none-any, no tag match
        release = self._release([
            {"name": "dglz-1.0.0-cp313-cp313-linux_x86_64.whl", "browser_download_url": "https://example.com/linux.whl"},
            {"name": "dglz-1.0.0-cp313-cp313-win_amd64.whl", "browser_download_url": "https://example.com/win.whl"},
        ])

        # packaging.tags is available but no tag matches
        fake_tag = mock.MagicMock()
        fake_tag.__str__ = lambda self: "cp310-cp310-macosx_11_0_arm64"
        with mock.patch("packaging.tags.sys_tags", return_value=[fake_tag]):
            with pytest.raises(ValueError, match="asset.pattern"):
                select_wheel_asset(release)

    def test_single_platform_wheel_succeeds(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "dglz-1.0.0-cp313-cp313-linux_x86_64.whl", "browser_download_url": "https://example.com/linux.whl"},
        ])
        result = select_wheel_asset(release)
        assert result["name"] == "dglz-1.0.0-cp313-cp313-linux_x86_64.whl"

    def test_custom_package_name(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "my-pkg-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/a.whl"},
            {"name": "dglz-1.0.0-py3-none-any.whl", "browser_download_url": "https://example.com/b.whl"},
        ])
        result = select_wheel_asset(release, package_name="my-pkg")
        assert result["name"] == "my-pkg-1.0.0-py3-none-any.whl"

    def test_packaging_tags_picks_compatible_wheel(self):
        from eemoclas.cli.github_update import select_wheel_asset

        release = self._release([
            {"name": "dglz-1.0.0-cp313-cp313-win_amd64.whl", "browser_download_url": "https://example.com/win.whl"},
            {"name": "dglz-1.0.0-cp313-cp313-linux_x86_64.whl", "browser_download_url": "https://example.com/linux.whl"},
        ])

        fake_tag = mock.MagicMock()
        fake_tag.__str__ = lambda self: "cp313-cp313-linux_x86_64"

        with mock.patch("packaging.tags.sys_tags", return_value=[fake_tag]):
            result = select_wheel_asset(release)

        assert result["name"] == "dglz-1.0.0-cp313-cp313-linux_x86_64.whl"


class TestGetGithubReleaseAssetPattern:
    """Tests for asset_pattern parameter in get_github_release()."""

    def test_asset_pattern_matches_release(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v2.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-2.0.0-py3-none-any.whl"}],
            },
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "custom-1.0.0-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo", asset_pattern="custom-*.whl")

        assert result["tag_name"] == "v1.0.0"

    def test_asset_pattern_no_match_raises(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-1.0.0-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            with pytest.raises(ValueError, match="release"):
                get_github_release("owner", "repo", asset_pattern="nonexistent-*.whl")

    def test_no_asset_pattern_uses_package_prefix(self):
        from eemoclas.cli.github_update import get_github_release

        releases = [
            {
                "tag_name": "v1.0.0",
                "draft": False,
                "prerelease": False,
                "assets": [{"name": "dglz-1.0.0-py3-none-any.whl"}],
            },
        ]

        with mock.patch(
            "eemoclas.cli.github_update.github_api_get_json", return_value=releases
        ):
            result = get_github_release("owner", "repo")

        assert result["tag_name"] == "v1.0.0"
