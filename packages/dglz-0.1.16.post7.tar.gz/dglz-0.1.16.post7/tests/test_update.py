"""Tests for eemo update: update_log, version_check modules, and update_cmd."""

from __future__ import annotations

import csv
import io
import json
import os
import sys
import textwrap
from datetime import datetime
from unittest import mock

import pytest
import typer
from click.exceptions import Exit as ClickExit


# ---------------------------------------------------------------------------
# Fixtures: sample CSV data
# ---------------------------------------------------------------------------

SAMPLE_CSV = textwrap.dedent("""\
    version,date,type,title,description,migration_steps
    0.1.12,2026-05-08,feature,eemo update 命令,新增 eemo update 命令,无需额外操作
    0.1.12,2026-05-08,feature,版本自动检测,每次执行 eemo 时自动检测,无需额外操作
    0.1.11.post9,2026-05-08,feature,动态流式内存预加载,自动感知内存变化,无需额外操作
    0.1.11.post8,2026-05-08,fix,预加载面板修复,修复 holdout 模式,无需额外操作
    0.1.11.post7,2026-05-08,fix,预加载面板缺失,修复 BUG,无需额外操作
    0.1.11.post6,2026-05-08,change,移除 balanced_accuracy,统一使用 accuracy,检查脚本引用
    0.1.10,2026-05-08,feature,Focal Loss,新增损失函数,无需额外操作
""")


class TestLoadUpdateLog:
    """Tests for load_update_log()."""

    def test_loads_all_rows(self, tmp_path):
        from eemoclas.cli.update_log import load_update_log

        csv_path = tmp_path / "update_log.csv"
        csv_path.write_text(SAMPLE_CSV, encoding="utf-8")

        with mock.patch("eemoclas.cli.update_log._csv_path", return_value=str(csv_path)):
            rows = load_update_log()

        assert len(rows) == 7
        assert rows[0]["version"] == "0.1.12"
        assert rows[-1]["version"] == "0.1.10"

    def test_each_row_has_required_keys(self, tmp_path):
        from eemoclas.cli.update_log import load_update_log

        csv_path = tmp_path / "update_log.csv"
        csv_path.write_text(SAMPLE_CSV, encoding="utf-8")

        with mock.patch("eemoclas.cli.update_log._csv_path", return_value=str(csv_path)):
            rows = load_update_log()

        required = {"version", "date", "type", "title", "description", "migration_steps"}
        for row in rows:
            assert required.issubset(row.keys())


class TestFilterUpdates:
    """Tests for filter_updates()."""

    def test_filters_between_versions(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.11.post7", "0.1.12")

        versions = {r["version"] for r in result}
        # Should include everything AFTER 0.1.11.post7 up to 0.1.12
        assert "0.1.12" in versions
        assert "0.1.11.post9" in versions
        assert "0.1.11.post8" in versions
        # Should NOT include 0.1.11.post7 (exclusive lower bound) or 0.1.10
        assert "0.1.11.post7" not in versions
        assert "0.1.10" not in versions

    def test_empty_range_when_already_latest(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.12", "0.1.12")
        assert len(result) == 0

    def test_single_version_jump(self):
        from eemoclas.cli.update_log import filter_updates

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        result = filter_updates(rows, "0.1.11.post8", "0.1.11.post9")

        versions = {r["version"] for r in result}
        assert versions == {"0.1.11.post9"}


class TestRenderUpdateMd:
    """Tests for render_update_md()."""

    def test_generates_markdown(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post8", "0.1.11.post9")
        md = render_update_md(filtered, "0.1.11.post8", "0.1.11.post9")

        assert "# DGLZ 更新日志" in md
        assert "V0.1.11.post8" in md
        assert "V0.1.11.post9" in md
        assert "迁移步骤" in md

    def test_changelog_shows_new_to_old(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post7", "0.1.12")
        md = render_update_md(filtered, "0.1.11.post7", "0.1.12")

        # Changelog section: versions appear new-to-old
        pos_0112 = md.index("V0.1.12")
        pos_post9 = md.index("V0.1.11.post9")
        pos_post8 = md.index("V0.1.11.post8")
        assert pos_0112 < pos_post9 < pos_post8

    def test_migration_shows_old_to_new(self):
        from eemoclas.cli.update_log import filter_updates, render_update_md

        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        filtered = filter_updates(rows, "0.1.11.post7", "0.1.12")
        md = render_update_md(filtered, "0.1.11.post7", "0.1.12")

        # Migration section: find "迁移步骤" then check order is old-to-new
        migration_start = md.index("迁移步骤")
        pos_post8_m = md.index("V0.1.11.post8", migration_start)
        pos_post9_m = md.index("V0.1.11.post9", migration_start)
        pos_0112_m = md.index("V0.1.12", migration_start)
        assert pos_post8_m < pos_post9_m < pos_0112_m


# ---------------------------------------------------------------------------
# version_check tests
# ---------------------------------------------------------------------------


class TestVersionCache:
    """Tests for _cache_path, get_cached_latest, save_cache."""

    def test_save_and_load_cache(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest, save_cache

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file), \
             mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_cache("0.1.13")
            result = get_cached_latest()

        assert result == "0.1.13"

    def test_cache_returns_none_when_missing(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file):
            result = get_cached_latest()

        assert result is None

    def test_cache_returns_none_when_expired(self, tmp_path):
        from eemoclas.cli.version_check import get_cached_latest

        cache_file = tmp_path / "version_cache.json"
        with mock.patch("eemoclas.cli.version_check._cache_path", return_value=cache_file):
            # Save with old timestamp
            cache_file.write_text(json.dumps({
                "last_check": "2020-01-01T00:00:00",
                "latest_version": "0.1.12",
            }))
            result = get_cached_latest()

        assert result is None


class TestCheckForUpdate:
    """Tests for check_for_update()."""

    def test_returns_latest_when_update_available(self):
        from eemoclas.cli.version_check import check_for_update

        # Mock PyPI response — must be newer than current __version__
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value =mock_resp

            latest, has_update, error_type = check_for_update()

        assert latest == "0.1.17"
        assert has_update is True
        assert error_type is None

    def test_returns_false_when_already_latest(self):
        from eemoclas.cli.version_check import check_for_update

        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update, error_type = check_for_update()

        assert has_update is False
        assert error_type is None

    def test_returns_none_on_network_error(self):
        from eemoclas.cli.version_check import check_for_update

        with mock.patch("urllib.request.urlopen", side_effect=OSError("timeout")):
            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "network"

    def test_returns_missing_on_404(self):
        from eemoclas.cli.version_check import check_for_update
        import urllib.error

        err = urllib.error.HTTPError(
            url="https://pypi.org/pypi/DGLZ/json",
            code=404,
            msg="Not Found",
            hdrs=None,
            fp=None,
        )

        with mock.patch("urllib.request.urlopen", side_effect=err):
            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "missing"


# ---------------------------------------------------------------------------
# update_cmd tests
# ---------------------------------------------------------------------------


class TestUpdateCommand:
    """Tests for the update CLI command."""

    def test_already_latest(self):
        """When already at latest version, command prints success and exits."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        # GitHub also has no newer
        release = {
            "tag_name": "v0.1.16",
            "assets": [{"name": "dglz-0.1.16-py3-none-any.whl", "browser_download_url": "https://example.com/dglz.whl"}],
        }

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "已是最新" in result.output

    def test_update_available_runs_pip(self):
        """When update available, command runs pip and generates output."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result), \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            # Mock load_update_log to return sample data
            sample_rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
            with mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=sample_rows):
                result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output

    def test_windows_uses_detached_script(self):
        """On Windows, update tries synchronous pip first; on failure falls back to detached .bat."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()
        fail_result = mock.MagicMock(returncode=1, stderr="ERROR: file locked")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=True), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=fail_result), \
             mock.patch("eemoclas.cli.update_cmd._windows_detached_update") as mock_win, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        mock_win.assert_called_once()

    def test_unix_pip_failure_shows_manual_command(self):
        """On Unix, --dist-repo mode pip failure shows error and manual command."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        fail_result = mock.MagicMock(returncode=1, stderr="ERROR: something went wrong")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.github_update.get_github_release") as mock_gh:
            mock_gh.return_value = {
                "tag_name": "v0.1.17",
                "assets": [{
                    "name": "dglz-0.1.17-py3-none-any.whl",
                    "browser_download_url": "https://example.com/dglz.whl",
                }],
            }
            with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
                 mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=fail_result):
                result = runner.invoke(app, ["--dist-repo"])

        assert result.exit_code == 1
        assert "更新失败" in result.output

    def test_network_error_shows_error(self):
        """When PyPI unreachable, command tries GitHub fallback."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("urllib.request.urlopen", side_effect=OSError("timeout")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch(
                 "eemoclas.cli.update_cmd._github_update",
                 side_effect=SystemExit(0),
             ):
            result = runner.invoke(app, [])

        # The GitHub fallback was invoked (exits with 0)
        assert result.exit_code == 0


class TestUpdateLog:
    """Tests for log_update()."""

    def test_appends_log_entry(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.11.post9 -> 0.1.12")

        log_path = tmp_path / "update.log"
        assert log_path.exists()
        content = log_path.read_text(encoding="utf-8")
        assert "SUCCESS | 0.1.11.post9 -> 0.1.12" in content

    def test_log_is_append_mode(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.11.post9 -> 0.1.12")
            log_update("SUCCESS", "0.1.12 -> 0.1.13")

        log_path = tmp_path / "update.log"
        lines = log_path.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 2


class TestLogUpdate:
    """Tests for log_update() structured format."""

    def test_log_update_with_action_and_detail(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.12 -> 0.1.13")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        assert "SUCCESS | 0.1.12 -> 0.1.13" in content

    def test_log_update_action_only(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("ALREADY_LATEST", "0.1.13")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        assert "ALREADY_LATEST | 0.1.13" in content

    def test_log_update_append_mode(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("SUCCESS", "0.1.12 -> 0.1.13")
            log_update("ALREADY_LATEST", "0.1.13")

        log_path = tmp_path / "update.log"
        lines = log_path.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) == 2
        assert "SUCCESS" in lines[0]
        assert "ALREADY_LATEST" in lines[1]

    def test_log_update_has_timestamp(self, tmp_path):
        from eemoclas.cli.version_check import log_update

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            log_update("FAILED", "timeout")

        log_path = tmp_path / "update.log"
        content = log_path.read_text(encoding="utf-8")
        import re
        assert re.match(r"\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\] FAILED", content)


class TestDetectRecord:
    """Tests for save_detect_record()."""

    def test_save_detect_record_success(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", "0.1.13", True, "success")

        detect_path = tmp_path / "update_detect.json"
        assert detect_path.exists()
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert data["current_version"] == "0.1.12"
        assert data["latest_version"] == "0.1.13"
        assert data["has_update"] is True
        assert data["status"] == "success"

    def test_save_detect_record_network_error(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", None, False, "network_error")

        detect_path = tmp_path / "update_detect.json"
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert data["latest_version"] is None
        assert data["has_update"] is False
        assert data["status"] == "network_error"

    def test_detect_record_has_timestamp(self, tmp_path):
        from eemoclas.cli.version_check import save_detect_record

        with mock.patch("eemoclas.cli.version_check._cache_dir", return_value=tmp_path):
            save_detect_record("0.1.12", "0.1.12", False, "cache_hit")

        detect_path = tmp_path / "update_detect.json"
        data = json.loads(detect_path.read_text(encoding="utf-8"))
        assert "last_detect" in data
        datetime.fromisoformat(data["last_detect"])


class TestPlatformCheck:
    """Test _is_windows helper."""

    def test_is_windows_on_win32(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "win32"):
            assert _is_windows() is True

    def test_is_windows_on_linux(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "linux"):
            assert _is_windows() is False

    def test_is_windows_on_darwin(self):
        from eemoclas.cli.update_cmd import _is_windows

        with mock.patch.object(sys, "platform", "darwin"):
            assert _is_windows() is False


class TestBatScriptGeneration:
    """Test _generate_bat_script output."""

    def test_bat_contains_timeout_wait(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "timeout /t 3 /nobreak >nul" in script

    def test_bat_contains_pip_args(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--no-cache-dir", "--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "--no-cache-dir --upgrade DGLZ" in script

    def test_bat_contains_fallback_upgrade(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--no-cache-dir", "--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        # All 3 attempts now use the same pip args with --no-cache-dir
        assert script.count("--no-cache-dir --upgrade DGLZ") >= 1

    def test_bat_contains_log_write(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "update.log" in script
        assert "SUCCESS" in script
        assert "FAILED" in script

    def test_bat_contains_self_delete(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert 'del /f "%~f0"' in script

    def test_bat_creates_log_dir(self):
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--upgrade", "DGLZ"],
            label="0.1.16",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "if not exist" in script
        assert "mkdir" in script

    def test_bat_with_wheel_url(self):
        """GitHub mode: pip args include a URL instead of package name."""
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            pip_args=["--upgrade", "https://example.com/dglz-0.1.16-py3-none-any.whl"],
            label="0.1.16 (GitHub)",
            python_exe=r"C:\Python313\python.exe",
            log_dir=r"C:\Users\test\.dglz",
        )
        assert "https://example.com/dglz-0.1.16-py3-none-any.whl" in script


class TestLinuxRetry:
    """Tests for 3-attempt pip install fallback on Linux/macOS."""

    def test_first_attempt_succeeds(self):
        """Exact version install succeeds on first try."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result) as mock_pip, \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=[]):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert mock_pip.call_count == 1
        mock_pip.assert_called_with(["--no-cache-dir", "--upgrade", "DGLZ"])

    def test_fallback_on_first_failure(self):
        """First install fails, falls back."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        fail_result = mock.MagicMock(returncode=1, stderr="not found")
        success_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail_result, success_result]) as mock_pip, \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=[]):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert mock_pip.call_count == 2

    def test_all_three_attempts_fail(self):
        """All 3 attempts fail in --dist-repo mode -> show error."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        fail_result = mock.MagicMock(returncode=1, stderr="ERROR: something went wrong")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.github_update.get_github_release") as mock_gh:
            mock_gh.return_value = {
                "tag_name": "v0.1.17",
                "assets": [{
                    "name": "dglz-0.1.17-py3-none-any.whl",
                    "browser_download_url": "https://example.com/dglz.whl",
                }],
            }
            with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
                 mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=fail_result) as mock_pip:
                result = runner.invoke(app, ["--dist-repo"])

        assert result.exit_code == 1
        assert "更新失败" in result.output
        assert mock_pip.call_count == 3


# ---------------------------------------------------------------------------
# NEW: Option validation tests
# ---------------------------------------------------------------------------


class TestOptionValidation:
    """Tests for CLI option dependency validation."""

    def test_tag_without_dist_repo_fails(self):
        """--tag without --dist-repo should exit with error."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("eemoclas.cli.update_cmd.log_update"):
            result = runner.invoke(app, ["--tag", "v0.1.16"])

        assert result.exit_code == 1
        assert "--tag" in result.output and "--dist-repo" in result.output

    def test_asset_pattern_without_dist_repo_fails(self):
        """--asset-pattern without --dist-repo should exit with error."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("eemoclas.cli.update_cmd.log_update"):
            result = runner.invoke(app, ["--asset-pattern", "*.whl"])

        assert result.exit_code == 1
        assert "--asset-pattern" in result.output and "--dist-repo" in result.output

    def test_index_url_with_dist_repo_warns(self):
        """--index-url with --dist-repo should warn and ignore."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = {
            "tag_name": "v0.1.17",
            "assets": [{
                "name": "dglz-0.1.17-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz.whl",
            }],
        }

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--index-url", "https://custom.pypi.org/simple",
            ])

        assert "被忽略" in result.output

    def test_extra_index_url_with_dist_repo_warns(self):
        """--extra-index-url with --dist-repo should warn and ignore."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = {
            "tag_name": "v0.1.17",
            "assets": [{
                "name": "dglz-0.1.17-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz.whl",
            }],
        }

        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--extra-index-url", "https://extra.pypi.org/simple",
            ])

        assert "被忽略" in result.output


# ---------------------------------------------------------------------------
# NEW: GitHub mode tests
# ---------------------------------------------------------------------------


class TestGitHubMode:
    """Tests for --dist-repo (explicit GitHub mode)."""

    def _mock_release(self, tag="v0.1.17", version="0.1.17"):
        return {
            "tag_name": tag,
            "assets": [{
                "name": f"dglz-{version}-py3-none-any.whl",
                "browser_download_url": f"https://github.com/SuShuheng/dglz/releases/download/{tag}/dglz-{version}-py3-none-any.whl",
            }],
        }

    def test_dist_repo_uses_github_flow(self):
        """--dist-repo skips PyPI and uses GitHub."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = self._mock_release()
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release) as mock_get, \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, ["--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git"])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert "GitHub Release" in result.output
        mock_get.assert_called_once_with("SuShuheng", "dglz-dist", tag=None, prerelease=False, package_name="DGLZ", asset_pattern=None)

    def test_dist_repo_with_tag(self):
        """--dist-repo --tag installs specific release."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = self._mock_release(tag="v0.1.14", version="0.1.14")
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release) as mock_get, \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--tag", "v0.1.14",
            ])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        mock_get.assert_called_once_with("SuShuheng", "dglz-dist", tag="v0.1.14", prerelease=False, package_name="DGLZ", asset_pattern=None)

    def test_dist_repo_tag_installs_even_if_not_newer(self):
        """With explicit --tag, install even if version is not newer than current."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        # Current version from __version__.py is 0.1.15.post19
        # Use an older version to prove it installs anyway
        release = self._mock_release(tag="v0.1.10", version="0.1.10")
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--tag", "v0.1.10",
            ])

        assert result.exit_code == 0
        assert "更新成功" in result.output

    def test_dist_repo_already_latest(self):
        """Without --tag, GitHub mode reports already latest if no newer version."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        # Use the same version as current
        release = self._mock_release(tag="v0.1.16", version="0.1.16")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            result = runner.invoke(app, ["--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git"])

        assert result.exit_code == 0
        assert "当前已是最新" in result.output

    def test_dist_repo_default_url(self):
        """--dist-repo without value uses default URL."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = self._mock_release()
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release) as mock_get, \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            # Typer with Optional[str] Option(None) -- passing empty string simulates
            # the flag being present. We use "" to test default URL.
            # Actually with Typer, `--dist-repo` without a value will error.
            # The user must provide a value or use `--dist-repo ""`.
            result = runner.invoke(app, ["--dist-repo"])

        assert result.exit_code == 0
        mock_get.assert_called_once_with("SuShuheng", "dglz-dist", tag=None, prerelease=False, package_name="DGLZ", asset_pattern=None)

    def test_dist_repo_pre_flag(self):
        """--dist-repo --pre passes prerelease=True to get_github_release."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = self._mock_release(tag="v0.1.17b1", version="0.1.17b1")
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release) as mock_get, \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--pre",
            ])

        assert result.exit_code == 0
        mock_get.assert_called_once_with("SuShuheng", "dglz-dist", tag=None, prerelease=True, package_name="DGLZ", asset_pattern=None)

    def test_dist_repo_network_error(self):
        """GitHub network error shows error message."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch(
                 "eemoclas.cli.github_update.get_github_release",
                 side_effect=ConnectionError("network error"),
             ):
            result = runner.invoke(app, ["--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git"])

        assert result.exit_code == 1
        assert "无法连接 GitHub" in result.output
        # Should NOT have a raw ConnectionError as the exception
        assert not isinstance(result.exception, ConnectionError)

    def test_dist_repo_release_not_found(self):
        """GitHub release not found shows error message."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch(
                 "eemoclas.cli.github_update.get_github_release",
                 side_effect=ValueError("not found"),
             ):
            result = runner.invoke(app, ["--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git"])

        assert result.exit_code == 1
        assert "未找到发布版本" in result.output

    def test_dist_repo_no_matching_wheel(self):
        """No matching wheel asset shows error message."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = {
            "tag_name": "v0.1.16",
            "assets": [{"name": "source.tar.gz", "browser_download_url": "https://example.com/source.tar.gz"}],
        }

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            result = runner.invoke(app, ["--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git"])

        assert result.exit_code == 1
        assert "未找到匹配的 wheel" in result.output


# ---------------------------------------------------------------------------
# NEW: Dry-run tests
# ---------------------------------------------------------------------------


class TestDryRun:
    """Tests for --dry-run flag."""

    def test_dry_run_pypi_prints_command(self):
        """--dry-run in PyPI mode prints command without installing."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, ["--dry-run"])

        assert result.exit_code == 0
        assert "dry-run" in result.output
        assert "pip install" in result.output

    def test_dry_run_github_prints_info(self):
        """--dry-run in GitHub mode prints release/wheel info without installing."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = {
            "tag_name": "v0.1.17",
            "assets": [{
                "name": "dglz-0.1.17-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz-0.1.17-py3-none-any.whl",
            }],
        }

        with mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            result = runner.invoke(app, [
                "--dist-repo", "--dist-repo-url", "https://github.com/SuShuheng/dglz-dist.git",
                "--dry-run",
            ])

        assert result.exit_code == 0
        assert "dry-run" in result.output
        assert "v0.1.17" in result.output
        assert "dglz-0.1.17-py3-none-any.whl" in result.output


# ---------------------------------------------------------------------------
# NEW: Automatic mode fallback tests
# ---------------------------------------------------------------------------


class TestAutomaticFallback:
    """Tests for automatic mode: PyPI first -> GitHub fallback."""

    def test_pypi_newer_uses_pypi(self):
        """When PyPI has newer version, uses PyPI (no GitHub fallback)."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=[]), \
             mock.patch("eemoclas.cli.github_update.get_github_release") as mock_gh:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert "PyPI" in result.output
        # GitHub should NOT have been called
        mock_gh.assert_not_called()

    def test_pypi_install_failure_tries_github(self):
        """When PyPI has newer version but pip install fails, falls back to GitHub."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()
        fail_result = mock.MagicMock(returncode=1, stderr="ERROR")
        release = {
            "tag_name": "v0.1.17",
            "assets": [{
                "name": "dglz-0.1.17-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz.whl",
            }],
        }
        gh_success = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail_result, fail_result, fail_result, gh_success]), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=[]), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "GitHub Release" in result.output

    def test_pypi_network_error_tries_github(self):
        """When PyPI has network error, tries GitHub fallback."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        release = {
            "tag_name": "v0.1.17",
            "assets": [{
                "name": "dglz-0.1.17-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz-0.1.17-py3-none-any.whl",
            }],
        }
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen", side_effect=OSError("timeout")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release), \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result):
            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "更新成功" in result.output
        assert "GitHub Release" in result.output

    def test_pypi_already_latest_tries_github(self):
        """When PyPI reports already latest, tries GitHub fallback."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        # PyPI says current version is latest
        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        # GitHub also has no newer version
        release = {
            "tag_name": "v0.1.16",
            "assets": [{
                "name": "dglz-0.1.16-py3-none-any.whl",
                "browser_download_url": "https://example.com/dglz.whl",
            }],
        }

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.github_update.get_github_release", return_value=release) as mock_gh, \
             mock.patch("eemoclas.cli.github_update.get_project_package_name", return_value="DGLZ"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert "当前已是最新" in result.output
        # GitHub WAS consulted
        mock_gh.assert_called_once()

    def test_both_pypi_and_github_fail(self):
        """Both PyPI and GitHub fail with network errors."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("urllib.request.urlopen", side_effect=OSError("timeout")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch(
                 "eemoclas.cli.github_update.get_github_release",
                 side_effect=ConnectionError("GitHub network error"),
             ):
            result = runner.invoke(app, [])

        assert result.exit_code == 1
        assert "均无法连接" in result.output

    def test_pypi_down_github_no_wheel_no_dual_message(self):
        """PyPI unreachable + GitHub has no matching wheel -> no dual network error."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("urllib.request.urlopen", side_effect=OSError("timeout")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch(
                 "eemoclas.cli.github_update.get_github_release",
                 side_effect=ValueError("no matching wheel"),
             ):
            result = runner.invoke(app, [])

        assert result.exit_code == 1
        # Should show GitHub's specific error, NOT the dual network message
        assert "未找到发布版本" in result.output
        assert "均无法连接" not in result.output
# NEW: Version extraction helpers
# ---------------------------------------------------------------------------


class TestVersionExtraction:
    """Tests for _extract_version_from_wheel_name and _extract_version_from_tag."""

    def test_extract_from_wheel_name(self):
        from eemoclas.cli.update_cmd import _extract_version_from_wheel_name

        assert _extract_version_from_wheel_name("dglz-0.1.15.post19-py3-none-any.whl") == "0.1.15.post19"

    def test_extract_from_wheel_name_simple(self):
        from eemoclas.cli.update_cmd import _extract_version_from_wheel_name

        assert _extract_version_from_wheel_name("dglz-1.0.0-py3-none-any.whl") == "1.0.0"

    def test_extract_from_tag_with_v(self):
        from eemoclas.cli.update_cmd import _extract_version_from_tag

        assert _extract_version_from_tag("v0.1.15.post19") == "0.1.15.post19"

    def test_extract_from_tag_without_v(self):
        from eemoclas.cli.update_cmd import _extract_version_from_tag

        assert _extract_version_from_tag("0.1.15.post19") == "0.1.15.post19"

    def test_extract_from_wheel_name_raises_on_bad_format(self):
        from eemoclas.cli.update_cmd import _extract_version_from_wheel_name

        with pytest.raises(ValueError):
            _extract_version_from_wheel_name("badformat")


# ---------------------------------------------------------------------------
# NEW: Pip args builder tests
# ---------------------------------------------------------------------------


class TestBuildPipArgs:
    """Tests for _build_pip_args_pypi."""

    def test_default_args(self):
        from eemoclas.cli.update_cmd import _build_pip_args_pypi

        args = _build_pip_args_pypi()
        assert args == ["--no-cache-dir", "--upgrade", "DGLZ"]

    def test_with_pre(self):
        from eemoclas.cli.update_cmd import _build_pip_args_pypi

        args = _build_pip_args_pypi(pre=True)
        assert "--pre" in args
        assert "DGLZ" in args

    def test_with_index_url(self):
        from eemoclas.cli.update_cmd import _build_pip_args_pypi

        args = _build_pip_args_pypi(index_url="https://custom.pypi.org/simple")
        assert "--index-url" in args
        assert "https://custom.pypi.org/simple" in args

    def test_with_extra_index_url(self):
        from eemoclas.cli.update_cmd import _build_pip_args_pypi

        args = _build_pip_args_pypi(extra_index_url="https://extra.pypi.org/simple")
        assert "--extra-index-url" in args
        assert "https://extra.pypi.org/simple" in args

    def test_all_options(self):
        from eemoclas.cli.update_cmd import _build_pip_args_pypi

        args = _build_pip_args_pypi(
            pre=True,
            index_url="https://custom.pypi.org/simple",
            extra_index_url="https://extra.pypi.org/simple",
        )
        assert "--pre" in args
        assert "--index-url" in args
        assert "--extra-index-url" in args
        assert "DGLZ" in args


# ---------------------------------------------------------------------------
# NEW: PyPI status check tests
# ---------------------------------------------------------------------------


class TestCheckPyPIForUpdate:
    """Tests for _check_pypi_for_update."""

    def test_newer_version(self):
        from eemoclas.cli.update_cmd import _check_pypi_for_update, _PyPIStatus

        with mock.patch("eemoclas.cli.update_cmd.check_for_update", return_value=("0.1.17", True, None)):
            status, version = _check_pypi_for_update()

        assert status == _PyPIStatus.NEWER
        assert version == "0.1.17"

    def test_already_latest(self):
        from eemoclas.cli.update_cmd import _check_pypi_for_update, _PyPIStatus

        with mock.patch("eemoclas.cli.update_cmd.check_for_update", return_value=("0.1.13", False, None)):
            status, version = _check_pypi_for_update()

        assert status == _PyPIStatus.ALREADY_LATEST
        assert version == "0.1.13"

    def test_network_error(self):
        from eemoclas.cli.update_cmd import _check_pypi_for_update, _PyPIStatus

        with mock.patch("eemoclas.cli.update_cmd.check_for_update", return_value=(None, False, "network")):
            status, version = _check_pypi_for_update()

        assert status == _PyPIStatus.NETWORK_ERROR
        assert version is None

    def test_missing_package(self):
        from eemoclas.cli.update_cmd import _check_pypi_for_update, _PyPIStatus

        with mock.patch("eemoclas.cli.update_cmd.check_for_update", return_value=(None, False, "missing")):
            status, version = _check_pypi_for_update()

        assert status == _PyPIStatus.MISSING
        assert version is None


class TestPipFallbackBehavior:
    """Tests for pypi_fallback parameter in _do_pip_install and bat script."""

    def test_github_mode_retries_keep_wheel_url(self):
        """In GitHub mode (pypi_fallback=False), third retry uses original args."""
        from eemoclas.cli.update_cmd import _do_pip_install

        fail = mock.MagicMock(returncode=1, stderr="ERROR")

        with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail, fail, fail]) as mock_run, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            with pytest.raises(ClickExit):
                _do_pip_install(
                    ["--upgrade", "https://example.com/dglz.whl"],
                    "0.1.17",
                    pypi_fallback=False,
                )

        # Third call should use original args, not ["--upgrade", "DGLZ"]
        third_call_args = mock_run.call_args_list[2][0][0]
        assert third_call_args == ["--upgrade", "https://example.com/dglz.whl"]

    def test_pypi_mode_third_retry_falls_back_to_dglz(self):
        """In PyPI mode (pypi_fallback=True), third retry uses DGLZ."""
        from eemoclas.cli.update_cmd import _do_pip_install

        fail = mock.MagicMock(returncode=1, stderr="ERROR")

        with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail, fail, fail]) as mock_run, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            with pytest.raises(ClickExit):
                _do_pip_install(
                    ["--no-cache-dir", "--upgrade", "DGLZ"],
                    "0.1.17",
                    pypi_fallback=True,
                )

        third_call_args = mock_run.call_args_list[2][0][0]
        assert third_call_args == ["--upgrade", "DGLZ"]

    def test_bat_script_uses_third_cmd_for_github_mode(self):
        """Bat script third retry uses wheel URL when pypi_fallback=False."""
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            ["--upgrade", "https://example.com/dglz.whl"],
            "0.1.17",
            "python",
            "/tmp/log",
            pypi_fallback=False,
        )
        # Should NOT contain "DGLZ" on the RETRY2 line
        assert "DGLZ" not in script
        assert "https://example.com/dglz.whl" in script

    def test_bat_script_uses_dglz_for_pypi_mode(self):
        """Bat script third retry uses DGLZ when pypi_fallback=True."""
        from eemoclas.cli.update_cmd import _generate_bat_script

        script = _generate_bat_script(
            ["--no-cache-dir", "--upgrade", "DGLZ"],
            "0.1.17",
            "python",
            "/tmp/log",
            pypi_fallback=True,
        )
        # RETRY2 line should use DGLZ
        assert "upgrade DGLZ" in script


class TestWindowsDetachedExitCode:
    """Tests for Windows detached update exit code handling."""

    def test_detached_exit_0_not_caught_as_failure(self):
        """typer.Exit(0) from Windows detached update should NOT trigger GitHub fallback."""
        from eemoclas.cli.update_cmd import app, _do_pip_install
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.17"}}).encode()

        # _do_pip_install will raise typer.Exit(0) via _windows_detached_update
        def _mock_do_pip(*args, **kwargs):
            raise typer.Exit(code=0)

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd._do_pip_install", side_effect=_mock_do_pip), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.load_update_log", return_value=[]):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, [])

        # typer.Exit(0) should be re-raised, not caught as failure
        assert result.exit_code == 0


class TestCustomIndexDiscovery:
    """Tests for --index-url in discovery path."""

    def test_custom_index_tries_pip_when_pypi_says_latest(self):
        """When PyPI says already latest but --index-url is set, try pip install."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        # PyPI says current version is latest
        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result) as mock_pip:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, ["--index-url", "https://custom.pypi.org/simple"])

        assert result.exit_code == 0
        # pip should have been called with --index-url
        pip_calls = [call[0][0] for call in mock_pip.call_args_list]
        assert any("--index-url" in str(args) for args in pip_calls)

    def test_custom_index_dry_run(self):
        """--index-url with --dry-run shows the pip command."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        pypi_response = json.dumps({"info": {"version": "0.1.13"}}).encode()

        with mock.patch("urllib.request.urlopen") as mock_urlopen, \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = pypi_response
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            result = runner.invoke(app, ["--index-url", "https://custom.pypi.org/simple", "--dry-run"])

        assert result.exit_code == 0
        assert "index-url" in result.output

    def test_custom_index_tried_when_pypi_unreachable(self):
        """When PyPI is unreachable and --index-url is set, try custom index before GitHub."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()
        mock_run_result = mock.MagicMock(returncode=0, stdout="OK")

        with mock.patch("urllib.request.urlopen", side_effect=OSError("network error")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", return_value=mock_run_result) as mock_pip, \
             mock.patch("eemoclas.cli.github_update.get_github_release") as mock_gh:
            result = runner.invoke(app, ["--index-url", "https://custom.pypi.org/simple"])

        assert result.exit_code == 0
        # pip should have been called with --index-url, NOT GitHub
        pip_calls = [call[0][0] for call in mock_pip.call_args_list]
        assert any("--index-url" in str(args) for args in pip_calls)
        mock_gh.assert_not_called()

    def test_custom_index_dry_run_when_pypi_unreachable(self):
        """--index-url with --dry-run when PyPI unreachable shows pip command."""
        from eemoclas.cli.update_cmd import app
        from typer.testing import CliRunner

        runner = CliRunner()

        with mock.patch("urllib.request.urlopen", side_effect=OSError("network error")), \
             mock.patch("eemoclas.cli.update_cmd.log_update"):
            result = runner.invoke(app, ["--index-url", "https://custom.pypi.org/simple", "--dry-run"])

        assert result.exit_code == 0
        assert "index-url" in result.output


class TestQuietMode:
    """Tests for quiet mode in _do_pip_install."""

    def test_quiet_suppresses_error_output(self):
        """quiet=True does not print error panel on failure."""
        from eemoclas.cli.update_cmd import _do_pip_install

        fail = mock.MagicMock(returncode=1, stderr="ERROR")

        with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail, fail, fail]), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.console") as mock_console:
            with pytest.raises(ClickExit):
                _do_pip_install(["DGLZ"], "test", quiet=True)

        # print_cli_error should NOT have been called
        error_calls = [c for c in mock_console.print.call_args_list
                       if any("更新失败" in str(a) for a in c[0])]
        assert len(error_calls) == 0

    def test_github_mode_recovery_cmd_shows_wheel_url(self):
        """In GitHub mode (pypi_fallback=False), recovery shows wheel URL not DGLZ."""
        from eemoclas.cli.update_cmd import _do_pip_install

        fail = mock.MagicMock(returncode=1, stderr="ERROR")
        wheel_url = "https://example.com/dglz-0.1.17-py3-none-any.whl"

        with mock.patch("eemoclas.cli.update_cmd._is_windows", return_value=False), \
             mock.patch("eemoclas.cli.update_cmd._run_pip_install", side_effect=[fail, fail, fail]), \
             mock.patch("eemoclas.cli.update_cmd.log_update"), \
             mock.patch("eemoclas.cli.update_cmd.console") as mock_console:
            with pytest.raises(ClickExit):
                _do_pip_install(["--upgrade", wheel_url], "0.1.17", pypi_fallback=False)

        # Recovery command should contain the wheel URL, not just "DGLZ"
        output = str(mock_console.print.call_args_list)
        assert wheel_url in output
        assert "pip install DGLZ" not in output


class TestNotifyIfUpdateAvailable:
    """Tests for notify_if_update_available using the 3-tuple check_for_update."""

    def test_notify_shows_update_on_cache_miss(self):
        """When cache misses and PyPI has newer version, print notification."""
        from eemoclas.cli.version_check import notify_if_update_available

        mock_console = mock.MagicMock()
        with mock.patch("eemoclas.cli.version_check.get_cached_latest", return_value=None), \
             mock.patch("eemoclas.cli.version_check.check_for_update",
                        return_value=("0.1.17", True, None)), \
             mock.patch("eemoclas.cli.version_check.save_detect_record"):
            notify_if_update_available(mock_console)

        # Should have printed update notification
        assert any("0.1.17" in str(c) for c in mock_console.print.call_args_list)

    def test_notify_no_update_on_cache_miss(self):
        """When cache misses and PyPI says already latest, no notification."""
        from eemoclas.cli.version_check import notify_if_update_available

        mock_console = mock.MagicMock()
        with mock.patch("eemoclas.cli.version_check.get_cached_latest", return_value=None), \
             mock.patch("eemoclas.cli.version_check.check_for_update",
                        return_value=("0.1.13", False, None)), \
             mock.patch("eemoclas.cli.version_check.save_detect_record"):
            notify_if_update_available(mock_console)

        mock_console.print.assert_not_called()

    def test_notify_network_error_no_crash(self):
        """When cache misses and PyPI is unreachable, no crash."""
        from eemoclas.cli.version_check import notify_if_update_available

        mock_console = mock.MagicMock()
        with mock.patch("eemoclas.cli.version_check.get_cached_latest", return_value=None), \
             mock.patch("eemoclas.cli.version_check.check_for_update",
                        return_value=(None, False, "network")), \
             mock.patch("eemoclas.cli.version_check.save_detect_record"):
            notify_if_update_available(mock_console)

        mock_console.print.assert_not_called()

    def test_notify_missing_no_crash(self):
        """When cache misses and PyPI returns missing, no crash."""
        from eemoclas.cli.version_check import notify_if_update_available

        mock_console = mock.MagicMock()
        with mock.patch("eemoclas.cli.version_check.get_cached_latest", return_value=None), \
             mock.patch("eemoclas.cli.version_check.check_for_update",
                        return_value=(None, False, "missing")), \
             mock.patch("eemoclas.cli.version_check.save_detect_record"):
            notify_if_update_available(mock_console)

        mock_console.print.assert_not_called()


class TestCheckForUpdateMissingDistInfo:
    """Tests that check_for_update returns 'missing' for bad PyPI responses."""

    def test_missing_info_version_returns_missing(self):
        """PyPI response without info.version -> error_type='missing', not 'network'."""
        from eemoclas.cli.version_check import check_for_update

        bad_json = json.dumps({"info": {}}).encode()  # no "version" key
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = bad_json
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "missing"

    def test_invalid_version_string_returns_missing(self):
        """PyPI response with non-parseable version -> error_type='missing'."""
        from eemoclas.cli.version_check import check_for_update

        bad_json = json.dumps({"info": {"version": "not-a-version"}}).encode()
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = bad_json
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "missing"

    def test_network_error_returns_network(self):
        """Actual network error -> error_type='network'."""
        import urllib.error
        from eemoclas.cli.version_check import check_for_update

        with mock.patch("urllib.request.urlopen",
                        side_effect=OSError("DNS failure")):
            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "network"

    def test_invalid_json_returns_missing(self):
        """PyPI response with invalid JSON -> error_type='missing', not crash."""
        from eemoclas.cli.version_check import check_for_update

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.read.return_value = b"not json at all"
            mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = mock.MagicMock(return_value=False)
            mock_urlopen.return_value = mock_resp

            latest, has_update, error_type = check_for_update()

        assert latest is None
        assert has_update is False
        assert error_type == "missing"

    def test_notify_records_missing_not_network_error(self):
        """When PyPI returns missing, audit records 'missing' not 'network_error'."""
        from eemoclas.cli.version_check import notify_if_update_available

        mock_console = mock.MagicMock()
        with mock.patch("eemoclas.cli.version_check.get_cached_latest", return_value=None), \
             mock.patch("eemoclas.cli.version_check.check_for_update",
                        return_value=(None, False, "missing")), \
             mock.patch("eemoclas.cli.version_check.save_detect_record") as mock_save:
            notify_if_update_available(mock_console)

        # Should record "missing" status, not "network_error"
        mock_save.assert_called()
        last_call_status = mock_save.call_args[0][3]  # 4th positional arg is status
        assert last_call_status == "missing"
