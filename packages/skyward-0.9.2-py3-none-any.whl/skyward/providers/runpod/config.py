"""RunPod provider configuration.

Immutable configuration dataclass for RunPod provider.
"""

from __future__ import annotations

import typing
from dataclasses import dataclass
from typing import Literal

from skyward.containers import DockerImage
from skyward.core.provider import ProviderConfig

type ClusterMode = Literal["instant", "individual"]

if typing.TYPE_CHECKING:
    from skyward.providers.runpod.provider import RunPodProvider

# =============================================================================
# Configuration
# =============================================================================


@dataclass(frozen=True, slots=True)
class RunPod(ProviderConfig):
    """RunPod GPU Pods provider configuration.

    SSH keys are automatically detected from ~/.ssh/id_ed25519.pub or
    ~/.ssh/id_rsa.pub.

    Features:
        - Auto data center: If not specified, RunPod selects best location.

    Example:
        >>> from skyward.providers.runpod import RunPod
        >>> config = RunPod(data_center_ids=("EU-RO-1",))

    Args:
        api_key: RunPod API key. Falls back to RUNPOD_API_KEY env var.
        cloud_type: Cloud type (SECURE or COMMUNITY). Default: SECURE.
        container_disk_gb: Container disk size in GB. Default: 50.
        volume_gb: Persistent volume size in GB. Default: 20.
        volume_mount_path: Volume mount path. Default: /workspace.
        data_center_ids: Preferred data center IDs or "global" for auto-selection.
        ports: Port mappings (e.g., ["22/tcp", "8888/http"]). Default: ["22/tcp"].
        container_image: Override the container image for pods. When set, skips
            automatic image resolution from Docker Hub. Example:
            ``"runpod/base:1.0.3-cuda1210-ubuntu2204"``. Default: None (auto-select).
        registry_auth: Name of the container registry credential registered in RunPod
            account settings. Authenticates Docker Hub pulls to avoid rate limits.
            Set to None to skip. Default: "docker hub".
        min_inet_down: Minimum download speed in Mbps. None disables filter.
        min_inet_up: Minimum upload speed in Mbps. None disables filter.
        base_image: Docker Hub image family for automatic resolution. "base" uses
            ``runpod/base`` images (default), "pytorch" uses ``runpod/pytorch`` images
            which are typically pre-cached on RunPod hosts for faster startup.
            Ignored when ``container_image`` is set. Default: "base".
    """

    cluster_mode: ClusterMode = "individual"
    base_image: Literal["nvidia", "runpod-base", "runpod-pytorch"] = "runpod-base"
    global_networking: bool | None = None
    api_key: str | None = None
    cloud_type: Literal["community", "secure"] = "secure"
    ubuntu: Literal["20.04", "22.04", "24.04", "newest"] | str = "newest"
    container_disk_gb: int = 50
    volume_gb: int = 20
    volume_mount_path: str = "/workspace"
    data_center_ids: tuple[str, ...] | Literal["global"] = "global"
    ports: tuple[str, ...] = ("22/tcp",)
    request_timeout: int = 30
    cpu_clock: Literal["3c", "5c"] | str = "3c"
    bid_multiplier: float = 1
    container_image: DockerImage | None = None
    registry_auth: str | None = "docker hub"
    min_inet_down: float | None = None
    min_inet_up: float | None = None

    async def create_provider(self) -> RunPodProvider:
        from skyward.providers.runpod.provider import RunPodProvider
        return await RunPodProvider.create(self)

    @property
    def type(self) -> str: return "runpod"

    def default_options(self) -> None:
        return None

    @property
    def region(self) -> str:
        if self.data_center_ids == "global":
            return "global"
        return self.data_center_ids[0]
