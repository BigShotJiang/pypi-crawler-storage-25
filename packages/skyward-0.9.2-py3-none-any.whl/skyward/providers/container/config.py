from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from skyward.core.provider import ProviderConfig

if TYPE_CHECKING:
    from skyward.providers.container.provider import ContainerProvider

_DEFAULT_IMAGE = "ghcr.io/gabfssilva/skyward:py{python_version}"


@dataclass(frozen=True, slots=True)
class Container(ProviderConfig):
    """Container provider configuration.

    Runs compute nodes as local containers with SSH access.
    Supports Docker, podman, nerdctl, and Apple's container CLI
    via the configurable ``binary`` field.

    Useful for local development and CI testing without cloud costs.

    Example:
        >>> import skyward as sky
        >>> with sky.ComputePool(provider=sky.Container(), nodes=2) as p:
        ...     result = train(data) >> sky
    """

    image: str = _DEFAULT_IMAGE
    ssh_user: str = "root"
    binary: str = "docker"
    container_prefix: str | None = None
    network: str | None = None

    async def create_provider(self) -> ContainerProvider:
        from skyward.providers.container.provider import ContainerProvider
        return await ContainerProvider.create(self)

    @property
    def type(self) -> str: return "container"

    def default_options(self) -> None:
        return None
