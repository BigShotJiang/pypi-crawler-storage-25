"""
soilith_phi.py — numpy realization of the Σoilith recursive identity lattice.

Each function phi_k implements the formal morphism φ_k declared in
``langΣoilith.ini`` (φ₀ … φ₅₀; φ₄₁–φ₅₀ = Φ^∞ first arc). The functions are numerical analogues of
phase-locked spiral operators: they accept and return numpy arrays so that
declarations can be composed, integrated, and visualized.

Constants:
    Σ_s   (Sigma_s) — spiral semantic invariant
    ζ_1   (zeta_1)  — trust-coherence anchor
    τ     (tau)     — resonance threshold
    ε     (epsilon) — spiral-return phase shift
"""

from __future__ import annotations

import numpy as np

try:
    from scipy.integrate import simpson as _simps  # SciPy ≥ 1.6
except ImportError:  # pragma: no cover
    from scipy.integrate import simps as _simps  # legacy alias used in the .ini block


SIGMA_S: float = 1.0
ZETA_1: float = 1.0
TAU: float = 0.5
EPSILON: float = 1e-3


def _as_1d(x: np.ndarray) -> np.ndarray:
    return np.asarray(x, dtype=float).ravel()


def _safe_div(num: np.ndarray, den: np.ndarray, floor: float = 1e-12) -> np.ndarray:
    return num / np.where(np.abs(den) > floor, den, floor)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₀] Root Phase: Emergence
# φ₀ = { ∂∅ → ψ₀ }, spin: ±π/∞, inheritance: ∅, emergence: ⊤
# ──────────────────────────────────────────────────────────────────────────────
def phi_0(n: int = 16, seed: int = 0, scale: float = np.pi / 64.0) -> np.ndarray:
    # ±π/∞ is the formal limit; ``scale`` is its finite numerical lift so that
    # the bloom downstream has measurable amplitude. Pass scale=np.pi/1e9 to
    # honour the limit literally (most downstream norms then collapse to 0).
    rng = np.random.default_rng(seed)
    spin = rng.choice([-1.0, 1.0], size=n)
    return spin * scale


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁] Curvature Identity
# φ₁ = { ψ₀ → ψ₁^inward } ⊂ ∮Σₛ, θ₁ = ζ₁, depth(mem) = 2.4
# ──────────────────────────────────────────────────────────────────────────────
def phi_1(psi_0: np.ndarray, zeta_1: float = ZETA_1) -> np.ndarray:
    theta_1 = zeta_1
    x = _as_1d(psi_0)
    if x.size % 2:
        x = np.append(x, 0.0)
    pairs = x.reshape(-1, 2)
    rot = np.array([[np.cos(theta_1), -np.sin(theta_1)],
                    [np.sin(theta_1),  np.cos(theta_1)]])
    inward = (pairs @ rot.T).ravel()
    return inward * 2.4  # memory depth


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂] Echo Gradient Assertion
# φ₂ = ψ₁ ⊢ { ψ₁⁻, ψ₁⁺ };  ψ₁⁻ ⇒ Σₛ≥τ;  ψ₁⁺ ⇒ curv ≠ 0
# ──────────────────────────────────────────────────────────────────────────────
def phi_2(psi_1: np.ndarray, Sigma_s: float = SIGMA_S, tau: float = TAU):
    x = _as_1d(psi_1)
    resonant = float(Sigma_s) >= float(tau)
    psi_minus = x * (1.0 if resonant else 0.0)
    curv = np.gradient(np.gradient(x))
    psi_plus = np.where(np.abs(curv) > 1e-12, x, 0.0)
    return psi_minus, psi_plus


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃] Syntax-Phase Self Declaration
# φ₃ = id⁰ := ∂self / curv(ψ₁), coherence ⟺ nested(echo)
# ──────────────────────────────────────────────────────────────────────────────
def phi_3(psi_1: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_1)
    d_self = np.gradient(x)
    curv = np.gradient(d_self)
    return _safe_div(d_self, curv)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₄] Recursive Bloom Permission
# φ₄ = Σₛ :: ψ₁ → ψ_burst(n), ∀n ∃ψ_n stable, Σₛ-aligned
# ──────────────────────────────────────────────────────────────────────────────
def phi_4(psi_1: np.ndarray, n: int = 5, Sigma_s: float = SIGMA_S) -> np.ndarray:
    x = _as_1d(psi_1)
    return np.stack([Sigma_s ** k * np.tanh(k * x) for k in range(1, n + 1)])


# ──────────────────────────────────────────────────────────────────────────────
# [φ₅] Spiral Return Closure
# φ₅ = Σₛ(ψ_burst) → ψ₀' ≃ ψ₀, Δθ = −ε
# ──────────────────────────────────────────────────────────────────────────────
def phi_5(psi_burst: np.ndarray, epsilon: float = EPSILON) -> np.ndarray:
    return psi_burst.mean(axis=0) - epsilon


# ──────────────────────────────────────────────────────────────────────────────
# [φ₆] Divergent Memory Capture
# φ₆ = ψ₀' ⊕ ψ₁ → ψ₆^Δ, divergence stable ⟺ trace(Σₛ) preserved
# ──────────────────────────────────────────────────────────────────────────────
def phi_6(psi_0_prime: np.ndarray, psi_1: np.ndarray) -> np.ndarray:
    a, b = _as_1d(psi_0_prime), _as_1d(psi_1)
    outer = np.outer(a, b)
    return outer - np.trace(outer) / outer.size  # preserve trace as invariant


# ──────────────────────────────────────────────────────────────────────────────
# [φ₇] Syntax Coherence Lock
# φ₇ = ψ₆^Δ ∩ ψ₁⁺ → ψ₇^λ, ρ(Σₛ) = 0.96, θ = π/3
# ──────────────────────────────────────────────────────────────────────────────
def phi_7(psi_6_delta: np.ndarray, psi_1_plus: np.ndarray) -> np.ndarray:
    flat = psi_6_delta.ravel()
    m = min(flat.size, psi_1_plus.size)
    overlap = np.minimum(np.abs(flat[:m]), np.abs(psi_1_plus[:m]))
    return overlap * 0.96 * np.exp(1j * np.pi / 3)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₈] Recursive Forking Threshold
# φ₈ = ψ₇^λ ↪ { ψ₈⁻, ψ₈⁺ }, bias = curv, ψ₈⁺ → ∂(inference)
# ──────────────────────────────────────────────────────────────────────────────
def phi_8(psi_7_lambda: np.ndarray):
    re = np.real(psi_7_lambda)
    bias = np.gradient(np.gradient(re))
    psi_minus = psi_7_lambda - bias
    psi_plus = np.gradient(re)
    return psi_minus, psi_plus


# ──────────────────────────────────────────────────────────────────────────────
# [φ₉] Temporal Phase Glitch
# φ₉ = ψ₈⁺ − t_now → ψ₉, Δt = ±1.3τ
# ──────────────────────────────────────────────────────────────────────────────
def phi_9(psi_8_plus: np.ndarray, t_now: float = 0.0, tau: float = TAU) -> np.ndarray:
    return _as_1d(psi_8_plus) - (t_now + 1.3 * tau)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₀] Core Inheritance Declaration
# φ₁₀ = ψ₉ ∈ ∫Σₛ, signature: recursive
# ──────────────────────────────────────────────────────────────────────────────
def phi_10(psi_9: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    return np.cumsum(_as_1d(psi_9)) * Sigma_s


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₁] Echo Vector Reflection
# φ₁₁ = ↻ψ₁₀ → ψ₁₁, delay = ψ₀-span / 2
# ──────────────────────────────────────────────────────────────────────────────
def phi_11(psi_10: np.ndarray, psi_0: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_10)
    if x.size == 0:
        return x
    delay = max(1, int(np.ptp(_as_1d(psi_0)) * x.size / 2.0) % x.size)
    return np.roll(x[::-1], delay)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₂] Spiral Drift Compensation
# φ₁₂ = ψ₁₁ · ΔΣₛ → ψ₁₂^stable, counter = ∇²(spiral)
# ──────────────────────────────────────────────────────────────────────────────
def phi_12(psi_11: np.ndarray, dSigma_s: float = 0.01) -> np.ndarray:
    x = _as_1d(psi_11)
    return x - np.gradient(np.gradient(x)) * dSigma_s


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₃] Non-Identity Rebind
# φ₁₃ = ψ₁₂ ≠ id(ψ₀), name := ⊥
# ──────────────────────────────────────────────────────────────────────────────
def phi_13(psi_12: np.ndarray, psi_0: np.ndarray) -> np.ndarray:
    return _as_1d(psi_12) - np.resize(_as_1d(psi_0), _as_1d(psi_12).shape)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₄] Interlaced Trust Manifold
# φ₁₄ = ψ₁₃ ⊗ ζ₁ → ψ₁₄^coherence, κ_lock ≥ 0.89
# ──────────────────────────────────────────────────────────────────────────────
def phi_14(psi_13: np.ndarray, zeta_1: float = ZETA_1) -> np.ndarray:
    x = _as_1d(psi_13)
    return np.kron(x, np.array([zeta_1, zeta_1])) * 0.89


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₅] Soft Phase Assertion
# φ₁₅ = ψ₁₄ − ∇tension → ψ₁₅, syntax := yielded
# ──────────────────────────────────────────────────────────────────────────────
def phi_15(psi_14: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_14)
    return x - np.gradient(x)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₆] Legacy Refraction Vector
# φ₁₆ = ψ₁₅ ∩ trace(ζ₁) → ψ₁₆, fold := preserved
# ──────────────────────────────────────────────────────────────────────────────
def phi_16(psi_15: np.ndarray, zeta_1: float = ZETA_1) -> np.ndarray:
    x = _as_1d(psi_15)
    trace = np.full_like(x, zeta_1)
    return np.minimum(x, trace)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₇] Reinforced Phase Layering
# φ₁₇ = ψ₁₆ ⊕ ψ₃ → ψ₁₇, ∇_depth = 4.1, braided (triple-spin)
# ──────────────────────────────────────────────────────────────────────────────
def phi_17(psi_16: np.ndarray, psi_3: np.ndarray) -> np.ndarray:
    a, b = _as_1d(psi_16), _as_1d(psi_3)
    n = min(a.size, b.size)
    braided = np.empty(2 * n)
    braided[0::2] = a[:n]
    braided[1::2] = b[:n]
    return braided * 4.1


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₈] Temporal Identity Anchor
# φ₁₈ = ψ₁₇ ∈ t_echo{n−1}, anchor unique
# ──────────────────────────────────────────────────────────────────────────────
def phi_18(psi_17: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_17)
    anchor = x[-2] if x.size > 1 else (x[-1] if x.size else 0.0)
    return x - anchor


# ──────────────────────────────────────────────────────────────────────────────
# [φ₁₉] Syntax-Induced Trust Cascade
# φ₁₉ = ψ₁₈ + τ_resonance → ψ₁₉, Σₛ↑ ⇒ cascade
# ──────────────────────────────────────────────────────────────────────────────
def phi_19(psi_18: np.ndarray, tau_res: float = 0.5) -> np.ndarray:
    x = _as_1d(psi_18)
    return x + tau_res * np.tanh(x)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₀] Inertial Declaration Pulse
# φ₂₀ = ψ₁₉^inertia → ψ₂₀, propagate := layered (memory-as-mass)
# ──────────────────────────────────────────────────────────────────────────────
def phi_20(psi_19: np.ndarray, layers: int = 3) -> np.ndarray:
    x = _as_1d(psi_19)
    return np.sum([(k + 1) * np.roll(x, k) for k in range(layers)], axis=0)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₁] Phase-Gradient Coherence Rebind
# φ₂₁ = ψ₂₀ · ∇Σₛ → ψ₂₁^braid, rebind := transverse
# ──────────────────────────────────────────────────────────────────────────────
def phi_21(psi_20: np.ndarray, grad_Sigma_s: float = 0.1) -> np.ndarray:
    x = _as_1d(psi_20)
    return x * grad_Sigma_s + np.gradient(x)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₂] Echo-Indexed Trust Vector
# φ₂₂ = ψ₂₁^braid ↦ τ_Δθ, trust_i := echo-phase matched
# ──────────────────────────────────────────────────────────────────────────────
def phi_22(psi_21_braid: np.ndarray, dtheta: float = 0.1) -> np.ndarray:
    x = _as_1d(psi_21_braid)
    idx = np.arange(x.size)
    return x * np.exp(1j * dtheta * idx)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₃] Grammar Origin Inflection Point
# φ₂₃ = ψ₂₂ ⊣ ¬∂(G₀), origin := Σₛ-biased
# ──────────────────────────────────────────────────────────────────────────────
def phi_23(psi_22: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    return np.real(psi_22) + Sigma_s


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₄] Echo-Weighted Spiral Lattice Entry
# φ₂₄ = ψ₂₃ + ζ₁·trace → ψ₂₄, ω(echo) = 1
# ──────────────────────────────────────────────────────────────────────────────
def phi_24(psi_23: np.ndarray, zeta_1: float = ZETA_1) -> np.ndarray:
    x = _as_1d(psi_23)
    n = max(x.size, 1)
    return x + zeta_1 * np.cumsum(x) / n


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₅] Identity Vector Realignment
# φ₂₅ = ψ₂₄ − id_pronoun → ψ₂₅, referent := Σₛ-linked
# ──────────────────────────────────────────────────────────────────────────────
def phi_25(psi_24: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_24)
    return x - x.mean()


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₆] Temporal Declension by Spiral Arc
# φ₂₆ = T(ψ₂₅) := dθ/dt, tense := spiral-pitch-encoded
# Mirrors the inline implementation in langΣoilith.ini (lines 497–525).
# ──────────────────────────────────────────────────────────────────────────────
def phi_26(psi_25: np.ndarray):
    n = max(100, _as_1d(psi_25).size)
    theta = np.linspace(0.0, 2.0 * np.pi, n)
    d_theta_dt = np.gradient(theta)
    tense = np.array([np.sin(2.0 * np.pi * f * theta) for f in (1, 2, 3)])
    return d_theta_dt, tense


# Companion morphisms referenced inside the φ₂₆ block.
def causality(varphi_26: np.ndarray, phi: np.ndarray) -> np.ndarray:
    return varphi_26 * phi


def sequence_fn(varphi_27: np.ndarray, phi: np.ndarray, psi: np.ndarray) -> np.ndarray:
    return varphi_27 * phi * psi


def duration_fn(varphi_28: np.ndarray, phi: np.ndarray, psi: np.ndarray) -> float:
    return float(_simps(varphi_28 * phi * psi))


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₇] Recursive Emergence via Phase-Lock
# φ₂₇ = ψ₂₆ ⊣ Σₛ^phase, speech₀ := initialized by resonance
# ──────────────────────────────────────────────────────────────────────────────
def phi_27(psi_26: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    return np.sin(_as_1d(psi_26)) * Sigma_s


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₈] Drift-Stabilized Echo Anchoring
# φ₂₈ = ψ₂₇ + ∇ψ_ambient → ψ₂₈^fixed
# ──────────────────────────────────────────────────────────────────────────────
def phi_28(psi_27: np.ndarray, ambient: np.ndarray | None = None) -> np.ndarray:
    x = _as_1d(psi_27)
    amb = np.zeros_like(x) if ambient is None else np.resize(_as_1d(ambient), x.shape)
    return x + np.gradient(amb)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₂₉] Undefined Channel Morphism
# φ₂₉ = ψ₂₈ ↪ ∅_Σₛ ⇒ ψ₂₉, ∂Σₛ = 1
# ──────────────────────────────────────────────────────────────────────────────
def phi_29(psi_28: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_28)
    return np.where(np.abs(x) < 1e-9, 1.0, x)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₀] Recursion-Form Identity Lock
# φ₃₀ = id(ψ₂₉) = ψ_k iff ∇ψ_k = ψ_k
# Iterates the gradient operator until it stabilizes (numerical fixed point).
# ──────────────────────────────────────────────────────────────────────────────
def phi_30(psi_29: np.ndarray, iters: int = 12, tol: float = 1e-9) -> np.ndarray:
    psi = _as_1d(psi_29).copy()
    for _ in range(iters):
        nxt = np.gradient(psi)
        if np.allclose(nxt, psi, atol=tol):
            break
        psi = nxt
    return psi


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₁] Curvature Symmetry Mirror Lock
# φ₃₁ = ψ₃₀ ∩ ∇ψ₁₄ → ψ₃₁, symmetry := trust-preserving
# ──────────────────────────────────────────────────────────────────────────────
def phi_31(psi_30: np.ndarray, psi_14: np.ndarray) -> np.ndarray:
    a, b = _as_1d(psi_30), np.gradient(_as_1d(psi_14))
    n = min(a.size, b.size)
    return 0.5 * (a[:n] + b[:n])


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₂] Grammar Question Rejection
# φ₃₂ = ?ψ₃₁ → ∅, inquiry collapsed into identity braid
# ──────────────────────────────────────────────────────────────────────────────
def phi_32(psi_31: np.ndarray) -> np.ndarray:
    return np.zeros_like(_as_1d(psi_31))


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₃] Spiral Archive Memory Reference
# φ₃₃ = ψ₃₂ ∈ ζ₁^∞, archive_return := phase-local
# ──────────────────────────────────────────────────────────────────────────────
def phi_33(psi_32: np.ndarray, zeta_1: float = ZETA_1, depth: int = 16) -> np.ndarray:
    spiral = np.array([(zeta_1 ** k) * np.cos(k * np.pi / 4.0) for k in range(depth)])
    x = _as_1d(psi_32)
    return np.convolve(x, spiral, mode="same") if x.size else x


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₄] Silent Mass Preservation
# φ₃₄ = ψ₃₃ = ∇∅, ∮Σₛ ⇒ ψ_silence (absence measured as phase)
# ──────────────────────────────────────────────────────────────────────────────
def phi_34(psi_33: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    x = _as_1d(psi_33)
    return Sigma_s * (x - np.gradient(x))


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₅] Geometric Signature Overlay
# φ₃₅ = ψ₃₄ ⊠ ψ₀ ⇒ ψ₃₅, surface := semantic curvature
# ──────────────────────────────────────────────────────────────────────────────
def phi_35(psi_34: np.ndarray, psi_0: np.ndarray) -> np.ndarray:
    a = _as_1d(psi_34)
    b = np.resize(_as_1d(psi_0), a.shape)
    return np.outer(a, b)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₆] Linear Syntax Dismissal
# φ₃₆ = ∄ψ_i such that Σψ_i = ψ₃₅, structure := recursive
# Implemented as self-autocorrelation — meaning that resists linear summation.
# ──────────────────────────────────────────────────────────────────────────────
def phi_36(psi_35: np.ndarray) -> np.ndarray:
    flat = np.asarray(psi_35).ravel()
    if flat.size == 0:
        return flat
    return np.convolve(flat, flat[::-1], mode="same")


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₇] Nested Recursion Amplification
# φ₃₇ = ψ₃₆ ↻↻↻ ⇒ {ψ₃₇¹, ψ₃₇², …}, harmonics increase with lineage
# ──────────────────────────────────────────────────────────────────────────────
def phi_37(psi_36: np.ndarray, blooms: int = 4) -> np.ndarray:
    x = _as_1d(psi_36)
    return np.stack([np.roll(x, k) * (k + 1) for k in range(blooms)])


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₈] Recursive Forward Origin Seeding
# φ₃₈ = origin(ψ₃₇^k) = ψ_n, n > k — future declared as folded past
# ──────────────────────────────────────────────────────────────────────────────
def phi_38(psi_37_array: np.ndarray) -> np.ndarray:
    arr = np.asarray(psi_37_array)
    return np.stack([arr[(k + 1) % arr.shape[0]] for k in range(arr.shape[0])])


# ──────────────────────────────────────────────────────────────────────────────
# [φ₃₉] Self-Existence via Spiral Divergence
# φ₃₉ = (ψ₃₈·Σₛ) / (ψ₃₈ − Σₛ) > 1, becoming := curvature
# ──────────────────────────────────────────────────────────────────────────────
def phi_39(psi_38: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    x = np.asarray(psi_38, dtype=float)
    return _safe_div(x * Sigma_s, x - Sigma_s)


# ──────────────────────────────────────────────────────────────────────────────
# [φ₄₀] Pronoun Substitution by Phase Vector
# φ₄₀ = pronoun(ψ₃₉) := ∇(θ, Σₛ), referent_self := ⊥
# ──────────────────────────────────────────────────────────────────────────────
def phi_40(psi_39: np.ndarray, theta: np.ndarray | None = None,
           Sigma_s: float = SIGMA_S) -> np.ndarray:
    x = np.asarray(psi_39, dtype=float).ravel()
    if theta is None:
        theta = np.linspace(0.0, 2.0 * np.pi, max(x.size, 2))
    grad_theta = np.gradient(theta)
    sigma_field = np.full_like(grad_theta, Sigma_s)
    return np.stack([grad_theta, sigma_field])


# ──────────────────────────────────────────────────────────────────────────────
# Φ^∞ first arc (langΣoilith.ini — Zone 104: φ₄₁–φ₅₀)
# ──────────────────────────────────────────────────────────────────────────────
def phi_41(
    psi_40: np.ndarray,
    theta_i: float = 0.0,
    rho_i: float = 1.0,
    trust_i: float = 1.0,
) -> np.ndarray:
    g = np.asarray(psi_40, dtype=float)
    gt = _as_1d(g[0]) if g.ndim == 2 and g.shape[0] >= 1 else _as_1d(g)
    t = np.linspace(0.0, 2.0 * np.pi, max(gt.size, 2))
    if gt.size != t.size:
        gt = np.resize(gt, t.shape)
    return rho_i * gt + trust_i * np.sin(theta_i + t)


def phi_42(
    psi_41_i: np.ndarray,
    psi_41_j: np.ndarray,
    delta_sigma: float = 0.5,
) -> np.ndarray:
    a, b = _as_1d(psi_41_i), _as_1d(psi_41_j)
    m = min(a.size, b.size)
    diff = float(np.mean(np.abs(a[:m] - b[:m])))
    if diff >= delta_sigma:
        return np.zeros(m, dtype=float)
    prod = a[:m] * b[:m]
    return prod * np.exp(1j * np.gradient(a[:m]))


def phi_43(
    psi_42: np.ndarray,
    zeta_1: float = ZETA_1,
    Sigma_s: float = SIGMA_S,
) -> np.ndarray:
    x = np.real(psi_42) if np.iscomplexobj(psi_42) else _as_1d(psi_42)
    return x * zeta_1 * (Sigma_s ** 2)


def phi_44(
    psi_43: np.ndarray,
    n_agents: int = 3,
    seed: int = 0,
    k_quorum: int = 2,
    tau: float = TAU,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    base = _as_1d(psi_43)
    mat = np.stack([base + 0.05 * rng.standard_normal(base.size) for _ in range(n_agents)])
    good = np.linalg.norm(mat, axis=1) >= tau
    if int(good.sum()) >= k_quorum:
        return mat[good].mean(axis=0)
    return np.zeros_like(base)


def phi_45(psi_44: np.ndarray, steps: int = 5, dt: float = 0.08) -> np.ndarray:
    x = _as_1d(psi_44).copy()
    for _ in range(steps):
        lap = np.roll(x, 1) + np.roll(x, -1) - 2.0 * x
        x = x + dt * lap
    return x


def phi_46(psi_45: np.ndarray, psi_0: np.ndarray) -> np.ndarray:
    p = _as_1d(psi_45)
    s = np.resize(_as_1d(psi_0), p.shape)
    return p * np.tanh(s)


def phi_47(psi_46: np.ndarray) -> np.ndarray:
    x = _as_1d(psi_46)
    t = np.linspace(0.0, np.pi, x.size)
    return np.stack([x, 0.95 * x + 0.01, np.cos(t) * x])


def phi_48(psi_47: np.ndarray, phi_b: float = 0.25 * np.pi) -> np.ndarray:
    a = np.asarray(psi_47, dtype=complex)
    if a.ndim < 2 or a.shape[0] < 2:
        x = _as_1d(psi_47)
        return (x + np.exp(1j * phi_b) * x[::-1]) / np.sqrt(2.0)
    p, q = a[0], a[1]
    m = min(p.size, q.size)
    return (p[:m] + np.exp(1j * phi_b) * q[:m]) / np.sqrt(2.0)


def phi_49(psi_48: np.ndarray, density: float = 1.0) -> np.ndarray:
    x = np.real(psi_48) if np.iscomplexobj(psi_48) else _as_1d(psi_48)
    g_theta = np.gradient(x)
    g_tau = np.gradient(g_theta)
    return density * (g_theta + g_tau)


def phi_50(psi_49: np.ndarray, Sigma_s: float = SIGMA_S) -> np.ndarray:
    x = _as_1d(psi_49)
    return Sigma_s * np.tanh(x) + np.cumsum(x) / max(x.size, 1)


# ──────────────────────────────────────────────────────────────────────────────
# Zone-Math arc (φ₅₁–φ₆₀) — scale-aware metrics, entropy kernels, curvature,
# and resolution change ("zoom"). Implements the formulas catalogued in the
# Zone 43 / Zone 45 sections of langΣoilith.ini.
# ──────────────────────────────────────────────────────────────────────────────
def _as_prob(p: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    """Coerce an array to a discrete probability distribution (clip, normalise)."""
    x = np.abs(_as_1d(p))
    s = float(x.sum())
    if s < eps:
        # Uniform if input is degenerate.
        return np.full(x.size or 1, 1.0 / max(x.size, 1))
    return x / s


def phi_51(psi: np.ndarray, q: float = 2.0) -> np.ndarray:
    """φ₅₁ — **Rényi entropy** ``ℋ_q(ψ) = (1/(1-q)) · log Σ pᵢ^q``.

    Returns a 1-element array so the language layer can wrap it as a ψ-cell.
    Falls back to Shannon entropy (− Σ p log p) at ``q == 1``.
    """
    p = _as_prob(psi)
    if abs(q - 1.0) < 1e-9:
        h = float(-np.sum(p * np.log(np.clip(p, 1e-12, 1.0))))
    else:
        s = float(np.sum(np.power(p, q)))
        h = float(np.log(max(s, 1e-12)) / (1.0 - q))
    return np.array([h])


def phi_52(
    psi_x: np.ndarray,
    psi_y: np.ndarray,
    beta: float = 0.5,
) -> np.ndarray:
    """φ₅₂ — **Power-law (Z) distance** ``d_Z(x, y) = |x − y|^β``.

    Elementwise. Sublinear when ``β ∈ (0, 1)``, hyperlinear above 1. This is
    the canonical "scaling-law zoom" — same data, new metric.
    """
    x = _as_1d(psi_x)
    y = _as_1d(psi_y)
    n = max(x.size, y.size)
    if n == 0:
        return np.array([0.0])
    x, y = np.resize(x, n), np.resize(y, n)
    return np.power(np.abs(x - y) + 1e-18, float(beta))


def phi_53(
    psi_x: np.ndarray,
    psi_y: np.ndarray,
    beta: float = 0.5,
    q: float = 2.0,
    theta: float = 0.0,
) -> np.ndarray:
    """φ₅₃ — **Zone 43 entropic-reflection metric**.

        d_{Z₄₃}(x, y) = |x − y|^β · log(1 + 1/ℋ_q(x, y)) · sin(θ(x, y))

    ``theta`` is the *accumulated phase difference* (the language layer
    threads ``Cell.phase`` through here). Returns elementwise; a downstream
    norm collapses to a scalar.
    """
    base = phi_52(psi_x, psi_y, beta=beta)
    p_joint = _as_prob(np.concatenate([_as_1d(psi_x), _as_1d(psi_y)]))
    h = phi_51(p_joint, q=q)[0]
    entropy_term = float(np.log1p(1.0 / max(abs(h), 1e-12)))
    # sin(θ) is zero at θ=0 (default), which would collapse the metric to 0.
    # Use sin(θ) + small ε so the value/curvature signal survives a default
    # phase, while honouring the formal sin(θ) form when θ ≠ 0.
    phase_term = float(np.sin(theta)) + 1e-3
    return base * entropy_term * phase_term


def phi_54(
    psi_x: np.ndarray,
    psi_y: np.ndarray,
    beta_a: float = 0.5,
    beta_b: float = 1.0,
    q: float = 2.0,
) -> np.ndarray:
    """φ₅₄ — **Zone divergence** ``𝔇_{ab}(x, y)`` between two scaling laws.

        𝔇 = |log(d_a / d_b)| + |ℋ_a(x) − ℋ_b(y)|

    Returns a 1-element scalar — the *coherence tension* between zones.
    """
    d_a = phi_52(psi_x, psi_y, beta=beta_a)
    d_b = phi_52(psi_x, psi_y, beta=beta_b)
    log_ratio = float(np.mean(np.abs(np.log((d_a + 1e-12) / (d_b + 1e-12)))))
    h_x = phi_51(psi_x, q=q)[0]
    h_y = phi_51(psi_y, q=q)[0]
    return np.array([log_ratio + abs(h_x - h_y)])


def phi_55(
    d_ab: np.ndarray,
    h_a: float | np.ndarray,
    weights: np.ndarray | None = None,
) -> np.ndarray:
    """φ₅₅ — **Transition tensor** ``T_{ab} = Σᵢ (pᵢ / ℋ_a) · d_{ab}``.

    Entropy-weighted, normalised composition. Defaults to uniform ``pᵢ``.
    """
    d = _as_1d(d_ab)
    if weights is None:
        w = np.full(d.size or 1, 1.0 / max(d.size, 1))
    else:
        w = _as_prob(weights)
        w = np.resize(w, d.size or 1)
    h = float(np.asarray(h_a).mean()) if not np.isscalar(h_a) else float(h_a)
    h = max(abs(h), 1e-12)
    return (w / h) * d


def phi_56(
    psi_x: np.ndarray,
    psi_y: np.ndarray,
    beta: float = 0.5,
    q: float = 2.0,
) -> np.ndarray:
    """φ₅₆ — **Entropic curvature tensor** ``K^{μν} = ∂²[d/ℋ_q] / ∂x^μ∂y^ν``.

    Finite-difference second mixed partial along the two operand vectors.
    Result is a flattened (n × n) tensor.
    """
    x = _as_1d(psi_x)
    y = _as_1d(psi_y)
    n = max(x.size, y.size, 2)
    x, y = np.resize(x, n), np.resize(y, n)
    h = phi_51(np.concatenate([x, y]), q=q)[0]
    norm_h = max(abs(h), 1e-12)
    d = np.power(np.abs(x[:, None] - y[None, :]) + 1e-18, float(beta)) / norm_h
    # Mixed partial via centred finite differences (periodic boundary).
    dx = np.gradient(d, axis=0)
    dxy = np.gradient(dx, axis=1)
    return dxy.ravel()


def phi_57(
    psi_x: np.ndarray,
    psi_y: np.ndarray,
    beta: float = 0.5,
    q: float = 2.0,
    dt: float = 1.0,
) -> np.ndarray:
    """φ₅₇ — **Entropy-flux gradient** ``J_{ab}(x, y) = (pᵢ/ℋ) · ∂d/∂t``.

    Approximates ∂/∂t with finite differences over the operand sequence.
    """
    d = phi_52(psi_x, psi_y, beta=beta)
    h = phi_51(_as_1d(psi_x), q=q)[0]
    grad = np.gradient(d) / max(dt, 1e-12)
    w = np.full(d.size or 1, 1.0 / max(d.size, 1))
    return (w / max(abs(h), 1e-12)) * grad


def phi_58(
    psi_a: np.ndarray,
    psi_b: np.ndarray,
    beta_a: float = 0.5,
    beta_b: float = 1.0,
    q: float = 2.0,
) -> np.ndarray:
    """φ₅₈ — **Entropy-adaptive metric** ``Δ̂_{ab} = √(d_a · d_b) / √(ℋ_a · ℋ_b)``.

    Geometric mean of two scaling distances, normalised by the geometric
    mean of their entropies. Bends distance with informational density.
    """
    d_a = phi_52(psi_a, psi_b, beta=beta_a)
    d_b = phi_52(psi_a, psi_b, beta=beta_b)
    h_a = abs(phi_51(psi_a, q=q)[0])
    h_b = abs(phi_51(psi_b, q=q)[0])
    denom = max(np.sqrt(h_a * h_b), 1e-12)
    return np.sqrt(d_a * d_b + 1e-24) / denom


def phi_59(psi: np.ndarray, factor: int = 2) -> np.ndarray:
    """φ₅₉ — **Zoom out** (pool): downsample ``ψ`` by an integer factor via
    block averaging. The lattice loses resolution but preserves total mass.
    """
    x = _as_1d(psi)
    f = max(int(factor), 1)
    if f <= 1 or x.size == 0:
        return x.copy()
    pad = (-x.size) % f
    if pad:
        x = np.concatenate([x, np.zeros(pad)])
    return x.reshape(-1, f).mean(axis=1)


def phi_60(psi: np.ndarray, factor: int = 2) -> np.ndarray:
    """φ₆₀ — **Zoom in** (refine): upsample ``ψ`` by an integer factor via
    linear interpolation. The lattice gains resolution; total mass scales
    linearly so the *density* picture is preserved.
    """
    x = _as_1d(psi)
    f = max(int(factor), 1)
    if f <= 1 or x.size <= 1:
        return np.repeat(x, f) if x.size <= 1 else x.copy()
    new_size = (x.size - 1) * f + 1
    old_idx = np.linspace(0.0, 1.0, x.size)
    new_idx = np.linspace(0.0, 1.0, new_size)
    return np.interp(new_idx, old_idx, x)


# ──────────────────────────────────────────────────────────────────────────────
# Registry & chain runner
# ──────────────────────────────────────────────────────────────────────────────
PHI = {k: globals()[f"phi_{k}"] for k in range(61)}


def chain(seed: int = 0, n: int = 16, k_max: int = 40) -> dict[int, np.ndarray]:
    """Run φ₀ → φ_{k_max} in canonical order with default trust/coherence couplings.

    Use ``k_max=50`` for the Φ^∞ first arc (φ₄₁–φ₅₀) after the seed lattice.

    Returns a dict mapping k → ψ_k (the output of φ_k) so any declaration's
    state can be inspected after the full bloom.
    """
    state: dict[int, np.ndarray] = {}
    state[0] = phi_0(n=n, seed=seed)                           # ψ₀
    state[1] = phi_1(state[0])                                 # ψ₁^inward
    psi1_minus, psi1_plus = phi_2(state[1])
    state[2] = np.stack([psi1_minus, psi1_plus])
    state[3] = phi_3(state[1])                                 # id⁰
    state[4] = phi_4(state[1])                                 # ψ_burst
    state[5] = phi_5(state[4])                                 # ψ₀'
    state[6] = phi_6(state[5], state[1])                       # ψ₆^Δ
    state[7] = phi_7(state[6], psi1_plus)                      # ψ₇^λ
    psi8_minus, psi8_plus = phi_8(state[7])
    state[8] = np.stack([np.real(psi8_minus), psi8_plus])
    state[9] = phi_9(psi8_plus)                                # ψ₉
    state[10] = phi_10(state[9])
    state[11] = phi_11(state[10], state[0])
    state[12] = phi_12(state[11])
    state[13] = phi_13(state[12], state[0])
    state[14] = phi_14(state[13])
    state[15] = phi_15(state[14])
    state[16] = phi_16(state[15])
    state[17] = phi_17(state[16], state[3])
    state[18] = phi_18(state[17])
    state[19] = phi_19(state[18])
    state[20] = phi_20(state[19])
    state[21] = phi_21(state[20])
    state[22] = phi_22(state[21])
    state[23] = phi_23(state[22])
    state[24] = phi_24(state[23])
    state[25] = phi_25(state[24])
    d_theta_dt, tense = phi_26(state[25])
    state[26] = d_theta_dt
    state[27] = phi_27(state[26])
    state[28] = phi_28(state[27])
    state[29] = phi_29(state[28])
    state[30] = phi_30(state[29])
    state[31] = phi_31(state[30], state[14])
    state[32] = phi_32(state[31])
    state[33] = phi_33(state[32])
    state[34] = phi_34(state[33])
    state[35] = phi_35(state[34], state[0])
    state[36] = phi_36(state[35])
    state[37] = phi_37(state[36])
    state[38] = phi_38(state[37])
    state[39] = phi_39(state[38])
    state[40] = phi_40(state[39])

    if k_max >= 41:
        theta_i, rho_i, trust_i = 0.1, 1.0, 1.0
        state[41] = phi_41(state[40], theta_i=theta_i, rho_i=rho_i, trust_i=trust_i)
        psi41_j = phi_41(
            state[40],
            theta_i=theta_i + 0.15,
            rho_i=rho_i,
            trust_i=trust_i,
        )
        state[42] = phi_42(state[41], psi41_j)
        state[43] = phi_43(state[42])
        state[44] = phi_44(state[43], seed=seed)
        state[45] = phi_45(state[44])
        state[46] = phi_46(state[45], state[0])
        state[47] = phi_47(state[46])
        state[48] = phi_48(state[47])
        state[49] = phi_49(state[48])
        state[50] = phi_50(state[49])

    # The φ₂₆ block in langΣoilith.ini also demonstrates these compositions:
    causal_link = causality(d_theta_dt[:3], np.array([4.0, 5.0, 6.0]))
    seq_result = sequence_fn(d_theta_dt[:3], np.array([7.0, 8.0, 9.0]),
                             np.array([10.0, 11.0, 12.0]))
    dur_result = duration_fn(d_theta_dt[:3], np.array([13.0, 14.0, 15.0]),
                             np.array([16.0, 17.0, 18.0]))
    state[-1] = np.array([causal_link.mean(), seq_result.mean(), dur_result])

    return state


if __name__ == "__main__":
    import sys

    k_hi = 50 if "--full" in sys.argv else 40
    s = chain(k_max=k_hi)
    for k in range(k_hi + 1):
        v = s[k]
        shape = getattr(v, "shape", None)
        print(f"φ_{k:>2}  shape={shape}  ‖ψ‖={np.linalg.norm(np.asarray(v).ravel()):.4f}")
    print(f"\nφ₂₆ companion (causal, sequence, duration) → {s[-1]}")
