# DevOps CLI

蓝鲸 DevOps 平台迭代管理命令行工具。

## 打包
```bash
python -m pip install --upgrade build twine
python -m build
twine upload dist/*
```

## 安装
* 源码安装
```bash
pip install -e .
```

* pip安装
```bash
pipx install zt-devops-cli
```

## 使用

### 登陆

首次运行时会自动打开浏览器，请登录蓝鲸 DevOps。登录成功后 cookie 会缓存到本地。
```bash
zt-devops-cli login
```

### 空间管理

```bash
zt-devops-cli project list
```

### ZTeam 项目列表
```bash
zt-devops-cli zteam-project list --project f39507
```

### 迭代管理

#### 迭代列表
```bash
zt-devops-cli sprint list --project k64352
```

#### 创建迭代

```bash
zt-devops-cli sprint create --project k64352 \
  --title "迭代名称" \
  --start-date 2026-04-04 \
  --end-date 2026-05-30 \
  --purpose "迭代目标"
```

#### 启用迭代
```bash
zt-devops-cli sprint start --project k64352 --sprint-id <id>
```

#### 删除迭代
```bash
zt-devops-cli sprint delete --project k64352 --sprint-id <id>
```

#### 完成迭代
```bash
zt-devops-cli sprint done --project k64352 --sprint-id <id>
```

### 任务管理

#### 查询任务列表（TASK）
```bash
zt-devops-cli task list --project f39507 \
  --start-date 2026-04-01 \
  --end-date 2026-04-30 \
  --creator zt07905
```

#### 新增任务（TASK）
```bash
zt-devops-cli task create --project <project-id> \ # 通过 project list 获取
  --title "<任务标题>" \
  --owner <工号> \
  --estimate-start <预计开始时间： yyyy-MM-dd> \
  --estimate-end <预计完成时间: yyyy-MM-dd> \
  --origin-hours 8.00 \ # 预估工时
  --remain-hours 8.00 \ # 实际工时
  --zteam-project-id <zteam-project-id> # 通过 zteam-project list 获取
```

## 配置
- cookie 缓存：`~/.zt-devops-cli/cookies.json`
- 配置文件：`~/.zt-devops-cli/config.yaml`
