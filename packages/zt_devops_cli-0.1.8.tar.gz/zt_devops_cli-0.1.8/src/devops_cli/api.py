"""API 请求封装"""
import json as json_mod
import requests
from typing import Optional

from .auth import get_auth_cookies, get_auth_headers
from .config import config


class DevOpsAPI:
    """DevOps API 客户端"""

    def __init__(self, project_id: str):
        self.project_id = project_id
        self.base_url = config.BASE_URL

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """发送 API 请求"""
        cookies = get_auth_cookies()
        headers = get_auth_headers(cookies, self.project_id)

        url = f"{self.base_url}/{path}"

        # 处理 data 参数
        if "data" in kwargs:
            kwargs["json"] = kwargs.pop("data")

        # #############################################
        # # 打印 curl 命令
        # curl_parts = [f"curl -X {method}"]
        # for k, v in headers.items():
        #     curl_parts.append(f"-H '{k}: {v}'")
        # if "json" in kwargs:
        #     curl_parts.append(f"-d '{json_mod.dumps(kwargs['json'], ensure_ascii=False)}'")
        # curl_parts.append(f"'{url}'")
        # print(" ".join(curl_parts))
        # #############################################

        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            cookies=cookies,
            **kwargs
        )

        if response.status_code >= 400:
            raise Exception(f"API 错误: {response.status_code} {response.text}")

        return response.json()

    # ========== 迭代操作 ==========

    def create_sprint(
            self,
            title: str,
            start_date: str,
            end_date: str,
            purpose: str = "",
            test_start_date: Optional[str] = None,
            test_end_date: Optional[str] = None,
            development_pic: str = "",
            test_pic: str = "",
            acceptance_pic: str = "",
    ) -> dict:
        """创建迭代"""
        data = {
            "title": title,
            "startDate": start_date,
            "endDate": end_date,
            "purpose": purpose,
            "daterange": [f"{start_date}T16:00:00.000Z", f"{end_date}T16:00:00.000Z"],
            "reviewTime": "",
            "testStartDate": test_start_date or start_date,
            "testEndDate": test_end_date or end_date,
            "developmentPic": development_pic,
            "testPic": test_pic,
            "acceptancePic": acceptance_pic,
            "excludeTime": "",
            "state": "ACTIVE",
        }
        return self._request("POST", f"/ms/vteam/api/user/issue_sprint/{self.project_id}", data=data)

    def start_sprint(self, sprint_data: dict) -> dict:
        """启用迭代"""
        return self._request("PUT", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/start", data=sprint_data)

    def delete_sprint(self, sprint_id: str) -> dict:
        """删除迭代"""
        return self._request("DELETE", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/{sprint_id}")

    def done_sprint(self, sprint_id: str) -> dict:
        """完成迭代"""
        return self._request("PUT", f"/ms/vteam/api/user/issue_sprint/{self.project_id}/complete/{sprint_id}")

    def list_sprints(self) -> dict:
        """查询迭代列表"""
        return self._request("GET",
                             f"/ms/vteam/api/user/issue_sprint/{self.project_id}/flat?num=1&count=1&size=20&content=&start_time=&end_time=&state=ACTIVE%2CNOT_STARTED&sort_field=CREATED_TIME&sort_rule=DESC")

    def list_projects(self) -> dict:
        """查询项目列表"""
        return self._request("GET",
                             f"/ms/projectmanager/api/user/project/cw/selectByType?showTree=false&haveUser=false")

    def list_zteam_projects(self) -> dict:
        """查询 ZTeam 项目列表（任务字段选项）"""
        return self._request(
            "GET",
            f"/ms/vteam/api/user/issue_field_value/{self.project_id}/option/5abdcb4c783e11edbef4fa819a160800?all=false&classify=TASK",
        )

    # ========== 任务操作 ==========

    def create_task(
            self,
            title: str,
            model_type_id: str,
            priority: str = "CENTRAL",
            editor_type: str = "MARKDOWN",
            desc: str = "",
            parent_id: str = "",
            demand_classify: str = "-1",
            instance_values: Optional[list] = None,
    ) -> dict:
        """创建 TASK 任务"""
        data = {
            "title": title,
            "modelTypeId": model_type_id,
            "priority": priority,
            "editorType": editor_type,
            "desc": desc,
            "parentId": parent_id,
            "relationIssue": {},
            "demandClassify": demand_classify,
            "fileVO": [],
            "labelId": [],
            "instanceValue": instance_values or [],
        }
        return self._request("POST", f"/ms/vteam/api/user/issue/{self.project_id}", data=data)

    def list_tasks(
            self,
            creator: Optional[str] = None,
            start_date: Optional[str] = None,
            end_date: Optional[str] = None,
            num: int = 1,
            size: int = 20,
            remember: bool = False,
    ) -> dict:
        """按条件查询 TASK 列表"""

        data = [ {"name": "exclude", "value": []}]

        if creator:
            data.insert(0, {"name": "createUser", "value": [creator]})
        if start_date and end_date:
            data.insert(0, {"name": "estimate_start_time", "value": [start_date, end_date]})
            data.insert(0, {"name": "estimate_end_time", "value": [start_date, end_date]})
        remember_value = str(remember).lower()
        return self._request(
            "POST",
            f"/ms/vteam/api/user/issue/{self.project_id}/table/TASK?num={num}&size={size}&remember={remember_value}",
            data=data,
        )
