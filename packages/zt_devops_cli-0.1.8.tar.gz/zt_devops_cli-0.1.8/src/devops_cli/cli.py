"""CLI 入口"""
import click
import json
import shutil
from .api import DevOpsAPI
from .auth import login
from .config import config


def _normalize_cell(value):
    if value is None:
        return "-"
    return str(value)


def _truncate_text(text, width):
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width <= 1:
        return text[:width]
    return text[: width - 1] + "…"


def render_table(headers, rows, max_width=120, no_truncate_headers=None):
    if not rows:
        click.echo("暂无数据")
        return

    terminal_width = shutil.get_terminal_size((max_width, 20)).columns
    table_max_width = min(max_width, terminal_width)

    no_truncate_headers = set(no_truncate_headers or [])

    normalized_rows = []
    for row in rows:
        normalized = [_normalize_cell(cell) for cell in row[: len(headers)]]
        if len(normalized) < len(headers):
            normalized.extend(["-"] * (len(headers) - len(normalized)))
        normalized_rows.append(normalized)

    widths = [len(h) for h in headers]
    for row in normalized_rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    # 边框和分隔占用: 左右边框 + 每列两侧空格 + 列分隔符
    overhead = 3 * len(headers) + 1
    available = max(20, table_max_width - overhead)
    min_col_width = 10
    widths = [max(min_col_width, w) for w in widths]

    total = sum(widths)
    if total > available:
        fixed_idx = {i for i, h in enumerate(headers) if h in no_truncate_headers}
        shrinkable_idx = [i for i in range(len(headers)) if i not in fixed_idx]

        if shrinkable_idx:
            while sum(widths) > available:
                idx = max(shrinkable_idx, key=lambda i: widths[i])
                if widths[idx] > min_col_width:
                    widths[idx] -= 1
                else:
                    if all(widths[i] <= min_col_width for i in shrinkable_idx):
                        break
        # 若仍超出可用宽度，保留不截断列完整内容，允许终端自动换行/横向滚动查看

    def format_row(cells):
        parts = []
        for i, cell in enumerate(cells):
            text = cell if headers[i] in no_truncate_headers else _truncate_text(cell, widths[i])
            parts.append(f" {text.ljust(widths[i])} ")
        return "|" + "|".join(parts) + "|"

    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    click.echo(border)
    click.echo(format_row(headers))
    click.echo(border)
    for row in normalized_rows:
        click.echo(format_row(row))
    click.echo(border)


@click.group()
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option(
    "--output",
    "-o",
    "output_format",
    type=click.Choice(["human", "json"], case_sensitive=False),
    default="json",
    show_default=True,
    help="输出格式: human(表格) / json",
)
@click.pass_context
def cli(ctx, project, output_format):
    """DevOps 平台迭代管理工具"""
    ctx.ensure_object(dict)
    ctx.obj["project"] = project or config.default_project
    ctx.obj["output_format"] = output_format.lower()


@cli.command("login")
@click.option(
    "--headed",
    is_flag=True,
    help="显示浏览器窗口，用于无环境变量时的手动登录",
)
def cmd_login(headed):
    """登录 - 打开浏览器重新获取 cookie（默认无头；需手动登录时请传 --headed）"""
    login(headless=not headed)

@cli.group()
def sprint():
    """迭代管理命令组"""
    pass


@cli.group()
def project():
    """项目管理命令组"""
    pass


@cli.group()
def issue():
    """需求管理命令组"""
    pass


@cli.group()
def task():
    """任务管理命令组"""
    pass


@cli.group("zteam-project")
def zteam_project():
    """ZTeam 项目命令组"""
    pass


@sprint.command("create")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--title", "-t", required=True, help="迭代名称")
@click.option("--start-date", "-s", required=True, help="开始日期 (YYYY-MM-DD)")
@click.option("--end-date", "-e", required=True, help="结束日期 (YYYY-MM-DD)")
@click.option("--purpose", help="迭代目标")
@click.option("--test-start", help="测试开始日期")
@click.option("--test-end", help="测试结束日期")
@click.pass_context
def create_sprint(ctx, project, title, start_date, end_date, purpose, test_start, test_end):
    """创建迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        result = api.create_sprint(
            title=title,
            start_date=start_date,
            end_date=end_date,
            purpose=purpose or "",
            test_start_date=test_start,
            test_end_date=test_end,
        )
        click.echo(f"创建成功! 迭代 ID: {result.get('id')}")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("start")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def start_sprint(ctx, project, sprint_id):
    """启用迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        sprints = api.list_sprints()
        sprint_data = None
        for s in sprints.get("data").get("content"):
            if s.get("id") == sprint_id:
                sprint_data = s
                break

        if not sprint_data:
            click.echo(f"未找到迭代: {sprint_id}", err=True)
            return

        result = api.start_sprint(sprint_data)
        click.echo(f"启用成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("delete")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def delete_sprint(ctx, project, sprint_id):
    """删除迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    if not click.confirm(f"确认删除迭代 {sprint_id}?"):
        return

    try:
        api.delete_sprint(sprint_id)
        click.echo(f"删除成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("done")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def done_sprint(ctx, project, sprint_id):
    """ 完成迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    if not click.confirm(f"确认完成迭代 {sprint_id}?"):
        return

    try:
        api.done_sprint(sprint_id)
        click.echo(f"完成成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.pass_context
def list_sprint(ctx, project):
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        sprints = api.list_sprints()
        sprint_list = sprints.get("data", {}).get("content", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    sprint_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["迭代名称", "迭代ID", "开始时间", "结束时间", "迭代状态", "提测时间", "测试开始时间",
                     "测试完成时间", "验收完成", "开发负责人", "测试负责人", "验收负责人"],
            rows=[
                [
                    s.get("title"),
                    s.get("id"),
                    s.get("startDate"),
                    s.get("endDate"),
                    s.get("state"),
                    s.get("testStartDate"),
                    s.get("smokeEndDate"),
                    s.get("testEndDate"),
                    s.get("acceptanceEndDate"),
                    s.get("developmentPic"),
                    s.get("testPic"),
                    s.get("acceptancePic")
                ]
                for s in sprint_list
            ],
            no_truncate_headers=["迭代ID", "迭代名称"],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@project.command("list")
@click.pass_context
def list_project(ctx):
    api = DevOpsAPI("")

    try:
        projects = api.list_projects()
        project_list = projects.get("data", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    project_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["项目代码", "项目名称", "部门名称"],
            rows=[
                [
                    s.get("projectCode"),
                    s.get("projectName"),
                    s.get("deptName"),
                ]
                for s in project_list
            ],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@zteam_project.command("list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.pass_context
def list_zteam_project(ctx, project):
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_zteam_projects()
        project_list = payload.get("data", []) if isinstance(payload, dict) else []
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    project_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["ZTeam项目ID", "ZTeam项目名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in project_list
            ],
            no_truncate_headers=["ZTeam项目ID", "ZTeam项目名称"],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@task.command("list")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--start-date", required=True, help="预计开始/结束筛选起始日期 (YYYY-MM-DD)")
@click.option("--end-date", required=True, help="预计开始/结束筛选结束日期 (YYYY-MM-DD)")
@click.option("--creator", required=None, help="创建人账号，例如 zt07905")
@click.option("--num", default=1, show_default=True, type=int, help="页码")
@click.option("--size", default=20, show_default=True, type=int, help="每页条数")
@click.option("--remember/--no-remember", default=False, show_default=True, help="是否启用后端记忆筛选条件")
@click.pass_context
def list_task(ctx, project, start_date, end_date, creator, num, size, remember):
    def _extract_task_list(payload):
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if isinstance(data, list):
            return data
        if not isinstance(data, dict):
            return []

        # 兼容多种后端结构:
        # 1) data 为列表
        # 2) data.content 为列表
        # 3) data.records.content 为列表（DevOps 新版任务接口）
        content = None
        if isinstance(data.get("content"), list):
            content = data.get("content")
        else:
            records = data.get("records")
            if isinstance(records, dict) and isinstance(records.get("content"), list):
                content = records.get("content")

        if not isinstance(content, list):
            return []

        def _unwrap_value(v):
            if not isinstance(v, dict):
                return v
            for key in ("value", "label", "name", "displayName", "text", "title"):
                if key in v and v.get(key) not in (None, ""):
                    return v.get(key)
            # 兜底: 防止 {...} 这类占位结构影响输出
            return None

        result = []
        for item in content:
            if not isinstance(item, dict):
                continue

            # data.records.content[].property 结构
            prop = item.get("property")
            if isinstance(prop, dict):
                flattened = {}
                for k, v in prop.items():
                    flattened[k] = _unwrap_value(v)
                result.append(flattened)
                continue

            # 兼容旧结构（item 本身就是任务对象）
            normalized = {}
            for k, v in item.items():
                normalized[k] = _unwrap_value(v)
            result.append(normalized)

        return result

    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        result = api.list_tasks(
            start_date=start_date,
            end_date=end_date,
            creator=creator,
            num=num,
            size=size,
            remember=remember,
        )
        task_list = _extract_task_list(result)

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    task_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["任务ID", "标题", "状态", "创建人", "负责人", "预计开始", "预计结束"],
            rows=[
                [
                    t.get("id") or t.get("issue_id"),
                    t.get("title") or t.get("name"),
                    t.get("state") or t.get("status"),
                    t.get("createUser") or t.get("creator"),
                    t.get("currentOwner") or t.get("handler"),
                    t.get("estimate_start_time") or t.get("estimateStartTime"),
                    t.get("estimate_end_time") or t.get("estimateEndTime"),
                ]
                for t in task_list
            ],
            no_truncate_headers=["任务ID", "标题"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@task.command("create")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--title", "-t", required=True, help="任务标题")
@click.option("--model-type-id", default="4ba3d2994e6b456da3ddc43e94ad5c70", show_default=True, help="任务模型 ID")
@click.option("--priority", default="CENTRAL", show_default=True, help="优先级")
@click.option("--editor-type", default="MARKDOWN", show_default=True, help="编辑器类型")
@click.option("--desc", default="", show_default=True, help="任务描述")
@click.option("--parent-id", default="", show_default=True, help="父任务 ID")
@click.option("--demand-classify", default="-1", show_default=True, help="需求分类")
@click.option("--owner", required=True, help="负责人账号，例如 zt07905")
@click.option("--estimate-start", required=True, help="预计开始日期 (YYYY-MM-DD)")
@click.option("--estimate-end", required=True, help="预计结束日期 (YYYY-MM-DD)")
@click.option("--origin-hours", default="8.00", show_default=True, help="原始工时")
@click.option("--remain-hours", default="8.00", show_default=True, help="剩余工时")
@click.option("--zteam-project-id", required=True, default="", show_default=True, help="Zteam项目id")
@click.option("--field", "custom_fields", multiple=True, help="自定义字段，格式: fieldId=value，可重复")
@click.pass_context
def create_task(
        ctx,
        project,
        title,
        model_type_id,
        priority,
        editor_type,
        desc,
        parent_id,
        demand_classify,
        owner,
        estimate_start,
        estimate_end,
        origin_hours,
        remain_hours,
        zteam_project_id,
        custom_fields,
):
    """创建任务（TASK）"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()

    def _parse_custom_fields(entries):
        result = []
        for item in entries:
            if "=" not in item:
                raise click.ClickException(f"--field 参数格式错误: {item}，应为 fieldId=value")
            field_id, value = item.split("=", 1)
            field_id = field_id.strip()
            if not field_id:
                raise click.ClickException(f"--field 参数格式错误: {item}，fieldId 不能为空")
            result.append({"fieldId": field_id, "value": value})
        return result

    # 与浏览器抓包参数保持一致，便于直接复现页面创建行为
    instance_values = [
        {"fieldId": "456e808faf85419b912535da923b7f22", "value": owner},
        {"fieldId": "684f26d36cd747f68dde32104a701956", "value": ""},
        {"fieldId": "a84b922da3054d08bfee798f7162a0c6", "value": ""},
        {"fieldId": "0cae6c6cbfb64b52a33beec849dd7a78", "value": ""},
        {"fieldId": "80d66115a46946a08a3cebf542df6339", "value": estimate_start},
        {"fieldId": "43bc2b003ee445c999fc948005238658", "value": estimate_end},
        {"fieldId": "753aefd914cb403685edcb6fc79d5de2", "value": ""},
        {"fieldId": "4d24b8fe8c41406f9a0ed023aac0f954", "value": origin_hours},
        {"fieldId": "b70df6a5c2ba4a5f96b41416949df209", "value": remain_hours},
        {"fieldId": "5abdcb4c783e11edbef4fa819a160800", "value": zteam_project_id},
    ]
    instance_values.extend(_parse_custom_fields(custom_fields))

    api = DevOpsAPI(project_id)
    try:
        result = api.create_task(
            title=title,
            model_type_id=model_type_id,
            priority=priority,
            editor_type=editor_type,
            desc=desc,
            parent_id=parent_id,
            demand_classify=demand_classify,
            instance_values=instance_values,
        )
        if ctx.obj.get("output_format") == "json":
            click.echo(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            return
        task_id = result.get("data", {}).get("id") if isinstance(result, dict) else None
        click.echo(f"创建成功! 任务 ID: {task_id or '-'}")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def main():
    cli()


if __name__ == "__main__":
    main()
