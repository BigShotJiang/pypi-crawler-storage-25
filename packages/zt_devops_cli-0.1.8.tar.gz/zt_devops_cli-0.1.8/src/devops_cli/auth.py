"""认证模块 - 通过 Playwright 获取浏览器 cookie"""
import json
import os

from playwright.sync_api import sync_playwright

from .config import config


# DevOps 域名
DEVOPS_DOMAIN = ".ztn.cn"

# SSO 登录页面
LOGIN_URL = "https://sso.ztn.cn/v2/cas/login?service=https%3A%2F%2Fpaas.ztn.cn%2Flogin%2F%3Fc_url%3Dhttps%3A%2F%2Fdevops.ztn.cn%2Fconsole%2F&locale=zh_CN"

def save_cookies(cookies: dict):
    """保存 cookie 到缓存文件"""
    config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(config.COOKIE_FILE, "w") as f:
        json.dump(cookies, f)

def load_cookies() -> dict:
    """从缓存文件加载 cookie"""
    if config.COOKIE_FILE.exists():
        with open(config.COOKIE_FILE) as f:
            return json.load(f)
    return {}

def get_auth_headers(cookies: dict, project_id: str) -> dict:
    """从 cookie 构建认证请求头"""
    return {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN",
        "Content-Type": "application/json;charset=UTF-8",
        "Origin": "https://devops.ztn.cn",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "X-DEVOPS-TENANT-ID": cookies.get("X-DEVOPS-TENANT-ID", "ZTN"),
        "bk_token": cookies.get("bk_token", ""),
        "X-DEVOPS-TOKEN": cookies.get("X-DEVOPS-TOKEN", ""),
        "X-DEVOPS-PROJECT-ID": project_id,
    }

def get_auth_cookies() -> dict:
    """获取认证 cookie，优先使用缓存，失效则重新获取"""
    cookies = load_cookies()

    # 检查必要的 cookie 是否存在
    required = ["bk_token", "X-DEVOPS-TOKEN"]
    if all(cookies.get(k) for k in required):
        return cookies

    # 缓存失效，重新获取
    cookies = get_cookies_from_browser()
    save_cookies(cookies)

    print(f"已获取新的 cookie: {cookies}")
    return cookies

def open_login_page(page) -> bool:
    """自动登录 - 尝试读取环境变量自动填写账号密码"""
    username = os.environ.get("ZT_SSO_USERNAME")
    password = os.environ.get("ZT_SSO_PASSWORD")

    if not username or not password:
        return False

    print(f"检测到环境变量，自动登录中...")

    # 等待页面加载
    page.wait_for_selector("#username")

    try:
        # 填写用户名
        page.fill("#username", username)
        print(f"已填写用户名")

        # 填写密码 - 使用 #password2
        page.fill("#password2", password)
        print(f"已填写密码")

        # 点击登录按钮
        page.click(".login_in")
        print("已点击登录按钮")

        return True

    except Exception as e:
        print(f"自动登录失败: {e}")

    return False

def get_cookies_from_browser(headless) -> dict:
    """通过 Playwright 从浏览器获取 cookie"""
    print("正在启动浏览器（无头模式），请登录...")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context()
        page = context.new_page()

        # 导航到 SSO 登录页
        page.goto(LOGIN_URL)

        # 尝试自动登录
        if not open_login_page(page):
            print(
                "自动登录失败。无头模式下无法手动操作页面，请设置环境变量 "
                "ZT_SSO_USERNAME 与 ZT_SSO_PASSWORD 后重试。"
            )
            browser.close()
            raise RuntimeError(
                "无头模式需要 ZT_SSO_USERNAME / ZT_SSO_PASSWORD 环境变量以完成自动登录。"
            )

        print("等待登录完成...")
        page.wait_for_function(
            f"""() => {{
                const cookies = document.cookie;
                return cookies.includes('X-DEVOPS-TOKEN');
            }}""",
            timeout=300000  # 5分钟超时
        )

        print("登陆成功. 已获取关键 cookie")

        # 获取所有 cookie
        cookies = context.cookies()

        # 提取需要的 cookie
        cookie_dict = {}
        for cookie in cookies:
            if cookie["domain"] == DEVOPS_DOMAIN or DEVOPS_DOMAIN in cookie["domain"]:
                cookie_dict[cookie["name"]] = cookie["value"]

        # 从 cookie 获取 X-DEVOPS-PROJECT-ID
        project_id = page.evaluate("""() => {
            const name = 'X-DEVOPS-PROJECT-ID=';
            const decodedCookie = decodeURIComponent(document.cookie);
            const ca = decodedCookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return '';
        }""")

        if project_id:
            cookie_dict["X-DEVOPS-PROJECT-ID"] = project_id

        browser.close()

    return cookie_dict

def login(headless) -> dict:
    """手动登录 - 强制打开浏览器重新获取 cookie"""
    print("正在启动浏览器（无头模式），请重新登录...")
    cookies = get_cookies_from_browser(headless)
    save_cookies(cookies)
    print("登录成功，cookie 已缓存!")
    return cookies

if __name__ == "__main__":
    print(login())