"""配置管理模块"""
import os
from pathlib import Path
from typing import Optional

import yaml


class Config:
    """配置类"""
    
    CONFIG_DIR = Path.home() / ".zt-devops-cli"
    COOKIE_FILE = CONFIG_DIR / "cookies.json"
    CONFIG_FILE = CONFIG_DIR / "config.yaml"
    
    # API 配置
    BASE_URL = "https://devops.ztn.cn"
    
    def __init__(self):
        self._config = self._load_config()
    
    def _load_config(self) -> dict:
        """加载配置文件"""
        if self.CONFIG_FILE.exists():
            with open(self.CONFIG_FILE) as f:
                return yaml.safe_load(f) or {}
        return {}
    
    @property
    def default_project(self) -> Optional[str]:
        return self._config.get("default_project")
    
    @property
    def browser_channel(self) -> str:
        return self._config.get("browser_channel", "chromium")


config = Config()
