from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.message_model_role import MessageModelRole
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message_model_structured_result_type_0 import MessageModelStructuredResultType0


T = TypeVar("T", bound="MessageModel")


@_attrs_define
class MessageModel:
    """
    Attributes:
        role (MessageModelRole):
        content (str):
        created_at (datetime.datetime):
        structured_result (MessageModelStructuredResultType0 | None | Unset):
    """

    role: MessageModelRole
    content: str
    created_at: datetime.datetime
    structured_result: MessageModelStructuredResultType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.message_model_structured_result_type_0 import (
            MessageModelStructuredResultType0,
        )

        role = self.role.value

        content = self.content

        created_at = self.created_at.isoformat()

        structured_result: dict[str, Any] | None | Unset
        if isinstance(self.structured_result, Unset):
            structured_result = UNSET
        elif isinstance(self.structured_result, MessageModelStructuredResultType0):
            structured_result = self.structured_result.to_dict()
        else:
            structured_result = self.structured_result

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "role": role,
                "content": content,
                "created_at": created_at,
            }
        )
        if structured_result is not UNSET:
            field_dict["structured_result"] = structured_result

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_model_structured_result_type_0 import (
            MessageModelStructuredResultType0,
        )

        d = dict(src_dict)
        role = MessageModelRole(d.pop("role"))

        content = d.pop("content")

        created_at = isoparse(d.pop("created_at"))

        def _parse_structured_result(
            data: object,
        ) -> MessageModelStructuredResultType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                structured_result_type_0 = MessageModelStructuredResultType0.from_dict(data)

                return structured_result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MessageModelStructuredResultType0 | None | Unset, data)

        structured_result = _parse_structured_result(d.pop("structured_result", UNSET))

        message_model = cls(
            role=role,
            content=content,
            created_at=created_at,
            structured_result=structured_result,
        )

        message_model.additional_properties = d
        return message_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
