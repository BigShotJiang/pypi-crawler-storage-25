from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message_model import MessageModel


T = TypeVar("T", bound="ConversationDetail")


@_attrs_define
class ConversationDetail:
    """
    Attributes:
        conv_id (str):
        workflow (str):
        status (str):
        created_at (datetime.datetime):
        messages (list[MessageModel]):
        current_pending_id (None | str | Unset):
    """

    conv_id: str
    workflow: str
    status: str
    created_at: datetime.datetime
    messages: list[MessageModel]
    current_pending_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        conv_id = self.conv_id

        workflow = self.workflow

        status = self.status

        created_at = self.created_at.isoformat()

        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)

        current_pending_id: None | str | Unset
        if isinstance(self.current_pending_id, Unset):
            current_pending_id = UNSET
        else:
            current_pending_id = self.current_pending_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "conv_id": conv_id,
                "workflow": workflow,
                "status": status,
                "created_at": created_at,
                "messages": messages,
            }
        )
        if current_pending_id is not UNSET:
            field_dict["current_pending_id"] = current_pending_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_model import MessageModel

        d = dict(src_dict)
        conv_id = d.pop("conv_id")

        workflow = d.pop("workflow")

        status = d.pop("status")

        created_at = isoparse(d.pop("created_at"))

        messages = []
        _messages = d.pop("messages")
        for messages_item_data in _messages:
            messages_item = MessageModel.from_dict(messages_item_data)

            messages.append(messages_item)

        def _parse_current_pending_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_pending_id = _parse_current_pending_id(d.pop("current_pending_id", UNSET))

        conversation_detail = cls(
            conv_id=conv_id,
            workflow=workflow,
            status=status,
            created_at=created_at,
            messages=messages,
            current_pending_id=current_pending_id,
        )

        conversation_detail.additional_properties = d
        return conversation_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
