from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.poll_response_status import PollResponseStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.poll_response_structured_result_type_0 import PollResponseStructuredResultType0


T = TypeVar("T", bound="PollResponse")


@_attrs_define
class PollResponse:
    """
    Attributes:
        status (PollResponseStatus):
        result_text (None | str | Unset):
        structured_result (None | PollResponseStructuredResultType0 | Unset):
        error (None | str | Unset):
        result_parse_error (None | str | Unset):
    """

    status: PollResponseStatus
    result_text: None | str | Unset = UNSET
    structured_result: None | PollResponseStructuredResultType0 | Unset = UNSET
    error: None | str | Unset = UNSET
    result_parse_error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.poll_response_structured_result_type_0 import (
            PollResponseStructuredResultType0,
        )

        status = self.status.value

        result_text: None | str | Unset
        if isinstance(self.result_text, Unset):
            result_text = UNSET
        else:
            result_text = self.result_text

        structured_result: dict[str, Any] | None | Unset
        if isinstance(self.structured_result, Unset):
            structured_result = UNSET
        elif isinstance(self.structured_result, PollResponseStructuredResultType0):
            structured_result = self.structured_result.to_dict()
        else:
            structured_result = self.structured_result

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        result_parse_error: None | str | Unset
        if isinstance(self.result_parse_error, Unset):
            result_parse_error = UNSET
        else:
            result_parse_error = self.result_parse_error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if result_text is not UNSET:
            field_dict["result_text"] = result_text
        if structured_result is not UNSET:
            field_dict["structured_result"] = structured_result
        if error is not UNSET:
            field_dict["error"] = error
        if result_parse_error is not UNSET:
            field_dict["result_parse_error"] = result_parse_error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.poll_response_structured_result_type_0 import (
            PollResponseStructuredResultType0,
        )

        d = dict(src_dict)
        status = PollResponseStatus(d.pop("status"))

        def _parse_result_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        result_text = _parse_result_text(d.pop("result_text", UNSET))

        def _parse_structured_result(
            data: object,
        ) -> None | PollResponseStructuredResultType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                structured_result_type_0 = PollResponseStructuredResultType0.from_dict(data)

                return structured_result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PollResponseStructuredResultType0 | Unset, data)

        structured_result = _parse_structured_result(d.pop("structured_result", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_result_parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        result_parse_error = _parse_result_parse_error(d.pop("result_parse_error", UNSET))

        poll_response = cls(
            status=status,
            result_text=result_text,
            structured_result=structured_result,
            error=error,
            result_parse_error=result_parse_error,
        )

        poll_response.additional_properties = d
        return poll_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
