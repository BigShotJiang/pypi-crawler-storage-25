from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AppConfig")


@_attrs_define
class AppConfig:
    """
    Attributes:
        app_id (str):
        org_id (str):
        created_at (datetime.datetime):
        created_by (str):
        llm_base_url (str | Unset):  Default: ''.
        llm_model (str | Unset):  Default: ''.
        llm_configured (bool | Unset):  Default: False.
    """

    app_id: str
    org_id: str
    created_at: datetime.datetime
    created_by: str
    llm_base_url: str | Unset = ""
    llm_model: str | Unset = ""
    llm_configured: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_id = self.app_id

        org_id = self.org_id

        created_at = self.created_at.isoformat()

        created_by = self.created_by

        llm_base_url = self.llm_base_url

        llm_model = self.llm_model

        llm_configured = self.llm_configured

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_id": app_id,
                "org_id": org_id,
                "created_at": created_at,
                "created_by": created_by,
            }
        )
        if llm_base_url is not UNSET:
            field_dict["llm_base_url"] = llm_base_url
        if llm_model is not UNSET:
            field_dict["llm_model"] = llm_model
        if llm_configured is not UNSET:
            field_dict["llm_configured"] = llm_configured

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        app_id = d.pop("app_id")

        org_id = d.pop("org_id")

        created_at = isoparse(d.pop("created_at"))

        created_by = d.pop("created_by")

        llm_base_url = d.pop("llm_base_url", UNSET)

        llm_model = d.pop("llm_model", UNSET)

        llm_configured = d.pop("llm_configured", UNSET)

        app_config = cls(
            app_id=app_id,
            org_id=org_id,
            created_at=created_at,
            created_by=created_by,
            llm_base_url=llm_base_url,
            llm_model=llm_model,
            llm_configured=llm_configured,
        )

        app_config.additional_properties = d
        return app_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
