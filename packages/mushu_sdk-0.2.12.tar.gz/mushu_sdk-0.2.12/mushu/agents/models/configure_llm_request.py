from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ConfigureLlmRequest")


@_attrs_define
class ConfigureLlmRequest:
    """
    Attributes:
        llm_base_url (str):
        llm_model (str):
        api_key (str):
    """

    llm_base_url: str
    llm_model: str
    api_key: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        llm_base_url = self.llm_base_url

        llm_model = self.llm_model

        api_key = self.api_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "llm_base_url": llm_base_url,
                "llm_model": llm_model,
                "api_key": api_key,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        llm_base_url = d.pop("llm_base_url")

        llm_model = d.pop("llm_model")

        api_key = d.pop("api_key")

        configure_llm_request = cls(
            llm_base_url=llm_base_url,
            llm_model=llm_model,
            api_key=api_key,
        )

        configure_llm_request.additional_properties = d
        return configure_llm_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
