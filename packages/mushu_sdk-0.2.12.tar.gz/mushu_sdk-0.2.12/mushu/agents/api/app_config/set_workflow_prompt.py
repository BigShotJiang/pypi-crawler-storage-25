from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.workflow_prompt_override_request import WorkflowPromptOverrideRequest
from ...models.workflow_prompt_override_response import WorkflowPromptOverrideResponse
from ...types import Response


def _get_kwargs(
    app_id: str,
    workflow_name: str,
    *,
    body: WorkflowPromptOverrideRequest,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/apps/{app_id}/agents-config/workflows/{workflow_name}/prompt".format(
            app_id=quote(str(app_id), safe=""),
            workflow_name=quote(str(workflow_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkflowPromptOverrideResponse | None:
    if response.status_code == 200:
        response_200 = WorkflowPromptOverrideResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkflowPromptOverrideResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    workflow_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: WorkflowPromptOverrideRequest,
    authorization: str,
) -> Response[HTTPValidationError | WorkflowPromptOverrideResponse]:
    """Set Workflow Prompt

     Set a tenant-specific system prompt for a workflow.

    Overrides the built-in WorkflowRegistry prompt for this app. Pass an empty
    string to revert — or use DELETE to remove the override entirely.

    Args:
        app_id (str):
        workflow_name (str):
        authorization (str):
        body (WorkflowPromptOverrideRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkflowPromptOverrideResponse]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        workflow_name=workflow_name,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    workflow_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: WorkflowPromptOverrideRequest,
    authorization: str,
) -> HTTPValidationError | WorkflowPromptOverrideResponse | None:
    """Set Workflow Prompt

     Set a tenant-specific system prompt for a workflow.

    Overrides the built-in WorkflowRegistry prompt for this app. Pass an empty
    string to revert — or use DELETE to remove the override entirely.

    Args:
        app_id (str):
        workflow_name (str):
        authorization (str):
        body (WorkflowPromptOverrideRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkflowPromptOverrideResponse
    """

    return sync_detailed(
        app_id=app_id,
        workflow_name=workflow_name,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    workflow_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: WorkflowPromptOverrideRequest,
    authorization: str,
) -> Response[HTTPValidationError | WorkflowPromptOverrideResponse]:
    """Set Workflow Prompt

     Set a tenant-specific system prompt for a workflow.

    Overrides the built-in WorkflowRegistry prompt for this app. Pass an empty
    string to revert — or use DELETE to remove the override entirely.

    Args:
        app_id (str):
        workflow_name (str):
        authorization (str):
        body (WorkflowPromptOverrideRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkflowPromptOverrideResponse]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        workflow_name=workflow_name,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    workflow_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: WorkflowPromptOverrideRequest,
    authorization: str,
) -> HTTPValidationError | WorkflowPromptOverrideResponse | None:
    """Set Workflow Prompt

     Set a tenant-specific system prompt for a workflow.

    Overrides the built-in WorkflowRegistry prompt for this app. Pass an empty
    string to revert — or use DELETE to remove the override entirely.

    Args:
        app_id (str):
        workflow_name (str):
        authorization (str):
        body (WorkflowPromptOverrideRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkflowPromptOverrideResponse
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            workflow_name=workflow_name,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
