from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connect_response import ConnectResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/chatgpt/connect",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConnectResponse | None:
    if response.status_code == 200:
        response_200 = ConnectResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConnectResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConnectResponse]:
    """Chatgpt Connect

     Generate a ChatGPT Plus OAuth authorize URL (iOS WKWebView flow).

    Returns a session_id and auth_url. Open the auth_url in a WKWebView.
    When the WKWebView intercepts a localhost:1455 redirect, send the full
    redirect URL to POST /chatgpt/callback with the session_id.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> ConnectResponse | None:
    """Chatgpt Connect

     Generate a ChatGPT Plus OAuth authorize URL (iOS WKWebView flow).

    Returns a session_id and auth_url. Open the auth_url in a WKWebView.
    When the WKWebView intercepts a localhost:1455 redirect, send the full
    redirect URL to POST /chatgpt/callback with the session_id.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConnectResponse]:
    """Chatgpt Connect

     Generate a ChatGPT Plus OAuth authorize URL (iOS WKWebView flow).

    Returns a session_id and auth_url. Open the auth_url in a WKWebView.
    When the WKWebView intercepts a localhost:1455 redirect, send the full
    redirect URL to POST /chatgpt/callback with the session_id.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> ConnectResponse | None:
    """Chatgpt Connect

     Generate a ChatGPT Plus OAuth authorize URL (iOS WKWebView flow).

    Returns a session_id and auth_url. Open the auth_url in a WKWebView.
    When the WKWebView intercepts a localhost:1455 redirect, send the full
    redirect URL to POST /chatgpt/callback with the session_id.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
