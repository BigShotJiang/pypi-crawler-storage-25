from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.poll_response import PollResponse
from ...types import Response


def _get_kwargs(
    conv_id: str,
    pending_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/conversations/{conv_id}/poll/{pending_id}".format(
            conv_id=quote(str(conv_id), safe=""),
            pending_id=quote(str(pending_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PollResponse | None:
    if response.status_code == 200:
        response_200 = PollResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PollResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conv_id: str,
    pending_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | PollResponse]:
    """Poll Message

     Poll for the result of a send_message call.

    Args:
        conv_id (str):
        pending_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PollResponse]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
        pending_id=pending_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conv_id: str,
    pending_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | PollResponse | None:
    """Poll Message

     Poll for the result of a send_message call.

    Args:
        conv_id (str):
        pending_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PollResponse
    """

    return sync_detailed(
        conv_id=conv_id,
        pending_id=pending_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conv_id: str,
    pending_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | PollResponse]:
    """Poll Message

     Poll for the result of a send_message call.

    Args:
        conv_id (str):
        pending_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PollResponse]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
        pending_id=pending_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conv_id: str,
    pending_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | PollResponse | None:
    """Poll Message

     Poll for the result of a send_message call.

    Args:
        conv_id (str):
        pending_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PollResponse
    """

    return (
        await asyncio_detailed(
            conv_id=conv_id,
            pending_id=pending_id,
            client=client,
        )
    ).parsed
