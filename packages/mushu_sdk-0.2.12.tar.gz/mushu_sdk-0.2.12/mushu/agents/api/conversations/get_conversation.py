from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.conversation_detail import ConversationDetail
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    conv_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/conversations/{conv_id}".format(
            conv_id=quote(str(conv_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConversationDetail | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConversationDetail.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConversationDetail | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConversationDetail | HTTPValidationError]:
    """Get Conversation

     Get conversation detail including full message history.

    Args:
        conv_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationDetail | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> ConversationDetail | HTTPValidationError | None:
    """Get Conversation

     Get conversation detail including full message history.

    Args:
        conv_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationDetail | HTTPValidationError
    """

    return sync_detailed(
        conv_id=conv_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ConversationDetail | HTTPValidationError]:
    """Get Conversation

     Get conversation detail including full message history.

    Args:
        conv_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationDetail | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> ConversationDetail | HTTPValidationError | None:
    """Get Conversation

     Get conversation detail including full message history.

    Args:
        conv_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationDetail | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            conv_id=conv_id,
            client=client,
        )
    ).parsed
