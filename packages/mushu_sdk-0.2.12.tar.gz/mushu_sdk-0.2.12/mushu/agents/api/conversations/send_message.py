from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.send_message_request import SendMessageRequest
from ...models.send_message_response import SendMessageResponse
from ...types import Response


def _get_kwargs(
    conv_id: str,
    *,
    body: SendMessageRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/conversations/{conv_id}/messages".format(
            conv_id=quote(str(conv_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SendMessageResponse | None:
    if response.status_code == 200:
        response_200 = SendMessageResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SendMessageResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,
) -> Response[HTTPValidationError | SendMessageResponse]:
    """Send Message

     Send a user message. Enqueues LLM call and returns pending_id to poll.

    Args:
        conv_id (str):
        body (SendMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SendMessageResponse]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,
) -> HTTPValidationError | SendMessageResponse | None:
    """Send Message

     Send a user message. Enqueues LLM call and returns pending_id to poll.

    Args:
        conv_id (str):
        body (SendMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SendMessageResponse
    """

    return sync_detailed(
        conv_id=conv_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,
) -> Response[HTTPValidationError | SendMessageResponse]:
    """Send Message

     Send a user message. Enqueues LLM call and returns pending_id to poll.

    Args:
        conv_id (str):
        body (SendMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SendMessageResponse]
    """

    kwargs = _get_kwargs(
        conv_id=conv_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conv_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendMessageRequest,
) -> HTTPValidationError | SendMessageResponse | None:
    """Send Message

     Send a user message. Enqueues LLM call and returns pending_id to poll.

    Args:
        conv_id (str):
        body (SendMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SendMessageResponse
    """

    return (
        await asyncio_detailed(
            conv_id=conv_id,
            client=client,
            body=body,
        )
    ).parsed
