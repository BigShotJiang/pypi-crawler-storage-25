from __future__ import annotations

from typing import Any, TypedDict

class VatRegisterMarkerJSON(TypedDict):
    Id: int
    Code: str
    IsActive: bool
