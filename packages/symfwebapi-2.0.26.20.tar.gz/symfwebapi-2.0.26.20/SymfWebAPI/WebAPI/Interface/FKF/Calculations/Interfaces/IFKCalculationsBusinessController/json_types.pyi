from __future__ import annotations

from typing import Any, TypedDict

class BalanceAndTurnoverListElementJSON(TypedDict):
    Type: Any
    YearId: int
    AccountFull: str
    Synthetic: int
    Analytic1: int | None
    Analytic2: int | None
    Analytic3: int | None
    Analytic4: int | None
    Analytic5: int | None
    Account01: str
    Account02: str
    Account03: str
    Account04: str
    Account05: str
    Account06: str
    Account07: str
    Account08: str
    Account09: str
    Account10: str
    Account11: str
    Account12: str
    Account13: str
    Account14: str
    Account15: str
    Account16: str
    Account17: str
    Account18: str
    Account19: str
    Account20: str
    Value: float | int
    BO: float | int
    OR: float | int
    Value1: float | int
    Value2: float | int
    Value3: float | int
    Value4: float | int
    Value5: float | int
    Value6: float | int
    Value7: float | int
    Value8: float | int
    Value9: float | int
    Value10: float | int
    Value11: float | int
    Value12: float | int
    Value13: float | int
    Value14: float | int
    Value15: float | int
    Value16: float | int
    Value17: float | int
    Value18: float | int
    Value19: float | int
    Value20: float | int
    Value21: float | int
    Value22: float | int
    Value23: float | int
    CalculationDate: str
