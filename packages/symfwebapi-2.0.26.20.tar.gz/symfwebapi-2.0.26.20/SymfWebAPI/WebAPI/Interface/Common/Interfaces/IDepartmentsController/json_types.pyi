from __future__ import annotations

from typing import Any, TypedDict

class DepartmentJSON(TypedDict):
    Id: int
    Name: str
    Code: str
