from __future__ import annotations

from typing import Any, TypedDict

class DocumentSeriesJSON(TypedDict):
    Id: int
    Code: str
