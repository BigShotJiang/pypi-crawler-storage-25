from __future__ import annotations

from typing import Any, TypedDict

class RegionJSON(TypedDict):
    Id: int
    Name: str
    Description: str
    Active: bool
