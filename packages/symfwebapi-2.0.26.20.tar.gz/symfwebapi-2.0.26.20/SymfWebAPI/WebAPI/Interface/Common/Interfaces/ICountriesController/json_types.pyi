from __future__ import annotations

from typing import Any, TypedDict

class CountryJSON(TypedDict):
    Id: int
    Name: str
    Code: str
    Active: bool
