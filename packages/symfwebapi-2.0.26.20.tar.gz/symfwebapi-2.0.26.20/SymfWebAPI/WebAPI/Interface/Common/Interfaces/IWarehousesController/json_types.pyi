from __future__ import annotations

from typing import Any, TypedDict

class WarehouseJSON(TypedDict):
    Id: int
    Name: str
    Code: str
