from __future__ import annotations

from typing import Any, TypedDict

class PKWiUCodeJSON(TypedDict):
    Id: int
    Name: str
    Description: str
    Active: bool
