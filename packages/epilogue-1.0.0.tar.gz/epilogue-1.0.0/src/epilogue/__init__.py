from epilogue.lib import atomic, defer

__all__ = ["atomic", "defer"]