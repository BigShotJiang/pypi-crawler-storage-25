import functools
from contextvars import ContextVar
from typing import Any, Callable

_queue: ContextVar[list[tuple[Callable, tuple, dict]]] = ContextVar("epilogue_queue")


def defer(func: Callable, *args: Any, **kwargs: Any) -> None:
    try:
        _queue.get().append((func, args, kwargs))
    except LookupError:
        raise RuntimeError(
            "epilogue.defer() must be called inside an @epilogue.atomic context."
        )


def atomic(func: Callable) -> Callable:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        token = _queue.set([])

        try:
            result = func(*args, **kwargs)
            intents = _queue.get()
        finally:
            _queue.reset(token)

        errors = []
        for action, action_args, action_kwargs in intents:
            try:
                action(*action_args, **action_kwargs)
            except Exception as e:
                errors.append(e)

        if errors:
            raise ExceptionGroup(
                "Exceptions occurred during deferred epilogue execution", errors
            )

        return result

    return wrapper
