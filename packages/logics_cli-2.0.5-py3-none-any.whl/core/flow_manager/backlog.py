from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class BacklogItem:
    item_id: str
    title: str
    status: str = "open"
    priority: int = 3
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    path: Path | None = None
    body: str = ""
    frontmatter: dict[str, Any] = field(default_factory=dict)


def read_backlog(directory: str | Path) -> list[BacklogItem]:
    directory = Path(directory)
    items = [read_item(path) for path in sorted(directory.glob("*.md"))]
    return items


def read_item(path: str | Path) -> BacklogItem:
    path = Path(path)
    content = path.read_text(encoding="utf-8")
    frontmatter, body = _split_frontmatter(content)
    item_id = str(frontmatter.get("id") or path.stem)
    title = str(frontmatter.get("title") or _extract_title(path.stem, body))
    status = str(frontmatter.get("status", "open"))
    priority = int(frontmatter.get("priority", 3))
    created_at = _parse_datetime(frontmatter.get("created_at"))
    return BacklogItem(
        item_id=item_id,
        title=title,
        status=status,
        priority=priority,
        created_at=created_at,
        path=path,
        body=body,
        frontmatter=dict(frontmatter),
    )


def write_item(item: BacklogItem, path: str | Path | None = None) -> Path:
    target = Path(path or item.path or f"{item.item_id}.md")
    frontmatter = dict(item.frontmatter)
    frontmatter.update(
        {
            "id": item.item_id,
            "title": item.title,
            "status": item.status,
            "priority": item.priority,
            "created_at": item.created_at.isoformat(),
        }
    )
    payload = f"---\n{yaml.safe_dump(frontmatter, sort_keys=False).strip()}\n---\n"
    body = item.body if item.body.startswith("\n") or not item.body else f"\n{item.body}"
    target.write_text(payload + body, encoding="utf-8")
    return target


def _split_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    if content.startswith("---\n"):
        try:
            _, raw_frontmatter, body = content.split("---\n", 2)
        except ValueError:
            return {}, content
        frontmatter = yaml.safe_load(raw_frontmatter) or {}
        if not isinstance(frontmatter, dict):
            frontmatter = {}
        return frontmatter, content
    return _parse_blockquote_indicators(content), content


def _parse_blockquote_indicators(content: str) -> dict[str, Any]:
    """Parse the `> Key: Value` indicator format used in Logics markdown files."""
    indicators: dict[str, Any] = {}
    for line in content.splitlines():
        if line.startswith("> ") and ": " in line:
            key, _, value = line[2:].partition(": ")
            indicators[key.strip().lower().replace(" ", "_")] = value.strip()
    raw_status = indicators.get("status", "")
    indicators["status"] = _normalize_status(raw_status)
    return indicators


def _normalize_status(raw: str) -> str:
    """Map Logics indicator status values to CLI status tokens."""
    mapping = {
        "done": "done",
        "archived": "done",
        "in progress": "in-progress",
        "in-progress": "in-progress",
        "blocked": "blocked",
    }
    return mapping.get(raw.lower(), "open")


def _extract_title(stem: str, body: str) -> str:
    for line in body.splitlines():
        if line.startswith("## ") and " - " in line:
            return line.split(" - ", 1)[1].strip()
        if line.startswith("# "):
            return line[2:].strip()
    return stem.replace("_", " ").replace("-", " ").strip()


def _parse_datetime(raw: Any) -> datetime:
    if isinstance(raw, datetime):
        return raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
    if isinstance(raw, str) and raw:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    return datetime(1970, 1, 1, tzinfo=timezone.utc)

