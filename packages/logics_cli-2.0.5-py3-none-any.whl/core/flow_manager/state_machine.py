from __future__ import annotations

VALID_STATUSES = ("open", "in-progress", "review", "done")
VALID_TRANSITIONS = {
    "open": {"in-progress"},
    "in-progress": {"review"},
    "review": {"done"},
    "done": set(),
}


def can_transition(current_status: str, next_status: str) -> bool:
    return next_status in VALID_TRANSITIONS.get(current_status, set())

