from __future__ import annotations

from collections.abc import Iterable

from core.flow_manager.backlog import BacklogItem

STATUS_ORDER = {"open": 0, "in-progress": 1, "review": 2, "done": 3}


def filter_items(
    items: Iterable[BacklogItem],
    *,
    status: str | None = None,
    priority: int | None = None,
) -> list[BacklogItem]:
    result = list(items)
    if status is not None:
        result = [item for item in result if item.status == status]
    if priority is not None:
        result = [item for item in result if item.priority == priority]
    return result


def sort_items(items: Iterable[BacklogItem]) -> list[BacklogItem]:
    return sorted(
        items,
        key=lambda item: (
            item.priority,
            STATUS_ORDER.get(item.status, 99),
            item.created_at,
            item.item_id,
        ),
    )


def next_item(items: Iterable[BacklogItem]) -> BacklogItem | None:
    actionable = [item for item in items if item.status != "done"]
    ordered = sort_items(actionable)
    return ordered[0] if ordered else None

