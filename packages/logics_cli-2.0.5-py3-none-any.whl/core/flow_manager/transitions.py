from __future__ import annotations

from dataclasses import replace

from core.flow_manager.state_machine import VALID_STATUSES, can_transition


class InvalidTransitionError(ValueError):
    pass


def validate_transition(current_status: str, next_status: str) -> None:
    if current_status not in VALID_STATUSES:
        raise InvalidTransitionError(f"Unknown current status: {current_status}")
    if next_status not in VALID_STATUSES:
        raise InvalidTransitionError(f"Unknown target status: {next_status}")
    if not can_transition(current_status, next_status):
        raise InvalidTransitionError(
            f"Invalid transition from '{current_status}' to '{next_status}'"
        )


def apply_transition(item, next_status: str):
    validate_transition(item.status, next_status)
    return replace(item, status=next_status)

