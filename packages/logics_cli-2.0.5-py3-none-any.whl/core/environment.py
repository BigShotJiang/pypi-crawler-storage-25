from __future__ import annotations

import dataclasses
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

from core.config import ConfigValidationError, LogicsConfig, load_config
from core.skills import SkillStatus, resolve_skills

GENERATED_ARTIFACTS = ("INDEX.md", "RELATIONSHIPS.md", "hybrid_assist_audit.jsonl")
DEFAULT_PROVIDER_URLS = {
    "openai": "https://api.openai.com/v1/models",
    "gemini": "https://generativelanguage.googleapis.com",
    "anthropic": "https://api.anthropic.com",
}


@dataclass(frozen=True)
class CliStatus:
    status: str
    version: str | None


@dataclass(frozen=True)
class ProjectStatus:
    status: str
    configFound: bool
    workflowDirs: list[str]
    missingDirs: list[str]


@dataclass(frozen=True)
class HybridStatus:
    enabled: bool
    providers: list[str] = field(default_factory=list)
    providerStatuses: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class GitFootprintStatus:
    status: str
    trackedArtifacts: list[str]
    warnings: list[str]


@dataclass(frozen=True)
class EnvironmentIssue:
    code: str
    severity: str
    message: str
    fixable: bool = False


@dataclass(frozen=True)
class EnvironmentReport:
    version: str
    cli: CliStatus
    project: ProjectStatus
    skills: list[SkillStatus]
    hybrid: HybridStatus
    gitFootprint: GitFootprintStatus
    issues: list[EnvironmentIssue]
    repairAvailable: bool


@dataclass(frozen=True)
class RepairAction:
    code: str
    description: str
    path: str | None = None
    applied: bool = False


def check(
    *,
    project_root: str | Path,
    config_path: str | Path | None = None,
    cli_version: str | None = None,
) -> EnvironmentReport:
    root = Path(project_root).resolve()
    version = cli_version or _read_repo_version(root)
    issues: list[EnvironmentIssue] = []

    try:
        config = load_config(config_path or root / "logics.yaml")
        config_found = config.initialized
        config_issues = [
            EnvironmentIssue(
                code="config_warning",
                severity="warning",
                message=warning,
                fixable=False,
            )
            for warning in config.warnings
        ]
        issues.extend(config_issues)
    except ConfigValidationError as exc:
        config = None
        config_found = bool(config_path or (root / "logics.yaml").exists())
        issues.append(
            EnvironmentIssue(
                code="config_invalid",
                severity="error",
                message=str(exc),
                fixable=False,
            )
        )

    cli = CliStatus(status="ok", version=version)
    project = _check_project(root, config_found=config_found, config=config, issues=issues)
    skills = _check_skills(config, version=version, root=root, issues=issues)
    git_footprint = _check_git_footprint(root, issues=issues)

    report = EnvironmentReport(
        version=version,
        cli=cli,
        project=project,
        skills=skills,
        hybrid=HybridStatus(
            enabled=False if config is None else config.hybrid.enabled,
            providers=[] if config is None else list(config.hybrid.providers),
            providerStatuses=[] if config is None else _check_hybrid(config, issues=issues),
        ),
        gitFootprint=git_footprint,
        issues=issues,
        repairAvailable=any(issue.fixable for issue in issues),
    )
    dataclasses.asdict(report)
    return report


def repair(
    *,
    project_root: str | Path,
    dry_run: bool = True,
    config_path: str | Path | None = None,
) -> list[RepairAction]:
    root = Path(project_root).resolve()
    actions: list[RepairAction] = []
    config_file = Path(config_path) if config_path is not None else root / "logics.yaml"

    if not config_file.exists():
        actions.append(
            _apply_action(
                RepairAction(
                    code="create_config",
                    description="Create default logics.yaml",
                    path=str(config_file),
                ),
                dry_run=dry_run,
                callback=lambda: config_file.write_text(_default_config_text(), encoding="utf-8"),
            )
        )

    config = load_config(config_file if config_file.exists() else None)
    for name, directory in (
        ("backlog", config.paths.backlog),
        ("tasks", config.paths.tasks),
        ("request", config.paths.request),
        ("specs", config.paths.specs),
    ):
        if directory.exists():
            continue
        actions.append(
            _apply_action(
                RepairAction(
                    code="create_directory",
                    description=f"Create missing workflow directory '{name}'",
                    path=str(directory),
                ),
                dry_run=dry_run,
                callback=lambda directory=directory: directory.mkdir(parents=True, exist_ok=True),
            )
        )

    for artifact in _tracked_generated_artifacts(root):
        actions.append(
            _apply_action(
                RepairAction(
                    code="ignore_generated_artifact",
                    description=f"Ignore generated artifact '{artifact}' in .gitignore",
                    path=str(root / ".gitignore"),
                ),
                dry_run=dry_run,
                callback=lambda artifact=artifact: _ensure_gitignore_entry(root, artifact),
            )
        )

    return actions


def _check_project(
    root: Path,
    *,
    config_found: bool,
    config: LogicsConfig | None,
    issues: list[EnvironmentIssue],
) -> ProjectStatus:
    if not config_found:
        issues.append(
            EnvironmentIssue(
                code="config_missing",
                severity="warning",
                message="logics.yaml is missing; project is not initialized.",
                fixable=True,
            )
        )
        workflow_dirs = ["backlog", "tasks", "request", "specs"]
        return ProjectStatus(
            status="not_initialized",
            configFound=False,
            workflowDirs=workflow_dirs,
            missingDirs=workflow_dirs,
        )

    if config is None:
        return ProjectStatus(
            status="invalid",
            configFound=True,
            workflowDirs=["backlog", "tasks", "request", "specs"],
            missingDirs=[],
        )

    workflow_dirs = {
        "backlog": config.paths.backlog,
        "tasks": config.paths.tasks,
        "request": config.paths.request,
        "specs": config.paths.specs,
    }
    missing = [name for name, path in workflow_dirs.items() if not path.exists()]
    for name in missing:
        issues.append(
            EnvironmentIssue(
                code="workflow_dir_missing",
                severity="warning",
                message=f"Workflow directory '{name}' is missing.",
                fixable=True,
            )
        )
    status = "ready" if not missing else "warning"
    return ProjectStatus(
        status=status,
        configFound=True,
        workflowDirs=list(workflow_dirs),
        missingDirs=missing,
    )


def _check_skills(
    config: LogicsConfig | None,
    *,
    version: str,
    root: Path,
    issues: list[EnvironmentIssue],
) -> list[SkillStatus]:
    if config is None:
        return [
            SkillStatus(
                name="flow-manager",
                status="ok",
                version=version,
                message="Core workflow engine is always available.",
            )
        ]

    resolved = resolve_skills(config, skills_root=root / "skills", version=version)
    for skill in resolved:
        if skill.status == "missing":
            issues.append(
                EnvironmentIssue(
                    code="skill_missing",
                    severity="warning",
                    message=skill.message or f"Declared skill '{skill.name}' is missing.",
                    fixable=False,
                )
            )
    return resolved


def _check_hybrid(
    config: LogicsConfig,
    *,
    issues: list[EnvironmentIssue],
) -> list[dict[str, str]]:
    if not config.hybrid.enabled:
        return []

    provider_statuses: list[dict[str, str]] = []
    for provider in config.hybrid.providers:
        status = _probe_provider(provider)
        provider_statuses.append({"name": provider, "status": status})
        if status != "ok":
            issues.append(
                EnvironmentIssue(
                    code="hybrid_provider_unreachable",
                    severity="warning",
                    message=f"Hybrid provider '{provider}' is unreachable.",
                    fixable=False,
                )
            )
    return provider_statuses


def _check_git_footprint(root: Path, *, issues: list[EnvironmentIssue]) -> GitFootprintStatus:
    tracked = _tracked_generated_artifacts(root)
    warnings = [
        f"Generated artifact '{artifact}' is tracked by git."
        for artifact in tracked
    ]
    for warning in warnings:
        issues.append(
            EnvironmentIssue(
                code="git_footprint",
                severity="warning",
                message=warning,
                fixable=True,
            )
        )
    return GitFootprintStatus(
        status="ok" if not tracked else "warning",
        trackedArtifacts=tracked,
        warnings=warnings,
    )


def _tracked_generated_artifacts(root: Path) -> list[str]:
    tracked: list[str] = []
    for artifact in GENERATED_ARTIFACTS:
        try:
            result = subprocess.run(
                ["git", "-C", str(root), "ls-files", "--error-unmatch", artifact],
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError:
            continue
        if result.returncode == 0:
            tracked.append(artifact)
    return tracked


def _probe_provider(provider: str) -> str:
    url = DEFAULT_PROVIDER_URLS.get(provider)
    if not url:
        return "unknown"
    request = Request(url, method="HEAD")
    try:
        with urlopen(request, timeout=2):
            return "ok"
    except (URLError, OSError):
        return "unreachable"


def _ensure_gitignore_entry(root: Path, artifact: str) -> None:
    gitignore_path = root / ".gitignore"
    existing = gitignore_path.read_text(encoding="utf-8") if gitignore_path.exists() else ""
    lines = [line.strip() for line in existing.splitlines()]
    if artifact in lines:
        return
    prefix = "" if not existing or existing.endswith("\n") else "\n"
    gitignore_path.write_text(f"{existing}{prefix}{artifact}\n", encoding="utf-8")


def _apply_action(action: RepairAction, *, dry_run: bool, callback) -> RepairAction:
    if not dry_run:
        callback()
    return RepairAction(
        code=action.code,
        description=action.description,
        path=action.path,
        applied=not dry_run,
    )


def _default_config_text() -> str:
    return (
        "# yaml-language-server: $schema=./schema/logics.yaml.schema.json\n"
        "version: 2\n"
        "skills:\n"
        "  - flow-manager\n"
        "hybrid:\n"
        "  enabled: false\n"
        "  providers: []\n"
    )


def _read_repo_version(root: Path) -> str:
    version_file = root / "VERSION"
    if version_file.exists():
        return version_file.read_text(encoding="utf-8").strip()
    return "0.0.0"
