from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from core.config import LogicsConfig


@dataclass(frozen=True)
class SkillStatus:
    name: str
    status: str
    version: str | None = None
    message: str | None = None
    path: str | None = None


def resolve_skills(
    config: LogicsConfig,
    *,
    skills_root: str | Path | None = None,
    version: str | None = None,
) -> list[SkillStatus]:
    root = Path(skills_root) if skills_root is not None else config.project_root / "skills"
    bundled = _discover_bundled_skills(root)
    declared = set(config.skills)
    statuses = [
        SkillStatus(
            name="flow-manager",
            status="ok",
            version=version,
            path=str(_resolve_skill_path(root, "flow-manager")) if root.exists() else None,
            message="Core workflow engine is always available.",
        )
    ]

    for skill_name in sorted(declared - {"flow-manager"}):
        skill_path = _resolve_skill_path(root, skill_name)
        if skill_name in bundled:
            statuses.append(
                SkillStatus(
                    name=skill_name,
                    status="ok",
                    version=version,
                    path=str(skill_path),
                )
            )
        else:
            statuses.append(
                SkillStatus(
                    name=skill_name,
                    status="missing",
                    version=version,
                    path=str(skill_path),
                    message=f"Declared skill '{skill_name}' is not present in bundled skills.",
                )
            )

    for skill_name in sorted(bundled - declared - {"flow-manager"}):
        statuses.append(
            SkillStatus(
                name=skill_name,
                status="disabled",
                version=version,
                path=str(_resolve_skill_path(root, skill_name)),
            )
        )

    return statuses


def _discover_bundled_skills(skills_root: Path) -> set[str]:
    if not skills_root.exists():
        return set()
    bundled: set[str] = set()
    for entry in skills_root.iterdir():
        if not entry.is_dir():
            continue
        if (entry / "SKILL.md").exists():
            name = entry.name
            if name.startswith("logics-"):
                name = name[len("logics-") :]
            bundled.add(name)
    bundled.add("flow-manager")
    return bundled


def _resolve_skill_path(skills_root: Path, skill_name: str) -> Path:
    direct = skills_root / skill_name
    if (direct / "SKILL.md").exists():
        return direct
    prefixed = skills_root / f"logics-{skill_name}"
    return prefixed

