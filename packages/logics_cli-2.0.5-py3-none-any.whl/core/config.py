from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml
from yaml.nodes import MappingNode, Node, ScalarNode, SequenceNode

DEFAULT_CONFIG_FILENAME = "logics.yaml"


@dataclass(frozen=True)
class HybridConfig:
    enabled: bool = False
    providers: tuple[str, ...] = ()


@dataclass(frozen=True)
class PathsConfig:
    backlog: Path
    tasks: Path
    request: Path
    specs: Path


@dataclass(frozen=True)
class LogicsConfig:
    version: int
    skills: tuple[str, ...]
    hybrid: HybridConfig
    paths: PathsConfig
    kit: str | None
    initialized: bool
    project_root: Path
    warnings: tuple[str, ...] = field(default_factory=tuple)


class ConfigValidationError(ValueError):
    def __init__(self, message: str, key_path: str, line: int | None = None):
        self.key_path = key_path
        self.line = line
        suffix = f" (line {line})" if line is not None else ""
        super().__init__(f"{message} at '{key_path}'{suffix}")


def load_config(path: str | Path | None = None) -> LogicsConfig:
    if path is None:
        project_root = Path.cwd()
        return _default_config(project_root=project_root, initialized=False)

    config_path = Path(path)
    project_root = config_path.parent.resolve()
    if not config_path.exists():
        return _default_config(project_root=project_root, initialized=False)

    return parse_config_text(
        config_path.read_text(encoding="utf-8"),
        project_root=project_root,
        source_path=config_path,
    )


def parse_config_text(
    content: str,
    *,
    project_root: str | Path,
    source_path: str | Path | None = None,
) -> LogicsConfig:
    project_root = Path(project_root).resolve()
    try:
        raw = yaml.safe_load(content) or {}
    except yaml.YAMLError as exc:
        line = getattr(getattr(exc, "problem_mark", None), "line", None)
        raise ConfigValidationError(
            "Invalid YAML syntax",
            key_path="$",
            line=None if line is None else line + 1,
        ) from exc

    if not isinstance(raw, dict):
        raise ConfigValidationError("Config root must be an object", key_path="$", line=1)

    schema = _load_schema()
    line_map = _build_line_map(content)
    warnings = _collect_top_level_warnings(raw, schema)
    normalized = _normalize_with_schema(raw, schema, line_map)
    return _to_config(
        normalized,
        project_root=project_root,
        initialized=True,
        warnings=warnings,
    )


def _default_config(*, project_root: Path, initialized: bool) -> LogicsConfig:
    schema = _load_schema()
    defaults = {
        key: _copy_default(field_schema.get("default"))
        for key, field_schema in schema["properties"].items()
    }
    return _to_config(defaults, project_root=project_root, initialized=initialized, warnings=())


def _to_config(
    normalized: dict[str, Any],
    *,
    project_root: Path,
    initialized: bool,
    warnings: tuple[str, ...],
) -> LogicsConfig:
    paths = normalized["paths"]
    return LogicsConfig(
        version=normalized["version"],
        skills=tuple(normalized["skills"]),
        hybrid=HybridConfig(
            enabled=normalized["hybrid"]["enabled"],
            providers=tuple(normalized["hybrid"]["providers"]),
        ),
        paths=PathsConfig(
            backlog=_resolve_project_path(project_root, paths["backlog"]),
            tasks=_resolve_project_path(project_root, paths["tasks"]),
            request=_resolve_project_path(project_root, paths["request"]),
            specs=_resolve_project_path(project_root, paths["specs"]),
        ),
        kit=normalized["kit"] or None,
        initialized=initialized,
        project_root=project_root,
        warnings=warnings,
    )


def _resolve_project_path(project_root: Path, value: str) -> Path:
    candidate = Path(value)
    if candidate.is_absolute():
        return candidate
    return (project_root / candidate).resolve()


def _load_schema() -> dict[str, Any]:
    schema_path = Path(__file__).resolve().parent.parent / "schema" / "logics.yaml.schema.json"
    return json.loads(schema_path.read_text(encoding="utf-8"))


def _collect_top_level_warnings(raw: dict[str, Any], schema: dict[str, Any]) -> tuple[str, ...]:
    allowed = set(schema["properties"])
    warnings = []
    for key in raw:
        if key not in allowed:
            warnings.append(f"Unknown top-level key '{key}' ignored for forward compatibility.")
    return tuple(warnings)


def _normalize_with_schema(
    raw: dict[str, Any],
    schema: dict[str, Any],
    line_map: dict[str, int],
) -> dict[str, Any]:
    allowed = schema["properties"]
    normalized: dict[str, Any] = {}
    for key, field_schema in allowed.items():
        path = key
        if key in raw:
            normalized[key] = _validate_value(raw[key], field_schema, path, line_map)
        elif key in schema.get("required", []):
            raise ConfigValidationError(
                "Missing required key",
                key_path=path,
                line=line_map.get(path),
            )
        else:
            normalized[key] = _copy_default(field_schema.get("default"))
    return normalized


def _validate_value(value: Any, schema: dict[str, Any], path: str, line_map: dict[str, int]) -> Any:
    expected_type = schema.get("type")
    if expected_type == "integer":
        if isinstance(value, bool) or not isinstance(value, int):
            _raise_type_error(expected_type, path, line_map)
        return value
    if expected_type == "boolean":
        if not isinstance(value, bool):
            _raise_type_error(expected_type, path, line_map)
        return value
    if expected_type == "string":
        if not isinstance(value, str):
            _raise_type_error(expected_type, path, line_map)
        return value
    if expected_type == "array":
        if not isinstance(value, list):
            _raise_type_error(expected_type, path, line_map)
        item_schema = schema.get("items", {})
        return [
            _validate_value(item, item_schema, f"{path}[{index}]", line_map)
            for index, item in enumerate(value)
        ]
    if expected_type == "object":
        if not isinstance(value, dict):
            _raise_type_error(expected_type, path, line_map)
        return _validate_object(value, schema, path, line_map)
    return value


def _validate_object(
    value: dict[str, Any],
    schema: dict[str, Any],
    path: str,
    line_map: dict[str, int],
) -> dict[str, Any]:
    properties = schema.get("properties", {})
    additional_allowed = schema.get("additionalProperties", True)
    normalized: dict[str, Any] = {}
    for key, field_schema in properties.items():
        child_path = f"{path}.{key}"
        if key in value:
            normalized[key] = _validate_value(value[key], field_schema, child_path, line_map)
        else:
            normalized[key] = _copy_default(field_schema.get("default"))
    if not additional_allowed:
        for key in value:
            if key not in properties:
                raise ConfigValidationError(
                    "Unknown key",
                    key_path=f"{path}.{key}",
                    line=line_map.get(f"{path}.{key}"),
                )
    return normalized


def _raise_type_error(expected_type: str, path: str, line_map: dict[str, int]) -> None:
    raise ConfigValidationError(
        f"Expected {expected_type}",
        key_path=path,
        line=line_map.get(path),
    )


def _copy_default(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _copy_default(child) for key, child in value.items()}
    if isinstance(value, list):
        return [_copy_default(child) for child in value]
    return value


def _build_line_map(content: str) -> dict[str, int]:
    try:
        node = yaml.compose(content)
    except yaml.YAMLError:
        return {}
    if node is None:
        return {}
    line_map: dict[str, int] = {}
    _walk_node(node, prefix="", line_map=line_map)
    return line_map


def _walk_node(node: Node, *, prefix: str, line_map: dict[str, int]) -> None:
    if isinstance(node, MappingNode):
        for key_node, value_node in node.value:
            if not isinstance(key_node, ScalarNode):
                continue
            path = f"{prefix}.{key_node.value}" if prefix else str(key_node.value)
            line_map[path] = key_node.start_mark.line + 1
            _walk_node(value_node, prefix=path, line_map=line_map)
    elif isinstance(node, SequenceNode):
        for index, item_node in enumerate(node.value):
            path = f"{prefix}[{index}]"
            line_map[path] = item_node.start_mark.line + 1
            _walk_node(item_node, prefix=path, line_map=line_map)
