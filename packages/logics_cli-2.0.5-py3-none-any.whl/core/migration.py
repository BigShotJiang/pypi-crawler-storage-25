from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import yaml


@dataclass(frozen=True)
class MigrationDetection:
    is_v1: bool
    reasons: list[str] = field(default_factory=list)
    artifacts: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class InferredConfig:
    version: int
    skills: list[str]
    hybrid_enabled: bool
    providers: list[str]


@dataclass(frozen=True)
class MigrationStepResult:
    description: str
    applied: bool = False
    rolled_back: bool = False


@dataclass(frozen=True)
class MigrationReport:
    detected: MigrationDetection
    inferred_config: InferredConfig
    steps: list[MigrationStepResult]
    dry_run: bool
    success: bool
    rolled_back: bool


def detect_v1(project_root: str | Path) -> MigrationDetection:
    root = Path(project_root).resolve()
    reasons: list[str] = []
    artifacts: list[str] = []

    skills_dir = root / "logics" / "skills"
    if skills_dir.exists():
        reasons.append("Found v1 logics/skills directory.")
        artifacts.append(str(skills_dir.relative_to(root)))

    gitmodules = root / ".gitmodules"
    if gitmodules.exists():
        text = gitmodules.read_text(encoding="utf-8")
        if "cdx-logics-kit" in text:
            reasons.append("Found .gitmodules entry referencing cdx-logics-kit.")
            artifacts.append(".gitmodules")

    claude_dir = root / ".claude"
    if claude_dir.exists():
        reasons.append("Found v1 Claude workspace artifacts.")
        artifacts.append(".claude")

    hybrid_audit = root / "hybrid_assist_audit.jsonl"
    if hybrid_audit.exists():
        reasons.append("Found hybrid assist audit log.")
        artifacts.append("hybrid_assist_audit.jsonl")

    legacy_yaml = root / "logics.yaml"
    if legacy_yaml.exists():
        try:
            raw = yaml.safe_load(legacy_yaml.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            raw = {}
        if isinstance(raw, dict) and raw.get("version") == 1:
            reasons.append("Found v1 logics.yaml config.")
            artifacts.append("logics.yaml")

    return MigrationDetection(is_v1=bool(reasons), reasons=reasons, artifacts=sorted(set(artifacts)))


def infer_config(project_root: str | Path) -> InferredConfig:
    root = Path(project_root).resolve()
    skills = ["flow-manager"]
    providers: list[str] = []
    hybrid_enabled = False

    if (root / ".claude").exists():
        skills.append("claude-bridge")

    legacy_yaml = root / "logics.yaml"
    if legacy_yaml.exists():
        try:
            raw = yaml.safe_load(legacy_yaml.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError:
            raw = {}
        if isinstance(raw, dict):
            hybrid = raw.get("hybrid_assist")
            if isinstance(hybrid, dict):
                hybrid_enabled = True
                provider_map = hybrid.get("providers", {})
                if isinstance(provider_map, dict):
                    for name, payload in provider_map.items():
                        if isinstance(payload, dict) and payload.get("enabled") is True:
                            providers.append(name)

    if (root / "hybrid_assist_audit.jsonl").exists():
        hybrid_enabled = True

    return InferredConfig(
        version=2,
        skills=sorted(set(skills)),
        hybrid_enabled=hybrid_enabled,
        providers=sorted(set(providers)),
    )


def build_migration_steps(project_root: str | Path) -> list[str]:
    root = Path(project_root).resolve()
    steps = ["Rewrite logics.yaml from v1 to v2"]

    if (root / ".gitmodules").exists():
        steps.append("Remove legacy cdx-logics-kit .gitmodules entry")

    steps.append("Ensure workflow directories exist with .gitkeep files")
    steps.append("Ensure generated artifacts are ignored in .gitignore")
    return steps


def migrate(project_root: str | Path, *, dry_run: bool = True) -> MigrationReport:
    root = Path(project_root).resolve()
    detection = detect_v1(root)
    inferred = infer_config(root)
    step_labels = build_migration_steps(root)

    if dry_run:
        return MigrationReport(
            detected=detection,
            inferred_config=inferred,
            steps=[MigrationStepResult(description=label, applied=False) for label in step_labels],
            dry_run=True,
            success=True,
            rolled_back=False,
        )

    backup_dir = root / ".logics-migrate-backup"
    applied: list[tuple[MigrationStepResult, Callable[[], None]]] = []
    try:
        _snapshot_files(root, backup_dir, ("logics.yaml", ".gitignore", ".gitmodules"))
        for label in step_labels:
            rollback = _apply_step(root, label, inferred)
            applied.append((MigrationStepResult(description=label, applied=True), rollback))
    except Exception:
        for _, rollback in reversed(applied):
            rollback()
        _restore_snapshot(root, backup_dir, ("logics.yaml", ".gitignore", ".gitmodules"))
        return MigrationReport(
            detected=detection,
            inferred_config=inferred,
            steps=[
                MigrationStepResult(
                    description=result.description,
                    applied=result.applied,
                    rolled_back=result.applied,
                )
                for result, _ in applied
            ],
            dry_run=False,
            success=False,
            rolled_back=True,
        )
    finally:
        if backup_dir.exists():
            shutil.rmtree(backup_dir)

    return MigrationReport(
        detected=detection,
        inferred_config=inferred,
        steps=[result for result, _ in applied],
        dry_run=False,
        success=True,
        rolled_back=False,
    )


def _apply_step(root: Path, label: str, inferred: InferredConfig) -> Callable[[], None]:
    if label == "Rewrite logics.yaml from v1 to v2":
        target = root / "logics.yaml"
        previous = target.read_text(encoding="utf-8") if target.exists() else None
        target.write_text(_render_v2_config(inferred), encoding="utf-8")
        return lambda: _restore_text(target, previous)

    if label == "Remove legacy cdx-logics-kit .gitmodules entry":
        gitmodules = root / ".gitmodules"
        previous = gitmodules.read_text(encoding="utf-8")
        lines = [line for line in previous.splitlines() if "cdx-logics-kit" not in line]
        gitmodules.write_text("\n".join(lines).strip() + ("\n" if lines else ""), encoding="utf-8")
        return lambda: gitmodules.write_text(previous, encoding="utf-8")

    if label == "Ensure workflow directories exist with .gitkeep files":
        created: list[Path] = []
        for name in ("backlog", "tasks", "request", "specs"):
            directory = root / "logics" / name
            if not directory.exists():
                directory.mkdir(parents=True, exist_ok=True)
                created.append(directory)
            gitkeep = directory / ".gitkeep"
            if not gitkeep.exists():
                gitkeep.write_text("", encoding="utf-8")
                created.append(gitkeep)
        return lambda: _cleanup_created(created)

    if label == "Ensure generated artifacts are ignored in .gitignore":
        gitignore = root / ".gitignore"
        previous = gitignore.read_text(encoding="utf-8") if gitignore.exists() else None
        content = previous or ""
        lines = [line.strip() for line in content.splitlines()]
        for entry in ("INDEX.md", "RELATIONSHIPS.md", "hybrid_assist_audit.jsonl"):
            if entry not in lines:
                content += ("" if not content or content.endswith("\n") else "\n") + f"{entry}\n"
                lines.append(entry)
        gitignore.write_text(content, encoding="utf-8")
        return lambda: _restore_text(gitignore, previous)

    raise ValueError(f"Unknown migration step: {label}")


def _render_v2_config(inferred: InferredConfig) -> str:
    payload = {
        "version": inferred.version,
        "skills": inferred.skills,
        "hybrid": {
            "enabled": inferred.hybrid_enabled,
            "providers": inferred.providers,
        },
    }
    return "# yaml-language-server: $schema=./schema/logics.yaml.schema.json\n" + yaml.safe_dump(
        payload,
        sort_keys=False,
    )


def _snapshot_files(root: Path, backup_dir: Path, relative_paths: tuple[str, ...]) -> None:
    backup_dir.mkdir(parents=True, exist_ok=True)
    for relative in relative_paths:
        source = root / relative
        if source.exists():
            target = backup_dir / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def _restore_snapshot(root: Path, backup_dir: Path, relative_paths: tuple[str, ...]) -> None:
    for relative in relative_paths:
        backup = backup_dir / relative
        target = root / relative
        if backup.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup, target)


def _restore_text(target: Path, previous: str | None) -> None:
    if previous is None:
        target.unlink(missing_ok=True)
    else:
        target.write_text(previous, encoding="utf-8")


def _cleanup_created(created: list[Path]) -> None:
    for path in reversed(created):
        if path.is_file():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
