from pathlib import Path

import pytest

from core.config import ConfigValidationError, load_config, parse_config_text


def test_parse_minimal_config_applies_defaults() -> None:
    config = parse_config_text(
        "version: 2\nskills:\n  - flow-manager\n",
        project_root="/repo/project",
    )

    assert config.version == 2
    assert config.skills == ("flow-manager",)
    assert config.hybrid.enabled is False
    assert config.hybrid.providers == ()
    assert config.paths.backlog == Path("/repo/project/logics/backlog")
    assert config.paths.tasks == Path("/repo/project/logics/tasks")
    assert config.kit is None
    assert config.initialized is True


def test_invalid_type_reports_key_path_and_line() -> None:
    with pytest.raises(ConfigValidationError) as excinfo:
        parse_config_text(
            "version: 2\nhybrid:\n  enabled: nope\n",
            project_root="/repo/project",
        )

    error = excinfo.value
    assert error.key_path == "hybrid.enabled"
    assert error.line == 3
    assert "Expected boolean" in str(error)


def test_unknown_top_level_key_is_warning_not_error() -> None:
    config = parse_config_text(
        "version: 2\nunknown: true\n",
        project_root="/repo/project",
    )

    assert config.version == 2
    assert config.warnings == ("Unknown top-level key 'unknown' ignored for forward compatibility.",)


def test_missing_config_returns_uninitialized_defaults(tmp_path: Path) -> None:
    config = load_config(tmp_path / "logics.yaml")

    assert config.initialized is False
    assert config.version == 2
    assert config.paths.backlog == (tmp_path / "logics/backlog").resolve()


def test_paths_resolve_relative_to_project_root() -> None:
    config = parse_config_text(
        "version: 2\npaths:\n  backlog: workflow/backlog\n",
        project_root="/repo/project",
    )

    assert config.paths.backlog == Path("/repo/project/workflow/backlog")
    assert config.paths.tasks == Path("/repo/project/logics/tasks")

