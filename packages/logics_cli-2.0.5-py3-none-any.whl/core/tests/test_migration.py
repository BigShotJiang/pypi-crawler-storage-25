import json
from dataclasses import asdict
from pathlib import Path

from core.migration import detect_v1, infer_config, migrate


def test_detect_v1_finds_legacy_markers(tmp_path: Path) -> None:
    (tmp_path / "logics" / "skills").mkdir(parents=True)
    (tmp_path / ".gitmodules").write_text('[submodule "kit"]\n\turl = git@github.com:AlexAgo83/cdx-logics-kit.git\n', encoding="utf-8")

    detection = detect_v1(tmp_path)

    assert detection.is_v1 is True
    assert detection.artifacts


def test_infer_config_reads_v1_features(tmp_path: Path) -> None:
    (tmp_path / ".claude").mkdir()
    (tmp_path / "hybrid_assist_audit.jsonl").write_text("", encoding="utf-8")
    (tmp_path / "logics.yaml").write_text(
        "version: 1\nhybrid_assist:\n  providers:\n    openai:\n      enabled: true\n",
        encoding="utf-8",
    )

    inferred = infer_config(tmp_path)

    assert "claude-bridge" in inferred.skills
    assert inferred.hybrid_enabled is True
    assert inferred.providers == ["openai"]


def test_migrate_dry_run_does_not_modify_files(tmp_path: Path) -> None:
    original = "version: 1\n"
    target = tmp_path / "logics.yaml"
    target.write_text(original, encoding="utf-8")

    report = migrate(tmp_path, dry_run=True)

    assert report.success is True
    assert target.read_text(encoding="utf-8") == original


def test_migrate_apply_rolls_back_on_failure(tmp_path: Path, monkeypatch) -> None:
    target = tmp_path / "logics.yaml"
    target.write_text("version: 1\n", encoding="utf-8")

    from core import migration as migration_module

    original_apply_step = migration_module._apply_step

    def failing_apply_step(root, label, inferred):
        if label == "Ensure workflow directories exist with .gitkeep files":
            raise RuntimeError("boom")
        return original_apply_step(root, label, inferred)

    monkeypatch.setattr(migration_module, "_apply_step", failing_apply_step)
    report = migrate(tmp_path, dry_run=False)

    assert report.success is False
    assert report.rolled_back is True
    assert target.read_text(encoding="utf-8") == "version: 1\n"


def test_migration_report_is_json_serializable(tmp_path: Path) -> None:
    (tmp_path / "logics.yaml").write_text("version: 1\n", encoding="utf-8")
    report = migrate(tmp_path, dry_run=True)
    json.dumps(asdict(report))
