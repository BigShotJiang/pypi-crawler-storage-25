from datetime import datetime, timezone
from pathlib import Path

import pytest

from core.flow_manager.backlog import BacklogItem, _normalize_status, _parse_blockquote_indicators, read_backlog, read_item, write_item
from core.flow_manager.queries import filter_items, next_item, sort_items
from core.flow_manager.transitions import InvalidTransitionError, apply_transition, validate_transition


def test_invalid_transition_raises_typed_error() -> None:
    with pytest.raises(InvalidTransitionError):
        validate_transition("open", "done")


def test_apply_transition_updates_status() -> None:
    item = BacklogItem(item_id="item_1", title="Test", status="open")

    moved = apply_transition(item, "in-progress")

    assert moved.status == "in-progress"


def test_read_backlog_is_idempotent(tmp_path: Path) -> None:
    item = BacklogItem(
        item_id="item_001",
        title="First item",
        status="open",
        priority=1,
        created_at=datetime(2026, 4, 18, tzinfo=timezone.utc),
        body="# First item\n\nBody\n",
    )
    write_item(item, tmp_path / "item_001.md")

    first = read_backlog(tmp_path)
    second = read_backlog(tmp_path)

    assert first == second


def test_next_item_prefers_highest_priority_then_oldest_actionable() -> None:
    items = [
        BacklogItem(
            item_id="item_002",
            title="Later high priority",
            status="open",
            priority=1,
            created_at=datetime(2026, 4, 19, tzinfo=timezone.utc),
        ),
        BacklogItem(
            item_id="item_001",
            title="Older high priority",
            status="open",
            priority=1,
            created_at=datetime(2026, 4, 18, tzinfo=timezone.utc),
        ),
        BacklogItem(
            item_id="item_003",
            title="Done item",
            status="done",
            priority=0,
            created_at=datetime(2026, 4, 17, tzinfo=timezone.utc),
        ),
    ]

    selected = next_item(items)

    assert selected is not None
    assert selected.item_id == "item_001"


def test_read_item_blockquote_format(tmp_path: Path) -> None:
    content = (
        "## item_350_remove_obsolete_typescript_files - Remove obsolete TypeScript files\n"
        "> From version: 2.0.0\n"
        "> Status: Done\n"
        "> Understanding: 92%\n"
        "> Progress: 100%\n"
        "\n"
        "# Body\n"
        "Some content.\n"
    )
    p = tmp_path / "item_350_remove_obsolete_typescript_files.md"
    p.write_text(content, encoding="utf-8")

    item = read_item(p)

    assert item.item_id == "item_350_remove_obsolete_typescript_files"
    assert item.title == "Remove obsolete TypeScript files"
    assert item.status == "done"


def test_normalize_status_mapping() -> None:
    assert _normalize_status("Done") == "done"
    assert _normalize_status("Archived") == "done"
    assert _normalize_status("In progress") == "in-progress"
    assert _normalize_status("In Progress") == "in-progress"
    assert _normalize_status("Draft") == "open"
    assert _normalize_status("Ready") == "open"
    assert _normalize_status("Blocked") == "blocked"
    assert _normalize_status("") == "open"


def test_parse_blockquote_indicators() -> None:
    content = "> Status: In progress\n> Understanding: 80%\n> Complexity: High\n"
    result = _parse_blockquote_indicators(content)
    assert result["status"] == "in-progress"
    assert result["understanding"] == "80%"
    assert result["complexity"] == "High"


def test_read_backlog_blockquote_items_are_not_all_open(tmp_path: Path) -> None:
    done_content = (
        "## item_001_done - Done item\n"
        "> Status: Done\n"
        "> Progress: 100%\n"
    )
    open_content = (
        "## item_002_open - Open item\n"
        "> Status: Ready\n"
        "> Progress: 0%\n"
    )
    (tmp_path / "item_001_done.md").write_text(done_content, encoding="utf-8")
    (tmp_path / "item_002_open.md").write_text(open_content, encoding="utf-8")

    items = read_backlog(tmp_path)
    by_id = {i.item_id: i for i in items}

    assert by_id["item_001_done"].status == "done"
    assert by_id["item_002_open"].status == "open"


def test_filter_and_sort_items() -> None:
    items = [
        BacklogItem(
            item_id="b",
            title="Review",
            status="review",
            priority=2,
            created_at=datetime(2026, 4, 19, tzinfo=timezone.utc),
        ),
        BacklogItem(
            item_id="a",
            title="Open",
            status="open",
            priority=1,
            created_at=datetime(2026, 4, 20, tzinfo=timezone.utc),
        ),
    ]

    filtered = filter_items(items, status="open")
    ordered = sort_items(items)

    assert [item.item_id for item in filtered] == ["a"]
    assert [item.item_id for item in ordered] == ["a", "b"]
