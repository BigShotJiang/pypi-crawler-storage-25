import json
import subprocess
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

import pytest

from core.environment import check, repair


def test_environment_report_matches_contract_shape(tmp_path: Path) -> None:
    (tmp_path / "VERSION").write_text("2.0.0\n", encoding="utf-8")
    (tmp_path / "logics.yaml").write_text("version: 2\nskills:\n  - flow-manager\n", encoding="utf-8")
    for name in ("backlog", "tasks", "request", "specs"):
        (tmp_path / "logics" / name).mkdir(parents=True, exist_ok=True)

    report = check(project_root=tmp_path)
    payload = asdict(report)

    assert payload["version"] == "2.0.0"
    assert payload["cli"]["status"] == "ok"
    assert payload["project"]["configFound"] is True
    assert "skills" in payload
    assert "gitFootprint" in payload
    json.dumps(payload)


def test_checks_are_independent_when_config_missing(tmp_path: Path) -> None:
    (tmp_path / "VERSION").write_text("2.0.0\n", encoding="utf-8")
    report = check(project_root=tmp_path)

    assert report.project.configFound is False
    assert report.gitFootprint.status in {"ok", "warning"}
    assert any(issue.code == "config_missing" for issue in report.issues)


def test_hybrid_disabled_makes_no_network_call(tmp_path: Path) -> None:
    (tmp_path / "VERSION").write_text("2.0.0\n", encoding="utf-8")
    (tmp_path / "logics.yaml").write_text(
        "version: 2\nhybrid:\n  enabled: false\n  providers:\n    - openai\n",
        encoding="utf-8",
    )
    with patch("core.environment.urlopen") as mocked_urlopen:
        report = check(project_root=tmp_path)

    mocked_urlopen.assert_not_called()
    assert report.hybrid.providerStatuses == []


def test_hybrid_unreachable_provider_is_reported(tmp_path: Path) -> None:
    (tmp_path / "VERSION").write_text("2.0.0\n", encoding="utf-8")
    (tmp_path / "logics.yaml").write_text(
        "version: 2\nhybrid:\n  enabled: true\n  providers:\n    - openai\n",
        encoding="utf-8",
    )
    with patch("core.environment.urlopen", side_effect=OSError("offline")):
        report = check(project_root=tmp_path)

    assert report.hybrid.providerStatuses == [{"name": "openai", "status": "unreachable"}]
    assert any(issue.code == "hybrid_provider_unreachable" for issue in report.issues)


def test_repair_dry_run_lists_actions_without_modifying(tmp_path: Path) -> None:
    actions = repair(project_root=tmp_path, dry_run=True)

    assert actions
    assert all(action.applied is False for action in actions)
    assert not (tmp_path / "logics.yaml").exists()


@pytest.mark.integration
def test_repair_apply_creates_config_and_dirs(tmp_path: Path) -> None:
    actions = repair(project_root=tmp_path, dry_run=False)

    assert any(action.applied for action in actions)
    assert (tmp_path / "logics.yaml").exists()
    assert (tmp_path / "logics" / "backlog").exists()


@pytest.mark.integration
def test_git_footprint_warns_for_tracked_generated_artifacts(tmp_path: Path) -> None:
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=tmp_path, check=True)
    (tmp_path / "VERSION").write_text("2.0.0\n", encoding="utf-8")
    (tmp_path / "logics.yaml").write_text("version: 2\n", encoding="utf-8")
    (tmp_path / "INDEX.md").write_text("generated\n", encoding="utf-8")
    subprocess.run(["git", "add", "INDEX.md"], cwd=tmp_path, check=True)

    report = check(project_root=tmp_path)

    assert report.gitFootprint.status == "warning"
    assert "INDEX.md" in report.gitFootprint.trackedArtifacts
