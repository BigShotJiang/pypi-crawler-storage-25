from pathlib import Path

from core.config import parse_config_text
from core.skills import resolve_skills


def test_declared_missing_skill_returns_missing(tmp_path: Path) -> None:
    skills_root = tmp_path / "skills"
    skills_root.mkdir()

    config = parse_config_text(
        "version: 2\nskills:\n  - unknown-skill\n",
        project_root=tmp_path,
    )

    resolved = resolve_skills(config, skills_root=skills_root, version="2.0.0")
    missing = next(skill for skill in resolved if skill.name == "unknown-skill")
    assert missing.status == "missing"


def test_undeclared_skill_returns_disabled(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "logics-extra-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# extra\n", encoding="utf-8")

    config = parse_config_text("version: 2\n", project_root=tmp_path)
    resolved = resolve_skills(config, skills_root=tmp_path / "skills", version="2.0.0")

    disabled = next(skill for skill in resolved if skill.name == "extra-skill")
    assert disabled.status == "disabled"


def test_flow_manager_is_always_ok(tmp_path: Path) -> None:
    config = parse_config_text("version: 2\nskills: []\n", project_root=tmp_path)
    resolved = resolve_skills(config, skills_root=tmp_path / "skills", version="2.0.0")

    flow_manager = next(skill for skill in resolved if skill.name == "flow-manager")
    assert flow_manager.status == "ok"

