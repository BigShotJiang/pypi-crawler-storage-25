# Changelog (`2.0.0 -> 2.0.1`)

## Major Highlights

- `logics flow list` and `logics flow next` now correctly read the status of all Logics markdown files — previously every item was returned as `open` regardless of its actual status.

## Bug Fix — Backlog Status Parsing

- The core backlog parser (`core/flow_manager/backlog.py`) only handled YAML frontmatter (`---`) but all Logics files use the `> Key: Value` blockquote indicator format. This caused `flow list --json` to report all 354 items as `open`.
- Added `_parse_blockquote_indicators` to extract key/value pairs from blockquote lines.
- Added `_normalize_status` to map Logics status labels (`Done`, `In progress`, `Draft`, `Ready`, `Blocked`, `Archived`) to CLI status tokens (`done`, `in-progress`, `open`, `blocked`).
- `_extract_title` now also handles the `## item_NNN - Title` heading format used in Logics files.
- With the fix applied, `flow list` on the `logics-manager` backlog correctly returns 348 `done` and 6 `open` items.

## Phase 5 Validation (task_148)

- Smoke test confirmed: the VSCode plugin delegates all commands to the CLI via `execFile` — results are identical by design.
- `logics migrate` dry-run validated on `cdx-logics-vscode` (real v1 project): all steps reported as `DRY-RUN`, git status unchanged after execution.
- `logics flow list --json` confirmed clean on 354 items after blockquote fix.

## Tests

- Added 4 new tests in `core/tests/test_flow_manager.py`:
  - `test_read_item_blockquote_format` — parses a real-format file and asserts correct title and status
  - `test_normalize_status_mapping` — covers all Logics status labels
  - `test_parse_blockquote_indicators` — validates key extraction and status normalization
  - `test_read_backlog_blockquote_items_are_not_all_open` — end-to-end read from files with mixed statuses
- Full suite: 332 passed, 13 skipped.

## Validation

- `python3 -m pytest --tb=short -q` — 332 passed, 13 skipped
- `logics flow list --json | python3 -m json.tool` — valid JSON, 354 items
- `logics flow next --json` — returns correct open item
- `cd vscode && npm run compile` — TypeScript compilation clean
