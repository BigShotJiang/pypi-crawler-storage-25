# Changelog (`1.x -> 2.0.0`)

## Major Highlights

- **New monorepo** — `logics-manager` replaces `cdx-logics-vscode` + `cdx-logics-kit` as the single source of truth for the Logics v2 stack.
- **Python-first CLI** — all business logic moves to a Python core (`core/`) shared by the CLI and the VSCode plugin. The plugin becomes a thin client with zero TypeScript business logic.
- **Terminal-only usage** — `logics flow`, `logics env`, `logics skills`, `logics migrate` work fully without VSCode.
- **Near-zero client footprint** — client projects only need `logics.yaml`; no git submodule, no kit folder.

## New: Python Core (`core/`)

- `core/config.py` — `LogicsConfig` typed object, defaults, schema validation, `ConfigValidationError` (`item_342`)
- `core/flow_manager/` — state machine, backlog read/write, transitions, queries, `next()` logic (`item_341`)
- `core/environment.py` — `EnvironmentReport`, git footprint check, repair logic, JSON-serializable (`item_343`)
- `core/skills.py` — skill resolution from declared names to bundled implementations, skill status in `EnvironmentReport` (`item_344`)
- `core/migration.py` — v1 → v2 migration with per-step rollback and structured report (`item_352`)
- `schema/logics.yaml.schema.json` — JSON Schema for `logics.yaml` with editor autocomplete support (`item_354`)

## New: Python CLI (`logics`)

- `logics flow list [--json]` — list backlog items with status and priority
- `logics flow next [--json]` — return the highest-priority actionable item
- `logics flow push <item_id>` — advance an item through the state machine
- `logics flow open <item_id>` — open item file in `$EDITOR`
- `logics flow new --title ... --description ...` — create a new backlog item
- `logics env check [--json]` — full environment report (CLI, project, skills, hybrid, git footprint)
- `logics skills list / add / remove` — manage declared skills
- `logics init` — silent init with defaults
- `logics migrate [--apply]` — detect v1 project and migrate to v2 with rollback support
- `logics repair [--apply]` — detect and fix broken project structure
- `logics update [--check]` — check for CLI updates
- Opt-in skill and hybrid activation gate — undeclared skills ignored, `hybrid.enabled: false` blocks all AI calls (`item_353`)

## New: VSCode Plugin Refactor

- `CliRunner.ts` — all plugin commands call the Python CLI via `child_process.execFile`; no TypeScript file probing or business logic (`item_348`)
- Adaptive UI via VSCode context keys — `setContext` on startup, `when` clauses in `package.json`, `logics.yaml` file watcher, status bar (`item_349`)
- Bootstrap and onboarding flow v2 — CLI detection → auto-install prompt → init prompt → workflow view (`item_351`)
- Removed `logicsGlobalKitLifecycle.ts`, Codex overlay files, Claude bridge files, `pythonRuntime.ts` (`item_350`)

## Monorepo & CI

- Single repo (`logics-manager`) with layout: `core/`, `cli/`, `vscode/`, `skills/`, `schema/` (`item_339`)
- CI pipeline on tag `v*.*.*`: pip publish (wheel-only build) + VSCode `.vsix` build uploaded as release asset
- `pip install logics-cli` installs the full CLI with all core modules
- Deprecation headers added to `cdx-logics-vscode` and `cdx-logics-kit` pointing to `logics-manager` (`item_340`)

## Migration from v1

- `logics migrate` detects legacy `logics.yaml` (version 1), git submodule references, and missing workflow directories
- Dry-run by default — `--apply` required to write changes
- Per-step rollback: any failure reverts all completed steps

## Tests

- 328 tests across core modules (config, flow manager, environment, skills, migration)
- Gate validations: `python -m build --wheel` (wheel-only), `logics flow list --json | jq .`, `logics migrate` dry-run on v1 project

## Validation

- `pip install logics-cli` on macOS — editable + wheel build pass, all tests green
- `logics flow list --json` — 354 items, valid JSON, piping clean
- TypeScript compilation clean — `vsce package` ready
- CI pipeline green on tag push
