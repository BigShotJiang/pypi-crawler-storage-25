from __future__ import annotations

import argparse
import datetime as dt
from importlib import metadata
import json
import shutil
import sys
from dataclasses import asdict
import os
from pathlib import Path
import subprocess
import tempfile

import yaml

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from core.config import load_config
from core.environment import check, repair
from core.flow_manager.backlog import BacklogItem, read_backlog, read_item, write_item
from core.flow_manager.queries import next_item, sort_items
from core.flow_manager.transitions import InvalidTransitionError, apply_transition
from core.migration import migrate
from core.skills import resolve_skills


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "env" and args.env_command == "check":
        return _run_env_check(args)
    if args.command == "skills":
        return _run_skills(args)
    if args.command == "init":
        return _run_init(args)
    if args.command == "repair":
        return _run_repair(args)
    if args.command == "migrate":
        return _run_migrate(args)
    if args.command == "update":
        return _run_update(args)
    if args.command == "flow":
        return _run_flow(args)

    parser.print_help(sys.stderr)
    return 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="logics")
    subparsers = parser.add_subparsers(dest="command")

    env = subparsers.add_parser("env")
    env_subparsers = env.add_subparsers(dest="env_command")
    env_check = env_subparsers.add_parser("check")
    env_check.add_argument("--json", action="store_true", dest="as_json")
    env_check.add_argument("--project-root", default=".")

    skills = subparsers.add_parser("skills")
    skills_subparsers = skills.add_subparsers(dest="skills_command")

    skills_list = skills_subparsers.add_parser("list")
    skills_list.add_argument("--project-root", default=".")

    skills_add = skills_subparsers.add_parser("add")
    skills_add.add_argument("name")
    skills_add.add_argument("--project-root", default=".")

    skills_remove = skills_subparsers.add_parser("remove")
    skills_remove.add_argument("name")
    skills_remove.add_argument("--project-root", default=".")

    init = subparsers.add_parser("init")
    init.add_argument("--project-root", default=".")

    repair_parser = subparsers.add_parser("repair")
    repair_parser.add_argument("--project-root", default=".")
    repair_parser.add_argument("--apply", action="store_true")

    migrate = subparsers.add_parser("migrate")
    migrate.add_argument("--project-root", default=".")
    migrate.add_argument("--apply", action="store_true")

    update = subparsers.add_parser("update")
    update.add_argument("--check", action="store_true")
    update.add_argument("--version")

    flow = subparsers.add_parser("flow")
    flow_subparsers = flow.add_subparsers(dest="flow_command")

    flow_list = flow_subparsers.add_parser("list")
    flow_list.add_argument("--project-root", default=".")
    flow_list.add_argument("--json", action="store_true", dest="as_json")

    flow_status = flow_subparsers.add_parser("status")
    flow_status.add_argument("item_id")
    flow_status.add_argument("--project-root", default=".")
    flow_status.add_argument("--json", action="store_true", dest="as_json")

    flow_next = flow_subparsers.add_parser("next")
    flow_next.add_argument("--project-root", default=".")
    flow_next.add_argument("--json", action="store_true", dest="as_json")

    flow_push = flow_subparsers.add_parser("push")
    flow_push.add_argument("item_id")
    flow_push.add_argument("--project-root", default=".")
    flow_push.add_argument("--json", action="store_true", dest="as_json")

    flow_open = flow_subparsers.add_parser("open")
    flow_open.add_argument("item_id")
    flow_open.add_argument("--project-root", default=".")
    flow_open.add_argument("--json", action="store_true", dest="as_json")

    flow_new = flow_subparsers.add_parser("new")
    flow_new.add_argument("--project-root", default=".")
    flow_new.add_argument("--title")
    flow_new.add_argument("--description")
    flow_new.add_argument("--priority", type=int, default=3)
    flow_new.add_argument("--json", action="store_true", dest="as_json")
    return parser


def _run_env_check(args: argparse.Namespace) -> int:
    report = check(project_root=args.project_root, cli_version=_read_current_version())
    if args.as_json:
        print(json.dumps(asdict(report), indent=2))
    else:
        _print_human_report(report)
    return 0 if not report.issues else 1


def _run_skills(args: argparse.Namespace) -> int:
    project_root = Path(args.project_root).resolve()
    config_path = project_root / "logics.yaml"
    config = load_config(config_path)

    if args.skills_command == "list":
        statuses = resolve_skills(config, skills_root=project_root / "skills", version=None)
        for status in statuses:
            print(f"{status.name}\t{status.status}")
        return 0

    if args.skills_command == "add":
        return _add_skill(config_path, args.name, project_root)

    if args.skills_command == "remove":
        return _remove_skill(config_path, args.name, project_root)

    print("Unknown skills command.", file=sys.stderr)
    return 1


def _run_init(args: argparse.Namespace) -> int:
    project_root = Path(args.project_root).resolve()
    config_path = project_root / "logics.yaml"
    if config_path.exists():
        print("logics.yaml already exists.", file=sys.stderr)
        return 1
    _write_config(config_path, 2, ["flow-manager"], False, [])
    created_dirs = []
    for name in ("backlog", "tasks", "request", "specs"):
        directory = project_root / "logics" / name
        directory.mkdir(parents=True, exist_ok=True)
        (directory / ".gitkeep").write_text("", encoding="utf-8")
        created_dirs.append(directory)
    for artifact in ("INDEX.md", "RELATIONSHIPS.md", "hybrid_assist_audit.jsonl"):
        _append_gitignore_entry(project_root / ".gitignore", artifact)
    print(f"Initialized Logics project in {project_root}")
    return 0


def _run_repair(args: argparse.Namespace) -> int:
    actions = repair(project_root=args.project_root, dry_run=not args.apply)
    for action in actions:
        mode = "APPLY" if action.applied else "DRY-RUN"
        target = f" -> {action.path}" if action.path else ""
        print(f"{mode}: {action.description}{target}")
    return 0


def _run_migrate(args: argparse.Namespace) -> int:
    report = migrate(args.project_root, dry_run=not args.apply)
    for step in report.steps:
        mode = "APPLY" if step.applied else "DRY-RUN"
        suffix = " (rolled back)" if step.rolled_back else ""
        print(f"{mode}: {step.description}{suffix}")
    return 0 if report.success else 1


def _run_update(args: argparse.Namespace) -> int:
    current = _read_current_version()
    target = args.version or current
    if args.check:
        print(json.dumps({"current": current, "available": target, "updateAvailable": target != current}))
        return 0
    response = input(f"Update logics-cli from {current} to {target}? [y/N] ").strip().lower()
    if response not in {"y", "yes"}:
        print("Update cancelled.")
        return 0
    command = [sys.executable, "-m", "pip", "install", "--upgrade", "logics-cli"]
    if args.version:
        command[-1] = f"logics-cli=={args.version}"
    result = subprocess.run(command, check=False)
    return result.returncode


def _run_flow(args: argparse.Namespace) -> int:
    config = load_config(Path(args.project_root).resolve() / "logics.yaml")
    backlog_dir = config.paths.backlog
    if args.flow_command == "list":
        items = sort_items(read_backlog(backlog_dir)) if backlog_dir.exists() else []
        if not items:
            return 2
        if args.as_json:
            print(json.dumps({"items": [_item_to_json(item) for item in items]}, indent=2))
        else:
            for item in items:
                print(_format_item_line(item))
        return 0

    if args.flow_command == "status":
        item = _find_item(backlog_dir, args.item_id)
        if item is None:
            return 2
        if args.as_json:
            print(json.dumps(_item_to_json(item), indent=2))
        else:
            print(_format_item_line(item))
        return 0

    if args.flow_command == "next":
        items = read_backlog(backlog_dir) if backlog_dir.exists() else []
        item = next_item(items)
        if item is None:
            return 2
        if args.as_json:
            print(json.dumps(_item_to_json(item), indent=2))
        else:
            print(_format_item_line(item))
        return 0

    if args.flow_command == "push":
        item = _find_item(backlog_dir, args.item_id)
        if item is None:
            return 2
        next_status = {
            "open": "in-progress",
            "in-progress": "review",
            "review": "done",
            "done": "done",
        }.get(item.status, "done")
        try:
            moved = apply_transition(item, next_status)
        except InvalidTransitionError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        write_item(moved, item.path)
        if args.as_json:
            print(json.dumps(_item_to_json(moved), indent=2))
        else:
            print(f"{moved.item_id} -> {moved.status}")
        return 0

    if args.flow_command == "open":
        item = _find_item(backlog_dir, args.item_id)
        if item is None:
            return 2
        if args.as_json:
            print(json.dumps(_item_to_json(item), indent=2))
        else:
            print(item.path)
        return 0

    if args.flow_command == "new":
        return _run_flow_new(args, backlog_dir)

    print("Unknown flow command.", file=sys.stderr)
    return 1


def _add_skill(config_path: Path, name: str, project_root: Path) -> int:
    config = load_config(config_path)
    available = {
        status.name
        for status in resolve_skills(config, skills_root=project_root / "skills", version=None)
        if status.status != "missing"
    }
    if name not in available:
        print(
            f"Unknown skill '{name}'. Available skills: {', '.join(sorted(available))}",
            file=sys.stderr,
        )
        return 1
    skills = list(dict.fromkeys((*config.skills, name)))
    _write_config(config_path, config.version, skills, config.hybrid.enabled, list(config.hybrid.providers))
    return 0


def _remove_skill(config_path: Path, name: str, project_root: Path) -> int:
    del project_root
    if name == "flow-manager":
        print("flow-manager cannot be removed.", file=sys.stderr)
        return 1
    config = load_config(config_path)
    skills = [skill for skill in config.skills if skill != name]
    _write_config(config_path, config.version, skills, config.hybrid.enabled, list(config.hybrid.providers))
    return 0


def _write_config(
    config_path: Path,
    version: int,
    skills: list[str],
    hybrid_enabled: bool,
    providers: list[str],
) -> None:
    payload = {
        "version": version,
        "skills": skills,
        "hybrid": {
            "enabled": hybrid_enabled,
            "providers": providers,
        },
    }
    text = "# yaml-language-server: $schema=./schema/logics.yaml.schema.json\n"
    text += yaml.safe_dump(payload, sort_keys=False)
    config_path.write_text(text, encoding="utf-8")


def _append_gitignore_entry(gitignore_path: Path, entry: str) -> None:
    existing = gitignore_path.read_text(encoding="utf-8") if gitignore_path.exists() else ""
    lines = [line.strip() for line in existing.splitlines()]
    if entry in lines:
        return
    prefix = "" if not existing or existing.endswith("\n") else "\n"
    gitignore_path.write_text(f"{existing}{prefix}{entry}\n", encoding="utf-8")


def _read_current_version() -> str:
    try:
        return metadata.version("logics-cli")
    except metadata.PackageNotFoundError:
        version_file = REPO_ROOT / "VERSION"
        if version_file.exists():
            return version_file.read_text(encoding="utf-8").strip()
        return "0.0.0"


def _find_item(backlog_dir: Path, item_id: str) -> BacklogItem | None:
    if not backlog_dir.exists():
        return None
    for item in read_backlog(backlog_dir):
        if item.item_id == item_id:
            return item
    return None


def _item_to_json(item: BacklogItem) -> dict[str, object]:
    return {
        "id": item.item_id,
        "title": item.title,
        "status": item.status,
        "priority": item.priority,
        "createdAt": item.created_at.isoformat(),
        "path": None if item.path is None else str(item.path),
        "body": item.body,
    }


def _format_item_line(item: BacklogItem) -> str:
    age_days = max((dt.datetime.now(dt.timezone.utc) - item.created_at).days, 0)
    return f"{item.item_id} [{item.status}] P{item.priority} {age_days}d {item.title}"


def _run_flow_new(args: argparse.Namespace, backlog_dir: Path) -> int:
    title = args.title
    description = args.description
    interactive = sys.stdout.isatty()

    if interactive and (title is None or description is None):
        editor = os.environ.get("EDITOR")
        if not editor:
            print("EDITOR is not set.", file=sys.stderr)
            return 1
        with tempfile.NamedTemporaryFile("w+", suffix=".md", delete=False) as handle:
            handle.write("# Title\n\nDescribe the item.\n")
            temp_path = Path(handle.name)
        try:
            result = subprocess.run([editor, str(temp_path)], check=False)
            if result.returncode != 0:
                print("Editor exited with an error.", file=sys.stderr)
                return 1
            content = temp_path.read_text(encoding="utf-8").strip().splitlines()
            if not content:
                print("No item content provided.", file=sys.stderr)
                return 1
            title = content[0].lstrip("#").strip()
            description = "\n".join(content[1:]).strip()
        finally:
            temp_path.unlink(missing_ok=True)
    elif title is None or description is None:
        print("Non-interactive flow new requires --title and --description.", file=sys.stderr)
        return 1

    backlog_dir.mkdir(parents=True, exist_ok=True)
    item_id = _next_item_id(backlog_dir)
    item = BacklogItem(
        item_id=item_id,
        title=title,
        status="open",
        priority=args.priority,
        created_at=dt.datetime.now(dt.timezone.utc),
        path=backlog_dir / f"{item_id}.md",
        body=f"# {title}\n\n{description}\n",
    )
    write_item(item, item.path)
    if args.as_json:
        print(json.dumps(_item_to_json(item), indent=2))
    else:
        print(f"Created {item_id}")
    return 0


def _next_item_id(backlog_dir: Path) -> str:
    max_number = 0
    for path in backlog_dir.glob("item_*.md"):
        stem = path.stem
        suffix = stem.split("_", 1)[-1]
        if suffix.isdigit():
            max_number = max(max_number, int(suffix))
    return f"item_{max_number + 1:03d}"


def _print_human_report(report) -> None:
    lines = [
        _human_line(report.cli.status, "cli", f"version {report.cli.version}"),
        _human_line(report.project.status, "project", "workflow state checked"),
        _human_line(report.gitFootprint.status, "gitFootprint", "git footprint checked"),
    ]
    for skill in report.skills:
        lines.append(_human_line(skill.status, f"skill:{skill.name}", skill.message or "skill resolved"))
    for provider in report.hybrid.providerStatuses:
        lines.append(_human_line(provider["status"], f"hybrid:{provider['name']}", "provider check"))
    for line in lines:
        print(line)


def _human_line(status: str, name: str, summary: str) -> str:
    symbol = {"ok": "✓", "ready": "✓", "warning": "!", "not_initialized": "!", "unreachable": "!", "invalid": "✗"}.get(status, "!")
    return f"{symbol} {name}: {summary}"


if __name__ == "__main__":
    raise SystemExit(main())
