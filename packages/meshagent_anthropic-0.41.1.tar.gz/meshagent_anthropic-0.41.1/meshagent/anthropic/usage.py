from __future__ import annotations

from typing import Any
import logging

from opentelemetry import metrics
from pydantic import BaseModel

logger = logging.getLogger("anthropic_agent")
_usage_meters: dict[str, object] = {}
_BILLABLE_USAGE_KEYS = frozenset(
    {
        "input_tokens",
        "output_tokens",
        "cache_creation_input_tokens",
        "cache_read_input_tokens",
    }
)


def _to_float(value: Any) -> float | None:
    if value is None:
        return None

    try:
        return float(value)
    except Exception:
        return None


def _flatten_usage(usage: dict[str, Any]) -> dict[str, float]:
    flattened: dict[str, float] = {}

    for key, value in usage.items():
        try:
            if isinstance(value, dict):
                for nested_key, nested_value in value.items():
                    if isinstance(nested_value, dict):
                        continue
                    nested_number = _to_float(nested_value)
                    if nested_number is not None:
                        flattened[nested_key] = nested_number
                continue

            number = _to_float(value)
            if number is not None:
                flattened[key] = number
        except Exception as error:
            logger.warning("unexpected usage key %s:%s", key, value, exc_info=error)

    return flattened


def split_anthropic_usage_by_tier(
    *, model: str, usage: dict[str, float]
) -> dict[str, float]:
    def total_input_tokens(current: dict[str, float]) -> float:
        return (
            float(current.get("input_tokens", 0))
            + float(current.get("cache_creation_input_tokens", 0))
            + float(current.get("cache_read_input_tokens", 0))
        )

    normalized_model = model.strip().lower()
    premium_long_context_exact_models = frozenset(
        {
            "claude-sonnet-4",
        }
    )
    premium_long_context_prefixes = (
        "claude-sonnet-4-5",
        "claude-sonnet-4-0",
        "claude-sonnet-4-20250514",
    )

    if (
        normalized_model not in premium_long_context_exact_models
        and not normalized_model.startswith(premium_long_context_prefixes)
    ):
        return dict(usage)

    if total_input_tokens(usage) <= 200_000:
        return dict(usage)

    split_usage = dict(usage)

    def move(token_key: str) -> None:
        if token_key in split_usage:
            split_usage[f"{token_key}_long"] = float(split_usage.pop(token_key))

    move("input_tokens")
    move("output_tokens")
    move("cache_creation_input_tokens")
    move("cache_read_input_tokens")

    return split_usage


def normalize_anthropic_usage(usage: object) -> dict[str, Any] | None:
    if usage is None:
        return None

    if isinstance(usage, BaseModel):
        try:
            return usage.model_dump(mode="json")
        except Exception:
            return None

    if isinstance(usage, dict):
        return usage

    return None


def preprocess_anthropic_usage(
    *, model: str, usage: dict[str, Any]
) -> dict[str, float] | None:
    if not isinstance(usage, dict):
        return None

    service_tier = usage.get("service_tier")
    if service_tier is not None and service_tier != "standard":
        logger.warning("custom pricing tier is in use, ignoring custom tier")

    flattened = _flatten_usage(
        {key: value for key, value in usage.items() if key in _BILLABLE_USAGE_KEYS}
    )
    return split_anthropic_usage_by_tier(model=model, usage=flattened)


def add_usage_metrics(*, totals: dict[str, float], usage: dict[str, float]) -> None:
    for key, value in usage.items():
        totals[key] = float(totals.get(key, 0.0)) + float(value)


def _get_counter_meter(name: str):
    meter = _usage_meters.get(name)
    if meter is None:
        usage_meter = metrics.get_meter("meshagent.usage")
        meter = usage_meter.create_counter(name, "tokens")
        _usage_meters[name] = meter
    return meter


def track_otel_usage_metrics(
    *,
    model: str,
    provider: str,
    tokens: dict[str, float],
    annotations: dict[str, str] | None = None,
) -> None:
    attributes = {"model": model, "provider": provider}
    for name, value in (annotations or {}).items():
        attributes[f"annotation.{name}"] = value
    for token_name, total in tokens.items():
        meter = _get_counter_meter(token_name)
        meter.add(total, attributes)


# Backwards compatibility for older imports.
_preprocess_anthropic = preprocess_anthropic_usage
