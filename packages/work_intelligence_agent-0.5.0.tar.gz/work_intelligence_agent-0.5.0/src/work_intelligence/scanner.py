"""Repository scanner for discovering git repositories."""

from __future__ import annotations

import logging
import os

from work_intelligence.models import ProgressLog, ReportConfiguration

logger = logging.getLogger(__name__)


async def scan_repositories(
    config: ReportConfiguration,
    progress: ProgressLog | None = None,
) -> list[str]:
    """Discover and validate git repositories from config sources."""
    candidates: set[str] = set()

    if not config.parent_directory and not config.repositories:
        if progress:
            await progress.error("scanner", "No parent_directory or repositories provided.")
        return []

    if config.parent_directory:
        parent = os.path.realpath(config.parent_directory)
        max_depth = config.max_scan_depth
        if progress:
            await progress.log(
                "scanner",
                f"Scanning: '{config.parent_directory}' -> '{parent}' (max_depth={max_depth})",
            )
        if os.path.isdir(parent):
            parent_depth = parent.rstrip(os.sep).count(os.sep)
            for dirpath, dirnames, _filenames in os.walk(parent):
                current_depth = dirpath.rstrip(os.sep).count(os.sep) - parent_depth
                if current_depth >= max_depth:
                    dirnames.clear()
                    continue
                if ".git" in dirnames:
                    repo_path = os.path.realpath(dirpath)
                    candidates.add(repo_path)
                    if progress:
                        await progress.log("scanner", f"  Found: {repo_path}")
                    dirnames.remove(".git")
            if not candidates and progress:
                await progress.warning("scanner", f"No git repos found under '{parent}'.")
        else:
            msg = f"Not a directory: '{parent}'"
            if progress:
                await progress.error("scanner", msg)
            logger.warning(msg)

    if config.repositories:
        if progress:
            await progress.log("scanner", f"Adding {len(config.repositories)} explicit repo(s)...")
        for repo in config.repositories:
            resolved = os.path.realpath(repo)
            candidates.add(resolved)

    valid: list[str] = []
    for path in candidates:
        if not os.path.exists(path):
            if progress:
                await progress.warning("scanner", f"Path missing: {path}")
            logger.warning("Path does not exist: %s", path)
            continue
        git_dir = os.path.join(path, ".git")
        if not os.path.isdir(git_dir):
            if progress:
                await progress.warning("scanner", f"Not a git repo: {path}")
            logger.warning("Not a valid git repository: %s", path)
            continue
        valid.append(path)

    if progress:
        await progress.log("scanner", f"Scan done: {len(valid)} valid repo(s).")
    return sorted(set(valid))
