"""MCP server — exposes the work-intelligence pipeline as MCP tools."""

from __future__ import annotations

import os
from datetime import date, timedelta

from fastmcp import Context, FastMCP

from work_intelligence.extractor import extract_history as _extract_history
from work_intelligence.models import DateRange, ProgressLog, ReportConfiguration
from work_intelligence.pipeline import run_pipeline
from work_intelligence.scanner import scan_repositories

mcp = FastMCP("work-intelligence-agent")


def _default_date_range(
    start_date: str | None,
    end_date: str | None,
) -> DateRange:
    """Build a DateRange, defaulting to the last 7 days."""
    today = date.today()
    return DateRange(
        start=start_date or (today - timedelta(days=7)).isoformat(),
        end=end_date or today.isoformat(),
    )


def _gemini_status() -> str:
    """Return a status line about Gemini AI summarization."""
    if os.environ.get("GEMINI_API_KEY"):
        return "✅ Gemini AI summarization is enabled."
    return (
        "💡 Tip: Set GEMINI_API_KEY in your MCP config env to enable "
        "AI-powered commit summaries."
    )


@mcp.tool()
async def generate_report(
    author: str,
    ctx: Context,
    parent_directory: str | None = None,
    repositories: list[str] | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    output_path: str | None = None,
) -> str:
    """Generate a weekly work report by scanning git history.

    Before calling this tool, please ask the user for:
    - author: Their git author name (e.g. "Jane Doe")
    - parent_directory OR repositories: Where to find their git repos
    - start_date / end_date: Date range (defaults to last 7 days)
    - output_path: Optional file path to save the report (e.g. "report.md")
    """
    if not author or not author.strip():
        return (
            "I need your git author name, repo location, "
            "and optionally a date range to generate a report."
        )

    if not parent_directory and not repositories:
        return (
            f"Author is **{author}**. Please also provide "
            "a parent_directory or list of repositories."
        )

    await ctx.info(f"Starting report for author='{author}'")
    await ctx.info(f"Server CWD: {os.getcwd()}")

    config = ReportConfiguration(
        author=author,
        parent_directory=parent_directory,
        repositories=repositories,
        date_range=_default_date_range(start_date, end_date),
        output_path=output_path,
    )

    progress = ProgressLog(ctx=ctx)
    report = await run_pipeline(config, progress)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(report)
        await ctx.info(f"Report saved to {output_path}")

    return f"{_gemini_status()}\n\n{progress.render()}{report}"


@mcp.tool()
async def scan_repos(parent_directory: str, ctx: Context) -> list[str]:
    """Discover git repositories under a parent directory.

    Ask the user for the parent directory path if not provided.
    """
    if not parent_directory or not parent_directory.strip():
        return ["Please provide a parent directory path to scan."]

    await ctx.info(f"Scanning: {parent_directory}")
    progress = ProgressLog(ctx=ctx)
    config = ReportConfiguration(author="", parent_directory=parent_directory)
    repos = await scan_repositories(config, progress)
    await ctx.info(f"Found {len(repos)} repo(s).")
    return repos


@mcp.tool()
async def extract_history(
    repo_paths: list[str],
    author: str,
    ctx: Context,
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """Extract commit history from specified repositories.

    Ask the user for their git author name and repo paths if not provided.
    """
    await ctx.info(f"Extracting history for '{author}'...")
    progress = ProgressLog(ctx=ctx)
    date_range = _default_date_range(start_date, end_date)
    commits = await _extract_history(repo_paths, author, date_range, progress)
    await ctx.info(f"Found {len(commits)} commit(s).")
    return [
        {
            "hash": c.hash,
            "author": c.author,
            "date": c.date.isoformat(),
            "message": c.message,
            "repository": c.repository,
        }
        for c in commits
    ]


def main() -> None:
    """Entry point for the MCP server."""
    mcp.run()
