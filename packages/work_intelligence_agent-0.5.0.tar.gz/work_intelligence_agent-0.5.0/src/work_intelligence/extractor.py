"""History extractor — runs git log and parses output into CommitRecords."""

from __future__ import annotations

import asyncio
import logging
import os
import subprocess
from datetime import datetime

from work_intelligence.models import CommitRecord, DateRange, ProgressLog

logger = logging.getLogger(__name__)


def _run_git_sync(
    cmd: list[str], cwd: str, timeout: int = 60
) -> tuple[str, str, int]:
    """Run a git command synchronously with a timeout. Returns (stdout, stderr, returncode)."""
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.stdout, proc.stderr, proc.returncode


def parse_git_log_line(line: str, repository: str) -> CommitRecord:
    """Parse a single pipe-delimited git log line into a CommitRecord."""
    parts = line.split("|", maxsplit=3)
    if len(parts) != 4:
        raise ValueError(
            f"Expected 4 pipe-delimited fields, got {len(parts)}: {line!r}"
        )
    commit_hash, author, date_str, message = parts
    return CommitRecord(
        hash=commit_hash,
        author=author,
        date=datetime.fromisoformat(date_str),
        message=message,
        repository=repository,
    )


def format_git_log_line(record: CommitRecord) -> str:
    """Format a CommitRecord back into the pipe-delimited git log format."""
    return (
        f"{record.hash}|{record.author}"
        f"|{record.date.isoformat()}|{record.message}"
    )


async def extract_history(
    repo_paths: list[str],
    author: str,
    date_range: DateRange,
    progress: ProgressLog | None = None,
) -> list[CommitRecord]:
    """Extract commit history from repos filtered by author and date_range."""
    all_commits: list[CommitRecord] = []

    if not repo_paths:
        if progress:
            await progress.error("extractor", "No repository paths — nothing to extract.")
        return []

    if progress:
        await progress.log(
            "extractor",
            f"Extracting: author='{author}', "
            f"range={date_range.start}..{date_range.end}, "
            f"repos={len(repo_paths)}",
        )

    for repo_path in repo_paths:
        repo_name = os.path.basename(repo_path)
        cmd = [
            "git", "log", "--all",
            "--format=%h|%an|%aI|%s",
            f"--after={date_range.start}",
            f"--before={date_range.end}",
            f"--author={author}",
        ]

        if progress:
            await progress.log("extractor", f"  git log in '{repo_name}'...")

        try:
            result = await asyncio.to_thread(
                _run_git_sync, cmd, repo_path
            )
            stdout, stderr, returncode = result
        except Exception as exc:
            if progress:
                await progress.error("extractor", f"{repo_name}: {exc}")
            continue

        if returncode != 0:
            err_msg = stderr.strip() if stderr else "unknown error"
            if progress:
                await progress.error(
                    "extractor",
                    f"{repo_name} exit {returncode}: {err_msg}",
                )
            continue

        repo_commits = 0
        for line in stdout.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                commit = parse_git_log_line(stripped, repo_name)
                all_commits.append(commit)
                repo_commits += 1
            except (ValueError, IndexError) as exc:
                if progress:
                    await progress.warning(
                        "extractor", f"Bad line in {repo_name}: {exc}"
                    )

        if progress:
            await progress.log("extractor", f"  {repo_name}: {repo_commits} commit(s)")

    all_commits.sort(key=lambda c: c.date)
    if progress:
        await progress.log(
            "extractor",
            f"Total: {len(all_commits)} commit(s) from {len(repo_paths)} repo(s).",
        )
    return all_commits
