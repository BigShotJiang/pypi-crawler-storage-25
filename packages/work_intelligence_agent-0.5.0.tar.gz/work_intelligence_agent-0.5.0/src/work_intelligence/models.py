"""Shared data models for the Work Intelligence Agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


class ProgressLog:
    """Collects progress messages and sends them via MCP Context."""

    def __init__(self, ctx: object | None = None) -> None:
        self._messages: list[str] = []
        self._ctx = ctx  # FastMCP Context for real-time notifications

    async def log(self, tag: str, msg: str) -> None:
        """Send a progress message via MCP context and collect it."""
        import sys
        line = f"[{tag}] {msg}"
        self._messages.append(line)
        print(line, file=sys.stderr, flush=True)
        if self._ctx is not None:
            try:
                await self._ctx.info(line)
            except Exception:
                pass  # Don't break pipeline if ctx notification fails

    async def warning(self, tag: str, msg: str) -> None:
        """Send a warning via MCP context."""
        import sys
        line = f"[{tag}] WARNING: {msg}"
        self._messages.append(line)
        print(line, file=sys.stderr, flush=True)
        if self._ctx is not None:
            try:
                await self._ctx.warning(line)
            except Exception:
                pass

    async def error(self, tag: str, msg: str) -> None:
        """Send an error via MCP context."""
        import sys
        line = f"[{tag}] ERROR: {msg}"
        self._messages.append(line)
        print(line, file=sys.stderr, flush=True)
        if self._ctx is not None:
            try:
                await self._ctx.error(line)
            except Exception:
                pass

    def render(self) -> str:
        """Return all messages as a formatted block."""
        if not self._messages:
            return ""
        lines = "\n".join(self._messages)
        return (
            f"<details>\n<summary>📋 Processing Log</summary>"
            f"\n\n```\n{lines}\n```\n</details>\n\n"
        )


@dataclass
class DateRange:
    """ISO 8601 date range for filtering git history."""

    start: str
    end: str


@dataclass
class ReportConfiguration:
    """User-provided settings for report generation."""

    author: str
    parent_directory: str | None = None
    repositories: list[str] | None = None
    date_range: DateRange | None = None
    output_path: str | None = None
    max_scan_depth: int = 3


@dataclass
class CommitRecord:
    """A single git commit extracted from a repository."""

    hash: str
    author: str
    date: datetime
    message: str
    repository: str


@dataclass
class RepoGroup:
    """Commits grouped by repository within a single day."""

    repository: str
    commits: list[CommitRecord]


@dataclass
class WeekdayGroup:
    """Commits grouped by weekday, sub-grouped by repository."""

    weekday: str
    date: str
    repos: list[RepoGroup]


@dataclass
class SummaryGroup:
    """A group of commits sharing a common message prefix."""

    prefix: str
    commits: list[CommitRecord]
    is_summarized: bool
    ai_summary: str | None = None


@dataclass
class SummarizedRepoGroup:
    """Summarized commits grouped by repository."""

    repository: str
    groups: list[SummaryGroup]


@dataclass
class SummarizedWeekdayGroup:
    """Summarized commits grouped by weekday."""

    weekday: str
    date: str
    repos: list[SummarizedRepoGroup]
