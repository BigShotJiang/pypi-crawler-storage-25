"""Commit summarizer — groups similar commits and optionally summarizes with Gemini.

Uses prefix-based grouping as the core logic. When a Gemini API key is available
(via GEMINI_API_KEY env var), groups with 3+ commits get an AI-generated summary.
Falls back gracefully to prefix-only summaries if the key is missing or the API fails.

System design concepts demonstrated:
- Strategy pattern: AI vs prefix-only summarization
- Graceful degradation: API failure doesn't break the pipeline
- Environment-based configuration: API key from env var
- Single Responsibility: grouping logic is separate from AI calls
"""

from __future__ import annotations

import logging
import os
from collections import defaultdict

from work_intelligence.models import (
    CommitRecord,
    SummarizedRepoGroup,
    SummarizedWeekdayGroup,
    SummaryGroup,
    WeekdayGroup,
)

logger = logging.getLogger(__name__)


def extract_prefix(message: str) -> str:
    """Extract the prefix of a commit message.

    Returns the substring up to the first colon or the first 50 characters,
    whichever is shorter. If no colon exists within the first 50 characters,
    returns the first 50 characters (or the full message if shorter than 50).
    """
    truncated = message[:50]
    colon_pos = truncated.find(":")
    if colon_pos != -1:
        return truncated[:colon_pos]
    return truncated


def _build_prefix_groups(commits: list[CommitRecord]) -> list[SummaryGroup]:
    """Group commits by normalized prefix. Core grouping logic."""
    prefix_buckets: dict[str, list[CommitRecord]] = defaultdict(list)
    prefix_display: dict[str, str] = {}

    for commit in commits:
        raw_prefix = extract_prefix(commit.message)
        normalized = raw_prefix.strip().lower()
        prefix_buckets[normalized].append(commit)
        if normalized not in prefix_display:
            prefix_display[normalized] = raw_prefix

    groups: list[SummaryGroup] = []
    for normalized, bucket_commits in prefix_buckets.items():
        groups.append(SummaryGroup(
            prefix=prefix_display[normalized],
            commits=bucket_commits,
            is_summarized=len(bucket_commits) >= 3,
        ))
    return groups


def _get_gemini_client():
    """Create a Gemini client if API key is available. Returns None otherwise."""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None
    try:
        from google import genai
        return genai.Client(api_key=api_key)
    except Exception as exc:
        logger.warning("Failed to initialize Gemini client: %s", exc)
        return None


def _summarize_with_gemini(client, group: SummaryGroup) -> str | None:
    """Call Gemini to produce a one-line summary for a group of commits.

    Returns the summary string, or None if the call fails.
    """
    messages = "\n".join(f"- {c.message}" for c in group.commits)
    prompt = (
        "You are a developer assistant. Summarize these related git commits "
        "into ONE concise sentence (max 20 words) describing what was accomplished. "
        "Do not use bullet points. Do not start with 'This'.\n\n"
        f"Commits:\n{messages}"
    )

    try:
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt,
        )
        text = response.text.strip()
        return text if text else None
    except Exception as exc:
        logger.warning("Gemini summarization failed: %s", exc)
        return None


def summarize_commits(
    weekday_groups: list[WeekdayGroup],
) -> list[SummarizedWeekdayGroup]:
    """Summarize commits within each repo group on a given day.

    Groups commits by normalized (lowercased, stripped) prefix.
    Groups with 3+ commits get ``is_summarized=True``.
    Groups with fewer than 3 commits get ``is_summarized=False``.

    If GEMINI_API_KEY is set, summarized groups also get an ``ai_summary``
    field with a Gemini-generated one-liner. Falls back silently on failure.
    """
    client = _get_gemini_client()
    if client:
        logger.info("Gemini API key found — AI summaries enabled")
    else:
        logger.info("No Gemini API key — using prefix-only summaries")

    result: list[SummarizedWeekdayGroup] = []

    for wg in weekday_groups:
        summarized_repos: list[SummarizedRepoGroup] = []

        for rg in wg.repos:
            groups = _build_prefix_groups(rg.commits)

            # Enrich summarized groups with AI summaries if available
            if client:
                for group in groups:
                    if group.is_summarized:
                        group.ai_summary = _summarize_with_gemini(client, group)

            summarized_repos.append(SummarizedRepoGroup(
                repository=rg.repository,
                groups=groups,
            ))

        result.append(SummarizedWeekdayGroup(
            weekday=wg.weekday,
            date=wg.date,
            repos=summarized_repos,
        ))

    return result
