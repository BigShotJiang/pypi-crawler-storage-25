"""CLI entry point for the Work Intelligence Agent."""

from __future__ import annotations

import argparse
import sys

from work_intelligence.config import load_configuration
from work_intelligence.pipeline import run_pipeline


def build_arg_parser() -> argparse.ArgumentParser:
    """Build the argparse parser with all CLI options."""
    parser = argparse.ArgumentParser(
        description="Generate a weekly work report from git history.",
    )
    parser.add_argument(
        "--author",
        help="Author name for filtering commits (required)",
    )
    parser.add_argument(
        "--parent-directory",
        help="Parent directory to scan recursively for git repositories",
    )
    parser.add_argument(
        "--repositories",
        nargs="+",
        help="Explicit list of repository paths",
    )
    parser.add_argument(
        "--start-date",
        help="Start date for the report range (YYYY-MM-DD)",
    )
    parser.add_argument(
        "--end-date",
        help="End date for the report range (YYYY-MM-DD)",
    )
    parser.add_argument(
        "--output",
        help="Output file path (defaults to stdout)",
    )
    parser.add_argument(
        "--config",
        default=".kiro/work-intelligence.json",
        help="Path to configuration file (default: .kiro/work-intelligence.json)",
    )
    return parser


def main() -> None:
    """CLI entry point.

    Parses args, loads config, runs the full pipeline:
    load config → scan repos → extract history → group → summarize → render → output.
    """
    parser = build_arg_parser()
    args = parser.parse_args()

    cli_args: dict = {}
    if args.author is not None:
        cli_args["author"] = args.author
    if args.parent_directory is not None:
        cli_args["parent_directory"] = args.parent_directory
    if args.repositories is not None:
        cli_args["repositories"] = args.repositories
    if args.start_date is not None or args.end_date is not None:
        cli_args["date_range"] = {
            "start": args.start_date or "",
            "end": args.end_date or "",
        }
    if args.output is not None:
        cli_args["output_path"] = args.output

    try:
        config = load_configuration(args.config, cli_args)

        import asyncio
        report = asyncio.run(run_pipeline(config))

        if config.output_path:
            with open(config.output_path, "w", encoding="utf-8") as f:
                f.write(report)
        else:
            print(report)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
