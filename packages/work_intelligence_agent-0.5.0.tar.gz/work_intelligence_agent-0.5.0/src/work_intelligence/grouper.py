"""Commit grouper — groups commits by calendar date and repository."""

from __future__ import annotations

from collections import defaultdict

from work_intelligence.models import CommitRecord, RepoGroup, WeekdayGroup


def group_by_weekday(commits: list[CommitRecord]) -> list[WeekdayGroup]:
    """Group commits by calendar date, then by repository within each date.

    Orders groups chronologically (ascending date order).
    Omits days with zero commits.
    Each WeekdayGroup contains the weekday name and the actual date string.
    """
    if not commits:
        return []

    # Group commits by calendar date
    by_date: dict[str, list[CommitRecord]] = defaultdict(list)
    for commit in commits:
        date_key = commit.date.strftime("%Y-%m-%d")
        by_date[date_key].append(commit)

    # Build WeekdayGroups sorted chronologically
    groups: list[WeekdayGroup] = []
    for date_str in sorted(by_date):
        day_commits = by_date[date_str]

        # Sub-group by repository
        by_repo: dict[str, list[CommitRecord]] = defaultdict(list)
        for commit in day_commits:
            by_repo[commit.repository].append(commit)

        repo_groups = [
            RepoGroup(repository=repo, commits=repo_commits)
            for repo, repo_commits in sorted(by_repo.items())
        ]

        # Derive weekday name from the first commit's date
        weekday_name = day_commits[0].date.strftime("%A")

        groups.append(WeekdayGroup(
            weekday=weekday_name,
            date=date_str,
            repos=repo_groups,
        ))

    return groups
