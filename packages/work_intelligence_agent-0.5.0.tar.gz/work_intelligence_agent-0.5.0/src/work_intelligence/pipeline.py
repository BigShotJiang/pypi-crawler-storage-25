"""Pipeline orchestrator — runs the full report generation flow."""

from __future__ import annotations

from work_intelligence.extractor import extract_history
from work_intelligence.grouper import group_by_weekday
from work_intelligence.models import ProgressLog, ReportConfiguration
from work_intelligence.renderer import render_markdown
from work_intelligence.scanner import scan_repositories
from work_intelligence.summarizer import summarize_commits


async def run_pipeline(
    config: ReportConfiguration,
    progress: ProgressLog | None = None,
) -> str:
    """Execute the full report pipeline and return the markdown string.

    Flow: scan repos → extract history → group → summarize → render.
    """
    if progress:
        await progress.log("pipeline", f"Starting for author='{config.author}'")
        if config.date_range:
            await progress.log(
                "pipeline",
                f"Date range: {config.date_range.start} to {config.date_range.end}",
            )

    repo_paths = await scan_repositories(config, progress)
    if not repo_paths and progress:
        await progress.warning("pipeline", "No repositories found.")

    commits = await extract_history(
        repo_paths, config.author, config.date_range, progress
    )
    if not commits and progress:
        await progress.warning("pipeline", "No commits found.")

    weekday_groups = group_by_weekday(commits)
    summarized_groups = summarize_commits(weekday_groups)
    report = render_markdown(summarized_groups, config, len(commits))

    if progress:
        await progress.log("pipeline", "Done.")

    return report
