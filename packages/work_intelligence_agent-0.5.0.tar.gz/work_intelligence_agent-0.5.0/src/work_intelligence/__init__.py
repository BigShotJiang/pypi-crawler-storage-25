"""Work Intelligence Agent — automated weekly work reporting from git history."""
