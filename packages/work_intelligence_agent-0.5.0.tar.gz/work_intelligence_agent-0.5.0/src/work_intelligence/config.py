"""Configuration loading and validation for the Work Intelligence Agent."""

from __future__ import annotations

import json
import os
from datetime import date, timedelta

from work_intelligence.models import DateRange, ReportConfiguration


def load_configuration(config_file_path: str, cli_args: dict) -> ReportConfiguration:
    """Load configuration from a JSON file and merge with CLI arguments.

    Reads JSON from config_file_path if it exists, ignores if missing.
    Merges CLI args on top of file values (CLI wins for non-None values).
    Validates author is present and non-empty.
    Validates at least one of parent_directory or repositories is provided.
    Defaults date_range to last 7 days if not specified.
    Raises ValueError if start date > end date.
    """
    # 1. Read config file (ignore if missing)
    file_config: dict = {}
    if os.path.isfile(config_file_path):
        with open(config_file_path, "r", encoding="utf-8") as f:
            file_config = json.load(f)

    # 2. Merge CLI args on top of file values (CLI wins for non-None values)
    merged: dict = dict(file_config)
    for key, value in cli_args.items():
        if value is not None:
            merged[key] = value

    # 3. Validate author
    author = merged.get("author", "")
    if not author or not isinstance(author, str) or not author.strip():
        raise ValueError("author is required and must be a non-empty string")

    # 4. Validate at least one repo source
    parent_directory = merged.get("parent_directory")
    repositories = merged.get("repositories")
    if not parent_directory and not repositories:
        raise ValueError(
            "at least one of parent_directory or repositories must be provided"
        )

    # 5. Handle date_range
    date_range_raw = merged.get("date_range")
    if date_range_raw is not None:
        if isinstance(date_range_raw, dict):
            start_str = date_range_raw.get("start", "")
            end_str = date_range_raw.get("end", "")
        elif isinstance(date_range_raw, DateRange):
            start_str = date_range_raw.start
            end_str = date_range_raw.end
        else:
            raise ValueError("date_range must be a dict with 'start' and 'end' keys or a DateRange")

        # 6. Validate start <= end
        start_date = date.fromisoformat(start_str)
        end_date = date.fromisoformat(end_str)
        if start_date > end_date:
            raise ValueError(
                f"start date ({start_str}) must not be after end date ({end_str})"
            )
        date_range = DateRange(start=start_str, end=end_str)
    else:
        # Default to last 7 days
        today = date.today()
        start = today - timedelta(days=7)
        date_range = DateRange(start=start.isoformat(), end=today.isoformat())

    return ReportConfiguration(
        author=author.strip(),
        parent_directory=parent_directory,
        repositories=repositories,
        date_range=date_range,
        output_path=merged.get("output_path"),
    )
