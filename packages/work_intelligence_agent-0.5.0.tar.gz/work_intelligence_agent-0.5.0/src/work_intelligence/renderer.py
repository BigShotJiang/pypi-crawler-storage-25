"""Markdown renderer — produces the final report output."""

from __future__ import annotations

from work_intelligence.models import (
    ReportConfiguration,
    SummarizedWeekdayGroup,
)


def render_markdown(
    groups: list[SummarizedWeekdayGroup],
    config: ReportConfiguration,
    total_commits: int,
) -> str:
    """Produce a markdown report from summarized weekday groups.

    Produces a top-level heading with author, date range, and total commit count.
    Each day is a ## Weekday — YYYY-MM-DD heading.
    Each repo within a day is a ### RepoName heading.
    Summarized groups render as a summary line with count, followed by individual
    commits as sub-items.
    Non-summarized commits render as - `hash` message.
    If zero commits, produces a message stating no commits were found.
    """
    lines: list[str] = []

    # Header
    date_range_str = ""
    if config.date_range:
        date_range_str = f" ({config.date_range.start} to {config.date_range.end})"

    lines.append(f"# Work Report for {config.author}{date_range_str}")
    lines.append("")
    lines.append(f"**Total commits: {total_commits}**")
    lines.append("")

    # Zero commits case
    if total_commits == 0:
        lines.append(
            f"No commits were found for {config.author}{date_range_str}."
        )
        lines.append("")
        return "\n".join(lines)

    # Render each day
    for day in groups:
        lines.append(f"## {day.weekday} — {day.date}")
        lines.append("")

        for repo in day.repos:
            lines.append(f"### {repo.repository}")
            lines.append("")

            for group in repo.groups:
                if group.is_summarized:
                    # AI summary line if available, otherwise prefix-based
                    if group.ai_summary:
                        lines.append(
                            f"- **{group.prefix}** ({len(group.commits)} commits) — *{group.ai_summary}*"
                        )
                    else:
                        lines.append(
                            f"- **{group.prefix}** ({len(group.commits)} commits)"
                        )
                    for commit in group.commits:
                        lines.append(f"  - `{commit.hash}` {commit.message}")
                else:
                    # Non-summarized: render each commit directly
                    for commit in group.commits:
                        lines.append(f"- `{commit.hash}` {commit.message}")

            lines.append("")

    return "\n".join(lines)
