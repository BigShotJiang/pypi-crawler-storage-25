# System Design Concepts — Learned Through Work Intelligence Agent

This guide maps **every major system design concept** to real code in this repo.
You're not reading theory — you're reading *your own project*.

---

## 1. Layered Architecture (N-Tier)

**Concept**: Separate your system into layers where each layer has a single responsibility and only talks to the layer below it.

**In this repo**:
```
Layer 3 (Interface)    →  cli.py, server.py       ← User-facing entry points
Layer 2 (Orchestration)→  pipeline.py             ← Coordinates the workflow
Layer 1 (Business Logic)→ scanner, extractor, grouper, summarizer, renderer
Layer 0 (Data)         →  models.py               ← Shared data structures
```

**Why it matters**: `cli.py` and `server.py` are two completely different interfaces (CLI vs MCP), but they both call the same `pipeline.py`. You can add a REST API tomorrow without touching any business logic.

**File to study**: `pipeline.py` — notice how it imports from Layer 1 but never from Layer 3.

---

## 2. Separation of Concerns (SoC)

**Concept**: Each module should do exactly one thing.

**In this repo**:
| Module | Single Responsibility |
|---|---|
| `scanner.py` | Find git repos on disk |
| `extractor.py` | Run `git log` and parse output |
| `grouper.py` | Organize commits by date and repo |
| `summarizer.py` | Cluster similar commits together |
| `renderer.py` | Turn data into markdown |
| `config.py` | Load and validate settings |
| `models.py` | Define data shapes (nothing else) |

**Anti-pattern avoided**: Imagine if `extractor.py` also rendered markdown. Changing the output format would risk breaking git parsing. SoC prevents that.

---

## 3. Pipeline / Chain of Responsibility Pattern

**Concept**: Process data through a sequence of stages, where each stage transforms the data and passes it to the next.

**In this repo** — `pipeline.py`:
```python
repo_paths       = scan_repositories(config)      # Stage 1: Discover
commits          = extract_history(repo_paths, …) # Stage 2: Extract
weekday_groups   = group_by_weekday(commits)       # Stage 3: Group
summarized_groups= summarize_commits(weekday_groups)# Stage 4: Summarize
return render_markdown(summarized_groups, …)       # Stage 5: Render
```

Each function takes the output of the previous one. This is the **Pipeline pattern** — identical to how Unix pipes work (`find | grep | sort | uniq`).

**System design interview tip**: This is how ETL systems, data pipelines, and compiler phases work.

---

## 4. Data Modeling / Schema Design

**Concept**: Define clear, typed data structures that flow between components.

**In this repo** — `models.py`:
```python
CommitRecord → RepoGroup → WeekdayGroup → SummarizedWeekdayGroup
```

This is a **progressive enrichment** pattern. Raw data (`CommitRecord`) gets enriched at each pipeline stage into richer structures. Each dataclass is immutable-ish and self-documenting.

**Key insight**: Notice how `models.py` has ZERO imports from other modules. It's the foundation — everything depends on it, it depends on nothing. This is the **Dependency Inversion Principle** in action.

---

## 5. Configuration Management

**Concept**: Externalize settings so behavior can change without code changes.

**In this repo** — `config.py`:
- Reads from a JSON config file
- Merges CLI arguments on top (CLI wins)
- Validates required fields
- Applies sensible defaults (last 7 days)

```python
def load_configuration(config_file_path: str, cli_args: dict) -> ReportConfiguration:
```

**Design patterns used**:
- **Strategy pattern**: Config determines behavior (which repos, which author, which dates)
- **Merge semantics**: File config < CLI args (precedence chain)
- **Fail-fast validation**: Raises `ValueError` immediately on bad input

**Real-world parallel**: This is exactly how tools like Docker, Kubernetes, and Terraform handle config — file + CLI + defaults + validation.

---

## 6. Interface / API Design (Multiple Entry Points)

**Concept**: Expose the same core logic through different interfaces.

**In this repo**:
| Interface | File | Protocol | User |
|---|---|---|---|
| CLI | `cli.py` | Command line args | Developers in terminal |
| MCP Server | `server.py` | Model Context Protocol | AI assistants (Kiro) |

Both call `run_pipeline()` from `pipeline.py`. The core logic doesn't know or care how it was invoked.

**This is the Facade pattern**: `pipeline.run_pipeline()` is a simple facade over 5 complex subsystems.

---

## 7. Error Handling / Graceful Degradation

**Concept**: When part of the system fails, keep going with what works.

**In this repo** — `extractor.py`:
```python
except subprocess.TimeoutExpired:
    logger.warning("git log timed out for repository %s", repo_path)
    continue  # ← Skip this repo, process the rest
except OSError as exc:
    logger.warning("Failed to run git log for %s: %s", repo_path, exc)
    continue  # ← Same: skip and continue
```

And `scanner.py`:
```python
logger.warning("Path does not exist: %s", path)
continue  # ← Skip invalid paths, return what's valid
```

**Pattern**: **Bulkhead / Partial Failure Tolerance**. One bad repo doesn't crash the whole report. This is critical in distributed systems — if one microservice is down, you degrade gracefully instead of failing entirely.

---

## 8. Subprocess / External System Integration

**Concept**: Your system often needs to call external tools or services.

**In this repo** — `extractor.py`:
```python
result = subprocess.run(
    cmd, cwd=repo_path,
    capture_output=True, text=True,
    timeout=30,  # ← Timeout prevents hanging
)
```

**Design decisions**:
- **Timeout**: 30 seconds prevents a hung git process from blocking everything
- **capture_output**: Captures stdout/stderr for parsing and error reporting
- **cwd**: Runs in the repo's directory (isolation)

**Real-world parallel**: This is how systems integrate with external APIs — with timeouts, error handling, and output parsing.

---

## 9. Data Transformation / ETL Pattern

**Concept**: Extract → Transform → Load. Pull raw data, reshape it, output it.

**In this repo**:
```
Extract:   extractor.py  → raw CommitRecords from git
Transform: grouper.py    → group by date/repo
           summarizer.py → cluster by prefix
Load:      renderer.py   → output as markdown
```

This is the same pattern used in data warehouses, analytics pipelines, and report generators at scale.

---

## 10. Protocol / API Layer (MCP)

**Concept**: Define a standard protocol so different systems can communicate.

**In this repo** — `server.py`:
```python
mcp = FastMCP("work-intelligence-agent")

@mcp.tool()
def generate_report(author: str, ...) -> str:
```

MCP (Model Context Protocol) is like REST or gRPC but designed for AI agents. The `@mcp.tool()` decorator exposes a Python function as a callable tool that any MCP-compatible client can discover and invoke.

**System design parallel**: This is identical to how you'd design a REST API or gRPC service — define your contract (parameters + return type), implement the logic behind it, and let clients call it.

---

## 11. Testing Strategy

**Concept**: Test at the right level with the right tools.

**In this repo**:

| Strategy | Example | File |
|---|---|---|
| **Unit tests** | Test `scan_repositories` with fake `.git` dirs | `test_scanner.py` |
| **Property-based testing** | Hypothesis generates random valid inputs | `conftest.py` |
| **Test fixtures** | `tmp_path` for isolated filesystem tests | `test_scanner.py` |
| **Strategies as factories** | `commit_records()`, `weekday_groups()` | `conftest.py` |

**Property-based testing** (Hypothesis) is the advanced concept here. Instead of writing 5 specific test cases, you describe *what valid input looks like* and let the framework generate hundreds of random cases:
```python
commit_records = st.composite(...)  # "A commit looks like this"
# Hypothesis will generate thousands of random commits to test with
```

---

## 12. Dependency Management / Build System

**Concept**: Declare what your project needs and how to build it.

**In this repo** — `pyproject.toml`:
```toml
dependencies = ["fastmcp"]           # Runtime deps
[project.optional-dependencies]
test = ["pytest", "hypothesis"]      # Dev-only deps

[project.scripts]
work-intelligence = "work_intelligence.cli:main"        # CLI entry point
work-intelligence-mcp = "work_intelligence.server:main" # MCP entry point
```

**Key design choices**:
- Minimal dependencies (only `fastmcp` at runtime)
- Test deps are optional (don't ship to production)
- Named entry points make the tool installable via `pip install`

---

## 13. Logging / Observability

**Concept**: Make your system's behavior visible without changing its logic.

**In this repo** — `scanner.py`, `extractor.py`:
```python
logger = logging.getLogger(__name__)
logger.warning("Path does not exist: %s", path)
```

Uses Python's standard `logging` module with `__name__` scoping. This means you can control log levels per-module without code changes.

**Real-world parallel**: In production systems, this feeds into log aggregation (ELK, CloudWatch, Datadog).

---

## 14. Input Validation / Defensive Programming

**Concept**: Never trust input. Validate early, fail with clear messages.

**In this repo** — `config.py`:
```python
if not author or not isinstance(author, str) or not author.strip():
    raise ValueError("author is required and must be a non-empty string")

if start_date > end_date:
    raise ValueError(f"start date ({start_str}) must not be after end date ({end_str})")
```

And `extractor.py`:
```python
parts = line.split("|", maxsplit=3)
if len(parts) != 4:
    raise ValueError(f"Expected 4 pipe-delimited fields, got {len(parts)}")
```

**Pattern**: **Fail-fast**. Bad data is caught at the boundary, not deep inside the pipeline where it's harder to debug.

---

## 15. Idempotency

**Concept**: Running the same operation multiple times produces the same result.

**In this repo**: `scan_repositories` returns `sorted(set(valid))` — deduplicated and sorted. Call it 10 times with the same config, get the same list. `group_by_weekday` is a pure function — same commits in, same groups out.

**Why it matters**: In distributed systems, operations may be retried. Idempotent operations are safe to retry.

---

## 16. Single Responsibility Principle (SOLID - S)

Already covered in SoC above, but worth calling out: every file in `src/work_intelligence/` does exactly one thing. This is the "S" in SOLID.

## 17. Open/Closed Principle (SOLID - O)

**Concept**: Open for extension, closed for modification.

**In this repo**: Want to add a new output format (HTML instead of markdown)? Write a new `render_html()` function. You don't need to modify `render_markdown()` or any other module. The pipeline could be extended to accept a renderer parameter.

## 18. Dependency Inversion Principle (SOLID - D)

**Concept**: High-level modules shouldn't depend on low-level modules. Both should depend on abstractions.

**In this repo**: `pipeline.py` (high-level) depends on `models.py` (abstractions/data contracts), not on implementation details of how git is called or how markdown is formatted.

---

## Summary: Concept → File Quick Reference

| Concept | Where to Look |
|---|---|
| Layered Architecture | Project structure as a whole |
| Separation of Concerns | Each `.py` file = one concern |
| Pipeline Pattern | `pipeline.py` |
| Data Modeling | `models.py` |
| Configuration Management | `config.py` |
| Multiple Interfaces / Facade | `cli.py` + `server.py` → `pipeline.py` |
| Graceful Degradation | `extractor.py`, `scanner.py` (try/except + continue) |
| External System Integration | `extractor.py` (subprocess) |
| ETL Pattern | extractor → grouper → summarizer → renderer |
| API/Protocol Design | `server.py` (MCP tools) |
| Testing Strategy | `tests/` + `conftest.py` (Hypothesis) |
| Dependency Management | `pyproject.toml` |
| Logging/Observability | `scanner.py`, `extractor.py` |
| Input Validation | `config.py`, `extractor.py` |
| Idempotency | `scanner.py` (sorted + deduplicated) |
| SOLID Principles | Spread across the entire codebase |

---

## What's NOT in This Repo (Yet) — Advanced Concepts to Add

These are concepts you'd encounter in larger systems. Each one is a great exercise to add:

| Concept | How to Add It |
|---|---|
| **Caching** | Cache `git log` results so re-runs are instant |
| **Rate Limiting** | Limit concurrent `git log` subprocesses |
| **Async / Concurrency** | Run `git log` on multiple repos in parallel |
| **Database / Persistence** | Store reports in SQLite for history |
| **Authentication** | Add API key validation to the MCP server |
| **Retry with Backoff** | Retry failed `git log` calls with exponential backoff |
| **Event-Driven Architecture** | Emit events when reports are generated |
| **Message Queue** | Queue report requests for async processing |
| **Monitoring / Metrics** | Track report generation time, error rates |
| **Feature Flags** | Toggle Gemini summarization on/off |
