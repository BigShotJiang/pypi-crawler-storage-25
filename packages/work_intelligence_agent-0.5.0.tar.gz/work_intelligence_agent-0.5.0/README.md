# Work Intelligence Agent

Automated weekly work reporting from git history across multiple repositories — now with optional AI-powered summaries via Google Gemini.

## What It Does

Point the agent at a directory (or list of repos) and an author name, and it produces a clean markdown report of the week's work — grouped by day, organized by repository, with similar commits summarized together.

**New in v0.2.0**: When a Gemini API key is configured, groups of 3+ related commits get an AI-generated one-line summary for faster reading.

## Installation

Requires Python 3.11+ and `git` on your PATH.

```bash
pip install work-intelligence-agent
```

Or run directly with `uvx`:

```bash
uvx work-intelligence-agent --author "Your Name" --parent-directory ~/projects
```

## AI Summarization (Optional)

Set your Gemini API key to enable AI-powered commit summaries:

```bash
export GEMINI_API_KEY="your-gemini-api-key"
```

Get a free API key at [Google AI Studio](https://aistudio.google.com/apikey).

Without the key, the agent still works — it just uses prefix-based grouping instead of AI summaries.

## CLI Usage

```bash
# Scan a parent directory for repos and generate a report
work-intelligence --author "Jane Doe" --parent-directory ~/projects

# Specify repos explicitly
work-intelligence --author "Jane Doe" --repositories ~/projects/repo-a ~/projects/repo-b

# Custom date range
work-intelligence --author "Jane Doe" --parent-directory ~/projects \
  --start-date 2025-01-06 --end-date 2025-01-12

# Write output to a file
work-intelligence --author "Jane Doe" --parent-directory ~/projects --output report.md
```

### CLI Options

| Option | Description |
|--------|-------------|
| `--author` | Author name for filtering commits (required) |
| `--parent-directory` | Directory to scan recursively for git repos |
| `--repositories` | Explicit list of repo paths |
| `--start-date` | Start date, YYYY-MM-DD (default: 7 days ago) |
| `--end-date` | End date, YYYY-MM-DD (default: today) |
| `--output` | Output file path (default: stdout) |
| `--config` | Config file path (default: `.kiro/work-intelligence.json`) |

## Configuration File

Place a JSON config at `.kiro/work-intelligence.json` to set defaults:

```json
{
  "author": "Jane Doe",
  "parent_directory": "~/projects",
  "date_range": {
    "start": "2025-01-06",
    "end": "2025-01-12"
  }
}
```

CLI arguments override config file values.

## MCP Server

The agent also runs as an MCP server for integration with AI tools like Kiro.

```json
{
  "mcpServers": {
    "work-intelligence-agent": {
      "command": "uvx",
      "args": ["--from", "work-intelligence-agent", "work-intelligence-mcp"],
      "env": {
        "GEMINI_API_KEY": "your-gemini-api-key"
      }
    }
  }
}
```

When used via MCP, the agent will prompt you for any missing details (author name, repo location, date range) through the AI assistant conversation.

The server exposes three tools:

- **`generate_report`** — Full weekly report generation (prompts for author, repos, dates, and output path)
- **`scan_repos`** — Discover git repos under a directory
- **`extract_history`** — Extract raw commit history

## Development

```bash
# Install with test dependencies
pip install -e ".[test]"

# Run tests
pytest

# Run the MCP server locally
work-intelligence-mcp
```

## Changelog

### v0.2.0

- AI-powered commit summarization via Google Gemini (`gemini-2.0-flash`)
- Set `GEMINI_API_KEY` to enable — falls back gracefully without it
- MCP server now prompts users for missing parameters (author, repos, dates)
- `generate_report` tool now accepts `output_path` to save reports to file
- Added `google-genai` dependency

### v0.1.0

- Initial release
- CLI and MCP server for weekly work report generation
- Prefix-based commit grouping and summarization
- Recursive git repository scanning

## License

MIT
