"""Unit tests for the repository scanner."""

from __future__ import annotations

import logging
import os

import pytest

from work_intelligence.models import ReportConfiguration
from work_intelligence.scanner import scan_repositories


def _make_git_repo(path):
    """Create a fake git repo by making a .git directory."""
    git_dir = os.path.join(path, ".git")
    os.makedirs(git_dir, exist_ok=True)


class TestScanParentDirectory:
    """Tests for scanning a parent directory with nested git repos."""

    @pytest.mark.anyio
    async def test_finds_nested_git_repos(self, tmp_path):
        repo_a = tmp_path / "projects" / "repo-a"
        repo_b = tmp_path / "projects" / "repo-b"
        _make_git_repo(str(repo_a))
        _make_git_repo(str(repo_b))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)

        assert len(result) == 2
        assert os.path.realpath(str(repo_a)) in result
        assert os.path.realpath(str(repo_b)) in result

    @pytest.mark.anyio
    async def test_finds_deeply_nested_repos(self, tmp_path):
        deep = tmp_path / "a" / "b" / "c" / "repo"
        _make_git_repo(str(deep))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
            max_scan_depth=5,
        )
        result = await scan_repositories(config)

        assert len(result) == 1
        assert os.path.realpath(str(deep)) in result

    @pytest.mark.anyio
    async def test_parent_directory_itself_is_repo(self, tmp_path):
        _make_git_repo(str(tmp_path))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)

        assert len(result) == 1
        assert os.path.realpath(str(tmp_path)) in result


class TestExplicitRepositories:
    """Tests for using explicit repository paths."""

    @pytest.mark.anyio
    async def test_resolves_explicit_paths(self, tmp_path):
        repo = tmp_path / "my-repo"
        _make_git_repo(str(repo))

        config = ReportConfiguration(
            author="Dev",
            repositories=[str(repo)],
        )
        result = await scan_repositories(config)

        assert len(result) == 1
        assert os.path.realpath(str(repo)) in result

    @pytest.mark.anyio
    async def test_resolves_relative_paths(self, tmp_path, monkeypatch):
        repo = tmp_path / "my-repo"
        _make_git_repo(str(repo))
        monkeypatch.chdir(tmp_path)

        config = ReportConfiguration(
            author="Dev",
            repositories=["my-repo"],
        )
        result = await scan_repositories(config)

        assert len(result) == 1
        assert os.path.realpath(str(repo)) in result


class TestMergeAndDeduplication:
    """Tests for merging discovered and explicit repos with deduplication."""

    @pytest.mark.anyio
    async def test_merges_parent_and_explicit(self, tmp_path):
        repo_a = tmp_path / "repos" / "repo-a"
        repo_b = tmp_path / "standalone"
        _make_git_repo(str(repo_a))
        _make_git_repo(str(repo_b))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path / "repos"),
            repositories=[str(repo_b)],
        )
        result = await scan_repositories(config)

        assert len(result) == 2
        assert os.path.realpath(str(repo_a)) in result
        assert os.path.realpath(str(repo_b)) in result

    @pytest.mark.anyio
    async def test_deduplicates_same_repo(self, tmp_path):
        repo = tmp_path / "repos" / "my-repo"
        _make_git_repo(str(repo))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
            repositories=[str(repo)],
        )
        result = await scan_repositories(config)

        assert len(result) == 1

    @pytest.mark.anyio
    async def test_result_is_sorted(self, tmp_path):
        for name in ["zebra", "alpha", "middle"]:
            _make_git_repo(str(tmp_path / name))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)

        assert result == sorted(result)


class TestWarningsForInvalidPaths:
    """Tests for warning on invalid/missing paths."""

    @pytest.mark.anyio
    async def test_warns_on_nonexistent_explicit_path(self, tmp_path, caplog):
        config = ReportConfiguration(
            author="Dev",
            repositories=[str(tmp_path / "does-not-exist")],
        )
        with caplog.at_level(logging.WARNING):
            result = await scan_repositories(config)

        assert len(result) == 0
        assert "does not exist" in caplog.text

    @pytest.mark.anyio
    async def test_warns_on_non_git_directory(self, tmp_path, caplog):
        not_a_repo = tmp_path / "just-a-dir"
        not_a_repo.mkdir()

        config = ReportConfiguration(
            author="Dev",
            repositories=[str(not_a_repo)],
        )
        with caplog.at_level(logging.WARNING):
            result = await scan_repositories(config)

        assert len(result) == 0
        assert (
            "not a valid git repository" in caplog.text.lower()
            or "not a git repo" in caplog.text.lower()
        )

    @pytest.mark.anyio
    async def test_warns_on_nonexistent_parent_directory(self, tmp_path, caplog):
        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path / "nope"),
        )
        with caplog.at_level(logging.WARNING):
            result = await scan_repositories(config)

        assert len(result) == 0
        assert (
            "does not exist" in caplog.text.lower()
            or "not a directory" in caplog.text.lower()
        )

    @pytest.mark.anyio
    async def test_continues_after_invalid_path(self, tmp_path, caplog):
        good_repo = tmp_path / "good"
        _make_git_repo(str(good_repo))

        config = ReportConfiguration(
            author="Dev",
            repositories=[
                str(tmp_path / "bad"),
                str(good_repo),
            ],
        )
        with caplog.at_level(logging.WARNING):
            result = await scan_repositories(config)

        assert len(result) == 1
        assert os.path.realpath(str(good_repo)) in result


class TestEmptyResults:
    """Tests for empty results when no repos found."""

    @pytest.mark.anyio
    async def test_empty_parent_no_repos(self, tmp_path):
        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)
        assert result == []

    @pytest.mark.anyio
    async def test_no_sources_configured(self):
        config = ReportConfiguration(author="Dev")
        result = await scan_repositories(config)
        assert result == []

    @pytest.mark.anyio
    async def test_returns_list_type(self, tmp_path):
        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)
        assert isinstance(result, list)


class TestReturnedPathsAreAbsolute:
    """Tests that all returned paths are absolute."""

    @pytest.mark.anyio
    async def test_all_paths_are_absolute(self, tmp_path):
        for name in ["repo1", "repo2"]:
            _make_git_repo(str(tmp_path / name))

        config = ReportConfiguration(
            author="Dev",
            parent_directory=str(tmp_path),
        )
        result = await scan_repositories(config)

        for path in result:
            assert os.path.isabs(path)
