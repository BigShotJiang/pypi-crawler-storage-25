"""Unit tests for the commit grouper module."""

from datetime import datetime, timezone

from work_intelligence.grouper import group_by_weekday
from work_intelligence.models import CommitRecord


def _commit(date_str: str, repo: str = "my-repo", msg: str = "fix stuff") -> CommitRecord:
    """Helper to build a CommitRecord with a given ISO date string."""
    return CommitRecord(
        hash="abc1234",
        author="Alice",
        date=datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc),
        message=msg,
        repository=repo,
    )


class TestGroupByWeekday:
    """Tests for group_by_weekday."""

    def test_empty_list_returns_empty(self):
        assert group_by_weekday([]) == []

    def test_single_commit(self):
        commits = [_commit("2025-01-06T10:00:00")]  # Monday
        groups = group_by_weekday(commits)

        assert len(groups) == 1
        assert groups[0].weekday == "Monday"
        assert groups[0].date == "2025-01-06"
        assert len(groups[0].repos) == 1
        assert groups[0].repos[0].repository == "my-repo"
        assert len(groups[0].repos[0].commits) == 1

    def test_multiple_commits_same_day_same_repo(self):
        commits = [
            _commit("2025-01-06T09:00:00", "repo-a", "first"),
            _commit("2025-01-06T14:00:00", "repo-a", "second"),
        ]
        groups = group_by_weekday(commits)

        assert len(groups) == 1
        assert len(groups[0].repos) == 1
        assert len(groups[0].repos[0].commits) == 2

    def test_multiple_repos_same_day(self):
        commits = [
            _commit("2025-01-06T09:00:00", "repo-a"),
            _commit("2025-01-06T14:00:00", "repo-b"),
        ]
        groups = group_by_weekday(commits)

        assert len(groups) == 1
        assert len(groups[0].repos) == 2
        repo_names = [r.repository for r in groups[0].repos]
        assert repo_names == ["repo-a", "repo-b"]

    def test_multiple_days_chronological_order(self):
        commits = [
            _commit("2025-01-08T10:00:00", "repo-a"),  # Wednesday
            _commit("2025-01-06T10:00:00", "repo-a"),  # Monday
            _commit("2025-01-07T10:00:00", "repo-a"),  # Tuesday
        ]
        groups = group_by_weekday(commits)

        assert len(groups) == 3
        assert [g.date for g in groups] == ["2025-01-06", "2025-01-07", "2025-01-08"]
        assert [g.weekday for g in groups] == ["Monday", "Tuesday", "Wednesday"]

    def test_days_with_no_commits_are_omitted(self):
        # Monday and Wednesday only — Tuesday is skipped
        commits = [
            _commit("2025-01-06T10:00:00"),  # Monday
            _commit("2025-01-08T10:00:00"),  # Wednesday
        ]
        groups = group_by_weekday(commits)

        assert len(groups) == 2
        assert [g.date for g in groups] == ["2025-01-06", "2025-01-08"]

    def test_repos_sorted_alphabetically_within_day(self):
        commits = [
            _commit("2025-01-06T10:00:00", "zebra"),
            _commit("2025-01-06T11:00:00", "alpha"),
            _commit("2025-01-06T12:00:00", "middle"),
        ]
        groups = group_by_weekday(commits)

        repo_names = [r.repository for r in groups[0].repos]
        assert repo_names == ["alpha", "middle", "zebra"]

    def test_commits_assigned_to_correct_repo_group(self):
        commits = [
            _commit("2025-01-06T09:00:00", "repo-a", "a-commit"),
            _commit("2025-01-06T14:00:00", "repo-b", "b-commit"),
        ]
        groups = group_by_weekday(commits)

        repo_a = groups[0].repos[0]
        repo_b = groups[0].repos[1]
        assert repo_a.repository == "repo-a"
        assert repo_a.commits[0].message == "a-commit"
        assert repo_b.repository == "repo-b"
        assert repo_b.commits[0].message == "b-commit"
