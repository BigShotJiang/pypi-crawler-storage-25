"""Unit tests for the markdown renderer module."""

from datetime import datetime, timezone

from work_intelligence.models import (
    CommitRecord,
    DateRange,
    ReportConfiguration,
    SummarizedRepoGroup,
    SummarizedWeekdayGroup,
    SummaryGroup,
)
from work_intelligence.renderer import render_markdown


# --- Helper ---


def _commit(
    message: str,
    hash: str = "abc1234",
    repo: str = "my-repo",
) -> CommitRecord:
    return CommitRecord(
        hash=hash,
        author="Alice",
        date=datetime(2025, 1, 6, 10, 0, tzinfo=timezone.utc),
        message=message,
        repository=repo,
    )


def _config(
    author: str = "Alice",
    start: str = "2025-01-06",
    end: str = "2025-01-12",
) -> ReportConfiguration:
    return ReportConfiguration(
        author=author,
        date_range=DateRange(start=start, end=end),
        parent_directory="/repos",
    )


# --- Tests ---


class TestRenderMarkdownHeader:
    def test_header_contains_author(self):
        md = render_markdown([], _config(), 0)
        assert "# Work Report for Alice" in md

    def test_header_contains_date_range(self):
        md = render_markdown([], _config(), 0)
        assert "2025-01-06 to 2025-01-12" in md

    def test_header_contains_total_commits(self):
        md = render_markdown([], _config(), 5)
        assert "Total commits: 5" in md

    def test_header_no_date_range(self):
        config = ReportConfiguration(author="Bob", parent_directory="/repos")
        md = render_markdown([], config, 0)
        assert "# Work Report for Bob" in md
        assert "to" not in md.split("\n")[0]


class TestRenderMarkdownZeroCommits:
    def test_zero_commits_message(self):
        md = render_markdown([], _config(), 0)
        assert "No commits were found" in md
        assert "Alice" in md

    def test_zero_commits_includes_date_range(self):
        md = render_markdown([], _config(), 0)
        assert "2025-01-06 to 2025-01-12" in md


class TestRenderMarkdownDayHeadings:
    def test_day_heading_format(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[SummaryGroup(
                    prefix="feat",
                    commits=[_commit("feat: login")],
                    is_summarized=False,
                )],
            )],
        )
        md = render_markdown([day], _config(), 1)
        assert "## Monday — 2025-01-06" in md


class TestRenderMarkdownRepoHeadings:
    def test_repo_heading(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="cool-project",
                groups=[SummaryGroup(
                    prefix="feat",
                    commits=[_commit("feat: login")],
                    is_summarized=False,
                )],
            )],
        )
        md = render_markdown([day], _config(), 1)
        assert "### cool-project" in md

    def test_multiple_repos(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[
                SummarizedRepoGroup(
                    repository="repo-a",
                    groups=[SummaryGroup(
                        prefix="feat",
                        commits=[_commit("feat: x", repo="repo-a")],
                        is_summarized=False,
                    )],
                ),
                SummarizedRepoGroup(
                    repository="repo-b",
                    groups=[SummaryGroup(
                        prefix="fix",
                        commits=[_commit("fix: y", repo="repo-b")],
                        is_summarized=False,
                    )],
                ),
            ],
        )
        md = render_markdown([day], _config(), 2)
        assert "### repo-a" in md
        assert "### repo-b" in md


class TestRenderMarkdownNonSummarized:
    def test_commit_format(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[SummaryGroup(
                    prefix="feat",
                    commits=[_commit("feat: add login", hash="a1b2c3d")],
                    is_summarized=False,
                )],
            )],
        )
        md = render_markdown([day], _config(), 1)
        assert "- `a1b2c3d` feat: add login" in md

    def test_two_commits_not_summarized(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[SummaryGroup(
                    prefix="fix",
                    commits=[
                        _commit("fix: typo A", hash="1111111"),
                        _commit("fix: typo B", hash="2222222"),
                    ],
                    is_summarized=False,
                )],
            )],
        )
        md = render_markdown([day], _config(), 2)
        assert "- `1111111` fix: typo A" in md
        assert "- `2222222` fix: typo B" in md
        # Should NOT have summary line
        assert "commits)" not in md


class TestRenderMarkdownSummarized:
    def test_summary_line_with_count(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[SummaryGroup(
                    prefix="fix",
                    commits=[
                        _commit("fix: typo A", hash="1111111"),
                        _commit("fix: typo B", hash="2222222"),
                        _commit("fix: typo C", hash="3333333"),
                    ],
                    is_summarized=True,
                )],
            )],
        )
        md = render_markdown([day], _config(), 3)
        assert "**fix** (3 commits)" in md

    def test_sub_items_indented(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[SummaryGroup(
                    prefix="fix",
                    commits=[
                        _commit("fix: typo A", hash="1111111"),
                        _commit("fix: typo B", hash="2222222"),
                        _commit("fix: typo C", hash="3333333"),
                    ],
                    is_summarized=True,
                )],
            )],
        )
        md = render_markdown([day], _config(), 3)
        assert "  - `1111111` fix: typo A" in md
        assert "  - `2222222` fix: typo B" in md
        assert "  - `3333333` fix: typo C" in md


class TestRenderMarkdownMultipleDays:
    def test_multiple_days(self):
        days = [
            SummarizedWeekdayGroup(
                weekday="Monday",
                date="2025-01-06",
                repos=[SummarizedRepoGroup(
                    repository="r",
                    groups=[SummaryGroup(
                        prefix="a",
                        commits=[_commit("a: work")],
                        is_summarized=False,
                    )],
                )],
            ),
            SummarizedWeekdayGroup(
                weekday="Tuesday",
                date="2025-01-07",
                repos=[SummarizedRepoGroup(
                    repository="r",
                    groups=[SummaryGroup(
                        prefix="b",
                        commits=[_commit("b: more work")],
                        is_summarized=False,
                    )],
                )],
            ),
        ]
        md = render_markdown(days, _config(), 2)
        assert "## Monday — 2025-01-06" in md
        assert "## Tuesday — 2025-01-07" in md
        # Monday should appear before Tuesday
        assert md.index("Monday") < md.index("Tuesday")


class TestRenderMarkdownMixedGroups:
    def test_summarized_and_non_summarized_in_same_repo(self):
        day = SummarizedWeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[SummarizedRepoGroup(
                repository="my-repo",
                groups=[
                    SummaryGroup(
                        prefix="feat",
                        commits=[
                            _commit("feat: login", hash="aaa1111"),
                            _commit("feat: signup", hash="aaa2222"),
                        ],
                        is_summarized=False,
                    ),
                    SummaryGroup(
                        prefix="fix",
                        commits=[
                            _commit("fix: typo A", hash="bbb1111"),
                            _commit("fix: typo B", hash="bbb2222"),
                            _commit("fix: typo C", hash="bbb3333"),
                        ],
                        is_summarized=True,
                    ),
                ],
            )],
        )
        md = render_markdown([day], _config(), 5)
        # Non-summarized commits rendered directly
        assert "- `aaa1111` feat: login" in md
        assert "- `aaa2222` feat: signup" in md
        # Summarized group has summary line + sub-items
        assert "**fix** (3 commits)" in md
        assert "  - `bbb1111` fix: typo A" in md
