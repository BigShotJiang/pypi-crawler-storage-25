"""Shared Hypothesis strategies and pytest fixtures for Work Intelligence Agent tests."""

from datetime import datetime, timezone

from hypothesis import strategies as st

from work_intelligence.models import (
    CommitRecord,
    DateRange,
    RepoGroup,
    ReportConfiguration,
    SummarizedRepoGroup,
    SummarizedWeekdayGroup,
    SummaryGroup,
    WeekdayGroup,
)

# --- Primitive strategies ---

author_names = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "Nd", "Zs"),
        whitelist_characters="-_.",
    ),
    min_size=1,
    max_size=40,
).filter(lambda s: s.strip())

repo_names = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "Nd"),
        whitelist_characters="-_",
    ),
    min_size=1,
    max_size=30,
).filter(lambda s: s.strip())

commit_hashes = st.text(
    alphabet="0123456789abcdef",
    min_size=7,
    max_size=7,
)

commit_messages = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "Nd", "Zs", "P"),
        whitelist_characters=": -_",
    ),
    min_size=1,
    max_size=120,
).filter(lambda s: s.strip() and "|" not in s and "\n" not in s)

directory_paths = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "Nd"),
        whitelist_characters="/-_",
    ),
    min_size=1,
    max_size=60,
).filter(lambda s: s.strip())

# --- Date strategies ---

_min_date = datetime(2020, 1, 1).date()
_max_date = datetime(2030, 12, 31).date()

iso_dates = st.dates(
    min_value=_min_date, max_value=_max_date
).map(lambda d: d.isoformat())

aware_datetimes = st.datetimes(
    min_value=datetime(2020, 1, 1),
    max_value=datetime(2030, 12, 31),
    timezones=st.just(timezone.utc),
)


# --- Composite strategies ---


@st.composite
def date_ranges(draw):
    """Generate a valid DateRange where start <= end."""
    d1 = draw(st.dates(min_value=_min_date, max_value=_max_date))
    d2 = draw(st.dates(min_value=_min_date, max_value=_max_date))
    start, end = sorted([d1, d2])
    return DateRange(start=start.isoformat(), end=end.isoformat())


@st.composite
def commit_records(draw, repository=None, date=None):
    """Generate a CommitRecord with optional fixed repo or date."""
    return CommitRecord(
        hash=draw(commit_hashes),
        author=draw(author_names),
        date=date if date is not None else draw(aware_datetimes),
        message=draw(commit_messages),
        repository=(
            repository if repository is not None
            else draw(repo_names)
        ),
    )


@st.composite
def report_configurations(draw, valid=True):
    """Generate a ReportConfiguration.

    If valid=True, ensures author and at least one repo source.
    """
    if valid:
        author = draw(author_names)
    else:
        author = draw(st.one_of(st.just(""), author_names))
    parent_dir = draw(st.one_of(st.none(), directory_paths))
    repos = draw(st.one_of(
        st.none(),
        st.lists(directory_paths, min_size=1, max_size=5),
    ))
    if valid and parent_dir is None and repos is None:
        parent_dir = draw(directory_paths)
    dr = draw(st.one_of(st.none(), date_ranges()))
    output = draw(st.one_of(st.none(), directory_paths))
    return ReportConfiguration(
        author=author,
        parent_directory=parent_dir,
        repositories=repos,
        date_range=dr,
        output_path=output,
    )


@st.composite
def repo_groups(draw, min_commits=1, max_commits=5):
    """Generate a RepoGroup with commits sharing a repo name."""
    repo = draw(repo_names)
    commits = draw(st.lists(
        commit_records(repository=repo),
        min_size=min_commits,
        max_size=max_commits,
    ))
    return RepoGroup(repository=repo, commits=commits)


@st.composite
def weekday_groups(draw, min_repos=1, max_repos=3):
    """Generate a WeekdayGroup with a consistent date/weekday."""
    d = draw(st.dates(min_value=_min_date, max_value=_max_date))
    weekday = d.strftime("%A")
    repos = draw(st.lists(
        repo_groups(), min_size=min_repos, max_size=max_repos,
    ))
    return WeekdayGroup(
        weekday=weekday, date=d.isoformat(), repos=repos,
    )


@st.composite
def summary_groups(draw, min_commits=1, max_commits=6):
    """Generate a SummaryGroup."""
    prefix = draw(commit_messages)
    commits = draw(st.lists(
        commit_records(),
        min_size=min_commits,
        max_size=max_commits,
    ))
    is_summarized = len(commits) >= 3
    return SummaryGroup(
        prefix=prefix, commits=commits, is_summarized=is_summarized,
    )


@st.composite
def summarized_repo_groups(draw):
    """Generate a SummarizedRepoGroup."""
    repo = draw(repo_names)
    groups = draw(st.lists(summary_groups(), min_size=1, max_size=4))
    return SummarizedRepoGroup(repository=repo, groups=groups)


@st.composite
def summarized_weekday_groups(draw):
    """Generate a SummarizedWeekdayGroup."""
    d = draw(st.dates(min_value=_min_date, max_value=_max_date))
    weekday = d.strftime("%A")
    repos = draw(st.lists(
        summarized_repo_groups(), min_size=1, max_size=3,
    ))
    return SummarizedWeekdayGroup(
        weekday=weekday, date=d.isoformat(), repos=repos,
    )
