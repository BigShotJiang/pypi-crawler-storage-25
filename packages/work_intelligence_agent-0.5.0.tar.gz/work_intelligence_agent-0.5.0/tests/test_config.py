"""Unit tests for configuration loading and validation."""

from __future__ import annotations

import json
import os
from datetime import date, timedelta

import pytest

from work_intelligence.config import load_configuration
from work_intelligence.models import DateRange, ReportConfiguration


class TestLoadConfigurationFromFile:
    """Tests for reading config from a JSON file."""

    def test_loads_from_json_file(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "author": "Alice",
            "parent_directory": "/repos",
        }))
        result = load_configuration(str(config_file), {})
        assert result.author == "Alice"
        assert result.parent_directory == "/repos"

    def test_ignores_missing_file(self):
        result = load_configuration(
            "/nonexistent/path/config.json",
            {"author": "Bob", "repositories": ["/repo1"]},
        )
        assert result.author == "Bob"
        assert result.repositories == ["/repo1"]

    def test_malformed_json_raises(self, tmp_path):
        config_file = tmp_path / "bad.json"
        config_file.write_text("{not valid json")
        with pytest.raises(json.JSONDecodeError):
            load_configuration(str(config_file), {"author": "X", "repositories": ["/r"]})


class TestCLIMerge:
    """Tests for CLI args overriding file values."""

    def test_cli_overrides_file_values(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "author": "FileAuthor",
            "parent_directory": "/file/dir",
        }))
        result = load_configuration(str(config_file), {
            "author": "CLIAuthor",
        })
        assert result.author == "CLIAuthor"
        assert result.parent_directory == "/file/dir"

    def test_cli_none_does_not_override(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "author": "FileAuthor",
            "parent_directory": "/file/dir",
        }))
        result = load_configuration(str(config_file), {
            "author": None,
            "parent_directory": None,
        })
        assert result.author == "FileAuthor"
        assert result.parent_directory == "/file/dir"

    def test_cli_only_no_file(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/my/repo"],
        })
        assert result.author == "Dev"
        assert result.repositories == ["/my/repo"]


class TestAuthorValidation:
    """Tests for author validation."""

    def test_missing_author_raises(self):
        with pytest.raises(ValueError, match="author"):
            load_configuration("/no/file.json", {
                "repositories": ["/repo"],
            })

    def test_empty_author_raises(self):
        with pytest.raises(ValueError, match="author"):
            load_configuration("/no/file.json", {
                "author": "",
                "repositories": ["/repo"],
            })

    def test_whitespace_only_author_raises(self):
        with pytest.raises(ValueError, match="author"):
            load_configuration("/no/file.json", {
                "author": "   ",
                "repositories": ["/repo"],
            })


class TestRepoSourceValidation:
    """Tests for repository source validation."""

    def test_no_repo_source_raises(self):
        with pytest.raises(ValueError, match="parent_directory or repositories"):
            load_configuration("/no/file.json", {"author": "Dev"})

    def test_parent_directory_only_is_valid(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "parent_directory": "/repos",
        })
        assert result.parent_directory == "/repos"
        assert result.repositories is None

    def test_repositories_only_is_valid(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo1"],
        })
        assert result.parent_directory is None
        assert result.repositories == ["/repo1"]

    def test_both_sources_is_valid(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "parent_directory": "/repos",
            "repositories": ["/repo1"],
        })
        assert result.parent_directory == "/repos"
        assert result.repositories == ["/repo1"]


class TestDateRangeDefaults:
    """Tests for date range defaulting and validation."""

    def test_defaults_to_last_7_days(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo"],
        })
        today = date.today()
        expected_start = (today - timedelta(days=7)).isoformat()
        expected_end = today.isoformat()
        assert result.date_range is not None
        assert result.date_range.start == expected_start
        assert result.date_range.end == expected_end

    def test_explicit_date_range_preserved(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo"],
            "date_range": {"start": "2025-01-01", "end": "2025-01-07"},
        })
        assert result.date_range.start == "2025-01-01"
        assert result.date_range.end == "2025-01-07"

    def test_start_after_end_raises(self):
        with pytest.raises(ValueError, match="start date"):
            load_configuration("/no/file.json", {
                "author": "Dev",
                "repositories": ["/repo"],
                "date_range": {"start": "2025-01-10", "end": "2025-01-01"},
            })

    def test_same_start_and_end_is_valid(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo"],
            "date_range": {"start": "2025-01-05", "end": "2025-01-05"},
        })
        assert result.date_range.start == "2025-01-05"
        assert result.date_range.end == "2025-01-05"

    def test_date_range_as_dataclass(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo"],
            "date_range": DateRange(start="2025-03-01", end="2025-03-15"),
        })
        assert result.date_range.start == "2025-03-01"
        assert result.date_range.end == "2025-03-15"


class TestReturnType:
    """Tests for the returned ReportConfiguration."""

    def test_returns_report_configuration(self):
        result = load_configuration("/no/file.json", {
            "author": "Dev",
            "repositories": ["/repo"],
        })
        assert isinstance(result, ReportConfiguration)

    def test_output_path_passed_through(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({
            "author": "Dev",
            "repositories": ["/repo"],
            "output_path": "/out/report.md",
        }))
        result = load_configuration(str(config_file), {})
        assert result.output_path == "/out/report.md"

    def test_author_is_stripped(self):
        result = load_configuration("/no/file.json", {
            "author": "  Dev  ",
            "repositories": ["/repo"],
        })
        assert result.author == "Dev"
