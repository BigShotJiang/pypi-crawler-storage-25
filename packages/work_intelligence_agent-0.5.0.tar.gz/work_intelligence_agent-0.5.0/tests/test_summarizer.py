"""Unit tests for the commit summarizer module."""

from datetime import datetime, timezone

from work_intelligence.models import (
    CommitRecord,
    RepoGroup,
    WeekdayGroup,
)
from work_intelligence.summarizer import extract_prefix, summarize_commits


# --- Helper ---

def _commit(message: str, repo: str = "my-repo") -> CommitRecord:
    return CommitRecord(
        hash="abc1234",
        author="Alice",
        date=datetime(2025, 1, 6, 10, 0, tzinfo=timezone.utc),
        message=message,
        repository=repo,
    )


# --- extract_prefix tests ---


class TestExtractPrefix:
    def test_colon_within_50(self):
        assert extract_prefix("feat: add login") == "feat"

    def test_colon_at_start(self):
        assert extract_prefix(": something") == ""

    def test_no_colon_short_message(self):
        assert extract_prefix("short msg") == "short msg"

    def test_no_colon_long_message(self):
        msg = "a" * 80
        assert extract_prefix(msg) == "a" * 50

    def test_colon_after_50_chars(self):
        # Colon at position 55 — beyond the 50-char window
        msg = "a" * 55 + ": rest"
        assert extract_prefix(msg) == "a" * 50

    def test_colon_exactly_at_50(self):
        # 50 chars then colon — colon is at index 50, outside [:50]
        msg = "a" * 50 + ": rest"
        assert extract_prefix(msg) == "a" * 50

    def test_colon_at_49(self):
        # 49 chars then colon — colon is at index 49, inside [:50]
        msg = "a" * 49 + ": rest"
        assert extract_prefix(msg) == "a" * 49

    def test_empty_message(self):
        assert extract_prefix("") == ""

    def test_multiple_colons(self):
        assert extract_prefix("fix: scope: detail") == "fix"

    def test_exactly_50_chars_no_colon(self):
        msg = "b" * 50
        assert extract_prefix(msg) == msg


# --- summarize_commits tests ---


class TestSummarizeCommits:
    def test_empty_input(self):
        assert summarize_commits([]) == []

    def test_single_commit_not_summarized(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[_commit("feat: add login")],
            )],
        )
        result = summarize_commits([wg])
        assert len(result) == 1
        assert len(result[0].repos) == 1
        groups = result[0].repos[0].groups
        assert len(groups) == 1
        assert groups[0].is_summarized is False
        assert len(groups[0].commits) == 1

    def test_two_same_prefix_not_summarized(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[
                    _commit("fix: typo in readme"),
                    _commit("fix: typo in docs"),
                ],
            )],
        )
        result = summarize_commits([wg])
        groups = result[0].repos[0].groups
        assert len(groups) == 1
        assert groups[0].is_summarized is False
        assert groups[0].prefix == "fix"

    def test_three_same_prefix_summarized(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[
                    _commit("fix: typo A"),
                    _commit("fix: typo B"),
                    _commit("fix: typo C"),
                ],
            )],
        )
        result = summarize_commits([wg])
        groups = result[0].repos[0].groups
        assert len(groups) == 1
        assert groups[0].is_summarized is True
        assert len(groups[0].commits) == 3

    def test_mixed_prefixes(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[
                    _commit("feat: login"),
                    _commit("fix: typo A"),
                    _commit("fix: typo B"),
                    _commit("fix: typo C"),
                    _commit("feat: signup"),
                ],
            )],
        )
        result = summarize_commits([wg])
        groups = result[0].repos[0].groups
        # Two prefix groups: "feat" (2 commits, not summarized) and "fix" (3, summarized)
        prefixes = {g.prefix.lower(): g for g in groups}
        assert prefixes["feat"].is_summarized is False
        assert len(prefixes["feat"].commits) == 2
        assert prefixes["fix"].is_summarized is True
        assert len(prefixes["fix"].commits) == 3

    def test_case_insensitive_prefix_grouping(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[
                    _commit("Fix: issue 1"),
                    _commit("fix: issue 2"),
                    _commit("FIX: issue 3"),
                ],
            )],
        )
        result = summarize_commits([wg])
        groups = result[0].repos[0].groups
        assert len(groups) == 1
        assert groups[0].is_summarized is True

    def test_preserves_weekday_and_date(self):
        wg = WeekdayGroup(
            weekday="Tuesday",
            date="2025-01-07",
            repos=[RepoGroup(
                repository="my-repo",
                commits=[_commit("chore: cleanup")],
            )],
        )
        result = summarize_commits([wg])
        assert result[0].weekday == "Tuesday"
        assert result[0].date == "2025-01-07"

    def test_preserves_repository_name(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[RepoGroup(
                repository="cool-project",
                commits=[_commit("docs: update", repo="cool-project")],
            )],
        )
        result = summarize_commits([wg])
        assert result[0].repos[0].repository == "cool-project"

    def test_multiple_repos_in_one_day(self):
        wg = WeekdayGroup(
            weekday="Monday",
            date="2025-01-06",
            repos=[
                RepoGroup(repository="repo-a", commits=[
                    _commit("feat: x", repo="repo-a"),
                ]),
                RepoGroup(repository="repo-b", commits=[
                    _commit("fix: y", repo="repo-b"),
                ]),
            ],
        )
        result = summarize_commits([wg])
        assert len(result[0].repos) == 2
        assert result[0].repos[0].repository == "repo-a"
        assert result[0].repos[1].repository == "repo-b"

    def test_multiple_weekday_groups(self):
        groups = [
            WeekdayGroup(
                weekday="Monday", date="2025-01-06",
                repos=[RepoGroup(repository="r", commits=[_commit("a")])],
            ),
            WeekdayGroup(
                weekday="Tuesday", date="2025-01-07",
                repos=[RepoGroup(repository="r", commits=[_commit("b")])],
            ),
        ]
        result = summarize_commits(groups)
        assert len(result) == 2
        assert result[0].weekday == "Monday"
        assert result[1].weekday == "Tuesday"
