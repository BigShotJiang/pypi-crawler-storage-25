# Work Intelligence Agent — Steering Guide

## Overview

The Work Intelligence Agent generates weekly work reports from git history. Use it to produce markdown summaries of what a developer worked on across multiple repositories.

## When to Use

- A user asks for a summary of their recent work or commits
- A user wants a weekly status report or standup notes
- A user needs to see what they worked on across multiple repos

## Typical Workflow

1. **Discover repos** — If the user has a workspace with multiple repos, use `scan_repos` with the parent directory to find them.
2. **Generate report** — Call `generate_report` with the author name and either a `parent_directory` or explicit `repositories` list. The tool handles scanning, extraction, grouping, summarization, and rendering in one call.
3. **Present the report** — The output is a markdown string. Display it directly or save it to a file.

## Tool Selection

| Goal | Tool |
|------|------|
| Full weekly report | `generate_report` |
| List repos in a directory | `scan_repos` |
| Raw commit data only | `extract_history` |

Use `generate_report` for most requests. Use `scan_repos` or `extract_history` when the user only needs part of the pipeline.

## Parameter Guidance

- **author**: Use the git author name (e.g., `"Jane Doe"`). The match is case-insensitive substring.
- **parent_directory**: An absolute path to a directory containing git repos. The scanner walks subdirectories recursively.
- **repositories**: A list of absolute paths to specific git repos. Use this when the user names exact repos.
- **start_date / end_date**: ISO 8601 date strings (`YYYY-MM-DD`). If omitted, defaults to the last 7 days.

## Tips

- If the user doesn't specify a date range, the default (last 7 days) is usually what they want.
- If the user provides a workspace root, pass it as `parent_directory` — the scanner will find nested repos automatically.
- The report groups commits by weekday and summarizes similar commit messages, so the output stays concise even with many commits.
- For large directory trees, `scan_repos` can be called first to confirm which repos will be included.
