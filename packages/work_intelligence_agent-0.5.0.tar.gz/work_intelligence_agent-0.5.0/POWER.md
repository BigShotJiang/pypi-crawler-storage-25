# Work Intelligence Agent

Generate weekly work reports by scanning git history across multiple repositories — with optional AI-powered summaries via Google Gemini.

## What It Does

The Work Intelligence Agent automates weekly work reporting. Point it at a parent directory (or list of repos), and it will:

- Discover git repositories recursively
- Extract commit history filtered by author and date range
- Group commits by weekday and repository
- Summarize similar commits together
- **Optionally generate AI summaries** for commit clusters using Gemini
- Produce a clean markdown report

## AI Summarization

When `GEMINI_API_KEY` is set in the MCP server environment, groups of 3+ related commits get an AI-generated one-line summary. Without the key, the agent falls back to prefix-based grouping — no errors, no disruption.

## Tools

### `generate_report`

Generate a full weekly work report as markdown. The tool will prompt you for any missing details.

**Parameters:**
- `author` (string, required) — Author name for filtering commits. Ask the user for their git author name.
- `parent_directory` (string, optional) — Directory to scan for git repos. Ask the user where their repos are.
- `repositories` (list of strings, optional) — Explicit list of repo paths
- `start_date` (string, optional) — Start date in YYYY-MM-DD format (defaults to 7 days ago)
- `end_date` (string, optional) — End date in YYYY-MM-DD format (defaults to today)
- `output_path` (string, optional) — File path to save the report (e.g. `report.md`). Ask the user if they want to save it.

### `scan_repos`

Discover git repositories under a directory.

**Parameters:**
- `parent_directory` (string, required) — Directory to scan recursively for git repos

### `extract_history`

Extract commit history from specified repositories.

**Parameters:**
- `repo_paths` (list of strings, required) — Paths to git repositories
- `author` (string, required) — Author name for filtering commits
- `start_date` (string, optional) — Start date in YYYY-MM-DD format (defaults to 7 days ago)
- `end_date` (string, optional) — End date in YYYY-MM-DD format (defaults to today)

## Installation

This power requires Python 3.11+ and `git` available on your PATH.

Install and run via `uvx`:

```bash
uvx work-intelligence-agent
```

## MCP Server Configuration

Add the following to your MCP client configuration:

```json
{
  "mcpServers": {
    "work-intelligence-agent": {
      "command": "uvx",
      "args": ["--from", "work-intelligence-agent", "work-intelligence-mcp"],
      "env": {
        "GEMINI_API_KEY": "your-gemini-api-key"
      }
    }
  }
}
```

Get a free Gemini API key at [Google AI Studio](https://aistudio.google.com/apikey).

The `GEMINI_API_KEY` is optional — the agent works without it, just without AI summaries.
