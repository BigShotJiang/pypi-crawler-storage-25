# Requirements Document

## Introduction

The Work Intelligence Agent is a Kiro-native tool that automates weekly work reporting by scanning git history across multiple repositories. Given a parent directory or explicit list of repository paths, the agent discovers git repositories, extracts commit history for a configured author and date range, groups commits by weekday, and produces a clean markdown report. The goal is a repeatable, automated solution that replaces manual repo-by-repo inspection.

## Glossary

- **Agent**: The Work Intelligence Agent system that orchestrates repository scanning, git history extraction, and report generation
- **Repository_Scanner**: The component responsible for discovering git repositories within a given directory tree or from an explicit list of paths
- **History_Extractor**: The component responsible for running git log queries filtered by author and date range against discovered repositories
- **Report_Generator**: The component responsible for grouping, formatting, and outputting the final markdown report
- **Commit_Record**: A structured representation of a single git commit containing hash, author, date, repository name, and commit message
- **Report_Configuration**: The user-provided settings including author name, date range, repository paths or parent directory, and output preferences
- **Parent_Directory**: A filesystem directory that may contain one or more git repositories as immediate or nested subdirectories
- **Date_Range**: A start date and end date defining the window of git history to scan, defaulting to the last 7 days

## Requirements

### Requirement 1: Repository Discovery

**User Story:** As a developer, I want the agent to automatically find all git repositories in a parent directory, so that I don't have to specify each repo manually.

#### Acceptance Criteria

1. WHEN a parent directory path is provided, THE Repository_Scanner SHALL recursively search for directories containing a `.git` folder
2. WHEN an explicit list of repository paths is provided, THE Repository_Scanner SHALL use those paths directly without recursive scanning
3. WHEN both a parent directory and an explicit list are provided, THE Repository_Scanner SHALL merge discovered repositories with the explicit list and remove duplicates
4. IF a provided path does not exist on the filesystem, THEN THE Repository_Scanner SHALL log a warning identifying the invalid path and continue scanning remaining paths
5. IF a provided path exists but is not a valid git repository, THEN THE Repository_Scanner SHALL log a warning identifying the non-repository path and exclude it from results
6. THE Repository_Scanner SHALL return a deduplicated list of valid git repository absolute paths

### Requirement 2: Git History Extraction

**User Story:** As a developer, I want the agent to extract my commits from all discovered repositories filtered by my author name and a date range, so that I can see what I worked on.

#### Acceptance Criteria

1. WHEN a list of valid repository paths is provided, THE History_Extractor SHALL run a git log query against each repository
2. THE History_Extractor SHALL filter commits by the author name specified in the Report_Configuration using a case-insensitive substring match against the git author field
3. THE History_Extractor SHALL filter commits to only include those within the Date_Range specified in the Report_Configuration
4. WHEN no Date_Range is specified, THE History_Extractor SHALL default to the last 7 days from the current date
5. THE History_Extractor SHALL extract the commit hash (short form), author name, commit date, commit message, and source repository name for each matching commit
6. IF a repository is inaccessible or the git log command fails for a repository, THEN THE History_Extractor SHALL log a warning identifying the failed repository and continue processing remaining repositories
7. THE History_Extractor SHALL return a list of Commit_Records sorted by commit date in ascending order

### Requirement 3: Commit Grouping by Weekday

**User Story:** As a developer, I want my commits grouped by day of the week, so that I can see my daily work pattern at a glance.

#### Acceptance Criteria

1. WHEN a list of Commit_Records is provided, THE Report_Generator SHALL group commits by the day of the week (Monday through Sunday) based on the commit date
2. THE Report_Generator SHALL order the weekday groups chronologically starting from Monday
3. WHEN multiple commits from different repositories fall on the same day, THE Report_Generator SHALL sub-group those commits by repository name within the day group
4. WHEN a day within the Date_Range has no commits, THE Report_Generator SHALL omit that day from the output

### Requirement 4: Markdown Report Generation

**User Story:** As a developer, I want a clean markdown-formatted report of my weekly work, so that I can share it in standups, status updates, or documentation.

#### Acceptance Criteria

1. THE Report_Generator SHALL produce output in valid markdown format
2. THE Report_Generator SHALL include a report header containing the author name, date range, and total number of commits
3. THE Report_Generator SHALL render each weekday group as a second-level heading (e.g., `## Monday — 2025-01-06`)
4. THE Report_Generator SHALL render each repository within a day group as a third-level heading with the repository name
5. THE Report_Generator SHALL render each commit as a list item containing the short commit hash and commit message
6. WHEN the report contains zero commits across all repositories, THE Report_Generator SHALL produce a report stating that no commits were found for the given author and date range

### Requirement 5: Report Configuration

**User Story:** As a developer, I want to configure the author name, date range, and repository locations, so that the agent works for my specific setup.

#### Acceptance Criteria

1. THE Agent SHALL accept a Report_Configuration specifying the author name as a required field
2. THE Agent SHALL accept an optional parent directory path in the Report_Configuration
3. THE Agent SHALL accept an optional list of explicit repository paths in the Report_Configuration
4. IF neither a parent directory nor an explicit repository list is provided, THEN THE Agent SHALL report an error indicating that at least one repository source is required
5. THE Agent SHALL accept an optional Date_Range in the Report_Configuration with start and end dates
6. WHEN no Date_Range is provided, THE Agent SHALL default to the last 7 days ending on the current date
7. THE Agent SHALL accept an optional output file path in the Report_Configuration for writing the report to disk
8. WHEN no output file path is provided, THE Agent SHALL output the report to standard output

### Requirement 6: Commit Summarization

**User Story:** As a developer, I want similar commits to be summarized together, so that the report is concise and highlights themes rather than listing every trivial commit.

#### Acceptance Criteria

1. WHEN multiple commits within the same repository and same day share similar commit messages, THE Report_Generator SHALL group those commits under a single summary line with a count
2. THE Report_Generator SHALL determine similarity by comparing commit message prefixes up to the first colon or first 50 characters, whichever is shorter
3. WHEN a summary group contains 3 or more commits, THE Report_Generator SHALL display the group as a single summary line followed by an expandable list of individual commits
4. WHEN a summary group contains fewer than 3 commits, THE Report_Generator SHALL display each commit individually without summarization

### Requirement 7: Kiro-Native Execution

**User Story:** As a Kiro user, I want to invoke the work intelligence agent as a repeatable Kiro command, so that I can generate reports without leaving my development environment.

#### Acceptance Criteria

1. THE Agent SHALL be implementable as a Kiro-compatible tool or script that can be invoked from within the Kiro environment
2. THE Agent SHALL read its Report_Configuration from a configuration file (e.g., `.kiro/work-intelligence.json`) when present in the workspace
3. WHEN a configuration file is present, THE Agent SHALL use those settings as defaults that can be overridden by command-line arguments
4. THE Agent SHALL provide a single entry-point command that performs the full workflow: discover repositories, extract history, and generate the report
