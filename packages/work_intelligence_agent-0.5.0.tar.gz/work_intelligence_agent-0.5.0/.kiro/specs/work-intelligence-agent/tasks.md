# Implementation Plan: Work Intelligence Agent

## Overview

Build a Python CLI tool that scans git history across multiple repositories and generates a weekly markdown work report. Implementation follows the pipeline architecture: config → scan → extract → group → summarize → render. Layer 1 delivers the CLI tool; Layer 2 wraps it as an MCP server for Kiro Power distribution.

## Tasks

- [x] 1. Set up project structure and shared data models
  - [x] 1.1 Create `pyproject.toml` with package metadata, dependencies (`fastmcp`), entry points (`work-intelligence` → `work_intelligence.cli:main`, `work-intelligence-mcp` → `work_intelligence.server:main`), and test dependencies (`pytest`, `hypothesis`)
    - Create `src/work_intelligence/__init__.py`
    - Create `tests/__init__.py` and `tests/conftest.py` with shared Hypothesis strategies for `CommitRecord`, `ReportConfiguration`, `DateRange`, `WeekdayGroup`, `RepoGroup`, `SummaryGroup`
    - _Requirements: 7.1_

  - [x] 1.2 Implement shared data models in `src/work_intelligence/models.py`
    - Define `DateRange` dataclass with `start: str` and `end: str` (ISO 8601)
    - Define `ReportConfiguration` dataclass with `author`, `parent_directory`, `repositories`, `date_range`, `output_path`
    - Define `CommitRecord` dataclass with `hash`, `author`, `date` (datetime), `message`, `repository`
    - Define `RepoGroup` dataclass with `repository` and `commits`
    - Define `WeekdayGroup` dataclass with `weekday`, `date`, `repos`
    - Define `SummaryGroup`, `SummarizedRepoGroup`, `SummarizedWeekdayGroup` dataclasses
    - _Requirements: 2.5, 3.1, 6.1_

- [x] 2. Implement configuration loading and validation
  - [x] 2.1 Implement `load_configuration` in `src/work_intelligence/config.py`
    - Read JSON from config file path if it exists, ignore if missing
    - Merge CLI args on top of file values (CLI wins)
    - Validate `author` is present and non-empty, raise `ValueError` if not
    - Validate at least one of `parent_directory` or `repositories` is provided, raise `ValueError` if not
    - Default `date_range` to last 7 days from current date if not specified
    - Raise `ValueError` if start date > end date
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 7.2, 7.3_

  - [ ]* 2.2 Write property test: configuration validation rejects invalid configs
    - **Property 8: Configuration validation rejects invalid configs**
    - **Validates: Requirements 5.1, 5.4**

  - [ ]* 2.3 Write property test: CLI overrides file defaults
    - **Property 11: Configuration merge — CLI overrides file defaults**
    - **Validates: Requirements 7.2, 7.3**

- [x] 3. Implement repository scanner
  - [x] 3.1 Implement `scan_repositories` in `src/work_intelligence/scanner.py`
    - Recursively walk `parent_directory` using `os.walk` to find `.git` directories
    - Resolve explicit `repositories` to absolute paths via `os.path.realpath`
    - Merge discovered and explicit repos, deduplicate by absolute path
    - Verify each candidate has a `.git` directory; log warnings for invalid/missing paths
    - Return sorted, deduplicated list of absolute paths
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

  - [ ]* 3.2 Write property test: scanner produces deduplicated absolute paths
    - **Property 1: Repository scanner produces deduplicated absolute paths**
    - **Validates: Requirements 1.3, 1.6**

- [x] 4. Implement history extractor
  - [x] 4.1 Implement `extract_history`, `parse_git_log_line`, and `format_git_log_line` in `src/work_intelligence/extractor.py`
    - Run `subprocess.run` with `git log --format=%h|%an|%aI|%s --after=... --before=... --author=...` per repo
    - Set `cwd` to repo path, `capture_output=True`, `text=True`, `timeout=30`
    - Parse each output line into `CommitRecord` via `parse_git_log_line`
    - Log warnings and continue on subprocess failure or unparseable lines
    - Return all commits sorted by date ascending
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_

  - [ ]* 4.2 Write property test: git log line parsing round trip
    - **Property 3: Git log line parsing round trip**
    - **Validates: Requirements 2.5**

  - [ ]* 4.3 Write property test: extracted commits sorted by date ascending
    - **Property 4: Extracted commits are sorted by date ascending**
    - **Validates: Requirements 2.7**

  - [ ]* 4.4 Write property test: all returned commits match author and date filters
    - **Property 2: All returned commits match author and date filters**
    - **Validates: Requirements 2.2, 2.3**

- [x] 5. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Implement commit grouper
  - [x] 6.1 Implement `group_by_weekday` in `src/work_intelligence/grouper.py`
    - Group commits by calendar date, then by repository within each date
    - Order groups chronologically (ascending date)
    - Omit days with zero commits
    - Each `WeekdayGroup` contains weekday name and date string
    - _Requirements: 3.1, 3.2, 3.3, 3.4_

  - [ ]* 6.2 Write property test: commits grouped into correct weekday and repository
    - **Property 5: Commits are grouped into correct weekday and repository**
    - **Validates: Requirements 3.1, 3.3**

  - [ ]* 6.3 Write property test: weekday groups chronologically ordered with no empty groups
    - **Property 6: Weekday groups are chronologically ordered with no empty groups**
    - **Validates: Requirements 3.2, 3.4**

- [x] 7. Implement commit summarizer
  - [x] 7.1 Implement `extract_prefix` and `summarize_commits` in `src/work_intelligence/summarizer.py`
    - `extract_prefix`: return substring up to first colon or first 50 chars, whichever is shorter
    - `summarize_commits`: group commits by normalized prefix within each repo/day; set `is_summarized=True` for groups with 3+ commits
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [ ]* 7.2 Write property test: commit message prefix extraction
    - **Property 9: Commit message prefix extraction**
    - **Validates: Requirements 6.2**

  - [ ]* 7.3 Write property test: summarization threshold
    - **Property 10: Summarization threshold**
    - **Validates: Requirements 6.1, 6.3, 6.4**

- [x] 8. Implement markdown renderer
  - [x] 8.1 Implement `render_markdown` in `src/work_intelligence/renderer.py`
    - Produce top-level heading with author, date range, total commit count
    - Render each day as `## Weekday — YYYY-MM-DD`
    - Render each repo within a day as `### RepoName`
    - Summarized groups: summary line with count, then individual commits as sub-items
    - Non-summarized commits: `- \`hash\` message`
    - Zero commits: produce "no commits found" message
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_

  - [ ]* 8.2 Write property test: rendered report contains all input data elements
    - **Property 7: Rendered report contains all input data elements**
    - **Validates: Requirements 4.2, 4.3, 4.4, 4.5**

- [x] 9. Implement pipeline orchestrator and CLI entry point
  - [x] 9.1 Implement `run_pipeline` in `src/work_intelligence/pipeline.py`
    - Orchestrate the full flow: load config → scan repos → extract history → group → summarize → render
    - Return the markdown report string
    - _Requirements: 7.4_

  - [x] 9.2 Implement CLI entry point in `src/work_intelligence/cli.py`
    - Build `argparse` parser with options: `--author`, `--parent-directory`, `--repositories` (nargs), `--start-date`, `--end-date`, `--output`, `--config` (default `.kiro/work-intelligence.json`)
    - Call `load_configuration` with parsed args, then `run_pipeline`
    - Write output to file or stdout based on config
    - Handle errors with user-friendly messages
    - _Requirements: 5.1, 5.2, 5.3, 5.5, 5.7, 5.8, 7.1, 7.4_

- [x] 10. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Implement MCP server (Layer 2)
  - [x] 11.1 Implement MCP server in `src/work_intelligence/server.py`
    - Create `FastMCP("work-intelligence-agent")` instance
    - Implement `generate_report` tool: accepts author, parent_directory, repositories, start_date, end_date; calls pipeline; returns markdown string
    - Implement `scan_repos` tool: accepts parent_directory; returns list of repo paths
    - Implement `extract_history` tool: accepts repo_paths, author, start_date, end_date; returns list of commit dicts
    - Add `main()` function that calls `mcp.run()`
    - _Requirements: 7.1_

  - [ ]* 11.2 Write integration test with a temporary git repository
    - Create temp directory with git repos and commits using `subprocess.run`
    - Run the full pipeline end-to-end
    - Verify the markdown output contains expected headings, commits, and structure
    - _Requirements: 1.1, 2.1, 3.1, 4.1, 7.4_

- [x] 12. Create Kiro Power packaging files
  - [x] 12.1 Create `POWER.md` manifest and steering file
    - Write `POWER.md` with tool name, description, installation instructions (`uvx`), and MCP server configuration
    - Write `.kiro/steering/work-intelligence.md` steering file with usage guidance for the agent
    - Create `README.md` with project overview, installation, and usage instructions
    - _Requirements: 7.1_

- [x] 13. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Hypothesis strategies in `conftest.py` are shared across all property test files
- Layer 2 (MCP server) depends on Layer 1 being complete — it imports the same pipeline functions
