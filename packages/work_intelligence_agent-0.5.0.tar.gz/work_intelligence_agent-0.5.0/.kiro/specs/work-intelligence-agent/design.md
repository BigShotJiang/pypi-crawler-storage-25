# Design Document: Work Intelligence Agent

## Overview

The Work Intelligence Agent is a Python CLI tool that automates weekly work reporting by scanning git history across multiple repositories. It discovers git repos from a parent directory or explicit list, extracts commit history filtered by author and date range, groups commits by weekday, summarizes similar commits, and outputs a clean markdown report.

The system is delivered in two layers:

- **Layer 1 (CLI)**: A standalone Python CLI tool using `argparse` for argument parsing and `subprocess.run` for git commands. This is the core product — a working command-line tool that reads config from `.kiro/work-intelligence.json` and runs the full pipeline.
- **Layer 2 (MCP/Power)**: A thin MCP server wrapper using `fastmcp` that exposes the core pipeline as MCP tools. Packaged for `uvx` distribution as a Kiro Power, with `POWER.md` and steering files for team use.

Both layers share the same functional pipeline: scan → extract → group → summarize → render.

### Key Design Decisions

- **subprocess for git**: Use Python `subprocess.run` to invoke `git log` rather than a git library like GitPython. This avoids heavy dependencies and gives direct control over the log format.
- **Functional pipeline**: Each stage (scan → extract → group → summarize → render) is a pure function operating on typed data (dataclasses), making the system easy to test and compose.
- **No database**: All data flows in-memory from git output to markdown string. No persistence layer is needed.
- **Configuration layering**: Config file provides defaults, CLI args override. The config file lives at `.kiro/work-intelligence.json`.
- **CLI-first, MCP-second**: The CLI tool is the primary artifact. The MCP server is a thin wrapper that imports and calls the same pipeline functions.
- **Dataclasses for models**: Use Python `dataclasses` for typed data structures. Pydantic is not needed since we don't require runtime JSON schema validation.
- **uvx distribution**: Package as a standard Python project with `pyproject.toml` so it can be installed and run via `uvx`.

## Architecture

```mermaid
flowchart TD
    subgraph "Layer 1: CLI"
        A[CLI Entry Point<br>argparse] --> B[Configuration Loader]
        B --> C[Repository Scanner]
        C --> D[History Extractor]
        D --> E[Commit Grouper]
        E --> F[Commit Summarizer]
        F --> G[Markdown Renderer]
        G --> H{Output Path?}
        H -->|Yes| I[Write to File]
        H -->|No| J[Write to stdout]
    end

    subgraph "Layer 2: MCP Server"
        K[fastmcp Server] -->|calls| B
        K -->|exposes tools| L[generate_report tool]
        K -->|exposes tools| M[scan_repos tool]
        K -->|exposes tools| N[extract_history tool]
    end
```

### Data Flow

1. **Configuration Loader** reads `.kiro/work-intelligence.json` and merges with CLI args → produces `ReportConfiguration`
2. **Repository Scanner** takes parent directory and/or explicit paths → produces `list[str]` of valid repo absolute paths
3. **History Extractor** takes repo paths + author + date range → produces `list[CommitRecord]` sorted by date ascending
4. **Commit Grouper** takes `list[CommitRecord]` → produces `list[WeekdayGroup]` (chronological, sub-grouped by repo)
5. **Commit Summarizer** takes `list[WeekdayGroup]` → produces `list[SummarizedWeekdayGroup]` with similar commits collapsed
6. **Markdown Renderer** takes `list[SummarizedWeekdayGroup]` + config metadata → produces markdown string

## Components and Interfaces

### ConfigurationLoader

```python
@dataclass
class DateRange:
    start: str  # ISO 8601 date string (YYYY-MM-DD)
    end: str    # ISO 8601 date string (YYYY-MM-DD)

@dataclass
class ReportConfiguration:
    author: str                          # Required — author name for filtering
    parent_directory: str | None = None  # Optional — directory to scan recursively
    repositories: list[str] | None = None  # Optional — explicit repo paths
    date_range: DateRange | None = None  # Optional — defaults to last 7 days
    output_path: str | None = None       # Optional — file path for report output

def load_configuration(config_file_path: str, cli_args: dict) -> ReportConfiguration:
    """
    Reads JSON from config_file_path if it exists.
    Merges CLI args on top (CLI wins).
    Validates that author is present.
    Validates that at least one of parent_directory or repositories is provided.
    Defaults date_range to last 7 days if not specified.
    """
    ...
```

### RepositoryScanner

```python
def scan_repositories(config: ReportConfiguration) -> list[str]:
    """
    If parent_directory is set, recursively walks the directory tree looking for .git folders
    using os.walk.
    If repositories is set, resolves each to an absolute path via os.path.realpath.
    Merges both lists, deduplicates by resolved absolute path.
    For each candidate, verifies it is a valid git repo (checks .git exists and is a directory).
    Logs warnings for invalid/missing paths via logging module, does not raise.
    Returns sorted, deduplicated list of absolute paths.
    """
    ...
```

### HistoryExtractor

```python
@dataclass
class CommitRecord:
    hash: str           # Short commit hash (7 chars)
    author: str         # Author name from git
    date: datetime      # Commit date (timezone-aware)
    message: str        # First line of commit message
    repository: str     # Repository name (basename of repo path)

def extract_history(
    repo_paths: list[str],
    author: str,
    date_range: DateRange,
) -> list[CommitRecord]:
    """
    For each repo, runs:
        subprocess.run(
            ["git", "log", f"--format=%h|%an|%aI|%s",
             f"--after={date_range.start}", f"--before={date_range.end}",
             f"--author={author}"],
            cwd=repo_path, capture_output=True, text=True, timeout=30
        )
    The --author flag in git already does case-insensitive substring matching (Req 2.2).
    Parses each line into a CommitRecord.
    On failure for a repo, logs warning and continues.
    Returns all commits sorted by date ascending.
    """
    ...

def parse_git_log_line(line: str, repository: str) -> CommitRecord:
    """Parses a single pipe-delimited git log line into a CommitRecord."""
    ...

def format_git_log_line(record: CommitRecord) -> str:
    """Formats a CommitRecord back into the pipe-delimited git log format."""
    ...
```

### CommitGrouper

```python
@dataclass
class RepoGroup:
    repository: str
    commits: list[CommitRecord]

@dataclass
class WeekdayGroup:
    weekday: str        # e.g., "Monday"
    date: str           # e.g., "2025-01-06"
    repos: list[RepoGroup]

def group_by_weekday(commits: list[CommitRecord]) -> list[WeekdayGroup]:
    """
    Groups commits by calendar date, then by repository within each date.
    Orders groups chronologically (ascending date order).
    Omits days with zero commits.
    Each WeekdayGroup contains the weekday name and the actual date string.
    """
    ...
```

### CommitSummarizer

```python
@dataclass
class SummaryGroup:
    prefix: str                    # The shared prefix
    commits: list[CommitRecord]    # Individual commits in this group
    is_summarized: bool            # True if 3+ commits share the prefix

@dataclass
class SummarizedRepoGroup:
    repository: str
    groups: list[SummaryGroup]

@dataclass
class SummarizedWeekdayGroup:
    weekday: str
    date: str
    repos: list[SummarizedRepoGroup]

def extract_prefix(message: str) -> str:
    """
    Extracts the prefix of a commit message: up to the first colon or
    first 50 characters, whichever is shorter. If no colon within the
    first 50 chars, returns the first 50 chars (or full message if shorter).
    """
    ...

def summarize_commits(weekday_groups: list[WeekdayGroup]) -> list[SummarizedWeekdayGroup]:
    """
    Within each repo group on a given day, groups commits by normalized prefix.
    Groups with 3+ commits get is_summarized=True.
    Groups with fewer than 3 commits get is_summarized=False.
    """
    ...
```

### MarkdownRenderer

```python
def render_markdown(
    groups: list[SummarizedWeekdayGroup],
    config: ReportConfiguration,
    total_commits: int,
) -> str:
    """
    Produces a top-level heading with author, date range, and total commit count.
    Each day is a ## Weekday — YYYY-MM-DD heading.
    Each repo within a day is a ### RepoName heading.
    Summarized groups render as a summary line with count, followed by individual
    commits as sub-items.
    Non-summarized commits render as - `hash` message.
    If zero commits, produces a message stating no commits were found.
    """
    ...
```

### CLI Entry Point

```python
def build_arg_parser() -> argparse.ArgumentParser:
    """Builds the argparse parser with all CLI options."""
    ...

def main() -> None:
    """
    CLI entry point. Parses args, loads config, runs the full pipeline:
    load config → scan repos → extract history → group → summarize → render → output.
    """
    ...
```

### MCP Server (Layer 2)

```python
from fastmcp import FastMCP

mcp = FastMCP("work-intelligence-agent")

@mcp.tool()
def generate_report(
    author: str,
    parent_directory: str | None = None,
    repositories: list[str] | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
) -> str:
    """
    Generate a weekly work report by scanning git history.
    Calls the same pipeline functions as the CLI.
    Returns the markdown report as a string.
    """
    ...

@mcp.tool()
def scan_repos(parent_directory: str) -> list[str]:
    """Discover git repositories under a parent directory."""
    ...

@mcp.tool()
def extract_history(
    repo_paths: list[str],
    author: str,
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    """Extract commit history from specified repositories."""
    ...
```

## Data Models

### CommitRecord

| Field      | Type       | Description                          |
|-----------|------------|--------------------------------------|
| hash      | str        | Short git commit hash (7 chars)      |
| author    | str        | Git author name                      |
| date      | datetime   | Commit timestamp (timezone-aware)    |
| message   | str        | First line of commit message         |
| repository| str        | Repository name (directory basename) |

### ReportConfiguration

| Field            | Type                | Required | Description                                 |
|-----------------|---------------------|----------|---------------------------------------------|
| author          | str                 | Yes      | Author name for commit filtering            |
| parent_directory| str \| None         | No       | Parent directory to scan for repos          |
| repositories    | list[str] \| None   | No       | Explicit list of repo paths                 |
| date_range      | DateRange \| None   | No       | ISO 8601 date range, defaults to last 7 days|
| output_path     | str \| None         | No       | Output file path, defaults to stdout        |

### WeekdayGroup

| Field   | Type            | Description                        |
|--------|----------------|------------------------------------|
| weekday| str            | Day name (Monday–Sunday)           |
| date   | str            | Calendar date (YYYY-MM-DD)         |
| repos  | list[RepoGroup]| Commits sub-grouped by repository  |

### SummaryGroup

| Field         | Type              | Description                                       |
|--------------|-------------------|---------------------------------------------------|
| prefix       | str               | Shared commit message prefix                      |
| commits      | list[CommitRecord]| Individual commits in this group                  |
| is_summarized| bool              | True if group has 3+ commits (renders as summary) |

### Package Structure

```
work-intelligence-agent/
├── pyproject.toml              # Package config, entry points for CLI + MCP
├── POWER.md                    # Kiro Power manifest
├── README.md
├── src/
│   └── work_intelligence/
│       ├── __init__.py
│       ├── cli.py              # argparse CLI entry point
│       ├── config.py           # ConfigurationLoader
│       ├── scanner.py          # RepositoryScanner
│       ├── extractor.py        # HistoryExtractor
│       ├── grouper.py          # CommitGrouper
│       ├── summarizer.py       # CommitSummarizer
│       ├── renderer.py         # MarkdownRenderer
│       ├── models.py           # Shared dataclasses
│       ├── pipeline.py         # Orchestrates the full pipeline
│       └── server.py           # fastmcp MCP server (Layer 2)
├── tests/
│   ├── test_config.py
│   ├── test_scanner.py
│   ├── test_extractor.py
│   ├── test_grouper.py
│   ├── test_summarizer.py
│   ├── test_renderer.py
│   └── test_integration.py
└── .kiro/
    └── steering/
        └── work-intelligence.md  # Steering file for Kiro Power
```

The `pyproject.toml` defines two entry points:
- `work-intelligence` → `work_intelligence.cli:main` (CLI)
- `work-intelligence-mcp` → `work_intelligence.server:main` (MCP server)

This allows `uvx work-intelligence-agent` for CLI use and MCP server configuration for Kiro Power integration.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Repository scanner produces deduplicated absolute paths

*For any* combination of a parent directory (containing nested git repos) and an explicit repository list, the scanner output should contain exactly the union of discovered and explicit valid repos, with no duplicate entries, and every path in the output should be an absolute path.

**Validates: Requirements 1.3, 1.6**

### Property 2: All returned commits match author and date filters

*For any* set of commit records and any author string and date range, every commit returned by the history extractor should have an author field that contains the search string (case-insensitive) AND a date that falls within the specified date range (inclusive).

**Validates: Requirements 2.2, 2.3**

### Property 3: Git log line parsing round trip

*For any* valid CommitRecord, formatting it into the git log pipe-delimited format (`hash|author|date|message`) and then parsing it back should produce an equivalent CommitRecord.

**Validates: Requirements 2.5**

### Property 4: Extracted commits are sorted by date ascending

*For any* list of CommitRecords returned by the history extractor, each commit's date should be less than or equal to the next commit's date.

**Validates: Requirements 2.7**

### Property 5: Commits are grouped into correct weekday and repository

*For any* list of CommitRecords, after grouping by weekday, every commit within a WeekdayGroup should have a date that falls on that group's weekday, and every commit within a RepoGroup should have a repository field matching that group's repository name.

**Validates: Requirements 3.1, 3.3**

### Property 6: Weekday groups are chronologically ordered with no empty groups

*For any* list of WeekdayGroups produced by the grouper, the groups should be in ascending date order, and every group should contain at least one commit.

**Validates: Requirements 3.2, 3.4**

### Property 7: Rendered report contains all input data elements

*For any* set of SummarizedWeekdayGroups and ReportConfiguration, the rendered markdown string should contain: the author name, the date range, the total commit count in the header, each weekday group's name as a `##` heading, each repository name as a `###` heading, and each commit's hash and message somewhere in the output.

**Validates: Requirements 4.2, 4.3, 4.4, 4.5**

### Property 8: Configuration validation rejects invalid configs

*For any* ReportConfiguration where `author` is missing or empty, OR where both `parent_directory` and `repositories` are absent, validation should return an error. For any ReportConfiguration where `author` is non-empty AND at least one of `parent_directory` or `repositories` is provided, validation should succeed.

**Validates: Requirements 5.1, 5.4**

### Property 9: Commit message prefix extraction

*For any* commit message string, the extracted prefix should be the substring up to the first colon or the first 50 characters, whichever is shorter. If no colon exists within the first 50 characters, the prefix should be the first 50 characters (or the full message if shorter than 50).

**Validates: Requirements 6.2**

### Property 10: Summarization threshold

*For any* set of commits within the same repo and same day that share the same prefix, if the group contains 3 or more commits then `is_summarized` should be `True`, and if the group contains fewer than 3 commits then `is_summarized` should be `False`.

**Validates: Requirements 6.1, 6.3, 6.4**

### Property 11: Configuration merge — CLI overrides file defaults

*For any* configuration file values and any CLI argument values, the resulting merged configuration should equal the CLI values for every field where CLI provides a value, and equal the file values for every field where CLI does not provide a value.

**Validates: Requirements 7.2, 7.3**

## Error Handling

### Repository Scanner Errors

- **Path does not exist**: Log a warning with the path via `logging.warning()`, skip it, continue scanning. Do not raise.
- **Path exists but is not a git repo**: Log a warning, exclude from results, continue.
- **Permission denied on directory traversal**: Log a warning, skip that subtree, continue.

### History Extractor Errors

- **git log command fails for a repo** (e.g., corrupted repo, permission issue): Log a warning identifying the repo, continue with remaining repos. The overall result is a partial success.
- **subprocess.run timeout** (30s default): Log a warning, skip that repo, continue.
- **Unparseable git log output line**: Log a warning with the raw line, skip that commit, continue parsing.

### Configuration Errors

- **Missing author**: Raise a `ValueError` with a clear message before any scanning begins.
- **No repository source**: Raise a `ValueError` indicating at least one of `parent_directory` or `repositories` is required.
- **Invalid date range** (start > end): Raise a `ValueError`.
- **Config file not found**: Not an error — proceed with CLI args only.
- **Config file is malformed JSON**: Raise a `json.JSONDecodeError` with the parse failure details.

### Output Errors

- **Cannot write to output file** (permission denied, invalid path): Raise an `OSError` after report generation, so the report content is not lost. Print to stdout as fallback if possible.

## Testing Strategy

### Property-Based Testing

Use **Hypothesis** as the property-based testing library for Python.

Each property test must:
- Run a minimum of 100 examples using `@settings(max_examples=100)`
- Reference its design document property with a tag comment
- Tag format: `# Feature: work-intelligence-agent, Property {number}: {title}`

Property tests cover:
- Repository deduplication and path resolution (Property 1)
- Commit filtering by author and date (Property 2)
- Git log line parse/format round trip (Property 3)
- Commit sort order invariant (Property 4)
- Weekday and repository grouping correctness (Property 5)
- Weekday group ordering and non-emptiness (Property 6)
- Markdown rendering completeness (Property 7)
- Configuration validation (Property 8)
- Prefix extraction logic (Property 9)
- Summarization threshold logic (Property 10)
- Configuration merge precedence (Property 11)

Each correctness property must be implemented by a single Hypothesis property-based test. Custom Hypothesis strategies should be defined for generating `CommitRecord`, `ReportConfiguration`, and other domain types.

### Unit Testing

Use **pytest** as the test runner.

Unit tests focus on:
- Specific examples: a known directory structure producing expected repo list
- Edge cases: empty commit list produces "no commits found" report (Req 4.6), date range defaults to last 7 days (Req 2.4, 5.6), output defaults to stdout (Req 5.8)
- Error conditions: missing author, no repo source, malformed config file, inaccessible repo
- Integration: end-to-end test with a temp git repo (using `subprocess.run` to create commits), verifying final markdown output

### Test Organization

```
tests/
  test_config.py         # Unit + property tests for config loading and validation
  test_scanner.py        # Unit + property tests for repository scanning
  test_extractor.py      # Unit + property tests for history extraction and parsing
  test_grouper.py        # Unit + property tests for weekday grouping
  test_summarizer.py     # Unit + property tests for commit summarization
  test_renderer.py       # Unit + property tests for markdown rendering
  test_integration.py    # End-to-end integration test with temp git repos
  conftest.py            # Shared Hypothesis strategies and pytest fixtures
```
