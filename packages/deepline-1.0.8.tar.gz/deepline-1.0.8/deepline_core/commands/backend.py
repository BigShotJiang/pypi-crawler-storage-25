from __future__ import annotations

from dataclasses import dataclass
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict
from urllib.parse import urlparse

_IS_WINDOWS = sys.platform == "win32"
_CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
_DETACHED_PROCESS = getattr(subprocess, "DETACHED_PROCESS", 0x00000008)

from deepline_core.command_decorators import OptionSpec, ParsedRouteOptions, SubcommandRouter
from deepline_core.command_decorators import build_command_handler
from deepline_core.command_common import EXIT_OK, EXIT_SERVER
from deepline_core.browser import open_url_in_browser
from deepline_core.http import http_request
from deepline_core.playground_helpers import (
    ensure_playground_native_modules,
    refresh_runtime_playground,
    env_dir,
    find_node_bin,
    install_playground_dependencies,
    playground_default_api,
    playground_read_state,
    runtime_playground_dependency_root,
    runtime_playground_dir,
    playground_write_state,
    terminate_pid,
)

router = SubcommandRouter()

def _info(msg: str) -> None:
    """Print only when DEBUG is set — informational, not essential."""
    if os.environ.get("DEBUG"):
        print(f"[debug] {msg}")


def _resolve_repo_root_for_runtime() -> str:
    explicit = str(os.environ.get("DEEPLINE_REPO_ROOT", "")).strip()
    if explicit:
        return explicit

    current = Path(__file__).resolve()
    for parent in [current.parent] + list(current.parents):
        if (parent / "package.json").is_file() and (parent / "src").is_dir():
            return str(parent)
    return str(Path.cwd())


def _assume_backend_ready_env() -> bool:
    """Eval/parallel-harness escape hatch — skip backend start/stop entirely."""
    raw = str(os.environ.get("DEEPLINE_ASSUME_BACKEND_READY", "")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def usage_backend_computed() -> list[str]:
    lines = router.usage_lines("deepline backend")
    lines.append("")
    lines.append("Tip:")
    lines.append("  Use --json for machine-readable status/stop responses.")
    return lines


@dataclass(frozen=True)
class StartParams:
    port: str
    open_flag: bool
    install_mode: str


@dataclass(frozen=True)
class StatusParams:
    output_json: bool


@dataclass(frozen=True)
class StopParams:
    output_json: bool
    just_backend: bool


def refresh_runtime(base_url: str) -> int:
    try:
        runtime_pg_dir = refresh_runtime_playground(base_url)
    except RuntimeError as exc:
        print(str(exc))
        return EXIT_SERVER

    runtime_version = _runtime_playground_version(runtime_pg_dir)
    print(f"Runtime: {runtime_pg_dir}")
    if runtime_version:
        print(f"Version: {runtime_version}")
    return EXIT_OK


def playground_health(api_url: str) -> bool:
    try:
        status, _ = http_request("GET", f"{api_url.rstrip('/')}/api/health", None, None, timeout=3)
        return status == 200
    except RuntimeError:
        return False


def _wait_backend_health(api_url: str, timeout_s: int | None = None) -> bool:
    if timeout_s is None:
        timeout_s = 45 if _IS_WINDOWS else 25
    end = time.time() + timeout_s
    while time.time() < end:
        if playground_health(api_url):
            return True
        time.sleep(0.5)
    return False


def _backend_port_from_url(api_url: str) -> int:
    try:
        parsed = urlparse(api_url)
        if parsed.port:
            return int(parsed.port)
    except Exception:
        pass
    return 4173


def _pids_listening_on_port(port: int) -> list[int]:
    if port <= 0:
        return []

    if _IS_WINDOWS:
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
                creationflags=_CREATE_NO_WINDOW,
            )
        except Exception:
            return []
        pids: list[int] = []
        for raw in (result.stdout or "").splitlines():
            line = raw.strip()
            if "LISTENING" not in line:
                continue
            parts = line.split()
            # netstat -ano format: proto  local_addr  foreign_addr  state  pid
            if len(parts) < 5:
                continue
            # Extract port from local address (e.g. "0.0.0.0:3000" or "[::1]:3000")
            addr_port = parts[1].rsplit(":", 1)[-1]
            if addr_port != str(port):
                continue
            pid_str = parts[-1]
            if pid_str.isdigit():
                pids.append(int(pid_str))
    else:
        lsof_bin = shutil.which("lsof")
        if not lsof_bin:
            return []
        try:
            result = subprocess.run(
                [lsof_bin, "-Pan", "-t", f"-iTCP:{port}", "-sTCP:LISTEN"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
            )
        except Exception:
            return []
        pids = []
        for raw in (result.stdout or "").splitlines():
            item = raw.strip()
            if item.isdigit():
                pids.append(int(item))

    # De-duplicate while preserving order.
    seen: set[int] = set()
    out: list[int] = []
    for pid in pids:
        if pid not in seen:
            seen.add(pid)
            out.append(pid)
    return out


def _listening_ports_for_pid(pid: int) -> list[int]:
    if pid <= 0:
        return []

    ports: list[int] = []
    if _IS_WINDOWS:
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
                creationflags=_CREATE_NO_WINDOW,
            )
        except Exception:
            return []
        for raw in (result.stdout or "").splitlines():
            line = raw.strip()
            if "LISTENING" not in line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            pid_str = parts[-1]
            if pid_str != str(pid):
                continue
            addr_port = parts[1].rsplit(":", 1)[-1]
            try:
                ports.append(int(addr_port))
            except Exception:
                continue
    else:
        lsof_bin = shutil.which("lsof")
        if not lsof_bin:
            return []
        try:
            result = subprocess.run(
                [lsof_bin, "-Pan", "-p", str(pid), "-iTCP", "-sTCP:LISTEN", "-Fn"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                check=False,
            )
        except Exception:
            return []
        for raw in (result.stdout or "").splitlines():
            line = raw.strip()
            if not line.startswith("n"):
                continue
            address = line[1:]
            addr_port = address.rsplit(":", 1)[-1]
            try:
                ports.append(int(addr_port))
            except Exception:
                continue

    seen: set[int] = set()
    out: list[int] = []
    for port_value in ports:
        if port_value not in seen:
            seen.add(port_value)
            out.append(port_value)
    return out


def _find_free_port(starting_from: int, max_attempts: int = 20) -> int | None:
    """Find a free TCP port starting from *starting_from + 1*."""
    import socket

    for offset in range(1, max_attempts + 1):
        candidate = starting_from + offset
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", candidate))
                return candidate
        except OSError:
            continue
    return None


def _runner_command_markers() -> tuple[list[str], str]:
    runtime_dir = runtime_playground_dir()
    current_path = str((runtime_dir / "run.cjs").resolve())
    current_alt_path = str(runtime_dir / "run.cjs")
    legacy_path = str((runtime_dir / "run.js").resolve())
    legacy_alt_path = str(runtime_dir / "run.js")
    shared_marker = f"{os.sep}.local{os.sep}deepline{os.sep}runtime{os.sep}playground{os.sep}run."
    return [current_path, current_alt_path, legacy_path, legacy_alt_path], shared_marker


def _pid_command_map() -> dict[int, str]:
    if _IS_WINDOWS:
        return {}
    try:
        result = subprocess.run(
            ["ps", "-axo", "pid=,command="],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=False,
        )
    except Exception:
        return {}

    command_map: dict[int, str] = {}
    for raw in (result.stdout or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        parts = line.split(None, 1)
        if len(parts) != 2 or not parts[0].isdigit():
            continue
        command_map[int(parts[0])] = parts[1]
    return command_map


def _process_command(pid: int) -> str:
    return _pid_command_map().get(pid, "")


def _is_playground_runner_command(command: str) -> bool:
    if not command:
        return False
    markers, shared_marker = _runner_command_markers()
    return any(marker in command for marker in markers) or shared_marker in command


def _should_stop_port_listener(pid: int, target_port: int) -> bool:
    if pid <= 0:
        return False
    command = _process_command(pid)
    if _is_playground_runner_command(command):
        return True
    if target_port != 4173:
        return False
    if not command:
        return True
    lowered = command.lower()
    protected_markers = (
        "postgres",
        "postmaster",
        "redis",
        "mysql",
        "mongod",
        "docker",
        "podman",
        "python -m http.server",
        "uvicorn",
        "gunicorn",
        "next dev",
        "vite",
    )
    return not any(marker in lowered for marker in protected_markers)


def _list_playground_runner_pids(current_home_only: bool = False) -> list[int]:
    if _IS_WINDOWS:
        return []

    command_map = _pid_command_map()
    markers, shared_marker = _runner_command_markers()

    pids: list[int] = []
    for pid, command in command_map.items():
        if not any(marker in command for marker in markers):
            if current_home_only or shared_marker not in command:
                continue
        if current_home_only and not any(marker in command for marker in markers):
            continue
        pids.append(pid)

    seen: set[int] = set()
    out: list[int] = []
    for value in pids:
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


def _list_current_home_playground_runner_pids() -> list[int]:
    if _IS_WINDOWS:
        return []

    markers, _shared_marker = _runner_command_markers()
    broad_runner_pids = _list_playground_runner_pids()

    pids: list[int] = []
    for pid in broad_runner_pids:
        command = _process_command(pid)
        if not any(marker in command for marker in markers):
            continue
        pids.append(pid)

    seen: set[int] = set()
    out: list[int] = []
    for value in pids:
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


def _list_related_playground_runner_pids(target_port: int) -> list[int]:
    broad_runner_pids = _list_playground_runner_pids()
    current_home_runner_pids = set(_list_current_home_playground_runner_pids())

    related: list[int] = []
    for pid in broad_runner_pids:
        command = _process_command(pid)
        if pid in current_home_runner_pids:
            related.append(pid)
            continue
        if target_port > 0 and str(target_port) in command:
            related.append(pid)

    return _unique_pids(related)


def _wait_for_pid_to_listen_on_port(pid: int, port: int, timeout_s: float = 3.0) -> bool:
    end = time.time() + max(0.1, timeout_s)
    while time.time() < end:
        if pid in _pids_listening_on_port(port):
            return True
        time.sleep(0.1)
    return pid in _pids_listening_on_port(port)


def _record_backend_state(
    *,
    backend_pid: int | None,
    api_url: str,
    log_path: str,
    runtime_version: str,
) -> None:
    state = playground_read_state()
    if isinstance(backend_pid, int) and backend_pid > 0:
        state["backend_pid"] = backend_pid
    else:
        state.pop("backend_pid", None)
    state.update(
        {
            "backend_api_url": api_url,
            "backend_log_path": log_path,
            "backend_started_at": int(time.time()),
            "backend_runtime_version": runtime_version,
        }
    )
    state.pop("session_ui_opened", None)
    playground_write_state(state)


def _unique_pids(values: list[int]) -> list[int]:
    seen: set[int] = set()
    out: list[int] = []
    for value in values:
        if value <= 0 or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _terminate_pids(pids: list[int]) -> tuple[list[int], list[int]]:
    stopped: list[int] = []
    failed: list[int] = []
    for candidate in _unique_pids(pids):
        if terminate_pid(candidate):
            stopped.append(candidate)
        else:
            failed.append(candidate)
    return stopped, failed


def _pid_still_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        result = subprocess.run(
            ["ps", "-o", "stat=", "-p", str(pid)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=False,
        )
    except Exception:
        result = None

    if result is not None:
        if result.returncode != 0:
            return False
        status = (result.stdout or "").strip()
        if not status:
            return False
        if "Z" in status:
            return False

    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True


def _reconcile_stopped_pids(
    stopped: list[int],
    failed: list[int],
    wait_s: float = 2.0,
    poll_s: float = 0.1,
) -> tuple[list[int], list[int]]:
    if not failed:
        return stopped, failed

    deadline = time.time() + max(0.0, wait_s)
    remaining = _unique_pids(failed)
    while remaining and time.time() < deadline:
        next_remaining: list[int] = []
        for candidate in remaining:
            if _pid_still_alive(candidate):
                next_remaining.append(candidate)
            else:
                stopped.append(candidate)
        remaining = next_remaining
        if remaining and poll_s > 0:
            time.sleep(poll_s)

    still_failed: list[int] = []
    for candidate in remaining:
        if _pid_still_alive(candidate):
            still_failed.append(candidate)
        else:
            stopped.append(candidate)
    return _unique_pids(stopped), _unique_pids(still_failed)


def _runtime_playground_version(runtime_pg_dir) -> str:
    try:
        version_file = runtime_pg_dir / ".version"
        if not version_file.is_file():
            return ""
        return version_file.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def _started_at_iso(value: object) -> str:
    if not isinstance(value, (int, float)):
        return ""
    try:
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(float(value)))
    except Exception:
        return ""


def _probe_http_health_status(
    url: str,
    *,
    timeout: int = 2,
    healthy_statuses: tuple[int, ...] = (200, 404),
) -> str:
    if not url:
        return "unknown"
    try:
        status, _ = http_request("GET", url, None, None, timeout=timeout)
    except RuntimeError:
        return "unhealthy"
    return "healthy" if status in healthy_statuses else "unhealthy"


def _render_status_payload(state: Dict[str, object], checked_at: str) -> dict[str, object]:
    render_url = str(state.get("render_url") or "")
    render_pid = state.get("render_pid")
    render_alive = _pid_still_alive(render_pid) if isinstance(render_pid, int) else False
    render_health = str(state.get("render_health_status") or "").strip()
    if not render_health:
        if render_alive and render_url:
            render_health = _probe_http_health_status(render_url, timeout=2)
        else:
            render_health = "unknown"
    render_status = (
        "running"
        if render_alive and render_health == "healthy"
        else ("unhealthy" if render_alive else "stopped")
    )
    return {
        "status": render_status,
        "process_alive": render_alive,
        "pid": render_pid if isinstance(render_pid, int) else None,
        "url": render_url,
        "log_path": state.get("render_log_path") or "",
        "mode": (state.get("render_mode") or "background") if isinstance(render_pid, int) else "",
        "started_at": state.get("render_started_at") or "",
        "health_status": render_health,
        "health_checked_at": checked_at,
    }


def _stop_backend_for_refresh(state: Dict[str, object], port: str) -> bool:
    tracked_pid = state.get("backend_pid")
    if isinstance(tracked_pid, int):
        if terminate_pid(tracked_pid):
            state.pop("backend_pid", None)
            state.pop("backend_runtime_version", None)
            playground_write_state(state)
            return True
    api_url = str(state.get("backend_api_url") or f"http://127.0.0.1:{port}")
    target_port = _backend_port_from_url(api_url)
    stopped_any = False
    for candidate in _pids_listening_on_port(target_port):
        if _should_stop_port_listener(candidate, target_port) and terminate_pid(candidate):
            stopped_any = True
    if stopped_any and not playground_health(api_url):
        state.pop("backend_pid", None)
        state.pop("backend_runtime_version", None)
        playground_write_state(state)
        return True
    return False


def _should_restart_running_backend(
    runtime_pg_dir,
    desired_runtime_version: str,
    running_runtime_version: str,
) -> bool:
    if not runtime_pg_dir or not desired_runtime_version:
        return False
    if not running_runtime_version:
        return True
    return desired_runtime_version != running_runtime_version


def _current_cli_binary() -> str:
    for key in ("DEEPLINE_BIN", "DEEPLINE_CLI"):
        candidate = str(os.environ.get(key) or "").strip()
        if candidate:
            return candidate
    argv0 = str(sys.argv[0] or "").strip()
    if not argv0:
        return ""
    try:
        resolved = os.path.realpath(argv0)
    except Exception:
        resolved = argv0
    if not resolved or not os.path.isfile(resolved):
        return ""
    if _IS_WINDOWS or os.access(resolved, os.X_OK):
        return resolved
    return ""


def _resolve_runtime_playground_for_start(
    base_url: str,
    skip_runtime_refresh: bool,
):
    if skip_runtime_refresh:
        try:
            return runtime_playground_dir(base_url=base_url)
        except Exception:
            pass
    try:
        return refresh_runtime_playground(base_url)
    except RuntimeError as exc:
        print(str(exc))
        return None


def start_backend(
    base_url: str,
    port: str,
    open_flag: bool,
    install_mode: str,
    *,
    skip_runtime_refresh: bool = False,
) -> int:
    api_url = f"http://127.0.0.1:{port}"
    target_port = _backend_port_from_url(api_url)
    backend_alive = playground_health(api_url)
    state = playground_read_state()
    runtime_pg_dir = _resolve_runtime_playground_for_start(base_url, skip_runtime_refresh)
    if runtime_pg_dir is None:
        return EXIT_SERVER

    desired_runtime_version = _runtime_playground_version(runtime_pg_dir)
    runner_pids = _list_playground_runner_pids()
    occupied_target_pids = _pids_listening_on_port(target_port)

    if not backend_alive and occupied_target_pids:
        runner_pids_set = set(runner_pids)
        occupied_runner_pids = [pid for pid in occupied_target_pids if pid in runner_pids_set]
        occupied_non_runner_pids = [pid for pid in occupied_target_pids if pid not in runner_pids_set]
        if occupied_non_runner_pids:
            # Auto-select a free port only when the caller did not explicitly
            # request a specific port (i.e. using the default).  An explicit
            # --port should fail loudly so the user knows their choice is taken.
            if target_port == 4173:
                auto_port = _find_free_port(target_port)
            else:
                auto_port = None
            if auto_port is not None:
                print(
                    f"Default port {target_port} is in use by a non-playground process "
                    f"({','.join(str(pid) for pid in occupied_non_runner_pids)}); "
                    f"auto-selecting port {auto_port}."
                )
                port = str(auto_port)
                api_url = f"http://127.0.0.1:{port}"
                target_port = auto_port
                occupied_target_pids = _pids_listening_on_port(target_port)
            else:
                print(
                    "Error: requested playground backend port "
                    f"{target_port} is already in use by a non-playground process: "
                    f"{','.join(str(pid) for pid in occupied_non_runner_pids)}"
                )
                print("Run `deepline backend start --port <port>` to choose a different port.")
                return EXIT_SERVER
        failed_cleanup: list[int] = []
        for candidate in occupied_runner_pids:
            if not terminate_pid(candidate):
                failed_cleanup.append(candidate)
        if failed_cleanup:
            print(
                "Error: requested playground backend port "
                f"{target_port} is occupied by stale playground runner(s) that could not be stopped: "
                f"{','.join(str(pid) for pid in failed_cleanup)}"
            )
            return EXIT_SERVER
        if occupied_runner_pids:
            print(
                "Stopped stale playground backend process(es) that were blocking the "
                f"requested port {target_port}: {','.join(str(pid) for pid in occupied_runner_pids)}"
            )
        occupied_target_pids = _pids_listening_on_port(target_port)
        if occupied_target_pids:
            print(
                "Error: requested playground backend port "
                f"{target_port} is still occupied after cleanup: "
                f"{','.join(str(pid) for pid in occupied_target_pids)}"
            )
            return EXIT_SERVER

    if backend_alive:
        running_runtime_version = str(state.get("backend_runtime_version") or "").strip()
        listener_pids = _pids_listening_on_port(target_port)
        listener_pid = listener_pids[0] if listener_pids else None
        should_restart_for_refresh = _should_restart_running_backend(
            runtime_pg_dir,
            desired_runtime_version,
            running_runtime_version,
        )
        if should_restart_for_refresh:
            if running_runtime_version:
                print(
                    "Playground runtime mismatch while backend is running; restarting backend "
                    f"to pick up latest runtime (running={running_runtime_version or '(missing)'}, "
                    f"available={desired_runtime_version or '(missing)'})."
                )
            else:
                print(
                    "Playground backend runtime is unknown; restarting backend to ensure current pipeline/runtime. "
                    f"available={desired_runtime_version or '(missing)'}."
                )
            if not _stop_backend_for_refresh(state, port):
                print("Playground backend is running but could not be restarted automatically.")
                return EXIT_SERVER
            backend_alive = False
        else:
            tracked_pid = state.get("backend_pid")
            if isinstance(tracked_pid, int) and listener_pid is not None and tracked_pid != listener_pid:
                if terminate_pid(tracked_pid):
                    print(
                        "Stopped stale playground backend process that was not serving "
                        f"the requested port: {tracked_pid}"
                    )
                else:
                    print(
                        "Warning: found a stale tracked playground backend process but "
                        f"could not stop it: {tracked_pid}"
                    )
            if listener_pid is not None:
                stray_runner_pids = _unique_pids(
                    [value for value in _list_playground_runner_pids() if value != listener_pid]
                )
                failed_cleanup: list[int] = []
                stopped_cleanup: list[int] = []
                for candidate in stray_runner_pids:
                    if terminate_pid(candidate):
                        stopped_cleanup.append(candidate)
                    else:
                        failed_cleanup.append(candidate)
                if failed_cleanup:
                    print(
                        "Error: multiple playground backends were detected and some could "
                        f"not be stopped: {','.join(str(pid) for pid in failed_cleanup)}"
                    )
                    return EXIT_SERVER
                if stopped_cleanup:
                    print(
                        "Stopped stray playground backend process(es) before reusing the "
                        f"healthy backend: {','.join(str(pid) for pid in stopped_cleanup)}"
                    )
                state["backend_pid"] = listener_pid
                state["backend_api_url"] = api_url
                state["backend_log_path"] = str(state.get("backend_log_path") or "")
                state["backend_started_at"] = int(state.get("backend_started_at") or int(time.time()))
                state["backend_runtime_version"] = running_runtime_version or desired_runtime_version
                playground_write_state(state)
                _info(
                    "Playground backend is already running; reusing existing backend "
                    f"(runtime={running_runtime_version or '(missing)'}, target={desired_runtime_version or '(missing)'})."
                )
                _info(f"Backend PID: {listener_pid}")
                _info(f"API URL: {api_url}")
                if open_flag:
                    render_url = str(state.get("render_url") or "")
                    if render_url:
                        try:
                            open_url_in_browser(render_url)
                        except Exception:
                            pass
                return EXIT_OK

            tracked = False
            if isinstance(tracked_pid, int):
                try:
                    os.kill(tracked_pid, 0)
                    tracked = True
                except Exception:
                    tracked = False
                if tracked:
                    _info(
                        "Playground backend is already running; reusing existing backend "
                        f"(runtime={running_runtime_version or '(missing)'}, target={desired_runtime_version or '(missing)'})."
                    )
                else:
                    _info("Playground backend is already running but not tracked in local runtime state.")
                    state["backend_api_url"] = api_url
                    playground_write_state(state)
                _info(f"API URL: {api_url}")
                if open_flag:
                    render_url = str(state.get("render_url") or "")
                    if render_url:
                        try:
                            open_url_in_browser(render_url)
                        except Exception:
                            pass
                return EXIT_OK

    if runner_pids:
        stopped_cleanup, failed_cleanup = _terminate_pids(runner_pids)
        if failed_cleanup:
            print(
                "Error: stale playground backend process(es) were detected and could "
                f"not be stopped before startup: {','.join(str(pid) for pid in failed_cleanup)}"
            )
            return EXIT_SERVER
        if stopped_cleanup:
            print(
                "Stopped stale playground backend process(es) before startup: "
                f"{','.join(str(pid) for pid in stopped_cleanup)}"
            )
        occupied_target_pids = _pids_listening_on_port(target_port)
        remaining_non_runner_pids = [pid for pid in occupied_target_pids if pid not in set(_list_playground_runner_pids())]
        if remaining_non_runner_pids:
            print(
                "Error: requested playground backend port "
                f"{target_port} is already in use by a non-playground process: "
                f"{','.join(str(pid) for pid in remaining_non_runner_pids)}"
            )
            print("Run `deepline backend start --port <port>` to choose a different port.")
            return EXIT_SERVER

    run_js = runtime_pg_dir / "run.cjs"
    if not run_js.is_file():
        print(f"Missing playground runner at {run_js}")
        return EXIT_SERVER
    node_bin = find_node_bin()
    if not node_bin:
        print("Missing Node.js executable.")
        return EXIT_SERVER
    if install_mode != "skip":
        dependency_root = runtime_playground_dependency_root(runtime_pg_dir)
        should_install = install_mode == "force" or not (dependency_root / "node_modules").is_dir() or not (
            dependency_root / "node_modules" / "better-sqlite3"
        ).is_dir()
        if should_install:
            try:
                install_playground_dependencies(runtime_pg_dir, node_bin)
            except RuntimeError as exc:
                print(str(exc))
                return EXIT_SERVER
    try:
        ensure_playground_native_modules(runtime_pg_dir, node_bin)
    except RuntimeError as exc:
        print(str(exc))
        return EXIT_SERVER

    state_dir = env_dir(base_url=base_url, write=True)
    state_dir.mkdir(parents=True, exist_ok=True)
    log_path = state_dir / "playground-backend-python.log"
    cmd = [
        node_bin,
        str(run_js),
        "--prevent-auto-die-after-10-min",
        "--api-port",
        str(port),
        "--ui-port",
        "0",
    ]
    child_env = os.environ.copy()
    # Keep the playground backend on the same API origin the CLI resolved for
    # this run so enrich and direct tool execution follow the same backend path.
    child_env["DEEPLINE_API_BASE_URL"] = base_url.rstrip("/")
    child_env["DEEPLINE_REPO_ROOT"] = _resolve_repo_root_for_runtime()
    current_cli_binary = _current_cli_binary()
    if current_cli_binary:
        child_env["DEEPLINE_BIN"] = current_cli_binary
    popen_kwargs: dict = dict(
        stdin=subprocess.DEVNULL,
        stdout=subprocess.STDOUT,
        cwd=str(runtime_pg_dir),
        env=child_env,
    )
    if _IS_WINDOWS:
        popen_kwargs["creationflags"] = (
            _CREATE_NO_WINDOW | _DETACHED_PROCESS
        )
    else:
        popen_kwargs["start_new_session"] = True
        popen_kwargs["close_fds"] = True
    with open(log_path, "ab") as log:
        popen_kwargs["stdout"] = log
        popen_kwargs["stderr"] = log
        proc = subprocess.Popen(cmd, **popen_kwargs)
    api_url = f"http://127.0.0.1:{port}"
    if not _wait_backend_health(api_url):
        print(f"Timed out waiting for playground backend to start. Check logs at {log_path}")
        return EXIT_SERVER

    runtime_version = desired_runtime_version or _runtime_playground_version(runtime_pg_dir)
    if not _wait_for_pid_to_listen_on_port(proc.pid, target_port):
        listener_pids = _pids_listening_on_port(target_port)
        actual_ports = _listening_ports_for_pid(proc.pid)
        if _wait_backend_health(api_url, timeout_s=5):
            listener_pid = listener_pids[0] if listener_pids else None
            tracked_pid = listener_pid if listener_pid else (proc.pid if _pid_still_alive(proc.pid) else None)
            _record_backend_state(
                backend_pid=tracked_pid,
                api_url=api_url,
                log_path=str(log_path),
                runtime_version=runtime_version,
            )
            if listener_pid:
                _info("Playground backend was already running on the requested port; reusing it.")
                _info(f"Backend PID: {listener_pid}")
            else:
                _info(
                    "Playground backend passed health checks before listener ownership metadata "
                    "settled; trusting the healthy backend."
                )
                if tracked_pid:
                    _info(f"Backend PID: {tracked_pid}")
            _info(f"API URL: {api_url}")
            return EXIT_OK

        if terminate_pid(proc.pid):
            print(
                "Stopped newly spawned playground backend because it did not bind "
                f"the requested port {target_port}."
            )
        if listener_pids and _wait_backend_health(api_url, timeout_s=5):
            listener_pid = listener_pids[0]
            _record_backend_state(
                backend_pid=listener_pid,
                api_url=api_url,
                log_path=str(log_path),
                runtime_version=runtime_version,
            )
            _info("Playground backend was already running on the requested port; reusing it.")
            _info(f"Backend PID: {listener_pid}")
            _info(f"API URL: {api_url}")
            return EXIT_OK

        if actual_ports:
            ports_text = ",".join(str(value) for value in actual_ports)
            print(
                "Playground backend bound unexpected port(s) "
                f"{ports_text} instead of requested port {target_port}. Check logs at {log_path}"
            )
        else:
            print(
                "Playground backend never bound the requested port and no healthy "
                f"backend was found at {api_url}. Check logs at {log_path}"
            )
        return EXIT_SERVER

    _record_backend_state(
        backend_pid=proc.pid,
        api_url=api_url,
        log_path=str(log_path),
        runtime_version=runtime_version,
    )
    _info("Playground backend is running.")
    _info(f"Backend PID: {proc.pid}")
    _info(f"API URL: {api_url}")

    if open_flag:
        render_url = str(state.get("render_url") or "")
        if render_url:
            try:
                open_url_in_browser(render_url)
            except Exception:
                pass
    return EXIT_OK


def status_backend(output_json: bool) -> int:
    state = playground_read_state()
    api = str(state.get("backend_api_url") or playground_default_api())
    alive = playground_health(api)
    pid = state.get("backend_pid")
    backend_started_at = state.get("backend_started_at")
    backend_runtime_version = str(state.get("backend_runtime_version") or "").strip()
    local_runtime_version = _runtime_playground_version(runtime_playground_dir())
    restart_recommended = bool(
        alive
        and (
            (not backend_runtime_version and bool(local_runtime_version))
            or (
                bool(backend_runtime_version)
                and bool(local_runtime_version)
                and backend_runtime_version != local_runtime_version
            )
        )
    )
    status_text = "running" if alive else "stopped"
    checked_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    backend_process_alive = _pid_still_alive(pid) if isinstance(pid, int) else False

    if output_json:
        render = _render_status_payload(state, checked_at)
        overall_status = status_text
        if status_text == "running" and render["status"] != "running":
            overall_status = "partial"
        elif status_text != "running" and render["status"] == "running":
            overall_status = "partial"
        print(
            json.dumps(
                {
                    "status": overall_status,
                    "backend": {
                        "status": status_text,
                        "process_alive": backend_process_alive,
                        "pid": pid,
                        "api_url": api,
                        "log_path": state.get("backend_log_path") or "",
                        "mode": (state.get("backend_mode") or "") if isinstance(pid, int) else "",
                        "started_at": (backend_started_at or "") if isinstance(pid, int) else "",
                        "started_at_iso": _started_at_iso(backend_started_at) if isinstance(pid, int) else "",
                        "runtime_version": backend_runtime_version,
                        "desired_runtime_version": local_runtime_version,
                        "restart_recommended": restart_recommended,
                        "health_status": "healthy" if alive else "unhealthy",
                        "health_checked_at": checked_at,
                    },
                    "render": render,
                }
            )
        )
        return EXIT_OK

    print(f"Backend: {status_text}")
    print(f"API URL: {api}")
    if pid:
        print(f"PID: {pid}")
    if state.get("backend_log_path"):
        print(f"Logs: {state.get('backend_log_path')}")
    return EXIT_OK


def _stop_tracked_backend_pid_fast(state: Dict[str, object], just_backend: bool) -> tuple[bool, list[int], list[int]]:
    tracked_pid = state.get("backend_pid")
    if not isinstance(tracked_pid, int) or tracked_pid <= 0:
        return False, [], []

    stopped: list[int] = []
    failed: list[int] = []
    if terminate_pid(tracked_pid) or not _pid_still_alive(tracked_pid):
        stopped.append(tracked_pid)
    else:
        failed.append(tracked_pid)

    if not just_backend:
        render_pid = state.get("render_pid")
        if isinstance(render_pid, int) and render_pid > 0:
            if terminate_pid(render_pid) or not _pid_still_alive(render_pid):
                stopped.append(render_pid)
            else:
                failed.append(render_pid)

    stopped, failed = _reconcile_stopped_pids(stopped, failed)
    return True, _unique_pids(stopped), _unique_pids(failed)


def _stoppable_listener_pids(state: Dict[str, object], target_port: int, listener_pids: list[int]) -> list[int]:
    tracked_pid = state.get("backend_pid")
    current_home_runner_pids = set(_list_current_home_playground_runner_pids())
    related_runner_pids = set(_list_related_playground_runner_pids(target_port))
    candidates: list[int] = []
    for candidate in listener_pids:
        if _should_stop_port_listener(candidate, target_port):
            candidates.append(candidate)
            continue
        if candidate in current_home_runner_pids or candidate in related_runner_pids:
            candidates.append(candidate)
            continue
        if isinstance(tracked_pid, int) and candidate == tracked_pid:
            candidates.append(candidate)
    return _unique_pids(candidates)


def stop_backend(
    output_json: bool,
    just_backend: bool,
    *,
    prefer_tracked_pid_only: bool = False,
) -> int:
    state = playground_read_state()
    pid = state.get("backend_pid")
    render_pid = state.get("render_pid")
    api = str(state.get("backend_api_url") or playground_default_api())
    target_port = _backend_port_from_url(api)
    used_fast_path = False
    stopped: list[int] = []
    failed: list[int] = []
    if prefer_tracked_pid_only:
        used_fast_path, stopped, failed = _stop_tracked_backend_pid_fast(state, just_backend)

    if not used_fast_path:
        candidate_pids = []
        runner_cleanup_pids: list[int] = _list_playground_runner_pids()
        if isinstance(pid, int):
            candidate_pids.append(pid)
        listener_pids = _pids_listening_on_port(target_port)
        candidate_pids.extend(_stoppable_listener_pids(state, target_port, listener_pids))
        if (
            isinstance(pid, int)
            and pid > 0
            and target_port > 0
            and listener_pids
            and pid not in listener_pids
            and playground_health(api)
        ):
            # If the recorded backend PID is stale but the recorded API URL is
            # still serving health checks on the target port, trust the live
            # listener as the backend we meant to stop.
            candidate_pids.extend(listener_pids)
        candidate_pids.extend(_list_related_playground_runner_pids(target_port))
        if not just_backend and isinstance(render_pid, int):
            candidate_pids.append(render_pid)

        runner_cleanup_pid_set = set(_unique_pids(runner_cleanup_pids))
        for candidate in _unique_pids(candidate_pids):
            if terminate_pid(candidate):
                stopped.append(candidate)
            elif not _pid_still_alive(candidate):
                stopped.append(candidate)
            elif candidate in runner_cleanup_pid_set:
                # Runner cleanup is best-effort. Do not fail backend stop if an
                # unrelated or already-managed runner process cannot be terminated.
                continue
            else:
                failed.append(candidate)

        stopped, failed = _reconcile_stopped_pids(stopped, failed)

    state.pop("backend_pid", None)
    state.pop("backend_api_url", None)
    state.pop("backend_log_path", None)
    if not just_backend:
        state.pop("render_pid", None)
        state.pop("render_url", None)
        state.pop("render_log_path", None)
    playground_write_state(state)

    if used_fast_path and not failed:
        unmanaged_alive = False
    else:
        remaining_backend_pids = _unique_pids(
            [candidate for candidate in _pids_listening_on_port(target_port) if _should_stop_port_listener(candidate, target_port)]
            + _list_related_playground_runner_pids(target_port)
        )
        unmanaged_alive = bool(remaining_backend_pids) or playground_health(api)

    if output_json:
        print(
            json.dumps(
                {
                    "ok": len(failed) == 0 and not unmanaged_alive,
                    "stopped_count": len(stopped),
                    "failed_count": len(failed),
                    "stopped_pids": stopped,
                    "failed_pids": failed,
                    "unmanaged_backend_running": unmanaged_alive,
                    "api_url": api,
                }
            )
        )
        return EXIT_OK if not failed and not unmanaged_alive else EXIT_SERVER

    if stopped:
        _info(f"Stopped {len(stopped)} playground process(es): {','.join(str(x) for x in stopped)}")
        return EXIT_OK
    _info("No running playground process found.")
    return EXIT_OK


handle = build_command_handler(command_name="backend", router=router, usage_factory=usage_backend_computed)


def build_start_params(parsed: ParsedRouteOptions) -> StartParams:
    return StartParams(
        port=str(parsed.options.get("port") or "4173").lstrip(":"),
        open_flag=not bool(parsed.options.get("no_open")),
        install_mode=(
            "force"
            if bool(parsed.options.get("install"))
            else ("skip" if bool(parsed.options.get("no_install")) else "auto")
        ),
    )


def build_status_params(parsed: ParsedRouteOptions) -> StatusParams:
    return StatusParams(output_json=bool(parsed.options.get("json")))


def build_stop_params(parsed: ParsedRouteOptions) -> StopParams:
    return StopParams(
        output_json=bool(parsed.options.get("json")),
        just_backend=bool(parsed.options.get("just_backend")),
    )


@router.route_typed(
    "refresh-runtime",
    "sync-runtime",
    summary="Download or refresh the local playground runtime bundle.",
    usage="deepline backend refresh-runtime",
    options=[],
    params_parser=lambda _parsed: None,
)
def handle_refresh_runtime(_base_url: str, _env: Dict[str, str], _params: None) -> int:
    return refresh_runtime(_base_url)


@router.route_typed(
    "start",
    summary="Start the playground backend process.",
    description="Starts a background backend and writes PID/log metadata to local state.",
    usage="deepline backend start [--port PORT|:PORT] [--open|--no-open] [--install|--no-install]",
    options=[
        OptionSpec("--port", "Port to report for backend API URL (default: 4173).", takes_value=True, value_name="PORT|:PORT", key="port"),
        OptionSpec("--open", "Open render URL after start when available.", key="open"),
        OptionSpec("--no-open", "Disable browser open behavior.", key="no_open"),
        OptionSpec("--install", "Force reinstall runtime playground dependencies.", key="install"),
        OptionSpec("--no-install", "Skip dependency installation checks.", key="no_install"),
    ],
    params_parser=build_start_params,
)
def handle_start(_base_url: str, _env: Dict[str, str], params: StartParams) -> int:
    if _assume_backend_ready_env():
        print("Backend assumed ready (DEEPLINE_ASSUME_BACKEND_READY=1); skipping start_backend.")
        return EXIT_OK
    return start_backend(_base_url, params.port, params.open_flag, params.install_mode)


@router.route_typed(
    "status",
    summary="Show backend status and health.",
    usage="deepline backend status [--json]",
    options=[OptionSpec("--json", "Emit structured JSON status payload.", key="json")],
    params_parser=build_status_params,
)
def handle_status(_base_url: str, _env: Dict[str, str], params: StatusParams) -> int:
    return status_backend(params.output_json)


@router.route_typed(
    "stop",
    summary="Stop backend process (and render unless --just-backend).",
    usage="deepline backend stop [--json] [--just-backend]",
    options=[
        OptionSpec("--json", "Emit structured JSON stop payload.", key="json"),
        OptionSpec("--just-backend", "Only stop backend; keep render process running.", key="just_backend"),
    ],
    params_parser=build_stop_params,
)
def handle_stop(_base_url: str, _env: Dict[str, str], params: StopParams) -> int:
    if _assume_backend_ready_env():
        print("Backend assumed ready (DEEPLINE_ASSUME_BACKEND_READY=1); skipping stop_backend.")
        return EXIT_OK
    return stop_backend(params.output_json, params.just_backend)
