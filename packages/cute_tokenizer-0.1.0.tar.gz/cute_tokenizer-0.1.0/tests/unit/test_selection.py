"""Unit tests for cute_tokenizer.selection."""

from __future__ import annotations

from collections import Counter

import pytest

from cute_tokenizer.selection import (
    coverage_of,
    is_good_token,
    select_by_coverage,
)


class TestIsGoodToken:
    @pytest.mark.parametrize("tok", ["def", "(", ",", ":", "==", "user_id", "🌍"])
    def test_accepts(self, tok: str) -> None:
        assert is_good_token(tok)

    @pytest.mark.parametrize("tok", ["", " ", "\t", "\n", "  \n  "])
    def test_rejects_whitespace(self, tok: str) -> None:
        assert not is_good_token(tok)

    def test_rejects_too_long(self) -> None:
        assert not is_good_token("x" * 100, max_len=50)

    def test_does_not_reject_single_punctuation(self) -> None:
        """v2.1 had a bug rejecting these. Confirm fix."""
        for tok in ["(", ")", ",", ":", ";", ".", "[", "]", "{", "}", "="]:
            assert is_good_token(tok), f"{tok!r} must be PUA-eligible"


class TestSelectByCoverage:
    def test_empty_freq(self) -> None:
        assert select_by_coverage(Counter()) == []

    def test_zero_total(self) -> None:
        assert select_by_coverage(Counter({"a": 0, "b": 0})) == []

    def test_priority_order(self) -> None:
        freq = Counter({"a": 100, "b": 50, "c": 25})
        out = select_by_coverage(freq, coverage_target=1.0)
        assert out == ["a", "b", "c"]

    def test_lexicographic_tiebreak(self) -> None:
        freq = Counter({"banana": 10, "apple": 10, "cherry": 10})
        out = select_by_coverage(freq, coverage_target=1.0)
        assert out == ["apple", "banana", "cherry"]

    def test_coverage_threshold_stops_early(self) -> None:
        # Total = 100. 90% = 90. {a:50, b:30, c:15, d:5} → a+b+c=95 ≥ 90.
        freq = Counter({"a": 50, "b": 30, "c": 15, "d": 5})
        out = select_by_coverage(freq, coverage_target=0.9)
        assert "a" in out
        assert "b" in out
        # We should stop as soon as coverage hits 90%, not include everything.
        assert len(out) <= 4

    def test_filtered_tokens_skipped(self) -> None:
        freq = Counter({"def": 100, "  ": 200, "x" * 100: 50, "return": 90})
        out = select_by_coverage(freq, coverage_target=1.0, max_len=50)
        assert "def" in out
        assert "  " not in out
        assert "x" * 100 not in out
        assert "return" in out

    def test_max_tokens_cap(self) -> None:
        freq = Counter({chr(0x61 + i): 100 - i for i in range(20)})
        out = select_by_coverage(freq, coverage_target=1.0, max_tokens=5)
        assert len(out) == 5

    def test_invalid_coverage_target(self) -> None:
        with pytest.raises(ValueError):
            select_by_coverage(Counter({"a": 1}), coverage_target=0.0)
        with pytest.raises(ValueError):
            select_by_coverage(Counter({"a": 1}), coverage_target=1.5)

    def test_determinism(self) -> None:
        """Same input → same output, every time."""
        freq = Counter({chr(0x61 + i): (i * 7) % 11 + 1 for i in range(26)})
        out1 = select_by_coverage(freq, coverage_target=0.85)
        out2 = select_by_coverage(freq.copy(), coverage_target=0.85)
        assert out1 == out2


class TestCoverageOf:
    def test_full_coverage(self) -> None:
        freq = Counter({"a": 5, "b": 3, "c": 2})
        assert coverage_of(freq, ["a", "b", "c"]) == 1.0

    def test_partial(self) -> None:
        freq = Counter({"a": 5, "b": 3, "c": 2})
        assert coverage_of(freq, ["a"]) == 0.5

    def test_unknown_token(self) -> None:
        freq = Counter({"a": 5, "b": 3})
        assert coverage_of(freq, ["a", "missing"]) == 5 / 8

    def test_empty_freq(self) -> None:
        assert coverage_of(Counter(), ["a"]) == 0.0
