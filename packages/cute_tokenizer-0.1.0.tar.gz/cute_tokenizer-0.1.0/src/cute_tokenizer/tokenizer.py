"""HuggingFace-compatible tokenizer wrapper.

Subclasses `PreTrainedTokenizerFast` so users get a drop-in replacement for
`AutoTokenizer` in any HF training/inference loop.

Usage:
    from cute_tokenizer import CUTETokenizerFast
    tok = CUTETokenizerFast.from_pretrained("./output")
    ids = tok("def hello(): return 42").input_ids
    text = tok.decode(ids)

The two-line wrapper UX the user asked for. Pre-tokenization runs in Python
(Aho-Corasick over the PUA mapping); the trained byte-level BPE handles
the residual stream in Rust.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from transformers import PreTrainedTokenizerFast

from .decode import reverse_pua_substitute
from .pretokenizer import pretokenize_to_string
from .pua import PUAMapping
from .trainer import load_mapping

if TYPE_CHECKING:
    pass


_MAPPING_FILENAME = "cute_mapping.json"


class CUTETokenizerFast(PreTrainedTokenizerFast):
    """CUTE wrapper. Performs Python-side PUA substitution before delegating
    encoding to the underlying byte-level BPE tokenizer.

    Inherits everything else from `PreTrainedTokenizerFast` — padding,
    truncation, batch encoding, special tokens, save/load semantics.
    """

    # Static map of constructor kwarg name → on-disk filename. Required by
    # PreTrainedTokenizerFast machinery; values are immutable strings, so
    # the class-level dict is safe despite RUF012's general advice.
    vocab_files_names = {  # type: ignore[assignment]  # noqa: RUF012
        "tokenizer_file": "tokenizer.json",
        "cute_mapping_file": _MAPPING_FILENAME,
    }

    def __init__(
        self,
        tokenizer_file: str | Path | None = None,
        cute_mapping_file: str | Path | None = None,
        **kwargs: Any,
    ) -> None:
        if tokenizer_file is None:
            raise ValueError("CUTETokenizerFast requires `tokenizer_file`")
        if cute_mapping_file is None:
            raise ValueError("CUTETokenizerFast requires `cute_mapping_file`")

        # PreTrainedTokenizerFast loads the underlying tokenizer.json itself.
        super().__init__(tokenizer_file=str(tokenizer_file), **kwargs)

        self._cute_mapping: PUAMapping = load_mapping(Path(cute_mapping_file))
        self._cute_mapping_file = str(cute_mapping_file)

    # ---------------------------------------------------------------------
    # Persistence
    # ---------------------------------------------------------------------

    @property
    def cute_mapping(self) -> PUAMapping:
        return self._cute_mapping

    def _save_pretrained(  # type: ignore[override]
        self,
        save_directory: Any,
        file_names: tuple[str, ...],
        legacy_format: bool | None = None,
        filename_prefix: str | None = None,
    ) -> tuple[str, ...]:
        """Save the BPE tokenizer.json + cute_mapping.json + tokenizer_config.json.

        We hook here (rather than `save_vocabulary`) because Fast tokenizers
        bypass `save_vocabulary` entirely — `_save_pretrained` is the real
        extension point.
        """
        save_directory = Path(save_directory)
        save_directory.mkdir(parents=True, exist_ok=True)

        # Let the parent write tokenizer.json + tokenizer_config.json + special_tokens_map.json
        out = super()._save_pretrained(
            str(save_directory),
            file_names=file_names,
            legacy_format=legacy_format,
            filename_prefix=filename_prefix,
        )

        prefix = f"{filename_prefix}-" if filename_prefix else ""
        mapping_path = save_directory / f"{prefix}{_MAPPING_FILENAME}"

        from .trainer import save_mapping

        save_mapping(self._cute_mapping, mapping_path)

        return (*out, str(mapping_path))

    # ---------------------------------------------------------------------
    # Encode path (override at the lowest convenient level)
    # ---------------------------------------------------------------------

    def _cute_pretokenize(self, text: str) -> str:
        """Run PUA substitution + identifier splitting on a single string."""
        return pretokenize_to_string(text, self._cute_mapping)

    def _batch_encode_plus(  # type: ignore[override]
        self,
        batch_text_or_text_pairs: Any,
        **kwargs: Any,
    ) -> Any:
        return super()._batch_encode_plus(
            self._preprocess_batch(batch_text_or_text_pairs), **kwargs
        )

    def _encode_plus(  # type: ignore[override]
        self,
        text: Any,
        text_pair: Any | None = None,
        **kwargs: Any,
    ) -> Any:
        text = self._preprocess_one(text)
        if text_pair is not None:
            text_pair = self._preprocess_one(text_pair)
        return super()._encode_plus(text, text_pair=text_pair, **kwargs)

    def _preprocess_one(self, x: Any) -> Any:
        if isinstance(x, str):
            return self._cute_pretokenize(x)
        # Pre-tokenized input (list of strings) — substitute each piece.
        if isinstance(x, list) and all(isinstance(p, str) for p in x):
            return [self._cute_pretokenize(p) for p in x]
        return x

    def _preprocess_batch(self, batch: Any) -> Any:
        if isinstance(batch, list):
            return [self._preprocess_pair_or_text(b) for b in batch]
        return batch

    def _preprocess_pair_or_text(self, item: Any) -> Any:
        if isinstance(item, tuple) and len(item) == 2:
            a, b = item
            return (self._preprocess_one(a), self._preprocess_one(b))
        return self._preprocess_one(item)

    # ---------------------------------------------------------------------
    # Decode path
    # ---------------------------------------------------------------------

    def _decode(  # type: ignore[override]
        self,
        token_ids: Any,
        skip_special_tokens: bool = False,
        clean_up_tokenization_spaces: bool | None = None,
        **kwargs: Any,
    ) -> str:
        text = super()._decode(
            token_ids,
            skip_special_tokens=skip_special_tokens,
            clean_up_tokenization_spaces=clean_up_tokenization_spaces,
            **kwargs,
        )
        return reverse_pua_substitute(text, self._cute_mapping)

    def convert_tokens_to_string(self, tokens: list[str]) -> str:  # type: ignore[override]
        text = super().convert_tokens_to_string(tokens)
        return reverse_pua_substitute(text, self._cute_mapping)


__all__ = ["CUTETokenizerFast"]
