"""Configuration for the CUTE tokenizer build pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

DEFAULT_SPECIAL_TOKENS: tuple[str, ...] = (
    "<pad>",
    "<s>",
    "</s>",
    "<unk>",
    "<|endoftext|>",
    "<|fim_prefix|>",
    "<|fim_middle|>",
    "<|fim_suffix|>",
    "<|file_sep|>",
    "<|repo_name|>",
)

DEFAULT_CODE_EXTENSIONS: tuple[str, ...] = (
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".cs",
    ".rs",
    ".go",
    ".rb",
    ".php",
    ".swift",
    ".kt",
    ".scala",
    ".sh",
    ".sql",
    ".html",
    ".css",
    ".scss",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".md",
)


@dataclass(frozen=True)
class CUTEConfig:
    """All knobs for a CUTE build, in one place.

    Frozen so hashing/comparison is well-defined and the manifest serializer
    can dump a stable representation.
    """

    vocab_size: int = 80_000
    coverage_target: float = 0.90
    max_token_len: int = 50
    boost_weight: float = 0.3
    min_bpe_budget: int = 8_000
    min_frequency: int = 2
    seed: int = 42
    extensions: tuple[str, ...] = DEFAULT_CODE_EXTENSIONS
    special_tokens: tuple[str, ...] = DEFAULT_SPECIAL_TOKENS
    workers: int = 0  # 0 means os.cpu_count()
    shard_size_bytes: int = 64 * 1024 * 1024  # 64 MiB per shard
    license_allowlist: tuple[str, ...] = (
        "MIT",
        "Apache-2.0",
        "BSD-3-Clause",
        "BSD-2-Clause",
        "ISC",
        "Apache 2.0",
        "Apache License 2.0",
    )
    enable_secret_scrub: bool = True
    enable_license_filter: bool = False  # off by default; opt-in

    def __post_init__(self) -> None:
        if not 0.0 < self.coverage_target < 1.0:
            raise ValueError(f"coverage_target must be in (0,1), got {self.coverage_target}")
        if self.vocab_size < 1024:
            raise ValueError(f"vocab_size too small: {self.vocab_size}")
        if self.max_token_len < 1:
            raise ValueError(f"max_token_len must be positive: {self.max_token_len}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


__all__ = ["DEFAULT_CODE_EXTENSIONS", "DEFAULT_SPECIAL_TOKENS", "CUTEConfig"]
