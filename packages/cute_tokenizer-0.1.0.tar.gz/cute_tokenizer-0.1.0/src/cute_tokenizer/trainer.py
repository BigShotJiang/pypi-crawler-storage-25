"""End-to-end build pipeline: corpus → frequency → selection → PUA → BPE.

Architecture decision: PUA chars are added to the trained BPE tokenizer as
**AddedTokens** (post-training). This:
  - Gives each PUA char its own atomic vocab ID — never byte-split.
  - Avoids the NormalizedString offset-tracking complexity of a custom
    Python pre-tokenizer (PUA chars have a different length than the
    words they replace, which breaks the in-Rust slicing arithmetic).
  - Produces a fully portable `tokenizer.json` — any HF loader sees real
    vocab entries for the PUA chars.

The wrapper class (`CUTETokenizerFast`) substitutes mapped tokens with their
PUA chars in Python, then hands the substituted string to the tokenizer.
The tokenizer's AddedToken matcher catches PUA chars atomically; everything
else flows through ByteLevel + BPE as usual.

Output artifacts:
    output_dir/
    ├── shards/                 # corpus shards (intermediate)
    ├── tokenizer.json          # ByteLevel BPE + PUA AddedTokens — portable
    ├── cute_mapping.json       # word ↔ PUA codepoint mapping (for the wrapper)
    ├── tokenizer_config.json   # HF auto-load config with auto_map
    └── build_manifest.json     # reproducibility audit
"""

from __future__ import annotations

import json
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from tokenizers import AddedToken, Tokenizer, decoders, models, trainers
from tokenizers.pre_tokenizers import ByteLevel

from .config import CUTEConfig
from .corpus import ingest_corpus, iter_shard_texts
from .frequency import count_frequencies
from .manifest import (
    hash_corpus_shards,
    hash_vocab,
    make_manifest,
)
from .pua import PUAMapping, assign_pua_mapping
from .selection import coverage_of, select_by_coverage

# ---------------------------------------------------------------------------
# Mapping persistence
# ---------------------------------------------------------------------------


def save_mapping(mapping: PUAMapping, path: Path) -> None:
    """Write the mapping as JSON. Word → PUA codepoint integer for clarity."""
    payload = {
        "version": 1,
        "size": mapping.size,
        "skipped_codepoints": list(mapping.skipped_codepoints),
        # Store as codepoint ints rather than chars to avoid JSON encoding
        # surprises for surrogate-area characters / Plane 16.
        "word_to_codepoint": {w: ord(c) for w, c in mapping.word_to_pua.items()},
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_mapping(path: Path) -> PUAMapping:
    """Inverse of `save_mapping`."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    word_to_pua = {w: chr(cp) for w, cp in payload["word_to_codepoint"].items()}
    pua_to_word = {c: w for w, c in word_to_pua.items()}
    return PUAMapping(
        word_to_pua=word_to_pua,
        pua_to_word=pua_to_word,
        skipped_codepoints=tuple(payload.get("skipped_codepoints", [])),
    )


# ---------------------------------------------------------------------------
# BPE training
# ---------------------------------------------------------------------------


def _build_bpe_tokenizer() -> Tokenizer:
    """Construct an untrained Tokenizer with vanilla ByteLevel pre-tokenizer."""
    tok = Tokenizer(models.BPE(unk_token=None))
    tok.pre_tokenizer = ByteLevel(add_prefix_space=False, use_regex=True, trim_offsets=True)
    tok.decoder = decoders.ByteLevel()
    return tok


def _train_bpe(
    tokenizer: Tokenizer,
    shards_dir: Path,
    mapping: PUAMapping,
    config: CUTEConfig,
) -> None:
    """Run BPE training, then add PUA chars as AddedTokens.

    Vocab budget split: BPE merges + 256 byte-level alphabet + special_tokens
    + PUA AddedTokens = config.vocab_size.
    """
    bpe_vocab_size = config.vocab_size - len(mapping.word_to_pua)
    bpe_merge_budget = bpe_vocab_size - len(config.special_tokens) - 256

    if bpe_merge_budget < config.min_bpe_budget:
        raise ValueError(
            f"BPE merge budget too small: {bpe_merge_budget} < {config.min_bpe_budget}. "
            f"Lower coverage_target (currently {config.coverage_target}) or raise "
            f"vocab_size (currently {config.vocab_size})."
        )

    trainer = trainers.BpeTrainer(
        vocab_size=bpe_vocab_size,
        special_tokens=list(config.special_tokens),
        initial_alphabet=list(ByteLevel.alphabet()),
        min_frequency=config.min_frequency,
        show_progress=False,
    )

    tokenizer.train_from_iterator(iter_shard_texts(shards_dir), trainer=trainer)

    # Add PUA chars as atomic vocab entries. `normalized=False` keeps them
    # exact-match; `single_word=False` allows them to appear inside words
    # (which is essential — PUA chars often replace word-internal substrings).
    pua_added = [
        AddedToken(
            ch,
            single_word=False,
            lstrip=False,
            rstrip=False,
            normalized=False,
            special=False,
        )
        for ch in mapping.pua_chars
    ]
    if pua_added:
        tokenizer.add_tokens(pua_added)


# ---------------------------------------------------------------------------
# Public entrypoint
# ---------------------------------------------------------------------------


def build_cute(
    corpus_dir: Path,
    output_dir: Path,
    config: CUTEConfig | None = None,
) -> Path:
    """Run the full CUTE build. Returns the path to the manifest file.

    Idempotent: re-running with the same inputs reproduces the same artifacts.
    """
    if config is None:
        config = CUTEConfig()

    random.seed(config.seed)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    timing: dict[str, float] = {}

    # Phase 1 — ingest corpus
    t0 = time.perf_counter()
    ingest_stats = ingest_corpus(
        corpus_dir=Path(corpus_dir),
        out_dir=output_dir,
        extensions=config.extensions,
        shard_size_bytes=config.shard_size_bytes,
        enable_secret_scrub=config.enable_secret_scrub,
        enable_license_filter=config.enable_license_filter,
        license_allowlist=config.license_allowlist,
    )
    timing["ingest"] = time.perf_counter() - t0
    shards_dir = output_dir / "shards"

    # Phase 2 — frequency analysis
    t0 = time.perf_counter()
    freq = count_frequencies(
        shards_dir=shards_dir,
        boost_weight=config.boost_weight,
        max_token_len=config.max_token_len,
        workers=config.workers,
    )
    timing["frequency"] = time.perf_counter() - t0

    if not freq:
        raise RuntimeError(
            f"Corpus at {corpus_dir} produced zero tokens. "
            "Check that the directory contains files matching config.extensions."
        )

    # Phase 3 — selection + PUA assignment
    t0 = time.perf_counter()
    selected = select_by_coverage(
        freq,
        coverage_target=config.coverage_target,
        max_len=config.max_token_len,
    )
    coverage = coverage_of(freq, selected)
    mapping = assign_pua_mapping(
        selected,
        corpus_pua_codepoints=ingest_stats.pua_codepoints_in_corpus,
    )
    save_mapping(mapping, output_dir / "cute_mapping.json")
    timing["selection_and_pua"] = time.perf_counter() - t0

    # Phase 4 — BPE training + AddedTokens
    t0 = time.perf_counter()
    tok = _build_bpe_tokenizer()
    _train_bpe(tok, shards_dir, mapping, config)
    tok.save(str(output_dir / "tokenizer.json"))
    timing["bpe_training"] = time.perf_counter() - t0

    # Phase 5 — tokenizer_config.json (so HF auto_map works)
    _write_tokenizer_config(output_dir, config)

    # Phase 6 — manifest
    t0 = time.perf_counter()
    vocab = tok.get_vocab()
    manifest = make_manifest(
        config=config.to_dict(),
        corpus_hash=hash_corpus_shards(shards_dir),
        vocab_hash=hash_vocab(vocab),
        pua_mapping_size=mapping.size,
        pua_codepoints_in_corpus=sorted(ingest_stats.pua_codepoints_in_corpus),
        coverage_achieved=coverage,
        timing_seconds=timing,
        ingest_stats={
            k: (sorted(v) if isinstance(v, frozenset) else v)
            for k, v in asdict(ingest_stats).items()
        },
    )
    manifest_path = output_dir / "build_manifest.json"
    manifest.write(manifest_path)
    timing["manifest"] = time.perf_counter() - t0

    return manifest_path


def _write_tokenizer_config(output_dir: Path, config: CUTEConfig) -> None:
    """Write `tokenizer_config.json` so `AutoTokenizer.from_pretrained` works."""
    cfg: dict[str, Any] = {
        "tokenizer_class": "CUTETokenizerFast",
        "auto_map": {
            "AutoTokenizer": [None, "cute_tokenizer.tokenizer.CUTETokenizerFast"],
        },
        "model_max_length": 1_000_000,
        "padding_side": "right",
        "truncation_side": "right",
        "bos_token": "<s>",
        "eos_token": "</s>",
        "pad_token": "<pad>",
        "unk_token": "<unk>",
    }
    (output_dir / "tokenizer_config.json").write_text(
        json.dumps(cfg, indent=2),
        encoding="utf-8",
    )


__all__ = ["build_cute", "load_mapping", "save_mapping"]
