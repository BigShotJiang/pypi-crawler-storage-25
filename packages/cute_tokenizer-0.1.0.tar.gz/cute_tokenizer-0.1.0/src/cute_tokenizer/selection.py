"""Coverage-based PUA token selection.

Selects the smallest set of tokens whose cumulative frequency reaches
`coverage_target` (default 90%). The selection is deterministic given the
input frequency table — frequency-then-lexicographic order.
"""

from __future__ import annotations

from collections import Counter

# Tokens longer than this are excluded from PUA assignment regardless of frequency.
# A 50-char token costs 50 chars to spell out but only saves 1 token slot.
DEFAULT_MAX_LEN = 50


def is_good_token(tok: str, max_len: int = DEFAULT_MAX_LEN) -> bool:
    """Filter for PUA-eligible tokens.

    Rejects:
    - Pure whitespace (we'd never substitute it; BPE handles whitespace)
    - Tokens longer than `max_len`
    - The empty string

    NOTE: Does NOT reject single-char punctuation. The v2.1 draft's filter
    `all(ch in "_-=.,;:()[]{}'\\"`")` was wrong — those chars are exactly
    the high-frequency tokens worth compressing.
    """
    if not tok:
        return False
    if tok.isspace():
        return False
    return len(tok) <= max_len


def select_by_coverage(
    freq: Counter[str],
    coverage_target: float = 0.90,
    max_len: int = DEFAULT_MAX_LEN,
    max_tokens: int | None = None,
) -> list[str]:
    """Select tokens covering `coverage_target` fraction of total frequency.

    Returns tokens in deterministic order: descending count, then ascending
    lexicographic for ties. Tokens that fail `is_good_token` are skipped
    (their counts still contribute to the denominator).

    Parameters
    ----------
    freq
        Token frequency counter. Treated read-only.
    coverage_target
        Stop selecting once cumulative frequency of selected tokens reaches
        this fraction of `sum(freq.values())`.
    max_len
        Skip tokens longer than this many characters.
    max_tokens
        Optional hard cap on the number of selected tokens.

    Returns
    -------
    List of selected tokens in priority order (most frequent first).
    """
    if not 0.0 < coverage_target <= 1.0:
        raise ValueError(f"coverage_target must be in (0,1], got {coverage_target}")

    total = sum(freq.values())
    if total == 0:
        return []

    # Sort by (-count, token) for deterministic, frequency-priority order.
    sorted_items = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))

    selected: list[str] = []
    cumulative = 0
    threshold = coverage_target * total

    for token, count in sorted_items:
        if not is_good_token(token, max_len=max_len):
            continue
        selected.append(token)
        cumulative += count
        if max_tokens is not None and len(selected) >= max_tokens:
            break
        if cumulative >= threshold:
            break

    return selected


def coverage_of(freq: Counter[str], tokens: list[str]) -> float:
    """Compute the fraction of total frequency covered by `tokens`.

    Useful for diagnostics / manifest reporting.
    """
    total = sum(freq.values())
    if total == 0:
        return 0.0
    covered = sum(freq.get(t, 0) for t in tokens)
    return covered / total


__all__ = ["DEFAULT_MAX_LEN", "coverage_of", "is_good_token", "select_by_coverage"]
