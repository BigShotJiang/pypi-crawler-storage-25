"""CUTE — Compact Unicode Token Encoding.

Public API:
    build_cute      — train a CUTE tokenizer from a corpus directory.
    CUTEConfig      — all knobs for the build pipeline.
    CUTETokenizerFast — HuggingFace-compatible inference wrapper.
    PUAMapping      — word ↔ PUA character mapping.
"""

from __future__ import annotations

import os as _os

# Silence the "None of PyTorch, TensorFlow, or Flax have been found" warning
# that `transformers` emits at import. CUTE only needs the tokenizer layer, not
# the model layer, so this warning is irrelevant. Must be set BEFORE the first
# `transformers` import — putting it here covers both library and CLI paths.
_os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
_os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")

from ._version import __version__
from .config import CUTEConfig
from .pua import PUAMapping
from .tokenizer import CUTETokenizerFast
from .trainer import build_cute, load_mapping, save_mapping

__all__ = [
    "CUTEConfig",
    "CUTETokenizerFast",
    "PUAMapping",
    "__version__",
    "build_cute",
    "load_mapping",
    "save_mapping",
]
