# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

from airflow.exceptions import AirflowException

# Todo: we cannot have a backcompat import for AirflowException yet
# because PodMutationHookException is redefined in airflow.exception
# Remove this and either import AirflowException from common.sdk or
# import it from airflow.sdk.exceptions when PodMutationHookException
# is removed from airflow.exceptions


class PodMutationHookException(AirflowException):
    """Raised when exception happens during Pod Mutation Hook execution."""


class PodReconciliationError(AirflowException):
    """Raised when an error is encountered while trying to merge pod configs."""


class KubernetesApiError(AirflowException):
    """Raised when an error is encountered while trying access Kubernetes API."""


class KubernetesApiPermissionError(AirflowException):
    """Raised when an error is encountered while trying access Kubernetes API."""
