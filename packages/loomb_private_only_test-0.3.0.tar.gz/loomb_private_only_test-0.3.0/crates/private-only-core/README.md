# Private-Only Release Sample

This repository demonstrates the single-repo version of the SDK release flow:

- release planning and GitHub Releases happen in this private repo
- there is no public mirror repository
- the Python package wraps a small Rust library through PyO3
- the release workflow creates a GitHub App token, checks out the private
  `loomb-oai/sdk-release-action` repo, and runs that action locally
- publishing targets PyPI from this repository with Trusted Publishing
- publishing targets crates.io from this repository with Cargo and a
  `CARGO_REGISTRY_TOKEN` secret

Repository shape:

- `crates/private-only-core`
  - Rust business logic
- `packages/python-sdk`
  - PyO3 extension module and Python package
- `.github/workflows/release-bot.yml`
  - shared release entrypoint

Example Python use:

```python
from private_only_sdk import get_magic_number

get_magic_number()
```

Release shape:

- `.github/sdk-release.yml` declares `releases.github.target: source`
- scheduled jobs dispatch `PUB_BETA` and `CUT_RC`
- manual dispatch can run `PUB_ALPHA`, `PUB_BETA`, `CUT_RC`, or `PROMOTE_RC`
- the release job creates the GitHub Release in this repo, then the PyPI publish
  job uploads the Python distributions
- the reusable action handles crates.io internally with Cargo's
  dry-run-then-publish flow, adding `--allow-dirty` because channel versions are
  stamped into the checked-out manifest during the publish job

Counter: 3
