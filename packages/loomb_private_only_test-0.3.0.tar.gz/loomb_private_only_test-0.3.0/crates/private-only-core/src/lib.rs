const MAGIC_NUMBER: i64 = 33;

pub fn get_magic_number() -> i64 {
    MAGIC_NUMBER
}

#[cfg(test)]
mod tests {
    use super::get_magic_number;

    #[test]
    fn returns_magic_number() {
        assert_eq!(get_magic_number(), 33);
    }
}
