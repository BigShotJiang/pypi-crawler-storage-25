# Changelog

## [0.3.0](https://github.com/loomb-oai/test-private-only-repo/compare/rust-core-v0.2.0...rust-core-v0.3.0) (2026-05-21)


### Features

* **samples:** expose get_magic_number demo API ([06d9dde](https://github.com/loomb-oai/test-private-only-repo/commit/06d9ddece51abec192d404096d6ca7ae693db1d1))
* **samples:** set magic number to 33 ([8817033](https://github.com/loomb-oai/test-private-only-repo/commit/881703370c395100a34803cb426c4c40ccbbd716))
* **samples:** set magic number to 33 ([a1492cb](https://github.com/loomb-oai/test-private-only-repo/commit/a1492cb63163ab0e50b8014c753c84cac4582c07))
* **samples:** set private-only magic number to 21 ([f956b14](https://github.com/loomb-oai/test-private-only-repo/commit/f956b148fac5c80297c602e726557fef79e8e956))
* **samples:** set private-only magic number to 21 ([cbea156](https://github.com/loomb-oai/test-private-only-repo/commit/cbea156ba6c97a0b6b8c389feae8e47d9fc6f9d9))
* **sdk:** add rust-backed goodbye variant ([201706b](https://github.com/loomb-oai/test-private-only-repo/commit/201706b3d0303c7315bc986dc1bdd2cd67a14ea2))
* **sdk:** add rust-backed goodbye variant ([909fab1](https://github.com/loomb-oai/test-private-only-repo/commit/909fab1940aeab8f371eef3e94e7c29374b1fd9d))
* **sdk:** rename rust greeting to australian gday API ([700ed10](https://github.com/loomb-oai/test-private-only-repo/commit/700ed105aaa1e34fde2d0c17c76a04bfe1b6c3e4))

## [0.2.0](https://github.com/loomb-oai/test-private-only-repo/compare/rust-core-v0.1.0...rust-core-v0.2.0) (2026-05-19)


### Features

* add private-only release sample ([bc8e9ec](https://github.com/loomb-oai/test-private-only-repo/commit/bc8e9ecccc93f5580715dbca5482a0b5fdb4a7ec))
* wire crates.io publishing sample ([4749471](https://github.com/loomb-oai/test-private-only-repo/commit/474947115aecdb46989571e264864131b1f0af12))
* wire crates.io publishing sample ([51dd10e](https://github.com/loomb-oai/test-private-only-repo/commit/51dd10e9d272b9c4c0256045c27fb5ec98ff4059))
