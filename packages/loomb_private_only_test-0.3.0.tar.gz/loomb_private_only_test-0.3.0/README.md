# Private Only Python SDK

Python package wrapping the repository's Rust core library with PyO3.

```python
from private_only_sdk import get_magic_number

get_magic_number()
```
