from ._native import get_magic_number

__version__ = "0.3.0"


__all__ = [
    "__version__",
    "get_magic_number",
]
