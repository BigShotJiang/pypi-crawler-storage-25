use pyo3::prelude::*;

#[pyfunction]
fn get_magic_number() -> i64 {
    private_only_core::get_magic_number()
}

#[pymodule]
fn _native(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(get_magic_number, module)?)?;
    Ok(())
}
