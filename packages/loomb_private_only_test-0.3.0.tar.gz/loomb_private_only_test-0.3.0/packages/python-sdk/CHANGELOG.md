# Changelog

## [0.3.0](https://github.com/loomb-oai/test-private-only-repo/compare/python-sdk-v0.2.0...python-sdk-v0.3.0) (2026-05-21)


### Features

* **samples:** expose get_magic_number demo API ([06d9dde](https://github.com/loomb-oai/test-private-only-repo/commit/06d9ddece51abec192d404096d6ca7ae693db1d1))
* **sdk:** add rust-backed goodbye variant ([201706b](https://github.com/loomb-oai/test-private-only-repo/commit/201706b3d0303c7315bc986dc1bdd2cd67a14ea2))
* **sdk:** add rust-backed goodbye variant ([909fab1](https://github.com/loomb-oai/test-private-only-repo/commit/909fab1940aeab8f371eef3e94e7c29374b1fd9d))
* **sdk:** rename rust greeting to australian gday API ([700ed10](https://github.com/loomb-oai/test-private-only-repo/commit/700ed105aaa1e34fde2d0c17c76a04bfe1b6c3e4))

## [0.2.0](https://github.com/loomb-oai/test-private-only-repo/compare/python-sdk-v0.1.0...python-sdk-v0.2.0) (2026-05-19)


### Features

* add private-only release sample ([bc8e9ec](https://github.com/loomb-oai/test-private-only-repo/commit/bc8e9ecccc93f5580715dbca5482a0b5fdb4a7ec))
