"""Utilities for the translator module."""

from __future__ import annotations

import functools
import json
from collections import OrderedDict
from typing import Union

import numpy as np
import pydantic as pd
import unyt as u

from flow360.component.simulation.draft_context.coordinate_system_manager import (
    CoordinateSystemManager,
)
from flow360.component.simulation.framework.base_model import Flow360BaseModel
from flow360.component.simulation.framework.base_model_config import snake_to_camel
from flow360.component.simulation.framework.entity_base import EntityBase, EntityList
from flow360.component.simulation.framework.param_utils import AssetCache
from flow360.component.simulation.framework.unique_list import UniqueItemList
from flow360.component.simulation.meshing_param import snappy
from flow360.component.simulation.meshing_param.params import ModularMeshingWorkflow
from flow360.component.simulation.primitives import (
    BOUNDARY_FULL_NAME_WHEN_NOT_FOUND,
    _SurfaceEntityBase,
    _VolumeEntityBase,
)
from flow360.component.simulation.simulation_params import SimulationParams
from flow360.component.simulation.unit_system import LengthType
from flow360.component.simulation.user_code.core.types import Expression, UserVariable
from flow360.component.simulation.utils import is_exact_instance
from flow360.exceptions import Flow360TranslationError


# pylint: disable=too-many-arguments
def apply_coordinate_system_transformations(params: SimulationParams) -> SimulationParams:
    """
    Apply coordinate system transformations to entities before translation.

    For each entity with a coordinate system assignment:
    1. Get the combined transformation matrix from CoordinateSystemManager
    2. Call entity._apply_transformation(matrix)
    3. Replace the original entity with the transformed version in-place

    Args:
        params: The simulation parameters with potential coordinate system assignments

    Returns:
        The simulation parameters with transformed entities (modified in-place)
    """
    # Check if coordinate system status exists
    if params.private_attribute_asset_cache is None:
        return params

    coord_status = params.private_attribute_asset_cache.coordinate_system_status
    if coord_status is None or not coord_status.assignments:
        # No coordinate systems or assignments, nothing to transform
        return params

    # Rebuild coordinate system manager from cached status

    manager = CoordinateSystemManager._from_status(  # pylint: disable=protected-access
        status=coord_status
    )
    _apply_transformations_to_model(params, manager)

    return params


def _transform_single_entity(entity: EntityBase, manager: CoordinateSystemManager) -> EntityBase:
    """Transform a single entity if it has a coordinate system assignment."""
    matrix = manager._get_matrix_for_entity(entity=entity)  # pylint: disable=protected-access
    if matrix is not None and hasattr(entity, "_apply_transformation"):
        return entity._apply_transformation(matrix)  # pylint: disable=protected-access
    return entity


def _transform_entity_list(entity_list: EntityList, manager: CoordinateSystemManager) -> EntityList:
    """Transform all entities in an EntityList."""
    if not entity_list.stored_entities:
        return entity_list

    transformed_entities = [
        _transform_single_entity(entity, manager) for entity in entity_list.stored_entities
    ]
    return entity_list.model_copy(update={"stored_entities": transformed_entities})


def _transform_sequence_item(item, manager: CoordinateSystemManager):
    """Transform a single item from a list or tuple."""
    if isinstance(item, EntityBase):
        return _transform_single_entity(item, manager)
    if isinstance(item, Flow360BaseModel):
        _apply_transformations_to_model(item, manager)
    return item


def _apply_transformations_to_model(
    model: Flow360BaseModel, manager: "CoordinateSystemManager"
) -> None:
    """
    Recursively apply coordinate system transformations to all entities in a model.

    Modifies entities in-place by replacing them with transformed versions.

    Args:
        model: The model containing entities to transform
        manager: The coordinate system manager with transformation matrices
    """
    for field_name, field_value in model.__dict__.items():
        if isinstance(field_value, AssetCache):
            continue

        if isinstance(field_value, EntityBase):
            transformed = _transform_single_entity(field_value, manager)
            if transformed is not field_value:
                setattr(model, field_name, transformed)

        elif isinstance(field_value, EntityList):
            new_entity_list = _transform_entity_list(field_value, manager)
            if new_entity_list is not field_value:
                setattr(model, field_name, new_entity_list)

        elif isinstance(field_value, (list, tuple)):
            new_items = [_transform_sequence_item(item, manager) for item in field_value]
            new_value = new_items if isinstance(field_value, list) else tuple(new_items)
            setattr(model, field_name, new_value)

        elif isinstance(field_value, Flow360BaseModel):
            _apply_transformations_to_model(field_value, manager)


def expand_selectors_for_translation(input_params: SimulationParams):
    """
    Expand entity selectors in-place for translation.

    This modifies the input_params object by expanding all selectors in EntityList
    attributes and adding the results to their stored_entities.

    After translation, the original params object is not needed, so in-place
    modification is safe and efficient.

    This implementation is consistent with ParamsValidationInfo.expand_entity_list(),
    working directly with deserialized objects without unnecessary serialization.
    """
    # pylint: disable=import-outside-toplevel
    from flow360.component.simulation.framework.entity_expansion_utils import (
        expand_all_entity_lists_in_place,
    )

    expand_all_entity_lists_in_place(input_params, merge_mode="merge")


def preprocess_input(func):
    """Call param preprocess() method before calling the translator."""

    @functools.wraps(func)
    def wrapper(input_params, mesh_unit, *args, **kwargs):
        skip_selector_expansion = kwargs.pop("skip_selector_expansion", False)
        # pylint: disable=no-member
        if func.__name__ == "get_solver_json":
            preprocess_exclude = ["meshing"]
        elif func.__name__ in ("get_surface_meshing_json", "get_volume_meshing_json"):
            preprocess_exclude = [
                "reference_geometry",
                "operating_condition",
                "models",
                "time_stepping",
                "user_defined_dynamics",
                "outputs",
            ]
        else:
            preprocess_exclude = []
        validated_mesh_unit = LengthType.validate(mesh_unit)
        processed_input = preprocess_param(input_params, validated_mesh_unit, preprocess_exclude)

        apply_coordinate_system_transformations(processed_input)

        if not skip_selector_expansion:
            # Expand entity selectors in-place before translation (Stage 4)
            # This ensures selectors work for all translators (solver, surface mesh, volume mesh)
            expand_selectors_for_translation(processed_input)

        return func(processed_input, validated_mesh_unit, *args, **kwargs)

    return wrapper


def preprocess_param(
    input_params: SimulationParams | str | dict,
    validated_mesh_unit: LengthType,
    preprocess_exclude: list[str],
):
    """
    Get the dictionary of `SimulationParams`.
    """
    param_dict = None
    param = None
    if isinstance(input_params, SimulationParams):
        param = input_params
    elif isinstance(input_params, str):
        try:
            # If input is a JSON string
            param_dict = json.loads(input_params)
            if param_dict is None:
                raise ValueError(f"Invalid input <{input_params}> for translator. ")
            param = SimulationParams(file_content=param_dict)
        except json.JSONDecodeError:
            # If input is a file path
            param = SimulationParams(filename=input_params)

    if param is not None:
        # pylint: disable=protected-access
        param._private_set_length_unit(validated_mesh_unit)
        return param._preprocess(validated_mesh_unit, exclude=preprocess_exclude)
    raise ValueError(f"Invalid input <{input_params.__class__.__name__}> for translator. ")


def replace_dict_key(input_dict: dict, key_to_replace: str, replacement_key: str):
    """Replace a key in a dictionary."""
    if key_to_replace in input_dict:
        input_dict[replacement_key] = input_dict.pop(key_to_replace)


def convert_tuples_to_lists(input_dict):
    """
    Recursively convert all tuples to lists in a nested dictionary.

    This function traverses through all the elements in the input dictionary and
    converts any tuples it encounters into lists. It also handles nested dictionaries
    and lists by applying the conversion recursively.

    Args:
        input_dict (dict): The input dictionary that may contain tuples.

    Returns:
        dict: A new dictionary with all tuples converted to lists.

    Examples:
        >>> input_dict = {
        ...     'a': (1, 2, 3),
        ...     'b': {
        ...         'c': (4, 5),
        ...         'd': [6, (7, 8)]
        ...     }
        ... }
        >>> convert_tuples_to_lists(input_dict)
        {'a': [1, 2, 3], 'b': {'c': [4, 5], 'd': [6, [7, 8]]}}
    """
    if isinstance(input_dict, dict):
        return {k: convert_tuples_to_lists(v) for k, v in input_dict.items()}
    if isinstance(input_dict, tuple):
        return list(input_dict)
    if isinstance(input_dict, list):
        return [convert_tuples_to_lists(item) for item in input_dict]
    return input_dict


def remove_units_in_dict(input_dict, skip_keys: list[str] = None):
    """Remove units from a dimensioned value."""
    if skip_keys is None:
        skip_keys = []

    def _is_unyt_or_unyt_like_obj(value):
        return "value" in value.keys() and "units" in value.keys()

    if isinstance(input_dict, dict):
        new_dict = {}
        if _is_unyt_or_unyt_like_obj(input_dict):
            new_dict = input_dict["value"]
            if (
                input_dict["units"] is not None
                and input_dict["units"].startswith("flow360_") is False
            ):
                raise ValueError(
                    f"[Internal Error] Unit {new_dict['units']} is not non-dimensionalized."
                )
            return new_dict
        for key, value in input_dict.items():
            if key in skip_keys or key in [snake_to_camel(item) for item in skip_keys]:
                new_dict[key] = value
                continue
            if isinstance(value, dict) and _is_unyt_or_unyt_like_obj(value):
                new_dict[key] = value["value"]
            else:
                new_dict[key] = remove_units_in_dict(value, skip_keys=skip_keys)
        return new_dict
    if isinstance(input_dict, list):
        return [remove_units_in_dict(item, skip_keys=skip_keys) for item in input_dict]
    return input_dict


def get_units_from_field(field, input_params) -> u.Unit:
    """Get output units from a field, which can be either a UserVariable or a string."""
    if isinstance(field, UserVariable):
        return field.value.get_output_units(input_params=input_params)
    return u.dimensionless  # pylint:disable=no-member


def convert_value_to_units(value, units):
    """Convert a value to specified units or unit system if the value is not already a float."""
    if isinstance(value, float):
        return value
    return value.to(units).v.item()


def translate_value_or_expression_object(
    obj: Union[Expression, u.unyt_quantity, u.unyt_array], input_params: SimulationParams
):
    """Translate for an ValueOrExpression object"""
    if isinstance(obj, Expression):
        # Only allowing client-time evaluable expressions
        evaluated = obj.evaluate(raise_on_non_evaluable=True)
        converted = evaluated.in_base(unit_system=input_params.flow360_unit_system).v.item()
        return converted
    # Non dimensionalized unyt objects
    return obj.value.item()


def inline_expressions_in_dict(input_dict, input_params):
    """Inline all client-time evaluable expressions in the provided dict to their evaluated values"""
    if isinstance(input_dict, dict):
        new_dict = {}
        if "typeName" in input_dict.keys():
            if input_dict["typeName"] == "expression":
                expression = Expression(expression=input_dict["expression"])
                evaluated = expression.evaluate(raise_on_non_evaluable=False)
                converted = evaluated.in_base(unit_system=input_params.flow360_unit_system).v
                new_dict = converted
                return new_dict
            # Handle non-dimensional number fields - unit removal does not handle them later on
            if "units" not in input_dict.keys() and input_dict["typeName"] == "number":
                new_dict = input_dict["value"]
                return new_dict
        for key, value in input_dict.items():
            # For number-type fields the schema should match dimensioned unit fields
            # so remove_units_in_dict should handle them correctly...
            if isinstance(value, dict) and "expression" in value.keys():
                expression = Expression(expression=value["expression"])
                evaluated = expression.evaluate(raise_on_non_evaluable=False)
                converted = evaluated.in_base(unit_system=input_params.flow360_unit_system).v
                if isinstance(converted, np.ndarray):
                    if converted.ndim == 0:
                        converted = float(converted)
                    else:
                        converted = converted.tolist()
                new_dict[key] = converted
            else:
                new_dict[key] = inline_expressions_in_dict(value, input_params)
        return new_dict
    if isinstance(input_dict, list):
        return [inline_expressions_in_dict(item, input_params) for item in input_dict]
    return input_dict


def has_instance_in_list(obj_list: list, class_type):
    """Check if a list contains an instance of a given type."""
    if obj_list is not None:
        for obj in obj_list:
            if is_exact_instance(obj, class_type):
                return True
    return False


def getattr_by_path(obj, path: Union[str, list], *args):
    """Get attribute by path from a list"""
    # If path is a string, return the attribute directly
    if isinstance(path, str):
        return getattr(obj, path, *args)

    # If path is a list, iterate through each attribute name
    for attr in path:
        obj = getattr(obj, attr)

    return obj


def get_all_entries_of_type(obj_list: list, class_type: type[pd.BaseModel]):
    """Get all entries matching the exact class_type in the obj_list"""
    entries = []

    if obj_list is not None:
        for obj in obj_list:
            if is_exact_instance(obj, class_type):
                entries.append(obj)

    return entries


def get_global_setting_from_first_instance(
    obj_list: list,
    class_type,
    attribute_name: Union[str, list],
):
    """In a list loop and find the first instance matching the given type and retrive the attribute"""
    if obj_list is not None:
        for obj in obj_list:
            if (
                is_exact_instance(obj, class_type)
                and getattr_by_path(obj, attribute_name, None) is not None
            ):
                # Allowed to look into non-empty-entity instances
                # Then we return the first non-None value.
                # Previously we return the value that is non-default.
                # But this is deemed not intuitive and very hard to implement.
                return getattr_by_path(obj, attribute_name)
    return None


def update_dict_recursively(a: dict, b: dict):
    """
    Recursively updates dictionary 'a' with values from dictionary 'b'.
    If the same key contains dictionaries in both 'a' and 'b', they are merged recursively.
    """
    for key, value in b.items():
        if key in a and isinstance(a[key], dict) and isinstance(value, dict):
            # If both a[key] and b[key] are dictionaries, recurse
            update_dict_recursively(a[key], value)
        else:
            # Otherwise, simply update/overwrite the value in 'a' with the value from 'b'
            a[key] = value


def _get_key_name(entity: EntityBase):
    if isinstance(entity, (_SurfaceEntityBase, _VolumeEntityBase)):
        # Note: If the entity is a Surface/Boundary, we need to use the full name
        return entity.full_name

    return entity.name


# pylint: disable=too-many-branches, too-many-arguments, too-many-locals, too-many-statements
def translate_setting_and_apply_to_all_entities(
    obj_list: list,
    class_type,
    translation_func=lambda x, **kwargs: {},
    to_list: bool = False,
    entity_injection_func=lambda x, **kwargs: {},
    pass_translated_setting_to_entity_injection=False,
    custom_output_dict_entries=False,
    lump_list_of_entities=False,
    use_instance_name_as_key=False,
    use_sub_item_as_key=False,
    entity_type_to_include=None,
    entity_list_field_name="entities",
    **kwargs,
):
    """
    Translate settings and apply them to all entities of a given type.

    This function iterates over a list of objects, applies a translation function to each object if
    it matches the given `class_type`, and then processes its entities based on various customization
    options. The function supports returning either a dictionary or a list of translated settings.

    Parameters
    ----------
    obj_list : list
        A list of objects to process.
    class_type : type
        The type of objects to match. Only objects of this type will be processed.
    translation_func : callable
        A function that translates the settings for each object. It should return a dictionary.
    to_list : bool, optional
        If True, the output is a list. If False (default), the output is a dictionary.
    entity_injection_func : callable, optional
        A function for injecting additional settings into each entity. Defaults to a lambda returning an empty dict.
    pass_translated_setting_to_entity_injection : bool, optional
        If True, passes the translated settings to `entity_injection_func`. Defaults to False.
    custom_output_dict_entries : bool, optional
        If True, allows customization of output dictionary entries. Defaults to False.
    lump_list_of_entities : bool, optional
        If True, lumps all entities into a single list. Defaults to False.
    use_instance_name_as_key : bool, optional
        If True, uses the instance name of the object as the key in the output dictionary.
        Only valid if `lump_list_of_entities` is False. Defaults to False.
    use_sub_item_as_key : bool, optional
        If True, uses subcomponents of entities as keys in the output dictionary. Defaults to False.
    **kwargs : dict, optional
        Additional keyword arguments. Arguments prefixed with `translation_func_` are passed to
        `translation_func`, and those prefixed with `entity_injection_` are passed to `entity_injection_func`.

    Returns
    -------
    dict or list
        A dictionary or list containing the translated settings applied to all entities.
        If `to_list` is False (default), the output is a dictionary, where keys are entity names (or custom keys)
        and values are the translated settings. If `to_list` is True, the output is a list.

    Raises
    ------
    NotImplementedError
        If `lump_list_of_entities` is used with `entity_pairs` or if `use_instance_name_as_key`
        is used when `lump_list_of_entities` is True.

    Notes
    -----
    - The `translation_func` must return a dictionary with the translated settings.
    - The `entity_injection_func` allows additional customizations to be applied to each entity.
    - If `lump_list_of_entities` is True, all entities are treated as a single group, and custom key usage
      (e.g., `use_instance_name_as_key`) may be restricted.

    Examples
    --------
    >>> translate_setting_and_apply_to_all_entities(obj_list, MyClass, my_translation_func)
    {'entity1': {'setting1': 'value1'}, 'entity2': {'setting1': 'value2'}}
    """
    if not to_list:
        output = {}
    else:
        output = []

    translation_func_prefix = "translation_func_"
    translation_func_kwargs = {
        k[len(translation_func_prefix) :]: v
        for k, v in kwargs.items()
        if k.startswith(translation_func_prefix)
    }
    entity_injection_prefix = "entity_injection_"
    entity_injection_kwargs = {
        k[len(entity_injection_prefix) :]: v
        for k, v in kwargs.items()
        if k.startswith(entity_injection_prefix)
    }

    # pylint: disable=too-many-nested-blocks
    for obj in obj_list:
        if class_type and is_exact_instance(obj, class_type):
            list_of_entities = []
            if entity_list_field_name in obj.__class__.model_fields:
                entity_list = getattr(obj, entity_list_field_name)
                if entity_list is None or (
                    "stored_entities" in entity_list.__class__.model_fields
                    and entity_list.stored_entities is None
                ):  # unique item list does not allow None "items" for now.
                    continue
                if isinstance(entity_list, EntityList):
                    list_of_entities = (
                        entity_list.stored_entities
                        if lump_list_of_entities is False
                        else [entity_list]
                    )
                elif isinstance(entity_list, UniqueItemList):
                    list_of_entities = (
                        entity_list.items if lump_list_of_entities is False else [entity_list]
                    )
            elif "entity_pairs" in obj.__class__.model_fields:
                # Note: This is only used in Periodic BC and lump_list_of_entities is not relavant
                if lump_list_of_entities:
                    raise NotImplementedError(
                        "[Internal Error]: lump_list_of_entities cannot be used with entity_pairs"
                    )
                list_of_entities = obj.entity_pairs.items

            translated_setting = translation_func(obj, **translation_func_kwargs)

            if pass_translated_setting_to_entity_injection:
                entity_injection_kwargs["translated_setting"] = translated_setting

            if entity_type_to_include is not None and lump_list_of_entities:
                if not isinstance(list_of_entities[0].stored_entities[0], entity_type_to_include):
                    continue

            for entity in list_of_entities:
                if (
                    entity_type_to_include is None
                    or lump_list_of_entities
                    or isinstance(entity, entity_type_to_include)
                ):
                    if not to_list:
                        # Generate a $name:{$value} dict
                        if custom_output_dict_entries:
                            setting = entity_injection_func(entity, **entity_injection_kwargs)
                            if setting is None:
                                continue
                            output.update(setting)
                        else:
                            if use_instance_name_as_key is True and lump_list_of_entities is False:
                                raise NotImplementedError(
                                    "[Internal Error]: use_instance_name_as_key cannot be used"
                                    " when lump_list_of_entities is True"
                                )
                            if use_sub_item_as_key is True:
                                key_names = getattr(
                                    entity, "private_attribute_sub_components", None
                                )
                                if key_names is None:
                                    key_names = [_get_key_name(entity)]
                            else:
                                key_names = [
                                    (
                                        _get_key_name(entity)
                                        if use_instance_name_as_key is False
                                        else obj.name
                                    )
                                ]
                            for key_name in key_names:
                                if key_name == BOUNDARY_FULL_NAME_WHEN_NOT_FOUND:
                                    # Skip missing boundary
                                    continue
                                if output.get(key_name) is None:
                                    setting = entity_injection_func(
                                        entity, **entity_injection_kwargs
                                    )
                                    if setting is None:
                                        continue
                                    output[key_name] = setting
                                update_dict_recursively(output[key_name], translated_setting)
                    else:
                        # Generate a list with $name being an item
                        # Note: Surface/Boundary logic should be handled in the entity_injection_func
                        setting = entity_injection_func(entity, **entity_injection_kwargs)
                        if setting is None:
                            continue
                        setting.update(translated_setting)
                        output.append(setting)
    return output


def merge_unique_item_lists(list1: list[str], list2: list[str]) -> list:
    """Merge two lists and remove duplicates."""
    combined = list1 + list2
    return list(OrderedDict.fromkeys(combined))


def ensure_meshing_is_specified(input_params: SimulationParams):
    """Check if meshing parameters are included in SimulationParams."""
    if input_params.meshing is None:
        raise Flow360TranslationError(
            "meshing not specified.",
            None,
            ["meshing"],
        )


def using_snappy(input_params: SimulationParams):
    """Checks if snappy is being used"""
    return isinstance(input_params.meshing, ModularMeshingWorkflow) and isinstance(
        input_params.meshing.surface_meshing, snappy.SurfaceMeshingParams
    )


def remove_keys(obj, key_to_remove):
    """Remove all keys recursively from the input dict"""
    if isinstance(obj, dict):
        return {k: remove_keys(v, key_to_remove) for k, v in obj.items() if k != key_to_remove}
    if isinstance(obj, list):
        return [remove_keys(item, key_to_remove) for item in obj]
    return obj
