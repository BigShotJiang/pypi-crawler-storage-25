# outhad-contextkit-sdk

Thin Python client for the **Outhad ContextKit** cloud — long-term memory
for AI agents, with multimodal + temporal-causal recall, personalised
retrieval, and tenant isolation built in.

This package ships **client only**. There is no local memory engine, no
vector store driver, no LLM provider. Calls go to the Outhad ContextKit
cloud where the heavy lifting happens — billed against the API key you
mint at https://contextkit.outhad.com.

## Install

```bash
pip install outhad-contextkit-sdk
```

## Quickstart

```python
from outhad_contextkit_sdk import MemoryClient

client = MemoryClient(api_key="ock_live_...")  # or set OUTHAD_CONTEXTKIT_API_KEY

client.add(
    messages=[
        {"role": "user", "content": "Hi, my name is Alice and I love sushi."},
    ],
    user_id="alice",
)

hits = client.search(query="What food does Alice like?", user_id="alice")
for hit in hits["results"]:
    print(hit["score"], hit["memory"])
```

## Switching the LLM at runtime

The default model is whatever the project has saved in **Dashboard →
Settings**. You can override it on a single call without touching the
project default:

```python
client.add(
    messages=[{"role": "user", "content": "I love sushi."}],
    user_id="alice",
    llm={"provider": "anthropic", "model": "claude-haiku-4-5-20251001"},
)

# Same override shape works on search:
client.search(
    query="What food do I like?",
    user_id="alice",
    llm={"provider": "anthropic", "model": "claude-haiku-4-5-20251001"},
)
```

Pass `api_key` inside the dict to bring your own upstream key for that
single call (never persisted server-side):

```python
client.add(
    messages=[...],
    user_id="alice",
    llm={
        "provider": "anthropic",
        "model": "claude-haiku-4-5-20251001",
        "api_key": "sk-ant-…",
    },
)
```

Override the embedder the same way with `embedder={"provider": "...",
"model": "...", "api_key": "..."}`.

Without overrides every call uses the project's saved defaults — set
those once in the dashboard and forget about them.

## Get an API key

1. Sign up at <https://contextkit.outhad.com>.
2. Open the dashboard → **API keys**.
3. Click **Create key**, copy the one-shot secret (looks like
   `ock_live_<8-char-prefix>_<32-byte-secret>`).
4. Either pass it as `MemoryClient(api_key=…)` or export it in your
   shell as `OUTHAD_CONTEXTKIT_API_KEY`.

## Auth header

The SDK sends `Authorization: Token <api-key>` on every request. The
cloud dispatcher also accepts `Bearer` and `X-API-Key` if you prefer to
hit the HTTP API directly (e.g. from `curl`).

## Host resolution

| Resolution order | Default |
|------------------|---------|
| `host=` constructor arg | (none) |
| `OUTHAD_CONTEXTKIT_HOST` env var | (none) |
| Production default | `https://contextkit.outhad.com` |
| Dev fallback (transparent retry on connection error) | `http://localhost:8000` |

When the production default is unreachable (DNS failure / connection
refused) the client transparently retries against
`http://localhost:8000` and pins itself there for the rest of the
session — useful while you are working against `make cloud-up` locally.
The fallback is disabled when you pass `host=` or set
`OUTHAD_CONTEXTKIT_HOST` explicitly.

## Async

```python
from outhad_contextkit_sdk import AsyncMemoryClient

async def main():
    async with AsyncMemoryClient(api_key="ock_live_...") as client:
        await client.add(
            messages=[{"role": "user", "content": "I prefer dark mode."}],
            user_id="alice",
        )
```

## API surface

* `add(messages, *, user_id, agent_id, run_id, metadata, infer, llm, embedder)`
* `get_all(*, user_id, agent_id, run_id, limit)`
* `get(memory_id)`
* `search(query, *, user_id, agent_id, run_id, filters, limit, llm, embedder)`
* `update(memory_id, *, text)`
* `history(memory_id)`
* `delete(memory_id)`
* `delete_all(*, user_id, agent_id, run_id)`

`llm` / `embedder` (optional, since 1.1.0) — per-request model override
(see *Switching the LLM at runtime* above).

For dashboard-style operations the same client also exposes
`list_api_keys()`, `create_api_key()`, `revoke_api_key()` — those
require a Clerk session JWT and are intended for interactive tooling.

## License

Apache-2.0.
