# Outhad ContextKit SDK — API Reference

Thin Python client for the Outhad ContextKit cloud. Speaks HTTP to
`https://contextkit.outhad.com`. Ships **only** the network client —
no model providers, no vector store drivers, no local memory engine.

## Install

```bash
pip install outhad-contextkit-sdk
```

## Quick start

```python
from outhad_contextkit_sdk import MemoryClient

client = MemoryClient(api_key="ock_live_...")  # or set OUTHAD_CONTEXTKIT_API_KEY

client.add(
    messages=[{"role": "user", "content": "I love sushi"}],
    user_id="alice",
)

hits = client.search(query="What food do I like?", user_id="alice")
for hit in hits["results"]:
    print(hit["memory"], hit["score"])
```

## Pages

- [getting_started.md](getting_started.md) — install, auth, env vars, first call
- [memory_client.md](memory_client.md) — sync `MemoryClient` constructor + lifecycle
- [async_memory_client.md](async_memory_client.md) — async twin
- [memory_operations.md](memory_operations.md) — `add` / `get_all` / `get` / `search` / `update` / `history` / `delete` / `delete_all`
- [feedback_and_lifecycle.md](feedback_and_lifecycle.md) — `feedback` / `reset` / `users` / `delete_users` / `batch_update` / `batch_delete` / `summary` / `export`
- [multimodal.md](multimodal.md) — image + content-block support on `add`
- [retrieval_kwargs.md](retrieval_kwargs.md) — `top_k` / `threshold` / `use_context_graph` / `categories` / `output_format` / `includes` / `excludes`
- [cgl.md](cgl.md) — Context-Graph Layer (`use_context_graph`, structural edges, re-rank blend)
- [mspr.md](mspr.md) — MSPR personalisation (`feedback`, intent / frequency / success boosts)
- [tcmgm.md](tcmgm.md) — TCMGM fused retrieval (`use_tcmgm` / `time_window` / `include_causal`)
- [versioning.md](versioning.md) — `versions` / `latest_version` / `rollback` / `diff_versions`
- [decay_and_lifecycle.md](decay_and_lifecycle.md) — decay v2 + cold storage + references
- [backfill_and_reset.md](backfill_and_reset.md) — `backfill(kind)` / `reset_cgl` / `reset_feedback`
- [phase16_extras.md](phase16_extras.md) — `pin` / `unpin` / advanced filter operators / hybrid keyword / LLM filter / idempotency keys
- [projects_and_members.md](projects_and_members.md) — project CRUD, members + RBAC, custom_instructions / custom_categories / retrieval_criteria / enable_graph / api_version
- [webhooks.md](webhooks.md) — outbound `memory.created` / `memory.updated` / `memory.deleted` webhooks with HMAC-SHA256 signature
- [ttl_and_pagination.md](ttl_and_pagination.md) — `expiration_date` + `page` / `page_size`
- [per_request_overrides.md](per_request_overrides.md) — `llm=` and `embedder=` per-call overrides
- [api_keys.md](api_keys.md) — `list_api_keys` / `create_api_key` / `revoke_api_key`
- [errors.md](errors.md) — `APIError`, `AuthenticationError` and status-code mapping
- [host_resolution.md](host_resolution.md) — production / dev fallback / explicit host

## Conventions

- All keyword args are keyword-only (after `*`). Positional args are
  the resource id or primary input only.
- Methods return the parsed JSON body (usually `dict` or `{"results": [...]}`).
- Network or 4xx/5xx errors raise `APIError`; 401 raises `AuthenticationError`.
- Every memory op needs **at least one** session id — `user_id`,
  `agent_id`, or `run_id`. Tenant scoping is automatic; the API key
  decides which tenant the call lands in.

## Versions

Current: **1.6.0**
- `pin` / `unpin` (lock metadata) — `update` / `delete` 409 on locked rows
- Advanced metadata filter operators (`$gt` / `$lt` / `$gte` / `$lte`
  / `$in` / `$nin` / `$ne` / `$contains` + `AND` / `OR` / `NOT`
  composition) via `client.get_all_filtered({...})`
- Hybrid keyword search — `client.search(..., keyword_search=True)`
  fuses dense vector hits with ILIKE keyword matches via
  reciprocal-rank fusion
- LLM relevance gate — `client.search(..., filter_memories=True)`
  asks the project's chat LLM to vote which rows directly answer
  the query, drops the rest
- Idempotency keys — `client.add_idempotent(key, ...)` sends
  `Idempotency-Key` header; cloud caches responses per
  `(tenant_id, key)` so retries don't double-write

**1.5.0**
- Surfaces every previously-unwired engine subsystem:
  versioning (`versions` / `latest_version` / `rollback` /
  `diff_versions`), decay v2 (`tick_decay` / `archive_low` /
  `decay_score`), cold storage (`demote_to_cold` /
  `promote_from_cold`), references (`record_reference`),
  backfill (`backfill('context_graph' | 'mspr' | 'decay_v2')`),
  resets (`reset_cgl` / `reset_feedback`).
- Cloud config wires `decay_v2.enabled=True` +
  `versioning.mode='immutable'` +
  `cold_storage.backend='local'` +
  `track_references=True` whenever the project flips
  `enable_graph=True` (already turns CGL + MSPR on).

**1.4.0**
- TCMGM (Temporal-Causal Multimodal Graph Memory) fused retrieval —
  `use_tcmgm`, `time_window`, `include_causal` on `client.search(...)`
- Cloud-side fix: `custom_instructions` no longer breaks `add()` —
  engine prompt is now appended (not replaced) so the JSON-mode
  contract is preserved
- Multimodal `add()` now produces extractable facts — the engine's
  `get_image_description` injects an explicit describe-this-image
  directive into the dict-shaped vision call so the downstream fact
  extractor sees a clean first-person description instead of a chat
  reply (was 0 events for content-block uploads in 1.3)
- CGL (Context-Graph Layer) now actually runs when the project flips
  `enable_graph=True` — `memory_cache.build_memory` sets
  `context_graph.enabled=True` + networkx backend + per-project
  snapshot path, and the cloud image bundles `networkx>=3.2` so the
  engine no longer falls back with "networkx package missing"
- MSPR (Multi-Stage Personalised Retrieval) now actually runs when
  the project flips `enable_graph=True` — `memory_cache.build_memory`
  sets `mspr.enabled=True` plus the `feedback` / `intent` / `frequency`
  / `success` sub-features, and the CGL retrieval block bumps the
  `δ·personal` / `ε·frequency` / `ζ·success` weights to `0.10` each
  so feedback actually shifts ranks. `client.feedback(...)` returns
  `{recorded: True, delta_applied: 0.15, ...}` instead of the old
  `mspr_or_feedback_disabled` reason
- Audio-via-SDK workflow documented (transcribe client-side via
  Whisper + `client.add(infer=False)`); native `audio_url` block
  ingestion lands in v1.5

**1.3.0**
- Project / member / webhook CRUD: `list_projects`, `create_project`,
  `get_project`, `update_project`, `delete_project`
- Members + RBAC: `list_members`, `add_member`, `update_member`,
  `remove_member` (`OWNER` / `ADMIN` / `WRITER` / `READER`)
- Webhooks: `list_webhooks`, `create_webhook`, `update_webhook`,
  `delete_webhook` with HMAC-SHA256 signed delivery on
  `memory.created` / `memory.updated` / `memory.deleted`
- Project knobs: `custom_instructions`, `custom_categories`,
  `retrieval_criteria`, `enable_graph`, `api_version`

**1.2.0**
- `feedback`, `reset`, `users`, `delete_users`, `batch_update`, `batch_delete`, `summary`, `export`
- multimodal `add` (text + image_url content blocks)
- `expiration_date` per-memory TTL
- retrieval kwargs: `top_k`, `threshold`, `use_context_graph`, `categories`
- shape control: `output_format`, `includes`, `excludes`, `version`
- pagination on `get_all` (`page`, `page_size`)
- `history(since=, until=)` time-range filter

**1.1.0** — per-request `llm=` / `embedder=` overrides.
