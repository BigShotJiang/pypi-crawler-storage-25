"""Outhad ContextKit — thin Python SDK.

This distribution intentionally ships **only** the cloud HTTP client.
There is no local memory engine, no vector store driver, no LLM
provider — those live in the upstream ``outhad_contextkit`` library
which only operators of the cloud platform need.

End-user flow:

1. Sign up at https://contextkit.outhad.com.
2. Mint an API key in the dashboard.
3. ``pip install outhad-contextkit-sdk``
4. ``from outhad_contextkit_sdk import MemoryClient``

Example::

    from outhad_contextkit_sdk import MemoryClient

    client = MemoryClient(api_key="ock_live_...")  # picks up env var if omitted
    client.add(
        messages=[{"role": "user", "content": "I love sushi"}],
        user_id="alice",
    )
    hits = client.search(query="What food do I like?", user_id="alice")
"""
from outhad_contextkit_sdk.client.errors import APIError, AuthenticationError
from outhad_contextkit_sdk.client.main import (
    DEFAULT_HOST,
    DEV_HOST,
    AsyncMemoryClient,
    MemoryClient,
)

__version__ = "1.7.0"

__all__ = [
    "APIError",
    "AsyncMemoryClient",
    "AuthenticationError",
    "DEFAULT_HOST",
    "DEV_HOST",
    "MemoryClient",
    "__version__",
]
