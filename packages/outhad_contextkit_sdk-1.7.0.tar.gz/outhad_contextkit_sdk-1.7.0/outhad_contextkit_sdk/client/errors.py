"""Typed exceptions raised by the SDK."""
from __future__ import annotations

from typing import Any, Optional


class APIError(Exception):
    """Raised on any non-2xx response from the cloud backend.

    Attributes:
        status: HTTP status code returned by the server.
        body: Decoded JSON / text body, when available.
    """

    def __init__(
        self,
        message: str,
        *,
        status: Optional[int] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.body = body

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        if self.status is None:
            return super().__str__()
        return f"[{self.status}] {super().__str__()}"


class AuthenticationError(APIError):
    """Raised when the API key is missing, malformed, revoked or expired."""


__all__ = ["APIError", "AuthenticationError"]
