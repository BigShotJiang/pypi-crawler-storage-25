"""Thin Python client for the Outhad ContextKit cloud.

This module is the **only** public surface of ``outhad-contextkit-sdk``.
It speaks HTTP to the cloud backend and never imports any model
provider, vector store driver, or local memory engine. All authenticated
calls require an ``ock_live_…`` / ``ock_test_…`` API key minted at
https://contextkit.outhad.com/dashboard/api-keys.

Host resolution
---------------
1. Explicit ``host=`` constructor arg, when provided.
2. ``OUTHAD_CONTEXTKIT_HOST`` env var, when set.
3. Production default (``DEFAULT_HOST = "https://contextkit.outhad.com"``).
4. On a connection error against the production default the client
   transparently retries against the local-dev fallback
   (``DEV_HOST = "http://localhost:8000"``) and pins itself there for
   the rest of the session — useful while the production deployment
   is still spinning up. The fallback is only triggered when the
   default URL is in use; explicit ``host=`` / env wins.

Auth header
-----------
``Authorization: Token <api_key>`` — the format the cloud dispatcher
already accepts (contextkit-compat). Set once on the underlying httpx client
so every request carries it.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx

from outhad_contextkit_sdk.client.errors import APIError, AuthenticationError

logger = logging.getLogger(__name__)

# Production cloud host. Override via ``host=`` arg or
# ``OUTHAD_CONTEXTKIT_HOST`` env var. Pinned to the public dashboard
# domain so the SDK works out of the box for paying customers.
DEFAULT_HOST = "https://contextkit.outhad.com"

# Local dev host used by ``server/docker-compose.cloud.yaml``. The
# client falls back to this transparently when the default URL is
# unreachable (DNS failure / connection refused) — see the docstring.
DEV_HOST = "http://localhost:8000"

# How long a single HTTP call may take, in seconds. Generous because
# memory operations include OpenAI fact extraction on the server side.
DEFAULT_TIMEOUT = 30.0


def _shape_result(
    result: Any,
    *,
    output_format: Optional[str] = None,
    includes: Optional[List[str]] = None,
    excludes: Optional[List[str]] = None,
) -> Any:
    """contextkit-compat ``output_format`` + ``includes`` / ``excludes`` trimmer.

    The cloud always emits the v1.1 envelope ``{"results": [...]}``.
    ``output_format="v1.0"`` rewinds to the legacy bare-list shape so
    callers porting from contextkit v0 SDKs don't have to special-case the
    response. ``includes`` / ``excludes`` apply per-row key filtering
    after the unwrap; both lists are mutually exclusive at apply time
    (``includes`` takes precedence when both are passed).
    """
    if result is None:
        return result
    rows: List[Any]
    if isinstance(result, dict) and "results" in result:
        rows = list(result.get("results") or [])
    elif isinstance(result, list):
        rows = list(result)
    else:
        return result

    if includes:
        rows = [
            {k: v for k, v in r.items() if k in set(includes)} if isinstance(r, dict) else r
            for r in rows
        ]
    elif excludes:
        rows = [
            {k: v for k, v in r.items() if k not in set(excludes)} if isinstance(r, dict) else r
            for r in rows
        ]

    if (output_format or "").lower() in {"v1.0", "v1"}:
        return rows
    if isinstance(result, dict):
        result = dict(result)
        result["results"] = rows
        return result
    return rows


def _select_host(explicit: Optional[str]) -> str:
    if explicit:
        return explicit.rstrip("/")
    env = os.environ.get("OUTHAD_CONTEXTKIT_HOST")
    if env:
        return env.rstrip("/")
    return DEFAULT_HOST


def _decode_error(resp: httpx.Response) -> APIError:
    try:
        body = resp.json()
        msg = (
            body.get("detail")
            if isinstance(body, dict) and "detail" in body
            else str(body)
        )
    except Exception:
        body = resp.text
        msg = body
    if resp.status_code == 401:
        return AuthenticationError(msg, status=resp.status_code, body=body)
    return APIError(msg, status=resp.status_code, body=body)


def _is_connection_failure(exc: BaseException) -> bool:
    """Heuristic — whether ``exc`` looks like the prod URL being down.

    httpx raises ``httpx.ConnectError`` for DNS / connection-refused, and
    ``httpx.ReadTimeout`` when the server hangs. We treat both as
    "unreachable" and trigger the dev-host fallback.
    """
    return isinstance(
        exc,
        (
            httpx.ConnectError,
            httpx.ConnectTimeout,
            httpx.ReadTimeout,
            httpx.RemoteProtocolError,
        ),
    )


# ────────────────────────────────────────────────────────────────────────────
# Sync client
# ────────────────────────────────────────────────────────────────────────────


class MemoryClient:
    """Synchronous client for the Outhad ContextKit cloud.

    Args:
        api_key: ``ock_live_…`` or ``ock_test_…`` token minted at the
            dashboard. Falls back to the ``OUTHAD_CONTEXTKIT_API_KEY``
            env var when omitted; raises :class:`AuthenticationError`
            when neither is provided.
        host: Override the cloud host. Defaults to
            :data:`DEFAULT_HOST` (production). Pass ``DEV_HOST`` for a
            local backend.
        timeout: Per-request timeout in seconds.
        client: Pre-built ``httpx.Client``. When supplied,
            ``base_url`` and ``Authorization`` headers are overwritten
            so the rest of the SDK works as-expected.
        allow_dev_fallback: When True (default), a connection failure
            against the production default URL retries once against
            ``DEV_HOST`` and pins the client to it for the session.
            Disabled automatically when the host was set explicitly.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        host: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        client: Optional[httpx.Client] = None,
        allow_dev_fallback: bool = True,
    ) -> None:
        self.api_key = api_key or os.environ.get("OUTHAD_CONTEXTKIT_API_KEY")
        if not self.api_key:
            raise AuthenticationError(
                "Outhad ContextKit API key not provided. Pass api_key=… or "
                "set OUTHAD_CONTEXTKIT_API_KEY in your environment. "
                "Mint a key at https://contextkit.outhad.com/dashboard/api-keys.",
                status=401,
            )

        explicit_host = host is not None or "OUTHAD_CONTEXTKIT_HOST" in os.environ
        self.host = _select_host(host)
        self.timeout = timeout
        self._allow_fallback = allow_dev_fallback and not explicit_host
        self._fell_back = False
        self._owns_client = client is None

        if client is None:
            self._client = httpx.Client(
                base_url=self.host,
                timeout=self.timeout,
                headers=self._auth_headers(),
            )
        else:
            self._client = client
            self._client.base_url = httpx.URL(self.host)
            self._client.headers.update(self._auth_headers())

        # Surface identity on construction (and trigger dev fallback
        # when the production default is unreachable).
        self.identity: Dict[str, Any] = self._validate()
        self.user_email = self.identity.get("user_email")
        self.org_id = self.identity.get("org_id")
        self.project_id = self.identity.get("project_id")

    # ----- private --------------------------------------------------------
    def _auth_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Token {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "outhad-contextkit-sdk-python/1.7.0",
        }

    def _retarget(self, host: str) -> None:
        self.host = host.rstrip("/")
        self._client.base_url = httpx.URL(self.host)
        self._fell_back = True

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        try:
            resp = self._client.request(method, path, **kwargs)
        except Exception as exc:
            if (
                self._allow_fallback
                and not self._fell_back
                and self.host == DEFAULT_HOST
                and _is_connection_failure(exc)
            ):
                logger.warning(
                    "Production host %s unreachable (%s) — retrying against %s",
                    DEFAULT_HOST,
                    exc.__class__.__name__,
                    DEV_HOST,
                )
                self._retarget(DEV_HOST)
                return self._client.request(method, path, **kwargs)
            raise
        return resp

    def _json(self, method: str, path: str, **kwargs) -> Any:
        resp = self._request(method, path, **kwargs)
        if not resp.is_success:
            raise _decode_error(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    def _validate(self) -> Dict[str, Any]:
        # ``GET /v1/ping/`` returns identity when a valid API key is
        # supplied — that is the canonical handshake the cloud backend
        # implements.
        try:
            resp = self._request("GET", "/v1/ping/")
        except Exception:
            raise
        if resp.status_code == 401:
            raise AuthenticationError(
                "API key rejected — verify it on the dashboard.",
                status=401,
                body=resp.text,
            )
        if not resp.is_success:
            raise APIError(
                f"Failed to reach Outhad ContextKit cloud at {self.host}",
                status=resp.status_code,
                body=resp.text,
            )
        try:
            data = resp.json()
        except Exception:
            data = {}
        if isinstance(data, dict) and data.get("auth") == "invalid_api_key":
            raise AuthenticationError(
                "API key rejected by the cloud.",
                status=401,
                body=data,
            )
        return data if isinstance(data, dict) else {}

    # ----- memory CRUD ----------------------------------------------------
    def add(
        self,
        messages: Any,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        infer: bool = True,
        llm: Optional[Dict[str, Any]] = None,
        embedder: Optional[Dict[str, Any]] = None,
        expiration_date: Optional[str] = None,
    ) -> Any:
        """Persist memories.

        ``messages`` accepts the original contextkit-compat shape
        ``[{"role": "user", "content": "..."}]`` or the OpenAI vision
        shape with content blocks::

            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": "Vacation in Tokyo"},
                    {"type": "image_url",
                     "image_url": {"url": "https://example.com/sushi.jpg"}},
                ],
            }]

        When a content-block list arrives the cloud routes it through
        the project's vision-capable LLM, gets a description, and
        stores that as a normal text fact — image bytes never leave
        the LLM call.

        ``llm`` / ``embedder`` are per-request model overrides:

            client.add(
                messages=[...],
                user_id="alice",
                llm={"provider": "anthropic", "model": "claude-haiku-4-5-20251001"},
            )

        Pass ``api_key`` inside the dict to BYOK for that single call::

            llm={"provider": "anthropic", "model": "claude-haiku-4-5-20251001",
                 "api_key": "sk-ant-…"}

        ``expiration_date`` (ISO-8601) makes the row invisible to
        retrieval after the cutoff. Stored as ``metadata.expiration_date``;
        TTL enforcement is at retrieval time, no background sweep.
        """
        payload: Dict[str, Any] = {
            "messages": messages,
            "user_id": user_id,
            "agent_id": agent_id,
            "run_id": run_id,
            "metadata": metadata,
            "infer": infer,
        }
        if llm is not None:
            payload["llm"] = llm
        if embedder is not None:
            payload["embedder"] = embedder
        if expiration_date is not None:
            payload["expiration_date"] = expiration_date
        return self._json("POST", "/v1/memories/", json=payload)

    def get_all(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        limit: int = 100,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        version: Optional[str] = None,
        output_format: Optional[str] = None,
        includes: Optional[List[str]] = None,
        excludes: Optional[List[str]] = None,
    ) -> Any:
        """List memories matching the supplied scope.

        ``page`` / ``page_size`` slice the materialised result set at
        the route layer. Walking deeper than ``limit`` requires raising
        ``limit`` accordingly — the underlying vector store only fetches
        ``limit`` rows. Default behaviour (omit page kwargs) is unchanged.

        ``version`` / ``output_format`` / ``includes`` / ``excludes``
        behave as in :meth:`search` — contextkit-compat passthrough that
        re-shapes the client-side response.
        """
        params = {
            k: v
            for k, v in {
                "user_id": user_id,
                "agent_id": agent_id,
                "run_id": run_id,
                "limit": limit,
                "page": page,
                "page_size": page_size,
            }.items()
            if v is not None
        }
        result = self._json("GET", "/v1/memories/", params=params)
        return _shape_result(result, output_format=output_format, includes=includes, excludes=excludes)

    def get(self, memory_id: str) -> Any:
        return self._json("GET", f"/v1/memories/{memory_id}/")

    def search(
        self,
        query: str,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 10,
        llm: Optional[Dict[str, Any]] = None,
        embedder: Optional[Dict[str, Any]] = None,
        threshold: Optional[float] = None,
        use_context_graph: Optional[bool] = None,
        categories: Optional[List[str]] = None,
        top_k: Optional[int] = None,
        version: Optional[str] = None,
        output_format: Optional[str] = None,
        includes: Optional[List[str]] = None,
        excludes: Optional[List[str]] = None,
        use_tcmgm: Optional[bool] = None,
        time_window: Optional[Dict[str, Any]] = None,
        include_causal: Optional[bool] = None,
        keyword_search: Optional[bool] = None,
        filter_memories: Optional[bool] = None,
    ) -> Any:
        """Vector-search the project. ``llm`` / ``embedder`` overrides
        accepted as in :meth:`add`.

        ``threshold`` — minimum score [0..1]; rows below are dropped.
        ``use_context_graph`` — route through CGL pipeline (graph-first
            seeding + BFS expansion + re-rank). Falls back to plain
            vector search when CGL is disabled in MemoryConfig.
        ``categories`` — list of metadata.categories values to match
            (any-of). Equivalent to passing ``filters={"categories": [...]}``.
        ``top_k`` — alias for ``limit``; honoured when both are passed.
        ``version`` / ``output_format`` — contextkit-compat shape selectors.
            Server currently emits the v1.1 shape regardless; the kwargs
            are accepted so callers porting from contextkit don't have to
            strip them, and ``output_format='v1.0'`` triggers a
            client-side compatibility unwrap that returns a bare list.
        ``includes`` / ``excludes`` — return-shape trimmers applied
            client-side after the response arrives. Useful for slimming
            payloads on memory-heavy clients (mobile / edge).
        ``use_tcmgm`` — opt-in TCMGM (Temporal-Causal Multimodal Graph
            Memory) fused retrieval. Combines vector hits with timeline
            + causal-graph expansion in a single ranked envelope.
            Requires the project's ``enable_graph=True`` so the engine
            has the graph + timeline stack initialised; otherwise it's
            a no-op that falls back to plain vector search. Response
            shape stays ``{"results": [...]}`` and gains
            ``timeline_results`` + ``causal_chains`` + ``fused_ranking``
            siblings when TCMGM actually runs.
        ``time_window`` — ``{"start": ISO, "end": ISO}`` filter on the
            TCMGM timeline stage. No-op when ``use_tcmgm=False``.
        ``include_causal`` — explicit override for causal-chain
            expansion within TCMGM (defaults to ``True`` engine-side).
        """
        if top_k is not None:
            limit = top_k
        payload: Dict[str, Any] = {
            "query": query,
            "user_id": user_id,
            "agent_id": agent_id,
            "run_id": run_id,
            "filters": filters,
            "limit": limit,
        }
        if llm is not None:
            payload["llm"] = llm
        if embedder is not None:
            payload["embedder"] = embedder
        if threshold is not None:
            payload["threshold"] = threshold
        if use_context_graph is not None:
            payload["use_context_graph"] = use_context_graph
        if categories is not None:
            payload["categories"] = categories
        if use_tcmgm is not None:
            payload["use_tcmgm"] = use_tcmgm
        if time_window is not None:
            payload["time_window"] = time_window
        if include_causal is not None:
            payload["include_causal"] = include_causal
        if keyword_search is not None:
            payload["keyword_search"] = keyword_search
        if filter_memories is not None:
            payload["filter_memories"] = filter_memories
        result = self._json("POST", "/v1/memories/search/", json=payload)
        return _shape_result(result, output_format=output_format, includes=includes, excludes=excludes)

    def update(self, memory_id: str, *, text: Optional[str] = None) -> Any:
        if text is None:
            raise ValueError("update(): provide text=...")
        return self._json("PUT", f"/v1/memories/{memory_id}/", json={"text": text})

    def history(
        self,
        memory_id: str,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
    ) -> Any:
        """Per-memory change log.

        ``since`` / ``until`` are ISO-8601 timestamps that filter the
        events at the route layer. Without them the full log is
        returned — matches the original v1.0 behaviour.
        """
        params: Dict[str, Any] = {}
        if since is not None:
            params["since"] = since
        if until is not None:
            params["until"] = until
        return self._json(
            "GET", f"/v1/memories/{memory_id}/history/", params=params or None
        )

    def delete(self, memory_id: str) -> Any:
        return self._json("DELETE", f"/v1/memories/{memory_id}/")

    def delete_all(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Any:
        params = {
            k: v
            for k, v in {
                "user_id": user_id,
                "agent_id": agent_id,
                "run_id": run_id,
            }.items()
            if v is not None
        }
        return self._json("DELETE", "/v1/memories/", params=params)

    # ----- Feedback / reset / entities --------------------------------------

    def feedback(
        self,
        memory_id: str,
        *,
        feedback: Optional[str] = None,
        helpful: Optional[bool] = None,
        feedback_reason: Optional[str] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        query: Optional[str] = None,
    ) -> Any:
        """Record a verdict on a retrieved memory (MSPR/F3).

        Either pass contextkit-compat ``feedback="POSITIVE"|"NEGATIVE"|"VERY_NEGATIVE"``
        OR engine-native ``helpful=True/False``. ``helpful`` wins when
        both are set. The cloud maps both onto the engine's
        ``record_feedback`` boolean.

        Returns ``{"recorded": True, "memory_id": ..., "delta_applied": ...,
        "new_relevance": ..., "event_id": ..., "helpful": ...}`` on
        success. Returns ``{"recorded": False, "reason": "..."}`` when
        MSPR or feedback is disabled in the cloud build — non-fatal so
        callers can wrap retrieval flows without try/except.
        """
        body: Dict[str, Any] = {"memory_id": memory_id}
        if feedback is not None:
            body["feedback"] = feedback
        if helpful is not None:
            body["helpful"] = helpful
        if feedback_reason is not None:
            body["feedback_reason"] = feedback_reason
        if user_id is not None:
            body["user_id"] = user_id
        if agent_id is not None:
            body["agent_id"] = agent_id
        if run_id is not None:
            body["run_id"] = run_id
        if query is not None:
            body["query"] = query
        return self._json("POST", "/v1/memories/feedback/", json=body)

    def reset(self) -> Any:
        """Tenant-scoped wipe — every row tagged with this API key's tenant."""
        return self._json("POST", "/v1/memories/reset/")

    def users(self, *, limit: int = 1000) -> Any:
        """List every distinct user_id / agent_id / run_id under this tenant.

        Returns ``{"results": [{"id": "...", "type": "user|agent|run"}]}``.
        """
        return self._json("GET", "/v1/memories/entities/", params={"limit": limit})

    def delete_users(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Any:
        """Wipe every memory tagged with the given entity id.

        Pass exactly one of ``user_id`` / ``agent_id`` / ``run_id``.
        """
        kinds = {"user_id": user_id, "agent_id": agent_id, "run_id": run_id}
        chosen = {k: v for k, v in kinds.items() if v is not None}
        if len(chosen) != 1:
            raise ValueError("delete_users(): pass exactly one of user_id/agent_id/run_id.")
        kind, val = next(iter(chosen.items()))
        kind_short = kind.removesuffix("_id")
        return self._json("DELETE", f"/v1/memories/entities/{kind_short}/{val}/")

    # ----- Batch update / delete --------------------------------------------

    def batch_update(self, memories: List[Dict[str, Any]]) -> Any:
        """Update up to 1000 memories per call.

        Each entry: ``{"memory_id": "...", "text": "..."}``.
        """
        return self._json("PUT", "/v1/memories/batch/", json={"memories": memories})

    def batch_delete(self, memory_ids: List[str]) -> Any:
        """Delete up to 1000 memories per call by id."""
        return self._json(
            "DELETE", "/v1/memories/batch/", json={"memory_ids": memory_ids}
        )

    # ----- Summary / export -------------------------------------------------

    def summary(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 200,
        llm: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """LLM-distilled brief over rows matching the supplied scope.

        Returns ``{"summary": "...", "memory_count": N}``.
        """
        body: Dict[str, Any] = {
            "user_id": user_id,
            "agent_id": agent_id,
            "run_id": run_id,
            "filters": filters,
            "limit": limit,
        }
        if llm is not None:
            body["llm"] = llm
        return self._json("POST", "/v1/memories/summary/", json=body)

    def export(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        include_history: bool = False,
        limit: int = 10000,
    ) -> Any:
        """GDPR-style synchronous export.

        Returns ``{"exported_at": ISO, "tenant_id": ..., "memory_count": N,
        "memories": [...]}``. When ``include_history=True`` each row
        carries its full change log under a ``history`` key.
        """
        body: Dict[str, Any] = {
            "user_id": user_id,
            "agent_id": agent_id,
            "run_id": run_id,
            "filters": filters,
            "include_history": include_history,
            "limit": limit,
        }
        return self._json("POST", "/v1/memories/export/", json=body)

    # ----- Phase 1.5 — engine-shipped surfaces previously unwired -------

    # Versioning
    def versions(self, memory_id: str) -> Any:
        """Return every version row for ``memory_id`` (immutable mode)."""
        return self._json("GET", f"/v1/memories/{memory_id}/versions/")

    def latest_version(self, memory_id: str) -> Any:
        return self._json("GET", f"/v1/memories/{memory_id}/latest_version/")

    def rollback(self, memory_id: str, *, to_version: int) -> Any:
        """Roll a memory back to ``to_version``. Writes a new immutable
        row carrying the old payload + a ``rolled_back_from`` metadata
        tag. Original versions stay queryable via :meth:`versions`.
        """
        return self._json(
            "POST",
            f"/v1/memories/{memory_id}/rollback/",
            json={"to_version": to_version},
        )

    def diff_versions(self, old: str, new: str) -> Any:
        """Diff two memory rows. Engine default uses unified-diff format."""
        return self._json(
            "GET", "/v1/memories/diff/", params={"old": old, "new": new}
        )

    # Decay v2
    def tick_decay(self) -> Any:
        return self._json("POST", "/v1/memories/decay/tick/")

    def archive_low(
        self,
        *,
        threshold: Optional[float] = None,
        dry_run: bool = False,
    ) -> Any:
        body: Dict[str, Any] = {"dry_run": dry_run}
        if threshold is not None:
            body["threshold"] = threshold
        return self._json("POST", "/v1/memories/decay/archive_low/", json=body)

    def decay_score(self, memory_id: str) -> Any:
        return self._json("GET", f"/v1/memories/{memory_id}/decay_score/")

    # Cold storage
    def demote_to_cold(self, memory_id: str) -> Any:
        return self._json("POST", f"/v1/memories/{memory_id}/cold/demote/")

    def promote_from_cold(self, memory_id: str) -> Any:
        return self._json("POST", f"/v1/memories/{memory_id}/cold/promote/")

    # References (Phase D6)
    def record_reference(self, memory_id: str, *, strength: float = 1.0) -> Any:
        """Distinct from feedback — call this when an agent actually
        consumed the row in its response (vs only retrieving it).
        Bumps access_count + last_accessed_at on the CGL node."""
        return self._json(
            "POST",
            f"/v1/memories/{memory_id}/reference/",
            json={"strength": strength},
        )

    # Backfill
    def backfill(
        self,
        kind: str,
        *,
        batch_size: Optional[int] = None,
        embed: Optional[bool] = None,
    ) -> Any:
        """Idempotent reconstruction of ``context_graph`` / ``mspr`` /
        ``decay_v2`` from existing vector + history rows. Useful after
        flipping a feature on a project that already has data."""
        body: Dict[str, Any] = {}
        if batch_size is not None:
            body["batch_size"] = batch_size
        if embed is not None:
            body["embed"] = embed
        return self._json("POST", f"/v1/memories/backfill/{kind}/", json=body)

    # Reset CGL / feedback
    def reset_cgl(self) -> Any:
        return self._json("POST", "/v1/memories/reset_cgl/")

    def reset_feedback(self, *, user_id: Optional[str] = None) -> Any:
        body: Dict[str, Any] = {}
        if user_id is not None:
            body["user_id"] = user_id
        return self._json("POST", "/v1/memories/reset_feedback/", json=body)

    # ----- Phase 1.6 — pin / hybrid / LLM filter / advanced filters / idempotency

    def pin(self, memory_id: str) -> Any:
        """Mark a memory immutable. update / delete return 409 on locked rows."""
        return self._json("POST", f"/v1/memories/{memory_id}/pin/")

    def unpin(self, memory_id: str) -> Any:
        return self._json("POST", f"/v1/memories/{memory_id}/unpin/")

    def add_idempotent(
        self,
        idempotency_key: str,
        messages: Any,
        **kwargs: Any,
    ) -> Any:
        """Same as :meth:`add` but sends ``Idempotency-Key`` so a retry
        with the same key returns the cached response without
        re-running fact extraction.

        Cache lives in-process on the cloud — replay protection is
        per worker, sufficient for the common "pre-flight POST timed
        out, retry once" pattern.
        """
        # Build the JSON body the same way :meth:`add` does, then
        # send via _request so we can attach the Idempotency-Key
        # header (the regular _json wrapper doesn't take headers).
        payload: Dict[str, Any] = {"messages": messages}
        payload.update({k: v for k, v in kwargs.items() if v is not None})
        resp = self._request(
            "POST", "/v1/memories/", json=payload,
            headers={"Idempotency-Key": idempotency_key},
        )
        if not resp.is_success:
            raise _decode_error(resp)
        return resp.json() if resp.content else None

    # search() already accepts keyword_search / filter_memories /
    # filters={...} kwargs from earlier phases — Phase 1.6 just adds
    # cloud-side handlers for them. Surface them explicitly here so
    # the static signature surfaces the new options, even though
    # **kwargs on AsyncMemoryClient.search already pipes them through.

    def get_all_filtered(
        self,
        filters: Dict[str, Any],
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        limit: int = 100,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
    ) -> Any:
        """``get_all`` with the full Phase 1.6 operator filter dict.

        Body cannot be sent on a GET, so the dict is JSON-encoded into
        the ``filters_json`` query param. Operators supported:
        ``$eq``, ``$ne``, ``$gt``, ``$gte``, ``$lt``, ``$lte``, ``$in``,
        ``$nin``, ``$contains`` plus ``AND`` / ``OR`` / ``NOT``
        composition. Example::

            client.get_all_filtered(
                {"AND": [
                    {"created_at": {"$gt": "2026-01-01T00:00:00Z"}},
                    {"OR": [
                        {"metadata.priority": {"$gte": 5}},
                        {"metadata.tag": {"$in": ["urgent", "p0"]}},
                    ]},
                ]},
                user_id="alice",
            )
        """
        import json as _json
        params: Dict[str, Any] = {
            "filters_json": _json.dumps(filters),
            "limit": limit,
        }
        for k, v in {
            "user_id": user_id, "agent_id": agent_id, "run_id": run_id,
            "page": page, "page_size": page_size,
        }.items():
            if v is not None:
                params[k] = v
        return self._json("GET", "/v1/memories/", params=params)

    # ----- Project / workspace management (Phase 1.3) --------------------

    def list_projects(self) -> Any:
        """Every project the caller's organization owns."""
        return self._json("GET", "/v1/projects/")

    def create_project(
        self,
        name: str,
        *,
        slug: Optional[str] = None,
        llm_provider: Optional[str] = None,
        llm_model: Optional[str] = None,
        embedder_provider: Optional[str] = None,
        embedder_model: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
        retrieval_criteria: Optional[Dict[str, Any]] = None,
        enable_graph: Optional[bool] = None,
        api_version: Optional[str] = None,
    ) -> Any:
        """Create a project under the calling user's current org. Clerk-only."""
        body: Dict[str, Any] = {"name": name}
        for k, v in {
            "slug": slug,
            "llm_provider": llm_provider,
            "llm_model": llm_model,
            "embedder_provider": embedder_provider,
            "embedder_model": embedder_model,
            "custom_instructions": custom_instructions,
            "custom_categories": custom_categories,
            "retrieval_criteria": retrieval_criteria,
            "enable_graph": enable_graph,
            "api_version": api_version,
        }.items():
            if v is not None:
                body[k] = v
        return self._json("POST", "/v1/projects/", json=body)

    def get_project(self, project_id: str) -> Any:
        return self._json("GET", f"/v1/projects/{project_id}")

    def update_project(
        self,
        project_id: str,
        *,
        llm_provider: Optional[str] = None,
        llm_model: Optional[str] = None,
        llm_api_key: Optional[str] = None,
        embedder_provider: Optional[str] = None,
        embedder_model: Optional[str] = None,
        embedder_api_key: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        custom_categories: Optional[List[str]] = None,
        retrieval_criteria: Optional[Dict[str, Any]] = None,
        enable_graph: Optional[bool] = None,
        api_version: Optional[str] = None,
        multilingual: Optional[bool] = None,
        memory_depth: Optional[int] = None,
        usecase_setting: Optional[str] = None,
    ) -> Any:
        """PATCH a subset of project fields. Clerk-only.

        Mirrors the dashboard ``Settings → Save`` flow — pass only the
        fields you want to change. ``None`` skips, empty string / list /
        dict clears.

        Phase 1.7 fields:

        * ``multilingual`` — bool. When True, the cloud appends a
          'preserve original-language phrasing' directive to the
          fact-extraction prompt.
        * ``memory_depth`` — int 1..200. Persisted on the project for
          dashboard surfacing; engine reads its own update-context
          limits.
        * ``usecase_setting`` — preset name (``support`` /
          ``personal-assistant`` / ``research`` / ``sales``). Cloud
          appends a use-case-specific instruction snippet to the
          extraction prompt.
        """
        body: Dict[str, Any] = {}
        for k, v in {
            "llm_provider": llm_provider,
            "llm_model": llm_model,
            "llm_api_key": llm_api_key,
            "embedder_provider": embedder_provider,
            "embedder_model": embedder_model,
            "embedder_api_key": embedder_api_key,
            "custom_instructions": custom_instructions,
            "custom_categories": custom_categories,
            "retrieval_criteria": retrieval_criteria,
            "enable_graph": enable_graph,
            "api_version": api_version,
            "multilingual": multilingual,
            "memory_depth": memory_depth,
            "usecase_setting": usecase_setting,
        }.items():
            if v is not None:
                body[k] = v
        return self._json("PATCH", f"/v1/projects/{project_id}", json=body)

    def delete_project(self, project_id: str) -> Any:
        """Soft-delete (sets is_active=False; audit trail preserved). Clerk-only."""
        return self._json("DELETE", f"/v1/projects/{project_id}")

    # ----- Project members + RBAC ----------------------------------------

    def list_members(self, project_id: str) -> Any:
        return self._json("GET", f"/v1/projects/{project_id}/members")

    def add_member(self, project_id: str, *, email: str, role: str = "READER") -> Any:
        """Bind an existing user (matched by email) into the project's org."""
        return self._json(
            "POST",
            f"/v1/projects/{project_id}/members",
            json={"email": email, "role": role},
        )

    def update_member(self, project_id: str, member_id: str, *, role: str) -> Any:
        return self._json(
            "PATCH",
            f"/v1/projects/{project_id}/members/{member_id}",
            json={"role": role},
        )

    def remove_member(self, project_id: str, member_id: str) -> Any:
        return self._json("DELETE", f"/v1/projects/{project_id}/members/{member_id}")

    # ----- Project webhooks ---------------------------------------------

    def list_webhooks(self, project_id: str) -> Any:
        return self._json("GET", f"/v1/projects/{project_id}/webhooks")

    def create_webhook(
        self,
        project_id: str,
        *,
        url: str,
        event_types: Optional[List[str]] = None,
        secret: Optional[str] = None,
        is_active: bool = True,
    ) -> Any:
        """Register an outbound webhook. Returns the webhook + its secret.

        The cloud signs every delivery's body with HMAC-SHA256 of the
        secret. Receivers should compute the same HMAC and compare in
        constant time.
        """
        body: Dict[str, Any] = {"url": url, "is_active": is_active}
        if event_types is not None:
            body["event_types"] = event_types
        if secret is not None:
            body["secret"] = secret
        return self._json("POST", f"/v1/projects/{project_id}/webhooks", json=body)

    def update_webhook(
        self,
        project_id: str,
        webhook_id: str,
        *,
        url: Optional[str] = None,
        event_types: Optional[List[str]] = None,
        secret: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Any:
        body: Dict[str, Any] = {}
        for k, v in {
            "url": url,
            "event_types": event_types,
            "secret": secret,
            "is_active": is_active,
        }.items():
            if v is not None:
                body[k] = v
        return self._json(
            "PATCH",
            f"/v1/projects/{project_id}/webhooks/{webhook_id}",
            json=body,
        )

    def delete_webhook(self, project_id: str, webhook_id: str) -> Any:
        return self._json(
            "DELETE", f"/v1/projects/{project_id}/webhooks/{webhook_id}"
        )

    # ----- API-key management (Clerk JWT only — for dashboard parity) ----
    def list_api_keys(self) -> Any:
        return self._json("GET", "/v1/api-keys")

    def create_api_key(
        self,
        name: str,
        *,
        scopes: Optional[List[str]] = None,
        environment: str = "live",
        project_id: Optional[str] = None,
    ) -> Any:
        """Mint a new API key. Clerk-only.

        Phase 1.7 — pass ``project_id`` to bind the new key to a
        non-default project (e.g. minting a 'production' key for a
        team's prod project + a 'sandbox' key for their dev project).
        Caller must be a member of the same organization that owns
        the project, otherwise the route returns 403.

        ``environment="test"`` mints a sandbox-prefixed key
        (``ock_test_…``); the cloud routes test-mode traffic to a
        physically separate pgvector collection per (project, env)
        so test rows can never leak into production memory.
        """
        body: Dict[str, Any] = {
            "name": name,
            "scopes": scopes,
            "environment": environment,
        }
        if project_id is not None:
            body["project_id"] = project_id
        return self._json("POST", "/v1/api-keys", json=body)

    def revoke_api_key(self, api_key_id: str) -> Any:
        return self._json("DELETE", f"/v1/api-keys/{api_key_id}")

    # ----- lifecycle ------------------------------------------------------
    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "MemoryClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ────────────────────────────────────────────────────────────────────────────
# Async twin
# ────────────────────────────────────────────────────────────────────────────


class AsyncMemoryClient:
    """Async equivalent of :class:`MemoryClient` (httpx.AsyncClient under the hood)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        host: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        client: Optional[httpx.AsyncClient] = None,
        allow_dev_fallback: bool = True,
    ) -> None:
        self.api_key = api_key or os.environ.get("OUTHAD_CONTEXTKIT_API_KEY")
        if not self.api_key:
            raise AuthenticationError(
                "Outhad ContextKit API key not provided.",
                status=401,
            )
        explicit_host = host is not None or "OUTHAD_CONTEXTKIT_HOST" in os.environ
        self.host = _select_host(host)
        self.timeout = timeout
        self._allow_fallback = allow_dev_fallback and not explicit_host
        self._fell_back = False
        self._owns_client = client is None

        headers = {
            "Authorization": f"Token {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "outhad-contextkit-sdk-python-async/1.1.0",
        }
        if client is None:
            self._client = httpx.AsyncClient(
                base_url=self.host, timeout=timeout, headers=headers
            )
        else:
            self._client = client
            self._client.base_url = httpx.URL(self.host)
            self._client.headers.update(headers)

    # ----- private --------------------------------------------------------
    def _retarget(self, host: str) -> None:
        self.host = host.rstrip("/")
        self._client.base_url = httpx.URL(self.host)
        self._fell_back = True

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        try:
            return await self._client.request(method, path, **kwargs)
        except Exception as exc:
            if (
                self._allow_fallback
                and not self._fell_back
                and self.host == DEFAULT_HOST
                and _is_connection_failure(exc)
            ):
                logger.warning(
                    "Production host %s unreachable (%s) — retrying against %s",
                    DEFAULT_HOST,
                    exc.__class__.__name__,
                    DEV_HOST,
                )
                self._retarget(DEV_HOST)
                return await self._client.request(method, path, **kwargs)
            raise

    async def _json(self, method: str, path: str, **kwargs) -> Any:
        resp = await self._request(method, path, **kwargs)
        if not resp.is_success:
            raise _decode_error(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    async def validate(self) -> Dict[str, Any]:
        resp = await self._request("GET", "/v1/ping/")
        if resp.status_code == 401:
            raise AuthenticationError("API key rejected.", status=401)
        if not resp.is_success:
            raise APIError(
                f"Failed to reach Outhad ContextKit cloud at {self.host}",
                status=resp.status_code,
                body=resp.text,
            )
        return resp.json() if resp.content else {}

    # ----- memory CRUD ----------------------------------------------------
    async def add(
        self,
        messages,
        *,
        llm: Optional[Dict[str, Any]] = None,
        embedder: Optional[Dict[str, Any]] = None,
        **kw,
    ) -> Any:
        body: Dict[str, Any] = {"messages": messages, **kw}
        if llm is not None:
            body["llm"] = llm
        if embedder is not None:
            body["embedder"] = embedder
        return await self._json("POST", "/v1/memories/", json=body)

    async def get_all(self, **kw) -> Any:
        return await self._json("GET", "/v1/memories/", params=kw)

    async def get(self, memory_id: str) -> Any:
        return await self._json("GET", f"/v1/memories/{memory_id}/")

    async def search(
        self,
        query: str,
        *,
        llm: Optional[Dict[str, Any]] = None,
        embedder: Optional[Dict[str, Any]] = None,
        **kw,
    ) -> Any:
        body: Dict[str, Any] = {"query": query, **kw}
        if llm is not None:
            body["llm"] = llm
        if embedder is not None:
            body["embedder"] = embedder
        return await self._json("POST", "/v1/memories/search/", json=body)

    async def update(self, memory_id: str, *, text: str) -> Any:
        return await self._json("PUT", f"/v1/memories/{memory_id}/", json={"text": text})

    async def history(
        self,
        memory_id: str,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
    ) -> Any:
        params: Dict[str, Any] = {}
        if since is not None:
            params["since"] = since
        if until is not None:
            params["until"] = until
        return await self._json(
            "GET",
            f"/v1/memories/{memory_id}/history/",
            params=params or None,
        )

    async def delete(self, memory_id: str) -> Any:
        return await self._json("DELETE", f"/v1/memories/{memory_id}/")

    async def delete_all(self, **kw) -> Any:
        return await self._json("DELETE", "/v1/memories/", params=kw)

    # ----- Phase-1.2 ops (feedback / reset / users / batch / summary / export) -----

    async def feedback(self, memory_id: str, **kw) -> Any:
        body = {"memory_id": memory_id, **{k: v for k, v in kw.items() if v is not None}}
        return await self._json("POST", "/v1/memories/feedback/", json=body)

    async def reset(self) -> Any:
        return await self._json("POST", "/v1/memories/reset/")

    async def users(self, *, limit: int = 1000) -> Any:
        return await self._json("GET", "/v1/memories/entities/", params={"limit": limit})

    async def delete_users(
        self,
        *,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Any:
        kinds = {"user_id": user_id, "agent_id": agent_id, "run_id": run_id}
        chosen = {k: v for k, v in kinds.items() if v is not None}
        if len(chosen) != 1:
            raise ValueError(
                "delete_users(): pass exactly one of user_id/agent_id/run_id."
            )
        kind, val = next(iter(chosen.items()))
        kind_short = kind.removesuffix("_id")
        return await self._json(
            "DELETE", f"/v1/memories/entities/{kind_short}/{val}/"
        )

    async def batch_update(self, memories: List[Dict[str, Any]]) -> Any:
        return await self._json(
            "PUT", "/v1/memories/batch/", json={"memories": memories}
        )

    async def batch_delete(self, memory_ids: List[str]) -> Any:
        return await self._json(
            "DELETE", "/v1/memories/batch/", json={"memory_ids": memory_ids}
        )

    async def summary(self, **kw) -> Any:
        return await self._json("POST", "/v1/memories/summary/", json=kw)

    async def export(self, **kw) -> Any:
        return await self._json("POST", "/v1/memories/export/", json=kw)

    # ----- Phase 1.5 ops (versioning / decay / cold / refs / backfill / reset) ---

    async def versions(self, memory_id: str) -> Any:
        return await self._json("GET", f"/v1/memories/{memory_id}/versions/")

    async def latest_version(self, memory_id: str) -> Any:
        return await self._json("GET", f"/v1/memories/{memory_id}/latest_version/")

    async def rollback(self, memory_id: str, *, to_version: int) -> Any:
        return await self._json(
            "POST", f"/v1/memories/{memory_id}/rollback/",
            json={"to_version": to_version},
        )

    async def diff_versions(self, old: str, new: str) -> Any:
        return await self._json(
            "GET", "/v1/memories/diff/", params={"old": old, "new": new}
        )

    async def tick_decay(self) -> Any:
        return await self._json("POST", "/v1/memories/decay/tick/")

    async def archive_low(
        self, *, threshold: Optional[float] = None, dry_run: bool = False
    ) -> Any:
        body: Dict[str, Any] = {"dry_run": dry_run}
        if threshold is not None:
            body["threshold"] = threshold
        return await self._json(
            "POST", "/v1/memories/decay/archive_low/", json=body
        )

    async def decay_score(self, memory_id: str) -> Any:
        return await self._json("GET", f"/v1/memories/{memory_id}/decay_score/")

    async def demote_to_cold(self, memory_id: str) -> Any:
        return await self._json("POST", f"/v1/memories/{memory_id}/cold/demote/")

    async def promote_from_cold(self, memory_id: str) -> Any:
        return await self._json("POST", f"/v1/memories/{memory_id}/cold/promote/")

    async def record_reference(self, memory_id: str, *, strength: float = 1.0) -> Any:
        return await self._json(
            "POST", f"/v1/memories/{memory_id}/reference/",
            json={"strength": strength},
        )

    async def backfill(
        self, kind: str, *, batch_size: Optional[int] = None, embed: Optional[bool] = None
    ) -> Any:
        body: Dict[str, Any] = {}
        if batch_size is not None:
            body["batch_size"] = batch_size
        if embed is not None:
            body["embed"] = embed
        return await self._json("POST", f"/v1/memories/backfill/{kind}/", json=body)

    async def reset_cgl(self) -> Any:
        return await self._json("POST", "/v1/memories/reset_cgl/")

    async def reset_feedback(self, *, user_id: Optional[str] = None) -> Any:
        body: Dict[str, Any] = {}
        if user_id is not None:
            body["user_id"] = user_id
        return await self._json("POST", "/v1/memories/reset_feedback/", json=body)

    # ----- Phase 1.6 ops (pin / idempotent add / advanced filter get_all) -----

    async def pin(self, memory_id: str) -> Any:
        return await self._json("POST", f"/v1/memories/{memory_id}/pin/")

    async def unpin(self, memory_id: str) -> Any:
        return await self._json("POST", f"/v1/memories/{memory_id}/unpin/")

    async def add_idempotent(self, idempotency_key: str, messages: Any, **kw) -> Any:
        payload: Dict[str, Any] = {"messages": messages}
        payload.update({k: v for k, v in kw.items() if v is not None})
        resp = await self._request(
            "POST", "/v1/memories/", json=payload,
            headers={"Idempotency-Key": idempotency_key},
        )
        if not resp.is_success:
            raise _decode_error(resp)
        return resp.json() if resp.content else None

    async def get_all_filtered(
        self, filters: Dict[str, Any], **kw: Any
    ) -> Any:
        import json as _json
        params: Dict[str, Any] = {"filters_json": _json.dumps(filters)}
        for k, v in kw.items():
            if v is not None:
                params[k] = v
        return await self._json("GET", "/v1/memories/", params=params)

    # ----- Phase-1.3 ops (projects / members / webhooks) ----------------

    async def list_projects(self) -> Any:
        return await self._json("GET", "/v1/projects/")

    async def create_project(self, name: str, **kw) -> Any:
        body = {"name": name, **{k: v for k, v in kw.items() if v is not None}}
        return await self._json("POST", "/v1/projects/", json=body)

    async def get_project(self, project_id: str) -> Any:
        return await self._json("GET", f"/v1/projects/{project_id}")

    async def update_project(self, project_id: str, **kw) -> Any:
        body = {k: v for k, v in kw.items() if v is not None}
        return await self._json("PATCH", f"/v1/projects/{project_id}", json=body)

    async def delete_project(self, project_id: str) -> Any:
        return await self._json("DELETE", f"/v1/projects/{project_id}")

    async def list_members(self, project_id: str) -> Any:
        return await self._json("GET", f"/v1/projects/{project_id}/members")

    async def add_member(
        self, project_id: str, *, email: str, role: str = "READER"
    ) -> Any:
        return await self._json(
            "POST",
            f"/v1/projects/{project_id}/members",
            json={"email": email, "role": role},
        )

    async def update_member(
        self, project_id: str, member_id: str, *, role: str
    ) -> Any:
        return await self._json(
            "PATCH",
            f"/v1/projects/{project_id}/members/{member_id}",
            json={"role": role},
        )

    async def remove_member(self, project_id: str, member_id: str) -> Any:
        return await self._json(
            "DELETE", f"/v1/projects/{project_id}/members/{member_id}"
        )

    async def list_webhooks(self, project_id: str) -> Any:
        return await self._json("GET", f"/v1/projects/{project_id}/webhooks")

    async def create_webhook(self, project_id: str, *, url: str, **kw) -> Any:
        body = {"url": url, **{k: v for k, v in kw.items() if v is not None}}
        return await self._json(
            "POST", f"/v1/projects/{project_id}/webhooks", json=body
        )

    async def update_webhook(
        self, project_id: str, webhook_id: str, **kw
    ) -> Any:
        body = {k: v for k, v in kw.items() if v is not None}
        return await self._json(
            "PATCH",
            f"/v1/projects/{project_id}/webhooks/{webhook_id}",
            json=body,
        )

    async def delete_webhook(self, project_id: str, webhook_id: str) -> Any:
        return await self._json(
            "DELETE", f"/v1/projects/{project_id}/webhooks/{webhook_id}"
        )

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncMemoryClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()


__all__ = [
    "DEFAULT_HOST",
    "DEV_HOST",
    "AsyncMemoryClient",
    "MemoryClient",
]
