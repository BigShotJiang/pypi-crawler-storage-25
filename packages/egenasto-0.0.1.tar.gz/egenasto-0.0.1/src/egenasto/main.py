"""A task 2 library code"""
def xyzw(variable_amount, f, function):
    if variable_amount == 4:
        print("X Y Z W")
        for x in range(2):
            for y in range(2):
                for z in range(2):
                    for w in range(2):
                        if function(x, y, z, w) == f:
                            print(x, y, z, w)
#function must be "lambda x, y, z, w: (your task function)"
#example: for "F = (y == z) and (x <= y)" write "lambda x, y, z: (y == z) and (x <= y)"
"""A task 26 library codes"""
def binary_search(target, searching_list):
    left, right = 0, len(searching_list) - 1
    while left <= right:
        mid = (left + right) // 2
        if searching_list[mid] == target:
            return True
        elif searching_list[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return False