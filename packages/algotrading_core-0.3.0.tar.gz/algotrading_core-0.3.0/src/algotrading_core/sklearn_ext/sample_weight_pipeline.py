"""Pipeline subclass that forwards ``sample_weight`` to the final estimator.

Used by the side-model training pipeline so ``BaggingClassifier`` fits base
estimators with per-sample weights. Defined in **algotrading-core** so joblib
artifacts deserialize in ``algotrading-backend`` without ``algotrading_research``.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline


class SampleWeightPipeline(Pipeline):
    """Pipeline that forwards ``sample_weight`` to the final estimator.

    Standard ``sklearn.pipeline.Pipeline.fit`` does not pass
    ``sample_weight`` through to the last step. This subclass intercepts
    it and injects the correct ``step_name__sample_weight`` key.
    """

    def fit(
        self,
        X: pd.DataFrame | np.ndarray,
        y: pd.Series | np.ndarray,
        sample_weight: pd.Series | np.ndarray | None = None,
        **fit_params: object,
    ) -> SampleWeightPipeline:
        """Fit the pipeline, forwarding sample_weight to the last step.

        Args:
            X: Feature matrix.
            y: Labels.
            sample_weight: Per-sample weights forwarded to the last step.
            **fit_params: Additional fit parameters.

        Returns:
            Fitted pipeline (self).
        """
        if sample_weight is not None:
            final_step_name = self.steps[-1][0]
            fit_params[f"{final_step_name}__sample_weight"] = sample_weight
        return super().fit(X, y, **fit_params)
