"""Scikit-learn extensions shared across research and backend (pickle-safe)."""

from algotrading_core.sklearn_ext.sample_weight_pipeline import SampleWeightPipeline

__all__ = ["SampleWeightPipeline"]
