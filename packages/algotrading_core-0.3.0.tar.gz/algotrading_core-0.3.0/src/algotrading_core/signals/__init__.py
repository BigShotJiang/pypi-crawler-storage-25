"""Signal detection utilities shared across research and backend.

Public API
----------
get_sr_breakout_events : Detect support/resistance breakout events.
get_exit_timestamps    : Compute exit timestamps for trade events.
"""

from algotrading_core.signals.breakout import get_exit_timestamps, get_sr_breakout_events

__all__ = [
    "get_sr_breakout_events",
    "get_exit_timestamps",
]
