# Plom common utilities Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [0.21.3] - 2026-05-12

### Fixed
* Asking about user roles on 0.20.x servers was broken.
* Fix client crash when asking for existing annotations from 0.20.x server.
* Don't append ":" when there is no port provided (such as when using default 80 or 443).


## 0.21.2 - 2026-05-11

### Changed
* These tools and libraries were previously developed as part of the main Plom repo, are now in this separate project.


[0.21.3]: https://gitlab.com/plom/plom-client/-/compare/v0.21.2...v0.21.3
