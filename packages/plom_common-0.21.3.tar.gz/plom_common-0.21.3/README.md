# plom-common

This is a support library for [Plom](https://plomgrading.org),
a shared dependency of various other Plom tools.


## Development

Running tests: `PYTHONPATH="." pytest`
`
