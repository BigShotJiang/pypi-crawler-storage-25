import logging
import os
from pyspark.sql import SparkSession

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def is_databricks():
    return "DATABRICKS_RUNTIME_VERSION" in os.environ


def execute_run_databricks(query, retrieve_result=True, load_data=False):
    result = None
    query = query.strip()

    try:
        server_hostname = os.getenv("DATABRICKS_SERVER_HOSTNAME")
        http_path = os.getenv("DATABRICKS_HTTP_PATH")
        access_token = os.getenv("DATABRICKS_ACCESS_TOKEN")

        # ✅ CASE 1: External connection (SQL Connector)
        if server_hostname and http_path and access_token:
            logger.info("Connecting to Databricks via SQL Connector...")

            # 🔥 Lazy import (FIX)
            from databricks import sql as databricks_sql

            conn = databricks_sql.connect(
                server_hostname=server_hostname,
                http_path=http_path,
                access_token=access_token
            )

            cursor = conn.cursor()

            if retrieve_result:
                cursor.execute(query)
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                result = [tuple(columns)] + rows

            elif load_data:
                return conn

            else:
                for single_query in query.split(";"):
                    if single_query.strip():
                        cursor.execute(single_query)

            cursor.close()
            conn.close()
            return result

        # ✅ CASE 2: Running inside Databricks
        elif is_databricks():
            logger.info("Running query using SparkSession inside Databricks...")

            spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()

            if retrieve_result:
                df = spark.sql(query)
                columns = df.columns
                rows = df.collect()
                result = [tuple(columns)] + [tuple(row) for row in rows]
                return result
            else:
                for single_query in query.split(";"):
                    if single_query.strip():
                        spark.sql(single_query)
                return None

        # ❌ CASE 3: Misconfiguration
        else:
            raise ValueError(
                "Databricks connection details not found and not running inside Databricks."
            )

    except Exception as e:
        logger.error("Error occurred while executing query on Databricks")
        logger.exception(e)
        raise