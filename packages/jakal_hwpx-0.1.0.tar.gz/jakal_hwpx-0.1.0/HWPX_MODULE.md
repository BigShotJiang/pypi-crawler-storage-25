# `jakal_hwpx` Module Notes

This document describes the Python package under `src/jakal_hwpx/`.

## Main Entry Point

### `HwpxDocument`

`HwpxDocument` is the primary public API.

It supports:

- opening an existing `.hwpx`
- creating a blank document
- reading and updating package metadata
- editing paragraph text
- appending paragraphs
- adding or replacing package parts
- validating package structure and references
- saving and round-tripping the package

Example:

```python
from jakal_hwpx import HwpxDocument

doc = HwpxDocument.open("example.hwpx")
doc.replace_text("before", "after")
doc.save("example-edited.hwpx")
```

## Package Layout

### `document.py`

Core document container and editing logic.

Key responsibilities:

- open, build, compile, and save HWPX zip packages
- expose high-level editing helpers
- preserve and update internal package parts
- perform structural validation

### `parts.py`

Low-level package part model.

Key responsibilities:

- represent content parts such as `header.xml`, `section*.xml`, and `content.hpf`
- distinguish XML, text, binary, and preview parts
- expose metadata helpers for `content.hpf`

### `elements.py`

Wrappers over frequently edited XML structures.

Examples:

- paragraph and character styles
- tables and table cells
- pictures
- notes
- equations
- bookmarks and fields
- headers and footers

### `xmlnode.py`

Small XML convenience wrapper used by other modules.

### `namespaces.py`

Namespace constants, QName helpers, and section path matching.

### `exceptions.py`

Custom exception types for invalid packages and validation failures.

## Validation Surfaces

The package exposes several complementary validation helpers:

- `validation_errors()`
- `xml_validation_errors()`
- `reference_validation_errors()`
- `save_reopen_validation_errors()`
- `roundtrip_validate()`

These checks catch different classes of failure: malformed XML, broken references, missing manifest entries, and packages that cannot be reopened after save.

## Public Types Re-Exported from `jakal_hwpx`

The package root re-exports:

- `HwpxDocument`
- `DocumentMetadata`
- `HwpxPart`
- `XmlPart`
- `SectionPart`
- `HeaderPart`
- `ContentHpfPart`
- `SettingsPart`
- `VersionPart`
- `MimetypePart`
- `ContainerPart`
- `ContainerRdfPart`
- `ManifestPart`
- `BinaryDataPart`
- `GenericBinaryPart`
- `GenericTextPart`
- `GenericXmlPart`
- `PreviewImagePart`
- `PreviewTextPart`
- `ScriptPart`
- `Picture`
- `Table`
- `TableCell`
- `Note`
- `Equation`
- `Bookmark`
- `Field`
- `AutoNumber`
- `HeaderFooterBlock`
- `SectionSettings`
- `StyleDefinition`
- `ParagraphStyle`
- `CharacterStyle`
- `ShapeObject`
- `HwpxError`
- `HwpxValidationError`
- `InvalidHwpxFileError`

## Round-Trip and Editing Notes

### Safe Editing Model

The package is designed around preserving package structure as much as possible:

- existing parts are loaded and kept in memory
- unknown parts are preserved by type inference
- zip entry metadata is cloned on compile when possible
- the document can be reopened and validated after save

### Distribution-Protected Packages

If `content.hpf` marks the package as distribution-protected, editable section XML may not be present.

In that case:

- the package can still be opened
- structural validation still works
- high-level editing APIs can be unavailable

### Why the Package Uses Element Wrappers

HWPX editing often requires working across:

- document metadata
- package manifests
- section XML
- style tables
- embedded binaries

The wrappers in `elements.py` let the rest of the code expose domain-specific operations without pushing raw XPath and XML bookkeeping into every call site.

## Typical Usage Patterns

### Inspect and validate a document

```python
from jakal_hwpx import HwpxDocument

doc = HwpxDocument.open("example.hwpx")

print(doc.metadata())
print(doc.validation_errors())
print(doc.reference_validation_errors())
```

### Update text and save

```python
from jakal_hwpx import HwpxDocument

doc = HwpxDocument.open("example.hwpx")
doc.replace_text("draft", "final")
doc.save("example-final.hwpx")
```

### Generate a blank document

```python
from jakal_hwpx import HwpxDocument

doc = HwpxDocument.blank()
doc.set_metadata(title="Generated")
doc.set_paragraph_text(0, 0, "Hello")
doc.save("build/blank.hwpx")
```

## Related Repo Assets

This document is about the Python package itself. The repository also includes:

- `examples/samples/`
- `examples/output_smoke/`
- `examples/output/`
- `tools/`

The Java-based `.hwp -> .hwpx` conversion helpers live under `tools/` and are not part of the importable Python package.
