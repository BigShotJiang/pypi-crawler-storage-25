# jakal-hwpx

`jakal-hwpx`는 `HWPX` 문서를 읽고, 수정하고, 검증하고, 다시 저장하기 위한 Python 패키지입니다.

영문 문서: [README.md](./README.md)

## 저장소 구성

- `src/jakal_hwpx`: 실제 Python 패키지
- `examples/samples`: 샘플 `hwpx`, `hwp` 문서
- `examples/output_smoke`: 테스트용 smoke corpus
- `examples/output`: showcase 산출물
- `tools`: `.hwp -> .hwpx` 변환에 쓰는 유지보수용 Java 도구

## 설치

Python 3.11 이상이 필요합니다.

PyPI에서 설치:

```bash
python -m pip install --upgrade pip
python -m pip install jakal-hwpx
```

로컬 체크아웃에서 설치:

```bash
python -m pip install --upgrade pip
python -m pip install .
```

개발 모드 설치:

```bash
python -m pip install -e .[dev]
```

패키지 이름은 `jakal-hwpx`, import 경로는 `jakal_hwpx`입니다.

## 빠른 시작

```python
from jakal_hwpx import HwpxDocument

doc = HwpxDocument.blank()
doc.set_metadata(title="예제", creator="jakal-hwpx")
doc.set_paragraph_text(0, 0, "Hello HWPX")
doc.save("build/hello.hwpx")
```

모듈 구조와 주요 편집 API는 [HWPX_MODULE.md](./HWPX_MODULE.md)를 참고하세요.

## 테스트

```bash
python -m pip install -e .[dev]
python -m pytest -q
```

테스트는 기본적으로 아래 순서로 샘플을 찾습니다.

1. `JAKAL_HWPX_SAMPLE_DIR`
2. `all_hwpx_flat/`
3. `examples/output_smoke/`
4. `examples/output/`
5. `examples/samples/hwpx/`

## 추가 문서

- [HWPX_MODULE.md](./HWPX_MODULE.md): 패키지 구조와 API 설명
- [examples/SHOWCASE.md](./examples/SHOWCASE.md): showcase 생성 흐름
- [RELEASING.md](./RELEASING.md): 배포 체크리스트
- [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md): 샘플 문서와 번들 도구 관련 고지

## 라이선스

프로젝트가 직접 작성한 소스 코드는 [MIT License](./LICENSE)를 따릅니다.

샘플 문서, 커밋된 산출물, `tools/` 아래 번들 도구 자산은 별도 권리나 상위 라이선스를 따를 수 있습니다. 재배포 전에는 [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md)를 함께 확인하세요.
