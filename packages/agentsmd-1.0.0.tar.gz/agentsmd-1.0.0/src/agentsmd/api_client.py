"""Thin HTTP client for the AgentsMD backend API."""

import base64
import os
from pathlib import Path
from typing import Optional

import httpx


class APIClient:
    """HTTP client that talks to the AgentsMD backend.

    All sync intelligence lives on the server. This client just
    sends files and receives results.
    """

    def __init__(self, token: str, base_url: Optional[str] = None):
        self.base_url = base_url or os.environ.get(
            "AGENTSMD_API_URL", "https://api.agentsmd.com"
        )
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=60.0,
        )

    async def validate_token(self) -> dict:
        """Validate the API token against the backend."""
        resp = await self._client.post("/api/v1/auth/validate-token")
        resp.raise_for_status()
        return resp.json()

    async def sync(self, workspace_id: str, machine_id: str, workspace_path: str) -> dict:
        """Send all local files to the backend for sync.

        The backend handles hashing, diffing, vector clocks, and R2 storage.
        Returns sync results including files to download.
        """
        files = _collect_files(workspace_path)

        upload_files = []
        for name, content in files.items():
            upload_files.append(("files", (name, content, "application/octet-stream")))

        resp = await self._client.post(
            "/api/v1/sync",
            data={"workspace_id": workspace_id, "machine_id": machine_id},
            files=upload_files,
        )
        resp.raise_for_status()
        return resp.json()

    async def get_status(self, workspace_id: str) -> dict:
        """Get workspace sync status from the backend."""
        resp = await self._client.get(
            "/api/v1/sync/status",
            params={"workspace_id": workspace_id},
        )
        resp.raise_for_status()
        return resp.json()


def _load_gitignore_patterns(workspace: Path) -> set[str]:
    """Load patterns from .gitignore if it exists."""
    gitignore = workspace / ".gitignore"
    if not gitignore.exists():
        return set()

    patterns = set()
    for line in gitignore.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.add(line)
    return patterns


def _is_ignored(relative_path: str, gitignore_patterns: set[str]) -> bool:
    """Check if a relative path matches any .gitignore pattern."""
    for pattern in gitignore_patterns:
        if pattern.endswith("/"):
            # Directory pattern — match if path starts with it
            if relative_path.startswith(pattern) or relative_path.startswith(pattern.rstrip("/")):
                return True
        elif pattern.startswith("*"):
            # Glob pattern like *.log
            import fnmatch
            if fnmatch.fnmatch(relative_path, pattern) or fnmatch.fnmatch(Path(relative_path).name, pattern):
                return True
        else:
            # Exact match or prefix
            if relative_path == pattern or relative_path.startswith(pattern + "/"):
                return True
    return False


def _collect_files(workspace_path: str) -> dict[str, bytes]:
    """Read AgentsMD workspace files into a dict.

    Syncs only the files that agentsmd manages:
    - AGENTS.md, CLAUDE.md (and other agent config files)
    - memory/ directory
    - prompts/ directory
    - .agentsmd/ directory (including config.yml)

    Additionally respects .gitignore patterns.
    """
    workspace = Path(workspace_path)
    files = {}
    gitignore = _load_gitignore_patterns(workspace)

    # Root-level agent config files
    agent_files = ["AGENTS.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"]
    for name in agent_files:
        path = workspace / name
        if path.exists() and not _is_ignored(name, gitignore):
            files[name] = path.read_bytes()

    # Tool directories
    tool_dirs = [".cursor/rules", ".windsurf/rules", ".github/instructions"]
    for dir_path in tool_dirs:
        full_dir = workspace / dir_path
        if full_dir.is_dir():
            for file_path in full_dir.rglob("*"):
                if file_path.is_file():
                    try:
                        relative = str(file_path.relative_to(workspace))
                        if not _is_ignored(relative, gitignore):
                            files[relative] = file_path.read_bytes()
                    except (IOError, PermissionError):
                        pass

    # GitHub Copilot instructions file
    copilot_file = workspace / ".github" / "copilot-instructions.md"
    if copilot_file.exists():
        relative = ".github/copilot-instructions.md"
        if not _is_ignored(relative, gitignore):
            files[relative] = copilot_file.read_bytes()

    # .agentsmd/ directory
    agentsmd_dir = workspace / ".agentsmd"
    if agentsmd_dir.is_dir():
        for file_path in agentsmd_dir.rglob("*"):
            if file_path.is_file():
                try:
                    relative = str(file_path.relative_to(workspace))
                    if not _is_ignored(relative, gitignore):
                        files[relative] = file_path.read_bytes()
                except (IOError, PermissionError):
                    pass

    # memory/ directory
    memory_dir = workspace / "memory"
    if memory_dir.exists():
        for file_path in memory_dir.rglob("*"):
            if file_path.is_file():
                try:
                    relative = str(file_path.relative_to(workspace))
                    if not _is_ignored(relative, gitignore):
                        files[relative] = file_path.read_bytes()
                except (IOError, PermissionError):
                    pass

    # prompts/ directory
    prompts_dir = workspace / "prompts"
    if prompts_dir.exists():
        for file_path in prompts_dir.rglob("*"):
            if file_path.is_file():
                try:
                    relative = str(file_path.relative_to(workspace))
                    if not _is_ignored(relative, gitignore):
                        files[relative] = file_path.read_bytes()
                except (IOError, PermissionError):
                    pass

    return files


def write_downloaded_files(workspace_path: str, downloaded: list[dict]) -> int:
    """Write downloaded files from sync result to disk."""
    count = 0
    for item in downloaded:
        file_path = Path(workspace_path) / item["path"]
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(base64.b64decode(item["content"]))
        count += 1
    return count
