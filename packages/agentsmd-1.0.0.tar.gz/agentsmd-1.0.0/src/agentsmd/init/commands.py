"""Initialization command implementation."""

import sys
from pathlib import Path
from agentsmd.init.interview import run_interview
from agentsmd.init.generator import write_workspace_files


async def run() -> None:
    """Run workspace initialization."""
    print("AgentsMD Workspace Initialization")
    print("=" * 40)
    print()

    interview_data = await run_interview()

    print()
    print("Generating workspace files...")
    print()

    workspace_path = str(Path.cwd())
    write_workspace_files(interview_data, workspace_path)

    print()
    print("Workspace created successfully!")
    print()
    print("Next steps:")
    print("  1. Review generated files")
    print("  2. Customize as needed")
    print("  3. Provide your API token via AGENTSMD_API_TOKEN or run 'agentsmd login --token <TOKEN>'")
    print("  4. Run 'agentsmd sync' to synchronize across machines")
