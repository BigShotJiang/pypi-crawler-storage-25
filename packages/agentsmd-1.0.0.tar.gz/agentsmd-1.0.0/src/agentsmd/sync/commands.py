"""Synchronization command implementations — thin client."""

import hashlib
import sys
from pathlib import Path
from typing import Optional


async def _detect_workspace() -> Optional[str]:
    """Detect workspace root by finding AGENTS.md or CLAUDE.md."""
    current = Path.cwd()
    workspace_files = ["AGENTS.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"]

    for path in [current] + list(current.parents):
        if any((path / f).exists() for f in workspace_files):
            return str(path)
    return None


async def run(workspace_path: Optional[str] = None) -> None:
    """Run workspace synchronization via backend API."""
    from agentsmd.auth.commands import require_token
    from agentsmd.config import get_token
    from agentsmd.machine import ensure_machine_id
    from agentsmd.api_client import APIClient, write_downloaded_files

    token = require_token()

    workspace = workspace_path or await _detect_workspace()
    if not workspace:
        print("No workspace found. Run 'agentsmd init' first.")
        sys.exit(1)

    # Reconcile tool formats before cloud sync
    try:
        from agentsmd.converter.reconcile import reconcile
        reconcile_result = reconcile(Path(workspace))
        if reconcile_result.files_written:
            print(f"Reconciled {len(reconcile_result.files_written)} file(s)")
    except Exception:
        pass  # Reconciliation is best-effort, don't block sync

    # Derive workspace ID from directory name
    dir_name = Path(workspace).resolve().name
    workspace_id = hashlib.sha256(dir_name.encode()).hexdigest()[:16]
    machine_id = ensure_machine_id()

    client = APIClient(token=token)

    print("AgentsMD Sync")
    print("=" * 40)
    print()
    print(f"Workspace: {workspace}")
    print(f"Syncing with backend...")

    try:
        result = await client.sync(workspace_id, machine_id, workspace)
    except Exception as e:
        print(f"Sync failed: {e}")
        sys.exit(1)

    if not result.get("success"):
        print(f"Error: {result.get('error')}")
        sys.exit(1)

    uploaded = result.get("uploaded", 0)
    downloaded = result.get("downloaded", [])
    conflicts = result.get("conflicts", [])

    # Write downloaded files
    dl_count = write_downloaded_files(workspace, downloaded)

    print(f"Uploaded: {uploaded} files")
    print(f"Downloaded: {dl_count} files")

    if conflicts:
        print(f"Conflicts detected: {len(conflicts)}")
    else:
        print("No conflicts detected")

    print()
    print("Sync complete.")


async def run_status(workspace_path: Optional[str] = None) -> None:
    """Display workspace synchronization status via backend API."""
    from agentsmd.auth.commands import require_token
    from agentsmd.config import get_token
    from agentsmd.machine import get_machine_id
    from agentsmd.api_client import APIClient

    token = require_token()

    workspace = workspace_path or await _detect_workspace()
    if not workspace:
        print("No workspace found. Run 'agentsmd init' first.")
        sys.exit(1)

    dir_name = Path(workspace).resolve().name
    workspace_id = hashlib.sha256(dir_name.encode()).hexdigest()[:16]

    client = APIClient(token=token)

    try:
        result = await client.get_status(workspace_id)
    except Exception as e:
        print(f"Status check failed: {e}")
        sys.exit(1)

    print("AgentsMD Status")
    print("=" * 40)
    print()
    print(f"Workspace: {workspace}")
    print(f"Workspace ID: {result.get('workspace_id', workspace_id)}")
    print(f"Status: {result.get('status', 'unknown')}")
    print(f"Last sync: {result.get('last_sync', 'Never')}")
    print(f"File count: {result.get('files_count', 0)}")

    current_machine = get_machine_id()
    if current_machine:
        print(f"This machine: {current_machine}")
