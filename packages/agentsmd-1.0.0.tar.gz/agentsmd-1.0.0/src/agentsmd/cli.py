"""AgentsMD CLI - Command-line interface.

Orchestrates workspace initialization, synchronization, and authentication.
"""

import sys
import logging
import typer
from pathlib import Path
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

app = typer.Typer(
    name="agentsmd",
    help="AgentsMD - Intelligent workspace scaffolding and file synchronization",
    add_completion=False,
    no_args_is_help=True
)


@app.command(name="init")
def init_cmd():
    """Initialize a new workspace."""
    try:
        from agentsmd.init.commands import run as run_init
        import asyncio
        asyncio.run(run_init())
    except KeyboardInterrupt:
        print("\n\nInitialization cancelled.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Initialization failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="sync")
def sync_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Synchronize workspace to/from Cloudflare R2."""
    try:
        from agentsmd.sync.commands import run as run_sync
        import asyncio
        asyncio.run(run_sync(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception as e:
        logger.error(f"Sync failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="status")
def status_cmd(
    workspace_path: Optional[Path] = typer.Argument(
        None,
        help="Path to workspace directory"
    )
):
    """Show workspace synchronization status."""
    try:
        from agentsmd.sync.commands import run_status
        import asyncio
        asyncio.run(run_status(workspace_path=str(workspace_path) if workspace_path else None))
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="login")
def login_cmd(
    token: Optional[str] = typer.Option(
        None,
        "--token",
        "-t",
        help="API token to save globally"
    )
):
    """Authenticate via API token."""
    try:
        from agentsmd.auth.commands import run_login
        import asyncio
        asyncio.run(run_login(token))
    except Exception as e:
        logger.error(f"Login failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="logout")
def logout_cmd():
    """Clear local credentials."""
    try:
        from agentsmd.auth.commands import run_logout
        import asyncio
        asyncio.run(run_logout())
    except Exception as e:
        logger.error(f"Logout failed: {e}")
        raise typer.Exit(code=1)


@app.command(name="migrate")
def migrate_cmd(
    source: str = typer.Option(..., "--from", help="Source format (agents, claude, cursor, windsurf, copilot)"),
    target: Optional[str] = typer.Option(None, "--to", help="Target format (default: agents + re-derive all)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print output without writing files"),
):
    """Convert between AI tool config formats."""
    from agentsmd.converter.migrate import run_migrate
    result = run_migrate(Path.cwd(), source_format=source, target_format=target, dry_run=dry_run)

    if not result.success:
        print(f"Error: {result.error}")
        raise typer.Exit(code=1)

    if dry_run and result.output:
        print(result.output)
    else:
        for f in result.files_written:
            print(f"  Written: {f}")
        print(f"\nMigration complete. {len(result.files_written)} file(s) written.")


@app.command(name="reconcile")
def reconcile_cmd(
    source: Optional[str] = typer.Option(None, "--from", help="Force source format (default: auto-detect)"),
):
    """Re-derive all tool config formats from the source of truth."""
    from agentsmd.converter.reconcile import reconcile
    result = reconcile(Path.cwd(), source_format=source)

    if not result.success:
        print(f"Error: {result.error}")
        raise typer.Exit(code=1)

    if result.changed_files:
        print(f"Changed files: {result.changed_files}")
    if result.files_written:
        for f in result.files_written:
            print(f"  Written: {f}")
        print(f"\nReconcile complete. {len(result.files_written)} file(s) updated.")
    else:
        print("All formats are in sync. No changes needed.")


@app.command(name="tool-list")
def tool_list_cmd():
    """Show detected AI tools in this workspace."""
    from agentsmd.converter.detector import detect_tools
    from agentsmd.converter.registry import FORMATS

    workspace = Path.cwd()
    detected = detect_tools(workspace)

    if not detected:
        print("No AI tool config files detected.")
        print("Default: agents (AGENTS.md)")
        return

    print("Detected tools:")
    for fmt in detected:
        info = FORMATS.get(fmt, {})
        files = info.get("files", [])
        dirs = info.get("dirs", [])
        locations = files + dirs
        location_str = ", ".join(locations)

        count = ""
        for d in dirs:
            full_dir = workspace / d
            if full_dir.is_dir():
                rule_files = list(full_dir.glob("*"))
                if rule_files:
                    count = f" — {len(rule_files)} rule(s)"

        print(f"  ✓ {fmt:10s} ({location_str}{count})")

    print(f"\nDefault: agents (AGENTS.md)")


@app.command(name="tool-add")
def tool_add_cmd():
    """Register a custom AI tool interactively."""
    print("Add Custom Tool")
    print("=" * 40)
    print()

    name = input("Tool name: ").strip()
    if not name:
        print("Tool name is required.")
        raise typer.Exit(code=1)

    filename = input("Config filename: ").strip()
    if not filename:
        print("Filename is required.")
        raise typer.Exit(code=1)

    is_dir = input("Is directory-based? (y/n): ").strip().lower() == "y"

    print()
    print("Map markdown headings to canonical sections.")
    print("Press Enter to skip a mapping.")
    print()

    section_mappings = {}
    canonical_sections = ["overview", "rules", "constraints", "context", "workflow", "testing"]
    for section in canonical_sections:
        heading = input(f"  Which heading maps to '{section}'? ").strip()
        if heading:
            section_mappings[heading.lower()] = section

    config_path = Path.cwd() / ".agentsmd" / "config.yml"
    config_path.parent.mkdir(parents=True, exist_ok=True)

    import yaml

    config = {}
    if config_path.exists():
        try:
            config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        except Exception:
            config = {}

    custom_tools = config.get("tools", [])
    custom_tools.append({
        "name": name,
        "filename": filename,
        "is_directory": is_dir,
        "heading_mappings": section_mappings,
    })
    config["tools"] = custom_tools

    config_path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    print(f"\n✓ {name} registered in .agentsmd/config.yml")
    print("✓ Run 'agentsmd sync' to reconcile.")


@app.callback()
def main(ctx: typer.Context) -> None:
    """Main entry point."""
    if ctx.resilient_parsing:
        return

    import agentsmd
    typer.echo(f"AgentsMD v{agentsmd.__version__}")


if __name__ == "__main__":
    app()
