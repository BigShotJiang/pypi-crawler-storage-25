"""Tests for the v0 backtest engine."""

from datetime import timedelta

import polars as pl
import pytest

from hl_research.backtest.engine import BacktestData, BacktestEngine, run_backtest
from hl_research.backtest.fills import FillModel
from hl_research.backtest.metrics import compute_metrics
from hl_research.backtest.optimizer import ChoiceDistribution, grid_search, random_search
from hl_research.backtest.portfolio import ClosedTrade, EquityPoint, Portfolio
from hl_research.backtest.strategy import (
    BacktestContext,
    Candle,
    Fill,
    FundingTick,
    Order,
    Strategy,
)
from hl_research.backtest.walkforward import walk_forward

HOUR_MS = 60 * 60 * 1_000


class BuyThenSellStrategy(Strategy):
    """Toy strategy with hand-computed PnL."""

    def on_candle(self, candle: Candle, ctx: BacktestContext) -> list[Order]:
        if candle.open_time == 0:
            return [Order(asset="BTC", side="buy", size=1.0, kind="market")]
        if candle.open_time == 2 * HOUR_MS and ctx.position("BTC").size > 0:
            return [Order(asset="BTC", side="sell", size=1.0, kind="market")]
        return []


class ThresholdStrategy(Strategy):
    """Buys when the candle close is above a parameterized threshold."""

    def on_candle(self, candle: Candle, ctx: BacktestContext) -> list[Order]:
        threshold = float(ctx.params.get("threshold", 0.0))
        if candle.open_time == 0 and candle.close >= threshold:
            return [Order(asset="BTC", side="buy", size=1.0, kind="market")]
        if candle.open_time == HOUR_MS and ctx.position("BTC").size > 0:
            return [Order(asset="BTC", side="sell", size=1.0, kind="market")]
        return []


def test_engine_runs_hand_computed_toy_strategy() -> None:
    engine = BacktestEngine(initial_cash=100_000.0, fill_model=FillModel(0.0, 0.0, 0.0))
    result = engine.run(BuyThenSellStrategy(), _toy_data())

    assert [(fill.order.side, fill.fill_price, fill.fee) for fill in result.fills] == [
        ("buy", 110.0, 0.0),
        ("sell", 130.0, 0.0),
    ]
    assert result.portfolio.closed_trades[0].pnl == 20.0
    assert result.equity_curve[-1].equity == 100_020.0
    assert result.metrics.total_return == pytest.approx(0.0002)
    assert result.metrics.trade_count == 1
    assert result.metrics.hit_rate == 1.0
    assert result.metrics.average_hold_ms == 2 * HOUR_MS


def test_fill_model_documents_market_limit_and_stop_assumptions() -> None:
    model = FillModel(taker_fee_rate=0.01, maker_fee_rate=0.005, slippage_bps=10.0)
    candle = _candle(0, open_=100.0, high=110.0, low=90.0, close=105.0)

    market = model.simulate(Order("BTC", "buy", 2.0, "market"), candle)
    assert market is not None
    assert market.fill_price == 100.1
    assert market.fee == pytest.approx(2.002)

    limit = model.simulate(Order("BTC", "sell", 1.0, "limit", price=108.0), candle)
    assert limit is not None
    assert limit.fill_price == 108.0
    assert limit.fee == pytest.approx(0.54)

    missed = model.simulate(Order("BTC", "buy", 1.0, "limit", price=80.0), candle)
    assert missed is None

    stop = model.simulate(Order("BTC", "sell", 1.0, "stop", price=95.0), candle)
    assert stop is not None
    assert stop.fill_price == 99.9


def test_portfolio_reduce_flip_and_funding_accounting() -> None:
    portfolio = Portfolio(initial_cash=1_000.0)
    buy = Fill(Order("BTC", "buy", 1.0, "market"), fill_price=100.0, fill_time=0, fee=1.0)
    sell = Fill(Order("BTC", "sell", 2.0, "market"), fill_price=110.0, fill_time=HOUR_MS, fee=2.0)

    portfolio.apply_fill(buy)
    portfolio.apply_fill(sell)

    assert portfolio.closed_trades[0].pnl == 10.0
    assert portfolio.positions["BTC"].size == -1.0
    assert portfolio.positions["BTC"].average_price == 110.0
    assert portfolio.apply_funding("BTC", rate=0.01, mark_price=100.0) == 1.0
    assert portfolio.funding_earned == 1.0


def test_metrics_include_losses_and_drawdown() -> None:
    portfolio = Portfolio(initial_cash=100_000.0)
    trades = [ClosedTrade("BTC", 0, HOUR_MS, 1.0, -100.0)]
    curve = [
        EquityPoint(0, 100_000.0, 100_000.0),
        EquityPoint(HOUR_MS, 99_000.0, 99_000.0),
        EquityPoint(2 * HOUR_MS, 99_500.0, 99_500.0),
    ]
    metrics = compute_metrics(curve, trades, portfolio)

    assert metrics.max_drawdown == pytest.approx(-0.01)
    assert metrics.drawdown_duration_ms == HOUR_MS
    assert metrics.average_loss == -100.0


def test_grid_and_random_search() -> None:
    data = _toy_data()
    grid = grid_search(
        ThresholdStrategy,
        {"threshold": [50.0, 200.0]},
        data,
        metric="total_return",
        initial_cash=100_000.0,
    )
    assert grid.best.params == {"threshold": 50.0}
    assert len(grid.runs) == 2

    random_result = random_search(
        ThresholdStrategy,
        {"threshold": ChoiceDistribution([50.0])},
        n=2,
        data=data,
        metric="total_return",
        seed=1,
        initial_cash=100_000.0,
    )
    assert len(random_result.runs) == 2
    assert random_result.best.params == {"threshold": 50.0}


def test_optimizer_rejects_empty_grid() -> None:
    with pytest.raises(ValueError):
        grid_search(BuyThenSellStrategy, {"threshold": []}, _toy_data())


def test_walk_forward_runs_rolling_windows() -> None:
    result = walk_forward(
        BuyThenSellStrategy,
        {},
        _toy_data(),
        window=timedelta(hours=2),
        step=timedelta(hours=1),
        initial_cash=100_000.0,
    )
    assert len(result.windows) == 2
    assert result.windows[0].start_ms == 0
    assert result.windows[0].end_ms == 2 * HOUR_MS


def test_walk_forward_validates_window_and_handles_empty_data() -> None:
    empty = BacktestData(candles=pl.DataFrame())
    result = walk_forward(BuyThenSellStrategy, {}, empty, timedelta(hours=1), timedelta(hours=1))
    assert result.windows == []
    with pytest.raises(ValueError):
        walk_forward(BuyThenSellStrategy, {}, _toy_data(), timedelta(0), timedelta(hours=1))


def test_run_backtest_instantiates_strategy_class() -> None:
    result = run_backtest(
        BuyThenSellStrategy,
        _toy_data(),
        initial_cash=100_000.0,
    )
    assert result.metrics.trade_count == 1


def test_strategy_default_hooks_return_no_orders() -> None:
    strategy = Strategy()
    ctx = BacktestContext(cash=1.0, equity=1.0)
    candle = _candle(0, 1.0, 1.0, 1.0, 1.0)
    tick = FundingTick(asset="BTC", time=0, rate=0.0, premium=0.0)

    assert strategy.on_candle(candle, ctx) == []
    assert strategy.on_funding(tick, ctx) == []
    strategy.on_start(ctx)
    strategy.on_fill(Fill(Order("BTC", "buy", 1.0, "market"), 1.0, 0, 0.0), ctx)
    strategy.on_end(ctx)


def _toy_data(final_close: float = 130.0) -> BacktestData:
    return BacktestData(
        candles=pl.DataFrame(
            [
                _candle_row(0, 100.0, 100.0, 100.0, 100.0),
                _candle_row(HOUR_MS, 110.0, 115.0, 105.0, 112.0),
                _candle_row(2 * HOUR_MS, 120.0, 125.0, 115.0, 122.0),
                _candle_row(3 * HOUR_MS, 130.0, 135.0, 90.0, final_close),
            ]
        ),
        funding=pl.DataFrame(
            {
                "asset": ["BTC"],
                "time": [2 * HOUR_MS],
                "funding_rate": [0.0],
                "premium": [0.0],
            }
        ),
    )


def _candle_row(
    open_time: int,
    open_: float,
    high: float,
    low: float,
    close: float,
) -> dict[str, object]:
    return {
        "asset": "BTC",
        "interval": "1h",
        "open_time": open_time,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": 1.0,
    }


def _candle(open_time: int, open_: float, high: float, low: float, close: float) -> Candle:
    return Candle(
        asset="BTC",
        interval="1h",
        open_time=open_time,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=1.0,
    )
