"""Offline tests for the Hyperliquid info API client."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from hl_research.api.client import AsyncInfoHTTPClient, RetryConfig, TokenBucket
from hl_research.api.errors import HLHTTPError, HLNetworkError, HLRateLimitError, HLValidationError
from hl_research.api.info import InfoClient

FIXTURE_ROOT = Path(__file__).parent / "fixtures" / "hl"
USER = "0x0000000000000000000000000000000000000001"
VAULT = "0x0000000000000000000000000000000000000002"

FIXTURE_BY_TYPE = {
    "meta": "meta.json",
    "metaAndAssetCtxs": "meta_and_asset_ctxs.json",
    "clearinghouseState": "clearinghouse_state.json",
    "userFills": "fills.json",
    "userFillsByTime": "fills.json",
    "fundingHistory": "funding_history.json",
    "userFunding": "user_funding.json",
    "historicalOrders": "orders.json",
    "candleSnapshot": "candles.json",
    "recentTrades": "trades.json",
    "l2Book": "book.json",
    "vaultDetails": "vault_details.json",
    "vaultSummaries": "vault_summaries.json",
}


def load_fixture(name: str) -> object:
    """Load a recorded JSON fixture."""
    return json.loads((FIXTURE_ROOT / name).read_text())


def fixture_transport() -> httpx.MockTransport:
    """Return a transport that maps info request types to recorded fixtures."""

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content)
        fixture_name = FIXTURE_BY_TYPE[payload["type"]]
        return httpx.Response(200, json=load_fixture(fixture_name))

    return httpx.MockTransport(handler)


@pytest.mark.asyncio
async def test_info_client_parses_recorded_fixtures() -> None:
    client = InfoClient(transport=fixture_transport())
    try:
        meta = await client.meta()
        assert meta.universe[0].name == "BTC"

        meta_ctxs = await client.meta_and_asset_ctxs()
        assert meta_ctxs.contexts[0].mark_px == 65000.0

        state = await client.clearinghouse_state(USER)
        assert state.asset_positions[0].position.szi == 0.01

        fills = await client.user_fills(USER, aggregate_by_time=True)
        assert fills[0].hash == "0xfill"

        fills_by_time = await client.user_fills_by_time(USER, 1710000000000)
        assert fills_by_time[0].tid == 11

        funding = await client.funding_history("BTC", 1710000000000)
        assert funding[0].funding_rate == 0.0001

        payments = await client.user_funding(USER, 1710000000000)
        assert payments[0].delta.usdc == -0.2

        orders = await client.historical_orders(USER)
        assert orders[0].status == "filled"

        candles = await client.candle_snapshot("BTC", "1h", 1710000000000, 1710003600000)
        assert candles[0].close == 65000.0

        trades = await client.recent_trades("BTC")
        assert trades[0].side == "A"

        book = await client.l2_snapshot("BTC")
        assert book.levels[0][0].px == 64999.0

        vault = await client.vault_details(VAULT)
        assert vault.name == "Test Vault"

        summaries = await client.vault_summaries()
        assert summaries[0].tvl == 1000.0
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_info_client_raises_validation_error_with_raw_payload() -> None:
    transport = httpx.MockTransport(lambda _request: httpx.Response(200, json={"bad": "payload"}))
    client = InfoClient(transport=transport)
    try:
        with pytest.raises(HLValidationError) as exc_info:
            await client.meta()
        assert exc_info.value.raw_payload == {"bad": "payload"}
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_http_client_retries_transient_server_error() -> None:
    attempts = 0

    def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            return httpx.Response(500, json={"error": "temporary"})
        return httpx.Response(200, json={"ok": True})

    client = AsyncInfoHTTPClient(
        retry=RetryConfig(base_delay=0.0, jitter=0.0),
        transport=httpx.MockTransport(handler),
    )
    try:
        assert await client.post_info({"type": "meta"}) == {"ok": True}
        assert attempts == 2
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_http_client_does_not_retry_non_rate_limit_4xx() -> None:
    transport = httpx.MockTransport(lambda _request: httpx.Response(400))
    client = AsyncInfoHTTPClient(transport=transport)
    try:
        with pytest.raises(HLHTTPError) as exc_info:
            await client.post_info({"type": "meta"})
        assert exc_info.value.status_code == 400
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_http_client_raises_after_repeated_network_errors() -> None:
    async def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("offline")

    client = AsyncInfoHTTPClient(
        retry=RetryConfig(max_attempts=2, base_delay=0.0, jitter=0.0),
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(HLNetworkError):
            await client.post_info({"type": "meta"})
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_http_client_raises_rate_limit_after_retries() -> None:
    client = AsyncInfoHTTPClient(
        retry=RetryConfig(max_attempts=1, base_delay=0.0, jitter=0.0),
        transport=httpx.MockTransport(
            lambda _request: httpx.Response(429, headers={"Retry-After": "0"})
        ),
    )
    try:
        with pytest.raises(HLRateLimitError) as exc_info:
            await client.post_info({"type": "meta"})
        assert exc_info.value.retry_after == 0.0
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_token_bucket_validates_arguments() -> None:
    with pytest.raises(ValueError):
        TokenBucket(capacity=0, refill_per_second=1)
    bucket = TokenBucket(capacity=1, refill_per_second=1)
    with pytest.raises(ValueError):
        await bucket.acquire(0)
    with pytest.raises(ValueError):
        await bucket.acquire(2)
