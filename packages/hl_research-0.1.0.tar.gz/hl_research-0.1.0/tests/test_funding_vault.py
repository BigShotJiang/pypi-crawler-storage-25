"""Tests for funding and vault analytics."""

from pathlib import Path

import polars as pl
import pytest

from hl_research.analytics.funding_arb import perp_perp_basis, rank_basis
from hl_research.analytics.funding_predict import METHOD, predict_next_funding
from hl_research.analytics.vaults import (
    analyze_vault,
    asset_breakdown,
    inspect_trades,
    vault_metrics,
)
from hl_research.api.info import InfoClient
from hl_research.api.types import VaultDetails, VaultSummary, VaultTrade
from hl_research.cache.store import Cache
from hl_research.cache.sync import Syncer

DAY_MS = 24 * 60 * 60 * 1_000
VAULT = "0x0000000000000000000000000000000000000002"
LEADER = "0x0000000000000000000000000000000000000001"


def test_perp_perp_basis_math() -> None:
    btc = pl.DataFrame(
        {"time": [1, 2, 3], "asset": ["BTC"] * 3, "funding_rate": [0.01, 0.02, 0.03]}
    )
    eth = pl.DataFrame(
        {"time": [1, 2, 3], "asset": ["ETH"] * 3, "funding_rate": [0.00, 0.01, 0.01]}
    )

    result = perp_perp_basis(btc.lazy(), eth.lazy(), "BTC", "ETH")

    assert result.observations == 3
    assert result.mean_basis == pytest.approx(0.0133333333)
    assert result.latest_basis == pytest.approx(0.02)
    assert result.latest_annualized_basis == pytest.approx(21.9)
    assert result.series.to_dicts()[-1]["reference_asset"] == "ETH"


def test_rank_basis_orders_by_absolute_latest_basis() -> None:
    base = pl.DataFrame({"time": [1], "funding_rate": [0.03]})
    low = pl.DataFrame({"time": [1], "funding_rate": [0.02]})
    high = pl.DataFrame({"time": [1], "funding_rate": [-0.01]})

    ranked = rank_basis({"BTC": base, "ETH": low, "SOL": high}, "BTC")

    assert [item.reference_asset for item in ranked] == ["SOL", "ETH"]


def test_predict_next_funding_ewma_baseline() -> None:
    funding = pl.DataFrame(
        {
            "time": [1, 2, 3],
            "asset": ["BTC", "BTC", "BTC"],
            "funding_rate": [0.01, 0.03, 0.02],
            "premium": [0.0, 0.0, 0.0],
        }
    )

    prediction = predict_next_funding(funding.lazy(), "BTC", span=3)

    assert prediction.method == METHOD
    assert prediction.predicted_rate == pytest.approx(0.02)
    assert prediction.observations == 3
    assert prediction.lower_bound < prediction.predicted_rate < prediction.upper_bound


def test_predict_next_funding_handles_empty_and_bad_span() -> None:
    empty = predict_next_funding(pl.DataFrame(), "BTC")
    assert empty.predicted_rate == 0.0
    assert empty.observations == 0
    with pytest.raises(ValueError):
        predict_next_funding(pl.DataFrame({"funding_rate": [0.01]}), "BTC", span=0)


def test_vault_analysis_metrics_and_trade_inspection() -> None:
    equity = _equity_curve()
    trades = _vault_trades()
    followers = pl.DataFrame({"user": ["a", "b", "a"], "vault_equity": [10.0, 20.0, 11.0]})

    analysis = analyze_vault(
        VAULT,
        equity.lazy(),
        trades.lazy(),
        followers.lazy(),
        name="Test Vault",
        leader=LEADER,
    )

    assert analysis.vault == VAULT
    assert analysis.name == "Test Vault"
    assert analysis.leader == LEADER
    assert analysis.tvl == 150.0
    assert analysis.depositor_count == 2
    assert analysis.metrics.total_return == pytest.approx(0.5)
    assert analysis.metrics.max_drawdown == pytest.approx(-0.25)
    assert analysis.asset_breakdown.to_dicts()[0]["asset"] == "BTC"
    assert inspect_trades(trades, asset="ETH", limit=1).height == 1


def test_vault_metrics_empty_and_asset_breakdown_empty() -> None:
    metrics = vault_metrics(pl.DataFrame())
    assert metrics.total_return == 0.0
    assert asset_breakdown(pl.DataFrame()).is_empty()


@pytest.mark.asyncio
async def test_vault_sync_path_caches_summaries_details_and_trades(tmp_path: Path) -> None:
    cache = Cache(tmp_path)
    syncer = Syncer(FakeVaultClient(), cache)

    summaries = await syncer.pull_vault_summaries()
    details = await syncer.pull_vault_details(VAULT)
    trade_result = syncer.cache_vault_trades(VAULT, [_vault_trade()])

    vaults = cache.read_vault_summaries()
    assert summaries.rows_written == 1
    assert details.rows_written == 1
    assert trade_result.rows_written == 1
    assert vaults["address"].item() == VAULT
    assert vaults["tvl"].item() == 1_000.0
    assert cache.read_vault_trades(VAULT).collect()["hash"].item() == "0xtrade"


class FakeVaultClient(InfoClient):
    """Offline vault client for sync tests."""

    def __init__(self) -> None:
        pass

    async def vault_summaries(self) -> list[VaultSummary]:
        return [
            VaultSummary.model_validate(
                {
                    "name": "Test Vault",
                    "vaultAddress": VAULT,
                    "leader": LEADER,
                    "tvl": "1000.0",
                    "apr": "0.12",
                    "isClosed": False,
                }
            )
        ]

    async def vault_details(self, vault: str) -> VaultDetails:
        assert vault == VAULT
        return VaultDetails.model_validate(
            {
                "name": "Test Vault",
                "vaultAddress": VAULT,
                "leader": LEADER,
                "description": "fixture",
                "portfolio": [],
                "followers": [],
                "isClosed": False,
            }
        )


def _equity_curve() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "time": [0, DAY_MS, 2 * DAY_MS, 3 * DAY_MS],
            "equity": [100.0, 120.0, 90.0, 150.0],
        }
    )


def _vault_trades() -> pl.DataFrame:
    return pl.DataFrame(
        [
            {
                "vault": VAULT,
                "asset": "BTC",
                "time": 1,
                "side": "B",
                "price": 100.0,
                "size": 2.0,
                "closed_pnl": 10.0,
            },
            {
                "vault": VAULT,
                "asset": "ETH",
                "time": 2,
                "side": "A",
                "price": 50.0,
                "size": 1.0,
                "closed_pnl": -5.0,
            },
        ]
    )


def _vault_trade() -> VaultTrade:
    return VaultTrade.model_validate(
        {
            "coin": "BTC",
            "px": "100.0",
            "sz": "1.0",
            "side": "B",
            "time": 1,
            "startPosition": "0.0",
            "dir": "Open Long",
            "closedPnl": "0.0",
            "hash": "0xtrade",
            "oid": 1,
            "crossed": True,
            "fee": "0.1",
            "tid": 1,
            "feeToken": "USDC",
        }
    )
