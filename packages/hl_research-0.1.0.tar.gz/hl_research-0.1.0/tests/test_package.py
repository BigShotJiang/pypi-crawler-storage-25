"""Package-level smoke tests."""

from hl_research import __version__


def test_version_is_defined() -> None:
    assert __version__ == "0.1.0"
