"""Tests for wallet analytics primitives."""

from __future__ import annotations

from dataclasses import asdict

import polars as pl

from hl_research.analytics.behavior import classify_behavior
from hl_research.analytics.counterfactual import SPOT_PROXY_ASSUMPTION, build_counterfactual
from hl_research.analytics.types import RoundTripTrade
from hl_research.analytics.wrapped import build_wrapped, reconstruct_round_trip_trades

HOUR_MS = 60 * 60 * 1_000
DAY_MS = 24 * HOUR_MS
WALLET = "0x0000000000000000000000000000000000000001"


def test_reconstruct_round_trip_trades_walks_position_to_zero() -> None:
    trades = reconstruct_round_trip_trades(_fixture_fills())

    assert [(trade.asset, trade.side, trade.size, trade.realized_pnl) for trade in trades] == [
        ("BTC", "long", 1.5, 100.0),
        ("BTC", "short", 0.5, -50.0),
    ]
    assert trades[0].entry_price == 101.0
    assert trades[0].exit_price == 120.0
    assert round(trades[0].fees, 2) == 0.35


def test_counterfactual_uses_perp_candle_close_as_spot_proxy() -> None:
    trades = [_trade("BTC", 0, HOUR_MS, 100.0, size=2.0, entry_price=100.0)]
    result = build_counterfactual(trades, {"BTC": _fixture_candles().lazy()})

    assert result.assumption == SPOT_PROXY_ASSUMPTION
    assert result.actual_pnl == 100.0
    assert result.hold_spot_pnl == 20_000.0
    assert result.alpha_vs_hold == -19_900.0


def test_wrapped_report_snapshot() -> None:
    report = build_wrapped(
        fills=_fixture_fills().lazy(),
        funding=_fixture_funding().lazy(),
        candles={"BTC": _fixture_candles().lazy()},
        wallet=WALLET,
    )

    snapshot = {
        "wallet": report.wallet,
        "period": [dt.isoformat() for dt in report.period],
        "total_realized_pnl": report.total_realized_pnl,
        "funding_paid": report.funding_paid,
        "funding_earned": report.funding_earned,
        "win_rate": report.win_rate,
        "trade_count": report.trade_count,
        "behavior_cluster": report.behavior_cluster,
        "counterfactual": {
            "actual_pnl": report.counterfactual.actual_pnl,
            "hold_spot_pnl": report.counterfactual.hold_spot_pnl,
            "alpha_vs_hold": report.counterfactual.alpha_vs_hold,
        },
        "pnl_by_asset": report.pnl_by_asset.to_dicts(),
        "top_wins": [asdict(row) | {"time": row.time.isoformat()} for row in report.top_wins],
        "top_losses": [asdict(row) | {"time": row.time.isoformat()} for row in report.top_losses],
    }

    assert snapshot == {
        "wallet": WALLET,
        "period": ["2024-03-09T16:00:00+00:00", "2024-03-10T00:00:00+00:00"],
        "total_realized_pnl": 50.0,
        "funding_paid": 5.0,
        "funding_earned": 10.0,
        "win_rate": 0.5,
        "trade_count": 2,
        "behavior_cluster": "balanced",
        "counterfactual": {
            "actual_pnl": 50.0,
            "hold_spot_pnl": 19993.5,
            "alpha_vs_hold": -19943.5,
        },
        "pnl_by_asset": [{"asset": "BTC", "realized_pnl": 50.0, "trade_count": 2}],
        "top_wins": [
            {
                "asset": "BTC",
                "time": "2024-03-09T18:00:00+00:00",
                "side": "long",
                "price": 120.0,
                "size": 1.5,
                "pnl": 100.0,
            }
        ],
        "top_losses": [
            {
                "asset": "BTC",
                "time": "2024-03-09T20:00:00+00:00",
                "side": "short",
                "price": 130.0,
                "size": 0.5,
                "pnl": -50.0,
            }
        ],
    }


def test_behavior_revenge_trader() -> None:
    trades = [
        _trade("BTC", 0, HOUR_MS, -10.0),
        _trade("BTC", HOUR_MS + 1_000, 2 * HOUR_MS, 20.0),
        _trade("ETH", 3 * HOUR_MS, 4 * HOUR_MS, -5.0),
        _trade("ETH", 4 * HOUR_MS + 1_000, 5 * HOUR_MS, 10.0),
    ]
    assert classify_behavior(trades).label == "revenge_trader"


def test_behavior_funding_farmer() -> None:
    funding = pl.DataFrame({"usdc": [100.0, 25.0]})
    assert classify_behavior([], funding).label == "funding_farmer"


def test_behavior_leverage_addict() -> None:
    trades = [
        _trade("BTC", 0, HOUR_MS, -100.0, size=2.0, entry_price=100_000.0),
        _trade("ETH", 2 * HOUR_MS, 3 * HOUR_MS, 10.0, size=1.0, entry_price=120_000.0),
    ]
    assert classify_behavior(trades).label == "leverage_addict"


def test_behavior_scalper() -> None:
    trades = [
        _trade("BTC", index * HOUR_MS, index * HOUR_MS + 30 * 60 * 1_000, 1.0) for index in range(5)
    ]
    assert classify_behavior(trades).label == "scalper"


def test_behavior_hold_and_pray() -> None:
    trades = [
        _trade("BTC", 0, 8 * DAY_MS, -10.0),
        _trade("ETH", 9 * DAY_MS, 17 * DAY_MS, 10.0),
    ]
    assert classify_behavior(trades).label == "hold_and_pray"


def test_behavior_swing_trader() -> None:
    trades = [
        _trade("BTC", 0, 2 * DAY_MS, 10.0),
        _trade("ETH", 3 * DAY_MS, 5 * DAY_MS, 20.0),
    ]
    assert classify_behavior(trades).label == "swing_trader"


def test_behavior_chad() -> None:
    trades = [
        _trade("BTC", 0, 2 * HOUR_MS, 700.0),
        _trade("ETH", 3 * HOUR_MS, 5 * HOUR_MS, 500.0),
        _trade("SOL", 6 * HOUR_MS, 8 * HOUR_MS, -100.0),
    ]
    assert classify_behavior(trades).label == "chad"


def test_behavior_balanced() -> None:
    trades = [
        _trade("BTC", 0, 2 * HOUR_MS, 10.0),
        _trade("ETH", 3 * HOUR_MS, 5 * HOUR_MS, -5.0),
    ]
    assert classify_behavior(trades).label == "balanced"


def _trade(
    asset: str,
    entry_time: int,
    exit_time: int,
    pnl: float,
    size: float = 1.0,
    entry_price: float = 100.0,
) -> RoundTripTrade:
    return RoundTripTrade(
        asset=asset,
        side="long",
        entry_time=entry_time,
        exit_time=exit_time,
        entry_price=entry_price,
        exit_price=entry_price + pnl / size,
        size=size,
        realized_pnl=pnl,
        fees=0.0,
        fill_count=2,
    )


def _fixture_fills() -> pl.DataFrame:
    return pl.DataFrame(
        [
            _fill_row(HOUR_MS * 0, "B", 1.0, 100.0, 0.0, 0.10),
            _fill_row(HOUR_MS * 1, "B", 0.5, 103.0, 0.0, 0.05),
            _fill_row(HOUR_MS * 2, "A", 1.5, 120.0, 100.0, 0.20),
            _fill_row(HOUR_MS * 3, "A", 0.5, 110.0, 0.0, 0.05),
            _fill_row(HOUR_MS * 4, "B", 0.5, 130.0, -50.0, 0.05),
        ]
    )


def _fill_row(
    time: int,
    side: str,
    size: float,
    price: float,
    closed_pnl: float,
    fee: float,
) -> dict[str, object]:
    return {
        "wallet": WALLET,
        "asset": "BTC",
        "time": 1_710_000_000_000 + time,
        "side": side,
        "price": price,
        "size": size,
        "start_position": 0.0,
        "direction": "fixture",
        "closed_pnl": closed_pnl,
        "hash": f"0x{time}",
        "oid": time,
        "tid": time,
        "crossed": True,
        "fee": fee,
        "fee_token": "USDC",
        "liquidation": False,
    }


def _fixture_funding() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "asset": ["BTC", "BTC"],
            "time": [1_710_000_000_000 + 2 * HOUR_MS, 1_710_000_000_000 + 8 * HOUR_MS],
            "usdc": [10.0, -5.0],
        }
    )


def _fixture_candles() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "asset": ["BTC", "BTC"],
            "interval": ["1h", "1h"],
            "open_time": [1_710_000_000_000, 1_710_000_000_000 + 8 * HOUR_MS],
            "close_time": [1_710_003_599_999, 1_710_032_399_999],
            "open": [100.0, 120.0],
            "high": [130.0, 140.0],
            "low": [90.0, 110.0],
            "close": [110.0, 10_100.0],
            "volume": [1.0, 1.0],
            "trade_count": [1, 1],
        }
    )
