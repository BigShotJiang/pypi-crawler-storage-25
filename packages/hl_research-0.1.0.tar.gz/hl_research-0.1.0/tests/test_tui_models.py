"""Offline tests for TUI reactive screen models."""

from pathlib import Path

import pytest

from hl_research.api.types import Candle, Fill, FundingRate, UniverseAsset, VaultSummary, VaultTrade
from hl_research.backtest.strategy import BacktestContext, Order, Strategy
from hl_research.backtest.strategy import Candle as BacktestCandle
from hl_research.cache.store import Cache
from hl_research.tui.screens.backtest import BacktestScreenModel
from hl_research.tui.screens.funding import FundingScreenModel
from hl_research.tui.screens.home import HomeScreenModel
from hl_research.tui.screens.settings import SettingsScreenModel
from hl_research.tui.screens.vault import VaultScreenModel
from hl_research.tui.screens.wallet import WalletScreenModel

WALLET = "0x0000000000000000000000000000000000000001"
VAULT = "0x0000000000000000000000000000000000000002"
HOUR_MS = 60 * 60 * 1_000


class BuyFirstCandleStrategy(Strategy):
    """Tiny strategy used by the backtest screen model test."""

    def on_candle(self, candle: BacktestCandle, ctx: BacktestContext) -> list[Order]:
        if candle.open_time == 0:
            return [Order(asset="BTC", side="buy", size=1.0, kind="market")]
        return []


@pytest.mark.asyncio
async def test_home_model_loads_cache_summary(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = HomeScreenModel(cache)

    await model.load()

    assert model.error is None
    assert model.loading is False
    assert model.summary is not None
    assert model.summary.dataset_count >= 4
    assert model.summary.asset_count == 1
    assert model.summary.vault_count == 1
    assert model.assets["name"].item() == "BTC"


@pytest.mark.asyncio
async def test_wallet_model_loads_fills_and_wrapped_report(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = WalletScreenModel(cache)

    await model.load(WALLET)

    assert model.error is None
    assert model.address == WALLET
    assert model.summary is not None
    assert model.summary.fill_count == 2
    assert model.summary.realized_pnl == 25.0
    assert model.wrapped is not None
    assert model.wrapped.trade_count == 1


@pytest.mark.asyncio
async def test_funding_model_loads_prediction_basis_and_heatmap(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = FundingScreenModel(cache)

    await model.load("BTC", "ETH")

    assert model.error is None
    assert model.history.height == 2
    assert model.prediction is not None
    assert model.prediction.asset == "BTC"
    assert model.basis is not None
    assert model.basis.reference_asset == "ETH"
    assert model.heatmap.height == 4


@pytest.mark.asyncio
async def test_vault_model_loads_summary_and_analysis(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = VaultScreenModel(cache)

    await model.load(VAULT)

    assert model.error is None
    assert model.vault == VAULT
    assert model.summaries.height == 1
    assert model.trades.height == 1
    assert model.analysis is not None
    assert model.analysis.vault == VAULT
    assert model.analysis.depositor_count == 0


@pytest.mark.asyncio
async def test_backtest_model_loads_data_and_runs_strategy(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = BacktestScreenModel(cache)

    await model.load_data("BTC")
    await model.run(BuyFirstCandleStrategy)

    assert model.error is None
    assert model.candles.height == 2
    assert model.funding.height == 2
    assert model.result is not None
    assert len(model.result.orders) == 1


@pytest.mark.asyncio
async def test_settings_model_loads_cache_state(tmp_path: Path) -> None:
    cache = _seed_cache(tmp_path)
    model = SettingsScreenModel(cache)

    await model.load()

    assert model.error is None
    assert model.state is not None
    assert model.state.cache_dir == str(tmp_path)
    assert model.state.dataset_count >= 4
    assert len(model.cache_entries) >= 4


def _seed_cache(root: Path) -> Cache:
    cache = Cache(root)
    cache.write_assets(
        [UniverseAsset.model_validate({"name": "BTC", "szDecimals": 5, "maxLeverage": 50})]
    )
    cache.write_candles("BTC", "1h", _candles())
    cache.write_funding("BTC", _funding("BTC", [0.01, 0.02]))
    cache.write_funding("ETH", _funding("ETH", [0.005, 0.01]))
    cache.write_fills(WALLET, _fills())
    cache.write_vault_summaries(
        [
            VaultSummary.model_validate(
                {
                    "name": "Test Vault",
                    "vaultAddress": VAULT,
                    "leader": WALLET,
                    "tvl": "1000.0",
                    "apr": "0.10",
                    "isClosed": False,
                }
            )
        ]
    )
    cache.write_vault_trades(VAULT, [_vault_trade()])
    return cache


def _candles() -> list[Candle]:
    return [
        Candle.model_validate(
            {
                "t": 0,
                "T": HOUR_MS - 1,
                "s": "BTC",
                "i": "1h",
                "o": "100.0",
                "c": "110.0",
                "h": "115.0",
                "l": "95.0",
                "v": "1.0",
                "n": 1,
            }
        ),
        Candle.model_validate(
            {
                "t": HOUR_MS,
                "T": 2 * HOUR_MS - 1,
                "s": "BTC",
                "i": "1h",
                "o": "120.0",
                "c": "130.0",
                "h": "135.0",
                "l": "115.0",
                "v": "1.0",
                "n": 1,
            }
        ),
    ]


def _funding(asset: str, rates: list[float]) -> list[FundingRate]:
    return [
        FundingRate.model_validate(
            {"coin": asset, "fundingRate": str(rate), "premium": "0.0", "time": index * HOUR_MS}
        )
        for index, rate in enumerate(rates)
    ]


def _fills() -> list[Fill]:
    return [
        Fill.model_validate(
            {
                "coin": "BTC",
                "px": "100.0",
                "sz": "1.0",
                "side": "B",
                "time": 0,
                "startPosition": "0.0",
                "dir": "Open Long",
                "closedPnl": "0.0",
                "hash": "0xopen",
                "oid": 1,
                "crossed": True,
                "fee": "0.1",
                "tid": 1,
                "feeToken": "USDC",
            }
        ),
        Fill.model_validate(
            {
                "coin": "BTC",
                "px": "125.0",
                "sz": "1.0",
                "side": "A",
                "time": HOUR_MS,
                "startPosition": "1.0",
                "dir": "Close Long",
                "closedPnl": "25.0",
                "hash": "0xclose",
                "oid": 2,
                "crossed": True,
                "fee": "0.1",
                "tid": 2,
                "feeToken": "USDC",
            }
        ),
    ]


def _vault_trade() -> VaultTrade:
    return VaultTrade.model_validate(
        {
            "coin": "BTC",
            "px": "100.0",
            "sz": "1.0",
            "side": "B",
            "time": 0,
            "startPosition": "0.0",
            "dir": "Open Long",
            "closedPnl": "10.0",
            "hash": "0xvault",
            "oid": 1,
            "crossed": True,
            "fee": "0.1",
            "tid": 1,
            "feeToken": "USDC",
        }
    )
