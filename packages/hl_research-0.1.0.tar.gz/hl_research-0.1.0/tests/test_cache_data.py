"""Tests for cache round trips and LazyFrame data views."""

from datetime import UTC, datetime
from pathlib import Path

import polars as pl
from pytest import MonkeyPatch

from hl_research.api.types import Candle, Fill, FundingRate, UniverseAsset, VaultTrade
from hl_research.cache.paths import default_cache_dir
from hl_research.cache.store import Cache
from hl_research.cache.sync import detect_gaps
from hl_research.data.candles import candles
from hl_research.data.fills import fills
from hl_research.data.funding import funding
from hl_research.data.universe import universe
from hl_research.data.vaults import vault_trades

WALLET = "0x0000000000000000000000000000000000000001"
VAULT = "0x0000000000000000000000000000000000000002"


def test_default_cache_dir_honors_hlr_cache_dir(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HLR_CACHE_DIR", str(tmp_path / "cache"))
    assert default_cache_dir() == tmp_path / "cache"


def test_default_cache_dir_honors_xdg_cache_home(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("HLR_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    assert default_cache_dir() == tmp_path / "hl-research"


def test_default_cache_dir_falls_back_to_home(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("HLR_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    assert default_cache_dir() == tmp_path / ".cache" / "hl-research"


def test_cache_round_trip_and_data_views(tmp_path: Path) -> None:
    cache = Cache(tmp_path)
    candle_rows = [
        Candle.model_validate(
            {
                "t": 1710000000000,
                "T": 1710003599999,
                "s": "BTC",
                "i": "1h",
                "o": "64000.0",
                "c": "65000.0",
                "h": "65100.0",
                "l": "63900.0",
                "v": "12.3",
                "n": 42,
            }
        )
    ]
    funding_rows = [
        FundingRate.model_validate(
            {
                "coin": "BTC",
                "fundingRate": "0.0001",
                "premium": "0.0002",
                "time": 1710000000000,
            }
        )
    ]
    fill_rows = [
        Fill.model_validate(
            {
                "coin": "BTC",
                "px": "65000.0",
                "sz": "0.01",
                "side": "B",
                "time": 1710000000000,
                "startPosition": "0.0",
                "dir": "Open Long",
                "closedPnl": "0.0",
                "hash": "0xfill",
                "oid": 1,
                "crossed": True,
                "fee": "0.1",
                "tid": 11,
                "feeToken": "USDC",
            }
        )
    ]
    vault_rows = [VaultTrade.model_validate(fill_rows[0].model_dump(by_alias=True))]
    asset_rows = [
        UniverseAsset.model_validate(
            {"name": "BTC", "szDecimals": 5, "maxLeverage": 50, "onlyIsolated": False}
        )
    ]

    cache.write_assets(asset_rows)
    cache.write_candles("BTC", "1h", candle_rows)
    cache.write_funding("BTC", funding_rows)
    cache.write_fills(WALLET, fill_rows)
    cache.write_vault_trades(VAULT, vault_rows)

    assert cache.sync_state("candles", "BTC", "1h") is not None
    assert len(cache.list()) == 4

    assert cache.read_candles("BTC", "1h").collect()["close"].item() == 65000.0
    assert cache.read_funding("BTC").collect()["funding_rate"].item() == 0.0001
    assert cache.read_fills(WALLET).collect()["hash"].item() == "0xfill"
    assert cache.read_vault_trades(VAULT).collect()["vault"].item() == VAULT
    assert cache.read_assets()["name"].item() == "BTC"

    since = datetime.fromtimestamp(1709999999, tz=UTC)
    until = datetime.fromtimestamp(1710000001, tz=UTC)
    assert candles("BTC", "1h", since, until, cache).collect().height == 1
    assert funding("BTC", since, until, cache).collect().height == 1
    assert fills(WALLET, "BTC", since, until, cache).collect().height == 1
    assert vault_trades(VAULT, since, until, cache).collect().height == 1
    assert universe(cache).height == 1

    missing = cache.read_candles("ETH", "1h").collect()
    assert missing.equals(pl.DataFrame(schema=missing.schema))

    assert cache.clear(kind="fills", entity=WALLET) == 1
    assert cache.read_fills(WALLET).collect().is_empty()


def test_detect_gaps() -> None:
    gaps = detect_gaps([0, 1_000, 3_000], 1_000)
    assert len(gaps) == 1
    assert gaps[0].start_ms == 2_000
    assert gaps[0].end_ms == 2_000
