"""Offline CLI snapshot tests for help text and JSON output shapes."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Self, cast

from pytest import MonkeyPatch
from typer.testing import CliRunner

from hl_research.api.types import (
    Candle,
    ClearinghouseState,
    Fill,
    FundingPayment,
    FundingRate,
    VaultDetails,
    VaultSummary,
    VaultTrade,
)
from hl_research.cache.store import Cache
from hl_research.cli.main import app

WALLET = "0x0000000000000000000000000000000000000001"
VAULT = "0x0000000000000000000000000000000000000002"
LEADER = "0x0000000000000000000000000000000000000003"
HOUR_MS = 60 * 60 * 1_000
DAY_MS = 24 * HOUR_MS
T0 = 1_704_067_200_000

runner = CliRunner()
type JsonObject = dict[str, object]


def test_cli_help_snapshots() -> None:
    """Command groups expose stable help surfaces without touching live HL."""
    cases = [
        (["--help"], "Quantitative research toolkit for Hyperliquid."),
        (["data", "--help"], "Pull, inspect, and manage the local Hyperliquid data cache."),
        (["wallet", "--help"], "Inspect wallets, build wrapped reports, list fills and funding."),
        (["funding", "--help"], "Funding-rate history, cross-asset heatmap"),
        (["vault", "--help"], "List, rank, and inspect Hyperliquid vaults."),
        (["backtest", "--help"], "Run, optimize, and walk-forward backtest a strategy file."),
    ]

    for args, expected in cases:
        result = runner.invoke(app, args)
        assert result.exit_code == 0
        assert expected in result.output


def test_data_json_output_shapes(tmp_path: Path) -> None:
    """Data commands emit predictable JSON from an offline cache."""
    _seed_cache(tmp_path)

    listing = _json_list(["--cache-dir", str(tmp_path), "--json", "data", "ls"])
    assert {row["kind"] for row in listing} >= {"candles", "funding", "fills", "vault"}
    assert listing[0].keys() >= {"kind", "entity", "row_count", "updated_at"}

    info = _json_dict(["--cache-dir", str(tmp_path), "--json", "data", "info"])
    assert info["cache_dir"] == str(tmp_path)
    assert isinstance(info["dataset_count"], int)
    assert info["dataset_count"] >= 4
    assert isinstance(info["file_count"], int)
    assert info["file_count"] >= 4

    cleared = _json_dict(
        ["--cache-dir", str(tmp_path), "--json", "data", "clear", "--kind", "fills", "--yes"]
    )
    assert cleared == {"removed_datasets": 1, "scope": "kind=fills"}


def test_data_pull_json_output_shapes(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    """Data pull commands can sync from a fake client and report JSON sync results."""
    monkeypatch.setattr("hl_research.cli.data.InfoClient", FakeInfoClient)

    candles = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "data",
            "pull",
            "BTC",
            "--since",
            "2024-01-01",
            "--until",
            "2024-01-02",
        ]
    )
    assert candles["kind"] == "candles"
    assert isinstance(candles["rows_written"], int)
    assert candles["rows_written"] > 0

    funding = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "data",
            "pull-funding",
            "BTC",
            "--since",
            "2024-01-01",
            "--until",
            "2024-01-02",
        ]
    )
    assert funding["kind"] == "funding"
    assert funding["entity"] == "BTC"

    fills = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "data",
            "pull-fills",
            WALLET,
            "--since",
            "2024-01-01",
            "--until",
            "2024-01-02",
        ]
    )
    assert fills["kind"] == "fills"
    assert isinstance(fills["rows_written"], int)
    assert fills["rows_written"] > 0


def test_funding_json_output_shapes(tmp_path: Path) -> None:
    """Funding commands read cached data and emit JSON with analytics fields."""
    _seed_cache(tmp_path)

    history = _json_dict(["--cache-dir", str(tmp_path), "--json", "funding", "history", "BTC"])
    assert history["asset"] == "BTC"
    assert isinstance(history["observations"], int)
    assert history["observations"] >= 3
    rates = cast(list[JsonObject], history["rates"])
    assert rates[0].keys() >= {"time", "funding_rate", "premium"}

    heatmap = _json_list(["--cache-dir", str(tmp_path), "--json", "funding", "heatmap"])
    assert {row["asset"] for row in heatmap} >= {"BTC", "ETH"}
    assert heatmap[0].keys() >= {"funding_rate", "annualized"}

    arb = _json_list(["--cache-dir", str(tmp_path), "--json", "funding", "arb", "BTC"])
    assert arb[0].keys() >= {"base", "reference", "latest_basis", "observations"}

    prediction = _json_dict(["--cache-dir", str(tmp_path), "--json", "funding", "predict", "BTC"])
    assert prediction["asset"] == "BTC"
    assert prediction["method"] == "naive_ewma_baseline"


def test_wallet_json_output_shapes(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    """Wallet commands can be snapshot-tested offline with a fake info client."""
    _seed_cache(tmp_path)
    monkeypatch.setattr("hl_research.cli.wallet.InfoClient", FakeInfoClient)

    inspect_payload = _json_dict(
        ["--cache-dir", str(tmp_path), "--json", "wallet", "inspect", WALLET]
    )
    assert inspect_payload["time"] == T0
    assert inspect_payload["withdrawable"] == 9500.0

    fills = _json_list(["--cache-dir", str(tmp_path), "--json", "wallet", "fills", WALLET])
    assert fills[0].keys() >= {"coin", "px", "sz", "side", "time"}

    funding = _json_list(["--cache-dir", str(tmp_path), "--json", "wallet", "funding", WALLET])
    delta = cast(JsonObject, funding[0]["delta"])
    assert delta["coin"] == "BTC"

    wrapped = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "wallet",
            "wrapped",
            WALLET,
            "--out",
            str(tmp_path / "wrapped.html"),
        ]
    )
    assert wrapped == {"path": str(tmp_path / "wrapped.html"), "wallet": WALLET}


def test_vault_json_output_shapes(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    """Vault commands emit list, rank, and inspect JSON without live calls."""
    _seed_cache(tmp_path)
    monkeypatch.setattr("hl_research.cli.vault.InfoClient", FakeInfoClient)

    listed = _json_list(["--cache-dir", str(tmp_path), "--json", "vault", "ls"])
    assert listed[0].keys() >= {"address", "name", "leader", "tvl", "apr"}

    ranked = _json_list(
        ["--cache-dir", str(tmp_path), "--json", "vault", "rank", "--metric", "tvl"]
    )
    assert ranked[0]["address"] == VAULT

    inspected = _json_dict(["--cache-dir", str(tmp_path), "--json", "vault", "inspect", VAULT])
    assert inspected["vault"] == VAULT
    assert inspected.keys() >= {"metrics", "depositor_count", "equity_curve", "trade_list"}


def test_backtest_json_output_shapes(tmp_path: Path) -> None:
    """Backtest run, optimize, and walk-forward JSON shapes are stable."""
    _seed_cache(tmp_path)
    strategy_path = _write_strategy(tmp_path)

    run_payload = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "backtest",
            "run",
            str(strategy_path),
            "--asset",
            "BTC",
        ]
    )
    assert run_payload["strategy"] == "SnapshotStrategy"
    run_metrics = cast(JsonObject, run_payload["metrics"])
    assert run_metrics.keys() >= {"total_return", "sharpe", "trade_count"}

    optimized = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "backtest",
            "optimize",
            str(strategy_path),
            "--param",
            "size:0.01,0.02",
            "--asset",
            "BTC",
        ]
    )
    assert optimized["metric"] == "sharpe"
    runs = cast(list[JsonObject], optimized["runs"])
    assert len(runs) == 2

    walked = _json_dict(
        [
            "--cache-dir",
            str(tmp_path),
            "--json",
            "backtest",
            "walk-forward",
            str(strategy_path),
            "--window",
            "12h",
            "--step",
            "6h",
            "--asset",
            "BTC",
        ]
    )
    assert walked["strategy"] == "SnapshotStrategy"
    assert walked["windows"]


def _json_dict(args: list[str]) -> JsonObject:
    result = runner.invoke(app, args)
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert isinstance(payload, dict)
    return cast(JsonObject, payload)


def _json_list(args: list[str]) -> list[JsonObject]:
    result = runner.invoke(app, args)
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert isinstance(payload, list)
    assert all(isinstance(item, dict) for item in payload)
    return cast(list[JsonObject], payload)


def _seed_cache(root: Path) -> Cache:
    cache = Cache(root)
    cache.write_candles("BTC", "1h", _candles())
    cache.write_funding("BTC", _funding("BTC", [0.0001, -0.0002, 0.0003, 0.0002]))
    cache.write_funding("ETH", _funding("ETH", [-0.0001, 0.0001, -0.0001, 0.0001]))
    cache.write_fills(WALLET, _fills())
    cache.write_vault_summaries(
        [
            VaultSummary.model_validate(
                {
                    "name": "Snapshot Vault",
                    "vaultAddress": VAULT,
                    "leader": LEADER,
                    "tvl": "250000.0",
                    "apr": "0.18",
                    "isClosed": False,
                }
            )
        ]
    )
    cache.write_vault_trades(
        VAULT,
        [VaultTrade.model_validate(row.model_dump(by_alias=True)) for row in _fills()],
    )
    return cache


def _candles() -> list[Candle]:
    rows: list[Candle] = []
    price = 100.0
    for i in range(48):
        open_time = T0 + i * HOUR_MS
        close = price + (1.2 if i % 4 else -0.8)
        rows.append(
            Candle.model_validate(
                {
                    "t": open_time,
                    "T": open_time + HOUR_MS - 1,
                    "s": "BTC",
                    "i": "1h",
                    "o": str(price),
                    "c": str(close),
                    "h": str(max(price, close) + 1.0),
                    "l": str(min(price, close) - 1.0),
                    "v": "1000.0",
                    "n": 100,
                }
            )
        )
        price = close
    return rows


def _funding(asset: str, rates: list[float]) -> list[FundingRate]:
    return [
        FundingRate.model_validate(
            {
                "coin": asset,
                "fundingRate": str(rate),
                "premium": str(rate / 2),
                "time": T0 + index * HOUR_MS,
            }
        )
        for index, rate in enumerate(rates)
    ]


def _fills() -> list[Fill]:
    raw = [
        ("BTC", "B", T0, 100.0, 0.5, 0.0, "Open Long", 0.0),
        ("BTC", "A", T0 + 2 * HOUR_MS, 105.0, 0.5, 2.5, "Close Long", 0.5),
        ("ETH", "B", T0 + 3 * HOUR_MS, 200.0, 0.2, 0.0, "Open Long", 0.0),
        ("ETH", "A", T0 + 5 * HOUR_MS, 190.0, 0.2, -2.0, "Close Long", 0.2),
    ]
    return [
        Fill.model_validate(
            {
                "coin": asset,
                "px": str(price),
                "sz": str(size),
                "side": side,
                "time": time,
                "startPosition": str(start_position),
                "dir": direction,
                "closedPnl": str(pnl),
                "hash": f"0x{index:064x}",
                "oid": index,
                "crossed": True,
                "fee": "0.05",
                "tid": index,
                "feeToken": "USDC",
            }
        )
        for index, (
            asset,
            side,
            time,
            price,
            size,
            pnl,
            direction,
            start_position,
        ) in enumerate(raw, 1)
    ]


def _funding_payments() -> list[FundingPayment]:
    return [
        FundingPayment.model_validate(
            {
                "time": T0,
                "hash": "0xfunding",
                "delta": {
                    "coin": "BTC",
                    "fundingRate": "0.0001",
                    "szi": "0.5",
                    "usdc": "3.25",
                },
            }
        )
    ]


def _state() -> ClearinghouseState:
    summary = {
        "accountValue": "10000.0",
        "totalMarginUsed": "500.0",
        "totalNtlPos": "1200.0",
        "totalRawUsd": "10000.0",
    }
    return ClearinghouseState.model_validate(
        {
            "assetPositions": [],
            "crossMarginSummary": summary,
            "marginSummary": summary,
            "time": T0,
            "withdrawable": "9500.0",
        }
    )


def _vault_details() -> VaultDetails:
    return VaultDetails.model_validate(
        {
            "name": "Snapshot Vault",
            "vaultAddress": VAULT,
            "leader": LEADER,
            "description": "offline fixture",
            "portfolio": [
                {
                    "time": T0,
                    "accountValueHistory": [
                        [T0, 100000.0],
                        [T0 + DAY_MS, 103000.0],
                        [T0 + 2 * DAY_MS, 101000.0],
                    ],
                    "pnlHistory": [],
                }
            ],
            "followers": [
                {
                    "user": WALLET,
                    "vaultEquity": "1000.0",
                    "pnl": "50.0",
                    "allTimePnl": "75.0",
                    "daysFollowing": 14,
                }
            ],
            "isClosed": False,
        }
    )


class FakeInfoClient:
    """Async context manager matching the InfoClient surface used by CLI tests."""

    def __init__(self, *_args: object, **_kwargs: object) -> None:
        pass

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        return None

    async def clearinghouse_state(self, user: str) -> ClearinghouseState:
        assert user == WALLET
        return _state()

    async def user_fills(self, user: str) -> list[Fill]:
        assert user == WALLET
        return _fills()

    async def user_fills_by_time(
        self, user: str, _start: int, _end: int | None = None
    ) -> list[Fill]:
        assert user == WALLET
        return _fills()

    async def user_funding(
        self, user: str, _start: int, _end: int | None = None
    ) -> list[FundingPayment]:
        assert user == WALLET
        return _funding_payments()

    async def candle_snapshot(
        self, coin: str, _interval: str, _start: int, _end: int
    ) -> list[Candle]:
        assert coin == "BTC"
        return _candles()[:3]

    async def funding_history(
        self, coin: str, _start: int, _end: int | None = None
    ) -> list[FundingRate]:
        assert coin == "BTC"
        return _funding("BTC", [0.0001, -0.0002, 0.0003])

    async def vault_details(self, vault: str) -> VaultDetails:
        assert vault == VAULT
        return _vault_details()


def _write_strategy(root: Path) -> Path:
    path = root / "snapshot_strategy.py"
    path.write_text(
        """
from hl_research.backtest.strategy import Order, Strategy


class SnapshotStrategy(Strategy):
    def __init__(self) -> None:
        super().__init__()
        self._entered = False

    def on_candle(self, candle, ctx):
        size = float(ctx.params.get("size", 0.01))
        position = ctx.positions.get(candle.asset)
        held = position.size if position else 0.0
        if not self._entered:
            self._entered = True
            return [Order(asset=candle.asset, side="buy", size=size, kind="market")]
        if held > 0 and candle.open_time % (12 * 60 * 60 * 1000) == 0:
            return [
                Order(
                    asset=candle.asset,
                    side="sell",
                    size=abs(held),
                    kind="market",
                    reduce_only=True,
                )
            ]
        return []
""".strip()
        + "\n",
        encoding="utf-8",
    )
    return path
