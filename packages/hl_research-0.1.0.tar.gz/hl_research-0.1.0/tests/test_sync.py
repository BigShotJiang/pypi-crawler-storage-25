"""Tests for incremental cache synchronization."""

from pathlib import Path

import pytest

from hl_research.api.info import InfoClient
from hl_research.api.types import Candle, Fill, FundingRate, Interval, Meta
from hl_research.cache.store import Cache
from hl_research.cache.sync import Syncer

USER = "0x0000000000000000000000000000000000000001"


class FakeInfoClient(InfoClient):
    """Small offline client for sync tests."""

    def __init__(self) -> None:
        self.candle_starts: list[int] = []
        self.funding_starts: list[int] = []
        self.fill_starts: list[int] = []

    async def meta(self) -> Meta:
        return Meta.model_validate(
            {
                "universe": [
                    {"name": "BTC", "szDecimals": 5, "maxLeverage": 50, "onlyIsolated": False}
                ]
            }
        )

    async def candle_snapshot(
        self, coin: str, interval: Interval, start: int, end: int
    ) -> list[Candle]:
        self.candle_starts.append(start)
        if start > end:
            return []
        rows: list[Candle] = []
        cursor = start
        while cursor <= end and len(rows) < 5_000:
            rows.append(
                Candle.model_validate(
                    {
                        "t": cursor,
                        "T": cursor + 3_599_999,
                        "s": coin,
                        "i": interval,
                        "o": "1",
                        "c": "2",
                        "h": "3",
                        "l": "1",
                        "v": "10",
                        "n": 1,
                    }
                )
            )
            cursor += 3_600_000
        return rows

    async def funding_history(
        self, coin: str, start: int, end: int | None = None
    ) -> list[FundingRate]:
        self.funding_starts.append(start)
        upper = end if end is not None else start
        if start > upper:
            return []
        return [
            FundingRate.model_validate(
                {"coin": coin, "fundingRate": "0.1", "premium": "0.2", "time": start}
            )
        ]

    async def user_fills_by_time(
        self,
        user: str,
        start: int,
        end: int | None = None,
        aggregate_by_time: bool = False,
    ) -> list[Fill]:
        self.fill_starts.append(start)
        upper = end if end is not None else start
        if start > upper:
            return []
        return [
            Fill.model_validate(
                {
                    "coin": "BTC",
                    "px": "2",
                    "sz": "1",
                    "side": "B",
                    "time": start,
                    "startPosition": "0",
                    "dir": "Open Long",
                    "closedPnl": "0",
                    "hash": f"0x{start}",
                    "oid": 1,
                    "crossed": True,
                    "fee": "0.01",
                    "tid": 1,
                }
            )
        ]


@pytest.mark.asyncio
async def test_syncer_pulls_and_resumes(tmp_path: Path) -> None:
    cache = Cache(tmp_path)
    client = FakeInfoClient()
    syncer = Syncer(client, cache)

    universe = await syncer.pull_universe()
    assert universe.rows_written == 1
    assert cache.read_assets()["name"].item() == "BTC"

    candles = await syncer.pull_candles("BTC", "1h", 1_710_000_000_000, 1_710_003_600_000)
    assert candles.rows_written == 2
    assert cache.read_candles("BTC", "1h").collect().height == 2

    resumed = await syncer.pull_candles("BTC", "1h", 1_710_000_000_000, 1_710_007_200_000)
    assert resumed.since_ms == 1_710_007_200_000
    assert client.candle_starts[-1] == 1_710_007_200_000

    funding = await syncer.pull_funding("BTC", 1_710_000_000_000, 1_710_000_000_000)
    assert funding.rows_written == 1

    fills = await syncer.pull_fills(USER, 1_710_000_000_000, 1_710_000_000_000)
    assert fills.rows_written == 1
