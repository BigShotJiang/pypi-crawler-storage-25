"""Vault analytics primitives."""

import math

import polars as pl

from hl_research.analytics.types import VaultAnalysis, VaultMetrics
from hl_research.api.types import Address

MS_PER_YEAR = 365 * 24 * 60 * 60 * 1_000


def analyze_vault(
    vault: Address,
    equity_curve: pl.LazyFrame | pl.DataFrame,
    trades: pl.LazyFrame | pl.DataFrame,
    followers: pl.LazyFrame | pl.DataFrame | None = None,
    name: str | None = None,
    leader: Address | None = None,
    tvl: float | None = None,
) -> VaultAnalysis:
    """Build a vault inspection result from cached vault frames."""
    equity = _collect(equity_curve).sort("time")
    trade_list = _collect(trades).sort("time")
    follower_frame = _collect(followers) if followers is not None else pl.DataFrame()
    depositor_count = _depositor_count(follower_frame)
    resolved_tvl = tvl if tvl is not None else _latest_equity(equity)

    return VaultAnalysis(
        vault=vault,
        name=name,
        leader=leader,
        tvl=resolved_tvl,
        depositor_count=depositor_count,
        equity_curve=equity,
        metrics=vault_metrics(equity),
        trade_list=trade_list,
        asset_breakdown=asset_breakdown(trade_list),
    )


def vault_metrics(equity_curve: pl.LazyFrame | pl.DataFrame) -> VaultMetrics:
    """Compute basic performance metrics for a vault equity curve."""
    frame = _collect(equity_curve)
    if frame.height < 2 or "time" not in frame.columns or "equity" not in frame.columns:
        return VaultMetrics(
            total_return=0.0,
            annualized_return=0.0,
            volatility=0.0,
            sharpe=0.0,
            max_drawdown=0.0,
        )
    frame = frame.sort("time")

    values = [float(value) for value in frame.get_column("equity").to_list()]
    times = [int(value) for value in frame.get_column("time").to_list()]
    returns = [
        (current / previous) - 1
        for previous, current in zip(values, values[1:], strict=False)
        if previous
    ]
    total_return = (values[-1] / values[0]) - 1 if values[0] else 0.0
    years = (times[-1] - times[0]) / MS_PER_YEAR
    annualized = (1 + total_return) ** (1 / years) - 1 if years > 0 and total_return > -1 else 0.0
    volatility = _std(returns) * math.sqrt(365) if returns else 0.0

    return VaultMetrics(
        total_return=total_return,
        annualized_return=annualized,
        volatility=volatility,
        sharpe=annualized / volatility if volatility else 0.0,
        max_drawdown=_max_drawdown(values),
    )


def asset_breakdown(trades: pl.LazyFrame | pl.DataFrame) -> pl.DataFrame:
    """Summarize vault trades by asset."""
    frame = _collect(trades)
    if frame.is_empty():
        return pl.DataFrame(
            schema={
                "asset": pl.String,
                "trade_count": pl.Int64,
                "volume": pl.Float64,
                "closed_pnl": pl.Float64,
            }
        )
    pnl_expr = pl.col("closed_pnl").fill_null(0.0) if "closed_pnl" in frame.columns else pl.lit(0.0)
    return (
        frame.with_columns((pl.col("price") * pl.col("size")).abs().alias("notional"))
        .group_by("asset")
        .agg(
            pl.len().alias("trade_count"),
            pl.col("notional").sum().alias("volume"),
            pnl_expr.sum().alias("closed_pnl"),
        )
        .sort("volume", descending=True)
    )


def inspect_trades(
    trades: pl.LazyFrame | pl.DataFrame,
    asset: str | None = None,
    limit: int = 50,
) -> pl.DataFrame:
    """Return a sorted vault trade list for inspection."""
    frame = _collect(trades).sort("time", descending=True)
    if asset is not None and not frame.is_empty():
        frame = frame.filter(pl.col("asset") == asset)
    return frame.head(limit)


def _depositor_count(followers: pl.DataFrame) -> int:
    if followers.is_empty():
        return 0
    if "user" in followers.columns:
        return int(followers.select(pl.col("user").n_unique()).item())
    return followers.height


def _latest_equity(equity_curve: pl.DataFrame) -> float | None:
    if equity_curve.is_empty() or "equity" not in equity_curve.columns:
        return None
    return float(equity_curve.select(pl.col("equity").last()).item())


def _std(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance)


def _max_drawdown(values: list[float]) -> float:
    peak = -math.inf
    drawdown = 0.0
    for value in values:
        peak = max(peak, value)
        if peak > 0:
            drawdown = min(drawdown, (value / peak) - 1)
    return drawdown


def _collect(frame: pl.LazyFrame | pl.DataFrame) -> pl.DataFrame:
    if isinstance(frame, pl.LazyFrame):
        return frame.collect()
    return frame
