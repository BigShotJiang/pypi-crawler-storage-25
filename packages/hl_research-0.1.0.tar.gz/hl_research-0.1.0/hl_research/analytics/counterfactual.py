"""Counterfactual performance analysis."""

import polars as pl

from hl_research.analytics.types import CounterfactualResult, CounterfactualTrade, RoundTripTrade

SPOT_PROXY_ASSUMPTION = (
    "Perp candle close is used as the spot proxy because v0 has no spot data integration."
)


def build_counterfactual(
    trades: list[RoundTripTrade],
    candles: dict[str, pl.LazyFrame],
) -> CounterfactualResult:
    """Compare actual closed-trade PnL against holding spot from entry to latest close.

    Assumption: Hyperliquid perp candle close is used as a spot-price proxy. This keeps v0
    local and dependency-free until real spot feeds are added.
    """
    candle_frames = {asset: frame.collect().sort("open_time") for asset, frame in candles.items()}
    results: list[CounterfactualTrade] = []
    for trade in trades:
        candle_frame = candle_frames.get(trade.asset)
        if candle_frame is None or candle_frame.is_empty():
            continue
        latest = candle_frame.filter(pl.col("open_time") >= trade.entry_time)
        if latest.is_empty():
            latest = candle_frame
        final_close = float(latest.select(pl.col("close").last()).item())
        hold_spot_pnl = trade.size * (final_close - trade.entry_price)
        actual_pnl = trade.realized_pnl
        results.append(
            CounterfactualTrade(
                asset=trade.asset,
                entry_time=trade.entry_time,
                exit_time=trade.exit_time,
                actual_pnl=actual_pnl,
                hold_spot_pnl=hold_spot_pnl,
                alpha_vs_hold=actual_pnl - hold_spot_pnl,
                final_close=final_close,
            )
        )

    actual_total = sum(row.actual_pnl for row in results)
    hold_total = sum(row.hold_spot_pnl for row in results)
    return CounterfactualResult(
        assumption=SPOT_PROXY_ASSUMPTION,
        actual_pnl=actual_total,
        hold_spot_pnl=hold_total,
        alpha_vs_hold=actual_total - hold_total,
        trades=results,
    )
