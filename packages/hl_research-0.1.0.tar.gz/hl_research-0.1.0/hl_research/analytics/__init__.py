"""Research primitives over cached Hyperliquid datasets."""
