"""Liquidation scans over cached fills."""
