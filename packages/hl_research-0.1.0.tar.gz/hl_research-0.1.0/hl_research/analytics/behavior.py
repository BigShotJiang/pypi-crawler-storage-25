"""Wallet behavior classification."""

from dataclasses import dataclass

import polars as pl

from hl_research.analytics.types import BehaviorResult, RoundTripTrade

TEN_MINUTES_MS = 10 * 60 * 1_000
ONE_HOUR_MS = 60 * 60 * 1_000
ONE_DAY_MS = 24 * ONE_HOUR_MS
SEVEN_DAYS_MS = 7 * ONE_DAY_MS


@dataclass(frozen=True)
class BehaviorCriteria:
    """Thresholds for the rules-based v0 behavior classifier."""

    revenge_loss_window_ms: int = TEN_MINUTES_MS
    revenge_min_loss_count: int = 2
    revenge_followup_ratio: float = 0.40
    """revenge_trader: more than 40% of losing trades are followed within 10 minutes."""

    funding_farmer_min_net_funding: float = 25.0
    funding_farmer_min_funding_share: float = 0.60
    """funding_farmer: earned funding is at least 60% of positive realized plus funding PnL."""

    leverage_addict_min_avg_notional: float = 100_000.0
    leverage_addict_min_loss_rate: float = 0.50
    """leverage_addict: average entry notional exceeds 100k and at least half of trades lose."""

    scalper_max_median_hold_ms: int = ONE_HOUR_MS
    scalper_min_trade_count: int = 5
    """scalper: at least five trades with median hold time below one hour."""

    hold_and_pray_min_median_hold_ms: int = SEVEN_DAYS_MS
    hold_and_pray_max_win_rate: float = 0.50
    """hold_and_pray: median hold exceeds seven days and win rate is no better than 50%."""

    swing_trader_min_median_hold_ms: int = ONE_DAY_MS
    swing_trader_max_median_hold_ms: int = SEVEN_DAYS_MS
    """swing_trader: median hold sits between one and seven days."""

    chad_min_win_rate: float = 0.65
    chad_min_total_pnl: float = 1_000.0
    """chad: win rate is at least 65% and total realized PnL exceeds 1k."""


DEFAULT_CRITERIA = BehaviorCriteria()


def classify_behavior(
    trades: list[RoundTripTrade],
    funding: pl.DataFrame | None = None,
    criteria: BehaviorCriteria = DEFAULT_CRITERIA,
) -> BehaviorResult:
    """Classify a wallet by applying documented rules in priority order."""
    stats = _behavior_stats(trades, funding)

    if (
        stats.losing_trades >= criteria.revenge_min_loss_count
        and stats.revenge_followup_ratio > criteria.revenge_followup_ratio
    ):
        return BehaviorResult(
            label="revenge_trader",
            reason=(
                "More than 40% of losing trades were followed by another trade within 10 minutes."
            ),
        )

    if (
        stats.net_funding >= criteria.funding_farmer_min_net_funding
        and stats.funding_share >= criteria.funding_farmer_min_funding_share
    ):
        return BehaviorResult(
            label="funding_farmer",
            reason="Positive funding accounts for at least 60% of realized plus funding PnL.",
        )

    if (
        stats.avg_notional >= criteria.leverage_addict_min_avg_notional
        and stats.loss_rate >= criteria.leverage_addict_min_loss_rate
    ):
        return BehaviorResult(
            label="leverage_addict",
            reason="Average entry notional is high and at least half of closed trades lost money.",
        )

    if (
        stats.trade_count >= criteria.scalper_min_trade_count
        and stats.median_hold_ms < criteria.scalper_max_median_hold_ms
    ):
        return BehaviorResult(
            label="scalper",
            reason="At least five closed trades had a median hold time under one hour.",
        )

    if (
        stats.median_hold_ms >= criteria.hold_and_pray_min_median_hold_ms
        and stats.win_rate <= criteria.hold_and_pray_max_win_rate
    ):
        return BehaviorResult(
            label="hold_and_pray",
            reason="Median hold time exceeded seven days while win rate stayed at or below 50%.",
        )

    if (
        criteria.swing_trader_min_median_hold_ms
        <= stats.median_hold_ms
        <= criteria.swing_trader_max_median_hold_ms
    ):
        return BehaviorResult(
            label="swing_trader",
            reason="Median hold time landed between one and seven days.",
        )

    if (
        stats.win_rate >= criteria.chad_min_win_rate
        and stats.total_pnl >= criteria.chad_min_total_pnl
    ):
        return BehaviorResult(
            label="chad",
            reason="Win rate was at least 65% and total realized PnL exceeded 1k.",
        )

    return BehaviorResult(label="balanced", reason="No dominant behavior rule was triggered.")


@dataclass(frozen=True)
class _BehaviorStats:
    trade_count: int
    total_pnl: float
    win_rate: float
    loss_rate: float
    losing_trades: int
    median_hold_ms: float
    avg_notional: float
    revenge_followup_ratio: float
    net_funding: float
    funding_share: float


def _behavior_stats(trades: list[RoundTripTrade], funding: pl.DataFrame | None) -> _BehaviorStats:
    if not trades:
        return _BehaviorStats(
            trade_count=0,
            total_pnl=0.0,
            win_rate=0.0,
            loss_rate=0.0,
            losing_trades=0,
            median_hold_ms=0.0,
            avg_notional=0.0,
            revenge_followup_ratio=0.0,
            net_funding=_net_funding(funding),
            funding_share=1.0 if _net_funding(funding) > 0 else 0.0,
        )

    pnls = [trade.realized_pnl for trade in trades]
    losing = [trade for trade in trades if trade.realized_pnl < 0]
    total_pnl = sum(pnls)
    net_funding = _net_funding(funding)
    positive_pool = max(0.0, total_pnl) + max(0.0, net_funding)
    funding_share = max(0.0, net_funding) / positive_pool if positive_pool else 0.0

    return _BehaviorStats(
        trade_count=len(trades),
        total_pnl=total_pnl,
        win_rate=sum(1 for pnl in pnls if pnl > 0) / len(trades),
        loss_rate=len(losing) / len(trades),
        losing_trades=len(losing),
        median_hold_ms=_median([float(trade.hold_ms) for trade in trades]),
        avg_notional=sum(trade.notional for trade in trades) / len(trades),
        revenge_followup_ratio=_revenge_followup_ratio(trades, losing),
        net_funding=net_funding,
        funding_share=funding_share,
    )


def _revenge_followup_ratio(
    trades: list[RoundTripTrade], losing_trades: list[RoundTripTrade]
) -> float:
    if not losing_trades:
        return 0.0
    ordered = sorted(trades, key=lambda trade: trade.entry_time)
    followups = 0
    for losing_trade in losing_trades:
        if any(
            losing_trade.exit_time < trade.entry_time <= losing_trade.exit_time + TEN_MINUTES_MS
            for trade in ordered
        ):
            followups += 1
    return followups / len(losing_trades)


def _net_funding(funding: pl.DataFrame | None) -> float:
    if funding is None or funding.is_empty() or "usdc" not in funding.columns:
        return 0.0
    return float(funding.select(pl.col("usdc").sum()).item())


def _median(values: list[float]) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    midpoint = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[midpoint]
    return (ordered[midpoint - 1] + ordered[midpoint]) / 2
