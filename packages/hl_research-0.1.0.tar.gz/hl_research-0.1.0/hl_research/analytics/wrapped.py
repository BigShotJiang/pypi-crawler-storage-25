"""Wallet wrapped report calculations."""

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Literal

import polars as pl

from hl_research.analytics.behavior import classify_behavior
from hl_research.analytics.counterfactual import build_counterfactual
from hl_research.analytics.types import FillSummary, RoundTripTrade, WrappedReport
from hl_research.api.types import Address


def build_wrapped(
    fills: pl.LazyFrame,
    funding: pl.LazyFrame,
    candles: dict[str, pl.LazyFrame],
    wallet: Address,
) -> WrappedReport:
    """Build a wallet wrapped report from cached fills, funding, and candle frames."""
    fills_frame = fills.collect().sort("time")
    funding_frame = funding.collect().sort("time")
    trades = reconstruct_round_trip_trades(fills_frame)
    behavior = classify_behavior(trades, funding_frame)
    counterfactual = build_counterfactual(trades, candles)

    period = _period(fills_frame, funding_frame)
    total_realized_pnl = _sum_column(fills_frame, "closed_pnl")
    funding_paid = abs(min(0.0, _sum_negative(funding_frame, "usdc")))
    funding_earned = max(0.0, _sum_positive(funding_frame, "usdc"))
    trade_count = len(trades)
    win_rate = (
        sum(1 for trade in trades if trade.realized_pnl > 0) / trade_count if trade_count else 0.0
    )

    return WrappedReport(
        wallet=wallet,
        period=period,
        total_realized_pnl=total_realized_pnl,
        total_unrealized_pnl=0.0,
        funding_paid=funding_paid,
        funding_earned=funding_earned,
        win_rate=win_rate,
        trade_count=trade_count,
        pnl_by_asset=_pnl_by_asset(trades),
        hour_of_day=_hour_of_day(trades),
        hold_time_dist=_hold_time_dist(trades),
        behavior_cluster=behavior.label,
        behavior_reason=behavior.reason,
        counterfactual=counterfactual,
        top_wins=_top_trades(trades, reverse=True),
        top_losses=_top_trades(trades, reverse=False),
        trades=trades,
    )


def reconstruct_round_trip_trades(fills: pl.DataFrame) -> list[RoundTripTrade]:
    """Reconstruct closed round-trip trades by walking asset position transitions to zero."""
    if fills.is_empty():
        return []

    active: dict[str, _OpenPosition] = {}
    trades: list[RoundTripTrade] = []

    for row in fills.sort("time").iter_rows(named=True):
        fill = _FillRow.from_row(row)
        remaining_delta = fill.delta
        position = active.get(fill.asset)

        if position is None or position.signed_size == 0:
            if remaining_delta != 0:
                active[fill.asset] = _OpenPosition.from_fill(fill, remaining_delta)
            continue

        if _same_direction(position.signed_size, remaining_delta):
            position.add(fill, remaining_delta)
            continue

        close_size = min(abs(position.signed_size), abs(remaining_delta))
        realized_share = close_size / abs(remaining_delta) if remaining_delta else 0.0
        position.closed_pnl += fill.closed_pnl * realized_share
        position.fees += fill.fee * realized_share
        position.fill_count += 1
        position.signed_size += _signed(close_size, remaining_delta)

        if abs(position.signed_size) < 1e-12:
            trades.append(position.close(fill, close_size))
            active.pop(fill.asset, None)

        leftover = abs(remaining_delta) - close_size
        if leftover > 1e-12:
            active[fill.asset] = _OpenPosition.from_fill(fill, _signed(leftover, remaining_delta))

    return trades


@dataclass
class _FillRow:
    asset: str
    time: int
    side: Literal["A", "B"]
    price: float
    size: float
    closed_pnl: float
    fee: float

    @property
    def delta(self) -> float:
        return self.size if self.side == "B" else -self.size

    @classmethod
    def from_row(cls, row: dict[str, object]) -> "_FillRow":
        return cls(
            asset=str(row["asset"]),
            time=_to_int(row["time"]),
            side="B" if row["side"] == "B" else "A",
            price=_to_float(row["price"]),
            size=_to_float(row["size"]),
            closed_pnl=_to_float(row["closed_pnl"]),
            fee=_to_float(row["fee"]),
        )


@dataclass
class _OpenPosition:
    asset: str
    side: Literal["long", "short"]
    entry_time: int
    entry_price: float
    signed_size: float
    max_size: float
    closed_pnl: float
    fees: float
    fill_count: int

    @classmethod
    def from_fill(cls, fill: _FillRow, signed_size: float) -> "_OpenPosition":
        return cls(
            asset=fill.asset,
            side="long" if signed_size > 0 else "short",
            entry_time=fill.time,
            entry_price=fill.price,
            signed_size=signed_size,
            max_size=abs(signed_size),
            closed_pnl=fill.closed_pnl,
            fees=fill.fee,
            fill_count=1,
        )

    def add(self, fill: _FillRow, signed_delta: float) -> None:
        current_abs = abs(self.signed_size)
        added_abs = abs(signed_delta)
        self.entry_price = ((self.entry_price * current_abs) + (fill.price * added_abs)) / (
            current_abs + added_abs
        )
        self.signed_size += signed_delta
        self.max_size = max(self.max_size, abs(self.signed_size))
        self.closed_pnl += fill.closed_pnl
        self.fees += fill.fee
        self.fill_count += 1

    def close(self, fill: _FillRow, close_size: float) -> RoundTripTrade:
        return RoundTripTrade(
            asset=self.asset,
            side=self.side,
            entry_time=self.entry_time,
            exit_time=fill.time,
            entry_price=self.entry_price,
            exit_price=fill.price,
            size=max(self.max_size, close_size),
            realized_pnl=self.closed_pnl,
            fees=self.fees,
            fill_count=self.fill_count,
        )


def _same_direction(left: float, right: float) -> bool:
    return (left > 0 and right > 0) or (left < 0 and right < 0)


def _signed(size: float, direction: float) -> float:
    return size if direction > 0 else -size


def _period(fills: pl.DataFrame, funding: pl.DataFrame) -> tuple[datetime, datetime]:
    times: list[int] = []
    if not fills.is_empty():
        times.extend(
            [
                int(fills.select(pl.col("time").min()).item()),
                int(fills.select(pl.col("time").max()).item()),
            ]
        )
    if not funding.is_empty() and "time" in funding.columns:
        times.extend(
            [
                int(funding.select(pl.col("time").min()).item()),
                int(funding.select(pl.col("time").max()).item()),
            ]
        )
    if not times:
        now = datetime.now(tz=UTC)
        return (now, now)
    return (_dt(min(times)), _dt(max(times)))


def _pnl_by_asset(trades: list[RoundTripTrade]) -> pl.DataFrame:
    if not trades:
        return pl.DataFrame(
            schema={"asset": pl.String, "realized_pnl": pl.Float64, "trade_count": pl.Int64}
        )
    return (
        pl.DataFrame(
            [{"asset": trade.asset, "realized_pnl": trade.realized_pnl} for trade in trades]
        )
        .group_by("asset")
        .agg(pl.col("realized_pnl").sum(), pl.len().alias("trade_count"))
        .sort("realized_pnl", descending=True)
    )


def _hour_of_day(trades: list[RoundTripTrade]) -> pl.DataFrame:
    if not trades:
        return pl.DataFrame(
            schema={"hour": pl.Int64, "trade_count": pl.Int64, "realized_pnl": pl.Float64}
        )
    rows = [
        {
            "hour": datetime.fromtimestamp(trade.exit_time / 1000, tz=UTC).hour,
            "realized_pnl": trade.realized_pnl,
        }
        for trade in trades
    ]
    return (
        pl.DataFrame(rows)
        .group_by("hour")
        .agg(pl.len().alias("trade_count"), pl.col("realized_pnl").sum())
        .sort("hour")
    )


def _hold_time_dist(trades: list[RoundTripTrade]) -> pl.DataFrame:
    if not trades:
        return pl.DataFrame(schema={"bucket": pl.String, "trade_count": pl.Int64})
    rows = [{"bucket": _hold_bucket(trade.hold_ms)} for trade in trades]
    return pl.DataFrame(rows).group_by("bucket").agg(pl.len().alias("trade_count")).sort("bucket")


def _hold_bucket(hold_ms: int) -> str:
    if hold_ms < 60 * 60 * 1_000:
        return "scalp"
    if hold_ms < 24 * 60 * 60 * 1_000:
        return "intraday"
    if hold_ms < 7 * 24 * 60 * 60 * 1_000:
        return "swing"
    return "hold"


def _top_trades(trades: list[RoundTripTrade], reverse: bool) -> list[FillSummary]:
    ordered = sorted(trades, key=lambda trade: trade.realized_pnl, reverse=reverse)
    selected = [
        trade
        for trade in ordered
        if (trade.realized_pnl >= 0 if reverse else trade.realized_pnl < 0)
    ]
    return [
        FillSummary(
            asset=trade.asset,
            time=_dt(trade.exit_time),
            side=trade.side,
            price=trade.exit_price,
            size=trade.size,
            pnl=trade.realized_pnl,
        )
        for trade in selected[:20]
    ]


def _sum_column(frame: pl.DataFrame, column: str) -> float:
    if frame.is_empty() or column not in frame.columns:
        return 0.0
    return float(frame.select(pl.col(column).sum()).item())


def _sum_positive(frame: pl.DataFrame, column: str) -> float:
    if frame.is_empty() or column not in frame.columns:
        return 0.0
    return float(frame.filter(pl.col(column) > 0).select(pl.col(column).sum()).item() or 0.0)


def _sum_negative(frame: pl.DataFrame, column: str) -> float:
    if frame.is_empty() or column not in frame.columns:
        return 0.0
    return float(frame.filter(pl.col(column) < 0).select(pl.col(column).sum()).item() or 0.0)


def _dt(timestamp_ms: int) -> datetime:
    return datetime.fromtimestamp(timestamp_ms / 1000, tz=UTC)


def _to_float(value: object) -> float:
    if value is None:
        return 0.0
    if isinstance(value, int | float | str):
        return float(value)
    return 0.0


def _to_int(value: object) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, float | str):
        return int(value)
    return 0
