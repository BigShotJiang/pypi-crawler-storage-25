"""Naive funding-rate prediction baseline."""

import math

import polars as pl

from hl_research.analytics.types import FundingPrediction

METHOD = "naive_ewma_baseline"


def predict_next_funding(
    funding: pl.LazyFrame | pl.DataFrame,
    asset: str,
    span: int = 8,
    confidence_width: float = 1.96,
) -> FundingPrediction:
    """Predict next funding with a naive EWMA baseline.

    This is intentionally simple and should be labeled as a baseline in any user-facing
    output. It uses only historical funding rates, no order book, no premium-index model,
    and no cross-venue signal.
    """
    if span <= 0:
        msg = "span must be positive"
        raise ValueError(msg)

    frame = _collect(funding)
    if frame.is_empty() or "funding_rate" not in frame.columns:
        return FundingPrediction(
            asset=asset,
            predicted_rate=0.0,
            lower_bound=0.0,
            upper_bound=0.0,
            confidence_band=0.0,
            observations=0,
            method=METHOD,
        )
    frame = frame.sort("time") if "time" in frame.columns else frame

    rates = [float(value) for value in frame.get_column("funding_rate").to_list()]
    alpha = 2 / (span + 1)
    prediction = rates[0]
    fitted: list[float] = []
    for rate in rates:
        fitted.append(prediction)
        prediction = alpha * rate + (1 - alpha) * prediction

    residuals = [rate - fit for rate, fit in zip(rates, fitted, strict=True)]
    band = confidence_width * _std(residuals)
    return FundingPrediction(
        asset=asset,
        predicted_rate=prediction,
        lower_bound=prediction - band,
        upper_bound=prediction + band,
        confidence_band=band,
        observations=len(rates),
        method=METHOD,
    )


def _std(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance)


def _collect(frame: pl.LazyFrame | pl.DataFrame) -> pl.DataFrame:
    if isinstance(frame, pl.LazyFrame):
        return frame.collect()
    return frame
