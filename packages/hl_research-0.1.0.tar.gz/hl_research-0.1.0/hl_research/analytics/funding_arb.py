"""Funding arbitrage research primitives."""

import polars as pl

from hl_research.analytics.types import FundingBasisResult

PERIODS_PER_YEAR = 3 * 365


def perp_perp_basis(
    funding: pl.LazyFrame | pl.DataFrame,
    reference: pl.LazyFrame | pl.DataFrame,
    asset: str,
    reference_asset: str,
) -> FundingBasisResult:
    """Compute perp-vs-perp funding basis between two funding-rate histories.

    v0 does not integrate spot data. This function compares one perpetual's funding
    rate against another perpetual's funding rate on matching timestamps.
    """
    left = _collect(funding).select(
        pl.col("time"),
        pl.col("funding_rate").alias("funding_rate"),
    )
    right = _collect(reference).select(
        pl.col("time"),
        pl.col("funding_rate").alias("reference_rate"),
    )
    joined = (
        left.join(right, on="time", how="inner")
        .with_columns(
            (pl.col("funding_rate") - pl.col("reference_rate")).alias("basis"),
            ((pl.col("funding_rate") - pl.col("reference_rate")) * PERIODS_PER_YEAR).alias(
                "annualized_basis"
            ),
            pl.lit(asset).alias("asset"),
            pl.lit(reference_asset).alias("reference_asset"),
        )
        .select(
            "time",
            "asset",
            "reference_asset",
            "funding_rate",
            "reference_rate",
            "basis",
            "annualized_basis",
        )
        .sort("time")
    )

    if joined.is_empty():
        return FundingBasisResult(
            asset=asset,
            reference_asset=reference_asset,
            mean_basis=0.0,
            latest_basis=0.0,
            latest_annualized_basis=0.0,
            observations=0,
            series=joined,
        )

    return FundingBasisResult(
        asset=asset,
        reference_asset=reference_asset,
        mean_basis=float(joined.select(pl.col("basis").mean()).item()),
        latest_basis=float(joined.select(pl.col("basis").last()).item()),
        latest_annualized_basis=float(joined.select(pl.col("annualized_basis").last()).item()),
        observations=joined.height,
        series=joined,
    )


def rank_basis(
    funding_by_asset: dict[str, pl.LazyFrame | pl.DataFrame],
    base_asset: str,
) -> list[FundingBasisResult]:
    """Rank perp-vs-perp basis for a base asset against other cached assets."""
    base = funding_by_asset[base_asset]
    results = [
        perp_perp_basis(base, frame, base_asset, reference_asset)
        for reference_asset, frame in funding_by_asset.items()
        if reference_asset != base_asset
    ]
    return sorted(results, key=lambda result: abs(result.latest_basis), reverse=True)


def _collect(frame: pl.LazyFrame | pl.DataFrame) -> pl.DataFrame:
    if isinstance(frame, pl.LazyFrame):
        return frame.collect()
    return frame
