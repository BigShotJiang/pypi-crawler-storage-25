"""Public dataclasses for wallet analytics."""

from dataclasses import dataclass
from datetime import datetime
from typing import Literal

import polars as pl

from hl_research.api.types import Address

BehaviorLabel = Literal[
    "revenge_trader",
    "funding_farmer",
    "leverage_addict",
    "scalper",
    "hold_and_pray",
    "swing_trader",
    "chad",
    "balanced",
]


@dataclass(frozen=True)
class RoundTripTrade:
    """Closed position reconstructed from one or more HL fills."""

    asset: str
    side: Literal["long", "short"]
    entry_time: int
    exit_time: int
    entry_price: float
    exit_price: float
    size: float
    realized_pnl: float
    fees: float
    fill_count: int

    @property
    def hold_ms(self) -> int:
        """Return the position hold time in milliseconds."""
        return self.exit_time - self.entry_time

    @property
    def net_pnl(self) -> float:
        """Return realized PnL after fees."""
        return self.realized_pnl - self.fees

    @property
    def notional(self) -> float:
        """Return entry notional in dollars."""
        return abs(self.entry_price * self.size)


@dataclass(frozen=True)
class FillSummary:
    """Compact fill or trade summary for report tables."""

    asset: str
    time: datetime
    side: str
    price: float
    size: float
    pnl: float


@dataclass(frozen=True)
class CounterfactualTrade:
    """Per-trade realized-vs-hold comparison."""

    asset: str
    entry_time: int
    exit_time: int
    actual_pnl: float
    hold_spot_pnl: float
    alpha_vs_hold: float
    final_close: float


@dataclass(frozen=True)
class CounterfactualResult:
    """Aggregate result for the hold-spot counterfactual."""

    assumption: str
    actual_pnl: float
    hold_spot_pnl: float
    alpha_vs_hold: float
    trades: list[CounterfactualTrade]


@dataclass(frozen=True)
class BehaviorResult:
    """Behavior classifier output with a reason suitable for presentation."""

    label: BehaviorLabel
    reason: str


@dataclass(frozen=True)
class WrappedReport:
    """Wallet wrapped report data consumed by presentation surfaces."""

    wallet: Address
    period: tuple[datetime, datetime]
    total_realized_pnl: float
    total_unrealized_pnl: float
    funding_paid: float
    funding_earned: float
    win_rate: float
    trade_count: int
    pnl_by_asset: pl.DataFrame
    hour_of_day: pl.DataFrame
    hold_time_dist: pl.DataFrame
    behavior_cluster: BehaviorLabel
    behavior_reason: str
    counterfactual: CounterfactualResult
    top_wins: list[FillSummary]
    top_losses: list[FillSummary]
    trades: list[RoundTripTrade]


@dataclass(frozen=True)
class BasisPoint:
    """One perp-vs-perp funding basis observation."""

    time: int
    asset: str
    reference_asset: str
    funding_rate: float
    reference_rate: float
    basis: float
    annualized_basis: float


@dataclass(frozen=True)
class FundingBasisResult:
    """Perp-vs-perp funding basis summary for one asset."""

    asset: str
    reference_asset: str
    mean_basis: float
    latest_basis: float
    latest_annualized_basis: float
    observations: int
    series: pl.DataFrame


@dataclass(frozen=True)
class FundingPrediction:
    """Naive next-period funding prediction."""

    asset: str
    predicted_rate: float
    lower_bound: float
    upper_bound: float
    confidence_band: float
    observations: int
    method: str


@dataclass(frozen=True)
class VaultMetrics:
    """Performance metrics for a vault equity curve."""

    total_return: float
    annualized_return: float
    volatility: float
    sharpe: float
    max_drawdown: float


@dataclass(frozen=True)
class VaultAnalysis:
    """Vault inspection result consumed by CLI and presentation surfaces."""

    vault: Address
    name: str | None
    leader: Address | None
    tvl: float | None
    depositor_count: int
    equity_curve: pl.DataFrame
    metrics: VaultMetrics
    trade_list: pl.DataFrame
    asset_breakdown: pl.DataFrame
