"""Canonical cache schemas."""

import polars as pl
from polars.datatypes.classes import DataTypeClass

Schema = dict[str, DataTypeClass | pl.DataType]

CANDLE_SCHEMA: Schema = {
    "asset": pl.String,
    "interval": pl.String,
    "open_time": pl.Int64,
    "close_time": pl.Int64,
    "open": pl.Float64,
    "high": pl.Float64,
    "low": pl.Float64,
    "close": pl.Float64,
    "volume": pl.Float64,
    "trade_count": pl.Int64,
}

FUNDING_SCHEMA: Schema = {
    "asset": pl.String,
    "time": pl.Int64,
    "funding_rate": pl.Float64,
    "premium": pl.Float64,
}

FILL_SCHEMA: Schema = {
    "wallet": pl.String,
    "asset": pl.String,
    "time": pl.Int64,
    "side": pl.String,
    "price": pl.Float64,
    "size": pl.Float64,
    "start_position": pl.Float64,
    "direction": pl.String,
    "closed_pnl": pl.Float64,
    "hash": pl.String,
    "oid": pl.Int64,
    "tid": pl.Int64,
    "crossed": pl.Boolean,
    "fee": pl.Float64,
    "fee_token": pl.String,
    "liquidation": pl.Boolean,
}

VAULT_TRADE_SCHEMA: Schema = {
    "vault": pl.String,
    "asset": pl.String,
    "time": pl.Int64,
    "side": pl.String,
    "price": pl.Float64,
    "size": pl.Float64,
    "start_position": pl.Float64,
    "direction": pl.String,
    "closed_pnl": pl.Float64,
    "hash": pl.String,
    "oid": pl.Int64,
    "tid": pl.Int64,
    "crossed": pl.Boolean,
    "fee": pl.Float64,
    "fee_token": pl.String,
    "liquidation": pl.Boolean,
}

ASSET_SCHEMA: Schema = {
    "name": pl.String,
    "sz_decimals": pl.Int64,
    "max_leverage": pl.Int64,
    "only_isolated": pl.Boolean,
}

VAULT_SUMMARY_SCHEMA: Schema = {
    "address": pl.String,
    "name": pl.String,
    "leader": pl.String,
    "tvl": pl.Float64,
    "apr": pl.Float64,
    "is_closed": pl.Boolean,
}


def empty_frame(schema: Schema) -> pl.DataFrame:
    """Return an empty DataFrame with a canonical schema."""
    return pl.DataFrame(schema=dict(schema))


def polars_schema(schema: Schema) -> pl.Schema:
    """Convert a canonical schema mapping into a Polars Schema."""
    return pl.Schema(schema)
