"""Cache path resolution."""

import os
from pathlib import Path

DEFAULT_CACHE_DIRNAME = "hl-research"


def default_cache_dir() -> Path:
    """Return the default XDG-compatible cache directory."""
    env_override = os.environ.get("HLR_CACHE_DIR")
    if env_override:
        return Path(env_override).expanduser()

    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home).expanduser() / DEFAULT_CACHE_DIRNAME

    return Path.home() / ".cache" / DEFAULT_CACHE_DIRNAME
