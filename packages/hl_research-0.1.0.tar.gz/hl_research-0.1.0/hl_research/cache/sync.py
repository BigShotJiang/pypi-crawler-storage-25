"""Incremental cache synchronization."""

from __future__ import annotations

from dataclasses import dataclass, field

from hl_research.api.info import InfoClient
from hl_research.api.types import Candle, Fill, FundingRate, Interval, VaultTrade
from hl_research.cache.store import Cache

MAX_PAGES = 1_000

INTERVAL_MS: dict[Interval, int] = {
    "1m": 60_000,
    "3m": 180_000,
    "5m": 300_000,
    "15m": 900_000,
    "30m": 1_800_000,
    "1h": 3_600_000,
    "2h": 7_200_000,
    "4h": 14_400_000,
    "8h": 28_800_000,
    "12h": 43_200_000,
    "1d": 86_400_000,
    "3d": 259_200_000,
    "1w": 604_800_000,
    "1M": 2_592_000_000,
}


@dataclass(frozen=True)
class Gap:
    """Detected timestamp gap in a synced dataset."""

    start_ms: int
    end_ms: int
    expected_step_ms: int


@dataclass(frozen=True)
class SyncResult:
    """Result of an incremental sync operation."""

    kind: str
    entity: str
    interval: str | None
    rows_written: int
    since_ms: int
    until_ms: int
    gaps: list[Gap] = field(default_factory=list)


class Syncer:
    """Incrementally synchronize Hyperliquid info data into the local cache."""

    def __init__(self, client: InfoClient, cache: Cache) -> None:
        self._client = client
        self._cache = cache

    async def pull_universe(self) -> SyncResult:
        """Fetch and cache the current perpetual universe."""
        meta = await self._client.meta()
        self._cache.write_assets(meta.universe)
        return SyncResult(
            kind="assets",
            entity="perps",
            interval=None,
            rows_written=len(meta.universe),
            since_ms=0,
            until_ms=0,
        )

    async def pull_candles(
        self,
        asset: str,
        interval: Interval,
        since_ms: int,
        until_ms: int,
    ) -> SyncResult:
        """Incrementally pull candle history."""
        state = self._cache.sync_state("candles", asset, interval)
        start = max(since_ms, (state.until_ms + INTERVAL_MS[interval]) if state else since_ms)
        rows: list[Candle] = []
        cursor = start
        for _page in range(MAX_PAGES):
            if cursor > until_ms:
                break
            page = await self._client.candle_snapshot(asset, interval, cursor, until_ms)
            if not page:
                break
            rows.extend(page)
            next_cursor = max(row.open_time for row in page) + INTERVAL_MS[interval]
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            if len(page) < 5_000:
                break
        self._cache.write_candles(asset, interval, rows)
        gaps = detect_gaps([row.open_time for row in rows], INTERVAL_MS[interval])
        return _sync_result("candles", asset, interval, rows, start, until_ms, gaps)

    async def pull_funding(
        self,
        asset: str,
        since_ms: int,
        until_ms: int | None = None,
    ) -> SyncResult:
        """Incrementally pull funding-rate history."""
        state = self._cache.sync_state("funding", asset)
        start = max(since_ms, (state.until_ms + 1) if state else since_ms)
        rows: list[FundingRate] = []
        cursor = start
        for _page in range(MAX_PAGES):
            page = await self._client.funding_history(asset, cursor, until_ms)
            if not page:
                break
            rows.extend(page)
            next_cursor = max(row.time for row in page) + 1
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            if len(page) < 500:
                break
        self._cache.write_funding(asset, rows)
        end = until_ms if until_ms is not None else (max((row.time for row in rows), default=start))
        gaps = detect_gaps([row.time for row in rows], 3_600_000)
        return _sync_result("funding", asset, None, rows, start, end, gaps)

    async def pull_fills(
        self,
        wallet: str,
        since_ms: int,
        until_ms: int | None = None,
    ) -> SyncResult:
        """Incrementally pull wallet fills."""
        state = self._cache.sync_state("fills", wallet)
        start = max(since_ms, (state.until_ms + 1) if state else since_ms)
        rows: list[Fill] = []
        cursor = start
        for _page in range(MAX_PAGES):
            page = await self._client.user_fills_by_time(wallet, cursor, until_ms)
            if not page:
                break
            rows.extend(page)
            next_cursor = max(row.time for row in page) + 1
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            if len(page) < 2_000:
                break
        self._cache.write_fills(wallet, rows)
        end = until_ms if until_ms is not None else (max((row.time for row in rows), default=start))
        return _sync_result("fills", wallet, None, rows, start, end, [])

    async def pull_vault_summaries(self) -> SyncResult:
        """Fetch and cache all vault summaries."""
        rows = await self._client.vault_summaries()
        self._cache.write_vault_summaries(rows)
        return SyncResult(
            kind="vault_summaries",
            entity="all",
            interval=None,
            rows_written=len(rows),
            since_ms=0,
            until_ms=0,
        )

    async def pull_vault_details(self, vault: str) -> SyncResult:
        """Fetch and cache metadata for one vault."""
        details = await self._client.vault_details(vault)
        self._cache.write_vault_details(details)
        return SyncResult(
            kind="vault_details",
            entity=vault,
            interval=None,
            rows_written=1,
            since_ms=0,
            until_ms=0,
        )

    def cache_vault_trades(self, vault: str, rows: list[VaultTrade]) -> SyncResult:
        """Cache already-fetched vault trades.

        Hyperliquid's public info docs expose vault state via `vaultDetails`, but do not
        document a separate historical vault-trade endpoint. This hook lets CLI code cache
        normalized vault trades when they are available from a details payload or fixture.
        """
        self._cache.write_vault_trades(vault, rows)
        return _sync_result("vault", vault, None, rows, 0, 0, [])


def detect_gaps(timestamps: list[int], expected_step_ms: int) -> list[Gap]:
    """Detect gaps larger than the expected step between timestamps."""
    if len(timestamps) < 2:
        return []
    ordered = sorted(set(timestamps))
    gaps: list[Gap] = []
    for previous, current in zip(ordered, ordered[1:], strict=False):
        if current - previous > expected_step_ms:
            gaps.append(
                Gap(
                    start_ms=previous + expected_step_ms,
                    end_ms=current - expected_step_ms,
                    expected_step_ms=expected_step_ms,
                )
            )
    return gaps


def _sync_result(
    kind: str,
    entity: str,
    interval: str | None,
    rows: list[Candle] | list[FundingRate] | list[Fill] | list[VaultTrade],
    since_ms: int,
    until_ms: int,
    gaps: list[Gap],
) -> SyncResult:
    row_times = [_row_time(row) for row in rows]
    return SyncResult(
        kind=kind,
        entity=entity,
        interval=interval,
        rows_written=len(rows),
        since_ms=min(row_times, default=since_ms),
        until_ms=max(row_times, default=until_ms),
        gaps=gaps,
    )


def _row_time(row: Candle | FundingRate | Fill | VaultTrade) -> int:
    if isinstance(row, Candle):
        return row.open_time
    return row.time
