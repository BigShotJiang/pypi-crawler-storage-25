"""Local cache primitives backed by Parquet and DuckDB."""
