"""Parquet and DuckDB cache store."""

from __future__ import annotations

import shutil
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import duckdb
import polars as pl

from hl_research.api.types import (
    Candle,
    Fill,
    FundingRate,
    Interval,
    UniverseAsset,
    VaultDetails,
    VaultSummary,
    VaultTrade,
)
from hl_research.cache.paths import default_cache_dir
from hl_research.cache.schema import (
    ASSET_SCHEMA,
    CANDLE_SCHEMA,
    FILL_SCHEMA,
    FUNDING_SCHEMA,
    VAULT_SUMMARY_SCHEMA,
    VAULT_TRADE_SCHEMA,
    Schema,
    empty_frame,
    polars_schema,
)


@dataclass(frozen=True)
class SyncState:
    """Recorded sync range for one cached dataset."""

    kind: str
    entity: str
    interval: str | None
    since_ms: int
    until_ms: int
    row_count: int
    updated_at: datetime


@dataclass(frozen=True)
class CacheEntry:
    """Summary row for one cached dataset."""

    kind: str
    entity: str
    interval: str | None
    since_ms: int
    until_ms: int
    row_count: int
    size_bytes: int
    updated_at: datetime


class Cache:
    """Local Parquet cache with DuckDB metadata."""

    def __init__(self, root: Path | None = None) -> None:
        self.root = root or default_cache_dir()
        self.data_root = self.root / "data"
        self.meta_path = self.root / "meta.duckdb"
        self.root.mkdir(parents=True, exist_ok=True)
        self.data_root.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def write_assets(self, rows: list[UniverseAsset]) -> None:
        """Persist universe asset metadata into DuckDB."""
        if not rows:
            return
        fetched_at = datetime.now(tz=UTC)
        values = [
            (row.name, row.sz_decimals, row.max_leverage, row.only_isolated, fetched_at)
            for row in rows
        ]
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT OR REPLACE INTO assets
                (name, sz_decimals, max_leverage, only_isolated, fetched_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                values,
            )

    def read_assets(self) -> pl.DataFrame:
        """Read cached universe asset metadata."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT name, sz_decimals, max_leverage, only_isolated
                FROM assets
                ORDER BY name
                """
            ).fetchall()
        if not rows:
            return empty_frame(ASSET_SCHEMA)
        return pl.DataFrame(
            rows,
            schema=["name", "sz_decimals", "max_leverage", "only_isolated"],
            orient="row",
        ).cast(polars_schema(ASSET_SCHEMA))

    def write_vault_summaries(self, rows: list[VaultSummary]) -> None:
        """Persist vault summaries into DuckDB."""
        if not rows:
            return
        fetched_at = datetime.now(tz=UTC)
        values = [
            (
                row.vault_address,
                row.name,
                row.leader,
                row.tvl,
                row.apr,
                row.is_closed,
                fetched_at,
            )
            for row in rows
        ]
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT OR REPLACE INTO vaults
                (address, name, leader, tvl, apr, is_closed, fetched_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                values,
            )

    def write_vault_details(self, row: VaultDetails) -> None:
        """Persist metadata from one vault details response."""
        fetched_at = datetime.now(tz=UTC)
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT tvl, apr FROM vaults WHERE address = ?",
                [row.vault_address],
            ).fetchone()
            tvl = existing[0] if existing is not None else None
            apr = existing[1] if existing is not None else None
            conn.execute(
                """
                INSERT OR REPLACE INTO vaults
                (address, name, leader, tvl, apr, is_closed, fetched_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    row.vault_address,
                    row.name,
                    row.leader,
                    tvl,
                    apr,
                    row.is_closed,
                    fetched_at,
                ],
            )

    def read_vault_summaries(self) -> pl.DataFrame:
        """Read cached vault summaries."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT address, name, leader, tvl, apr, is_closed
                FROM vaults
                ORDER BY tvl DESC NULLS LAST, name
                """
            ).fetchall()
        if not rows:
            return empty_frame(VAULT_SUMMARY_SCHEMA)
        return pl.DataFrame(
            rows,
            schema=["address", "name", "leader", "tvl", "apr", "is_closed"],
            orient="row",
        ).cast(polars_schema(VAULT_SUMMARY_SCHEMA))

    def write_candles(self, asset: str, interval: Interval, rows: list[Candle]) -> None:
        """Write candle rows partitioned by asset, interval, and month."""
        records = [
            {
                "asset": asset,
                "interval": interval,
                "open_time": row.open_time,
                "close_time": row.close_time,
                "open": row.open,
                "high": row.high,
                "low": row.low,
                "close": row.close,
                "volume": row.volume,
                "trade_count": row.trade_count,
            }
            for row in rows
        ]
        frame = _frame(records, CANDLE_SCHEMA)
        self._write_partitioned(
            frame,
            self.data_root / "candles" / f"asset={asset}" / f"interval={interval}",
            "open_time",
            _month_partition,
        )
        self._record_sync("candles", asset, interval, frame, "open_time")

    def write_funding(self, asset: str, rows: list[FundingRate]) -> None:
        """Write funding-rate rows partitioned by asset and year."""
        records = [
            {
                "asset": asset,
                "time": row.time,
                "funding_rate": row.funding_rate,
                "premium": row.premium,
            }
            for row in rows
        ]
        frame = _frame(records, FUNDING_SCHEMA)
        self._write_partitioned(
            frame,
            self.data_root / "funding" / f"asset={asset}",
            "time",
            _year_partition,
        )
        self._record_sync("funding", asset, None, frame, "time")

    def write_fills(self, wallet: str, rows: list[Fill]) -> None:
        """Write wallet fills partitioned by wallet and quarter."""
        records = [_fill_record("wallet", wallet, row) for row in rows]
        frame = _frame(records, FILL_SCHEMA)
        self._write_partitioned(
            frame,
            self.data_root / "fills" / f"wallet={wallet}",
            "time",
            _quarter_partition,
        )
        self._record_sync("fills", wallet, None, frame, "time")

    def write_vault_trades(self, vault: str, rows: list[VaultTrade]) -> None:
        """Write normalized vault trades."""
        records = [_fill_record("vault", vault, row) for row in rows]
        frame = _frame(records, VAULT_TRADE_SCHEMA)
        self._write_partitioned(
            frame,
            self.data_root / "vaults" / f"address={vault}",
            "time",
            _single_partition,
        )
        self._record_sync("vault", vault, None, frame, "time")

    def read_candles(self, asset: str, interval: Interval) -> pl.LazyFrame:
        """Read cached candles as a LazyFrame."""
        path = self.data_root / "candles" / f"asset={asset}" / f"interval={interval}"
        return self._scan(path, CANDLE_SCHEMA)

    def read_funding(self, asset: str) -> pl.LazyFrame:
        """Read cached funding rates as a LazyFrame."""
        path = self.data_root / "funding" / f"asset={asset}"
        return self._scan(path, FUNDING_SCHEMA)

    def read_fills(self, wallet: str) -> pl.LazyFrame:
        """Read cached wallet fills as a LazyFrame."""
        path = self.data_root / "fills" / f"wallet={wallet}"
        return self._scan(path, FILL_SCHEMA)

    def read_vault_trades(self, vault: str) -> pl.LazyFrame:
        """Read cached vault trades as a LazyFrame."""
        path = self.data_root / "vaults" / f"address={vault}"
        return self._scan(path, VAULT_TRADE_SCHEMA)

    def sync_state(self, kind: str, entity: str, interval: str | None = None) -> SyncState | None:
        """Return the recorded sync state for a cached dataset."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT kind, entity, interval, since_ms, until_ms, row_count, updated_at
                FROM sync_state
                WHERE kind = ? AND entity = ? AND interval = ?
                """,
                [kind, entity, _db_interval(interval)],
            ).fetchone()
        if row is None:
            return None
        kind_value, entity_value, interval_value, since_ms, until_ms, row_count, updated_at = row
        return SyncState(
            kind=kind_value,
            entity=entity_value,
            interval=_public_interval(interval_value),
            since_ms=since_ms,
            until_ms=until_ms,
            row_count=row_count,
            updated_at=updated_at,
        )

    def list(self) -> list[CacheEntry]:
        """List cached datasets with metadata and file sizes."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT kind, entity, interval, since_ms, until_ms, row_count, updated_at
                FROM sync_state
                ORDER BY kind, entity, interval
                """
            ).fetchall()
        entries: list[CacheEntry] = []
        for kind, entity, interval, since_ms, until_ms, row_count, updated_at in rows:
            entries.append(
                CacheEntry(
                    kind=kind,
                    entity=entity,
                    interval=_public_interval(interval),
                    since_ms=since_ms,
                    until_ms=until_ms,
                    row_count=row_count,
                    size_bytes=self._dataset_size(kind, entity, interval),
                    updated_at=updated_at,
                )
            )
        return entries

    def clear(self, kind: str | None = None, entity: str | None = None) -> int:
        """Clear cached datasets matching the optional kind/entity scope."""
        entries = [
            entry
            for entry in self.list()
            if (kind is None or entry.kind == kind) and (entity is None or entry.entity == entity)
        ]
        for entry in entries:
            path = self._dataset_path(entry.kind, entry.entity, entry.interval)
            if path.exists():
                shutil.rmtree(path)
        with self._connect() as conn:
            if kind is None and entity is None:
                conn.execute("DELETE FROM sync_state")
            elif kind is None:
                conn.execute("DELETE FROM sync_state WHERE entity = ?", [entity])
            elif entity is None:
                conn.execute("DELETE FROM sync_state WHERE kind = ?", [kind])
            else:
                conn.execute("DELETE FROM sync_state WHERE kind = ? AND entity = ?", [kind, entity])
        return len(entries)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sync_state (
                    kind TEXT NOT NULL,
                    entity TEXT NOT NULL,
                    interval TEXT NOT NULL,
                    since_ms BIGINT NOT NULL,
                    until_ms BIGINT NOT NULL,
                    row_count BIGINT NOT NULL,
                    updated_at TIMESTAMP NOT NULL,
                    PRIMARY KEY (kind, entity, interval)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS assets (
                    name TEXT PRIMARY KEY,
                    sz_decimals INTEGER NOT NULL,
                    max_leverage INTEGER NOT NULL,
                    only_isolated BOOLEAN NOT NULL,
                    fetched_at TIMESTAMP NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS vaults (
                    address TEXT PRIMARY KEY,
                    name TEXT,
                    leader TEXT,
                    tvl DOUBLE,
                    apr DOUBLE,
                    is_closed BOOLEAN,
                    fetched_at TIMESTAMP NOT NULL
                )
                """
            )
            _ensure_column(conn, "vaults", "apr", "DOUBLE")
            _ensure_column(conn, "vaults", "is_closed", "BOOLEAN")

    def _connect(self) -> duckdb.DuckDBPyConnection:
        return duckdb.connect(str(self.meta_path))

    def _scan(self, path: Path, schema: Schema) -> pl.LazyFrame:
        files = sorted(path.glob("*.parquet"))
        if not files:
            return empty_frame(schema).lazy()
        return pl.scan_parquet([str(file) for file in files]).cast(polars_schema(schema))

    def _write_partitioned(
        self,
        frame: pl.DataFrame,
        root: Path,
        time_column: str,
        partition_key: PartitionKey,
    ) -> None:
        if frame.is_empty():
            return
        root.mkdir(parents=True, exist_ok=True)
        keys = frame.select(time_column).to_series().map_elements(partition_key).unique()
        for key in sorted(keys):
            output_path = root / f"{key}.parquet"
            partition = frame.filter(
                pl.col(time_column).map_elements(partition_key, return_dtype=pl.String) == key
            )
            existing = pl.read_parquet(output_path) if output_path.exists() else None
            combined = pl.concat([existing, partition]) if existing is not None else partition
            combined.unique(maintain_order=True).sort(time_column).write_parquet(output_path)

    def _record_sync(
        self,
        kind: str,
        entity: str,
        interval: str | None,
        frame: pl.DataFrame,
        time_column: str,
    ) -> None:
        if frame.is_empty():
            return
        since_ms = int(frame.select(pl.col(time_column).min()).item())
        until_ms = int(frame.select(pl.col(time_column).max()).item())
        row_count = frame.height
        updated_at = datetime.now(tz=UTC)
        previous = self.sync_state(kind, entity, interval)
        if previous is not None:
            since_ms = min(since_ms, previous.since_ms)
            until_ms = max(until_ms, previous.until_ms)
            row_count += previous.row_count
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO sync_state
                (kind, entity, interval, since_ms, until_ms, row_count, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                [kind, entity, _db_interval(interval), since_ms, until_ms, row_count, updated_at],
            )

    def _dataset_size(self, kind: str, entity: str, interval: str | None) -> int:
        path = self._dataset_path(kind, entity, interval)
        if not path.exists():
            return 0
        return sum(file.stat().st_size for file in path.glob("*.parquet"))

    def _dataset_path(self, kind: str, entity: str, interval: str | None) -> Path:
        if kind == "candles":
            return self.data_root / "candles" / f"asset={entity}" / f"interval={interval}"
        if kind == "funding":
            return self.data_root / "funding" / f"asset={entity}"
        if kind == "fills":
            return self.data_root / "fills" / f"wallet={entity}"
        if kind == "vault":
            return self.data_root / "vaults" / f"address={entity}"
        return self.data_root / kind / entity


PartitionKey = Callable[[int], str]


def _frame(records: list[dict[str, object]], schema: Schema) -> pl.DataFrame:
    if not records:
        return empty_frame(schema)
    return pl.DataFrame(records).cast(polars_schema(schema))


def _fill_record(entity_key: str, entity: str, row: Fill) -> dict[str, object]:
    return {
        entity_key: entity,
        "asset": row.coin,
        "time": row.time,
        "side": row.side,
        "price": row.px,
        "size": row.sz,
        "start_position": row.start_position,
        "direction": row.dir,
        "closed_pnl": row.closed_pnl,
        "hash": row.hash,
        "oid": row.oid,
        "tid": row.tid,
        "crossed": row.crossed,
        "fee": row.fee,
        "fee_token": row.fee_token,
        "liquidation": row.liquidation,
    }


def _month_partition(timestamp_ms: int) -> str:
    dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=UTC)
    return f"{dt:%Y-%m}"


def _year_partition(timestamp_ms: int) -> str:
    dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=UTC)
    return f"{dt:%Y}"


def _quarter_partition(timestamp_ms: int) -> str:
    dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=UTC)
    quarter = (dt.month - 1) // 3 + 1
    return f"{dt.year}-Q{quarter}"


def _single_partition(_timestamp_ms: int) -> str:
    return "trades"


def _db_interval(interval: str | None) -> str:
    return interval or ""


def _public_interval(interval: str) -> str | None:
    return interval or None


def _ensure_column(conn: duckdb.DuckDBPyConnection, table: str, column: str, dtype: str) -> None:
    columns = {row[1] for row in conn.execute(f"PRAGMA table_info('{table}')").fetchall()}
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {dtype}")
