"""``hlr wallet`` command group.

Owns argument design, help text, error tone, and output formatting for the
wallet surfaces. Delegates analytics to ``hl_research.analytics``, cache reads
to ``hl_research.cache``, and live state to ``hl_research.api``.
"""

from __future__ import annotations

import asyncio
import sys
from collections.abc import Callable, Coroutine
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Annotated, Any

import polars as pl
import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from hl_research.analytics.types import WrappedReport
from hl_research.analytics.wrapped import build_wrapped
from hl_research.api.info import InfoClient
from hl_research.cache.store import Cache
from hl_research.cli.context import emit_json
from hl_research.cli.context import get as get_ctx
from hl_research.presentation.report import render_wrapped
from hl_research.presentation.tables import (
    account_summary,
    fills_table,
    funding_summary,
    positions_table,
    render,
)
from hl_research.presentation.theme import (
    RICH_STYLE_BODY,
    RICH_STYLE_HAIRLINE,
    RICH_STYLE_HEADER,
    RICH_STYLE_MUTED,
    RICH_STYLE_PNL_DOWN,
    RICH_STYLE_PNL_UP,
)

app = typer.Typer(
    name="wallet",
    help="Inspect wallets, build wrapped reports, list fills and funding.",
    no_args_is_help=True,
)


# Type aliases -----------------------------------------------------------------

WalletArg = Annotated[
    str,
    typer.Argument(
        help="Wallet address. 42-character hex starting with 0x.",
        show_default=False,
    ),
]
SinceOpt = Annotated[
    datetime | None,
    typer.Option(
        "--since",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="Start of range (UTC). Default: 2023-01-01.",
    ),
]
UntilOpt = Annotated[
    datetime | None,
    typer.Option(
        "--until",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="End of range (UTC). Default: now.",
    ),
]
AssetFilterOpt = Annotated[
    str | None,
    typer.Option(
        "--asset",
        help="Filter to a single asset (e.g. BTC).",
    ),
]
OutOpt = Annotated[
    Path | None,
    typer.Option(
        "--out",
        help="Write a standalone HTML report to this path.",
    ),
]
LimitOpt = Annotated[
    int,
    typer.Option(
        "--limit",
        help="Maximum rows to display.",
    ),
]


_DEFAULT_SINCE = datetime(2023, 1, 1, tzinfo=UTC)


# Validation -------------------------------------------------------------------


def _validate_address(value: str) -> str:
    if not value.startswith("0x") or len(value) != 42:
        raise typer.BadParameter(
            f"Invalid wallet address: {value!r}. Expected 42-character hex starting with 0x."
        )
    try:
        int(value[2:], 16)
    except ValueError as exc:
        raise typer.BadParameter(
            f"Invalid wallet address: {value!r}. Non-hex characters in payload."
        ) from exc
    return value.lower()


def _to_ms(dt: datetime | None, default: datetime) -> int:
    value = dt if dt is not None else default
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


def _console(ctx: typer.Context) -> Console:
    cli = get_ctx(ctx)
    return Console(no_color=not cli.use_color, quiet=cli.quiet, highlight=False)


def _run[T](
    console: Console,
    human: bool,
    label: str,
    coro_factory: Callable[[], Coroutine[Any, Any, T]],
) -> T:
    if human and not console.quiet:
        with console.status(label, spinner="line"):
            return asyncio.run(coro_factory())
    return asyncio.run(coro_factory())


# Commands ---------------------------------------------------------------------


@app.command("inspect")
def inspect(ctx: typer.Context, wallet: WalletArg) -> None:
    """Show current account state: equity, margin, open positions, withdrawable."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    wallet_norm = _validate_address(wallet)

    async def _load() -> Any:
        async with InfoClient() as client:
            return await client.clearinghouse_state(wallet_norm)

    state = _run(console, cli.human_output, f"Loading {wallet_norm[:6]}…", _load)

    if cli.json:
        emit_json(state.model_dump(by_alias=True))
        return

    render(console, account_summary(state, wallet=wallet_norm))
    if state.asset_positions:
        console.print()
        render(console, positions_table(state.asset_positions))
    else:
        console.print()
        console.print("[dim]No open positions.[/dim]")


@app.command("wrapped")
def wrapped(
    ctx: typer.Context,
    wallet: WalletArg,
    since: SinceOpt = None,
    until: UntilOpt = None,
    out: OutOpt = None,
) -> None:
    """Build a behavioral wrapped report from cached fills and funding.

    Run `hlr data pull-fills <wallet>` first to populate the cache.
    """
    cli = get_ctx(ctx)
    console = _console(ctx)
    wallet_norm = _validate_address(wallet)
    since_ms = _to_ms(since, _DEFAULT_SINCE)
    until_ms = _to_ms(until, datetime.now(tz=UTC))

    cache = Cache(cli.cache_dir)
    fills_lazy = _load_cached_fills(cache, wallet_norm, since_ms, until_ms)
    fills_count = fills_lazy.select(pl.len()).collect().item()
    if fills_count == 0:
        console.print(
            f"[dim]No cached fills for {wallet_norm[:6]}…{wallet_norm[-4:]} in this window. "
            f"Run `hlr data pull-fills {wallet_norm}` first.[/dim]"
        )
        raise typer.Exit(code=1)

    async def _fetch_funding() -> pl.LazyFrame:
        async with InfoClient() as client:
            payments = await client.user_funding(wallet_norm, since_ms, until_ms)
        return _funding_frame(payments).lazy()

    funding_lazy = _run(console, cli.human_output, "Fetching user funding history", _fetch_funding)

    candles = _load_candles_for_assets(cache, fills_lazy)

    report = build_wrapped(fills_lazy, funding_lazy, candles, wallet_norm)

    if out is not None:
        html = render_wrapped(report)
        out.write_text(html, encoding="utf-8")
        if cli.json:
            emit_json({"path": str(out), "wallet": wallet_norm})
        else:
            console.print(f"Wrote wrapped report to [bold]{out}[/bold]")
        return

    if cli.json:
        emit_json(_report_to_dict(report))
        return

    render(console, _terminal_summary(report))


@app.command("fills")
def fills(
    ctx: typer.Context,
    wallet: WalletArg,
    asset: AssetFilterOpt = None,
    limit: LimitOpt = 50,
    csv: Annotated[
        bool,
        typer.Option("--csv", help="Emit CSV to stdout instead of a formatted table."),
    ] = False,
) -> None:
    """List recent fills for a wallet. Pulled live from the HL info API."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    wallet_norm = _validate_address(wallet)

    async def _load() -> Any:
        async with InfoClient() as client:
            return await client.user_fills(wallet_norm)

    raw = _run(console, cli.human_output, f"Loading fills for {wallet_norm[:6]}…", _load)
    rows = [f for f in raw if asset is None or f.coin == asset.upper()]
    rows = rows[:limit]

    if csv:
        _emit_fills_csv(rows)
        return

    if cli.json:
        emit_json([f.model_dump(by_alias=True) for f in rows])
        return

    if not rows:
        scope = f" for {asset.upper()}" if asset else ""
        console.print(f"[dim]No fills{scope}.[/dim]")
        return

    render(console, fills_table(rows))


@app.command("funding")
def funding(
    ctx: typer.Context,
    wallet: WalletArg,
    since: SinceOpt = None,
    until: UntilOpt = None,
) -> None:
    """Show per-asset funding paid, earned, and net for a wallet."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    wallet_norm = _validate_address(wallet)
    since_ms = _to_ms(since, datetime.now(tz=UTC) - timedelta(days=90))
    until_ms = _to_ms(until, datetime.now(tz=UTC))

    async def _load() -> Any:
        async with InfoClient() as client:
            return await client.user_funding(wallet_norm, since_ms, until_ms)

    payments = _run(console, cli.human_output, f"Loading funding for {wallet_norm[:6]}…", _load)

    if cli.json:
        emit_json([p.model_dump(by_alias=True) for p in payments])
        return

    if not payments:
        console.print("[dim]No funding payments in this window.[/dim]")
        return

    render(console, funding_summary(payments))


# Cache loaders ----------------------------------------------------------------


def _load_cached_fills(cache: Cache, wallet: str, since_ms: int, until_ms: int) -> pl.LazyFrame:
    """Read cached fills for a wallet, filtered to the requested window."""
    return (
        cache.read_fills(wallet)
        .filter(pl.col("time").is_between(since_ms, until_ms, closed="both"))
        .sort("time")
    )


def _load_candles_for_assets(cache: Cache, fills_lazy: pl.LazyFrame) -> dict[str, pl.LazyFrame]:
    """Build the candles dict that ``build_wrapped`` expects.

    Iterates the distinct assets referenced by the cached fills and pulls their
    1h candle history from the cache. Missing assets simply do not appear in
    the dict; the counterfactual handles that case.
    """
    assets = fills_lazy.select(pl.col("asset").unique()).collect().to_series().to_list()
    return {asset: cache.read_candles(asset, "1h") for asset in assets}


# Funding frame ----------------------------------------------------------------


def _funding_frame(payments: list[Any]) -> pl.DataFrame:
    """Convert ``list[FundingPayment]`` to the Polars shape ``build_wrapped`` expects.

    Required columns: ``time`` (int ms), ``asset`` (str), ``usdc`` (float).
    """
    if not payments:
        return pl.DataFrame(
            {"time": [], "asset": [], "usdc": []},
            schema={"time": pl.Int64, "asset": pl.String, "usdc": pl.Float64},
        )
    return pl.DataFrame(
        {
            "time": [p.time for p in payments],
            "asset": [p.delta.coin for p in payments],
            "usdc": [p.delta.usdc for p in payments],
        }
    )


# Terminal summary -------------------------------------------------------------


def _terminal_summary(report: WrappedReport) -> Panel:
    """Compact textual summary when no ``--out`` is supplied."""
    body = Text()
    body.append("WALLET            ", style=RICH_STYLE_MUTED)
    body.append(f"{_short(report.wallet)}\n", style=RICH_STYLE_BODY)
    body.append("PERIOD            ", style=RICH_STYLE_MUTED)
    body.append(
        f"{report.period[0]:%Y-%m-%d} → {report.period[1]:%Y-%m-%d}\n",
        style=RICH_STYLE_BODY,
    )
    body.append("REALIZED PNL      ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_usd(report.total_realized_pnl)}\n",
        style=_pnl_style(report.total_realized_pnl),
    )
    funding_net = report.funding_earned - report.funding_paid
    body.append("FUNDING NET       ", style=RICH_STYLE_MUTED)
    body.append(f"{_usd(funding_net)}\n", style=_pnl_style(funding_net))
    body.append("WIN RATE          ", style=RICH_STYLE_MUTED)
    body.append(f"{report.win_rate * 100:.1f}%\n", style=RICH_STYLE_BODY)
    body.append("TRADES            ", style=RICH_STYLE_MUTED)
    body.append(f"{report.trade_count:,}\n", style=RICH_STYLE_BODY)
    body.append("CLUSTER           ", style=RICH_STYLE_MUTED)
    body.append(f"{report.behavior_cluster.replace('_', ' ')}\n", style=RICH_STYLE_HEADER)
    body.append("                  ", style=RICH_STYLE_MUTED)
    body.append(f"{report.behavior_reason}\n\n", style=RICH_STYLE_MUTED)
    body.append("HOLD vs ACTUAL    ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_usd(report.counterfactual.alpha_vs_hold)}",
        style=_pnl_style(report.counterfactual.alpha_vs_hold),
    )
    body.append("   (pass --out to write the full HTML report)", style=RICH_STYLE_MUTED)

    return Panel(
        body,
        title="wallet wrapped",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def _report_to_dict(report: WrappedReport) -> dict[str, Any]:
    """JSON-friendly view of the wrapped report.

    Polars frames serialize to lists of records; nested dataclasses use asdict.
    """
    data = {
        "wallet": report.wallet,
        "period": [report.period[0].isoformat(), report.period[1].isoformat()],
        "total_realized_pnl": report.total_realized_pnl,
        "total_unrealized_pnl": report.total_unrealized_pnl,
        "funding_paid": report.funding_paid,
        "funding_earned": report.funding_earned,
        "win_rate": report.win_rate,
        "trade_count": report.trade_count,
        "behavior_cluster": report.behavior_cluster,
        "behavior_reason": report.behavior_reason,
        "pnl_by_asset": report.pnl_by_asset.to_dicts(),
        "hour_of_day": report.hour_of_day.to_dicts(),
        "hold_time_dist": report.hold_time_dist.to_dicts(),
        "counterfactual": asdict(report.counterfactual),
        "top_wins": [asdict(f) for f in report.top_wins],
        "top_losses": [asdict(f) for f in report.top_losses],
    }
    return data


# CSV emitters -----------------------------------------------------------------


def _emit_fills_csv(rows: list[Any]) -> None:
    """Emit fill rows as CSV to stdout."""
    writer = sys.stdout
    writer.write("time,asset,side,size,price,fee,closed_pnl,liquidation\n")
    for f in rows:
        writer.write(
            ",".join(
                [
                    str(f.time),
                    f.coin,
                    f.side,
                    f"{f.sz}",
                    f"{f.px}",
                    f"{f.fee}",
                    f"{f.closed_pnl if f.closed_pnl is not None else ''}",
                    "true" if f.liquidation else "false",
                ]
            )
            + "\n"
        )


# Formatters -------------------------------------------------------------------


def _short(addr: str) -> str:
    if addr.startswith("0x") and len(addr) == 42:
        return f"{addr[:6]}…{addr[-4:]}"
    return addr


def _usd(value: float) -> str:
    if value == 0:
        return "$0.00"
    sign = "-" if value < 0 else "+"
    return f"{sign}${abs(value):,.2f}"


def _pnl_style(value: float) -> str:
    if value > 0:
        return RICH_STYLE_PNL_UP
    if value < 0:
        return RICH_STYLE_PNL_DOWN
    return RICH_STYLE_BODY


__all__ = ["app"]
