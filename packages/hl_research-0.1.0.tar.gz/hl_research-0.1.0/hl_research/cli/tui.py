"""``hlr tui`` command entry point."""

from __future__ import annotations

import typer

from hl_research.cli.context import get as get_ctx
from hl_research.tui.app import run as run_app


def launch(ctx: typer.Context) -> None:
    """Launch the hl-research interactive TUI."""
    cli = get_ctx(ctx)
    run_app(cache_dir=cli.cache_dir)


__all__ = ["launch"]
