"""Scan command group."""
