"""``hlr vault`` command group.

Lists cached vaults, ranks them, and inspects a single vault in depth.
Inspect pulls the vault's portfolio history live (the HL info API exposes it
through ``vaultDetails`` rather than as a separately cached time series).
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from dataclasses import asdict
from pathlib import Path
from typing import Annotated, Any

import polars as pl
import typer
from rich.console import Console

from hl_research.analytics.types import VaultAnalysis
from hl_research.analytics.vaults import analyze_vault
from hl_research.api.info import InfoClient
from hl_research.api.types import VaultDetails
from hl_research.cache.store import Cache
from hl_research.cli.context import emit_json
from hl_research.cli.context import get as get_ctx
from hl_research.presentation.report import render_vault
from hl_research.presentation.tables import (
    render,
    vault_asset_breakdown,
    vault_listing,
    vault_metrics_panel,
    vault_summary_panel,
)

app = typer.Typer(
    name="vault",
    help="List, rank, and inspect Hyperliquid vaults.",
    no_args_is_help=True,
)


VaultArg = Annotated[
    str,
    typer.Argument(
        help="Vault address. 42-character hex starting with 0x.",
        show_default=False,
    ),
]
OutOpt = Annotated[
    Path | None,
    typer.Option("--out", help="Write a standalone HTML vault report to this path."),
]
TopOpt = Annotated[
    int,
    typer.Option("--top", help="Maximum rows to display."),
]


_VALID_METRICS: frozenset[str] = frozenset({"tvl", "apr", "name"})


def _validate_address(value: str) -> str:
    if not value.startswith("0x") or len(value) != 42:
        raise typer.BadParameter(
            f"Invalid vault address: {value!r}. Expected 42-character hex starting with 0x."
        )
    try:
        int(value[2:], 16)
    except ValueError as exc:
        raise typer.BadParameter(
            f"Invalid vault address: {value!r}. Non-hex characters in payload."
        ) from exc
    return value.lower()


def _console(ctx: typer.Context) -> Console:
    cli = get_ctx(ctx)
    return Console(no_color=not cli.use_color, quiet=cli.quiet, highlight=False)


def _run[T](
    console: Console,
    human: bool,
    label: str,
    coro_factory: Callable[[], Coroutine[Any, Any, T]],
) -> T:
    if human and not console.quiet:
        with console.status(label, spinner="line"):
            return asyncio.run(coro_factory())
    return asyncio.run(coro_factory())


# Commands ---------------------------------------------------------------------


@app.command("ls")
def ls(
    ctx: typer.Context,
    top: TopOpt = 50,
) -> None:
    """List cached vault summaries."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    cache = Cache(cli.cache_dir)
    frame = cache.read_vault_summaries()

    if frame.is_empty():
        console.print(
            "[dim]No cached vaults. Run `hlr data` integration is pending; "
            "use the Syncer in a script to pull vault summaries.[/dim]"
        )
        raise typer.Exit(code=1)

    if cli.json:
        emit_json(frame.to_dicts())
        return

    render(console, vault_listing(frame.head(top)))


@app.command("rank")
def rank(
    ctx: typer.Context,
    metric: Annotated[
        str,
        typer.Option(
            "--metric",
            help="Ranking metric. v0 supports: tvl, apr, name.",
        ),
    ] = "tvl",
    top: TopOpt = 20,
) -> None:
    """Rank cached vaults by a summary metric.

    Sharpe/return-style ranking requires live equity curves and is not in v0.
    Use `hlr vault inspect` for per-vault performance.
    """
    cli = get_ctx(ctx)
    console = _console(ctx)
    if metric not in _VALID_METRICS:
        raise typer.BadParameter(
            f"Invalid metric: {metric!r}. v0 supports: {', '.join(sorted(_VALID_METRICS))}."
        )

    cache = Cache(cli.cache_dir)
    frame = cache.read_vault_summaries()
    if frame.is_empty():
        console.print("[dim]No cached vaults to rank.[/dim]")
        raise typer.Exit(code=1)

    if metric == "tvl":
        frame = frame.sort(pl.col("tvl"), descending=True, nulls_last=True)
    elif metric == "apr":
        frame = frame.sort(pl.col("apr"), descending=True, nulls_last=True)
    else:
        frame = frame.sort(pl.col("name"), descending=False, nulls_last=True)

    if cli.json:
        emit_json(frame.head(top).to_dicts())
        return

    render(console, vault_listing(frame, top=top))


@app.command("inspect")
def inspect(
    ctx: typer.Context,
    vault: VaultArg,
    out: OutOpt = None,
) -> None:
    """Inspect one vault: equity curve, metrics, asset breakdown, recent trades."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    vault_norm = _validate_address(vault)
    cache = Cache(cli.cache_dir)

    async def _fetch() -> VaultDetails:
        async with InfoClient() as client:
            return await client.vault_details(vault_norm)

    details = _run(console, cli.human_output, f"Loading vault {vault_norm[:6]}…", _fetch)

    equity_curve = _equity_curve_from_details(details)
    trades = _read_trades(cache, vault_norm)
    followers_frame = _followers_frame(details)

    analysis = analyze_vault(
        vault=vault_norm,
        equity_curve=equity_curve,
        trades=trades,
        followers=followers_frame,
        name=details.name,
        leader=details.leader,
        tvl=None,
    )

    if out is not None:
        html = render_vault(analysis)
        out.write_text(html, encoding="utf-8")
        if cli.json:
            emit_json({"path": str(out), "vault": vault_norm})
        else:
            console.print(f"Wrote vault report to [bold]{out}[/bold]")
        return

    if cli.json:
        emit_json(_analysis_to_dict(analysis))
        return

    render(console, vault_summary_panel(analysis))
    console.print()
    render(console, vault_metrics_panel(analysis.metrics))
    if not analysis.asset_breakdown.is_empty():
        console.print()
        render(console, vault_asset_breakdown(analysis.asset_breakdown))
    if analysis.trade_list.is_empty():
        console.print(
            "\n[dim]No cached vault trades. Cache them with "
            "`Syncer.cache_vault_trades(...)` from a script to populate this view.[/dim]"
        )


# Helpers ----------------------------------------------------------------------


def _equity_curve_from_details(details: VaultDetails) -> pl.DataFrame:
    """Flatten ``VaultDetails.portfolio[*].account_value_history`` into one frame.

    Each portfolio entry can carry its own time series. We concatenate them all,
    deduplicate by timestamp, and keep the latest value per timestamp.
    """
    records: list[dict[str, float]] = []
    for entry in details.portfolio:
        for time_ms, equity in entry.account_value_history:
            records.append({"time": int(time_ms), "equity": float(equity)})
    if not records:
        return pl.DataFrame(schema={"time": pl.Int64, "equity": pl.Float64})
    frame = pl.DataFrame(records)
    return frame.unique(subset=["time"], keep="last").sort("time")


def _read_trades(cache: Cache, vault: str) -> pl.DataFrame:
    """Read cached vault trades. Returns an empty frame if nothing is cached."""
    lazy = cache.read_vault_trades(vault)
    return lazy.collect()


def _followers_frame(details: VaultDetails) -> pl.DataFrame:
    if not details.followers:
        return pl.DataFrame()
    return pl.DataFrame(
        {
            "user": [f.user for f in details.followers],
            "vault_equity": [f.vault_equity for f in details.followers],
            "pnl": [f.pnl for f in details.followers],
            "all_time_pnl": [f.all_time_pnl for f in details.followers],
            "days_following": [f.days_following for f in details.followers],
        }
    )


def _analysis_to_dict(analysis: VaultAnalysis) -> dict[str, Any]:
    return {
        "vault": analysis.vault,
        "name": analysis.name,
        "leader": analysis.leader,
        "tvl": analysis.tvl,
        "depositor_count": analysis.depositor_count,
        "metrics": asdict(analysis.metrics),
        "asset_breakdown": analysis.asset_breakdown.to_dicts(),
        "equity_curve": analysis.equity_curve.to_dicts(),
        "trade_list": analysis.trade_list.head(50).to_dicts(),
    }


__all__ = ["app"]
