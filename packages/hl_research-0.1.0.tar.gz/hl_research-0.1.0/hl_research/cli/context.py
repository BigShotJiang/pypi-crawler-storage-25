"""Typed CLI context.

Replaces the untyped `ctx.obj` dict used in the bootstrap. Every subcommand
module reads its global flag state through this dataclass.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import typer


@dataclass(frozen=True)
class CliContext:
    """Global CLI flag state, populated once in the root callback."""

    cache_dir: Path | None
    quiet: bool
    verbose: bool
    json: bool
    no_color: bool

    @property
    def use_color(self) -> bool:
        """Resolved color preference. Honors NO_COLOR env per spec."""
        return not (self.no_color or bool(os.environ.get("NO_COLOR")))

    @property
    def human_output(self) -> bool:
        """True when the user wants formatted output, not JSON."""
        return not self.json


def get(ctx: typer.Context) -> CliContext:
    """Fetch the typed context from a Typer context object."""
    obj = ctx.ensure_object(dict)
    cli_ctx = obj.get("cli_context")
    if cli_ctx is None:
        raise RuntimeError(
            "CliContext missing. The root Typer callback must run before subcommands."
        )
    return cli_ctx  # type: ignore[no-any-return]


def set_(ctx: typer.Context, cli_ctx: CliContext) -> None:
    """Install the typed context on the Typer context object."""
    obj = ctx.ensure_object(dict)
    obj["cli_context"] = cli_ctx


def _json_default(value: Any) -> Any:
    """Fall-through serializer for objects ``json.dumps`` would otherwise reject."""
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if hasattr(value, "model_dump"):
        return value.model_dump(by_alias=True)
    return str(value)


def emit_json(payload: Any) -> None:
    """Write pipeable JSON to stdout. No ANSI, no terminal detection.

    Use this for every ``--json`` mode CLI output. ``rich.Console.print_json``
    colorizes even when ``no_color=True`` is set on the console, which breaks
    ``hlr --json ... | jq`` and similar pipelines.
    """
    sys.stdout.write(json.dumps(payload, indent=2, default=_json_default))
    sys.stdout.write("\n")
