"""Typer root command for hl-research.

Subcommand groups are added in their own modules and attached here. This file
owns the global flag surface and the version command. Subcommand wiring is
intentionally minimal until each command group lands.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from hl_research.__version__ import __version__
from hl_research.cli import backtest as backtest_cli
from hl_research.cli import data as data_cli
from hl_research.cli import funding as funding_cli
from hl_research.cli import tui as tui_cli
from hl_research.cli import vault as vault_cli
from hl_research.cli import wallet as wallet_cli
from hl_research.cli.context import CliContext
from hl_research.cli.context import set_ as set_context

app = typer.Typer(
    name="hl-research",
    help="Quantitative research toolkit for Hyperliquid.",
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode=None,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"hl-research {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    cache_dir: Annotated[
        Path | None,
        typer.Option(
            "--cache-dir",
            envvar="HLR_CACHE_DIR",
            help="Override the cache directory. Defaults to the XDG cache path.",
        ),
    ] = None,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-q", help="Suppress non-error output."),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Emit debug-level logs."),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Emit machine-readable JSON instead of formatted output."),
    ] = False,
    no_color: Annotated[
        bool,
        typer.Option("--no-color", help="Disable color output. Honors NO_COLOR env."),
    ] = False,
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Print the version and exit.",
        ),
    ] = None,
) -> None:
    """Quantitative research toolkit for Hyperliquid."""
    set_context(
        ctx,
        CliContext(
            cache_dir=cache_dir,
            quiet=quiet,
            verbose=verbose,
            json=json_output,
            no_color=no_color,
        ),
    )


app.add_typer(data_cli.app, name="data")
app.add_typer(wallet_cli.app, name="wallet")
app.add_typer(funding_cli.app, name="funding")
app.add_typer(vault_cli.app, name="vault")
app.add_typer(backtest_cli.app, name="backtest")
app.command(name="tui")(tui_cli.launch)

# Future subcommand groups attach here, in CLI-surface order:
# from hl_research.cli import scan
# app.add_typer(scan.app, name="scan")


if __name__ == "__main__":
    app()
