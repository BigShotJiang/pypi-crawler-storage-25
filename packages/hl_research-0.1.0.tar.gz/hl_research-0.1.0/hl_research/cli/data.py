"""``hlr data`` command group.

Owns the user-facing surface for cache management: argument design, help text,
error messages, output formatting. Delegates all data work to
``hl_research.cache`` and ``hl_research.api``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Annotated, Any

import typer
from rich.console import Console

from hl_research.api.info import InfoClient
from hl_research.api.types import Interval
from hl_research.cache.store import Cache, CacheEntry
from hl_research.cache.sync import Syncer, SyncResult
from hl_research.cli.context import emit_json
from hl_research.cli.context import get as get_ctx
from hl_research.presentation.tables import cache_listing, cache_summary, render

app = typer.Typer(
    name="data",
    help="Pull, inspect, and manage the local Hyperliquid data cache.",
    no_args_is_help=True,
)


# Type aliases -----------------------------------------------------------------

AssetArg = Annotated[
    str,
    typer.Argument(
        help="Asset name as listed by HL (e.g. BTC, ETH, SOL).",
        show_default=False,
    ),
]
WalletArg = Annotated[
    str,
    typer.Argument(
        help="Wallet address. 42-character hex starting with 0x.",
        show_default=False,
    ),
]
VaultArg = Annotated[
    str,
    typer.Argument(
        help="Vault address. 42-character hex starting with 0x.",
        show_default=False,
    ),
]
IntervalOpt = Annotated[
    str,
    typer.Option(
        "--interval",
        help="Candle interval. One of: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 8h, 12h, 1d, 3d, 1w, 1M.",
    ),
]
SinceOpt = Annotated[
    datetime | None,
    typer.Option(
        "--since",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="Start of range (UTC). Default: 2023-01-01.",
    ),
]
UntilOpt = Annotated[
    datetime | None,
    typer.Option(
        "--until",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="End of range (UTC). Default: now.",
    ),
]


# Validation -------------------------------------------------------------------


_VALID_INTERVALS: frozenset[str] = frozenset(
    {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "8h", "12h", "1d", "3d", "1w", "1M"}
)
_DEFAULT_SINCE = datetime(2023, 1, 1, tzinfo=UTC)


def _validate_asset(name: str) -> str:
    """Normalize and validate an asset symbol."""
    if not name:
        raise typer.BadParameter("Asset name is required.")
    if not name.replace("-", "").replace("_", "").isalnum():
        raise typer.BadParameter(
            f"Invalid asset name: {name!r}. Expected an alphanumeric symbol like BTC."
        )
    return name.upper()


def _validate_address(value: str, *, kind: str) -> str:
    """Validate a 0x-prefixed 42-character hex address."""
    if not value.startswith("0x") or len(value) != 42:
        raise typer.BadParameter(
            f"Invalid {kind} address: {value!r}. Expected 42-character hex starting with 0x."
        )
    try:
        int(value[2:], 16)
    except ValueError as exc:
        raise typer.BadParameter(
            f"Invalid {kind} address: {value!r}. Non-hex characters in payload."
        ) from exc
    return value.lower()


def _validate_interval(value: str) -> Interval:
    if value not in _VALID_INTERVALS:
        raise typer.BadParameter(
            f"Invalid interval: {value!r}. Valid intervals: {', '.join(sorted(_VALID_INTERVALS))}."
        )
    return value  # type: ignore[return-value]


def _to_ms(dt: datetime | None, default: datetime) -> int:
    """Convert an aware-or-naive datetime to UTC ms-epoch. Naive treated as UTC."""
    value = dt if dt is not None else default
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


def _console(ctx: typer.Context) -> Console:
    cli = get_ctx(ctx)
    return Console(no_color=not cli.use_color, quiet=cli.quiet, highlight=False)


# Commands ---------------------------------------------------------------------


@app.command("pull")
def pull(
    ctx: typer.Context,
    asset: AssetArg,
    interval: IntervalOpt = "1h",
    since: SinceOpt = None,
    until: UntilOpt = None,
) -> None:
    """Pull candle history for one asset. Resumes from last cached candle."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    interval_norm = _validate_interval(interval)
    since_ms = _to_ms(since, _DEFAULT_SINCE)
    until_ms = _to_ms(until, datetime.now(tz=UTC))

    async def _run() -> SyncResult:
        async with InfoClient() as client:
            syncer = Syncer(client, Cache(cli.cache_dir))
            return await syncer.pull_candles(asset_norm, interval_norm, since_ms, until_ms)

    label = f"Pulling {asset_norm} {interval_norm} candles"
    result = _run_with_status(console, cli.human_output, label, _run)
    _emit_sync_result(console, cli.json, result)


@app.command("pull-funding")
def pull_funding(
    ctx: typer.Context,
    asset: AssetArg,
    since: SinceOpt = None,
    until: UntilOpt = None,
) -> None:
    """Pull funding-rate history for one asset."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    since_ms = _to_ms(since, _DEFAULT_SINCE)
    until_ms = _to_ms(until, datetime.now(tz=UTC)) if until is not None else None

    async def _run() -> SyncResult:
        async with InfoClient() as client:
            syncer = Syncer(client, Cache(cli.cache_dir))
            return await syncer.pull_funding(asset_norm, since_ms, until_ms)

    label = f"Pulling {asset_norm} funding rates"
    result = _run_with_status(console, cli.human_output, label, _run)
    _emit_sync_result(console, cli.json, result)


@app.command("pull-fills")
def pull_fills(
    ctx: typer.Context,
    wallet: WalletArg,
    since: SinceOpt = None,
    until: UntilOpt = None,
) -> None:
    """Pull per-wallet fill history."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    wallet_norm = _validate_address(wallet, kind="wallet")
    since_ms = _to_ms(since, _DEFAULT_SINCE)
    until_ms = _to_ms(until, datetime.now(tz=UTC)) if until is not None else None

    async def _run() -> SyncResult:
        async with InfoClient() as client:
            syncer = Syncer(client, Cache(cli.cache_dir))
            return await syncer.pull_fills(wallet_norm, since_ms, until_ms)

    label = f"Pulling fills for {wallet_norm[:6]}…{wallet_norm[-4:]}"
    result = _run_with_status(console, cli.human_output, label, _run)
    _emit_sync_result(console, cli.json, result)


@app.command("pull-vault")
def pull_vault(
    ctx: typer.Context,
    vault: VaultArg,
) -> None:
    """Pull trade history for a vault. Arrives in Phase 5."""
    _validate_address(vault, kind="vault")
    console = _console(ctx)
    console.print(
        "[dim]Vault trade sync is not yet implemented. The HL info API does not "
        "expose a single endpoint for vault trade history; ingestion lands in "
        "Phase 5 alongside vault analytics.[/dim]"
    )
    raise typer.Exit(code=1)


@app.command("ls")
def ls(ctx: typer.Context) -> None:
    """List cached datasets with row counts, date ranges, and file sizes."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    entries = Cache(cli.cache_dir).list()

    if cli.json:
        payload = [_cache_entry_to_dict(entry) for entry in entries]
        emit_json(payload)
        return

    if not entries:
        console.print("[dim]No cached datasets. Run `hlr data pull <asset>` to start.[/dim]")
        raise typer.Exit(code=0)

    render(console, cache_listing(entries))


@app.command("info")
def info(ctx: typer.Context) -> None:
    """Show cache directory, total size, file count, and last sync time."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    cache = Cache(cli.cache_dir)
    summary = _build_cache_info(cache)

    if cli.json:
        emit_json(
            {
                "cache_dir": summary.cache_dir,
                "total_bytes": summary.total_bytes,
                "file_count": summary.file_count,
                "dataset_count": summary.dataset_count,
                "last_sync": summary.last_sync.isoformat() if summary.last_sync else None,
            }
        )
        return

    render(console, cache_summary(summary))


@app.command("clear")
def clear(
    ctx: typer.Context,
    asset: Annotated[
        str | None,
        typer.Option("--asset", help="Clear only this asset's or wallet's data."),
    ] = None,
    kind: Annotated[
        str | None,
        typer.Option(
            "--kind",
            help="Clear only one kind: candles, funding, fills, or vault.",
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt."),
    ] = False,
) -> None:
    """Clear cached data. Requires explicit scope; clearing everything must be opted in."""
    cli = get_ctx(ctx)
    console = _console(ctx)

    if asset is None and kind is None:
        raise typer.BadParameter(
            "Specify at least one of --asset or --kind. Clearing the entire cache must be explicit."
        )

    valid_kinds = {"candles", "funding", "fills", "vault"}
    if kind is not None and kind not in valid_kinds:
        raise typer.BadParameter(
            f"Invalid --kind {kind!r}. Choose one of: {', '.join(sorted(valid_kinds))}."
        )

    entity_norm: str | None = None
    if asset is not None:
        if asset.startswith("0x"):
            entity_norm = _validate_address(asset, kind="entity")
        else:
            entity_norm = _validate_asset(asset)

    target_parts: list[str] = []
    if kind:
        target_parts.append(f"kind={kind}")
    if entity_norm:
        target_parts.append(f"entity={entity_norm}")
    target = " and ".join(target_parts) or "everything"

    if not yes:
        confirmed = typer.confirm(f"Clear cached data for {target}?")
        if not confirmed:
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(code=0)

    removed = Cache(cli.cache_dir).clear(kind=kind, entity=entity_norm)
    if cli.json:
        emit_json({"removed_datasets": removed, "scope": target})
        return
    console.print(f"Cleared {removed} dataset(s) matching {target}.")


# Helpers ----------------------------------------------------------------------


@dataclass(frozen=True)
class _CacheInfo:
    cache_dir: str
    total_bytes: int
    file_count: int
    dataset_count: int
    last_sync: datetime | None


def _build_cache_info(cache: Cache) -> _CacheInfo:
    """Compute filesystem stats from the cache root. Local to the CLI for now."""
    data_root = cache.data_root
    files = list(data_root.rglob("*.parquet")) if data_root.exists() else []
    total = sum(file.stat().st_size for file in files)

    entries = cache.list()
    last_sync = max((entry.updated_at for entry in entries), default=None)

    return _CacheInfo(
        cache_dir=str(cache.root),
        total_bytes=total,
        file_count=len(files),
        dataset_count=len(entries),
        last_sync=last_sync,
    )


def _cache_entry_to_dict(entry: CacheEntry) -> dict[str, object]:
    payload = asdict(entry)
    payload["updated_at"] = entry.updated_at.isoformat()
    return payload


def _run_with_status(
    console: Console,
    human: bool,
    label: str,
    coro_factory: Callable[[], Coroutine[Any, Any, SyncResult]],
) -> SyncResult:
    """Run an async sync operation with a status spinner in human mode."""
    if human and not console.quiet:
        with console.status(label, spinner="line"):
            return asyncio.run(coro_factory())
    return asyncio.run(coro_factory())


def _emit_sync_result(console: Console, as_json: bool, result: SyncResult) -> None:
    """Print a SyncResult to terminal or JSON."""
    if as_json:
        emit_json(
            {
                "kind": result.kind,
                "entity": result.entity,
                "interval": result.interval,
                "rows_written": result.rows_written,
                "since_ms": result.since_ms,
                "until_ms": result.until_ms,
                "gap_count": len(result.gaps),
            }
        )
        return

    since = _ms_to_label(result.since_ms)
    until = _ms_to_label(result.until_ms)
    gap_note = f", {len(result.gaps)} gap(s)" if result.gaps else ""
    console.print(
        f"Synced {result.rows_written:,} row(s) for {result.kind}:{result.entity}"
        + (f" {result.interval}" if result.interval else "")
        + f"  [dim]{since} → {until}{gap_note}[/dim]"
    )


def _ms_to_label(ms: int) -> str:
    if ms <= 0:
        return "—"
    return datetime.fromtimestamp(ms / 1000, tz=UTC).strftime("%Y-%m-%d")


__all__ = ["app"]
