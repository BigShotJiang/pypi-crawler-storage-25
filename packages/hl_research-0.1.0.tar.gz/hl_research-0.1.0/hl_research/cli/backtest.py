"""``hlr backtest`` command group.

Loads user-provided strategy files, drives the backtest engine, and renders
results. Argument design, parameter parsing, and output formatting live here;
the engine and analytics live in ``hl_research.backtest``.
"""

from __future__ import annotations

import importlib.util
import inspect
import re
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Annotated, Any

import polars as pl
import typer
from rich.console import Console

from hl_research.api.types import Interval
from hl_research.backtest.engine import BacktestData, BacktestResult, run_backtest
from hl_research.backtest.optimizer import (
    ChoiceDistribution,
    Distribution,
    OptimizationResult,
    grid_search,
    random_search,
)
from hl_research.backtest.strategy import ParamValue, Strategy
from hl_research.backtest.walkforward import WalkForwardResult, walk_forward
from hl_research.cache.store import Cache
from hl_research.cli.context import emit_json
from hl_research.cli.context import get as get_ctx
from hl_research.presentation.report import render_backtest
from hl_research.presentation.tables import (
    backtest_summary,
    equity_sparkline_panel,
    optimization_table,
    render,
    walk_forward_table,
)

app = typer.Typer(
    name="backtest",
    help="Run, optimize, and walk-forward backtest a strategy file.",
    no_args_is_help=True,
)


# Type aliases -----------------------------------------------------------------

StrategyArg = Annotated[
    Path,
    typer.Argument(
        help="Path to a Python file containing a Strategy subclass.",
        show_default=False,
        exists=True,
        dir_okay=False,
        readable=True,
    ),
]
AssetOpt = Annotated[
    str,
    typer.Option("--asset", help="Asset to backtest against (e.g. BTC)."),
]
IntervalOpt = Annotated[
    str,
    typer.Option("--interval", help="Candle interval. Default 1h."),
]
SinceOpt = Annotated[
    datetime | None,
    typer.Option(
        "--since",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="Start of range (UTC). Default: earliest cached candle.",
    ),
]
UntilOpt = Annotated[
    datetime | None,
    typer.Option(
        "--until",
        formats=["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"],
        help="End of range (UTC). Default: latest cached candle.",
    ),
]
CashOpt = Annotated[
    float,
    typer.Option("--initial-cash", help="Starting cash in USD. Default 100,000."),
]
OutOpt = Annotated[
    Path | None,
    typer.Option("--out", help="Write a standalone HTML backtest report to this path."),
]
ParamOpt = Annotated[
    list[str] | None,
    typer.Option(
        "--param",
        help=(
            "Parameter sweep, repeatable. Syntax: 'name:start..end:step' for numeric "
            "grids, 'name:a,b,c' for categorical choices."
        ),
    ),
]
MetricOpt = Annotated[
    str,
    typer.Option(
        "--metric",
        help="Metric to optimize. One of: sharpe, sortino, calmar, total_return.",
    ),
]
WindowOpt = Annotated[
    str,
    typer.Option(
        "--window",
        help="Walk-forward window size, e.g. 90d, 30d, 12h.",
    ),
]
StepOpt = Annotated[
    str,
    typer.Option(
        "--step",
        help="Walk-forward step size, e.g. 30d, 7d.",
    ),
]


_VALID_INTERVALS: frozenset[str] = frozenset(
    {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "8h", "12h", "1d", "3d", "1w", "1M"}
)
_VALID_METRICS: frozenset[str] = frozenset(
    {"sharpe", "sortino", "calmar", "total_return", "profit_factor", "hit_rate"}
)


# Validation -------------------------------------------------------------------


def _validate_asset(name: str) -> str:
    if not name or not name.replace("-", "").replace("_", "").isalnum():
        raise typer.BadParameter(
            f"Invalid asset name: {name!r}. Expected an alphanumeric symbol like BTC."
        )
    return name.upper()


def _validate_interval(value: str) -> Interval:
    if value not in _VALID_INTERVALS:
        raise typer.BadParameter(
            f"Invalid interval: {value!r}. Valid: {', '.join(sorted(_VALID_INTERVALS))}."
        )
    return value  # type: ignore[return-value]


def _validate_metric(value: str) -> str:
    if value not in _VALID_METRICS:
        raise typer.BadParameter(
            f"Invalid metric: {value!r}. Choose one of: {', '.join(sorted(_VALID_METRICS))}."
        )
    return value


def _console(ctx: typer.Context) -> Console:
    cli = get_ctx(ctx)
    return Console(no_color=not cli.use_color, quiet=cli.quiet, highlight=False)


# Strategy loader --------------------------------------------------------------


def _load_strategy(path: Path) -> tuple[type[Strategy], str]:
    """Import a strategy file and return its Strategy subclass and display name."""
    module_name = f"_hlr_user_strategy_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise typer.BadParameter(f"Could not load strategy file: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        raise typer.BadParameter(f"Strategy file failed to import: {exc}") from exc

    candidates = [
        cls
        for _name, cls in inspect.getmembers(module, inspect.isclass)
        if cls is not Strategy and issubclass(cls, Strategy) and cls.__module__ == module_name
    ]
    if not candidates:
        raise typer.BadParameter(
            f"No Strategy subclass found in {path.name}. "
            f"Define `class MyStrategy(Strategy):` in the file."
        )
    if len(candidates) > 1:
        names = ", ".join(c.__name__ for c in candidates)
        raise typer.BadParameter(
            f"Multiple Strategy subclasses in {path.name}: {names}. Keep one per file for now."
        )
    return candidates[0], candidates[0].__name__


# Data loading -----------------------------------------------------------------


def _load_backtest_data(
    cache: Cache,
    asset: str,
    interval: Interval,
    since: datetime | None,
    until: datetime | None,
) -> BacktestData:
    """Pull candles and funding for one asset from the cache into a BacktestData."""
    candles_lazy = cache.read_candles(asset, interval)
    candles = candles_lazy.collect()
    if candles.is_empty():
        raise typer.BadParameter(
            f"No cached candles for {asset} {interval}. "
            f"Run `hlr data pull {asset} --interval {interval}` first."
        )

    funding = cache.read_funding(asset).collect()
    if not funding.is_empty():
        funding = funding.with_columns(pl.lit(asset).alias("asset"))

    since_ms = _to_ms(since)
    until_ms = _to_ms(until)
    if since_ms is not None:
        candles = candles.filter(pl.col("open_time") >= since_ms)
        if not funding.is_empty():
            funding = funding.filter(pl.col("time") >= since_ms)
    if until_ms is not None:
        candles = candles.filter(pl.col("open_time") <= until_ms)
        if not funding.is_empty():
            funding = funding.filter(pl.col("time") <= until_ms)

    if candles.is_empty():
        raise typer.BadParameter(
            f"No cached candles for {asset} {interval} in the requested window."
        )

    return BacktestData(candles=candles, funding=funding)


def _to_ms(dt: datetime | None) -> int | None:
    if dt is None:
        return None
    value = dt if dt.tzinfo else dt.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


# Parameter parsing ------------------------------------------------------------


_NUMBER = r"-?\d+(?:\.\d+)?"
_PARAM_RANGE = re.compile(
    rf"^(?P<name>[A-Za-z_][\w]*):(?P<start>{_NUMBER})\.\.(?P<end>{_NUMBER})"
    rf"(?::(?P<step>{_NUMBER}))?$"
)
_PARAM_CHOICE = re.compile(r"^(?P<name>[A-Za-z_][\w]*):(?P<values>.+)$")


def _parse_param_grid(specs: list[str]) -> dict[str, list[ParamValue]]:
    """Parse repeated ``--param`` flags into a grid for ``grid_search``.

    Syntax:
      lookback:10..100:5     → [10, 15, ..., 100]
      threshold:0.1..0.5:0.1 → [0.1, 0.2, ..., 0.5]
      mode:a,b,c             → ["a", "b", "c"]
    """
    grid: dict[str, list[ParamValue]] = {}
    for spec in specs:
        match_range = _PARAM_RANGE.match(spec)
        if match_range:
            name = match_range["name"]
            start = float(match_range["start"])
            end = float(match_range["end"])
            step = float(match_range["step"]) if match_range["step"] else 1.0
            if step <= 0:
                raise typer.BadParameter(f"Param step must be positive: {spec!r}")
            values: list[ParamValue] = []
            cursor = start
            while cursor <= end + 1e-9:
                values.append(int(cursor) if cursor.is_integer() else round(cursor, 6))
                cursor += step
            grid[name] = values
            continue

        match_choice = _PARAM_CHOICE.match(spec)
        if match_choice:
            name = match_choice["name"]
            raw_values = [v.strip() for v in match_choice["values"].split(",") if v.strip()]
            if len(raw_values) < 2:
                raise typer.BadParameter(
                    f"Categorical param needs >=2 values: {spec!r}. "
                    f"Use 'name:a,b,c' or 'name:start..end:step'."
                )
            grid[name] = [_coerce_value(v) for v in raw_values]
            continue

        raise typer.BadParameter(
            f"Could not parse --param {spec!r}. Expected 'name:start..end:step' or 'name:a,b,c'."
        )
    return grid


def _coerce_value(raw: str) -> ParamValue:
    """Coerce a string to int → float → str (in that order)."""
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    if raw.lower() in {"true", "false"}:
        return raw.lower() == "true"
    return raw


def _grid_as_distribution(grid: dict[str, list[ParamValue]]) -> dict[str, Distribution]:
    """Wrap each grid axis as a ChoiceDistribution for random_search."""
    return {name: ChoiceDistribution(values=list(values)) for name, values in grid.items()}


# Duration parsing -------------------------------------------------------------


_DURATION_RE = re.compile(r"^(?P<n>\d+(?:\.\d+)?)(?P<unit>[smhdw])$")


def _parse_duration(value: str) -> timedelta:
    match = _DURATION_RE.match(value.strip())
    if not match:
        raise typer.BadParameter(f"Invalid duration: {value!r}. Use forms like 90d, 12h, 30m, 1w.")
    n = float(match["n"])
    unit = match["unit"]
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 86400 * 7}
    return timedelta(seconds=n * units[unit])


# Commands ---------------------------------------------------------------------


@app.command("run")
def run(
    ctx: typer.Context,
    strategy_path: StrategyArg,
    asset: AssetOpt = "BTC",
    interval: IntervalOpt = "1h",
    since: SinceOpt = None,
    until: UntilOpt = None,
    initial_cash: CashOpt = 100_000.0,
    out: OutOpt = None,
) -> None:
    """Run one backtest of a strategy file on one asset."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    interval_norm = _validate_interval(interval)
    strategy_cls, strategy_name = _load_strategy(strategy_path)

    cache = Cache(cli.cache_dir)
    data = _load_backtest_data(cache, asset_norm, interval_norm, since, until)

    result = run_backtest(strategy_cls, data, initial_cash=initial_cash)

    if out is not None:
        html = render_backtest(result, strategy_name=strategy_name, asset=asset_norm)
        out.write_text(html, encoding="utf-8")
        if cli.json:
            emit_json({"path": str(out), "strategy": strategy_name})
        else:
            console.print(f"Wrote backtest report to [bold]{out}[/bold]")
        return

    if cli.json:
        emit_json(_result_to_dict(result, strategy_name=strategy_name, asset=asset_norm))
        return

    render(console, backtest_summary(result, strategy_name=strategy_name, asset=asset_norm))
    console.print()
    render(console, equity_sparkline_panel(result.equity_curve))


@app.command("optimize")
def optimize(
    ctx: typer.Context,
    strategy_path: StrategyArg,
    param: ParamOpt = None,
    asset: AssetOpt = "BTC",
    interval: IntervalOpt = "1h",
    since: SinceOpt = None,
    until: UntilOpt = None,
    initial_cash: CashOpt = 100_000.0,
    metric: MetricOpt = "sharpe",
    random_trials: Annotated[
        int,
        typer.Option(
            "--random",
            help="If >0, run random search with this many trials instead of grid.",
        ),
    ] = 0,
    seed: Annotated[
        int,
        typer.Option("--seed", help="Random seed for --random search."),
    ] = 0,
) -> None:
    """Sweep parameters via grid or random search."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    interval_norm = _validate_interval(interval)
    metric_norm = _validate_metric(metric)

    if not param:
        raise typer.BadParameter("At least one --param is required.")

    strategy_cls, strategy_name = _load_strategy(strategy_path)
    grid = _parse_param_grid(param or [])

    cache = Cache(cli.cache_dir)
    data = _load_backtest_data(cache, asset_norm, interval_norm, since, until)

    if random_trials > 0:
        opt_result = random_search(
            strategy_cls,
            _grid_as_distribution(grid),
            random_trials,
            data,
            metric=metric_norm,
            seed=seed,
            initial_cash=initial_cash,
        )
    else:
        opt_result = grid_search(
            strategy_cls,
            grid,
            data,
            metric=metric_norm,
            initial_cash=initial_cash,
        )

    if cli.json:
        emit_json(_opt_to_dict(opt_result, strategy_name=strategy_name))
        return

    console.print(
        f"[bold]{strategy_name}[/bold] · {asset_norm} {interval_norm} · "
        f"{len(opt_result.runs)} runs · best {metric_norm}={opt_result.best.metric_value:.4f}"
    )
    console.print()
    render(console, optimization_table(opt_result))


@app.command("walk-forward")
def walk_forward_cmd(
    ctx: typer.Context,
    strategy_path: StrategyArg,
    window: WindowOpt,
    step: StepOpt,
    asset: AssetOpt = "BTC",
    interval: IntervalOpt = "1h",
    since: SinceOpt = None,
    until: UntilOpt = None,
    initial_cash: CashOpt = 100_000.0,
) -> None:
    """Run a rolling-window walk-forward analysis."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    interval_norm = _validate_interval(interval)
    window_td = _parse_duration(window)
    step_td = _parse_duration(step)

    strategy_cls, strategy_name = _load_strategy(strategy_path)
    cache = Cache(cli.cache_dir)
    data = _load_backtest_data(cache, asset_norm, interval_norm, since, until)

    wf_result = walk_forward(
        strategy_cls,
        params={},
        data=data,
        window=window_td,
        step=step_td,
        initial_cash=initial_cash,
    )

    if cli.json:
        emit_json(_wf_to_dict(wf_result, strategy_name=strategy_name))
        return

    if not wf_result.windows:
        console.print(
            "[dim]No walk-forward windows produced. "
            "Try a smaller --window or pull more candles first.[/dim]"
        )
        raise typer.Exit(code=1)

    console.print(
        f"[bold]{strategy_name}[/bold] · {asset_norm} {interval_norm} · "
        f"{len(wf_result.windows)} window(s) · {window} window / {step} step"
    )
    console.print()
    render(console, walk_forward_table(wf_result))


# JSON serializers -------------------------------------------------------------


def _result_to_dict(result: BacktestResult, *, strategy_name: str, asset: str) -> dict[str, Any]:
    m = result.metrics
    return {
        "strategy": strategy_name,
        "asset": asset,
        "metrics": {
            "total_return": m.total_return,
            "annualized_return": m.annualized_return,
            "volatility": m.volatility,
            "sharpe": m.sharpe,
            "sortino": m.sortino,
            "calmar": m.calmar,
            "max_drawdown": m.max_drawdown,
            "drawdown_duration_ms": m.drawdown_duration_ms,
            "hit_rate": m.hit_rate,
            "average_win": m.average_win,
            "average_loss": m.average_loss,
            "profit_factor": m.profit_factor,
            "trade_count": m.trade_count,
            "average_hold_ms": m.average_hold_ms,
            "funding_paid": m.funding_paid,
            "funding_earned": m.funding_earned,
            "net_funding": m.net_funding,
        },
        "equity_curve": [
            {"time": p.time, "equity": p.equity, "cash": p.cash} for p in result.equity_curve
        ],
        "closed_trades": [
            {
                "asset": t.asset,
                "entry_time": t.entry_time,
                "exit_time": t.exit_time,
                "size": t.size,
                "pnl": t.pnl,
            }
            for t in result.portfolio.closed_trades
        ],
    }


def _opt_to_dict(result: OptimizationResult, *, strategy_name: str) -> dict[str, Any]:
    return {
        "strategy": strategy_name,
        "metric": result.metric,
        "best": {
            "params": result.best.params,
            "metric_value": result.best.metric_value,
        },
        "runs": [
            {
                "params": run.params,
                "metric_value": run.metric_value,
                "total_return": run.result.metrics.total_return,
                "sharpe": run.result.metrics.sharpe,
                "max_drawdown": run.result.metrics.max_drawdown,
                "trade_count": run.result.metrics.trade_count,
            }
            for run in result.runs
        ],
    }


def _wf_to_dict(result: WalkForwardResult, *, strategy_name: str) -> dict[str, Any]:
    return {
        "strategy": strategy_name,
        "windows": [
            {
                "start_ms": w.start_ms,
                "end_ms": w.end_ms,
                "total_return": w.result.metrics.total_return,
                "sharpe": w.result.metrics.sharpe,
                "max_drawdown": w.result.metrics.max_drawdown,
                "trade_count": w.result.metrics.trade_count,
            }
            for w in result.windows
        ],
    }


__all__ = ["app"]
