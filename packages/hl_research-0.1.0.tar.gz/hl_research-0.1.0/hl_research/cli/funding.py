"""``hlr funding`` command group.

History, cross-asset heatmap, perp-vs-perp basis, and naive next-period
prediction. Reads from the local cache; never calls HL live.
"""

from __future__ import annotations

from typing import Annotated, Any

import polars as pl
import typer
from rich.console import Console

from hl_research.analytics.funding_arb import rank_basis
from hl_research.analytics.funding_predict import predict_next_funding
from hl_research.cache.store import Cache
from hl_research.cli.context import emit_json
from hl_research.cli.context import get as get_ctx
from hl_research.presentation.ascii import BarRow, funding_bars
from hl_research.presentation.tables import (
    funding_arb_table,
    funding_history_panel,
    funding_prediction_panel,
    render,
)

app = typer.Typer(
    name="funding",
    help="Funding-rate history, cross-asset heatmap, basis, and prediction.",
    no_args_is_help=True,
)


AssetArg = Annotated[
    str,
    typer.Argument(help="Asset name as listed by HL (e.g. BTC).", show_default=False),
]


def _validate_asset(name: str) -> str:
    if not name or not name.replace("-", "").replace("_", "").isalnum():
        raise typer.BadParameter(
            f"Invalid asset name: {name!r}. Expected an alphanumeric symbol like BTC."
        )
    return name.upper()


def _console(ctx: typer.Context) -> Console:
    cli = get_ctx(ctx)
    return Console(no_color=not cli.use_color, quiet=cli.quiet, highlight=False)


# Commands ---------------------------------------------------------------------


@app.command("history")
def history(ctx: typer.Context, asset: AssetArg) -> None:
    """Show funding-rate history for one asset (summary + sparkline)."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    cache = Cache(cli.cache_dir)
    frame = cache.read_funding(asset_norm).collect().sort("time")

    if cli.json:
        emit_json(_history_to_dict(asset_norm, frame))
        return

    render(console, funding_history_panel(asset_norm, frame))


@app.command("heatmap")
def heatmap(
    ctx: typer.Context,
    top: Annotated[
        int,
        typer.Option("--top", help="Maximum rows in the bar chart."),
    ] = 20,
) -> None:
    """Cross-asset funding-rate snapshot. One row per cached asset."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    cache = Cache(cli.cache_dir)
    rows = _latest_funding_rows(cache)

    if not rows:
        console.print(
            "[dim]No cached funding rates. Run `hlr data pull-funding <asset>` first.[/dim]"
        )
        raise typer.Exit(code=1)

    rows.sort(key=lambda r: abs(r.value), reverse=True)
    rows = rows[:top]

    if cli.json:
        emit_json(
            [
                {"asset": r.label, "funding_rate": r.value, "annualized": r.value * 3 * 365}
                for r in rows
            ]
        )
        return

    render(console, funding_bars(rows, width=28, value_format="{:+.4f}%"))


@app.command("arb")
def arb(
    ctx: typer.Context,
    asset: AssetArg,
    top: Annotated[
        int,
        typer.Option("--top", help="Maximum rows in the leaderboard."),
    ] = 20,
) -> None:
    """Perp-vs-perp funding basis leaderboard between an asset and every other cached asset."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    cache = Cache(cli.cache_dir)

    funding_by_asset: dict[str, pl.LazyFrame | pl.DataFrame] = dict(_all_cached_funding(cache))
    if asset_norm not in funding_by_asset:
        raise typer.BadParameter(
            f"No cached funding for {asset_norm}. Pull it first with "
            f"`hlr data pull-funding {asset_norm}`."
        )
    if len(funding_by_asset) < 2:
        raise typer.BadParameter(
            "Need at least two assets in the cache for a basis comparison. "
            "Pull funding for one more asset."
        )

    results = rank_basis(funding_by_asset, asset_norm)[:top]

    if cli.json:
        emit_json(
            [
                {
                    "base": asset_norm,
                    "reference": r.reference_asset,
                    "latest_basis": r.latest_basis,
                    "latest_annualized_basis": r.latest_annualized_basis,
                    "mean_basis": r.mean_basis,
                    "observations": r.observations,
                }
                for r in results
            ]
        )
        return

    render(console, funding_arb_table(results, base_asset=asset_norm))


@app.command("predict")
def predict(
    ctx: typer.Context,
    asset: AssetArg,
    span: Annotated[
        int,
        typer.Option("--span", help="EWMA span (periods)."),
    ] = 8,
) -> None:
    """Predict the next funding rate with the naive EWMA baseline."""
    cli = get_ctx(ctx)
    console = _console(ctx)
    asset_norm = _validate_asset(asset)
    cache = Cache(cli.cache_dir)
    frame = cache.read_funding(asset_norm).collect().sort("time")

    if frame.is_empty():
        raise typer.BadParameter(
            f"No cached funding for {asset_norm}. Pull it first with "
            f"`hlr data pull-funding {asset_norm}`."
        )

    prediction = predict_next_funding(frame, asset_norm, span=span)

    if cli.json:
        emit_json(
            {
                "asset": prediction.asset,
                "predicted_rate": prediction.predicted_rate,
                "lower_bound": prediction.lower_bound,
                "upper_bound": prediction.upper_bound,
                "confidence_band": prediction.confidence_band,
                "observations": prediction.observations,
                "method": prediction.method,
            }
        )
        return

    render(console, funding_prediction_panel(prediction))


# Cache helpers ----------------------------------------------------------------


def _all_cached_funding(cache: Cache) -> dict[str, pl.DataFrame]:
    """Return ``{asset: funding_frame}`` for every asset with cached funding."""
    out: dict[str, pl.DataFrame] = {}
    for entry in cache.list():
        if entry.kind != "funding":
            continue
        frame = cache.read_funding(entry.entity).collect().sort("time")
        if not frame.is_empty():
            out[entry.entity] = frame
    return out


def _latest_funding_rows(cache: Cache) -> list[BarRow]:
    """Latest funding rate per cached asset, as ``BarRow`` for the heatmap."""
    rows: list[BarRow] = []
    for asset, frame in _all_cached_funding(cache).items():
        latest = float(frame.select(pl.col("funding_rate").last()).item())
        rate_pct = latest * 100
        annualized_pct = latest * 3 * 365 * 100
        rows.append(
            BarRow(
                label=asset,
                value=rate_pct,
                annotation=f"{annualized_pct:+,.1f}% APR",
            )
        )
    return rows


def _history_to_dict(asset: str, frame: pl.DataFrame) -> dict[str, Any]:
    if frame.is_empty():
        return {"asset": asset, "observations": 0, "rates": []}
    return {
        "asset": asset,
        "observations": frame.height,
        "rates": [
            {
                "time": int(row["time"]),
                "funding_rate": float(row["funding_rate"]),
                "premium": float(row.get("premium", 0.0)),
            }
            for row in frame.iter_rows(named=True)
        ],
    }


__all__ = ["app"]
