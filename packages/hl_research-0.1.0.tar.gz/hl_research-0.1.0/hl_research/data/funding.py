"""Funding dataset transforms."""

from datetime import datetime

import polars as pl

from hl_research.cache.store import Cache
from hl_research.data.frames import filter_time_range


def funding(
    asset: str,
    since: datetime | None = None,
    until: datetime | None = None,
    cache: Cache | None = None,
) -> pl.LazyFrame:
    """Return cached funding rates filtered by optional time bounds."""
    source = cache or Cache()
    frame = source.read_funding(asset)
    return filter_time_range(frame, "time", since, until)
