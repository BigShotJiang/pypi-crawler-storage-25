"""Shared DataFrame helpers."""

from datetime import datetime

import polars as pl

TIME_MS_PER_SECOND = 1_000


def datetime_to_ms(value: datetime) -> int:
    """Convert a datetime to unix milliseconds."""
    return int(value.timestamp() * TIME_MS_PER_SECOND)


def filter_time_range(
    frame: pl.LazyFrame,
    column: str,
    since: datetime | None = None,
    until: datetime | None = None,
) -> pl.LazyFrame:
    """Apply optional datetime bounds to a LazyFrame timestamp column."""
    if since is not None:
        frame = frame.filter(pl.col(column) >= datetime_to_ms(since))
    if until is not None:
        frame = frame.filter(pl.col(column) <= datetime_to_ms(until))
    return frame
