"""Universe metadata transforms."""

import polars as pl

from hl_research.cache.store import Cache


def universe(cache: Cache | None = None) -> pl.DataFrame:
    """Return cached perpetual universe metadata."""
    source = cache or Cache()
    return source.read_assets()
