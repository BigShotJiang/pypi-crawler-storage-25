"""Vault dataset transforms."""

from datetime import datetime

import polars as pl

from hl_research.cache.store import Cache
from hl_research.data.frames import filter_time_range


def vault_trades(
    vault: str,
    since: datetime | None = None,
    until: datetime | None = None,
    cache: Cache | None = None,
) -> pl.LazyFrame:
    """Return cached vault trades filtered by optional time bounds."""
    source = cache or Cache()
    frame = source.read_vault_trades(vault)
    return filter_time_range(frame, "time", since, until)
