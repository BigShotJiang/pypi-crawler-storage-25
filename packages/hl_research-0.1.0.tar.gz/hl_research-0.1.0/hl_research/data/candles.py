"""Candle dataset transforms."""

from datetime import datetime

import polars as pl

from hl_research.api.types import Interval
from hl_research.cache.store import Cache
from hl_research.data.frames import filter_time_range


def candles(
    asset: str,
    interval: Interval,
    since: datetime | None = None,
    until: datetime | None = None,
    cache: Cache | None = None,
) -> pl.LazyFrame:
    """Return cached candles filtered by optional time bounds."""
    source = cache or Cache()
    frame = source.read_candles(asset, interval)
    return filter_time_range(frame, "open_time", since, until)
