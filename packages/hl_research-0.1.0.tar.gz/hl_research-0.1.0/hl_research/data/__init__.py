"""Polars data accessors and transforms over cached datasets."""
