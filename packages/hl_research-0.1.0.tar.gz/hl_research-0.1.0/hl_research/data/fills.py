"""Fill dataset transforms."""

from datetime import datetime

import polars as pl

from hl_research.cache.store import Cache
from hl_research.data.frames import filter_time_range


def fills(
    wallet: str,
    asset: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
    cache: Cache | None = None,
) -> pl.LazyFrame:
    """Return cached wallet fills filtered by asset and optional time bounds."""
    source = cache or Cache()
    frame = source.read_fills(wallet)
    if asset is not None:
        frame = frame.filter(pl.col("asset") == asset)
    return filter_time_range(frame, "time", since, until)
