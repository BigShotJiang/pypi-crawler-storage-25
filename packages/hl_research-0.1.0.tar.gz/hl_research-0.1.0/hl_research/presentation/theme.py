"""Color tokens, typography, and shared style constants.

Single source of truth for every visual surface: terminal output, matplotlib
and plotly stylesheets, Jinja2 HTML reports, and Textual CSS. Do not hardcode
colors anywhere else in the codebase.

Palette mirrors Hyperliquid's brand: signature mint as the primary accent and
positive PnL signal, coral for losses, slightly teal-tinted neutrals.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True)
class Palette:
    """Hyperliquid-aligned palette plus the two PnL-state accents."""

    # Neutral ramp (teal-tinted dark surface, light text)
    neutral_50: str = "#f5f9f8"
    neutral_200: str = "#dfe5e4"
    neutral_400: str = "#9aa3a3"
    neutral_600: str = "#3a4344"
    neutral_700: str = "#252b2c"
    neutral_800: str = "#15191a"
    neutral_900: str = "#0a0e0e"

    # Brand + state accents.
    # Mint is the Hyperliquid signature: it doubles as the primary accent and
    # the positive PnL color. Coral is the loss color. Brand and loss never
    # collide on the same hex.
    mint: str = "#97FCE4"
    coral: str = "#ED7088"
    teal_deep: str = "#50D2B1"


PALETTE: Final[Palette] = Palette()


@dataclass(frozen=True)
class Semantic:
    """Semantic aliases for the palette.

    Reference these by intent (`text_primary`) rather than by hex
    (`neutral_200`). When the palette shifts, only this struct changes.
    """

    background: str = PALETTE.neutral_900
    surface: str = PALETTE.neutral_800
    surface_elev: str = PALETTE.neutral_700
    text_primary: str = PALETTE.neutral_200
    text_secondary: str = PALETTE.neutral_400
    text_tertiary: str = PALETTE.neutral_600
    hairline: str = PALETTE.neutral_600
    accent: str = PALETTE.mint
    pnl_up: str = PALETTE.mint
    pnl_down: str = PALETTE.coral


COLOR: Final[Semantic] = Semantic()


@dataclass(frozen=True)
class Typography:
    body_family: str = "Inter, sans-serif"
    mono_family: str = "Geist Mono, JetBrains Mono, monospace"
    body_size: int = 10
    mono_size: int = 10


TYPE: Final[Typography] = Typography()


def pnl_color(value: float) -> str:
    """Return the PnL accent for a signed value. Zero resolves to text_secondary."""
    if value > 0:
        return COLOR.pnl_up
    if value < 0:
        return COLOR.pnl_down
    return COLOR.text_secondary


# Rich style strings, prebuilt for table builders.
RICH_STYLE_HEADER: Final[str] = f"bold {COLOR.text_primary}"
RICH_STYLE_BODY: Final[str] = COLOR.text_primary
RICH_STYLE_MUTED: Final[str] = COLOR.text_secondary
RICH_STYLE_HAIRLINE: Final[str] = COLOR.hairline
RICH_STYLE_PNL_UP: Final[str] = COLOR.pnl_up
RICH_STYLE_PNL_DOWN: Final[str] = COLOR.pnl_down
RICH_STYLE_ACCENT: Final[str] = COLOR.accent
