"""ASCII chart helpers for funding and similar small-multiple terminal views.

Inputs are generic (label + value pairs, or a labeled 2D matrix). The CLI
layer is responsible for shaping data from ``analytics`` into these inputs.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text

from hl_research.presentation.theme import (
    COLOR,
    RICH_STYLE_BODY,
    RICH_STYLE_HAIRLINE,
    RICH_STYLE_HEADER,
    RICH_STYLE_MUTED,
    RICH_STYLE_PNL_DOWN,
    RICH_STYLE_PNL_UP,
)


@dataclass(frozen=True)
class BarRow:
    """One row in a horizontal-bar terminal chart."""

    label: str
    value: float
    annotation: str | None = None  # optional secondary text after the bar


_BLOCK_FILLED = "█"
_BLOCK_EMPTY = " "
_BLOCK_CENTER = "│"
_SHADES = "▁▂▃▄▅▆▇█"


def funding_bars(
    rows: Sequence[BarRow],
    *,
    width: int = 32,
    value_format: str = "{:+.4f}%",
    title: str = "funding rates",
) -> Table:
    """Render a sorted cross-asset funding bar chart.

    Each row's value is rendered as a signed horizontal bar centered on zero,
    colored PnL-up for positive and PnL-down for negative. Width is the number
    of cells on each side of the zero line.
    """
    if not rows:
        return _empty_table(title, "No funding rates available.")

    max_abs = max((abs(r.value) for r in rows), default=0.0)
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("ASSET", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("RATE", justify="right", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("", no_wrap=True)
    if any(r.annotation for r in rows):
        table.add_column("", style=RICH_STYLE_MUTED, no_wrap=True)

    for row in rows:
        rate_style = (
            RICH_STYLE_PNL_UP
            if row.value > 0
            else (RICH_STYLE_PNL_DOWN if row.value < 0 else RICH_STYLE_BODY)
        )
        bar = _signed_bar(row.value, max_abs=max_abs, width=width)
        cells: list[str | Text] = [
            row.label,
            Text(value_format.format(row.value), style=rate_style),
            bar,
        ]
        if any(r.annotation for r in rows):
            cells.append(row.annotation or "")
        table.add_row(*cells)
    return table


def funding_heatmap_grid(
    *,
    row_labels: Sequence[str],
    col_labels: Sequence[str],
    values: Sequence[Sequence[float]],
    title: str = "funding heatmap",
) -> Table:
    """Render a 2D heatmap: rows are assets, columns are time buckets.

    Cells use a shaded block character whose intensity reflects ``|value| / max_abs``,
    colored by sign. Useful for spotting persistent funding bias per asset.
    """
    if not row_labels or not col_labels or not values:
        return _empty_table(title, "No heatmap data.")

    flat = [v for row in values for v in row]
    max_abs = max((abs(v) for v in flat), default=0.0)

    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
        collapse_padding=True,
    )
    table.add_column("ASSET", style=RICH_STYLE_BODY, no_wrap=True)
    for col in col_labels:
        table.add_column(col, justify="center", style=RICH_STYLE_MUTED, no_wrap=True)

    for label, row in zip(row_labels, values, strict=False):
        cells: list[str | Text] = [label]
        for value in row:
            cells.append(_heatmap_cell(value, max_abs=max_abs))
        table.add_row(*cells)
    return table


def sparkline(values: Sequence[float], *, width: int = 60) -> str:
    """Render a list of floats as a unicode sparkline at most ``width`` cells."""
    if not values:
        return ""
    samples = list(values)
    if len(samples) > width:
        step = len(samples) / width
        samples = [values[int(i * step)] for i in range(width)]

    lo = min(samples)
    hi = max(samples)
    if hi == lo:
        return _SHADES[len(_SHADES) // 2] * len(samples)

    span = hi - lo
    return "".join(_SHADES[int(((v - lo) / span) * (len(_SHADES) - 1))] for v in samples)


def print_table(console: Console, renderable: Table) -> None:
    """Thin wrapper so callers never touch ``console.print`` directly."""
    console.print(renderable)


# Internals --------------------------------------------------------------------


def _signed_bar(value: float, *, max_abs: float, width: int) -> Text:
    """Return a centered signed bar of ``width`` cells per side of the zero line."""
    if max_abs <= 0:
        return Text(_BLOCK_EMPTY * (width * 2 + 1), style=RICH_STYLE_MUTED)

    cells = max(1, min(width, int(round((abs(value) / max_abs) * width))))
    if value > 0:
        left = _BLOCK_EMPTY * width
        right = _BLOCK_FILLED * cells + _BLOCK_EMPTY * (width - cells)
        style = COLOR.pnl_up
    elif value < 0:
        left = _BLOCK_EMPTY * (width - cells) + _BLOCK_FILLED * cells
        right = _BLOCK_EMPTY * width
        style = COLOR.pnl_down
    else:
        left = _BLOCK_EMPTY * width
        right = _BLOCK_EMPTY * width
        style = COLOR.text_tertiary

    bar = Text()
    bar.append(left, style=style)
    bar.append(_BLOCK_CENTER, style=RICH_STYLE_HAIRLINE)
    bar.append(right, style=style)
    return bar


def _heatmap_cell(value: float, *, max_abs: float) -> Text:
    """Two-character cell whose shade reflects intensity and sign reflects color."""
    if max_abs <= 0 or value == 0:
        return Text("··", style=RICH_STYLE_MUTED)

    intensity = min(1.0, abs(value) / max_abs)
    shade_idx = max(0, min(len(_SHADES) - 1, int(intensity * (len(_SHADES) - 1))))
    char = _SHADES[shade_idx]
    style = COLOR.pnl_up if value > 0 else COLOR.pnl_down
    return Text(char * 2, style=style)


def _empty_table(title: str, message: str) -> Table:
    table = Table(
        title=title,
        title_style=RICH_STYLE_MUTED,
        box=box.SIMPLE,
        show_header=False,
        border_style=RICH_STYLE_HAIRLINE,
    )
    table.add_row(Text(message, style=RICH_STYLE_MUTED))
    return table


__all__ = [
    "BarRow",
    "funding_bars",
    "funding_heatmap_grid",
    "print_table",
    "sparkline",
]
