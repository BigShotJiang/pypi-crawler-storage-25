"""Reusable Rich progress factory.

One factory function so every long-running operation produces the same visual
shape. Subcommands never instantiate ``rich.progress.Progress`` directly; they
call :func:`pull_progress` and use its returned context manager.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Final

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    ProgressColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from hl_research.presentation.theme import COLOR

_BAR_STYLE: Final[str] = COLOR.text_tertiary
_BAR_COMPLETE_STYLE: Final[str] = COLOR.text_primary
_BAR_FINISHED_STYLE: Final[str] = COLOR.pnl_up


def _columns() -> list[ProgressColumn]:
    """Default column set for any pull-like operation."""
    return [
        TextColumn("[bold]{task.description}", style=COLOR.text_primary),
        BarColumn(
            bar_width=None,
            style=_BAR_STYLE,
            complete_style=_BAR_COMPLETE_STYLE,
            finished_style=_BAR_FINISHED_STYLE,
        ),
        TaskProgressColumn(style=COLOR.text_secondary),
        MofNCompleteColumn(),
        TextColumn("·", style=COLOR.text_tertiary),
        TimeElapsedColumn(),
        TextColumn("·", style=COLOR.text_tertiary),
        TimeRemainingColumn(),
    ]


@contextmanager
def pull_progress(console: Console | None = None) -> Iterator[Progress]:
    """Yield a configured ``Progress`` for any long-running pull.

    Usage:

        with pull_progress(console) as progress:
            task = progress.add_task("Pulling BTC candles", total=120)
            ...
            progress.update(task, advance=1)
    """
    progress = Progress(*_columns(), console=console, transient=False)
    with progress:
        yield progress


@contextmanager
def indeterminate(description: str, console: Console | None = None) -> Iterator[Progress]:
    """Progress with an unknown total. Use for first-pass discovery calls."""
    progress = Progress(
        TextColumn("[bold]{task.description}", style=COLOR.text_primary),
        BarColumn(
            bar_width=None,
            style=_BAR_STYLE,
            complete_style=_BAR_COMPLETE_STYLE,
            pulse_style=_BAR_COMPLETE_STYLE,
        ),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    )
    with progress:
        progress.add_task(description, total=None)
        yield progress
