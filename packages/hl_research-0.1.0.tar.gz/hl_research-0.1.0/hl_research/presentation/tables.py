"""Table builders for terminal output.

Every tabular surface in the CLI funnels through one of the builders here.
Subcommands pass typed row objects; this module owns the column layout,
formatting rules, and styling.

Row Protocols define the presentation contract. ``hl_research.cache.store``
dataclasses conform to them, but this module never imports from ``api``,
``cache``, or ``data``.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from typing import Protocol, runtime_checkable

import polars as pl
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from hl_research.analytics.types import (
    FundingBasisResult,
    FundingPrediction,
    VaultAnalysis,
    VaultMetrics,
)
from hl_research.api.types import AssetPosition, ClearinghouseState, Fill, FundingPayment
from hl_research.backtest.engine import BacktestResult
from hl_research.backtest.metrics import BacktestMetrics
from hl_research.backtest.optimizer import OptimizationResult
from hl_research.backtest.portfolio import EquityPoint
from hl_research.backtest.walkforward import WalkForwardResult
from hl_research.presentation.theme import (
    RICH_STYLE_BODY,
    RICH_STYLE_HAIRLINE,
    RICH_STYLE_HEADER,
    RICH_STYLE_MUTED,
    RICH_STYLE_PNL_DOWN,
    RICH_STYLE_PNL_UP,
)

# Presentation contracts -------------------------------------------------------


@runtime_checkable
class CacheEntryLike(Protocol):
    """Row shape consumed by :func:`cache_listing`.

    Matches ``hl_research.cache.store.CacheEntry``. Read-only to compose
    cleanly with frozen dataclasses.
    """

    @property
    def kind(self) -> str: ...
    @property
    def entity(self) -> str: ...
    @property
    def interval(self) -> str | None: ...
    @property
    def since_ms(self) -> int: ...
    @property
    def until_ms(self) -> int: ...
    @property
    def row_count(self) -> int: ...
    @property
    def size_bytes(self) -> int: ...
    @property
    def updated_at(self) -> datetime: ...


@runtime_checkable
class CacheInfoLike(Protocol):
    """Summary stats for :func:`cache_summary`. Built inline in ``cli/data.py``."""

    @property
    def cache_dir(self) -> str: ...
    @property
    def total_bytes(self) -> int: ...
    @property
    def file_count(self) -> int: ...
    @property
    def dataset_count(self) -> int: ...
    @property
    def last_sync(self) -> datetime | None: ...


# Builders ---------------------------------------------------------------------


def cache_listing(entries: Sequence[CacheEntryLike]) -> Table:
    """Render ``hlr data ls`` output."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
        collapse_padding=False,
    )
    table.add_column("KIND", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("ENTITY", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("INTERVAL", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("ROWS", justify="right", style=RICH_STYLE_BODY)
    table.add_column("SIZE", justify="right", style=RICH_STYLE_BODY)
    table.add_column("SINCE", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("UNTIL", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("UPDATED", style=RICH_STYLE_MUTED, no_wrap=True)

    for e in entries:
        table.add_row(
            e.kind,
            _short_entity(e.entity),
            e.interval or "—",
            f"{e.row_count:,}",
            _format_size(e.size_bytes),
            _format_ms_date(e.since_ms),
            _format_ms_date(e.until_ms),
            _format_datetime(e.updated_at),
        )

    return table


def cache_summary(info: CacheInfoLike) -> Panel:
    """Render ``hlr data info`` output as a key-value panel."""
    body = Text()
    body.append("CACHE DIRECTORY    ", style=RICH_STYLE_MUTED)
    body.append(f"{info.cache_dir}\n", style=RICH_STYLE_BODY)
    body.append("TOTAL SIZE         ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_size(info.total_bytes)}\n", style=RICH_STYLE_BODY)
    body.append("FILES              ", style=RICH_STYLE_MUTED)
    body.append(f"{info.file_count:,}\n", style=RICH_STYLE_BODY)
    body.append("DATASETS           ", style=RICH_STYLE_MUTED)
    body.append(f"{info.dataset_count:,}\n", style=RICH_STYLE_BODY)
    body.append("LAST SYNC          ", style=RICH_STYLE_MUTED)
    body.append(
        _format_datetime(info.last_sync) if info.last_sync else "never",
        style=RICH_STYLE_BODY,
    )

    return Panel(
        body,
        title="cache",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def render(console: Console, renderable: object) -> None:
    """Thin print wrapper. Subcommands call this; never ``console.print`` directly."""
    console.print(renderable)


# Wallet surfaces --------------------------------------------------------------


def account_summary(state: ClearinghouseState, *, wallet: str) -> Panel:
    """Render ``hlr wallet inspect`` header: equity, margin used, withdrawable."""
    body = Text()
    body.append("WALLET             ", style=RICH_STYLE_MUTED)
    body.append(f"{_short_entity(wallet)}\n", style=RICH_STYLE_BODY)
    body.append("ACCOUNT VALUE      ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd(state.margin_summary.account_value)}\n", style=RICH_STYLE_BODY)
    body.append("WITHDRAWABLE       ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd(state.withdrawable)}\n", style=RICH_STYLE_BODY)
    body.append("MARGIN USED        ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd(state.margin_summary.total_margin_used)}\n", style=RICH_STYLE_BODY)
    body.append("NOTIONAL EXPOSURE  ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd(state.margin_summary.total_ntl_pos)}", style=RICH_STYLE_BODY)

    return Panel(
        body,
        title="account",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def positions_table(positions: Sequence[AssetPosition]) -> Table:
    """Render open positions for ``hlr wallet inspect``."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("COIN", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("SIDE", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("SIZE", justify="right", style=RICH_STYLE_BODY)
    table.add_column("ENTRY", justify="right", style=RICH_STYLE_BODY)
    table.add_column("NOTIONAL", justify="right", style=RICH_STYLE_BODY)
    table.add_column("LEV", justify="right", style=RICH_STYLE_MUTED)
    table.add_column("UPNL", justify="right", style=RICH_STYLE_BODY)
    table.add_column("LIQ PX", justify="right", style=RICH_STYLE_MUTED)

    for ap in positions:
        p = ap.position
        side = "LONG" if p.szi > 0 else "SHORT"
        leverage = f"{p.leverage.value}x" if p.leverage else "—"
        upnl = p.unrealized_pnl or 0.0
        upnl_style = (
            RICH_STYLE_PNL_UP
            if upnl > 0
            else (RICH_STYLE_PNL_DOWN if upnl < 0 else RICH_STYLE_BODY)
        )

        table.add_row(
            p.coin,
            side,
            _format_num(abs(p.szi)),
            _format_num(p.entry_px) if p.entry_px else "—",
            _format_usd(p.position_value or 0.0),
            leverage,
            Text(_format_usd(upnl), style=upnl_style),
            _format_num(p.liquidation_px) if p.liquidation_px else "—",
        )

    return table


def fills_table(fills: Sequence[Fill], *, limit: int | None = None) -> Table:
    """Render recent fills for ``hlr wallet fills``."""
    rows = list(fills)
    if limit is not None:
        rows = rows[:limit]

    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("TIME", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("ASSET", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("SIDE", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("SIZE", justify="right", style=RICH_STYLE_BODY)
    table.add_column("PRICE", justify="right", style=RICH_STYLE_BODY)
    table.add_column("FEE", justify="right", style=RICH_STYLE_MUTED)
    table.add_column("PNL", justify="right", style=RICH_STYLE_BODY)

    for f in rows:
        pnl = f.closed_pnl or 0.0
        pnl_style = (
            RICH_STYLE_PNL_UP if pnl > 0 else (RICH_STYLE_PNL_DOWN if pnl < 0 else RICH_STYLE_MUTED)
        )
        side_label = "BUY" if f.side == "B" else "SELL"
        table.add_row(
            _format_ms_datetime(f.time),
            f.coin,
            side_label,
            _format_num(f.sz),
            _format_num(f.px),
            _format_usd(f.fee),
            Text(_format_usd(pnl), style=pnl_style),
        )

    return table


def funding_summary(payments: Sequence[FundingPayment]) -> Table:
    """Render per-asset funding paid/earned/net for ``hlr wallet funding``."""
    by_asset: dict[str, dict[str, float]] = {}
    for p in payments:
        coin = p.delta.coin
        amount = p.delta.usdc
        bucket = by_asset.setdefault(coin, {"paid": 0.0, "earned": 0.0})
        if amount < 0:
            bucket["paid"] += amount
        else:
            bucket["earned"] += amount

    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("ASSET", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("PAID", justify="right", style=RICH_STYLE_PNL_DOWN)
    table.add_column("EARNED", justify="right", style=RICH_STYLE_PNL_UP)
    table.add_column("NET", justify="right", style=RICH_STYLE_BODY)

    total_paid = 0.0
    total_earned = 0.0
    for asset, vals in sorted(by_asset.items()):
        paid = vals["paid"]
        earned = vals["earned"]
        net = paid + earned
        total_paid += paid
        total_earned += earned
        net_style = (
            RICH_STYLE_PNL_UP if net > 0 else (RICH_STYLE_PNL_DOWN if net < 0 else RICH_STYLE_BODY)
        )
        table.add_row(
            asset,
            _format_usd(paid),
            _format_usd(earned),
            Text(_format_usd(net), style=net_style),
        )

    if by_asset:
        total_net = total_paid + total_earned
        total_net_style = (
            RICH_STYLE_PNL_UP
            if total_net > 0
            else (RICH_STYLE_PNL_DOWN if total_net < 0 else RICH_STYLE_BODY)
        )
        table.add_section()
        table.add_row(
            Text("TOTAL", style=RICH_STYLE_HEADER),
            _format_usd(total_paid),
            _format_usd(total_earned),
            Text(_format_usd(total_net), style=total_net_style),
        )

    return table


# Backtest surfaces ------------------------------------------------------------


def backtest_summary(
    result: BacktestResult,
    *,
    strategy_name: str,
    asset: str | None,
    params: Mapping[str, object] | None = None,
) -> Panel:
    """Top-level backtest summary panel: header + key metrics."""
    metrics = result.metrics
    body = Text()
    body.append("STRATEGY           ", style=RICH_STYLE_MUTED)
    body.append(f"{strategy_name}\n", style=RICH_STYLE_BODY)
    body.append("ASSET              ", style=RICH_STYLE_MUTED)
    body.append(f"{asset or 'all'}\n", style=RICH_STYLE_BODY)
    if params:
        body.append("PARAMS             ", style=RICH_STYLE_MUTED)
        body.append(f"{_format_params(params)}\n", style=RICH_STYLE_BODY)
    body.append("PERIOD             ", style=RICH_STYLE_MUTED)
    body.append(f"{_equity_period(result.equity_curve)}\n\n", style=RICH_STYLE_BODY)

    body.append("TOTAL RETURN       ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_pct(metrics.total_return)}\n",
        style=_signed_style(metrics.total_return),
    )
    body.append("ANNUALIZED         ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_pct(metrics.annualized_return)}\n",
        style=_signed_style(metrics.annualized_return),
    )
    body.append("SHARPE             ", style=RICH_STYLE_MUTED)
    body.append(f"{metrics.sharpe:,.2f}\n", style=RICH_STYLE_BODY)
    body.append("SORTINO            ", style=RICH_STYLE_MUTED)
    body.append(f"{metrics.sortino:,.2f}\n", style=RICH_STYLE_BODY)
    body.append("MAX DRAWDOWN       ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_pct(metrics.max_drawdown)}\n",
        style=RICH_STYLE_PNL_DOWN if metrics.max_drawdown < 0 else RICH_STYLE_BODY,
    )
    body.append("HIT RATE           ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_pct(metrics.hit_rate)}\n", style=RICH_STYLE_BODY)
    body.append("PROFIT FACTOR      ", style=RICH_STYLE_MUTED)
    body.append(f"{metrics.profit_factor:,.2f}\n", style=RICH_STYLE_BODY)
    body.append("TRADES             ", style=RICH_STYLE_MUTED)
    body.append(f"{metrics.trade_count:,}\n", style=RICH_STYLE_BODY)
    body.append("NET FUNDING        ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_usd(metrics.net_funding)}",
        style=_signed_style(metrics.net_funding),
    )

    return Panel(
        body,
        title="backtest",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def backtest_metrics_table(metrics: BacktestMetrics) -> Table:
    """Full per-metric table for verbose output."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("METRIC", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("VALUE", justify="right", style=RICH_STYLE_BODY)

    rows: list[tuple[str, str]] = [
        ("Total return", _format_pct(metrics.total_return)),
        ("Annualized return", _format_pct(metrics.annualized_return)),
        ("Volatility", _format_pct(metrics.volatility)),
        ("Sharpe ratio", f"{metrics.sharpe:,.2f}"),
        ("Sortino ratio", f"{metrics.sortino:,.2f}"),
        ("Calmar ratio", f"{metrics.calmar:,.2f}"),
        ("Max drawdown", _format_pct(metrics.max_drawdown)),
        ("Drawdown duration", _format_duration_ms(metrics.drawdown_duration_ms)),
        ("Hit rate", _format_pct(metrics.hit_rate)),
        ("Average win", _format_usd(metrics.average_win)),
        ("Average loss", _format_usd(metrics.average_loss)),
        ("Profit factor", f"{metrics.profit_factor:,.2f}"),
        ("Trades", f"{metrics.trade_count:,}"),
        ("Average hold", _format_duration_ms(int(metrics.average_hold_ms))),
        ("Funding paid", _format_usd(-metrics.funding_paid)),
        ("Funding earned", _format_usd(metrics.funding_earned)),
        ("Net funding", _format_usd(metrics.net_funding)),
    ]
    for label, value in rows:
        table.add_row(label, value)
    return table


def equity_sparkline_panel(equity_curve: list[EquityPoint], *, width: int = 60) -> Panel:
    """ASCII sparkline of the equity curve with start, end, peak, trough."""
    if not equity_curve:
        body = Text("No equity data.", style=RICH_STYLE_MUTED)
        return Panel(body, title="equity", title_align="left", border_style=RICH_STYLE_HAIRLINE)

    spark = _sparkline([p.equity for p in equity_curve], width=width)
    first = equity_curve[0].equity
    last = equity_curve[-1].equity
    peak = max(equity_curve, key=lambda p: p.equity).equity
    trough = min(equity_curve, key=lambda p: p.equity).equity
    delta = last - first
    delta_pct = (last / first - 1) if first else 0.0

    body = Text()
    body.append(spark + "\n\n", style=_signed_style(delta))
    body.append("START   ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd_unsigned(first)}    ", style=RICH_STYLE_BODY)
    body.append("END     ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd_unsigned(last)}\n", style=RICH_STYLE_BODY)
    body.append("PEAK    ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd_unsigned(peak)}    ", style=RICH_STYLE_BODY)
    body.append("TROUGH  ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_usd_unsigned(trough)}\n", style=RICH_STYLE_BODY)
    body.append("CHANGE  ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_usd(delta)} ({_format_pct(delta_pct)})",
        style=_signed_style(delta),
    )

    return Panel(
        body,
        title="equity",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def optimization_table(result: OptimizationResult, *, top: int = 10) -> Table:
    """Leaderboard of top runs sorted by the optimization metric."""
    ranked = sorted(result.runs, key=lambda run: run.metric_value, reverse=True)[:top]

    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("RANK", justify="right", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("PARAMS", style=RICH_STYLE_BODY)
    table.add_column(result.metric.upper(), justify="right", style=RICH_STYLE_BODY)
    table.add_column("RETURN", justify="right", style=RICH_STYLE_BODY)
    table.add_column("DRAWDOWN", justify="right", style=RICH_STYLE_BODY)
    table.add_column("TRADES", justify="right", style=RICH_STYLE_MUTED)

    for rank, run in enumerate(ranked, start=1):
        m = run.result.metrics
        is_best = run.params == result.best.params
        rank_text = Text(f"{rank}", style=RICH_STYLE_HEADER if is_best else RICH_STYLE_MUTED)
        metric_text = Text(
            f"{run.metric_value:,.4f}",
            style=_signed_style(run.metric_value),
        )
        ret_text = Text(_format_pct(m.total_return), style=_signed_style(m.total_return))
        dd_text = Text(
            _format_pct(m.max_drawdown),
            style=RICH_STYLE_PNL_DOWN if m.max_drawdown < 0 else RICH_STYLE_BODY,
        )
        table.add_row(
            rank_text,
            _format_params(run.params),
            metric_text,
            ret_text,
            dd_text,
            f"{m.trade_count:,}",
        )
    return table


def walk_forward_table(result: WalkForwardResult) -> Table:
    """Per-window metrics for a walk-forward result."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("#", justify="right", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("START", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("END", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("RETURN", justify="right", style=RICH_STYLE_BODY)
    table.add_column("SHARPE", justify="right", style=RICH_STYLE_BODY)
    table.add_column("DRAWDOWN", justify="right", style=RICH_STYLE_BODY)
    table.add_column("TRADES", justify="right", style=RICH_STYLE_MUTED)

    for idx, window in enumerate(result.windows, start=1):
        m = window.result.metrics
        ret_text = Text(_format_pct(m.total_return), style=_signed_style(m.total_return))
        dd_text = Text(
            _format_pct(m.max_drawdown),
            style=RICH_STYLE_PNL_DOWN if m.max_drawdown < 0 else RICH_STYLE_BODY,
        )
        table.add_row(
            f"{idx}",
            _format_ms_date(window.start_ms),
            _format_ms_date(window.end_ms),
            ret_text,
            f"{m.sharpe:,.2f}",
            dd_text,
            f"{m.trade_count:,}",
        )
    return table


# Vault surfaces ---------------------------------------------------------------


def vault_listing(rows: pl.DataFrame, *, top: int | None = None) -> Table:
    """Render ``hlr vault ls`` from the cached vault-summary DataFrame.

    Expected columns: address, name, leader, tvl, apr, is_closed.
    """
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("NAME", style=RICH_STYLE_BODY, no_wrap=False)
    table.add_column("ADDRESS", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("LEADER", style=RICH_STYLE_MUTED, no_wrap=True)
    table.add_column("TVL", justify="right", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("APR", justify="right", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("STATE", style=RICH_STYLE_MUTED, no_wrap=True)

    materialized = list(rows.iter_rows(named=True))
    if top is not None:
        materialized = materialized[:top]

    for row in materialized:
        tvl = row.get("tvl")
        apr = row.get("apr")
        table.add_row(
            row.get("name") or "—",
            _short_entity(row.get("address") or ""),
            _short_entity(row.get("leader") or "") if row.get("leader") else "—",
            _format_usd_unsigned(float(tvl)) if tvl is not None else "—",
            f"{float(apr) * 100:+,.2f}%" if apr is not None else "—",
            "closed" if row.get("is_closed") else "open",
        )
    return table


def vault_summary_panel(analysis: VaultAnalysis) -> Panel:
    """Header panel for ``hlr vault inspect``: identity, TVL, depositors."""
    body = Text()
    body.append("NAME               ", style=RICH_STYLE_MUTED)
    body.append(f"{analysis.name or '—'}\n", style=RICH_STYLE_BODY)
    body.append("ADDRESS            ", style=RICH_STYLE_MUTED)
    body.append(f"{analysis.vault}\n", style=RICH_STYLE_BODY)
    body.append("LEADER             ", style=RICH_STYLE_MUTED)
    body.append(f"{analysis.leader or '—'}\n", style=RICH_STYLE_BODY)
    body.append("TVL                ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_usd_unsigned(analysis.tvl) if analysis.tvl is not None else '—'}\n",
        style=RICH_STYLE_BODY,
    )
    body.append("DEPOSITORS         ", style=RICH_STYLE_MUTED)
    body.append(f"{analysis.depositor_count:,}", style=RICH_STYLE_BODY)

    return Panel(
        body,
        title="vault",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def vault_metrics_panel(metrics: VaultMetrics) -> Panel:
    """Vault performance metrics panel."""
    body = Text()
    body.append("TOTAL RETURN       ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_pct(metrics.total_return)}\n", style=_signed_style(metrics.total_return))
    body.append("ANNUALIZED         ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_pct(metrics.annualized_return)}\n",
        style=_signed_style(metrics.annualized_return),
    )
    body.append("VOLATILITY         ", style=RICH_STYLE_MUTED)
    body.append(f"{_format_pct(metrics.volatility)}\n", style=RICH_STYLE_BODY)
    body.append("SHARPE             ", style=RICH_STYLE_MUTED)
    body.append(f"{metrics.sharpe:,.2f}\n", style=RICH_STYLE_BODY)
    body.append("MAX DRAWDOWN       ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_pct(metrics.max_drawdown)}",
        style=RICH_STYLE_PNL_DOWN if metrics.max_drawdown < 0 else RICH_STYLE_BODY,
    )

    return Panel(
        body,
        title="performance",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def vault_asset_breakdown(frame: pl.DataFrame) -> Table:
    """Per-asset volume + PnL table for vault inspect."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("ASSET", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("TRADES", justify="right", style=RICH_STYLE_BODY)
    table.add_column("VOLUME", justify="right", style=RICH_STYLE_BODY)
    table.add_column("CLOSED PNL", justify="right", style=RICH_STYLE_BODY)

    for row in frame.iter_rows(named=True):
        pnl = float(row.get("closed_pnl") or 0.0)
        table.add_row(
            row.get("asset", "—"),
            f"{int(row.get('trade_count') or 0):,}",
            _format_usd_unsigned(float(row.get("volume") or 0.0)),
            Text(_format_usd(pnl), style=_signed_style(pnl)),
        )
    return table


# Funding surfaces -------------------------------------------------------------


def funding_history_panel(asset: str, frame: pl.DataFrame) -> Panel:
    """Render ``hlr funding history``: summary stats + recent rates sparkline.

    Expected columns: time (int ms), funding_rate (float), premium (float).
    """
    if frame.is_empty():
        body = Text(
            f"No cached funding for {asset}. Run `hlr data pull-funding {asset}` first.",
            style=RICH_STYLE_MUTED,
        )
        return Panel(
            body,
            title="funding history",
            title_align="left",
            border_style=RICH_STYLE_HAIRLINE,
            padding=(1, 2),
        )

    rates = frame.get_column("funding_rate").to_list()
    times = frame.get_column("time").to_list()
    latest = float(rates[-1])
    mean = sum(rates) / len(rates)
    spark = _sparkline([float(r) for r in rates], width=50)

    body = Text()
    body.append("ASSET              ", style=RICH_STYLE_MUTED)
    body.append(f"{asset}\n", style=RICH_STYLE_BODY)
    body.append("OBSERVATIONS       ", style=RICH_STYLE_MUTED)
    body.append(f"{len(rates):,}\n", style=RICH_STYLE_BODY)
    body.append("RANGE              ", style=RICH_STYLE_MUTED)
    body.append(
        f"{_format_ms_date(int(times[0]))} → {_format_ms_date(int(times[-1]))}\n",
        style=RICH_STYLE_BODY,
    )
    body.append("LATEST             ", style=RICH_STYLE_MUTED)
    body.append(
        f"{float(latest) * 100:+,.4f}% / period\n",
        style=_signed_style(float(latest)),
    )
    body.append("MEAN               ", style=RICH_STYLE_MUTED)
    body.append(f"{mean * 100:+,.4f}% / period\n\n", style=_signed_style(mean))
    body.append(spark, style=RICH_STYLE_BODY)

    return Panel(
        body,
        title="funding history",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


def funding_arb_table(results: list[FundingBasisResult], *, base_asset: str) -> Table:
    """Perp-vs-perp basis leaderboard for ``hlr funding arb``."""
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style=RICH_STYLE_HEADER,
        border_style=RICH_STYLE_HAIRLINE,
        pad_edge=False,
    )
    table.add_column("PAIR", style=RICH_STYLE_BODY, no_wrap=True)
    table.add_column("LATEST BASIS", justify="right", style=RICH_STYLE_BODY)
    table.add_column("ANNUALIZED", justify="right", style=RICH_STYLE_BODY)
    table.add_column("MEAN BASIS", justify="right", style=RICH_STYLE_BODY)
    table.add_column("N", justify="right", style=RICH_STYLE_MUTED)

    for r in results:
        latest_style = _signed_style(r.latest_basis)
        ann_style = _signed_style(r.latest_annualized_basis)
        table.add_row(
            f"{base_asset} / {r.reference_asset}",
            Text(f"{r.latest_basis * 100:+,.4f}%", style=latest_style),
            Text(f"{r.latest_annualized_basis * 100:+,.2f}%", style=ann_style),
            Text(f"{r.mean_basis * 100:+,.4f}%", style=_signed_style(r.mean_basis)),
            f"{r.observations:,}",
        )
    return table


def funding_prediction_panel(prediction: FundingPrediction) -> Panel:
    """Render the naive funding-rate prediction with a clear disclaimer."""
    body = Text()
    body.append("ASSET              ", style=RICH_STYLE_MUTED)
    body.append(f"{prediction.asset}\n", style=RICH_STYLE_BODY)
    body.append("METHOD             ", style=RICH_STYLE_MUTED)
    body.append(f"{prediction.method}\n", style=RICH_STYLE_BODY)
    body.append("OBSERVATIONS       ", style=RICH_STYLE_MUTED)
    body.append(f"{prediction.observations:,}\n\n", style=RICH_STYLE_BODY)

    body.append("PREDICTED RATE     ", style=RICH_STYLE_MUTED)
    body.append(
        f"{prediction.predicted_rate * 100:+,.4f}%\n",
        style=_signed_style(prediction.predicted_rate),
    )
    body.append("LOWER (95%)        ", style=RICH_STYLE_MUTED)
    body.append(
        f"{prediction.lower_bound * 100:+,.4f}%\n",
        style=_signed_style(prediction.lower_bound),
    )
    body.append("UPPER (95%)        ", style=RICH_STYLE_MUTED)
    body.append(
        f"{prediction.upper_bound * 100:+,.4f}%\n\n",
        style=_signed_style(prediction.upper_bound),
    )

    body.append(
        "Naive EWMA baseline. Do not trade on this without a real model.",
        style=RICH_STYLE_MUTED,
    )

    return Panel(
        body,
        title="funding prediction",
        title_align="left",
        border_style=RICH_STYLE_HAIRLINE,
        padding=(1, 2),
    )


# Formatters -------------------------------------------------------------------


_SIZE_UNITS = ("B", "KB", "MB", "GB", "TB")


def _format_size(n: int) -> str:
    """Human-readable byte count. Two-decimal precision above KB."""
    if n < 1024:
        return f"{n} B"
    size = float(n)
    unit_index = 0
    while size >= 1024 and unit_index < len(_SIZE_UNITS) - 1:
        size /= 1024
        unit_index += 1
    return f"{size:.2f} {_SIZE_UNITS[unit_index]}"


def _format_ms_date(ms: int) -> str:
    """Render a ms-epoch timestamp as YYYY-MM-DD. Zero renders as em-dash."""
    if ms <= 0:
        return "—"
    return datetime.fromtimestamp(ms / 1000, tz=UTC).strftime("%Y-%m-%d")


def _format_ms_datetime(ms: int) -> str:
    """Render a ms-epoch timestamp as YYYY-MM-DD HH:MM."""
    if ms <= 0:
        return "—"
    return datetime.fromtimestamp(ms / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M")


def _format_datetime(d: datetime | None) -> str:
    if d is None:
        return "—"
    return d.strftime("%Y-%m-%d %H:%M")


def _format_usd(value: float) -> str:
    """Signed USD with thousands separators and two decimals."""
    if value == 0:
        return "$0.00"
    sign = "-" if value < 0 else "+"
    return f"{sign}${abs(value):,.2f}"


def _format_num(value: float) -> str:
    """General numeric formatter: thousands separator above 1000, precision adapted."""
    if abs(value) >= 1000:
        return f"{value:,.2f}"
    if abs(value) >= 1:
        return f"{value:,.4f}"
    return f"{value:.6f}"


def _format_pct(value: float) -> str:
    """Render a unit-fraction as a signed percent with two decimals."""
    return f"{value * 100:+,.2f}%"


def _format_usd_unsigned(value: float) -> str:
    return f"${value:,.2f}"


def _format_duration_ms(ms: int) -> str:
    """Compact duration: 90d, 14h, 35m, 2s, or em-dash for zero."""
    if ms <= 0:
        return "—"
    seconds = ms / 1000
    days = seconds / 86400
    if days >= 1:
        return f"{days:.1f}d"
    hours = seconds / 3600
    if hours >= 1:
        return f"{hours:.1f}h"
    minutes = seconds / 60
    if minutes >= 1:
        return f"{minutes:.1f}m"
    return f"{seconds:.1f}s"


def _signed_style(value: float) -> str:
    if value > 0:
        return RICH_STYLE_PNL_UP
    if value < 0:
        return RICH_STYLE_PNL_DOWN
    return RICH_STYLE_BODY


def _equity_period(equity_curve: list[EquityPoint]) -> str:
    if not equity_curve:
        return "—"
    start = _format_ms_date(equity_curve[0].time)
    end = _format_ms_date(equity_curve[-1].time)
    return f"{start} → {end}"


def _format_params(params: Mapping[str, object]) -> str:
    """Render a params dict as ``k=v, k=v`` for compact display."""
    if not params:
        return "—"
    parts = []
    for key, value in params.items():
        if isinstance(value, float):
            parts.append(f"{key}={value:.4g}")
        else:
            parts.append(f"{key}={value}")
    return ", ".join(parts)


_SPARK_CHARS = "▁▂▃▄▅▆▇█"


def _sparkline(values: list[float], *, width: int = 60) -> str:
    """Render a list of values as a unicode sparkline at most ``width`` cells."""
    if not values:
        return ""
    if len(values) > width:
        step = len(values) / width
        sampled = [values[int(i * step)] for i in range(width)]
    else:
        sampled = values

    lo = min(sampled)
    hi = max(sampled)
    if hi == lo:
        return _SPARK_CHARS[len(_SPARK_CHARS) // 2] * len(sampled)

    span = hi - lo
    chars = []
    for v in sampled:
        idx = int(((v - lo) / span) * (len(_SPARK_CHARS) - 1))
        chars.append(_SPARK_CHARS[idx])
    return "".join(chars)


def _short_entity(entity: str) -> str:
    """Wallet/vault addresses are 0x + 40 hex. Compress to 0x1234…abcd."""
    if entity.startswith("0x") and len(entity) == 42:
        return f"{entity[:6]}…{entity[-4:]}"
    return entity


__all__ = [
    "CacheEntryLike",
    "CacheInfoLike",
    "account_summary",
    "backtest_metrics_table",
    "backtest_summary",
    "cache_listing",
    "cache_summary",
    "equity_sparkline_panel",
    "fills_table",
    "funding_arb_table",
    "funding_history_panel",
    "funding_prediction_panel",
    "funding_summary",
    "optimization_table",
    "positions_table",
    "render",
    "vault_asset_breakdown",
    "vault_listing",
    "vault_metrics_panel",
    "vault_summary_panel",
    "walk_forward_table",
]
