"""HTML report rendering for wallet wrapped and downstream report kinds.

Consumes a ``WrappedReport`` from ``hl_research.analytics`` and produces a
single self-contained HTML string. Plotly's bundle is embedded once at the
document head; per-chart fragments use ``include_plotlyjs=False``.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

import plotly.graph_objects as go
import plotly.offline as plotly_offline
import polars as pl
from jinja2 import Environment, PackageLoader, select_autoescape

from hl_research.__version__ import __version__
from hl_research.analytics.types import FillSummary, VaultAnalysis, WrappedReport
from hl_research.backtest.engine import BacktestResult
from hl_research.backtest.portfolio import ClosedTrade, EquityPoint
from hl_research.presentation.plots import (
    apply_plotly_theme,
    figure_to_html,
    pnl_marker_colors,
)
from hl_research.presentation.theme import COLOR

# Public API -------------------------------------------------------------------


def render_wrapped(report: WrappedReport) -> str:
    """Render a WrappedReport into a complete standalone HTML document."""
    env = _env()
    template = env.get_template("wrapped.html.j2")

    pnl_by_asset_rows = _rows(report.pnl_by_asset)

    context: dict[str, Any] = {
        "wallet_short": _short_address(report.wallet),
        "period_label": _period_label(report.period),
        "period_end_label": report.period[1].strftime("%Y-%m-%d"),
        "realized_pnl": float(report.total_realized_pnl),
        "funding_net": float(report.funding_earned - report.funding_paid),
        "win_rate": float(report.win_rate),
        "trade_count": int(report.trade_count),
        "behavior_label": _label_text(report.behavior_cluster),
        "behavior_description": report.behavior_reason,
        "chart_pnl_by_asset": _chart_pnl_by_asset(pnl_by_asset_rows),
        "chart_hour_of_day": _chart_hour_of_day(_rows(report.hour_of_day)),
        "chart_hold_time": _chart_hold_time(_rows(report.hold_time_dist)),
        "pnl_by_asset_rows": pnl_by_asset_rows,
        "funding_rows": _funding_rows(report),
        "cf_actual": float(report.counterfactual.actual_pnl),
        "cf_hold": float(report.counterfactual.hold_spot_pnl),
        "cf_delta": float(report.counterfactual.alpha_vs_hold),
        "top_wins": [_fill_row(f) for f in report.top_wins],
        "top_losses": [_fill_row(f) for f in report.top_losses],
        "version": __version__,
        "generated_at": datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC"),
        "plotly_bundle": plotly_offline.get_plotlyjs(),
    }

    return template.render(**context)


# Jinja environment ------------------------------------------------------------


def _env() -> Environment:
    env = Environment(
        loader=PackageLoader("hl_research.presentation", "templates"),
        autoescape=select_autoescape(default_for_string=True, default=True),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    env.filters["usd"] = _filter_usd
    env.filters["usd_pos"] = _filter_usd_pos
    env.filters["usd_neg"] = _filter_usd_neg
    env.filters["pct"] = _filter_pct
    env.filters["int_format"] = _filter_int
    env.filters["num"] = _filter_num
    env.globals["pnl_class"] = _pnl_class
    return env


def _filter_usd(value: float | int) -> str:
    n = float(value)
    sign = "-" if n < 0 else ("+" if n > 0 else "")
    return f"{sign}${abs(n):,.2f}"


def _filter_usd_pos(value: float | int) -> str:
    n = abs(float(value))
    return f"${n:,.2f}"


def _filter_usd_neg(value: float | int) -> str:
    n = abs(float(value))
    if n == 0:
        return "$0.00"
    return f"-${n:,.2f}"


def _filter_pct(value: float) -> str:
    return f"{float(value) * 100:,.1f}%"


def _filter_int(value: int | float) -> str:
    return f"{int(value):,}"


def _filter_num(value: float | int) -> str:
    n = float(value)
    if abs(n) >= 1000:
        return f"{n:,.2f}"
    if abs(n) >= 1:
        return f"{n:,.4f}"
    return f"{n:.6f}"


def _pnl_class(value: float | int) -> str:
    n = float(value)
    if n > 0:
        return "pnl-up"
    if n < 0:
        return "pnl-down"
    return ""


# Chart builders ---------------------------------------------------------------


def _chart_pnl_by_asset(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_chart("No closed trades in this window.")

    assets = [r["asset"] for r in rows]
    values = [float(r["realized_pnl"]) for r in rows]
    fig = go.Figure(
        data=[
            go.Bar(
                x=values,
                y=assets,
                orientation="h",
                marker={"color": pnl_marker_colors(values)},
                hovertemplate="%{y}<br>$%{x:,.2f}<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=max(180, 32 * len(rows) + 80),
        showlegend=False,
        xaxis={"title": "Realized PnL (USD)"},
        yaxis={"autorange": "reversed"},
    )
    return figure_to_html(apply_plotly_theme(fig))


def _chart_hour_of_day(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_chart("No hour-of-day data.")

    by_hour = {int(r["hour"]): r for r in rows}
    hours = list(range(24))
    counts = [int(by_hour.get(h, {}).get("trade_count", 0)) for h in hours]
    pnl = [float(by_hour.get(h, {}).get("realized_pnl", 0.0)) for h in hours]

    fig = go.Figure(
        data=[
            go.Bar(
                x=hours,
                y=counts,
                marker={"color": pnl_marker_colors(pnl)},
                hovertemplate="%{x:02d}:00<br>%{y} trades<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=220,
        showlegend=False,
        xaxis={
            "title": "Hour (UTC)",
            "tickmode": "array",
            "tickvals": [0, 4, 8, 12, 16, 20],
        },
        yaxis={"title": "Trades"},
        bargap=0.15,
    )
    return figure_to_html(apply_plotly_theme(fig))


def _chart_hold_time(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_chart("No hold-time data.")

    order = ["scalp", "intraday", "swing", "hold"]
    by_bucket = {str(r["bucket"]): int(r["trade_count"]) for r in rows}
    counts = [by_bucket.get(b, 0) for b in order]

    fig = go.Figure(
        data=[
            go.Bar(
                x=order,
                y=counts,
                marker={"color": COLOR.text_primary},
                hovertemplate="%{x}<br>%{y} trades<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=200,
        showlegend=False,
        xaxis={"title": "Hold time"},
        yaxis={"title": "Trades"},
        bargap=0.2,
    )
    return figure_to_html(apply_plotly_theme(fig))


def _empty_chart(message: str) -> str:
    fig = go.Figure()
    fig.update_layout(
        height=120,
        annotations=[
            {
                "text": message,
                "showarrow": False,
                "x": 0.5,
                "y": 0.5,
                "xref": "paper",
                "yref": "paper",
                "font": {"color": COLOR.text_tertiary, "size": 12},
            }
        ],
        xaxis={"visible": False},
        yaxis={"visible": False},
    )
    return figure_to_html(apply_plotly_theme(fig))


# Row converters ---------------------------------------------------------------


def _rows(frame: pl.DataFrame) -> list[dict[str, Any]]:
    """Materialize a Polars frame as a list of dicts for Jinja iteration."""
    if frame is None or frame.is_empty():
        return []
    return frame.to_dicts()


def _funding_rows(report: WrappedReport) -> list[dict[str, Any]]:
    """Wallet-level funding totals as a single row.

    Per-asset funding lives in a future analytics extension. Until then the
    ledger surface shows the rollup.
    """
    paid = float(report.funding_paid)
    earned = float(report.funding_earned)
    return [
        {
            "asset": "all",
            "paid": paid,
            "earned": earned,
            "net": earned - paid,
        }
    ]


def _fill_row(fill: FillSummary) -> dict[str, Any]:
    return {
        "time": fill.time.strftime("%Y-%m-%d %H:%M"),
        "asset": fill.asset,
        "side": fill.side,
        "size": float(fill.size),
        "price": float(fill.price),
        "pnl": float(fill.pnl),
    }


# Formatters -------------------------------------------------------------------


def _short_address(addr: str) -> str:
    if addr.startswith("0x") and len(addr) == 42:
        return f"{addr[:6]}…{addr[-4:]}"
    return addr


def _period_label(period: tuple[datetime, datetime]) -> str:
    start, end = period
    return f"{start.strftime('%Y-%m-%d')} → {end.strftime('%Y-%m-%d')}"


def _label_text(label: str) -> str:
    """Convert ``revenge_trader`` to ``revenge trader`` for display."""
    return label.replace("_", " ")


def render_backtest(
    result: BacktestResult,
    *,
    strategy_name: str,
    asset: str | None,
    params: Mapping[str, object] | None = None,
) -> str:
    """Render a BacktestResult into a standalone HTML document."""
    env = _env()
    template = env.get_template("backtest.html.j2")
    env.filters["pct_unsigned"] = _filter_pct_unsigned
    env.filters["num2"] = _filter_num2

    metrics = result.metrics
    equity_curve = result.equity_curve
    period_label = _equity_period_label(equity_curve)

    context: dict[str, Any] = {
        "strategy_name": strategy_name,
        "asset_label": asset or "all assets",
        "period_label": period_label,
        "params_label": _params_label(params) if params else "",
        "total_return": float(metrics.total_return),
        "sharpe": float(metrics.sharpe),
        "max_drawdown": float(metrics.max_drawdown),
        "hit_rate": float(metrics.hit_rate),
        "chart_equity": _chart_equity_curve(equity_curve),
        "chart_drawdown": _chart_drawdown(equity_curve),
        "metrics_rows": _metrics_rows(metrics),
        "closed_trades": _trade_rows(result.portfolio.closed_trades),
        "version": __version__,
        "generated_at": datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC"),
        "plotly_bundle": plotly_offline.get_plotlyjs(),
    }

    return template.render(**context)


# Backtest helpers -------------------------------------------------------------


def _filter_pct_unsigned(value: float) -> str:
    return f"{float(value) * 100:,.1f}%"


def _filter_num2(value: float | int) -> str:
    return f"{float(value):,.2f}"


def _chart_equity_curve(curve: list[EquityPoint]) -> str:
    if len(curve) < 2:
        return _empty_chart("Not enough data for an equity curve.")

    times = [datetime.fromtimestamp(p.time / 1000, tz=UTC) for p in curve]
    equity = [p.equity for p in curve]
    delta = equity[-1] - equity[0]
    line_color = COLOR.pnl_up if delta >= 0 else COLOR.pnl_down

    fig = go.Figure(
        data=[
            go.Scatter(
                x=times,
                y=equity,
                mode="lines",
                line={"color": line_color, "width": 1.5},
                hovertemplate="%{x|%Y-%m-%d}<br>$%{y:,.2f}<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=280,
        showlegend=False,
        xaxis={"title": "Time (UTC)"},
        yaxis={"title": "Equity (USD)"},
    )
    return figure_to_html(apply_plotly_theme(fig))


def _chart_drawdown(curve: list[EquityPoint]) -> str:
    if len(curve) < 2:
        return _empty_chart("Not enough data for a drawdown curve.")

    times = [datetime.fromtimestamp(p.time / 1000, tz=UTC) for p in curve]
    peak = -float("inf")
    drawdowns: list[float] = []
    for p in curve:
        peak = max(peak, p.equity)
        drawdowns.append((p.equity / peak - 1) if peak > 0 else 0.0)

    fig = go.Figure(
        data=[
            go.Scatter(
                x=times,
                y=[d * 100 for d in drawdowns],
                mode="lines",
                fill="tozeroy",
                line={"color": COLOR.pnl_down, "width": 1.25},
                fillcolor="rgba(239, 107, 107, 0.18)",
                hovertemplate="%{x|%Y-%m-%d}<br>%{y:.2f}%<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=200,
        showlegend=False,
        xaxis={"title": "Time (UTC)"},
        yaxis={"title": "Drawdown (%)", "rangemode": "tozero"},
    )
    return figure_to_html(apply_plotly_theme(fig))


def _metrics_rows(metrics: Any) -> list[dict[str, str]]:
    """Flat rows for the metrics table in the HTML report."""
    rows = [
        ("Total return", _filter_pct(metrics.total_return), _pnl_class(metrics.total_return)),
        (
            "Annualized return",
            _filter_pct(metrics.annualized_return),
            _pnl_class(metrics.annualized_return),
        ),
        ("Volatility", _filter_pct(metrics.volatility), ""),
        ("Sharpe ratio", _filter_num2(metrics.sharpe), ""),
        ("Sortino ratio", _filter_num2(metrics.sortino), ""),
        ("Calmar ratio", _filter_num2(metrics.calmar), ""),
        ("Max drawdown", _filter_pct(metrics.max_drawdown), _pnl_class(metrics.max_drawdown)),
        ("Hit rate", _filter_pct_unsigned(metrics.hit_rate), ""),
        ("Average win", _filter_usd(metrics.average_win), _pnl_class(metrics.average_win)),
        ("Average loss", _filter_usd(metrics.average_loss), _pnl_class(metrics.average_loss)),
        ("Profit factor", _filter_num2(metrics.profit_factor), ""),
        ("Trade count", _filter_int(metrics.trade_count), ""),
        ("Funding paid", _filter_usd(-metrics.funding_paid), _pnl_class(-metrics.funding_paid)),
        ("Funding earned", _filter_usd(metrics.funding_earned), _pnl_class(metrics.funding_earned)),
        ("Net funding", _filter_usd(metrics.net_funding), _pnl_class(metrics.net_funding)),
    ]
    return [{"label": label, "value": value, "css": css} for label, value, css in rows]


def _trade_rows(closed: list[ClosedTrade]) -> list[dict[str, Any]]:
    """Top 50 closed trades by absolute PnL for the HTML report."""
    sorted_trades = sorted(closed, key=lambda t: abs(t.pnl), reverse=True)[:50]
    return [
        {
            "entry_time": datetime.fromtimestamp(t.entry_time / 1000, tz=UTC).strftime(
                "%Y-%m-%d %H:%M"
            ),
            "exit_time": datetime.fromtimestamp(t.exit_time / 1000, tz=UTC).strftime(
                "%Y-%m-%d %H:%M"
            ),
            "asset": t.asset,
            "size": float(t.size),
            "hold": _format_hold(t.hold_ms),
            "pnl": float(t.pnl),
        }
        for t in sorted_trades
    ]


def _format_hold(ms: int) -> str:
    if ms <= 0:
        return "—"
    seconds = ms / 1000
    days = seconds / 86400
    if days >= 1:
        return f"{days:.1f}d"
    hours = seconds / 3600
    if hours >= 1:
        return f"{hours:.1f}h"
    return f"{seconds / 60:.1f}m"


def _equity_period_label(curve: list[EquityPoint]) -> str:
    if not curve:
        return "—"
    start = datetime.fromtimestamp(curve[0].time / 1000, tz=UTC).strftime("%Y-%m-%d")
    end = datetime.fromtimestamp(curve[-1].time / 1000, tz=UTC).strftime("%Y-%m-%d")
    return f"{start} → {end}"


def _params_label(params: Mapping[str, object]) -> str:
    if not params:
        return ""
    parts = []
    for key, value in params.items():
        if isinstance(value, float):
            parts.append(f"{key}={value:.4g}")
        else:
            parts.append(f"{key}={value}")
    return ", ".join(parts)


def render_vault(analysis: VaultAnalysis) -> str:
    """Render a VaultAnalysis into a complete standalone HTML document."""
    env = _env()
    env.filters["pct_unsigned"] = _filter_pct_unsigned
    env.filters["num2"] = _filter_num2
    template = env.get_template("vault.html.j2")

    metrics = analysis.metrics
    equity_curve = _vault_equity_points(analysis.equity_curve)

    context: dict[str, Any] = {
        "vault_name": analysis.name or "Unnamed vault",
        "vault_address": analysis.vault,
        "leader": str(analysis.leader) if analysis.leader else "",
        "leader_short": _short_address(str(analysis.leader)) if analysis.leader else "",
        "tvl": float(analysis.tvl) if analysis.tvl is not None else 0.0,
        "total_return": float(metrics.total_return),
        "sharpe": float(metrics.sharpe),
        "depositors": int(analysis.depositor_count),
        "chart_equity": _chart_vault_equity(equity_curve),
        "metrics_rows": _vault_metrics_rows(metrics),
        "asset_rows": _rows(analysis.asset_breakdown),
        "trade_rows": _vault_trade_rows(analysis.trade_list),
        "version": __version__,
        "generated_at": datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC"),
        "plotly_bundle": plotly_offline.get_plotlyjs(),
    }

    return template.render(**context)


def _vault_equity_points(frame: pl.DataFrame) -> list[tuple[int, float]]:
    """Extract ``(time_ms, equity)`` pairs from a vault equity-curve frame."""
    if frame is None or frame.is_empty():
        return []
    times = frame.get_column("time").to_list()
    equity = frame.get_column("equity").to_list()
    return [(int(t), float(e)) for t, e in zip(times, equity, strict=False)]


def _chart_vault_equity(points: list[tuple[int, float]]) -> str:
    if len(points) < 2:
        return _empty_chart("Not enough equity samples for a curve.")
    times = [datetime.fromtimestamp(p[0] / 1000, tz=UTC) for p in points]
    values = [p[1] for p in points]
    delta = values[-1] - values[0]
    line_color = COLOR.pnl_up if delta >= 0 else COLOR.pnl_down

    fig = go.Figure(
        data=[
            go.Scatter(
                x=times,
                y=values,
                mode="lines",
                line={"color": line_color, "width": 1.5},
                hovertemplate="%{x|%Y-%m-%d}<br>$%{y:,.2f}<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=280,
        showlegend=False,
        xaxis={"title": "Time (UTC)"},
        yaxis={"title": "Equity (USD)"},
    )
    return figure_to_html(apply_plotly_theme(fig))


def _vault_metrics_rows(metrics: Any) -> list[dict[str, str]]:
    rows = [
        ("Total return", _filter_pct(metrics.total_return), _pnl_class(metrics.total_return)),
        (
            "Annualized return",
            _filter_pct(metrics.annualized_return),
            _pnl_class(metrics.annualized_return),
        ),
        ("Volatility", _filter_pct(metrics.volatility), ""),
        ("Sharpe ratio", _filter_num2(metrics.sharpe), ""),
        ("Max drawdown", _filter_pct(metrics.max_drawdown), _pnl_class(metrics.max_drawdown)),
    ]
    return [{"label": label, "value": value, "css": css} for label, value, css in rows]


def _vault_trade_rows(frame: pl.DataFrame, *, limit: int = 30) -> list[dict[str, Any]]:
    if frame is None or frame.is_empty():
        return []
    rows = list(frame.iter_rows(named=True))[:limit]
    out: list[dict[str, Any]] = []
    for row in rows:
        time_ms = int(row.get("time") or 0)
        pnl = float(row.get("closed_pnl") or 0.0)
        side = str(row.get("side") or "")
        side_label = "BUY" if side == "B" else ("SELL" if side == "A" else side)
        out.append(
            {
                "time": datetime.fromtimestamp(time_ms / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M"),
                "asset": row.get("asset", "—"),
                "side": side_label,
                "size": float(row.get("size") or 0.0),
                "price": float(row.get("price") or 0.0),
                "pnl": pnl,
            }
        )
    return out


__all__ = ["render_backtest", "render_vault", "render_wrapped"]
