"""Presentation helpers for terminal, plot, and report outputs."""
