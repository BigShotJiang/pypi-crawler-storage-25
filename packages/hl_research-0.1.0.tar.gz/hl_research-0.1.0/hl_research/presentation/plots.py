"""Plot theme helpers.

Single source of truth for matplotlib and plotly visual style. Charts in
``presentation/report.py`` and downstream notebooks consume these helpers
rather than touching ``rcParams`` or ``Layout`` directly.
"""

from __future__ import annotations

from typing import Any

import matplotlib as mpl
import plotly.graph_objects as go

from hl_research.presentation.theme import COLOR, PALETTE, TYPE

# Matplotlib ------------------------------------------------------------------


_MPL_RC: dict[str, Any] = {
    "figure.facecolor": COLOR.background,
    "axes.facecolor": COLOR.background,
    "axes.edgecolor": COLOR.hairline,
    "axes.labelcolor": COLOR.text_primary,
    "axes.titlecolor": COLOR.text_primary,
    "xtick.color": COLOR.text_secondary,
    "ytick.color": COLOR.text_secondary,
    "text.color": COLOR.text_primary,
    "grid.color": COLOR.surface,
    "grid.linestyle": "-",
    "grid.linewidth": 0.5,
    "font.family": "sans-serif",
    "font.sans-serif": ["Inter", "Helvetica", "Arial", "sans-serif"],
    "font.size": float(TYPE.body_size),
    "lines.linewidth": 1.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "savefig.facecolor": COLOR.background,
    "savefig.edgecolor": COLOR.background,
    "savefig.transparent": False,
    "savefig.dpi": 144,
}


def apply_matplotlib_theme() -> None:
    """Install hl-research matplotlib defaults. Idempotent."""
    mpl.rcParams.update(_MPL_RC)


# Plotly ----------------------------------------------------------------------


_PLOTLY_LAYOUT: dict[str, Any] = {
    "paper_bgcolor": COLOR.background,
    "plot_bgcolor": COLOR.background,
    "font": {
        "family": TYPE.body_family,
        "size": TYPE.body_size + 2,
        "color": COLOR.text_primary,
    },
    "xaxis": {
        "gridcolor": COLOR.surface,
        "linecolor": COLOR.hairline,
        "tickcolor": COLOR.hairline,
        "tickfont": {"color": COLOR.text_secondary},
        "title": {"font": {"color": COLOR.text_secondary}},
        "zeroline": False,
    },
    "yaxis": {
        "gridcolor": COLOR.surface,
        "linecolor": COLOR.hairline,
        "tickcolor": COLOR.hairline,
        "tickfont": {"color": COLOR.text_secondary},
        "title": {"font": {"color": COLOR.text_secondary}},
        "zeroline": False,
    },
    "margin": {"l": 48, "r": 16, "t": 24, "b": 40},
    "hoverlabel": {
        "bgcolor": COLOR.surface,
        "bordercolor": COLOR.hairline,
        "font": {"family": TYPE.mono_family, "color": COLOR.text_primary},
    },
    "colorway": [
        PALETTE.mint,
        COLOR.text_primary,
        PALETTE.teal_deep,
        PALETTE.coral,
    ],
    "legend": {
        "bgcolor": COLOR.background,
        "bordercolor": COLOR.hairline,
        "borderwidth": 0,
        "font": {"color": COLOR.text_secondary},
    },
}


def apply_plotly_theme(fig: go.Figure) -> go.Figure:
    """Return ``fig`` with hl-research plotly defaults applied."""
    fig.update_layout(**_PLOTLY_LAYOUT)
    return fig


def pnl_marker_colors(values: list[float]) -> list[str]:
    """Map each value to the mint (positive) or coral (negative) accent."""
    return [PALETTE.mint if v >= 0 else PALETTE.coral for v in values]


def figure_to_html(fig: go.Figure, *, include_plotlyjs: bool | str = False) -> str:
    """Render a plotly figure as an HTML fragment.

    Default ``include_plotlyjs=False`` produces a fragment suitable for embedding
    inside a template that already loads the plotly bundle. Pass ``"inline"``
    only when the fragment must stand alone.
    """
    html: str = fig.to_html(
        include_plotlyjs=include_plotlyjs,
        full_html=False,
        config={"displayModeBar": False, "responsive": True},
    )
    return html


__all__ = [
    "apply_matplotlib_theme",
    "apply_plotly_theme",
    "pnl_marker_colors",
    "figure_to_html",
]
