"""Local-first quantitative research toolkit for Hyperliquid."""

from hl_research.__version__ import __version__

__all__ = ["__version__"]
