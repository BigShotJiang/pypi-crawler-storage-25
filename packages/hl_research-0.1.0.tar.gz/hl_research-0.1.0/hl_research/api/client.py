"""HTTP client primitives for the Hyperliquid info API."""

from __future__ import annotations

import asyncio
import random
import time
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Self, cast

import httpx

from hl_research.api.errors import HLHTTPError, HLNetworkError, HLRateLimitError

DEFAULT_BASE_URL = "https://api.hyperliquid.xyz"
INFO_PATH = "/info"


@dataclass(frozen=True)
class RetryConfig:
    """Retry configuration for transient API failures."""

    max_attempts: int = 5
    base_delay: float = 0.25
    max_delay: float = 8.0
    jitter: float = 0.1


class TokenBucket:
    """Async token bucket that blocks until capacity is available."""

    def __init__(self, capacity: int, refill_per_second: float) -> None:
        if capacity <= 0:
            msg = "capacity must be positive"
            raise ValueError(msg)
        if refill_per_second <= 0:
            msg = "refill_per_second must be positive"
            raise ValueError(msg)
        self._capacity = float(capacity)
        self._tokens = float(capacity)
        self._refill_per_second = refill_per_second
        self._updated_at = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, weight: int = 1) -> None:
        """Block until `weight` tokens are available."""
        if weight <= 0:
            msg = "weight must be positive"
            raise ValueError(msg)
        if weight > self._capacity:
            msg = "weight cannot exceed token bucket capacity"
            raise ValueError(msg)

        while True:
            async with self._lock:
                now = time.monotonic()
                elapsed = now - self._updated_at
                self._tokens = min(self._capacity, self._tokens + elapsed * self._refill_per_second)
                self._updated_at = now
                if self._tokens >= weight:
                    self._tokens -= weight
                    return
                missing = weight - self._tokens
                wait_for = missing / self._refill_per_second
            await asyncio.sleep(wait_for)


class AsyncInfoHTTPClient:
    """Async HTTP wrapper for the Hyperliquid info endpoint."""

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        rate_limit: int = 1200,
        timeout: float = 30.0,
        retry: RetryConfig | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._retry = retry or RetryConfig()
        self._bucket = TokenBucket(capacity=rate_limit, refill_per_second=rate_limit / 60)
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=httpx.Timeout(timeout, connect=min(timeout, 10.0)),
            headers={"Content-Type": "application/json"},
            transport=transport,
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def post_info(self, payload: Mapping[str, object], weight: int = 20) -> object:
        """POST a JSON payload to `/info` and return decoded JSON."""
        await self._bucket.acquire(weight)
        last_network_error: httpx.HTTPError | None = None

        for attempt in range(1, self._retry.max_attempts + 1):
            try:
                response = await self._client.post(INFO_PATH, json=dict(payload))
            except httpx.HTTPError as exc:
                last_network_error = exc
                if attempt == self._retry.max_attempts:
                    break
                await self._sleep_before_retry(attempt)
                continue

            if response.status_code == 429:
                retry_after = _retry_after_seconds(response.headers)
                if attempt == self._retry.max_attempts:
                    raise HLRateLimitError("Hyperliquid rate limit exhausted.", retry_after)
                await asyncio.sleep(retry_after or self._retry_delay(attempt))
                continue

            if 500 <= response.status_code <= 599:
                if attempt == self._retry.max_attempts:
                    raise HLHTTPError(
                        response.status_code,
                        f"Hyperliquid server error: HTTP {response.status_code}.",
                        _safe_json(response),
                    )
                await self._sleep_before_retry(attempt)
                continue

            if 400 <= response.status_code <= 499:
                raise HLHTTPError(
                    response.status_code,
                    f"Hyperliquid request failed: HTTP {response.status_code}.",
                    _safe_json(response),
                )

            return response.json()

        raise HLNetworkError(
            "Hyperliquid network request failed after retries."
        ) from last_network_error

    async def _sleep_before_retry(self, attempt: int) -> None:
        await asyncio.sleep(self._retry_delay(attempt))

    def _retry_delay(self, attempt: int) -> float:
        delay: float = min(self._retry.max_delay, self._retry.base_delay * 2 ** (attempt - 1))
        jitter: float = random.random() * self._retry.jitter
        return delay + jitter


def _safe_json(response: httpx.Response) -> object | None:
    try:
        return cast(object, response.json())
    except ValueError:
        return response.text


def _retry_after_seconds(headers: httpx.Headers) -> float | None:
    value = headers.get("Retry-After")
    if value is None:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None
