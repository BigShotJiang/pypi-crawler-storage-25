"""Typed clients and models for the Hyperliquid info API."""
