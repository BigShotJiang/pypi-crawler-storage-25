"""Exception hierarchy for Hyperliquid API access."""

from typing import Any


class HLAPIError(Exception):
    """Base exception for Hyperliquid API failures."""


class HLHTTPError(HLAPIError):
    """Raised for non-retryable HTTP errors."""

    def __init__(self, status_code: int, message: str, payload: object | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class HLRateLimitError(HLAPIError):
    """Raised when the API rate limit cannot be recovered by retrying."""

    def __init__(self, message: str, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class HLNetworkError(HLAPIError):
    """Raised when the API cannot be reached after retries."""


class HLResponseError(HLAPIError):
    """Raised when Hyperliquid returns a malformed or unexpected response."""

    def __init__(self, message: str, raw_payload: Any) -> None:
        super().__init__(message)
        self.raw_payload = raw_payload


class HLValidationError(HLResponseError):
    """Raised when response validation fails."""
