"""Pydantic models for Hyperliquid info API responses."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, RootModel

type Address = str
type Interval = Literal[
    "1m",
    "3m",
    "5m",
    "15m",
    "30m",
    "1h",
    "2h",
    "4h",
    "8h",
    "12h",
    "1d",
    "3d",
    "1w",
    "1M",
]
type Side = Literal["A", "B"]


class HLModel(BaseModel):
    """Base model that tolerates additive fields from the Hyperliquid API."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class UniverseAsset(HLModel):
    """Perpetual asset metadata returned by `meta`."""

    name: str
    sz_decimals: int = Field(alias="szDecimals")
    max_leverage: int = Field(alias="maxLeverage")
    only_isolated: bool = Field(default=False, alias="onlyIsolated")
    is_delisted: bool = Field(default=False, alias="isDelisted")


class MarginTier(HLModel):
    """Margin tier metadata."""

    lower_bound: str = Field(alias="lowerBound")
    max_leverage: int = Field(alias="maxLeverage")


class MarginTable(HLModel):
    """Margin table metadata."""

    description: str = ""
    margin_tiers: list[MarginTier] = Field(default_factory=list, alias="marginTiers")


class Meta(HLModel):
    """Universe metadata for tradeable perpetual assets."""

    universe: list[UniverseAsset]
    margin_tables: list[tuple[int, MarginTable]] = Field(default_factory=list, alias="marginTables")


class AssetContext(HLModel):
    """Real-time context for one perpetual asset."""

    day_ntl_vlm: float | None = Field(default=None, alias="dayNtlVlm")
    funding: float | None = None
    impact_pxs: list[float] | None = Field(default=None, alias="impactPxs")
    mark_px: float | None = Field(default=None, alias="markPx")
    mid_px: float | None = Field(default=None, alias="midPx")
    open_interest: float | None = Field(default=None, alias="openInterest")
    oracle_px: float | None = Field(default=None, alias="oraclePx")
    premium: float | None = None
    prev_day_px: float | None = Field(default=None, alias="prevDayPx")


class MetaAndAssetCtxs(RootModel[tuple[Meta, list[AssetContext]]]):
    """Combined `metaAndAssetCtxs` response."""

    @property
    def meta(self) -> Meta:
        """Return the metadata half of the response."""
        return self.root[0]

    @property
    def contexts(self) -> list[AssetContext]:
        """Return the asset context half of the response."""
        return self.root[1]


class MarginSummary(HLModel):
    """Account margin summary."""

    account_value: float = Field(alias="accountValue")
    total_margin_used: float = Field(alias="totalMarginUsed")
    total_ntl_pos: float = Field(alias="totalNtlPos")
    total_raw_usd: float = Field(alias="totalRawUsd")


class Leverage(HLModel):
    """Position leverage settings."""

    type: str
    value: int
    raw_usd: float | None = Field(default=None, alias="rawUsd")


class Position(HLModel):
    """Open position details."""

    coin: str
    cum_funding: dict[str, float] = Field(default_factory=dict, alias="cumFunding")
    entry_px: float | None = Field(default=None, alias="entryPx")
    leverage: Leverage | None = None
    liquidation_px: float | None = Field(default=None, alias="liquidationPx")
    margin_used: float | None = Field(default=None, alias="marginUsed")
    max_leverage: int | None = Field(default=None, alias="maxLeverage")
    position_value: float | None = Field(default=None, alias="positionValue")
    return_on_equity: float | None = Field(default=None, alias="returnOnEquity")
    szi: float
    unrealized_pnl: float | None = Field(default=None, alias="unrealizedPnl")


class AssetPosition(HLModel):
    """Position wrapper returned by `clearinghouseState`."""

    position: Position
    type: str


class ClearinghouseState(HLModel):
    """Current account state for one wallet."""

    asset_positions: list[AssetPosition] = Field(default_factory=list, alias="assetPositions")
    cross_margin_summary: MarginSummary = Field(alias="crossMarginSummary")
    margin_summary: MarginSummary = Field(alias="marginSummary")
    time: int
    withdrawable: float


class Fill(HLModel):
    """User fill record."""

    coin: str
    px: float
    sz: float
    side: Side
    time: int
    start_position: float | None = Field(default=None, alias="startPosition")
    dir: str
    closed_pnl: float | None = Field(default=None, alias="closedPnl")
    hash: str
    oid: int
    crossed: bool
    fee: float
    tid: int
    fee_token: str | None = Field(default=None, alias="feeToken")
    liquidation: bool = False


class FundingRate(HLModel):
    """Historical funding rate record."""

    coin: str
    funding_rate: float = Field(alias="fundingRate")
    premium: float
    time: int


class FundingDelta(HLModel):
    """Nested funding payment delta."""

    coin: str
    funding_rate: float = Field(alias="fundingRate")
    szi: float
    usdc: float


class FundingPayment(HLModel):
    """User funding payment record."""

    time: int
    hash: str
    delta: FundingDelta


class OrderDetails(HLModel):
    """Historical order details."""

    coin: str
    side: Side
    limit_px: float = Field(alias="limitPx")
    sz: float
    oid: int
    timestamp: int
    orig_sz: float | None = Field(default=None, alias="origSz")
    cloid: str | None = None


class Order(HLModel):
    """Historical order wrapper."""

    order: OrderDetails
    status: str
    status_timestamp: int = Field(alias="statusTimestamp")


class Candle(HLModel):
    """OHLCV candle returned by `candleSnapshot`."""

    open_time: int = Field(alias="t")
    close_time: int = Field(alias="T")
    coin: str = Field(alias="s")
    interval: Interval = Field(alias="i")
    open: float = Field(alias="o")
    close: float = Field(alias="c")
    high: float = Field(alias="h")
    low: float = Field(alias="l")
    volume: float = Field(alias="v")
    trade_count: int = Field(default=0, alias="n")


class Trade(HLModel):
    """Recent public trade."""

    coin: str
    side: Side
    px: float
    sz: float
    time: int
    hash: str
    tid: int
    users: list[Address] = Field(default_factory=list)


class VaultTrade(Fill):
    """Vault trade record normalized to the fill shape."""


class BookLevel(HLModel):
    """One L2 book price level."""

    px: float
    sz: float
    n: int


class Book(HLModel):
    """Current L2 book snapshot."""

    coin: str
    time: int
    levels: tuple[list[BookLevel], list[BookLevel]]


class VaultFollower(HLModel):
    """Vault follower summary."""

    user: Address
    vault_equity: float | None = Field(default=None, alias="vaultEquity")
    pnl: float | None = None
    all_time_pnl: float | None = Field(default=None, alias="allTimePnl")
    days_following: int | None = Field(default=None, alias="daysFollowing")


class VaultPortfolioEntry(HLModel):
    """Vault portfolio time-series entry."""

    time: int
    account_value_history: list[tuple[int, float]] = Field(
        default_factory=list, alias="accountValueHistory"
    )
    pnl_history: list[tuple[int, float]] = Field(default_factory=list, alias="pnlHistory")
    vlm: float | None = None


class VaultDetails(HLModel):
    """Detailed vault state."""

    name: str
    vault_address: Address = Field(alias="vaultAddress")
    leader: Address
    description: str = ""
    portfolio: list[VaultPortfolioEntry] = Field(default_factory=list)
    followers: list[VaultFollower] = Field(default_factory=list)
    max_distributable: float | None = Field(default=None, alias="maxDistributable")
    max_withdrawable: float | None = Field(default=None, alias="maxWithdrawable")
    is_closed: bool = Field(default=False, alias="isClosed")
    relationship: dict[str, object] | None = None
    allow_deposits: bool = Field(default=True, alias="allowDeposits")
    always_close_on_withdraw: bool = Field(default=False, alias="alwaysCloseOnWithdraw")


class VaultSummary(HLModel):
    """Vault summary row."""

    name: str
    vault_address: Address = Field(alias="vaultAddress")
    leader: Address
    tvl: float | None = None
    apr: float | None = None
    follower_state: str | None = Field(default=None, alias="followerState")
    is_closed: bool = Field(default=False, alias="isClosed")
    relationship: dict[str, object] | None = None
