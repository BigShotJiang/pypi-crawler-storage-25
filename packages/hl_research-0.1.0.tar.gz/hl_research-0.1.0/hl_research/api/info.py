"""Typed info endpoint methods for Hyperliquid."""

from typing import TypeVar, cast

import httpx
from pydantic import TypeAdapter, ValidationError

from hl_research.api.client import DEFAULT_BASE_URL, AsyncInfoHTTPClient, RetryConfig
from hl_research.api.errors import HLValidationError
from hl_research.api.types import (
    Address,
    Book,
    Candle,
    ClearinghouseState,
    Fill,
    FundingPayment,
    FundingRate,
    Interval,
    Meta,
    MetaAndAssetCtxs,
    Order,
    Trade,
    VaultDetails,
    VaultSummary,
)

T = TypeVar("T")


class InfoClient:
    """Typed async client for Hyperliquid info requests."""

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        rate_limit: int = 1200,
        timeout: float = 30.0,
        retry: RetryConfig | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._http = AsyncInfoHTTPClient(
            base_url=base_url,
            rate_limit=rate_limit,
            timeout=timeout,
            retry=retry,
            transport=transport,
        )

    async def __aenter__(self) -> "InfoClient":
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def meta(self) -> Meta:
        """Fetch perpetual universe metadata."""
        return await self._post_model({"type": "meta"}, Meta)

    async def meta_and_asset_ctxs(self) -> MetaAndAssetCtxs:
        """Fetch universe metadata plus real-time asset contexts."""
        return await self._post_model({"type": "metaAndAssetCtxs"}, MetaAndAssetCtxs)

    async def clearinghouse_state(self, user: Address) -> ClearinghouseState:
        """Fetch current clearinghouse state for a wallet."""
        return await self._post_model(
            {"type": "clearinghouseState", "user": user},
            ClearinghouseState,
            weight=2,
        )

    async def user_fills(self, user: Address, aggregate_by_time: bool = False) -> list[Fill]:
        """Fetch recent fills for a wallet."""
        payload: dict[str, object] = {"type": "userFills", "user": user}
        if aggregate_by_time:
            payload["aggregateByTime"] = True
        return await self._post_model(payload, list[Fill])

    async def user_fills_by_time(
        self,
        user: Address,
        start: int,
        end: int | None = None,
        aggregate_by_time: bool = False,
    ) -> list[Fill]:
        """Fetch fills for a wallet starting at a timestamp."""
        payload: dict[str, object] = {"type": "userFillsByTime", "user": user, "startTime": start}
        if end is not None:
            payload["endTime"] = end
        if aggregate_by_time:
            payload["aggregateByTime"] = True
        return await self._post_model(payload, list[Fill])

    async def user_funding(
        self, user: Address, start: int, end: int | None = None
    ) -> list[FundingPayment]:
        """Fetch funding payments for a wallet."""
        payload: dict[str, object] = {"type": "userFunding", "user": user, "startTime": start}
        if end is not None:
            payload["endTime"] = end
        return await self._post_model(payload, list[FundingPayment])

    async def historical_orders(self, user: Address) -> list[Order]:
        """Fetch recent historical orders for a wallet."""
        return await self._post_model({"type": "historicalOrders", "user": user}, list[Order])

    async def candle_snapshot(
        self, coin: str, interval: Interval, start: int, end: int
    ) -> list[Candle]:
        """Fetch OHLCV candles for an asset and interval."""
        payload = {
            "type": "candleSnapshot",
            "coin": coin,
            "interval": interval,
            "startTime": start,
            "endTime": end,
        }
        return await self._post_model(payload, list[Candle], weight=20)

    async def funding_history(
        self, coin: str, start: int, end: int | None = None
    ) -> list[FundingRate]:
        """Fetch historical funding rates for an asset."""
        payload: dict[str, object] = {"type": "fundingHistory", "coin": coin, "startTime": start}
        if end is not None:
            payload["endTime"] = end
        return await self._post_model(payload, list[FundingRate])

    async def recent_trades(self, coin: str) -> list[Trade]:
        """Fetch recent public trades for an asset."""
        return await self._post_model({"type": "recentTrades", "coin": coin}, list[Trade])

    async def l2_snapshot(self, coin: str) -> Book:
        """Fetch the current L2 book snapshot for an asset."""
        return await self._post_model({"type": "l2Book", "coin": coin}, Book, weight=2)

    async def vault_details(self, vault: Address) -> VaultDetails:
        """Fetch detailed state for a vault."""
        return await self._post_model(
            {"type": "vaultDetails", "vaultAddress": vault},
            VaultDetails,
        )

    async def vault_summaries(self) -> list[VaultSummary]:
        """Fetch all vault summaries."""
        return await self._post_model({"type": "vaultSummaries"}, list[VaultSummary])

    async def _post_model(self, payload: dict[str, object], target: object, weight: int = 20) -> T:
        raw = await self._http.post_info(payload, weight=weight)
        try:
            return cast(T, TypeAdapter(target).validate_python(raw))
        except ValidationError as exc:
            message = f"Invalid Hyperliquid response for {payload['type']}."
            raise HLValidationError(message, raw) from exc
