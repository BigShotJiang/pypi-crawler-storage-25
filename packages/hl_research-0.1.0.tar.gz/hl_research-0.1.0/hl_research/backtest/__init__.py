"""Backtest engine primitives."""
