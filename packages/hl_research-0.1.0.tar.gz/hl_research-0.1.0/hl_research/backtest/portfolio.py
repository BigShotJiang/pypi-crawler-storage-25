"""Portfolio accounting for backtests."""

from __future__ import annotations

from dataclasses import dataclass, field

from hl_research.backtest.strategy import Fill, PositionView


@dataclass
class Position:
    """Mutable portfolio position."""

    asset: str
    size: float = 0.0
    average_price: float = 0.0
    realized_pnl: float = 0.0


@dataclass(frozen=True)
class ClosedTrade:
    """Closed position segment used for metrics."""

    asset: str
    entry_time: int
    exit_time: int
    size: float
    pnl: float

    @property
    def hold_ms(self) -> int:
        """Return hold duration in milliseconds."""
        return self.exit_time - self.entry_time


@dataclass(frozen=True)
class EquityPoint:
    """One mark-to-market portfolio point."""

    time: int
    equity: float
    cash: float


@dataclass
class Portfolio:
    """Position tracking and PnL accounting."""

    initial_cash: float
    cash: float | None = None
    positions: dict[str, Position] = field(default_factory=dict)
    closed_trades: list[ClosedTrade] = field(default_factory=list)
    funding_paid: float = 0.0
    funding_earned: float = 0.0
    _entry_times: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.cash is None:
            self.cash = self.initial_cash

    def apply_fill(self, fill: Fill) -> None:
        """Apply a simulated fill to cash and position state."""
        signed_delta = fill.order.size if fill.order.side == "buy" else -fill.order.size
        position = self.positions.setdefault(fill.order.asset, Position(asset=fill.order.asset))
        cash = self._cash()
        cash -= signed_delta * fill.fill_price
        cash -= fill.fee
        self.cash = cash

        if position.size == 0 or _same_sign(position.size, signed_delta):
            self._increase(position, signed_delta, fill)
            return

        self._reduce_or_flip(position, signed_delta, fill)

    def apply_funding(self, asset: str, rate: float, mark_price: float) -> float:
        """Apply funding to an open position and return signed cash flow."""
        position = self.positions.get(asset)
        if position is None or position.size == 0:
            return 0.0
        payment = -position.size * mark_price * rate
        self.cash = self._cash() + payment
        if payment < 0:
            self.funding_paid += abs(payment)
        else:
            self.funding_earned += payment
        return payment

    def equity(self, marks: dict[str, float]) -> float:
        """Return mark-to-market equity."""
        unrealized = 0.0
        for asset, position in self.positions.items():
            mark = marks.get(asset, position.average_price)
            unrealized += position.size * mark
        return self._cash() + unrealized

    def position_views(self) -> dict[str, PositionView]:
        """Return read-only position views for strategy context."""
        return {
            asset: PositionView(
                asset=asset,
                size=position.size,
                average_price=position.average_price,
                realized_pnl=position.realized_pnl,
            )
            for asset, position in self.positions.items()
        }

    def _increase(self, position: Position, signed_delta: float, fill: Fill) -> None:
        previous_abs = abs(position.size)
        delta_abs = abs(signed_delta)
        if previous_abs == 0:
            position.average_price = fill.fill_price
            self._entry_times[position.asset] = fill.fill_time
        else:
            position.average_price = (
                position.average_price * previous_abs + fill.fill_price * delta_abs
            ) / (previous_abs + delta_abs)
        position.size += signed_delta

    def _reduce_or_flip(self, position: Position, signed_delta: float, fill: Fill) -> None:
        closing_size = min(abs(position.size), abs(signed_delta))
        direction = 1.0 if position.size > 0 else -1.0
        pnl = (fill.fill_price - position.average_price) * closing_size * direction
        position.realized_pnl += pnl
        entry_time = self._entry_times.get(position.asset, fill.fill_time)
        self.closed_trades.append(
            ClosedTrade(
                asset=position.asset,
                entry_time=entry_time,
                exit_time=fill.fill_time,
                size=closing_size,
                pnl=pnl,
            )
        )

        position.size += signed_delta
        if abs(position.size) < 1e-12:
            position.size = 0.0
            position.average_price = 0.0
            self._entry_times.pop(position.asset, None)
        elif not _same_sign(position.size, direction):
            position.average_price = fill.fill_price
            self._entry_times[position.asset] = fill.fill_time

    def _cash(self) -> float:
        if self.cash is None:
            return self.initial_cash
        return self.cash


def _same_sign(left: float, right: float) -> bool:
    return (left > 0 and right > 0) or (left < 0 and right < 0)
