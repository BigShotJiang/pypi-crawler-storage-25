"""Strategy base classes and contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Protocol

from hl_research.api.types import Interval

type OrderSide = Literal["buy", "sell"]
type OrderKind = Literal["market", "limit", "stop"]
type ParamValue = bool | int | float | str


@dataclass(frozen=True)
class Candle:
    """Backtest candle event."""

    asset: str
    interval: Interval
    open_time: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True)
class FundingTick:
    """Backtest funding event."""

    asset: str
    time: int
    rate: float
    premium: float


@dataclass(frozen=True)
class Order:
    """Strategy order request."""

    asset: str
    side: OrderSide
    size: float
    kind: OrderKind
    price: float | None = None
    reduce_only: bool = False


@dataclass(frozen=True)
class Fill:
    """Simulated fill for an order."""

    order: Order
    fill_price: float
    fill_time: int
    fee: float


@dataclass(frozen=True)
class PositionView:
    """Read-only position exposed to strategies."""

    asset: str
    size: float
    average_price: float
    realized_pnl: float


class BacktestLogger(Protocol):
    """Small logger protocol for strategy contexts."""

    def info(self, message: str) -> None:
        """Record an informational message."""


@dataclass
class ListLogger:
    """In-memory logger used by default in backtests."""

    messages: list[str] = field(default_factory=list)

    def info(self, message: str) -> None:
        """Append an informational message."""
        self.messages.append(message)


@dataclass
class BacktestContext:
    """Mutable strategy context owned by the engine."""

    cash: float
    equity: float
    params: dict[str, ParamValue] = field(default_factory=dict)
    logger: BacktestLogger = field(default_factory=ListLogger)
    positions: dict[str, PositionView] = field(default_factory=dict)

    def position(self, asset: str) -> PositionView:
        """Return current position for an asset or a flat placeholder."""
        return self.positions.get(
            asset,
            PositionView(asset=asset, size=0.0, average_price=0.0, realized_pnl=0.0),
        )


class Strategy:
    """Base class for backtest strategies.

    Subclasses override hooks and return orders. State should live in `ctx`
    rather than on the strategy instance so optimization can instantiate cleanly.
    """

    def on_start(self, ctx: BacktestContext) -> None:
        """Run once before the first event."""

    def on_candle(self, candle: Candle, ctx: BacktestContext) -> list[Order]:
        """Handle one candle and optionally return orders."""
        return []

    def on_funding(self, tick: FundingTick, ctx: BacktestContext) -> list[Order]:
        """Handle one funding tick and optionally return orders."""
        return []

    def on_fill(self, fill: Fill, ctx: BacktestContext) -> None:
        """Handle one simulated fill."""

    def on_end(self, ctx: BacktestContext) -> None:
        """Run once after the final event."""
