"""Backtest parameter search."""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass
from typing import Protocol

from hl_research.backtest.engine import BacktestData, BacktestResult, run_backtest
from hl_research.backtest.strategy import ParamValue, Strategy


class Distribution(Protocol):
    """Random-search distribution protocol."""

    def sample(self, rng: random.Random) -> ParamValue:
        """Sample one parameter value."""


@dataclass(frozen=True)
class ChoiceDistribution:
    """Discrete parameter distribution."""

    values: list[ParamValue]

    def sample(self, rng: random.Random) -> ParamValue:
        """Sample one value."""
        return rng.choice(self.values)


@dataclass(frozen=True)
class OptimizationRun:
    """One optimization trial."""

    params: dict[str, ParamValue]
    metric_value: float
    result: BacktestResult


@dataclass(frozen=True)
class OptimizationResult:
    """Optimizer output."""

    metric: str
    best: OptimizationRun
    runs: list[OptimizationRun]


def grid_search(
    strategy_cls: type[Strategy],
    param_grid: dict[str, list[ParamValue]],
    data: BacktestData,
    metric: str = "sharpe",
    initial_cash: float = 100_000.0,
) -> OptimizationResult:
    """Run a single-process grid search."""
    names = list(param_grid)
    runs: list[OptimizationRun] = []
    for values in itertools.product(*(param_grid[name] for name in names)):
        params = dict(zip(names, values, strict=True))
        result = run_backtest(strategy_cls, data, params=params, initial_cash=initial_cash)
        runs.append(_optimization_run(params, result, metric))
    return _optimization_result(metric, runs)


def random_search(
    strategy_cls: type[Strategy],
    param_dist: dict[str, Distribution],
    n: int,
    data: BacktestData,
    metric: str = "sharpe",
    seed: int | None = None,
    initial_cash: float = 100_000.0,
) -> OptimizationResult:
    """Run a single-process random search."""
    rng = random.Random(seed)
    runs: list[OptimizationRun] = []
    for _index in range(n):
        params = {name: dist.sample(rng) for name, dist in param_dist.items()}
        result = run_backtest(strategy_cls, data, params=params, initial_cash=initial_cash)
        runs.append(_optimization_run(params, result, metric))
    return _optimization_result(metric, runs)


def _optimization_run(
    params: dict[str, ParamValue],
    result: BacktestResult,
    metric: str,
) -> OptimizationRun:
    return OptimizationRun(
        params=params,
        metric_value=float(getattr(result.metrics, metric)),
        result=result,
    )


def _optimization_result(metric: str, runs: list[OptimizationRun]) -> OptimizationResult:
    if not runs:
        msg = "optimizer requires at least one run"
        raise ValueError(msg)
    best = max(runs, key=lambda run: run.metric_value)
    return OptimizationResult(metric=metric, best=best, runs=runs)
