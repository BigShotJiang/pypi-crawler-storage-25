"""Backtest metric calculations."""

from __future__ import annotations

import math
from dataclasses import dataclass

from hl_research.backtest.portfolio import ClosedTrade, EquityPoint, Portfolio

MS_PER_YEAR = 365 * 24 * 60 * 60 * 1_000


@dataclass(frozen=True)
class BacktestMetrics:
    """Performance metrics computed from an equity curve and closed trades."""

    total_return: float
    annualized_return: float
    volatility: float
    sharpe: float
    sortino: float
    calmar: float
    max_drawdown: float
    drawdown_duration_ms: int
    hit_rate: float
    average_win: float
    average_loss: float
    profit_factor: float
    trade_count: int
    average_hold_ms: float
    funding_paid: float
    funding_earned: float
    net_funding: float


def compute_metrics(
    equity_curve: list[EquityPoint],
    closed_trades: list[ClosedTrade],
    portfolio: Portfolio,
) -> BacktestMetrics:
    """Compute v0 backtest metrics."""
    returns = _period_returns(equity_curve)
    total_return = _total_return(equity_curve)
    annualized = _annualized_return(equity_curve, total_return)
    volatility = _sample_std(returns) * math.sqrt(365) if returns else 0.0
    downside = [value for value in returns if value < 0]
    downside_vol = _sample_std(downside) * math.sqrt(365) if downside else 0.0
    max_drawdown, drawdown_duration = _drawdown(equity_curve)
    wins = [trade.pnl for trade in closed_trades if trade.pnl > 0]
    losses = [trade.pnl for trade in closed_trades if trade.pnl < 0]
    gross_win = sum(wins)
    gross_loss = abs(sum(losses))

    return BacktestMetrics(
        total_return=total_return,
        annualized_return=annualized,
        volatility=volatility,
        sharpe=annualized / volatility if volatility else 0.0,
        sortino=annualized / downside_vol if downside_vol else 0.0,
        calmar=annualized / abs(max_drawdown) if max_drawdown else 0.0,
        max_drawdown=max_drawdown,
        drawdown_duration_ms=drawdown_duration,
        hit_rate=len(wins) / len(closed_trades) if closed_trades else 0.0,
        average_win=sum(wins) / len(wins) if wins else 0.0,
        average_loss=sum(losses) / len(losses) if losses else 0.0,
        profit_factor=gross_win / gross_loss if gross_loss else 0.0,
        trade_count=len(closed_trades),
        average_hold_ms=(
            sum(trade.hold_ms for trade in closed_trades) / len(closed_trades)
            if closed_trades
            else 0.0
        ),
        funding_paid=portfolio.funding_paid,
        funding_earned=portfolio.funding_earned,
        net_funding=portfolio.funding_earned - portfolio.funding_paid,
    )


def _total_return(equity_curve: list[EquityPoint]) -> float:
    if len(equity_curve) < 2:
        return 0.0
    first = equity_curve[0].equity
    last = equity_curve[-1].equity
    return (last / first) - 1 if first else 0.0


def _annualized_return(equity_curve: list[EquityPoint], total_return: float) -> float:
    if len(equity_curve) < 2:
        return 0.0
    elapsed = equity_curve[-1].time - equity_curve[0].time
    if elapsed <= 0:
        return 0.0
    years = elapsed / MS_PER_YEAR
    return (1 + total_return) ** (1 / years) - 1 if total_return > -1 else -1.0


def _period_returns(equity_curve: list[EquityPoint]) -> list[float]:
    returns: list[float] = []
    for previous, current in zip(equity_curve, equity_curve[1:], strict=False):
        if previous.equity:
            returns.append((current.equity / previous.equity) - 1)
    return returns


def _sample_std(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance)


def _drawdown(equity_curve: list[EquityPoint]) -> tuple[float, int]:
    peak = -math.inf
    peak_time = 0
    max_drawdown = 0.0
    max_duration = 0
    for point in equity_curve:
        if point.equity >= peak:
            peak = point.equity
            peak_time = point.time
        if peak > 0:
            drawdown = (point.equity / peak) - 1
            if drawdown < max_drawdown:
                max_drawdown = drawdown
                max_duration = point.time - peak_time
    return max_drawdown, max_duration
