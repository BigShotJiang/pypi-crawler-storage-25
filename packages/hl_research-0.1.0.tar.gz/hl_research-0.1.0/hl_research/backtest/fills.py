"""Candle-based fill simulation.

v0 fill model assumptions:

- Market orders fill on the next candle open with fixed slippage.
- Limit orders fill when the next candle range crosses the limit price.
- Stop orders trigger when the next candle range crosses the stop, then fill
  like market orders using the candle open plus slippage.
- There is no partial fill, queue-position, latency, or book-impact model.
"""

from dataclasses import dataclass

from hl_research.backtest.strategy import Candle, Fill, Order


@dataclass(frozen=True)
class FillModel:
    """Candle-range fill simulator."""

    taker_fee_rate: float = 0.00045
    maker_fee_rate: float = 0.00015
    slippage_bps: float = 0.5

    def simulate(self, order: Order, candle: Candle) -> Fill | None:
        """Simulate one order against one candle."""
        if order.size <= 0:
            return None
        if order.kind == "market":
            price = self._slipped_price(order.side, candle.open)
            return self._fill(order, price, candle.open_time, self.taker_fee_rate)
        if order.kind == "limit":
            if order.price is None or not (candle.low <= order.price <= candle.high):
                return None
            return self._fill(order, order.price, candle.open_time, self.maker_fee_rate)
        if order.kind == "stop":
            if order.price is None or not (candle.low <= order.price <= candle.high):
                return None
            price = self._slipped_price(order.side, candle.open)
            return self._fill(order, price, candle.open_time, self.taker_fee_rate)
        return None

    def _slipped_price(self, side: str, price: float) -> float:
        slippage = self.slippage_bps / 10_000
        return price * (1 + slippage) if side == "buy" else price * (1 - slippage)

    def _fill(self, order: Order, price: float, fill_time: int, fee_rate: float) -> Fill:
        return Fill(
            order=order,
            fill_price=price,
            fill_time=fill_time,
            fee=abs(order.size * price) * fee_rate,
        )
