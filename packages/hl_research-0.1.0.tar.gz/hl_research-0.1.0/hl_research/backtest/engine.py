"""Backtest event loop driver."""

from __future__ import annotations

from dataclasses import dataclass, field

import polars as pl

from hl_research.backtest.fills import FillModel
from hl_research.backtest.metrics import BacktestMetrics, compute_metrics
from hl_research.backtest.portfolio import EquityPoint, Portfolio
from hl_research.backtest.strategy import (
    BacktestContext,
    Candle,
    Fill,
    FundingTick,
    Order,
    ParamValue,
    Strategy,
)


@dataclass(frozen=True)
class BacktestData:
    """Input data for a backtest run."""

    candles: pl.DataFrame
    funding: pl.DataFrame = field(default_factory=pl.DataFrame)


@dataclass(frozen=True)
class BacktestResult:
    """Complete output of a backtest run."""

    equity_curve: list[EquityPoint]
    fills: list[Fill]
    orders: list[Order]
    metrics: BacktestMetrics
    portfolio: Portfolio


class BacktestEngine:
    """Drive candle and funding events through a strategy."""

    def __init__(
        self,
        initial_cash: float = 100_000.0,
        fill_model: FillModel | None = None,
    ) -> None:
        self._initial_cash = initial_cash
        self._fill_model = fill_model or FillModel()

    def run(
        self,
        strategy: Strategy,
        data: BacktestData,
        params: dict[str, ParamValue] | None = None,
    ) -> BacktestResult:
        """Run a strategy over sorted candle and funding events."""
        candles = _candles_from_frame(data.candles)
        funding = _funding_from_frame(data.funding)
        funding_by_time = _group_funding(funding)
        portfolio = Portfolio(initial_cash=self._initial_cash)
        ctx = BacktestContext(
            cash=self._initial_cash,
            equity=self._initial_cash,
            params=params or {},
        )
        pending: list[Order] = []
        orders: list[Order] = []
        fills: list[Fill] = []
        marks: dict[str, float] = {}
        equity_curve: list[EquityPoint] = []

        strategy.on_start(ctx)
        for candle in candles:
            simulated = [self._fill_model.simulate(order, candle) for order in pending]
            pending = []
            for fill in [item for item in simulated if item is not None]:
                portfolio.apply_fill(fill)
                fills.append(fill)
                _sync_context(ctx, portfolio, marks)
                strategy.on_fill(fill, ctx)

            marks[candle.asset] = candle.close
            for tick in funding_by_time.get(candle.open_time, []):
                portfolio.apply_funding(tick.asset, tick.rate, marks.get(tick.asset, candle.close))
                _sync_context(ctx, portfolio, marks)
                new_orders = strategy.on_funding(tick, ctx)
                orders.extend(new_orders)
                pending.extend(new_orders)

            _sync_context(ctx, portfolio, marks)
            new_orders = strategy.on_candle(candle, ctx)
            orders.extend(new_orders)
            pending.extend(new_orders)
            equity_curve.append(
                EquityPoint(
                    time=candle.open_time,
                    equity=portfolio.equity(marks),
                    cash=portfolio.cash or portfolio.initial_cash,
                )
            )

        _sync_context(ctx, portfolio, marks)
        strategy.on_end(ctx)
        metrics = compute_metrics(equity_curve, portfolio.closed_trades, portfolio)
        return BacktestResult(
            equity_curve=equity_curve,
            fills=fills,
            orders=orders,
            metrics=metrics,
            portfolio=portfolio,
        )


def run_backtest(
    strategy_cls: type[Strategy],
    data: BacktestData,
    params: dict[str, ParamValue] | None = None,
    initial_cash: float = 100_000.0,
) -> BacktestResult:
    """Instantiate and run a strategy class."""
    engine = BacktestEngine(initial_cash=initial_cash)
    return engine.run(strategy_cls(), data, params=params)


def _sync_context(ctx: BacktestContext, portfolio: Portfolio, marks: dict[str, float]) -> None:
    ctx.cash = portfolio.cash or portfolio.initial_cash
    ctx.equity = portfolio.equity(marks)
    ctx.positions = portfolio.position_views()


def _candles_from_frame(frame: pl.DataFrame) -> list[Candle]:
    return [
        Candle(
            asset=str(row["asset"]),
            interval=row["interval"],
            open_time=int(row["open_time"]),
            open=float(row["open"]),
            high=float(row["high"]),
            low=float(row["low"]),
            close=float(row["close"]),
            volume=float(row["volume"]),
        )
        for row in frame.sort("open_time").iter_rows(named=True)
    ]


def _funding_from_frame(frame: pl.DataFrame) -> list[FundingTick]:
    if frame.is_empty():
        return []
    return [
        FundingTick(
            asset=str(row["asset"]),
            time=int(row["time"]),
            rate=float(row["funding_rate"]),
            premium=float(row["premium"]),
        )
        for row in frame.sort("time").iter_rows(named=True)
    ]


def _group_funding(funding: list[FundingTick]) -> dict[int, list[FundingTick]]:
    grouped: dict[int, list[FundingTick]] = {}
    for tick in funding:
        grouped.setdefault(tick.time, []).append(tick)
    return grouped
