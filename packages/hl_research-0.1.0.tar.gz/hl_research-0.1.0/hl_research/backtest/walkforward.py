"""Walk-forward backtest analysis."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

import polars as pl

from hl_research.backtest.engine import BacktestData, BacktestResult, run_backtest
from hl_research.backtest.strategy import ParamValue, Strategy


@dataclass(frozen=True)
class WalkForwardWindow:
    """One walk-forward test window."""

    start_ms: int
    end_ms: int
    result: BacktestResult


@dataclass(frozen=True)
class WalkForwardResult:
    """Walk-forward result across rolling windows."""

    windows: list[WalkForwardWindow]


def walk_forward(
    strategy_cls: type[Strategy],
    params: dict[str, ParamValue],
    data: BacktestData,
    window: timedelta,
    step: timedelta,
    initial_cash: float = 100_000.0,
) -> WalkForwardResult:
    """Run a strategy on rolling out-of-sample windows."""
    if data.candles.is_empty():
        return WalkForwardResult(windows=[])
    start = int(data.candles.select(pl.col("open_time").min()).item())
    end = int(data.candles.select(pl.col("open_time").max()).item())
    window_ms = int(window.total_seconds() * 1000)
    step_ms = int(step.total_seconds() * 1000)
    if window_ms <= 0 or step_ms <= 0:
        msg = "window and step must be positive"
        raise ValueError(msg)

    windows: list[WalkForwardWindow] = []
    cursor = start
    while cursor + window_ms <= end + 1:
        window_end = cursor + window_ms
        candles = data.candles.filter(
            (pl.col("open_time") >= cursor) & (pl.col("open_time") < window_end)
        )
        funding = (
            data.funding.filter((pl.col("time") >= cursor) & (pl.col("time") < window_end))
            if not data.funding.is_empty()
            else data.funding
        )
        result = run_backtest(
            strategy_cls,
            BacktestData(candles=candles, funding=funding),
            params=params,
            initial_cash=initial_cash,
        )
        windows.append(WalkForwardWindow(start_ms=cursor, end_ms=window_end, result=result))
        cursor += step_ms
    return WalkForwardResult(windows=windows)
