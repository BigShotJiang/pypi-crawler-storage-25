"""Textual application package."""
