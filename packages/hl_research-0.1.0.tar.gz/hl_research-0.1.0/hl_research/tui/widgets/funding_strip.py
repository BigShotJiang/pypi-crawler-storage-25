"""Funding strip widget."""
