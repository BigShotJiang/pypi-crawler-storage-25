"""Asset picker modal.

A fuzzy-find palette opened from any screen. Pressing ``/`` pushes this modal
and the selected value is dismissed back to the caller.
"""

from __future__ import annotations

from collections.abc import Sequence

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, ListItem, ListView, Static


class AssetPicker(ModalScreen[str]):
    """Modal fuzzy-find palette. Returns the selected label or ``None`` on cancel."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("enter", "accept", "Select"),
    ]

    def __init__(self, options: Sequence[str], title: str = "select") -> None:
        super().__init__()
        self._options = list(options)
        self._filtered: list[str] = list(self._options)
        self._title = title

    def compose(self) -> ComposeResult:
        with Vertical(id="picker"):
            yield Static(self._title.upper(), classes="picker-title")
            yield Input(placeholder="type to filter…", id="picker-input")
            yield ListView(
                *(ListItem(Static(opt)) for opt in self._options),
                id="picker-list",
            )

    def on_mount(self) -> None:
        self.query_one("#picker-input", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        query = event.value.lower().strip()
        if not query:
            self._filtered = list(self._options)
        else:
            self._filtered = [opt for opt in self._options if query in opt.lower()]

        list_view = self.query_one("#picker-list", ListView)
        list_view.clear()
        for opt in self._filtered:
            list_view.append(ListItem(Static(opt)))

    def action_accept(self) -> None:
        if not self._filtered:
            return
        list_view = self.query_one("#picker-list", ListView)
        index = list_view.index or 0
        self.dismiss(self._filtered[index])

    def action_cancel(self) -> None:
        self.dismiss(None)


__all__ = ["AssetPicker"]
