"""Candle chart widget."""
