"""Textual application entry point.

Two-pane layout: navigation column on the left, content area on the right.
Each view holds an instance of a ScreenModel from ``tui/screens/`` and
renders its reactive attributes. All views render at 80x24 minimum.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import ContentSwitcher, DataTable, Footer, Header, Input, Static

from hl_research.__version__ import __version__
from hl_research.cache.store import Cache
from hl_research.tui.screens.backtest import BacktestScreenModel
from hl_research.tui.screens.funding import FundingScreenModel
from hl_research.tui.screens.home import HomeScreenModel
from hl_research.tui.screens.settings import SettingsScreenModel
from hl_research.tui.screens.vault import VaultScreenModel
from hl_research.tui.screens.wallet import WalletScreenModel
from hl_research.tui.widgets.asset_picker import AssetPicker

_NAV_ITEMS: list[tuple[str, str, str]] = [
    ("home", "Home", "1"),
    ("wallet", "Wallet", "2"),
    ("funding", "Funding", "3"),
    ("vault", "Vault", "4"),
    ("backtest", "Backtest", "5"),
    ("settings", "Settings", "6"),
]


# Navigation column ------------------------------------------------------------


class NavItem(Static):
    """One row in the navigation column."""

    def __init__(self, key: str, label: str, shortcut: str) -> None:
        super().__init__()
        self._key = key
        self._label = label
        self._shortcut = shortcut
        self.set_class(False, "-active")

    def render(self) -> str:
        return f"[bold]{self._shortcut}[/bold]  {self._label}"


class NavColumn(Vertical):
    """Left navigation column with section list."""

    active: reactive[str] = reactive("home")

    def compose(self) -> ComposeResult:
        yield Static("HL-RESEARCH", classes="nav-eyebrow")
        for key, label, shortcut in _NAV_ITEMS:
            item = NavItem(key, label, shortcut)
            item.add_class("nav-item")
            item.id = f"nav-{key}"
            yield item

    def watch_active(self, new_value: str) -> None:
        for key, _label, _shortcut in _NAV_ITEMS:
            item = self.query_one(f"#nav-{key}", NavItem)
            item.set_class(key == new_value, "-active")


# Home view --------------------------------------------------------------------


class HomeView(VerticalScroll):
    """Home dashboard: cache summary, asset and vault counts."""

    def __init__(self) -> None:
        super().__init__()
        self.model = HomeScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("home", classes="view-title")
        with Container(classes="card"):
            yield Static("CACHE SUMMARY", classes="card-title")
            yield Static("loading…", id="home-summary", classes="muted")
        with Container(classes="card"):
            yield Static("CACHED ASSETS", classes="card-title")
            yield DataTable(id="home-assets", show_cursor=False)
        with Container(classes="card"):
            yield Static("CACHED VAULTS", classes="card-title")
            yield DataTable(id="home-vaults", show_cursor=False)
        yield Static(
            "Tip: press 1-6 to switch sections, / to open the picker, ? for help.",
            classes="hint",
        )

    async def on_mount(self) -> None:
        assets = self.query_one("#home-assets", DataTable)
        assets.add_columns("ASSET", "MAX LEV", "ONLY ISOLATED")
        vaults = self.query_one("#home-vaults", DataTable)
        vaults.add_columns("NAME", "ADDRESS", "TVL")
        self.watch(self.model, "summary", self._render_summary, init=False)
        self.watch(self.model, "assets", self._render_assets, init=False)
        self.watch(self.model, "vaults", self._render_vaults, init=False)
        await self.model.load()

    def _render_summary(self, summary: Any) -> None:
        widget = self.query_one("#home-summary", Static)
        if summary is None:
            widget.update("loading…")
            return
        widget.update(
            f"datasets: {summary.dataset_count:,}    "
            f"rows: {summary.total_rows:,}    "
            f"size: {_format_bytes(summary.total_size_bytes)}    "
            f"assets: {summary.asset_count:,}    "
            f"vaults: {summary.vault_count:,}"
        )

    def _render_assets(self, frame: Any) -> None:
        table = self.query_one("#home-assets", DataTable)
        table.clear()
        if frame is None or frame.is_empty():
            return
        for row in list(frame.iter_rows(named=True))[:30]:
            table.add_row(
                str(row.get("name", "—")),
                str(row.get("max_leverage", "—")),
                "yes" if row.get("only_isolated") else "no",
            )

    def _render_vaults(self, frame: Any) -> None:
        table = self.query_one("#home-vaults", DataTable)
        table.clear()
        if frame is None or frame.is_empty():
            return
        for row in list(frame.iter_rows(named=True))[:30]:
            tvl = row.get("tvl")
            tvl_text = f"${float(tvl):,.0f}" if tvl is not None else "—"
            table.add_row(
                str(row.get("name") or "—"),
                _short_address(str(row.get("address") or "")),
                tvl_text,
            )


# Wallet view ------------------------------------------------------------------


class WalletView(VerticalScroll):
    """Wallet view: paste an address, see summary + fill count."""

    def __init__(self) -> None:
        super().__init__()
        self.model = WalletScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("wallet", classes="view-title")
        with Container(classes="card"):
            yield Static("ADDRESS", classes="card-title")
            yield Input(placeholder="0x…", id="wallet-input")
        with Container(classes="card"):
            yield Static("SUMMARY", classes="card-title")
            yield Static(
                "Paste a wallet address and press Enter.", id="wallet-summary", classes="muted"
            )
        with Container(classes="card"):
            yield Static("RECENT FILLS", classes="card-title")
            yield DataTable(id="wallet-fills", show_cursor=False)

    async def on_mount(self) -> None:
        table = self.query_one("#wallet-fills", DataTable)
        table.add_columns("TIME", "ASSET", "SIDE", "PRICE", "SIZE", "PNL")
        self.watch(self.model, "summary", self._render_summary, init=False)
        self.watch(self.model, "fills", self._render_fills, init=False)
        self.watch(self.model, "error", self._render_error, init=False)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "wallet-input":
            return
        address = event.value.strip().lower()
        if not address.startswith("0x") or len(address) != 42:
            self.query_one("#wallet-summary", Static).update(
                "[red]Invalid address. Expected 42-character hex starting with 0x.[/red]"
            )
            return
        self.query_one("#wallet-summary", Static).update("loading…")
        await self.model.load(address)

    def _render_summary(self, summary: Any) -> None:
        widget = self.query_one("#wallet-summary", Static)
        if summary is None:
            return
        pnl_style = "green" if summary.realized_pnl >= 0 else "red"
        widget.update(
            f"address: {_short_address(summary.address)}    "
            f"fills: {summary.fill_count:,}    "
            f"assets: {summary.asset_count:,}    "
            f"realized: [{pnl_style}]{_signed_usd(summary.realized_pnl)}[/{pnl_style}]"
        )

    def _render_fills(self, frame: Any) -> None:
        table = self.query_one("#wallet-fills", DataTable)
        table.clear()
        if frame is None or frame.is_empty():
            return
        rows = list(frame.iter_rows(named=True))[-30:]
        rows.reverse()
        for row in rows:
            pnl = row.get("closed_pnl") or 0.0
            table.add_row(
                _ms_to_short(int(row.get("time") or 0)),
                str(row.get("asset", "—")),
                "BUY" if row.get("side") == "B" else "SELL",
                f"{float(row.get('price') or 0):,.4f}",
                f"{float(row.get('size') or 0):,.4f}",
                _signed_usd(float(pnl)),
            )

    def _render_error(self, err: Any) -> None:
        if err is None:
            return
        self.query_one("#wallet-summary", Static).update(f"[red]{err.message}[/red]")


# Funding view -----------------------------------------------------------------


class FundingView(VerticalScroll):
    """Funding history + prediction for one asset."""

    def __init__(self) -> None:
        super().__init__()
        self.model = FundingScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("funding", classes="view-title")
        with Container(classes="card"):
            yield Static("ASSET", classes="card-title")
            yield Input(placeholder="BTC", id="funding-input")
        with Container(classes="card"):
            yield Static("HISTORY", classes="card-title")
            yield Static(
                "Pick an asset to load funding history.", id="funding-summary", classes="muted"
            )
        with Container(classes="card"):
            yield Static("PREDICTION", classes="card-title")
            yield Static("—", id="funding-prediction", classes="muted")

    async def on_mount(self) -> None:
        self.watch(self.model, "history", self._render_history, init=False)
        self.watch(self.model, "prediction", self._render_prediction, init=False)
        self.watch(self.model, "error", self._render_error, init=False)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "funding-input":
            return
        asset = event.value.strip().upper()
        if not asset:
            return
        self.query_one("#funding-summary", Static).update("loading…")
        await self.model.load(asset)

    def _render_history(self, frame: Any) -> None:
        widget = self.query_one("#funding-summary", Static)
        if frame is None or frame.is_empty():
            widget.update("[dim]No cached funding for this asset.[/dim]")
            return
        rates = frame.get_column("funding_rate").to_list()
        latest = float(rates[-1])
        mean = sum(rates) / len(rates)
        widget.update(
            f"observations: {len(rates):,}    "
            f"latest: {latest * 100:+,.4f}%    "
            f"mean: {mean * 100:+,.4f}%"
        )

    def _render_prediction(self, prediction: Any) -> None:
        widget = self.query_one("#funding-prediction", Static)
        if prediction is None:
            widget.update("—")
            return
        widget.update(
            f"predicted: {prediction.predicted_rate * 100:+,.4f}%    "
            f"band: ±{prediction.confidence_band * 100:,.4f}%    "
            f"[dim]naive EWMA baseline[/dim]"
        )

    def _render_error(self, err: Any) -> None:
        if err is None:
            return
        self.query_one("#funding-summary", Static).update(f"[red]{err.message}[/red]")


# Vault view -------------------------------------------------------------------


class VaultView(VerticalScroll):
    """Vault list + inspect."""

    def __init__(self) -> None:
        super().__init__()
        self.model = VaultScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("vault", classes="view-title")
        with Container(classes="card"):
            yield Static("VAULT ADDRESS", classes="card-title")
            yield Input(placeholder="0x…", id="vault-input")
        with Container(classes="card"):
            yield Static("CACHED VAULTS", classes="card-title")
            yield DataTable(id="vault-list", show_cursor=False)
        with Container(classes="card"):
            yield Static("ANALYSIS", classes="card-title")
            yield Static(
                "Paste a vault address or pick from the list above.",
                id="vault-summary",
                classes="muted",
            )

    async def on_mount(self) -> None:
        table = self.query_one("#vault-list", DataTable)
        table.add_columns("NAME", "ADDRESS", "TVL", "APR")
        self.watch(self.model, "summaries", self._render_summaries, init=False)
        self.watch(self.model, "analysis", self._render_analysis, init=False)
        self.watch(self.model, "error", self._render_error, init=False)
        await self.model.load()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "vault-input":
            return
        addr = event.value.strip().lower()
        if not addr.startswith("0x") or len(addr) != 42:
            self.query_one("#vault-summary", Static).update("[red]Invalid vault address.[/red]")
            return
        self.query_one("#vault-summary", Static).update("loading…")
        await self.model.load(addr)

    def _render_summaries(self, frame: Any) -> None:
        table = self.query_one("#vault-list", DataTable)
        table.clear()
        if frame is None or frame.is_empty():
            return
        for row in list(frame.iter_rows(named=True))[:30]:
            tvl = row.get("tvl")
            apr = row.get("apr")
            table.add_row(
                str(row.get("name") or "—"),
                _short_address(str(row.get("address") or "")),
                f"${float(tvl):,.0f}" if tvl is not None else "—",
                f"{float(apr) * 100:+,.2f}%" if apr is not None else "—",
            )

    def _render_analysis(self, analysis: Any) -> None:
        widget = self.query_one("#vault-summary", Static)
        if analysis is None:
            return
        m = analysis.metrics
        ret_style = "green" if m.total_return >= 0 else "red"
        dd_style = "red" if m.max_drawdown < 0 else "white"
        widget.update(
            f"name: {analysis.name or '—'}\n"
            f"depositors: {analysis.depositor_count:,}\n"
            f"total return: [{ret_style}]{m.total_return * 100:+,.2f}%[/{ret_style}]    "
            f"sharpe: {m.sharpe:,.2f}    "
            f"drawdown: [{dd_style}]{m.max_drawdown * 100:+,.2f}%[/{dd_style}]"
        )

    def _render_error(self, err: Any) -> None:
        if err is None:
            return
        self.query_one("#vault-summary", Static).update(f"[red]{err.message}[/red]")


# Backtest view ----------------------------------------------------------------


class BacktestView(VerticalScroll):
    """Backtest preview: load cached data, show what's available.

    Full strategy loading and execution lives in the CLI for v0. The TUI
    surfaces what's already cached and points at the CLI for actual runs.
    """

    def __init__(self) -> None:
        super().__init__()
        self.model = BacktestScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("backtest", classes="view-title")
        with Container(classes="card"):
            yield Static("LOAD CACHED DATA", classes="card-title")
            yield Input(placeholder="asset (e.g. BTC)", id="backtest-input")
        with Container(classes="card"):
            yield Static("CACHED INPUTS", classes="card-title")
            yield Static(
                "Pick an asset to inspect cached candles and funding.",
                id="backtest-summary",
                classes="muted",
            )
        with Container(classes="card"):
            yield Static("RUN", classes="card-title")
            yield Static(
                "Strategy execution from the TUI lands in v0.2. "
                "For now, use `hlr backtest run <strategy.py>` from your shell.",
                classes="muted",
            )

    async def on_mount(self) -> None:
        self.watch(self.model, "candles", self._render_summary, init=False)
        self.watch(self.model, "error", self._render_error, init=False)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "backtest-input":
            return
        asset = event.value.strip().upper()
        if not asset:
            return
        self.query_one("#backtest-summary", Static).update("loading…")
        await self.model.load_data(asset)

    def _render_summary(self, frame: Any) -> None:
        widget = self.query_one("#backtest-summary", Static)
        if frame is None or frame.is_empty():
            widget.update("[dim]No cached candles for this asset.[/dim]")
            return
        first = int(frame.select("open_time").to_series().min() or 0)
        last = int(frame.select("open_time").to_series().max() or 0)
        funding_rows = int(self.model.funding.height) if self.model.funding is not None else 0
        widget.update(
            f"candles: {frame.height:,}    "
            f"funding ticks: {funding_rows:,}\n"
            f"range: {_ms_to_short(first)} → {_ms_to_short(last)}"
        )

    def _render_error(self, err: Any) -> None:
        if err is None:
            return
        self.query_one("#backtest-summary", Static).update(f"[red]{err.message}[/red]")


# Settings view ----------------------------------------------------------------


class SettingsView(VerticalScroll):
    """Settings + key reference."""

    def __init__(self) -> None:
        super().__init__()
        self.model = SettingsScreenModel()

    def compose(self) -> ComposeResult:
        yield Static("settings", classes="view-title")
        with Container(classes="card"):
            yield Static("ENVIRONMENT", classes="card-title")
            yield Static("loading…", id="settings-state", classes="muted")
        with Container(classes="card"):
            yield Static("KEY BINDINGS", classes="card-title")
            yield Static(
                "1-6      Switch between sections "
                "(Home, Wallet, Funding, Vault, Backtest, Settings)\n"
                "/        Open the asset picker palette\n"
                "?        Show this help overlay\n"
                "r        Reload data for the active view\n"
                "q        Quit",
                classes="muted",
            )

    async def on_mount(self) -> None:
        self.watch(self.model, "state", self._render_state, init=False)
        await self.model.load()

    def _render_state(self, state: Any) -> None:
        widget = self.query_one("#settings-state", Static)
        if state is None:
            return
        widget.update(
            f"cache directory: {state.cache_dir}\n"
            f"datasets: {state.dataset_count:,}    "
            f"size: {_format_bytes(state.total_size_bytes)}\n"
            f"version: hl-research {__version__}"
        )


# App --------------------------------------------------------------------------


class HLResearchApp(App[None]):
    """hl-research interactive TUI."""

    CSS_PATH = "styles.tcss"
    TITLE = "hl-research"
    SUB_TITLE = f"v{__version__}"

    BINDINGS = [
        Binding("1", "switch('home')", "Home"),
        Binding("2", "switch('wallet')", "Wallet"),
        Binding("3", "switch('funding')", "Funding"),
        Binding("4", "switch('vault')", "Vault"),
        Binding("5", "switch('backtest')", "Backtest"),
        Binding("6", "switch('settings')", "Settings"),
        Binding("r", "reload", "Reload"),
        Binding("slash", "picker", "Picker"),
        Binding("q", "quit", "Quit"),
    ]

    def __init__(self, cache_dir: Path | None = None) -> None:
        super().__init__()
        self._cache = Cache(cache_dir)
        self._views: dict[str, Widget] = {}

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Horizontal(id="root"):
            yield NavColumn(id="nav")
            with ContentSwitcher(id="content", initial="home"):
                yield self._make_view("home", HomeView())
                yield self._make_view("wallet", WalletView())
                yield self._make_view("funding", FundingView())
                yield self._make_view("vault", VaultView())
                yield self._make_view("backtest", BacktestView())
                yield self._make_view("settings", SettingsView())
        yield Footer()

    def _make_view(self, key: str, widget: Widget) -> Widget:
        widget.id = key
        self._views[key] = widget
        if hasattr(widget, "model"):
            widget.model.cache = self._cache
        return widget

    def action_switch(self, target: str) -> None:
        switcher = self.query_one("#content", ContentSwitcher)
        switcher.current = target
        nav = self.query_one(NavColumn)
        nav.active = target

    async def action_reload(self) -> None:
        current = self.query_one("#content", ContentSwitcher).current
        if current is None:
            return
        view = self._views.get(current)
        if view is None:
            return
        loader = getattr(view, "on_mount", None)
        if loader is not None:
            await loader()

    async def action_picker(self) -> None:
        options = self._picker_options()
        if not options:
            self.notify("Nothing to pick yet. Pull data first.", severity="warning")
            return

        def on_dismiss(value: str | None) -> None:
            if value is None:
                return
            self._apply_pick(value)

        await self.push_screen(AssetPicker(options, title="select"), on_dismiss)

    def _picker_options(self) -> list[str]:
        entries = self._cache.list()
        return sorted({entry.entity for entry in entries if entry.kind in {"candles", "funding"}})

    def _apply_pick(self, value: str) -> None:
        current = self.query_one("#content", ContentSwitcher).current
        if current == "funding":
            inp = self.query_one("#funding-input", Input)
            inp.value = value
        elif current == "backtest":
            inp = self.query_one("#backtest-input", Input)
            inp.value = value


def run(cache_dir: Path | None = None) -> None:
    """Entry point for ``hlr tui``."""
    HLResearchApp(cache_dir=cache_dir).run()


# Helpers ----------------------------------------------------------------------


def _format_bytes(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    size = float(n)
    units = ("KB", "MB", "GB", "TB")
    idx = 0
    while size >= 1024 and idx < len(units) - 1:
        size /= 1024
        idx += 1
    return f"{size:.2f} {units[idx]}"


def _signed_usd(value: float) -> str:
    if value == 0:
        return "$0.00"
    sign = "-" if value < 0 else "+"
    return f"{sign}${abs(value):,.2f}"


def _ms_to_short(ms: int) -> str:
    from datetime import UTC, datetime

    if ms <= 0:
        return "—"
    return datetime.fromtimestamp(ms / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M")


def _short_address(addr: str) -> str:
    if addr.startswith("0x") and len(addr) == 42:
        return f"{addr[:6]}…{addr[-4:]}"
    return addr


__all__ = ["HLResearchApp", "run"]
