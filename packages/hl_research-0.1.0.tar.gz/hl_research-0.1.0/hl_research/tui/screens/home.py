"""Home TUI screen models."""

from dataclasses import dataclass

import polars as pl
from textual.reactive import reactive

from hl_research.cache.store import CacheEntry
from hl_research.tui.screens._models import LoadError, ScreenModel, load_in_thread


@dataclass(frozen=True)
class HomeSummary:
    """Summary values for the TUI home screen."""

    dataset_count: int
    total_rows: int
    total_size_bytes: int
    asset_count: int
    vault_count: int


class HomeScreenModel(ScreenModel):
    """Reactive data source for the Home screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    summary = reactive[HomeSummary | None](None)
    cache_entries = reactive[list[CacheEntry]](list)
    assets = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    vaults = reactive[pl.DataFrame](pl.DataFrame, always_update=True)

    async def load(self) -> None:
        """Load cache summary, universe metadata, and vault summaries."""
        self.loading = True
        self.error = None
        try:
            summary, entries, assets, vaults = await load_in_thread(self._load)
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.summary = summary
            self.cache_entries = entries
            self.assets = assets
            self.vaults = vaults
        finally:
            self.loading = False

    def _load(self) -> tuple[HomeSummary, list[CacheEntry], pl.DataFrame, pl.DataFrame]:
        entries = self.cache.list()
        assets = self.cache.read_assets()
        vaults = self.cache.read_vault_summaries()
        summary = HomeSummary(
            dataset_count=len(entries),
            total_rows=sum(entry.row_count for entry in entries),
            total_size_bytes=sum(entry.size_bytes for entry in entries),
            asset_count=assets.height,
            vault_count=vaults.height,
        )
        return summary, entries, assets, vaults
