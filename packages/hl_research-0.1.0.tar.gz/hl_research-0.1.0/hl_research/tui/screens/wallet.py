"""Wallet TUI screen models."""

from dataclasses import dataclass

import polars as pl
from textual.reactive import reactive

from hl_research.analytics.types import WrappedReport
from hl_research.analytics.wrapped import build_wrapped
from hl_research.api.types import Address, Interval
from hl_research.tui.screens._models import (
    LoadError,
    ScreenModel,
    empty_funding_payments,
    load_in_thread,
)


@dataclass(frozen=True)
class WalletSummary:
    """Compact wallet summary for the TUI."""

    address: Address
    fill_count: int
    asset_count: int
    realized_pnl: float


class WalletScreenModel(ScreenModel):
    """Reactive data source for the Wallet screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    address = reactive[Address | None](None)
    summary = reactive[WalletSummary | None](None)
    fills = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    wrapped = reactive[WrappedReport | None](None)

    async def load(self, address: Address, interval: Interval = "1h") -> None:
        """Load wallet fills and wrapped analytics from cache."""
        self.loading = True
        self.error = None
        self.address = address
        try:
            summary, fills, wrapped = await load_in_thread(lambda: self._load(address, interval))
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.summary = summary
            self.fills = fills
            self.wrapped = wrapped
        finally:
            self.loading = False

    def _load(
        self, address: Address, interval: Interval
    ) -> tuple[WalletSummary, pl.DataFrame, WrappedReport]:
        fills = self.cache.read_fills(address).collect().sort("time")
        assets = (
            sorted(fills.get_column("asset").unique().to_list()) if not fills.is_empty() else []
        )
        candles = {asset: self.cache.read_candles(str(asset), interval) for asset in assets}
        funding = empty_funding_payments().lazy()
        summary = WalletSummary(
            address=address,
            fill_count=fills.height,
            asset_count=len(assets),
            realized_pnl=_sum_column(fills, "closed_pnl"),
        )
        wrapped = build_wrapped(fills.lazy(), funding, candles, address)
        return summary, fills, wrapped


def _sum_column(frame: pl.DataFrame, column: str) -> float:
    if frame.is_empty() or column not in frame.columns:
        return 0.0
    return float(frame.select(pl.col(column).sum()).item() or 0.0)
