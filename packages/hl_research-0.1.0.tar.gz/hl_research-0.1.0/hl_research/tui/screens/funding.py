"""Funding TUI screen models."""

import polars as pl
from textual.reactive import reactive

from hl_research.analytics.funding_arb import perp_perp_basis
from hl_research.analytics.funding_predict import predict_next_funding
from hl_research.analytics.types import FundingBasisResult, FundingPrediction
from hl_research.tui.screens._models import LoadError, ScreenModel, load_in_thread


class FundingScreenModel(ScreenModel):
    """Reactive data source for the Funding screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    asset = reactive[str | None](None)
    reference_asset = reactive[str | None](None)
    history = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    prediction = reactive[FundingPrediction | None](None)
    basis = reactive[FundingBasisResult | None](None)
    heatmap = reactive[pl.DataFrame](pl.DataFrame, always_update=True)

    async def load(self, asset: str, reference_asset: str | None = None) -> None:
        """Load funding history, EWMA prediction, optional basis, and heatmap data."""
        self.loading = True
        self.error = None
        self.asset = asset
        self.reference_asset = reference_asset
        try:
            history, prediction, basis, heatmap = await load_in_thread(
                lambda: self._load(asset, reference_asset)
            )
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.history = history
            self.prediction = prediction
            self.basis = basis
            self.heatmap = heatmap
        finally:
            self.loading = False

    def _load(
        self, asset: str, reference_asset: str | None
    ) -> tuple[pl.DataFrame, FundingPrediction, FundingBasisResult | None, pl.DataFrame]:
        history = self.cache.read_funding(asset).collect().sort("time")
        prediction = predict_next_funding(history, asset)
        basis = None
        if reference_asset is not None:
            reference = self.cache.read_funding(reference_asset).collect().sort("time")
            basis = perp_perp_basis(history, reference, asset, reference_asset)
        return history, prediction, basis, self._heatmap()

    def _heatmap(self) -> pl.DataFrame:
        frames: list[pl.DataFrame] = []
        for entry in self.cache.list():
            if entry.kind != "funding":
                continue
            frame = self.cache.read_funding(entry.entity).collect()
            if frame.is_empty():
                continue
            frames.append(
                frame.select(
                    pl.lit(entry.entity).alias("asset"),
                    pl.col("time"),
                    pl.col("funding_rate"),
                )
            )
        return pl.concat(frames) if frames else _empty_heatmap()


def _empty_heatmap() -> pl.DataFrame:
    return pl.DataFrame(schema={"asset": pl.String, "time": pl.Int64, "funding_rate": pl.Float64})
