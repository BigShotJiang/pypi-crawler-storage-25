"""Shared TUI screen model helpers."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass

import polars as pl
from textual.dom import DOMNode

from hl_research.cache.store import Cache


@dataclass(frozen=True)
class LoadError:
    """Recoverable load error exposed to TUI screens."""

    message: str


class ScreenModel(DOMNode):
    """Base class for non-visual reactive screen models."""

    def __init__(self, cache: Cache | None = None) -> None:
        super().__init__()
        self.cache = cache or Cache()


async def load_in_thread[T](func: Callable[[], T]) -> T:
    """Run blocking cache and Polars work off the event loop."""
    return await asyncio.to_thread(func)


def empty_funding_payments() -> pl.DataFrame:
    """Return an empty wallet-funding payment frame."""
    return pl.DataFrame(schema={"time": pl.Int64, "usdc": pl.Float64})


def empty_equity_curve() -> pl.DataFrame:
    """Return an empty vault equity curve frame."""
    return pl.DataFrame(schema={"time": pl.Int64, "equity": pl.Float64})
