"""Backtest TUI screen models."""

import polars as pl
from textual.reactive import reactive

from hl_research.api.types import Interval
from hl_research.backtest.engine import BacktestData, BacktestResult, run_backtest
from hl_research.backtest.strategy import ParamValue, Strategy
from hl_research.tui.screens._models import LoadError, ScreenModel, load_in_thread


class BacktestScreenModel(ScreenModel):
    """Reactive data source for the Backtest screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    asset = reactive[str | None](None)
    interval = reactive[Interval | None](None)
    candles = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    funding = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    result = reactive[BacktestResult | None](None)

    async def load_data(self, asset: str, interval: Interval = "1h") -> None:
        """Load cached backtest input data."""
        self.loading = True
        self.error = None
        self.asset = asset
        self.interval = interval
        try:
            candles, funding = await load_in_thread(lambda: self._load_data(asset, interval))
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.candles = candles
            self.funding = funding
            self.result = None
        finally:
            self.loading = False

    async def run(
        self,
        strategy_cls: type[Strategy],
        params: dict[str, ParamValue] | None = None,
        initial_cash: float = 100_000.0,
    ) -> None:
        """Run a strategy against the currently loaded cached data."""
        self.loading = True
        self.error = None
        try:
            result = await load_in_thread(
                lambda: run_backtest(
                    strategy_cls,
                    BacktestData(candles=self.candles, funding=self.funding),
                    params=params,
                    initial_cash=initial_cash,
                )
            )
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.result = result
        finally:
            self.loading = False

    def _load_data(self, asset: str, interval: Interval) -> tuple[pl.DataFrame, pl.DataFrame]:
        return (
            self.cache.read_candles(asset, interval).collect().sort("open_time"),
            self.cache.read_funding(asset).collect().sort("time"),
        )
