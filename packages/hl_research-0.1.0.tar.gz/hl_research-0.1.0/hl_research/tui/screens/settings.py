"""Settings TUI screen models."""

from dataclasses import dataclass

from textual.reactive import reactive

from hl_research.cache.store import CacheEntry
from hl_research.tui.screens._models import LoadError, ScreenModel, load_in_thread


@dataclass(frozen=True)
class SettingsState:
    """Current local settings exposed to the Settings screen."""

    cache_dir: str
    dataset_count: int
    total_size_bytes: int


class SettingsScreenModel(ScreenModel):
    """Reactive data source for the Settings screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    state = reactive[SettingsState | None](None)
    cache_entries = reactive[list[CacheEntry]](list)

    async def load(self) -> None:
        """Load local settings and cache metadata."""
        self.loading = True
        self.error = None
        try:
            state, entries = await load_in_thread(self._load)
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.state = state
            self.cache_entries = entries
        finally:
            self.loading = False

    def _load(self) -> tuple[SettingsState, list[CacheEntry]]:
        entries = self.cache.list()
        state = SettingsState(
            cache_dir=str(self.cache.root),
            dataset_count=len(entries),
            total_size_bytes=sum(entry.size_bytes for entry in entries),
        )
        return state, entries
