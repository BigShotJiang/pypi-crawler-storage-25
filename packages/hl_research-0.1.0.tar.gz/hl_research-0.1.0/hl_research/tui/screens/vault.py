"""Vault TUI screen models."""

import polars as pl
from textual.reactive import reactive

from hl_research.analytics.types import VaultAnalysis
from hl_research.analytics.vaults import analyze_vault, inspect_trades
from hl_research.api.types import Address
from hl_research.tui.screens._models import (
    LoadError,
    ScreenModel,
    empty_equity_curve,
    load_in_thread,
)


class VaultScreenModel(ScreenModel):
    """Reactive data source for the Vault screen."""

    loading = reactive(False)
    error = reactive[LoadError | None](None)
    vault = reactive[Address | None](None)
    summaries = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    trades = reactive[pl.DataFrame](pl.DataFrame, always_update=True)
    analysis = reactive[VaultAnalysis | None](None)

    async def load(self, vault: Address | None = None) -> None:
        """Load vault summaries and optional vault analysis from cache."""
        self.loading = True
        self.error = None
        self.vault = vault
        try:
            summaries, trades, analysis = await load_in_thread(lambda: self._load(vault))
        except Exception as exc:  # pragma: no cover - defensive TUI boundary
            self.error = LoadError(str(exc))
        else:
            self.summaries = summaries
            self.trades = trades
            self.analysis = analysis
        finally:
            self.loading = False

    def _load(
        self, vault: Address | None
    ) -> tuple[pl.DataFrame, pl.DataFrame, VaultAnalysis | None]:
        summaries = self.cache.read_vault_summaries()
        if vault is None:
            return summaries, _empty_trades(), None
        trades = self.cache.read_vault_trades(vault).collect().sort("time")
        metadata = _vault_metadata(summaries, vault)
        analysis = analyze_vault(
            vault,
            _equity_from_trades(trades).lazy(),
            trades.lazy(),
            name=metadata.name,
            leader=metadata.leader,
            tvl=metadata.tvl,
        )
        return summaries, inspect_trades(trades), analysis


class _VaultMetadata:
    def __init__(self, name: str | None, leader: Address | None, tvl: float | None) -> None:
        self.name = name
        self.leader = leader
        self.tvl = tvl


def _vault_metadata(summaries: pl.DataFrame, vault: Address) -> _VaultMetadata:
    if summaries.is_empty():
        return _VaultMetadata(None, None, None)
    row = summaries.filter(pl.col("address") == vault)
    if row.is_empty():
        return _VaultMetadata(None, None, None)
    return _VaultMetadata(
        name=str(row["name"].item()) if row["name"].item() is not None else None,
        leader=str(row["leader"].item()) if row["leader"].item() is not None else None,
        tvl=float(row["tvl"].item()) if row["tvl"].item() is not None else None,
    )


def _equity_from_trades(trades: pl.DataFrame) -> pl.DataFrame:
    if trades.is_empty() or "closed_pnl" not in trades.columns:
        return empty_equity_curve()
    return (
        trades.select("time", pl.col("closed_pnl").fill_null(0.0))
        .sort("time")
        .with_columns(pl.col("closed_pnl").cum_sum().alias("equity"))
        .select("time", "equity")
    )


def _empty_trades() -> pl.DataFrame:
    return pl.DataFrame(schema={"time": pl.Int64, "asset": pl.String, "closed_pnl": pl.Float64})
