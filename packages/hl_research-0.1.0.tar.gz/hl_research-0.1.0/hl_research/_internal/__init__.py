"""Internal utilities."""
