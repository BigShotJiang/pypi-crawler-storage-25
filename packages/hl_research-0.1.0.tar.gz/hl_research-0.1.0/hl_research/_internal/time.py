"""Time conversion helpers."""
