# Contributing to grelmicro

Thank you for your interest in contributing. This document captures
the conventions the project follows so your pull request lands
quickly and cleanly.

grelmicro aims for the same level of polish and documentation
ergonomics as [FastAPI](https://fastapi.tiangolo.com/) and
[Pydantic](https://docs.pydantic.dev/). When in doubt, imitate those
two projects.

## Quick start

```bash
# Install with all extras for development
uv sync --all-extras

# Install the pre-commit hooks (runs all CI gates on every commit)
uv run pre-commit install

# Run the full gate set on demand
uv run pre-commit run --all-files
```

The pre-commit configuration (`.pre-commit-config.yaml`) is the
single source of truth for what "passes CI": ruff, ty, pytest
(unit and integration), coverage, and file-hygiene hooks.

## Branch and commit conventions

- Work on a branch named for the change, e.g. `feat/<name>` or
  `fix/<name>`.
- Every commit and PR title **must** follow the
  [gitmoji](https://gitmoji.dev/) convention. The format (from
  [gitmoji's spec](https://gitmoji.dev/about)) is:

  ```
  <intention> [scope?][:?] <message>
  ```

  - `intention`: a single emoji from the
    [gitmoji list](https://gitmoji.dev/) that describes what the
    change does. The [full list](https://gitmoji.dev/) is the
    source of truth. Pick the one whose meaning fits best.
  - `scope` (optional): a short contextual string followed by `:`.
    Repo conventions accept either a Conventional-Commits type
    (`feat`, `docs`, `chore`, `ci`) or a module name
    (`resilience`, `logging`, `sync`, `task`).
  - `message`: a concise imperative summary of the change.

  The [full gitmoji list](https://gitmoji.dev/) is the source of
  truth. The ones that cover most grelmicro commits, with the
  exact code and description from gitmoji.dev:

  | Emoji | `:code:` | Description (from gitmoji.dev) |
  |---|---|---|
  | ✨ | `:sparkles:` | Introduce new features. |
  | 🐛 | `:bug:` | Fix a bug. |
  | 📝 | `:memo:` | Add or update documentation. |
  | ♻️ | `:recycle:` | Refactor code. |
  | ✅ | `:white_check_mark:` | Add, update, or pass tests. |
  | ⚡️ | `:zap:` | Improve performance. |
  | 🔒️ | `:lock:` | Fix security or privacy issues. |
  | 👷 | `:construction_worker:` | Add or update CI build system. |
  | ⬆️ | `:arrow_up:` | Upgrade dependencies. |
  | 🚨 | `:rotating_light:` | Fix compiler / linter warnings. |
  | 🔥 | `:fire:` | Remove code or files. |
  | 🎨 | `:art:` | Improve structure / format of the code. |

  Sample titles that combine the right emoji with a realistic
  grelmicro-style message:

  - `✨ feat: Add DuplicateFilter for noisy repeated log records (#94)`
  - `🔒 ci: Grant security-events write to Workflow Lint (#101)`
  - `👷 ci: Add attestations, wheel verification, and fetch-depth to release`
  - `📝 docs: Update changelog for 0.13.0 release`
  - `♻️ resilience: Bind algorithm to strategy once at construction`
  - `⬆️ Bump pydantic-extra-types from 2.11.1 to 2.11.2`

- Reference the issue or PR number in parentheses where applicable
  (e.g. `✨ resilience: Add TokenBucket algorithm (#93)`).
- Keep each commit focused. When chaining related commits, pause
  for review between them.

## Code style

### Type annotations

Mechanical style rules (modern unions, built-in generics,
keyword-only arguments, import layout) are enforced by ruff and
ty: let the tooling fail the hook and fix what it points at.
The rules below are the ones the tooling can't check:

- Annotate **every public parameter** with
  [`typing.Annotated`](https://docs.python.org/3/library/typing.html#typing.Annotated)
  and
  [`typing_extensions.Doc`](https://peps.python.org/pep-0727/).
  Each `Annotated` block reads as a self-contained paragraph of
  documentation.
- Mark deprecated parameters with
  [`typing_extensions.deprecated`](https://peps.python.org/pep-0702/)
  as a second `Annotated` entry so type-checkers and IDEs surface
  the deprecation inline. Keep a runtime `warnings.warn` alongside
  it.
- Keep `__init__` bodies thin. Attribute assignment only. Delegate
  validation to a frozen Pydantic config model.

### Pydantic models

- Every configuration class is
  `BaseModel, frozen=True, extra="forbid"`.
- Every field is annotated with `Annotated[type, Doc("...")]`.
- For discriminated unions, include a `type: Literal["..."]`
  discriminator field and wrap the union with
  `Annotated[A | B, Discriminator("type")]`.
- Expose the config through a `@property def config(self) -> XConfig`
  on the front-door class.

### Naming

- Full English words. No `algo`, `ctx`, `cfg`. The one exception
  is the underscore-prefixed private module names
  (`_protocol.py`, `_backends.py`).
- Public primitives get short, descriptive class names
  (`RateLimiter`, `Lock`, `CircuitBreaker`).
- Vendor- or product-specific names do **not** appear in public
  docstrings or user-facing docs. Industry conventions are OK
  ("token bucket", "sliding window"). Brand names are not.
  Attribution of adapted code belongs in `THIRD_PARTY_NOTICES.md`.

### Error messages

- Always actionable. Include the offending value where relevant
  (`f"cost must be between 1 and {limit}, got {cost}"`).
- Domain errors inherit from a package-specific base
  (`ResilienceError`, `LoggingError`, `SyncError`) which itself
  inherits from `GrelmicroError`.
- Use
  [`typing.assert_never`](https://docs.python.org/3/library/typing.html#typing.assert_never)
  in `match` statements over discriminated unions so new variants
  fail type-check immediately.

### Runtime-cost discipline

- A primitive with a pluggable strategy or algorithm should
  resolve the choice **once at construction** (bind it to a
  concrete object) and forward directly on every call. No
  `isinstance` / `match` dispatch on the hot path.
- Sync code paths that will be called from loops or
  `logging.Filter.filter()` must avoid allocation and I/O where
  possible. Prefer `time.monotonic` to `time.time`.

## Docstring style

We use [MkDocs Material](https://squidfunk.github.io/mkdocs-material/)
with [mkdocstrings](https://mkdocstrings.github.io/) and the Google
docstring style.

### Conventions

- **Markdown only.** No reStructuredText directives
  (`:class:`, `:meth:`, `:func:`, `:mod:`).
- **Single backticks** (`` `Name` ``) for inline code and type
  references. Double backticks are not required.
- **Cross-references** use mkdocstrings syntax:
  `` [`Name`][grelmicro.full.path.Name] ``. The label may be
  shortened to the local name. The target path must be fully
  qualified.
- **External links** use plain markdown: `[Label](url)`.
- **RFC and PEP references** link to their canonical page in
  Markdown files under `docs/`: `[RFC 9211](https://www.rfc-editor.org/rfc/rfc9211.html)`
  and `[PEP 702](https://peps.python.org/pep-0702/)`. Inside
  Python docstrings, keep them as plain text (`RFC 9211`,
  `PEP 702`) so they read naturally in IDEs and tracebacks.
- **Runnable example** in every public class docstring. Include
  all necessary `import` statements and show the primitive in use.
- **"Read more" link** at the end of class docstrings, pointing
  to the section of the user guide that covers the feature:
  `` Read more in the [Topic](../topic.md#section) docs. ``
- **Google-style `Args:` / `Returns:` / `Raises:` sections** on
  method docstrings. `__init__` docstrings stay as a one-line
  summary because the parameter docs live in the `Annotated`
  `Doc(...)` blocks.
- **Triple-quoted multi-paragraph `Doc(...)`** blocks with blank
  leading and trailing lines. Single-paragraph `Doc(...)` may use
  one line of prose.
- **No em dashes.** Use `: `, ` - ` (spaced), or `(…)` to separate
  clauses. Rewrite the sentence if none of those fit.
- **No semicolons in prose.** Split into two sentences or use a
  comma. Semicolons remain fine inside code blocks, SQL snippets,
  and parametrize IDs.

### Plain English for non-native readers

A large share of grelmicro's readers are professional developers
whose first language is not English. Write accordingly. This
applies to every user-facing surface: Markdown pages under `docs/`,
docstrings that mkdocstrings renders, the README, and release
notes.

- **Plain, industry-standard vocabulary.** Use the words readers
  already know from FastAPI, Pydantic, AWS, Kubernetes, and the
  Python standard library. Prefer "backend", "primitive", "request
  path", "timeout", "retry", "deadline" over invented or clever
  alternatives.
- **Short active sentences.** Aim for 15-20 words. Split rather
  than stack clauses with "and", "which", or a comma.
- **No idioms or metaphors.** Examples to avoid: "plumbing",
  "eating threads", "hitting a key", "touching a lock", "gate the
  task behind", "boring in the best possible way", "à la carte",
  "surface the health", "in the spirit of". Literal verbs win.
- **No anthropomorphic phrasing.** "The primitive asks for...",
  "the backend speaks a protocol..." - rewrite with a literal
  subject ("The primitive needs...", "the backend implements a
  protocol...").
- **No marketing adjectives without support.** Drop "effortlessly",
  "aggressively", "ergonomic", "blazing", "best possible way". If
  you claim something is fast or production-ready, either point to
  a benchmark or test suite, or rewrite with the concrete feature
  that delivers it.
- **Name technologies we integrate with** (FastAPI, Redis,
  PostgreSQL, Kubernetes, OpenTelemetry). Do not drop vendor
  names for flavour or comparison ("like zerolog", "in the
  Stripe style"). Industry concept names (JSON, sliding window,
  token bucket) are fine.
- **Compact shorthand is fine inside code blocks** (`~3x`, `1:1`,
  `1/sec`), but expand it in prose ("about 3 times faster",
  "maps directly", "1 per second").

### Example (a public class)

```python
class RateLimiter:
    """Rate limiter with a pluggable algorithm.

    Summary paragraph.

    Second paragraph explaining a subtle constraint.

    Example:
    ```python
    from grelmicro.resilience import RateLimiter

    rl = RateLimiter.token_bucket("api", capacity=10, refill_rate=1)
    ```

    Read more in the [Rate Limiter](../resilience/rate-limiter.md) docs.
    """
```

## Testing

- Name tests for the behaviour, not the method
  (`test_acquire_rejected_when_limit_exceeded`).
- Every test function has a one-line docstring.
- Use **Arrange / Act / Assert** comments to separate phases.
- Parametrize related cases with `pytest.mark.parametrize`.
- Mark integration tests (those that require Docker / a live
  service) with `pytest.mark.integration`. Unit tests run by
  default.
- Prefer fixtures with a `_` prefix for side-effect-only setups
  (consumed via `@pytest.mark.usefixtures`). Fixtures returning a
  value the test uses drop the prefix.
- **100 % coverage** across unit + integration is enforced.

## Documentation

- Every public module, class, method, and dataclass field has a
  docstring.
- Every user-facing feature has a section in the relevant
  `docs/*.md` page and a runnable snippet under
  `docs/snippets/<topic>/`.
- Snippets must be **self-contained and runnable**: include
  every `import` and define every variable they reference.
- Cross-reference classes with mkdocstrings syntax so the docs
  site auto-links to the API reference.
- When adding a decision point (e.g. multiple algorithms), write
  an explicit **"Choosing a ..." guide**: a numbered decision
  list plus a side-by-side comparison table.

## Third-party material

If you adapt code from another project, even a snippet:

1. Credit the source in `THIRD_PARTY_NOTICES.md` with a link to
   the original repo and its copyright line.
2. Verify the licence is compatible with MIT. Both the source
   repo and our root `LICENSE` must remain consistent.
3. Add a comment near the adapted code pointing to the
   `THIRD_PARTY_NOTICES.md` section.
4. Never use vendor-specific names in API documentation. Keep
   attribution in `THIRD_PARTY_NOTICES.md` only.

## Architectural conventions

### Backends

- Every storage-agnostic primitive (`Lock`, `RateLimiter`, cache,
  ...) has a matching `XBackend` Protocol under the package's
  `_protocol.py`, with at least a Memory and a Redis
  implementation.
- Backends live in a multi-name registry
  (`grelmicro/_backends.py::BackendRegistry`). Construction is
  pure: `__init__` performs no registry writes and no I/O. User
  code wires a backend by calling `<module>.register(backend)`
  (defaults to the `"default"` name) or
  `<module>.register(backend, "analytics")` for a named entry,
  then opens every registered backend via
  `grelmicro.lifespan()`. Primitives accept `backend=` as an
  instance override or `backend="<name>"` for a named lookup;
  the registry is consulted on every call so that
  `<module>.use(...)` overrides take effect.

### About grelmicro versions

grelmicro follows [Semantic Versioning](https://semver.org). The
public API is **not stable** until `1.0.0`. The `0.x` line exists
to converge on a design we want to commit to for `1.x`, the
enterprise-ready line.

While on `0.x`, breaking changes are allowed on a `MINOR` bump
(`0.14.0` → `0.15.0`) and never on a `PATCH` bump (`0.14.0` →
`0.14.1`). Pin the minor:

```text
grelmicro>=0.14.0,<0.15.0
```

Every breaking change appears under **Breaking** in
[`docs/changelog.md`](docs/changelog.md) with a migration snippet.
Deprecation shims are optional on `0.x`.

After `1.0.0`, standard semver applies: breaking changes only on
`MAJOR`, and removals go through at least two `MINOR` releases
with a `DeprecationWarning` first.

## Before opening a PR

- All pre-commit gates pass locally
  (`uv run pre-commit run --all-files`).
- Coverage stays at 100 %.
- Every new public symbol has a docstring and a test.
- `docs/` is updated if user-facing behaviour changed.
- `docs/changelog.md` has an entry under `## Unreleased`.
- Commit titles follow the gitmoji + conventional-commit format.

Thanks for reading. If a convention in this document surprised
you, open an issue: either the rule is wrong or the rationale
isn't written down yet.
