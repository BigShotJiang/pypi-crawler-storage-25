"""Cache Snippets."""
