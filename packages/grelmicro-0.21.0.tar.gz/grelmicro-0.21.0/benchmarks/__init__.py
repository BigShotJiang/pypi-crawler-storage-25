"""Benchmarks for grelmicro."""
