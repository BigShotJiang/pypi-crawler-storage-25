"""Health check tests."""
