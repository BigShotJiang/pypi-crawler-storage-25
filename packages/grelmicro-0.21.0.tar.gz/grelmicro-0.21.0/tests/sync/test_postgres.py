"""Tests for PostgreSQL Backends."""

import pytest

from grelmicro.errors import OutOfContextError
from grelmicro.sync._backends import sync_backend_registry
from grelmicro.sync.errors import SyncSettingsValidationError
from grelmicro.sync.postgres import PostgresSyncBackend

pytestmark = [pytest.mark.timeout(1)]

URL = "postgresql://test_user:test_password@test_host:1234/test_db"
URL_DEFAULT_PORT = "postgresql://test_user:test_password@test_host:5432/test_db"


@pytest.mark.parametrize(
    "table_name",
    [
        "locks table",
        "%locks",
        "locks;table",
        "locks' OR '1'='1",
        "locks; DROP TABLE users; --",
    ],
)
def test_sync_backend_table_name_invalid(table_name: str) -> None:
    """Test Synchronization Backend Table Name Invalid."""
    # Act / Assert
    with pytest.raises(
        ValueError, match=r"Table name '.*' is not a valid SQL identifier"
    ):
        PostgresSyncBackend(url=URL, table_name=table_name)


async def test_sync_backend_out_of_context_errors() -> None:
    """Test Synchronization Backend Out Of Context Errors."""
    # Arrange
    backend = PostgresSyncBackend(url=URL)
    name = "lock"
    key = "token"

    # Act / Assert
    with pytest.raises(OutOfContextError):
        await backend.acquire(name=name, token=key, duration=1)
    with pytest.raises(OutOfContextError):
        await backend.release(name=name, token=key)
    with pytest.raises(OutOfContextError):
        await backend.locked(name=name)
    with pytest.raises(OutOfContextError):
        await backend.owned(name=name, token=key)


@pytest.mark.parametrize(
    ("environs"),
    [
        {"POSTGRES_URL": URL},
        {
            "POSTGRES_USER": "test_user",
            "POSTGRES_PASSWORD": "test_password",
            "POSTGRES_HOST": "test_host",
            "POSTGRES_PORT": "1234",
            "POSTGRES_DB": "test_db",
        },
    ],
)
def test_postgres_env_var_settings(
    environs: dict[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test PostgreSQL Settings from Environment Variables."""
    # Arrange
    for key, value in environs.items():
        monkeypatch.setenv(key, value)

    # Act
    backend = PostgresSyncBackend()

    # Assert
    assert backend._url == URL


@pytest.mark.parametrize(
    ("environs"),
    [
        {
            "POSTGRES_URL": "test://test_user:test_password@test_host:1234/test_db"
        },
        {"POSTGRES_USER": "test_user"},
        {
            "POSTGRES_URL": URL,
            "POSTGRES_USER": "test_user",
            "POSTGRES_PASSWORD": "test_password",
            "POSTGRES_HOST": "test_host",
            "POSTGRES_PORT": "1234",
            "POSTGRES_DB": "test_db",
        },
    ],
)
def test_postgres_env_var_settings_validation_error(
    environs: dict[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test PostgreSQL Settings from Environment Variables."""
    # Arrange
    for key, value in environs.items():
        monkeypatch.setenv(key, value)

    # Assert / Act
    with pytest.raises(
        SyncSettingsValidationError,
        match=(r"Could not validate environment variables settings:\n"),
    ):
        PostgresSyncBackend()


def test_sync_backend_constructor_does_not_register() -> None:
    """Constructing the backend performs no registry writes."""
    sync_backend_registry.reset()

    PostgresSyncBackend(url=URL)

    assert not sync_backend_registry.is_loaded


def test_sync_backend_custom_table_name() -> None:
    """Test Synchronization Backend Custom Table Name."""
    # Act
    backend = PostgresSyncBackend(url=URL, table_name="my_locks")

    # Assert
    assert backend._table_name == "my_locks"


def test_postgres_env_var_settings_default_port(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Test PostgreSQL Settings from Environment Variables with Default Port."""
    # Arrange
    monkeypatch.setenv("POSTGRES_USER", "test_user")
    monkeypatch.setenv("POSTGRES_PASSWORD", "test_password")
    monkeypatch.setenv("POSTGRES_HOST", "test_host")
    monkeypatch.setenv("POSTGRES_DB", "test_db")

    # Act
    backend = PostgresSyncBackend()

    # Assert
    assert backend._url == URL_DEFAULT_PORT
