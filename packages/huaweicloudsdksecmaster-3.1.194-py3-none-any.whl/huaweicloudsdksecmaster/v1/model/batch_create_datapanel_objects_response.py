# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchCreateDatapanelObjectsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'body': 'list[DataObjectCreateUpdateResponse]',
        'x_request_id': 'str'
    }

    attribute_map = {
        'body': 'body',
        'x_request_id': 'X-request-id'
    }

    def __init__(self, body=None, x_request_id=None):
        r"""BatchCreateDatapanelObjectsResponse

        The model defined in huaweicloud sdk

        :param body: 数据对象信息列表
        :type body: list[:class:`huaweicloudsdksecmaster.v1.DataObjectCreateUpdateResponse`]
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._body = None
        self._x_request_id = None
        self.discriminator = None

        if body is not None:
            self.body = body
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def body(self):
        r"""Gets the body of this BatchCreateDatapanelObjectsResponse.

        数据对象信息列表

        :return: The body of this BatchCreateDatapanelObjectsResponse.
        :rtype: list[:class:`huaweicloudsdksecmaster.v1.DataObjectCreateUpdateResponse`]
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this BatchCreateDatapanelObjectsResponse.

        数据对象信息列表

        :param body: The body of this BatchCreateDatapanelObjectsResponse.
        :type body: list[:class:`huaweicloudsdksecmaster.v1.DataObjectCreateUpdateResponse`]
        """
        self._body = body

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this BatchCreateDatapanelObjectsResponse.

        :return: The x_request_id of this BatchCreateDatapanelObjectsResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this BatchCreateDatapanelObjectsResponse.

        :param x_request_id: The x_request_id of this BatchCreateDatapanelObjectsResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("BatchCreateDatapanelObjectsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchCreateDatapanelObjectsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
