"""Bundle build-tree DLLs into pymergetic-easybind Windows wheels (cibuildwheel repair step)."""

from __future__ import annotations

import pathlib
import subprocess
import sys


def _dll_add_paths(project_root: pathlib.Path) -> list[str]:
    """Directories to pass to delvewheel --add-path (non-recursive; one entry per DLL dir)."""
    build_root = project_root / "build"
    if not build_root.is_dir():
        return []

    seen: set[str] = set()
    paths: list[str] = []
    for dll in build_root.rglob("*.dll"):
        parent = str(dll.parent)
        if parent not in seen:
            seen.add(parent)
            paths.append(parent)
    return sorted(paths)


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if len(args) != 2:
        print("usage: repair_wheel_windows.py DEST_DIR WHEEL", file=sys.stderr)
        return 2
    dest_dir, wheel = args
    project_root = pathlib.Path(__file__).resolve().parents[1]

    cmd = ["delvewheel", "repair", "-w", dest_dir]
    add_paths = _dll_add_paths(project_root)
    if not add_paths:
        print("warning: no *.dll found under build/; delvewheel may fail", file=sys.stderr)
    for path in add_paths:
        cmd.extend(["--add-path", path])
    cmd.append(wheel)
    subprocess.check_call(cmd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
