# imports from td_matrices
from pydistintox.td_matrices.core import (
    compute_td_matrices_and_measures,
)

# imports from distinct_measures
from pydistintox.distinct_measures.core import (
    calculate_rank_correlation,
    calculate_scores,
)

# imports from visualize
from pydistintox.visualize.core import (
    format_scores,
    open_html,
    save_results,
    visualize_rank_correlations,
    visualize_score,
    write_html_index,
)

# imports from common
import pydistintox.common.utils as common_utils
import pydistintox.common.config as common_config

# intra-package imports
from pydistintox.cli import (
    arguments,
    handle_input,
)


def main() -> None:

    # init config
    config = handle_input(arguments())

    # setup logging
    common_utils.setup_logging(config.verbose)
    
    """package td_matrices"""
    td_matrices, scores_tf_idf, terms = compute_td_matrices_and_measures(
        config
    )

    """package distinct_measures"""
    # calculate scores from non-tf-idf measures
    scores_non_tf_idf = calculate_scores(
        matrices=td_matrices, 
        config=config,
    )

    # format scores
    scores_all = scores_tf_idf | scores_non_tf_idf
    measures = list(scores_all.keys())
    scores_processed = format_scores(scores_all,terms)
    for name, score in scores_processed.items():
        save_results(
            result= score,
            path=common_config.RESULTS_CLI_SCORES / f'{name}.csv',
        )

    # calculate rank correlation between scores
    correlation_matrix, index = calculate_rank_correlation(scores_all)

    """package visualize"""
    # create visualizations
    for measure, score in scores_processed.items():
        visualize_score(
            score_processed=score,
            title=measure,
            path=common_config.RESULTS_CLI_SCORES,
        )
    visualize_rank_correlations(
        correlation_matrix,
        index,
        dir_path= common_config.RESULTS_CLI_CORRELATIONS
    )

    # show visualizations
    write_html_index(
        file_names=[f'{name}.html' for name in measures],
        dir= common_config.RESULTS_CLI_SCORES,
    )

    open_html(common_config.RESULTS_CLI_SCORES / 'index.html')
    open_html(common_config.RESULTS_CLI_CORRELATIONS / 'heatmap.html')

    return

if __name__ == '__main__':
    main()