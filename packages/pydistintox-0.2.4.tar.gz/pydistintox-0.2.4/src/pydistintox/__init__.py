__version__ = "unversioned"
__author__ = "Leon Glüsing and Stefan Walter-Heßbrüggen"
__author_email__ = "leongluesing@uni-muenster.de"
__license__ = "CC0-1.0"
__homepage__ = "https://www.uni-muenster.de/Wissenschaftstheorie/Forschung/PRODATPHIL/"
__description__ = (
    'Pydistinto-Lite is a lightweight, memory-efficient tool '
    'for comparing two text corpora to identify statistically '
    'distinctive words. Originally based on '
    '[Pydistinto](https://github.com/Zeta-and-Company/pydistinto)'
    ', it uses Gensim and NumPy/SciPy to handle large datasets '
    'that exceed RAM limits.'
)

from pydistintox.common.config import (
    Config,
)
from pydistintox.common.utils import (
    save_as_sparse,
    setup_logging,
)
from pydistintox.td_matrices.core import (
    compute_td_matrices_and_measures,
    spacy_download,
)
from pydistintox.distinct_measures.core import (
    calculate_rank_correlation,
    calculate_scores,
)
from pydistintox.visualize.core import (
    format_scores,
    open_html,
    save_results,
    visualize_rank_correlations,
    visualize_score,
    write_html_index,
)

__all__ = [
    "calculate_rank_correlation",
    "calculate_scores",
    "compute_td_matrices_and_measures",
    "Config",
    "format_scores",
    "open_html",
    "visualize_rank_correlations",
    "visualize_score",
    "save_as_sparse",
    "save_results",
    "setup_logging",
    "spacy_download",
    "write_html_index",
]
