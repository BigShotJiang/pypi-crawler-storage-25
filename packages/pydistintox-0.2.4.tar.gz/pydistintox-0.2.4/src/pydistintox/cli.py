# standard library imports
import argparse
import logging
from pathlib import Path
import sys

# third-party imports

# application-specific imports
import pydistintox.common.utils as common_utils
import pydistintox.common.config as common_config
from pydistintox.td_matrices.core import spacy_download

# intra-package imports


""" Argument handling """
def arguments()-> argparse.Namespace:
    # create parser
    parser = argparse.ArgumentParser(
        description='Generate matrices for analysis.'
    )

    # download model
    parser.add_argument(
        '--download',
        metavar='MODEL',
        type=str,
        help=(
        'Download the specified spaCy model (e.g., "en_core_web_sm" or "de_core_news_sm"). '
        'See all available models: https://spacy.io/models'
        )
    )
    # verbose option
    parser.add_argument(
        '-v', '--verbose', 
        action='store_true', 
        help='Changes logging mode to verbose.'
    )
    # add package-specific parser options
    parser.add_argument(
        '--load-nlp',
        type=str,
        metavar='PATH',
        help=(
            'Load NLP results from a directory'
            'The directory must contain tar/ and ref/ subfolders. '
        )
    )
    parser.add_argument(
        '--save-nlp',
        type=str,
        metavar='PATH',
        help=(
            'Save NLP results to directory (creates tar/ and ref/ subfolders)'
        )
    )
    parser.add_argument(
        '--tar',
        type=str,
        help='Path to directory from which to load texts.)'
    )
    parser.add_argument(
        '--ref',
        type=str,
        help='Path to directory from which to load texts.)'
    )
    parser.add_argument(
        '--model',
        type=str,
        # required=True,
        help=(
            "spaCy model name format: '{lang}_core_{dataset}_{size}'"
            "Example: 'en_core_web_sm' (lang=en, dataset=web, size=sm)\n"
            # "'en_core_web_sm' is used when no model is specified.\n\n"
            "Available sizes: sm, md, lg, trf"
            "Find models: https://spacy.io/models"
        )
    )
    parser.add_argument(
        '--raw-scores',
        action='store_true',
        help='Scores will not be scaled to -1,1.'
    )

    # parse given arguments and return them
    args = parser.parse_args()

    # checks
    if args.download:  ## no analysis here
        if any([args.tar, args.ref, args.load_nlp, args.save_nlp, args.model, args.raw_scores]):
            parser.error("--download cannot be combined with other arguments. Run it separately first.")
    else:  ## run anaylsis
        if not args.model:
            parser.error('--model is required')
        if bool(args.tar) != bool(args.ref):
            parser.error('Specify both --tar and --ref')
        if bool(args.load_nlp) and bool(args.save_nlp):
            parser.error('--load-nlp and --save-nlp have been raised.')

    return args


def handle_input(args: argparse.Namespace) -> common_config.Config:
    """Resolves input paths based on CLI arguments and returns a structured config."""

    # local function
    def _validate_paths(
            target: Path, 
            reference: Path, 
            error_message: str
        ) -> None:
        """Validates that directories exist and are not empty."""
        if common_utils.dir_is_empty(target):
            logging.error(
                f"Directory '{target}' is empty. {error_message}"
            )
            sys.exit(1)
        if common_utils.dir_is_empty(reference):
            logging.error(
                f"Directory '{reference}' is empty. {error_message}"
            )
            sys.exit(1)

    # local function
    def _log_paths(
            config: common_config.Config,
            message: str
        ) -> None:
        """Logs the paths being used."""
        logging.info(
            f'{message}\n'
            f'Target dir: {config.target}\n'
            f'Reference dir: {config.reference}'
        )

    # --- Case 0: Download spaCy model ---
    if args.download:
        model_name = args.download
        spacy_download(model_name)
        logging.critical(
            f'\n\n'
            f"Successfully downloaded '{model_name}' \n"
            f'You may now run the analysis.'
        )
        sys.exit(0)

    # --- Case 1: Run Analysis and load NLP results ---
    elif args.load_nlp:
        logging.warning(
            'CAUTION: To ensure all annotations and token mappings are loaded correctly, '
            'use the same spaCy model (and version) that was used to store the data.'
        )
        INPUT_JSON = Path(args.load_nlp)
        config = common_config.Config(
            skip_nlp=True,
            save_nlp=False,
            target=INPUT_JSON / 'tar',
            reference=INPUT_JSON / 'ref',
            source='load-nlp',
            spacy_model_name=args.model,
        )
        _validate_paths(
            config.target,
            config.reference,
            error_message=(
                "The '--load-nlp' flag was set, "
                "but no corpus files were found."
            )
        )
        _log_paths(
            config,
            'The following paths will be used to load JSON:'
        )

    # --- Case 2: Run analysis and do nlp ---
    else:
        config = common_config.Config(
            skip_nlp=False,
            target=Path(args.tar),
            reference=Path(args.ref),
            source='external',
            spacy_model_name=args.model,
        )
        _log_paths(
            config,
            'The following paths have been given:\n\n'
        )
            

    # --- Parameters independent of nlp ---
    config.verbose = bool(args.verbose)
    config.save_nlp = (
        False if args.save_nlp is None
        else Path(args.save_nlp)
    )
    config.scaling = not(args.raw_scores)

    return config