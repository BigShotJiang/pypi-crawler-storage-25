# standard library imports
import logging
from pathlib import Path
import sys

# third-party imports
import numpy as np
import pandas as pd

# application-specific imports
import pydistintox.common.utils as common_utils
import pydistintox.common.config as common_config
from pydistintox.common.config import SparseMatrix

# no intra-package imports to prevent circular imports


""" Handle errors and logging"""


def log_shapes(
        matrices: common_config.Matrices
    )-> tuple[int,int,int]:

    number_of_documents_tar = matrices.abs_tar.shape[1]
    number_of_documents_ref = matrices.abs_ref.shape[1]
    number_of_terms = matrices.abs_tar.shape[0]

    logging.info(f'TARGET CORPUS: \n {number_of_documents_ref} documents')
    logging.info(f'REFERENCE CORPUS: \n {number_of_documents_tar} documents')
    logging.info(f'NUMBER OF TERMS: {number_of_terms}')
    
    return (
        number_of_documents_tar, 
        number_of_documents_ref, 
        number_of_terms
    )