# standard library imports
import logging
from pathlib import Path

# third-party imports
import scipy.sparse as sp

# application-specific imports
from pydistintox.common.config import SparseMatrix


"""Load functions"""

def load_sparse(
        file_names:list[str], 
        input_dir: Path
        )-> dict[str,sp.csc_array|sp.csr_array]:
    """
    takes a list of file names such as ['absfreq_csr.pkl',...],
    and returns a dictionary with the file names as keys.
    """

    matrices = {}
    logging.debug(
        'The following matrices will be loaded:', 
        file_names
    )

    for name in file_names:
        file_path = input_dir / name
        if file_path.exists():  
            matrix = sp.load_npz(file_path)
            matrices[name.removesuffix('.npz')] = matrix 
        else:
            logging.error(f'Warning: File {name} not found in {input_dir}')

    logging.debug(
        'saved matrices in dictionary:',
        list(matrices.keys())
    )

    return matrices


def load_sparse_from_path(
        path:Path
    )-> SparseMatrix:
    
    logging.debug(f'The following matrice is loaded: {path.name}')
    return sp.load_npz(path)