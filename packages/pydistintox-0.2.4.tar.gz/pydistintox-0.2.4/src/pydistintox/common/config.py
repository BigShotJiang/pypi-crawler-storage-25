# standard library imports
import csv
from dataclasses import (
    dataclass,
    field
)
import logging
from pathlib import Path
from typing import TypeAlias

# third-party imports
import numpy as np
from scipy import sparse as sp


""" Paths for CLI """
RESULTS_CLI = Path('results')
RESULTS_CLI_SCORES = RESULTS_CLI / 'scores'
RESULTS_CLI_CORRELATIONS = RESULTS_CLI / 'correlations_of_measures'
# for CLI use: make directory if not there
for p in (RESULTS_CLI, RESULTS_CLI_SCORES, RESULTS_CLI_CORRELATIONS):
    p.mkdir(exist_ok=True)

""" Static Paths for Development """

# general
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
SRC = PROJECT_ROOT / 'src'

# data
DATA = PROJECT_ROOT / 'data'
INTERIM = DATA / 'interim'
JSON = INTERIM / 'json'
JSON_TAR = JSON / 'tar'
JSON_REF = JSON / 'ref'
TD_MATRICES = INTERIM / 'td_matrices'
STAGING = INTERIM / 'staging'
RESULTS = DATA / 'results'
RESULTS_SCORES = RESULTS / 'scores'
RESULTS_CORRELATIONS = RESULTS / 'correlations_of_measures'
SCORES_EXAMPLE = RESULTS_SCORES / 'example'
CORRELATIONS_EXAMPLE = RESULTS_CORRELATIONS / 'example'

# example texts
EXAMPLE_TEXTS = DATA / 'example_texts'
EXAMPLE_TAR = EXAMPLE_TEXTS / 'tar'
EXAMPLE_REF = EXAMPLE_TEXTS / 'ref'
EXAMPLE_JSON = JSON / 'example'
EXAMPLE_JSON_TAR = EXAMPLE_JSON / 'tar'
EXAMPLE_JSON_REF = EXAMPLE_JSON / 'ref'

# tests
TESTS = PROJECT_ROOT / 'tests'

""" Type declaration """
SparseMatrix: TypeAlias = sp.csc_array | sp.csr_array


@dataclass
class Config:
    """Configuration for NLP input paths and processing flags."""
    skip_nlp: bool
    target: Path
    reference: Path
    spacy_model_name: str  # = 'en_core_web_sm'
    source: str = 'Not specified'  # only for logging / documentation
    save_nlp: bool | Path = False
    verbose: bool = False
    measures_to_calculate: list[str] | None = None
    scaling: bool = True  # scale scores to -1,1
    segmentlength: int = 5000
    # the following parameters are relevant to non-tf-idf measures
    logaddition: np.float64 = np.float64(1 + 1e-11)
    # logaddition is a normalization factor; 
    # we want log(x + logaddition) > 0, 
    # hence logaddition > 1 for x near 0.
    divaddition: np.float64 = np.float64(1e-11)
    # Define division-by-zero avoidance
    # and convert input into np.float
    def __post_init__(self):
        from pydistintox.td_matrices.config import measures_available as tf_idf_measures
        from pydistintox.distinct_measures.config import measures_available as non_tf_idf_measures
        measures_available = set(tf_idf_measures + non_tf_idf_measures)
        if self.measures_to_calculate:
            assert set(self.measures_to_calculate).issubset(measures_available), (
                f'The requested measures are not available. Please check for typos.\n'
                f'Your input:\n\n'
                f'{self.measures_to_calculate}\n\n'
                f'Possible measures:\n\n'
                f'{measures_available}'
            )

@dataclass
class Matrices:
    # sparse dt-matrices
    bin_tar: SparseMatrix
    bin_ref: SparseMatrix
    rel_tar: SparseMatrix
    rel_ref: SparseMatrix
    abs_tar: SparseMatrix
    abs_ref: SparseMatrix

    # dense dt-matrices
    abs_dense_tar: np.ndarray | None = field(init=False, default=None)
    abs_dense_ref: np.ndarray | None = field(init=False, default=None)

@dataclass
class Indicators:
    docprops_tar: np.ndarray
    docprops_ref: np.ndarray
    relative_tar: np.ndarray
    relative_ref: np.ndarray

@dataclass
class CalculationData:
    matrices: Matrices
    indicators: Indicators
    # Parameters added later
    segmentlength: int | None = field(init=False, default=None)
    logaddition: np.float64 | None = field(init=False, default=None)
    divaddition: np.float64 | None = field(init=False, default=None)

    def set_params(
            self,
            logaddition:np.float64, 
            segmentlength:int, 
            divaddition:np.float64,
        ) ->  None:

        self.segmentlength = segmentlength
        self.logaddition = logaddition
        self.divaddition = divaddition
        
        logging.info(
            f'The following parameters are used:\n\n'
            f'segmentlength: {segmentlength}\n'
            f'logaddition: {logaddition}\n'
            f'divaddition: {divaddition}\n'
        )
     


    # def __post_init__(self) -> None:
    #     """Optional: Validate data after initialization."""
    #     required_sparse = {'tar', 'ref'}
    #     if not required_sparse.issubset(self.sparse_matrices.keys()):
    #         raise ValueError(f"Missing sparse matrices. Expected: {required_sparse}")



CSV_EXPORT_CONFIG = {
    "quoting": csv.QUOTE_NONNUMERIC,
    "quotechar": '"',
    "doublequote": True,
    "escapechar": '\\',
    "sep": ',',  # Default separator
    "encoding": 'utf-8',  # Default encoding
}
