#standard library imports
from pathlib import Path
from typing import Literal

#third-party imports
import altair as alt
import numpy as np
import pandas as pd

# intra-package imports
from .config import (HEATMAP_CONFIG)

# application-specific imports
import pydistintox.common.utils as common_utils


def generate_html_structure(
        title: str, 
        list_items: str
    ) -> str:
    """Generates the HTML structure for the index page."""
    return f"""<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
        }}
        h1 {{
            color: #333;
        }}
        ul {{
            list-style-type: none;
            padding: 0;
        }}
        li {{
            margin: 8px 0;
        }}
        a {{
            text-decoration: none;
            color: #0066cc;
            font-weight: bold;
        }}
        a:hover {{
            text-decoration: underline;
        }}
    </style>
</head>
<body>
    <h1>{title}</h1>
    <p>Click on a link to open the results in a new tab:</p>
    <ul>
    {list_items}
    </ul>
</body>
</html>"""


def create_html_index_str(
        html_files_names: list[str],
        dir: Path,
        title: str = 'index',
    ) -> str:
    """
    Generates the HTML text for an index.html page with links 
    to all HTML files in the specified directory.
    """
    
    # Generate list items for HTML files
    list_items = ''.join(
        f'        <li><a href="{file_name}" target="_blank">{(dir / file_name).stem}</a></li>\n'
        for file_name in sorted(html_files_names)
    )
    
    # Generate the complete HTML structure
    return generate_html_structure(title, list_items)

def heatmap(
        df: pd.DataFrame, 
        save_path: Path,
        index_x_axis: 'str',
        index_y_axis: 'str',
        title: 'str',
        color: str = 'purpleblue',  # see https://vega.github.io/vega/docs/schemes/ for more options
    )->None:
    """
    Read matrix of correlation between distinctness rankings.
    Transform into wide format. Visualize as heatmap.
    """
    sort_config = HEATMAP_CONFIG['sort']
    size_config = HEATMAP_CONFIG['size']

    # Melt works easier for me, if not including index (?)
    
    df_no_index = df.reset_index(names=index_x_axis)

    # Wide form data frame
    
    df_wide = df_no_index.melt(index_x_axis, var_name=index_y_axis, value_name='Correlation')

    # Shared base of heatmap and labels

    heatbase = alt.Chart(
        df_wide,
        title=title,
        **size_config
    ).encode(
        alt.X(index_y_axis, axis=alt.Axis(labelAngle=-45)).sort(**sort_config),
        alt.Y(index_x_axis).sort(**sort_config)
    )
    
    # heatmap
    
    heatmap = heatbase.mark_rect().encode(
        color=alt.Color('Correlation').scale(scheme=color))

    # labels
    
    heattext = heatbase.mark_text(baseline='middle').encode(
        alt.Text('Correlation', format='.2f'))

    # output
    
    figure = heatmap + heattext
    figure.save(save_path)

    return

def zip_array_terms(
        array: np.ndarray,
        terms: list[str],
        index_array: str,
        index_terms: str,
    )->pd.DataFrame:
    """
    Combines a numerical array (result of a stochastic mesaure) 
    with the list of terms into a pandas DataFrame.
    """

    # Ensure that the lengths match
    assert len(array) == len(terms)
    df = pd.DataFrame({
        index_terms: terms,
        index_array: array,
    })

    return df