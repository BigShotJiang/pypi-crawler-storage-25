# standard library imports
import logging
from pathlib import Path
import webbrowser

# third-party imports
import altair as alt
import numpy as np
import pandas as pd

# application-specific imports
import pydistintox.common.config as common_config
import pydistintox.common.utils as common_utils

# intra-package imports
from .utils import (
    create_html_index_str,
    heatmap,
    zip_array_terms,
)
from .config import (
    CSV_EXPORT_CONFIG,
)


""" store results """
# this function is not used for the moment but may become relevant for the API
def save_result_as_array(
        name:str, 
        numpy_array: np.ndarray,
    )->None:
    """Dump results as numpy array"""

    file_name = f'{name}.csv'
    np.savetxt(
        common_config.STAGING / file_name,
        numpy_array, 
        delimiter=','
    )
    logging.debug(f'Saved result without index of {name} in STAGING')


def save_results(
        result: pd.DataFrame,
        path: Path,
        write_header: bool = True,
    )-> None:
    """
    store results as textfile in csv format in given directory.
    """

    result.to_csv(
        path,
        header = write_header,
        index = False,
        **CSV_EXPORT_CONFIG,
    )
    logging.debug(f'wrote result into path {path}.')
    return


# format scores for visualization
def format_scores(
        scores_all: dict[str, np.ndarray],
        terms: list[str],
        header_scores = 'Score',
        header_terms = 'Term',
    )-> dict[str, pd.DataFrame]:

    scores_processed = {}

    for name, score in scores_all.items():
        df = zip_array_terms(
            array=score,
            terms=terms,
            index_array=header_scores,
            index_terms=header_terms,
        )
        df_sorted = df.sort_values(by=header_scores, ascending=False)
        scores_processed[name]= df_sorted

    return scores_processed


""" Visualization """
def visualize_score(
        score_processed: pd.DataFrame, 
        title: str, 
        path: Path,  # to dir
    )-> None:
    """
    Visualizes the top and bottom terms 
    from a score DataFrame as a horizontal bar chart.

    Displays the top 25 terms (highest scores) in lightgreen 
    and the bottom 25 terms (lowest scores) in lightblue. 
    The chart is saved as an interactive HTML file in 
    the specified directory.
    """

    show_data_1 = score_processed.head(25).copy()  
    # a copy is used only to avoid warnings when executed (.loc works as well)
    show_data_2 = score_processed.tail(25).copy()  
    # a copy is used only to avoid warnings when executed (.loc works as well)

    show_data_1.columns = ['Term', 'Score']
    show_data_2.columns = ['Term', 'Score']

    show_data_1['color'] = 'lightgreen'
    show_data_2['color'] = 'lightblue'

    data_to_show = pd.concat([show_data_1, show_data_2])

    # altair variables     
    predicate = alt.datum.Score > 0
    # align = alt.when(predicate).then(alt.value('right')).otherwise(alt.value('left'))

    # altair chart
    # change column names if different in input df  
    bars = alt.Chart(
        data_to_show, width=500, 
        height=700, 
        title=title
    ).mark_bar().encode(
        x='Score',
        y=alt.Y(
            'Term', 
            sort={
                'field': '-x', 
                'order': 'descending'
            }, 
            axis=None
        ),
        color=alt.Color(
            'color', 
            scale=None
        )
    )

    text = bars.mark_text(
        baseline='middle',
        align='center',
        dx=alt.expr(alt.expr.if_(
            predicate, 
            -50, 
            50)
        )).encode(
            text='Term',
            color=alt.value('black')
        )
    
    figure = bars + text
    figure.save(path / f'{title}.html')

    return 


def visualize_rank_correlations(
        matrix: np.ndarray,
        index: list[str],
        dir_path: Path,
    )-> None:
    """visualize rank correlations between scores"""
    
    df = pd.DataFrame(
        matrix, 
        index=index,
        columns = index
    )
    
    df.to_csv(dir_path / 'measure_correlations.csv')
    
    # create and save visualization of rank correlations
    heatmap(
        df=df,
        save_path=dir_path / 'heatmap.html',
        title='Measures of Distinctiveness: Correlations',
        index_x_axis='Score 1',
        index_y_axis='Score 2',
    )

    return 


def write_html_index(
        file_names: list[str],
        dir: Path,
        title: str = 'index',
    )->None:
    
    with open(dir / 'index.html','w') as f:
        html = create_html_index_str(file_names,dir,title)
        f.write(html)
    return


def open_html(
        html_path: Path,
    )->None:
    
    path_str = html_path.absolute()
    webbrowser.open(f'file://{path_str}')
    return