# standard library imports
from pathlib import Path
import logging
import sys

# third-party imports
import spacy

# no intra-package imports to prevent circular imports!


# application-specific import
from pydistintox.common import utils as common_utils
from pydistintox.common import config as common_config


""" logging """
def log_corp(
        corp: list[tuple[str,list[str]]]
    )-> None:

    ids = {id for id, lemma in corp}

    logging.info(
        f'The corpus contains {str(len(ids))} documents '
        f'in {str(len(corp))} chunks. '
    )

""" Spacy specific functions """
def load_spacy_model(
        model: str
    )-> spacy.language.Language:

    try:
        nlp=spacy.load(
            model, 
            disable='ner'
        )
        logging.debug(f'loaded spacy model: {model}')
        return nlp
    
    except OSError:
        logging.critical(
            f'The spaCy model {model} was not found. \n'
            f'If you use PyDistintoX CLI run first with the following command and then try again:       \n\n'
            f'pydistintox --download {model} \n\n'
            f'Else you may download it via (uv) pip and then try again\n\n'
            f'pip install $(spacy info {model} --url)'
        )
        sys.exit(1) 

def spacy_download(
        model: str
    )-> None:

    try:
        spacy.cli.download(model)
        logging.info(f'{model} successfully downloaded.')
    except:
        logging.error(
            f'Could not download {model}. '
            f'Visit https://spacy.io/models and check whether the requested model is available.'
        )
        raise

""" storing results"""
def store_list(
        list: list,
        path: Path,
    ) -> None:  

    with open(path, 'w') as file:
        for element in list:
            file.write(f'{element}\n')

    logging.debug(f'wrote list of len {len(list)} to {path}.')
    return