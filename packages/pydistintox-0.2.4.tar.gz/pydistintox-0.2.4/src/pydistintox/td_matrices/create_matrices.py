# third party imports
import numpy as np

# application-specific imports
import pydistintox.common.config as common_config

# intra-package imports
from .tfidf_measures import initialize_tfidf


def create_matrices(
        corp_lemma_tar: list[tuple[str,list[str]]], 
        corp_lemma_ref: list[tuple[str,list[str]]], 
        bow_corpus,  # add type
        chunk_length: int = 5000,
    ) -> common_config.Matrices:

    # absolute frequencies
    abs_tup = initialize_tfidf(
        bow_corpus,
        'nnn', 
        len(corp_lemma_tar),
        len(corp_lemma_ref)
    )

    # binary frequencies
    bin_tup = initialize_tfidf(
        bow_corpus,
        'bnn', 
        len(corp_lemma_tar),
        len(corp_lemma_ref)
    )

    # relative frequencies
    rel_tar = abs_tup[0].copy()
    rel_tar.data /= chunk_length
    rel_ref = abs_tup[1].copy()
    rel_ref.data /= chunk_length

    data = common_config.Matrices(
    abs_tar = abs_tup[0],
    abs_ref = abs_tup[1],
    rel_tar = rel_tar,
    rel_ref = rel_ref,
    bin_tar = bin_tup[0],
    bin_ref = bin_tup[1],
    )

    return data