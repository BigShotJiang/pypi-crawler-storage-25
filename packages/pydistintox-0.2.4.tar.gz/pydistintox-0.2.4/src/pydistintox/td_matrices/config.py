measures_available = [
    'nfn',
    'nfc',
    'bfn',
    'afn',
    'lfn',
    'ltc'
]

DEFAULT_CHUNK_LENGTH = 5000

# if no scaling is wished, this "scaler" is used
class DummyScaler:
    def fit_transform(self, X):

        return X
