# standard library imports
import logging
from pathlib import Path

# third-party imports
import spacy  # only for type declaration in parse
from spacy.tokens import Doc

# application-specific imports
import pydistintox.common.utils as common_utils

# intra-package imports

SPACY_MAX_CHARS = 1_000_000


# ner takes quite long and is not necessary, hence disabled
def parse(
        file_content: str, 
        spacy_model: spacy.language.Language,
    )-> Doc:
    """
    Takes string from file and parses with spacy
    Spacy has a hard size limit for texts with
    > 1 million chars.
    """

    logging.debug(f'parse with spacy: {file_content[:30]}...')

    if len(file_content) > SPACY_MAX_CHARS:  # spacy needs chunks below one million
        big_chunks = [
            file_content[i:i + 999999] 
            for i in range(0, len(file_content), SPACY_MAX_CHARS)
        ]
        big_chunk_docs = [spacy_model(x) for x in big_chunks]
        file_doc = Doc.from_docs(big_chunk_docs) 
    else:
        # if chunk is smaller:
        file_doc = spacy_model(file_content)

    return file_doc


def extract_lemmas(spacy_doc: Doc) -> list[str]:
    """
    Extracts lemmas from a SpaCy Doc, excluding punctuation, digits, and whitespace.
    """

    return [
        token.lemma_.lower()
        for token in spacy_doc
        if not (token.is_punct or token.is_digit or token.is_space)
    ]


def chunk_lemmas(
        lemmas: list[str],
        chunk_length: int,
    )->list[list[str]]:
    """
    Extracts lemmas from a SpaCy Doc, filtering out punctuation, digits, and whitespace.
    Returns a list of lowercase lemmas.    
    """

    return common_utils.chunk_list(
        items = lemmas,
        chunk_length = chunk_length,
    )


def create_corp(path:Path)->list[tuple[str, str]]:
    """
    Collects all .txt files from the specified directory and 
    returns a list of tuples, each containing the filename 
    and its content as a string.
    
    gives a list of tuples: list[tuple[name_of_file, file_content]]
    """
    return common_utils.scan_directory(
        common_utils.create_pathlist(
            path,
            'txt'
        )
    )




