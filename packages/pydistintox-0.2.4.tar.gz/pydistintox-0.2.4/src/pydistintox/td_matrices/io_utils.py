
# standard library imports
import json
import logging
from pathlib import Path
from typing import Any

# third-party imports
import spacy  # only for type declaration in parse
from spacy.tokens import Doc

# application-specific imports
import pydistintox.common.utils as common_utils

# intra-package imports
from .parsing import (
    chunk_lemmas,
    extract_lemmas,
    parse,
)


""" serialisation """
def write_doc(
        dir : Path, 
        file_name : str, 
        spacy_doc : Doc
    )-> dict[str,Any]:
    """
    Serialize parsed full text as json and write to disk
    """

    file_json = spacy_doc.to_json()
    json_file_name = file_name.replace('.txt', '.json')
    save_path = dir / json_file_name

    with open(save_path, 'w', encoding='utf-8') as j:
        json.dump(file_json, j)
        logging.info(f'{json_file_name} saved in {dir}.')

    return file_json


def generate_spacy_documents(
        corp: list[tuple[str, str]],
        spacy_model: spacy.language.Language
    ) -> list[tuple[str, Doc]]:
    """Processes texts into spaCy Docs (with chunking if needed)."""
    return [(
        filename, 
        parse(content, spacy_model)
    ) for filename, content in corp]


""" Loading """
def reconstruct_spacy_doc(
        doc_json: dict, 
        nlp: spacy.language.Language
    ) -> Doc:
    """
    Reconstructs a SpaCy Doc from its JSON representation.
    """

    return Doc(nlp.vocab).from_json(doc_json)


def create_corp_with_id_from_path(
    chunked_lemmas: list[list[str]],
    json_path: Path
) -> list[tuple[str, list[str]]]:
    """
    Creates a list of tuples, each consisting of an identifier (based on the filename and chunk number)
    and the actual chunk content.

    Args:
        chunked_lemmas: List of chunks (e.g., from json_to_lemmas).
        json_path: Path to the JSON file, used to generate the identifier from the filename.

    Returns:
        List of tuples in the format (identifier, chunk).
    """
    return [
        (
            f"{str(json_path.parts[-1]).replace('.json', '')}_{str(x[0])}",
            x[1]
        )
        for x in enumerate(chunked_lemmas)
    ]


def load_doc_from_json(
        json_path: Path,
        nlp:  spacy.language.Language,
        chunk_length: int = 5000
    )-> list[tuple[str, list[str]]]:
    """
    Loads a JSON file, processes it into chunks, 
    with identifiers.

    More precise and efficient chunking. Backport to keyterms_en.py!
    We count lemmas per chunk, not punctuation and/or digits.
    """

    logging.debug(f'Load the following json_file: {json_path}')

    with open(json_path, 'r') as js:
        doc_json = json.load(js)
        
        spacy_doc = reconstruct_spacy_doc(
            doc_json,
            nlp
        )

        lemmas = extract_lemmas(spacy_doc)
        chunked_lemmas = chunk_lemmas(
            lemmas,
            chunk_length,
            )
        
        # the chunked_lemmas_with_ids consist of an identifier in the first and the chunk in the second place
        chunked_lemmas_with_ids = create_corp_with_id_from_path(
            chunked_lemmas,
            json_path
        )

    return chunked_lemmas_with_ids


def load_corp_from_dir(
        path_dir: Path,
        spacy_model: spacy.language.Language,
        # this needs to be the same model as the was saved with!
    )->list[tuple[str,list[str]]]:
    """
    Loads and aggregates chunks from all JSON files in a directory.
    """

    corp = []
    pathlist_json = common_utils.create_pathlist(path_dir, 'json')

    for one_path in pathlist_json:
        lemma_doc_list = load_doc_from_json(one_path, spacy_model)
        corp.extend(lemma_doc_list)

    
    
    return corp