# Contributing to PHOTON-Q

Thank you for your interest in contributing to **PHOTON-Q**!

## How to Contribute

### 1. Report Bugs
- Use GitHub/GitLab Issues
- Include: Python version, OS, optical regime, steps to reproduce
- Label: `bug`

### 2. Suggest Features
- Open an issue with label `enhancement`
- Describe the use case and expected behavior
- New optical regimes are welcome

### 3. Submit Code Changes

#### Prerequisites
```bash
pip install -e .[dev]
pre-commit install
```

Development Workflow

```bash
git clone https://github.com/YOUR_USERNAME/PHOTON-Q
cd PHOTON-Q
git checkout -b feature/your-feature-name
pytest tests/ -v
git commit -m "feat: add QOEI parameter"
git push origin feature/your-feature-name
```

4. Update Documentation

· Edit README.md, docs/, or docstrings
· Ensure make docs builds successfully

Code Style

· Python: PEP 8 (use black)
· Type hints: Required for all public functions
· Docstrings: Google style

Testing Requirements

· All tests must pass: pytest tests/ -v
· Coverage should not decrease: pytest --cov=photon_q
· New features require tests
· Physical constraints must be enforced in PINN layers

Commit Convention

Type Description
feat New feature
fix Bug fix
docs Documentation
test Testing
refactor Code refactor
perf Performance improvement

Questions?

Open an issue or email: gitdeeper@gmail.com

---

Thank you for contributing to quantum-optical AI and coherence control! 🔬
