"""PHOTON-Q: Neural Wavefront Intelligence for Phase-Coherent Quantum-Optical Systems.

A Physics-Informed AI framework for Neural Helmholtz Prediction,
Phase Coherence Tensor tracking, and Quantum-Optical Efficiency Index computation
in high-noise photonic and quantum communication environments.
"""

__version__ = "1.0.0"
__doi__ = "10.5281/zenodo.19729926"
__author__ = "Samir Baladi"
__email__ = "gitdeeper@gmail.com"

from photon_q.core.psi_dynamics_tracker import PsiDynamicsTracker
from photon_q.core.qoei import QOEIComputer

__all__ = [
    "PsiDynamicsTracker",
    "QOEIComputer",
]
