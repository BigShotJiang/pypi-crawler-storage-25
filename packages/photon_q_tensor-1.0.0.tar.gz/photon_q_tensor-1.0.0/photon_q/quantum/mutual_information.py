"""Quantum mutual information I(ρ_in; ρ_out)."""

import math
from typing import List


class MutualInformation:
    """Compute quantum mutual information."""
    
    @staticmethod
    def compute(rho_in: List[List[complex]], rho_out: List[List[complex]]) -> float:
        """Compute I(ρ_in; ρ_out) = S(ρ_in) + S(ρ_out) - S(ρ_in, ρ_out)."""
        # Simplified: compute from fidelity
        dim = len(rho_in)
        fidelity = 0.0
        
        for i in range(dim):
            for j in range(dim):
                fidelity += abs(rho_in[i][j] * rho_out[i][j].conjugate())
        
        signal = fidelity
        noise = 1 - fidelity
        
        if noise > 0 and signal > 0:
            mutual_info = signal * math.log2(signal / noise)
        else:
            mutual_info = 0.0
        
        return max(0.0, min(1.0, mutual_info))
