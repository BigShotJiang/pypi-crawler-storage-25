"""Holevo channel capacity upper bound."""

import math
from typing import List


class HolevoBound:
    """Compute Holevo bound for channel capacity."""
    
    @staticmethod
    def compute(snr_db: float = 8.0) -> float:
        """Compute Holevo bound from SNR."""
        # Holevo bound: χ = log₂(1 + SNR)
        snr_linear = 10 ** (snr_db / 10)
        capacity = math.log2(1 + snr_linear)
        return capacity
