"""Von Neumann relative entropy S(ρ||σ)."""

import math
from typing import List


class VonNeumannEntropy:
    """Compute von Neumann relative entropy."""
    
    @staticmethod
    def compute(rho: List[List[complex]], sigma: List[List[complex]]) -> float:
        """Compute S(ρ||σ) = Tr(ρ log ρ - ρ log σ)."""
        # Simplified: compute from fidelity difference
        dim = len(rho)
        fidelity_rho = 0.0
        fidelity_sigma = 0.0
        
        for i in range(dim):
            fidelity_rho += abs(rho[i][i])
            fidelity_sigma += abs(sigma[i][i])
        
        fidelity_rho /= dim
        fidelity_sigma /= dim
        
        entropy = abs(fidelity_rho - fidelity_sigma)
        
        return max(0.0, min(0.5, entropy))
