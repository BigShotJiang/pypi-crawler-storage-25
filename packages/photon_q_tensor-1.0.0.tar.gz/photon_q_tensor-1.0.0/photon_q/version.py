"""Version information for PHOTON-Q."""

__version__ = "1.0.0"
__doi__ = "10.5281/zenodo.19729926"
__release_date__ = "2026-04-25"
