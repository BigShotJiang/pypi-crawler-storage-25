"""Live QOEI monitoring dashboard."""

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class DashboardData:
    """Dashboard data for visualization."""
    qoei_value: float
    status: str
    coherence_trace: float
    decoherence_rate: float
    history: List[float]
    alert_level: str


class QOEIDashboard:
    """Generate dashboard data for QOEI monitoring."""
    
    def __init__(self):
        self.history: List[float] = []
    
    def update(self, qoei: float) -> None:
        """Update QOEI history."""
        self.history.append(qoei)
        if len(self.history) > 100:
            self.history.pop(0)
    
    def get_data(self, qoei: float, status: str, coherence_trace: float, decoherence_rate: float) -> DashboardData:
        """Get dashboard data for current state."""
        self.update(qoei)
        
        if qoei >= 0.95:
            alert = "NORMAL"
        elif qoei >= 0.80:
            alert = "WARNING"
        else:
            alert = "CRITICAL"
        
        return DashboardData(
            qoei_value=qoei,
            status=status,
            coherence_trace=coherence_trace,
            decoherence_rate=decoherence_rate,
            history=self.history.copy(),
            alert_level=alert
        )
