"""Visualization module for PHOTON-Q."""

from photon_q.visualization.qoei_dashboard import QOEIDashboard

__all__ = ["QOEIDashboard"]
