"""Phase-Locking Algorithm (PLA) — model-predictive coherence maximization.

Objective: max_{φ_corr} ∫₀ᵀ Tr[C(t, φ_corr)] dt subject to |φ_corr(t)| ≤ φ_max
"""

import math
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class PLAResult:
    """Phase-Locking Algorithm result."""
    phase_correction: float  # φ_corr (rad)
    predicted_coherence: float
    horizon_seconds: float
    optimal: bool


class PhaseLockingAlgorithm:
    """Phase-Locking Algorithm using model-predictive control."""

    def __init__(self, max_correction_rad: float = math.pi, horizon_us: float = 100.0):
        self.phi_max = max_correction_rad
        self.horizon = horizon_us * 1e-6  # convert to seconds

    def compute(
        self,
        current_coherence: float,
        decoherence_rate: float,
        coherence_slope: Optional[float] = None,
    ) -> PLAResult:
        """Compute optimal phase correction.

        Args:
            current_coherence: Tr[C(t)] — current coherence trace
            decoherence_rate: Γ_θ(t) — predicted decoherence rate
            coherence_slope: d/dt Tr[C(t)] — rate of coherence change

        Returns:
            PLAResult with optimal phase correction
        """
        if coherence_slope is None:
            coherence_slope = -decoherence_rate * current_coherence

        # Predict coherence at horizon
        predicted_coherence = current_coherence + coherence_slope * self.horizon
        predicted_coherence = max(0.0, min(1.0, predicted_coherence))

        # Compute required phase correction to maximize coherence
        # Simplified: φ_corr ∝ (1 - predicted_coherence) * decoherence_rate
        if predicted_coherence < 0.9:
            correction_raw = (1.0 - predicted_coherence) * decoherence_rate / 1e6
        else:
            correction_raw = 0.0

        # Apply saturation limit
        phi_corr = max(-self.phi_max, min(self.phi_max, correction_raw * self.phi_max))

        is_optimal = abs(phi_corr) < self.phi_max * 0.8

        return PLAResult(
            phase_correction=phi_corr,
            predicted_coherence=predicted_coherence,
            horizon_seconds=self.horizon,
            optimal=is_optimal,
        )
