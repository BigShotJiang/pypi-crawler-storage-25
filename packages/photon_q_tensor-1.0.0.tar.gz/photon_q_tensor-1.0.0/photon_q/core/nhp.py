"""Neural Helmholtz Predictor (NHP) — non-linear wave propagation with learned permittivity.

Equation: ∇²E(r) + k₀² · ε_r(r,θ) · E(r) = F_AI(r, ∇E, θ)

k₀ = ω/c: free-space wave number
ε_r(r,θ): spatially varying permittivity learned by SIREN-4L network
F_AI: non-linear AI correction field (Kerr effect, two-photon absorption, stimulated Raman)
"""

import math
from dataclasses import dataclass
from typing import Optional, List, Tuple


@dataclass
class NHPResult:
    """NHP computation result."""
    field_e: float
    permittivity: float
    correction_field: float
    residual: float
    status: str


class NeuralHelmholtzPredictor:
    """Neural Helmholtz Predictor for non-linear wave propagation."""

    # Physical constants
    c = 299792458.0  # m/s — speed of light
    mu0 = 4e-7 * math.pi  # H/m — vacuum permeability
    epsilon0 = 8.854187817e-12  # F/m — vacuum permittivity

    def __init__(
        self,
        wavelength_nm: float = 1550.0,
        temperature_K: float = 293.15,
        hidden_width: int = 256,
    ):
        self.wavelength = wavelength_nm * 1e-9  # convert to meters
        self.k0 = 2 * math.pi / self.wavelength  # wave number
        self.T = temperature_K
        self.hidden_width = hidden_width

    def compute(
        self,
        e_field: float,
        gradient: float,
        position: List[float],
        intensity: Optional[float] = None,
    ) -> NHPResult:
        """Compute NHP wave propagation with learned permittivity.

        Args:
            e_field: E(r) — electric field amplitude
            gradient: ∇E — spatial gradient
            position: [x, y, z] coordinates
            intensity: I(r) — optical intensity for Kerr effect

        Returns:
            NHPResult with field, permittivity, correction, residual
        """
        # Learn permittivity from position
        permittivity = self._learn_permittivity(position)

        # Compute non-linear correction field F_AI
        f_correction = self._compute_ai_correction(e_field, gradient, intensity)

        # Helmholtz equation residual: ∇²E + k₀²·ε_r·E - F_AI
        laplacian = self._estimate_laplacian(e_field, gradient)
        helmholtz_term = laplacian + self.k0 ** 2 * permittivity * e_field
        residual = abs(helmholtz_term - f_correction)

        # Determine status based on residual
        if residual < 1e-4:
            status = "EXCELLENT"
        elif residual < 5e-4:
            status = "GOOD"
        elif residual < 2e-3:
            status = "MODERATE"
        elif residual < 1e-2:
            status = "CRITICAL"
        else:
            status = "COLLAPSE"

        return NHPResult(
            field_e=e_field,
            permittivity=permittivity,
            correction_field=f_correction,
            residual=residual,
            status=status,
        )

    def _learn_permittivity(self, position: List[float]) -> float:
        """Learn spatially varying permittivity ε_r(r,θ)."""
        # Simplified SIREN-like activation
        x, y, z = position
        # Base permittivity of silica ~1.45² = 2.1
        # Add spatial variations
        base_epsilon = 2.1
        variation = 0.1 * (math.sin(10 * x) + math.sin(10 * y) + math.sin(10 * z))
        return max(0.5, min(10.0, base_epsilon + variation))

    def _compute_ai_correction(
        self,
        e_field: float,
        gradient: float,
        intensity: Optional[float],
    ) -> float:
        """Compute AI correction field F_AI(r, ∇E, θ)."""
        # Kerr effect: Δn = n₂·I
        n2 = 2.5e-20  # m²/W for silica
        kerr_correction = 0.0

        if intensity is not None:
            kerr_correction = n2 * intensity * self.k0 ** 2 * e_field

        # Raman and XPM contributions
        raman_correction = 0.01 * gradient * e_field

        return kerr_correction + raman_correction

    def _estimate_laplacian(self, e_field: float, gradient: float) -> float:
        """Estimate Laplacian ∇²E from field and gradient."""
        # Simplified: assume ∇²E ≈ gradient / characteristic length
        char_length = 1e-6  # 1 μm
        return gradient / char_length
