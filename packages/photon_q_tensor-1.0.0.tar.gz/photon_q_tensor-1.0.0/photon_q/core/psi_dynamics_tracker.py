"""PsiDynamicsTracker — central state evolution object for PHOTON-Q.

Encapsulates density matrix ρ(t), phase coherence tensor C(t), and QOEI trajectory.
"""

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from photon_q.core.nhp import NeuralHelmholtzPredictor, NHPResult
from photon_q.core.pct import PhaseCoherenceTensor, PCTResult
from photon_q.core.qoei import QOEIComputer, QOEIResult
from photon_q.core.phase_locking import PhaseLockingAlgorithm, PLAResult


@dataclass
class TrackerState:
    """Full state of PsiDynamicsTracker at time t."""
    timestamp: float
    coherence_trace: float
    decoherence_rate: float
    phase_correction: float
    qoei: float
    status: str


class PsiDynamicsTracker:
    """Main state tracker for quantum-optical coherence evolution."""

    def __init__(
        self,
        mode_dim: int = 64,
        lstm_hidden: int = 128,
        wavelength_nm: float = 1550.0,
    ):
        self.mode_dim = mode_dim
        self.lstm_hidden = lstm_hidden
        self.wavelength_nm = wavelength_nm

        # Initialize components
        self.nhp = NeuralHelmholtzPredictor(wavelength_nm=wavelength_nm)
        self.pct = PhaseCoherenceTensor(mode_dim=mode_dim, lstm_hidden=lstm_hidden)
        self.qoei_computer = QOEIComputer()
        self.pla = PhaseLockingAlgorithm()

        # State variables
        self._t = 0.0
        self._coherence_trace = 1.0
        self._coherence_history: List[float] = []

        # Mode amplitudes (initialized to coherent state)
        self._mode_amplitudes = [complex(1.0 / math.sqrt(mode_dim), 0.0) for _ in range(mode_dim)]

    def step(
        self,
        dt: float,
        env_obs: Dict[str, float],
        optical_field: Optional[float] = None,
        intensity: Optional[float] = None,
    ) -> TrackerState:
        """Single-step state evolution.

        Args:
            dt: Timestep (seconds)
            env_obs: Environmental observations dict
                keys: 'temperature_K', 'vibration_psd', 'em_background'
            optical_field: Current optical field amplitude E(r)
            intensity: Current optical intensity (W/m²) for Kerr effect

        Returns:
            TrackerState after evolution
        """
        # Extract environmental readings
        temperature = env_obs.get('temperature_K', 293.15)
        vibration_psd = env_obs.get('vibration_psd', 1e-15)
        em_background = env_obs.get('em_background', 1e-12)

        # Update time
        self._t += dt

        # Predict decoherence rate from sensors
        gamma = self.pct.predict_decoherence_rate(temperature, vibration_psd, em_background)

        # Update mode amplitudes with decoherence
        for i in range(self.mode_dim):
            decay = math.exp(-gamma * dt)
            self._mode_amplitudes[i] *= decay

        # Compute Phase Coherence Tensor
        pct_result = self.pct.compute(self._mode_amplitudes, gamma, dt)
        self._coherence_trace = pct_result.coherence_trace
        self._coherence_history.append(self._coherence_trace)

        # Compute NHP if field provided
        if optical_field is not None:
            # Simplified gradient estimation
            gradient = 1e3  # V/m²
            position = [0.0, 0.0, 0.0]
            nhp_result = self.nhp.compute(optical_field, gradient, position, intensity)

        # Compute optimal phase correction
        coherence_slope = self._get_coherence_slope()
        pla_result = self.pla.compute(self._coherence_trace, gamma, coherence_slope)

        # Apply phase correction to mode amplitudes
        for i in range(self.mode_dim):
            phase_shift = pla_result.phase_correction * math.sin(2 * math.pi * i / self.mode_dim)
            self._mode_amplitudes[i] *= complex(math.cos(phase_shift), math.sin(phase_shift))

        # Compute QOEI
        qoei_result = self.qoei_computer.compute(
            input_state=1.0,
            output_state=self._coherence_trace,
            channel_capacity=1.0,
        )

        # Determine overall status
        status = self._get_overall_status(pct_result.status, qoei_result.status)

        return TrackerState(
            timestamp=self._t,
            coherence_trace=self._coherence_trace,
            decoherence_rate=gamma,
            phase_correction=pla_result.phase_correction,
            qoei=qoei_result.value,
            status=status,
        )

    def _get_coherence_slope(self) -> float:
        """Estimate coherence trace slope from history."""
        if len(self._coherence_history) < 3:
            return -self._coherence_history[-1] * 1e6 if self._coherence_history else -1e3

        # Linear fit on last 3 points
        recent = self._coherence_history[-3:]
        slope = (recent[-1] - recent[-3]) / 2.0
        return slope

    def _get_overall_status(self, pct_status: str, qoei_status: str) -> str:
        """Combine PCT and QOEI status into overall status."""
        status_priority = ["EXCELLENT", "GOOD", "MODERATE", "CRITICAL", "COLLAPSE"]

        def priority(status):
            return status_priority.index(status) if status in status_priority else 3

        return status_priority[min(priority(pct_status), priority(qoei_status))]

    def reset(self):
        """Reset tracker to initial coherent state."""
        self._t = 0.0
        self._coherence_trace = 1.0
        self._coherence_history = []
        self._mode_amplitudes = [complex(1.0 / math.sqrt(self.mode_dim), 0.0) for _ in range(self.mode_dim)]
