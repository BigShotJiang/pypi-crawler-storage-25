"""Quantum-Optical Efficiency Index (QOEI) — unified information-theoretic metric.

Equation: η_Q = [I(ρ_in; ρ_out) - S(ρ_out||ρ_in)] / I_max ∈ [0, 1]

I(·;·): quantum mutual information
S(·||·): von Neumann relative entropy (entropic overhead)
I_max: channel capacity upper bound (Holevo bound)
"""

import math
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class QOEIResult:
    """QOEI computation result."""
    value: float  # η_Q
    status: str
    mutual_information: float
    relative_entropy: float
    channel_capacity: float
    recommendation: str


class QOEIComputer:
    """Quantum-Optical Efficiency Index computer."""

    # QOEI thresholds (from paper)
    THRESHOLDS = {
        "EXCELLENT": (0.95, 1.0),
        "GOOD": (0.90, 0.95),
        "MODERATE": (0.80, 0.90),
        "CRITICAL": (0.65, 0.80),
        "COLLAPSE": (0.0, 0.65),
    }

    def compute(
        self,
        input_state: Optional[float] = None,
        output_state: Optional[float] = None,
        channel_capacity: float = 1.0,
    ) -> QOEIResult:
        """Compute QOEI from quantum states.

        Args:
            input_state: ρ_in — input quantum state (or fidelity)
            output_state: ρ_out — output quantum state (or fidelity)
            channel_capacity: I_max — Holevo bound upper limit

        Returns:
            QOEIResult with η_Q and status
        """
        # Default values if not provided
        if input_state is None:
            input_state = 1.0
        if output_state is None:
            output_state = 0.94

        # Quantum mutual information I(ρ_in; ρ_out)
        # Simplified: I = log2(1 + SNR) / log2(1 + SNR_max)
        snr = 10 ** (9 / 10)  # 8 dB SNR
        snr_max = 10 ** (20 / 10)  # 20 dB SNR max
        mutual_info = math.log2(1 + snr) / math.log2(1 + snr_max)

        # Von Neumann relative entropy S(ρ_out||ρ_in)
        # Simplified: entropy penalty from fidelity loss
        fidelity = output_state / max(input_state, 0.01)
        relative_entropy = max(0.0, (1.0 - fidelity) * 0.3)

        # QOEI formula
        qoei_raw = (mutual_info - relative_entropy) / max(channel_capacity, 0.01)
        qoei = max(0.0, min(1.0, qoei_raw))

        # Determine status
        status = self._get_status(qoei)

        # Generate recommendation
        recommendation = self._get_recommendation(status)

        return QOEIResult(
            value=qoei,
            status=status,
            mutual_information=mutual_info,
            relative_entropy=relative_entropy,
            channel_capacity=channel_capacity,
            recommendation=recommendation,
        )

    def _get_status(self, value: float) -> str:
        """Get status based on QOEI value."""
        for status, (low, high) in self.THRESHOLDS.items():
            if low <= value < high:
                return status
        if value >= 0.95:
            return "EXCELLENT"
        return "COLLAPSE"

    def _get_recommendation(self, status: str) -> str:
        """Generate intervention recommendation."""
        recommendations = {
            "EXCELLENT": "Continue standard coherence monitoring",
            "GOOD": "Schedule periodic phase calibration review",
            "MODERATE": "Phase-locking parameter retuning required",
            "CRITICAL": "Emergency coherence recovery — check environment sensors",
            "COLLAPSE": "Immediate optical channel shutdown and full recalibration",
        }
        return recommendations.get(status, "Monitor system closely")
