"""Phase Coherence Tensor (PCT) — Hermitian multi-mode coherence tracking.

Equation: C(t) = Σᵢⱼ αᵢ*(t,θ) · αⱼ(t,θ) · exp(-Γ_θ(t)·|i-j|·Δt)

αᵢ(t,θ): neurally optimized mode amplitude
Γ_θ(t): learned decoherence rate — predicted from environmental sensors
Δt: coherence sampling interval
"""

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class PCTResult:
    """PCT computation result."""
    coherence_trace: float
    coherence_tensor: List[List[complex]]
    decoherence_rate: float
    status: str
    mode_amplitudes: List[complex]


class PhaseCoherenceTensor:
    """Phase Coherence Tensor for multi-mode coherence tracking."""

    def __init__(self, mode_dim: int = 64, lstm_hidden: int = 128):
        self.mode_dim = mode_dim
        self.lstm_hidden = lstm_hidden
        self._history: List[float] = []

    def compute(
        self,
        mode_amplitudes: List[complex],
        decoherence_rate: float,
        dt: float = 1e-9,
    ) -> PCTResult:
        """Compute Phase Coherence Tensor.

        Args:
            mode_amplitudes: List of complex mode amplitudes αᵢ
            decoherence_rate: Γ_θ(t) — decoherence rate (s⁻¹)
            dt: Coherence sampling interval Δt (s)

        Returns:
            PCTResult with coherence trace, tensor, and status
        """
        dim = len(mode_amplitudes)
        if dim == 0:
            dim = self.mode_dim
            mode_amplitudes = [complex(1.0, 0.0) for _ in range(dim)]

        # Build coherence tensor C_ij
        coherence_tensor = []
        for i in range(dim):
            row = []
            for j in range(dim):
                amplitude_product = mode_amplitudes[i].conjugate() * mode_amplitudes[j]
                decoherence_factor = math.exp(-decoherence_rate * abs(i - j) * dt)
                row.append(amplitude_product * decoherence_factor)
            coherence_tensor.append(row)

        # Compute coherence trace Tr(C)
        trace = sum(abs(row[i]) for i, row in enumerate(coherence_tensor))

        # Normalize trace to [0, 1]
        max_trace = dim if dim > 0 else 1
        trace_norm = min(1.0, trace / max_trace)

        # Determine status
        if trace_norm > 0.95:
            status = "EXCELLENT"
        elif trace_norm > 0.85:
            status = "GOOD"
        elif trace_norm > 0.70:
            status = "MODERATE"
        elif trace_norm > 0.50:
            status = "CRITICAL"
        else:
            status = "COLLAPSE"

        return PCTResult(
            coherence_trace=trace_norm,
            coherence_tensor=coherence_tensor,
            decoherence_rate=decoherence_rate,
            status=status,
            mode_amplitudes=mode_amplitudes,
        )

    def predict_decoherence_rate(
        self,
        temperature: float,
        vibration_psd: float,
        em_noise: float,
    ) -> float:
        """Predict decoherence rate from environmental sensors.

        Using LSTM-like prediction (simplified).

        Args:
            temperature: Temperature (K)
            vibration_psd: Vibration power spectral density (W/Hz)
            em_noise: Electromagnetic background noise power (W)

        Returns:
            Predicted decoherence rate Γ_θ (s⁻¹)
        """
        # Base decoherence rate
        base_gamma = 1e6  # 1 MHz baseline

        # Temperature contribution: increased at higher T
        temp_contribution = max(0, (temperature - 293.15) * 1e4)

        # Vibration contribution
        vibration_contribution = vibration_psd * 1e15

        # EM noise contribution
        em_contribution = em_noise * 1e20

        gamma = base_gamma + temp_contribution + vibration_contribution + em_contribution

        # Update history
        self._history.append(gamma)
        if len(self._history) > 1000:
            self._history.pop(0)

        return gamma
