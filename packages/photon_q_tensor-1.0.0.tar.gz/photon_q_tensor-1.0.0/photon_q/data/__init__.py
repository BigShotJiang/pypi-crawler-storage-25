"""Data pipeline module for PHOTON-Q."""

from photon_q.data.optical_loader import OpticalLoader

__all__ = ["OpticalLoader"]
