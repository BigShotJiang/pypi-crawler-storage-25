"""Optical measurement data loader."""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class OpticalMeasurement:
    """Single optical measurement record."""
    channel_id: str
    regime: str
    qoei: float
    coherence_trace: float
    decoherence_rate: float
    timestamp: float


class OpticalLoader:
    """Load optical measurement data from various sources."""
    
    def load_batch(self, data_dir: str, pattern: str = "*.h5") -> List[OpticalMeasurement]:
        """Load batch of optical measurements."""
        # Simplified: return simulated data
        import random
        import time
        
        measurements = []
        regimes = ["R1", "R2", "R3", "R4", "R5", "R6"]
        
        for i, regime in enumerate(regimes):
            measurement = OpticalMeasurement(
                channel_id=f"CH-{i+1:02d}",
                regime=regime,
                qoei=random.uniform(0.85, 0.98),
                coherence_trace=random.uniform(0.80, 0.99),
                decoherence_rate=random.uniform(1e6, 1e8),
                timestamp=time.time()
            )
            measurements.append(measurement)
        
        return measurements
