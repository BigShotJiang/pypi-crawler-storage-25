"""Real-time QOEI monitoring engine."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class CoherenceRecord:
    """Single coherence measurement record."""
    timestamp: float
    qoei: float
    status: str
    coherence_trace: float
    decoherence_rate: float


class CoherenceMonitor:
    """Real-time coherence monitor for optical channels."""
    
    def __init__(self, alert_threshold: float = 0.80):
        self.alert_threshold = alert_threshold
        self.history: List[CoherenceRecord] = []
    
    def update(self, qoei: float, status: str, coherence_trace: float, decoherence_rate: float) -> CoherenceRecord:
        """Update monitor with new measurement."""
        import time
        
        record = CoherenceRecord(
            timestamp=time.time(),
            qoei=qoei,
            status=status,
            coherence_trace=coherence_trace,
            decoherence_rate=decoherence_rate
        )
        self.history.append(record)
        
        if len(self.history) > 1000:
            self.history.pop(0)
        
        return record
    
    def get_mean_qoei(self) -> float:
        """Get mean QOEI over recent history."""
        if not self.history:
            return 0.0
        return sum(r.qoei for r in self.history) / len(self.history)
    
    def get_trend(self) -> str:
        """Get QOEI trend."""
        if len(self.history) < 5:
            return "stable"
        
        recent = [r.qoei for r in self.history[-5:]]
        if recent[-1] > recent[0] * 1.02:
            return "improving"
        elif recent[-1] < recent[0] * 0.98:
            return "degrading"
        return "stable"
