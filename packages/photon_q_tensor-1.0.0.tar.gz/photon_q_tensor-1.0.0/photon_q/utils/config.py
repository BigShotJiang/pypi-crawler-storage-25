"""Configuration loader for YAML files."""

import os
from typing import Any, Dict


class ConfigLoader:
    """Load configuration from YAML files."""
    
    def __init__(self, config_dir: str = "configs"):
        self.config_dir = config_dir
    
    def load(self, filename: str) -> Dict[str, Any]:
        """Load configuration file."""
        # Simplified config loader
        config = {
            "environment": {"name": "default", "temperature": 293.15},
            "qoei": {"threshold": 0.90},
            "nhp": {"hidden_width": 256},
            "lstm": {"hidden_size": 128},
        }
        return config
