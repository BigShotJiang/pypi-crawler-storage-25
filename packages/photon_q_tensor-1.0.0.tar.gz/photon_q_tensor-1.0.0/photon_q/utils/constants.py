"""Physical constants for PHOTON-Q."""

# Speed of light
C_SPEED = 299792458.0  # m/s

# Reduced Planck constant
H_BAR = 1.054571817e-34  # J·s

# Vacuum permittivity
EPSILON_0 = 8.854187817e-12  # F/m

# Boltzmann constant
BOLTZMANN = 1.380649e-23  # J/K

# Electron charge
ELECTRON_CHARGE = 1.602176634e-19  # C

# Standard temperature
STANDARD_TEMPERATURE = 293.15  # K

# Quantum efficiency ideal
IDEAL_QOEI = 1.0
