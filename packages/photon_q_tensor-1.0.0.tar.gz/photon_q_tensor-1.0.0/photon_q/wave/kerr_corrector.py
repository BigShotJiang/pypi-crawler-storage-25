"""Kerr effect non-linear correction module."""

from dataclasses import dataclass


@dataclass
class KerrResult:
    """Kerr correction result."""
    delta_n: float
    correction_field: float


class KerrCorrector:
    """Kerr non-linear optical effect corrector."""

    def __init__(self, n2: float = 2.5e-20):  # m²/W for silica
        self.n2 = n2

    def compute(self, intensity: float, wavelength_nm: float = 1550.0) -> KerrResult:
        """Compute Kerr effect correction."""
        # Kerr-induced refractive index change: Δn = n₂·I
        delta_n = self.n2 * intensity
        
        # Correction field: Δn * k₀² * E
        k0 = 2 * math.pi / (wavelength_nm * 1e-9)
        correction = delta_n * k0 ** 2
        
        return KerrResult(delta_n=delta_n, correction_field=correction)
