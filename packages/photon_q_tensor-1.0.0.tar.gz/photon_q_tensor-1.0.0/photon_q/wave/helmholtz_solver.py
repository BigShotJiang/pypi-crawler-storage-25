"""Analytical Helmholtz PDE solver."""

import math
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class HelmholtzSolution:
    """Helmholtz equation solution."""
    field: float
    laplacian: float
    residual: float
    converged: bool


class HelmholtzSolver:
    """Helmholtz equation solver for wave propagation."""

    def __init__(self, k0: float = 4.05e6):  # ~1550 nm
        self.k0 = k0

    def solve(self, e_field: float, permittivity: float, gradient: float) -> HelmholtzSolution:
        """Solve Helmholtz equation: ∇²E + k₀²·ε_r·E = 0."""
        laplacian = gradient / 1e-6  # approximate
        helmholtz_term = laplacian + self.k0 ** 2 * permittivity * e_field
        residual = abs(helmholtz_term)
        
        return HelmholtzSolution(
            field=e_field,
            laplacian=laplacian,
            residual=residual,
            converged=residual < 1e-4
        )
