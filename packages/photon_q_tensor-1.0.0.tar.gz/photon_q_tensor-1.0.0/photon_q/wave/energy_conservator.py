"""Energy conservation constraint enforcer."""

from dataclasses import dataclass


@dataclass
class EnergyResult:
    """Energy conservation result."""
    incident_power: float
    output_power: float
    conservation_error: float
    conserved: bool


class EnergyConservator:
    """Enforce energy conservation in wave propagation."""

    def enforce(self, incident_field: float, output_field: float) -> EnergyResult:
        """Check and enforce energy conservation."""
        incident_power = incident_field ** 2
        output_power = output_field ** 2
        
        conservation_error = abs(incident_power - output_power) / max(incident_power, 1e-12)
        conserved = conservation_error < 0.01
        
        return EnergyResult(
            incident_power=incident_power,
            output_power=output_power,
            conservation_error=conservation_error,
            conserved=conserved
        )
