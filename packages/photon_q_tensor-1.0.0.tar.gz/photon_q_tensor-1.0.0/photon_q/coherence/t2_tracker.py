"""T2 dephasing time measurement module."""

from dataclasses import dataclass
from typing import List


@dataclass
class T2Result:
    """T2 measurement result."""
    t2_time: float  # seconds
    extension_factor: float
    baseline_t2: float


class T2Tracker:
    """Track T2 dephasing time and extension factor."""

    def __init__(self, baseline_t2: float = 1e-6):
        self.baseline_t2 = baseline_t2
        self.history: List[float] = []

    def measure(self, coherence_trace: float, time: float) -> T2Result:
        """Measure T2 from coherence trace decay."""
        self.history.append((time, coherence_trace))
        
        # Find time when coherence drops to 1/e
        t2 = self.baseline_t2
        if len(self.history) > 1:
            for t, c in self.history:
                if c < 0.3679:  # 1/e
                    t2 = t
                    break
        
        extension = t2 / self.baseline_t2 if self.baseline_t2 > 0 else 1.0
        
        return T2Result(t2_time=t2, extension_factor=extension, baseline_t2=self.baseline_t2)
