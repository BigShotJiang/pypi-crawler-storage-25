"""Quantum density matrix algebra (ρ)."""

import math
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class DensityMatrixResult:
    """Density matrix operation result."""
    matrix: List[List[complex]]
    trace: float
    purity: float
    valid: bool


class DensityMatrix:
    """Density matrix representation and operations."""

    @staticmethod
    def create_pure_state(dim: int, state_vector: List[complex]) -> List[List[complex]]:
        """Create density matrix from pure state: ρ = |ψ⟩⟨ψ|."""
        rho = [[0j for _ in range(dim)] for _ in range(dim)]
        for i in range(dim):
            for j in range(dim):
                rho[i][j] = state_vector[i] * state_vector[j].conjugate()
        return rho

    @staticmethod
    def trace(rho: List[List[complex]]) -> float:
        """Compute trace of density matrix."""
        return sum(rho[i][i].real for i in range(len(rho)))

    @staticmethod
    def purity(rho: List[List[complex]]) -> float:
        """Compute purity: Tr(ρ²)."""
        dim = len(rho)
        purity = 0.0
        for i in range(dim):
            for j in range(dim):
                purity += abs(rho[i][j]) ** 2
        return purity

    @staticmethod
    def is_valid(rho: List[List[complex]]) -> bool:
        """Check if density matrix is valid (Hermitian, trace=1, positive)."""
        # Check trace
        trace = DensityMatrix.trace(rho)
        if abs(trace - 1.0) > 1e-6:
            return False
        
        # Check Hermiticity
        dim = len(rho)
        for i in range(dim):
            for j in range(dim):
                if abs(rho[i][j] - rho[j][i].conjugate()) > 1e-6:
                    return False
        
        # Check positivity (simplified: purity ≤ 1)
        purity = DensityMatrix.purity(rho)
        if purity > 1.0 + 1e-6:
            return False
        
        return True
