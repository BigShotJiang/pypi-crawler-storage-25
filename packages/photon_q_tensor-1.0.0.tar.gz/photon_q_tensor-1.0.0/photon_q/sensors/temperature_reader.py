"""Thermal gradient sensor interface."""

from dataclasses import dataclass


@dataclass
class TemperatureReading:
    """Temperature sensor reading."""
    temperature_k: float
    gradient_kcm: float
    timestamp_us: float


class TemperatureReader:
    """Temperature sensor reader (4K - 320K range)."""
    
    def read(self) -> TemperatureReading:
        """Simulate temperature reading."""
        import random
        import time
        
        # Simulate room temperature with small fluctuations
        base_temp = 293.15
        fluctuation = random.uniform(-0.5, 0.5)
        
        return TemperatureReading(
            temperature_k=base_temp + fluctuation,
            gradient_kcm=random.uniform(0.1, 1.0),
            timestamp_us=time.time() * 1e6
        )
