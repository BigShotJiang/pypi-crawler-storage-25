"""LSTM decoherence rate predictor."""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class LSTMResult:
    """LSTM prediction result."""
    predicted_gamma: float  # s⁻¹
    confidence: float
    horizon_us: float


class DecoherenceLSTM:
    """LSTM-128 decoherence rate predictor with look-ahead."""

    def __init__(self, hidden_size: int = 128, horizon_us: float = 100.0):
        self.hidden_size = hidden_size
        self.horizon = horizon_us
        self._state: List[float] = []

    def predict(self, temperature: float, vibration_psd: float, em_noise: float) -> LSTMResult:
        """Predict decoherence rate 100 μs ahead."""
        # Simplified LSTM prediction
        base_gamma = 1e6
        
        temp_contrib = max(0, (temperature - 293.15) * 1e4)
        vib_contrib = vibration_psd * 1e15
        em_contrib = em_noise * 1e20
        
        predicted = base_gamma + temp_contrib + vib_contrib + em_contrib
        
        # Confidence based on prediction stability
        self._state.append(predicted)
        if len(self._state) > 100:
            self._state.pop(0)
        
        confidence = 0.95 if len(self._state) > 10 else 0.7
        
        return LSTMResult(predicted_gamma=predicted, confidence=confidence, horizon_us=self.horizon)
