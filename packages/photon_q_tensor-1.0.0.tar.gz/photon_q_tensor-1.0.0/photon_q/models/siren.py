"""SIREN network implementation (sinusoidal activation)."""

import math
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SIRENResult:
    """SIREN network output."""
    output: float
    hidden_activations: List[float]


class SIRENNetwork:
    """Sinusoidal Representation Network for permittivity learning."""

    def __init__(self, hidden_width: int = 256, omega0: float = 30.0):
        self.hidden_width = hidden_width
        self.omega0 = omega0

    def forward(self, x: float, y: float, z: float) -> SIRENResult:
        """Forward pass through SIREN network."""
        # Simplified SIREN activation
        input_val = self.omega0 * (x + y + z)
        hidden = [math.sin(input_val * (i + 1) / self.hidden_width) for i in range(self.hidden_width)]
        
        # Output layer (permittivity)
        output = 2.1 + 0.5 * math.sin(input_val)
        
        return SIRENResult(output=output, hidden_activations=hidden)
