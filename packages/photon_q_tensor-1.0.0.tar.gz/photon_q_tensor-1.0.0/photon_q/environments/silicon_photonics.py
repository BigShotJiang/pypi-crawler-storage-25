"""On-chip silicon photonics environment (R6)."""

from dataclasses import dataclass


@dataclass
class SiliconPhotonicsEnvironment:
    """Silicon photonics environment."""
    
    fabrication_disorder: float = 2e-3  # Δn_eff
    waveguide_crossing_loss_db: float = 0.1
    temperature_k: float = 298.15
    num_rings: int = 8
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.97, "GOOD": 0.94, "MODERATE": 0.90, "CRITICAL": 0.82}
    
    def get_baseline_t2_ns(self) -> float:
        return 200  # nanoseconds
