"""Fiber Bragg grating quantum memory environment (R3)."""

from dataclasses import dataclass


@dataclass
class FiberBraggEnvironment:
    """Fiber Bragg grating environment."""
    
    bandwidth_ghz: float = 50.0
    temperature_k: float = 293.15
    thermal_gradient_kcm: float = 0.5
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.96, "GOOD": 0.93, "MODERATE": 0.89, "CRITICAL": 0.79}
    
    def get_baseline_t2_ns(self) -> float:
        return 500  # nanoseconds
