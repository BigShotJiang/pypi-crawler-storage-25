"""Optical regime configurations for PHOTON-Q."""

from photon_q.environments.photonic_crystal import PhotonicCrystalEnvironment
from photon_q.environments.free_space_channel import FreeSpaceChannelEnvironment
from photon_q.environments.fiber_bragg import FiberBraggEnvironment
from photon_q.environments.kerr_waveguide import KerrWaveguideEnvironment
from photon_q.environments.atmospheric_link import AtmosphericLinkEnvironment
from photon_q.environments.silicon_photonics import SiliconPhotonicsEnvironment

__all__ = [
    "PhotonicCrystalEnvironment",
    "FreeSpaceChannelEnvironment",
    "FiberBraggEnvironment",
    "KerrWaveguideEnvironment",
    "AtmosphericLinkEnvironment",
    "SiliconPhotonicsEnvironment",
]
