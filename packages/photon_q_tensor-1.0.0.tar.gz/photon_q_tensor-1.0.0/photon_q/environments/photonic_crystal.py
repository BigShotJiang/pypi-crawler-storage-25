"""Photonic crystal cavity environment configuration (R1)."""

from dataclasses import dataclass


@dataclass
class PhotonicCrystalEnvironment:
    """Photonic crystal cavity environment."""
    
    cavity_mode: str = "TE_00"
    q_factor: float = 1.2e6
    temperature_k: float = 4.2
    phonon_bath_coupling: float = 1e-3
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.97, "GOOD": 0.94, "MODERATE": 0.90, "CRITICAL": 0.80}
    
    def get_baseline_t2_us(self) -> float:
        return 1.1  # microseconds
