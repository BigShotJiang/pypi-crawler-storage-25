"""Kerr-nonlinear waveguide environment (R4)."""

from dataclasses import dataclass


@dataclass
class KerrWaveguideEnvironment:
    """Kerr-nonlinear waveguide environment."""
    
    nonlinearity_n2: float = 2.5e-20  # m²/W
    peak_intensity_wcm2: float = 1e12
    waveguide_length_mm: float = 5.0
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.94, "GOOD": 0.90, "MODERATE": 0.85, "CRITICAL": 0.75}
    
    def get_baseline_t2_ns(self) -> float:
        return 10  # nanoseconds
