"""Atmospheric turbulence link environment (R5)."""

from dataclasses import dataclass


@dataclass
class AtmosphericLinkEnvironment:
    """Atmospheric turbulence link environment."""
    
    link_distance_km: float = 5.0
    cn2_turbulence: float = 1e-14  # m^(-2/3)
    wavelength_nm: float = 1550
    wind_speed_ms: float = 5.0
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.93, "GOOD": 0.89, "MODERATE": 0.84, "CRITICAL": 0.73}
    
    def get_baseline_t2_ns(self) -> float:
        return 5  # nanoseconds
