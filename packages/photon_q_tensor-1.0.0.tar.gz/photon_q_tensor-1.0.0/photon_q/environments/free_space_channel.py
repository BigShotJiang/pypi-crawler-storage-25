"""Free-space entanglement channel environment (R2)."""

from dataclasses import dataclass


@dataclass
class FreeSpaceChannelEnvironment:
    """Free-space QKD link environment."""
    
    link_distance_km: float = 10.0
    wavelength_nm: float = 1550
    aperture_diameter_m: float = 0.3
    turbulence_cn2: float = 1e-14
    
    def get_qoei_thresholds(self) -> dict:
        return {"EXCELLENT": 0.95, "GOOD": 0.92, "MODERATE": 0.88, "CRITICAL": 0.78}
    
    def get_baseline_t2_ns(self) -> float:
        return 50  # nanoseconds
