#!/usr/bin/env python
"""Framework performance benchmarking."""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from photon_q.core.qoei import QOEIComputer
from photon_q.core.nhp import NeuralHelmholtzPredictor
from photon_q.core.pct import PhaseCoherenceTensor
from photon_q.core.psi_dynamics_tracker import PsiDynamicsTracker


def benchmark_qoei(n_iterations: int = 1000):
    """Benchmark QOEI computation speed."""
    computer = QOEIComputer()
    
    start = time.time()
    for _ in range(n_iterations):
        result = computer.compute()
    elapsed = time.time() - start
    
    print(f"QOEI Computation: {n_iterations} iterations in {elapsed:.3f}s")
    print(f"  Average: {elapsed / n_iterations * 1000:.3f} ms per computation")
    return elapsed


def benchmark_nhp(n_iterations: int = 1000):
    """Benchmark NHP computation speed."""
    nhp = NeuralHelmholtzPredictor()
    
    start = time.time()
    for _ in range(n_iterations):
        result = nhp.compute(e_field=1.0, gradient=1e3, position=[0,0,0])
    elapsed = time.time() - start
    
    print(f"NHP Computation: {n_iterations} iterations in {elapsed:.3f}s")
    print(f"  Average: {elapsed / n_iterations * 1000:.3f} ms per computation")
    return elapsed


def benchmark_pct(n_iterations: int = 1000):
    """Benchmark PCT computation speed."""
    pct = PhaseCoherenceTensor(mode_dim=64)
    import math
    mode_amplitudes = [complex(1.0/math.sqrt(64), 0.0) for _ in range(64)]
    
    start = time.time()
    for _ in range(n_iterations):
        result = pct.compute(mode_amplitudes, decoherence_rate=1e6, dt=1e-9)
    elapsed = time.time() - start
    
    print(f"PCT Computation: {n_iterations} iterations in {elapsed:.3f}s")
    print(f"  Average: {elapsed / n_iterations * 1000:.3f} ms per computation")
    return elapsed


def benchmark_tracker(n_iterations: int = 100):
    """Benchmark PsiDynamicsTracker step speed."""
    tracker = PsiDynamicsTracker(mode_dim=32)
    env_obs = {'temperature_K': 293.15, 'vibration_psd': 1e-15, 'em_background': 1e-12}
    
    start = time.time()
    for _ in range(n_iterations):
        state = tracker.step(dt=1e-9, env_obs=env_obs)
    elapsed = time.time() - start
    
    print(f"Tracker Step: {n_iterations} iterations in {elapsed:.3f}s")
    print(f"  Average: {elapsed / n_iterations * 1000:.3f} ms per step")
    return elapsed


def main():
    print("=" * 60)
    print("PHOTON-Q Performance Benchmark")
    print("=" * 60)
    
    benchmark_qoei()
    print()
    benchmark_nhp()
    print()
    benchmark_pct()
    print()
    benchmark_tracker()
    
    print()
    print("=" * 60)
    print("✅ Benchmark complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
