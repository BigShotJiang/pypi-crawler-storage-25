#!/usr/bin/env python
"""Generate daily coherence monitoring report."""

import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from photon_q.core.qoei import QOEIComputer
from photon_q.core.psi_dynamics_tracker import PsiDynamicsTracker


def generate_daily_report():
    """Generate daily report from optical analysis."""
    
    date = datetime.now()
    report_date = date.strftime("%Y%m%d")
    
    results_dir = "results"
    os.makedirs(results_dir, exist_ok=True)
    
    channels = [
        ("PHOTONIC-CRYSTAL-01", "photonic_crystal"),
        ("FREE-SPACE-01", "free_space_channel"),
        ("FIBER-BRAGG-01", "fiber_bragg"),
        ("KERR-WG-01", "kerr_waveguide"),
        ("ATMOSPHERIC-01", "atmospheric_link"),
        ("SILICON-01", "silicon_photonics"),
    ]
    
    results = []
    qoei_computer = QOEIComputer()
    
    for channel_id, regime in channels:
        # Simulate analysis
        import random
        qoei = random.uniform(0.85, 0.98)
        result = qoei_computer.compute(input_state=1.0, output_state=qoei)
        
        results.append({
            "channel": channel_id,
            "regime": regime,
            "qoei": qoei,
            "status": result.status,
            "recommendation": result.recommendation,
        })
    
    # Generate report
    report_lines = []
    report_lines.append("=" * 70)
    report_lines.append("PHOTON-Q Daily Coherence Report")
    report_lines.append(f"Date: {date.strftime('%Y-%m-%d')}")
    report_lines.append(f"Time: {date.strftime('%H:%M:%S')}")
    report_lines.append(f"Version: 1.0.0 | DOI: 10.5281/zenodo.19729926")
    report_lines.append("=" * 70)
    report_lines.append("")
    
    # Summary
    avg_qoei = sum(r['qoei'] for r in results) / len(results)
    report_lines.append("EXECUTIVE SUMMARY")
    report_lines.append("-" * 50)
    report_lines.append(f"Channels Analyzed:     {len(results)}")
    report_lines.append(f"Average QOEI:          {avg_qoei:.4f}")
    report_lines.append("")
    
    # Channel details
    report_lines.append("CHANNEL DETAILS")
    report_lines.append("=" * 70)
    
    for r in results:
        icon = "🟢" if r['status'] == "EXCELLENT" else "🟡" if r['status'] == "GOOD" else "🟠" if r['status'] == "MODERATE" else "🔴"
        report_lines.append("")
        report_lines.append(f"{icon} {r['channel']} ({r['regime']})")
        report_lines.append(f"  QOEI: {r['qoei']:.4f}  [{r['status']}]")
        report_lines.append(f"  Recommendation: {r['recommendation']}")
    
    report_lines.append("")
    report_lines.append("=" * 70)
    report_lines.append("End of Report")
    report_lines.append("=" * 70)
    
    # Save report
    report_path = os.path.join(results_dir, f"daily_report_{report_date}.txt")
    with open(report_path, 'w') as f:
        f.write("\n".join(report_lines))
    
    print(f"✅ Daily report saved to: {report_path}")
    
    # Save JSON
    json_path = os.path.join(results_dir, f"daily_report_{report_date}.json")
    with open(json_path, 'w') as f:
        json.dump({
            "date": date.isoformat(),
            "channels": results,
            "summary": {"total": len(results), "average_qoei": avg_qoei}
        }, f, indent=2)
    
    print(f"✅ JSON data saved to: {json_path}")
    
    return report_path


if __name__ == "__main__":
    report_path = generate_daily_report()
    print(f"\n📁 Report location: {report_path}")
