Security Policy for PHOTON-Q

Supported Versions

Version Supported Notes
1.0.x ✅ Yes Current stable
< 1.0 ❌ No Pre-release only

Reporting a Vulnerability

Please report via email to: gitdeeper@gmail.com

You should receive a response within 48 hours.

Security Considerations for PHOTON-Q

QOEI Framework

· All 3 constructs bounded to physical constraints
· Normalization prevents numerical overflow
· Regime-specific reference distributions

AI Architecture

· PINN penalty layer enforces physical consistency
· Helmholtz compliance enforcement
· Energy conservation constraint
· Density matrix positivity enforcement

Data Handling

· 6-regime dataset with validation splits
· Cross-validation across independent sensor stations
· No human subjects data

Known Vulnerabilities (None)

No security vulnerabilities are currently known.

Responsible Disclosure

1. Reporter notifies us privately
2. We confirm and develop fix (7-14 days)
3. Fix released with patch version
4. Public disclosure after 30 days

---

Last updated: April 2026
