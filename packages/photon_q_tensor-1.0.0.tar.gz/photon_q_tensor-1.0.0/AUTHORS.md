# 👥 Authors

## Project: PHOTON-Q
## Neural Wavefront Intelligence for Phase-Coherent Quantum-Optical Systems

---

### Lead Author

**Samir Baladi**
- Interdisciplinary AI Researcher — Neural Optics & Quantum-Optical Intelligence Division
- Ronin Institute / Rite of Renaissance
- 📧 gitdeeper@gmail.com
- 🆔 ORCID: 0009-0003-8903-0029

**Contributions:**
- PHOTON-Q framework design
- Quantum-Optical Efficiency Index (QOEI) formulation
- Neural Helmholtz Predictor (NHP) architecture
- Phase Coherence Tensor (PCT) formulation
- Phase-Locking Algorithm (PLA) with MPC
- Physics-Informed Neural Network (PINN) with Helmholtz constraint
- Neural ODE for quantum state evolution
- Experimental validation across 6 optical regimes
- Research documentation and paper preparation

---

### Contributors

*Open for contributions from researchers*

| Name | Affiliation | Contribution | Dates |
|------|-------------|--------------|-------|
| *Available* | *Available* | *Available* | *Available* |

---

### Acknowledgments

- Photonic crystal cavity fabrication team (IMEC)
- Free-space QKD link operators (Berlin Quantum)
- Fiber Bragg grating quantum memory group (Max Planck)
- Silicon photonics foundry (TowerJazz)
- Atmospheric turbulence measurement network (DLR)
- Cryogenic optics lab (NIST Boulder)

---

**📅 Last updated:** April 2026
**📜 License:** MIT License
