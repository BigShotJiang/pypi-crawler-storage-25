#!/usr/bin/env python
"""Quick start example for PHOTON-Q."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from photon_q.core.qoei import QOEIComputer
from photon_q.core.nhp import NeuralHelmholtzPredictor
from photon_q.core.pct import PhaseCoherenceTensor
from photon_q.core.psi_dynamics_tracker import PsiDynamicsTracker


def main():
    print("=" * 60)
    print("PHOTON-Q Quick Start Example")
    print("=" * 60)

    # Initialize components
    qoei = QOEIComputer()
    nhp = NeuralHelmholtzPredictor()
    pct = PhaseCoherenceTensor(mode_dim=8)
    tracker = PsiDynamicsTracker(mode_dim=8)

    print("\n📊 QOEI Computation:")
    result = qoei.compute()
    print(f"  η_Q = {result.value:.4f} [{result.status}]")
    print(f"  Recommendation: {result.recommendation}")

    print("\n🔬 NHP Wave Propagation:")
    nhp_result = nhp.compute(e_field=1.0, gradient=1e3, position=[0,0,0], intensity=1e12)
    print(f"  Residual: {nhp_result.residual:.4e} [{nhp_result.status}]")

    print("\n🌀 Phase Coherence Tensor:")
    import math
    mode_amplitudes = [complex(1.0/math.sqrt(8), 0.0) for _ in range(8)]
    pct_result = pct.compute(mode_amplitudes, decoherence_rate=1e6, dt=1e-9)
    print(f"  Coherence Trace: {pct_result.coherence_trace:.4f} [{pct_result.status}]")

    print("\n⚡ State Evolution:")
    env_obs = {'temperature_K': 293.15, 'vibration_psd': 1e-15, 'em_background': 1e-12}
    state = tracker.step(dt=1e-9, env_obs=env_obs)
    print(f"  η_Q: {state.qoei:.4f} | Tr(C): {state.coherence_trace:.4f}")
    print(f"  Decoherence Rate: {state.decoherence_rate:.4e} s⁻¹")
    print(f"  Status: {state.status}")

    print("\n✅ PHOTON-Q is ready for use!")
    print("📚 For more examples, see the notebooks/ directory")
    print("🌐 Dashboard: https://photon-q.netlify.app")


if __name__ == "__main__":
    main()
