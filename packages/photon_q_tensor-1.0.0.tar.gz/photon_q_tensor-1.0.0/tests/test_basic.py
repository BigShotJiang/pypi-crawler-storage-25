"""Basic tests for PHOTON-Q."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from photon_q.core.qoei import QOEIComputer
from photon_q.core.nhp import NeuralHelmholtzPredictor
from photon_q.core.pct import PhaseCoherenceTensor


def test_qoei():
    computer = QOEIComputer()
    result = computer.compute()
    assert 0 <= result.value <= 1
    assert result.status in ["EXCELLENT", "GOOD", "MODERATE", "CRITICAL", "COLLAPSE"]
    print(f"✓ QOEI test passed: {result.value:.4f} [{result.status}]")


def test_nhp():
    nhp = NeuralHelmholtzPredictor()
    result = nhp.compute(e_field=1.0, gradient=1e3, position=[0,0,0])
    assert result.residual >= 0
    assert result.status in ["EXCELLENT", "GOOD", "MODERATE", "CRITICAL", "COLLAPSE"]
    print(f"✓ NHP test passed: residual = {result.residual:.4e}")


def test_pct():
    pct = PhaseCoherenceTensor(mode_dim=8)
    import math
    mode_amplitudes = [complex(1.0/math.sqrt(8), 0.0) for _ in range(8)]
    result = pct.compute(mode_amplitudes, decoherence_rate=1e6, dt=1e-9)
    assert 0 <= result.coherence_trace <= 1
    print(f"✓ PCT test passed: Tr(C) = {result.coherence_trace:.4f}")


if __name__ == "__main__":
    test_qoei()
    test_nhp()
    test_pct()
    print("\n✅ All basic tests passed!")
