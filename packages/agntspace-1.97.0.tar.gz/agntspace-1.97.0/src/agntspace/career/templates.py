"""Default fact-file templates shipped to fresh vaults.

The user authors these files; the agent reads them for CV generation,
cover-letter writing, and JD coverage analysis.

Placeholder convention:
    Every example line that exists ONLY to teach shape starts with
    ``[e.g., "..."]``. This matches the ProfilePage placeholder detector
    convention so the FactsPage can classify which sections the user has
    genuinely filled in vs. which are still untouched.

Templates are intentionally short — they show ONE worked example per
category, then leave room for the user to extend. Heavier templates
discourage editing.
"""
# arch:deterministic — closed enum of fact categories; the engine assumes this set
# is fixed. Adding a 7th category requires touching service.py, templates.py, UI,
# tests, AND the i18n keys — a deliberate cross-cutting change, never silent.
FACT_CATEGORIES: tuple[str, ...] = (
    "work-history",
    "education",
    "skills",
    "projects",
    "achievements",
    "recommendations",
)


_WORK_HISTORY = """\
---
last_updated: ""
positions: []
---
# Work history

Chronological list, most recent first. The agent reads BOTH the YAML
``positions`` list (structured) and the prose body (context) when tailoring
a CV — keep them in sync.

[e.g., "## Acme Corp — Senior Engineer (Jan 2023 – Apr 2025)"]
[e.g., "Stockholm, hybrid. Led the platform team rebuilding the billing pipeline."]
[e.g., ""]
[e.g., "### Quantified outcomes"]
[e.g., "- Cut ingestion latency from 45s p99 to 800ms while doubling throughput."]
[e.g., "- Retained $1.2M ARR from migrations that previously caused churn."]
[e.g., "- Mentored 4 engineers; 2 promoted within 18 months."]
[e.g., ""]
[e.g., "### Stack"]
[e.g., "Python, Rust, PostgreSQL, Kubernetes, GraphQL."]
"""


_EDUCATION = """\
---
last_updated: ""
degrees: []
---
# Education

Degrees, certifications, and professionally-relevant courses. Skip
secondary school unless it's the highest level you've reached.

[e.g., "## KTH Royal Institute of Technology — MSc Computer Science (2018 – 2020)"]
[e.g., "Stockholm. Thesis on distributed systems consensus (defended Jun 2020)."]
[e.g., ""]
[e.g., "## AWS Certified Solutions Architect — Professional (2022)"]
[e.g., "Renewed 2025. Credential ID: ABC-12345."]
"""


_SKILLS = """\
---
last_updated: ""
---
# Skills

Group by category. The agent matches JD requirements against this file —
honesty matters more than breadth. Mark proficiency only when you can
back it up under interview scrutiny.

[e.g., "## Languages"]
[e.g., "- Python (expert, 8+ years professional)"]
[e.g., "- Rust (intermediate, 2 years on production billing service)"]
[e.g., "- Go (basic, occasional scripts)"]
[e.g., ""]
[e.g., "## Infrastructure & Platforms"]
[e.g., "- Kubernetes (advanced, ran production clusters at Acme)"]
[e.g., "- AWS (intermediate, EKS + RDS + S3 daily)"]
[e.g., ""]
[e.g., "## Domain"]
[e.g., "- Payment systems, billing reconciliation, idempotency design"]
[e.g., "- Team mentorship, hiring, technical interviewing"]
"""


_PROJECTS = """\
---
last_updated: ""
---
# Notable projects

Projects that demonstrate range or impact. Include open-source, internal,
or side-projects. If a project exists in your AgntSpace ``agntspace-projects/``
tree, you can [[wikilink]] to it — the agent will follow the link when
generating CVs.

[e.g., "## Acme billing rebuild (2024)"]
[e.g., "Lead engineer. Replaced 12-year-old monolith with event-sourced microservices."]
[e.g., "Outcome: 56× latency reduction, $1.2M ARR retention."]
[e.g., "Stack: Python, Rust, PostgreSQL, Kafka."]
[e.g., ""]
[e.g., "## Open-source: pyfoobar (2022 – present)"]
[e.g., "Maintainer. 12k stars, 80+ contributors."]
[e.g., "Tools: github.com/me/pyfoobar"]
"""


_ACHIEVEMENTS = """\
---
last_updated: ""
---
# Quantified achievements

Specific wins with numbers attached. The agent uses these as concrete
evidence in CV bullets and cover letters. Each entry should have:
WHAT you did, by HOW MUCH, with what MEASURABLE OUTCOME.

[e.g., "## 2024 — Cut billing pipeline latency 56× (45s p99 → 800ms)"]
[e.g., "Refactored event ingestion from synchronous to streaming. Cited in"]
[e.g., "internal engineering newsletter; presented at quarterly all-hands."]
[e.g., ""]
[e.g., "## 2023 — Saved $1.2M ARR through churn-blocking migrations"]
[e.g., "Identified 3 customer-segment migrations that historically caused"]
[e.g., "12% churn. Designed zero-downtime cutover; retention improved to 97%."]
[e.g., ""]
[e.g., "## 2022 — Open-source pyfoobar reached 10k GitHub stars"]
[e.g., "From 200 stars at start of year. Featured in Python Weekly newsletter."]
"""


_RECOMMENDATIONS = """\
---
last_updated: ""
---
# Recommendations & references

Testimonials and reference contacts. The agent does NOT quote these in CVs
without your explicit approval — they're context for cover letters and
interview prep. Mark references as ``confidential: true`` to prevent the
agent from naming them in any generated output.

[e.g., "## Jane Doe — VP Engineering, Acme Corp (2023 – 2025 manager)"]
[e.g., "Email: jane@acme.example (confirmed willing to be contacted)"]
[e.g., "Relationship: direct manager for 22 months."]
[e.g., "Strengths she'd highlight: systems design, mentorship, owning ambiguous problems."]
[e.g., ""]
[e.g., "## LinkedIn recommendation from Sara — engineer at Acme"]
[e.g., "\\"One of the best engineers I've worked with. Asked the questions"]
[e.g., "nobody else thought to ask.\\" (2024-Q3, viewable on LinkedIn)"]
"""


DEFAULT_FACT_TEMPLATES: dict[str, str] = {
    "work-history": _WORK_HISTORY,
    "education": _EDUCATION,
    "skills": _SKILLS,
    "projects": _PROJECTS,
    "achievements": _ACHIEVEMENTS,
    "recommendations": _RECOMMENDATIONS,
}

# Sanity check: every category in the closed enum has a template, no orphans.
assert set(DEFAULT_FACT_TEMPLATES.keys()) == set(FACT_CATEGORIES), (
    "DEFAULT_FACT_TEMPLATES keys must match FACT_CATEGORIES exactly. "
    f"Drift detected: templates={set(DEFAULT_FACT_TEMPLATES.keys())} vs "
    f"categories={set(FACT_CATEGORIES)}"
)


# ────────────────────────────────────────────────────────────────────
# Phase 2 — Listings (job announcements)
# ────────────────────────────────────────────────────────────────────

# arch:deterministic — closed pipeline-status enum locked by Phase 1 user
# confirmation (2026-05-19 session). Adding an 8th status requires touching
# service.py + UI + tests + i18n + this constant in one PR — a deliberate
# cross-cutting change. NEVER add a status silently; status meanings drive
# Dashboard counters + pipeline visualisation + Phase 4 follow-up detectors.
LISTING_STATUSES: tuple[str, ...] = (
    "saved",          # user noticed the role; no action yet
    "applied",        # CV/cover sent
    "interviewing",   # any interview stage (phone screen → onsite → offer call)
    "offer",          # offer in hand, deciding
    "rejected",       # rejection received, OR self-classified as ghosted past 30 days
    "declined",       # offer received, user declined
    "withdrawn",      # user pulled application before any decision
)


def is_valid_listing_status(status: object) -> bool:
    """Pure predicate used by service + route layers."""
    return isinstance(status, str) and status in LISTING_STATUSES


# Listing markdown template. Frontmatter carries STRUCTURED data; body
# preserves the JD verbatim from the source (so the user can re-read
# requirements without round-tripping through the original page).
LISTING_TEMPLATE = """\
---
slug: "{slug}"
company: "{company}"
role: "{role}"
url: "{url}"
status: "{status}"
source: "{source}"
location: "{location}"
salary_range: "{salary_range}"
deadline: "{deadline}"
tech_stack: {tech_stack_yaml}
recruiter: "{recruiter}"
posted_at: "{posted_at}"
created_at: "{created_at}"
status_history:
  - {{status: "{status}", at: "{created_at}", note: "Initial entry"}}
---

## Job Description

{jd_body}
"""


# Canonical frontmatter field set (closed). PATCH /api/career/listings/{slug}
# rejects keys outside this set — guards against route-injection of arbitrary
# metadata. Status is handled by the dedicated PATCH /status route.
LISTING_FRONTMATTER_FIELDS: frozenset[str] = frozenset({
    "company",
    "role",
    "url",
    "source",
    "location",
    "salary_range",
    "deadline",
    "tech_stack",
    "recruiter",
    "posted_at",
    # Async LLM enrichment markers. Set by the work-queue handler
    # ``career_enrich_listing`` after the fast-save route creates the
    # initial listing. Possible values:
    #   - pending   (job enqueued, LLM hasn't run yet)
    #   - complete  (LLM extracted; company/role/location/tech_stack updated)
    #   - failed    (LLM call timed out OR returned unparseable output)
    #   - skipped   (raw_jd_text empty, no extraction possible)
    "enrichment_status",
    "enrichment_completed_at",
    "enrichment_error",
    # status + status_history are mutated only through update_listing_status.
    # slug + created_at are immutable.
})


# ────────────────────────────────────────────────────────────────────
# Phase 3 — Applications (your response to a listing)
# ────────────────────────────────────────────────────────────────────
#
# Architectural decision: an application is a FOLDER, not just a status
# flip on the listing. Folder layout (created on demand):
#
#   agntspace-career/applications/{slug}/
#     metadata.md           — frontmatter + body (this template)
#     jd_analysis.md        — generated by analyze_gaps()
#     cv.docx               — generated by Phase 3 Slice B
#     cover_letter.docx     — generated by Phase 3 Slice B
#
# Why a folder, not a single .md:
#   - Multiple deliverables (CV + cover letter + analysis) belong
#     together for the same role.
#   - Re-runs of the JD analyzer overwrite jd_analysis.md cleanly.
#   - User can grep ``applications/{slug}/`` and see everything they
#     submitted for one role.
#   - Phase 3 Slice B's CV generation writes a .docx that lives
#     alongside the metadata.
#
# Why a SEPARATE entity from the listing (not just a status):
#   - Multiple applications to the same role (different versions /
#     retries) make sense. Each gets its own folder + numeric suffix.
#   - Listings describe the JD; applications describe the user's response.
#   - Listing status_history tracks JD pipeline (saved → applied →
#     interviewing → offer); application status_history tracks the
#     PREPARATION pipeline (draft → preparing → submitted → withdrawn).
#     Conflating them would lose the distinction between "have I sent
#     CV?" and "what did they say back?".

# arch:deterministic — closed application-status enum. Adding a 5th
# status requires touching service.py + UI + tests + i18n + this
# constant in one PR. Status meanings drive Dashboard counters + Phase 4
# reminders + the CV-builder's "ready to generate?" gate.
APPLICATION_STATUSES: tuple[str, ...] = (
    "draft",        # application created, nothing generated yet
    "preparing",    # CV / cover letter / gap analysis being generated
    "submitted",    # user clicked "submit" (or marked as sent manually)
    "withdrawn",    # user pulled the application before submission
)


def is_valid_application_status(status: object) -> bool:
    """Pure predicate used by service + route layers."""
    return isinstance(status, str) and status in APPLICATION_STATUSES


# Application metadata template. Frontmatter carries the linkage to the
# listing + audit trail; body explains the folder layout. The actual
# deliverables (cv.docx, cover_letter.docx, jd_analysis.md) live as
# sibling files in the same folder, created on demand.
APPLICATION_METADATA_TEMPLATE = """\
---
slug: "{slug}"
listing_slug: "{listing_slug}"
status: "{status}"
created_at: "{created_at}"
status_history:
  - {{status: "{status}", at: "{created_at}", note: "Initial entry"}}
generated_assets: []
---

# Application: {listing_slug}

Generated assets (CV, cover letter, JD analysis) live alongside this
file in the same folder. See ``cv.docx``, ``cover_letter.docx``, and
``jd_analysis.md`` once Phase 3 Slice B ships.
"""


# Canonical frontmatter field set (closed). PATCH /api/career/applications/{slug}
# rejects keys outside this set. Status mutations go through the dedicated
# PATCH /status route; slug + listing_slug + created_at + status_history
# are immutable.
APPLICATION_FRONTMATTER_FIELDS: frozenset[str] = frozenset({
    "generated_assets",  # list of relative paths: ["cv.docx", "cover_letter.docx", ...]
    # Deliberately NOT including listing_slug, status, slug, created_at,
    # status_history — those are not user-patchable.
})


__all__ = [
    "FACT_CATEGORIES",
    "DEFAULT_FACT_TEMPLATES",
    "LISTING_STATUSES",
    "LISTING_TEMPLATE",
    "LISTING_FRONTMATTER_FIELDS",
    "is_valid_listing_status",
    "APPLICATION_STATUSES",
    "APPLICATION_METADATA_TEMPLATE",
    "APPLICATION_FRONTMATTER_FIELDS",
    "is_valid_application_status",
]
