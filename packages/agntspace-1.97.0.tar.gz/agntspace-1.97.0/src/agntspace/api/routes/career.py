"""Career API — Phase 1: facts CRUD.

Surfaces the ``CareerService`` over HTTP. The UI's FactsPage drives every
mutating call through ``PUT /api/career/facts/{category}``; reads come
through ``GET /api/career/facts`` (list) and ``GET /api/career/facts/{category}``
(full body).

Phase 2+ will add listings + applications + CV generation routes to this
same router. Phase 1 deliberately keeps the surface small.

Activity middleware classifications live in
[api/activity_middleware.py](../activity_middleware.py). Per Rule 19 the
mutating PUT route ships with a workflow test from day one
(``tests/e2e/workflows/test_career_facts_workflow.py``).
"""
from __future__ import annotations

import logging
import re
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

router = APIRouter(prefix="/career", tags=["career"])


def _service(request: Request):
    svc = getattr(request.app.state, "career", None)
    if svc is None:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "career_service_not_wired",
                "message": (
                    "CareerService is not attached to the running app. "
                    "This is a server-config issue, not a user error."
                ),
            },
        )
    return svc


# ────────────────────────────────────────────────────────────────────
# Request models
# ────────────────────────────────────────────────────────────────────
class FactUpdateRequest(BaseModel):
    """Body for PUT /api/career/facts/{category}.

    The full document (frontmatter + body) is sent as ``content``.
    Server auto-stamps ``last_updated`` before persisting.
    """
    content: str = Field(..., description="Full markdown document (frontmatter + body).")


# ────────────────────────────────────────────────────────────────────
# Read routes
# ────────────────────────────────────────────────────────────────────
@router.get("/facts")
async def list_facts(request: Request) -> dict[str, Any]:
    """Return per-category summary for all 6 fact categories.

    Always returns 6 entries in canonical order regardless of scaffolding
    state — categories with no file on disk return ``exists=False`` so the
    UI can render a consistent "needs setup" affordance.
    """
    svc = _service(request)
    items = svc.list_facts()
    return {
        # Rule 20: even though this list is bounded-by-domain (6 entries
        # always), shipping a structured shape keeps future expansion
        # (e.g. multi-profile) clean.
        "items": [
            {
                "category": fm.category,
                "path": fm.path,
                "exists": fm.exists,
                "size_bytes": fm.size_bytes,
                "last_updated": fm.last_updated,
                "is_empty": fm.is_empty,
            }
            for fm in items
        ],
        "total": len(items),
        # arch:bounded-by-domain — FACT_CATEGORIES is a closed enum of 6;
        # the list is exhaustive by construction, never paginated.
        "has_more": False,
    }


@router.get("/facts/{category}")
async def get_fact(category: str, request: Request) -> dict[str, Any]:
    """Return the full body + parsed frontmatter for one category.

    404 when:
      - ``category`` is not a valid FACT_CATEGORIES slug (path injection
        guard via the service's KeyError).
      - ``category`` is valid but no file exists yet (scaffolding never
        ran for it, or the user deleted it from the file system).
    """
    svc = _service(request)
    try:
        return svc.get_fact(category)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "unknown_career_fact_category",
                "message": str(exc),
            },
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "career_fact_not_scaffolded",
                "category": category,
                "message": (
                    f"Category {category!r} is valid but no file exists at "
                    f"career/facts/{category}.md. Re-run vault init or "
                    f"recreate the file via PUT /api/career/facts/{category}."
                ),
            },
        ) from exc


# ────────────────────────────────────────────────────────────────────
# Write routes
# ────────────────────────────────────────────────────────────────────
@router.put("/facts/{category}")
async def update_fact(category: str, payload: FactUpdateRequest, request: Request) -> dict[str, Any]:
    """Replace a fact file's content.

    Returns:
        Updated FactMeta dict (category, path, exists, size_bytes,
        last_updated, is_empty) so the UI can show the new timestamp +
        size without a second round-trip.

    Errors:
        400: ``content`` is empty / whitespace-only (the FactsPage editor
             guards against this client-side, but the server enforces too).
        404: invalid category slug.
    """
    svc = _service(request)
    try:
        fm = svc.update_fact(category, payload.content)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "unknown_career_fact_category",
                "message": str(exc),
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "invalid_career_fact_content",
                "message": str(exc),
            },
        ) from exc

    return {
        "category": fm.category,
        "path": fm.path,
        "exists": fm.exists,
        "size_bytes": fm.size_bytes,
        "last_updated": fm.last_updated,
        "is_empty": fm.is_empty,
    }


# ════════════════════════════════════════════════════════════════════
# Phase 2 — Listings (job announcements) routes
# ════════════════════════════════════════════════════════════════════


class ListingCreateRequest(BaseModel):
    """Body for POST /api/career/listings.

    company + role are required. Everything else is optional — paste-JD-text
    workflow fills `raw_jd_text`; URL-paste flow fills `url` + uses the
    extracted page title for `role`. Phase 2.5 will add URL fetch + parse;
    for now the user fills fields manually.
    """
    company: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    url: str = ""
    raw_jd_text: str = ""
    status: str = "saved"
    source: str = "manual"  # manual | linkedin | indeed | direct | referral | screenshot
    location: str = ""
    salary_range: str = ""
    deadline: str = ""
    tech_stack: list[str] | str | None = None
    recruiter: str = ""
    posted_at: str = ""


class ListingPatchRequest(BaseModel):
    """Body for PATCH /api/career/listings/{slug}.

    Subset of LISTING_FRONTMATTER_FIELDS — status MUST go through the
    dedicated /status route so the timeline log stays append-only.
    All fields optional; the route patches whatever is present.
    """
    company: str | None = None
    role: str | None = None
    url: str | None = None
    source: str | None = None
    location: str | None = None
    salary_range: str | None = None
    deadline: str | None = None
    tech_stack: list[str] | str | None = None
    recruiter: str | None = None
    posted_at: str | None = None


class ListingStatusRequest(BaseModel):
    """Body for PATCH /api/career/listings/{slug}/status."""
    new_status: str = Field(..., min_length=1)
    note: str = ""


# ── Read routes ────────────────────────────────────────────────────


@router.get("/listings")
async def list_listings(
    request: Request,
    status: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    """List job listings. Rule 20 shape: {items, total, has_more}.

    Query params:
        status: optional filter (saved | applied | interviewing | offer |
            rejected | declined | withdrawn). 400 on unknown status.
        limit: max items per page. Clamped server-side to [1, 500].
        offset: pagination offset.
    """
    svc = _service(request)
    try:
        return svc.list_listings(status=status, limit=limit, offset=offset)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "unknown_listing_status", "message": str(exc)},
        ) from exc


@router.get("/listings/{slug}")
async def get_listing(slug: str, request: Request) -> dict[str, Any]:
    """Return full body + parsed frontmatter for one listing.

    404 on unknown slug shape (path-injection guard) OR on missing file.
    """
    svc = _service(request)
    try:
        return svc.get_listing(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "invalid_listing_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


# ── Write routes ───────────────────────────────────────────────────


@router.post("/listings")
async def create_listing(
    payload: ListingCreateRequest, request: Request
) -> dict[str, Any]:
    """Create a new job listing. Returns slug + path for UI navigation.

    400 on invalid status / missing company / missing role.
    """
    svc = _service(request)
    try:
        return svc.create_listing(
            company=payload.company,
            role=payload.role,
            url=payload.url,
            raw_jd_text=payload.raw_jd_text,
            status=payload.status,
            source=payload.source,
            location=payload.location,
            salary_range=payload.salary_range,
            deadline=payload.deadline,
            tech_stack=payload.tech_stack,
            recruiter=payload.recruiter,
            posted_at=payload.posted_at,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_input", "message": str(exc)},
        ) from exc


@router.patch("/listings/{slug}/status")
async def update_listing_status(
    slug: str, payload: ListingStatusRequest, request: Request
) -> dict[str, Any]:
    """Move a listing through the pipeline.

    Body: ``{new_status, note?}``. Appends to the status_history timeline
    so every transition is preserved for audit. Same-status transitions
    are no-ops with ``changed: false`` so accidental re-clicks don't
    pollute the timeline.

    400 on unknown status. 404 on unknown slug.
    """
    svc = _service(request)
    try:
        return svc.update_listing_status(slug, payload.new_status, payload.note)
    except KeyError as exc:
        # Two cases collapse here: invalid slug shape OR invalid status.
        # The error message distinguishes them; route returns 400 either
        # way since both are user-supplied input violations.
        msg = str(exc)
        if "slug" in msg.lower():
            raise HTTPException(
                status_code=404,
                detail={"error": "invalid_listing_slug", "message": msg},
            ) from exc
        raise HTTPException(
            status_code=400,
            detail={"error": "unknown_listing_status", "message": msg},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


@router.patch("/listings/{slug}")
async def update_listing(
    slug: str, payload: ListingPatchRequest, request: Request
) -> dict[str, Any]:
    """Patch listing frontmatter fields. Status uses /status route.

    Only fields present in the body (non-None) are patched — undefined
    fields are preserved. 400 on unknown field keys (shouldn't reach the
    service since Pydantic validates the body shape, but the service has
    its own defence). 404 on unknown slug.
    """
    svc = _service(request)
    # Filter to only fields the user set — Pydantic returns None for
    # absent fields, but we don't want to overwrite frontmatter with None.
    fields = {
        k: v
        for k, v in payload.model_dump(exclude_unset=True).items()
        if v is not None
    }
    if not fields:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "no_fields_to_patch",
                "message": "PATCH body must include at least one non-null field.",
            },
        )
    try:
        return svc.update_listing(slug, **fields)
    except KeyError as exc:
        msg = str(exc)
        if "slug" in msg.lower():
            raise HTTPException(
                status_code=404,
                detail={"error": "invalid_listing_slug", "message": msg},
            ) from exc
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_field", "message": msg},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


@router.delete("/listings/{slug}")
async def delete_listing(slug: str, request: Request) -> dict[str, Any]:
    """Idempotent delete. Returns ``{deleted, slug}`` where ``deleted``
    is False if the file was already gone (Rule 18 phantom-cleanup shape)."""
    svc = _service(request)
    try:
        return svc.delete_listing(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "invalid_listing_slug", "message": str(exc)},
        ) from exc


# ── URL → listing import (Phase 2.5) ─────────────────────────────────────


class ListingFromUrlRequest(BaseModel):
    """Body for ``POST /api/career/listings/from-url``.

    Two modes:

    1. ``raw_jd_text`` empty: server-side anonymous fetch via ``extract_job_from_url``.
       Works for public job posts but fails on auth-walled / iframe-CSR boards
       (LinkedIn, Workday, Matrareach-style EU boards like cv.unikresurs.se).
    2. ``raw_jd_text`` non-empty: skip the fetch, hand the text straight to the
       LLM extractor. This is the path the Chrome extension uses — it captures
       the JD body from the user's authenticated DOM and ships it as plain text.

    ``force_draft=true`` saves a partial draft listing using URL hostname as a
    company fallback when the LLM can't extract enough fields. Lets the user
    fill in the blanks manually instead of refusing entirely.
    """

    url: str = Field(..., min_length=1, description="The JD URL to fetch.")
    status: str = Field("saved", description="Initial pipeline status.")
    raw_jd_text: str = Field(
        "", description="JD body captured client-side; skips server fetch when set."
    )
    force_draft: bool = Field(
        False,
        description="Save a partial draft even when company/role extraction is thin.",
    )


@router.post("/listings/from-url")
async def create_listing_from_url(
    payload: ListingFromUrlRequest, request: Request,
) -> dict[str, Any]:
    """Fetch ``payload.url`` + LLM-extract a structured JD + create a listing.

    Phase 2.5 — the user-facing surface for the "I have a JD URL, save it"
    workflow. Backend chain:

    1. ``fetch_url_text`` — URL safety gate + 30s timeout + 4 MB cap +
       content-type check. Failures return empty text; route raises 502.
    2. ``extract_job_via_llm`` — capable-tier LLM extraction into a
       structured ``ExtractedJob``. JSON-output, anti-fabrication rules
       baked into the prompt.
    3. ``CareerService.create_listing`` — writes the listing markdown +
       seeds status_history.

    Returns the same shape as ``POST /api/career/listings`` so the UI
    can navigate directly to the created listing.

    HTTP codes:
    - 200: listing created. Body includes ``slug``, ``path``, ``status``,
      ``created_at``, ``extracted`` (the structured fields populated by
      the LLM — UI can render a preview of what was extracted).
    - 422 (Pydantic): ``url`` missing or empty.
    - 502: URL safety reject / unreachable / oversized / wrong content
      type / empty text after HTML strip.
    - 503: extraction insufficient (company OR role missing from LLM
      output). Returns a structured detail so the UI can offer the user
      a chance to paste the JD body manually instead.
    - 503: career service / agent / skill loader not wired.
    """
    svc = _service(request)
    agent = getattr(request.app.state, "agent", None)
    if agent is None:
        raise HTTPException(
            status_code=503,
            detail={"error": "agent_unavailable",
                    "message": "Agent service is not wired."},
        )
    skill_loader = getattr(request.app.state, "skills", None)

    try:
        from agntspace.career.jd_extract import (
            extract_job_from_url,
            extract_job_via_llm,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail={"error": "jd_extract_unavailable",
                    "message": f"JD extractor unavailable: {exc}"},
        ) from exc

    url = payload.url.strip()
    if not url:
        raise HTTPException(
            status_code=422,
            detail={"error": "empty_url", "message": "url is required"},
        )

    # ── Pick extraction path ────────────────────────────────────────────
    # When the client (Chrome extension) supplied raw_jd_text from the
    # user's authenticated DOM, skip the server-side fetch entirely —
    # most job boards block anonymous fetches anyway, and the user's
    # browser already has the rendered JD body.
    raw_jd_text = (payload.raw_jd_text or "").strip()
    if raw_jd_text:
        try:
            job = await extract_job_via_llm(
                raw_jd_text,
                source_url=url,
                agent=agent,
                skill_loader=skill_loader,
            )
        except Exception as exc:
            log.exception(
                "create_listing_from_url: LLM extraction crashed (raw_jd_text=%d chars)",
                len(raw_jd_text),
            )
            raise HTTPException(
                status_code=502,
                detail={"error": "extraction_crashed", "message": str(exc)},
            ) from exc
    else:
        try:
            job = await extract_job_from_url(
                url, agent=agent, skill_loader=skill_loader,
            )
        except Exception as exc:
            log.exception("create_listing_from_url: extraction crashed for %s", url)
            raise HTTPException(
                status_code=502,
                detail={"error": "extraction_crashed", "message": str(exc)},
            ) from exc

    if not job.has_minimum_fields:
        # Pipeline ran cleanly but produced too little to act on. Two paths:
        # (a) force_draft=true → save a partial listing using URL hostname
        #     as a company fallback so the user can fill the blanks manually
        #     in /career/listings. Strongly preferred for the "I'm looking
        #     at the page, just save SOMETHING" UX.
        # (b) force_draft=false (legacy) → 502 with structured detail so
        #     the UI can offer the user a chance to retry / paste manually.
        if payload.force_draft:
            from urllib.parse import urlparse

            hostname = ""
            try:
                raw_host = (urlparse(url).hostname or "")
                # Strip the literal "www." prefix only — NOT .lstrip("www.")
                # which would strip each of {w, .} individually and mangle
                # "wwww.test.com" or any host starting with one of those chars.
                hostname = raw_host[4:] if raw_host.startswith("www.") else raw_host
            except Exception:
                hostname = ""
            fallback_company = job.company or hostname or "Unknown company"
            fallback_role = job.role or "(role TBD)"
            kwargs = job.to_listing_kwargs()
            kwargs["company"] = fallback_company
            kwargs["role"] = fallback_role
            if payload.status and isinstance(payload.status, str):
                kwargs["status"] = payload.status.strip() or "saved"
            try:
                result = svc.create_listing(**kwargs)
            except ValueError as exc:
                raise HTTPException(
                    status_code=400,
                    detail={"error": "invalid_listing_input", "message": str(exc)},
                ) from exc
            if isinstance(result, dict):
                # Surface the values ACTUALLY used (post-fallback) at the
                # top level so the extension's success banner reads
                # "Saved {company} — {role} as draft" without digging into
                # `extracted` (which holds the LLM's raw output, possibly
                # empty on the company/role fields).
                result["company"] = fallback_company
                result["role"] = fallback_role
                result["extracted"] = {
                    "company": job.company,
                    "role": job.role,
                    "location": job.location,
                    "salary_range": job.salary_range,
                    "deadline": job.deadline,
                    "tech_stack": list(job.tech_stack),
                    "recruiter": job.recruiter,
                    "posted_at": job.posted_at,
                    "source_url": job.source_url,
                    "body_chars": len(job.body),
                }
                result["draft_reason"] = "extraction_insufficient_force_draft"
                result["draft_fallback"] = {
                    "company_fallback": not job.company,
                    "role_fallback": not job.role,
                }
            return result

        raise HTTPException(
            status_code=502,
            detail={
                "error": "extraction_insufficient",
                "message": (
                    "Could not extract company AND role. Retry with "
                    "raw_jd_text from your browser, or send force_draft=true "
                    "to save a partial listing you can fill in manually."
                ),
                "url": url,
                "extracted": {
                    "company": job.company,
                    "role": job.role,
                    "location": job.location,
                    "body_chars": len(job.body),
                },
            },
        )

    kwargs = job.to_listing_kwargs()
    # Caller-supplied status override (default `saved` is correct for
    # most imports; some flows want `applied` straight away).
    if payload.status and isinstance(payload.status, str):
        kwargs["status"] = payload.status.strip() or "saved"

    try:
        result = svc.create_listing(**kwargs)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_input", "message": str(exc)},
        ) from exc

    # Augment the response with the LLM-extracted preview so the UI can
    # show what fields were captured.
    if isinstance(result, dict):
        # Top-level company/role for consistency with the force_draft
        # branch — extension uses these for the success banner without
        # branching on which path the response came from.
        result["company"] = job.company
        result["role"] = job.role
        result["extracted"] = {
            "company": job.company,
            "role": job.role,
            "location": job.location,
            "salary_range": job.salary_range,
            "deadline": job.deadline,
            "tech_stack": list(job.tech_stack),
            "recruiter": job.recruiter,
            "posted_at": job.posted_at,
            "source_url": job.source_url,
        }
    return result


# ── Fast save (no LLM in critical path — extension's hot path) ────────────


class ListingFromUrlFastRequest(BaseModel):
    """Body for ``POST /api/career/listings/from-url-fast``.

    Architectural commitment: this route NEVER calls the LLM. It derives
    company from the URL hostname and role from the page title, then
    creates the listing in ~200ms. The raw_jd_text is preserved in
    frontmatter for an async enrichment job to consume later — the user
    sees the listing instantly, structured fields fill in over the next
    30s as the LLM completes asynchronously.

    Mirrors the architecture every working web clipper uses (Pocket /
    Raindrop / Notion Web Clipper): cheap save, async enrich, never
    block the popup on a slow process.
    """

    url: str = Field(..., min_length=1, description="The JD URL (used as source_url).")
    page_title: str = Field("", description="Browser tab title — best signal for the role.")
    raw_jd_text: str = Field("", description="JD body text from the user's authenticated DOM.")
    status: str = Field("saved", description="Initial pipeline status.")
    enrich: bool = Field(
        True,
        description="Enqueue async LLM enrichment after save (default true).",
    )


# Hostname → friendly company name. Known boards where we already know
# the brand. For anything else we strip www. + first segment and Title-Case.
_HOSTNAME_TO_COMPANY: dict[str, str] = {  # arch:deterministic — known-host mapping
    "linkedin.com": "LinkedIn",
    "indeed.com": "Indeed",
    "glassdoor.com": "Glassdoor",
    "unikresurs.se": "Unik Resurs",
    "matrareach.com": "Matrareach",
    "stackoverflow.com": "Stack Overflow",
    "wellfound.com": "Wellfound",
    "angel.co": "AngelList",
    "ycombinator.com": "Y Combinator",
}


def _derive_company_from_url(url: str) -> str:
    """Hostname → friendly company name.

    For known boards (LinkedIn, Indeed, Workday tenants etc.) return the
    canonical brand. For everything else strip ``www.``, take the first
    label, Title-Case it. Conservative — never invents.
    """
    if not url:
        return ""
    from urllib.parse import urlparse

    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        return ""
    if not host:
        return ""

    # Strip www. prefix
    host = host[4:] if host.startswith("www.") else host

    # Known mappings (exact match OR suffix match)
    if host in _HOSTNAME_TO_COMPANY:
        return _HOSTNAME_TO_COMPANY[host]
    for known, friendly in _HOSTNAME_TO_COMPANY.items():
        if host.endswith("." + known) or host == known:
            return friendly

    # Strip cv. / jobs. / careers. / apply. / etc. subdomain prefixes
    parts = host.split(".")
    common_prefixes = {"cv", "jobs", "careers", "apply", "hire", "work", "job"}
    while len(parts) > 2 and parts[0] in common_prefixes:
        parts = parts[1:]

    # First label, Title-cased, hyphen-split to multi-word
    label = parts[0] if parts else host
    words = label.replace("-", " ").replace("_", " ").split()
    return " ".join(w.capitalize() for w in words) if words else host


# Common prefixes that prepend the actual title — strip when seen at the
# start so "Ledigt jobb : Senior Engineer" → "Senior Engineer".
_TITLE_PREFIX_STRIP_RE = re.compile(  # arch:deterministic — title-cleanup heuristic
    r"^\s*(ledigt jobb|lediga jobb|job|jobb|stelling|stilling|offerta di lavoro|"
    r"oferta de empleo|offre d.emploi|stellenangebot|jobangebot|career|carriere|"
    r"vacancy|vacature|empleo|emploi|posición|posizione|stillingsbeskrivelse|"
    r"open position|new job|stelle|werk)\s*[:\-–—|]\s*",
    re.IGNORECASE,
)
# Common suffix segments that are board/site chrome, not role — strip from end.
_TITLE_SUFFIX_SEPS_RE = re.compile(r"\s*[|·•–—-]\s*")


def _derive_role_from_title(page_title: str) -> str:
    """Browser tab title → cleaned role string.

    Common shapes:
      "Ledigt jobb : Senior Engineer | Acme Corp" → "Senior Engineer"
      "Senior Engineer - Acme - LinkedIn" → "Senior Engineer"
      "Acme Corp careers — Senior Engineer" → "Senior Engineer" (split + longest)
      "Untitled" → "(role TBD)"
    Heuristic, not LLM. If the result is clearly garbage (too short, all
    punctuation), returns "(role TBD)" — user can fix in the detail page.
    """
    if not page_title or not page_title.strip():
        return "(role TBD)"

    t = page_title.strip()
    # Strip leading "Job:" / "Ledigt jobb:" patterns
    t = _TITLE_PREFIX_STRIP_RE.sub("", t, count=1)
    # Many titles are "Role | Company | Board" — split and pick the
    # segment that looks most like a role (longest, not all-caps brand).
    parts = [p.strip() for p in _TITLE_SUFFIX_SEPS_RE.split(t) if p.strip()]
    if not parts:
        return "(role TBD)"
    # Drop trailing brand-shaped segments (single word, short, all-caps
    # or initial-caps with no spaces) but only if there's something else.
    while len(parts) > 1:
        last = parts[-1]
        looks_brand = (
            len(last) <= 30 and " " not in last
        ) or last.lower() in {
            "linkedin", "indeed", "glassdoor", "workday", "lever",
            "greenhouse", "ashby", "wellfound", "angel.co", "angellist",
        }
        if looks_brand:
            parts = parts[:-1]
            continue
        break
    # Pick the longest remaining segment as the role
    role = max(parts, key=len).strip()
    if not role or len(role) < 2:
        return "(role TBD)"
    # Cap at reasonable length
    if len(role) > 140:
        role = role[:140].rstrip()
    return role


@router.post("/listings/from-url-fast")
async def create_listing_from_url_fast(
    payload: ListingFromUrlFastRequest, request: Request,
) -> dict[str, Any]:
    """Instant save. NO LLM in the critical path.

    Returns the created listing in ~200ms. ``raw_jd_text`` is preserved
    in the listing frontmatter so an async LLM enrichment job can fill
    in company / role / location / tech_stack accurately later.

    Status codes:
    - 200: listing created with derived fields. Body includes ``slug``,
      ``path``, ``company`` (derived from hostname), ``role`` (derived
      from page_title), ``enrichment_status`` ("pending" iff the
      enrichment job was enqueued).
    - 400: ``url`` empty after strip (Pydantic 422 catches the empty
      input shape; this catches all-whitespace).
    - 503: career service unavailable.
    """
    svc = _service(request)
    url = payload.url.strip()
    if not url:
        raise HTTPException(
            status_code=400,
            detail={"error": "empty_url", "message": "url is required"},
        )

    company = _derive_company_from_url(url) or "Unknown"
    role = _derive_role_from_title(payload.page_title)

    create_kwargs: dict[str, Any] = {
        "company": company,
        "role": role,
        "url": url,
        "raw_jd_text": payload.raw_jd_text or "",
        "status": (payload.status or "saved").strip() or "saved",
        "source": "imported",
    }

    try:
        result = svc.create_listing(**create_kwargs)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_input", "message": str(exc)},
        ) from exc

    enrichment_status = "skipped"
    enqueued_job_id: str | int | None = None
    if payload.enrich and payload.raw_jd_text and result and isinstance(result, dict):
        # Try to enqueue async LLM enrichment. Best-effort — if the work
        # queue isn't wired, the listing still exists with derived fields.
        slug = result.get("slug")
        if slug:
            work_queue = getattr(request.app.state, "work_queue", None)
            if work_queue is not None:
                try:
                    enqueued_job_id = await work_queue.enqueue(
                        "career_enrich_listing",
                        {"slug": slug, "url": url},
                        deduplicate=True,
                    )
                    enrichment_status = "pending"
                except Exception:  # noqa: BLE001
                    log.exception("from-url-fast: enrichment enqueue failed")
                    enrichment_status = "enqueue_failed"
            else:
                enrichment_status = "no_queue"

    if isinstance(result, dict):
        result["company"] = company
        result["role"] = role
        result["enrichment_status"] = enrichment_status
        if enqueued_job_id is not None:
            result["enrichment_job_id"] = enqueued_job_id
        result["derived"] = {
            "company_from_hostname": True,
            "role_from_title": bool(payload.page_title),
        }

        # Persist the enrichment marker to the listing's frontmatter so
        # the UI can render an "Enriching…" pill without re-querying the
        # work queue. Best-effort — failure to stamp doesn't undo the
        # save.
        slug = result.get("slug")
        if slug and enrichment_status in {"pending", "enqueue_failed", "no_queue", "skipped"}:
            try:
                svc.update_listing(slug, enrichment_status=enrichment_status)
            except Exception:  # noqa: BLE001
                log.debug("from-url-fast: enrichment_status stamp failed", exc_info=True)
    return result


# ── Applications routes (Phase 3 Slice B) ────────────────────────────────


class ApplicationCreateRequest(BaseModel):
    """Body for ``POST /api/career/applications``."""

    listing_slug: str = Field(..., min_length=1, description="The listing slug this application targets.")
    status: str = Field("draft", description="Initial preparation-pipeline status.")


class ApplicationStatusRequest(BaseModel):
    """Body for ``PATCH /api/career/applications/{slug}/status``."""

    new_status: str = Field(..., min_length=1, description="One of APPLICATION_STATUSES.")
    note: str = Field("", description="Optional note for the status_history entry.")


class ApplicationUpdateRequest(BaseModel):
    """Body for ``PATCH /api/career/applications/{slug}``.

    Free-form dict; the service validates against APPLICATION_FRONTMATTER_FIELDS
    and rejects unknown / immutable fields with 400.
    """

    generated_assets: list[str] | None = Field(
        default=None,
        description="Append to the list of generated deliverables (cv.docx, jd_analysis.md, etc.).",
    )


@router.post("/applications")
async def create_application(
    payload: ApplicationCreateRequest, request: Request,
) -> dict[str, Any]:
    """Create a new application folder + metadata.md for a listing.

    The slug is derived as ``<listing_slug>-app-<NN>`` with auto-
    incremented attempt counter so multiple applications to the same
    listing get distinct folders (retries / revisions).

    Returns the standard ``{slug, path, folder, listing_slug, status,
    created_at, attempt}`` shape so the UI can navigate to the
    application detail view without a second round-trip.

    400 codes:
    - missing listing_slug, invalid status, or listing_slug doesn't
      match an existing listing on disk.
    """
    svc = _service(request)
    try:
        return svc.create_application(
            listing_slug=payload.listing_slug,
            status=payload.status,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_input", "message": str(exc)},
        ) from exc


@router.get("/applications")
async def list_applications(
    request: Request,
    status: str | None = None,
    listing_slug: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    """Rule-20 paged list of applications.

    Query params:
    - ``status``: optional pipeline-status filter (one of
      APPLICATION_STATUSES). Invalid → 400.
    - ``listing_slug``: optional filter — "how many CV versions have I
      made for X?" — return only applications targeting this listing.
    - ``limit``, ``offset``: pagination (limit clamped to [1, 500]).
    """
    svc = _service(request)
    try:
        return svc.list_applications(
            status=status,
            listing_slug=listing_slug,
            limit=limit,
            offset=offset,
        )
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_filter", "message": str(exc)},
        ) from exc


@router.get("/applications/{slug}")
async def get_application(slug: str, request: Request) -> dict[str, Any]:
    """Return the full application metadata + body."""
    svc = _service(request)
    try:
        return svc.get_application(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


@router.patch("/applications/{slug}/status")
async def update_application_status(
    slug: str, payload: ApplicationStatusRequest, request: Request,
) -> dict[str, Any]:
    """Move an application through the preparation pipeline (draft →
    preparing → submitted → withdrawn). The status_history list in
    frontmatter gets a new append-only entry on every transition.
    """
    svc = _service(request)
    try:
        return svc.update_application_status(slug, payload.new_status, note=payload.note)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_status", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


@router.patch("/applications/{slug}")
async def update_application(
    slug: str, payload: ApplicationUpdateRequest, request: Request,
) -> dict[str, Any]:
    """Patch application frontmatter fields (status uses the dedicated
    ``/status`` route — patching ``status`` here is rejected by the
    service-level allowlist with 400).

    Only fields in ``APPLICATION_FRONTMATTER_FIELDS`` are accepted —
    today that's only ``generated_assets``. Immutable fields (slug,
    listing_slug, status, created_at, status_history) are not patchable
    through this route.
    """
    svc = _service(request)
    # Build kwargs from the Pydantic body — only include explicitly-set fields.
    fields: dict[str, Any] = {}
    if payload.generated_assets is not None:
        fields["generated_assets"] = payload.generated_assets
    if not fields:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "empty_application_patch",
                "message": "PATCH body must include at least one allowed field. "
                           "Use /status route for status changes.",
            },
        )
    try:
        return svc.update_application(slug, **fields)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_field", "message": str(exc)},
        ) from exc


@router.delete("/applications/{slug}")
async def delete_application(slug: str, request: Request) -> dict[str, Any]:
    """Idempotent delete of an application folder (Rule 18
    phantom-cleanup shape).

    Wipes the entire ``applications/{slug}/`` directory including all
    generated deliverables. Returns ``{deleted: False, slug, reason:
    "not_found"}`` for a folder that's already gone — safe to retry.
    """
    svc = _service(request)
    try:
        return svc.delete_application(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc


# ── Application JD gap analysis (Phase 3 Slice B Part 2) ──────────────────


class AnalyzeGapsRequest(BaseModel):
    """Body for ``POST /api/career/applications/{slug}/analyze-gaps``.

    ``force_refresh`` defaults True so a click reliably re-runs the
    analysis against the latest facts/. Set False to short-circuit when
    a prior ``jd_analysis.md`` already exists on disk.
    """

    force_refresh: bool = Field(
        True,
        description=(
            "When False AND jd_analysis.md already exists on disk, return "
            "the cached path without re-running the LLM."
        ),
    )


@router.post("/applications/{slug}/analyze-gaps")
async def analyze_application_gaps(
    slug: str,
    request: Request,
    payload: AnalyzeGapsRequest | None = None,
) -> dict[str, Any]:
    """Run JD gap analysis for an application.

    Reads the linked listing's JD body + the candidate's
    ``career/facts/`` files; calls the LLM at capable tier (configurable
    via ``_meta/career-jd-analyzer/config/analyze.yaml``); writes
    ``applications/{slug}/jd_analysis.md`` and appends ``jd_analysis.md``
    to ``generated_assets``. Promotes ``draft`` → ``preparing`` so the
    pipeline reflects forward motion.

    The rendered analysis is the anti-fabrication ground truth for
    Slice C's CV builder + cover letter generator. They read the same
    file and refuse to claim a missing requirement as covered.

    Response (success):

    .. code-block:: json

        {
          "ok": true,
          "slug": "<app-slug>",
          "listing_slug": "<listing-slug>",
          "path": "career/applications/<slug>/jd_analysis.md",
          "covered_count": 3,
          "partial_count": 2,
          "missing_count": 4,
          "total_requirements": 9,
          "coverage_ratio": 0.333,
          "honest_summary": "...",
          "status_promoted": true,
          "previous_status": "draft"
        }

    Response (non-fatal failure — returns 200 with diagnostic shape so
    the UI can show a friendly toast instead of an opaque 500):

    .. code-block:: json

        {"ok": false, "reason": "<closed-enum>", "slug": "...", "message": "..."}

    Closed enum of ``reason`` values:

    - ``analyzer_disabled`` — YAML kill switch flipped to false.
    - ``agent_not_wired`` — server config issue.
    - ``application_missing_listing_slug`` — vault integrity issue.
    - ``listing_jd_empty`` — listing exists but body is empty.
    - ``no_usable_signal`` — LLM produced no usable JSON.
    - ``analyzer_crashed`` — belt-and-braces; analyzer never raises.
    """
    svc = _service(request)
    force_refresh = True if payload is None else payload.force_refresh
    try:
        return await svc.analyze_application_gaps(slug, force_refresh=force_refresh)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


# ── Application CV builder (Phase 3 Slice C) ──────────────────────────────


class BuildCvRequest(BaseModel):
    """Body for ``POST /api/career/applications/{slug}/build-cv``."""

    force_refresh: bool = Field(
        True,
        description=(
            "When False AND cv.docx already exists, return the cached "
            "path without re-running the LLM."
        ),
    )


@router.post("/applications/{slug}/build-cv")
async def build_application_cv(
    slug: str,
    request: Request,
    payload: BuildCvRequest | None = None,
) -> dict[str, Any]:
    """Build a tailored CV .docx for an application.

    Reads the application's metadata, the parent listing's JD, the
    previously-generated ``jd_analysis.md`` (REQUIRED — the gap report
    is the anti-fabrication ground truth), and the candidate's
    ``career/facts/`` files. Calls the LLM at capable tier, parses
    structured CV sections, runs the anti-fabrication post-lint (strips
    any MISSING-list terms that leaked through the prompt), renders the
    result to ``applications/{slug}/cv.docx``.

    Appends ``cv.docx`` to ``generated_assets``. Promotes
    ``draft → preparing`` so the pipeline reflects forward motion.

    Closed enum of non-fatal ``reason`` values (200 response):

    - ``builder_disabled`` — YAML kill switch.
    - ``agent_not_wired`` — server config.
    - ``application_missing_listing_slug`` — vault integrity.
    - ``missing_gap_report`` — user must run analyze-gaps first.
    - ``listing_jd_empty`` — listing has no JD body.
    - ``no_facts_on_file`` — career/facts/ is empty.
    - ``no_usable_content`` — LLM produced no usable CV.
    - ``docx_render_failed`` — python-docx not installed or IO error.
    - ``builder_crashed`` — belt-and-braces.
    """
    svc = _service(request)
    force_refresh = True if payload is None else payload.force_refresh
    try:
        return await svc.build_application_cv(slug, force_refresh=force_refresh)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


# ── Application cover letter builder (Phase 3 Slice C) ────────────────────


class BuildCoverLetterRequest(BaseModel):
    """Body for ``POST /api/career/applications/{slug}/build-cover-letter``."""

    force_refresh: bool = Field(
        True,
        description=(
            "When False AND cover_letter.docx already exists, return "
            "the cached path without re-running the LLM."
        ),
    )


@router.post("/applications/{slug}/build-cover-letter")
async def build_application_cover_letter(
    slug: str,
    request: Request,
    payload: BuildCoverLetterRequest | None = None,
) -> dict[str, Any]:
    """Build a tailored cover letter .docx for an application.

    Mirrors ``build-cv`` shape — reads metadata + listing + gap report
    + facts/, LLM at capable tier, anti-fabrication post-lint
    (paragraph-grained drop instead of CV's line-grained strip), renders
    to ``applications/{slug}/cover_letter.docx``.

    Requires a prior ``jd_analysis.md`` — the gap report is the
    anti-fabrication ground truth.

    Closed enum of non-fatal ``reason`` values mirrors ``build-cv``.
    """
    svc = _service(request)
    force_refresh = True if payload is None else payload.force_refresh
    try:
        return await svc.build_application_cover_letter(
            slug, force_refresh=force_refresh,
        )
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


# ── Privacy — forget-all (Phase 4) ─────────────────────────────────────────


class ForgetAllRequest(BaseModel):
    """Body for ``POST /api/career/forget-all``.

    The ``confirm`` field is required — defaults to False so an empty
    POST is a dry-run inventory, not an accidental wipe.
    """

    confirm: bool = Field(
        False,
        description=(
            "When False (default) returns inventory without deleting. "
            "When True, wipes every file under "
            "career/{facts,listings,applications,library,inbox}/. "
            "Destructive + irreversible — UI MUST surface a confirm dialog."
        ),
    )


@router.post("/forget-all")
async def forget_all_career_data(
    request: Request,
    payload: ForgetAllRequest | None = None,
) -> dict[str, Any]:
    """GDPR-aligned wipe of all career data.

    Two-step UX:
      1. ``{confirm: false}`` (default) returns the inventory without
         deleting. The UI shows the user what would be wiped.
      2. ``{confirm: true}`` actually wipes + emits a single
         high-importance ``career_forget_all`` activity event.

    Returns the canonical ``forget_all`` result dict (see service
    docstring). Idempotent on empty vaults.

    Per Rule 14, this is destructive + irreversible. The route does
    NOT echo back the body to the user (the activity event carries
    the audit trail).
    """
    svc = _service(request)
    confirm = False if payload is None else payload.confirm
    return svc.forget_all(confirm=confirm)
