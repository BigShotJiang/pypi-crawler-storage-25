"""GET /api/extension/web-clipper/{info,download} — serve the browser
extension to users who want to install it.

Two modes:

1. **Repo install** — the user cloned the repo. ``_find_extension_dir``
   returns ``<repo>/extensions/web-clipper/``. The /info endpoint
   returns this path so the UI can show it in a copy-able field; users
   can paste it directly into Chrome's "Load unpacked" file picker.

2. **Wheel install** — the user installed via ``pip install agntspace``.
   ``_find_extension_dir`` falls back to
   ``importlib.resources.files("agntspace") / "extensions" / "web-clipper"``.
   The /download endpoint zips the directory on-the-fly so users can
   unzip somewhere convenient and then "Load unpacked" against the
   extracted folder.

Both endpoints are read-only — no contract gate, no activity event.
Mirrors the resolver pattern in ``setup/init._find_defaults_dir`` so
the dev-vs-wheel boundary stays uniform across the codebase.
"""
from __future__ import annotations

import importlib.resources
import io
import json
import logging
import zipfile
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

log = logging.getLogger(__name__)

router = APIRouter(prefix="/extension", tags=["extension"])


# ── Extension directory resolution ─────────────────────────────────────────

_EXTENSION_FILES = (  # arch:deterministic — file inventory of a fixed directory we ship, not strategy
    "manifest.json",
    "background.js",
    "popup.html",
    "popup.js",
    "options.html",
    "options.js",
    "README.md",
    "icons/icon16.png",
    "icons/icon32.png",
    "icons/icon48.png",
    "icons/icon128.png",
)
# ^^ Files copied into the .zip download. Anything not on this list is
# excluded — defends against accidental .git / __pycache__ / .DS_Store
# pollution if a maintainer ever runs the extension dir through a dev
# tool that leaves artifacts behind. Lock the inline marker on the
# constant's own line so the arch:no-hardcoded-strategy scanner sees it.


def _find_extension_dir() -> Path | None:
    """Locate ``extensions/web-clipper/`` — repo path first, then wheel.

    Returns ``None`` when neither path exists (which means the install is
    broken — extension files weren't bundled or weren't checked out).
    The route caller turns this into a 503.
    """
    # 1. Repo path. server/src/agntspace/api/routes/extension.py →
    #    parents[5] is the repo root.
    repo_path = (
        Path(__file__).parent.parent.parent.parent.parent.parent
        / "extensions"
        / "web-clipper"
    )
    if repo_path.is_dir():
        return repo_path

    # 2. Wheel-bundled path. Force-included in pyproject.toml under
    #    agntspace/extensions/web-clipper/.
    try:
        ref = importlib.resources.files("agntspace") / "extensions" / "web-clipper"
        pkg_path = Path(str(ref))
        if pkg_path.is_dir():
            return pkg_path
    except (TypeError, FileNotFoundError, ModuleNotFoundError):
        pass

    return None


def _read_manifest_version(ext_dir: Path) -> str:
    """Read manifest.json and return its version string.

    Returns empty string on any failure. Never raises — the /info
    endpoint shouldn't 500 because a stray manifest.json is malformed.
    """
    try:
        manifest_path = ext_dir / "manifest.json"
        if not manifest_path.is_file():
            return ""
        with manifest_path.open(encoding="utf-8") as fh:
            data = json.load(fh)
        version = data.get("version", "")
        return str(version) if version else ""
    except Exception:
        log.debug("extension: failed to read manifest.json", exc_info=True)
        return ""


def _build_extension_zip(ext_dir: Path) -> bytes:
    """Build an in-memory zip of the extension files.

    Returns bytes — bounded by the small file set (~30-50 KB total).
    Each file is read separately so a missing optional file (e.g. a
    future-added file that isn't on every install) doesn't kill the zip.
    """
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel in _EXTENSION_FILES:
            src = ext_dir / rel
            if not src.is_file():
                # Missing optional file. Log + skip rather than 500 — the
                # remaining files still produce a usable extension.
                log.debug("extension: missing file %s", rel)
                continue
            zf.write(src, arcname=rel)
    return buffer.getvalue()


# ── Routes ─────────────────────────────────────────────────────────────────


@router.get("/web-clipper/info")
async def web_clipper_info() -> dict[str, Any]:
    """Return install-time facts about the web-clipper extension.

    Used by the /extension UI page to render the install guide:
    - ``available``: whether the extension dir was found at all.
    - ``version``: manifest.json's version (e.g. "1.1.0").
    - ``path``: absolute filesystem path users can paste into Chrome's
      "Load unpacked" dialog. Empty when ``available`` is False.
    - ``file_count``: how many of the canonical files were found on disk.
    """
    ext_dir = _find_extension_dir()
    if ext_dir is None:
        return {
            "available": False,
            "version": "",
            "path": "",
            "file_count": 0,
        }

    file_count = sum(1 for rel in _EXTENSION_FILES if (ext_dir / rel).is_file())
    return {
        "available": True,
        "version": _read_manifest_version(ext_dir),
        "path": str(ext_dir),
        "file_count": file_count,
    }


@router.get("/web-clipper/download")
async def web_clipper_download() -> StreamingResponse:
    """Stream a zip of the extension files.

    User downloads, unzips somewhere, then in chrome://extensions clicks
    "Load unpacked" against the unzipped folder.
    """
    ext_dir = _find_extension_dir()
    if ext_dir is None:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "extension_not_found",
                "message": (
                    "AgntSpace web-clipper extension files not found. "
                    "Reinstall AgntSpace or clone the repository."
                ),
            },
        )

    try:
        zip_bytes = _build_extension_zip(ext_dir)
    except Exception as exc:
        log.exception("extension: failed to build zip")
        raise HTTPException(
            status_code=500,
            detail={"error": "zip_build_failed", "message": str(exc)},
        ) from exc

    # An "empty" zip still has ~22 bytes of central-directory header, so
    # `not zip_bytes` is False even when no files were packaged. Verify
    # by reading the namelist — that's the structural emptiness check.
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            packaged_names = zf.namelist()
    except zipfile.BadZipFile:
        packaged_names = []

    if not packaged_names:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "extension_empty",
                "message": "Extension directory exists but no files were packaged.",
            },
        )

    version = _read_manifest_version(ext_dir) or "latest"
    filename = f"agntspace-web-clipper-{version}.zip"

    return StreamingResponse(
        io.BytesIO(zip_bytes),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(zip_bytes)),
        },
    )
