"""
Geek Cafe, LLC
MIT License.  See Project Root for the license information.

SubscriptionService for managing tenant subscriptions and billing.
"""

from typing import Dict, Any, Optional, List, Tuple, Union
from decimal import Decimal
from boto3_assist.dynamodb.dynamodb import DynamoDB
from geek_cafe_saas_sdk.core.services.database_service import DatabaseService
from .tenant_service import TenantService
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.lambda_handlers._base.decorators import service_method
from geek_cafe_saas_sdk.core.service_errors import ValidationError, NotFoundError, AccessDeniedError
from geek_cafe_saas_sdk.modules.tenancy.models import Subscription
from geek_cafe_saas_sdk.modules.tenancy.models import Tenant
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
import datetime as dt


class SubscriptionService(DatabaseService[Subscription]):
    """
    Service for subscription management operations.
    
    Handles subscription lifecycle including:
    - Creating and activating subscriptions
    - Subscription history tracking
    - Active subscription pointer management
    - Billing period management
    - Payment tracking
    - Cancellations
    
    Uses active subscription pointer pattern:
    - History items: PK=subscription#<id>, SK=subscription#<id>
    - Active pointer: PK=tenant#<tenant_id>, SK=subscription#active
    
    The active pointer allows O(1) lookup of current subscription
    without scanning history.
    """

    def __init__(self, *, dynamodb: DynamoDB = None, table_name: str = None,
                 tenant_service: TenantService = None, request_context: Optional[Dict[str, str]] = None):
        super().__init__(dynamodb=dynamodb, table_name=table_name, request_context=request_context)
        # Tenant service for updating tenant plan_tier
        self.tenant_service = tenant_service or TenantService(
            dynamodb=dynamodb, table_name=table_name, request_context=request_context
        )

    @service_method("create")


    def create(self, payload: Dict[str, Any]) -> ServiceResult[Subscription]:
        """
        Create a new subscription (adds to history).
        
        Note: This creates a subscription record but does NOT make it active.
        Use activate_subscription() to make it the active subscription.
        
        Args:
            payload: Subscription data
            
        Returns:
            ServiceResult with Subscription
            
        Security:
            - Requires authentication
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id
        try:
            # Validate required fields
            required_fields = ['plan_code', 'price_cents']
            self._validate_required_fields(payload, required_fields)

            # Create subscription instance
            subscription = Subscription().map(payload)
            subscription.tenant_id = tenant_id
            subscription.user_id = user_id
            subscription.created_by_id = user_id

            # Set defaults
            if not subscription.currency:
                subscription.currency = "USD"
            if subscription.seat_count < 1:
                subscription.seat_count = 1

            # Prepare for save
            subscription.prep_for_save()

            # Save to database
            return self._save_model(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'create_subscription')

    @service_method("activate_subscription")
    def activate_subscription(self, 
                            payload: Dict[str, Any]) -> ServiceResult[Subscription]:
        """
        Create and activate a new subscription for tenant.
        
        Atomically:
        1. Puts new subscription record
        2. If an old active subscription exists, marks it as "superseded"
        3. Updates active subscription pointer
        4. Updates tenant plan_tier (non-critical, outside transaction)
        
        Args:
            payload: Subscription data (plan_code, price_cents, etc.)
            
        Returns:
            ServiceResult with new active Subscription
            
        Security:
            - Requires authentication
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id
        try:
            # Validate required fields
            required_fields = ['plan_code', 'price_cents', 'current_period_start_utc_ts',
                             'current_period_end_utc_ts']
            self._validate_required_fields(payload, required_fields)

            # Create subscription
            subscription = Subscription().map(payload)
            subscription.tenant_id = tenant_id
            subscription.user_id = user_id
            subscription.created_by_id = user_id

            # Set defaults
            if not subscription.status:
                subscription.status = "active"
            if not subscription.currency:
                subscription.currency = "USD"
            if subscription.seat_count < 1:
                subscription.seat_count = 1

            # Prepare for save
            subscription.prep_for_save()

            # 1. Get current active subscription (if any)
            old_sub = None
            active_result = self.get_active_subscription()
            if active_result.success and active_result.data is not None:
                old_sub = active_result.data

            # 2. Build TransactWrite operations
            from boto3_assist.dynamodb.dynamodb_key import DynamoDBKey

            operations: List[Dict[str, Any]] = [
                # Put new subscription
                {
                    "Put": {
                        "TableName": self.table_name,
                        "Item": subscription.to_resource_dictionary(),
                    }
                },
            ]

            # If old active sub exists, mark it as superseded
            if old_sub is not None:
                old_pk = DynamoDBKey.build_key(("subscription", old_sub.id))
                old_sk = DynamoDBKey.build_key(("subscription", old_sub.id))
                now_ts = Decimal(str(dt.datetime.now(dt.UTC).timestamp()))

                operations.append(
                    {
                        "Update": {
                            "TableName": self.table_name,
                            "Key": {"pk": old_pk, "sk": old_sk},
                            "UpdateExpression": "SET #status = :superseded, notes = :notes, modified_utc_ts = :now",
                            "ExpressionAttributeNames": {"#status": "status"},
                            "ExpressionAttributeValues": {
                                ":superseded": "superseded",
                                ":notes": f"Superseded by: {subscription.id}",
                                ":now": now_ts,
                            },
                        }
                    }
                )

            # Put active pointer
            operations.append(
                self._update_active_pointer_operation(tenant_id, subscription.id, user_id)
            )

            # 3. Execute atomic transaction
            tx_result = self._execute_transact_write(operations)
            if not tx_result.success:
                return tx_result

            # 4. Update tenant plan_tier and max_users (non-critical, keep outside transaction)
            plan_tier = self._map_plan_code_to_tier(subscription.plan_code)
            tenant_result = self.tenant_service.update(
                tenant_id,
                {"plan_tier": plan_tier, "max_users": subscription.seat_count}
            )
            if not tenant_result.success:
                # Log error but don't fail - subscription is already active
                pass

            return ServiceResult.success_result(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'activate_subscription',
                                                 tenant_id=tenant_id, user_id=user_id)

    def _update_active_pointer(self, tenant_id: str, subscription_id: str,
                              user_id: str, execute: bool = True) -> Union[ServiceResult[Dict[str, Any]], Dict[str, Any]]:
        """
        Update active subscription pointer for tenant.
        
        Creates/updates a special pointer item:
        PK: tenant#<tenant_id>
        SK: subscription#active
        
        Args:
            tenant_id: Tenant ID
            subscription_id: Subscription ID to point to
            user_id: User performing update
            execute: When True (default), performs the put directly.
                     When False, returns the pointer item dict wrapped
                     in a TransactWrite Put operation format.
            
        Returns:
            When execute=True: ServiceResult with pointer item data
            When execute=False: A TransactWrite Put operation dict
        """
        try:
            # Build pointer item
            from boto3_assist.dynamodb.dynamodb_key import DynamoDBKey
            
            pk = DynamoDBKey.build_key(("tenant", tenant_id))
            sk = "subscription#active"
            
            now = dt.datetime.now(dt.UTC).timestamp()
            
            pointer_item = {
                "pk": pk,
                "sk": sk,
                "active_subscription_id": subscription_id,
                "modified_utc_ts": Decimal(str(now)),  # Convert to Decimal for DynamoDB
                "updated_by_id": user_id
            }

            if not execute:
                return {"Put": {"TableName": self.table_name, "Item": pointer_item}}

            # Put item
            self.dynamodb.resource.Table(self.table_name).put_item(Item=pointer_item)

            return ServiceResult.success_result(pointer_item)

        except Exception as e:
            return ServiceResult(
                success=False,
                message=f"Failed to update active pointer: {str(e)}",
                error_code="POINTER_UPDATE_ERROR"
            )

    def _map_plan_code_to_tier(self, plan_code: str) -> str:
        """Map plan code to tenant plan_tier."""
        mapping = {
            "free": "free",
            "basic": "basic",
            "basic_monthly": "basic",
            "basic_yearly": "basic",
            "pro": "pro",
            "pro_monthly": "pro",
            "pro_yearly": "pro",
            "enterprise": "enterprise"
        }
        return mapping.get(plan_code, str(plan_code).lower())

    @service_method("get_active_subscription")


    def get_active_subscription(self) -> ServiceResult[Subscription]:
        """
        Get active subscription for tenant (O(1) lookup via pointer).
        
        Returns:
            ServiceResult with active Subscription, or None if no active subscription
            
        Security:
            - Requires authentication
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        try:
            # Get pointer item
            from boto3_assist.dynamodb.dynamodb_key import DynamoDBKey
            
            pk = DynamoDBKey.build_key(("tenant", tenant_id))
            sk = "subscription#active"

            response = self.dynamodb.resource.Table(self.table_name).get_item(
                Key={"pk": pk, "sk": sk}
            )

            if "Item" not in response:
                # No active subscription
                return ServiceResult.success_result(None)

            pointer_item = response["Item"]
            active_sub_id = pointer_item.get("active_subscription_id")

            if not active_sub_id:
                return ServiceResult.success_result(None)

            # Get the actual subscription
            return self.get_by_id(active_sub_id)

        except Exception as e:
            return self._handle_service_exception(e, 'get_active_subscription')

    @service_method("get_by_id")
    def get_by_id(self, subscription_id: str) -> ServiceResult[Subscription]:
        """
        Get subscription by ID with access control.
        
        Args:
            subscription_id: Subscription ID
            
        Returns:
            ServiceResult with Subscription
            
        Security:
            - Requires authentication
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        try:
            subscription = self._get_by_id(subscription_id, Subscription)

            if not subscription:
                raise NotFoundError(f"Subscription with ID {subscription_id} not found")

            # Check if deleted
            if subscription.is_deleted():
                raise NotFoundError(f"Subscription with ID {subscription_id} not found")

            # Validate tenant access
            if subscription.tenant_id != tenant_id:
                raise AccessDeniedError("You don't have access to this subscription")

            return ServiceResult.success_result(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'get_subscription',
                                                 subscription_id=subscription_id)

    @service_method("list_subscription_history")
    def list_subscription_history(self,
                                  limit: int = 50) -> ServiceResult[List[Subscription]]:
        """
        List subscription history for tenant (newest first).
        
        Uses GSI1 to query all subscriptions for a tenant, sorted by period start date.
        
        Args:
            limit: Maximum number of results
            
        Returns:
            ServiceResult with list of Subscriptions
            
        Security:
            - Requires authentication
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        try:
            # Create temp subscription for GSI1 query
            temp_sub = Subscription()
            temp_sub.tenant_id = tenant_id            

            result = self._query_by_index(
                temp_sub,
                "gsi1",
                ascending=False,  # Newest first
                limit=limit
            )

            if not result.success:
                return result

            # Filter out deleted subscriptions
            active_subs = [s for s in result.data if not s.is_deleted()]

            return ServiceResult.success_result(active_subs)

        except Exception as e:
            return self._handle_service_exception(e, 'list_subscription_history')

    @service_method("cancel_subscription")


    def cancel_subscription(self, subscription_id: str,
                          reason: Optional[str] = None, immediate: bool = False) -> ServiceResult[Subscription]:
        """
        Cancel a subscription.
        
        Args:
            subscription_id: Subscription ID to cancel
            reason: Optional cancellation reason
            immediate: If True, cancel immediately; if False, cancel at period end
            
        Returns:
            ServiceResult with canceled Subscription
        """
        try:
            # Get user for audit trail
            user_id = self.request_context.target_user_id
            
            # Get subscription (tenant/user validation handled by get_by_id)
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return get_result

            subscription = get_result.data

            # Cancel
            subscription.cancel(reason=reason, immediate=immediate)
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1

            # Save
            save_result = self._save_model(subscription)

            if save_result.success and immediate:
                # If immediate cancellation, could remove active pointer or set to free plan
                # For now, we'll leave the pointer but mark subscription as canceled
                pass

            return save_result

        except Exception as e:
            return self._handle_service_exception(e, 'cancel_subscription',
                                                 subscription_id=subscription_id)

    @service_method("record_payment")


    def record_payment(self, subscription_id: str,
                      amount_cents: int) -> ServiceResult[Subscription]:
        """
        Record a successful payment for subscription.
        
        Args:
            subscription_id: Subscription ID
            amount_cents: Payment amount in cents
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            # Get user for audit trail
            user_id = self.request_context.target_user_id
            
            # Get subscription (tenant/user validation handled by get_by_id)
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return get_result

            subscription = get_result.data

            # Record payment
            subscription.record_payment(amount_cents)
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1

            # Save
            return self._save_model(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'record_payment',
                                                 subscription_id=subscription_id)

    @service_method("mark_past_due")


    def mark_past_due(self, subscription_id: str) -> ServiceResult[Subscription]:
        """
        Mark subscription as past due (payment failed).
        
        Args:
            subscription_id: Subscription ID
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            # Get user for audit trail
            user_id = self.request_context.target_user_id
            
            # Get subscription (tenant/user validation handled by get_by_id)
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return get_result

            subscription = get_result.data

            # Mark past due
            subscription.mark_past_due()
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1

            # Save
            return self._save_model(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'mark_past_due',
                                                 subscription_id=subscription_id)

    def list_subscriptions_by_status(self, status: str, limit: int = 50) -> ServiceResult[List[Subscription]]:
        """
        List subscriptions by status (for billing jobs/admin).
        
        Uses GSI2 to query subscriptions by status, sorted by next_billing_date.
        This is useful for background jobs that process billing.
        
        Args:
            status: Subscription status (trial|active|past_due|canceled|expired)
            limit: Maximum number of results
            
        Returns:
            ServiceResult with list of Subscriptions
        """
        try:
            # Create temp subscription for GSI2 query
            temp_sub = Subscription()
            temp_sub.status = status

            result = self._query_by_index(
                temp_sub,
                "gsi2",
                ascending=True,  # Earliest next billing first
                limit=limit
            )

            if not result.success:
                return result

            # Filter out deleted subscriptions
            active_subs = [s for s in result.data if not s.is_deleted()]

            return ServiceResult.success_result(active_subs)

        except Exception as e:
            return self._handle_service_exception(e, 'list_subscriptions_by_status',
                                                 status=status)

    @service_method("update")


    def update(self, subscription_id: str,
               updates: Dict[str, Any]) -> ServiceResult[Subscription]:
        """
        Update subscription.
        
        Args:
            subscription_id: Subscription ID to update
            updates: Fields to update
            
        Returns:
            ServiceResult with updated Subscription
        """
        self.request_context.require_authentication()
        user_id = self.request_context.target_user_id
        try:
            # Get subscription
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return get_result

            subscription = get_result.data

            # Update fields
            subscription.map(updates)
            subscription.updated_by_id = user_id
            if not subscription.user_id:
                subscription.user_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1

            # Save
            return self._save_model(subscription)

        except Exception as e:
            return self._handle_service_exception(e, 'update_subscription',
                                                 subscription_id=subscription_id)

    @service_method("delete")


    def delete(self, subscription_id: str) -> ServiceResult[bool]:
        """
        Soft delete subscription.
        
        Args:
            subscription_id: Subscription ID to delete
            
        Returns:
            ServiceResult with boolean (True if deleted)
        """
        self.request_context.require_authentication()
        user_id = self.request_context.target_user_id
        try:
            # Get subscription
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return ServiceResult(success=False, message=get_result.message,
                                   error_code=get_result.error_code)

            subscription = get_result.data

            # Soft delete
            subscription.deleted_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.deleted_by_id = user_id
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()

            # Save
            save_result = self._save_model(subscription)
            if not save_result.success:
                return ServiceResult(success=False, message=save_result.message,
                                   error_code=save_result.error_code)

            return ServiceResult.success_result(True)

        except Exception as e:
            return self._handle_service_exception(e, 'delete_subscription',
                                                 subscription_id=subscription_id)
    
    # ========================================================================
    # Renewal Methods
    # ========================================================================

    def check_renewal_eligibility(self, subscription: Subscription) -> ServiceResult:
        """
        Check whether a subscription is eligible for renewal.

        Checks are evaluated in priority order:
        1. cancel_at_period_end → RENEWAL_CANCELED
        2. status "disabled" → RENEWAL_DISABLED
        3. status "past_due" → RENEWAL_PAST_DUE
        4. status "canceled" or "expired" → RENEWAL_INELIGIBLE
        5. status "active" or "trial" with cancel_at_period_end False → success

        Args:
            subscription: The Subscription to evaluate.

        Returns:
            ServiceResult indicating eligibility or the specific rejection reason.
        """
        # 1. Check cancel_at_period_end first (active sub can be pending cancel)
        if subscription.cancel_at_period_end:
            return ServiceResult(
                success=False,
                message="Subscription is set to cancel at period end",
                error_code="RENEWAL_CANCELED",
            )

        # 2. Disabled
        if subscription.status == "disabled":
            return ServiceResult(
                success=False,
                message="Subscription is disabled",
                error_code="RENEWAL_DISABLED",
            )

        # 3. Past due
        if subscription.status == "past_due":
            return ServiceResult(
                success=False,
                message="Subscription has past due payments",
                error_code="RENEWAL_PAST_DUE",
            )

        # 4. Canceled or expired
        if subscription.status in ("canceled", "expired"):
            return ServiceResult(
                success=False,
                message="Subscription is not in a renewable state",
                error_code="RENEWAL_INELIGIBLE",
            )

        # 5. Eligible statuses
        if subscription.status in ("active", "trial"):
            return ServiceResult.success_result(subscription)

        # Any other status is ineligible
        return ServiceResult(
            success=False,
            message="Subscription is not in a renewable state",
            error_code="RENEWAL_INELIGIBLE",
        )

    def _calculate_contiguous_period(
        self, old_subscription: Subscription
    ) -> Union[Tuple[float, float, float], ServiceResult]:
        """
        Calculate contiguous billing period dates for a renewal.

        Args:
            old_subscription: The subscription being renewed.

        Returns:
            A tuple of (new_start, new_end, next_billing) as epoch floats,
            or a ServiceResult with error code INVALID_PERIOD if the old
            subscription has no valid period end date.
        """
        period_end = old_subscription.current_period_end_utc_ts

        if period_end is None or period_end == 0:
            return ServiceResult(
                success=False,
                message="Subscription has no valid period end date",
                error_code="INVALID_PERIOD",
            )

        new_start_ts: float = period_end
        new_start_dt = datetime.fromtimestamp(new_start_ts, tz=timezone.utc)

        if old_subscription.billing_interval == "year":
            new_end_dt = new_start_dt + relativedelta(years=1)
        else:
            # Default to month
            new_end_dt = new_start_dt + relativedelta(months=1)

        new_end_ts: float = new_end_dt.timestamp()
        next_billing_ts: float = new_end_ts

        return (new_start_ts, new_end_ts, next_billing_ts)

    def _compute_idempotency_key(self, tenant_id: str, period_start_ts: float) -> str:
        """
        Compute a deterministic idempotency key for a renewal.

        The key is derived from the tenant ID and the target period start
        timestamp, ensuring the same renewal attempt always produces the
        same key.

        Args:
            tenant_id: The tenant's identifier.
            period_start_ts: The target period start timestamp (epoch float).

        Returns:
            A string key in the format ``"<tenant_id>#<int(period_start_ts)}"``.
        """
        return f"{tenant_id}#{int(period_start_ts)}"

    def _find_existing_renewal(
        self, tenant_id: str, period_start_ts: float
    ) -> Optional[Subscription]:
        """
        Check whether a renewal subscription already exists for the given period.

        Queries the tenant's subscription history and looks for a subscription
        whose ``current_period_start_utc_ts`` matches *period_start_ts*
        (compared as integers to avoid floating-point issues).

        Args:
            tenant_id: The tenant's identifier.
            period_start_ts: The target period start timestamp to match.

        Returns:
            The existing ``Subscription`` if found, otherwise ``None``.
        """
        try:
            history_result = self.list_subscription_history(limit=50)
            if not history_result.success or not history_result.data:
                return None

            target_int = int(period_start_ts)
            for sub in history_result.data:
                if (
                    sub.current_period_start_utc_ts is not None
                    and int(sub.current_period_start_utc_ts) == target_int
                ):
                    return sub

            return None
        except Exception:
            return None

    def _build_renewal_subscription(
        self,
        old_sub: Subscription,
        new_start: float,
        new_end: float,
        next_billing: float,
    ) -> Subscription:
        """
        Build a new Subscription that renews *old_sub*.

        Copies plan and billing fields from the old subscription and sets
        the new period timestamps.  Calls ``prep_for_save()`` to generate
        a fresh ID and populate index keys.

        Args:
            old_sub: The subscription being renewed.
            new_start: New period start timestamp.
            new_end: New period end timestamp.
            next_billing: Next billing timestamp.

        Returns:
            A new ``Subscription`` ready to be persisted.
        """
        new_sub = Subscription()

        # Identity
        new_sub.tenant_id = old_sub.tenant_id
        new_sub.user_id = old_sub.user_id

        # Plan details
        new_sub.plan_code = old_sub.plan_code
        new_sub.plan_name = old_sub.plan_name
        new_sub.plan_id = old_sub.plan_id
        new_sub.price_cents = old_sub.price_cents
        new_sub.currency = old_sub.currency
        new_sub.billing_interval = old_sub.billing_interval
        new_sub.seat_count = old_sub.seat_count

        # Payment / external
        new_sub.payment_method = old_sub.payment_method
        new_sub.external_subscription_id = old_sub.external_subscription_id
        new_sub.external_customer_id = old_sub.external_customer_id

        # Addons
        new_sub.active_addons = list(old_sub.active_addons)
        new_sub.addon_metadata = dict(old_sub.addon_metadata)

        # Status & period
        new_sub.status = "active"
        new_sub.current_period_start_utc_ts = new_start
        new_sub.current_period_end_utc_ts = new_end
        new_sub.next_billing_utc_ts = next_billing

        # Generate ID and index keys
        new_sub.prep_for_save()

        return new_sub

    def _execute_transact_write(
        self, operations: List[Dict[str, Any]]
    ) -> ServiceResult:
        """
        Execute a DynamoDB TransactWrite with error handling.

        Args:
            operations: A list of TransactWrite operation dicts
                        (Put / Update / Delete / ConditionCheck).

        Returns:
            ``ServiceResult.success_result(True)`` on success, or a
            ``ServiceResult`` with error code ``TRANSACTION_FAILED`` on
            failure.
        """
        try:
            self.dynamodb.transact_write_items(operations=operations)
            return ServiceResult.success_result(True)
        except Exception as e:
            return ServiceResult(
                success=False,
                message=f"Renewal transaction failed: {str(e)}",
                error_code="TRANSACTION_FAILED",
            )

    def _update_active_pointer_operation(
        self, tenant_id: str, subscription_id: str, user_id: str
    ) -> Dict[str, Any]:
        """
        Build a TransactWrite Put operation dict for the active pointer.

        This is the non-executing counterpart of ``_update_active_pointer``
        and is used when the pointer update must be part of a larger
        transaction.

        Args:
            tenant_id: Tenant ID.
            subscription_id: Subscription ID to point to.
            user_id: User performing the update.

        Returns:
            A dict suitable for inclusion in a TransactWrite operations list.
        """
        from boto3_assist.dynamodb.dynamodb_key import DynamoDBKey

        pk = DynamoDBKey.build_key(("tenant", tenant_id))
        sk = "subscription#active"
        now = dt.datetime.now(dt.UTC).timestamp()

        pointer_item = {
            "pk": pk,
            "sk": sk,
            "active_subscription_id": subscription_id,
            "modified_utc_ts": Decimal(str(now)),
            "updated_by_id": user_id,
        }

        return {"Put": {"TableName": self.table_name, "Item": pointer_item}}

    def renew_subscription(
        self, subscription_id: str
    ) -> ServiceResult[Subscription]:
        """
        Renew an existing subscription.

        Full flow:
        1. Require authentication.
        2. Fetch the subscription by ID.
        3. Check renewal eligibility.
        4. Compute idempotency key and look for an existing renewal.
        5. Calculate contiguous period.
        6. Build the renewal subscription.
        7. Execute an atomic TransactWrite (put new sub, expire old sub,
           update active pointer).
        8. Return the new subscription.

        Args:
            subscription_id: The ID of the subscription to renew.

        Returns:
            ``ServiceResult[Subscription]`` with the new subscription on
            success, or an error result describing the failure.
        """
        self.request_context.require_authentication()
        tenant_id = self.request_context.target_tenant_id
        user_id = self.request_context.target_user_id

        try:
            # 1. Get the subscription
            get_result = self.get_by_id(subscription_id)
            if not get_result.success:
                return get_result

            old_sub: Subscription = get_result.data

            # 2. Check eligibility
            eligibility = self.check_renewal_eligibility(old_sub)
            if not eligibility.success:
                return eligibility

            # 3. Idempotency check
            period_start_ts = old_sub.current_period_end_utc_ts
            self._compute_idempotency_key(tenant_id, period_start_ts)
            existing = self._find_existing_renewal(tenant_id, period_start_ts)
            if existing is not None:
                return ServiceResult(
                    success=True,
                    data=existing,
                    message="Renewal already processed for this billing period",
                )

            # 4. Calculate contiguous period
            period_result = self._calculate_contiguous_period(old_sub)
            if isinstance(period_result, ServiceResult):
                return period_result
            new_start, new_end, next_billing = period_result

            # 5. Build renewal subscription
            new_sub = self._build_renewal_subscription(
                old_sub, new_start, new_end, next_billing
            )

            # 6. Build TransactWrite operations
            from boto3_assist.dynamodb.dynamodb_key import DynamoDBKey

            old_pk = DynamoDBKey.build_key(("subscription", old_sub.id))
            old_sk = DynamoDBKey.build_key(("subscription", old_sub.id))
            now_ts = Decimal(str(dt.datetime.now(dt.UTC).timestamp()))

            operations: List[Dict[str, Any]] = [
                # Put new subscription
                {
                    "Put": {
                        "TableName": self.table_name,
                        "Item": new_sub.to_resource_dictionary(),
                    }
                },
                # Expire old subscription
                {
                    "Update": {
                        "TableName": self.table_name,
                        "Key": {"pk": old_pk, "sk": old_sk},
                        "UpdateExpression": "SET #status = :expired, modified_utc_ts = :now",
                        "ExpressionAttributeNames": {"#status": "status"},
                        "ExpressionAttributeValues": {
                            ":expired": "expired",
                            ":now": now_ts,
                        },
                    }
                },
                # Update active pointer
                self._update_active_pointer_operation(
                    tenant_id, new_sub.id, user_id
                ),
            ]

            # 7. Execute transaction
            tx_result = self._execute_transact_write(operations)
            if not tx_result.success:
                return tx_result

            # 8. Return new subscription
            return ServiceResult.success_result(new_sub)

        except Exception as e:
            return self._handle_service_exception(
                e, "renew_subscription", subscription_id=subscription_id
            )

    # ========================================================================
    # NEW: Plan and Addon Integration Methods
    # ========================================================================
    
    @service_method("create_from_plan")

    
    def create_from_plan(
        self,
        plan_id: str,
        plan_code: str,
        plan_name: str,
        price_cents: int,
        seat_count: int = 1,
        billing_interval: str = "month",
        **kwargs
    ) -> ServiceResult[Subscription]:
        """
        Create a subscription from a Plan definition.
        
        This links the tenant subscription to a platform-wide Plan,
        copying pricing and configuration at subscription time.
        
        Args:
            tenant_id: Tenant ID
            user_id: User creating subscription
            plan_id: Reference to subscriptions.Plan.id
            plan_code: Plan code
            plan_name: Plan name
            price_cents: Price in cents
            seat_count: Number of seats
            billing_interval: "month" or "year"
            **kwargs: Additional fields
            
        Returns:
            ServiceResult with Subscription
        """
        payload = {
            "plan_id": plan_id,
            "plan_code": plan_code,
            "plan_name": plan_name,
            "price_cents": price_cents,
            "seat_count": seat_count,
            "billing_interval": billing_interval,
            **kwargs
        }
        
        return self.activate_subscription(tenant_id, user_id, payload)
    
    @service_method("add_addon_to_subscription")

    
    def add_addon_to_subscription(
        self,
        subscription_id: str,
        addon_code: str,
        addon_metadata: Optional[Dict[str, Any]] = None
    ) -> ServiceResult[Subscription]:
        """
        Add an addon to an existing subscription.
        
        Args:
            subscription_id: Subscription ID
            tenant_id: Tenant ID
            user_id: User performing action
            addon_code: Addon code to add
            addon_metadata: Optional addon-specific settings
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            # Get subscription
            result = self.get_by_id(subscription_id, tenant_id, user_id)
            if not result.success:
                return result
            
            subscription = result.data
            
            # Add addon
            subscription.add_addon(addon_code, addon_metadata)
            
            # Update
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1
            
            # Save
            return self._save_model(subscription)
            
        except Exception as e:
            return self._handle_service_exception(
                e, 'add_addon_to_subscription',
                subscription_id=subscription_id, tenant_id=tenant_id
            )
    
    @service_method("remove_addon_from_subscription")

    
    def remove_addon_from_subscription(
        self,
        subscription_id: str,
        addon_code: str
    ) -> ServiceResult[Subscription]:
        """
        Remove an addon from a subscription.
        
        Args:
            subscription_id: Subscription ID
            tenant_id: Tenant ID
            user_id: User performing action
            addon_code: Addon code to remove
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            result = self.get_by_id(subscription_id, tenant_id, user_id)
            if not result.success:
                return result
            
            subscription = result.data
            subscription.remove_addon(addon_code)
            
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1
            
            return self._save_model(subscription)
            
        except Exception as e:
            return self._handle_service_exception(
                e, 'remove_addon_from_subscription',
                subscription_id=subscription_id, tenant_id=tenant_id
            )
    
    @service_method("apply_discount_to_subscription")

    
    def apply_discount_to_subscription(
        self,
        subscription_id: str,
        discount_id: str,
        discount_code: str,
        discount_amount_cents: int
    ) -> ServiceResult[Subscription]:
        """
        Apply a discount to a subscription.
        
        Args:
            subscription_id: Subscription ID
            tenant_id: Tenant ID
            user_id: User performing action
            discount_id: Reference to subscriptions.Discount.id
            discount_code: Discount code
            discount_amount_cents: Discount amount per period
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            result = self.get_by_id(subscription_id, tenant_id, user_id)
            if not result.success:
                return result
            
            subscription = result.data
            subscription.apply_discount(discount_id, discount_code, discount_amount_cents)
            
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1
            
            return self._save_model(subscription)
            
        except Exception as e:
            return self._handle_service_exception(
                e, 'apply_discount_to_subscription',
                subscription_id=subscription_id, tenant_id=tenant_id
            )
    
    @service_method("remove_discount_from_subscription")

    
    def remove_discount_from_subscription(
        self,
        subscription_id: str
    ) -> ServiceResult[Subscription]:
        """
        Remove discount from a subscription.
        
        Args:
            subscription_id: Subscription ID
            tenant_id: Tenant ID
            user_id: User performing action
            
        Returns:
            ServiceResult with updated Subscription
        """
        try:
            result = self.get_by_id(subscription_id, tenant_id, user_id)
            if not result.success:
                return result
            
            subscription = result.data
            subscription.remove_discount()
            
            subscription.updated_by_id = user_id
            subscription.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()
            subscription.version += 1
            
            return self._save_model(subscription)
            
        except Exception as e:
            return self._handle_service_exception(
                e, 'remove_discount_from_subscription',
                subscription_id=subscription_id, tenant_id=tenant_id
            )
