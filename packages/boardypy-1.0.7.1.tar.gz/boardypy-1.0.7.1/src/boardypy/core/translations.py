﻿from __future__ import annotations

from typing import Any

from ..paths import APP_VERSION

# ---------------------------------------------------------------------------
# Translation dictionaries
# ---------------------------------------------------------------------------

_STRINGS: dict[str, dict[str, str]] = {
    # ---- Main window ----
    "app_title":                {"en": "BoardyPy — MicroPython IDE",       "ru": "BoardyPy — MicroPython IDE"},
    "ready":                    {"en": "Ready",                             "ru": "Готово"},
    "no_device_connected":      {"en": "No device connected",              "ru": "Устройство не подключено"},

    # ---- Menus ----
    "menu_file":                {"en": "&File",                             "ru": "&Файл"},
    "menu_edit":                {"en": "&Edit",                             "ru": "&Редактирование"},
    "menu_view":                {"en": "&View",                             "ru": "&Вид"},
    "menu_device":              {"en": "&Device",                           "ru": "&Устройство"},
    "menu_run":                 {"en": "&Run",                              "ru": "&Запуск"},
    "menu_settings":            {"en": "&Settings",                         "ru": "&Настройки"},
    "menu_tools":               {"en": "&Tools",                            "ru": "&Инструменты"},
    "menu_help":                {"en": "&Help",                             "ru": "&Помощь"},

    # File menu
    "action_new":               {"en": "&New",                              "ru": "&Новый"},
    "action_open":              {"en": "&Open...",                          "ru": "&Открыть..."},
    "action_save":              {"en": "&Save",                             "ru": "&Сохранить"},
    "action_save_as":           {"en": "Save &As...",                       "ru": "Сохранить &как..."},
    "action_close_tab":         {"en": "&Close Tab",                        "ru": "&Закрыть вкладку"},
    "action_exit":              {"en": "E&xit",                             "ru": "В&ыход"},

    # Edit menu
    "action_undo":              {"en": "&Undo",                             "ru": "&Отменить"},
    "action_redo":              {"en": "&Redo",                             "ru": "&Повторить"},
    "action_cut":               {"en": "Cu&t",                              "ru": "&Вырезать"},
    "action_copy":              {"en": "&Copy",                             "ru": "&Копировать"},
    "action_paste":             {"en": "&Paste",                            "ru": "Вст&авить"},
    "action_select_all":        {"en": "Select &All",                       "ru": "Выделить вс&ё"},
    "action_find":              {"en": "&Find",                             "ru": "&Найти"},

    # View menu
    "action_toggle_console":    {"en": "Toggle &Console",                   "ru": "Показать/скрыть &консоль"},
    "action_toggle_explorer":   {"en": "Toggle &File Explorer",             "ru": "Показать/скрыть &проводник"},
    "action_zoom_in":           {"en": "Zoom &In",                          "ru": "&Увеличить масштаб"},
    "action_zoom_out":          {"en": "Zoom &Out",                         "ru": "У&меньшить масштаб"},
    "action_reset_zoom":        {"en": "&Reset Zoom",                       "ru": "&Сбросить масштаб"},

    # Device menu
    "action_select_port":       {"en": "&Select Port...",                   "ru": "&Выбрать порт..."},
    "action_refresh_ports":     {"en": "&Refresh Ports",                    "ru": "&Обновить порты"},
    "action_connect":           {"en": "&Connect",                          "ru": "&Подключить"},
    "action_disconnect":        {"en": "&Disconnect",                       "ru": "&Отключить"},

    # Run menu
    "action_run_script":        {"en": "&Run Script",                       "ru": "&Запустить скрипт"},
    "action_stop_execution":    {"en": "&Stop Execution",                   "ru": "&Остановить выполнение"},

    # Settings menu
    "menu_theme":               {"en": "&Theme",                            "ru": "&Тема"},
    "action_font_size":         {"en": "&Font Size...",                     "ru": "&Размер шрифта..."},
    "action_auto_save":         {"en": "&Auto Save",                        "ru": "&Автосохранение"},
    "action_syntax_highlight":  {"en": "&Syntax Highlighting",               "ru": "&Подсветка синтаксиса"},
    "menu_language":            {"en": "&Language",                          "ru": "&Язык"},
    "lang_russian":             {"en": "Russian",                           "ru": "Русский"},
    "lang_english":             {"en": "English",                           "ru": "Английский"},

    # Help menu
    "action_about":             {"en": "&About",                            "ru": "&О программе"},
    "action_web_search":        {"en": "Yandex &Search",                    "ru": "Яндекс &Поиск"},

    # ---- About dialog ----
    "about_title":              {"en": "About BoardyPy",                    "ru": "О программе BoardyPy"},
    "about_description":        {"en": f"<p>Professional MicroPython IDE.</p>"
                               f"<p><b>Version:</b> {APP_VERSION}</p>",
                                 "ru": f"<p>Профессиональная IDE для MicroPython.</p>"
                               f"<p><b>Версия:</b> {APP_VERSION}</p>"},
    "about_creator":            {"en": "<b>Creator:</b> @Timon2306<br>"
                                       "Student of group И24-11<br>"
                                       "ГПОУ ПК, Novokuznetsk<br>"
                                       "named after T.A. Kucheryavenko",
                                 "ru": "<b>Создатель:</b> @Timon2306<br>"
                                       "Студент группы И24-11<br>"
                                       "ГПОУ ПК г. Новокузнецка<br>"
                                       "им. Кучерявенко Т.А."},
    "about_support":            {"en": "Support — Telegram",
                                 "ru": "Поддержка — Telegram"},
    "about_patchnotes_btn":     {"en": "What's New",
                                 "ru": "Что нового"},
    "about_patchnotes_title":   {"en": f"What's New — v{APP_VERSION}",
                                 "ru": f"Что нового — v{APP_VERSION}"},
    "about_patchnotes":         {"en": f"<h3>Version {APP_VERSION}</h3>"
                                       "<ul>"
                                       "<li>The update dialog now offers an Update button that installs the new version through pip</li>"
                                       "<li>BoardyPy now closes before self-update and restarts automatically after a successful install</li>"
                                       "<li>If the update fails, the next launch shows the details instead of silently ignoring the problem</li>"
                                       "<li>Packaging and release files were cleaned up for a tidier PyPI build</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.6</h3>"
                                       "<ul>"
                                       "<li>Library Manager now offers a choice between .py and .mpy for each library</li>"
                                       "<li>Installing a library now replaces an older file with the same base name even if one is .py and the other is .mpy</li>"
                                       "<li>Library uploads to ESP8266 were reworked to be more reliable with larger files and noticeably faster</li>"
                                       "<li>Removed the extra console error when /lib already exists during library installation</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.5</h3>"
                                       "<ul>"
                                       "<li>Automatic device connection on startup when a controller is detected</li>"
                                       "<li>Added update check on startup with a download button and version ignore option</li>"
                                       "<li>Crash/session recovery improved: unsaved tabs are restored after restart</li>"
                                       "<li>Toolbar is adaptive in small windows and keeps the main actions visible</li>"
                                       "<li>Device storage panel got improved navigation and the library catalogue was expanded</li>"
                                       "<li>Russian UI labels and text encoding issues were cleaned up</li>"
                                       "<li>Added search in the editor with Ctrl+F, next/previous navigation and match counter</li>"
                                       "<li>Search now opens as a compact popup in the top-right corner of the editor</li>"
                                       "<li>Added code folding buttons near line numbers for functions, loops and other indented blocks</li>"
                                       "<li>Editor indent guides were refined for a cleaner and more readable look</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.4</h3>"
                                       "<ul>"
                                       "<li>Auto-detects the serial device port on connect — prefers CH340/CP210x/FTDI chips and /dev/ttyUSB* on Linux; manual selection always available</li>"
                                       "<li>Extended syntax highlighting: f-strings, b-strings, __dunder__ names, exception classes, -&gt; type annotations, *args/**kwargs — each in a distinct color</li>"
                                       "<li>Special comment colors: #! warning (red bold), ## section header (yellow bold), plain # with TODO/FIXME/NOTE accent</li>"
                                       "<li>Syntax highlighting toggle added to Settings menu (on by default)</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.2</h3>"
                                       "<ul>"
                                       "<li>Priority run: open script runs by its file path (__file__ works, relative imports work)</li>"
                                       "<li>Binary file viewer: .mpy, .bin, .hex files open as hex dump</li>"
                                       "<li>File explorer now shows all file types</li>"
                                       "<li>Library Manager: install bundled MicroPython libraries to device with one click</li>"
                                       "<li>Fixed line number vertical alignment in editor</li>"
                                       "<li>Linux desktop shortcut: run install_desktop.sh once for double-click launch</li>"
                                       "</ul>"
                                       "<h3>Version 1.0.1</h3>"
                                       "<ul>"
                                       "<li>Migrated from PyQt6 to PyQt5 (Python 3.9 / ALT Linux 10.4 support)</li>"
                                       "<li>Dark theme is now the default</li>"
                                       "<li>Fixed print() output in the console (separate line, correct colors)</li>"
                                       "<li>Adaptive console colors when switching themes</li>"
                                       "<li>Reduced line spacing in the console</li>"
                                       "<li>Language switching without restart</li>"
                                       "</ul>",
                                   "ru": f"<h3>Версия {APP_VERSION}</h3>"
                                       "<ul>"
                                       "<li>В окне обновления кнопка «Обновить» теперь ставит новую версию напрямую через pip</li>"
                                       "<li>Перед автообновлением BoardyPy закрывается, а после успешной установки запускается снова автоматически</li>"
                                       "<li>Если обновление не удалось, при следующем запуске показываются подробности ошибки</li>"
                                       "<li>Подчищена структура проекта и файлы сборки для более аккуратного релиза на PyPI</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.6</h3>"
                                       "<ul>"
                                       "<li>Менеджер библиотек теперь предлагает выбор формата .py или .mpy для каждой библиотеки</li>"
                                       "<li>При установке библиотека заменяет старый файл с тем же именем, даже если расширение отличается (.py/.mpy)</li>"
                                       "<li>Загрузка библиотек на ESP8266 переработана: большие файлы передаются надёжнее и заметно быстрее</li>"
                                       "<li>Убрана лишняя ошибка в консоли, если папка /lib уже существует во время установки библиотеки</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.5</h3>"
                                       "<ul>"
                                       "<li>Добавлено автоподключение к контроллеру при запуске, если устройство найдено</li>"
                                       "<li>Добавлена проверка обновлений при старте с кнопкой перехода к скачиванию и возможностью скрыть эту версию</li>"
                                       "<li>Улучшено восстановление сессии после сбоя: несохранённые вкладки возвращаются после перезапуска</li>"
                                       "<li>Тулбар стал адаптивнее в маленьком окне и лучше сохраняет основные кнопки</li>"
                                       "<li>Доработана навигация по хранилищу контроллера и расширен каталог библиотек</li>"
                                       "<li>Исправлены проблемы кодировки и русских подписей в интерфейсе</li>"
                                       "<li>Добавлен поиск в редакторе по Ctrl+F с переходом вперёд/назад и счётчиком совпадений</li>"
                                       "<li>Окно поиска теперь открывается как компактное всплывающее меню справа сверху в редакторе</li>"
                                       "<li>Добавлены кнопки сворачивания кода рядом с номерами строк для функций, циклов и других блоков</li>"
                                       "<li>Подправлена визуализация направляющих табуляции в редакторе</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.4</h3>"
                                       "<ul>"
                                       "<li>Добавлено автоопределение COM-порта при подключении устройства (ручной выбор по-прежнему доступен)</li>"
                                       "<li>Расширена подсветка синтаксиса для MicroPython и популярных библиотек</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.2</h3>"
                                       "<ul>"
                                       "<li>Приоритет запуска: открытый скрипт запускается по пути файла (__file__ работает, импорты работают)</li>"
                                       "<li>Просмотр бинарных файлов: .mpy, .bin, .hex открываются как hex-дамп</li>"
                                       "<li>Проводник теперь показывает все типы файлов</li>"
                                       "<li>Менеджер библиотек: установка встроенных MicroPython библиотек на устройство нажатием одной кнопки</li>"
                                       "<li>Исправлено вертикальное выравнивание номеров строк в редакторе</li>"
                                       "<li>Ярлык для Linux: запусти install_desktop.sh один раз для запуска двойным кликом</li>"
                                       "</ul>"
                                       "<h3>Версия 1.0.1</h3>"
                                       "<ul>"
                                       "<li>Переход с PyQt6 на PyQt5 (поддержка Python 3.9 / ALT Linux 10.4)</li>"
                                       "<li>Тёмная тема по умолчанию</li>"
                                       "<li>Исправлен вывод print() в консоли (отдельная строка, корректные цвета)</li>"
                                       "<li>Адаптивные цвета консоли при смене темы</li>"
                                       "<li>Уменьшены промежутки между строками в консоли</li>"
                                       "<li>Смена языка без перезапуска</li>"
                                       "</ul>"},

    # ---- Port dialog ----
    "port_dialog_title":        {"en": "Select Serial Port",               "ru": "Выбор COM-порта"},
    "port_label":               {"en": "Port:",                             "ru": "Порт:"},
    "port_no_ports":            {"en": "(no ports found)",                  "ru": "(порты не найдены)"},
    "port_btn_connect":         {"en": "Connect",                           "ru": "Подключить"},
    "port_btn_cancel":          {"en": "Cancel",                            "ru": "Отмена"},

    # ---- Status bar / messages ----
    "status_port":              {"en": "Port: {port}",                      "ru": "Порт: {port}"},
    "status_selected_port":     {"en": "Selected port: {port}",            "ru": "Выбран порт: {port}"},
    "status_available_ports":   {"en": "Available ports: {ports}",         "ru": "Доступные порты: {ports}"},
    "status_no_ports":          {"en": "No serial ports found.",           "ru": "Последовательные порты не найдены."},
    "status_already_connected": {"en": "Already connected.",               "ru": "Уже подключено."},
    "status_not_connected":     {"en": "Not connected.",                   "ru": "Не подключено."},
    "status_connected":         {"en": "Connected: {port} @ {baud}",      "ru": "Подключено: {port} @ {baud}"},
    "status_connected_to":      {"en": "Connected to {port}",             "ru": "Подключено к {port}"},
    "status_connected_baud":    {"en": "Connected to {port} at {baud} baud.", "ru": "Подключено к {port} на скорости {baud} бод."},
    "status_disconnected":      {"en": "Disconnected",                     "ru": "Отключено"},
    "status_disconnected_err":  {"en": "Disconnected (error)",             "ru": "Отключено (ошибка)"},
    "status_device_disconnected": {"en": "Device disconnected.",           "ru": "Устройство отключено."},

    # ---- Errors / warnings ----
    "err_no_ports_title":       {"en": "No Ports",                         "ru": "Нет портов"},
    "err_no_ports_msg":         {"en": "No serial ports found. Connect a device first.",
                                 "ru": "Последовательные порты не найдены. Сначала подключите устройство."},
    "err_connection_title":     {"en": "Connection Error",                 "ru": "Ошибка подключения"},
    "err_connection_failed":    {"en": "Connection failed: {err}",         "ru": "Не удалось подключиться: {err}"},
    "err_not_connected_title":  {"en": "Not Connected",                    "ru": "Нет подключения"},
    "err_not_connected_msg":    {"en": "Please connect to a MicroPython device first.",
                                 "ru": "Сначала подключитесь к устройству MicroPython."},
    "err_not_connected_send":   {"en": "Not connected to any device.",     "ru": "Нет подключения к устройству."},
    "err_serial":               {"en": "Serial error: {err}",             "ru": "Ошибка порта: {err}"},
    "err_run":                  {"en": "Run error: {err}",                "ru": "Ошибка запуска: {err}"},
    "err_send":                 {"en": "Send error: {err}",               "ru": "Ошибка отправки: {err}"},
    "err_stop":                 {"en": "Stop error: {err}",               "ru": "Ошибка остановки: {err}"},

    # ---- Updates ----
    "update_available_title":   {"en": "Update Available",                "ru": "Доступно обновление"},
    "update_available_text":    {"en": "A new version {version} is available.",
                                 "ru": "Доступна новая версия {version}."},
    "update_available_notes":   {"en": "Changes in this version:\n{notes}",
                                 "ru": "Изменения в этой версии:\n{notes}"},
    "update_auto_hint":         {"en": "BoardyPy will close, install the update, and then restart automatically.",
                                 "ru": "BoardyPy закроется, установит обновление и затем запустится снова автоматически."},
    "update_download":          {"en": "Update",                          "ru": "Обновить"},
    "update_later":             {"en": "Later",                           "ru": "Позже"},
    "update_ignore":            {"en": "Don't show again",                "ru": "Не показывать"},
    "update_auto_connected":    {"en": "Automatic device connection completed.",
                                 "ru": "Автоподключение к устройству выполнено."},
    "update_installing":        {"en": "Closing BoardyPy and starting update…",
                                 "ru": "BoardyPy закрывается и запускает обновление…"},
    "update_installing_short":  {"en": "Updating…",
                                 "ru": "Обновление…"},
    "update_failed_title":      {"en": "Update Failed",
                                 "ru": "Не удалось обновить"},
    "update_failed_text":       {"en": "BoardyPy could not update itself automatically.",
                                 "ru": "BoardyPy не смог обновиться автоматически."},
    "update_failed_hint":       {"en": "You can open the details below or update BoardyPy manually with pip.",
                                 "ru": "Открой подробности ниже или обнови BoardyPy вручную через pip."},
    "update_start_failed":      {"en": "Could not start the update process: {err}",
                                 "ru": "Не удалось запустить процесс обновления: {err}"},

    # ---- Run messages ----
    "run_nothing":              {"en": "Nothing to run — editor is empty.", "ru": "Нечего запускать — редактор пуст."},
    "run_script_sent":          {"en": ">>> Script sent to device.",       "ru": ">>> Скрипт отправлен на устройство."},
    "run_stopped":              {"en": ">>> Execution stopped (CTRL+C sent).", "ru": ">>> Выполнение остановлено (CTRL+C отправлен)."},

    # ---- Font size dialog ----
    "font_size_title":          {"en": "Font Size",                        "ru": "Размер шрифта"},
    "font_size_prompt":         {"en": "Enter font size (6–36):",          "ru": "Введите размер шрифта (6–36):"},

    # ---- Console ----
    "console_title":            {"en": "Console / REPL",                   "ru": "Консоль / REPL"},
    "console_placeholder":      {"en": "Type command and press Enter...",  "ru": "Введите команду и нажмите Enter..."},
    "console_clear":            {"en": "Clear",                            "ru": "Очистить"},
    "console_device_connected": {"en": "Device connected",                 "ru": "Устройство подключено"},
    "console_device_disconnected": {"en": "Device disconnected",           "ru": "Устройство отключено"},

    # ---- File explorer ----
    "explorer_title":           {"en": "PC — File Explorer",               "ru": "ПК — Проводник"},
    "explorer_open_folder":     {"en": "Open Folder",                      "ru": "Открыть папку"},
    "explorer_go_home":         {"en": "Go to Home",                       "ru": "Домашняя папка"},
    "explorer_select_folder":   {"en": "Select Folder",                    "ru": "Выберите папку"},

    # ---- Editor dialogs ----
    "editor_error":             {"en": "Error",                            "ru": "Ошибка"},
    "editor_cannot_open":       {"en": "Cannot open file:\n{err}",        "ru": "Не удалось открыть файл:\n{err}"},
    "editor_cannot_save":       {"en": "Cannot save file:\n{err}",        "ru": "Не удалось сохранить файл:\n{err}"},
    "editor_save_as":           {"en": "Save As",                          "ru": "Сохранить как"},
    "editor_open_file":         {"en": "Open File",                        "ru": "Открыть файл"},
    "editor_unsaved_title":     {"en": "Unsaved Changes",                  "ru": "Несохранённые изменения"},
    "editor_unsaved_msg":       {"en": "'{name}' has unsaved changes. Save before closing?",
                                 "ru": "'{name}' содержит несохранённые изменения. Сохранить перед закрытием?"},
    "editor_py_filter":         {"en": "Python Files (*.py);;All Files (*)",
                                 "ru": "Файлы Python (*.py);;Все файлы (*)"},
    "editor_find_placeholder":  {"en": "Find in current file",             "ru": "Поиск в текущем файле"},
    "editor_find_prev":         {"en": "Find previous",                    "ru": "Найти предыдущее"},
    "editor_find_next":         {"en": "Find next",                        "ru": "Найти следующее"},
    "editor_find_close":        {"en": "Close search",                     "ru": "Закрыть поиск"},

    # ---- Language restart ----
    "lang_restart_title":       {"en": "Restart Required",                 "ru": "Требуется перезапуск"},
    "lang_restart_msg":         {"en": "Language will change after restarting the application.",
                                 "ru": "Язык будет изменён после перезапуска приложения."},

    # ---- Toolbar tooltips ----
    "tb_new":                   {"en": "New File",                         "ru": "Новый файл"},
    "tb_open":                  {"en": "Open File",                        "ru": "Открыть файл"},
    "tb_save":                  {"en": "Save",                             "ru": "Сохранить"},
    "tb_run":                   {"en": "Run (F5)",                         "ru": "Запустить (F5)"},
    "tb_stop":                  {"en": "Stop (F6)",                        "ru": "Остановить (F6)"},
    "tb_restart":               {"en": "Restart",                          "ru": "Перезапустить"},
    "tb_connect":               {"en": "Connect Device",                   "ru": "Подключить устройство"},
    "tb_disconnect":            {"en": "Disconnect Device",                "ru": "Отключить устройство"},
    "web_search_placeholder":   {"en": "Search in Yandex...",              "ru": "Поиск в Яндексе..."},
    "web_search_tooltip":       {"en": "Type a query and press Enter to open Yandex Search in your browser. The URL includes the clid parameter.",
                                 "ru": "Введите запрос и нажмите Enter, чтобы открыть Яндекс Поиск во внешнем браузере. В URL используется параметр clid."},
    "web_search_button":        {"en": "Yandex",                           "ru": "Яндекс"},
    "web_search_empty":         {"en": "Enter a search query.",            "ru": "Введите поисковый запрос."},
    "web_search_opened":        {"en": "Yandex Search opened in your browser.",
                                 "ru": "Яндекс Поиск открыт в браузере."},
    "web_search_failed":        {"en": "Could not open the browser.",      "ru": "Не удалось открыть браузер."},

    # ---- Run menu additions ----
    "action_run_local":         {"en": "&Run Locally",                     "ru": "&Запустить локально"},
    "action_run_on_device":     {"en": "Run on &Device",                   "ru": "Запустить на &устройстве"},
    "action_restart":           {"en": "&Restart",                         "ru": "&Перезапустить"},
    "run_restarting":           {"en": ">>> Restarting script...",         "ru": ">>> Перезапуск скрипта..."},

    # ---- Local run messages ----
    "run_local_started":        {"en": ">>> Running script locally...",    "ru": ">>> Запуск скрипта локально..."},
    "run_local_finished":       {"en": ">>> Script finished (exit code {code}).", "ru": ">>> Скрипт завершён (код выхода {code})."},
    "run_local_error":          {"en": "Local run error: {err}",           "ru": "Ошибка локального запуска: {err}"},
    "run_local_stopped":        {"en": ">>> Local script stopped.",        "ru": ">>> Локальный скрипт остановлен."},
    "run_local_nothing":        {"en": "Nothing to run — editor is empty.", "ru": "Нечего запускать — редактор пуст."},
    "status_running_local":     {"en": "Running locally...",               "ru": "Выполняется локально..."},

    # ---- Console always-on ----
    "console_local_placeholder": {"en": "Type Python or command...",       "ru": "Введите Python-код или команду..."},

    # ---- Device file explorer ----
    "devexp_title":             {"en": "Controller Storage",               "ru": "Хранилище контроллера"},
    "devexp_refresh":           {"en": "Refresh",                          "ru": "Обновить"},
    "devexp_go_up":             {"en": "Go Up",                            "ru": "Наверх"},
    "devexp_upload":            {"en": "Upload",                           "ru": "Загрузить"},
    "devexp_upload_tip":        {"en": "Upload file to device",            "ru": "Загрузить файл на устройство"},
    "devexp_upload_title":      {"en": "Select file to upload",            "ru": "Выберите файл для загрузки"},
    "devexp_mkdir":             {"en": "New Folder",                       "ru": "Новая папка"},
    "devexp_mkdir_tip":         {"en": "Create folder on device",          "ru": "Создать папку на устройстве"},
    "devexp_mkdir_title":       {"en": "New Folder",                       "ru": "Новая папка"},
    "devexp_mkdir_prompt":      {"en": "Folder name:",                     "ru": "Имя папки:"},
    "devexp_download":          {"en": "Download",                         "ru": "Скачать"},
    "devexp_delete":            {"en": "Delete",                           "ru": "Удалить"},
    "devexp_delete_title":      {"en": "Delete",                           "ru": "Удаление"},
    "devexp_delete_confirm":    {"en": "Delete '{name}' from device?",     "ru": "Удалить '{name}' с устройства?"},
    "devexp_save_as":           {"en": "Save file as",                     "ru": "Сохранить файл как"},
    "devexp_not_connected":     {"en": "Device not connected",             "ru": "Устройство не подключено"},
    "devexp_connected":         {"en": "Device connected — loading…",      "ru": "Устройство подключено — загрузка…"},
    "devexp_items_count":       {"en": "{count} items",                    "ru": "Элементов: {count}"},
    "devexp_uploading":         {"en": "Uploading {name}…",                "ru": "Загрузка {name}…"},
    "devexp_file_opened":       {"en": "Opened from device: {name}",       "ru": "Открыт с устройства: {name}"},
    "devexp_downloading":       {"en": "Downloading {name}…",              "ru": "Скачивание {name}…"},
    "devexp_uploaded":          {"en": "{name} uploaded ✓",                "ru": "{name} загружен ✓"},
    "devexp_downloaded":        {"en": "{name} saved ✓",                   "ru": "{name} сохранён ✓"},
    "devexp_dir_created":       {"en": "Folder created ✓",                 "ru": "Папка создана ✓"},
    "devexp_deleted":           {"en": "Deleted ✓",                        "ru": "Удалено ✓"},
    "devexp_col_name":          {"en": "Name",                             "ru": "Имя"},
    "devexp_col_size":          {"en": "Size",                             "ru": "Размер"},
    "devexp_col_type":          {"en": "Type",                             "ru": "Тип"},
    "action_toggle_devexp":     {"en": "Toggle &Device Storage",           "ru": "Показать/скрыть &хранилище контроллера"},
    "explorer_upload_to_device":{"en": "Upload to device",                 "ru": "Загрузить на устройство"},

    # ---- Library Manager ----
    "menu_libraries":           {"en": "&Libraries",                        "ru": "&Библиотеки"},
    "action_lib_manager":       {"en": "📦 &MicroPython Libraries...",       "ru": "📦 &Библиотеки MicroPython..."},
    "libmgr_title":             {"en": "MicroPython Library Manager",       "ru": "Менеджер библиотек MicroPython"},
    "libmgr_header":            {"en": "Bundled libraries for ESP8266 / MicroPython. "
                                       "Select a library to view description and install it to the device /lib/ folder.",
                                 "ru": "Встроенные библиотеки для ESP8266 / MicroPython. "
                                       "Выбери библиотеку, посмотри описание и установи её в папку /lib/ на устройстве."},
    "libmgr_view":              {"en": "View source",                       "ru": "Посмотреть код"},
    "libmgr_install_device":    {"en": "Install to device /lib/",           "ru": "Установить на устройство /lib/"},
    "libmgr_install_tip":       {"en": "Upload selected library to /lib/ on the connected device",
                                 "ru": "Загрузить выбранную библиотеку в папку /lib/ на подключённом устройстве"},
    "libmgr_formats_line":      {"en": "Available formats: {formats}",
                                 "ru": "Доступные форматы: {formats}"},
    "libmgr_format_title":      {"en": "Choose Library Format",             "ru": "Выбор формата библиотеки"},
    "libmgr_format_msg":        {"en": "Choose how to install '{name}' to the device.",
                                 "ru": "Выбери, в каком формате установить '{name}' на устройство."},
    "libmgr_format_hint":       {"en": ".py: {py_status}\n.mpy: {mpy_status}\n\n"
                                       ".py is more compatible, .mpy is usually smaller but may not work on some firmware.",
                                 "ru": ".py: {py_status}\n.mpy: {mpy_status}\n\n"
                                       ".py совместимее, .mpy обычно меньше по размеру, но поддерживается не всеми прошивками."},
    "libmgr_format_py":         {"en": "Install .py",                       "ru": "Установить .py"},
    "libmgr_format_mpy":        {"en": "Install .mpy",                      "ru": "Установить .mpy"},
    "libmgr_format_missing":    {"en": "not available",                     "ru": "нет в комплекте"},
    "libmgr_format_size":       {"en": "{size} bytes",                      "ru": "{size} байт"},
    "libmgr_install_ok_title":  {"en": "Library Queued",                   "ru": "Библиотека в очереди"},
    "libmgr_install_ok_msg":    {"en": "'{name}' will be uploaded to {path}.\n"
                                       "Check console for progress.",
                                 "ru": "'{name}' будет загружена в {path}.\n"
                                       "Прогресс — в консоли."},
    "tb_libraries":             {"en": "Libraries",                         "ru": "Библиотеки"},
}


# ---------------------------------------------------------------------------
# Current language state
# ---------------------------------------------------------------------------

_current_lang: str = "ru"


def set_language(lang: str) -> None:
    """Set the active language ('en' or 'ru')."""
    global _current_lang
    _current_lang = lang if lang in ("en", "ru") else "ru"


def get_language() -> str:
    return _current_lang


def tr(key: str, **kwargs: Any) -> str:
    """Return translated string by key. Supports {placeholder} formatting."""
    entry = _STRINGS.get(key)
    if entry is None:
        return key
    text = entry.get(_current_lang, entry.get("en", key))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, IndexError):
            pass
    return text

