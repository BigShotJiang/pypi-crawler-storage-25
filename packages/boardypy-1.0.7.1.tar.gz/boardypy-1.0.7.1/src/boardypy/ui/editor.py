from __future__ import annotations

import os
import re
from typing import Optional

from PyQt5.QtCore import Qt, QRect, QSize, pyqtSignal, QRegularExpression
from PyQt5.QtGui import QColor, QFont, QFontMetrics, QIcon, QKeyEvent, QPaintEvent, QPainter, QPalette, QResizeEvent, QSyntaxHighlighter, QTextCharFormat, QTextCursor, QTextDocument
from PyQt5.QtWidgets import QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QTabWidget, QTextEdit, QWidget

from ..core.translations import tr


class PythonHighlighter(QSyntaxHighlighter):
    _DQ3 = 1
    _SQ3 = 2

    def __init__(self, document: QTextDocument, dark: bool = False) -> None:
        super().__init__(document)
        self._dark = dark
        self._enabled = True
        self._rules: list[tuple[QRegularExpression, QTextCharFormat]] = []
        self._comment_fmt = QTextCharFormat()
        self._todo_fmt = QTextCharFormat()
        self._warn_fmt = QTextCharFormat()
        self._sect_fmt = QTextCharFormat()
        self._str_fmt = QTextCharFormat()
        self._build_rules()

    def _fmt(self, color: str, bold: bool = False, italic: bool = False) -> QTextCharFormat:
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        if bold:
            fmt.setFontWeight(700)
        if italic:
            fmt.setFontItalic(True)
        return fmt

    def _add_words(self, words: list[str], fmt: QTextCharFormat) -> None:
        for word in words:
            self._rules.append((QRegularExpression(rf"\b{word}\b"), fmt))

    def _build_rules(self) -> None:
        self._rules.clear()
        dark = self._dark
        colors = {
            "kw": "#569cd6" if dark else "#0000ff",
            "built": "#4ec9b0" if dark else "#267f99",
            "str": "#ce9178" if dark else "#a31515",
            "comment": "#6a9955" if dark else "#008000",
            "num": "#d19a66" if dark else "#b36b00",
            "func": "#dcdcaa" if dark else "#795e26",
            "cls": "#4ec9b0" if dark else "#267f99",
            "self": "#9cdcfe" if dark else "#001080",
            "dec": "#c586c0" if dark else "#af00db",
            "op": "#d4d4d4" if dark else "#383838",
            "module": "#c586c0" if dark else "#8b008b",
            "method": "#60a5fa" if dark else "#005cc5",
            "bracket": "#7fb069" if dark else "#2f855a",
            "todo": "#e5c07b" if dark else "#b8860b",
            "warn": "#f44747" if dark else "#cc0000",
            "ann": "#00d8d8" if dark else "#007080",
            "exc": "#f08840" if dark else "#b83800",
        }
        keywords = ["False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"]
        builtins = ["abs", "all", "any", "bin", "bool", "bytearray", "bytes", "callable", "chr", "compile", "complex", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip"]
        modules = ["ADC", "AP_IF", "DAC", "I2C", "PWM", "Pin", "RTC", "SPI", "STA_IF", "Signal", "Timer", "UART", "WDT", "WLAN", "btree", "dht", "ds18x20", "esp", "esp32", "framebuf", "gc", "json", "lcd_api", "lvgl", "machine", "micropython", "mfrc522", "network", "neopixel", "onewire", "os", "rp2", "socket", "ssd1306", "st7735", "st7789", "st7789py", "sys", "tft", "tft_config", "time", "ubinascii", "uerrno", "ujson", "uos", "ure", "usocket", "ustruct", "usys", "utime", "wifi_helper"]
        methods = ["active", "angle", "atten", "bind", "blit", "brightness", "clear", "close", "collect", "connect", "convert_temp", "deinit", "detach", "duty", "duty_u16", "feed", "fill", "fill_rect", "freq", "get_weight", "high", "ifconfig", "init", "irq", "isconnected", "listen", "low", "measure", "mem_alloc", "mem_free", "mkdir", "move_to", "off", "on", "open", "pixel", "putchar", "putstr", "read", "read_temp", "readfrom", "readfrom_mem", "readinto", "readline", "recv", "request", "reset", "scan", "send", "set_scale", "show", "sleep", "sleep_ms", "sleep_us", "start", "step", "stop", "sync", "tare", "text", "toggle", "value", "write", "write_angle", "writeto", "writeto_mem"]
        exceptions = ["AssertionError", "AttributeError", "BaseException", "Exception", "FileNotFoundError", "IOError", "ImportError", "IndexError", "KeyError", "MemoryError", "NameError", "NotImplementedError", "OSError", "OverflowError", "RecursionError", "RuntimeError", "StopIteration", "SyntaxError", "TypeError", "UnicodeDecodeError", "UnicodeEncodeError", "UnicodeError", "ValueError", "ZeroDivisionError"]
        self._add_words(keywords, self._fmt(colors["kw"], True))
        self._add_words(builtins, self._fmt(colors["built"]))
        self._add_words(modules, self._fmt(colors["module"], True))
        self._add_words(methods, self._fmt(colors["method"], True))
        self._add_words(exceptions, self._fmt(colors["exc"]))
        extra = [
            (r"\b__\w+__\b", self._fmt(colors["module"], True)),
            (r"\b(self|cls)\b", self._fmt(colors["self"])),
            (r"@\w+", self._fmt(colors["dec"])),
            (r"\b[0-9]+\.?[0-9]*([eE][+-]?[0-9]+)?\b", self._fmt(colors["num"], True)),
            (r"\b0[xX][0-9A-Fa-f]+\b", self._fmt(colors["num"], True)),
            (r"\b0[bB][01]+\b", self._fmt(colors["num"], True)),
            (r"\b0[oO][0-7]+\b", self._fmt(colors["num"], True)),
            (r"[+\-*/%=<>!&|^~]+", self._fmt(colors["op"])),
            (r"\->", self._fmt(colors["ann"], True)),
            (r"\*{1,2}[A-Za-z_]\w*", self._fmt(colors["module"])),
            (r"\bdef\s+(\w+)", self._fmt(colors["func"], True)),
            (r"\bclass\s+(\w+)", self._fmt(colors["cls"], True)),
            (r"'[^'\\]*(\\.[^'\\]*)*'", self._fmt(colors["str"])),
            (r'"[^"\\]*(\\.[^"\\]*)*"', self._fmt(colors["str"])),
            (r'f"[^"\\]*(\\.[^"\\]*)*"', self._fmt(colors["str"])),
            (r"f'[^'\\]*(\\.[^'\\]*)*'", self._fmt(colors["str"])),
            (r'b"[^"\\]*(\\.[^"\\]*)*"', self._fmt(colors["built"])),
            (r"b'[^'\\]*(\\.[^'\\]*)*'", self._fmt(colors["built"])),
            (r"[()\[\]{}]", self._fmt(colors["bracket"], True)),
        ]
        for pattern, fmt in extra:
            self._rules.append((QRegularExpression(pattern), fmt))
        self._comment_fmt = self._fmt(colors["comment"], italic=True)
        self._todo_fmt = self._fmt(colors["todo"], True, True)
        self._warn_fmt = self._fmt(colors["warn"], True)
        self._sect_fmt = self._fmt(colors["todo"], True)
        self._str_fmt = self._fmt(colors["str"])
        self._rules.append((QRegularExpression(r"#[^\n]*"), self._comment_fmt))

    def update_theme(self, dark: bool) -> None:
        self._dark = dark
        self._build_rules()
        self.rehighlight()

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        self.rehighlight()

    def highlightBlock(self, text: str) -> None:  # type: ignore[override]
        if not self._enabled:
            return
        self._highlight_multiline(text)
        for pattern, fmt in self._rules:
            it = pattern.globalMatch(text)
            while it.hasNext():
                match = it.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)
        comment = QRegularExpression(r"#[^\n]*").match(text)
        if not comment.hasMatch():
            return
        start = comment.capturedStart()
        length = comment.capturedLength()
        value = comment.captured()
        if QRegularExpression(r"##[^\n]*").match(text).hasMatch():
            self.setFormat(start, length, self._sect_fmt)
            return
        if QRegularExpression(r"#![^\n]*").match(text).hasMatch():
            self.setFormat(start, length, self._warn_fmt)
            return
        self.setFormat(start, length, self._comment_fmt)
        it = QRegularExpression(r"\b(TODO|FIXME|NOTE|HACK|XXX)\b").globalMatch(value)
        while it.hasNext():
            match = it.next()
            self.setFormat(start + match.capturedStart(), match.capturedLength(), self._todo_fmt)

    def _highlight_multiline(self, text: str) -> None:
        for delimiter, state in [('"""', self._DQ3), ("'''", self._SQ3)]:
            start = 0
            if self.previousBlockState() == state:
                end = text.find(delimiter)
                if end == -1:
                    self.setFormat(0, len(text), self._str_fmt)
                    self.setCurrentBlockState(state)
                    return
                self.setFormat(0, end + 3, self._str_fmt)
                start = end + 3
            while start < len(text):
                idx = text.find(delimiter, start)
                if idx == -1:
                    break
                end = text.find(delimiter, idx + 3)
                if end == -1:
                    self.setFormat(idx, len(text) - idx, self._str_fmt)
                    self.setCurrentBlockState(state)
                    return
                self.setFormat(idx, end - idx + 3, self._str_fmt)
                start = end + 3


class _LineNumberArea(QWidget):
    def __init__(self, editor: "CodeEditor") -> None:
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self) -> QSize:
        return QSize(self._editor.line_number_area_width(), 0)

    def paintEvent(self, event: QPaintEvent) -> None:
        self._editor.line_number_area_paint_event(event)

    def mousePressEvent(self, event) -> None:
        self._editor.line_number_area_mouse_press_event(event)
        super().mousePressEvent(event)


class _FindLineEdit(QLineEdit):
    escape_pressed = pyqtSignal()
    shift_return_pressed = pyqtSignal()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key_Escape:
            self.escape_pressed.emit()
            event.accept()
            return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ShiftModifier:
            self.shift_return_pressed.emit()
            event.accept()
            return
        super().keyPressEvent(event)


_BRACKET_PAIRS = {"(": ")", "[": "]", "{": "}"}
_CLOSE_TO_OPEN = {v: k for k, v in _BRACKET_PAIRS.items()}
_ALL_BRACKETS = set(_BRACKET_PAIRS) | set(_CLOSE_TO_OPEN)


class CodeEditor(QPlainTextEdit):
    _INDENT_WIDTH = 4

    def __init__(self, dark: bool = False, font_size: int = 13) -> None:
        super().__init__()
        self._dark = dark
        self._font_size = font_size
        self._line_number_area = _LineNumberArea(self)
        self._highlighter = PythonHighlighter(self.document(), dark)
        self._bracket_selections: list[QTextEdit.ExtraSelection] = []
        self._search_selections: list[QTextEdit.ExtraSelection] = []
        self._search_current_selection: list[QTextEdit.ExtraSelection] = []
        self._folded_blocks: set[int] = set()
        self._setup_font(font_size)
        self._setup_colors()
        self.blockCountChanged.connect(self._update_line_number_area_width)
        self.updateRequest.connect(self._update_line_number_area)
        self.cursorPositionChanged.connect(self._highlight_current_line)
        self.cursorPositionChanged.connect(self._highlight_matching_bracket)
        self._update_line_number_area_width(0)
        self._highlight_current_line()
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setTabStopDistance(QFontMetrics(self.font()).horizontalAdvance(" ") * self._INDENT_WIDTH)

    def _setup_font(self, size: int) -> None:
        font = QFont("Consolas")
        if not QFontMetrics(font).averageCharWidth():
            font = QFont("Courier New")
        font.setPointSize(size)
        font.setFixedPitch(True)
        self.setFont(font)

    def _setup_colors(self) -> None:
        if self._dark:
            bg, fg = QColor("#1e1e1e"), QColor("#d4d4d4")
            self._current_line_color = QColor("#282828")
            self._line_num_bg, self._line_num_fg, self._line_num_active = QColor("#252526"), QColor("#858585"), QColor("#c6c6c6")
            self._indent_guide_color = QColor("#3c3c3c")
            self._fold_marker_bg = QColor("#2f3136")
            self._fold_marker_border = QColor("#64676d")
            self._fold_marker_fg = QColor("#c9ccd2")
            self._fold_marker_active_bg = QColor("#3a3d44")
            self._bracket_match_bg = QColor("#24362a")
            self._search_match_bg = QColor("#4b3f18")
            self._search_current_bg = QColor("#c89614")
            self._search_current_fg = QColor("#111111")
        else:
            bg, fg = QColor("#f5f5f7"), QColor("#1e1e1e")
            self._current_line_color = QColor("#e8f0fe")
            self._line_num_bg, self._line_num_fg, self._line_num_active = QColor("#ebebef"), QColor("#999999"), QColor("#333333")
            self._indent_guide_color = QColor("#d0d0d4")
            self._fold_marker_bg = QColor("#f5f5f7")
            self._fold_marker_border = QColor("#9ca3ad")
            self._fold_marker_fg = QColor("#4b5563")
            self._fold_marker_active_bg = QColor("#e8edf5")
            self._bracket_match_bg = QColor("#dceee2")
            self._search_match_bg = QColor("#fff1b5")
            self._search_current_bg = QColor("#f0bf4e")
            self._search_current_fg = QColor("#1e1e1e")
        palette = self.palette()
        palette.setColor(QPalette.Base, bg)
        palette.setColor(QPalette.Text, fg)
        self.setPalette(palette)

    def update_theme(self, dark: bool) -> None:
        self._dark = dark
        self._setup_colors()
        self._highlighter.update_theme(dark)
        self._highlight_current_line()
        self._line_number_area.update()
        self.viewport().update()

    def set_syntax_highlight(self, enabled: bool) -> None:
        self._highlighter.set_enabled(enabled)

    def set_font_size(self, size: int) -> None:
        self._font_size = size
        font = self.font()
        font.setPointSize(size)
        self.setFont(font)
        self.setTabStopDistance(QFontMetrics(self.font()).horizontalAdvance(" ") * self._INDENT_WIDTH)

    def zoom_in(self) -> None:
        self.set_font_size(min(self._font_size + 1, 36))

    def zoom_out(self) -> None:
        self.set_font_size(max(self._font_size - 1, 6))

    def reset_zoom(self, default: int = 13) -> None:
        self.set_font_size(default)

    def line_number_area_width(self) -> int:
        digits = max(1, len(str(self.blockCount())))
        number_width = QFontMetrics(self.font()).horizontalAdvance("9") * (digits + 1)
        return 6 + number_width + self._fold_marker_total_width()

    def _fold_marker_size(self) -> int:
        return 10

    def _fold_marker_total_width(self) -> int:
        return self._fold_marker_size() + 8

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        rect = self.contentsRect()
        self._line_number_area.setGeometry(QRect(rect.left(), rect.top(), self.line_number_area_width(), rect.height()))

    def _update_line_number_area_width(self, _: int) -> None:
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _update_line_number_area(self, rect: QRect, dy: int) -> None:
        if dy:
            self._line_number_area.scroll(0, dy)
        else:
            self._line_number_area.update(0, rect.y(), self._line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_line_number_area_width(0)

    def line_number_area_paint_event(self, event: QPaintEvent) -> None:
        painter = QPainter(self._line_number_area)
        painter.fillRect(event.rect(), self._line_num_bg)
        current = self.textCursor().blockNumber()
        block = self.firstVisibleBlock()
        number = block.blockNumber()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                if number == current:
                    painter.setPen(self._line_num_active)
                    font = QFont(self.font())
                    font.setBold(True)
                    painter.setFont(font)
                else:
                    painter.setPen(self._line_num_fg)
                    painter.setFont(self.font())
                marker_width = self._fold_marker_total_width()
                painter.drawText(0, top, self._line_number_area.width() - marker_width - 3, bottom - top, Qt.AlignVCenter | Qt.AlignRight, str(number + 1))
                if self._is_foldable_block(block):
                    self._paint_fold_marker(painter, block.blockNumber(), top, bottom, number == current)
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            number += 1

    def _paint_fold_marker(self, painter: QPainter, block_number: int, top: int, bottom: int, active: bool) -> None:
        size = self._fold_marker_size()
        x = self._line_number_area.width() - size - 4
        y = top + max(0, (bottom - top - size) // 2)
        rect = QRect(x, y, size, size)
        painter.save()
        painter.setPen(self._fold_marker_border)
        painter.setBrush(self._fold_marker_active_bg if active else self._fold_marker_bg)
        painter.drawRoundedRect(rect, 2, 2)
        painter.setPen(self._fold_marker_fg)
        mid_y = rect.top() + rect.height() // 2
        painter.drawLine(rect.left() + 2, mid_y, rect.right() - 2, mid_y)
        if block_number in self._folded_blocks:
            mid_x = rect.left() + rect.width() // 2
            painter.drawLine(mid_x, rect.top() + 2, mid_x, rect.bottom() - 2)
        painter.restore()

    def line_number_area_mouse_press_event(self, event) -> None:
        block = self._block_at_y(event.pos().y())
        if block is None or not self._is_foldable_block(block):
            return
        size = self._fold_marker_size()
        marker_left = self._line_number_area.width() - size - 4
        if event.pos().x() < marker_left - 2:
            return
        self._toggle_fold(block.blockNumber())

    def _block_at_y(self, y: int):
        block = self.firstVisibleBlock()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        while block.isValid():
            if block.isVisible() and top <= y <= bottom:
                return block
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
        return None

    def _leading_columns(self, text: str) -> int:
        count = 0
        for char in text:
            if char == " ":
                count += 1
            elif char == "\t":
                count += self._INDENT_WIDTH
            else:
                break
        return count

    def _fold_range(self, start_block) -> list[int]:
        base_indent = self._leading_columns(start_block.text())
        block = start_block.next()
        pending_blank: list[int] = []
        result: list[int] = []
        seen_child = False
        while block.isValid():
            text = block.text()
            stripped = text.strip()
            if not stripped:
                pending_blank.append(block.blockNumber())
                block = block.next()
                continue
            indent = self._leading_columns(text)
            if indent <= base_indent:
                break
            if pending_blank:
                result.extend(pending_blank)
                pending_blank = []
            result.append(block.blockNumber())
            seen_child = True
            block = block.next()
        if seen_child and pending_blank:
            result.extend(pending_blank)
        return result if seen_child else []

    def _is_foldable_block(self, block) -> bool:
        text = block.text().rstrip()
        if not text or text.lstrip().startswith("#") or not text.endswith(":"):
            return False
        return bool(self._fold_range(block))

    def _toggle_fold(self, block_number: int) -> None:
        if block_number in self._folded_blocks:
            self._folded_blocks.remove(block_number)
        else:
            self._folded_blocks.add(block_number)
        self._apply_folding()

    def _apply_folding(self) -> None:
        doc = self.document()
        block = doc.begin()
        while block.isValid():
            block.setVisible(True)
            block.setLineCount(1)
            block = block.next()
        for block_number in sorted(self._folded_blocks):
            start_block = doc.findBlockByNumber(block_number)
            if not start_block.isValid():
                continue
            hidden_numbers = self._fold_range(start_block)
            if not hidden_numbers:
                continue
            for hidden_number in hidden_numbers:
                hidden_block = doc.findBlockByNumber(hidden_number)
                if hidden_block.isValid():
                    hidden_block.setVisible(False)
                    hidden_block.setLineCount(0)
        doc.markContentsDirty(0, doc.characterCount())
        self.viewport().update()
        self._line_number_area.update()
        self._update_line_number_area_width(0)

    def _highlight_current_line(self) -> None:
        selections: list[QTextEdit.ExtraSelection] = []
        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()
            selection.format.setBackground(self._current_line_color)
            selection.format.setProperty(QTextCharFormat.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            selections.append(selection)
        selections.extend(self._search_selections)
        selections.extend(self._search_current_selection)
        selections.extend(self._bracket_selections)
        self.setExtraSelections(selections)
        self._line_number_area.update()

    def clear_search_highlights(self) -> None:
        self._search_selections = []
        self._search_current_selection = []
        self._highlight_current_line()

    def highlight_search_results(self, query: str, current_range: Optional[tuple[int, int]] = None) -> list[tuple[int, int]]:
        self._search_selections = []
        self._search_current_selection = []
        matches: list[tuple[int, int]] = []
        if not query:
            self._highlight_current_line()
            return matches

        normal_fmt = QTextCharFormat()
        normal_fmt.setBackground(self._search_match_bg)
        current_fmt = QTextCharFormat()
        current_fmt.setBackground(self._search_current_bg)
        current_fmt.setForeground(self._search_current_fg)

        cursor = QTextCursor(self.document())
        while True:
            cursor = self.document().find(query, cursor)
            if cursor.isNull():
                break
            found_range = (cursor.selectionStart(), cursor.selectionEnd())
            matches.append(found_range)
            selection = QTextEdit.ExtraSelection()
            selection.cursor = QTextCursor(cursor)
            if current_range and found_range == current_range:
                selection.format = current_fmt
                self._search_current_selection.append(selection)
            else:
                selection.format = normal_fmt
                self._search_selections.append(selection)

        self._highlight_current_line()
        return matches

    def _highlight_matching_bracket(self) -> None:
        self._bracket_selections = []
        doc = self.document()
        pos = self.textCursor().position()
        for check_pos in (pos, pos - 1):
            if check_pos < 0 or check_pos >= doc.characterCount():
                continue
            cursor = QTextCursor(doc)
            cursor.setPosition(check_pos)
            cursor.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor)
            char = cursor.selectedText()
            if char not in _ALL_BRACKETS:
                continue
            match_pos = self._find_matching_bracket(check_pos, char)
            if match_pos is None:
                continue
            fmt = QTextCharFormat()
            fmt.setBackground(self._bracket_match_bg)
            items = []
            for bracket_pos in (check_pos, match_pos):
                sel = QTextEdit.ExtraSelection()
                sel_cursor = QTextCursor(doc)
                sel_cursor.setPosition(bracket_pos)
                sel_cursor.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor)
                sel.cursor = sel_cursor
                sel.format = fmt
                items.append(sel)
            self._bracket_selections = items
            break
        self._highlight_current_line()

    def _find_matching_bracket(self, pos: int, char: str) -> Optional[int]:
        if char in _BRACKET_PAIRS:
            target, direction = _BRACKET_PAIRS[char], 1
        elif char in _CLOSE_TO_OPEN:
            target, direction = _CLOSE_TO_OPEN[char], -1
        else:
            return None
        doc = self.document()
        depth = 0
        i = pos
        limit = 5000
        while 0 <= i < doc.characterCount() and limit > 0:
            cursor = QTextCursor(doc)
            cursor.setPosition(i)
            cursor.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor)
            current = cursor.selectedText()
            if current == char:
                depth += 1
            elif current == target:
                depth -= 1
                if depth == 0:
                    return i
            i += direction
            limit -= 1
        return None

    def paintEvent(self, event: QPaintEvent) -> None:
        super().paintEvent(event)
        painter = QPainter(self.viewport())
        painter.setPen(self._indent_guide_color)
        space_w = QFontMetrics(self.font()).horizontalAdvance(" ")
        indent_px = space_w * self._INDENT_WIDTH
        block = self.firstVisibleBlock()
        while block.isValid():
            geom = self.blockBoundingGeometry(block).translated(self.contentOffset())
            if geom.top() > event.rect().bottom():
                break
            if block.isVisible() and geom.bottom() >= event.rect().top():
                leading = 0
                for char in block.text():
                    if char == " ":
                        leading += 1
                    elif char == "\t":
                        leading += self._INDENT_WIDTH
                    else:
                        break
                for level in range(1, leading // self._INDENT_WIDTH + 1):
                    x = int(indent_px * level - indent_px + space_w * 0.5)
                    painter.drawLine(x, int(geom.top()), x, int(geom.bottom()))
            block = block.next()
        painter.end()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key_Return:
            indent = re.match(r"^(\s*)", self.textCursor().block().text()).group(1)
            if self.textCursor().block().text().rstrip().endswith(":"):
                indent += " " * self._INDENT_WIDTH
            super().keyPressEvent(event)
            self.insertPlainText(indent)
            return
        if event.key() == Qt.Key_Tab:
            cursor = self.textCursor()
            if cursor.hasSelection():
                self._indent_selection(cursor)
            else:
                self.insertPlainText(" " * self._INDENT_WIDTH)
            return
        if event.key() == Qt.Key_Backtab:
            self._dedent_selection(self.textCursor())
            return
        super().keyPressEvent(event)

    def _indent_selection(self, cursor: QTextCursor) -> None:
        start, end = cursor.selectionStart(), cursor.selectionEnd()
        cursor.setPosition(start)
        cursor.movePosition(QTextCursor.StartOfBlock)
        cursor.beginEditBlock()
        while cursor.position() <= end:
            cursor.insertText(" " * self._INDENT_WIDTH)
            end += self._INDENT_WIDTH
            if not cursor.movePosition(QTextCursor.NextBlock):
                break
        cursor.endEditBlock()

    def _dedent_selection(self, cursor: QTextCursor) -> None:
        start, end = cursor.selectionStart(), cursor.selectionEnd()
        cursor.setPosition(start)
        cursor.movePosition(QTextCursor.StartOfBlock)
        cursor.beginEditBlock()
        while cursor.position() <= end:
            remove = 0
            for char in cursor.block().text()[:self._INDENT_WIDTH]:
                if char == " ":
                    remove += 1
                else:
                    break
            for _ in range(remove):
                cursor.deleteChar()
                end -= 1
            if not cursor.movePosition(QTextCursor.NextBlock):
                break
        cursor.endEditBlock()


class EditorWidget(QTabWidget):
    file_opened = pyqtSignal(str)
    modification_changed = pyqtSignal(bool)
    device_file_save_requested = pyqtSignal(str, bytes)
    state_changed = pyqtSignal()

    def __init__(self, config_manager, theme_manager) -> None:
        super().__init__()
        self._config = config_manager
        self._theme = theme_manager
        self._tab_paths: dict[int, Optional[str]] = {}
        self._tab_meta: dict[int, dict[str, str]] = {}
        self._new_file_counter = 1
        self._draft_counter = 1
        self._syntax_highlight = config_manager.get("syntax_highlight", True)
        self._find_visible = False
        self.setTabsClosable(True)
        self.setMovable(True)
        self.tabBar().setIconSize(QSize(16, 16))
        self._build_find_popup()
        self.tabCloseRequested.connect(self.close_tab)
        self.currentChanged.connect(self._on_current_changed)
        self.tabBar().tabMoved.connect(lambda *_: self.state_changed.emit())
        self.new_tab()

    def _build_find_popup(self) -> None:
        self._find_popup = QWidget(self)
        self._find_popup.setObjectName("EditorFindPopup")
        self._find_popup.setAttribute(Qt.WA_StyledBackground, True)
        self._find_popup.setFixedHeight(36)
        layout = QHBoxLayout(self._find_popup)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        self._find_edit = _FindLineEdit()
        self._find_edit.setPlaceholderText(tr("editor_find_placeholder"))
        self._find_edit.setClearButtonEnabled(True)
        self._find_edit.setMinimumWidth(180)
        self._find_edit.textChanged.connect(self._on_find_text_changed)
        self._find_edit.returnPressed.connect(self.find_next)
        self._find_edit.shift_return_pressed.connect(self.find_previous)
        self._find_edit.escape_pressed.connect(self.hide_find_popup)

        self._find_count = QLabel("")
        self._find_count.setFixedWidth(56)
        self._find_count.setAlignment(Qt.AlignCenter)

        self._btn_find_prev = QPushButton("\u25C0")
        self._btn_find_prev.setFixedSize(26, 24)
        self._btn_find_prev.setToolTip(tr("editor_find_prev"))
        self._btn_find_prev.clicked.connect(self.find_previous)

        self._btn_find_next = QPushButton("\u25B6")
        self._btn_find_next.setFixedSize(26, 24)
        self._btn_find_next.setToolTip(tr("editor_find_next"))
        self._btn_find_next.clicked.connect(self.find_next)

        self._btn_find_close = QPushButton("\u00D7")
        self._btn_find_close.setFixedSize(26, 24)
        self._btn_find_close.setToolTip(tr("editor_find_close"))
        self._btn_find_close.clicked.connect(self.hide_find_popup)

        layout.addWidget(self._find_edit)
        layout.addWidget(self._find_count)
        layout.addWidget(self._btn_find_prev)
        layout.addWidget(self._btn_find_next)
        layout.addWidget(self._btn_find_close)

        self._find_popup.hide()
        self._apply_find_popup_theme(self._current_dark())

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._position_find_popup()

    def _current_dark(self) -> bool:
        return self._theme.is_dark()

    def _current_font_size(self) -> int:
        return self._config.get("font_size", 13)

    def _draft_id(self) -> str:
        value = f"draft-{self._draft_counter}"
        self._draft_counter += 1
        return value

    def _next_untitled_name(self) -> str:
        used_numbers: set[int] = set()
        pattern = re.compile(r"^untitled_(\d+)\.py$")
        for idx in range(self.count()):
            path = self._tab_paths.get(idx)
            if path:
                continue
            match = pattern.match(self._base_title(idx))
            if match:
                used_numbers.add(int(match.group(1)))
        number = 1
        while number in used_numbers:
            number += 1
        self._new_file_counter = max(self._new_file_counter, number + 1)
        return f"untitled_{number}.py"

    def _editor(self, content: str = "") -> CodeEditor:
        editor = CodeEditor(self._current_dark(), self._current_font_size())
        if not self._syntax_highlight:
            editor.set_syntax_highlight(False)
        if content:
            editor.setPlainText(content)
        editor.document().contentsChanged.connect(self.state_changed.emit)
        return editor

    def _base_title(self, idx: int) -> str:
        return self._tab_meta.get(idx, {}).get("title", self.tabText(idx).rstrip("*"))

    def _set_base_title(self, idx: int, title: str) -> None:
        self._tab_meta.setdefault(idx, {"title": title, "draft_id": self._draft_id()})["title"] = title
        editor = self.widget(idx)
        modified = isinstance(editor, CodeEditor) and editor.document().isModified()
        self.setTabText(idx, title + ("*" if modified else ""))
        self._apply_tab_icon(idx, self._tab_paths.get(idx), title)

    def _reindex(self) -> None:
        old_paths, old_meta = dict(self._tab_paths), dict(self._tab_meta)
        self._tab_paths, self._tab_meta = {}, {}
        for idx in range(self.count()):
            self._tab_paths[idx] = old_paths.get(idx)
            self._tab_meta[idx] = old_meta.get(idx, {"title": self.tabText(idx).rstrip("*"), "draft_id": self._draft_id()})

    def new_tab(self, path: Optional[str] = None, content: str = "", title: Optional[str] = None, draft_id: Optional[str] = None, modified: bool = False) -> int:
        editor = self._editor(content)
        if title is None:
            title = os.path.basename(path) if path else self._next_untitled_name()
        if path is None:
            self._new_file_counter = max(self._new_file_counter, 1)
        idx = self.addTab(editor, title)
        self._tab_paths[idx] = path
        self._tab_meta[idx] = {"title": title, "draft_id": draft_id or self._draft_id()}
        self.setCurrentIndex(idx)
        self._apply_tab_icon(idx, path, title)
        editor.document().modificationChanged.connect(lambda is_modified, i=idx: self._on_modification_changed(i, is_modified))
        editor.document().setModified(modified)
        if path and not path.startswith("device:"):
            self.file_opened.emit(path)
        self.state_changed.emit()
        return idx

    def _on_current_changed(self, _: int) -> None:
        self.state_changed.emit()
        if self._find_visible:
            self._refresh_find(reset=True)

    def _position_find_popup(self) -> None:
        if not hasattr(self, "_find_popup"):
            return
        width = max(320, self.width() // 3)
        width = min(width, 420)
        self._find_popup.setFixedWidth(width)
        x = self.width() - width - 12
        y = self.tabBar().height() + 8
        self._find_popup.move(max(8, x), max(8, y))

    def _apply_find_popup_theme(self, dark: bool) -> None:
        bg = "#2d2d30" if dark else "#f5f5f5"
        border = "#444448" if dark else "#cccccc"
        fg = "#d4d4d4" if dark else "#1e1e1e"
        btn_bg = "#3a3a3d" if dark else "#ffffff"
        btn_hover = "#4a4a4f" if dark else "#e9e9e9"
        btn_border = "#5a5a60" if dark else "#c8c8c8"
        muted = "#a0a0a8" if dark else "#666666"
        self._find_popup.setStyleSheet(
            f"""
            QWidget#EditorFindPopup {{
                background: {bg};
                border: 1px solid {border};
                border-radius: 8px;
            }}
            QWidget#EditorFindPopup QLabel {{
                color: {muted};
                border: none;
            }}
            QWidget#EditorFindPopup QPushButton {{
                background: {btn_bg};
                color: {fg};
                border: 1px solid {btn_border};
                border-radius: 4px;
                padding: 0;
            }}
            QWidget#EditorFindPopup QPushButton:hover {{
                background: {btn_hover};
            }}
            """
        )
        self._refresh_find_input_style(None)

    def _refresh_find_input_style(self, found: Optional[bool]) -> None:
        dark = self._current_dark()
        bg = "#1f1f1f" if dark else "#ffffff"
        fg = "#d4d4d4" if dark else "#1e1e1e"
        border = "#5a5a60" if dark else "#c8c8c8"
        if found is False:
            bg = "#382323" if dark else "#fff2f1"
            border = "#d9534f"
        self._find_edit.setStyleSheet(
            f"""
            QLineEdit {{
                background: {bg};
                color: {fg};
                border: 1px solid {border};
                border-radius: 4px;
                padding: 2px 6px;
            }}
            """
        )

    def _clear_search_highlights(self) -> None:
        for idx in range(self.count()):
            widget = self.widget(idx)
            if isinstance(widget, CodeEditor):
                widget.clear_search_highlights()

    def show_find_bar(self) -> None:
        editor = self.current_editor()
        if not editor:
            return
        self._find_visible = True
        self._apply_find_popup_theme(self._current_dark())
        self._position_find_popup()
        self._find_popup.show()
        self._find_popup.raise_()
        selected = editor.textCursor().selectedText()
        if selected and "\u2029" not in selected:
            if self._find_edit.text() != selected:
                self._find_edit.setText(selected)
            else:
                self._refresh_find(reset=True)
        else:
            self._refresh_find(reset=True)
        self._find_edit.setFocus()
        self._find_edit.selectAll()

    def hide_find_popup(self) -> None:
        self._find_visible = False
        self._find_popup.hide()
        self._find_count.setText("")
        self._refresh_find_input_style(None)
        self._clear_search_highlights()
        editor = self.current_editor()
        if editor:
            editor.setFocus()

    def _on_find_text_changed(self, text: str) -> None:
        if not text:
            self._find_count.setText("")
            self._refresh_find_input_style(None)
            self._clear_search_highlights()
            return
        self._refresh_find(reset=True)

    def _update_find_count(self, total: int, current_index: int) -> None:
        if total <= 0:
            self._find_count.setText("0")
            return
        if current_index <= 0:
            self._find_count.setText(f"0/{total}")
            return
        self._find_count.setText(f"{current_index}/{total}")

    def _find_match(self, backward: bool = False, reset: bool = False) -> None:
        editor = self.current_editor()
        query = self._find_edit.text()
        if not editor or not query:
            return
        self._clear_search_highlights()

        flags = QTextDocument.FindFlags()
        if backward:
            flags |= QTextDocument.FindBackward

        if reset:
            start_cursor = QTextCursor(editor.document())
            start_cursor.movePosition(QTextCursor.End if backward else QTextCursor.Start)
        else:
            start_cursor = editor.textCursor()

        found = editor.document().find(query, start_cursor, flags)
        if found.isNull() and not reset:
            wrap_cursor = QTextCursor(editor.document())
            wrap_cursor.movePosition(QTextCursor.End if backward else QTextCursor.Start)
            found = editor.document().find(query, wrap_cursor, flags)

        current_range: Optional[tuple[int, int]] = None
        if not found.isNull():
            editor.setTextCursor(found)
            editor.centerCursor()
            current_range = (found.selectionStart(), found.selectionEnd())

        matches = editor.highlight_search_results(query, current_range)
        if not matches:
            self._update_find_count(0, 0)
            self._refresh_find_input_style(False)
            return

        current_index = matches.index(current_range) + 1 if current_range in matches else 0
        self._update_find_count(len(matches), current_index)
        self._refresh_find_input_style(current_index > 0)

    def _refresh_find(self, reset: bool = False) -> None:
        query = self._find_edit.text()
        if not query:
            self._find_count.setText("")
            self._refresh_find_input_style(None)
            self._clear_search_highlights()
            return
        self._find_match(reset=reset)

    def find_next(self) -> None:
        self._find_match(backward=False, reset=False)

    def find_previous(self) -> None:
        self._find_match(backward=True, reset=False)

    def open_file(self, path: str) -> None:
        for idx, open_path in self._tab_paths.items():
            if open_path == path:
                self.setCurrentIndex(idx)
                return
        binary_exts = {".mpy", ".bin", ".hex", ".dat", ".o"}
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext in binary_exts:
                with open(path, "rb") as fh:
                    content = self._hex_dump(fh.read(), path)
            else:
                with open(path, "r", encoding="utf-8") as fh:
                    content = fh.read()
        except UnicodeDecodeError:
            try:
                with open(path, "rb") as fh:
                    content = self._hex_dump(fh.read(), path)
            except OSError as exc:
                QMessageBox.critical(self, tr("editor_error"), tr("editor_cannot_open", err=exc))
                return
        except OSError as exc:
            QMessageBox.critical(self, tr("editor_error"), tr("editor_cannot_open", err=exc))
            return
        self.new_tab(path, content)

    @staticmethod
    def _hex_dump(data: bytes, path: str) -> str:
        lines = [f"Binary file: {os.path.basename(path)}", f"Size: {len(data)} bytes", "Hex dump (read-only view):", ""]
        for i in range(0, len(data), 16):
            chunk = data[i:i + 16]
            lines.append(f"{i:08X}  {' '.join(f'{b:02X}' for b in chunk):<47}  |{''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)}|")
        return "\n".join(lines)

    def open_device_file(self, remote_path: str, data: bytes) -> None:
        tag = "device:" + remote_path
        for idx, open_path in self._tab_paths.items():
            if open_path == tag:
                self.setCurrentIndex(idx)
                return
        try:
            content = data.decode("utf-8", errors="replace")
        except Exception:
            content = str(data)
        self.new_tab(tag, content, remote_path.rsplit("/", 1)[-1])

    def save_current(self) -> bool:
        idx = self.currentIndex()
        if idx < 0:
            return False
        path = self._tab_paths.get(idx)
        if not path:
            return self.save_current_as()
        if path.startswith("device:"):
            editor = self.widget(idx)
            if isinstance(editor, CodeEditor):
                self.device_file_save_requested.emit(path[len("device:"):], editor.toPlainText().encode("utf-8"))
                editor.document().setModified(False)
                self._set_base_title(idx, path.rsplit("/", 1)[-1])
            self.state_changed.emit()
            return True
        return self._save_to(idx, path)

    def save_current_as(self) -> bool:
        idx = self.currentIndex()
        if idx < 0:
            return False
        path, _ = QFileDialog.getSaveFileName(self, tr("editor_save_as"), "", tr("editor_py_filter"))
        if not path:
            return False
        self._tab_paths[idx] = path
        self._set_base_title(idx, os.path.basename(path))
        return self._save_to(idx, path)

    def _save_to(self, idx: int, path: str) -> bool:
        editor = self.widget(idx)
        if not isinstance(editor, CodeEditor):
            return False
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(editor.toPlainText())
            editor.document().setModified(False)
            self._set_base_title(idx, os.path.basename(path))
            self.state_changed.emit()
            return True
        except OSError as exc:
            QMessageBox.critical(self, tr("editor_error"), tr("editor_cannot_save", err=exc))
            return False

    def close_tab(self, idx: int) -> None:
        editor = self.widget(idx)
        if isinstance(editor, CodeEditor) and editor.document().isModified():
            path = self._tab_paths.get(idx, "untitled")
            name = os.path.basename(path) if path else "untitled"
            reply = QMessageBox.question(self, tr("editor_unsaved_title"), tr("editor_unsaved_msg", name=name), QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if reply == QMessageBox.Save:
                self.setCurrentIndex(idx)
                if not self.save_current():
                    return
            elif reply == QMessageBox.Cancel:
                return
        old_paths = dict(self._tab_paths)
        old_meta = dict(self._tab_meta)
        old_paths.pop(idx, None)
        old_meta.pop(idx, None)
        self.removeTab(idx)
        self._tab_paths = {}
        self._tab_meta = {}
        for old_idx, path in old_paths.items():
            new_idx = old_idx if old_idx < idx else old_idx - 1
            self._tab_paths[new_idx] = path
        for old_idx, meta in old_meta.items():
            new_idx = old_idx if old_idx < idx else old_idx - 1
            self._tab_meta[new_idx] = meta
        if self.count() == 0:
            self.new_tab()
        self.state_changed.emit()

    def serialize_session(self) -> dict:
        tabs = []
        for idx in range(self.count()):
            editor = self.widget(idx)
            if not isinstance(editor, CodeEditor):
                continue
            path = self._tab_paths.get(idx)
            if path and path.startswith("device:"):
                tab_type = "device_cached"
            elif path:
                tab_type = "local_saved"
            else:
                tab_type = "local_unsaved"
            tabs.append({"type": tab_type, "title": self._base_title(idx), "path": path, "content": editor.toPlainText(), "modified": editor.document().isModified(), "draft_id": self._tab_meta.get(idx, {}).get("draft_id", "")})
        return {"current_index": self.currentIndex(), "tabs": tabs}

    def restore_session(self, snapshot: dict) -> bool:
        tabs = snapshot.get("tabs", [])
        if not tabs:
            return False
        while self.count():
            self.removeTab(0)
        self._tab_paths.clear()
        self._tab_meta.clear()
        for tab in tabs:
            tab_type = tab.get("type")
            path = tab.get("path")
            title = tab.get("title")
            content = tab.get("content", "")
            modified = bool(tab.get("modified"))
            draft_id = tab.get("draft_id") or self._draft_id()
            if tab_type == "local_saved" and path and os.path.isfile(path):
                self.new_tab(path, content, title, draft_id, modified)
            elif tab_type == "device_cached" and path:
                self.new_tab(path, content, title, draft_id, modified)
            else:
                self.new_tab(None, content, title, draft_id, modified or bool(content))
        current = snapshot.get("current_index", 0)
        if 0 <= current < self.count():
            self.setCurrentIndex(current)
        self.state_changed.emit()
        return True

    def current_editor(self) -> Optional[CodeEditor]:
        widget = self.currentWidget()
        return widget if isinstance(widget, CodeEditor) else None

    def current_content(self) -> str:
        editor = self.current_editor()
        return editor.toPlainText() if editor else ""

    def current_file_path(self) -> Optional[str]:
        idx = self.currentIndex()
        if idx < 0:
            return None
        path = self._tab_paths.get(idx)
        if path and not path.startswith("device:"):
            return path
        return None

    def _on_modification_changed(self, idx: int, modified: bool) -> None:
        if idx >= self.count():
            return
        self.setTabText(idx, self._base_title(idx) + ("*" if modified else ""))
        self.modification_changed.emit(modified)
        self.state_changed.emit()

    def _apply_tab_icon(self, idx: int, path: Optional[str], title: str) -> None:
        self.setTabIcon(idx, QIcon())

    def apply_theme(self, dark: bool) -> None:
        self._apply_find_popup_theme(dark)
        for idx in range(self.count()):
            widget = self.widget(idx)
            if isinstance(widget, CodeEditor):
                widget.update_theme(dark)
        if self._find_visible and self._find_edit.text():
            self._refresh_find(reset=False)

    def apply_font_size(self, size: int) -> None:
        for idx in range(self.count()):
            widget = self.widget(idx)
            if isinstance(widget, CodeEditor):
                widget.set_font_size(size)

    def set_syntax_highlight(self, enabled: bool) -> None:
        self._syntax_highlight = enabled
        for idx in range(self.count()):
            widget = self.widget(idx)
            if isinstance(widget, CodeEditor):
                widget.set_syntax_highlight(enabled)

    def zoom_in(self) -> None:
        editor = self.current_editor()
        if editor:
            editor.zoom_in()

    def zoom_out(self) -> None:
        editor = self.current_editor()
        if editor:
            editor.zoom_out()

    def reset_zoom(self) -> None:
        editor = self.current_editor()
        if editor:
            editor.reset_zoom(self._current_font_size())
