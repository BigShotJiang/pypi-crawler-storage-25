# BoardyPy

BoardyPy is a desktop MicroPython IDE built with PyQt5.

It focuses on a lightweight workflow for MicroPython boards and bundles the tools you need in one place:

- code editor with syntax highlighting
- serial REPL / console
- local file explorer
- device file explorer for MicroPython boards
- bundled MicroPython library manager
- local script runner

## Installation

```bash
pip install boardypy
```

## Run

```bash
boardypy
```

## Development

```bash
pip install -e .
python -m boardypy
```

## Notes

- Python `>=3.9` is required.
- The project uses a custom attribution-required license; see `LICENSE`.
- Runtime configuration, logs, and session snapshots are stored in the user profile directory, not inside the installed package.
- The toolbar web search opens Yandex Search in the external browser; the generated URL includes the `clid` parameter.
