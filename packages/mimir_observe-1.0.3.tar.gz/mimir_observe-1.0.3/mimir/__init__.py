"""
Mimir — auto-instrumentation and visibility for AI agents.

Usage:
    import mimir

    mimir.instrument_openai()         # Raw OpenAI client (chat.completions.create)
    mimir.instrument_anthropic()      # Raw Anthropic client (messages.create)
    mimir.instrument_openai_agents()  # OpenAI Agents SDK (Runner.run)
    mimir.instrument_claude()         # Claude Agent SDK (query)

That's it. Every call is captured automatically.
"""

from .sdk import Task, Run, configure, trace


def task(name: str, config: str, tools: list[str] | None = None, model: str = "") -> Task:
    """Create a Task (agent identity)."""
    return Task(name=name, config=config, tools=tools, model=model)


# --- Raw client instrumentation ---

def instrument_openai() -> None:
    """Patch OpenAI chat.completions.create to auto-capture every call."""
    from .openai_client import instrument_openai as _inst
    _inst()


def uninstrument_openai() -> None:
    """Restore original OpenAI client methods."""
    from .openai_client import uninstrument_openai as _uninst
    _uninst()


def instrument_anthropic() -> None:
    """Patch Anthropic messages.create to auto-capture every call."""
    from .anthropic_client import instrument_anthropic as _inst
    _inst()


def uninstrument_anthropic() -> None:
    """Restore original Anthropic client methods."""
    from .anthropic_client import uninstrument_anthropic as _uninst
    _uninst()


# --- Agent SDK instrumentation ---

def instrument_openai_agents() -> None:
    """Patch OpenAI Agents SDK Runner to auto-capture every run."""
    from .openai_agents import instrument_openai_agents as _inst
    _inst()


def uninstrument_openai_agents() -> None:
    """Restore original OpenAI Agents SDK Runner methods."""
    from .openai_agents import uninstrument_openai_agents as _uninst
    _uninst()


def instrument_claude() -> None:
    """Patch Claude SDK query() to auto-capture every run."""
    from .claude_agents import instrument_claude as _inst
    _inst()


def uninstrument_claude() -> None:
    """Restore original Claude SDK query()."""
    from .claude_agents import uninstrument_claude as _uninst
    _uninst()


# --- Manual hooks ---

def openai_hooks(run: Run) -> object:
    """Create OpenAI Agents SDK hooks for manual instrumentation."""
    from .openai_agents import openai_hooks as _oh
    return _oh(run)


def claude_hooks(run: Run) -> dict:
    """Create Claude SDK hooks for manual instrumentation."""
    from .claude_agents import claude_hooks as _ch
    return _ch(run)


__all__ = [
    "task",
    "trace",
    "configure",
    "Task",
    "Run",
    "instrument_openai",
    "uninstrument_openai",
    "instrument_anthropic",
    "uninstrument_anthropic",
    "instrument_openai_agents",
    "uninstrument_openai_agents",
    "instrument_claude",
    "uninstrument_claude",
    "openai_hooks",
    "claude_hooks",
]

__version__ = "1.0.3"
