# Copyright 2022-Coopdevs Treball SCCL (<https://coopdevs.org>)
# - César López Ramírez - <cesar.lopez@coopdevs.org>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "Add RESTfull API for Partner adapted to Femprocomuns",
    "version": "16.0.1.0.1",
    "depends": [
        "api_common_base",
        "partner_contact_in_several_companies_femprocomuns",
    ],
    "author": "Coopdevs Treball SCCL",
    "category": "",
    "website": "https://git.coopdevs.org/coopdevs/odoo/odoo-addons/odoo-femprocomuns",
    "license": "AGPL-3",
    "summary": """
        Adapt cooperator API module to Femprocomuns
    """,
    "data": [],
    "installable": True,
}
