from werkzeug.exceptions import BadRequest, NotFound

from odoo import _

from odoo.addons.base_rest import restapi
from odoo.addons.base_rest.http import wrapJsonException
from odoo.addons.component.core import Component

from . import schemas


class ResPartnerService(Component):
    _name = "res.partner.rest.service"
    _inherit = "base.rest.service"
    _usage = "partner"
    _collection = "api_common_base.services"
    _description = """ ResPartner API for FemProcomuns """

    is_company = False

    @restapi.method(
        [(["/<int:_id>"], "GET")],
        input_param=restapi.CerberusValidator("_validator_get"),
        output_param=restapi.CerberusValidator("_validator_return_get"),
        auth="api_key",
    )
    def get(self, _id):
        partner = self.env["res.partner"].browse(_id)
        if not partner:
            raise wrapJsonException(NotFound(_("No partner for id %s") % _id))
        return self._to_dict(partner)

    # pylint: disable=W8106
    @restapi.method(
        [(["/"], "POST")],
        input_param=restapi.CerberusValidator("_validator_create"),
        output_param=restapi.CerberusValidator("_validator_return_get"),
        auth="api_key",
    )
    def create(self, **params):
        related_company = params.pop("related_company", None)
        newsletter = params.pop("newsletter", None)
        partner_params = self._prepare_create(params)
        partner = self.env["res.partner"].create(partner_params)
        if related_company:
            related_company_params = self._prepare_related_company_create(
                partner.id, related_company, params
            )
            self.env["res.partner"].create(related_company_params)
        if newsletter and self.env.company.newsletter_tag_id:
            partner.category_id = [(6, 0, [self.env.company.newsletter_tag_id.id])]
        return self._to_dict(partner)

    @restapi.method(
        [(["/<int:_id>"], "PUT")],
        input_param=restapi.CerberusValidator("_validator_update"),
        output_param=restapi.CerberusValidator("_validator_return_get"),
        auth="api_key",
    )
    def update(self, _id, **params):
        partner = self.env["res.partner"].browse(_id)
        if not partner:
            raise wrapJsonException(NotFound(_("No partner for id %d") % _id))
        if "address" in params.keys():
            address = params.pop("address")
            country = self.env["res.country"].search(
                [("code", "=", address.pop("country"))]
            )
            if not country:
                raise wrapJsonException(BadRequest(_("Country not found")))
            address["country_id"] = country.id
            params.update(address)
        if "iban" in params.keys():
            # We assume that the first bank is the only one for now
            if partner.bank_ids:
                partner.bank_ids[0].acc_number = params.pop("iban")
            else:
                partner.bank_ids.create(
                    {"partner_id": partner.id, "acc_number": params.pop("iban")}
                )

        if "companies" in params.keys():
            for company in params.pop("companies"):
                relation_exist = partner.other_contact_ids.filtered(
                    lambda x: x.parent_id.id == company["company_id"]
                )
                if relation_exist:
                    continue
                related_company_params = self._prepare_related_company_create(
                    partner.id, company, params
                )
                self.env["res.partner"].create(related_company_params)

        partner.write(params)
        return self._to_dict(partner)

    @restapi.method(
        [("/<int:id>", "DELETE")],
        input_param=restapi.CerberusValidator(schema="_validator_delete"),
    )
    def delete(self, _id):
        partner = self.env["res.partner"].browse(_id)
        partner.unlink()
        return {"response": "DELETE called with id %s " % _id}

    def _prepare_create(self, params):
        address = params.pop("address", None)
        if address:
            country_code = address.pop("country")
            country = self.env["res.country"].search([("code", "=", country_code)])
            params.update(address)
            params.update({"country_id": country.id})
        return params

    def _prepare_related_company_create(self, partner_id, related_company, params):
        return {
            "parent_id": related_company["company_id"],
            "contact_type": "attached",
            "contact_id": partner_id,
            "function": related_company["function"],
            "firstname": params.get("firstname"),
            "lastname": params.get("lastname"),
            "email": params.get("email"),
        }

    def _to_dict(self, partner):
        vals = {
            "id": partner.id,
            "vat": partner.vat or "",
            "phone": partner.phone or "",
            "address": {
                "street": partner.street or "",
                "zip": partner.zip or "",
                "city": partner.city or "",
                "country": partner.country_id.code if partner.country_id else "",
            },
        }
        if partner.bank_ids:
            # We assume that the first bank is the only one for now
            vals.update({"iban": partner.bank_ids.mapped("acc_number")[0]})
        if partner.is_company:
            # This is_company is used to select the validator response
            self.is_company = True
            return {
                **vals,
                "company_name": partner.name or "",
                "company_email": partner.email or "",
                "contacts": [
                    {
                        "id": p.id,
                        "contact_id": p.contact_id.id,
                        "firstname": p.contact_id.firstname or "",
                        "lastname": p.contact_id.lastname or "",
                        "email": p.contact_id.email or "",
                        "function": p.function or "",
                    }
                    for p in partner.child_ids
                ],
            }
        # This is_company is used to select the validator response
        self.is_company = False
        if partner.other_contact_ids:
            vals.update(
                {
                    "companies": [
                        {
                            "company_id": contact.parent_id.id,
                            "id": contact.id,
                            "name": contact.parent_id.name,
                            "function": contact.function or "",
                        }
                        for contact in partner.other_contact_ids
                    ]
                }
            )
        return {
            **vals,
            "firstname": partner.firstname or "",
            "lastname": partner.lastname or "",
            "email": partner.email or "",
        }

    def _validator_get(self):
        return schemas.S_RES_PARTNER_GET

    def _validator_create(self):
        return schemas.S_RES_PARTNER_CREATE

    def _validator_delete(self):
        return schemas.S_RES_PARTNER_GET

    def _validator_return_get(self):
        if self.is_company:
            return schemas.S_RES_PARTNER_RETURN_GET_COMPANY
        return schemas.S_RES_PARTNER_RETURN_GET_PERSON

    def _validator_update(self):
        return schemas.S_RES_PARTNER_PUT


class ProfileService(Component):
    _name = "profile.rest.service"
    _inherit = "res.partner.rest.service"
    _usage = "profile"
    _description = """ ResPartner API for FemProcomuns """
