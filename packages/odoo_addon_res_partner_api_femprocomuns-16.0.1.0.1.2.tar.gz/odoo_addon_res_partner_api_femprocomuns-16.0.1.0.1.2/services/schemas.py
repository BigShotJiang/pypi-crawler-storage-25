ADDRESS_SCHEMA = {
    "street": {"type": "string", "required": False, "empty": True},
    "zip": {"type": "string", "required": False, "empty": True},
    "city": {"type": "string", "required": False, "empty": True},
    "country": {"type": "string", "required": False, "empty": True},
}

S_RES_PARTNER_GET = {"_id": {"type": "integer"}}

RELATED_COMPANY_SCHEMA = {
    "company_id": {"type": "integer", "required": True},
    "function": {"type": "string", "required": False},
}

S_RES_PARTNER_CREATE = {
    "vat": {"type": "string", "required": True},
    "firstname": {"type": "string", "required": True},
    "lastname": {"type": "string", "required": True},
    "email": {"type": "string", "required": True},
    "somnuvol_account_name": {"type": "string", "required": True},
    "phone": {"type": "string", "required": False, "empty": True},
    "gender": {"type": "string", "nullable": True},
    "address": {
        "type": "dict",
        "required": False,
        "schema": ADDRESS_SCHEMA,
    },
    "related_company": {
        "type": "dict",
        "required": False,
        "schema": RELATED_COMPANY_SCHEMA,
    },
    "newsletter": {"type": "boolean", "required": True},
}

S_RES_PARTNER_RETURN_GET_RELATED_COMPANY = {
    "id": {"type": "integer", "required": True},
    "company_id": {"type": "integer", "required": True},
    "name": {"type": "string", "required": False},
    "function": {"type": "string", "required": False, "empty": True},
}

S_RES_PARTNER_RETURN_GET = {
    "id": {"type": "integer", "required": True},
    "vat": {"type": "string", "required": False, "empty": True},
    "phone": {"type": "string", "required": False, "empty": True},
    "address": {
        "type": "dict",
        "required": False,
        "schema": ADDRESS_SCHEMA,
    },
    "iban": {
        "type": "string",
        "required": False,
        "empty": True,
    },
}

S_RES_PARTNER_RETURN_GET_COMPANY = {
    **S_RES_PARTNER_RETURN_GET,
    "company_name": {"type": "string", "required": False},
    "company_email": {"type": "string", "required": False},
    "contacts": {
        "type": "list",
        "required": False,
        "schema": {
            "type": "dict",
            "schema": {
                "id": {"type": "integer", "required": False},
                "contact_id": {"type": "integer", "required": False},
                "firstname": {"type": "string", "required": False},
                "lastname": {"type": "string", "required": False},
                "email": {"type": "string", "required": False},
                "function": {"type": "string", "required": False},
            },
        },
    },
}

S_RES_PARTNER_RETURN_GET_PERSON = {
    **S_RES_PARTNER_RETURN_GET,
    "firstname": {"type": "string", "required": False},
    "lastname": {"type": "string", "required": False},
    "email": {"type": "string", "required": False},
    "companies": {
        "type": "list",
        "schema": {
            "type": "dict",
            "required": False,
            "empty": True,
            "schema": S_RES_PARTNER_RETURN_GET_RELATED_COMPANY,
        },
        "required": False,
        "empty": True,
    },
}


S_RES_PARTNER_PUT_RELATED_COMPANY = {
    "company_id": {"type": "integer", "required": True},
    "function": {"type": "string", "required": False, "empty": True},
}

S_RES_PARTNER_PUT = {
    "_id": {"type": "integer", "empty": False},
    "email": {"type": "string", "empty": False},
    "phone": {"type": "string"},
    "iban": {"type": "string", "empty": False},
    "lang": {"type": "string", "empty": False},
    "address": {
        "type": "dict",
        "empty": False,
        "schema": ADDRESS_SCHEMA,
    },
    "companies": {
        "type": "list",
        "required": False,
        "empty": True,
        "schema": {
            "type": "dict",
            "required": False,
            "empty": True,
            "schema": S_RES_PARTNER_PUT_RELATED_COMPANY,
        },
    },
}
