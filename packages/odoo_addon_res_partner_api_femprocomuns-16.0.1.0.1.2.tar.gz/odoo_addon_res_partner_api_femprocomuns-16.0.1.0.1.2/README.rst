==============================
contract_api_femprocomuns
==============================

.. image:: https://img.shields.io/badge/license-AGPL--3-blue.svg
   :target: https://www.gnu.org/licenses/agpl-3.0-standalone.html

Overview
========

API for partner data.

Usage
=====

Expose partner information via API.

Credits
=======

Authors
-------

* Coopdevs Treball SCCL

Maintainers
-----------

This module is maintained by Coopdevs.

License
=======

AGPL-3