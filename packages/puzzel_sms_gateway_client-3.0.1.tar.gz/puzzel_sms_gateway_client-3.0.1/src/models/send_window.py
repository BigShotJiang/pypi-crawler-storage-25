from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SendWindow(Parsable):
    # The startDate property
    start_date: Optional[str] = None
    # The startTime property
    start_time: Optional[str] = None
    # The stopDate property
    stop_date: Optional[str] = None
    # The stopTime property
    stop_time: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SendWindow:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SendWindow
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SendWindow()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "startDate": lambda n : setattr(self, 'start_date', n.get_str_value()),
            "startTime": lambda n : setattr(self, 'start_time', n.get_str_value()),
            "stopDate": lambda n : setattr(self, 'stop_date', n.get_str_value()),
            "stopTime": lambda n : setattr(self, 'stop_time', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("startDate", self.start_date)
        writer.write_str_value("startTime", self.start_time)
        writer.write_str_value("stopDate", self.stop_date)
        writer.write_str_value("stopTime", self.stop_time)
    

