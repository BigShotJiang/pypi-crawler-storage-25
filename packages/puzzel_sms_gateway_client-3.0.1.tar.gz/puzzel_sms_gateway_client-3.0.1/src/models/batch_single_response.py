from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .batch_response import BatchResponse

@dataclass
class BatchSingleResponse(Parsable):
    # The messageBatch property
    message_batch: Optional[BatchResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BatchSingleResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BatchSingleResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BatchSingleResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .batch_response import BatchResponse

        from .batch_response import BatchResponse

        fields: dict[str, Callable[[Any], None]] = {
            "messageBatch": lambda n : setattr(self, 'message_batch', n.get_object_value(BatchResponse)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("messageBatch", self.message_batch)
    

