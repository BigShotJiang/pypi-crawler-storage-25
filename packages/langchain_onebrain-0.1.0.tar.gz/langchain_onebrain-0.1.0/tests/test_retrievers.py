"""Tests for OneBrainRetriever."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document

from langchain_onebrain.retrievers import OneBrainRetriever
from tests.conftest import make_search_response, make_search_result


class TestOneBrainRetrieverInit:
    """Tests for OneBrainRetriever initialization."""

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_init_defaults(self, mock_cls):
        retriever = OneBrainRetriever(api_key="ob_test:secret")
        assert retriever.top_k == 10
        assert retriever.search_mode == "hybrid"
        assert retriever.alpha is None
        mock_cls.assert_called_once_with(api_key="ob_test:secret")

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_init_custom_params(self, mock_cls):
        retriever = OneBrainRetriever(
            api_key="ob_test:secret",
            top_k=5,
            search_mode="vector",
            alpha=0.7,
            base_url="https://custom.api.com",
        )
        assert retriever.top_k == 5
        assert retriever.search_mode == "vector"
        assert retriever.alpha == 0.7
        mock_cls.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_init_without_api_key(self, mock_cls):
        retriever = OneBrainRetriever()
        mock_cls.assert_called_once_with()

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_init_with_base_url_only(self, mock_cls):
        OneBrainRetriever(base_url="https://self-hosted.example.com")
        mock_cls.assert_called_once_with(
            base_url="https://self-hosted.example.com",
        )


class TestOneBrainRetrieverGetRelevantDocuments:
    """Tests for the _get_relevant_documents method."""

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_returns_documents_from_search_results(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        results = [
            make_search_result(
                memory_id="mem_001",
                title="User Preference",
                body="Prefers dark mode",
                memory_type="preference",
                confidence=0.95,
                score=0.88,
                source_type="user_input",
                created_at="2026-01-15T09:30:00Z",
            ),
            make_search_result(
                memory_id="mem_002",
                title="Coding Style",
                body="Uses Python type hints",
                memory_type="fact",
                confidence=0.85,
                score=0.72,
            ),
        ]
        client.memory.search.return_value = make_search_response(results)

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        docs = retriever._get_relevant_documents("preferences", run_manager=run_manager)

        assert len(docs) == 2
        assert isinstance(docs[0], Document)
        assert docs[0].page_content == "Prefers dark mode"
        assert docs[0].metadata["id"] == "mem_001"
        assert docs[0].metadata["title"] == "User Preference"
        assert docs[0].metadata["type"] == "preference"
        assert docs[0].metadata["confidence"] == 0.95
        assert docs[0].metadata["score"] == 0.88
        assert docs[0].metadata["source_type"] == "user_input"
        assert docs[0].metadata["created_at"] == "2026-01-15T09:30:00Z"

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_returns_empty_list_for_no_results(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        docs = retriever._get_relevant_documents("nothing", run_manager=run_manager)

        assert docs == []

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_passes_search_mode_and_top_k(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        retriever = OneBrainRetriever(
            api_key="ob_test:secret",
            top_k=3,
            search_mode="keyword",
        )
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        retriever._get_relevant_documents("test", run_manager=run_manager)

        client.memory.search.assert_called_once_with(
            query="test",
            mode="keyword",
            top_k=3,
        )

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_passes_alpha_when_set(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        retriever = OneBrainRetriever(
            api_key="ob_test:secret",
            alpha=0.6,
        )
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        retriever._get_relevant_documents("test", run_manager=run_manager)

        client.memory.search.assert_called_once_with(
            query="test",
            mode="hybrid",
            top_k=10,
            alpha=0.6,
        )

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_does_not_pass_alpha_when_none(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        retriever._get_relevant_documents("test", run_manager=run_manager)

        call_kwargs = client.memory.search.call_args.kwargs
        assert "alpha" not in call_kwargs

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_handles_response_with_results_key(self, mock_cls):
        """Test when API returns 'results' instead of 'data'."""
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = {
            "results": [
                make_search_result(body="From results key"),
            ],
        }

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        docs = retriever._get_relevant_documents("test", run_manager=run_manager)

        assert len(docs) == 1
        assert docs[0].page_content == "From results key"

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_uses_title_when_body_missing(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([
            {"id": "mem_001", "title": "Fallback Title", "type": "fact"},
        ])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        docs = retriever._get_relevant_documents("test", run_manager=run_manager)

        assert len(docs) == 1
        assert docs[0].page_content == "Fallback Title"

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_metadata_defaults_for_missing_fields(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([
            {"body": "Minimal result"},
        ])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        run_manager = MagicMock(spec=CallbackManagerForRetrieverRun)
        docs = retriever._get_relevant_documents("test", run_manager=run_manager)

        assert docs[0].metadata["id"] == ""
        assert docs[0].metadata["title"] == ""
        assert docs[0].metadata["type"] == ""
        assert docs[0].metadata["confidence"] == 0.0
        assert docs[0].metadata["score"] == 0.0


class TestOneBrainRetrieverInvoke:
    """Tests for the public invoke method."""

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_invoke_calls_get_relevant_documents(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([
            make_search_result(body="Result from invoke"),
        ])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        docs = retriever.invoke("test query")

        assert len(docs) == 1
        assert docs[0].page_content == "Result from invoke"

    @patch("langchain_onebrain.retrievers.OneBrain")
    def test_invoke_with_empty_query(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        docs = retriever.invoke("")

        assert docs == []
        client.memory.search.assert_called_once()
