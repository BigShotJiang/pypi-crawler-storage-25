"""Tests for OneBrainChatMessageHistory."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    message_to_dict,
)

from langchain_onebrain.memory import (
    OneBrainChatMessageHistory,
    _memory_body_to_message,
    _message_to_memory_body,
)
from tests.conftest import make_memory_item, make_paginated_response


class TestMessageSerialization:
    """Tests for message serialization/deserialization helpers."""

    def test_serialize_human_message(self):
        msg = HumanMessage(content="Hello there")
        body = _message_to_memory_body(msg)
        data = json.loads(body)
        assert data["type"] == "human"
        assert data["data"]["content"] == "Hello there"

    def test_serialize_ai_message(self):
        msg = AIMessage(content="Hi! How can I help?")
        body = _message_to_memory_body(msg)
        data = json.loads(body)
        assert data["type"] == "ai"
        assert data["data"]["content"] == "Hi! How can I help?"

    def test_serialize_system_message(self):
        msg = SystemMessage(content="You are a helpful assistant.")
        body = _message_to_memory_body(msg)
        data = json.loads(body)
        assert data["type"] == "system"

    def test_deserialize_human_message(self):
        msg = HumanMessage(content="Test message")
        body = _message_to_memory_body(msg)
        result = _memory_body_to_message(body)
        assert isinstance(result, HumanMessage)
        assert result.content == "Test message"

    def test_deserialize_ai_message(self):
        msg = AIMessage(content="AI response")
        body = _message_to_memory_body(msg)
        result = _memory_body_to_message(body)
        assert isinstance(result, AIMessage)
        assert result.content == "AI response"

    def test_deserialize_system_message(self):
        msg = SystemMessage(content="System prompt")
        body = _message_to_memory_body(msg)
        result = _memory_body_to_message(body)
        assert isinstance(result, SystemMessage)
        assert result.content == "System prompt"

    def test_deserialize_invalid_json_returns_none(self):
        result = _memory_body_to_message("not valid json {{{")
        assert result is None

    def test_deserialize_empty_string_returns_none(self):
        result = _memory_body_to_message("")
        assert result is None

    def test_deserialize_malformed_dict_returns_none(self):
        result = _memory_body_to_message('{"foo": "bar"}')
        assert result is None

    def test_roundtrip_preserves_content(self):
        original = HumanMessage(content="Round-trip test with unicode: umlauts")
        body = _message_to_memory_body(original)
        restored = _memory_body_to_message(body)
        assert restored is not None
        assert restored.content == original.content


class TestOneBrainChatMessageHistoryInit:
    """Tests for OneBrainChatMessageHistory initialization."""

    @patch("langchain_onebrain.memory.OneBrain")
    def test_init_with_api_key(self, mock_cls):
        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        mock_cls.assert_called_once_with(api_key="ob_test:secret")
        assert history.session_id == "sess-1"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_init_with_base_url(self, mock_cls):
        OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
            base_url="https://custom.api.com",
        )
        mock_cls.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )

    @patch("langchain_onebrain.memory.OneBrain")
    def test_init_default_session_id(self, mock_cls):
        history = OneBrainChatMessageHistory(api_key="ob_test:secret")
        assert history.session_id == "default"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_init_without_api_key(self, mock_cls):
        OneBrainChatMessageHistory(session_id="sess-1")
        mock_cls.assert_called_once_with()


class TestOneBrainChatMessageHistoryMessages:
    """Tests for message retrieval."""

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_returns_empty_list_when_no_items(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.list.return_value = make_paginated_response([])

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        assert history.messages == []

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_returns_stored_messages(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        human_msg = HumanMessage(content="Hello")
        ai_msg = AIMessage(content="Hi there")

        items = [
            make_memory_item(
                memory_id="mem_001",
                body=_message_to_memory_body(human_msg),
                metadata={"session_id": "sess-1", "role": "human"},
            ),
            make_memory_item(
                memory_id="mem_002",
                body=_message_to_memory_body(ai_msg),
                metadata={"session_id": "sess-1", "role": "ai"},
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        msgs = history.messages
        assert len(msgs) == 2
        assert isinstance(msgs[0], HumanMessage)
        assert msgs[0].content == "Hello"
        assert isinstance(msgs[1], AIMessage)
        assert msgs[1].content == "Hi there"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_filters_by_session_id(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        items = [
            make_memory_item(
                memory_id="mem_001",
                body=_message_to_memory_body(HumanMessage(content="Right session")),
                metadata={"session_id": "sess-1"},
            ),
            make_memory_item(
                memory_id="mem_002",
                body=_message_to_memory_body(HumanMessage(content="Wrong session")),
                metadata={"session_id": "sess-other"},
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        msgs = history.messages
        assert len(msgs) == 1
        assert msgs[0].content == "Right session"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_handles_pagination(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        page1_items = [
            make_memory_item(
                memory_id="mem_001",
                body=_message_to_memory_body(HumanMessage(content="Page 1")),
                metadata={"session_id": "sess-1"},
            ),
        ]
        page2_items = [
            make_memory_item(
                memory_id="mem_002",
                body=_message_to_memory_body(AIMessage(content="Page 2")),
                metadata={"session_id": "sess-1"},
            ),
        ]

        client.memory.list.side_effect = [
            make_paginated_response(page1_items, cursor="cursor_1", has_more=True),
            make_paginated_response(page2_items, cursor=None, has_more=False),
        ]

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        msgs = history.messages
        assert len(msgs) == 2
        assert msgs[0].content == "Page 1"
        assert msgs[1].content == "Page 2"
        assert client.memory.list.call_count == 2

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_skips_invalid_body(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        items = [
            make_memory_item(
                memory_id="mem_001",
                body="not valid json",
                metadata={"session_id": "sess-1"},
            ),
            make_memory_item(
                memory_id="mem_002",
                body=_message_to_memory_body(HumanMessage(content="Valid")),
                metadata={"session_id": "sess-1"},
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        msgs = history.messages
        assert len(msgs) == 1
        assert msgs[0].content == "Valid"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_messages_handles_missing_metadata(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        items = [
            make_memory_item(
                memory_id="mem_001",
                body=_message_to_memory_body(HumanMessage(content="No metadata")),
                metadata=None,
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        msgs = history.messages
        assert len(msgs) == 0


class TestOneBrainChatMessageHistoryAddMessage:
    """Tests for adding messages."""

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_human_message(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.add_message(HumanMessage(content="Hello world"))

        client.memory.create.assert_called_once()
        call_kwargs = client.memory.create.call_args
        assert call_kwargs.kwargs.get("type") or call_kwargs[1].get("type") == "experience"
        args_dict = {**dict(zip(["type", "title", "body"], call_kwargs.args)), **call_kwargs.kwargs}
        assert args_dict["type"] == "experience"
        assert "sess-1" in args_dict["title"]
        assert "human" in args_dict["title"]
        body_data = json.loads(args_dict["body"])
        assert body_data["data"]["content"] == "Hello world"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_ai_message(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.add_message(AIMessage(content="I can help!"))

        client.memory.create.assert_called_once()
        call_args = client.memory.create.call_args
        args_dict = {**dict(zip(["type", "title", "body"], call_args.args)), **call_args.kwargs}
        assert "ai" in args_dict["title"]

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_message_includes_metadata(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-42",
        )
        history.add_message(HumanMessage(content="Test"))

        call_args = client.memory.create.call_args
        args_dict = {**dict(zip(["type", "title", "body"], call_args.args)), **call_args.kwargs}
        metadata = args_dict["metadata"]
        assert metadata["session_id"] == "sess-42"
        assert metadata["role"] == "human"
        assert metadata["langchain_type"] == "human"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_messages_calls_create_for_each(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        messages = [
            HumanMessage(content="First"),
            AIMessage(content="Second"),
            HumanMessage(content="Third"),
        ]
        history.add_messages(messages)
        assert client.memory.create.call_count == 3

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_messages_empty_list(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.add_messages([])
        client.memory.create.assert_not_called()

    @patch("langchain_onebrain.memory.OneBrain")
    def test_add_message_truncates_long_title(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="s",
        )
        long_content = "A" * 200
        history.add_message(HumanMessage(content=long_content))

        call_args = client.memory.create.call_args
        args_dict = {**dict(zip(["type", "title", "body"], call_args.args)), **call_args.kwargs}
        assert len(args_dict["title"]) < 200


class TestOneBrainChatMessageHistoryClear:
    """Tests for clearing message history."""

    @patch("langchain_onebrain.memory.OneBrain")
    def test_clear_archives_session_memories(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        items = [
            make_memory_item(
                memory_id="mem_001",
                metadata={"session_id": "sess-1"},
            ),
            make_memory_item(
                memory_id="mem_002",
                metadata={"session_id": "sess-1"},
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.clear()

        assert client.memory.update.call_count == 2
        for call in client.memory.update.call_args_list:
            assert call.kwargs.get("status") == "archived" or call[1].get("status") == "archived"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_clear_skips_other_sessions(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        items = [
            make_memory_item(
                memory_id="mem_001",
                metadata={"session_id": "sess-1"},
            ),
            make_memory_item(
                memory_id="mem_002",
                metadata={"session_id": "sess-other"},
            ),
        ]
        client.memory.list.return_value = make_paginated_response(items)

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.clear()

        assert client.memory.update.call_count == 1
        call_args = client.memory.update.call_args
        assert call_args.args[0] == "mem_001" or call_args[0][0] == "mem_001"

    @patch("langchain_onebrain.memory.OneBrain")
    def test_clear_handles_empty_results(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.list.return_value = make_paginated_response([])

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.clear()

        client.memory.update.assert_not_called()

    @patch("langchain_onebrain.memory.OneBrain")
    def test_clear_handles_pagination(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        page1 = [
            make_memory_item(
                memory_id="mem_001",
                metadata={"session_id": "sess-1"},
            ),
        ]
        page2 = [
            make_memory_item(
                memory_id="mem_002",
                metadata={"session_id": "sess-1"},
            ),
        ]
        client.memory.list.side_effect = [
            make_paginated_response(page1, cursor="c1", has_more=True),
            make_paginated_response(page2, cursor=None, has_more=False),
        ]

        history = OneBrainChatMessageHistory(
            api_key="ob_test:secret",
            session_id="sess-1",
        )
        history.clear()

        assert client.memory.update.call_count == 2
