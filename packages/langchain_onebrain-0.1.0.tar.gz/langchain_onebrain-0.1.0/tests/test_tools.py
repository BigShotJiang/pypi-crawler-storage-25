"""Tests for OneBrain LangChain tools."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from pydantic import BaseModel

from langchain_onebrain.tools import (
    ContextInput,
    EntityInput,
    OneBrainContextTool,
    OneBrainEntityTool,
    OneBrainSearchTool,
    OneBrainWriteTool,
    SearchInput,
    WriteInput,
)
from tests.conftest import (
    make_entity_item,
    make_paginated_response,
    make_search_response,
    make_search_result,
)


# ── Input Schema Tests ───────────────────────────────────


class TestSearchInputSchema:
    """Tests for SearchInput schema."""

    def test_default_values(self):
        schema = SearchInput(query="test")
        assert schema.query == "test"
        assert schema.top_k == 10
        assert schema.mode == "hybrid"

    def test_custom_values(self):
        schema = SearchInput(query="hello", top_k=5, mode="vector")
        assert schema.query == "hello"
        assert schema.top_k == 5
        assert schema.mode == "vector"

    def test_schema_fields_documented(self):
        fields = SearchInput.model_fields
        assert "query" in fields
        assert "top_k" in fields
        assert "mode" in fields
        assert fields["query"].description is not None


class TestWriteInputSchema:
    """Tests for WriteInput schema."""

    def test_default_values(self):
        schema = WriteInput(title="Test", body="Body")
        assert schema.title == "Test"
        assert schema.body == "Body"
        assert schema.memory_type == "fact"

    def test_custom_type(self):
        schema = WriteInput(title="Test", body="Body", memory_type="preference")
        assert schema.memory_type == "preference"

    def test_schema_fields_documented(self):
        fields = WriteInput.model_fields
        assert "title" in fields
        assert "body" in fields
        assert "memory_type" in fields


class TestContextInputSchema:
    """Tests for ContextInput schema."""

    def test_default_scope(self):
        schema = ContextInput()
        assert schema.scope == "deep"

    def test_custom_scope(self):
        schema = ContextInput(scope="brief")
        assert schema.scope == "brief"


class TestEntityInputSchema:
    """Tests for EntityInput schema."""

    def test_default_values(self):
        schema = EntityInput()
        assert schema.entity_type is None
        assert schema.limit == 20

    def test_custom_values(self):
        schema = EntityInput(entity_type="person", limit=5)
        assert schema.entity_type == "person"
        assert schema.limit == 5


# ── OneBrainSearchTool Tests ────────────────────────────


class TestOneBrainSearchTool:
    """Tests for OneBrainSearchTool."""

    @patch("langchain_onebrain.tools.OneBrain")
    def test_tool_metadata(self, mock_cls):
        tool = OneBrainSearchTool(api_key="ob_test:secret")
        assert tool.name == "onebrain_search"
        assert "Search" in tool.description or "search" in tool.description
        assert tool.args_schema == SearchInput

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_formatted_results(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        results = [
            make_search_result(
                memory_id="mem_001",
                title="Dark Mode",
                body="User prefers dark mode",
                memory_type="preference",
                score=0.92,
            ),
            make_search_result(
                memory_id="mem_002",
                title="Python",
                body="Loves Python programming",
                memory_type="fact",
                score=0.78,
            ),
        ]
        client.memory.search.return_value = make_search_response(results)

        tool = OneBrainSearchTool(api_key="ob_test:secret")
        output = tool._run(query="preferences", top_k=10, mode="hybrid")

        assert "Dark Mode" in output
        assert "User prefers dark mode" in output
        assert "0.92" in output
        assert "Python" in output
        assert "Loves Python programming" in output
        client.memory.search.assert_called_once_with(
            query="preferences",
            top_k=10,
            mode="hybrid",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_no_results_message(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        tool = OneBrainSearchTool(api_key="ob_test:secret")
        output = tool._run(query="nonexistent")

        assert "No memories found" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_with_custom_params(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([])

        tool = OneBrainSearchTool(api_key="ob_test:secret")
        tool._run(query="test", top_k=3, mode="keyword")

        client.memory.search.assert_called_once_with(
            query="test",
            top_k=3,
            mode="keyword",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_invoke_with_dict_input(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = make_search_response([
            make_search_result(title="Test", body="Result"),
        ])

        tool = OneBrainSearchTool(api_key="ob_test:secret")
        output = tool.invoke({"query": "test"})

        assert "Test" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_init_with_base_url(self, mock_cls):
        OneBrainSearchTool(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )
        mock_cls.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_handles_results_key_in_response(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.search.return_value = {
            "results": [
                make_search_result(title="Via Results", body="Content"),
            ]
        }

        tool = OneBrainSearchTool(api_key="ob_test:secret")
        output = tool._run(query="test")
        assert "Via Results" in output


# ── OneBrainWriteTool Tests ─────────────────────────────


class TestOneBrainWriteTool:
    """Tests for OneBrainWriteTool."""

    @patch("langchain_onebrain.tools.OneBrain")
    def test_tool_metadata(self, mock_cls):
        tool = OneBrainWriteTool(api_key="ob_test:secret")
        assert tool.name == "onebrain_write"
        assert "Store" in tool.description or "memory" in tool.description
        assert tool.args_schema == WriteInput

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_creates_memory(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.create.return_value = {
            "data": {"id": "mem_new_001", "title": "Test"},
        }

        tool = OneBrainWriteTool(api_key="ob_test:secret")
        output = tool._run(
            title="User Preference",
            body="Prefers dark mode",
            memory_type="preference",
        )

        assert "mem_new_001" in output
        assert "successfully" in output.lower() or "created" in output.lower()
        client.memory.create.assert_called_once_with(
            type="preference",
            title="User Preference",
            body="Prefers dark mode",
            source_type="ai_extraction",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_with_default_type(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.create.return_value = {"data": {"id": "mem_002"}}

        tool = OneBrainWriteTool(api_key="ob_test:secret")
        tool._run(title="Fact", body="The sky is blue")

        call_args = client.memory.create.call_args
        assert call_args.kwargs["type"] == "fact"

    @patch("langchain_onebrain.tools.OneBrain")
    def test_invoke_with_dict_input(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.create.return_value = {"data": {"id": "mem_003"}}

        tool = OneBrainWriteTool(api_key="ob_test:secret")
        output = tool.invoke({
            "title": "Test",
            "body": "Content",
            "memory_type": "goal",
        })

        assert "mem_003" in output
        client.memory.create.assert_called_once_with(
            type="goal",
            title="Test",
            body="Content",
            source_type="ai_extraction",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_handles_flat_response(self, mock_cls):
        """Test when API returns id at top level instead of data.id."""
        client = MagicMock()
        mock_cls.return_value = client
        client.memory.create.return_value = {"id": "mem_flat"}

        tool = OneBrainWriteTool(api_key="ob_test:secret")
        output = tool._run(title="Test", body="Content")

        assert "mem_flat" in output


# ── OneBrainContextTool Tests ────────────────────────────


class TestOneBrainContextTool:
    """Tests for OneBrainContextTool."""

    @patch("langchain_onebrain.tools.OneBrain")
    def test_tool_metadata(self, mock_cls):
        tool = OneBrainContextTool(api_key="ob_test:secret")
        assert tool.name == "onebrain_context"
        assert "context" in tool.description.lower()
        assert tool.args_schema == ContextInput

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_formatted_context(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "data": {
                "formatted": "User is a software engineer who prefers Python.",
                "structured": {},
                "meta": {"scope": "deep", "token_estimate": 50},
            },
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        output = tool._run(scope="deep")

        assert "software engineer" in output
        client.context.get.assert_called_once_with(scope="deep")

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_falls_back_to_structured(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "data": {
                "formatted": "",
                "structured": {"preferences": {"theme": "dark"}},
            },
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        output = tool._run(scope="brief")

        assert "dark" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_no_context_message(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "data": {
                "formatted": "",
                "structured": {},
            },
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        output = tool._run(scope="deep")

        assert "No context available" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_with_default_scope(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "data": {"formatted": "Some context"},
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        tool._run()

        client.context.get.assert_called_once_with(scope="deep")

    @patch("langchain_onebrain.tools.OneBrain")
    def test_invoke_with_dict_input(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "data": {"formatted": "Brief context"},
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        output = tool.invoke({"scope": "brief"})

        assert "Brief context" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_handles_flat_response(self, mock_cls):
        """Test when API returns formatted at top level."""
        client = MagicMock()
        mock_cls.return_value = client
        client.context.get.return_value = {
            "formatted": "Top-level formatted",
            "structured": {},
        }

        tool = OneBrainContextTool(api_key="ob_test:secret")
        output = tool._run()

        assert "Top-level formatted" in output


# ── OneBrainEntityTool Tests ─────────────────────────────


class TestOneBrainEntityTool:
    """Tests for OneBrainEntityTool."""

    @patch("langchain_onebrain.tools.OneBrain")
    def test_tool_metadata(self, mock_cls):
        tool = OneBrainEntityTool(api_key="ob_test:secret")
        assert tool.name == "onebrain_entity"
        assert "entit" in tool.description.lower()
        assert tool.args_schema == EntityInput

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_formatted_entities(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client

        entities = [
            make_entity_item(
                entity_id="ent_001",
                name="Alice",
                entity_type="person",
                description="Software engineer",
            ),
            make_entity_item(
                entity_id="ent_002",
                name="Acme Corp",
                entity_type="organization",
                description="Tech company",
            ),
        ]
        client.entity.list.return_value = make_paginated_response(entities)

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        output = tool._run()

        assert "Alice" in output
        assert "person" in output
        assert "Software engineer" in output
        assert "Acme Corp" in output
        assert "organization" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_returns_no_entities_message(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = make_paginated_response([])

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        output = tool._run()

        assert "No entities found" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_with_type_filter(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = make_paginated_response([])

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        tool._run(entity_type="person", limit=5)

        client.entity.list.assert_called_once_with(
            limit=5,
            type="person",
        )

    @patch("langchain_onebrain.tools.OneBrain")
    def test_run_without_type_filter(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = make_paginated_response([])

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        tool._run()

        client.entity.list.assert_called_once_with(limit=20)

    @patch("langchain_onebrain.tools.OneBrain")
    def test_invoke_with_dict_input(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = make_paginated_response([
            make_entity_item(name="Bob"),
        ])

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        output = tool.invoke({"entity_type": "person", "limit": 10})

        assert "Bob" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_handles_entities_without_description(self, mock_cls):
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = make_paginated_response([
            {
                "id": "ent_001",
                "name": "No Desc",
                "type": "tool",
                "description": "",
            },
        ])

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        output = tool._run()

        assert "No Desc" in output
        assert "[tool]" in output

    @patch("langchain_onebrain.tools.OneBrain")
    def test_handles_items_key_in_response(self, mock_cls):
        """Test when API returns 'items' instead of 'data'."""
        client = MagicMock()
        mock_cls.return_value = client
        client.entity.list.return_value = {
            "items": [make_entity_item(name="From Items")],
            "meta": {"hasMore": False, "total": 1},
        }

        tool = OneBrainEntityTool(api_key="ob_test:secret")
        output = tool._run()

        assert "From Items" in output


# ── Cross-Cutting Tool Tests ─────────────────────────────


class TestToolsCommon:
    """Tests for common tool behavior across all tools."""

    @patch("langchain_onebrain.tools.OneBrain")
    def test_all_tools_have_name(self, mock_cls):
        tools = [
            OneBrainSearchTool(api_key="ob_test:secret"),
            OneBrainWriteTool(api_key="ob_test:secret"),
            OneBrainContextTool(api_key="ob_test:secret"),
            OneBrainEntityTool(api_key="ob_test:secret"),
        ]
        names = {t.name for t in tools}
        assert len(names) == 4
        for tool in tools:
            assert isinstance(tool.name, str)
            assert len(tool.name) > 0

    @patch("langchain_onebrain.tools.OneBrain")
    def test_all_tools_have_description(self, mock_cls):
        tools = [
            OneBrainSearchTool(api_key="ob_test:secret"),
            OneBrainWriteTool(api_key="ob_test:secret"),
            OneBrainContextTool(api_key="ob_test:secret"),
            OneBrainEntityTool(api_key="ob_test:secret"),
        ]
        for tool in tools:
            assert isinstance(tool.description, str)
            assert len(tool.description) > 10

    @patch("langchain_onebrain.tools.OneBrain")
    def test_all_tools_have_args_schema(self, mock_cls):
        tools = [
            OneBrainSearchTool(api_key="ob_test:secret"),
            OneBrainWriteTool(api_key="ob_test:secret"),
            OneBrainContextTool(api_key="ob_test:secret"),
            OneBrainEntityTool(api_key="ob_test:secret"),
        ]
        for tool in tools:
            assert tool.args_schema is not None
            assert issubclass(tool.args_schema, BaseModel)

    @patch("langchain_onebrain.tools.OneBrain")
    def test_all_tools_unique_names(self, mock_cls):
        tools = [
            OneBrainSearchTool(api_key="ob_test:secret"),
            OneBrainWriteTool(api_key="ob_test:secret"),
            OneBrainContextTool(api_key="ob_test:secret"),
            OneBrainEntityTool(api_key="ob_test:secret"),
        ]
        names = [t.name for t in tools]
        assert len(names) == len(set(names))
