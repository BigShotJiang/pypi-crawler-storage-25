"""Shared test fixtures for langchain-onebrain tests."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest


def make_memory_item(
    memory_id: str = "mem_001",
    title: str = "Test Memory",
    body: str = "Test body content",
    memory_type: str = "fact",
    confidence: float = 0.9,
    status: str = "active",
    source_type: str = "user_input",
    metadata: Optional[Dict[str, Any]] = None,
    created_at: str = "2026-01-15T09:30:00Z",
    updated_at: str = "2026-01-15T09:30:00Z",
) -> Dict[str, Any]:
    """Create a mock memory item dictionary."""
    return {
        "id": memory_id,
        "user_id": "user_001",
        "type": memory_type,
        "title": title,
        "body": body,
        "source_type": source_type,
        "confidence": confidence,
        "status": status,
        "metadata": metadata or {},
        "created_at": created_at,
        "updated_at": updated_at,
    }


def make_entity_item(
    entity_id: str = "ent_001",
    name: str = "Test Entity",
    entity_type: str = "person",
    description: str = "A test entity",
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Create a mock entity item dictionary."""
    return {
        "id": entity_id,
        "user_id": "user_001",
        "name": name,
        "type": entity_type,
        "description": description,
        "metadata": metadata or {},
        "created_at": "2026-01-15T09:30:00Z",
        "updated_at": "2026-01-15T09:30:00Z",
    }


def make_search_result(
    memory_id: str = "mem_001",
    title: str = "Test Memory",
    body: str = "Test body content",
    memory_type: str = "fact",
    confidence: float = 0.9,
    score: float = 0.85,
    source_type: str = "user_input",
    created_at: str = "2026-01-15T09:30:00Z",
) -> Dict[str, Any]:
    """Create a mock search result dictionary."""
    return {
        "id": memory_id,
        "title": title,
        "body": body,
        "type": memory_type,
        "confidence": confidence,
        "score": score,
        "source_type": source_type,
        "created_at": created_at,
    }


def make_paginated_response(
    items: List[Dict[str, Any]],
    cursor: Optional[str] = None,
    has_more: bool = False,
    total: int = 0,
) -> Dict[str, Any]:
    """Create a mock paginated API response."""
    return {
        "data": items,
        "meta": {
            "cursor": cursor,
            "hasMore": has_more,
            "total": total or len(items),
        },
    }


def make_search_response(
    results: List[Dict[str, Any]],
    mode: str = "hybrid",
) -> Dict[str, Any]:
    """Create a mock search API response."""
    return {
        "data": results,
        "search_mode": mode,
    }


@pytest.fixture
def mock_onebrain_client():
    """Create a mock OneBrain client with all resource mocks."""
    with patch("onebrain.OneBrain") as mock_cls:
        client = MagicMock()
        client.memory = MagicMock()
        client.entity = MagicMock()
        client.context = MagicMock()
        client.brain = MagicMock()
        client.connect = MagicMock()
        mock_cls.return_value = client
        yield client


@pytest.fixture
def api_key() -> str:
    """Return a test API key."""
    return "ob_test:secret_key_for_testing"
