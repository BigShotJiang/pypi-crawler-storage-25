"""OneBrain tools for LangChain agents."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Type

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr

from onebrain import OneBrain


# ── Input Schemas ────────────────────────────────────────


class SearchInput(BaseModel):
    """Input schema for OneBrainSearchTool."""

    query: str = Field(description="The search query string.")
    top_k: int = Field(
        default=10,
        ge=1,
        le=100,
        description="Maximum number of results to return.",
    )
    mode: str = Field(
        default="hybrid",
        description=(
            "Search mode: 'keyword', 'vector', or 'hybrid'."
        ),
    )


class WriteInput(BaseModel):
    """Input schema for OneBrainWriteTool."""

    title: str = Field(description="Short descriptive title for the memory.")
    body: str = Field(description="Full content of the memory.")
    memory_type: str = Field(
        default="fact",
        description=(
            "Memory type: 'fact', 'preference', 'decision', "
            "'goal', 'experience', or 'skill'."
        ),
    )


class ContextInput(BaseModel):
    """Input schema for OneBrainContextTool."""

    scope: str = Field(
        default="deep",
        description=(
            "Context scope: 'brief', 'assistant', 'project', or 'deep'."
        ),
    )


class EntityInput(BaseModel):
    """Input schema for OneBrainEntityTool."""

    entity_type: Optional[str] = Field(
        default=None,
        description="Filter entities by type (e.g., 'person', 'organization').",
    )
    limit: int = Field(
        default=20,
        ge=1,
        le=100,
        description="Maximum number of entities to return.",
    )


# ── Helper ───────────────────────────────────────────────


def _build_client(
    api_key: Optional[str],
    base_url: Optional[str],
) -> OneBrain:
    """Create an OneBrain client with optional overrides."""
    kwargs: Dict[str, Any] = {}
    if api_key is not None:
        kwargs["api_key"] = api_key
    if base_url is not None:
        kwargs["base_url"] = base_url
    return OneBrain(**kwargs)


# ── Tools ────────────────────────────────────────────────


class OneBrainSearchTool(BaseTool):
    """Search OneBrain memories using keyword, vector, or hybrid search.

    This tool allows LangChain agents to search through stored memories
    in OneBrain, returning the most relevant results for a given query.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        base_url: Base URL of the OneBrain API.

    Example::

        from langchain_onebrain import OneBrainSearchTool

        tool = OneBrainSearchTool(api_key="ob_xxx:secret")
        result = tool.invoke({"query": "user preferences", "top_k": 5})
    """

    name: str = "onebrain_search"
    description: str = (
        "Search through OneBrain memories to find relevant information. "
        "Use this when you need to recall past conversations, facts, "
        "preferences, or any stored knowledge."
    )
    args_schema: Type[BaseModel] = SearchInput

    api_key: Optional[str] = Field(default=None, exclude=True)
    base_url: Optional[str] = Field(default=None, exclude=True)

    _client: OneBrain = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        """Initialize the OneBrain client."""
        self._client = _build_client(self.api_key, self.base_url)

    def _run(
        self,
        query: str,
        top_k: int = 10,
        mode: str = "hybrid",
        *,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Execute a memory search and return formatted results.

        Args:
            query: The search query.
            top_k: Max results.
            mode: Search mode.
            run_manager: Callback manager.

        Returns:
            Formatted string of search results.
        """
        response = self._client.memory.search(
            query=query,
            top_k=top_k,
            mode=mode,
        )
        results = response.get("data", response.get("results", []))

        if not results:
            return "No memories found matching the query."

        lines: List[str] = []
        for idx, item in enumerate(results, 1):
            title = item.get("title", "Untitled")
            body = item.get("body", "")
            score = item.get("score", 0.0)
            mem_type = item.get("type", "unknown")
            lines.append(
                f"{idx}. [{mem_type}] {title} (score: {score:.2f})\n"
                f"   {body}"
            )
        return "\n\n".join(lines)


class OneBrainWriteTool(BaseTool):
    """Write a new memory to OneBrain.

    This tool allows LangChain agents to persist new information as
    OneBrain memory items for future recall.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        base_url: Base URL of the OneBrain API.

    Example::

        from langchain_onebrain import OneBrainWriteTool

        tool = OneBrainWriteTool(api_key="ob_xxx:secret")
        result = tool.invoke({
            "title": "User preference",
            "body": "The user prefers dark mode.",
            "memory_type": "preference",
        })
    """

    name: str = "onebrain_write"
    description: str = (
        "Store a new memory in OneBrain. Use this to save important "
        "information, user preferences, decisions, goals, or any "
        "knowledge that should be remembered for future conversations."
    )
    args_schema: Type[BaseModel] = WriteInput

    api_key: Optional[str] = Field(default=None, exclude=True)
    base_url: Optional[str] = Field(default=None, exclude=True)

    _client: OneBrain = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        """Initialize the OneBrain client."""
        self._client = _build_client(self.api_key, self.base_url)

    def _run(
        self,
        title: str,
        body: str,
        memory_type: str = "fact",
        *,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Create a new memory item in OneBrain.

        Args:
            title: Memory title.
            body: Memory content.
            memory_type: Type of memory.
            run_manager: Callback manager.

        Returns:
            Confirmation string with the created memory ID.
        """
        result = self._client.memory.create(
            type=memory_type,
            title=title,
            body=body,
            source_type="ai_extraction",
        )
        data = result.get("data", result)
        memory_id = data.get("id", "unknown")
        return f"Memory created successfully (id: {memory_id})."


class OneBrainContextTool(BaseTool):
    """Retrieve user context from OneBrain.

    This tool allows LangChain agents to fetch optimized context about
    the user, including their profile, preferences, and relevant memories.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        base_url: Base URL of the OneBrain API.

    Example::

        from langchain_onebrain import OneBrainContextTool

        tool = OneBrainContextTool(api_key="ob_xxx:secret")
        result = tool.invoke({"scope": "brief"})
    """

    name: str = "onebrain_context"
    description: str = (
        "Get the user's context from OneBrain. Returns a summary of "
        "the user's profile, preferences, and relevant memories. "
        "Use 'brief' for a short overview or 'deep' for comprehensive context."
    )
    args_schema: Type[BaseModel] = ContextInput

    api_key: Optional[str] = Field(default=None, exclude=True)
    base_url: Optional[str] = Field(default=None, exclude=True)

    _client: OneBrain = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        """Initialize the OneBrain client."""
        self._client = _build_client(self.api_key, self.base_url)

    def _run(
        self,
        scope: str = "deep",
        *,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Retrieve context for the given scope.

        Args:
            scope: Context scope level.
            run_manager: Callback manager.

        Returns:
            Formatted context string.
        """
        response = self._client.context.get(scope=scope)
        data = response.get("data", response)
        formatted = data.get("formatted", "")
        if formatted:
            return formatted

        structured = data.get("structured", {})
        if structured:
            import json
            return json.dumps(structured, indent=2, ensure_ascii=False)

        return "No context available."


class OneBrainEntityTool(BaseTool):
    """Search and list entities in OneBrain.

    This tool allows LangChain agents to discover people, organizations,
    tools, and other entities tracked in OneBrain.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        base_url: Base URL of the OneBrain API.

    Example::

        from langchain_onebrain import OneBrainEntityTool

        tool = OneBrainEntityTool(api_key="ob_xxx:secret")
        result = tool.invoke({"entity_type": "person", "limit": 5})
    """

    name: str = "onebrain_entity"
    description: str = (
        "List entities (people, organizations, tools, etc.) stored in "
        "OneBrain. Use this to find information about known contacts, "
        "companies, or other tracked objects."
    )
    args_schema: Type[BaseModel] = EntityInput

    api_key: Optional[str] = Field(default=None, exclude=True)
    base_url: Optional[str] = Field(default=None, exclude=True)

    _client: OneBrain = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        """Initialize the OneBrain client."""
        self._client = _build_client(self.api_key, self.base_url)

    def _run(
        self,
        entity_type: Optional[str] = None,
        limit: int = 20,
        *,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """List entities from OneBrain.

        Args:
            entity_type: Filter by entity type.
            limit: Max results.
            run_manager: Callback manager.

        Returns:
            Formatted string of entity results.
        """
        kwargs: Dict[str, Any] = {"limit": limit}
        if entity_type is not None:
            kwargs["type"] = entity_type

        response = self._client.entity.list(**kwargs)
        items = response.get("data", response.get("items", []))

        if not items:
            return "No entities found."

        lines: List[str] = []
        for idx, entity in enumerate(items, 1):
            name = entity.get("name", "Unknown")
            etype = entity.get("type", "unknown")
            desc = entity.get("description", "")
            line = f"{idx}. [{etype}] {name}"
            if desc:
                line += f" - {desc}"
            lines.append(line)

        return "\n".join(lines)
