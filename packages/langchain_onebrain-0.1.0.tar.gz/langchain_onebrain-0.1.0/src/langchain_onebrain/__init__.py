"""LangChain integration for OneBrain — persistent AI memory layer.

Provides chat message history, retriever, and agent tools that connect
LangChain to the OneBrain memory platform via the official Python SDK.

Example::

    from langchain_onebrain import (
        OneBrainChatMessageHistory,
        OneBrainRetriever,
        OneBrainSearchTool,
        OneBrainWriteTool,
        OneBrainContextTool,
        OneBrainEntityTool,
    )
"""

from langchain_onebrain._version import __version__
from langchain_onebrain.memory import OneBrainChatMessageHistory
from langchain_onebrain.retrievers import OneBrainRetriever
from langchain_onebrain.tools import (
    OneBrainContextTool,
    OneBrainEntityTool,
    OneBrainSearchTool,
    OneBrainWriteTool,
)

__all__ = [
    "__version__",
    "OneBrainChatMessageHistory",
    "OneBrainRetriever",
    "OneBrainSearchTool",
    "OneBrainWriteTool",
    "OneBrainContextTool",
    "OneBrainEntityTool",
]
