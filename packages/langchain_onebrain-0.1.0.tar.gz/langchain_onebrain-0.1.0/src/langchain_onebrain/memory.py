"""OneBrain chat message history for LangChain."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Sequence

from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    messages_from_dict,
    message_to_dict,
)

from onebrain import OneBrain

logger = logging.getLogger(__name__)

_ROLE_MAP = {
    "human": "human",
    "ai": "ai",
    "system": "system",
}

_CLASS_MAP = {
    "human": HumanMessage,
    "ai": AIMessage,
    "system": SystemMessage,
}


def _message_to_memory_body(message: BaseMessage) -> str:
    """Serialize a LangChain message to a JSON string for storage."""
    return json.dumps(message_to_dict(message), ensure_ascii=False)


def _memory_body_to_message(body: str) -> Optional[BaseMessage]:
    """Deserialize a JSON string from OneBrain memory back to a message."""
    try:
        data = json.loads(body)
        msgs = messages_from_dict([data])
        return msgs[0] if msgs else None
    except (json.JSONDecodeError, KeyError, IndexError):
        logger.warning("Failed to deserialize memory body: %s", body[:80])
        return None


class OneBrainChatMessageHistory(BaseChatMessageHistory):
    """Chat message history backed by OneBrain memory storage.

    Stores each chat message as an individual OneBrain memory item,
    enabling persistent conversation history across sessions.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        session_id: Unique identifier for this conversation session.
            Used to tag and filter memories belonging to the same chat.
        base_url: Base URL of the OneBrain API. Defaults to the
            official EU endpoint.

    Example::

        from langchain_onebrain import OneBrainChatMessageHistory

        history = OneBrainChatMessageHistory(
            api_key="ob_xxx:secret",
            session_id="session-123",
        )
        history.add_user_message("Hello!")
        history.add_ai_message("Hi there!")
        print(history.messages)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        session_id: str = "default",
        base_url: Optional[str] = None,
    ) -> None:
        kwargs: Dict[str, Any] = {}
        if api_key is not None:
            kwargs["api_key"] = api_key
        if base_url is not None:
            kwargs["base_url"] = base_url
        self._client = OneBrain(**kwargs)
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        """Return the session identifier."""
        return self._session_id

    @property
    def messages(self) -> List[BaseMessage]:
        """Retrieve all messages for this session from OneBrain.

        Returns:
            Ordered list of BaseMessage instances.
        """
        result: List[BaseMessage] = []
        cursor: Optional[str] = None
        has_more = True

        while has_more:
            response = self._client.memory.list(
                type="experience",
                search=self._session_id,
                cursor=cursor,
                limit=100,
            )
            items = response.get("data", response.get("items", []))
            for item in items:
                metadata = item.get("metadata") or {}
                if metadata.get("session_id") != self._session_id:
                    continue
                body = item.get("body", "")
                msg = _memory_body_to_message(body)
                if msg is not None:
                    result.append(msg)

            meta = response.get("meta", response)
            has_more = meta.get("hasMore", meta.get("has_more", False))
            cursor = meta.get("cursor")
            if not cursor:
                has_more = False

        return result

    def add_message(self, message: BaseMessage) -> None:
        """Persist a single message to OneBrain.

        Args:
            message: The LangChain message to store.
        """
        msg_type = message.type
        role = _ROLE_MAP.get(msg_type, msg_type)
        title = f"[{self._session_id}] {role}: {str(message.content)[:60]}"
        body = _message_to_memory_body(message)

        self._client.memory.create(
            type="experience",
            title=title,
            body=body,
            source_type="ai_extraction",
            metadata={
                "session_id": self._session_id,
                "role": role,
                "langchain_type": msg_type,
            },
        )

    def add_messages(self, messages: Sequence[BaseMessage]) -> None:
        """Persist multiple messages to OneBrain.

        Args:
            messages: Sequence of LangChain messages to store.
        """
        for message in messages:
            self.add_message(message)

    def clear(self) -> None:
        """Archive all messages for this session.

        Marks session memories as archived rather than deleting them,
        preserving history for audit purposes.
        """
        cursor: Optional[str] = None
        has_more = True

        while has_more:
            response = self._client.memory.list(
                type="experience",
                search=self._session_id,
                cursor=cursor,
                limit=100,
            )
            items = response.get("data", response.get("items", []))
            for item in items:
                metadata = item.get("metadata") or {}
                if metadata.get("session_id") != self._session_id:
                    continue
                memory_id = item.get("id", "")
                if memory_id:
                    self._client.memory.update(
                        memory_id,
                        status="archived",
                    )

            meta = response.get("meta", response)
            has_more = meta.get("hasMore", meta.get("has_more", False))
            cursor = meta.get("cursor")
            if not cursor:
                has_more = False
