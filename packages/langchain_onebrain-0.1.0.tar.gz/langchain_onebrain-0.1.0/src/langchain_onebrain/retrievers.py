"""OneBrain retriever for LangChain."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import Field, PrivateAttr

from onebrain import OneBrain


class OneBrainRetriever(BaseRetriever):
    """LangChain retriever that searches OneBrain memories.

    Uses OneBrain's deep search (keyword, vector, or hybrid) to find
    relevant memories and return them as LangChain Document objects.

    Args:
        api_key: OneBrain API key. Falls back to the ONEBRAIN_API_KEY
            environment variable when None.
        top_k: Maximum number of results to return. Defaults to 10.
        search_mode: Search mode — one of 'keyword', 'vector', or
            'hybrid'. Defaults to 'hybrid'.
        base_url: Base URL of the OneBrain API.
        alpha: Balance between keyword and vector search (0.0-1.0).
            Only used in hybrid mode.

    Example::

        from langchain_onebrain import OneBrainRetriever

        retriever = OneBrainRetriever(
            api_key="ob_xxx:secret",
            top_k=5,
            search_mode="hybrid",
        )
        docs = retriever.invoke("user preferences")
        for doc in docs:
            print(doc.page_content, doc.metadata)
    """

    api_key: Optional[str] = Field(default=None, exclude=True)
    top_k: int = Field(default=10, ge=1, le=100)
    search_mode: str = Field(default="hybrid")
    base_url: Optional[str] = Field(default=None, exclude=True)
    alpha: Optional[float] = Field(default=None, ge=0.0, le=1.0)

    _client: OneBrain = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        """Initialize the OneBrain client after pydantic validation."""
        kwargs: Dict[str, Any] = {}
        if self.api_key is not None:
            kwargs["api_key"] = self.api_key
        if self.base_url is not None:
            kwargs["base_url"] = self.base_url
        self._client = OneBrain(**kwargs)

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> List[Document]:
        """Search OneBrain memories and return matching documents.

        Args:
            query: The search query string.
            run_manager: Callback manager (required by LangChain).

        Returns:
            List of Document objects with memory content and metadata.
        """
        search_kwargs: Dict[str, Any] = {
            "query": query,
            "mode": self.search_mode,
            "top_k": self.top_k,
        }
        if self.alpha is not None:
            search_kwargs["alpha"] = self.alpha

        response = self._client.memory.search(**search_kwargs)
        results = response.get("data", response.get("results", []))

        documents: List[Document] = []
        for item in results:
            content = item.get("body", item.get("title", ""))
            metadata: Dict[str, Any] = {
                "id": item.get("id", ""),
                "title": item.get("title", ""),
                "type": item.get("type", ""),
                "confidence": item.get("confidence", 0.0),
                "score": item.get("score", 0.0),
                "source_type": item.get("source_type", ""),
                "created_at": item.get("created_at", ""),
            }
            documents.append(
                Document(page_content=content, metadata=metadata)
            )

        return documents
