<div align="center">

# strange

<img
    src="./docs/content/img/strange_logo.svg"
    alt="strange logo"
    width="25%">

A python software used to computed interaction between two molecules, from their
pharmacophore.

**Contributors:** Lucas ROUAUD

**Documentation:** <https://strange.mol3d.tech/>

</div>

## Installation

> [!INFO]
>
> We recommand either `pipx` or `uv` as installation method.

### pipx

```bash
pipx install strange-mol
strange --help
```

### uv

```bash
uv pip install strange-mol
strange --help
```

### pip

```bash
pip install strange-mol
strange --help
```

## Running through `nix`

If you have nix, you can run this software without installing it like:

```bash
nix --extra-experimental-features "nix-command flakes" run \
    git+https://gitlab.galaxy.ibpc.fr/rouaud/strange -- \
    --help
```

The first two lines are for the `nix` command. After the `--`, you can give
`strange` argument. For instance:

```bash
nix --extra-experimental-features "nix-command flakes" run \
    git+https://gitlab.galaxy.ibpc.fr/rouaud/strange -- \
    --input ... --output ...
```

## Command line interface

### `--help` and parameters explained

To get the program help, you can run:

```bash
strange --help
```

**Here, is a table giving parameters details:**

- **Bold parameters** are mandatory.
- [option in brackets] must be given together. So `[opt1 opt2]` for parameter
  `-x` will be translated to `-x opt1 opt2` in the CLI.

|      **Parameter**       |                                                                                                                   **Value type**                                                                                                                   | **Explaination**                                                                                                                                                                                                                                                | **Values example**                                             |
| :----------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------- |
|  **`--input` or `-i`**   |                                                                                                          One or two files with molecules.                                                                                                          | This is where you input the molecules to compute pharmacophore and interaction from.                                                                                                                                                                            | [protein.pdb ligand.sdf] <br> [protein.pdb]                    |
|  **`--output` or `-o`**  |                                                                                                    A `.csv` files to store compute interaction.                                                                                                    | This files is going to contain which pharmacophores are interacting, and some other parameters.                                                                                                                                                                 | [interaction.csv]                                              |
|     `--help` or `-h`     |                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                 |                                                                |
|   `--version` or `-v`    |                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                 |                                                                |
|  `--selection` or `-s`   | Selection to apply to the molecule. Work only for files parsed by MDAnalysis (not `.sdf`, `.mol`, `.mol2`, `xyz`). For more details, check [MDAnalysis selection algebra](https://docs.mdanalysis.org/stable/documentation_pages/selections.html). | This parameter will let you select subparts of your molecule to make the computation.                                                                                                                                                                           | ["protein" "resid CEL"] <br> ["chainID A" "chainID B"]         |
|  `--parameter` or `-p`   |                                                                            Parameter file to configure the software. [Check the associated section](../../parameter/).                                                                             | The parameter file that you will input here is going to change the software behaviour.                                                                                                                                                                          | [parameters.yml] <br> [parameters.json] <br> [parameters.toml] |
|    `--pharmacophore`     |                                                                                                  Two `.csv` files to store compute pharmacophore.                                                                                                  | The computed pharmacophore. If you gave two molecules, the first file correspond to the first molecule, the second one to the second molecule. If one molecule is given, first and second files will respectfully correspond to the first and second selection. | [protein.csv ligand.csv]                                       |
|     `--feature_file`     |                                                                                    A `.fdef` file that is going to be used by RDKit to identify pharmacophore.                                                                                     | This file contained SMART that are used to define certain type of pharmacophore with RDKit.                                                                                                                                                                     | [feature_file.fdef]                                            |
|    `--visualization`     |                                                                              You can either give a `.pml` file or a `.mvsj` file to visualize using PyMOL or MolStar.                                                                              | Use this to visualize the pharmacophore using PyMOL (`pymol visualization.pml`) or MolStar (open first the `visualization.mvsj`, then load it, then your molecules).                                                                                            | [interaction.pml] <br> [interaction.mvsj]                      |
| `--add_hydrogen` or `-a` |                                                                                               If you want to add hydrogens to your input molecules.                                                                                                | You can choose, with this option, to add hydrogen to the first input molecule only, the second input molecule only, both or none. If one file is given, it will correspond to the selection (first selection only, second only, both or none).                  | [0] <br> ["both"]                                              |

## 🙇‍♂️ Acknowledgement

- **Original idea:** Etienne REBOUL
- **Formula checking:** Charles ROBERT
- **Beta testing:** Isleme KHALFAOUI, Malek MELLITI

## License

**This works is under:**

- A `MIT` license (software).
- A `CC-BY` license (documentation).
