"""Module used to setup van der Waals radius."""

# =======================
# Python internal package
# =======================
# E
import dataclasses

# ==============
# Module package
# ==============
# G
from .generic import (
    check_typing,
)


# pylint: disable=invalid-name
#   —> Using atoms names as attributes.


@dataclasses.dataclass
class VanDerWaalsRadius:
    """Contains a list of element linked to their VdW radii, in Å.

    Citation
    --------
    Alvarez, S. (2013).
    A cartography of the van der Waals territories.
    Dalton Transactions, 42(24), 8617.
    https://doi.org/10.1039/c3dt50599e
    """

    def __post_init__(self) -> None:
        """Check if user values are good typing. In other words, `str` instead
        of `float` for instance.
        """
        check_typing(self)

    def dict(self) -> dict[str, float]:
        """Convert this whole enumerate into a dictonnary. If None, element is
        skipped during the convertion.

        Returns
        -------
        `dict[str, float]`
            The dictionnary.
        """
        data: dict[str, float | None] = dataclasses.asdict(self)

        # Filter out all None from the dictionnary.
        return dict(filter(lambda item: item[1] is not None, data.items()))

    H: float | None = 1.20
    HE: float | None = 1.43
    LI: float | None = 2.12
    BE: float | None = 1.98
    B: float | None = 1.91
    C: float | None = 1.77
    N: float | None = 1.66
    O: float | None = 1.50
    F: float | None = 1.46
    NE: float | None = 1.58
    NA: float | None = 2.50
    MG: float | None = 2.51
    AL: float | None = 2.25
    SI: float | None = 2.19
    P: float | None = 1.90
    S: float | None = 1.89
    CL: float | None = 1.82
    AR: float | None = 1.83
    K: float | None = 2.73
    CA: float | None = 2.62
    SC: float | None = 2.58
    TI: float | None = 2.46
    V: float | None = 2.42
    CR: float | None = 2.45
    MN: float | None = 2.45
    FE: float | None = 2.44
    CO: float | None = 2.40
    NI: float | None = 2.40
    CU: float | None = 2.38
    ZN: float | None = 2.39
    GA: float | None = 2.32
    GE: float | None = 2.29
    AS: float | None = 1.88
    SE: float | None = 1.82
    BR: float | None = 1.86
    KR: float | None = 2.25
    RB: float | None = 3.21
    SR: float | None = 2.84
    Y: float | None = 2.75
    ZR: float | None = 2.52
    NB: float | None = 2.56
    MO: float | None = 2.45
    TC: float | None = 2.44
    RU: float | None = 2.46
    RH: float | None = 2.44
    PD: float | None = 2.15
    AG: float | None = 2.53
    CD: float | None = 2.49
    IN: float | None = 2.43
    SN: float | None = 2.42
    SB: float | None = 2.47
    TE: float | None = 1.99
    I: float | None = 2.04
    XE: float | None = 2.06
    CS: float | None = 3.48
    BA: float | None = 3.03
    LA: float | None = 2.98
    CE: float | None = 2.88
    PR: float | None = 2.92
    ND: float | None = 2.95
    PM: float | None = None
    SM: float | None = 2.90
    EU: float | None = 2.87
    GD: float | None = 2.83
    TB: float | None = 2.79
    DY: float | None = 2.87
    HO: float | None = 2.81
    ER: float | None = 2.83
    TM: float | None = 2.79
    YB: float | None = 2.80
    LU: float | None = 2.74
    HF: float | None = 2.63
    TA: float | None = 2.53
    W: float | None = 2.57
    RE: float | None = 2.49
    OS: float | None = 2.48
    IR: float | None = 2.41
    PT: float | None = 2.29
    AU: float | None = 2.32
    HG: float | None = 2.45
    TL: float | None = 2.47
    PB: float | None = 2.60
    BI: float | None = 2.54
    PO: float | None = None
    AT: float | None = None
    RN: float | None = None
    AC: float | None = 2.8
    TH: float | None = 2.93
    PA: float | None = 2.88
    U: float | None = 2.71
    NP: float | None = 2.82
    PU: float | None = 2.81
    AM: float | None = 2.83
    CM: float | None = 3.05
    BK: float | None = 3.4
    CF: float | None = 3.05
    ES: float | None = 2.7
    FM: float | None = None
    MD: float | None = None
    NO: float | None = None
    LR: float | None = None
    RF: float | None = None
    DB: float | None = None
    SG: float | None = None
    BH: float | None = None
    HS: float | None = None
    MT: float | None = None
    DS: float | None = None
    RG: float | None = None
    CN: float | None = None
    NH: float | None = None
    FL: float | None = None
    MC: float | None = None
    LV: float | None = None
    TS: float | None = None
    OG: float | None = None
