"""A python software used to computed interaction between two molecules,
from their pharmacophore.
"""

__authors__ = ["Lucas ROUAUD"]
__contact__ = ["lucas.rouaud@gmail.com"]
__version__ = "0.1.2"
__date__ = "2026-02-20"
__copyright__ = ["MIT License", "CC-BY-SA"]
