"""ALX Protocol — Attribution trace resolution."""

from collections import deque
from typing import Dict, List


def trace_attribution(root_hash: str, graph: Dict[str, List[str]]) -> dict:
    root = root_hash.strip().lower()
    if not root:
        raise ValueError("rootHash is required")

    # Cycle pre-check via DFS
    cycle_detected = False
    visiting = set()
    visited_cycle = set()

    def check_cycle(node):
        nonlocal cycle_detected
        if node in visited_cycle:
            return
        if node in visiting:
            cycle_detected = True
            return
        visiting.add(node)
        for p in graph.get(node, []):
            check_cycle(p.strip().lower())
        visiting.discard(node)
        visited_cycle.add(node)

    check_cycle(root)

    # BFS discovery
    node_data = {}  # hash -> {min_depth, max_depth, parent_count}
    edge_set = set()
    edge_list = []
    child_counts = {}
    global_max_depth = 0

    queue = deque([(root, 0)])
    while queue:
        h, depth = queue.popleft()
        if h in node_data:
            node_data[h]["min_depth"] = min(node_data[h]["min_depth"], depth)
            node_data[h]["max_depth"] = max(node_data[h]["max_depth"], depth)
            if depth > global_max_depth:
                global_max_depth = depth
            continue

        parents = [p.strip().lower() for p in graph.get(h, [])]
        node_data[h] = {"min_depth": depth, "max_depth": depth, "parent_count": len(parents)}
        if depth > global_max_depth:
            global_max_depth = depth

        for p in parents:
            edge_key = f"{h}\0{p}"
            if edge_key not in edge_set:
                edge_set.add(edge_key)
                edge_list.append({"from": h, "to": p})
                child_counts[p] = child_counts.get(p, 0) + 1
            queue.append((p, depth + 1))

    # Topological path count propagation
    path_counts = {root: 1}
    sorted_hashes = sorted(node_data.keys(), key=lambda x: (node_data[x]["min_depth"], x))
    for h in sorted_hashes:
        my_paths = path_counts.get(h, 0)
        for p in [x.strip().lower() for x in graph.get(h, [])]:
            if p in node_data:
                path_counts[p] = path_counts.get(p, 0) + my_paths

    # Build output
    nodes = []
    leaves = []
    for h, data in node_data.items():
        nodes.append({
            "hash": h,
            "minDepth": data["min_depth"],
            "maxDepth": data["max_depth"],
            "pathCount": path_counts.get(h, 0),
            "parentCount": data["parent_count"],
            "childCount": child_counts.get(h, 0),
        })
        if data["parent_count"] == 0:
            leaves.append(h)

    nodes.sort(key=lambda n: (n["minDepth"], n["hash"]))
    edge_list.sort(key=lambda e: (e["from"], e["to"]))
    leaves.sort()

    return {
        "root": root,
        "nodes": nodes,
        "edges": edge_list,
        "leaves": leaves,
        "maxDepth": global_max_depth,
        "cycle": cycle_detected,
    }
