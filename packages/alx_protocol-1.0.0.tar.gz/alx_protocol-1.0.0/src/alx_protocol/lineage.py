"""ALX Protocol — Lineage validation."""

from typing import Dict, List, Optional, Set


def validate_lineage(
    block_hash: str,
    parent_hashes: List[str],
    known_hashes: Optional[Set[str]] = None,
) -> dict:
    h = block_hash.strip().lower()
    raw = [p.strip().lower() for p in parent_hashes]
    unique = sorted(set(raw))

    seen = set()
    duplicates = []
    for p in raw:
        if p in seen:
            duplicates.append(p)
        seen.add(p)

    self_ref = h in unique
    known = known_hashes or set()
    missing = sorted(p for p in unique if known and p not in known)

    return {
        "ok": not duplicates and not missing and not self_ref,
        "blockHash": h,
        "parents": unique,
        "duplicates": sorted(set(duplicates)),
        "missing": missing,
        "selfRef": self_ref,
        "cycle": self_ref,
    }


def validate_graph(graph: Dict[str, List[str]]) -> dict:
    all_hashes = set(graph.keys())
    cycle_nodes = _detect_all_cycles(graph)
    issues = []
    edges = 0
    roots = []

    for h, parents in graph.items():
        edges += len(parents)
        if not parents:
            roots.append(h)
        result = validate_lineage(h, parents, all_hashes)
        if h in cycle_nodes:
            result["cycle"] = True
            result["ok"] = False
        if not result["ok"]:
            issues.append(result)

    return {
        "ok": len(issues) == 0,
        "blocks": len(graph),
        "edges": edges,
        "roots": sorted(roots),
        "issues": issues,
    }


def build_graph(blocks: list) -> Dict[str, List[str]]:
    g = {}
    for b in blocks:
        h = b["blockHash"].strip().lower()
        parents = sorted(p.strip().lower() for p in b.get("parentHashes", []))
        g[h] = parents
    return g


def _detect_all_cycles(graph: Dict[str, List[str]]) -> Set[str]:
    visiting = set()
    visited = set()
    in_cycle = set()

    def visit(node):
        if node in visited:
            return False
        if node in visiting:
            in_cycle.add(node)
            return True
        visiting.add(node)
        for parent in graph.get(node, []):
            if visit(parent):
                in_cycle.add(node)
        visiting.discard(node)
        visited.add(node)
        return False

    for node in graph:
        visit(node)
    return in_cycle
