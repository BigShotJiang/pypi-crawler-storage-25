"""
ALX Protocol — Canonicalization.

Deterministic JSON serialization. Layer 1 of the protocol.

Rules:
  - Objects: keys sorted lexicographically, undefined/None values excluded
  - Arrays: order-preserving (not sorted)
  - null/None: canonicalizes to "null"
  - Numbers: -0 → 0, safe integer range enforced, non-finite rejected
  - Strings: JSON-escaped
  - Depth limit: 128
"""

import json
import math
from typing import Any

MAX_DEPTH = 128
MAX_SAFE_INTEGER = 2**53 - 1
MIN_SAFE_INTEGER = -(2**53 - 1)


def canonicalize(value: Any, _depth: int = 0) -> str:
    if _depth > MAX_DEPTH:
        raise ValueError(f"Canonicalization depth exceeded {MAX_DEPTH}")

    if value is None:
        return "null"

    if isinstance(value, bool):
        return "true" if value else "false"

    if isinstance(value, int) and not isinstance(value, bool):
        if value > MAX_SAFE_INTEGER or value < MIN_SAFE_INTEGER:
            raise ValueError(f"Integer out of safe range: {value}")
        return str(value)

    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"Non-finite number not allowed: {value}")
        if value == 0.0 and math.copysign(1.0, value) == -1.0:
            return "0"  # -0 → 0
        if value == int(value) and MIN_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER:
            return str(int(value))
        return json.dumps(value)

    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)

    if isinstance(value, list):
        return "[" + ",".join(canonicalize(v, _depth + 1) for v in value) + "]"

    if isinstance(value, dict):
        keys = sorted(k for k in value.keys() if value[k] is not None or True)
        # Exclude keys whose values are the Python equivalent of JS undefined
        # In Python, we don't have undefined — None maps to JSON null and is kept.
        parts = []
        for k in keys:
            parts.append(json.dumps(str(k), ensure_ascii=False) + ":" + canonicalize(value[k], _depth + 1))
        return "{" + ",".join(parts) + "}"

    raise TypeError(f"Unsupported type for canonicalization: {type(value).__name__}")
