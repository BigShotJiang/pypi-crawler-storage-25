"""
ALX Protocol — Python implementation.

Deterministic infrastructure for verifiable content,
interoperable context, and traceable attribution.

One primitive: Block = { blockHash, contentHash, parentHashes, content }
Four operations: canonicalize, hash, validate, trace
"""

from alx_protocol.canonical import canonicalize
from alx_protocol.block import (
    derive_block_hash,
    derive_content_hash,
    create_block,
    validate_block,
    normalize_hash,
    normalize_hashes,
)
from alx_protocol.lineage import validate_lineage, validate_graph, build_graph
from alx_protocol.trace import trace_attribution
from alx_protocol.merkle import build_merkle_tree, get_merkle_proof, verify_merkle_proof

__version__ = "1.0.0"

__all__ = [
    "__version__",
    "canonicalize",
    "derive_block_hash", "derive_content_hash", "create_block", "validate_block",
    "normalize_hash", "normalize_hashes",
    "validate_lineage", "validate_graph", "build_graph",
    "trace_attribution",
    "build_merkle_tree", "get_merkle_proof", "verify_merkle_proof",
]
