"""
ALX Protocol — Block primitive.

Block = { blockHash, contentHash, parentHashes, content }

blockHash   = keccak256(canonicalize({ content, parentHashes }))
contentHash = keccak256(canonicalize(content))
"""

import re
from typing import Any, Dict, List, Optional
from eth_hash.auto import keccak
from alx_protocol.canonical import canonicalize

HASH_PATTERN = re.compile(r"^0x[a-f0-9]{64}$")


def derive_block_hash(content: Any, parent_hashes: Optional[List[str]] = None) -> str:
    parents = normalize_hashes(parent_hashes or [])
    canonical = canonicalize({"content": content, "parentHashes": parents})
    return "0x" + keccak(canonical.encode("utf-8")).hex()


def derive_content_hash(content: Any) -> str:
    canonical = canonicalize(content if content is not None else None)
    return "0x" + keccak(canonical.encode("utf-8")).hex()


def create_block(content: Any, parent_hashes: Optional[List[str]] = None) -> Dict[str, Any]:
    parents = normalize_hashes(parent_hashes or [])
    return {
        "blockHash": derive_block_hash(content, parents),
        "contentHash": derive_content_hash(content),
        "parentHashes": parents,
        "content": content,
    }


def validate_block(block: Dict[str, Any]) -> Dict[str, Any]:
    expected = derive_block_hash(block.get("content"), block.get("parentHashes", []))
    actual = normalize_hash(block["blockHash"])
    return {"ok": expected == actual, "expected": expected, "actual": actual}


def normalize_hash(h: str) -> str:
    s = str(h).strip().lower()
    if not HASH_PATTERN.match(s):
        raise ValueError(f"invalid hash: {h}")
    return s


def normalize_hashes(hashes: List[str]) -> List[str]:
    result = set()
    for h in hashes:
        s = str(h).strip().lower()
        if HASH_PATTERN.match(s):
            result.add(s)
    return sorted(result)
