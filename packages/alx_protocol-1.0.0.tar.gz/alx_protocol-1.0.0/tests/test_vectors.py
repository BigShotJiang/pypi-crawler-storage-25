"""ALX Protocol test vectors — Python implementation.

Loads canonical vectors from protocol/test-vectors/*.json and runs
language-specific inline tests for edge cases JSON cannot represent.
"""

import json
from pathlib import Path

from alx_protocol import derive_block_hash, create_block, validate_block, canonicalize

VECTORS_DIR = Path(__file__).resolve().parents[3] / "protocol" / "test-vectors"


def load_vectors(filename: str) -> dict:
    return json.loads((VECTORS_DIR / filename).read_text())


# ════════════��═══════════════════════════════════════════════════════════════
# DATA-DRIVEN: protocol/test-vectors/canonicalization.json
# ════════════════════════════════════════════════════════════════════════════


class TestCanonicalizationVectors:
    """Load and replay canonicalization vectors from JSON data files."""

    def test_vectors_from_json(self):
        suite = load_vectors("canonicalization.json")
        for v in suite["vectors"]:
            # Skip C4 (negative zero — Python has no -0 literal) and C10 (undefined — N/A in Python)
            if v["id"] in ("C4", "C10"):
                continue
            result = canonicalize(v["input"])
            assert result == v["expected"], f"VECTOR {v['id']}: {v['description']} — got {result!r}"


# ═════════════���══════════════════════════════���═══════════════════════════════
# INLINE TESTS (language-specific edge cases + original vectors)
# ═══════════════════════════════��═════════════════════════════════���══════════


def test_null_canonicalizes_to_null():
    assert canonicalize(None) == "null"


def test_keys_sorted():
    assert canonicalize({"b": 1, "a": 2}) == '{"a":2,"b":1}'


def test_array_order_preserved():
    assert canonicalize([3, 1, 2]) == "[3,1,2]"


def test_same_content_same_hash():
    a = derive_block_hash("hello", [])
    b = derive_block_hash("hello", [])
    assert a == b


def test_different_content_different_hash():
    a = derive_block_hash("hello", [])
    b = derive_block_hash("world", [])
    assert a != b


def test_parent_order_irrelevant():
    p1 = "0x" + "a" * 64
    p2 = "0x" + "b" * 64
    a = derive_block_hash("test", [p1, p2])
    b = derive_block_hash("test", [p2, p1])
    assert a == b


def test_block_validates():
    block = create_block("test", [])
    result = validate_block(block)
    assert result["ok"] is True


def test_tampered_block_fails():
    block = create_block("test", [])
    block["content"] = "tampered"
    result = validate_block(block)
    assert result["ok"] is False
