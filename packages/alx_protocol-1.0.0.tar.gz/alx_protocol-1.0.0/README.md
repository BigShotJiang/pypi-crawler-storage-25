<p align="center">
  <img src="../../assets/xandrlabs/xandrlabs_logo3.png" alt="Xandr Labs" width="160"/>
</p>
<p align="center"><strong><em>Infrastructure compounds. Block by block.</em></strong></p><p align="center">https://xandrlabs.ai</p>

---

# ALX Protocol - Python Implementation

This implementation tracks parity with the TypeScript SDK in `reference-implementations/typescript`.

## Authority

- Canonical specification: [`protocol/spec.md`](../../protocol/spec.md)
- JSON Schemas: [`protocol/schemas/`](../../protocol/schemas/)
- Test vectors: [`protocol/test-vectors/`](../../protocol/test-vectors/)
- Companion docs: [`docs/`](../../docs/)

## Layout

- `pyproject.toml` - package `alx-protocol`, `src/alx_protocol/`
- `tests/` - smoke tests (`pytest`)

```bash
cd reference-implementations/python
python -m venv .venv
.venv\Scripts\activate   # Windows
pip install -e ".[dev]"
pytest
# or vector replay only (same entrypoint as CI):
python verify_vectors.py
```

Next steps: virtual registry, signing (EIP-712), and broader API parity with the TypeScript reference implementation.

## Reference

Compare behavior with [`reference-implementations/typescript`](../../reference-implementations/typescript/), especially `src/canonicalization.js` and `src/__tests__/conformance-vectors.test.js`.
