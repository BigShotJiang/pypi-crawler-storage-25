from typing import Tuple, List, Optional, TYPE_CHECKING

from sympy import Poly, Expr, Symbol, Integer, Rational, Float, Add, sqrt, im
import numpy as np

from .cubic import sos_struct_cubic
from .quartic import sos_struct_quartic
from .quintic_symmetric import sos_struct_quintic_symmetric
from ..univariate import prove_univariate
from .utils import (
    sum_y_exprs, nroots, rationalize, rationalize_bound, rationalize_func,
    zip_longest, quadratic_weighting, align_cyclic_group
)

if TYPE_CHECKING:
    from .utils import (
        Coeff
    )

def _verify_border_nonnegative(border):
    """Verify whether a polynomial >= 0 over R+."""
    if border.degree() == 0:
        return True
    if border.LC() < 0:
        return False
    factor_list = border.factor_list()[1]
    for factor, multiplicity in factor_list:
        if multiplicity % 2 == 1:
            if factor.degree() == 1 and factor.coeff_monomial((0,)) == 0:
                continue
            if factor.count_roots(0, None):
                return False
    return True


def _prove_quintic_from_border(coeff: 'Coeff', border: Poly) -> Optional[List[Expr]]:
    """
    Let f(a,b,c) be a septic (degree-7) cyclic polynomial without a^7 term.
    Then B(x) = f(x,1,0) / x is quintic. Assume that B(x) >= 0 (x >= 0).
    Given such B, we find a sum-of-squares form g(a,b,c), such that
    sum abg(a,b,c) = f(a,b,c) when c = 0. That is, the border of sum g
    coincides with the border of f.

    This is used to cancel out the border of a septic polynomial, so that
    it remains to prove a quartic * abc.
    """
    if border.LC() < 0:
        return None
    a, b, c = coeff.gens
    proof = prove_univariate(border, (0, None), return_type = 'list')
    if proof is None:
        return None
    s_args = []
    for multiplier, cps in proof:
        if multiplier == 1:
            for coeff, poly in cps:
                bias = poly(1) # ensure f(1,1,1) = 0
                poly = sum(v*a**i*b**(2-i) for (i,), v in poly.terms()) - bias*a*c
                s_args.append(coeff * b * poly**2)
        elif multiplier == border.gen:
            for coeff, poly in cps:
                bias = poly(1)
                poly = sum(v*a**i*b**(2-i) for (i,), v in poly.terms()) - bias*b*c
                s_args.append(coeff * a * poly**2)
    return s_args # Add(*s_args)



def sos_struct_quintic(coeff, real = True):
    """
    Solve quintic inequalities.
    """

    # first try symmetric solution
    if coeff((4,1,0)) == coeff((1,4,0)) and coeff((3,2,0)) == coeff((2,3,0)):
        return sos_struct_quintic_symmetric(coeff)

    if coeff((5,0,0)) == 0:
        return _sos_struct_quintic_hexagon(coeff)
    else:
        return _sos_struct_quintic_full(coeff)
    return None


def _solve_sa2minusab_mul_cubic(coeff: 'Coeff', x, y, mul = 1):
    """
    Solve `mul * s(a^2-ab)s(a^3 + xa^2b + yab^2 - (x+y+1)abc) >= 0`.

    Theorem:
    If and only if `p,q >= 0` or `p^2q^2 + 18pq - 4p^3 - 4q^3 - 27 <= 0`, the inequality
    `f(a,b,c) = s(a^3 + p*a^2*b + q*a*b^2 - (p+q+1)*a*b*c) >= 0` is true for all `a,b,c >= 0`.

    The curve `-4*x**3 + x**2*y**2 + 18*x*y - 4*y**3 - 27 = 0` can be parametrized by
    ```
    x = -(2*t**3 - 1)/t**2
    y = (t**3 - 2)/t
    ```

    Using the parametrization, `f_t(t,1,0) = 0`. And we have the solution that
    `s(a^2-ab)*f_t(a,b,c) = 1/t^2 * s(a(ta-(t-1)b-c)^2(tb-(t-1)c-a)^2) >= 0`.

    When `(x, y)` is not on the curve, it would be a linear combination of two points on the curve.
    """
    a, b, c = coeff.gens
    CyclicSum = coeff.cyclic_sum
    if x >= 0 and y >= 0:
        cubic_poly = coeff.from_dict({(3,0,0): 1, (2,1,0): x, (1,2,0): y, (1,1,1): -3*(x+y+1)})
        return Rational(1,2) * mul * CyclicSum((a-b)**2) * sos_struct_cubic(cubic_poly)

    def _solve_t(t):
        return (1/t**2) * CyclicSum(a*(t*a - (t-1)*b - c)**2*(t*b - (t-1)*c - a)**2)

    # find t such that (x,y) >= (-(2*t**3 - 1)/t**2, (t**3 - 2)/t)  (t > 0)
    eq1t = coeff.from_list([2, x, 0, -1], (a,)).as_poly()
    eq2t = coeff.from_list([-1, 0, y, 2], (a,)).as_poly()
    # first check whether there exists multiplicative roots
    eqgcd = eq1t.gcd(eq2t)
    if eqgcd.degree() == 1 and eqgcd.coeff_monomial((0,)) != 0:
        t_ = - eqgcd.coeff_monomial((0,)) / eqgcd.coeff_monomial((1,))
        return mul * _solve_t(t_)

    def _check_valid(t):
        return t > 0 and eq2t(t) >= 0

    t = rationalize_func(eq1t, _check_valid, direction = 1)
    if t is None:
        return None
    p1 = mul * _solve_t(t)
    x1 = x + (2*t**3 - 1)/t**2
    y1 = y - (t**3 - 2)/t
    p2 = (mul*x1) * (a - c)**2 + (mul*y1) * (a - b)**2
    return p1 + CyclicSum(a * p2 * (b - c)**2)



#########################################################
#
#                     Quintic Full
#
#########################################################

def _solve_uvxy(coeff: 'Coeff'):
    """
    Given quintic polynomial F(a,b,c), we can enhance it by finding maximum t such that
    F(a,b,c) - tabcs(a^2-ab) >= 0.
    At this maximum t, there exists nontrivial equality cases, and we assume
    that the equality satisfies a^2-b^2+u(ab-ac)+v(bc-ab) = 0 and its cyclic permutations.

    Now we represent F in the form of
    F(a,b,c) = sum (a + cy)f(a,b,c)^2 + 2x*sum af(a,b,c)f(b,c,a).

    Return u, v, x, y.
    """
    a, b, c = coeff.gens
    ring = coeff.domain[a, b]
    u, v = ring.gens

    m, p, q, g, h = [coeff(_) for _ in [(5,0,0),(4,1,0),(1,4,0),(3,2,0),(2,3,0)]]
    p, q, g, h = p/m, q/m, g/m, h/m
    x1 = -p + q + 4*u - 2*v - 1
    x2 = 2*(u + v - 1)
    y1 = (2*u**2 - 4*u*v + 2*u - 2*v - 4)*x1 + 4*u**2*v - 4*u**2 + 2*u*v**2 - 4*u*v + 8*u - 2*v**3 + 6*v**2 - 4 + (g - h)*x2
    y3 = (u**2 + 2*u - v**2 - 2*v)
    y2 = y3 * x2

    eq1p = ((-p + 2*u - 2*v)*y2 - 2*u*x1*y3 + y1)
    eq2p = (-2*u**2 + 2*u*v + 2*u + 2)*x1*y3 + (u**2 - 2*v)*y1 + (- g + u**2 - 2*u*v + v**2 - 2)*y2

    # print(latex(eq1.as_expr().subs({u:Symbol('x'), v:Symbol('y')})).replace(' ',''))
    # print(latex(eq2.as_expr().subs({u:Symbol('x'), v:Symbol('y')})).replace(' ',''))
    # print(eq1, '\n', eq2)

    # numerical solver: unstable
    # try:
    #     u, v = (nsolve((eq1, eq2), (u, v), (2, 2)))
    #  except Exception:
    #     return None

    eq1 = coeff.from_rep(eq1p).as_poly()
    eq2 = coeff.from_rep(eq2p).as_poly()

    success = False
    u, v, u_, v_ = 0, 0, 0, 0
    if True:
        v_eq = eq1.resultant(eq2)
        method = 'factor' # if is_rational else 'numpy'
        roots = sorted(nroots(v_eq, method = method, real = True, nonnegative = True))#[::-1]
        for v_ in roots:
            u_eq = eq1.eval(1, v_)
            roots_u = nroots(u_eq, method = method, real = True, nonnegative = True)
            for u_ in roots_u:
                if abs(u_ - v_) > 1e-5 and abs(u_ + v_ - 1) > 1e-5 and \
                        abs(eq2.eval((u_, v_))) < 1e-3 and u_ * v_ >= 1:
                    success = True
                    u, v = u_, v_
                    break
            if success:
                break

    if not success:
        return None

    if u + v - 1 == 0 or u**2 + 2*u - v**2 - 2*v == 0:
        return None

    x = (-p + q + 4*u - 2*v - 1)/(2*(u + v - 1))
    y = (g - h + 2*u**2*x - 4*u*v*x + 2*u*v + 2*u*x - 2*u - v**2 - 2*v*x + 2*v - 4*x + 2)/(u**2 + 2*u - v**2 - 2*v)
    # print('u v x y =', u, v, x, y)

    # z = 2*u**2*x - 2*u**2 + 2*u*v*x - 2*u*v*y + 2*u*v - 2*v**2*x
    # print(u, v, x, y, z)
    # if z < coeff((3,1,1)) / m - 1e-5:
    #     return None
    return u, v, x, y


def _sos_struct_quintic_full(coeff: 'Coeff'):
    """
    Try to solve quintic with nonzero a^5 coefficient by subtracting something.

    Let f(a,b,c) = a^2-b^2 + u(ab-ac) + v(bc-ab) to be the quadratic form. We consider
    F(a,b,c) = sum a(f(a,b,c) + xf(b,c,a))^2 + k*sum cf(a,b,c)^2 >= 0.
    This is tight when uv >= 1 and u,v >= 0 because there exists nontrivial equality cases.

    Expand F, we obtain
    F(a,b,c) = sum (a + c(x^2+k))f(a,b,c)^2 + 2x*sum af(a,b,c)f(b,c,a).
    Now we take y = x^2 + k >= x^2.
    We solve u,v,x,y from the coefficient of a^5,a^4b,a^3b^2,a^2b^3,ab^4.

    Examples
    --------
    => s(a5+a4b-3a3b2-9a3bc+4a3c2+6a2b2c)

    => s(a5-3a4b+3a3b2-6a3bc+3a3c2+2a2b2c)

    => s(2a5-5a4b+a4c+5a3b2-19a3bc+6a3c2+10a2b2c)

    => s(a2(a-b)(a2+2b2-2ac+2c2))-5/4abcs(a2-ab)

    => s(31a5-58a4b-8a4c+35a3c2)

    => s(a2(a-b)(a2-3bc))

    => s(10a5-19a4b+4a3b2+5a2b2c)

    => s(38a5-73a4b+16a3b2+19a2b2c)

    => s(a2(a-b)(a2+ab-5bc))

    => s(a2(a-b)(a2+b2-3ac+3c2))-1/3abcs(a2-ab)

    => s((a+b-c*4/5)(a2-b2+0(ab-ac)+(bc-ab))2)

    => s(2a5-5a4b-7a4c+5a3b2+14a3bc+6a3c2-15a2b2c)

    => s((23a-5b-c)(a-b)2(a+b-3c)2) # doctest:+SKIP

    => s(36a5-39a4b-164a4c-122a3b2+311a3bc+253a3c2-275a2b2c) # doctest:+SKIP

    => s((a-2b)2(2a2-2ab+b2)(2a+b)-4a5+a3bc+25abc(a2-ab)) # doctest:+SKIP

    => s(53361a5-354459a4b-107547a4c+678010a3b2+1034825a3bc-254726a3c2-1049464a2b2c) # doctest:+SKIP

    => s(144400a5-261516a4b-1447320a4c-1613008a3b2+5235581a3bc+3966569a3c2-6024706a2b2c) # doctest:+SKIP

    => s(34105600a5-71885436a4b-328258080a4c-328208596a3b2+1188005225a3bc+862751801a3c2-1356510514a2b2c) # doctest:+SKIP

    => s(13660416a5-74323095a4b-26634720a4c+120979510a3b2+194638463a3bc-42269615a3c2-186050959a2b2c) # doctest:+SKIP
    """

    if coeff((5,0,0)) <= 0:
        return None

    a, b, c = coeff.gens
    CyclicSum = coeff.cyclic_sum

    # method 1
    solution = _solve_trivial_quintic_full(coeff)
    if solution is not None:
        return solution

    if not coeff.is_rational:
        return None

    # method 2
    sol = _solve_uvxy(coeff)
    if sol is None:
        return None

    u_, v_, x_, y_ = sol
    if y_ >= x_**2:
        m, p, q, g, h, z, w = [coeff(_) for _ in [(5,0,0),(4,1,0),(1,4,0),(3,2,0),(2,3,0),(3,1,1),(2,2,1)]]
        p, q, g, h, z, w = p/m, q/m, g/m, h/m, z/m, w/m

        for u, v in zip_longest(
            rationalize_bound(u_, direction = 0), rationalize_bound(v_, direction = 0)
        ):
            x = (-p + q + 4*u - 2*v - 1)/(2*(u + v - 1))
            if 2*(u + v - 1) == 0:
                continue
                # if -p + q + 4*u - 2*v - 1 == 0:
                #     x = Integer(0)
            y = x**2
            if p + 2*(u*x-u+v) >= y:
                _new_coeffs = {
                    (4,1,0): (p - (-2*u*x + 2*u - 2*v + y)) * m,
                    (1,4,0): (p - (-2*u*x + 2*u - 2*v + y)) * m,
                    (3,2,0): (g - (-2*u**2*x + u**2*y + u**2 + 2*u*v*x - 2*u*v + 2*u*x + v**2 - 2*v*y + 2*x - 2)) * m,
                    (2,3,0): (h - (u**2 - 2*u*v*x + 4*u*x - 2*u*y - 2*u + v**2*y - 2*v*x + 2*v - 2*x)) * m,
                    (3,1,1): (z - (2*u**2*x - 2*u**2 + 2*u*v*x - 2*u*v*y + 2*u*v - 2*v**2*x)) * m,
                    (2,2,1): (w - (-u**2*y - 2*u*v*x + 2*u*v*y - 4*u*x + 2*u*y + 2*u + 2*v**2*x - v**2*y - v**2 + 2*v*y + 2*x - 2*y)) * m,
                }
                solution = _sos_struct_quintic_hexagon(coeff.from_dict(_new_coeffs))
                if solution is not None:
                    xu, xv = x*u, x*v
                    solution = m * CyclicSum(
                        a*(a**2-b**2+(u-v)*a*b-u*a*c+v*b*c + x*b**2-x*c**2 + (xu-xv)*b*c - xu*b*a + xv*c*a)**2
                    ) + solution
                    return solution
        return None


    # method 3
    # now we handle the ultimate case
    if (isinstance(u_, Rational) and isinstance(v_, Rational)):
        # cannot perturb -> not implemented
        return None
    return _solve_quintic_full_final(coeff, (u_, v_))


def _solve_trivial_quintic_full(coeff: 'Coeff'):
    """
    Method 1: Try subtracting s(a^2-ab)s(a^3 + xa^2b + yab^2 - (x+y+1)abc)
    where x, y are to be determined, so that the remaining polynomial
    falls into the hexagon case with equal coefficients of a^4b and ab^4.

    To ensure coeff((4,1,0)) == coeff((1,4,0)) = t for the remaining poly,
    we can assume x = x0 - t, y = y0 - t.
    Then the remaining coefficients of coeff((3,2,0)) and coeff((2,3,0)) do not
    depend on the choice of t.

    In most ideal case, the remaining poly should have discriminant == 0,
    and we can solve for the exact minimum t that ensures the remaining polynomial
    nonnegative.
    See more details at _sos_struct_quintic_hexagon.
    """
    coeff500 = coeff((5,0,0))
    x0, y0 = coeff((4,1,0)) / coeff500 + 1, coeff((1,4,0)) / coeff500 + 1

    # the remaining coefficient of a^3b^2 and a^2b^3 are given by ... (not depend on t)
    p, q = coeff((3,2,0)) / coeff500 - (1-x0+y0), coeff((2,3,0)) / coeff500 - (1-y0+x0)

    z0 = coeff((3,1,1)) / coeff500 + (4+4*(x0+y0))
    # print(p, q, z0)

    if p >= 0 and q >= 0 and (4*p*q >= z0**2 or z0 >= 0):
        t0 = 0
    else:
        # Plug in the discriminant, the discriminant is linear of t,
        # so we can solve the exact minimum t that makes the remaining poly nonnegative.
        denom = (2*p + 2*q + z0)*(4*p**2 - 4*p*q - 2*p*z0 + 4*q**2 - 2*q*z0 + z0**2)
        if denom <= 0 or 4*p*q - z0**2 == 0:
            t0 = None
        else:
            t0 = (-4*p*q + z0**2)**2/(8*denom)

    if t0 is None: # or t0 < 0:
        return

    x_, y_ = x0 - t0, y0 - t0
    if (x_ >= 0 and y_ >= 0) or (-4*x_**3 + x_**2*y_**2 + 18*x_*y_ - 4*y_**3 - 27) <= 0:
        p1 = _solve_sa2minusab_mul_cubic(coeff, x_, y_, mul = coeff500)
        if p1 is None:
            return None

        hexagon_coeffs = {
            (4,1,0): t0,
            (3,2,0): p,
            (2,3,0): q,
            (1,4,0): t0,
            (3,1,1): z0 - 8*t0,
            (2,2,1): -(-6*t0+p+q+z0) + coeff.poly111() / 3 / coeff500
        }
        p2 = _sos_struct_quintic_hexagon(coeff.from_dict(hexagon_coeffs))

        if p2 is not None:
            return p1 + coeff500 * p2
    return None



def _build_quintic_full_solution(coeff: 'Coeff', mul: Rational, params: List[Rational],
        border_proof: List[Expr], mpnq: Tuple[Rational, ...]):
    from ....utils.monomials import invarraylize
    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product
    coeff500 = coeff((5,0,0))
    m, p, n, q = mpnq

    multiplier = CyclicSum(a**2 + mul*b*c)
    sol_main = CyclicSum(a * invarraylize(params, (a, b, c), degree=3).as_expr()**2)

    border_proof_split_a, border_proof_split_b = [], []
    for arg in border_proof: #.args:
        if (a in arg.args) or arg == a:
            border_proof_split_a.append(arg)
        else:
            border_proof_split_b.append(arg)
    border_proof_split_a = Add(*border_proof_split_a)
    border_proof_split_b = Add(*border_proof_split_b)
    border_proof = CyclicSum(a*b*border_proof_split_a) + CyclicSum(a*b*border_proof_split_b)

    quartic_coeffs = {
        (4,0,0): m, (3,1,0): p, (2,2,0): n, (1,3,0): q, (2,1,1): -(m+p+n+q)
    }
    rest = sos_struct_quartic(coeff.from_dict(quartic_coeffs), None)
    rest += coeff.poly111() * (1 + mul) * CyclicSum(a**2*b*c)
    rest = coeff500 * CyclicProduct(a) * rest
    return (coeff500 * sol_main + coeff500 * border_proof + rest) / multiplier



def _solve_flip_sgn_eqs(eqs, border, criterion) -> Optional[Tuple[List[float], Float]]:
    """
    Add in the constraints of sqrt(-x) * f(x) +- g(x) = 0.
    Note that there are 2 choices of sign for each equation, we need to try
    both of them.

    Return None if no solution is found. Return params of V and z otherwise.
    """
    eqs = np.array(eqs, dtype = np.float64)
    target = np.array([1] + [0]*9, dtype=eqs.dtype)
    borderdiff = border.all_coeffs()[-2]
    as_arr = lambda a,b,c: np.array(
        [a**3, a**2*b, a**2*c, a*b**2, a*b*c, a*c**2, b**3, b**2*c, b*c**2, c**3])
    as_vec_float = lambda *x: as_arr(*x).astype(np.float64).reshape((1,10))
    as_vec_complex = lambda *x: as_arr(*x).astype(np.complex128).reshape((1,10))

    eqs_choices = []
    for r in nroots(border):
        if r.is_real:
            if r > 0:
                return None
            else: # r <= 0
                eqs_choices.append(
                    [(sgn * float(sqrt(-r).n(15)) * as_vec_float(r,1,0) + as_vec_float(1,0,r)) for sgn in (1,-1)]
                )
        elif im(r) > 0:
            # conjugate pair must have equal selection of sign and we handle them at the same time
            # hint: to ensure the solution is real, we can add in the real and imag part of a complex equation
            # to the real equations
            tmp = []
            for sgn in (1,-1):
                eq_complex = sgn * complex(sqrt(-r).n(15)) * as_vec_complex(r,1,0) + as_vec_complex(1,0,r)
                eq_real = np.vstack([eq_complex.real, eq_complex.imag])
                tmp.append(eq_real)
            eqs_choices.append(tmp)

    from itertools import product
    for comb in product((0, 1), repeat = len(eqs_choices)):
        # select the combination of signs
        eqs_ = np.vstack([eqs] + [eqs_choices[i][comb[i]] for i in range(len(eqs_choices))])
        params = np.linalg.solve(eqs_, target).tolist()
        mul = params[6]**2 + params[2]*2 - borderdiff
        if mul >= -1:
            # we require mul >= -1 and det >= 0 to apply the quartic theorem
            if criterion(mul, params):
                # m_, p_, n_, q_ = mpnq
                # print('Expected mpnq =', mpnq,
                # '\nExpected det =', (3*m_*(m_+n_) - (p_**2+p_*q_+q_**2)).n(15),
                # '\nExpected mul =', mul_)
                return params, mul
    return None


def _solve_quintic_full_final(coeff: 'Coeff', uv = None):
    """
    Given quintic `F(a,b,c)`. We denote `B(x) = F(x,1,0) >= 0` be its border.
    Assume `F(a,b,c) * sum(a^2 + zab) = sum a*V(a,b,c)^2 + abc*sum R(a,b,c)`.
    We can apply the quartic theorem on R(a,b,c). Now we will illustrate how to find V and z.

    Let f(x) = V(x,1,0) and g(x) = V(1,0,x). Take b = 1 and c = 0 in the identity
    we yield `xf(x)^2 + g(x)^2 = B(x)(x^2 + zx + 1)`.

    Now we take x to be the five roots of B(x), then for each root we must have
    sqrt(-x) * f(x) pm g(x) = 0
    Also we may assume V(1,0,0) = 1 when the leading coeff F is 1. We also require V(1,1,1) = 0
    to cover the equality at the center. Moreover, when F has tight nontrivial equality case
    (a0, b0, c0) and its permutations satisfying that sum (a^2-b^2+u(ab-ac)+v(bc-ab))^2 == 0,
    we need V(a0,b0,c0) = 0 and its permutations.

    Together, there are 10 equations and 10 unknowns. And we can solve for V by solving a linear system,
    NUMERICALLY. Lastly, z is given by

    `z = lim(x->0) (xf(x)^2 + g(x)^2 - B(x)) / (xB(x)) = f(0)^2 + 2g'(0) - B'(0)`


    In most ideal cases, V and z are rational and everything is done. However, when V and z are
    not rational, we first assume that the R(a,b,c) > 0 is strict when (a,b,c) != (1,1,1). Then
    we can add a little more:

    `F(a,b,c) * sum (a^2 + (z+dz)ab) = sum a* #V(a,b,c)^2 + sum abU(a,b,c) + abc*sum #R(a,b,c).`

    Here #V is a perturbation of V. We select dz > 0 such that the border is slightly larger than
    the original. Then U(a,b,c) is small and we use it to handle the remaining part of the border.
    Lastly we apply quartic theorem on the perturbed #R.
    """
    def _extract_quartic(poly: Poly) -> Poly:
        """Given septic polynomial F(a,b,c), return the quartic polynomial with coefficients
        being the a^5bc, a^4b^2c, a^3b^3c, a^2b^4c, ab^5c coefficients of F."""
        return Poly([poly.coeff_monomial((5-i,i+1,1)) for i in range(5)], a)

    a, b, c = coeff.gens
    z = c
    # standardize
    coeff500 = coeff((5,0,0))
    poly = coeff.as_poly()
    poly = poly.mul_ground(1/coeff500)

    if uv is None:
        u_, v_, __, ___ = _solve_uvxy(coeff)
    else:
        u_, v_ = uv

    border = poly.eval(2,0).eval(1,1) # poly.subs({b:1, c:0}).as_poly(a)

    criterion = lambda m,p,n,q: (m>0 and (3*m*(m+n)-p**2-p*q-q**2)>=0) \
                                 or (m==0 and p>=0 and 4*p*q>=n**2)

    # border_std = ((a*a+z*a+1).as_poly(a) * border - a**7 - 1).div(a.as_poly(a))[0]
    # border_std_coeff5 = border_std.coeff_monomial((5,))
    border_std = [
        border,
        Poly((Poly([1, 0, 1], a)*border).all_coeffs()[1:-1], a),
    ]
    border_std_eval = lambda z_: border_std[0]*z_ + border_std[1]
    border_std_coeff5 = [_.coeff_monomial((5,)) for _ in border_std]

    quartic_mul_a2 = _extract_quartic((a*a+b*b).as_poly(a,b,c) * poly)
    quartic_mul_ab = _extract_quartic((a*b+b*c+c*a).as_poly(a,b,c) * poly)

    def _get_quartic_remain(mul, params, return_mpnq = False):
        """
        Params is the coefficient of V, which is a length-10 vector.
        Compute _extract_quartic(f(a,b,c) * sum(z^2 + zab) - sum a*V(a,b,c)^2).
        When setting return_mpnq = True, return the coefficient of
        a^5bc, a^4b^2c, a^3b^3c, a^2b^4c (denoted by m, p, n, q).
        """
        _, x1, x2, x3, x4, x5, x6, x7, x8, x9 = params
        quartic_sub = [
            2*x1*x2 + 2*x4 + 2*x6*x7 + 2*x8*x9,
            2*x1*x4 + 2*x2*x3 + 2*x4*x9 + 2*x5*x8 + 2*x6*x8 + x7**2 + 2*x7,
            2*x1*x7 + 2*x1*x9 + 2*x2*x6 + 2*x2*x8 + 2*x3*x4 + 2*x4*x5 + 2*x6*x9 + 2*x7*x8,
            2*x1*x5 + 2*x2*x4 + 2*x3*x7 + 2*x4*x6 + 2*x7*x9 + x8**2 + 2*x8,
            2*x1*x2 + 2*x4 + 2*x6*x7 + 2*x8*x9
        ]
        quartic_sub = Poly(quartic_sub, a)
        quartic_rem = quartic_mul_a2 + quartic_mul_ab * mul - quartic_sub
        if return_mpnq:
            return [quartic_rem.coeff_monomial((4-i,)) for i in range(4)]
        return quartic_rem
    def composed_cri(mul, params):
        mpnq = _get_quartic_remain(mul, params, return_mpnq = True)
        return criterion(*mpnq)

    # construct the linear system, which is 10*10
    eqs = [np.array([1.] + [0] * 9), np.array([1.] * 10)]

    from ....utils.roots.roots import Root
    uvroot = Root.from_uv(u_, v_)
    a0, b0, c0 = uvroot.root
    as_vec = lambda a,b,c: np.array(
        [a**3, a**2*b, a**2*c, a*b**2, a*b*c, a*c**2, b**3, b**2*c, b*c**2, c**3]).astype(float)
    eqs.extend([as_vec(a0,b0,c0), as_vec(b0,c0,a0), as_vec(c0,a0,b0)])


    solved_params = _solve_flip_sgn_eqs(eqs, border, composed_cri)
    if solved_params is None:
        return None
    params_, mul_ = solved_params

    # print(f's(a2+{mul_}ab)' + poly_get_factor_form(poly))
    # ker = invarraylize(params_, cyc = False)
    # print(f's(a({poly_get_factor_form(ker)})2)')

    for rounding in (1, 144, 144**2, 144**3, 144**5):
        params = [Rational(round(_ * rounding), rounding) for _ in params_[:-1]]
        params.append(-sum(params)) # be sure that the sum is zero
        _, x1, x2, x3, x4, x5, x6, x7, x8, x9 = params
        border_sub = [
            2*x1 + x9**2,
            x1**2 + 2*x3 + 2*x5*x9,
            2*x1*x3 + 2*x2*x9 + x5**2 + 2*x6,
            2*x1*x6 + 2*x2*x5 + x3**2 + 2*x9,
            x2**2 + 2*x3*x6 + 2*x5,
            2*x2 + x6**2
        ]
        border_sub = Poly(border_sub, a)

        # compute a rationalization of mul_
        z_min = (-border_std_coeff5[1] + (2*x1+x9**2))/border_std_coeff5[0]
        det_z = (border_std_eval(z) - border_sub).as_poly(a).discriminant().as_poly(z)
        # print(border_sub, border_std)

        lower_bounds = nroots(det_z, method = 'numpy', real = True)
        lb = None
        for lb_ in lower_bounds:
            if lb_ >= z_min and (lb is None or lb_ < lb):
                lb = lb_
        else:
            lb = max(mul_, z_min)
        lb = Rational(round(lb * rounding + .5), rounding)
        border_rem_tmp = border_std_eval(lb) - border_sub
        if _verify_border_nonnegative(border_rem_tmp):
            border_rem = border_rem_tmp
            mul = lb
        else:
            mul = None
            # for index, ((left, right), __) in enumerate(det_z.intervals()[::-1]):
            if True:
                (left, right), _ = det_z.intervals()[-1]
                left, right = det_z.refine_root(left, right, eps = 1/rounding)#/24)
                for val in (left, right):
                    if val >= z_min:
                        border_rem_tmp = border_std_eval(val) - border_sub
                        # print('COUNT =', count_roots(border_rem_tmp, 0, None), 'LC =', border_rem_tmp.LC(), '\t', '(l,r) =', (left,right), 'index =', index)#border_rem_tmp.as_expr().n(5))
                        if _verify_border_nonnegative(border_rem_tmp):
                            border_rem = border_rem_tmp
                            mul = val
                            break
                # if left < z_min:
                #     break
            if mul is None:
                continue

        quartic_rem = _get_quartic_remain(mul, params, return_mpnq = False)
        if quartic_rem.LC() < 0:
            continue

        border_proof = _prove_quintic_from_border(coeff, border_rem)
        if border_proof is None:
            continue
        quartic_sub2 = _extract_quartic((a*b).as_poly(a,b,c) * Add(*border_proof).as_poly(a,b,c))
        quartic_rem -= quartic_sub2
        mpnq = [quartic_rem.coeff_monomial((4-i,)) for i in range(4)]

        # print('Det =', (3*m_*(m_+n_) - (p_**2+p_*q_+q_**2)).n(15),
        #   quartic_rem.as_expr().n(10), 'Mul =', mul.n(15), mul_)
        if criterion(*mpnq): # and m_ > 0:
            solution = _build_quintic_full_solution(
                coeff, mul, params, border_proof, mpnq)
            if solution is not None:
                return solution
    return None


#########################################################
#
#                       Windmill
#
#########################################################

def _sos_struct_quintic_windmill(coeff: 'Coeff'):
    """
    Give solution to s(a3b2+?a2b3+?ab4+?a3bc+?a2b2c) >= 0,

    Theorem:
    When u >= (v - 1)^2/4 + 1
    s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2) >= 0

    Examples
    --------
    => s(a2c(4a-3b-c)2)-20abcs(a2-ab)

    => s(a)2s(a2b)-9abcs(a2)

    => 4s(c(a-b)2(a-c)2)-s(c2(11a-15b-c)(a-b)2)

    => s(4a4c+a3b2-23a3bc+4a3c2+14a2b2c)

    => (s(c(4b2-c2)(a-b)2)-11s(c2(b-a)3))

    => 10s(a3b2-6/5a2b3+3/4ab4-101/40a3bc+79/40a2b2c)

    => 2s(a4b-3a3b2+4a2b3-2a2b2c)-17/2abcs(a2-ab)

    => s(a4b-3a3b2-8a3bc+7a3c2+3a2b2c)

    => s(c(2a2-ab-ac)2)-4abcs(a2-ab)

    => s(ab2(2(a-b)-5(b-c))2)-59abcs(a2-ab)

    => s(ac2(3(a-b)+5(b-c))2)-25abcs(a2-ab)

    => s(6a4c+10a3b2-67a3bc+19a3c2+32a2b2c)

    => s(a4c+a3b2-13a3bc+6a3c2+5a2b2c)

    => s(29a4c+711a3b2-4100a3bc+3599a3c2-239a2b2c)

    => s(8a4c+2a3b2-425a3bc+613a3c2-198a2b2c)

    => s(9a4c+a3b2-44a3bc+6a3c2+28a2b2c)

    => s(2a4b-6a3b2-5a3bc+8a3c2+a2b2c)

    => s(c(a-b)2(2a2+3ab+10ac+2c2))-abcs(a2-ab)

    => s((b-a+3c)(a2-b2+2(ab-ac)+31/9(bc-ab))2) # doctest:+SKIP

    => s((b-a+207/100c)((a2-b2+307/200(ab-ac)+247/100(bc-ab)))2) # doctest:+SKIP

    => s(a4c+a3b2-a3bc-a2b2c)-3*2^(2/3)s(a2-ab)p(a)

    Reference
    ---------
    [1] https://tieba.baidu.com/p/6472739202
    """
    solution = None
    if coeff((5,0,0)) != 0 or (coeff((4,1,0)) != 0 and coeff((1,4,0)) != 0):
        return None

    if coeff.poly111() < 0:
        return None


    if coeff((4,1,0)) != 0:
        # reflect the polynomial so that coeff((4,1,0)) == 0
        sol = _sos_struct_quintic_windmill(coeff.reflect())
        return align_cyclic_group(sol, coeff.gens)

    a = coeff.gens[0]

    # now we assume coeff((4,1,0)) == 0
    if coeff((1,4,0)) < 0:
        return None
    elif coeff((1,4,0)) == 0:
        return _sos_struct_quintic_windmill_degenerated(coeff)

    c320 = coeff((3,2,0))
    if c320 == 0:
        if coeff((2,3,0)) >= 0:
            solution = _sos_struct_quintic_uncentered(coeff)
        return solution
    elif c320 < 0:
        return None


    _solvers = [
        _sos_struct_quintic_windmill_trivial,
        _sos_struct_quintic_windmill_trivial2,
        _sos_struct_quintic_windmill_quadratic # now we have to lift the degree
    ]
    for _solver in _solvers:
        solution = _solver(coeff)
        if solution is not None:
            return solution


    x, y, z, = coeff((1,4,0)) / c320, coeff((2,3,0)) / c320, coeff((3,1,1)) / c320
    u_ = None

    def _compute_coeffs(u, v):
        """
        Compute the coefficients ab^4, a^2b^3, a^3bc of the regularized polynomial
        s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2) / (2*u**3-2*u**2-2*u*v+2*u+2).
        Note that the regularized polynomial has coefficient a^3b^2 == 1.
        """
        denom = u**3 - u**2 - u*v + u + 1
        x2 = (u + v - 1)/denom
        y2 = (-2*u**2 + u*v**2 - u*v + 2*u - v - 1)/denom
        z2 = (-2*u**2*v + u**2 + u*v - v**2)/denom
        return x2, y2, z2


    # Now we formally start.
    # Define g(a,b,c) = f(a,b,c) - s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2) / (2*u**3-2*u**2-2*u*v+2*u+2)
    # Then the a^3b^2 coefficient of g is zero.
    # The following v (a function of u) ensures that the ab^4 coefficient of g is also zero.
    # and we only need to solve for u so that the a^2b^3 coefficient of g approximates to 0.
    # The `eq` here is (-coeff(g, a^2b^3) * (u+1) * (ux+1)), we need it <= 0.
    _compute_v = lambda u: (u**3*x - u**2*x + u*x - u + x + 1) / (u*x + 1)
    eq = coeff.from_list([
        x**2,
        -x**2,
        -2*x,
        -x**2 - x*y + x,
        -x*y - 4*x - y + 1,
        -x - y - 2
    ], (a,)).as_poly()

    def _is_valid_uv(u, v):
        """
        Make sure that
        f(a,b,c) - s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2) / (2*u**3-2*u**2-2*u*v+2*u+2) >= 0,
        by ensuring the coefficients of ab^4 >= 0, a^2b^3 >= 0,
        and a^3bc >= 0 after subtracting (x - x_) * s(a^2c(a-b)^2).
        """
        # if not (u >= (v-1)**2/4 + 1 or
        #         (2*u**2-u*v**2+u*v-2*u+v+1 <= 0 and u**3-u**2-u*v+u+1 >= 0)):
        #     return False
        if u**3 - u**2 - u*v + u + 1 <= 0:
            return False
        x2, y2, z2 = _compute_coeffs(u, v)
        return x2 <= x and y2 <= y and (z - z2) / 2 + x - x2 >= 0

    def _is_valid_u(u):
        if u < 1: return False
        return _is_valid_uv(u, _compute_v(u))

    eq_linears = [factor for factor, mul in eq.factor_list()[1] if factor.total_degree() == 1]
    for eq_linear in eq_linears:
        root = -eq_linear.rep.TC() / eq_linear.rep.LC()
        root = coeff.convert(root)
        # first try rational u, v if exists
        if _is_valid_u(root):
            u_ = root
            v_ = _compute_v(u_)
            break
    else:
        if not coeff.is_rational:
            return None

        # General case: add a small perturbation so that we can obtain rational u and v
        if not ((y < 0) and (y**2 == 4*x)):
            u_ = rationalize_func(eq, _is_valid_u, validation_initial = lambda u: u >= 1, direction = -1)
            if u_ is None:
                return None

            # Despite (u,v) cancels out a^3b^2 and ab^4 terms perfectly,
            # the v is oftentimes too complicated.
            # We can find a nicer v sometimes.
            v_ = _compute_v(u_)
            for v__ in rationalize_bound(u_.q * v_.n(15), direction = -1, compulsory = True):
                # trick: keep the denominator of v and u aligned
                v__ /= u_.q
                if _is_valid_uv(u_, v__):
                    v_ = v__
                    break
            else:
                # restore the complicated solution
                v_ = _compute_v(u_)

        else:
            return _sos_struct_quintic_windmill_border(coeff)


    # Now we call the solver to solve the problem at (u, v).
    u, v = u_, v_
    main_solution = _sos_struct_quintic_windmill_uv(coeff, u, v)

    if main_solution is not None:
        multiplier, main_solution = main_solution

        denom = u**3 - u**2 - u*v + u + 1
        _new_coeffs = {
            (2,3,0): y + (2*u**2-u*v**2+u*v-2*u+v+1) / denom,
            (1,4,0): x - (u+v-1) / denom,
            (3,1,1): z + (2*u**2*v-u**2-u*v+v**2) / denom,
            (2,2,1): coeff((2,2,1)) / c320 - (-u**3 + 2*u**2*v + 2*u**2 - u*v**2 + u*v - 4*u + v**2 + 1) / denom
        }

        rest_solution = _sos_struct_quintic_windmill(coeff.from_dict(_new_coeffs))
        if rest_solution is not None:
            ker = c320 / 2 / denom
            return (ker * main_solution + c320 * multiplier * rest_solution) / multiplier

    return None


def _sos_struct_quintic_windmill_degenerated(coeff: 'Coeff'):
    """
    coeff((4,1,0)) == coeff((1,4,0)) == 0
    now if we change variables a -> 1/a, b -> 1/b, c -> 1/c, it will be quartic
    so we can see that coeff((3,0,2)) * x^2 + coeff((3,1,1)) * x + coeff((3,2,0)) >= 0
    e.g. s(a3b2+4a2b3-5a2b2c)-4abcs(a2-ab)
    """
    if coeff((4,1,0)) != 0 or coeff((1,4,0)) != 0:
        return None

    const_ = coeff((3,2,0)) + coeff((2,3,0)) + coeff((3,1,1)) + coeff((2,2,1))
    u_ = None
    if coeff((3,2,0)) < 0 or coeff((2,3,0)) < 0 or const_ < 0:
        y = None
    elif coeff((3,1,1)) >= 0:
        y = [0, coeff((3,2,0)), coeff((2,3,0)), coeff((3,1,1)) / 2, const_]
    elif coeff((3,1,1)) ** 2 > 4 * coeff((3,2,0)) * coeff((2,3,0)):
        y = None
    else:
        u_ = coeff((3,1,1)) / (-2 * coeff((3,2,0)))
        y = [coeff((3,2,0)), 0, coeff((2,3,0)) - coeff((3,2,0)) * u_ ** 2, 0, const_]

    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product
    if y is not None and all(_ >= 0 for _ in y):
        exprs = [
            CyclicSum(b*(u_*a*b-(u_-1)*a*c-b*c)**2 if u_ is not None else a**3*b*c),
            CyclicSum(a**2*c*(b-c)**2),
            CyclicSum(a**2*b*(b-c)**2),
            CyclicSum((b-c)**2) * CyclicProduct(a),
            CyclicSum(a*b) * CyclicProduct(a)
        ]
        return sum_y_exprs(y, exprs)


def _sos_struct_quintic_windmill_trivial(coeff: 'Coeff'):
    """
    Solve very simple cases without lifting the degree using several ideas.
    """
    if coeff((4,1,0)) != 0:
        return
    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product
    rem = (coeff.poly111() / 3) * CyclicSum(a*b) * CyclicProduct(a)
    if True:
        # Easy case 2. in the form of s(c(a-b)2(xa2+yac+zc2+uab+vbc)) + ...s(a2b2c)
        # such that y^2 <= 4xz where x = coeff((1,4,0)) is fixed

        if coeff((2,3,0)) >= 0:
            # A. possibly simple and nice
            t = min(coeff((3,2,0)), coeff((2,3,0)))
            y = [
                coeff((1,4,0)), t,
                coeff((3,1,1)) / 2 + coeff((1,4,0)) + t,
                abs(coeff((3,2,0)) - coeff((2,3,0))),
            ]
            if all(_ >= 0 for _ in y):
                character = b if coeff((3,2,0)) >= coeff((2,3,0)) else a
                p1 = (y[0]*a**2 + y[1]*c**2 + y[2]*a*b + y[3]*character*c).together()
                return CyclicSum(c*(a-b)**2*p1) + rem

        # B. y^2 <= 4xz
        # x = coeff((1,4,0))
        # y + z = coeff((2,3,0))
        # v + z = coeff((3,2,0)) => z <= coeff((3,2,0)) => y >= coeff((2,3,0)) - coeff((3,2,0)
        # -2(x + z) + 2u = coeff((3,1,1)) => z >= - x - coeff((3,1,1)) / 2
        #      => y <= coeff((2,3,0)) + x + coeff((3,1,1)) / 2
        # Problem: whether y >= ... has a solution such that
        # y^2 <= 4x(coeff((2,3,0)) - y)

        bound_l = coeff((2,3,0)) - coeff((3,2,0))
        bound_r = coeff((2,3,0)) + coeff((1,4,0)) + coeff((3,1,1)) / 2
        if bound_l <= bound_r:
            bound = -2 * coeff((1,4,0)) # symmetric axis
            if bound_l <= bound <= bound_r:
                # symmetric axis inbetween
                pass
            elif bound <= bound_l:
                bound = bound_l
            else:
                bound = bound_r

            y = [
                coeff((1,4,0)),
                bound,
                coeff((2,3,0)) - bound,
                (coeff((3,1,1)) / 2 + coeff((1,4,0)) + (coeff((2,3,0)) - bound)),
                coeff((3,2,0)) - (coeff((2,3,0)) - bound)
            ]

            if (y[0] >= 0 and y[2] >= 0 and 4*y[0]*y[2] >= y[1]**2):
                p1 = (quadratic_weighting(coeff, y[0], y[1], y[2], [a, c]) + y[3]*a*b + y[4]*b*c).together()
                return CyclicSum(c*(a-b)**2*p1) + rem

    x_, y_, z_ = [coeff((1,4,0)) / coeff((3,2,0)), coeff((2,3,0)) / coeff((3,2,0)), coeff((3,1,1)) / coeff((3,2,0))]
    if True:
        # Easy case 3. try another case where we do not need to lift the degree
        # idea: use s(a*b^2*(a-ub+(u-1)c)^2)
        u_ = (y_ / (-2))
        y = [
            1,
            x_ - u_ ** 2,
            (z_ - (-2 * u_**2 + 2 * u_)) / 2 + (x_ - u_ ** 2)
        ]
        if all(_ >= 0 for _ in y):
            y = [_ * coeff((3,2,0)) for _ in y]
            exprs = [
                CyclicSum(a*b**2*(a-u_*b+(u_-1)*c)**2),
                CyclicSum(a*b**2*(b-c)**2),
                CyclicSum((b-c)**2) * CyclicProduct(a)
            ]
            return sum_y_exprs(y, exprs) + rem

    if True:
        # Easy case 4. use s(c*(a-c)^2*(a-t*b)^2)
        if x_ >= 1:
            t = (z_ + 2*(x_ - 1)) / (-4)
            y1 = (coeff((2,3,0)) - (t**2 - 2) * coeff((3,2,0)))
            if y1 >= 0:
                y2 = coeff((1,4,0)) - coeff((3,2,0))
                p1 = coeff((3,2,0)) * CyclicSum(c*(a-c)**2*(a-t*b)**2)
                p2 = CyclicSum(a*c*(a-b)**2*(y1*c + y2*a).together())
                return p1 + p2 + rem
        elif x_ < 1:
            # two cases:
            # 1. x_s(c(a-c)2(a-tb)2) + ?s(a3(b-c)2) + ??s(bc2(a-b)2)
            # 2. x_s(c(a-c)2(a-tb)2) + ?s(a3(b-c)2) + ??s(a2c(a-b)2)
            # -z/2 - 2tx >= 0
            # 1 + 2tx - x + z/2 >= 0
            # thus, (x - z/2 - 1)/(2x) <= t <= -z/(4x)
            # in this bound, we should make t as close to 1 as possible
            # to minimize t^2 - 2t - 2
            bound_l = (x_ - z_ / 2 - 1) / (2*x_)
            bound_r = -z_ / (4*x_)
            if bound_l <= bound_r:
                if bound_l <= 1 <= bound_r:
                    t = Integer(1)
                elif abs(bound_l - 1) < abs(bound_r - 1):
                    t = bound_l
                else:
                    t = bound_r

                # the sum of following equals to the polynomial
                y = [
                    x_,
                    -z_ / 2 - 2*t*x_,
                    1 + 2*t*x_ - x_ + z_ / 2,
                    y_ - (t**2 - 2*t - 2)*x_ + z_ / 2
                ]
                # print('(l,r) =', (bound_l, bound_r), '  t =', t,'\ny =', y)
                if all(_ >= 0 for _ in y):
                    y = [_ * coeff((3,2,0)) for _ in y]
                    exprs = [
                        CyclicSum(c*(a-c)**2*(a-t*b)**2),
                        CyclicSum(a**3*(b-c)**2),
                        CyclicSum(b*c**2*(a-b)**2),
                        CyclicSum(a*c**2*(a-b)**2)
                    ]
                    return sum_y_exprs(y, exprs) + rem


def _sos_struct_quintic_windmill_trivial2(coeff: 'Coeff'):
    """
    Try subtracting `s(c(a2-ab-u(ac-ab)+v(bc-ab))2)`
    and the rest does not have `s(ab^4)` term.
    In this case, we must have `coeff((2,3,0))*coeff((3,2,0))*4 >= coeff((3,1,1))**2`,
    which is equivalent to `det <= 0` where `det =`

    ```
    8*u^3-8*u^2*v+(4*y+4)*u^2+8*u*v^2+4*z*u*v+(-8*x-4*z-8)*u+(4*x+4)*v^2+(4*z+8)*v-4*x*y+z^2+4*z+4
    ```

    It is a quadratic function of v, so WLOG `v = symmetric axis = (2*u**2 - u*z - z - 2)/(2*(2*u + x + 1))`.
    Substitute it back, the discriminant is factorizable and we require
    `det_u = 12*u**2 + (8*x + 8*y + 4*z + 16)*u + 4*x*y + 4*y - z**2 - 4*z - 4 >= 0`,
    meanwhile `coeff((3,2,0)) >= 0` requires `u^2 <= x`.
    """
    if not coeff.is_rational:
        return None
    c140 = coeff((1,4,0))
    x, y, z = coeff((3,2,0)) / c140, coeff((2,3,0)) / c140, coeff((3,1,1)) / c140

    eq1 = 12*x + 4*x*y + 4*y - (z + 2)**2
    sym1 = 8*x + 8*y + 4*z + 16
    if eq1 >= 0 or eq1**2 <= sym1**2 * x:
        # det_u >= 0
        u = sqrt(x)
        if not isinstance(u, Rational):
            eq1 -= 12*x
            det_u = lambda u: 12*u**2 + sym1*u + eq1
            for u_ in rationalize_bound(u.n(15), direction = -1, compulsory = True):
                if det_u(u_) >= 0 and u_**2 <= x: # prevent u_ < 0 but u_^2 >= x
                    u = u_
                    break
            else:
                u = None
        if u is not None:
            v = (2*u**2 - u*z - z - 2)/(2*(2*u + x + 1))
            # print(u, v, sym1, eq1)
            _new_coeffs = {
                (3,2,0): x - u**2,
                (2,3,0): y + 2*u - v**2,
                (3,1,1): 2*u*v - 2*u + 2*v + z + 2,
                (2,2,1): coeff((2,2,1)) / c140 + ((u - v)**2 - 2*v - 1)
            }
            solution = _sos_struct_quintic_windmill(coeff.from_dict(_new_coeffs))
            if solution is not None:
                a, b, c = coeff.gens
                CyclicSum = coeff.cyclic_sum
                return solution * c140 \
                    + c140 * CyclicSum(c*(a**2+(u-v-1)*a*b-u*a*c+v*b*c)**2)


def _sos_struct_quintic_windmill_quadratic(coeff: 'Coeff'):
    """
    First try whether we can handle neat cases.
    Theorem 1.1:
    f(a,b,c) = s(a(ac+b^2-2bc)^2(a-b)^2) = s(a^2-ab)s(a^4c-3a^3bc+2a^2b^2c) >= 0
    g(a,b,c) = s(a(ab-2bc+c^2)^2(a-b)^2) = s(a^2-ab)s(a^3b^2-a^2b^2c) >= 0
    h(a,b,c) = s(a(ac+b^2-2bc)(ab-2bc+c^2)(a-b)^2) = -s(a^2-ab)s(a^3bc-a^3c^2)
    Then,
    c1f(a,b,c) + c2h(a,b,c) + c3g(a,b,c) >= 0 holds when c2^2 <= 4c1c3
    """

    # Case A.
    c1, c2, c3 = coeff((1,4,0)), None, coeff((3,2,0))
    c320, c230, c311, c221 = [coeff(_) for _ in [(3,2,0),(2,3,0),(3,1,1),(2,2,1)]]

    # Constraints on c2:
    # c2 <= coeff((2,3,0))
    # -3*c1 - c2 <= coeff((3,1,1))
    # Thus,
    # -3*c1 - coeff((3,1,1)) <= c2 <= coeff((2,3,0))
    # Also, c2^2 <= 4c1c3
    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    lb_, ub_ = -3*c1 - c311, c230
    if lb_ <= ub_:
        if ub_ < 0:
            c2 = ub_
        elif lb_ > 0:
            c2 = lb_
        else:
            c2 = Integer(0)

    if c2 is not None and c2**2 <= 4*c1*c3:
        pp = (c3 - c2**2/(4*c1)) * b + (c230 - c2) * a
        pp = pp.together().as_coeff_Mul()
        y = [
            2 * c1,
            pp[0],
            (c311 + 3*c1 + c2) / 2,
        ]
        if all(_ >= 0 for _ in y):
            multiplier = CyclicSum((a-b)**2)
            w = c2/(2*c1)
            exprs = [
                CyclicSum(a*(a-b)**2*(w*a*b-(2+2*w)*b*c+w*c**2+a*c+b**2)**2),
                CyclicSum(c**2*(a-b)**2*pp[1]) * multiplier,
                CyclicProduct(a) * CyclicSum((a-b)**2)**2
            ]
            return sum_y_exprs(y, exprs) / multiplier + (coeff.poly111()/3) * CyclicSum(a*b) * CyclicProduct(a)

    # Case B.
    # Assume we subtract c1(f(a,b,c) + wg(a,b,c))^2, then the remaining does not contain s(ab^4) term.
    # In this case, we must have c230*c320*4 >= c311**2

    # eq = (-(c320 - c1*w**2) * (c230 - 2*c1*w) * 4 + (c311 + c1*(3 + 2*w))**2).as_poly(w)
    # eq2 = (c230 - 2*c1*w).as_poly(w)
    if not coeff.is_rational:
        return None
    w = None
    eq = coeff.from_list([
        -8*c1**2,
        4*c1**2 + 4*c1*c230,
        12*c1**2 + 4*c1*c311 + 8*c1*c320,
        9*c1**2 + 6*c1*c311 - 4*c230*c320 + c311**2
    ], (a,)).as_poly()
    eq2 = coeff.from_list([-2*c1, c230], (a,)).as_poly()
    for (w_, interval_end), _ in (eq * eq2).intervals():
        if eq2.eval(w_) >= 0 and eq.eval(w_) <= 0:
            w = coeff.convert(w_)
            break

    if w is not None:
        multiplier = CyclicSum((a-b)**2)
        _new_coeffs = {
            (3,2,0): c320 - c1*w**2,
            (2,3,0): c230 - 2*c1*w,
            (3,1,1): c311 + c1*(3 + 2*w),
            (2,2,1): c221 - c1*(2 - w**2),
        }

        solution = _sos_struct_quintic_windmill(coeff.from_dict(_new_coeffs))
        if solution is not None:
            return (2*c1*CyclicSum(a*(a-b)**2*(w*a*b-(2+2*w)*b*c+w*c**2+a*c+b**2)**2) + solution * multiplier) / multiplier


def _sos_struct_quintic_windmill_uv(coeff: 'Coeff', u, v):
    """
    Given (u,v), solve the inequality
    `f(a,b,c) = s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2) >= 0`.

    Return the multiplier g and the sum-of-squares proof for f*g.

    Reference
    -------
    [1] https://tieba.baidu.com/p/6472739202
    """
    if u is None or v is None or u + v < 1:
        return None

    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    if u > 1 and 2*u**2 - u*v - 2*u + 3 >= 0 and u**2 + u*v - u - v**2 + v - 1 >= 0:
        # Theorem 2.0
        # When 2u^2-uv-2u+3 >= 0 and u^2+uv-u-v^2+v-1 >= 0, the inequality holds.
        # Because it yields better solution than Theorem 1, we use it first.

        # This is because
        # (u - 1)*(u + v - 1) * F1 + (2*u**2 - u*v - 2*u + 3) * F2 + (-u**2 + u*v + 3*u - v**2 + 3*v - 5) * F3
        # = (2u - v + 1)/2 * s(a^2-ab) * s((b-a+(2u-1)c)(a^2-b^2+u(ab-ac)+v(bc-ab))^2)
        # where
        # F1 = s(a(b-c)^2(a^2-b^2+u(ab-ac)+v(bc-ab))^2)
        # F2 = s(a(a-b)^2(b^2-c^2+u(bc-ba)+v(ca-bc))^2)
        # F3 = s(a(a-b)(b-c)(a^2-b^2+u(ab-ac)+v(bc-ab))(b^2-c^2+u(bc-ba)+v(ca-bc)))

        c1 = (u - 1)*(u + v - 1)
        c2 = (2*u**2 - u*v - 2*u + 3)
        c3 = (-u**2 + u*v + 3*u - v**2 + 3*v - 5)

        multiplier = CyclicSum((a-b)**2)
        denom2 = ((2*u - v + 1) / 4)

        y = [
            c1 / denom2,
            (c2 - c3**2 / (4*c1)) / denom2
        ]

        p1 = (b - c) * (a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))
        p2 = (a - b) * (b**2 - c**2 + u*(b*c-a*b) + v*(c*a-b*c))
        exprs = [
            CyclicSum(a * ((p1 + c3/(2*c1)*p2).expand())**2),
            CyclicSum(a * p2**2)
        ]

        return multiplier, sum_y_exprs(y, exprs)


    if u >= (v - 1)**2/4 + 1:
        # Theorem 1 (Main Theorem)
        # When u >= (v - 1)^2/4 + 1, the inequality holds.

        multiplier = CyclicSum(a**2 + (u+v+1)*b*c)

        p1 = (-u*v + u + 2)*a**2*b + (-2*u + v**2 + 3)*a**2*c + (-u*v + u - v + 1)*a*b**2 \
            + (-4*u**2 + 4*u*v + 2*u - v**2 - 3*v)*a*b*c + (2*u**2 + u*v - 3*u - v - 1)*a*c**2 + (-v - 1)*b**3 \
            + (2*u**2 - u*v + 3*u + v**2 + 2*v - 3)*b**2*c + (-2*u*v - 2*u - v**2 + 4*v - 1)*b*c**2
        p2 = u*a**2*b + (-v - 1)*a**2*c + (u - 1)*a*b**2 + (-2*u + v)*a*b*c \
            + (u + 1)*a*c**2 - b**3 + (-u + v + 1)*b**2*c + (1 - v)*b*c**2

        exprs = [
            CyclicSum(a * p1**2),
            CyclicSum(a * p2**2),
            CyclicProduct(a) * CyclicSum((a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))**2)
        ]

        y = [
            Rational(1, 2),
            (4*u - v*v + 2*v - 5) / 2,
            (u + v + 2) * (4*u + v - 4)
        ]

        return multiplier, sum_y_exprs(y, exprs)


    if (3*u**2 + 2*u*v - 4*u - v**2 - 8) >= 0:
        # Theorem 2.1
        # When 3u^2 + 2uv - 4u - v^2 - 8 >= 0, the inequality holds.

        multiplier = CyclicSum(a*b)

        denom = u**3 - u**2 - u*v + u + 1
        denom2 = 2 * (u+1)**2 * denom
        g = -(u**2 - u*v + 2*u + 2)/(2*u**3 + u**2*v - u*v**2 - u + v + 2)

        p1 = a**2*c*(-u*v + 1) + a*b**2*(u**2*v - u) + a*b*c*(u**3 - u**2*v - u**2 + u*v + u - v) \
            + b**2*c*(-u**3 - 1) + b*c**2*(u**2 + v)
        p2 = a**2*c + a*b**2*(g*u*v - g) + a*b*c*(g*u**2 - g*u - g*v**2 + g*v + u - v) \
            + a*c**2*(-g*u*v + g - u) + b**2*c*(-g*u**2 - g*v - 1) + b*c**2*(g*u + g*v**2 + v)

        exprs = [
            CyclicSum(a * p1**2),
            CyclicSum(a * p2**2),
            CyclicProduct(a) * CyclicSum((a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))**2)
        ]

        y = [
            (3*u**2 + 2*u*v - 4*u - v**2 - 8) / denom2,
            (2*u**3 + u**2*v - u*v**2 - u + v + 2)**2 / denom2,
            u + v - 1
        ]

        return multiplier, sum_y_exprs(y, exprs)

    if u**2 - u*v + 2*u + 2 < 0:
        # Theorem 2.2 (very ugly)
        # When (u,v) is in the following region, the inequality holds:
        # u^2-uv+2u+2 < 0
        # 3*u^7-u^6*v-2*u^6-u^5*v^2+u^5*v-5*u^5+3*u^4*v^2-4*u^4*v-u^3*v^2+u^3*v+2*u^3+2*u^2*v^2+8*u^2*v-10*u^2+u*v^2-3*u*v-9*u-v <= 0
        # 6*u^6-2*u^5*v+11*u^5-2*u^4*v^2-3*u^4*v+11*u^4+u^3*v^2-5*u^3*v+13*u^3-2*u^2*v^2-12*u^2*v+18*u^2-2*u*v^2+20*u+2*v+6 <= 0

        # Although the region is complicated, it handles almost all cases with very large v.

        w = (3*u**5 - u**4*v + 4*u**4 - u**3*v**2 + u**3 - 2*u*v + 2*u + 2)/(u**2*(u**2 - u*v + 2*u + 2))
        if w >= -1:
            multiplier = CyclicSum(a**2 + w*b*c)

            p3 = a**2*c*(-u*v + 1) + a*b*c*(u**3 - u**2*v - u**2 + u*v**2 + u*v + u - 2*v) \
                + b**3*(u*v - 1) + b**2*c*(-u**3 + u**2*v - u*v**2 - u + v - 1) + b*c**2*(u**2 - u*v + v + 1)
            p4 = a**2*c*(-u*v + 1) + a*b**2*(u**2*v - u) + a*b*c*(u**3 - u**2*v - u**2 + u*v + u - v) \
                + b**2*c*(-u**3 - 1) + b*c**2*(u**2 + v)

            exprs = [
                CyclicSum(a*(u*a**2*b+(-v-1)*a**2*c+(u-1)*a*b**2+(-2*u+v)*a*b*c\
                             +(u+1)*a*c**2-b**3+(-u+v+1)*b**2*c+(1-v)*b*c**2)**2),
                CyclicSum(a*c**2*(a**2-b**2+u*(a*b-a*c)+v*(b*c-a*b))**2),
                CyclicSum(a * p3**2),
                CyclicSum(a * p4**2),
                CyclicProduct(a) * CyclicSum((a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))**2)
            ]

            y = [
                2 * (u**3 - u**2 - u*v + u + 1) / u**2,
                2 * (u**5*w - 3*u**5 - u**4*w + u**4 + u**3*v**2 - u**3*v*w + 2*u**3*v \
                     + u**3*w - 2*u**3 - u**2*v + u**2*w - 3*u**2 + u*v - u - 1) / u**4,
                2 * (u + 1) / (u**2 * (u*v - 1)),
                2 * (3*u**4*v - u**4 - u**3*v**2 + 3*u**3*v - 6*u**3 - u**2*v**3 + u**2*v**2 \
                     + 3*u**2*v - 6*u**2 + 2*u*v**2 - u*v - 3*u - v)/(u**3*(u*v - 1)*(u**2 - u*v + 2*u + 2)),
                (6*u**6 - 2*u**5*v + 11*u**5 - 2*u**4*v**2 - 3*u**4*v + 11*u**4 + u**3*v**2 \
                 - 5*u**3*v + 13*u**3 - 2*u**2*v**2 - 12*u**2*v + 18*u**2 - 2*u*v**2 + 20*u + 2*v + 6)\
                    /(u**2*(u**2 - u*v + 2*u + 2)),
            ]

            if all(_ >= 0 for _ in y):
                return multiplier, sum_y_exprs(y, exprs)


def _sos_struct_quintic_windmill_border(coeff: 'Coeff'):
    """
    Case Special. when y_ < 0 and y_^2 = 4x_, then there is a root on the border
    then perturbation has no chance,
    e.g. s(c(2a2-ab-ac)2)-4abcs(a2-ab)

    We take the limit of our sum-of-squares proof to the numerical, exact solution.
    """
    if coeff((4,1,0)) != 0:
        return None
    c320 = coeff((3,2,0))
    x, y, z = coeff((1,4,0)) / c320, coeff((2,3,0)) / c320, coeff((3,1,1)) / c320
    rem = coeff((2,2,1)) / coeff((3,2,0)) + (x + y + z + 1)
    if y**2 != 4*x or rem < 0:
        return None

    a, b, c = coeff.gens
    # first solve v, which is a cubic equation
    # r = -4(v+1) / (v**3 - 3*v**2 + 7*v - 13)
    r = -y / 2
    # eq = ((v**3 - 3*v**2 + 7*v - 13) + 4*(v+1) / r).as_poly(v)
    eq = coeff.from_list([1, -3, (7*r + 4)/r, (4 - 13*r)/r], (a,)).as_poly()
    # we can see that eq is strictly increasing and has a real root > -1
    roots = nroots(eq, method='factor', real=True)
    if len(roots) == 0:
        return None
    v = roots[0]

    # the true g is given by
    # g = b*(a**2 + (1-r)*a*b - r*b**2 + 2*(r-1)*a*c) + z0*a*c*(r*a - c - (r-1)*b) + b*c*(z1*b+z2*c-(z1+z2)*a)
    # with z0, z1, z2 given below
    z0  = (v + 1)/2
    z1 = (3 - v)/2 + r*(2*v - 1)
    z2 = r*(1 - v)*(3*v - 1)/4 - 1

    w = z # coeff((3,1,1)) / c320
    # we have det >= 0 as long as w < -1 (in non-trivial case)
    def compute_discriminant(z0, z1, z2):
        """Require z0, z1, z2 that m >= 0 and disc >= 0"""
        m = r**2*z0**2 + 2*r**2 - 2*r*z0 + 2*r*z1 + w
        n = -r**2*z0**2 + 2*r**2 - 2*r*z0**2 - 2*r*z0*z2 + 8*r*z0 - 2*r*z1 - 2*r*z2 - 8*r - w*z0**2 + 2*z0**2 - 2*z0*z1 - 2*z0*z2 - 6*z0 - 2*z1*z2 + 2*z2 + 4
        p = 2*r**2*z0 + 2*r*z2 - 2*r + w*z0**2 + w + z0**2 + 2*z0*z2 - 2*z0 - z1**2 + 2*z1 + 2*z2 + 5
        q = 3*r**2*z0**2 - 6*r**2*z0 + 5*r**2 - 4*r*z0**2 + 2*r*z0*z1 + 2*r*z0*z2 + 6*r*z0 - 2*r*z2 - 6*r + w*z0**2 + w + 2*z0 - 2*z1 - z2**2 - 1
        disc = 3*m*(m + n) - (p**2 + p*q + q**2)
        return m, p, n, q, disc

    disc, m = -1, -1
    for rounding in (.5, .2, .1, 1e-2, 1e-3, 1e-5, 1e-8):
        z0_, z1_, z2_ = [rationalize(_, rounding = rounding, reliable = False) for _ in (z0, z1, z2)]
        m, p, n, q, disc = compute_discriminant(z0_, z1_, z2_)
        if disc >= 0 and m > 0:
            break

    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product
    if disc >= 0 and m > 0:
        multiplier = CyclicSum(a**2 + (z0_**2 + 2)*b*c)
        y = [1, m / 2, disc / 6 / m, rem]
        y = [_ * c320 for _ in y]
        exprs = [
            CyclicSum(a*(a**2*b+(1-r)*a*b**2-r*b**3+(r*z0_)*a**2*c-z0_*a*c**2+z1_*b**2*c+z2_*b*c**2-((2-z0_)*(1-r)+z1_+z2_)*a*b*c)**2),
            CyclicProduct(a) * CyclicSum((a**2-b**2-(p + 2*q)/3/m*(a*b-a*c)-(q + 2*p)/3/m*(b*c-a*b))**2),
            CyclicProduct(a) * CyclicSum(a**2*(b-c)**2),
            CyclicProduct(a) * CyclicSum(a*b) * CyclicSum(a**2+(z0_**2 + 2)*a*b)
        ]

        return sum_y_exprs(y, exprs) / multiplier


def _sos_struct_quintic_uncentered(coeff: 'Coeff'):
    """
    Give the solution to s(ab4+?a2b3-?a3bc+?a2b2c) >= 0,
    which might have equality not at (1,1,1) but elsewhere.

    Examples
    --------
    => s(2ab4+5a2b3-17a3bc+13a2b2c)

    => s(ab4+347/30a2b3-3833/230a3bc+475/69a2b2c)

    => s(ab4+0a2b3-19/4a3bc+9/2a2b2c)

    => s(2ab4+4a2b3-13a3bc+7a2b2c)

    => s(a2c(a-b)(a+c-4b))

    => s(a2c(a-5/2b)2)-abcs(8a2-131/4ab)

    References
    ----------
    [1] https://artofproblemsolving.com/community/u426077h2242759p21856167

    [2] https://artofproblemsolving.com/community/u861323h3019177p27134161

    [3] https://tieba.baidu.com/p/7710460926
    """
    rem = coeff((2,3,0)) + coeff((1,4,0)) + coeff((3,1,1)) + coeff((2,2,1))
    if rem < 0:
        return None
    if rem == 0 and coeff((2,3,0)) == 0:
        return _sos_struct_quintic_windmill_special(coeff)

    u, v = Symbol('u'), Symbol('v')
    t = coeff((1,4,0))

    r1, r2, r3, u_, v_ = coeff((2,3,0)) / t, coeff((3,1,1)) / t, coeff((2,2,1)) / t, None, None
    r1_, r2_ = r1, r2

    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    if True:
        y = [coeff((2,3,0)), coeff((1,4,0)), coeff((3,1,1)) / 2 + coeff((1,4,0)), rem]
        if all(_ >= 0 for _ in y):
            exprs = [
                CyclicSum(a**2*b*(b-c)**2),
                CyclicSum(a*b**2*(b-c)**2),
                CyclicSum((b-c)**2) * CyclicProduct(a),
                CyclicSum(a*b) * CyclicProduct(a)
            ]
            return sum_y_exprs(y, exprs)

    if t <= 0:
        # the case t == 0 should already be handled above
        return None

    if True:
        # Theorem 1.
        # f(a,b,c) = s(a(ac+b^2-2bc)^2(a-b)^2) = s(a^2-ab)s(a^4c-3a^3bc+2a^2b^2c) >= 0
        # g(a,b,c) = s(a(ac+b^2-2bc)^2(a-c)^2) = s(a^2-ab)s(a^3c^2-a^2b^2c) >= 0
        # h(a,b,c) = s(a(ac+b^2-2bc)^2(a-b)(a-c)) = s(a^2-ab)^2 * abc
        # This implies that f(a,b,c) - 2xh(a,b,c) + x^2g(a,b,c) >= 0.
        # This gives very beautiful solution, if valid.
        x = max(0, (r2 + 3) / (-2))
        y = [
            2,
            r1 - x**2,
            (r2 - (-3 - 2*x)) / 2,
            rem / t
        ]
        if all(_ >= 0 for _ in y):
            multiplier = CyclicSum((a-b)**2)
            y = [_ * t for _ in y]
            exprs = [
                CyclicSum(a*(a*c+b**2-2*b*c)**2*((1-x)*a - b + x*c)**2),
                CyclicSum(a*c**2*(a-b)**2) * multiplier,
                CyclicProduct(a) * CyclicSum((a-b)**2)**2,
                CyclicSum(a*b) * CyclicProduct(a) * multiplier
            ]
            return sum_y_exprs(y, exprs) / multiplier


    if not coeff.is_rational:
        return None

    if rem == 0:
        # v = (u^3 - u^2 + u + 1) / u
        eq = coeff.from_list([1, -1, 0, -(1 + r1), -r1], (u,)).as_poly()

        def _compute_v_r1_r2(u):
            v = (u**3 - u**2 + u + 1)/u
            r1 = u*(u**3 - u**2 - 1)/(u + 1)
            r2 = -(3*u**4 - 2*u**3 + 3*u + 1)/(u*(u + 1))
            return v, r1, r2

        def _is_valid(u):
            if u > 0:
                v, r1_, r2_ = _compute_v_r1_r2(u)
                return 0 <= r1_ <= r1 and r2_ <= r2
            return False

        u_ = rationalize_func(eq, _is_valid, validation_initial = lambda u: u > 0, direction = -1)
        if u_ is None:
            return
        v_, r1_, r2_ = _compute_v_r1_r2(u_)

    elif rem > 0:

        if r1 == 0 and r2 == -13:
            # The only exception where u, v are irrational but coefficients are rational
            # is s(a2c(a-5/2b)2)-abcs(8a2-131/4ab)
            # in this case u = 1/2, v = (17+3*sqrt(13))/4
            # So we use the direct result:
            # (s(a2c(a-5/2b)2)-abcs(8a2-131/4ab))s(ab(a-b+3c)2) =
            # s(a(a^3c-8a^2bc-a^2c^2+10ab^2c-4abc^2-b^2c^2+3bc^3)^2)
            # + 1/2p(a)s((9a2c-2ab2-26abc-8ac2+b3-7b2c+5bc2+c3)2) + 3/2p(a)s(a2b-4a2c-6abc)2
            if r3 >= 39:
                multiplier = CyclicSum(a*b*(a-b+3*c)**2)
                y = [
                    t,
                    t / 2,
                    t * 3 / 2,
                    (r3 - 39) * t
                ]
                exprs = [
                    CyclicSum(a*c**2*(a**3 - 8*a**2*b - a**2*c + 10*a*b**2 - 4*a*b*c - b**2*c + 3*b*c**2)**2),
                    CyclicProduct(a) * CyclicSum((9*a**2*c - 2*a*b**2 - 26*a*b*c - 8*a*c**2 + b**3 - 7*b**2*c + 5*b*c**2 + c**3)**2),
                    CyclicProduct(a) * CyclicSum(a**2*b - 4*a**2*c - 6*a*b*c)**2,
                    CyclicSum(a*b) * CyclicProduct(a) * multiplier
                ]
                return sum_y_exprs(y, exprs) / multiplier
            return None


        eq_coeffs = [
            r1*(r1*(28*r1 - 20*r2 - 44) + r2*(4*r2 + 8) + 52),
            r1*(r1*(r1*(-4*r1 + 32*r2 - 128) + r2*(24 - 20*r2) + 92) + r2*(4*r2**2 + 20) - 264) + r2*(4*r2 + 8) + 52,
            r1*(r1*(r1*(r1*(80 - 4*r2) + r2*(11*r2 - 124) + 308) + r2*(r2*(45 - 5*r2) - 8) - 56) \
                + r2*(r2*(r2*(r2 - 6) - 7) - 132) + 464) + r2*(4*r2**2 + 40) - 220,
            r1*(r1*(r1*(r1*(-16*r1 + r2*(36 - r2) - 176) + r2*(r2*(r2 - 36) + 192) - 352) + r2*(r2*(13*r2 - 33) - 24) + 40) \
                + r2*(r2*(6 - 2*r2**2) + 168) - 328) + r2*(r2*(r2*(r2 - 6) + 13) - 156) + 400,
            r1*(r1*(r1*(r1*(r1*(r1 - 3*r2 + 33) + r2*(4*r2 - 56) + 176) + r2*(r2*(36 - 2*r2) - 141) + 189) \
                + r2*(r2*(-9*r2 - 8) + 52) - 108) + r2*(r2*(r2*(r2 + 9) - 8) - 39) - 11) + r2*(r2*(r2*(5 - 2*r2) - 36) + 214) - 361,
            r1*(r1*(r1*(r1*(r1*(-2*r1 + 4*r2 - 20) + r2*(27 - 3*r2) - 48) + r2*(r2*(r2 - 10) + 18) + 16) \
                + r2*(r2*(r2 + 25) - 67) + 128) + r2*(r2*(16 - 7*r2) - 66) + 108) + r2*(r2*(r2*(r2 - 2) + 35) - 105) + 142
        ]
        eq = coeff.from_list(eq_coeffs, (u,)).as_poly()

        for root in eq.ground_roots():
            if isinstance(root, Rational) and root >= 2:
                v_ = root
                eq2 = coeff.from_list([
                    1,
                    r1 - v_ - 3,
                    r1*v_ - 3*r1 + v_**2 + 6,
                    -3*r1*v_ + 4*r1 - 2*v_ - 5,
                    -r1*v_**2 + 3*r1*v_ - 2*r1 - v_ + 4
                ], (u,)).as_poly()
                for root2 in eq2.ground_roots():
                    if isinstance(root2, Rational) and root2 > 0:
                        u_ = root2
                        r1_ = r1
                        r2_ = r2
                        break
                else:
                    v_ = None
                    continue

                break
        else:
            for root in nroots(eq, real = True):
                if root >= 2:
                    v_ = root
                    break

            # TODO: handle general cases

            if False and v_ is not None:
                # approximate a rational number
                v_numer = v_
                for tol in (.3, .1, 3e-2, 3e-3, 3e-4, 3e-5, 3e-7, 3e-9):
                    v_ = rationalize(v_numer - tol * 3, rounding = tol)
                    if v_ >= 2:
                        r1_ = u_*(u_**3 - u_**2 - 1)/(u_ + 1)
                        if r1_ <= r1:
                            r2_ = -(3*u_**4 - 2*u_**3 + 3*u_ + 1)/(u_*(u_ + 1))# + 2*(r1 - r1_)
                            if r2_ <= r2:
                                v_ = (u_**3 - u_**2 + u_ + 1) / u_
                                break

    if u_ is not None and v_ is not None:
        u, v = u_, v_
        factor1 = (u**4 + 3*u**3*v - 2*u**3 - u**2*v**2 - 5*u**2*v - u**2 - 2*u*v**2 + 5*u*v + 5*u - v**2 + 4*v - 6)
        factor2 = (u**3 + u**2*v - u**2 - 3*u*v - u - v + 4)
        w = (u + 1) * (2*u**2 - u*v - 3*u - v + 4) / ((u**2 - u + 1) * factor2)
        d1 = u**2*v**2*w**2 + 2*u**2*v*w - 2*u*v*w**2 - 2*u*w - 2*u + w**2
        a_ = -(u + 1) * (u*v - 1) * (2*u**2 - u*v - 3*u - v + 4) / factor1
        phi = r1_ * (1/(u + a_)**2 - 1) + d1
        rho = (u**2 - u*v - u + v**2 - v + 3)/(u + v - 1)
        z = a_ / (u*v - 1)

        multiplier = CyclicSum(a**2 + phi*b*c)

        y = [
            1,
            r1_ * factor1**2 / (((u**2 - u + 1) * factor2)**2),
            (u + v - 1) * (u**3 - u**2 - u*v + u + 1) * (phi + 1) / (u*v - 1) / (u**2 - 2*u - v + 2)
        ]
        y.append((r2_ + phi + 2*(u**3*w - u + v + w) - y[-1]) / 2)
        y.append(1 if (r1 != r1_ or r2 != r2_) else 0)

        y = [_ * t for _ in y]

        exprs = [
            CyclicSum(a*((-u*v*w+w)*a**2*c + (u**2*v*w-u*w-u)*a*b**2 \
                + (u**3*w-u**2*v*w-u**2*w+u*v*w+u*w-v*w+v)*a*b*c
                + b**3 + (-u**3*w+u-v-w)*b**2*c + (u**2*w+v*w-1)*b*c**2).together()**2),
            CyclicSum(a*(a**2*c + (u*v*z-z)*a*b**2 \
                + (u**2*z-u*z+u-v**2*z+v*z-v)*a*b*c + (-u*v*z-u+z)*a*c**2\
                + (-u**2*z-v*z-1)*b**2*c + (u*z+v**2*z+v)*b*c**2).together()**2),
            CyclicProduct(a) * CyclicSum(a**2 - rho*a*b)**2,
            CyclicProduct(a) * CyclicSum((a**2 - b**2 - u*a*c + v*b*c + (u-v)*a*b)**2),
            CyclicSum(a*c*(a-b)**2*((r1-r1_)*c + (r2-r2_)/2*b)) * multiplier
        ]

        return sum_y_exprs(y, exprs) / multiplier

    return None


def _sos_struct_quintic_windmill_special(coeff: 'Coeff'):
    """
    Give the solution to `s(ab4-a2b2c) >= wabcs(a2-ab)`
    here optimal `w = 3.581412179607289955451719993913205662648` is the root of `x**3-8*x**2+39*x-83`

    Idea: `x, y, z` are coeffs to be determined, and apply the quartic discriminant on:

    `s(ab4-a2b2c-wabc(a2-ab))s(a2+(z*z+2)ab) - s(c(a3-abc-(x)(a2b-abc)+(y)(ab2-abc)-(z)(bc2-abc)+(a2c-abc))2)`

    Optimal solution:

    ```
    x = 3.729311215312077309477934958844193027565   rootof(x**3-3*x**2+19*x-81) = (4*w**2 + 16*w + 7)/31
    y = 2.079041499458323407339677415370865580968   rootof(x**3+6*x**2+x-37) = (10*w**2 - 53*w + 126)/31
    z = 1.682327803828019327369483739711048256891   rootof(x**3-3*x**2+4*x-3) = (w**2 + 4*w + 25)/31
    ```

    Code:

    ```
    from sympy import nsolve
    p = -w*z**2 - w - x**2 - 2*y + 2*z
    q = -w*z**2 - w + 2*x*z - y**2 - 2*y*z + 2*y + 3*z**2 - 6*z + 5
    disc = (-3*w + 6*x + 3*z**2 + 6)*(w*z**2 - w + 2*x*y + 2*y*z + 2*y + 4) - (p**2 + p*q + q**2)
    disc = disc.subs(w,3.581412179607289955451719993913205662648)
    print(nsolve((disc.diff(x), disc.diff(y), disc.diff(z)), (x,y,z), (2163/580, 1736/835, 1647/979), prec = 40))
    ```

    Reference
    -------
    [1] https://tieba.baidu.com/p/7710460926
    """
    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    t = coeff((1,4,0))
    w =  -coeff((3,1,1)) / t
    if w > 3 and w**3 - 8*w**2 + 39*w - 83 > 0:
        return None
    elif w <= 2:
        # very trivial in this case
        return t * CyclicSum(a**2*c*(a-b)**2) + (2 - w) * t / 2 * CyclicSum((a-b)**2) * CyclicProduct(a)

    # compute the quartic discriminant
    def compute_disc(x, y, z):
        p = -w*z**2 - w - x**2 - 2*y + 2*z
        q = -w*z**2 - w + 2*x*z - y**2 - 2*y*z + 2*y + 3*z**2 - 6*z + 5
        disc = (-3*w + 6*x + 3*z**2 + 6)*(w*z**2 - w + 2*x*y + 2*y*z + 2*y + 4) - (p**2 + p*q + q**2)
        return p, q, disc

    # candidate selections of (x,y,z) such that disc >= 0
    candidates = [
        (Integer(3), Integer(2), Integer(1)),              # w = 3.5433               > 7/2
        (Rational(26,7), Integer(2), Rational(12,7)),       # w = 3.580565...
        (Rational(26,7), Rational(79,38), Rational(5,3)),  # w = 3.5813989766...      > 25/43
        # (Rational(2163,580), Rational(1736,835), Rational(1647,979)),  # w = 3.58141217960666...
        ((4*w**2 + 16*w + 7)/31, (10*w**2 - 53*w + 126)/31, (w**2 + 4*w + 25)/31) # exact
    ]

    for x, y, z in candidates:
        p, q, disc = compute_disc(x, y, z)
        if disc < 0:
            continue

        multiplier = CyclicSum(a**2 + (z**2 + 2)*b*c)
        m = (-w + 2*x + z**2 + 2)
        if m <= 0:
            continue
        sol = Add(
            t * CyclicSum(c*(a**3 - x*a**2*b + y*a*b**2 - z*b*c**2 + a**2*c + (x-y+z-2)*a*b*c)**2),
            t * m / 2 * CyclicProduct(a) * CyclicSum((a**2 - b**2 + (-(p+q*2)/3/m)*(a*b-a*c) + (-(2*p+q)/3/m)*(b*c-a*b))**2),
            t * disc / 6 / m * CyclicProduct(a) * CyclicSum(a**2*(b-c)**2)
        )
        return sol / multiplier

    return None


def _solve_quintic_hexagon_pqz(coeff: 'Coeff', p, q, z, mul = 1):
    """
    When `Det = 64*p^3-16*p^2*q^2+8*p*q*z^2+32*p*q*z-256*p*q+64*q^3-z^4-24*z^3-192*z^2-512*z >= 0`,
    we have `f(a,b,c) = s(a^4b + pa^3b^2 + qa^2b^3 + ab^4 + za^3bc - (p+q+z+2)a^2b^2c) >= 0`.

    Proof: Take `w = z + 8`, `u = 4(2p^2-qw)/(w^2-4pq)`, `v = 4(2q^2-pw)/(w^2-4pq)`,
    and `t = (4pq-w^2)^2/(8(2p+2q+w)(3(p-q)^2+(w-p-q)^2))`,
    then `1 - t = Det/... >= 0`, and we have

    ```
    f(a,b,c) = t*CyclicSum(c(a**2-b**2+u(ab-ac)+v(bc-ab))**2) + (1 - t)*CyclicSum(c(a-b)**4) >= 0.
    ```

    The function solves for `mul * s(a^4b + pa^3b^2 + qa^2b^3 + ab^4 + za^3bc - (p+q+z+2)a^2b^2c)`.
    """
    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    det = (64*p**3 - 16*p**2*q**2 + 8*p*q*z**2 + 32*p*q*z - 256*p*q \
           + 64*q**3 - z**4 - 24*z**3 - 192*z**2 - 512*z)
    if det >= 0:
        w = z + 8
        if p != q or w != p + q:
            # Actually the case p == q will be handled in quintic_symmetric, so we ignore it here.
            denom = (1 / (8*(2*p + 2*q + w)*(3*(p-q)**2 + (w-p-q)**2)))
            c1, c2, c3 = [w**2-4*p*q, 4*(2*p**2-q*w), 4*(2*q**2-p*w)]
            return Add(
                (denom * mul) * CyclicSum(c*(c1*(a**2-b**2) + c2*(a*b-a*c) + c3*(b*c-a*b))**2),
                (det * denom * mul) * CyclicSum(c*(a-b)**4)
            )

    if z >= -2:
        det = -16*(p**2*q**2 + 18*p*q - 4*p**3 - 4*q**3 - 27)
        if det >= 0 and (p != 3 or q != 3):
            u, v = (2*p**2 - 6*q) / (9 - p*q), (2*q**2 - 6*p) / (9 - p*q)
            t = (9 - p*q)**2 / (p + q + 3) / (3*(p - q)**2 + (6 - p - q)**2)

            y = [(z + 2) * mul / 2, t * mul, (1 - t) * mul]
            exprs = [
                CyclicProduct(a) * CyclicSum((a-b)**2),
                CyclicSum(c*(a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))**2),
                CyclicSum(c*(a-b)**4),
            ]
            return sum_y_exprs(y, exprs)


#########################################################
#
#                       Hexagon
#
#########################################################

def _sos_struct_quintic_hexagon(coeff: 'Coeff'):
    """
    Try solving quintics without s(a^5).

    Theorem 1.
    When Det = 64*p^3-16*p^2*q^2+8*p*q*z^2+32*p*q*z-256*p*q+64*q^3-z^4-24*z^3-192*z^2-512*z >= 0,
    we have f(a,b,c) = s(a^4b + pa^3b^2 + qa^2b^3 + ab^4 + za^3bc - (p+q+z+2)a^2b^2c) >= 0.

    Proof: Take w = z + 8, u = 4(2p^2-qw)/(w^2-4pq), v = 4(2q^2-pw)/(w^2-4pq),
    and t = (4pq-w^2)^2/(8(2p+2q+w)(3(p-q)^2+(w-p-q)^2)),
    then 1 - t = Det/... >= 0, and we have
    f(a,b,c) = t*sum c(a^2-b^2+u(ab-ac)+v(bc-ab))^2 + (1 - t)sum c(a-b)^4 >= 0.

    Examples
    --------
    => s(c(a-b)2(a+b-3c)2)

    => s(a4b+a4c+6a3b2+a2b3-9a3bc)-10abcs(a2-ab)

    => s(4a4b+4a4c-8a3b2-29a3bc+8a3c2+21a2b2c)

    => s(a4b+a4c+5a3b2+3a2b3-10a2b2c)-20s(a3bc-a2b2c)

    => s(4a4b+a4c+9a3b2-36a3bc+2a3c2+20a2b2c)

    => s(4a4b+a4c-3a3b2-16a3bc+2a3c2+12a2b2c)

    => s(a4b-3a3b2+6a2b3+3ab4-7a3bc) # doctest:+SKIP

    => s(a4b+7a4c-3a3b2-17a3bc-a3c2+13a2b2c)

    => 2s(a2(a-b)(a2-3bc))-s((a+b-c)(a-b)2(a+b-3/2c)2)

    => s((23(b-a)+31c)(a2-b2+(ab-ac)+2(bc-ab))2) # doctest:+SKIP

    Reference
    -------
    [1] https://artofproblemsolving.com/community/u426077h2246130p17263853
    """
    if coeff((5,0,0)) != 0 or coeff((4,1,0)) < 0 or coeff((1,4,0)) < 0:
        return None
    if coeff((4,1,0)) == 0 or coeff((1,4,0)) == 0:
        return _sos_struct_quintic_windmill(coeff)

    rem = sum(coeff(_) for _ in [(4,1,0),(3,2,0),(2,3,0),(1,4,0),(3,1,1),(2,2,1)])
    if rem < 0:
        return None

    a, b, c = coeff.gens
    CyclicSum, CyclicProduct = coeff.cyclic_sum, coeff.cyclic_product

    if coeff((4,1,0)) == coeff((1,4,0)):
        # Theorem 1.
        # In this case, there must exist u, v such that
        # f / coeff((4,1,0)) >= s(c(a^2-b^2+u(ab-ac)+v(bc-ab))^2)
        coeff410 = coeff((4,1,0))

        p, q, z = coeff((3,2,0)) / coeff410, coeff((2,3,0)) / coeff410, coeff((3,1,1)) / coeff410
        solution = _solve_quintic_hexagon_pqz(coeff, p, q, z, mul = coeff410)
        if solution is not None:
            return solution + rem * CyclicSum(a**2*b**2*c)

        if not coeff.is_rational:
            return None

        # backup plan:
        # u^2-2v <= p   --->  v <= (u^2-p)/2
        # v^2-2u <= q   --->  (u^2-p)^2/4 - 2u <= q

        eq = coeff.from_list([1, 0, -2*p, -8, p**2 - 4*q], (a,)).as_poly()
        u, v = None, None

        for root in eq.ground_roots():
            if isinstance(root, Rational):
                u = root
                v = (u ** 2 - p) / 2
                if -2 * u * v <= z:
                    break
                u, v = None, None
        if (u is None or v is None) and (not coeff.is_rational):
            return None

        if u is None:
            try:
                for root in nroots(eq, real=True):
                    if -root * (root**2 - p) <= z:
                        direction = 1 if eq.diff().eval(root) <= 0 else -1
                        for u in rationalize_bound(root, direction, compulsory = True):
                            if eq(u) <= 0:
                                v = (u ** 2 - p) / 2
                                if -2 * u * v <= z:
                                    break
                        else:
                            u, v = None, None
            except Exception:
                pass

        if u is not None:
            y = [
                1,
                q - (v **2 - 2 * u),
                (z + 2 * u * v) / 2,
                rem / coeff410
            ]
            if all(_ >= 0 for _ in y):
                y = [_ * coeff410 for _ in y]
                exprs = [
                    CyclicSum(c*(a**2 - b**2 + u*(a*b-a*c) + v*(b*c-a*b))**2),
                    CyclicSum(a**2*b*(b-c)**2),
                    CyclicProduct(a) * CyclicSum((b-c)**2),
                    CyclicProduct(a) * CyclicSum(a*b)
                ]
                return sum_y_exprs(y, exprs)

        # The case must have been solved above.
        # If not, the problem is false.
        return None


    if coeff.is_rational:
        # solve trivial case:
        # Try to represent f(a,b,c) in the form
        # xs(c(a^2-b^2+u(ab-ac)+v(bc-ab))^2) + zs(c(a-b)^4) - ys(c(a^2-b^2+u(ab-ac)+v(bc-ab))(a-b)^2)
        # Then, when y^2 <= 4xz, the result is positive semidefinite.
        y = (coeff((4,1,0)) - coeff((1,4,0))) / 2
        s = (coeff((4,1,0)) + coeff((1,4,0))) / 2 # s = x + z
        x = s / 2 + sqrt(coeff((4,1,0)) * coeff((1,4,0))) / 2
        g, h = coeff((3,2,0)), coeff((2,3,0))
        if isinstance(x, Expr) and not isinstance(x, Rational):
            x = x.n(15)

        # u^2x - 2vx - vy = g => v = (u^2x - g) / (2x + y)
        # v^2x - 2ux + uy = h


        def _compute_uvcoef(u, x, y, s, g):
            # coef is the coefficient of a^3bc
            u = coeff.convert(u)
            v = (u**2*x - g) / (2*x + y)
            coef = -2*u*v*x - 2*u*y + 2*v*y - 8*(s - x)
            return u, v, coef

        def _solve_uvcoef(x, y, g, h, s):
            x = coeff.convert(x)
            eq = coeff.from_list([
                x**3, 0, -2*g*x**2, (-8*x**3 - 4*x**2*y + 2*x*y**2 + y**3), g**2*x - 4*h*x**2 - 4*h*x*y - h*y**2
            ], (a,)).as_poly()

            roots = nroots(eq, method='factor', real = True, nonnegative = True)
            for root in roots:
                _, v, coef = _compute_uvcoef(root, x, y, s, g)
                if coef <= coeff((3,1,1)):
                    return root, v, coef


        params = _solve_uvcoef(x, y, g, h, s)
        if params is not None and not isinstance(x, Rational):
            # perturb x to be slightly smaller
            for x_ in rationalize_bound(x, direction = -1, compulsory = True):
                if x_ < s / 2:
                    continue
                params = _solve_uvcoef(x_, y, g, h, s)
                if params is not None:
                    x = x_
                    break
                params = None

        if params is not None:
            # now that x is rational
            u, v, coef = params

            if isinstance(u, Float) and (not coeff.domain.is_RR):
                direction = -1 if (4*u*x**2*(-g + u**2*x)/(2*x + y)**2 - 2*x + y) > 0 else 1
                for u_ in rationalize_bound(u, direction = direction, compulsory = True):
                    u_, v, coef = _compute_uvcoef(u_, x, y, s, g)
                    if v**2*x - 2*u*x + u*y <= h and coef <= coeff((3,1,1)):
                        u = u_
                        break
                else:
                    u = None

            # print(x, params, u, v, (u**2*x - 2*v*x - v*y), (v**2*x - 2*u*x + u*y))
            if u is not None:
                u, x = coeff.convert(u), coeff.convert(x)
                z = s - x
                _y = [
                    x,
                    z - y**2 / 4 / x,
                    g - (u**2*x - 2*v*x - v*y),
                    h - (v**2*x - 2*u*x + u*y),
                    (coeff((3,1,1)) - (-2*u*v*x - 2*u*y + 2*v*y - 8*(s - x))) / 2,
                    rem
                ]
                if all(_ >= 0 for _ in _y):
                    exprs = [
                        CyclicSum(c*((1-y/(2*x))*a**2-(1+y/(2*x))*b**2+(y/x+u-v)*a*b + v*b*c -u*a*c)**2),
                        CyclicSum(c*(a-b)**4),
                        CyclicSum(b*c**2*(a-b)**2),
                        CyclicSum(a*c**2*(a-b)**2),
                        CyclicProduct(a) * CyclicSum((a-b)**2),
                        CyclicProduct(a) * CyclicSum(a*b)
                    ]
                    return sum_y_exprs(_y, exprs)


    return None
