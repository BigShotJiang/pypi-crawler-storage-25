from typing import Union, Dict, Optional, TYPE_CHECKING

from sympy import Function, Mul
from sympy.core.symbol import uniquely_named_symbol
from sympy.combinatorics import PermutationGroup, Permutation

from .cubic import quaternary_cubic_symmetric, _quaternary_cubic_partial_symmetric
from .quartic import quaternary_quartic
from .quartic_symmetric import quaternary_quartic_symmetric
from .quintic import quaternary_quintic_symmetric
from .dense_symmetric import quaternary_dense_symmetric, quaternary_dense_dihedral

from ..utils import Coeff, PolynomialNonpositiveError, PolynomialUnsolvableError
from ..sparse import sos_struct_common, sos_struct_degree_specified_solver
from ..solution import SolutionStructural

if TYPE_CHECKING:
    from sympy import Poly, Expr


SOLVERS_CYCLIC = {
    4: quaternary_quartic,
}

SOLVERS_SYMMETRIC = {
    3: quaternary_cubic_symmetric,
    4: quaternary_quartic_symmetric,
    5: quaternary_quintic_symmetric,
}

SOLVERS_SYMMETRIC_NONHOM = {
    3: _quaternary_cubic_partial_symmetric,
}

def _structural_sos_4vars_symmetric(
    coeff: Union["Poly", Coeff, Dict],
    real: int = 1
) -> Optional["Expr"]:
    """
    Internal function to solve a 4-var homogeneous symmetric polynomial using structural SOS.
    It does not check the homogeneous / cyclic property of the polynomial to save time.
    """
    if not isinstance(coeff, Coeff):
        coeff = Coeff(coeff)

    return sos_struct_common(coeff,
        sos_struct_degree_specified_solver(SOLVERS_SYMMETRIC, homogeneous=True),
        quaternary_dense_symmetric,
        real=real
    )

def _structural_sos_4vars_cyclic(
    coeff: Union["Poly", Coeff, Dict],
    real: int = 1
) -> Optional["Expr"]:
    """
    Internal function to solve a 4-var homogeneous cyclic polynomial using structural SOS.
    It does not check the homogeneous / cyclic property of the polynomial to save time.
    """
    if not isinstance(coeff, Coeff):
        coeff = Coeff(coeff)

    return sos_struct_common(coeff,
        sos_struct_degree_specified_solver(SOLVERS_CYCLIC, homogeneous=True),
        real=real
    )

def _structural_sos_4vars_partial_symmetric(
    coeff: Union["Poly", Coeff, Dict],
    real: int = 1
) -> Optional["Expr"]:
    """
    Internal function to solve a 4-var homogeneous partial symmetric polynomial using structural SOS.
    The function assumes the polynomial has group symmetry `PermutationGroup(Permutation([1,2,0,3]))`
    It is also symmetric with respect to a, b, c if we set d = 1.
    It does not check the homogeneous / cyclic property of the polynomial to save time.
    """
    if not isinstance(coeff, Coeff):
        coeff = Coeff(coeff)
    return sos_struct_common(coeff,
        sos_struct_degree_specified_solver(SOLVERS_SYMMETRIC_NONHOM, homogeneous=True),
        real=real
    )

def _structural_sos_4vars_dihedral(
    coeff: Union["Poly", Coeff, Dict],
    real: int = 1
) -> Optional["Expr"]:
    """
    Internal function to solve a 4-var homogeneous dihedral polynomial using structural SOS.
    It does not check the homogeneous / dihedral property of the polynomial to save time.

    The permutation group is assumed to be [[2,3,0,1], [1,0,2,3]].
    """
    if not isinstance(coeff, Coeff):
        coeff = Coeff(coeff)
    if coeff.total_degree() <= 2:
        from ..nvars.quadratic import sos_struct_nvars_quadratic
        sol = sos_struct_nvars_quadratic(coeff)
        if sol is not None:
            return sol

    poly = coeff.as_poly()
    const, factors = poly.factor_list()

    if const < 0:
        return None

    factor_sols = [const]
    dih = PermutationGroup(Permutation([2,3,0,1]), Permutation([1,0,2,3]))
    for factor, mul in factors:
        if mul % 2 == 1:
            factor_coeff = Coeff(factor)
            if not factor_coeff.is_cyclic(dih):
                # factors of a D4-symmetric polynomial might not
                # still be cyclic under D4
                # e.g. a*b*c*d
                wrap = factor_coeff.wrap
                if all(wrap(z) >= 0 for z in factor_coeff.coeffs()):
                    factor_sols.append(factor.as_expr() ** mul)
                    continue
                return None
            sol = quaternary_dense_dihedral(factor_coeff)
            if sol is None:
                return None
            factor_sols.append(sol ** mul)
        else:
            factor_sols.append(factor.as_expr() ** mul)

    return Mul(*factor_sols)


def structural_sos_4vars(
    poly: "Poly",
    ineq_constraints: Dict["Poly", "Expr"] = {},
    eq_constraints: Dict["Poly", "Expr"] = {}
) -> Optional["Expr"]:
    """
    Main function of structural SOS for 4-var homogeneous polynomials.
    """
    if len(poly.gens) != 4: # should not happen
        raise ValueError("structural_sos_4vars only supports 4-var polynomials.")
    if not poly.is_homogeneous: # should not happen
        raise ValueError("structural_sos_4vars only supports homogeneous polynomials.")

    coeff = Coeff(poly)
    solution = None
    func = None
    if coeff.is_symmetric():
        func = _structural_sos_4vars_symmetric
    elif coeff.is_cyclic():
        func = _structural_sos_4vars_cyclic
    else:
        pg = PermutationGroup(Permutation([1,2,0,3]), Permutation([1,0,2,3]))
        if coeff.is_cyclic(pg):
            func = _structural_sos_4vars_partial_symmetric

        # TODO: dihedral belongs to cyclic
        pg = PermutationGroup(Permutation([2,3,0,1]), Permutation([1,0,2,3]))
        if coeff.is_cyclic(pg):
            func = _structural_sos_4vars_dihedral

    try:
        if func is not None:
            solution = func(coeff, real = 1)
    except (PolynomialNonpositiveError, PolynomialUnsolvableError):
        return None

    if solution is None:
        return None

    ####################################################################
    # replace assumed-nonnegative symbols with inequality constraints
    ####################################################################
    func_name = uniquely_named_symbol('G', poly.gens + tuple(ineq_constraints.values()))
    func = Function(func_name)
    solution = SolutionStructural._extract_nonnegative_exprs(solution, func_name=func_name)
    if solution is None:
        return None

    replacement = {}
    for k, v in ineq_constraints.items():
        if len(k.free_symbols) == 1 and k.is_monomial and k.LC() >= 0:
            replacement[func(k.free_symbols.pop())] = v/k.LC()
    solution = solution.xreplace(replacement)

    if solution.has(func):
        # unhandled nonnegative symbols -> not a valid solution
        return None

    return solution
