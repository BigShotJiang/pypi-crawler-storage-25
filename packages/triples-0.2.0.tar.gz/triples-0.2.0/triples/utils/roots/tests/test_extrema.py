from sympy.abc import a,b,c,d,n,x,y,z
from sympy import Integer, Float, sqrt

from ..extrema import optimize_poly
from ....utils import CyclicSum

class ExtremaProblems():
    def collect(self):
        return {k: getattr(self, k) for k in dir(self) if k.startswith('problem')}

    def problem_doc1(self):
        return (-(a + 2*b), [a, b], [a**2 + b**2 - 1]), [(1/5**.5, 2/5**.5)]
    def problem_pqr(self):
        return (-x, [a,b,c], [a+b+c-5,a*b+b*c+c*a-3,a*b*c-x]),\
            [(13/3,1/3,1/3,13/27), (1/3,13/3,1/3,13/27), (1/3,1/3,13/3,13/27)]
    def problem1003(self):
        poly = Integer(4)/3-y+x
        return (poly, [], [x**2*(1-x)-(1-y)*y**2-(1-x)*(1-y)]), [(-5/9, 7/9)]
    def problem1007(self):
        poly = Integer(4)/9 - CyclicSum(x*y*(1-x),(x,y,z))
        return (poly, [x,y,z,16-9*x,16-9*y,16-9*z], []), [(0, 1/2, 16/9), (1/2, 16/9, 0), (2/3, 2/3, 2/3), (16/9, 0, 1/2)]
    def problem_2003(self):
        # https://artofproblemsolving.com/community/c6h3378194
        poly = 7*(a+b)*(b+c)*(c+d)*(d+a)-240*a*b*c*d
        return (poly, [a,b,c,d,a-b-7*c-d], [d-1, poly]), [(1,0,0,1), (5,1,3/7,1)]
    # def problem2004(self):
    #     # https://artofproblemsolving.com/community/c6t243f6h3528057
    #     poly = -2*x**2*y**2*z**2 - x**2*y**2 + 2*x**2*y*z - x**2*z**2 + y**2*z**2
    #     return (poly, [2*x-1, 2*y-1, 2*z-1], [x**2+y**2+z**2 - 1, poly]), [(2**-.5, 1/2, 1/2)]
    def problem_beale(self):
        # https://www.sfu.ca/~ssurjano/beale.html
        poly = (Integer(3)/2 - x + x*y)**2 + (Integer(225)/100 - x + x*y**2)**2 + (Integer(2625)/1000 - x + x*y**3)**2
        return (poly, [], []), [(3, 0.5)]
    def problem_camel6(self):
        # https://www.sfu.ca/~ssurjano/camel6.html
        poly = 4*x**2 - Integer(21)/10*x**4 + x**6/3 + x*y - 4*y**2 + 4*y**4
        return (poly, [], []), [(-0.0898420131, 0.712656403), (0.0898420131, -0.712656403)]
    def problem_sinusoidal(self):
        poly = 2 + sqrt(5)*x - 4*y
        return (poly, [], [x**2 + y**2 - 1]), [(-5**.5/21**.5, 4/21**.5)]

def test_extrema():
    problems = ExtremaProblems().collect()
    for func in problems.values():
        (poly, ineqs, eqs), solutions = func()
        result = optimize_poly(poly, ineqs, eqs)
        assert len(result) == len(solutions)

        result_dict = {tuple(_.n(4) for _ in v) for v in result}
        solution_dict = {tuple(Float(_).n(4) for _ in v) for v in solutions}
        assert result_dict == solution_dict

def test_extrema_max_different():
    assert optimize_poly((a-2*b+2)**4+(b-c-1)**2+(c+2*a-3*d-1)**2+(d-a+3)**4,max_different=4)\
        == [(16,9,8,13)]

def test_extrema_issues():
    # this should exit successfully and return nothing since (0,0,0) is not feasible
    assert optimize_poly(z-2*n*x+2*n-1,[z,n-1,n,x,(z-1-(2*n)*(x-1))],[n,z,x]) == []
