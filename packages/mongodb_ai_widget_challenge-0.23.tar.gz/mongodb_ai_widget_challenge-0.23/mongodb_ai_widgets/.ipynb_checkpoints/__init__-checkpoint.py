# mongodb_ai_playground/__init__.py

from .widget import MongoDBAIPlayground

__all__ = ["MongoDBAIPlayground"]
