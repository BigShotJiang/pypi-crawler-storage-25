"""Backward-compatible import path for the challenge widget."""

from mongodb_ai_widget_challenge import MongoDBChallenge

__all__ = [
    "MongoDBChallenge",
]
