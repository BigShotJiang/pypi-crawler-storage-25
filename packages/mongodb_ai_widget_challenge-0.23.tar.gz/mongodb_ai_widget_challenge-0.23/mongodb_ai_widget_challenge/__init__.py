"""Challenge widget package."""

from .rag_widget import MongoDBChallenge

__all__ = [
    "MongoDBChallenge",
]
