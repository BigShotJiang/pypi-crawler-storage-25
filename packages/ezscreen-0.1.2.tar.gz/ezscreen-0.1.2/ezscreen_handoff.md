# ezscreen — Complete Developer Handoff

> GPU-accelerated virtual screening CLI  
> Prepared for: **Antigravity**  
> This document is the single source of truth for the development team. Every design decision, architectural choice, UX specification, and implementation detail is recorded here. Nothing has been omitted.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Technical Stack](#2-technical-stack)
3. [Architecture](#3-architecture)
4. [Command Surface](#4-command-surface)
5. [Receptor & Ligand Prep](#5-receptor--ligand-prep)
6. [Pocket Detection](#6-pocket-detection)
7. [Search Depth](#7-search-depth)
8. [Prep Report Format](#8-prep-report-format)
9. [Error Taxonomy](#9-error-taxonomy)
10. [Authentication UX](#10-authentication-ux)
11. [ADMET Filtering](#11-admet-filtering)
12. [Results Viewer](#12-results-viewer)
13. [Status Screen & Version Updates](#13-status-screen--version-updates)
14. [UX Design Principles](#14-ux-design-principles)
15. [Shard & Retry Logic](#15-shard--retry-logic)
16. [Deferred to v2](#16-deferred-to-v2)
17. [Items Needing Further Discussion](#17-items-needing-further-discussion)
18. [Quick Reference — All Decisions](#18-quick-reference--all-decisions)

---

## 1. Project Overview

ezscreen is a command-line tool that makes GPU-accelerated virtual screening accessible to researchers who do not have access to high-performance computing hardware. It automates the entire molecular docking pipeline — from receptor and ligand preparation through docking, hit filtering, and pose validation — using Kaggle's free T4 GPU infrastructure as the compute backend.

**Problem it solves:** Computational chemists and pharmacologists at under-resourced institutions spend hours configuring docking tools, managing file formats, and debugging prep pipelines before any science gets done. ezscreen collapses this into an interactive CLI with sensible defaults and a guided decision tree.

**Target users:** Researchers and students in molecular biology, pharmacology, and computational chemistry who are comfortable with a terminal but are not necessarily expert computational chemists. They use Kaggle or Google Colab for GPU access.

> ⚠️ **Scope:** Everything in this document is scoped to v1. Features marked v2 are explicitly deferred and must not be implemented in the initial release.

---

## 2. Technical Stack

### 2.1 Core dependencies

| Component | Decision | Reasoning |
|---|---|---|
| CLI framework | **Typer** | Cleaner nested subcommands than Click; type-hint driven; less boilerplate |
| Terminal output | **Rich** | Progress bars, styled tables, panels, syntax highlighting |
| Interactive prompts | **Questionary** | Styled select menus, checkboxes, text inputs via prompt-toolkit |
| Config format | **TOML** | No YAML Norway-problem bugs; `tomllib` in stdlib (3.11+); `tomli-w` for writing |
| Python floor | **3.10 minimum** | Cross-check all deps before finalising; 3.11+ preferred |
| Package distribution | **pip first** | `pyproject.toml`; conda-forge recipe filed after stable release |
| Checkpointing | **SQLite** | Run state, shard status, resume by run-id |

### 2.2 Docking engines

| Stage | Engine | Notes |
|---|---|---|
| Stage 1 primary | **UniDock-Pro** | SBVS + LBVS + Hybrid; Apache 2.0; build from source on Kaggle |
| Stage 1 fallback | **UniDock** | `pip install unidock-tools`; used when no reference ligand available |
| Stage 2 validation | **DiffDock-L** | Via NVIDIA NIM API; free; called locally, not on Kaggle |
| v2 | Local backend, Colab backend, MD/MMGBSA | Deferred |

> ⚠️ UniDock-Pro must be built from source on Kaggle (CUDA ≥ 11.8 + Boost). This happens in notebook template Cell 2. UniDock is the pip fallback when a reference ligand is not provided.

### 2.3 Prep pipeline

| Step | Tool | Notes |
|---|---|---|
| Receptor prep | pdbfixer → Meeko mk_prepare_receptor | Missing residues, waters, alternates, hydrogens |
| Ligand prep | scrub.py → RDKit ETKDG → Meeko | Protonation, 3D conformers, PDBQT |
| Pocket detection | Tiered (see Section 6) | co-crystal → residues → P2Rank → blind |
| ADMET | RDKit | Ro5, PAINS, toxicophores, Veber, Egan BBB |
| Molscrub install | `git+https://github.com/forlilab/scrubber` | Not on PyPI — pinned in pyproject.toml; consider vendoring for long-term stability |

---

## 3. Architecture

### 3.1 Package structure

```
ezscreen/
├── cli.py                  # Typer entry points — all subcommands
├── state.py                # State machine — BACK sentinel, context dict
├── config.py               # TOML loader/writer — ~/.ezscreen/config.toml
├── auth.py                 # Credential management — ~/.ezscreen/credentials
├── backends/
│   └── kaggle/
│       ├── runner.py       # Orchestrates dataset push + kernel + poll + download
│       ├── dataset.py      # Kaggle datasets API wrapper
│       ├── kernel.py       # Kaggle kernels API wrapper
│       ├── poller.py       # Status polling — Rich progress, retry logic
│       └── templates/
│           └── vina_shard.ipynb.j2   # Jinja2 notebook template
├── prep/
│   ├── receptor.py         # pdbfixer + Meeko receptor prep
│   └── ligands.py          # scrub.py + RDKit + Meeko ligand prep
├── pocket/
│   └── detect.py           # Tiered pocket detection
├── admet/
│   └── filter.py           # RDKit ADMET filters
├── results/
│   ├── merger.py           # Merge shard CSVs, global re-rank
│   └── viewer.py           # Rich table + py3Dmol HTML generator
├── checkpoint.py           # SQLite run state — create, update, resume
├── report.py               # Prep report — .txt + .json writer
├── errors.py               # Error taxonomy — all error classes
└── vendor/
    └── scrubber/           # Vendored molscrub (with attribution) — if vendoring chosen
```

### 3.2 Config files

**`~/.ezscreen/config.toml`** — all user preferences, never secrets:

```toml
[run]
auto_resume_threshold = 10   # resume automatically if failures >= this %
shard_retry_limit = 3        # retries before prompting user again
default_search_depth = "Balanced"
default_ph = 7.4
admet_pre_filter = true

[kaggle]
default_dataset = "username/ezscreen-workspace"

[defaults]
box_padding = 5.0
enumerate_tautomers = false
```

**`~/.ezscreen/credentials`** — chmod 600 enforced — NEVER stored in config.toml:

```
kaggle_json_path = "~/.kaggle/kaggle.json"
nim_api_key = "nvapi-xxxxxxxxxxxx"
```

### 3.3 Kaggle dataset strategy

A single persistent dataset called `ezscreen-workspace` is maintained per user. A local manifest at `~/.ezscreen/manifest.json` tracks uploaded files by SHA-256 hash.

- On each run: check if receptor hash is already in the dataset → skip upload if yes
- Ligand shards are always new per run
- Dataset structure: `receptor_{hash8}.pdb`, `shard_{run_id}_{n}.sdf`
- Kaggle dataset versions are immutable — `ezscreen clean` deletes entire datasets
- `ezscreen clean [run-id]` removes Kaggle dataset + kernel artifacts for a run

### 3.4 Notebook template structure

Jinja2 template at `backends/kaggle/templates/vina_shard.ipynb.j2`:

| Cell | Purpose |
|---|---|
| Cell 1 | Auto-generated header comment — do not edit |
| Cell 2 | Install dependencies — UniDock-Pro build or UniDock pip, Meeko, RDKit |
| Cell 3 | Environment check — GPU available? CUDA version? Disk space? |
| Cell 4 | Load inputs from `/kaggle/input/ezscreen-{run_id}/` |
| Cell 5 | Receptor prep — pdbfixer → Meeko |
| Cell 6 | Ligand prep — scrub.py → Meeko, batch |
| Cell 7 | Docking loop — UniDock-Pro, writes checkpoint per shard |
| Cell 8 | Collect results — write `scores.csv` + `poses.sdf` to `/kaggle/working/` |
| Cell 9 | Write `done.flag` — signals clean completion to poller |

> ⚠️ Every cell has explicit error handling that writes a structured `error.json` to `/kaggle/working/` before raising. The poller distinguishes between timeout, prep failure, GPU OOM, and clean completion.

### 3.5 Jinja2 template variables

```python
{
  "run_id": "ezs-4f2a8c",
  "engine": "unidock-pro",        # or "unidock"
  "mode": "hybrid",               # sbvs | lbvs | hybrid
  "box_center": [x, y, z],
  "box_size": [sx, sy, sz],
  "exhaustiveness": 8,
  "num_modes": 3,
  "refine_step": 5,
  "max_step": 0,
  "ph": 7.4,
  "shard_index": 2,
  "total_shards": 10,
  "enumerate_tautomers": false,
  "receptor_dataset_path": "/kaggle/input/ezscreen-abc123/receptor.pdb",
  "ligand_dataset_path": "/kaggle/input/ezscreen-abc123/shard_02.sdf"
}
```

### 3.6 State machine (back button implementation)

Every screen function returns either its result or a `BACK` sentinel. The caller catches `BACK` and re-renders the previous screen. The context dict is passed forward through every prompt function.

```python
BACK = object()  # sentinel

def screen_binding_site(ctx):
    choice = questionary.select(..., choices=[..., "← Back"]).ask()
    if choice == "← Back":
        return BACK
    ctx["binding_site"] = choice
    return ctx
```

---

## 4. Command Surface

### 4.1 Subcommands

| Command | Purpose |
|---|---|
| `ezscreen run` | Main screening workflow — full interactive decision tree |
| `ezscreen auth` | Credential wizard — Kaggle + NIM setup and validation |
| `ezscreen validate` | Stage 2: DiffDock-L via NVIDIA NIM on a hit list |
| `ezscreen admet` | Standalone ADMET filter — works on any CSV or SDF |
| `ezscreen view` | Open results viewer — Rich table + py3Dmol HTML |
| `ezscreen status` | All recent Kaggle jobs — auto-refresh 30s — attach/view/resume/delete |
| `ezscreen resume [run-id]` | Resume interrupted run — resubmits only incomplete shards |
| `ezscreen clean [run-id]` | Delete Kaggle dataset + kernel artifacts for a run |

### 4.2 Auth behaviour

- Any command without credentials → short error + offer inline auth
- `ezscreen run` specifically → if no credentials, offer auth wizard then continue run flow without restart
- All other commands → `✗ Authentication required. Run ezscreen auth.`
- NIM key is optional — only required for `ezscreen validate`

### 4.3 `ezscreen run` flow (decision tree order)

```
1. Receptor input (PDB code or file path)
2. Chain selection (if multi-chain)
3. AlphaFold warning (if AF structure detected)
4. Binding site method (co-crystal / residues / P2Rank / blind)
5. Ligand library (file/folder / ZINC / ChEMBL)
6. ADMET pre-filter (yes / no)
7. Search depth (Fast / Balanced / Thorough / Exhaustive / Expert)
8. Prep report summary + option to view full report
9. Job confirmation (submit / view report / change something / back)
10. Progress (live shard progress + retry display)
11. Post-completion (ADMET / validate / view results / main menu)
```

---

## 5. Receptor & Ligand Prep

### 5.1 Receptor prep — failure modes and handling

| Issue | Handling |
|---|---|
| Missing residues/loops | pdbfixer models automatically — warn user — note in prep report |
| Missing heavy atoms | pdbfixer fills — silent |
| No hydrogens (typical) | Added at pH 7.4 — warn that histidine states are guesses |
| Alternate conformations | Always pick A — warn user |
| Waters | Remove all by default — `--keep-waters` flag to preserve |
| Multiple chains | See Section 5.3 — chain selection decision tree |
| Residue renumbering by pdbfixer | Noted in prep report; original numbers cross-referenced |
| AlphaFold structures | See Section 5.4 |

### 5.2 Ligand prep — failure modes and handling

| Issue | Handling |
|---|---|
| Salt stripping / largest fragment | Auto-silent |
| SMILES sanitization failure | Log to `failed.sdf` — never crash — continue with rest |
| 3D conformer failure (RDKit ETKDG) | Log to `failed.sdf` — count in prep report |
| Protonation at pH 7.4 | scrub.py — automated — warn about titratable groups |
| Tautomer enumeration | Off by default — `--enumerate-tautomers` flag — noted in prep report |
| Unsupported atom types | Log to `failed.sdf` — count in prep report |
| Mixed folder (SDF + SMILES) | Both handled — merged into single prepared library |
| Folder input | Recursive scan for `.sdf` and `.smi` — dedup by compound ID — per-file counts shown |

> ⚠️ Prep failures are never fatal for ligands. The run continues with whatever passed. A prep failure on the receptor IS fatal.

### 5.3 Multi-chain logic

When a structure has more than one chain, prompt:

```
❯ Auto — use chain A
  Choose a specific chain  (A · B · C...)
  Ask me for every multi-chain structure
  ← Back
```

### 5.4 AlphaFold detection

AF structures are detected by header format (REMARK 280 or MODEL_TYPE field in AF2/AF3 outputs — confirm exact heuristic before implementing).

When detected:
- Show amber warning: pocket prediction less reliable, P2Rank AF profile will be used
- User chooses: continue this structure / continue all AF this session / abort
- P2Rank uses `--profile alphafold` (no B-factor dependence)
- Warning recorded in prep report with `severity: medium`

---

## 6. Pocket Detection

The binding site definition is the single most important decision in the pipeline. Never silently default — always show the user what was chosen.

### 6.1 Detection methods

| Method | When | Reliability | Automation |
|---|---|---|---|
| Co-crystal ligand | PDB has HETATM ligand (non-solvent) | Highest | Fully automatic — extract centroid, +5Å padding |
| Active site residues | User knows their target | High | User provides residue numbers; CLI computes centroid |
| P2Rank | Any protein structure | ~77% top-1 on crystal structures | Show top 3 pockets with scores — user selects |
| Blind docking | Last resort | Low — noisy, slow | Whole-protein box — explicit warning shown |

> ⚠️ P2Rank top-1 is wrong ~23% of the time on known crystal structures. On AlphaFold models it is worse. Always show the top 3 predictions with confidence scores — never silently take top-1.

### 6.2 Box size rules

| Method | Box definition |
|---|---|
| Co-crystal ligand | Envelope ligand atoms + 5Å padding per side |
| Residue-defined | Convex hull of residue Cα atoms + 8Å padding |
| P2Rank | Predicted pocket volume + 6Å padding |
| Blind | Whole-protein bounding box + 4Å padding |

Warn if box volume > 30,000 Å³ (likely too large) or < 1,500 Å³ (likely too small).

### 6.3 Co-crystal ligand filtering

Strip known crystallographic additives from HETATM records before using as binding site reference: PEG, DMSO, glycerol, MPD, EDO, GOL, SO4, PO4, and common buffers. Only use genuine drug-like ligands.

---

## 7. Search Depth

### 7.1 Presets

Option description format: `Name · purpose · implication (exhaustiveness N · poses N)`

```
Fast       · triage only · misses ~25% best poses      (exhaustiveness 4  · poses 1)
Balanced ★ · standard VS · good for rigid pockets      (exhaustiveness 8  · poses 3)
Thorough   · flexible ligands · induced-fit targets    (exhaustiveness 16 · poses 5)
Exhaustive · allosteric/cryptic pockets · pub quality  (exhaustiveness 32 · poses 9)
Expert     · set all parameters manually
← Back
```

ETA and GPU cost shown inline per option, calculated from actual compound count. GPU hours remaining shown at bottom.

### 7.2 Expert mode parameters

Expert mode description format: `name · what it does · practical implication (range)`

```
exhaustiveness  · breadth of conformational search · diminishing returns above 64   (range 4–512)
num_modes       · poses per ligand · VS needs 1–3, validation needs 9+             (range 1–20)
refine_step     · local pose polish after search · better geometry, small cost      (range 0–20)
max_step        · caps MC steps per run · leave auto unless ligands very flexible    (0 = auto)
```

Input fields pre-filled with Balanced defaults. ETA updates on field exit (not on every keystroke).

### 7.3 Confirmation screen

Always shows full raw parameter set regardless of preset or expert mode:

```
Search depth   Balanced  exh 8 · modes 3 · refine 5 · max_step auto
```

This is required for researchers citing their methods.

### 7.4 LBVS note

For LBVS mode (reference ligand provided), the Fast preset quietly sets `--no_refine` because refinement does not improve LBVS ranking but costs time. This is an implementation detail — do not expose to the user.

---

## 8. Prep Report Format

### 8.1 When generated

Written after prep completes, before Kaggle submission. Summary shown on confirmation screen. Full report available on request. Always saved as both `.txt` and `.json` to `results/ezs-{run_id}/`.

### 8.2 Fields

**Receptor section:** source (RCSB/local), PDB ID, chain used + selection method, residue count, missing residues, alternates resolved, waters removed, tool versions (pdbfixer, Meeko)

**Binding site section:** method, reference ligand ID if co-crystal, P2Rank top-3 scores if P2Rank, final box center (x y z Å), box dimensions, box volume (Å³), warning if unusually large/small

**Ligands section:** input source + file count, total input, ADMET removed (breakdown by rule), prep passed count, prep failed count (breakdown by failure type), path to `failed_prep.sdf`, tautomers enumerated T/F, protonation pH, tool versions

**Warnings section:** flat list — each entry has `severity` (low/medium/high), `category`, `affected_count`, `message`, `action`

### 8.3 JSON schema

```json
{
  "run_id": "ezs-4f2a8c",
  "timestamp": "2025-04-06T14:32:00Z",
  "ezscreen_version": "0.1.0",
  "receptor": {
    "source": "rcsb",
    "pdb_id": "7L11",
    "chain": "A",
    "chain_selection": "auto",
    "residues": 312,
    "missing_residues": 0,
    "alternates_resolved": 0,
    "waters_removed": 147,
    "tools": { "pdbfixer": "1.9", "meeko": "0.5" }
  },
  "binding_site": {
    "method": "co_crystal",
    "reference_ligand": "LY2",
    "reference_chain": "A",
    "box_center": [14.2, 53.1, 17.8],
    "box_size": [20.0, 20.0, 20.0],
    "box_volume_angstrom3": 8000
  },
  "ligands": {
    "input_source": "~/libraries/zinc_druglike/",
    "input_files": 3,
    "total_input": 48312,
    "admet_removed": 6847,
    "admet_breakdown": { "ro5_violations": 4201, "pains_alerts": 2646 },
    "prep_passed": 41312,
    "prep_failed": 153,
    "prep_failures": {
      "conformer_generation": 91,
      "sanitization": 44,
      "unsupported_atoms": 18
    },
    "failed_prep_file": "results/ezs-4f2a8c/failed_prep.sdf",
    "tautomers_enumerated": false,
    "protonation_ph": 7.4,
    "tools": { "scrubber": "1.0", "rdkit": "2024.3", "meeko": "0.5" }
  },
  "warnings": [
    {
      "severity": "medium",
      "category": "tautomers_not_enumerated",
      "affected_count": 312,
      "message": "312 ligands have titratable groups — scores may vary by protonation state",
      "action": "rerun with --enumerate-tautomers for rigorous results"
    }
  ]
}
```

---

## 9. Error Taxonomy

### 9.1 Categories

| Category | Symbol | Handling |
|---|---|---|
| User input error | `✗` red | Block before submission. Clear message: what + why + exact fix. No quota spent. |
| Prep failure (partial) | `⚠` amber | Never abort. Skip affected compounds. Log to `failed.sdf`. Continue. |
| Prep failure (receptor) | `✗` red | Fatal — cannot continue. Clear message + action. |
| Kaggle transient | `⟳` blue | Auto-retry. Show `Retry N/3`. After retry limit: prompt user. |
| Kaggle permanent | `✗` red | No retry. Clear message + Kaggle settings URL. |
| Scientific warning | `⚠` amber | Never block. Always shown. Logged in prep report. |
| Fatal internal error | `✗` red | Clean one-line message + log path + GitHub issues URL + offer to open pre-filled browser issue. |

### 9.2 Error message format

```
✗  [what failed]
   [one sentence why]
   [exactly what to do — with URL or command if applicable]
```

Example:
```
✗  Kaggle authentication failed
   Your API key has been revoked or expired.
   Go to kaggle.com/settings/account → API → Create New Token
   then run: ezscreen auth --update kaggle
```

### 9.3 Kaggle-specific error codes

| Error | Type | Message shown |
|---|---|---|
| 401 Unauthorized | Permanent | "API key rejected — go to kaggle.com/settings → API → Create New Token" |
| 403 Forbidden | Permanent | "Account needs phone verification — complete at kaggle.com/settings" |
| Kernel preempted | Transient | "Retry N/3 — kernel preempted · resubmitting..." |
| Network timeout | Transient | Retry once after 3s → "Could not reach Kaggle API. Check connection." |
| GPU quota exhausted | Permanent | "Weekly GPU quota exhausted. Resets every Monday." |
| Storage limit | Permanent | "Kaggle dataset storage full. Run ezscreen clean to free space." |
| Rate limit (kernel push) | Transient | Exponential backoff — user sees progress, not error |

### 9.4 Log files

Every run writes to `~/.ezscreen/logs/ezs-{run_id}.log`:
- Full tracebacks
- All API responses
- Every prep decision with timestamp
- Exact UniDock-Pro command generated
- Shard status transitions

Users never see this unless something goes wrong, at which point:
```
✗  Unexpected error in results merger
   Full details: ~/.ezscreen/logs/ezs-4f2a8c.log
   Report this at: github.com/yourname/ezscreen/issues
```

---

## 10. Authentication UX

### 10.1 Auth wizard flow (`ezscreen auth`)

**Step 1 — Kaggle:**
1. Detect `KAGGLE_USERNAME` / `KAGGLE_KEY` env vars — warn if present: "Found KAGGLE_KEY env var — this overrides your kaggle.json"
2. Prompt for kaggle.json path (default: `~/.kaggle/kaggle.json`)
3. Validate in sequence: file exists → JSON parseable → `username` + `key` fields present → permissions 600 (offer auto-fix if wrong) → live API call
4. On success: show username + GPU hours remaining

**Step 2 — NIM (optional):**
1. Label: "optional — only needed for hit validation (`ezscreen validate`)"
2. Prompt for NIM key — user can skip with enter
3. Validate with test ping to DiffDock-L endpoint
4. On skip: note that `ezscreen validate` will prompt for it when needed

**Step 3 — Summary:**
1. Show: `Kaggle ✓ researcher42 · 28.4 GPU-hrs` / `NIM ✓ active` or `NIM — skipped`
2. Write credentials to `~/.ezscreen/credentials` (chmod 600 enforced)

**Re-running `ezscreen auth`:** shows current state first → asks which to update → never blindly overwrites working credentials.

### 10.2 All auth failure modes

| Failure | Type | Handling |
|---|---|---|
| `kaggle.json` not found | Fatal | Detect before API call — offer wizard inline |
| Wrong permissions (not 600) | Fatal | Detect proactively — offer `chmod 600` auto-fix |
| Malformed JSON | Fatal | Parse ourselves — show exact field missing |
| Missing username/key fields | Fatal | Validate before API call |
| 401 Unauthorized | Fatal | Revoked/expired — show renewal URL |
| 403 Forbidden | Fatal | Phone verification required — show URL |
| Env var override (`KAGGLE_KEY`) | Sneaky | Always detect and surface explicitly |
| Network timeout | Transient | Retry once after 3s → "check connection" |
| GPU quota exhausted | Runtime | Check at auth time — show in main menu quota bar |
| NIM key not set | Soft | Only surface when `ezscreen validate` is run |
| NIM 401 | Fatal for validate | "Get a free key at build.nvidia.com" |
| NIM rate limit | Transient | Batch + exponential backoff — progress, not error |
| Key stored insecurely | Silent risk | Warn if config.toml contains any API key pattern |

### 10.3 Credentials file

```
~/.ezscreen/credentials   # chmod 600 — NEVER in config.toml
```

Never in dotfiles. Never in git. Warn explicitly if a config file appears to contain a key-like string.

---

## 11. ADMET Filtering

### 11.1 Flow

- **Pre-filter:** offered during `ezscreen run` before docking — reduces library size, saves GPU quota
- **Post-filter:** offered after docking — user selects how many top hits to filter
- **Standalone:** `ezscreen admet` — works on any CSV or SDF, not just ezscreen output
- **Main menu:** "Run ADMET filtering" as a top-level option

### 11.2 Post-filter prompt

```
How many top hits to filter?
❯ Top 500
  Top 1,000
  Top 2,000
  Custom › ___
  ← Back
```

### 11.3 Available filters (v1)

| Filter | Default | Description |
|---|---|---|
| Lipinski Rule of Five | ON | MW≤500, logP≤5, HBD≤5, HBA≤10 — oral drug-likeness |
| PAINS alerts | ON | Pan-assay interference — removes promiscuous binders |
| Basic toxicophores | ON | Known reactive/toxic substructures |
| Veber | OFF | Oral bioavailability — rotatable bonds + PSA |
| Egan BBB | OFF | Blood-brain barrier permeability |

> ⚠️ v1 ADMET is purely rule-based (RDKit). It does not predict ADMET properties. This must be communicated clearly in the UI. Deep ADMET (ADMET-AI, pkCSM) is v2.

---

## 12. Results Viewer

### 12.1 Terminal table (Rich)

Columns: rank, compound ID, docking score (kcal/mol), MW, logP, ADMET status (`✓` / `✗ rule_name`). Shows top N. Every completion screen routes here before exit.

### 12.2 3D pose viewer (py3Dmol)

Self-contained HTML file — SDF embedded as JavaScript string. No server. Fully offline. Shareable. Opens in default browser. Features: 3D rotation/zoom, compound table alongside, click row to jump to pose.

Trigger: "View 3D poses in browser" option in results screen. Also: "View specific compound" for single pose by rank or ID.

### 12.3 When viewer is offered

After every action that produces results: docking complete, ADMET complete, DiffDock validation complete, opening a previous run. The tool never exits to a bare terminal prompt without offering the viewer.

---

## 13. Status Screen & Version Updates

### 13.1 Status screen (`ezscreen status`)

- All recent runs sorted by recency
- Auto-refreshes every 30 seconds silently in background
- `r` key forces immediate refresh
- States: `⟳` running (with shard progress + ETA) · `✓` complete · `✗` failed · queued
- Kaggle quota bar at bottom: GPU hours remaining + storage remaining
- Actions per job: attach to running / view results / view error + resume / delete (`d` key)

### 13.2 Version check

- Async PyPI check on every `ezscreen run` command — never blocks
- 24-hour TTL cache in `~/.ezscreen/version_cache.json`
- Banner shown in main menu header if update available: `ezscreen 0.2.0 available — update in settings`
- Settings screen shows: current version, latest version, `pip install --upgrade ezscreen` command
- User presses enter on command to copy to clipboard — never auto-updates

---

## 14. UX Design Principles

### 14.1 Terminal aesthetic

Minimal, techy, sciency. Dark terminal style. No emoji.

| Color | Hex | Used for |
|---|---|---|
| Cyan | `#79c0ff` | Prompts, input fields, highlights |
| Amber | `#e3b341` | Warnings, ETA, quota usage |
| Green | `#3fb950` | Success states |
| Red | `#f85149` | Errors, failures |
| Gray | `#8b949e` | Secondary text, unselected options |
| White bold | `#f0f6fc` | Primary text, headings |
| Muted | `#6e7681` | Descriptions, supplementary info |
| Dim | `#484f58` | Dividers, structural chrome |

### 14.2 Navigation

- Every screen has `← Back` as the last item in the selection list
- Breadcrumb trail always shown at top: `main › run › receptor › binding site`
- Back implemented as BACK sentinel in state machine context dict
- "Change something else" on confirm screen goes back to receptor (start of run flow)

### 14.3 Option description format

Consistent across all decision screens:

```
Name · what it does · practical implication  (technical detail)
```

Examples:
```
Balanced ★ · standard VS · good for rigid pockets      (exhaustiveness 8  · poses 3)
exhaustiveness  · breadth of conformational search · diminishing returns above 64  (range 4–512)
```

### 14.4 Confirmation screen rules

- Always shows full raw parameter set regardless of how settings were chosen
- Always shows ETA + GPU cost + remaining quota
- Always shows prep warning count with link to full report
- Run ID always shown here so user can reference it later

### 14.5 Inline setting changes

When a user changes a threshold or setting during a run (e.g. auto-resume threshold), always prompt:
```
Save as default in settings? [Y/n]
```

### 14.6 ctrl+c during a run

```
Job ezs-4f2a8c is still running on Kaggle.
Detach and continue in background? [Y/n]
```
Default Y. Kaggle kernel continues regardless. User reattaches with `ezscreen status`.

### 14.7 Post-action routing

After any action that produces results, always offer:
- View results (table + 3D poses)
- Run next logical stage (ADMET / validate)
- Back to main menu

Never exit to a bare prompt.

---

## 15. Shard & Retry Logic

### 15.1 What sharding is

When a library is too large for one Kaggle kernel, ezscreen splits it into batches (shards) of ~2,000 compounds each and submits them as parallel kernels. Each shard is independent. If one fails, the others are unaffected.

### 15.2 Retry behaviour

Each failed shard is retried up to `shard_retry_limit` times (default: 3, configurable in settings). Each retry shows:
```
⟳  shard 07  Retry 2/3 — kernel preempted · resubmitting...
```

### 15.3 Post-failure prompt logic

After all retries are exhausted for one or more shards:

1. Calculate: `failure_pct = failed_compounds / total_compounds * 100`
2. If `failure_pct < auto_resume_threshold` (default 10%):
```
⚠  20/21 shards complete · shard 07 failed (Retry 3/3 — preempted)
   441 compounds not docked  (3.5% of library — below 10% threshold)

❯ Continue with partial results  (40,871 compounds · 96.5% complete)
  Resume — resubmit shard 07 only  (~4 min · ~0.05 GPU-hrs)
  Change auto-resume threshold  (currently 10%)
  ← Back
```
3. If `failure_pct >= auto_resume_threshold`: auto-resume without prompt, show status update

### 15.4 If resume also fails

After `shard_retry_limit` retries on the resumed shard:
```
✗  Shard 07 failed after resume  (Retry 3/3)
   441 compounds cannot be docked at this time.

❯ Continue with partial results  (40,871 compounds · 96.5% complete)
  Try later  (saves checkpoint · run ezscreen resume ezs-4f2a8c)
  ← Back
```

The decision is returned to the user permanently at this point — no more auto-resume loops.

### 15.5 Configurable settings

Both adjustable in `settings` and inline during a run (with "Save as default?" prompt):

```toml
[run]
auto_resume_threshold = 10   # % — resume auto if failures >= this
shard_retry_limit = 3        # retries before prompting user
```

---

## 16. Deferred to v2

Do not implement these in v1:

| Feature | Notes |
|---|---|
| Local backend | Run UniDock-Pro/UniDock locally without Kaggle |
| Colab backend | Google Drive polling approach |
| Refinement stage | `ezscreen refine` — MD / MMGBSA post-docking |
| Web dashboard | Gradio or Streamlit UI on top of CLI |
| Multi-target screening | One library vs N receptors in parallel |
| Deep ADMET | ADMET-AI or pkCSM for property prediction |
| Collaboration | Shared results, team hit lists |
| Consensus docking | UniDock-Pro + Gnina dual-score pipeline |

---

## 17. Items Needing Further Discussion

These were flagged during design but not fully resolved. Address before implementing the relevant module:

- **Error taxonomy edge cases** — exact recoverable vs fatal boundary for every Kaggle API error code needs full enumeration against the Kaggle API docs
- **AlphaFold header detection** — header format varies between AF2 and AF3 outputs; confirm exact detection heuristic before implementing `pocket/detect.py`
- **Multi-chain interface edge case** — what if the true binding site spans two chains (e.g. protein-protein interface)? Current design assumes single-chain binding sites
- **Molscrub vendoring** — current plan is `git+` install; vendoring into `ezscreen/vendor/scrubber/` is safer for long-term stability; decision pending
- **Python 3.10 vs 3.11 floor** — needs a concrete compatibility matrix against all pinned dependencies (UniDock-Tools, Meeko, pdbfixer, RDKit, scrubber, Typer, Rich, Questionary, Kaggle API package) before finalising

---

## 18. Quick Reference — All Decisions

| Decision | Choice |
|---|---|
| Tool name | `ezscreen` |
| CLI framework | Typer |
| TUI / output | Rich + Questionary |
| Config format | TOML (`tomllib` stdlib + `tomli-w`) |
| Python floor | 3.10 (verify dep matrix) |
| Distribution | pip first; conda-forge later |
| Stage 1 engine | UniDock-Pro (SBVS + Hybrid) / UniDock fallback |
| Stage 2 validation | DiffDock-L via NVIDIA NIM API |
| Receptor prep | pdbfixer + Meeko |
| Ligand prep | scrub.py + RDKit ETKDG + Meeko |
| Molscrub install | `git+` install pinned in pyproject.toml |
| Pocket detection | Tiered: co-crystal → residues → P2Rank → blind |
| ADMET v1 | RDKit: Ro5, PAINS, toxicophores, Veber, Egan BBB |
| Results viewer | Rich table + py3Dmol self-contained HTML |
| Checkpointing | SQLite — resume by run-id |
| Kaggle strategy | Persistent workspace dataset + SHA-256 hash dedup manifest |
| Shard retry limit | 3 (configurable in settings) |
| Auto-resume threshold | 10% failure → auto resume (configurable) |
| Version check | Async on every `run` command — 24h cache |
| Update mechanism | Show command — user copies — never auto |
| Credentials storage | `~/.ezscreen/credentials` — chmod 600 — never in config.toml |
| ctrl+c behaviour | Confirm prompt — detach default Y — kernel continues on Kaggle |
| Search depth presets | Fast (4) / Balanced (8) / Thorough (16) / Exhaustive (32) / Expert |
| Back buttons | Every screen — BACK sentinel state machine |
| Breadcrumbs | Always shown top of every screen |
| Prep report | Post-prep pre-submission — `.txt` + `.json` — always saved |
| Error display | `✗` red fatal · `⚠` amber warning · `⟳` blue retry · `✓` green success |
| Log files | `~/.ezscreen/logs/ezs-{run_id}.log` — full tracebacks always written |
| Fatal error UX | Clean message + log path + GitHub issues URL + offer pre-filled browser issue |
| AlphaFold handling | Detect header → warn → user chooses → P2Rank AF profile |
| Multi-chain | Ask: auto chain A / choose chain / ask per structure |
| NIM key | Optional — only required for `ezscreen validate` |
| Settings contents | Kaggle API, NIM key, auto_resume_threshold, shard_retry_limit, search depth default, pH, ADMET default, update |
| Notebook template | 9 cells — Jinja2 — structured `error.json` on failure |
| LBVS fast mode | Quietly sets `--no_refine` — not exposed to user |
| Inline threshold changes | Always offer "Save as default?" prompt |
| Post-action routing | Always offer viewer / next stage / main menu — never bare prompt |

---

*End of handoff document — ezscreen · prepared for Antigravity*
