# 03 — Task Tracker

> **The living checklist. Updated after every session.**  
> `[ ]` = pending · `[/]` = in progress · `[x]` = done

---

## Phase 0 — Project Initialization ✅

- [x] Establish the 9 Operating Rules
- [x] Create the Context Vault (`.ai_context/` directory)
- [x] Ingest full handoff document (ezscreen_handoff.md)
- [x] Populate all 5 vault files from handoff
- [x] Resolve 5 open discussion items (see `04_DECISION_LOG.md`)
- [x] Finalize Python 3.11 floor decision

---

## Phase 1 — Project Scaffold

> One unit of work per commit. Write → commit → next.

### ~~"set up project layout and dependencies"~~ ✅ `b7afda3`
- [x] `pyproject.toml` — Python 3.11+, all deps pinned, hatchling build, ruff + black config
- [x] `ezscreen/__init__.py` — exposes `__version__`
- [x] All subpackage `__init__.py` files
- [x] `tests/__init__.py`

### ~~"add all the error classes we'll need"~~ ✅ `591d532`
- [x] `ezscreen/errors.py` — 18 classes across 7 categories

### ~~"wire up the back button pattern"~~ ✅ `591d532`
- [x] `ezscreen/state.py` — BACK sentinel + `make_context()` (swept into same commit)

### ~~"stubbed out all 8 cli commands for now"~~ ✅ `9075f14`
- [x] `ezscreen/cli.py` — Typer app + 8 subcommand stubs (no logic)

---

## Phase 2 — Core Foundation Modules

### ~~"add config loading and writing"~~ ✅ `c2d9891`
- [x] `ezscreen/config.py` — load/write `~/.ezscreen/config.toml`

### ~~"got the auth wizard working"~~ ✅ `83bca34`
- [x] `ezscreen/auth.py`
  - [x] Kaggle: env var detection, validate kaggle.json, live API call
  - [x] NIM: optional endpoint ping, skippable
  - [x] Summary + write credentials (chmod 600)
  - [x] Re-run mode: show existing state → ask which to update

### ~~"add run checkpointing with sqlite"~~ ✅ `0c179bf`
- [x] `ezscreen/checkpoint.py` — create run, update shard, increment retry, mark complete, resume by run-id

---

## Phase 3 — Prep Pipeline

### ~~"got receptor prep working with pdbfixer and meeko"~~ ✅ `82206e2`
- [x] `ezscreen/prep/receptor.py` — AF 4-tier, chain multi-select, RCSB fetch, pdbfixer, mk_prepare_receptor

### ~~"ligand prep pipeline with fallback scrubber"~~ ✅ `82206e2`
- [x] `ezscreen/prep/ligands.py` — scrubber fallback, SDF+SMILES recursive, ETKDG, Meeko, sharding, failed_prep.sdf

### ~~"add tiered pocket detection"~~ ✅ `5aa5158`
- [x] `ezscreen/pocket/detect.py` — co-crystal, residue Cα box, P2Rank top-3 + AF profile, blind, volume validation

---

## Phase 4 — ADMET Filtering

### ~~"add admet filter — ro5 and pains for now"~~ ✅ `b6e7bde`
- [x] `ezscreen/admet/filter.py` — Lipinski Ro5, PAINS, Brenk toxicophores, Veber, Egan BBB; per-filter config; library-level SDF pass-through with breakdown stats

---

## Phase 5 — Kaggle Backend

### ~~"start on the kaggle dataset uploader"~~ ✅ `804e7bf`
- [x] `dataset.py` — SHA-256 dedup, manifest, dataset create, delete support

### ~~"add the kernel push wrapper"~~ ✅ `804e7bf`
- [x] `kernel.py` — notebook push, exp backoff, kernel-metadata.json, delete

### ~~"polling loop for running kaggle jobs"~~ ✅ `804e7bf`
- [x] `poller.py` — 30s poll, Rich Live, error classification, retry signalling

### ~~"kaggle runner that ties dataset and kernel together"~~ ✅ `804e7bf`
- [x] `runner.py` — orchestrates full pipeline, retry loop, output download, clean_run()

### ~~"jinja2 notebook template for kaggle"~~ ✅ `25a2602`
- [x] `vina_shard.ipynb.j2` — 9 cells, UniDock-Pro/UniDock switch, scrubber fallback, error.json on every failure, done.flag

---

### ~~"start on the auth command"~~ ✅ `ed1f421`
- [x] `commands/auth.py` — thin wrapper around auth.run_wizard()

### ~~"add the status command"~~ ✅ `ecf1442`
- [x] `commands/status.py` — Rich table, colour-coded status, run count

### ~~"standalone admet command working"~~ ✅ `fefcfe6`
- [x] `commands/admet.py` — interactive filter toggle, breakdown output

### ~~"got the 3d viewer working"~~ ✅ `4316267`
- [x] `commands/view.py` — Rich table + self-contained py3Dmol HTML viewer

### ~~"validate command for diffdock nim"~~ ✅ `2e49e39`
- [x] `commands/validate.py` — DiffDock-L REST, key guard, timeout/auth mapping

### ~~"the big run command — full decision tree"~~ ✅ `bb58e91`
- [x] `commands/run.py` — 8-step state machine (receptor→chains→AF→pocket→ligands→ADMET→depth→confirm→submit)

### ~~"wire all commands into cli.py"~~ ✅ `cd8e472`
- [x] `cli.py` — all 8 subcommands wired with typed Typer arguments

---

## Phase 7 — Results & Reporting

### ~~"merge shard results and render the viewer"~~ ✅ `af6b008`
- [x] `results/merger.py` — CSV merge, best-score dedup, global sort, SDF + failed_prep concat

### ~~"prep report writer"~~ ✅ `2988862`
- [x] `report.py` — Section 8.3 JSON schema, `.txt` human-readable, Rich summary panel

---

## Phase 8 — Status Screen & Version Check

### ~~"ezscreen status with live refresh"~~ ✅ `388efb2`
- [x] `ezscreen status` — 30s auto-refresh
- [x] Version check async + PyPI banner ✅ `45a2986`

---

## Phase 9 — Polish & Packaging

### ~~"final cleanup and readme"~~ ✅
- [x] Smoke test — merger, report, version_check ✅ `9cdebb5`
- [x] `README.md` — install + quickstart ✅ `3c2674a`
- [ ] Conda-forge recipe (post pip release)

---

## Backlog / Nice-to-Have (Post v1)

- All v2 features from handoff Section 16
