# 01 — Tech Architecture

> **STATUS: ALL DECISIONS FINAL — from handoff document**

---

## Tech Stack

| Layer | Technology | Rationale |
|---|---|---|
| CLI framework | **Typer** | Cleaner nested subcommands than Click; type-hint driven; less boilerplate |
| Terminal output | **Rich** | Progress bars, styled tables, panels, syntax highlighting |
| Interactive prompts | **Questionary** | Styled select menus, checkboxes, text inputs via prompt-toolkit |
| Config format | **TOML** | No YAML Norway-problem bugs; `tomllib` in stdlib (3.11+); `tomli-w` for writing |
| Python floor | **3.10 minimum** | 3.11+ preferred; compatibility matrix must be verified before finalising |
| Package distribution | **pip first** | `pyproject.toml`; conda-forge recipe filed after stable v1 release |
| Checkpointing | **SQLite** | Run state, shard status, resume by run-id |
| Notebook templating | **Jinja2** | Renders complete `.ipynb` from template variables |

---

## Docking Engines

| Stage | Engine | Notes |
|---|---|---|
| Stage 1 primary | **UniDock-Pro** | SBVS + LBVS + Hybrid; Apache 2.0; built from source on Kaggle (CUDA ≥ 11.8 + Boost) |
| Stage 1 fallback | **UniDock** | `pip install unidock-tools`; used when no reference ligand is available |
| Stage 2 validation | **DiffDock-L** | Via NVIDIA NIM API; free; called locally (not on Kaggle) |
| v2 (deferred) | Local backend, Colab backend, MD/MMGBSA | Do not implement |

> ⚠️ UniDock-Pro build from source happens in notebook template Cell 2 on Kaggle.

---

## Prep Pipeline

| Step | Tool | Notes |
|---|---|---|
| Receptor prep | pdbfixer → Meeko `mk_prepare_receptor` | Missing residues, waters, alternates, hydrogens |
| Ligand prep | scrub.py → RDKit ETKDG → Meeko | Protonation, 3D conformers, PDBQT output |
| Pocket detection | Tiered (see below) | co-crystal → residues → P2Rank → blind |
| ADMET filtering | RDKit | Ro5, PAINS, toxicophores, Veber, Egan BBB |
| Molscrub install | `git+https://github.com/forlilab/scrubber` | Not on PyPI — pinned in pyproject.toml |

---

## Package Structure

```
ezscreen/
├── cli.py                  # Typer entry points — all subcommands
├── state.py                # State machine — BACK sentinel, context dict
├── config.py               # TOML loader/writer — ~/.ezscreen/config.toml
├── auth.py                 # Credential management — ~/.ezscreen/credentials
├── backends/
│   └── kaggle/
│       ├── runner.py       # Orchestrates dataset push + kernel + poll + download
│       ├── dataset.py      # Kaggle datasets API wrapper
│       ├── kernel.py       # Kaggle kernels API wrapper
│       ├── poller.py       # Status polling — Rich progress, retry logic
│       └── templates/
│           └── vina_shard.ipynb.j2   # Jinja2 notebook template
├── prep/
│   ├── receptor.py         # pdbfixer + Meeko receptor prep
│   └── ligands.py          # scrub.py + RDKit + Meeko ligand prep
├── pocket/
│   └── detect.py           # Tiered pocket detection
├── admet/
│   └── filter.py           # RDKit ADMET filters
├── results/
│   ├── merger.py           # Merge shard CSVs, global re-rank
│   └── viewer.py           # Rich table + py3Dmol HTML generator
├── checkpoint.py           # SQLite run state — create, update, resume
├── report.py               # Prep report — .txt + .json writer
├── errors.py               # Error taxonomy — all error classes
└── vendor/
    └── scrubber/           # Vendored molscrub (if vendoring decided)
```

---

## Config Files

### `~/.ezscreen/config.toml` — preferences only, never secrets

```toml
[run]
auto_resume_threshold = 10   # auto-resume if failure % >= this
shard_retry_limit = 3        # retries before prompting user
default_search_depth = "Balanced"
default_ph = 7.4
admet_pre_filter = true

[kaggle]
default_dataset = "username/ezscreen-workspace"

[defaults]
box_padding = 5.0
enumerate_tautomers = false
```

### `~/.ezscreen/credentials` — chmod 600 enforced — NEVER in config.toml

```
kaggle_json_path = "~/.kaggle/kaggle.json"
nim_api_key = "nvapi-xxxxxxxxxxxx"
```

---

## Kaggle Dataset Strategy

- Single persistent dataset: `ezscreen-workspace` per user
- Local manifest at `~/.ezscreen/manifest.json` — SHA-256 hash dedup
- Receptor: uploaded once, reused across runs if hash matches
- Ligand shards: always new per run
- Dataset structure: `receptor_{hash8}.pdb`, `shard_{run_id}_{n}.sdf`
- `ezscreen clean [run-id]` → deletes entire dataset + kernel artifacts

---

## Notebook Template Structure (Jinja2 → .ipynb)

| Cell | Purpose |
|---|---|
| Cell 1 | Auto-generated header — do not edit |
| Cell 2 | Install deps — UniDock-Pro build or UniDock pip, Meeko, RDKit |
| Cell 3 | Environment check — GPU? CUDA version? Disk space? |
| Cell 4 | Load inputs from `/kaggle/input/ezscreen-{run_id}/` |
| Cell 5 | Receptor prep — pdbfixer → Meeko |
| Cell 6 | Ligand prep — scrub.py → Meeko, batch processing |
| Cell 7 | Docking loop — UniDock-Pro, writes checkpoint per shard |
| Cell 8 | Collect results — write `scores.csv` + `poses.sdf` to `/kaggle/working/` |
| Cell 9 | Write `done.flag` — signals clean completion to poller |

> Every cell writes a structured `error.json` before raising. Poller distinguishes: timeout / prep failure / GPU OOM / clean completion.

### Jinja2 Template Variables

```python
{
  "run_id": "ezs-4f2a8c",
  "engine": "unidock-pro",       # or "unidock"
  "mode": "hybrid",              # sbvs | lbvs | hybrid
  "box_center": [x, y, z],
  "box_size": [sx, sy, sz],
  "exhaustiveness": 8,
  "num_modes": 3,
  "refine_step": 5,
  "max_step": 0,
  "ph": 7.4,
  "shard_index": 2,
  "total_shards": 10,
  "enumerate_tautomers": false,
  "receptor_dataset_path": "/kaggle/input/ezscreen-abc123/receptor.pdb",
  "ligand_dataset_path": "/kaggle/input/ezscreen-abc123/shard_02.sdf"
}
```

---

## State Machine (Back Button)

```python
BACK = object()  # sentinel

def screen_binding_site(ctx):
    choice = questionary.select(..., choices=[..., "← Back"]).ask()
    if choice == "← Back":
        return BACK
    ctx["binding_site"] = choice
    return ctx
```

---

## Pocket Detection — Box Size Rules

| Method | Box Definition |
|---|---|
| Co-crystal ligand | Envelope ligand atoms + 5Å padding per side |
| Residue-defined | Convex hull of residue Cα atoms + 8Å padding |
| P2Rank | Predicted pocket volume + 6Å padding |
| Blind | Whole-protein bounding box + 4Å padding |

⚠️ Warn if box volume > 30,000 Å³ (too large) or < 1,500 Å³ (too small).

---

## Search Depth Presets

| Preset | Exhaustiveness | Poses | Description |
|---|---|---|---|
| Fast | 4 | 1 | triage only · misses ~25% best poses |
| Balanced ★ | 8 | 3 | standard VS · good for rigid pockets |
| Thorough | 16 | 5 | flexible ligands · induced-fit targets |
| Exhaustive | 32 | 9 | allosteric/cryptic pockets · pub quality |
| Expert | custom | custom | all params set manually |

LBVS mode: Fast preset quietly sets `--no_refine` — not exposed to user.

---

## Terminal Color Palette

| Color | Hex | Used for |
|---|---|---|
| Cyan | `#79c0ff` | Prompts, input fields, highlights |
| Amber | `#e3b341` | Warnings, ETA, quota usage |
| Green | `#3fb950` | Success states |
| Red | `#f85149` | Errors, failures |
| Gray | `#8b949e` | Secondary text, unselected options |
| White bold | `#f0f6fc` | Primary text, headings |
| Muted | `#6e7681` | Descriptions, supplementary info |
| Dim | `#484f58` | Dividers, structural chrome |

---

## Shard & Retry Logic

- Shard size: ~2,000 compounds per Kaggle kernel
- `shard_retry_limit`: 3 (configurable)
- `auto_resume_threshold`: 10% (configurable)
- If `failure_pct < threshold`: prompt user (continue partial / resume / change threshold)
- If `failure_pct >= threshold`: auto-resume without prompt
- If auto-resume also fails: prompt permanently (continue partial / try later with checkpoint)

---

## Environment Variables (`.env.example`)

```env
# ezscreen does NOT use .env files for runtime config.
# All user preferences → ~/.ezscreen/config.toml
# All credentials    → ~/.ezscreen/credentials (chmod 600)
#
# For development/testing only:
EZSCREEN_DEV_MODE=false
EZSCREEN_LOG_LEVEL=INFO
```
