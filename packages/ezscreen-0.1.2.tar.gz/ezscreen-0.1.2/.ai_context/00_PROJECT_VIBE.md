# 00 — Project Vibe

> **STATUS: INITIALIZED FROM HANDOFF DOCUMENT**

---

## Core Vision

**ezscreen** is a command-line tool that makes GPU-accelerated virtual screening accessible to researchers who do not have access to high-performance computing hardware. It automates the entire molecular docking pipeline — from receptor and ligand preparation through docking, hit filtering, and pose validation — using Kaggle's free T4 GPU infrastructure as the compute backend.

---

## The Problem We Are Solving

Computational chemists and pharmacologists at under-resourced institutions spend hours configuring docking tools, managing file formats, and debugging prep pipelines before any science gets done. ezscreen collapses this into an interactive CLI with sensible defaults and a guided decision tree.

---

## Target Users

Researchers and students in molecular biology, pharmacology, and computational chemistry who are:
- Comfortable with a terminal
- Not necessarily expert computational chemists
- Using Kaggle or Google Colab for GPU access
- At institutions without dedicated HPC infrastructure

---

## The North Star Statement

> *"A researcher with a PDB code and a ligand library should be able to run GPU-accelerated virtual screening in under 10 minutes, with no HPC access and no configuration expertise."*

---

## Non-Negotiable Core Features (v1 MVP)

1. **`ezscreen run`** — Full interactive guided pipeline: receptor prep → binding site detection → ligand prep → ADMET pre-filter → docking on Kaggle T4 → results
2. **`ezscreen auth`** — Credential wizard for Kaggle API + NVIDIA NIM (optional)
3. **`ezscreen status`** — Live job monitor with auto-refresh, attach/resume/delete actions
4. **`ezscreen resume [run-id]`** — Checkpoint-based resume for interrupted runs (SQLite state)
5. **`ezscreen validate`** — Stage 2 DiffDock-L hit validation via NVIDIA NIM API
6. **`ezscreen admet`** — Standalone ADMET filtering on any CSV or SDF
7. **`ezscreen view`** — Rich table + py3Dmol self-contained HTML results viewer
8. **`ezscreen clean [run-id]`** — Remove Kaggle dataset + kernel artifacts for a run

---

## UX Non-Negotiables

- Every screen has a `← Back` option
- Breadcrumb trail always shown at top of every screen
- Never exit to a bare terminal prompt — always offer next logical action
- Full raw parameter set always shown on confirmation screen (for citation)
- No silent defaults on consequential decisions
- ctrl+c detaches gracefully — Kaggle kernel continues running
- No emoji in terminal output — color-coded with specific hex palette (see `01_TECH_ARCHITECTURE.md`)

---

## Scope — v1 Only

> ⚠️ Features marked v2 in the handoff are **explicitly deferred** and must not be implemented in v1.

**Out of scope for v1:**
- Local compute backend (no Kaggle)
- Google Colab backend
- `ezscreen refine` — MD / MMGBSA post-docking
- Web dashboard (Gradio / Streamlit)
- Multi-target screening (one library vs N receptors)
- Deep ADMET (ADMET-AI, pkCSM)
- Collaboration / team hit lists
- Consensus docking (UniDock-Pro + Gnina)
