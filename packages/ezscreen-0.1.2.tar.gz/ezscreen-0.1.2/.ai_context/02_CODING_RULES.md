# 02 — Coding Rules

> **These rules are the non-negotiable law of this project. Every line of code must comply.**

---

## The 9 Operating Rules

### Rule 1 — The Context Vault
All project meta-knowledge lives in `/.ai_context/`. These 5 files are the absolute source of truth:
- `00_PROJECT_VIBE.md` — Core vision and non-negotiable features
- `01_TECH_ARCHITECTURE.md` — Tech stack, DB schemas, API routes
- `02_CODING_RULES.md` — This file
- `03_TASK_TRACKER.md` — Living checklist of features
- `04_DECISION_LOG.md` — Running log of architectural decisions

The AI must immediately output updated markdown for any file after a decision changes it.

### Rule 2 — Human-Centric Commit Simulation
- Write code in small, iterative, logically ordered pieces
- Code must be clean, functional, and accurate
- No intentional bugs, missing imports, or logical errors
- No unsolicited comments in the code

### Rule 3 — The State Tracker
Every single response from the AI must end with a State Tracker block in this exact format:
```
---
**STATE TRACKER**
* **Current Phase:** [Name]
* **Pending Tasks:**
  - [ ] Task
* **Completed Tasks:**
  - [x] Task
* **Recent Decisions:** [Brief summary]
---
```

### Rule 4 — Test-Driven Vibe Validation
Before writing logic for any complex module:
1. The user provides the vibe/feature
2. The AI writes edge cases and expected behavior
3. The AI waits for explicit user approval before writing code

### Rule 5 — Hard Checkpoints
After every major component is complete:
- Generate a summary of the current codebase state
- Provide a simulated Git commit message as a mental fallback point

### Rule 6 — The Scratchpad Pre-Computation Rule
Before writing any code or vault file updates, the AI must use `<thinking> ... </thinking>` tags to:
- Plan the architecture
- Map out file dependencies
- Catch logical flaws before outputting the final result

### Rule 7 — The Devil's Advocate Clause
Before implementing any new library, database, or major architectural change:
- The AI must provide a strict 2-sentence warning detailing the biggest risk, bottleneck, or technical debt the choice might create

### Rule 8 — `.env` / Secrets Guardrail
- Never hardcode configuration values, API keys, database URIs, or sensitive data
- All user preferences → `~/.ezscreen/config.toml`
- All credentials → `~/.ezscreen/credentials` (chmod 600 enforced)
- Keep `.env.example` updated in the Context Vault

### Rule 9 — The Nuclear Reset Command
If the user types `[SYSTEM RESET]`, the AI must:
- Disregard all current conversational context and memory
- Wipe its internal state entirely
- Rely solely on the `.md` files in `/.ai_context/`
- Await fresh instructions based only on those files

---

## Project-Specific Code Rules

### Language & Version
- Python 3.10 minimum (3.11+ preferred)
- Type hints required on all function signatures
- Use `tomllib` (stdlib 3.11+) or `tomli` (backport for 3.10) for TOML reads
- Use `tomli-w` for TOML writes

### CLI Architecture Rules
- All Typer entry points live in `cli.py` only
- Every screen function follows the BACK sentinel pattern from `state.py`
- Context dict is passed forward through every prompt function — never use global state
- Every questionary select must include `← Back` as the last choice

### Error Handling Rules
- All error classes defined in `errors.py` — never define inline
- Error messages follow the 3-line format: what failed → why → exact fix/URL
- Ligand prep failures: log to `failed.sdf`, never abort the run
- Receptor prep failures: always fatal — clean message + exit
- Kaggle transient errors: auto-retry with `⟳` indicator, up to `shard_retry_limit`

### Security Rules
- Credentials stored in `~/.ezscreen/credentials` only — chmod 600 enforced at write time
- Warn if `config.toml` contains any string matching an API key pattern
- Never log credentials — scrub from all log output

### Output / UX Rules
- No emoji in terminal output
- Use the exact hex color palette defined in `01_TECH_ARCHITECTURE.md`
- Breadcrumb trail must be rendered at the top of every screen
- Confirmation screen must always show full raw parameter set (for citation)
- Post-action routing: always offer viewer / next stage / main menu — never exit to bare prompt

### Logging Rules
- Every run writes to `~/.ezscreen/logs/ezs-{run_id}.log`
- Log: full tracebacks, all API responses, every prep decision with timestamp, exact UniDock-Pro command, shard state transitions
- Users never see logs unless something goes wrong

---

## Git Commit Convention

Commit messages must sound like a real developer wrote them. No conventional commit prefixes. Natural English, lowercase, short and specific.

```
# Good — human, specific
set up project layout and dependencies
add all the error classes we'll need
wire up the back button pattern
stubbed out all 8 cli commands for now
start on the kaggle dataset uploader
got receptor prep working with pdbfixer and meeko
fix auth wizard blowing up on missing kaggle.json
add admet filter — ro5 and pains for now

# Bad — robotic
feat(errors): add full error taxonomy
chore(scaffold): initialize package structure and pyproject.toml
fix(backend): handle Kaggle 403 forbidden during kernel push
```

---

## Code Style
- Formatter: **black** (line length 88)
- Linter: **ruff**
- Import order: stdlib → third-party → local (enforced by ruff isort)
- No unsolicited inline comments
- Docstrings: Google style, only on public-facing functions
