# 04 — Decision Log

> Every significant architectural choice is logged here with reasoning.

---



## Log

### 2026-04-06

**Decision:** Adopted the 9-Rule Vibe Coding Operating System  
**Rationale:** Ensures context permanence across sessions, prevents architecture drift, enforces disciplined iterative delivery.  
**Alternatives Considered:** Ad-hoc development with no formal structure — rejected due to context window drift risk in long-running projects.

---

**Decision:** CLI framework → **Typer** (final)  
**Rationale:** Cleaner nested subcommands than Click; type-hint driven; significantly less boilerplate for a multi-subcommand tool like ezscreen.  
**Alternatives Considered:** Click (more mature, larger ecosystem but more verbose), argparse (too low-level), Cement (overkill for this CLI surface).

---

**Decision:** Interactive prompts → **Questionary** (final)  
**Rationale:** Styled select menus, checkboxes, text inputs via prompt-toolkit. Richer UX than Click's built-in prompts; more control over visual styling than InquirerPy.  
**Alternatives Considered:** InquirerPy (similar feature set, less mature), Click prompts (too basic for guided decision tree).

---

**Decision:** Terminal output → **Rich** (final)  
**Rationale:** Best-in-class Python terminal library for progress bars, styled tables, panels, syntax highlighting. Industry standard.  
**Alternatives Considered:** Colorama (too basic), blessed/urwid (overkill for this use case).

---

**Decision:** Config format → **TOML** (final)  
**Rationale:** `tomllib` is stdlib in Python 3.11+; no YAML Norway-problem bugs; human-readable; `tomli-w` for writing. Credentials stored separately in `~/.ezscreen/credentials` (chmod 600), never in config.  
**Alternatives Considered:** YAML (Norway bug, PyYAML dependency), JSON (not human-editable), INI (too limited for nested config).

---

**Decision:** Checkpointing → **SQLite** (final)  
**Rationale:** Zero-dependency (stdlib), sufficient for tracking run state + shard status per run-id, enables `ezscreen resume` without external service.  
**Alternatives Considered:** Plain JSON files (concurrency risk, harder to query), Redis (external service dependency), PostgreSQL (overkill).

---

**Decision:** Stage 1 primary engine → **UniDock-Pro** (final)  
**Rationale:** Supports SBVS, LBVS, and Hybrid modes in a single tool. Apache 2.0 license. GPU-accelerated. Build from source on Kaggle (CUDA ≥ 11.8 + Boost in Cell 2 of notebook template).  
**Fallback:** UniDock (`pip install unidock-tools`) when no reference ligand is provided (LBVS mode unavailable).  
**Alternatives Considered:** Vina-GPU (older, less maintained), GNINA (deferred to v2 consensus docking).

---

**Decision:** Stage 2 validation → **DiffDock-L via NVIDIA NIM API** (final)  
**Rationale:** Free API, no local GPU required, called from the user's machine (not on Kaggle). NIM key is optional — only required for `ezscreen validate`.  
**Alternatives Considered:** Local DiffDock (requires significant GPU locally), Glide (commercial).

---

**Decision:** Receptor prep → **pdbfixer + Meeko** (final)  
**Rationale:** pdbfixer handles missing residues, waters, alternates. Meeko `mk_prepare_receptor` for PDBQT output. Both are well-maintained and compatible with UniDock-Pro.  
**Alternatives Considered:** OpenBabel (less precise for receptor prep), ADFRsuite (UCSF, good but larger dependency footprint).

---

**Decision:** Ligand prep → **scrub.py (molscrub) + RDKit ETKDG + Meeko** (final)  
**Rationale:** scrub.py handles protonation + tautomers at pH 7.4. RDKit ETKDG generates 3D conformers. Meeko outputs PDBQT for UniDock-Pro.  
**Molscrub install:** `git+` install pinned in pyproject.toml — not on PyPI. Vendoring into `ezscreen/vendor/scrubber/` is still under consideration for long-term stability.

---

**Decision:** Pocket detection → **Tiered (co-crystal → residues → P2Rank → blind)** (final)  
**Rationale:** Ordered by reliability. Co-crystal is gold standard. Residue-defined is high confidence. P2Rank (~77% top-1 on crystals) always shows top 3 to user — never silently takes top-1. Blind is last resort with explicit warning.  
**Critical:** P2Rank top-1 is wrong ~23% of the time; 100% of the time on AlphaFold models it is worse — user must always see top 3 with scores.

---

**Decision:** ADMET v1 → **RDKit rule-based** (final; v2 will add ADMET-AI/pkCSM)  
**Rationale:** Rule-based ADMET (Ro5, PAINS, toxicophores, Veber, Egan BBB) is sufficient for v1 triage. Zero additional dependencies beyond RDKit. Must be clearly communicated to users as "not predictive."  
**v2:** ADMET-AI or pkCSM for property prediction. Not in v1.

---

**Decision:** Results viewer → **Rich table + py3Dmol self-contained HTML** (final)  
**Rationale:** Rich table for in-terminal ranking. py3Dmol generates a self-contained HTML file (SDF embedded as JavaScript string) — no server required, fully offline, shareable by sending the file.  
**Alternatives Considered:** ChimeraX (requires installation), Py3DMol server mode (requires Python server), Gradio (v2 only).

---

**Decision:** Kaggle dataset strategy → **persistent workspace dataset + SHA-256 hash dedup manifest** (final)  
**Rationale:** Single `ezscreen-workspace` dataset per user. Local `manifest.json` tracks file hashes. Receptor uploaded once, reused. Ligand shards always new. `ezscreen clean` deletes when quota needed.

---

**Decision:** Shard & retry logic — thresholds (final defaults, configurable)  
- `shard_retry_limit = 3` — retries per shard before user is prompted  
- `auto_resume_threshold = 10%` — auto-resume if failure% >= this; prompt if below  
- Both adjustable in Settings and inline during a run (with "Save as default?" prompt)

---

---

## 2026-04-06 — Resolved Decisions (from Q&A session)

**Decision: Python floor → Python 3.11** ✅  
**Rationale:** User initially selected 3.10, but compatibility research confirmed the `kaggle` PyPI package (as of Feb 2026) requires Python >=3.11 — a hard constraint since Kaggle is ezscreen's entire compute layer. User confirmed raising to 3.11. Benefits: `tomllib` is stdlib (no `tomli` backport needed), Meeko 3.12 concern resolved, cleaner dependency tree.  
**`requires-python = ">=3.11"`** in `pyproject.toml`.

---

**Decision: Molscrub install strategy → `git+` first, vendor fallback** ✅  
**Rationale:** Try `git+https://github.com/forlilab/scrubber` at install time. If that fails (repo moved, network error, GitHub down), fall back automatically to the vendored copy in `ezscreen/vendor/scrubber/`. This is the most robust approach for a scientific tool where upstream stability cannot be guaranteed.  
**Implementation:** `pyproject.toml` dependency resolver with custom install hook; vendor copy always ships with the package for fallback.

---

**Decision: AlphaFold detection heuristic → 4-tier approach** ✅  
**Research findings:**
- AF3 outputs primarily in mmCIF (`.cif`) format; AF2 outputs PDB (`.pdb`)
- Both use B-factor column for pLDDT scores (range 0–100)
- REMARK lines: AF2 contains `ALPHAFOLD MONOMER` / `ALPHAFOLD MULTIMER V2`; AF3 has expanded REMARKs for non-protein entities
- AF3 may contain non-protein HETATM records (DNA, RNA, ligands)
- Companion JSON (`summary_confidences.json`) is most reliable AF3 indicator

**Proposed detection order (in `prep/receptor.py`):**
1. File extension `.cif` → flag as AF3 (mmCIF); prompt user to convert to PDB before proceeding
2. Companion `summary_confidences.json` in same directory → AF3
3. Scan REMARK lines (case-insensitive) for `ALPHAFOLD`:
   - Contains `V3` or `ALPHAFOLD3` → af3
   - Contains `MONOMER` or `MULTIMER` or `V2` → af2
   - Contains `ALPHAFOLD` without version → unknown AF (treat as af2, warn)
4. B-factor heuristic: if all B-factors ∈ [0, 100] and ≥90% are > 49, likely pLDDT → flag as probable AF, prompt user to confirm

P2Rank: use `--profile alphafold` for any detected AF structure (both AF2 and AF3).  
AlphaFold detection flagged in prep report with `severity: medium`.

---

**Decision: Multi-chain binding site → allow multi-chain selection** ✅  
**Rationale:** User confirmed: allow selection of more than one chain for protein-protein interface binding sites.  
**Implementation:**
- During chain selection prompt, allow `checkbox` multi-select (Questionary)
- Merge ATOM records from all selected chains into a combined receptor for prep
- Box calculation: convex hull of Cα atoms from ALL selected chains + 8Å padding
- Warn user: "Multi-chain receptor selected — box calculation uses combined chain coordinates"
- Note in prep report: chains selected, selection method (user-chosen multi)
- This replaces the v1 assumption of single-chain binding sites.

---

**Decision: Kaggle API error taxonomy → research-complete** ✅  
**Complete error taxonomy for `errors.py`:**

| HTTP Code | Category | ezscreen Type | Retry? | User Message |
|---|---|---|---|---|
| 200 | Success | — | — | — |
| 400 | Bad Request | Permanent | No | "Invalid request parameters — check run config" |
| 401 | Unauthorized | Permanent | No | "API key rejected — go to kaggle.com/settings → API → Create New Token" |
| 403 | Forbidden | Permanent | No | "Account needs phone verification — complete at kaggle.com/settings" |
| 404 | Not Found | Permanent | No | "Resource not found — dataset or kernel may have been deleted" |
| 429 | Rate Limit | Transient | Yes (exp backoff + Retry-After header) | Progress bar, not error message |
| 500 | Server Error | Transient | Yes (exp backoff, max 3) | "Kaggle server error — Retry N/3 · retrying in Ns" |
| 502/503/504 | Gateway/Timeout | Transient | Yes (exp backoff, max 3) | "Kaggle unavailable — Retry N/3 · retrying in Ns" |
| Kernel preempted | Runtime | Transient | Yes (shard_retry_limit) | "⟳ shard N  Retry N/3 — kernel preempted · resubmitting..." |
| GPU quota exhausted | Runtime | Permanent | No | "Weekly GPU quota exhausted. Resets every Monday." |
| Storage limit | Runtime | Permanent | No | "Kaggle dataset storage full. Run ezscreen clean to free space." |
| Network timeout | Network | Transient | Yes (once after 3s) | "Could not reach Kaggle API. Check connection." |

**Key rules:**
- 401/403/400/404: never retry — these are configuration issues
- 429: check `Retry-After` header first; if absent, exponential backoff (2, 4, 8, 16s)
- 5xx: exponential backoff, max 3 retries
- All transient retries show progress indicator, not error message

---

## Pending Decisions

| Item | Blocking | Status |
|---|---|---|
| Python version floor | `pyproject.toml`, Phase 1 | ✅ Resolved — Python 3.11 |
| AlphaFold header detection heuristic | `prep/receptor.py`, `pocket/detect.py` | ✅ Resolved — 4-tier heuristic |
| Molscrub vendoring vs `git+` | `pyproject.toml`, Phase 1 | ✅ Resolved — git+ with vendor fallback |
| Error taxonomy: full Kaggle API enumeration | `errors.py`, Phase 1 | ✅ Resolved — complete table above |
| Multi-chain interface edge case | `pocket/detect.py`, Phase 3 | ✅ Resolved — multi-select + merge |

> **All open items resolved. Phase 1 scaffold cleared to begin.**

---

**Decision: Commit granularity � one file per commit (from Phase 6 onward)** ?
One file, one commit. No bundling. Exception: trivial companion __init__.py changes with no logic may be swept into the parent file's commit.

