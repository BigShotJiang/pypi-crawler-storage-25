"""
Nexus — filesystem/context plane.

Nexus combines a VFS-style filesystem interface with deployment-aware context,
storage, and service composition for agent systems.

Deployment profiles control which bricks are enabled:
- slim: Bare VFS, storage only
- embedded: Storage + eventlog
- lite: Core services
- full: All bricks (default)
- cloud: All bricks + federation
- innovation: All bricks + startup validation (experimental)
- remote: Thin gRPC client (RemoteBackend + RemoteServiceProxy)

SDK vs CLI:
-----------
For programmatic access (building tools, libraries, integrations), use the SDK:

    from nexus.sdk import connect

    nx = connect(config={"profile": "slim", "data_dir": "./nexus-data"})
    await nx.sys_write("/workspace/data.txt", b"Hello World")
    content = await nx.sys_read("/workspace/data.txt")

For command-line usage, use the nexus CLI:

    $ nexus ls /workspace
    $ nexus write /file.txt "content"

Backward Compatibility:
-----------------------
    import nexus

    nx = nexus.connect()  # Still works, but prefer nexus.sdk.connect()

The main nexus module re-exports core functionality for backward compatibility.
New projects should use nexus.sdk for a cleaner API.

PERFORMANCE NOTE:
-----------------
This module uses lazy imports to minimize startup time. Heavy modules like
nexus.core.nexus_fs and nexus.remote are only loaded when
first accessed. This reduces import time from ~10s to ~1s for simple use cases.
"""

import logging
import os as _os
from typing import TYPE_CHECKING, Any, cast

__version__ = "0.9.20"  # release version
__author__ = "Nexi Lab Team"
__license__ = "Apache-2.0"

# =============================================================================
# LAZY IMPORTS for performance optimization
# =============================================================================
# These modules are imported lazily via __getattr__ to avoid loading heavy
# dependencies (nexus_fs, remote) on module import.
# This significantly speeds up CLI startup and FUSE mount initialization.

if TYPE_CHECKING:
    # Type hints for IDE support - these don't trigger actual imports
    from pathlib import Path

    from nexus.backends.base.backend import Backend
    from nexus.backends.storage.cas_gcs import CASGCSBackend as GCSBackend
    from nexus.backends.storage.cas_local import CASLocalBackend
    from nexus.config import NexusConfig, load_config
    from nexus.contracts.exceptions import (
        BackendError,
        InvalidPathError,
        MetadataError,
        NexusError,
        NexusFileNotFoundError,
        NexusPermissionError,
    )
    from nexus.contracts.filesystem.filesystem_abc import NexusFilesystem as NexusFilesystem
    from nexus.core.metastore import MetastoreABC
    from nexus.core.nexus_fs import NexusFS

# =============================================================================
# Lightweight imports (always loaded) - these are fast
# =============================================================================
from nexus.contracts.exceptions import (
    BackendError,
    InvalidPathError,
    MetadataError,
    NexusError,
    NexusFileNotFoundError,
    NexusPermissionError,
)

# All mutable state (data, metastore, record store, etc.) lives under this directory.
NEXUS_STATE_DIR = _os.path.expanduser("~/.nexus")

logger = logging.getLogger(__name__)

# Module-level cache for lazy imports
_lazy_imports_cache: dict[str, Any] = {}

# Mapping of attribute names to their import paths
_LAZY_IMPORTS = {
    # Backends
    "Backend": ("nexus.backends.base.backend", "Backend"),
    "CASLocalBackend": ("nexus.backends.storage.cas_local", "CASLocalBackend"),
    "GCSBackend": ("nexus.backends.storage.cas_gcs", "CASGCSBackend"),
    # Config
    "NexusConfig": ("nexus.config", "NexusConfig"),
    "load_config": ("nexus.config", "load_config"),
    # Core - heavy
    "NexusFilesystem": ("nexus.contracts.filesystem.filesystem_abc", "NexusFilesystem"),
    "NexusFS": ("nexus.core.nexus_fs", "NexusFS"),
    # Slim package top-level API (nexus.mount / nexus.mount_sync)
    "mount": ("nexus.fs", "mount"),
    "mount_sync": ("nexus.fs", "mount_sync"),
}


def __getattr__(name: str) -> Any:
    """Lazy import for heavy dependencies.

    This function is called when an attribute is not found in the module.
    It loads the requested module/class on demand, significantly reducing
    import time for simple use cases.
    """
    # Check cache first
    if name in _lazy_imports_cache:
        return _lazy_imports_cache[name]

    # Check if this is a lazy import
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        import importlib

        module = importlib.import_module(module_path)
        value = getattr(module, attr_name)
        _lazy_imports_cache[name] = value
        return value

    # Special case: connect function (defined below but needs lazy deps)
    if name == "connect":
        return connect

    raise AttributeError(f"module 'nexus' has no attribute {name!r}")


def _open_local_metastore(metadata_path: str) -> "MetastoreABC":
    """Open a local metadata store — RaftMetadataStore.embedded → DictMetastore fallback."""
    from pathlib import Path

    try:
        from nexus.storage.raft_metadata_store import RaftMetadataStore

        return RaftMetadataStore.embedded(metadata_path)
    except (RuntimeError, ImportError):
        from nexus.storage.dict_metastore import DictMetastore

        dict_metastore_path = Path(metadata_path).with_suffix(".json")
        logger.info(
            "Rust metastore not available; using JSON-backed DictMetastore fallback at %s. "
            "Build rust/nexus_raft with maturin develop -m rust/nexus_raft/Cargo.toml "
            "--features python for the durable metastore.",
            dict_metastore_path,
        )
        return DictMetastore(dict_metastore_path)


async def connect(
    config: "str | Path | dict | NexusConfig | None" = None,
) -> "NexusFilesystem":
    """
    Connect to Nexus filesystem.

    This is the main entry point for using Nexus. It dispatches based on the
    deployment profile in configuration:

    - **profile="remote"**: Thin gRPC client (RemoteBackend + RemoteServiceProxy).
    - **All other profiles**: Local NexusFS. Federation (Raft + ZoneManager) is
      auto-detected based on whether the Rust extensions are importable.

    Args:
        config: Configuration source:
            - None: Auto-discover from environment/files (default)
            - str/Path: Path to config file
            - dict: Configuration dictionary
            - NexusConfig: Already loaded config

    Returns:
        NexusFilesystem instance. All profiles implement the NexusFilesystem
        interface, ensuring consistent API.

    Raises:
        ValueError: If configuration is invalid

    Examples:
        Remote profile (production client):
            >>> nx = nexus.connect(config={
            ...     "profile": "remote",
            ...     "url": "http://localhost:2026",
            ...     "api_key": "your-api-key"
            ... })

        Default (development/testing):
            >>> nx = nexus.connect()
            >>> await nx.sys_write("/workspace/file.txt", b"Hello World")

        Federation (auto-detected when Rust extensions available):
            >>> # Requires NEXUS_PEERS, NEXUS_BIND_ADDR env vars
            >>> nx = nexus.connect(config={"profile": "cloud"})
    """
    import os
    from pathlib import Path

    from nexus.config import NexusConfig, load_config

    # Load configuration
    cfg = load_config(config)

    # ── Profile: remote ──────────────────────────────────────────────
    if cfg.profile == "remote":
        from urllib.parse import urlparse

        server_url = cfg.url or os.getenv("NEXUS_URL")
        if not server_url:
            raise ValueError(
                "profile='remote' requires a server URL. "
                "Set 'url' in config or NEXUS_URL environment variable."
            )
        api_key = cfg.api_key or os.getenv("NEXUS_API_KEY")
        timeout = int(cfg.timeout) if hasattr(cfg, "timeout") else 30
        connect_timeout = int(cfg.connect_timeout) if hasattr(cfg, "connect_timeout") else 5

        # Build gRPC address from NEXUS_URL hostname + gRPC port.
        # Port precedence: NEXUS_GRPC_PORT env > nexus.yaml ports.grpc > default 2028
        _grpc_port_str = os.getenv("NEXUS_GRPC_PORT")
        if not _grpc_port_str:
            try:
                import yaml as _yaml

                _pf = Path("nexus.yaml")
                if _pf.exists():
                    with open(_pf) as _f:
                        _pc = _yaml.safe_load(_f) or {}
                    _grpc_port_str = str(_pc.get("ports", {}).get("grpc", ""))
            except Exception:
                pass
        grpc_port = int(_grpc_port_str) if _grpc_port_str else 2028
        parsed = urlparse(server_url)
        grpc_address = f"{parsed.hostname}:{grpc_port}"

        # Single shared RPCTransport (gRPC channel) for all remote proxies.
        from nexus.remote.rpc_transport import RPCTransport

        # TLS: only use TLS when explicitly requested via:
        #   1. NEXUS_DATA_DIR env var (2-phase bootstrap)
        #   2. nexus.yaml tls: true (written by `nexus up` when server uses mTLS)
        # Do NOT auto-discover from data_dir/tls/ alone — the server may
        # generate certs but run gRPC insecure (new default on develop).
        _tls_config = None
        _tls_enabled = False
        _data_dir = os.getenv("NEXUS_DATA_DIR")
        if _data_dir:
            _tls_enabled = True  # Explicit env var = TLS intended
        if not _data_dir:
            _project_yaml = Path("nexus.yaml")
            if _project_yaml.exists():
                try:
                    import yaml as _yaml

                    with open(_project_yaml) as _f:
                        _project_cfg = _yaml.safe_load(_f) or {}
                    _data_dir = _project_cfg.get("data_dir")
                    _tls_enabled = bool(_project_cfg.get("tls"))
                except Exception:
                    pass
        if not _data_dir:
            _data_dir = getattr(cfg, "data_dir", None)

        if _data_dir and _tls_enabled:
            from nexus.security.tls.config import ZoneTlsConfig

            _tls_config = ZoneTlsConfig.from_data_dir(_data_dir)

        transport = RPCTransport(
            server_address=grpc_address,
            auth_token=api_key,
            timeout=float(timeout),
            connect_timeout=float(connect_timeout),
            tls_config=_tls_config,
        )

        # RemoteBackend + RemoteMetastore — stateless proxies, server is SSOT.
        from nexus.backends.storage.remote import RemoteBackend
        from nexus.storage.remote_metastore import RemoteMetastore

        remote_backend = RemoteBackend(transport)
        remote_metastore = RemoteMetastore(transport)

        # Build a lightweight NexusFS directly — no factory, no bricks.
        # Server is SSOT; client just proxies calls via gRPC.
        # No parser registries — remote delegates all parsing to the server.
        from nexus.core.config import PermissionConfig as _PermissionConfig
        from nexus.core.mount_table import MountTable as _MountTable
        from nexus.core.nexus_fs import NexusFS as _RemoteNexusFS
        from nexus.core.router import PathRouter as _PathRouter

        _mount_table = _MountTable(remote_metastore)
        _mount_table.add("/", remote_backend)
        _router = _PathRouter(_mount_table)

        from nexus.contracts.types import OperationContext as _RemoteOC

        nfs = _RemoteNexusFS(
            metadata_store=remote_metastore,
            permissions=_PermissionConfig(enforce=False),
            router=_router,
            init_cred=_RemoteOC(user_id="remote", groups=[], is_admin=False),
        )

        # Wire service proxies for REMOTE profile (Issue #1171).
        # Fills all 25+ service slots with RemoteServiceProxy — forwards
        # method calls to the server via gRPC.
        from nexus.factory._remote import (
            _boot_remote_services,
            install_remote_kernel_rpc_overrides,
        )

        await _boot_remote_services(nfs, call_rpc=transport.call_rpc)
        install_remote_kernel_rpc_overrides(nfs, transport)
        nfs._register_runtime_closeable(transport)

        return nfs

    # ── Local node (single-node or federated, auto-detected) ────────
    # Heavy imports for local profiles
    from nexus.backends.base.backend import Backend
    from nexus.backends.storage.cas_local import CASLocalBackend
    from nexus.core.nexus_fs import NexusFS

    # Create backend based on configuration
    backend: Backend
    if cfg.backend == "gcs":
        from nexus.backends.storage.cas_gcs import CASGCSBackend

        if not cfg.gcs_bucket_name:
            raise ValueError(
                "gcs_bucket_name is required when backend='gcs'. "
                "Set gcs_bucket_name in your config or NEXUS_GCS_BUCKET_NAME environment variable."
            )
        backend = CASGCSBackend(
            bucket_name=cfg.gcs_bucket_name,
            project_id=cfg.gcs_project_id,
            credentials_path=cfg.gcs_credentials_path,
        )
        nexus_root = NEXUS_STATE_DIR
        data_dir = str(Path(nexus_root) / "data")
    else:
        data_dir = cfg.data_dir if cfg.data_dir is not None else str(Path(NEXUS_STATE_DIR) / "data")
        # nexus_root hosts sibling state directories (metastore, record_store).
        # When data_dir is explicitly provided (e.g. --data-dir /some/path), USE
        # data_dir itself as nexus_root so metastore goes inside it — this avoids
        # polluting the parent directory (which could be /tmp or /) and ensures
        # each data_dir is fully self-contained.  When data_dir is the default
        # (~/.nexus/data), the parent (~/.nexus) is still used as nexus_root
        # for backward compatibility.
        nexus_root = data_dir if cfg.data_dir is not None else str(Path(data_dir).parent)
        if cfg.backend == "path_local":
            from nexus.backends.storage.path_local import PathLocalBackend

            backend = PathLocalBackend(root_path=Path(data_dir).resolve())
        else:
            # Parse tiering config from YAML if present (Issue #3406)
            tiering_cfg = None
            if cfg.tiering and cfg.tiering.get("enabled"):
                from nexus.core.config import TieringConfig

                t = cfg.tiering
                tiering_cfg = TieringConfig(
                    enabled=True,
                    quiet_period_seconds=float(t.get("quiet_period", 3600)),
                    min_volume_size_bytes=int(t.get("min_volume_size", 100 * 1024 * 1024)),
                    cloud_backend=str(t.get("cloud_backend", "gcs")),
                    cloud_bucket=str(t.get("cloud_bucket", "")),
                    upload_rate_limit_bytes=int(t.get("upload_rate_limit", 25 * 1024 * 1024)),
                    sweep_interval_seconds=float(t.get("sweep_interval", 60)),
                    local_cache_size_bytes=int(t.get("local_cache_size", 10 * 1024 * 1024 * 1024)),
                    burst_read_threshold=int(t.get("burst_read_threshold", 5)),
                    burst_read_window_seconds=float(t.get("burst_read_window", 60)),
                )
            backend = CASLocalBackend(
                root_path=Path(data_dir).resolve(),
                tiering_config=tiering_cfg,
            )

    # Resolve paths — new fields take precedence, db_path is legacy fallback
    metadata_path = cfg.metastore_path or cfg.db_path or str(Path(nexus_root) / "metastore")
    record_store_path = cfg.record_store_path or None

    # --- Profile resolution (Issue #1708, moved before metadata store for federation gating) ---
    from nexus.contracts.deployment_profile import DeploymentProfile, resolve_enabled_bricks

    if cfg.profile == "auto":
        from nexus.lib.device_capabilities import detect_capabilities, suggest_profile

        caps = detect_capabilities()
        resolved_profile = suggest_profile(caps)
        logger.info(
            "Auto-detected profile: %s (RAM=%dMB, GPU=%s, cores=%d)",
            resolved_profile,
            caps.memory_mb,
            caps.has_gpu,
            caps.cpu_cores,
        )
    else:
        resolved_profile = DeploymentProfile(cfg.profile)
        # Warn if explicit profile may exceed device capabilities
        from nexus.lib.device_capabilities import (
            detect_capabilities,
            warn_if_profile_exceeds_device,
        )

        caps = detect_capabilities()
        warn_if_profile_exceeds_device(resolved_profile, caps)

    # Apply FeaturesConfig overrides (Issue #1389)
    overrides = cfg.features.to_overrides() if cfg.features else {}
    enabled_bricks = resolve_enabled_bricks(resolved_profile, overrides=overrides)

    # Create metadata store — profile-gated federation (PR #3371 Phase 2)
    metadata_store: MetastoreABC
    federation = None

    # Federation: attempt when IPC brick is enabled (cluster profile and above).
    # Federation is a system service (not a brick) but requires IPC infrastructure.
    if "ipc" in enabled_bricks:
        try:
            from nexus.raft.federation import NexusFederation

            federation, metadata_store = NexusFederation.bootstrap(metadata_path=metadata_path)
        except ImportError:
            logger.warning("Federation brick enabled but Rust extensions unavailable")
            federation = None
            metadata_store = _open_local_metastore(metadata_path)
        except RuntimeError as exc:
            if "ZoneManager requires PyO3 build with --features full" not in str(exc):
                raise
            logger.info(
                "Federation extensions unavailable for local connect(); "
                "falling back to single-node metadata store"
            )
            federation = None
            metadata_store = _open_local_metastore(metadata_path)
    else:
        metadata_store = _open_local_metastore(metadata_path)

    # Permission defaults: standalone without explicit config → permissive
    enforce_permissions = cfg.enforce_permissions
    if config is None or isinstance(config, dict) and "enforce_permissions" not in config:
        enforce_permissions = False

    # Zone isolation: default enabled for security
    enforce_zone_isolation = cfg.enforce_zone_isolation
    if config is None or isinstance(config, dict) and "enforce_zone_isolation" not in config:
        enforce_zone_isolation = True

    # Tiger Cache
    enable_tiger_cache_env = os.getenv("NEXUS_ENABLE_TIGER_CACHE", "true").lower()
    enable_tiger_cache = enable_tiger_cache_env in ("true", "1", "yes")

    # RecordStore (Four Pillars) — created from NEXUS_RECORD_STORE_PATH or
    # NEXUS_DATABASE_URL.  Passing None gives a bare kernel (storage-only)
    # where all service-layer features (audit log, versioning, ReBAC, Memory
    # API, etc.) are skipped.  The factory handles record_store=None gracefully.
    _database_url = os.environ.get("NEXUS_DATABASE_URL")
    if record_store_path:
        from nexus.storage.record_store import SQLAlchemyRecordStore

        record_store = SQLAlchemyRecordStore(db_path=record_store_path)
    elif _database_url:
        from nexus.storage.record_store import SQLAlchemyRecordStore

        record_store = SQLAlchemyRecordStore(db_url=_database_url)
    else:
        record_store = None

    # Build config objects from NexusConfig fields (Issue #1391)
    from nexus.core.config import (
        CacheConfig,
        DistributedConfig,
        ParseConfig,
        PermissionConfig,
    )

    cache_cfg = CacheConfig(
        path_size=cfg.cache_path_size,
        list_size=cfg.cache_list_size,
        kv_size=cfg.cache_kv_size,
        exists_size=cfg.cache_exists_size,
        ttl_seconds=cfg.cache_ttl_seconds,
    )

    perm_cfg = PermissionConfig(
        enforce=enforce_permissions,
        allow_admin_bypass=cfg.allow_admin_bypass,
        enforce_zone_isolation=enforce_zone_isolation,
        enable_tiger_cache=enable_tiger_cache,
    )

    dist_cfg = DistributedConfig(
        enable_workflows=cfg.enable_workflows,
    )

    parse_cfg = ParseConfig(
        auto_parse=cfg.auto_parse,
        providers=tuple(cfg.parse_providers) if cfg.parse_providers else None,
    )

    # Audit strict mode: env var override (default True for compliance)
    from nexus.contracts.types import AuditConfig

    _audit_strict = os.environ.get("NEXUS_AUDIT_STRICT_MODE", "true").lower() not in (
        "false",
        "0",
        "no",
    )
    audit_cfg = AuditConfig(strict_mode=_audit_strict)

    # Create NexusFS via factory
    from nexus.factory import create_nexus_fs

    nx_fs = await create_nexus_fs(
        backend=backend,
        metadata_store=metadata_store,
        record_store=record_store,
        is_admin=cfg.is_admin,
        cache=cache_cfg,
        permissions=perm_cfg,
        distributed=dist_cfg,
        parsing=parse_cfg,
        enabled_bricks=enabled_bricks,
        audit=audit_cfg,
        federation=federation,
    )

    # Set memory config for Memory API
    if cfg.zone_id or cfg.user_id or cfg.agent_id:
        nx_fs._memory_config = {
            "zone_id": cfg.zone_id,
            "user_id": cfg.user_id,
            "agent_id": cfg.agent_id,
        }

    # Store config for OAuth factory and other components that need it
    nx_fs._config = cfg

    # Register federation content resolver (PRE-DISPATCH, Issue #163)
    # Registered LAST so Pipe/Memory/VirtualView resolvers get priority.
    # Federation is already enlisted in ServiceRegistry by _wire_services().
    if federation is not None:
        await _register_federation_resolver(nx_fs, federation, backend)

    # Restore saved mounts (application-layer startup I/O)
    await _restore_mounts(nx_fs)

    return nx_fs


async def _register_federation_resolver(nx_fs: "NexusFS", federation: Any, backend: Any) -> None:
    """Wire federation transport — set TLS config on RPCTransportPool.

    Content locality (remote reads) and IPC (remote pipe/stream) are now
    handled transparently by DriverLifecycleCoordinator.resolve_backend()
    and RPCTransportPool. No PRE-DISPATCH resolvers needed.

    The old FederationContentResolver, FederationIPCResolver, and
    FederatedMetadataProxy have been deleted — their functionality is
    subsumed by PathRouter per-mount metastore (#3580), backend_key()
    write enrichment, and resolve_backend() pool lookup.
    """
    _ = backend  # unused after resolver deletion
    _zone_mgr = federation.zone_manager

    # Set TLS config on transport pool now that federation is initialized
    if (
        hasattr(nx_fs, "_transport_pool")
        and nx_fs._transport_pool is not None
        and _zone_mgr.tls_config
    ):
        nx_fs._transport_pool.set_tls_config(_zone_mgr.tls_config)

    logger.info("Federation transport configured (TLS=%s)", _zone_mgr.tls_config is not None)


async def _restore_mounts(nx_fs: "NexusFS") -> None:
    """Restore saved mounts from database at application startup.

    This is application-layer I/O that runs after NexusFS construction.
    The factory itself never performs I/O — callers decide when to
    restore mounts.
    """
    import os

    try:
        auto_sync = os.getenv("NEXUS_AUTO_SYNC_MOUNTS", "false").lower() in (
            "true",
            "1",
            "yes",
        )
        mount_result = await nx_fs.service("mount_persist").load_all_mounts(auto_sync=auto_sync)
        if mount_result["loaded"] > 0 or mount_result["failed"] > 0:
            sync_msg = f", {mount_result['synced']} synced" if mount_result["synced"] > 0 else ""
            logger.info(
                "Mount restoration: %d loaded%s, %d failed",
                mount_result["loaded"],
                sync_msg,
                mount_result["failed"],
            )
            if not auto_sync and mount_result["loaded"] > 0:
                logger.info(
                    "Auto-sync disabled for fast startup. "
                    "Use sync_mount() or set NEXUS_AUTO_SYNC_MOUNTS=true"
                )
            for error in mount_result.get("errors", []):
                logger.error("  Mount error: %s", error)
    except Exception as e:
        logger.warning("Failed to load saved mounts during initialization: %s", e)


__all__ = [
    # Version
    "__version__",
    # Main entry points
    "connect",
    "mount",
    "mount_sync",
    # Configuration
    "NexusConfig",
    "load_config",
    # Core interfaces
    "NexusFilesystem",  # Protocol for all filesystem modes
    # Filesystem implementation
    "NexusFS",
    # Backends
    "CASLocalBackend",
    "GCSBackend",
    # Exceptions (always loaded - lightweight)
    "NexusError",
    "NexusFileNotFoundError",
    "NexusPermissionError",
    "BackendError",
    "InvalidPathError",
    "MetadataError",
]
