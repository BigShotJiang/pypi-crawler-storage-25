# pyestrombe

quick tool to show practical code in terminal

---

## install

```bash
pip install pyestrombe
```

---

## use

list all:

```bash
pyestrombe list
```

get any practical:

```bash
pyestrombe 1
pyestrombe 2
pyestrombe 3
```

it will just give the access of exact code

---

## structure

```
modules/
 m01.py
 m02.py
 ...
 m08.py
```

---


---

## notes

* made for exams (fast access)

---

done 👍
