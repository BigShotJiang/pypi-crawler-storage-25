from __future__ import annotations

import re
import sys
from importlib import resources

MODULE_PATTERN = re.compile(r"^m(\d{2})\.py$")


def _available_modules() -> list[int]:
    modules_pkg = resources.files("pyinspect_cli.modules")
    found: list[int] = []
    for entry in modules_pkg.iterdir():
        if not entry.is_file():
            continue
        match = MODULE_PATTERN.match(entry.name)
        if match:
            found.append(int(match.group(1)))
    return sorted(found)


def _named_files() -> dict[str, object]:
    modules_pkg = resources.files("pyinspect_cli.modules")
    names: dict[str, object] = {}
    for entry in modules_pkg.iterdir():
        if not entry.is_file():
            continue
        # Keep numbered python modules managed by numeric lookup.
        if MODULE_PATTERN.match(entry.name):
            continue
        stem = entry.name.rsplit(".", 1)[0].lower()
        if stem == "__init__":
            continue
        names[stem] = entry
    return names


def _print_usage() -> None:
    print("Usage: pyestrombe <number|name> | pyestrombe list")


def main() -> None:
    args = sys.argv[1:]

    if not args:
        _print_usage()
        sys.exit(1)

    cmd = args[0]
    available = _available_modules()
    named = _named_files()

    if cmd == 'list':
        if not available and not named:
            print("No modules or named files found.")
            return
        for num in available:
            print(f"{num} - Module {num}")
        for name in sorted(named):
            print(f"{name} - Named file")
        return

    if cmd.isdigit():
        module_num = int(cmd)
        if module_num not in available:
            if not available:
                print("Error: No modules are available.")
            else:
                min_mod, max_mod = available[0], available[-1]
                print(
                    f"Error: Module {module_num} not found. "
                    f"Available range: {min_mod} to {max_mod}."
                )
            sys.exit(1)

        file_name = f"m{module_num:02d}.py"
        module_file = resources.files("pyinspect_cli.modules").joinpath(file_name)
        print(module_file.read_text(encoding="utf-8"))
    elif cmd.lower() in named:
        print(named[cmd.lower()].read_text(encoding="utf-8"))
    else:
        print(f"Error: Invalid command or module number/name '{cmd}'.")
        _print_usage()
        sys.exit(1)

if __name__ == "__main__":
    main()
