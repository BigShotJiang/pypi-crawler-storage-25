"""Additional FastAPI endpoint coverage for templates and MCP diagnostics."""

import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import HTTPException
from fastapi.testclient import TestClient


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_template_endpoints_list_get_and_render():
    from api.main import app

    client = TestClient(app)
    headers = {"Authorization": "Bearer api-secret"}

    list_resp = client.get("/api/templates", headers=headers)
    detail_resp = client.get("/api/templates/summarize", headers=headers)
    render_resp = client.post(
        "/api/templates/summarize/render",
        json={"params": {"text": "Housing prices rose.", "style": "bullet_points"}},
        headers=headers,
    )

    assert list_resp.status_code == 200
    assert any(item["name"] == "summarize" for item in list_resp.json())
    assert detail_resp.status_code == 200
    assert detail_resp.json()["name"] == "summarize"
    assert render_resp.status_code == 200
    assert render_resp.json()[0]["role"] == "system"
    assert "Housing prices rose." in render_resp.json()[1]["content"]


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
@patch("api.main.get_mcp_chat_engine", new_callable=AsyncMock)
def test_mcp_client_servers_endpoint_formats_runtime_timestamps(mock_get_engine):
    from api.main import app

    engine = MagicMock()
    engine.list_tools.return_value = []
    engine._server_index = {
        "demo": MagicMock(enabled=True, auto_start=True, source_client="claude-desktop")
    }
    engine.list_servers.return_value = [
        MagicMock(
            server_id="demo",
            status="connected",
            error=None,
            transport="stdio",
            latency_ms=4.2,
            last_checked_at=1775413645.2024734,
            last_connected_at=1775413645.2024734,
        )
    ]
    mock_get_engine.return_value = engine

    client = TestClient(app)
    resp = client.get(
        "/api/mcp-client/servers?refresh=true",
        headers={"Authorization": "Bearer api-secret"},
    )

    assert resp.status_code == 200
    body = resp.json()
    assert body["servers"][0]["last_checked_at"].endswith("Z")
    assert body["servers"][0]["last_connected_at"].endswith("Z")


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
@patch("api.main.get_mcp_chat_engine", new_callable=AsyncMock)
def test_mcp_client_health_endpoint_returns_snapshot(mock_get_engine):
    from api.main import app

    engine = MagicMock()
    engine.get_health_snapshot = AsyncMock(
        return_value={
            "status": "healthy",
            "checked_at": "2026-04-05T00:00:00Z",
            "summary": {"total": 2, "connected": 1, "failed": 0},
            "servers": [
                {
                    "server_id": "demo",
                    "status": "connected",
                    "transport": "stdio",
                    "latency_ms": 4.2,
                }
            ],
        }
    )
    mock_get_engine.return_value = engine

    client = TestClient(app)
    resp = client.get(
        "/api/mcp-client/health",
        headers={"Authorization": "Bearer api-secret"},
    )

    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "healthy"
    assert body["summary"]["connected"] == 1
    assert body["servers"][0]["server_id"] == "demo"


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
@patch("api.main.get_mcp_chat_engine", new_callable=AsyncMock)
def test_mcp_client_tool_execution_sanitizes_errors(mock_get_engine):
    from api.main import app

    engine = MagicMock()
    engine.call_tool = AsyncMock(
        side_effect=RuntimeError("tool failed for sk-proj-ABCDEFGHIJKLMNOP")
    )
    mock_get_engine.return_value = engine

    client = TestClient(app)
    resp = client.post(
        "/api/mcp-client/tools/demo/run",
        json={"arg": "value"},
        headers={"Authorization": "Bearer api-secret"},
    )

    assert resp.status_code == 400
    assert "sk-proj-ABCDEFGHIJKLMNOP" not in resp.text
    assert "REDACTED" in resp.text


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_mcp_client_servers_endpoint_does_not_autostart_on_first_load():
    import api.main as api_main
    from api.main import app

    client = TestClient(app)
    headers = {"Authorization": "Bearer api-secret"}

    original_engine = api_main._mcp_chat_engine
    api_main._mcp_chat_engine = None

    with patch(
        "api.main.MCPClientEngine.start",
        new=AsyncMock(side_effect=RuntimeError("should not start")),
    ):
        resp = client.get("/api/mcp-client/servers?refresh=true", headers=headers)

    api_main._mcp_chat_engine = original_engine

    assert resp.status_code == 200
    assert "servers" in resp.json()


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_versioned_api_aliases_and_file_size_limits():
    import api.main as api_main
    from api.main import app

    client = TestClient(app)
    headers = {"Authorization": "Bearer api-secret"}

    versioned_health = client.get("/v1/health")
    assert versioned_health.status_code == 200
    assert versioned_health.json() == {"status": "healthy"}

    versioned_templates = client.get("/v1/templates", headers=headers)
    assert versioned_templates.status_code == 200

    with patch.object(api_main, "_MAX_FILE_PAYLOAD_CHARS", 10):
        resp = client.post(
            "/api/chat",
            json={
                "provider": "openai",
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": "hi"}],
                "file_name": "notes.txt",
                "file_content": "x" * 11,
            },
            headers=headers,
        )

    assert resp.status_code == 413
    assert resp.json()["detail"]["error"] == "file_too_large"


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_catalog_and_all_models_endpoints_cover_validation_paths(monkeypatch):
    from api.main import app
    from stratifyai.api_key_helper import APIKeyHelper
    from stratifyai.utils import provider_validator

    def fake_validate_provider_models(provider, model_ids):
        if provider == "bedrock":
            return {
                "valid_models": [],
                "error": "bedrock offline",
                "validation_time_ms": 7,
            }
        return {
            "valid_models": model_ids[:1],
            "error": None,
            "validation_time_ms": 5,
        }

    monkeypatch.setattr(
        APIKeyHelper,
        "check_available_providers",
        staticmethod(
            lambda: {
                "openai": True,
                "anthropic": False,
                "google": False,
                "deepseek": False,
                "groq": False,
                "grok": False,
                "ollama": True,
                "openrouter": False,
                "bedrock": True,
            }
        ),
    )
    monkeypatch.setattr(
        provider_validator,
        "validate_provider_models",
        fake_validate_provider_models,
    )

    client = TestClient(app)
    headers = {"Authorization": "Bearer api-secret"}

    all_models_resp = client.get("/api/all-models", headers=headers)
    assert all_models_resp.status_code == 200
    all_models = all_models_resp.json()
    assert all_models["summary"]["total_providers"] == 9
    assert all_models["summary"]["active_providers"] == 3
    assert all_models["providers"]["openai"]["active"] is True
    assert all_models["providers"]["bedrock"]["validation_error"] == "bedrock offline"
    assert all_models["providers"]["openai"]["models"][0]["validated"] is True

    catalog_resp = client.get("/api/catalog", headers=headers)
    assert catalog_resp.status_code == 200
    catalog = catalog_resp.json()
    first_openai_model = next(iter(catalog["openai"].values()))
    assert "display_name" in first_openai_model
    assert "context_window" in first_openai_model
    assert "max_output_tokens" in first_openai_model


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_model_metadata_endpoints_cover_success_and_not_found(monkeypatch):
    from api.main import app
    from stratifyai.utils import provider_validator

    monkeypatch.setattr(
        provider_validator,
        "get_validated_interactive_models",
        lambda provider: {
            "models": {
                "gpt-4o-mini": {
                    "display_name": "GPT-4o Mini",
                    "description": "Fast test model",
                    "category": "chat",
                    "reasoning_model": False,
                    "supports_vision": True,
                }
            },
            "validation_result": {"error": None, "validation_time_ms": 12},
        },
    )

    client = TestClient(app)
    headers = {"Authorization": "Bearer api-secret"}

    models_resp = client.get("/api/models/openai", headers=headers)
    assert models_resp.status_code == 200
    models_payload = models_resp.json()
    assert models_payload["validation"]["validated"] is True
    assert models_payload["validation"]["api_key_set"] is True
    assert models_payload["models"][0]["id"] == "gpt-4o-mini"

    info_resp = client.get("/api/model-info/openai/gpt-4o-mini", headers=headers)
    assert info_resp.status_code == 200
    assert info_resp.json()["provider"] == "openai"

    providers_resp = client.get("/api/provider-info", headers=headers)
    assert providers_resp.status_code == 200
    assert any(item["name"] == "openai" for item in providers_resp.json())

    missing_provider = client.get("/api/models/not-a-provider", headers=headers)
    assert missing_provider.status_code == 404

    missing_model = client.get("/api/model-info/openai/not-a-model", headers=headers)
    assert missing_model.status_code == 404


@patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"})
def test_mcp_configure_reset_and_permissions_cover_extra_branches(tmp_path):
    import api.main as api_main
    from api.main import app
    from stratifyai.mcp_client.permissions import ServerPermissionConfig

    config_path = tmp_path / ".cursor" / "mcp.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        json.dumps(
            {
                "mcpServers": {"demo": {"command": "python", "args": ["-m", "demo"]}},
                "stratifyai": {"mcpClient": {"servers": {"demo": {"enabled": True}}}},
            }
        ),
        encoding="utf-8",
    )

    fake_config = SimpleNamespace(
        enabled=True,
        auto_start=True,
        permissions=ServerPermissionConfig(),
    )
    fake_engine = SimpleNamespace(
        _server_index={"demo": fake_config},
        _permission_manager=MagicMock(),
        _server_manager=MagicMock(),
        stop_server=AsyncMock(),
    )
    fake_engine._server_manager.is_running.return_value = True

    original_engine = api_main._mcp_chat_engine
    api_main._mcp_chat_engine = fake_engine

    try:
        client = TestClient(app)
        headers = {"Authorization": "Bearer api-secret"}

        missing_servers = client.post(
            "/api/mcp/configure",
            json={"client": "cursor", "server_ids": []},
            headers=headers,
        )
        assert missing_servers.status_code == 400

        claude_code = client.post(
            "/api/mcp/configure",
            json={
                "client": "claude-code",
                "server_ids": ["filesystem"],
                "arg_values": {"filesystem.paths": str(tmp_path)},
                "project_root": str(tmp_path),
                "apply": True,
            },
            headers=headers,
        )
        assert claude_code.status_code == 200
        claude_payload = claude_code.json()
        assert claude_payload["applied"] is False
        assert claude_payload["commands"]
        assert any(
            "output_path provided" in warning for warning in claude_payload["warnings"]
        )

        permissions_resp = client.put(
            "/api/mcp-client/permissions",
            json={
                "client": "cursor",
                "output_path": str(config_path),
                "servers": {
                    "demo": {
                        "enabled": False,
                        "auto_start": False,
                        "permissions": {
                            "allow": ["read_*"],
                            "confirm": ["delete_*"],
                        },
                    }
                },
            },
            headers=headers,
        )
        assert permissions_resp.status_code == 200
        assert fake_config.enabled is False
        assert fake_config.auto_start is False
        fake_engine._permission_manager.set_policy.assert_called_once()
        fake_engine.stop_server.assert_awaited_once_with("demo")

        reset_resp = client.post(
            "/api/mcp/reset",
            json={"client": "claude-code", "project_root": str(tmp_path)},
            headers=headers,
        )
        assert reset_resp.status_code == 400
        assert "claude mcp remove" in reset_resp.text
    finally:
        api_main._mcp_chat_engine = original_engine


def test_start_mcp_client_server_returns_503_for_runtime_launch_failure():
    from api.main import app

    fake_engine = SimpleNamespace(
        start_server=AsyncMock(
            side_effect=FileNotFoundError(
                "[WinError 2] The system cannot find the file specified"
            )
        )
    )

    client = TestClient(app)
    with (
        patch("api.main.get_mcp_chat_engine", new=AsyncMock(return_value=fake_engine)),
        patch.dict("os.environ", {"STRATIFYAI_API_KEY": "api-secret"}, clear=False),
    ):
        response = client.post(
            "/api/mcp-client/servers/filesystem/start",
            headers={"Authorization": "Bearer api-secret"},
        )

    assert response.status_code == 503
    assert "cannot find the file specified" in response.text.lower()


@patch.dict("os.environ", {}, clear=False)
def test_websocket_stream_with_active_mcp_servers_returns_tool_results():
    import os

    from api.main import app

    os.environ.pop("STRATIFYAI_API_KEY", None)

    tracked = MagicMock()
    tracked.chat_with_mcp = AsyncMock(
        return_value=SimpleNamespace(
            content="MCP-assisted answer",
            raw_response={
                "mcp_warnings": ["demo offline"],
                "mcp_tool_results": [{"namespace": "demo.echo", "ok": True}],
            },
            usage=SimpleNamespace(
                prompt_tokens=8,
                completion_tokens=3,
                total_tokens=11,
                cost_usd=0.0002,
            ),
            latency_ms=18.4,
        )
    )

    client = TestClient(app)
    with (
        patch("api.main.get_tracked_client", return_value=tracked),
        patch("api.main.get_mcp_chat_engine", new=AsyncMock(return_value=object())),
    ):
        with client.websocket_connect("/api/chat/stream") as ws:
            ws.send_text(
                json.dumps(
                    {
                        "provider": "openai",
                        "model": "gpt-4o-mini",
                        "messages": [{"role": "user", "content": "hello"}],
                        "active_mcp_servers": ["demo"],
                    }
                )
            )
            chunk = ws.receive_json()
            final = ws.receive_json()

    assert chunk["content"] == "MCP-assisted answer"
    assert chunk["tool_results"][0]["namespace"] == "demo.echo"
    assert final["done"] is True
    assert final["usage"]["total_tokens"] == 11
    tracked.chat_with_mcp.assert_awaited_once()


@patch.dict("os.environ", {}, clear=False)
def test_websocket_stream_returns_structured_validation_and_token_errors():
    import os

    from api.main import app

    os.environ.pop("STRATIFYAI_API_KEY", None)
    client = TestClient(app)

    fake_request = SimpleNamespace(
        provider="missing-provider",
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        temperature=None,
        max_tokens=None,
        file_content=None,
        file_name=None,
        active_mcp_servers=[],
        chunked=False,
        chunk_size=50000,
        model_dump=lambda: {"provider": "missing-provider", "model": "gpt-4o-mini"},
    )
    with patch(
        "api.main.ChatCompletionRequest.model_validate_json", return_value=fake_request
    ):
        with client.websocket_connect("/api/chat/stream") as ws:
            ws.send_text("{}")
            invalid_provider = ws.receive_json()
    assert invalid_provider["error"] == "invalid_provider"

    with client.websocket_connect("/api/chat/stream") as ws:
        ws.send_text(
            json.dumps(
                {
                    "provider": "openai",
                    "model": "not-a-model",
                    "messages": [{"role": "user", "content": "hello"}],
                }
            )
        )
        invalid_model = ws.receive_json()
    assert invalid_model["error"] == "invalid_model"

    # temperature out-of-range is caught by Pydantic validator → closes with validation_error
    from starlette.websockets import WebSocketDisconnect as WSDisconnect

    captured_validation = {}
    try:
        with client.websocket_connect("/api/chat/stream") as ws:
            ws.send_text(
                json.dumps(
                    {
                        "provider": "openai",
                        "model": "gpt-4o-mini",
                        "temperature": 3.5,
                        "messages": [{"role": "user", "content": "hello"}],
                    }
                )
            )
            captured_validation = ws.receive_json()
    except WSDisconnect:
        pass  # expected: WS closes after sending the error frame
    assert (
        captured_validation.get("error") == "validation_error"
        or captured_validation == {}
    )

    # override the WS-safe guard directly to exercise the custom branch
    bad_temp_request = SimpleNamespace(
        provider="openai",
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        temperature=3.5,
        max_tokens=None,
        file_content=None,
        file_name=None,
        active_mcp_servers=[],
        chunked=False,
        chunk_size=50000,
        model_dump=lambda: {},
    )
    with patch(
        "api.main.ChatCompletionRequest.model_validate_json",
        return_value=bad_temp_request,
    ):
        with client.websocket_connect("/api/chat/stream") as ws:
            ws.send_text("{}")
            ws_temp = ws.receive_json()
    assert ws_temp["error"] == "invalid_temperature"

    with patch(
        "api.main._check_token_limits",
        side_effect=HTTPException(
            status_code=413,
            detail={"error": "input_too_long", "message": "Too many tokens"},
        ),
    ):
        with client.websocket_connect("/api/chat/stream") as ws:
            ws.send_text(
                json.dumps(
                    {
                        "provider": "openai",
                        "model": "gpt-4o-mini",
                        "messages": [{"role": "user", "content": "hello"}],
                    }
                )
            )
            token_limit = ws.receive_json()

    assert token_limit["error"] == "input_too_long"
    assert token_limit["detail"] == "Too many tokens"
