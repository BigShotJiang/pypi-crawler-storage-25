"""Vector database integration for RAG and semantic search.

This module provides abstraction for storing and retrieving document embeddings
using ChromaDB (with potential support for other vector databases).
"""

import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, cast

try:
    import chromadb
    from chromadb.config import Settings

    CHROMADB_AVAILABLE = True
except ImportError:
    CHROMADB_AVAILABLE = False
    chromadb = None
    Settings = None

from .embeddings import EmbeddingProvider
from .exceptions import LLMAbstractionError
from .utils.sync_helpers import run_sync


@dataclass
class SearchResult:
    """Result from a semantic search query.

    Attributes:
        document: The matched document text
        metadata: Document metadata (file, chunk_idx, etc.)
        distance: Distance score (lower = more similar)
        doc_id: Unique document ID
    """

    document: str
    metadata: dict[str, Any]
    distance: float
    doc_id: str


class VectorDBClient:
    """Client for vector database operations using ChromaDB.

    Provides document storage, retrieval, and semantic search capabilities.
    """

    def __init__(
        self,
        embedding_provider: EmbeddingProvider,
        persist_directory: str | None = None,
    ):
        """Initialize vector database client.

        Args:
            embedding_provider: Provider for generating embeddings
            persist_directory: Directory to persist database (default: ./chroma_db)

        Raises:
            LLMAbstractionError: If ChromaDB is not installed
        """
        if not CHROMADB_AVAILABLE:
            raise LLMAbstractionError(
                "ChromaDB is not installed. Install with: pip install chromadb"
            )

        self.embedding_provider = embedding_provider
        self.persist_directory = persist_directory or "./chroma_db"

        # Initialize ChromaDB client
        if Settings is not None:
            self.client = chromadb.PersistentClient(
                path=self.persist_directory,
                settings=Settings(anonymized_telemetry=False),
            )
        else:
            self.client = chromadb.PersistentClient(path=self.persist_directory)

    def create_collection(
        self, name: str, metadata: dict[str, Any] | None = None
    ) -> str:
        """Create a new collection.

        Args:
            name: Collection name
            metadata: Optional collection metadata

        Returns:
            Collection name

        Raises:
            LLMAbstractionError: If collection already exists
        """
        try:
            self.client.create_collection(name=name, metadata=metadata or {})
            return name
        except Exception as e:
            if "already exists" in str(e).lower():
                raise LLMAbstractionError(
                    f"Collection '{name}' already exists. Use get_collection() or delete it first."
                ) from e
            raise LLMAbstractionError(f"Failed to create collection: {str(e)}") from e

    def get_collection(self, name: str):
        """Get an existing collection.

        Args:
            name: Collection name

        Returns:
            ChromaDB collection object

        Raises:
            LLMAbstractionError: If collection doesn't exist
        """
        try:
            return self.client.get_collection(name=name)
        except Exception as e:
            raise LLMAbstractionError(
                f"Collection '{name}' not found. Create it with create_collection()."
            ) from e

    def get_or_create_collection(self, name: str):
        """Get existing collection or create if it doesn't exist.

        Args:
            name: Collection name

        Returns:
            ChromaDB collection object
        """
        return self.client.get_or_create_collection(name=name)

    def list_collections(self) -> list[str]:
        """List all collections.

        Returns:
            List of collection names
        """
        collections = self.client.list_collections()
        return [col.name for col in collections]

    def delete_collection(self, name: str) -> None:
        """Delete a collection.

        Args:
            name: Collection name
        """
        try:
            self.client.delete_collection(name=name)
        except Exception as e:
            raise LLMAbstractionError(f"Failed to delete collection: {str(e)}") from e

    async def add_documents(
        self,
        collection_name: str,
        documents: list[str],
        metadatas: list[dict[str, Any]] | None = None,
        ids: list[str] | None = None,
    ) -> list[str]:
        """Add documents to a collection.

        Args:
            collection_name: Collection name
            documents: List of document texts
            metadatas: Optional list of metadata dicts (one per document)
            ids: Optional list of document IDs (generated if not provided)

        Returns:
            List of document IDs
        """
        if not documents:
            return []

        # Get or create collection
        collection = self.get_or_create_collection(collection_name)

        # Generate IDs if not provided
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in documents]

        # Add timestamp to metadata
        if metadatas is None:
            metadatas = [{} for _ in documents]

        for metadata in metadatas:
            if "timestamp" not in metadata:
                metadata["timestamp"] = datetime.now().isoformat()

        # Generate embeddings
        embedding_result = await self.embedding_provider.generate_embeddings(documents)

        # Add to collection
        collection.add(
            documents=documents,
            embeddings=embedding_result.embeddings,
            metadatas=metadatas,
            ids=ids,
        )

        return ids

    async def query(
        self,
        collection_name: str,
        query_text: str,
        n_results: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        """Query collection with semantic search.

        Args:
            collection_name: Collection name
            query_text: Query text
            n_results: Number of results to return (default: 5)
            where: Optional metadata filter

        Returns:
            List of SearchResult objects
        """
        collection = self.get_collection(collection_name)

        # Generate query embedding
        query_embedding = await self.embedding_provider.generate_embedding(query_text)

        # Query collection
        results = cast(
            dict[str, Any],
            collection.query(
                query_embeddings=[query_embedding], n_results=n_results, where=where
            ),
        )

        # Parse results
        search_results = []
        if results["documents"] and results["documents"][0]:
            for i in range(len(results["documents"][0])):
                search_results.append(
                    SearchResult(
                        document=results["documents"][0][i],
                        metadata=results["metadatas"][0][i]
                        if results["metadatas"]
                        else {},
                        distance=results["distances"][0][i]
                        if results["distances"]
                        else 0.0,
                        doc_id=results["ids"][0][i],
                    )
                )

        return search_results

    def get_collection_count(self, collection_name: str) -> int:
        """Get the number of documents in a collection.

        Args:
            collection_name: Collection name

        Returns:
            Number of documents
        """
        collection = self.get_collection(collection_name)
        return int(collection.count())

    def delete_documents(self, collection_name: str, ids: list[str]) -> None:
        """Delete documents from a collection by ID.

        Args:
            collection_name: Collection name
            ids: List of document IDs to delete
        """
        collection = self.get_collection(collection_name)
        collection.delete(ids=ids)

    async def update_documents(
        self,
        collection_name: str,
        ids: list[str],
        documents: list[str] | None = None,
        metadatas: list[dict[str, Any]] | None = None,
    ) -> None:
        """Update documents in a collection.

        Args:
            collection_name: Collection name
            ids: List of document IDs to update
            documents: Optional new document texts
            metadatas: Optional new metadatas
        """
        collection = self.get_collection(collection_name)

        update_kwargs: dict[str, Any] = {"ids": ids}

        if documents is not None:
            # Generate new embeddings
            embedding_result = await self.embedding_provider.generate_embeddings(
                documents
            )
            update_kwargs["documents"] = documents
            update_kwargs["embeddings"] = embedding_result.embeddings

        if metadatas is not None:
            update_kwargs["metadatas"] = metadatas

        collection.update(**update_kwargs)

    def update_documents_sync(
        self,
        collection_name: str,
        ids: list[str],
        documents: list[str] | None = None,
        metadatas: list[dict[str, Any]] | None = None,
    ) -> None:
        """Synchronous wrapper for update_documents()."""
        run_sync(
            self.update_documents(
                collection_name=collection_name,
                ids=ids,
                documents=documents,
                metadatas=metadatas,
            )
        )

    def add_documents_sync(
        self,
        collection_name: str,
        documents: list[str],
        metadatas: list[dict[str, Any]] | None = None,
        ids: list[str] | None = None,
    ) -> list[str]:
        """Synchronous wrapper for add_documents()."""
        return cast(
            list[str],
            run_sync(
                self.add_documents(
                    collection_name=collection_name,
                    documents=documents,
                    metadatas=metadatas,
                    ids=ids,
                )
            ),
        )

    def query_sync(
        self,
        collection_name: str,
        query_text: str,
        n_results: int = 5,
        where: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        """Synchronous wrapper for query()."""
        return cast(
            list[SearchResult],
            run_sync(
                self.query(
                    collection_name=collection_name,
                    query_text=query_text,
                    n_results=n_results,
                    where=where,
                )
            ),
        )

    def get_documents(
        self,
        collection_name: str,
        ids: list[str] | None = None,
        where: dict[str, Any] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Retrieve documents from a collection.

        Args:
            collection_name: Collection name
            ids: Optional list of document IDs to retrieve
            where: Optional metadata filter
            limit: Maximum number of documents to return

        Returns:
            List of documents with metadata
        """
        collection = self.get_collection(collection_name)

        get_kwargs: dict[str, Any] = {}
        if ids is not None:
            get_kwargs["ids"] = ids
        if where is not None:
            get_kwargs["where"] = where
        if limit is not None:
            get_kwargs["limit"] = limit

        results = cast(dict[str, Any], collection.get(**get_kwargs))

        # Format results
        documents = []
        if results["documents"]:
            for i in range(len(results["documents"])):
                documents.append(
                    {
                        "id": results["ids"][i],
                        "document": results["documents"][i],
                        "metadata": results["metadatas"][i]
                        if results["metadatas"]
                        else {},
                    }
                )

        return documents
