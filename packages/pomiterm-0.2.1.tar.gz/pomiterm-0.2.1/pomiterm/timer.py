import sys
import time
import threading
import subprocess
import cowsay
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TextColumn
from rich.columns import Columns
from rich.console import Group
from rich.align import Align

_MACOS_SOUNDS = {
    "focus": "Glass",
    "short_break": "Ping",
    "long_break": "Hero",
}

_WINDOWS_SOUNDS = {
    "focus": 0x00000030,
    "short_break": 0x00000000,
    "long_break": 0x00000010,
}

def _play_sound(sound):
    if sys.platform == "darwin":
        name = _MACOS_SOUNDS.get(sound, "Glass")
        subprocess.run(["afplay", f"/System/Library/Sounds/{name}.aiff"], check=False)
    elif sys.platform == "win32":
        import winsound
        winsound.MessageBeep(_WINDOWS_SOUNDS.get(sound, winsound.MB_OK))
    else:
        print("\a", end="", flush=True)


def _listen_for_key(stop_event, result):
    if sys.platform == "win32":
        import msvcrt
        while not stop_event.is_set():
            if msvcrt.kbhit():
                key = msvcrt.getch().decode("utf-8", errors="ignore").lower()
                if key in ("c", "\x03"):
                    result["action"] = "cancel"
                    stop_event.set()
                elif key == "s":
                    result["action"] = "skip"
                    stop_event.set()
            time.sleep(0.05)
    else:
        import tty
        import termios
        import select
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            while not stop_event.is_set():
                if select.select([sys.stdin], [], [], 0.05)[0]:
                    key = sys.stdin.read(1).lower()
                    if key in ("c", "\x03"):
                        result["action"] = "cancel"
                        stop_event.set()
                    elif key == "s":
                        result["action"] = "skip"
                        stop_event.set()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def countdown(seconds, live, timerName, sound="focus"):
    total = seconds
    result = {"action": "done"}
    stop_event = threading.Event()

    key_thread = threading.Thread(target=_listen_for_key, args=(stop_event, result), daemon=True)
    key_thread.start()

    ascii_art = cowsay.get_output_string("cow", "Focus time!")
    progress = Progress(TextColumn("[bold red]{task.fields[countdown]}"), BarColumn())
    task = progress.add_task("", total=total, countdown="")
    hints = "[dim](s) skip  (c) cancel[/dim]"

    while seconds > 0 and not stop_event.is_set():
        mins, secs = divmod(seconds, 60)
        progress.update(task, completed=total - seconds, countdown=f"{mins:02d}:{secs:02d}")
        live.update(Panel(Group(
            Columns([f"[bold white]{timerName}[/bold white]", progress, hints]),
            Align.left(ascii_art),
        )))
        time.sleep(1)
        seconds -= 1

    stop_event.set()
    key_thread.join(timeout=0.5)

    if result["action"] == "done":
        live.update(Panel("[bold green]Done![/bold green]"))
        _play_sound(sound)

    return result["action"]