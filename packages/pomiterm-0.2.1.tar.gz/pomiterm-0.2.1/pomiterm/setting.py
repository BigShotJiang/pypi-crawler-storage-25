import json
import questionary
from pathlib import Path
from rich.console import Console
from rich.table import Table

console = Console()

_CONFIG_PATH = Path.home() / ".config" / "pomiterm" / "settings.json"

_DEFAULTS = {
    "work_minutes": 25,
    "short_break": 5,
    "long_break": 15,
    "cycles": 4,
    "sound": True,
}

def _load() -> dict:
    if _CONFIG_PATH.exists():
        try:
            saved = json.loads(_CONFIG_PATH.read_text())
            return {**_DEFAULTS, **saved}
        except (json.JSONDecodeError, OSError):
            pass
    return dict(_DEFAULTS)

def _save(s: dict) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(s, indent=2))

settings = _load()

def show_settings():
    table = Table(title="Current Settings")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="yellow")
    for key, value in settings.items():
        table.add_row(key, str(value))
    console.print(table)

def edit_settings():
    show_settings()

    key = questionary.select(
        "Which setting to change?",
        choices=[*settings.keys(), "Reset to defaults", "Back"]
    ).ask()

    if key == "Back":
        return

    if key == "Reset to defaults":
        settings.update(_DEFAULTS)
        _save(settings)
        console.print("[green]✓ Settings reset to defaults[/green]")
        return

    if isinstance(settings[key], bool):
        settings[key] = questionary.confirm(f"{key}?").ask()
    else:
        new_val = questionary.text(
            f"New value for {key} (current: {settings[key]}):"
        ).ask()
        settings[key] = int(new_val)

    _save(settings)
    console.print(f"[green]✓ {key} updated to {settings[key]}[/green]")