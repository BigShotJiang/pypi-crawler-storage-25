from rich.panel import Panel
from rich.console import Console
from rich.live import Live
from datetime import datetime
from importlib.metadata import version
import sys
import questionary
import random
import urllib.request
import json
import subprocess
import os

from pomiterm import setting, timer


def check_for_update(current_version: str) -> str | None:
    try:
        with urllib.request.urlopen("https://pypi.org/pypi/pomiterm/json", timeout=2) as resp:
            data = json.loads(resp.read())
            latest = data["info"]["version"]
            if tuple(int(x) for x in latest.split(".")) > tuple(int(x) for x in current_version.split(".")):
                return latest
    except Exception:
        pass
    return None


def clear_screen():
    print("\033[H\033[2J\033[3J", end="", flush=True)


def main():
    while True:
        console = Console()
        now = datetime.now()

        settings = setting.settings

        quotes = [
            # Success
            "The secret of getting ahead is getting started.",
            "It always seems impossible until it's done.",
            "Don't watch the clock; do what it does. Keep going.",
            "Success is the sum of small efforts, repeated day in and day out.",
            "The only way to do great work is to love what you do.",
            "Focus on being productive instead of busy.",
            "Action is the foundational key to all success.",
            # Wisdom
            "The unexamined life is not worth living.",
            "In the middle of difficulty lies opportunity.",
            "He who has a why can endure any how.",
            "The quieter you become, the more you can hear.",
            "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.",
            "Knowing yourself is the beginning of all wisdom.",
            "The more I learn, the more I realize how much I don't know.",
            # Silly
            "I told my computer I needed a break. Now it won't stop sending me Kit-Kat ads.",
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "A tomato timer walks into a bar. The bartender says: 'You look ripe for a break.'",
            "My code doesn't have bugs. It has unexpected features.",
            "I'm on a seafood diet. I see food, I eat it — then I get back to work.",
            "The brain is a wonderful organ. It starts working the moment you get up and doesn't stop until you open a meeting invite.",
            "Work hard in silence. Let your commits speak.",
        ]

        current_version = version('pomiterm')
        latest_version = check_for_update(current_version)

        clear_screen()
        console.print("[bold red]🍅 PomiTerm[/bold red]")
        console.print(f"[bold yellow]V {current_version}[/bold yellow]")
        if latest_version:
            console.print(f"[bold cyan]New version available: {latest_version}[/bold cyan]")
        console.print("[bold dim]Small minimal Pomidoro timer running in your terminal.[/bold dim]")

        console.print(Panel(f'[bold white] {now.strftime("%H:%M - %A %m %Y")} [/bold white]\n[italic dim]"{random.choice(quotes)}"[/italic dim]'))

        choices = ["Start", "Settings"]
        if latest_version:
            choices.append(f"Update to {latest_version}")
        choices.append("Quit")

        choice = questionary.select(
            "Choose an option:",
            choices=choices
        ).ask()

        clear_screen()

        if choice == "Start":
            sessions = [
                ("Focus Time", "work_minutes", "focus"),
                ("Short Break", "short_break", "short_break"),
                ("Long Break", "long_break", "long_break"),
            ]
            cancelled = False
            cycle = 0
            with Live(refresh_per_second=2, transient=False) as live:
                while cycle < settings["cycles"] and not cancelled:
                    for name, key, sound in sessions:
                        action = timer.countdown(settings[key] * 60, live, timerName=name, sound=sound)
                        if action == "cancel":
                            cancelled = True
                            break
                    cycle += 1
        elif choice and choice.startswith("Update to"):
            console.print("[bold cyan]Updating PomiTerm...[/bold cyan]")
            result = subprocess.run(["pipx", "upgrade", "pomiterm"], cwd=os.path.expanduser("~"))
            if result.returncode == 0:
                console.print("[bold green]Update complete! Please restart PomiTerm.[/bold green]")
            else:
                console.print("[bold red]Update failed. Try running `pipx upgrade pomiterm` manually.[/bold red]")
            sys.exit()
        elif choice == "Quit":
            console.print("[dim]Goodbye![/dim]")
            sys.exit()
        elif choice == "Settings":
            setting.edit_settings()
