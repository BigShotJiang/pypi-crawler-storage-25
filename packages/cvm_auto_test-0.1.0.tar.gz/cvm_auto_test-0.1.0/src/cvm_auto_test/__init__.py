# -*- coding: utf-8 -*-
"""
CVM 自动化测试 MCP 工具

提供两个工具：
1. automation_test - 通过 Dify 工作流发起性能测试
2. get_test_status - 通过 Dify 工作流查询测试状态
"""
import os
import logging
import requests
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 从环境变量获取配置
DIFY_BASE_URL = os.environ.get("DIFY_BASE_URL", "")
AUTOMATION_TEST_API_KEY = os.environ.get("AUTOMATION_TEST_API_KEY", "")
GET_STATUS_API_KEY = os.environ.get("GET_STATUS_API_KEY", "")

mcp = FastMCP("cvm-auto-test")


def _call_dify_workflow(api_key: str, inputs: dict, key_name: str, user_id: str = "mcp_user") -> str:
    """调用 Dify 工作流的通用函数"""
    if not api_key:
        return f"❌ 错误：{key_name} 未配置，请在 mcp.json 的 env 中设置"

    url = f"{DIFY_BASE_URL}/workflows/run"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "inputs": inputs,
        "response_mode": "blocking",
        "user": user_id,
    }

    try:
        logger.info(f"调用 Dify 工作流: inputs={inputs}")
        response = requests.post(url, headers=headers, json=payload, timeout=1000)

        if response.status_code != 200:
            return f"❌ 工作流调用失败 ({response.status_code}): {response.text[:300]}"

        result = response.json()
        outputs = result.get("data", {}).get("outputs", {})
        # 优先返回 result 字段，其次 status 字段，最后返回整个 outputs
        return outputs.get("result", outputs.get("status", str(outputs)))

    except requests.exceptions.Timeout:
        return "❌ 工作流执行超时，请稍后重试"
    except requests.exceptions.RequestException as e:
        return f"❌ 网络请求失败: {str(e)}"
    except Exception as e:
        return f"❌ 工作流执行失败: {str(e)}"


@mcp.tool()
def automation_test(lan: str) -> str:
    """CVM 自动化性能测试工具。
    对云服务器发起自动化性能测试任务，通过调用云驭（Yunyu）平台的测试流水线，自动执行全套性能基准测试。

    功能说明:
    - 支持多云厂商：腾讯云(qcloud)、阿里云(aliyun)、华为云(huaweiyun)、火山引擎(volcengine)、AWS、Azure、GCP
    - 自动执行完整性能测试套件，包括：CPU(super_pi/linpack/vray/openssl)、内存(mlc/lmbench/stream)、
      系统(unixbench/contextswitch/compress)、网络(redis)、综合(speccpu/specjbb)等 28 项测试用例
    - 支持单机测试和批量多机测试
    - 测试完成后返回 plan_id 和 report_id，可用于后续查询测试结果

    lan 输入要求（自然语言描述，至少需要包含以下信息）:
    - **target_ip** (必须): 待测试机器的公网 IP 地址
    - **vendor** (必须): 云厂商标识，如 qcloud/aliyun/huaweiyun/volcengine/aws/azure/gcp
    - **Instance_Type** (必须): 完整机型名称，如 SA9e.2XLARGE32、ecs.g9ae.xlarge、c7g.16xlarge
    - **machine_id** (推荐): 机器实例 ID，如 ins-xxx、i-bp1xxx
    - **region** (推荐): 机器所在地域，如 ap-guangzhou、cn-hangzhou、us-east-1

    以下字段有默认值，不指定时自动填充:
    - password: 默认使用环境变量中配置的密码
    - os_user: 默认 root（Azure 默认 azureuser）
    - sold_type: 自动从 Instance_Type 提取（腾讯云取第一个.前面部分，其他厂商用完整名）
    - admin_user: 默认从环境变量读取
    - product_name: 默认 CVM
    - controller_group: 腾讯云自动设为 idc-whitelist，其他厂商为空

    使用场景:
    - 购买机器后对新实例发起性能基准测试
    - 对比不同机型/厂商的性能表现
    - 批量对多台机器发起测试

    返回结果:
    - 包含每台机器的 vendor、Instance_Type、target_ip、machine_id、region、plan_id、report_id、status
    - status 为 "✅ 发起成功" 或 "❌ 失败: <错误原因>"

    Args:
        lan: 自然语言描述的测试需求。

    示例输入:
    - "请对腾讯云机型 SA9e.2XLARGE32、IP 129.204.42.34、machine_id ins-5781ikg8、region ap-guangzhou 发起测试"
    - "请对阿里云 ecs.g9ae.xlarge 47.111.12.12 i-bp1c570uzt17llc8rtm7 cn-hangzhou 发起测试"
    - "请对 GCP n4d-standard-16 34.68.142.144 2560593100463912663 us-central1 发起测试"
    - "请对以下机器发起测试：腾讯云 SA9.2XLARGE16 129.204.42.34 ins-5781ikg8 ap-guangzhou、阿里云 ecs.g9ae.xlarge 47.111.12.12 i-bp1xxx cn-hangzhou"
    """
    logger.info(f"[automation_test] 收到测试请求: {lan[:100]}...")
    result = _call_dify_workflow(AUTOMATION_TEST_API_KEY, {"lan": lan}, "AUTOMATION_TEST_API_KEY")
    logger.info("[automation_test] 测试执行完成")
    return result


@mcp.tool()
def get_test_status(plan_id: str, report_id: str) -> str:
    """查询云驭性能测试任务状态。
    通过 plan_id 和 report_id 查询已发起的性能测试任务的当前执行状态。

    返回值为数字状态码，含义如下：

    | 状态码 | 含义 |
    |--------|------|
    | 4 | 执行成功 |
    | 3 | 执行中 |
    | 其他值 | 未执行/异常 |

    使用场景:
    - 发起测试后轮询查询任务是否完成
    - 检查测试任务的最终状态（成功/失败/超时等）
    - 批量查询多个测试任务的状态

    Args:
        plan_id: 测试计划 ID，发起测试时返回的 plan_id
        report_id: 测试报告 ID，发起测试时返回的 report_id

    示例输入:
    - plan_id="10000006099", report_id="10000012797"
    """
    logger.info(f"[get_test_status] 查询状态: plan_id={plan_id}, report_id={report_id}")
    result = _call_dify_workflow(
        GET_STATUS_API_KEY,
        {"plan_id": str(plan_id).strip(), "report_id": str(report_id).strip()},
        "GET_STATUS_API_KEY",
    )
    logger.info(f"[get_test_status] 查询完成: {result}")
    return result


def main():
    mcp.run()


if __name__ == "__main__":
    main()
