"""Shadow A/B runner. Runs two manifests on the same production input; only A is shown."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from cambium.core.types import BehavioralEvent, IdentityProfile, Manifest
from cambium.evals.metrics import iou

if TYPE_CHECKING:
    from cambium.service import CambiumService


@dataclass
class ShadowRecord:
    event_id: str
    score_a: float
    score_b: float
    dimensions_a: tuple[str, ...]
    dimensions_b: tuple[str, ...]


@dataclass
class ShadowSummary:
    n: int
    mean_abs_delta: float
    direction_agreement_rate: float
    mean_dim_iou: float


class ShadowRunner:
    """Run two manifests in parallel; record the comparison."""

    def __init__(
        self,
        *,
        service: "CambiumService",
        domain: str,
        manifest_a: Manifest,
        manifest_b: Manifest,
        claude_client: Any | None = None,
    ) -> None:
        self.service = service
        self.domain = domain
        self.manifest_a = manifest_a
        self.manifest_b = manifest_b
        self.claude_client = claude_client
        self.records: list[ShadowRecord] = []

    def observe(self, identity: IdentityProfile, event: BehavioralEvent) -> ShadowRecord:
        from cambium.core.spine import Spine

        spine_a = Spine(
            domain=self.domain, service=self.service,
            manifest=self.manifest_a, claude_client=self.claude_client,
        )
        spine_b = Spine(
            domain=self.domain, service=self.service,
            manifest=self.manifest_b, claude_client=self.claude_client,
        )
        score_a = spine_a.process_event(identity=identity, event=event)
        score_b = spine_b.process_event(identity=identity, event=event)
        record = ShadowRecord(
            event_id=event.event_id,
            score_a=score_a.score,
            score_b=score_b.score,
            dimensions_a=score_a.dimensions_cited,
            dimensions_b=score_b.dimensions_cited,
        )
        self.records.append(record)
        return record

    def summary(self) -> ShadowSummary:
        if not self.records:
            return ShadowSummary(0, 0.0, 0.0, 0.0)
        n = len(self.records)
        mean_abs_delta = sum(abs(r.score_a - r.score_b) for r in self.records) / n
        directions = sum(
            1
            for r in self.records
            if (r.score_a >= 0 and r.score_b >= 0) or (r.score_a < 0 and r.score_b < 0)
        )
        ious = [iou(list(r.dimensions_a), list(r.dimensions_b)) for r in self.records]
        return ShadowSummary(
            n=n,
            mean_abs_delta=mean_abs_delta,
            direction_agreement_rate=directions / n,
            mean_dim_iou=sum(ious) / n,
        )


__all__ = ["ShadowRecord", "ShadowRunner", "ShadowSummary"]
