"""Shadow A/B harness + paired statistics."""

from cambium.ab.shadow import ShadowRecord, ShadowRunner, ShadowSummary  # noqa: F401
from cambium.ab.stats import (  # noqa: F401
    PairedTestResult,
    mcnemar_test,
    paired_t_test,
    wilcoxon_signed_rank,
)

__all__ = [
    "PairedTestResult",
    "ShadowRecord",
    "ShadowRunner",
    "ShadowSummary",
    "mcnemar_test",
    "paired_t_test",
    "wilcoxon_signed_rank",
]
