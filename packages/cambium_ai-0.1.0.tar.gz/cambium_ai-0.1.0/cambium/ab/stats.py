"""Paired statistics — pure Python, no scipy.

- paired t-test (two-tailed)
- Wilcoxon signed-rank (approximate p)
- McNemar's test (mid-p variant)

The p-values are approximations sufficient for shadow A/B decisions.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class PairedTestResult:
    statistic: float
    p_value_approx: float
    n: int


def paired_t_test(a: Sequence[float], b: Sequence[float]) -> PairedTestResult:
    """Two-tailed paired t-test (normal approximation for the p)."""
    n = len(a)
    if n != len(b) or n < 2:
        return PairedTestResult(0.0, 1.0, n)
    diffs = [ai - bi for ai, bi in zip(a, b)]
    mean = sum(diffs) / n
    var = sum((d - mean) ** 2 for d in diffs) / (n - 1)
    if var <= 0:
        return PairedTestResult(0.0, 1.0, n)
    se = math.sqrt(var / n)
    t = mean / se
    # Normal-approximation two-tailed p
    p = 2 * (1 - _phi(abs(t)))
    return PairedTestResult(statistic=t, p_value_approx=p, n=n)


def wilcoxon_signed_rank(a: Sequence[float], b: Sequence[float]) -> PairedTestResult:
    """Wilcoxon signed-rank with normal approximation."""
    n = len(a)
    if n != len(b) or n == 0:
        return PairedTestResult(0.0, 1.0, n)
    diffs = [(i, ai - bi) for i, (ai, bi) in enumerate(zip(a, b)) if ai != bi]
    if not diffs:
        return PairedTestResult(0.0, 1.0, n)
    abs_diffs = sorted(diffs, key=lambda kv: abs(kv[1]))
    ranks = [i + 1 for i, _ in enumerate(abs_diffs)]
    w_plus = sum(r for r, (_, d) in zip(ranks, abs_diffs) if d > 0)
    n_eff = len(abs_diffs)
    mean_w = n_eff * (n_eff + 1) / 4
    sd_w = math.sqrt(n_eff * (n_eff + 1) * (2 * n_eff + 1) / 24)
    if sd_w == 0:
        return PairedTestResult(0.0, 1.0, n_eff)
    z = (w_plus - mean_w) / sd_w
    p = 2 * (1 - _phi(abs(z)))
    return PairedTestResult(statistic=z, p_value_approx=p, n=n_eff)


def mcnemar_test(b: int, c: int) -> PairedTestResult:
    """McNemar's test on a 2x2 paired contingency. b/c are the discordant cells."""
    n_disc = b + c
    if n_disc == 0:
        return PairedTestResult(0.0, 1.0, 0)
    chi2 = (abs(b - c) - 1) ** 2 / n_disc
    # Chi-square 1 df ≈ standard normal squared; p = 1 - F(sqrt(chi2))^2
    p = 2 * (1 - _phi(math.sqrt(chi2)))
    return PairedTestResult(statistic=chi2, p_value_approx=p, n=n_disc)


def _phi(z: float) -> float:
    """Standard-normal CDF using erf."""
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


__all__ = ["PairedTestResult", "mcnemar_test", "paired_t_test", "wilcoxon_signed_rank"]
