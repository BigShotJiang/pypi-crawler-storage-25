"""GroveAdapter — wraps Cambium as a Grove worker.

In production, Grove's ``celery_worker.py`` registers
``register_cambium_celery_tasks(celery_app)`` which exposes
``cambium.process_event`` and ``cambium.synthesize_window`` as Celery
tasks. This adapter is the Python-side glue.

The adapter holds no state beyond what Cambium's service holds. Grove
provides Celery's task identity (task_id, queue, retry policy).
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

from cambium.core.types import BehavioralEvent, CoherenceScore, IdentityProfile

if TYPE_CHECKING:
    from cambium.grove.bus import EventBus
    from cambium.service import CambiumService


class GroveAdapter:
    """Wraps cambium so it can be invoked from Celery tasks."""

    def __init__(
        self,
        *,
        domain: str,
        service: "CambiumService" | None = None,
        event_bus: "EventBus" | None = None,
    ) -> None:
        from cambium.grove.bus import InMemoryEventBus
        from cambium.service import get_default_service

        self.domain = domain
        self.service = service or get_default_service()
        self.event_bus = event_bus or InMemoryEventBus()

    def process_event(
        self, identity_payload: dict[str, Any], event_payload: dict[str, Any]
    ) -> dict[str, Any]:
        from cambium.core.spine import Spine

        spine = Spine(domain=self.domain, service=self.service)
        identity = IdentityProfile.model_validate(identity_payload)
        event = BehavioralEvent.model_validate(event_payload)
        score = spine.process_event(identity=identity, event=event)
        self._maybe_publish_low_confidence(score)
        return score.model_dump(mode="json")

    def synthesize_window(
        self,
        identity_payload: dict[str, Any],
        scores_payload: list[dict[str, Any]],
        events_payload: list[dict[str, Any]],
        window_start: str,
        window_end: str,
    ) -> dict[str, Any]:
        from cambium.a2ui.renderers import render_insight
        from cambium.core.spine import Spine

        spine = Spine(domain=self.domain, service=self.service)
        identity = IdentityProfile.model_validate(identity_payload)
        scores = [CoherenceScore.model_validate(s) for s in scores_payload]
        events = [BehavioralEvent.model_validate(e) for e in events_payload]
        insight, cert = spine.synthesize_window(
            identity=identity,
            scores=scores,
            events=events,
            window_start=datetime.fromisoformat(window_start),
            window_end=datetime.fromisoformat(window_end),
        )
        a2ui_doc = render_insight(insight=insight, certificate=cert, scores=scores)
        self.event_bus.publish(
            "cambium.weekly_insight_ready",
            {
                "event_type": "cambium.weekly_insight_ready",
                "event_id": insight.insight_id,
                "occurred_at": insight.composed_at.isoformat(),
                "domain": self.domain,
                "manifest_hash": cert.manifest_hash,
                "user_id_hash": insight.user_id_hash,
                "insight_id": insight.insight_id,
                "a2ui_directive_ref": a2ui_doc.directive_id,
                "certificate_id": cert.certificate_id,
            },
        )
        return {
            "insight": insight.model_dump(mode="json"),
            "certificate": cert.model_dump(mode="json"),
            "a2ui_directive": a2ui_doc.model_dump(mode="json"),
        }

    def _maybe_publish_low_confidence(self, score: CoherenceScore) -> None:
        if score.confidence >= 0.6:
            return
        self.event_bus.publish(
            "cambium.low_confidence_classification",
            {
                "event_type": "cambium.low_confidence_classification",
                "event_id": score.event_id,
                "domain": self.domain,
                "manifest_hash": self.service.get_active_manifest(self.domain).content_hash(),
                "user_id_hash": score.user_id_hash,
                "event_id_classifier_input": score.event_id,
                "semantic_category": "",
                "confidence": score.confidence,
                "confidence_band": "low",
            },
        )


__all__ = ["GroveAdapter"]
