"""Cross-domain handoff helpers."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class HandoffContext(BaseModel):
    """Context payload Grove passes to a target domain's spine."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    source_domain: str
    target_domain: str
    user_id_hash: str
    reason: str
    relevant_events: list[dict[str, Any]] = Field(default_factory=list)
    relevant_scores: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


def build_handoff_context(
    *,
    source_domain: str,
    target_domain: str,
    user_id_hash: str,
    reason: str,
    relevant_events: list[Any] | None = None,
    relevant_scores: list[Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> HandoffContext:
    return HandoffContext(
        source_domain=source_domain,
        target_domain=target_domain,
        user_id_hash=user_id_hash,
        reason=reason,
        relevant_events=[
            e.model_dump(mode="json") if hasattr(e, "model_dump") else dict(e)
            for e in (relevant_events or [])
        ],
        relevant_scores=[
            s.model_dump(mode="json") if hasattr(s, "model_dump") else dict(s)
            for s in (relevant_scores or [])
        ],
        metadata=metadata or {},
    )


__all__ = ["HandoffContext", "build_handoff_context"]
