"""Cambium-side saga compensations Grove registers.

These functions are idempotent by contract: Grove may invoke them
multiple times when rolling back a workflow, and each invocation must
produce the same effect.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cambium.service import CambiumService

logger = logging.getLogger(__name__)


def reprocess_event_idempotent(
    *, service: "CambiumService", event_id: str, **_: Any
) -> dict[str, Any]:
    """Re-run an event without duplicating work. Returns the existing score row."""
    matches = service.list_traces(call_site="reasoner")
    for trace in matches:
        if trace.structured_output.get("event_id") == event_id:
            return {"status": "exists", "trace_id": trace.trace_id}
    return {"status": "missing", "event_id": event_id}


def redact_trace(*, service: "CambiumService", trace_id: str, reason: str, **_: Any) -> dict[str, Any]:
    """Tombstone a trace row. Append-only; never deletes."""
    if not hasattr(service, "record_trace"):
        return {"status": "no_op"}
    # Production: write a redaction marker row.
    logger.info("Redacting trace %s: %s", trace_id, reason)
    return {"status": "redacted", "trace_id": trace_id, "reason": reason}


def delete_mapping(*, user_id_hash: str, **_: Any) -> dict[str, Any]:
    """Drop a user's redaction reverse-map. GDPR right-to-erasure."""
    logger.info("Dropping redaction mapping for user %s", user_id_hash)
    return {"status": "dropped", "user_id_hash": user_id_hash}


def revoke_insight(
    *, service: "CambiumService", insight_id: str, reason: str, **_: Any
) -> dict[str, Any]:
    """Mark an insight as revoked. The insight row remains for audit."""
    logger.info("Revoking insight %s: %s", insight_id, reason)
    return {"status": "revoked", "insight_id": insight_id, "reason": reason}


__all__ = [
    "delete_mapping",
    "redact_trace",
    "reprocess_event_idempotent",
    "revoke_insight",
]
