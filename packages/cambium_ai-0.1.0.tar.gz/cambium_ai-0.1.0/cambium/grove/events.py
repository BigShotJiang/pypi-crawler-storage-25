"""Typed events Cambium emits, which Grove subscribes to.

Every event carries the manifest_hash that produced it so a Grove
workflow can hold downstream actions against a specific manifest
version. All events are frozen Pydantic models — they cross the
audit boundary and end up in Grove's Redis pub/sub channels.

Channel naming (mirrors Grove's existing convention):
    cambium.<event_type_suffix>

For Grove to receive these, the Grove repo wires a
``RedisPubSubSubscriber`` against ``cambium.*`` channels and dispatches
to handlers registered with the ``RegistryDomain.CAMBIUM_WORKER``
namespace. See the Grove repo's
``grove/domains/events/cambium.py`` for the receiving side; this
file is the canonical *shape*.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class CambiumEvent(BaseModel):
    """Base class for every typed Cambium event.

    Subclasses set ``event_type`` to a stable string. Grove uses
    ``event_type`` as the routing key into the Redis channel
    ``cambium.<event_type>``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_type: str
    event_id: str = Field(description="UUID-style id; idempotency token.")
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    domain: str
    manifest_hash: str
    user_id_hash: Optional[str] = None
    correlation_id: Optional[str] = Field(
        default=None,
        description="Saga / workflow correlation id passed through Grove.",
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


class LowConfidenceClassification(CambiumEvent):
    """Classifier returned confidence below the active threshold."""

    event_type: Literal["cambium.low_confidence_classification"] = (
        "cambium.low_confidence_classification"
    )
    event_id_classifier_input: str
    semantic_category: str
    confidence: float = Field(ge=0.0, le=1.0)
    confidence_band: Literal["low", "medium", "high"]


class ActiveLearningCandidate(CambiumEvent):
    """A trace row selected for human labeling.

    ``strategy`` is one of the five selection strategies. The trace
    payload is included by reference, not by value — Grove fetches
    the trace from Cambium's trace store when the labeler opens it.
    """

    event_type: Literal["cambium.active_learning.candidate"] = (
        "cambium.active_learning.candidate"
    )
    strategy: Literal[
        "low_confidence",
        "judge_disagreement",
        "direction_flip",
        "novel_pattern",
        "user_negative_signal",
    ]
    call_site: Literal["classifier", "reasoner", "synthesizer"]
    trace_id: str
    priority: Literal["low", "normal", "high"] = "normal"


class HighCoherenceDrift(CambiumEvent):
    """Distributional shift on a per-user coherence score history."""

    event_type: Literal["cambium.high_coherence_drift"] = "cambium.high_coherence_drift"
    psi: float = Field(description="Population Stability Index over the window.")
    window_days: int


class WeeklyInsightReady(CambiumEvent):
    """The synthesizer produced an insight ready for delivery."""

    event_type: Literal["cambium.weekly_insight_ready"] = "cambium.weekly_insight_ready"
    insight_id: str
    a2ui_directive_ref: str = Field(
        description=(
            "Opaque id Grove uses to fetch the A2UI document from Cambium "
            "when handing off to a delivery surface (Sky, email, voice)."
        )
    )
    certificate_id: str


class ManifestPromotionPending(CambiumEvent):
    """A candidate manifest passed regression CI and awaits HITL approval."""

    event_type: Literal["cambium.manifest.promotion_pending"] = (
        "cambium.manifest.promotion_pending"
    )
    candidate_manifest_id: str
    baseline_manifest_id: str
    decision: Literal["PROMOTE", "HOLD"] = "PROMOTE"
    eval_report_ref: str


class ManifestDriftAlert(CambiumEvent):
    """The active manifest's behavior drifted on the canary set."""

    event_type: Literal["cambium.manifest.drift_alert"] = "cambium.manifest.drift_alert"
    severity: Literal["info", "warning", "alert"]
    psi: float
    kl_divergence: float
    canary_set_version: str


class UserFeedbackReceived(CambiumEvent):
    """A user provided structured feedback on an insight."""

    event_type: Literal["cambium.user_feedback.received"] = "cambium.user_feedback.received"
    insight_id: str
    signal: Literal["landed", "did_not_land", "off_topic", "incorrect"]
    comment: Optional[str] = None
    polarity: Literal["positive", "negative", "neutral"] = "neutral"


class CrossDomainHandoffRequested(CambiumEvent):
    """A domain pipeline implicates another domain.

    The receiving domain's spine is invoked by Grove with
    ``handoff_context`` as supplemental input. See
    ``cambium.grove.handoffs`` for the payload schema.
    """

    event_type: Literal["cambium.cross_domain.handoff_requested"] = (
        "cambium.cross_domain.handoff_requested"
    )
    source_domain: str
    target_domain: str
    handoff_context: dict[str, Any]
    reason: str


# Convenience lookup so Grove can dispatch by event_type string.
EVENT_TYPE_TO_CLASS: dict[str, type[CambiumEvent]] = {
    LowConfidenceClassification.model_fields["event_type"].default: LowConfidenceClassification,
    ActiveLearningCandidate.model_fields["event_type"].default: ActiveLearningCandidate,
    HighCoherenceDrift.model_fields["event_type"].default: HighCoherenceDrift,
    WeeklyInsightReady.model_fields["event_type"].default: WeeklyInsightReady,
    ManifestPromotionPending.model_fields["event_type"].default: ManifestPromotionPending,
    ManifestDriftAlert.model_fields["event_type"].default: ManifestDriftAlert,
    UserFeedbackReceived.model_fields["event_type"].default: UserFeedbackReceived,
    CrossDomainHandoffRequested.model_fields["event_type"].default: CrossDomainHandoffRequested,
}


__all__ = [
    "CambiumEvent",
    "LowConfidenceClassification",
    "ActiveLearningCandidate",
    "HighCoherenceDrift",
    "WeeklyInsightReady",
    "ManifestPromotionPending",
    "ManifestDriftAlert",
    "UserFeedbackReceived",
    "CrossDomainHandoffRequested",
    "EVENT_TYPE_TO_CLASS",
]
