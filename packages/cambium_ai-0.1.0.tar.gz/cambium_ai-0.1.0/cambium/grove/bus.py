"""Event bus Protocol + in-memory implementation.

Grove's Redis pubsub plugs in as a production implementation. Tests
use ``InMemoryEventBus``. The publishing side never sees Redis directly.
"""

from __future__ import annotations

from typing import Any, Callable, Protocol


class EventBus(Protocol):
    def publish(self, channel: str, payload: dict[str, Any]) -> None: ...

    @property
    def events(self) -> list[dict[str, Any]]: ...


class InMemoryEventBus:
    """Holds every published event in process memory. Test-only."""

    def __init__(self) -> None:
        self._events: list[dict[str, Any]] = []
        self._subscribers: list[Callable[[str, dict[str, Any]], None]] = []

    def publish(self, channel: str, payload: dict[str, Any]) -> None:
        record = {"channel": channel, **payload}
        self._events.append(record)
        for sub in self._subscribers:
            try:
                sub(channel, payload)
            except Exception:  # pragma: no cover
                continue

    @property
    def events(self) -> list[dict[str, Any]]:
        return list(self._events)

    def subscribe(self, handler: Callable[[str, dict[str, Any]], None]) -> None:
        self._subscribers.append(handler)


__all__ = ["EventBus", "InMemoryEventBus"]
