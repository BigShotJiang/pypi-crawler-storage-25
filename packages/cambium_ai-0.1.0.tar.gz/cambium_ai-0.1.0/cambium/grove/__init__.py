"""Grove integration package.

This package exposes:
- ``events`` — typed Pydantic event classes emitted by Cambium that
  Grove subscribes to.
- ``adapter`` — ``GroveAdapter`` wrapping Cambium as a Celery worker.
- ``handoffs`` — cross-domain handoff helpers.
- ``compensations`` — saga compensations Grove registers per
  workflow.

The actual Grove-side wiring (Celery task registration, Redis pub/sub
publication) lives in ``grove.domains.events.cambium`` and
``grove.domains.tasks.actions.cambium`` in the Grove repo. The shapes
are this package's responsibility.
"""

from cambium.grove.events import (
    ActiveLearningCandidate,
    CambiumEvent,
    CrossDomainHandoffRequested,
    HighCoherenceDrift,
    LowConfidenceClassification,
    ManifestDriftAlert,
    ManifestPromotionPending,
    UserFeedbackReceived,
    WeeklyInsightReady,
)

__all__ = [
    "ActiveLearningCandidate",
    "CambiumEvent",
    "CrossDomainHandoffRequested",
    "HighCoherenceDrift",
    "LowConfidenceClassification",
    "ManifestDriftAlert",
    "ManifestPromotionPending",
    "UserFeedbackReceived",
    "WeeklyInsightReady",
]
