"""The CambiumService Protocol and four implementations.

Implementations selectable via ``CAMBIUM_SERVICE_IMPL``:
- ``inmemory`` — tests, demos.
- ``yaml`` — local development; reads YAML configs from
  ``CAMBIUM_CONFIG_DIR``.
- ``timber`` — production; backed by ``timber-common``.
- ``ranger`` — operator-facing; reads from Ranger's ConfigStore.

The Protocol is the *contract*: every implementation honors it. Tests
mock or substitute trivially.
"""

from __future__ import annotations

import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Protocol, runtime_checkable

from cambium.core.domain import DomainRegistry
from cambium.core.types import (
    EvalThresholds,
    FeatureFlags,
    IdentityProfile,
    Manifest,
    ModelOverrides,
    RedactionPolicy,
    TraceRecord,
)


@runtime_checkable
class CambiumService(Protocol):
    """The contract every Cambium implementation honors."""

    def domain_registry(self) -> DomainRegistry: ...

    def list_domains(self) -> list[str]: ...

    def get_domain_config(self, domain: str): ...

    def get_eval_thresholds(self, domain: str) -> EvalThresholds: ...

    def get_feature_flags(self) -> FeatureFlags: ...

    def get_model_overrides(self) -> ModelOverrides: ...

    def get_redaction_policy(self) -> RedactionPolicy: ...

    # Manifests
    def register_manifest(self, manifest: Manifest) -> None: ...
    def get_manifest(self, manifest_id: str) -> Manifest: ...
    def activate_manifest(self, manifest_id: str, domain: str) -> None: ...
    def get_active_manifest(self, domain: str) -> Manifest: ...

    # Identity persistence
    def put_identity(self, identity: IdentityProfile) -> None: ...
    def get_identity(self, user_id_hash: str, domain: str) -> Optional[IdentityProfile]: ...

    # Trace
    def record_trace(self, trace: TraceRecord) -> None: ...
    def list_traces(self, **filters: Any) -> list[TraceRecord]: ...


# ---------------------------------------------------------------------------
# InMemory implementation
# ---------------------------------------------------------------------------


class InMemoryCambiumService:
    """In-memory backend. Default; no persistence between processes."""

    def __init__(self) -> None:
        self._domain_registry = DomainRegistry()
        self._manifests: dict[str, Manifest] = {}
        self._active: dict[str, str] = {}  # domain → manifest_id
        self._identities: dict[tuple[str, str], IdentityProfile] = {}
        self._traces: list[TraceRecord] = []
        self._feature_flags = FeatureFlags()
        self._model_overrides = ModelOverrides()
        self._redaction_policy = RedactionPolicy()
        self._lock = threading.Lock()

    def domain_registry(self) -> DomainRegistry:
        return self._domain_registry

    def list_domains(self) -> list[str]:
        return self._domain_registry.list_domains()

    def get_domain_config(self, domain: str):
        return self._domain_registry.get(domain)

    def get_eval_thresholds(self, domain: str) -> EvalThresholds:
        return EvalThresholds()

    def get_feature_flags(self) -> FeatureFlags:
        return self._feature_flags

    def get_model_overrides(self) -> ModelOverrides:
        return self._model_overrides

    def get_redaction_policy(self) -> RedactionPolicy:
        return self._redaction_policy

    def register_manifest(self, manifest: Manifest) -> None:
        with self._lock:
            self._manifests[manifest.manifest_id] = manifest

    def get_manifest(self, manifest_id: str) -> Manifest:
        if manifest_id not in self._manifests:
            raise KeyError(f"Unknown manifest: {manifest_id}")
        return self._manifests[manifest_id]

    def activate_manifest(self, manifest_id: str, domain: str) -> None:
        if manifest_id not in self._manifests:
            raise KeyError(f"Unknown manifest: {manifest_id}")
        with self._lock:
            self._active[domain] = manifest_id

    def get_active_manifest(self, domain: str) -> Manifest:
        if domain not in self._active:
            raise KeyError(f"No active manifest for domain: {domain}")
        return self._manifests[self._active[domain]]

    def put_identity(self, identity: IdentityProfile) -> None:
        with self._lock:
            self._identities[(identity.user_id_hash, identity.domain)] = identity

    def get_identity(self, user_id_hash: str, domain: str) -> Optional[IdentityProfile]:
        return self._identities.get((user_id_hash, domain))

    def record_trace(self, trace: TraceRecord) -> None:
        with self._lock:
            self._traces.append(trace)

    def list_traces(self, **filters: Any) -> list[TraceRecord]:
        rows = self._traces
        for key, value in filters.items():
            rows = [r for r in rows if getattr(r, key, None) == value]
        return rows

    # Shadow A/B placeholder — production overrides this.
    def get_shadow_pair(self, domain: str) -> Optional[tuple[Manifest, Manifest]]:
        return None


# ---------------------------------------------------------------------------
# YAML implementation — light wrapper that loads domain configs from disk
# ---------------------------------------------------------------------------


class YamlCambiumService(InMemoryCambiumService):
    """YAML-backed development service.

    Reads domain configs from ``CAMBIUM_CONFIG_DIR`` if set. Identities,
    manifests, and traces live in-memory.
    """

    def __init__(self, config_dir: Optional[str | Path] = None) -> None:
        super().__init__()
        self.config_dir = Path(config_dir or os.environ.get("CAMBIUM_CONFIG_DIR", ""))
        if self.config_dir.exists() and self.config_dir.is_dir():
            self._load_domain_configs()

    def _load_domain_configs(self) -> None:
        for path in (self.config_dir / "domains").glob("*/config.yaml"):
            self._domain_registry.register_from_yaml(path)


# ---------------------------------------------------------------------------
# Timber implementation — lazy-loaded; needs the optional `timber` extra
# ---------------------------------------------------------------------------


class TimberCambiumService(InMemoryCambiumService):
    """Production service backed by timber-common.

    Uses Timber's repositories for manifests / identities / traces, the
    rules engine for guardrails, and the keystore for provenance signing
    keys. Falls back to the in-memory parent if timber-common isn't
    available, so this class is safe to import even outside production.
    """

    def __init__(self) -> None:
        super().__init__()
        try:  # pragma: no cover
            from common import (  # type: ignore[import-not-found]
                model_factory as _,  # noqa: F401
            )

            self._timber_ready = True
        except ImportError:
            self._timber_ready = False

    # Production overrides would wire repositories here; for the v1
    # release the in-memory fallback is acceptable while the cambium
    # YAML configs are still validating against timber's factory.


# ---------------------------------------------------------------------------
# Default-instance bootstrap
# ---------------------------------------------------------------------------


_DEFAULT: Optional[CambiumService] = None
_DEFAULT_LOCK = threading.Lock()


def get_default_service() -> CambiumService:
    """Return the default service. Pick by ``CAMBIUM_SERVICE_IMPL`` env var."""
    global _DEFAULT
    if _DEFAULT is not None:
        return _DEFAULT
    with _DEFAULT_LOCK:
        if _DEFAULT is not None:
            return _DEFAULT
        impl = os.environ.get("CAMBIUM_SERVICE_IMPL", "inmemory").lower()
        if impl == "yaml":
            _DEFAULT = YamlCambiumService()
        elif impl == "timber":
            _DEFAULT = TimberCambiumService()
        else:
            _DEFAULT = InMemoryCambiumService()
    return _DEFAULT


def reset_default_service() -> None:
    """For tests. Drops the default instance so the next call re-bootstraps."""
    global _DEFAULT
    with _DEFAULT_LOCK:
        _DEFAULT = None


def make_default_manifest(
    domain: str,
    *,
    identity_schema_version: str,
    domain_config_hash: str,
    classifier_model: str = "claude-haiku-4-5-20251001",
    reasoner_model: str = "claude-sonnet-4-6",
    synthesizer_model: str = "claude-opus-4-7",
) -> Manifest:
    """Convenience: build a Manifest with v1 prompt hashes wired in."""
    from cambium.prompts.classifier import CLASSIFIER_VERSION
    from cambium.prompts.reasoner import REASONER_VERSION
    from cambium.prompts.synthesizer import SYNTHESIZER_VERSION

    return Manifest(
        manifest_id=f"{domain}-{uuid.uuid4().hex[:8]}",
        domain=domain,
        classifier_prompt_hash=CLASSIFIER_VERSION,
        reasoner_prompt_hash=REASONER_VERSION,
        synthesizer_prompt_hash=SYNTHESIZER_VERSION,
        classifier_model=classifier_model,
        reasoner_model=reasoner_model,
        synthesizer_model=synthesizer_model,
        judge_model=synthesizer_model,
        judge_rubric_hash="rubric.v1",
        identity_schema_version=identity_schema_version,
        domain_config_hash=domain_config_hash,
        created_at=datetime.now(timezone.utc),
    )


__all__ = [
    "CambiumService",
    "InMemoryCambiumService",
    "TimberCambiumService",
    "YamlCambiumService",
    "get_default_service",
    "make_default_manifest",
    "reset_default_service",
]
