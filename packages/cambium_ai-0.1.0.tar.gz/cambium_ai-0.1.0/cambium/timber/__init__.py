"""Timber integration. Imports lazily so cambium works without timber-common."""

from cambium.timber.rules import (  # noqa: F401
    build_reasoner_rules,
    build_synthesizer_rules,
    catastrophizing_filter_rule,
)

__all__ = [
    "build_reasoner_rules",
    "build_synthesizer_rules",
    "catastrophizing_filter_rule",
]
