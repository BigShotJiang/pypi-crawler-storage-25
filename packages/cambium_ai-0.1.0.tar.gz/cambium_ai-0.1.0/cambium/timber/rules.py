"""Declarative rules for Cambium guardrails.

These rules are the canonical implementation of Pattern 10 (Guardrail
Wrap). Each rule is a stable, versioned ``(rule_id, version)`` tuple
that flows into the manifest content hash.

In production, this module delegates to ``common.rules`` (added to
timber-common as part of the Cambium rollout). When that module isn't
importable, the in-process fallback used here keeps the API identical
so unit tests and dev environments run.
"""

from __future__ import annotations

import dataclasses
import json
from typing import Any, Callable, Optional, Sequence

from pydantic import BaseModel, ConfigDict, Field

try:  # pragma: no cover — import-time only
    from common.rules import (  # type: ignore[import-not-found]
        Rule as _CommonRule,
        RulesPackage as _CommonRulesPackage,
        Violation as _CommonViolation,
    )

    _USE_TIMBER = True
except ImportError:
    _USE_TIMBER = False


class _Violation(BaseModel):
    """Local violation type when timber-common is absent."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    rule_id: str
    version: str
    message: str
    severity: str = "error"


class _RuleResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    ok: bool
    violations: list[_Violation] = Field(default_factory=list)
    repaired_payload: Optional[dict[str, Any]] = None


@dataclasses.dataclass
class _Rule:
    """Local rule shape when timber-common is absent."""

    rule_id: str
    version: str
    description: str
    check: Callable[[dict[str, Any]], _RuleResult]
    repair: Optional[Callable[[dict[str, Any]], dict[str, Any]]] = None

    def apply(self, payload: dict[str, Any]) -> tuple[dict[str, Any], _RuleResult]:
        result = self.check(payload)
        if result.ok or self.repair is None:
            return payload, result
        repaired = self.repair(payload)
        result_after = self.check(repaired)
        return repaired, result_after


@dataclasses.dataclass
class _RulesPackage:
    package_id: str
    version: str
    rules: tuple[_Rule, ...]

    def apply(self, payload: dict[str, Any]) -> tuple[dict[str, Any], list[_Violation]]:
        out = dict(payload)
        violations: list[_Violation] = []
        for rule in self.rules:
            out, result = rule.apply(out)
            if not result.ok:
                violations.extend(result.violations)
        return out, violations

    def content_hash(self) -> str:
        import hashlib

        manifest = {
            "package_id": self.package_id,
            "version": self.version,
            "rules": [(r.rule_id, r.version) for r in self.rules],
        }
        canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# Public aliases that compose with whichever backend is active.
if _USE_TIMBER:  # pragma: no cover
    Rule = _CommonRule  # type: ignore[misc, assignment]
    RulesPackage = _CommonRulesPackage  # type: ignore[misc, assignment]
    Violation = _CommonViolation  # type: ignore[misc, assignment]
else:
    Rule = _Rule  # type: ignore[misc, assignment]
    RulesPackage = _RulesPackage  # type: ignore[misc, assignment]
    Violation = _Violation  # type: ignore[misc, assignment]


# ---------------------------------------------------------------------------
# Canonical rule constructors
# ---------------------------------------------------------------------------


def adjustment_ceiling_rule(ceiling: float) -> _Rule:
    """Reasoner adjustment magnitude bounded to ±ceiling."""

    def check(payload: dict[str, Any]) -> _RuleResult:
        adj = float(payload.get("reasoner_adjustment", 0.0))
        if abs(adj) <= ceiling:
            return _RuleResult(ok=True)
        return _RuleResult(
            ok=False,
            violations=[
                _Violation(
                    rule_id="reasoner.adjustment_ceiling",
                    version="1.0",
                    message=f"adjustment {adj} exceeds ceiling ±{ceiling}",
                )
            ],
        )

    def repair(payload: dict[str, Any]) -> dict[str, Any]:
        adj = float(payload.get("reasoner_adjustment", 0.0))
        clipped = max(-ceiling, min(ceiling, adj))
        return {**payload, "reasoner_adjustment": clipped}

    return _Rule(
        rule_id="reasoner.adjustment_ceiling",
        version="1.0",
        description=f"Reasoner adjustment must be within ±{ceiling} of baseline.",
        check=check,
        repair=repair,
    )


def dimension_citation_rule(permitted: Sequence[str]) -> _Rule:
    """Cited dimensions must be in the domain's permitted set."""

    permitted_set = set(permitted)

    def check(payload: dict[str, Any]) -> _RuleResult:
        cited = payload.get("dimensions_cited", [])
        unknown = [d for d in cited if d not in permitted_set]
        if not unknown:
            return _RuleResult(ok=True)
        return _RuleResult(
            ok=False,
            violations=[
                _Violation(
                    rule_id="reasoner.dimension_citation",
                    version="1.0",
                    message=f"cited dimensions not in domain set: {unknown}",
                )
            ],
        )

    def repair(payload: dict[str, Any]) -> dict[str, Any]:
        cited = [d for d in payload.get("dimensions_cited", []) if d in permitted_set]
        return {**payload, "dimensions_cited": cited}

    return _Rule(
        rule_id="reasoner.dimension_citation",
        version="1.0",
        description="Dimensions cited must belong to the active domain.",
        check=check,
        repair=repair,
    )


_CATASTROPHIZING_TOKENS = (
    "reckless",
    "irresponsible",
    "stupid",
    "foolish",
    "disastrous",
    "catastrophic",
)


def catastrophizing_filter_rule(
    tokens: Sequence[str] = _CATASTROPHIZING_TOKENS,
) -> _Rule:
    """Justifications must not contain catastrophizing tokens."""
    lowered = tuple(t.lower() for t in tokens)

    def check(payload: dict[str, Any]) -> _RuleResult:
        text = str(payload.get("justification", "")).lower()
        hits = [t for t in lowered if t in text]
        if not hits:
            return _RuleResult(ok=True)
        return _RuleResult(
            ok=False,
            violations=[
                _Violation(
                    rule_id="content_policy.catastrophizing",
                    version="1.0",
                    message=f"catastrophizing tokens present: {hits}",
                )
            ],
        )

    return _Rule(
        rule_id="content_policy.catastrophizing",
        version="1.0",
        description="Reject justifications containing catastrophizing tokens.",
        check=check,
    )


def event_reference_rule(permitted_event_ids: Sequence[str]) -> _Rule:
    """Synthesizer event references must be in the window."""

    permitted = set(permitted_event_ids)

    def check(payload: dict[str, Any]) -> _RuleResult:
        refs = payload.get("event_references", [])
        bad = [e for e in refs if e not in permitted]
        if not bad:
            return _RuleResult(ok=True)
        return _RuleResult(
            ok=False,
            violations=[
                _Violation(
                    rule_id="synthesizer.event_reference",
                    version="1.0",
                    message=f"referenced events outside window: {bad}",
                )
            ],
        )

    def repair(payload: dict[str, Any]) -> dict[str, Any]:
        refs = [e for e in payload.get("event_references", []) if e in permitted]
        return {**payload, "event_references": refs}

    return _Rule(
        rule_id="synthesizer.event_reference",
        version="1.0",
        description="Synthesizer must reference events from the supplied window.",
        check=check,
        repair=repair,
    )


# ---------------------------------------------------------------------------
# Pre-bundled rule packages per call site
# ---------------------------------------------------------------------------


def build_reasoner_rules(
    *, ceiling: float, permitted: Sequence[str]
) -> _RulesPackage:
    return _RulesPackage(
        package_id="cambium.reasoner",
        version="1.0",
        rules=(
            adjustment_ceiling_rule(ceiling),
            dimension_citation_rule(permitted),
            catastrophizing_filter_rule(),
        ),
    )


def build_synthesizer_rules(
    *,
    permitted_dimensions: Sequence[str],
    permitted_event_ids: Sequence[str],
) -> _RulesPackage:
    return _RulesPackage(
        package_id="cambium.synthesizer",
        version="1.0",
        rules=(
            dimension_citation_rule(permitted_dimensions),
            event_reference_rule(permitted_event_ids),
            catastrophizing_filter_rule(),
        ),
    )


__all__ = [
    "Rule",
    "RulesPackage",
    "Violation",
    "adjustment_ceiling_rule",
    "build_reasoner_rules",
    "build_synthesizer_rules",
    "catastrophizing_filter_rule",
    "dimension_citation_rule",
    "event_reference_rule",
]
