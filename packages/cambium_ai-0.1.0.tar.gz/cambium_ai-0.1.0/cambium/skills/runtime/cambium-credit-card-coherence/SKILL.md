---
name: cambium-credit-card-coherence
description: Per-vertical runtime configuration for scoring credit-card spending coherence within the finance domain. Vertical-specific category extensions, baseline tweaks, and tone hints.
---

# Credit-Card Coherence (finance vertical)

A runtime skill that layers on top of the finance domain to tune Cambium for the credit-card spending vertical.

When active, this skill:

- Tightens the baseline's impulse and status_signaling weights (credit cards are higher-friction; impulse signals are stronger).
- Adds two narrow categories: `revolving_debt_build` and `paydown_aggressive`.
- Tunes the prompt voice to be more curious about reward-redemption mental accounting.

## YAML overrides

See `config.yaml` alongside this file. Loaded via `service.get_skills_config(["cambium-credit-card-coherence"])` which returns an override dict the spine merges into the active domain config.

## Activation

Add `"cambium-credit-card-coherence"` to the active manifest's `active_skills` tuple. The manifest content hash changes; the regression CI runs.

## Removal

Drop the slug from `active_skills` and run regression CI again.
