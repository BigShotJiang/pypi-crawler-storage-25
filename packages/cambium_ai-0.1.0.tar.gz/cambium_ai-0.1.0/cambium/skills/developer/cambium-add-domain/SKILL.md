---
name: cambium-add-domain
description: Procedure for adding a new domain (health, career, sustainability, learning, relational) to Cambium without forking. Use when a contributor wants Cambium to cover a new signal source + identity instrument.
---

# Add a Domain

Cambium is a meta-framework. New domains plug in via configuration + four small Python modules + a golden seed. No platform code changes.

## Step 1 — Choose a slug

Pick a single-word lowercase identifier. Examples: `health`, `career`, `sustainability`, `learning`, `relational`.

## Step 2 — Copy the template

```bash
cp -r cambium/domains/_template cambium/domains/<slug>
```

## Step 3 — Edit `config.yaml`

Fields:
- `name` — the slug.
- `dimensions` — 5–12 dimension names (lowercase_snake_case).
- `categories` — 8–15 behavioral categories.
- `narrative_tags` — optional categorical identity claims.
- `reasoner_adjustment_ceiling` — default 0.3; justify any override.
- `prompt_voice` — the tone the synthesizer adopts.
- `baseline_class`, `identity_class`, `events_module` — dotted paths.

## Step 4 — Implement `baseline.py`

Per-category, per-dimension weights. Category valence. Magnitude modifier. Mirror `cambium/domains/finance/baseline.py` but tune for your domain.

## Step 5 — Implement `identity.py`

Reducer from your instrument's screen/question responses into an `IdentityProfile`. Use `FinancialDNACapture` as a template.

## Step 6 — Implement `events.py`

Adapters from your signal source(s) into `BehavioralEvent`. Use `from_plaid_transaction` as a template.

## Step 7 — Author the golden seed

At least 20 examples (10 classifier, 7 reasoner, 3 synthesizer) hand-labeled by two reviewers. JSONL under `golden_seeds/<slug>_v1.jsonl`. Use the existing finance seed as a structural template.

## Step 8 — Register at boot

```python
service = get_default_service()
service.domain_registry().register_from_yaml(
    Path("cambium/domains/<slug>/config.yaml")
)
```

## Step 9 — Eval

```bash
cambium eval --domain <slug> --call-site classifier --golden golden_seeds/<slug>_v1.jsonl
cambium eval --domain <slug> --call-site reasoner --golden golden_seeds/<slug>_v1.jsonl
cambium eval --domain <slug> --call-site synthesizer --golden golden_seeds/<slug>_v1.jsonl
```

Tune until metrics meet your domain's thresholds. Submit metrics with the PR.

## Step 10 — Cross-domain handoff (optional)

If your domain emits signals that another domain should consider, emit a `CrossDomainHandoffRequested` event via the Grove adapter. Grove routes; the target domain receives a `HandoffContext`.

## Done criteria

- [ ] `config.yaml` registers cleanly.
- [ ] All three call sites run end-to-end against the golden seed.
- [ ] Eval metrics meet the thresholds.
- [ ] Manifest content hash changes when domain config changes.
