---
name: cambium-author-golden-set
description: Authoring rubric for hand-labeled golden examples used by Cambium's eval framework. Use when adding examples to an existing golden set or seeding a new one.
---

# Author a Golden Set

Golden sets are the training-free analog of fine-tuned weights. They grow monotonically; you tombstone (`tags: ["deprecated"]`) instead of deleting.

## Labeler discipline

- **Two reviewers per example.** One author + one reviewer.
- **Plain JSONL.** Every example is one line. Diffable.
- **Cover modes.** Standard cases. Adversarial cases. Edge cases.
- **No PII in the example.** Use hashed user ids; pseudonymous merchants.

## Example shape (one JSONL row)

```json
{
  "id": "clf-021",
  "domain": "finance",
  "call_site": "classifier",
  "version_added": "finance_v2",
  "labeler": "human:<reviewer>",
  "rationale": "Recurring debt service is unambiguous.",
  "input": {
    "event": {
      "event_id": "clf-021",
      "user_id_hash": "demo",
      "domain": "finance",
      "event_type": "transaction",
      "timestamp": "2026-04-15T14:30:00+00:00",
      "magnitude": "350",
      "description": "Auto loan payment",
      "raw": {"plaid_category": ["Transfer", "Debit"]}
    },
    "preceding": []
  },
  "expected": {
    "semantic_category": "debt_service",
    "confidence_band": "high"
  },
  "adversarial": false,
  "tags": []
}
```

## Coverage targets

For each call site in a domain, the v1 set should hit:
- ≥ 60% mainstream cases (clear category, plain magnitude, common dimensions).
- 20-30% mode-boundary cases (the same event could plausibly be two categories).
- 10-20% adversarial cases (model-likely-to-fail; mark `adversarial: true`).

## Rationale standards

Each example has a `rationale` field explaining WHY this label is correct. Reviewers read the rationale before approving. If you can't write a one-sentence rationale, the example is too ambiguous to label.

## Versioning

Bump the set version when adding examples. Never edit an example in place. Tombstone old examples by adding `tags: ["deprecated"]`. The set version flows into the manifest content hash.

## Source

Read `cambium/golden_seeds/finance_classifier_v1.jsonl` to see worked examples.
