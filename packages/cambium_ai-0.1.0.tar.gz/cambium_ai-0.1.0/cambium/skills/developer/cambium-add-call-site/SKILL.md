---
name: cambium-add-call-site
description: Procedure for adding a fourth (or fifth, etc.) bounded LLM call site without breaking Cambium's manifest, trace, or eval contracts. Use when a contributor proposes a new structured LLM-backed step.
---

# Add a Call Site

A call site in Cambium is a *bounded* place where the model is asked one narrow question and answers with structured output. Adding one is rare. Doing it wrong breaks Pattern 10 (Guardrail Wrap) and Pattern 13 (Creative Sandbox with Deterministic Exit).

## Checklist before you start

- [ ] Are you sure this isn't a workflow step? If the new step is "after X, do Y," push it to Grove.
- [ ] Are you sure this isn't a context-enrichment? If the spine just needs more context, fetch it via `CambiumService` and pass it to an existing call site.
- [ ] Are you sure this isn't a domain customization? If only one domain needs it, customize via the domain plug-in (`cambium-add-domain`).

If you can answer NO to all three, proceed.

## Step 1 — Define the call site's structured output

Add a Pydantic model in `cambium/core/types.py`. Frozen + extra-forbid. Justify each field. Cite the field in `docs/ARCHITECTURE.md`.

## Step 2 — Write the prompt

Add `cambium/prompts/<call_site>.py` with:

```python
<CALL_SITE>_VERSION = "<call_site>.v1.0.0"
<CALL_SITE>_SYSTEM = """..."""

def build_<call_site>_prompt(...) -> str: ...
```

The system message must say:
- What inputs you'll be given.
- What strict JSON shape you must return.
- The bounds you cannot exceed.

## Step 3 — Implement the call site

Add `cambium/call_sites/<call_site>.py` with one function:

```python
def run_<call_site>(*, ..., claude_client, ...) -> dict[str, Any]:
    ...
```

Constraints:
- No HTTP calls beyond the model.
- No reads from a vector store inside the call site.
- No tool use.
- One repair retry on invalid output; second failure surfaces a fallback.

## Step 4 — Add rules

Add rule constructors to `cambium/timber/rules.py`. At minimum:
- A numeric bounds rule for any numeric outputs.
- A referential rule for any cited identifiers.
- The catastrophizing filter for any free-text output.

Add `build_<call_site>_rules(...)` returning a `RulesPackage`.

## Step 5 — Wire into the spine

Edit `cambium/core/spine.py` to call `run_<call_site>(...)`, apply the rules, record a trace.

## Step 6 — Extend the manifest

Add `<call_site>_prompt_hash`, `<call_site>_model` to `Manifest`. The content hash MUST change when these change.

## Step 7 — Extend the service Protocol

Add any per-call-site config the service must surface. Add to `InMemoryCambiumService`, `YamlCambiumService`, `TimberCambiumService`.

## Step 8 — Eval

Add an `EvalRunner.run_<call_site>` method. Choose your metric: classifier-style (F1) or regression-style (MAE) or judge-style (LLM rubric). Add the metric to the regression CI gates.

## Step 9 — Author 20 golden examples

Two reviewers minimum per example. Mix standard + adversarial.

## Step 10 — Update the docs

Update `docs/ARCHITECTURE.md` § 3 to list the new call site. Update `docs/agentic-patterns.md` if the new call site implements a new pattern.

## Done criteria

- [ ] Regression CI runs and produces metrics for the new call site.
- [ ] At least one example exercises it end-to-end.
- [ ] The manifest content hash changes when the new prompt changes.
- [ ] The new rule package is content-hashed and included in the manifest.
