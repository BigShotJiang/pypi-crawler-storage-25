---
name: cambium-update-a2ui-contract
description: Procedure for updating the A2UI block contract in lockstep across cambium/a2ui/components.py, acorn/models/a2ui.py, and sky/src/components/a2ui/types.ts. Use whenever you add, remove, or change a block type.
---

# Update the A2UI Contract

A2UI is a three-repo contract:

1. **Cambium** — `cambium/a2ui/components.py`. The Pydantic source of truth.
2. **Acorn** — `acorn/models/a2ui.py`. Server-side mirror so the chat envelope is fully typed end-to-end.
3. **Sky** — `sky/src/components/a2ui/types.ts` + `sky/src/components/a2ui/blocks/`. TypeScript twins + React components.

If any of these drifts, the chat envelope misrenders silently.

## Procedure

For any change to a block:

1. Modify the Pydantic model in `cambium/a2ui/components.py`. Bump `__version__` if the change is incompatible.
2. Mirror the change verbatim in `acorn/models/a2ui.py`. Field names, types, defaults, validators — match.
3. Mirror the change in `sky/src/components/a2ui/types.ts`. TypeScript types only (no logic).
4. For new block types, add a React component under `sky/src/components/a2ui/blocks/<NewBlock>.tsx`. Update `CambiumInsightRenderer.tsx` to dispatch the new `type` value.
5. Update `sky/src/components/a2ui/parser.ts` if you added a new directive `kind`.
6. Run the test triangle:
   - `pytest cambium/tests/` against Cambium.
   - Acorn's pydantic round-trip tests.
   - Sky's TypeScript compile + a snapshot render test.

## Done criteria

- [ ] Pydantic round-trips identical JSON to/from a TS-deserialized object.
- [ ] The new block renders in Sky's storybook (or its equivalent).
- [ ] No surface logs "unknown block type" warnings.
