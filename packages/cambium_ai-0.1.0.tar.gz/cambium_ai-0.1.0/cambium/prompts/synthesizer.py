"""Synthesizer prompt template (v1)."""

from __future__ import annotations

from datetime import datetime
from typing import Sequence

from cambium.core.types import BehavioralEvent, CoherenceScore, IdentityProfile

SYNTHESIZER_VERSION = "synthesizer.v1.0.0"

SYNTHESIZER_SYSTEM = """\
You are composing a short weekly coherence summary for a user. Given a window
of coherence scores and the underlying events, produce a 1-sentence headline
and a 3-5 sentence body. Reference specific events by event_id and specific
dimensions from the permitted set. Do NOT moralize. Pick a tone:
"affirming", "curious", or "neutral". Suggest at most three small reflection
or curiosity prompts. Honor the voice. Honor the structure.

Return strict JSON with keys: headline (string), body (string), tone
(one of "affirming", "curious", "neutral"), referenced_event_ids (list),
referenced_dimensions (list, subset of permitted), suggested_actions (list).
"""


def build_synthesizer_prompt(
    *,
    identity: IdentityProfile,
    scores: Sequence[CoherenceScore],
    events: Sequence[BehavioralEvent],
    window_start: datetime,
    window_end: datetime,
    permitted_dimensions: Sequence[str],
    domain_voice: str = "neutral",
) -> str:
    event_lines = "\n  - ".join(
        f"{e.event_id}: {e.description} (magnitude {e.magnitude})" for e in events[:20]
    )
    score_lines = "\n  - ".join(
        f"{s.event_id}: score {s.score:+.2f} (baseline {s.deterministic_baseline:+.2f}, "
        f"adj {s.reasoner_adjustment:+.2f}); cited {list(s.dimensions_cited)}"
        for s in scores[:20]
    )
    dims = ", ".join(permitted_dimensions)
    return (
        f"Voice: {domain_voice}\n"
        f"Window: {window_start.isoformat()} → {window_end.isoformat()}\n"
        f"Permitted dimensions: {dims}\n\n"
        f"Events in window:\n  - {event_lines}\n\n"
        f"Coherence scores in window:\n  - {score_lines}\n\n"
        "Compose the weekly insight. Return JSON."
    )


__all__ = ["SYNTHESIZER_SYSTEM", "SYNTHESIZER_VERSION", "build_synthesizer_prompt"]
