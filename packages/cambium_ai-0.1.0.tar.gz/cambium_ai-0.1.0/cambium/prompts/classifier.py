"""Classifier prompt template (v1)."""

from __future__ import annotations

from typing import Sequence

from cambium.core.types import BehavioralEvent

CLASSIFIER_VERSION = "classifier.v1.0.0"

CLASSIFIER_SYSTEM = """\
You are a classifier inside a deterministic spine. Your job is to label a
single behavioral event with ONE semantic category from a permitted set, and
report your confidence in [0, 1]. You will receive a redacted event
description and the permitted category set. You MUST choose strictly from
the permitted set. If unsure, choose the closest match and lower the
confidence. Return strict JSON with keys: semantic_category (string),
confidence (float in [0,1]).
"""


def build_classifier_prompt(
    *,
    event: BehavioralEvent,
    redacted_description: str,
    categories: Sequence[str],
    domain_voice: str = "neutral",
) -> str:
    cats = "\n  - ".join(categories)
    return (
        f"Voice: {domain_voice}\n"
        f"Permitted categories:\n  - {cats}\n\n"
        f"Event:\n"
        f"  event_id: {event.event_id}\n"
        f"  event_type: {event.event_type}\n"
        f"  description: {redacted_description}\n"
        f"  magnitude: {event.magnitude}\n"
        f"  timestamp: {event.timestamp.isoformat()}\n\n"
        "Return JSON: {\"semantic_category\": <one of the permitted "
        "categories>, \"confidence\": <float in [0,1]>}."
    )


__all__ = ["CLASSIFIER_SYSTEM", "CLASSIFIER_VERSION", "build_classifier_prompt"]
