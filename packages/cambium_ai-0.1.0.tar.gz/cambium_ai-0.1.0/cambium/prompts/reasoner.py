"""Reasoner prompt template (v1)."""

from __future__ import annotations

from typing import Sequence

from cambium.core.types import BehavioralEvent, ClassifiedEvent, IdentityProfile

REASONER_VERSION = "reasoner.v1.0.0"

REASONER_SYSTEM = """\
You are a reasoner inside a bounded-agent system. Given:
- a user's stated identity profile (dimensions in [0, 1]),
- an observed behavioral event (already classified),
- a deterministic baseline score in [-1, 1],

your task is to propose an adjustment in [-CEILING, +CEILING] that improves
how well the score reflects the alignment between stated identity and revealed
behavior. You may cite ONLY dimensions from the permitted set. You may NEVER
use catastrophizing language (e.g. "reckless", "irresponsible"). Be specific:
ground your justification in the observed magnitude, the cited dimensions,
and the structural fit.

Return strict JSON with keys: reasoner_adjustment (float in
[-CEILING, +CEILING]), dimensions_cited (list of strings, subset of the
permitted set), justification (one sentence), confidence (float in [0, 1]).
"""


def build_reasoner_prompt(
    *,
    identity: IdentityProfile,
    event: BehavioralEvent,
    redacted_description: str,
    classified: ClassifiedEvent,
    baseline: float,
    ceiling: float,
    permitted_dimensions: Sequence[str],
    domain_voice: str = "neutral",
) -> str:
    dims = "\n  - ".join(
        f"{name}: {identity.dimensions.get(name, 0.5):.2f}" for name in permitted_dimensions
    )
    return (
        f"Voice: {domain_voice}\n"
        f"CEILING: ±{ceiling}\n\n"
        f"Identity dimensions:\n  - {dims}\n\n"
        f"Event:\n"
        f"  event_id: {event.event_id}\n"
        f"  description: {redacted_description}\n"
        f"  magnitude: {event.magnitude}\n"
        f"  classified.semantic_category: {classified.semantic_category}\n"
        f"  classified.confidence: {classified.confidence:.2f}\n\n"
        f"Deterministic baseline: {baseline:+.3f}\n\n"
        "Propose a conservative adjustment. Return JSON."
    )


__all__ = ["REASONER_SYSTEM", "REASONER_VERSION", "build_reasoner_prompt"]
