"""Versioned prompt templates. Each template carries a stable hash flowed into the manifest."""

from cambium.prompts.classifier import CLASSIFIER_SYSTEM, build_classifier_prompt  # noqa: F401
from cambium.prompts.reasoner import REASONER_SYSTEM, build_reasoner_prompt  # noqa: F401
from cambium.prompts.synthesizer import SYNTHESIZER_SYSTEM, build_synthesizer_prompt  # noqa: F401

__all__ = [
    "CLASSIFIER_SYSTEM",
    "REASONER_SYSTEM",
    "SYNTHESIZER_SYSTEM",
    "build_classifier_prompt",
    "build_reasoner_prompt",
    "build_synthesizer_prompt",
]
