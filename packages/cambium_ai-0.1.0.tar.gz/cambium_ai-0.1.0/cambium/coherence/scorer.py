"""Window-level coherence aggregation. Pure deterministic Python."""

from __future__ import annotations

from typing import Sequence

from cambium.core.types import CoherenceScore


def compute_window_score(scores: Sequence[CoherenceScore]) -> float:
    """Weighted mean of coherence scores. Pure deterministic."""
    if not scores:
        return 0.0
    return sum(s.score for s in scores) / len(scores)


def dominant_dimensions(scores: Sequence[CoherenceScore], top_k: int = 3) -> list[str]:
    """Return the dimensions cited most often across the window."""
    if not scores:
        return []
    counts: dict[str, int] = {}
    for s in scores:
        for d in s.dimensions_cited:
            counts[d] = counts.get(d, 0) + 1
    return [d for d, _ in sorted(counts.items(), key=lambda kv: -kv[1])[:top_k]]


__all__ = ["compute_window_score", "dominant_dimensions"]
