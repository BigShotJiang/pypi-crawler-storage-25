"""Deterministic explainer.

Explanations are built from scoring traces and reasoner citations.
NEVER built via an additional LLM pass — explanations are part of the
auditable trace.
"""

from __future__ import annotations

from cambium.core.types import CoherenceScore


def explain_score(score: CoherenceScore) -> str:
    """Render a one-paragraph deterministic explanation of a score."""
    cited = ", ".join(score.dimensions_cited) if score.dimensions_cited else "no dimensions"
    sign = "above" if score.score >= 0 else "below"
    return (
        f"Score {score.score:+.2f} sits {sign} the user's baseline alignment for this domain. "
        f"Baseline {score.deterministic_baseline:+.2f} + adjustment {score.reasoner_adjustment:+.2f}. "
        f"Cited dimensions: {cited}. "
        f"Confidence {score.confidence:.2f}."
    )


__all__ = ["explain_score"]
