"""Cambium — a bounded-agent behavioral coherence engine.

The deterministic spine decides what to ask. The model only answers.
The eval framework decides whether the answer counted.
"""

from __future__ import annotations

__version__ = "0.1.0"

# Re-exported lazily; the public surface deliberately stays narrow so
# downstream services depend on a small contract.
from cambium.service import get_default_service

__all__ = [
    "__version__",
    "get_default_service",
]
