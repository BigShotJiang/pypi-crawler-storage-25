"""Eval runner — runs a golden set through a specific call site and reports metrics.

The runner is stateless: it takes a GoldenSet + manifest + service,
runs each example through the call site, and returns an
``EvalReport``. The report carries the metrics, per-example results,
and a calibration report.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from cambium.core.calibration import calibration_report
from cambium.core.types import BehavioralEvent, IdentityProfile, Manifest
from cambium.evals.golden import GoldenSet
from cambium.evals.metrics import (
    accuracy,
    direction_agreement,
    iou,
    macro_f1,
    mean_absolute_error,
)

if TYPE_CHECKING:
    from cambium.service import CambiumService


@dataclass
class ExampleResult:
    id: str
    predicted: dict[str, Any]
    expected: dict[str, Any]
    correct: bool


@dataclass
class EvalReport:
    call_site: str
    domain: str
    manifest_hash: str
    n: int
    metrics: dict[str, Any]
    per_example: list[ExampleResult] = field(default_factory=list)


class EvalRunner:
    """Run a golden set through one of the three call sites."""

    def __init__(
        self,
        *,
        service: "CambiumService",
        domain: str,
        manifest: Manifest,
        claude_client: Any | None = None,
    ) -> None:
        self.service = service
        self.domain = domain
        self.manifest = manifest
        self.claude_client = claude_client

    # ----------------------------------------------------------- classifier

    def run_classifier(self, golden: GoldenSet) -> EvalReport:
        from cambium.call_sites.classifier import run_classifier

        config = self.service.get_domain_config(self.domain)
        predictions: list[str] = []
        confidences: list[float] = []
        outcomes: list[int] = []
        expected: list[str] = []
        per_example: list[ExampleResult] = []
        for ex in golden.examples:
            event = _event_from_golden(ex.input.get("event", {}))
            identity = _identity_stub(event.user_id_hash, self.domain)
            out = run_classifier(
                identity=identity,
                event=event,
                domain_config=config,
                manifest=self.manifest,
                claude_client=self.claude_client,
            )
            pred = out["semantic_category"]
            predictions.append(pred)
            confidences.append(out["confidence"])
            exp = ex.expected.get("semantic_category", "")
            expected.append(exp)
            correct = int(pred == exp)
            outcomes.append(correct)
            per_example.append(
                ExampleResult(
                    id=ex.id, predicted=out, expected=ex.expected, correct=bool(correct)
                )
            )
        return EvalReport(
            call_site="classifier",
            domain=self.domain,
            manifest_hash=self.manifest.content_hash(),
            n=len(golden),
            metrics={
                "accuracy": accuracy(predictions, expected),
                "macro_f1": macro_f1(predictions, expected),
                "calibration": calibration_report(confidences, outcomes).model_dump(mode="json"),
            },
            per_example=per_example,
        )

    # ------------------------------------------------------------- reasoner

    def run_reasoner(self, golden: GoldenSet) -> EvalReport:
        from cambium.call_sites.reasoner import run_reasoner
        from cambium.core.types import ClassifiedEvent

        config = self.service.get_domain_config(self.domain)
        baseline = self.service.domain_registry().get_baseline(self.domain)
        predictions: list[float] = []
        expected_scores: list[float] = []
        cite_iou: list[float] = []
        per_example: list[ExampleResult] = []
        for ex in golden.examples:
            event = _event_from_golden(ex.input.get("event", {}))
            identity = _identity_stub(event.user_id_hash, self.domain)
            classified = ClassifiedEvent(
                event_id=event.event_id,
                semantic_category=ex.input.get("classified", {}).get(
                    "semantic_category", "routine_essential"
                ),
                confidence=ex.input.get("classified", {}).get("confidence", 0.7),
                confidence_band="medium",
                structural_validity=True,
            )
            baseline_score = 0.0
            if baseline is not None:
                baseline_score = baseline.score(identity, event, classified.semantic_category)
            out = run_reasoner(
                identity=identity,
                event=event,
                classified=classified,
                baseline=baseline_score,
                domain_config=config,
                manifest=self.manifest,
                claude_client=self.claude_client,
            )
            adj = out["reasoner_adjustment"]
            predicted_score = max(-1.0, min(1.0, baseline_score + adj))
            predictions.append(predicted_score)
            exp_score = float(ex.expected.get("score", 0.0))
            expected_scores.append(exp_score)
            cite_iou.append(
                iou(out["dimensions_cited"], ex.expected.get("dimensions_cited", []))
            )
            per_example.append(
                ExampleResult(
                    id=ex.id, predicted=out, expected=ex.expected, correct=False
                )
            )
        return EvalReport(
            call_site="reasoner",
            domain=self.domain,
            manifest_hash=self.manifest.content_hash(),
            n=len(golden),
            metrics={
                "score": {"mae": mean_absolute_error(predictions, expected_scores)},
                "direction_agreement": direction_agreement(predictions, expected_scores),
                "dimension_iou_mean": sum(cite_iou) / len(cite_iou) if cite_iou else 0.0,
            },
            per_example=per_example,
        )

    # ---------------------------------------------------------- synthesizer

    def run_synthesizer(self, golden: GoldenSet) -> EvalReport:
        from cambium.call_sites.synthesizer import run_synthesizer
        from datetime import datetime, timezone

        config = self.service.get_domain_config(self.domain)
        judge_scores: list[float] = []
        per_example: list[ExampleResult] = []
        for ex in golden.examples:
            events_data = ex.input.get("events", [])
            scores_data = ex.input.get("scores", [])
            events = [_event_from_golden(e) for e in events_data]
            scores = [_score_from_golden(s, self.domain) for s in scores_data]
            window_start = datetime.fromisoformat(
                ex.input.get("window_start", datetime.now(timezone.utc).isoformat())
            )
            window_end = datetime.fromisoformat(
                ex.input.get("window_end", datetime.now(timezone.utc).isoformat())
            )
            identity = _identity_stub(events[0].user_id_hash if events else "h", self.domain)
            out = run_synthesizer(
                identity=identity,
                scores=scores,
                events=events,
                window_start=window_start,
                window_end=window_end,
                domain_config=config,
                manifest=self.manifest,
                claude_client=self.claude_client,
            )
            judge = ex.expected.get("judge_overall", 0.0)
            judge_scores.append(float(judge))
            per_example.append(
                ExampleResult(id=ex.id, predicted=out, expected=ex.expected, correct=False)
            )
        mean_judge = sum(judge_scores) / len(judge_scores) if judge_scores else 0.0
        return EvalReport(
            call_site="synthesizer",
            domain=self.domain,
            manifest_hash=self.manifest.content_hash(),
            n=len(golden),
            metrics={"judge_mean_overall": mean_judge},
            per_example=per_example,
        )


def _event_from_golden(data: dict[str, Any]) -> BehavioralEvent:
    from datetime import datetime

    return BehavioralEvent(
        event_id=data["event_id"],
        user_id_hash=data["user_id_hash"],
        domain=data["domain"],
        event_type=data["event_type"],
        timestamp=datetime.fromisoformat(data["timestamp"]),
        magnitude=Decimal(str(data["magnitude"])),
        description=data["description"],
        raw=data.get("raw", {}),
    )


def _score_from_golden(data: dict[str, Any], domain: str):
    from cambium.core.types import CoherenceScore

    return CoherenceScore(
        event_id=data["event_id"],
        user_id_hash=data.get("user_id_hash", "h"),
        domain=domain,
        deterministic_baseline=data.get("baseline", 0.0),
        reasoner_adjustment=data.get("reasoner_adjustment", 0.0),
        score=data.get("score", 0.0),
        confidence=data.get("confidence", 0.6),
        dimensions_cited=tuple(data.get("dimensions_cited", [])),
        justification=data.get("justification", ""),
    )


def _identity_stub(user_id_hash: str, domain: str) -> IdentityProfile:
    from datetime import datetime, timezone

    return IdentityProfile(
        schema_version=f"{domain}.dna.v1.0.0",
        domain=domain,
        user_id_hash=user_id_hash,
        dimensions={d: 0.6 for d in (
            "future_orientation", "risk_tolerance", "family_orientation",
            "self_efficacy", "status_orientation", "stability_orientation",
            "experiential_orientation", "generosity_orientation",
            "financial_self_awareness", "spending_intentionality",
        )},
        narrative_tags=(),
        captured_at=datetime.now(timezone.utc),
    )


__all__ = ["EvalReport", "EvalRunner", "ExampleResult"]
