"""Golden sets and golden examples.

Versioned JSONL of labeled examples. Each example carries (input,
expected, labeler, rationale, version_added, adversarial flag, tags,
optional embedding).

Loaded from a JSONL file or constructed in code for tests. Removal is
tombstoning (`tags: ["deprecated"]`) — never deletion.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence


@dataclass(frozen=True)
class GoldenExample:
    id: str
    domain: str
    call_site: str
    version_added: str
    labeler: str
    rationale: str
    input: dict[str, Any]
    expected: dict[str, Any]
    adversarial: bool = False
    tags: tuple[str, ...] = ()
    embedding: tuple[float, ...] | None = None


@dataclass
class GoldenSet:
    """Mutable collection of golden examples, scoped to one call site."""

    examples: list[GoldenExample] = field(default_factory=list)
    version: str = "v1"

    @classmethod
    def load_jsonl(cls, path: Path | str, *, call_site: str | None = None) -> "GoldenSet":
        path = Path(path)
        examples: list[GoldenExample] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if call_site is not None and row.get("call_site") != call_site:
                continue
            examples.append(
                GoldenExample(
                    id=row["id"],
                    domain=row["domain"],
                    call_site=row["call_site"],
                    version_added=row.get("version_added", "v1"),
                    labeler=row.get("labeler", "unknown"),
                    rationale=row.get("rationale", ""),
                    input=row.get("input", {}),
                    expected=row.get("expected", {}),
                    adversarial=bool(row.get("adversarial", False)),
                    tags=tuple(row.get("tags", [])),
                    embedding=tuple(row["embedding"]) if row.get("embedding") else None,
                )
            )
        return cls(examples=examples, version=path.stem)

    def filter(self, *, tag: str | None = None, adversarial: bool | None = None) -> "GoldenSet":
        out = list(self.examples)
        if tag is not None:
            out = [e for e in out if tag in e.tags]
        if adversarial is not None:
            out = [e for e in out if e.adversarial == adversarial]
        return GoldenSet(examples=out, version=self.version)

    def active(self) -> "GoldenSet":
        """Drop deprecated examples."""
        return self.filter(tag="deprecated") and GoldenSet(
            examples=[e for e in self.examples if "deprecated" not in e.tags],
            version=self.version,
        )

    def __len__(self) -> int:
        return len(self.examples)

    def __iter__(self) -> Iterable[GoldenExample]:
        return iter(self.examples)


__all__ = ["GoldenExample", "GoldenSet"]
