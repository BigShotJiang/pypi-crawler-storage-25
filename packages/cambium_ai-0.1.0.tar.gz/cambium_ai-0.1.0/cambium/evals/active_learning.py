"""Active learning queue + selection strategies.

Five strategies:
- low_confidence: classifier confidence below threshold
- judge_disagreement: consensus disagreement above tolerance
- direction_flip: reasoner pushed baseline across zero
- novel_pattern: an example whose embedding sits far from existing
  golden examples
- user_negative_signal: user feedback marked the insight as off

Selected candidates land in a JSONL queue; reviewers label them; the
labeled examples join the next golden-set version.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Literal

Strategy = Literal[
    "low_confidence",
    "judge_disagreement",
    "direction_flip",
    "novel_pattern",
    "user_negative_signal",
]


@dataclass
class Candidate:
    candidate_id: str
    strategy: Strategy
    call_site: Literal["classifier", "reasoner", "synthesizer"]
    trace_id: str
    domain: str
    priority: Literal["low", "normal", "high"] = "normal"
    reason: str = ""
    metadata: dict = field(default_factory=dict)


class ActiveLearningQueue:
    """Append-only JSONL queue. Production replaces this with a Timber table."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def enqueue(self, candidate: Candidate) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(candidate)))
            f.write("\n")

    def list(self) -> list[Candidate]:
        if not self.path.exists():
            return []
        out: list[Candidate] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            out.append(Candidate(**row))
        return out


# ---------------------------------------------------------------------------
# Selection strategies
# ---------------------------------------------------------------------------


def select_low_confidence(
    rows: Iterable[dict], *, threshold: float = 0.5
) -> list[Candidate]:
    out: list[Candidate] = []
    for r in rows:
        conf = r.get("structured_output", {}).get("confidence", 1.0)
        if conf < threshold:
            out.append(
                Candidate(
                    candidate_id=r["trace_id"],
                    strategy="low_confidence",
                    call_site=r["call_site"],
                    trace_id=r["trace_id"],
                    domain=r["domain"],
                    reason=f"confidence {conf:.2f} below {threshold}",
                )
            )
    return out


def select_direction_flip(rows: Iterable[dict]) -> list[Candidate]:
    out: list[Candidate] = []
    for r in rows:
        if r.get("call_site") != "reasoner":
            continue
        body = r.get("structured_output", {})
        baseline = body.get("deterministic_baseline", 0.0)
        score = body.get("score", 0.0)
        if (baseline > 0 and score < 0) or (baseline < 0 and score > 0):
            out.append(
                Candidate(
                    candidate_id=r["trace_id"],
                    strategy="direction_flip",
                    call_site="reasoner",
                    trace_id=r["trace_id"],
                    domain=r["domain"],
                    reason=f"flipped from {baseline:+.2f} to {score:+.2f}",
                )
            )
    return out


def select_judge_disagreement(
    rows: Iterable[dict], *, tolerance: float = 0.2
) -> list[Candidate]:
    out: list[Candidate] = []
    for r in rows:
        body = r.get("structured_output", {})
        primary = body.get("primary_score")
        secondary = body.get("secondary_score")
        if primary is None or secondary is None:
            continue
        if abs(primary - secondary) > tolerance:
            out.append(
                Candidate(
                    candidate_id=r["trace_id"],
                    strategy="judge_disagreement",
                    call_site="synthesizer",
                    trace_id=r["trace_id"],
                    domain=r["domain"],
                    reason=f"|p−s| = {abs(primary - secondary):.2f}",
                )
            )
    return out


__all__ = [
    "ActiveLearningQueue",
    "Candidate",
    "Strategy",
    "select_direction_flip",
    "select_judge_disagreement",
    "select_low_confidence",
]
