"""Drift detection — PSI and KL divergence.

PSI = sum( (actual_pct - expected_pct) * ln(actual_pct / expected_pct) )
over fixed bins. Standard interpretation:
- PSI < 0.1: no significant change
- PSI < 0.25: minor change
- PSI ≥ 0.25: significant change (alert)

KL divergence over a category distribution provides a categorical
analogue for the classifier's output histogram.
"""

from __future__ import annotations

import math
from collections import Counter
from typing import Sequence


def population_stability_index(
    expected: Sequence[float],
    actual: Sequence[float],
    *,
    bins: int = 10,
    lo: float = -1.0,
    hi: float = 1.0,
) -> float:
    """Compute PSI over fixed equal-width bins."""
    if not expected or not actual:
        return 0.0
    width = (hi - lo) / bins
    edges = [lo + i * width for i in range(bins + 1)]

    def _hist(values: Sequence[float]) -> list[float]:
        counts = [0] * bins
        for v in values:
            if v < lo:
                counts[0] += 1
                continue
            if v >= hi:
                counts[-1] += 1
                continue
            idx = min(int((v - lo) / width), bins - 1)
            counts[idx] += 1
        total = max(sum(counts), 1)
        return [max(c / total, 1e-6) for c in counts]

    e = _hist(expected)
    a = _hist(actual)
    return sum((ai - ei) * math.log(ai / ei) for ei, ai in zip(e, a))


def kl_divergence(
    expected_categories: Sequence[str], actual_categories: Sequence[str]
) -> float:
    """KL(actual || expected) over categorical distributions."""
    if not expected_categories or not actual_categories:
        return 0.0
    e_counts = Counter(expected_categories)
    a_counts = Counter(actual_categories)
    categories = set(e_counts) | set(a_counts)
    e_total = max(sum(e_counts.values()), 1)
    a_total = max(sum(a_counts.values()), 1)
    kl = 0.0
    for cat in categories:
        p = max(a_counts.get(cat, 0) / a_total, 1e-6)
        q = max(e_counts.get(cat, 0) / e_total, 1e-6)
        kl += p * math.log(p / q)
    return kl


def drift_severity(psi: float, kl: float = 0.0) -> str:
    if psi >= 0.25 or kl >= 0.5:
        return "alert"
    if psi >= 0.1 or kl >= 0.2:
        return "warning"
    return "info"


__all__ = ["drift_severity", "kl_divergence", "population_stability_index"]
