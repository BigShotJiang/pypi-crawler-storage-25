"""Eval metrics in pure Python.

- macro F1 (multi-class classifier)
- mean absolute error
- direction agreement
- IoU on dimension citation
"""

from __future__ import annotations

from collections import Counter
from typing import Sequence


def macro_f1(predictions: Sequence[str], expected: Sequence[str]) -> float:
    """Macro-averaged F1. Each class weighted equally."""
    if not predictions:
        return 0.0
    classes = set(predictions) | set(expected)
    f1s = []
    for cls in classes:
        tp = sum(1 for p, e in zip(predictions, expected) if p == cls and e == cls)
        fp = sum(1 for p, e in zip(predictions, expected) if p == cls and e != cls)
        fn = sum(1 for p, e in zip(predictions, expected) if p != cls and e == cls)
        if tp == 0:
            f1s.append(0.0)
            continue
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        if prec + rec == 0:
            f1s.append(0.0)
        else:
            f1s.append(2 * prec * rec / (prec + rec))
    return sum(f1s) / len(f1s) if f1s else 0.0


def accuracy(predictions: Sequence, expected: Sequence) -> float:
    if not predictions:
        return 0.0
    return sum(1 for p, e in zip(predictions, expected) if p == e) / len(predictions)


def mean_absolute_error(predictions: Sequence[float], expected: Sequence[float]) -> float:
    if not predictions:
        return 0.0
    return sum(abs(p - e) for p, e in zip(predictions, expected)) / len(predictions)


def direction_agreement(predictions: Sequence[float], expected: Sequence[float]) -> float:
    """Fraction where sign(prediction) == sign(expected) (zero treated as 0)."""
    if not predictions:
        return 0.0

    def _sign(x: float) -> int:
        if x > 1e-6:
            return 1
        if x < -1e-6:
            return -1
        return 0

    return sum(1 for p, e in zip(predictions, expected) if _sign(p) == _sign(e)) / len(predictions)


def iou(a: Sequence[str], b: Sequence[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    return len(sa & sb) / max(len(sa | sb), 1)


def class_balance(values: Sequence[str]) -> dict[str, int]:
    return dict(Counter(values))


__all__ = [
    "accuracy",
    "class_balance",
    "direction_agreement",
    "iou",
    "macro_f1",
    "mean_absolute_error",
]
