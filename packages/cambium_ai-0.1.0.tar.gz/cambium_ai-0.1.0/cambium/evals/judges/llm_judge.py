"""LLM judge — scores a synthesizer output against a six-dimension rubric."""

from __future__ import annotations

from typing import Any

from cambium.claude.client import get_default_claude_client

JUDGE_SYSTEM = """\
You are a judge scoring a coherence insight against a six-dimension rubric:
- evidence: are the cited events and dimensions specific and plausible?
- fidelity: does the insight reflect the actual scores and patterns?
- tone: does the chosen tone match the data?
- specificity: is the language concrete (vs. generic)?
- actionability: are suggested_actions usable, kind, and proportional?
- respect: is the user treated as an adult?

Each in [0, 1]. Return strict JSON with rubric_scores (dict) and overall (mean).
"""


def judge_synthesizer(
    *, insight: dict[str, Any], judge_model: str, claude_client: Any | None = None
) -> dict[str, Any]:
    client = claude_client or get_default_claude_client()
    prompt = (
        "Insight to score:\n"
        f"headline: {insight.get('headline','')}\n"
        f"body: {insight.get('body','')}\n"
        f"tone: {insight.get('tone','neutral')}\n"
        f"referenced_event_ids: {insight.get('referenced_event_ids',[])}\n"
        f"referenced_dimensions: {insight.get('referenced_dimensions',[])}\n"
        f"suggested_actions: {insight.get('suggested_actions',[])}\n"
    )
    response = client.complete_structured(
        model=judge_model, system=JUDGE_SYSTEM, prompt=prompt, temperature=0.0
    )
    return response.structured


__all__ = ["judge_synthesizer"]
