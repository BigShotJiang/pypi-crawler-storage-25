"""Deterministic judges — pure comparison of predicted vs expected."""

from __future__ import annotations

from typing import Any

from cambium.evals.metrics import iou


def judge_classifier_deterministic(
    *, predicted: dict[str, Any], expected: dict[str, Any]
) -> dict[str, Any]:
    return {
        "category_match": predicted.get("semantic_category") == expected.get("semantic_category"),
        "confidence_band_match": predicted.get("confidence_band") == expected.get("confidence_band"),
    }


def judge_reasoner_deterministic(
    *, predicted: dict[str, Any], expected: dict[str, Any]
) -> dict[str, Any]:
    pred_score = float(predicted.get("score", 0.0))
    exp_score = float(expected.get("score", 0.0))
    return {
        "score_mae": abs(pred_score - exp_score),
        "direction_agreement": (
            (pred_score > 0 and exp_score > 0)
            or (pred_score < 0 and exp_score < 0)
            or (pred_score == 0 and exp_score == 0)
        ),
        "dimension_iou": iou(
            predicted.get("dimensions_cited", []),
            expected.get("dimensions_cited", []),
        ),
    }


__all__ = ["judge_classifier_deterministic", "judge_reasoner_deterministic"]
