"""Consensus judge — two LLM judges + disagreement routing."""

from __future__ import annotations

from typing import Any

from cambium.claude.consensus import consensus_score


def judge_with_consensus(
    *,
    insight: dict[str, Any],
    primary_model: str,
    secondary_model: str,
    tolerance: float = 0.2,
    claude_client: Any | None = None,
) -> dict[str, Any]:
    """Score with two judges; flag for active-learning if disagreement exceeds tolerance."""
    return consensus_score(
        insight=insight,
        primary_model=primary_model,
        secondary_model=secondary_model,
        tolerance=tolerance,
        claude_client=claude_client,
    )


__all__ = ["judge_with_consensus"]
