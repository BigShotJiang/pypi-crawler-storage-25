"""Pure functions that turn Cambium types into A2UI documents.

Renderers are deterministic and side-effect-free. They do not touch
the network or the database. Given the same insight + certificate,
they always produce the same A2UI document.

Surface renderers (Sky, email, voice, Slack) sit OUTSIDE this
package — they consume the A2UI document and render to their
surface. Cambium's audit boundary stops at this document.
"""

from __future__ import annotations

from cambium.a2ui.components import (
    A2UIDocument,
    CambiumInsightSpec,
    DimensionBadge,
    DimensionBadgesBlock,
    EventReference,
    EventReferencesBlock,
    FeedbackBlock,
    ProvenanceBlock,
    SuggestedActionsBlock,
    TextBlock,
)
from cambium.core.types import CoherenceScore, Insight, ProvenanceCertificate


def render_insight(
    *,
    insight: Insight,
    certificate: ProvenanceCertificate,
    scores: list[CoherenceScore] | None = None,
    verify_url: str | None = None,
) -> A2UIDocument:
    """Render a Cambium insight + provenance certificate as an A2UI document."""

    blocks: list = [
        TextBlock(role="headline", content=insight.headline),
        TextBlock(role="body", content=insight.body),
    ]

    if insight.referenced_dimensions:
        weights = _dimension_weights(scores or [], insight.referenced_dimensions)
        blocks.append(
            DimensionBadgesBlock(
                badges=tuple(
                    DimensionBadge(
                        name=name,
                        weight=weights.get(name, 0.5),
                        polarity="aligned" if weights.get(name, 0.0) > 0.6 else "neutral",
                    )
                    for name in insight.referenced_dimensions
                )
            )
        )

    if insight.referenced_event_ids and scores:
        score_by_event = {s.event_id: s for s in scores}
        blocks.append(
            EventReferencesBlock(
                events=tuple(
                    EventReference(
                        event_id=eid,
                        description=_describe_event(score_by_event.get(eid)),
                        sign=_score_sign(score_by_event.get(eid)),
                    )
                    for eid in insight.referenced_event_ids
                    if eid in score_by_event
                )
            )
        )

    if insight.suggested_actions:
        blocks.append(SuggestedActionsBlock(actions=tuple(insight.suggested_actions)))

    blocks.append(FeedbackBlock(insight_id=insight.insight_id))
    blocks.append(
        ProvenanceBlock(
            manifest_hash=certificate.manifest_hash,
            certificate_id=certificate.certificate_id,
            golden_set_version=certificate.golden_set_version,
            verify_url=verify_url,
        )
    )

    return A2UIDocument(
        spec=CambiumInsightSpec(
            insight_id=insight.insight_id,
            tone=insight.tone,
            blocks=tuple(blocks),
        ),
    )


def _describe_event(score: CoherenceScore | None) -> str:
    if score is None:
        return ""
    sign = "+" if score.score >= 0 else ""
    return f"{sign}{score.score:.2f}"


def _score_sign(score: CoherenceScore | None) -> str:
    if score is None or abs(score.score) < 0.05:
        return "neutral"
    return "positive" if score.score > 0 else "negative"


def _dimension_weights(
    scores: list[CoherenceScore], dimensions: tuple[str, ...]
) -> dict[str, float]:
    """Aggregate the citation frequency of each dimension across scores."""
    counts: dict[str, int] = {dim: 0 for dim in dimensions}
    for s in scores:
        for cited in s.dimensions_cited:
            if cited in counts:
                counts[cited] += 1
    total = max(sum(counts.values()), 1)
    return {dim: counts[dim] / total for dim in dimensions}


__all__ = ["render_insight"]
