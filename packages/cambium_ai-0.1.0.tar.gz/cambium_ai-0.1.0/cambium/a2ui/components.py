"""Typed block primitives for Cambium A2UI directives.

Wire-level compatible with ``acorn/models/a2ui.py``. Sky's
TypeScript twins (``src/components/a2ui/types.ts``) and Acorn's
Pydantic copies are kept in lockstep by the
``cambium-update-a2ui-contract`` developer skill (defined in this
package's ``skills/developer/`` directory).

Every block model is frozen + extra=forbid. The audit boundary of
the platform sits at the A2UI document, not at the rendered string:
provenance certificates reference A2UI documents, so the doc must
be deterministic.
"""

from __future__ import annotations

import uuid
from typing import Annotated, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field

InsightTone = Literal["affirming", "curious", "neutral"]
TextRole = Literal["headline", "subhead", "body", "caption", "meta"]


class TextBlock(BaseModel):
    """A paragraph of insight text in a particular role."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["text"] = "text"
    role: TextRole
    content: str


class DimensionBadge(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    weight: float = Field(ge=0.0, le=1.0)
    polarity: Literal["aligned", "neutral", "misaligned"] = "neutral"


class DimensionBadgesBlock(BaseModel):
    """A row of dimension badges with their weights/polarity."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["dimension_badges"] = "dimension_badges"
    badges: tuple[DimensionBadge, ...]


class EventReference(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str
    description: str
    sign: Literal["positive", "negative", "neutral"] = "neutral"


class EventReferencesBlock(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["event_references"] = "event_references"
    events: tuple[EventReference, ...]


class SuggestedActionsBlock(BaseModel):
    """Reflect / act / ask prompts attached to an insight."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["suggested_actions"] = "suggested_actions"
    actions: tuple[str, ...]


class FeedbackBlock(BaseModel):
    """Surface-native feedback affordance the user can engage."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["feedback"] = "feedback"
    insight_id: str
    options: tuple[str, ...] = (
        "landed",
        "did_not_land",
        "off_topic",
        "incorrect",
    )
    allow_comment: bool = True


class ProvenanceBlock(BaseModel):
    """A manifest-hash chip + verify affordance referencing a certificate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["provenance"] = "provenance"
    manifest_hash: str
    certificate_id: str
    golden_set_version: str
    verify_url: Optional[str] = None


Block = Annotated[
    Union[
        TextBlock,
        DimensionBadgesBlock,
        EventReferencesBlock,
        SuggestedActionsBlock,
        FeedbackBlock,
        ProvenanceBlock,
    ],
    Field(discriminator="type"),
]


class CambiumInsightSpec(BaseModel):
    """The ``spec`` payload for a ``render_cambium_insight`` directive."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    insight_id: str
    tone: InsightTone
    blocks: tuple[Block, ...]


class A2UIDocument(BaseModel):
    """The full A2UI directive Cambium emits for an insight.

    Compatible with the existing envelope in ``acorn/models/a2ui.py``:
    same ``directive_id``, ``version``, ``kind`` schema. The new
    ``kind`` value ``render_cambium_insight`` is dispatched by the
    Sky renderer to ``CambiumInsightRenderer.tsx``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    directive_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    version: str = "1"
    kind: Literal["render_cambium_insight"] = "render_cambium_insight"
    spec: CambiumInsightSpec


__all__ = [
    "A2UIDocument",
    "Block",
    "CambiumInsightSpec",
    "DimensionBadge",
    "DimensionBadgesBlock",
    "EventReference",
    "EventReferencesBlock",
    "FeedbackBlock",
    "InsightTone",
    "ProvenanceBlock",
    "SuggestedActionsBlock",
    "TextBlock",
    "TextRole",
]
