"""A2UI components for Cambium.

A2UI (Agent-to-UI) is the platform-wide protocol for typed, surface-
independent UI directives. Cambium emits an extension of the protocol
defined originally in ``acorn/models/a2ui.py``:

  - New directive ``kind`` value: ``render_cambium_insight``.
  - New block primitives: ``TextBlock``, ``DimensionBadgesBlock``,
    ``EventReferencesBlock``, ``SuggestedActionsBlock``,
    ``FeedbackBlock``, ``ProvenanceBlock``.

Sky's ``src/components/a2ui/`` ships matching TypeScript twins and a
``CambiumInsightRenderer`` that dispatches on block ``type``. Acorn's
``models/a2ui.py`` adds the same kinds and blocks server-side so the
chat envelope is fully typed end-to-end.
"""

from cambium.a2ui.components import (
    A2UIDocument,
    Block,
    CambiumInsightSpec,
    DimensionBadge,
    DimensionBadgesBlock,
    EventReference,
    EventReferencesBlock,
    FeedbackBlock,
    InsightTone,
    ProvenanceBlock,
    SuggestedActionsBlock,
    TextBlock,
    TextRole,
)
from cambium.a2ui.renderers import render_insight

__all__ = [
    "A2UIDocument",
    "Block",
    "CambiumInsightSpec",
    "DimensionBadge",
    "DimensionBadgesBlock",
    "EventReference",
    "EventReferencesBlock",
    "FeedbackBlock",
    "InsightTone",
    "ProvenanceBlock",
    "SuggestedActionsBlock",
    "TextBlock",
    "TextRole",
    "render_insight",
]
