"""Finance baseline scorer.

Computes a deterministic coherence baseline in [-1, 1] given an
identity profile, a behavioral event, and a semantic category. The
formula is intentionally simple:

  baseline = clip(
      sum( dimension_value * category_weight )
      * sign(category_valence)
      * magnitude_modifier,
      -1, 1,
  )

The IP value is in the *weights*, not the *formula*. Domain experts
can tune the weights without restructuring the spine.
"""

from __future__ import annotations

import math
from decimal import Decimal

from cambium.core.types import BehavioralEvent, IdentityProfile


# Per-category, per-dimension weights. Positive weight means the
# category aligns with that dimension; negative means it pulls
# against. Tuned by hand against the finance v1 golden seed.
CATEGORY_DIMENSION_WEIGHTS: dict[str, dict[str, float]] = {
    "investment_aligned": {
        "future_orientation": 0.40,
        "self_efficacy": 0.20,
        "spending_intentionality": 0.25,
        "stability_orientation": 0.15,
    },
    "planning_active": {
        "future_orientation": 0.30,
        "financial_self_awareness": 0.30,
        "spending_intentionality": 0.20,
        "self_efficacy": 0.20,
    },
    "routine_essential": {
        "stability_orientation": 0.50,
        "spending_intentionality": 0.30,
        "family_orientation": 0.20,
    },
    "routine_discretionary": {
        "experiential_orientation": 0.30,
        "spending_intentionality": -0.10,
        "stability_orientation": 0.10,
    },
    "status_signaling": {
        "status_orientation": 0.40,
        "future_orientation": -0.30,
        "spending_intentionality": -0.20,
        "financial_self_awareness": -0.10,
    },
    "impulse": {
        "spending_intentionality": -0.40,
        "financial_self_awareness": -0.20,
        "future_orientation": -0.20,
    },
    "generosity": {
        "generosity_orientation": 0.50,
        "family_orientation": 0.20,
    },
    "celebration": {
        "experiential_orientation": 0.40,
        "family_orientation": 0.20,
    },
    "debt_service": {
        "stability_orientation": 0.20,
        "financial_self_awareness": 0.20,
        "future_orientation": 0.10,
    },
    "emergency": {
        "stability_orientation": -0.20,
        "spending_intentionality": -0.10,
    },
    "transfer_internal": {
        "spending_intentionality": 0.20,
        "stability_orientation": 0.20,
    },
    "income": {"self_efficacy": 0.20},
    "escape_spending": {
        "spending_intentionality": -0.30,
        "financial_self_awareness": -0.20,
        "experiential_orientation": 0.10,
    },
}


# Category valence: does the category default to positive or negative
# coherence given a mainstream identity profile?
CATEGORY_VALENCE: dict[str, int] = {
    "investment_aligned": +1,
    "planning_active": +1,
    "routine_essential": +1,
    "routine_discretionary": 0,
    "status_signaling": -1,
    "impulse": -1,
    "generosity": +1,
    "celebration": +1,
    "debt_service": +1,
    "emergency": 0,
    "transfer_internal": +1,
    "income": +1,
    "escape_spending": -1,
}


class FinanceBaseline:
    """Deterministic baseline scorer for the finance domain."""

    def score(
        self,
        identity: IdentityProfile,
        event: BehavioralEvent,
        semantic_category: str,
    ) -> float:
        weights = CATEGORY_DIMENSION_WEIGHTS.get(semantic_category, {})
        if not weights:
            return 0.0
        dim_score = 0.0
        for dim, weight in weights.items():
            value = identity.dimensions.get(dim, 0.5)
            dim_score += weight * (value - 0.5) * 2  # remap [0,1] → [-1, +1]
        # Apply category valence.
        valence = CATEGORY_VALENCE.get(semantic_category, 0)
        if valence != 0:
            # Pull the score toward the valence, but don't override the signal.
            dim_score = 0.6 * dim_score + 0.4 * valence
        # Magnitude modifier — bigger events have slightly higher signal.
        magnitude_modifier = _magnitude_modifier(event.magnitude)
        out = dim_score * magnitude_modifier
        return max(-1.0, min(1.0, out))


def _magnitude_modifier(magnitude: Decimal | float | int) -> float:
    abs_value = abs(float(magnitude))
    # Logistic over [0, ~$2000]; never goes above 1.4.
    return 1.0 + 0.4 / (1 + math.exp(-(abs_value - 500) / 300))


__all__ = ["CATEGORY_DIMENSION_WEIGHTS", "CATEGORY_VALENCE", "FinanceBaseline"]
