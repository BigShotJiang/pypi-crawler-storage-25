"""Finance event adapters.

Translate raw signal-source payloads (Plaid transactions, recurring
ACH transfers, manual entries) into Cambium's domain-agnostic
``BehavioralEvent`` shape.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from cambium.core.types import BehavioralEvent


def from_plaid_transaction(
    *,
    user_id_hash: str,
    plaid_payload: dict[str, Any],
) -> BehavioralEvent:
    """Normalize a Plaid transaction into a BehavioralEvent."""
    timestamp = _parse_timestamp(plaid_payload.get("date") or plaid_payload.get("authorized_date"))
    magnitude = Decimal(str(plaid_payload.get("amount", "0")))
    name = plaid_payload.get("merchant_name") or plaid_payload.get("name") or ""
    category = plaid_payload.get("category") or []
    description = f"{name} [{' / '.join(category)}]" if category else name
    return BehavioralEvent(
        event_id=str(plaid_payload.get("transaction_id", "")),
        user_id_hash=user_id_hash,
        domain="finance",
        event_type="transaction",
        timestamp=timestamp,
        magnitude=magnitude,
        description=description,
        raw={
            "plaid_category": list(category),
            "merchant": name,
            "account_id": plaid_payload.get("account_id"),
            "iso_currency_code": plaid_payload.get("iso_currency_code"),
        },
    )


def from_recurring_contribution(
    *,
    user_id_hash: str,
    description: str,
    amount: float,
    timestamp: datetime,
    event_id: str,
) -> BehavioralEvent:
    return BehavioralEvent(
        event_id=event_id,
        user_id_hash=user_id_hash,
        domain="finance",
        event_type="recurring_contribution",
        timestamp=timestamp,
        magnitude=Decimal(str(amount)),
        description=description,
        raw={"channel": "recurring"},
    )


def _parse_timestamp(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        # Plaid often sends date as YYYY-MM-DD.
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return datetime.fromisoformat(value + "T00:00:00+00:00")
    raise ValueError(f"Cannot parse timestamp: {value!r}")


__all__ = ["from_plaid_transaction", "from_recurring_contribution"]
