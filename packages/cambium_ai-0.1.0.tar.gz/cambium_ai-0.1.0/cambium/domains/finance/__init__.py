"""Finance domain — Cambium plugin #1.

Stated identity: Financial DNA Protocol (16-screen psychometric
assessment, authored by Acorn / Grove's FDNA workflow).
Revealed behavior: Plaid transactions.

Loads via ``service.domain_registry().register_from_yaml(Path('config.yaml'))``.
"""
