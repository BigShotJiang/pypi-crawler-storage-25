"""Financial DNA Protocol identity capture.

The 16-screen instrument lives operationally in Grove's
``financial_dna_evaluation_workflow.yaml``. This module is the
*reducer*: it takes the screen-by-screen responses and produces an
``IdentityProfile`` Cambium can consume.

Each screen contributes weighted points to one or more dimensions. The
weights are deliberately simple — the IP value of the instrument is
in the screens themselves (the questions, the contrasts, the framing),
not in the reduction.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from cambium.core.types import IdentityProfile

# Per-screen dimension contributions. Each entry is
# {screen_id: {dimension: weight}}; the user's response score per
# question (in [0,1]) is multiplied by the weight; results aggregate
# across screens.
SCREEN_DIMENSION_WEIGHTS: dict[str, dict[str, float]] = {
    "s01": {"future_orientation": 0.20, "spending_intentionality": 0.15},  # Source Code
    "s02": {"future_orientation": 0.35, "stability_orientation": 0.10},   # Horizon
    "s03": {"financial_self_awareness": 0.30},                            # Reality Check
    "s04": {"risk_tolerance": 0.25, "spending_intentionality": 0.10},     # Trap Door
    "s05": {"financial_self_awareness": 0.20},                            # Verification
    "s06": {"future_orientation": 0.15, "generosity_orientation": 0.15},  # Windfall
    "s07": {"family_orientation": 0.20, "stability_orientation": 0.15},   # Buckets
    "s08": {"family_orientation": 0.30, "generosity_orientation": 0.15},  # Inheritance
    "s09": {"status_orientation": 0.30, "experiential_orientation": 0.10},# Dinner Party
    "s10": {"risk_tolerance": 0.20, "financial_self_awareness": 0.15},    # Regret Duality
    "s11": {"financial_self_awareness": 0.25, "spending_intentionality": 0.20},  # Fog
    "s12": {"risk_tolerance": 0.30, "stability_orientation": 0.20},       # Crash
    "s13": {"risk_tolerance": 0.20, "experiential_orientation": 0.15},    # Rally
    "s14": {"generosity_orientation": 0.20, "status_orientation": 0.10},  # Moral Ledger
    "s15": {"self_efficacy": 0.30, "financial_self_awareness": 0.20},     # Cockpit
    "s16": {"self_efficacy": 0.20, "spending_intentionality": 0.20},      # Mirror
}


@dataclass
class ScreenResponse:
    """One screen's response payload — dict of question_id → score in [0,1]."""

    screen_id: str
    answers: dict[str, float]

    def mean(self) -> float:
        if not self.answers:
            return 0.5
        return sum(self.answers.values()) / len(self.answers)


@dataclass
class FinancialDNACapture:
    """Reducer from screen responses to an IdentityProfile."""

    def reduce(
        self,
        *,
        user_id_hash: str,
        screens: list[ScreenResponse],
        captured_at: datetime | None = None,
        narrative_tags: tuple[str, ...] = (),
        domain_data: dict[str, Any] | None = None,
    ) -> IdentityProfile:
        dimensions: dict[str, float] = {}
        for dim in {d for s in screens for d in SCREEN_DIMENSION_WEIGHTS.get(s.screen_id, {})}:
            dimensions[dim] = 0.5  # neutral prior
        for screen in screens:
            weights = SCREEN_DIMENSION_WEIGHTS.get(screen.screen_id, {})
            for dim, weight in weights.items():
                dimensions.setdefault(dim, 0.5)
                # Move dimension toward the screen's mean, weighted.
                dimensions[dim] = (dimensions[dim] + screen.mean() * weight) / (1 + weight)
        # Clamp to [0, 1]
        for dim in dimensions:
            dimensions[dim] = max(0.0, min(1.0, dimensions[dim]))
        # Ensure all 10 finance dimensions are present.
        all_dims = (
            "future_orientation", "risk_tolerance", "family_orientation",
            "self_efficacy", "status_orientation", "stability_orientation",
            "experiential_orientation", "generosity_orientation",
            "financial_self_awareness", "spending_intentionality",
        )
        for dim in all_dims:
            dimensions.setdefault(dim, 0.5)
        return IdentityProfile(
            schema_version="finance.dna.v1.0.0",
            domain="finance",
            user_id_hash=user_id_hash,
            dimensions=dimensions,
            narrative_tags=narrative_tags,
            captured_at=captured_at or datetime.now(timezone.utc),
            domain_data=domain_data,
        )


def from_grove_session(payload: dict[str, Any]) -> IdentityProfile:
    """Construct an IdentityProfile from a Grove FinancialDNASession payload.

    Grove's ``financial_dna_evaluation_workflow`` produces a session
    payload with the 16 screens completed; this helper translates that
    payload into Cambium's IdentityProfile shape.
    """
    screens = [
        ScreenResponse(screen_id=screen["id"], answers=screen.get("answers", {}))
        for screen in payload.get("screens", [])
    ]
    return FinancialDNACapture().reduce(
        user_id_hash=payload["user_id_hash"],
        screens=screens,
        narrative_tags=tuple(payload.get("narrative_tags", [])),
        domain_data=payload.get("derived"),
    )


__all__ = ["FinancialDNACapture", "ScreenResponse", "from_grove_session"]
