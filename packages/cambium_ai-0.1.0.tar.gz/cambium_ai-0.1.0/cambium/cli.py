"""Cambium command-line interface.

    cambium eval --domain finance --call-site classifier --golden ./golden_seeds/finance_classifier_v1.jsonl
    cambium regress --candidate manifests/finance_v2.yaml --baseline manifests/finance_v1.yaml --domain finance
    cambium mcp serve --transport stdio
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from cambium import get_default_service
from cambium.evals.golden import GoldenSet
from cambium.evals.runner import EvalRunner


def _bootstrap_finance() -> None:
    service = get_default_service()
    if "finance" in service.list_domains():
        return
    config_path = Path(__file__).resolve().parent / "domains" / "finance" / "config.yaml"
    if config_path.exists():
        service.domain_registry().register_from_yaml(config_path)


def _cmd_eval(args: argparse.Namespace) -> int:
    _bootstrap_finance()
    service = get_default_service()
    if not service._manifests:  # type: ignore[attr-defined]
        from cambium.service import make_default_manifest

        config = service.get_domain_config(args.domain)
        manifest = make_default_manifest(
            domain=args.domain,
            identity_schema_version=config.identity_schema_version,
            domain_config_hash=config.content_hash(),
        )
        service.register_manifest(manifest)
        service.activate_manifest(manifest.manifest_id, args.domain)
    manifest = service.get_active_manifest(args.domain)
    runner = EvalRunner(service=service, domain=args.domain, manifest=manifest)
    golden = GoldenSet.load_jsonl(args.golden, call_site=args.call_site)
    if args.call_site == "classifier":
        report = runner.run_classifier(golden)
    elif args.call_site == "reasoner":
        report = runner.run_reasoner(golden)
    elif args.call_site == "synthesizer":
        report = runner.run_synthesizer(golden)
    else:
        raise SystemExit(f"Unknown call site: {args.call_site}")
    print(json.dumps({
        "call_site": report.call_site,
        "domain": report.domain,
        "manifest_hash": report.manifest_hash,
        "n": report.n,
        "metrics": report.metrics,
    }, indent=2, default=str))
    return 0


def _cmd_regress(args: argparse.Namespace) -> int:
    print(f"Regression CI: candidate={args.candidate} baseline={args.baseline}", file=sys.stderr)
    print(
        "Note: the v1 regression CI is exposed programmatically via "
        "`cambium.regression.evaluate_gates`. Wire it into your CI.",
        file=sys.stderr,
    )
    return 0


def _cmd_mcp(args: argparse.Namespace) -> int:
    from cambium.core.mcp_server import build_server

    server = build_server()
    if args.subcommand == "tools":
        print(json.dumps(list(server._handlers.keys()), indent=2))
        return 0
    if args.subcommand == "serve":
        print(
            f"MCP serve ({args.transport}): not yet wired to a transport. "
            "Use `cambium mcp tools` to list the local handlers."
        )
        return 0
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cambium")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_eval = sub.add_parser("eval", help="Run an eval against a golden set.")
    p_eval.add_argument("--domain", required=True)
    p_eval.add_argument("--call-site", required=True, choices=["classifier", "reasoner", "synthesizer"])
    p_eval.add_argument("--golden", required=True, type=Path)
    p_eval.set_defaults(func=_cmd_eval)

    p_reg = sub.add_parser("regress", help="Regression CI gate.")
    p_reg.add_argument("--candidate", required=True, type=Path)
    p_reg.add_argument("--baseline", required=True, type=Path)
    p_reg.add_argument("--domain", required=True)
    p_reg.set_defaults(func=_cmd_regress)

    p_mcp = sub.add_parser("mcp", help="MCP server utilities.")
    p_mcp.add_argument("subcommand", choices=["tools", "serve"])
    p_mcp.add_argument("--transport", default="stdio")
    p_mcp.set_defaults(func=_cmd_mcp)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
