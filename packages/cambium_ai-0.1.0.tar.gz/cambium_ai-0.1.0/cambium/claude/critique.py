"""Constitutional self-critique pass on the reasoner.

The critique can ONLY weaken adjustments toward zero. Strengthening is
forbidden by the prompt and enforced post-hoc by clamping.
"""

from __future__ import annotations

from typing import Any

from cambium.claude.client import get_default_claude_client

CRITIQUE_SYSTEM = """\
You are reviewing a previous reasoner pass against a constitution that asks for
conservative, evidence-grounded, non-judgmental adjustments to a deterministic
baseline. You may ONLY weaken the adjustment toward zero. You may NEVER
strengthen it. If the adjustment is already conservative, return it unchanged.
Output strict JSON with keys: reasoner_adjustment, dimensions_cited,
justification, confidence.
"""


def critique_reasoner(
    reasoner_out: dict[str, Any],
    *,
    claude_client: Any | None = None,
    constitution: str = "default",
) -> dict[str, Any]:
    """Apply a constitutional critique. Weakens only; never strengthens."""
    client = claude_client or get_default_claude_client()
    original_adj = float(reasoner_out.get("reasoner_adjustment", 0.0))
    prompt = (
        f"Constitution: {constitution}\n\n"
        f"Original reasoner output:\n"
        f"reasoner_adjustment: {original_adj}\n"
        f"dimensions_cited: {reasoner_out.get('dimensions_cited', [])}\n"
        f"justification: {reasoner_out.get('justification', '')}\n\n"
        "Critique the adjustment. If too strong, weaken toward zero. "
        "Return JSON."
    )
    response = client.complete_structured(
        model=reasoner_out.get("critique_model", "claude-sonnet-4-6"),
        system=CRITIQUE_SYSTEM,
        prompt=prompt,
        temperature=0.0,
        max_tokens=512,
    )
    critiqued_adj = float(response.structured.get("reasoner_adjustment", original_adj))
    # Enforce weaken-only invariant: |critiqued| ≤ |original|.
    if abs(critiqued_adj) > abs(original_adj):
        critiqued_adj = original_adj
    # Sign must match the original or be zero.
    if original_adj != 0 and (critiqued_adj * original_adj < 0):
        critiqued_adj = 0.0
    return {
        **reasoner_out,
        "reasoner_adjustment": critiqued_adj,
        "dimensions_cited": response.structured.get(
            "dimensions_cited", reasoner_out.get("dimensions_cited", [])
        ),
        "justification": response.structured.get(
            "justification", reasoner_out.get("justification", "")
        ),
        "confidence": float(
            response.structured.get("confidence", reasoner_out.get("confidence", 0.6))
        ),
        "critique_applied": True,
        "response_raw": (reasoner_out.get("response_raw", "") + "\n--- critique ---\n" + response.raw),
        "input_tokens": reasoner_out.get("input_tokens", 0) + response.input_tokens,
        "output_tokens": reasoner_out.get("output_tokens", 0) + response.output_tokens,
        "latency_ms": reasoner_out.get("latency_ms", 0) + response.latency_ms,
        "prompt": reasoner_out.get("prompt", "") + "\n--- critique ---\n" + prompt,
    }


__all__ = ["critique_reasoner"]
