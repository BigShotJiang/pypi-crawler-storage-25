"""Multi-judge consensus on the synthesizer.

Two LLM judges score the same insight. Disagreement beyond a tolerance
routes to active learning. Consensus score = min of the two (lean
conservative).
"""

from __future__ import annotations

from typing import Any

from cambium.claude.client import get_default_claude_client

JUDGE_SYSTEM = """\
You are a judge scoring a coherence insight against a six-dimension rubric:
evidence, fidelity, tone, specificity, actionability, respect. Each score is
in [0, 1]. Return strict JSON with rubric_scores (dict) and overall (mean).
"""


def consensus_score(
    *,
    insight: dict[str, Any],
    primary_model: str,
    secondary_model: str | None = None,
    tolerance: float = 0.2,
    claude_client: Any | None = None,
) -> dict[str, Any]:
    """Score an insight twice; emit the consensus + a disagreement flag."""
    client = claude_client or get_default_claude_client()
    prompt = (
        "Insight:\n"
        f"headline: {insight.get('headline','')}\n"
        f"body: {insight.get('body','')}\n"
        f"referenced_event_ids: {insight.get('referenced_event_ids',[])}\n"
        f"referenced_dimensions: {insight.get('referenced_dimensions',[])}\n"
        f"suggested_actions: {insight.get('suggested_actions',[])}\n"
    )
    primary = client.complete_structured(
        model=primary_model, system=JUDGE_SYSTEM, prompt=prompt, temperature=0.0
    )
    p_overall = float(primary.structured.get("overall", 0.0))
    if secondary_model is None:
        return {
            "primary_score": p_overall,
            "secondary_score": None,
            "consensus": p_overall,
            "disagreement": 0.0,
            "exceeds_tolerance": False,
        }
    secondary = client.complete_structured(
        model=secondary_model, system=JUDGE_SYSTEM, prompt=prompt, temperature=0.0
    )
    s_overall = float(secondary.structured.get("overall", 0.0))
    disagreement = abs(p_overall - s_overall)
    return {
        "primary_score": p_overall,
        "secondary_score": s_overall,
        "consensus": min(p_overall, s_overall),
        "disagreement": disagreement,
        "exceeds_tolerance": disagreement > tolerance,
    }


__all__ = ["consensus_score"]
