"""Anthropic SDK wrapper with structured-output extraction.

ClaudeClient takes a model id + prompt and returns a parsed dict (the
structured JSON output of the call site) plus token counts and
latency. StubClaudeClient returns deterministic outputs so tests run
without API keys.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

try:  # pragma: no cover — import-time only
    import anthropic  # type: ignore

    _HAS_ANTHROPIC = True
except ImportError:
    anthropic = None  # type: ignore[assignment]
    _HAS_ANTHROPIC = False


@dataclass
class ClaudeResponse:
    structured: dict[str, Any]
    raw: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    model: str
    prompt: str = ""


class ClaudeClient:
    """Thin Anthropic SDK wrapper. Lazy: only constructs SDK client when first used."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: Any = None

    def _ensure(self) -> Any:
        if self._client is None:
            if not _HAS_ANTHROPIC:
                raise RuntimeError(
                    "anthropic SDK is not installed; use StubClaudeClient or "
                    "install cambium with the appropriate extras."
                )
            self._client = anthropic.Anthropic(  # type: ignore[union-attr]
                api_key=self._api_key, timeout=self._timeout, max_retries=self._max_retries
            )
        return self._client

    def complete_structured(
        self,
        *,
        model: str,
        prompt: str,
        system: str = "",
        max_tokens: int = 1024,
        temperature: float = 0.2,
    ) -> ClaudeResponse:
        """Issue one Messages call. Extract the first JSON object from the response."""
        client = self._ensure()
        start = time.perf_counter()
        message = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        latency_ms = int((time.perf_counter() - start) * 1000)
        text = _flatten_content(message)
        structured = _extract_json(text) or {}
        return ClaudeResponse(
            structured=structured,
            raw=text,
            input_tokens=getattr(message.usage, "input_tokens", 0),
            output_tokens=getattr(message.usage, "output_tokens", 0),
            latency_ms=latency_ms,
            model=model,
            prompt=prompt,
        )


@dataclass
class StubClaudeClient:
    """A deterministic, in-memory stand-in. Tests use this.

    Configure responses via ``response_for`` (a dict of (call_site, key) →
    dict) or a callable ``responder``.
    """

    responses: dict[tuple[str, str], dict[str, Any]] = field(default_factory=dict)
    responder: Optional[Callable[[str, str], dict[str, Any]]] = None
    default_responses: dict[str, dict[str, Any]] = field(
        default_factory=lambda: {
            "classifier": {
                "semantic_category": "routine_essential",
                "confidence": 0.7,
                "structural_validity": True,
            },
            "reasoner": {
                "reasoner_adjustment": 0.0,
                "dimensions_cited": [],
                "justification": "Stub justification.",
                "confidence": 0.6,
            },
            "synthesizer": {
                "headline": "A quiet week of routine spending.",
                "body": "Most events looked routine.",
                "tone": "neutral",
                "referenced_event_ids": [],
                "referenced_dimensions": [],
                "suggested_actions": ["Notice your patterns this week."],
            },
            "critique": {
                "reasoner_adjustment": 0.0,
                "dimensions_cited": [],
                "justification": "Critique preserved adjustment.",
                "confidence": 0.6,
            },
            "judge": {
                "rubric_scores": {
                    "evidence": 0.8,
                    "fidelity": 0.8,
                    "tone": 0.8,
                    "specificity": 0.7,
                    "actionability": 0.7,
                    "respect": 0.9,
                },
                "overall": 0.78,
            },
        }
    )

    def complete_structured(
        self,
        *,
        model: str,
        prompt: str,
        system: str = "",
        max_tokens: int = 1024,
        temperature: float = 0.2,
    ) -> ClaudeResponse:
        call_site = _infer_call_site(system, prompt)
        if self.responder is not None:
            structured = self.responder(call_site, prompt)
        else:
            structured = self.responses.get((call_site, prompt)) or self.default_responses.get(
                call_site, {}
            )
        return ClaudeResponse(
            structured=structured,
            raw=json.dumps(structured),
            input_tokens=max(1, len(prompt) // 4),
            output_tokens=max(1, len(json.dumps(structured)) // 4),
            latency_ms=1,
            model=model,
            prompt=prompt,
        )


def get_default_claude_client() -> Any:
    """Return a real client if ANTHROPIC_API_KEY is set; otherwise a stub."""
    if os.environ.get("ANTHROPIC_API_KEY") and _HAS_ANTHROPIC:
        return ClaudeClient()
    return StubClaudeClient()


def _flatten_content(message: Any) -> str:
    out: list[str] = []
    for block in getattr(message, "content", []):
        text = getattr(block, "text", None)
        if text:
            out.append(text)
    return "".join(out)


def _extract_json(text: str) -> Optional[dict[str, Any]]:
    """Best-effort: pull the first balanced JSON object out of text."""
    # Look for a JSON object; tolerate prose around it.
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass
    # Scan for the first balanced { ... }
    depth = 0
    start = -1
    for i, ch in enumerate(text):
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                candidate = text[start : i + 1]
                try:
                    return json.loads(candidate)
                except json.JSONDecodeError:
                    continue
    return None


def _infer_call_site(system: str, prompt: str) -> str:
    blob = (system + "\n" + prompt).lower()
    if "synthesizer" in blob or "weekly insight" in blob:
        return "synthesizer"
    if "critique" in blob:
        return "critique"
    if "judge" in blob:
        return "judge"
    if "reasoner" in blob or "adjustment" in blob:
        return "reasoner"
    return "classifier"


__all__ = [
    "ClaudeClient",
    "ClaudeResponse",
    "StubClaudeClient",
    "get_default_claude_client",
]
