"""Append-only trace recorder.

Writes one JSONL row per Claude call. Files are partitioned by UTC
day (``YYYY-MM-DD.jsonl``). Redactions are appended as new rows with
a ``redaction_marker: true`` flag — never edits-in-place.

Production deployments back this with a Timber repository
(``timber_configs/trace_record.yaml``). The local-file recorder is
the development/test fallback.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class TraceRecorder:
    """Append-only JSONL recorder partitioned by UTC day."""

    def __init__(self, directory: Path | str) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def record(self, row: dict[str, Any]) -> str:
        """Append a row and return its trace_id."""
        ts = datetime.now(timezone.utc)
        trace_id = row.get("trace_id") or str(uuid.uuid4())
        full = {
            "trace_id": trace_id,
            "timestamp": row.get("timestamp", ts.isoformat()),
            **row,
        }
        path = self.directory / f"{ts.strftime('%Y-%m-%d')}.jsonl"
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(full, default=str, separators=(",", ":")))
            f.write("\n")
        return trace_id

    def redact(self, trace_id: str, reason: str) -> str:
        """Write a redaction marker for an existing trace_id."""
        return self.record(
            {
                "trace_id": trace_id,
                "redaction_marker": True,
                "redaction_reason": reason,
            }
        )

    def iter_rows(self, day: str | None = None) -> list[dict[str, Any]]:
        """Read rows for a given UTC day. Convenience for tests and replay."""
        rows: list[dict[str, Any]] = []
        files = (
            [self.directory / f"{day}.jsonl"]
            if day
            else sorted(self.directory.glob("*.jsonl"))
        )
        for f in files:
            if not f.exists():
                continue
            for line in f.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    rows.append(json.loads(line))
        return rows


__all__ = ["TraceRecorder"]
