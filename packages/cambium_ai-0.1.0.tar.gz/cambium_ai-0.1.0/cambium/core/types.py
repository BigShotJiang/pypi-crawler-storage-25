"""Canonical Pydantic types for Cambium.

These types are the single source of truth for every cross-service
contract. Cross-repo integrations (Grove events, Ranger config
validators, Sky/Acorn A2UI directive kinds, Canopy client schemas)
MUST mirror these shapes exactly. When a field here changes, every
consuming surface changes in lockstep.

The model is deliberately frozen / extra-forbidden where it crosses
the audit boundary. Anything that ends up in a trace row, a
provenance certificate, or an A2UI document is immutable Pydantic.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Identity and behavior
# ---------------------------------------------------------------------------


class IdentityProfile(BaseModel):
    """A captured snapshot of a user's stated identity in a domain.

    Authored by an upstream capture instrument (e.g. Grove's
    `financial_dna_evaluation` workflow for the finance domain). Cambium
    treats this as read-only input. Re-capture creates a new row; the
    repository keeps history.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: str = Field(description="Domain-scoped schema id, e.g. 'finance.dna.v1.0.0'.")
    domain: str
    user_id_hash: str
    dimensions: dict[str, float] = Field(description="Per-dimension scores in [0, 1].")
    narrative_tags: tuple[str, ...] = Field(default_factory=tuple)
    captured_at: datetime
    domain_data: Optional[dict[str, Any]] = Field(
        default=None,
        description=(
            "Domain-specific extras the baseline scorer may consult. Encrypted "
            "at rest by Timber per the timber_configs/identity_profile.yaml "
            "encryption block."
        ),
    )


class BehavioralEvent(BaseModel):
    """A single observed behavior in a domain.

    Examples: a Plaid transaction, a wearable data point, a calendar
    item, a content-consumption record. The shape is intentionally
    generic; domain-specific normalization lives in
    `cambium/domains/<domain>/events.py`.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str
    user_id_hash: str
    domain: str
    event_type: str
    timestamp: datetime
    magnitude: Decimal = Field(description="Signed magnitude in the domain's natural unit.")
    description: str
    raw: dict[str, Any] = Field(default_factory=dict)


class ClassifiedEvent(BaseModel):
    """Output of the classifier call site. Frozen — flows into traces."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str
    semantic_category: str
    confidence: float = Field(ge=0.0, le=1.0)
    confidence_band: Literal["low", "medium", "high"]
    structural_validity: bool = True


class CoherenceScore(BaseModel):
    """Output of the reasoner call site, after spine guardrails."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str
    user_id_hash: str
    domain: str
    deterministic_baseline: float = Field(ge=-1.0, le=1.0)
    reasoner_adjustment: float = Field(description="Bounded to ±ceiling by the spine.")
    score: float = Field(ge=-1.0, le=1.0, description="baseline + adjustment, clipped to [-1, 1].")
    confidence: float = Field(ge=0.0, le=1.0)
    dimensions_cited: tuple[str, ...]
    justification: str
    critique_applied: bool = False


class Insight(BaseModel):
    """Output of the synthesizer call site over a window of scores."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    insight_id: str
    user_id_hash: str
    domain: str
    headline: str
    body: str
    tone: Literal["affirming", "curious", "neutral"]
    referenced_event_ids: tuple[str, ...]
    referenced_dimensions: tuple[str, ...]
    suggested_actions: tuple[str, ...]
    window_start: datetime
    window_end: datetime
    composed_at: datetime
    judge_score: Optional[float] = None
    revoked: bool = False


# ---------------------------------------------------------------------------
# Manifest — the content-hashed bundle that defines a runnable system
# ---------------------------------------------------------------------------


class Manifest(BaseModel):
    """The content-hashed bundle that identifies a runnable Cambium config.

    `content_hash()` is structural: identical content → identical hash,
    independent of `created_at` and `manifest_id`. This is Pattern 11
    (Design-time → Runtime) made auditable.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    manifest_id: str
    domain: str
    classifier_prompt_hash: str
    reasoner_prompt_hash: str
    synthesizer_prompt_hash: str
    classifier_model: str
    reasoner_model: str
    synthesizer_model: str
    judge_model: str
    secondary_judge_model: Optional[str] = None
    judge_rubric_hash: str
    identity_schema_version: str
    domain_config_hash: str
    reasoner_adjustment_ceiling: float = 0.3
    constitution_hash: str = "default"
    rules_package_hash: str = "default"
    eval_thresholds_hash: str = "default"
    golden_set_version: str = "v1"
    active_skills: tuple[str, ...] = ()
    schema_version: str = "1.0.0"
    created_at: datetime
    notes: Optional[str] = None

    def content_hash(self) -> str:
        """Stable structural hash. Excludes manifest_id and created_at."""
        payload = self.model_dump(mode="json", exclude={"manifest_id", "created_at", "notes"})
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Provenance certificate
# ---------------------------------------------------------------------------


class ProvenanceCertificate(BaseModel):
    """A signed certificate proving an insight came from a specific manifest.

    Verifiable offline given the public key. Signature is over a
    canonical encoding of (insight_id, manifest_hash, golden_set_version,
    payload_canonical_hash, issued_at).
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    certificate_id: str
    insight_id: str
    manifest_hash: str
    golden_set_version: str
    signing_key_id: str
    signature: str
    payload_canonical_hash: str
    issued_at: datetime


# ---------------------------------------------------------------------------
# Trace record
# ---------------------------------------------------------------------------


class TraceRecord(BaseModel):
    """One Claude call. Append-only; redactions are new rows, not edits."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str
    timestamp: datetime
    user_id_hash: str
    domain: str
    call_site: Literal["classifier", "reasoner", "synthesizer", "critique", "judge"]
    manifest_hash: str
    prompt_hash: str
    prompt_redacted: str
    response_raw: str
    structured_output: dict[str, Any]
    latency_ms: int
    input_token_count: int
    output_token_count: int
    model: str
    rule_violations: Optional[list[str]] = None
    critique_applied: bool = False


# ---------------------------------------------------------------------------
# Service configuration types
# ---------------------------------------------------------------------------


class EvalThresholds(BaseModel):
    """Per-domain thresholds the regression CI enforces."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    classifier_f1_min: float = 0.75
    classifier_accuracy_min: float = 0.80
    reasoner_score_mae_max: float = 0.20
    reasoner_direction_agreement_min: float = 0.80
    synthesizer_judge_min: float = 0.70
    judge_disagreement_max: float = 0.30
    calibration_ece_max: float = 0.10


class FeatureFlags(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    constitutional_critique: bool = True
    multi_judge_consensus: bool = True
    shadow_ab_enabled: bool = False
    active_learning_enabled: bool = True
    drift_detection_enabled: bool = True


class ModelOverrides(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    classifier_model: str = "claude-haiku-4-5-20251001"
    reasoner_model: str = "claude-sonnet-4-6"
    synthesizer_model: str = "claude-opus-4-7"
    judge_model: str = "claude-opus-4-7"


class RedactionPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    redact_emails: bool = True
    redact_phone_numbers: bool = True
    redact_persons: bool = True
    redact_merchants_as_persons: bool = False
    salt_rotation_days: int = 30
    extra_patterns: tuple[tuple[str, str], ...] = ()


__all__ = [
    "IdentityProfile",
    "BehavioralEvent",
    "ClassifiedEvent",
    "CoherenceScore",
    "Insight",
    "Manifest",
    "ProvenanceCertificate",
    "TraceRecord",
    "EvalThresholds",
    "FeatureFlags",
    "ModelOverrides",
    "RedactionPolicy",
]


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)
