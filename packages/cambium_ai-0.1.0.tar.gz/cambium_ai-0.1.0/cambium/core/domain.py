"""Domain configuration and registry.

A domain plugs into Cambium via:
- A ``config.yaml`` describing dimensions, categories, narrative tags,
  default ceiling, and identity schema version.
- Four Python modules (``identity.py``, ``events.py``, ``baseline.py``,
  ``prompts.py``) that implement the per-domain behavior.

The registry holds the active set of registered domains. The spine
asks the registry for a domain's config at call time, never at import
time.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Protocol

import yaml
from pydantic import BaseModel, ConfigDict, Field

from cambium.core.types import BehavioralEvent, IdentityProfile


class DomainConfig(BaseModel):
    """Per-domain configuration, loaded from ``cambium/domains/<name>/config.yaml``."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    display_name: str
    description: str
    identity_schema_version: str
    dimensions: tuple[str, ...]
    categories: tuple[str, ...]
    narrative_tags: tuple[str, ...] = ()
    reasoner_adjustment_ceiling: float = 0.3
    catastrophizing_tokens: tuple[str, ...] = (
        "reckless",
        "irresponsible",
        "stupid",
        "foolish",
        "disastrous",
    )
    prompt_voice: str = "neutral, observational, non-judgmental"
    extra_redaction_patterns: tuple[tuple[str, str], ...] = ()
    baseline_class: str = ""
    identity_class: str = ""
    events_module: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def dimension_names(self) -> tuple[str, ...]:
        return self.dimensions

    @property
    def category_names(self) -> tuple[str, ...]:
        return self.categories

    def content_hash(self) -> str:
        payload = self.model_dump(mode="json")
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class BaselineScorer(Protocol):
    """Domain-specific deterministic baseline scorer."""

    def score(
        self,
        identity: IdentityProfile,
        event: BehavioralEvent,
        semantic_category: str,
    ) -> float:
        """Return a baseline coherence score in [-1, 1]."""
        ...


class DomainRegistry:
    """Holds registered domains. Cheap to clone for tests."""

    def __init__(self) -> None:
        self._configs: dict[str, DomainConfig] = {}
        self._baselines: dict[str, BaselineScorer] = {}

    def register(
        self,
        config: DomainConfig,
        baseline: BaselineScorer | None = None,
    ) -> None:
        self._configs[config.name] = config
        if baseline is not None:
            self._baselines[config.name] = baseline

    def register_from_yaml(self, yaml_path: Path) -> DomainConfig:
        """Load a domain's config.yaml and its baseline (if importable)."""
        data = yaml.safe_load(Path(yaml_path).read_text())
        config = _parse_yaml_to_config(data)
        baseline = _import_baseline(config) if config.baseline_class else None
        self.register(config, baseline)
        return config

    def get(self, name: str) -> DomainConfig:
        if name not in self._configs:
            raise KeyError(f"Domain '{name}' not registered")
        return self._configs[name]

    def get_baseline(self, name: str) -> BaselineScorer | None:
        return self._baselines.get(name)

    def list_domains(self) -> list[str]:
        return sorted(self._configs.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._configs


def _parse_yaml_to_config(data: dict[str, Any]) -> DomainConfig:
    """Translate the on-disk YAML shape into a DomainConfig."""
    return DomainConfig(
        name=data["name"],
        display_name=data.get("display_name", data["name"].title()),
        description=data.get("description", ""),
        identity_schema_version=data["identity_schema_version"],
        dimensions=tuple(data["dimensions"]),
        categories=tuple(data["categories"]),
        narrative_tags=tuple(data.get("narrative_tags", [])),
        reasoner_adjustment_ceiling=float(data.get("reasoner_adjustment_ceiling", 0.3)),
        catastrophizing_tokens=tuple(data.get("catastrophizing_tokens", [])) or (
            "reckless",
            "irresponsible",
            "stupid",
            "foolish",
            "disastrous",
        ),
        prompt_voice=data.get("prompt_voice", "neutral, observational, non-judgmental"),
        extra_redaction_patterns=tuple(
            (p["label"], p["pattern"]) for p in data.get("extra_redaction_patterns", [])
        ),
        baseline_class=data.get("baseline_class", ""),
        identity_class=data.get("identity_class", ""),
        events_module=data.get("events_module", ""),
        metadata=data.get("metadata", {}),
    )


def _import_baseline(config: DomainConfig) -> BaselineScorer | None:
    """Dynamically import the domain's baseline class.

    ``baseline_class`` is a fully-qualified dotted path, e.g.
    ``cambium.domains.finance.baseline.FinanceBaseline``.
    """
    if not config.baseline_class:
        return None
    module_name, _, attr = config.baseline_class.rpartition(".")
    if not module_name:
        return None
    try:
        module = __import__(module_name, fromlist=[attr])
        cls = getattr(module, attr)
        return cls()
    except (ImportError, AttributeError):
        return None


__all__ = [
    "BaselineScorer",
    "DomainConfig",
    "DomainRegistry",
]
