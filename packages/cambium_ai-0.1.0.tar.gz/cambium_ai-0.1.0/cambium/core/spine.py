"""The deterministic Spine — Cambium's orchestrator.

The spine decides what the model is asked. The model only answers. The
eval framework decides whether the answer counted.

``process_event`` walks: redact → classify → baseline → reasoner →
critique → clip/validate → trace → emit.

``synthesize_window`` walks: gather → synthesize → judge → validate
references → trace → emit + provenance certificate.

The spine NEVER lets the model touch a tool, a database, or the
network. Context flows in via the service abstraction; results flow
out via structured outputs the spine validates.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from cambium.core.otel import call_site_span, set_attribute
from cambium.core.provenance import InProcessSigner, issue_certificate
from cambium.core.redaction import Redactor, RedactionMapping
from cambium.core.types import (
    BehavioralEvent,
    ClassifiedEvent,
    CoherenceScore,
    IdentityProfile,
    Insight,
    Manifest,
    ProvenanceCertificate,
    TraceRecord,
)
from cambium.timber.rules import build_reasoner_rules, build_synthesizer_rules

if TYPE_CHECKING:
    from cambium.service import CambiumService


class Spine:
    """The orchestrator. Domain-agnostic; reads domain config from the service."""

    def __init__(
        self,
        *,
        domain: str,
        service: "CambiumService",
        manifest: Manifest | None = None,
        claude_client: Any | None = None,
        signer: Any | None = None,
    ) -> None:
        self.domain = domain
        self.service = service
        self.manifest = manifest or service.get_active_manifest(domain)
        self.claude = claude_client  # may be None in tests; call sites use a stub
        self.signer = signer or _default_signer()
        self._domain_config = service.get_domain_config(domain)
        self._redactor = Redactor(
            extra_patterns=self._domain_config.extra_redaction_patterns
        )

    # ----------------------------------------------------------------- process

    def process_event(
        self,
        *,
        identity: IdentityProfile,
        event: BehavioralEvent,
        mapping: RedactionMapping | None = None,
    ) -> CoherenceScore:
        """Classify → baseline → reason → critique → clip → validate → trace."""
        mapping = mapping or RedactionMapping(user_id_hash=identity.user_id_hash)
        baseline = self._baseline(identity, event)
        classified = self._classify(identity, event, mapping)
        baseline_with_category = self._score_baseline(identity, event, classified)
        reasoner_out = self._reason(
            identity, event, classified, baseline_with_category, mapping
        )
        critique_out = self._critique(reasoner_out) if self._critique_enabled() else reasoner_out
        ceiling = self.manifest.reasoner_adjustment_ceiling
        rules = build_reasoner_rules(
            ceiling=ceiling, permitted=self._domain_config.dimensions
        )
        repaired, violations = rules.apply({
            "reasoner_adjustment": critique_out["reasoner_adjustment"],
            "dimensions_cited": critique_out["dimensions_cited"],
            "justification": critique_out["justification"],
        })
        adjusted = baseline_with_category + repaired["reasoner_adjustment"]
        clipped = max(-1.0, min(1.0, adjusted))
        score = CoherenceScore(
            event_id=event.event_id,
            user_id_hash=identity.user_id_hash,
            domain=self.domain,
            deterministic_baseline=baseline_with_category,
            reasoner_adjustment=repaired["reasoner_adjustment"],
            score=clipped,
            confidence=critique_out.get("confidence", 0.6),
            dimensions_cited=tuple(repaired["dimensions_cited"]),
            justification=repaired["justification"],
            critique_applied=self._critique_enabled(),
        )
        self._record_trace(
            call_site="reasoner",
            user_id_hash=identity.user_id_hash,
            prompt_redacted=critique_out.get("prompt", ""),
            response_raw=critique_out.get("response_raw", ""),
            structured_output=score.model_dump(mode="json"),
            input_tokens=critique_out.get("input_tokens", 0),
            output_tokens=critique_out.get("output_tokens", 0),
            latency_ms=critique_out.get("latency_ms", 0),
            model=self.manifest.reasoner_model,
            rule_violations=violations,
            critique_applied=self._critique_enabled(),
        )
        return score

    # --------------------------------------------------------------- synthesize

    def synthesize_window(
        self,
        *,
        identity: IdentityProfile,
        scores: list[CoherenceScore],
        events: list[BehavioralEvent],
        window_start: datetime,
        window_end: datetime,
    ) -> tuple[Insight, ProvenanceCertificate]:
        """Synthesize a weekly insight from a window of scores + events."""
        synth_out = self._synthesize(identity, scores, events, window_start, window_end)
        synthesizer_rules = build_synthesizer_rules(
            permitted_dimensions=self._domain_config.dimensions,
            permitted_event_ids=tuple(e.event_id for e in events),
        )
        repaired, violations = synthesizer_rules.apply({
            "dimensions_cited": synth_out.get("referenced_dimensions", []),
            "event_references": synth_out.get("referenced_event_ids", []),
            "justification": synth_out.get("body", ""),
        })
        insight = Insight(
            insight_id=str(uuid.uuid4()),
            user_id_hash=identity.user_id_hash,
            domain=self.domain,
            headline=synth_out["headline"],
            body=synth_out["body"],
            tone=synth_out.get("tone", "neutral"),
            referenced_event_ids=tuple(repaired["event_references"]),
            referenced_dimensions=tuple(repaired["dimensions_cited"]),
            suggested_actions=tuple(synth_out.get("suggested_actions", [])),
            window_start=window_start,
            window_end=window_end,
            composed_at=datetime.now(timezone.utc),
            judge_score=synth_out.get("judge_score"),
        )
        certificate = issue_certificate(
            insight=insight,
            manifest_hash=self.manifest.content_hash(),
            golden_set_version=self.manifest.golden_set_version,
            signing_key_id="cambium-dev-1",
            sign_fn=self.signer.sign,
        )
        self._record_trace(
            call_site="synthesizer",
            user_id_hash=identity.user_id_hash,
            prompt_redacted=synth_out.get("prompt", ""),
            response_raw=synth_out.get("response_raw", ""),
            structured_output=insight.model_dump(mode="json"),
            input_tokens=synth_out.get("input_tokens", 0),
            output_tokens=synth_out.get("output_tokens", 0),
            latency_ms=synth_out.get("latency_ms", 0),
            model=self.manifest.synthesizer_model,
            rule_violations=violations,
        )
        return insight, certificate

    # --------------------------------------------------------------- internals

    def _baseline(
        self, identity: IdentityProfile, event: BehavioralEvent
    ) -> float:
        """Pre-classification baseline (default 0.0; domain may override)."""
        return 0.0

    def _score_baseline(
        self,
        identity: IdentityProfile,
        event: BehavioralEvent,
        classified: ClassifiedEvent,
    ) -> float:
        baseline = self.service.domain_registry().get_baseline(self.domain)
        if baseline is None:
            return 0.0
        score = baseline.score(identity, event, classified.semantic_category)
        return max(-1.0, min(1.0, float(score)))

    def _classify(
        self,
        identity: IdentityProfile,
        event: BehavioralEvent,
        mapping: RedactionMapping,
    ) -> ClassifiedEvent:
        from cambium.call_sites.classifier import run_classifier

        with call_site_span("cambium.classifier") as span:
            set_attribute(span, "domain", self.domain)
            set_attribute(span, "manifest_hash", self.manifest.content_hash())
            out = run_classifier(
                identity=identity,
                event=event,
                domain_config=self._domain_config,
                manifest=self.manifest,
                claude_client=self.claude,
                redactor=self._redactor,
                mapping=mapping,
            )
        classified = ClassifiedEvent(
            event_id=event.event_id,
            semantic_category=out["semantic_category"],
            confidence=out["confidence"],
            confidence_band=_band(out["confidence"]),
            structural_validity=out.get("structural_validity", True),
        )
        self._record_trace(
            call_site="classifier",
            user_id_hash=identity.user_id_hash,
            prompt_redacted=out.get("prompt", ""),
            response_raw=out.get("response_raw", ""),
            structured_output=classified.model_dump(mode="json"),
            input_tokens=out.get("input_tokens", 0),
            output_tokens=out.get("output_tokens", 0),
            latency_ms=out.get("latency_ms", 0),
            model=self.manifest.classifier_model,
        )
        return classified

    def _reason(
        self,
        identity: IdentityProfile,
        event: BehavioralEvent,
        classified: ClassifiedEvent,
        baseline: float,
        mapping: RedactionMapping,
    ) -> dict[str, Any]:
        from cambium.call_sites.reasoner import run_reasoner

        with call_site_span("cambium.reasoner") as span:
            set_attribute(span, "domain", self.domain)
            set_attribute(span, "manifest_hash", self.manifest.content_hash())
            return run_reasoner(
                identity=identity,
                event=event,
                classified=classified,
                baseline=baseline,
                domain_config=self._domain_config,
                manifest=self.manifest,
                claude_client=self.claude,
                redactor=self._redactor,
                mapping=mapping,
            )

    def _critique(self, reasoner_out: dict[str, Any]) -> dict[str, Any]:
        from cambium.claude.critique import critique_reasoner

        return critique_reasoner(reasoner_out, claude_client=self.claude)

    def _synthesize(
        self,
        identity: IdentityProfile,
        scores: list[CoherenceScore],
        events: list[BehavioralEvent],
        window_start: datetime,
        window_end: datetime,
    ) -> dict[str, Any]:
        from cambium.call_sites.synthesizer import run_synthesizer

        with call_site_span("cambium.synthesizer") as span:
            set_attribute(span, "domain", self.domain)
            set_attribute(span, "manifest_hash", self.manifest.content_hash())
            return run_synthesizer(
                identity=identity,
                scores=scores,
                events=events,
                window_start=window_start,
                window_end=window_end,
                domain_config=self._domain_config,
                manifest=self.manifest,
                claude_client=self.claude,
            )

    def _critique_enabled(self) -> bool:
        try:
            return self.service.get_feature_flags().constitutional_critique
        except AttributeError:
            return True

    def _record_trace(
        self,
        *,
        call_site: str,
        user_id_hash: str,
        prompt_redacted: str,
        response_raw: str,
        structured_output: dict[str, Any],
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        model: str,
        rule_violations: list | None = None,
        critique_applied: bool = False,
    ) -> None:
        if self.service is None or not hasattr(self.service, "record_trace"):
            return
        prompt_hash = hashlib.sha256(prompt_redacted.encode("utf-8")).hexdigest()[:16]
        trace = TraceRecord(
            trace_id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc),
            user_id_hash=user_id_hash,
            domain=self.domain,
            call_site=call_site,  # type: ignore[arg-type]
            manifest_hash=self.manifest.content_hash(),
            prompt_hash=prompt_hash,
            prompt_redacted=prompt_redacted,
            response_raw=response_raw,
            structured_output=structured_output,
            latency_ms=latency_ms,
            input_token_count=input_tokens,
            output_token_count=output_tokens,
            model=model,
            rule_violations=[
                v.model_dump(mode="json") if hasattr(v, "model_dump") else str(v)
                for v in (rule_violations or [])
            ]
            or None,
            critique_applied=critique_applied,
        )
        self.service.record_trace(trace)


def _band(confidence: float) -> str:
    if confidence < 0.5:
        return "low"
    if confidence < 0.8:
        return "medium"
    return "high"


def _default_signer() -> InProcessSigner:
    signer = InProcessSigner()
    signer.register_key("cambium-dev-1", b"cambium-dev-shared-secret-for-tests-only")
    return signer


__all__ = ["Spine"]
