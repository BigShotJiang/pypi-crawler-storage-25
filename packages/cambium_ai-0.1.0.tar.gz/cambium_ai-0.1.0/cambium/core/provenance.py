"""Signed provenance certificates.

A certificate binds an insight to a specific manifest + golden-set
version. The signature is over a canonical encoding of the payload,
produced via Timber's keystore in production
(``EncryptedKeystore.sign``) and an in-process HMAC fallback in
development.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from cambium.core.types import Insight, ProvenanceCertificate


SignFn = Callable[[str, bytes], bytes]
VerifyFn = Callable[[str, bytes, bytes], bool]


def canonical_payload(insight: Insight, manifest_hash: str, golden_set_version: str) -> bytes:
    payload = {
        "insight_id": insight.insight_id,
        "user_id_hash": insight.user_id_hash,
        "domain": insight.domain,
        "manifest_hash": manifest_hash,
        "golden_set_version": golden_set_version,
        "headline": insight.headline,
        "body": insight.body,
        "tone": insight.tone,
        "referenced_event_ids": list(insight.referenced_event_ids),
        "referenced_dimensions": list(insight.referenced_dimensions),
        "suggested_actions": list(insight.suggested_actions),
        "window_start": insight.window_start.isoformat(),
        "window_end": insight.window_end.isoformat(),
        "composed_at": insight.composed_at.isoformat(),
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def issue_certificate(
    *,
    insight: Insight,
    manifest_hash: str,
    golden_set_version: str,
    signing_key_id: str,
    sign_fn: SignFn,
) -> ProvenanceCertificate:
    """Issue a signed certificate over (insight + manifest + golden set)."""
    canonical = canonical_payload(insight, manifest_hash, golden_set_version)
    payload_hash = hashlib.sha256(canonical).hexdigest()
    signature = sign_fn(signing_key_id, canonical)
    return ProvenanceCertificate(
        certificate_id=str(uuid.uuid4()),
        insight_id=insight.insight_id,
        manifest_hash=manifest_hash,
        golden_set_version=golden_set_version,
        signing_key_id=signing_key_id,
        signature=signature.hex(),
        payload_canonical_hash=payload_hash,
        issued_at=datetime.now(timezone.utc),
    )


def verify_certificate(
    *,
    cert: ProvenanceCertificate,
    insight: Insight,
    verify_fn: VerifyFn,
) -> bool:
    """Verify a certificate matches an insight and manifest reference."""
    canonical = canonical_payload(insight, cert.manifest_hash, cert.golden_set_version)
    expected_hash = hashlib.sha256(canonical).hexdigest()
    if expected_hash != cert.payload_canonical_hash:
        return False
    return verify_fn(cert.signing_key_id, canonical, bytes.fromhex(cert.signature))


class InProcessSigner:
    """Fallback HMAC signer for development. Production uses Timber's keystore."""

    def __init__(self) -> None:
        self._keys: dict[str, bytes] = {}

    def register_key(self, key_id: str, key: bytes) -> None:
        self._keys[key_id] = key

    def sign(self, key_id: str, payload: bytes) -> bytes:
        key = self._keys.get(key_id)
        if key is None:
            raise KeyError(f"Unknown signing key: {key_id}")
        return hmac.new(key, payload, hashlib.sha256).digest()

    def verify(self, key_id: str, payload: bytes, signature: bytes) -> bool:
        key = self._keys.get(key_id)
        if key is None:
            return False
        expected = hmac.new(key, payload, hashlib.sha256).digest()
        return hmac.compare_digest(expected, signature)


__all__ = [
    "InProcessSigner",
    "SignFn",
    "VerifyFn",
    "canonical_payload",
    "issue_certificate",
    "verify_certificate",
]
