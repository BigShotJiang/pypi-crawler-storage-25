"""Calibration metrics — Brier score, expected calibration error.

Pure Python. No numpy / scipy. The platform deliberately keeps the
dependency surface small; these formulas are simple enough to
verify by inspection.
"""

from __future__ import annotations

from typing import Sequence

from pydantic import BaseModel, ConfigDict, Field


class ReliabilityBin(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    lower: float
    upper: float
    n: int
    mean_confidence: float
    accuracy: float


class CalibrationReport(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    brier: float
    ece: float
    bins: tuple[ReliabilityBin, ...] = Field(default_factory=tuple)
    n: int


def brier_score(confidences: Sequence[float], outcomes: Sequence[int]) -> float:
    """Mean squared error between confidence and binary outcome."""
    if not confidences:
        return 0.0
    return sum((c - o) ** 2 for c, o in zip(confidences, outcomes)) / len(confidences)


def expected_calibration_error(
    confidences: Sequence[float],
    outcomes: Sequence[int],
    num_bins: int = 10,
) -> tuple[float, list[ReliabilityBin]]:
    """Bin predictions by confidence and weight each bin's gap by mass."""
    if not confidences:
        return 0.0, []
    n = len(confidences)
    edges = [i / num_bins for i in range(num_bins + 1)]
    bins: list[ReliabilityBin] = []
    ece = 0.0
    for i in range(num_bins):
        lo, hi = edges[i], edges[i + 1]
        in_bin = [
            (c, o)
            for c, o in zip(confidences, outcomes)
            if (c > lo or (i == 0 and c == lo)) and c <= hi
        ]
        if not in_bin:
            continue
        cs, os_ = zip(*in_bin)
        mean_conf = sum(cs) / len(cs)
        acc = sum(os_) / len(os_)
        weight = len(in_bin) / n
        ece += weight * abs(mean_conf - acc)
        bins.append(
            ReliabilityBin(
                lower=lo,
                upper=hi,
                n=len(in_bin),
                mean_confidence=mean_conf,
                accuracy=acc,
            )
        )
    return ece, bins


def calibration_report(
    confidences: Sequence[float],
    outcomes: Sequence[int],
    num_bins: int = 10,
) -> CalibrationReport:
    brier = brier_score(confidences, outcomes)
    ece, bins = expected_calibration_error(confidences, outcomes, num_bins)
    return CalibrationReport(
        brier=brier, ece=ece, bins=tuple(bins), n=len(confidences)
    )


__all__ = [
    "brier_score",
    "expected_calibration_error",
    "calibration_report",
    "CalibrationReport",
    "ReliabilityBin",
]
