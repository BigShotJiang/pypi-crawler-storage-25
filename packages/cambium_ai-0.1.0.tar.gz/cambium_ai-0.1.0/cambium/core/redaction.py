"""PII redaction with reversible mapping.

Redactor produces a pseudonymized form of free text. Same source
value maps to the same pseudonym within a single ``RedactionMapping``;
the reverse map lives in the mapping object (encrypted at rest by
Timber).

This is the canonical implementation of Pattern 9 (reversible
field-level redaction) — the model never sees raw PII; the spine
rehydrates before returning to the user.
"""

from __future__ import annotations

import re
import secrets
from typing import Sequence

from pydantic import BaseModel, ConfigDict, Field

_DEFAULT_PATTERNS: tuple[tuple[str, str], ...] = (
    ("EMAIL", r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    ("PHONE", r"(?:\+?\d{1,2}[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}"),
    ("SSN", r"\b\d{3}-\d{2}-\d{4}\b"),
    ("CREDIT_CARD", r"\b(?:\d[ -]*?){13,16}\b"),
    ("URL", r"https?://[^\s]+"),
)


class RedactionMapping(BaseModel):
    """A user-scoped redaction mapping. Reverse-map is sensitive."""

    model_config = ConfigDict(extra="forbid")

    user_id_hash: str = ""
    forward: dict[str, str] = Field(default_factory=dict)
    reverse: dict[str, str] = Field(default_factory=dict)
    salt: str = Field(default_factory=lambda: secrets.token_hex(8))

    def has(self, raw: str) -> bool:
        return raw in self.forward

    def add(self, raw: str, label: str, counter: int) -> str:
        token = f"⟨{label}_{self.salt[:4]}_{counter:04d}⟩"
        self.forward[raw] = token
        self.reverse[token] = raw
        return token

    def get_token(self, raw: str) -> str | None:
        return self.forward.get(raw)


class Redactor:
    """Pseudonymize PII in free text; rehydrate via the mapping."""

    def __init__(
        self,
        extra_patterns: Sequence[tuple[str, str]] = (),
    ) -> None:
        patterns = list(_DEFAULT_PATTERNS) + list(extra_patterns)
        self._compiled = [(label, re.compile(pat)) for label, pat in patterns]

    def redact_text(self, raw: str, mapping: RedactionMapping) -> str:
        """Replace every matched span with a stable pseudonym."""
        out = raw
        for label, regex in self._compiled:
            counter = sum(1 for k in mapping.forward if k.startswith(label[:3]))
            matches = list(regex.finditer(out))
            for m in matches:
                value = m.group(0)
                token = mapping.get_token(value)
                if token is None:
                    counter += 1
                    token = mapping.add(value, label, counter)
                out = out.replace(value, token)
        return out

    def rehydrate(self, redacted: str, mapping: RedactionMapping) -> str:
        out = redacted
        # Sort longer tokens first to avoid prefix collisions
        for token, raw in sorted(
            mapping.reverse.items(), key=lambda kv: -len(kv[0])
        ):
            out = out.replace(token, raw)
        return out


__all__ = ["Redactor", "RedactionMapping"]
