"""Cambium MCP server.

Exposes six tools:
- process_event
- synthesize_window
- list_manifests
- get_manifest
- verify_certificate
- list_domains

Transport-agnostic. Pick stdio (for Claude Code) or HTTP/SSE (for
Grove orchestration) at deploy time.

When the ``mcp`` package isn't installed, ``build_server`` returns a
local handler dict callers can drive directly — useful for tests and
for the example script.
"""

from __future__ import annotations

from typing import Any, Callable

from cambium.service import CambiumService, get_default_service


class _LocalServer:
    """Test-time and demo-time stand-in for an MCP server."""

    def __init__(self) -> None:
        self._handlers: dict[str, Callable[..., Any]] = {}

    def tool(self, name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers[name] = fn
            return fn

        return decorator

    def call(self, name: str, **kwargs: Any) -> Any:
        if name not in self._handlers:
            raise KeyError(f"Unknown tool: {name}")
        return self._handlers[name](**kwargs)


def build_server(service: CambiumService | None = None) -> _LocalServer:
    """Build an MCP server (local stand-in if `mcp` is not installed)."""
    svc = service or get_default_service()
    server = _LocalServer()

    @server.tool("process_event")
    def process_event(
        domain: str,
        identity: dict[str, Any],
        event: dict[str, Any],
    ) -> dict[str, Any]:
        from cambium.core.spine import Spine
        from cambium.core.types import BehavioralEvent, IdentityProfile

        spine = Spine(domain=domain, service=svc)
        identity_obj = IdentityProfile.model_validate(identity)
        event_obj = BehavioralEvent.model_validate(event)
        score = spine.process_event(identity=identity_obj, event=event_obj)
        return score.model_dump(mode="json")

    @server.tool("synthesize_window")
    def synthesize_window(
        domain: str,
        identity: dict[str, Any],
        scores: list[dict[str, Any]],
        events: list[dict[str, Any]],
        window_start: str,
        window_end: str,
    ) -> dict[str, Any]:
        from datetime import datetime

        from cambium.a2ui.renderers import render_insight
        from cambium.core.spine import Spine
        from cambium.core.types import (
            BehavioralEvent,
            CoherenceScore,
            IdentityProfile,
        )

        spine = Spine(domain=domain, service=svc)
        identity_obj = IdentityProfile.model_validate(identity)
        score_objs = [CoherenceScore.model_validate(s) for s in scores]
        event_objs = [BehavioralEvent.model_validate(e) for e in events]
        insight, cert = spine.synthesize_window(
            identity=identity_obj,
            scores=score_objs,
            events=event_objs,
            window_start=datetime.fromisoformat(window_start),
            window_end=datetime.fromisoformat(window_end),
        )
        a2ui_doc = render_insight(insight=insight, certificate=cert, scores=score_objs)
        return {
            "insight": insight.model_dump(mode="json"),
            "certificate": cert.model_dump(mode="json"),
            "a2ui_directive": a2ui_doc.model_dump(mode="json"),
        }

    @server.tool("list_manifests")
    def list_manifests(domain: str | None = None) -> list[dict[str, Any]]:
        manifests = []
        for mid, m in svc._manifests.items() if hasattr(svc, "_manifests") else []:
            if domain is None or m.domain == domain:
                manifests.append(m.model_dump(mode="json"))
        return manifests

    @server.tool("get_manifest")
    def get_manifest(manifest_id: str) -> dict[str, Any]:
        return svc.get_manifest(manifest_id).model_dump(mode="json")

    @server.tool("verify_certificate")
    def verify_certificate(
        certificate: dict[str, Any], insight: dict[str, Any]
    ) -> dict[str, Any]:
        from cambium.core.provenance import InProcessSigner, verify_certificate as _verify
        from cambium.core.types import Insight, ProvenanceCertificate

        cert = ProvenanceCertificate.model_validate(certificate)
        insight_obj = Insight.model_validate(insight)
        # Use the in-process signer's key registry by default; production
        # injects its own verify_fn against Timber's keystore.
        signer = InProcessSigner()
        signer.register_key("cambium-dev-1", b"cambium-dev-shared-secret-for-tests-only")
        ok = _verify(cert=cert, insight=insight_obj, verify_fn=signer.verify)
        return {"ok": ok, "certificate_id": cert.certificate_id}

    @server.tool("list_domains")
    def list_domains() -> list[dict[str, Any]]:
        return [{"name": d} for d in svc.list_domains()]

    return server


__all__ = ["build_server"]
