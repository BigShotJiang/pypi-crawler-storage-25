"""Cambium core — domain-agnostic spine, types, and infrastructure."""
