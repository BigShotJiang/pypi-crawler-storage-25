"""OpenTelemetry hooks. No-op when OTel is not installed.

Cambium emits one span per Claude call site with structured attributes:
manifest hash, call site, model, latency, tokens, confidence, validity.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator

try:
    from opentelemetry import trace as _otel_trace

    _TRACER = _otel_trace.get_tracer("cambium")
    _OTEL = True
except ImportError:  # pragma: no cover
    _TRACER = None
    _OTEL = False


@contextmanager
def call_site_span(
    name: str,
    attributes: dict[str, Any] | None = None,
) -> Iterator[Any]:
    """Open a span for a call site; no-op if OTel is absent."""
    if not _OTEL or _TRACER is None:
        yield None
        return
    with _TRACER.start_as_current_span(name, attributes=attributes or {}) as span:
        yield span


def set_attribute(span: Any, key: str, value: Any) -> None:
    if span is not None and hasattr(span, "set_attribute"):
        span.set_attribute(key, value)


__all__ = ["call_site_span", "set_attribute"]
