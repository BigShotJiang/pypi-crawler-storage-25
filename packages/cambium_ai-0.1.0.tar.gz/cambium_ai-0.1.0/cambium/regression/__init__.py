"""Regression CI — PROMOTE / HOLD / BLOCK gate against the golden sets."""

from cambium.regression.runner import GateDecision, evaluate_gates  # noqa: F401

__all__ = ["GateDecision", "evaluate_gates"]
