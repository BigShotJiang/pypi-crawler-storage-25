"""Regression CI gate.

Runs every call site's evaluation against the active golden set, compares
to the baseline (active manifest), and emits PROMOTE / HOLD / BLOCK with
reasons. The CI is the ONLY authority that activates a new manifest in
production.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from cambium.core.types import Manifest

Decision = Literal["PROMOTE", "HOLD", "BLOCK"]


@dataclass
class GateDecision:
    decision: Decision
    candidate_manifest_id: str
    baseline_manifest_id: str
    reasons: list[str] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)
    candidate_hash: str = ""
    baseline_hash: str = ""


def evaluate_gates(
    *,
    candidate: Manifest,
    baseline: Manifest,
    candidate_metrics: dict[str, Any],
    baseline_metrics: dict[str, Any],
    thresholds: dict[str, float],
    regression_tolerance: float = 0.03,
) -> GateDecision:
    """Compare candidate vs baseline against absolute floors and tolerances."""
    reasons: list[str] = []
    block = False

    # Absolute floors (from thresholds)
    cls_f1 = candidate_metrics.get("classifier", {}).get("macro_f1", 0.0)
    cls_acc = candidate_metrics.get("classifier", {}).get("accuracy", 0.0)
    rsn_mae = candidate_metrics.get("reasoner", {}).get("score", {}).get("mae", 1.0)
    rsn_dir = candidate_metrics.get("reasoner", {}).get("direction_agreement", 0.0)
    syn_judge = candidate_metrics.get("synthesizer", {}).get("judge_mean_overall", 0.0)
    cal_ece = (
        candidate_metrics.get("classifier", {})
        .get("calibration", {})
        .get("ece", 1.0)
    )

    if cls_f1 < thresholds.get("classifier_f1_min", 0.75):
        block = True
        reasons.append(f"classifier macro_f1 {cls_f1:.2f} below floor")
    if cls_acc < thresholds.get("classifier_accuracy_min", 0.80):
        block = True
        reasons.append(f"classifier accuracy {cls_acc:.2f} below floor")
    if rsn_mae > thresholds.get("reasoner_score_mae_max", 0.20):
        block = True
        reasons.append(f"reasoner score MAE {rsn_mae:.2f} above ceiling")
    if rsn_dir < thresholds.get("reasoner_direction_agreement_min", 0.80):
        block = True
        reasons.append(f"reasoner direction agreement {rsn_dir:.2f} below floor")
    if syn_judge < thresholds.get("synthesizer_judge_min", 0.70):
        block = True
        reasons.append(f"synthesizer judge mean {syn_judge:.2f} below floor")
    if cal_ece > thresholds.get("calibration_ece_max", 0.10):
        block = True
        reasons.append(f"calibration ECE {cal_ece:.2f} above ceiling")

    if block:
        return GateDecision(
            decision="BLOCK",
            candidate_manifest_id=candidate.manifest_id,
            baseline_manifest_id=baseline.manifest_id,
            reasons=reasons,
            metrics=candidate_metrics,
            candidate_hash=candidate.content_hash(),
            baseline_hash=baseline.content_hash(),
        )

    # Regression tolerance vs baseline
    def _regressed(name: str, candidate_v: float, baseline_v: float, higher_is_better: bool) -> bool:
        diff = candidate_v - baseline_v
        if higher_is_better and diff < -regression_tolerance:
            reasons.append(
                f"{name} regressed: {candidate_v:.3f} vs baseline {baseline_v:.3f}"
            )
            return True
        if not higher_is_better and diff > regression_tolerance:
            reasons.append(
                f"{name} regressed: {candidate_v:.3f} vs baseline {baseline_v:.3f}"
            )
            return True
        return False

    cls_b_f1 = baseline_metrics.get("classifier", {}).get("macro_f1", 0.0)
    rsn_b_mae = baseline_metrics.get("reasoner", {}).get("score", {}).get("mae", 1.0)
    syn_b_judge = baseline_metrics.get("synthesizer", {}).get("judge_mean_overall", 0.0)

    hold = False
    if _regressed("classifier macro_f1", cls_f1, cls_b_f1, higher_is_better=True):
        hold = True
    if _regressed("reasoner MAE", rsn_mae, rsn_b_mae, higher_is_better=False):
        hold = True
    if _regressed("synthesizer judge mean", syn_judge, syn_b_judge, higher_is_better=True):
        hold = True

    decision: Decision = "HOLD" if hold else "PROMOTE"
    if decision == "PROMOTE":
        reasons.append("All floors met; no regression beyond tolerance.")
    return GateDecision(
        decision=decision,
        candidate_manifest_id=candidate.manifest_id,
        baseline_manifest_id=baseline.manifest_id,
        reasons=reasons,
        metrics=candidate_metrics,
        candidate_hash=candidate.content_hash(),
        baseline_hash=baseline.content_hash(),
    )


__all__ = ["GateDecision", "evaluate_gates"]
