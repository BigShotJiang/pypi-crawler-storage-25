"""Classifier call site.

Given a single BehavioralEvent + the domain's permitted categories,
return ``{semantic_category, confidence, structural_validity}``.

One repair retry is allowed on invalid output; second failure labels
``unclassified``.
"""

from __future__ import annotations

from typing import Any

from cambium.claude.client import get_default_claude_client
from cambium.core.domain import DomainConfig
from cambium.core.redaction import Redactor, RedactionMapping
from cambium.core.types import BehavioralEvent, IdentityProfile, Manifest
from cambium.prompts.classifier import CLASSIFIER_SYSTEM, build_classifier_prompt


def run_classifier(
    *,
    identity: IdentityProfile,
    event: BehavioralEvent,
    domain_config: DomainConfig,
    manifest: Manifest,
    claude_client: Any | None = None,
    redactor: Redactor | None = None,
    mapping: RedactionMapping | None = None,
) -> dict[str, Any]:
    client = claude_client or get_default_claude_client()
    redactor = redactor or Redactor(extra_patterns=domain_config.extra_redaction_patterns)
    mapping = mapping or RedactionMapping(user_id_hash=identity.user_id_hash)
    redacted_description = redactor.redact_text(event.description, mapping)
    prompt = build_classifier_prompt(
        event=event,
        redacted_description=redacted_description,
        categories=domain_config.categories,
        domain_voice=domain_config.prompt_voice,
    )
    response = client.complete_structured(
        model=manifest.classifier_model,
        system=CLASSIFIER_SYSTEM,
        prompt=prompt,
        temperature=0.0,
        max_tokens=256,
    )
    structured = response.structured
    category = structured.get("semantic_category", "unclassified")
    if category not in domain_config.categories:
        # One repair retry: ask the model to choose from the set explicitly.
        retry_prompt = prompt + (
            "\n\nPrevious answer used a category not in the permitted set. "
            f"Choose strictly from: {list(domain_config.categories)}. Return JSON."
        )
        response = client.complete_structured(
            model=manifest.classifier_model,
            system=CLASSIFIER_SYSTEM,
            prompt=retry_prompt,
            temperature=0.0,
            max_tokens=256,
        )
        structured = response.structured
        category = structured.get("semantic_category", "unclassified")
        if category not in domain_config.categories:
            category = "unclassified"
    confidence = float(structured.get("confidence", 0.3))
    confidence = max(0.0, min(1.0, confidence))
    return {
        "semantic_category": category,
        "confidence": confidence,
        "structural_validity": category != "unclassified",
        "prompt": prompt,
        "response_raw": response.raw,
        "input_tokens": response.input_tokens,
        "output_tokens": response.output_tokens,
        "latency_ms": response.latency_ms,
    }


__all__ = ["run_classifier"]
