"""Reasoner call site.

Given (IdentityProfile, BehavioralEvent, ClassifiedEvent, baseline),
return ``{reasoner_adjustment, dimensions_cited, justification,
confidence}``. The spine clips the adjustment to ±ceiling after the
call.
"""

from __future__ import annotations

from typing import Any

from cambium.claude.client import get_default_claude_client
from cambium.core.domain import DomainConfig
from cambium.core.redaction import Redactor, RedactionMapping
from cambium.core.types import BehavioralEvent, ClassifiedEvent, IdentityProfile, Manifest
from cambium.prompts.reasoner import REASONER_SYSTEM, build_reasoner_prompt


def run_reasoner(
    *,
    identity: IdentityProfile,
    event: BehavioralEvent,
    classified: ClassifiedEvent,
    baseline: float,
    domain_config: DomainConfig,
    manifest: Manifest,
    claude_client: Any | None = None,
    redactor: Redactor | None = None,
    mapping: RedactionMapping | None = None,
) -> dict[str, Any]:
    client = claude_client or get_default_claude_client()
    redactor = redactor or Redactor(extra_patterns=domain_config.extra_redaction_patterns)
    mapping = mapping or RedactionMapping(user_id_hash=identity.user_id_hash)
    redacted_description = redactor.redact_text(event.description, mapping)
    prompt = build_reasoner_prompt(
        identity=identity,
        event=event,
        redacted_description=redacted_description,
        classified=classified,
        baseline=baseline,
        ceiling=manifest.reasoner_adjustment_ceiling,
        permitted_dimensions=domain_config.dimensions,
        domain_voice=domain_config.prompt_voice,
    )
    response = client.complete_structured(
        model=manifest.reasoner_model,
        system=REASONER_SYSTEM,
        prompt=prompt,
        temperature=0.2,
        max_tokens=512,
    )
    structured = response.structured
    adjustment = float(structured.get("reasoner_adjustment", 0.0))
    cited = list(structured.get("dimensions_cited", []))
    justification = str(structured.get("justification", ""))
    confidence = float(structured.get("confidence", 0.5))
    return {
        "reasoner_adjustment": adjustment,
        "dimensions_cited": cited,
        "justification": justification,
        "confidence": max(0.0, min(1.0, confidence)),
        "prompt": prompt,
        "response_raw": response.raw,
        "input_tokens": response.input_tokens,
        "output_tokens": response.output_tokens,
        "latency_ms": response.latency_ms,
        "critique_model": manifest.reasoner_model,
    }


__all__ = ["run_reasoner"]
