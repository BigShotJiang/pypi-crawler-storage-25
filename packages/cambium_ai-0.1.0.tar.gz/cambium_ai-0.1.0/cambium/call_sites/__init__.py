"""The three bounded Claude call sites.

Each call site is a thin function that:
- Receives a domain-config + prompt template + input data.
- Calls the model once.
- Returns a structured dict the spine then validates / clips / traces.

No call site speaks to a database, a vector store, or the network
other than the model API. Tool use is the spine's responsibility, not
the call site's. This is the architectural commitment that makes
Cambium auditable.
"""
