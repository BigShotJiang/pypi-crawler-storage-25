"""Synthesizer call site.

Given a window of CoherenceScore values + the underlying events,
write a short coherence summary (headline + body + suggested_actions
+ tone + referenced ids).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from cambium.claude.client import get_default_claude_client
from cambium.core.domain import DomainConfig
from cambium.core.types import BehavioralEvent, CoherenceScore, IdentityProfile, Manifest
from cambium.prompts.synthesizer import SYNTHESIZER_SYSTEM, build_synthesizer_prompt


def run_synthesizer(
    *,
    identity: IdentityProfile,
    scores: list[CoherenceScore],
    events: list[BehavioralEvent],
    window_start: datetime,
    window_end: datetime,
    domain_config: DomainConfig,
    manifest: Manifest,
    claude_client: Any | None = None,
) -> dict[str, Any]:
    client = claude_client or get_default_claude_client()
    prompt = build_synthesizer_prompt(
        identity=identity,
        scores=scores,
        events=events,
        window_start=window_start,
        window_end=window_end,
        permitted_dimensions=domain_config.dimensions,
        domain_voice=domain_config.prompt_voice,
    )
    response = client.complete_structured(
        model=manifest.synthesizer_model,
        system=SYNTHESIZER_SYSTEM,
        prompt=prompt,
        temperature=0.4,
        max_tokens=1024,
    )
    structured = response.structured
    return {
        "headline": str(structured.get("headline", ""))[:160],
        "body": str(structured.get("body", ""))[:1200],
        "tone": structured.get("tone", "neutral"),
        "referenced_event_ids": list(structured.get("referenced_event_ids", [])),
        "referenced_dimensions": list(structured.get("referenced_dimensions", [])),
        "suggested_actions": list(structured.get("suggested_actions", []))[:5],
        "prompt": prompt,
        "response_raw": response.raw,
        "input_tokens": response.input_tokens,
        "output_tokens": response.output_tokens,
        "latency_ms": response.latency_ms,
    }


__all__ = ["run_synthesizer"]
