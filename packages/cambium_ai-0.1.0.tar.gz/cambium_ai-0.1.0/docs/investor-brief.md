# Cambium investor brief

For circulation to OakQuant investors. Two pages.

## What

Cambium is OakQuant's behavioral coherence engine — a bounded-agent
framework that measures alignment between a user's stated identity
(via psychometric assessment) and their revealed behavior (via
transaction data), and delivers weekly reflective insight to users.

It is the layer that turns a static identity assessment into an
ongoing relationship.

## Why now

Two trends converge:

1. **Bounded agents are becoming the default for regulated domains.**
   Enterprises increasingly distinguish "general agents" from
   "bounded agents under deterministic spines." Financial advice,
   healthcare guidance, employment decisions, and credit assessments
   are all migrating to the bounded pattern. Cambium is the platform
   pattern for that migration.

2. **Identity-as-static is dying.** Robo-advisors built on one-time
   risk questionnaires are losing to platforms that recognize identity
   evolves and that behavior is the most reliable signal of evolution.
   Cambium turns continuous behavior into continuous identity
   refinement.

## Defensible IP layers

Three layers, each independently defensible:

### Layer 1: Bounded-agent architecture (publishable but pattern-defining)

Three LLM call sites, deterministic spine, content-hashed manifests,
regression-gated promotion, multi-judge consensus, active learning.
The pattern itself is patent-resistant (broad prior art) but Cambium
is the canonical implementation; the platform that adopts the pattern
first defines its vocabulary.

### Layer 2: Financial DNA Protocol + golden sets

The Financial DNA Protocol is a 16-screen psychometric assessment
grounded in seven academic frameworks (Klontz Money Scripts,
Behavioral Life-Cycle Hypothesis, Prospect Theory, Goal-Setting
Theory, Self-Determination Theory, Social Cognitive Theory,
Financial Socialization Theory).

The golden sets — hand-labeled examples for each call site — are the
training-free analog of fine-tuned model weights. They are
trade-secret-protectable, expensive to reproduce, and improve
monotonically over time via the active-learning loop.

### Layer 3: Multi-domain extensibility

Cambium plugs in new domains (health, career, sustainability,
learning, relational) via YAML config + a small Python implementation
+ a golden seed dataset. The platform's market expands by domain
without forking the codebase.

## Competitive positioning

| Competitor type | Where they fall short |
|---|---|
| Robo-advisors (Betterment, Wealthfront) | Static identity model; no behavioral coherence |
| Behavioral finance apps | Coaching content, not personalized real-time signal |
| LLM chatbots wrapped in finance | Unbounded; cannot pass institutional audit |
| Custom enterprise platforms | Not productized; cannot achieve consumer cadence |

Cambium occupies the intersection: behaviorally personalized, LLM-
powered, but bounded enough to be auditable.

## Roadmap (12 months)

- **Q1** (now): Finance domain at v1; Plaid integration; weekly
  insight delivery in Sky; regression CI gating manifest promotion.
- **Q2**: Active-learning loop in production; first 1,000-example
  golden set milestone; shadow A/B production rollout.
- **Q3**: Cross-domain handoff infrastructure; first health-domain
  prototype.
- **Q4**: MCP server available for third-party integrators;
  white-label deployment for first enterprise design partner.

## Economic model

Three cost levers, all bounded:

- **Per-event LLM cost**: classifier + reasoner ≤ 1,500 tokens per
  event. At Anthropic's current Claude 4.5 Haiku pricing tier, this
  is sub-cent per user-per-week even at high event volumes.
- **Per-week LLM cost**: synthesizer ≤ 4,000 tokens per user per
  week. Sub-cent per user.
- **Judge cost**: amortized over the manifest, not per user. Run
  during eval cycles only.

Total LLM spend per user per year is bounded below $1. The
constraint on monetization is value-perception, not COGS.

## What we want from this round

Investment to fund:

- Expansion of the finance golden set from seed to v3 (1,000+
  examples across the three call sites).
- Production deployment of Cambium with first cohort of OakQuant
  beta users.
- Build of Ranger's HITL surfaces.
- First non-finance domain plugin (health or career).

We are seeking $750K at a $4.5M pre-money cap.

## Reference

For architectural detail, see `docs/ARCHITECTURE.md` and
`docs/agentic-patterns.md`. For technical depth, see the open-source
code under Apache 2.0 license — Cambium itself is publishable; the
golden sets and the trained-up manifest content are not.
