# Cambium Architecture

This document is the canonical reference for how Cambium is built and
why. Read this before extending or modifying the core.

## 1. Core thesis

A bounded-agent system has three failure modes that matter:

1. **The model decides things the system shouldn't let it decide.**
   (Unbounded tool use, multi-step autonomy without guardrails.)
2. **The model is asked questions outside its competence.**
   (Vague prompts, no structured output, no validation.)
3. **The system has no way to know whether the model is wrong.**
   (No eval framework, no calibration, no drift detection.)

Cambium addresses all three. The spine controls flow; the model
answers narrowly scoped questions; the eval framework with golden
sets, deterministic and LLM judges, calibration tracking, and
regression CI gates governs which manifest is allowed to run.

The shorthand is:

> The deterministic spine decides what to ask. The model only answers.
> The eval framework decides whether the answer counted.

## 2. Component map

```
cambium/
├── core/              # Domain-agnostic spine and types
│   ├── types.py           # IdentityProfile, BehavioralEvent, ...
│   ├── domain.py          # DomainConfig, DomainRegistry, BaselineScorer
│   ├── spine.py           # Spine — the orchestrator
│   ├── redaction.py       # PII redaction with reversible mapping
│   ├── trace.py           # Append-only trace recorder
│   ├── calibration.py     # Brier, ECE, reliability bins
│   ├── provenance.py      # Signed certificates
│   ├── mcp_server.py      # MCP tool interface
│   └── otel.py            # OpenTelemetry hooks
│
├── prompts/           # Versioned prompt templates
├── call_sites/        # The three bounded LLM call sites
├── claude/            # Anthropic SDK wrapper + critique + consensus
├── coherence/         # Scorer and explainer helpers
│
├── evals/             # Eval framework
│   ├── golden.py          # GoldenSet, GoldenExample
│   ├── metrics.py         # F1, IoU, MAE, direction agreement
│   ├── runner.py          # EvalRunner — per-call-site eval
│   ├── active_learning.py # Selection strategies + queue
│   ├── drift.py           # PSI, KL drift detection
│   └── judges/            # Deterministic, LLM, consensus
│
├── regression/        # CI gate (PROMOTE / HOLD / BLOCK)
├── ab/                # Shadow A/B harness + paired stats
│
├── timber/            # Timber integration (rules, factories, service)
├── grove/             # Grove integration (adapter, events, handoffs)
├── a2ui/              # Surface-independent UI components
│
├── service.py         # CambiumService Protocol + four implementations
│
├── domains/
│   ├── finance/           # Plugin #1
│   └── _template/         # Copy-and-edit starter
│
└── skills/            # Developer and runtime Claude skills

timber_configs/        # YAML configs for timber-common model factory
golden_seeds/          # Hand-labeled examples (60 for finance)
tests/                 # Pytest suite
examples/              # Runnable demonstrations
docs/                  # This document and others
```

## 3. The three call sites

### 3.1 Classifier

Given a single `BehavioralEvent`, which of the domain's `categories`
best describes the user's intent, plus confidence in [0, 1].

Output is structured JSON. Category must be in the domain's
permitted set; one repair retry on invalid; second failure labels
"unclassified" and routes to active-learning.

### 3.2 Reasoner

Given (`IdentityProfile`, `BehavioralEvent`, `ClassifiedEvent`,
deterministic baseline), what adjustment between **-ceiling** and
**+ceiling** improves the coherence score, plus cited dimensions
and a one-sentence justification.

Output is structured JSON. The spine clips the adjustment to the
ceiling after the call — the model can't override the bound.
Dimension citations are filtered to the permitted set. Optional
constitutional self-critique pass can only weaken adjustments.

### 3.3 Synthesizer

Given a window of coherence scores and the underlying events, write
a short coherence summary (headline, body, suggested_actions)
referencing specific events and dimensions.

Output is structured JSON. Length limits enforced; event and
dimension references validated; LLM judge scores six rubric
dimensions; multi-judge consensus supported.

## 4. The Manifest

The Manifest is the **content-hashed bundle** of prompt content
hashes, model selections, rules-package version, constitution
version, and domain reference. It is immutable; changes require new
manifests; the regression CI decides PROMOTE / HOLD / BLOCK against
the golden sets. This is pattern 11 (Design-time → Runtime) from the
13 agentic patterns.

## 5. The trace

Every Claude call writes one trace record. The trace is append-only;
redactions are written as new rows. The trace is the ground truth
Cambium reasons over: eval, drift detection, active learning, and
audit all read from it.

## 6. Service abstraction

All configurable parameters flow through `CambiumService`. Four
implementations selectable via `CAMBIUM_SERVICE_IMPL`:

| Impl | Use | Notes |
|---|---|---|
| `InMemoryCambiumService` | Tests, demos | No persistence |
| `YamlCambiumService` | Local dev | Reads YAML configs |
| `TimberCambiumService` | Production | Backed by timber-common |
| Ranger UI service | Operator | Writes through; emits cache-invalidation events |

## 7. The eval framework

### 7.1 Golden sets

Versioned JSONL of labeled `GoldenExample` rows. Two reviewers
minimum per example. Removal is tombstoning, not deletion. The set
grows monotonically.

### 7.2 Judges

- **Deterministic** judges for classifier and reasoner.
- **LLM** judge for synthesizer with structured rubric.
- **Consensus** judge running two LLM judges, routing disagreement
  to active learning.

### 7.3 Regression CI

`evaluate_gates()` runs every call site's evaluation, computes
calibration, and compares against the active manifest. The CI is the
**only** authority that activates a new manifest in production.

### 7.4 Active learning

Five selection strategies: low_confidence, judge_disagreement,
direction_flip, novel_pattern, user_negative_signal. Selected
candidates write to a JSONL queue; reviewers label them; the labeled
examples join the next golden-set version.

### 7.5 Drift detection

PSI and KL divergence over fixed canary sets detect distributional
change. Emits a Grove `ManifestDriftAlert` event.

## 8. Domain plug-in architecture

A domain provides config.yaml, identity.py, events.py, baseline.py,
and golden seed JSONL files. Domain code never imports cross-domain;
cross-domain signals flow through Grove events. See
`docs/multi-domain-architecture.md` for details.

## 9. Grove and Timber seams

**Grove.** `GroveAdapter` exposes Cambium as a Celery worker class;
typed events drive workflow patterns; saga compensations for
rollback; cross-domain handoff schema. See `docs/agentic-patterns.md`
for which workflow patterns Grove owns.

**Timber.** Model factory generates SQLAlchemy persistence from
YAML; rules engine consumes declarative rule definitions; field-level
encryption for redaction and captures; vector search for few-shot
retrieval. See `docs/timber-integration.md` for details.

## 10. Provenance and verifiability

Every insight carries a signed `ProvenanceCertificate`. The signature
is over a canonical encoding of the insight bound to the manifest
and golden set. Anyone with the public key can verify offline that a
specific insight came from a specific manifest with a specific
golden-set version.

## 11. Non-goals

Cambium intentionally does not do free-form chat, tool use inside
call sites, multi-step model reasoning within one call site, or
replace human judgment. The synthesizer's output is observational,
not prescriptive.

## 12. Decision log (selected)

| Decision | Rationale |
|---|---|
| ±0.3 reasoner ceiling | Empirical: larger ceilings collapse the baseline's anchor effect. Domains can override but should justify. |
| Three call sites, not two or four | Minimum to express the coherence task; more invites pattern 1 (chaining) becoming pattern 7 (orchestrator-workers), which belongs in Grove. |
| Append-only trace | Read-write traces invite silent edit; audit-grade requires append-only with explicit redaction markers. |
| Content-hashed manifest | Manifest identity is structural; two manifests with identical content are the same regardless of creation time. |
| Service-layer abstraction | Lets the same Cambium core run in tests, dev, production, and Ranger without code change. |
| Domain plug-ins ship YAML + 4 Python files | Lowest plausible bar without sacrificing inspectability of the baseline formula. |
| Golden sets in JSONL with reviewers | Plain text, diffable, reviewable. Database-only golden sets become unreviewable assets. |
| Apache 2.0 + CC-BY 4.0 split | Library should be permissively reusable; golden sets are author-attributable research artifacts. |
