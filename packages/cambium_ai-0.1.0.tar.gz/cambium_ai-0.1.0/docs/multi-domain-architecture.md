# Multi-domain architecture

Cambium is a meta-framework, not a finance product. The finance
domain (personal financial coherence using the Financial DNA Protocol
and Plaid transactions) is plugin #1. Other domains plug in via the
same interfaces.

## Why multi-domain matters

The bounded-agent coherence pattern — measuring alignment between
stated identity and revealed behavior with three bounded LLM call
sites and a deterministic spine — applies anywhere there is:

1. A measurable instrument for stated identity (assessment, survey,
   baseline, intake).
2. A measurable signal source for revealed behavior (transactions,
   wearable data, calendar, content consumption, location).
3. A user who would benefit from non-judgmental weekly reflection on
   the coherence between (1) and (2).

That's a large set of domains. Cambium's value to OakQuant is that
each new domain plugs in via configuration + a small Python
implementation + a golden seed dataset, not via a forked codebase.

## Candidate domains

The candidate domains below illustrate the breadth without committing
to a build order:

| Domain | Stated-identity instrument | Revealed-behavior signal | Example dimensions |
|---|---|---|---|
| **Finance** (plugin #1) | Financial DNA Protocol | Plaid transactions | future_orientation, risk_tolerance, family_orientation, ... |
| **Health** | Lifestyle assessment + biometric baseline | Wearable + food log + sleep | energy_management, recovery_priority, ... |
| **Career** | Work-values + skills inventory | Calendar + Slack + GitHub | focus_priority, collaboration, ... |
| **Sustainability** | Environmental values | Carbon-impact transactions + travel | consumption_minimalism, locality, ... |
| **Learning** | Goals + curiosity profile | Content consumption + reading log | depth, breadth, ... |
| **Relational** | Values + relationship aspirations | Communication patterns | reciprocity, presence, ... |

Each domain has its own golden set, its own baseline scorer, and its
own assessment instrument. The eval framework, manifest discipline,
trace, redaction, certificate, and Grove integration are reused.

## What is shared

| Component | Shared / Per-domain |
|---|---|
| Core types (`IdentityProfile`, `BehavioralEvent`, etc.) | Shared (generic, domain-agnostic) |
| Spine | Shared |
| Three call sites | Shared (read domain config) |
| Redactor | Shared (extensible patterns) |
| Trace recorder | Shared |
| Calibration, drift | Shared |
| Provenance | Shared |
| Manifest schema | Shared |
| Eval framework | Shared |
| Regression CI | Shared |
| Shadow A/B | Shared |
| Rules engine | Shared (rule values may vary) |
| A2UI rendering | Shared |
| MCP server | Shared |
| Grove adapter, events | Shared |
| **Domain config** | Per-domain (YAML) |
| **Identity capture** | Per-domain |
| **Event adapter** | Per-domain |
| **Baseline scorer** | Per-domain |
| **Golden seed** | Per-domain |
| **Prompt overrides** | Per-domain (optional) |

## How a new domain plugs in

```python
from pathlib import Path
from cambium import get_default_service

service = get_default_service()
service.domain_registry().register_from_yaml(
    Path("cambium/domains/<new_domain>/config.yaml"),
)
```

The `cambium-add-domain` developer skill walks Claude Code through
the full process: copy the template, edit the config, implement the
four required modules, author the golden seed, run the eval.

## Per-domain customization without forking

A new domain can customize:

- **Dimensions**: 5-12 dimensions; domain-specific.
- **Categories**: 8-15 behavioral categories; domain-specific.
- **Narrative tags**: categorical identity claims (optional).
- **Baseline formula**: per-dimension contributions; per-category
  valence; magnitude modifiers.
- **Prompt voice**: domain-specific tone hints injected into base
  prompts.
- **Redaction extras**: additional regex patterns for domain-specific
  PII (provider names, project codes).
- **Eval thresholds**: per-domain floors; defaults inherited.
- **Catastrophizing tokens**: additional banned tokens for the
  domain's content policy.

What a domain *cannot* customize:

- The call-site contract (three call sites, structured outputs).
- The bounded-agent thesis.
- The manifest content-hash discipline.
- The provenance certificate format.

These are platform-level invariants. Honoring them is how a new
domain inherits Cambium's audit guarantees.

## Cross-domain handoffs

Some signals matter across domains. A finance-domain pattern of
"escape spending" correlates with career-domain burnout markers. A
health-domain decline in sleep correlates with finance-domain impulse
spending. These cross-correlations are valuable to surface.

Cambium handles them via the cross-domain handoff event
(`cambium/grove/events.py::CrossDomainHandoffRequested`). The source
domain's pipeline emits the event with a `HandoffContext`; Grove
invokes the target domain's spine with the context; the target
domain incorporates the handoff signal into its reasoning.

This keeps domain code isolated (no cross-imports) while enabling
cross-domain reasoning at the workflow layer.

## Build order recommendation

Build domains in order of:

1. **Signal-source quality.** Plaid for finance is ideal — high
   volume, low noise, broadly available.
2. **Instrument readiness.** Existing validated psychometric
   instruments save months over building new ones.
3. **User-value clarity.** Where weekly coherence reflection has
   highest perceived value.
4. **Regulatory acceptability.** Avoid domains with extreme
   regulatory burden until the platform is mature.

Finance scores high on all four. Health and career are strong
candidates for plugin #2.
