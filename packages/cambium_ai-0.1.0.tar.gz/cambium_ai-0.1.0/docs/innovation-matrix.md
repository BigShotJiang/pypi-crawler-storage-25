# Innovation matrix

A two-axis view of Cambium's distinctive moves. Useful for press,
academic abstracts, and competitive positioning.

|  | **Standard practice in 2026** | **Cambium's move** |
|---|---|---|
| Agent control flow | Model decides next step | Spine decides; model only answers |
| Output bounds | Soft guardrails (string filters) | Numeric bounds + declarative rules + constitutional critique |
| Confidence | Self-reported, untracked | Self-reported, calibration-tracked, used for active learning |
| Personalization data | Identity capture once | Identity capture × continuous coherence × weekly synthesis |
| Memory | Long-context history | Bounded window + content-hashed manifest |
| Auditability | Logs, maybe LangSmith | Trace + provenance certificates + content-hashed manifests |
| Evaluation | Once-per-release, accuracy-only | Continuous, multi-metric (accuracy + calibration + drift) |
| Eval data | Static test set | Active-learning loop expanding the set |
| Judges | Single LLM judge | Multi-judge consensus with disagreement routing |
| RAG | Tool-using LLM retrieves | Spine retrieves; model gets enriched context |
| Tool use | LLM decides to invoke tools | Spine enriches context; no LLM-side tool calls |
| Output surfaces | Per-surface custom strings | A2UI documents with surface-independent renderers |
| Model swapping | Hard; coupled to prompts | One service parameter; manifest controls scope |
| Multi-tenancy | Hard-coded per-customer | Manifest A/B + skill overlays |
| Multi-domain | New domain = new app | New domain = config + 4 files + golden seed |
| Cross-domain insight | Manual integration | Cross-domain handoff events orchestrated by workflow |
| Promotion | Manual deploy | Regression-gated PROMOTE/HOLD/BLOCK |
| Drift | Not monitored | PSI + KL + canary; alerts gated to manifest changes |
| Failure | Silent fallback | Trace-recorded fallback with reason |
| Compensation | None | Saga inverse operations registered with Grove |
| Inter-system | Bespoke API | MCP server with typed tools |
| Observability | Application logs | OpenTelemetry spans with structured attributes |
| Privacy | Logs scrubbed | Pre-call redaction + reversible mapping + keystore |
| Right-to-erasure | Hard | Drop the mapping row; traces remain as aggregate signal |
| Patterns | Implicit | Explicit mapping to the 13 agentic patterns |

The pattern across the rows: Cambium pushes structure that other
platforms push to humans or to luck.
