# Cambium program plan

Twelve-week build plan to take Cambium from this initial release to a
production deployment serving the first OakQuant cohort.

## Weeks 1-2: Foundations

- [x] Bounded-agent thesis articulated in code and docs.
- [x] Three call sites implemented with deterministic spines.
- [x] Service abstraction with InMemory and YAML implementations.
- [x] Manifest content-hashing + provenance certificates.
- [x] Trace recorder + redaction layer.
- [x] Multi-domain architecture with finance domain plugin.
- [x] Grove integration module with typed events and adapter.
- [ ] Internal review of architecture + agentic-patterns mapping.

## Weeks 3-4: Golden sets

- [ ] Author finance v1 golden seed: 60 examples across three call
      sites (20 each), hand-labeled by two reviewers.
- [ ] Establish labeling rubric documentation (already drafted in
      `cambium-author-golden-set` skill).
- [ ] Stand up Ranger's labeling UI for the active-learning queue.
- [ ] First regression CI run; establish baseline metrics.

## Weeks 5-6: Production wiring

- [ ] TimberCambiumService backed by production timber-common.
- [ ] Generate persistence classes via `timber.factories.generate_all()`.
- [ ] Migrate database with the generated classes.
- [ ] Configure encryption keystore + rotation schedule.
- [ ] Wire MCP server behind the platform auth proxy.

## Weeks 7-8: Eval framework end-to-end

- [ ] Active-learning loop in production.
- [ ] Drift detection running on a daily canary.
- [ ] Shadow A/B harness deployed.
- [ ] Calibration tracking visible in Ranger.
- [ ] Regression CI gating manifest promotion in CI/CD.

## Weeks 9-10: Sky integration

- [ ] A2UI renderer in Sky for `cambium.insight` documents.
- [ ] Coherence card drill-down with the explainer output.
- [ ] User feedback affordances wired to active learning.
- [ ] Provenance verify affordance.

## Weeks 11-12: First cohort

- [ ] Beta cohort: 50-100 OakQuant users with weekly insights.
- [ ] Operational dashboards: cost per user, latency, judge
      disagreement rate, drift severity, active-learning throughput.
- [ ] First post-cohort manifest update (v2).

## Quarter 2: Multi-domain

- [ ] Second domain plugin (health or career).
- [ ] Cross-domain handoff in production.
- [ ] Second domain golden seed.
- [ ] Skills extensibility evaluated with at least two runtime skills.

## Risks and mitigations

| Risk | Mitigation |
|---|---|
| Golden-set labor underestimated | Use active-learning loop early; start labeling alongside development |
| Drift alerts noisy in early production | Loose initial thresholds; tighten as data accumulates |
| Cross-domain handoff complexity | Build single-domain first; treat multi-domain as Q2+ |
| Sky A2UI renderer lags | Ship a basic email renderer first; Sky catches up |
| Timber API drift | Pin timber-common version; coordinate releases |

## Success criteria for v1 production

- 90+% manifest content-hash reproducibility (same inputs → same outputs).
- < 5% active-learning queue depth growth rate after 4 weeks.
- < 0.1 PSI on weekly canary distributions.
- Median insight judge score ≥ 0.75.
- User-reported "landed" rate ≥ 60%.
- Zero regulatory blockers.
