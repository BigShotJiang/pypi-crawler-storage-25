# Cambium and Timber

Cambium uses `timber-common` for persistence, encryption, rules,
vector retrieval, and keystore. This document describes the
integration in detail.

## Why maximum Timber leverage

`timber-common` is a published library on PyPI that Pumulo Sikaneta
maintains as part of the OakQuant platform. It provides:

- **Model-factory generation** from YAML to SQLAlchemy.
- **Field-level Fernet encryption** declared in YAML.
- **Rules engine** for declarative guardrails.
- **Vector search** for semantic retrieval.
- **GDPR retention** policies attached at the table level.
- **Encrypted keystore** with key rotation.
- **Repository abstractions** with caching.

Cambium consumes all of these. Hand-rolling persistence, encryption,
or rules in Cambium would duplicate Timber's investment and drift from
the rest of the platform.

## Persistence: the model factory

Cambium ships YAML configs under `timber_configs/` for every
persistence shape it needs:

- `identity_profile.yaml`
- `behavioral_event.yaml`
- `classified_event.yaml`
- `coherence_score.yaml`
- `insight.yaml`
- `manifest.yaml`
- `trace_record.yaml`
- `golden_example.yaml`
- `domain_config.yaml`

`cambium.timber.factories.generate_all()` reads these and produces the
SQLAlchemy classes via `timber_common.factories.model_factory`. The
generated classes have:

- Indexes declared in YAML.
- Field-level encryption where the YAML marks `encrypted: true`.
- GDPR retention policy from the YAML's `retention` block.
- Audit columns (`created_at`, `updated_at`, `created_by_manifest_hash`)
  added uniformly.

If you change a YAML config, regenerate the SQLAlchemy classes,
generate a migration, and bump the schema version. The Pydantic API
contract types in `cambium/core/types.py` should be modified in
lockstep.

## Encryption: redaction reverse-map

The redactor (`cambium/core/redaction.py`) produces a reverse-mapping
from pseudonyms back to original values. This mapping is highly
sensitive — it is the key to re-identifying production data — and is
stored encrypted via Timber's field-level encryption.

The encryption key is held in Timber's encrypted keystore and rotated
on a schedule. Cambium accesses encryption via
`common.services.encryption.field_encryption`; it never holds raw key material.

When a user invokes GDPR right-to-erasure, Grove orchestrates a
saga that drops the user's row from the redaction mapping table.
After that drop, historical traces still exist but cannot be
re-identified — they remain useful for aggregate analysis and
immutable for audit purposes.

## Rules: guardrails as data

Cambium's guardrails (`cambium/timber/rules.py`) are declared as
`timber_common.Rule` objects. Each rule has:

- A stable `rule_id` and a `version`.
- A `check` function (returns ok/violation tuple).
- An optional `repair` function (compensating modification).

Rules are assembled into a `RulesPackage` per call site:

- `build_reasoner_rules`: adjustment ceiling + dimension citation +
  catastrophizing filter.
- `build_synthesizer_rules`: dimension citation + event references +
  catastrophizing filter.

Because rules are data, Ranger can render them, version them, and
swap them without redeployment. Each rule's version flows into the
manifest content hash.

## Vector retrieval: few-shot examples

The reasoner consults the k nearest golden examples to the current
case when constructing its prompt. The retrieval lives in Timber's
vector index over golden examples; Cambium consumes it through the
service:

```python
class CambiumService(Protocol):
    def retrieve_similar_examples(
        self, *, domain: str, query: dict, k: int = 5,
    ) -> list[GoldenExample]: ...
```

Production (`TimberCambiumService`) implements this by calling
`common.services.vector.search.vector_search_service`; development (`YamlCambiumService`)
returns a fixed seed; tests (`InMemoryCambiumService`) returns the
test fixture.

## Caching

The `TimberCambiumService` caches the active manifest, domain
configs, redaction policy, eval thresholds, judge rubric, feature
flags, model overrides, and skills config for the lifetime of one
manifest activation. Configuration pushes from Ranger emit a
`cambium.config.changed` pub/sub event; the service subscribes and
invalidates its cache.

## GDPR retention

Each YAML config declares a `retention` block:

- `trace_records`: 18 months (regulatory standard); after that,
  traces are aggregated and detail is purged.
- `redaction_mappings`: tied to user retention; deleted on
  right-to-erasure.
- `identity_profiles`: retained for the user's life on platform.
- `coherence_scores`: 24 months; rolled up to aggregates after.
- `insights`: retained at the user's discretion.
- `golden_examples`: indefinite (research / platform IP).

Timber applies these policies via scheduled jobs.

## Keystore: provenance signing keys

The provenance certificate signing key is held in Timber's encrypted
keystore. `TimberCambiumService.sign_provenance(payload)` delegates
to the keystore. Key rotation is a Timber concern; Cambium references
keys by `key_id` so rotated keys can still verify old certificates.

## What if I want to run Cambium without Timber?

Use the `YamlCambiumService` and `InMemoryCambiumService`
implementations:

```bash
export CAMBIUM_SERVICE_IMPL=yaml
export CAMBIUM_CONFIG_DIR=./local_config
```

The YAML service backs everything Timber provides with file-system
artifacts and in-memory state. Encryption is best-effort (Fernet,
key in env), rules are evaluated by the Python rules adapter, vector
retrieval falls back to in-memory similarity. Not suitable for
production, but lets you develop, eval, and demo without Timber.

## Modifications requested in timber-common

Cambium's integration assumes specific timber-common APIs. If your
installed timber-common version differs, see
`docs/timber-modifications-requested.md` for the surface Cambium
requires and the rationale.
