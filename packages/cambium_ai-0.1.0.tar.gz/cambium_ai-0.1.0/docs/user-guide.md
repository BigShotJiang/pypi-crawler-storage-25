# Cambium user guide (for engineers integrating the library)

This guide walks an engineer from zero to a working Cambium pipeline
in their service.

## Install

```bash
pip install cambium
# or, if integrating with the OakQuant production platform:
pip install cambium[timber]
```

## Quick start (development, no Timber)

```python
from cambium import get_default_service
from cambium.core.spine import Spine
from cambium.core.types import IdentityProfile, BehavioralEvent
from cambium.domains.finance.identity import (
    FinancialDNACapture, ScreenResponse,
)
from cambium.domains.finance.events import from_plaid_transaction

# 1. Bootstrap the service (defaults to inmemory in dev).
service = get_default_service()

# 2. Capture identity once.
captured = FinancialDNACapture().reduce(
    user_id_hash="u:abc123",
    screens=[
        ScreenResponse("s01", {"q1": 0.7, "q2": 0.6, "q3": 0.8}),
        ScreenResponse("s02", {"q1": 0.3, "q2": 0.7, "q3": 0.5}),
        # ... all 16 screens
    ],
)

# 3. Build the spine for the finance domain.
spine = Spine(domain="finance", service=service)

# 4. Process a Plaid transaction.
event = from_plaid_transaction(
    user_id_hash="u:abc123",
    plaid_payload={
        "transaction_id": "tx:001",
        "date": "2026-01-15",
        "amount": 89.50,
        "name": "Local Bistro",
        "category": ["Food and Drink", "Restaurants"],
        "merchant_name": "Local Bistro",
    },
)
score = spine.process_event(identity=captured, event=event)
print(score.score, score.justification)

# 5. After collecting a week of scores, synthesize.
insight, certificate = spine.synthesize_window(
    identity=captured,
    scores=[score, ...],
    events=[event, ...],
    window_start=...,
    window_end=...,
)
print(insight.headline)
print(insight.body)
```

## Selecting a service implementation

```bash
# In-memory (tests, demos).
export CAMBIUM_SERVICE_IMPL=inmemory

# YAML-backed (development).
export CAMBIUM_SERVICE_IMPL=yaml
export CAMBIUM_CONFIG_DIR=./local_config

# Timber-backed (production).
export CAMBIUM_SERVICE_IMPL=timber
```

You can also pass a `service=` keyword to any Cambium entry point.

## Adding observability

Install `opentelemetry-api` and `opentelemetry-sdk`; configure your
exporter; Cambium spans will appear automatically.

## Integrating with Grove

```python
from cambium.grove import GroveAdapter, InMemoryEventBus

bus = InMemoryEventBus()
adapter = GroveAdapter(domain="finance", event_bus=bus)

# Register as a Celery task class in Grove:
class CambiumFinanceWorker(adapter, BaseTask):  # pseudocode
    ...
```

Subscribe to Cambium events from Grove:

```python
for event in bus.events:
    if event.event_type == "cambium.active_learning.candidate":
        # Route to labeling queue
        ...
```

## Running the eval framework

```bash
cambium eval --domain finance --call-site classifier \
    --golden golden_seeds/finance_v1.jsonl

cambium eval --domain finance --call-site reasoner \
    --golden golden_seeds/finance_v1.jsonl

cambium eval --domain finance --call-site synthesizer \
    --golden golden_seeds/finance_v1.jsonl
```

## Running the regression CI

```bash
cambium regress \
    --candidate manifests/finance_v2.yaml \
    --baseline manifests/finance_v1.yaml \
    --domain finance
```

Outputs a JSON report with PROMOTE / HOLD / BLOCK and the reasons.

## Adding a new domain

See the `cambium-add-domain` developer skill at
`cambium/skills/developer/cambium-add-domain/SKILL.md`.

## Verifying a provenance certificate

```python
from cambium.core.provenance import verify_certificate

ok = verify_certificate(
    cert=cert,
    insight=insight,
    verify_signature=lambda key_id, payload, sig: ...,  # your impl
)
```

## Common pitfalls

1. **Don't read environment variables in your call sites.** Use
   `service.get_*` methods.
2. **Don't bypass the redactor.** Pass redacted text to the LLM.
3. **Don't increase the adjustment ceiling without bumping the
   manifest version.** The eval CI must run.
4. **Don't add a fourth call site without the `cambium-add-call-site`
   skill.** The architectural contract is precise.
5. **Don't share insights across users.** Each insight is scoped to
   one user_id_hash.

## Where to look next

- `docs/ARCHITECTURE.md`: the architectural source of truth.
- `docs/agentic-patterns.md`: how the 13 patterns split between
  Cambium and Grove.
- `examples/`: working pipelines.
- `tests/`: contracts that must hold.
