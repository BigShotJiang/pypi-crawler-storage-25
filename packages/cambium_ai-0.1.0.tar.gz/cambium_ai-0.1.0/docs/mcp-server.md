# Cambium MCP server

Cambium exposes itself as a Model Context Protocol (MCP) server so
external agents (Claude Code, third-party agentic systems, the user's
own Grove orchestrations) can consume Cambium tools without taking a
Python dependency.

This is the operational instance of Pattern 9 (Delegation / Handoff)
at the inter-system boundary: Cambium offers a typed tool surface;
any MCP-compatible client can call it.

## Tools exposed

| Tool | Purpose |
|---|---|
| `process_event` | Take an IdentityProfile + BehavioralEvent, return CoherenceScore |
| `synthesize_window` | Take a window of scores/events, return Insight + ProvenanceCertificate |
| `list_manifests` | List manifests (optionally filtered by domain) |
| `get_manifest` | Get a specific manifest by id |
| `verify_certificate` | Verify a provenance certificate against an insight |
| `list_domains` | List registered domains |

## Transport

Cambium ships transport-agnostic tool registrations
(`cambium/core/mcp_server.py::build_server`). Choose a transport at
deploy time:

- **stdio**: ideal for Claude Code integration. Run as a subprocess.
- **SSE / HTTP**: ideal for Grove integration. Run as a service.

## Why MCP instead of bespoke API

Three reasons:

1. **Reuse.** MCP clients exist for many languages and platforms.
   A bespoke API would require client implementations.

2. **Agent-friendly.** MCP tools are designed for LLM agents to
   discover and invoke. Grove's agentic workers can use Cambium
   without Cambium-specific glue.

3. **Audit-friendly.** Every MCP call produces a structured trace.
   Combined with Cambium's internal trace, this gives end-to-end
   observability.

## Authentication

The MCP transport layer (the `mcp` package) handles authentication.
In OakQuant's production deployment, Cambium's MCP server runs behind
the platform's auth proxy; tokens are scoped per consumer. Ranger
manages token issuance and revocation.

## Rate limiting

Per-consumer rate limits live at the transport layer, not in Cambium
itself. A misbehaving consumer cannot exhaust Cambium's capacity by
flooding the MCP server.

## What MCP does NOT expose

The MCP surface is read-mostly. It exposes processing (`process_event`,
`synthesize_window`) and inspection (`list_manifests`, `get_manifest`,
`verify_certificate`, `list_domains`). It does NOT expose:

- Manifest promotion (Ranger's responsibility).
- Active-learning labeling (Ranger's responsibility).
- Direct trace access (Ranger's responsibility, with auth).
- Domain registration (deploy-time responsibility).

These are excluded because they are governance actions, not agentic
tool invocations. Putting them behind MCP would invite agentic
self-modification, which is the failure mode the bounded-agent thesis
exists to prevent.
