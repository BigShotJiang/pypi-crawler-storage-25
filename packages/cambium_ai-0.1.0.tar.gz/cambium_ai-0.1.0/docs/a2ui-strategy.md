# A2UI strategy

Cambium emits A2UI (Agent-to-UI) documents instead of strings plus
metadata. This document explains the strategy and the components.

## Why A2UI

Cambium outputs need to render across multiple surfaces:

- Sky (React web)
- Mobile app
- Email
- Push notification
- Voice assistant (Alexa, Siri)
- Browser extension
- Slack / Teams message

Hand-coding renderers per surface produces drift, brittle coupling,
and uneven feature parity. A2UI is a typed intermediate representation
that captures intent (this is a headline; these are dimensions; this
is a feedback affordance) without committing to surface specifics.

Each surface implements its own A2UI renderer; Cambium emits A2UI;
the surfaces stay independently evolvable.

## Block types

| Block type | Purpose | Example use |
|---|---|---|
| `text` (with role) | Headline / body / caption / meta | Insight headline + body |
| `dimension_badges` | Tagged dimension labels with weight | "future-orientation", "family-orientation" |
| `event_references` | List of referenced events with sign | Anchoring an insight in real transactions |
| `suggested_actions` | Reflect / act / ask prompts | "Notice the spike in escape spending" |
| `feedback` | Surface-native feedback affordance | Thumbs / "didn't land" buttons |
| `provenance` | Manifest hash + verify affordance | "This insight came from manifest <hash>" |

## Tone

The A2UI document carries a tone (`affirming`, `curious`, `neutral`)
that surface renderers honor. Sky may use different accent colors for
each tone; email may use different sign-off phrases; voice may use
different prosody.

The tone is not surface-visible chrome — it is a Cambium output that
the synthesizer chose deliberately. Honoring the tone is honoring the
synthesizer's judgment.

## Why this matters for the bounded-agent thesis

If outputs are strings, surfaces add their own framing, copy editing,
and visual emphasis — and the user is reading content that is no
longer fully traceable to Cambium. A2UI keeps the renderable artifact
inside Cambium's audit boundary. The provenance certificate references
the A2UI document, not a string.

When a user reports "this insight landed wrong", we know exactly what
they saw, because we can re-render the same A2UI document.

## Implementation

- `cambium/a2ui/components.py`: typed block models (Pydantic, frozen).
- `cambium/a2ui/renderers.py`: pure functions Cambium types → A2UI docs.
- Surface renderers live OUTSIDE Cambium, in Sky / mobile / email
  templates.

## What this is NOT

A2UI is not a full UI framework. It is a minimal IR optimized for
Cambium's output shape. Other parts of the OakQuant platform (e.g.,
Sky onboarding flows) use richer in-Sky abstractions.
