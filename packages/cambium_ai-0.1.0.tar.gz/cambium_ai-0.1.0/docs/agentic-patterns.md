# The 13 Agentic Patterns, Mapped to Cambium and Grove

This document maps the thirteen agentic-AI patterns I published in
*Thirteen Patterns for Building Agentic AI You Can Actually Trust* to
where they live in the OakQuant platform. Some are intrinsic to the
Cambium call-site layer. Some are intrinsic to the Grove workflow
layer. A few cross both via the service abstraction. One is a
meta-pattern both implement.

The split isn't arbitrary. **Cambium owns the patterns that govern
what happens inside a bounded call; Grove owns the patterns that
govern what happens between calls and across time.**

If you read the LinkedIn article and want to see the production form,
this document is the bridge.

## Quick reference

| # | Pattern | Owner | Notes |
|---|---|---|---|
| 1 | Prompt Chaining | **Cambium** | Classifier → reasoner → critique is the canonical chain. |
| 2 | Routing | **Grove** | Workflow-level domain dispatch. |
| 3 | RAG | Both | Grove owns retrieval infra; Cambium consumes via service. |
| 4 | Tool Use | Both | Grove owns tool execution; Cambium consumes via service. |
| 5 | Evaluator-Optimizer | **Cambium** | Constitutional critique + LLM judges. |
| 6 | Parallel Fan-Out | **Grove** | Concurrent classification fan-out. |
| 7 | Orchestrator-Workers | **Grove** | Cambium plugs in as a worker type. |
| 8 | HITL Gate | **Grove** | Pending state during active-learning review. |
| 9 | Delegation / Handoff | **Grove** | Cross-domain handoffs orchestrated by Grove. |
| 10 | Guardrail Wrap | **Cambium** | Cambium *is* the canonical implementation. |
| 11 | Design-time → Runtime | Both (meta) | Manifest + workflow registries, same shape. |
| 12 | Saga | **Grove** | Compensations exposed by Cambium; orchestration in Grove. |
| 13 | Creative Sandbox w/ Deterministic Exit | **Cambium** | Reasoner inside the spine. |

## Patterns Cambium owns

### Pattern 1 — Prompt Chaining

The three call sites are the canonical chain:

```
classifier(event) → ClassifiedEvent
   → reasoner(identity, event, classified, baseline) → CoherenceScore
       → (optional) critique(score, constitution) → CoherenceScore
synthesizer(identity, scores, events, window) → Insight
   → (optional) consensus_judge(insight) → JudgedInsight
```

Between each step, the spine runs deterministic logic (clipping,
validation, redaction). This is the pattern in its most disciplined
form: every step's output is structured, validated, and traced
before becoming the next step's input.

**Where to look.** `cambium/core/spine.py` — `Spine.process_event`
and `Spine.synthesize_window`.

### Pattern 5 — Evaluator-Optimizer

Two implementations in Cambium:

1. **Constitutional self-critique** on the reasoner. The critique
   pass reads the reasoner's output and the constitution; it can
   only weaken adjustments toward zero. Strengthening is forbidden by
   the prompt and enforced by the spine.

2. **Multi-judge consensus** on the synthesizer. Primary and
   secondary judges score the same output against the rubric.
   Disagreement beyond tolerance routes to active learning; the
   consensus score is the minimum of the two.

**Where to look.** `cambium/claude/critique.py`,
`cambium/claude/consensus.py`, `cambium/evals/judges/consensus_judge.py`.

### Pattern 10 — Guardrail Wrap

Cambium is the canonical implementation. The guardrail wrap is not
an add-on; it's the architecture. Every model output is wrapped by
deterministic checks before the spine accepts it:

- Reasoner adjustment magnitude clipped to ceiling (±0.3 default).
- Catastrophizing-token filter on justification text.
- Dimension citations filtered to the permitted set.
- Event references validated against the input window.
- JSON-shape validation with one repair retry.

The guardrails are declared as `timber-common` rules and listed in
`timber_configs/cambium_rules.yaml`. They are inspectable and
editable; they are *not* hand-rolled validation scattered through
the call site code.

**Where to look.** `cambium/timber/rules.py`, `cambium/core/spine.py`.

### Pattern 13 — Creative Sandbox with Deterministic Exit

The reasoner is the sandbox; the spine is the exit. The reasoner
prompt invites genuine reasoning about why a behavior aligns or
doesn't with the user's stated identity. Within the prompt, the
model has latitude — it can cite any dimensions, frame the
justification any way it likes, propose any adjustment magnitude.

What it cannot do:

- Adjust beyond the ceiling (spine clips).
- Cite dimensions outside the domain's set (spine filters).
- Use catastrophizing language (rule rejects).
- Skip the trace.
- Bypass the rubric (the synthesizer's output is judged before
  delivery).

The deterministic exit happens at multiple layers — clipping, rules,
judges, regression CI for the manifest itself. The sandbox is
genuine; the exit is non-negotiable.

**Where to look.** Every file in `cambium/call_sites/` exhibits this
pattern; the cleanest expression is in `cambium/call_sites/reasoner.py`.

## Patterns Grove owns

### Pattern 2 — Routing

Grove decides which Cambium domain to invoke per event type or event
source. A Plaid transaction routes to finance; a wearable data point
routes to health; a calendar event routes to career. Cambium domains
don't route — they receive.

Routing is workflow decision, not agent decision. Grove implements
it with Celery routing keys or a thin dispatcher.

### Pattern 6 — Parallel Fan-Out

Grove fans out classification across many events concurrently using
Celery `group`. Once fan-out completes, Grove gathers results and
invokes the reasoner sequentially (because the reasoner depends on
the classified event). For weekly synthesis, Grove fans out
per-user pipelines in parallel.

### Pattern 7 — Orchestrator-Workers

Grove is the orchestrator. Cambium plugs in as a worker type via
`cambium/grove/adapter.py::GroveAdapter`. The orchestrator handles
retries, dead-letter queues, scheduling, and observability. Cambium
focuses on the bounded reasoning task.

### Pattern 8 — HITL Gate

The active-learning queue is the HITL gate. When Cambium routes a
low-confidence output, judge disagreement, or user negative signal
to the active-learning queue (via Grove event), Grove pauses the
relevant workflow in a "pending review" state. A human labels the
example; Grove resumes the workflow once the label is recorded.

The same HITL pattern gates manifest promotion: the regression CI
emits `ManifestPromotionPending`; an authorized human approves
before Grove flips the active manifest.

### Pattern 9 — Delegation / Handoff

Cross-domain handoffs. A finance-domain pattern (e.g., escape
spending after long workdays) might trigger a career-domain
consideration. The finance spine emits a
`CrossDomainHandoffRequested` event with a `HandoffContext`. Grove
invokes the career-domain spine with the context; the response feeds
back into the user's combined view.

Same pattern at the agent-to-agent layer via the MCP server:
Cambium exposes its tools to other agents (Claude Code, third-party
Grove-orchestrated agents). See `cambium/core/mcp_server.py`.

### Pattern 12 — Saga

Workflow rollback for batch reprocessing. If a week's batch
reprocessing of a user's events fails partway, Grove executes
compensating inverse operations to return the system to a consistent
state. Cambium exposes the inverses:

- `reprocess_event_idempotent` — re-run an event without
  duplicating work.
- `redact_trace` — tombstone a trace record (write a redaction
  marker; the append-only trace doesn't allow actual deletion).
- `delete_mapping` — drop the redaction reverse-map for a user
  (GDPR right to erasure).
- `revoke_insight` — mark an insight as revoked.

Grove registers these as saga steps.

**Where to look.** `cambium/grove/compensations.py`.

## Patterns that cross both layers

### Pattern 3 — RAG

Grove owns the vector store (Timber's vector search backs it in
production). Cambium consumes retrieval via the service abstraction:
`CambiumService.retrieve_similar_examples()`. The reasoner pulls
3–5 nearest-neighbor golden examples for few-shot inclusion in the
prompt.

The retrieval is invisible to the call site. From the call site's
perspective, the prompt template includes a "similar examples"
section that the spine populates before the call. The model never
queries a vector store; the spine queries it and hands the result to
the model.

This is the right placement: tool use is workflow, not agent
freedom.

### Pattern 4 — Tool Use

Grove owns tool execution. Cambium calls tools via the service
abstraction. If a domain needs to look up a merchant's prior
categorization for a user, the spine asks the service before the
call; the service either reads from cache (Timber) or invokes a
Grove tool. The call site receives enriched context, not a tool
handle.

This is the most important architectural commitment: **the model
never decides to call a tool**. The spine decides what context the
model has. This eliminates an entire class of agentic failure modes
(runaway tool loops, security issues from model-initiated calls,
opaque cost growth).

## The meta-pattern

### Pattern 11 — Design-time → Runtime

Both layers implement it.

**Cambium.** The Manifest is the design-time artifact. The
regression CI runs every candidate manifest through the golden sets;
PROMOTE / HOLD / BLOCK is the design-time gate. Promoted manifests
become runtime artifacts. Active manifests are content-hashed and
signed; runtime certificates point back to design-time identity.

**Grove.** Workflow DAGs are the design-time artifact. The workflow
is composed in Blueprint (or in code), versioned, deployed as Celery
tasks. Runtime workflow instances are bound to the deployed DAG.

The shape is the same:

```
design-time artifact (manifest / DAG)
   → eval-time gate (regression CI / Blueprint review)
       → runtime artifact (active manifest / deployed workflow)
           → trace and verification (provenance cert / workflow run)
```

This pattern is my own framing — a thing I keep seeing in the field
that doesn't yet have a settled name. Cambium and Grove implement it
at two different altitudes; together they show the pattern operating
across the platform.

## What this means for code reviewers

When a PR proposes a change to Cambium, ask:

1. Is the change about what happens *inside* a call site? Cambium
   owns it.
2. Is the change about what happens *between* calls or *across*
   time? Grove owns it. Reject from Cambium.
3. Is the change adding a tool the model can invoke? Reject. Add
   the tool to Grove and the context to the spine.
4. Is the change adding a fourth call site? Use the
   `cambium-add-call-site` skill; do not skip the contract.

When a PR proposes a change to Grove, the inverse:

1. If the change is workflow logic, Grove owns it.
2. If the change is "the model should be allowed to do X," push back
   — the model only answers questions Cambium asks. New X belongs in
   the spine's context-enrichment logic, not in workflow.

## Further reading

- LinkedIn article: *Thirteen Patterns for Building Agentic AI You
  Can Actually Trust* — the long-form discussion of each pattern.
- Anthropic's *Building Effective Agents* (December 2024) — the
  foundational read for patterns 1–7.
- `cambium/skills/developer/cambium-add-call-site/SKILL.md` — the
  contract for adding a new bounded call site.
