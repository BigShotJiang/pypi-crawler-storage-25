# Skills extensibility

Cambium ships Claude skills that work two ways:

## 1. Developer skills (build-time)

Files in `cambium/skills/developer/` are SKILL.md documents Claude
Code reads when extending Cambium. They encode the architectural
contracts as procedural recipes:

- `cambium-add-call-site/`: how to add a fourth LLM call site without
  breaking the manifest / trace / eval contract.
- `cambium-add-domain/`: how to plug a new domain into the
  multi-domain framework.
- `cambium-author-golden-set/`: how to maintain golden-set quality.

Developer skills are the operational form of Cambium's architectural
documentation. They turn "read ARCHITECTURE.md and follow the rules"
into "Claude Code will follow the rules mechanically." This is
Pattern 11 (design-time → runtime) applied to development: the
architectural design is encoded as an artifact agents can execute.

## 2. Runtime skills (per-vertical)

Files in `cambium/skills/runtime/` are SKILL.md documents that
configure Cambium for a specific vertical use case within a domain.
The first runtime skill is:

- `cambium-credit-card-coherence/`: a per-vertical configuration for
  scoring credit-card spending coherence — a focused subset of the
  finance domain with vertical-specific category extensions, baseline
  tweaks, and tone hints.

Runtime skills are activated via `service.get_skills_config()`. When
active, they layer their YAML overrides onto the domain's base
config. Skills compose: multiple skills can be active simultaneously
as long as their overrides don't conflict.

## How to author a new skill

### Developer skill

```bash
mkdir cambium/skills/developer/<slug>
# Write SKILL.md with frontmatter:
#   name: <slug>
#   description: <when to use>
# Then the body: what to do, in what order, with which contracts.
```

A developer skill is correct if Claude Code can follow it mechanically
and produce code that passes the regression CI.

### Runtime skill

```bash
mkdir cambium/skills/runtime/<slug>
# Write SKILL.md describing what the skill does at runtime.
# Add config.yaml with the overrides this skill applies.
```

A runtime skill is correct if its overrides compose cleanly with the
base domain and the regression CI continues to pass with the skill
active.

## Why both kinds

Developer skills shape how Cambium grows: they prevent contributors
(human or AI) from violating architectural invariants. Runtime skills
shape what Cambium does for specific verticals without forking the
domain or the codebase.

Both are versioned content-hashed artifacts (Pattern 11). The active
set of skills is part of the manifest content hash — a change in
skills counts as a manifest change and runs through the same
regression CI.

## What skills do NOT do

Skills do not:

- Add new LLM call sites (use `cambium-add-call-site` skill to do
  that properly).
- Bypass guardrails.
- Read configuration outside the service abstraction.
- Mutate the spine's flow.

If a skill tries to do any of these things, it is wrong and the
review should reject it.
