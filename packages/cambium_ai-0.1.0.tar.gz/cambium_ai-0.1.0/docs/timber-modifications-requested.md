# Timber modifications requested by Cambium

Cambium's integration with `timber-common` assumes a specific API
surface. This document lists the surface, the rationale, and (where
applicable) the modifications to timber-common that Cambium's
adoption justifies.

## Required modules

| Module | Required surface | Rationale |
|---|---|---|
| `timber_common.factories.model_factory(yaml_path, **kwargs)` | Generates a SQLAlchemy class from a YAML config | Single source of truth for persistence |
| `timber_common.rules.Rule`, `RuleResult` | Declarative rules with check/repair | Guardrails as data |
| `timber_common.repositories.*` | Repository per persistence shape | Caching + transactional semantics |
| `timber_common.encryption` | Field-level Fernet encryption | Reversible redaction mapping |
| `timber_common.keystore.EncryptedKeystore` | Key management with rotation | Provenance signing keys |
| `timber_common.vectors.search` | Vector retrieval over indexed records | Few-shot golden example retrieval |
| `timber_common.events.subscribe` | Pub/sub for config change invalidation | Cache invalidation |

## YAML schema additions Cambium expects

Cambium's YAML configs in `timber_configs/` use these field-level
options. If they aren't supported in the installed timber-common, add
them or adapt:

| Option | Purpose |
|---|---|
| `encrypted: true` on a field | Apply Fernet encryption at the column |
| `retention.duration_months: N` on a table | Apply scheduled retention |
| `index_strategy: ...` on a field | Apply column index |
| `vector.dim: N` on a field | Store a vector embedding column |
| `audit: true` on a table | Add `created_by_manifest_hash` audit column |

## Repository methods Cambium expects

Each timber-common repository should provide:

- `get(id)` — single fetch.
- `list(**filters)` — filtered list.
- `put(obj)` — upsert.
- `delete(id)` — delete (or tombstone, where retention forbids hard delete).

The `ManifestRepository` additionally provides:

- `get_active(domain, user_id_hash=None)` — resolve the active
  manifest for a domain (and optionally a user, for A/B bucketing).
- `activate(manifest_id, domain)` — atomically promote a manifest.
- `assign_bucket(user_id_hash, domain)` — sticky A/B bucket assignment.
- `get_shadow_pair(domain)` — return the (active, shadow) manifest pair.

## Modifications worth contributing back to timber-common

The following additions are useful beyond Cambium and would be good
contributions to timber-common:

1. **Sticky bucket assignment** with deterministic hash-based
   assignment. Cambium needs it; Grove A/B-style workflows would
   benefit.

2. **Audit column convention** (`created_by_manifest_hash`) with
   automatic population from context. Generalizes beyond Cambium to
   any artifact whose provenance the platform tracks.

3. **Tombstone-on-delete** for retention-bound tables. The append-only
   model is broader than Cambium's trace.

4. **Rules engine version registry**. Cambium uses rule versions in
   manifest content hashes; other consumers would benefit from
   versioned rule discovery.

5. **`watch` semantics on repository changes** (currently `subscribe`
   to events; a higher-level `watch` API on the repository itself
   would simplify cache invalidation).

## What Cambium does NOT need from timber-common

- Workflow orchestration (Grove's job).
- API surface generation (Canopy's job).
- React component library (Sky's job).
- Identity-instrument runtime (Acorn's job).
- Authentication (the platform's edge proxy).

Keeping timber-common focused on persistence-and-friends keeps the
dependency graph clean.

## Graceful degradation

If timber-common is absent (e.g., development without the production
infra), Cambium falls back to `InMemoryCambiumService` or
`YamlCambiumService`. The Timber-integrated code paths import
`timber_common` lazily and emit clear errors only when invoked.

See `cambium/timber/factories.py`, `cambium/timber/rules.py`,
`cambium/timber/service_impl.py` for the fallback patterns.
