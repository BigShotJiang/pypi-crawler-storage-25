# Cutting-edge capabilities

This document inventories the techniques Cambium incorporates that go
beyond standard LLM application patterns. They are listed here so
reviewers, customers, and (eventually) academic readers can see the
breadth of the technique surface at a glance.

## 1. Bounded reasoner with constitutional self-critique

The reasoner is allowed at most a ±0.3 adjustment to the deterministic
baseline. After producing its adjustment, an optional second LLM pass
critiques the adjustment against the active constitution. The
critique can only weaken (truncate toward zero); it cannot strengthen
the original. This is Pattern 5 (Evaluator-Optimizer) wired for
conservatism.

Files: `cambium/call_sites/reasoner.py`, `cambium/claude/critique.py`.

## 2. Multi-judge consensus with disagreement routing

Synthesizer outputs are judged by two LLM judges (typically different
models). Disagreement beyond a tolerance routes the case to the
active-learning queue. The judging system surfaces uncertainty
rather than masking it with averaging.

Files: `cambium/claude/consensus.py`, `cambium/evals/judges/consensus_judge.py`.

## 3. Calibration tracking

Every Cambium output carries a confidence in [0, 1]. Calibration is
tracked via Brier score, expected calibration error (ECE), and
reliability bins. Calibration metrics are part of the manifest
promotion gate: a poorly-calibrated manifest cannot be promoted even
if its accuracy is high.

Files: `cambium/core/calibration.py`, `cambium/evals/runner.py`.

## 4. Active learning loop

Production uncertainty (low confidence, judge disagreement, direction
flip, novel pattern, user negative signal) routes candidates to a
labeling queue. Labeled candidates grow the golden set; the next
manifest evaluates against the larger set.

Files: `cambium/evals/active_learning.py`.

## 5. Signed provenance certificates

Every insight is accompanied by a signed certificate that allows
offline verification: a verifier with the public key can confirm the
insight came from a specific manifest. Useful for regulatory audit
and for situations where the insight is forwarded outside Cambium
(e.g., a user sharing an insight with an advisor).

Files: `cambium/core/provenance.py`.

## 6. Drift detection (PSI, KL divergence)

Provider-side model updates can change behavior even with identical
prompts. Cambium runs a fixed canary set and monitors PSI on score
distributions and KL divergence on category distributions; drift
emits a Grove `ManifestDriftAlert` event.

Files: `cambium/evals/drift.py`.

## 7. Shadow A/B with paired statistics

Two manifests run on identical production inputs; only A's output is
shown; B's is recorded for paired analysis. Paired t-test, Wilcoxon
signed-rank, McNemar's test are implemented in pure Python (no scipy
dependency).

Files: `cambium/ab/shadow.py`, `cambium/ab/stats.py`.

## 8. Content-hashed manifests with regression-gated promotion

Every artifact that affects an LLM output (prompts, constitution,
judge rubric, thresholds, golden set) is content-hashed into a
manifest. New manifests pass through the regression CI; the regression
CI applies absolute floors and regression tolerances against the
baseline and emits PROMOTE / HOLD / BLOCK.

Files: `cambium/core/types.py::Manifest`, `cambium/regression/runner.py`.

## 9. Reversible field-level redaction

Inputs are pseudonymized before being shown to the model; the
reverse-map is held encrypted in Timber's keystore. Outputs are
rehydrated for the user; the model never sees raw PII; the trace
keeps the redacted form. GDPR right-to-erasure drops the user's
reverse-map row, making historical traces unrecoverable as
identification but preserved as aggregate signal.

Files: `cambium/core/redaction.py`.

## 10. Surface-independent rendering (A2UI)

Cambium outputs A2UI documents instead of strings. Each surface
implements its own renderer; the audit boundary stays at the A2UI
document, not at the rendered string. Provenance certificates
reference A2UI documents.

Files: `cambium/a2ui/components.py`, `cambium/a2ui/renderers.py`.

## 11. MCP server interface

Cambium exposes itself as an MCP server for cross-system access. Tools
include `process_event`, `synthesize_window`, `verify_certificate`,
and inspection tools. Read-mostly; governance actions stay in Ranger.

Files: `cambium/core/mcp_server.py`.

## 12. OpenTelemetry instrumentation

Every Claude call site emits OTel spans with structured attributes:
manifest hash, call site name, model id, latency, token counts,
confidence, structural validity. No-op when OTel is absent.

Files: `cambium/core/otel.py`.

## 13. Cross-domain handoffs

Domain pipelines emit cross-domain handoff events when their signals
implicate another domain. Grove orchestrates the delegated work.
Domain code stays isolated; cross-domain reasoning is workflow-level.

Files: `cambium/grove/handoffs.py`, `cambium/grove/events.py`.

## 14. Saga-compatible compensations

Cambium provides idempotent compensations Grove can register for
multi-step workflows: reprocess intent, trace redaction, mapping
deletion, insight revocation. Each writes a trace; each is local;
each tolerates re-execution.

Files: `cambium/grove/compensations.py`.

## 15. Composable runtime skills

Per-vertical skills layer YAML overrides onto a domain's base config
without forking. The active skill set is part of the manifest hash;
skill changes flow through regression CI.

Files: `cambium/skills/runtime/`.

## What is intentionally NOT cutting-edge

- **No fine-tuning.** Cambium uses base models; the IP is in golden
  sets, judge rubrics, and the bounded-agent architecture, not in
  model weights.
- **No agentic tool-using LLMs at the call site.** Tool use is
  workflow.
- **No long-context loops.** Three bounded call sites.
- **No "explanation generation" via additional LLM passes.**
  Explanations are deterministic, built from scoring traces and
  reasoner citations.

These choices are deliberate. They keep Cambium auditable and
reproducible.
