# Cambium in the OakQuant platform

Cambium is a microservice-library in the OakQuant constellation
(Sky, Canopy, Grove, Acorn, Timber, Ranger, Cambium). It is the
behavioral coherence engine that sits between identity capture
(Acorn → Timber) and user-facing delivery (Sky via Canopy).

## Constellation diagram

```
                       ┌────────────┐
                       │   Sky      │  React frontend
                       │ (glass UI) │  Renders A2UI documents
                       └─────┬──────┘
                             │
                       ┌─────┴──────┐
                       │  Canopy    │  Flask orchestrator
                       │            │  Owns user-facing flows
                       └─────┬──────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
       ┌──────┴──────┐               ┌──────┴──────┐
       │   Grove     │◄─────events───┤  Cambium    │  Bounded-agent
       │ (Celery)    │               │  (this lib) │  coherence engine
       │             │───workers────►│             │
       └──────┬──────┘               └──────┬──────┘
              │                             │
              │                             │
       ┌──────┴──────┐               ┌──────┴──────┐
       │   Acorn     │               │   Ranger    │  Admin/HITL surface
       │  (capture)  │               │  (admin)    │  Reads manifests, trace,
       └──────┬──────┘               └─────────────┘  active-learning queue
              │
              │
       ┌──────┴──────────────────────────────────┐
       │              Timber                     │  Shared persistence library
       │  models · rules · encryption · vectors  │  Published on PyPI
       │  GDPR retention · keystore              │
       └─────────────────────────────────────────┘
```

## How Cambium connects to each peer

### Sky

Sky consumes `A2UIDocument` instances emitted by
`cambium.a2ui.renderers`. Sky's renderer maps A2UI block types to
React components: TextBlock → typography component;
DimensionBadgesBlock → badge row; EventReferencesBlock → event list;
FeedbackBlock → thumbs/comments; ProvenanceBlock → "verify" affordance.

Sky never sees raw `Insight` or `CoherenceScore` objects. The A2UI
abstraction protects Sky from Cambium internal schema changes and
lets non-Sky surfaces (email, mobile, voice) render the same outputs.

### Canopy

Canopy is the user-facing **FastAPI** orchestrator (not Flask — early
drafts of this doc said Flask; correct shape is FastAPI on Port 5010).
Canopy talks to Cambium through `clients/cambium_client.py` over
httpx with the `X-Cambium-API-Key` service-API-key + user-context
headers (`X-User-Id`, `X-User-Email`, `X-User-Name`). For agent-driven
interactive use cases — where a model decides to call Cambium as a
tool — the call routes Sky → Canopy → Acorn (which runs `FastMCP`) →
Cambium's MCP tools. Canopy itself does NOT speak MCP. For batch use
cases (weekly insight generation), Canopy schedules work in Grove.

### Grove

Grove is the Celery-based workflow engine. Cambium plugs into Grove
via `cambium.grove.adapter.GroveAdapter`, which exposes
`process_event` and `synthesize_window` as Celery-compatible task
methods. Grove also subscribes to Cambium's typed events
(`cambium.grove.events`):

- `LowConfidenceClassification` and `ActiveLearningCandidate` →
  Grove routes to the labeling queue.
- `HighCoherenceDrift` → Grove may invoke a deeper analysis worker.
- `WeeklyInsightReady` → Grove queues delivery via Sky/email.
- `ManifestPromotionPending` → Grove holds promotion until Ranger
  releases the HITL gate.
- `ManifestDriftAlert` → Grove may pause deployment of the affected
  manifest.
- `UserFeedbackReceived` → Grove routes to active learning.
- `CrossDomainHandoffRequested` → Grove invokes the target domain.

### Acorn

Acorn is the **multi-agent reasoning service** (Vanguard / Oracle /
Catalyst, LangChain/LangGraph + FastMCP). Acorn does NOT itself run
the Financial DNA Protocol capture — that lives in **Grove** as the
`financial_dna_evaluation` workflow (16 screens, `fdna_s1` → `fdna_s16`),
and the captured `FinancialDNASession` is reduced into a Cambium
`IdentityProfile` via `cambium.domains.finance.identity.from_grove_session`.

What Acorn *does* with Cambium:
- Hosts MCP tools (`acorn/tools/cambium_tools.py`) that other agents
  invoke via FastMCP: `cambium_get_coherence`,
  `cambium_get_weekly_insight`, `cambium_verify_certificate`,
  `cambium_list_domains`.
- Pseudonymizes user identifiers via Acorn's
  `services/signal_collector/pii_filter.py::hash_user_id` before
  forwarding to Cambium.
- Mirrors Cambium's A2UI block types in `acorn/models/a2ui.py`
  (lockstep with `cambium/a2ui/components.py` and
  `sky/src/components/a2ui/types.ts`).

### Ranger

Ranger is the admin/governance surface. It reads:

- Active manifest per domain.
- Manifest history with content hashes and eval reports.
- Trace records (decrypted on demand with proper authorization).
- The active-learning queue.
- Drift reports.
- Shadow A/B summaries.

Ranger surfaces the HITL gates: manifest promotion, active-learning
labeling, drift alerts. Each gate corresponds to a Grove pending state
and a Cambium event type.

### Timber

Timber is the shared library and PyPI package. Cambium uses Timber
for:

- Model-factory generation of SQLAlchemy persistence classes from
  YAML configs (`timber_configs/*.yaml`).
- Field-level Fernet encryption for the redaction reverse-map and
  for DNA captures.
- Rules-engine declarations for Cambium's guardrails
  (`cambium/timber/rules.py`).
- Vector search backing the few-shot retrieval of golden examples.
- GDPR retention policy attached to the trace table.
- Encrypted keystore for the provenance signing keys.

## Deployment topology

Cambium runs as:

- A library inside Canopy (for interactive synchronous calls).
- A worker class inside Grove (for batch / event-driven work).
- A standalone MCP server (for cross-system access; e.g., Claude Code
  development, third-party agents).

The same Cambium code runs in all three modes. Only the wrapping
differs.

## Operational responsibilities by service

| Service | Owns | Reads from Cambium | Writes to Cambium |
|---|---|---|---|
| Sky | UI rendering | A2UI documents | User feedback signals |
| Canopy | User flows | MCP server | – |
| Grove | Orchestration | events, adapter | – |
| Acorn | Identity capture | – | IdentityProfile via service |
| Ranger | Admin / HITL | manifests, traces, queues | manifest activations, label decisions |
| Timber | Shared persistence | – | – (Cambium reads Timber, not vice versa) |
