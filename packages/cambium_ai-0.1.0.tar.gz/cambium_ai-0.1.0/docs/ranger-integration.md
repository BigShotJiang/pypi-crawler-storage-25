# Ranger integration

Ranger is OakQuant's master admin/governance surface. Cambium's
HITL gates, audit trails, and override capabilities surface through
Ranger.

## What Ranger reads from Cambium

| Surface | Cambium data |
|---|---|
| Manifest registry | Active manifest per domain, history, content hashes |
| Manifest detail | Prompt versions, constitution, judge rubric, eval thresholds, golden set version |
| Eval reports | Per-call-site metrics, calibration, per-example results |
| Trace records | Per-call-site request/response, latency, manifest hash |
| Active-learning queue | Candidates by strategy, by priority, with model output |
| Drift dashboard | PSI and KL divergence over rolling windows |
| Shadow A/B | Side-by-side comparison of two manifests on production traffic |
| Provenance verifier | Verify a certificate against a known manifest |

## What Ranger writes to Cambium

| Action | Effect |
|---|---|
| Promote manifest | Calls `service.activate_manifest()` |
| Hold manifest | Records HOLD decision; manifest stays in candidate pool |
| Block manifest | Records BLOCK decision; manifest cannot be promoted |
| Label active-learning candidate | Adds to golden set; bumps golden-set version |
| Disable feature flag | Updates `FeatureFlags` for a domain |
| Override model selection | Updates `ModelOverrides` for a call site |
| Pause domain | Sets feature flag to deterministic-only mode |

## HITL gates

Cambium emits Grove events for HITL gates. Ranger renders the
corresponding queue:

- `ManifestPromotionPending` → "Manifests awaiting promotion"
- `ActiveLearningCandidate` → "Examples awaiting labeling"
- `ManifestDriftAlert` → "Drift alerts awaiting investigation"
- `UserFeedbackReceived` (negative signal) → "User feedback to review"

Each gate has SLA: Promotion gates resolve within one business day;
active-learning candidates within five business days; drift alerts
within four hours of severity=alert.

## Why Ranger exists separately from Cambium

Two reasons:

1. **Separation of authority.** Cambium produces outputs; Ranger
   governs them. The same person should not write a prompt and
   approve its production deployment without an explicit gate. Ranger
   makes the gate ceremonial enough to be auditable.

2. **Cross-microservice scope.** Ranger surfaces are not Cambium-only.
   They cover Grove workflows, Acorn assessments, Sky deployments,
   and Timber retention policy. Ranger is the platform's governance
   layer; Cambium is a customer.

## Concrete Ranger views for Cambium

These views should exist in Ranger v1:

1. **Manifest history** for each domain. Diff between active and
   candidate.
2. **Eval report viewer** with per-example drill-in and rationale.
3. **Active-learning labeling UI** with rubric reminders and
   keyboard shortcuts.
4. **Trace search** by user_id_hash, time range, call site,
   confidence bin.
5. **Drift dashboard** with PSI/KL plots and severity history.
6. **Shadow A/B summary** with paired-statistics readouts.
7. **Provenance verifier** for arbitrary certificates.
8. **Constitution editor** with version history.
9. **Threshold editor** with regression-CI preview.
