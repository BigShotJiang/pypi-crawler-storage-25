# Cambium golden seeds

This directory holds the labeled golden datasets that drive Cambium's
eval framework, regression CI, and active-learning loop.

## Files

- `finance_v1.jsonl` — 20 hand-labeled examples for the finance
  domain (10 classifier, 7 reasoner, 3 synthesizer). Mix of standard
  and adversarial cases.

## Authoring

See the developer skill `cambium-author-golden-set` at
`cambium/skills/developer/cambium-author-golden-set/SKILL.md` for
the authoring rubric, coverage targets, and labeling discipline.

## Loading

```python
from pathlib import Path
from cambium.evals.golden import GoldenSet

golden = GoldenSet.load_jsonl(
    Path("golden_seeds/finance_v1.jsonl"),
    call_site="classifier",
)
print(f"Loaded {len(golden.examples)} examples")
```

## Versioning

Golden sets are content-hashed and versioned. A change to any example
bumps the set version; the new set version flows into the manifest
content hash; the regression CI runs on the new manifest before
promotion.

Never edit examples in place. Add new examples (incrementing version);
deprecate stale examples with a tag (`tags: ["deprecated"]`).

## License

The Cambium framework code is Apache 2.0. The golden seed datasets
are CC-BY 4.0 — usable for research and reference, attribution
required.

Production-quality golden sets (1000+ examples per call site, per
domain) are platform IP and not distributed with the open-source
release.
