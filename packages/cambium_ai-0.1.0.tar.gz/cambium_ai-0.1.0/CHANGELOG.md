# Changelog

All notable changes to Cambium will be recorded here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions
follow [SemVer](https://semver.org/).

## [0.1.0] — 2026-05-16

### Reality-check corrections vs. original spec

- Import path is `from cambium.*`; integration with timber-common uses
  `from common.*` (not `from timber_common.*`). This was the original
  spec's error; corrected throughout the code, README, and docs.
- `timber_configs/*.yaml` rewritten to match `timber-common`'s actual
  model-factory format (`models:` list with `mixins:`, `columns:`,
  `relationships:`). The original flat `fields:` shape would not have
  loaded.
- IdentityProfile authorship moved from Acorn to Grove: the
  Financial DNA Protocol's 16 screens live in Grove as
  `financial_dna_evaluation_workflow.yaml`; cambium provides the
  reducer `cambium.domains.finance.identity.from_grove_session`
  that turns the captured session into an `IdentityProfile`.
- Canopy integration corrected: Canopy is FastAPI (not Flask) and
  it consumes Cambium via httpx (not MCP). Agent-driven interactive
  use cases route Sky → Canopy → Acorn (FastMCP) → Cambium MCP
  tools.
- Build/dependency management uses **Poetry**, matching timber's
  publishing pattern. The hatchling `pyproject.toml` was replaced.

### Added — initial public release

#### Core architecture
- Three bounded Claude call sites: classifier, reasoner, synthesizer.
- Deterministic spine orchestrating call sites with strict guardrails.
- Reasoner adjustment bounded to ±0.3 from the deterministic baseline.
- Constitutional self-critique pass on the reasoner (weaken-only).
- Multi-judge consensus on synthesizer with disagreement routing.
- PII redaction layer with reversible mapping (per-user salt rotation).
- Append-only trace recorder with structured JSONL output.
- Content-hashed Manifest binding all prompt versions, model selections,
  rule versions, and constitution version.
- Signed provenance certificates with offline verification.

#### Multi-domain plug-in architecture
- Domain-agnostic core (`cambium.core`) with `DomainConfig`, `DomainRegistry`,
  `BaselineScorer` Protocol.
- Finance domain plugin (10 dimensions, 13 categories, 4 Klontz narrative tags).
- Template domain (`domains/_template/`) for copy-and-edit new domains.

#### Service abstraction
- `CambiumService` Protocol with four implementations:
  - `InMemoryCambiumService` (tests, demos)
  - `YamlCambiumService` (development)
  - `TimberCambiumService` (production, via timber-common)
  - Ranger admin tool integration via service interface
- Environment-driven implementation selection (`CAMBIUM_SERVICE_IMPL`).

#### Eval framework
- Golden-set loader and runner (`cambium.evals.golden`,
  `cambium.evals.runner`).
- Deterministic judges for classifier and reasoner.
- LLM judge for synthesizer with structured rubric.
- Multi-judge consensus with active-learning routing on disagreement.
- Active-learning queue with five selection strategies.
- Calibration tracking (Brier score, ECE, reliability bins).
- Drift detection (PSI, KL divergence).
- 60 hand-labeled golden examples for the finance domain (20 per call site).

#### Regression CI and rollout
- `evaluate_gates` regression CI with PROMOTE / HOLD / BLOCK decision.
- Shadow A/B harness for paired manifest comparison.
- Paired statistics (paired t-test, Wilcoxon signed-rank, McNemar).

#### Timber integration
- Declarative rules engine integration with three rule families:
  numeric bounds, content policy, referential integrity.
- Model factory bridge for SQLAlchemy persistence generation.
- 10 YAML config files for all persistent types.
- `TimberCambiumService` for production deployment.

#### Grove integration
- `GroveAdapter` exposing Cambium as a Celery worker class.
- Typed event system with 8 events Grove subscribes to.
- `EventBus` Protocol with `InMemoryEventBus` for tests.
- `HandoffContext` and `build_handoff_context` for cross-domain delegation.
- Saga compensations (idempotent reprocess, mapping deletion, trace
  redaction, insight revocation).

#### Output layer
- A2UI component schema for surface-independent insight output.
- Renderers for Insight, CoherenceScore, IdentityProfile.

#### MCP server
- Cambium exposed as an MCP server with six tools: process_event,
  synthesize_window, list_manifests, get_manifest, verify_certificate,
  list_domains.

#### Observability
- OpenTelemetry span hooks with no-op fallback when OTel not installed.

#### Skills
- Three developer skills: `cambium-add-call-site`, `cambium-add-domain`,
  `cambium-author-golden-set`.
- One runtime skill: `cambium-credit-card-coherence` (vertical example).

#### Tests
- Smoke tests covering types, service, baseline scoring, redaction,
  rules, provenance.
- Spine tests with stubbed Claude client.
- Manifest, redaction, service tests.

#### Examples
- `basic_pipeline.py` — single-event end-to-end run.
- `multi_domain_pipeline.py` — domain plug-in demonstration.
- `eval_run.py` — regression gate run.
- `shadow_ab.py` — shadow A/B with paired statistics.

#### Documentation
- `README.md` — quickstart, architecture summary, mental model.
- `docs/ARCHITECTURE.md` — full architectural reference.
- `docs/agentic-patterns.md` — mapping of the 13 patterns to Cambium and Grove.
- `docs/multi-domain-architecture.md` — domain plug-in design.
- `docs/timber-integration.md` — Timber integration details.
- `docs/oakquant-integration.md` — positioning in the OakQuant platform.
- Apache 2.0 license; golden sets under CC-BY 4.0.
