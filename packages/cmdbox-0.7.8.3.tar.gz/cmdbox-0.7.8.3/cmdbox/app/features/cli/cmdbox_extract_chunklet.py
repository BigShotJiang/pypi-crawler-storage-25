from cmdbox.app import common, client, feature, filer
from cmdbox.app.commons import convert, redis_client
from cmdbox.app.options import Options
from pathlib import Path
from typing import Dict, Any, Tuple, List, Union
import argparse
import logging
import json
import platform


class ExtractChunklet(feature.OneshotResultEdgeFeature):
    def get_mode(self) -> Union[str, List[str]]:
        """
        この機能のモードを返します

        Returns:
            Union[str, List[str]]: モード
        """
        return "extract"

    def get_cmd(self):
        """
        この機能のコマンドを返します

        Returns:
            str: コマンド
        """
        return 'chunklet'

    def get_option(self):
        """
        この機能のオプションを返します

        Returns:
            Dict[str, Any]: オプション
        """
        return dict(
            use_redis=self.USE_REDIS_TRUE, nouse_webmode=False, use_agent=True,
            description_ja="指定されたドキュメントファイルからテキストを抽出します。",
            description_en="Extracts text from the specified document file.",
            choice=[
                dict(opt="host", type=Options.T_STR, default=self.default_host, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスホストを指定します。",
                     description_en="Specify the service host of the Redis server."),
                dict(opt="port", type=Options.T_INT, default=self.default_port, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja="Redisサーバーのサービスポートを指定します。",
                     description_en="Specify the service port of the Redis server."),
                dict(opt="password", type=Options.T_PASSWD, default=self.default_pass, required=True, multi=False, hide=True, choice=None, web="mask",
                     description_ja=f"Redisサーバーのアクセスパスワード(任意)を指定します。省略時は `{self.default_pass}` を使用します。",
                     description_en=f"Specify the access password of the Redis server (optional). If omitted, `{self.default_pass}` is used."),
                dict(opt="svname", type=Options.T_STR, default=self.default_svname, required=True, multi=False, hide=True, choice=None, web="readonly",
                     description_ja="サーバーのサービス名を指定します。",
                     description_en="Specify the service name of the inference server."),
                dict(opt="scope", type=Options.T_STR, default="current", required=True, multi=False, hide=False, choice=["", "client", "current", "server"],
                     description_ja="参照先スコープを指定します。指定可能な画像タイプは `client` , `current` , `server` です。",
                     description_en="Specifies the scope to be referenced. When omitted, 'client' is used.",
                     choice_show=dict(client=["client_data"]),),
                dict(opt="fwpath", type=Options.T_FILE, default=None, required=True, multi=True, hide=False, choice=None,
                     description_ja="指定したパスが範囲外であるかどうかを判定するパスを指定します。このパスの配下でない場合エラーにします。",
                     description_en="Specify the path to determine whether the specified path is out of bounds. If it is not under this path, it will result in an error.",),
                dict(opt="loadpath", type=Options.T_FILE, default=None, required=True, multi=False, hide=False, choice=None,
                     description_ja="読み込みファイルパスを指定します。",
                     description_en="Specify the source file path."),
                dict(opt="client_data", type=Options.T_STR, default=None, required=False, multi=False, hide=False, choice=None, web="mask",
                     description_ja="ローカルを参照させる場合のデータフォルダのパスを指定します。",
                     description_en="Specify the path of the data folder when local is referenced."),
                dict(opt="chunk_lang", type=Options.T_STR, default='auto', required=False, multi=False, hide=False,
                     choice=['auto', 'ja', 'en'],
                     choice_edit=True,
                     description_ja="チャンキングするテキストの言語を指定します。`auto` を指定した場合は自動で言語を判定します。",
                     description_en="Specify the language of the text to be chunked. If `auto` is specified, the language will be automatically detected."),
                dict(opt="chunk_max_token_counter", type=Options.T_STR, default="gpt-4o", required=False, multi=False, hide=False, choice=None,
                     choice_fn=self.choice_chunk_max_token_counter, choice_edit=True,
                     description_ja="チャンキングするテキストの最大トークン数を指定します。",
                     description_en="Specify the maximum number of tokens for chunking text."),
                dict(opt="chunk_max_tokens", type=Options.T_INT, default=1024, required=False, multi=False, hide=False, choice=None,
                     description_ja="チャンキングするテキストの最大トークン数を指定します。",
                     description_en="Specify the maximum number of tokens for chunking text."),
                dict(opt="chunk_max_sentences", type=Options.T_INT, default=4, required=False, multi=False, hide=False, choice=None,
                     description_ja="チャンキングするテキストの最大文数(文字数ではない)を指定します。",
                     description_en="Specify the maximum number of sentences (not characters) for chunking text."),
                dict(opt="chunk_overlap_percent", type=Options.T_INT, default=20, required=False, multi=False, hide=False, choice=None,
                     description_ja="チャンクのオーバーラップ割合を指定します。",
                     description_en="Specifies the overlap percentage of the chunk."),
                dict(opt="retry_count", type=Options.T_INT, default=3, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーへの再接続回数を指定します。",
                     description_en="Specifies the number of reconnections to the Redis server."),
                dict(opt="retry_interval", type=Options.T_INT, default=5, required=False, multi=False, hide=True, choice=None,
                     description_ja="Redisサーバーに再接続までの秒数を指定します。",
                     description_en="Specifies the number of seconds before reconnecting to the Redis server."),
                dict(opt="timeout", type=Options.T_INT, default=120, required=False, multi=False, hide=True, choice=None,
                     description_ja="サーバーの応答が返ってくるまでの最大待ち時間を指定。",
                     description_en="Specify the maximum waiting time until the server responds."),
                dict(opt="output_json", short="o", type=Options.T_FILE, default=None, required=False, multi=False, hide=True, choice=None, fileio="out",
                     description_ja="処理結果jsonの保存先ファイルを指定。",
                     description_en="Specify the destination file for saving the processing result json."),
                dict(opt="output_json_append", short="a", type=Options.T_BOOL, default=False, required=False, multi=False, hide=True, choice=[True, False],
                     description_ja="処理結果jsonファイルを追記保存します。",
                     description_en="Save the processing result json file by appending."),
                dict(opt="stdout_log", type=Options.T_BOOL, default=True, required=False, multi=False, hide=True, choice=[True, False],
                     description_ja="GUIモードでのみ使用可能です。コマンド実行時の標準出力をConsole logに出力します。",
                     description_en="Available only in GUI mode. Outputs standard output during command execution to Console log."),
            ])

    def choice_chunk_max_token_counter(self, o:Dict[str, Any], webmode:bool, opt:Dict[str, Any]) -> Any:
        """
        オプションのchoiceを動的に生成する関数

        Args:
            o (Dict[str, Any]): choice_fn関数が呼ばれたコマンドオプションのchoice定義
            webmode (bool): Webモードかどうか
            opt (Dict[str, Any]): このコマンドのすべてのコマンドオプションのchoice定義

        Returns:
            Any: choice情報
        """
        from tiktoken import model
        return [""] + sorted([k for k in model.MODEL_TO_ENCODING.keys()])

    def apprun(self, logger:logging.Logger, args:argparse.Namespace, tm:float, pf:List[Dict[str, float]]=[]) -> Tuple[int, Dict[str, Any], Any]:
        """
        この機能の実行を行います

        Args:
            logger (logging.Logger): ロガー
            args (argparse.Namespace): 引数
            tm (float): 実行開始時間
            pf (List[Dict[str, float]]): 呼出元のパフォーマンス情報

        Returns:
            Tuple[int, Dict[str, Any], Any]: 終了コード, 結果, オブジェクト
        """
        if args.svname is None:
            msg = dict(warn=f"Please specify the --svname option.")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_WARN, msg, None
        if args.scope is None:
            msg = dict(warn=f"Please specify the --scope option.")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_WARN, msg, None
        if args.loadpath is None:
            msg = dict(warn=f"Please specify the --loadpath option.")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_WARN, msg, None
        if args.fwpath is None:
            msg = dict(warn=f"Please specify the --fwpath option.")
            common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
            return self.RESP_WARN, msg, None

        try:
            client_data = Path(args.client_data.replace('"','')) if args.client_data is not None else None
            if args.scope == "client":
                if client_data is not None:
                    f = filer.Filer(client_data, logger)
                    chk, abspath, msg = f._file_exists(args.loadpath)
                    if not chk:
                        common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                        return self.RESP_WARN, msg, None
                    chk, msg = f.check_fwpath(args.loadpath, args.fwpath)
                    if not chk:
                        common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                        return self.RESP_WARN, msg, None
                    res = self.extract(abspath, args, logger, tm, pf)
                    common.print_format(res, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                    if 'success' not in res:
                        return self.RESP_WARN, res, None
                    return self.RESP_SUCCESS, res, None
                else:
                    msg = dict(warn=f"client_data is empty.")
                    common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                    return self.RESP_WARN, msg, None
            elif args.scope == "current":
                f = filer.Filer(Path.cwd(), logger)
                chk, abspath, msg = f._file_exists(args.loadpath)
                if not chk:
                    common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                    return self.RESP_WARN, msg, None
                chk, msg = f.check_fwpath(args.loadpath, args.fwpath)
                if not chk:
                    common.print_format(msg, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                    return self.RESP_WARN, msg, None
                res = self.extract(abspath, args, logger, tm, pf)
                common.print_format(res, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                if 'success' not in res:
                    return self.RESP_WARN, res, None
                return self.RESP_SUCCESS, res, None
            elif args.scope == "server":
                cl = client.Client(logger, redis_host=args.host, redis_port=args.port, redis_password=args.password, svname=args.svname)
                payload = dict(
                    loadpath=args.loadpath,
                    fwpath=args.fwpath,
                    client_data=args.client_data,
                    chunk_lang=args.chunk_lang,
                    chunk_max_tokens=args.chunk_max_tokens,
                    chunk_max_sentences=args.chunk_max_sentences,
                    chunk_overlap_percent=args.chunk_overlap_percent,
                )
                payload_b64 = convert.str2b64str(common.to_str(payload))
                res = cl.redis_cli.send_cmd(self.get_svcmd(), [payload_b64],
                                            retry_count=args.retry_count, retry_interval=args.retry_interval, timeout=args.timeout)
                common.print_format(res, args.format, tm, args.output_json, args.output_json_append, pf=pf)
                if 'success' not in res:
                    return self.RESP_WARN, res, None
                return self.RESP_SUCCESS, res, None
            else:
                logger.warning(f"scope is invalid. {args.scope}")
                return dict(warn=f"scope is invalid. {args.scope}")
        except Exception as e:
            logger.warning(f"Exception occurred. {e}", exc_info=True)
            return self.RESP_WARN, dict(warn=f"Exception occurred. {e}"), None

    def is_cluster_redirect(self):
        return False

    def svrun(self, data_dir:Path, logger:logging.Logger, redis_cli:redis_client.RedisClient, msg:List[str],
              sessions:Dict[str, Dict[str, Any]]) -> int:
        """
        この機能のサーバー側の実行を行います

        Args:
            data_dir (Path): データディレクトリ
            logger (logging.Logger): ロガー
            redis_cli (redis_client.RedisClient): Redisクライアント
            msg (List[str]): 受信メッセージ
            sessions (Dict[str, Dict[str, Any]]): セッション情報
        
        Returns:
            int: 終了コード
        """
        reskey = msg[1]
        try:
            payload = json.loads(convert.b64str2str(msg[2]))
            f = filer.Filer(data_dir, logger)
            chk, abspath, res = f._file_exists(payload.get('loadpath'))
            if not chk:
                logger.warning(f"File not found. {payload.get('loadpath')}")
                redis_cli.rpush(reskey, res)
                return self.RESP_WARN
            chk, msg = f.check_fwpath(payload.get('loadpath'), payload.get('fwpath'))
            if not chk:
                logger.warning(f"F{msg}. {payload.get('loadpath')}")
                redis_cli.rpush(reskey, res)
                return self.RESP_WARN
            args = argparse.Namespace(**payload)
            res = self.extract(abspath, args, logger, 0, [])
            redis_cli.rpush(reskey, res)
        except Exception as e:
            logger.warning(f"Failed to {self.get_svcmd()}: {e}", exc_info=True)
            redis_cli.rpush(reskey, dict(warn=f"Failed to {self.get_svcmd()}: {e}", end=True))
            return self.RESP_WARN
        return self.RESP_SUCCESS

    def extract(self, abspath:Path, args:argparse.Namespace, logger:logging.Logger, tm:float, pf:List[Dict[str, float]]=[]) -> Dict[str, Any]:
        """
        指定されたファイルからテキストを抽出します

        Args:
            abspath (Path): 抽出対象ファイルの絶対パス
            args (argparse.Namespace): 引数
            logger (logging.Logger): ロガー
            tm (float): 実行開始時間
            pf (List[Dict[str, float]]): 呼出元のパフォーマンス情報
        Returns:
            Dict[str, Any]: 抽出結果
        """
        try:
            if abspath is not None and not abspath.is_file():
                raise IOError(f"File not found. {abspath}")
            import tiktoken
            from chunklet.document_chunker import DocumentChunker
            counter = None
            if args.chunk_max_token_counter:
                model = tiktoken.encoding_for_model(args.chunk_max_token_counter)
                counter = lambda text: len(model.encode(text))
            elif args.chunk_max_tokens:
                raise ValueError("chunk_max_token_counter is required when chunk_max_tokens is specified.")
            chunker = DocumentChunker()
            if platform.system() == "Windows":
                logger.warning(f"In a Windows environment, only text file formats are supported.", exc_info=True)
                chunks = chunker.chunk_file(
                    path=abspath,
                    lang=args.chunk_lang,
                    token_counter=counter,
                    max_tokens=args.chunk_max_tokens,
                    max_sentences=args.chunk_max_sentences,
                    overlap_percent=args.chunk_overlap_percent,
                    offset=0
                )
            else:
                chunks = chunker.chunk_files(
                    paths=[abspath],
                    lang=args.chunk_lang,
                    token_counter=counter,
                    max_tokens=args.chunk_max_tokens,
                    max_sentences=args.chunk_max_sentences,
                    overlap_percent=args.chunk_overlap_percent,
                    offset=0
                )
            res_data = []
            for i, chunk in enumerate(chunks):
                data = dict(content=chunk.content, metadata=chunk.metadata)
                res_data.append(data)
            ret = dict(success=dict(file=abspath, data=res_data))
            logger.info(f"extract success. abspath={abspath}")
            return ret
        except Exception as e:
            logger.error(f"extract error: {str(e)}", exc_info=True)
            ret = dict(error=f"extract error: {str(e)}")
            return ret
