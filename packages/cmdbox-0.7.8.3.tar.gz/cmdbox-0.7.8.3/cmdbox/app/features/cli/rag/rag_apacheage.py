from cmdbox.app import common
from cmdbox.app.features.cli.rag import rag_store
from typing import Dict, Any, Generator, List
import logging
import psycopg
from psycopg import Connection, sql


class RagApacheAGE(rag_store.RagStore):
    def __init__(self, dbhost:str, dbport:int, dbname:str, dbuser:str, dbpass:str, dbtimeout:int, logger:logging.Logger):
        """
        コンストラクタ

        Args:
            dbhost (str): データベースホスト名
            dbport (int): データベースポート
            dbname (str): データベース名
            dbuser (str): データベースユーザー名
            dbpass (str): データベースパスワード
            dbtimeout (int): データベース接続のタイムアウト
            logger (logging.Logger): ロガー
        """
        if logger is None:
            raise ValueError("logger is required.")
        if dbhost is None:
            raise ValueError("dbhost is required.")
        if dbport is None:
            raise ValueError("dbport is required.")
        if dbname is None:
            raise ValueError("dbname is required.")
        if dbuser is None:
            raise ValueError("dbuser is required.")
        if dbpass is None:
            raise ValueError("dbpass is required.")
        if dbtimeout is None:
            raise ValueError("dbtimeout is required.")
        self.logger = logger
        self.dbhost = dbhost
        self.dbport = dbport
        self.dbname = dbname
        self.dbuser = dbuser
        self.dbpass = dbpass
        self.dbtimeout = dbtimeout

    def install(self) -> None:
        """
        apacheage拡張機能をインストールします
        """
        with psycopg.connect(
            host=self.dbhost,
            port=self.dbport,
            dbname=self.dbname,
            user=self.dbuser,
            password=self.dbpass,
            connect_timeout=self.dbtimeout) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                I = sql.Identifier
                cur.execute(sql.SQL("CREATE SCHEMA IF NOT EXISTS {}").format(I(self.dbuser)))
                cur.execute(sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}").format(I(self.dbname), I(self.dbuser)))
                cur.execute(sql.SQL("GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA {} TO {}").format(I(self.dbuser), I(self.dbuser)))
                cur.execute(sql.SQL("GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA {} TO {}").format(I(self.dbuser), I(self.dbuser)))
                cur.execute(sql.SQL("GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA {} TO {}").format(I(self.dbuser), I(self.dbuser)))
                cur.execute(sql.SQL("GRANT ALL PRIVILEGES ON SCHEMA {} TO {}").format(I(self.dbuser), I(self.dbuser)))
                cur.execute(sql.SQL("CREATE EXTENSION IF NOT EXISTS age"))
                cur.execute(sql.SQL("SELECT extversion FROM pg_extension WHERE extname = 'age'"))
                for record in cur:
                    self.logger.info(f"extversion={record}")

    def create_tables(self, servicename:str, embed_vector_dim:int=256) -> None:
        """
        テーブル（グラフ）を作成します

        Args:
            servicename (str): サービス名
            embed_vector_dim (int): 埋め込みベクトルの次元数
        """
        if servicename is None: raise ValueError("servicename is required.")

        with self.connect() as conn:
            conn.autocommit = False
            with conn.cursor() as cur:
                # グラフを作成
                graph_name = f"{servicename}"
                cur.execute(sql.SQL("SELECT create_graph({})").format(sql.Literal(graph_name)))
                # 特徴量テーブルを作成
                table_name = f"{self.dbuser}.{servicename}_embedding"
                I = sql.Identifier
                cur.execute(sql.SQL(
                    "CREATE TABLE IF NOT EXISTS {} (" + \
                    "id SERIAL PRIMARY KEY, " + \
                    "vec_id UUID NOT NULL, " + \
                    "content_text TEXT, " + \
                    "content_type VARCHAR, " + \
                    "content_blob BYTEA, " + \
                    "content_size BIGINT, " + \
                    "origin_name VARCHAR, " + \
                    "origin_type VARCHAR, " + \
                    "origin_url VARCHAR, " + \
                    "metadata JSONB, " + \
                    "vec_model VARCHAR NOT NULL, " + \
                    f"vec_data vector({embed_vector_dim}) NOT NULL, " + \
                    "update_dt TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, " + \
                    "created_dt TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP" + \
                    ")").format(I(table_name)))
                cur.execute(sql.SQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS {} ON {} (vec_id)"
                    ).format(I(f"{table_name}_vec_id_idx"), I(table_name)))
                cur.execute(sql.SQL(
                    "CREATE INDEX IF NOT EXISTS {} ON {} " + \
                    "USING ivfflat (vec_data vector_l2_ops) WITH (lists = 100)"
                    ).format(I(f"{table_name}_vec_data_idx"), I(table_name)))
                conn.commit()

    def connect(self) -> Any:
        """
        データベースに接続します
        """
        return psycopg.connect(
            host=self.dbhost,
            port=self.dbport,
            dbname=self.dbname,
            user=self.dbuser,
            password=self.dbpass,
            connect_timeout=self.dbtimeout)

    def insert_doc(self, *, connection:Connection=None, servicename:str=None,
                   vec_id:str=None, content_text:str=None, content_type:str=None, content_blob:bytes=None,
                   origin_name:str=None, origin_type:str=None, origin_url:str=None,
                   metadata:Dict[str, Any]=None, vec_model:str=None, vec_data:Any=None
                   ) -> None:
        """
        ドキュメントを挿入します

        Args:
            connection: データベース接続オブジェクト
            servicename (str): サービス名
            content_text (str): ドキュメントの内容
            content_type (str): ドキュメントのタイプ
            content_blob (bytes): ドキュメントのバイナリデータ
            origin_name (str): ドキュメントの元の名前
            origin_type (str): ドキュメントの元のタイプ
            origin_url (str): ドキュメントの元のURL
            metadata (dict): ドキュメントのメタデータ
            vec_model (str): ベクトルモデルの名前
            vec_data (Any): ベクトルデータ
        """
        if connection is None: raise ValueError("connection is required.")
        if servicename is None: raise ValueError("servicename is required.")
        vec_id = vec_id if vec_id is not None else common.gen_uuid()
        if content_text is None: raise ValueError("content_text is required.")
        content_type = content_type if content_type is not None else metadata.get('content_type', 'text')
        content_blob = content_blob if content_blob is not None else b''
        content_size = len(content_blob) if content_blob else 0
        origin_name = origin_name if origin_name is not None else metadata.get('origin_name', 'unknown')
        origin_type = origin_type if origin_type is not None else metadata.get('origin_type', 'unknown')
        origin_url = origin_url if origin_url is not None else metadata.get('origin_url', 'unknown')
        if metadata is None: raise ValueError("metadata is required.")
        vec_model = vec_model if vec_model is not None else metadata.get('vec_model', 'unknown')
        if vec_data is None: raise ValueError("vec_data is required.")

        with connection.cursor() as cur:
            table_name = f"{self.dbuser}.{servicename}_embedding"
            I = sql.Identifier
            cur.execute(sql.SQL(
                "INSERT INTO {} ("
                "vec_id, "
                "content_text, "
                "content_type, "
                "content_blob, "
                "content_size, "
                "origin_name, "
                "origin_type, "
                "origin_url, "
                "metadata, "
                "vec_model, "
                "vec_data) VALUES ("
                "%(vec_id)s,"
                "%(content_text)s,"
                "%(content_type)s,"
                "%(content_blob)s,"
                "%(content_size)s,"
                "%(origin_name)s,"
                "%(origin_type)s,"
                "%(origin_url)s,"
                "%(metadata)s,"
                "%(vec_model)s,"
                "%(vec_data)s)"
            ).format(I(table_name)), {
                'vec_id': vec_id,
                'content_text': content_text,
                'content_type': content_type,
                'content_blob': content_blob,
                'content_size': content_size,
                'origin_name': origin_name,
                'origin_type': origin_type,
                'origin_url': origin_url,
                'metadata': common.to_str(metadata),
                'vec_model': vec_model,
                'vec_data': common.to_str(vec_data)
            })

    def delete_doc(self, *, connection:Connection=None, servicename:str=None,
                   vec_id:str=None, content_text:str=None, content_type:str=None,
                   origin_name:str=None, origin_type:str=None, origin_url:str=None,
                   metadata:Dict[str, Any]=None, vec_model:str=None) -> None:
        """
        ドキュメントを削除します

        Args:
            connection: データベース接続オブジェクト
            servicename (str): サービス名
            vec_id (str): ベクトルID
            content_text (str): ドキュメントの内容
            content_type (str): ドキュメントのタイプ
            origin_name (str): ドキュメントの元の名前
            origin_type (str): ドキュメントの元のタイプ
            origin_url (str): ドキュメントの元のURL
            metadata (dict): ドキュメントのメタデータ
            vec_model (str): ベクトルモデルの名前
        """
        if connection is None: raise ValueError("connection is required.")
        if servicename is None: raise ValueError("servicename is required.")
        metadata_where = None
        if metadata is not None and len(metadata) > 0:
            metadata_where = " AND ".join([f"metadata->>'{k}' = %({k})s" for k in metadata.keys()])
        with connection.cursor() as cur:
            table_name = f"{self.dbuser}.{servicename}_embedding"
            I = sql.Identifier
            where_clauses = list(filter(None, [
                ("vec_id = %(vec_id)s" if vec_id is not None else ""),
                ("content_text like %(content_text)s" if content_text is not None else ""),
                ("content_type = %(content_type)s" if content_type is not None else ""),
                ("origin_name = %(origin_name)s" if origin_name is not None else ""),
                ("origin_type = %(origin_type)s" if origin_type is not None else ""),
                ("origin_url = %(origin_url)s" if origin_url is not None else ""),
                (f"({metadata_where})" if metadata_where is not None else ""),
                ("vec_model = %(vec_model)s" if vec_model is not None else "")
            ]))
            params = {
                'vec_id': vec_id if vec_id is not None else '',
                'content_text': f'%{content_text}%' if content_text is not None else '',
                'content_type': content_type if content_type is not None else '',
                'origin_name': origin_name if origin_name is not None else '',
                'origin_type': origin_type if origin_type is not None else '',
                'origin_url': origin_url if origin_url is not None else '',
                'vec_model': vec_model if vec_model is not None else '',
            }
            if metadata is not None:
                params.update({k: common.to_str(v) for k, v in metadata.items()})
            cur.execute(query=sql.SQL(
                "DELETE FROM {} " + ("WHERE " + " AND ".join(where_clauses) if where_clauses else "")
            ).format(I(table_name)), params=params)

    def select_doc(self, *, connection:Any=None, select:List[str]=None, servicename:str=None,
                   vec_id:str=None, content_text:str=None, content_type:str=None,
                   origin_name:str=None, origin_type:str=None, origin_url:str=None,
                   metadata:Dict[str, Any]=None, vec_model:str=None,
                   vec_data:str=None, sort_dict:Dict[str, Any]=None, kcount:int=None,) -> Generator[Any, Any, Any]:
        """
        ドキュメントを選択します

        Args:
            connection: データベース接続オブジェクト
            select (str): 取得する項目をカンマ区切りで指定します。未指定の場合はすべての項目を返します。
            servicename (str): サービス名
            vec_id (str): ベクトルID
            content_text (str): ドキュメントの内容
            content_type (str): ドキュメントのタイプ
            origin_name (str): ドキュメントの元の名前
            origin_type (str): ドキュメントの元のタイプ
            origin_url (str): ドキュメントの元のURL
            metadata (dict): ドキュメントのメタデータ
            vec_model (str): ベクトルモデルの名前
            vec_data (str): ドキュメントのベクトル表現
            sort_dict (dict): ソート条件を指定します。キーに項目名、値にソート順（ `ASC` (昇順) 又は `DESC` (降順)）を指定します。
            kcount (int): 検索結果件数

        Yields:
            record: ドキュメントレコード
        """
        if connection is None: raise ValueError("connection is required.")
        if servicename is None: raise ValueError("servicename is required.")
        metadata_where = None
        if metadata is not None and len(metadata) > 0:
            metadata_where = " AND ".join([f"metadata->>'{k}' = %({k})s" for k in metadata.keys()])
        with connection.cursor() as cur:
            table_name = f"{self.dbuser}.{servicename}_embedding"
            I = sql.Identifier
            where_clauses = []
            params = {}
            if vec_id:
                where_clauses.append("vec_id = %(vec_id)s")
                params['vec_id'] = vec_id
            if content_text:
                where_clauses.append("content_text like %(content_text)s")
                params['content_text'] = f'%{content_text}%'
            if content_type:
                where_clauses.append("content_type = %(content_type)s")
                params['content_type'] = content_type
            if origin_name:
                where_clauses.append("origin_name = %(origin_name)s")
                params['origin_name'] = origin_name
            if origin_type:
                where_clauses.append("origin_type = %(origin_type)s")
                params['origin_type'] = origin_type
            if origin_url:
                where_clauses.append("origin_url = %(origin_url)s")
                params['origin_url'] = origin_url
            if metadata_where:
                where_clauses.append(f"({metadata_where})")
                params.update({k: common.to_str(v) for k, v in metadata.items()})
            if vec_model:
                where_clauses.append("vec_model = %(vec_model)s")
                params['vec_model'] = vec_model
            if vec_data:
                params['vec_data'] = vec_data
            if sort_dict is not None and len(sort_dict) > 0:
                order_clauses = []
                for k, v in sort_dict.items():
                    if v.upper() not in ['ASC', 'DESC']:
                        raise ValueError("sort_dict values must be 'ASC' or 'DESC'.")
                    order_clauses.append(f"{k} {v.upper()}")
                order_sql = " ORDER BY " + ", ".join(order_clauses)
            select = [s for s in select if s] if select is not None and len(select) > 0 else None
            cur.execute(query=sql.SQL(
                "SELECT {} FROM {} " + ("WHERE " + " AND ".join(where_clauses) if where_clauses else "")
                + (" ORDER BY vec_data <=> %(vec_data)s ASC " if vec_data is not None else "")
                + (order_sql if vec_data is None and order_sql is not None else "")
                + (f"LIMIT {kcount}" if kcount is not None else "")
            ).format(sql.SQL(',').join(map(I, select)) if select else sql.SQL('*'),
                     I(table_name)),
                     params=params)
            colnames = [desc[0] for desc in cur.description]
            for record in cur:
                yield dict(zip(colnames, record))
