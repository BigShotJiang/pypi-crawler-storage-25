"""LangChain agent demo — registers all four TradeOdds tools.

Requirements:
    pip install tradeodds-langchain langchain langchain-openai
    export TRADEODDS_API_KEY=sk-to-...
    export OPENAI_API_KEY=sk-...

Run:
    python examples/agent_example.py
"""
from __future__ import annotations

import os
import sys

from tradeodds_langchain import all_tools


def main() -> int:
    if not os.environ.get("TRADEODDS_API_KEY"):
        print("Set TRADEODDS_API_KEY first.")
        return 1

    # Direct tool invocation works without an LLM — useful for testing.
    tools = all_tools()
    by_name = {t.name: t for t in tools}

    print("Registered tools:")
    for tool in tools:
        print(f"  - {tool.name}")
    print()

    # Show a one-liner agents would call:
    print("Calling tradeodds_analyze({'symbol': 'SPY'}):")
    result = by_name["tradeodds_analyze"].invoke({"symbol": "SPY"})
    if isinstance(result, dict) and result.get("ok") is False:
        print(f"  error: {result['error']}")
        return 1

    match_count = result.get("match_count") if isinstance(result, dict) else None
    print(f"  match_count={match_count}")

    # Plug into a full agent — uncomment if you have an LLM key set.
    #
    # from langchain.agents import AgentExecutor, create_tool_calling_agent
    # from langchain_core.prompts import ChatPromptTemplate
    # from langchain_openai import ChatOpenAI
    #
    # llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    # prompt = ChatPromptTemplate.from_messages([
    #     ("system", "You are a quantitative trading research assistant. Use TradeOdds tools to ground every claim in historical base rates."),
    #     ("human", "{input}"),
    #     ("placeholder", "{agent_scratchpad}"),
    # ])
    # agent = create_tool_calling_agent(llm, tools, prompt)
    # executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
    # executor.invoke({"input": "Analyze SPY's setup right now and tell me the historical 5-day win rate."})
    return 0


if __name__ == "__main__":
    sys.exit(main())
