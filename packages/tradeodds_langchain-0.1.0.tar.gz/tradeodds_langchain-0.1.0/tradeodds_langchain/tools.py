"""LangChain ``BaseTool`` subclasses for the TradeOdds REST API.

Each tool wraps a single SDK method. Tools share a default
``TradeOddsClient`` so an agent that registers all four reuses one HTTP
session — pass ``client=...`` to override (useful for staging or for
injecting a session with retries).

Tool descriptions are written for the LLM that will call them: each spells
out *what it does*, *when to use it*, and *what it returns*. Agents that
read these descriptions should be able to pick the right tool without
further prompting.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field
from tradeodds import (
    ApiError,
    DNAConditions,
    ForwardPeriod,
    LookbackYears,
    PerfFilter,
    ReferencePeriod,
    ScreenerFilters,
    TradeOddsClient,
)

__version__ = "0.1.0"


# ── Argument schemas ────────────────────────────────────────────────────

class ListSymbolsInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    active_only: bool = Field(
        True,
        description="Return only currently synced symbols. Set False only if you specifically need deactivated symbols.",
    )


class AnalyzeInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    symbol: str = Field(
        ...,
        description="Ticker symbol to analyze. Must be active in the TradeOdds universe.",
    )
    reference_period: Literal["1d", "2d", "3d", "4d", "5d", "1w", "1m"] = Field(
        "1d",
        description="How recent the observed window is. '1d' = today's bar; '5d' = aggregated last 5 trading days.",
    )
    forward_period: Literal["1d", "2d", "3d", "4d", "5d", "20d", "1w", "1m"] = Field(
        "5d",
        description="Trading days forward to compute outcome statistics for each historical match.",
    )
    conditions: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "DNA filter flags. Boolean toggles for each factor. "
            "Available keys: daily_change, magnitude, magnitude_mode ('add'|'replace'), "
            "vix_level, vix_move, regime, rel_vol, rsi_zone, rsi_slope, "
            "structure_precision, earnings_prox, streak, volume_streak, earnings_perf, "
            "overnight_gap, analyst_trend, month_of_year, macro_risk. "
            "Omit a key or set False to ignore that factor. daily_change defaults to True."
        ),
    )
    lookback_years: Literal["1y", "3y", "5y", "10y", "20y", "max"] = Field(
        "max",
        description="How far back to search for historical matches.",
    )
    price_tolerance: int = Field(
        0, ge=0, le=3,
        description="Bucket-step tolerance for price-change matching (0=exact, 3=±3 buckets).",
    )
    vix_tolerance: int = Field(
        0, ge=0, le=3,
        description="Bucket-step tolerance for VIX matching (0=exact, 3=±3 buckets).",
    )


class FactorMatchInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    forward_periods: List[Literal["1d", "5d", "20d"]] = Field(
        default_factory=lambda: ["1d", "5d", "20d"],
        description="Forward windows to compute statistics for. Default = all three.",
    )
    conditions: Optional[Dict[str, Any]] = Field(
        None,
        description="DNA filter flags — same keys as the analyze tool.",
    )
    filters: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Symbol-universe filters applied before scanning. Keys: is_etf, is_crypto, "
            "is_gold_standard, sector, industry, symbols (whitelist), price_min, price_max, volume_min."
        ),
    )
    perf_filter: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Post-scan threshold. Shape: "
            "{metric: 'win_1d'|'win_5d'|'win_20d'|'mean_1d'|'mean_5d'|'mean_20d', "
            "operator: 'gt'|'lt', threshold: float}."
        ),
    )
    history_range: Literal["1y", "3y", "5y", "10y", "20y", "max"] = Field(
        "max",
        description="Historical lookback used to compute each match's stats.",
    )
    min_instances: int = Field(
        10, ge=1, le=100,
        description="Minimum historical match count required for a symbol to appear.",
    )
    price_tolerance: int = Field(0, ge=0, le=3)
    vix_tolerance: int = Field(0, ge=0, le=3)


# ── Helpers ─────────────────────────────────────────────────────────────

def _format_error(exc: ApiError) -> Dict[str, Any]:
    """Translate an SDK exception into a structured payload the agent can read."""
    return {
        "ok": False,
        "error": {
            "code": exc.code,
            "message": exc.message,
            "hint": exc.hint,
            "request_id": exc.request_id,
            "status_code": exc.status_code,
        },
    }


# ── Tools ───────────────────────────────────────────────────────────────

class _TradeOddsToolBase(BaseTool):
    """Shared plumbing — every tool gets an optional injected client."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    client: Optional[TradeOddsClient] = Field(
        default=None,
        exclude=True,
        description="Optional pre-configured TradeOddsClient. Defaults to one built from environment variables.",
    )

    def _client(self) -> TradeOddsClient:
        if self.client is None:
            # Lazy-build so importing the tool never requires an API key.
            self.client = TradeOddsClient()
        return self.client


class TradeOddsListSymbolsTool(_TradeOddsToolBase):
    """List every symbol available for TradeOdds analysis."""

    name: str = "tradeodds_list_symbols"
    description: str = (
        "List every symbol available in the TradeOdds universe (~3,200 active "
        "instruments — US equities, ETFs, major crypto). "
        "Use this when the user asks what symbols are supported, or when you "
        "need to verify a ticker before calling tradeodds_analyze. "
        "Returns: {count: int, symbols: [{symbol, name, sector, is_etf, is_gold_standard}]}. "
        "Free — no API key or per-call cost."
    )
    args_schema: Type[BaseModel] = ListSymbolsInput

    def _run(self, active_only: bool = True, **_: Any) -> Dict[str, Any]:
        try:
            return self._client().symbols(active_only=active_only)
        except ApiError as exc:
            return _format_error(exc)


class TradeOddsAnalyzeTool(_TradeOddsToolBase):
    """Run TradeOdds historical pattern analysis on a single symbol."""

    name: str = "tradeodds_analyze"
    description: str = (
        "Run quantitative historical-pattern analysis on a single symbol. "
        "Given the symbol's current DNA fingerprint (price move, VIX regime, RSI "
        "zone, market structure, etc.), this finds every matching historical day "
        "and reports forward-return statistics — match count, win rate, median "
        "return, distribution of outcomes. "
        "Use this when the user asks 'what usually happens after X', wants the "
        "base rate for a setup, or is evaluating a specific stock or ETF. "
        "Inputs: symbol (required), forward_period (e.g. '5d', '20d'), conditions "
        "(toggle DNA factors like vix_level, regime, rsi_zone, streak), lookback_years. "
        "Returns: structured analysis result including match_count, forward_stats, "
        "matching historical instances, narrative summary. "
        "Costs $0.05/call. Cap: 1,000 calls/day."
    )
    args_schema: Type[BaseModel] = AnalyzeInput

    def _run(
        self,
        symbol: str,
        reference_period: ReferencePeriod = "1d",
        forward_period: ForwardPeriod = "5d",
        conditions: Optional[Dict[str, Any]] = None,
        lookback_years: LookbackYears = "max",
        price_tolerance: int = 0,
        vix_tolerance: int = 0,
        **_: Any,
    ) -> Dict[str, Any]:
        try:
            return self._client().analyze(
                symbol=symbol,
                reference_period=reference_period,
                forward_period=forward_period,
                conditions=conditions,  # type: ignore[arg-type]
                lookback_years=lookback_years,
                price_tolerance=price_tolerance,
                vix_tolerance=vix_tolerance,
            )
        except ApiError as exc:
            return _format_error(exc)


class TradeOddsFactorMatchTool(_TradeOddsToolBase):
    """Scan the entire universe for symbols matching a DNA fingerprint."""

    name: str = "tradeodds_factor_match"
    description: str = (
        "Scan all ~3,200 TradeOdds symbols for instruments whose CURRENT state "
        "matches a supplied DNA fingerprint (e.g. 'high VIX, oversold RSI, bull "
        "regime'). Returns a ranked list with each symbol's historical forward-"
        "return stats over 1d / 5d / 20d windows. "
        "Use this when the user wants to discover candidates ('what's set up like "
        "X right now?'), screen for high win-rate setups, or build a watchlist. "
        "Inputs: conditions (DNA flags), filters (e.g. {'is_etf': false, "
        "'price_min': 10}), perf_filter (e.g. {'metric': 'win_5d', 'operator': "
        "'gt', 'threshold': 0.6}), min_instances. "
        "Heavy compute — server caps execution at 180s. If it times out, narrow "
        "filters or raise min_instances. "
        "Costs $0.15/call. Cap: 200 calls/day."
    )
    args_schema: Type[BaseModel] = FactorMatchInput

    def _run(
        self,
        forward_periods: Optional[List[str]] = None,
        conditions: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None,
        perf_filter: Optional[Dict[str, Any]] = None,
        history_range: LookbackYears = "max",
        min_instances: int = 10,
        price_tolerance: int = 0,
        vix_tolerance: int = 0,
        **_: Any,
    ) -> Dict[str, Any]:
        try:
            return self._client().factor_match(
                forward_periods=forward_periods,  # type: ignore[arg-type]
                conditions=conditions,  # type: ignore[arg-type]
                filters=filters,  # type: ignore[arg-type]
                perf_filter=perf_filter,  # type: ignore[arg-type]
                history_range=history_range,
                min_instances=min_instances,
                price_tolerance=price_tolerance,
                vix_tolerance=vix_tolerance,
            )
        except ApiError as exc:
            return _format_error(exc)


def all_tools(client: Optional[TradeOddsClient] = None) -> List[BaseTool]:
    """Return one instance of every TradeOdds tool, optionally sharing a client."""
    return [
        TradeOddsListSymbolsTool(client=client),
        TradeOddsAnalyzeTool(client=client),
        TradeOddsFactorMatchTool(client=client),
    ]


__all__ = [
    "__version__",
    "TradeOddsListSymbolsTool",
    "TradeOddsAnalyzeTool",
    "TradeOddsFactorMatchTool",
    "ListSymbolsInput",
    "AnalyzeInput",
    "FactorMatchInput",
    "all_tools",
]
