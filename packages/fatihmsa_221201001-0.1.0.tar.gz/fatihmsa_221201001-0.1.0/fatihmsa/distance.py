import numpy as np

def get_kmers(sequence, k=3):
    """Bir diziyi k uzunluğunda parçalara böler."""
    return set([sequence[i:i+k] for i in range(len(sequence) - k + 1)])

def calculate_distance_matrix(sequences):
    """K-mer kullanarak diziler arası uzaklık matrisini hesaplar."""
    n = len(sequences)
    dist_matrix = np.zeros((n, n))
    
    kmer_list = [get_kmers(seq) for seq in sequences]
    
    for i in range(n):
        for j in range(i+1, n):
            intersection = len(kmer_list[i].intersection(kmer_list[j]))
            union = len(kmer_list[i].union(kmer_list[j]))
            distance = 1.0 - (intersection / union) if union != 0 else 1.0
            
            dist_matrix[i][j] = distance
            dist_matrix[j][i] = distance
            
    return dist_matrix

def upgma(dist_matrix):
    """Basit bir UPGMA rehber ağaç oluşturma mantığı."""
    # Proje kapsamında en yakın iki dizinin indeksini bulup döndüren basitleştirilmiş bir rehber.
    # Gerçek MUSCLE burada dallanma geçmişini tutar.
    n = len(dist_matrix)
    min_dist = float('inf')
    closest_pair = (0, 1)
    
    for i in range(n):
        for j in range(i+1, n):
            if dist_matrix[i][j] < min_dist:
                min_dist = dist_matrix[i][j]
                closest_pair = (i, j)
                
    return closest_pair