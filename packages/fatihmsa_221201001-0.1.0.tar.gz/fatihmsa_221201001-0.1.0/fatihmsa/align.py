import numpy as np

def needleman_wunsch(seq1, seq2, match=1, mismatch=-1, gap=-2):
    """İki diziyi dinamik programlama ile hizalar."""
    n, m = len(seq1), len(seq2)
    score_matrix = np.zeros((n + 1, m + 1))
    
    # İlk satır ve sütunu boşluk cezaları ile doldur (Initialization)
    for i in range(n + 1):
        score_matrix[i][0] = gap * i
    for j in range(m + 1):
        score_matrix[0][j] = gap * j
        
    # Matrisi doldur (Recursion)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if seq1[i-1] == seq2[j-1]:
                match_score = score_matrix[i-1][j-1] + match
            else:
                match_score = score_matrix[i-1][j-1] + mismatch
                
            delete = score_matrix[i-1][j] + gap
            insert = score_matrix[i][j-1] + gap
            
            score_matrix[i][j] = max(match_score, delete, insert)
            
    # Geriye doğru takip (Traceback) - Hizalanmış dizileri oluştur
    align1, align2 = "", ""
    i, j = n, m
    
    while i > 0 and j > 0:
        current_score = score_matrix[i][j]
        diagonal_score = score_matrix[i-1][j-1]
        up_score = score_matrix[i][j-1]
        left_score = score_matrix[i-1][j]
        
        if current_score == diagonal_score + (match if seq1[i-1] == seq2[j-1] else mismatch):
            align1 += seq1[i-1]
            align2 += seq2[j-1]
            i -= 1
            j -= 1
        elif current_score == left_score + gap:
            align1 += seq1[i-1]
            align2 += "-"
            i -= 1
        elif current_score == up_score + gap:
            align1 += "-"
            align2 += seq2[j-1]
            j -= 1
            
    while i > 0:
        align1 += seq1[i-1]
        align2 += "-"
        i -= 1
    while j > 0:
        align1 += "-"
        align2 += seq2[j-1]
        j -= 1
        
    return align1[::-1], align2[::-1]