from .distance import calculate_distance_matrix, upgma
from .align import needleman_wunsch

def run_muscle(sequences):
    """
    MUSCLE algoritmasının ana akışı:
    1. K-mer uzaklık matrisi hesapla
    2. UPGMA ile birbirine en yakın dizileri bul
    3. Dinamik programlama ile hizala
    """
    print("1. Uzaklık Matrisi Hesaplanıyor (K-mer)...")
    dist_matrix = calculate_distance_matrix(sequences)
    
    print("2. UPGMA Rehber Ağaç Oluşturuluyor...")
    closest_pair = upgma(dist_matrix)
    seq1_idx, seq2_idx = closest_pair
    
    print(f"3. En yakın diziler hizalanıyor (Dizi {seq1_idx+1} ve Dizi {seq2_idx+1})...")
    aligned_1, aligned_2 = needleman_wunsch(sequences[seq1_idx], sequences[seq2_idx])
    
    return [aligned_1, aligned_2]