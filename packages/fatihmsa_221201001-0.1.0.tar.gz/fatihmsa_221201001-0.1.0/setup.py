from setuptools import setup, find_packages

setup(
    name="FatihMSA-221201001",
    version="0.1.0",
    author="Fatih Yilmazer",
    description="Python implementation of the MUSCLE Multiple Sequence Alignment algorithm.",
    packages=find_packages(),
    install_requires=["numpy"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)