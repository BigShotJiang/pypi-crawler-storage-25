class UnknownStdFunc(Exception):
  pass