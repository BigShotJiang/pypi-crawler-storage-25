"""OpenAI client plugin for space-evals."""

from __future__ import annotations

import json
import os
from typing import Any

from space_evals.clients.base import BaseClient, ClientResponse, Message
from space_evals.models.token_usage import TokenUsage
from space_evals.models.transcript import ToolCall


class OpenAIClient(BaseClient):
    def __init__(self, model: str, api_key_env: str | None = None, **params: Any) -> None:
        self.model = model
        self.api_key = os.environ[api_key_env or "OPENAI_API_KEY"]
        self.base_url = params.pop("base_url", None)
        self.params = params
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(api_key=self.api_key, base_url=self.base_url)
        return self._client

    async def send(self, messages: list[Message], system_prompt: str = "") -> ClientResponse:
        client = self._get_client()

        api_messages: list[dict[str, str]] = []
        if system_prompt:
            api_messages.append({"role": "system", "content": system_prompt})
        for msg in messages:
            api_messages.append({"role": msg.role, "content": msg.content})

        response = await client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            **self.params,
        )

        choice = response.choices[0]
        content = choice.message.content or ""

        tool_calls: list[ToolCall] = []
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append(ToolCall(
                    tool_name=tc.function.name,
                    arguments=json.loads(tc.function.arguments) if tc.function.arguments else {},
                ))

        usage = None
        if response.usage:
            usage = TokenUsage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
            )

        return ClientResponse(
            content=content,
            tool_calls=tool_calls,
            usage=usage,
            raw=response.model_dump(),
        )
