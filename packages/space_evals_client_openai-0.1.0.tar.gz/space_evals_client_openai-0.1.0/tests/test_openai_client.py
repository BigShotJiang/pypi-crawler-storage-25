"""Tests for the OpenAI client plugin."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from space_evals.clients.base import Message
from space_evals_client_openai import OpenAIClient


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    return OpenAIClient(model="gpt-4o")


class TestOpenAIClient:
    def test_reads_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        c = OpenAIClient(model="gpt-4o")
        assert c.api_key == "sk-test"

    def test_reads_custom_api_key_env(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "sk-custom")
        c = OpenAIClient(model="gpt-4o", api_key_env="MY_KEY")
        assert c.api_key == "sk-custom"

    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(KeyError):
            OpenAIClient(model="gpt-4o")

    @pytest.mark.asyncio
    async def test_send_formats_messages(self, client):
        mock_response = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = "Hello!"
        mock_choice.message.tool_calls = None
        mock_response.choices = [mock_choice]
        mock_response.model_dump.return_value = {"id": "test"}

        mock_async_client = AsyncMock()
        mock_async_client.chat.completions.create = AsyncMock(
            return_value=mock_response
        )
        client._client = mock_async_client

        result = await client.send(
            messages=[Message(role="user", content="Hi")],
            system_prompt="Be helpful",
        )

        assert result.content == "Hello!"
        call_kwargs = mock_async_client.chat.completions.create.call_args
        messages = call_kwargs.kwargs["messages"]
        assert messages[0] == {"role": "system", "content": "Be helpful"}
        assert messages[1] == {"role": "user", "content": "Hi"}

    @pytest.mark.asyncio
    async def test_send_extracts_tool_calls(self, client):
        mock_tc = MagicMock()
        mock_tc.function.name = "get_weather"
        mock_tc.function.arguments = json.dumps({"city": "NYC"})

        mock_choice = MagicMock()
        mock_choice.message.content = "Let me check"
        mock_choice.message.tool_calls = [mock_tc]

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.model_dump.return_value = {}

        mock_async_client = AsyncMock()
        mock_async_client.chat.completions.create = AsyncMock(
            return_value=mock_response
        )
        client._client = mock_async_client

        result = await client.send(messages=[Message(role="user", content="weather?")])

        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].tool_name == "get_weather"
        assert result.tool_calls[0].arguments == {"city": "NYC"}
