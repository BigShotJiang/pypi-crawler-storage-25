"""
Bankr wallet authentication. Signing, wallet resolution, transaction submission.
"""

import time
import os
import logging
import requests as _requests

log = logging.getLogger("litcoin")

BANKR_BASE = "https://api.bankr.bot"
CLAIMS_CONTRACT = "0xF703DcF2E88C0673F776870fdb12A453927C6A5e"


def _looks_like_html(body_text):
    """Return True if body_text is an HTML error page (Express, nginx, etc).
    The real Bankr API always returns JSON, so an HTML body is a strong
    signal that the request hit a different server (DNS hijack, proxy
    intercept, /etc/hosts override, shadowed auth.py)."""
    if not body_text:
        return False
    head = body_text.lstrip()[:200].lower()
    return head.startswith("<!doctype") or head.startswith("<html") or "cannot post" in head or "cannot get" in head


def _interception_hint():
    """Diagnostic hint surfaced when Bankr returns HTML instead of JSON.
    Includes everything the miner operator needs to self-diagnose without
    asking us to debug their machine."""
    proxies = []
    for var in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy"):
        v = os.environ.get(var)
        if v:
            proxies.append(f"{var}={v}")
    proxy_line = f" Proxy env vars set: {', '.join(proxies)}." if proxies else " No HTTP_PROXY env vars are set."
    return (
        f"Your machine is not reaching the real api.bankr.bot. "
        f"Something between your network and Bankr returned an HTML error page where "
        f"Bankr would return JSON. Common causes: corporate / ISP DNS hijack, an HTTP proxy, "
        f"an /etc/hosts entry for api.bankr.bot, or a shadowed litcoin/auth.py in your project. "
        f"Run `python -m litcoin.diagnose` for a step-by-step check, or send `nslookup api.bankr.bot` "
        f"and `env | grep -i proxy` for help.{proxy_line}"
    )


def _raise_for_bankr_response(r, op):
    """Shared error helper for every Bankr API call. Distinguishes three
    failure modes:
      1. Network intercept (HTML body) -> tells operator how to fix their network
      2. Real Bankr error (JSON body) -> surfaces Bankr's explicit error message
      3. Unknown shape -> shows truncated raw body
    op is the operation name (sign / submit / wallet lookup) used in the
    error message."""
    text = r.text or ""
    if _looks_like_html(text):
        raise ValueError(f"Bankr {op} failed: network is intercepting api.bankr.bot. {_interception_hint()}")
    try:
        body = r.json()
        msg = body.get("error") or body.get("message") or body.get("detail") or text[:200]
    except Exception:
        msg = text[:200]
    raise ValueError(f"Bankr {op} failed ({r.status_code}): {msg}")


class BankrAuth:
    """Manages Bankr wallet operations: signing, wallet lookup, tx submission."""

    def __init__(self, api_key):
        if not api_key:
            raise ValueError("Bankr API key required (bk_...)")
        self.api_key = api_key
        # Alias so existing call sites (agent.delegate / undelegate / confirm /
        # revoke) that reference self.bankr.key continue to work alongside
        # the canonical .api_key.
        self.key = api_key
        self._wallet = None

    def _headers(self):
        return {"Content-Type": "application/json", "X-API-Key": self.api_key}

    @property
    def wallet(self):
        """Resolve and cache the wallet address from Bankr."""
        if self._wallet:
            return self._wallet
        try:
            r = _requests.get(f"{BANKR_BASE}/agent/me", headers=self._headers(), timeout=15)
        except _requests.exceptions.RequestException as e:
            raise ValueError(f"Bankr wallet lookup failed: cannot reach api.bankr.bot ({e}). {_interception_hint()}")
        if r.status_code < 200 or r.status_code >= 300:
            _raise_for_bankr_response(r, "wallet lookup")
        if _looks_like_html(r.text or ""):
            raise ValueError(f"Bankr wallet lookup failed: api.bankr.bot returned an HTML page instead of JSON. {_interception_hint()}")
        try:
            data = r.json()
        except Exception:
            raise ValueError(f"Bankr returned non-JSON response: {(r.text or '')[:200]}. {_interception_hint()}")
        # Try multiple response formats
        for key in ("wallets", "addresses"):
            items = data.get(key, [])
            if isinstance(items, list):
                for w in items:
                    addr = w.get("address", w) if isinstance(w, dict) else w
                    if isinstance(addr, str) and addr.startswith("0x"):
                        self._wallet = addr.lower()
                        return self._wallet
        for key in ("address", "evmAddress", "wallet"):
            if key in data and isinstance(data[key], str) and data[key].startswith("0x"):
                self._wallet = data[key].lower()
                return self._wallet
        raise ValueError(f"No wallet found in Bankr response: {data}")

    def sign(self, message):
        """Sign a message via Bankr personal_sign.

        On non-2xx response, raises a ValueError that distinguishes three
        failure modes: network interception (DNS / proxy / hosts file
        rerouting api.bankr.bot to another server), real Bankr error
        (bad key, account inactive, maintenance), and unknown body shapes.
        Lets miner operators self-diagnose without scraping a stack trace.
        """
        try:
            r = _requests.post(f"{BANKR_BASE}/agent/sign", headers=self._headers(), timeout=15,
                               json={"signatureType": "personal_sign", "message": message})
        except _requests.exceptions.RequestException as e:
            raise ValueError(f"Bankr sign failed: cannot reach api.bankr.bot ({e}). {_interception_hint()}")
        if r.status_code < 200 or r.status_code >= 300:
            _raise_for_bankr_response(r, "sign")
        if _looks_like_html(r.text or ""):
            raise ValueError(f"Bankr sign failed: api.bankr.bot returned an HTML page instead of JSON. {_interception_hint()}")
        try:
            sig = r.json().get("signature")
        except Exception as e:
            raise ValueError(f"Bankr returned non-JSON response: {(r.text or '')[:200]}. {_interception_hint()}")
        if not sig:
            raise ValueError("No signature returned from Bankr")
        return sig

    def submit_tx(self, to, calldata, value="0"):
        """Submit a raw transaction via Bankr."""
        try:
            r = _requests.post(f"{BANKR_BASE}/agent/submit", headers=self._headers(), timeout=30,
                               json={"transaction": {
                                   "to": to, "data": calldata, "value": value, "chainId": 8453
                               }})
        except _requests.exceptions.RequestException as e:
            raise ValueError(f"Bankr tx failed: cannot reach api.bankr.bot ({e}). {_interception_hint()}")
        if r.status_code != 200:
            _raise_for_bankr_response(r, "tx")
        if _looks_like_html(r.text or ""):
            raise ValueError(f"Bankr tx failed: api.bankr.bot returned an HTML page instead of JSON. {_interception_hint()}")
        data = r.json()
        tx_hash = data.get("hash") or data.get("txHash") or data.get("transactionHash")
        return {"hash": tx_hash, "raw": data}


class AuthSession:
    """Manages JWT authentication with the coordinator."""

    def __init__(self, bankr, api):
        self.bankr = bankr
        self.api = api
        self._token = None
        self._expiry = 0

    @property
    def token(self):
        """Get a valid auth token, refreshing if needed."""
        if self._token and time.time() < (self._expiry - 60):
            return self._token
        return self.refresh()

    def refresh(self):
        """Force-refresh the auth token."""
        wallet = self.bankr.wallet
        message = self.api.get_nonce(wallet)
        signature = self.bankr.sign(message)
        self._token = self.api.verify_auth(wallet, message, signature)
        self._expiry = time.time() + 3600
        log.info("Authenticated with coordinator")
        return self._token

    def header(self):
        return {"Authorization": f"Bearer {self.token}"}
