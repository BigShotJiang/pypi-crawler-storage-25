"""
litcoin.diagnose — self-service troubleshooting for miner setups.

Run with:
    python -m litcoin.diagnose
    python -m litcoin.diagnose --bankr-key bk_yourkey   (optional, deeper check)

Surfaces the things that actually go wrong in operator setups:
  - SDK install location and version (catches shadowed local files)
  - DNS resolution for api.bankr.bot + api.litcoin.app
  - HTTP_PROXY / HTTPS_PROXY env vars (corporate proxies rewrite requests)
  - Bankr endpoint reachability + response shape (HTML body = intercepted)
  - Coordinator reachability + version
  - Optional: live signature round-trip with a real bk_ key
"""

import argparse
import json
import os
import socket
import sys
from urllib.parse import urlparse

import requests as _requests

try:
    from . import auth as _auth
    from . import api as _api
    from . import __version__ as _sdk_version
except Exception:
    _auth = None
    _api = None
    _sdk_version = "unknown"


def _ok(s):   return f"[ OK ]   {s}"
def _warn(s): return f"[WARN]   {s}"
def _fail(s): return f"[FAIL]   {s}"
def _info(s): return f"[INFO]   {s}"


def check_sdk_install():
    print("\n=== SDK install ===")
    if _auth is None:
        print(_fail("Cannot import litcoin.auth. Reinstall with `pip install --force-reinstall litcoin`."))
        return False
    print(_info(f"SDK version: {_sdk_version}"))
    print(_info(f"auth.py loaded from: {_auth.__file__}"))
    print(_info(f"api.py loaded from: {_api.__file__ if _api else 'unknown'}"))
    print(_info(f"BANKR_BASE: {_auth.BANKR_BASE}"))

    # Shadow check. Only escalate to FAIL when a local file actually
    # shadows the installed module (loaded auth.__file__ resolves into
    # the local dir). Otherwise WARN, since legitimate dev setups can
    # have a `litcoin/` folder for unrelated reasons.
    cwd = os.path.abspath(os.getcwd())
    auth_path = os.path.abspath(_auth.__file__)
    shadow_candidates = [
        os.path.join(cwd, "litcoin"),
        os.path.join(cwd, "litcoin.py"),
        os.path.join(cwd, "auth.py"),
    ]
    real_shadow = False
    found_any = False
    for p in shadow_candidates:
        if not os.path.exists(p):
            continue
        found_any = True
        if auth_path.startswith(os.path.abspath(p)):
            print(_fail(f"Local '{p}' is shadowing the installed SDK. Loaded auth.py is from this local copy, not pip's. Rename it or run from a different directory."))
            real_shadow = True
        else:
            print(_warn(f"Local '{p}' exists but is not currently shadowing (loaded auth.py is from {auth_path})."))
    if not found_any:
        print(_ok("No shadowed litcoin files in current directory."))
    return not real_shadow


def check_proxy_env():
    print("\n=== Proxy environment ===")
    proxy_vars = {}
    for var in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy", "NO_PROXY", "no_proxy"):
        v = os.environ.get(var)
        if v:
            proxy_vars[var] = v
    if not proxy_vars:
        print(_ok("No HTTP proxy environment variables set."))
        return True
    for k, v in proxy_vars.items():
        print(_warn(f"{k}={v}"))
    print(_warn("If api.bankr.bot is not in NO_PROXY, the proxy may be rewriting requests."))
    return False


def check_dns(host):
    print(f"\n=== DNS: {host} ===")
    try:
        ips = sorted({ai[4][0] for ai in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)})
        for ip in ips:
            print(_info(f"resolves to {ip}"))
        if not ips:
            print(_fail("No IPs returned."))
            return None
        return ips
    except Exception as e:
        print(_fail(f"DNS resolution failed: {e}"))
        return None


def check_endpoint_shape(url, op_name, expect_json=True):
    """GET an endpoint and check whether the response is JSON-shaped.
    The real Bankr/coordinator endpoints always return JSON. An HTML
    response is a strong signal that the request hit a different server
    (intercepted by proxy, DNS hijack, /etc/hosts, etc)."""
    print(f"\n=== {op_name}: {url} ===")
    try:
        r = _requests.get(url, timeout=10, allow_redirects=False)
    except Exception as e:
        print(_fail(f"Request failed: {e}"))
        return False
    print(_info(f"HTTP {r.status_code}"))
    body = (r.text or "")
    if _auth and _auth._looks_like_html(body):
        print(_fail("Response body is HTML, not JSON. Something is intercepting this request."))
        print(_info(f"First 160 chars of body: {body[:160].strip()}"))
        return False
    if expect_json:
        try:
            data = r.json()
            print(_ok(f"Got JSON response: {json.dumps(data)[:200]}"))
            return True
        except Exception:
            print(_warn(f"Response is not JSON: {body[:160].strip()}"))
            return False
    return True


def check_bankr_with_key(bk_key):
    print("\n=== Bankr live check (with key) ===")
    if not bk_key.startswith("bk_"):
        print(_fail("Key does not start with 'bk_' — not a Bankr key."))
        return False
    try:
        bankr = _auth.BankrAuth(bk_key)
        wallet = bankr.wallet
        print(_ok(f"Bankr resolved wallet: {wallet}"))
        sig = bankr.sign("diagnose-test-message")
        if sig and sig.startswith("0x") and len(sig) > 40:
            print(_ok(f"Bankr returned a signature ({len(sig)} chars). All systems go."))
            return True
        print(_fail(f"Bankr returned something but it does not look like a signature: {sig}"))
        return False
    except Exception as e:
        # auth.py now surfaces clean, actionable errors — print verbatim.
        print(_fail(str(e)))
        return False


def main():
    ap = argparse.ArgumentParser(description="LITCOIN SDK diagnostic. Surfaces network, DNS, and install issues that block mining.")
    ap.add_argument("--bankr-key", default=os.environ.get("BANKR_API_KEY"),
                    help="Optional bk_ key for a live signature round-trip. Reads BANKR_API_KEY env var if not given.")
    args = ap.parse_args()

    print("LITCOIN SDK Diagnostic")
    print("=" * 60)

    results = {
        "sdk_install": check_sdk_install(),
        "proxy_env":   check_proxy_env(),
    }
    bankr_host = urlparse(_auth.BANKR_BASE).hostname if _auth else "api.bankr.bot"
    coord_host = urlparse(_api.COORDINATOR_URL).hostname if _api else "api.litcoin.app"

    results["bankr_dns"]  = check_dns(bankr_host) is not None
    results["coord_dns"]  = check_dns(coord_host) is not None
    results["bankr_root"] = check_endpoint_shape(f"https://{bankr_host}/agent/me", "Bankr /agent/me (no auth, expect 401 JSON)", expect_json=True)
    results["coord_ping"] = check_endpoint_shape(f"https://{coord_host}/v1/ping", "Coordinator /v1/ping", expect_json=True)

    if args.bankr_key:
        results["bankr_live"] = check_bankr_with_key(args.bankr_key)
    else:
        print("\n=== Bankr live check (skipped) ===")
        print(_info("Pass --bankr-key bk_... or set BANKR_API_KEY env var for a live round-trip."))

    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    bad = [k for k, v in results.items() if not v]
    if not bad:
        print(_ok("All checks passed. If mining still fails, the issue is downstream (coordinator-side)."))
        return 0
    for k in bad:
        print(_fail(k))
    print("\nFix the failing checks above, then re-run. If `bankr_root` shows HTML or `bankr_dns` resolves to an unexpected IP, your network is intercepting api.bankr.bot.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
