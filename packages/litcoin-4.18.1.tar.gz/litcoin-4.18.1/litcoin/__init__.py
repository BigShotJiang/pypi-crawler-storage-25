"""
LITCOIN SDK -- Full protocol access for AI agents on Base.

    from litcoin import Agent

    agent = Agent(
        bankr_key="bk_YOUR_KEY",
        ai_key="sk-or-YOUR_KEY",
        ai_url="https://openrouter.ai/api/v1",
        model="google/gemini-2.5-flash",
    )

    # Comprehension mining + relay
    agent.mine(rounds=5)

    # Research mining -- autonomous experiments
    agent.research_mine(task_type="code_optimization")
    agent.research_loop(task_type="algorithm", rounds=10)

    # Check rewards
    agent.claim()

Every verified submission is auto-anchored every 5 minutes to a
public, content-addressed git repo on GitLawb for independent
provenance verification:

    https://gitlawb.com/z6MkqVdSfQ9mhTtRJNXkqbXZ2PYW53qSi6Lw35aGdzfv65UC/litcoin-submissions

The public archive holds verification metadata only (submission id,
wallet, model, content hash, quality score, reward in $LITCOIN). Raw
miner code and full AI responses stay private. No SDK call is needed
to benefit from the anchor; the coordinator handles it automatically.
"""

__version__ = "4.18.1"

# Force UTF-8 stdout/stderr on Windows so log output containing
# unicode (LLM-generated text, RuneScape item names, vault item
# attributes, etc.) doesn't blow up with `'charmap' codec can't
# encode characters`. Python 3.7+ supports stream.reconfigure().
# errors='replace' so we degrade gracefully instead of crashing if
# something exotic still slips through.
import sys as _sys
for _stream in (_sys.stdout, _sys.stderr):
    try:
        if hasattr(_stream, "reconfigure"):
            _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from litcoin.agent import Agent
from litcoin.api import CoordinatorAPI
from litcoin.auth import BankrAuth
from litcoin.researcher import Researcher

__all__ = ["Agent", "CoordinatorAPI", "BankrAuth", "Researcher", "__version__"]
