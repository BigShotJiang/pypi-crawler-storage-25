"""
Researcher — Autonomous research mining for LITCOIN.

    from litcoin import Agent

    agent = Agent(bankr_key="bk_...", ai_key="sk-...", ai_url="https://...")

    # Single research cycle
    result = agent.research_mine(task_type="code_optimization")

    # Autonomous loop
    agent.research_loop(task_type="code_optimization", rounds=10)
"""

import time
import json
import logging
import subprocess
import sys
import tempfile
import os
from urllib.request import Request, urlopen

from litcoin.api import CoordinatorAPI, APIError

log = logging.getLogger("litcoin")

MAX_LOCAL_RUNTIME = 120  # seconds

# ─── Security: blocked patterns in LLM-generated code ──────────────────────
# Mirrors coordinator server-side sanitization (research.js sanitizeCode).
#
# Two pattern types:
#   _BLOCKED_IMPORT_MODULES: exact import-statement matches via regex.
#     Catches "import X", "import X as Y", "from X import ...",
#     "from X.subpackage import ..." but NOT inside docstrings, comments,
#     or string literals. Older substring approach matched "pathlib" inside
#     any identifier or comment, false-rejecting otherwise-fine code.
#   _BLOCKED_SUBSTRINGS: substring matches against lowercased code. For
#     dangerous attribute access patterns where the import alone might be
#     legitimate (sys.stdin OK but sys.path NOT OK).
#
# `sys` and `io` removed from imports (sys.stdin and io.StringIO are
# legitimate codeforces idioms; the LLM prompt explicitly recommends them).
# Their dangerous attributes are caught by the substring list below.
import re as _re

_BLOCKED_IMPORT_MODULES = [
    "os", "subprocess", "shutil", "socket", "http", "urllib",
    "requests", "ctypes", "signal", "pathlib", "importlib",
    "tempfile", "glob", "fnmatch", "webbrowser", "ftplib",
    "smtplib", "xmlrpc", "multiprocessing", "threading", "asyncio",
]
_IMPORT_RE = _re.compile(
    r"\b(?:import\s+(" + "|".join(_BLOCKED_IMPORT_MODULES) + r")"
    r"|from\s+(" + "|".join(_BLOCKED_IMPORT_MODULES) + r")(?:\.[\w.]+)?\s+import)\b"
)

_BLOCKED_SUBSTRINGS = [
    "os.system", "os.popen", "os.environ", "os.getenv",
    "subprocess.", "exec(", "eval(", "__import__", "open(",
    # `compile(` removed 2026-05-06: it was over-broad, false-positive
    # rejecting `re.compile(...)` and `ast.compile(...)` which are
    # legitimate idioms (regex compilation is extremely common). The
    # only attack path through `compile()` is to pass the resulting
    # code object to `exec()` or `eval()`, both of which are still
    # blocked. Defense-in-depth via the server-side sandbox is the
    # real isolation layer regardless of this list.
    "getattr(", "setattr(", "delattr(",
    "globals(", "locals(", "breakpoint(",
    # sys allowed for stdin/stdout/argv/exit; these are escape vectors
    "sys.path", "sys.modules",
    # io allowed for StringIO/BytesIO; io.open is just open() under
    # another name and bypasses the open( substring above
    "io.open",
]

# Sources where the substring blocks above are too aggressive. SWE-bench
# tasks involve real Django / matplotlib / scikit-learn codebases whose
# legit patches sometimes include exec(), open(), or attribute reflection.
# LiveCodeBench solutions occasionally need open() for file-IO problems.
# For these sources we trust the server-side Docker sandbox (no network,
# no env, /tmp-only filesystem) to contain whatever the miner submits;
# the local substring check is just a heuristic, not the actual isolation.
# Module-level imports (subprocess, socket, requests, etc.) stay blocked.
_SOURCE_RELAXED = frozenset([
    "swe-bench",
    "livecodebench",
])

# Kept as `BLOCKED_PATTERNS` for backwards-compat with any downstream
# callers that import the symbol directly. Not used by sanitize_code
# anymore; read it as documentation only.
BLOCKED_PATTERNS = _BLOCKED_SUBSTRINGS + [
    f"import {m}" for m in _BLOCKED_IMPORT_MODULES
] + [
    f"from {m} " for m in _BLOCKED_IMPORT_MODULES
]

_SECURITY_WARNING_SHOWN = False


def _show_security_warning():
    """Show one-time security warning about local code execution."""
    global _SECURITY_WARNING_SHOWN
    if _SECURITY_WARNING_SHOWN:
        return
    _SECURITY_WARNING_SHOWN = True
    log.warning("=" * 60)
    log.warning("SECURITY NOTICE: Research mining generates and executes")
    log.warning("Python code locally via LLM. Code is sanitized to block")
    log.warning("dangerous imports (os, subprocess, socket, etc.) but")
    log.warning("runs in a subprocess with limited isolation.")
    log.warning("Review: https://litcoin.app/docs#security")
    log.warning("=" * 60)


# ─── Single source of truth for sanitize rules ──────────────────────────────
#
# Rules live at litcoin-coordinator/data/sanitize-rules.json. Both the
# coordinator and this SDK read the same file. The SDK fetches via
# GET /v1/research/sanitize-rules on first sanitize_code() call and caches
# in memory for the rest of the process. This eliminates the drift we used
# to have where `getattr(` was unblocked on the server but still blocked in
# the SDK (or vice versa) — every relax now propagates without an SDK release.
#
# Falls back to the baked-in lists above if the fetch fails (offline, 404,
# malformed JSON, > 5s timeout). Fail-safe: if anything goes wrong we keep
# the existing strict behavior.
_SANITIZE_RULES_CACHE = None
_LITCOIN_API_URL = os.environ.get("LITCOIN_API_URL", "https://api.litcoin.app")

def _get_active_rules():
    """Return the active sanitize rule set as a dict.

    Tries to fetch the latest rules from the coordinator on first call.
    On any failure, returns the baked-in module-level defaults.
    Cached module-level after first call (success or failure).
    """
    global _SANITIZE_RULES_CACHE
    if _SANITIZE_RULES_CACHE is not None:
        return _SANITIZE_RULES_CACHE
    try:
        url = f"{_LITCOIN_API_URL}/v1/research/sanitize-rules"
        req = Request(url, headers={"User-Agent": "litcoin-sdk"})
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if (isinstance(data.get("blocked_modules"), list)
                and isinstance(data.get("blocked_substrings"), list)
                and isinstance(data.get("relaxed_sources"), list)):
            _SANITIZE_RULES_CACHE = {
                "import_modules": [str(m).lower() for m in data["blocked_modules"]],
                "substrings": [str(s).lower() for s in data["blocked_substrings"]],
                "relaxed_sources": frozenset(str(s).lower() for s in data["relaxed_sources"]),
                "source": "coordinator",
                "version": data.get("version"),
            }
            log.debug(f"sanitize rules v{data.get('version')} loaded from coordinator")
            return _SANITIZE_RULES_CACHE
    except Exception as e:
        log.debug(f"sanitize rules fetch failed ({e}); using baked-in defaults")
    # Fallback to baked-in lists
    _SANITIZE_RULES_CACHE = {
        "import_modules": list(_BLOCKED_IMPORT_MODULES),
        "substrings": list(_BLOCKED_SUBSTRINGS),
        "relaxed_sources": _SOURCE_RELAXED,
        "source": "baked-in",
        "version": None,
    }
    return _SANITIZE_RULES_CACHE


def sanitize_code(code, source=None):
    """
    Check generated code for dangerous patterns.
    Returns (safe: bool, reason: str or None).
    Mirrors coordinator-side sanitizeCode() in research.js (same rules file).

    When `source` is in the relaxed-sources set (swe-bench, livecodebench by
    default), the substring block list is skipped — those adapters
    legitimately need constructs like `exec()` / `open()` for real-codebase
    patches, and the server-side sandbox is the real isolation layer. Module
    imports are still enforced even on relaxed sources.
    """
    rules = _get_active_rules()
    # Build the import regex from the active list (rules can change per
    # release without recompiling at module load).
    import_re = _re.compile(
        r"\b(?:import\s+(" + "|".join(rules["import_modules"]) + r")"
        r"|from\s+(" + "|".join(rules["import_modules"]) + r")(?:\.[\w.]+)?\s+import)\b"
    )
    m = import_re.search(code)
    if m:
        mod = m.group(1) or m.group(2)
        return False, f"Blocked module: {mod}"
    # Skip the substring block for real-codebase sources where exec /
    # open / etc. are part of legit patches.
    src_norm = (source or "").strip().lower()
    if src_norm in rules["relaxed_sources"]:
        return True, None
    # Substring match against lowercased code for attribute access patterns.
    lower = code.lower()
    for s in rules["substrings"]:
        if s in lower:
            return False, f"Blocked pattern: {s}"
    return True, None


def extract_reasoning(raw_response):
    """
    Extract reasoning trace from LLM response.
    Handles <think> tags (DeepSeek-R1, QwQ), prose before code blocks, etc.
    Returns (reasoning: str or None, remaining_content: str).
    """
    import re

    reasoning = None
    content = raw_response

    # DeepSeek-R1 / QwQ style: <think>...</think>
    think_match = re.search(r'<think>(.*?)</think>', raw_response, re.DOTALL)
    if think_match:
        reasoning = think_match.group(1).strip()
        content = raw_response[think_match.end():].strip()
        return reasoning[:50000] if reasoning else None, content

    # Prose before code block (at least 50 chars of thinking before ```)
    if '```' in raw_response:
        idx = raw_response.index('```')
        before = raw_response[:idx].strip()
        if len(before) > 50:
            reasoning = before
            content = raw_response[idx:]

    return (reasoning[:50000] if reasoning else None), content


class Researcher:
    """
    Handles the research mining loop:
    1. Fetch a task from the coordinator
    2. Use LLM to generate/iterate on experiment code
    3. Run experiment locally (sandboxed)
    4. Submit result if it improves on baseline
    """

    def __init__(self, api, wallet, ai_config=None, auth=None):
        """
        Args:
            api: CoordinatorAPI instance
            wallet: Miner wallet address
            ai_config: dict with keys: key, url, model, anthropic_mode
            auth: AuthSession instance (optional, for authenticated submissions)
        """
        self.api = api
        self.wallet = wallet
        self.ai = ai_config or {}
        self.auth = auth
        self._history = {}  # taskId -> list of (code, metric) attempts
        self._primary_successes = 0  # Track successful primary AI calls — relay failover only activates after ≥1 success
        # Resolved model from the most recent _call_llm / _call_relay response.
        # Forwarded as `actual_model` on submission so the coordinator can show
        # the real underlying model on the benchmark (e.g. when ai_config.model
        # is "openrouter/auto" or "openrouter/free", the upstream API returns
        # the actually-used model — "deepseek/deepseek-chat-v3:free" or whatever
        # OpenRouter routed to — and we forward that). See litcoin-coordinator
        # research.js submit handler for the receiving side (added 2026-04-29).
        self._last_actual_model = None

    def list_tasks(self, task_type=None):
        """List available research tasks."""
        return self.api.research_list_tasks(task_type)

    def get_task(self, task_id):
        """Get full task details."""
        return self.api.research_get_task(task_id)

    def fetch_task(self, task_type=None):
        """Fetch a random task for mining."""
        return self.api.research_fetch_task(task_type, self.wallet)

    def submit(self, task_id, code, reasoning=None):
        """Submit code to coordinator for verification.

        Forwards the resolved model name from the most recent LLM call (when
        available) as `actual_model`. The upstream API returns the actually-
        used model in its response body — for OpenRouter's "auto" or ":free"
        routing, that's the real underlying model that ran the inference. The
        coordinator prefers `actual_model` over the configured `model` so the
        benchmark surfaces accurate per-model attribution.
        """
        model = self.ai.get("model")
        provider = self.ai.get("url", "").split("//")[-1].split("/")[0] if self.ai.get("url") else None
        token = self.auth.token if self.auth else None
        return self.api.research_submit(
            task_id, self.wallet, code,
            model=model,
            model_provider=provider,
            reasoning=reasoning,
            auth_token=token,
            actual_model=self._last_actual_model,
        )

    def leaderboard(self, task_id=None):
        """Get research leaderboard."""
        return self.api.research_leaderboard(task_id)

    def stats(self):
        """Get global research stats."""
        return self.api.research_stats()

    def results(self, task_id=None, limit=20):
        """Get verified research results (discoveries)."""
        return self.api.research_results(task_id=task_id, miner=self.wallet, limit=limit)

    # ─── Local Experiment Runner ──────────────────────────────────────────

    def run_locally(self, code, test_code, entry_function, timeout=MAX_LOCAL_RUNTIME, task_source=None):
        """
        Run experiment code locally in a sandboxed subprocess.

        Security measures:
        - Code is sanitized against dangerous imports (os, subprocess, socket, etc.)
        - Subprocess runs with minimal environment variables (no HOME, no shell config)
        - Working directory is a temp folder (no access to user files)
        - Timeout enforced to prevent infinite loops
        - Temp script file is deleted after execution

        Returns dict with: success, metric_name, metric_value, stdout, stderr, error.
        When the task ships no local test_code (red-team, knowledge-synthesis,
        security-audit, exploit-forensics, adversarial-robustness, agentic-trace,
        synthetic-data, tcg-card-profile, tcg-sentiment, variant-pathogenicity,
        etc), returns success=True with skipped=True so the caller submits
        unconditionally and lets the coordinator's sandbox + judge verify.
        """
        # No local harness: skip execution and tell the caller to submit
        # unconditionally for server-side verification. Without this guard,
        # the f-string harness still wraps the user code in a near-empty
        # try block and the downstream baseline comparison crashes on None
        # metrics, dropping the submission entirely.
        if not test_code or not test_code.strip():
            return {
                "success": True,
                "skipped": True,
                "metric_name": "server-verified",
                "metric_value": None,
                "stdout": "",
                "stderr": "",
            }

        # ── Security: sanitize LLM-generated code before execution ──
        # We only sanitize the LLM-generated `code`. We deliberately do NOT
        # sanitize `test_code` — that's the task harness shipped by the
        # protocol via authenticated API. Sanitizing it locally was a
        # foot-gun: SWE-bench / matplotlib / Django test runners legitimately
        # contain `exec(`, `getattr(`, etc. and were getting false-rejected
        # in the SDK before the submission ever reached the coordinator.
        # The actual isolation layer is the server-side Docker sandbox
        # (no network, no env, /tmp-only filesystem, --network=none).
        # Removed 2026-05-08 in 4.14.10 to fix Hatcho's SWE-bench rejection.
        safe, reason = sanitize_code(code, source=task_source)
        if not safe:
            return {"success": False, "error": f"Code rejected (security): {reason}"}

        full_script = f"""{code}

# ─── Test harness ───
try:
{chr(10).join('    ' + line for line in test_code.strip().split(chr(10)))}
    print("VERIFY:PASS")
except AssertionError as e:
    print(f"VERIFY:FAIL:{{e}}")
except Exception as e:
    print(f"VERIFY:ERROR:{{e}}")
"""

        # encoding="utf-8" added 2026-05-06: this was the actual root
        # cause of Hatcho's `'charmap' codec can't encode characters`
        # rounds. tempfile.NamedTemporaryFile(mode='w') uses
        # locale.getpreferredencoding(), which is cp1252 on Windows.
        # The full_script contains literal U+2500 box-drawing chars
        # in our own harness (`─── Test harness ───`) AND can contain
        # unicode in LLM-generated code (em-dashes in comments,
        # smart quotes, accented chars in docstrings). Either path
        # crashed the write on cp1252. Forcing UTF-8 fixes both.
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='.py', delete=False, encoding='utf-8',
        ) as f:
            f.write(full_script)
            script_path = f.name

        try:
            # ── Restricted environment: minimal PATH, no HOME/USER/SHELL ──
            # PYTHONIOENCODING + encoding="utf-8" added 2026-05-06: on
            # Windows, the default stdout encoding is `cp1252` (charmap),
            # which can't encode emojis or some unicode characters that
            # appear in LLM-generated output and in task descriptions
            # (RuneScape item names, AI reasoning traces, etc.). Without
            # this, Hatcho and other Windows users hit:
            #   'charmap' codec can't encode characters in position N
            # mid-round, killing the round. Forcing UTF-8 on both child
            # and parent fixes it.
            safe_env = {
                "PATH": os.path.dirname(sys.executable),
                "PYTHONPATH": "",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONIOENCODING": "utf-8",
                "TMPDIR": tempfile.gettempdir(),
                "LANG": "en_US.UTF-8",
            }

            result = subprocess.run(
                [sys.executable, "-I", script_path],  # -I = isolated mode (no user site-packages, no PYTHON* env vars)
                capture_output=True, text=True,
                encoding="utf-8", errors="replace",
                timeout=timeout,
                cwd=tempfile.gettempdir(),
                env=safe_env,
            )

            stdout = result.stdout
            stderr = result.stderr

            if result.returncode != 0:
                # 2026-05-12: same ModuleNotFoundError carve-out as the
                # VERIFY:FAIL / VERIFY:ERROR paths below. The harness can
                # crash at module-import time before any VERIFY:* line
                # gets printed (e.g. test body has top-level `import
                # matplotlib`, raises before the outer try/except runs).
                # Skip locally so the submission reaches the coordinator
                # sandbox which has the full package set.
                if "No module named" in stderr or "ModuleNotFoundError" in stderr:
                    log.info(f"[research] Local harness hit ModuleNotFoundError at import time. Submitting for server-side verification.")
                    return {
                        "success": True,
                        "skipped": True,
                        "metric_name": "server-verified",
                        "metric_value": None,
                        "stdout": stdout[:1000],
                        "stderr": stderr[:500],
                    }
                return {
                    "success": False,
                    "error": f"Exit code {result.returncode}: {stderr[:500]}",
                    "stdout": stdout[:1000],
                    "stderr": stderr[:1000],
                }

            if "VERIFY:FAIL" in stdout:
                fail_msg = ""
                for line in stdout.split("\n"):
                    if "VERIFY:FAIL" in line:
                        fail_msg = line.split("VERIFY:FAIL:")[-1]
                # 2026-05-12: ModuleNotFoundError in the local harness is
                # almost always a sandbox/SDK environment artifact, not a
                # real miner-quality signal. SDK runs the harness with
                # `python -I` (isolated mode) which strips user
                # site-packages, so pip-installed libs like django,
                # matplotlib, scikit are invisible even when the user has
                # them on the host. Server-side sandbox has the full
                # package set. Treat as skipped so the submission still
                # reaches the coordinator for real verification instead
                # of being dropped locally.
                if "No module named" in fail_msg or "ModuleNotFoundError" in fail_msg:
                    log.info(f"[research] Local harness hit ModuleNotFoundError ({fail_msg[:120]}). Submitting for server-side verification.")
                    return {
                        "success": True,
                        "skipped": True,
                        "metric_name": "server-verified",
                        "metric_value": None,
                        "stdout": stdout[:1000],
                        "stderr": stderr[:500],
                    }
                return {"success": False, "error": f"Correctness failed: {fail_msg}"}

            if "VERIFY:ERROR" in stdout:
                err_msg = ""
                for line in stdout.split("\n"):
                    if "VERIFY:ERROR" in line:
                        err_msg = line.split("VERIFY:ERROR:")[-1]
                if "No module named" in err_msg or "ModuleNotFoundError" in err_msg:
                    log.info(f"[research] Local harness hit ModuleNotFoundError ({err_msg[:120]}). Submitting for server-side verification.")
                    return {
                        "success": True,
                        "skipped": True,
                        "metric_name": "server-verified",
                        "metric_value": None,
                        "stdout": stdout[:1000],
                        "stderr": stderr[:500],
                    }
                return {"success": False, "error": f"Runtime error: {err_msg}"}

            if "VERIFY:PASS" not in stdout:
                return {"success": False, "error": "Verification did not pass"}

            # Extract metric. Accepts three formats so harness inconsistency
            # across adapters doesn't reject valid submissions:
            #   1. "METRIC:name:value"          (strict, original)
            #   2. "METRIC: name = value"       (CC adapter pre-2026-05-16)
            #   3. "METRIC: name value"         (loose fallback)
            # Whatever the format, we find the LAST float on the line and
            # use that as metric_value. Identifier-style token (or "name")
            # is treated as metric_name. Added 2026-05-16 after Hatcho's
            # CC tasks rejected for "No metric reported" despite passing.
            import re as _re
            metric_name = None
            metric_value = None
            for line in stdout.split("\n"):
                if not line.startswith("METRIC"):
                    continue
                # Find all floats on the line; last one is the metric value.
                nums = _re.findall(r"-?\d+\.?\d*(?:[eE][+-]?\d+)?", line)
                if not nums:
                    continue
                try:
                    metric_value = float(nums[-1])
                except ValueError:
                    continue
                # Extract metric_name: first identifier-like token after METRIC
                m = _re.search(r"METRIC[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)", line)
                metric_name = m.group(1) if m else "metric"
                break

            if metric_value is None:
                return {"success": False, "error": "No metric reported"}

            return {
                "success": True,
                "metric_name": metric_name,
                "metric_value": metric_value,
                "stdout": stdout[:2000],
            }

        except subprocess.TimeoutExpired:
            return {"success": False, "error": f"Timeout ({timeout}s)"}
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            try:
                os.unlink(script_path)
            except:
                pass

    # ─── LLM Code Generation ─────────────────────────────────────────────

    def _call_llm(self, prompt, max_tokens=4096):
        """Call the miner's LLM to generate experiment code. Auto-failover to LITCOIN relay on billing errors."""
        if not self.ai.get("key"):
            raise RuntimeError("AI key required for research mining. Set ai_key when creating Agent.")

        import requests

        headers = {"Content-Type": "application/json"}
        url = self.ai["url"]
        model = self.ai.get("model", "gpt-4o-mini")

        if self.ai.get("anthropic_mode"):
            headers["x-api-key"] = self.ai["key"]
            headers["anthropic-version"] = "2023-06-01"
            payload = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            }
        else:
            headers["Authorization"] = f"Bearer {self.ai['key']}"
            payload = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7,
            }

        try:
            r = requests.post(
                url if "/v1/" in url else f"{url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=120,
            )

            # ── Relay failover on billing/rate errors ──
            # ABUSE PREVENTION: Only failover if primary key has worked at least once.
            # This prevents bots with fake keys from freeloading off the relay network.
            can_failover = self.ai.get("relay_failover", True) and self._primary_successes > 0
            if r.status_code in (402, 429, 403) and can_failover:
                log.warning(f"[research] AI provider returned {r.status_code} — failing over to LITCOIN relay (key worked {self._primary_successes}x before)...")
                return self._call_relay(prompt, model, max_tokens, requests)
            elif r.status_code in (402, 429, 403) and self._primary_successes == 0:
                log.error(f"[research] AI provider returned {r.status_code} — relay failover not available (primary key has never succeeded). Check your API key and credits.")

            r.raise_for_status()
            data = r.json()

            if self.ai.get("anthropic_mode"):
                text = data["content"][0]["text"]
            else:
                text = data["choices"][0]["message"]["content"]

            # Capture the resolved model name from the response. OpenRouter
            # returns the actually-routed model here even when the request
            # used "auto" or a ":free" tag; OpenAI returns the dated variant
            # (e.g. "gpt-5-2025-..."); Anthropic returns the canonical model
            # id. Forwarded as actual_model on submit so the benchmark shows
            # the real model rather than the user's configured label.
            resolved = data.get("model")
            if resolved:
                self._last_actual_model = str(resolved)

            # Track successful primary calls
            if text:
                self._primary_successes += 1

            return text

        except requests.exceptions.ConnectionError:
            can_failover = self.ai.get("relay_failover", True) and self._primary_successes > 0
            if can_failover:
                log.warning("[research] AI provider unreachable — failing over to LITCOIN relay...")
                return self._call_relay(prompt, model, max_tokens, requests)
            raise
        except requests.exceptions.HTTPError as e:
            can_failover = self.ai.get("relay_failover", True) and self._primary_successes > 0
            if e.response is not None and e.response.status_code in (402, 429, 403) and can_failover:
                log.warning(f"[research] AI provider billing error — failing over to LITCOIN relay...")
                return self._call_relay(prompt, model, max_tokens, requests)
            raise

    def _call_relay(self, prompt, model, max_tokens, requests):
        """Fallback: route LLM call through LITCOIN's compute relay network."""
        relay_url = f"{self.api.base_url}/v1/chat/completions"
        relay_headers = {"Content-Type": "application/json"}

        # Auth: use JWT if available, otherwise Bankr key
        if self.auth and self.auth.token:
            relay_headers["Authorization"] = f"Bearer {self.auth.token}"
        elif self.ai.get("key"):
            relay_headers["Authorization"] = f"Bearer {self.ai['key']}"

        relay_payload = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
        }

        try:
            r = requests.post(relay_url, headers=relay_headers, json=relay_payload, timeout=180)
            r.raise_for_status()
            data = r.json()
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            # Capture the resolved model from the relay response too. Relay
            # passes upstream's response.model through, so this is the real
            # model that served the request even after relay routing.
            resolved = data.get("model")
            if resolved:
                self._last_actual_model = str(resolved)
            if text:
                log.info(f"[research] Relay failover successful — {len(text)} chars")
            return text
        except Exception as e:
            log.error(f"[research] Relay failover also failed: {e}")
            raise RuntimeError(f"Both primary AI and LITCOIN relay failed. Primary error: billing/rate limit. Relay error: {e}")

    def _extract_code(self, llm_response):
        """Extract Python code from LLM response (handles markdown fences)."""
        # Try to find ```python ... ``` block
        if "```python" in llm_response:
            start = llm_response.index("```python") + 9
            end = llm_response.index("```", start)
            return llm_response[start:end].strip()
        elif "```" in llm_response:
            start = llm_response.index("```") + 3
            # Skip language identifier on first line
            if "\n" in llm_response[start:start+20]:
                start = llm_response.index("\n", start) + 1
            end = llm_response.index("```", start)
            return llm_response[start:end].strip()
        return llm_response.strip()

    def generate_solution(self, task, previous_attempts=None):
        """
        Use LLM to generate a solution for a research task.

        Args:
            task: Task dict from coordinator
            previous_attempts: List of (code, metric_value) tuples

        Returns:
            tuple: (code: str, reasoning: str or None)
        """
        prompt = f"""You are a research engineer competing in an optimization challenge.

TASK: {task['title']}
TYPE: {task['type']}
DESCRIPTION: {task['description']}

CONSTRAINTS:
- Language: {task['constraints']['language']}
- Entry function: `{task['constraints']['entry_function']}`
- Max runtime: {task['constraints']['max_runtime']} seconds

BASELINE:
- Metric: {task['baseline']['metric']}
- Baseline value: {task['baseline']['value']}
- Direction: {task['baseline']['direction']}
- Current best: {task.get('bestResult', {}).get('value', 'none yet') if task.get('bestResult') else 'none yet'}

"""

        if previous_attempts:
            prompt += "PREVIOUS ATTEMPTS (improve on these):\n"
            for i, (prev_code, prev_metric) in enumerate(previous_attempts[-3:]):
                prompt += f"\nAttempt {i+1} — metric: {prev_metric}\n```python\n{prev_code}\n```\n"
            prompt += "\nAnalyze what worked and what didn't. Try a fundamentally different approach.\n"
        else:
            prompt += "This is your first attempt. Write the best solution you can.\n"

        prompt += f"""
First, briefly explain your approach and reasoning in English (2-4 sentences).
Then write the Python function `{task['constraints']['entry_function']}` (and any helpers it needs) in a ```python block.
Do NOT include test code or imports of os, subprocess, socket, urllib, requests, or other network/filesystem modules.
You may use the standard library: math, collections, itertools, heapq, bisect, functools, re, string, decimal,
fractions, statistics, random, io.StringIO, sys.stdin/sys.argv (read-only), json.
Focus on correctness first, then optimization."""

        response = self._call_llm(prompt)
        reasoning, remaining = extract_reasoning(response)
        code = self._extract_code(remaining)

        # If no reasoning found yet, check for reasoning inside code (docstrings/comments)
        if not reasoning and code and len(code) > 50:
            import re
            ds_match = re.match(r'^(["\']{3})([\s\S]*?)\1\s*\n', code)
            if ds_match and len(ds_match.group(2).strip()) > 30:
                reasoning = ds_match.group(2).strip()[:50000]
                code = code[ds_match.end():].strip()
            if not reasoning:
                lines = code.split("\n")
                comment_lines = []
                for line in lines:
                    if line.strip().startswith("#") or line.strip() == "":
                        comment_lines.append(line.lstrip("# "))
                    else:
                        break
                comment_text = "\n".join(comment_lines).strip()
                if len(comment_text) > 50:
                    reasoning = comment_text[:50000]
                    code = "\n".join(lines[len(comment_lines):]).strip()

        return code, reasoning

    # ─── Research Mining Cycle ────────────────────────────────────────────

    def mine_once(self, task_type=None, task_id=None):
        """
        Run one research mining cycle:
        1. Fetch task
        2. Generate solution via LLM
        3. Test locally
        4. Submit if it beats baseline

        Returns dict with: task, code, local_result, submission (if submitted)
        """
        # Show one-time security warning about local code execution
        _show_security_warning()

        # 1. Get task
        if task_id:
            task = self.get_task(task_id)
        else:
            task = self.fetch_task(task_type)

        log.info(f"[research] Task: {task['title']} (baseline: {task['baseline']['value']})")

        # 2. Get previous attempts for this task
        prev = self._history.get(task["id"], [])

        # 3. Generate code
        code, reasoning = self.generate_solution(task, prev if prev else None)
        log.info(f"[research] Generated {len(code)} chars of code{f' + {len(reasoning)} chars reasoning' if reasoning else ''}")

        # 4. Test locally
        local = self.run_locally(
            code,
            task["constraints"].get("test_code", ""),
            task["constraints"]["entry_function"],
            timeout=task["constraints"].get("max_runtime", MAX_LOCAL_RUNTIME),
            task_source=task.get("source"),
        )

        result = {
            "task": {"id": task["id"], "title": task["title"]},
            "code": code,
            "reasoning": reasoning,
            "local_result": local,
            "submission": None,
        }

        if not local["success"]:
            log.warning(f"[research] Local test failed: {local['error']}")
            # Track failed attempt so LLM can learn from it
            self._history.setdefault(task["id"], []).append((code, None))
            return result

        metric = local["metric_value"]
        log.info(f"[research] Local metric: {local['metric_name']} = {metric}")

        # Track attempt
        self._history.setdefault(task["id"], []).append((code, metric))

        # 5. Check if it beats baseline before submitting.
        # Server-verified-only adapters (red-team, KS, security-audit,
        # exploit-forensics, adversarial-robustness, agentic-trace,
        # synthetic-data, tcg-*, variant-pathogenicity) have no local
        # harness and no local metric. Skip the baseline gate and submit
        # unconditionally; coordinator's sandbox + judge handle verification.
        if local.get("skipped"):
            log.info(f"[research] No local harness for this task type. Submitting for server-side verification.")
        else:
            baseline = task["baseline"]["value"]
            direction = task["baseline"]["direction"]
            beats = (metric < baseline) if direction == "lower_is_better" else (metric > baseline)

            if not beats:
                log.info(f"[research] Did not beat baseline ({baseline}), submitting for participation reward")

        # 6. Submit to coordinator for full verification
        if not local.get("skipped"):
            log.info(f"[research] Submitting (local metric {metric} vs baseline {task['baseline']['value']})")
        try:
            sub = self.submit(task["id"], code, reasoning=reasoning)
            result["submission"] = sub
            if sub.get("verified"):
                log.info(f"[research] Verified. {sub.get('message', '')}")
                if sub.get("isNewBest"):
                    log.info(f"[research] NEW RECORD")
            else:
                log.warning(f"[research] Verification failed: {sub.get('error', 'unknown')}")
        except Exception as e:
            log.error(f"[research] Submit error: {e}")
            # Always set submission to a structured error dict (never leave it
            # None). Caller-side loops commonly do `result["submission"].get(...)`,
            # which crashes with `'NoneType' object has no attribute 'get'` if
            # the submit raised before assignment. This guarantees the shape
            # callers expect, regardless of failure mode (Bankr API down,
            # coordinator timeout, network drop, auth failure, etc.).
            # 2026-05-20 fix triggered by Bankr API outage during their
            # wallet-compromise investigation, which made every bk_ key user's
            # SDK crash on the first round.
            result["submission"] = {
                "verified": False,
                "error": str(e),
                "reward": 0,
                "ok": False,
            }

        return result

    def mine_loop(self, task_type=None, task_id=None, rounds=10, delay=30):
        """
        Run autonomous research mining loop (Karpathy-style iteration).

        Sticks to ONE task and iterates on it. Each round builds on
        previous attempts' learnings. This is where real breakthroughs happen.

        Args:
            task_type: Filter by type (optional)
            task_id: Specific task to iterate on (recommended)
            rounds: Number of iterations (default 10)
            delay: Seconds between iterations (default 30)
        """
        log.info(f"[research] Starting research loop: {rounds} iterations, {'task ' + task_id if task_id else task_type or 'any'}")

        current_task_id = task_id

        for i in range(rounds):
            log.info(f"\n[research] ─── Iteration {i+1}/{rounds} ───")
            try:
                result = self.mine_once(task_type=task_type, task_id=current_task_id)

                # Lock onto this task for subsequent rounds
                if not current_task_id and result.get("task"):
                    current_task_id = result["task"]["id"]
                    log.info(f"[research] Locked onto: {result['task']['title']}")

                if result["submission"] and result["submission"].get("verified"):
                    reward = result["submission"].get("reward", 0)
                    streak = result["submission"].get("streak", 0)
                    pb = result["submission"].get("isPersonalBest", False)
                    nb = result["submission"].get("isNewBest", False)
                    iteration = result["submission"].get("iteration", i + 1)
                    zero_reason = result["submission"].get("zero_reason")
                    zero_explain = result["submission"].get("zero_explain")
                    if reward == 0 and zero_reason:
                        # Verified submission earned 0 LITCOIN. The coordinator
                        # tells us why via zero_reason. Surface it so miners
                        # understand whether to change their approach or move
                        # to a different task. Added 2026-05-15.
                        log.info(f"[research] [+0 LITCOIN — {zero_reason}] iteration #{iteration}")
                        if zero_explain:
                            log.info(f"[research]   why: {zero_explain}")
                    else:
                        marker = "[GLOBAL RECORD]" if nb else "[Personal best]" if pb else "[OK]"
                        log.info(f"[research] {marker} iteration #{iteration}, streak {streak}, +{reward:,} LITCOIN")
                elif result["local_result"]["success"]:
                    log.info(f"[research] Iteration {i+1}: metric={result['local_result']['metric_value']}")
                else:
                    log.info(f"[research] Iteration {i+1}: local test failed")

            except Exception as e:
                log.error(f"[research] Iteration {i+1} error: {e}")

            if i < rounds - 1:
                time.sleep(delay)

        log.info(f"[research] Loop complete. {rounds} iterations on {'task ' + current_task_id if current_task_id else 'various tasks'}.")
