# Copyright (c) 2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
import unittest
import tempfile
import shutil
import os
import json
from unittest.mock import patch

import lbkit.skill.manager as mgr
import lbkit.skill.constants as const


class TestSkillSync(unittest.TestCase):
    """测试技能同步逻辑"""

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp(prefix="skill_test_")
        self.repo_dir = os.path.join(self.tmp_dir, "repo")
        self.skills_dir = os.path.join(self.tmp_dir, "skills")
        self.manifest_path = os.path.join(self.tmp_dir, "manifest.json")
        # 保存原始常量
        self._old_cache = const.AGENTS_CACHE_DIR
        self._old_base = const.SKILLS_BASE_DIR
        self._old_manifest = const.SYNC_MANIFEST_PATH
        # 指向测试目录
        const.AGENTS_CACHE_DIR = self.repo_dir
        const.SKILLS_BASE_DIR = self.skills_dir
        const.SYNC_MANIFEST_PATH = self.manifest_path
        # 同步更新 manager 中已导入的引用
        mgr.AGENTS_CACHE_DIR = self.repo_dir
        mgr.SKILLS_BASE_DIR = self.skills_dir
        mgr.SYNC_MANIFEST_PATH = self.manifest_path

    def tearDown(self):
        const.AGENTS_CACHE_DIR = self._old_cache
        const.SKILLS_BASE_DIR = self._old_base
        const.SYNC_MANIFEST_PATH = self._old_manifest
        mgr.AGENTS_CACHE_DIR = self._old_cache
        mgr.SKILLS_BASE_DIR = self._old_base
        mgr.SYNC_MANIFEST_PATH = self._old_manifest
        shutil.rmtree(self.tmp_dir)

    def _create_repo_skills(self, names):
        """在 repo 的 skills/ 子目录下创建技能目录"""
        repo_skills = os.path.join(self.repo_dir, "skills")
        os.makedirs(repo_skills, exist_ok=True)
        # 创建 .git 目录以模拟已克隆仓库
        os.makedirs(os.path.join(self.repo_dir, ".git"), exist_ok=True)
        for name in names:
            skill_dir = os.path.join(repo_skills, name)
            os.makedirs(skill_dir, exist_ok=True)
            with open(os.path.join(skill_dir, "SKILL.md"), "w") as fp:
                fp.write(f"# {name}\n")
        return repo_skills

    def _read_manifest(self):
        """读取同步后生成的 manifest"""
        with open(self.manifest_path, "r", encoding="utf-8") as fp:
            return json.load(fp)

    @patch("lbkit.skill.manager.git.Repo")
    def test_sync_copies_skills(self, mock_repo_cls):
        """同步时应复制仓库中所有技能到用户目录"""
        self._create_repo_skills(["skill-a", "skill-b"])
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None

        mgr.sync()

        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-a")))
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-b")))

    @patch("lbkit.skill.manager.git.Repo")
    def test_sync_empty_repo(self, mock_repo_cls):
        """仓库无 skills/ 目录时应正常退出"""
        os.makedirs(os.path.join(self.repo_dir, ".git"), exist_ok=True)
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None

        mgr.sync()
        self.assertFalse(os.path.isdir(self.skills_dir))

    @patch("lbkit.skill.manager.git.Repo")
    def test_sync_replaces_previous_synced(self, mock_repo_cls):
        """同步时应替换上次同步安装的技能"""
        # 第一次同步：安装 skill-old
        self._create_repo_skills(["skill-old"])
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None
        mgr.sync()
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-old")))

        # 模拟用户自行安装的技能
        os.makedirs(os.path.join(self.skills_dir, "user-skill"), exist_ok=True)

        # 第二次同步：仓库更新为 skill-new
        repo_skills = os.path.join(self.repo_dir, "skills")
        shutil.rmtree(os.path.join(repo_skills, "skill-old"))
        os.makedirs(os.path.join(repo_skills, "skill-new"), exist_ok=True)
        with open(os.path.join(repo_skills, "skill-new", "SKILL.md"), "w") as fp:
            fp.write("# skill-new\n")
        mgr.sync()

        # 旧同步技能应被移除
        self.assertFalse(os.path.isdir(os.path.join(self.skills_dir, "skill-old")))
        # 新同步技能应存在
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-new")))
        # 用户自行安装的技能应保留
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "user-skill")))

    @patch("lbkit.skill.manager.git.Repo")
    def test_sync_preserves_user_skills(self, mock_repo_cls):
        """同步时不应删除用户自行安装的技能"""
        # 预先创建用户技能
        os.makedirs(os.path.join(self.skills_dir, "my-custom-skill"), exist_ok=True)
        with open(os.path.join(self.skills_dir, "my-custom-skill", "SKILL.md"), "w") as fp:
            fp.write("# my-custom-skill\n")

        self._create_repo_skills(["skill-a"])
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None

        mgr.sync()

        # 用户技能应保留
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "my-custom-skill")))
        # 同步技能应存在
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-a")))

    @patch("lbkit.skill.manager.git.Repo")
    def test_sync_writes_manifest(self, mock_repo_cls):
        """同步后应写入 manifest 文件"""
        self._create_repo_skills(["skill-a", "skill-b"])
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None

        mgr.sync()

        manifest = self._read_manifest()
        # manifest 应以目标目录路径为 key
        self.assertIn(self.skills_dir, manifest)
        self.assertEqual(sorted(manifest[self.skills_dir]), ["skill-a", "skill-b"])

    @patch("lbkit.skill.manager.git.Repo")
    def test_corrupted_manifest_handled(self, mock_repo_cls):
        """manifest 文件损坏时应视为空 manifest"""
        os.makedirs(os.path.dirname(self.manifest_path), exist_ok=True)
        with open(self.manifest_path, "w") as fp:
            fp.write("not valid json{{{")

        # 同时模拟旧技能（如果存在损坏 manifest 中的旧记录，无法清理）
        os.makedirs(os.path.join(self.skills_dir, "stale-skill"), exist_ok=True)

        self._create_repo_skills(["skill-a"])
        mock_repo_cls.return_value = mock_repo_cls
        mock_repo_cls.remotes.origin.pull.return_value = None

        mgr.sync()

        # 新技能应正常安装
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "skill-a")))
        # 无法识别的旧技能残留不会被删除（因为没有有效 manifest）
        self.assertTrue(os.path.isdir(os.path.join(self.skills_dir, "stale-skill")))


if __name__ == "__main__":
    unittest.main()
