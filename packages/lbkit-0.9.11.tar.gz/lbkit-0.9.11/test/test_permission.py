# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
import os
import tempfile
import unittest
from unittest.mock import MagicMock, call, patch

from lbkit import errors
from lbkit.tasks.task_build_rootfs import TaskClass


def _make_task():
    """创建一个跳过 __init__ 的 TaskClass 实例"""
    task = object.__new__(TaskClass)
    task.log = MagicMock()
    task.exec = MagicMock()
    task.pipe = MagicMock()
    task.config = MagicMock()
    return task


def _write_perm(tmpdir, lines):
    """在 tmpdir 下创建 permissions 文件并返回路径"""
    path = os.path.join(tmpdir, "permissions")
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return path


class TestDoPermissionBasic(unittest.TestCase):
    """基础格式校验测试"""

    def test_file_not_exist(self):
        """permissions 文件不存在时应直接返回"""
        task = _make_task()
        task.do_permission("/nonexistent/permissions")
        task.exec.assert_not_called()

    def test_comment_and_empty_line(self):
        """注释行和空行应被跳过"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, [
                "# this is a comment",
                "",
                "   ",
            ])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_not_called()

    def test_fields_too_few(self):
        """字段少于 5 个应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f 555 0"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)

    def test_path_not_absolute(self):
        """路径不以 / 开头应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["lib/libfoo.so f 555 0 0 - - - - -"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)

    def test_invalid_mode(self):
        """mode 字段不合法应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f abc 0 0 - - - - -"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)

    def test_invalid_uid(self):
        """uid 字段不合法应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f 555 abc 0 - - - - -"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)

    def test_invalid_gid(self):
        """gid 字段不合法应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f 555 0 abc - - - - -"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)

    def test_invalid_type(self):
        """type 字段不合法应抛出 PermissionFormatError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so x 555 0 0 - - - - -"])
            task = _make_task()
            with self.assertRaises(errors.PermissionFormatError):
                task.do_permission(per)


class TestDoPermissionFileDir(unittest.TestCase):
    """f/d/s/r 类型赋权测试"""

    def test_file_permission(self):
        """普通文件类型 f 应执行 chmod + chown"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f 644 0 0 - - - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("chmod 644 usr/lib/libfoo.so"),
                call("chown 0:0 usr/lib/libfoo.so"),
            ])

    def test_file_permission_dash_mode(self):
        """mode 为 - 时跳过 chmod"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f - 0 0 - - - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_called_once_with("chown 0:0 usr/lib/libfoo.so")

    def test_file_permission_dash_uid_gid(self):
        """uid/gid 为 - 时跳过 chown"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr/lib/libfoo.so f 644 - - - - - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_called_once_with("chmod 644 usr/lib/libfoo.so")

    def test_directory_permission(self):
        """目录类型 d 应执行 chmod + chown"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/usr d 755 0 0 - - - - -"])
            task = _make_task()
            with patch("os.path.isdir", return_value=True):
                task.do_permission(per)
            task.exec.assert_has_calls([
                call("chmod 755 usr"),
                call("chown 0:0 usr"),
            ])

    def test_directory_not_exist(self):
        """目录不存在时应打 error 日志但仍赋权"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/nonexistent d 755 0 0 - - - - -"])
            task = _make_task()
            with patch("os.path.isdir", return_value=False):
                task.do_permission(per)
            task.log.error.assert_called()
            task.exec.assert_has_calls([
                call("chmod 755 nonexistent"),
                call("chown 0:0 nonexistent"),
            ])

    def test_recursive_permission(self):
        """类型 r 应对目录下所有文件递归赋权"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # 创建测试文件
            os.makedirs(os.path.join(tmpdir, "mydir"))
            open(os.path.join(tmpdir, "mydir", "a.txt"), "w").close()
            open(os.path.join(tmpdir, "mydir", "b.txt"), "w").close()
            per = _write_perm(tmpdir, ["/mydir r 755 0 0 - - - - -"])
            task = _make_task()
            orig_cwd = os.getcwd()
            os.chdir(tmpdir)
            try:
                task.do_permission(per)
            finally:
                os.chdir(orig_cwd)
            # 应对 a.txt 和 b.txt 各执行 chmod + chown
            self.assertEqual(task.exec.call_count, 4)


class TestDoPermissionDevice(unittest.TestCase):
    """c/b/p 设备文件创建测试"""

    def test_char_device_create(self):
        """字符设备 c 应使用 mknod 创建"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/console c 666 0 0 5 1 - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("mknod dev/console c 5 1", ignore_error=True),
                call("chmod 666 dev/console"),
                call("chown 0:0 dev/console"),
            ])

    def test_block_device_create(self):
        """块设备 b 应使用 mknod 创建"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/sda b 640 0 0 8 0 - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("mknod dev/sda b 8 0", ignore_error=True),
                call("chmod 640 dev/sda"),
                call("chown 0:0 dev/sda"),
            ])

    def test_pipe_create(self):
        """管道 p 应使用 mknod p 创建"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/myfifo p 666 0 0 0 0 - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("mknod dev/myfifo p", ignore_error=True),
                call("chmod 666 dev/myfifo"),
                call("chown 0:0 dev/myfifo"),
            ])

    def test_char_device_no_major_minor(self):
        """字符设备 c 无 major/minor 时只做赋权"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/console c 666 0 0 - - - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("chmod 666 dev/console"),
                call("chown 0:0 dev/console"),
            ])

    def test_block_device_no_major_minor(self):
        """块设备 b 无 major/minor 时只做赋权"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/sda b 640 0 0 - - - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("chmod 640 dev/sda"),
                call("chown 0:0 dev/sda"),
            ])

    def test_device_dash_mode(self):
        """设备文件 mode 为 - 时跳过 chmod"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/null c - 0 0 1 3 - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("mknod dev/null c 1 3", ignore_error=True),
                call("chown 0:0 dev/null"),
            ])

    def test_device_dash_uid_gid(self):
        """设备文件 uid/gid 为 - 时跳过 chown"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/null c 666 - - 1 3 - - -"])
            task = _make_task()
            task.do_permission(per)
            task.exec.assert_has_calls([
                call("mknod dev/null c 1 3", ignore_error=True),
                call("chmod 666 dev/null"),
            ])


class TestDoPermissionDeviceBatch(unittest.TestCase):
    """设备批量创建测试（count/inc/start）"""

    def test_batch_char_devices(self):
        """批量创建字符设备：/dev/ttyS0 ~ /dev/ttyS3，minor 从 64 开始"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # count=4, start=0, inc=1 → 创建 ttyS0~ttyS3，minor = 64,65,66,67
            per = _write_perm(tmpdir, ["/dev/ttyS c 666 0 0 4 64 0 1 4"])
            task = _make_task()
            task.do_permission(per)
            cmds = [c[0][0] for c in task.exec.call_args_list]
            self.assertIn("mknod dev/ttyS0 c 4 64", cmds)
            self.assertIn("mknod dev/ttyS1 c 4 65", cmds)
            self.assertIn("mknod dev/ttyS2 c 4 66", cmds)
            self.assertIn("mknod dev/ttyS3 c 4 67", cmds)

    def test_batch_block_devices_with_increment(self):
        """批量创建块设备：/dev/hda1 ~ /dev/hda15，minor 从 1 递增"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # count=15, start=1, inc=1 → 创建 hda1~hda15，minor = 1..15
            per = _write_perm(tmpdir, ["/dev/hda b 640 0 0 3 1 1 1 15"])
            task = _make_task()
            task.do_permission(per)
            cmds = [c[0][0] for c in task.exec.call_args_list]
            self.assertIn("mknod dev/hda1 b 3 1", cmds)
            self.assertIn("mknod dev/hda8 b 3 8", cmds)
            self.assertIn("mknod dev/hda15 b 3 15", cmds)
            # 不应包含 hda0 或 hda16
            self.assertNotIn("mknod dev/hda0 b 3 0", cmds)
            self.assertNotIn("mknod dev/hda16 b 3 16", cmds)

    def test_batch_with_nontrivial_increment(self):
        """increment > 1 时 minor 按倍数递增"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # count=3, start=0, inc=4 → 创建 name0,name1,name2，minor = 0,4,8
            per = _write_perm(tmpdir, ["/dev/loop b 640 0 0 7 0 0 4 3"])
            task = _make_task()
            task.do_permission(per)
            cmds = [c[0][0] for c in task.exec.call_args_list]
            self.assertIn("mknod dev/loop0 b 7 0", cmds)
            self.assertIn("mknod dev/loop1 b 7 4", cmds)
            self.assertIn("mknod dev/loop2 b 7 8", cmds)

    def test_count_zero_single_device(self):
        """count=0 时只创建单个设备（无编号后缀）"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, ["/dev/null c 666 0 0 1 3 0 0 0"])
            task = _make_task()
            task.do_permission(per)
            cmds = [c[0][0] for c in task.exec.call_args_list]
            self.assertIn("mknod dev/null c 1 3", cmds)
            # 不应带数字后缀
            self.assertNotIn("mknod dev/null0 c 1 3", cmds)


class TestDoPermissionMultipleLines(unittest.TestCase):
    """多行 permissions 测试"""

    def test_multiple_types(self):
        """混合不同类型的权限行"""
        with tempfile.TemporaryDirectory() as tmpdir:
            per = _write_perm(tmpdir, [
                "# 设备文件",
                "/dev/null c 666 0 0 1 3 - - -",
                "/dev/sda b 640 0 0 8 0 - - -",
                "/dev/myfifo p 666 0 0 0 0 - - -",
                "/usr/lib/libfoo.so f 555 0 0 - - - - -",
            ])
            task = _make_task()
            task.do_permission(per)
            cmds = [c[0][0] for c in task.exec.call_args_list]
            self.assertIn("mknod dev/null c 1 3", cmds)
            self.assertIn("mknod dev/sda b 8 0", cmds)
            self.assertIn("mknod dev/myfifo p", cmds)
            self.assertIn("chmod 555 usr/lib/libfoo.so", cmds)


if __name__ == "__main__":
    unittest.main()
