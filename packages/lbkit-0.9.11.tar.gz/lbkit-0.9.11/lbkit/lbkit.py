# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
import sys
from lbkit.cli import main


def run():

    main(sys.argv[1:])


if __name__ == '__main__':
    run()
