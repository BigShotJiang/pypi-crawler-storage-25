# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""
    Exceptions raised and handled
"""

class LiteBmcException(Exception):
    """
         Generic lbkit exception
    """

class ArgException(Exception):
    """
         Generic Argument exception
    """

class PackageConfigException(Exception):
    """
         Generic Argument exception
    """

class RunCommandException(Exception):
    """
         Generic Argument exception
    """

class NotFoundException(LiteBmcException):  # 404
    """
        404 error
    """

class XmlErrorException(LiteBmcException):
    """
        XML parse error
    """


class HttpRequestException(Exception):
    """
         Http request exception
    """

class TestException(Exception):
    pass

class OdfValidateException(Exception):
    """ODF validate exception"""

class DigestNotMatchError(OSError):
    """Raised when source and destination are the same file."""

class ExtractRootfsTarFileError(OSError):
    """Raised when extract rootfs.tar.gz failed."""

class PermissionFormatError(OSError):
    """permission.ini with format error."""
