# Copyright (c) 2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""AI技能管理模块"""
from lbkit.skill.manager import sync

__all__ = ["sync"]
