# Copyright (c) 2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""AI技能管理常量定义"""
import os
from pathlib import Path

# 技能源仓库
AGENTS_REPO_URL = "https://gitee.com/litebmc/agents.git"

# 用户全局技能目录 (~/.claude/skills)
SKILLS_BASE_DIR = os.path.join(Path.home(), ".claude", "skills")

# OpenCode 技能目录 (~/.config/opencode/skills)
OPENCODE_SKILLS_BASE_DIR = os.path.join(Path.home(), ".config", "opencode", "skills")

# 仓库本地缓存（用于 clone 和 pull）
AGENTS_CACHE_DIR = os.path.join(Path.home(), ".cache", "litebmc", "agents")

# 仓库中技能子目录名
SKILLS_SUBDIR = "skills"

# 同步 manifest 文件路径，记录本次同步安装的技能列表
SYNC_MANIFEST_PATH = os.path.join(Path.home(), ".config", "lbk_skill_sync_list.json")
