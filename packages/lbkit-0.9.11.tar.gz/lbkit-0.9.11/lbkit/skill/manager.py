# Copyright (c) 2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""AI技能管理核心逻辑"""
import json
import os
import shutil

import git

from lbkit.log import Logger
from lbkit.skill.constants import (
    AGENTS_CACHE_DIR,
    AGENTS_REPO_URL,
    SKILLS_BASE_DIR,
    SKILLS_SUBDIR,
    OPENCODE_SKILLS_BASE_DIR,
    SYNC_MANIFEST_PATH,
)

log = Logger()


def _read_manifest():
    """读取同步 manifest，返回 {target_dir: [skill_names]} 字典"""
    if not os.path.isfile(SYNC_MANIFEST_PATH):
        return {}
    try:
        with open(SYNC_MANIFEST_PATH, "r", encoding="utf-8") as fp:
            return json.load(fp)
    except (json.JSONDecodeError, OSError):
        return {}


def _write_manifest(manifest):
    """写入同步 manifest"""
    manifest_dir = os.path.dirname(SYNC_MANIFEST_PATH)
    os.makedirs(manifest_dir, exist_ok=True)
    with open(SYNC_MANIFEST_PATH, "w", encoding="utf-8") as fp:
        json.dump(manifest, fp, indent=2, ensure_ascii=False)


def _cleanup_previous_sync(target_dir, manifest):
    """根据 manifest 删除上次同步安装到 target_dir 的技能，保留其它技能"""
    previous_skills = manifest.get(target_dir, [])
    for name in previous_skills:
        skill_path = os.path.join(target_dir, name)
        if os.path.isdir(skill_path):
            shutil.rmtree(skill_path)
            log.info(f"已移除旧技能: {name}")


def _sync_to_target(src_dir, target_dir, manifest):
    """同步技能到目标目录，仅管理本次同步的技能"""
    # 根据上次 manifest 删除旧技能
    _cleanup_previous_sync(target_dir, manifest)

    # 复制新技能
    os.makedirs(target_dir, exist_ok=True)
    new_skills = []
    for name in os.listdir(src_dir):
        src_path = os.path.join(src_dir, name)
        if not os.path.isdir(src_path):
            continue
        dst_path = os.path.join(target_dir, name)
        if os.path.isdir(dst_path):
            shutil.rmtree(dst_path)
        shutil.copytree(src_path, dst_path)
        new_skills.append(name)

    # 更新 manifest 中该目标目录的记录
    manifest[target_dir] = sorted(new_skills)

    return len(new_skills)


def sync():
    """从 agents 仓库同步技能到用户全局技能目录

    流程：clone 或 pull 仓库 → 复制 skills/ 目录到 ~/.claude/skills/ 和 ~/.config/opencode/skills/
    仅管理本次同步安装的技能，不会删除用户自行安装的其它技能。
    """
    # 确保 cache 目录存在
    cache_parent = os.path.dirname(AGENTS_CACHE_DIR)
    os.makedirs(cache_parent, exist_ok=True)

    # clone 或 pull 仓库
    if os.path.isdir(os.path.join(AGENTS_CACHE_DIR, ".git")):
        repo = git.Repo(AGENTS_CACHE_DIR)
        repo.remotes.origin.pull()
        log.info("已拉取最新技能仓库")
    else:
        if os.path.isdir(AGENTS_CACHE_DIR):
            shutil.rmtree(AGENTS_CACHE_DIR)
        git.Repo.clone_from(AGENTS_REPO_URL, AGENTS_CACHE_DIR)
        log.info("已克隆技能仓库")

    # 检查仓库中是否有 skills/ 目录
    src_dir = os.path.join(AGENTS_CACHE_DIR, SKILLS_SUBDIR)
    if not os.path.isdir(src_dir):
        log.info("技能仓库中尚无 skills/ 目录")
        return

    # 读取并更新 manifest
    manifest = _read_manifest()

    # 同步到 Claude Code 技能目录
    count = _sync_to_target(src_dir, SKILLS_BASE_DIR, manifest)
    log.success(f"已同步 {count} 个技能到 {SKILLS_BASE_DIR}")

    # 同步到 OpenCode 技能目录
    count = _sync_to_target(src_dir, OPENCODE_SKILLS_BASE_DIR, manifest)
    log.success(f"已同步 {count} 个技能到 {OPENCODE_SKILLS_BASE_DIR}")

    # 写入更新后的 manifest
    _write_manifest(manifest)
