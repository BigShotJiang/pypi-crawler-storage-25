# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
from mako.lookup import TemplateLookup

class Renderer(object):
    def __init__(self):
        super(Renderer, self).__init__()

    def render(self, lookup: TemplateLookup, template, **kwargs):
        t = lookup.get_template(template)
        return t.render(lookup=lookup, **kwargs)
