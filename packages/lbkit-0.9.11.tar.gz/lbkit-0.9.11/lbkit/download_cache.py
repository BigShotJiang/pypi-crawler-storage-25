# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""下载缓存模块

提供共享下载缓存，避免重复下载相同的文件。
缓存文件以 sha256 命名存储在 ~/.cache/litebmc/download/ 目录下，
支持多进程并发安全（临时文件 + 原子重命名模式）。
"""
import os
import time
import shutil
import requests

from lbkit.misc import DOWNLOAD_CACHE_DIR
from lbkit.tools import Tools


def get_cache_dir():
    """获取缓存目录路径。

    解析优先级：
    1. LBKIT_DOWNLOAD_CACHE 环境变量（设为空字符串则禁用缓存）
    2. 默认路径 ~/.cache/litebmc/download/

    Returns:
        str | None: 缓存目录路径，禁用时返回 None
    """
    env = os.environ.get("LBKIT_DOWNLOAD_CACHE")
    if env is not None:
        if env == "":
            return None
        cache_dir = env
    else:
        cache_dir = DOWNLOAD_CACHE_DIR
    try:
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir
    except OSError:
        return None


def cache_lookup(cache_dir, sha256):
    """在缓存中查找文件。

    Args:
        cache_dir: 缓存目录路径
        sha256: 期望的文件 sha256 值

    Returns:
        str | None: 缓存文件路径，未命中返回 None
    """
    cache_file = os.path.join(cache_dir, sha256)
    if not os.path.isfile(cache_file):
        return None
    calc_sha = Tools.file_digest_sha256(cache_file)
    if calc_sha != sha256:
        return None
    return cache_file


def cache_download_and_store(cache_dir, url, sha256, verify=True):
    """下载文件并存入缓存。

    下载到临时文件，校验 sha256 后原子重命名为 {sha256}。

    Args:
        cache_dir: 缓存目录路径
        url: 下载地址
        sha256: 期望的 sha256 值
        verify: SSL 证书校验开关

    Returns:
        str: 缓存文件路径

    Raises:
        Exception: 下载失败或 sha256 不匹配
    """
    os.makedirs(cache_dir, exist_ok=True)
    tmp_path = os.path.join(cache_dir, f".tmp_{os.getpid()}_{time.monotonic_ns()}")
    try:
        req = requests.get(url, stream=True, verify=verify, timeout=30)
        req.raise_for_status()
        total_size = int(req.headers.get('content-length', 0))
        total_down = 0
        last = time.time()
        with open(tmp_path, 'wb') as fp:
            for chunk in req.iter_content(chunk_size=16384):
                if chunk:
                    fp.write(chunk)
                    total_down += len(chunk)
                    now = time.time()
                    if now - last > 30:
                        print(f"Downloading to cache, {total_down} / {total_size}")
                        last = now
        calc_sha = Tools.file_digest_sha256(tmp_path)
        if sha256 != "any" and calc_sha != sha256:
            raise Exception(f"Cache download sha256 mismatch, need: {sha256}, get: {calc_sha}")
        cache_file = os.path.join(cache_dir, sha256)
        os.rename(tmp_path, cache_file)
        return cache_file
    except Exception:
        if os.path.isfile(tmp_path):
            os.unlink(tmp_path)
        raise


def cache_copy_to_dst(cache_file, dst):
    """从缓存复制文件到目标路径。

    Args:
        cache_file: 缓存文件路径
        dst: 目标文件路径
    """
    shutil.copyfile(cache_file, dst)
