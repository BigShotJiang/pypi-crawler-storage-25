# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""任务基础类"""
import os
import json
import tempfile
from lbkit.log import Logger
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from lbkit import misc
from lbkit.tools import Tools
from lbkit.misc import Color

tools = Tools()
log = tools.log


class BuildConanParallel(object):
    def __init__(self, orderinfo, lockfile, remote):
        self.orderinfo = orderinfo
        self.remote = remote
        self.lockfile = lockfile

    def _build_package(self, logfile, build_args, public_args):
        lockfile_out = logfile + ".lock"
        cmd = f"conan install {build_args} {public_args} --lockfile={self.lockfile} --lockfile-out={lockfile_out}"
        log.info("{}build start:    '{}".format(Color.GREEN, Color.RESET_ALL) + cmd + '  log file: ' + logfile)
        tools.exec(cmd, log_name=logfile, echo_cmd=False)
        log.info("{}build finished: '{}".format(Color.GREEN, Color.RESET_ALL) + cmd + '  log file: ' + logfile)

    def _build(self):
        with open(self.orderinfo, "r") as fp:
            order_info = json.load(fp)
        public_args = order_info.get("profiles", {}).get("self", {}).get("args", "")
        for orders in order_info.get("order", []):
            threadPool = ThreadPoolExecutor(max_workers=(os.cpu_count() + 1) // 2)
            results: list[Future] = []
            for order in orders:
                ref = order.get("ref")
                pkgname = ref.split("/")[0]
                logfile = f"{misc.LOG_DIR}/conan_{pkgname}.log"
                packages = order.get("packages", [])
                for package in packages:
                    for pkg in package:
                        binary = pkg.get("binary", "")
                        if binary == 'Download':
                            pkgid = pkg.get("package_id")
                            cmd = f'conan download {ref}:{pkgid}'
                            if self.remote:
                                cmd += f' -r {self.remote}'
                            tools.exec(cmd)
                            continue
                        if binary != "Build":
                            continue
                        build_args = pkg.get("build_args", "")
                        result = threadPool.submit(self._build_package, logfile, build_args, public_args)
                        results.append(result)
            for result in as_completed(results):
                result.result()

    def build(self):
        cwd = os.getcwd()
        tmp = tempfile.TemporaryDirectory()
        os.chdir(tmp.name)
        self._build()
        os.chdir(cwd)
