# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""fakeroot 会话管理器

维护一个持久的 faked 守护进程，所有命令在同一 fakeroot 会话中执行，
避免每个命令都启动/停止守护进程带来的开销。

原理:
    传统用法 ``fakeroot -s db -i db -- command`` 每次执行命令时都会:
    1. 启动 faked 守护进程 (fork + exec)
    2. 从 db 文件加载状态 (IPC 共享内存)
    3. 执行命令
    4. 退出时运行 ``ls -l /`` 刷新状态到文件
    5. 通过 ``while kill ... ; do sleep 0.1; done`` 等待守护进程退出

    每次调用至少耗时 100ms (sleep 0.1)，处理大量文件时产生 O(n^2) 瓶颈。

    本类通过直接管理 faked 守护进程的完整生命周期，所有命令共享同一个会话，
    将每个命令的开销从 "启动守护进程 + IPC + 加载/保存状态文件" 降低为
    "设置环境变量"，消除了 O(n) 的守护进程启动开销。

用法:
    # 方式一：上下文管理器（推荐）
    with Fakeroot("/tmp/fakeroot.db") as fr:
        env = os.environ.copy()
        env.update(fr.env)
        subprocess.run(["chown", "0:0", "/path"], env=env)

    # 方式二：手动管理生命周期
    fr = Fakeroot("/tmp/fakeroot.db")
    fr.start()
    try:
        env = os.environ.copy()
        env.update(fr.env)
        subprocess.run(["chown", "0:0", "/path"], env=env)
    finally:
        fr.stop()

传递给 TaskHook:
    Fakeroot 实例存储在 Config 对象上，Task 和 TaskHook 通过 config 共享同一会话::

        # 在 TaskBuildRootfs 中创建
        self.config.fakeroot = Fakeroot(db_file)
        self.config.fakeroot.start()
        try:
            ...
        finally:
            self.config.fakeroot.stop()

        # 在 TaskHook 中通过 config 访问
        class TaskHook(Task):
            def run(self):
                fr = self.config.fakeroot
                env = os.environ.copy()
                env.update(fr.env)
                ...

串行性分析:
    - ``start()`` / ``stop()`` 生命周期管理必须串行，同一时刻只能有一个活跃会话
    - 命令执行**支持并发**：faked 守护进程基于 SYSV IPC（信号量/共享内存），
      天然支持多进程并发访问，多个子进程可同时通过 ``FAKEROOTKEY`` 连接同一守护进程
    - 注意：同一文件的权限操作不应并发执行（可能产生竞态条件），
      但对不同文件的操作可以安全并行
"""

import os
import signal
import shutil
import subprocess
import time
from lbkit import errors


class Fakeroot:
    """fakeroot 会话管理器

    通过直接管理 faked 守护进程，提供持久的 fakeroot 会话。
    """

    FAKED_BIN = "faked-sysv"
    FAKEROOT_LIB = "libfakeroot-sysv.so"
    LIB_SEARCH_PATHS = [
        "/usr/lib/x86_64-linux-gnu/libfakeroot",
        "/usr/lib64/libfakeroot",
        "/usr/lib32/libfakeroot",
        "/usr/lib/libfakeroot",
    ]

    def __init__(self, db_file: str):
        """
        :param db_file: fakeroot 状态数据库文件路径，用于在不同会话间持久化权限信息
        """
        self.db_file = db_file
        self._daemon_pid: int | None = None
        self._fakeroot_key: str | None = None
        self._ld_preload: str | None = None
        self._ld_library_path: str | None = None
        # 标记是否继承已有 fakeroot 会话（如 CI 流水线中已在外层启动 fakeroot）
        self._inherited = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.stop()

    @property
    def active(self) -> bool:
        """fakeroot 会话是否已激活"""
        return self._fakeroot_key is not None

    @property
    def env(self) -> dict:
        """返回在 fakeroot 会话中执行命令所需的环境变量

        使用方式::

            env = os.environ.copy()
            env.update(fakeroot.env)
            subprocess.Popen(cmd, env=env)

        如果已在 fakeroot 环境中（继承模式），返回空字典，子进程自动继承
        父进程的 ``FAKEROOTKEY`` 等环境变量。
        """
        if not self.active:
            return {}
        if self._inherited:
            return {}

        result = {"FAKEROOTKEY": self._fakeroot_key}

        # LD_PRELOAD: 保留已有的 preload 库（与 fakeroot 脚本行为一致）
        ld_preload = self._ld_preload
        existing_preload = os.environ.get("LD_PRELOAD")
        if existing_preload:
            ld_preload = f"{ld_preload}:{existing_preload}"
        result["LD_PRELOAD"] = ld_preload

        # LD_LIBRARY_PATH: 保留已有的库路径
        ld_library_path = self._ld_library_path
        existing_lib_path = os.environ.get("LD_LIBRARY_PATH")
        if existing_lib_path:
            ld_library_path = f"{ld_library_path}:{existing_lib_path}"
        result["LD_LIBRARY_PATH"] = ld_library_path

        return result

    def start(self):
        """启动 fakeroot 会话

        如果当前进程已在 fakeroot 环境中（``FAKEROOTKEY`` 已设置），
        则直接复用现有会话，不启动新的守护进程。
        否则启动 faked 守护进程，建立独立的 fakeroot 会话。

        如果 db_file 已存在，会从中加载之前保存的状态。
        """
        if self.active:
            return

        # 已在 fakeroot 环境中（如 CI 流水线），复用现有会话
        if os.environ.get("FAKEROOTKEY"):
            self._fakeroot_key = os.environ["FAKEROOTKEY"]
            self._inherited = True
            return

        # 查找 faked 守护进程和预加载库
        faked_bin = shutil.which(self.FAKED_BIN)
        if not faked_bin:
            raise errors.NotFoundException(f"{self.FAKED_BIN} not found")
        lib_name, lib_path = self._find_library()

        # 构建守护进程启动命令
        cmd = [faked_bin, "--save-file", self.db_file]
        stdin_input = None
        if os.path.isfile(self.db_file):
            cmd.append("--load")
            with open(self.db_file, "r") as f:
                stdin_input = f.read()

        # 启动守护进程（faked 输出 KEY:PID 到 stdout 后 fork 到后台）
        result = subprocess.run(
            cmd, input=stdin_input, capture_output=True, text=True
        )
        if result.returncode != 0:
            raise errors.RunCommandException(
                f"Failed to start faked daemon: {result.stderr}"
            )

        # 解析 KEY:PID
        output = result.stdout.strip()
        if ":" not in output:
            raise errors.RunCommandException(
                f"Unexpected faked output: {output}"
            )

        parts = output.split(":")
        self._fakeroot_key = parts[0]
        self._daemon_pid = int(parts[1])
        self._ld_preload = lib_name
        self._ld_library_path = lib_path

    def stop(self):
        """停止 fakeroot 会话

        向 faked 守护进程发送 SIGTERM，守护进程会将状态保存到 db_file 后退出。
        如果会话是继承的（非本类启动的），则不做任何操作。
        """
        if self._daemon_pid is None:
            return

        try:
            os.kill(self._daemon_pid, signal.SIGTERM)
        except ProcessLookupError:
            pass

        # 等待守护进程退出（守护进程收到 SIGTERM 后会保存状态到 db_file）
        deadline = time.time() + 10
        while time.time() < deadline:
            try:
                os.kill(self._daemon_pid, 0)
                time.sleep(0.1)
            except ProcessLookupError:
                break

        self._daemon_pid = None
        self._fakeroot_key = None

    @classmethod
    def _find_library(cls) -> tuple[str, str]:
        """查找 fakeroot 预加载库

        :return: (lib_name, lib_path) 元组
        :raises errors.NotFoundException: 未找到 fakeroot 库
        """
        for path in cls.LIB_SEARCH_PATHS:
            full_path = os.path.join(path, cls.FAKEROOT_LIB)
            if os.path.isfile(full_path):
                return cls.FAKEROOT_LIB, path
        raise errors.NotFoundException(
            f"Fakeroot library {cls.FAKEROOT_LIB} not found in {cls.LIB_SEARCH_PATHS}"
        )
