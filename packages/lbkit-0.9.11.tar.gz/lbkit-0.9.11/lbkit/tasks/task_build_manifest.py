# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""应用构建任务"""
import os
import shutil
import json
from mako.lookup import TemplateLookup
from lbkit.tasks.config import Config
from lbkit.tasks.task import Task
from lbkit.build_conan_parallel import BuildConanParallel
from lbkit.codegen.codegen import __version__ as codegen_version
from lbkit.codegen.codegen import Version



class ManifestValidateError(OSError):
    """Raised when validation manifest.yml failed."""

src_cwd = os.path.split(os.path.realpath(__file__))[0]

class TaskClass(Task):
    """根据产品配置构建所有app,记录待安装应用路径到self.config.conan_install路径"""
    def __init__(self, cfg: Config, name: str):
        super().__init__(cfg, name)
        self.conan_build = os.path.join(self.config.temp_path, "conan")
        if os.path.isdir(self.conan_build):
            shutil.rmtree(self.conan_build)
        os.makedirs(self.conan_build)
        if self.config.build_type == "debug":
            self.conan_settings = " -s build_type=Debug"
        elif self.config.build_type == "release":
            self.conan_settings = " -s build_type=Release"
        elif self.config.build_type == "minsize":
            self.conan_settings = " -s build_type=MinSizeRel"
        self.common_args = "-r " + self.config.remote
        self.common_args += " -pr:b {} -pr:h {}".format(self.config.profile_build, self.config.profile_host)
        self.common_args += " -o */*:test=False"
        cv = self.get_manifest_config("metadata/codegen_version")
        if cv == "latest":
            cv = codegen_version.str
        self.common_args += " -o */*:codegen_version=" + cv
        version_info = Version(cv)
        self.common_args += " -o */*:compatible_required=" + version_info.info.lb_base_compatible_required
        os.environ["CODEGEN_VERSION"] = cv

    def deploy(self, graph_file):
        with open(graph_file, "r") as fp:
            graph = json.load(fp)
        nodes = graph.get("graph", {}).get("nodes", {})
        for id, info in nodes.items():
            context = info.get("context")
            if context != "host":
                continue
            package_folder = info.get("package_folder", "")
            ref = info.get("ref", "")
            if package_folder:
                self.config.conan_install.append((package_folder, ref))

    def build_rootfs(self):
        """构建产品rootfs包"""
        self.log.info("build rootfs")

        manifest = self.load_manifest()
        # 使用模板生成litebmc组件的配置
        lookup = TemplateLookup(directories=os.path.join(src_cwd, "template"))
        template = lookup.get_template("rootfs.py.mako")
        conanfile = template.render(lookup=lookup, pkg=manifest)

        recipe = os.path.join(self.conan_build, "rootfs")
        os.makedirs(recipe, exist_ok=True)
        os.chdir(recipe)
        fp = open("conanfile.py", "w", encoding="utf-8")
        fp.write(conanfile)
        fp.close()

        self.exec(f"conan create . {self.common_args} --build=missing", verbose=True)

    def build_litebmc(self):
        """构建产品conan包"""
        self.log.info("build litebmc")

        manifest = self.load_manifest()
        hook_name = "hook.prepare_manifest"
        self.do_hook(hook_name)
        # 使用模板生成litebmc组件的配置
        lookup = TemplateLookup(directories=os.path.join(src_cwd, "template"))
        template = lookup.get_template("conanfile.py.mako")
        conanfile = template.render(lookup=lookup, pkg=manifest, real_dependencies=self.config.get_dependencies())

        recipe = os.path.join(self.conan_build, "litebmc")
        os.makedirs(recipe, exist_ok=True)
        os.chdir(recipe)
        fp = open("conanfile.py", "w", encoding="utf-8")
        fp.write(conanfile)
        fp.close()

        base_cmd = f"{self.common_args} {self.conan_settings}"
        lockfile = os.path.join(self.config.code_path, "conan.lock")
        orderfile = os.path.join(self.config.temp_path, "build-order.json")
        graph_cmd = f"conan graph build-order . {base_cmd} --order-by=recipe -f json --out-file={orderfile}"
        if self.config.from_source:
            graph_cmd += " --build='*'"
        else:
            graph_cmd += " --build=missing"
        if self.config.update_lockfile or not os.path.isfile(lockfile):
            graph_cmd += f" --lockfile-out={lockfile}"
        else:
            graph_cmd += f" --lockfile={lockfile} --lockfile-partial"
        self.exec(graph_cmd, verbose=True)
        bcp = BuildConanParallel(orderfile, lockfile, self.config.remote)
        bcp.build()

        self.exec(f"sed -i 's@rootfs_df190c/0.0.1#.*\"@rootfs_df190c/0.0.1\"@g' {lockfile}")
        # 用conan install获取所有依赖的package_folder信息，避免逐个调用conan cache path
        graphfile = os.path.join(self.config.temp_path, "graph.info")
        self.pipe([f"conan install . {base_cmd} --lockfile={lockfile} -f json"], out_file=graphfile)
        # 部署应用到self.config.conan_install
        self.deploy(graphfile)

    def run(self):
        """任务入口"""
        self.build_rootfs()
        self.build_litebmc()
        return 0

if __name__ == "__main__":
    config = Config()
    build = TaskClass(config, "test")
    build.run()
