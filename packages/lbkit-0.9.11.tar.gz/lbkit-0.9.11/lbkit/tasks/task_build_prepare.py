# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""环境准备"""
import os
import hashlib
import shutil
import tempfile
import jinja2
import configparser
from string import Template
from lbkit.tasks.config import Config
from lbkit.tasks.task import Task
from lbkit.misc import DownloadFlag

class ManifestValidateError(OSError):
    """Raised when validation manifest.yml failed."""

src_cwd = os.path.split(os.path.realpath(__file__))[0]

class TaskClass(Task):
    def __init__(self, config, name):
        super().__init__(config, name)
        self.compiler_path = self.config.compiler_path
        self.sysroot_path = os.path.join(self.config.compiler_path, "sysroot")

    @staticmethod
    def _create_at_safe_link(real_path, log=None):
        """为含@字符的路径创建不含@的符号链接。

        Perl（OpenSSL等autotools项目使用）在双引号字符串中将@解释为数组变量前缀，
        导致路径如 toolkit-pr@3 被插值为 toolkit-pr（@3数组为空）。
        通过创建不含@的符号链接来规避此问题。

        Args:
            real_path: 原始路径（可能包含@字符）
            log: Logger实例，用于记录日志

        Returns:
            不含@字符的安全路径（原始路径不含@时直接返回，否则返回符号链接路径）
        """
        if '@' not in real_path:
            return real_path
        path_hash = hashlib.sha256(real_path.encode()).hexdigest()[:16]
        link_dir = os.path.join(tempfile.gettempdir(), "lbkit_links")
        os.makedirs(link_dir, exist_ok=True)
        link_name = os.path.join(link_dir, path_hash)
        target = os.path.abspath(real_path)
        if os.path.islink(link_name):
            existing_target = os.readlink(link_name)
            if os.path.abspath(existing_target) == target:
                return link_name
            os.unlink(link_name)
        elif os.path.exists(link_name):
            shutil.rmtree(link_name)
        os.symlink(target, link_name)
        if log:
            log.info("Created symlink %s -> %s to avoid '@' in path", link_name, target)
        return link_name

    def decompress_file(self, dir, name, toolchain):
        compiler = toolchain.get(name)
        file = compiler.get("file")
        strip = compiler.get("strip_components", 0)
        flag_file = os.path.join(dir, ".file.sha256")
        _, hash = DownloadFlag.read(flag_file)
        file_hash = self.tools.file_digest_sha256(file)
        if hash and file_hash == hash:
            return
        # 可能标记不匹配，所以尝试删除目录后重新创建
        if os.path.isdir(dir):
            shutil.rmtree(dir)
        os.makedirs(dir)
        cmd = f"tar -xf {file} -C {dir}"
        if strip:
            cmd += f" --strip-components={strip}"
        self.exec(cmd)
        sha256 = self.tools.file_digest_sha256(file)
        DownloadFlag.create(flag_file, file, sha256)

    def decompress_toolchain(self):
        toolchain = self.config.get_product_config("toolchain")
        if not toolchain:
            # todo：toolchain成为强制配置项
            return
        self.decompress_file(self.compiler_path, "compiler", toolchain)
        self.decompress_file(self.sysroot_path, "sysroot", toolchain)

    def get_conan_profile(self):
        profile = self.config.get_product_config("toolchain/profile")
        if profile:
            file = profile.get("file")
            name = profile.get("name")
        else:
            file = self.get_manifest_config("metadata/profile")
            name = "litebmc"
        return file, name


    def load_conan_profile(self):
        profile, name = self.get_conan_profile()
        self.log.info("Copy profile %s", profile)
        profiles_dir = os.path.expanduser("~/.conan2/profiles")
        if not os.path.isdir(profiles_dir):
            cmd = "conan profile detect -f"
            self.exec(cmd, ignore_error=True)
        dst_profile = os.path.join(profiles_dir, name)
        # 将含@的路径替换为不含@的符号链接路径，避免Perl等构建工具的字符串插值问题
        compiler_path = self._create_at_safe_link(self.compiler_path, self.log)
        sysroot_path = self._create_at_safe_link(self.sysroot_path, self.log)
        code_path = self._create_at_safe_link(self.config.code_path, self.log)
        with open(dst_profile, "w+") as dst_fp:
            src_fd = open(profile, "r")
            template = Template(src_fd.read())
            src_fd.close()
            content = template.safe_substitute(compiler_path=compiler_path,
                                               sysroot_path=sysroot_path,
                                               code_path=code_path)
            dst_fp.write(content)

        with open(dst_profile, "r") as fp:
            profile_data = jinja2.Template(fp.read()).render()
            parser = configparser.ConfigParser(allow_no_value=True, delimiters=('=',))
            parser.read_string(profile_data)
            strip = "strip"
            if parser.has_option("buildenv", "STRIP"):
                strip = parser.get("buildenv", "STRIP")
            path = ""
            if parser.has_option("buildenv", "PATH+"):
                path = parser.get("buildenv", "PATH+")
                if path.startswith("(path)"):
                    path = path[6:]
            elif parser.has_option("buildenv", "PATH"):
                path = parser.get("buildenv", "PATH")
                if path.startswith("(path)"):
                    path = path[6:]
            self.config.strip = os.path.join(path, strip)

    def run(self):
        """任务入口"""
        self.decompress_toolchain()
        """检查manifest文件是否满足schema格式描述"""
        self.config.load_manifest()
        self.load_conan_profile()
        return 0

if __name__ == "__main__":
    config = Config()
    build = TaskClass(config, "test")
    build.run()