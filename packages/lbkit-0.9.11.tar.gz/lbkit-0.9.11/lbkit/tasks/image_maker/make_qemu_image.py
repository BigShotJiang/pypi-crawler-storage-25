# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""环境准备"""
import os
from lbkit.tasks.config import Config
from lbkit.utils.images.emmc import MakeImage as MekeEmmcImage
from lbkit.tasks.image_maker.make_image import TaskMakeImage
from lbkit.utils.fakeroot import Fakeroot

src_cwd = os.path.split(os.path.realpath(__file__))[0]

class TaskMakeQemuImage(TaskMakeImage):
    def __init__(self, config, name):
        super().__init__(config, name)
        self.chip_model = None
        chip_model = self.config.get_product_config("chip_model")
        if chip_model not in ["qemu_arm64"]:
            return
        self.chip_model = chip_model
        self.uboot = self.config.get_product_config("flash/uboot")
        self.kernel = self.config.get_product_config("flash/kernel")

    @staticmethod
    def _trans_to_blk_1m(cfg: str):
        if cfg.endswith("K"):
            return int(cfg[:-1]) / 1024
        elif cfg.endswith("M"):
            return int(cfg[:-1])
        elif cfg.endswith("G"):
            return int(cfg[:-1]) * 1024

    def available(self):
        if not self.chip_model:
            return False
        if self.config.get_product_config("flash/type") != "emmc":
            return False
        return True

    def run(self):
        """任务入口"""
        os.chdir(self.config.output_path)
        mnt_path = self.config.mnt_path
        # 加载task_build_rootfs保存的fakeroot状态，继承权限配置
        fakeroot_file = os.path.join(self.config.temp_path, "make_rootfs", "fakeroot.db")
        fakeroot = Fakeroot(fakeroot_file)
        fakeroot.start()
        try:
            self.config.fakeroot = fakeroot
            # 复制内核文件到boot/Image
            cmd = f"cp {self.kernel} {mnt_path}/boot/Image"
            self.exec(cmd)
            cmd = f"chown 0:0 {mnt_path}/boot/Image"
            self.exec(cmd)
            # 重新生成rootfs镜像
            if os.path.exists(self.config.rootfs_img):
                os.unlink(self.config.rootfs_img)
            rootfs_size = self.config.get_product_config("rootfs/size")
            size_mb = int(self._trans_to_blk_1m(rootfs_size)) if rootfs_size else 1024
            cmd = f'mkfs.ext4 -d {mnt_path} -r 1 -N 0 -m 5 -L "rootfs" -O ^64bit {self.config.rootfs_img} "{size_mb}M"'
            self.exec(cmd)
        finally:
            self.config.fakeroot = None
            fakeroot.stop()

        # 制作eMMC镜像
        mk = MekeEmmcImage()
        rootfs_size = self.config.get_product_config("rootfs/size")
        if rootfs_size:
            mk.rootfs_blk_1m = self._trans_to_blk_1m(rootfs_size)
        emmc_size = self.config.get_product_config("flash/size")
        if emmc_size:
            mk.size_1m = self._trans_to_blk_1m(emmc_size)
        mk.run(self.config.rootfs_img, "qemu.img")
        cmd = 'cp /usr/share/litebmc/qemu.conf qemu.conf'
        self.exec(cmd)
        cmd = f'cp {self.uboot} u-boot.bin'
        self.exec(cmd)
        output_img = os.path.join(self.config.output_path, "litebmc_qemu.tar.gz")
        cmd = f'tar -czf {output_img} -C . qemu.img u-boot.bin qemu.conf'
        self.exec(cmd)
        self.log.success(f"Create litebmc image {output_img} successfully")
        return 0

if __name__ == "__main__":
    config = Config()
    build = TaskMakeQemuImage(config, "test")
    build.run()