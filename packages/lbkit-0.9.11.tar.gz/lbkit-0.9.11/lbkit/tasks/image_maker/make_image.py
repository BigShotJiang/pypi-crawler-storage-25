# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""环境准备"""
import os
from lbkit.tasks.config import Config
from lbkit.tasks.task import Task


class TaskMakeImage(Task):
    def available(self):
        return False

    def run(self):
        return

if __name__ == "__main__":
    config = Config()
    build = TaskMakeImage(config, "test")
    build.run()