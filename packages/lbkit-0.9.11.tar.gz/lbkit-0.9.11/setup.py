# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
import os
import re
from setuptools import setup, find_packages

def load_version():
    """ Loads a file content """
    filename = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                            "lbkit", "__init__.py"))
    with open(filename, "rt") as version_file:
        litebmc_init = version_file.read()
        version = re.search(r"__version__ = '([0-9.]+)'", litebmc_init).group(1)
        return version

setup(
    name="lbkit",
    version=load_version(),
    author="xuhj@litebmc.com",
    author_email="xuhj@litebmc.com",
    description="Tools provided by litebmc.com",
    long_description="build and code generate tools",
    long_description_content_type="text/markdown",
    install_requires=["pyyaml", "colorama", "mako", "node-semver>=0.6.1", "jsonschema", "conan", "requests", "gitpython", "inflection", "meson>=1.4.0", "psutil", "loguru"],
    url="https://www.litebmc.com",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    entry_points={
        'console_scripts': [
            'lbk=lbkit.lbkit:run',
            'lbkit=lbkit.lbkit:run',
        ],
    },
)
