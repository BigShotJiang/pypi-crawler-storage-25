"""Asset Reference Resolver.

Provides utilities for resolving asset paths to Unity references with
automatic GUID and fileID detection.

Usage:
    # In values, use @ prefix to reference assets
    "@Assets/Scripts/Player.cs"           -> Script reference
    "@Assets/Sprites/icon.png"            -> Sprite reference (Single mode)
    "@Assets/Sprites/atlas.png:idle_0"    -> Sprite sub-sprite (Multiple mode)
    "@Assets/Audio/jump.wav"              -> AudioClip reference
    "@Assets/Prefabs/Enemy.prefab"        -> Prefab reference
    "@Assets/Materials/Custom.mat"        -> Material reference
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from unityflow.asset_tracker import META_GUID_PATTERN


class AssetType(Enum):
    """Unity asset types for type validation."""

    SPRITE = "Sprite"
    TEXTURE = "Texture2D"
    AUDIO_CLIP = "AudioClip"
    MATERIAL = "Material"
    PREFAB = "Prefab"
    SCRIPT = "Script"
    SCRIPTABLE_OBJECT = "ScriptableObject"
    ANIMATION_CLIP = "AnimationClip"
    ANIMATOR_CONTROLLER = "AnimatorController"
    FONT = "Font"
    SHADER = "Shader"
    TEXT_ASSET = "TextAsset"
    VIDEO_CLIP = "VideoClip"
    MODEL = "Model"
    UNKNOWN = "Unknown"


# Extension to asset type mapping
EXTENSION_TO_ASSET_TYPE: dict[str, AssetType] = {
    # Sprites/Textures (images are typically used as sprites in 2D)
    ".png": AssetType.SPRITE,
    ".jpg": AssetType.SPRITE,
    ".jpeg": AssetType.SPRITE,
    ".tga": AssetType.SPRITE,
    ".psd": AssetType.SPRITE,
    ".tiff": AssetType.SPRITE,
    ".gif": AssetType.SPRITE,
    ".bmp": AssetType.SPRITE,
    ".exr": AssetType.TEXTURE,  # HDR textures
    ".hdr": AssetType.TEXTURE,
    # Audio
    ".wav": AssetType.AUDIO_CLIP,
    ".mp3": AssetType.AUDIO_CLIP,
    ".ogg": AssetType.AUDIO_CLIP,
    ".aiff": AssetType.AUDIO_CLIP,
    ".aif": AssetType.AUDIO_CLIP,
    ".flac": AssetType.AUDIO_CLIP,
    # Materials
    ".mat": AssetType.MATERIAL,
    # Scripts
    ".cs": AssetType.SCRIPT,
    # Prefabs
    ".prefab": AssetType.PREFAB,
    # ScriptableObjects
    ".asset": AssetType.SCRIPTABLE_OBJECT,
    # Animations
    ".anim": AssetType.ANIMATION_CLIP,
    ".controller": AssetType.ANIMATOR_CONTROLLER,
    # Fonts
    ".ttf": AssetType.FONT,
    ".otf": AssetType.FONT,
    ".fon": AssetType.FONT,
    # Shaders
    ".shader": AssetType.SHADER,
    ".shadergraph": AssetType.SHADER,
    # Text/Data
    ".txt": AssetType.TEXT_ASSET,
    ".json": AssetType.TEXT_ASSET,
    ".xml": AssetType.TEXT_ASSET,
    ".bytes": AssetType.TEXT_ASSET,
    ".csv": AssetType.TEXT_ASSET,
    # Models
    ".fbx": AssetType.MODEL,
    ".obj": AssetType.MODEL,
    ".blend": AssetType.MODEL,
    # Video
    ".mp4": AssetType.VIDEO_CLIP,
    ".webm": AssetType.VIDEO_CLIP,
    ".mov": AssetType.VIDEO_CLIP,
}


# Field name patterns to expected asset types
# Patterns are checked in order, first match wins
FIELD_NAME_TO_EXPECTED_TYPES: list[tuple[re.Pattern, list[AssetType]]] = [
    # Sprite fields (including camelCase like playerSprite)
    (re.compile(r"(?i)(^|_)sprite($|s$|_)|[a-z]Sprite(s)?$"), [AssetType.SPRITE]),
    (re.compile(r"^m_Sprite$"), [AssetType.SPRITE]),
    # Audio fields
    (re.compile(r"(?i)(audio|sound|clip|music|sfx)"), [AssetType.AUDIO_CLIP]),
    (re.compile(r"^m_audioClip$", re.IGNORECASE), [AssetType.AUDIO_CLIP]),
    # Material fields
    (re.compile(r"(?i)(^|_)material($|s$|_)"), [AssetType.MATERIAL]),
    (re.compile(r"^m_Material"), [AssetType.MATERIAL]),
    (re.compile(r"^m_Materials"), [AssetType.MATERIAL]),
    # Prefab fields
    (re.compile(r"(?i)prefab"), [AssetType.PREFAB]),
    # Script fields
    (re.compile(r"^m_Script$"), [AssetType.SCRIPT]),
    # Animator fields
    (re.compile(r"(?i)(animator|controller)"), [AssetType.ANIMATOR_CONTROLLER]),
    (re.compile(r"^m_Controller$"), [AssetType.ANIMATOR_CONTROLLER]),
    # Animation fields
    (re.compile(r"(?i)(anim|animation)(?!.*controller)"), [AssetType.ANIMATION_CLIP]),
    # Font fields
    (re.compile(r"(?i)font"), [AssetType.FONT]),
    # Texture fields (general textures, not sprites)
    (re.compile(r"(?i)texture"), [AssetType.TEXTURE, AssetType.SPRITE]),
    (re.compile(r"^m_Texture"), [AssetType.TEXTURE, AssetType.SPRITE]),
    # Mesh/Model fields
    (re.compile(r"(?i)(mesh|model)"), [AssetType.MODEL]),
    # Video fields
    (re.compile(r"(?i)video"), [AssetType.VIDEO_CLIP]),
    # ScriptableObject fields (generic data references)
    (re.compile(r"(?i)(data|config|settings|so$)"), [AssetType.SCRIPTABLE_OBJECT]),
]


class AssetTypeMismatchError(ValueError):
    """Error raised when asset type doesn't match expected field type."""

    def __init__(
        self,
        field_name: str,
        asset_path: str,
        expected_types: list[AssetType],
        actual_type: AssetType,
    ):
        self.field_name = field_name
        self.asset_path = asset_path
        self.expected_types = expected_types
        self.actual_type = actual_type
        expected_str = ", ".join(t.value for t in expected_types)
        super().__init__(
            f"Type mismatch for field '{field_name}': "
            f"expected {expected_str}, but '{asset_path}' is {actual_type.value}"
        )


def get_asset_type_from_extension(extension: str) -> AssetType:
    """Get the asset type from a file extension.

    Args:
        extension: File extension (with or without leading dot)

    Returns:
        AssetType for the extension
    """
    ext = extension.lower()
    if not ext.startswith("."):
        ext = "." + ext
    return EXTENSION_TO_ASSET_TYPE.get(ext, AssetType.UNKNOWN)


def get_expected_types_for_field(field_name: str) -> list[AssetType] | None:
    """Get expected asset types for a field name.

    Args:
        field_name: The field name (e.g., 'm_Sprite', 'audioClip', 'enemyPrefab')

    Returns:
        List of acceptable AssetTypes, or None if no expectation
    """
    for pattern, types in FIELD_NAME_TO_EXPECTED_TYPES:
        if pattern.search(field_name):
            return types
    return None


def validate_asset_type_for_field(
    field_name: str,
    asset_path: str,
    asset_type: AssetType,
) -> None:
    """Validate that an asset type is compatible with a field.

    Args:
        field_name: The field name being set
        asset_path: The asset path (for error messages)
        asset_type: The actual asset type

    Raises:
        AssetTypeMismatchError: If the type doesn't match expectations
    """
    expected_types = get_expected_types_for_field(field_name)

    if expected_types is None:
        # No expectation for this field, allow anything
        return

    if asset_type in expected_types:
        return

    # Special case: SPRITE can be used where TEXTURE is expected
    if asset_type == AssetType.SPRITE and AssetType.TEXTURE in expected_types:
        return

    # Special case: TEXTURE can be used where SPRITE is expected
    if asset_type == AssetType.TEXTURE and AssetType.SPRITE in expected_types:
        return

    raise AssetTypeMismatchError(
        field_name=field_name,
        asset_path=asset_path,
        expected_types=expected_types,
        actual_type=asset_type,
    )


# Standard fileIDs for different asset types
ASSET_TYPE_FILE_IDS: dict[str, int] = {
    # Scripts
    ".cs": 11500000,
    # Textures/Sprites
    ".png": 21300000,  # Sprite (Single mode default)
    ".jpg": 21300000,
    ".jpeg": 21300000,
    ".tga": 21300000,
    ".psd": 21300000,
    ".tiff": 21300000,
    ".gif": 21300000,
    ".bmp": 21300000,
    ".exr": 21300000,
    ".hdr": 21300000,
    # Audio
    ".wav": 8300000,
    ".mp3": 8300000,
    ".ogg": 8300000,
    ".aiff": 8300000,
    ".aif": 8300000,
    ".flac": 8300000,
    # Materials
    ".mat": 2100000,
    # Animations
    ".anim": 7400000,
    ".controller": 9100000,
    # Fonts
    ".ttf": 12800000,
    ".otf": 12800000,
    ".fon": 12800000,
    # Shaders
    ".shader": 4800000,
    ".shadergraph": 11400000,
    # ScriptableObjects
    ".asset": 11400000,
    # Text/Data
    ".txt": 4900000,
    ".json": 4900000,
    ".xml": 4900000,
    ".bytes": 4900000,
    ".csv": 4900000,
    # Models (main mesh)
    ".fbx": 10000,  # Mesh fileID varies, but ~100000 for main mesh
    ".obj": 10000,
    ".blend": 10000,
    # Video
    ".mp4": 32900000,
    ".webm": 32900000,
    ".mov": 32900000,
    # Prefabs - need special handling
    ".prefab": None,  # Requires parsing the prefab
}

# Reference type values
REF_TYPE_SERIALIZED = 2  # Serialized Unity asset (.mat, .anim, .controller, .asset, .playable, etc.)
REF_TYPE_IMPORTED = 3  # Imported asset processed by importer (.cs, .png, .wav, .fbx, etc.)

_SERIALIZED_ASSET_EXTENSIONS = frozenset(
    {
        ".mat",
        ".anim",
        ".controller",
        ".overrideController",
        ".asset",
        ".playable",
        ".shadergraph",
        ".shadersubgraph",
        ".prefab",
        ".unity",
        ".lighting",
        ".signal",
        ".mixer",
        ".preset",
        ".brush",
        ".guiskin",
        ".fontsettings",
        ".cubemap",
        ".rendertexture",
        ".flare",
        ".physicmaterial",
        ".physicsmaterial2d",
        ".mask",
        ".terrainlayer",
        ".spriteatlas",
    }
)


def _get_ref_type(suffix: str) -> int:
    return REF_TYPE_SERIALIZED if suffix in _SERIALIZED_ASSET_EXTENSIONS else REF_TYPE_IMPORTED


@dataclass
class AssetResolveResult:
    """Result of resolving an asset path to a Unity reference."""

    file_id: int
    guid: str
    ref_type: int = REF_TYPE_IMPORTED
    asset_path: str | None = None
    sub_asset: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to Unity reference dictionary format."""
        return {
            "fileID": self.file_id,
            "guid": self.guid,
            "type": self.ref_type,
        }


def is_asset_reference(value: str) -> bool:
    """Check if a value is an asset reference (starts with @)."""
    return isinstance(value, str) and value.startswith("@")


def is_internal_reference(value: str) -> bool:
    """Check if a value is an internal reference (starts with #).

    Internal references point to objects/components within the same file.
    Examples:
        "#Player/Child/Button"  -> Button component on Player/Child
        "#Canvas/Panel"         -> Panel GameObject under Canvas
    """
    return isinstance(value, str) and value.startswith("#")


def parse_internal_reference(value: str) -> tuple[str, str | None]:
    """Parse an internal reference into path and optional component type.

    Args:
        value: Internal reference string (e.g., "#Player/Child/Button")

    Returns:
        Tuple of (object_path, component_type or None)

    Examples:
        "#Player/Child/Button" -> ("Player/Child", "Button")
        "#Canvas/Panel" -> ("Canvas/Panel", None)
    """
    if not value.startswith("#"):
        return value, None

    path = value[1:]  # Remove # prefix

    # Check if path contains a component type at the end
    # Component types are capitalized (e.g., Button, Image, Transform)
    parts = path.rsplit("/", 1)
    if len(parts) == 2:
        parent, last = parts
        # If last part looks like a component type (PascalCase)
        # and not a typical GameObject name pattern
        if last and last[0].isupper() and not last.startswith("_"):
            # Check if it's a known Unity component type
            known_components = {
                "Transform",
                "RectTransform",
                "Button",
                "Image",
                "Text",
                "TextMeshProUGUI",
                "Canvas",
                "CanvasGroup",
                "CanvasRenderer",
                "GraphicRaycaster",
                "ScrollRect",
                "Slider",
                "Toggle",
                "InputField",
                "Dropdown",
                "RawImage",
                "Mask",
                "LayoutGroup",
                "HorizontalLayoutGroup",
                "VerticalLayoutGroup",
                "GridLayoutGroup",
                "ContentSizeFitter",
                "AspectRatioFitter",
                "Animator",
                "Animation",
                "AudioSource",
                "SpriteRenderer",
                "BoxCollider",
                "BoxCollider2D",
                "Rigidbody",
                "Rigidbody2D",
                "Camera",
                "Light",
            }
            if last in known_components:
                return parent, last
            # For MonoBehaviour scripts, they can have any PascalCase name
            # Heuristic: if it ends with common script suffixes
            if any(
                last.endswith(suffix) for suffix in ["Controller", "Manager", "Handler", "View", "Model", "Component"]
            ):
                return parent, last

    return path, None


def parse_asset_reference(value: str) -> tuple[str, str | None]:
    """Parse an asset reference into path and optional sub-asset.

    Args:
        value: Asset reference string (e.g., "@Assets/Sprites/atlas.png:idle_0")

    Returns:
        Tuple of (asset_path, sub_asset_name or None)

    Examples:
        "@Assets/Scripts/Player.cs" -> ("Assets/Scripts/Player.cs", None)
        "@Assets/Sprites/atlas.png:idle_0" -> ("Assets/Sprites/atlas.png", "idle_0")
    """
    if not value.startswith("@"):
        return value, None

    path = value[1:]  # Remove @ prefix

    # Check for sub-asset separator (:)
    if ":" in path:
        # Find the last colon that's after the file extension
        # This handles Windows paths like C:\path\file.png
        parts = path.rsplit(":", 1)
        # Verify the first part looks like a file path (has extension)
        if "." in parts[0]:
            return parts[0], parts[1]

    return path, None


def get_guid_from_meta(meta_path: Path) -> str | None:
    """Extract GUID from a .meta file.

    Args:
        meta_path: Path to the .meta file

    Returns:
        GUID string or None if not found
    """
    try:
        content = meta_path.read_text(encoding="utf-8")
        match = META_GUID_PATTERN.search(content)
        if match:
            return match.group(1)
    except OSError:
        pass
    return None


def get_sprite_file_id(meta_path: Path, sub_sprite_name: str | None = None) -> int | None:
    """Get the fileID for a sprite reference.

    Args:
        meta_path: Path to the sprite's .meta file
        sub_sprite_name: For Multiple mode, the name of the sub-sprite

    Returns:
        fileID or None if not found
    """
    try:
        content = meta_path.read_text(encoding="utf-8")
    except OSError:
        return None

    # Check sprite mode
    sprite_mode_match = re.search(r"^\s*spriteMode:\s*(\d+)", content, re.MULTILINE)
    sprite_mode = int(sprite_mode_match.group(1)) if sprite_mode_match else 1

    if sprite_mode == 1:  # Single mode
        return 21300000

    if sprite_mode == 2:  # Multiple mode
        if sub_sprite_name:
            # Look up in internalIDToNameTable
            pattern = re.compile(
                r"-\s+first:\s*\n\s+213:\s*(-?\d+)\s*\n\s+second:\s*" + re.escape(sub_sprite_name),
                re.MULTILINE,
            )
            match = pattern.search(content)
            if match:
                return int(match.group(1))

            # Also try spriteSheet.sprites section
            sprite_pattern = re.compile(
                r"name:\s*" + re.escape(sub_sprite_name) + r".*?internalID:\s*(-?\d+)",
                re.DOTALL,
            )
            match = sprite_pattern.search(content)
            if match:
                return int(match.group(1))

            return None
        else:
            # Return first sprite's ID
            pattern = re.compile(
                r"-\s+first:\s*\n\s+213:\s*(-?\d+)",
                re.MULTILINE,
            )
            match = pattern.search(content)
            if match:
                return int(match.group(1))

    return 21300000  # Fallback


def get_prefab_root_file_id(prefab_path: Path) -> int | None:
    """Get the root GameObject's fileID from a prefab.

    Args:
        prefab_path: Path to the .prefab file

    Returns:
        fileID of the root GameObject, or None if not found
    """
    try:
        content = prefab_path.read_text(encoding="utf-8")
    except OSError:
        return None

    # Find all GameObject declarations and their transforms
    # Pattern: --- !u!1 &<fileID>
    game_objects: list[int] = []
    pattern = re.compile(r"^--- !u!1 &(\d+)", re.MULTILINE)
    for match in pattern.finditer(content):
        game_objects.append(int(match.group(1)))

    if not game_objects:
        return None

    # The root is typically the first GameObject, but let's verify
    # by checking which GameObject has no parent Transform
    # For simplicity, return the first one (most prefabs have root first)
    return game_objects[0]


def resolve_asset_reference(
    value: str,
    project_root: Path | None = None,
    auto_generate_meta: bool = True,
    guid_index: Any = None,
) -> AssetResolveResult | None:
    """Resolve an asset reference to a Unity reference.

    Args:
        value: Asset reference string (e.g., "@Assets/Scripts/Player.cs")
        project_root: Unity project root for resolving relative paths
        auto_generate_meta: If True, automatically generate .meta file if missing
        guid_index: Optional GUIDIndex/LazyGUIDIndex for GUID lookup without filesystem

    Returns:
        AssetResolveResult with fileID and guid, or None if resolution failed
    """
    import logging

    logger = logging.getLogger(__name__)

    if not is_asset_reference(value):
        return None

    asset_path, sub_asset = parse_asset_reference(value)
    normalized_path = asset_path.replace("\\", "/")

    suffix = Path(normalized_path).suffix.lower()
    ref_type = _get_ref_type(suffix)

    if guid_index:
        guid = guid_index.get_guid(Path(normalized_path))
        if guid:
            file_id = _resolve_file_id_for_asset(suffix, sub_asset, normalized_path, project_root)
            if file_id is not None:
                return AssetResolveResult(
                    file_id=file_id,
                    guid=guid,
                    ref_type=ref_type,
                    asset_path=normalized_path,
                    sub_asset=sub_asset,
                )

    if project_root:
        full_path = project_root / normalized_path
    else:
        full_path = Path(normalized_path)

    meta_path = Path(str(full_path) + ".meta")

    if not meta_path.is_file():
        if auto_generate_meta and full_path.is_file():
            from unityflow.meta_generator import generate_meta_file

            try:
                generate_meta_file(full_path)
                logger.info(f"Auto-generated .meta file for: {normalized_path}")
            except Exception as e:
                logger.warning(f"Failed to auto-generate .meta for {normalized_path}: {e}")
                return None
        else:
            return None

    guid = get_guid_from_meta(meta_path)
    if not guid:
        return None

    file_id = _resolve_file_id_for_asset(suffix, sub_asset, normalized_path, project_root)
    if file_id is None:
        return None

    return AssetResolveResult(
        file_id=file_id,
        guid=guid,
        ref_type=ref_type,
        asset_path=normalized_path,
        sub_asset=sub_asset,
    )


def _resolve_file_id_for_asset(
    suffix: str,
    sub_asset: str | None,
    asset_path: str,
    project_root: Path | None,
) -> int | None:
    if project_root:
        full_path = project_root / asset_path
    else:
        full_path = Path(asset_path)
    meta_path = Path(str(full_path) + ".meta")

    if suffix in SPRITE_EXTENSIONS:
        return get_sprite_file_id(meta_path, sub_asset)

    if suffix == ".prefab":
        return get_prefab_root_file_id(full_path)

    if suffix in ASSET_TYPE_FILE_IDS:
        if sub_asset:
            if sub_asset.startswith("fileID="):
                return int(sub_asset[7:])
            return _resolve_name_to_file_id(meta_path, sub_asset)
        return ASSET_TYPE_FILE_IDS[suffix]

    if sub_asset:
        if sub_asset.startswith("fileID="):
            return int(sub_asset[7:])
        return _resolve_name_to_file_id(meta_path, sub_asset)
    return _get_main_object_file_id(meta_path)


def _compute_nested_file_id(prefab_instance_id: int, source_object_id: int) -> int:
    """Compute the local fileID for an object inside a PrefabInstance.

    Unity XORs the PrefabInstance's fileID with the source object's fileID
    to produce a deterministic, unique local identifier in the outer document.
    """
    return (prefab_instance_id ^ source_object_id) & 0x7FFFFFFFFFFFFFFF


def _ensure_stripped_entry(
    doc: Any,
    local_id: int,
    class_id: int,
    source_file_id: int,
    source_guid: str,
    pi_file_id: int,
) -> None:
    """Create a stripped YAML entry if it doesn't exist.

    Unity requires a stripped entry for each computed local fileID so it can
    resolve the reference back to the source prefab object.
    """
    if doc is None:
        return

    existing = doc.get_by_file_id(local_id)
    if existing is not None:
        content = existing.get_content()
        if content:
            content["m_PrefabInstance"] = {"fileID": pi_file_id}
            content["m_CorrespondingSourceObject"] = {"fileID": source_file_id, "guid": source_guid, "type": 3}
        return

    from unityflow.parser import UnityYAMLObject

    class_id_to_name = {1: "GameObject", 4: "Transform", 114: "MonoBehaviour", 224: "RectTransform"}
    class_name = class_id_to_name.get(class_id, "MonoBehaviour")

    obj = UnityYAMLObject(
        class_id=class_id,
        file_id=local_id,
        data={
            class_name: {
                "m_CorrespondingSourceObject": {"fileID": source_file_id, "guid": source_guid, "type": 3},
                "m_PrefabInstance": {"fileID": pi_file_id},
            }
        },
        stripped=True,
    )
    doc.add_object(obj)


def _compute_chained_file_id(ancestor_pi_ids: list[int], source_object_id: int) -> int:
    """Compute the local fileID by XOR-chaining all ancestor PrefabInstance IDs.

    For N-level nesting: localID = PI_0 ^ PI_1 ^ ... ^ PI_N ^ source_object_id
    All masked with 0x7FFFFFFFFFFFFFFF.
    """
    result = source_object_id
    for pi_id in ancestor_pi_ids:
        result ^= pi_id
    return result & 0x7FFFFFFFFFFFFFFF


def _collect_ancestor_prefab_instances(node: Any) -> list[Any]:
    """Collect all ancestor PrefabInstance nodes from innermost to outermost."""
    ancestors = []
    current = getattr(node, "parent", None)
    while current is not None:
        if getattr(current, "is_prefab_instance", False):
            ancestors.append(current)
        current = getattr(current, "parent", None)
    return ancestors


_TRANSFORM_TYPES = frozenset({"Transform", "RectTransform"})


def _resolve_ref_for_field_type(node: Any, field_type: str | None) -> tuple[int, int]:
    """Resolve the fileID and class_id for a node based on C# field type.

    - None/Transform/RectTransform → Transform/RectTransform fileID
    - GameObject → GameObject fileID
    - Other (CanvasGroup, Button, Animator, etc.) → find matching component
    """
    if field_type == "GameObject":
        return node.file_id, 1

    if field_type is None or field_type in _TRANSFORM_TYPES:
        transform_id = getattr(node, "transform_id", 0)
        if transform_id:
            is_ui = getattr(node, "is_ui", False)
            return transform_id, 224 if is_ui else 4
        return node.file_id, 1

    for comp in getattr(node, "components", []):
        comp_name = comp.script_name or comp.class_name
        if comp_name == field_type:
            return comp.file_id, comp.class_id

    transform_id = getattr(node, "transform_id", 0)
    if transform_id:
        is_ui = getattr(node, "is_ui", False)
        return transform_id, 224 if is_ui else 4
    return node.file_id, 1


def _make_ref_for_node(
    node: Any,
    doc: Any = None,
    field_type: str | None = None,
) -> dict[str, Any]:
    """Build a fileID reference dict for a hierarchy node.

    Uses field_type from C# script to select the correct component:
    - Transform/RectTransform for bare paths (default)
    - Specific component (CanvasGroup, Animator, etc.) when field_type matches
    - GameObject when field_type is "GameObject"
    """
    ref_id, ref_class_id = _resolve_ref_for_field_type(node, field_type)

    outer = getattr(node, "outer_file_id", 0)
    if outer:
        return {"fileID": outer}

    is_nested = getattr(node, "is_from_nested_prefab", False)
    if is_nested:
        ancestors = _collect_ancestor_prefab_instances(node)
        if ancestors:
            pi_ids = [a.file_id for a in ancestors]
            local_id = _compute_chained_file_id(pi_ids, ref_id)
            outermost_pi = ancestors[-1]
            inner_pi_ids = pi_ids[:-1] if len(pi_ids) > 1 else []
            corr_source_id = _compute_chained_file_id(inner_pi_ids, ref_id) if inner_pi_ids else ref_id
            _ensure_stripped_entry(
                doc,
                local_id,
                ref_class_id,
                corr_source_id,
                outermost_pi.source_guid,
                outermost_pi.file_id,
            )
            return {"fileID": local_id}

    return {"fileID": ref_id}


def _make_ref_for_component(comp: Any, parent_node: Any, doc: Any = None) -> dict[str, Any]:
    """Build a fileID reference dict for a component on a hierarchy node."""
    is_nested = getattr(parent_node, "is_from_nested_prefab", False)
    if is_nested:
        ancestors = _collect_ancestor_prefab_instances(parent_node)
        if ancestors:
            pi_ids = [a.file_id for a in ancestors]
            local_id = _compute_chained_file_id(pi_ids, comp.file_id)
            outermost_pi = ancestors[-1]
            inner_pi_ids = pi_ids[:-1] if len(pi_ids) > 1 else []
            corr_source_id = _compute_chained_file_id(inner_pi_ids, comp.file_id) if inner_pi_ids else comp.file_id
            _ensure_stripped_entry(
                doc,
                local_id,
                comp.class_id,
                corr_source_id,
                outermost_pi.source_guid,
                outermost_pi.file_id,
            )
            return {"fileID": local_id}

    return {"fileID": comp.file_id}


def resolve_internal_reference(
    value: str,
    doc: Any,
    hierarchy: Any,
    field_type: str | None = None,
) -> dict[str, Any]:
    """Resolve an internal # reference to a fileID dict.

    Resolution strategy:
    1. Try the full path as a GameObject path
    2. If not found, split last segment as component type on its parent

    When field_type is "GameObject", returns the GameObject fileID instead of
    the default Transform/RectTransform.
    """
    raw_path = value[1:] if value.startswith("#") else value

    target_node = hierarchy.find(raw_path)
    if target_node is not None:
        return _make_ref_for_node(target_node, doc=doc, field_type=field_type)

    parts = raw_path.rsplit("/", 1)
    if len(parts) == 2:
        parent_path, comp_spec = parts
        parent_node = hierarchy.find(parent_path)
        if parent_node is not None:
            import re

            idx_match = re.match(r"^(.+)\[(\d+)\]$", comp_spec)
            if idx_match:
                comp_name = idx_match.group(1)
                comp_index = int(idx_match.group(2))
            else:
                comp_name = comp_spec
                comp_index = None

            if comp_name in ("Transform", "RectTransform"):
                return _make_ref_for_node(parent_node, doc=doc, field_type=comp_name)

            matches = []
            for comp in parent_node.components:
                name = comp.script_name or comp.class_name
                if name == comp_name:
                    matches.append(comp)

            if matches:
                if comp_index is not None:
                    if comp_index < len(matches):
                        return _make_ref_for_component(matches[comp_index], parent_node, doc=doc)
                    raise ValueError(
                        f"Component index [{comp_index}] out of range. "
                        f"Found {len(matches)} '{comp_name}' on '{parent_path}'"
                    )
                return _make_ref_for_component(matches[0], parent_node, doc=doc)

            raise ValueError(f"Component '{comp_name}' not found on '{parent_path}'")

    raise ValueError(f"Internal reference not found: {raw_path}")


_UNITY_BUILTIN_TYPES = frozenset(
    {
        "GameObject",
        "Transform",
        "RectTransform",
        "Object",
        "Sprite",
        "Texture2D",
        "Material",
        "Mesh",
        "AudioClip",
        "AnimationClip",
        "RuntimeAnimatorController",
        "Font",
        "Shader",
        "TextAsset",
        "ScriptableObject",
    }
)


def _try_resolve_prefab_component(
    result: AssetResolveResult,
    field_type: str,
    project_root: Path | None,
    guid_index: Any,
) -> dict[str, Any] | None:
    """Try to resolve a prefab asset reference to a specific component inside.

    When field_type is a MonoBehaviour (not a Unity built-in type), the reference
    should point to the component inside the prefab, not the prefab asset itself.
    """
    if field_type in _UNITY_BUILTIN_TYPES:
        return None

    from unityflow.hierarchy import Hierarchy
    from unityflow.parser import UnityYAMLDocument

    prefab_path = None
    if project_root and result.asset_path:
        prefab_path = project_root / result.asset_path
    if prefab_path is None or not prefab_path.exists():
        return None

    try:
        source_doc = UnityYAMLDocument.load(prefab_path)
        source_hier = Hierarchy.build(source_doc, guid_index=guid_index)
    except Exception:
        return None

    for root in source_hier.root_objects:
        for comp in root.components:
            comp_name = comp.script_name or comp.class_name
            if comp_name == field_type:
                return {
                    "fileID": comp.file_id,
                    "guid": result.guid,
                    "type": REF_TYPE_SERIALIZED,
                }

    return None


def resolve_value(
    value: Any,
    project_root: Path | None = None,
    field_name: str | None = None,
    doc: Any = None,
    hierarchy: Any = None,
    guid_index: Any = None,
    field_type: str | None = None,
    script_info: Any = None,
) -> Any:
    """Resolve a value, converting asset/internal references to Unity reference dicts.

    Recursively processes dicts and lists, converting any string values
    that start with @ to asset references or # to internal references.

    Args:
        value: Value to process
        project_root: Unity project root for resolving relative paths
        field_name: The field name being set (for type validation)
        doc: UnityYAMLDocument (required for # internal references)
        hierarchy: Hierarchy instance (required for # internal references)
        guid_index: Optional GUIDIndex/LazyGUIDIndex for GUID lookup

    Returns:
        Processed value with references resolved

    Raises:
        ValueError: If a reference cannot be resolved
        AssetTypeMismatchError: If the asset type doesn't match the field type
    """
    if isinstance(value, str):
        if value in ("", "None"):
            return {"fileID": 0}

        if is_asset_reference(value):
            result = resolve_asset_reference(value, project_root, guid_index=guid_index)
            if result is None:
                raise ValueError(f"Could not resolve asset reference: {value}")

            if field_name and result.asset_path:
                suffix = Path(result.asset_path).suffix.lower()
                asset_type = get_asset_type_from_extension(suffix)
                validate_asset_type_for_field(field_name, result.asset_path, asset_type)

            if field_type and result.asset_path and Path(result.asset_path).suffix.lower() == ".prefab":
                component_ref = _try_resolve_prefab_component(
                    result,
                    field_type,
                    project_root,
                    guid_index,
                )
                if component_ref is not None:
                    return component_ref

            return result.to_dict()

        if is_internal_reference(value):
            if doc is None or hierarchy is None:
                raise ValueError(f"Internal reference '{value}' requires document context")
            return resolve_internal_reference(value, doc, hierarchy, field_type=field_type)

        return value

    elif isinstance(value, dict):
        result = {}
        for k, v in value.items():
            ft = None
            if script_info:
                for f in script_info.fields:
                    if f.unity_name == k:
                        ft = f.field_type
                        break
            result[k] = resolve_value(
                v,
                project_root,
                field_name=k,
                doc=doc,
                hierarchy=hierarchy,
                guid_index=guid_index,
                field_type=ft,
                script_info=script_info,
            )
        return result

    elif isinstance(value, list):
        return [
            resolve_value(item, project_root, field_name, doc=doc, hierarchy=hierarchy, guid_index=guid_index)
            for item in value
        ]

    return value


def get_asset_info(
    asset_path: str,
    project_root: Path | None = None,
) -> dict[str, Any] | None:
    """Get detailed information about an asset.

    Args:
        asset_path: Path to the asset (without @ prefix)
        project_root: Unity project root

    Returns:
        Dictionary with asset info, or None if not found
    """
    if project_root:
        full_path = project_root / asset_path
    else:
        full_path = Path(asset_path)

    meta_path = Path(str(full_path) + ".meta")

    if not meta_path.is_file():
        return None

    guid = get_guid_from_meta(meta_path)
    if not guid:
        return None

    suffix = full_path.suffix.lower()
    info: dict[str, Any] = {
        "path": asset_path,
        "guid": guid,
        "type": suffix[1:] if suffix else "unknown",
    }

    # Add sprite-specific info
    if suffix in (".png", ".jpg", ".jpeg", ".tga", ".psd"):
        try:
            content = meta_path.read_text(encoding="utf-8")
            mode_match = re.search(r"^\s*spriteMode:\s*(\d+)", content, re.MULTILINE)
            if mode_match:
                mode = int(mode_match.group(1))
                info["spriteMode"] = "Single" if mode == 1 else "Multiple" if mode == 2 else "None"

                if mode == 2:
                    # Extract sub-sprite names
                    sub_sprites: list[str] = []
                    pattern = re.compile(
                        r"-\s+first:\s*\n\s+213:\s*(-?\d+)\s*\n\s+second:\s*(\S+)",
                        re.MULTILINE,
                    )
                    for match in pattern.finditer(content):
                        sub_sprites.append(match.group(2))
                    info["subSprites"] = sub_sprites
        except OSError:
            pass

    return info


def _is_reference_dict(value: Any) -> bool:
    return isinstance(value, dict) and "fileID" in value


SPRITE_EXTENSIONS = frozenset((".png", ".jpg", ".jpeg", ".tga", ".psd", ".tiff", ".gif", ".bmp"))


_INTERNAL_ID_PATTERN = re.compile(
    r"-\s+first:\s*\n\s+(\d+):\s*(-?\d+)\s*\n\s+second:\s*(.+)",
    re.MULTILINE,
)


def _parse_internal_id_table(content: str) -> dict[int, str]:
    result: dict[int, str] = {}
    for match in _INTERNAL_ID_PATTERN.finditer(content):
        file_id = int(match.group(2))
        name = match.group(3).strip()
        result[file_id] = name
    return result


def _resolve_sub_object_name(file_id: int, suffix: str, asset_path: Path, project_root: Path) -> str | None:
    meta_path = (project_root / asset_path.as_posix()).with_suffix(suffix + ".meta")
    if suffix in SPRITE_EXTENSIONS:
        from unityflow.sprite import parse_sprite_meta

        info = parse_sprite_meta(meta_path)
        if info and info.is_multiple:
            id_to_name = {v: k for k, v in info.internal_id_table.items()}
            return id_to_name.get(file_id)
        return None
    try:
        content = meta_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return _parse_internal_id_table(content).get(file_id)


def _resolve_name_to_file_id(meta_path: Path, sub_asset_name: str) -> int | None:
    try:
        content = meta_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    for match in _INTERNAL_ID_PATTERN.finditer(content):
        name = match.group(3).strip()
        if name == sub_asset_name:
            return int(match.group(2))
    return None


def _get_main_object_file_id(meta_path: Path) -> int | None:
    try:
        content = meta_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    match = re.search(r"mainObjectFileID:\s*(-?\d+)", content)
    if match:
        return int(match.group(1))
    return None


def _humanize_single_reference(
    ref: dict[str, Any],
    guid_index: Any,
    hierarchy: Any | None,
    project_root: Path | None,
) -> Any:
    file_id = ref.get("fileID", 0)
    guid = ref.get("guid", "")

    if file_id == 0 and not guid:
        return ""

    if guid:
        asset_path = guid_index.get_path(guid) if guid_index else None
        if asset_path is None:
            return ref

        posix_path = asset_path.as_posix()
        suffix = asset_path.suffix.lower()

        standard_id = ASSET_TYPE_FILE_IDS.get(suffix)
        if standard_id is not None and file_id == standard_id:
            return f"@{posix_path}"
        if suffix not in ASSET_TYPE_FILE_IDS:
            if project_root and file_id:
                meta_path = (project_root / posix_path).with_suffix(suffix + ".meta")
                main_id = _get_main_object_file_id(meta_path)
                if main_id is not None and file_id != main_id:
                    name = _resolve_sub_object_name(file_id, suffix, asset_path, project_root)
                    if name:
                        return f"@{posix_path}:{name}"
                    return f"@{posix_path}:fileID={file_id}"
            return f"@{posix_path}"

        if project_root and file_id != standard_id:
            name = _resolve_sub_object_name(file_id, suffix, asset_path, project_root)
            if name:
                return f"@{posix_path}:{name}"
            return f"@{posix_path}:fileID={file_id}"

        return f"@{posix_path}"

    if file_id and hierarchy:
        ref_node = hierarchy._nodes_by_file_id.get(file_id)
        if ref_node:
            return f"#{ref_node.path}"

        for n in hierarchy.iter_all():
            if n.outer_file_id == file_id:
                return f"#{n.path}"
            if n.outer_transform_id == file_id:
                t_type = "RectTransform" if n.is_ui else "Transform"
                return f"#{n.path}/{t_type}"
            for c in n.components:
                if c.file_id == file_id:
                    return f"#{n.path}/{c.script_name or c.class_name}"

        resolved_node = hierarchy.resolve_game_object(file_id)
        if resolved_node:
            return f"#{resolved_node.path}"

        return ref

    return ref


def humanize_references(
    value: Any,
    guid_index: Any,
    hierarchy: Any | None = None,
    project_root: Path | None = None,
) -> Any:
    if _is_reference_dict(value):
        return _humanize_single_reference(value, guid_index, hierarchy, project_root)

    if isinstance(value, dict):
        return {k: humanize_references(v, guid_index, hierarchy, project_root) for k, v in value.items()}

    if isinstance(value, list):
        return [humanize_references(item, guid_index, hierarchy, project_root) for item in value]

    return value
