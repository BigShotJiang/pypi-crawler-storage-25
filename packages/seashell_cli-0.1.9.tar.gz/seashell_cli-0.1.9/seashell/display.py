"""Output formatting for query results."""

import json
import sys


def infer_action(query_text):
    """Infer the action type from a GQL query string."""
    q = query_text.strip().upper()
    if q.startswith("LIST PATIENTS"): return "list_patients"
    if q.startswith("LIST GENES"): return "list_genes"
    if q.startswith("COUNT VARIANTS"): return "count_variants"
    if q.startswith("COUNT PATIENTS"): return "count_patients"
    if q.startswith("FIND VARIANTS"): return "find_variants"
    if q.startswith("FIND PATIENTS"): return "find_patients"
    if q.startswith("FIND SIMILAR"): return "find_similar"
    if q.startswith("COMPARE"): return "compare_patients"
    if q.startswith("DIFF"): return "diff_patients"
    if q.startswith("PCA"): return "pca"
    if q.startswith("COVERAGE"): return "coverage"
    if q.startswith("QC"): return "qc"
    if q.startswith("FLAGSTAT"): return "flagstat"
    if q.startswith("CYCLE_QUALITY"): return "cycle_quality"
    if q.startswith("INSERT_SIZE"): return "insert_size"
    if q.startswith("SEXCHECK"): return "sexcheck"
    if q.startswith("KINSHIP COHORT"): return "kinship_cohort"
    if q.startswith("KINSHIP TRIO"): return "kinship_trio"
    if q.startswith("KINSHIP"): return "kinship_cohort"
    if q.startswith("CONTAMINATION"): return "contamination"
    if q.startswith("ANCESTRY"): return "ancestry"
    if q.startswith("MENDELIAN"): return "mendelian_trio"
    if q.startswith("PILEUP"): return "pileup"
    if q.startswith("DELETE PATIENT"): return "delete_patient"
    if q.startswith("LET "): return "let_cohort"
    if q.startswith("LIST COHORTS"): return "list_cohorts"
    if q.startswith("SHOW COHORT"): return "show_cohort"
    if q.startswith("DROP COHORT"): return "drop_cohort"
    if q.startswith("GWAS"): return "gwas"
    return ""


def display_result(result, output_format="table", action=None):
    """Display a query result in the requested format."""
    if "error" in result:
        sys.stderr.write("Error: %s\n" % result["error"])
        return

    if output_format == "json":
        print(json.dumps(result, indent=2))
        return

    if output_format == "tsv":
        _print_tsv(result)
        return

    # Use explicit action if provided, otherwise try to read from result
    if action is None:
        action = result.get("action", "")
    latency = result.get("latency_ms", "?")

    if action == "compare_patients":
        _print_compare(result, latency)
    elif action == "find_similar":
        _print_similar(result, latency)
    elif action in ("list_patients", "find_patients", "count_patients"):
        _print_patients(result, action, latency)
    elif action in ("find_variants", "count_variants"):
        _print_variants(result, action, latency)
    elif action == "list_genes":
        print("\n  %s genes loaded" % result.get("count", "?"))
        print("  %s ms" % latency)
    elif action == "diff_patients":
        _print_diff(result, latency)
    elif action == "pca":
        _print_pca(result, latency)
    elif action == "coverage":
        _print_coverage(result, latency)
    elif action == "qc":
        _print_qc(result, latency)
    elif action == "flagstat":
        _print_flagstat(result, latency)
    elif action == "cycle_quality":
        _print_cycle_quality(result, latency)
    elif action == "insert_size":
        _print_insert_size(result, latency)
    elif action == "sexcheck":
        _print_sexcheck(result, latency)
    elif action == "kinship_cohort":
        _print_kinship_cohort(result, latency)
    elif action == "kinship_trio":
        _print_kinship_trio(result, latency)
    elif action == "contamination":
        _print_contamination(result, latency)
    elif action == "ancestry":
        _print_ancestry(result, latency)
    elif action == "mendelian_trio":
        _print_mendelian_trio(result, latency)
    elif action == "pileup":
        _print_pileup(result, latency)
    elif action == "delete_patient":
        print("\n  Patient %s deleted." % result.get("patient_id", "?"))
        print("  %s ms" % latency)
    elif action == "let_cohort":
        _print_let_cohort(result, latency)
    elif action == "list_cohorts":
        _print_list_cohorts(result, latency)
    elif action == "show_cohort":
        _print_show_cohort(result, latency)
    elif action == "drop_cohort":
        print("\n  Cohort '%s' dropped." % result.get("cohort_name", "?"))
        print("  %s ms" % latency)
    elif action == "gwas":
        _print_gwas_complete(result)
    else:
        print(json.dumps(result, indent=2))


def _print_compare(result, latency):
    print("\n  %s vs %s" % (result.get("patient_a", "?"), result.get("patient_b", "?")))
    print("  Jaccard similarity:      %s" % result.get("jaccard_similarity", "?"))
    shared = result.get("shared_variants_estimate", result.get("shared_variants", "?"))
    print("  Shared variants (est):   %s" % shared)
    unique_a = result.get("unique_to_a_estimate", result.get("unique_to_a", "?"))
    unique_b = result.get("unique_to_b_estimate", result.get("unique_to_b", "?"))
    print("  Unique to A (est):       %s" % unique_a)
    print("  Unique to B (est):       %s" % unique_b)
    if result.get("note"):
        print("  Note: %s" % result["note"])
    print("\n  %s ms" % latency)


def _print_similar(result, latency):
    print("\n  Most similar to %s:\n" % result.get("patient", "?"))
    print("  %-15s %10s" % ("PATIENT", "JACCARD"))
    print("  %s %s" % ("-" * 15, "-" * 10))
    for r in result.get("results", []):
        print("  %-15s %10s" % (r["patient_id"], r["jaccard_similarity"]))
    print("\n  %s results | %s ms" % (result.get("count", 0), latency))


def _print_patients(result, action, latency):
    results = result.get("results", [])
    count = result.get("count", 0)
    total = result.get("total", count)

    if action == "count_patients":
        print("\n  %s of %s patients" % (count, total))
        print("  %s ms" % latency)
        return

    if not results:
        print("\n  0 patients found | %s ms" % latency)
        return

    has_variants = "variants" in results[0]
    has_matching = "matching_variants" in results[0]
    has_parent = "parent" in results[0]

    print()
    if has_variants and has_parent:
        print("  %-15s %10s %-15s" % ("PATIENT", "VARIANTS", "PARENT"))
        print("  %s %s %s" % ("-" * 15, "-" * 10, "-" * 15))
        for r in results:
            parent = r.get("parent") or "GRCh38"
            print("  %-15s %10s %-15s" % (r["patient_id"], r["variants"], parent))
    elif has_matching:
        print("  %-15s %10s" % ("PATIENT", "MATCHING"))
        print("  %s %s" % ("-" * 15, "-" * 10))
        for r in results:
            print("  %-15s %10s" % (r["patient_id"], r["matching_variants"]))
    else:
        print("  %-15s" % "PATIENT")
        print("  %s" % ("-" * 15))
        for r in results:
            print("  %-15s" % r["patient_id"])

    print("\n  %s patients | %s ms" % (count, latency))


def _print_variants(result, action, latency):
    results = result.get("results", [])
    count = result.get("count", 0)

    if action == "count_variants":
        print("\n  %s variants" % count)
        print("  %s ms" % latency)
        return

    if not results:
        print("\n  0 variants found | %s ms" % latency)
        return

    has_sig = any("significance" in r for r in results)
    has_gene = any("gene" in r for r in results)
    has_rs = any("rs_id" in r for r in results)

    print()
    header = "  %-8s %12s %-6s %-6s" % ("CHROM", "POS", "REF", "ALT")
    if has_gene:
        header += " %-12s" % "GENE"
    if has_sig:
        header += " %-20s" % "SIGNIFICANCE"
    if has_rs:
        header += " %-15s" % "RS_ID"
    print(header)
    print("  %s" % ("-" * (len(header) - 2)))

    for r in results:
        line = "  %-8s %12s %-6s %-6s" % (
            r.get("chrom", ""), r.get("pos", 0), r.get("ref", ""), r.get("alt", ""))
        if has_gene:
            line += " %-12s" % r.get("gene", "")
        if has_sig:
            line += " %-20s" % r.get("significance", "")
        if has_rs:
            line += " %-15s" % r.get("rs_id", "")
        print(line)

    print("\n  %s variants | %s ms" % (count, latency))


def _print_diff(result, latency):
    a = result.get("patient_a", "?")
    b = result.get("patient_b", "?")
    shared_count = result.get("shared_count", 0)
    unique_a_count = result.get("unique_to_a_count", 0)
    unique_b_count = result.get("unique_to_b_count", 0)
    truncated = result.get("truncated", False)

    print("\n  %s vs %s" % (a, b))
    print("  %s %12s variants" % ("Only in " + a + ":", "{:,}".format(unique_a_count)))
    print("  %s %12s variants" % ("Only in " + b + ":", "{:,}".format(unique_b_count)))
    print("  %s %12s variants" % ("Shared:" + " " * (len(a) + len(b) - 1), "{:,}".format(shared_count)))

    # Show a SAMPLE of shared variants — first PAGE_SIZE entries.
    # Rest is cached and accessed via `more` command.
    shared_sample = result.get("shared", [])
    if shared_sample:
        page_size = 25
        total_in_response = len(shared_sample)
        first_page = shared_sample[:page_size]
        print("\n  Shared variants (showing %d of %s):" % (
            len(first_page), "{:,}".format(shared_count)))
        _print_variant_table(first_page)
        remaining_in_cache = total_in_response - page_size
        if remaining_in_cache > 0:
            print('\n  Type "more" to see all')
        elif truncated:
            print('\n  Add LIMIT N to your query (e.g., LIMIT 1000) to see more.')

    print("\n  %s ms" % latency)


def _truncate(s, n):
    """Truncate a string to n chars with ellipsis."""
    if not isinstance(s, str):
        return str(s)
    if len(s) <= n:
        return s
    return s[:n - 1] + "…"


def _print_variant_table(rows):
    """Print a list of variant dicts as a table."""
    header = "  %-8s %12s %-6s %-6s %-12s" % ("CHROM", "POS", "REF", "ALT", "GENE")
    print(header)
    print("  %s" % ("-" * (len(header) - 2)))
    for r in rows:
        line = "  %-8s %12s %-6s %-6s %-12s" % (
            r.get("chrom", ""), r.get("pos", 0),
            _truncate(r.get("ref", ""), 6),
            _truncate(r.get("alt", ""), 6),
            r.get("gene", "—"))
        print(line)


def show_more(result, action, offset, page_size=25):
    """Show the next page of results from a cached query result.

    Returns the new offset after printing, or None if there's nothing more.
    """
    # Pick the right list field based on the action
    if action in ("find_variants", "count_variants"):
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "variants"
    elif action in ("list_patients", "find_patients", "count_patients"):
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "patients"
    elif action == "diff_patients":
        items = result.get("shared", [])
        total = result.get("shared_count", len(items))
        label = "shared variants"
    elif action == "find_similar":
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "matches"
    else:
        print("  No more results to show for this query type.")
        return None

    if offset >= len(items):
        if total > len(items):
            print("  No more cached results. The engine returned %d of %s %s — "
                  "use LIMIT to fetch more." % (len(items), "{:,}".format(total), label))
        else:
            print("  No more results.")
        return None

    end = min(offset + page_size, len(items))
    page = items[offset:end]

    print("\n  Showing %d-%d of %s %s:" % (offset + 1, end, "{:,}".format(total), label))

    if action == "diff_patients" or action in ("find_variants", "count_variants"):
        _print_variant_table(page)
    elif action in ("list_patients", "find_patients", "count_patients"):
        _print_patient_rows(page)
    elif action == "find_similar":
        for r in page:
            print("  %-15s %10s" % (r.get("patient_id", ""), r.get("jaccard_similarity", "")))

    remaining = len(items) - end
    if remaining > 0:
        print('\n  Type "more" to see all')
    elif total > len(items):
        print("\n  End of cached results. Add LIMIT N to your query to see more.")
    else:
        print("\n  End of results.")
    return end


def _print_patient_rows(rows):
    """Print patient rows in a table."""
    if not rows:
        return
    has_variants = "variants" in rows[0]
    has_parent = "parent" in rows[0]
    has_matching = "matching_variants" in rows[0]
    if has_variants and has_parent:
        print("  %-15s %10s %-15s" % ("PATIENT", "VARIANTS", "PARENT"))
        print("  %s %s %s" % ("-" * 15, "-" * 10, "-" * 15))
        for r in rows:
            parent = r.get("parent") or "GRCh38"
            print("  %-15s %10s %-15s" % (r["patient_id"], r["variants"], parent))
    elif has_matching:
        print("  %-15s %10s" % ("PATIENT", "MATCHING"))
        print("  %s %s" % ("-" * 15, "-" * 10))
        for r in rows:
            print("  %-15s %10s" % (r["patient_id"], r["matching_variants"]))
    else:
        print("  %-15s" % "PATIENT")
        print("  %s" % ("-" * 15))
        for r in rows:
            print("  %-15s" % r["patient_id"])


def _print_pca(result, latency):
    n_components = result.get("components", 3)
    results = result.get("results", [])
    n_patients = result.get("count", len(results))

    print("\n  PCA (%s components, %s patients)\n" % (n_components, n_patients))
    print("  %-15s %12s %12s %12s" % ("PATIENT", "PC1", "PC2", "PC3"))
    print("  %s %s %s %s" % ("-" * 15, "-" * 12, "-" * 12, "-" * 12))
    for r in results:
        pc1 = r.get("pc1", "")
        pc2 = r.get("pc2", "")
        pc3 = r.get("pc3", "")
        print("  %-15s %12s %12s %12s" % (r.get("patient_id", ""), pc1, pc2, pc3))

    var_explained = result.get("variance_explained", [])
    if var_explained:
        print("\n  Variance explained:")
        for i, v in enumerate(var_explained):
            print("    PC%d: %s" % (i + 1, v))

    print("\n  %s ms" % latency)


def _fmt_int(n):
    try:
        return "{:,}".format(int(n))
    except (TypeError, ValueError):
        return str(n)


def _print_coverage(result, latency):
    print()
    chrom = result.get("chrom", "?")
    rs = result.get("region_start", "?")
    re_ = result.get("region_end", "?")
    print("  Patient:        %s" % result.get("patient_id", "?"))
    print("  Region:         %s:%s-%s  (%s bp)" % (chrom, rs, re_, _fmt_int(result.get("region_length", "?"))))
    print("  Mean coverage:  %sx  (covered positions only)" % result.get("mean_coverage", "?"))
    print("  Mean coverage:  %sx  (entire region, includes 0x)" % result.get("mean_coverage_region", "?"))
    print("  Min / Max:      %sx / %sx" % (result.get("min_coverage", "?"), result.get("max_coverage", "?")))
    print("  Above 10x:      %s%%" % result.get("pct_above_10x", "?"))
    print("  Above 20x:      %s%%" % result.get("pct_above_20x", "?"))
    print("  Above 30x:      %s%%" % result.get("pct_above_30x", "?"))
    print("  Below 10x:      %s positions" % _fmt_int(result.get("positions_below_10x", "?")))
    print("  Covered:        %s positions" % _fmt_int(result.get("covered_positions", "?")))
    print("\n  %s ms" % latency)


def _print_qc(result, latency):
    print()
    total = result.get("total_reads", 0) or 0
    mapped = result.get("mapped_reads", 0) or 0
    pct_mapped = (100.0 * mapped / total) if total else 0.0
    print("  Patient:           %s" % result.get("patient_id", "?"))
    print("  Chromosome:        %s" % result.get("chrom", "?"))
    print("  Total reads:       %s" % _fmt_int(total))
    print("  Mapped:            %s  (%.1f%%)" % (_fmt_int(mapped), pct_mapped))
    print("  Unmapped:          %s" % _fmt_int(result.get("unmapped_reads", 0)))
    print("  Duplicates:        %s  (%.2f%%)" % (
        _fmt_int(result.get("duplicate_reads", 0)),
        (result.get("duplicate_rate", 0) or 0) * 100))
    print("  Secondary:         %s" % _fmt_int(result.get("secondary_reads", 0)))
    print("  Supplementary:     %s" % _fmt_int(result.get("supplementary_reads", 0)))
    print("  Properly paired:   %s  (%s%%)" % (
        _fmt_int(result.get("properly_paired", 0)),
        result.get("properly_paired_pct", "?")))
    print("  Mean MAPQ:         %s" % result.get("mean_mapping_quality", "?"))
    print("  Mean insert size:  %s ± %s" % (
        result.get("mean_insert_size", "?"),
        result.get("insert_size_std", "?")))
    print("\n  %s ms" % latency)


def _print_flagstat(result, latency):
    """Print samtools-flagstat-byte-identical output verbatim.

    The Rust engine pre-formats the 16-line samtools text in result["flagstat"];
    we just print it as-is so users can pipe it into existing scripts that
    grep / awk samtools output. The structured counter object lives in
    result["counts"] for callers that prefer JSON.
    """
    text = result.get("flagstat", "")
    if not text:
        # Engine returned only the counts dict — fall back to JSON dump
        print()
        print(json.dumps(result.get("counts", result), indent=2))
        print("\n  %s ms" % latency)
        return
    print()
    # Engine output already ends with a newline; strip and re-add for clean spacing
    print(text.rstrip())
    counts = result.get("counts", {}) or {}
    if not counts.get("unmapped_store_present", True) and counts.get("unmapped_store_count", 0):
        # The engine emits a `# note:` line itself when the unmapped store is
        # count-only; just remind the user it shows up in the output above.
        pass
    print("\n  %s ms" % latency)


def _print_cycle_quality(result, latency):
    """Print the per-cycle base-quality decay table from CYCLE_QUALITY.

    The bucket-resolution curve is computed in O(num_contexts) directly from
    `WaveletQualityStore.bv0_context_counts` — no bit decode. Each row is one
    of the 8 cycle buckets the encoder assigns (5' adapter, mid read, 3'
    adapter, etc.).
    """
    print()
    print("  Patient:      %s" % result.get("patient_id", "?"))
    print("  Chromosome:   %s" % result.get("chrom", "?"))
    top = result.get("top_symbol", "?")
    print("  Top symbol:   Q%s  (most-frequent quality value in this patient's reads)" % top)
    print()
    buckets = result.get("buckets", []) or []
    if not buckets:
        print("  No quality data available for this patient.")
        print("\n  %s ms" % latency)
        return
    print("  %-7s %-22s %14s %12s %10s" % (
        "BUCKET", "CYCLE_RANGE", "BASES", "FRAC_TOP", "MEAN_Q"))
    print("  %s %s %s %s %s" % (
        "-" * 7, "-" * 22, "-" * 14, "-" * 12, "-" * 10))
    for b in buckets:
        bn = b.get("base_count", 0) or 0
        if bn == 0:
            continue
        print("  %-7s %-22s %14s %12.4f %10.2f" % (
            b.get("bucket", ""),
            b.get("cycle_range", ""),
            _fmt_int(bn),
            b.get("frac_at_top_symbol", 0.0),
            b.get("mean_quality", 0.0),
        ))
    note = result.get("note")
    if note:
        print()
        print("  Note: %s" % note)
    print("\n  %s ms" % latency)


def _print_insert_size(result, latency):
    """Print INSERT_SIZE result. Headlines the samtools-compatible mean/std
    (which match `samtools stats` byte-for-byte) and shows the richer
    distribution stats Picard CollectInsertSizeMetrics reports.
    """
    print()
    d = result.get("distribution", {}) or {}
    print("  Patient:               %s" % result.get("patient_id", "?"))
    print("  Chromosome:            %s" % result.get("chrom", "?"))
    print("  Pair count:            %s" % _fmt_int(d.get("pair_count", 0)))
    print()
    print("  ── samtools-compatible (matches `samtools stats` byte-for-byte) ──")
    print("  Insert size mean:      %s" % d.get("samtools_mean", "?"))
    print("  Insert size std:       %s" % d.get("samtools_std", "?"))
    print()
    print("  ── richer distribution (Picard CollectInsertSizeMetrics-style) ──")
    print("  Median / Mode / MAD:   %s / %s / %s" % (
        d.get("median", "?"), d.get("mode", "?"), d.get("mad", "?")))
    print("  Mean / Std (raw):      %s / %s" % (d.get("mean", "?"), d.get("std", "?")))
    print("  Min / Max:             %s / %s" % (d.get("min", "?"), d.get("max", "?")))
    print("  Percentiles (10/25/50/75/90/95/99):")
    print("    %s   %s   %s   %s   %s   %s   %s" % (
        d.get("p10", "?"), d.get("p25", "?"), d.get("p50", "?"),
        d.get("p75", "?"), d.get("p90", "?"), d.get("p95", "?"), d.get("p99", "?")))
    cap = d.get("max_insert_size_filter", 8000)
    print()
    print("  Filter: positive TLEN, primary alignments only, same-chromosome")
    print("          mates only, clamp at %s bp (samtools default)" % cap)
    hist = d.get("histogram", []) or []
    if hist:
        print()
        print("  Histogram: %d distinct insert sizes (use FORMAT json to retrieve)" % len(hist))
    print("\n  %s ms" % latency)


def _print_sexcheck(result, latency):
    """Print SEXCHECK result. Headlines the inferred sex + confidence, then
    shows the chrX / chrY / autosomal coverage values and the normalized
    ratios that drove the classification.
    """
    print()
    r = result.get("result", {}) or {}
    sex = r.get("inferred_sex", "?")
    conf = r.get("confidence", "?")
    print("  Patient:           %s" % r.get("patient_id", result.get("patient_id", "?")))
    print()
    print("  Inferred sex:      %s    (confidence: %s)" % (sex.upper(), conf))
    print("  Note:              %s" % r.get("note", ""))
    print()
    print("  ── coverage ──")
    print("  chrX (non-PAR):    %sx   region %s" % (r.get("chrx_coverage", "?"), r.get("chrx_region", "?")))
    print("  chrY (male-spec):  %sx   region %s" % (r.get("chry_coverage", "?"), r.get("chry_region", "?")))
    print("  Autosomal (chr22): %sx   region %s" % (r.get("autosomal_coverage", "?"), r.get("autosomal_region", "?")))
    print()
    print("  ── normalized ratios (chrom / autosomal) ──")
    print("  X normalized:      %s   (peddy threshold: > 0.7 = diploid X)" % r.get("x_normalized", "?"))
    print("  Y normalized:      %s   (peddy threshold: > 0.3 = chrY present)" % r.get("y_normalized", "?"))
    print("\n  %s ms" % latency)


def _print_kinship_cohort(result, latency):
    """Print KINSHIP COHORT result. Headlines the cohort size + total pairs +
    a small distribution-by-class table, then shows the top-N highest-Jaccard
    pairs (which is the screening signal — anything unexpectedly high there
    deserves a KING follow-up).
    """
    print()
    pairs = result.get("pairs", []) or []
    cohort_size = result.get("cohort_size", "?")
    print("  Cohort size:    %s patients" % cohort_size)
    print("  Pairs computed: %s  (returned: %d)" % (
        _fmt_int(cohort_size * (cohort_size - 1) // 2 if isinstance(cohort_size, int) else "?"),
        len(pairs)))
    if result.get("min_jaccard", 0):
        print("  Filter:         Jaccard >= %s" % result["min_jaccard"])
    print()

    if not pairs:
        print("  No pairs to show.")
        print("\n  %s ms" % latency)
        return

    # Distribution by classification
    buckets = {}
    for p in pairs:
        rel = p.get("relationship", "?")
        buckets.setdefault(rel, []).append(p.get("jaccard", 0))
    print("  Distribution by relationship class:")
    for rel in ("identical_or_duplicate", "likely_first_degree",
                "borderline_or_low_diversity_pop", "unrelated_same_ancestry",
                "unrelated_or_cross_ancestry"):
        if rel not in buckets: continue
        bs = buckets[rel]
        print("    %-40s  count=%-4d  J %.4f .. %.4f" % (
            rel, len(bs), min(bs), max(bs)))
    print()

    # Top 15 pairs
    show = pairs[:15]
    print("  Top %d pairs by Jaccard:" % len(show))
    print("    %-15s %-15s  %-7s   %-35s  %s" % (
        "PATIENT_A", "PATIENT_B", "JACCARD", "RELATIONSHIP", "CONF"))
    for p in show:
        print("    %-15s %-15s  %.4f    %-35s  %s" % (
            p.get("patient_a", ""), p.get("patient_b", ""),
            p.get("jaccard", 0), p.get("relationship", ""),
            p.get("confidence", "")))

    flagged = [p for p in pairs if p.get("relationship") in
               ("likely_first_degree", "identical_or_duplicate")]
    if flagged:
        print()
        print("  ⚠ %d pair(s) flagged as likely first-degree or duplicate."
              " Run KING for confirmation." % len(flagged))
    print()
    print("  Note: KINSHIP is a screening pre-filter, not a kinship coefficient.")
    print("        See docs/kinship-calibration.md for limitations and ancestry caveats.")
    print("\n  %s ms" % latency)


def _print_kinship_trio(result, latency):
    """Print KINSHIP TRIO result for a declared family trio. Each pair is
    annotated with its relationship class. Trios where mom-child or dad-child
    don't show up as `likely_first_degree` get an explicit warning — almost
    always a sample swap.
    """
    print()
    print("  Trio:    %s (mom) | %s (dad) | %s (child)" % (
        result.get("mom", "?"), result.get("dad", "?"), result.get("child", "?")))
    print()
    print("    %-15s %-15s  %-7s   %-35s  %s" % (
        "A", "B", "JACCARD", "RELATIONSHIP", "CONF"))
    for p in result.get("pairs", []) or []:
        print("    %-15s %-15s  %.4f    %-35s  %s" % (
            p.get("patient_a", ""), p.get("patient_b", ""),
            p.get("jaccard", 0), p.get("relationship", ""),
            p.get("confidence", "")))
    warnings = result.get("warnings", []) or []
    if warnings:
        print()
        print("  ⚠ TRIO VALIDATION WARNINGS:")
        for w in warnings:
            print("    - %s" % w)
        print()
        print("  These mismatches commonly indicate sample swaps. Re-confirm")
        print("  pedigree before running clinical analyses on this trio.")
    else:
        print()
        print("  ✓ Trio looks consistent with declared parent-child structure.")
    print("\n  %s ms" % latency)


def _print_contamination(result, latency):
    """Print CONTAMINATION result. Headlines status + max-Jaccard partner +
    z-score, then shows the cohort baseline statistics that the classification
    is grounded in.
    """
    print()
    r = result.get("result", {}) or {}
    status = r.get("status", "?").upper()
    conf = r.get("confidence", "?")
    print("  Patient:                %s" % r.get("patient_id", result.get("patient_id", "?")))
    print("  Cohort size:            %s patients" % r.get("cohort_size", "?"))
    print()
    print("  Status:                 %s   (confidence: %s)" % (status, conf))
    if r.get("estimated_contamination_pct") is not None:
        print("  Estimated contamination: %.1f%%" % r["estimated_contamination_pct"])
    print()
    print("  ── max-Jaccard partner ──")
    print("  Partner:                %s" % (r.get("max_jaccard_partner") or "—"))
    print("  Max Jaccard:            %.4f" % (r.get("max_jaccard", 0) or 0))
    print("  Cohort baseline mean:   %.4f" % (r.get("cohort_jaccard_mean", 0) or 0))
    print("  Cohort baseline std:    %.4f" % (r.get("cohort_jaccard_std", 0) or 0))
    print("  Z-score:                %.2f" % (r.get("max_jaccard_z_score", 0) or 0))
    note = r.get("note", "")
    if note:
        print()
        # Wrap long notes at 75 chars
        import textwrap
        for line in textwrap.wrap(note, width=75):
            print("  %s" % line)
    print("\n  %s ms" % latency)


def _print_ancestry(result, latency):
    """Print ANCESTRY result. Headlines the predicted super-population +
    confidence + margin, then shows the per-population mean Jaccards and
    the normalized mixture.
    """
    print()
    r = result.get("result", {}) or {}
    pred = r.get("predicted_super_pop", "?")
    conf = r.get("confidence", "?")
    margin = r.get("margin", 0)
    print("  Patient:                %s" % r.get("patient_id", result.get("patient_id", "?")))
    print()
    print("  Predicted super-pop:    %s    (confidence: %s)" % (pred.upper(), conf))
    print("  Top vs 2nd margin:      %.4f" % margin)
    print()
    print("  ── per-super-population mean Jaccard ──")
    print("  %-7s %-12s  %-12s" % ("RANK", "SUPER_POP", "MEAN_JACCARD"))
    print("  %s" % ("-" * 38))
    for i, (pop, jac, n_ref) in enumerate(r.get("raw_scores", []) or [], start=1):
        marker = " ← predicted" if i == 1 else ""
        print("  %-7d %-12s  %.4f       (%d ref samples)%s" % (i, pop, jac, n_ref, marker))
    print()
    print("  ── normalized mixture (share of similarity signal) ──")
    for pop, frac in r.get("mixture", []) or []:
        bar_len = int(frac * 80)
        print("  %-6s  %.3f  %s" % (pop, frac, "█" * bar_len))
    note = r.get("note", "")
    if note:
        print()
        import textwrap
        for line in textwrap.wrap(note, width=75):
            print("  %s" % line)
    print("\n  %s ms" % latency)


def _print_mendelian_trio(result, latency):
    """Print MENDELIAN TRIO result. Headlines the de novo count + sanity-check
    warnings, then shows the full inheritance partition (de novo / maternal /
    paternal / biparental).
    """
    print()
    r = result.get("result", {}) or {}
    print("  Trio:    %s (mom) | %s (dad) | %s (child)" % (
        r.get("mom", "?"), r.get("dad", "?"), r.get("child", "?")))
    print()

    warning = r.get("kinship_warning")
    if warning:
        print("  ⚠ TRIO SANITY CHECK FAILED")
        for line in warning.split("; "):
            print("    %s" % line)
        print()

    child_total = r.get("child_total_variants", 0) or 0
    print("  ── inheritance partition of child's %s variants ──" % _fmt_int(child_total))
    print("  %-22s  %12s  %s" % ("CLASS", "COUNT", "% OF CHILD"))
    print("  %s" % ("-" * 50))
    for label, key in [
        ("de novo (in child)",   "de_novo_count"),
        ("maternal only",        "maternal_only_count"),
        ("paternal only",        "paternal_only_count"),
        ("biparental (in both)", "biparental_count"),
    ]:
        c = r.get(key, 0) or 0
        pct = (c / child_total * 100) if child_total > 0 else 0
        marker = "  ← screening signal" if key == "de_novo_count" else ""
        print("  %-22s  %12s  %6.2f%%%s" % (label, _fmt_int(c), pct, marker))
    print()
    print("  Variant counts: mom=%s   dad=%s   child=%s" % (
        _fmt_int(r.get("mom_total_variants", 0)),
        _fmt_int(r.get("dad_total_variants", 0)),
        _fmt_int(child_total)))

    note = r.get("note", "")
    if note:
        print()
        import textwrap
        for line in textwrap.wrap(note, width=75):
            print("  %s" % line)
    print("\n  %s ms" % latency)


def _print_pileup(result, latency):
    print()
    print("  Patient:    %s" % result.get("patient_id", "?"))
    print("  Position:   %s:%s" % (result.get("chrom", "?"), result.get("position", "?")))
    print("  Ref base:   %s" % result.get("reference_base", "?"))
    print("  Depth:      %s" % result.get("depth", "?"))
    base_counts = result.get("base_counts", {}) or {}
    mean_q = result.get("mean_quality_per_base", {}) or {}
    if base_counts:
        depth = result.get("depth", 0) or 0
        print("  Base counts:")
        print("    Base   Count    Pct    Mean Q")
        for base in sorted(base_counts.keys(), key=lambda b: -base_counts[b]):
            count = base_counts[base]
            pct = (100.0 * count / depth) if depth else 0.0
            q = mean_q.get(base, 0)
            print("    %-4s   %5s   %5.1f%%   %s" % (base, _fmt_int(count), pct, q))
    print("\n  %s ms" % latency)


def _print_tsv(result):
    results = result.get("results", [])
    if not results:
        return
    keys = list(results[0].keys())
    print("\t".join(keys))
    for r in results:
        print("\t".join(str(r.get(k, "")) for k in keys))


def print_job_progress(job):
    """Print progress for async jobs (upload/export)."""
    status = job.get("status", "?")
    completed = job.get("patients_completed", 0)
    total = job.get("patients_total", job.get("num_patients", "?"))
    errors = len(job.get("errors", []))

    line = "\r  Progress: %s/%s" % (completed, total)
    if errors:
        line += " (%s errors)" % errors
    if status in ("complete", "complete_with_errors"):
        line += " - Done"
    sys.stdout.write(line)
    sys.stdout.flush()

    if status in ("complete", "complete_with_errors"):
        print()  # newline after progress
        if job.get("errors"):
            for err in job["errors"]:
                sys.stderr.write("  Error: %s — %s\n" % (
                    err.get("patient_id", "?"), err.get("error", "?")))


# ──────────────────────────────────────── Cohort + GWAS display ──────────────

def _print_let_cohort(result, latency):
    name = result.get("cohort_name") or result.get("cohort", "?")
    count = result.get("count", "?")
    print("\n  Cohort '%s' saved — %s patients." % (name, count))
    print("  %s ms" % latency)


def _print_list_cohorts(result, latency):
    cohorts = result.get("cohorts", [])
    if not cohorts:
        print("\n  No cohorts defined. Use LET <name> = FIND PATIENTS WHERE ...")
        return
    print("\n  %-20s %8s  %s" % ("COHORT", "PATIENTS", "UPDATED"))
    print("  %s %s  %s" % ("-" * 20, "-" * 8, "-" * 24))
    for c in cohorts:
        print("  %-20s %8s  %s" % (
            c.get("name", "?"),
            c.get("count", "?"),
            c.get("updated_at", "?")[:19]))
    print("\n  %d cohort(s) | %s ms" % (len(cohorts), latency))


def _print_show_cohort(result, latency):
    name = result.get("cohort_name") or result.get("cohort", "?")
    total = result.get("total") or result.get("count", "?")
    ids = result.get("patient_ids") or result.get("preview", [])
    print("\n  Cohort: %s  (%s patients total)" % (name, total))
    print()
    for pid in ids:
        print("    %s" % pid)
    if len(ids) < int(total or 0):
        print("    ... and %d more" % (int(total) - len(ids)))
    print("\n  %s ms" % latency)


def _print_gwas_complete(result):
    """Display completed GWAS results (top hits table + stats)."""
    hits = result.get("hits", result.get("top_hits", []))
    total = result.get("total_tested", "?")
    lam = result.get("lambda", "?")
    sig = result.get("significance_threshold", 5e-8)
    models = result.get("model_counts", result.get("model_breakdown", {}))
    outfile = result.get("full_results_file", "")

    print("\n  GWAS Results")
    print("  ─────────────────────────────────────────────────────────────────")
    print("  Variants tested:  %s" % total)
    if lam != "?":
        warn = "  ⚠  stratification warning" if float(lam) > 1.05 else ""
        print("  Lambda (GC):      %.4f%s" % (float(lam), warn))
    if models:
        parts = ", ".join("%s=%s" % (k, v) for k, v in sorted(models.items()))
        print("  Models used:      %s" % parts)
    print("  Significance:     %s" % sig)
    if outfile:
        print("  Full results:     %s" % outfile)
    print()

    sig_hits = [h for h in hits if h.get("p_value", 1.0) < float(sig)]
    if not hits:
        print("  No hits to display.")
        return

    print("  %-6s %12s %-6s %-6s %-12s %8s %8s %8s %10s  %s" % (
        "CHR", "POS", "REF", "ALT", "GENE", "CASE_AF", "CTRL_AF", "OR", "P", "MODEL"))
    print("  %s" % ("-" * 100))

    # Show genome-wide significant hits first, then top hits up to 20
    shown = set()
    for h in sig_hits[:20]:
        _print_gwas_hit(h)
        shown.add(id(h))

    remaining = [h for h in hits[:20] if id(h) not in shown]
    if remaining and not sig_hits:
        for h in remaining:
            _print_gwas_hit(h)

    sig_count = len([h for h in hits if h.get("p_value", 1.0) < float(sig)])
    print("\n  %d genome-wide significant hits (p < %s)" % (sig_count, sig))
    if outfile:
        print("  Download full TSV: seashell --download-gwas %s" % outfile)


def _print_gwas_hit(h):
    print("  %-6s %12s %-6s %-6s %-12s %8.4f %8.4f %8.3f %10.2e  %s" % (
        h.get("chrom", "?"),
        h.get("pos", "?"),
        (h.get("ref_allele", "?") or "?")[:6],
        (h.get("alt_allele", "?") or "?")[:6],
        (h.get("gene", "-") or "-")[:12],
        float(h.get("case_af", 0) or 0),
        float(h.get("ctrl_af", 0) or 0),
        float(h.get("odds_ratio", 1) or 1),
        float(h.get("p_value", 1) or 1),
        h.get("model", "?")))
