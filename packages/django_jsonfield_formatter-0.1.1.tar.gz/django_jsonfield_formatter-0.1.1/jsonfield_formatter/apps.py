from django.apps import AppConfig


class JsonfieldFormatterConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jsonfield_formatter"
    label = "jsonfield_formatter"
    verbose_name = "JSON field formatter"
