"""
Admin widget for JSONField using JSONEditor.

Vendored assets: jsoneditor **10.1.0** (josdejong/jsoneditor), shipped under
static/jsonfield_formatter/ (min JS/CSS + img/jsoneditor-icons.svg).
"""

from __future__ import annotations

import json
from typing import Any

from django.forms.widgets import Widget


class JSONFormatterWidget(Widget):
    """
    Tree/code/view JSON editor for ``JSONField`` in the Django admin.

    Parameters
    ----------
    attrs:
        Extra HTML attributes for the hidden textarea.
    mode:
        Initial JSONEditor mode: ``tree``, ``code``, or ``view``.
    height:
        CSS height for the editor root (e.g. ``\"400px\"``, ``\"min(60vh, 480px)\"``).
    editor_options:
        Dict merged into JSONEditor constructor options (see JSONEditor docs).
    show_fullscreen_button:
        When ``True``, show a **Fullscreen** control that uses the browser Fullscreen API
        on the editor (Escape exits). JSONEditor is resized when entering or leaving
        fullscreen.
    """

    template_name = "jsonfield_formatter/widgets/json_formatter.html"

    def __init__(
        self,
        attrs: dict[str, Any] | None = None,
        *,
        mode: str = "tree",
        height: str = "400px",
        editor_options: dict[str, Any] | None = None,
        show_fullscreen_button: bool = True,
    ) -> None:
        self.mode = mode
        self.height = height
        self.editor_options = dict(editor_options) if editor_options else {}
        self.show_fullscreen_button = show_fullscreen_button
        default_attrs = {
            "class": "jsonfield-formatter-textarea",
            "rows": 4,
            "cols": 40,
            "style": "display: none;",
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(default_attrs)

    class Media:
        css = {
            "all": (
                "jsonfield_formatter/jsoneditor.min.css",
                "jsonfield_formatter/json_formatter_widget.css",
            )
        }
        js = (
            "jsonfield_formatter/jsoneditor.min.js",
            "jsonfield_formatter/json_formatter_widget.js",
        )

    def format_value(self, value: Any) -> str:
        if value is None or value == "":
            return ""
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    def get_context(self, name: str, value: Any, attrs: dict[str, Any]) -> dict[str, Any]:
        context = super().get_context(name, value, attrs)
        widget = context["widget"]
        default_opts: dict[str, Any] = {
            "mode": self.mode,
            "modes": ["tree", "code", "view"],
            "navigationBar": True,
            "statusBar": True,
            "mainMenuBar": True,
        }
        merged = {**default_opts, **self.editor_options}
        merged["mode"] = self.editor_options.get("mode", self.mode)
        widget["height"] = self.height
        widget["editor_options_json"] = json.dumps(merged)
        widget["show_fullscreen_button"] = self.show_fullscreen_button
        return context
