from __future__ import annotations

from django.db.models import JSONField

from jsonfield_formatter.widgets import JSONFormatterWidget


class JSONFormatterAdminMixin:
    """
    Sets ``formfield_overrides`` so all ``JSONField`` columns use
    :class:`~jsonfield_formatter.widgets.JSONFormatterWidget`.

    Example::

        @admin.register(MyModel)
        class MyModelAdmin(JSONFormatterAdminMixin, admin.ModelAdmin):
            pass
    """

    formfield_overrides = {
        JSONField: {"widget": JSONFormatterWidget},
    }
