/**
 * Initializes vendored JSONEditor (see widgets.py for pinned version) on each
 * .jsonfield-formatter-root and syncs content to the textarea on submit.
 * Optional fullscreen toggle uses the Fullscreen API and calls editor.resize().
 */
(function () {
  'use strict';

  function parseOptions(raw) {
    if (!raw) {
      return {};
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {};
    }
  }

  function getFullscreenElement() {
    return (
      document.fullscreenElement ||
      document.webkitFullscreenElement ||
      document.msFullscreenElement ||
      null
    );
  }

  function requestFullscreen(el) {
    var fn = el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen;
    if (fn) {
      return fn.call(el);
    }
    return Promise.reject(new Error('Fullscreen not supported'));
  }

  function exitFullscreen() {
    var d = document;
    var fn = d.exitFullscreen || d.webkitExitFullscreen || d.msExitFullscreen;
    if (fn) {
      return fn.call(d);
    }
    return Promise.reject(new Error('Exit fullscreen not supported'));
  }

  function resizeEditorIfAny(root) {
    var ed = root._jffJSONEditor;
    if (ed && typeof ed.resize === 'function') {
      window.setTimeout(function () {
        ed.resize();
      }, 0);
    }
  }

  function syncAllFullscreenUi() {
    document.querySelectorAll('.jsonfield-formatter-root').forEach(function (root) {
      resizeEditorIfAny(root);
      var btn = root.querySelector('.jsonfield-formatter-fs-btn');
      if (!btn) {
        return;
      }
      var active = getFullscreenElement() === root;
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
      btn.textContent = active ? 'Exit fullscreen' : 'Fullscreen';
      btn.setAttribute(
        'title',
        active ? 'Leave fullscreen (or press Escape)' : 'Expand editor to fullscreen'
      );
    });
  }

  if (!window._jffFullscreenListeners) {
    window._jffFullscreenListeners = true;
    document.addEventListener('fullscreenchange', syncAllFullscreenUi);
    document.addEventListener('webkitfullscreenchange', syncAllFullscreenUi);
    document.addEventListener('MSFullscreenChange', syncAllFullscreenUi);
  }

  function bindFullscreen(root, editor) {
    root._jffJSONEditor = editor;
    var btn = root.querySelector('.jsonfield-formatter-fs-btn');
    if (!btn) {
      return;
    }

    btn.addEventListener('click', function () {
      if (getFullscreenElement() === root) {
        exitFullscreen().then(syncAllFullscreenUi).catch(syncAllFullscreenUi);
      } else {
        requestFullscreen(root).then(syncAllFullscreenUi).catch(syncAllFullscreenUi);
      }
    });
  }

  function initRoot(root) {
    if (root.getAttribute('data-jff-initialized') === '1') {
      return;
    }
    if (typeof window.JSONEditor === 'undefined') {
      return;
    }
    var textarea = root.querySelector('textarea.jsonfield-formatter-textarea');
    var container = root.querySelector('.jsonfield-formatter-editor');
    if (!textarea || !container) {
      return;
    }
    root.setAttribute('data-jff-initialized', '1');

    var options = parseOptions(root.getAttribute('data-editor-options'));
    var editor = new window.JSONEditor(container, options);

    var raw = (textarea.value || '').trim();
    try {
      if (raw === '') {
        editor.set({});
      } else {
        editor.set(JSON.parse(raw));
      }
    } catch (err) {
      editor.updateText(raw);
      editor.setMode('code');
    }

    bindFullscreen(root, editor);

    var form = textarea.form;
    if (form) {
      form.addEventListener('submit', function () {
        try {
          textarea.value = JSON.stringify(editor.get());
        } catch (e) {
          textarea.value = editor.getText();
        }
      });
    }
  }

  function initAll(context) {
    var scope = context || document;
    var nodes = scope.querySelectorAll('.jsonfield-formatter-root');
    for (var i = 0; i < nodes.length; i++) {
      initRoot(nodes[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      initAll(document);
    });
  } else {
    initAll(document);
  }

  if (typeof django !== 'undefined' && django.jQuery) {
    django.jQuery(document).on('formset:added', function (event, row) {
      initAll(row && row.get ? row.get(0) : row);
    });
  }
})();
