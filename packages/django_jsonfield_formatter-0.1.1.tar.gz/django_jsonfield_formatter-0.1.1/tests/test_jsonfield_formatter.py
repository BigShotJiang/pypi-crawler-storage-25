import json

import pytest
from django.contrib.auth import get_user_model
from django.urls import reverse

from jsonfield_formatter.widgets import JSONFormatterWidget

from tests.test_app.models import JsonBlob


@pytest.mark.django_db
def test_widget_renders_html():
    widget = JSONFormatterWidget()
    html = widget.render("data", {"a": 1}, attrs={"id": "id_data"})
    assert "jsonfield-formatter-root" in html
    assert "jsonfield-formatter-textarea" in html
    assert '"a"' in html or "a" in html
    assert "jsonfield-formatter-fs-btn" in html


@pytest.mark.django_db
def test_widget_fullscreen_button_disabled():
    widget = JSONFormatterWidget(show_fullscreen_button=False)
    html = widget.render("data", {}, attrs={"id": "id_data"})
    assert "jsonfield-formatter-fs-btn" not in html


@pytest.mark.django_db
def test_widget_format_value_none():
    w = JSONFormatterWidget()
    assert w.format_value(None) == ""


@pytest.mark.django_db
def test_admin_add_post_roundtrip(client):
    User = get_user_model()
    User.objects.create_superuser("admin", "admin@test.example", "pass")
    assert client.login(username="admin", password="pass")
    url = reverse("admin:test_app_jsonblob_add")
    payload = {"name": "t1", "data": '{"x": 1, "y": [2, 3]}'}
    response = client.post(url, payload, follow=True)
    assert response.status_code == 200
    obj = JsonBlob.objects.get(name="t1")
    assert obj.data == {"x": 1, "y": [2, 3]}


@pytest.mark.django_db
def test_admin_change_post_roundtrip(client):
    blob = JsonBlob.objects.create(name="b2", data={"n": 1})
    User = get_user_model()
    User.objects.create_superuser("admin2", "admin2@test.example", "pass2")
    assert client.login(username="admin2", password="pass2")
    url = reverse("admin:test_app_jsonblob_change", args=[blob.pk])
    payload = {
        "name": "b2",
        "data": json.dumps({"n": 2, "z": True}),
    }
    response = client.post(url, payload, follow=True)
    assert response.status_code == 200
    blob.refresh_from_db()
    assert blob.data == {"n": 2, "z": True}
