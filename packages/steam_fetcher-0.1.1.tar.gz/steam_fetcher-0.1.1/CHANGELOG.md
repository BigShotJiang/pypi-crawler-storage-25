# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-04-12

### Added

- 23 tests for `AsyncSteamAuthClient` — coverage increased from 41% to 100%
- 32 CLI integration tests via `typer.testing.CliRunner` — covers all game and user commands
- `typer` and `aiolimiter` added to dev dependencies for test support

### Changed

- Overall test coverage increased from 89% to 90% (179 tests total)
- Improved mkdocs theme: light/dark mode toggle, `Inter`/`JetBrains Mono` fonts, navigation tabs, code copy button, syntax highlighting, footer navigation

## [0.1.0] - 2026-04-12

### Added

- `SteamClient` — synchronous Steam Store API client (no API key required)
- `AsyncSteamClient` — asynchronous Steam Store API client with rate limiting via `aiolimiter`
- `SteamAuthClient` — synchronous Steam Web API client (requires API key)
- `AsyncSteamAuthClient` — asynchronous Steam Web API client (requires API key)
- Rate limiting for sync clients via `threading.Lock` + `time.sleep`
- Retry logic with exponential backoff (retries only on 5xx errors)

#### Public methods (no key required)

- `get_game(app_id, country, language)` — game details with localization support
- `get_player_count(app_id)` — current online players
- `get_reviews(app_id, language, review_filter, num_per_page, cursor)` — reviews with cursor-based pagination
- `search(query, country, language)` — store search with localization
- `get_steamspy_details(app_id)` — SteamSpy statistics
- `get_news(app_id, count, max_length)` — game news
- `get_global_achievement_percentages(app_id)` — global achievement stats

#### Authenticated methods (API key required)

- `get_user_profile(steam_id)` — user profile with online status and current game
- `get_user_profiles(steam_ids)` — batch profiles (auto-chunked by 100)
- `get_user_library(steam_id)` — game library
- `get_user_achievements(steam_id, app_id)` — user achievements
- `get_user_friends(steam_id)` — friend list
- `get_user_bans(steam_ids)` — ban info (batch, auto-chunked)
- `resolve_vanity_url(vanity_url)` — vanity URL to Steam ID
- `get_recently_played(steam_id)` — recently played games
- `get_steam_level(steam_id)` — Steam level
- `get_user_badges(steam_id)` — badges and XP
- `get_wishlist(steam_id)` — wishlist (unofficial API)
- `get_user_stats(steam_id, app_id)` — user game stats
- `get_game_schema(app_id)` — achievement and stat definitions
- `get_app_list(last_appid, max_results)` — IStoreService app list with cursor pagination

#### Models

- Pydantic v2 models for all API responses: `GameDetails`, `UserProfile`, `UserLibrary`, `GameAchievements`, `SearchResult`, `PlayerCount`, `ReviewSummary`, `Review`, `SteamSpyDetails`, `AppNews`, `NewsItem`, `FriendList`, `Friend`, `PlayerBan`, `RecentlyPlayed`, `RecentGame`, `UserBadges`, `Badge`, `WishlistItem`, `UserStats`, `StatEntry`, `GameSchema`, `AchievementSchema`, `StatSchema`, `GlobalAchievements`, `GlobalAchievement`, `AppList`, `AppListEntry`
- `AppType` enum for Steam application types
- `LibraryGame.icon_url` — computed property for full icon URL
- `SearchEntry.platforms` — platform info from search results
- `SecretStr` support for API keys

#### Exporters

- `JsonExporter`, `CsvExporter`, `ParquetExporter` (via `polars`), `SqlExporter` (via `sqlalchemy`)
- Unified `BaseExporter` Protocol with `export(data, destination)` interface

#### CLI

- `games details`, `games search`, `games players`, `games reviews`, `games schema`, `games news`
- `users profile`, `users library`, `users achievements`, `users friends`, `users bans`, `users resolve`, `users recently-played`, `users level`, `users badges`
- `--country`/`--language` flags for localization
- `STEAM_API_KEY` environment variable support

#### Other

- Bilingual documentation (English + Russian) via mkdocs-material + mkdocs-static-i18n
- 130 tests, 91% coverage
- Pre-commit hooks: ruff lint + format, trailing whitespace, end-of-file fixer

[0.1.1]: https://github.com/cop1cat/steam-fetcher/releases/tag/v0.1.1
[0.1.0]: https://github.com/cop1cat/steam-fetcher/releases/tag/v0.1.0
