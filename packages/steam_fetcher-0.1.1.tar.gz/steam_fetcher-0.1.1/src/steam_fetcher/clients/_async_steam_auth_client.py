from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from httpx import QueryParams
from pydantic import SecretStr

from steam_fetcher.clients._async_steam_client import AsyncSteamClient

if TYPE_CHECKING:
    from steam_fetcher.models.game import AppList
    from steam_fetcher.models.player import GameSchema, UserStats
    from steam_fetcher.models.user import (
        FriendList,
        GameAchievements,
        PlayerBan,
        RecentlyPlayed,
        UserBadges,
        UserLibrary,
        UserProfile,
        WishlistItem,
    )

logger = logging.getLogger(__name__)


class AsyncSteamAuthClient(AsyncSteamClient):
    """
        Asynchronous Steam client with Web API authentication.

        Args:
            api_key (SecretStr | str): Steam Web API key.
            requests_per_minute (int): Maximum number of requests per minute.
            time_period (float): Time period in seconds for rate limiting.
            retries (int): Number of retry attempts on failure.
            timeout (float): Request timeout in seconds.
            burst_size (int): Maximum burst size for rate limiter.

        Example:
    ```python
            async with AsyncSteamAuthClient(api_key="your_api_key") as client:
                profile = await client.get_user_profile("76561198000000000")
                library = await client.get_user_library("76561198000000000")
    ```
    """

    def __init__(
        self,
        api_key: SecretStr | str,
        requests_per_minute: int = 200,
        time_period: float = 60.0,
        retries: int = 3,
        timeout: float = 10.0,
        burst_size: int = 10,
    ) -> None:
        super().__init__(
            requests_per_minute=requests_per_minute,
            time_period=time_period,
            retries=retries,
            timeout=timeout,
            burst_size=burst_size,
        )
        self._api_key = (
            SecretStr(api_key) if isinstance(api_key, str) else api_key
        )

    async def get_user_profile(self, steam_id: str) -> UserProfile | None:
        """
        Fetches public profile for a Steam user.

        Args:
            steam_id (str): Steam 64-bit user ID.

        Returns:
            UserProfile | None: User profile or None if not found.
        """
        response = await self._get(
            f"{self._API_URL}/ISteamUser/GetPlayerSummaries/v2",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamids": steam_id,
                }
            ),
        )
        result = self._parse_user_profile(response.json())
        if result is None:
            logger.warning("User profile %s not found", steam_id)
        return result

    async def get_user_library(self, steam_id: str) -> UserLibrary | None:
        """
        Fetches game library for a Steam user.

        Args:
            steam_id (str): Steam 64-bit user ID.

        Returns:
            UserLibrary | None: User library or None if not found.
        """
        response = await self._get(
            f"{self._API_URL}/IPlayerService/GetOwnedGames/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                    "include_appinfo": 1,
                    "include_played_free_games": 1,
                }
            ),
        )
        result = self._parse_user_library(steam_id, response.json())
        if result is None:
            logger.warning("User library %s not found", steam_id)
        return result

    async def get_user_achievements(
        self, steam_id: str, app_id: int
    ) -> GameAchievements | None:
        """
        Fetches achievements for a Steam user in a specific game.

        Args:
            steam_id (str): Steam 64-bit user ID.
            app_id (int): Steam application ID.

        Returns:
            GameAchievements | None: Game achievements or None if not found.
        """
        response = await self._get(
            f"{self._API_URL}/ISteamUserStats/GetPlayerAchievements/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                    "appid": app_id,
                }
            ),
        )
        result = self._parse_achievements(app_id, response.json())
        if result is None:
            logger.warning(
                "Achievements for user %s game %s not found",
                steam_id,
                app_id,
            )
        return result

    async def get_user_friends(self, steam_id: str) -> FriendList | None:
        """Fetches friend list for a Steam user."""
        response = await self._get(
            f"{self._API_URL}/ISteamUser/GetFriendList/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                    "relationship": "friend",
                }
            ),
        )
        result = self._parse_friends(steam_id, response.json())
        if result is None:
            logger.warning("Friends for %s not found", steam_id)
        return result

    async def get_user_bans(self, steam_ids: list[str]) -> list[PlayerBan]:
        """Fetches ban info for Steam users (up to 100 per chunk)."""
        all_bans: list[PlayerBan] = []
        for i in range(0, len(steam_ids), 100):
            chunk = steam_ids[i : i + 100]
            response = await self._get(
                f"{self._API_URL}/ISteamUser/GetPlayerBans/v1",
                params=QueryParams(
                    {
                        "key": self._api_key.get_secret_value(),
                        "steamids": ",".join(chunk),
                    }
                ),
            )
            all_bans.extend(self._parse_bans(response.json()))
        return all_bans

    async def resolve_vanity_url(self, vanity_url: str) -> str | None:
        """Resolves a vanity URL to a Steam ID."""
        response = await self._get(
            f"{self._API_URL}/ISteamUser/ResolveVanityURL/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "vanityurl": vanity_url,
                }
            ),
        )
        return self._parse_vanity_url(response.json())

    async def get_user_profiles(
        self, steam_ids: list[str]
    ) -> list[UserProfile]:
        """Fetches profiles for multiple Steam users."""
        profiles: list[UserProfile] = []
        for i in range(0, len(steam_ids), 100):
            chunk = steam_ids[i : i + 100]
            response = await self._get(
                f"{self._API_URL}/ISteamUser/GetPlayerSummaries/v2",
                params=QueryParams(
                    {
                        "key": self._api_key.get_secret_value(),
                        "steamids": ",".join(chunk),
                    }
                ),
            )
            data = response.json()
            players = data.get("response", {}).get("players", [])
            for player_data in players:
                profile = self._parse_user_profile(
                    {"response": {"players": [player_data]}}
                )
                if profile:
                    profiles.append(profile)
        return profiles

    async def get_recently_played(
        self, steam_id: str, count: int = 0
    ) -> RecentlyPlayed | None:
        """Fetches recently played games."""
        response = await self._get(
            f"{self._API_URL}/IPlayerService/GetRecentlyPlayedGames/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                    "count": count,
                }
            ),
        )
        result = self._parse_recently_played(steam_id, response.json())
        if result is None:
            logger.warning("Recently played for %s not found", steam_id)
        return result

    async def get_steam_level(self, steam_id: str) -> int | None:
        """Fetches Steam level for a user."""
        response = await self._get(
            f"{self._API_URL}/IPlayerService/GetSteamLevel/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                }
            ),
        )
        return self._parse_steam_level(response.json())

    async def get_user_badges(self, steam_id: str) -> UserBadges | None:
        """Fetches badges for a Steam user."""
        response = await self._get(
            f"{self._API_URL}/IPlayerService/GetBadges/v1",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                }
            ),
        )
        result = self._parse_badges(steam_id, response.json())
        if result is None:
            logger.warning("Badges for %s not found", steam_id)
        return result

    async def get_wishlist(self, steam_id: str) -> list[WishlistItem]:
        """Fetches wishlist for a Steam user."""
        response = await self._get(
            f"{self._STORE_URL}/wishlist/profiles/{steam_id}/wishlistdata",
        )
        return self._parse_wishlist(steam_id, response.json())

    async def get_user_stats(
        self, steam_id: str, app_id: int
    ) -> UserStats | None:
        """Fetches user stats for a game."""
        response = await self._get(
            f"{self._API_URL}/ISteamUserStats/GetUserStatsForGame/v2",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "steamid": steam_id,
                    "appid": app_id,
                }
            ),
        )
        result = self._parse_user_stats(steam_id, app_id, response.json())
        if result is None:
            logger.warning(
                "Stats for user %s game %s not found",
                steam_id,
                app_id,
            )
        return result

    async def get_app_list(
        self,
        last_appid: int = 0,
        max_results: int = 10000,
    ) -> AppList:
        """Fetches app list via IStoreService (cursor-based pagination)."""
        params: dict[str, str | int] = {
            "key": self._api_key.get_secret_value(),
            "max_results": max_results,
        }
        if last_appid > 0:
            params["last_appid"] = last_appid
        response = await self._get(
            f"{self._API_URL}/IStoreService/GetAppList/v1",
            params=QueryParams(params),
        )
        return self._parse_app_list(response.json())

    async def get_game_schema(self, app_id: int) -> GameSchema | None:
        """Fetches game schema (achievements and stats definitions)."""
        response = await self._get(
            f"{self._API_URL}/ISteamUserStats/GetSchemaForGame/v2",
            params=QueryParams(
                {
                    "key": self._api_key.get_secret_value(),
                    "appid": app_id,
                }
            ),
        )
        result = self._parse_game_schema(app_id, response.json())
        if result is None:
            logger.warning("Game schema for %s not found", app_id)
        return result
