from __future__ import annotations

import re
from typing import Any

from steam_fetcher.models.game import (
    AppList,
    AppListEntry,
    GameDetails,
    Platforms,
)
from steam_fetcher.models.news import AppNews, NewsItem
from steam_fetcher.models.player import (
    AchievementSchema,
    GameSchema,
    GlobalAchievement,
    GlobalAchievements,
    PlayerCount,
    Review,
    ReviewSummary,
    StatEntry,
    StatSchema,
    SteamSpyDetails,
    UserStats,
)
from steam_fetcher.models.search import SearchEntry, SearchResult
from steam_fetcher.models.user import (
    Achievement,
    Avatar,
    Badge,
    Friend,
    FriendList,
    GameAchievements,
    LibraryGame,
    PlayerBan,
    RecentGame,
    RecentlyPlayed,
    UserBadges,
    UserLibrary,
    UserProfile,
    WishlistItem,
)


class BaseClient:
    """
    Base Steam client with shared configuration and parsing logic.

    Args:
        retries (int): Number of retry attempts on failure.
        timeout (float): Request timeout in seconds.
    """

    _STORE_API_URL = "https://store.steampowered.com/api"
    _STORE_URL = "https://store.steampowered.com"
    _API_URL = "https://api.steampowered.com"

    def __init__(
        self,
        retries: int = 3,
        timeout: float = 10.0,
    ) -> None:
        self._retries = retries
        self._timeout = timeout

    def _parse_game(
        self, app_id: int, data: dict[str, Any]
    ) -> GameDetails | None:
        """
        Parses raw Steam Store API response into GameDetails model.

        Args:
            app_id (int): Steam application ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            GameDetails | None: Parsed game details or None if not found.
        """
        app = data.get(str(app_id), {})
        if not app.get("success"):
            return None

        raw = app["data"]
        return GameDetails.model_validate(
            {
                "app_id": raw.get("steam_appid"),
                "name": raw.get("name"),
                "type": raw.get("type"),
                "is_free": raw.get("is_free", False),
                "short_description": raw.get("short_description") or None,
                "about_the_game": raw.get("about_the_game") or None,
                "detailed_description": raw.get("detailed_description") or None,
                "supported_languages": self._parse_languages(
                    raw.get("supported_languages", "")
                ),
                "header_image": raw.get("header_image") or None,
                "website": raw.get("website") or None,
                "developers": raw.get("developers", []),
                "publishers": raw.get("publishers", []),
                "price": raw.get("price_overview") or None,
                "platforms": raw.get("platforms") or None,
                "metacritic": raw.get("metacritic") or None,
                "categories": raw.get("categories", []),
                "genres": raw.get("genres", []),
                "screenshots": raw.get("screenshots", []),
                "movies": raw.get("movies", []),
                "release_date": raw.get("release_date") or None,
                "dlc_count": len(raw.get("dlc", [])),
                "achievements": raw.get("achievements", {}).get("total", 0),
                "recommendations": raw.get("recommendations", {}).get(
                    "total", 0
                ),
                "required_age": int(
                    str(raw.get("required_age", 0)).replace("+", "")
                ),
            }
        )

    def _parse_player_count(
        self, app_id: int, data: dict[str, Any]
    ) -> PlayerCount | None:
        """
        Parses raw Steam API response into PlayerCount model.

        Args:
            app_id (int): Steam application ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            PlayerCount | None: Parsed player count or None if not found.
        """
        response = data.get("response", {})
        if response.get("result") != 1:
            return None

        return PlayerCount(
            app_id=app_id,
            player_count=response["player_count"],
        )

    def _parse_reviews(
        self, app_id: int, data: dict[str, Any]
    ) -> ReviewSummary | None:
        """
        Parses raw Steam API response into ReviewSummary model.

        Args:
            app_id (int): Steam application ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            ReviewSummary | None: Parsed review summary or None if not found.
        """
        if data.get("success") != 1:
            return None

        summary = data["query_summary"]
        reviews = [
            Review(
                recommendation_id=r.get("recommendationid", ""),
                author_steam_id=r.get("author", {}).get("steamid", ""),
                language=r.get("language", ""),
                review=r.get("review", ""),
                timestamp_created=r.get("timestamp_created", 0),
                voted_up=r.get("voted_up", False),
                votes_up=r.get("votes_up", 0),
                votes_funny=r.get("votes_funny", 0),
                weighted_vote_score=float(r.get("weighted_vote_score", 0)),
                comment_count=r.get("comment_count", 0),
                steam_purchase=r.get("steam_purchase", False),
                received_for_free=r.get("received_for_free", False),
            )
            for r in data.get("reviews", [])
        ]
        return ReviewSummary(
            app_id=app_id,
            total=summary["total_reviews"],
            positive=summary["total_positive"],
            negative=summary["total_negative"],
            score=summary["review_score"],
            score_description=summary["review_score_desc"],
            review_type="all",
            purchase_type="all",
            cursor=data.get("cursor"),
            reviews=reviews,
        )

    def _parse_search(self, term: str, data: dict[str, Any]) -> SearchResult:
        """
        Parses raw Steam search response into SearchResult model.

        Args:
            term (str): Search query term.
            data (dict[str, Any]): Raw API response data.

        Returns:
            SearchResult: Parsed search results.
        """
        items = data.get("items", [])
        return SearchResult(
            term=term,
            total=data.get("total", len(items)),
            entries=[
                SearchEntry(
                    app_id=int(item["id"]),
                    name=item["name"],
                    icon=item.get("tiny_image") or None,
                    price=self._format_search_price(item.get("price")),
                    platforms=Platforms(
                        windows=item.get("platforms", {}).get("windows", False),
                        mac=item.get("platforms", {}).get("mac", False),
                        linux=item.get("platforms", {}).get("linux", False),
                    )
                    if item.get("platforms")
                    else None,
                )
                for item in items
            ],
        )

    def _parse_user_profile(self, data: dict[str, Any]) -> UserProfile | None:
        """
        Parses raw Steam Web API response into UserProfile model.

        Args:
            data (dict[str, Any]): Raw API response data.

        Returns:
            UserProfile | None: Parsed user profile or None if not found.
        """
        players = data.get("response", {}).get("players", [])
        if not players:
            return None

        player = players[0]
        return UserProfile(
            steam_id=player["steamid"],
            username=player["personaname"],
            real_name=player.get("realname") or None,
            avatar=Avatar(
                small=player["avatar"],
                medium=player["avatarmedium"],
                full=player["avatarfull"],
            ),
            profile_url=player["profileurl"],
            country_code=player.get("loccountrycode") or None,
            state_code=player.get("locstatecode") or None,
            time_created=player.get("timecreated") or None,
            last_logoff=player.get("lastlogoff") or None,
            is_public=player.get("communityvisibilitystate") == 3,
            persona_state=player.get("personastate"),
            game_id=int(player["gameid"]) if player.get("gameid") else None,
            game_extra_info=player.get("gameextrainfo") or None,
        )

    def _parse_user_library(
        self, steam_id: str, data: dict[str, Any]
    ) -> UserLibrary | None:
        """
        Parses raw Steam Web API response into UserLibrary model.

        Args:
            steam_id (str): Steam 64-bit user ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            UserLibrary | None: Parsed user library or None if not found.
        """
        response = data.get("response", {})
        if not response:
            return None

        return UserLibrary(
            steam_id=steam_id,
            game_count=response.get("game_count", 0),
            games=[
                LibraryGame(
                    app_id=game["appid"],
                    name=game.get("name") or None,
                    playtime_forever=game.get("playtime_forever", 0),
                    playtime_2weeks=game.get("playtime_2weeks") or None,
                    img_icon_url=game.get("img_icon_url") or None,
                    last_played=game.get("rtime_last_played") or None,
                )
                for game in response.get("games", [])
            ],
        )

    def _parse_achievements(
        self, app_id: int, data: dict[str, Any]
    ) -> GameAchievements | None:
        """
        Parses raw Steam Web API response into GameAchievements model.

        Args:
            app_id (int): Steam application ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            GameAchievements | None: Parsed achievements or None if not found.
        """
        player_stats = data.get("playerstats")
        if not player_stats:
            return None

        return GameAchievements(
            app_id=app_id,
            game_name=player_stats.get("gameName", ""),
            achievements=[
                Achievement(
                    api_name=a["apiname"],
                    achieved=bool(a["achieved"]),
                    unlock_time=a.get("unlocktime") or None,
                    name=a.get("name") or None,
                    description=a.get("description") or None,
                )
                for a in player_stats.get("achievements", [])
            ],
        )

    @staticmethod
    def _format_search_price(
        price_data: dict[str, Any] | None,
    ) -> str | None:
        """Formats search price from cents to readable string."""
        if not price_data:
            return None
        final = price_data.get("final", 0)
        if final == 0:
            return "Free to Play"
        currency = price_data.get("currency", "USD")
        return f"${final / 100:.2f} {currency}"

    @staticmethod
    def _parse_languages(raw: str) -> list[str]:
        """
        Parses Steam supported languages string into a list.

        Args:
            raw (str): Raw languages string from Steam API.

        Returns:
            list[str]: List of language names.
        """
        cleaned = re.sub(r"<[^>]+>", "", raw)
        cleaned = cleaned.replace("languages with full audio support", "")
        return [
            lang.replace("*", "").strip()
            for lang in cleaned.split(",")
            if lang.strip()
        ]

    def _parse_friends(
        self, steam_id: str, data: dict[str, Any]
    ) -> FriendList | None:
        fl = data.get("friendslist", {})
        if not fl:
            return None
        return FriendList(
            steam_id=steam_id,
            friends=[
                Friend(
                    steam_id=f["steamid"],
                    relationship=f["relationship"],
                    friend_since=f["friend_since"],
                )
                for f in fl.get("friends", [])
            ],
        )

    def _parse_bans(self, data: dict[str, Any]) -> list[PlayerBan]:
        return [
            PlayerBan(
                steam_id=p["SteamId"],
                community_banned=p["CommunityBanned"],
                vac_banned=p["VACBanned"],
                number_of_vac_bans=p["NumberOfVACBans"],
                days_since_last_ban=p["DaysSinceLastBan"],
                number_of_game_bans=p["NumberOfGameBans"],
                economy_ban=p["EconomyBan"],
            )
            for p in data.get("players", [])
        ]

    def _parse_vanity_url(self, data: dict[str, Any]) -> str | None:
        response = data.get("response", {})
        if response.get("success") != 1:
            return None
        steam_id: str | None = response.get("steamid")
        return steam_id

    def _parse_recently_played(
        self, steam_id: str, data: dict[str, Any]
    ) -> RecentlyPlayed | None:
        response = data.get("response", {})
        if not response:
            return None
        return RecentlyPlayed(
            steam_id=steam_id,
            total_count=response.get("total_count", 0),
            games=[
                RecentGame(
                    app_id=g["appid"],
                    name=g.get("name", ""),
                    playtime_2weeks=g.get("playtime_2weeks", 0),
                    playtime_forever=g.get("playtime_forever", 0),
                    img_icon_url=g.get("img_icon_url") or None,
                )
                for g in response.get("games", [])
            ],
        )

    def _parse_steam_level(self, data: dict[str, Any]) -> int | None:
        response = data.get("response", {})
        if "player_level" not in response:
            return None
        level: int = response["player_level"]
        return level

    def _parse_badges(
        self, steam_id: str, data: dict[str, Any]
    ) -> UserBadges | None:
        response = data.get("response", {})
        if not response:
            return None
        return UserBadges(
            steam_id=steam_id,
            badges=[
                Badge(
                    badge_id=b["badgeid"],
                    level=b.get("level", 0),
                    completion_time=b.get("completion_time", 0),
                    xp=b.get("xp", 0),
                    scarcity=b.get("scarcity", 0),
                )
                for b in response.get("badges", [])
            ],
            player_xp=response.get("player_xp", 0),
            player_level=response.get("player_level", 0),
        )

    def _parse_wishlist(
        self, steam_id: str, data: dict[str, Any]
    ) -> list[WishlistItem]:
        return [
            WishlistItem(
                app_id=int(app_id),
                priority=info.get("priority", 0),
                date_added=info.get("added") or None,
            )
            for app_id, info in data.items()
        ]

    def _parse_user_stats(
        self, steam_id: str, app_id: int, data: dict[str, Any]
    ) -> UserStats | None:
        ps = data.get("playerstats")
        if not ps:
            return None
        return UserStats(
            steam_id=steam_id,
            app_id=app_id,
            game_name=ps.get("gameName", ""),
            stats=[
                StatEntry(name=s["name"], value=s["value"])
                for s in ps.get("stats", [])
            ],
        )

    def _parse_game_schema(
        self, app_id: int, data: dict[str, Any]
    ) -> GameSchema | None:
        game = data.get("game")
        if not game:
            return None
        avail = game.get("availableGameStats", {})
        return GameSchema(
            app_id=app_id,
            game_name=game.get("gameName", ""),
            achievements=[
                AchievementSchema(
                    name=a["name"],
                    display_name=a.get("displayName", ""),
                    description=a.get("description") or None,
                    icon=a.get("icon") or None,
                    icon_gray=a.get("icongray") or None,
                )
                for a in avail.get("achievements", [])
            ],
            stats=[
                StatSchema(
                    name=s["name"],
                    display_name=s.get("displayName", ""),
                )
                for s in avail.get("stats", [])
            ],
        )

    def _parse_global_achievements(
        self, app_id: int, data: dict[str, Any]
    ) -> GlobalAchievements | None:
        ag = data.get("achievementpercentages", {})
        achievements = ag.get("achievements", [])
        if not achievements and not ag:
            return None
        return GlobalAchievements(
            app_id=app_id,
            achievements=[
                GlobalAchievement(name=a["name"], percent=a["percent"])
                for a in achievements
            ],
        )

    def _parse_news(self, app_id: int, data: dict[str, Any]) -> AppNews | None:
        an = data.get("appnews")
        if not an:
            return None
        return AppNews(
            app_id=app_id,
            items=[
                NewsItem(
                    gid=n["gid"],
                    title=n["title"],
                    url=n["url"],
                    author=n.get("author", ""),
                    contents=n.get("contents", ""),
                    date=n["date"],
                    feed_name=n.get("feedname", ""),
                )
                for n in an.get("newsitems", [])
            ],
        )

    def _parse_app_list(self, data: dict[str, Any]) -> AppList:
        response = data.get("response", {})
        return AppList(
            apps=[
                AppListEntry(
                    app_id=a["appid"],
                    name=a.get("name", ""),
                    last_modified=a.get("last_modified", 0),
                    price_change_number=a.get("price_change_number", 0),
                )
                for a in response.get("apps", [])
            ],
            have_more_results=response.get("have_more_results", False),
            last_appid=response.get("last_appid", 0),
        )

    def _parse_steamspy(
        self, app_id: int, data: dict[str, Any]
    ) -> SteamSpyDetails | None:
        """
        Parses raw SteamSpy API response into SteamSpyDetails model.

        Args:
            app_id (int): Steam application ID.
            data (dict[str, Any]): Raw API response data.

        Returns:
            SteamSpyDetails | None: Parsed SteamSpy details or None if not found.
        """
        if not data or data.get("developer") == "":
            return None

        return SteamSpyDetails.model_validate({**data, "app_id": app_id})
