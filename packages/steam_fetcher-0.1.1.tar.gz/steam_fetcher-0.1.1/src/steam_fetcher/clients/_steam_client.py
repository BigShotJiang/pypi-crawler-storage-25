from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Self

import httpx
from httpx import QueryParams
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from steam_fetcher.clients._base import BaseClient

if TYPE_CHECKING:
    from steam_fetcher.models.game import GameDetails
    from steam_fetcher.models.news import AppNews
    from steam_fetcher.models.player import (
        GlobalAchievements,
        PlayerCount,
        ReviewSummary,
        SteamSpyDetails,
    )
    from steam_fetcher.models.search import SearchResult

logger = logging.getLogger(__name__)


class SteamClient(BaseClient):
    """
        Synchronous Steam Store API client.

        Args:
            requests_per_minute (int): Maximum requests per minute (0=unlimited).
            retries (int): Number of retry attempts on failure.
            timeout (float): Request timeout in seconds.

        Example:
    ```python
            with SteamClient() as client:
                game = client.get_game(730)
                players = client.get_player_count(730)
                reviews = client.get_reviews(730)
                results = client.search("counter strike")
    ```
    """

    def __init__(
        self,
        requests_per_minute: int = 200,
        retries: int = 3,
        timeout: float = 10.0,
    ) -> None:
        super().__init__(
            retries=retries,
            timeout=timeout,
        )
        self._client: httpx.Client | None = None
        self._rpm = requests_per_minute
        self._min_interval = (
            60.0 / requests_per_minute if requests_per_minute > 0 else 0
        )
        self._last_request_time = 0.0
        self._rate_lock = threading.Lock()

    def __enter__(self) -> Self:
        """
        Opens HTTP session.

        Returns:
            Self: self
        """
        self._client = httpx.Client(timeout=self._timeout)
        return self

    def __exit__(self, *args: object) -> None:
        """
        Closes HTTP session.

        Args:
            *args (object): Exception info.
        """
        if self._client is not None:
            self._client.close()
            self._client = None

    def _throttle(self) -> None:
        """Enforces rate limiting between requests."""
        if self._min_interval <= 0:
            return
        with self._rate_lock:
            now = time.monotonic()
            elapsed = now - self._last_request_time
            if elapsed < self._min_interval:
                time.sleep(self._min_interval - elapsed)
            self._last_request_time = time.monotonic()

    def _get(
        self, url: str, params: QueryParams | None = None
    ) -> httpx.Response:
        """
        Makes a GET request with rate limiting and retry logic.

        Args:
            url (str): Request URL.
            params (QueryParams | None): Query parameters.

        Returns:
            httpx.Response: HTTP response.

        Raises:
            RuntimeError: If client is not initialized.
        """
        if self._client is None:
            raise RuntimeError(
                "Client is not initialized. Use 'with SteamClient() as client'"
            )

        client = self._client

        def _is_server_error(exc: BaseException) -> bool:
            return isinstance(exc, httpx.HTTPStatusError) and (
                exc.response.status_code >= 500
            )

        @retry(
            stop=stop_after_attempt(self._retries),
            wait=wait_exponential(multiplier=1, min=2, max=60),
            retry=retry_if_exception(_is_server_error),
        )
        def _request() -> httpx.Response:
            self._throttle()
            response = client.get(url, params=params)
            response.raise_for_status()
            return response

        return _request()

    def get_game(
        self,
        app_id: int,
        country: str = "US",
        language: str = "en",
    ) -> GameDetails | None:
        """
        Fetches game details from Steam Store API.

        Args:
            app_id (int): Steam application ID.
            country (str): ISO country code for pricing.
            language (str): Language code for descriptions.

        Returns:
            GameDetails | None: Game details or None if not found.
        """
        response = self._get(
            f"{self._STORE_API_URL}/appdetails",
            params=QueryParams(
                {"appids": app_id, "cc": country, "l": language}
            ),
        )
        result = self._parse_game(app_id, response.json())
        if result is None:
            logger.warning("Game %s not found", app_id)
        return result

    def get_player_count(self, app_id: int) -> PlayerCount | None:
        """
        Fetches current player count for a game.

        Args:
            app_id (int): Steam application ID.

        Returns:
            PlayerCount | None: Player count or None if not found.
        """
        response = self._get(
            f"{self._API_URL}/ISteamUserStats/GetNumberOfCurrentPlayers/v1",
            params=QueryParams({"appid": app_id}),
        )
        result = self._parse_player_count(app_id, response.json())
        if result is None:
            logger.warning("Player count for %s not found", app_id)
        return result

    def get_reviews(
        self,
        app_id: int,
        language: str = "all",
        review_filter: str = "all",
        num_per_page: int = 20,
        cursor: str = "*",
    ) -> ReviewSummary | None:
        """
        Fetches review summary for a game.

        Args:
            app_id (int): Steam application ID.
            language (str): Language filter.
            review_filter (str): Filter: 'all', 'recent', 'updated'.
            num_per_page (int): Reviews per page (max 100).
            cursor (str): Pagination cursor ('*' for first page).

        Returns:
            ReviewSummary | None: Review summary or None if not found.
        """
        response = self._get(
            f"{self._STORE_URL}/appreviews/{app_id}",
            params=QueryParams(
                {
                    "json": 1,
                    "language": language,
                    "purchase_type": "all",
                    "filter": review_filter,
                    "num_per_page": num_per_page,
                    "cursor": cursor,
                }
            ),
        )
        result = self._parse_reviews(app_id, response.json())
        if result is None:
            logger.warning("Reviews for %s not found", app_id)
        return result

    def get_steamspy_details(self, app_id: int) -> SteamSpyDetails | None:
        """
        Fetches game details and statistics from SteamSpy.

        Args:
            app_id (int): Steam application ID.

        Returns:
            SteamSpyDetails | None: SteamSpy details or None if not found.
        """
        response = self._get(
            "https://steamspy.com/api.php",
            params=QueryParams({"request": "appdetails", "appid": app_id}),
        )
        result = self._parse_steamspy(app_id, response.json())
        if result is None:
            logger.warning("SteamSpy details for %s not found", app_id)
        return result

    def search(
        self,
        query: str,
        country: str = "US",
        language: str = "en",
    ) -> SearchResult:
        """
        Searches Steam store for games.

        Args:
            query (str): Search query.
            country (str): ISO country code for pricing.
            language (str): Language code.

        Returns:
            SearchResult: Search results.
        """
        response = self._get(
            f"{self._STORE_API_URL}/storesearch/",
            params=QueryParams(
                {
                    "term": query,
                    "cc": country,
                    "l": language,
                }
            ),
        )
        return self._parse_search(query, response.json())

    def get_global_achievement_percentages(
        self, app_id: int
    ) -> GlobalAchievements | None:
        """
        Fetches global achievement percentages for a game.

        Args:
            app_id (int): Steam application ID.

        Returns:
            GlobalAchievements | None: Global achievements or None.
        """
        response = self._get(
            f"{self._API_URL}/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v2",
            params=QueryParams({"gameid": app_id}),
        )
        result = self._parse_global_achievements(app_id, response.json())
        if result is None:
            logger.warning("Global achievements for %s not found", app_id)
        return result

    def get_news(
        self,
        app_id: int,
        count: int = 20,
        max_length: int = 0,
    ) -> AppNews | None:
        """
        Fetches news for a game.

        Args:
            app_id (int): Steam application ID.
            count (int): Number of news items.
            max_length (int): Max content length (0=full).

        Returns:
            AppNews | None: News or None if not found.
        """
        response = self._get(
            f"{self._API_URL}/ISteamNews/GetNewsForApp/v2",
            params=QueryParams(
                {
                    "appid": app_id,
                    "count": count,
                    "maxlength": max_length,
                }
            ),
        )
        result = self._parse_news(app_id, response.json())
        if result is None:
            logger.warning("News for %s not found", app_id)
        return result
