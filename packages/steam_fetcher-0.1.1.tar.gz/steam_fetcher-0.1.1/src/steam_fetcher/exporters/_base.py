from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pydantic import BaseModel


@runtime_checkable
class BaseExporter(Protocol):
    """
    Protocol for Steam data exporters.

    All exporters must implement the export method
    which accepts a list of Pydantic models and a file path.
    """

    def export(self, data: list[BaseModel], destination: str) -> None:
        """
        Exports data to a destination.

        Args:
            data (list[BaseModel]): List of Pydantic models to export.
            destination (str): Output target (file path or table name).

        Raises:
            ExportError: If export fails.
        """
        ...


class ExportError(Exception):
    """Raised when export operation fails."""
