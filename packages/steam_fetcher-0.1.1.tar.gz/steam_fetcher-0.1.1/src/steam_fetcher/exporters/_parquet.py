from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from steam_fetcher.exporters._base import ExportError

if TYPE_CHECKING:
    from pydantic import BaseModel

logger = logging.getLogger(__name__)

ParquetCompression = Literal[
    "lz4", "uncompressed", "snappy", "gzip", "brotli", "zstd"
]


class ParquetExporter:
    """
        Exports Steam data to Parquet format using polars.

        Args:
            compression (ParquetCompression): Compression algorithm.

        Example:
    ```python
            with SteamClient() as client:
                game = client.get_game(730)

            exporter = ParquetExporter(compression=ParquetCompression.ZSTD)
            exporter.export([game], "games.parquet")
    ```
    """

    def __init__(
        self,
        compression: ParquetCompression = "zstd",
    ) -> None:
        self._compression = compression

    def export(self, data: list[BaseModel], destination: str) -> None:
        """
        Exports data to a Parquet file.

        Args:
            data (list[BaseModel]): List of Pydantic models to export.
            destination (str): Output file path.

        Raises:
            ExportError: If export fails.
            ValueError: If data is empty.
            ImportError: If polars is not installed.
        """
        try:
            import polars as pl
        except ImportError as e:
            raise ImportError(
                "polars is required for ParquetExporter. "
                "Install it with: pip install steam-fetcher[parquet]"
            ) from e

        if not data:
            raise ValueError("Data is empty")

        try:
            output = Path(destination)
            output.parent.mkdir(parents=True, exist_ok=True)

            records = [model.model_dump(mode="json") for model in data]
            df = pl.DataFrame(records)
            df.write_parquet(output, compression=self._compression)

            logger.info("Exported %d records to %s", len(data), destination)
        except ValueError:
            raise
        except Exception as e:
            raise ExportError(f"Failed to export to Parquet: {e}") from e
