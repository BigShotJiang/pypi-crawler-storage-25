from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from steam_fetcher.exporters._base import ExportError

if TYPE_CHECKING:
    from pydantic import BaseModel

logger = logging.getLogger(__name__)


class JsonExporter:
    """
        Exports Steam data to JSON format.

        Args:
            indent (int): JSON indentation level.
            ensure_ascii (bool): Whether to escape non-ASCII characters.

        Example:
    ```python
            with SteamClient() as client:
                game = client.get_game(730)

            exporter = JsonExporter()
            exporter.export([game], "games.json")
    ```
    """

    def __init__(
        self,
        indent: int = 4,
        ensure_ascii: bool = False,
    ) -> None:
        self._indent = indent
        self._ensure_ascii = ensure_ascii

    def export(self, data: list[BaseModel], destination: str) -> None:
        """
        Exports data to a JSON file.

        Args:
            data (list[BaseModel]): List of Pydantic models to export.
            destination (str): Output file path.

        Raises:
            ExportError: If export fails.
            ValueError: If data is empty.
        """
        if not data:
            raise ValueError("Data is empty")

        try:
            output = Path(destination)
            output.parent.mkdir(parents=True, exist_ok=True)

            records = [model.model_dump(mode="json") for model in data]

            with output.open("w", encoding="utf-8") as f:
                json.dump(
                    records,
                    f,
                    indent=self._indent,
                    ensure_ascii=self._ensure_ascii,
                )

            logger.info("Exported %d records to %s", len(data), destination)
        except ValueError:
            raise
        except Exception as e:
            raise ExportError(f"Failed to export to JSON: {e}") from e
