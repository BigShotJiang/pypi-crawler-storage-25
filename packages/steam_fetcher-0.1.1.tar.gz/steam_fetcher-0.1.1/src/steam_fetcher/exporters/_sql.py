from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from steam_fetcher.exporters._base import ExportError

if TYPE_CHECKING:
    import sqlalchemy as sa
    from pydantic import BaseModel

logger = logging.getLogger(__name__)


class SqlExporter:
    """
    Exports Steam data to SQL database using SQLAlchemy.

    Args:
        url (str): SQLAlchemy connection URL e.g.:
            - 'sqlite:///games.db'
            - 'postgresql://user:pass@localhost/steam'
            - 'mysql://user:pass@localhost/steam'
        if_exists (str): What to do if table exists: 'fail', 'replace', 'append'.
        chunk_size (int): Number of records to insert per batch.

    Example:
        ```python
        with SteamClient() as client:
            game = client.get_game(730)

        exporter = SqlExporter(url="sqlite:///games.db")
        exporter.export([game], "games")
        ```
    """

    def __init__(
        self,
        url: str,
        if_exists: str = "append",
        chunk_size: int = 1000,
    ) -> None:
        self._url = url
        self._if_exists = if_exists
        self._chunk_size = chunk_size

    def export(self, data: list[BaseModel], destination: str) -> None:
        """
        Exports data to a SQL table.

        Args:
            data (list[BaseModel]): List of Pydantic models to export.
            destination (str): Target table name.

        Raises:
            ExportError: If export fails.
            ValueError: If data is empty.
            ImportError: If sqlalchemy is not installed.
        """
        try:
            import sqlalchemy as sa
        except ImportError as e:
            raise ImportError(
                "sqlalchemy is required for SqlExporter. "
                "Install it with: pip install steam-fetcher[sql]"
            ) from e

        if not data:
            raise ValueError("Data is empty")

        try:
            records = [
                _flatten_record(model.model_dump(mode="json")) for model in data
            ]

            engine = sa.create_engine(self._url)
            metadata = sa.MetaData()

            columns = _infer_columns(records[0])
            table_obj = sa.Table(destination, metadata, *columns)

            with engine.begin() as conn:
                if self._if_exists == "replace":
                    table_obj.drop(conn, checkfirst=True)
                    table_obj.create(conn)
                elif self._if_exists == "fail" and sa.inspect(engine).has_table(
                    destination
                ):
                    raise ExportError(f"Table '{destination}' already exists")
                else:
                    table_obj.create(conn, checkfirst=True)

                for i in range(0, len(records), self._chunk_size):
                    chunk = records[i : i + self._chunk_size]
                    conn.execute(table_obj.insert(), chunk)

            logger.info(
                "Exported %d records to table '%s'", len(data), destination
            )
        except (ValueError, ExportError):
            raise
        except Exception as e:
            raise ExportError(f"Failed to export to SQL: {e}") from e


def _flatten_record(record: dict[str, object]) -> dict[str, object]:
    """
    Flattens nested dicts and lists to strings for SQL storage.

    Args:
        record (dict[str, object]): Record to flatten.

    Returns:
        dict[str, object]: Flattened record.
    """
    result: dict[str, object] = {}
    for key, value in record.items():
        if isinstance(value, dict | list):
            result[key] = str(value)
        else:
            result[key] = value
    return result


def _infer_columns(record: dict[str, object]) -> list[sa.Column[Any]]:
    """
    Infers SQLAlchemy columns from a record.

    Args:
        record (dict[str, object]): Sample record to infer columns from.

    Returns:
        list[sa.Column[Any]]: List of SQLAlchemy Column objects.
    """
    import sqlalchemy as sa

    type_map: dict[type, sa.types.TypeEngine[Any]] = {
        int: sa.Integer(),
        float: sa.Float(),
        bool: sa.Boolean(),
        str: sa.Text(),
    }

    columns: list[sa.Column[Any]] = []
    for key, value in record.items():
        col_type: sa.types.TypeEngine[Any] = type_map.get(
            type(value), sa.Text()
        )
        columns.append(sa.Column(key, col_type))
    return columns
