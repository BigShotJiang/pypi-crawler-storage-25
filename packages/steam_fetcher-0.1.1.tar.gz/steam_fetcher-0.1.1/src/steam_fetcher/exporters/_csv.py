from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from steam_fetcher.exporters._base import ExportError

if TYPE_CHECKING:
    from pydantic import BaseModel

logger = logging.getLogger(__name__)


class CsvExporter:
    """
        Exports Steam data to CSV format.

        Args:
            delimiter (str): CSV delimiter character.
            flatten (bool): Whether to flatten nested fields to strings.

        Example:
    ```python
            with SteamClient() as client:
                game = client.get_game(730)

            exporter = CsvExporter()
            exporter.export([game], "games.csv")
    ```
    """

    def __init__(
        self,
        delimiter: str = ",",
        flatten: bool = True,
    ) -> None:
        self._delimiter = delimiter
        self._flatten = flatten

    def _flatten_value(self, value: Any) -> str:  # noqa: ANN401
        """
        Flattens nested values to string representation.

        Args:
            value (Any): Value to flatten.

        Returns:
            str: String representation of the value.
        """
        if isinstance(value, list):
            return "|".join(str(v) for v in value)
        if isinstance(value, dict):
            return str(value)
        if value is None:
            return ""
        return str(value)

    def export(self, data: list[BaseModel], destination: str) -> None:
        """
        Exports data to a CSV file.

        Args:
            data (list[BaseModel]): List of Pydantic models to export.
            destination (str): Output file path.

        Raises:
            ExportError: If export fails.
            ValueError: If data is empty.
        """
        if not data:
            raise ValueError("Data is empty")

        try:
            output = Path(destination)
            output.parent.mkdir(parents=True, exist_ok=True)

            records = [model.model_dump(mode="json") for model in data]
            fieldnames = list(records[0].keys())

            with output.open("w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(
                    f, fieldnames=fieldnames, delimiter=self._delimiter
                )
                writer.writeheader()

                for record in records:
                    if self._flatten:
                        record = {
                            k: self._flatten_value(v) for k, v in record.items()
                        }
                    writer.writerow(record)

            logger.info("Exported %d records to %s", len(data), destination)
        except ValueError:
            raise
        except Exception as e:
            raise ExportError(f"Failed to export to CSV: {e}") from e
