from __future__ import annotations

import logging
from enum import StrEnum
from typing import TYPE_CHECKING

import typer

from steam_fetcher.exporters._csv import CsvExporter
from steam_fetcher.exporters._json import JsonExporter
from steam_fetcher.exporters._parquet import ParquetExporter
from steam_fetcher.exporters._sql import SqlExporter

if TYPE_CHECKING:
    from pydantic import BaseModel

logger = logging.getLogger(__name__)


class OutputFormat(StrEnum):
    """Supported output formats."""

    JSON = "json"
    CSV = "csv"
    PARQUET = "parquet"
    SQL = "sql"


def format_callback(value: str) -> str:
    """
    Validates output format value.

    Args:
        value (str): Output format string.

    Returns:
        str: Validated format string.

    Raises:
        typer.BadParameter: If format is not supported.
    """
    if value not in OutputFormat:
        raise typer.BadParameter(
            f"Unsupported format '{value}'. Choose from: {', '.join(OutputFormat)}"
        )
    return value


def export_data(
    data: list[BaseModel],
    output_format: str,
    output: str,
    url: str = "",
) -> None:
    """
    Exports data to the specified format.

    Args:
        data (list[BaseModel]): List of Pydantic models to export.
        format (str): Output format.
        output (str): Output file path.
        url (str): SQLAlchemy connection URL (only for sql format).

    Raises:
        typer.Exit: If export fails.
    """
    try:
        match OutputFormat(output_format):
            case OutputFormat.JSON:
                JsonExporter().export(data, output)
            case OutputFormat.CSV:
                CsvExporter().export(data, output)
            case OutputFormat.PARQUET:
                ParquetExporter().export(data, output)
            case OutputFormat.SQL:
                if not url:
                    typer.echo("--url is required for sql format", err=True)
                    raise typer.Exit(1)
                SqlExporter(url=url).export(data, output)

        typer.echo(f"Exported to {output}")
    except Exception as e:
        logger.exception("Export failed")
        typer.echo(f"Export failed: {e}", err=True)
        raise typer.Exit(1) from e
