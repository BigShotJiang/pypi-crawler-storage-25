from __future__ import annotations

import typer

from steam_fetcher.cli._utils import export_data, format_callback
from steam_fetcher.clients._steam_auth_client import SteamAuthClient

user_app = typer.Typer(
    name="user",
    help="Commands for fetching user data.",
    no_args_is_help=True,
)


@user_app.command()
def profile(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch public profile for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        user = client.get_user_profile(steam_id)

    if user is None:
        typer.echo(f"User {steam_id} not found", err=True)
        raise typer.Exit(1)

    export_data([user], output_format=output_format, output=output, url=url)


@user_app.command()
def library(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch game library for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        lib = client.get_user_library(steam_id)

    if lib is None:
        typer.echo(f"Library for {steam_id} not found", err=True)
        raise typer.Exit(1)

    export_data([lib], output_format=output_format, output=output, url=url)


@user_app.command()
def achievements(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    app_id: int = typer.Argument(..., help="Steam application ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch achievements for a Steam user in a specific game.
    """
    with SteamAuthClient(api_key=api_key) as client:
        game_achievements = client.get_user_achievements(steam_id, app_id)

    if game_achievements is None:
        typer.echo(
            f"Achievements for user {steam_id} game {app_id} not found",
            err=True,
        )
        raise typer.Exit(1)

    export_data(
        [game_achievements],
        output_format=output_format,
        output=output,
        url=url,
    )


@user_app.command()
def friends(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option("", "--url", "-u", help="SQLAlchemy URL"),
) -> None:
    """
    Fetch friend list for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_user_friends(steam_id)

    if result is None:
        typer.echo(f"Friends for {steam_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        [result],
        output_format=output_format,
        output=output,
        url=url,
    )


@user_app.command()
def bans(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option("", "--url", "-u", help="SQLAlchemy URL"),
) -> None:
    """
    Fetch ban info for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_user_bans([steam_id])

    if not result:
        typer.echo(f"Bans for {steam_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        list(result),
        output_format=output_format,
        output=output,
        url=url,
    )


@user_app.command()
def resolve(
    vanity_url: str = typer.Argument(..., help="Vanity URL name"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
) -> None:
    """
    Resolve a vanity URL to a Steam ID.
    """
    with SteamAuthClient(api_key=api_key) as client:
        steam_id = client.resolve_vanity_url(vanity_url)

    if steam_id is None:
        typer.echo(f"Vanity URL '{vanity_url}' not found", err=True)
        raise typer.Exit(1)

    typer.echo(steam_id)


@user_app.command(name="recently-played")
def recently_played(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option("", "--url", "-u", help="SQLAlchemy URL"),
) -> None:
    """
    Fetch recently played games for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_recently_played(steam_id)

    if result is None:
        typer.echo(
            f"Recently played for {steam_id} not found",
            err=True,
        )
        raise typer.Exit(1)

    export_data(
        [result],
        output_format=output_format,
        output=output,
        url=url,
    )


@user_app.command()
def level(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
) -> None:
    """
    Fetch Steam level for a user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_steam_level(steam_id)

    if result is None:
        typer.echo(f"Level for {steam_id} not found", err=True)
        raise typer.Exit(1)

    typer.echo(f"Steam Level: {result}")


@user_app.command()
def badges(
    steam_id: str = typer.Argument(..., help="Steam 64-bit user ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option("", "--url", "-u", help="SQLAlchemy URL"),
) -> None:
    """
    Fetch badges for a Steam user.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_user_badges(steam_id)

    if result is None:
        typer.echo(f"Badges for {steam_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        [result],
        output_format=output_format,
        output=output,
        url=url,
    )
