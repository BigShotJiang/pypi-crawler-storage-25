from __future__ import annotations

import typer

from steam_fetcher.cli._utils import export_data, format_callback
from steam_fetcher.clients._steam_auth_client import SteamAuthClient
from steam_fetcher.clients._steam_client import SteamClient

game_app = typer.Typer(
    name="game",
    help="Commands for fetching game data.",
    no_args_is_help=True,
)


@game_app.command()
def details(
    app_id: int = typer.Argument(..., help="Steam application ID"),
    country: str = typer.Option(
        "US", "--country", "-c", help="ISO country code for pricing"
    ),
    language: str = typer.Option(
        "en", "--language", "-L", help="Language code"
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch game details by Steam application ID.
    """
    with SteamClient() as client:
        game = client.get_game(app_id, country=country, language=language)

    if game is None:
        typer.echo(f"Game {app_id} not found", err=True)
        raise typer.Exit(1)

    export_data([game], output_format=output_format, output=output, url=url)


@game_app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    country: str = typer.Option(
        "US", "--country", "-c", help="ISO country code"
    ),
    language: str = typer.Option(
        "en", "--language", "-L", help="Language code"
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Search Steam store for games.
    """
    with SteamClient() as client:
        results = client.search(query, country=country, language=language)

    export_data([results], output_format=output_format, output=output, url=url)


@game_app.command()
def players(
    app_id: int = typer.Argument(..., help="Steam application ID"),
) -> None:
    """
    Fetch current player count for a game.
    """
    with SteamClient() as client:
        count = client.get_player_count(app_id)

    if count is None:
        typer.echo(f"Player count for {app_id} not found", err=True)
        raise typer.Exit(1)

    typer.echo(f"Current players: {count.player_count}")


@game_app.command()
def reviews(
    app_id: int = typer.Argument(..., help="Steam application ID"),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch review summary for a game.
    """
    with SteamClient() as client:
        summary = client.get_reviews(app_id)

    if summary is None:
        typer.echo(f"Reviews for {app_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        [summary],
        output_format=output_format,
        output=output,
        url=url,
    )


@game_app.command()
def schema(
    app_id: int = typer.Argument(..., help="Steam application ID"),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        envvar="STEAM_API_KEY",
        help="Steam Web API key",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch game schema (achievements and stats definitions). Requires API key.
    """
    with SteamAuthClient(api_key=api_key) as client:
        result = client.get_game_schema(app_id)

    if result is None:
        typer.echo(f"Schema for {app_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        [result],
        output_format=output_format,
        output=output,
        url=url,
    )


@game_app.command()
def news(
    app_id: int = typer.Argument(..., help="Steam application ID"),
    count: int = typer.Option(20, "--count", "-n", help="Number of news items"),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, csv, parquet, sql",
        callback=format_callback,
    ),
    output: str = typer.Option(
        "output", "--output", "-o", help="Output file path"
    ),
    url: str = typer.Option(
        "",
        "--url",
        "-u",
        help="SQLAlchemy connection URL (only for sql format)",
    ),
) -> None:
    """
    Fetch news for a game.
    """
    with SteamClient() as client:
        result = client.get_news(app_id, count=count)

    if result is None:
        typer.echo(f"News for {app_id} not found", err=True)
        raise typer.Exit(1)

    export_data(
        [result],
        output_format=output_format,
        output=output,
        url=url,
    )
