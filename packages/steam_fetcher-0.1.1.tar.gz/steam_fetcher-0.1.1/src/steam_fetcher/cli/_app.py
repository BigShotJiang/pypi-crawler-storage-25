from __future__ import annotations

import typer

from steam_fetcher.cli.commands._game import game_app
from steam_fetcher.cli.commands._user import user_app

app = typer.Typer(
    name="steam-fetcher",
    help="Fetch and export Steam data.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
)

app.add_typer(game_app, name="games")
app.add_typer(user_app, name="users")


def main() -> None:
    """
    Entry point for the CLI.
    """
    app()
