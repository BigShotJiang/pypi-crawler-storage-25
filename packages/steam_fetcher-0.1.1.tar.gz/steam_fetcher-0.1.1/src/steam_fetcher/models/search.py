from __future__ import annotations

from pydantic import BaseModel, Field, HttpUrl

from steam_fetcher.models.game import Platforms  # noqa: TC001


class SearchEntry(BaseModel):
    """Single game entry from Steam search results."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str = Field(..., description="Game name")
    icon: HttpUrl | None = Field(None, description="Game icon URL")
    price: str | None = Field(None, description="Formatted price string")
    platforms: Platforms | None = Field(None, description="Supported platforms")


class SearchResult(BaseModel):
    """Steam store search results."""

    term: str = Field(..., description="Search query term")
    total: int = Field(..., description="Total number of results found", ge=0)
    entries: list[SearchEntry] = Field(
        default_factory=list, description="List of search result entries"
    )
