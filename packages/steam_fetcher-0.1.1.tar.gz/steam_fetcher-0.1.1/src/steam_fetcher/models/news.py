from __future__ import annotations

from pydantic import BaseModel, Field


class NewsItem(BaseModel):
    """Steam news item."""

    gid: str = Field(..., description="News item global ID")
    title: str = Field(..., description="News title")
    url: str = Field(..., description="News URL")
    author: str = Field(..., description="Author name")
    contents: str = Field(..., description="News content")
    date: int = Field(..., description="Unix timestamp of publication", ge=0)
    feed_name: str = Field(..., description="Feed name")


class AppNews(BaseModel):
    """News for a Steam application."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    items: list[NewsItem] = Field(
        default_factory=list, description="List of news items"
    )
