from __future__ import annotations

from pydantic import BaseModel, Field, HttpUrl, computed_field


class Avatar(BaseModel):
    """Steam user avatar URLs."""

    small: HttpUrl = Field(..., description="Small avatar URL (32x32)")
    medium: HttpUrl = Field(..., description="Medium avatar URL (64x64)")
    full: HttpUrl = Field(..., description="Full avatar URL (184x184)")


class UserProfile(BaseModel):
    """Steam user public profile."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    username: str = Field(..., description="Steam display name")
    real_name: str | None = Field(
        None, description="User's real name if set and public"
    )
    avatar: Avatar = Field(..., description="Avatar URLs")
    profile_url: HttpUrl = Field(..., description="Steam community profile URL")
    country_code: str | None = Field(
        None, description="ISO 3166-1 alpha-2 country code"
    )
    state_code: str | None = Field(None, description="State or province code")
    time_created: int | None = Field(
        None, description="Unix timestamp of account creation", ge=0
    )
    last_logoff: int | None = Field(
        None, description="Unix timestamp of last logoff", ge=0
    )
    is_public: bool = Field(
        False, description="Whether the profile is publicly visible"
    )
    persona_state: int | None = Field(
        None,
        description="Online status (0=Offline, 1=Online, 2=Busy, 3=Away, 4=Snooze, 5=Looking to trade, 6=Looking to play)",
        ge=0,
    )
    game_id: int | None = Field(
        None, description="App ID of game currently playing", ge=0
    )
    game_extra_info: str | None = Field(
        None, description="Name of game currently playing"
    )


class Friend(BaseModel):
    """Steam friend entry."""

    steam_id: str = Field(..., description="Friend's Steam 64-bit ID")
    relationship: str = Field(..., description="Relationship type")
    friend_since: int = Field(
        ..., description="Unix timestamp of when friendship was created", ge=0
    )


class FriendList(BaseModel):
    """User's Steam friend list."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    friends: list[Friend] = Field(
        default_factory=list, description="List of friends"
    )


class PlayerBan(BaseModel):
    """Steam player ban info."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    community_banned: bool = Field(..., description="Whether community banned")
    vac_banned: bool = Field(..., description="Whether VAC banned")
    number_of_vac_bans: int = Field(..., description="Number of VAC bans", ge=0)
    days_since_last_ban: int = Field(
        ..., description="Days since last ban", ge=0
    )
    number_of_game_bans: int = Field(
        ..., description="Number of game bans", ge=0
    )
    economy_ban: str = Field(..., description="Economy ban status")


class Achievement(BaseModel):
    """Steam user achievement."""

    api_name: str = Field(..., description="Achievement API name")
    achieved: bool = Field(
        ..., description="Whether the achievement is unlocked"
    )
    unlock_time: int | None = Field(
        None, description="Unix timestamp of unlock time", ge=0
    )
    name: str | None = Field(None, description="Achievement display name")
    description: str | None = Field(None, description="Achievement description")


class GameAchievements(BaseModel):
    """Achievements for a specific game."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    game_name: str = Field(..., description="Game name")
    achievements: list[Achievement] = Field(
        default_factory=list, description="List of achievements"
    )


class LibraryGame(BaseModel):
    """Game in user's Steam library."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str | None = Field(None, description="Game name")
    playtime_forever: int = Field(
        0, description="Total playtime in minutes", ge=0
    )
    playtime_2weeks: int | None = Field(
        None, description="Playtime in last 2 weeks in minutes", ge=0
    )
    img_icon_url: str | None = Field(None, description="Game icon image hash")
    last_played: int | None = Field(
        None, description="Unix timestamp of last play session", ge=0
    )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def icon_url(self) -> str | None:
        """Full icon URL constructed from app_id and hash."""
        if not self.img_icon_url:
            return None
        return f"https://media.steampowered.com/steamcommunity/public/images/apps/{self.app_id}/{self.img_icon_url}.jpg"


class UserLibrary(BaseModel):
    """User's Steam game library."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    game_count: int = Field(
        ..., description="Total number of games in library", ge=0
    )
    games: list[LibraryGame] = Field(
        default_factory=list, description="List of games in library"
    )


class RecentGame(BaseModel):
    """Recently played game."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str = Field(..., description="Game name")
    playtime_2weeks: int = Field(
        ..., description="Playtime in last 2 weeks in minutes", ge=0
    )
    playtime_forever: int = Field(
        ..., description="Total playtime in minutes", ge=0
    )
    img_icon_url: str | None = Field(None, description="Game icon image hash")


class RecentlyPlayed(BaseModel):
    """User's recently played games."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    total_count: int = Field(
        ..., description="Total number of recently played games", ge=0
    )
    games: list[RecentGame] = Field(
        default_factory=list, description="List of recently played games"
    )


class Badge(BaseModel):
    """Steam user badge."""

    badge_id: int = Field(..., description="Badge ID", ge=0)
    level: int = Field(..., description="Badge level", ge=0)
    completion_time: int = Field(
        ..., description="Unix timestamp of completion", ge=0
    )
    xp: int = Field(..., description="XP earned from badge", ge=0)
    scarcity: int = Field(
        ..., description="Number of users who have this badge", ge=0
    )


class UserBadges(BaseModel):
    """User's Steam badges."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    badges: list[Badge] = Field(
        default_factory=list, description="List of badges"
    )
    player_xp: int = Field(..., description="Total player XP", ge=0)
    player_level: int = Field(..., description="Player level", ge=0)


class WishlistItem(BaseModel):
    """Steam wishlist item."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    priority: int = Field(0, description="Wishlist priority", ge=0)
    date_added: int | None = Field(
        None, description="Unix timestamp when added", ge=0
    )
