from __future__ import annotations

from pydantic import BaseModel, Field


class PlayerCount(BaseModel):
    """Current players online for a Steam game."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    player_count: int = Field(
        ..., description="Current number of players online", ge=0
    )


class Review(BaseModel):
    """Individual Steam user review."""

    recommendation_id: str = Field(..., description="Unique recommendation ID")
    author_steam_id: str = Field(..., description="Review author Steam ID")
    language: str = Field(..., description="Review language")
    review: str = Field(..., description="Review text")
    timestamp_created: int = Field(
        ..., description="Unix timestamp of review creation", ge=0
    )
    voted_up: bool = Field(..., description="Whether the review is positive")
    votes_up: int = Field(..., description="Number of upvotes", ge=0)
    votes_funny: int = Field(..., description="Number of funny votes", ge=0)
    weighted_vote_score: float = Field(..., description="Weighted vote score")
    comment_count: int = Field(..., description="Number of comments", ge=0)
    steam_purchase: bool = Field(..., description="Whether purchased on Steam")
    received_for_free: bool = Field(
        ..., description="Whether received for free"
    )


class ReviewSummary(BaseModel):
    """Steam game review summary."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    total: int = Field(..., description="Total number of reviews", ge=0)
    positive: int = Field(..., description="Number of positive reviews", ge=0)
    negative: int = Field(..., description="Number of negative reviews", ge=0)
    score: int = Field(
        ..., description="Review score from 0 to 10", ge=0, le=10
    )
    score_description: str = Field(
        ..., description="Review score description e.g. 'Very Positive'"
    )
    review_type: str = Field(..., description="Review type filter e.g. 'all'")
    purchase_type: str = Field(
        ..., description="Purchase type filter e.g. 'all'"
    )
    cursor: str | None = Field(None, description="Cursor for pagination")
    reviews: list[Review] = Field(
        default_factory=list, description="List of individual reviews"
    )


class SteamSpyDetails(BaseModel):
    """SteamSpy game details and statistics."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str = Field(..., description="Game name")
    developer: str = Field(..., description="Developer name")
    publisher: str = Field(..., description="Publisher name")
    score_rank: str = Field(..., description="Score rank among all games")
    positive: int = Field(..., description="Number of positive reviews", ge=0)
    negative: int = Field(..., description="Number of negative reviews", ge=0)
    userscore: int = Field(..., description="User score", ge=0)
    owners: str = Field(
        ...,
        description="Estimated owners range e.g. '1,000,000 .. 2,000,000'",
    )
    average_forever: int = Field(
        ..., description="Average playtime forever in minutes", ge=0
    )
    average_2weeks: int = Field(
        ...,
        description="Average playtime in last 2 weeks in minutes",
        ge=0,
    )
    median_forever: int = Field(
        ..., description="Median playtime forever in minutes", ge=0
    )
    median_2weeks: int = Field(
        ...,
        description="Median playtime in last 2 weeks in minutes",
        ge=0,
    )
    ccu: int = Field(0, description="Current concurrent users", ge=0)
    price: str = Field("0", description="Game price in cents")
    discount: str = Field("0", description="Current discount percentage")
    tags: dict[str, int] = Field(
        default_factory=dict, description="Tags with vote counts"
    )


class GlobalAchievement(BaseModel):
    """Global achievement percentage."""

    name: str = Field(..., description="Achievement API name")
    percent: float = Field(
        ..., description="Percentage of players who unlocked it", ge=0
    )


class GlobalAchievements(BaseModel):
    """Global achievement percentages for a game."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    achievements: list[GlobalAchievement] = Field(
        default_factory=list, description="List of achievements"
    )


class AchievementSchema(BaseModel):
    """Achievement schema definition."""

    name: str = Field(..., description="Achievement API name")
    display_name: str = Field(..., description="Achievement display name")
    description: str | None = Field(None, description="Achievement description")
    icon: str | None = Field(None, description="Icon URL")
    icon_gray: str | None = Field(None, description="Gray icon URL")


class StatSchema(BaseModel):
    """Stat schema definition."""

    name: str = Field(..., description="Stat API name")
    display_name: str = Field(..., description="Stat display name")


class GameSchema(BaseModel):
    """Game schema with achievements and stats definitions."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    game_name: str = Field(..., description="Game name")
    achievements: list[AchievementSchema] = Field(
        default_factory=list, description="List of achievement schemas"
    )
    stats: list[StatSchema] = Field(
        default_factory=list, description="List of stat schemas"
    )


class StatEntry(BaseModel):
    """User stat entry for a game."""

    name: str = Field(..., description="Stat name")
    value: int = Field(..., description="Stat value")


class UserStats(BaseModel):
    """User stats for a specific game."""

    steam_id: str = Field(..., description="Steam 64-bit user ID")
    app_id: int = Field(..., description="Steam application ID", ge=0)
    game_name: str = Field(..., description="Game name")
    stats: list[StatEntry] = Field(
        default_factory=list, description="List of stats"
    )
