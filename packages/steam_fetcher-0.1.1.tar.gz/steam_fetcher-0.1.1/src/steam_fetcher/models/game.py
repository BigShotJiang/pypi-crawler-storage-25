from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field, HttpUrl


class AppType(StrEnum):
    """Steam application type."""

    GAME = "game"
    DLC = "dlc"
    DEMO = "demo"
    MOD = "mod"
    VIDEO = "video"
    SERIES = "series"
    EPISODE = "episode"
    BUNDLE = "bundle"
    ADVERTISING = "advertising"


class Price(BaseModel):
    """Steam game price information."""

    currency: str = Field(..., description="Currency code e.g. USD")
    initial: float = Field(..., description="Initial price in cents", ge=0)
    final: float = Field(
        ..., description="Final price in cents after discount", ge=0
    )
    discount_percent: int = Field(
        ..., description="Discount percentage", ge=0, le=100
    )
    initial_formatted: str = Field(
        ..., description="Initial price formatted string"
    )
    final_formatted: str = Field(
        ..., description="Final price formatted string"
    )


class Screenshot(BaseModel):
    """Steam game screenshot."""

    id: int = Field(..., description="Screenshot ID", ge=0)
    path_thumbnail: HttpUrl = Field(..., description="Thumbnail screenshot URL")
    path_full: HttpUrl = Field(
        ..., description="Full resolution screenshot URL"
    )


class Movie(BaseModel):
    """Steam game movie/trailer."""

    id: int = Field(..., description="Movie ID", ge=0)
    name: str = Field(..., description="Movie name")
    thumbnail: HttpUrl = Field(..., description="Movie thumbnail URL")
    webm_max: HttpUrl | None = Field(None, description="Max quality WebM URL")
    mp4_max: HttpUrl | None = Field(None, description="Max quality MP4 URL")


class Category(BaseModel):
    """Steam game category."""

    id: int = Field(..., description="Category ID", ge=0)
    description: str = Field(..., description="Category description")


class Genre(BaseModel):
    """Steam game genre."""

    id: int = Field(..., description="Genre ID", ge=0)
    description: str = Field(..., description="Genre description")


class Platforms(BaseModel):
    """Supported platforms."""

    windows: bool = Field(False, description="Windows support")
    mac: bool = Field(False, description="macOS support")
    linux: bool = Field(False, description="Linux support")


class Metacritic(BaseModel):
    """Metacritic score and url."""

    score: int = Field(..., description="Metacritic score", ge=0, le=100)
    url: HttpUrl = Field(..., description="Metacritic review URL")


class ReleaseDate(BaseModel):
    """Steam game release date."""

    coming_soon: bool = Field(
        ..., description="Whether the game is not yet released"
    )
    date: str | None = Field(
        None, description="Release date string as returned by Steam"
    )


class AppListEntry(BaseModel):
    """Entry from IStoreService/GetAppList."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str = Field("", description="Application name")
    last_modified: int = Field(
        0, description="Last modified Unix timestamp", ge=0
    )
    price_change_number: int = Field(0, description="Price change number", ge=0)


class AppList(BaseModel):
    """Paginated list of Steam applications."""

    apps: list[AppListEntry] = Field(
        default_factory=list, description="List of applications"
    )
    have_more_results: bool = Field(
        False, description="Whether more results are available"
    )
    last_appid: int = Field(
        0, description="Last app ID for cursor pagination", ge=0
    )


class GameDetails(BaseModel):
    """Full Steam game details from Store API."""

    app_id: int = Field(..., description="Steam application ID", ge=0)
    name: str = Field(..., description="Game name")
    type: AppType = Field(..., description="Application type")
    is_free: bool = Field(..., description="Whether the game is free to play")
    short_description: str | None = Field(
        None, description="Short game description"
    )
    about_the_game: str | None = Field(
        None, description="About the game section"
    )
    detailed_description: str | None = Field(
        None, description="Full detailed description"
    )
    supported_languages: list[str] = Field(
        default_factory=list, description="List of supported languages"
    )
    header_image: HttpUrl | None = Field(None, description="Header image URL")
    website: HttpUrl | None = Field(
        None, description="Official game website URL"
    )
    developers: list[str] = Field(
        default_factory=list, description="List of developers"
    )
    publishers: list[str] = Field(
        default_factory=list, description="List of publishers"
    )
    price: Price | None = Field(
        None, description="Price information, None if free"
    )
    platforms: Platforms | None = Field(None, description="Supported platforms")
    metacritic: Metacritic | None = Field(
        None, description="Metacritic score, None if not available"
    )
    categories: list[Category] = Field(
        default_factory=list, description="List of Steam categories"
    )
    genres: list[Genre] = Field(
        default_factory=list, description="List of genres"
    )
    screenshots: list[Screenshot] = Field(
        default_factory=list, description="List of screenshots"
    )
    movies: list[Movie] = Field(
        default_factory=list, description="List of trailers"
    )
    release_date: ReleaseDate | None = Field(
        None, description="Release date information"
    )
    dlc_count: int = Field(0, description="Number of DLCs available", ge=0)
    achievements: int = Field(
        0, description="Total number of achievements", ge=0
    )
    recommendations: int = Field(
        0, description="Total number of recommendations", ge=0
    )
    required_age: int = Field(0, description="Minimum required age", ge=0)
