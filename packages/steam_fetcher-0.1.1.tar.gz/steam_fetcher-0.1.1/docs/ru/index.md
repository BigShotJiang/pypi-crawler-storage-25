# steam-fetcher

Типизированный Python-клиент для Steam Store API, Steam Web API и SteamSpy API.

## Возможности

- **Синхронный и асинхронный клиенты** с одинаковым API
- **Модели Pydantic v2** для всех ответов
- **Rate limiting** — sync (threading) и async (aiolimiter)
- **Повторные запросы** с экспоненциальной задержкой (только на 5xx ошибки)
- **Экспортеры** — JSON, CSV, Parquet, SQL
- **CLI** через typer
- **Безопасность API-ключа** через `SecretStr`

## Быстрый пример

```python
from steam_fetcher import SteamClient

with SteamClient() as client:
    game = client.get_game(730)
    print(game.name)  # Counter-Strike 2

    players = client.get_player_count(730)
    print(players.player_count)  # 684339

    results = client.search("half-life")
    for entry in results.entries:
        print(f"{entry.name} — {entry.price}")

    reviews = client.get_reviews(730, num_per_page=5)
    print(f"{reviews.score_description}: {reviews.positive}/{reviews.total}")

    news = client.get_news(730, count=3)
    for item in news.items:
        print(item.title)
```

## Асинхронный пример

```python
import asyncio
from steam_fetcher import AsyncSteamClient

async def main():
    async with AsyncSteamClient() as client:
        games = await asyncio.gather(
            client.get_game(730),
            client.get_game(570),
            client.get_game(440),
        )
        for g in games:
            if g:
                print(g.name)

asyncio.run(main())
```

## Пример с авторизацией

```python
from steam_fetcher import SteamAuthClient

with SteamAuthClient(api_key="YOUR_KEY") as client:
    profile = client.get_user_profile("76561198000000000")
    friends = client.get_user_friends("76561198000000000")
    level = client.get_steam_level("76561198000000000")
```

## Установка

```bash
pip install steam-fetcher
```

Опциональные зависимости:

```bash
pip install steam-fetcher[async]     # асинхронный клиент
pip install steam-fetcher[parquet]   # Parquet-экспорт (polars)
pip install steam-fetcher[sql]       # SQL-экспорт (SQLAlchemy)
pip install steam-fetcher[cli]       # CLI (typer)
pip install steam-fetcher[all]       # всё сразу
```

## Далее

- [Начало работы](getting-started.md) — установка, настройка, первые шаги
- [SteamClient](api/client.md) — публичный клиент (7 методов)
- [SteamAuthClient](api/auth_client.md) — клиент с авторизацией (14 дополнительных методов)
- [Модели](api/models.md) — все Pydantic-модели
- [Экспортеры](api/exporters.md) — сохранение данных в файлы и базы данных
