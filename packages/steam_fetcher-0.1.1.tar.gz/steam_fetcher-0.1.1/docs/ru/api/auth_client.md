# SteamAuthClient / AsyncSteamAuthClient

Клиенты Steam Web API. Требуют [Steam Web API key](https://steamcommunity.com/dev/apikey).

Эти клиенты **расширяют** публичные клиенты, поэтому все методы из [`SteamClient`](client.md) / [`AsyncSteamClient`](client.md) также доступны.

## SteamAuthClient

Синхронный клиент с авторизацией.

```python
from steam_fetcher import SteamAuthClient

with SteamAuthClient(api_key="YOUR_KEY") as client:
    profile = client.get_user_profile("76561198000000000")
```

### Конструктор

```python
SteamAuthClient(
    api_key: SecretStr | str,
    requests_per_minute: int = 200,
    retries: int = 3,
    timeout: float = 10.0,
)
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `api_key` | `SecretStr \| str` | *обязателен* | Steam Web API key |
| `requests_per_minute` | `int` | `200` | Макс. запросов в минуту (rate limiting) |
| `retries` | `int` | `3` | Повторные попытки с экспоненциальной задержкой |
| `timeout` | `float` | `10.0` | Таймаут запроса в секундах |

API-ключ оборачивается в `pydantic.SecretStr` — он не появится в `repr()`, логах или стек-трейсах.

### Методы

Все методы `SteamClient` плюс:

#### `get_user_profile(steam_id: str) -> UserProfile | None`

Получает публичный профиль пользователя.

```python
profile = client.get_user_profile("76561198000000000")
if profile:
    print(profile.username)
    print(profile.avatar.full)       # URL аватара в полном размере
    print(profile.country_code)      # "US", "RU" и т.д.
    print(profile.is_public)         # True если профиль публичный
    print(profile.time_created)      # Unix timestamp
    print(profile.last_logoff)       # Unix timestamp
```

---

#### `get_user_library(steam_id: str) -> UserLibrary | None`

Получает библиотеку игр пользователя.

```python
library = client.get_user_library("76561198000000000")
if library:
    print(f"Игр: {library.game_count}")
    for game in library.games:
        hours = game.playtime_forever / 60
        print(f"  {game.name}: {hours:.0f}ч")
        if game.playtime_2weeks:
            print(f"    Последние 2 недели: {game.playtime_2weeks} мин")
```

Возвращает `None`, если профиль приватный.

---

#### `get_user_achievements(steam_id: str, app_id: int) -> GameAchievements | None`

Получает достижения пользователя в конкретной игре.

```python
achievements = client.get_user_achievements("76561198000000000", 730)
if achievements:
    print(f"Игра: {achievements.game_name}")
    for a in achievements.achievements:
        status = "получено" if a.achieved else "не получено"
        print(f"  {a.name}: {status}")
```

---

#### `get_user_friends(steam_id: str) -> FriendList | None`

Получает список друзей пользователя.

```python
friends = client.get_user_friends("76561198000000000")
if friends:
    print(f"Друзей: {len(friends.friends)}")
    for f in friends.friends:
        print(f"  {f.steam_id} — {f.relationship}, с {f.friend_since}")
```

Возвращает `None`, если профиль приватный.

---

#### `get_user_bans(steam_ids: list[str]) -> list[PlayerBan]`

Получает информацию о банах для одного или нескольких пользователей.

```python
bans = client.get_user_bans(["76561198000000000", "76561198000000001"])
for ban in bans:
    print(f"  {ban.steam_id}: VAC={ban.vac_banned}, бан сообщества={ban.community_banned}")
    print(f"  VAC-банов: {ban.number_of_vac_bans}, игровых банов: {ban.number_of_game_bans}")
```

---

#### `resolve_vanity_url(vanity_url: str) -> str | None`

Преобразует пользовательский URL (vanity URL) в Steam ID.

```python
steam_id = client.resolve_vanity_url("gabelogannewell")
if steam_id:
    print(f"Steam ID: {steam_id}")
```

Возвращает `None`, если vanity URL не найден.

---

#### `get_user_profiles(steam_ids: list[str]) -> list[UserProfile]`

Получает профили нескольких пользователей за один вызов. Автоматически разбивает список на чанки по 100 ID.

```python
profiles = client.get_user_profiles([
    "76561198000000000",
    "76561198000000001",
    "76561198000000002",
])
for profile in profiles:
    print(f"  {profile.username} ({profile.steam_id})")
```

---

#### `get_recently_played(steam_id: str, count: int = 0) -> RecentlyPlayed | None`

Получает список недавно запускавшихся игр.

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `steam_id` | `str` | *обязателен* | 64-битный Steam ID |
| `count` | `int` | `0` | Ограничить количество (0 = все) |

```python
recent = client.get_recently_played("76561198000000000")
if recent:
    print(f"Всего: {recent.total_count}")
    for game in recent.games:
        print(f"  {game.name}: {game.playtime_2weeks} мин за 2 недели")
```

---

#### `get_steam_level(steam_id: str) -> int | None`

Получает уровень Steam пользователя.

```python
level = client.get_steam_level("76561198000000000")
if level is not None:
    print(f"Уровень: {level}")
```

---

#### `get_user_badges(steam_id: str) -> UserBadges | None`

Получает значки пользователя.

```python
badges = client.get_user_badges("76561198000000000")
if badges:
    print(f"Уровень: {badges.player_level}, XP: {badges.player_xp}")
    for badge in badges.badges:
        print(f"  Значок {badge.badge_id}: уровень {badge.level}, XP: {badge.xp}")
```

---

#### `get_wishlist(steam_id: str) -> list[WishlistItem]`

Получает список желаемого пользователя. Использует неофициальный API.

```python
wishlist = client.get_wishlist("76561198000000000")
for item in wishlist:
    print(f"  App {item.app_id}: приоритет {item.priority}, добавлен {item.date_added}")
```

---

#### `get_user_stats(steam_id: str, app_id: int) -> UserStats | None`

Получает статистику пользователя в конкретной игре.

```python
stats = client.get_user_stats("76561198000000000", 730)
if stats:
    print(f"Игра: {stats.game_name}")
    for s in stats.stats:
        print(f"  {s.name}: {s.value}")
```

---

#### `get_app_list(last_appid: int = 0, max_results: int = 10000) -> AppList`

Получает список приложений Steam через IStoreService. Поддерживает cursor-based пагинацию.

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `last_appid` | `int` | `0` | Последний app ID предыдущей страницы (для пагинации) |
| `max_results` | `int` | `10000` | Макс. количество результатов |

```python
app_list = client.get_app_list()
print(f"Получено: {len(app_list.apps)} приложений")
for app in app_list.apps[:5]:
    print(f"  [{app.appid}] {app.name}")

# Пагинация
if app_list.have_more_results:
    next_page = client.get_app_list(last_appid=app_list.last_appid)
```

---

## AsyncSteamAuthClient

Асинхронная версия. Те же методы, что у `SteamAuthClient`, все `async`.

```python
from steam_fetcher import AsyncSteamAuthClient

async with AsyncSteamAuthClient(api_key="YOUR_KEY") as client:
    profile = await client.get_user_profile("76561198000000000")
```

### Конструктор

```python
AsyncSteamAuthClient(
    api_key: SecretStr | str,
    requests_per_minute: int = 200,
    time_period: float = 60.0,
    retries: int = 3,
    timeout: float = 10.0,
    burst_size: int = 10,
)
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `api_key` | `SecretStr \| str` | *обязателен* | Steam Web API key |
| `requests_per_minute` | `int` | `200` | Макс. запросов за период |
| `time_period` | `float` | `60.0` | Окно rate limiting (секунды) |
| `retries` | `int` | `3` | Повторные попытки |
| `timeout` | `float` | `10.0` | Таймаут запроса в секундах |
| `burst_size` | `int` | `10` | Макс. размер burst для rate limiter |

### Методы

Все методы `AsyncSteamClient` плюс:

- `await get_user_profile(steam_id)` → `UserProfile | None`
- `await get_user_library(steam_id)` → `UserLibrary | None`
- `await get_user_achievements(steam_id, app_id)` → `GameAchievements | None`
- `await get_user_friends(steam_id)` → `FriendList | None`
- `await get_user_bans(steam_ids)` → `list[PlayerBan]`
- `await resolve_vanity_url(vanity_url)` → `str | None`
- `await get_user_profiles(steam_ids)` → `list[UserProfile]`
- `await get_recently_played(steam_id, count)` → `RecentlyPlayed | None`
- `await get_steam_level(steam_id)` → `int | None`
- `await get_user_badges(steam_id)` → `UserBadges | None`
- `await get_wishlist(steam_id)` → `list[WishlistItem]`
- `await get_user_stats(steam_id, app_id)` → `UserStats | None`
- `await get_app_list(last_appid, max_results)` → `AppList`

### Зависимости

```bash
pip install steam-fetcher[async]
```
