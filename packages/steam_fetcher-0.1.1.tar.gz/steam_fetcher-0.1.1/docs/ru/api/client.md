# SteamClient / AsyncSteamClient

Публичные клиенты Steam Store API. API-ключ не требуется.

## SteamClient

Синхронный клиент. Используется как контекстный менеджер.

```python
from steam_fetcher import SteamClient

with SteamClient(retries=3, timeout=10.0) as client:
    game = client.get_game(730)
```

### Конструктор

```python
SteamClient(
    requests_per_minute: int = 200,
    retries: int = 3,
    timeout: float = 10.0,
)
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `requests_per_minute` | `int` | `200` | Макс. запросов в минуту (rate limiting) |
| `retries` | `int` | `3` | Количество повторных попыток с экспоненциальной задержкой |
| `timeout` | `float` | `10.0` | Таймаут запроса в секундах |

### Методы

#### `get_game(app_id: int, country: str = "US", language: str = "en") -> GameDetails | None`

Получает полную информацию об игре из Steam Store API.

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `app_id` | `int` | *обязателен* | ID приложения в Steam |
| `country` | `str` | `"US"` | Код страны для цен (ISO 3166-1 alpha-2) |
| `language` | `str` | `"en"` | Язык описания |

```python
game = client.get_game(730, country="RU", language="russian")
if game:
    print(game.name, game.type, game.is_free)
    print(game.developers, game.publishers)
    print(game.price)         # Price | None
    print(game.platforms)     # Platforms | None
    print(game.metacritic)    # Metacritic | None
    print(game.release_date)  # ReleaseDate | None
```

Возвращает `None`, если app ID не существует или API вернул ошибку.

---

#### `get_player_count(app_id: int) -> PlayerCount | None`

Получает текущее количество онлайн-игроков.

```python
players = client.get_player_count(730)
if players:
    print(players.player_count)
```

---

#### `get_reviews(app_id: int, language: str = "all", review_filter: str = "all", num_per_page: int = 20, cursor: str = "*") -> ReviewSummary | None`

Получает сводку и список отзывов об игре.

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `app_id` | `int` | *обязателен* | ID приложения в Steam |
| `language` | `str` | `"all"` | Язык отзывов (`"all"`, `"russian"`, `"english"` и т.д.) |
| `review_filter` | `str` | `"all"` | Фильтр: `"all"`, `"positive"`, `"negative"` |
| `num_per_page` | `int` | `20` | Количество отзывов на страницу |
| `cursor` | `str` | `"*"` | Курсор пагинации |

```python
reviews = client.get_reviews(730, language="russian", num_per_page=5)
if reviews:
    print(f"{reviews.score_description}: {reviews.positive}/{reviews.total}")
    print(f"Оценка: {reviews.score}/10")
    for r in reviews.reviews:
        print(f"  {r.author_steam_id}: voted_up={r.voted_up}")
        print(f"  {r.review[:100]}")
    # Пагинация
    next_page = client.get_reviews(730, cursor=reviews.cursor)
```

---

#### `get_steamspy_details(app_id: int) -> SteamSpyDetails | None`

Получает статистику игры из SteamSpy API.

```python
spy = client.get_steamspy_details(730)
if spy:
    print(f"Владельцев: {spy.owners}")
    print(f"П��к CCU: {spy.peak_ccu}")
    print(f"Среднее время игры: {spy.average_forever} мин")
    print(f"Теги: {spy.tags}")
```

---

#### `get_game_schema(app_id: int) -> GameSchema | None`

Получает определения достижений и статистик игры.

```python
schema = client.get_game_schema(730)
if schema:
    print(f"Игра: {schema.game_name}")
    for a in schema.achievements:
        print(f"  {a.display_name}: {a.description}")
    for s in schema.stats:
        print(f"  Стат: {s.display_name}")
```

---

#### `get_global_achievement_percentages(app_id: int) -> GlobalAchievements | None`

Получает глобальный процент получения достижений.

```python
global_achs = client.get_global_achievement_percentages(730)
if global_achs:
    for a in global_achs.achievements:
        print(f"  {a.name}: {a.percent:.1f}%")
```

---

#### `get_news(app_id: int, count: int = 20, max_length: int = 0) -> AppNews | None`

Получает новости для приложения.

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `app_id` | `int` | *обязателен* | ID приложения в Steam |
| `count` | `int` | `20` | Количество новостей |
| `max_length` | `int` | `0` | Макс. длина текста (0 = без ограничения) |

```python
news = client.get_news(730, count=5)
if news:
    for item in news.items:
        print(f"  {item.title} — {item.feed_name}")
        print(f"  {item.url}")
```

---

#### `search(query: str, country: str = "US", language: str = "en") -> SearchResult`

Поиск по магазину Steam. Всегда возвращает `SearchResult` (возможно, с нулём результатов).

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `query` | `str` | *обязателен* | Поисковый запрос |
| `country` | `str` | `"US"` | Код страны для цен |
| `language` | `str` | `"en"` | Язык результатов |

```python
results = client.search("portal", country="RU", language="russian")
print(f"Найдено: {results.total}")
for entry in results.entries:
    print(f"  [{entry.app_id}] {entry.name} — {entry.price}")
    print(f"  Платформы: {entry.platforms}")
```

---

## AsyncSteamClient

Асинхронная версия со встроенным rate limiting. Те же методы, что и у `SteamClient`, но с `async`.

```python
from steam_fetcher import AsyncSteamClient

async with AsyncSteamClient() as client:
    game = await client.get_game(730)
```

### Конструктор

```python
AsyncSteamClient(
    requests_per_minute: int = 200,
    time_period: float = 60.0,
    retries: int = 3,
    timeout: float = 10.0,
    burst_size: int = 10,
)
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `requests_per_minute` | `int` | `200` | Макс. запросов за период |
| `time_period` | `float` | `60.0` | Окно rate limiting (секунды) |
| `retries` | `int` | `3` | Повторные попытки с экспоненциальной задержкой |
| `timeout` | `float` | `10.0` | Таймаут запроса в секундах |
| `burst_size` | `int` | `10` | Макс. размер burst для rate limiter |

### Методы

Те же, что у `SteamClient`, все `async`:

- `await get_game(app_id, country, language)` → `GameDetails | None`
- `await get_player_count(app_id)` → `PlayerCount | None`
- `await get_reviews(app_id, language, review_filter, num_per_page, cursor)` → `ReviewSummary | None`
- `await get_steamspy_details(app_id)` → `SteamSpyDetails | None`
- `await get_game_schema(app_id)` → `GameSchema | None`
- `await get_global_achievement_percentages(app_id)` → `GlobalAchievements | None`
- `await get_news(app_id, count, max_length)` → `AppNews | None`
- `await search(query, country, language)` → `SearchResult`

### Параллельные запросы

```python
import asyncio

async with AsyncSteamClient() as client:
    games = await asyncio.gather(
        client.get_game(730),
        client.get_game(570),
        client.get_game(440),
    )
```

Rate limiting применяется автоматически к каждому запросу.

### Зависимости

```bash
pip install steam-fetcher[async]
```
