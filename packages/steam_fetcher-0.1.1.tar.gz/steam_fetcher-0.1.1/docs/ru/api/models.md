# Модели

Все модели — подклассы `BaseModel` из Pydantic v2. Импорт из `steam_fetcher` или `steam_fetcher.models`:

```python
from steam_fetcher import GameDetails, UserProfile, PlayerCount
# или
from steam_fetcher.models import GameDetails, UserProfile, PlayerCount
```

---

## Модели игр

### GameDetails

Полная информация об игре из Steam Store API. Возвращается методом `get_game()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `name` | `str` | Название игры |
| `type` | `AppType` | Тип приложения (`game`, `dlc`, `demo` и т.д.) |
| `is_free` | `bool` | Бесплатная ли игра |
| `short_description` | `str \| None` | Краткое описание |
| `about_the_game` | `str \| None` | Раздел «Об игре» (HTML) |
| `detailed_description` | `str \| None` | Полное описание (HTML) |
| `supported_languages` | `list[str]` | Поддерживаемые языки |
| `header_image` | `HttpUrl \| None` | URL обложки |
| `website` | `HttpUrl \| None` | URL официального сайта |
| `developers` | `list[str]` | Разработчики |
| `publishers` | `list[str]` | Издатели |
| `price` | `Price \| None` | Цена (`None` если бесплатная) |
| `platforms` | `Platforms \| None` | Поддерживаемые платформы |
| `metacritic` | `Metacritic \| None` | Оценка Metacritic |
| `categories` | `list[Category]` | Категории Steam |
| `genres` | `list[Genre]` | Жанры |
| `screenshots` | `list[Screenshot]` | URL скриншотов |
| `movies` | `list[Movie]` | URL трейлеров |
| `release_date` | `ReleaseDate \| None` | Дата выхода |
| `dlc_count` | `int` | Количество DLC |
| `achievements` | `int` | Общее количество достижений |
| `recommendations` | `int` | Количество рекомендаций |
| `required_age` | `int` | Минимальный возраст |

### AppType

`StrEnum` типов приложений Steam:

```python
from steam_fetcher import AppType

AppType.GAME        # "game"
AppType.DLC         # "dlc"
AppType.DEMO        # "demo"
AppType.MOD         # "mod"
AppType.VIDEO       # "video"
AppType.SERIES      # "series"
AppType.EPISODE     # "episode"
AppType.BUNDLE      # "bundle"
AppType.ADVERTISING # "advertising"
```

### Price

| Поле | Тип | Описание |
|------|-----|----------|
| `currency` | `str` | Код валюты (например, `"USD"`) |
| `initial` | `float` | Начальная цена в центах |
| `final` | `float` | Цена после скидки (центы) |
| `discount_percent` | `int` | Процент скидки (0–100) |
| `initial_formatted` | `str` | Форматированная начальная цена |
| `final_formatted` | `str` | Форматированная конечная цена |

### Platforms

| Поле | Тип | По умолчанию | Описание |
|------|-----|-------------|----------|
| `windows` | `bool` | `False` | Поддержка Windows |
| `mac` | `bool` | `False` | Поддержка macOS |
| `linux` | `bool` | `False` | Поддержка Linux |

### Metacritic

| Поле | Тип | Описание |
|------|-----|----------|
| `score` | `int` | Оценка Metacritic (0–100) |
| `url` | `HttpUrl` | URL рецензии на Metacritic |

### Category / Genre

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | `int` | ID категории/жанра |
| `description` | `str` | Название категории/жанра |

### Screenshot

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | `int` | ID скриншота |
| `path_thumbnail` | `HttpUrl` | URL миниатюры |
| `path_full` | `HttpUrl` | URL полного разрешения |

### Movie

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | `int` | ID трейлера |
| `name` | `str` | Название трейлера |
| `thumbnail` | `HttpUrl` | URL миниатюры |
| `webm_max` | `HttpUrl \| None` | URL WebM макс. качества |
| `mp4_max` | `HttpUrl \| None` | URL MP4 макс. качества |

### ReleaseDate

| Поле | Тип | Описание |
|------|-----|----------|
| `coming_soon` | `bool` | Ещё не вышла |
| `date` | `str \| None` | Строка даты выхода (например, `"Sep 27, 2023"`) |

---

## Модели игроков

### PlayerCount

Возвращается методом `get_player_count()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `player_count` | `int` | Текущее количество онлайн-игроков |

### ReviewSummary

Возвращается методом `get_reviews()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `total` | `int` | Всего отзывов |
| `positive` | `int` | Положительных |
| `negative` | `int` | Отрицательных |
| `score` | `int` | Оценка (0–10) |
| `score_description` | `str` | Например, `"Very Positive"` |
| `review_type` | `str` | Фильтр типа отзывов |
| `purchase_type` | `str` | Фильтр типа покупки |
| `cursor` | `str` | Курсор для пагинации |
| `reviews` | `list[Review]` | Список отзывов |

### Review

Отдельный отзыв пользователя.

| Поле | Тип | Описание |
|------|-----|----------|
| `recommendation_id` | `str` | ID рекомендации |
| `author_steam_id` | `str` | Steam ID автора |
| `language` | `str` | Язык отзыва |
| `review` | `str` | Текст отзыва |
| `timestamp_created` | `int` | Время создания (Unix timestamp) |
| `voted_up` | `bool` | Положительный ли отзыв |
| `votes_up` | `int` | Количество голосов «полезно» |
| `votes_funny` | `int` | Количество голосов «смешно» |
| `weighted_vote_score` | `float` | Взвешенная оценка полезности |
| `comment_count` | `int` | Количество комментариев |
| `steam_purchase` | `bool` | Куплено ли через Steam |
| `received_for_free` | `bool` | Получено ли бесплатно |

### GlobalAchievement

Глобальный процент получения одного достижения.

| Поле | Тип | Описание |
|------|-----|----------|
| `name` | `str` | API-имя достижения |
| `percent` | `float` | Процент игроков, получивших достижение |

### GlobalAchievements

Возвращается методом `get_global_achievement_percentages()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `achievements` | `list[GlobalAchievement]` | Список достижений с процентами |

### AchievementSchema

Определение достижения из схемы игры.

| Поле | Тип | Описание |
|------|-----|----------|
| `name` | `str` | API-имя достижения |
| `display_name` | `str` | Отображаемое название |
| `description` | `str \| None` | Описание достижения |
| `icon` | `str \| None` | URL иконки (получено) |
| `icon_gray` | `str \| None` | URL иконки (не получено) |

### StatSchema

Определение статистики из схемы игры.

| Поле | Тип | Описание |
|------|-----|----------|
| `name` | `str` | API-имя статистики |
| `display_name` | `str` | Отображаемое название |

### GameSchema

Возвращается методом `get_game_schema()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `game_name` | `str` | Название игры |
| `achievements` | `list[AchievementSchema]` | Определения достижений |
| `stats` | `list[StatSchema]` | Определения статистик |

### StatEntry

Значение отдельной статистики пользователя.

| Поле | Тип | Описание |
|------|-----|----------|
| `name` | `str` | API-имя статистики |
| `value` | `int \| float` | Значение |

### UserStats

Возвращается методом `get_user_stats()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `app_id` | `int` | ID приложения в Steam |
| `game_name` | `str` | Название игры |
| `stats` | `list[StatEntry]` | Список статистик пользователя |

### SteamSpyDetails

Возвращается методом `get_steamspy_details()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `name` | `str` | Название игры |
| `developer` | `str` | Разработчик |
| `publisher` | `str` | Издатель |
| `score_rank` | `str` | Ранг оценки |
| `positive` | `int` | Положительных отзывов |
| `negative` | `int` | Отрицательных отзывов |
| `userscore` | `int` | Пользовательская оценка |
| `owners` | `str` | Диапазон владельцев (напр. `"50,000,000 .. 100,000,000"`) |
| `average_forever` | `int` | Среднее время игры за всё время (минуты) |
| `average_2weeks` | `int` | Среднее время игры за 2 недели (минуты) |
| `median_forever` | `int` | Медианное время игры за всё время (минуты) |
| `median_2weeks` | `int` | Медианное время игры за 2 недели (минуты) |
| `peak_ccu` | `int` | Пиковое количество одновременных игроков |
| `price` | `str` | Цена в центах |
| `discount` | `int` | Текущая скидка (0–100) |
| `tags` | `dict[str, int]` | Теги с количеством голосов |

### AppListEntry

Запись в списке приложений Steam (IStoreService).

| Поле | Тип | Описание |
|------|-----|----------|
| `appid` | `int` | ID приложения в Steam |
| `name` | `str` | Название приложения |
| `last_modified` | `int` | Время последнего изменения (Unix timestamp) |
| `price_change_number` | `int` | Номер изменения цены |

### AppList

Возвращается методом `get_app_list()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `apps` | `list[AppListEntry]` | Список приложений |
| `have_more_results` | `bool` | Есть ли ещё результаты |
| `last_appid` | `int` | Последний app ID (для пагинации) |

---

## Модели поиска

### SearchResult

Возвращается методом `search()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `term` | `str` | Поисковый запрос |
| `total` | `int` | Количество результатов |
| `entries` | `list[SearchEntry]` | Результаты поиска |

### SearchEntry

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `name` | `str` | Название игры |
| `icon` | `str \| None` | URL миниатюры |
| `price` | `str \| None` | Форматированная цена |
| `platforms` | `Platforms \| None` | Поддерживаемые платформы |

---

## Модели пользователей

### UserProfile

Возвращается методом `get_user_profile()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `username` | `str` | Отображаемое имя |
| `real_name` | `str \| None` | Настоящее имя (если публичное) |
| `avatar` | `Avatar` | URL аватаров |
| `profile_url` | `HttpUrl` | URL профиля в Steam Community |
| `country_code` | `str \| None` | Код страны ISO 3166-1 alpha-2 |
| `state_code` | `str \| None` | Код региона/штата |
| `time_created` | `int \| None` | Дата создания аккаунта (Unix timestamp) |
| `last_logoff` | `int \| None` | Последний выход (Unix timestamp) |
| `is_public` | `bool` | Публичный ли профиль |
| `persona_state` | `int \| None` | Текущий статус (0=Offline, 1=Online и т.д.) |
| `game_id` | `str \| None` | ID текущей игры (если в игре) |
| `game_extra_info` | `str \| None` | Название текущей игры (если в игре) |

### Avatar

| Поле | Тип | Описание |
|------|-----|----------|
| `small` | `HttpUrl` | Аватар 32x32 |
| `medium` | `HttpUrl` | Аватар 64x64 |
| `full` | `HttpUrl` | Аватар 184x184 |

### UserLibrary

Возвращается методом `get_user_library()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `game_count` | `int` | Всего игр |
| `games` | `list[LibraryGame]` | Игры в библиотеке |

### LibraryGame

| Поле | Тип | По умолчанию | Описание |
|------|-----|-------------|----------|
| `app_id` | `int` | | ID приложения в Steam |
| `name` | `str \| None` | `None` | Название игры |
| `playtime_forever` | `int` | `0` | Общее время игры (минуты) |
| `playtime_2weeks` | `int \| None` | `None` | Время игры за 2 недели (минуты) |
| `img_icon_url` | `str \| None` | `None` | Хеш иконки игры |
| `icon_url` | `str \| None` | *computed* | Полный URL иконки (вычисляется из `app_id` и `img_icon_url`) |
| `last_played` | `int \| None` | `None` | Последняя игровая сессия (Unix timestamp) |

### GameAchievements

Возвращается методом `get_user_achievements()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `game_name` | `str` | Название игры |
| `achievements` | `list[Achievement]` | Список достижений |

### Achievement

| Поле | Тип | Описание |
|------|-----|----------|
| `api_name` | `str` | API-имя достижения |
| `achieved` | `bool` | Получено ли |
| `unlock_time` | `int \| None` | Время получения (Unix timestamp) |
| `name` | `str \| None` | Отображаемое название |
| `description` | `str \| None` | Описание достижения |

### Friend

Запись о друге пользователя.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID друга |
| `relationship` | `str` | Тип отношений (например, `"friend"`) |
| `friend_since` | `int` | Дата добавления в друзья (Unix timestamp) |

### FriendList

Возвращается методом `get_user_friends()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID владельца |
| `friends` | `list[Friend]` | Список друзей |

### PlayerBan

Информация о банах пользователя. Возвращается методом `get_user_bans()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `community_banned` | `bool` | Бан в сообществе |
| `vac_banned` | `bool` | Наличие VAC-бана |
| `number_of_vac_bans` | `int` | Количество VAC-банов |
| `days_since_last_ban` | `int` | Дней с последнего бана |
| `number_of_game_bans` | `int` | Количество игровых банов |
| `economy_ban` | `str` | Статус бана в торговле (например, `"none"`) |

### RecentGame

Недавно запускавшаяся игра.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `name` | `str` | Название игры |
| `playtime_2weeks` | `int` | Время игры за 2 недели (минуты) |
| `playtime_forever` | `int` | Общее время игры (минуты) |
| `img_icon_url` | `str \| None` | URL иконки игры |

### RecentlyPlayed

Возвращается методом `get_recently_played()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `total_count` | `int` | Общее количество недавних игр |
| `games` | `list[RecentGame]` | Список недавних игр |

### Badge

Отдельный значок пользователя.

| Поле | Тип | Описание |
|------|-----|----------|
| `badge_id` | `int` | ID значка |
| `level` | `int` | Уровень значка |
| `completion_time` | `int` | Время получения (Unix timestamp) |
| `xp` | `int` | Количество XP за значок |
| `scarcity` | `int` | Количество владельцев значка |

### UserBadges

Возвращается методом `get_user_badges()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `steam_id` | `str` | 64-битный Steam ID |
| `badges` | `list[Badge]` | Список значков |
| `player_xp` | `int` | Общий XP игрока |
| `player_level` | `int` | Уровень Steam |

### WishlistItem

Элемент списка желаемого. Возвращается методом `get_wishlist()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `priority` | `int` | Приоритет в списке желаемого |
| `date_added` | `int` | Дата добавления (Unix timestamp) |

---

## Модели новостей

### NewsItem

Отдельная новость.

| Поле | Тип | Описание |
|------|-----|----------|
| `gid` | `str` | Уникальный ID новости |
| `title` | `str` | Заголовок |
| `url` | `str` | URL новости |
| `author` | `str` | Автор |
| `contents` | `str` | Содержимое (HTML или BBCode) |
| `date` | `int` | Дата публикации (Unix timestamp) |
| `feed_name` | `str` | Название фида (например, `"steam_community_announcements"`) |

### AppNews

Возвращается методом `get_news()`.

| Поле | Тип | Описание |
|------|-----|----------|
| `app_id` | `int` | ID приложения в Steam |
| `items` | `list[NewsItem]` | Список новостей |
