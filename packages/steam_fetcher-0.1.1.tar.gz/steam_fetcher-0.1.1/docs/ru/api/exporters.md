# Экспортеры

Экспортеры сохраняют списки Pydantic-моделей в файлы или базы данных. Все экспортеры реализуют единый интерфейс:

```python
exporter.export(data: list[BaseModel], destination: str) -> None
```

- `data` — список Pydantic-моделей (не должен быть пустым)
- `destination` — путь к файлу или имя таблицы (для SQL)

Импорт из `steam_fetcher.exporters`:

```python
from steam_fetcher.exporters import JsonExporter, CsvExporter, ParquetExporter, SqlExporter
```

---

## JsonExporter

Экспорт в JSON-массив. Дополнительные зависимости не нужны.

```python
from steam_fetcher.exporters import JsonExporter

exporter = JsonExporter(indent=4, ensure_ascii=False)
exporter.export([game], "games.json")
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `indent` | `int` | `4` | Уровень отступа JSON |
| `ensure_ascii` | `bool` | `False` | Экранировать не-ASCII символы |

Пример вывода:

```json
[
    {
        "app_id": 730,
        "name": "Counter-Strike 2",
        "type": "game",
        "is_free": true
    }
]
```

---

## CsvExporter

Экспорт в CSV. Вложенные поля (списки, словари) сглаживаются в строки. Дополнительные зависимости не нужны.

```python
from steam_fetcher.exporters import CsvExporter

exporter = CsvExporter(delimiter=",", flatten=True)
exporter.export([game], "games.csv")
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `delimiter` | `str` | `","` | Разделитель CSV |
| `flatten` | `bool` | `True` | Сглаживать вложенные поля |

Правила сглаживания:

- Списки → через `|`: `["Action", "FPS"]` → `"Action|FPS"`
- Словари → строковое представление: `{"id": 1}` → `"{'id': 1}"`
- `None` → пустая строка

---

## ParquetExporter

Экспорт в Apache Parquet через `polars`.

```bash
pip install steam-fetcher[parquet]
```

```python
from steam_fetcher.exporters import ParquetExporter

exporter = ParquetExporter(compression="zstd")
exporter.export([game], "games.parquet")
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `compression` | `ParquetCompression` | `"zstd"` | Алгоритм сжатия |

Поддерживаемые алгоритмы: `"lz4"`, `"uncompressed"`, `"snappy"`, `"gzip"`, `"brotli"`, `"zstd"`.

---

## SqlExporter

Экспорт в SQL-базу данных через SQLAlchemy. Таблица создаётся автоматически.

```bash
pip install steam-fetcher[sql]
```

```python
from steam_fetcher.exporters import SqlExporter

exporter = SqlExporter(
    url="sqlite:///steam.db",
    if_exists="append",
    chunk_size=1000,
)
exporter.export([game], "games")  # destination = имя таблицы
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `url` | `str` | *обязателен* | URL подключения SQLAlchemy |
| `if_exists` | `str` | `"append"` | `"fail"`, `"replace"` или `"append"` |
| `chunk_size` | `int` | `1000` | Записей за один INSERT |

Примеры URL подключения:

```
sqlite:///games.db
postgresql://user:pass@localhost/steam
mysql://user:pass@localhost/steam
```

Вложенные поля (списки, словари) сохраняются как строковые представления. Типы колонок определяются по первой записи (`int` → `Integer`, `float` → `Float`, `bool` → `Boolean`, всё остальное → `Text`).

---

## Обработка ошибок

Все экспортеры выбрасывают:

- `ValueError("Data is empty")` — если передан пустой список
- `ExportError` — если операция экспорта завершилась неудачей (оборачивает исходное исключение)

```python
from steam_fetcher.exporters import ExportError

try:
    exporter.export(data, "output.json")
except ValueError:
    print("Нет данных для экспорта")
except ExportError as e:
    print(f"Ошибка экспорта: {e}")
```
