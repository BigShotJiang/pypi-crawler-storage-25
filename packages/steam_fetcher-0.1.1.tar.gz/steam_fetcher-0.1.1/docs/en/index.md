# steam-fetcher

Typed Python client for the Steam Store API, Steam Web API, and SteamSpy API.

## Features

- **Sync & async clients** with identical API
- **Pydantic v2 models** for all responses
- **Rate limiting** — sync (threading) and async (aiolimiter)
- **Retry logic** with exponential backoff (only on 5xx errors)
- **Exporters** — JSON, CSV, Parquet, SQL
- **CLI** via typer
- **API key safety** via `SecretStr`

## Quick example

```python
from steam_fetcher import SteamClient

with SteamClient() as client:
    game = client.get_game(730)
    print(game.name)  # Counter-Strike 2

    players = client.get_player_count(730)
    print(players.player_count)  # 684339

    results = client.search("half-life")
    for entry in results.entries:
        print(f"{entry.name} — {entry.price}")

    reviews = client.get_reviews(730, num_per_page=5)
    print(f"{reviews.score_description}: {reviews.positive}/{reviews.total}")

    news = client.get_news(730, count=3)
    for item in news.items:
        print(item.title)
```

## Async example

```python
import asyncio
from steam_fetcher import AsyncSteamClient

async def main():
    async with AsyncSteamClient() as client:
        games = await asyncio.gather(
            client.get_game(730),
            client.get_game(570),
            client.get_game(440),
        )
        for g in games:
            if g:
                print(g.name)

asyncio.run(main())
```

## Authenticated example

```python
from steam_fetcher import SteamAuthClient

with SteamAuthClient(api_key="YOUR_KEY") as client:
    profile = client.get_user_profile("76561198000000000")
    friends = client.get_user_friends("76561198000000000")
    level = client.get_steam_level("76561198000000000")
```

## Installation

```bash
pip install steam-fetcher
```

Optional extras:

```bash
pip install steam-fetcher[async]     # async client
pip install steam-fetcher[parquet]   # Parquet export (polars)
pip install steam-fetcher[sql]       # SQL export (SQLAlchemy)
pip install steam-fetcher[cli]       # CLI (typer)
pip install steam-fetcher[all]       # everything
```

## What's next

- [Getting Started](getting-started.md) — installation, setup, first steps
- [SteamClient](api/client.md) — public client (7 methods)
- [SteamAuthClient](api/auth_client.md) — authenticated client (14 additional methods)
- [Models](api/models.md) — all Pydantic models
- [Exporters](api/exporters.md) — saving data to files and databases
