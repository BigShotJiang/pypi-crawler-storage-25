# SteamAuthClient / AsyncSteamAuthClient

Steam Web API clients. Require a [Steam Web API key](https://steamcommunity.com/dev/apikey).

These clients **extend** the public clients, so all methods from [`SteamClient`](client.md) / [`AsyncSteamClient`](client.md) are available as well.

## SteamAuthClient

Synchronous authenticated client.

```python
from steam_fetcher import SteamAuthClient

with SteamAuthClient(api_key="YOUR_KEY") as client:
    profile = client.get_user_profile("76561198000000000")
```

### Constructor

```python
SteamAuthClient(
    api_key: SecretStr | str,
    requests_per_minute: int = 200,
    retries: int = 3,
    timeout: float = 10.0,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `api_key` | `SecretStr \| str` | *required* | Steam Web API key |
| `requests_per_minute` | `int` | `200` | Max requests per minute for rate limiting |
| `retries` | `int` | `3` | Retry attempts with exponential backoff |
| `timeout` | `float` | `10.0` | Request timeout in seconds |

The API key is wrapped in `pydantic.SecretStr` — it won't appear in `repr()`, logs, or stack traces.

### Methods

All methods from `SteamClient` plus:

#### `get_user_profile(steam_id: str) -> UserProfile | None`

Fetches a user's public profile.

```python
profile = client.get_user_profile("76561198000000000")
if profile:
    print(profile.username)
    print(profile.avatar.full)       # full-size avatar URL
    print(profile.country_code)      # "US", "RU", etc.
    print(profile.is_public)         # True if profile is public
    print(profile.time_created)      # Unix timestamp
    print(profile.last_logoff)       # Unix timestamp
```

---

#### `get_user_library(steam_id: str) -> UserLibrary | None`

Fetches a user's game library.

```python
library = client.get_user_library("76561198000000000")
if library:
    print(f"Games: {library.game_count}")
    for game in library.games:
        hours = game.playtime_forever / 60
        print(f"  {game.name}: {hours:.0f}h played")
        if game.playtime_2weeks:
            print(f"    Last 2 weeks: {game.playtime_2weeks} min")
```

Returns `None` if the profile is private.

---

#### `get_user_achievements(steam_id: str, app_id: int) -> GameAchievements | None`

Fetches a user's achievements for a specific game.

```python
achievements = client.get_user_achievements("76561198000000000", 730)
if achievements:
    print(f"Game: {achievements.game_name}")
    for a in achievements.achievements:
        status = "unlocked" if a.achieved else "locked"
        print(f"  {a.name}: {status}")
```

---

#### `get_user_friends(steam_id: str) -> FriendList | None`

Fetches a user's friend list.

```python
friends = client.get_user_friends("76561198000000000")
if friends:
    print(f"Friends: {len(friends.friends)}")
    for f in friends.friends:
        print(f"  {f.steam_id} — since {f.friend_since}")
```

---

#### `get_user_bans(steam_ids: list[str]) -> list[PlayerBan]`

Fetches ban information for one or more users.

```python
bans = client.get_user_bans(["76561198000000000"])
for ban in bans:
    print(f"  {ban.steam_id}: VAC={ban.vac_banned}, {ban.number_of_vac_bans} bans")
```

---

#### `resolve_vanity_url(vanity_url: str) -> str | None`

Resolves a Steam vanity URL to a 64-bit Steam ID.

```python
steam_id = client.resolve_vanity_url("gabelogannewell")
if steam_id:
    print(f"Steam ID: {steam_id}")
```

Returns `None` if the vanity URL does not resolve.

---

#### `get_user_profiles(steam_ids: list[str]) -> list[UserProfile]`

Fetches profiles for multiple users in a single call. Automatically chunks requests into batches of 100.

```python
profiles = client.get_user_profiles(["76561198000000000", "76561198000000001"])
for profile in profiles:
    print(f"  {profile.username} ({profile.steam_id})")
```

---

#### `get_recently_played(steam_id: str, count: int = 0) -> RecentlyPlayed | None`

Fetches recently played games for a user. Set `count=0` to return all recent games.

```python
recent = client.get_recently_played("76561198000000000", count=5)
if recent:
    print(f"Total: {recent.total_count}")
    for game in recent.games:
        print(f"  {game.name}: {game.playtime_2weeks} min (2 weeks)")
```

---

#### `get_steam_level(steam_id: str) -> int | None`

Fetches a user's Steam level.

```python
level = client.get_steam_level("76561198000000000")
if level is not None:
    print(f"Steam level: {level}")
```

---

#### `get_user_badges(steam_id: str) -> UserBadges | None`

Fetches a user's badges and XP information.

```python
badges = client.get_user_badges("76561198000000000")
if badges:
    print(f"Level: {badges.player_level}, XP: {badges.player_xp}")
    for badge in badges.badges:
        print(f"  Badge {badge.badge_id}: level {badge.level}")
```

---

#### `get_wishlist(steam_id: str) -> list[WishlistItem]`

Fetches a user's wishlist. Uses the unofficial Steam Store wishlist API.

```python
wishlist = client.get_wishlist("76561198000000000")
for item in wishlist:
    print(f"  [{item.app_id}] priority={item.priority}, added={item.date_added}")
```

---

#### `get_user_stats(steam_id: str, app_id: int) -> UserStats | None`

Fetches a user's stats for a specific game.

```python
stats = client.get_user_stats("76561198000000000", 730)
if stats:
    print(f"Game: {stats.game_name}")
    for s in stats.stats:
        print(f"  {s.name}: {s.value}")
```

---

#### `get_app_list(last_appid: int = 0, max_results: int = 10000) -> AppList`

Fetches the list of all Steam apps via the IStoreService. Supports cursor-based pagination.

```python
app_list = client.get_app_list()
print(f"Apps: {len(app_list.apps)}, more={app_list.have_more_results}")
for app in app_list.apps[:5]:
    print(f"  [{app.appid}] {app.name}")

# Paginate
if app_list.have_more_results:
    next_page = client.get_app_list(last_appid=app_list.last_appid)
```

---

## AsyncSteamAuthClient

Asynchronous version. Same methods as `SteamAuthClient`, all `async`.

```python
from steam_fetcher import AsyncSteamAuthClient

async with AsyncSteamAuthClient(api_key="YOUR_KEY") as client:
    profile = await client.get_user_profile("76561198000000000")
```

### Constructor

```python
AsyncSteamAuthClient(
    api_key: SecretStr | str,
    requests_per_minute: int = 200,
    time_period: float = 60.0,
    retries: int = 3,
    timeout: float = 10.0,
    burst_size: int = 10,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `api_key` | `SecretStr \| str` | *required* | Steam Web API key |
| `requests_per_minute` | `int` | `200` | Max requests per time period |
| `time_period` | `float` | `60.0` | Rate limiting window (seconds) |
| `retries` | `int` | `3` | Retry attempts |
| `timeout` | `float` | `10.0` | Request timeout in seconds |
| `burst_size` | `int` | `10` | Max burst size for rate limiter |

### Methods

All methods from `AsyncSteamClient` plus:

- `await get_user_profile(steam_id)` → `UserProfile | None`
- `await get_user_profiles(steam_ids)` → `list[UserProfile]`
- `await get_user_library(steam_id)` → `UserLibrary | None`
- `await get_user_achievements(steam_id, app_id)` → `GameAchievements | None`
- `await get_user_friends(steam_id)` → `FriendList | None`
- `await get_user_bans(steam_ids)` → `list[PlayerBan]`
- `await resolve_vanity_url(vanity_url)` → `str | None`
- `await get_recently_played(steam_id, count=0)` → `RecentlyPlayed | None`
- `await get_steam_level(steam_id)` → `int | None`
- `await get_user_badges(steam_id)` → `UserBadges | None`
- `await get_wishlist(steam_id)` → `list[WishlistItem]`
- `await get_user_stats(steam_id, app_id)` → `UserStats | None`
- `await get_app_list(last_appid=0, max_results=10000)` → `AppList`

### Requires

```bash
pip install steam-fetcher[async]
```
