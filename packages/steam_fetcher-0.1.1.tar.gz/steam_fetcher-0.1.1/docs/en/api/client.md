# SteamClient / AsyncSteamClient

Public Steam Store API clients. No API key required.

## SteamClient

Synchronous client. Must be used as a context manager.

```python
from steam_fetcher import SteamClient

with SteamClient(retries=3, timeout=10.0) as client:
    game = client.get_game(730)
```

### Constructor

```python
SteamClient(
    requests_per_minute: int = 200,
    retries: int = 3,
    timeout: float = 10.0,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `requests_per_minute` | `int` | `200` | Max requests per minute for rate limiting |
| `retries` | `int` | `3` | Number of retry attempts with exponential backoff |
| `timeout` | `float` | `10.0` | Request timeout in seconds |

### Methods

#### `get_game(app_id: int, country: str = "US", language: str = "en") -> GameDetails | None`

Fetches full game details from the Steam Store API.

```python
game = client.get_game(730)
if game:
    print(game.name, game.type, game.is_free)
    print(game.developers, game.publishers)
    print(game.price)         # Price | None
    print(game.platforms)     # Platforms | None
    print(game.metacritic)    # Metacritic | None
    print(game.release_date)  # ReleaseDate | None

# Localized request
game = client.get_game(730, country="DE", language="german")
```

Returns `None` if the app ID doesn't exist or the API returns a failure response.

---

#### `get_player_count(app_id: int) -> PlayerCount | None`

Fetches the current number of online players.

```python
players = client.get_player_count(730)
if players:
    print(players.player_count)
```

---

#### `get_reviews(app_id: int, language: str = "all", review_filter: str = "all", num_per_page: int = 20, cursor: str = "*") -> ReviewSummary | None`

Fetches the review summary and individual reviews for a game.

```python
reviews = client.get_reviews(730)
if reviews:
    print(f"{reviews.score_description}: {reviews.positive}/{reviews.total}")
    print(f"Score: {reviews.score}/10")
    for review in reviews.reviews:
        print(f"  {review.author_steam_id}: {'👍' if review.voted_up else '👎'}")

# Pagination
reviews = client.get_reviews(730, num_per_page=50, cursor="*")
if reviews and reviews.cursor:
    next_page = client.get_reviews(730, cursor=reviews.cursor)
```

---

#### `get_steamspy_details(app_id: int) -> SteamSpyDetails | None`

Fetches game statistics from the SteamSpy API.

```python
spy = client.get_steamspy_details(730)
if spy:
    print(f"Owners: {spy.owners}")
    print(f"Peak CCU: {spy.peak_ccu}")
    print(f"Average playtime: {spy.average_forever} min")
    print(f"Tags: {spy.tags}")
```

---

#### `get_game_schema(app_id: int) -> GameSchema | None`

Fetches achievement and stat definitions for a game.

```python
schema = client.get_game_schema(730)
if schema:
    print(f"Game: {schema.game_name}")
    for a in schema.achievements:
        print(f"  {a.display_name}: {a.description}")
    for s in schema.stats:
        print(f"  Stat: {s.display_name}")
```

---

#### `get_global_achievement_percentages(app_id: int) -> GlobalAchievements | None`

Fetches global achievement unlock percentages for a game.

```python
global_achs = client.get_global_achievement_percentages(730)
if global_achs:
    for a in global_achs.achievements:
        print(f"  {a.name}: {a.percent:.1f}%")
```

---

#### `get_news(app_id: int, count: int = 20, max_length: int = 0) -> AppNews | None`

Fetches news articles for a game.

```python
news = client.get_news(730, count=5)
if news:
    for item in news.items:
        print(f"  [{item.feed_name}] {item.title}")
        print(f"    {item.url}")
```

---

#### `search(query: str, country: str = "US", language: str = "en") -> SearchResult`

Searches the Steam store. Always returns a `SearchResult` (possibly with zero entries).

```python
results = client.search("portal")
print(f"Found: {results.total}")
for entry in results.entries:
    print(f"  [{entry.app_id}] {entry.name} — {entry.price}")
    print(f"    Platforms: {entry.platforms}")
```

---

## AsyncSteamClient

Asynchronous version with built-in rate limiting. Same methods as `SteamClient`, but `async`.

```python
from steam_fetcher import AsyncSteamClient

async with AsyncSteamClient() as client:
    game = await client.get_game(730)
```

### Constructor

```python
AsyncSteamClient(
    requests_per_minute: int = 200,
    time_period: float = 60.0,
    retries: int = 3,
    timeout: float = 10.0,
    burst_size: int = 10,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `requests_per_minute` | `int` | `200` | Max requests per time period |
| `time_period` | `float` | `60.0` | Time window for rate limiting (seconds) |
| `retries` | `int` | `3` | Retry attempts with exponential backoff |
| `timeout` | `float` | `10.0` | Request timeout in seconds |
| `burst_size` | `int` | `10` | Max burst size for rate limiter |

### Methods

Same as `SteamClient`, all `async`:

- `await get_game(app_id, country="US", language="en")` → `GameDetails | None`
- `await get_player_count(app_id)` → `PlayerCount | None`
- `await get_reviews(app_id, language="all", review_filter="all", num_per_page=20, cursor="*")` → `ReviewSummary | None`
- `await get_steamspy_details(app_id)` → `SteamSpyDetails | None`
- `await get_game_schema(app_id)` → `GameSchema | None`
- `await get_global_achievement_percentages(app_id)` → `GlobalAchievements | None`
- `await get_news(app_id, count=20, max_length=0)` → `AppNews | None`
- `await search(query, country="US", language="en")` → `SearchResult`

### Concurrent requests

```python
import asyncio

async with AsyncSteamClient() as client:
    games = await asyncio.gather(
        client.get_game(730),
        client.get_game(570),
        client.get_game(440),
    )
```

Rate limiting is applied per-request automatically.

### Requires

```bash
pip install steam-fetcher[async]
```
