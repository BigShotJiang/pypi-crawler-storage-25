## Description

<!-- What does this PR do? -->

## Changes
<!-- List of changes -->

## Related Issues
<!-- Closes #123 -->

## Checklist

- [ ] Tests added or updated
- [ ] Coverage does not drop below 80%
- [ ] Docstrings on all public methods
- [ ] `CHANGELOG.md` updated under `[Unreleased]`
- [ ] `mypy` passes
- [ ] `ruff` passes
