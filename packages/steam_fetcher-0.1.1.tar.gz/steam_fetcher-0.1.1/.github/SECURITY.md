# Security Policy

## Reporting a Vulnerability

Please do not open a public issue for security vulnerabilities.
Instead, email directly or open a private advisory on GitHub:
https://github.com/cop1cat/steam-fetcher/security/advisories/new
