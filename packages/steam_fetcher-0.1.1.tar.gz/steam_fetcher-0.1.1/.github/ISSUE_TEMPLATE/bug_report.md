---
name: Bug Report
about: Something is not working as expected
labels: bug
---

## Description
<!-- What happened? -->

## Expected behavior
<!-- What should have happened? -->

## Reproduction
```python
# minimal example
```

## Environment
- steam-fetcher version:
- Python version:
- OS:
