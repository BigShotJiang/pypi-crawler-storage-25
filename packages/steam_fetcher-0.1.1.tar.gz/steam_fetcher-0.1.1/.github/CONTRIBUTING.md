# Contributing

## Setup

```bash
git clone https://github.com/cop1cat/steam-fetcher
cd steam-fetcher
uv sync --all-extras
uv run pre-commit install
```

## Development

```bash
uv run pytest        # run tests
uv run mypy src      # type check
uv run ruff check .  # lint
```

## Pull Requests

- Branch from `main`
- Tests are required - coverage must not drop below 80%
- Docstrings on all public methods
- Add an entry to `CHANGELOG.md` under `[Unreleased]`

## Commit Style

```
feat: add get_game method
fix: handle 429 rate limit response
docs: update README examples
chore: bump httpx to 0.28.0
```
