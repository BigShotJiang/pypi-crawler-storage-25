"""Integration tests for AsyncSteamClient and AsyncSteamAuthClient with respx."""

from __future__ import annotations

import pytest
import respx
from httpx import Response

from steam_fetcher.clients._async_steam_auth_client import AsyncSteamAuthClient
from steam_fetcher.clients._async_steam_client import AsyncSteamClient


class TestAsyncSteamClientContextManager:
    async def test_raises_without_context_manager(self):
        client = AsyncSteamClient()
        with pytest.raises(RuntimeError, match="Client is not initialized"):
            await client.get_game(730)

    async def test_context_manager_lifecycle(self):
        client = AsyncSteamClient()
        assert client._client is None
        async with client:
            assert client._client is not None
        assert client._client is None


class TestAsyncSteamClientGetGame:
    @respx.mock
    async def test_success(self, raw_game_success):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_success)
        )
        async with AsyncSteamClient() as client:
            result = await client.get_game(730)
        assert result is not None
        assert result.app_id == 730

    @respx.mock
    async def test_not_found(self, raw_game_failure):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_failure)
        )
        async with AsyncSteamClient() as client:
            result = await client.get_game(730)
        assert result is None


class TestAsyncSteamClientGetPlayerCount:
    @respx.mock
    async def test_success(self, raw_player_count_success):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1"
        ).mock(return_value=Response(200, json=raw_player_count_success))
        async with AsyncSteamClient() as client:
            result = await client.get_player_count(730)
        assert result is not None
        assert result.player_count == 42000


class TestAsyncSteamClientGetReviews:
    @respx.mock
    async def test_success(self, raw_reviews_success):
        respx.get("https://store.steampowered.com/appreviews/730").mock(
            return_value=Response(200, json=raw_reviews_success)
        )
        async with AsyncSteamClient() as client:
            result = await client.get_reviews(730)
        assert result is not None
        assert result.total == 1000


class TestAsyncSteamClientSearch:
    @respx.mock
    async def test_results(self, raw_search_results):
        respx.get("https://store.steampowered.com/api/storesearch/").mock(
            return_value=Response(200, json=raw_search_results)
        )
        async with AsyncSteamClient() as client:
            result = await client.search("counter")
        assert result.total == 2


class TestAsyncSteamClientGetSteamSpy:
    @respx.mock
    async def test_success(self, raw_steamspy_success):
        respx.get("https://steamspy.com/api.php").mock(
            return_value=Response(200, json=raw_steamspy_success)
        )
        async with AsyncSteamClient() as client:
            result = await client.get_steamspy_details(730)
        assert result is not None
        assert result.name == "Counter-Strike 2"


class TestAsyncSteamAuthClientGetUserProfile:
    @respx.mock
    async def test_success(self, raw_user_profile_success):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_success))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_profile("76561198000000000")
        assert result is not None
        assert result.username == "TestUser"

    @respx.mock
    async def test_not_found(self, raw_user_profile_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_empty))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_profile("76561198000000000")
        assert result is None


class TestAsyncSteamAuthClientGetUserLibrary:
    @respx.mock
    async def test_success(self, raw_user_library_success):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_success))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_library("76561198000000000")
        assert result is not None
        assert result.game_count == 2


class TestAsyncSteamAuthClientGetAchievements:
    @respx.mock
    async def test_success(self, raw_achievements_success):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_success))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_achievements(
                "76561198000000000", 730
            )
        assert result is not None
        assert len(result.achievements) == 2
