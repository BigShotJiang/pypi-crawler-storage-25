"""Tests for exporters that require optional dependencies (Parquet, SQL)."""

from __future__ import annotations

from pathlib import Path

import pytest

from steam_fetcher.models.player import PlayerCount

polars = pytest.importorskip("polars", reason="polars not installed")
sa = pytest.importorskip("sqlalchemy", reason="sqlalchemy not installed")


@pytest.fixture()
def sample_models():
    return [
        PlayerCount(app_id=730, player_count=42000),
        PlayerCount(app_id=570, player_count=80000),
    ]


class TestParquetExporter:
    def test_export(self, tmp_path, sample_models):
        from steam_fetcher.exporters._parquet import ParquetExporter

        path = str(tmp_path / "out.parquet")
        ParquetExporter().export(sample_models, path)
        assert Path(path).exists()
        assert Path(path).stat().st_size > 0

    def test_empty_raises(self, tmp_path):
        from steam_fetcher.exporters._parquet import ParquetExporter

        with pytest.raises(ValueError, match="Data is empty"):
            ParquetExporter().export([], str(tmp_path / "out.parquet"))


class TestSqlExporter:
    def test_export(self, tmp_path, sample_models):
        from steam_fetcher.exporters._sql import SqlExporter

        db_path = tmp_path / "test.db"
        exporter = SqlExporter(url=f"sqlite:///{db_path}")
        exporter.export(sample_models, "player_counts")

        engine = sa.create_engine(f"sqlite:///{db_path}")
        with engine.connect() as conn:
            rows = conn.execute(
                sa.text("SELECT * FROM player_counts")
            ).fetchall()
        assert len(rows) == 2

    def test_empty_raises(self, tmp_path):
        from steam_fetcher.exporters._sql import SqlExporter

        with pytest.raises(ValueError, match="Data is empty"):
            SqlExporter(url="sqlite:///test.db").export([], "t")

    def test_if_exists_fail(self, tmp_path, sample_models):
        from steam_fetcher.exporters._base import ExportError
        from steam_fetcher.exporters._sql import SqlExporter

        db_path = tmp_path / "test.db"
        url = f"sqlite:///{db_path}"
        SqlExporter(url=url, if_exists="append").export(
            sample_models, "player_counts"
        )
        with pytest.raises(ExportError, match="already exists"):
            SqlExporter(url=url, if_exists="fail").export(
                sample_models, "player_counts"
            )

    def test_if_exists_replace(self, tmp_path, sample_models):
        from steam_fetcher.exporters._sql import SqlExporter

        db_path = tmp_path / "test.db"
        url = f"sqlite:///{db_path}"
        SqlExporter(url=url).export(sample_models, "t")
        SqlExporter(url=url, if_exists="replace").export(sample_models[:1], "t")
        engine = sa.create_engine(url)
        with engine.connect() as conn:
            rows = conn.execute(sa.text("SELECT * FROM t")).fetchall()
        assert len(rows) == 1
