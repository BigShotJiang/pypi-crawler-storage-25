"""Unit tests for BaseClient._parse_* methods."""

from __future__ import annotations

from steam_fetcher.clients._base import BaseClient


class TestParseGame:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_game_success):
        result = self.client._parse_game(730, raw_game_success)
        assert result is not None
        assert result.app_id == 730
        assert result.name == "Counter-Strike 2"
        assert result.type == "game"
        assert result.is_free is True
        assert result.short_description == "A competitive FPS"
        assert result.developers == ["Valve"]
        assert result.publishers == ["Valve"]
        assert result.price is not None
        assert result.price.currency == "USD"
        assert result.platforms is not None
        assert result.platforms.windows is True
        assert result.platforms.linux is True
        assert result.metacritic is not None
        assert result.metacritic.score == 83
        assert len(result.categories) == 1
        assert len(result.genres) == 1
        assert len(result.screenshots) == 1
        assert result.dlc_count == 3
        assert result.achievements == 67
        assert result.recommendations == 500000
        assert result.required_age == 0
        assert result.release_date is not None
        assert result.release_date.coming_soon is False

    def test_failure(self, raw_game_failure):
        result = self.client._parse_game(730, raw_game_failure)
        assert result is None

    def test_missing_app_id(self):
        result = self.client._parse_game(999, {"730": {"success": True}})
        assert result is None

    def test_empty_optional_fields(self):
        data = {
            "1": {
                "success": True,
                "data": {
                    "steam_appid": 1,
                    "name": "Test",
                    "type": "game",
                    "is_free": False,
                    "short_description": "",
                    "about_the_game": "",
                    "detailed_description": "",
                    "supported_languages": "",
                    "header_image": "",
                    "website": "",
                    "developers": [],
                    "publishers": [],
                    "platforms": None,
                    "categories": [],
                    "genres": [],
                    "screenshots": [],
                    "movies": [],
                    "release_date": None,
                    "required_age": "18+",
                },
            }
        }
        result = self.client._parse_game(1, data)
        assert result is not None
        assert result.short_description is None
        assert result.website is None
        assert result.header_image is None
        assert result.supported_languages == []
        assert result.required_age == 18


class TestParsePlayerCount:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_player_count_success):
        result = self.client._parse_player_count(730, raw_player_count_success)
        assert result is not None
        assert result.app_id == 730
        assert result.player_count == 42000

    def test_failure(self, raw_player_count_failure):
        result = self.client._parse_player_count(730, raw_player_count_failure)
        assert result is None


class TestParseReviews:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_reviews_success):
        result = self.client._parse_reviews(730, raw_reviews_success)
        assert result is not None
        assert result.app_id == 730
        assert result.total == 1000
        assert result.positive == 900
        assert result.negative == 100
        assert result.score == 8
        assert result.score_description == "Very Positive"
        assert result.review_type == "all"
        assert result.purchase_type == "all"

    def test_failure(self, raw_reviews_failure):
        result = self.client._parse_reviews(730, raw_reviews_failure)
        assert result is None


class TestParseSearch:
    def setup_method(self):
        self.client = BaseClient()

    def test_results(self, raw_search_results):
        result = self.client._parse_search("counter", raw_search_results)
        assert result.term == "counter"
        assert result.total == 2
        assert len(result.entries) == 2
        assert result.entries[0].app_id == 730
        assert result.entries[0].name == "Counter-Strike 2"
        assert result.entries[0].price == "Free to Play"
        assert result.entries[0].platforms is not None
        assert result.entries[0].platforms.windows is True
        assert result.entries[1].icon is None
        assert result.entries[1].platforms is None

    def test_empty(self):
        result = self.client._parse_search("nothing", {"total": 0, "items": []})
        assert result.total == 0
        assert result.entries == []


class TestParseUserProfile:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_user_profile_success):
        result = self.client._parse_user_profile(raw_user_profile_success)
        assert result is not None
        assert result.steam_id == "76561198000000000"
        assert result.username == "TestUser"
        assert result.real_name == "John Doe"
        assert result.avatar.small is not None
        assert result.country_code == "US"
        assert result.is_public is True
        assert result.time_created == 1200000000

    def test_empty(self, raw_user_profile_empty):
        result = self.client._parse_user_profile(raw_user_profile_empty)
        assert result is None


class TestParseUserLibrary:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_user_library_success):
        result = self.client._parse_user_library(
            "76561198000000000", raw_user_library_success
        )
        assert result is not None
        assert result.steam_id == "76561198000000000"
        assert result.game_count == 2
        assert len(result.games) == 2
        assert result.games[0].app_id == 730
        assert result.games[0].playtime_forever == 5000
        assert result.games[0].playtime_2weeks == 120
        assert result.games[1].playtime_2weeks is None

    def test_empty(self, raw_user_library_empty):
        result = self.client._parse_user_library(
            "76561198000000000", raw_user_library_empty
        )
        assert result is None


class TestParseAchievements:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_achievements_success):
        result = self.client._parse_achievements(730, raw_achievements_success)
        assert result is not None
        assert result.app_id == 730
        assert result.game_name == "Counter-Strike 2"
        assert len(result.achievements) == 2
        assert result.achievements[0].api_name == "WIN_BOMB"
        assert result.achievements[0].achieved is True
        assert result.achievements[0].unlock_time == 1700000000
        assert result.achievements[1].achieved is False
        assert result.achievements[1].unlock_time is None

    def test_empty(self, raw_achievements_empty):
        result = self.client._parse_achievements(730, raw_achievements_empty)
        assert result is None


class TestParseSteamSpy:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self, raw_steamspy_success):
        result = self.client._parse_steamspy(730, raw_steamspy_success)
        assert result is not None
        assert result.app_id == 730
        assert result.name == "Counter-Strike 2"
        assert result.developer == "Valve"
        assert result.ccu == 1500000
        assert result.tags == {"FPS": 10000, "Competitive": 8000}

    def test_empty_developer(self, raw_steamspy_empty):
        result = self.client._parse_steamspy(730, raw_steamspy_empty)
        assert result is None

    def test_none_data(self):
        result = self.client._parse_steamspy(730, {})
        assert result is None


class TestParseLanguages:
    def test_simple(self):
        result = BaseClient._parse_languages("English, Russian, German")
        assert result == ["English", "Russian", "German"]

    def test_with_html_and_asterisks(self):
        result = BaseClient._parse_languages(
            "English<strong>*</strong>, Russian, German<strong>*</strong>"
        )
        assert "English" in result
        assert "Russian" in result
        assert "German" in result

    def test_with_audio_support_text(self):
        result = BaseClient._parse_languages(
            "English, Russianlanguages with full audio support"
        )
        assert "English" in result

    def test_empty(self):
        result = BaseClient._parse_languages("")
        assert result == []
