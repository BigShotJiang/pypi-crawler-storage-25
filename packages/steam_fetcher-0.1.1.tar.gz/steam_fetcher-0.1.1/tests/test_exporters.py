"""Tests for exporters (CSV, JSON, Parquet, SQL)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from steam_fetcher.exporters._csv import CsvExporter
from steam_fetcher.exporters._json import JsonExporter
from steam_fetcher.models.player import PlayerCount


@pytest.fixture()
def sample_models():
    return [
        PlayerCount(app_id=730, player_count=42000),
        PlayerCount(app_id=570, player_count=80000),
    ]


@pytest.fixture()
def single_model():
    return [PlayerCount(app_id=730, player_count=42000)]


class TestJsonExporter:
    def test_export(self, tmp_path, sample_models):
        path = str(tmp_path / "out.json")
        JsonExporter().export(sample_models, path)

        with open(path) as f:
            data = json.load(f)
        assert len(data) == 2
        assert data[0]["app_id"] == 730
        assert data[1]["player_count"] == 80000

    def test_creates_parent_dirs(self, tmp_path, single_model):
        path = str(tmp_path / "sub" / "dir" / "out.json")
        JsonExporter().export(single_model, path)
        assert Path(path).exists()

    def test_empty_raises(self, tmp_path):
        with pytest.raises(ValueError, match="Data is empty"):
            JsonExporter().export([], str(tmp_path / "out.json"))

    def test_indent(self, tmp_path, single_model):
        path = str(tmp_path / "out.json")
        JsonExporter(indent=2).export(single_model, path)
        content = Path(path).read_text()
        assert "  " in content


class TestCsvExporter:
    def test_export(self, tmp_path, sample_models):
        path = str(tmp_path / "out.csv")
        CsvExporter().export(sample_models, path)

        with open(path, newline="") as f:
            reader = list(csv.DictReader(f))
        assert len(reader) == 2
        assert reader[0]["app_id"] == "730"
        assert reader[1]["player_count"] == "80000"

    def test_custom_delimiter(self, tmp_path, single_model):
        path = str(tmp_path / "out.csv")
        CsvExporter(delimiter=";").export(single_model, path)
        content = Path(path).read_text()
        assert ";" in content

    def test_empty_raises(self, tmp_path):
        with pytest.raises(ValueError, match="Data is empty"):
            CsvExporter().export([], str(tmp_path / "out.csv"))

    def test_flatten_nested(self, tmp_path):
        from steam_fetcher.models.game import GameDetails

        game = GameDetails(
            app_id=1,
            name="Test",
            type="game",
            is_free=True,
            developers=["Dev1", "Dev2"],
            required_age=0,
        )
        path = str(tmp_path / "out.csv")
        CsvExporter(flatten=True).export([game], path)

        with open(path, newline="") as f:
            reader = list(csv.DictReader(f))
        assert "Dev1|Dev2" in reader[0]["developers"]


class TestCsvExporterFlattenValue:
    def setup_method(self):
        self.exporter = CsvExporter()

    def test_list(self):
        assert self.exporter._flatten_value(["a", "b"]) == "a|b"

    def test_dict(self):
        result = self.exporter._flatten_value({"k": "v"})
        assert "k" in result

    def test_none(self):
        assert self.exporter._flatten_value(None) == ""

    def test_scalar(self):
        assert self.exporter._flatten_value(42) == "42"
