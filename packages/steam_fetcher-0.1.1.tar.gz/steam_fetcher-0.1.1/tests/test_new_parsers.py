"""Tests for new _parse_* methods added in TODO implementation."""

from __future__ import annotations

from steam_fetcher.clients._base import BaseClient


class TestParseFriends:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "friendslist": {
                "friends": [
                    {
                        "steamid": "111",
                        "relationship": "friend",
                        "friend_since": 1600000000,
                    },
                    {
                        "steamid": "222",
                        "relationship": "friend",
                        "friend_since": 1700000000,
                    },
                ]
            }
        }
        result = self.client._parse_friends("000", data)
        assert result is not None
        assert result.steam_id == "000"
        assert len(result.friends) == 2
        assert result.friends[0].steam_id == "111"
        assert result.friends[1].friend_since == 1700000000

    def test_empty(self):
        result = self.client._parse_friends("000", {})
        assert result is None


class TestParseBans:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "players": [
                {
                    "SteamId": "111",
                    "CommunityBanned": False,
                    "VACBanned": True,
                    "NumberOfVACBans": 1,
                    "DaysSinceLastBan": 100,
                    "NumberOfGameBans": 0,
                    "EconomyBan": "none",
                }
            ]
        }
        result = self.client._parse_bans(data)
        assert len(result) == 1
        assert result[0].vac_banned is True
        assert result[0].number_of_vac_bans == 1

    def test_empty(self):
        result = self.client._parse_bans({})
        assert result == []


class TestParseVanityUrl:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {"response": {"success": 1, "steamid": "76561198000000000"}}
        result = self.client._parse_vanity_url(data)
        assert result == "76561198000000000"

    def test_not_found(self):
        data = {"response": {"success": 42}}
        result = self.client._parse_vanity_url(data)
        assert result is None


class TestParseRecentlyPlayed:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "response": {
                "total_count": 1,
                "games": [
                    {
                        "appid": 730,
                        "name": "CS2",
                        "playtime_2weeks": 120,
                        "playtime_forever": 5000,
                    }
                ],
            }
        }
        result = self.client._parse_recently_played("000", data)
        assert result is not None
        assert result.total_count == 1
        assert result.games[0].app_id == 730

    def test_empty(self):
        result = self.client._parse_recently_played("000", {"response": {}})
        assert result is None


class TestParseSteamLevel:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {"response": {"player_level": 42}}
        assert self.client._parse_steam_level(data) == 42

    def test_empty(self):
        assert self.client._parse_steam_level({"response": {}}) is None


class TestParseBadges:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "response": {
                "badges": [
                    {
                        "badgeid": 1,
                        "level": 5,
                        "completion_time": 1600000000,
                        "xp": 100,
                        "scarcity": 50000,
                    }
                ],
                "player_xp": 1000,
                "player_level": 10,
            }
        }
        result = self.client._parse_badges("000", data)
        assert result is not None
        assert result.player_level == 10
        assert len(result.badges) == 1
        assert result.badges[0].badge_id == 1

    def test_empty(self):
        result = self.client._parse_badges("000", {"response": {}})
        assert result is None


class TestParseWishlist:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "730": {"priority": 1, "added": 1700000000},
            "570": {"priority": 2},
        }
        result = self.client._parse_wishlist("000", data)
        assert len(result) == 2
        ids = {item.app_id for item in result}
        assert 730 in ids
        assert 570 in ids


class TestParseUserStats:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "playerstats": {
                "gameName": "CS2",
                "stats": [
                    {"name": "total_kills", "value": 5000},
                ],
            }
        }
        result = self.client._parse_user_stats("000", 730, data)
        assert result is not None
        assert result.game_name == "CS2"
        assert result.stats[0].name == "total_kills"

    def test_empty(self):
        result = self.client._parse_user_stats("000", 730, {})
        assert result is None


class TestParseGameSchema:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "game": {
                "gameName": "CS2",
                "availableGameStats": {
                    "achievements": [
                        {
                            "name": "WIN",
                            "displayName": "Winner",
                            "description": "Win a round",
                        }
                    ],
                    "stats": [
                        {"name": "kills", "displayName": "Kills"},
                    ],
                },
            }
        }
        result = self.client._parse_game_schema(730, data)
        assert result is not None
        assert result.game_name == "CS2"
        assert len(result.achievements) == 1
        assert len(result.stats) == 1

    def test_empty(self):
        result = self.client._parse_game_schema(730, {})
        assert result is None


class TestParseGlobalAchievements:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "achievementpercentages": {
                "achievements": [
                    {"name": "WIN", "percent": 45.5},
                ]
            }
        }
        result = self.client._parse_global_achievements(730, data)
        assert result is not None
        assert result.achievements[0].percent == 45.5

    def test_empty(self):
        result = self.client._parse_global_achievements(730, {})
        assert result is None


class TestParseNews:
    def setup_method(self):
        self.client = BaseClient()

    def test_success(self):
        data = {
            "appnews": {
                "newsitems": [
                    {
                        "gid": "123",
                        "title": "Update",
                        "url": "https://example.com",
                        "author": "Valve",
                        "contents": "New update",
                        "date": 1700000000,
                        "feedname": "steam",
                    }
                ]
            }
        }
        result = self.client._parse_news(730, data)
        assert result is not None
        assert len(result.items) == 1
        assert result.items[0].title == "Update"

    def test_empty(self):
        result = self.client._parse_news(730, {})
        assert result is None


class TestParseUserProfileNewFields:
    def setup_method(self):
        self.client = BaseClient()

    def test_persona_state_and_game(self):
        data = {
            "response": {
                "players": [
                    {
                        "steamid": "111",
                        "personaname": "Test",
                        "avatar": "https://a.com/s.jpg",
                        "avatarmedium": "https://a.com/m.jpg",
                        "avatarfull": "https://a.com/f.jpg",
                        "profileurl": "https://steamcommunity.com/id/test/",
                        "communityvisibilitystate": 3,
                        "personastate": 1,
                        "gameid": "730",
                        "gameextrainfo": "Counter-Strike 2",
                    }
                ]
            }
        }
        result = self.client._parse_user_profile(data)
        assert result is not None
        assert result.persona_state == 1
        assert result.game_id == 730
        assert result.game_extra_info == "Counter-Strike 2"


class TestLibraryGameIconUrl:
    def test_with_hash(self):
        from steam_fetcher.models.user import LibraryGame

        g = LibraryGame(app_id=730, img_icon_url="abc123")
        assert g.icon_url is not None
        assert "730" in g.icon_url
        assert "abc123" in g.icon_url

    def test_without_hash(self):
        from steam_fetcher.models.user import LibraryGame

        g = LibraryGame(app_id=730)
        assert g.icon_url is None
