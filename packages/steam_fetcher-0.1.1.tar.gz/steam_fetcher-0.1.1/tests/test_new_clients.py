"""Tests for new client methods."""

from __future__ import annotations

import respx
from httpx import Response

from steam_fetcher.clients._steam_auth_client import SteamAuthClient
from steam_fetcher.clients._steam_client import SteamClient


class TestSteamClientGetGlobalAchievements:
    @respx.mock
    def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "achievementpercentages": {
                        "achievements": [{"name": "WIN", "percent": 45.5}]
                    }
                },
            )
        )
        with SteamClient() as client:
            result = client.get_global_achievement_percentages(730)
        assert result is not None
        assert len(result.achievements) == 1


class TestSteamClientGetNews:
    @respx.mock
    def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamNews/GetNewsForApp/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "appnews": {
                        "newsitems": [
                            {
                                "gid": "1",
                                "title": "Update",
                                "url": "https://example.com",
                                "author": "Valve",
                                "contents": "text",
                                "date": 1700000000,
                                "feedname": "steam",
                            }
                        ]
                    }
                },
            )
        )
        with SteamClient() as client:
            result = client.get_news(730)
        assert result is not None
        assert len(result.items) == 1


class TestSteamAuthClientNewMethods:
    @respx.mock
    def test_get_user_friends(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetFriendList/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "friendslist": {
                        "friends": [
                            {
                                "steamid": "111",
                                "relationship": "friend",
                                "friend_since": 1600000000,
                            }
                        ]
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_user_friends("000")
        assert result is not None
        assert len(result.friends) == 1

    @respx.mock
    def test_get_user_bans(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerBans/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "players": [
                        {
                            "SteamId": "111",
                            "CommunityBanned": False,
                            "VACBanned": False,
                            "NumberOfVACBans": 0,
                            "DaysSinceLastBan": 0,
                            "NumberOfGameBans": 0,
                            "EconomyBan": "none",
                        }
                    ]
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_user_bans(["111"])
        assert len(result) == 1
        assert result[0].steam_id == "111"

    @respx.mock
    def test_resolve_vanity_url(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {"success": 1, "steamid": "76561198000000000"}
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.resolve_vanity_url("testuser")
        assert result == "76561198000000000"

    @respx.mock
    def test_get_user_profiles(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "players": [
                            {
                                "steamid": "111",
                                "personaname": "User1",
                                "avatar": "https://a.com/s.jpg",
                                "avatarmedium": "https://a.com/m.jpg",
                                "avatarfull": "https://a.com/f.jpg",
                                "profileurl": "https://steamcommunity.com/id/u1/",
                                "communityvisibilitystate": 3,
                            }
                        ]
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_user_profiles(["111"])
        assert len(result) == 1
        assert result[0].steam_id == "111"

    @respx.mock
    def test_get_recently_played(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetRecentlyPlayedGames/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "total_count": 1,
                        "games": [
                            {
                                "appid": 730,
                                "name": "CS2",
                                "playtime_2weeks": 120,
                                "playtime_forever": 5000,
                            }
                        ],
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_recently_played("000")
        assert result is not None
        assert result.total_count == 1

    @respx.mock
    def test_get_steam_level(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetSteamLevel/v1"
        ).mock(
            return_value=Response(200, json={"response": {"player_level": 42}})
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_steam_level("000")
        assert result == 42

    @respx.mock
    def test_get_user_badges(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetBadges/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "badges": [
                            {
                                "badgeid": 1,
                                "level": 5,
                                "completion_time": 1600000000,
                                "xp": 100,
                                "scarcity": 50000,
                            }
                        ],
                        "player_xp": 1000,
                        "player_level": 10,
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_user_badges("000")
        assert result is not None
        assert result.player_level == 10

    @respx.mock
    def test_get_wishlist(self):
        respx.get(
            "https://store.steampowered.com/wishlist/profiles/000/wishlistdata"
        ).mock(
            return_value=Response(
                200,
                json={"730": {"priority": 1, "added": 1700000000}},
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_wishlist("000")
        assert len(result) == 1
        assert result[0].app_id == 730

    @respx.mock
    def test_get_user_stats(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetUserStatsForGame/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "playerstats": {
                        "gameName": "CS2",
                        "stats": [{"name": "kills", "value": 5000}],
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_user_stats("000", 730)
        assert result is not None
        assert result.stats[0].value == 5000

    @respx.mock
    def test_get_game_schema(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "game": {
                        "gameName": "CS2",
                        "availableGameStats": {
                            "achievements": [
                                {"name": "WIN", "displayName": "Win"}
                            ],
                            "stats": [
                                {"name": "kills", "displayName": "Kills"}
                            ],
                        },
                    }
                },
            )
        )
        with SteamAuthClient(api_key="k") as client:
            result = client.get_game_schema(730)
        assert result is not None
        assert result.game_name == "CS2"
