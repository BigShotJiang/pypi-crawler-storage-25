from __future__ import annotations

import pytest


@pytest.fixture()
def raw_game_success():
    return {
        "730": {
            "success": True,
            "data": {
                "steam_appid": 730,
                "name": "Counter-Strike 2",
                "type": "game",
                "is_free": True,
                "short_description": "A competitive FPS",
                "about_the_game": "About CS2",
                "detailed_description": "Detailed CS2",
                "supported_languages": "English, Russian<strong>*</strong>",
                "header_image": "https://cdn.akamai.steamstatic.com/header.jpg",
                "website": "https://counter-strike.net",
                "developers": ["Valve"],
                "publishers": ["Valve"],
                "price_overview": {
                    "currency": "USD",
                    "initial": 0,
                    "final": 0,
                    "discount_percent": 0,
                    "initial_formatted": "$0.00",
                    "final_formatted": "$0.00",
                },
                "platforms": {"windows": True, "mac": True, "linux": True},
                "metacritic": {
                    "score": 83,
                    "url": "https://www.metacritic.com/game/cs2",
                },
                "categories": [{"id": 1, "description": "Multi-player"}],
                "genres": [{"id": 1, "description": "Action"}],
                "screenshots": [
                    {
                        "id": 0,
                        "path_thumbnail": "https://cdn.steam.com/thumb.jpg",
                        "path_full": "https://cdn.steam.com/full.jpg",
                    }
                ],
                "movies": [
                    {
                        "id": 100,
                        "name": "Trailer",
                        "thumbnail": "https://cdn.steam.com/movie.jpg",
                        "webm": {"max": "https://cdn.steam.com/movie.webm"},
                        "mp4": {"max": "https://cdn.steam.com/movie.mp4"},
                    }
                ],
                "release_date": {"coming_soon": False, "date": "Sep 27, 2023"},
                "dlc": [1, 2, 3],
                "achievements": {"total": 67},
                "recommendations": {"total": 500000},
                "required_age": 0,
            },
        }
    }


@pytest.fixture()
def raw_game_failure():
    return {"730": {"success": False}}


@pytest.fixture()
def raw_player_count_success():
    return {"response": {"result": 1, "player_count": 42000}}


@pytest.fixture()
def raw_player_count_failure():
    return {"response": {"result": 42}}


@pytest.fixture()
def raw_reviews_success():
    return {
        "success": 1,
        "query_summary": {
            "total_reviews": 1000,
            "total_positive": 900,
            "total_negative": 100,
            "review_score": 8,
            "review_score_desc": "Very Positive",
        },
    }


@pytest.fixture()
def raw_reviews_failure():
    return {"success": 0}


@pytest.fixture()
def raw_search_results():
    return {
        "total": 2,
        "items": [
            {
                "id": 730,
                "name": "Counter-Strike 2",
                "tiny_image": "https://cdn.steam.com/icon.jpg",
                "price": {"currency": "USD", "initial": 0, "final": 0},
                "platforms": {"windows": True, "mac": False, "linux": True},
            },
            {
                "id": 10,
                "name": "Counter-Strike",
                "tiny_image": None,
                "price": {"currency": "USD", "initial": 999, "final": 999},
            },
        ],
    }


@pytest.fixture()
def raw_user_profile_success():
    return {
        "response": {
            "players": [
                {
                    "steamid": "76561198000000000",
                    "personaname": "TestUser",
                    "realname": "John Doe",
                    "avatar": "https://avatars.steam.com/small.jpg",
                    "avatarmedium": "https://avatars.steam.com/medium.jpg",
                    "avatarfull": "https://avatars.steam.com/full.jpg",
                    "profileurl": "https://steamcommunity.com/id/test/",
                    "loccountrycode": "US",
                    "locstatecode": "CA",
                    "timecreated": 1200000000,
                    "lastlogoff": 1700000000,
                    "communityvisibilitystate": 3,
                }
            ]
        }
    }


@pytest.fixture()
def raw_user_profile_empty():
    return {"response": {"players": []}}


@pytest.fixture()
def raw_user_library_success():
    return {
        "response": {
            "game_count": 2,
            "games": [
                {
                    "appid": 730,
                    "name": "Counter-Strike 2",
                    "playtime_forever": 5000,
                    "playtime_2weeks": 120,
                    "img_icon_url": "abc123",
                    "rtime_last_played": 1700000000,
                },
                {
                    "appid": 570,
                    "name": "Dota 2",
                    "playtime_forever": 10000,
                },
            ],
        }
    }


@pytest.fixture()
def raw_user_library_empty():
    return {"response": {}}


@pytest.fixture()
def raw_achievements_success():
    return {
        "playerstats": {
            "gameName": "Counter-Strike 2",
            "achievements": [
                {
                    "apiname": "WIN_BOMB",
                    "achieved": 1,
                    "unlocktime": 1700000000,
                    "name": "Bomb Expert",
                    "description": "Win 100 bomb rounds",
                },
                {
                    "apiname": "HEADSHOT",
                    "achieved": 0,
                    "unlocktime": 0,
                    "name": "Sharpshooter",
                    "description": None,
                },
            ],
        }
    }


@pytest.fixture()
def raw_achievements_empty():
    return {}


@pytest.fixture()
def raw_steamspy_success():
    return {
        "appid": 730,
        "name": "Counter-Strike 2",
        "developer": "Valve",
        "publisher": "Valve",
        "score_rank": "95",
        "positive": 900000,
        "negative": 100000,
        "userscore": 0,
        "owners": "50,000,000 .. 100,000,000",
        "average_forever": 30000,
        "average_2weeks": 500,
        "median_forever": 10000,
        "median_2weeks": 200,
        "ccu": 1500000,
        "price": "0",
        "discount": "0",
        "tags": {"FPS": 10000, "Competitive": 8000},
    }


@pytest.fixture()
def raw_steamspy_empty():
    return {"developer": ""}
