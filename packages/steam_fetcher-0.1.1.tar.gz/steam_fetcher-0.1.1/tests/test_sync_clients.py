"""Integration tests for SteamClient and SteamAuthClient with respx."""

from __future__ import annotations

import pytest
import respx
from httpx import Response

from steam_fetcher.clients._steam_auth_client import SteamAuthClient
from steam_fetcher.clients._steam_client import SteamClient


class TestSteamClientContextManager:
    def test_raises_without_context_manager(self):
        client = SteamClient()
        with pytest.raises(RuntimeError, match="Client is not initialized"):
            client.get_game(730)

    def test_context_manager_lifecycle(self):
        client = SteamClient()
        assert client._client is None
        with client:
            assert client._client is not None
        assert client._client is None


class TestSteamClientGetGame:
    @respx.mock
    def test_success(self, raw_game_success):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_success)
        )
        with SteamClient() as client:
            result = client.get_game(730)
        assert result is not None
        assert result.app_id == 730
        assert result.name == "Counter-Strike 2"

    @respx.mock
    def test_not_found(self, raw_game_failure):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_failure)
        )
        with SteamClient() as client:
            result = client.get_game(730)
        assert result is None


class TestSteamClientGetPlayerCount:
    @respx.mock
    def test_success(self, raw_player_count_success):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1"
        ).mock(return_value=Response(200, json=raw_player_count_success))
        with SteamClient() as client:
            result = client.get_player_count(730)
        assert result is not None
        assert result.player_count == 42000

    @respx.mock
    def test_not_found(self, raw_player_count_failure):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1"
        ).mock(return_value=Response(200, json=raw_player_count_failure))
        with SteamClient() as client:
            result = client.get_player_count(730)
        assert result is None


class TestSteamClientGetReviews:
    @respx.mock
    def test_success(self, raw_reviews_success):
        respx.get("https://store.steampowered.com/appreviews/730").mock(
            return_value=Response(200, json=raw_reviews_success)
        )
        with SteamClient() as client:
            result = client.get_reviews(730)
        assert result is not None
        assert result.total == 1000

    @respx.mock
    def test_not_found(self, raw_reviews_failure):
        respx.get("https://store.steampowered.com/appreviews/730").mock(
            return_value=Response(200, json=raw_reviews_failure)
        )
        with SteamClient() as client:
            result = client.get_reviews(730)
        assert result is None


class TestSteamClientSearch:
    @respx.mock
    def test_results(self, raw_search_results):
        respx.get("https://store.steampowered.com/api/storesearch/").mock(
            return_value=Response(200, json=raw_search_results)
        )
        with SteamClient() as client:
            result = client.search("counter")
        assert result.total == 2
        assert result.entries[0].app_id == 730


class TestSteamClientGetSteamSpy:
    @respx.mock
    def test_success(self, raw_steamspy_success):
        respx.get("https://steamspy.com/api.php").mock(
            return_value=Response(200, json=raw_steamspy_success)
        )
        with SteamClient() as client:
            result = client.get_steamspy_details(730)
        assert result is not None
        assert result.name == "Counter-Strike 2"

    @respx.mock
    def test_not_found(self, raw_steamspy_empty):
        respx.get("https://steamspy.com/api.php").mock(
            return_value=Response(200, json=raw_steamspy_empty)
        )
        with SteamClient() as client:
            result = client.get_steamspy_details(730)
        assert result is None


class TestSteamClientRetry:
    @respx.mock
    def test_retries_on_server_error(self, raw_game_success):
        route = respx.get("https://store.steampowered.com/api/appdetails").mock(
            side_effect=[
                Response(500),
                Response(200, json=raw_game_success),
            ]
        )
        with SteamClient(retries=3) as client:
            result = client.get_game(730)
        assert result is not None
        assert route.call_count == 2


class TestSteamAuthClientGetUserProfile:
    @respx.mock
    def test_success(self, raw_user_profile_success):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_success))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_profile("76561198000000000")
        assert result is not None
        assert result.steam_id == "76561198000000000"
        assert result.username == "TestUser"

    @respx.mock
    def test_not_found(self, raw_user_profile_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_empty))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_profile("76561198000000000")
        assert result is None


class TestSteamAuthClientGetUserLibrary:
    @respx.mock
    def test_success(self, raw_user_library_success):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_success))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_library("76561198000000000")
        assert result is not None
        assert result.game_count == 2

    @respx.mock
    def test_empty(self, raw_user_library_empty):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_empty))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_library("76561198000000000")
        assert result is None


class TestSteamAuthClientGetAchievements:
    @respx.mock
    def test_success(self, raw_achievements_success):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_success))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_achievements("76561198000000000", 730)
        assert result is not None
        assert result.game_name == "Counter-Strike 2"
        assert len(result.achievements) == 2

    @respx.mock
    def test_empty(self, raw_achievements_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_empty))
        with SteamAuthClient(api_key="test_key") as client:
            result = client.get_user_achievements("76561198000000000", 730)
        assert result is None


class TestSteamAuthClientApiKey:
    def test_accepts_string(self):
        client = SteamAuthClient(api_key="my_key")
        assert client._api_key.get_secret_value() == "my_key"

    def test_accepts_secret_str(self):
        from pydantic import SecretStr

        client = SteamAuthClient(api_key=SecretStr("my_key"))
        assert client._api_key.get_secret_value() == "my_key"
