"""Integration tests for AsyncSteamAuthClient methods with respx."""

from __future__ import annotations

import respx
from httpx import Response

from steam_fetcher.clients._async_steam_auth_client import AsyncSteamAuthClient


class TestAsyncSteamAuthClientGetUserLibraryEmpty:
    @respx.mock
    async def test_empty(self, raw_user_library_empty):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_empty))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_library("76561198000000000")
        assert result is None


class TestAsyncSteamAuthClientGetAchievementsEmpty:
    @respx.mock
    async def test_empty(self, raw_achievements_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_empty))
        async with AsyncSteamAuthClient(api_key="test_key") as client:
            result = await client.get_user_achievements(
                "76561198000000000", 730
            )
        assert result is None


class TestAsyncSteamAuthClientGetUserFriends:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetFriendList/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "friendslist": {
                        "friends": [
                            {
                                "steamid": "111",
                                "relationship": "friend",
                                "friend_since": 1600000000,
                            }
                        ]
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_friends("000")
        assert result is not None
        assert len(result.friends) == 1

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetFriendList/v1"
        ).mock(return_value=Response(200, json={}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_friends("000")
        assert result is None


class TestAsyncSteamAuthClientGetUserBans:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerBans/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "players": [
                        {
                            "SteamId": "111",
                            "CommunityBanned": False,
                            "VACBanned": False,
                            "NumberOfVACBans": 0,
                            "DaysSinceLastBan": 0,
                            "NumberOfGameBans": 0,
                            "EconomyBan": "none",
                        }
                    ]
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_bans(["111"])
        assert len(result) == 1
        assert result[0].steam_id == "111"


class TestAsyncSteamAuthClientResolveVanityUrl:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "success": 1,
                        "steamid": "76561198000000000",
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.resolve_vanity_url("testuser")
        assert result == "76561198000000000"

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1"
        ).mock(
            return_value=Response(
                200,
                json={"response": {"success": 42}},
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.resolve_vanity_url("nobody")
        assert result is None


class TestAsyncSteamAuthClientGetUserProfiles:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "players": [
                            {
                                "steamid": "111",
                                "personaname": "User1",
                                "avatar": "https://a.com/s.jpg",
                                "avatarmedium": "https://a.com/m.jpg",
                                "avatarfull": "https://a.com/f.jpg",
                                "profileurl": "https://steamcommunity.com/id/u1/",
                                "communityvisibilitystate": 3,
                            }
                        ]
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_profiles(["111"])
        assert len(result) == 1
        assert result[0].steam_id == "111"


class TestAsyncSteamAuthClientGetRecentlyPlayed:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetRecentlyPlayedGames/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "total_count": 1,
                        "games": [
                            {
                                "appid": 730,
                                "name": "CS2",
                                "playtime_2weeks": 120,
                                "playtime_forever": 5000,
                            }
                        ],
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_recently_played("000")
        assert result is not None
        assert result.total_count == 1

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetRecentlyPlayedGames/v1"
        ).mock(return_value=Response(200, json={}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_recently_played("000")
        assert result is None


class TestAsyncSteamAuthClientGetSteamLevel:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetSteamLevel/v1"
        ).mock(
            return_value=Response(200, json={"response": {"player_level": 42}})
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_steam_level("000")
        assert result == 42

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetSteamLevel/v1"
        ).mock(return_value=Response(200, json={"response": {}}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_steam_level("000")
        assert result is None


class TestAsyncSteamAuthClientGetUserBadges:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetBadges/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "badges": [
                            {
                                "badgeid": 1,
                                "level": 5,
                                "completion_time": 1600000000,
                                "xp": 100,
                                "scarcity": 50000,
                            }
                        ],
                        "player_xp": 1000,
                        "player_level": 10,
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_badges("000")
        assert result is not None
        assert result.player_level == 10

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetBadges/v1"
        ).mock(return_value=Response(200, json={"response": {}}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_badges("000")
        assert result is None


class TestAsyncSteamAuthClientGetWishlist:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://store.steampowered.com/wishlist/profiles/000/wishlistdata"
        ).mock(
            return_value=Response(
                200,
                json={"730": {"priority": 1, "added": 1700000000}},
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_wishlist("000")
        assert len(result) == 1
        assert result[0].app_id == 730


class TestAsyncSteamAuthClientGetUserStats:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetUserStatsForGame/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "playerstats": {
                        "gameName": "CS2",
                        "stats": [{"name": "kills", "value": 5000}],
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_stats("000", 730)
        assert result is not None
        assert result.stats[0].value == 5000

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetUserStatsForGame/v2"
        ).mock(return_value=Response(200, json={}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_user_stats("000", 730)
        assert result is None


class TestAsyncSteamAuthClientGetAppList:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/IStoreService/GetAppList/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "apps": [
                            {"appid": 730, "name": "CS2"},
                            {"appid": 570, "name": "Dota 2"},
                        ],
                        "last_appid": 570,
                        "have_more_results": True,
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_app_list()
        assert len(result.apps) == 2
        assert result.last_appid == 570

    @respx.mock
    async def test_with_pagination(self):
        respx.get(
            "https://api.steampowered.com/IStoreService/GetAppList/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "apps": [{"appid": 1000, "name": "Game"}],
                        "last_appid": 1000,
                        "have_more_results": False,
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_app_list(last_appid=570)
        assert len(result.apps) == 1


class TestAsyncSteamAuthClientGetGameSchema:
    @respx.mock
    async def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "game": {
                        "gameName": "CS2",
                        "availableGameStats": {
                            "achievements": [
                                {"name": "WIN", "displayName": "Win"}
                            ],
                            "stats": [
                                {"name": "kills", "displayName": "Kills"}
                            ],
                        },
                    }
                },
            )
        )
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_game_schema(730)
        assert result is not None
        assert result.game_name == "CS2"

    @respx.mock
    async def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2"
        ).mock(return_value=Response(200, json={}))
        async with AsyncSteamAuthClient(api_key="k") as client:
            result = await client.get_game_schema(999999)
        assert result is None


class TestAsyncSteamAuthClientApiKey:
    def test_accepts_string(self):
        client = AsyncSteamAuthClient(api_key="my_key")
        assert client._api_key.get_secret_value() == "my_key"

    def test_accepts_secret_str(self):
        from pydantic import SecretStr

        client = AsyncSteamAuthClient(api_key=SecretStr("my_key"))
        assert client._api_key.get_secret_value() == "my_key"
