"""CLI integration tests using typer.testing.CliRunner."""

from __future__ import annotations

import respx
from httpx import Response
from typer.testing import CliRunner

from steam_fetcher.cli._app import app

runner = CliRunner()


class TestCliNoArgs:
    def test_shows_help(self):
        result = runner.invoke(app, [])
        assert (
            "Usage" in result.output or "steam-fetcher" in result.output.lower()
        )

    def test_games_shows_help(self):
        result = runner.invoke(app, ["games"])
        assert "Usage" in result.output or "games" in result.output.lower()

    def test_users_shows_help(self):
        result = runner.invoke(app, ["users"])
        assert "Usage" in result.output or "users" in result.output.lower()


class TestCliGameDetails:
    @respx.mock
    def test_success(self, raw_game_success, tmp_path):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_success)
        )
        out = str(tmp_path / "game")
        result = runner.invoke(app, ["games", "details", "730", "-o", out])
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self, raw_game_failure):
        respx.get("https://store.steampowered.com/api/appdetails").mock(
            return_value=Response(200, json=raw_game_failure)
        )
        result = runner.invoke(app, ["games", "details", "730"])
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliGameSearch:
    @respx.mock
    def test_success(self, raw_search_results, tmp_path):
        respx.get("https://store.steampowered.com/api/storesearch/").mock(
            return_value=Response(200, json=raw_search_results)
        )
        out = str(tmp_path / "search")
        result = runner.invoke(app, ["games", "search", "counter", "-o", out])
        assert result.exit_code == 0
        assert "Exported" in result.output


class TestCliGamePlayers:
    @respx.mock
    def test_success(self, raw_player_count_success):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1"
        ).mock(return_value=Response(200, json=raw_player_count_success))
        result = runner.invoke(app, ["games", "players", "730"])
        assert result.exit_code == 0
        assert "42000" in result.output

    @respx.mock
    def test_not_found(self, raw_player_count_failure):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1"
        ).mock(return_value=Response(200, json=raw_player_count_failure))
        result = runner.invoke(app, ["games", "players", "730"])
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliGameReviews:
    @respx.mock
    def test_success(self, raw_reviews_success, tmp_path):
        respx.get("https://store.steampowered.com/appreviews/730").mock(
            return_value=Response(200, json=raw_reviews_success)
        )
        out = str(tmp_path / "reviews")
        result = runner.invoke(app, ["games", "reviews", "730", "-o", out])
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self, raw_reviews_failure):
        respx.get("https://store.steampowered.com/appreviews/730").mock(
            return_value=Response(200, json=raw_reviews_failure)
        )
        result = runner.invoke(app, ["games", "reviews", "730"])
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliGameNews:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamNews/GetNewsForApp/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "appnews": {
                        "newsitems": [
                            {
                                "gid": "1",
                                "title": "Update",
                                "url": "https://example.com",
                                "author": "Valve",
                                "contents": "text",
                                "date": 1700000000,
                                "feedname": "steam",
                            }
                        ]
                    }
                },
            )
        )
        out = str(tmp_path / "news")
        result = runner.invoke(app, ["games", "news", "730", "-o", out])
        assert result.exit_code == 0
        assert "Exported" in result.output


class TestCliGameSchema:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2"
        ).mock(
            return_value=Response(
                200,
                json={
                    "game": {
                        "gameName": "CS2",
                        "availableGameStats": {
                            "achievements": [
                                {"name": "WIN", "displayName": "Win"}
                            ],
                            "stats": [
                                {"name": "kills", "displayName": "Kills"}
                            ],
                        },
                    }
                },
            )
        )
        out = str(tmp_path / "schema")
        result = runner.invoke(
            app,
            ["games", "schema", "730", "-k", "test_key", "-o", out],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetSchemaForGame/v2"
        ).mock(return_value=Response(200, json={}))
        result = runner.invoke(
            app, ["games", "schema", "730", "-k", "test_key"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserProfile:
    @respx.mock
    def test_success(self, raw_user_profile_success, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_success))
        out = str(tmp_path / "profile")
        result = runner.invoke(
            app,
            [
                "users",
                "profile",
                "76561198000000000",
                "-k",
                "test_key",
                "-o",
                out,
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self, raw_user_profile_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2"
        ).mock(return_value=Response(200, json=raw_user_profile_empty))
        result = runner.invoke(
            app,
            ["users", "profile", "76561198000000000", "-k", "test_key"],
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserLibrary:
    @respx.mock
    def test_success(self, raw_user_library_success, tmp_path):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_success))
        out = str(tmp_path / "lib")
        result = runner.invoke(
            app,
            [
                "users",
                "library",
                "76561198000000000",
                "-k",
                "test_key",
                "-o",
                out,
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self, raw_user_library_empty):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1"
        ).mock(return_value=Response(200, json=raw_user_library_empty))
        result = runner.invoke(
            app,
            ["users", "library", "76561198000000000", "-k", "test_key"],
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserAchievements:
    @respx.mock
    def test_success(self, raw_achievements_success, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_success))
        out = str(tmp_path / "ach")
        result = runner.invoke(
            app,
            [
                "users",
                "achievements",
                "76561198000000000",
                "730",
                "-k",
                "test_key",
                "-o",
                out,
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self, raw_achievements_empty):
        respx.get(
            "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1"
        ).mock(return_value=Response(200, json=raw_achievements_empty))
        result = runner.invoke(
            app,
            [
                "users",
                "achievements",
                "76561198000000000",
                "730",
                "-k",
                "test_key",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserFriends:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetFriendList/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "friendslist": {
                        "friends": [
                            {
                                "steamid": "111",
                                "relationship": "friend",
                                "friend_since": 1600000000,
                            }
                        ]
                    }
                },
            )
        )
        out = str(tmp_path / "friends")
        result = runner.invoke(
            app,
            ["users", "friends", "000", "-k", "test_key", "-o", out],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetFriendList/v1"
        ).mock(return_value=Response(200, json={}))
        result = runner.invoke(
            app, ["users", "friends", "000", "-k", "test_key"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserBans:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerBans/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "players": [
                        {
                            "SteamId": "111",
                            "CommunityBanned": False,
                            "VACBanned": False,
                            "NumberOfVACBans": 0,
                            "DaysSinceLastBan": 0,
                            "NumberOfGameBans": 0,
                            "EconomyBan": "none",
                        }
                    ]
                },
            )
        )
        out = str(tmp_path / "bans")
        result = runner.invoke(
            app, ["users", "bans", "111", "-k", "test_key", "-o", out]
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/GetPlayerBans/v1"
        ).mock(return_value=Response(200, json={"players": []}))
        result = runner.invoke(app, ["users", "bans", "111", "-k", "test_key"])
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserResolve:
    @respx.mock
    def test_success(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "success": 1,
                        "steamid": "76561198000000000",
                    }
                },
            )
        )
        result = runner.invoke(
            app, ["users", "resolve", "testuser", "-k", "test_key"]
        )
        assert result.exit_code == 0
        assert "76561198000000000" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/ISteamUser/ResolveVanityURL/v1"
        ).mock(return_value=Response(200, json={"response": {"success": 42}}))
        result = runner.invoke(
            app, ["users", "resolve", "nobody", "-k", "test_key"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserRecentlyPlayed:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetRecentlyPlayedGames/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "total_count": 1,
                        "games": [
                            {
                                "appid": 730,
                                "name": "CS2",
                                "playtime_2weeks": 120,
                                "playtime_forever": 5000,
                            }
                        ],
                    }
                },
            )
        )
        out = str(tmp_path / "recent")
        result = runner.invoke(
            app,
            [
                "users",
                "recently-played",
                "000",
                "-k",
                "test_key",
                "-o",
                out,
            ],
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetRecentlyPlayedGames/v1"
        ).mock(return_value=Response(200, json={}))
        result = runner.invoke(
            app,
            ["users", "recently-played", "000", "-k", "test_key"],
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserLevel:
    @respx.mock
    def test_success(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetSteamLevel/v1"
        ).mock(
            return_value=Response(200, json={"response": {"player_level": 42}})
        )
        result = runner.invoke(app, ["users", "level", "000", "-k", "test_key"])
        assert result.exit_code == 0
        assert "42" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetSteamLevel/v1"
        ).mock(return_value=Response(200, json={"response": {}}))
        result = runner.invoke(app, ["users", "level", "000", "-k", "test_key"])
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUserBadges:
    @respx.mock
    def test_success(self, tmp_path):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetBadges/v1"
        ).mock(
            return_value=Response(
                200,
                json={
                    "response": {
                        "badges": [
                            {
                                "badgeid": 1,
                                "level": 5,
                                "completion_time": 1600000000,
                                "xp": 100,
                                "scarcity": 50000,
                            }
                        ],
                        "player_xp": 1000,
                        "player_level": 10,
                    }
                },
            )
        )
        out = str(tmp_path / "badges")
        result = runner.invoke(
            app, ["users", "badges", "000", "-k", "test_key", "-o", out]
        )
        assert result.exit_code == 0
        assert "Exported" in result.output

    @respx.mock
    def test_not_found(self):
        respx.get(
            "https://api.steampowered.com/IPlayerService/GetBadges/v1"
        ).mock(return_value=Response(200, json={"response": {}}))
        result = runner.invoke(
            app, ["users", "badges", "000", "-k", "test_key"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output


class TestCliUtilsFormatCallback:
    def test_invalid_format(self):
        result = runner.invoke(app, ["games", "details", "730", "-f", "xml"])
        assert result.exit_code != 0
