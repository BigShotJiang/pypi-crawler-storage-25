"""Tests for Pydantic model validation."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from steam_fetcher.models.game import (
    AppType,
    GameDetails,
    Metacritic,
    Platforms,
    Price,
)
from steam_fetcher.models.player import (
    PlayerCount,
    ReviewSummary,
    SteamSpyDetails,
)
from steam_fetcher.models.search import SearchResult
from steam_fetcher.models.user import (
    Achievement,
    Avatar,
    LibraryGame,
    UserProfile,
)


class TestAppType:
    def test_values(self):
        assert AppType.GAME == "game"
        assert AppType.DLC == "dlc"
        assert AppType.DEMO == "demo"

    def test_from_string(self):
        assert AppType("game") == AppType.GAME


class TestPrice:
    def test_valid(self):
        p = Price(
            currency="USD",
            initial=999,
            final=499,
            discount_percent=50,
            initial_formatted="$9.99",
            final_formatted="$4.99",
        )
        assert p.discount_percent == 50

    def test_negative_price_rejected(self):
        with pytest.raises(ValidationError):
            Price(
                currency="USD",
                initial=-1,
                final=0,
                discount_percent=0,
                initial_formatted="",
                final_formatted="",
            )

    def test_discount_over_100_rejected(self):
        with pytest.raises(ValidationError):
            Price(
                currency="USD",
                initial=100,
                final=0,
                discount_percent=101,
                initial_formatted="",
                final_formatted="",
            )


class TestPlatforms:
    def test_defaults(self):
        p = Platforms()
        assert p.windows is False
        assert p.mac is False
        assert p.linux is False


class TestMetacritic:
    def test_score_bounds(self):
        m = Metacritic(score=83, url="https://metacritic.com/game/test")
        assert m.score == 83

    def test_score_over_100_rejected(self):
        with pytest.raises(ValidationError):
            Metacritic(score=101, url="https://metacritic.com/game/test")


class TestGameDetails:
    def test_minimal(self):
        g = GameDetails(
            app_id=1,
            name="Test",
            type="game",
            is_free=True,
            required_age=0,
        )
        assert g.developers == []
        assert g.categories == []
        assert g.price is None
        assert g.dlc_count == 0

    def test_negative_app_id_rejected(self):
        with pytest.raises(ValidationError):
            GameDetails(
                app_id=-1,
                name="Test",
                type="game",
                is_free=True,
                required_age=0,
            )


class TestPlayerCount:
    def test_valid(self):
        pc = PlayerCount(app_id=730, player_count=42000)
        assert pc.player_count == 42000

    def test_negative_count_rejected(self):
        with pytest.raises(ValidationError):
            PlayerCount(app_id=730, player_count=-1)


class TestReviewSummary:
    def test_score_bounds(self):
        r = ReviewSummary(
            app_id=730,
            total=1000,
            positive=900,
            negative=100,
            score=8,
            score_description="Very Positive",
            review_type="all",
            purchase_type="all",
        )
        assert r.score == 8

    def test_score_over_10_rejected(self):
        with pytest.raises(ValidationError):
            ReviewSummary(
                app_id=730,
                total=1000,
                positive=900,
                negative=100,
                score=11,
                score_description="test",
                review_type="all",
                purchase_type="all",
            )


class TestSteamSpyDetails:
    def test_tags_default(self):
        s = SteamSpyDetails(
            app_id=730,
            name="Test",
            developer="Dev",
            publisher="Pub",
            score_rank="1",
            positive=100,
            negative=10,
            userscore=0,
            owners="1000 .. 2000",
            average_forever=100,
            average_2weeks=10,
            median_forever=50,
            median_2weeks=5,
            ccu=500,
            price="999",
            discount="0",
        )
        assert s.tags == {}


class TestUserProfile:
    def test_optional_fields(self):
        u = UserProfile(
            steam_id="123",
            username="test",
            avatar=Avatar(
                small="https://a.com/s.jpg",
                medium="https://a.com/m.jpg",
                full="https://a.com/f.jpg",
            ),
            profile_url="https://steamcommunity.com/id/test/",
        )
        assert u.real_name is None
        assert u.country_code is None
        assert u.is_public is False


class TestAchievement:
    def test_unlocked(self):
        a = Achievement(
            api_name="WIN_ROUND", achieved=True, unlock_time=1700000000
        )
        assert a.achieved is True

    def test_locked(self):
        a = Achievement(api_name="WIN_ROUND", achieved=False)
        assert a.unlock_time is None


class TestLibraryGame:
    def test_defaults(self):
        g = LibraryGame(app_id=730)
        assert g.name is None
        assert g.playtime_forever == 0
        assert g.playtime_2weeks is None


class TestSearchResult:
    def test_empty(self):
        sr = SearchResult(term="test", total=0)
        assert sr.entries == []


class TestExports:
    """Verify that all key types are importable from top-level."""

    def test_top_level_imports(self):
        from steam_fetcher import (
            AppType,
            AsyncSteamAuthClient,
            AsyncSteamClient,
            GameDetails,
            SteamAuthClient,
            SteamClient,
            SteamSpyDetails,
        )

        assert AppType is not None
        assert SteamSpyDetails is not None
        assert GameDetails is not None
        assert SteamClient is not None
        assert AsyncSteamClient is not None
        assert SteamAuthClient is not None
        assert AsyncSteamAuthClient is not None
