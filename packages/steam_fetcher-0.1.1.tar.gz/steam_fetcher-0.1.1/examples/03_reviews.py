"""
Отзывы с пагинацией (без API ключа).

Запуск:
    uv run python examples/03_reviews.py
"""

from steam_fetcher import SteamClient

with SteamClient() as client:
    # Сводка
    summary = client.get_reviews(730, num_per_page=5, language="all")

if summary is None:
    print("Отзывы не найдены")
    raise SystemExit(1)

print("=== Отзывы CS2 ===")
print(f"Всего:        {summary.total:,}")
print(f"Положительных: {summary.positive:,}")
print(f"Отрицательных: {summary.negative:,}")
print(f"Оценка:       {summary.score}/10 ({summary.score_description})")
print(f"Cursor:       {summary.cursor}")
print(f"Отзывов в ответе: {len(summary.reviews)}")

if summary.reviews:
    print("\n--- Последние отзывы ---")
    for r in summary.reviews[:3]:
        vote = "+" if r.voted_up else "-"
        text = r.review[:80].replace("\n", " ")
        print(f"  [{vote}] ({r.language}) {text}...")
        print(f"      Голосов за: {r.votes_up}, забавных: {r.votes_funny}")
