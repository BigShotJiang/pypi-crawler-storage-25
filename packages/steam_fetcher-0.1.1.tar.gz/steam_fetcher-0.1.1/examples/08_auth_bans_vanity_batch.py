"""
Баны, резолв vanity URL, batch-профили (нужен API ключ).

Запуск:
    export STEAM_API_KEY=your_key
    uv run python examples/08_auth_bans_vanity_batch.py
"""

import os

from steam_fetcher import SteamAuthClient

API_KEY = os.environ.get("STEAM_API_KEY", "")
if not API_KEY:
    print("Установите STEAM_API_KEY: export STEAM_API_KEY=your_key")
    raise SystemExit(1)

with SteamAuthClient(api_key=API_KEY) as client:
    # Resolve vanity URL
    print("=== Resolve vanity URL ===")
    steam_id = client.resolve_vanity_url("gabelogannewell")
    if steam_id:
        print(f"  'gabelogannewell' → {steam_id}")
    else:
        print("  Не найден")

    # Баны (можно передать несколько ID)
    print("\n=== Проверка банов ===")
    test_ids = [steam_id] if steam_id else []
    if test_ids:
        bans = client.get_user_bans(test_ids)
        for ban in bans:
            print(f"  Steam ID: {ban.steam_id}")
            print(
                f"  VAC:       {'да' if ban.vac_banned else 'нет'} ({ban.number_of_vac_bans} бан(ов))"
            )
            print(f"  Game bans: {ban.number_of_game_bans}")
            print(f"  Community: {'да' if ban.community_banned else 'нет'}")
            print(f"  Economy:   {ban.economy_ban}")

    # Batch-загрузка профилей
    print("\n=== Batch-загрузка профилей ===")
    # Используем несколько известных Steam ID
    batch_ids = ["76561198000000000", "76561197960287930"]
    if steam_id:
        batch_ids.append(steam_id)
    profiles = client.get_user_profiles(batch_ids)
    print(f"Запрошено: {len(batch_ids)}, получено: {len(profiles)}")
    for p in profiles:
        print(
            f"  {p.username} ({p.steam_id}) — {'публичный' if p.is_public else 'приватный'}"
        )
