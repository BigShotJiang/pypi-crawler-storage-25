"""
Поиск игр и текущий онлайн (без API ключа).

Запуск:
    uv run python examples/02_search_and_players.py
"""

from steam_fetcher import SteamClient

with SteamClient() as client:
    # Поиск
    results = client.search("half-life", country="US", language="en")

    print(f"Поиск: '{results.term}' — найдено {results.total} результатов\n")
    for entry in results.entries:
        platforms_str = ""
        if entry.platforms:
            p = []
            if entry.platforms.windows:
                p.append("Win")
            if entry.platforms.mac:
                p.append("Mac")
            if entry.platforms.linux:
                p.append("Lin")
            platforms_str = f" [{'/'.join(p)}]"
        print(
            f"  [{entry.app_id:>7}] {entry.name} — {entry.price or 'N/A'}{platforms_str}"
        )

    # Онлайн для нескольких игр
    print("\n--- Текущий онлайн ---")
    for app_id, name in [(730, "CS2"), (570, "Dota 2"), (440, "TF2")]:
        count = client.get_player_count(app_id)
        if count:
            print(f"  {name}: {count.player_count:,} игроков")
        else:
            print(f"  {name}: нет данных")
