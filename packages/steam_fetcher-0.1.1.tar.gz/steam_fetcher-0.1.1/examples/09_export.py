"""
Экспорт данных в JSON и CSV.

Запуск:
    uv run python examples/09_export.py
"""

import json
import os
import tempfile

from steam_fetcher import SteamClient
from steam_fetcher.exporters import CsvExporter, JsonExporter

with SteamClient() as client:
    game = client.get_game(730)
    players = client.get_player_count(730)

if not game or not players:
    print("Не удалось получить данные")
    raise SystemExit(1)

tmpdir = tempfile.mkdtemp()

# JSON
json_path = os.path.join(tmpdir, "game.json")
JsonExporter(indent=2).export([game], json_path)
print(f"JSON → {json_path}")
with open(json_path) as f:
    data = json.load(f)
    print(f"  Записей: {len(data)}")
    print(f"  Поля: {', '.join(list(data[0].keys())[:8])}...")

# CSV
csv_path = os.path.join(tmpdir, "game.csv")
CsvExporter().export([game], csv_path)
print(f"\nCSV → {csv_path}")
with open(csv_path) as f:
    lines = f.readlines()
    print(f"  Строк: {len(lines)} (1 заголовок + {len(lines) - 1} запись)")
    print(f"  Заголовок: {lines[0][:80].strip()}...")

# JSON для player count
players_path = os.path.join(tmpdir, "players.json")
JsonExporter().export([players], players_path)
print(f"\nJSON (players) → {players_path}")
with open(players_path) as f:
    data = json.load(f)
    print(f"  {data}")

print(f"\nФайлы сохранены в: {tmpdir}")
