"""
Профиль пользователя, библиотека, достижения, друз��я, бейджи (��ужен API ключ).

Запуск:
    export STEAM_API_KEY=your_key
    uv run python examples/07_auth_user_profile.py <steam_id>

Пример:
    uv run python examples/07_auth_user_profile.py 76561198000000000
"""

import os
import sys

import httpx

from steam_fetcher import SteamAuthClient

API_KEY = os.environ.get("STEAM_API_KEY", "")
if not API_KEY:
    print("Установите STEAM_API_KEY: export STEAM_API_KEY=your_key")
    raise SystemExit(1)

steam_id = sys.argv[1] if len(sys.argv) > 1 else "76561198000000000"


def safe_call(fn, fallback_msg="Данные недоступны (приватный профиль)"):
    """Вызывает fn(), при HTTP 401/403/400 возвращает None."""
    try:
        return fn()
    except httpx.HTTPStatusError as e:
        if e.response.status_code in (400, 401, 403):
            print(f"\n{fallback_msg}")
            return None
        raise


with SteamAuthClient(api_key=API_KEY) as client:
    # Профиль
    profile = client.get_user_profile(steam_id)
    if profile:
        print(f"=== Профиль: {profile.username} ===")
        print(f"Steam ID:  {profile.steam_id}")
        print(f"Реальное имя: {profile.real_name or 'скрыто'}")
        print(f"Страна:    {profile.country_code or 'скрыто'}")
        print(f"Публичный: {'д��' if profile.is_public else 'нет'}")
        states = {
            0: "Offline",
            1: "Online",
            2: "Busy",
            3: "Away",
            4: "Snooze",
        }
        if profile.persona_state is not None:
            print(f"Статус:    {states.get(profile.persona_state, 'Unknown')}")
        if profile.game_extra_info:
            print(f"Играет в:  {profile.game_extra_info}")
        print(f"Аватар:    {profile.avatar.full}")
    else:
        print(f"Профиль {steam_id} не найден")
        raise SystemExit(1)

    # Уровень
    level = safe_call(lambda: client.get_steam_level(steam_id), "Уровень скрыт")
    if level is not None:
        print(f"\nSteam Level: {level}")

    # Друзья
    friends = safe_call(
        lambda: client.get_user_friends(steam_id),
        "Список друзей скрыт",
    )
    if friends:
        print(f"\nДрузей: {len(friends.friends)}")
        for f in friends.friends[:5]:
            print(f"  {f.steam_id} (с {f.friend_since})")
        if len(friends.friends) > 5:
            print(f"  ... и ещё {len(friends.friends) - 5}")

    # Библиотека
    library = client.get_user_library(steam_id)
    if library:
        print(f"\nБиблиотека: {library.game_count} игр")
        top = sorted(
            library.games,
            key=lambda g: g.playtime_forever,
            reverse=True,
        )
        for g in top[:5]:
            hours = g.playtime_forever / 60
            icon = f" | {g.icon_url}" if g.icon_url else ""
            print(f"  {g.name or g.app_id}: {hours:.0f}ч{icon}")
    else:
        print("\nБиблиотека скрыта")

    # Бейджи
    badges = client.get_user_badges(steam_id)
    if badges:
        print(
            f"\nБейджи: {len(badges.badges)}, XP: {badges.player_xp}, Level: {badges.player_level}"
        )
    else:
        print("\nБейджи скрыты")

    # Недавние игры
    recent = client.get_recently_played(steam_id)
    if recent:
        print(f"\nНедавно играл ({recent.total_count}):")
        for g in recent.games[:5]:
            print(f"  {g.name}: {g.playtime_2weeks} мин за 2 нед.")
    else:
        print("\nНедавние игры скрыты")
