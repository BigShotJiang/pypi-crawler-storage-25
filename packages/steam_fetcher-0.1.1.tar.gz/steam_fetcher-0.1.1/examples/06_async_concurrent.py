"""
Асинхронные параллельные запросы.

Запуск:
    uv run python examples/06_async_concurrent.py
"""

import asyncio

from steam_fetcher import AsyncSteamClient


async def main() -> None:
    async with AsyncSteamClient(requests_per_minute=200) as client:
        # Загружаем 5 игр параллельно
        app_ids = [730, 570, 440, 292030, 1091500]
        games = await asyncio.gather(
            *(client.get_game(app_id) for app_id in app_ids)
        )

        print("=== Параллельная загрузка 5 игр ===\n")
        for game in games:
            if game:
                free = (
                    "Free"
                    if game.is_free
                    else game.price.final_formatted
                    if game.price
                    else "N/A"
                )
                print(f"  {game.name} ({game.app_id}) — {free}")

        # Параллельно: онлайн + отзывы + SteamSpy для CS2
        print("\n=== CS2: параллельные запросы ===\n")
        players, reviews, spy = await asyncio.gather(
            client.get_player_count(730),
            client.get_reviews(730),
            client.get_steamspy_details(730),
        )

        if players:
            print(f"  Онлайн: {players.player_count:,}")
        if reviews:
            print(
                f"  Отзывы: {reviews.score_description} ({reviews.positive:,}/{reviews.total:,})"
            )
        if spy:
            print(f"  Владельцев: {spy.owners}")
            print(f"  Пик CCU: {spy.ccu:,}")


asyncio.run(main())
