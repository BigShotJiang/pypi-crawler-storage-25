"""
Новости игры и глобальные достижения (без API ключа).

Запуск:
    uv run python examples/05_news_and_schema.py
"""

from steam_fetcher import SteamClient

with SteamClient() as client:
    # Новости
    news = client.get_news(730, count=3)
    if news:
        print(f"=== Новости CS2 ({len(news.items)} шт.) ===\n")
        for item in news.items:
            print(f"  [{item.feed_name}] {item.title}")
            print(f"  Автор: {item.author or 'N/A'}")
            print(f"  URL: {item.url}")
            print()

    # Глобальные проценты достижений
    global_ach = client.get_global_achievement_percentages(730)
    if global_ach:
        print(f"=== Глобальные достижения ({len(global_ach.achievements)}) ===")
        sorted_ach = sorted(
            global_ach.achievements, key=lambda a: a.percent, reverse=True
        )
        print("Топ-5 самых популярных:")
        for a in sorted_ach[:5]:
            print(f"  {a.name}: {a.percent:.1f}%")
        print("Топ-5 самых редких:")
        for a in sorted_ach[-5:]:
            print(f"  {a.name}: {a.percent:.2f}%")
    else:
        print("Глобальные достижения не найдены")
