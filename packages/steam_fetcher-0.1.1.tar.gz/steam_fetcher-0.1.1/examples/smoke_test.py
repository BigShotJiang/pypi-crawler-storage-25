"""
Smoke test — проверяет каждый endpoint библиотеки против реального Steam API.

Запуск (публичные):
    uv run python examples/smoke_test.py

Запуск (все, включая авторизованные):
    STEAM_API_KEY=your_key uv run python examples/smoke_test.py
"""

from __future__ import annotations

import os
import sys
import traceback

OK = "\033[32m✓\033[0m"
FAIL = "\033[31m✗\033[0m"
SKIP = "\033[33m⊘\033[0m"

results: list[tuple[str, str, str]] = []


def check(name: str, fn: object) -> None:
    try:
        result = fn()  # type: ignore[operator]
        if result is None:
            results.append((SKIP, name, "returned None"))
        elif isinstance(result, list) and len(result) == 0:
            results.append((SKIP, name, "returned empty list"))
        else:
            results.append((OK, name, repr(result)[:80]))
    except Exception as e:
        import httpx

        # 401/403 on private profiles is expected, not a library bug
        if isinstance(e, httpx.HTTPStatusError) and e.response.status_code in (
            400,
            401,
            403,
        ):
            results.append(
                (
                    SKIP,
                    name,
                    f"HTTP {e.response.status_code} (private/restricted)",
                )
            )
        elif isinstance(
            e, httpx.HTTPStatusError
        ) and e.response.status_code in (
            301,
            302,
        ):
            results.append(
                (SKIP, name, f"HTTP {e.response.status_code} (redirect)")
            )
        else:
            results.append((FAIL, name, f"{type(e).__name__}: {e!s:.80}"))
            traceback.print_exc()
            print()


def main() -> None:
    api_key = os.environ.get("STEAM_API_KEY", "")

    # ─── Публичные эндпоинты (SteamClient) ───

    from steam_fetcher import SteamClient

    print("=== Публичные эндпоинты (SteamClient) ===\n")
    with SteamClient(retries=2, timeout=15.0) as c:
        check("get_game(730)", lambda: c.get_game(730))
        check(
            "get_game(730, country='RU')",
            lambda: c.get_game(730, country="RU"),
        )
        check("get_player_count(730)", lambda: c.get_player_count(730))
        check("get_reviews(730)", lambda: c.get_reviews(730))
        check(
            "get_reviews(730, num_per_page=3, cursor='*')",
            lambda: c.get_reviews(730, num_per_page=3),
        )
        check("search('portal')", lambda: c.search("portal"))
        check(
            "search('portal', country='RU')",
            lambda: c.search("portal", country="RU"),
        )
        check("get_steamspy_details(730)", lambda: c.get_steamspy_details(730))
        check("get_news(730, count=2)", lambda: c.get_news(730, count=2))
        check(
            "get_global_achievement_percentages(440)",
            lambda: c.get_global_achievement_percentages(440),
        )

    # ─── Авторизованные эндпоинты (SteamAuthClient) ───

    if not api_key:
        print(f"\n{SKIP} Пропускаю auth-эндпоинты (нет STEAM_API_KEY)\n")
    else:
        from steam_fetcher import SteamAuthClient

        print("\n=== Авторизованные эндпоинты (SteamAuthClient) ===\n")

        # Сначала resolve vanity URL чтобы получить реальный steam_id
        with SteamAuthClient(api_key=api_key, retries=2, timeout=15.0) as c:
            check(
                "resolve_vanity_url('gabelogannewell')",
                lambda: c.resolve_vanity_url("gabelogannewell"),
            )

            # Используем Gabe Newell's ID как пример публичного профиля
            sid = "76561197960287930"

            check(
                f"get_user_profile('{sid}')",
                lambda: c.get_user_profile(sid),
            )
            check(
                f"get_user_profiles(['{sid}'])",
                lambda: c.get_user_profiles([sid]),
            )
            check(
                f"get_user_friends('{sid}')",
                lambda: c.get_user_friends(sid),
            )
            check(
                f"get_user_bans(['{sid}'])",
                lambda: c.get_user_bans([sid]),
            )
            check(
                f"get_steam_level('{sid}')",
                lambda: c.get_steam_level(sid),
            )
            check(
                f"get_user_badges('{sid}')",
                lambda: c.get_user_badges(sid),
            )
            check(
                f"get_recently_played('{sid}')",
                lambda: c.get_recently_played(sid),
            )
            check(
                f"get_user_library('{sid}')",
                lambda: c.get_user_library(sid),
            )
            check(
                f"get_user_achievements('{sid}', 440)",
                lambda: c.get_user_achievements(sid, 440),
            )
            check(
                f"get_user_stats('{sid}', 440)",
                lambda: c.get_user_stats(sid, 440),
            )
            check(
                "get_game_schema(440)",
                lambda: c.get_game_schema(440),
            )
            check(
                "get_wishlist('{sid}')",
                lambda: c.get_wishlist(sid),
            )
            check(
                "get_app_list(max_results=5)",
                lambda: c.get_app_list(max_results=5),
            )

    # ─── Итог ───

    print("=" * 60)
    passed = sum(1 for s, _, _ in results if s == OK)
    failed = sum(1 for s, _, _ in results if s == FAIL)
    skipped = sum(1 for s, _, _ in results if s == SKIP)

    for status, name, detail in results:
        short = detail[:60]
        print(f"  {status} {name}")
        if status == FAIL:
            print(f"      {short}")

    print()
    print(f"Итого: {passed} passed, {failed} failed, {skipped} skipped")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
