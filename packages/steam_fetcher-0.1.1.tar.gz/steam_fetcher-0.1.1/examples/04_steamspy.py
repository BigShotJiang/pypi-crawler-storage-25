"""
Статистика SteamSpy (без API ключа).

Запуск:
    uv run python examples/04_steamspy.py
"""

from steam_fetcher import SteamClient

with SteamClient() as client:
    spy = client.get_steamspy_details(730)

if spy is None:
    print("Данные SteamSpy не найдены")
    raise SystemExit(1)

print(f"=== SteamSpy: {spy.name} ===")
print(f"Разработчик:     {spy.developer}")
print(f"Издатель:        {spy.publisher}")
print(f"Владельцев:      {spy.owners}")
print(f"Пик CCU:         {spy.ccu:,}")
print(
    f"Среднее время:   {spy.average_forever} мин ({spy.average_forever // 60}ч)"
)
print(
    f"Медиана:         {spy.median_forever} мин ({spy.median_forever // 60}ч)"
)
print(f"За 2 недели:     {spy.average_2weeks} мин")
print(f"Отзывы:          +{spy.positive:,} / -{spy.negative:,}")

if spy.tags:
    top_tags = sorted(spy.tags.items(), key=lambda x: x[1], reverse=True)[:10]
    print("\nТоп теги:")
    for tag, votes in top_tags:
        print(f"  {tag}: {votes}")
